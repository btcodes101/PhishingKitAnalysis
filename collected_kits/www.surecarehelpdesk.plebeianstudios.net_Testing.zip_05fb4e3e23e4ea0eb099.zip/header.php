<?php
  session_start();
  require "includes/dbh.inc.php";
/* Database include for DB connect :p */
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="description" content="This is an example of a meta description. This will often show up in search results.">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <title>Service Desk V1.4</title>
    <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://www.google.com/recaptcha/api.js?render=6LcrUvAbAAAAAPSYPqK8_cLCA4rAUxj7zrmHScyb"></script>
  </head>
  <body><!-- Ignore this body, it's just going to give an error here because the other half is in another include file-->

  <!-- LOGIN SESSION STUFF -->
  <?php
  $usertype = 'guest';
  if (isset($_SESSION['id'])) { /* If visitor is logged in */
      $sql = "SELECT `usertype` FROM users WHERE `idUsers`={$_SESSION['id']}";
      $result = mysqli_query($conn, $sql);
      $row_cnt = mysqli_num_rows($result);
    if ($result) {
        $row = $result->fetch_assoc();
        //echo $result->num_rows;
        $usertype = $row['usertype'];
    } else {
        echo "MYSQL error:" . mysqli_error($conn);
        exit(); /* hecking no! */
    }
}

  switch ($usertype) {
      case 'Admin':

          require "templates/admin_menu.php";
          // code...
          break;
      case 'Staff':

          require "templates/staff_menu.php";
          // code...
          break;
      case 'User':

          require "templates/client_menu.php";
          // code...
          break;
      default:

          require "templates/guest_menu.php";
          // code...
          break;
  }

  ?>
  <!-- LOGIN SESSION STUFF -->

  <!-- PASSWORD ERROR MESSAGE -->
    <?php
    // Error messages
    if (isset($_GET["error"])) {
        if ($_GET["error"] == "wrongpwd") {
            echo "<p>Wrong password</p>";
        }
    }
    ?>
    <!-- PASSWORD ERROR MESSAGE -->

    <!-- LOGIN HANDLER/SIGNUP -->
      <div class="header-login">
  <div class="wrapper d-flex align-items-stretch">
      <nav id="sidebar" class="active">
          <h1><a href="index.html" class="logo">M.</a></h1>
          <ul class="list-unstyled components mb-5">
              <li class="active">
                  <a href="#"><span class="fa fa-home"></span> Home</a>
              </li>
              <li>
                  <a href="#"><span class="fa fa-user"></span> About</a>
              </li>
              <li>
                  <a href="#"><span class="fa fa-sticky-note"></span> Blog</a>
              </li>
              <li>
                  <?php echo '<a href="assets/includes/onetouch.inc.php"><span class="fa fa-heartbeat"></span> One Touch</a>' ?>
              </li>
              <li>
                  <a href="#"><span class="fa fa-ticket"></span>Help Desk</a>
              </li>
          </ul>

          <div style="float: bottom;" class="footer">
              <p>
                  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib.com</a>
              </p>
          </div>
      </nav>

      <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5">

          <div class="navbar navbar-expand-lg navbar-light bg-light">
              <div class="container-fluid">

                  <button type="button" id="sidebarCollapse" class="btn btn-primary">
                      <i class="fa fa-bars"></i>
                      <span class="sr-only">Toggle Menu</span>
                  </button>
                  <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                      <i class="fa fa-bars"></i>
                  </button>

                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <div class="nav navbar-nav ml-auto">
                          <?php
                          if (!isset($_SESSION['id'])) {
                              echo '
            
                                    <form action="includes/login.inc.php" method="post">
                            <input type="text" name="mailuid" placeholder="E-mail/Username">
                            <input type="password" name="pwd" placeholder="Password">   
                            <button onclick="grecaptcha.execute();" type="submit" name="login-submit">Login</button>
                                    </form>
                            <a href="signup.php" class="header-signup">Signup</a>';

                          }
                          else if (isset($_SESSION['id'])) {
                              echo '<form action="includes/logout.inc.php" method="post">
                            <button type="submit" name="login-submit">Logout</button>
                                    </form>
                            <a href="profile.php" class="header-signup">Profile</a>';
                          }
                          ?>
                      </div>
                  </div>
              </div>
          </div>


