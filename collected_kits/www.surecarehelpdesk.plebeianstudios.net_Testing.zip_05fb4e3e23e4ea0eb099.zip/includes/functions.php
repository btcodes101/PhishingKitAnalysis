<?php
include "dbh.inc.php";
// move to settings page
date_default_timezone_set('Europe/London');

