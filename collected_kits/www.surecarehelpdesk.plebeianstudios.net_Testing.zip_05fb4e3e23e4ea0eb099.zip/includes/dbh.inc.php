<?php
$dBServername = "localhost"; //Always leave this as local host!
$dBUsername = "main"; //With xampp you're going to need to make a new SQL user in http://localhost/phpmyadmin
$dBPassword = "mysql"; //You're going to need to set the password for this user
$dBName = "ticketsystem"; //The name of the database, just create one called ticketsystem and import the ticketsystem.sql into it!

// Create connection
$conn = mysqli_connect($dBServername, $dBUsername, $dBPassword, $dBName);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
