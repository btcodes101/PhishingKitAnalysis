

<footer class="footer">
    <div class="copyright" style="text-align: center" class="copyright">Copyright © <script wfd-invisible="true">document.write(new Date().getFullYear());</script> Mark Bentley. All Rights Reserved</div>
</footer>
<script src="assets/js/grecaptcha.js"></script>
</body>

</html>
