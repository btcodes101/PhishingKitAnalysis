<?php

session_start();

require "includes/dbh.inc.php";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="This is an example of a meta description. This will often show up in search results.">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="./assets/css/style.css">
    <script src="https://www.google.com/recaptcha/api.js?render=6LcrUvAbAAAAAPSYPqK8_cLCA4rAUxj7zrmHScyb"></script>
</head>
<body>


<header>

    <nav class="nav-header-main">

        <div>
            <a class="header-logo" href="../index.php">
                <img src="assets/img/logo.png" alt="surecare logo">
            </a>
        </div>
    </nav>

    <div class="header-login">

        <!--
                if (!isset($_SESSION['id'])) {
            echo '<form action="includes/login.inc.php" method="post">
            <input type="text" name="mailuid" placeholder="E-mail/Username">
            <input type="password" name="pwd" placeholder="Password">
            <button type="submit" name="login-submit">Login</button>
          </form>
          <a href="signup.php" class="header-signup">Signup</a>';
        }
        else
        -->

        <?php if (isset($_SESSION['id'])) {
            echo '<form action="includes/logout.inc.php" method="post">
            <button type="submit" name="login-submit">Logout</button>
          </form>';
        }
        ?>
    </div>
</header>
