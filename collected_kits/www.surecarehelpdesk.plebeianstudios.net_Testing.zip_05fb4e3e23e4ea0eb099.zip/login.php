<?php
  require "header.php";
?>
<style>
    .notice_border {
        text-align: center;
        box-sizing: border-box;
        border-left-style: solid;
        border-width: 5px;
        width: 500px;
        box-shadow: 0 4px 8px 0 rgb(0 41 89 / 10%);
        margin-top: 15px;
        padding: 20px 28px;
        margin-bottom: 8px;
        border-color:#e64342!important;
        background-color:#ffebeb!important
    }
</style>
<main>
    <div class="wrapper-main">
        <section class="section-default">
            <h1>Login</h1>
            <?php
            // Error messages
            if (isset($_GET["error"])) {
                if ($_GET["error"] == "wrongpwd") {
                    echo "<div style='margin:auto;' class='notice_border'>
                            <p class='notice_text'><b>ERROR: </b>Incorrect username or password</p>
                            </div>";
                }
            }
            ?>
            <form class="form-signup" action="includes/login.inc.php" method="post">
                <?php
                if (!isset($_SESSION['id'])) {
                    echo '<input type="text" name="mailuid" placeholder="E-mail/Username">
                            <input type="password" name="pwd" placeholder="Password">
                        <button onclick="grecaptcha.execute();" type="submit" name="login-submit">Login</button>
                        </form>
                       <div align="center">
                    <a href="signup.php" class="header-signup">Signup</a>
                        <a href="reset-password.php" class="header-signup">Forgot Password</a>
                    </div>';
                }
                ?>

<?php
  require "footer.php";
?>

