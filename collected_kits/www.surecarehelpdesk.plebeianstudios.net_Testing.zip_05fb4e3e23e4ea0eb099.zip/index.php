<?php
  require "header.php";
?>
    <main>
      <div class="wrapper-main">
        <section class="section-default">
          <?php
          switch ($usertype) {
              case 'Admin':
              case 'Staff':
                  //echo '<p class="login-status">Welcome back '.$_SESSION['uid'].'!<br> ME AND THE BOYS AT 3AM LOOKING FOR BEANNNNNNS</p>';
                  // code...
                  break;
             // case 'Staff':
                 // echo '<p class="login-status">Welcome back '.$_SESSION['uid'].'! There is XYZ amount of tickets open!</p>';
                  // code...
                //  break;
              case 'User':
                  //echo '<p class="login-status">Welcome back '.$_SESSION['uid'].'! Remember to check the knowledge base, we update it regularly!</p>';
                  // code...
                  break;
              default:
                  //echo '<p class="login-status">Please login or <a href="signup.php">register</a> to create a ticket and view the knowledge base!</p>';
                  // code...
                  break;
          }

          ?>

        </section>
          <!-- Knowledge base search here hopefully -->

      </div>
    </main>
<?php
switch ($usertype) {
    case 'Admin':
        include("templates/admin_index.php");
        // code...
        break;
    case 'Staff':
        include("templates/staff_index.php");
        // code...
        break;
    case 'User':
        include("templates/user_index.php");
        // code...
        break;
    default:

        // code...
        break;
}

?>

<?php
  require "footer.php";
?>

