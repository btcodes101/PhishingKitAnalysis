<?php require "includes/chat.inc.php"; ?>
<p>test</p>
