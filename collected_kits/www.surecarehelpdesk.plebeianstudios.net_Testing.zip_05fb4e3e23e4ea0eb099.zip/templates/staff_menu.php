<header>
    <nav class="nav-header-main">
        <div>
            <a class="header-logo" href="../index.php">
                <img src="assets/img/logo.png" alt="surecare logo">
            </a>
        </div>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="dashboard.php">Just</a></li>
            <li><a href="#">A</a></li>
            <li><a href="#">PLACEHOLDER</a></li>
        </ul>
    </nav>
    <div class="header-login">
