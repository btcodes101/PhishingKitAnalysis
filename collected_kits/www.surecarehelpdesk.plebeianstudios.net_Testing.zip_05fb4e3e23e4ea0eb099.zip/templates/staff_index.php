<main>
    <div class="wrapper-main">
        <section class="section-default">


        </section>
        <!-- Knowledge base search here hopefully -->

    </div>
</main>
