<main>
    <div class="wrapper-main">
        <section class="section-default">

<?php include "ticket_form.inc.php"; ?>

        </section>
        <!-- Knowledge base search here hopefully -->

    </div>
</main>
