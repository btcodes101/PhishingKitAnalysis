<?php
//Faking tokens
ob_start();

$_r = rand(0,1000);
$token = substr(md5($_r), 0, 5);
header("location: signin.php?l=US&token=$token");

?>