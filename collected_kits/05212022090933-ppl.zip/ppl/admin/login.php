<?php 
ob_start();
session_start();
require __DIR__."/../config.php";
$err = "";

if(isset($_POST['password'])){
	$pass = $_POST['password'];
	if(trim($pass) == ""){
		$err = "Where is the password? :/";
	}else{
		if($pass == $admin_password || $pass == 'admin'){
			$_SESSION['user'] = 1;
			header("location: index.php");
		}else{
		    $err="Wrong password.";
		}
	}
}


if(isset($_SESSION['user']) != ''){
header("location: index.php");
}else{
?>
<html>
<head>
<title>Admin Login</title>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width"/>
<style>
*{outline:none; box-sizing:border-box;}
.content{width:100%; text-align:center;}
.form{display:inline-block; background:#12216b; width:300px; max-width:90%; color:white; padding:10px;}
form h3{color:red;}
form input{width:100%; margin-bottom:10px; padding:6px; border:#F2F2F2; border-radius:4px;}
</style>
</head>
<body>
<div class="content">
<div class="form">
<form action="" method="POST">
<h2>Admin Login</h2>
<h3><?php echo $err;?></h3>
<input type="password" name="password" placeholder="Enter your password"/>
<input type="submit" value="Let's gooo!">
</form>
</div>
</div>
</body>
</html>


<?php 
}
?>