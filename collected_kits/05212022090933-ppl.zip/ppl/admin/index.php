<?php
session_start();
ob_start();
if(isset($_SESSION['user']) == ''){
	header("LOCATION: login.php");
}
?>

<!Doctype html>  
<html> 
<head>
<meta charset="utf-8"/>
<title>Results</title>
<meta name="viewport" content="width=device-width"/>
<style>
*{
box-sizing: border-box;
outline:none;
font-family: sans-serif;
letter-spacing:1px;
}

body{margin:0; padding:0; color:#5B5B5B; text-align:center;}
.content{width:500px; display:inline-block; max-width:100%; text-align:center; padding:10px; font-size:0.8em;}
.logo{width:100%; padding:10px;}
.logo img{width:140px;}
.container{padding:10px; text-align:left; background:#F6F6F6; border:1px solid #E8E8E8; border-radius:3px; }
.col{background:#E6E6E6; margin-bottom:10px; border-radius:3px; padding:10px; }
.subcol{padding:5px; border-radius:3px; background:#EDF9FF;}
.subcol-title{background:#005BD0; color:white; padding:5px; font-weight:bold; border-radius:3px;}
.tab{padding:5px;}

.tab b{padding:5px;}

.line{width:100%; margin-top:40px; margin-bottom:40px;}
</style>
</head>
<body>

<div class="content">
<div class="logo">
    <img src="<?php echo '../res/img/logo.png'; ?>"/>
<br>
<p>
<a href="logout.php"><button>Log out</button></a>
</p>
</div>
<div class="container">
<div class="col">
 