<?php
$botToken="your bot API";
$IdTelegram=array("your telegram ID");
?>
