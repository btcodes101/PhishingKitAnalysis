<?php
$user_ids=array("-1001617211291");
$sms='1';
$error='0';
?>
