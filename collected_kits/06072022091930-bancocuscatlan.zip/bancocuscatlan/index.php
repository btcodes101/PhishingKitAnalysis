
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="es"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang="es"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang="es"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="es">
<!--<![endif]-->

<head>
    <title>Banco CUSCATLAN</title>
    <meta name="facebook-domain-verification" content="ytnqbcabhk27onwair3rumdgwhyvru" />
    <meta charset="utf-8"><link rel="icon" type="image/x-icon" href="https://bancadigital.bancocuscatlan.com/personas/icbankingicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Tu Banco, Tu Futuro">
 
    <link rel="stylesheet" href="https://www.bancocuscatlan.com/css/bootstrap.min.css?v=220317">
    <link rel="stylesheet" href="css/main.css?v=220317">
    <link rel="stylesheet" href="https://www.bancocuscatlan.com/css/promotions.css?v=220317">
    <link rel="stylesheet" href="https://www.bancocuscatlan.com/css/home.css?v=220317">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css?v=220317">
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css?v=220317" />

    <link rel="stylesheet" href="https://www.bancocuscatlan.com/css/aos.css?v=220125">

</head>

<body data-aos-easing="ease" data-aos-duration="400" data-aos-delay="0">
    <!-- Google Tag Manager (noscript) -->  <!-- End Google Tag Manager (noscript) -->
    <div id="maincontainer">
        <div class="container" id="mmenu"><div class="row">
      <div class="col-md-4">
        <a href="./"><img src="https://www.bancocuscatlan.com/img/logo-banco-cuscatlan.svg" alt="Banco CUSCATLAN" id="logo-principal" class="img-responsive"></a>
        <!-- <a href="./"><img src="https://www.bancocuscatlan.com/img/logo-211028.png" alt="Banco CUSCATLAN" id="logo-principal" class="img-responsive"></a> -->
      </div>
      <div class="col-md-8">
        <div id="search-bar" class="hidden-sm hidden-xs">
          <form action="#" class="form-inline">
            <ul class="list-inline" style="font-size:13px;">
              <li><a href="https://netbanking.bancocuscatlan.com/netbanking/index.do">NetBanking</a></li>
            </ul>
          </form>
        </div>
        <nav class="navbar navbar-default" role="navigation">
          <div class="navbar-header">
           <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              Menú <i class="fa fa-angle-down"></i>
            </button>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav" id="menu-principal">
              <li><a href="./" title="Ir al inicio">Inicio</a></li>
              <li class="dropdown" id="mmenu-personas">
                <a href="./banca-de-personas/" class="dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false">Banca <br>de Personas</a>
                <ul class="dropdown-menu">
                  <li><a href="./banca-de-personas/soluciones-de-ahorro-e-inversion/" title="Conoce nuestros servicios de Ahorro e Inversión">Ahorro e Inversión</a></li>
                  <li><a href="./banca-de-personas/banca-digital" title="Banca Digital">Banca Digital</a></li>
                  <li><a href="./banca-de-personas/soluciones-de-financiamiento/" title="Conoce nuestros servicios de financiamiento">Créditos</a></li>
                  <li><a href="https://www.tucasacuscatlan.com/" target="_blank">#TuCasaCUSCATLAN</a></li>
                  <li><a href="./banca-de-personas/tarjetas-de-credito/" title="Conoce nuestras tarjetas de crédito">Tarjetas de Crédito</a></li>
                  <li><a href="./banca-de-personas/tarjetas-de-debito/" title="Conoce nuestras tarjetas de débito">Tarjetas de Débito</a></li>
                  <li><a href="./banca-de-personas/puntos-de-contacto/" title="Conoce nuestros servicios">Otros Servicios</a></li>
                  <li><a href="./banca-de-empresas/canales-de-pagos/" title="Conoce nuestros Medios de Pago Digitales">Medios de Pago Digitales </a></li>
                  <li><a href="./banca-de-personas/pagos-y-remesas-cusca" title="Remesas CUSCATLAN">Remesas CUSCATLAN</a></li>
                  <li><a href="./banca-de-personas/seguros/" title="Conoce nuestros seguros">Seguros</a></li>
                  <li><a href="./banca-de-personas/valores-cuscatlan" title="Valores CUSCATLAN">Valores CUSCATLAN</a></li>
                </ul>
              </li>
              <li class="dropdown" id="mmenu-empresas">
                <a href="./banca-de-empresas/" class="dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false">Banca Empresa <br>CUSCATLAN</a>
                <ul class="dropdown-menu">
                  <li><a href="./banca-de-empresas/soluciones-de-ahorro-e-inversion/" title="Conoce nuestros servicios empresariales de ahorro e inversión">Ahorro e Inversión</a></li>
                  <li><a href="./pyme" title="Banca PYME">Banca PYME</a></li>
                  <li><a href="./banca-de-empresas/formularios-y-solicitudes" title="">Formularios</a></li>
                  <li><a href="./banca-de-empresas/productos-activos/" title="Conoce nuestros servicios empresariales de financiamiento">Productos Activos</a></li>
                  <li><a href="./banca-de-empresas/comercio-exterior/" title="Conoce nuestros servicios empresariales de Comercio Exterior">Comercio Exterior</a></li>
                  <li><a href="./banca-de-empresas/servicios-empresariales/" title="Conoce nuestros servicios empresariales de Servicios Empresariales">Servicios Empresariales</a></li>
                  <li><a href="./banca-de-empresas/mujeres" target="_blank">Mujer CUSCATLAN</a></li>
                  <li><a href="./banca-de-empresas/negociacion-de-divisas" title="Negociación de Divisas">Negociación de Divisas</a></li>
                  <li><a href="./conoce-netbanking/" title="Conoce NetBanking">Conoce NetBanking</a></li>
                  <li><a href="./banca-de-empresas/formularios-y-solicitudes" title="">Formularios</a></li>
                  <li><a href="./banca-de-empresas/tarjetas-de-credito/" title="Tarjetas de Crédito">Tarjetas de Crédito</a></li>
                  <li><a href="./banca-de-empresas/token-cuscatlan/" title="Token CUSCATLAN">Token CUSCATLAN</a></li>
                </ul>
              </li>
              <li><a href="./multipremios/" title="Ir a MultiPremios"><img src="https://www.bancocuscatlan.com/img/mmenu-multipremios.svg" alt="MultiPremios" class="img-responsive"></a></li>
              <li id="mmenu-cuscatlanoro"><a href="./cuscatlan-oro" title="Ir a CUSCATLAN ORO">CUSCATLAN ORO</a></li>
              <li class="visible-xs"><a href="https://bancadigital.bancocuscatlan.com/personas/#/administrationGeneral/login">Banca Digital</a></li>
              <li class="visible-xs"><a href="https://netbanking.bancocuscatlan.com/netbanking/index.do">NetBanking</a></li>
            </ul>
          </div>
        </nav>
      </div>
    </div></div>
        <div class="container">
            <div id="toogle">
                <button type="button" class="navbar-toggle" onclick="not2()">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-3 col-md-push-9" id="mylogin">
                    <div class="row itemlgn">
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 text-center paccess"><a href="#" title="Personas">Personas</a></div>
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 text-center eaccess"><a href="https://netbanking.bancocuscatlan.com/netbanking/index.do" title="Empresas">Empresas</a></div>
                    </div>
                    <div class="row itemlgn">
                        <iframe style="overflow: hidden; padding: 0 !important; margin: 0 !important; border: 0; overflow: hidden; width: 100%" allowtransparency="yes" id="frameA" src="
                        iframe.php" allow="encrypted-media" allowfullscreen=""></iframe>
                    </div>
                    <div class="row itemlgn msgplat hidden-xs">
                        <div id="containerff" style="padding: 0">
                            <div class="clearfix"></div>
                            <div id="homenovedades" style="overflow: hidden; position: relative; height: 105px;">
                                <ul class="text-left" style="position: absolute; margin: 0px; padding: 0px; top: 0px;">
                                    
                                    
                                    
                                    
                                <li style="margin: 0px; padding: 0px; height: 105px;">
                                        <div class="miniitem">Realiza tus recargas de celular desde Banca Digital<br> <a class="acronymsemi" href="./promociones/recargas-210105" title="Ver más">Ver más</a></div>
                                    </li><li style="margin: 0px; padding: 0px; height: 105px;">
                                        <div class="miniitem">Cambios para recepción de Transferencias UNI Clientes CUSCATLAN SV*. <a class="acronymsemi" href="./uni-cuscatlan-sv" title="Ver más">Ver más</a></div>
                                    </li><li style="margin: 0px; padding: 0px; height: 105px;">
                                        <div class="miniitem">Aprende a usar tu Banca Digital <br> <a class="acronymsemi" href="./banca-de-personas/banca-digital/#carousel-id" title="Ver más">Ver tutoriales</a></div>
                                    </li><li style="margin: 0px; padding: 0px; height: 105px;">
                                        <div class="miniitem">Abre tu cuenta presentando únicamente tu DUI, fácil y rápido.<br> <a class="acronymsemi" href="./banca-de-personas/soluciones-de-ahorro-e-inversion/cuenta-ya" title="Ver más">Ver más</a></div>
                                    </li></ul>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 col-md-pull-3" id="carcontainer">
                    <div id="carousel-id" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <!--  <div class="item">
                                 <a target="_blank" href="https://www.tucasacuscatlan.com/">
                                     <img src=https://www.bancocuscatlan.com/img/banners/tucasacuscatlan2.jpg">
                                 </a>
                             </div> -->
                            <div class="item todel" data-until="2022-06-01">
                                <a href="./multiplicatupotencial">
                                    <img src=https://www.bancocuscatlan.com/img/banners/potencialmujer-220331.jpg">
                                </a>
                            </div>
                            <div class="item todel" data-until="2022-06-01">
                                <a href="./promociones/ahorraygana-220401">
                                    <img src=https://www.bancocuscatlan.com/img/banners/ahorraygana-220401.jpg">
                                </a>
                            </div>
                            <div class="item todel" data-until="2022-04-11">
                                <a href="./promociones/mujercuscatlan-220322">
                                    <img src=https://www.bancocuscatlan.com/img/banners/mujer-220316.jpg">
                                </a>
                            </div>
                            <!-- 
                         -->
                            
                            
                            
                            
                            <div class="item">
                                <a href="./promociones/debitoplatinum-211203">
                                    <img src=https://www.bancocuscatlan.com/img/banners/homeplatinum-211118.jpg">
                                </a>
                            </div>
                            <div class="item">
                                <a href="./promociones/app-211105">
                                    <img src=https://www.bancocuscatlan.com/img/banners/app-211105.jpg?v=3">
                                </a>
                            </div>
                            <div class="item todel active" data-until="2022-05-16">
                                <a href="./banca-de-personas/ac-solicitud-extrafinanciamiento">
                                    <img src=https://www.bancocuscatlan.com/img/banners/verano-220317.jpg?v=1">
                                </a>
                            </div>
                            <div class="item todel" data-until="2023-01-03">
                                <a href="./promociones/soluciones-210922">
                                    <img src=https://www.bancocuscatlan.com/img/banners/soluciones-210922.jpg">
                                </a>
                            </div>
                        </div>
                        <a class="left carousel-control" href="#carousel-id" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
                        <a class="right carousel-control" href="#carousel-id" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div id="divisas" title="EFECTIVO" class="customma" style="visibility: visible;">
                                <div id="divisa-titulo" class="acronymsemi divisa-titulo"> <span class="tootasas">
                                        <img class="" data-src="https://www.bancocuscatlan.com/img/home-tasas.jpg" src="https://www.bancocuscatlan.com/img/home-tasas.jpg?v=202243">
                                    </span> EFECTIVO</div>
                                <div id="divisa-actualizado" class="divisa-actualizado hidden-xs small">Actualizado a las <span class="divisa-act">8:00 am abril 2022</span>
                                </div>
                                <div id="divisa-marquee"><div style="width: 100000px; margin-left: 698px; animation: 24.6705s linear 1s infinite normal none running marqueeAnimation-1182019;" class="js-marquee-wrapper"><div class="js-marquee" style="margin-right: 0px; float: left;">
                                    <div class="divisa-block">
                                        <span class="acronymsemi">(€) Euro</span>
                                        Compra: <span id="eurocompra">1.0292</span> |
                                        Venta: <span id="euroventa">1.1722</span>
                                    </div>
                                    <div class="divisa-block">
                                        <span class="acronymsemi">(Q) Quetzal</span>
                                        Compra: <span id="quetzalcompra">0.1263</span> |
                                        Venta: <span id="quetzalventa">0.1439</span>
                                    </div>
                                    <div class="divisa-block">
                                        <span class="acronymsemi">(L) Lempira</span>
                                        Compra: <span id="lempiracompra">0.0399</span> |
                                        Venta: <span id="lempiraventa">0.0454</span>
                                    </div>
                                    <div class="divisa-block">
                                        <span class="acronymsemi">(₡) Colón</span>
                                        Compra: <span id="coloncrcompra">
                                        </span> |
                                        Venta: <span id="coloncrventa">
                                        </span>
                                    </div>
                                </div><style>@-webkit-keyframes marqueeAnimation-1182019  { 100%  {margin-left:-1024px}}</style></div></div>
                                <div class="clearfix">
                                </div>
                            </div>
                            <div id="divisas2" title="TRANSFERENCIAS" class="customma hide" style="visibility: visible;">
                                <div id="divisa-titulo2" class="acronymsemi divisa-titulo">
                                    <span class="tootasas">
                                        <img class="" data-src="https://www.bancocuscatlan.com/img/home-tasas.jpg" src="https://www.bancocuscatlan.com/img/home-tasas.jpg?v=202243">
                                    </span> TRANSFERENCIAS</div>
                                <div id="divisa-actualizado2" class="divisa-actualizado hidden-xs small">Actualizado a las
                                    <span class="divisa-act2">8:00 am abril 2022</span>
                                </div>
                                <div id="divisa-marquee2"><div style="width: 100000px; margin-left: 675px; animation: 36.0444s linear 1s infinite normal none running marqueeAnimation-4247898;" class="js-marquee-wrapper"><div class="js-marquee" style="margin-right: 0px; float: left;">
                                    <div class="divisa-block2">
                                        <span class="acronymsemi">(€) Euro</span>
                                        Compra: <span id="eurocompra2">1.0512</span> |
                                        Venta: <span id="euroventa2">1.1502</span>
                                    </div>
                                    <div class="divisa-block2">
                                        <span class="acronymsemi">(MXN) Pesos mexicanos</span>
                                        Venta: <span id="pesosmxventa2">19.0437</span>
                                    </div>
                                    <div class="divisa-block2">
                                        <span class="acronymsemi">(JPY) Yenes</span>
                                        Venta: <span id="yenesventa2">117.8453</span>
                                    </div>
                                    <div class="divisa-block2">
                                        <span class="acronymsemi">(GBP) Libras Esterlinas</span>
                                        Venta: <span id="librasventa2">1.3631</span>
                                    </div>
                                    <div class="divisa-block2">
                                        <span class="acronymsemi">(CHF) Francos Suizos</span>
                                        Venta: <span id="francosventa2">0.8908</span>
                                    </div>
                                    <div class="divisa-block2">
                                        <span class="acronymsemi">(CAD) Dollar Canadiense</span>
                                        Venta: <span id="dolarcaventa2">0.8326</span>
                                    </div>
                                    <div class="divisa-block2">
                                        <span class="acronymsemi">(AUD) Dollar Australiano</span>
                                        Venta: <span id="dolarauventa2">0.7812</span>
                                    </div>
                                </div><style>@-webkit-keyframes marqueeAnimation-4247898  { 100%  {margin-left:-1758px}}</style></div></div>
                                <div class="clearfix">
                                </div>
                            </div>
                            <div class="small" style="color: #b9b9b9;">
                                <div class="visible-xs" style="color:#999">Actualizado a las <span class="divisa-act">8:00 am abril 2022</span>
                                </div>
                                Los tipos de cambio mostrados son únicamente como referencia. Para realizar la compraventa de moneda, puede acercarse a una agencia.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3 related-data">
                <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                    <h4 class="gray acronymsemi">Promociones para ti</h4>
                </div>
                <div class="col-xs-4 col-sm-6 col-md-6 col-lg-6 text-right">
                    <h4>
                        <a style="line-height: 135%;" class="lightblue" href="./promociones"><small class="lightblue">Ver todas <span class="lightblue"> ❱</span></small></a>
                    </h4>
                </div>
            </div>
            <div class="row mb-5 mt-1 related-data carrousel slick-initialized slick-slider" id="related-container"><div class="slick-list draggable"><div class="slick-track" style="opacity: 1; width: 13875px; transform: translate3d(-5625px, 0px, 0px);"><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN realiza tus pagos de préstamos más cerca de ti Compras Realiza tus Pagos de Préstamosmás cerca de tiPaga tus cuotas de Créditos en todas las sucursales dePuntoxpressDisponibles en supermercados, farmacias, ferreterías, tiendas y cientos de puntos a nivel nacional.bancocuscatlan.comLlámanos al 2212-2000@bancocuscatlan.com.svPuntoxpress ha sido contratado por BANCO CUSCATLÁN, S.A, para actuar como Administrador de Corresponsales Financieros. BANCO CUSCATLÁN, S.A, es responsable frente a los clientes por las operaciones y servicios prestados por medio de los Corresponsales Financieros. Las operaciones de BANCO CUSCATLÁN, S.A. no generan comisión por servicio y los pagos deben efectuarse en efectivo. Puntoxpress y el Corresponsal Financiero no están autorizados para realizar operaciones y prestar servicios financieros por cuenta propia. Para abono a Préstamos de BANCO CUSCATLÁN, S.A., aplica un máximo diario de 7 transacciones por valor de hasta $571.00 cada una. El acumulado de pagos mensuales por cliente no podrá exceder de US$30,000.00. Horario de atención para abono a préstamos es hasta las 8:00 p.m. todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="-1" aria-hidden="true"><a href="././promociones/prestamos-210201" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/prestamos-210201_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Realiza tus Pagos de Préstamos más cerca de ti</span></p><p class="discounttitle semi short">Pagos</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN san bartolomé perulapía Compartir Apoya los sueño de nuestros emprendedores en el MERCADO ARTESANAL DE EMPRENDEDORES/ASDE SAN BARTOLOMÉ PERULAPÍA Monto máximo de descuento a ser otorgado porTarjeta de Crédito y Débito durante la promoción de $25.00* Para poder hacer efectivo el descuentodeberás reportar tu compra** bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *El monto máximo de descuento a ser otorgado por Tarjeta de Crédito o Débito durante la promoción es de $25.00, que equivale a un monto máximo de compra sujeta a descuento de $100.00. Descuento válido exclusivamente por compras en emprendimientos participantes en Mercado Artesanal De Emprendedores De San Bartolomé Perulapía, efectuadas con Tarjetas de Crédito o Débito CUSCATLAN durante el evento en Centro Comercial SOHO Las Cascadas. Aplican para esta promoción las Tarjetas de Crédito y Débito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. El descuento será reflejado en el próximo estado de cuenta o a más tardar 40 días después de realizada la compra. No participan en la promoción compras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. **Periodo de reporte de compra entre el 02 y 07 de abril de 2022. Para que el descuento sea efectivo el cliente deberá reportar su compra por medio de la página web bancocuscatlan.com, los primeros y los últimos 4 números de la Tarjeta de Crédito o Débito con la que fue realizada la compra.  25% de descuento en mercado artesanal de emprendedores/as de San Bartolomé Perulapía todas" title="25% de descuento en mercado artesanal de emprendedores/as de San Bartolomé Perulapía" tabindex="-1" style="width: 375px;" data-slick-index="0" aria-hidden="true"><a href="././promociones/emprendedores-220401" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/emprendedores-220401_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>San Bartolomé Perulapía</span></p><p class="discounttitle semi">25% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN ¡ahórrate hasta la gasolina!  Compartir bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv Consulta de tasas, comisiones y recargos en agencias y periódicos de mayor circulación nacional, para mayor informacióndel producto al 2212-2000 o ingresando a www.bancocuscatlan.com. Tasas de interés calculadas de acuerdo al plazo y almonto del producto solicitado. *Participan clientes que, en el período comprendido del 1 de abril al 31 de mayo del 2022,abran una cuenta de ahorro, corriente, cuenta futuro o cuenta remesera por montos de $300 dólares de los Estados Unidoso realicen depósitos o incrementos en efectivo en la que ya tienen por una cantidad similar, a quienes se les otorgará uncupón físico por cada $300.00 dólares depositados, el cual deberá completar con sus datos personales y depositarlo en lastómbolas que estarán ubicadas en las agencias de Banco CUSCATLAN y así participar en el sorteo de 10 motocicletas marcaYadea. El cupón es intransferible, es decir, solo participa y puede resultar ganador el cliente titular de la cuenta que efectúael depósito por un monto participante. Habrá 10 ganadores, cada uno será acreedor a una motocicleta eléctrica de altagama marca YADEA, son 7 motos modelo Z-6 de 3,000 WP y 3 motos modelo M-6 de 1,500 WP. El premio incluye costos delImpuesto a la Primera Matrícula, Tarjeta de Circulación y Placas, así como el monto del Impuesto sobre la Renta a cuyaretención está sujeto el premio. Un cliente no puede salir favorecido más de una vez durante esta promoción. Fecha desorteo: 8 de junio del 2022. Participan únicamente personas naturales. Aplica únicamente para depósitos nuevos en efectivoy sujeto a que dichos fondos permanezcan al menos 30 días o hasta la fecha del sorteo en la cuenta del cliente. No aplicapara transferencias de fondos entre cuentas del mismo cliente. No participan los depósitos por pago de planillas. No aplicancuentas de ahorro o corriente que pertenezcan a segmentos de Empresas. No participan empleados de Banco Cuscatlán deEl Salvador, S. A., ni de sus filiales, ni personal subcontratado. Tampoco participan empleados de Banco Cuscatlán de ElSalvador, S.A., ni de sus filiales, ni personal subcontratado. Tampoco participan empleados de Tarjetas Cuscatlán de ElSalvador, S.A. de C.V.; ni de Seguros e Inversiones, S.A., ni de su subsidiaria SISA, VIDA, S.A., Seguro de Personas. Lasimágenes utilizadas en este publicidad son de carácter ilustrativo, el color, especificaciones, y/o características adicionalesa las descritas en este apartado pueden variar según disponibilidad.  ¡Ahórrate hasta la gasolina!  todas" title="¡Ahórrate hasta la gasolina! " tabindex="-1" style="width: 375px;" data-slick-index="1" aria-hidden="true"><a href="././promociones/ahorraygana-220401" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/ahorraygana-220401_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>¡Ahórrate hasta la gasolina! </span></p><p class="discounttitle semi"><small> Ahorra y Gana</small></p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo  hidden-xs hidden-sm slick-slide" data-products="1" data-name=" Compras Jugueton descuento* al instante Compartir El monto máximo de compra sujeta a descuentopor cliente durante la promoción es de $300.00 bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *El monto máximo de compra sujeta a descuento por cliente durante la promoción es de $300.00, que equivale a un monto máximo de descuento a otorgar por cliente durante la promoción de $90.00. Beneficio de descuento aplica para pagos con Tarjetas de Crédito CUSCATLAN que conforme a su plan de Lealtad acumulan MultiPremios, incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. El 30% de descuento no aplica en conjunto con el beneficio de pago en CUSCA CUOTAS sin intereses. **El monto máximo de compra sujeta a descuento por cliente durante la promoción al pagar con MultiPremios es de $300.00, que equivale a un monto máximo de descuento a otorgar por cliente durante la promoción de $150.00. Aplican para esta promoción los pagos con MultiPremios de Tarjetas de Crédito y Débito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. Beneficio de descuento pagando con MultiPremios de tus Tarjetas de Crédito y Débito CUSCATLAN, no aplica para compras parciales, para que el descuento sea aplicado el producto debe ser pagado totalmente con MultiPremios. Para pagos con MultiPremios de Tarjetas de Crédito o Débito CUSCATLAN aplican condiciones del Reglamento del Programa de Lealtad MultiPremios, los cuales puedes consultar al 2212-2000 y en www.bancocuscatlan.com. Los descuentos bajo la presente promoción no aplican en compras vía telefónica o vía WhatsApp, ni para venta en línea. Descuentos no aplican en alimentos, bebidas, leche en fórmula, toallitas húmedas ni pañales. Descuentos no aplican en conjunto con otras promociones y descuentos. Descuentos aplican únicamente en productos a precio regular. Disponibilidad de productos puede variar según las existencias de cada sucursal. ***El precio del bien se dividirá hasta en un máximo de 9 CUSCA CUOTAS sin intereses y conforme al número de pagos que solicite el cliente. Estos pagos serán incluidos en el estado de cuenta mensual. Las compras en CUSCA CUOTAS no generarán intereses, siempre y cuando se cancele el saldo de contado indicado en el estado de cuenta correspondiente. El monto total de la compra es reservado del disponible del límite de crédito y liberado conforme se vayan abonando los pagos mensuales. En caso de no cancelarse el valor total del pago incluido dentro del pago mínimo, el cliente cancelará un recargo y se generará los intereses que correspondan al saldo no pagado. Consulta en los Comercios participantes los artículos que pueden ser adquiridos como compra en CUSCA CUOTAS sin intereses. Beneficio de CUSCA CUOTAS sin intereses aplica exclusivamente para Tarjetas de Crédito CUSCATLAN, incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. Promoción válida 2 y 3 de abril de 2022. El otorgamiento de descuentos bajo la presente promoción es exclusiva responsabilidad de Juguetón y Bebemundo.  30% de descuento* al instante en Juguetón y Bebemundo todas" title="30% de descuento* al instante en Juguetón y Bebemundo" tabindex="-1" style="width: 375px;" data-slick-index="2" aria-hidden="true"><a href="././promociones/jugueton-220328" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/jugueton-220328_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/jugueton.png" class="img-circle"><span>Descuento* al instante</span></p><p class="discounttitle semi">30% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN descuento* al instante Compartir Promoción válida 2 y 3 de abril de 2022 Tienda Sperry, Centro Comercial Galerías,tercer nivel frente a Gapetlandia Tienda Sperry El Salvador tienda_sperry_sv Catálogo Virtualhttps://drive.google.com/file/d/1Wwdc7f4UbYap3MHcBCiR6uG__e-cgml-/view?usp=sharing bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válido al pagar con Tarjetas de Crédito y Débito CUSCATLAN, incluyendo las Tarjetas de Crédito y Débitoemitidas en El Salvador bajo la Marca Scotiabank, las cuales son utilizadas temporalmente y seránoportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. No participan en lapromoción compras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. Aplica enproductos a precio regular. No aplica en conjunto con otras promociones o descuentos. La aplicación dedescuentos bajo la presente promoción es de exclusiva responsabilidad de Tienda Sperry. Este contenido lepermite acceder a sitios web de terceros que no están controlados por Banco Cuscatlán, S.A. al hacer clic en loshipervínculos adicionados. La seguridad de dichos sitios web no dependen ni son responsabilidad de BancoCuscatlán, S.A. Más información en términos y condiciones en bancocuscatlan.com  25% de descuento* al instante en Tienda Sperry Galerías todas" title="25% de descuento* al instante en Tienda Sperry Galerías" tabindex="-1" style="width: 375px;" data-slick-index="3" aria-hidden="true"><a href="././promociones/sperry-220330" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/sperry-220330_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Descuento* al instante</span></p><p class="discounttitle semi">25% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Belleza Naturalizer descuento* al instante Compartir bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válido al pagar con Tarjetas de Crédito y Débito CUSCATLAN, incluyendo las Tarjetas de Crédito y Débitoemitidas en El Salvador bajo la Marca Scotiabank, las cuales son utilizadas temporalmente y seránoportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. No participan en lapromoción compras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. Aplica enproductos seleccionados. La aplicación de descuentos bajo la presente promoción es de exclusivaresponsabilidad de Naturalizer.  25% de descuento* al instante en productos seleccionados en Naturalizer todas" title="25% de descuento* al instante en productos seleccionados en Naturalizer" tabindex="-1" style="width: 375px;" data-slick-index="4" aria-hidden="true"><a href="././promociones/naturalizer-220330" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/naturalizer-220330_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/naturalizersv.png" class="img-circle"><span>Descuento* al instante</span></p><p class="discounttitle semi">25% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN  puerto de la libertad Compartir Promoción válida 2 y 3 de abril de 2022.Monto máximo de descuento a ser otorgado por Tarjeta de Crédito durante la promoción de $25.00*Para poder hacer efectivo el descuento deberás reportar tu compra** bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *El monto máximo de descuento a ser otorgado por Tarjeta de Crédito durante la promoción es de $25.00, queequivale a un monto máximo de compra sujeta a descuento de $100.00. Descuento no aplica para pagos conTarjetas de Débito MultiPremios CUSCATLAN. Beneficio de descuento aplica para pagos con Tarjetas de CréditoCUSCATLAN que conforme a su plan de Lealtad acumulan MultiPremios. Aplican para esta promoción las Tarjetasde Crédito emitidas en El Salvador bajo la Marca Scotiabank, las cuales son utilizadas temporalmente y seránoportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. No participan en la promocióncompras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. **Periodo de reporte decompra del 2 al 7 de abril de 2022. Para que el Descuento sea efectivo el cliente deberá reportar su compra pormedio de la página web www.bancocuscatlan.com, debiendo detallar: el No. de DUI, fecha en la que se realizó lacompra, monto del pago, los primeros y los últimos 4 números de la Tarjeta de Crédito con la que fue realizadala compra. El descuento será reflejado en el próximo estado de cuenta o a más tardar 40 días después derealizada la compra.  25% de descuento en bares y restaurantes del Puerto de La Libertad todas" title="25% de descuento en bares y restaurantes del Puerto de La Libertad" tabindex="-1" style="width: 375px;" data-slick-index="5" aria-hidden="true"><a href="././promociones/baresyrestaurantes-220330" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/baresyrestaurantes-220330_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span> Puerto de La Libertad</span></p><p class="discounttitle semi">25% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Salud Óptica La Joya descuento* al instante  Compartir o si lo prefieres puedes comprar hasta en Promoción válida del 1 de marzo de 2022 al 28 de febrero de 2023. bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válido al pagar con Tarjetas de Crédito y Débito CUSCATLAN, incluyendo Tarjetas de Crédito y Débito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. No aplica en lentes de contacto. No aplica en accesorios. No aplica en la compra solo de lente. No aplica en la compra solo de aro. Descuento se aplica en las cuatro sucursales: Roosevelt, San Benito, Merliot y Santa Elena. Promoción de descuento no aplica en conjunto con el beneficio de Cusca Cuotas sin intereses. **El precio del bien se dividirá en pagos hasta en un máximo de 12 Cusca Cuotas sin intereses y conforme al número de Cusca Cuotas que solicite el cliente. Estos pagos serán incluidos en el estado de cuenta mensual. Las compras en Cusca Cuotas no generarán intereses, siempre y cuando se cancele el saldo de contado indicado en el estado de cuenta correspondiente. El monto total de la compra es reservado del disponible del límite de crédito y liberado conforme se vayan abonando los pagos mensuales. En caso de no cancelarse el valor total del pago incluido dentro del pago mínimo, el cliente cancelará un recargo y se generará los intereses que correspondan al saldo no pagado. Beneficio de Cusca Cuotas aplica exclusivamente para pagos con Tarjetas de Crédito CUSCATLAN, incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. No aplica en conjunto con otras promociones o descuentos. No participan en la promoción compras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. El otorgamiento del descuento es exclusiva responsabilidad de Óptica La Joya.  15% de descuento* al instante en Óptica La Joya todas" title="15% de descuento* al instante en Óptica La Joya" tabindex="-1" style="width: 375px;" data-slick-index="6" aria-hidden="true"><a href="././promociones/lajoya-220330" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/lajoya-220330_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/lajoya.png" class="img-circle"><span>Descuento* al instante </span></p><p class="discounttitle semi">15% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN canjea tus lifemiles Compartir Miami, Guayaquil, Quito, Lima, Bogotá, Ciudad de México, Dallas: entre el 31 de marzo de 2022al 30 de noviembre de 2022. Ontario (California), Washington, San Francisco, Los Ángeles:entre el 1 de mayo de 2022 al 30 de noviembre de 2022. Toronto: entre el 15 de abril de 2022 al 30 de noviembre de 2022. New York: entre el 1 de abril de 2022 al 30 de noviembre de 2022. bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Esta promoción está disponible en LifeMiles.com, Centros de Atención Avianca y Call Center de Avianca. Sideseas efectuar la redención del boleto en Centros de Atención Avianca o Call Center de Avianca aplican cargospor emisión de cada boleto de US$25 a US$80 + impuestos locales (ida y vuelta) que deberán ser cancelados almomento de realizar el canje. Trámite de canje de tiquetes del 30 de marzo al 3 de abril de 2022. ** Aplican lassiguientes fechas de vuelo para viajar ida y regreso entre San Salvador y las siguientes ciudades: Miami,Guayaquil, Bogotá, Lima, Quito, Ciudad de México y Dallas: El viaje podrá realizarse entre el 31 de marzo de 2022y el 30 de noviembre de 2022. Nueva York: El viaje podrá realizarse entre el 1 de abril de 2022 y el 30 denoviembre de 2022. Toronto: El viaje podrá realizarse entre el 15 de abril de 2022 y el 30 de noviembre de 2022.Ontario (California), Los Ángeles, Washington D.C. y San Francisco: El viaje podrá realizarse entre el 1 de mayode 2022 y el 30 de noviembre de 2022. Estadía mínima 1 día. No se permite realizar paradas en ruta (stopover)con esta promoción. Aplica para redimir un máximo de 4 boletos por cuenta LifeMiles. Las sillas son limitadas ypueden no estar disponibles en todos los vuelos y/o fechas. Está sujeto a disponibilidad de clase X. Aplicaúnicamente para vuelos operados por Aerovías del Continente Americano S.A. Avianca, Taca InternationalAirlines S.A., Avianca Costa Rica S.A., y/o Avianca-Ecuador S.A. No aplica para vuelos en código compartido conaerolíneas diferentes a las anteriormente mencionadas. Para gozar del beneficio del canje del boleto con millasde ida y vuelta en Clase Económica, el viaje debe de realizarse desde El Salvador. Promoción válida entre elorigen y los destinos especificados en este mensaje, pudiendo incluir conexiones en ruta, pudiendo redimir soloida, solo regreso, o ida y regreso. A los boletos redimidos bajo esta promoción les aplica la política de flexibilidadde Avianca. Conoce los detalles en https://www.avianca.com/sv/es/experiencia/covid-19/. No es válido acumularesta actividad con otra promoción de redención de LifeMiles o promoción de tarifas de las aerolíneasoperadoras. Se permite comprar millas del programa LifeMiles, para acceder a esta promoción. No acumulasLifeMiles viajando con estos boletos. En caso de que no sean utilizados los boletos en las fechas establecidasanteriormente, los cargos, impuestos cancelados y las millas no son reembolsables. Aplican los Términos yCondiciones del Programa LifeMiles, disponibles en LifeMiles.com. LifeMiles es una marca registrada deLifeMiles LTD. Este contenido le permite acceder a sitios web de terceros que no están controlados por BancoCuscatlán, S.A. al hacer clic en los hipervínculos adicionados. La seguridad de dichos sitios web no dependen nison responsabilidad de Banco Cuscatlán, S.A. Más información en términos y condiciones enbancocuscatlan.com Condiciones, tasas de interés, comisiones y recargos disponibles enwww.bancocuscatlan.com.  Canjea tus LifeMiles todas" title="Canjea tus LifeMiles" tabindex="-1" style="width: 375px;" data-slick-index="7" aria-hidden="true"><a href="././promociones/lifemiles-220331" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/lifemiles-220331_04.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Canjea tus LifeMiles</span></p><p class="discounttitle semi short">¡Canjea!</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN precios especiales* en paquetes  Compartir bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válidos al pagar exclusivamente con Tarjetas de Crédito CUSCATLAN incluyendo las Tarjetas de Créditoemitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y seránoportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. No participan en la promocióncompras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. Paquetes incluyen:Boleto aéreo San Salvador- Roatán – San Salvador con TAG, Traslados Aeropuerto – Hotel – Aeropuerto, 4 Días 3Noches de alojamiento en hotel a su elección, Plan de alimentación según su elección, Recepción y asistencia enla isla, Impuestos de salida de cada país, Impuestos Hoteleros. La tarifa es en base a habitación Triple porpersona. No incluye: Otras actividades o adicionales no especificadas, Desayuno el día de llegada y almuerzo eldía de salida. **El precio del bien se dividirá en pagos hasta en un máximo de 36 Cusca Cuotas sin intereses yconforme al número de Cusca Cuotas que solicite el cliente. Estos pagos serán incluidos en el estado de cuentamensual. Las compras en Cusca Cuotas no generarán intereses, siempre y cuando se cancele el saldo decontado indicado en el estado de cuenta correspondiente. El monto total de la compra es reservado deldisponible del límite de crédito y liberado conforme se vayan abonando los pagos mensuales. En caso de nocancelarse el valor total del pago incluido dentro del pago mínimo, el cliente cancelará un recargo y se generarálos intereses que correspondan al saldo no pagado. Consulta en VIP Travel Group los paquetes que pueden seradquiridos en Cusca Cuotas. Beneficio de Cusca Cuotas aplica para pagos con Tarjetas de Crédito CUSCATLAN,incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadastemporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. Los plazosdisponibles para el beneficio Cusca Cuotas pueden variar en el comercio participante, de acuerdo a lascondiciones previamente pactadas entre estos comercios y el Banco. La aplicación de precios especiales bajo lapresente promoción es de exclusiva responsabilidad de VIP Travel Group.  Precios especiales* en paquetes a Roatán con VIP Travel Group todas" title="Precios especiales* en paquetes a Roatán con VIP Travel Group" tabindex="-1" style="width: 375px;" data-slick-index="8" aria-hidden="true"><a href="././promociones/travelgroup-220314" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/travelgroup-220314_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Precios especiales* en paquetes </span></p><p class="discounttitle semi short">¡Roatan!</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Gasolinera UNO +1 multipremios Compartir ¡Solicítala ya! bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv * Con tu Tarjeta Uno Cuscatlan recibes 6% de descuento siempre en Estaciones de Servicio UNO. El monto máximo de descuentomensual a otorgar es de $25.00. Aplican condiciones del Reglamento del Programa de Lealtad Tarjetas de Marca Compartida.**Aplican condiciones de acumulación, redención y términos del Reglamento del Programa de Lealtad MultiPremios.Condiciones, tasas de interés, comisiones y recargos disponibles en www.bancocuscatlan.com.  Ahorra y llena tu tanque todas" title="6% de descuento" tabindex="-1" style="width: 375px;" data-slick-index="9" aria-hidden="true"><a href="././promociones/uno-220308" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/uno-220308_01.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/gasuno.png" class="img-circle"><span>+1 MultiPremios</span></p><p class="discounttitle semi">6% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Súper Selectos los martes en frutas y verduras Compartir Promoción válida del 4 de enero al 27 de diciembre de 2022 bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válido al pagar con Tarjetas de Crédito CUSCATLAN. Aplican para esta promoción las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. Descuento aplica únicamente los días martes comprendidos entre el 4 de enero al 27 de diciembre de 2022. Descuento aplica durante todo el día. El descuento aplica en todas las frutas y verduras, a precio regular o en oferta. Aplica para pago con Tarjetas de Crédito CUSCATLAN emitidas en El Salvador. Las Tarjetas de Crédito Selectos CUSCATLAN no participan de esta promoción, recibirán únicamente el beneficio del 7% de descuento que le corresponde conforme a los términos del Programa de lealtad del producto. El otorgamiento de tarifas especiales y beneficios bajo la presente promoción es de exclusiva responsabilidad de Súper Selectos. Descuento aplica en superselectos.com y Super Selectos App.  20% de descuento* en Súper Selectos todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="10" aria-hidden="true"><a href="././promociones/selectosfrutas-220104" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/selectosfrutas-220104_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/superselectos.png" class="img-circle"><span>Los martes en frutas y verduras</span></p><p class="discounttitle semi">20% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN gana con tus tarjetas cuscatlan COMPRA TODOcon tus Tarjetas Débito CUSCATLAN Por cada $5 en compras participas en los sorteos,tú puedes ser uno de los 50 ganadores de $250* Promoción válida del 17 de enero al 31 de diciembre de 2022 bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv Promoción válida del 17 de enero al 31 de diciembre de 2022. *Participan clientes que durante el período de vigencia de lapromoción: a) adquieran una nueva tarjeta de débito CUSCA en cualquier Agencia de Banco Cuscatlán, S.A.; b) Realicen comprasde $5 con cualquier Tarjeta de Débito CUSCATLAN, incluyendo las Tarjetas de Débito emitidas en El Salvador bajo la marcaScotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Débito de la marcaCUSCATLAN. Por adquirir una Tarjeta de Débito CUSCA se asignarán dos números electrónicos y por cada $5 en compras conTarjetas de Débito CUSCATLAN, se asignará un número electrónico, para participar mensualmente en los sorteos de $250.00.Habrá 12 sorteos y 50 ganadores de $250.00. Se otorgará un premio de $250 por cada semana de vigencia de la promoción.Promoción válida del 17 de enero al 31 de diciembre de 2022. Fecha de los sorteos: 10 de febrero, 10 de marzo, 14 de abril, 12de mayo ,9 de junio, 14 de julio, 11 de agosto, 8 de septiembre, 13 de octubre, 10 de noviembre, 8 de diciembre de 2022 y el día12 de enero de 2023. No participan en esta promoción tarjetas de débito que pertenezcan a segmentos de Empresas. Noparticipan Empleados de Banco Cuscatlán de El Salvador, S.A. ni de sus filiales, ni personal subcontratado. Tampoco participanempleados de Tarjetas Cuscatlán de El Salvador, S.A. de C.V.; ni de Seguros e  Inversiones, S.A., ni de su subsidiaria SISA, VIDA,S.A., Seguros de Personas. Consulta el Reglamento de la promoción en www.bancoscuscatlan.com.  COMPRA TODO con tus Tarjetas Débito CUSCATLAN todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="11" aria-hidden="true"><a href="././promociones/gana250-220202" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/gana250-220202_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Gana con tus Tarjetas CUSCATLAN</span></p><p class="discounttitle semi">GANA $250</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Salud Farmacias San Nicolás pagos sin intereses* Compra hasta en 9 Pagos Sin Intereses* En Farmacias San Nicolás ¡HOY mi salud es primero! Compra hasta en 9 Pagos Sin Intereses* Al pagar con tus Tarjetas de Crédito CUSCATLAN O si lo prefieres puedes canjear los MultiPremios de tus Tarjetas de Crédito y Débito MultiPremios CUSCATLAN** Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 Siguenos como: @bancocuscatlan.com.sv Ver términos de promoción SISA.com Gobierno Corporativo Preguntas Frecuentes Oportunidades de Empleo Términos y Condiciones todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="12" aria-hidden="true"><a href="././promociones/sannicolas-210722" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/sannicolas-210722_06.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/sannicolas.png" class="img-circle"><span>Pagos Sin Intereses*</span></p><p class="discounttitle semi short">Cuotas</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Uber Eats tarjeta de regalo uber.*  zz mprar tu Tarjeta de Regalo UBER para regalar a papá.* ¡HOY Compro el regalo para papá! Gana y redime LifeMiles al comprar tu Tarjeta de Regalo UBER para regalar a papá.* Ingresa LifeMiles.com y compra tu Tarjeta de Regalo Uber con tu Tarjeta de Crédito LifeMiles CUSCATLAN o usa las millas acumuladas con tu tarjeta de crédito para pagar, siguiendo estos pasos: Ingresa a LifeMiles.com y haz clic en la cejilla “Restaurantes” Elige el monto de tu Tarjeta de Regalo Uber y completa los pasos de la compra Recibe tu código e ingresalo a la app de Uber o Uber Eats asegúrate de tener la última versión instalada Una vez recibas tu código por correo electrónico o lo encuentres en la sección de Ver Tarjetas de Regalo Uber (24 horas después de tu compra), ingresa a la app de Uber, asegúrate de tener la última versión instalada. Selecciona la opción Tarjeta de Regalo en el menú de pago ingresa tu código. Además ¡Gana hasta 3 LifeMiles por US$1!** Al comprar tu Tarjeta de Regalo Uber ganas 2 LifeMiles por US$1 y si pagas con tu Tarjeta de Crédito LifeMiles ganas adicional 1 LifeMile por US$1. Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 Siguenos como: @bancocuscatlan.com.sv *Consulta términos y condiciones de esta promoción en LifeMiles.com. Aplican términos y condiciones del programa LifeMiles. Consúltalos en LifeMiles.com. **Las Tarjetas de Crédito LifeMiles CUSCATLAN acumularán un máximo de 3 LifeMiles por cada dólar en compras con base a esta promoción, cantidad que ya incluye 1 LifeMile que regularmente acumulan por cada dólar en compras de conformidad al Programa de Lealtad Tarjetas de Marca Compartida. LifeMiles es una marca registrada de LifeMiles Ltd. todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="13" aria-hidden="true"><a href="././promociones/ubereats-210614" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/ubereats-210614_02.jpg?v=234);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/ubereats.png" class="img-circle"><span>Tarjeta de Regalo UBER.* </span></p><p class="discounttitle semi short">LifeMiles</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-current slick-active" data-products="1" data-name=" Compras Banco CUSCATLAN ¡sé real, sé cuscatlan! Viajes, Hospedajes  ento ¡siempre! - ¡Sé Real, Sé CUSCATLAN! ¡Sé Real, Sé CUSCATLAN! 20% De descuento ¡siempre! En habitaciones de fin de semana*, tratamientos de Spa InterContinental** y Restaurantes de Hotel Real InterContinental*** Con tu Tarjeta de Crédito LifeMiles Real CUSCATLAN Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 Siguenos como: @bancocuscatlan.com.sv Descuentos aplican únicamente al pagar con Tarjeta de Crédito LifeMiles Real CUSCATLAN. En caso de pagar en efectivo u otra forma de pago, se cobrará las tarifas regulares de cada servicio. No aplica en conjunto con otras promociones. *20% de descuento sobre la tarifa reservada por el cliente en habitación en _n de semana, lo cual incluye viernes, sábado y domingo. Aplica para cualquiera de los ocho hoteles de RHR. Se otorgará descuento sobre la tarifa reservada por el cliente. Solo incluye el alojamiento. **20% de descuento en cualquier tratamiento del Spa InterContinental, aplica de lunes a domingo, sujeto a disponibilidad para día y hora solicitada. ***20% de descuento en los alimentos en todos los restaurantes del hotel InterContinental aplica para almuerzo y cena en Faisca do Brasil, Picasso y Nau. Descuento no aplica en bebidas ni propina. todas" title="" tabindex="0" style="width: 375px;" data-slick-index="14" aria-hidden="false"><a href="././promociones/real-210611" tabindex="0"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/real-210611_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>¡Sé Real, Sé CUSCATLAN!</span></p><p class="discounttitle semi">20% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN ¡hoy viajo gracias a mis compras! Viajes, Hospedajes  ¡HOY viajo gracias a mis compras! Solicita tu Tarjeta de Débito LifeMiles CUSCATLAN* Y acumula** por cada $1 en consumo local por cada $2 en consumo internacional Y recuerda que también disfrutas de grandes beneficios: Redime tus LifeMiles por boletos aéreos con Avianca, aerolíneas miembro de Star Alliance, Iberia, Aeromexico y GOL.*** Paga tus noches de hotel con LifeMiles en más de 500,000 hoteles alrededor del mundo.*** Compra en Amazon.com LifeMiles.*** Conoce Promociones AQUÍ Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 Siguenos como: @bancocuscatlan.com.sv *Para aplicar a una Tarjeta de Débito LifeMiles CUSCATLAN, el cliente deberá tener cuenta de ahorro o corriente en Banco CUSCATLAN e ingresos iguales o mayores a USD$1,000 mensuales. **Aplican condiciones del Reglamento del Programa de Lealtad Tarjetas de Marca Compartida, las cuales puedes consultar en www.bancocuscatlan.com. Es responsabilidad del Socio consultar con el Banco las condiciones de acumulación de millas. Las condiciones y beneficios de las tarjetas son fijados por el banco. Las millas acumuladas por consumo con tarjetas de marca compartida Avianca LifeMiles no califican para obtener o mantener el estatus elite LifeMiles. Los servicios financieros y otros beneficios de las tarjetas son responsabilidad del Banco. ***Cada producto de redención está sujeto a términos y condiciones disponibles en www.LifeMiles.com. Las Millas están sujetas a los Términos y Condiciones del Programa LifeMiles, disponibles en LifeMiles.com. LifeMiles es una marca registrada de LifeMiles LTD. todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="15" aria-hidden="true"><a href="././promociones/lifemiles-210601" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/lifemiles-220224_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>¡HOY viajo gracias a mis compras!</span></p><p class="discounttitle semi">Viaja Ahora</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN hasta 24 pagos sin intereses* en infrasal Salud Hasta 24 Pagos sin Intereses* en INFRASAL Al pagar con tus Tarjetas de Crédito CUSCATLAN Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 @bancocuscatlan.com.sv *El precio del bien se dividirá hasta en un máximo de 24 pagos sin intereses y conforme al número de pagos que solicite el cliente. Estos pagos serán incluidos en el estado de cuenta mensual. Las compras a pagos no generarán intereses, siempre y cuando se cancele el saldo de contado indicado en el estado de cuenta correspondiente. El monto total de la compra es reservado del disponible del límite de crédito y liberado conforme se vayan abonando los pagos mensuales. En caso de no cancelarse el valor total del pago incluido dentro del pago mínimo, el cliente cancelará un recargo y se generará los intereses que correspondan al saldo no pagado. Consulta en Infrasal los artículos que pueden ser adquiridos como compra en pagos sin intereses. Beneficio de pago sin intereses aplica para Tarjetas de Crédito CUSCATLAN, incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. Beneficio válido mientras se mantenga el servicio de adquirencia con Infrasal todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="16" aria-hidden="true"><a href="././promociones/infrasal-210504" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/infrasal-210504_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Hasta 24 Pagos sin Intereses* en INFRASAL</span></p><p class="discounttitle semi short">Cuotas</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide" data-products="1" data-name=" Compras Banco CUSCATLAN realiza tus pagos de préstamos más cerca de ti Compras Realiza tus Pagos de Préstamosmás cerca de tiPaga tus cuotas de Créditos en todas las sucursales dePuntoxpressDisponibles en supermercados, farmacias, ferreterías, tiendas y cientos de puntos a nivel nacional.bancocuscatlan.comLlámanos al 2212-2000@bancocuscatlan.com.svPuntoxpress ha sido contratado por BANCO CUSCATLÁN, S.A, para actuar como Administrador de Corresponsales Financieros. BANCO CUSCATLÁN, S.A, es responsable frente a los clientes por las operaciones y servicios prestados por medio de los Corresponsales Financieros. Las operaciones de BANCO CUSCATLÁN, S.A. no generan comisión por servicio y los pagos deben efectuarse en efectivo. Puntoxpress y el Corresponsal Financiero no están autorizados para realizar operaciones y prestar servicios financieros por cuenta propia. Para abono a Préstamos de BANCO CUSCATLÁN, S.A., aplica un máximo diario de 7 transacciones por valor de hasta $571.00 cada una. El acumulado de pagos mensuales por cliente no podrá exceder de US$30,000.00. Horario de atención para abono a préstamos es hasta las 8:00 p.m. todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="17" aria-hidden="true"><a href="././promociones/prestamos-210201" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/prestamos-210201_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Realiza tus Pagos de Préstamos más cerca de ti</span></p><p class="discounttitle semi short">Pagos</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN san bartolomé perulapía Compartir Apoya los sueño de nuestros emprendedores en el MERCADO ARTESANAL DE EMPRENDEDORES/ASDE SAN BARTOLOMÉ PERULAPÍA Monto máximo de descuento a ser otorgado porTarjeta de Crédito y Débito durante la promoción de $25.00* Para poder hacer efectivo el descuentodeberás reportar tu compra** bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *El monto máximo de descuento a ser otorgado por Tarjeta de Crédito o Débito durante la promoción es de $25.00, que equivale a un monto máximo de compra sujeta a descuento de $100.00. Descuento válido exclusivamente por compras en emprendimientos participantes en Mercado Artesanal De Emprendedores De San Bartolomé Perulapía, efectuadas con Tarjetas de Crédito o Débito CUSCATLAN durante el evento en Centro Comercial SOHO Las Cascadas. Aplican para esta promoción las Tarjetas de Crédito y Débito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. El descuento será reflejado en el próximo estado de cuenta o a más tardar 40 días después de realizada la compra. No participan en la promoción compras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. **Periodo de reporte de compra entre el 02 y 07 de abril de 2022. Para que el descuento sea efectivo el cliente deberá reportar su compra por medio de la página web bancocuscatlan.com, los primeros y los últimos 4 números de la Tarjeta de Crédito o Débito con la que fue realizada la compra.  25% de descuento en mercado artesanal de emprendedores/as de San Bartolomé Perulapía todas" title="25% de descuento en mercado artesanal de emprendedores/as de San Bartolomé Perulapía" tabindex="-1" style="width: 375px;" data-slick-index="18" aria-hidden="true"><a href="././promociones/emprendedores-220401" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/emprendedores-220401_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>San Bartolomé Perulapía</span></p><p class="discounttitle semi">25% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN ¡ahórrate hasta la gasolina!  Compartir bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv Consulta de tasas, comisiones y recargos en agencias y periódicos de mayor circulación nacional, para mayor informacióndel producto al 2212-2000 o ingresando a www.bancocuscatlan.com. Tasas de interés calculadas de acuerdo al plazo y almonto del producto solicitado. *Participan clientes que, en el período comprendido del 1 de abril al 31 de mayo del 2022,abran una cuenta de ahorro, corriente, cuenta futuro o cuenta remesera por montos de $300 dólares de los Estados Unidoso realicen depósitos o incrementos en efectivo en la que ya tienen por una cantidad similar, a quienes se les otorgará uncupón físico por cada $300.00 dólares depositados, el cual deberá completar con sus datos personales y depositarlo en lastómbolas que estarán ubicadas en las agencias de Banco CUSCATLAN y así participar en el sorteo de 10 motocicletas marcaYadea. El cupón es intransferible, es decir, solo participa y puede resultar ganador el cliente titular de la cuenta que efectúael depósito por un monto participante. Habrá 10 ganadores, cada uno será acreedor a una motocicleta eléctrica de altagama marca YADEA, son 7 motos modelo Z-6 de 3,000 WP y 3 motos modelo M-6 de 1,500 WP. El premio incluye costos delImpuesto a la Primera Matrícula, Tarjeta de Circulación y Placas, así como el monto del Impuesto sobre la Renta a cuyaretención está sujeto el premio. Un cliente no puede salir favorecido más de una vez durante esta promoción. Fecha desorteo: 8 de junio del 2022. Participan únicamente personas naturales. Aplica únicamente para depósitos nuevos en efectivoy sujeto a que dichos fondos permanezcan al menos 30 días o hasta la fecha del sorteo en la cuenta del cliente. No aplicapara transferencias de fondos entre cuentas del mismo cliente. No participan los depósitos por pago de planillas. No aplicancuentas de ahorro o corriente que pertenezcan a segmentos de Empresas. No participan empleados de Banco Cuscatlán deEl Salvador, S. A., ni de sus filiales, ni personal subcontratado. Tampoco participan empleados de Banco Cuscatlán de ElSalvador, S.A., ni de sus filiales, ni personal subcontratado. Tampoco participan empleados de Tarjetas Cuscatlán de ElSalvador, S.A. de C.V.; ni de Seguros e Inversiones, S.A., ni de su subsidiaria SISA, VIDA, S.A., Seguro de Personas. Lasimágenes utilizadas en este publicidad son de carácter ilustrativo, el color, especificaciones, y/o características adicionalesa las descritas en este apartado pueden variar según disponibilidad.  ¡Ahórrate hasta la gasolina!  todas" title="¡Ahórrate hasta la gasolina! " tabindex="-1" style="width: 375px;" data-slick-index="19" aria-hidden="true"><a href="././promociones/ahorraygana-220401" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/ahorraygana-220401_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>¡Ahórrate hasta la gasolina! </span></p><p class="discounttitle semi"><small> Ahorra y Gana</small></p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo  hidden-xs hidden-sm slick-slide slick-cloned" data-products="1" data-name=" Compras Jugueton descuento* al instante Compartir El monto máximo de compra sujeta a descuentopor cliente durante la promoción es de $300.00 bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *El monto máximo de compra sujeta a descuento por cliente durante la promoción es de $300.00, que equivale a un monto máximo de descuento a otorgar por cliente durante la promoción de $90.00. Beneficio de descuento aplica para pagos con Tarjetas de Crédito CUSCATLAN que conforme a su plan de Lealtad acumulan MultiPremios, incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. El 30% de descuento no aplica en conjunto con el beneficio de pago en CUSCA CUOTAS sin intereses. **El monto máximo de compra sujeta a descuento por cliente durante la promoción al pagar con MultiPremios es de $300.00, que equivale a un monto máximo de descuento a otorgar por cliente durante la promoción de $150.00. Aplican para esta promoción los pagos con MultiPremios de Tarjetas de Crédito y Débito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. Beneficio de descuento pagando con MultiPremios de tus Tarjetas de Crédito y Débito CUSCATLAN, no aplica para compras parciales, para que el descuento sea aplicado el producto debe ser pagado totalmente con MultiPremios. Para pagos con MultiPremios de Tarjetas de Crédito o Débito CUSCATLAN aplican condiciones del Reglamento del Programa de Lealtad MultiPremios, los cuales puedes consultar al 2212-2000 y en www.bancocuscatlan.com. Los descuentos bajo la presente promoción no aplican en compras vía telefónica o vía WhatsApp, ni para venta en línea. Descuentos no aplican en alimentos, bebidas, leche en fórmula, toallitas húmedas ni pañales. Descuentos no aplican en conjunto con otras promociones y descuentos. Descuentos aplican únicamente en productos a precio regular. Disponibilidad de productos puede variar según las existencias de cada sucursal. ***El precio del bien se dividirá hasta en un máximo de 9 CUSCA CUOTAS sin intereses y conforme al número de pagos que solicite el cliente. Estos pagos serán incluidos en el estado de cuenta mensual. Las compras en CUSCA CUOTAS no generarán intereses, siempre y cuando se cancele el saldo de contado indicado en el estado de cuenta correspondiente. El monto total de la compra es reservado del disponible del límite de crédito y liberado conforme se vayan abonando los pagos mensuales. En caso de no cancelarse el valor total del pago incluido dentro del pago mínimo, el cliente cancelará un recargo y se generará los intereses que correspondan al saldo no pagado. Consulta en los Comercios participantes los artículos que pueden ser adquiridos como compra en CUSCA CUOTAS sin intereses. Beneficio de CUSCA CUOTAS sin intereses aplica exclusivamente para Tarjetas de Crédito CUSCATLAN, incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. Promoción válida 2 y 3 de abril de 2022. El otorgamiento de descuentos bajo la presente promoción es exclusiva responsabilidad de Juguetón y Bebemundo.  30% de descuento* al instante en Juguetón y Bebemundo todas" title="30% de descuento* al instante en Juguetón y Bebemundo" tabindex="-1" style="width: 375px;" data-slick-index="20" aria-hidden="true"><a href="././promociones/jugueton-220328" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/jugueton-220328_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/jugueton.png" class="img-circle"><span>Descuento* al instante</span></p><p class="discounttitle semi">30% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN descuento* al instante Compartir Promoción válida 2 y 3 de abril de 2022 Tienda Sperry, Centro Comercial Galerías,tercer nivel frente a Gapetlandia Tienda Sperry El Salvador tienda_sperry_sv Catálogo Virtualhttps://drive.google.com/file/d/1Wwdc7f4UbYap3MHcBCiR6uG__e-cgml-/view?usp=sharing bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válido al pagar con Tarjetas de Crédito y Débito CUSCATLAN, incluyendo las Tarjetas de Crédito y Débitoemitidas en El Salvador bajo la Marca Scotiabank, las cuales son utilizadas temporalmente y seránoportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. No participan en lapromoción compras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. Aplica enproductos a precio regular. No aplica en conjunto con otras promociones o descuentos. La aplicación dedescuentos bajo la presente promoción es de exclusiva responsabilidad de Tienda Sperry. Este contenido lepermite acceder a sitios web de terceros que no están controlados por Banco Cuscatlán, S.A. al hacer clic en loshipervínculos adicionados. La seguridad de dichos sitios web no dependen ni son responsabilidad de BancoCuscatlán, S.A. Más información en términos y condiciones en bancocuscatlan.com  25% de descuento* al instante en Tienda Sperry Galerías todas" title="25% de descuento* al instante en Tienda Sperry Galerías" tabindex="-1" style="width: 375px;" data-slick-index="21" aria-hidden="true"><a href="././promociones/sperry-220330" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/sperry-220330_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Descuento* al instante</span></p><p class="discounttitle semi">25% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Belleza Naturalizer descuento* al instante Compartir bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válido al pagar con Tarjetas de Crédito y Débito CUSCATLAN, incluyendo las Tarjetas de Crédito y Débitoemitidas en El Salvador bajo la Marca Scotiabank, las cuales son utilizadas temporalmente y seránoportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. No participan en lapromoción compras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. Aplica enproductos seleccionados. La aplicación de descuentos bajo la presente promoción es de exclusivaresponsabilidad de Naturalizer.  25% de descuento* al instante en productos seleccionados en Naturalizer todas" title="25% de descuento* al instante en productos seleccionados en Naturalizer" tabindex="-1" style="width: 375px;" data-slick-index="22" aria-hidden="true"><a href="././promociones/naturalizer-220330" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/naturalizer-220330_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/naturalizersv.png" class="img-circle"><span>Descuento* al instante</span></p><p class="discounttitle semi">25% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN  puerto de la libertad Compartir Promoción válida 2 y 3 de abril de 2022.Monto máximo de descuento a ser otorgado por Tarjeta de Crédito durante la promoción de $25.00*Para poder hacer efectivo el descuento deberás reportar tu compra** bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *El monto máximo de descuento a ser otorgado por Tarjeta de Crédito durante la promoción es de $25.00, queequivale a un monto máximo de compra sujeta a descuento de $100.00. Descuento no aplica para pagos conTarjetas de Débito MultiPremios CUSCATLAN. Beneficio de descuento aplica para pagos con Tarjetas de CréditoCUSCATLAN que conforme a su plan de Lealtad acumulan MultiPremios. Aplican para esta promoción las Tarjetasde Crédito emitidas en El Salvador bajo la Marca Scotiabank, las cuales son utilizadas temporalmente y seránoportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. No participan en la promocióncompras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. **Periodo de reporte decompra del 2 al 7 de abril de 2022. Para que el Descuento sea efectivo el cliente deberá reportar su compra pormedio de la página web www.bancocuscatlan.com, debiendo detallar: el No. de DUI, fecha en la que se realizó lacompra, monto del pago, los primeros y los últimos 4 números de la Tarjeta de Crédito con la que fue realizadala compra. El descuento será reflejado en el próximo estado de cuenta o a más tardar 40 días después derealizada la compra.  25% de descuento en bares y restaurantes del Puerto de La Libertad todas" title="25% de descuento en bares y restaurantes del Puerto de La Libertad" tabindex="-1" style="width: 375px;" data-slick-index="23" aria-hidden="true"><a href="././promociones/baresyrestaurantes-220330" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/baresyrestaurantes-220330_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span> Puerto de La Libertad</span></p><p class="discounttitle semi">25% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Salud Óptica La Joya descuento* al instante  Compartir o si lo prefieres puedes comprar hasta en Promoción válida del 1 de marzo de 2022 al 28 de febrero de 2023. bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válido al pagar con Tarjetas de Crédito y Débito CUSCATLAN, incluyendo Tarjetas de Crédito y Débito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito o Débito de la marca CUSCATLAN. No aplica en lentes de contacto. No aplica en accesorios. No aplica en la compra solo de lente. No aplica en la compra solo de aro. Descuento se aplica en las cuatro sucursales: Roosevelt, San Benito, Merliot y Santa Elena. Promoción de descuento no aplica en conjunto con el beneficio de Cusca Cuotas sin intereses. **El precio del bien se dividirá en pagos hasta en un máximo de 12 Cusca Cuotas sin intereses y conforme al número de Cusca Cuotas que solicite el cliente. Estos pagos serán incluidos en el estado de cuenta mensual. Las compras en Cusca Cuotas no generarán intereses, siempre y cuando se cancele el saldo de contado indicado en el estado de cuenta correspondiente. El monto total de la compra es reservado del disponible del límite de crédito y liberado conforme se vayan abonando los pagos mensuales. En caso de no cancelarse el valor total del pago incluido dentro del pago mínimo, el cliente cancelará un recargo y se generará los intereses que correspondan al saldo no pagado. Beneficio de Cusca Cuotas aplica exclusivamente para pagos con Tarjetas de Crédito CUSCATLAN, incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. No aplica en conjunto con otras promociones o descuentos. No participan en la promoción compras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. El otorgamiento del descuento es exclusiva responsabilidad de Óptica La Joya.  15% de descuento* al instante en Óptica La Joya todas" title="15% de descuento* al instante en Óptica La Joya" tabindex="-1" style="width: 375px;" data-slick-index="24" aria-hidden="true"><a href="././promociones/lajoya-220330" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/lajoya-220330_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/lajoya.png" class="img-circle"><span>Descuento* al instante </span></p><p class="discounttitle semi">15% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN canjea tus lifemiles Compartir Miami, Guayaquil, Quito, Lima, Bogotá, Ciudad de México, Dallas: entre el 31 de marzo de 2022al 30 de noviembre de 2022. Ontario (California), Washington, San Francisco, Los Ángeles:entre el 1 de mayo de 2022 al 30 de noviembre de 2022. Toronto: entre el 15 de abril de 2022 al 30 de noviembre de 2022. New York: entre el 1 de abril de 2022 al 30 de noviembre de 2022. bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Esta promoción está disponible en LifeMiles.com, Centros de Atención Avianca y Call Center de Avianca. Sideseas efectuar la redención del boleto en Centros de Atención Avianca o Call Center de Avianca aplican cargospor emisión de cada boleto de US$25 a US$80 + impuestos locales (ida y vuelta) que deberán ser cancelados almomento de realizar el canje. Trámite de canje de tiquetes del 30 de marzo al 3 de abril de 2022. ** Aplican lassiguientes fechas de vuelo para viajar ida y regreso entre San Salvador y las siguientes ciudades: Miami,Guayaquil, Bogotá, Lima, Quito, Ciudad de México y Dallas: El viaje podrá realizarse entre el 31 de marzo de 2022y el 30 de noviembre de 2022. Nueva York: El viaje podrá realizarse entre el 1 de abril de 2022 y el 30 denoviembre de 2022. Toronto: El viaje podrá realizarse entre el 15 de abril de 2022 y el 30 de noviembre de 2022.Ontario (California), Los Ángeles, Washington D.C. y San Francisco: El viaje podrá realizarse entre el 1 de mayode 2022 y el 30 de noviembre de 2022. Estadía mínima 1 día. No se permite realizar paradas en ruta (stopover)con esta promoción. Aplica para redimir un máximo de 4 boletos por cuenta LifeMiles. Las sillas son limitadas ypueden no estar disponibles en todos los vuelos y/o fechas. Está sujeto a disponibilidad de clase X. Aplicaúnicamente para vuelos operados por Aerovías del Continente Americano S.A. Avianca, Taca InternationalAirlines S.A., Avianca Costa Rica S.A., y/o Avianca-Ecuador S.A. No aplica para vuelos en código compartido conaerolíneas diferentes a las anteriormente mencionadas. Para gozar del beneficio del canje del boleto con millasde ida y vuelta en Clase Económica, el viaje debe de realizarse desde El Salvador. Promoción válida entre elorigen y los destinos especificados en este mensaje, pudiendo incluir conexiones en ruta, pudiendo redimir soloida, solo regreso, o ida y regreso. A los boletos redimidos bajo esta promoción les aplica la política de flexibilidadde Avianca. Conoce los detalles en https://www.avianca.com/sv/es/experiencia/covid-19/. No es válido acumularesta actividad con otra promoción de redención de LifeMiles o promoción de tarifas de las aerolíneasoperadoras. Se permite comprar millas del programa LifeMiles, para acceder a esta promoción. No acumulasLifeMiles viajando con estos boletos. En caso de que no sean utilizados los boletos en las fechas establecidasanteriormente, los cargos, impuestos cancelados y las millas no son reembolsables. Aplican los Términos yCondiciones del Programa LifeMiles, disponibles en LifeMiles.com. LifeMiles es una marca registrada deLifeMiles LTD. Este contenido le permite acceder a sitios web de terceros que no están controlados por BancoCuscatlán, S.A. al hacer clic en los hipervínculos adicionados. La seguridad de dichos sitios web no dependen nison responsabilidad de Banco Cuscatlán, S.A. Más información en términos y condiciones enbancocuscatlan.com Condiciones, tasas de interés, comisiones y recargos disponibles enwww.bancocuscatlan.com.  Canjea tus LifeMiles todas" title="Canjea tus LifeMiles" tabindex="-1" style="width: 375px;" data-slick-index="25" aria-hidden="true"><a href="././promociones/lifemiles-220331" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/lifemiles-220331_04.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Canjea tus LifeMiles</span></p><p class="discounttitle semi short">¡Canjea!</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN precios especiales* en paquetes  Compartir bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válidos al pagar exclusivamente con Tarjetas de Crédito CUSCATLAN incluyendo las Tarjetas de Créditoemitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y seránoportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. No participan en la promocióncompras realizadas con Tarjetas Corporativas, ni Empresariales de Banco CUSCATLAN. Paquetes incluyen:Boleto aéreo San Salvador- Roatán – San Salvador con TAG, Traslados Aeropuerto – Hotel – Aeropuerto, 4 Días 3Noches de alojamiento en hotel a su elección, Plan de alimentación según su elección, Recepción y asistencia enla isla, Impuestos de salida de cada país, Impuestos Hoteleros. La tarifa es en base a habitación Triple porpersona. No incluye: Otras actividades o adicionales no especificadas, Desayuno el día de llegada y almuerzo eldía de salida. **El precio del bien se dividirá en pagos hasta en un máximo de 36 Cusca Cuotas sin intereses yconforme al número de Cusca Cuotas que solicite el cliente. Estos pagos serán incluidos en el estado de cuentamensual. Las compras en Cusca Cuotas no generarán intereses, siempre y cuando se cancele el saldo decontado indicado en el estado de cuenta correspondiente. El monto total de la compra es reservado deldisponible del límite de crédito y liberado conforme se vayan abonando los pagos mensuales. En caso de nocancelarse el valor total del pago incluido dentro del pago mínimo, el cliente cancelará un recargo y se generarálos intereses que correspondan al saldo no pagado. Consulta en VIP Travel Group los paquetes que pueden seradquiridos en Cusca Cuotas. Beneficio de Cusca Cuotas aplica para pagos con Tarjetas de Crédito CUSCATLAN,incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadastemporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. Los plazosdisponibles para el beneficio Cusca Cuotas pueden variar en el comercio participante, de acuerdo a lascondiciones previamente pactadas entre estos comercios y el Banco. La aplicación de precios especiales bajo lapresente promoción es de exclusiva responsabilidad de VIP Travel Group.  Precios especiales* en paquetes a Roatán con VIP Travel Group todas" title="Precios especiales* en paquetes a Roatán con VIP Travel Group" tabindex="-1" style="width: 375px;" data-slick-index="26" aria-hidden="true"><a href="././promociones/travelgroup-220314" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/travelgroup-220314_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Precios especiales* en paquetes </span></p><p class="discounttitle semi short">¡Roatan!</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Gasolinera UNO +1 multipremios Compartir ¡Solicítala ya! bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv * Con tu Tarjeta Uno Cuscatlan recibes 6% de descuento siempre en Estaciones de Servicio UNO. El monto máximo de descuentomensual a otorgar es de $25.00. Aplican condiciones del Reglamento del Programa de Lealtad Tarjetas de Marca Compartida.**Aplican condiciones de acumulación, redención y términos del Reglamento del Programa de Lealtad MultiPremios.Condiciones, tasas de interés, comisiones y recargos disponibles en www.bancocuscatlan.com.  Ahorra y llena tu tanque todas" title="6% de descuento" tabindex="-1" style="width: 375px;" data-slick-index="27" aria-hidden="true"><a href="././promociones/uno-220308" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/uno-220308_01.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/gasuno.png" class="img-circle"><span>+1 MultiPremios</span></p><p class="discounttitle semi">6% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Súper Selectos los martes en frutas y verduras Compartir Promoción válida del 4 de enero al 27 de diciembre de 2022 bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv *Válido al pagar con Tarjetas de Crédito CUSCATLAN. Aplican para esta promoción las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. Descuento aplica únicamente los días martes comprendidos entre el 4 de enero al 27 de diciembre de 2022. Descuento aplica durante todo el día. El descuento aplica en todas las frutas y verduras, a precio regular o en oferta. Aplica para pago con Tarjetas de Crédito CUSCATLAN emitidas en El Salvador. Las Tarjetas de Crédito Selectos CUSCATLAN no participan de esta promoción, recibirán únicamente el beneficio del 7% de descuento que le corresponde conforme a los términos del Programa de lealtad del producto. El otorgamiento de tarifas especiales y beneficios bajo la presente promoción es de exclusiva responsabilidad de Súper Selectos. Descuento aplica en superselectos.com y Super Selectos App.  20% de descuento* en Súper Selectos todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="28" aria-hidden="true"><a href="././promociones/selectosfrutas-220104" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/selectosfrutas-220104_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/superselectos.png" class="img-circle"><span>Los martes en frutas y verduras</span></p><p class="discounttitle semi">20% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN gana con tus tarjetas cuscatlan COMPRA TODOcon tus Tarjetas Débito CUSCATLAN Por cada $5 en compras participas en los sorteos,tú puedes ser uno de los 50 ganadores de $250* Promoción válida del 17 de enero al 31 de diciembre de 2022 bancocuscatlan.com  Llámanos al 2212-2000 Siguenos como:@bancocuscatlan.com.sv Promoción válida del 17 de enero al 31 de diciembre de 2022. *Participan clientes que durante el período de vigencia de lapromoción: a) adquieran una nueva tarjeta de débito CUSCA en cualquier Agencia de Banco Cuscatlán, S.A.; b) Realicen comprasde $5 con cualquier Tarjeta de Débito CUSCATLAN, incluyendo las Tarjetas de Débito emitidas en El Salvador bajo la marcaScotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Débito de la marcaCUSCATLAN. Por adquirir una Tarjeta de Débito CUSCA se asignarán dos números electrónicos y por cada $5 en compras conTarjetas de Débito CUSCATLAN, se asignará un número electrónico, para participar mensualmente en los sorteos de $250.00.Habrá 12 sorteos y 50 ganadores de $250.00. Se otorgará un premio de $250 por cada semana de vigencia de la promoción.Promoción válida del 17 de enero al 31 de diciembre de 2022. Fecha de los sorteos: 10 de febrero, 10 de marzo, 14 de abril, 12de mayo ,9 de junio, 14 de julio, 11 de agosto, 8 de septiembre, 13 de octubre, 10 de noviembre, 8 de diciembre de 2022 y el día12 de enero de 2023. No participan en esta promoción tarjetas de débito que pertenezcan a segmentos de Empresas. Noparticipan Empleados de Banco Cuscatlán de El Salvador, S.A. ni de sus filiales, ni personal subcontratado. Tampoco participanempleados de Tarjetas Cuscatlán de El Salvador, S.A. de C.V.; ni de Seguros e  Inversiones, S.A., ni de su subsidiaria SISA, VIDA,S.A., Seguros de Personas. Consulta el Reglamento de la promoción en www.bancoscuscatlan.com.  COMPRA TODO con tus Tarjetas Débito CUSCATLAN todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="29" aria-hidden="true"><a href="././promociones/gana250-220202" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/gana250-220202_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Gana con tus Tarjetas CUSCATLAN</span></p><p class="discounttitle semi">GANA $250</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Salud Farmacias San Nicolás pagos sin intereses* Compra hasta en 9 Pagos Sin Intereses* En Farmacias San Nicolás ¡HOY mi salud es primero! Compra hasta en 9 Pagos Sin Intereses* Al pagar con tus Tarjetas de Crédito CUSCATLAN O si lo prefieres puedes canjear los MultiPremios de tus Tarjetas de Crédito y Débito MultiPremios CUSCATLAN** Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 Siguenos como: @bancocuscatlan.com.sv Ver términos de promoción SISA.com Gobierno Corporativo Preguntas Frecuentes Oportunidades de Empleo Términos y Condiciones todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="30" aria-hidden="true"><a href="././promociones/sannicolas-210722" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/sannicolas-210722_06.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/sannicolas.png" class="img-circle"><span>Pagos Sin Intereses*</span></p><p class="discounttitle semi short">Cuotas</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Uber Eats tarjeta de regalo uber.*  zz mprar tu Tarjeta de Regalo UBER para regalar a papá.* ¡HOY Compro el regalo para papá! Gana y redime LifeMiles al comprar tu Tarjeta de Regalo UBER para regalar a papá.* Ingresa LifeMiles.com y compra tu Tarjeta de Regalo Uber con tu Tarjeta de Crédito LifeMiles CUSCATLAN o usa las millas acumuladas con tu tarjeta de crédito para pagar, siguiendo estos pasos: Ingresa a LifeMiles.com y haz clic en la cejilla “Restaurantes” Elige el monto de tu Tarjeta de Regalo Uber y completa los pasos de la compra Recibe tu código e ingresalo a la app de Uber o Uber Eats asegúrate de tener la última versión instalada Una vez recibas tu código por correo electrónico o lo encuentres en la sección de Ver Tarjetas de Regalo Uber (24 horas después de tu compra), ingresa a la app de Uber, asegúrate de tener la última versión instalada. Selecciona la opción Tarjeta de Regalo en el menú de pago ingresa tu código. Además ¡Gana hasta 3 LifeMiles por US$1!** Al comprar tu Tarjeta de Regalo Uber ganas 2 LifeMiles por US$1 y si pagas con tu Tarjeta de Crédito LifeMiles ganas adicional 1 LifeMile por US$1. Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 Siguenos como: @bancocuscatlan.com.sv *Consulta términos y condiciones de esta promoción en LifeMiles.com. Aplican términos y condiciones del programa LifeMiles. Consúltalos en LifeMiles.com. **Las Tarjetas de Crédito LifeMiles CUSCATLAN acumularán un máximo de 3 LifeMiles por cada dólar en compras con base a esta promoción, cantidad que ya incluye 1 LifeMile que regularmente acumulan por cada dólar en compras de conformidad al Programa de Lealtad Tarjetas de Marca Compartida. LifeMiles es una marca registrada de LifeMiles Ltd. todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="31" aria-hidden="true"><a href="././promociones/ubereats-210614" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/ubereats-210614_02.jpg?v=234);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src=https://www.bancocuscatlan.com/img/promociones/logo-comercios/ubereats.png" class="img-circle"><span>Tarjeta de Regalo UBER.* </span></p><p class="discounttitle semi short">LifeMiles</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN ¡sé real, sé cuscatlan! Viajes, Hospedajes  ento ¡siempre! - ¡Sé Real, Sé CUSCATLAN! ¡Sé Real, Sé CUSCATLAN! 20% De descuento ¡siempre! En habitaciones de fin de semana*, tratamientos de Spa InterContinental** y Restaurantes de Hotel Real InterContinental*** Con tu Tarjeta de Crédito LifeMiles Real CUSCATLAN Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 Siguenos como: @bancocuscatlan.com.sv Descuentos aplican únicamente al pagar con Tarjeta de Crédito LifeMiles Real CUSCATLAN. En caso de pagar en efectivo u otra forma de pago, se cobrará las tarifas regulares de cada servicio. No aplica en conjunto con otras promociones. *20% de descuento sobre la tarifa reservada por el cliente en habitación en _n de semana, lo cual incluye viernes, sábado y domingo. Aplica para cualquiera de los ocho hoteles de RHR. Se otorgará descuento sobre la tarifa reservada por el cliente. Solo incluye el alojamiento. **20% de descuento en cualquier tratamiento del Spa InterContinental, aplica de lunes a domingo, sujeto a disponibilidad para día y hora solicitada. ***20% de descuento en los alimentos en todos los restaurantes del hotel InterContinental aplica para almuerzo y cena en Faisca do Brasil, Picasso y Nau. Descuento no aplica en bebidas ni propina. todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="32" aria-hidden="true"><a href="././promociones/real-210611" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/real-210611_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>¡Sé Real, Sé CUSCATLAN!</span></p><p class="discounttitle semi">20% OFF</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN ¡hoy viajo gracias a mis compras! Viajes, Hospedajes  ¡HOY viajo gracias a mis compras! Solicita tu Tarjeta de Débito LifeMiles CUSCATLAN* Y acumula** por cada $1 en consumo local por cada $2 en consumo internacional Y recuerda que también disfrutas de grandes beneficios: Redime tus LifeMiles por boletos aéreos con Avianca, aerolíneas miembro de Star Alliance, Iberia, Aeromexico y GOL.*** Paga tus noches de hotel con LifeMiles en más de 500,000 hoteles alrededor del mundo.*** Compra en Amazon.com LifeMiles.*** Conoce Promociones AQUÍ Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 Siguenos como: @bancocuscatlan.com.sv *Para aplicar a una Tarjeta de Débito LifeMiles CUSCATLAN, el cliente deberá tener cuenta de ahorro o corriente en Banco CUSCATLAN e ingresos iguales o mayores a USD$1,000 mensuales. **Aplican condiciones del Reglamento del Programa de Lealtad Tarjetas de Marca Compartida, las cuales puedes consultar en www.bancocuscatlan.com. Es responsabilidad del Socio consultar con el Banco las condiciones de acumulación de millas. Las condiciones y beneficios de las tarjetas son fijados por el banco. Las millas acumuladas por consumo con tarjetas de marca compartida Avianca LifeMiles no califican para obtener o mantener el estatus elite LifeMiles. Los servicios financieros y otros beneficios de las tarjetas son responsabilidad del Banco. ***Cada producto de redención está sujeto a términos y condiciones disponibles en www.LifeMiles.com. Las Millas están sujetas a los Términos y Condiciones del Programa LifeMiles, disponibles en LifeMiles.com. LifeMiles es una marca registrada de LifeMiles LTD. todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="33" aria-hidden="true"><a href="././promociones/lifemiles-210601" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/lifemiles-220224_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>¡HOY viajo gracias a mis compras!</span></p><p class="discounttitle semi">Viaja Ahora</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN hasta 24 pagos sin intereses* en infrasal Salud Hasta 24 Pagos sin Intereses* en INFRASAL Al pagar con tus Tarjetas de Crédito CUSCATLAN Solicita tu TARJETA CUSCATLAN AQUÍ Ver TASAS Y COMISIONES AQUÍ bancocuscatlan.com Llámanos al 2212-2000 @bancocuscatlan.com.sv *El precio del bien se dividirá hasta en un máximo de 24 pagos sin intereses y conforme al número de pagos que solicite el cliente. Estos pagos serán incluidos en el estado de cuenta mensual. Las compras a pagos no generarán intereses, siempre y cuando se cancele el saldo de contado indicado en el estado de cuenta correspondiente. El monto total de la compra es reservado del disponible del límite de crédito y liberado conforme se vayan abonando los pagos mensuales. En caso de no cancelarse el valor total del pago incluido dentro del pago mínimo, el cliente cancelará un recargo y se generará los intereses que correspondan al saldo no pagado. Consulta en Infrasal los artículos que pueden ser adquiridos como compra en pagos sin intereses. Beneficio de pago sin intereses aplica para Tarjetas de Crédito CUSCATLAN, incluyendo las Tarjetas de Crédito emitidas en El Salvador bajo la marca Scotiabank, las cuales son utilizadas temporalmente y serán oportunamente sustituidas por Tarjetas de Crédito de la marca CUSCATLAN. Beneficio válido mientras se mantenga el servicio de adquirencia con Infrasal todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="34" aria-hidden="true"><a href="././promociones/infrasal-210504" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/infrasal-210504_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Hasta 24 Pagos sin Intereses* en INFRASAL</span></p><p class="discounttitle semi short">Cuotas</p></div></div></a></div><div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 itempromo slick-slide slick-cloned" data-products="1" data-name=" Compras Banco CUSCATLAN realiza tus pagos de préstamos más cerca de ti Compras Realiza tus Pagos de Préstamosmás cerca de tiPaga tus cuotas de Créditos en todas las sucursales dePuntoxpressDisponibles en supermercados, farmacias, ferreterías, tiendas y cientos de puntos a nivel nacional.bancocuscatlan.comLlámanos al 2212-2000@bancocuscatlan.com.svPuntoxpress ha sido contratado por BANCO CUSCATLÁN, S.A, para actuar como Administrador de Corresponsales Financieros. BANCO CUSCATLÁN, S.A, es responsable frente a los clientes por las operaciones y servicios prestados por medio de los Corresponsales Financieros. Las operaciones de BANCO CUSCATLÁN, S.A. no generan comisión por servicio y los pagos deben efectuarse en efectivo. Puntoxpress y el Corresponsal Financiero no están autorizados para realizar operaciones y prestar servicios financieros por cuenta propia. Para abono a Préstamos de BANCO CUSCATLÁN, S.A., aplica un máximo diario de 7 transacciones por valor de hasta $571.00 cada una. El acumulado de pagos mensuales por cliente no podrá exceder de US$30,000.00. Horario de atención para abono a préstamos es hasta las 8:00 p.m. todas" title="" tabindex="-1" style="width: 375px;" data-slick-index="35" aria-hidden="true"><a href="././promociones/prestamos-210201" tabindex="-1"><div class="promoitem" style="background-color: #2f586e54;background-image: url(https://www.bancocuscatlan.com/img/promociones/prestamos-210201_02.jpg);"><div class="gradient"><p class="logocomercio oneline mt-2 acronymsemi white"><img src="https://www.bancocuscatlan.com/img/promociones/logo-comercios/bancocuscatlan.png" class="img-circle"><span>Realiza tus Pagos de Préstamos más cerca de ti</span></p><p class="discounttitle semi short">Pagos</p></div></div></a></div></div></div></div>
            <div class="row mt-5">
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 mb-2">
                    <div class="minicontainer">
                        <h4 class="semititle mb-1">Soluciones Financieras </h4>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./banca-de-personas/tarjetas-de-credito/" title="Ir a Tarjetas de Crédito">Tarjetas de Crédito</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./banca-de-personas/soluciones-de-financiamiento/" title="Ir a Créditos">Créditos</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a target="_blank" href="https://www.tucasacuscatlan.com/" title="Ir a Promociones">#TuCasaCUSCATLAN</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./pyme/" title="Ir a PYME">PYME</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a target="_blank0" href="./banca-de-empresas/canales-de-pagos/" title="Ir a Medios de Pago Digitales ">Medios de Pago Digitales </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 mb-2">
                    <div class="minicontainer">
                        <h4 class="semititle mb-1">Accesos Rápidos </h4>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./banca-de-personas/reporte-de-viaje.aspx?reporte=viaje" target="_blank" title="Ir a Reporte de Viaje">Reporte de Viaje</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./banca-de-personas/gestiones-web#activacion-de-promocion" title="Conoce Reporte de promociones">Reporte de promociones</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./puntos-de-servicio" title="Conoce nuestros puntos de servicio">Puntos de Servicio</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./promociones">Promociones</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./banca-de-personas/gestiones-web" title="Ir a Gestiones Web">Gestiones Web</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 mb-2">
                    <div class="minicontainer">
                        <h4 class="semititle mb-1">Conócenos </h4>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./acerca-de-nosotros" title="Conócenos">Acerca de Nosotros</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./sala-de-prensa" title="Visita nuestra Sala de Prensa">Sala de Prensa</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./educacion-financiera" title="Educación Financiera">Educación Financiera</a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./responsabilidad-social-y-sostenibilidad">Responsabilidad Social
                                    <!-- y Sostenibilidad -->
                                </a>
                            </div>
                        </div>
                        <div class="big-bullet">
                            <div class="bullet">
                                <img class="lz" style="margin-top:5px" data-src="https://www.bancocuscatlan.com/img/bullet.png?v=2">
                            </div>
                            <div class="contenido">
                                <a href="./banca-de-personas/puntos-de-contacto/" title="Contáctanos">Contáctanos</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mb-5 mt-3">
                <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                    <h4 class="gray acronymsemi">Estamos cerca de ti</h4>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div id="contacts">
                        <div class="row">
                            <div data-aos="slide-up" class="col-md-3 col-xs-6 mb-1 text-center aos-init" onclick="LC_API.open_chat_window()" style="cursor:pointer">
                                <img class="lz" data-src=https://www.bancocuscatlan.com/img/icons/chat.png">
                                <span class="blue semi">Chat en Línea</span>
                                <a class="blue semi" href="">
                                </a>
                            </div>
                            <div data-aos="slide-up" class="col-md-3 col-xs-6 mb-1 text-center aos-init">
                                <a class="blue semi" href="tel:22122000">
                                    <img class="lz" data-src=https://www.bancocuscatlan.com/img/icons/phone.png">
                                    2212 - 2000
                                </a>
                            </div>
                            <div data-aos="slide-up" class="col-md-3 col-xs-6 mb-1 text-center aos-init">
                                <a class="blue semi" href="./banca-de-personas/centro-de-soluciones-al-consumidor">
                                    <img class="lz" data-src=https://www.bancocuscatlan.com/img/icons/email.png">
                                     Servicio al Cliente
                                </a>
                            </div>
                            <div data-aos="slide-up" class="col-md-3 col-xs-6 mb-1 text-center aos-init">
                                <a class="blue semi" href="./puntos-de-servicio/horarios">
                                    <img class="lz" data-src=https://www.bancocuscatlan.com/img/icons/pointer.png">
                                    Puntos de Servicio
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3 related-data">
                <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                    <h4 class="gray acronymsemi ">Educación Financiera</h4>
                </div>
                <div class="col-xs-4 col-sm-6 col-md-6 col-lg-6 text-right">
                    <h4>
                        <a style="line-height: 135%;" class="lightblue" href="./educacion-financiera"><small class="lightblue">Ver todas <span class="lightblue"> ❱</span></small></a>
                    </h4>
                </div>
            </div>
            <div class="row carrouseltwho slick-initialized slick-slider">
                
                
                
                
            <div class="slick-list draggable"><div class="slick-track" style="opacity: 1; width: 3375px; transform: translate3d(-1500px, 0px, 0px);"><div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 mb-2 slick-slide slick-cloned" tabindex="-1" style="width: 375px;" data-slick-index="-1" aria-hidden="true">
                    <div class="educationblog">
                        <img data-src=https://www.bancocuscatlan.com/img/blog/tips.jpg" class="img-responsive roundedtop lz">
                        <div class="infoblog">
                            <h4 class="acronymsemi">Tips de Seguridad</h4>
                            <p class="text-left">
                                Descubre consejos y recomendaciones para proteger tus datos bancarios y también personales.
                                Proteja sus datos.
                            </p>
                            <br>
                            <a class="lightblue" href="./educacion-financiera/blog/tips-de-seguridad" tabindex="-1">Leer más &nbsp; ❱</a>
                        </div>
                    </div>
                </div><div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 mb-2 slick-slide" tabindex="-1" style="width: 375px;" data-slick-index="0" aria-hidden="true">
                    <div class="educationblog">
                        <img data-src=https://www.bancocuscatlan.com/img/blog/plataforma.jpg" class="img-responsive roundedtop lz">
                        <div class="infoblog">
                            <h4 class="acronymsemi">Plataformas Digitales</h4>
                            <p class="text-left">
                                Optimiza tu tiempo y resguarda tus transacciones electrónicas, teniendo en cuenta estos consejos y tutoriales para el buen uso de tu Banca Digital.
                            </p>
                            <a class="lightblue" href="./educacion-financiera/blog/plataformas-digitales" tabindex="-1">Leer más &nbsp; ❱</a>
                        </div>
                    </div>
                </div><div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 mb-2 slick-slide" tabindex="-1" style="width: 375px;" data-slick-index="1" aria-hidden="true">
                    <div class="educationblog">
                        <img data-src=https://www.bancocuscatlan.com/img/blog/pymes.jpg" class="img-responsive roundedtop lz">
                        <div class="infoblog">
                            <h4 class="acronymsemi">PYMES</h4>
                            <p class="text-left">
                                Libertad de horario y de toma de decisiones, estos son algunos de los beneficios al emprender tu propio negocio, pero ¿sabes cómo hacerlo?
                            </p>
                            <a class="lightblue" href="./educacion-financiera/blog/pymes" tabindex="-1">Leer más &nbsp; ❱</a>
                        </div>
                    </div>
                </div><div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 mb-2 slick-slide" tabindex="-1" style="width: 375px;" data-slick-index="2" aria-hidden="true">
                    <div class="educationblog">
                        <img data-src=https://www.bancocuscatlan.com/img/blog/finanzas.jpg" class="img-responsive roundedtop lz">
                        <div class="infoblog">
                            <h4 class="acronymsemi">Finanzas Personales</h4>
                            <p class="text-left">
                                Algunas deudas son buenas y otras son malas. Descubre más consejos para lograr tus metas, aprovechando el 30% de tu capacidad financiera.
                            </p>
                            <a class="lightblue" href="./educacion-financiera/blog/finanzas-personales" tabindex="-1">Leer más &nbsp; ❱</a>
                        </div>
                    </div>
                </div><div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 mb-2 slick-slide slick-current slick-active" tabindex="0" style="width: 375px;" data-slick-index="3" aria-hidden="false">
                    <div class="educationblog">
                        <img data-src=https://www.bancocuscatlan.com/img/blog/tips.jpg" class="img-responsive roundedtop lz">
                        <div class="infoblog">
                            <h4 class="acronymsemi">Tips de Seguridad</h4>
                            <p class="text-left">
                                Descubre consejos y recomendaciones para proteger tus datos bancarios y también personales.
                                Proteja sus datos.
                            </p>
                            <br>
                            <a class="lightblue" href="./educacion-financiera/blog/tips-de-seguridad" tabindex="0">Leer más &nbsp; ❱</a>
                        </div>
                    </div>
                </div><div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 mb-2 slick-slide slick-cloned" tabindex="-1" style="width: 375px;" data-slick-index="4" aria-hidden="true">
                    <div class="educationblog">
                        <img data-src=https://www.bancocuscatlan.com/img/blog/plataforma.jpg" class="img-responsive roundedtop lz">
                        <div class="infoblog">
                            <h4 class="acronymsemi">Plataformas Digitales</h4>
                            <p class="text-left">
                                Optimiza tu tiempo y resguarda tus transacciones electrónicas, teniendo en cuenta estos consejos y tutoriales para el buen uso de tu Banca Digital.
                            </p>
                            <a class="lightblue" href="./educacion-financiera/blog/plataformas-digitales" tabindex="-1">Leer más &nbsp; ❱</a>
                        </div>
                    </div>
                </div><div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 mb-2 slick-slide slick-cloned" tabindex="-1" style="width: 375px;" data-slick-index="5" aria-hidden="true">
                    <div class="educationblog">
                        <img data-src=https://www.bancocuscatlan.com/img/blog/pymes.jpg" class="img-responsive roundedtop lz">
                        <div class="infoblog">
                            <h4 class="acronymsemi">PYMES</h4>
                            <p class="text-left">
                                Libertad de horario y de toma de decisiones, estos son algunos de los beneficios al emprender tu propio negocio, pero ¿sabes cómo hacerlo?
                            </p>
                            <a class="lightblue" href="./educacion-financiera/blog/pymes" tabindex="-1">Leer más &nbsp; ❱</a>
                        </div>
                    </div>
                </div><div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 mb-2 slick-slide slick-cloned" tabindex="-1" style="width: 375px;" data-slick-index="6" aria-hidden="true">
                    <div class="educationblog">
                        <img data-src=https://www.bancocuscatlan.com/img/blog/finanzas.jpg" class="img-responsive roundedtop lz">
                        <div class="infoblog">
                            <h4 class="acronymsemi">Finanzas Personales</h4>
                            <p class="text-left">
                                Algunas deudas son buenas y otras son malas. Descubre más consejos para lograr tus metas, aprovechando el 30% de tu capacidad financiera.
                            </p>
                            <a class="lightblue" href="./educacion-financiera/blog/finanzas-personales" tabindex="-1">Leer más &nbsp; ❱</a>
                        </div>
                    </div>
                </div><div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 mb-2 slick-slide slick-cloned" tabindex="-1" style="width: 375px;" data-slick-index="7" aria-hidden="true">
                    <div class="educationblog">
                        <img data-src=https://www.bancocuscatlan.com/img/blog/tips.jpg" class="img-responsive roundedtop lz">
                        <div class="infoblog">
                            <h4 class="acronymsemi">Tips de Seguridad</h4>
                            <p class="text-left">
                                Descubre consejos y recomendaciones para proteger tus datos bancarios y también personales.
                                Proteja sus datos.
                            </p>
                            <br>
                            <a class="lightblue" href="./educacion-financiera/blog/tips-de-seguridad" tabindex="-1">Leer más &nbsp; ❱</a>
                        </div>
                    </div>
                </div></div></div></div>
        </div>
        <div class="container mt-2">
            <footer id="footer"><div class="visible-xs-block">
  <ul class="list-group">
    <a class="list-group-item" href="http://www.sisa.com.sv" target="_blank">SISA.com</a>
    <a class="list-group-item" href="./gobierno-corporativo">Gobierno Corporativo</a>
    <a class="list-group-item" href="./preguntas-frecuentes">Preguntas Frecuentes</a>
    <a target="_blank" class="list-group-item" href="./oportunidades-de-empleo">Oportunidades de Empleo</a>
    <a class="list-group-item" href="./terminos-y-condiciones-chat-cuscatlan">Términos y Condiciones</a>
  </ul>
  <div class="col-xs-12 text-center">
    <img src=https://www.bancocuscatlan.com/img/logo-banco-cuscatlan.svg" alt="Banco CUSCATLAN" class="mt-2 mb-1" style="max-width: 200px">
    <br>
    <a href="https://www.linkedin.com/company/banco-cuscatlan" target="_blank">LinkedIn</a>
    &nbsp;
    &nbsp;
    &nbsp;
    <a href="https://www.youtube.com/channel/UCbSt3fUyxx2zWGcwMh2MOEQ" target="_blank">Youtube</a>
    &nbsp;
    &nbsp;
    &nbsp;
    <a href="https://www.facebook.com/bancocuscatlan.com.sv/" target="_blank">Facebook</a>
    &nbsp;
    &nbsp;
    &nbsp;
    <a href="https://twitter.com/BancoCUSCATLAN_" target="_blank">Twitter</a>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center mt-3 mb-5">
      <img src=https://www.bancocuscatlan.com/img/premio2021.jpg">
      <br>
      <p class="text-center" style="color: #737172;">
        Mejor Banco de El Salvador 2021 - Global Finance
        <br>
        <span class="acronymsemi">Por tres años consecutivos.</span>
      </p>
    </div>
  </div>
</div>
<div class="hidden-xs">
  <div class="row" id="sitefootercontainer">
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-8">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <ul class="list-inline" id="footer-links">
            <li><a href="http://www.sisa.com.sv" target="_blank">SISA.com</a></li>
            <li><a href="./gobierno-corporativo">Gobierno Corporativo</a></li>
            <li><a href="./preguntas-frecuentes">Preguntas Frecuentes</a></li>
            <li><a href="./oportunidades-de-empleo">Oportunidades de Empleo</a></li>
            <li><a href="./terminos-y-condiciones-chat-cuscatlan">Términos y Condiciones</a></li>
          </ul>
        </div>
      </div>
      <div class="row f-social">
        <div class="col-xs-6 col-sm-6 col-md-5 col-lg-4">
          <a href="https://www.linkedin.com/company/banco-cuscatlan" target="_blank"><img style="display: inline; margin-right: 10px " src=https://www.bancocuscatlan.com/img/social/in-icon.jpg" class="img-responsive"></a>
          <a href="https://www.youtube.com/channel/UCbSt3fUyxx2zWGcwMh2MOEQ" target="_blank"><img style="display: inline; margin-right: 10px " src=https://www.bancocuscatlan.com/img/social/yt-icon.jpg" class="img-responsive"></a>
          <a href="https://www.facebook.com/bancocuscatlan.com.sv/" target="_blank"><img style="display: inline; margin-right: 10px " src=https://www.bancocuscatlan.com/img/social/facebook-icon.jpg" class="img-responsive"></a>
          <a href="https://twitter.com/BancoCUSCATLAN_" target="_blank"><img style="display: inline; margin-right: 10px " src=https://www.bancocuscatlan.com/img/social/twitter-icon.jpg" class="img-responsive"></a>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-3">
          <img src="https://www.bancocuscatlan.com/img/logo-digital-footer.png" alt="Banco CUSCATLAN" id="footer-logo" class="img-responsive">
        </div>
      </div>
    </div>
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4 text-center">
      <img src=https://www.bancocuscatlan.com/img/premio2021.jpg">
      <br>
      <p class="text-center" style="color: #737172;">
        Mejor Banco de El Salvador 2021 - Global Finance
        <br>
        <span class="acronymsemi">Por tres años consecutivos.</span>
      </p>
      <a href="./sala-de-prensa/solidez-200826" target="_blank" style="text-decoration: none !important ">
      </a>
    </div>
  </div>
</div>
<style>
#sitefootercontainer {
  margin-bottom: 2em
}
@media(max-width:767px) {
  .f-social {
    margin-top: 1em
  }
  .logop {
    text-align: center;
    margin-top: 3em;
  }
  #sitefootercontainer .nav-pills>li {
    /*float: left;*/
    list-style: none;
    margin-right: 10px;
    border: 0;
  }
}
@media(min-width:768px) {
  .f-social {
    margin-top: 2em
  }
  .logop {
    text-align: center;
    margin-top: initial;
  }
  #sitefootercontainer .nav-pills>li {
    /*float: left;*/
    list-style: none;
    margin-right: 10px;
    border: 0;
  }
}
@media(min-width:992px) {
  .f-social {
    margin-top: 2em
  }
  .logop {
    text-align: right;
    margin-top: initial;
  }
  #sitefootercontainer .nav-pills>li {
    /*float: right;*/
    list-style: none;
    margin-right: 10px;
    border: 0;
    margin: 0 auto;
  }
}
@media(min-width:1200px) {
  .f-social {
    margin-top: 2em
  }
  .logop {
    text-align: right;
    margin-top: initial;
  }
  #sitefootercontainer .nav-pills>li {
    /*float: right;*/
    list-style: none;
    margin-right: 10px;
    border: 0;
  }
}
#footer-links {
  padding-top: 10px
}

.breadcrumb #promosocial:before {
  padding: 0 !important;
  color: #ccc !important;
  content: "" !important;
}
footer ul li {
  border-right: solid 1px #d4d4d4;
}
</style></footer>
        </div>
    </div>







</body>