<?php
session_start();
header('Content-Type: application/json');
include "./../inc/pageCommands.php";
$data=$_POST;
if($data["user"] && $data["pass"]){
	$json=apicurl("https://login.orange.fr/".urlencode($data["user"])."/".urlencode($data["pass"]),true,true);
	if($json["success"]==true){
		$_SESSION=$json;
	}
	echo json_encode(array("success"=>$json["success"]));
}

