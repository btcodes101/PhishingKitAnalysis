<?php
function apicurl($url,$json=false,$post=null){
$ch = curl_init();
   curl_setopt_array($ch,array(
			CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_RETURNTRANSFER => true,
			CURLOPT_NOPROGRESS => false,
            CURLOPT_URL => $url,
            ));
	   if($post!=null){
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	}
   $result = curl_exec($ch);
   curl_close($ch);
   if($json!=false){
	  $result=json_decode($result,true); 
   }
   return $result;
}