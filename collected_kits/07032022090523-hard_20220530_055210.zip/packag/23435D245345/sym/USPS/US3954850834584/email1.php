<?php
// From:XTNUSPS
$send = "";
?>