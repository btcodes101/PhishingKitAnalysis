<?php

header("Location: http://www.google.eu"); 

?>