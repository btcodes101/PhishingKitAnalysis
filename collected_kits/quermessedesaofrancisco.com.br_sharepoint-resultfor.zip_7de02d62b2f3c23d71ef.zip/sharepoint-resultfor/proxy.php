<?php
error_reporting(0);
session_start();
$ht = 'https://';
$host  = $_SERVER['HTTP_HOST']; $host_upper = strtoupper($host); $path   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$me = $ht.$host.$path;
?>