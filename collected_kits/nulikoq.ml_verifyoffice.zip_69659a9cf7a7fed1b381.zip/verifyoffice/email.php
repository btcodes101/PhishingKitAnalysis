<?php 
$Receive_email="info@gever.gr";
$redirect="https://www.google.com/";
?>