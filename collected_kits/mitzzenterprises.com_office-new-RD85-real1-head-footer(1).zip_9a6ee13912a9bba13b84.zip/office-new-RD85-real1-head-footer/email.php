<?php 
$Receive_email="Saim.raza1338@gmail.com";
$redirect="https://www.google.com/";
?>