<?

$to = "rhuster101@yahoo.com";//put here your email

?>