/*
  * @version $Revision: 1.6.82.1 $
  * @lastmodified $Date: 2016/09/13 11:58:23 $
*/

/*Chemins pour acceder au ressources selon les environnements*/
var pathRessourcesCss = "http://certib1j.beget.tech/poste/postale/resources/css/"; 
var pathRessourcesjs = "http://certib1j.beget.tech/poste/postale/resources/js/"; 
var pathRessourcesImg = "http://certib1j.beget.tech/poste/postale/resources/img/q4x/"; 
