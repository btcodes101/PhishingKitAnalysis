/*
  * @version $Revision: 1.52.54.1.10.1 $
  * @lastmodified $Date: 2017/04/24 14:21:53 $
*/



function getCookie(c_name, path) {
	if (document.cookie.length > 0) {
		c_start = document.cookie.indexOf(c_name + "=");
		if (c_start != -1) {
			c_start = c_start + c_name.length + 1;
			c_end = document.cookie.indexOf(";", c_start);
			if (c_end == -1) {
				c_end = document.cookie.length;
			}
			return unescape(document.cookie.substring(c_start, c_end));
		}
	}
	return "";
}

function setCookie(c_name, value, expirationTime, path) {
	var exdate = new Date();
	if (expirationTime == null) {
		expirationTime = 3600*1000*24*365*100;
	}
	exdate.setTime(exdate.getTime() + expirationTime);
	var c_value = escape(value) + "; expires=" + exdate.toUTCString();
	if (path) { c_value += ';path=' + path; }
	document.cookie = c_name + "=" + c_value;
}

function JSONTools() {
	var	escapeable = /["\\\x00-\x1f\x7f-\x9f]/g,
		meta = {
			'\b': '\\b',
			'\t': '\\t',
			'\n': '\\n',
			'\f': '\\f',
			'\r': '\\r',
			'"' : '\\"',
			'\\': '\\\\'
		};
	/**
	 * jQuery.toJSON
	 * Converts the given argument into a JSON respresentation.
	 *
	 * @param o {Mixed} The json-serializble *thing* to be converted
	 *
	 * If an object has a toJSON prototype, that will be used to get the representation.
	 * Non-integer/string keys are skipped in the object, as are keys that point to a
	 * function.
	 *
	 */
	$.toJSON = typeof JSON === 'object' && JSON.stringify
		? JSON.stringify
		: function( o ) {

		if ( o === null ) {
			return 'null';
		}

		var type = typeof o;

		if ( type === 'undefined' ) {
			return undefined;
		}
		if ( type === 'number' || type === 'boolean' ) {
			return '' + o;
		}
		if ( type === 'string') {
			return $.quoteString( o );
		}
		if ( type === 'object' ) {
			if ( typeof o.toJSON === 'function' ) {
				return $.toJSON( o.toJSON() );
			}
			if ( o.constructor === Date ) {
				var	month = o.getUTCMonth() + 1,
					day = o.getUTCDate(),
					year = o.getUTCFullYear(),
					hours = o.getUTCHours(),
					minutes = o.getUTCMinutes(),
					seconds = o.getUTCSeconds(),
					milli = o.getUTCMilliseconds();

				if ( month < 10 ) {
					month = '0' + month;
				}
				if ( day < 10 ) {
					day = '0' + day;
				}
				if ( hours < 10 ) {
					hours = '0' + hours;
				}
				if ( minutes < 10 ) {
					minutes = '0' + minutes;
				}
				if ( seconds < 10 ) {
					seconds = '0' + seconds;
				}
				if ( milli < 100 ) {
					milli = '0' + milli;
				}
				if ( milli < 10 ) {
					milli = '0' + milli;
				}
				return '"' + year + '-' + month + '-' + day + 'T' +
					hours + ':' + minutes + ':' + seconds +
					'.' + milli + 'Z"';
			}
			if ( o.constructor === Array ) {
				var ret = [];
				for ( var i = 0; i < o.length; i++ ) {
					ret.push( $.toJSON( o[i] ) || 'null' );
				}
				return '[' + ret.join(',') + ']';
			}
			var	name,
				val,
				pairs = [];
			for ( var k in o ) {
				type = typeof k;
				if ( type === 'number' ) {
					name = '"' + k + '"';
				} else if (type === 'string') {
					name = $.quoteString(k);
				} else {
					// Keys must be numerical or string. Skip others
					continue;
				}
				type = typeof o[k];

				if ( type === 'function' || type === 'undefined' ) {
					// Invalid values like these return undefined
					// from toJSON, however those object members
					// shouldn't be included in the JSON string at all.
					continue;
				}
				val = $.toJSON( o[k] );
				pairs.push( name + ':' + val );
			}
			return '{' + pairs.join( ',' ) + '}';
		}
	};

	/**
	 * jQuery.quoteString
	 * Returns a string-repr of a string, escaping quotes intelligently.
	 * Mostly a support function for toJSON.
	 * Examples:
	 * >>> jQuery.quoteString('apple')
	 * "apple"
	 *
	 * >>> jQuery.quoteString('"Where are we going?", she asked.')
	 * "\"Where are we going?\", she asked."
	 */
	$.quoteString = function( string ) {
		if ( string.match( escapeable ) ) {
			return '"' + string.replace( escapeable, function( a ) {
				var c = meta[a];
				if ( typeof c === 'string' ) {
					return c;
				}
				c = a.charCodeAt();
				return '\\u00' + Math.floor(c / 16).toString(16) + (c % 16).toString(16);
			}) + '"';
		}
		return '"' + string + '"';
	};
}

function openPopinWithLink(link, title) {
	var reg=new RegExp("(webaccess)", "g");

	var corps = 	"<div class=\"header\">";
	corps = corps + "	<a href=\"#\" class=\"close\">Fermer</a>";
	corps = corps + "	<h1 id=\"popinTitle\">"+title.replace(reg,"")+"</h1>";
	corps = corps + "</div>";
	corps = corps + "<div class=\"line\">";
	corps = corps + "	<iframe id=\"framePopin\" frameborder=\"none\" src=\""+link+"\" class=\"iframe\" width=\"670\" height=\"100%\" scrolling=\"auto\">";
	corps = corps + "		<a href=\""+link+"\" title=\"Acc&eacute;der au contenu de la popin\">Acc&eacute;der ou contenu de la popin</a>";
	corps = corps + "	</iframe>";
	corps = corps + "</div>";

	openSimplePopin("modalWindow", corps, false);

	$('object').hide();
	$('.simplemodal-close').click(function (e) { $('object').show(); });
	$(document).keydown(function(e) { if (e.keyCode == 27) { $('object').show(); } });

	return false;
}

function openPopinNoFrame(text, title) {
	var reg=new RegExp("(webaccess)", "g");

	var corps = 	"<div class=\"header\">";
	corps = corps + "	<a href=\"#\" class=\"close\">Fermer</a>";
	corps = corps + "	<h1 id=\"popinTitle\">"+title.replace(reg,"")+"</h1>";
	corps = corps + "</div>";
	corps = corps + "<div class=\"line\">";
	corps = corps + "	<div class=\"text\" style=\"padding:20px;\">"+text+"</p>";
	corps = corps + "</div>";

	openSimplePopin("modalWindow", corps, false);

	$('object').hide();
	$('.simplemodal-close').click(function (e) { $('object').show(); });
	$(document).keydown(function(e) { if (e.keyCode == 27) { $('object').show(); } });

	return false;
}

function openPopinWithLinkNoCross(link, title) {
	var reg=new RegExp("(webaccess)", "g");
				alert("popin no cross");
	var corps = 	"<div class=\"header\">";
	corps = corps + "	<h1 id=\"popinTitle\">"+title.replace(reg,"")+"</h1>";
	corps = corps + "</div>";
	corps = corps + "<div class=\"line\">";
	corps = corps + "	<iframe id=\"framePopin\" frameborder=\"none\" src=\""+link+"\" class=\"iframe\" width=\"670\" scrolling=\"auto\">";
	corps = corps + "		<a href=\""+link+"\" title=\"Acc&eacute;der au contenu de la popin\">Acc&eacute;der ou contenu de la popin</a>";
	corps = corps + "	</iframe>";
	corps = corps + "</div>";

	openSimplePopin("modalWindow", corps, false);

	$('object').hide();
	$('.simplemodal-close').click(function (e) { $('object').show(); });
	$(document).keydown(function(e) { if (e.keyCode == 27) { $('object').show(); } });

	return false;
}

function openPopinWithReloadOnClose(link, title) {
	var reg=new RegExp("(webaccess)", "g");

	var corps = 	"<div class=\"header\">";
	corps = corps + "	<a href=\"#\" class=\"close simplemodal-close\">Fermer</a>";
	corps = corps + "	<h1 id=\"popinTitle\">"+title.replace(reg,"")+"</h1>";
	corps = corps + "</div>";
	corps = corps + "<div class=\"line\">";
	corps = corps + "	<iframe id=\"framePopin\" frameborder=\"none\" src=\""+link+"\" class=\"iframe\" width=\"670\" scrolling=\"auto\">";
	corps = corps + "		<a href=\""+link+"\" title=\"Acc&eacute;der au contenu de la popin\">Acc&eacute;der ou contenu de la popin</a>";
	corps = corps + "	</iframe>";
	corps = corps + "</div>";

	openSimplePopin("modalWindow", corps, false);

	$('object').hide();
	$('.simplemodal-close').click(function (e) { $('object').show();window.location.reload(); });
	$(document).keydown(function(e) { if (e.keyCode == 27) { $('object').show();window.location.reload(); } });

	return false;
}

function openPopinDeconnexion(link, title) {
	var reg=new RegExp("(webaccess)", "g");

	var corps = 	"<div class=\"header\">";
	corps = corps + "	<h1 id=\"popinTitle\">"+title.replace(reg,"")+"</h1>";
	corps = corps + "</div>";
	corps = corps + "<div class=\"line\">";
	corps = corps + "	<iframe id=\"framePopin\" frameborder=\"none\" src=\""+link+"\" class=\"iframe\" width=\"670\" scrolling=\"auto\">";
	corps = corps + "		<a href=\""+link+"\" title=\"Acc&eacute;der au contenu de la popin\">Acc&eacute;der ou contenu de la popin</a>";
	corps = corps + "	</iframe>";
	corps = corps + "</div>";

	openSimplePopin("modalWindow", corps, false);

	$('object').hide();
	$('.simplemodal-close').click(function (e) { $('object').show(); });
	$(document).keydown(function(e) { if (e.keyCode == 27) { $('object').show(); } });

	return false;
}

function checkChoice(){
	$("#main fieldset .colheader input ").click(function(){
		if(this.checked)
		{
			$("#main fieldset."+this.id+" div span input").removeAttr('disabled');
			$("#main fieldset."+this.id+" .week input").removeAttr('disabled');
			$("#main fieldset."+this.id+" .spec-a input").removeAttr('disabled');

		}else{
			$("#main fieldset."+this.id+" div span input").attr('disabled', 'disabled');
			$("#main fieldset."+this.id+" .week input").attr('disabled', 'disabled');
			$("#main fieldset."+this.id+" .spec-a input").attr('disabled', 'disabled');
		}
	});

	$("#main fieldset div.formline.radio input[type=radio] ").click(function(){
		$("#main fieldset div.formline.radio div.field input").attr('disabled', 'disabled');
		$("#main fieldset div.formline.radio div.field select").attr('disabled', 'disabled');
		$("#main fieldset div.formline.radio."+this.id+" div.field input").removeAttr('disabled');
		$("#main fieldset div.formline.radio."+this.id+" div.field select").removeAttr('disabled');
	});
	$("#main fieldset div.formline.radio1 input[type=radio] ").click(function(){
		$("#main fieldset div.formline.radio1 div.field input").attr('disabled', 'disabled');
		$("#main fieldset div.formline.radio1 div.field select").attr('disabled', 'disabled');
		$("#main fieldset div.formline.radio1."+this.id+" div.field input").removeAttr('disabled');
		$("#main fieldset div.formline.radio1."+this.id+" div.field select").removeAttr('disabled');
	});
	$("#main fieldset div.formline.radio2 input[type=radio] ").click(function(){
		$("#main fieldset div.formline.radio2 div.field input").attr('disabled', 'disabled');
		$("#main fieldset div.formline.radio2 div.field select").attr('disabled', 'disabled');
		$("#main fieldset div.formline.radio2."+this.id+" div.field input").removeAttr('disabled');
		$("#main fieldset div.formline.radio2."+this.id+" div.field select").removeAttr('disabled');
	});
}

function supportChoice(form){
	$("#chSupport"+form.val()).show();

	$("#chSupport"+form.val()+" select").change(function(){
		$(".valueSet"+$(this).val()).show();
	});
}

$(document).ready(function() {

// *********************************************************   Debut des fonctions reskin -- Avril 2016 ********************************************************* //

// --------- Debut stepper -------- //

	// Stepper :  Ajout d'une balise span dans le stepper pour mise en forme du numéro detape //
	$( "#stepper li" ).each(function(index){
	    $(this).prepend( '<span class= stepper-num>' + (index+1) ).removeAttr( "style" );
	});

	// Stepper : Suppression des chiffres, tirets, points, underscore présents dans le texte html //
	$('#stepper li span:last-child').text(function(){
		var txt = $(this).text();
		var result = txt.replace(new RegExp("[0-9 \._-]", "g"), ' ');
		return (result);
	});

	// Suppression de class active sur les li précédentes à l'etape en cours //
	$( "#stepper li.active:last" ).prevAll().removeAttr('class');

// --------- Fin stepper -------- //

// --------- Debut Mise en forme des pages de synthese ( releve_ccp.html, releve_cne.html)  -------- //

	// Recuperation de lurl de la page active
	var urlPage = document.location.href;

	// Decoupage de l'url pour ne garder que le nom de la page
	var nomPage = urlPage.substring(urlPage.lastIndexOf( "/" )+1, urlPage.lastIndexOf( "." ) );

	// Tableau des pages pour mise en forme spécifiques aux pages de synthese de compte
	var verifPage = [
					"releveCPP-releve_ccp",
					"releveCNE-releve_cne",
					"afficheSyntheseComptes-synthese",
					"rechercheContratAssuranceDepuisMenu-synthese",
					"preparerRechercheListePrets-synthese",
					"rechercheContratAssurance-synthese",
					"preparerRechercheListePrets-synthese"
	];

	// page releve cne : suppression de la balise strong enfante du div.infosynthese //
	if( nomPage == verifPage[1]) {
		$(".part-a:first strong:eq(0) strong").unwrap();
	};

	// Mis en forme de la synthèse haute (div.info-synthese) des pages releve cne et releve ccp //
	if( nomPage == verifPage[0] || nomPage == verifPage[1]) {

	    // Repositionnement des boutons d'actions (Editer un rib, rechercher une operation ) en dessous du div.info-synthese //
	    $('ul.liens:first').insertBefore("#formID");

			// recuperation du texte de div.infosynthese + Imbrication dans trois div pour mise en forme + Suppression des br presents dans le code html //
	    $( ".part-a:first" ).contents()
	        .filter(function(index) {return this.nodeType === 3;})
	        .wrap( '<div></div>')
	        .end()
	        .filter("br")
	        .remove();

			// Ajout de classe au div generes ci-dessus pour la mise en forme du div.infosynthese //
	    $( ".part-a div" ).addClass( function(index){
	        return "synthese_ligne-" + (index+1);
	    });

			// Suppression du div contenant la chaine de caractere euro //
			$( ".part-a:first div:contains('euros')" ).remove();

			// Ajout du caractere € a la fin du solde de compte //
	    $('.part-a:first strong').each(function(){
	        var ele = $(this);
	        var str = ele.replaceWith('<div class="synthese_solde">' + ele.text() + '<sup> &euro;</sup></div>');
	        return (str);
	    });
	    $( ".part-a:first .soldeur + div:contains('francs')" ).css( "display", "inline").appendTo('.soldeur');
	};
	// ---- fin Mise en forme des pages de synthese ( releve_ccp.html, releve_cne.html)  ---- //


	// Suppression des pictos sur les boutons d'actions //
	$("ul.liens span img").remove();


// *********************************************************  fin des fonctions reskin ********************************************************* //


		if(navigator.userAgent.match(/MSIE/i) != null)
			{ $("html").addClass("ie"); }
		
		// Gestion largeur de div contenant input radio puis label //
		var checkbox = $("li.checkbox");
		for (var i= 0; i <= checkbox.length; i++){
			var currentChk = $(checkbox[i]),
				inputInDiv = $(checkbox[i]).find('input');

			if ((currentChk.find("input").attr('type') === 'radio') && (inputInDiv.siblings().length === 0)){
				$(currentChk).find('div').eq(0).css('width','3%');
				$(currentChk).find('div').eq(1).css('width','90%');
			};
		}

// ################# Désactivation 25 Avril 2016 ################ //

		// **** Gestion largeur de div contenant input radio puis label **** //

		// $.fn.fixColHeight();
		// $('.equalize').fixColHeight();

		// **** seulement si l'element dl n'a PAS la classe "no-height-fix" **** //

		// $('#main dl').not('.no-height-fix').fixColHeight();
		// $('.formline').fixColHeight();
		// $('.delColheight').each(function(){
		// 	$(this).children("div").css("min-height","1em");
		// });

// ########################################################################################## //

		radioNoSelectedbis();
		checkChoice();



		$('.tablesorter').tablesorter({textExtraction: "complex",dateFormat: 'uk', headers: {0: {sorter: "shortDate"}}});

		$(".tablesorter thead th a").click(function() {
			$(this).parent().click();
			return false; // a remplacer par des event.preventDefault()
		});

		try {
			/*$('.date_picker').datePicker().val($('.date_picker').val()).trigger('change');*/
			$.dpText = {
					TEXT_PREV_YEAR		:	'Ann�e pr�c�dente',
					TEXT_PREV_MONTH		:	'Mois pr�c�dent',
					TEXT_NEXT_YEAR		:	'Ann�e suivante',
					TEXT_NEXT_MONTH		:	'Mois suivant',
					TEXT_CLOSE			:	'Fermer',
					TEXT_CHOOSE_DATE	:	'Choisir une date'
			}
			var vDatePicker = $('.date_picker').datePicker();
			if (vDatePicker.length > 0) {
				vDatePicker.val().trigger('change');
			}
		}
		catch( error ) {}

		var noWebKitOpenPopinFunc = function(urlPopin, titlePopin) {
			try { top.openPopinWithLink(urlPopin, titlePopin); }
			catch(e) {
				try { window.openPopinWithLink(urlPopin, titlePopin); }
				catch(ex) {
					try { openPopinWithLink(urlPopin, titlePopin); } catch(exx) { if (console) { console.log('unable to open popin'); } }
				}
			}
		}

		var noWebKitOpenPopinFuncNoCross = function(urlPopin, titlePopin) {
			try { top.openPopinWithLinkNoCross(urlPopin, titlePopin); }
			catch(e) {
				try { window.openPopinWithLinkNoCross(urlPopin, titlePopin); }
				catch(ex) {
					try { openPopinWithLinkNoCross(urlPopin, titlePopin); } catch(exx) { if (console) { console.log('unable to open popin'); } }
				}
			}
		}

		$(".popin").live('click', function(e) {
			e.preventDefault();
			var cBrowser = checkBrower();
			var urlPopin = $(this).attr("hrefPopin");
			var titlePopin = "";
			
			if (!urlPopin) { urlPopin = $(this).attr("href"); }
			if (!urlPopin) { urlPopin = $(this).parent().attr("href"); }
			if (!urlPopin) { urlPopin = $(this).parent().parent().attr("href"); }

			if(urlPopin){ $(this).attr("hrefPopin", urlPopin); $(this).attr("href", "#"); }

			if(cBrowser != 'webkit'){
				noWebKitOpenPopinFunc(urlPopin,titlePopin);
			}else {
				openPopinWithLink(urlPopin,titlePopin);
			}

			return false; // a remplacer par des event.preventDefault()
		});

		$(".popinText").live('click', function(e) {
			e.preventDefault();
			var cBrowser = checkBrower();
			var txtPopin = $(this).find(".insideText").html();
			var titlePopin = "";

			openPopinNoFrame(txtPopin,titlePopin);

			return false; // a remplacer par des event.preventDefault()
		});


		$(".popinNoCross").live('click', function(e) {
			e.preventDefault();
			var cBrowser = checkBrower();
			var urlPopin = $(this).attr("hrefPopin");
			var titlePopin = "";
			
			if (!urlPopin) { urlPopin = $(this).attr("href"); }
			if (!urlPopin) { urlPopin = $(this).parent().attr("href"); }
			if (!urlPopin) { urlPopin = $(this).parent().parent().attr("href"); }

			if(urlPopin){ $(this).attr("hrefPopin", urlPopin); $(this).attr("href", "#"); }

			if(cBrowser != 'webkit'){
				noWebKitOpenPopinFuncNoCross(urlPopin,titlePopin);
			}else {
				openPopinWithLinkNoCross(urlPopin,titlePopin);
			}

			return false; // a remplacer par des event.preventDefault()
		});

		$(".popin1").click(function(e) {
			e.preventDefault();
			var cBrowser = checkBrower();
			var urlPopin = $(this).attr("hrefPopin");
			var titlePopin = "";

			if (!urlPopin) { urlPopin = $(this).attr("href"); }
			if (!urlPopin) { urlPopin = $(this).parent().attr("href"); }
			if (!urlPopin) { urlPopin = $(this).parent().parent().attr("href"); }

			if(urlPopin){ $(this).attr("hrefPopin", urlPopin); $(this).attr("href", "#"); }

			if(cBrowser != 'webkit'){
				noWebKitOpenPopinFunc(urlPopin,titlePopin);
			}else {
				openPopinWithLink(urlPopin,titlePopin);
			}

			return false; // a remplacer par des event.preventDefault()
		});

        $(".popin a").live('click', function(e) {
			e.preventDefault();
			var cBrowser = checkBrower();
			var urlPopin = $(this).attr("hrefPopin");
			var titlePopin = "";
			
			if (!urlPopin) { urlPopin = $(this).attr("href"); }
			if(urlPopin){ $(this).attr("hrefPopin", urlPopin); $(this).attr("href", "#"); }

			if(cBrowser != 'webkit'){
				noWebKitOpenPopinFunc(urlPopin,titlePopin);
			}else {
				openPopinWithLink(urlPopin,titlePopin);
			}
			return false; // a remplacer par des event.preventDefault()
		});

		$(".popinWithReloadOnClose").click(function() {
			openPopinWithReloadOnClose($(this).attr("href"),$(this).html());
			return false; // a remplacer par des event.preventDefault()
		});

		$(".popinDeconnexion").click(function() {
			var urlPopin = $(this).attr("hrefPopin");
			if (!urlPopin) { urlPopin = $(this).attr("href"); }
			if (!urlPopin) { urlPopin = $(this).parent().attr("href"); }
			if (!urlPopin) { urlPopin = $(this).parent().parent().attr("href"); }

			if(urlPopin){ $(this).attr("hrefPopin", urlPopin); $(this).attr("href", "#"); }

			openPopinDeconnexion(urlPopin,$(this).html());
			return false; // a remplacer par des event.preventDefault()
		});

		$(".help").click(function() {
			var paramUrl = $(this).attr("href");
			var paramAlt = $(this).find("img").eq(0).attr("alt");
			var cBrowser = checkBrower();

			//openPopin($(this).attr("href"),$(this).html());
			if($(this).hasClass('helpIframe') && cBrowser != 'webkit'){
				noWebKitOpenPopinFunc(paramUrl,paramAlt);
			}
			else if(cBrowser == 'webkit') {
				openPopinWithLink(paramUrl,paramAlt);
			}else {
				openPopinWithLink(paramUrl,paramAlt);
			}
			return false; // a remplacer par des event.preventDefault()
		});
		$("a.helper").click(function() {
			openPopinWithLink($(this).attr("href"),$(this).find("img").eq(0).attr("alt"));
			return false; // a remplacer par des event.preventDefault()
		});

		/*gestion des styles selon les navigateurs*/
		/*firefox 2.0*/
		jQuery.each(jQuery.browser, function(i, val) {
			if(i=="mozilla" && jQuery.browser.version.substr(0,3)=="1.8")
			{
				$("legend").css('display','none');
				$("#main  ul.liens li").css('float','left');
				$("#main ul.actions li").css('float','left');
				$("#main ul.actions li.btnlk").css('width','70px');
				$("#main ul.actions li.btnlk").css('margin-top','-13px');
				$("#main  ul.liens").css('clear','both');
			}
		});

		/* gestionRelevesPDF */
		$('.conditionnalDisplay').css('display', 'none')
		$('input[type=radio]').change( function()
		{
			if( $(this).val() == 'ligne')
			{
				$(this).parent().parent().parent().children('.conditionnalDisplay').css('display','block');
			}
			else
			{
				$(this).parent().parent().parent().children('.conditionnalDisplay').css('display','none');
			}
		});

		/* gestion du double date_picker */

		if( !$("#DateChoix1").is(':checked') ) {
			$('#jusqueDateVirement').siblings('.dp-choose-date').eq(0).hide();
			$('#jusqueDateVirement').attr('disabled', 'disabled');
		}

		$("#DateChoix1").click(function () {
			$('#jusqueDateVirement').removeAttr('disabled');
			$('#jusqueDateVirement').siblings('.dp-choose-date').eq(0).show();
		});

		$("#DateChoix2").click(function () {
			$('#jusqueDateVirement').attr('disabled', 'disabled');
			$('#jusqueDateVirement').siblings('.dp-choose-date').eq(0).hide();
		});
		// if( !$("#DateChoix1").is(':checked') ) {
			// $('#jusqueDateVirement').siblings('.dp-choose-date').eq(0).addClass('dp-disabled');
		// }

		// $("#DateChoix1").click(function () {
			// $('#jusqueDateVirement').removeAttr('disabled');
			// $('#jusqueDateVirement').siblings('.dp-choose-date').eq(0).removeClass('dp-disabled');
		// });

		// $("#DateChoix2").click(function () {
			// $('#jusqueDateVirement').attr('disabled', 'disabled');
			// $('#jusqueDateVirement').siblings('.dp-choose-date').eq(0).addClass('dp-disabled');
		// });

		$("#aSupport").change(function(){
			supportChoice($(this));
		});
		$(".repartchoice input").click(function(){
			$("input.repartinput").each(function(){
				if($(this).is(':disabled')){
					$(this).attr("disabled", false);
				}else{
					$(this).attr("disabled", true);
				}
			});
		});
		/**demande 2621**/
		/***gestion des champs disabled***/
			var checkRepart1 = ".repartchoice1",
				checkRepart2 = ".repartchoice2",
				allButton = $('a strong');
			if ($(checkRepart1 || checkRepart2).length > 0){


			allButton.each(function() {
				//console.log( index + ": " + $( this ).text() );
				if( $(this).html() === 'Supprimer' ){

					$(this).addClass('delete')
					$(this).closest('tr').addClass('disabled');

					$(this).closest('tr').find('input.repartinput1').attr('disabled', 'disabled');
					$(this).closest('tr').find('input.repartinput2').attr('disabled', 'disabled');
				}
				else{allButton.parents('tr').find('input.repartinput1').attr('enabled', 'enabled');
					allButton.parents('tr').find('input.repartinput2').attr('enabled', 'enabled');}
			});

		}

		$(".repartchoice1 input").click(function(){
			$("input.repartinput1").each(function(){
				if($(this).is(':disabled')){
					$(this).attr("disabled", false);
					$("input.repartinput2").attr("disabled", true);
				}
			});
			if ($(checkRepart1).length > 0){


				allButton.each(function() {
					//console.log( index + ": " + $( this ).text() );
					if( $(this).html() === 'Supprimer' ){

						$(this).addClass('delete')
						$(this).closest('tr').addClass('disabled');

						$(this).closest('tr').find('input.repartinput1').attr('disabled', 'disabled');

					}
					else{
						allButton.parents('tr').find('input.repartinput1').attr('enabled', 'enabled');
					}
				});

			}
		});

		$(".repartchoice2 input").click(function(){
			$("input.repartinput2 ").each(function(){
				if($(this).is(':disabled')){
					$(this).attr("disabled", false);
					$("input.repartinput1").attr("disabled", true);
				}
			});
			if ($(checkRepart2).length > 0){


			allButton.each(function() {
				//console.log( index + ": " + $( this ).text() );
				if( $(this).html() === 'Supprimer' ){

					$(this).addClass('delete')
					$(this).closest('tr').addClass('disabled');

					$(this).closest('tr').find('input.repartinput2').attr('disabled', 'disabled');
				}
				else{allButton.parents('tr').find('input.repartinput2').attr('enabled', 'enabled');}
			});

		}
		});


		/*$('.selAQ #typeRel').change(function(){
			var optPeriod = $(".selAQ #period option").eq(0);
			if($(this).val() === "ligne"){
				$("#period").attr('disabled', 'disabled');
				optPeriod.prop('selected', true);
			}
			else
			{
				$("#period").removeAttr('disabled');
			}
		});*/
		$(".ss_investissement #formID_18_1").click(function(){
				$("#formID_19_1").removeAttr('disabled');
				$("#formID_19_2").removeAttr('disabled');
				$("#formID_19_3").removeAttr('disabled');
		});
		$(".ss_investissement #formID_18_2").click(function(){
				$("#formID_19_1").attr('disabled','disabled');
				$("#formID_19_1").attr('checked', false);
				$("#formID_19_2").attr('disabled','disabled');
				$("#formID_19_2").attr('checked', false);
				$("#formID_19_3").attr('disabled','disabled');
				$("#formID_19_3").attr('checked', false);
		});

		$(".AccordionCheckBox .accoCheck").each(function(){
			if($(this).is(':checked')){
				$(this).parent().find(".creditCards").addClass("selected");
			}
		});

		$(window).resize(function() {

			getAccesAssur()
		});

		if($("#servicePMSCYes").attr("checked")){
			$("#PMSCtoggle").show();
		}else{
			$("#PMSCtoggle").hide();
		}

		$("#servicePMSCYes").click(function(){
			if($(this).attr("checked")){
				$("#PMSCtoggle").show();
			}
		});
		$("#servicePMSCNo").click(function(){
			if($(this).attr("checked")){
				$("#PMSCtoggle").hide();
			}
		});

		if($("#PSMCnumSelect").val()=="otherNum"){
			$("#otherNum").show();
		}else{
			$("#otherNum").hide();
		}

		$("#PSMCnumSelect").click(function(){
			if($(this).val()=="otherNum"){
				$("#otherNum").show();
			}else{
				$("#otherNum").hide();
			}
		});



		/**** A2G ****/
		$(".checkboxlink a").click(function(){
			if($(this).parents(".checkboxlink").find("#accepte").is(':checked')){
				return true;
			}else{
				alert($(this).parents(".checkboxlink").find(".texteAlert").html());
				return false;
			}
		});

		$(".a2gformModify").click(function(){
			$('.a2gform #address').attr('disabled','');
			return false;
		});

		$(".smallPopin").click(function(e){
			if(!e) e = window.event;
			e.preventDefault();
			var deviceLine = $(this).parents("tr");

			$.ajax({
				url:$(this).attr("href"),
				type:'GET',
				success: function(data){
					var popinContent = $(data).find('.ajaxPopin').html();
					openSmallPopin(popinContent, deviceLine);
				},
				error : function (err) {
					console.log(err);
				}
			});

			return false;
		});

		$(".medPopin").click(function(e){
			if(!e) e = window.event;
			e.preventDefault();

			$.ajax({
				url:$(this).attr("href"),
				type:'GET',
				success: function(data){
					var popinContent = $(data).find('.ajaxPopin').html();
					openMedPopin(popinContent);
				},
				error : function (err) {
					console.log(err);
				}
			});

			return false;
		});

		$("input[name=defaultDevice]:radio").change(function(e){
			if(!e) e = window.event;
			e.preventDefault();

			$.ajax({
				url:$(this).attr("href"),
				type:'GET',
				success: function(data){
					var defaultContent = $(data).find('.ajaxPopin').html();
					openSmallPopin(defaultContent, null);
				},
				error : function (err) {
					console.log(err);
				}
			});

			return false;
		});

		$(".a2gTab tbody tr a").hover(function (){ $(this).parents(".a2gTab tr").addClass("hover"); });
		$(".a2gTab tbody tr a").focus(function (){ $(this).parents(".a2gTab tr").addClass("hover"); });
		$(".a2gTab tbody tr a").blur(function (){ $(this).parents(".a2gTab tr").removeClass("hover"); });
		$(".a2gTab tbody tr a").mouseleave(function (){ $(this).parents(".a2gTab tr").removeClass("hover"); });

		$(".a2gTab tbody tr a").click(function(){
			var operationLine = $(this).parents("tr");

			$(this).parents(".a2gTab tr").addClass("current");

			$.ajax({
				url:$(this).attr("href"),
				type:'GET',
				success: function(data){
					var operationContent = $(data).find('.ajaxPopin').html();
					openSmallPopin(operationContent, operationLine);
				}
			});

			return false;
		});

		/**** A2G ****/





		MPIbanque();
		getinfobulle();
		getHelp(pathRessourcesImg);
		displayPrimaryNav();

		getAccordions();
		otherNumSelect();
		finaliseChoice();
		radioNoSelected();
		selectSynchro();
		getSlider();
		getInputSlider();
		choixArbitrage();
		releve();
		idemAdresse();
		toggleInputSitImmoStatus();
		getSelectedTextOption();
		activateImmoStatus();
		activateSubscriptionButton();
		openPopinBlockEdito();
		activateLine();
		HBTotalInput();
		getAccesAssur()
	}
);

function activateSubscriptionButton() {
	var link = $('.actions .jscontrol');
	var datepickerInput = $('.validateContent').find('#dateSignature');
	var signatureCheckbox = $('.validateContent').find('#hasRecieveSignature');
	link.addClass('disabled');

	signatureCheckbox.click(function (){
		if ($(this).attr('checked') && datepickerInput.val().length != 0) { link.removeClass('disabled');
		} else { link.addClass('disabled'); }
	});
	datepickerInput.change(function(){
		if ($(this).val().length == 0){ link.addClass('disabled');
		} else if (signatureCheckbox.attr('checked') && $(this).val().length != 0) { link.removeClass('disabled'); }
	});
}

function checkBrower() {
	var agent = "";
	if($.browser.webkit) agent = 'webkit';
	return agent;
}

function ouvrirPopup(Link) {
	window.open(Link,'popup','menubar=no,scrollbars,toolbar=no,location=no,directories=no,status=yes,RESIZABLE=YES,width=650,height=600');
	return false;
	}

function getAccordions(){

	$(".AccordionCheckBox .accoCheck").click(function(){
		$(this).parent().find(".affichercontenu a.lire").click();
	});

	$(".AccordionCheckBox #ECarteBleue").parent().find(".affichercontenu #ecarteoui").click(function(e) {
		$(".actions .nextBtn").removeClass("inactif");
	});

	$(".AccordionCheckBox #ECarteBleue").parent().find(".affichercontenu #ecartenon").click(function(e) {
		$(".actions .nextBtn").addClass("inactif");
	});

	$(".affichercontenu a.lire").click(function(e) {
		if ($(this).parents().eq(2).hasClass('selected')){
			$(this).parents().eq(2).removeClass('selected');
			$(this).parents().eq(2).parent().find(".accoCheck").attr("checked",false);
		}else{
			$(this).parents().eq(2).addClass('selected');
			$(this).parents().eq(2).parent().find(".accoCheck").attr("checked",true);
		}

		var togglenext = false;
		if($(".AccordionCheckBox #Alliatys").parent().find(".affichercontenu").hasClass("selected")){ togglenext = true; }
		if($(".AccordionCheckBox #ECarteBleue").parent().find(".affichercontenu").hasClass("selected")){ if($(".AccordionCheckBox #ECarteBleue").parent().find(".affichercontenu #ecarteoui").attr("checked")){ togglenext = true; }}
		if($(".AccordionCheckBox #PaiementMobile").parent().find(".affichercontenu").hasClass("selected")){ togglenext = true; }

		if(togglenext){ $(".actions .nextBtn").removeClass("inactif"); }
		else{ $(".actions .nextBtn").addClass("inactif"); }
		
		//Permet de ne pas recharger toute la page d'accueil lors du d�pliement d'un bloc si pas besoin d'appel au serveur
		if($(this).attr('href') == "#"){
			event.preventDefault();
		}
	});

	$(".affichercontenu a.liretitle").click(function() {
		if ($(this).parents().eq(3).hasClass('selected')){
			$(this).parents().eq(3).removeClass('selected');
			$(this).parents().eq(2).parent().find(".accoCheck").attr("checked",false);
		}else{
			$(this).parents().eq(3).addClass('selected');
			$(this).parents().eq(2).parent().find(".accoCheck").attr("checked",true);
		}
	});
}


function getinfobulle() {
	$("#main span.altbulle").mouseover(function(){
		if($(this).children("img").attr("alt") !="")
		{
			$(this).children("strong").html($(this).children("img").attr("alt"));
			$(this).children("img").attr("alt","");
		}
		if($(this).children("strong").html().length > 1)
		{
			$(this).children("strong").addClass("selected");
		}
	});
	$("#main span.altbulle").mouseout(function(){
		$(this).children("strong").removeClass("selected");
	});
	$("#main span.altbulle").parent().focus(function(){
		if($(this).children("img").attr("alt") !="")
		{
			$(this).children("span").children("strong").html($(this).children("span").children("img").attr("alt"));
			$(this).children("img").attr("alt","");
		}
		if($(this).children("span").children("strong").html().length > 1)
		{
			$(this).children("span").children("strong").addClass("selected");
		}
	});
	$("#main span.altbulle").parent().blur(function(){
		$(this).children("span").children("strong").removeClass("selected");
	});
}

function getHelp(pathRessourcesImg) {
	$('a.helper ').each(function(){
			var myAlt = $(this).children("span.webaccess").text();
			$(this).children("span.webaccess").replaceWith("<img src='"+pathRessourcesImg+"intr_petit.png' alt='"+myAlt+"' class='imghelper' />");
			$(this).addClass('img');
			$(this).attr('title', myAlt);
		});

	$('a.help ').each(function(){
		var myAlt = $(this).children("span.webaccess").text();
		$(this).children("span.webaccess").replaceWith("<img src='"+pathRessourcesImg+"intr_petit.png' alt='"+myAlt+"' class='imghelper' />");
		$(this).addClass('img');
	});
}

function finaliseChoice() {
	$(".finaliseChoice").change( function() {
		if ($(this).attr("id")=="plus_tard") {
			$(".dateCondition").addClass('selected');
		} else {
			$(".dateCondition").removeClass('selected');
		}
	});
}

function otherNumSelect() {
 $(".selectChange").change( function() {
		if($(this).children("option:selected").attr("value")=="autrenum") {
			$("#nouveau_numero").addClass('selected');
		} else {
			$("#nouveau_numero").removeClass('selected');
		}
	});
}


function radioNoSelected(){
	$(".radioNoSelected").click(function() {
		if ($(this).attr("id")=="versnon") {
			$(".noselected").css("display","none");
		}else {
			$(".noselected").css("display","block");
		}
	});
}

function radioNoSelectedbis() {
	$(".radioNoSelectedbis").click(function() {
		if ($(this).attr("id")=="versnonbis") {
			$(".noselectedbis").css("display","none");
		} else {
			$(".noselectedbis").css("display","block");
		}
	});
}

function getSelectedTextOption() {
	$('.targetText').hide();
	$(".selectList").change(function() {
		if ($(this).val() == 0){
			$('.targetText').hide();
		} else {
			$('.targetText').show();
		}
		var valText = $('.selectList').val();
		$('#dynamicContent').html(valText);
	});
}

function selectSynchro(){
$(".refSelect").change(function(){
	$(".copySelect").val($(".refSelect").val());
});
}


function displayPrimaryNav() {
	$("#middleContent li").mouseover(function(){
		$(this).addClass("current");
	});
	$("#middleContent li").mouseleave(function(){
		$(this).removeClass("current");
	});
	$("#middleContent li a").focus(function(){
		if($(this).hasClass('title')){
			$(this).parent().addClass("current");
		}
		else{
		$(this).parent().parents("li").addClass("current");
		}
		});
	$("#middleContent li a").blur(function(){
		if($(this).hasClass('title')){
			$(this).parent().removeClass("current");
		}
		else{
		$(this).parent().parents("li").removeClass("current");
		}
	});
}

function hasId(id){
    if($(id).length > 0){
      return true;
    }
    return false;
}

function getActualvalue(value) {
	var mynumber = $("#"+value+" span").html();
		mynumber = $.trim(mynumber);
		mynumber = mynumber.replace("&nbsp;","");
	return (getANumber(mynumber));
}

function getANumber(number) {

	number = ""+number+"";

	number = number.replace(" ","");
	number = number.replace(",",".");
	number = number.replace("+","");
	number = number.replace("-","");

	if (number == "" || isNaN(number)){
		number = 0;
	}

	return parseFloat(number);
}

function setHtmlNumber(number){
	number=""+number+"";

	if(number.indexOf(".")>-1){
		number = number.replace(".",",");
	}else{
		number = number+",00";
	}

	if(number!="0,00") {
		if(hasId("#desinvest") && number.indexOf('-')==-1) { number = "-"+number; }
	}

	return number;
}


function arrondi2Decimales ( nombre, precision){
	var coef = Math.pow(10, precision);
	nombre = Math.round(nombre*coef) / coef;
	nombre = nombre.toString();
	var index = nombre.indexOf('.');
	if ( (index != -1) && ((nombre.substring(index+1)).length<2) ){
		nombre = nombre + "0";
	}

	return nombre;
}
//gestion de la hauteur des boutons d'accès de Hermès Bompard
function getAccesAssur(){

	var heights = [];
	 $('.accesAssur li strong').each(function(){ heights.push( $(this).height()); });
	 var max_height = Math.max.apply(null, heights);
	 $('.accesAssur li').css( {'height': max_height+'px'} );
}

/*
getSlider()

ID : myId  = Identifiant du slider
ID : myId+"value"  = Id > span : valeur de base du calcul
ID : myId+"target = champs dans lequel la valeur calcul\351e sera envoy\351e
ID : myId+"label = Label du slider

*/
/*
getSlider()

ID : idSlider  = Identifiant du slider
ID : idSlider+"value"  = Id > span : valeur de base du calcul
ID : idSlider+"target = champs dans lequel la valeur calcul\351e sera envoy\351e
ID : idSlider+"label = Label du slider

*/

function onSlideFunction(slider, event, ui, slideEvent) {
	var idSlider = slider.id;
	var sliderValue = ui.value;
	var oldValue = document.getElementById(idSlider+"target").value;

	if(slideEvent == true) {
		//A chaque fois qu'on entre un montant, on passe par ici
		var isModeReinvestissement = document.getElementById('totalRestantHidden') ? true : false;
		var valeurReferente = 0;
		if (isModeReinvestissement) {
			//En r\351investissement, la valeur r\351f\351rente est le montant de l'arbitrage libre
			valeurReferente = getANumber(document.getElementById('totalRestantHidden').value);
		}
		else {
			//En d\351sinvestissement, la valeur r\351f\351rente est le montant du support
			valeurReferente = getActualvalue(idSlider+"value");
		}

		var valeurChampMontantAssocie = (valeurReferente * getANumber(sliderValue)) / 100;
			valeurChampMontantAssocie = format(valeurChampMontantAssocie, 2, " ");
			valeurChampMontantAssocie = setHtmlNumber(valeurChampMontantAssocie);

		document.getElementById(idSlider+"target").value = valeurChampMontantAssocie;
	}

	var validateResult = validateSliderValue(idSlider, true);

	//Fin - Valorisation du champ montant associ\351 au slider

	if(validateResult[1]) {
		//D\351but - Valorisation du l'infobulle associ\351e au slider
		$(slider).find("div.ui-slider-range").attr("aria-labelledby",idSlider+"label")
										   .attr("aria-valuenow",sliderValue)
										   .attr("aria-valuetext",+"%");

		if($(slider).find("span.absslider").css('display')=='none') {
			$(slider).find("span.absslider").css('display', 'block');
		}
		$(slider).find("span.absslider").html(sliderValue + " %").css('left', sliderValue+'%');

		var labelvalue = $(slider).find("strong.absslider.webaccess").html();
		$(slider).find("span strong.absslider").replaceWith("<label for='abs"+idSlider+"' class='webaccess'>"+(labelvalue)+"</label>");
		//Fin - Valorisation du l'infobulle associ\351e au slider
	}

	if(validateResult[1] == false && slideEvent == true) {
		document.getElementById(idSlider+"target").value = oldValue;
	}

	//D\351but - Valorisation des Totaux bruts
	valoriserTotaux(validateResult[0]);
	//Fin - Valorisation des Totaux bruts

	return validateResult[1];
}

function defineSlider(id, range, value, min, max) {
	$(id).slider({
		range: range,
		value: value,
		min: min,
		max: max,
		create: function(event, ui) {
				$(this).append("<span class='absslider' id='abs" + $(this).attr("id") + "' style='display:none;'>0 %</span>");
			},
		change: function(event, ui) {
				if (!event.originalEvent) {
					onSlideFunction(this, event, ui, false);
				}
			},
		slide: function(event, ui) {
				return onSlideFunction(this, event, ui, true);
			}
	});
}

function getSlider() //LBP
{
	defineSlider(".slider", "min", 0, 0, 100);
}

function validateSliderValue(idChampMontant, slideEvent, valueChampMontant) {
	//A chaque fois qu'on entre un montant, on passe par ici
	var isModeReinvestissement = document.getElementById('totalRestantHidden') ? true : false;

	var valeurReferente = 0;
	//Verification que la saisie de depasse pas le reste \340 investir
	var isSaisieInferieurRAI;

	if (isModeReinvestissement) {
		//En r\351investissement, la valeur r\351f\351rente est le montant de l'arbitrage libre
		valeurReferente = getANumber(document.getElementById('totalRestantHidden').value);

		//RG - reinvestissement
		var sommeChamps = 0;
		$(".champMontant").each(function(){
			if ($(this).attr('value') =="" || $(this).attr('value') =="-"){
				var valueSupport = 0;
			}else{
				var valueSupport = getANumber($(this).attr('value'));
			}
			sommeChamps = sommeChamps + valueSupport;
		});
		var totalRestantHiddenValue = getANumber(document.getElementById('totalRestantHidden').value);
//		isSaisieInferieurRAI = (totalRestantHiddenValue >= sommeChamps) ? true : false;
		isSaisieInferieurRAI = (totalRestantHiddenValue < sommeChamps - 1) ? false : true;
		if (!isSaisieInferieurRAI) {
			if(!slideEvent) { alert("Le montant saisi d\351passe le reste \340 r\351investir"); }
			valueChampMontant = 0;
		}
	}
	else {
		//En d\351sinvestissement, la valeur r\351f\351rente est le montant du support
		valeurReferente = getActualvalue(idChampMontant+"value");

		//RG - desinvestissement
		//Verification que le desinvestissement ne d\351passe pas le montant du support
		if (typeof valueChampMontant != 'undefined' && valueChampMontant > valeurReferente) {
			alert("Le d\351sinvestissement d\351passe le montant disponible sur le support");
			valueChampMontant = valeurReferente;
		}

		//Dans le cas du desinvestissement, c'est toujours vrai
		isSaisieInferieurRAI = true;
	}

	return new Array(isModeReinvestissement, isSaisieInferieurRAI, valeurReferente, valueChampMontant);
}

function getInputSlider() {
	//On d\351finit les actions associ\351es aux champs montant - lot 2
	$(".champMontant").blur(function(){
		var idChampMontant = this.id;
		idChampMontant = idChampMontant.replace("target","");
		var valueChampMontant = getANumber(this.value);

		validateResult = validateSliderValue(idChampMontant, false, valueChampMontant);
		valueChampMontant = validateResult[3];
		valueChampMontant = getANumber(valueChampMontant);
		valueChampMontant = format(valueChampMontant, 2, " ");
		valueChampMontant = setHtmlNumber(valueChampMontant);

		var valeurReferente = validateResult[2];
		var champRatioHidden = document.getElementById(idChampMontant + "tauxRepartition");
		var champMontantHidden = document.getElementById(idChampMontant + "montant");
		var infoBulleSlider = document.getElementById("abs" + idChampMontant );
		var champMontant = document.getElementById( idChampMontant + "target" );

		if(champMontant!=null) { champMontant.value = valueChampMontant; }

		var valueChampMontantHidden = getANumber(valueChampMontant);

		if (champMontantHidden != null) {
			champMontantHidden.value = valueChampMontantHidden;
		}

		var valueRatio = (valueChampMontantHidden / valeurReferente * 100);
		valueRatio = format(valueRatio, 2, "");
		if (champRatioHidden != null) {
			champRatioHidden.value = valueRatio;
		}

		$("#"+idChampMontant).slider('value', valueRatio);
		$(infoBulleSlider).text(Math.round(valueRatio) + " %");

		// On teste dans le cas d'un support UC le desinvestissement total
		traitementSupportUC(idChampMontant, valueChampMontant, valeurReferente);

		if (!validateResult[1]) {
			reinitValorisation(idChampMontant);
		}

		valoriserTotaux(validateResult[0]);
	});
}

function choixArbitrage(){
	$("#arbitrage #target #formule div.formline input[type=radio]").click(function()
	{
		if ($("#target").hasClass("selected"))
		{
			$("#target").removeClass();
		}
		$("#target").addClass("selected");
		$("#target").addClass($(this).attr("id"));
	});
}

function releve(){
	$("#main input[type=radio].enligne").click
	(function(){
		$("#main input[type=radio].enligne").attr('checked', 'checked');
		$("#main input[type=radio].courrier").removeAttr('checked', 'checked');
		$("#main select.periode").removeAttr('disabled', 'disabled');
	});
	$("#main input[type=radio].courrier").click
	(function(){
		$("#main input[type=radio].courrier").attr('checked', 'checked');
		$("#main input[type=radio].enligne").removeAttr('checked', 'checked');
		$("#main select.periode").attr('disabled', 'disabled');
	});
}

function MPIbanque(){
		/*$('select.choixBanque').change( function(){
			$('div.choixBanque').css('display','block');
			$(this).attr('disabled','disabled');
		});*/
}

function idemAdresse(){
	$('input.idemAdresse').click( function()
	{
		if ($('div.idemAdresse').css('display')=="block")
		{
		$('div.idemAdresse').css('display','none');
		}
		else{
		$('div.idemAdresse').css('display','block')
		}
	});
}
/****CIFO****/
function toggleInputSitImmoStatus() {
    $("input.toggleElement").click(function() {
		if ($(this).attr("checked")) {
			$(this).parents("div."+$(this).attr("class")).find("input:radio").attr("disabled", true);
			$(this).parents("div."+$(this).attr("class")).find("input:radio, input:checkbox").not($(this)).attr("disabled", true).removeAttr('checked');
		} else {
			$(this).parents("div."+$(this).attr("class")).find("input:checkbox").not($(this)).removeAttr('disabled');
			if ($("input#pro").length == 0) {
				$(this).parents("div."+$(this).attr("class")).find("input:radio").not($(this)).removeAttr('disabled');
			}
		}
    });
}

function activateImmoStatus(){
    $("input#pro").click(function() {
        if ($(this).attr("checked")) {
			$(this).parents("div.toggleElement").find("input:radio").attr("disabled", false);
        }else {

            $(this).parents("div.toggleElement").find("input:radio").attr("disabled", "disabled").removeAttr('checked');
        }
    });
};


/* ------------------------------------------*/
/* Partie sp\351ciale pour Arbitrage Libre - AJOUT SQLI  24102011*/
/* ------------------------------------------*/
function reinitValorisation(idChampMontant){

	var champRatioHidden = document.getElementById(idChampMontant + "tauxRepartition");
	var champMontantHidden = document.getElementById(idChampMontant + "montant");
	var infoBulleSlider = document.getElementById("abs" + idChampMontant );
	var champMontant = document.getElementById( idChampMontant + "target" );

	$("#"+idChampMontant).slider({
		value: 0
	});

	if (champMontantHidden != null) { champMontantHidden.value = 0; }
	if (champRatioHidden != null) { champRatioHidden.value = 0; }
	if (infoBulleSlider != null) { infoBulleSlider.value = "0 %"; }
	if (champMontant != null) { champMontant.value = "0,00"; }
}

function traitementSupportUC(idChampMontant,valueChampMontant,valeurReferente){

	var sliderUCOuEuro = document.getElementById( idChampMontant + "estEuro");

	if (sliderUCOuEuro && sliderUCOuEuro.value == "uc") {

		if (getANumber(valueChampMontant) == valeurReferente) {

			if ( confirm("Veuillez confirmer le d\351sinvestissement total de votre support UC") == false ) {

				reinitValorisation(idChampMontant);
			}
		}
	}
}

/**
* Permet de formater un nombre

* @param Number valeur La valeur a formater
* @param Number decimal Le nombre de d\351cimales du nombre a afficher
* @param Number separateur le s\351parateur de millier pour le nombre a afficher
* @return String le nombre formater
*/
function format(valeur, decimal, separateur) {

	valeur = parseFloat(valeur);
	var deci=Math.round( Math.pow(10,decimal)*(Math.abs(valeur)-Math.floor(Math.abs(valeur)))) ;
	var val=Math.floor(Math.abs(valeur));

	if ( (decimal==0) || (deci==Math.pow(10,decimal)) ) {
		if(deci == Math.pow(10,decimal)) {
			val=Math.floor(Math.abs(valeur)) + 1;
		}
		deci=0;
	}
	var val_format=val+"";
	var nb=val_format.length;

	for (var i=1;i<4;i++) {
		if (val>=Math.pow(10,(3*i))) {
			val_format=val_format.substring(0,nb-(3*i))+separateur+val_format.substring(nb-(3*i));
		}
	}
	if (decimal>0) {
		var decim="";
		for (var j=0;j<(decimal-deci.toString().length);j++) {decim+="0";}
		deci=decim+deci.toString();
		val_format=val_format+"."+deci;
	}

	if (parseFloat(valeur)< 0) {
		val_format="-"+val_format;
	}

	return val_format;
}

function valoriserTotaux(isModeReinvestissement){

	//Pour l\340, on calcule la somme des montants des supports
	var montantTotalBrut = 0;

	$(".champMontant").each(function(i){
		var montantTemporaire = montantTotalBrut + getANumber($(this).attr('value'));
		montantTotalBrut = getANumber(montantTemporaire);
	});

	montantTotalBrut = getANumber(montantTotalBrut);
	montantTotalBrut = format(montantTotalBrut,2," ");
	montantTotalBrut = setHtmlNumber(montantTotalBrut);

	$("#totalTarget span").text(montantTotalBrut);

	// Si on est en r\351inv on valorise \351galement le reste \340 investir
	if (isModeReinvestissement) {

		var totalAReinvestir = getANumber(document.getElementById('totalRestantHidden').value);
		var totalRestant = totalAReinvestir - getANumber(montantTotalBrut);

		if ($('.champMontant:disabled').length == $('.champMontant').length) {
			totalRestant = format(totalRestant, 0, " ");
			//totalRestant = setHtmlNumber(totalRestant);
		}
		else {
			totalRestant = format(totalRestant, 2, " ");
			totalRestant = setHtmlNumber(totalRestant);
		}

		$("#totalRestant span").text(totalRestant);

		if (totalRestant.indexOf('-') != -1) {
			$("#totalRestant").addClass("warning");
		}
		else {
			$("#totalRestant").removeClass("warning");
		}
	}
}

function openPopinBlockEdito() {
	var autoPopinElm = $('.autoPopin');
	var exceptionList = {
		0 : [ '/voscomptes/canalXHTML/comptesCommun/synthese_assurancesEtComptes/afficheSyntheseComptes-synthese.ea', '/voscomptes/canalXHTML/donneesPersonnelles/aiguillage_personnalisation/init-aiguillagePersonnalisation.ea' ]
	};

	if (autoPopinElm.length > 0) {
		autoPopinElm = autoPopinElm.last();
		var displayCookieName = 'lbpAutoPopinDisplay';
		var sessionCookieName = 'lbpAutoPopinSession';
		var path = null;
		for (var x in exceptionList) {
			for (var p in exceptionList[x]) {
				if (document.location.pathname.indexOf(exceptionList[x][p]) != -1) {
					path = '/';
					displayCookieName += 'Exception' + x;
					sessionCookieName += 'Exception' + x;
				}
			}
		}
		var autoPopinDisplayCookie = getCookie(displayCookieName);
		var autoPopinSessionCookie = getCookie(sessionCookieName);
		var pageCID = encodeURIComponent(document.location.pathname);
		var shouldDisplayPopin = false;
		var nbDisplayed = 0;

		if (!autoPopinDisplayCookie) {
			shouldDisplayPopin = true;
			autoPopinDisplayCookie = {};
		}
		else {
			if (!autoPopinSessionCookie) {
				var popinDisplayedTimes = autoPopinElm.attr('popinDisplayedTimes') ? autoPopinElm.attr('popinDisplayedTimes') : 1;
				autoPopinDisplayCookie = jQuery.parseJSON(autoPopinDisplayCookie);
				if (!autoPopinDisplayCookie[pageCID]) {
					shouldDisplayPopin = true;
				}
				else {
					nbDisplayed = autoPopinDisplayCookie[pageCID];
					if(nbDisplayed < popinDisplayedTimes) {
						shouldDisplayPopin = true;
					}
				}
			}
		}

		if (shouldDisplayPopin) {
			var reg = new RegExp("(webaccess)", "g");
			var title = autoPopinElm.attr('popinTitle') ? autoPopinElm.attr('popinTitle') : "";
			var corps = '<div class="autoPopinContent">\
							<div class="header clearfix">\
								<h1 id="popinTitle" style="float:left">' + title.replace(reg, "") + '</h1>\
								<a href="#" class="close">Fermer</a>\
							</div>\
							<div class="line"></div>\
						</div>';
			corps = $(corps).find('.line').append(autoPopinElm.html()).end().html();

			openSimplePopin("modalWindow", corps, false);

			nbDisplayed++;
			autoPopinDisplayCookie[pageCID] = nbDisplayed;
			var jsonStringifyFc = null;
			if (typeof JSON !== 'object' || !JSON.stringify) {
				JSONTools();
				jsonStringifyFc = $.toJSON;
			}
			else {
				jsonStringifyFc = JSON.stringify;
			}
			setCookie(displayCookieName, jsonStringifyFc(autoPopinDisplayCookie), null, path);
			if (!autoPopinSessionCookie) {
				autoPopinSessionCookie = {};
				autoPopinSessionCookie[pageCID] = 'activeSession';
				setCookie(sessionCookieName, jsonStringifyFc(autoPopinSessionCookie), 3600*1000, path);
			}
		}
	}
}

function activateLine() {
	var select = $(".recherche .PEA-CTO");

	if (select.length > 0){
		defaultSelectedValue 	= select.find("option:selected").val(),
		matchValues				= ["PEA", "CTO"],
		hideShowElt				= $(".hideShow");

		hideShowElt.hide();

		if(defaultSelectedValue.slice(0,3) == matchValues[0] || defaultSelectedValue.slice(0,3) == matchValues[1]) {
			hideShowElt.show();
		}

		select.change(function () {
			var value = $(this).val();

			if(value.slice(0,3) == matchValues[0] || value.slice(0,3) == matchValues[1]) {
				hideShowElt.show();
			} else {
				hideShowElt.hide();
			}
		});
	}
}

/********************************************************* SIMPLEPOPIN *********************************************************/

/***//* FERMETURE *//***/
function closeSimplePopin(){
	//suppression du fond
	$('#popinBack').remove();
	//suppression du fond blanc
	$('#popinContBack').remove();
	//Dans le cas d'un PDF affiche et sous IE10 et 11 uniquement, resout un probleme de page blanche - cf. jira45492
	$("#framePopin").attr('src',"about:blank");
	//suppression de la popin
	$('.popinCont').remove();
	//Rendre le fond re vocalisable par voiceover/talkback
	$('#page').removeAttr("aria-hidden","true");
	return false;
}

/***//* OUVERTURE *//***/
function openSimplePopin(id,content){
	openSimplePopin(id,content,true);
}

function openPopin(id,content,closeOpt){
	openSimplePopin(id,content,closeOpt);
}


function openSimplePopin(id,content,closeOpt){
	//fermeture des eventuelles popins deja ouvertes
	closeSimplePopin();

	if(closeOpt!=false){ closeOpt = true; }

	// gestion du corps de popin
	var corps = 	"<div id=\"popinBack\"></div>";
	corps = corps + "<div id=\"popinContBack\"></div>";
	corps = corps +	"<div id=\""+id+"\" tabindex='5000' class=\"popinCont\">";
	corps = corps +	"	<a id=\"popinStart\" href=\"#popinStart\" ><span class=\"webaccess\">D&eacute;but de popin</span></a>";
	corps = corps +	"	<div class=\"modalContent\">";
	if(closeOpt){
		corps = corps + "		<a href=\"#\" title=\"Fermer\" class=\"close\"><span>Fermer</span></a>";
	}
	corps = corps + content;
	corps = corps + "	</div>";
	corps = corps + "	<a id=\"popinEnd\" style='display:block;' href=\"#popinEnd\">Fin de popin</a>";
	corps = corps + "</div>";

	// insertion de la popin dans la page
	$('body').prepend(corps);
	
	//Rendre le fond non vocalisable par voiceover/talkback
	$('#page').attr("aria-hidden","true");

	// postionnement du fond
	if (document.body && document.body.offsetWidth) {
		myWidth = document.body.offsetWidth;
		myHeight = document.body.offsetHeight;
	}
	if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) {
		myWidth = document.documentElement.offsetWidth;
		myHeight = document.documentElement.offsetHeight;
	}
	if (window.innerWidth && window.innerHeight) {
		myWidth = window.innerWidth;
		myHeight = window.innerHeight;
	}

	$('#popinBack').css('width', myWidth+'px');
	$('#popinBack').css('height', myHeight+'px');

	// positionnement de la popin
	var popinWidth = $('#'+id).css('width').replace("px","");
	var popinHeight = $('#'+id).css('height').replace("px","");

	var positionLeft = (myWidth - popinWidth)/2;
	var positionTop = (myHeight - popinHeight)/2;

	// positionnement du fond blanc
	$('#popinContBack').css('width', (popinWidth-20)+'px');
	$('#popinContBack').css('height', (popinHeight-20)+'px');
	$('#popinContBack').css('left', ((myWidth - (popinWidth-20))/2)+'px');
	$('#popinContBack').css('top', ((myHeight - (popinHeight-20))/2)+'px');

	$('.popinCont').css('left', positionLeft+'px');
	$('.popinCont').css('top', positionTop+'px');

	// gestion des focus
	$('#'+id).focus();
	$("#popinEnd").css('opacity', 0).focusin(function () { $('#'+id).trigger('focus'); });

	//events de sortie de popin
	$('.close').click(function (e) { closeSimplePopin(); return false; });
	$('#popinBack').click(function (e) { closeSimplePopin(); return false; });
	$(document).keydown(function(e) { if (e.keyCode == 27) { closeSimplePopin(); return false; } });

	$(window).resize(function() { /* repositionnage si resize de la fenetre */
		// postionnement du fond
		if (document.body && document.body.offsetWidth) {
			myWidth = document.body.offsetWidth;
			myHeight = document.body.offsetHeight;
		}
		if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) {
			myWidth = document.documentElement.offsetWidth;
			myHeight = document.documentElement.offsetHeight;
		}
		if (window.innerWidth && window.innerHeight) {
			myWidth = window.innerWidth;
			myHeight = window.innerHeight;
		}

		$('#popinBack').css('width', myWidth+'px');
		$('#popinBack').css('height', myHeight+'px');

		// positionnement de la popin

		var positionLeft = (myWidth - popinWidth)/2;
		var positionTop = (myHeight - popinHeight)/2;

		// positionnement du fond blanc
		$('#popinContBack').css('left', ((myWidth - (popinWidth-20))/2)+'px');
		$('#popinContBack').css('top', ((myHeight - (popinHeight-20))/2)+'px');

		$('.popinCont').css('left', positionLeft+'px');
		$('.popinCont').css('top', positionTop+'px');

	});

	return false;
}

function openSmallPopin(content, deviceLine){
	//fermeture des eventuelles popins deja ouvertes
	closeSimplePopin();

	// gestion du corps de popin
	var corps = 	"<div id=\"popinBack\"></div>";
	corps = corps + "<div id=\"popinContBack\"></div>";
	corps = corps +	"<div id=\"smallPopin\" tabindex='5000' class=\"popinCont\">";
	corps = corps +	"	<a id=\"popinStart\" href=\"#popinStart\" ><span class=\"webaccess\">D&eacute;but de popin</span></a>";
	corps = corps +	"	<div class=\"modalContent\">";
	corps = corps + content;
	corps = corps + "	</div>";
	corps = corps + "	<a id=\"popinEnd\" style='display:block;' href=\"#popinEnd\">Fin de popin</a>";
	corps = corps + "</div>";

	// insertion de la popin dans la page
	$('body').prepend(corps);

	//Rendre le fond non vocalisable par voiceover/talkback
	$('#page').attr("aria-hidden","true");
	
	// postionnement du fond
	if (document.body && document.body.offsetWidth) {
		myWidth = document.body.offsetWidth;
		myHeight = document.body.offsetHeight;
	}
	if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) {
		myWidth = document.documentElement.offsetWidth;
		myHeight = document.documentElement.offsetHeight;
	}
	if (window.innerWidth && window.innerHeight) {
		myWidth = window.innerWidth;
		myHeight = window.innerHeight;
	}

	$('#popinBack').css('width', myWidth+'px');
	$('#popinBack').css('height', myHeight+'px');

	// positionnement de la popin
	var popinWidth = $('#smallPopin').css('width').replace("px","");
	var popinHeight = $('#smallPopin').css('height').replace("px","");

	var positionLeft = (myWidth - popinWidth)/2;
	var positionTop = (myHeight - popinHeight)/2;

	// positionnement du fond blanc
	$('#popinContBack').css('width', (popinWidth-20)+'px');
	$('#popinContBack').css('height', (popinHeight-20)+'px');
	$('#popinContBack').css('left', ((myWidth - (popinWidth-20))/2)+'px');
	$('#popinContBack').css('top', ((myHeight - (popinHeight-20))/2)+'px');

	$('.popinCont').css('left', positionLeft+'px');
	$('.popinCont').css('top', positionTop+'px');

	// gestion des focus
	$('#smallPopin').focus();
	$("#popinEnd").css('opacity', 0).focusin(function () { $('#'+id).trigger('focus'); });

	//events de sortie de popin
	$('.close').click(function (e) { $(".a2gTab tbody tr").removeClass("current"); closeSimplePopin(); return false; });
	$('.smallPopinClose').click(function (e) { $(".a2gTab tbody tr").removeClass("current"); closeSimplePopin(); return false; });
	$('#popinBack').click(function (e) { $(".a2gTab tbody tr").removeClass("current"); closeSimplePopin(); return false; });
	$(document).keydown(function(e) { if (e.keyCode == 27) { $(".a2gTab tbody tr").removeClass("current"); closeSimplePopin(); return false; } });


	/********** BASIC BEHAVIOR **********/
	$(".smallPopin").click(function(e){
		if(!e) e = window.event;
		e.preventDefault();

		$.ajax({
			url:$(this).attr("href"),
			type:'GET',
			success: function(data){
				var dataContent = $(data).find('.ajaxPopin').html();

				openSmallPopin(dataContent, deviceLine);
			},
			error : function (err) {
				console.log(err);
			}
		});

		return false;
	});

	/********** MODIFY BEHAVIOR **********/
	$("#deviceNameForm").val(deviceLine.find(".nameHandle").html());
	$("#deviceNameForm").keydown(function(e) {
		if (e.keyCode == 13) {
			$(".devicePopinModifyConfirm").click();
		}
	});
	$(".devicePopinModifyConfirm").click(function(){
		$.ajax({
			url:$(this).attr("href"),
			type:'GET',
			success: function(data){
				var modifyValue = $("#deviceNameForm").val();

				if(modifyValue==""){
					modifyValue = $("#deviceNameForm").attr("placeholder");
				}

				deviceLine.find(".nameHandle").html(modifyValue);
				deviceLine.find(".nameHiddenInput").val(modifyValue);

				var dataContent = $(data).find('.ajaxPopin').html();
				openSmallPopin(dataContent, deviceLine);
			}
		});

		return false;
	});

	/********** DELETE BEHAVIOR **********/
	$(".devicePopinDeleteConfirmOk").click(function(){
		deviceLine.remove();
	});

	/********** FRAUD BEHAVIOR **********/




	$(window).resize(function() { /* repositionnage si resize de la fenetre */
		// postionnement du fond
		if (document.body && document.body.offsetWidth) {
			myWidth = document.body.offsetWidth;
			myHeight = document.body.offsetHeight;
		}
		if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) {
			myWidth = document.documentElement.offsetWidth;
			myHeight = document.documentElement.offsetHeight;
		}
		if (window.innerWidth && window.innerHeight) {
			myWidth = window.innerWidth;
			myHeight = window.innerHeight;
		}

		$('#popinBack').css('width', myWidth+'px');
		$('#popinBack').css('height', myHeight+'px');

		// positionnement de la popin

		var positionLeft = (myWidth - popinWidth)/2;
		var positionTop = (myHeight - popinHeight)/2;

		// positionnement du fond blanc
		$('#popinContBack').css('left', ((myWidth - (popinWidth-20))/2)+'px');
		$('#popinContBack').css('top', ((myHeight - (popinHeight-20))/2)+'px');

		$('.popinCont').css('left', positionLeft+'px');
		$('.popinCont').css('top', positionTop+'px');

	});

	return false;
}

function openMedPopin(content, deviceLine){
	//fermeture des eventuelles popins deja ouvertes
	closeSimplePopin();

	// gestion du corps de popin
	var corps = 	"<div id=\"popinBack\"></div>";
	corps = corps + "<div id=\"popinContBack\"></div>";
	corps = corps +	"<div id=\"smallPopin\" tabindex='5000' class=\"popinCont mediumSize\">";
	corps = corps +	"	<a id=\"popinStart\" href=\"#popinStart\" ><span class=\"webaccess\">D&eacute;but de popin</span></a>";
	corps = corps +	"	<div class=\"modalContent\">";
	corps = corps + content;
	corps = corps + "	</div>";
	corps = corps + "	<a id=\"popinEnd\" style='display:block;' href=\"#popinEnd\">Fin de popin</a>";
	corps = corps + "</div>";

	// insertion de la popin dans la page
	$('body').prepend(corps);

	//Rendre le fond non vocalisable par voiceover/talkback
	$('#page').attr("aria-hidden","true");
	
	// postionnement du fond
	if (document.body && document.body.offsetWidth) {
		myWidth = document.body.offsetWidth;
		myHeight = document.body.offsetHeight;
	}
	if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) {
		myWidth = document.documentElement.offsetWidth;
		myHeight = document.documentElement.offsetHeight;
	}
	if (window.innerWidth && window.innerHeight) {
		myWidth = window.innerWidth;
		myHeight = window.innerHeight;
	}

	$('#popinBack').css('width', myWidth+'px');
	$('#popinBack').css('height', myHeight+'px');

	// positionnement de la popin
	var popinWidth = $('#smallPopin').css('width').replace("px","");
	var popinHeight = $('#smallPopin').css('height').replace("px","");

	var positionLeft = (myWidth - popinWidth)/2;
	var positionTop = (myHeight - popinHeight)/2;

	// positionnement du fond blanc
	$('#popinContBack').css('width', (popinWidth-20)+'px');
	$('#popinContBack').css('height', (popinHeight-20)+'px');
	$('#popinContBack').css('left', ((myWidth - (popinWidth-20))/2)+'px');
	$('#popinContBack').css('top', ((myHeight - (popinHeight-20))/2)+'px');

	$('.popinCont').css('left', positionLeft+'px');
	$('.popinCont').css('top', positionTop+'px');

	// gestion des focus
	$('#smallPopin').focus();
	$("#popinEnd").css('opacity', 0).focusin(function () { $('#'+id).trigger('focus'); });

	//events de sortie de popin
	$('.close').click(function (e) { closeSimplePopin(); return false; });
	$('#popinBack').click(function (e) { closeSimplePopin(); return false; });
	$(document).keydown(function(e) { if (e.keyCode == 27) { closeSimplePopin(); return false; } });

	$(window).resize(function() { /* repositionnage si resize de la fenetre */
		// postionnement du fond
		if (document.body && document.body.offsetWidth) {
			myWidth = document.body.offsetWidth;
			myHeight = document.body.offsetHeight;
		}
		if (document.compatMode=='CSS1Compat' && document.documentElement && document.documentElement.offsetWidth ) {
			myWidth = document.documentElement.offsetWidth;
			myHeight = document.documentElement.offsetHeight;
		}
		if (window.innerWidth && window.innerHeight) {
			myWidth = window.innerWidth;
			myHeight = window.innerHeight;
		}

		$('#popinBack').css('width', myWidth+'px');
		$('#popinBack').css('height', myHeight+'px');

		// positionnement de la popin

		var positionLeft = (myWidth - popinWidth)/2;
		var positionTop = (myHeight - popinHeight)/2;

		// positionnement du fond blanc
		$('#popinContBack').css('left', ((myWidth - (popinWidth-20))/2)+'px');
		$('#popinContBack').css('top', ((myHeight - (popinHeight-20))/2)+'px');

		$('.popinCont').css('left', positionLeft+'px');
		$('.popinCont').css('top', positionTop+'px');

	});

	return false;
}

/********************************************************* END SIMPLEPOPIN *********************************************************/

/*********Demande 2621*********/
/**Calcul des totaux**/

function HBTotalInput(){

	if($('.dataNum').length > 0) { // check if table exist

		var DataNum = (function() {
			var dataNum = {
				totalLabel : 'totalInputRepart',
				totalInputRepart1 : 0,
				totalInputRepart2 : 0,
				displayRepart1 : '.total1 strong',
				displayRepart2 : '.total2 strong',
				listEltRepart1 : $('.num.repartinput1'),
				listEltRepart2 : $('.num.repartinput2'),
				init : function (){
					var that = this;

					// 1st time
					$(dataNum).trigger('evt:toCalculate', { from : that.listEltRepart1, to : that.displayRepart1, result : "1" });
					$(dataNum).trigger('evt:toCalculate', { from : that.listEltRepart2, to : that.displayRepart2, result : "2" });
					// Event to call
					$.browser.chrome = $.browser.webkit && !!window.chrome,
					$.browser.safari = $.browser.webkit && !window.chrome;

					var eventToCall = "change";
					if($.browser.msie) {
						eventToCall = "blur";
					}else if ($.browser.safari) {
						eventToCall = "blur";
					}else {
						eventToCall = "change";
					}
					// 1st List
					this.listEltRepart1.each(function (index){
						var current = $(this);

						current.on( eventToCall , function(e){
							if(!e) e = window.event;
							e.preventDefault();
							that.totalInputRepart1 = 0; // Reset variable
							$(dataNum).trigger('evt:toCalculate', { from : that.listEltRepart1, to : that.displayRepart1, result : "1" });
						});
						current.on('keyup', function(e) {
							if(!e) e = window.event;
							e.preventDefault();
							this.value = this.value.replace(/[^0-9\.,]/g,'');
						});
					});

					// 2nd List
					this.listEltRepart2.each(function (index){
						var current = $(this);

						current.on( eventToCall , function(e){
							if(!e) e = window.event;
							e.preventDefault();
							that.totalInputRepart2 = 0; // Reset variable
							$(dataNum).trigger('evt:toCalculate', { from : that.listEltRepart2, to : that.displayRepart2, result : "2" });
						});
						current.on('keyup', function(e) {
							if(!e) e = window.event;
							e.preventDefault();
							this.value = this.value.replace(/[^0-9\.,]/g,'');
						});

					});
				},
				currencyMode : function(value) {
					var currentValue = value,
						currencyValue;
						currencyValue = (currentValue).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
					return currencyValue;
				}
			};

			$(dataNum).on('evt:toCalculate', function (e, data){
				if(!e) e = window.event;
				e.preventDefault();
				var listElt = data.from,
					nbAllElt = listElt.length,
					tempVal = 0,
					finalVal = ''
					tempTab = [];

				for( var currentIndex = 0; currentIndex < nbAllElt; currentIndex++) {
					var currentElt = listElt[currentIndex],
						dirtyVal = $(currentElt).val() || '0';
						cleanVal = dirtyVal.replace(/ /g, '').replace(/,/g, '.');
						dataNum[dataNum.totalLabel + data.result] = parseFloat(dataNum[dataNum.totalLabel + data.result]) + parseFloat(cleanVal);
				}
				tempVal = (dataNum[dataNum.totalLabel + data.result]).toFixed(2);
				tempTab = tempVal.split(".");
				finalVal = dataNum.currencyMode(tempTab[0]) + "," + tempTab[1];
				$(data.to).empty().append( finalVal );
			});

			return {
				init : function () {
					dataNum.init();
				}
			}
		})();

		DataNum.init();
	}


}
