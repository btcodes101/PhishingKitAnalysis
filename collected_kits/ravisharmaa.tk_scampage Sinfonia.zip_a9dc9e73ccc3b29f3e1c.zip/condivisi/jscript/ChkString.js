// ****************************************************************************************
// Controllo sulla valorizzazione di un dato.
// Se � valorizzato return 1 altrimenti return 0.

function IsValorizzato (oDato ){
var sDato = oDato.value;
return (IsValorizzatoString (sDato ))
}

//vedo se la stringa passata � valorizzata
function IsValorizzatoString (sDato ){
var carattere;
if (sDato.length ==0)
	{
	return 0
	}

// vedo se la stringa � composta da tutti blank,
// se c'� almeno un carattere non blank va bene
var blank = " ";
for (var intLoop = 0; intLoop < sDato .length;
    intLoop++)
{
	carattere = sDato.charAt(intLoop);
	// verifico se il carattere � un blank
    if (-1 == blank.indexOf(carattere))
	{
	  //c'� almeno un carattere diverso da blank
	  return 1
	}
}

return 0
}

// ****************************************************************************************
/*
function ToUpperCase( oDato ){

if (IsValorizzato (oDato) == 0)
	return "";

var ritorno = "";
var minuscole = "abcdefghkijlmnopqrstuvxywz";
var maiuscole = "ABCDEFGHKIJLMNOPQRSTUVXYWZ";
var carattere;
var newcarattere;

var posizione;

var string = oDato.value;
for (var intLoop = 0; intLoop < string.length;
    intLoop++)
{
	carattere = string.charAt(intLoop);
	posizione = minuscole.indexOf(carattere);
    	if (posizione != -1)
	{
		//	assert : � un carattere minuscolo
		//    prendo il maiuscolo corrispondente
		newcarattere = maiuscole.charAt(posizione);
	}
	else
	{
		newcarattere = carattere;
	}
	ritorno = ritorno + newcarattere;
}
oDato.value = ritorno;
return ritorno;
}
*/

// ****************************************************************************************
// Verifica che la stringa contenga i caratteri validi per un nome o un cognome o altre
// stringhe del genere quindi
// non valgono i numeri n� i simboli eccetto l'apice (es: DELL'OLIO).
// I caratteri accentati non sono validi (es: cal� va scritto calo')
// Il blank � valido (es: EDOARDO FILIPPO).
// Il trattino � valido (es: CHIA-YUN )


function ChkNoSymbolNoNumberString( oDato ){
var ammessi = "ABCDEFGHKIJLMNOPQRSTUVXYWZ abcdefghkijlmnopqrstuvxywz'-";

if (IsValorizzato (oDato) == 0)
return 0

var string = oDato.value;

if (string.length<1)
	{
	 return 0
	}


for (var intLoop = 0; intLoop < string.length;
    intLoop++)
{
    if (-1 == ammessi.indexOf(string.charAt(intLoop)))
	{
	 return 0
	}
}
return 1;
}


// ****************************************************************************************

function IsNumericString(string){
var ammessi = "0123456789";
if (string.length<1)
	return 0;

for (var intLoop = 0; intLoop < string.length;
    intLoop++)
{
    if (-1 == ammessi.indexOf(string.charAt(intLoop)))
	{
       return 0;
	}
}
return 1;
}

// ****************************************************************************************

function IsAlfabeticString(string){
var ammessi = "ABCDEFGHKIJLMNOPQRSTUVXYWZabcdefghkijlmnopqrstuvxywz";
if (string.length<1)
	return 0;
for (var intLoop = 0; intLoop < string.length;
    intLoop++)
{
    if (-1 == ammessi .indexOf(string.charAt(intLoop)))
	{
        return 0;
	}
}
return 1;
}

// ****************************************************************************************

function IsAlfaNumericString(string){
var ammessi = "ABCDEFGHKIJLMNOPQRSTUVXYWZabcdefghkijlmnopqrstuvxywz0123456789";
if (string.length<1)
	return 0;
for (var intLoop = 0; intLoop < string.length;
    intLoop++)
{
    if (-1 == ammessi .indexOf(string.charAt(intLoop)))
	{
        return 0;
	}
}
return 1;
}
// ****************************************************************************************
function IsRealNumberString(string){
var ammessi = "0123456789,.-";
var virgola = ",";
var negativo = "-";
var numVirgole = 0;
var numNegativo = 0;
var posizionenegativo;
var posizioneVirgola;

if (string.length<1)
	return 0;
	
for (var intLoop = 0; intLoop < string.length;
    intLoop++)
{
    if (-1 == ammessi.indexOf(string.charAt(intLoop)))
	{
		// non � un carattere ammesso
       return 0;
	}
	
	
	if (negativo.indexOf(string.charAt(intLoop)) > -1){
		// � un segno -
		numNegativo++;
		// deve esserci al massimo un segno -
		if (numNegativo > 1) return 0;
	}
	
	if ( virgola.indexOf(string.charAt(intLoop)) > -1)
	{
		// � una virgola
		numVirgole++;
		// deve esserci al massimo una sola virgola
		if (numVirgole > 1) return 0;
	}
}

if (numNegativo == 1){
	// c'� il segno -
	posizioneNegativo = string.indexOf('-');

	//se il segno negativo non � in prima posizione
	if (posizioneNegativo != 0)
		return 0;
	
	// non pu� terminare con il segno -
	if (posizioneNegativo == (string.length-1))
		return 0;
}

if (numVirgole == 1)
{
	// c'� la virgola
	posizioneVirgola = string.indexOf(',');

	// non pu� iniziare con la virgola
	if (posizioneVirgola == 0)
		return 0;

	// non pu� terminare con la virgola
	if (posizioneVirgola == (string.length-1))
		return 0;
}

return 1;
}

// ****************************************************************************************
function IsFloatDueDecimali(string){
	if (IsRealNumberString(string) == 0)  return 0;

	var posizioneVirgola = string.indexOf(',');

	if (posizioneVirgola != -1)
	{
		// c'� la virgola
		if ((string.length - posizioneVirgola) > 3)
			return 0;
	}
	return 1;

}
// ****************************************************************************************

function replaceVirgolaConPunto (string){

	var virgola = ",";
	var ritorno = "";

	for (var intLoop = 0; intLoop < string.length; intLoop++)
	{
    	if (-1 == virgola.indexOf(string.charAt(intLoop)))
		{
    	   	// non � una virgola
			ritorno += string.charAt(intLoop);
		}else{
			// virgola
			ritorno += ".";
		}
	}

	return ritorno;

}

// ****************************************************************************************

function replacePuntoConVirgola(string){

	var punto = ".";
	var ritorno = "";

	for (var intLoop = 0; intLoop < string.length; intLoop++)
	{
    	if (-1 == punto.indexOf(string.charAt(intLoop)))
		{
    	   	// non � un punto
			ritorno += string.charAt(intLoop);
		}else{
			// punto
			ritorno += ",";
		}
	}

	return ritorno;

}

//****************************************************************************************

//function IsValidPassword(password) {
//	var oRegExp = /^[a-zA-Z]([a-zA-Z0-9]){3}([a-zA-Z0-9]{0,32})$/;
//	
//	if (!oRegExp.test(password))
//		return 0;
//	
//	return 1;
//}

//****************************************************************************************
//Copiato da EDOTTO - Lucio Villani
function IsValidPassword(password) {	
	var score = 0;
	
	if (password.length = 0)
		return 0;
	
	if (/[a-z]/.test(password))
		score = score + 1;
	if (/[A-Z]/.test(password))
		score++;
	if (/\d/.test(password))
		score++;
	if (/[!@#$%^&*?_~"£\/\()=\^|§°+<>]/.test(password))
		score++;
	
	if (score < 3)
		return 0;
	
	return 1;
}
//Fine


