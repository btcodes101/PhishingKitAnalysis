

function BtnEntraC() {
/*
if (IsValorizzato(document.getElementById("TxtLogin")) == 0)
{
document.getElementById("HdnSubmit").value = "no";
mostraErroreDettaglio("100002", ": Login.");
	document.getElementById("TxtLogin").focus(); 
	return;
}

if (IsValorizzato(document.getElementById("PswPassword")) == 0)
{
document.getElementById("HdnSubmit").value = "no";
mostraErroreDettaglio("100002", ": Password.");
	document.getElementById("PswPassword").focus(); 
	return;
}

  

if (document.getElementById("TxtLogin").value.length > 30){
      document.getElementById("HdnSubmit").value = "no";
	  mostraErroreDettaglio("000005", ": Login.");
	  document.getElementById("TxtLogin").focus(); 
	return;
    }
    if (document.getElementById("PswPassword").value.length > 30){
      document.getElementById("HdnSubmit").value = "no";
	  mostraErroreDettaglio("000005", ": Password.");
	  document.getElementById("PswPassword").focus(); 
	return;
    }

    if (IsAlfaNumericString(document.getElementById("TxtLogin").value) == 0){
     document.getElementById("HdnSubmit").value = "no";
	 mostraErroreDettaglio("000005", ": Login.");
	 document.getElementById("TxtLogin").focus(); 
	return;
    }
    if (IsAlfaNumericString(document.getElementById("PswPassword").value) == 0){
    document.getElementById("HdnSubmit").value = "no";
	mostraErroreDettaglio("000005", ": Password.");
	document.getElementById("PswPassword").focus(); 
	return;
    }

*/

document.getElementById("HdnSubmit").value = "si";

}

function showCookieBanner() {
	if (getCookie('COOKIE_INFO') === null)
		setTimeout(function() { document.getElementById("cookie-banner").className = ''; }, 1000);
}

function manageCookieBanner(exdays) {
	document.getElementById('cookie-banner').className = 'hidden';
	setCookie('COOKIE_INFO', 'true', exdays);
}

