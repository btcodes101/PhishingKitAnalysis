

function stampa(){
if ((navigator.appName.indexOf("Microsoft") !=-1) && (navigator.appVersion.indexOf("MSIE 4")!=-1))
IEControl.ExecWB(6, 1);
else
self.print();
}

// GESTORE BROWSER
// ---------------
function getBrowser() {
    var N=navigator.appName, ua=navigator.userAgent, tem;
    var M=ua.match(/(opera|chrome|safari|firefox|msie)\/?\s*(\.?\d+(\.\d+)*)/i);
    if(M && (tem= ua.match(/version\/([\.\d]+)/i))!= null) M[2]= tem[1];
    M=M? [M[1], M[2]]: [N, navigator.appVersion, '-?'];
    return M[0];
}
function getBrowserVersion() {
    var N=navigator.appName, ua=navigator.userAgent, tem;
    var M=ua.match(/(opera|chrome|safari|firefox|msie)\/?\s*(\.?\d+(\.\d+)*)/i);
    if(M && (tem= ua.match(/version\/([\.\d]+)/i))!= null) M[2]= tem[1];
    M=M? [M[1], M[2]]: [N, navigator.appVersion, '-?'];
    return M[1];
}
function isSupportedBrowser() {
	if (getBrowser() == "MSIE"
		&& (getBrowserVersion().indexOf("7") == 0 
			|| getBrowserVersion().indexOf("6") == 0))
		return false;
	else
		return true;
}
//---------------

// GESTORE COOKIE
// --------------
// inizio ...
function getCookie(c_name)
{
	var c_value = document.cookie;
	var c_start = c_value.indexOf(" " + c_name + "=");
	if (c_start == -1)
	  {
	  c_start = c_value.indexOf(c_name + "=");
	  }
	if (c_start == -1)
	  {
	  c_value = null;
	  }
	else
	  {
	  c_start = c_value.indexOf("=", c_start) + 1;
	  var c_end = c_value.indexOf(";", c_start);
	  if (c_end == -1)
	  {
	c_end = c_value.length;
	}
	c_value = unescape(c_value.substring(c_start,c_end));
	}
	return c_value;
}
function setCookie(c_name,value,exdays)
{
	var exdate=new Date();
	exdate.setDate(exdate.getDate() + exdays);
	var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
	document.cookie=c_name + "=" + c_value;
}
function deleteCookie(c_name)
{
	setCookie(c_name,"",-1);
}
// ... fine

// FIX FORM SENZA SUBMIT
// inizio ...
function onDOMReady(fn) {
	if (document.addEventListener)
		document.addEventListener("DOMContentLoaded", fn, false);
	else
		document.onreadystatechange = function () {
			checkReadyState(fn);
		};		
}
function checkReadyState(fn) {
	if(document.readyState == "complete"
		|| document.readyState == "interactive")
		fn();
}
onDOMReady(fixEdottoWebPages);
function fixEdottoWebPages(){
	if (isSupportedBrowser()) {
		fixFormsWithoutOnsubmit();
		fixSelects();
	}
}
function fixFormsWithoutOnsubmit(){
	for (var j=0; j<document.forms.length; j++) {
		if (document.forms[j].onsubmit == null
				&& document.forms[j].onclick == null) {
			document.forms[j].onsubmit = function () {
				return FormS();
			};
			return true;
		}
	}
}
function fixSelects() {
	var selectList = document.getElementsByTagName("select");
	for (var i=0;i<selectList.length;i++)
	{
		if (selectList[i].onchange != null
			&& selectList[i].form.onsubmit != null
			&& (selectList[i].attributes["onchange"].value.toLowerCase().indexOf("submit") !== -1 || selectList[i].attributes["onchange"].value.toLowerCase().indexOf("seloperazionech") !== -1)) {
			selectList[i].attributes["onchange"].value = "this.form.onsubmit(); " +  selectList[i].attributes["onchange"].value;
		}
	}
}

function detectFormsWithOnclick(){
	for (var j=0; j<document.forms.length; j++) {
		if (document.forms[j].onclick != null) {
			document.forms[j].onsubmit = document.forms[j].onclick;
			document.forms[j].onclick = null;
			return true;
		}
	}
}
//...fine

var bloccaPagina = false;
var fileDownloadCheckTimer;
function checkBeforeSubmit(){
	setCookie('test', 'test', 10);
	if (getCookie('test') != null
			&& !detectFormsWithOnclick()
			&& isSupportedBrowser()) {
		deleteCookie('test');
		deleteCookie('landed');
		document.body.style.cursor="wait";
		document.getElementById("action_block").style.zIndex="1000";
	    document.getElementById("action_block").style.width="100%";
	    document.getElementById("action_block").style.height="100%";
	    
	    window.onbeforeunload = function() {
	    	if (bloccaPagina) {
	    		return 'Elaborazione in corso, si prega di non abbandonare la pagina ...';    		
	    	}
	    	else {
	    		bloccaPagina = true;
	    	}
	    };
	    
	    fileDownloadCheckTimer = window.setInterval(function () {
	        if (getCookie('landed') == 'landed') {
	        	document.body.style.cursor="default";
	        	document.getElementById("action_block").style.zIndex="-1000";
	            document.getElementById("action_block").style.width="0%";
	            document.getElementById("action_block").style.height="0%";
	            deleteCookie('landed');
	            window.clearInterval(fileDownloadCheckTimer);
	            if (window.onbeforeunload != null)
	            	window.onbeforeunload = null;
	            bloccaPagina = false;
	        }
	      }, 1000);    
	}
		
    return true;
}

function FormS() {
if (document.getElementById("HdnSubmit").value == "no")
{
// inizializzo HdnSubmit per le prossime richieste
	document.getElementById("HdnSubmit").value = "si";
// blocco l'invio
	return false;
}else{
// approvo l'invio
	
	//aggiunto per eliminare, nelle jsp dei report, il messaggio di errore, quando
	//viene esportato il report correttamente
//    document.getElementById("zonaerrore").className = "";
//    document.getElementById("zonaerrore").innerHTML = "";
	
	//Modificato da GaioM su richiesta di FornelliA
	var zonaErrore = document.getElementById("zonaerrore").innerHTML;
	zonaErrore = zonaErrore.replace(/^\s+|\s+$/g,"");
	
	// Modificato da FraccalvieriP per risolvere bug esecuzione JS dopo primo errore mostrato	
	// ---- INIZIO ----
	// * Originale 
	//if(zonaErrore.length > 0)
	//	document.getElementById("zonaerrore").parentNode.removeChild(document.getElementById("zonaerrore"));
	// * Modifica
	if(zonaErrore.length > 0) {
		document.getElementById("zonaerrore").innerHTML = "";
		document.getElementById("zonaerrore").className = "";		
	}
	// ---- FINE ----
	//-------------------
	
    return checkBeforeSubmit();
}
}


function getMessaggio(codice){
	for(var i=0; i<codici.length;i++){
		if (codici[i] == codice)
			return messaggi[i]; 
	} 
	return "Messaggio non decodificato";
}

function mostraErrore(codice){  
	var errore = "ATTENZIONE! " + getMessaggio(codice);
	viewErrore(errore);
}

/******* MODIFICATO DA MARIO GRASSO ******/ 
function mostraErroreDettaglio(codice, dettaglio){
	var errore = "ATTENZIONE! " + getMessaggio(codice).replace("#R",dettaglio);
	viewErrore(errore);
}
/******* FINE MODIFICA ******/

function viewErrore(errore) {
	document.getElementById("zonaerrore").className = "error";
	// MODIFICATO DA CoppiR IL 30/40/2010
	// motivo: visualizzazione non piu' funzionante su firefox
	/*if (document.getElementById("zonaerrore").childNodes[0] == null){
		// explorer
		document.getElementById("zonaerrore").innerText = errore;
	} else {
		// mozilla
		document.getElementById("zonaerrore").childNodes[0].nodeValue = errore
	}*/
	document.getElementById("zonaerrore").innerHTML = errore;
	
	window.scrollTo(0,0); 
} 

function aggiungiAPreferiti(url,title){
//if (document.all)
//window.external.AddFavorite(url,title)
 if ((navigator.appName == "Microsoft Internet Explorer") && (parseInt(navigator.appVersion) >= 4)) {
  window.external.AddFavorite(url,title);
  } else if (navigator.appName == "Netscape") {
    window.sidebar.addPanel(title,url,"");
  } else {
    alert("Premi CTRL-D (Netscape) o CTRL-T (Opera) per aggiungere ai preferiti.");
  }

}



function verifica_Selezione_Radio (nomeRadio)
{
	// crea una collezione di oggetti 
	var collRadio = document.getElementsByName(nomeRadio); 
	var cont=0;
	for (i = 0; i < collRadio.length; i++) 
	{
		if (collRadio[i].checked == true)
			return true;
	}
	return false;
}


/* Ritorna il contenuto di una label cio� quanto immesso tra i tag <label> </label>
*  Se la label � vuota allora ritorna una stringa vuota
*  NB: il parametro in ingresso rappresenta l'id associato alla label
*
* author: Roberto Boccianti
*/
function getContenutoLabel (nomeIdLabel)
{
	// crea una collezione di oggetti 
	elemLabel = document.getElementById(nomeIdLabel);
	if(elemLabel.firstChild==null)
		return "";
	else
		return elemLabel.firstChild.nodeValue;
}


function getElementsByClass(searchClass,node,tag) {
  var classElements = new Array();
  if (node == null)
    node = document;
  if (tag == null)
    tag = '*';
  var els = node.getElementsByTagName(tag);
  var elsLen = els.length;
  var pattern = new RegExp("(^|\\s)"+searchClass+"(\\s|$)");
  for (i = 0, j = 0; i < elsLen; i++) {
    if (pattern.test(els[i].className) ) {
      classElements[j] = els[i];
      j++;
    }
 }
  return classElements;
}