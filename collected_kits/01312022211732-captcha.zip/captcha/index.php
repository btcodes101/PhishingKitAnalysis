<?php      
  header('Location: captcha.php');      
?>