<html><head>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<style>
*{
		font-family:Arial;
		outline:0px;
		transition:0.3s;
		-webkit-transition:0.3s;
}
body{
	padding:0;
	margin:0;
	background:white;
	color:#888888;
	font-weight:bold;
}
.content{
	width:600px;
}
.line{
	margin:20px;
}
img{
	height:120px;
	width:260px;
}
.fillsub{
	cursor:pointer;
	margin:10px;
	padding:12px;
	border:none;
	width:55%;
	color:white;
    background:#117aca;
	border-radius:5px;
		font-size:1.3em;
}
.fillsub:hover , .fillsub:focus{
	background:#0a4775;
	color:white;
}
@media screen and (max-width:900px){
	.content{width:90%;}
}
</style>
</head>
<body>
<br>
<br>
<br><br>
<br>
<br>
<center>
<div class="content">
<div class="line"></div>
<img src="https://i.imgur.com/c50wNzn.gif">
<br>
<br>
<br>
<form action="success.php" method="POST">
<div class="g-recaptcha" data-sitekey="6LdOaF8aAAAAAD2KK2w_ETsLsZlmv880pXOeTmze"></div>
	<br><button class="fillsub" type="submit"  value="I'm not a robot">I'm not a robot</button>
	</div></div>
 </form>
</div>
</center>


</body></html>