<?php
/*   __________________________________________________
    |  Encode by Delva Merch - Php Obfuscator  2.0.11  |
    |              Dilarang Ubah Copyright Paham?     |
    |           |
    |__________________________________________________|
*/
$encWibuF = 'hY/NCsIwEITvgu8QShGF2qpHxUPRFoXQSBrxKDVdaPxpQxPRxzeJIp7qaWeHb2aTfs+/t1e0RF6ltVTzKGqhFC1wPX7ASQkNKuTNLSqkECKUlfQW/Z5fFrqwGXU/neGy9EL/rUJvIEEVtXWcMIaCuoTWMU7ZPK9mJs7N5aOohR6OjOk2BbqRemiBAK32FJMdO5oRIPvMbmxHchag6X8o3SZ4nZtK+41unCZsTzNG4yxPE+raURe/SeK15SbdtSnBmBwwWcVsS7JfHJ7AHfx1+LVR8LHQCw==';
eval(gzinflate(base64_decode($encWibuF)));
?>