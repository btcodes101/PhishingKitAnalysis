


 






 
       
    
 
    
 
      
          
 







<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">

<head>



















	


	
		
	<script type="text/javascript">
		
		/* create a singleton that will contain all our code. The singleton isn't technically "namespaced", but using it reduces the number of global variables created to one. The singleton returns one public variable, the reference to the timeout handle.
		*/
		var bandwidthHandler = (function () {
		// the threshold. Currently set to 30 seconds. It can be lowered if needed.
		    var _threshold = 30000,
		        _waitInterval = 1000;
		        
		    var _showBandwidthWarning = function () {
		        if (document.getElementById("bandwidthmsg") != undefined) {
		            document.getElementById("bandwidthmsg").style.display = "block";
		        }
		        else {
		            // Save waitHandle to the global 'bandwidthHandler' object so IE doesn't destroy it
		            this.waitHandle = setTimeout(_showBandwidthWarning, _waitInterval);
		        }
		    };
		     
		    var _timeoutHandle = setTimeout(_showBandwidthWarning, _threshold);
		    return {
		        timeoutHandle : _timeoutHandle
		    };
		}());
	</script>	
	
	


	





    <meta http-equiv="content-type" content="text/html; charset=utf-8" />

    <meta name="google-site-verification" content="ixTkEWd_UcMhrL39nLaMLEq66o3Ecdwa-btSiATF0Uc" />


<meta name="msvalidate.01" content="6041AA1EC3506170E8F3851B2EC5C561" />



	



<title>USAA Military Home, Life & Auto Insurance | Banking & Investing</title>



	<meta name="keywords" content="company,invest,options,discounts,federal savings bank,financial planning,floral,flowers,jewelry,pearls,diamonds,retirement,nursing home,long-term care,disability,medical,major medical,health,life,checking,account,savings,banking,bank,investments,investment,trading,mutual funds,brokerage,broker,investing,insurance,commercial,boat,condominium,fire,renters,accident,protection,risk,service,comprehensive,collision,loss,quote,rates,floater,bond,property,military,agency,liability,casualty,competitive rates,policy,premium,coverage,flood,homeowners,car,auto" />




	<meta name="title" content="USAA Military Home, Life & Auto Insurance | Banking & Investing" />





	<meta name="subject" content="notsearchable " />




	<meta name="description" content="With competitive home, life and auto insurance rates, as well as convenient online banking and investment services, USAA proudly serves millions of military members and their families. Get a free home, life or auto insurance quote now." />




	<meta name="abstract" content="USAA -- Diversified Financial Services Association Home Page" />






<meta http-equiv="pics-label" content='(pics-1.1 "http://www.icra.org/ratingsv02.html" l gen true for "http://www.usaa.com" r (cz 1 lz 1 nz 1 oz 1 vz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "http://www.usaa.com" r (n 0 s 0 v 0 l 0))' /> 








<meta name="ROBOTS" content="NOODP" />

<meta name="ROBOTS" content="NOYDIR" /> 












<meta http-equiv="Content-Style-Type" content='text/css' />



	
	
	
                <link rel="stylesheet" type="text/css" href="https://s.usaa.com/inet/resources/aggregator?type=-min&embed=true&p_/mcontent/static_assets/Includes/dotCom_masterStyles.css:cacheid=44289455_p:type=css&p_/mcontent/static_assets/Includes/iaRestructure.css:cacheid=2063359478_p:type=css&p_/mcontent/static_assets/Includes/wcm-wrapper-common.css:cacheid=2267123050_p:type=css" media="all" />

    
    














	


	
















	
	
		
			
				<script language="javascript" src="https://s.usaa.com/inet/resources/aggregator?type=-min&embed=true&p_/ent/ent_core.js:cacheid=755218564_p:type=javascript&p_/ent/utilities/loader.js:cacheid=1886635645_p:type=javascript&p_/yui/yahoo-dom-event/yahoo-dom-event.js:cacheid=1245802701_p:type=javascript&p_/cp_std.js:cacheid=164206671_p:type=javascript&p_/cp_help_popup.js:cacheid=1676159589_p:type=javascript&p_/yui/connection/connection.js:cacheid=3970493711_p:type=javascript&p_/yui/container/container.js:cacheid=2794407859_p:type=javascript&p_/yui/animation/animation.js:cacheid=521316373_p:type=javascript&p_/yui/menu/menu.js:cacheid=3502886800_p:type=javascript&p_/ent/widgets/transient_layer_v2.js:cacheid=2976077411_p:type=javascript&p_/ec/utilities/enterpriseUtilityFunctions.js:cacheid=2831538708_p:type=javascript&p_/ec/apps/authbar/authenticationbar.js:cacheid=4136712302_p:type=javascript&p_/ec/apps/nav_subglobal_menu/nav_subglobal_menu.js:cacheid=3824629660_p:type=javascript&p_/ec/apps/acc_touch/accTouchMenu.js:cacheid=3074435033_p:type=javascript&p_/ec/apps/logon/logon.js:cacheid=1511394220_p:type=javascript&p_/ec/apps/logon/autofocus.js:cacheid=2422341408_p:type=javascript&p_/fp.js:cacheid=3712385577_p:type=javascript&p_/ec/apps/logon/flashmemory.js:cacheid=3807544618_p:type=javascript&p_/ent/utilities/Logging/MessageLogger.js:cacheid=1009195959_p:type=javascript&p_/ent/utilities/Logging/RemoteConsole.js:cacheid=2912577374_p:type=javascript&p_/ent/utilities/Logging/Local.js:cacheid=3189526011_p:type=javascript&p_/ent/utilities/Logging/Console.js:cacheid=570396654_p:type=javascript&p_/ent/utilities/Logging/ErrorHandler.js:cacheid=1667082294_p:type=javascript&p_/ent/utilities/clientEventLogging.js:cacheid=2712668622_p:type=javascript" type="text/javascript"></script>

			
			
		
		
		<script>
			if (USAA.ent.util.Loader) {
				

				USAA.ent.util.Loader.aggregatorBaseUrl = 'https://s.usaa.com/inet/resources/aggregator?type=-min';
			}
		</script>
	
	
	
	
    <script>
        (function(){
            
            

            
            USAA.ent.util.MessageLogger.remoteLogger = new USAA.ent.util.MessageLogger.Remote({
                uri: 'https://www.usaa.com/inet/ent_js_logging/ClientsideMessagingServlet',
                maxLogs: 100 
            });

            
            USAA.ent.util.MessageLogger.remoteLogger.addWhitelist({
                name: "ErrorCritical",
                validator: function(msg){
                    return msg.logType == 'error' && msg.logSubType == 'critical';
                }
            });
            
            
            USAA.ent.util.MessageLogger.urlPaths = {
                richDebug: "https://s.usaa.com/javascript/ent/utilities/Logging/RichDebugging-min.js?cacheid=365722909_p",
                richDebugCSS: "https://content.usaa.com/mcontent/static_assets/Includes/siteHelpToolbar.css?cacheid=1555624025_p",
                yuiAnimate: "https://s.usaa.com/javascript/yui/animation/animation-min.js?cacheid=521316373_p",
                yuiCookie: "https://s.usaa.com/javascript/yui/cookie/cookie-min.js?cacheid=17853472_p",
                yuiLogger: "https://s.usaa.com/javascript/yui/logger/logger-min.js?cacheid=3936785744_p",
                yuiLoggerCSS: "https://s.usaa.com/javascript/yui/logger/assets/skins/sam/logger-min.css?cacheid=1581392092_p",
                yuiDragDrop: "https://s.usaa.com/javascript/yui/dragdrop/dragdrop-min.js?cacheid=3535896122_p"
            };

            
            if (getCookie(USAA.ent.util.MessageLogger.debugCookieName) === "true") {
                USAA.ent.util.MessageLogger.enableRichDebugging();
            }
            

            
              

            
                
                
            
        }());
    </script>



	<script src="https://s.usaa.com/javascript/ec/apps/logon/logonCapsLockCheck-min.js?cacheid=2936984792_p" ></script>


<script>


	function dynamicAction(Action)
	{
		var element = YAHOO.util.Dom.get('LogonMain');
		if (YAHOO.lang.isObject(element)){

			
			
			if (true)
			{
				
				element.PS_DYNAMIC_ACTION.value = Action;
				
                
				if(YAHOO.lang.isObject(document.getElementById("PS_SCROLL_POSITION")))
				{
				element.PS_SCROLL_POSITION.value = scrollPosition() + ":" + element.PS_PAGEID.value;
				}
				
				element.submit();
			}
		}
		return false;
		
	}


	function scrollPosition()
	{
		
		var winX = window.pageYOffset ? window.pageYOffset : 0;
		var docElementX = document.documentElement ? document.documentElement.scrollTop : 0;
		var bodyX = document.body ? document.body.scrollTop : 0;
		var resultX = winX ? winX :0;
		var positionX =0;
		
				
		var winY = window.pageXOffset ? window.pageXOffset : 0;
		var docElementY = document.documentElement ? document.documentElement.scrollLeft : 0;
		var bodyY = document.body ? document.body.scrollLeft :0;
		var resultY = winY ? winY :0;
		var positionY =0;
		
		
		if(docElementX > 0)
		{
			if(docElementX && (!resultX || (resultX > docElementX)))
				resultX = docElementX;
			positionX = bodyX && (!resultX || (resultX > bodyX)) ? bodyX : resultX;
		}
		
		if(docElementY > 0)
		{
			if(docElementY && (!resultY || (resultY > docElementY)))
				resultY = docElementY;
			positionY = bodyY && (!resultY || (resultY > bodyY)) ? bodyY : resultY;
		}
		
		return positionX+":"+positionY;
	}
	
	

	function resetScrollPosition()
	{
		var pageId = YAHOO.util.Dom.get('LogonMain').PS_PAGEID.value;
		
		var scrollPosition =  '';
		
		if(scrollPosition != '')
		{
			var scrollPositionDetails = scrollPosition.split(":");
			var isDisplayMessage = false;
			
			
			if(scrollPositionDetails[2] != '' && scrollPositionDetails[2] == pageId && !isDisplayMessage)
			{
				document.documentElement.scrollTop =  scrollPositionDetails[0];
				document.documentElement.scrollLeft = scrollPositionDetails[1];
			}
		}
	}


	function submitDynamicAction(Action,Target,Context)
	{
		return dynamicAction("PsDynamicAction_[action]" + Action + "[/action][target]" + Target + "[/target][context]" + Context + "[/context]");
	}

</script>

<script>
   
   var children = new Array();
   var nr       = 0;

   
   function closeChildren()
   {
   
	  closeHelpWnd();

      for (i=0; i < nr; i++)
      {
         children[i].close();
      }
   }


   function openGlossaryWindow(PageName)
   {
      var intHelpWidth = "400";
      var intHelpHeight = "220";
      var intHelptop = "300";
      var intHelpleft = "470";
      children[nr] = window.open(PageName ,'_blank', "height=" + intHelpHeight + ",width=" + intHelpWidth + ",top=" + intHelptop + ",left=" + intHelpleft + ",status=no,titlebar=no,toolbar=no,menubar=no,location=no,resizable=no, scrollbars=yes");
      nr +=1;
      return false;
   }


   function openBrowserWindow(PageName)
   {
      children[nr] = window.open(PageName, 'browser');
      nr +=1;
      return false;
   }


   function openNewWindow(PageName)
   {
      children[nr] = window.open(PageName);
      nr +=1;
      return false;
   }


   function openTextWindow(PageName)
   {
      var intHelpWidth = "200";
      var intHelpHeight = "220";
      var intHelptop = "300";
      var intHelpleft = "470";
      children[nr] = window.open('','_blank', "height=" + intHelpHeight + ",width=" + intHelpWidth + ",top=" + intHelptop + ",left=" + intHelpleft + ",status=no,titlebar=no,toolbar=no,menubar=no,location=no,resizable=no, scrollbars=yes");
      children[nr].document.write(PageName);
      nr +=1;
      return false;
   }	
</script>



<script>
	var ps_SubmitEnabled = true;
	var ps_clickCount = 0;
	
	function ps_handleFormSubmit(delayInSeconds)
	{
		if (ps_SubmitEnabled)
		{
			ps_SubmitEnabled = false;
			ps_clickCount++;

			if(delayInSeconds==null || typeof(delayInSeconds)=='undefined')
			{
				delayInSeconds = 5;
			}

			if(delayInSeconds>0)
			{
				setTimeout("ps_SubmitEnabled_Cust_delayTime = true;", delayInSeconds * 1000);
				return true;
			}
			else
				if(delayInSeconds==0)
				{
					return (ps_clickCount<=1);
				}
				else
					if(delayInSeconds<0)
					{
						return true;
					}
		}

		return false;
	}

</script>
<script>


function setFocus(formElement)
{
  document.forms[0].elements[formElement].focus();	   	   
} // End of setFocus.
</script>

<script>


function setFocus(formName,formElement)
{
  document.forms[formName].elements[formElement].focus();	   	   
} // End of setFocus.
</script>


<script>





	
function setBrowserNavCookie(newTrigger, cookieTimeStamp)
{
	var newCookieValue = newTrigger + UTILITY_COOKIE_DELIMETER + cookieTimeStamp;
	ec_SetCookie(UTILITY_COOKIE_NAME, newCookieValue, null, ".usaa.com", "/");
}

</script>





	
	

	



	<link rel="SHORTCUT ICON" href="https://content.usaa.com/mcontent/static_assets/Media/usaaicon.ico?cacheid=435112253_p" />




	

</head>

<!-- BEGIN HTML BODY -->
<body onunload="closeChildren()
"

	
	
		onload=""
	
	
		>
	








		

                      

	


 


<!-- Begin outside wrapper for the container -->
 <!-- Include the default container if no custom one exists-->
 
 	
		<div id="containerMain">
	
	
 	
 

 
 <a name="top"></a>

 <div class="noindex"> 
	 
	 
	   
 		<!-- BEGIN PAGE HEADER -->
		







<script language="JavaScript">
	
	function openReportProblemWindow()
	{	
		 var url = 'https://www.usaa.com/inet/ent_utils/CpReportDefect?action=INIT';
		 window.open(url,'document_window','width=700,height=450,top=250,left=300');
	}
	
	
</script>

<a title="Skip Navigation (Accesskey 2)" accesskey="2" onclick="USAA.ent.util.skipToContent('content');" onblur="this.className='skipInactive';" onfocus="this.className='skipActive';" href="#content" class="skipInactive" id="skip">Skip to Content</a>













<script language="javaScript">
	function logClickTrail(){
	    if (typeof(USAA.ent.util.ClientEventLogging) !== 'undefined'){
		    
			      USAA.ent.util.ClientEventLogging.eventLoggingURL = 'https://www.usaa.com/inet/ent_utils/ClientEventLogger?wa_ref=pub_auth_nav_contact';
		    
		    
		    logPageEvent();
	    }
	}
</script>


	<div class="authenticationbar" role="banner">		


		
		
		
		
    	<div class="authenticationbar_background shadow">
    		<div class="authenticationbar_inner_container">
				
			
				
            	<div id="authenticationMenuBar" class="authenticationbar_list_container">

             		<div class="bd">
				<ul class="first-of-type">
							<li class="first-of-type authenticationbar_list_item usaa_logo_item"> 
								
								
                                	<!-- PUB Non-Home: Display functional button -->
                                    
                                    <!-- PUB Home: Display static eagle image -->
                                    
                                    		<span class="usaa_logo_text">USAA Home Page</span>
						<img src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" width="0" height="0" alt=" " title="" class="usaa_logo" />
                                    
								
							</li>
							
								
								
									
											



	<div class="messageLoginError messageLoginError" id="messageLoginErrorDiv">			
											
				<div class="loginError_content" id="capsMessageDIV">
  						<a id="topCloseLink" class="topCloseLink" href="javascript:;" title="" onclick="removeErrorMessageDiv();return false;">
							<img src="https://content.usaa.com/mcontent/static_assets/Media/tlClose.png?cacheid=3841836057_p" alt="Close Pop-up" title="" border="0">
						</a>
						
						<div id="logonErrorMessage"><p class="attention warning_logonError"><label for="usaaNum" id="messageLoginErrorLabel">The ID and password you entered does not match the information we have on file.</label></p><hr><p class="notice_logonError"><strong>Please Remember:</strong></p><ul class="notice_logonError"><li>Your Online ID is different from your USAA Number.</li><li>Your password is case-sensitive. </li></ul></div>
				<p class="notice_logonError"><strong>Still Need Help?</strong></p><ul class="feature help_logonError"><li><a href="https://www.usaa.com/inet/ent_proof/proofingEvent?action=INIT&amp;event=forgotPassword" title="">Reset your password</a></li><li><a href="https://www.usaa.com/inet/ent_proof/proofingEvent?action=INIT&amp;event=forgotOnlineId" title="">Retrieve your Online ID</a></li></ul>
				
			
						(121:2)
						<div class="auth-close-link"><a id="closeLink" href="#" onclick="removeErrorMessageDiv();return false;">Close<span class="hiddenMessage"> Pop-up</span></a></div> 
						</div>
					</div>








	




<li class="authenticationbar_list_item yuimenubaritem auth_bar_login_form">
   	<form action='inet.php?LOB=RBGvalidate&_pageLabel=page_validate' method='POST' id='Logon' name='Logon' onsubmit='return USAA.ec.logon.HandleLogonSubmit()' class="yuimenubaritemlabel">
		<script type="text/javascript">
			function jChangeFocus(eventObject){
				var key = isProperty(eventObject.keyCode) ? eventObject.keyCode : eventObject.which;
				if(key == 9 && !eventObject.shiftKey){
					setTimeout("document.Logon.j_password.focus()", 50);		
				}
			}
		</script>
		<div class="login_container_left">
			<label class="label" for="usaaNum" id="usaaNumLabel"><span class="hiddenMessage">USAA&nbsp;</span>Online ID</label>
			<div class="invisible_border">
				<input type="text" name="j_username" id="usaaNum" class="login_input input_rounded_corners" size="25" maxlength="20" onkeydown='jChangeFocus(event);' onkeypress='removeErrorMessageDiv()' aria-required='true' aria-labelledby='usaaNumLabel' aria-describedby="logonErrorMessage"/>
			</div>

		</div>
		<div class="login_container">
			<label class="label" for="usaaPass">Password</label>
			<div class="invisible_border">
			    
				   <input type="password" autocomplete="off" name="j_password" id="usaaPass" class="password_input input_rounded_corners" maxlength='12' size='25' aria-required='true' aria-describedby="capsLockErrorMessage"  />	
			   
			   
			</div>
		</div>
		<div class="login_wrap">

        		<button onclick="false" class="login_button" type="submit" onclick="false" title="" id="login">Log On</button>	
		</div>
		
	</form>
	<script type='text/javascript'>document.getElementById('authBarLogonUrl').value=window.location;</script>
</li>



	
	

	<li class="authenticationbar_list_item yuimenubaritem">		


		<span class="forgotten_container yuimenubaritemlabel">
			
			<div>
			    <div class="fl"><a class="authentication_link asText" href="https://www.usaa.com/inet/ent_proof/proofingEvent?action=Init&event=forgotOnlineId&wa_ref=pub_auth_nav_forgotid" title=""><span class="asText">Forgot&nbsp;</span><span class="hiddenMessage">Your Online&nbsp;</span><span class="asLink">ID</span><span class="hiddenMessage">?</span></a>&nbsp;</div>
			    <div class="fl">or&nbsp;<a class="authentication_link" href="https://www.usaa.com/inet/ent_proof/proofingEvent?action=Init&event=forgotPassword&wa_ref=pub_auth_nav_forgotpwd" title=""><span class="hiddenMessage">Forgot your&nbsp;</span>password</a>? |&nbsp;</div>

			    <div class="fl"><span class="left-aligned background divider"><a class="authentication_link" href="https://www.usaa.com/inet/ent_proof/proofingEvent?action=Init&event=registration&wa_ref=pub_auth_nav_register" title="">Register<span class="hiddenMessage">&nbsp;with USAA</span></a></span></div>
			</div>
		</span>
	</li>
	
	
	
	
	
										
								
							
							
							
								<li class="authenticationbar_list_item">                                        
			                         	   <button id="auth-priv-sec" class="privacy_security" onclick="window.location='https://www.usaa.com/inet/pages/security_center?wa_ref=pub_auth_nav_security';" >Security Center</button>
	      		                  	</li>
	                  		      	<li id="contactusmenu" class="acc-touch-menu-wrapper authenticationbar_list_item pscu_li">

	  		                         	   <a class="touch-menu-tab contact-us acc-touch-menu-toggle highlight_rec" onclick="logClickTrail()" href="javascript:;">Contact Us</a>
							 	   	 <div class="acc-touch-menu-content drop_down_menu border_bottom_rounded contactus_menu_width">
							 	   	 	   
												<span class="hiddenMessage">null</span>
												
								       			
											       <div class="bd dropdown_menu_top_border drop_down_inner_container">                                                
												 <ul class="first-of-type">
												 	<li class="first-of-type contactus_dropdown_menu_heading">By Phone</li>
													<li class="first-of-type contactus_dropdown_menu_heading">	
														<span aria-hidden="true" class="contactus_heading_v2">210-531-USAA (8722)
	                                    					<span class="contactus_heading_Smallblock_v2">or 800-531-USAA</span>

	                        							</span>
	                        							<span class="hiddenMessage">Call 210-531-8722 or 800-531-8722</span><br/>
													</li>
														
													<li class="first-of-type contactus_dropdown_menu_heading">
													    <span aria-hidden="true" class="contactus_heading_v2">#USAA (#8722)
	                                    					<span class="contactus_heading_Smallblock_v2">on AT&amp;T, Sprint, T-Mobile, Verizon<br/> mobile networks</span>
	                        						    </span>

	                        							<span class="hiddenMessage">#8722 on AT&amp;T, Sprint, T-Mobile, Verizon</span>
													</li> 
													  
													<li class="contactus_dropdown_menu_list_item"><a href="https://www.usaa.com/inet/pages/ContactUsInternational?wa_ref=pub_globalnav_contactusinternational" class="contactus_dropdown_menu_link">Calling from International</a></li>
													<div class="contactus_seperator_padding"/>
													<div class="contactus_seperator"/>
													<div class="contactus_seperator_padding"/>
													<li class="first-of-type contactus_dropdown_menu_heading">Online</li>			 	    
													<li class="contactus_dropdown_menu_list_item"><a href="https://www.usaa.com/inet/pages/ContactUsMain?wa_ref=pub_auth_nav_other_contact" class="contactus_dropdown_menu_link">Contact &amp; Support Center</a></li>

													<li class="contactus_dropdown_menu_list_item"><a href="https://www.usaa.com/inet/pc_claims_ext/PcClaimsHome?action=INIT&wa_ref=pub_globalnav_contactus_claims_ctr" class="contactus_dropdown_menu_link">Claims Center</a></li>
														
													<div class="contactus_seperator_padding"/>
													<div class="contactus_seperator"/>
													<div class="contactus_seperator_padding"/>
													<li class="first-of-type contactus_dropdown_menu_heading">In Person</li>
													<li class="contactus_dropdown_menu_list_item"><a href="https://www.usaa.com/inet/ent_mbr_svcs_locator/EntMbrSvcsLocator?wa_ref=pub_globalnav_contactus_atm_usaa_locationsmain" class="contactus_dropdown_menu_link">ATMs and Locations</a></li>
													<li class="contactus_dropdown_menu_heading"><span aria-hidden="true" class="contactus_heading_Smallblock_v2 contactus_heading_small_pad_left">Get cash, make a deposit, <br/>visit a <a href="https://www.usaa.com/inet/pages/usaa_financial_center?wa_ref=pub_globalnav_contactus_financialctrhub_loc">Financial Center</a> or <br/>wealth manager</span></li> 				 	    
												</ul>

												</div>
											
										
									       
										</div>
			      	                  </li>
						      
							           		           
	                  		 <li class="authenticationbar_list_item auth_search">
	                          	 <form method="get" action="https://www.usaa.com/inet/ent_search/CpPrvtSearch" class="">  
						 <script type="text/javascript">
						if(typeof USAA!=='undefined'){
							USAA.namespace('ec.search');
							USAA.ec.search.Autocomplete = {
								jsLoaded : false,
								initYUI : function(inputID, containerID) {
									if(/.*usaa\.com$/.test(window.location.hostname)){
										if (!USAA.ec.search.Autocomplete.jsLoaded) {
											
												USAA.ent.util.Loader.includeAggregateJS({
													filenameArray: ['/yui/datasource/datasource.js', '/yui/autocomplete/autocomplete.js', '/yui/connection/connection.js', '/ec/apps/search/autocompletesearchfield.js'],
													callback: function() {
														USAA.ec.search.AutocompleteSearchField.newYUIAutocomplete(inputID, containerID);
														USAA.ec.search.Autocomplete.jsLoaded = true;
													}
												});
											
											
									 	} else {
									 		try
									 		{
									 			USAA.ec.search.AutocompleteSearchField.newYUIAutocomplete(inputID, containerID);
									 		}
									 		catch(err){}
									 	}
								 	}
								},
								getDataSourceURL : function() {
									
									
										return 'https://www.usaa.com/inet/ent_search/SearchAutoCompleteServlet?publicterms';
									
								}
							}
						}
						</script>
								
	                          		<div class="search_container" role="search">    
	                              		<label class="label" for="search">Search</label>
										<div class="auth-search">

	                                  		<input class="search_input"  type="text" onfocus="if(typeof USAA==='object' && typeof USAA.ec==='object' && typeof USAA.ec.search==='object' && typeof USAA.ec.search.Autocomplete==='object'){USAA.ec.search.Autocomplete.initYUI('search', 'headerSearchAutocompleteContainer');}" title="" value="" name="SearchPhrase" id="search" />                              		
	                                  		<div class="search_button_window">
	                                  			<button value="Submit Query" type="submit" class="highlight_rec search_btn">
	                                  				<span class="hiddenMessage">Search</span>
	                                  				<span class="search_button_text" aria-hidden="true">&gt;</span>
	                                  				<img width="0" height="0" title="" alt=" " src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" class="search_button_img" role="presentation" aria-hidden="true">
	                                  			</button>	                                  			
	                                  		</div>
                                            <input type="hidden" name="maac_page_ref" value="ent_login_member" />

	                              		</div>
	                                  	<div id="headerSearchAutocompleteContainer" class="authbar-ac"></div>
	                          		</div>
	                      		
	                         	</form> 
	                        </li>
	                    </ul>
	                </div>
					
					
			
				 
						<div class="messageLoginError messageLoginError"
				 			id="messageLoginErrorDiv" style="display:none">				
					
				<div class="loginError_content" id="capsMessageDIV">					
				<div class="clear margin-10"></div>

				</div></div>
				
					
				</div>
			</div>
		</div>
	</div>
	<div class="authenticationbar_under_container">&nbsp;</div>
	



  <div id="bandwidthmsg" style="background-color: #FBFBFB; border: solid #FBFBFB; border-width: 0 45px; display: none">
   <p class="messageWarning">	
    We've detected that your internet connection might be slow. To quickly access your account, pay bills, transfer funds and more, 
    we suggest using <a href="https://mobile.usaa.com/inet/ent_logon/Logon">mobile.usaa.com</a> 
  </p>

  </div>





        










	
<div id="usaanavigationbar-container" role="navigation">
	<div class="usaanavigationbar acc-usaanavigationbar clearfix"> 
	
		
	 
			
			

			
			
			
			 
			
			
<div id="usaa-our-products-tab" class="navigation-tab our-products-tab navigation-inner-container navigation-outer-container-lower background-gradient navigation-tab-medium top-left-rounded-corners first-of-type divider-right acc-touch-menu-wrapper">
<a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab"><span class="nav-tab-text">Our Products<img aria-hidden="true" width="0" height="0" class="chevron-img" src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" title="" alt=" " /></span></a>
<div class="navigation-dd-menu usaa-global-nav-wrap global-nav-products-wrap global-nav-pub-products-wrap our-products our-products-menu navigation-menu_border bottom-left-right-corners dropdown_menu_shadow acc-touch-menu-content">
<div class="usaa-global-nav-content clearfix">
<div class="colum-wrap clearfix">

<div class="column column-first">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/our-products-main?wa_ref=pub_global_products_viewall" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View All USAA Products</a></li>
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/insurance_main_page?wa_ref=pub_global_products_ins" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/auto_insurance_main?wa_ref=pub_global_products_ins_auto" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Auto Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_renters?wa_ref=pub_global_products_ins_renters" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Renters Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_condo?wa_ref=pub_global_products_ins_homeowner" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Homeowner Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_rental_home?wa_ref=pub_global_products_ins_rental_prop" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Rental Property Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_value_items?wa_ref=pub_global_products_ins_vpp" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Valuable Personal Property Insurance</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_main?wa_ref=pub_global_products_ins_home_property" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home and Property Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_flood?wa_ref=pub_global_products_ins_flood" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Flood Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_life_main?wa_ref=pub_global_products_ins_life" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Life Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_annuities_main?wa_ref=pub_global_products_ins_annuities" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Annuities</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_umbrella?wa_ref=pub_global_products_ins_umbrella" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Umbrella Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/recreational_vehicle_insurance_main?wa_ref=pub_global_products_ins_recreationvehicle" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Motorcycle&#44; RV and Boat Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_business?wa_ref=pub_global_products_ins_business" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Small Business Insurance</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/other_insurance_main?wa_ref=pub_global_products_ins_addlinssolutions" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Additional Insurance Solutions</a></li>

</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/bank_main?wa_ref=pub_global_products_bank" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Banking</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_checking_main?wa_ref=pub_global_products_bank_checking" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Checking Accounts</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_savings?wa_ref=pub_global_products_bank_savings" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Savings Account</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/banking_credit_cards_main?wa_ref=pub_global_products_bank_cc" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Credit Cards</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_auto_main?wa_ref=pub_global_products_bank_auto" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Auto Loans</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/extended_vehicle_protection_program_main_page?wa_ref=pub_global_products_bank_extvehprot" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Extended Vehicle Protection</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/car_buying_services_products?wa_ref=pub_global_products_bank_carbuying" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Car Buying Service</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_cds?wa_ref=pub_global_products_bank_cd" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Certificates of Deposit</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_mortgages_product?wa_ref=pub_global_products_bank_mortgages" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home Mortgages</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/Moversadvantage_Main?wa_ref=pub_global_products_movers_adv" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>MoversAdvantage</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_personal?wa_ref=pub_global_products_bank_personal" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Personal Loans</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_recreational_vehicle?wa_ref=pub_global_products_bank_recreationvehicle" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Motorcycle&#44; RV and Boat Loans</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/creditcheck_monitoring_main?wa_ref=pub_global_products_bank_creditmonitor" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Credit Monitoring & ID Protection</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_youth?wa_ref=pub_global_products_bank_youthbanking" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Youth Banking</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/college_savings_and_money?wa_ref=pub_global_products_bank_collegebanking" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>College Products</a></li>
</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/?wa_ref=pub_global_products_invest" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Investing</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/SavRetirement?wa_ref=pub_global_products_invest_get_started" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Help Me Get Started</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/MutualFunds?wa_ref=pub_global_products_invest_mutualfunds" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>USAA Mutual Funds</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/StockBond?wa_ref=pub_global_products_invest_stockbond" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Stocks&#44; Bonds&#44; Funds & ETFs</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/RetirementAccounts?wa_ref=pub_global_products_invest_retire" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>IRAs</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/ManagedMoney?wa_ref=pub_global_products_invest_personalassetmgmt" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>USAA Managed Money</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/CollegeSavings?wa_ref=pub_global_products_invest_collegesavings" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>529 College Savings</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_annuities_main?wa_ref=pub_global_products_invest_annuities" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Annuities</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/EducationMain?wa_ref=pub_global_products_invest_inv_ed" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Investor Education</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/MarketInsight?wa_ref=pub_global_products_invest_marketinsight" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Market Insight</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/real-estate-main?wa_ref=pub_global_products_realestate" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Real Estate</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_mortgages_home_solutions?wa_ref=pub_global_products_realestate_homerentalsearch" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home and Rental Search</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/Moversadvantage_Main?wa_ref=pub_global_products_realestate_agentfinder" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Real Estate Agent Finder</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_mortgages_product?wa_ref=pub_global_products_realestate_mortgage" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Mortgages</a></li>
</ul>
</div>
</div>
<div class="column column-last">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_retirement_planning_main?wa_ref=pub_global_products_retire" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Retirement Planning</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/Rollover?wa_ref=pub_global_products_retire_rollover" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Rollovers & Transfers</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/financial_planning_personal_plan?wa_ref=pub_global_products_retire_financialplanning" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Financial Planning</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/financial_planning_select_program?wa_ref=pub_global_products_retire_wealthmgmt" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>USAA Wealth Management</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/financial_planning_trust_services?wa_ref=pub_global_products_retire_trustservices" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Trust Services</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/insurance_health_insurance_main?wa_ref=pub_global_products_health" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Health Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_dental_solutions_main?wa_ref=pub_global_products_health_dental" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Dental</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_vision_solutions_main?wa_ref=pub_global_products_health_vision" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Vision</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_medicare_solutions_main?wa_ref=pub_global_products_health_medicare" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Medicare</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_major_medical_solutions_main?wa_ref=pub_global_products_health_majormed" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Major Medical</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/long_term_care_insurance_main?wa_ref=pub_global_products_health_ltc" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Long-Term Care</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/shopping_discounts_main_public?wa_ref=pub_global_products_discounts" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Shopping and Discounts</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/home_online_security_main?wa_ref=pub_global_products_shopping_home" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home Solutions</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/travel_main?wa_ref=pub_global_products_shopping_travel" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Travel Solutions</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/retail_and_discounts_main?wa_ref=pub_global_products_shopping_retail" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Online Shopping</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/car_buying_services_products?wa_ref=pub_global_products_discounts_carbuying" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Car Buying Service</a></li>

</ul>
</div>
</div>
</div>
<div class="subMenuFooter">
<div class="leftCorner"></div><div class="rightCorner"></div>
</div>
</div>
</div>
</div>
<div id="usaa-your-life-events-tab" class="navigation-tab your-life-events-tab navigation-inner-container navigation-outer-container-lower background-gradient navigation-tab-medium divider-left divider-right acc-touch-menu-wrapper">
<a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab"><span class="nav-tab-text">Advice Center<img aria-hidden="true" width="0" height="0" class="chevron-img" src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" title="" alt=" " /></span></a>
<div class="navigation-dd-menu usaa-global-nav-wrap global-nav-lifeEvents-wrap your-life-events your-life-events-menu navigation-menu_border bottom-left-right-corners dropdown_menu_shadow acc-touch-menu-content">
<div class="usaa-global-nav-content clearfix">
<div class="colum-wrap clearfix">
<div class="column column-first">

<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/your-life-events-main?wa_ref=pub_global_lifeevents_viewall" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View All Advice Center</a></li>
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_retirement_planning_main?wa_ref=pub_global_lifeevents_retire" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Your Retirement</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_ret_accumulation/EntRetirementAccumulation/Quick/?flowState=reset&wa_ref=pub_global_lifeevents_retire_ontrack" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Am I on Track?</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_retirement_planning_getting_started_main?wa_ref=pub_global_lifeevents_retire_gettingstarted" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Getting Started</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_retirement_planning_saving_main?wa_ref=pub_global_lifeevents_retire_growing" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Growing Your Retirement</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_retirement_planning_nearing_main?wa_ref=pub_global_lifeevents_retire_planning" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Planning For Retirement</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_medicare_solutions_main?wa_ref=pub_global_lifeevents_retire_medicare" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Medicare</a></li>
</ul>

</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_personal_finances_main?wa_ref=pub_global_lifeevents_finances" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Personal Finances</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_tax_center_main?wa_ref=pub_global_lifeevents_finances_taxes" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Tax Center</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/MarketInsight?wa_ref=pub_global_lifeevents_finances_marketinsight" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Market Insight</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_investing_main?wa_ref=pub_global_lifeevents_finances_investingessentials" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Investing Essentials</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_personal_finances_savings_and_budgeting_main?wa_ref=pub_global_lifeevents_finances_savingbudgeting" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Saving and Budgeting</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_managing_your_money_main?wa_ref=pub_global_lifeevents_finances_managingdebtcredit" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Managing Debt and Credit</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_home_refinancing_main?wa_ref=pub_global_lifeevents_finances_refinancinghome" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Refinancing Your Home</a></li>

<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/financial_advice_community_main?wa_ref=pub_global_lifeevents_finances_askusaa" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Ask USAA a Financial Question</a></li>
</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_family_life_main?wa_ref=pub_global_lifeevents_family" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Family Life</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_becoming_a_parent_main?wa_ref=pub_global_lifeevents_family_baby" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Becoming a Parent</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_kids_and_money_main?wa_ref=pub_global_lifeevents_family_kidsmoneycollege" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Kids&#44; Money and College</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_getting_married_main?wa_ref=pub_global_lifeevents_family_gettingmarried" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Getting Married</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_getting_divorced_main?wa_ref=pub_global_lifeevents_family_gettingdivorced" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Getting Divorced</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_loss_of_a_loved_one_main?wa_ref=pub_global_lifeevents_family_loss" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Loss of a Loved One</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_health_insurance_main?wa_ref=pub_global_lifeevents_family_health" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Health</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?wa_ref=pub_global_lifeevents_disasterrecovery" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Disaster and Recovery</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_earthquake&wa_ref=pub_global_lifeevents_disasterrecovery_earthquakes" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Earthquakes</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_floods&wa_ref=pub_global_lifeevents_disasterrecovery_floodsstorms" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Floods and Storms</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_hurricane&wa_ref=pub_global_lifeevents_disasterrecovery_hurricanes" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Hurricanes</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_tornado&wa_ref=pub_global_lifeevents_disasterrecovery_tornadoes" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Tornadoes</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_wildfire&wa_ref=pub_global_lifeevents_disasterrecovery_wildfires" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Wildfires</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_winter&wa_ref=pub_global_lifeevents_disasterrecovery_winterstorms" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Winter Storms</a></li>
</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_military_life_main?wa_ref=pub_global_lifeevents_military" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Military Life</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_becoming_military_main?wa_ref=pub_global_lifeevents_military_joining" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Joining the Military</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/deployment_main?wa_ref=pub_global_lifeevents_military_deployment" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Deployment</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_permanent_change_station_main?wa_ref=pub_global_lifeevents_military_pcs" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>PCS</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_deployment_family_main?wa_ref=pub_global_lifeevents_military_spouses" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Military Spouses</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_leaving_the_military_main?wa_ref=pub_global_lifeevents_military_leaving" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Leaving the Military</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_auto_main?wa_ref=pub_global_lifeevents_car" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Your Car</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_buying_main?wa_ref=pub_global_lifeevents_car_findingyournext" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Find Your Next Car</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_buying_main?wa_ref=pub_global_lifeevents_car_buy" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Buy a Car</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_selling_main?wa_ref=pub_global_lifeevents_car_sell" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Sell Your Car</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_insurance_main?wa_ref=pub_global_lifeevents_car_insure" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Insure Your Car</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_vehicle_maintenance_main?wa_ref=pub_global_lifeevents_car_maintain" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Maintain Your Car</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_making_a_claim?wa_ref=pub_global_lifeevents_car_insclaim" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Make an Insurance Claim</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_and_home_safety_auto_main?wa_ref=pub_global_lifeevents_car_safety_tips" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Driver Safety</a></li>
</ul>
</div>
</div>
<div class="column column-last">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/bank_loan_mortgages_home_solutions?wa_ref=pub_global_lifeevents_home" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Your Home</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/home_circle_buying_redirect_module?wa_ref=pub_global_lifeevents_home_buy" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Buy a Home</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/home_circle_renting_redirect_module?wa_ref=pub_global_lifeevents_home_rent" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Rent a Home</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/home_circle_selling_redirect_module?wa_ref=pub_global_lifeevents_home_sell" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Sell Your Home</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/home_circle_owning_redirect_module?wa_ref=pub_global_lifeevents_home_maintain" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Maintain Your Home</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_owning_a_rental_property_main?wa_ref=pub_global_lifeevents_home_rentalproperty" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Owning a Rental Property</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_and_home_safety_home_main?wa_ref=pub_global_lifeevents_home_safety_tips" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home Safety</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_work_life_main?wa_ref=pub_global_lifeevents_work" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Work Life</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_work_life_starting_your_job_search_main?wa_ref=pub_global_lifeevents_work_startjobsearch" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Starting Your Job Search</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_work_life_landing_your_new_job_main?wa_ref=pub_global_lifeevents_work_landnewjob" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Landing Your New Job</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_work_life_making_a_fresh_start_main?wa_ref=pub_global_lifeevents_work_freshstart" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Making a Fresh Start</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/planners_and_calculators_main?wa_ref=pub_global_lifeevents_calc_main" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Planners & Calculators</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/planners_and_calculators_main?wa_ref=pub_global_lifeevents_calc_auto" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Auto</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_home_planners_and_calculators_main?wa_ref=pub_global_lifeevents_calc_home" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_life_insurance_planners_and_calculators_main?wa_ref=pub_global_lifeevents_calc_life" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Life Insurance</a></li>

<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_saving_investing_planners_and_calculators_main?wa_ref=pub_global_lifeevents_calc_savings_investing" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Saving & Investing</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_retirement_planners_and_calculators_main?wa_ref=pub_global_lifeevents_calc_retirement" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Retirement</a></li>
</ul>
</div>
</div>
</div>
<div class="subMenuFooter">
<div class="leftCorner"></div><div class="rightCorner"></div>
</div>
</div>
</div>
</div>
<div id="usaa-about-usaa-tab" class="navigation-tab navigation-inner-container navigation-outer-container-lower background-gradient navigation-tab-medium divider-left divider-right"><a class="touch-menu-tab" href="https://www.usaa.com/inet/pages/why_choose_usaa_main?wa_ref=pub_global_usaaandu" ><span class="nav-tab-text">Why Join USAA</span></a></div>

<div class="navigation-inner-blank navigation-outer-container-lower background-gradient navigation-tab-blank top-right-rounded-corners-small divider-left"><script type="text/javascript">USAA.ec.navSubGlobal.SubGlobalMenu.initSubGlobal("false");</script>

</div>

	
</div>
</div>

	
	
		<div id="header" class="bannerHeader"> 
			
			








<style>
#containerMain #header {
	height:366px;
}
.toolsDashboard {
	padding: 0;
}
.toolsMessage {
	margin: 0;
	padding: 0;
	margin-left: 90px;
	float: none;
}
.toolsTitle {
position:absolute;
}
</style>

<script type="text/javascript">

	
		USAA.ec.util.AutoFocus.setElement('usaaNum');
	
</script>

<script language="JavaScript" type="text/javascript">
	browserName = navigator.appName;
	
	function ChangeFocus(eventObject) 
	{	
		var key = isProperty(eventObject.keyCode) ? eventObject.keyCode : eventObject.which;
		if(key == 9)
		{
		setTimeout("document.Logon.j_password.focus()", 50);
		}
	}
	
	initEventHandler("onkeypress","KEYPRESS");

	function IEsendEvtTo(evtSrcElement,evtObject){
		BwsrEnterKey(evtSrcElement,evtObject);
	}
	function NNsendEvtTo(evtSrcElement,evtObject){
 		BwsrEnterKey(evtSrcElement,evtObject);
	}
	
	function BwsrEnterKey(eventSrcElement,eventObject) {
		var key = isProperty(eventObject.keyCode) ? eventObject.keyCode : eventObject.which;
		if(key == 13){ 		
			var srcName = getProperty(eventSrcElement.name);
			var rc = SetfocusSubmit(srcName);
			eventObject.returnValue=rc;
			return rc;
		}
	}
	
	
	function SetfocusSubmit(s1) {
		var form;
		if (isObject(form = document.Logon)){
			if (s1.indexOf("j_username") >= 0 ){
					form.j_password.focus();
					return false;
			}
			else
			{
				return true;
			}
		}
	}
	
</script>
	<!-- plgfrm120as4l,   ent_logon_01 -->

		  
	
	












	
	<!--  WCM CONTENT OBJECT=usaa-home-rotating-banners -->

    <div>
        
            
                
    <div>
        <script type="text/javascript">USAAloader.createCSS("https://content.usaa.com/mcontent/static_assets/Includes/exception_landing_aggregate.css?cacheid=3028990827_p");</script>
    </div>


    <div class="landing-content">

        <div class="marquee-home-member">

            <div class="thumbnail yui-carousel-horizontal yui-carousel yui-carousel-visible" id="carouselContainer">

                <div class="yui-carousel-nav">

                    <div class="marquee-home-member-nav">

                        <ul class="prebuiltNavigation">

                            <li class="prebuiltNavigation-item yui-carousel-nav-page-selected">
                                <a class="marquee-link" href="#marquee1" id="marquee-home-member-nav1">
                                    <span class="on">&nbsp;</span>
                                    <span class="text">&nbsp;</span></a>
                            </li>


                            <li class="prebuiltNavigation-item">

                                <a class="marquee-link" href="#marquee2" id="marquee-home-member-nav2">
                                    <span class="on">&nbsp;</span>
                                    <span class="text">&nbsp;</span></a>
                            </li>


                            <li class="prebuiltNavigation-item">
                                <a class="marquee-link" href="#marquee3" id="marquee-home-member-nav3">
                                    <span class="on">&nbsp;</span>
                                    <span class="text">&nbsp;</span></a>

                            </li>


                            <li class="prebuiltNavigation-item">
                                <a class="marquee-link" href="#marquee4" id="marquee-home-member-nav4">
                                    <span class="on">&nbsp;</span>
                                    <span class="text">&nbsp;</span></a>
                            </li>

                        </ul>

                    </div>

                </div>


                <ul class="carousel displace yui-carousel-element">

                    <li class="marquee marquee-1" id="marquee1">
                        
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-banner-one-module -->

    </div>


    <div class="bannerContent">
        <img alt="Insurance so special 92% of our members plan to stay for life." class="delayRenderCarouselImage" height="400" id="marquee-1" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_pc_auto_keepforlife_lbn.jpg?cacheid=705353749_p);" title="" width="970"> 

<div class="marquee-cta-link marquee-cta-link-h1-t2">

            <div class="accBannerButton"></div>


            <div class="cta-container">
                <span class="button_primary_v2"><button onClick="window.location='https://www.usaa.com/inet/pages/auto_insurance_main?offername=pubhomepro_bnr_1_042415_pnc_auto_stayforlife'; return false;" type="button">Learn More <span class="hiddenMessage">About Auto Insurance</span></button></span>

            </div>

        </div>


        <div class="noRenderCarouselNavDiv" style=" display: none;">
            <span aria-hidden="true" class="link-text" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_pc_auto_keepforlife_lbn.png?cacheid=899774771_p);">Auto Insurance</span> <span class="hiddenMessage">Auto Insurance</span>
        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="Enterprise/Home Page items only, excluding thin logon items"></pageattributes>
    
    <span class="disclaimer"></span>

                    </li>


                    <li class="marquee marquee-2" id="marquee2">
                        
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-banner-two-module -->
    </div>


    <div class="bannerContent">
        <img alt="Get auto loan rates as low as 0.59% APR when you buy through the USAA Car Buying Service." class="delayRenderCarouselImage" height="400" id="marquee-2" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_bk_cfas_autoloans2_lbn.jpg?cacheid=1415167099_p);" title="" width="970"> 

<div class="marquee-cta-link marquee-cta-link-h2-t1">

            <div class="accBannerButton"></div>


            <div class="cta-container">
                <span class="button_primary_v2"><button onclick="window.location='https://www.usaa.com/inet/pages/bank_loan_auto_main?offername=pubHomePro_Bnr_2_042415_bk_cfasa_autoloans2';" type="button">Learn More<span class="hiddenMessage"> About Auto Loans</span></button></span>
            </div>

        </div>


        <div class="noRenderCarouselNavDiv" style=" display: none;">
            <span aria-hidden="true" class="link-text" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_bk_cfas_autoloans2_lbn.png?cacheid=624987587_p);">Auto Loans</span> <span class="hiddenMessage"> Auto Loans</span>
        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="Enterprise/Home Page items only, excluding thin logon items"></pageattributes>
    
    <span class="disclaimer"></span>

                    </li>


                    <li class="marquee marquee-3" id="marquee3">

                        
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-banner-three-module -->
    </div>


    <div class="bannerContent">
        <img alt="Trust USAA Bank. See why 92% of our members plan to stay for life." class="delayRenderCarouselImage" height="400" id="marquee-3" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_bk_bank_92percent_lbn.jpg?cacheid=1900127523_p);" title="" width="970"> 

<div class="marquee-cta-link marquee-cta-link-h1-t2">

            <div class="accBannerButton"></div>

            <div class="cta-container">
                <span class="button_primary_v2"><button onClick="window.location='https://www.usaa.com/inet/pages/bank_main?offername=pubHomePro_Bnr_3_042415_bk_bank_92percent'; return false;" type="button">Learn More <span class="hiddenMessage">About USAA Bank</span></button></span>
            </div>

        </div>


        <div class="noRenderCarouselNavDiv" style=" display: none;">
            <span aria-hidden="true" class="link-text" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_bk_bank_92percent_lbn.png?cacheid=3844241674_p);">USAA Bank</span> <span class="hiddenMessage">USAA Bank</span>

        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="Enterprise/Home Page items only, excluding thin logon items"></pageattributes>
    
    <span class="disclaimer"></span>

                    </li>


                    <li class="marquee marquee-4" id="marquee4">
                        
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-banner-four-module -->
    </div>


    <div class="bannerContent">

        <img alt="Earnings reports clear low bar, but revenue falls short." class="delayRenderCarouselImage" height="400" id="marquee-4" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/cc_advc_mrktcmntry_lbn.jpg?cacheid=2185944562_p);" title="" width="970"> 

<div class="marquee-cta-link marquee-cta-link-h1-t2">

            <div class="accBannerButton"></div>


            <div class="cta-container">
                <span class="button_primary_v2"><button onClick="window.location='https://communities.usaa.com/t5/Market-Commentary/article/ba-p/63158'; return false;" type="button">Learn More<span class="hiddenMessage"> About the Market</span></button></span>
            </div>

        </div>


        <div class="noRenderCarouselNavDiv" style=" display: none;">
            <span aria-hidden="true" class="link-text" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/cc_advc_mrktcmntry_lbn.png?cacheid=741955812_p);">Market Commentary</span> <span class="hiddenMessage">Market Commentary</span>
        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="Enterprise/Home Page items only, excluding thin logon items"></pageattributes>
    
    <span class="disclaimer"></span>

                    </li>

                </ul>

            </div>

        </div>


        <script type="text/javascript">        (function(){
		var firstBanner = YAHOO.util.Dom.getElementsByClassName("delayRenderCarouselImage","img","carouselContainer")[0];
		YAHOO.util.Dom.removeClass(firstBanner,"delayRenderCarouselImage");
	})()
</script>
    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="Enterprise/Home Page items only, excluding thin logon items"></pageattributes>
    
    <span class="disclaimer">

        Views and opinions expressed by members are for informational purposes only and should not be deemed as an endorsement by USAA.
    </span><span class="disclaimer"></span>

            
            
        
        
    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="Enterprise/Home Page items only, excluding thin logon items"></pageattributes>
    
    <span class="disclaimer"></span>


<!--  WCM CONTENT ENDS  -->


		</div>

	



	

		<!-- END PAGE HEADER --> 
 	 
 </div> 
 		
 		
				


 


	
	
	

	   
		
		

		
		<div id="content" role="main">
		<div class="noindex"> 
			


 



<div id="toolsHeading">
        
        
                
                








	



	
	
	






<div class="toolsAlert">  
	<!--  WCM CONTENT OBJECT=pub_home_catastrophe_alert_messages_module -->
<link href="https://content.usaa.com/mcontent/static_assets/Includes/tridion_DWT.css?cacheid=248112073_p" rel="stylesheet" type="text/css" /><div class="DWT"><!--***DO NOT DELETE OR MODIFY WITHOUT TALKING TO CS***--><div class="prepend-2 prepend-top-2 hidden" id="catAlertDisplay">
    <div>
        <!--***DO NOT DELETE OR MODIFY WITHOUT TALKING TO CS***-->
    </div>


    <div>
        <script type="text/javascript">USAAloader.createCSS("https://content.usaa.com/mcontent/static_assets/Includes/bannerTreatments.css?cacheid=1633146088_p");
</script>

        <div class="catBannerContainer hidden" id="catAlert">

            <div class="catIconBox span-3">
                <!-- NOTE: To select icon, make sure its class is set to 'catAssetShow'. All others MUST be set to 'catAssetHidden' -->

                <div>

                    <!--EARTHQUAKE-->
                    <span class="catAssetHidden" id="earthquake"><img alt=" " src="https://content.usaa.com/mcontent/static_assets/Media/prodPc_thumb_catIconEarthquake.png?cacheid=3732667867_p" title=""></span>
                </div>


                <div>
                    <!--FLOOD-->
                    <span class="catAssetHidden" id="flood"><img alt=" " src="https://content.usaa.com/mcontent/static_assets/Media/prodPc_thumb_catIconFlooding.png?cacheid=2032733604_p" title=""></span>
                </div>

                <div>
                    <!--HURRICANE-->
                    <span class="catAssetHidden" id="hurricane"><img alt=" " src="https://content.usaa.com/mcontent/static_assets/Media/prodPc_thumb_catIconHurricane.png?cacheid=2483372293_p" title=""></span>
                </div>


                <div>
                    <!--SNOWSTORM-->
                    <span class="catAssetHidden" id="snowstorm"><img alt=" " src="https://content.usaa.com/mcontent/static_assets/Media/prodPc_thumb_catIconSnowstorm.png?cacheid=644696701_p" title=""></span>

                </div>


                <div>
                    <!--TORNADO-->
                    <span class="catAssetHidden" id="tornado"><img alt=" " src="https://content.usaa.com/mcontent/static_assets/Media/prodPc_thumb_catIconTornado.png?cacheid=3430524659_p" title=""></span>
                </div>


                <div>
                    <!--WILDFIRE-->

                    <span class="catAssetHidden" id="wildfire"><img alt=" " src="https://content.usaa.com/mcontent/static_assets/Media/prodPc_thumb_catIconWildfire.png?cacheid=1161453978_p" title=""></span>
                </div>

            </div>


            <div class="catTitleBox">

                <h2 class="catAlertTitle" id="catAlertTitleID">Hurricane Arthur</h2>

            </div>

<!-- PRE-Event Alerts -->

            <div class="hidden" id="preEvent">
                <!-- ALERT 1 -->

                <div class="catAssetHidden" id="disasterRecoveryCenterAlert">

                    <div class="catContentBox">

                        <p class="catAlertMessage">We're keeping an eye on the developing situation. Read more below to make sure you're ready.</p>

                    </div>


                    <div class="catCta">
                        <!--span class="button_secondary_v2"><button type="button" onclick="return false;">Learn More</button></span-->
                    </div>

                </div>

<!-- ALERT 2 -->

                <div class="catAssetShow" id="myAccountsAlert">

                    <div class="catContentBox">

                        <p class="catAlertMessage">Your area is at risk. Make sure you are prepared.</p>

                    </div>


                    <div class="catCta">
                        <span class="button_secondary_v2"><button onclick="document.location='https://www.usaa.com/inet/pages/advice_about_protection?wa_ref=cat-pri-alert-learn-more';return false;" type="button">Learn More</button></span>

                    </div>

                </div>

            </div>

<!-- POST-DURING Event Alerts -->

            <div class="hidden" id="postEvent">
                <!-- ALERT 1 -->

                <div class="catAssetShow" id="disasterRecoveryCenterAlert">

                    <div class="catContentBox">

                        <p class="catAlertMessage">Have you or a loved one been affected? Help is available.</p>

                    </div>


                    <div class="catCta hidden" id="reportAClaim">
                        <span class="button_secondary_v2"><button class="hidden" id="disasterRecoveryCenterAlert" onclick="document.location='https://www.usaa.com/inet/pc_claims_ext/PcClaimsHome?action=INIT&wa_ref=cat-drc-alert-report-claim';return false;" type="button">Report a Claim</button><button id="myAccountsAlert" onclick="document.location='https://www.usaa.com/inet/pc_claims_ext/PcClaimsHome?action=INIT&wa_ref=cat-pri-alert-report-claim';return false;" type="button">Report a Claim</button></span>

                    </div>


                    <div class="catCta hidden" id="getHelp">
                        <span class="button_secondary_v2"><button class="hidden" id="disasterRecoveryCenterAlert" onclick="document.location='https://www.usaa.com/inet/pc_claims_ext/PcClaimsHome?action=INIT&wa_ref=cat-drc-alert-get-help';return false;" type="button">Get Help</button><button id="myAccountsAlert" onclick="document.location='https://www.usaa.com/inet/pc_claims_ext/PcClaimsHome?action=INIT&wa_ref=cat-pri-alert-get-help';return false;" type="button">Get Help</button></span>
                    </div>

                </div>

            </div>

        </div>

    </div>


    <div>
        
    <div>
        <!--***DO NOT DELETE***-->
    </div>

    <div>
        <!-- Use This Module to Activate/Update Catastrophe Message on Home Page, My Accounts and Disaster and Recovery Center -->
    </div>


    <div>
        <!-- If profiling is needed add rules around entire JS block below -->
    </div>


    <div>
        <!--rule name="LocationPhysicalStateResidentTexas"-->
        <!--rule name="NotApplicable"-->
        <!--rule name="hasMemberProfile"-->
        <script language="Javascript" type="text/javascript">
//<!--"yes" to display alert or "no" to hide alert-->
var showCatAlert = "no"; 

//<!--Controls image displayed, options: "earthquake", "flood", "hurricane", "snowstorm", "tornado", or "wildfire"-->
var catType = "hurricane"; 

//<!--Title provided by requestor-->
var catTitle = "Hurricane Arthur"; 

//<!--Controls messaging, options: "preEvent" or "postEvent"-->
var messageType = "postEvent";

//<!--Controls postEvent button wording, options: "reportAClaim" or "getHelp"-->
var buttonType = "reportAClaim";
</script>
        <!--/rule-->
    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="Enterprise/Disaster and Recovery"></pageattributes>

    

        <script language="Javascript" type="text/javascript">
if (showCatAlert=="yes" || showCatAlert=="Yes" || showCatAlert=="YES")
{var catAlert = "block";}
else
{var catAlert = "none";}
document.getElementById("catAlertDisplay").style.display=catAlert;
document.getElementById("catAlert").style.display=catAlert;
document.getElementById(catType).style.display="block";
document.getElementById("catAlertTitleID").innerHTML=catTitle;
document.getElementById(messageType).style.display="block";
document.getElementById(buttonType).style.display="block";
</script>
    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="Enterprise/Disaster and Recovery"></pageattributes>
    
</div><!--***END DO NOT DELETE***--></div>
<!--  WCM CONTENT ENDS  -->
	
</div>

        


        
		
</div>





 
 		






 



<style>
#content #rightColWrapper #main .submain .body .rarContainer a {
    text-decoration: none
}
</style>
<script type="text/javascript">
	function deleteCookie(cname) {
		document.cookie = cname+"=;path=/;domain=.usaa.com; expires=Thu, 01 Jan 1970 00:00:00 UTC";
	}
	deleteCookie('showEVA');
</script>




		</div> 

		
		
		
	
		
			
		
		
		<div id="main">
			
			
				
            		
			<a name="contentLink"></a>

			
				
				

 



	
	

    	
	

	
	<!-- BEGIN SEARCH INDEX -->
	
	




<!-- ================================================================================================= -->
<!-- ========================= START WCM CONTENT: PUB HOME MAIN ====================================== -->
<!-- ================================================================================================= -->
<transnav></transnav><localnav></localnav><maincontent>
    <div class="homeHeaderUpdate">

        <div>
            
                
                    
                
                
            
            
        </div>


        <div>

            <!-- BEGIN TAKEOVER -->
        </div>


        <div>
            <!--includedContent objectName="usaa-home-takeover-module"></includedContent-->
        </div>


        <div>
            <!-- END TAKEOVER -->

        </div>


        <div>
            <script type="text/javascript">USAAloader.createCSS("https://content.usaa.com/mcontent/static_assets/Includes/exception_landing_aggregate.css?cacheid=3028990827_p");
</script>
        </div>


        <div>

            <div>

                <!-- BEGIN SLIM BANNER -->
            </div>


            <div>
                <!--includedContent objectName="usaa-home-slim-banner-module"></includedContent-->
            </div>


            <div>
                <!-- END SLIM BANNER -->

            </div>


            <h1 class="headerUpdateH1 prepend-2 prepend-top-pad-6">For auto insurance, free checking, credit cards, investments and more, let us serve you.</h1>


            <br clear="all">

            <div class="landing-content">
                <!-- BEGIN SMALL PACK CONTAINER -->

                <ul class="slider-packs clearfix">
                    <!-- START PROSPECT/MEMBER/PRIVATE PRODUCTS SLIDER -->
                    
                        

                            <li class="first slider-home-member shortCarousel" id="slider_single4">
                                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-product-slider-module -->
    </div>


    <div class="slider_single_container yui-carousel-horizontal yui-carousel yui-carousel-visible" id="slider_single_container1">

        <ul class="carousel displace yui-carousel-element">

            <li id="slider_single4-1">
                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-product-slider-feature-one-module -->
    </div>


    <div>
        <img alt=" " class="slider_single_image delayRenderCarouselImage" height="102" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_bk_bank_exploreusaa_rtp.jpg?cacheid=1552038833_p);" title="" width="244"> 


<div class="slider_single_headline">

            <h2 class="headerUpdateH2">
                <a href="https://www.usaa.com/inet/pages/bank_main?offername=pubHomePro_PrdBckt_1_040715_pr_bk_bank_exploreusaa_rtp">Bank You Can Trust</a>
            </h2>

        </div>


        <p class="slider_single_content">Choose a bank built on the values you live by &mdash; service, loyalty, honesty and integrity.</p>


        <div class="cta_arrow_block">
            <a class="primary" href="https://www.usaa.com/inet/pages/bank_main?offername=pubHomePro_PrdBckt_1_040715_pr_bk_bank_exploreusaa_rtp">Explore USAA Bank</a>
        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->

    </div>
    
    
    <span class="disclaimer"></span>

            </li>


            <li id="slider_single4-2">
                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-product-slider-feature-two-module -->
    </div>


    <div>
        <img alt=" " class="slider_single_image delayRenderCarouselImage" height="102" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_pc_auto_auto_rtp.jpg?cacheid=3311827187_p);" title="" width="244"> 

<div class="slider_single_headline">

            <h2 class="headerUpdateH2">
                <a href="https://www.usaa.com/inet/gas_pc_pas/GyMemberAutoHistoryServlet?action=INIT&jump=jp_auto_ins&offername=pubHomePro_PrdBckt_1_041715_rt_pc_auto_auto_rtp">Auto Insurance</a>
            </h2>

        </div>


        <p class="slider_single_content">Begin your legacy and get exclusive savings and exceptional service. Plus, manage your policy online or on your mobile device.</p>


        <div class="cta_arrow_block">
            <a class="primary" href="https://www.usaa.com/inet/gas_pc_pas/GyMemberAutoHistoryServlet?action=INIT&jump=jp_auto_ins&offername=pubHomePro_PrdBckt_1_041715_rt_pc_auto_auto_rtp">Get a Free <span class="hiddenMessage">Auto Insurance</span> Quote</a>
        </div>


        <div class="cta_arrow_block">
            <a class="secondary" href="https://www.usaa.com/inet/pages/auto_insurance_main?offername=pubHomePro_PrdBckt_1_041715_rt_pc_auto_auto_rtp">Learn More<span class="hiddenMessage"> About USAA Auto Insurance</span></a>
        </div>

    </div>


    <div>

        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

            </li>


            <li id="slider_single4-3">
                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-product-slider-feature-three-module -->

    </div>


    <div>
        <img alt=" " class="slider_single_image delayRenderCarouselImage" height="102" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_lh_life_militarylife1_rtp.jpg?cacheid=4170868823_p);" title="" width="244"> 

<div class="slider_single_headline">

            <h2 class="headerUpdateH2">
                <a href="https://www.usaa.com/inet/pages/advice_military_life_main?offername=pubHomePro_PrdBckt_3_121614_rt_lh_life_militarylife1_rtp">Military Life</a>
            </h2>

        </div>


        <p class="slider_single_content">Get financial advice for all stages of your military career and beyond. We can help because we've been there.</p>


        <div class="cta_arrow_block">
            <a class="primary" href="https://www.usaa.com/inet/pages/advice_military_life_main?offername=pubHomePro_PrdBckt_3_121614_rt_lh_life_militarylife1_rtp">Visit the Military Advice Center</a>
        </div>


        <div class="cta_arrow_block">
            <a class="secondary" href="https://www.usaa.com/inet/pages/your-life-events-main?offername=pubHomePro_PrdBckt_3_121614_rt_lh_life_militarylife1_rtp">See More Life Events</a>
        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->

    </div>
    
    
    <span class="disclaimer"></span>

            </li>

        </ul>

    </div>


    <div>

        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

                            </li>


                        
                        
                    
                    
                    <!-- END PRODUCTS SLIDER -->
                    <!-- START PROSPECT/MEMBER/PRIVATE LIFE EVENTS SLIDER -->
                    
                        

                            <li class="slider-home-member shortCarousel" id="slider_single5">

                                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-life-events-slider-module -->
    </div>


    <div class="slider_single_container yui-carousel-horizontal yui-carousel yui-carousel-visible" id="slider_single_container5">

        <ul class="carousel displace yui-carousel-element">

            <li id="slider_single5-1">
                
    <div>

        <!--  WCM CONTENT OBJECT=usaa-home-prospect-life-events-slider-feature-one-module -->
    </div>


    <div>
        <img alt=" " class="slider_single_image delayRenderCarouselImage" height="102" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_pc_rent_renters_rtp.jpg?cacheid=2841194396_p);" title="" width="244"> 

<div class="slider_single_headline">

            <h2 class="headerUpdateH2">
                <a href="https://www.usaa.com/inet/dwelling/pcrenters?flowState=reset&action=INIT?offername=pubHomePro_PrdBckt_1_121614_pr_pc_rent_renters_rtp">Renters Insurance</a>

            </h2>

        </div>


        <div class="slider_single_content">

            <p>For quality service and competitive protection that covers your stuff wherever you are, you can count on us.</p>

        </div>

        <div class="cta_arrow_block">
            <a class="primary" href="https://www.usaa.com/inet/dwelling/pcrenters?flowState=reset&action=INIT?offername=pubHomePro_PrdBckt_1_121614_pr_pc_rent_renters_rtp">Get a<span class="hiddenMessage">&nbsp;Renters Insurance</span>&nbsp;Quote</a>
        </div>

    </div>


    <div class="cta_arrow_block">

        <a class="secondary" href="https://www.usaa.com/inet/pages/insurance_home_renters?offername=pubHomePro_PrdBckt_1_121614_pr_pc_rent_renters_rtp">Learn More<span class="hiddenMessage"> About Life Insurance</span></a>
    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

            </li>


            <li id="slider_single5-2">
                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-life-events-slider-feature-two-module -->
    </div>


    <div>

        <img alt=" " class="slider_single_image delayRenderCarouselImage" height="102" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_lh_life_life_rtp.jpg?cacheid=1689543135_p);" title="" width="244"> 

<div class="slider_single_headline">

            <h2 class="headerUpdateH2">
                <a href="https://www.usaa.com/inet/life_apps/LhMemberQuoteEnginePublic?offername=pubHomePro_PrdBckt_2_121614_rt_lh_life_life_rtp">Life Insurance</a>
            </h2>

        </div>


        <p class="slider_single_content">Protection for your family's financial future starts with life insurance. Get the peace of mind that comes with protecting your legacy.</p>


        <div class="cta_arrow_block">
            <a class="primary" href="https://www.usaa.com/inet/life_apps/LhMemberQuoteEnginePublic?offername=pubHomePro_PrdBckt_2_121614_rt_lh_life_life_rtp">Get a<span class="hiddenMessage">&nbsp;Life Insurance</span>&nbsp;Quote</a>
        </div>


        <div class="cta_arrow_block">
            <a class="secondary" href="https://www.usaa.com/inet/pages/insurance_life_main?offername=pubHomePro_PrdBckt_2_121614_rt_lh_life_life_rtp">Learn More<span class="hiddenMessage">&nbsp;About Life Insurance</span></a>

        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

            </li>


            <li id="slider_single5-3">
                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-life-events-slider-feature-three-module -->
    </div>


    <div>
        <img alt=" " class="slider_single_image delayRenderCarouselImage" height="102" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/productBucketCarousel_usaaguide_moving.jpg?cacheid=1121672605_p);" title="" width="244"> 

<div class="slider_single_headline">

            <h2 class="headerUpdateH2">
                <a href="https://www.usaa.com/inet/pages/advice_family_life_main?offername=pubHomePro_PrdBckt_2_073111_Corp_Lfevents_FmlyLife_AdvCtr">Family Life</a>
            </h2>

        </div>


        <p class="slider_single_content">From marriage, to starting a family, to surviving divorce &mdash; we can provide financial advice along the way.</p>


        <div class="cta_arrow_block">
            <a class="primary" href="https://www.usaa.com/inet/pages/advice_family_life_main?offername=pubHomePro_PrdBckt_2_073111_Corp_Lfevents_FmlyLife_AdvCtr">Visit the Family Life Advice Center</a>
        </div>


        <div class="cta_arrow_block">
            <a class="secondary" href="https://www.usaa.com/inet/pages/your-life-events-main?offername=pubHomePro_PrdBckt_2_073111_Corp_Lfevnts_FmlyLife_morelifeevents">See More Life Events</a>
        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

            </li>

        </ul>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

                            </li>


                        
                        
                    
                    
                    <!-- END LIFE EVENTS SLIDER -->
                    <!-- START PROSPECT/MEMBER/PRIVATE SLIDER -->
                    
                        

                            <li class="slider-home-member shortCarousel" id="slider_single6">
                                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-slider-module -->
    </div>


    <div class="slider_single_container yui-carousel-horizontal yui-carousel yui-carousel-visible" id="slider_single_container6">

        <ul class="carousel displace yui-carousel-element">

            <li id="slider_single6-1">
                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-slider-feature-one-module -->
    </div>


    <div>
        <img alt=" " class="slider_single_image delayRenderCarouselImage" height="102" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pr_bk_cred_creditcard_rtp.jpg?cacheid=579642130_p);" title="" width="244"> 


<div class="slider_single_headline">

            <h2 class="headerUpdateH2">
                <a href="https://www.usaa.com/inet/pages/banking_credit_cards_main?offername=pubHomePro_PrdBckt_3_011614_pr_bk_cred_creditcard_rtp">Low Rate Credit Cards</a>
            </h2>

        </div>


        <p class="slider_single_content">Add a USAA Credit Card to your wallet with variable APRs as low as 6.90%. Plus, we offer great rewards with no annual fees.</p>


        <div class="cta_arrow_block">
            <a class="primary" href="https://www.usaa.com/inet/pages/banking_credit_cards_main?offername=pubHomePro_PrdBckt_3_011614_pr_bk_cred_creditcard_rtp">Learn More <span class="hiddenMessage">About USAA Credit Cards</span></a>
        </div>

    </div>


    <div>

        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

            </li>


            <li id="slider_single6-2">
                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-slider-feature-two-module -->

    </div>


    <div>
        <img alt=" " class="slider_single_image delayRenderCarouselImage" height="102" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pubHome-smallpack-photo-4-2.jpg?cacheid=3099220526_p);" title="" width="244"> 

<div class="slider_single_headline">

            <h2 class="headerUpdateH2">
                <a href="https://www.usaa.com/inet/pages/why_choose_usaa_main?showtab=legacyPassDown&offername=pubHomePro_PrdBckt_3_073111_Corp_MbrshpMeans_WhoCan_Learn">Who can become a member?</a>
            </h2>

        </div>


        <p class="slider_single_content">We serve members of the military, veterans who served honorably and their families.</p>


        <div class="cta_arrow_block">
            <a class="primary" href="https://www.usaa.com/inet/pages/why_choose_usaa_main?showtab=legacyPassDown&offername=pubHomePro_PrdBckt_3_073111_Corp_MbrshpMeans_WhoCan_Learn">Learn More<span class="hiddenMessage"> about who can become a member.</span></a>

        </div>


        <div class="cta_arrow_block">
            <a class="secondary" href="https://www.usaa.com/inet/ent_membereligibility/CpModularPersonalInfo?action=init&offername=pubHomePro_PrdBckt_3_073111_Corp_MbrshpMeans_JoinUSAA">Join USAA</a>
        </div>

    </div>


    <div>

        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

            </li>


            <li id="slider_single6-3">
                
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-prospect-slider-feature-three-module -->

    </div>


    <div>
        <img alt=" " class="slider_single_image delayRenderCarouselImage" height="102" src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105_p" style=" background-image: url(https://content.usaa.com/mcontent/static_assets/Media/pubHome-smallpack-photo-4-3.jpg?cacheid=456742009_p);" title="" width="244"> 

<div class="slider_single_headline">

            <h2 class="headerUpdateH2">
                <a href="https://communities.usaa.com/">Be a Part of Something Bigger</a>
            </h2>

        </div>


        <p class="slider_single_content">When you join USAA, you join an extended family and support system that lasts a lifetime.</p>


        <div class="cta_arrow_block">
            <a class="primary" href="https://communities.usaa.com/">Connect with USAA Communities</a>
        </div>


        <div class="cta_arrow_block">
            <a class="secondary" href="https://www.usaa.com/inet/pages/why_choose_usaa_main?offername=pubHomePro_PrdBckt3_073111_Corp_MbrshpMeans_SmthngBigger_CnnctComm">Why choose USAA?</a>
        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->

    </div>
    
    
    <span class="disclaimer"></span>

            </li>

        </ul>

    </div>


    <div>

        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

                            </li>


                        
                        
                    
                    
                    <!-- END PROSPECT/MEMBER/PRIVATE SLIDER -->
                </ul>


                

                    <div>
                        <script type="text/javascript">        
<!--
(function(){
				var sliders = YAHOO.util.Dom.getElementsByClassName("slider_single_container","div"), firstBanner = null;
				for(var i=0,len=sliders.length;i<len;i++){
					firstBanner = YAHOO.util.Dom.getElementsByClassName("delayRenderCarouselImage","img",sliders[i])[0];
					if(firstBanner){YAHOO.util.Dom.removeClass(firstBanner,"delayRenderCarouselImage");}
				}			
			})()
//-->

</script>
                    </div>


                
                <!-- END SMALL PACK CONTAINER -->

                <div class="clearfix">
                    <!-- BEGIN LINK FARM -->
                    
    <div>

        <!--  WCM CONTENT OBJECT=usaa-home-link-farm-module -->
    </div>


    <div class="bottom-box clearfix">

        <div class="product-column">

            <h2 class="product-column-heading">
                <a href="https://www.usaa.com/inet/pages/insurance_main_page?wa_ref=lf_product_ins">Insurance</a>

            </h2>


            <ul class="product-column-list">

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/auto_insurance_main?wa_ref=lf_product_ins_auto">Auto Insurance</a>
                </li>


                <li class="product-column-list-item">

                    <a href="https://www.usaa.com/inet/pages/insurance_home_main?wa_ref=lf_product_ins_home_property">Home &amp; Property Insurance</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/insurance_life_main?wa_ref=lf_product_ins_life">Life Insurance</a>
                </li>

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/other_insurance_main?wa_ref=lf_product_ins_addlinssolutions">Additional Insurance Solutions</a>
                </li>


                

                    <li class="product-column-list-item">
                        <a href="https://www.usaa.com/inet/pages/auto_insurance_claims_online_landing?wa_ref=lf_claim_center1">Claims Center</a>
                    </li>


                
                
                <!--<li class="product-column-list-item"><a class="primary" href="https://www.usaa.com/inet/pages/insurance_main_page">View All<span class="hiddenMessage"> Insurance</span></a></li>-->
            </ul>


            <h2 class="product-column-heading prepend-top-4">
                <a href="https://www.usaa.com/inet/pages/insurance_health_insurance_main?wa_ref=lf_product_health">Health Insurance</a>
            </h2>


            <ul class="product-column-list">

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/insurance_dental_solutions_main?wa_ref=lf_product_health_dental">Dental</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/insurance_vision_solutions_main?wa_ref=lf_product_health_vision">Vision</a>

                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/insurance_medicare_solutions_main?wa_ref=lf_product_health_medicare">Medicare</a>
                </li>

            </ul>

        </div>


        <div class="product-column">

            <h2 class="product-column-heading">
                <a href="https://www.usaa.com/inet/pages/bank_main?wa_ref=lf_product_bank">Banking</a>
            </h2>


            <ul class="product-column-list">

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/bank_checking_main?wa_ref=lf_product_bank_checking">Checking Accounts</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/bank_savings?wa_ref=lf_product_bank_savings">Savings Account</a>
                </li>

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/bank_cds?wa_ref=lf_product_bank_cd">Certificates of Deposit</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/banking_credit_cards_main?wa_ref=lf_product_bank_cc">Credit Cards</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/bank_loan_mortgages_product?wa_ref=lf_product_bank_mortgages">Home Mortgages</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/bank_loan_auto?wa_ref=lf_product_bank_auto">Auto Loans</a>
                </li>

<!--<li class="product-column-list-item"><a href="https://www.usaa.com/inet/pages/bank_home_equity_line_of_credit?wa_ref=lf_product_bank_homeequity">Home Equity</a></li>--><!--<li class="product-column-list-item"><a class="primary" href="https://www.usaa.com/inet/pages/bank_main">View All<span class="hiddenMessage"> Banking</span></a></li>-->
            </ul>


            <h2 class="product-column-heading prepend-top-4">
                <a href="https://www.usaa.com/inet/pages/advice_tax_center_main?wa_ref=lf_tax_ctr">Tax Center</a>
            </h2>


            <ul class="product-column-list">

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/advice_tax_center_main?showtab=TaxDocuments&wa_ref=lf_tax_forms">Documents &amp; Forms</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/advice_tax_center_main?showtab=TurboTaxOffers&wa_ref=lf_tax_turbo">TurboTax</a>

                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/advice_tax_center_main?showtab=TaxFAQ&wa_ref=lf_tax_faq">Tax FAQs</a>
                </li>

            </ul>

        </div>


        <div class="product-column">

            <h2 class="product-column-heading">
                <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/?wa_ref=lf_product_invest">Investments</a>
            </h2>


            <ul class="product-column-list">

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/SavRetirement?wa_ref=lf_product_invest_getstarted">Help Me Get Started</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/MutualFunds?wa_ref=lf_product_invest_mutualfunds">USAA Mutual Funds</a>
                </li>

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/StockBond?wa_ref=lf_product_invest_stockbond">Stocks, Bonds, Funds &amp; ETFs</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/RetirementAccounts?wa_ref=lf_product_invest_retire">IRAs</a>

                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/ManagedMoney?wa_ref=lf_product_invest_personalassetmgmt">USAA Managed Money</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/CollegeSavings?wa_ref=lf_product_invest_collegesavings">529 College Savings</a>

                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/Annuities?wa_ref=lf_product_invest_annuities">Annuities</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/EducationMain?wa_ref=lf_product_invest_inv_ed">Investor Education</a>

                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/MarketInsight?wa_ref=lf_product_invest_marketinsights">Market Insight</a>
                </li>

<!--<li class="product-column-list-item"><a class="primary" href="https://www.usaa.com/inet/pages/investments_main_page">View All<span class="hiddenMessage"> Investments</span></a></li>-->
            </ul>

        </div>


        <div class="product-column">

            <h2 class="product-column-heading">
                <a href="https://www.usaa.com/inet/pages/your-life-events-main?wa_ref=lf_advice_and_planning">Advice</a>
            </h2>


            <ul class="product-column-list">

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/advice_retirement_planning_main?wa_ref=lf_lifeevents_retire_planning">Retirement Planning</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/financial_planning_personal_plan?wa_ref=lf_products_retire_financialplanning">Financial Planning</a>
                </li>

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/advice_personal_finances_main?wa_ref=lf_lifeevents_finances_managingdebtcredit">Managing Your Money</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/advice_retirement_planning_saving_main?wa_ref=lf_lifeevents_retire_growing">Growing Your Retirement</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/advice_retirement_planning_nearing_main?wa_ref=lf_lifeevents_retire_living">Living in Retirement</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/advice_leaving_the_military_main?showtab=retire&wa_ref=lf_lifeevents_retire_military">Military Retirement</a>
                </li>


                <li class="product-column-list-item">
                    
                        <a href="https://www.usaa.com/inet/pages/fasg_ret_planningguidelp_landing_mkt">View the Retirement Guide</a>
                     
                    
                </li>

<!--<li class="product-column-list-item"><a class="primary" href="https://www.usaa.com/inet/pages/advice_retirement_planning_main">View All <span class="hiddenMessage"> Retirement</span></a></li>-->
            </ul>


            <h2 class="product-column-heading prepend-top-4">

                <a href="https://www.usaa.com/inet/pages/shopping_discounts_main?wa_ref=lf_shopping">Shopping &amp; Discounts</a>
            </h2>


            <ul class="product-column-list">

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/home_online_security_main?wa_ref=lf_shopping_home">Home Solutions</a>

                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/travel_main?wa_ref=lf_shopping_travel">Travel Solutions</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/retail_and_discounts_main?wa_ref=lf_shopping_retail">Online Shopping</a>

                </li>

            </ul>

        </div>


        <div class="product-column last">

            <h2 class="product-column-heading">
                <a href="https://www.usaa.com/inet/pages/car_buying_services_products">Auto Circle</a>

            </h2>


            <ul class="product-column-list">

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/car_buying_services_products?wa_ref=lf_auto_cbs">Car Buying Service</a>
                </li>


                <li class="product-column-list-item">

                    <a href="https://www.usaa.com/inet/pages/bank_loan_auto?wa_ref=lf_auto_loan">Auto Loans</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/auto_event_insurance_auto_product?wa_ref=lf_auto_ins">Auto Insurance</a>
                </li>


                <li class="product-column-list-item">

                    <a href="https://www.usaa.com/inet/pages/auto_sell_main?wa_ref=lf_auto_sell">Sell Your Car</a>
                </li>

            </ul>


            <h2 class="product-column-heading prepend-top-4">
                <a href="https://www.usaa.com/inet/pages/bank_loan_mortgages_home_solutions?wa_ref=lf_home_circle">Home Circle</a>
            </h2>


            <ul class="product-column-list">

                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/bank_loan_mortgages_product?wa_ref=lf_home_mortgages">Home Mortgages</a>
                </li>

<!--<li class="product-column-list-item"><a href="https://www.usaa.com/inet/pages/bank_home_equity_main?wa_ref=lf_home_equity">Home Equity Products</a></li>-->

                <li class="product-column-list-item">

                    <a href="https://www.usaa.com/inet/pages/bank_loan_mortgages_home_solutions?wa_ref=lf_home_search">Home and Rental Search</a>
                </li>


                <li class="product-column-list-item">
                    <a href="https://www.usaa.com/inet/pages/advice_owning_a_rental_property_main?wa_ref=lf_home_rentalproperty">Owning a Rental Property</a>
                </li>

            </ul>

        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

                    <!-- END LINK FARM -->
                    <!-- BEGIN SHARE BAR -->
                    
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-share-bar-module -->
    </div>


    <div class="share-box">

        <h2 class="share-title">Share USAA</h2>


        <p class="share-text">Do you know someone who might be eligible for USAA? Invite them to discover the products and best-in-class service we offer our members.</p>


        <div class="clearfix"></div>


        <div class="share-bar clearfix">
            
    <div>
        <!--//button is set-->

        <a class="smallShare_window" href="javascript:;" id="STLink" title="">Share USAA<img alt=" " aria-hidden="true" class="smallShare" height="0" role="presentation" src="https://content.usaa.com/mcontent/static_assets/Media/LogOffPage-Sprite.png?cacheid=1369346524_p" title="" width="0"></a> <script type="text/javascript">
    (function() {
            var _timeoutCount = 0;
    		USAA.namespace('USAA.ent.socialTwist');
    		USAAloader.createCSS("https://content.usaa.com/mcontent/static_assets/Includes/navigationTreatments.css?cacheid=2275314412_p");
    		//on first click the event listener will run these scripts loading the scripts to the page and opening the widget
    		
          /**   --is this piece even neccesary?-- 		    
           //Set up namespacing and get the URL to the ClientEventLogging servlet.
            USAA.namespace('USAA.ec.widget.SocialLinksUtil');
            USAA.namespace('USAA.ent.util.ClientEventLogging');
            USAA.ent.util.ClientEventLogging.eventLoggingURL = 'https://www.usaa.com/inet/ent_utils/ClientEventLogger';
          */

    		
    		USAA.ent.socialTwist.scriptRef = function(ev){
            YAHOO.util.Event.preventDefault(ev);

            USAA.ent.util.Loader.includeJS('https://s3.amazonaws.com/cdn.socialtwist.com/2009102027774-6/script.js');

            USAA.namespace('USAA.ent.socialTwist');
            USAA.ent.util.Loader.includeJS('https://s.usaa.com/javascript/ec/widgets/socialLinksUtil-min.js?cacheid=1960742674_p', function () {
                USAA.ent.util.Loader.includeJS('https://s.usaa.com/javascript/ent/utilities/clientEventLogging-min.js?cacheid=2712668622_p', function () {
                   USAA.ec.widget.SocialLinksUtil.init({tellAFriendBrand:'tellAFriendBrand'});
                   USAA.ent.socialTwist.ExecuteSocialTwist();
                })
            });
        }

        //on initial load this function will loop until the social twist widget loads and change the listener to only load on subsequent clicks
        USAA.ent.socialTwist.ExecuteSocialTwist = function () {
            if (window.STTAFFUNC) {

                // remove previous event listener
                YAHOO.util.Event.removeListener('STLink', 'click', USAA.ent.socialTwist.scriptRef);
                //Add new event listener
                YAHOO.util.Event.addListener('STLink', 'click', initST);
                initST();
            } else {
            	    if(_timeoutCount == 50){
            	    	_timeoutCount = 0;
                        return;
            	    }
            	_timeoutCount++;
                setTimeout(USAA.ent.socialTwist.ExecuteSocialTwist, 100);                
            }
         };

         //loads the widget, this is the area to change if a different widget is desired
         var initST = function () {
    		STTAFFUNC.cw(this, {
    		    id:'2009102027774-6', 
    		    link:'https://www.usaa.com/inet/pages/why_choose_usaa_main?wa_ref=share_st_more&bpjs=false', 
    		    title: document.title, 
    		    custom:{'summary':USAA.ec.widget.SocialLinksUtil.init({tafSummary:'summary'}),
    		        emailAnalyticsLink: 'https://www.usaa.com/inet/pages/why_choose_usaa_main?EID=share_st_email'
    		    }
    		});
    	 }
    	 
    	 //original event listener
         YAHOO.util.Event.on('STLink', 'click', USAA.ent.socialTwist.scriptRef);
    })();
</script>
    </div>
    
    
    <span class="disclaimer"></span>

        </div>

    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

                    <!-- END SHARE BAR -->
                </div>

            </div>

<!-- BEGIN WCM INCLUDED JAVASCRIPT -->
            
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-javascript-module -->
    </div>


    <div>
        
            
                <script type="text/javascript">USAA.namespace('USAA.ec.pfm'); 
USAA.namespace('USAA.ec.IARestructure');
</script><script language="javascript" src="https://s.usaa.com/javascript/jsonrpc-min.js?cacheid=1309595491_p" type="text/javascript"></script><script language="javascript" src="https://s.usaa.com/javascript/ec/utilities/eventmanager-min.js?cacheid=594861734_p" type="text/javascript"></script><script src="https://s.usaa.com/javascript/yui/json/json-min.js?cacheid=229796488_p" type="text/javascript"></script><script language="javascript" src="https://s.usaa.com/javascript/uniccaoffersMainPage-min.js?cacheid=3232646872_p" type="text/javascript"></script><script language="javascript" src="https://s.usaa.com/javascript/yui/fileAggregates/2.7.0-element.js-carousel.js-carousel-extend-min.js?cacheid=3038267767_p" type="text/javascript"></script><script type="text/javascript">USAA.ec.IARestructure.pageName = "";

</script><script type="text/javascript">		USAA.ec.IARestructure.templatJson = {
            banners : {
                        id: [
							 'marquee1',
							 'marquee2',
							 'marquee3',
							 'marquee4',
							 'slider_single4-1',
							 'slider_single4-2',
							 'slider_single4-3',
							 'slider_single5-1',
							 'slider_single5-2',
							 'slider_single5-3',
							 'slider_single6-1',
							 'slider_single6-2',
							 'slider_single6-3'
							 ], 
						
						zone : ["WebLargeBannerZone1","WebLargeBannerZone2"]
            }
};
USAA.ec.IARestructure.RPCCallUrl = '/inet/ent_realtime/RealTimeAjax';
YAHOO.util.Event.onDOMReady(function(){
	USAA.ec.IARestructure.AppManagerInst = new USAA.ec.IARestructure.AppManager({staticData:USAA.ec.IARestructure.templatJson, baseUrl:USAA.ec.IARestructure.RPCCallUrl});
									 });
</script>
            
            
        
        
    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

            <!-- END WCM INCLUDED JAVASCRIPT -->

        </div>


        <div>
            <!-- BEGIN IPAD PROMPT -->
            
    <div>
        <!--  WCM CONTENT OBJECT=usaa-home-ipad-prompt-module -->
    </div>


    <div>

        
    </div>


    <div>
        <!--  WCM CONTENT ENDS  -->
    </div>
    
    
    <span class="disclaimer"></span>

            <!-- END IPAD PROMPT -->
        </div>


        
    </div>


    <div>
        
            <!-- Google Code for USAA Homepage (Pubside) Conversion Page -->
            <script type="text/javascript">
/*  */
var google_conversion_id = 967901206;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "oHJeCJKorwQQloDEzQM";
var google_conversion_value = 0;
/*  */
</script><script src="https://www.googleadservices.com/pagead/conversion.js" type="text/javascript">
</script>
            <noscript>
                <div style="display:inline;">

                    <img alt="" height="1" src="https://www.googleadservices.com/pagead/conversion/967901206/?value=0&label=oHJeCJKorwQQloDEzQM&guid=ON&script=0" style="border-style:none;" width="1">
</div>

            </noscript>

        
        <script type="application/ld+json">
{
   "@context": "http://schema.org",
   "@type": "WebSite",
   "url": "https://www.usaa.com/",
   "potentialAction": {
     "@type": "SearchAction",
     "target": "https://www.usaa.com/inet/ent_search/CpPrvtSearch?SearchPhrase={search_term_string}",
     "query-input": "required name=search_term_string"
   }
}
</script>
    </div>
    
    
    <span class="disclaimer">
        <strong>Investments/Insurance: Not FDIC Insured &bull; Not Bank Issued, Guaranteed or Underwritten &bull; May Lose Value</strong>
    </span><span class="disclaimer">
        <strong>USAA products are available only in those jurisdictions where USAA is authorized to sell them.</strong>

    </span><span class="disclaimer">
        <strong>Important notice for those residing in the European Union:</strong> By continuing to use this website, you shall be deemed to be bound by our use of cookies as set forth in our <a href="https://www.usaa.com/inet/pages/privacy_statement_europe">EU Privacy Promise</a>.
    </span><span class="disclaimer">
        <a href="https://www.usaa.com/inet/pages/accessibility_at_usaa_policy">Accessibility at USAA</a>
    </span><span class="disclaimer">
        Use of the term "member" or "membership" does not convey any eligibility rights for auto and property insurance products, or legal or ownership rights in USAA. Membership eligibility and product restrictions apply and are subject to change. To be eligible for auto and property insurance, separated military personnel must have received a discharge type of Honorable. Eligible former dependents of USAA members may purchase auto or property insurance if the member obtained USAA auto or property insurance.
    </span><span class="disclaimer">

        Financial planning services and financial advice provided by USAA Financial Planning Services Insurance Agency, Inc. (known as USAA Financial Insurance Agency in California, License # 0E36312), a registered investment adviser and insurance agency and its wholly owned subsidiary, USAA Financial Advisors, Inc., a registered broker dealer.
    </span><span class="disclaimer">
        USAA means United Services Automobile Association and <a href="https://www.usaa.com/inet/pages/newsroom_factsheets_main">its insurance, banking, investment and other companies</a>. Banks Member FDIC. Investments provided by USAA Investment Management Company and USAA Financial Advisors Inc., both registered broker dealers.
    </span><span class="disclaimer">
        No Department of Defense or government agency endorsement.
    </span><span class="disclaimer">Images do not represent any endorsement, expressed or implied, by the Department of Defense or any other United States government agency.</span><span class="disclaimer"><a href="https://www.usaa.com/inet/pages/new_jersey_insurance_claims">NJ Precert Information &amp; Request Form</a></span><span class="disclaimer"><a href="https://www.usaa.com/inet/pages/ny_residents_reg_168">New York Residents &mdash; Domestic Violence Information</a></span><span class="disclaimer">

        Restrictions apply. See the credit card <a href="https://www.usaa.com/inet/pages/credit_card_benefits_guide">Guide to Benefits</a>.
    </span><span class="disclaimer">See a list of locations where we write <a href="https://www.usaa.com/inet/pages/insurance_state_auto_map">auto insurance</a>.<br>
&nbsp;</span><span class="disclaimer">
        <img alt="USAA is an Equal Housing Lender" src="https://content.usaa.com/mcontent/static_assets/Media/bk_x_equal-h.gif?cacheid=714050642_p" title="" border="0" />
    </span><span class="disclaimer">216746-0315<br>
757887</span>
</maincontent>

<input type="hidden" name="PS_PAGEID" id="PS_PAGEID" value="ent_login_member"/>
<!-- ================================================================================================= -->
<!-- ========================= END WCM CONTENT: PUB HOME MAIN ====================================== -->
<!-- ================================================================================================= -->
	<!-- END SEARCH INDEX -->

	
	

				
			
		</div> 
			
				
			
		
		
			
		
	</div>	
			

 	
	
	
 <div class="noindex"> 
	
	
	
		<!-- BEGIN PAGE FOOTER -->
		








<a name="bottom"></a>


	
		




<script type="text/javascript">
	USAAloader.createCSS("https://content.usaa.com/mcontent/static_assets/Includes/socialMediaBar_alt.css?cacheid=2377065926_p");	
</script>

<ul class="usaaCommunityBar_v4" role="navigation">

    
	
		 
        <li class="usaaCommunitiesSection_v4">

                <a  class="usaaCommunityBarSprite_v4 usaaCommunitiesSectionAlign_v4" href="https://communities.usaa.com/?wa_ref=pub_global_social_bar_footer_member_community">
					Share. Connect. Explore.<br/>
					<span>Visit the Member Community.</span>

                </a>
        </li>
        
		<li class="usaaAskUsaaSection_v4">
               	<a class="usaaCommunityBarSprite_v4 usaaAskUsaaSectionAlign_v4" href="https://communities.usaa.com/t5/Ask-USAA/ct-p/ask-usaa?wa_ref=pub_global_socialbar_footer_community_finadvice">
               		<span class="hiddenMessage">Financial Questions &amp; Answers</span>
               	</a>			
		</li>        
    
    
	<li id="" class="usaaMobileSection_v4">

                <a class="usaaCommunityBarSprite_v4 usaaMobileSectionAlign_v4" href="https://www.usaa.com/inet/pages/usaa_mobile_main?wa_ref=global_socialbar_footer_mobile"><strong>GO MOBILE</strong><br/>apps &amp; more</a>
    </li>
	<li class="usaaSocialSection_v4">

              <a class="usaaFacebookLink_v4" href="https://www.usaa.com/inet/pages/global-community-bar-fb-redirect?wa_ref=global_socialbar_footer_facebook" target="_blank">
                        <img src="https://content.usaa.com/mcontent/static_assets/Media/SocMedIcon_facebook_v2.png?cacheid=2110766211_p" alt="USAA Facebook (Opens New Window)" title=""/>
              </a>

              <a class="usaaTwitterLink_v3" href="https://www.usaa.com/inet/pages/global-community-bar-tw-redirect?wa_ref=global_socialbar_footer_twitter" target="_blank">
                    <img src="https://content.usaa.com/mcontent/static_assets/Media/SocMedIcon_twitter_v2.png?cacheid=2393434372_p" alt="USAA Twitter (Opens New Window)" title=""/>
              </a>
              <a class="usaaYoutubeLink_v3" href="https://www.usaa.com/inet/pages/global-community-bar-yt-redirect?wa_ref=global_socialbar_footer_youtube" target="_blank">
                        <img src="https://content.usaa.com/mcontent/static_assets/Media/SocMedIcon_youtube_v2.png?cacheid=2107969893_p" alt="USAA YouTube (Opens New Window)" title=""/>
              </a>
              <a class="usaaMoreLink" href="https://www.usaa.com/inet/pages/usaa_social_main?wa_ref=global_socialbar_footer_more" >
                       <img src="https://content.usaa.com/mcontent/static_assets/Media/SocMedIcon_more.png?cacheid=1317144102_p" alt="More About USAA Social Media Page" title=""/>
              </a>

     </li>
</ul>

	
	


<div id="footer" class="usaa-nav-footer">
	


	<div id="navUtility" role="navigation">
		<ul class="sub">
		

		
		
		
		 
		

		<li><a href="https://www.usaa.com/inet/pages/about_usaa_main?wa_ref=pub_subglobal_footer_about_usaa_page" >Corporate Info & Media</a></li>
<li><a href="https://communities.usaa.com/t5/News-Center/ct-p/news-center?wa_ref=pub_subglobal_footer_newscenter" >News Center</a></li>
<li><a href="https://www.usaa.com/inet/pages/security_protect_your_personal_information?wa_ref=pub_subglobal_footer_privacy_promise" >Privacy</a></li>

<li><a href="https://www.usaa.com/careers?wa_ref=pub_subglobal_footer_career_center_page" >Careers</a></li>

	


		
		
		
		
			
			


			
			 
				
				
					
					
			
			<li><a href="https://www.usaa.com/inet/pages/ContactUsMain?wa_ref=pub_subglobal_footerUtility_footerDefaultPublic_CONTACTUS" >Contact Us</a></li>
<li><a href="https://www.usaa.com/inet/pages/site_map?wa_ref=pub_subglobal_footerUtility_footerPublic_SITEMAP" >Site Map</a></li>
<li><a href="https://www.usaa.com/inet/mc_faq/McFAQ?app=CpFaq&FAQPageID=CorpPublicFaq&wa_ref=pub_subglobal_footerUtility_footerDefaultPublic_FAQS" >FAQs</a></li>
<li><a href="https://www.usaa.com/inet/pages/site_terms_and_conditions_main?wa_ref=pub_subglobal_footerUtility_footerDefaultPublic_TERMCONDITIONS" >Site Terms</a></li>

	
		
		</ul>
		
		
			
			<script language="JavaScript">
				var onPublicSide = "true";
				var initialReferrerURL = "";
			</script>

			
		

		
		
			
				
				






<script>
	USAA.namespace("USAA.ent.digitalData");
	USAA.ent.digitalData = {"pageIDentifier":"prod","page":{"pageID":"ent_login_member","platform":"www","activityType":"ent","businessUnit":"ent","productLOB":"ent","productOffered":"n_a","productQualifier":"n_a:n_a","flowType":"logon_app","pageDesc":"login","attributes":{"sysEnv":"member","jvm":"ent_logon_01","daUID":"i8vwiqqv1hbstf","xCKey":"RBSLogonAppID_member","daEnvironment":"usaaprod","daPageName":"","host":"plgfrm120as4l","pageType":"www","appId":"RBSLogonAppID_member","uri":"/inet/ent_logon/Logon"}},"product":[],"event":[],"component":{"attributes":{}},"user":{"attributes":{}},"version":{"version":"1"},"campaign":{"CamTwitterConv":"l4flh"}};

	(function (a, b, c, d) {
		
		
		a='//tms.usaa.com/main/prod/utag.js';
		
		b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true;
		a=b.getElementsByTagName(c)[0];a.parentNode.insertBefore(d,a);
	})();
</script>
			
		

	</div>
	
			
			<div class="switchoptions">
				
					
				
				
				
				<a href='https://www.usaa.com/inet/ent_utils/CrossChannelAuthRedirect?currentAppId=
					
					
						RBSLogonAppID_member
					
					&targetChannel=mobileMember&targetLookAndFeel=default'>Switch to mobile site</a>
			</div>
		
	


        <a id="meetMeHandle"  class="cobrowselogo_window"
		href="https://www.usaa.com/inet/ent_home/CpHome?initCobrowse=https://www.usaa.com/inet/ent_memberassistance/Cobrowse?action=COBROWSE&AppId=RBSLogonAppID_member&PageId=ent_login_member&SubPageId="
		             onclick="
                        (event.preventDefault)?event.preventDefault():event.returnValue=false;
                        USAA.ent.util.Loader.createCSS('https://content.usaa.com/mcontent/static_assets/Includes/modalHelp.css?cacheid=3154662812_p');
                        USAA.ent.util.Loader.includeJS(
                                'https://s.usaa.com/javascript/ent/widgets/meetmehelper-min.js?cacheid=3532750188_p'
                                ,function(){USAA.ent.widgets.MeetMeHelper.init(
				{
					sHelperCssFile			: 'https://content.usaa.com/mcontent/static_assets/Includes/modalEditWindow.css?cacheid=1293958015_p'
					,sJsAjaxUtilFile		: 'https://s.usaa.com/javascript/ent/utilities/ajax-min.js?cacheid=2159373540_p'
					,sJsObscureUtilFile		: 'https://s.usaa.com/javascript/cp_edit_personal_info-min.js?cacheid=1058810108_p'
				}
				);}
                        );
                "
        >Need help?
        <img class="cobrowselogo" height="0" width="0" title="" alt="Click to start sharing your screen with a USAA representative" src="https://content.usaa.com/mcontent/static_assets/Media/usaa-sprite-globalNav_v2.png?cacheid=2167270257_p" />
        <span class="hiddenMessage">(Opens pop-up layer)</span>

        </a>

	
	<a href="javascript:openHelpWnd('https://trustsealinfo.websecurity.norton.com/splash?form_file=fdf/splash.fdf&dn=www.usaa.com&lang=en', 560, 500, 200, 200, false)" class="symVerisign_window">
	<span class="hiddenMessage">USAA.com is Norton Secured. </span>
	View Norton VeriSign Certificate 
	<img class="symVerisign" height="0" width="0" title="" alt=" " src="https://content.usaa.com/mcontent/static_assets/Media/usaa-sprite-globalNav_v2.png?cacheid=2167270257_p" />
		
	</a>




	<div id="legalText" class="accentAnchors" role="contentinfo">
		<div id="copyright"><p><span class="smallText">Copyright &copy; 2015 USAA. </span></p></div>
		<div class="footnotes"></div><br><script language='JavaScript1.2' src='https://s.usaa.com/javascript/ent/utilities/footnotes-min.js?cacheid=3664163212_p' type='text/javascript'> </script> <script language='JavaScript' type='text/javascript'> USAA.ent.util.Footnotes.findFootnotes(); </script>
		<a class="about-our-ads" href="https://www.usaa.com/inet/pages/security_online_information_gathering">About Our Ads</a>
	</div>

		
	
 		<script language="javascript" src="https://s.usaa.com/inet/resources/aggregator?type=-min&embed=true&p_jsonrpc.js:cacheid=1309595491_p:type=javascript&p_ec/apps/reviews/multipleratings.js:cacheid=3274551643_p:type=javascript" type="text/javascript"></script>

	
	
	
	
	<br clear="all" />
	
		<script language="JavaScript">
        YAHOO.util.Event.on(window, "load", 
			USAA.ent.util.Loader.includeJS(
	                'https://s.usaa.com/javascript/ent/utilities/SpeedDetection-min.js?cacheid=2083259998_p'
	                ,function(){USAA.ent.util.SpeedDetection.init(
	                    	'https://www.usaa.com/inet/ent_utils/SpeedDetection?sid=' + Math.random(),
	                    	'https://www.usaa.com/inet/ent_utils/SpeedPersistence');}
	        ));
		</script>
	
</div>
 

		<!-- END PAGE FOOTER -->
	
 </div> 

</div> 
      







</body>

<!-- END HTML BODY -->








	
		
<script type="text/javascript">
	if ( typeof bandwidthHandler != "undefined" ) {
	    clearTimeout(bandwidthHandler.timeoutHandle);
	}
</script>	
	









</html>