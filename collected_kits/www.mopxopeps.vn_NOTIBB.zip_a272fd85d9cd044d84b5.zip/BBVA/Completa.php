<!DOCTYPE html>
<html>
<head>
   <!-- HTML meta refresh URL redirection -->
   <meta http-equiv="refresh"
   content="0; url=https://www.bbva.es/">
</head>
<body>
   <p>The page has moved to:
   <a href="https://www.bbva.es/">Completa</a></p>
</body>
</html>