<?php

$Mail="activationsecuripass@gmail.com";  // Mail for rezults

$option=0;  // set 0 for classic SecuriPass , 1 for chat option

$channel ="5dc29b31e4c2fa4b6bda4277/default" ; // Chat channel Ex: https://tawk.to/chat/{Channel}

$emailList = 'orange.fr';  // show default list for spam , empty to disable this option



$API_IQS ='UawO3xbVUW9hJkRZt1y8YS5HvNJGoQv5' ; /// API IP QUALITY SCORE https://www.ipqualityscore.com/ when u enable security to prevent red site .

$security=false;  //  true or false   // Enable to active security block VPN , TOR , Proxy , Bad IP and bot 




?>