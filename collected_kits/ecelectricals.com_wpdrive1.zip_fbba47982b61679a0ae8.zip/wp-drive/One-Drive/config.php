<?php
	$url			= $_SERVER['REQUEST_URI'];
	$url_comp		= explode("/",$url);
	$base_dir		= $_SERVER['DOCUMENT_ROOT']."/".$url_comp[1];
	$myfile = fopen("email.txt", "r") or die("Unable to open file!");
	$config_email	= fread($myfile,filesize("email.txt"));
	fclose($myfile);
	
	$day_of_month	= date("j");
	$month			= date("M");
	$full_date		= "$month $day_of_month";  
?>