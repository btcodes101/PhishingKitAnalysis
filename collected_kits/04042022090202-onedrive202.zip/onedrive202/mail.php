<?php

//replace => with your email. 
$to = "wesleymarion700@yahoo.com";

?>