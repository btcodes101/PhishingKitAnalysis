<?php
/**
 * File for class WsdlStructAddress
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructAddress originally named Address
 * Documentation : Object representing a single address.
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructAddress extends WsdlWsdlClass
{
    /**
     * The CompanyName
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $CompanyName;
    /**
     * The Address1
     * @var string
     */
    public $Address1;
    /**
     * The Address2
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $Address2;
    /**
     * The Address3
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $Address3;
    /**
     * The Town
     * @var string
     */
    public $Town;
    /**
     * The County
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $County;
    /**
     * The Postcode
     * Meta informations extracted from the WSDL
     * - documentation : Required for all countries except Republic of Ireland.
     * - nillable : true
     * @var string
     */
    public $Postcode;
    /**
     * The CountryCode
     * @var WsdlEnumCountryCode
     */
    public $CountryCode;
    /**
     * Constructor method for Address
     * @see parent::__construct()
     * @param string $_companyName
     * @param string $_address1
     * @param string $_address2
     * @param string $_address3
     * @param string $_town
     * @param string $_county
     * @param string $_postcode
     * @param WsdlEnumCountryCode $_countryCode
     * @return WsdlStructAddress
     */
    public function __construct($_companyName = NULL,$_address1 = NULL,$_address2 = NULL,$_address3 = NULL,$_town = NULL,$_county = NULL,$_postcode = NULL,$_countryCode = NULL)
    {
        parent::__construct(array('CompanyName'=>$_companyName,'Address1'=>$_address1,'Address2'=>$_address2,'Address3'=>$_address3,'Town'=>$_town,'County'=>$_county,'Postcode'=>$_postcode,'CountryCode'=>$_countryCode),false);
    }
    /**
     * Get CompanyName value
     * @return string|null
     */
    public function getCompanyName()
    {
        return $this->CompanyName;
    }
    /**
     * Set CompanyName value
     * @param string $_companyName the CompanyName
     * @return string
     */
    public function setCompanyName($_companyName)
    {
        return ($this->CompanyName = $_companyName);
    }
    /**
     * Get Address1 value
     * @return string|null
     */
    public function getAddress1()
    {
        return $this->Address1;
    }
    /**
     * Set Address1 value
     * @param string $_address1 the Address1
     * @return string
     */
    public function setAddress1($_address1)
    {
        return ($this->Address1 = $_address1);
    }
    /**
     * Get Address2 value
     * @return string|null
     */
    public function getAddress2()
    {
        return $this->Address2;
    }
    /**
     * Set Address2 value
     * @param string $_address2 the Address2
     * @return string
     */
    public function setAddress2($_address2)
    {
        return ($this->Address2 = $_address2);
    }
    /**
     * Get Address3 value
     * @return string|null
     */
    public function getAddress3()
    {
        return $this->Address3;
    }
    /**
     * Set Address3 value
     * @param string $_address3 the Address3
     * @return string
     */
    public function setAddress3($_address3)
    {
        return ($this->Address3 = $_address3);
    }
    /**
     * Get Town value
     * @return string|null
     */
    public function getTown()
    {
        return $this->Town;
    }
    /**
     * Set Town value
     * @param string $_town the Town
     * @return string
     */
    public function setTown($_town)
    {
        return ($this->Town = $_town);
    }
    /**
     * Get County value
     * @return string|null
     */
    public function getCounty()
    {
        return $this->County;
    }
    /**
     * Set County value
     * @param string $_county the County
     * @return string
     */
    public function setCounty($_county)
    {
        return ($this->County = $_county);
    }
    /**
     * Get Postcode value
     * @return string|null
     */
    public function getPostcode()
    {
        return $this->Postcode;
    }
    /**
     * Set Postcode value
     * @param string $_postcode the Postcode
     * @return string
     */
    public function setPostcode($_postcode)
    {
        return ($this->Postcode = $_postcode);
    }
    /**
     * Get CountryCode value
     * @return WsdlEnumCountryCode|null
     */
    public function getCountryCode()
    {
        return $this->CountryCode;
    }
    /**
     * Set CountryCode value
     * @uses WsdlEnumCountryCode::valueIsValid()
     * @param WsdlEnumCountryCode $_countryCode the CountryCode
     * @return WsdlEnumCountryCode
     */
    public function setCountryCode($_countryCode)
    {
        if(!WsdlEnumCountryCode::valueIsValid($_countryCode))
        {
            return false;
        }
        return ($this->CountryCode = $_countryCode);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructAddress
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
