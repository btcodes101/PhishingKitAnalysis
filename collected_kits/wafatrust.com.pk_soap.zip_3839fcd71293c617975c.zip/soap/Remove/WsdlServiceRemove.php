<?php
/**
 * File for class WsdlServiceRemove
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlServiceRemove originally named Remove
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlServiceRemove extends WsdlWsdlClass
{
    /**
     * Sets the AuthHeader SoapHeader param
     * @uses WsdlWsdlClass::setSoapHeader()
     * @param WsdlStructAuthHeader $_wsdlStructAuthHeader
     * @param string $_nameSpace http://www.beautyfort.com/api/
     * @param bool $_mustUnderstand
     * @param string $_actor
     * @return bool true|false
     */
    public function setSoapHeaderAuthHeader(WsdlStructAuthHeader $_wsdlStructAuthHeader,$_nameSpace = 'http://www.beautyfort.com/api/',$_mustUnderstand = false,$_actor = null)
    {
        return $this->setSoapHeader($_nameSpace,'AuthHeader',$_wsdlStructAuthHeader,$_mustUnderstand,$_actor);
    }
    /**
     * Method to call the operation originally named RemoveBreakBulkOrderItem
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructRemoveBreakBulkOrderItemRequestType $_wsdlStructRemoveBreakBulkOrderItemRequestType
     * @return WsdlStructRemoveBreakBulkOrderItemResponseType
     */
    public function RemoveBreakBulkOrderItem(WsdlStructRemoveBreakBulkOrderItemRequestType $_wsdlStructRemoveBreakBulkOrderItemRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->RemoveBreakBulkOrderItem($_wsdlStructRemoveBreakBulkOrderItemRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Method to call the operation originally named RemoveOrderItem
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructRemoveOrderItemRequestType $_wsdlStructRemoveOrderItemRequestType
     * @return WsdlStructRemoveOrderItemResponseType
     */
    public function RemoveOrderItem(WsdlStructRemoveOrderItemRequestType $_wsdlStructRemoveOrderItemRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->RemoveOrderItem($_wsdlStructRemoveOrderItemRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Returns the result
     * @see WsdlWsdlClass::getResult()
     * @return WsdlStructRemoveBreakBulkOrderItemResponseType|WsdlStructRemoveOrderItemResponseType
     */
    public function getResult()
    {
        return parent::getResult();
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
