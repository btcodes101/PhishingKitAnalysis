<?php
/**
 * File for class WsdlStructRemoveOrderItemResponseType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructRemoveOrderItemResponseType originally named RemoveOrderItemResponseType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructRemoveOrderItemResponseType extends WsdlStructAbstractResponseType
{
    /**
     * The Success
     * @var boolean
     */
    public $Success;
    /**
     * Constructor method for RemoveOrderItemResponseType
     * @see parent::__construct()
     * @param boolean $_success
     * @return WsdlStructRemoveOrderItemResponseType
     */
    public function __construct($_success = NULL)
    {
        WsdlWsdlClass::__construct(array('Success'=>$_success),false);
    }
    /**
     * Get Success value
     * @return boolean|null
     */
    public function getSuccess()
    {
        return $this->Success;
    }
    /**
     * Set Success value
     * @param boolean $_success the Success
     * @return boolean
     */
    public function setSuccess($_success)
    {
        return ($this->Success = $_success);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructRemoveOrderItemResponseType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
