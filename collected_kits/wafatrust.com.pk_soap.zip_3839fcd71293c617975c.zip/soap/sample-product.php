<?php

ini_set('memory_limit','512M');
ini_set('display_errors',true);
error_reporting(-1);
/**
 * Load autoload
 */
require_once dirname(__FILE__) . '/WsdlAutoload.php';
require_once  'config.php';
require_once  'Shopify.php';

$productUrl = $secureUrl."/admin/api/2019-07/products.json";
 $random = substr(md5(mt_rand()), 0, 7);
//echo "<pre>";
$shopify = new Shopify();
/********************************
 * Example for WsdlServiceProduct
 */
date_default_timezone_set('Europe/London');
$now = new DateTime();
$created  = $now->format('Y-m-d H:i:s');
$_nonce = $random;
$password = base64_encode(sha1($_nonce.$created."ib1hJswqvDZ2QOW3Fg9neR0KzxPS4CHkr"));
$wsdlServiceProduct = new WsdlServiceProduct();
// sample call for WsdlServiceProduct::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
$wsdlServiceProduct->setSoapHeaderAuthHeader(new WsdlStructAuthHeader("abbasahmed@mac.com",$_nonce,$created,$password));

// sample call for WsdlServiceProduct::ProductSearch()
if($wsdlServiceProduct->ProductSearch(new WsdlStructProductSearchRequestType(/*** update parameters list ***/)))
{
    $soapData = $wsdlServiceProduct->getResult();
   // print_r($soapData);
    $items = $soapData->Items;
    //print_r($items);
    $i = 0;
    $products_array  = array();
    foreach ($items->Item as $item){
           if ($i == 2) { // for testing purpose it will execute only 2 times
                    break;
            } else {
                $i++;
            }
         //   print_r($item);
        $product  = (array) $item;
        $productPrice = (array) $product['UnitPrice'];
        $product_array = array(
            "product" => array(
                'title' => $product['Name'],
                'vendor' => "beautyfort",
                "metafields_global_title_tag" => $product['Name'],
                "metafields_global_description_tag" => $product['Name'],
                "body_html" => $product['Name'],
                "published" => true,
                "variants" => array(
                    array(
                        "sku" => $product['StockCode'],
                        "inventory_quantity" => $product['QuantityAvailable'],
                        "price" => $productPrice["Amount"] + ( $productPrice["Amount"]  * 0.35)
                    )
                ),
                "images" => array(
                    array(
                        "src" => $product['HighResImageUrl'],
                    )
                )
            )
        );
        
        $products_array[] = $product_array;
       
        
//        $response = $shopify->createProduct($productUrl,$productData);
//        $productresponse = json_decode(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $response), true);
//        $productId = $productresponse['product']['id'];
    }
     header('Content-type: application/json');
echo json_encode($products_array);
 //     print_r($soapData['Items']);
    //$soapDataItems = $soapData->items;
}  
//
else
    print_r($wsdlServiceProduct->getLastError());

/*******************************
 * Example for WsdlServiceRemove
 */
//$wsdlServiceRemove = new WsdlServiceRemove();
//// sample call for WsdlServiceRemove::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
//$wsdlServiceRemove->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
//// sample call for WsdlServiceRemove::RemoveBreakBulkOrderItem()
//if($wsdlServiceRemove->RemoveBreakBulkOrderItem(new WsdlStructRemoveBreakBulkOrderItemRequestType(/*** update parameters list ***/)))
//    print_r($wsdlServiceRemove->getResult());
//else
//    print_r($wsdlServiceRemove->getLastError());
// sample call for WsdlServiceRemove::RemoveOrderItem()
//if($wsdlServiceRemove->RemoveOrderItem(new WsdlStructRemoveOrderItemRequestType(/*** update parameters list ***/)))
//    print_r($wsdlServiceRemove->getResult());
//else
//    print_r($wsdlServiceRemove->getLastError());
