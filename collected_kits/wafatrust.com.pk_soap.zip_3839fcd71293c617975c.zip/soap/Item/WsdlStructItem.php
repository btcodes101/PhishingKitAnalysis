<?php
/**
 * File for class WsdlStructItem
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructItem originally named Item
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructItem extends WsdlWsdlClass
{
    /**
     * The StockCode
     * @var string
     */
    public $StockCode;
    /**
     * The Name
     * @var string
     */
    public $Name;
    /**
     * The QuantityAvailable
     * @var int
     */
    public $QuantityAvailable;
    /**
     * The UnitPrice
     * @var WsdlStructAmount
     */
    public $UnitPrice;
    /**
     * The YourRating
     * Meta informations extracted from the WSDL
     * - nillable : true
     * - maxInclusive : 5
     * - minInclusive : 1
     * @var int
     */
    public $YourRating;
    /**
     * The YourStockCode
     * @var string
     */
    public $YourStockCode;
    /**
     * The ImageLastUpdated
     * Meta informations extracted from the WSDL
     * - nillable : true
     * @var dateTime
     */
    public $ImageLastUpdated;
    /**
     * The ThumbnailImageUrl
     * Meta informations extracted from the WSDL
     * - nillable : true
     * @var anyURI
     */
    public $ThumbnailImageUrl;
    /**
     * The HighResImageUrl
     * Meta informations extracted from the WSDL
     * - nillable : true
     * @var anyURI
     */
    public $HighResImageUrl;
    /**
     * Constructor method for Item
     * @see parent::__construct()
     * @param string $_stockCode
     * @param string $_name
     * @param int $_quantityAvailable
     * @param WsdlStructAmount $_unitPrice
     * @param int $_yourRating
     * @param string $_yourStockCode
     * @param dateTime $_imageLastUpdated
     * @param anyURI $_thumbnailImageUrl
     * @param anyURI $_highResImageUrl
     * @return WsdlStructItem
     */
    public function __construct($_stockCode = NULL,$_name = NULL,$_quantityAvailable = NULL,$_unitPrice = NULL,$_yourRating = NULL,$_yourStockCode = NULL,$_imageLastUpdated = NULL,$_thumbnailImageUrl = NULL,$_highResImageUrl = NULL)
    {
        parent::__construct(array('StockCode'=>$_stockCode,'Name'=>$_name,'QuantityAvailable'=>$_quantityAvailable,'UnitPrice'=>$_unitPrice,'YourRating'=>$_yourRating,'YourStockCode'=>$_yourStockCode,'ImageLastUpdated'=>$_imageLastUpdated,'ThumbnailImageUrl'=>$_thumbnailImageUrl,'HighResImageUrl'=>$_highResImageUrl),false);
    }
    /**
     * Get StockCode value
     * @return string|null
     */
    public function getStockCode()
    {
        return $this->StockCode;
    }
    /**
     * Set StockCode value
     * @param string $_stockCode the StockCode
     * @return string
     */
    public function setStockCode($_stockCode)
    {
        return ($this->StockCode = $_stockCode);
    }
    /**
     * Get Name value
     * @return string|null
     */
    public function getName()
    {
        return $this->Name;
    }
    /**
     * Set Name value
     * @param string $_name the Name
     * @return string
     */
    public function setName($_name)
    {
        return ($this->Name = $_name);
    }
    /**
     * Get QuantityAvailable value
     * @return int|null
     */
    public function getQuantityAvailable()
    {
        return $this->QuantityAvailable;
    }
    /**
     * Set QuantityAvailable value
     * @param int $_quantityAvailable the QuantityAvailable
     * @return int
     */
    public function setQuantityAvailable($_quantityAvailable)
    {
        return ($this->QuantityAvailable = $_quantityAvailable);
    }
    /**
     * Get UnitPrice value
     * @return WsdlStructAmount|null
     */
    public function getUnitPrice()
    {
        return $this->UnitPrice;
    }
    /**
     * Set UnitPrice value
     * @param WsdlStructAmount $_unitPrice the UnitPrice
     * @return WsdlStructAmount
     */
    public function setUnitPrice($_unitPrice)
    {
        return ($this->UnitPrice = $_unitPrice);
    }
    /**
     * Get YourRating value
     * @return int|null
     */
    public function getYourRating()
    {
        return $this->YourRating;
    }
    /**
     * Set YourRating value
     * @param int $_yourRating the YourRating
     * @return int
     */
    public function setYourRating($_yourRating)
    {
        return ($this->YourRating = $_yourRating);
    }
    /**
     * Get YourStockCode value
     * @return string|null
     */
    public function getYourStockCode()
    {
        return $this->YourStockCode;
    }
    /**
     * Set YourStockCode value
     * @param string $_yourStockCode the YourStockCode
     * @return string
     */
    public function setYourStockCode($_yourStockCode)
    {
        return ($this->YourStockCode = $_yourStockCode);
    }
    /**
     * Get ImageLastUpdated value
     * @return dateTime|null
     */
    public function getImageLastUpdated()
    {
        return $this->ImageLastUpdated;
    }
    /**
     * Set ImageLastUpdated value
     * @param dateTime $_imageLastUpdated the ImageLastUpdated
     * @return dateTime
     */
    public function setImageLastUpdated($_imageLastUpdated)
    {
        return ($this->ImageLastUpdated = $_imageLastUpdated);
    }
    /**
     * Get ThumbnailImageUrl value
     * @return anyURI|null
     */
    public function getThumbnailImageUrl()
    {
        return $this->ThumbnailImageUrl;
    }
    /**
     * Set ThumbnailImageUrl value
     * @param anyURI $_thumbnailImageUrl the ThumbnailImageUrl
     * @return anyURI
     */
    public function setThumbnailImageUrl($_thumbnailImageUrl)
    {
        return ($this->ThumbnailImageUrl = $_thumbnailImageUrl);
    }
    /**
     * Get HighResImageUrl value
     * @return anyURI|null
     */
    public function getHighResImageUrl()
    {
        return $this->HighResImageUrl;
    }
    /**
     * Set HighResImageUrl value
     * @param anyURI $_highResImageUrl the HighResImageUrl
     * @return anyURI
     */
    public function setHighResImageUrl($_highResImageUrl)
    {
        return ($this->HighResImageUrl = $_highResImageUrl);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructItem
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
