<?php
/**
 * File for class WsdlStructPriceRange
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructPriceRange originally named PriceRange
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructPriceRange extends WsdlWsdlClass
{
    /**
     * The Lower
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * - fractionDigits : 2
     * @var decimal
     */
    public $Lower;
    /**
     * The Upper
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * - fractionDigits : 2
     * @var decimal
     */
    public $Upper;
    /**
     * Constructor method for PriceRange
     * @see parent::__construct()
     * @param decimal $_lower
     * @param decimal $_upper
     * @return WsdlStructPriceRange
     */
    public function __construct($_lower = NULL,$_upper = NULL)
    {
        parent::__construct(array('Lower'=>$_lower,'Upper'=>$_upper),false);
    }
    /**
     * Get Lower value
     * @return decimal|null
     */
    public function getLower()
    {
        return $this->Lower;
    }
    /**
     * Set Lower value
     * @param decimal $_lower the Lower
     * @return decimal
     */
    public function setLower($_lower)
    {
        return ($this->Lower = $_lower);
    }
    /**
     * Get Upper value
     * @return decimal|null
     */
    public function getUpper()
    {
        return $this->Upper;
    }
    /**
     * Set Upper value
     * @param decimal $_upper the Upper
     * @return decimal
     */
    public function setUpper($_upper)
    {
        return ($this->Upper = $_upper);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructPriceRange
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
