<?php
/**
 * File for class WsdlServiceGet
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlServiceGet originally named Get
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlServiceGet extends WsdlWsdlClass
{
    /**
     * Sets the AuthHeader SoapHeader param
     * @uses WsdlWsdlClass::setSoapHeader()
     * @param WsdlStructAuthHeader $_wsdlStructAuthHeader
     * @param string $_nameSpace http://www.beautyfort.com/api/
     * @param bool $_mustUnderstand
     * @param string $_actor
     * @return bool true|false
     */
    public function setSoapHeaderAuthHeader(WsdlStructAuthHeader $_wsdlStructAuthHeader,$_nameSpace = 'http://www.beautyfort.com/api/',$_mustUnderstand = false,$_actor = null)
    {
        return $this->setSoapHeader($_nameSpace,'AuthHeader',$_wsdlStructAuthHeader,$_mustUnderstand,$_actor);
    }
    /**
     * Method to call the operation originally named GetAccountInformation
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructGetAccountInformationRequestType $_wsdlStructGetAccountInformationRequestType
     * @return WsdlStructGetAccountInformationResponseType
     */
    public function GetAccountInformation(WsdlStructGetAccountInformationRequestType $_wsdlStructGetAccountInformationRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->GetAccountInformation($_wsdlStructGetAccountInformationRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Method to call the operation originally named GetAccountStatement
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructGetAccountStatementRequestType $_wsdlStructGetAccountStatementRequestType
     * @return WsdlStructGetAccountStatementResponseType
     */
    public function GetAccountStatement(WsdlStructGetAccountStatementRequestType $_wsdlStructGetAccountStatementRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->GetAccountStatement($_wsdlStructGetAccountStatementRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Method to call the operation originally named GetFreeDirectDispatchCancellationsLeft
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructGetFreeDirectDispatchCancellationsLeftRequestType $_wsdlStructGetFreeDirectDispatchCancellationsLeftRequestType
     * @return WsdlStructGetFreeDirectDispatchCancellationsLeftResponseType
     */
    public function GetFreeDirectDispatchCancellationsLeft(WsdlStructGetFreeDirectDispatchCancellationsLeftRequestType $_wsdlStructGetFreeDirectDispatchCancellationsLeftRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->GetFreeDirectDispatchCancellationsLeft($_wsdlStructGetFreeDirectDispatchCancellationsLeftRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Method to call the operation originally named GetHighResImage
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructGetHighResImageRequestType $_wsdlStructGetHighResImageRequestType
     * @return WsdlStructGetHighResImageResponseType
     */
    public function GetHighResImage(WsdlStructGetHighResImageRequestType $_wsdlStructGetHighResImageRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->GetHighResImage($_wsdlStructGetHighResImageRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Method to call the operation originally named GetOrderDetail
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructGetOrderDetailRequestType $_wsdlStructGetOrderDetailRequestType
     * @return WsdlStructGetOrderDetailResponseType
     */
    public function GetOrderDetail(WsdlStructGetOrderDetailRequestType $_wsdlStructGetOrderDetailRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->GetOrderDetail($_wsdlStructGetOrderDetailRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Method to call the operation originally named GetOrders
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructGetOrdersRequestType $_wsdlStructGetOrdersRequestType
     * @return WsdlStructGetOrdersResponseType
     */
    public function GetOrders(WsdlStructGetOrdersRequestType $_wsdlStructGetOrdersRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->GetOrders($_wsdlStructGetOrdersRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Method to call the operation originally named GetStockFile
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructGetStockFileRequestType $_wsdlStructGetStockFileRequestType
     * @return WsdlStructGetStockFileResponseType
     */
    public function GetStockFile(WsdlStructGetStockFileRequestType $_wsdlStructGetStockFileRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->GetStockFile($_wsdlStructGetStockFileRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Returns the result
     * @see WsdlWsdlClass::getResult()
     * @return WsdlStructGetAccountInformationResponseType|WsdlStructGetAccountStatementResponseType|WsdlStructGetFreeDirectDispatchCancellationsLeftResponseType|WsdlStructGetHighResImageResponseType|WsdlStructGetOrderDetailResponseType|WsdlStructGetOrdersResponseType|WsdlStructGetStockFileResponseType
     */
    public function getResult()
    {
        return parent::getResult();
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
