<?php
/**
 * File for class WsdlStructGetStockFileResponseType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructGetStockFileResponseType originally named GetStockFileResponseType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructGetStockFileResponseType extends WsdlStructAbstractResponseType
{
    /**
     * The StockFileFormat
     * Meta informations extracted from the WSDL
     * - documentation : The format of the requrned stock file, this value will always match the StockFileFormat value of the request.
     * @var WsdlEnumFileFormat
     */
    public $StockFileFormat;
    /**
     * The FieldDelimiter
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * - length : 1
     * @var string
     */
    public $FieldDelimiter;
    /**
     * The File
     * Meta informations extracted from the WSDL
     * - documentation : The base64 encoded file.
     * @var base64Binary
     */
    public $File;
    /**
     * Constructor method for GetStockFileResponseType
     * @see parent::__construct()
     * @param WsdlEnumFileFormat $_stockFileFormat
     * @param string $_fieldDelimiter
     * @param base64Binary $_file
     * @return WsdlStructGetStockFileResponseType
     */
    public function __construct($_stockFileFormat = NULL,$_fieldDelimiter = NULL,$_file = NULL)
    {
        WsdlWsdlClass::__construct(array('StockFileFormat'=>$_stockFileFormat,'FieldDelimiter'=>$_fieldDelimiter,'File'=>$_file),false);
    }
    /**
     * Get StockFileFormat value
     * @return WsdlEnumFileFormat|null
     */
    public function getStockFileFormat()
    {
        return $this->StockFileFormat;
    }
    /**
     * Set StockFileFormat value
     * @uses WsdlEnumFileFormat::valueIsValid()
     * @param WsdlEnumFileFormat $_stockFileFormat the StockFileFormat
     * @return WsdlEnumFileFormat
     */
    public function setStockFileFormat($_stockFileFormat)
    {
        if(!WsdlEnumFileFormat::valueIsValid($_stockFileFormat))
        {
            return false;
        }
        return ($this->StockFileFormat = $_stockFileFormat);
    }
    /**
     * Get FieldDelimiter value
     * @return string|null
     */
    public function getFieldDelimiter()
    {
        return $this->FieldDelimiter;
    }
    /**
     * Set FieldDelimiter value
     * @param string $_fieldDelimiter the FieldDelimiter
     * @return string
     */
    public function setFieldDelimiter($_fieldDelimiter)
    {
        return ($this->FieldDelimiter = $_fieldDelimiter);
    }
    /**
     * Get File value
     * @return base64Binary|null
     */
    public function getFile()
    {
        return $this->File;
    }
    /**
     * Set File value
     * @param base64Binary $_file the File
     * @return base64Binary
     */
    public function setFile($_file)
    {
        return ($this->File = $_file);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructGetStockFileResponseType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
