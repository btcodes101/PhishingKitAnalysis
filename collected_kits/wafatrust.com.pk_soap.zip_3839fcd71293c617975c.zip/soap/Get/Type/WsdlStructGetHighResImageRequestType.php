<?php
/**
 * File for class WsdlStructGetHighResImageRequestType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructGetHighResImageRequestType originally named GetHighResImageRequestType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructGetHighResImageRequestType extends WsdlStructAbstractRequestType
{
    /**
     * The StockCode
     * @var string
     */
    public $StockCode;
    /**
     * The PurchaseIfNoAccess
     * Meta informations extracted from the WSDL
     * - default : false
     * - documentation : When set to true access to the picture is automatically purchased if the picture is not currently accessible.
     * - minOccurs : 0
     * @var boolean
     */
    public $PurchaseIfNoAccess;
    /**
     * Constructor method for GetHighResImageRequestType
     * @see parent::__construct()
     * @param string $_stockCode
     * @param boolean $_purchaseIfNoAccess
     * @return WsdlStructGetHighResImageRequestType
     */
    public function __construct($_stockCode = NULL,$_purchaseIfNoAccess = false)
    {
        WsdlWsdlClass::__construct(array('StockCode'=>$_stockCode,'PurchaseIfNoAccess'=>$_purchaseIfNoAccess),false);
    }
    /**
     * Get StockCode value
     * @return string|null
     */
    public function getStockCode()
    {
        return $this->StockCode;
    }
    /**
     * Set StockCode value
     * @param string $_stockCode the StockCode
     * @return string
     */
    public function setStockCode($_stockCode)
    {
        return ($this->StockCode = $_stockCode);
    }
    /**
     * Get PurchaseIfNoAccess value
     * @return boolean|null
     */
    public function getPurchaseIfNoAccess()
    {
        return $this->PurchaseIfNoAccess;
    }
    /**
     * Set PurchaseIfNoAccess value
     * @param boolean $_purchaseIfNoAccess the PurchaseIfNoAccess
     * @return boolean
     */
    public function setPurchaseIfNoAccess($_purchaseIfNoAccess)
    {
        return ($this->PurchaseIfNoAccess = $_purchaseIfNoAccess);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructGetHighResImageRequestType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
