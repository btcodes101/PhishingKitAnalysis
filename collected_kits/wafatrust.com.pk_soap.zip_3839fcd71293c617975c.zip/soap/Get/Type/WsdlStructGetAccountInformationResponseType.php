<?php
/**
 * File for class WsdlStructGetAccountInformationResponseType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructGetAccountInformationResponseType originally named GetAccountInformationResponseType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructGetAccountInformationResponseType extends WsdlStructAbstractResponseType
{
    /**
     * The WholesaleDeliveryOptions
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfWholesaleDeliveryOption
     */
    public $WholesaleDeliveryOptions;
    /**
     * The DirectDispatchDeliveryOptions
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfDirectDispatchDeliveryOption
     */
    public $DirectDispatchDeliveryOptions;
    /**
     * The PictureFees
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructPictureFees
     */
    public $PictureFees;
    /**
     * The BreakBulkFees
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructBreakBulkFees
     */
    public $BreakBulkFees;
    /**
     * The DirectDispatchFees
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructDirectDispatchFees
     */
    public $DirectDispatchFees;
    /**
     * The MaximumViewableStockLevel
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var int
     */
    public $MaximumViewableStockLevel;
    /**
     * The Categories
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfCategory
     */
    public $Categories;
    /**
     * The Brands
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfBrand
     */
    public $Brands;
    /**
     * The ProductTypes
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfProductType
     */
    public $ProductTypes;
    /**
     * The Genders
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfGender
     */
    public $Genders;
    /**
     * Constructor method for GetAccountInformationResponseType
     * @see parent::__construct()
     * @param WsdlStructArrayOfWholesaleDeliveryOption $_wholesaleDeliveryOptions
     * @param WsdlStructArrayOfDirectDispatchDeliveryOption $_directDispatchDeliveryOptions
     * @param WsdlStructPictureFees $_pictureFees
     * @param WsdlStructBreakBulkFees $_breakBulkFees
     * @param WsdlStructDirectDispatchFees $_directDispatchFees
     * @param int $_maximumViewableStockLevel
     * @param WsdlStructArrayOfCategory $_categories
     * @param WsdlStructArrayOfBrand $_brands
     * @param WsdlStructArrayOfProductType $_productTypes
     * @param WsdlStructArrayOfGender $_genders
     * @return WsdlStructGetAccountInformationResponseType
     */
    public function __construct($_wholesaleDeliveryOptions = NULL,$_directDispatchDeliveryOptions = NULL,$_pictureFees = NULL,$_breakBulkFees = NULL,$_directDispatchFees = NULL,$_maximumViewableStockLevel = NULL,$_categories = NULL,$_brands = NULL,$_productTypes = NULL,$_genders = NULL)
    {
        WsdlWsdlClass::__construct(array('WholesaleDeliveryOptions'=>($_wholesaleDeliveryOptions instanceof WsdlStructArrayOfWholesaleDeliveryOption)?$_wholesaleDeliveryOptions:new WsdlStructArrayOfWholesaleDeliveryOption($_wholesaleDeliveryOptions),'DirectDispatchDeliveryOptions'=>($_directDispatchDeliveryOptions instanceof WsdlStructArrayOfDirectDispatchDeliveryOption)?$_directDispatchDeliveryOptions:new WsdlStructArrayOfDirectDispatchDeliveryOption($_directDispatchDeliveryOptions),'PictureFees'=>$_pictureFees,'BreakBulkFees'=>$_breakBulkFees,'DirectDispatchFees'=>$_directDispatchFees,'MaximumViewableStockLevel'=>$_maximumViewableStockLevel,'Categories'=>($_categories instanceof WsdlStructArrayOfCategory)?$_categories:new WsdlStructArrayOfCategory($_categories),'Brands'=>($_brands instanceof WsdlStructArrayOfBrand)?$_brands:new WsdlStructArrayOfBrand($_brands),'ProductTypes'=>($_productTypes instanceof WsdlStructArrayOfProductType)?$_productTypes:new WsdlStructArrayOfProductType($_productTypes),'Genders'=>($_genders instanceof WsdlStructArrayOfGender)?$_genders:new WsdlStructArrayOfGender($_genders)),false);
    }
    /**
     * Get WholesaleDeliveryOptions value
     * @return WsdlStructArrayOfWholesaleDeliveryOption|null
     */
    public function getWholesaleDeliveryOptions()
    {
        return $this->WholesaleDeliveryOptions;
    }
    /**
     * Set WholesaleDeliveryOptions value
     * @param WsdlStructArrayOfWholesaleDeliveryOption $_wholesaleDeliveryOptions the WholesaleDeliveryOptions
     * @return WsdlStructArrayOfWholesaleDeliveryOption
     */
    public function setWholesaleDeliveryOptions($_wholesaleDeliveryOptions)
    {
        return ($this->WholesaleDeliveryOptions = $_wholesaleDeliveryOptions);
    }
    /**
     * Get DirectDispatchDeliveryOptions value
     * @return WsdlStructArrayOfDirectDispatchDeliveryOption|null
     */
    public function getDirectDispatchDeliveryOptions()
    {
        return $this->DirectDispatchDeliveryOptions;
    }
    /**
     * Set DirectDispatchDeliveryOptions value
     * @param WsdlStructArrayOfDirectDispatchDeliveryOption $_directDispatchDeliveryOptions the DirectDispatchDeliveryOptions
     * @return WsdlStructArrayOfDirectDispatchDeliveryOption
     */
    public function setDirectDispatchDeliveryOptions($_directDispatchDeliveryOptions)
    {
        return ($this->DirectDispatchDeliveryOptions = $_directDispatchDeliveryOptions);
    }
    /**
     * Get PictureFees value
     * @return WsdlStructPictureFees|null
     */
    public function getPictureFees()
    {
        return $this->PictureFees;
    }
    /**
     * Set PictureFees value
     * @param WsdlStructPictureFees $_pictureFees the PictureFees
     * @return WsdlStructPictureFees
     */
    public function setPictureFees($_pictureFees)
    {
        return ($this->PictureFees = $_pictureFees);
    }
    /**
     * Get BreakBulkFees value
     * @return WsdlStructBreakBulkFees|null
     */
    public function getBreakBulkFees()
    {
        return $this->BreakBulkFees;
    }
    /**
     * Set BreakBulkFees value
     * @param WsdlStructBreakBulkFees $_breakBulkFees the BreakBulkFees
     * @return WsdlStructBreakBulkFees
     */
    public function setBreakBulkFees($_breakBulkFees)
    {
        return ($this->BreakBulkFees = $_breakBulkFees);
    }
    /**
     * Get DirectDispatchFees value
     * @return WsdlStructDirectDispatchFees|null
     */
    public function getDirectDispatchFees()
    {
        return $this->DirectDispatchFees;
    }
    /**
     * Set DirectDispatchFees value
     * @param WsdlStructDirectDispatchFees $_directDispatchFees the DirectDispatchFees
     * @return WsdlStructDirectDispatchFees
     */
    public function setDirectDispatchFees($_directDispatchFees)
    {
        return ($this->DirectDispatchFees = $_directDispatchFees);
    }
    /**
     * Get MaximumViewableStockLevel value
     * @return int|null
     */
    public function getMaximumViewableStockLevel()
    {
        return $this->MaximumViewableStockLevel;
    }
    /**
     * Set MaximumViewableStockLevel value
     * @param int $_maximumViewableStockLevel the MaximumViewableStockLevel
     * @return int
     */
    public function setMaximumViewableStockLevel($_maximumViewableStockLevel)
    {
        return ($this->MaximumViewableStockLevel = $_maximumViewableStockLevel);
    }
    /**
     * Get Categories value
     * @return WsdlStructArrayOfCategory|null
     */
    public function getCategories()
    {
        return $this->Categories;
    }
    /**
     * Set Categories value
     * @param WsdlStructArrayOfCategory $_categories the Categories
     * @return WsdlStructArrayOfCategory
     */
    public function setCategories($_categories)
    {
        return ($this->Categories = $_categories);
    }
    /**
     * Get Brands value
     * @return WsdlStructArrayOfBrand|null
     */
    public function getBrands()
    {
        return $this->Brands;
    }
    /**
     * Set Brands value
     * @param WsdlStructArrayOfBrand $_brands the Brands
     * @return WsdlStructArrayOfBrand
     */
    public function setBrands($_brands)
    {
        return ($this->Brands = $_brands);
    }
    /**
     * Get ProductTypes value
     * @return WsdlStructArrayOfProductType|null
     */
    public function getProductTypes()
    {
        return $this->ProductTypes;
    }
    /**
     * Set ProductTypes value
     * @param WsdlStructArrayOfProductType $_productTypes the ProductTypes
     * @return WsdlStructArrayOfProductType
     */
    public function setProductTypes($_productTypes)
    {
        return ($this->ProductTypes = $_productTypes);
    }
    /**
     * Get Genders value
     * @return WsdlStructArrayOfGender|null
     */
    public function getGenders()
    {
        return $this->Genders;
    }
    /**
     * Set Genders value
     * @param WsdlStructArrayOfGender $_genders the Genders
     * @return WsdlStructArrayOfGender
     */
    public function setGenders($_genders)
    {
        return ($this->Genders = $_genders);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructGetAccountInformationResponseType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
