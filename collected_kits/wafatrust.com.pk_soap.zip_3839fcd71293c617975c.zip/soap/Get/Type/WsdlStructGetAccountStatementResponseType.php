<?php
/**
 * File for class WsdlStructGetAccountStatementResponseType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructGetAccountStatementResponseType originally named GetAccountStatementResponseType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructGetAccountStatementResponseType extends WsdlStructAbstractResponseType
{
    /**
     * The DateRange
     * @var WsdlStructDateRange
     */
    public $DateRange;
    /**
     * The BalanceBroughtForward
     * @var WsdlStructAmount
     */
    public $BalanceBroughtForward;
    /**
     * The Transactions
     * @var WsdlStructArrayOfTransaction
     */
    public $Transactions;
    /**
     * The FinalBalance
     * @var WsdlStructAmount
     */
    public $FinalBalance;
    /**
     * The CurrentAvailableCredit
     * Meta informations extracted from the WSDL
     * - documentation : NOTE: This is the current available credit, not the available credit for the report date range.
     * @var WsdlStructAmount
     */
    public $CurrentAvailableCredit;
    /**
     * The CurrentBalance
     * Meta informations extracted from the WSDL
     * - documentation : NOTE: This is the current balance, not the balance for the report date range.
     * @var WsdlStructAmount
     */
    public $CurrentBalance;
    /**
     * The CurrentOverdue
     * Meta informations extracted from the WSDL
     * - documentation : NOTE: This is the current overdue amount, not the overdue amount for the report date range.
     * - minOccurs : 0
     * @var WsdlStructAmount
     */
    public $CurrentOverdue;
    /**
     * Constructor method for GetAccountStatementResponseType
     * @see parent::__construct()
     * @param WsdlStructDateRange $_dateRange
     * @param WsdlStructAmount $_balanceBroughtForward
     * @param WsdlStructArrayOfTransaction $_transactions
     * @param WsdlStructAmount $_finalBalance
     * @param WsdlStructAmount $_currentAvailableCredit
     * @param WsdlStructAmount $_currentBalance
     * @param WsdlStructAmount $_currentOverdue
     * @return WsdlStructGetAccountStatementResponseType
     */
    public function __construct($_dateRange = NULL,$_balanceBroughtForward = NULL,$_transactions = NULL,$_finalBalance = NULL,$_currentAvailableCredit = NULL,$_currentBalance = NULL,$_currentOverdue = NULL)
    {
        WsdlWsdlClass::__construct(array('DateRange'=>$_dateRange,'BalanceBroughtForward'=>$_balanceBroughtForward,'Transactions'=>($_transactions instanceof WsdlStructArrayOfTransaction)?$_transactions:new WsdlStructArrayOfTransaction($_transactions),'FinalBalance'=>$_finalBalance,'CurrentAvailableCredit'=>$_currentAvailableCredit,'CurrentBalance'=>$_currentBalance,'CurrentOverdue'=>$_currentOverdue),false);
    }
    /**
     * Get DateRange value
     * @return WsdlStructDateRange|null
     */
    public function getDateRange()
    {
        return $this->DateRange;
    }
    /**
     * Set DateRange value
     * @param WsdlStructDateRange $_dateRange the DateRange
     * @return WsdlStructDateRange
     */
    public function setDateRange($_dateRange)
    {
        return ($this->DateRange = $_dateRange);
    }
    /**
     * Get BalanceBroughtForward value
     * @return WsdlStructAmount|null
     */
    public function getBalanceBroughtForward()
    {
        return $this->BalanceBroughtForward;
    }
    /**
     * Set BalanceBroughtForward value
     * @param WsdlStructAmount $_balanceBroughtForward the BalanceBroughtForward
     * @return WsdlStructAmount
     */
    public function setBalanceBroughtForward($_balanceBroughtForward)
    {
        return ($this->BalanceBroughtForward = $_balanceBroughtForward);
    }
    /**
     * Get Transactions value
     * @return WsdlStructArrayOfTransaction|null
     */
    public function getTransactions()
    {
        return $this->Transactions;
    }
    /**
     * Set Transactions value
     * @param WsdlStructArrayOfTransaction $_transactions the Transactions
     * @return WsdlStructArrayOfTransaction
     */
    public function setTransactions($_transactions)
    {
        return ($this->Transactions = $_transactions);
    }
    /**
     * Get FinalBalance value
     * @return WsdlStructAmount|null
     */
    public function getFinalBalance()
    {
        return $this->FinalBalance;
    }
    /**
     * Set FinalBalance value
     * @param WsdlStructAmount $_finalBalance the FinalBalance
     * @return WsdlStructAmount
     */
    public function setFinalBalance($_finalBalance)
    {
        return ($this->FinalBalance = $_finalBalance);
    }
    /**
     * Get CurrentAvailableCredit value
     * @return WsdlStructAmount|null
     */
    public function getCurrentAvailableCredit()
    {
        return $this->CurrentAvailableCredit;
    }
    /**
     * Set CurrentAvailableCredit value
     * @param WsdlStructAmount $_currentAvailableCredit the CurrentAvailableCredit
     * @return WsdlStructAmount
     */
    public function setCurrentAvailableCredit($_currentAvailableCredit)
    {
        return ($this->CurrentAvailableCredit = $_currentAvailableCredit);
    }
    /**
     * Get CurrentBalance value
     * @return WsdlStructAmount|null
     */
    public function getCurrentBalance()
    {
        return $this->CurrentBalance;
    }
    /**
     * Set CurrentBalance value
     * @param WsdlStructAmount $_currentBalance the CurrentBalance
     * @return WsdlStructAmount
     */
    public function setCurrentBalance($_currentBalance)
    {
        return ($this->CurrentBalance = $_currentBalance);
    }
    /**
     * Get CurrentOverdue value
     * @return WsdlStructAmount|null
     */
    public function getCurrentOverdue()
    {
        return $this->CurrentOverdue;
    }
    /**
     * Set CurrentOverdue value
     * @param WsdlStructAmount $_currentOverdue the CurrentOverdue
     * @return WsdlStructAmount
     */
    public function setCurrentOverdue($_currentOverdue)
    {
        return ($this->CurrentOverdue = $_currentOverdue);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructGetAccountStatementResponseType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
