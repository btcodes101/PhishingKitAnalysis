<?php
/**
 * File for class WsdlStructGetStockFileRequestType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructGetStockFileRequestType originally named GetStockFileRequestType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructGetStockFileRequestType extends WsdlStructAbstractRequestType
{
    /**
     * The SortBy
     * Meta informations extracted from the WSDL
     * - minOccurs : 1
     * @var WsdlEnumStockFileSort
     */
    public $SortBy;
    /**
     * The StockFileFormat
     * Meta informations extracted from the WSDL
     * - documentation : The format the stock file should be returned in.
     * @var WsdlEnumFileFormat
     */
    public $StockFileFormat;
    /**
     * The FieldDelimiter
     * Meta informations extracted from the WSDL
     * - default : ,
     * - documentation : The delimeter to use for the delimited file format.
     * - minOccurs : 0
     * - length : 1
     * @var string
     */
    public $FieldDelimiter;
    /**
     * The StockFileFields
     * Meta informations extracted from the WSDL
     * - documentation : The stock file columns that should be returned in the stock file. If none are specified the default columns shown in a stock file for the customer are included.
     * - minOccurs : 0
     * @var WsdlStructArrayOfStockFileField
     */
    public $StockFileFields;
    /**
     * Constructor method for GetStockFileRequestType
     * @see parent::__construct()
     * @param WsdlEnumStockFileSort $_sortBy
     * @param WsdlEnumFileFormat $_stockFileFormat
     * @param string $_fieldDelimiter
     * @param WsdlStructArrayOfStockFileField $_stockFileFields
     * @return WsdlStructGetStockFileRequestType
     */
    public function __construct($_sortBy,$_stockFileFormat = NULL,$_fieldDelimiter = ',',$_stockFileFields = NULL)
    {
        WsdlWsdlClass::__construct(array('SortBy'=>$_sortBy,'StockFileFormat'=>$_stockFileFormat,'FieldDelimiter'=>$_fieldDelimiter,'StockFileFields'=>($_stockFileFields instanceof WsdlStructArrayOfStockFileField)?$_stockFileFields:new WsdlStructArrayOfStockFileField($_stockFileFields)),false);
    }
    /**
     * Get SortBy value
     * @return WsdlEnumStockFileSort
     */
    public function getSortBy()
    {
        return $this->SortBy;
    }
    /**
     * Set SortBy value
     * @uses WsdlEnumStockFileSort::valueIsValid()
     * @param WsdlEnumStockFileSort $_sortBy the SortBy
     * @return WsdlEnumStockFileSort
     */
    public function setSortBy($_sortBy)
    {
        if(!WsdlEnumStockFileSort::valueIsValid($_sortBy))
        {
            return false;
        }
        return ($this->SortBy = $_sortBy);
    }
    /**
     * Get StockFileFormat value
     * @return WsdlEnumFileFormat|null
     */
    public function getStockFileFormat()
    {
        return $this->StockFileFormat;
    }
    /**
     * Set StockFileFormat value
     * @uses WsdlEnumFileFormat::valueIsValid()
     * @param WsdlEnumFileFormat $_stockFileFormat the StockFileFormat
     * @return WsdlEnumFileFormat
     */
    public function setStockFileFormat($_stockFileFormat)
    {
        if(!WsdlEnumFileFormat::valueIsValid($_stockFileFormat))
        {
            return false;
        }
        return ($this->StockFileFormat = $_stockFileFormat);
    }
    /**
     * Get FieldDelimiter value
     * @return string|null
     */
    public function getFieldDelimiter()
    {
        return $this->FieldDelimiter;
    }
    /**
     * Set FieldDelimiter value
     * @param string $_fieldDelimiter the FieldDelimiter
     * @return string
     */
    public function setFieldDelimiter($_fieldDelimiter)
    {
        return ($this->FieldDelimiter = $_fieldDelimiter);
    }
    /**
     * Get StockFileFields value
     * @return WsdlStructArrayOfStockFileField|null
     */
    public function getStockFileFields()
    {
        return $this->StockFileFields;
    }
    /**
     * Set StockFileFields value
     * @param WsdlStructArrayOfStockFileField $_stockFileFields the StockFileFields
     * @return WsdlStructArrayOfStockFileField
     */
    public function setStockFileFields($_stockFileFields)
    {
        return ($this->StockFileFields = $_stockFileFields);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructGetStockFileRequestType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
