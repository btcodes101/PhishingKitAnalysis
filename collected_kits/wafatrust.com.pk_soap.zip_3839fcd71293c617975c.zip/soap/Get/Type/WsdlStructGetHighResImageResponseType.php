<?php
/**
 * File for class WsdlStructGetHighResImageResponseType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructGetHighResImageResponseType originally named GetHighResImageResponseType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructGetHighResImageResponseType extends WsdlStructAbstractResponseType
{
    /**
     * The Image
     * @var base64Binary
     */
    public $Image;
    /**
     * The Purchased
     * Meta informations extracted from the WSDL
     * - default : false
     * @var boolean
     */
    public $Purchased;
    /**
     * Constructor method for GetHighResImageResponseType
     * @see parent::__construct()
     * @param base64Binary $_image
     * @param boolean $_purchased
     * @return WsdlStructGetHighResImageResponseType
     */
    public function __construct($_image = NULL,$_purchased = false)
    {
        WsdlWsdlClass::__construct(array('Image'=>$_image,'Purchased'=>$_purchased),false);
    }
    /**
     * Get Image value
     * @return base64Binary|null
     */
    public function getImage()
    {
        return $this->Image;
    }
    /**
     * Set Image value
     * @param base64Binary $_image the Image
     * @return base64Binary
     */
    public function setImage($_image)
    {
        return ($this->Image = $_image);
    }
    /**
     * Get Purchased value
     * @return boolean|null
     */
    public function getPurchased()
    {
        return $this->Purchased;
    }
    /**
     * Set Purchased value
     * @param boolean $_purchased the Purchased
     * @return boolean
     */
    public function setPurchased($_purchased)
    {
        return ($this->Purchased = $_purchased);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructGetHighResImageResponseType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
