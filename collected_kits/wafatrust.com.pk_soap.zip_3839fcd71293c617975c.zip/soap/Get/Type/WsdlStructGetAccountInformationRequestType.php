<?php
/**
 * File for class WsdlStructGetAccountInformationRequestType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructGetAccountInformationRequestType originally named GetAccountInformationRequestType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructGetAccountInformationRequestType extends WsdlStructAbstractRequestType
{
    /**
     * The AccountInformationTypes
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfAccountInformationType
     */
    public $AccountInformationTypes;
    /**
     * Constructor method for GetAccountInformationRequestType
     * @see parent::__construct()
     * @param WsdlStructArrayOfAccountInformationType $_accountInformationTypes
     * @return WsdlStructGetAccountInformationRequestType
     */
    public function __construct($_accountInformationTypes = NULL)
    {
        WsdlWsdlClass::__construct(array('AccountInformationTypes'=>($_accountInformationTypes instanceof WsdlStructArrayOfAccountInformationType)?$_accountInformationTypes:new WsdlStructArrayOfAccountInformationType($_accountInformationTypes)),false);
    }
    /**
     * Get AccountInformationTypes value
     * @return WsdlStructArrayOfAccountInformationType|null
     */
    public function getAccountInformationTypes()
    {
        return $this->AccountInformationTypes;
    }
    /**
     * Set AccountInformationTypes value
     * @param WsdlStructArrayOfAccountInformationType $_accountInformationTypes the AccountInformationTypes
     * @return WsdlStructArrayOfAccountInformationType
     */
    public function setAccountInformationTypes($_accountInformationTypes)
    {
        return ($this->AccountInformationTypes = $_accountInformationTypes);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructGetAccountInformationRequestType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
