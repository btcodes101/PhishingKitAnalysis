<?php
/**
 * File for class WsdlStructGetOrdersRequestType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructGetOrdersRequestType originally named GetOrdersRequestType
 * Documentation : The get orders request.
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructGetOrdersRequestType extends WsdlStructAbstractRequestType
{
    /**
     * The DateRange
     * @var WsdlStructDateRange
     */
    public $DateRange;
    /**
     * Constructor method for GetOrdersRequestType
     * @see parent::__construct()
     * @param WsdlStructDateRange $_dateRange
     * @return WsdlStructGetOrdersRequestType
     */
    public function __construct($_dateRange = NULL)
    {
        WsdlWsdlClass::__construct(array('DateRange'=>$_dateRange),false);
    }
    /**
     * Get DateRange value
     * @return WsdlStructDateRange|null
     */
    public function getDateRange()
    {
        return $this->DateRange;
    }
    /**
     * Set DateRange value
     * @param WsdlStructDateRange $_dateRange the DateRange
     * @return WsdlStructDateRange
     */
    public function setDateRange($_dateRange)
    {
        return ($this->DateRange = $_dateRange);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructGetOrdersRequestType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
