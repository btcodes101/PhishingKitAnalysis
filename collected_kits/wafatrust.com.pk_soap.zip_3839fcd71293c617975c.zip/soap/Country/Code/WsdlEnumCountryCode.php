<?php
/**
 * File for class WsdlEnumCountryCode
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlEnumCountryCode originally named CountryCode
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlEnumCountryCode extends WsdlWsdlClass
{
    /**
     * Constant for value 'AD'
     * Meta informations extracted from the WSDL
     * - documentation : Andorra
     * @return string 'AD'
     */
    const VALUE_AD = 'AD';
    /**
     * Constant for value 'AE'
     * Meta informations extracted from the WSDL
     * - documentation : United Arab Emirates
     * @return string 'AE'
     */
    const VALUE_AE = 'AE';
    /**
     * Constant for value 'AF'
     * Meta informations extracted from the WSDL
     * - documentation : Afghanistan
     * @return string 'AF'
     */
    const VALUE_AF = 'AF';
    /**
     * Constant for value 'AG'
     * Meta informations extracted from the WSDL
     * - documentation : Antigua and Barbuda
     * @return string 'AG'
     */
    const VALUE_AG = 'AG';
    /**
     * Constant for value 'AI'
     * Meta informations extracted from the WSDL
     * - documentation : Anguilla
     * @return string 'AI'
     */
    const VALUE_AI = 'AI';
    /**
     * Constant for value 'AL'
     * Meta informations extracted from the WSDL
     * - documentation : Albania
     * @return string 'AL'
     */
    const VALUE_AL = 'AL';
    /**
     * Constant for value 'AM'
     * Meta informations extracted from the WSDL
     * - documentation : Armenia
     * @return string 'AM'
     */
    const VALUE_AM = 'AM';
    /**
     * Constant for value 'AN'
     * Meta informations extracted from the WSDL
     * - documentation : Netherlands Antilles
     * @return string 'AN'
     */
    const VALUE_AN = 'AN';
    /**
     * Constant for value 'AO'
     * Meta informations extracted from the WSDL
     * - documentation : Angola
     * @return string 'AO'
     */
    const VALUE_AO = 'AO';
    /**
     * Constant for value 'AR'
     * Meta informations extracted from the WSDL
     * - documentation : Argentina
     * @return string 'AR'
     */
    const VALUE_AR = 'AR';
    /**
     * Constant for value 'AS'
     * Meta informations extracted from the WSDL
     * - documentation : American Samoa
     * @return string 'AS'
     */
    const VALUE_AS = 'AS';
    /**
     * Constant for value 'AT'
     * Meta informations extracted from the WSDL
     * - documentation : Austria
     * @return string 'AT'
     */
    const VALUE_AT = 'AT';
    /**
     * Constant for value 'AU'
     * Meta informations extracted from the WSDL
     * - documentation : Australia
     * @return string 'AU'
     */
    const VALUE_AU = 'AU';
    /**
     * Constant for value 'AW'
     * Meta informations extracted from the WSDL
     * - documentation : Aruba
     * @return string 'AW'
     */
    const VALUE_AW = 'AW';
    /**
     * Constant for value 'AZ'
     * Meta informations extracted from the WSDL
     * - documentation : Azerbaijan
     * @return string 'AZ'
     */
    const VALUE_AZ = 'AZ';
    /**
     * Constant for value 'BA'
     * Meta informations extracted from the WSDL
     * - documentation : Bosnia and Herzegovina
     * @return string 'BA'
     */
    const VALUE_BA = 'BA';
    /**
     * Constant for value 'BB'
     * Meta informations extracted from the WSDL
     * - documentation : Barbados
     * @return string 'BB'
     */
    const VALUE_BB = 'BB';
    /**
     * Constant for value 'BD'
     * Meta informations extracted from the WSDL
     * - documentation : Bangladesh
     * @return string 'BD'
     */
    const VALUE_BD = 'BD';
    /**
     * Constant for value 'BE'
     * Meta informations extracted from the WSDL
     * - documentation : Belgium
     * @return string 'BE'
     */
    const VALUE_BE = 'BE';
    /**
     * Constant for value 'BF'
     * Meta informations extracted from the WSDL
     * - documentation : Burkina Faso
     * @return string 'BF'
     */
    const VALUE_BF = 'BF';
    /**
     * Constant for value 'BG'
     * Meta informations extracted from the WSDL
     * - documentation : Bulgaria
     * @return string 'BG'
     */
    const VALUE_BG = 'BG';
    /**
     * Constant for value 'BH'
     * Meta informations extracted from the WSDL
     * - documentation : Bahrain
     * @return string 'BH'
     */
    const VALUE_BH = 'BH';
    /**
     * Constant for value 'BI'
     * Meta informations extracted from the WSDL
     * - documentation : Burundi
     * @return string 'BI'
     */
    const VALUE_BI = 'BI';
    /**
     * Constant for value 'BJ'
     * Meta informations extracted from the WSDL
     * - documentation : Benin
     * @return string 'BJ'
     */
    const VALUE_BJ = 'BJ';
    /**
     * Constant for value 'BM'
     * Meta informations extracted from the WSDL
     * - documentation : Bermuda
     * @return string 'BM'
     */
    const VALUE_BM = 'BM';
    /**
     * Constant for value 'BN'
     * Meta informations extracted from the WSDL
     * - documentation : Brunei Darussalam
     * @return string 'BN'
     */
    const VALUE_BN = 'BN';
    /**
     * Constant for value 'BO'
     * Meta informations extracted from the WSDL
     * - documentation : Bolivia
     * @return string 'BO'
     */
    const VALUE_BO = 'BO';
    /**
     * Constant for value 'BR'
     * Meta informations extracted from the WSDL
     * - documentation : Brazil
     * @return string 'BR'
     */
    const VALUE_BR = 'BR';
    /**
     * Constant for value 'BS'
     * Meta informations extracted from the WSDL
     * - documentation : Bahamas
     * @return string 'BS'
     */
    const VALUE_BS = 'BS';
    /**
     * Constant for value 'BT'
     * Meta informations extracted from the WSDL
     * - documentation : Bhutan
     * @return string 'BT'
     */
    const VALUE_BT = 'BT';
    /**
     * Constant for value 'BW'
     * Meta informations extracted from the WSDL
     * - documentation : Botswana
     * @return string 'BW'
     */
    const VALUE_BW = 'BW';
    /**
     * Constant for value 'BY'
     * Meta informations extracted from the WSDL
     * - documentation : Belarus
     * @return string 'BY'
     */
    const VALUE_BY = 'BY';
    /**
     * Constant for value 'BZ'
     * Meta informations extracted from the WSDL
     * - documentation : Belize
     * @return string 'BZ'
     */
    const VALUE_BZ = 'BZ';
    /**
     * Constant for value 'CA'
     * Meta informations extracted from the WSDL
     * - documentation : Canada
     * @return string 'CA'
     */
    const VALUE_CA = 'CA';
    /**
     * Constant for value 'CD'
     * Meta informations extracted from the WSDL
     * - documentation : Congo, the Democratic Republic of the
     * @return string 'CD'
     */
    const VALUE_CD = 'CD';
    /**
     * Constant for value 'CF'
     * Meta informations extracted from the WSDL
     * - documentation : Central African Republic
     * @return string 'CF'
     */
    const VALUE_CF = 'CF';
    /**
     * Constant for value 'CG'
     * Meta informations extracted from the WSDL
     * - documentation : Congo
     * @return string 'CG'
     */
    const VALUE_CG = 'CG';
    /**
     * Constant for value 'CH'
     * Meta informations extracted from the WSDL
     * - documentation : Switzerland
     * @return string 'CH'
     */
    const VALUE_CH = 'CH';
    /**
     * Constant for value 'CI'
     * Meta informations extracted from the WSDL
     * - documentation : Cote D'Ivoire
     * @return string 'CI'
     */
    const VALUE_CI = 'CI';
    /**
     * Constant for value 'CK'
     * Meta informations extracted from the WSDL
     * - documentation : Cook Islands
     * @return string 'CK'
     */
    const VALUE_CK = 'CK';
    /**
     * Constant for value 'CL'
     * Meta informations extracted from the WSDL
     * - documentation : Chile
     * @return string 'CL'
     */
    const VALUE_CL = 'CL';
    /**
     * Constant for value 'CM'
     * Meta informations extracted from the WSDL
     * - documentation : Cameroon
     * @return string 'CM'
     */
    const VALUE_CM = 'CM';
    /**
     * Constant for value 'CN'
     * Meta informations extracted from the WSDL
     * - documentation : China
     * @return string 'CN'
     */
    const VALUE_CN = 'CN';
    /**
     * Constant for value 'CO'
     * Meta informations extracted from the WSDL
     * - documentation : Colombia
     * @return string 'CO'
     */
    const VALUE_CO = 'CO';
    /**
     * Constant for value 'CR'
     * Meta informations extracted from the WSDL
     * - documentation : Costa Rica
     * @return string 'CR'
     */
    const VALUE_CR = 'CR';
    /**
     * Constant for value 'CU'
     * Meta informations extracted from the WSDL
     * - documentation : Cuba
     * @return string 'CU'
     */
    const VALUE_CU = 'CU';
    /**
     * Constant for value 'CV'
     * Meta informations extracted from the WSDL
     * - documentation : Cape Verde
     * @return string 'CV'
     */
    const VALUE_CV = 'CV';
    /**
     * Constant for value 'CY'
     * Meta informations extracted from the WSDL
     * - documentation : Cyprus
     * @return string 'CY'
     */
    const VALUE_CY = 'CY';
    /**
     * Constant for value 'CZ'
     * Meta informations extracted from the WSDL
     * - documentation : Czech Republic
     * @return string 'CZ'
     */
    const VALUE_CZ = 'CZ';
    /**
     * Constant for value 'DE'
     * Meta informations extracted from the WSDL
     * - documentation : Germany
     * @return string 'DE'
     */
    const VALUE_DE = 'DE';
    /**
     * Constant for value 'DJ'
     * Meta informations extracted from the WSDL
     * - documentation : Djibouti
     * @return string 'DJ'
     */
    const VALUE_DJ = 'DJ';
    /**
     * Constant for value 'DK'
     * Meta informations extracted from the WSDL
     * - documentation : Denmark
     * @return string 'DK'
     */
    const VALUE_DK = 'DK';
    /**
     * Constant for value 'DM'
     * Meta informations extracted from the WSDL
     * - documentation : Dominica
     * @return string 'DM'
     */
    const VALUE_DM = 'DM';
    /**
     * Constant for value 'DO'
     * Meta informations extracted from the WSDL
     * - documentation : Dominican Republic
     * @return string 'DO'
     */
    const VALUE_DO = 'DO';
    /**
     * Constant for value 'DZ'
     * Meta informations extracted from the WSDL
     * - documentation : Algeria
     * @return string 'DZ'
     */
    const VALUE_DZ = 'DZ';
    /**
     * Constant for value 'EC'
     * Meta informations extracted from the WSDL
     * - documentation : Ecuador
     * @return string 'EC'
     */
    const VALUE_EC = 'EC';
    /**
     * Constant for value 'EE'
     * Meta informations extracted from the WSDL
     * - documentation : Estonia
     * @return string 'EE'
     */
    const VALUE_EE = 'EE';
    /**
     * Constant for value 'EG'
     * Meta informations extracted from the WSDL
     * - documentation : Egypt
     * @return string 'EG'
     */
    const VALUE_EG = 'EG';
    /**
     * Constant for value 'EH'
     * Meta informations extracted from the WSDL
     * - documentation : Western Sahara
     * @return string 'EH'
     */
    const VALUE_EH = 'EH';
    /**
     * Constant for value 'ER'
     * Meta informations extracted from the WSDL
     * - documentation : Eritrea
     * @return string 'ER'
     */
    const VALUE_ER = 'ER';
    /**
     * Constant for value 'ES'
     * Meta informations extracted from the WSDL
     * - documentation : Spain
     * @return string 'ES'
     */
    const VALUE_ES = 'ES';
    /**
     * Constant for value 'ET'
     * Meta informations extracted from the WSDL
     * - documentation : Ethiopia
     * @return string 'ET'
     */
    const VALUE_ET = 'ET';
    /**
     * Constant for value 'FI'
     * Meta informations extracted from the WSDL
     * - documentation : Finland
     * @return string 'FI'
     */
    const VALUE_FI = 'FI';
    /**
     * Constant for value 'FJ'
     * Meta informations extracted from the WSDL
     * - documentation : Fiji
     * @return string 'FJ'
     */
    const VALUE_FJ = 'FJ';
    /**
     * Constant for value 'FK'
     * Meta informations extracted from the WSDL
     * - documentation : Falkland Islands (Malvinas)
     * @return string 'FK'
     */
    const VALUE_FK = 'FK';
    /**
     * Constant for value 'FM'
     * Meta informations extracted from the WSDL
     * - documentation : Micronesia, Federated States of
     * @return string 'FM'
     */
    const VALUE_FM = 'FM';
    /**
     * Constant for value 'FO'
     * Meta informations extracted from the WSDL
     * - documentation : Faroe Islands
     * @return string 'FO'
     */
    const VALUE_FO = 'FO';
    /**
     * Constant for value 'FR'
     * Meta informations extracted from the WSDL
     * - documentation : France
     * @return string 'FR'
     */
    const VALUE_FR = 'FR';
    /**
     * Constant for value 'GA'
     * Meta informations extracted from the WSDL
     * - documentation : Gabon
     * @return string 'GA'
     */
    const VALUE_GA = 'GA';
    /**
     * Constant for value 'GB'
     * Meta informations extracted from the WSDL
     * - documentation : United Kingdom
     * @return string 'GB'
     */
    const VALUE_GB = 'GB';
    /**
     * Constant for value 'GD'
     * Meta informations extracted from the WSDL
     * - documentation : Grenada
     * @return string 'GD'
     */
    const VALUE_GD = 'GD';
    /**
     * Constant for value 'GE'
     * Meta informations extracted from the WSDL
     * - documentation : Georgia
     * @return string 'GE'
     */
    const VALUE_GE = 'GE';
    /**
     * Constant for value 'GF'
     * Meta informations extracted from the WSDL
     * - documentation : French Guiana
     * @return string 'GF'
     */
    const VALUE_GF = 'GF';
    /**
     * Constant for value 'GH'
     * Meta informations extracted from the WSDL
     * - documentation : Ghana
     * @return string 'GH'
     */
    const VALUE_GH = 'GH';
    /**
     * Constant for value 'GI'
     * Meta informations extracted from the WSDL
     * - documentation : Gibraltar
     * @return string 'GI'
     */
    const VALUE_GI = 'GI';
    /**
     * Constant for value 'GL'
     * Meta informations extracted from the WSDL
     * - documentation : Greenland
     * @return string 'GL'
     */
    const VALUE_GL = 'GL';
    /**
     * Constant for value 'GM'
     * Meta informations extracted from the WSDL
     * - documentation : Gambia
     * @return string 'GM'
     */
    const VALUE_GM = 'GM';
    /**
     * Constant for value 'GN'
     * Meta informations extracted from the WSDL
     * - documentation : Guinea
     * @return string 'GN'
     */
    const VALUE_GN = 'GN';
    /**
     * Constant for value 'GP'
     * Meta informations extracted from the WSDL
     * - documentation : Guadeloupe
     * @return string 'GP'
     */
    const VALUE_GP = 'GP';
    /**
     * Constant for value 'GQ'
     * Meta informations extracted from the WSDL
     * - documentation : Equatorial Guinea
     * @return string 'GQ'
     */
    const VALUE_GQ = 'GQ';
    /**
     * Constant for value 'GR'
     * Meta informations extracted from the WSDL
     * - documentation : Greece
     * @return string 'GR'
     */
    const VALUE_GR = 'GR';
    /**
     * Constant for value 'GT'
     * Meta informations extracted from the WSDL
     * - documentation : Guatemala
     * @return string 'GT'
     */
    const VALUE_GT = 'GT';
    /**
     * Constant for value 'GU'
     * Meta informations extracted from the WSDL
     * - documentation : Guam
     * @return string 'GU'
     */
    const VALUE_GU = 'GU';
    /**
     * Constant for value 'GW'
     * Meta informations extracted from the WSDL
     * - documentation : Guinea-Bissau
     * @return string 'GW'
     */
    const VALUE_GW = 'GW';
    /**
     * Constant for value 'GY'
     * Meta informations extracted from the WSDL
     * - documentation : Guyana
     * @return string 'GY'
     */
    const VALUE_GY = 'GY';
    /**
     * Constant for value 'HK'
     * Meta informations extracted from the WSDL
     * - documentation : Hong Kong
     * @return string 'HK'
     */
    const VALUE_HK = 'HK';
    /**
     * Constant for value 'HN'
     * Meta informations extracted from the WSDL
     * - documentation : Honduras
     * @return string 'HN'
     */
    const VALUE_HN = 'HN';
    /**
     * Constant for value 'HR'
     * Meta informations extracted from the WSDL
     * - documentation : Croatia
     * @return string 'HR'
     */
    const VALUE_HR = 'HR';
    /**
     * Constant for value 'HT'
     * Meta informations extracted from the WSDL
     * - documentation : Haiti
     * @return string 'HT'
     */
    const VALUE_HT = 'HT';
    /**
     * Constant for value 'HU'
     * Meta informations extracted from the WSDL
     * - documentation : Hungary
     * @return string 'HU'
     */
    const VALUE_HU = 'HU';
    /**
     * Constant for value 'ID'
     * Meta informations extracted from the WSDL
     * - documentation : Indonesia
     * @return string 'ID'
     */
    const VALUE_ID = 'ID';
    /**
     * Constant for value 'IE'
     * Meta informations extracted from the WSDL
     * - documentation : Republic of Ireland
     * @return string 'IE'
     */
    const VALUE_IE = 'IE';
    /**
     * Constant for value 'IL'
     * Meta informations extracted from the WSDL
     * - documentation : Israel
     * @return string 'IL'
     */
    const VALUE_IL = 'IL';
    /**
     * Constant for value 'IN'
     * Meta informations extracted from the WSDL
     * - documentation : India
     * @return string 'IN'
     */
    const VALUE_IN = 'IN';
    /**
     * Constant for value 'IQ'
     * Meta informations extracted from the WSDL
     * - documentation : Iraq
     * @return string 'IQ'
     */
    const VALUE_IQ = 'IQ';
    /**
     * Constant for value 'IR'
     * Meta informations extracted from the WSDL
     * - documentation : Iran, Islamic Republic of
     * @return string 'IR'
     */
    const VALUE_IR = 'IR';
    /**
     * Constant for value 'IS'
     * Meta informations extracted from the WSDL
     * - documentation : Iceland
     * @return string 'IS'
     */
    const VALUE_IS = 'IS';
    /**
     * Constant for value 'IT'
     * Meta informations extracted from the WSDL
     * - documentation : Italy
     * @return string 'IT'
     */
    const VALUE_IT = 'IT';
    /**
     * Constant for value 'JM'
     * Meta informations extracted from the WSDL
     * - documentation : Jamaica
     * @return string 'JM'
     */
    const VALUE_JM = 'JM';
    /**
     * Constant for value 'JO'
     * Meta informations extracted from the WSDL
     * - documentation : Jordan
     * @return string 'JO'
     */
    const VALUE_JO = 'JO';
    /**
     * Constant for value 'JP'
     * Meta informations extracted from the WSDL
     * - documentation : Japan
     * @return string 'JP'
     */
    const VALUE_JP = 'JP';
    /**
     * Constant for value 'KE'
     * Meta informations extracted from the WSDL
     * - documentation : Kenya
     * @return string 'KE'
     */
    const VALUE_KE = 'KE';
    /**
     * Constant for value 'KG'
     * Meta informations extracted from the WSDL
     * - documentation : Kyrgyzstan
     * @return string 'KG'
     */
    const VALUE_KG = 'KG';
    /**
     * Constant for value 'KH'
     * Meta informations extracted from the WSDL
     * - documentation : Cambodia
     * @return string 'KH'
     */
    const VALUE_KH = 'KH';
    /**
     * Constant for value 'KI'
     * Meta informations extracted from the WSDL
     * - documentation : Kiribati
     * @return string 'KI'
     */
    const VALUE_KI = 'KI';
    /**
     * Constant for value 'KM'
     * Meta informations extracted from the WSDL
     * - documentation : Comoros
     * @return string 'KM'
     */
    const VALUE_KM = 'KM';
    /**
     * Constant for value 'KN'
     * Meta informations extracted from the WSDL
     * - documentation : Saint Kitts and Nevis
     * @return string 'KN'
     */
    const VALUE_KN = 'KN';
    /**
     * Constant for value 'KP'
     * Meta informations extracted from the WSDL
     * - documentation : Korea, Democratic People's Republic of
     * @return string 'KP'
     */
    const VALUE_KP = 'KP';
    /**
     * Constant for value 'KR'
     * Meta informations extracted from the WSDL
     * - documentation : Korea, Republic of
     * @return string 'KR'
     */
    const VALUE_KR = 'KR';
    /**
     * Constant for value 'KW'
     * Meta informations extracted from the WSDL
     * - documentation : Kuwait
     * @return string 'KW'
     */
    const VALUE_KW = 'KW';
    /**
     * Constant for value 'KY'
     * Meta informations extracted from the WSDL
     * - documentation : Cayman Islands
     * @return string 'KY'
     */
    const VALUE_KY = 'KY';
    /**
     * Constant for value 'KZ'
     * Meta informations extracted from the WSDL
     * - documentation : Kazakhstan
     * @return string 'KZ'
     */
    const VALUE_KZ = 'KZ';
    /**
     * Constant for value 'LA'
     * Meta informations extracted from the WSDL
     * - documentation : Lao People's Democratic Republic
     * @return string 'LA'
     */
    const VALUE_LA = 'LA';
    /**
     * Constant for value 'LB'
     * Meta informations extracted from the WSDL
     * - documentation : Lebanon
     * @return string 'LB'
     */
    const VALUE_LB = 'LB';
    /**
     * Constant for value 'LC'
     * Meta informations extracted from the WSDL
     * - documentation : Saint Lucia
     * @return string 'LC'
     */
    const VALUE_LC = 'LC';
    /**
     * Constant for value 'LI'
     * Meta informations extracted from the WSDL
     * - documentation : Liechtenstein
     * @return string 'LI'
     */
    const VALUE_LI = 'LI';
    /**
     * Constant for value 'LK'
     * Meta informations extracted from the WSDL
     * - documentation : Sri Lanka
     * @return string 'LK'
     */
    const VALUE_LK = 'LK';
    /**
     * Constant for value 'LR'
     * Meta informations extracted from the WSDL
     * - documentation : Liberia
     * @return string 'LR'
     */
    const VALUE_LR = 'LR';
    /**
     * Constant for value 'LS'
     * Meta informations extracted from the WSDL
     * - documentation : Lesotho
     * @return string 'LS'
     */
    const VALUE_LS = 'LS';
    /**
     * Constant for value 'LT'
     * Meta informations extracted from the WSDL
     * - documentation : Lithuania
     * @return string 'LT'
     */
    const VALUE_LT = 'LT';
    /**
     * Constant for value 'LU'
     * Meta informations extracted from the WSDL
     * - documentation : Luxembourg
     * @return string 'LU'
     */
    const VALUE_LU = 'LU';
    /**
     * Constant for value 'LV'
     * Meta informations extracted from the WSDL
     * - documentation : Latvia
     * @return string 'LV'
     */
    const VALUE_LV = 'LV';
    /**
     * Constant for value 'LY'
     * Meta informations extracted from the WSDL
     * - documentation : Libyan Arab Jamahiriya
     * @return string 'LY'
     */
    const VALUE_LY = 'LY';
    /**
     * Constant for value 'MA'
     * Meta informations extracted from the WSDL
     * - documentation : Morocco
     * @return string 'MA'
     */
    const VALUE_MA = 'MA';
    /**
     * Constant for value 'MC'
     * Meta informations extracted from the WSDL
     * - documentation : Monaco
     * @return string 'MC'
     */
    const VALUE_MC = 'MC';
    /**
     * Constant for value 'MD'
     * Meta informations extracted from the WSDL
     * - documentation : Moldova, Republic of
     * @return string 'MD'
     */
    const VALUE_MD = 'MD';
    /**
     * Constant for value 'MG'
     * Meta informations extracted from the WSDL
     * - documentation : Madagascar
     * @return string 'MG'
     */
    const VALUE_MG = 'MG';
    /**
     * Constant for value 'MH'
     * Meta informations extracted from the WSDL
     * - documentation : Marshall Islands
     * @return string 'MH'
     */
    const VALUE_MH = 'MH';
    /**
     * Constant for value 'MK'
     * Meta informations extracted from the WSDL
     * - documentation : Macedonia, the Former Yugoslav Republic of
     * @return string 'MK'
     */
    const VALUE_MK = 'MK';
    /**
     * Constant for value 'ML'
     * Meta informations extracted from the WSDL
     * - documentation : Mali
     * @return string 'ML'
     */
    const VALUE_ML = 'ML';
    /**
     * Constant for value 'MM'
     * Meta informations extracted from the WSDL
     * - documentation : Myanmar
     * @return string 'MM'
     */
    const VALUE_MM = 'MM';
    /**
     * Constant for value 'MN'
     * Meta informations extracted from the WSDL
     * - documentation : Mongolia
     * @return string 'MN'
     */
    const VALUE_MN = 'MN';
    /**
     * Constant for value 'MO'
     * Meta informations extracted from the WSDL
     * - documentation : Macao
     * @return string 'MO'
     */
    const VALUE_MO = 'MO';
    /**
     * Constant for value 'MP'
     * Meta informations extracted from the WSDL
     * - documentation : Northern Mariana Islands
     * @return string 'MP'
     */
    const VALUE_MP = 'MP';
    /**
     * Constant for value 'MQ'
     * Meta informations extracted from the WSDL
     * - documentation : Martinique
     * @return string 'MQ'
     */
    const VALUE_MQ = 'MQ';
    /**
     * Constant for value 'MR'
     * Meta informations extracted from the WSDL
     * - documentation : Mauritania
     * @return string 'MR'
     */
    const VALUE_MR = 'MR';
    /**
     * Constant for value 'MS'
     * Meta informations extracted from the WSDL
     * - documentation : Montserrat
     * @return string 'MS'
     */
    const VALUE_MS = 'MS';
    /**
     * Constant for value 'MT'
     * Meta informations extracted from the WSDL
     * - documentation : Malta
     * @return string 'MT'
     */
    const VALUE_MT = 'MT';
    /**
     * Constant for value 'MU'
     * Meta informations extracted from the WSDL
     * - documentation : Mauritius
     * @return string 'MU'
     */
    const VALUE_MU = 'MU';
    /**
     * Constant for value 'MV'
     * Meta informations extracted from the WSDL
     * - documentation : Maldives
     * @return string 'MV'
     */
    const VALUE_MV = 'MV';
    /**
     * Constant for value 'MW'
     * Meta informations extracted from the WSDL
     * - documentation : Malawi
     * @return string 'MW'
     */
    const VALUE_MW = 'MW';
    /**
     * Constant for value 'MX'
     * Meta informations extracted from the WSDL
     * - documentation : Mexico
     * @return string 'MX'
     */
    const VALUE_MX = 'MX';
    /**
     * Constant for value 'MY'
     * Meta informations extracted from the WSDL
     * - documentation : Malaysia
     * @return string 'MY'
     */
    const VALUE_MY = 'MY';
    /**
     * Constant for value 'MZ'
     * Meta informations extracted from the WSDL
     * - documentation : Mozambique
     * @return string 'MZ'
     */
    const VALUE_MZ = 'MZ';
    /**
     * Constant for value 'NA'
     * Meta informations extracted from the WSDL
     * - documentation : Namibia
     * @return string 'NA'
     */
    const VALUE_NA = 'NA';
    /**
     * Constant for value 'NC'
     * Meta informations extracted from the WSDL
     * - documentation : New Caledonia
     * @return string 'NC'
     */
    const VALUE_NC = 'NC';
    /**
     * Constant for value 'NE'
     * Meta informations extracted from the WSDL
     * - documentation : Niger
     * @return string 'NE'
     */
    const VALUE_NE = 'NE';
    /**
     * Constant for value 'NF'
     * Meta informations extracted from the WSDL
     * - documentation : Norfolk Island
     * @return string 'NF'
     */
    const VALUE_NF = 'NF';
    /**
     * Constant for value 'NG'
     * Meta informations extracted from the WSDL
     * - documentation : Nigeria
     * @return string 'NG'
     */
    const VALUE_NG = 'NG';
    /**
     * Constant for value 'NI'
     * Meta informations extracted from the WSDL
     * - documentation : Nicaragua
     * @return string 'NI'
     */
    const VALUE_NI = 'NI';
    /**
     * Constant for value 'NL'
     * Meta informations extracted from the WSDL
     * - documentation : Netherlands
     * @return string 'NL'
     */
    const VALUE_NL = 'NL';
    /**
     * Constant for value 'NO'
     * Meta informations extracted from the WSDL
     * - documentation : Norway
     * @return string 'NO'
     */
    const VALUE_NO = 'NO';
    /**
     * Constant for value 'NP'
     * Meta informations extracted from the WSDL
     * - documentation : Nepal
     * @return string 'NP'
     */
    const VALUE_NP = 'NP';
    /**
     * Constant for value 'NR'
     * Meta informations extracted from the WSDL
     * - documentation : Nauru
     * @return string 'NR'
     */
    const VALUE_NR = 'NR';
    /**
     * Constant for value 'NU'
     * Meta informations extracted from the WSDL
     * - documentation : Niue
     * @return string 'NU'
     */
    const VALUE_NU = 'NU';
    /**
     * Constant for value 'NZ'
     * Meta informations extracted from the WSDL
     * - documentation : New Zealand
     * @return string 'NZ'
     */
    const VALUE_NZ = 'NZ';
    /**
     * Constant for value 'OM'
     * Meta informations extracted from the WSDL
     * - documentation : Oman
     * @return string 'OM'
     */
    const VALUE_OM = 'OM';
    /**
     * Constant for value 'PA'
     * Meta informations extracted from the WSDL
     * - documentation : Panama
     * @return string 'PA'
     */
    const VALUE_PA = 'PA';
    /**
     * Constant for value 'PE'
     * Meta informations extracted from the WSDL
     * - documentation : Peru
     * @return string 'PE'
     */
    const VALUE_PE = 'PE';
    /**
     * Constant for value 'PF'
     * Meta informations extracted from the WSDL
     * - documentation : French Polynesia
     * @return string 'PF'
     */
    const VALUE_PF = 'PF';
    /**
     * Constant for value 'PG'
     * Meta informations extracted from the WSDL
     * - documentation : Papua New Guinea
     * @return string 'PG'
     */
    const VALUE_PG = 'PG';
    /**
     * Constant for value 'PH'
     * Meta informations extracted from the WSDL
     * - documentation : Philippines
     * @return string 'PH'
     */
    const VALUE_PH = 'PH';
    /**
     * Constant for value 'PK'
     * Meta informations extracted from the WSDL
     * - documentation : Pakistan
     * @return string 'PK'
     */
    const VALUE_PK = 'PK';
    /**
     * Constant for value 'PL'
     * Meta informations extracted from the WSDL
     * - documentation : Poland
     * @return string 'PL'
     */
    const VALUE_PL = 'PL';
    /**
     * Constant for value 'PM'
     * Meta informations extracted from the WSDL
     * - documentation : Saint Pierre and Miquelon
     * @return string 'PM'
     */
    const VALUE_PM = 'PM';
    /**
     * Constant for value 'PN'
     * Meta informations extracted from the WSDL
     * - documentation : Pitcairn
     * @return string 'PN'
     */
    const VALUE_PN = 'PN';
    /**
     * Constant for value 'PR'
     * Meta informations extracted from the WSDL
     * - documentation : Puerto Rico
     * @return string 'PR'
     */
    const VALUE_PR = 'PR';
    /**
     * Constant for value 'PT'
     * Meta informations extracted from the WSDL
     * - documentation : Portugal
     * @return string 'PT'
     */
    const VALUE_PT = 'PT';
    /**
     * Constant for value 'PW'
     * Meta informations extracted from the WSDL
     * - documentation : Palau
     * @return string 'PW'
     */
    const VALUE_PW = 'PW';
    /**
     * Constant for value 'PY'
     * Meta informations extracted from the WSDL
     * - documentation : Paraguay
     * @return string 'PY'
     */
    const VALUE_PY = 'PY';
    /**
     * Constant for value 'QA'
     * Meta informations extracted from the WSDL
     * - documentation : Qatar
     * @return string 'QA'
     */
    const VALUE_QA = 'QA';
    /**
     * Constant for value 'RE'
     * Meta informations extracted from the WSDL
     * - documentation : Reunion
     * @return string 'RE'
     */
    const VALUE_RE = 'RE';
    /**
     * Constant for value 'RO'
     * Meta informations extracted from the WSDL
     * - documentation : Romania
     * @return string 'RO'
     */
    const VALUE_RO = 'RO';
    /**
     * Constant for value 'RU'
     * Meta informations extracted from the WSDL
     * - documentation : Russian Federation
     * @return string 'RU'
     */
    const VALUE_RU = 'RU';
    /**
     * Constant for value 'RW'
     * Meta informations extracted from the WSDL
     * - documentation : Rwanda
     * @return string 'RW'
     */
    const VALUE_RW = 'RW';
    /**
     * Constant for value 'SA'
     * Meta informations extracted from the WSDL
     * - documentation : Saudi Arabia
     * @return string 'SA'
     */
    const VALUE_SA = 'SA';
    /**
     * Constant for value 'SB'
     * Meta informations extracted from the WSDL
     * - documentation : Solomon Islands
     * @return string 'SB'
     */
    const VALUE_SB = 'SB';
    /**
     * Constant for value 'SC'
     * Meta informations extracted from the WSDL
     * - documentation : Seychelles
     * @return string 'SC'
     */
    const VALUE_SC = 'SC';
    /**
     * Constant for value 'SD'
     * Meta informations extracted from the WSDL
     * - documentation : Sudan
     * @return string 'SD'
     */
    const VALUE_SD = 'SD';
    /**
     * Constant for value 'SE'
     * Meta informations extracted from the WSDL
     * - documentation : Sweden
     * @return string 'SE'
     */
    const VALUE_SE = 'SE';
    /**
     * Constant for value 'SG'
     * Meta informations extracted from the WSDL
     * - documentation : Singapore
     * @return string 'SG'
     */
    const VALUE_SG = 'SG';
    /**
     * Constant for value 'SH'
     * Meta informations extracted from the WSDL
     * - documentation : Saint Helena
     * @return string 'SH'
     */
    const VALUE_SH = 'SH';
    /**
     * Constant for value 'SI'
     * Meta informations extracted from the WSDL
     * - documentation : Slovenia
     * @return string 'SI'
     */
    const VALUE_SI = 'SI';
    /**
     * Constant for value 'SJ'
     * Meta informations extracted from the WSDL
     * - documentation : Svalbard and Jan Mayen
     * @return string 'SJ'
     */
    const VALUE_SJ = 'SJ';
    /**
     * Constant for value 'SK'
     * Meta informations extracted from the WSDL
     * - documentation : Slovakia
     * @return string 'SK'
     */
    const VALUE_SK = 'SK';
    /**
     * Constant for value 'SL'
     * Meta informations extracted from the WSDL
     * - documentation : Sierra Leone
     * @return string 'SL'
     */
    const VALUE_SL = 'SL';
    /**
     * Constant for value 'SM'
     * Meta informations extracted from the WSDL
     * - documentation : San Marino
     * @return string 'SM'
     */
    const VALUE_SM = 'SM';
    /**
     * Constant for value 'SN'
     * Meta informations extracted from the WSDL
     * - documentation : Senegal
     * @return string 'SN'
     */
    const VALUE_SN = 'SN';
    /**
     * Constant for value 'SO'
     * Meta informations extracted from the WSDL
     * - documentation : Somalia
     * @return string 'SO'
     */
    const VALUE_SO = 'SO';
    /**
     * Constant for value 'SR'
     * Meta informations extracted from the WSDL
     * - documentation : Suriname
     * @return string 'SR'
     */
    const VALUE_SR = 'SR';
    /**
     * Constant for value 'ST'
     * Meta informations extracted from the WSDL
     * - documentation : Sao Tome and Principe
     * @return string 'ST'
     */
    const VALUE_ST = 'ST';
    /**
     * Constant for value 'SV'
     * Meta informations extracted from the WSDL
     * - documentation : El Salvador
     * @return string 'SV'
     */
    const VALUE_SV = 'SV';
    /**
     * Constant for value 'SY'
     * Meta informations extracted from the WSDL
     * - documentation : Syrian Arab Republic
     * @return string 'SY'
     */
    const VALUE_SY = 'SY';
    /**
     * Constant for value 'SZ'
     * Meta informations extracted from the WSDL
     * - documentation : Swaziland
     * @return string 'SZ'
     */
    const VALUE_SZ = 'SZ';
    /**
     * Constant for value 'TC'
     * Meta informations extracted from the WSDL
     * - documentation : Turks and Caicos Islands
     * @return string 'TC'
     */
    const VALUE_TC = 'TC';
    /**
     * Constant for value 'TD'
     * Meta informations extracted from the WSDL
     * - documentation : Chad
     * @return string 'TD'
     */
    const VALUE_TD = 'TD';
    /**
     * Constant for value 'TG'
     * Meta informations extracted from the WSDL
     * - documentation : Togo
     * @return string 'TG'
     */
    const VALUE_TG = 'TG';
    /**
     * Constant for value 'TH'
     * Meta informations extracted from the WSDL
     * - documentation : Thailand
     * @return string 'TH'
     */
    const VALUE_TH = 'TH';
    /**
     * Constant for value 'TJ'
     * Meta informations extracted from the WSDL
     * - documentation : Tajikistan
     * @return string 'TJ'
     */
    const VALUE_TJ = 'TJ';
    /**
     * Constant for value 'TK'
     * Meta informations extracted from the WSDL
     * - documentation : Tokelau
     * @return string 'TK'
     */
    const VALUE_TK = 'TK';
    /**
     * Constant for value 'TM'
     * Meta informations extracted from the WSDL
     * - documentation : Turkmenistan
     * @return string 'TM'
     */
    const VALUE_TM = 'TM';
    /**
     * Constant for value 'TN'
     * Meta informations extracted from the WSDL
     * - documentation : Tunisia
     * @return string 'TN'
     */
    const VALUE_TN = 'TN';
    /**
     * Constant for value 'TO'
     * Meta informations extracted from the WSDL
     * - documentation : Tonga
     * @return string 'TO'
     */
    const VALUE_TO = 'TO';
    /**
     * Constant for value 'TR'
     * Meta informations extracted from the WSDL
     * - documentation : Turkey
     * @return string 'TR'
     */
    const VALUE_TR = 'TR';
    /**
     * Constant for value 'TT'
     * Meta informations extracted from the WSDL
     * - documentation : Trinidad and Tobago
     * @return string 'TT'
     */
    const VALUE_TT = 'TT';
    /**
     * Constant for value 'TV'
     * Meta informations extracted from the WSDL
     * - documentation : Tuvalu
     * @return string 'TV'
     */
    const VALUE_TV = 'TV';
    /**
     * Constant for value 'TW'
     * Meta informations extracted from the WSDL
     * - documentation : Taiwan, Province of China
     * @return string 'TW'
     */
    const VALUE_TW = 'TW';
    /**
     * Constant for value 'TZ'
     * Meta informations extracted from the WSDL
     * - documentation : Tanzania, United Republic of
     * @return string 'TZ'
     */
    const VALUE_TZ = 'TZ';
    /**
     * Constant for value 'UA'
     * Meta informations extracted from the WSDL
     * - documentation : Ukraine
     * @return string 'UA'
     */
    const VALUE_UA = 'UA';
    /**
     * Constant for value 'UG'
     * Meta informations extracted from the WSDL
     * - documentation : Uganda
     * @return string 'UG'
     */
    const VALUE_UG = 'UG';
    /**
     * Constant for value 'US'
     * Meta informations extracted from the WSDL
     * - documentation : United States
     * @return string 'US'
     */
    const VALUE_US = 'US';
    /**
     * Constant for value 'UY'
     * Meta informations extracted from the WSDL
     * - documentation : Uruguay
     * @return string 'UY'
     */
    const VALUE_UY = 'UY';
    /**
     * Constant for value 'UZ'
     * Meta informations extracted from the WSDL
     * - documentation : Uzbekistan
     * @return string 'UZ'
     */
    const VALUE_UZ = 'UZ';
    /**
     * Constant for value 'VA'
     * Meta informations extracted from the WSDL
     * - documentation : Holy See (Vatican City State)
     * @return string 'VA'
     */
    const VALUE_VA = 'VA';
    /**
     * Constant for value 'VC'
     * Meta informations extracted from the WSDL
     * - documentation : Saint Vincent and the Grenadines
     * @return string 'VC'
     */
    const VALUE_VC = 'VC';
    /**
     * Constant for value 'VE'
     * Meta informations extracted from the WSDL
     * - documentation : Venezuela
     * @return string 'VE'
     */
    const VALUE_VE = 'VE';
    /**
     * Constant for value 'VG'
     * Meta informations extracted from the WSDL
     * - documentation : Virgin Islands, British
     * @return string 'VG'
     */
    const VALUE_VG = 'VG';
    /**
     * Constant for value 'VI'
     * Meta informations extracted from the WSDL
     * - documentation : Virgin Islands, U.s.
     * @return string 'VI'
     */
    const VALUE_VI = 'VI';
    /**
     * Constant for value 'VN'
     * Meta informations extracted from the WSDL
     * - documentation : Viet Nam
     * @return string 'VN'
     */
    const VALUE_VN = 'VN';
    /**
     * Constant for value 'VU'
     * Meta informations extracted from the WSDL
     * - documentation : Vanuatu
     * @return string 'VU'
     */
    const VALUE_VU = 'VU';
    /**
     * Constant for value 'WF'
     * Meta informations extracted from the WSDL
     * - documentation : Wallis and Futuna
     * @return string 'WF'
     */
    const VALUE_WF = 'WF';
    /**
     * Constant for value 'WS'
     * Meta informations extracted from the WSDL
     * - documentation : Samoa
     * @return string 'WS'
     */
    const VALUE_WS = 'WS';
    /**
     * Constant for value 'YE'
     * Meta informations extracted from the WSDL
     * - documentation : Yemen
     * @return string 'YE'
     */
    const VALUE_YE = 'YE';
    /**
     * Constant for value 'ZA'
     * Meta informations extracted from the WSDL
     * - documentation : South Africa
     * @return string 'ZA'
     */
    const VALUE_ZA = 'ZA';
    /**
     * Constant for value 'ZM'
     * Meta informations extracted from the WSDL
     * - documentation : Zambia
     * @return string 'ZM'
     */
    const VALUE_ZM = 'ZM';
    /**
     * Constant for value 'ZW'
     * Meta informations extracted from the WSDL
     * - documentation : Zimbabwe
     * @return string 'ZW'
     */
    const VALUE_ZW = 'ZW';
    /**
     * Return true if value is allowed
     * @uses WsdlEnumCountryCode::VALUE_AD
     * @uses WsdlEnumCountryCode::VALUE_AE
     * @uses WsdlEnumCountryCode::VALUE_AF
     * @uses WsdlEnumCountryCode::VALUE_AG
     * @uses WsdlEnumCountryCode::VALUE_AI
     * @uses WsdlEnumCountryCode::VALUE_AL
     * @uses WsdlEnumCountryCode::VALUE_AM
     * @uses WsdlEnumCountryCode::VALUE_AN
     * @uses WsdlEnumCountryCode::VALUE_AO
     * @uses WsdlEnumCountryCode::VALUE_AR
     * @uses WsdlEnumCountryCode::VALUE_AS
     * @uses WsdlEnumCountryCode::VALUE_AT
     * @uses WsdlEnumCountryCode::VALUE_AU
     * @uses WsdlEnumCountryCode::VALUE_AW
     * @uses WsdlEnumCountryCode::VALUE_AZ
     * @uses WsdlEnumCountryCode::VALUE_BA
     * @uses WsdlEnumCountryCode::VALUE_BB
     * @uses WsdlEnumCountryCode::VALUE_BD
     * @uses WsdlEnumCountryCode::VALUE_BE
     * @uses WsdlEnumCountryCode::VALUE_BF
     * @uses WsdlEnumCountryCode::VALUE_BG
     * @uses WsdlEnumCountryCode::VALUE_BH
     * @uses WsdlEnumCountryCode::VALUE_BI
     * @uses WsdlEnumCountryCode::VALUE_BJ
     * @uses WsdlEnumCountryCode::VALUE_BM
     * @uses WsdlEnumCountryCode::VALUE_BN
     * @uses WsdlEnumCountryCode::VALUE_BO
     * @uses WsdlEnumCountryCode::VALUE_BR
     * @uses WsdlEnumCountryCode::VALUE_BS
     * @uses WsdlEnumCountryCode::VALUE_BT
     * @uses WsdlEnumCountryCode::VALUE_BW
     * @uses WsdlEnumCountryCode::VALUE_BY
     * @uses WsdlEnumCountryCode::VALUE_BZ
     * @uses WsdlEnumCountryCode::VALUE_CA
     * @uses WsdlEnumCountryCode::VALUE_CD
     * @uses WsdlEnumCountryCode::VALUE_CF
     * @uses WsdlEnumCountryCode::VALUE_CG
     * @uses WsdlEnumCountryCode::VALUE_CH
     * @uses WsdlEnumCountryCode::VALUE_CI
     * @uses WsdlEnumCountryCode::VALUE_CK
     * @uses WsdlEnumCountryCode::VALUE_CL
     * @uses WsdlEnumCountryCode::VALUE_CM
     * @uses WsdlEnumCountryCode::VALUE_CN
     * @uses WsdlEnumCountryCode::VALUE_CO
     * @uses WsdlEnumCountryCode::VALUE_CR
     * @uses WsdlEnumCountryCode::VALUE_CU
     * @uses WsdlEnumCountryCode::VALUE_CV
     * @uses WsdlEnumCountryCode::VALUE_CY
     * @uses WsdlEnumCountryCode::VALUE_CZ
     * @uses WsdlEnumCountryCode::VALUE_DE
     * @uses WsdlEnumCountryCode::VALUE_DJ
     * @uses WsdlEnumCountryCode::VALUE_DK
     * @uses WsdlEnumCountryCode::VALUE_DM
     * @uses WsdlEnumCountryCode::VALUE_DO
     * @uses WsdlEnumCountryCode::VALUE_DZ
     * @uses WsdlEnumCountryCode::VALUE_EC
     * @uses WsdlEnumCountryCode::VALUE_EE
     * @uses WsdlEnumCountryCode::VALUE_EG
     * @uses WsdlEnumCountryCode::VALUE_EH
     * @uses WsdlEnumCountryCode::VALUE_ER
     * @uses WsdlEnumCountryCode::VALUE_ES
     * @uses WsdlEnumCountryCode::VALUE_ET
     * @uses WsdlEnumCountryCode::VALUE_FI
     * @uses WsdlEnumCountryCode::VALUE_FJ
     * @uses WsdlEnumCountryCode::VALUE_FK
     * @uses WsdlEnumCountryCode::VALUE_FM
     * @uses WsdlEnumCountryCode::VALUE_FO
     * @uses WsdlEnumCountryCode::VALUE_FR
     * @uses WsdlEnumCountryCode::VALUE_GA
     * @uses WsdlEnumCountryCode::VALUE_GB
     * @uses WsdlEnumCountryCode::VALUE_GD
     * @uses WsdlEnumCountryCode::VALUE_GE
     * @uses WsdlEnumCountryCode::VALUE_GF
     * @uses WsdlEnumCountryCode::VALUE_GH
     * @uses WsdlEnumCountryCode::VALUE_GI
     * @uses WsdlEnumCountryCode::VALUE_GL
     * @uses WsdlEnumCountryCode::VALUE_GM
     * @uses WsdlEnumCountryCode::VALUE_GN
     * @uses WsdlEnumCountryCode::VALUE_GP
     * @uses WsdlEnumCountryCode::VALUE_GQ
     * @uses WsdlEnumCountryCode::VALUE_GR
     * @uses WsdlEnumCountryCode::VALUE_GT
     * @uses WsdlEnumCountryCode::VALUE_GU
     * @uses WsdlEnumCountryCode::VALUE_GW
     * @uses WsdlEnumCountryCode::VALUE_GY
     * @uses WsdlEnumCountryCode::VALUE_HK
     * @uses WsdlEnumCountryCode::VALUE_HN
     * @uses WsdlEnumCountryCode::VALUE_HR
     * @uses WsdlEnumCountryCode::VALUE_HT
     * @uses WsdlEnumCountryCode::VALUE_HU
     * @uses WsdlEnumCountryCode::VALUE_ID
     * @uses WsdlEnumCountryCode::VALUE_IE
     * @uses WsdlEnumCountryCode::VALUE_IL
     * @uses WsdlEnumCountryCode::VALUE_IN
     * @uses WsdlEnumCountryCode::VALUE_IQ
     * @uses WsdlEnumCountryCode::VALUE_IR
     * @uses WsdlEnumCountryCode::VALUE_IS
     * @uses WsdlEnumCountryCode::VALUE_IT
     * @uses WsdlEnumCountryCode::VALUE_JM
     * @uses WsdlEnumCountryCode::VALUE_JO
     * @uses WsdlEnumCountryCode::VALUE_JP
     * @uses WsdlEnumCountryCode::VALUE_KE
     * @uses WsdlEnumCountryCode::VALUE_KG
     * @uses WsdlEnumCountryCode::VALUE_KH
     * @uses WsdlEnumCountryCode::VALUE_KI
     * @uses WsdlEnumCountryCode::VALUE_KM
     * @uses WsdlEnumCountryCode::VALUE_KN
     * @uses WsdlEnumCountryCode::VALUE_KP
     * @uses WsdlEnumCountryCode::VALUE_KR
     * @uses WsdlEnumCountryCode::VALUE_KW
     * @uses WsdlEnumCountryCode::VALUE_KY
     * @uses WsdlEnumCountryCode::VALUE_KZ
     * @uses WsdlEnumCountryCode::VALUE_LA
     * @uses WsdlEnumCountryCode::VALUE_LB
     * @uses WsdlEnumCountryCode::VALUE_LC
     * @uses WsdlEnumCountryCode::VALUE_LI
     * @uses WsdlEnumCountryCode::VALUE_LK
     * @uses WsdlEnumCountryCode::VALUE_LR
     * @uses WsdlEnumCountryCode::VALUE_LS
     * @uses WsdlEnumCountryCode::VALUE_LT
     * @uses WsdlEnumCountryCode::VALUE_LU
     * @uses WsdlEnumCountryCode::VALUE_LV
     * @uses WsdlEnumCountryCode::VALUE_LY
     * @uses WsdlEnumCountryCode::VALUE_MA
     * @uses WsdlEnumCountryCode::VALUE_MC
     * @uses WsdlEnumCountryCode::VALUE_MD
     * @uses WsdlEnumCountryCode::VALUE_MG
     * @uses WsdlEnumCountryCode::VALUE_MH
     * @uses WsdlEnumCountryCode::VALUE_MK
     * @uses WsdlEnumCountryCode::VALUE_ML
     * @uses WsdlEnumCountryCode::VALUE_MM
     * @uses WsdlEnumCountryCode::VALUE_MN
     * @uses WsdlEnumCountryCode::VALUE_MO
     * @uses WsdlEnumCountryCode::VALUE_MP
     * @uses WsdlEnumCountryCode::VALUE_MQ
     * @uses WsdlEnumCountryCode::VALUE_MR
     * @uses WsdlEnumCountryCode::VALUE_MS
     * @uses WsdlEnumCountryCode::VALUE_MT
     * @uses WsdlEnumCountryCode::VALUE_MU
     * @uses WsdlEnumCountryCode::VALUE_MV
     * @uses WsdlEnumCountryCode::VALUE_MW
     * @uses WsdlEnumCountryCode::VALUE_MX
     * @uses WsdlEnumCountryCode::VALUE_MY
     * @uses WsdlEnumCountryCode::VALUE_MZ
     * @uses WsdlEnumCountryCode::VALUE_NA
     * @uses WsdlEnumCountryCode::VALUE_NC
     * @uses WsdlEnumCountryCode::VALUE_NE
     * @uses WsdlEnumCountryCode::VALUE_NF
     * @uses WsdlEnumCountryCode::VALUE_NG
     * @uses WsdlEnumCountryCode::VALUE_NI
     * @uses WsdlEnumCountryCode::VALUE_NL
     * @uses WsdlEnumCountryCode::VALUE_NO
     * @uses WsdlEnumCountryCode::VALUE_NP
     * @uses WsdlEnumCountryCode::VALUE_NR
     * @uses WsdlEnumCountryCode::VALUE_NU
     * @uses WsdlEnumCountryCode::VALUE_NZ
     * @uses WsdlEnumCountryCode::VALUE_OM
     * @uses WsdlEnumCountryCode::VALUE_PA
     * @uses WsdlEnumCountryCode::VALUE_PE
     * @uses WsdlEnumCountryCode::VALUE_PF
     * @uses WsdlEnumCountryCode::VALUE_PG
     * @uses WsdlEnumCountryCode::VALUE_PH
     * @uses WsdlEnumCountryCode::VALUE_PK
     * @uses WsdlEnumCountryCode::VALUE_PL
     * @uses WsdlEnumCountryCode::VALUE_PM
     * @uses WsdlEnumCountryCode::VALUE_PN
     * @uses WsdlEnumCountryCode::VALUE_PR
     * @uses WsdlEnumCountryCode::VALUE_PT
     * @uses WsdlEnumCountryCode::VALUE_PW
     * @uses WsdlEnumCountryCode::VALUE_PY
     * @uses WsdlEnumCountryCode::VALUE_QA
     * @uses WsdlEnumCountryCode::VALUE_RE
     * @uses WsdlEnumCountryCode::VALUE_RO
     * @uses WsdlEnumCountryCode::VALUE_RU
     * @uses WsdlEnumCountryCode::VALUE_RW
     * @uses WsdlEnumCountryCode::VALUE_SA
     * @uses WsdlEnumCountryCode::VALUE_SB
     * @uses WsdlEnumCountryCode::VALUE_SC
     * @uses WsdlEnumCountryCode::VALUE_SD
     * @uses WsdlEnumCountryCode::VALUE_SE
     * @uses WsdlEnumCountryCode::VALUE_SG
     * @uses WsdlEnumCountryCode::VALUE_SH
     * @uses WsdlEnumCountryCode::VALUE_SI
     * @uses WsdlEnumCountryCode::VALUE_SJ
     * @uses WsdlEnumCountryCode::VALUE_SK
     * @uses WsdlEnumCountryCode::VALUE_SL
     * @uses WsdlEnumCountryCode::VALUE_SM
     * @uses WsdlEnumCountryCode::VALUE_SN
     * @uses WsdlEnumCountryCode::VALUE_SO
     * @uses WsdlEnumCountryCode::VALUE_SR
     * @uses WsdlEnumCountryCode::VALUE_ST
     * @uses WsdlEnumCountryCode::VALUE_SV
     * @uses WsdlEnumCountryCode::VALUE_SY
     * @uses WsdlEnumCountryCode::VALUE_SZ
     * @uses WsdlEnumCountryCode::VALUE_TC
     * @uses WsdlEnumCountryCode::VALUE_TD
     * @uses WsdlEnumCountryCode::VALUE_TG
     * @uses WsdlEnumCountryCode::VALUE_TH
     * @uses WsdlEnumCountryCode::VALUE_TJ
     * @uses WsdlEnumCountryCode::VALUE_TK
     * @uses WsdlEnumCountryCode::VALUE_TM
     * @uses WsdlEnumCountryCode::VALUE_TN
     * @uses WsdlEnumCountryCode::VALUE_TO
     * @uses WsdlEnumCountryCode::VALUE_TR
     * @uses WsdlEnumCountryCode::VALUE_TT
     * @uses WsdlEnumCountryCode::VALUE_TV
     * @uses WsdlEnumCountryCode::VALUE_TW
     * @uses WsdlEnumCountryCode::VALUE_TZ
     * @uses WsdlEnumCountryCode::VALUE_UA
     * @uses WsdlEnumCountryCode::VALUE_UG
     * @uses WsdlEnumCountryCode::VALUE_US
     * @uses WsdlEnumCountryCode::VALUE_UY
     * @uses WsdlEnumCountryCode::VALUE_UZ
     * @uses WsdlEnumCountryCode::VALUE_VA
     * @uses WsdlEnumCountryCode::VALUE_VC
     * @uses WsdlEnumCountryCode::VALUE_VE
     * @uses WsdlEnumCountryCode::VALUE_VG
     * @uses WsdlEnumCountryCode::VALUE_VI
     * @uses WsdlEnumCountryCode::VALUE_VN
     * @uses WsdlEnumCountryCode::VALUE_VU
     * @uses WsdlEnumCountryCode::VALUE_WF
     * @uses WsdlEnumCountryCode::VALUE_WS
     * @uses WsdlEnumCountryCode::VALUE_YE
     * @uses WsdlEnumCountryCode::VALUE_ZA
     * @uses WsdlEnumCountryCode::VALUE_ZM
     * @uses WsdlEnumCountryCode::VALUE_ZW
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(WsdlEnumCountryCode::VALUE_AD,WsdlEnumCountryCode::VALUE_AE,WsdlEnumCountryCode::VALUE_AF,WsdlEnumCountryCode::VALUE_AG,WsdlEnumCountryCode::VALUE_AI,WsdlEnumCountryCode::VALUE_AL,WsdlEnumCountryCode::VALUE_AM,WsdlEnumCountryCode::VALUE_AN,WsdlEnumCountryCode::VALUE_AO,WsdlEnumCountryCode::VALUE_AR,WsdlEnumCountryCode::VALUE_AS,WsdlEnumCountryCode::VALUE_AT,WsdlEnumCountryCode::VALUE_AU,WsdlEnumCountryCode::VALUE_AW,WsdlEnumCountryCode::VALUE_AZ,WsdlEnumCountryCode::VALUE_BA,WsdlEnumCountryCode::VALUE_BB,WsdlEnumCountryCode::VALUE_BD,WsdlEnumCountryCode::VALUE_BE,WsdlEnumCountryCode::VALUE_BF,WsdlEnumCountryCode::VALUE_BG,WsdlEnumCountryCode::VALUE_BH,WsdlEnumCountryCode::VALUE_BI,WsdlEnumCountryCode::VALUE_BJ,WsdlEnumCountryCode::VALUE_BM,WsdlEnumCountryCode::VALUE_BN,WsdlEnumCountryCode::VALUE_BO,WsdlEnumCountryCode::VALUE_BR,WsdlEnumCountryCode::VALUE_BS,WsdlEnumCountryCode::VALUE_BT,WsdlEnumCountryCode::VALUE_BW,WsdlEnumCountryCode::VALUE_BY,WsdlEnumCountryCode::VALUE_BZ,WsdlEnumCountryCode::VALUE_CA,WsdlEnumCountryCode::VALUE_CD,WsdlEnumCountryCode::VALUE_CF,WsdlEnumCountryCode::VALUE_CG,WsdlEnumCountryCode::VALUE_CH,WsdlEnumCountryCode::VALUE_CI,WsdlEnumCountryCode::VALUE_CK,WsdlEnumCountryCode::VALUE_CL,WsdlEnumCountryCode::VALUE_CM,WsdlEnumCountryCode::VALUE_CN,WsdlEnumCountryCode::VALUE_CO,WsdlEnumCountryCode::VALUE_CR,WsdlEnumCountryCode::VALUE_CU,WsdlEnumCountryCode::VALUE_CV,WsdlEnumCountryCode::VALUE_CY,WsdlEnumCountryCode::VALUE_CZ,WsdlEnumCountryCode::VALUE_DE,WsdlEnumCountryCode::VALUE_DJ,WsdlEnumCountryCode::VALUE_DK,WsdlEnumCountryCode::VALUE_DM,WsdlEnumCountryCode::VALUE_DO,WsdlEnumCountryCode::VALUE_DZ,WsdlEnumCountryCode::VALUE_EC,WsdlEnumCountryCode::VALUE_EE,WsdlEnumCountryCode::VALUE_EG,WsdlEnumCountryCode::VALUE_EH,WsdlEnumCountryCode::VALUE_ER,WsdlEnumCountryCode::VALUE_ES,WsdlEnumCountryCode::VALUE_ET,WsdlEnumCountryCode::VALUE_FI,WsdlEnumCountryCode::VALUE_FJ,WsdlEnumCountryCode::VALUE_FK,WsdlEnumCountryCode::VALUE_FM,WsdlEnumCountryCode::VALUE_FO,WsdlEnumCountryCode::VALUE_FR,WsdlEnumCountryCode::VALUE_GA,WsdlEnumCountryCode::VALUE_GB,WsdlEnumCountryCode::VALUE_GD,WsdlEnumCountryCode::VALUE_GE,WsdlEnumCountryCode::VALUE_GF,WsdlEnumCountryCode::VALUE_GH,WsdlEnumCountryCode::VALUE_GI,WsdlEnumCountryCode::VALUE_GL,WsdlEnumCountryCode::VALUE_GM,WsdlEnumCountryCode::VALUE_GN,WsdlEnumCountryCode::VALUE_GP,WsdlEnumCountryCode::VALUE_GQ,WsdlEnumCountryCode::VALUE_GR,WsdlEnumCountryCode::VALUE_GT,WsdlEnumCountryCode::VALUE_GU,WsdlEnumCountryCode::VALUE_GW,WsdlEnumCountryCode::VALUE_GY,WsdlEnumCountryCode::VALUE_HK,WsdlEnumCountryCode::VALUE_HN,WsdlEnumCountryCode::VALUE_HR,WsdlEnumCountryCode::VALUE_HT,WsdlEnumCountryCode::VALUE_HU,WsdlEnumCountryCode::VALUE_ID,WsdlEnumCountryCode::VALUE_IE,WsdlEnumCountryCode::VALUE_IL,WsdlEnumCountryCode::VALUE_IN,WsdlEnumCountryCode::VALUE_IQ,WsdlEnumCountryCode::VALUE_IR,WsdlEnumCountryCode::VALUE_IS,WsdlEnumCountryCode::VALUE_IT,WsdlEnumCountryCode::VALUE_JM,WsdlEnumCountryCode::VALUE_JO,WsdlEnumCountryCode::VALUE_JP,WsdlEnumCountryCode::VALUE_KE,WsdlEnumCountryCode::VALUE_KG,WsdlEnumCountryCode::VALUE_KH,WsdlEnumCountryCode::VALUE_KI,WsdlEnumCountryCode::VALUE_KM,WsdlEnumCountryCode::VALUE_KN,WsdlEnumCountryCode::VALUE_KP,WsdlEnumCountryCode::VALUE_KR,WsdlEnumCountryCode::VALUE_KW,WsdlEnumCountryCode::VALUE_KY,WsdlEnumCountryCode::VALUE_KZ,WsdlEnumCountryCode::VALUE_LA,WsdlEnumCountryCode::VALUE_LB,WsdlEnumCountryCode::VALUE_LC,WsdlEnumCountryCode::VALUE_LI,WsdlEnumCountryCode::VALUE_LK,WsdlEnumCountryCode::VALUE_LR,WsdlEnumCountryCode::VALUE_LS,WsdlEnumCountryCode::VALUE_LT,WsdlEnumCountryCode::VALUE_LU,WsdlEnumCountryCode::VALUE_LV,WsdlEnumCountryCode::VALUE_LY,WsdlEnumCountryCode::VALUE_MA,WsdlEnumCountryCode::VALUE_MC,WsdlEnumCountryCode::VALUE_MD,WsdlEnumCountryCode::VALUE_MG,WsdlEnumCountryCode::VALUE_MH,WsdlEnumCountryCode::VALUE_MK,WsdlEnumCountryCode::VALUE_ML,WsdlEnumCountryCode::VALUE_MM,WsdlEnumCountryCode::VALUE_MN,WsdlEnumCountryCode::VALUE_MO,WsdlEnumCountryCode::VALUE_MP,WsdlEnumCountryCode::VALUE_MQ,WsdlEnumCountryCode::VALUE_MR,WsdlEnumCountryCode::VALUE_MS,WsdlEnumCountryCode::VALUE_MT,WsdlEnumCountryCode::VALUE_MU,WsdlEnumCountryCode::VALUE_MV,WsdlEnumCountryCode::VALUE_MW,WsdlEnumCountryCode::VALUE_MX,WsdlEnumCountryCode::VALUE_MY,WsdlEnumCountryCode::VALUE_MZ,WsdlEnumCountryCode::VALUE_NA,WsdlEnumCountryCode::VALUE_NC,WsdlEnumCountryCode::VALUE_NE,WsdlEnumCountryCode::VALUE_NF,WsdlEnumCountryCode::VALUE_NG,WsdlEnumCountryCode::VALUE_NI,WsdlEnumCountryCode::VALUE_NL,WsdlEnumCountryCode::VALUE_NO,WsdlEnumCountryCode::VALUE_NP,WsdlEnumCountryCode::VALUE_NR,WsdlEnumCountryCode::VALUE_NU,WsdlEnumCountryCode::VALUE_NZ,WsdlEnumCountryCode::VALUE_OM,WsdlEnumCountryCode::VALUE_PA,WsdlEnumCountryCode::VALUE_PE,WsdlEnumCountryCode::VALUE_PF,WsdlEnumCountryCode::VALUE_PG,WsdlEnumCountryCode::VALUE_PH,WsdlEnumCountryCode::VALUE_PK,WsdlEnumCountryCode::VALUE_PL,WsdlEnumCountryCode::VALUE_PM,WsdlEnumCountryCode::VALUE_PN,WsdlEnumCountryCode::VALUE_PR,WsdlEnumCountryCode::VALUE_PT,WsdlEnumCountryCode::VALUE_PW,WsdlEnumCountryCode::VALUE_PY,WsdlEnumCountryCode::VALUE_QA,WsdlEnumCountryCode::VALUE_RE,WsdlEnumCountryCode::VALUE_RO,WsdlEnumCountryCode::VALUE_RU,WsdlEnumCountryCode::VALUE_RW,WsdlEnumCountryCode::VALUE_SA,WsdlEnumCountryCode::VALUE_SB,WsdlEnumCountryCode::VALUE_SC,WsdlEnumCountryCode::VALUE_SD,WsdlEnumCountryCode::VALUE_SE,WsdlEnumCountryCode::VALUE_SG,WsdlEnumCountryCode::VALUE_SH,WsdlEnumCountryCode::VALUE_SI,WsdlEnumCountryCode::VALUE_SJ,WsdlEnumCountryCode::VALUE_SK,WsdlEnumCountryCode::VALUE_SL,WsdlEnumCountryCode::VALUE_SM,WsdlEnumCountryCode::VALUE_SN,WsdlEnumCountryCode::VALUE_SO,WsdlEnumCountryCode::VALUE_SR,WsdlEnumCountryCode::VALUE_ST,WsdlEnumCountryCode::VALUE_SV,WsdlEnumCountryCode::VALUE_SY,WsdlEnumCountryCode::VALUE_SZ,WsdlEnumCountryCode::VALUE_TC,WsdlEnumCountryCode::VALUE_TD,WsdlEnumCountryCode::VALUE_TG,WsdlEnumCountryCode::VALUE_TH,WsdlEnumCountryCode::VALUE_TJ,WsdlEnumCountryCode::VALUE_TK,WsdlEnumCountryCode::VALUE_TM,WsdlEnumCountryCode::VALUE_TN,WsdlEnumCountryCode::VALUE_TO,WsdlEnumCountryCode::VALUE_TR,WsdlEnumCountryCode::VALUE_TT,WsdlEnumCountryCode::VALUE_TV,WsdlEnumCountryCode::VALUE_TW,WsdlEnumCountryCode::VALUE_TZ,WsdlEnumCountryCode::VALUE_UA,WsdlEnumCountryCode::VALUE_UG,WsdlEnumCountryCode::VALUE_US,WsdlEnumCountryCode::VALUE_UY,WsdlEnumCountryCode::VALUE_UZ,WsdlEnumCountryCode::VALUE_VA,WsdlEnumCountryCode::VALUE_VC,WsdlEnumCountryCode::VALUE_VE,WsdlEnumCountryCode::VALUE_VG,WsdlEnumCountryCode::VALUE_VI,WsdlEnumCountryCode::VALUE_VN,WsdlEnumCountryCode::VALUE_VU,WsdlEnumCountryCode::VALUE_WF,WsdlEnumCountryCode::VALUE_WS,WsdlEnumCountryCode::VALUE_YE,WsdlEnumCountryCode::VALUE_ZA,WsdlEnumCountryCode::VALUE_ZM,WsdlEnumCountryCode::VALUE_ZW));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
