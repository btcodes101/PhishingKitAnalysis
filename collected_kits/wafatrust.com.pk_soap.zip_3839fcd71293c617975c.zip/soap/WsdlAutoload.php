<?php
/**
 * File to load generated classes once at once time
 * @package Wsdl
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * Includes for all generated classes files
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
require_once dirname(__FILE__) . '/WsdlWsdlClass.php';
require_once dirname(__FILE__) . '/Abstract/Type/WsdlStructAbstractResponseType.php';
require_once dirname(__FILE__) . '/Abstract/Type/WsdlStructAbstractRequestType.php';
require_once dirname(__FILE__) . '/Abstract/Detail/WsdlStructAbstractSkuDetail.php';
require_once dirname(__FILE__) . '/Abstract/Option/WsdlStructAbstractDeliveryOption.php';
require_once dirname(__FILE__) . '/Error/WsdlStructError.php';
require_once dirname(__FILE__) . '/Create/Type/WsdlStructCreateOrderRequestType.php';
require_once dirname(__FILE__) . '/Add/Type/WsdlStructAddOrderItemRequestType.php';
require_once dirname(__FILE__) . '/Array/Item/WsdlStructArrayOfBreakBulkOrderItem.php';
require_once dirname(__FILE__) . '/Cancel/Type/WsdlStructCancelOrderRequestType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetFreeDirectDispatchCancellationsLeftRequestType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetOrdersRequestType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetOrderDetailRequestType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetAccountStatementRequestType.php';
require_once dirname(__FILE__) . '/Edit/Type/WsdlStructEditOrderItemRequestType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetStockFileRequestType.php';
require_once dirname(__FILE__) . '/Order/Type/WsdlEnumOrderType.php';
require_once dirname(__FILE__) . '/Stock/Sort/WsdlEnumStockFileSort.php';
require_once dirname(__FILE__) . '/Stock/Field/WsdlEnumStockFileField.php';
require_once dirname(__FILE__) . '/File/Format/WsdlEnumFileFormat.php';
require_once dirname(__FILE__) . '/Order/Status/WsdlEnumOrderStatus.php';
require_once dirname(__FILE__) . '/Currency/WsdlEnumCurrency.php';
require_once dirname(__FILE__) . '/Product/Type/WsdlStructProductSearchRequestType.php';
require_once dirname(__FILE__) . '/Account/Type/WsdlEnumAccountInformationType.php';
require_once dirname(__FILE__) . '/Country/Code/WsdlEnumCountryCode.php';
require_once dirname(__FILE__) . '/Break/Item/WsdlStructBreakBulkOrderItem.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetAccountInformationRequestType.php';
require_once dirname(__FILE__) . '/Product/Type/WsdlStructProductSearchResponseType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetOrdersResponseType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetOrderDetailResponseType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetFreeDirectDispatchCancellationsLeftResponseType.php';
require_once dirname(__FILE__) . '/Remove/Type/WsdlStructRemoveOrderItemResponseType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetAccountInformationResponseType.php';
require_once dirname(__FILE__) . '/Remove/Type/WsdlStructRemoveBreakBulkOrderItemResponseType.php';
require_once dirname(__FILE__) . '/Add/Type/WsdlStructAddBreakBulkOrderItemResponseType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetHighResImageResponseType.php';
require_once dirname(__FILE__) . '/Place/Type/WsdlStructPlaceOrderResponseType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetAccountStatementResponseType.php';
require_once dirname(__FILE__) . '/Edit/Type/WsdlStructEditOrderItemResponseType.php';
require_once dirname(__FILE__) . '/Add/Type/WsdlStructAddBreakBulkOrderItemRequestType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetHighResImageRequestType.php';
require_once dirname(__FILE__) . '/Place/Type/WsdlStructPlaceOrderRequestType.php';
require_once dirname(__FILE__) . '/Break/Reference/WsdlStructBreakBulkReference.php';
require_once dirname(__FILE__) . '/Remove/Type/WsdlStructRemoveBreakBulkOrderItemRequestType.php';
require_once dirname(__FILE__) . '/Get/Type/WsdlStructGetStockFileResponseType.php';
require_once dirname(__FILE__) . '/Create/Type/WsdlStructCreateOrderResponseType.php';
require_once dirname(__FILE__) . '/Cancel/Type/WsdlStructCancelOrderResponseType.php';
require_once dirname(__FILE__) . '/Add/Type/WsdlStructAddOrderItemResponseType.php';
require_once dirname(__FILE__) . '/Remove/Type/WsdlStructRemoveOrderItemRequestType.php';
require_once dirname(__FILE__) . '/Break/Item/WsdlStructBreakBulkItem.php';
require_once dirname(__FILE__) . '/Order/Summary/WsdlStructOrderCostSummary.php';
require_once dirname(__FILE__) . '/Order/Detail/WsdlStructOrderDetail.php';
require_once dirname(__FILE__) . '/Order/Overview/WsdlStructOrderOverview.php';
require_once dirname(__FILE__) . '/Array/Overview/WsdlStructArrayOfOrderOverview.php';
require_once dirname(__FILE__) . '/Array/Item/WsdlStructArrayOfOrderItem.php';
require_once dirname(__FILE__) . '/Address/WsdlStructAddress.php';
require_once dirname(__FILE__) . '/Transaction/WsdlStructTransaction.php';
require_once dirname(__FILE__) . '/Array/Transaction/WsdlStructArrayOfTransaction.php';
require_once dirname(__FILE__) . '/Array/Item/WsdlStructArrayOfItem.php';
require_once dirname(__FILE__) . '/Array/Code/WsdlStructArrayOfStockCode.php';
require_once dirname(__FILE__) . '/Date/Range/WsdlStructDateRange.php';
require_once dirname(__FILE__) . '/Warning/WsdlStructWarning.php';
require_once dirname(__FILE__) . '/Array/Warning/WsdlStructArrayOfWarning.php';
require_once dirname(__FILE__) . '/Array/Error/WsdlStructArrayOfError.php';
require_once dirname(__FILE__) . '/Array/Field/WsdlStructArrayOfStockFileField.php';
require_once dirname(__FILE__) . '/Order/Item/WsdlStructOrderItem.php';
require_once dirname(__FILE__) . '/Item/WsdlStructItem.php';
require_once dirname(__FILE__) . '/Amount/WsdlStructAmount.php';
require_once dirname(__FILE__) . '/Array/Type/WsdlStructArrayOfAccountInformationType.php';
require_once dirname(__FILE__) . '/Array/Option/WsdlStructArrayOfWholesaleDeliveryOption.php';
require_once dirname(__FILE__) . '/Product/Type/WsdlStructProductType.php';
require_once dirname(__FILE__) . '/Array/Type/WsdlStructArrayOfProductType.php';
require_once dirname(__FILE__) . '/Brand/WsdlStructBrand.php';
require_once dirname(__FILE__) . '/Array/Brand/WsdlStructArrayOfBrand.php';
require_once dirname(__FILE__) . '/Array/Gender/WsdlStructArrayOfGender.php';
require_once dirname(__FILE__) . '/Gender/WsdlStructGender.php';
require_once dirname(__FILE__) . '/Auth/Header/WsdlStructAuthHeader.php';
require_once dirname(__FILE__) . '/Array/Item/WsdlStructArrayOfBreakBulkItem.php';
require_once dirname(__FILE__) . '/Price/Range/WsdlStructPriceRange.php';
require_once dirname(__FILE__) . '/Category/WsdlStructCategory.php';
require_once dirname(__FILE__) . '/Array/Category/WsdlStructArrayOfCategory.php';
require_once dirname(__FILE__) . '/Delivery/Option/WsdlStructDeliveryOption.php';
require_once dirname(__FILE__) . '/Direct/Option/WsdlStructDirectDispatchDeliveryOption.php';
require_once dirname(__FILE__) . '/Wholesale/Option/WsdlStructWholesaleDeliveryOption.php';
require_once dirname(__FILE__) . '/Array/Option/WsdlStructArrayOfDirectDispatchDeliveryOption.php';
require_once dirname(__FILE__) . '/Array/Method/WsdlStructArrayOfPaymentMethod.php';
require_once dirname(__FILE__) . '/Payment/Method/WsdlStructPaymentMethod.php';
require_once dirname(__FILE__) . '/Direct/Fees/WsdlStructDirectDispatchFees.php';
require_once dirname(__FILE__) . '/Break/Fees/WsdlStructBreakBulkFees.php';
require_once dirname(__FILE__) . '/Picture/Fees/WsdlStructPictureFees.php';
require_once dirname(__FILE__) . '/Array/Reference/WsdlStructArrayOfBreakBulkReference.php';
require_once dirname(__FILE__) . '/Add/WsdlServiceAdd.php';
require_once dirname(__FILE__) . '/Cancel/WsdlServiceCancel.php';
require_once dirname(__FILE__) . '/Create/WsdlServiceCreate.php';
require_once dirname(__FILE__) . '/Edit/WsdlServiceEdit.php';
require_once dirname(__FILE__) . '/Get/WsdlServiceGet.php';
require_once dirname(__FILE__) . '/Place/WsdlServicePlace.php';
require_once dirname(__FILE__) . '/Product/WsdlServiceProduct.php';
require_once dirname(__FILE__) . '/Remove/WsdlServiceRemove.php';
require_once dirname(__FILE__) . '/WsdlClassMap.php';
