<?php
/**
 * Test with Wsdl for 'http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl'
 * @package Wsdl
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
ini_set('memory_limit','512M');
ini_set('display_errors',true);
error_reporting(-1);
/**
 * Load autoload
 */
require_once dirname(__FILE__) . '/WsdlAutoload.php';
/**
 * Wsdl instanciation infos. By default, nothing has to be set.
 * If you wish to override the SoapClient's options, please refer to the sample below.
 * 
 * This is an associative array as:
 * - the key must be a WsdlWsdlClass constant beginning with WSDL_
 * - the value must be the corresponding key value
 * Each option matches the {@link http://www.php.net/manual/en/soapclient.soapclient.php} options
 * 
 * Here is below an example of how you can set the array:
 * $wsdl = array();
 * $wsdl[WsdlWsdlClass::WSDL_URL] = 'http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl';
 * $wsdl[WsdlWsdlClass::WSDL_CACHE_WSDL] = WSDL_CACHE_NONE;
 * $wsdl[WsdlWsdlClass::WSDL_TRACE] = true;
 * $wsdl[WsdlWsdlClass::WSDL_LOGIN] = 'myLogin';
 * $wsdl[WsdlWsdlClass::WSDL_PASSWD] = '**********';
 * etc....
 * Then instantiate the Service class as: 
 * - $wsdlObject = new WsdlWsdlClass($wsdl);
 */
/**
 * Examples
 */


/****************************
 * Example for WsdlServiceAdd
 */
$wsdlServiceAdd = new WsdlServiceAdd();
// sample call for WsdlServiceAdd::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
$wsdlServiceAdd->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
// sample call for WsdlServiceAdd::AddBreakBulkOrderItem()
if($wsdlServiceAdd->AddBreakBulkOrderItem(new WsdlStructAddBreakBulkOrderItemRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceAdd->getResult());
else
    print_r($wsdlServiceAdd->getLastError());
// sample call for WsdlServiceAdd::AddOrderItem()
if($wsdlServiceAdd->AddOrderItem(new WsdlStructAddOrderItemRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceAdd->getResult());
else
    print_r($wsdlServiceAdd->getLastError());

/*******************************
 * Example for WsdlServiceCancel
 */
$wsdlServiceCancel = new WsdlServiceCancel();
// sample call for WsdlServiceCancel::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
$wsdlServiceCancel->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
// sample call for WsdlServiceCancel::CancelOrder()
if($wsdlServiceCancel->CancelOrder(new WsdlStructCancelOrderRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceCancel->getResult());
else
    print_r($wsdlServiceCancel->getLastError());

/*******************************
 * Example for WsdlServiceCreate
 */
$wsdlServiceCreate = new WsdlServiceCreate();
// sample call for WsdlServiceCreate::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
$wsdlServiceCreate->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
// sample call for WsdlServiceCreate::CreateOrder()
if($wsdlServiceCreate->CreateOrder(new WsdlStructCreateOrderRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceCreate->getResult());
else
    print_r($wsdlServiceCreate->getLastError());

/*****************************
 * Example for WsdlServiceEdit
 */
$wsdlServiceEdit = new WsdlServiceEdit();
// sample call for WsdlServiceEdit::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
$wsdlServiceEdit->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
// sample call for WsdlServiceEdit::EditOrderItem()
if($wsdlServiceEdit->EditOrderItem(new WsdlStructEditOrderItemRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceEdit->getResult());
else
    print_r($wsdlServiceEdit->getLastError());

/****************************
 * Example for WsdlServiceGet
 */
$wsdlServiceGet = new WsdlServiceGet();
// sample call for WsdlServiceGet::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
$wsdlServiceGet->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
// sample call for WsdlServiceGet::GetAccountInformation()
if($wsdlServiceGet->GetAccountInformation(new WsdlStructGetAccountInformationRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceGet->getResult());
else
    print_r($wsdlServiceGet->getLastError());
// sample call for WsdlServiceGet::GetAccountStatement()
if($wsdlServiceGet->GetAccountStatement(new WsdlStructGetAccountStatementRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceGet->getResult());
else
    print_r($wsdlServiceGet->getLastError());
// sample call for WsdlServiceGet::GetFreeDirectDispatchCancellationsLeft()
if($wsdlServiceGet->GetFreeDirectDispatchCancellationsLeft(new WsdlStructGetFreeDirectDispatchCancellationsLeftRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceGet->getResult());
else
    print_r($wsdlServiceGet->getLastError());
// sample call for WsdlServiceGet::GetHighResImage()
if($wsdlServiceGet->GetHighResImage(new WsdlStructGetHighResImageRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceGet->getResult());
else
    print_r($wsdlServiceGet->getLastError());
// sample call for WsdlServiceGet::GetOrderDetail()
if($wsdlServiceGet->GetOrderDetail(new WsdlStructGetOrderDetailRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceGet->getResult());
else
    print_r($wsdlServiceGet->getLastError());
// sample call for WsdlServiceGet::GetOrders()
if($wsdlServiceGet->GetOrders(new WsdlStructGetOrdersRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceGet->getResult());
else
    print_r($wsdlServiceGet->getLastError());
// sample call for WsdlServiceGet::GetStockFile()
if($wsdlServiceGet->GetStockFile(new WsdlStructGetStockFileRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceGet->getResult());
else
    print_r($wsdlServiceGet->getLastError());

/******************************
 * Example for WsdlServicePlace
 */
$wsdlServicePlace = new WsdlServicePlace();
// sample call for WsdlServicePlace::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
$wsdlServicePlace->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
// sample call for WsdlServicePlace::PlaceOrder()
if($wsdlServicePlace->PlaceOrder(new WsdlStructPlaceOrderRequestType(/*** update parameters list ***/)))
    print_r($wsdlServicePlace->getResult());
else
    print_r($wsdlServicePlace->getLastError());

/********************************
 * Example for WsdlServiceProduct
 */
$wsdlServiceProduct = new WsdlServiceProduct();
// sample call for WsdlServiceProduct::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
$wsdlServiceProduct->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
// sample call for WsdlServiceProduct::ProductSearch()
if($wsdlServiceProduct->ProductSearch(new WsdlStructProductSearchRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceProduct->getResult());
else
    print_r($wsdlServiceProduct->getLastError());

/*******************************
 * Example for WsdlServiceRemove
 */
$wsdlServiceRemove = new WsdlServiceRemove();
// sample call for WsdlServiceRemove::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
$wsdlServiceRemove->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
// sample call for WsdlServiceRemove::RemoveBreakBulkOrderItem()
if($wsdlServiceRemove->RemoveBreakBulkOrderItem(new WsdlStructRemoveBreakBulkOrderItemRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceRemove->getResult());
else
    print_r($wsdlServiceRemove->getLastError());
// sample call for WsdlServiceRemove::RemoveOrderItem()
if($wsdlServiceRemove->RemoveOrderItem(new WsdlStructRemoveOrderItemRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceRemove->getResult());
else
    print_r($wsdlServiceRemove->getLastError());
