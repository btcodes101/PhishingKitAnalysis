<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
set_time_limit(60000);
ini_set('memory_limit', '1256M');
//Modify these
$API_KEY = 'f4dda004439aae9dc813c9d322e6fa5b';
$SECRET = '4fe4450557d01be7e838c7479d91c7f8';
$TOKEN = '73007128e5ca92ef7eb2f8011fa3baa7'; //password
//$APIKEY = '2333a664'; //username
//$APISECRET = 'ZL5lt3aEBhGVSLjj2ZA3iJC4FIMhLNkY'; //password
$STORE_URL = 'adeel-test-1.myshopify.com';
$FEED_URL = 'https://www.musicpayhost.com/productapi/v1/feeds';


$secureUrl = "https://".$API_KEY.":".$SECRET."@".$STORE_URL;

