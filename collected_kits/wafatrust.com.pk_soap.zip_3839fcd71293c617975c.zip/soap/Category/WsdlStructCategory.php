<?php
/**
 * File for class WsdlStructCategory
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructCategory originally named Category
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructCategory extends WsdlStructAbstractSkuDetail
{
    /**
     * The ParentID
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var int
     */
    public $ParentID;
    /**
     * The ParentName
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $ParentName;
    /**
     * Constructor method for Category
     * @see parent::__construct()
     * @param int $_parentID
     * @param string $_parentName
     * @return WsdlStructCategory
     */
    public function __construct($_parentID = NULL,$_parentName = NULL)
    {
        WsdlWsdlClass::__construct(array('ParentID'=>$_parentID,'ParentName'=>$_parentName),false);
    }
    /**
     * Get ParentID value
     * @return int|null
     */
    public function getParentID()
    {
        return $this->ParentID;
    }
    /**
     * Set ParentID value
     * @param int $_parentID the ParentID
     * @return int
     */
    public function setParentID($_parentID)
    {
        return ($this->ParentID = $_parentID);
    }
    /**
     * Get ParentName value
     * @return string|null
     */
    public function getParentName()
    {
        return $this->ParentName;
    }
    /**
     * Set ParentName value
     * @param string $_parentName the ParentName
     * @return string
     */
    public function setParentName($_parentName)
    {
        return ($this->ParentName = $_parentName);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructCategory
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
