<?php
/**
 * File for class WsdlEnumCurrency
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlEnumCurrency originally named Currency
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlEnumCurrency extends WsdlWsdlClass
{
    /**
     * Constant for value 'GBP'
     * Meta informations extracted from the WSDL
     * - documentation : GBP currency.
     * @return string 'GBP'
     */
    const VALUE_GBP = 'GBP';
    /**
     * Constant for value 'EUR'
     * Meta informations extracted from the WSDL
     * - documentation : EUR currency.
     * @return string 'EUR'
     */
    const VALUE_EUR = 'EUR';
    /**
     * Constant for value 'DKK'
     * Meta informations extracted from the WSDL
     * - documentation : DKK currency.
     * @return string 'DKK'
     */
    const VALUE_DKK = 'DKK';
    /**
     * Constant for value 'CZK'
     * Meta informations extracted from the WSDL
     * - documentation : CZK currency.
     * @return string 'CZK'
     */
    const VALUE_CZK = 'CZK';
    /**
     * Constant for value 'NOK'
     * Meta informations extracted from the WSDL
     * - documentation : NOK currency.
     * @return string 'NOK'
     */
    const VALUE_NOK = 'NOK';
    /**
     * Constant for value 'PLN'
     * Meta informations extracted from the WSDL
     * - documentation : PLN currency.
     * @return string 'PLN'
     */
    const VALUE_PLN = 'PLN';
    /**
     * Constant for value 'SEK'
     * Meta informations extracted from the WSDL
     * - documentation : SEK currency.
     * @return string 'SEK'
     */
    const VALUE_SEK = 'SEK';
    /**
     * Return true if value is allowed
     * @uses WsdlEnumCurrency::VALUE_GBP
     * @uses WsdlEnumCurrency::VALUE_EUR
     * @uses WsdlEnumCurrency::VALUE_DKK
     * @uses WsdlEnumCurrency::VALUE_CZK
     * @uses WsdlEnumCurrency::VALUE_NOK
     * @uses WsdlEnumCurrency::VALUE_PLN
     * @uses WsdlEnumCurrency::VALUE_SEK
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(WsdlEnumCurrency::VALUE_GBP,WsdlEnumCurrency::VALUE_EUR,WsdlEnumCurrency::VALUE_DKK,WsdlEnumCurrency::VALUE_CZK,WsdlEnumCurrency::VALUE_NOK,WsdlEnumCurrency::VALUE_PLN,WsdlEnumCurrency::VALUE_SEK));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
