<?php
/**
 * File for class WsdlServicePlace
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlServicePlace originally named Place
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlServicePlace extends WsdlWsdlClass
{
    /**
     * Sets the AuthHeader SoapHeader param
     * @uses WsdlWsdlClass::setSoapHeader()
     * @param WsdlStructAuthHeader $_wsdlStructAuthHeader
     * @param string $_nameSpace http://www.beautyfort.com/api/
     * @param bool $_mustUnderstand
     * @param string $_actor
     * @return bool true|false
     */
    public function setSoapHeaderAuthHeader(WsdlStructAuthHeader $_wsdlStructAuthHeader,$_nameSpace = 'http://www.beautyfort.com/api/',$_mustUnderstand = false,$_actor = null)
    {
        return $this->setSoapHeader($_nameSpace,'AuthHeader',$_wsdlStructAuthHeader,$_mustUnderstand,$_actor);
    }
    /**
     * Method to call the operation originally named PlaceOrder
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructPlaceOrderRequestType $_wsdlStructPlaceOrderRequestType
     * @return WsdlStructPlaceOrderResponseType
     */
    public function PlaceOrder(WsdlStructPlaceOrderRequestType $_wsdlStructPlaceOrderRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->PlaceOrder($_wsdlStructPlaceOrderRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Returns the result
     * @see WsdlWsdlClass::getResult()
     * @return WsdlStructPlaceOrderResponseType
     */
    public function getResult()
    {
        return parent::getResult();
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
