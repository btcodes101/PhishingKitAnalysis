<?php
/**
 * File for class WsdlStructPlaceOrderRequestType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructPlaceOrderRequestType originally named PlaceOrderRequestType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructPlaceOrderRequestType extends WsdlStructAbstractRequestType
{
    /**
     * The OrderReference
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var int
     */
    public $OrderReference;
    /**
     * The YourOrderReference
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $YourOrderReference;
    /**
     * The AttemptAutomaticPayment
     * @var boolean
     */
    public $AttemptAutomaticPayment;
    /**
     * The EnforceQuantityChanges
     * Meta informations extracted from the WSDL
     * - default : false
     * - minOccurs : 0
     * @var boolean
     */
    public $EnforceQuantityChanges;
    /**
     * The InvoiceFirstName
     * Meta informations extracted from the WSDL
     * - documentation : The invoice first name for the order.
     * @var string
     */
    public $InvoiceFirstName;
    /**
     * The InvoiceLastName
     * Meta informations extracted from the WSDL
     * - documentation : The invoice last name for the order.
     * @var string
     */
    public $InvoiceLastName;
    /**
     * The InvoiceAddress
     * Meta informations extracted from the WSDL
     * - documentation : The invoice address for the order.
     * @var WsdlStructAddress
     */
    public $InvoiceAddress;
    /**
     * The DeliveryFirstName
     * Meta informations extracted from the WSDL
     * - documentation : The delivery first name for the order.
     * @var string
     */
    public $DeliveryFirstName;
    /**
     * The DeliveryLastName
     * Meta informations extracted from the WSDL
     * - documentation : The delivery last name for the order.
     * @var string
     */
    public $DeliveryLastName;
    /**
     * The DeliveryAddress
     * Meta informations extracted from the WSDL
     * - documentation : The delivery address for the order.
     * @var WsdlStructAddress
     */
    public $DeliveryAddress;
    /**
     * The DeliveryOption
     * @var WsdlStructDeliveryOption
     */
    public $DeliveryOption;
    /**
     * The PromoCode
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $PromoCode;
    /**
     * Constructor method for PlaceOrderRequestType
     * @see parent::__construct()
     * @param int $_orderReference
     * @param string $_yourOrderReference
     * @param boolean $_attemptAutomaticPayment
     * @param boolean $_enforceQuantityChanges
     * @param string $_invoiceFirstName
     * @param string $_invoiceLastName
     * @param WsdlStructAddress $_invoiceAddress
     * @param string $_deliveryFirstName
     * @param string $_deliveryLastName
     * @param WsdlStructAddress $_deliveryAddress
     * @param WsdlStructDeliveryOption $_deliveryOption
     * @param string $_promoCode
     * @return WsdlStructPlaceOrderRequestType
     */
    public function __construct($_orderReference = NULL,$_yourOrderReference = NULL,$_attemptAutomaticPayment = NULL,$_enforceQuantityChanges = false,$_invoiceFirstName = NULL,$_invoiceLastName = NULL,$_invoiceAddress = NULL,$_deliveryFirstName = NULL,$_deliveryLastName = NULL,$_deliveryAddress = NULL,$_deliveryOption = NULL,$_promoCode = NULL)
    {
        WsdlWsdlClass::__construct(array('OrderReference'=>$_orderReference,'YourOrderReference'=>$_yourOrderReference,'AttemptAutomaticPayment'=>$_attemptAutomaticPayment,'EnforceQuantityChanges'=>$_enforceQuantityChanges,'InvoiceFirstName'=>$_invoiceFirstName,'InvoiceLastName'=>$_invoiceLastName,'InvoiceAddress'=>$_invoiceAddress,'DeliveryFirstName'=>$_deliveryFirstName,'DeliveryLastName'=>$_deliveryLastName,'DeliveryAddress'=>$_deliveryAddress,'DeliveryOption'=>$_deliveryOption,'PromoCode'=>$_promoCode),false);
    }
    /**
     * Get OrderReference value
     * @return int|null
     */
    public function getOrderReference()
    {
        return $this->OrderReference;
    }
    /**
     * Set OrderReference value
     * @param int $_orderReference the OrderReference
     * @return int
     */
    public function setOrderReference($_orderReference)
    {
        return ($this->OrderReference = $_orderReference);
    }
    /**
     * Get YourOrderReference value
     * @return string|null
     */
    public function getYourOrderReference()
    {
        return $this->YourOrderReference;
    }
    /**
     * Set YourOrderReference value
     * @param string $_yourOrderReference the YourOrderReference
     * @return string
     */
    public function setYourOrderReference($_yourOrderReference)
    {
        return ($this->YourOrderReference = $_yourOrderReference);
    }
    /**
     * Get AttemptAutomaticPayment value
     * @return boolean|null
     */
    public function getAttemptAutomaticPayment()
    {
        return $this->AttemptAutomaticPayment;
    }
    /**
     * Set AttemptAutomaticPayment value
     * @param boolean $_attemptAutomaticPayment the AttemptAutomaticPayment
     * @return boolean
     */
    public function setAttemptAutomaticPayment($_attemptAutomaticPayment)
    {
        return ($this->AttemptAutomaticPayment = $_attemptAutomaticPayment);
    }
    /**
     * Get EnforceQuantityChanges value
     * @return boolean|null
     */
    public function getEnforceQuantityChanges()
    {
        return $this->EnforceQuantityChanges;
    }
    /**
     * Set EnforceQuantityChanges value
     * @param boolean $_enforceQuantityChanges the EnforceQuantityChanges
     * @return boolean
     */
    public function setEnforceQuantityChanges($_enforceQuantityChanges)
    {
        return ($this->EnforceQuantityChanges = $_enforceQuantityChanges);
    }
    /**
     * Get InvoiceFirstName value
     * @return string|null
     */
    public function getInvoiceFirstName()
    {
        return $this->InvoiceFirstName;
    }
    /**
     * Set InvoiceFirstName value
     * @param string $_invoiceFirstName the InvoiceFirstName
     * @return string
     */
    public function setInvoiceFirstName($_invoiceFirstName)
    {
        return ($this->InvoiceFirstName = $_invoiceFirstName);
    }
    /**
     * Get InvoiceLastName value
     * @return string|null
     */
    public function getInvoiceLastName()
    {
        return $this->InvoiceLastName;
    }
    /**
     * Set InvoiceLastName value
     * @param string $_invoiceLastName the InvoiceLastName
     * @return string
     */
    public function setInvoiceLastName($_invoiceLastName)
    {
        return ($this->InvoiceLastName = $_invoiceLastName);
    }
    /**
     * Get InvoiceAddress value
     * @return WsdlStructAddress|null
     */
    public function getInvoiceAddress()
    {
        return $this->InvoiceAddress;
    }
    /**
     * Set InvoiceAddress value
     * @param WsdlStructAddress $_invoiceAddress the InvoiceAddress
     * @return WsdlStructAddress
     */
    public function setInvoiceAddress($_invoiceAddress)
    {
        return ($this->InvoiceAddress = $_invoiceAddress);
    }
    /**
     * Get DeliveryFirstName value
     * @return string|null
     */
    public function getDeliveryFirstName()
    {
        return $this->DeliveryFirstName;
    }
    /**
     * Set DeliveryFirstName value
     * @param string $_deliveryFirstName the DeliveryFirstName
     * @return string
     */
    public function setDeliveryFirstName($_deliveryFirstName)
    {
        return ($this->DeliveryFirstName = $_deliveryFirstName);
    }
    /**
     * Get DeliveryLastName value
     * @return string|null
     */
    public function getDeliveryLastName()
    {
        return $this->DeliveryLastName;
    }
    /**
     * Set DeliveryLastName value
     * @param string $_deliveryLastName the DeliveryLastName
     * @return string
     */
    public function setDeliveryLastName($_deliveryLastName)
    {
        return ($this->DeliveryLastName = $_deliveryLastName);
    }
    /**
     * Get DeliveryAddress value
     * @return WsdlStructAddress|null
     */
    public function getDeliveryAddress()
    {
        return $this->DeliveryAddress;
    }
    /**
     * Set DeliveryAddress value
     * @param WsdlStructAddress $_deliveryAddress the DeliveryAddress
     * @return WsdlStructAddress
     */
    public function setDeliveryAddress($_deliveryAddress)
    {
        return ($this->DeliveryAddress = $_deliveryAddress);
    }
    /**
     * Get DeliveryOption value
     * @return WsdlStructDeliveryOption|null
     */
    public function getDeliveryOption()
    {
        return $this->DeliveryOption;
    }
    /**
     * Set DeliveryOption value
     * @param WsdlStructDeliveryOption $_deliveryOption the DeliveryOption
     * @return WsdlStructDeliveryOption
     */
    public function setDeliveryOption($_deliveryOption)
    {
        return ($this->DeliveryOption = $_deliveryOption);
    }
    /**
     * Get PromoCode value
     * @return string|null
     */
    public function getPromoCode()
    {
        return $this->PromoCode;
    }
    /**
     * Set PromoCode value
     * @param string $_promoCode the PromoCode
     * @return string
     */
    public function setPromoCode($_promoCode)
    {
        return ($this->PromoCode = $_promoCode);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructPlaceOrderRequestType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
