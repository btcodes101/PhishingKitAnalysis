<?php
/**
 * File for class WsdlStructAuthHeader
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructAuthHeader originally named AuthHeader
 * Documentation : Authentication information for the customer on whose behalf the applicaiton is making the request. Only registered wholesale users with a valid API key are allowed to make API calls. As API calls do not pass session information you must pass the customers email address and API key with every SOAP API call. Authenticaiton header used for SOAP API calls.
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructAuthHeader extends WsdlWsdlClass
{
    /**
     * The Username
     * @var string
     */
    public $Username;
    /**
     * The Nonce
     * @var string
     */
    public $Nonce;
    /**
     * The Created
     * @var dateTime
     */
    public $Created;
    /**
     * The Password
     * @var string
     */
    public $Password;
    /**
     * Constructor method for AuthHeader
     * @see parent::__construct()
     * @param string $_username
     * @param string $_nonce
     * @param dateTime $_created
     * @param string $_password
     * @return WsdlStructAuthHeader
     */
    public function __construct($_username = NULL,$_nonce = NULL,$_created = NULL,$_password = NULL)
    {
        parent::__construct(array('Username'=>$_username,'Nonce'=>$_nonce,'Created'=>$_created,'Password'=>$_password),false);
    }
    /**
     * Get Username value
     * @return string|null
     */
    public function getUsername()
    {
        return $this->Username;
    }
    /**
     * Set Username value
     * @param string $_username the Username
     * @return string
     */
    public function setUsername($_username)
    {
        return ($this->Username = $_username);
    }
    /**
     * Get Nonce value
     * @return string|null
     */
    public function getNonce()
    {
        return $this->Nonce;
    }
    /**
     * Set Nonce value
     * @param string $_nonce the Nonce
     * @return string
     */
    public function setNonce($_nonce)
    {
        return ($this->Nonce = $_nonce);
    }
    /**
     * Get Created value
     * @return dateTime|null
     */
    public function getCreated()
    {
        return $this->Created;
    }
    /**
     * Set Created value
     * @param dateTime $_created the Created
     * @return dateTime
     */
    public function setCreated($_created)
    {
        return ($this->Created = $_created);
    }
    /**
     * Get Password value
     * @return string|null
     */
    public function getPassword()
    {
        return $this->Password;
    }
    /**
     * Set Password value
     * @param string $_password the Password
     * @return string
     */
    public function setPassword($_password)
    {
        return ($this->Password = $_password);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructAuthHeader
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
