<?php
/**
 * File for class WsdlStructArrayOfGender
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructArrayOfGender originally named ArrayOfGender
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructArrayOfGender extends WsdlWsdlClass
{
    /**
     * The Gender
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * @var WsdlStructGender
     */
    public $Gender;
    /**
     * Constructor method for ArrayOfGender
     * @see parent::__construct()
     * @param WsdlStructGender $_gender
     * @return WsdlStructArrayOfGender
     */
    public function __construct($_gender = NULL)
    {
        parent::__construct(array('Gender'=>$_gender),false);
    }
    /**
     * Get Gender value
     * @return WsdlStructGender|null
     */
    public function getGender()
    {
        return $this->Gender;
    }
    /**
     * Set Gender value
     * @param WsdlStructGender $_gender the Gender
     * @return WsdlStructGender
     */
    public function setGender($_gender)
    {
        return ($this->Gender = $_gender);
    }
    /**
     * Returns the current element
     * @see WsdlWsdlClass::current()
     * @return WsdlStructGender
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see WsdlWsdlClass::item()
     * @param int $_index
     * @return WsdlStructGender
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see WsdlWsdlClass::first()
     * @return WsdlStructGender
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see WsdlWsdlClass::last()
     * @return WsdlStructGender
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see WsdlWsdlClass::last()
     * @param int $_offset
     * @return WsdlStructGender
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see WsdlWsdlClass::getAttributeName()
     * @return string Gender
     */
    public function getAttributeName()
    {
        return 'Gender';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructArrayOfGender
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
