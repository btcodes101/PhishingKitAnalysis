<?php
/**
 * File for class WsdlStructArrayOfStockCode
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructArrayOfStockCode originally named ArrayOfStockCode
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructArrayOfStockCode extends WsdlWsdlClass
{
    /**
     * The StockCode
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * @var string
     */
    public $StockCode;
    /**
     * Constructor method for ArrayOfStockCode
     * @see parent::__construct()
     * @param string $_stockCode
     * @return WsdlStructArrayOfStockCode
     */
    public function __construct($_stockCode = NULL)
    {
        parent::__construct(array('StockCode'=>$_stockCode),false);
    }
    /**
     * Get StockCode value
     * @return string|null
     */
    public function getStockCode()
    {
        return $this->StockCode;
    }
    /**
     * Set StockCode value
     * @param string $_stockCode the StockCode
     * @return string
     */
    public function setStockCode($_stockCode)
    {
        return ($this->StockCode = $_stockCode);
    }
    /**
     * Returns the current element
     * @see WsdlWsdlClass::current()
     * @return string
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see WsdlWsdlClass::item()
     * @param int $_index
     * @return string
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see WsdlWsdlClass::first()
     * @return string
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see WsdlWsdlClass::last()
     * @return string
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see WsdlWsdlClass::last()
     * @param int $_offset
     * @return string
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see WsdlWsdlClass::getAttributeName()
     * @return string StockCode
     */
    public function getAttributeName()
    {
        return 'StockCode';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructArrayOfStockCode
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
