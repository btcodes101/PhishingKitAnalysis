<?php
/**
 * File for class WsdlStructArrayOfBreakBulkReference
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructArrayOfBreakBulkReference originally named ArrayOfBreakBulkReference
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructArrayOfBreakBulkReference extends WsdlWsdlClass
{
    /**
     * The BreakBulkReference
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 1
     * @var WsdlStructBreakBulkReference
     */
    public $BreakBulkReference;
    /**
     * Constructor method for ArrayOfBreakBulkReference
     * @see parent::__construct()
     * @param WsdlStructBreakBulkReference $_breakBulkReference
     * @return WsdlStructArrayOfBreakBulkReference
     */
    public function __construct($_breakBulkReference)
    {
        parent::__construct(array('BreakBulkReference'=>$_breakBulkReference),false);
    }
    /**
     * Get BreakBulkReference value
     * @return WsdlStructBreakBulkReference
     */
    public function getBreakBulkReference()
    {
        return $this->BreakBulkReference;
    }
    /**
     * Set BreakBulkReference value
     * @param WsdlStructBreakBulkReference $_breakBulkReference the BreakBulkReference
     * @return WsdlStructBreakBulkReference
     */
    public function setBreakBulkReference($_breakBulkReference)
    {
        return ($this->BreakBulkReference = $_breakBulkReference);
    }
    /**
     * Returns the current element
     * @see WsdlWsdlClass::current()
     * @return WsdlStructBreakBulkReference
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see WsdlWsdlClass::item()
     * @param int $_index
     * @return WsdlStructBreakBulkReference
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see WsdlWsdlClass::first()
     * @return WsdlStructBreakBulkReference
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see WsdlWsdlClass::last()
     * @return WsdlStructBreakBulkReference
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see WsdlWsdlClass::last()
     * @param int $_offset
     * @return WsdlStructBreakBulkReference
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see WsdlWsdlClass::getAttributeName()
     * @return string BreakBulkReference
     */
    public function getAttributeName()
    {
        return 'BreakBulkReference';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructArrayOfBreakBulkReference
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
