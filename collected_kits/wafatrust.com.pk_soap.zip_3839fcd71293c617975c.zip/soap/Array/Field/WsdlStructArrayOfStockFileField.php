<?php
/**
 * File for class WsdlStructArrayOfStockFileField
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructArrayOfStockFileField originally named ArrayOfStockFileField
 * Documentation : The fields to include in the returned stock file. Fields will be included in the supplied order.
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructArrayOfStockFileField extends WsdlWsdlClass
{
    /**
     * The StockFileField
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 1
     * @var WsdlEnumStockFileField
     */
    public $StockFileField;
    /**
     * Constructor method for ArrayOfStockFileField
     * @see parent::__construct()
     * @param WsdlEnumStockFileField $_stockFileField
     * @return WsdlStructArrayOfStockFileField
     */
    public function __construct($_stockFileField)
    {
        parent::__construct(array('StockFileField'=>$_stockFileField),false);
    }
    /**
     * Get StockFileField value
     * @return WsdlEnumStockFileField
     */
    public function getStockFileField()
    {
        return $this->StockFileField;
    }
    /**
     * Set StockFileField value
     * @param WsdlEnumStockFileField $_stockFileField the StockFileField
     * @return WsdlEnumStockFileField
     */
    public function setStockFileField($_stockFileField)
    {
        return ($this->StockFileField = $_stockFileField);
    }
    /**
     * Returns the current element
     * @see WsdlWsdlClass::current()
     * @return WsdlEnumStockFileField
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see WsdlWsdlClass::item()
     * @param int $_index
     * @return WsdlEnumStockFileField
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see WsdlWsdlClass::first()
     * @return WsdlEnumStockFileField
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see WsdlWsdlClass::last()
     * @return WsdlEnumStockFileField
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see WsdlWsdlClass::last()
     * @param int $_offset
     * @return WsdlEnumStockFileField
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Add element to array
     * @see WsdlWsdlClass::add()
     * @uses WsdlEnumStockFileField::valueIsValid()
     * @param WsdlEnumStockFileField $_item
     * @return WsdlEnumStockFileField
     */
    public function add($_item)
    {
        return WsdlEnumStockFileField::valueIsValid($_item)?parent::add($_item):false;
    }
    /**
     * Returns the attribute name
     * @see WsdlWsdlClass::getAttributeName()
     * @return string StockFileField
     */
    public function getAttributeName()
    {
        return 'StockFileField';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructArrayOfStockFileField
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
