<?php
/**
 * File for class WsdlStructArrayOfTransaction
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructArrayOfTransaction originally named ArrayOfTransaction
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructArrayOfTransaction extends WsdlWsdlClass
{
    /**
     * The Transaction
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * @var WsdlStructTransaction
     */
    public $Transaction;
    /**
     * Constructor method for ArrayOfTransaction
     * @see parent::__construct()
     * @param WsdlStructTransaction $_transaction
     * @return WsdlStructArrayOfTransaction
     */
    public function __construct($_transaction = NULL)
    {
        parent::__construct(array('Transaction'=>$_transaction),false);
    }
    /**
     * Get Transaction value
     * @return WsdlStructTransaction|null
     */
    public function getTransaction()
    {
        return $this->Transaction;
    }
    /**
     * Set Transaction value
     * @param WsdlStructTransaction $_transaction the Transaction
     * @return WsdlStructTransaction
     */
    public function setTransaction($_transaction)
    {
        return ($this->Transaction = $_transaction);
    }
    /**
     * Returns the current element
     * @see WsdlWsdlClass::current()
     * @return WsdlStructTransaction
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see WsdlWsdlClass::item()
     * @param int $_index
     * @return WsdlStructTransaction
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see WsdlWsdlClass::first()
     * @return WsdlStructTransaction
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see WsdlWsdlClass::last()
     * @return WsdlStructTransaction
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see WsdlWsdlClass::last()
     * @param int $_offset
     * @return WsdlStructTransaction
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see WsdlWsdlClass::getAttributeName()
     * @return string Transaction
     */
    public function getAttributeName()
    {
        return 'Transaction';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructArrayOfTransaction
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
