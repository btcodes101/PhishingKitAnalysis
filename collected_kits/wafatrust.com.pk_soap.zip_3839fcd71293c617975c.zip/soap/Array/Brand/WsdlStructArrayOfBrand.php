<?php
/**
 * File for class WsdlStructArrayOfBrand
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructArrayOfBrand originally named ArrayOfBrand
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructArrayOfBrand extends WsdlWsdlClass
{
    /**
     * The Brand
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * @var WsdlStructBrand
     */
    public $Brand;
    /**
     * Constructor method for ArrayOfBrand
     * @see parent::__construct()
     * @param WsdlStructBrand $_brand
     * @return WsdlStructArrayOfBrand
     */
    public function __construct($_brand = NULL)
    {
        parent::__construct(array('Brand'=>$_brand),false);
    }
    /**
     * Get Brand value
     * @return WsdlStructBrand|null
     */
    public function getBrand()
    {
        return $this->Brand;
    }
    /**
     * Set Brand value
     * @param WsdlStructBrand $_brand the Brand
     * @return WsdlStructBrand
     */
    public function setBrand($_brand)
    {
        return ($this->Brand = $_brand);
    }
    /**
     * Returns the current element
     * @see WsdlWsdlClass::current()
     * @return WsdlStructBrand
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see WsdlWsdlClass::item()
     * @param int $_index
     * @return WsdlStructBrand
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see WsdlWsdlClass::first()
     * @return WsdlStructBrand
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see WsdlWsdlClass::last()
     * @return WsdlStructBrand
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see WsdlWsdlClass::last()
     * @param int $_offset
     * @return WsdlStructBrand
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see WsdlWsdlClass::getAttributeName()
     * @return string Brand
     */
    public function getAttributeName()
    {
        return 'Brand';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructArrayOfBrand
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
