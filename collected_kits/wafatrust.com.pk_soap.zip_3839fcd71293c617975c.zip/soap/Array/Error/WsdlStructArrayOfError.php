<?php
/**
 * File for class WsdlStructArrayOfError
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructArrayOfError originally named ArrayOfError
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructArrayOfError extends WsdlWsdlClass
{
    /**
     * The Error
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * @var WsdlStructError
     */
    public $Error;
    /**
     * Constructor method for ArrayOfError
     * @see parent::__construct()
     * @param WsdlStructError $_error
     * @return WsdlStructArrayOfError
     */
    public function __construct($_error = NULL)
    {
        parent::__construct(array('Error'=>$_error),false);
    }
    /**
     * Get Error value
     * @return WsdlStructError|null
     */
    public function getError()
    {
        return $this->Error;
    }
    /**
     * Set Error value
     * @param WsdlStructError $_error the Error
     * @return WsdlStructError
     */
    public function setError($_error)
    {
        return ($this->Error = $_error);
    }
    /**
     * Returns the current element
     * @see WsdlWsdlClass::current()
     * @return WsdlStructError
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see WsdlWsdlClass::item()
     * @param int $_index
     * @return WsdlStructError
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see WsdlWsdlClass::first()
     * @return WsdlStructError
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see WsdlWsdlClass::last()
     * @return WsdlStructError
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see WsdlWsdlClass::last()
     * @param int $_offset
     * @return WsdlStructError
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see WsdlWsdlClass::getAttributeName()
     * @return string Error
     */
    public function getAttributeName()
    {
        return 'Error';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructArrayOfError
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
