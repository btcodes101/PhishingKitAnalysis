<?php
/**
 * File for class WsdlStructArrayOfAccountInformationType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructArrayOfAccountInformationType originally named ArrayOfAccountInformationType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructArrayOfAccountInformationType extends WsdlWsdlClass
{
    /**
     * The AccountInformationType
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * @var WsdlEnumAccountInformationType
     */
    public $AccountInformationType;
    /**
     * Constructor method for ArrayOfAccountInformationType
     * @see parent::__construct()
     * @param WsdlEnumAccountInformationType $_accountInformationType
     * @return WsdlStructArrayOfAccountInformationType
     */
    public function __construct($_accountInformationType = NULL)
    {
        parent::__construct(array('AccountInformationType'=>$_accountInformationType),false);
    }
    /**
     * Get AccountInformationType value
     * @return WsdlEnumAccountInformationType|null
     */
    public function getAccountInformationType()
    {
        return $this->AccountInformationType;
    }
    /**
     * Set AccountInformationType value
     * @param WsdlEnumAccountInformationType $_accountInformationType the AccountInformationType
     * @return WsdlEnumAccountInformationType
     */
    public function setAccountInformationType($_accountInformationType)
    {
        return ($this->AccountInformationType = $_accountInformationType);
    }
    /**
     * Returns the current element
     * @see WsdlWsdlClass::current()
     * @return WsdlEnumAccountInformationType
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see WsdlWsdlClass::item()
     * @param int $_index
     * @return WsdlEnumAccountInformationType
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see WsdlWsdlClass::first()
     * @return WsdlEnumAccountInformationType
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see WsdlWsdlClass::last()
     * @return WsdlEnumAccountInformationType
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see WsdlWsdlClass::last()
     * @param int $_offset
     * @return WsdlEnumAccountInformationType
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Add element to array
     * @see WsdlWsdlClass::add()
     * @uses WsdlEnumAccountInformationType::valueIsValid()
     * @param WsdlEnumAccountInformationType $_item
     * @return WsdlEnumAccountInformationType
     */
    public function add($_item)
    {
        return WsdlEnumAccountInformationType::valueIsValid($_item)?parent::add($_item):false;
    }
    /**
     * Returns the attribute name
     * @see WsdlWsdlClass::getAttributeName()
     * @return string AccountInformationType
     */
    public function getAttributeName()
    {
        return 'AccountInformationType';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructArrayOfAccountInformationType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
