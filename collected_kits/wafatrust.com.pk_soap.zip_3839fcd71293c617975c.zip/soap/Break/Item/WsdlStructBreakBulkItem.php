<?php
/**
 * File for class WsdlStructBreakBulkItem
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructBreakBulkItem originally named BreakBulkItem
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructBreakBulkItem extends WsdlWsdlClass
{
    /**
     * The StockCode
     * @var string
     */
    public $StockCode;
    /**
     * The Item
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructItem
     */
    public $Item;
    /**
     * The Quantity
     * Meta informations extracted from the WSDL
     * - documentation : The quantity of the item to include in each break bulk item.
     * @var int
     */
    public $Quantity;
    /**
     * Constructor method for BreakBulkItem
     * @see parent::__construct()
     * @param string $_stockCode
     * @param WsdlStructItem $_item
     * @param int $_quantity
     * @return WsdlStructBreakBulkItem
     */
    public function __construct($_stockCode = NULL,$_item = NULL,$_quantity = NULL)
    {
        parent::__construct(array('StockCode'=>$_stockCode,'Item'=>$_item,'Quantity'=>$_quantity),false);
    }
    /**
     * Get StockCode value
     * @return string|null
     */
    public function getStockCode()
    {
        return $this->StockCode;
    }
    /**
     * Set StockCode value
     * @param string $_stockCode the StockCode
     * @return string
     */
    public function setStockCode($_stockCode)
    {
        return ($this->StockCode = $_stockCode);
    }
    /**
     * Get Item value
     * @return WsdlStructItem|null
     */
    public function getItem()
    {
        return $this->Item;
    }
    /**
     * Set Item value
     * @param WsdlStructItem $_item the Item
     * @return WsdlStructItem
     */
    public function setItem($_item)
    {
        return ($this->Item = $_item);
    }
    /**
     * Get Quantity value
     * @return int|null
     */
    public function getQuantity()
    {
        return $this->Quantity;
    }
    /**
     * Set Quantity value
     * @param int $_quantity the Quantity
     * @return int
     */
    public function setQuantity($_quantity)
    {
        return ($this->Quantity = $_quantity);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructBreakBulkItem
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
