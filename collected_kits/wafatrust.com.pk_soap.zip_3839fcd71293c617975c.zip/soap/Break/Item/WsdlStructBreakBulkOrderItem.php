<?php
/**
 * File for class WsdlStructBreakBulkOrderItem
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructBreakBulkOrderItem originally named BreakBulkOrderItem
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructBreakBulkOrderItem extends WsdlWsdlClass
{
    /**
     * The OrderReference
     * @var int
     */
    public $OrderReference;
    /**
     * The YourOrderReference
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $YourOrderReference;
    /**
     * The BreakBulkItemReference
     * @var int
     */
    public $BreakBulkItemReference;
    /**
     * The Items
     * @var WsdlStructArrayOfBreakBulkItem
     */
    public $Items;
    /**
     * The References
     * @var WsdlStructArrayOfBreakBulkReference
     */
    public $References;
    /**
     * The TotalQuantity
     * Meta informations extracted from the WSDL
     * - documentation : The total quantity of the break bulk item ordered.
     * @var int
     */
    public $TotalQuantity;
    /**
     * The TotalBreakBulkCosts
     * Meta informations extracted from the WSDL
     * - documentation : The total break bulk costs for the break bulk item.
     * @var WsdlStructAmount
     */
    public $TotalBreakBulkCosts;
    /**
     * Constructor method for BreakBulkOrderItem
     * @see parent::__construct()
     * @param int $_orderReference
     * @param string $_yourOrderReference
     * @param int $_breakBulkItemReference
     * @param WsdlStructArrayOfBreakBulkItem $_items
     * @param WsdlStructArrayOfBreakBulkReference $_references
     * @param int $_totalQuantity
     * @param WsdlStructAmount $_totalBreakBulkCosts
     * @return WsdlStructBreakBulkOrderItem
     */
    public function __construct($_orderReference = NULL,$_yourOrderReference = NULL,$_breakBulkItemReference = NULL,$_items = NULL,$_references = NULL,$_totalQuantity = NULL,$_totalBreakBulkCosts = NULL)
    {
        parent::__construct(array('OrderReference'=>$_orderReference,'YourOrderReference'=>$_yourOrderReference,'BreakBulkItemReference'=>$_breakBulkItemReference,'Items'=>($_items instanceof WsdlStructArrayOfBreakBulkItem)?$_items:new WsdlStructArrayOfBreakBulkItem($_items),'References'=>($_references instanceof WsdlStructArrayOfBreakBulkReference)?$_references:new WsdlStructArrayOfBreakBulkReference($_references),'TotalQuantity'=>$_totalQuantity,'TotalBreakBulkCosts'=>$_totalBreakBulkCosts),false);
    }
    /**
     * Get OrderReference value
     * @return int|null
     */
    public function getOrderReference()
    {
        return $this->OrderReference;
    }
    /**
     * Set OrderReference value
     * @param int $_orderReference the OrderReference
     * @return int
     */
    public function setOrderReference($_orderReference)
    {
        return ($this->OrderReference = $_orderReference);
    }
    /**
     * Get YourOrderReference value
     * @return string|null
     */
    public function getYourOrderReference()
    {
        return $this->YourOrderReference;
    }
    /**
     * Set YourOrderReference value
     * @param string $_yourOrderReference the YourOrderReference
     * @return string
     */
    public function setYourOrderReference($_yourOrderReference)
    {
        return ($this->YourOrderReference = $_yourOrderReference);
    }
    /**
     * Get BreakBulkItemReference value
     * @return int|null
     */
    public function getBreakBulkItemReference()
    {
        return $this->BreakBulkItemReference;
    }
    /**
     * Set BreakBulkItemReference value
     * @param int $_breakBulkItemReference the BreakBulkItemReference
     * @return int
     */
    public function setBreakBulkItemReference($_breakBulkItemReference)
    {
        return ($this->BreakBulkItemReference = $_breakBulkItemReference);
    }
    /**
     * Get Items value
     * @return WsdlStructArrayOfBreakBulkItem|null
     */
    public function getItems()
    {
        return $this->Items;
    }
    /**
     * Set Items value
     * @param WsdlStructArrayOfBreakBulkItem $_items the Items
     * @return WsdlStructArrayOfBreakBulkItem
     */
    public function setItems($_items)
    {
        return ($this->Items = $_items);
    }
    /**
     * Get References value
     * @return WsdlStructArrayOfBreakBulkReference|null
     */
    public function getReferences()
    {
        return $this->References;
    }
    /**
     * Set References value
     * @param WsdlStructArrayOfBreakBulkReference $_references the References
     * @return WsdlStructArrayOfBreakBulkReference
     */
    public function setReferences($_references)
    {
        return ($this->References = $_references);
    }
    /**
     * Get TotalQuantity value
     * @return int|null
     */
    public function getTotalQuantity()
    {
        return $this->TotalQuantity;
    }
    /**
     * Set TotalQuantity value
     * @param int $_totalQuantity the TotalQuantity
     * @return int
     */
    public function setTotalQuantity($_totalQuantity)
    {
        return ($this->TotalQuantity = $_totalQuantity);
    }
    /**
     * Get TotalBreakBulkCosts value
     * @return WsdlStructAmount|null
     */
    public function getTotalBreakBulkCosts()
    {
        return $this->TotalBreakBulkCosts;
    }
    /**
     * Set TotalBreakBulkCosts value
     * @param WsdlStructAmount $_totalBreakBulkCosts the TotalBreakBulkCosts
     * @return WsdlStructAmount
     */
    public function setTotalBreakBulkCosts($_totalBreakBulkCosts)
    {
        return ($this->TotalBreakBulkCosts = $_totalBreakBulkCosts);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructBreakBulkOrderItem
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
