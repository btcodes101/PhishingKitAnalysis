<?php
/**
 * File for class WsdlStructBreakBulkFees
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructBreakBulkFees originally named BreakBulkFees
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructBreakBulkFees extends WsdlWsdlClass
{
    /**
     * The FirstItemFee
     * @var WsdlStructAmount
     */
    public $FirstItemFee;
    /**
     * The AdditionalItemFee
     * @var WsdlStructAmount
     */
    public $AdditionalItemFee;
    /**
     * Constructor method for BreakBulkFees
     * @see parent::__construct()
     * @param WsdlStructAmount $_firstItemFee
     * @param WsdlStructAmount $_additionalItemFee
     * @return WsdlStructBreakBulkFees
     */
    public function __construct($_firstItemFee = NULL,$_additionalItemFee = NULL)
    {
        parent::__construct(array('FirstItemFee'=>$_firstItemFee,'AdditionalItemFee'=>$_additionalItemFee),false);
    }
    /**
     * Get FirstItemFee value
     * @return WsdlStructAmount|null
     */
    public function getFirstItemFee()
    {
        return $this->FirstItemFee;
    }
    /**
     * Set FirstItemFee value
     * @param WsdlStructAmount $_firstItemFee the FirstItemFee
     * @return WsdlStructAmount
     */
    public function setFirstItemFee($_firstItemFee)
    {
        return ($this->FirstItemFee = $_firstItemFee);
    }
    /**
     * Get AdditionalItemFee value
     * @return WsdlStructAmount|null
     */
    public function getAdditionalItemFee()
    {
        return $this->AdditionalItemFee;
    }
    /**
     * Set AdditionalItemFee value
     * @param WsdlStructAmount $_additionalItemFee the AdditionalItemFee
     * @return WsdlStructAmount
     */
    public function setAdditionalItemFee($_additionalItemFee)
    {
        return ($this->AdditionalItemFee = $_additionalItemFee);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructBreakBulkFees
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
