<?php
/**
 * File for class WsdlStructBreakBulkReference
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructBreakBulkReference originally named BreakBulkReference
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructBreakBulkReference extends WsdlWsdlClass
{
    /**
     * The Reference
     * @var string
     */
    public $Reference;
    /**
     * Constructor method for BreakBulkReference
     * @see parent::__construct()
     * @param string $_reference
     * @return WsdlStructBreakBulkReference
     */
    public function __construct($_reference = NULL)
    {
        parent::__construct(array('Reference'=>$_reference),false);
    }
    /**
     * Get Reference value
     * @return string|null
     */
    public function getReference()
    {
        return $this->Reference;
    }
    /**
     * Set Reference value
     * @param string $_reference the Reference
     * @return string
     */
    public function setReference($_reference)
    {
        return ($this->Reference = $_reference);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructBreakBulkReference
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
