<?php
/**
 * File for class WsdlStructTransaction
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructTransaction originally named Transaction
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructTransaction extends WsdlWsdlClass
{
    /**
     * The Date
     * @var dateTime
     */
    public $Date;
    /**
     * The DueDate
     * Meta informations extracted from the WSDL
     * - nillable : true
     * @var date
     */
    public $DueDate;
    /**
     * The Description
     * @var string
     */
    public $Description;
    /**
     * The Debit
     * Meta informations extracted from the WSDL
     * - nillable : true
     * @var WsdlStructAmount
     */
    public $Debit;
    /**
     * The Credit
     * Meta informations extracted from the WSDL
     * - nillable : true
     * @var WsdlStructAmount
     */
    public $Credit;
    /**
     * The Balance
     * @var WsdlStructAmount
     */
    public $Balance;
    /**
     * Constructor method for Transaction
     * @see parent::__construct()
     * @param dateTime $_date
     * @param date $_dueDate
     * @param string $_description
     * @param WsdlStructAmount $_debit
     * @param WsdlStructAmount $_credit
     * @param WsdlStructAmount $_balance
     * @return WsdlStructTransaction
     */
    public function __construct($_date = NULL,$_dueDate = NULL,$_description = NULL,$_debit = NULL,$_credit = NULL,$_balance = NULL)
    {
        parent::__construct(array('Date'=>$_date,'DueDate'=>$_dueDate,'Description'=>$_description,'Debit'=>$_debit,'Credit'=>$_credit,'Balance'=>$_balance),false);
    }
    /**
     * Get Date value
     * @return dateTime|null
     */
    public function getDate()
    {
        return $this->Date;
    }
    /**
     * Set Date value
     * @param dateTime $_date the Date
     * @return dateTime
     */
    public function setDate($_date)
    {
        return ($this->Date = $_date);
    }
    /**
     * Get DueDate value
     * @return date|null
     */
    public function getDueDate()
    {
        return $this->DueDate;
    }
    /**
     * Set DueDate value
     * @param date $_dueDate the DueDate
     * @return date
     */
    public function setDueDate($_dueDate)
    {
        return ($this->DueDate = $_dueDate);
    }
    /**
     * Get Description value
     * @return string|null
     */
    public function getDescription()
    {
        return $this->Description;
    }
    /**
     * Set Description value
     * @param string $_description the Description
     * @return string
     */
    public function setDescription($_description)
    {
        return ($this->Description = $_description);
    }
    /**
     * Get Debit value
     * @return WsdlStructAmount|null
     */
    public function getDebit()
    {
        return $this->Debit;
    }
    /**
     * Set Debit value
     * @param WsdlStructAmount $_debit the Debit
     * @return WsdlStructAmount
     */
    public function setDebit($_debit)
    {
        return ($this->Debit = $_debit);
    }
    /**
     * Get Credit value
     * @return WsdlStructAmount|null
     */
    public function getCredit()
    {
        return $this->Credit;
    }
    /**
     * Set Credit value
     * @param WsdlStructAmount $_credit the Credit
     * @return WsdlStructAmount
     */
    public function setCredit($_credit)
    {
        return ($this->Credit = $_credit);
    }
    /**
     * Get Balance value
     * @return WsdlStructAmount|null
     */
    public function getBalance()
    {
        return $this->Balance;
    }
    /**
     * Set Balance value
     * @param WsdlStructAmount $_balance the Balance
     * @return WsdlStructAmount
     */
    public function setBalance($_balance)
    {
        return ($this->Balance = $_balance);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructTransaction
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
