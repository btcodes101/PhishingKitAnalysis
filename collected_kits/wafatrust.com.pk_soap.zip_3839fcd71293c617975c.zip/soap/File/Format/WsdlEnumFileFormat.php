<?php
/**
 * File for class WsdlEnumFileFormat
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlEnumFileFormat originally named FileFormat
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlEnumFileFormat extends WsdlWsdlClass
{
    /**
     * Constant for value 'Delimited'
     * Meta informations extracted from the WSDL
     * - documentation : Delimited file format.
     * @return string 'Delimited'
     */
    const VALUE_DELIMITED = 'Delimited';
    /**
     * Constant for value 'XML'
     * Meta informations extracted from the WSDL
     * - documentation : XML file format.
     * @return string 'XML'
     */
    const VALUE_XML = 'XML';
    /**
     * Constant for value 'JSON'
     * Meta informations extracted from the WSDL
     * - documentation : JSON file format.
     * @return string 'JSON'
     */
    const VALUE_JSON = 'JSON';
    /**
     * Constant for value 'XLSX'
     * Meta informations extracted from the WSDL
     * - documentation : XLSX file format.
     * @return string 'XLSX'
     */
    const VALUE_XLSX = 'XLSX';
    /**
     * Return true if value is allowed
     * @uses WsdlEnumFileFormat::VALUE_DELIMITED
     * @uses WsdlEnumFileFormat::VALUE_XML
     * @uses WsdlEnumFileFormat::VALUE_JSON
     * @uses WsdlEnumFileFormat::VALUE_XLSX
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(WsdlEnumFileFormat::VALUE_DELIMITED,WsdlEnumFileFormat::VALUE_XML,WsdlEnumFileFormat::VALUE_JSON,WsdlEnumFileFormat::VALUE_XLSX));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
