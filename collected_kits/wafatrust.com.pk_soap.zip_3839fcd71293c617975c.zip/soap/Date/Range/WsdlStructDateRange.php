<?php
/**
 * File for class WsdlStructDateRange
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructDateRange originally named DateRange
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructDateRange extends WsdlWsdlClass
{
    /**
     * The StartDate
     * @var date
     */
    public $StartDate;
    /**
     * The EndDate
     * @var date
     */
    public $EndDate;
    /**
     * Constructor method for DateRange
     * @see parent::__construct()
     * @param date $_startDate
     * @param date $_endDate
     * @return WsdlStructDateRange
     */
    public function __construct($_startDate = NULL,$_endDate = NULL)
    {
        parent::__construct(array('StartDate'=>$_startDate,'EndDate'=>$_endDate),false);
    }
    /**
     * Get StartDate value
     * @return date|null
     */
    public function getStartDate()
    {
        return $this->StartDate;
    }
    /**
     * Set StartDate value
     * @param date $_startDate the StartDate
     * @return date
     */
    public function setStartDate($_startDate)
    {
        return ($this->StartDate = $_startDate);
    }
    /**
     * Get EndDate value
     * @return date|null
     */
    public function getEndDate()
    {
        return $this->EndDate;
    }
    /**
     * Set EndDate value
     * @param date $_endDate the EndDate
     * @return date
     */
    public function setEndDate($_endDate)
    {
        return ($this->EndDate = $_endDate);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructDateRange
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
