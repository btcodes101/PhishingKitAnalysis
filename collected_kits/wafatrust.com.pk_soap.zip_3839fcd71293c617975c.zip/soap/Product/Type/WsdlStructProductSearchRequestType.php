<?php
/**
 * File for class WsdlStructProductSearchRequestType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructProductSearchRequestType originally named ProductSearchRequestType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructProductSearchRequestType extends WsdlStructAbstractRequestType
{
    /**
     * The StockCodes
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfStockCode
     */
    public $StockCodes;
    /**
     * The Categories
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfCategory
     */
    public $Categories;
    /**
     * The Brands
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfBrand
     */
    public $Brands;
    /**
     * The ProductTypes
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfProductType
     */
    public $ProductTypes;
    /**
     * The Genders
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfGender
     */
    public $Genders;
    /**
     * The PriceRange
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructPriceRange
     */
    public $PriceRange;
    /**
     * The MinimumAvailableStock
     * Meta informations extracted from the WSDL
     * - default : 1
     * - minOccurs : 0
     * @var int
     */
    public $MinimumAvailableStock;
    /**
     * The SearchTerm
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $SearchTerm;
    /**
     * The Page
     * Meta informations extracted from the WSDL
     * - default : 1
     * @var int
     */
    public $Page;
    /**
     * The ResultsPerPage
     * Meta informations extracted from the WSDL
     * - default : 50
     * @var int
     */
    public $ResultsPerPage;
    /**
     * Constructor method for ProductSearchRequestType
     * @see parent::__construct()
     * @param WsdlStructArrayOfStockCode $_stockCodes
     * @param WsdlStructArrayOfCategory $_categories
     * @param WsdlStructArrayOfBrand $_brands
     * @param WsdlStructArrayOfProductType $_productTypes
     * @param WsdlStructArrayOfGender $_genders
     * @param WsdlStructPriceRange $_priceRange
     * @param int $_minimumAvailableStock
     * @param string $_searchTerm
     * @param int $_page
     * @param int $_resultsPerPage
     * @return WsdlStructProductSearchRequestType
     */
    public function __construct($_stockCodes = NULL,$_categories = NULL,$_brands = NULL,$_productTypes = NULL,$_genders = NULL,$_priceRange = NULL,$_minimumAvailableStock = 1,$_searchTerm = NULL,$_page = 1,$_resultsPerPage = 50)
    {
        WsdlWsdlClass::__construct(array('StockCodes'=>($_stockCodes instanceof WsdlStructArrayOfStockCode)?$_stockCodes:new WsdlStructArrayOfStockCode($_stockCodes),'Categories'=>($_categories instanceof WsdlStructArrayOfCategory)?$_categories:new WsdlStructArrayOfCategory($_categories),'Brands'=>($_brands instanceof WsdlStructArrayOfBrand)?$_brands:new WsdlStructArrayOfBrand($_brands),'ProductTypes'=>($_productTypes instanceof WsdlStructArrayOfProductType)?$_productTypes:new WsdlStructArrayOfProductType($_productTypes),'Genders'=>($_genders instanceof WsdlStructArrayOfGender)?$_genders:new WsdlStructArrayOfGender($_genders),'PriceRange'=>$_priceRange,'MinimumAvailableStock'=>$_minimumAvailableStock,'SearchTerm'=>$_searchTerm,'Page'=>$_page,'ResultsPerPage'=>$_resultsPerPage),false);
    }
    /**
     * Get StockCodes value
     * @return WsdlStructArrayOfStockCode|null
     */
    public function getStockCodes()
    {
        return $this->StockCodes;
    }
    /**
     * Set StockCodes value
     * @param WsdlStructArrayOfStockCode $_stockCodes the StockCodes
     * @return WsdlStructArrayOfStockCode
     */
    public function setStockCodes($_stockCodes)
    {
        return ($this->StockCodes = $_stockCodes);
    }
    /**
     * Get Categories value
     * @return WsdlStructArrayOfCategory|null
     */
    public function getCategories()
    {
        return $this->Categories;
    }
    /**
     * Set Categories value
     * @param WsdlStructArrayOfCategory $_categories the Categories
     * @return WsdlStructArrayOfCategory
     */
    public function setCategories($_categories)
    {
        return ($this->Categories = $_categories);
    }
    /**
     * Get Brands value
     * @return WsdlStructArrayOfBrand|null
     */
    public function getBrands()
    {
        return $this->Brands;
    }
    /**
     * Set Brands value
     * @param WsdlStructArrayOfBrand $_brands the Brands
     * @return WsdlStructArrayOfBrand
     */
    public function setBrands($_brands)
    {
        return ($this->Brands = $_brands);
    }
    /**
     * Get ProductTypes value
     * @return WsdlStructArrayOfProductType|null
     */
    public function getProductTypes()
    {
        return $this->ProductTypes;
    }
    /**
     * Set ProductTypes value
     * @param WsdlStructArrayOfProductType $_productTypes the ProductTypes
     * @return WsdlStructArrayOfProductType
     */
    public function setProductTypes($_productTypes)
    {
        return ($this->ProductTypes = $_productTypes);
    }
    /**
     * Get Genders value
     * @return WsdlStructArrayOfGender|null
     */
    public function getGenders()
    {
        return $this->Genders;
    }
    /**
     * Set Genders value
     * @param WsdlStructArrayOfGender $_genders the Genders
     * @return WsdlStructArrayOfGender
     */
    public function setGenders($_genders)
    {
        return ($this->Genders = $_genders);
    }
    /**
     * Get PriceRange value
     * @return WsdlStructPriceRange|null
     */
    public function getPriceRange()
    {
        return $this->PriceRange;
    }
    /**
     * Set PriceRange value
     * @param WsdlStructPriceRange $_priceRange the PriceRange
     * @return WsdlStructPriceRange
     */
    public function setPriceRange($_priceRange)
    {
        return ($this->PriceRange = $_priceRange);
    }
    /**
     * Get MinimumAvailableStock value
     * @return int|null
     */
    public function getMinimumAvailableStock()
    {
        return $this->MinimumAvailableStock;
    }
    /**
     * Set MinimumAvailableStock value
     * @param int $_minimumAvailableStock the MinimumAvailableStock
     * @return int
     */
    public function setMinimumAvailableStock($_minimumAvailableStock)
    {
        return ($this->MinimumAvailableStock = $_minimumAvailableStock);
    }
    /**
     * Get SearchTerm value
     * @return string|null
     */
    public function getSearchTerm()
    {
        return $this->SearchTerm;
    }
    /**
     * Set SearchTerm value
     * @param string $_searchTerm the SearchTerm
     * @return string
     */
    public function setSearchTerm($_searchTerm)
    {
        return ($this->SearchTerm = $_searchTerm);
    }
    /**
     * Get Page value
     * @return int|null
     */
    public function getPage()
    {
        return $this->Page;
    }
    /**
     * Set Page value
     * @param int $_page the Page
     * @return int
     */
    public function setPage($_page)
    {
        return ($this->Page = $_page);
    }
    /**
     * Get ResultsPerPage value
     * @return int|null
     */
    public function getResultsPerPage()
    {
        return $this->ResultsPerPage;
    }
    /**
     * Set ResultsPerPage value
     * @param int $_resultsPerPage the ResultsPerPage
     * @return int
     */
    public function setResultsPerPage($_resultsPerPage)
    {
        return ($this->ResultsPerPage = $_resultsPerPage);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructProductSearchRequestType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
