<?php
/**
 * File for class WsdlStructProductSearchResponseType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructProductSearchResponseType originally named ProductSearchResponseType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructProductSearchResponseType extends WsdlStructAbstractResponseType
{
    /**
     * The Page
     * @var int
     */
    public $Page;
    /**
     * The ResultsPerPage
     * @var int
     */
    public $ResultsPerPage;
    /**
     * The TotalResults
     * @var int
     */
    public $TotalResults;
    /**
     * The Items
     * @var WsdlStructArrayOfItem
     */
    public $Items;
    /**
     * Constructor method for ProductSearchResponseType
     * @see parent::__construct()
     * @param int $_page
     * @param int $_resultsPerPage
     * @param int $_totalResults
     * @param WsdlStructArrayOfItem $_items
     * @return WsdlStructProductSearchResponseType
     */
    public function __construct($_page = NULL,$_resultsPerPage = NULL,$_totalResults = NULL,$_items = NULL)
    {
        WsdlWsdlClass::__construct(array('Page'=>$_page,'ResultsPerPage'=>$_resultsPerPage,'TotalResults'=>$_totalResults,'Items'=>($_items instanceof WsdlStructArrayOfItem)?$_items:new WsdlStructArrayOfItem($_items)),false);
    }
    /**
     * Get Page value
     * @return int|null
     */
    public function getPage()
    {
        return $this->Page;
    }
    /**
     * Set Page value
     * @param int $_page the Page
     * @return int
     */
    public function setPage($_page)
    {
        return ($this->Page = $_page);
    }
    /**
     * Get ResultsPerPage value
     * @return int|null
     */
    public function getResultsPerPage()
    {
        return $this->ResultsPerPage;
    }
    /**
     * Set ResultsPerPage value
     * @param int $_resultsPerPage the ResultsPerPage
     * @return int
     */
    public function setResultsPerPage($_resultsPerPage)
    {
        return ($this->ResultsPerPage = $_resultsPerPage);
    }
    /**
     * Get TotalResults value
     * @return int|null
     */
    public function getTotalResults()
    {
        return $this->TotalResults;
    }
    /**
     * Set TotalResults value
     * @param int $_totalResults the TotalResults
     * @return int
     */
    public function setTotalResults($_totalResults)
    {
        return ($this->TotalResults = $_totalResults);
    }
    /**
     * Get Items value
     * @return WsdlStructArrayOfItem|null
     */
    public function getItems()
    {
        return $this->Items;
    }
    /**
     * Set Items value
     * @param WsdlStructArrayOfItem $_items the Items
     * @return WsdlStructArrayOfItem
     */
    public function setItems($_items)
    {
        return ($this->Items = $_items);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructProductSearchResponseType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
