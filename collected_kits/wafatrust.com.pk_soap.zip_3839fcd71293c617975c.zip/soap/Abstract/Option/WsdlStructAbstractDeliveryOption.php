<?php
/**
 * File for class WsdlStructAbstractDeliveryOption
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructAbstractDeliveryOption originally named AbstractDeliveryOption
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
abstract class WsdlStructAbstractDeliveryOption extends WsdlWsdlClass
{
    /**
     * The ID
     * @var int
     */
    public $ID;
    /**
     * The CountryCode
     * @var WsdlEnumCountryCode
     */
    public $CountryCode;
    /**
     * The Name
     * @var string
     */
    public $Name;
    /**
     * The Price
     * @var WsdlStructAmount
     */
    public $Price;
    /**
     * Constructor method for AbstractDeliveryOption
     * @see parent::__construct()
     * @param int $_iD
     * @param WsdlEnumCountryCode $_countryCode
     * @param string $_name
     * @param WsdlStructAmount $_price
     * @return WsdlStructAbstractDeliveryOption
     */
    public function __construct($_iD = NULL,$_countryCode = NULL,$_name = NULL,$_price = NULL)
    {
        parent::__construct(array('ID'=>$_iD,'CountryCode'=>$_countryCode,'Name'=>$_name,'Price'=>$_price),false);
    }
    /**
     * Get ID value
     * @return int|null
     */
    public function getID()
    {
        return $this->ID;
    }
    /**
     * Set ID value
     * @param int $_iD the ID
     * @return int
     */
    public function setID($_iD)
    {
        return ($this->ID = $_iD);
    }
    /**
     * Get CountryCode value
     * @return WsdlEnumCountryCode|null
     */
    public function getCountryCode()
    {
        return $this->CountryCode;
    }
    /**
     * Set CountryCode value
     * @uses WsdlEnumCountryCode::valueIsValid()
     * @param WsdlEnumCountryCode $_countryCode the CountryCode
     * @return WsdlEnumCountryCode
     */
    public function setCountryCode($_countryCode)
    {
        if(!WsdlEnumCountryCode::valueIsValid($_countryCode))
        {
            return false;
        }
        return ($this->CountryCode = $_countryCode);
    }
    /**
     * Get Name value
     * @return string|null
     */
    public function getName()
    {
        return $this->Name;
    }
    /**
     * Set Name value
     * @param string $_name the Name
     * @return string
     */
    public function setName($_name)
    {
        return ($this->Name = $_name);
    }
    /**
     * Get Price value
     * @return WsdlStructAmount|null
     */
    public function getPrice()
    {
        return $this->Price;
    }
    /**
     * Set Price value
     * @param WsdlStructAmount $_price the Price
     * @return WsdlStructAmount
     */
    public function setPrice($_price)
    {
        return ($this->Price = $_price);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructAbstractDeliveryOption
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
