<?php
/**
 * File for class WsdlStructAbstractResponseType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructAbstractResponseType originally named AbstractResponseType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
abstract class WsdlStructAbstractResponseType extends WsdlWsdlClass
{
    /**
     * The TestMode
     * @var boolean
     */
    public $TestMode;
    /**
     * The Errors
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfError
     */
    public $Errors;
    /**
     * The Warnings
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructArrayOfWarning
     */
    public $Warnings;
    /**
     * Constructor method for AbstractResponseType
     * @see parent::__construct()
     * @param boolean $_testMode
     * @param WsdlStructArrayOfError $_errors
     * @param WsdlStructArrayOfWarning $_warnings
     * @return WsdlStructAbstractResponseType
     */
    public function __construct($_testMode = NULL,$_errors = NULL,$_warnings = NULL)
    {
        parent::__construct(array('TestMode'=>$_testMode,'Errors'=>($_errors instanceof WsdlStructArrayOfError)?$_errors:new WsdlStructArrayOfError($_errors),'Warnings'=>($_warnings instanceof WsdlStructArrayOfWarning)?$_warnings:new WsdlStructArrayOfWarning($_warnings)),false);
    }
    /**
     * Get TestMode value
     * @return boolean|null
     */
    public function getTestMode()
    {
        return $this->TestMode;
    }
    /**
     * Set TestMode value
     * @param boolean $_testMode the TestMode
     * @return boolean
     */
    public function setTestMode($_testMode)
    {
        return ($this->TestMode = $_testMode);
    }
    /**
     * Get Errors value
     * @return WsdlStructArrayOfError|null
     */
    public function getErrors()
    {
        return $this->Errors;
    }
    /**
     * Set Errors value
     * @param WsdlStructArrayOfError $_errors the Errors
     * @return WsdlStructArrayOfError
     */
    public function setErrors($_errors)
    {
        return ($this->Errors = $_errors);
    }
    /**
     * Get Warnings value
     * @return WsdlStructArrayOfWarning|null
     */
    public function getWarnings()
    {
        return $this->Warnings;
    }
    /**
     * Set Warnings value
     * @param WsdlStructArrayOfWarning $_warnings the Warnings
     * @return WsdlStructArrayOfWarning
     */
    public function setWarnings($_warnings)
    {
        return ($this->Warnings = $_warnings);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructAbstractResponseType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
