<?php
/**
 * File for the class which returns the class map definition
 * @package Wsdl
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * Class which returns the class map definition by the static method WsdlClassMap::classMap()
 * @package Wsdl
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlClassMap
{
    /**
     * This method returns the array containing the mapping between WSDL structs and generated classes
     * This array is sent to the SoapClient when calling the WS
     * @return array
     */
    final public static function classMap()
    {
        return array (
  'AbstractDeliveryOption' => 'WsdlStructAbstractDeliveryOption',
  'AbstractRequestType' => 'WsdlStructAbstractRequestType',
  'AbstractResponseType' => 'WsdlStructAbstractResponseType',
  'AbstractSkuDetail' => 'WsdlStructAbstractSkuDetail',
  'AccountInformationType' => 'WsdlEnumAccountInformationType',
  'AddBreakBulkOrderItemRequestType' => 'WsdlStructAddBreakBulkOrderItemRequestType',
  'AddBreakBulkOrderItemResponseType' => 'WsdlStructAddBreakBulkOrderItemResponseType',
  'AddOrderItemRequestType' => 'WsdlStructAddOrderItemRequestType',
  'AddOrderItemResponseType' => 'WsdlStructAddOrderItemResponseType',
  'Address' => 'WsdlStructAddress',
  'Amount' => 'WsdlStructAmount',
  'ArrayOfAccountInformationType' => 'WsdlStructArrayOfAccountInformationType',
  'ArrayOfBrand' => 'WsdlStructArrayOfBrand',
  'ArrayOfBreakBulkItem' => 'WsdlStructArrayOfBreakBulkItem',
  'ArrayOfBreakBulkOrderItem' => 'WsdlStructArrayOfBreakBulkOrderItem',
  'ArrayOfBreakBulkReference' => 'WsdlStructArrayOfBreakBulkReference',
  'ArrayOfCategory' => 'WsdlStructArrayOfCategory',
  'ArrayOfDirectDispatchDeliveryOption' => 'WsdlStructArrayOfDirectDispatchDeliveryOption',
  'ArrayOfError' => 'WsdlStructArrayOfError',
  'ArrayOfGender' => 'WsdlStructArrayOfGender',
  'ArrayOfItem' => 'WsdlStructArrayOfItem',
  'ArrayOfOrderItem' => 'WsdlStructArrayOfOrderItem',
  'ArrayOfOrderOverview' => 'WsdlStructArrayOfOrderOverview',
  'ArrayOfPaymentMethod' => 'WsdlStructArrayOfPaymentMethod',
  'ArrayOfProductType' => 'WsdlStructArrayOfProductType',
  'ArrayOfStockCode' => 'WsdlStructArrayOfStockCode',
  'ArrayOfStockFileField' => 'WsdlStructArrayOfStockFileField',
  'ArrayOfTransaction' => 'WsdlStructArrayOfTransaction',
  'ArrayOfWarning' => 'WsdlStructArrayOfWarning',
  'ArrayOfWholesaleDeliveryOption' => 'WsdlStructArrayOfWholesaleDeliveryOption',
  'AuthHeader' => 'WsdlStructAuthHeader',
  'Brand' => 'WsdlStructBrand',
  'BreakBulkFees' => 'WsdlStructBreakBulkFees',
  'BreakBulkItem' => 'WsdlStructBreakBulkItem',
  'BreakBulkOrderItem' => 'WsdlStructBreakBulkOrderItem',
  'BreakBulkReference' => 'WsdlStructBreakBulkReference',
  'CancelOrderRequestType' => 'WsdlStructCancelOrderRequestType',
  'CancelOrderResponseType' => 'WsdlStructCancelOrderResponseType',
  'Category' => 'WsdlStructCategory',
  'CountryCode' => 'WsdlEnumCountryCode',
  'CreateOrderRequestType' => 'WsdlStructCreateOrderRequestType',
  'CreateOrderResponseType' => 'WsdlStructCreateOrderResponseType',
  'Currency' => 'WsdlEnumCurrency',
  'DateRange' => 'WsdlStructDateRange',
  'DeliveryOption' => 'WsdlStructDeliveryOption',
  'DirectDispatchDeliveryOption' => 'WsdlStructDirectDispatchDeliveryOption',
  'DirectDispatchFees' => 'WsdlStructDirectDispatchFees',
  'EditOrderItemRequestType' => 'WsdlStructEditOrderItemRequestType',
  'EditOrderItemResponseType' => 'WsdlStructEditOrderItemResponseType',
  'Error' => 'WsdlStructError',
  'FileFormat' => 'WsdlEnumFileFormat',
  'Gender' => 'WsdlStructGender',
  'GetAccountInformationRequestType' => 'WsdlStructGetAccountInformationRequestType',
  'GetAccountInformationResponseType' => 'WsdlStructGetAccountInformationResponseType',
  'GetAccountStatementRequestType' => 'WsdlStructGetAccountStatementRequestType',
  'GetAccountStatementResponseType' => 'WsdlStructGetAccountStatementResponseType',
  'GetFreeDirectDispatchCancellationsLeftRequestType' => 'WsdlStructGetFreeDirectDispatchCancellationsLeftRequestType',
  'GetFreeDirectDispatchCancellationsLeftResponseType' => 'WsdlStructGetFreeDirectDispatchCancellationsLeftResponseType',
  'GetHighResImageRequestType' => 'WsdlStructGetHighResImageRequestType',
  'GetHighResImageResponseType' => 'WsdlStructGetHighResImageResponseType',
  'GetOrderDetailRequestType' => 'WsdlStructGetOrderDetailRequestType',
  'GetOrderDetailResponseType' => 'WsdlStructGetOrderDetailResponseType',
  'GetOrdersRequestType' => 'WsdlStructGetOrdersRequestType',
  'GetOrdersResponseType' => 'WsdlStructGetOrdersResponseType',
  'GetStockFileRequestType' => 'WsdlStructGetStockFileRequestType',
  'GetStockFileResponseType' => 'WsdlStructGetStockFileResponseType',
  'Item' => 'WsdlStructItem',
  'OrderCostSummary' => 'WsdlStructOrderCostSummary',
  'OrderDetail' => 'WsdlStructOrderDetail',
  'OrderItem' => 'WsdlStructOrderItem',
  'OrderOverview' => 'WsdlStructOrderOverview',
  'OrderStatus' => 'WsdlEnumOrderStatus',
  'OrderType' => 'WsdlEnumOrderType',
  'PaymentMethod' => 'WsdlStructPaymentMethod',
  'PictureFees' => 'WsdlStructPictureFees',
  'PlaceOrderRequestType' => 'WsdlStructPlaceOrderRequestType',
  'PlaceOrderResponseType' => 'WsdlStructPlaceOrderResponseType',
  'PriceRange' => 'WsdlStructPriceRange',
  'ProductSearchRequestType' => 'WsdlStructProductSearchRequestType',
  'ProductSearchResponseType' => 'WsdlStructProductSearchResponseType',
  'ProductType' => 'WsdlStructProductType',
  'RemoveBreakBulkOrderItemRequestType' => 'WsdlStructRemoveBreakBulkOrderItemRequestType',
  'RemoveBreakBulkOrderItemResponseType' => 'WsdlStructRemoveBreakBulkOrderItemResponseType',
  'RemoveOrderItemRequestType' => 'WsdlStructRemoveOrderItemRequestType',
  'RemoveOrderItemResponseType' => 'WsdlStructRemoveOrderItemResponseType',
  'StockFileField' => 'WsdlEnumStockFileField',
  'StockFileSort' => 'WsdlEnumStockFileSort',
  'Transaction' => 'WsdlStructTransaction',
  'Warning' => 'WsdlStructWarning',
  'WholesaleDeliveryOption' => 'WsdlStructWholesaleDeliveryOption',
);
    }
}
