<?php

ini_set('memory_limit','512M');
ini_set('display_errors',true);
error_reporting(-1);
/**
 * Load autoload
 */
require_once dirname(__FILE__) . '/WsdlAutoload.php';
require_once  'config.php';
require_once  'Shopify.php';

$productUrl = $secureUrl."/admin/api/2019-07/products.json";
 $random = substr(md5(mt_rand()), 0, 7);
//echo "<pre>";
$shopify = new Shopify();
/********************************
 * Example for WsdlServiceProduct
 */
date_default_timezone_set('Europe/London');
$now = new DateTime();
$created  = $now->format('Y-m-d H:i:s');
$_nonce = $random;
$password = base64_encode(sha1($_nonce.$created."ib1hJswqvDZ2QOW3Fg9neR0KzxPS4CHkr"));
/*******************************
 * Example for WsdlServiceCreate
 */
$wsdlServiceCreate = new WsdlServiceCreate();
// sample call for WsdlServiceCreate::setSoapHeaderAuthHeader() in order to initialize required SoapHeader
//$wsdlServiceCreate->setSoapHeaderAuthHeader(new WsdlStructAuthHeader(/*** update parameters list ***/));
$wsdlServiceCreate->setSoapHeaderAuthHeader(new WsdlStructAuthHeader("abbasahmed@mac.com",$_nonce,$created,$password));
// sample call for WsdlServiceCreate::CreateOrder()
if($wsdlServiceCreate->CreateOrder(new WsdlStructCreateOrderRequestType(/*** update parameters list ***/)))
    print_r($wsdlServiceCreate->getResult());
//else
//    print_r($wsdlServiceCreate->getLastError());