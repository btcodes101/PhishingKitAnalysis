<?php
/**
 * File for class WsdlStructAmount
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructAmount originally named Amount
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructAmount extends WsdlWsdlClass
{
    /**
     * The Currency
     * Meta informations extracted from the WSDL
     * - use : required
     * @var WsdlEnumCurrency
     */
    public $Currency;
    /**
     * The Amount
     * Meta informations extracted from the WSDL
     * - fractionDigits : 2
     * @var decimal
     */
    public $Amount;
    /**
     * Constructor method for Amount
     * @see parent::__construct()
     * @param WsdlEnumCurrency $_currency
     * @param decimal $_amount
     * @return WsdlStructAmount
     */
    public function __construct($_currency,$_amount = NULL)
    {
        parent::__construct(array('Currency'=>$_currency,'Amount'=>$_amount),false);
    }
    /**
     * Get Currency value
     * @return WsdlEnumCurrency
     */
    public function getCurrency()
    {
        return $this->Currency;
    }
    /**
     * Set Currency value
     * @uses WsdlEnumCurrency::valueIsValid()
     * @param WsdlEnumCurrency $_currency the Currency
     * @return WsdlEnumCurrency
     */
    public function setCurrency($_currency)
    {
        if(!WsdlEnumCurrency::valueIsValid($_currency))
        {
            return false;
        }
        return ($this->Currency = $_currency);
    }
    /**
     * Get Amount value
     * @return decimal|null
     */
    public function getAmount()
    {
        return $this->Amount;
    }
    /**
     * Set Amount value
     * @param decimal $_amount the Amount
     * @return decimal
     */
    public function setAmount($_amount)
    {
        return ($this->Amount = $_amount);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructAmount
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
