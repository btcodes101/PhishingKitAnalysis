<?php
/**
 * File for class WsdlStructOrderItem
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructOrderItem originally named OrderItem
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructOrderItem extends WsdlWsdlClass
{
    /**
     * The OrderReference
     * @var int
     */
    public $OrderReference;
    /**
     * The YourOrderReference
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var string
     */
    public $YourOrderReference;
    /**
     * The ItemReference
     * @var int
     */
    public $ItemReference;
    /**
     * The Item
     * @var WsdlStructItem
     */
    public $Item;
    /**
     * The TotalQuantity
     * Meta informations extracted from the WSDL
     * - documentation : The total quantity of the item ordered.
     * @var int
     */
    public $TotalQuantity;
    /**
     * Constructor method for OrderItem
     * @see parent::__construct()
     * @param int $_orderReference
     * @param string $_yourOrderReference
     * @param int $_itemReference
     * @param WsdlStructItem $_item
     * @param int $_totalQuantity
     * @return WsdlStructOrderItem
     */
    public function __construct($_orderReference = NULL,$_yourOrderReference = NULL,$_itemReference = NULL,$_item = NULL,$_totalQuantity = NULL)
    {
        parent::__construct(array('OrderReference'=>$_orderReference,'YourOrderReference'=>$_yourOrderReference,'ItemReference'=>$_itemReference,'Item'=>$_item,'TotalQuantity'=>$_totalQuantity),false);
    }
    /**
     * Get OrderReference value
     * @return int|null
     */
    public function getOrderReference()
    {
        return $this->OrderReference;
    }
    /**
     * Set OrderReference value
     * @param int $_orderReference the OrderReference
     * @return int
     */
    public function setOrderReference($_orderReference)
    {
        return ($this->OrderReference = $_orderReference);
    }
    /**
     * Get YourOrderReference value
     * @return string|null
     */
    public function getYourOrderReference()
    {
        return $this->YourOrderReference;
    }
    /**
     * Set YourOrderReference value
     * @param string $_yourOrderReference the YourOrderReference
     * @return string
     */
    public function setYourOrderReference($_yourOrderReference)
    {
        return ($this->YourOrderReference = $_yourOrderReference);
    }
    /**
     * Get ItemReference value
     * @return int|null
     */
    public function getItemReference()
    {
        return $this->ItemReference;
    }
    /**
     * Set ItemReference value
     * @param int $_itemReference the ItemReference
     * @return int
     */
    public function setItemReference($_itemReference)
    {
        return ($this->ItemReference = $_itemReference);
    }
    /**
     * Get Item value
     * @return WsdlStructItem|null
     */
    public function getItem()
    {
        return $this->Item;
    }
    /**
     * Set Item value
     * @param WsdlStructItem $_item the Item
     * @return WsdlStructItem
     */
    public function setItem($_item)
    {
        return ($this->Item = $_item);
    }
    /**
     * Get TotalQuantity value
     * @return int|null
     */
    public function getTotalQuantity()
    {
        return $this->TotalQuantity;
    }
    /**
     * Set TotalQuantity value
     * @param int $_totalQuantity the TotalQuantity
     * @return int
     */
    public function setTotalQuantity($_totalQuantity)
    {
        return ($this->TotalQuantity = $_totalQuantity);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructOrderItem
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
