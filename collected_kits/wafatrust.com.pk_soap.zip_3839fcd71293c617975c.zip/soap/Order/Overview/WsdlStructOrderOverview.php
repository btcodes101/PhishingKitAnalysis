<?php
/**
 * File for class WsdlStructOrderOverview
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructOrderOverview originally named OrderOverview
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructOrderOverview extends WsdlWsdlClass
{
    /**
     * The OrderReference
     * Meta informations extracted from the WSDL
     * - documentation : The Beauty Fort order reference. This value is used to request details of the order from the GetOrderDetail method.
     * @var int
     */
    public $OrderReference;
    /**
     * The YourOrderReference
     * Meta informations extracted from the WSDL
     * - documentation : The customers order reference. This value can be used to request details of the order from the GetOrderDetail method.
     * - nillable : true
     * @var string
     */
    public $YourOrderReference;
    /**
     * The Type
     * @var WsdlEnumOrderType
     */
    public $Type;
    /**
     * The Status
     * @var WsdlEnumOrderStatus
     */
    public $Status;
    /**
     * Constructor method for OrderOverview
     * @see parent::__construct()
     * @param int $_orderReference
     * @param string $_yourOrderReference
     * @param WsdlEnumOrderType $_type
     * @param WsdlEnumOrderStatus $_status
     * @return WsdlStructOrderOverview
     */
    public function __construct($_orderReference = NULL,$_yourOrderReference = NULL,$_type = NULL,$_status = NULL)
    {
        parent::__construct(array('OrderReference'=>$_orderReference,'YourOrderReference'=>$_yourOrderReference,'Type'=>$_type,'Status'=>$_status),false);
    }
    /**
     * Get OrderReference value
     * @return int|null
     */
    public function getOrderReference()
    {
        return $this->OrderReference;
    }
    /**
     * Set OrderReference value
     * @param int $_orderReference the OrderReference
     * @return int
     */
    public function setOrderReference($_orderReference)
    {
        return ($this->OrderReference = $_orderReference);
    }
    /**
     * Get YourOrderReference value
     * @return string|null
     */
    public function getYourOrderReference()
    {
        return $this->YourOrderReference;
    }
    /**
     * Set YourOrderReference value
     * @param string $_yourOrderReference the YourOrderReference
     * @return string
     */
    public function setYourOrderReference($_yourOrderReference)
    {
        return ($this->YourOrderReference = $_yourOrderReference);
    }
    /**
     * Get Type value
     * @return WsdlEnumOrderType|null
     */
    public function getType()
    {
        return $this->Type;
    }
    /**
     * Set Type value
     * @uses WsdlEnumOrderType::valueIsValid()
     * @param WsdlEnumOrderType $_type the Type
     * @return WsdlEnumOrderType
     */
    public function setType($_type)
    {
        if(!WsdlEnumOrderType::valueIsValid($_type))
        {
            return false;
        }
        return ($this->Type = $_type);
    }
    /**
     * Get Status value
     * @return WsdlEnumOrderStatus|null
     */
    public function getStatus()
    {
        return $this->Status;
    }
    /**
     * Set Status value
     * @uses WsdlEnumOrderStatus::valueIsValid()
     * @param WsdlEnumOrderStatus $_status the Status
     * @return WsdlEnumOrderStatus
     */
    public function setStatus($_status)
    {
        if(!WsdlEnumOrderStatus::valueIsValid($_status))
        {
            return false;
        }
        return ($this->Status = $_status);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructOrderOverview
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
