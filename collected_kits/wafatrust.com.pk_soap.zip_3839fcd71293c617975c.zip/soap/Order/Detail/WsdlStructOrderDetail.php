<?php
/**
 * File for class WsdlStructOrderDetail
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructOrderDetail originally named OrderDetail
 * Documentation : Details of a single order.
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructOrderDetail extends WsdlWsdlClass
{
    /**
     * The OrderReference
     * Meta informations extracted from the WSDL
     * - documentation : The Beauty Fort order reference.
     * @var int
     */
    public $OrderReference;
    /**
     * The YourOrderReference
     * Meta informations extracted from the WSDL
     * - documentation : The customers order reference.
     * - nillable : true
     * @var string
     */
    public $YourOrderReference;
    /**
     * The Type
     * Meta informations extracted from the WSDL
     * - documentation : The order type.
     * @var WsdlEnumOrderType
     */
    public $Type;
    /**
     * The Status
     * Meta informations extracted from the WSDL
     * - documentation : The status of the order.
     * @var WsdlEnumOrderStatus
     */
    public $Status;
    /**
     * The OrderCostSummary
     * Meta informations extracted from the WSDL
     * - documentation : Summary details of the cost of the order.
     * @var WsdlStructOrderCostSummary
     */
    public $OrderCostSummary;
    /**
     * The DeliveryOption
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructDeliveryOption
     */
    public $DeliveryOption;
    /**
     * The OrderItems
     * Meta informations extracted from the WSDL
     * - documentation : Details of the items in the order.
     * - minOccurs : 0
     * @var WsdlStructArrayOfOrderItem
     */
    public $OrderItems;
    /**
     * The BreakBulkOrderItems
     * Meta informations extracted from the WSDL
     * - documentation : Details of the break bulk items in the order.
     * - minOccurs : 0
     * @var WsdlStructArrayOfBreakBulkOrderItem
     */
    public $BreakBulkOrderItems;
    /**
     * Constructor method for OrderDetail
     * @see parent::__construct()
     * @param int $_orderReference
     * @param string $_yourOrderReference
     * @param WsdlEnumOrderType $_type
     * @param WsdlEnumOrderStatus $_status
     * @param WsdlStructOrderCostSummary $_orderCostSummary
     * @param WsdlStructDeliveryOption $_deliveryOption
     * @param WsdlStructArrayOfOrderItem $_orderItems
     * @param WsdlStructArrayOfBreakBulkOrderItem $_breakBulkOrderItems
     * @return WsdlStructOrderDetail
     */
    public function __construct($_orderReference = NULL,$_yourOrderReference = NULL,$_type = NULL,$_status = NULL,$_orderCostSummary = NULL,$_deliveryOption = NULL,$_orderItems = NULL,$_breakBulkOrderItems = NULL)
    {
        parent::__construct(array('OrderReference'=>$_orderReference,'YourOrderReference'=>$_yourOrderReference,'Type'=>$_type,'Status'=>$_status,'OrderCostSummary'=>$_orderCostSummary,'DeliveryOption'=>$_deliveryOption,'OrderItems'=>($_orderItems instanceof WsdlStructArrayOfOrderItem)?$_orderItems:new WsdlStructArrayOfOrderItem($_orderItems),'BreakBulkOrderItems'=>($_breakBulkOrderItems instanceof WsdlStructArrayOfBreakBulkOrderItem)?$_breakBulkOrderItems:new WsdlStructArrayOfBreakBulkOrderItem($_breakBulkOrderItems)),false);
    }
    /**
     * Get OrderReference value
     * @return int|null
     */
    public function getOrderReference()
    {
        return $this->OrderReference;
    }
    /**
     * Set OrderReference value
     * @param int $_orderReference the OrderReference
     * @return int
     */
    public function setOrderReference($_orderReference)
    {
        return ($this->OrderReference = $_orderReference);
    }
    /**
     * Get YourOrderReference value
     * @return string|null
     */
    public function getYourOrderReference()
    {
        return $this->YourOrderReference;
    }
    /**
     * Set YourOrderReference value
     * @param string $_yourOrderReference the YourOrderReference
     * @return string
     */
    public function setYourOrderReference($_yourOrderReference)
    {
        return ($this->YourOrderReference = $_yourOrderReference);
    }
    /**
     * Get Type value
     * @return WsdlEnumOrderType|null
     */
    public function getType()
    {
        return $this->Type;
    }
    /**
     * Set Type value
     * @uses WsdlEnumOrderType::valueIsValid()
     * @param WsdlEnumOrderType $_type the Type
     * @return WsdlEnumOrderType
     */
    public function setType($_type)
    {
        if(!WsdlEnumOrderType::valueIsValid($_type))
        {
            return false;
        }
        return ($this->Type = $_type);
    }
    /**
     * Get Status value
     * @return WsdlEnumOrderStatus|null
     */
    public function getStatus()
    {
        return $this->Status;
    }
    /**
     * Set Status value
     * @uses WsdlEnumOrderStatus::valueIsValid()
     * @param WsdlEnumOrderStatus $_status the Status
     * @return WsdlEnumOrderStatus
     */
    public function setStatus($_status)
    {
        if(!WsdlEnumOrderStatus::valueIsValid($_status))
        {
            return false;
        }
        return ($this->Status = $_status);
    }
    /**
     * Get OrderCostSummary value
     * @return WsdlStructOrderCostSummary|null
     */
    public function getOrderCostSummary()
    {
        return $this->OrderCostSummary;
    }
    /**
     * Set OrderCostSummary value
     * @param WsdlStructOrderCostSummary $_orderCostSummary the OrderCostSummary
     * @return WsdlStructOrderCostSummary
     */
    public function setOrderCostSummary($_orderCostSummary)
    {
        return ($this->OrderCostSummary = $_orderCostSummary);
    }
    /**
     * Get DeliveryOption value
     * @return WsdlStructDeliveryOption|null
     */
    public function getDeliveryOption()
    {
        return $this->DeliveryOption;
    }
    /**
     * Set DeliveryOption value
     * @param WsdlStructDeliveryOption $_deliveryOption the DeliveryOption
     * @return WsdlStructDeliveryOption
     */
    public function setDeliveryOption($_deliveryOption)
    {
        return ($this->DeliveryOption = $_deliveryOption);
    }
    /**
     * Get OrderItems value
     * @return WsdlStructArrayOfOrderItem|null
     */
    public function getOrderItems()
    {
        return $this->OrderItems;
    }
    /**
     * Set OrderItems value
     * @param WsdlStructArrayOfOrderItem $_orderItems the OrderItems
     * @return WsdlStructArrayOfOrderItem
     */
    public function setOrderItems($_orderItems)
    {
        return ($this->OrderItems = $_orderItems);
    }
    /**
     * Get BreakBulkOrderItems value
     * @return WsdlStructArrayOfBreakBulkOrderItem|null
     */
    public function getBreakBulkOrderItems()
    {
        return $this->BreakBulkOrderItems;
    }
    /**
     * Set BreakBulkOrderItems value
     * @param WsdlStructArrayOfBreakBulkOrderItem $_breakBulkOrderItems the BreakBulkOrderItems
     * @return WsdlStructArrayOfBreakBulkOrderItem
     */
    public function setBreakBulkOrderItems($_breakBulkOrderItems)
    {
        return ($this->BreakBulkOrderItems = $_breakBulkOrderItems);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructOrderDetail
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
