<?php
/**
 * File for class WsdlEnumOrderType
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlEnumOrderType originally named OrderType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlEnumOrderType extends WsdlWsdlClass
{
    /**
     * Constant for value 'Wholesale'
     * @return string 'Wholesale'
     */
    const VALUE_WHOLESALE = 'Wholesale';
    /**
     * Constant for value 'Direct Dispatch'
     * @return string 'Direct Dispatch'
     */
    const VALUE_DIRECT_DISPATCH = 'Direct Dispatch';
    /**
     * Return true if value is allowed
     * @uses WsdlEnumOrderType::VALUE_WHOLESALE
     * @uses WsdlEnumOrderType::VALUE_DIRECT_DISPATCH
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(WsdlEnumOrderType::VALUE_WHOLESALE,WsdlEnumOrderType::VALUE_DIRECT_DISPATCH));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
