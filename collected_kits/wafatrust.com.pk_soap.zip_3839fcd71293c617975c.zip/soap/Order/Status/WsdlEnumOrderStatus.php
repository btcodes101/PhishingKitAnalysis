<?php
/**
 * File for class WsdlEnumOrderStatus
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlEnumOrderStatus originally named OrderStatus
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlEnumOrderStatus extends WsdlWsdlClass
{
    /**
     * Constant for value 'New'
     * @return string 'New'
     */
    const VALUE_NEW = 'New';
    /**
     * Constant for value 'Payment Hold'
     * @return string 'Payment Hold'
     */
    const VALUE_PAYMENT_HOLD = 'Payment Hold';
    /**
     * Constant for value 'Processing'
     * @return string 'Processing'
     */
    const VALUE_PROCESSING = 'Processing';
    /**
     * Constant for value 'Dispatched'
     * @return string 'Dispatched'
     */
    const VALUE_DISPATCHED = 'Dispatched';
    /**
     * Constant for value 'Cancelled'
     * @return string 'Cancelled'
     */
    const VALUE_CANCELLED = 'Cancelled';
    /**
     * Return true if value is allowed
     * @uses WsdlEnumOrderStatus::VALUE_NEW
     * @uses WsdlEnumOrderStatus::VALUE_PAYMENT_HOLD
     * @uses WsdlEnumOrderStatus::VALUE_PROCESSING
     * @uses WsdlEnumOrderStatus::VALUE_DISPATCHED
     * @uses WsdlEnumOrderStatus::VALUE_CANCELLED
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(WsdlEnumOrderStatus::VALUE_NEW,WsdlEnumOrderStatus::VALUE_PAYMENT_HOLD,WsdlEnumOrderStatus::VALUE_PROCESSING,WsdlEnumOrderStatus::VALUE_DISPATCHED,WsdlEnumOrderStatus::VALUE_CANCELLED));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
