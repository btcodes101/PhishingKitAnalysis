<?php
/**
 * File for class WsdlStructOrderCostSummary
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructOrderCostSummary originally named OrderCostSummary
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructOrderCostSummary extends WsdlWsdlClass
{
    /**
     * The OrderTotalExVat
     * @var WsdlStructAmount
     */
    public $OrderTotalExVat;
    /**
     * The Discount
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructAmount
     */
    public $Discount;
    /**
     * The Vat
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructAmount
     */
    public $Vat;
    /**
     * The OrderTotal
     * @var WsdlStructAmount
     */
    public $OrderTotal;
    /**
     * The AccountCreditUsed
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructAmount
     */
    public $AccountCreditUsed;
    /**
     * The PaymentRequired
     * Meta informations extracted from the WSDL
     * - minOccurs : 0
     * @var WsdlStructAmount
     */
    public $PaymentRequired;
    /**
     * Constructor method for OrderCostSummary
     * @see parent::__construct()
     * @param WsdlStructAmount $_orderTotalExVat
     * @param WsdlStructAmount $_discount
     * @param WsdlStructAmount $_vat
     * @param WsdlStructAmount $_orderTotal
     * @param WsdlStructAmount $_accountCreditUsed
     * @param WsdlStructAmount $_paymentRequired
     * @return WsdlStructOrderCostSummary
     */
    public function __construct($_orderTotalExVat = NULL,$_discount = NULL,$_vat = NULL,$_orderTotal = NULL,$_accountCreditUsed = NULL,$_paymentRequired = NULL)
    {
        parent::__construct(array('OrderTotalExVat'=>$_orderTotalExVat,'Discount'=>$_discount,'Vat'=>$_vat,'OrderTotal'=>$_orderTotal,'AccountCreditUsed'=>$_accountCreditUsed,'PaymentRequired'=>$_paymentRequired),false);
    }
    /**
     * Get OrderTotalExVat value
     * @return WsdlStructAmount|null
     */
    public function getOrderTotalExVat()
    {
        return $this->OrderTotalExVat;
    }
    /**
     * Set OrderTotalExVat value
     * @param WsdlStructAmount $_orderTotalExVat the OrderTotalExVat
     * @return WsdlStructAmount
     */
    public function setOrderTotalExVat($_orderTotalExVat)
    {
        return ($this->OrderTotalExVat = $_orderTotalExVat);
    }
    /**
     * Get Discount value
     * @return WsdlStructAmount|null
     */
    public function getDiscount()
    {
        return $this->Discount;
    }
    /**
     * Set Discount value
     * @param WsdlStructAmount $_discount the Discount
     * @return WsdlStructAmount
     */
    public function setDiscount($_discount)
    {
        return ($this->Discount = $_discount);
    }
    /**
     * Get Vat value
     * @return WsdlStructAmount|null
     */
    public function getVat()
    {
        return $this->Vat;
    }
    /**
     * Set Vat value
     * @param WsdlStructAmount $_vat the Vat
     * @return WsdlStructAmount
     */
    public function setVat($_vat)
    {
        return ($this->Vat = $_vat);
    }
    /**
     * Get OrderTotal value
     * @return WsdlStructAmount|null
     */
    public function getOrderTotal()
    {
        return $this->OrderTotal;
    }
    /**
     * Set OrderTotal value
     * @param WsdlStructAmount $_orderTotal the OrderTotal
     * @return WsdlStructAmount
     */
    public function setOrderTotal($_orderTotal)
    {
        return ($this->OrderTotal = $_orderTotal);
    }
    /**
     * Get AccountCreditUsed value
     * @return WsdlStructAmount|null
     */
    public function getAccountCreditUsed()
    {
        return $this->AccountCreditUsed;
    }
    /**
     * Set AccountCreditUsed value
     * @param WsdlStructAmount $_accountCreditUsed the AccountCreditUsed
     * @return WsdlStructAmount
     */
    public function setAccountCreditUsed($_accountCreditUsed)
    {
        return ($this->AccountCreditUsed = $_accountCreditUsed);
    }
    /**
     * Get PaymentRequired value
     * @return WsdlStructAmount|null
     */
    public function getPaymentRequired()
    {
        return $this->PaymentRequired;
    }
    /**
     * Set PaymentRequired value
     * @param WsdlStructAmount $_paymentRequired the PaymentRequired
     * @return WsdlStructAmount
     */
    public function setPaymentRequired($_paymentRequired)
    {
        return ($this->PaymentRequired = $_paymentRequired);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructOrderCostSummary
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
