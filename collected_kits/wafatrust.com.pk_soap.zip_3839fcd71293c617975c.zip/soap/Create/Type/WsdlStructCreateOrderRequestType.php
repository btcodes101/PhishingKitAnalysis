<?php
/**
 * File for class WsdlStructCreateOrderRequestType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructCreateOrderRequestType originally named CreateOrderRequestType
 * Documentation : The create order request.
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructCreateOrderRequestType extends WsdlStructAbstractRequestType
{
    /**
     * The Type
     * Meta informations extracted from the WSDL
     * - documentation : The order type.
     * @var WsdlEnumOrderType
     */
    public $Type;
    /**
     * The YourOrderReference
     * Meta informations extracted from the WSDL
     * - documentation : The customers order reference number.
     * - minOccurs : 0
     * @var string
     */
    public $YourOrderReference;
    /**
     * Constructor method for CreateOrderRequestType
     * @see parent::__construct()
     * @param WsdlEnumOrderType $_type
     * @param string $_yourOrderReference
     * @return WsdlStructCreateOrderRequestType
     */
    public function __construct($_type = NULL,$_yourOrderReference = NULL)
    {
        WsdlWsdlClass::__construct(array('Type'=>$_type,'YourOrderReference'=>$_yourOrderReference),false);
    }
    /**
     * Get Type value
     * @return WsdlEnumOrderType|null
     */
    public function getType()
    {
        return $this->Type;
    }
    /**
     * Set Type value
     * @uses WsdlEnumOrderType::valueIsValid()
     * @param WsdlEnumOrderType $_type the Type
     * @return WsdlEnumOrderType
     */
    public function setType($_type)
    {
        if(!WsdlEnumOrderType::valueIsValid($_type))
        {
            return false;
        }
        return ($this->Type = $_type);
    }
    /**
     * Get YourOrderReference value
     * @return string|null
     */
    public function getYourOrderReference()
    {
        return $this->YourOrderReference;
    }
    /**
     * Set YourOrderReference value
     * @param string $_yourOrderReference the YourOrderReference
     * @return string
     */
    public function setYourOrderReference($_yourOrderReference)
    {
        return ($this->YourOrderReference = $_yourOrderReference);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructCreateOrderRequestType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
