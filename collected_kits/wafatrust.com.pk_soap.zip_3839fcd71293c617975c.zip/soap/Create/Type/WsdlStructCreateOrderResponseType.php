<?php
/**
 * File for class WsdlStructCreateOrderResponseType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructCreateOrderResponseType originally named CreateOrderResponseType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructCreateOrderResponseType extends WsdlStructAbstractResponseType
{
    /**
     * The OrderReference
     * Meta informations extracted from the WSDL
     * - documentation : A reference number for the created order.
     * @var int
     */
    public $OrderReference;
    /**
     * The YourOrderReference
     * Meta informations extracted from the WSDL
     * - documentation : The customers reference number for the created order. This matches the value set in the CreateOrder request.
     * - minOccurs : 0
     * @var string
     */
    public $YourOrderReference;
    /**
     * Constructor method for CreateOrderResponseType
     * @see parent::__construct()
     * @param int $_orderReference
     * @param string $_yourOrderReference
     * @return WsdlStructCreateOrderResponseType
     */
    public function __construct($_orderReference = NULL,$_yourOrderReference = NULL)
    {
        WsdlWsdlClass::__construct(array('OrderReference'=>$_orderReference,'YourOrderReference'=>$_yourOrderReference),false);
    }
    /**
     * Get OrderReference value
     * @return int|null
     */
    public function getOrderReference()
    {
        return $this->OrderReference;
    }
    /**
     * Set OrderReference value
     * @param int $_orderReference the OrderReference
     * @return int
     */
    public function setOrderReference($_orderReference)
    {
        return ($this->OrderReference = $_orderReference);
    }
    /**
     * Get YourOrderReference value
     * @return string|null
     */
    public function getYourOrderReference()
    {
        return $this->YourOrderReference;
    }
    /**
     * Set YourOrderReference value
     * @param string $_yourOrderReference the YourOrderReference
     * @return string
     */
    public function setYourOrderReference($_yourOrderReference)
    {
        return ($this->YourOrderReference = $_yourOrderReference);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructCreateOrderResponseType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
