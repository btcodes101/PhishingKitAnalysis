<?php
/**
 * File for class WsdlServiceCreate
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlServiceCreate originally named Create
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlServiceCreate extends WsdlWsdlClass
{
    /**
     * Sets the AuthHeader SoapHeader param
     * @uses WsdlWsdlClass::setSoapHeader()
     * @param WsdlStructAuthHeader $_wsdlStructAuthHeader
     * @param string $_nameSpace http://www.beautyfort.com/api/
     * @param bool $_mustUnderstand
     * @param string $_actor
     * @return bool true|false
     */
    public function setSoapHeaderAuthHeader(WsdlStructAuthHeader $_wsdlStructAuthHeader,$_nameSpace = 'http://www.beautyfort.com/api/',$_mustUnderstand = false,$_actor = null)
    {
        return $this->setSoapHeader($_nameSpace,'AuthHeader',$_wsdlStructAuthHeader,$_mustUnderstand,$_actor);
    }
    /**
     * Method to call the operation originally named CreateOrder
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructCreateOrderRequestType $_wsdlStructCreateOrderRequestType
     * @return WsdlStructCreateOrderResponseType
     */
    public function CreateOrder(WsdlStructCreateOrderRequestType $_wsdlStructCreateOrderRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->CreateOrder($_wsdlStructCreateOrderRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Returns the result
     * @see WsdlWsdlClass::getResult()
     * @return WsdlStructCreateOrderResponseType
     */
    public function getResult()
    {
        return parent::getResult();
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
