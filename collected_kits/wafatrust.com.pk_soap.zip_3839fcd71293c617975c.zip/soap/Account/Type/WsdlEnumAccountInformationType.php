<?php
/**
 * File for class WsdlEnumAccountInformationType
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlEnumAccountInformationType originally named AccountInformationType
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlEnumAccountInformationType extends WsdlWsdlClass
{
    /**
     * Constant for value 'DeliveryOptions'
     * Meta informations extracted from the WSDL
     * - documentation : The DeliveryOptions account information type.
     * @return string 'DeliveryOptions'
     */
    const VALUE_DELIVERYOPTIONS = 'DeliveryOptions';
    /**
     * Constant for value 'PictureFees'
     * Meta informations extracted from the WSDL
     * - documentation : The PictureFees account information type.
     * @return string 'PictureFees'
     */
    const VALUE_PICTUREFEES = 'PictureFees';
    /**
     * Constant for value 'BreakBulkFees'
     * Meta informations extracted from the WSDL
     * - documentation : The BreakBulkFees account information type.
     * @return string 'BreakBulkFees'
     */
    const VALUE_BREAKBULKFEES = 'BreakBulkFees';
    /**
     * Constant for value 'DirectDispatchFees'
     * Meta informations extracted from the WSDL
     * - documentation : The DirectDispatchFees account information type.
     * @return string 'DirectDispatchFees'
     */
    const VALUE_DIRECTDISPATCHFEES = 'DirectDispatchFees';
    /**
     * Constant for value 'MaximumViewableStockLevel'
     * Meta informations extracted from the WSDL
     * - documentation : The MaximumViewableStockLevel account information type.
     * @return string 'MaximumViewableStockLevel'
     */
    const VALUE_MAXIMUMVIEWABLESTOCKLEVEL = 'MaximumViewableStockLevel';
    /**
     * Constant for value 'Categories'
     * Meta informations extracted from the WSDL
     * - documentation : The Categories account information type.
     * @return string 'Categories'
     */
    const VALUE_CATEGORIES = 'Categories';
    /**
     * Constant for value 'Brands'
     * Meta informations extracted from the WSDL
     * - documentation : The Brands account information type.
     * @return string 'Brands'
     */
    const VALUE_BRANDS = 'Brands';
    /**
     * Constant for value 'ProductTypes'
     * Meta informations extracted from the WSDL
     * - documentation : The ProductTypes account information type.
     * @return string 'ProductTypes'
     */
    const VALUE_PRODUCTTYPES = 'ProductTypes';
    /**
     * Constant for value 'Genders'
     * Meta informations extracted from the WSDL
     * - documentation : The Genders account information type.
     * @return string 'Genders'
     */
    const VALUE_GENDERS = 'Genders';
    /**
     * Return true if value is allowed
     * @uses WsdlEnumAccountInformationType::VALUE_DELIVERYOPTIONS
     * @uses WsdlEnumAccountInformationType::VALUE_PICTUREFEES
     * @uses WsdlEnumAccountInformationType::VALUE_BREAKBULKFEES
     * @uses WsdlEnumAccountInformationType::VALUE_DIRECTDISPATCHFEES
     * @uses WsdlEnumAccountInformationType::VALUE_MAXIMUMVIEWABLESTOCKLEVEL
     * @uses WsdlEnumAccountInformationType::VALUE_CATEGORIES
     * @uses WsdlEnumAccountInformationType::VALUE_BRANDS
     * @uses WsdlEnumAccountInformationType::VALUE_PRODUCTTYPES
     * @uses WsdlEnumAccountInformationType::VALUE_GENDERS
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(WsdlEnumAccountInformationType::VALUE_DELIVERYOPTIONS,WsdlEnumAccountInformationType::VALUE_PICTUREFEES,WsdlEnumAccountInformationType::VALUE_BREAKBULKFEES,WsdlEnumAccountInformationType::VALUE_DIRECTDISPATCHFEES,WsdlEnumAccountInformationType::VALUE_MAXIMUMVIEWABLESTOCKLEVEL,WsdlEnumAccountInformationType::VALUE_CATEGORIES,WsdlEnumAccountInformationType::VALUE_BRANDS,WsdlEnumAccountInformationType::VALUE_PRODUCTTYPES,WsdlEnumAccountInformationType::VALUE_GENDERS));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
