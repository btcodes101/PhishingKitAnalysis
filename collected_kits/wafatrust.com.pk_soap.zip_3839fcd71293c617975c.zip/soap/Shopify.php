<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Shopify
 *
 * @author adeelislam
 */

class Shopify {

    //put your code here


    public function findCollection($collections, $title) {

        $found = false;
        foreach ($collections as $collection) {
            if ($collection['title'] == $title) {
                $found = $collection['id'];
                break;
            } else {
                $found = false;
            }
        }
        return $found;
    }

    public function findProduct($products, $stockCode) {
        $found = false;
        foreach ($products as $product) {
            if ($product["variants"][0]["sku"] == $stockCode) {
                $found = $product['id'];
                break;
            } else {
                $found = false;
            }
        }
        return $found;
    }

    function getCollections($collectionUrl) {

        try {
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $collectionUrl);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_VERBOSE, 0);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($curl);
            curl_close($curl);
            return $response;
        } catch (Exception $e) {
            throw new Exception("Invalid URL", 0, $e);
        }
    }

    function getAllProducts($productUrl) {
        try {
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $productUrl);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_VERBOSE, 0);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($curl);
            curl_close($curl);
            return $response;
        } catch (Exception $ex) {
            throw new Exception("Invalid URL", 0, $ex);
        }
    }

    function getFeeds($url) {
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_VERBOSE, 0);
            curl_setopt($ch, CURLOPT_USERPWD, $GLOBALS['APIKEY'] . ":" . $GLOBALS['APISECRET']);
            $output = curl_exec($ch);
            curl_close($ch);
            return $output;
        } catch (Exception $ex) {
            throw new Exception("Invalid URL", 0, $ex);
        }
    }

    function createCollection($collectioUrl, $collection) {

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $collectioUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($collection));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function saveProductImage($urlImage, $images) {

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $urlImage);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 1);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($images));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
    }

    function assignProductCollection($collectionAssignUrl, $productCollection) {


        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $collectionAssignUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($productCollection));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function createProduct($productUrl, $product) {

        $productPrice = (array) $product['UnitPrice'];
        $products_array = array(
            "product" => array(
                'title' => $product['Name'],
                "metafields_global_title_tag" => $product['Name'],
                "metafields_global_description_tag" => $product['Name'],
                "body_html" => $product['Name'],
                "published" => true,
                "variants" => array(
                    array(
                        "sku" => $product['StockCode'],
                        "inventory_quantity" => $product['QuantityAvailable'],
                        "price" => $productPrice["Amount"]
                    )
                ),
                "images" => array(
                    array(
                        "src" => $product['HighResImageUrl'],
                    )
                )
            )
        );
        
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $productUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($products_array));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);

        return $response;
    }

    function updateProduct($productUrl, $product, $productId) {

        //exit($product);
        $classes = $product['classes']['primary'];
        $tags = '';
        foreach ($classes as $key => $value) {
            if ($key != "id") {
                $tags .= $value . ",";
            }
        }

        $tags = rtrim($tags, ",");
        $products_array = array(
            "product" => array(
                "id" => $productId,
                'title' => $product['invoiceLine'],
                "product_type" => $product['inventoryType'],
                "metafields_global_title_tag" => $product['invoiceLine'],
                "metafields_global_description_tag" => $product['lineItemDescription'],
                "body_html" => $product['description'],
                "vendor" => $product['brand']['name'],
                "published" => true,
                "tags" => $tags,
                "variants" => array(
                    array(
                        "sku" => $product['stockCode'],
                        "price" => $product['price'],
                        "inventory_quantity" => "150",
                        "weight" => $product['weight']
                    )
                ),
                "images" => array(
                    array(
                        "src" => $product['imageURL'],
                    )
                )
            )
        );

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $productUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($products_array));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
        //echo $response;
        return $response;
    }

}
