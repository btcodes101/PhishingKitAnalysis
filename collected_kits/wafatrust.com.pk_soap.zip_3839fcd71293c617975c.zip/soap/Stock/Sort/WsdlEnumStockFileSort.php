<?php
/**
 * File for class WsdlEnumStockFileSort
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlEnumStockFileSort originally named StockFileSort
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlEnumStockFileSort extends WsdlWsdlClass
{
    /**
     * Constant for value 'StockCode'
     * @return string 'StockCode'
     */
    const VALUE_STOCKCODE = 'StockCode';
    /**
     * Constant for value 'Category'
     * @return string 'Category'
     */
    const VALUE_CATEGORY = 'Category';
    /**
     * Constant for value 'Brand'
     * @return string 'Brand'
     */
    const VALUE_BRAND = 'Brand';
    /**
     * Constant for value 'StockLevel'
     * @return string 'StockLevel'
     */
    const VALUE_STOCKLEVEL = 'StockLevel';
    /**
     * Constant for value 'Price'
     * @return string 'Price'
     */
    const VALUE_PRICE = 'Price';
    /**
     * Constant for value 'FullName'
     * @return string 'FullName'
     */
    const VALUE_FULLNAME = 'FullName';
    /**
     * Return true if value is allowed
     * @uses WsdlEnumStockFileSort::VALUE_STOCKCODE
     * @uses WsdlEnumStockFileSort::VALUE_CATEGORY
     * @uses WsdlEnumStockFileSort::VALUE_BRAND
     * @uses WsdlEnumStockFileSort::VALUE_STOCKLEVEL
     * @uses WsdlEnumStockFileSort::VALUE_PRICE
     * @uses WsdlEnumStockFileSort::VALUE_FULLNAME
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(WsdlEnumStockFileSort::VALUE_STOCKCODE,WsdlEnumStockFileSort::VALUE_CATEGORY,WsdlEnumStockFileSort::VALUE_BRAND,WsdlEnumStockFileSort::VALUE_STOCKLEVEL,WsdlEnumStockFileSort::VALUE_PRICE,WsdlEnumStockFileSort::VALUE_FULLNAME));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
