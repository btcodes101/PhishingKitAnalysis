<?php
/**
 * File for class WsdlEnumStockFileField
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlEnumStockFileField originally named StockFileField
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlEnumStockFileField extends WsdlWsdlClass
{
    /**
     * Constant for value 'StockCode'
     * Meta informations extracted from the WSDL
     * - documentation : The Beauty Fort stock code for the sku.
     * @return string 'StockCode'
     */
    const VALUE_STOCKCODE = 'StockCode';
    /**
     * Constant for value 'Category'
     * Meta informations extracted from the WSDL
     * - documentation : The category for the sku.
     * @return string 'Category'
     */
    const VALUE_CATEGORY = 'Category';
    /**
     * Constant for value 'Brand'
     * Meta informations extracted from the WSDL
     * - documentation : The brand for the sku.
     * @return string 'Brand'
     */
    const VALUE_BRAND = 'Brand';
    /**
     * Constant for value 'Collection'
     * Meta informations extracted from the WSDL
     * - documentation : The collection for the sku.
     * @return string 'Collection'
     */
    const VALUE_COLLECTION = 'Collection';
    /**
     * Constant for value 'Type'
     * Meta informations extracted from the WSDL
     * - documentation : The product type for the sku.
     * @return string 'Type'
     */
    const VALUE_TYPE = 'Type';
    /**
     * Constant for value 'Description'
     * Meta informations extracted from the WSDL
     * - documentation : The Beauty Fort description for the sku.
     * @return string 'Description'
     */
    const VALUE_DESCRIPTION = 'Description';
    /**
     * Constant for value 'Size'
     * Meta informations extracted from the WSDL
     * - documentation : The size, in ml/g, for the sku.
     * @return string 'Size'
     */
    const VALUE_SIZE = 'Size';
    /**
     * Constant for value 'Gender'
     * Meta informations extracted from the WSDL
     * - documentation : The gender for the sku. This field will contain M for Male, F for Female or U for Unisex.
     * @return string 'Gender'
     */
    const VALUE_GENDER = 'Gender';
    /**
     * Constant for value 'StockLevel'
     * Meta informations extracted from the WSDL
     * - documentation : The available stock level for the sku.
     * @return string 'StockLevel'
     */
    const VALUE_STOCKLEVEL = 'StockLevel';
    /**
     * Constant for value 'Price'
     * Meta informations extracted from the WSDL
     * - documentation : The price for the sku.
     * @return string 'Price'
     */
    const VALUE_PRICE = 'Price';
    /**
     * Constant for value 'Barcode'
     * Meta informations extracted from the WSDL
     * - documentation : The barcode, or barcodes, for the sku. Where there are multiple barcodes for the sku these are comma separated.
     * @return string 'Barcode'
     */
    const VALUE_BARCODE = 'Barcode';
    /**
     * Constant for value 'YourRating'
     * Meta informations extracted from the WSDL
     * - documentation : The customers rating, if any, for the sku. Valid ratings are between 1 and 5.
     * @return string 'YourRating'
     */
    const VALUE_YOURRATING = 'YourRating';
    /**
     * Constant for value 'YourStockCode'
     * Meta informations extracted from the WSDL
     * - documentation : The customers stock code, if any, for the sku.
     * @return string 'YourStockCode'
     */
    const VALUE_YOURSTOCKCODE = 'YourStockCode';
    /**
     * Constant for value 'LastPurchasedDate'
     * Meta informations extracted from the WSDL
     * - documentation : The date the sku was last purchased by the customer.
     * @return string 'LastPurchasedDate'
     */
    const VALUE_LASTPURCHASEDDATE = 'LastPurchasedDate';
    /**
     * Constant for value 'LastPurchasedPrice'
     * Meta informations extracted from the WSDL
     * - documentation : The last price paid by the customer for the sku.
     * @return string 'LastPurchasedPrice'
     */
    const VALUE_LASTPURCHASEDPRICE = 'LastPurchasedPrice';
    /**
     * Constant for value 'ImageLastUpdated'
     * Meta informations extracted from the WSDL
     * - documentation : The date/time the image was last updated for the item.
     * @return string 'ImageLastUpdated'
     */
    const VALUE_IMAGELASTUPDATED = 'ImageLastUpdated';
    /**
     * Constant for value 'ThumbnailImageUrl'
     * Meta informations extracted from the WSDL
     * - documentation : The URL of a thumbnail image for the sku.
     * @return string 'ThumbnailImageUrl'
     */
    const VALUE_THUMBNAILIMAGEURL = 'ThumbnailImageUrl';
    /**
     * Constant for value 'HighResImageUrl'
     * Meta informations extracted from the WSDL
     * - documentation : The URL of a high resolution image for the sku.
     * @return string 'HighResImageUrl'
     */
    const VALUE_HIGHRESIMAGEURL = 'HighResImageUrl';
    /**
     * Constant for value 'FullName'
     * Meta informations extracted from the WSDL
     * - documentation : The Beauty Fort full name for the sku.
     * @return string 'FullName'
     */
    const VALUE_FULLNAME = 'FullName';
    /**
     * Constant for value 'RRP'
     * Meta informations extracted from the WSDL
     * - documentation : The recommended retail price for the sku.
     * @return string 'RRP'
     */
    const VALUE_RRP = 'RRP';
    /**
     * Constant for value 'Quantity'
     * Meta informations extracted from the WSDL
     * - documentation : The quantity of the sku to order. This value will always be returned blank.
     * @return string 'Quantity'
     */
    const VALUE_QUANTITY = 'Quantity';
    /**
     * Constant for value 'BreakBulkReference'
     * Meta informations extracted from the WSDL
     * - documentation : The break bulk reference to apply to the line. This value will always be returned blank.
     * @return string 'BreakBulkReference'
     */
    const VALUE_BREAKBULKREFERENCE = 'BreakBulkReference';
    /**
     * Return true if value is allowed
     * @uses WsdlEnumStockFileField::VALUE_STOCKCODE
     * @uses WsdlEnumStockFileField::VALUE_CATEGORY
     * @uses WsdlEnumStockFileField::VALUE_BRAND
     * @uses WsdlEnumStockFileField::VALUE_COLLECTION
     * @uses WsdlEnumStockFileField::VALUE_TYPE
     * @uses WsdlEnumStockFileField::VALUE_DESCRIPTION
     * @uses WsdlEnumStockFileField::VALUE_SIZE
     * @uses WsdlEnumStockFileField::VALUE_GENDER
     * @uses WsdlEnumStockFileField::VALUE_STOCKLEVEL
     * @uses WsdlEnumStockFileField::VALUE_PRICE
     * @uses WsdlEnumStockFileField::VALUE_BARCODE
     * @uses WsdlEnumStockFileField::VALUE_YOURRATING
     * @uses WsdlEnumStockFileField::VALUE_YOURSTOCKCODE
     * @uses WsdlEnumStockFileField::VALUE_LASTPURCHASEDDATE
     * @uses WsdlEnumStockFileField::VALUE_LASTPURCHASEDPRICE
     * @uses WsdlEnumStockFileField::VALUE_IMAGELASTUPDATED
     * @uses WsdlEnumStockFileField::VALUE_THUMBNAILIMAGEURL
     * @uses WsdlEnumStockFileField::VALUE_HIGHRESIMAGEURL
     * @uses WsdlEnumStockFileField::VALUE_FULLNAME
     * @uses WsdlEnumStockFileField::VALUE_RRP
     * @uses WsdlEnumStockFileField::VALUE_QUANTITY
     * @uses WsdlEnumStockFileField::VALUE_BREAKBULKREFERENCE
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(WsdlEnumStockFileField::VALUE_STOCKCODE,WsdlEnumStockFileField::VALUE_CATEGORY,WsdlEnumStockFileField::VALUE_BRAND,WsdlEnumStockFileField::VALUE_COLLECTION,WsdlEnumStockFileField::VALUE_TYPE,WsdlEnumStockFileField::VALUE_DESCRIPTION,WsdlEnumStockFileField::VALUE_SIZE,WsdlEnumStockFileField::VALUE_GENDER,WsdlEnumStockFileField::VALUE_STOCKLEVEL,WsdlEnumStockFileField::VALUE_PRICE,WsdlEnumStockFileField::VALUE_BARCODE,WsdlEnumStockFileField::VALUE_YOURRATING,WsdlEnumStockFileField::VALUE_YOURSTOCKCODE,WsdlEnumStockFileField::VALUE_LASTPURCHASEDDATE,WsdlEnumStockFileField::VALUE_LASTPURCHASEDPRICE,WsdlEnumStockFileField::VALUE_IMAGELASTUPDATED,WsdlEnumStockFileField::VALUE_THUMBNAILIMAGEURL,WsdlEnumStockFileField::VALUE_HIGHRESIMAGEURL,WsdlEnumStockFileField::VALUE_FULLNAME,WsdlEnumStockFileField::VALUE_RRP,WsdlEnumStockFileField::VALUE_QUANTITY,WsdlEnumStockFileField::VALUE_BREAKBULKREFERENCE));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
