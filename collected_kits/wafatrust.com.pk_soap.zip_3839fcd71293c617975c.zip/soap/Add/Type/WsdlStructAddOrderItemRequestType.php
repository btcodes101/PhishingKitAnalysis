<?php
/**
 * File for class WsdlStructAddOrderItemRequestType
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlStructAddOrderItemRequestType originally named AddOrderItemRequestType
 * Documentation : The add order item request.
 * Meta informations extracted from the WSDL
 * - from schema : {@link http://www.beautyfort.com/api/wsdl/v2/wsdl.wsdl}
 * @package Wsdl
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlStructAddOrderItemRequestType extends WsdlStructAbstractRequestType
{
    /**
     * The OrderReference
     * Meta informations extracted from the WSDL
     * - documentation : The order reference returned by CreateOrder of the order this item should be added to. One of OrderReference and YourOrderReference is required, if both are supplied they must be for the same order.
     * - minOccurs : 0
     * @var int
     */
    public $OrderReference;
    /**
     * The YourOrderReference
     * Meta informations extracted from the WSDL
     * - documentation : The customers reference for the order this item should be added to. One of OrderReference and YourOrderReference is required, if both are supplied they must be for the same order.
     * - minOccurs : 0
     * @var string
     */
    public $YourOrderReference;
    /**
     * The StockCode
     * Meta informations extracted from the WSDL
     * - documentation : The Beauty Fort stock code for the item.
     * @var string
     */
    public $StockCode;
    /**
     * The Quantity
     * Meta informations extracted from the WSDL
     * - documentation : The quantity of the item to be ordered.
     * @var int
     */
    public $Quantity;
    /**
     * Constructor method for AddOrderItemRequestType
     * @see parent::__construct()
     * @param int $_orderReference
     * @param string $_yourOrderReference
     * @param string $_stockCode
     * @param int $_quantity
     * @return WsdlStructAddOrderItemRequestType
     */
    public function __construct($_orderReference = NULL,$_yourOrderReference = NULL,$_stockCode = NULL,$_quantity = NULL)
    {
        WsdlWsdlClass::__construct(array('OrderReference'=>$_orderReference,'YourOrderReference'=>$_yourOrderReference,'StockCode'=>$_stockCode,'Quantity'=>$_quantity),false);
    }
    /**
     * Get OrderReference value
     * @return int|null
     */
    public function getOrderReference()
    {
        return $this->OrderReference;
    }
    /**
     * Set OrderReference value
     * @param int $_orderReference the OrderReference
     * @return int
     */
    public function setOrderReference($_orderReference)
    {
        return ($this->OrderReference = $_orderReference);
    }
    /**
     * Get YourOrderReference value
     * @return string|null
     */
    public function getYourOrderReference()
    {
        return $this->YourOrderReference;
    }
    /**
     * Set YourOrderReference value
     * @param string $_yourOrderReference the YourOrderReference
     * @return string
     */
    public function setYourOrderReference($_yourOrderReference)
    {
        return ($this->YourOrderReference = $_yourOrderReference);
    }
    /**
     * Get StockCode value
     * @return string|null
     */
    public function getStockCode()
    {
        return $this->StockCode;
    }
    /**
     * Set StockCode value
     * @param string $_stockCode the StockCode
     * @return string
     */
    public function setStockCode($_stockCode)
    {
        return ($this->StockCode = $_stockCode);
    }
    /**
     * Get Quantity value
     * @return int|null
     */
    public function getQuantity()
    {
        return $this->Quantity;
    }
    /**
     * Set Quantity value
     * @param int $_quantity the Quantity
     * @return int
     */
    public function setQuantity($_quantity)
    {
        return ($this->Quantity = $_quantity);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see WsdlWsdlClass::__set_state()
     * @uses WsdlWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return WsdlStructAddOrderItemRequestType
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
