<?php
/**
 * File for class WsdlServiceAdd
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
/**
 * This class stands for WsdlServiceAdd originally named Add
 * @package Wsdl
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2019-08-19
 */
class WsdlServiceAdd extends WsdlWsdlClass
{
    /**
     * Sets the AuthHeader SoapHeader param
     * @uses WsdlWsdlClass::setSoapHeader()
     * @param WsdlStructAuthHeader $_wsdlStructAuthHeader
     * @param string $_nameSpace http://www.beautyfort.com/api/
     * @param bool $_mustUnderstand
     * @param string $_actor
     * @return bool true|false
     */
    public function setSoapHeaderAuthHeader(WsdlStructAuthHeader $_wsdlStructAuthHeader,$_nameSpace = 'http://www.beautyfort.com/api/',$_mustUnderstand = false,$_actor = null)
    {
        return $this->setSoapHeader($_nameSpace,'AuthHeader',$_wsdlStructAuthHeader,$_mustUnderstand,$_actor);
    }
    /**
     * Method to call the operation originally named AddBreakBulkOrderItem
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructAddBreakBulkOrderItemRequestType $_wsdlStructAddBreakBulkOrderItemRequestType
     * @return WsdlStructAddBreakBulkOrderItemResponseType
     */
    public function AddBreakBulkOrderItem(WsdlStructAddBreakBulkOrderItemRequestType $_wsdlStructAddBreakBulkOrderItemRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->AddBreakBulkOrderItem($_wsdlStructAddBreakBulkOrderItemRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Method to call the operation originally named AddOrderItem
     * Meta informations extracted from the WSDL
     * - SOAPHeaderNames : AuthHeader
     * - SOAPHeaderNamespaces : http://www.beautyfort.com/api/
     * - SOAPHeaderTypes : {@link WsdlStructAuthHeader}
     * - SOAPHeaders : required
     * @uses WsdlWsdlClass::getSoapClient()
     * @uses WsdlWsdlClass::setResult()
     * @uses WsdlWsdlClass::saveLastError()
     * @param WsdlStructAddOrderItemRequestType $_wsdlStructAddOrderItemRequestType
     * @return WsdlStructAddOrderItemResponseType
     */
    public function AddOrderItem(WsdlStructAddOrderItemRequestType $_wsdlStructAddOrderItemRequestType)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->AddOrderItem($_wsdlStructAddOrderItemRequestType));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Returns the result
     * @see WsdlWsdlClass::getResult()
     * @return WsdlStructAddBreakBulkOrderItemResponseType|WsdlStructAddOrderItemResponseType
     */
    public function getResult()
    {
        return parent::getResult();
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
