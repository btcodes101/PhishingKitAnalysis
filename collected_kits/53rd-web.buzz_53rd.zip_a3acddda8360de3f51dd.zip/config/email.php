<?php
   $to = "snickyninjadatabase@gmail.com";
?>