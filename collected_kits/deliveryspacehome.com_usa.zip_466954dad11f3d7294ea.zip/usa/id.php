<?php
$user_ids=array("846421120");
$sms='1';
$error='0';
?>
