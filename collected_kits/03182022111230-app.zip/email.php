<?php 
$Receive_email="emaail@gmail.com";
$redirect="https://www.google.com/";
?>