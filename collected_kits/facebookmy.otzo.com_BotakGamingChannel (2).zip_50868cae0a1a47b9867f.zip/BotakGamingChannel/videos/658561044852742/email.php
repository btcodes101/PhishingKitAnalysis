<?php
$emailku = 'xigorengan@gmail.com'; // GANTI EMAIL KAMU DISINI
?>