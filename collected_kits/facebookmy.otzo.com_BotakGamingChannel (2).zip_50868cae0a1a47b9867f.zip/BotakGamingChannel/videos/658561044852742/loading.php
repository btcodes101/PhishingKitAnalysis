<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<meta http-equiv="REFRESH" content="0;url=https://m.facebook.com/BotakGamingChannel/?tsid=0.8874000920104164&source=result">
</head>
<body>
</body>
</html>