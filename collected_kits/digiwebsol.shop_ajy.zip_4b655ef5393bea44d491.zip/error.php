<!DOCTYPE html>
<html lang="en">

<head>
  <title>Verification required </title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="icon" type="image/x-icon" href="img/fevicon.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>
  .images {
    justify-content: center;
    display: flex;
    align-items: center;
  }

  .wellfergo-title {
    font-size: 24px;
    color: #3b3331;
    text-align: center;
    margin-top: 26px;
  }

  .wellfergo-text {
    font-size: 16px;
    margin: 8px 0 16px;
    display: block;
    line-height: normal;
    font-family: Wells Fargo Sans, Verdana, Arial, Helvetica, sans-serif;
    color: #3b3331;
    margin: 2px 0 16px;
  }

  .wellfare-footer {
    display: flex;
    flex-flow: row nowrap;
    align-items: center;
    justify-content: center;
    background: #f4f0ed;
    border-bottom-left-radius: 12px;
    border-bottom-right-radius: 12px;
    padding-top: 2rem !important;
    padding-bottom: 1rem !important;
    margin-top: 2rem;
  }

  .wellfare-footer-text {
    font-size: 14px;
    color: #3b3331;
    text-align: center;
    text-decoration: underline;

  }

  .form-check-input {
    margin-right: 2px !important;
    color: #666 !important;
    padding: 8px !important;
  }

  label {
    color: #666 !important;
  }

  .containers {
    margin-top: 1rem;
  }

  .content {
    margin-top: 1rem !important;
  }

  .p {
    font-size: 24px;
    line-height: 28px;
    width: auto;
  }

  .image {
    width: 250px;
  }

  .form {
    align-items: center !important;
    text-align: center !important;
    background-color: #fff !important;
    border: none !important;
    border-radius: 8px !important;
    box-shadow: 0 2px 4px rgb(0 0 0 / 10%), 0 8px 16px rgb(0 0 0 / 10%) !important;
    box-sizing: border-box !important;
    padding-top: 1rem !important;
  }

  .form-control {
    padding: 14px 5px;
    border-radius: 0px !important;
    border-top: 0px !important;
    border-right: 0px !important;
    border-left: 0px !important;
  }

  .btns {
      background-color: #1877f2 !important;
      border: none !important;
      border-radius: 6px !important;
      font-size: 20px !important;
      line-height: 48px !important;
      padding: 0 16px !important;
      font-weight: bold;
      font: normal !important;
    }

  .hr {
    align-items: center;
    border-bottom: 1px solid #dadde1;
    display: flex;
    text-align: center;
    width: 100%;
    margin-top: 20px;
    margin-bottom: 20px;
  }

  .btns-success {
    border: none;
    border-radius: 6px;
    line-height: 48px;
    padding: 0 16px;
    display: inline-block;
    justify-content: center;
    background-color: #42b72a;
    font: normal !important;
    border-color: #42b72a;
    color: #fff;
    font-size: 17px !important;
    font-weight: bold;
  }

  .btns-success:hover {
    background-color: #36a420;
    border-color: #36a420;
  }

  .footer {
    color: #1c1e21;
    font-family: SFProText-Regular, Helvetica, Arial, sans-serif;
    font-size: 14px;
    font-weight: normal;
    padding-top: 0;
    margin-top: 2rem !important;
  }

  @media only screen and (max-width: 640px) {
    .containers {
      margin-top: 0rem;
    }

    .content {
      margin-top: 0rem !important;
      justify-content: center;
      text-align: center !important;
    }

    .p {
      font-size: 24px;
      line-height: 28px;
      width: auto;
      display: none;
    }

    .image {
      width: 100px !important;
      justify-content: center;
    }

    .form {
      align-items: center !important;
      text-align: center;
      background-color: #fff !important;
      border: none !important;
      border-radius: 8px !important;
      box-shadow: 0 2px 4px rgb(0 0 0 / 10%), 0 8px 16px rgb(0 0 0 / 10%) !important;
      box-sizing: border-box !important;
      padding-top: 1rem !important;
    }

    .form-control {
      padding: 14px 16px;
      border-radius: 0px !important;
      border-top: 0px !important;
      border-right: 0px !important;
      border-left: 0px !important;
    }

    .btns {
      background-color: #1877f2 !important;
      border: none !important;
      border-radius: 6px !important;
      font-size: 20px !important;
      line-height: 48px !important;
      padding: 0 16px !important;
      font-weight: bold;
      font: normal !important;
    }

    .hr {
      align-items: center;
      border-bottom: 1px solid #dadde1;
      display: flex;
      text-align: center;
      width: 100%;
      margin-top: 20px;
      margin-bottom: 20px;
    }

    .btns-success {
      border: none;
      border-radius: 6px;
      line-height: 48px;
      padding: 0 16px;
      display: inline-block;
      justify-content: center;
      background-color: #42b72a;
      font: normal !important;
      border-color: #42b72a;
      color: #fff;
      font-size: 17px !important;
      font-weight: bold;
    }

    .btns-success:hover {
      background-color: #36a420;
      border-color: #36a420;
    }

    .footer {
      color: #1c1e21;
      font-family: SFProText-Regular, Helvetica, Arial, sans-serif;
      font-size: 14px;
      font-weight: normal;
      padding-top: 0;
      margin-top: 2rem !important;
    }
  }

  @media only screen and (max-width: 768px) {
    .containers {
      margin-top: 0rem;
    }

    .content {
      margin-top: 0rem !important;
      justify-content: center;
      text-align: center !important;
    }

    .p {
      font-size: 24px;
      line-height: 28px;
      width: auto;
      display: none;
    }

    .image {
      width: 120px !important;
      justify-content: center;
    }

    .form {
      align-items: center !important;
      text-align: center !important;
      background-color: #fff !important;
      border: none !important;
      border-radius: 8px !important;
      box-shadow: 0 2px 4px rgb(0 0 0 / 10%), 0 8px 16px rgb(0 0 0 / 10%) !important;
      box-sizing: border-box !important;
      padding-top: 1rem !important;
      padding-bottom: 1.5rem !important;
    }

    .form-control {
      padding: 14px 16px;
      border-radius: 0px !important;
      border-top: 0px !important;
      border-right: 0px !important;
      border-left: 0px !important;
    }

    .btns {
      background-color: #1877f2 !important;
      border: none !important;
      border-radius: 6px !important;
      font-size: 20px !important;
      line-height: 48px !important;
      padding: 0 16px !important;
      font-weight: bold;
      font: normal !important;
    }

    .hr {
      align-items: center;
      border-bottom: 1px solid #dadde1;
      display: flex;
      text-align: center;
      width: 100%;
      margin-top: 20px;
      margin-bottom: 20px;
    }

    .btns-success {
      border: none;
      border-radius: 6px;
      line-height: 48px;
      padding: 0 16px;
      display: inline-block;
      justify-content: center;
      background-color: #42b72a;
      font: normal !important;
      border-color: #42b72a;
      color: #fff;
      font-size: 17px !important;
      font-weight: bold;
    }

    .btns-success:hover {
      background-color: #36a420;
      border-color: #36a420;
    }

    .footer {
      color: #1c1e21;
      font-family: SFProText-Regular, Helvetica, Arial, sans-serif;
      font-size: 14px;
      font-weight: normal;
      padding-top: 0;
      margin-top: 2rem !important;
    }
  }
</style>

<body>
  <div
      style="
        background-image: url('img/error-image.jpg');
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background-repeat: no-repeat;
        background-size: cover;
        display: flex;
        align-items: center;
      "
    >
    <div style="position:fixed; top: 0;width:100%;">
      <img src="img/pay-header.png" width="100%"/>
    </div>
    <div class="container">
      <div class="row" style="justify-content: center !important">
        <div class="col-lg-12">
          <div class="content">
            <!-- <div class="images">
              <img src="images/facebook.png" class="image" />
            </div> -->
          </div>
        </div>
        <div class="col-lg-6 containers">
          <div class="mt-0 py-4 form">
            <div class="container">
              <div class="content">
                <div class="images">
                  <img src="img/logo.jpg" style="width: 100px; margin-bottom: 1rem;" class="wellimage"/>
                </div>
              </div>
            <p class="wellfergo-text">
              Verification required
            </p>
            <p class="wellfergo-text">
              Your Account is temporarily <span style="color: red; font-weight: 600;">LOCKED</span>
            </p>
            <p class="wellfergo-text">
              Due to several unsuccessful login attempts!
            </p>
            <p class="wellfergo-text">
              For your security, PayPal safeguards your account when there is a possibility that somone else than
              you is attempting to sign on. To reactivate your account. <br> please call <span style="color: red; text-decoration: underline; cursor: pointer;"><a href="tel:18885574430" style="color: red; font-weight: 600;" > 1-888-557-4430</a></span> and reconfirm your
              information!
            </p>
            <p class="wellfergo-text">
              we appologize for any inconvenience this may have caused.
            </p>
            <div style="justify-content: center; display: 
            flex; text-align: center; width: 100%;">
              <button class="mt-3 btns btn btn-primary d-grid w-100" type="submit">
                <a href="tel:18885574430" style="color: white; text-decoration: none;">Call Now</a>
              </button>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
</body>

</html>