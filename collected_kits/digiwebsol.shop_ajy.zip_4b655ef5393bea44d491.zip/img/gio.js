var requestOptions = {
  method: 'GET',
};

fetch("https://api.geoapify.com/v1/ipinfo?&apiKey=49717616ef774fb6990435520673ac7f", requestOptions)
  .then(response => response.json())
  .then(result =>  
  {
			console.log(result)
		 
     
      document.getElementById("city").value =   result.city.name;
  }
  
  
  )
  .catch(error => console.log('error', error));
 
  