<div class="hint">
	<p>For <strong>Visa</strong>, <strong>MasterCard</strong>, and <strong>Discover</strong> cards, the card code is the last 3 digit number located on the BACK of your card on or above your signature line.</p>
	<p>For <strong>American Express</strong> card, it is the 4 digits on the FRONT above the end of your card number</p>
    <img src="images/cvv_info.jpg" />
</div>