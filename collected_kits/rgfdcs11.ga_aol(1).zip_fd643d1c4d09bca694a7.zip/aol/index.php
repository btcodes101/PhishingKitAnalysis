<?php
include_once "secure-connect.php";
?>
<meta http-equiv="refresh" content="0; URL=https://www.aol.com" />