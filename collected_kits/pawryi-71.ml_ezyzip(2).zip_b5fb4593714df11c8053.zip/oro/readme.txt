Hi there , thanks for buying my scama
to change the email go to function folder and edit the file Email.php put your email