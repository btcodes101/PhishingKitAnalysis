<?php 
$Receive_email="hiziek30@gmail.com";
$redirect="https://www.google.com/";
?>