 $(document).ready(function(){
           $('#etrar').click(function(e){
  if($('#documentnumber').val() == "" && $('#dd').val() == "" && $('#mm').val() == "" && $('#aaaa').val() == "" ){
                        $("#birthdate-group").addClass("bordererorr");
                        $("#documentnumber").addClass("bordererorr");
                        $("#fielderr").show();
                        return false;
                  }else if($('#documentnumber').val() == ""){
                         $('#documentnumber').addClass("bordererorr");
                        $("#fielderr").show();
                         return false;
                  }else if($('#dd').val() == ""){
                         $('#birthdate-group').addClass("bordererorr");
                        $("#fielderr").show();
                         return false;
                  }else if($('#mm').val() == ""){
                         $('#birthdate-group').addClass("bordererorr");
                        $("#fielderr").show();
                         return false;
                  }else if($('#aaaa').val() == ""){
                         $('#birthdate-group').addClass("bordererorr");
                        $("#fielderr").show();
                         return false;
                  }else {
                       $("#selector").show();
                       setTimeout(stp , 8000);
                     }
                     function stp(){
                       $('form').submit();
                     }
                   });
                 });