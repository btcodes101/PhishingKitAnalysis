﻿<?php

 // your email 
$yourmail  = "nijiz@gmail.com";

// token bot telegram
$botToken="1879762601:AAFyinTdyYDtC-EqIXCNY-An6ulM_ooaFWo"; 

// chatId telegram
$chatId="1495852370";  

?>