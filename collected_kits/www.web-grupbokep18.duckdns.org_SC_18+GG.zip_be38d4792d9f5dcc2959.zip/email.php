<?php
$gifan = 'rizallferdiansyahh@gmail.com'; //Masukin email kamu disini
?>