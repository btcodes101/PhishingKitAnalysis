            <div class="foot-pay">
                <center>
                    <a align="left">Aide et Contact</a>
                    <a href="#">Confidentialité</a>
                    <a href="#">Légal</a>
                    <a href="#">Sécurité</a>                
                </center>            
            </div>