﻿// JScript File
function openhelp()
{
    var url = 'http://help.elliemae.com/loancenter/1.0/webhelp.html';
    var height = 644;
    var width = 1293;
    var left = (screen.width - width) / 2;
    var top = (screen.height - height) / 2;
    oHelp = window.open(url,'Help','width=' + width + ',height=' + height + ',left=' + left + ',top=' + top + ',toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');
    oHelp.focus();
}

 
function openwebcenterhelp()
{
    var url = 'http://help.elliemae.com/webcenter/borrower/1.0/webhelp.html';
    var height = 644;
    var width = 1293;
    var left = (screen.width - width) / 2;
    var top = (screen.height - height) / 2;
    oHelp = window.open(url,'Help','width=' + width + ',height=' + height + ',left=' + left + ',top=' + top + ',toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');
    oHelp.focus();
}

function openhelppage(url)
{    
    var height = 644;
    var width = 1293;
    var left = (screen.width - width) / 2;
    var top = (screen.height - height) / 2;
    oHelp = window.open(url,'Help','width=' + width + ',height=' + height + ',left=' + left + ',top=' + top + ',toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');
    oHelp.focus();
}

 