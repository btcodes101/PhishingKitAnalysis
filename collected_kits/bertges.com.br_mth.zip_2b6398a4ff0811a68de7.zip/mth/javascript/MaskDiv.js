﻿function initMaskDivStyle(mask)
{
    initMaskDivStyle(mask, 10);
}
function initMaskDivStyle(mask, zIndex)
{
    if (null != mask)
    {
        mask.style.width = "100%";
        mask.style.height = "100%";
        mask.style.top = "0px";
        mask.style.left = "0px";
        mask.style.backgroundColor = "#000000";
        mask.style.zIndex = zIndex.toString();
        mask.style.filter = "alpha(opacity=40)";
        mask.style.opacity = "0.4";
        mask.style.color = "#fff";
        //mask.style.display = "none";
    }
}

function showMask()
{
    showMask("maskDiv", null, -1)
}
function showMask(id, text, zIndex)
{
    if (!id) id = "maskDiv";
    hideMask(id);
    text = !text ? "" : text.toLowerCase();
    if (!zIndex || zIndex < 0) zIndex = 10;
    var mask = document.createElement("div");
    mask.setAttribute("id", id);
    initMaskDivStyle(mask, zIndex);
    if (text != "")
    {
        var html = "<table width='100%' height='100%'><tr><td align='center' vAlign='middle'>";
        if (text == "saving" || text == "uploading")
        {
            mask.className = "uploading";
        }
        else
        {
            html += text;
        }
        html += "</td></tr></table>";
        mask.innerHTML = html;
    }
    document.body.appendChild(mask);
    mask.style.display = "block";
    if(IsIE6())
    {
        mask.style.position = "absolute";
        initMask();
        hideSelect();
    }
    else
    {
        mask.style.position = "fixed";
    }
}

function hideMask()
{
    hideMask("maskDiv");
}
function hideMask(id)
{
    if (!id) id = "maskDiv";
    var mask = document.getElementById(id);
    if(mask)
    {
        mask.parentNode.removeChild(mask);
        if(IsIE6())
        {
            showselect();
        }
    }
}

function initMask(){
    var dde = document.documentElement;
    var ww = dde.offsetWidth;
    var wh = dde.offsetHeight;
    var bgX = dde.scrollWidth;
    var bgY = dde.scrollHeight;

    var mask = document.getElementById("maskDiv");
    mask.style.width = bgX + "px";
    mask.style.height = bgY + "px";
    
}

function showselect()
{
    var selects = document.getElementsByTagName("SELECT");
    for(i=0;i< selects.length;i++)
    {
        if(selects[i].getAttribute("removedByDialog") == "1")
        {
            selects[i].style.visibility = "visible";
        }
        selects[i].removeAttribute("removedByDialog");
    }
}

function hideSelect()
{

    var selects = document.getElementsByTagName("SELECT");
    for(i=0;i< selects.length;i++)
    {
        if(selects[i].getAttribute("removeByMask") != "0")
        {
            selects[i].style.visibility = "hidden";
            selects[i].setAttribute("removedByDialog","1");
        }
    }
}
