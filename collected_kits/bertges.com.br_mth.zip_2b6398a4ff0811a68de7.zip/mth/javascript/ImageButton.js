﻿// JScript File

// function imageButton_OnMouseEnter(which)
//    {
//        which.src = which.src.replace(".gif","_ovr.gif");
//    }

//    function imageButton_OnMouseOut(which)
//    {
//        which.src = which.src.replace("_ovr.gif",".gif");
//    }