﻿// JScript File

function $(elementID) {
    return document.getElementById(elementID);
}

function pageInit() {
    setNavigationCurrentPage();
}

function openSecurityStatement() {
    var dialogFeatures = "";
    dialogFeatures += "height=600px,";
    dialogFeatures += "width=600px,";
    dialogFeatures += "toolbar=no,";
    dialogFeatures += "scrollbars=yes,";

    var dialogUrl = "https://www.mortgage-application.net/SecurityStatement.aspx";
    if (typeof(enableExternalLinkSecurityPopUp) == "undefined" || !enableExternalLinkSecurityPopUp || confirm(externalSitesLinkPopupMessage))
        window.open(dialogUrl, null, dialogFeatures);
}

function LTrim(str) {
    var whitespace = new String(" \t\n\r");
    var s = new String(str);

    if (whitespace.indexOf(s.charAt(0)) != -1) {
        var j = 0, i = s.length;
        while (j < i && whitespace.indexOf(s.charAt(j)) != -1) {
            j++;
        }
        s = s.substring(j, i);
    }
    return s;
}

function RTrim(str) {
    var whitespace = new String(" \t\n\r");
    var s = new String(str);

    if (whitespace.indexOf(s.charAt(s.length - 1)) != -1) {
        var i = s.length - 1;
        while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1) {
            i--;
        }
        s = s.substring(0, i + 1);
    }
    return s;
}

function Trim(str) {
    return RTrim(LTrim(str));
}

function $(elementID) {
    if (elementID != null && elementID.length > 0) {
        return document.getElementById(elementID);
    }
    else { return null; }
}


function checkNum(who) {
    if (who.value.length == 0) {
        return true;
    }
    if (isNaN(who.value)) {
        alert("The field format is incorrect.");
        who.focus();
        who.select();
        return false;
    }
    return true;
}

function checkNumWithoutAlert(el) {
    var val = el.trim();
    if (val.length == 0) return false;
    var n = (val + ".").indexOf(".");
    var str = val.substring(0, n).replace(/,/g, "");
    var number = str;
    if (n < val.length) number += val.substr(n);
    if (!number.length == 0 && isNaN(number)) {
        return false;
    }

    return true;
}

function checkNumEnter(who) {
    if (who.value.length == 0) {
        return true;
    }
    if (isNaN(who.value)) {
        document.body.focus();
        who.focus();
        who.select();
        return false;
    }
    return true;
}

function checkInt(who) {
    if (who.value.length == 0) {
        return true;
    }
    var numeric = /^\d*$/
    if (!numeric.test(who.value)) {
        alert("The field format is incorrect.");
        who.select();
        return false;
    }
    return true;
}

function checkIntEnter(who) {
    if (who.value.length == 0) {
        return true;
    }
    var numeric = /^\d*$/
    if (!numeric.test(who.value)) {
        document.body.focus();
        who.select();
        return false;
    }
    return true;
}

function checkZip(who) {
    if (who.value.length == 0) {
        return true;
    }
    var numeric = /\d{5}$/
    if (!numeric.test(who.value)) {
        alert("The field format is incorrect.");
        setTimeout("setFoucs(\"" + who.id + "\");", 2);
        return false;
    }
    return true;
}


function checkZipEnter(who) {
    if (who.value.length == 0) {
        return true;
    }
    var numeric = /\d{5}$/
    if (!numeric.test(who.value)) {
        document.body.focus();
        who.focus();
        who.select();
        stopEvent(event);
        return false;
    }
    return true;
}

function checkMail(who) {
    if (who.value.length == 0) {
        return true;
    }
    var email = /(\S)+@(\S)+(\.)(\S)*/;
    if (!email.test(who.value)) {
        alert("The field format is incorrect.");
        who.focus();
        who.select();
        return false;
    }
    return true;
}

function checkMailEnter(who) {
    if (who.value.length == 0) {
        return true;
    }
    var email = /(\S)+@(\S)+(\.)(\S)*/;
    if (!email.test(who.value)) {
        document.body.focus();
        who.focus();
        who.select();
        return false;
    }
    return true;
}

function checkUrl(who) {
    if (who.value.length == 0) {
        return true;
    }
    if (who.value.toLowerCase().indexOf("http://") < 0) {
        alert("The field format is incorrect.");
        who.value = "http://";
        who.focus();
        who.select();
        return false;
    }
    return true;
}

function checkUrlEnter(who) {
    if (who.value.length == 0) {
        return true;
    }
    if (who.value.toLowerCase().indexOf("http://") < 0) {
        document.body.focus();
        who.focus();
        who.select();
        return false;
    }
    return true;
}

function checkMonthYear(who) {
    if (who.value.length == 0) {
        return true;
    }
    var monthYear = /^(0?[1-9]|10|11|12)\/((1[6-9]|[2-9]\d)\d{2})$/;
    if (!monthYear.test(who.value)) {
        alert("The field format is incorrect.");
        who.focus();
        who.select();
        return false;
    }
    return true;
}

function checkMonthYearEnter(who) {
    if (who.value.length == 0) {
        return true;
    }
    var monthYear = /^(0?[1-9]|10|11|12)\/((1[6-9]|[2-9]\d)\d{2})$/;
    if (!monthYear.test(who.value)) {
        document.body.focus();
        who.focus();
        who.select();
        return false;
    }
    return true;
}

function checkMonthDayYear(who) {
    if (who.value.length == 0 || who.value == "//") {
        return true;
    }
    var monthYear = /^\d{2}\/\d{2}\/\d{4}$/;
    if (!monthYear.test(who.value)) {
        alert("The field format is incorrect.");
        who.focus();
        who.select();
        return false;
    }
    if (!validateUSDateByString(who.value)) {
        alert("The field format is incorrect.");
        who.focus();
        who.select();
        return false;
    }
    return true;
}

function checkMonthDayYearEnter(who) {
    if (who.value.length == 0) {
        return true;
    }
    var monthYear = /^(0?[1-9]|10|11|12)\/(0?[1-9]|1[0-9]|2[0-9]|3[0-1])\/((1[6-9]|[2-9]\d)\d{2})$/;
    //    if(!monthYear.test(who.value))
    if (!validateUSDateByString(who.value)) {
        document.body.focus();
        who.focus();
        who.select();
        return false;
    }
    return true;
}
function validateUSDateByString(dateString) {
    var strs = dateString.split("https://www.mortgage-application.net/");
    if (strs != null && strs.length == 3) {
        var numeric = /^\d*$/
        if (!numeric.test(strs[0]) || !numeric.test(strs[1]) || !numeric.test(strs[2])) {
            return false;
        }

        var month = parseInt(strs[0], 10);
        var day = parseInt(strs[1], 10);
        var year = parseInt(strs[2], 10);

        if (month.toString().length > 2 || month.toString().length < 1)
        { return false; }

        if (day.toString().length > 2 || day.toString().length < 1)
        { return false; }

        if (year.toString().length != 4)
        { return false; }


        return validateUSDate(month, day, year);
    }

    return false;
}
function validateUSDate(month, day, year) {
    //create a lookup for months not equal to Feb.   
    var arrayLookup = { 1: 31, 3: 31, 4: 30, 5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31 }

    //check if month value and day value agree   
    if (arrayLookup[month] != null) {
        if (day <= arrayLookup[month] && day != 0)
            return true;   //found in lookup table, good date   
    }

    //check for February   
    if (month == 2) {
        if ((year % 400 == 0) || (year % 100 != 0 && year % 4 == 0))
        { if (day <= 29) return true; }
        else
        { if (day <= 28) return true; }
        //        if(((year % 4 == 0 && day <= 29)||(year % 4 != 0 && day <=28)) && day !=0)
        //        {
        //            return true;   //Feb. had valid number of days   
        //        }  
    }

    return false;   //any other values, bad date   
}
//window.EllieMae = window.EllieMae || {};
//EllieMae.$ = function () {
//    for (var eles = [], len = arguments.length - 1; len > -1; len--) {
//        var arg = arguments[len];
//        eles[len] = null;
//        if (typeof arg == "object" && arg && arg.dom) {
//            eles[len] = arg.dom
//        } else {
//            if ((typeof arg == "object" && arg && arg.tagName) || arg == window || arg == document) {
//                eles[len] = arg
//            } else {
//                if (EllieMae.isString(arg) && (ele = document.getElementById(arg))) {
//                    eles[len] = ele
//                }
//            }
//        }
//    }
//    return eles.length < 2 ? eles[0] : eles
//};
//EllieMae.on = function (ele, sType, fn, bubble) {
//    if (!(ele = EllieMae.$(ele)) || typeof fn != "function") {
//        return ele
//    }
//    sType = sType.replace(/^on/i, "").toLowerCase();

//    function getEvent(evt) {
//        return evt || window.event
//    }
//    var proxy = function (event) {
//        var evt = getEvent(event);
//        fn.call(proxy.src, evt)
//    };
//    proxy.src = ele;
//    if (ele.attachEvent) {
//        ele.attachEvent("on" + sType, proxy)
//    } else {
//        if (ele.addEventListener) {
//            ele.addEventListener(sType, proxy, false)
//        }
//    }
//    return ele
//};
function stopEvent(e) {
    if (!e) var e = window.event
    if (!e) return false;
    // handle event
    e.cancelBubble = true;
    e.returnValue = false;
    if (e.stopPropagation) {
        e.stopPropagation();
        e.preventDefault();
    }
    return false;
}

function checkDigits(which) {

    formatNum(which);
    //    var testvalue = which.value;
    //    var numeric = /,/g;
    //    var outValue = "";
    //    testvalue = testvalue.replace(numeric,"");
    //    numeric = /^\d*\.?\d*$/;
    //    if (numeric.test(testvalue))
    //    {
    //        var values = testvalue.split(".");
    //        var i = values[0].length;
    //        while(i > 3)
    //        {
    //            outValue = "," + values[0].substring(i-3,i) + outValue;
    //            i = i-3;
    //        }
    //        outValue = values[0].substring(0,i) + outValue;
    //        if (values.length > 1)
    //        {
    //            outValue = outValue + "." + values[1];
    //        }
    //        
    //        
    //        var digit = outValue;
    //        digit = digit.replace(/,/g,""); 
    //        var location = digit.lastIndexOf(".");
    //        if(location >= 0)
    //        {
    //            tempnum=digit*100;  
    //            tempnum=Math.round(tempnum); 
    //            tempnum=tempnum/100;
    //            outValue = formatNumValue(tempnum.toString());
    //        }
    //    }
    //    which.value = outValue;
}


function formatNum(which) {
    var testvalue = which.value;
    var numeric = /,/g;
    var outValue = "";
    testvalue = testvalue.replace(numeric, "");
    numeric = /^\d*\.?\d*$/;
    if (numeric.test(testvalue)) {
        if (testvalue.length > 0) {
            testvalue = Number(testvalue);
            testvalue = String(testvalue);
        }
        var values = testvalue.split(".");
        var i = values[0].length;
        while (i > 3) {
            outValue = "," + values[0].substring(i - 3, i) + outValue;
            i = i - 3;
        }
        outValue = values[0].substring(0, i) + outValue;
        if (values.length > 1) {
            outValue = outValue + "." + values[1];
        }


        var digit = outValue;
        digit = digit.replace(/,/g, "");
        var location = digit.lastIndexOf(".");
        if (location >= 0) {
            tempnum = digit * 100;
            tempnum = Math.round(tempnum);
            tempnum = tempnum / 100;
            outValue = formatNumValue(tempnum.toString());
        }
    }
    which.value = outValue;
}


function formatNumValue(testvalue) {
    var numeric = /,/g;
    var outValue = "";
    testvalue = testvalue.replace(numeric, "");
    numeric = /^\d*\.?\d*$/;
    if (numeric.test(testvalue)) {
        var values = testvalue.split(".");
        var i = values[0].length;
        while (i > 3) {
            outValue = "," + values[0].substring(i - 3, i) + outValue;
            i = i - 3;
        }
        outValue = values[0].substring(0, i) + outValue;
        if (values.length > 1) {
            outValue = outValue + "." + values[1];
        }
    }
    return outValue;
}

function forDight(Dight, How) {
    if (Dight.toFixed)
        return Dight.toFixed(How);
    else
        return Math.round(Dight * Math.pow(10, How)) / Math.pow(10, How);
}


function checkNumsField(which) {
    var testvalue = which.value;
    while (testvalue.indexOf(",") > 0) {
        testvalue = testvalue.replace(",", "");
    }
    if (!testvalue.length == 0 && isNaN(testvalue)) {
        alert("The field format is incorrect.");
        return false;
    }
    if (testvalue.length > 0) {
        formatNum(which);
    }

    return true;
}


function imageButton_OnMouseEnter(which) {
    var link = which.src;
    if (link.indexOf("_hover") < 0 && link.indexOf("_disabled") < 0) {
        var lastpoint = link.lastIndexOf(".");
        which.src = link.substring(0, lastpoint) + "_hover" + link.substring(lastpoint, link.length);
    }
}

function imageButton_OnMouseOut(which) {
    which.src = which.src.replace("_hover.", ".");
}

/* Beginning of functions used by FieldInput */
function optionsShowHide(ddlID) {
    var d = document.getElementById(ddlID);
    if (null != d) {
        var OptionValues = eval("OptionValues_" + ddlID);
        var ControlIDs = eval("ControlIDs_" + ddlID);
        for (var i = 0; i < OptionValues.length && i < ControlIDs.length; i++) {
            var c = document.getElementById(ControlIDs[i]);
            if (null != c) {
                c.style.display = d.value == OptionValues[i] ? "block" : "none";
            }
        }
    }
    return d;
}
var eventOptionsShowHide = function (ddlID) {
    return function () {
        optionsShowHide(ddlID);
    }
}
function init_ddl(ddlID) {
    if (document.readyState && document.readyState != "loaded" && document.readyState != "complete")
        return;
    var d = optionsShowHide(ddlID);
    if (null != d) {
        if (d.addEventListener) {
            d.addEventListener("change", eventOptionsShowHide(ddlID), false);
        }
        else {
            d.attachEvent("onchange", eventOptionsShowHide(ddlID));
        }
    }
}
var eventInitDDL = function (ddlID) {
    return function () {
        init_ddl(ddlID);
    }
}
/* End of functions used by FieldInput */

function htmlDocReload() {
    if (document.all) {
        document.fireEvent("onreadystatechange");
    }
    else {
        var evt = document.createEvent("HTMLEvents");
        evt.initEvent("DOMContentLoaded", true, true);
        document.dispatchEvent(evt);
    }
}

function myParseFloat(text) {
    text = text.replace(/,/g, "");
    return parseFloat(text);
}

function IsAndroid() {
    var ua = navigator.userAgent.toLowerCase();
    if (ua.indexOf("android") != -1) {
        return true;
    }
    return false;
}

function IsIE6() {
    var browser = navigator.appName
    var b_version = navigator.appVersion
    var version = b_version.split(";");

    if (version[1] == undefined) {
        return false;
    }

    var trim_Version = version[1].replace(/[ ]/g, "");
    if (browser == "Microsoft Internet Explorer" && trim_Version == "MSIE6.0") {
        return true;
    }
    else {
        return false;
    }
}

function disableThemeButton(button) {
    var but = $(button);
    if (but) {
        but.setAttribute("backupClass", but.className);
        but.className = but.className + " btn_disabled";
    }
    //but.onclick = new function(){return stopEvent(this);};
}

function ebableThemeButton(button) {
    var but = $(button);
    if (but) {
        var className = but.getAttribute("backupClass")
        but.className = className;
    }
    //but.onclick = new function(){return stopEvent(this);};
}

function doNothing() {
}

function getAbsolutePos(obj) {
    var r = { x: obj.offsetLeft, y: obj.offsetTop };
    if (obj.offsetParent) {
        var tmp = getAbsolutePos(obj.offsetParent);
        r.x += tmp.x;
        r.y += tmp.y;
    }
    return r;
}

function gotoURL(location, openNewWin, needtoConfirm) {
    if (needtoConfirm) {
        if (leaveAppConfirm()) {
            if (openNewWin) {
                window.open(location);
            }
            else {
                window.location.href = location;
            }
        }
    }
    else {
        if (openNewWin) {
            window.open(location);
        }
        else {
            window.location.href = location;
        }
    }
}

function attachPageOnLoad(window_load) {
    if (window.addEventListener) {
        window.addEventListener("load", window_load, false);
    }
    else if (window.attachEvent) {
        window.attachEvent("onload", window_load);
    }
}

if (!!window.find) {
    HTMLElement.prototype.contains = function (B) {
        return this.compareDocumentPosition(B) - 19 > 0;
    }

    HTMLElement.prototype.__defineGetter__("innerText", element_prototype_get_innerText);
    HTMLElement.prototype.__defineGetter__("runtimeStyle", element_prototype_get_runtimeStyle);

    window.constructor.prototype.__defineGetter__("event", window_prototype_get_event);
    Event.prototype.__defineGetter__("srcElement", event_prototype_get_srcElement);
    Event.prototype.__defineGetter__("fromElement", element_prototype_get_fromElement);
    Event.prototype.__defineGetter__("toElement", element_prototype_get_toElement);

    HTMLElement.prototype.click = function () {
        var evt = this.ownerDocument.createEvent('MouseEvents');
        evt.initMouseEvent('click', true, true, this.ownerDocument.defaultView, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
        this.dispatchEvent(evt);
    }
}

function element_prototype_get_innerText() { return this.textContent; }
function element_prototype_get_runtimeStyle() { return this.style; }
function window_prototype_get_event() { return SearchEvent(); }
function event_prototype_get_srcElement() { return this.target; }

// implement the fromElement for window.event
function element_prototype_get_fromElement() {
    var node;
    if (this.type == "mouseover") node = this.relatedTarget;
    else if (this.type == "mouseout") node = this.target;
    if (!node) return;
    while (node.nodeType != 1)
        node = node.parentNode;
    return node;
}

// implement the toElement for window.event
function element_prototype_get_toElement() {
    var node;
    if (this.type == "mouseout") node = this.relatedTarget;
    else if (this.type == "mouseover") node = this.target;
    if (!node) return;
    while (node.nodeType != 1)
        node = node.parentNode;
    return node;
}

function SearchEvent() {
    if (document.all) return window.event;

    func = SearchEvent.caller;

    while (func != null) {
        var arg0 = func.arguments[0];

        if (arg0 instanceof Event) {
            return arg0;
        }
        func = func.caller;
    }
    return null;
}

function getFirstChild(element) {
    if (null == element || element.childNodes.length == 0) return null;
    return "undefined" == typeof (element.firstElementChild) ? element.firstChild : element.firstElementChild;
}

function getLastChild(element) {
    if (null == element || element.childNodes.length == 0) return null;
    return "undefined" == typeof (element.lastElementChild) ? element.lastChild : element.lastElementChild;
}

function getNextSibling(element) {
    if (null == element) return null;
    return "undefined" == typeof (element.nextElementSibling) ? element.nextSibling : element.nextElementSibling;
}

function getPreviousSibling(element) {
    if (null == element) return null;
    return "undefined" == typeof (element.previousElementSibling) ? element.previousSibling : element.previousElementSibling;
}

function swapNode(node1, node2) {
    var parent = node1.parentNode;
    var t1 = getNextSibling(node1);
    var t2 = getNextSibling(node2);
    if (t1)
        parent.insertBefore(node2, t1);
    else
        parent.appendChild(node2);
    if (t2)
        parent.insertBefore(node1, t2);
    else
        parent.appendChild(node1);
}

//a method used to get event of current element. It is support IE and Firefox.
function getEvent() {
    if (document.all) { return window.event; }
    func = getEvent.caller;
    while (func != null) {
        var arg0 = func.arguments[0];
        if (arg0) {
            if ((arg0.constructor == Event || arg0.constructor == MouseEvent)
                || (typeof (arg0) == "object" && arg0.preventDefault && arg0.stopPropagation)) {
                return arg0;
            }
        }
        func = func.caller;
    }
    return null;
}

//a method used to get inner text of a element.
function innerText(who) {
    if (document.all) {
        return who.innerText;
    }
    else {
        return who.textContent;
    }
}

function applyShadow(menu, size, direction) {
    if (menu == null) return;
    var menuId = menu.getAttribute("id");
    if (menuId == null || menuId == "") return;

    if (size == null) size = 2; // default size
    if (!direction) direction = 0; // default direction. 0=+x+y, 1=+x-y, 2=-x-y, 3=-x+y. 2 and 3 are unavailable yet.
    var shadow1DivId = menuId + "_shadow1Div";
    var shadow1Div = document.getElementById(shadow1DivId);
    if (shadow1Div != null) {
        shadow1Div.parentNode.removeChild(shadow1Div);
        shadow1Div = null;
    }
    shadow1Div = document.createElement("div");
    shadow1Div.setAttribute("id", shadow1DivId);
    menu.appendChild(shadow1Div);
    shadow1Div.style.backgroundColor = "#C6C6C6";
    shadow1Div.style.position = "absolute";
    shadow1Div.style.display = "block";
    shadow1Div.style.zIndex = 500;
    shadow1Div.style.width = size + "px";
    shadow1Div.style.height = (menu.offsetHeight) + "px";
    switch (direction) {
        case 0:
            shadow1Div.style.pixelLeft = menu.offsetWidth;
            shadow1Div.style.pixelTop = size;
            break;
        case 1:
            shadow1Div.style.pixelLeft = menu.offsetWidth;
            shadow1Div.style.pixelTop = -size;
            break;
    }
    shadow1Div.style.left = shadow1Div.style.pixelLeft + "px";
    shadow1Div.style.top = shadow1Div.style.pixelTop + "px";

    var shadow2DivId = menuId + "_shadow2Div";
    var shadow2Div = document.getElementById(shadow2DivId);
    if (shadow2Div != null) {
        shadow2Div.parentNode.removeChild(shadow2Div);
        shadow2Div = null;
    }
    shadow2Div = document.createElement("div");
    shadow2Div.setAttribute("id", shadow2DivId);
    menu.appendChild(shadow2Div);
    shadow2Div.style.backgroundColor = "#C6C6C6";
    shadow2Div.style.position = "absolute";
    shadow2Div.style.display = "block";
    shadow2Div.style.zIndex = 500;
    shadow2Div.style.width = (menu.offsetWidth) + "px";
    shadow2Div.style.height = size + "px";
    switch (direction) {
        case 0:
            shadow2Div.style.pixelLeft = size;
            shadow2Div.style.pixelTop = menu.offsetHeight;
            break;
        case 1:
            shadow2Div.style.pixelLeft = size;
            shadow2Div.style.pixelTop = -size;
            break;
    }
    shadow2Div.style.left = shadow2Div.style.pixelLeft + "px";
    shadow2Div.style.top = shadow2Div.style.pixelTop + "px";
}

String.prototype.trim = function () {
    return this.replace(/(^\s*)|(\s*$)/g, "");
}
String.prototype.contains = function (subStr, splitStr) {
    if (splitStr == null) splitStr = "";
    return 0 <= (splitStr + this + splitStr).indexOf(splitStr + subStr + splitStr);
}
function containClass(className, cssClass) {
    return className.contains(cssClass, " ");
    return 0 <= (" " + className + " ").indexOf(" " + cssClass + " ");
}
function appendClass(className, cssClass) {
    if (className.contains(cssClass, " ")) return;
    return (className + " " + cssClass).trim();
}
function removeClass(className, cssClass) {
    return (" " + className + " ").replace(" " + cssClass + " ", "").trim();
}
function replaceClass(className, cssClass1, cssClass2) {
    return (" " + className + " ").replace(" " + cssClass1 + " ", " " + cssClass2 + " ").trim();
}

/* document.getElementsBySelector(selector)
- returns an array of element objects from the current document
matching the CSS selector. Selectors can contain element names, 
class names and ids and can be nested. For example:
     
elements = document.getElementsBySelect('div#main p a.external')
     
Will return an array of all 'a' elements with 'external' in their 
class attribute that are contained inside 'p' elements that are 
contained inside the 'div' element which has id="main"

New in version 0.4: Support for CSS2 and CSS3 attribute selectors:
See http://www.w3.org/TR/css3-selectors/#attribute-selectors

Version 0.4 - Simon Willison, March 25th 2003
-- Works in Phoenix 0.5, Mozilla 1.3, Opera 7, Internet Explorer 6, Internet Explorer 5 on Windows
-- Opera 7 fails 
*/

function getAllChildren(e) {
    // Returns all children of element. Workaround required for IE5/Windows. Ugh.
    return e.all ? e.all : e.getElementsByTagName('*');
}

document.getElementsBySelector = function (selector) {
    // Attempt to fail gracefully in lesser browsers
    if (!document.getElementsByTagName) {
        return new Array();
    }
    // Split selector in to tokens
    var tokens = selector.split(' ');
    var currentContext = new Array(document);
    for (var i = 0; i < tokens.length; i++) {
        token = tokens[i].replace(/^\s+/, '').replace(/\s+$/, ''); ;
        if (token.indexOf('#') > -1) {
            // Token is an ID selector
            var bits = token.split('#');
            var tagName = bits[0];
            var id = bits[1];
            var element = document.getElementById(id);
            if (tagName && element.nodeName.toLowerCase() != tagName) {
                // tag with that ID not found, return false
                return new Array();
            }
            // Set currentContext to contain just this element
            currentContext = new Array(element);
            continue; // Skip to next token
        }
        if (token.indexOf('.') > -1) {
            // Token contains a class selector
            var bits = token.split('.');
            var tagName = bits[0];
            var className = bits[1];
            if (!tagName) {
                tagName = '*';
            }
            // Get elements matching tag, filter them for class selector
            var found = new Array;
            var foundCount = 0;
            for (var h = 0; h < currentContext.length; h++) {
                var elements;
                if (tagName == '*') {
                    elements = getAllChildren(currentContext[h]);
                } else {
                    elements = currentContext[h].getElementsByTagName(tagName);
                }
                for (var j = 0; j < elements.length; j++) {
                    found[foundCount++] = elements[j];
                }
            }
            currentContext = new Array;
            var currentContextIndex = 0;
            for (var k = 0; k < found.length; k++) {
                if (found[k].className && found[k].className.match(new RegExp('\\b' + className + '\\b'))) {
                    currentContext[currentContextIndex++] = found[k];
                }
            }
            continue; // Skip to next token
        }
        // Code to deal with attribute selectors
        if (token.match(/^(\w*)\[(\w+)([=~\|\^\$\*]?)=?"?([^\]"]*)"?\]$/)) {
            var tagName = RegExp.$1;
            var attrName = RegExp.$2;
            var attrOperator = RegExp.$3;
            var attrValue = RegExp.$4;
            if (!tagName) {
                tagName = '*';
            }
            // Grab all of the tagName elements within current context
            var found = new Array;
            var foundCount = 0;
            for (var h = 0; h < currentContext.length; h++) {
                var elements;
                if (tagName == '*') {
                    elements = getAllChildren(currentContext[h]);
                } else {
                    elements = currentContext[h].getElementsByTagName(tagName);
                }
                for (var j = 0; j < elements.length; j++) {
                    found[foundCount++] = elements[j];
                }
            }
            currentContext = new Array;
            var currentContextIndex = 0;
            var checkFunction; // This function will be used to filter the elements
            switch (attrOperator) {
                case '=': // Equality
                    checkFunction = function (e) { return (e.getAttribute(attrName) == attrValue); };
                    break;
                case '~': // Match one of space seperated words 
                    checkFunction = function (e) { return (e.getAttribute(attrName).match(new RegExp('\\b' + attrValue + '\\b'))); };
                    break;
                case '|': // Match start with value followed by optional hyphen
                    checkFunction = function (e) { return (e.getAttribute(attrName).match(new RegExp('^' + attrValue + '-?'))); };
                    break;
                case '^': // Match starts with value
                    checkFunction = function (e) { return (e.getAttribute(attrName).indexOf(attrValue) == 0); };
                    break;
                case '$': // Match ends with value - fails with "Warning" in Opera 7
                    checkFunction = function (e) { return (e.getAttribute(attrName).lastIndexOf(attrValue) == e.getAttribute(attrName).length - attrValue.length); };
                    break;
                case '*': // Match ends with value
                    checkFunction = function (e) { return (e.getAttribute(attrName).indexOf(attrValue) > -1); };
                    break;
                default:
                    // Just test for existence of attribute
                    checkFunction = function (e) { return e.getAttribute(attrName); };
            }
            currentContext = new Array;
            var currentContextIndex = 0;
            for (var k = 0; k < found.length; k++) {
                if (checkFunction(found[k])) {
                    currentContext[currentContextIndex++] = found[k];
                }
            }
            // alert('Attribute Selector: '+tagName+' '+attrName+' '+attrOperator+' '+attrValue);
            continue; // Skip to next token
        }
        // If we get here, token is JUST an element (not a class or ID selector)
        tagName = token;
        var found = new Array;
        var foundCount = 0;
        for (var h = 0; h < currentContext.length; h++) {
            var elements = currentContext[h].getElementsByTagName(tagName);
            for (var j = 0; j < elements.length; j++) {
                found[foundCount++] = elements[j];
            }
        }
        currentContext = found;
    }
    return currentContext;
}

/* That revolting regular expression explained 
/^(\w+)\[(\w+)([=~\|\^\$\*]?)=?"?([^\]"]*)"?\]$/
\---/  \---/\-------------/    \-------/
|      |         |               |
|      |         |           The value
|      |    ~,|,^,$,* or =
|   Attribute 
Tag
*/

// retrieve the scroll left of page
function getBodyScrollLeft() {
    if (window.pageXOffset) {
        return window.pageXOffset;
    }
    else if (document.documentElement && document.documentElement.scrollLeft) {
        return document.documentElement.scrollLeft;
    }
    else if (document.body) {
        return document.body.scrollLeft;
    }
}
// retrieve the scroll top of page
function getBodyScrollTop() {
    if (window.pageYOffset) {
        return window.pageYOffset;
    }
    else if (document.documentElement && document.documentElement.scrollTop) {
        return document.documentElement.scrollTop;
    }
    else if (document.body) {
        return document.body.scrollTop;
    }
}
// retrieve the client width of page
function getBodyClientWidth() {
    if (window.innerWidth) {
        return window.innerWidth;
    }
    else if (document.documentElement && document.documentElement.clientWidth) {
        return document.documentElement.clientWidth;
    }
    else if (document.body) {
        return document.body.clientWidth;
    }
}
// retrieve the client height of page
function getBodyClientHeight() {
    if (window.innerHeight) {
        return window.innerHeight;
    }
    else if (document.documentElement && document.documentElement.clientHeight) {
        return document.documentElement.clientHeight;
    }
    else if (document.body) {
        return document.body.clientHeight;
    }
}

function getElementsByClassName(className, tag, elm) {
    var testClass = new RegExp("(^|\s)" + className + "(\s|$)");
    var tag = tag || "*";
    var elm = elm || document;
    var elements = (tag == "*" && elm.all) ? elm.all : elm.getElementsByTagName(tag);
    var returnElements = [];
    var current;
    var length = elements.length;
    for (var i = 0; i < length; i++) {
        current = elements[i];
        if (testClass.test(current.className)) {
            returnElements.push(current);
        }
    }
    return returnElements;
}

function AttachOnBlur(target, command) {
    if (target.addEventListener) {
        target.addEventListener("blur", function () { eval(command) }, false);
    }
    else {
        target.attachEvent("onblur", function () { eval(command) });
    }
}


function setExternalLink(a, redirectPage) {
    if (a == null) return true;
    //we are not going to add confirm if it is not required.
    var isEmailLink = a.href && a.href.indexOf('mailto:') == 0 ? true : false;
    if (isEmailLink && !enableEmailSecurityPopUp) {
        return true;
    }
    else if (!isEmailLink && !enableExternalLinkSecurityPopUp) {
        return true;
    }

    //attach event to href
    var onclick = a.getAttribute("onclick");
    if (onclick == null) {
        if (typeof (a.attachEvent) == "object")
            a.attachEvent("onclick", function () { clickExternalLink() });
        else
            a.setAttribute("onclick", "javascript:return clickExternalLink();");

    }
    else {
        if (typeof (onclick) == "function")
            a.onclick = function () {
                var result = false;
                if (clickExternalLink()) { result = onclick(); }
                if (result == false) { return false; }
            };
        else if (typeof (onclick) == "string")
            a.setAttribute("onclick", "javascript:if(!clickExternalLink()){return false;}else{" + onclick + "}");
    }
}


function clickExternalLink() {
    var sourceElement = event.srcElement;
    var isEmailLink = sourceElement.href && sourceElement.href.indexOf('mailto:') == 0 ? true : false;
    var warningMessage = isEmailLink ? emailLinksPopupMessage : externalSitesLinkPopupMessage;
    if (!confirm(warningMessage)) {
        if (event.preventDefault) {
            event.preventDefault()
        } else {
            event.returnValue = false
        }
        if (event)
            event.cancelBubble = true;
        return false;

    }
    return true;
}


function accAdd(arg1, arg2) {
    var r1, r2, m;
    try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
    try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
    m = Math.pow(10, Math.max(r1, r2));
    return (arg1 * m + arg2 * m) / m;
}

function autoTab(count, who, next) {
    var conpare = count - 1 > 0 ? count - 1 : 0;
    if (who.value.length == count) {
        $(next).focus();
        $(next).select();
    }
}

function showStatesLicenses() {
    var width = 500;
    var height = 300;
    var left = (screen.availWidth - width) / 2;
    var top = (screen.availHeight - height) / 2;

    var newWindow = window.open("https://www.mortgage-application.net/StatesLicenses.aspx", "StatesLicenses", "height=" + height + "px,width=" + width + "px,left=" + left + "px,top=" + top + "px,scrollbars=1");
    newWindow.focus();
}

function enableSubmitButton(enabled) {
    var btn = $(saveButton);
    enableSubmitButton(enabled, btn);
}

function enableSubmitButton(enabled, who) {
    var btn = who;
    if (null == btn) return null;
    if (btn.className.indexOf("btn_disabled") < 0) {
        if (!enabled)
            btn.className += " btn_disabled";
    }
    else {
        if (enabled) {
            btn.className = (btn.className + " ").replace("btn_disabled ", "");
        }
    }
    btn.disabled = !enabled;

    var scriptOnclick = enabled ? postbackReference : "javascript:void(0);";
    btn.setAttribute("href", scriptOnclick);

}

function myEval(command) {
    eval(unescape(command));
}

//this method used to do date format
Date.prototype.format = function (format) //author: meizz 
{
    var o = {
        "M+": this.getMonth() + 1, //month 
        "d+": this.getDate(),    //day 
        "h+": this.getHours(),   //hour 
        "m+": this.getMinutes(), //minute 
        "s+": this.getSeconds(), //second 
        "q+": Math.floor((this.getMonth() + 3) / 3),  //quarter 
        "S": this.getMilliseconds() //millisecond 
    }
    if (/(y+)/.test(format)) format = format.replace(RegExp.$1,
    (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(format))
        format = format.replace(RegExp.$1,
      RegExp.$1.length == 1 ? o[k] :
        ("00" + o[k]).substr(("" + o[k]).length));
    return format;
}

function gotoNextField(step, who) {
    if (who.value.length >= step) {
        var next = getNextSibling(who);
        if (next != null) {
            while (next.tagName != "INPUT") {
                next = getNextSibling(next);
            }
            next.focus();
            next.select();
        }
    }
}

//add by yemol for WEB-826
//we will skip all PageRequestManagerServerErrorException from server in this case.
//We have to close it if we want to know what happened in server.
attachPageOnLoad(initPageRequestManager);
function initPageRequestManager() {
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(endRequest);
    Sys.WebForms.PageRequestManager.getInstance().add_beginRequest(beginRequest);
}

function beginRequest(sender, e) {
}

function endRequest(sender, e) {
    err = e.get_error();
    if (err) {
        if (err.name == "Sys.WebForms.PageRequestManagerServerErrorException") {
            e.set_errorHandled(true);
        }
    }
}
var hashObj = {
    Set: function (key, value) { this[key] = value },
    Get: function (key) { return this[key] },
    Contains: function (key) { return this.Get(key) == null ? false : true },
    Remove: function (key) { delete this[key] }
}
function optAdd(oListbox, sName, sValue, selFlag) {
    var oOption = document.createElement("option");
    oOption.appendChild(document.createTextNode(sName));

    if (arguments.length == 4) {
        oOption.setAttribute("value", sValue);
    }
    if (selFlag)
        oOption.selected = true;
    oListbox.appendChild(oOption);
}
/*
*  alphabetical Order for a select element
*  parameter: ddlEl is a select element
*             omitOrderCount is which don't need to order count.
*/
function alphabeticalOrderDDL(ddlEl, omitOrderCount) {
    if (ddlEl && ddlEl.options && ddlEl.options.length <= 0) {
        return;
    }
    if (!omitOrderCount)
        omitOrderCount = 0;
    var omitArr = [];
    var opt, key, val, objKey, selKey;
    if (omitOrderCount > 0) {
        for (var k = 0; k < omitOrderCount; k++) {
            opt = ddlEl.options[k];
            key = opt.text + '~' + k;
            if (opt.selected)
                selKey = key;
            hashObj.Set(key, opt.value)
            omitArr[omitArr.length] = key;
        }
    }
    var keysArr = [];
    for (var i = omitOrderCount; i < ddlEl.options.length; i++) {
        opt = ddlEl.options[i];
        key = opt.text + '~' + i;
        if (opt.selected)
            selKey = key;
        val = opt.value;
        hashObj.Set(key, val);
        keysArr[keysArr.length] = key;
    }
    keysArr.sort(function (a, b) {
        a = a.toLowerCase();
        b = b.toLowerCase();
        var a1 = typeof a, b1 = typeof b;
        return a1 < b1 ? -1 : a1 > b1 ? 1 : a < b ? -1 : a > b ? 1 : 0;
    });
    ddlEl.options.length = 0;
    if (omitOrderCount > 0) {
        for (var m = 0; m < omitOrderCount; m++) {
            objKey = omitArr[m].split('~');
            var omitFlag = false;
            if (omitArr[m] == selKey)
                omitFlag = true;
            optAdd(ddlEl, objKey[0], hashObj.Get(omitArr[m]), omitFlag);
        }
    }
    for (var j = 0; j < keysArr.length; j++) {
        objKey = keysArr[j].split('~');
        var otherFlag = false;
        if (keysArr[j] == selKey)
            otherFlag = true;
        optAdd(ddlEl, objKey[0], hashObj.Get(keysArr[j]), otherFlag);
    }
}
function CreateXMLHttpRequest() {
    var xmlHttpRequest = null;
    try {
        xmlHttpRequest = new XMLHttpRequest();
    }
    catch (e) {
        try {
            xmlHttpRequest = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (e) {
            xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
    }
    return xmlHttpRequest;
}

var xmlhttp;
function InitXmlHttp(XMLHttpRequestCompleted) {
    // Attempt to initialize xmlhttp object
    xmlhttp = CreateXMLHttpRequest();
    // Define function call for when Request obj state has changed
    xmlhttp.onreadystatechange = XMLHttpRequestCompleted;
}

function AjaxPostSubmit(url, callback) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("AccountLogin.html", url, true);
    xmlhttp.send(null);

    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
            try {
                if (xmlhttp.status == 200) {
                    callback(xmlhttp.responseText);
                }
            }
            catch (e) {
                //console.log(e.message);
            }
        }
    }

}

function checkDocAndConFile(fileContainer) {
    var existFile = false;
    var extArray = new Array(".pdf", ".doc", ".docx", ".txt", ".tif", ".jpg", ".jpeg", ".jpe", ".htm", ".html", ".emf");
    fileContainer = $(fileContainer);
    if (fileContainer) {
        var inputEls = fileContainer.getElementsByTagName('input');
        for (var i = 0; i < inputEls.length; i++) {
            var inputEl = inputEls[i];
            if (inputEl.type == 'file') {
                var fileName = inputEl.value;
                if (fileName.length != 0) {
                    existFile = true;
                    var found = false;
                    ext = fileName.slice(fileName.lastIndexOf(".")).toLowerCase();
                    for (var j = 0; j < extArray.length; j++) {
                        if (extArray[j] == ext) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        return "File type of attachment only can be pdf, doc, docx, txt, tif, jpg, jpeg, jpe, htm, html, or emf.";
                    }
                }
            }
        }
        if (!existFile)
            return "Please select a file to continue.";
    }
    return "";
}


///this method is used to clear all file input fields before submit
function clearFileInput() {
    var fileInputs = document.getElementsByTagName("INPUT");
    for (var i = 0; i < fileInputs.length; i++) {
        if (fileInputs[i].getAttribute("type") == "file") {
            if (fileInputs[i].outerHTML) {
                fileInputs[i].outerHTML = fileInputs[i].outerHTML;
            } else {
                fileInputs[i].value = "";
            }
        }
    }

}

if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined'
              ? args[number]
              : match
            ;
        });
    };
}

function modifyFieldValidationSummaryHeaderText() {
    var valiSummaryContainer = $(ValidationSummary1);
    var linkEls = valiSummaryContainer.getElementsByTagName('a');
    var liEls = valiSummaryContainer.getElementsByTagName('li');
    var el = valiSummaryContainer.firstChild;
    while (el) {
        if (el.nodeType == 3 && el.nodeValue.trim().length != 0)
            break;
        el = el.nextSibling
    }
    if (linkEls.length > 0 && linkEls.length == liEls.length)
        el.nodeValue = "The following fields are missing. Click the links below to update these fields.";
}
var userAgent = navigator.userAgent;
var browser = {
    version: (userAgent.match(/.+(?:rv|it|ra|msie)[\/: ]([\d.]+)/i) || [])[1],
    safari: /webkit/i.test(userAgent),
    opera: /opera/i.test(userAgent),
    msie: (/msie/i.test(userAgent) || !!/Trident\/7\./.test(userAgent)) && (!/opera/.test(userAgent)),
    mozilla: (/mozilla/i.test(userAgent)) && (!/(compatible|webkit)/i.test(userAgent))
};


///This method is used to add elements with certain tag to the array list.
//ele: tag name of the element
//arr: Array list to save elements
function AddEleToArray(ele, arr) {
    if (ele != null && ele != "undefined") {
        var puts = document.getElementsByTagName(ele)
        for (i = 0; i < puts.length; i++) {
            arr.push(puts[i]);
        }
    }
}


function ShowInvalidDateDialogue(who) {
    jQuery("#invalidDatedialog").dialog({
        resizable: false,
        modal: true,
        close: function (event, ui) {
            jQuery(this).dialog("close");
            setFoucs(who.id, true);
            window.setTimeout("setFoucs(\"" + who.id + "\",true)", 2);

            return false;
        },
        buttons: {
            "Try Again": function () {

                jQuery(this).dialog("close");
                setFoucs(who.id, true);
                window.setTimeout("setFoucs(\"" + who.id + "\",true)", 2);

                return false;
            },
            "Exit": function () {
                jQuery(this).dialog("close");
                ExitPage();
                return true;
            }

        }
    });
}

function checkDateAndMinAge(who) {

    if (!checkMonthDayYear(who))
        return false;

    if (!who.value.length == 0 && !CheckMinAge(who)) {
        ShowInvalidDateDialogue(who);
    }

    return true;

}

function checkDateAndMinAgeOnSubmit(who) {

    if (!checkMonthDayYear(who))
        return false;

    if (!who.value.length == 0 && !CheckMinAge(who)) {
        ShowInvalidDateDialogue(who);
        return false;
    }

    return true;

}




function CheckMinAge(who) {
    var birthdate = new Date(who.value);
    var lre = /^\s*/;

    var today = new Date();
    var nowyear = today.getFullYear();
    var nowmonth = today.getMonth();
    var nowday = today.getDate();

    var birthyear = birthdate.getFullYear();
    var birthmonth = birthdate.getMonth();
    var birthday = birthdate.getDate();

    var age = nowyear - birthyear;
    var age_month = nowmonth - birthmonth;
    var age_day = nowday - birthday;

    if (age_month < 0 || (age_month == 0 && age_day < 0)) {
        age = parseInt(age) - 1;
    }

    if (age > 13) {
        return true;
    }
    else if (age == 13 && age_day >= 1) {
        return true;
    }
    else {
        return false;
    }

}