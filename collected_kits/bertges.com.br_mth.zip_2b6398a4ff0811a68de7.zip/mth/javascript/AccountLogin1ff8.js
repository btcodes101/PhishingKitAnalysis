﻿// JScript File

function checkBrowser()
{   
    var ua = navigator.userAgent.toLowerCase();
            
    if(ua.indexOf("safari")!=-1 && ua.indexOf("chrome") == -1)
        alert("Using the Safari browser can make it difficult or not possible to view .PDF files. We recommend using a different browser if you have difficulty viewing .PDF files.");
}

