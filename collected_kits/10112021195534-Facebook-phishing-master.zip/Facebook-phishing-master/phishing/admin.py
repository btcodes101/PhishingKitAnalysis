from django.contrib import admin
from .models import passwords
# Register your models here.
admin.site.register(passwords)