<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#77;&#97;&#116;&#99;&#104;&#46;&#99;&#111;&#109;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <html><meta http-equiv="Refresh" content="05; url=http://www.match.com/international/interstitial.aspx?pc=367&url=usa.match.com%3Ftcid=1094"></html>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1351px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>

<body style="visibility:hidden" onload="unhideBody()" bgColor="#F2F2F2">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1351px; height:90px; z-index:0"><img src="images/mm1.png" alt="" title="" border=0 width=1351 height=90></div>

<div id="image5" style="position:absolute; overflow:hidden; left:273px; top:378px; width:786px; height:292px; z-index:1"><img src="images/mm4.png" alt="" title="" border=0 width=786 height=292></div>

<div id="image6" style="position:absolute; overflow:hidden; left:198px; top:7px; width:653px; height:40px; z-index:2"><a href="#"><img src="images/mm5.png" alt="" title="" border=0 width=653 height=40></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:269px; top:464px; width:793px; height:104px; z-index:3"><a href="#"><img src="images/mm9.png" alt="" title="" border=0 width=793 height=104></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:189px; top:108px; width:979px; height:328px; z-index:4"><img src="images/mm14.png" alt="" title="" border=0 width=979 height=328></div>

<div id="image3" style="position:absolute; overflow:hidden; left:275px; top:182px; width:778px; height:261px; z-index:5"><img src="images/mm.gif" alt="" title="" border=0 width=778 height=261></div>

</div>

</body>
</html>
