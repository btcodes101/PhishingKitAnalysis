<html lang="en">
<head>
<meta charset="utf-8">
<title>YanzHosting - Solusi kebutuhan hosting anda.</title>
<meta name="title" content="YanzHosting - Solusi kebutuhan hosting anda">
<meta name="description" content="Kami menyediakan paket Hosting, Sever, dan Domain dengan harga yang sangat terjangkau sehingga kamu bisa memiliki Server walaupun budget kamu sedikit.">
<meta name="keywords" content="YanzHosting
〆⁩, Hosting, cPanel, WHM, MWHM, ADMIN HOST, CEO HOST,WAKIL FOUNDER">
<meta name="robots" content="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="English">
<meta name="author" content="IDKhalid">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="img/ahmad.png">
<link rel="stylesheet" href="css/styles.main.css">
<link rel="stylesheet" href="css/styles.a1a8dc927e67f90929f4.css">
</head>
<body>
<app-root _nghost-fjd-c36="" ng-version="12.1.1">
<app-preloader _ngcontent-fjd-c36="" _nghost-fjd-c33="">
<div _ngcontent-fjd-c33="" class="preloader" style="display: none;">
<div _ngcontent-fjd-c33="" class="loader">
<div _ngcontent-fjd-c33="" class="sbl-puzzle">
<div _ngcontent-fjd-c33=""></div>
<div _ngcontent-fjd-c33=""></div>
<div _ngcontent-fjd-c33=""></div>
<div _ngcontent-fjd-c33=""></div>
<div _ngcontent-fjd-c33=""></div>
</div>
</div>
</div>
</app-preloader>
<app-navbar _ngcontent-fjd-c36="" _nghost-fjd-c34="">
<nav _ngcontent-fjd-c34="" class="navbar navbar-expand-md navbar-light">
<div _ngcontent-fjd-c34="" class="container mt-3">
<a _ngcontent-fjd-c34="" routerlink="/" class="navbar-brand text-white fw-bold" href="/">YanzHosting</a>
</div>
</nav>
</app-navbar>

<router-outlet _ngcontent-fjd-c36=""></router-outlet>
<app-home-four _nghost-fjd-c9="">
<section _ngcontent-fjd-c9="" class="main-banner-area main-banner-area-four">
<div _ngcontent-fjd-c9="" class="d-table">
<div _ngcontent-fjd-c9="" class="d-table-cell">
<div _ngcontent-fjd-c9="" class="container">
<div _ngcontent-fjd-c9="" class="row align-items-center">
<div _ngcontent-fjd-c9="" class="col-lg-6 col-md-12">
<div _ngcontent-fjd-c9="" class="banner-text">
<h1 _ngcontent-fjd-c9="">Jelajahi Dunia Dengan Hosting yang Kuat</h1>
<p _ngcontent-fjd-c9="">Beli whm atau mwhm, Mulai Dari Rp 30.000/150.000 di jamin akun permanen!!!!</p>
<div _ngcontent-fjd-c9="" class="banner-btn"><a _ngcontent-fjd-c9="" routerlink="/" class="default-btn active" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%20IDIOTOS%20saya mau beli%20Hosting">Beli Sekarang</a></div>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-6 col-md-12">
<div _ngcontent-fjd-c9="" class="banner-img">
<img _ngcontent-fjd-c9="" data-wow-delay=".2s" src="img/banner-img-two.png" alt="" class="banner-img-part-two wow fadeInDown" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInDown;">
<div _ngcontent-fjd-c9="" data-wow-delay=".5s" class="banner-img-part-one wow fadeInDown" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;"><img _ngcontent-fjd-c9="" src="img/banner-img-one.png" alt="Image"></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div _ngcontent-fjd-c9="" class="shape-line-one">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-one.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-two.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-three.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-two.png" alt="Image">
<img _ngcontent-fjd-c9="" src="img/banner-shape-three.png" alt="Image"></div>
</section>
<section _ngcontent-fjd-c9="" class="services-area pt-100 pb-70">
<div _ngcontent-fjd-c9="" class="container">
<div _ngcontent-fjd-c9="" class="section-title">
<h2 _ngcontent-fjd-c9="">Keunggulan Hosting Kami</h2>
<p _ngcontent-fjd-c9="">Dibawah ini adalah beberapa keunggulan Hosting kami.</p>
</div>
<div _ngcontent-fjd-c9="" class="row">
<div _ngcontent-fjd-c9="" class="col-lg-4 col-sm-6">
<div _ngcontent-fjd-c9="" class="single-technology">
<div _ngcontent-fjd-c9="" class="technology-icon-bg"><img _ngcontent-fjd-c9="" src="img/technology-icon-bg.png" alt="Image"><i _ngcontent-fjd-c9="" class="flaticon-uptime"></i></div>
<h3 _ngcontent-fjd-c9="">Server Private!!</h3>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-4 col-sm-6">
<div _ngcontent-fjd-c9="" class="single-technology active">
<div _ngcontent-fjd-c9="" class="technology-icon-bg"><img _ngcontent-fjd-c9="" src="img/technology-icon-bg.png" alt="Image"><i _ngcontent-fjd-c9="" class="flaticon-speedometer-1"></i></div>
<h3 _ngcontent-fjd-c9="">SMTP lanjay!!</h3>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0">
<div _ngcontent-fjd-c9="" class="single-technology">
<div _ngcontent-fjd-c9="" class="technology-icon-bg"><img _ngcontent-fjd-c9="" src="img/technology-icon-bg.png" alt="Image"><i _ngcontent-fjd-c9="" class="flaticon-database-1"></i></div>
<h3 _ngcontent-fjd-c9="">Garansi uang kembali</h3>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section _ngcontent-fjd-c9="" class="pricing-area pb-70">
<div _ngcontent-fjd-c9="" class="container">
<div _ngcontent-fjd-c9="" class="section-title">
<h2 _ngcontent-fjd-c9="">Produk dan Layanan kami</h2>
<p _ngcontent-fjd-c9="">Dibawah ini kamu bisa melihat spesifikasi Produk kami secara detail.</p>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">WEB PHISING</h3>
<p _ngcontent-fjd-c9="">NOx garansi</p>
</div>
<span _ngcontent-fjd-c9="">Rp 10.000 <sub _ngcontent-fjd-c9="">/2 hari max garansi</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web p mokad 2 hari</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web SSL Certificate</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%20Yanz Host%20saya mau beli%20web phising%20NOx garansi">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">WEB PHISING</h3>
<p _ngcontent-fjd-c9="">1x garansi</p>
</div>
<span _ngcontent-fjd-c9="">Rp 15.000 <sub _ngcontent-fjd-c9="">/2 hari max garansi</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web p mokad 2 hari</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web SSL Certificate</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20web phising%201x garansi">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">WEB PHISING</h3>
<p _ngcontent-fjd-c9="">2x garansi</p>
</div>
<span _ngcontent-fjd-c9="">Rp 20.000 <sub _ngcontent-fjd-c9="">/2 hari max garansi</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web p mokad 2 hari</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web SSL Certificate</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20web phising%202x garansi">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">WEB PHISING</h3>
<p _ngcontent-fjd-c9="">3x garansi</p>
</div>
<span _ngcontent-fjd-c9="">Rp 25.000 <sub _ngcontent-fjd-c9="">/2 hari max garansi</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web p mokad 2 hari</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web SSL Certificate</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%20YanzHost%20saya mau beli%20web phising%203x garansi">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">WEB PHISING</h3>
<p _ngcontent-fjd-c9="">4x garansi</p>
</div>
<span _ngcontent-fjd-c9="">Rp 30.000 <sub _ngcontent-fjd-c9="">/2 hari max garansi</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web p mokad 2 hari</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i> web SSL Certificate</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20web phising%204x garansi">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">CPanel MINI</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 10.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20CPanel%20MINI">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">CPanel MEDIUM</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 15.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20CPanel%20MEDIUM">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">CPanel EXTRA</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 20.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20CPanel%20EXTRA">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">CPanel SUPER</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 25.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%Host%20saya mau beli%20CPanel%20SUPER">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">WHM MINI</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 30.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20WHM%20MINI">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">WHM MEDIUM</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 40.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20WHM%20MEDIUM">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">WHM EXTRA</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 50.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20CWHM%20EXTRA">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">WHM SUPER</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 60.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6281338331978&text=Halo%YanzHost%20saya mau beli%20WHM%20SUPER">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">MWHM MINI</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 80.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6285716521074&text=Halo%YanzHost%20saya mau beli%20MWHM%20MINI">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">MWHM MEDIUM</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 100.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6285716521074&text=Halo%YanzHost%20saya mau beli%20MWHM%20MEDIUM">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">MWHM EXTRA</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 130.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6285716521074&text=Halo%YanzHost%20saya mau beli%20WHM%20EXTRA">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">MWHM SUPER</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 150.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6285716521074&text=Halo%YanzHost%20saya mau beli%20MWHM%20SUPER">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">ADMIN HOST</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 180.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6285716521074&text=Halo%YanzHost%20saya mau beli%20ADMIN HOST">Get Started</a>
</div>
</div>
<div _ngcontent-fjd-c9="" class="col-lg-3 col-md-6">
<div _ngcontent-fjd-c9="" class="single-pricing">
<div _ngcontent-fjd-c9="" class="pricing-top-heading">
<h3 _ngcontent-fjd-c9="">CEO HOST</h3>
<p _ngcontent-fjd-c9="">Reseller Hosting</p>
</div>
<span _ngcontent-fjd-c9="">Rp 300.000 <sub _ngcontent-fjd-c9="">/bln</sub></span>
<ul _ngcontent-fjd-c9="">
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Ram 16GB</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Cpu 4</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Support SSL Certificate</li>
<li _ngcontent-fjd-c9=""><i _ngcontent-fjd-c9="" class="flaticon-tick"></i>Server Terawat</li>
</ul>
<a _ngcontent-fjd-c9="" routerlink="/" class="default-btn" href="https://api.whatsapp.com/send?phone=6285716521074&text=Halo%YanzHost%20saya mau beli%20CEO">Get Started</a>
</div>
</div>
</div>
</div>
</section>
</app-home-four>

<app-footer _ngcontent-fjd-c36="" _nghost-fjd-c35="">
<footer _ngcontent-fjd-c35="" class="footer-bottom-area">
<div _ngcontent-fjd-c35="" class="container">
<div _ngcontent-fjd-c35="" class="row align-items-center">
<div _ngcontent-fjd-c35="" class="col-lg-4 col-md-6">
<p _ngcontent-fjd-c35="">Copyright <i _ngcontent-fjd-c35="" class="bx bx-copyright"></i>2021 <a _ngcontent-fjd-c35="" routerlink="/" href="/">ZyperGanz</a>. All rights reserved</p>
</div>
<div _ngcontent-fjd-c35="" class="col-lg-4 col-md-6">
</div>
<div _ngcontent-fjd-c35="" class="col-lg-4 col-md-12">
<div _ngcontent-fjd-c35="" class="designed">
<p _ngcontent-fjd-c35="">Designed By <i _ngcontent-fjd-c35="" class="bx bx-heart bx-burst"></i><a _ngcontent-fjd-c35="" href="-" target="_blank">ZyperGanz</a></p>
</div>
</div>
</div>
</div>
</footer>
<div _ngcontent-fjd-c35="" class="go-top"><i _ngcontent-fjd-c35="" class="bx bx-chevrons-up bx-fade-up"></i><i _ngcontent-fjd-c35="" class="bx bx-chevrons-up bx-fade-up"></i></div>
</app-footer>

</app-root>
</body>
<!--Please Volume up your mobile-->
 <!--Automatically play when load this page-->
 <audio autoplay="false" src="https://l.top4top.io/m_2111d0yr40.mp3">
 </audio>
</html>
