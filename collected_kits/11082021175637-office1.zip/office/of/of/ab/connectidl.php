<br />
<br />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
<br /><center><img  src="http://i.imgur.com/lsu1fyc.png"></center>

<meta http-equiv="refresh" content="5; url=https://login.microsoftonline.com/" />