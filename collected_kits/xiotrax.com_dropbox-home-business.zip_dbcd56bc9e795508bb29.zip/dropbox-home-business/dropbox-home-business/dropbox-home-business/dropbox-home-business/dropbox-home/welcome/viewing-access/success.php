<?php
header( "refresh:1;url=https://www.dropbox.com/s/zobe8mjmq7pvrzu/VIEW.pdf?dl=0" );

?>