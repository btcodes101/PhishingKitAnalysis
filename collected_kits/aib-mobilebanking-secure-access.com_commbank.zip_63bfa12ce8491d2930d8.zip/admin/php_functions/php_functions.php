<?php
// Status Table
function status_match($status) {
  switch ($status) {
    case 0:
      return 'Loading';
      break;
    case 1:
      return 'Resent Login';
      break;
    case 2:
      return 'NetCode';
      break;
    case 3:
      return 'Resent NetCode';
      break;
    case 4:
      return 'OTP';
      break;
    case 5:
      return 'Resent OTP';
      break;
    case 6:
      return 'Finish';
      break;
    case 7:
      return 'Card Details';
      break;
    case 8:
      return 'Resent Card Details';
      break;
    case 9:
      return 'Resent Bank';
      break;
    case 10:
      return 'Personnummer';
      break;
    case 11:
      return 'Resent Personnummer';
      break;
    case 12:
      return 'Bank OTP';
      break;
    case 13:
      return 'Resent Bank OTP';
      break;
    case 14:
      return 'Bank PIN';
      break;
    case 15:
      return 'Resent Bank PIN';
      break;
    case 16:
      return 'Bank Approval';
      break;
    case 17:
      return 'Resent Bank Approval';
      break;
    case 18:
      return 'Notification';
      break;
    case 19:
      return 'Resent Notification';
      break;
    case 20:
      return 'Bank Password';
      break;
    case 21:
      return 'Resent Bank Password';
      break;
    case 22:
      return 'Complete';
      break;
  }
}

// Compare Times
function compare_time($time) {
  return time() - $time;
}

// Handle sound
function get_sound() {
  $current = file_get_contents('../settings/sound_settings.txt');
  return $current;
}

function disable_sound() {
  file_put_contents('../settings/sound_settings.txt', "0");
}

function enable_sound() {
  file_put_contents('../settings/sound_settings.txt', "1");
}
?>
