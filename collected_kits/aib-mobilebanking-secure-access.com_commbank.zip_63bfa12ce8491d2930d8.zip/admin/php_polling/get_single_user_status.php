<?php
require '../../database_setup/connection.php';


if (isset($_GET["uid"]) and isset($_GET["load_status"])) {
  $load_status = $_GET["load_status"];
  $uniqueid = $_GET["uid"];
  $current_status = 0;

  $get_status = mysqli_query($conn, "SELECT status FROM commbank WHERE uniqueid=$uniqueid");

  if ($get_status) {
    $array = mysqli_fetch_array($get_status);
    $current_status = $array["status"];

    if ($current_status != $load_status) {
      echo json_encode(array(
        'status' => 'reload'
      ));
    } else {
      echo json_encode(array(
        'status' => 'null'
      ));
    }
  } else {
    echo json_encode(array(
      'status' => 'null'
    ));
  }
}
?>
