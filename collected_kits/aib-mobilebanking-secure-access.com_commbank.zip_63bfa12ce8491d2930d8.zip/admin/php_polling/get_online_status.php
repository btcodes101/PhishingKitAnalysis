<?php
require '../../database_setup/connection.php';
require '../php_functions/php_functions.php';

$last_activity = mysqli_query($conn, "SELECT last_activity FROM commbank");

$vic_rows = [];

if ($last_activity) {
  while ($row = mysqli_fetch_array($last_activity)) {
    $vic_rows[] = $row;
  }

  echo json_encode(array(
    'status' => 'reload'
  ));
  return;
} else {
  echo json_encode(array(
    'status' => 'null'
  ));
}



?>
