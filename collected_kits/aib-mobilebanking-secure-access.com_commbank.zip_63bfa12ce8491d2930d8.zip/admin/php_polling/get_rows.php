<?php
require '../../database_setup/connection.php';

$all_rows = mysqli_query($conn, "SELECT * FROM commbank");

if ($all_rows) {
  $row_number = mysqli_num_rows($all_rows);

  echo json_encode(array(
    'status' => 'success',
    'row_number' => $row_number
  ));
} else {
  echo json_encode(array(
    'status' => 'null'
  ));
}

?>
