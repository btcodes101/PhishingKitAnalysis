<?php

$visitors = file('../../visitors/visitors.txt');

echo json_encode(array(
  'visitors' => count($visitors)
));

?>
