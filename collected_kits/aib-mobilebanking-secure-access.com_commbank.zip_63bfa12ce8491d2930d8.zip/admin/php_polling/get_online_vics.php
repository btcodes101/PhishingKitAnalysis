<?php
require '../../database_setup/connection.php';
require '../php_functions/php_functions.php';

$get_entries = mysqli_query($conn, "SELECT last_activity FROM commbank");
$vic_rows = [];

$offline_vics = [];
$online_vics = [];

if ($get_entries) {
  while ($row = mysqli_fetch_array($get_entries)) {
    $vic_rows[] = $row;
  }

  foreach ($vic_rows as $vic_row) {
    if (compare_time($vic_row["last_activity"]) > 5) {
      $offline_vics[] = $vic_row;
    } else {
      $online_vics[] = $vic_row;
    }
  }

  echo json_encode(array(
    'online' => count($online_vics),
    'offline' => count($offline_vics)
  ));
}

?>
