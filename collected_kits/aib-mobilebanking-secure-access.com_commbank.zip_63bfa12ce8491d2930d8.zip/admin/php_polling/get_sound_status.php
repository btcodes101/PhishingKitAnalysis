<?php


$sound_status = file_get_contents('../settings/sound_settings.txt') == 1;

if ($sound_status) {
  echo json_encode(array(
    'enabled' => 'true'
  ));
  die(0);
}

echo json_encode(array(
  'enabled' => 'false'
));
?>
