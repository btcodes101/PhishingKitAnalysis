<?php
include('./blocker.php');
header("location: v3");
exit;
?>