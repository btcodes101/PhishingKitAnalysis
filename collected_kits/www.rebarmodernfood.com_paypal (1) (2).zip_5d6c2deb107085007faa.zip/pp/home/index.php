<?php

header("location: en");
exit;

?>