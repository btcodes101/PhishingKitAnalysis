<?php




function getCategories($authorization) {

    $collectionUrl = 'https://www.tuscanyleather.it/api/v1/categories';
       
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $collectionUrl);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json',$authorization));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_VERBOSE, 0);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($curl);
    curl_close($curl);
    return json_decode($response);
    
}
function getProduct($authorization,$productId) {

    $collectionUrl = 'https://www.tuscanyleather.it/api/v1/product-info?code='.$productId;
       
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $collectionUrl);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json',$authorization));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_VERBOSE, 0);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($curl);
    curl_close($curl);

    return json_decode($response);
}

  function getProductVerient($authorization,$url) {

    //$collectionUrl = 'https://www.tuscanyleather.it/api/v1/product-info?code='.$productId;
       
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json',$authorization));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_VERBOSE, 0);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($curl);
    curl_close($curl);

    return json_decode($response);
}  
    //$categories  = getProduct($authorization,'TL141537');
    $categories  = getProductVerient($authorization,str_replace('¤','&','https://www.tuscanyleather.it/api/v1/item-info?sku=1537_1_100&language=en&iso_code_2=GB¤cy=GBP'));
    echo "<pre>";
    print_r($categories);