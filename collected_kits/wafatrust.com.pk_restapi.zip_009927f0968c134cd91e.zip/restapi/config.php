<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
set_time_limit(600000);
ini_set('memory_limit', '2256M');
//Modify these
$API_KEY = 'f4dda004439aae9dc813c9d322e6fa5b';
$SECRET = '4fe4450557d01be7e838c7479d91c7f8';
$STORE_URL = 'goodsathomeuk.myshopify.com/';
$secureUrl = "https://".$API_KEY.":".$SECRET."@".$STORE_URL;
$authorization = "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjE2MTA3NiwiaXNzIjoiaHR0cHM6Ly93d3cudHVzY2FueWxlYXRoZXIuaXQvcmVmcmVzaC1hcGktdG9rZW4iLCJpYXQiOjE1NzM1MjA1NDEsImV4cCI6MTg4ODg4MDU0MSwibmJmIjoxNTczNTIwNTQxLCJqdGkiOiJCYWFsb0hPUkswcXZ3b3JVIn0.orGlcRhG-5nbnjxSAKCMw5AK_6uUXqO6cTfWjIcqwAs";

