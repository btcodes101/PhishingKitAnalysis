<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Shopify
 *
 * @author adeelislam
 */
class Shopify {

    //put your code here


    public function findCollection($collections, $title) {

        $found = false;
        foreach ($collections as $collection) {
            if ($collection['title'] == $title) {
                $found = $collection['id'];
                break;
            } else {
                $found = false;
            }
        }
        return $found;
    }

    public function findProduct($products, $stockCode) {
        $found = false;
        foreach ($products as $product) {
            // echo "<br>--" . $product["title"] . " == " . $stockCode;
            if (trim($product["title"]) == trim($stockCode)) {
                $found = $product;
                break;
            } else {
                $found = false;
            }
        }
        return $found;
    }

    public function findVarient($varients, $stockCode) {

        foreach ($varients as $variant) {
            //   echo "<br>--" . $variant["sku"] . " == " . $stockCode;
            if ($variant["sku"] == $stockCode) {
                $found = $variant["id"];
                break;
            } else {
                $found = false;
            }
        }
        return $found;
    }

    function getCollections($collectionUrl) {

        try {
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $collectionUrl);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_VERBOSE, 0);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($curl);
            curl_close($curl);
            return $response;
        } catch (Exception $e) {
            throw new Exception("Invalid URL", 0, $e);
        }
    }

    function getAllProducts($productUrl, $productCountUrl) {

        // gte product count
        $productsCount = 0;
        try {
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $productCountUrl);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_VERBOSE, 0);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($curl);
            curl_close($curl);
            $productsCount = json_decode($response, true);
            //return $response;
        } catch (Exception $ex) {
            throw new Exception("Invalid URL", 0, $ex);
        }
        //print_r($productsCount['count']);exit;
       // $totalProductsList = array();
        ///==================================
        $productCount = $productsCount['count'];
        $page = 1;
        while ($productCount > 0) {
//echo($productUrl . "?limit=30&page=$page");
            try {
                $productCount = $productCount - 250;
                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL, $productUrl . "?limit=250&page=$page");
                curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_VERBOSE, 0);
                curl_setopt($curl, CURLOPT_HEADER, 0);
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                $response = curl_exec($curl);
              
                $productsList = json_decode($response, true);
             //   echo "<pre>";
              //  print_r($productsList);
               // echo ("<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>");
                curl_close($curl);
                foreach ($productsList['products'] as $product) {
                    $totalProductsList[] = $product;
                 //   echo "<br>".count($totalProductsList)."<br>";
                }
                $page++;
                //   return $response;
            } catch (Exception $ex) {
                throw new Exception("Invalid URL", 0, $ex);
            }
        }
        return $totalProductsList;
    }

    function getFeeds($url) {
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_VERBOSE, 0);
            curl_setopt($ch, CURLOPT_USERPWD, $GLOBALS['APIKEY'] . ":" . $GLOBALS['APISECRET']);
            $output = curl_exec($ch);
            curl_close($ch);
            return $output;
        } catch (Exception $ex) {
            throw new Exception("Invalid URL", 0, $ex);
        }
    }

    function createCollection($collectioUrl, $collection) {

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $collectioUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($collection));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function saveProductImage($urlImage, $images) {

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $urlImage);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($images));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function assignProductCollection($collectionAssignUrl, $productCollection) {


        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $collectionAssignUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($productCollection));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function createProduct($productUrl, $product) {

        $classes = $product['classes']['primary'];
        $tags = '';
        foreach ($classes as $key => $value) {
            if ($key != "id") {
                $tags .= $value . ",";
            }
        }

        $tags = rtrim($tags, ",");
        $products_array = array(
            "product" => array(
                'title' => $product['invoiceLine'],
                "product_type" => $product['inventoryType'],
                "metafields_global_title_tag" => $product['invoiceLine'],
                "metafields_global_description_tag" => $product['lineItemDescription'],
                "body_html" => $product['description'],
                "inventoryID" => $product['inventoryID'],
                "vendor" => $product['brand']['name'],
                "published" => true,
                "tags" => $tags,
                "variants" => array(
                    array(
                        "sku" => $product['stockCode'],
                        "price" => $product['price'],
                        "weight" => $product['weight']
                    )
                ),
                "images" => array(
                    array(
                        "src" => $product['imageURL'],
                    )
                )
            )
        );


        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $productUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($products_array));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);

        return $response;
    }

    function createProductVarient($productUrl, $product, $image = null) {
        $option1 = null;
        $option2 = null;
        $price = $this->updatePrice($product[6]);
        if (strpos($product[3], " / ") !== false) {
            $options = explode(" / ", $product[3]);
            $option1 = $options[0];
            $option2 = $options[1];
            if (sizeof($options) > 2) {
                $option3 = $options[2];
            }

            if (!isset($option3)) {
                $option3 = null;
            }
            if (isset($option3)) {
                $variant = array(
                    "variant" => array(
                        "title" => $product[2],
                        "option1" => $option1,
                        "option2" => $option2,
                        "option3" => $option2,
                        "sku" => $product[0],
                        "price" => $price,
                        "barcode" => $product[7],
                        "weight" => $product[5],
                        "inventory_quantity" => $product[4],
                        "image_id" => $image
                    )
                );
            } else if (sizeof($options) == 2 && isset($options[1])) {
                $variant = array(
                    "variant" => array(
                        "title" => $product[2],
                        "option1" => $option1,
                        "option2" => $option2,
                        "sku" => $product[0],
                        "price" => $price,
                        "barcode" => $product[7],
                        "weight" => $product[5],
                        "inventory_quantity" => $product[4],
                        "image_id" => $image
                    )
                );
            } else {

                $variant = array(
                    "variant" => array(
                        "title" => $product[2],
                        "option1" => $option1,
                        "option2" => $option2,
                        "sku" => $product[0],
                        "price" => $price,
                        "barcode" => $product[7],
                        "weight" => $product[5],
                        "inventory_quantity" => $product[4],
                        "image_id" => $image
                    )
                );
            }
        } else {
            $variant = array(
                "variant" => array(
                    "title" => $product[2],
                    "option1" => $product[3],
                    "sku" => $product[0],
                    "price" => $price,
                    "barcode" => $product[7],
                    "weight" => $product[5],
                    "inventory_quantity" => $product[4],
                    "image_id" => $image
                )
            );
        }

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $productUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($variant));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
        $response = json_decode(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $response), true);
        //   echo "<br>===========================<br>";
        return $response;
    }

    function updateProductVarient($productUrl, $product, $image = null) {

        $option1 = null;
        $option2 = null;
        $price = $this->updatePrice($product[6]);
        if (strpos($product[3], " / ") !== false) {
            $options = explode(" / ", $product[3]);
            $option1 = $options[0];
            $option2 = $options[1];
//            $option1 = preg_replace('/[^a-zA-Z0-9\/\/]/', '', $options[0]);
//            $option2 = preg_replace('/[^a-zA-Z0-9\/\/]/', '', $options[1]);
            if (sizeof($options) > 2) {
                //$option3 = preg_replace('/[^a-zA-Z0-9\/\/]/', '', $options[2]);
                $option3 = $options[2];
            }
            if (!isset($option3)) {
                $option3 = null;
            }
            if (isset($option3)) {
                $variant = array(
                    "variant" => array(
                        "title" => $product[2],
                        "option1" => $option1,
                        "option2" => $option2,
                        "option3" => $option2,
                        "sku" => $product[0],
                        "price" => $price,
                        "barcode" => $product[7],
                        "weight" => $product[5],
                        "image_id" => $image
                    // "inventory_quantity" => $product[4]
                    )
                );
            } else if (sizeof($options) == 2 && isset($options[1])) {
                $variant = array(
                    "variant" => array(
                        "title" => $product[2],
                        "option1" => $option1,
                        "option2" => $option2,
                        "sku" => $product[0],
                        "price" => $price,
                        "barcode" => $product[7],
                        "weight" => $product[5],
                        "image_id" => $image
                    // "inventory_quantity" => $product[4]
                    )
                );
            } else {

                $variant = array(
                    "variant" => array(
                        "title" => $product[2],
                        "option1" => $option1,
                        "option2" => $option2,
                        "sku" => $product[0],
                        "price" => $price,
                        "barcode" => $product[7],
                        "weight" => $product[5],
                        // "inventory_quantity" => $product[4],
                        "image_id" => $image
                    )
                );
            }
        } else {
            $variant = array(
                "variant" => array(
                    "title" => $product[2],
                    "option1" => $product[3],
                    "sku" => $product[0],
                    "price" => $price,
                    "barcode" => $product[7],
                    "weight" => $product[5],
                    // "inventory_quantity" => $product[4],
                    "image_id" => $image
                )
            );
        }

        //   var_dump($variant);
//exit;
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $productUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($variant));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
        $response = json_decode(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $response), true);
        return $response;
    }

    function updateProduct($productUrl, $product, $productId) {

        //exit($product);
        $classes = $product['classes']['primary'];
        $tags = '';
        foreach ($classes as $key => $value) {
            if ($key != "id") {
                $tags .= $value . ",";
            }
        }

        $tags = rtrim($tags, ",");
        $products_array = array(
            "product" => array(
                "id" => $productId,
                'title' => $product['invoiceLine'],
                "product_type" => $product['inventoryType'],
                "metafields_global_title_tag" => $product['invoiceLine'],
                "metafields_global_description_tag" => $product['lineItemDescription'],
                "body_html" => $product['description'],
                "vendor" => $product['brand']['name'],
                "published" => true,
                "tags" => $tags,
                "variants" => array(
                    array(
                        "sku" => $product['stockCode'],
                        "price" => $this->updatePrice($product['price']),
                        "inventory_quantity" => "150",
                        "weight" => $product['weight']
                    )
                ),
                "images" => array(
                    array(
                        "src" => $product['imageURL'],
                    )
                )
            )
        );

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $productUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 0);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($products_array));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
        curl_close($curl);
        //echo $response;
        return $response;
    }

    public function updatePrice($price) {

        $updatedPrice = $price;
        if ($price <= 4.5) {
            $updatedPrice = 2.40 * $price;
        } elseif ($price <= 8.95) {
            $updatedPrice = 1.75 * $price;
        } elseif ($price <= 10) {
            $updatedPrice = 1.60 * $price;
        } elseif ($price <= 19.95) {
            $updatedPrice = 1.50 * $price;
        } elseif ($price <= 29.95) {
            $updatedPrice = 1.45 * $price;
        } else {
            $updatedPrice = 1.50 * $price;
        }
        $updatedPricef = 0;
        //-----
        if (round($updatedPrice) == $updatedPrice) {
            $updatedPricef = $updatedPrice + 0.50;
        } elseif ($updatedPrice > round($updatedPrice)) {
            $updatedPricef = round($updatedPrice) + 0.50;
        } elseif ((round($updatedPrice) - 0.10) < $updatedPrice) {
            $updatedPricef = round($updatedPrice) + 0.50;
        } else {
            $updatedPricef = round($updatedPrice) - 0.10;
        }
        return $updatedPricef;
    }

    public function cleanString($str) {

        $newStr = preg_replace('#<a.*?>(.*?)</a>#i', '\1', $str);
        return $newStr;
    }

}
