<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require_once 'config.php';
require_once 'Shopify.php';
$shopify = new Shopify();
$collectioUrl = $secureUrl . "/admin/custom_collections.json";
$productUrl = $secureUrl . "/admin/api/2019-04/products.json";
$productCountUrl = $secureUrl . "/admin/api/2019-10/products/count.json";
$collectionAssignUrl = $secureUrl . "/admin/api/2019-10/collects.json";
echo "<pre>";

//============ get all products 
$productsList = $shopify->getAllProducts($productUrl, $productCountUrl);
//print_r($productsList);exit;
//exit("counts is  = ".count($productsList));
//var_dump($response);exit;
//$productsList = json_decode($response, true);
//$productsList = $productsList["products"];
//exit(sizeof($productsList));
$csvData = array();
$file = fopen('https://ccpapi.ekwholesale.co.uk/stockfeeds/afrwzvhlgk', 'r');
//$file = fopen('2019-10-08T14_27_01+00_00_feed_orignal.csv', 'r');
//$file = fopen('2019-10-08T14_27_01+00_00_feed-1.csv', 'r');
while (($result = fgetcsv($file)) !== false) {
    $csvData[] = $result;
}
echo "<pre>";
$uniqueData = array();
$previous = "";
foreach ($csvData as $data) {

    //echo "<br>===".$previous."----".$data[1];
    if (trim($data[1]) == trim($previous) || $data[1] == "handle") {
        continue;
    } else {
        $uniqueData[] = $data;
        $previous = $data[1];
    }
}
$i = 0;
echo '<pre>';
//print_r($uniqueData);exit;
foreach ($uniqueData as $udata) {
 //   $i++;
//    if ($i > 5) {
//        break;
//    }

    $img = "";
    $baseField = $udata[1];
    $varients = array();
    // update options
    $size[] = array();
    $color[] = array();
    foreach ($csvData as $data) {
        if ($data[1] == $baseField) {
            if (strpos($data[3], " / ") !== false) {
                $options = explode(" / ", $data[3]);
                $option1 = $options[0];
                $option2 = $options[1];
//                $option1 = preg_replace('/[^a-zA-Z0-9\/\/]/', '', $options[0]);
//                $option2 = preg_replace('/[^a-zA-Z0-9\/\/]/', '', $options[1]);
                if (sizeof($options) > 2) {

                    //$option3 = preg_replace('/[^a-zA-Z0-9\/\/]/', '', $options[2]);
                    $option3 = $options[2];
                    $options3[] = $option3;
                }

                $size[] = $option2;
                $color[] = $option1;
            }
        }
    }
    $pOptions = array();

    $product = $shopify->findProduct($productsList, $udata[2]);
    if ($product) {
        //var_dump($product);exit;
        $productId = $product['id'];
        $url = $secureUrl . "/admin/api/2019-07/products/" . $productId . ".json";
        //======================================================== Update product 
        //=================================================================================
//        echo "<br> Product Found<br>";
//        continue;
        if (isset($size) && sizeof($size) > 0 && isset($color) && sizeof($color)) {

            if (sizeof($color) > 3) {
                $color = array_unique($color, SORT_REGULAR);
                $color = array_slice($color, 2);
            }
            if (sizeof($size) > 3) {
                $size = array_unique($size, SORT_REGULAR);
                $size = array_slice($size, 2);
            }
            $options = explode(" / ", $udata[3]);
            if (sizeof($options) > 1) {

                $pOptions[] = array(
                    "name" => "Color",
                    "values" => $color
                );
            }
            if (isset($options[1])) {
                $pOptions[] = array(
                    "name" => "Size",
                    "values" => $size
                );
            }
            if (sizeof($options) > 2) {

                $pOptions[] = array(
                    "name" => "Box",
                    "values" => $options3
                );
                // $option3 = preg_replace('/[^a-zA-Z0-9\/\/]/', '', $options[2]);
                $option3 = $options[2];
            } else {
                // echo "less then 3";
            }
            // var_dump($pOptions);exit;
            $option1 = $options[0];
            $option2 = $options[1];

            $products_array = array(
                "product" => array(
                    'title' => $udata[2],
                    "body_html" => $shopify->cleanString($udata[8]),
                    "vendor" => "ekwholesale",
                    "published" => true,
                    "variants" => $product['variants'],
                    "options" => $pOptions,
                    "images" => array(
                        array(
                            "src" => $udata[9],
                        )
                    )
                )
            );

            $url = $secureUrl . "/admin/api/2019-07/products/" . $productId . ".json";
            //=========== Crul request to update 
            echo "<pre>";
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_VERBOSE, 0);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($products_array));
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $productResponse = curl_exec($curl);
            //var_dump($productResponse);
            //  exit;
            if (isset($productResponse->errors)) {
                print_r($productResponse->errors);
                // exit(json_encode($products_array));
            }
            $productResponse = json_decode(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $productResponse), true);

            curl_close($curl);
        } else {

            //============================================================================== No multiple Varient
            // continue;
            $products_array = array(
                "product" => array(
                    'title' => $udata[2],
                    "body_html" => $shopify->cleanString($udata[8]),
                    "vendor" => "ekwholesale",
                    "published" => true,
                    "variants" => $product['variants'],
                    "images" => array(
                        array(
                            "src" => $udata[9],
                        )
                    )
                )
            );
            //echo $url;
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_VERBOSE, 0);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($products_array));
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $productResponse = curl_exec($curl);
            $productResponse = json_decode(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $productResponse), true);
            //  continue;
            curl_close($curl);
        }

        //// UPdate product Varients
        //===================================================================
        //-- end options
        $urlImage = $secureUrl . "/admin/api/2019-07/products/" . $productId . "/images.json";
        $urlVarient = $secureUrl . "/admin/api/2019-07/products/" . $productId . "/variants.json";

        foreach ($csvData as $data) {

            if ($data[1] == $baseField) {

                $img = $data[9];
                $images = array(
                    "image" => array(
                        "src" => $img
                    )
                );
                $responseProductImage = $shopify->saveProductImage($urlImage, $images);
                $responseProductImage = json_decode($responseProductImage);
                $imageId = null;
                if (!isset($responseProductImage->errors)) {
                    $imageId = $responseProductImage->image->id;
                }

                $varientId = $shopify->findVarient($product['variants'], $udata[0]);

                if ($varientId) {
                    //    echo "<br> Varient Found<br>";
                    $varientUrl = $secureUrl . "/admin/api/2019-10/variants/" . $varientId . ".json";
                    $responseProductVarient = $shopify->updateProductVarient($varientUrl, $data, $imageId);
                } else {
                    //   echo "<br> Varient Not Found<br>";

                    $responseProductVarient = $shopify->createProductVarient($urlVarient, $data, $imageId);
                    //    $responseProductVarient = json_decode($responseProductVarient);
                }
            }
        }
        //================================================================================================================
        //======================================================== Update product ENDS
    } else {
        if (isset($size) && sizeof($size) > 0 && isset($color) && sizeof($color)) {

            if (sizeof($color) > 3) {
                $color = array_unique($color, SORT_REGULAR);
                $color = array_slice($color, 2);
            }
            if (sizeof($size) > 3) {
                $size = array_unique($size, SORT_REGULAR);
                $size = array_slice($size, 2);
            }
            $options = explode(" / ", $udata[3]);
            if (sizeof($options) > 1) {

                $pOptions[] = array(
                    "name" => "Color",
                    "values" => $color
                );
            }
            if (isset($options[1])) {
                $pOptions[] = array(
                    "name" => "Size",
                    "values" => $size
                );
            }
            if (sizeof($options) > 2) {

                $pOptions[] = array(
                    "name" => "Box",
                    "values" => $options3
                );
                //$option3 = preg_replace('/[^a-zA-Z0-9\/\/]/', '', $options[2]);
                $option3 = $options[2];
            } else {
                //   echo "less then 3";
            }

            $option1 = $options[0];
            $option2 = $options[1];
            if (isset($option3)) {
                $varient = array(
                    "title" => $udata[2],
                    "option1" => $option1,
                    "option2" => $option2,
                    "option3" => $option3,
                    "sku" => $udata[0],
                    "price" => $shopify->updatePrice($udata[6]),
                    "barcode" => $udata[7],
                    "weight" => $udata[5],
                    "inventory_quantity" => $udata[4],
                    "images" => array(
                        array(
                            "src" => $udata[9],
                        )
                    )
                );
            } else if (sizeof($options) == 2 && isset($options[1])) {
                $varient = array(
                    "title" => $udata[2],
                    "option1" => $option1,
                    "option2" => $option2,
                    "sku" => $udata[0],
                    "price" => $shopify->updatePrice($udata[6]),
                    "barcode" => $udata[7],
                    "weight" => $udata[5],
                    "inventory_quantity" => $udata[4],
                    "images" => array(
                        array(
                            "src" => $udata[9],
                        )
                    )
                );
            } else {
                $varient = array(
                    "title" => $udata[2],
                    "option1" => $option1,
                    "option2" => $option2,
                    "sku" => $udata[0],
                    "price" => $shopify->updatePrice($udata[6]),
                    "barcode" => $udata[7],
                    "weight" => $udata[5],
                    "inventory_quantity" => $udata[4],
                    "images" => array(
                        array(
                            "src" => $udata[9],
                        )
                    )
                );
            }
//                    var_dump($varient);
//                    exit;
            $products_array = array(
                "product" => array(
                    'title' => $udata[2],
                    "body_html" => $shopify->cleanString($udata[8]),
                    "vendor" => "ekwholesale",
                    "published" => true,
                    "variants" => array(
                        $varient
                    ),
                    "options" => $pOptions,
                    "images" => array(
                        array(
                            "src" => $udata[9],
                        )
                    )
                )
            );
            $varients = array();
            ////========
            echo "<pre>";
            $newproduct  = false;
             $product = $shopify->findProduct($productsList, trim($udata[2]));
            if ($product) {
                continue;
            }else{
                $newproduct  = true;
                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL, $productUrl);
                curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_VERBOSE, 0);
                curl_setopt($curl, CURLOPT_HEADER, 0);
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($products_array));
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                $productResponse = curl_exec($curl);
                if (isset($productResponse->errors)) {
                    print_r($productResponse->errors);
                }
                $productResponse = json_decode(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $productResponse), true);
                // print_r($products_array);
                // print_r($productResponse);
                curl_close($curl);
            }


            // exit;
        } else {
            // continue; 
            //  exit("MOre then 1 varient");
            $products_array = array(
                "product" => array(
                    'title' => $udata[2],
                    "body_html" => $shopify->cleanString($udata[8]),
                    "vendor" => "ekwholesale",
                    "published" => true,
                    "variants" => array(),
                    "images" => array(
                        array(
                            "src" => $udata[9],
                        )
                    )
                )
            );
$newproduct  = false;
            $product = $shopify->findProduct($productsList, trim($udata[2]));
            if ($product) {
                continue;
            }else{
                $newproduct  = true;
                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL, $productUrl);
                curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_VERBOSE, 0);
                curl_setopt($curl, CURLOPT_HEADER, 0);
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($products_array));
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                $productResponse = curl_exec($curl);
                $productResponse = json_decode(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $productResponse), true);
                //  continue;
                if (isset($productResponse->errors)) {
                    print_r($productResponse->errors);
                }
                curl_close($curl);
            }
        }
        // continue;

        if (!isset($productResponse->errors )&& $newproduct) {
            $urlImage = $secureUrl . "/admin/api/2019-07/products/" . $productResponse["product"]['id'] . "/images.json";
            $urlVarient = $secureUrl . "/admin/api/2019-07/products/" . $productResponse["product"]['id'] . "/variants.json";

//            $img = $udata[9];
//            $images = array(
//                "image" => array(
//                    "src" => $img
//                )
//            );
//
//            $responseProductImage = $shopify->saveProductImage($urlImage, $images);
//            $responseProductImage = json_decode($responseProductImage);
//
//            $imageId = null;
//            if (!isset($responseProductImage->errors)) {
//                $imageId = $responseProductImage->image->id;
//                //    echo "<br>===============";
//            }
            //-- end options
            foreach ($csvData as $data) {
                if ($data[1] == $baseField) {
                    $img = $data[9];
                    $images = array(
                        "image" => array(
                            "src" => $img
                        )
                    );
                    $responseProductImage = $shopify->saveProductImage($urlImage, $images);
                    $responseProductImage = json_decode($responseProductImage);
                    $imageId = null;
                    if (!isset($responseProductImage->errors)) {
                        $imageId = $responseProductImage->image->id;
                    }
                    $responseProductVarient = $shopify->createProductVarient($urlVarient, $data, $imageId);
                }
            }
        }
    }
}

fclose($file);


