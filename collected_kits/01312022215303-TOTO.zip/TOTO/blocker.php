<?php


/* BLOCKING HOSTS AND SPIDERS */ 
function _bot_detected($blockedHosts) {
  return (
    isset($_SERVER['HTTP_USER_AGENT'])
    && preg_match('/'.$blockedHosts.'/i', $_SERVER['HTTP_USER_AGENT'])
  );
}

/* SAVE BLOCKED IP IN FILE */
function _save_blocked_ip($file,$ip)
{
        file_put_contents($file,$ip . PHP_EOL , FILE_APPEND);
}