<?php

$EMAIL = 'zikoroot@gmail.com';

$bot_token = "819904934:AAEOe3KW_5TPgcNFlFLBO5tc67nDa42S78E";
$chat_id = "-1001645755881";

$Send_Email = 0;
$Send_telegram = 1;
$Ftp_Write = 0;
	 
	 
?>
