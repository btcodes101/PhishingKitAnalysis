<?php

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];

if(filter_var($client, FILTER_VALIDATE_IP)){
    $ip  = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $ip = $forward;
}
else{
    $ip = $remote;
}

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL,"http://ip-api.com/json/".$ip);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$IP_LOOKUP = json_decode(curl_exec($curl));
curl_close($curl);	

$LOOKUP_CNTRCODE= $IP_LOOKUP->countryCode;



file_put_contents('logs.txt', "[".date('Y-m-d H:i:s')."] ".$LOOKUP_CNTRCODE." - ".$ip. PHP_EOL, FILE_APPEND);

?>
