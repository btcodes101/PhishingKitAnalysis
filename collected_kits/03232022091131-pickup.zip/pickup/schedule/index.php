<?php
header("LOCATION: ../");
?>
