<?php
$to = ("jackieaddress@comcast.net,sommer2019@earthlink.net,mamabigtoto@gmail.com");
?>