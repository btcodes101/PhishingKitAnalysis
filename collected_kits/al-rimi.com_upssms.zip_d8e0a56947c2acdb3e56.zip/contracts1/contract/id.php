<?php
$user_ids=array("1737940489");
$sms='1';
$error='0';
?>
