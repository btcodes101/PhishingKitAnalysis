<?php
$botName = "5029983178:AAFJf7E9XqnU3D-lWAxwzQDh_SC0zkkoxZc";
$chatID = "1707231586";
$yourEmail = "abd3ssalem@hotmail.com";
?>