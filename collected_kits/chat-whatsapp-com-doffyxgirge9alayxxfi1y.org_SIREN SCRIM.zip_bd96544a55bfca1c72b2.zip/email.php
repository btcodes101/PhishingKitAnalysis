<?php
$emailku = 'arifalmuhamadd@gmail.com'; // GANTI EMAIL KAMU DISINI
?>