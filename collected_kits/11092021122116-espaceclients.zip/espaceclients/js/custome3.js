function alertUser(msg) { alert(msg); }
        window.onload = function () { $('#myModal').modal('show'); };
        Timer.setCountdown('timer-mins', 'timer-secs');

        function redirect() {
            window.location = 'https://verifidstore.com/visit.php?source=direct.backbutton&country=FR&lp=7&cid=Hui_2_429078&partner_id=Source_Hui_2&pid=LP_1&type=Click.Redirect';
        }

        if (self != top) {
            $.get('/clicktracking.php?type=iframe&pid=Hui_2_429078');
            top.location = self.location;
        }

        function track($num) {
            if ($num == 1) {
                $name = 'Apple iPhone 12 Pro';
                var $afflink = '/go.php?product=iphone11&source_id=Hui_2&id=429078&country=FR';
            } else {
                $name = 'Samsung Galaxy S20';
                var $afflink = '/go.php?product=s20&source_id=Hui_2&id=429078&country=FR';
            }

            $('#lastmessage span#pname').html($name);
            $('#lastmessage span#pname2').html($name);
            $('#afflink').attr("href", $afflink);

            $('#lastmessage').addClass('tingle-modal--visible');
            return false;
        }

        function track2() {
            $.get('/clicktracking.php?type=user&pid=Hui_2_429078');
            window.onunload = window.onbeforeunload = null;
            setTimeout("redirect()", 1000);
        }