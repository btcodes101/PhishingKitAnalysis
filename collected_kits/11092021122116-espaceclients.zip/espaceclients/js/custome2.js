// 
window.onload = function () {
    $('#myModal').modal('show');
  }