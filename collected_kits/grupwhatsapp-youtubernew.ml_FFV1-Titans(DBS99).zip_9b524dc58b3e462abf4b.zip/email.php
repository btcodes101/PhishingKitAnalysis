<?php
$emailku = 'uhdukbaty@gmail.com'; 
?>