<?
header("Location: logowanie.php?652109458356bvhgfpmlsfsads848nghuty");
die();
?>