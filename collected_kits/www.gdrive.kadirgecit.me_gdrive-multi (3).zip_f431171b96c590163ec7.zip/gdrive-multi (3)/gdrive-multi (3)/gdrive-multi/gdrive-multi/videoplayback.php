<?php
	//if (stristr($_SERVER['HTTP_REFERER'],"ancokplayer.win") || 
    //stristr($_SERVER['HTTP_REFERER'],"yourdomainname.com")|| 
    //stristr($_SERVER['HTTP_REFERER'],"yourdomainname.com")) {   
;?>
<!DOCTYPE html><html><head><title>Gdrive Multi Iframe Embed</title><meta name="robots" content="noindex"><meta name="robots" content="noindex"><meta name="referrer" content="never"/><meta name="referrer" content="no-referrer"/><link rel="shortcut icon" href="favicon.png" type="image/x-icon" /><style type="text/css" media="screen">html,body{background:#000;padding:0;margin:0;width:100%;height:100%;overflow:hidden;}.wrapper{position:relative;}.ancok-iframe{position:absolute !important;height:100%;width:100%;}.videocontent,#video_player{width:100%;height:100%;}.jwplayer{margin:0;position:fixed !important}@media only screen and (max-width: 450px) {.jw-settings-topbar .jw-settings-close { margin-right: 30px; !important}}.videocontent{position: relative;color: #fff;}#list-server-more{z-index: 1;padding: 10px 0 0 0;position: absolute;color: #fff;top: 0;right: 8px;text-align: right;font-family: Arial, Helvetica, sans-serif;} #show-server{color: #fff;padding: 5px 15px;font-size: 10px;background: url('icon.png') no-repeat center center;z-index:999999}.list-server-items{margin-top: 10px;background: rgba(0, 0, 0, .7);}.list-server-items li {cursor: pointer;padding: 6px 5px 6px 15px;color: #ccc;text-align: right;list-style: none;border-top: solid 1px #20201f;font-size: 13px;} .list-server-items li.active, .list-server-items li:hover{color: #fff;} #load-iframe{display: none;position: relative;}.list-server-items li:first-child{border: 0;}</style><!--<script type="text/javascript" src="https://content.jwplatform.com/libraries/SPrnWq3s.js"></script>--><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" type="text/javascript"></script><script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script><!--<script type="text/javascript">var default_resolution='480';var refreshPlayers = true;var refreshPlayersTime = 500;var collection = true;var domain = 'lidplay.net';var providers = ['vk.com/video_ext.php','vk.me/video_ext.php','new.vk.com/video_ext.php','vkontakte.ru/video_ext.php','drive.google.com','docs.google.com','vimeo.com','player.vimeo.com','my.mail.ru','videoapi.my.mail.ru','video.mail.ru','www.mp4upload.com','facebook.com/plugins/video.php','ok.ru/videoembed','embed.publicvideohost.org','www.dailymotion.com',	'www.dropbox.com','www.stormo.tv','embed.redtube.com','xhamster.com','flashservice.xvideos.com','www.xvideos.com','www.porn.com','www.pornhub.com','www.youporn.com','www.tube8.com','player.tnaflix.com'];!function(){function t(t){var e=[];for(var r in t)e.push(encodeURIComponent(r)+"="+encodeURIComponent(t[r]));return e.join("&")}function e(t,e){return t.indexOf(e)>-1}function r(t,r){if("[object String]"==Object.prototype.toString.call(r))return e(t,r);for(var l=0;l<r.length;l++)if(e(t,r[l]))return!0;return!1}function l(){for(var l=document.getElementsByTagName("iframe"),i=0;i<l.length;i++)if(!e(l[i].src,domain)&&r(l[i].src,providers)&&(s=l[i],void 0,void 0,void 0,n=s.getBoundingClientRect(),a=n.top,b=n.bottom,a<window.innerHeight&&b>=0)&&(u=l[i],"none"!==window.getComputedStyle(u).display)){var o={url:l[i].src,collection:collection,default_resolution:default_resolution,referrer:window.location.href};l[i].getAttribute("subtitles")?o.subtitles=l[i].getAttribute("subtitles"):delete o.subtitles,l[i].getAttribute("subtitles_src")?o.subtitles_src=l[i].getAttribute("subtitles_src"):delete o.subtitles_src,l[i].getAttribute("subtitles_label")?o.subtitles_label=l[i].getAttribute("subtitles_label"):delete o.subtitles_label,l[i].getAttribute("default_resolution")?o.default_resolution=l[i].getAttribute("default_resolution"):delete o.default_resolution,l[i].getAttribute("start")?o.start=l[i].getAttribute("start"):delete o.start,l[i].getAttribute("autoplay")?o.autoplay=l[i].getAttribute("autoplay"):delete o.autoplay,l[i].src="//"+domain+"/video/?"+t(o),l[i].setAttribute("allowfullscreen",""),l[i].setAttribute("mozallowfullscreen",""),l[i].setAttribute("webkitallowfullscreen",""),l[i].removeAttribute("sandbox")}var u,s,n,a,b}l(),refreshPlayers&&setInterval(l,refreshPlayersTime)}();</script>--></head><body><div class="wrapper"><div class="videocontent"><script type="text/javascript">eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('A a=["\\p\\g\\b\\k\\b\\v\\d\\S\\b\\o\\c\\B\\i\\d","\\d\\j\\q\\q\\i\\b","\\C\\i\\e\\f\\d\\m\\f\\b\\g\\k\\b\\g\\m\\e\\d\\b\\l\\f","\\r\\i\\e\\r\\T","\\s\\f\\n\\j\\D\\m\\f\\b\\g\\k\\b\\g","\\h\\c\\d\\c\\m\\k\\e\\h\\b\\j","\\c\\d\\d\\g","\\h\\c\\d\\c\\m\\f\\d\\c\\d\\B\\f","\\c\\r\\d\\e\\k\\b","\\n\\c\\f\\E\\i\\c\\f\\f","\\n\\e\\h\\b","\\e\\o\\g\\c\\l\\b","\\C\\k\\e\\h\\b\\j\\r\\j\\v\\d\\b\\v\\d\\F\\e\\l\\q","\\f\\g\\r","","\\k\\e\\h\\b\\j\\J\\p\\i\\c\\t\\b\\g","\\q\\b\\d\\U\\i\\b\\l\\b\\v\\d\\V\\t\\W\\h","\\p\\i\\c\\t","\\f\\n\\j\\D","\\s\\k\\e\\h\\b\\j\\J\\p\\i\\c\\t\\b\\g","\\f\\d\\j\\p","\\s\\i\\j\\c\\h\\m\\e\\o\\g\\c\\l\\b","\\s\\i\\j\\c\\h\\m\\e\\o\\g\\c\\l\\b\\F\\e\\o\\g\\c\\l\\b","\\g\\b\\l\\j\\k\\b\\E\\i\\c\\f\\f","\\C\\i\\e\\f\\d\\m\\f\\b\\g\\k\\b\\g\\m\\e\\d\\b\\l\\f\\F\\i\\e","\\c\\h\\h\\E\\i\\c\\f\\f","\\D\\e\\h\\d\\n","\\s\\b\\l\\X\\b\\h\\k\\e\\h\\b\\j","\\n\\b\\e\\q\\n\\d","\\g\\b\\c\\h\\t","\\o\\c\\h\\b\\Y\\B\\d"];$(w)[a[Z]](u(){G();$(a[4])[a[3]](u(x){x[a[0]]();$(a[2])[a[1]]()});$(a[K])[a[3]](u(x){x[a[0]]();A L=$(y)[a[6]](a[5]);A H=$(y)[a[6]](a[7]);z($(y)[a[9]](a[8])){1a 1b}I{$(a[11])[a[10]]();$(a[12])[a[10]]();$(a[11])[a[6]](a[13],a[14]);z(w[a[16]](a[15])){z(H==0){M[a[17]]();$(a[19])[a[18]]()}I{M[a[1c]]();$(a[19])[a[10]]()}};z(H==1){$(a[N])[a[18]]();$(a[O])[a[18]]();$(a[O])[a[6]](a[13],L)}I{$(a[N])[a[10]]()};G()};$(a[K])[a[1d]](a[8]);$(y)[a[1e]](a[8])});$(a[P])[a[Q]]($(w)[a[Q]]());$(a[P])[a[R]]($(w)[a[R]]())});u G(){1f(u(){$(a[2])[a[1g]]()},1h)}',62,80,'||||||||||_0x8e85|x65|x61|x74|x69|x73|x72|x64|x6C|x6F|x76|x6D|x2D|x68|x66|x70|x67|x63|x23|x79|function|x6E|document|_0xf5bfx1|this|if|var|x75|x2E|x77|x43|x20|closeServer|_0xf5bfx3|else|x5F|24|_0xf5bfx2|playerInstance|21|22|27|26|28|x44|x6B|x45|x42|x49|x62|x4F|29|||||||||||return|false|20|23|25|setTimeout|30|3000'.split('|'),0,{}))</script>
        <?php 
		error_reporting(0);
		function encrypte($string,$key){
    $returnString = "";
    $charsArray = str_split("e7NjchMCEGgTpsx3mKXbVPiAqn8DLzWo_6.tvwJQ-R0OUrSak954fd2FYyuH~1lIBZ");
    $charsLength = count($charsArray);
    $stringArray = str_split($string);
    $keyArray = str_split(hash('sha256',$key));
    $randomKeyArray = array();
    while(count($randomKeyArray) < $charsLength){
        $randomKeyArray[] = $charsArray[rand(0, $charsLength-1)];
    }
    for ($a = 0; $a < count($stringArray); $a++){
        $numeric = ord($stringArray[$a]) + ord($randomKeyArray[$a%$charsLength]);
        $returnString .= $charsArray[floor($numeric/$charsLength)];
        $returnString .= $charsArray[$numeric%$charsLength];
    }
    $randomKeyEnc = '';
    for ($a = 0; $a < $charsLength; $a++){
        $numeric = ord($randomKeyArray[$a]) + ord($keyArray[$a%count($keyArray)]);
        $randomKeyEnc .= $charsArray[floor($numeric/$charsLength)];
        $randomKeyEnc .= $charsArray[$numeric%$charsLength];
    }
    return $randomKeyEnc.hash('sha256',$string).$returnString;
}
//Split link
function split_link($link) {
	$spilt = chunk_split($link, 500, "=");
	$array = explode('=', $spilt);
	foreach($array as $i => $data) {
		$list .= 'link'.($i+1).'='.$data.'&';
	}
	$split_link = rtrim($list, '&');
	return $split_link;
}

		$data = (isset($_GET['id'])) ? $_GET['id'] : '';
		if ($data != '') {
			include_once 'library.php';
			require_once 'packer.php';			
			include_once 'curl.php';
			$data = json_decode(decode($data));
			$link = (isset($data->link)) ? $data->link : '';
			$link2 = (isset($data->link2)) ? $data->link2 : '';
			$link3 = (isset($data->link3)) ? $data->link3 : '';
			if(empty($link3)) {
                        $link3 = 'video-not-found.mp4';
                        }	        
			$link4 = (isset($data->link4)) ? $data->link4 : '';
			$link5 = (isset($data->link5)) ? $data->link5 : '';
			$link6 = (isset($data->link6)) ? $data->link6 : '';
			if(empty($link6)) {
                        $link6 = 'video-not-found.mp4';
                        }
                        $link7 = (isset($data->link7)) ? $data->link7 : '';
                        if(empty($link7)) {
                        $link7 = 'video-not-found.mp4';
                        }
			$backup = (isset($data->backup)) ? $data->backup : '';
			$link = str_replace("&amp;","&",$link);			
			$file_id = (strpos($link, '?id=') > 0) ? parse_param('id', $link) : explode('/', $link)[5];
			$file_id1 = (strpos($link5, '?id=') > 0) ? parse_param('id', $link5) : explode('/', $link5)[5];
			$file_id2 = (strpos($link2, '?id=') > 0) ? parse_param('id', $link2) : explode('/', $link2)[5];
			$file_id3 = (strpos($link4, '?id=') > 0) ? parse_param('id', $link4) : explode('/', $link4)[5];
			$file_id_backup = (strpos($backup, '?id=') > 0) ? parse_param('id', $backup) : explode('/', $backup)[5];
			$acok = "https://www.googleapis.com/drive/v3/files/".$file_id."?alt=media&key=AIzaSyBFHimHWDyLOtcNJjA268KwRLhsBuckUxc";
			$link_source = 'sources:[{file: "redirector.php?'.split_link(encrypte($acok,'uplaycrypt')).'",label: "Auto","type" : "video/mp4"},{file: "redirector.php?'.split_link(encrypte($a,'uplaycrypt')).'",label: "Auto","type" : "video/mp4"}]';
	        $bcok = "https://www.googleapis.com/drive/v3/files/".$file_id2."?alt=media&key=AIzaSyBFHimHWDyLOtcNJjA268KwRLhsBuckUxc";
	        $link2_source = 'sources:[{file: "redirector.php?'.split_link(encrypte($bcok,'uplaycrypt')).'",label:"ORIGINAL","type":"video/mp4"}]';
	        $ccok = "https://www.googleapis.com/drive/v3/files/".$file_id3."?alt=media&key=AIzaSyDdoetN4aDmDBc6Y11CUGK4nhZ0pvZbXOw";
	        $link4_source = 'sources:[{file: "redirector.php?'.split_link(encrypte($ccok,'uplaycrypt')).'",label:"ORIGINAL","type":"video/mp4"}]';
		$link5_source = curl("https://ancokplayer.win/api-gdrive/api-drive-photos.php?url=".$link5);
		$img = "https://drive.google.com/thumbnail?sz=w900-h500-n&id=".$file_id_backup;
                $ch = curl_init($img);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($ch, CURLOPT_HEADER, TRUE); 
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, FALSE); 
                $response = curl_exec($ch);
                preg_match_all('/^Location:(.*)$/mi', $response, $matches);
                curl_close($ch);
                $kimak = !empty($matches[1]) ? trim($matches[1][0]) : 'https://cdn.maxdeliver.net/nontongo.win/adrive/api-new/fireup4u.jpg';
                $download_link = (isset($data->download_link)) ? $data->download_link : '';
                $sub = (isset($data->sub)) ? $data->sub : '';
			$player_mode = (isset($data->player_mode)) ? $data->player_mode : '';
			$cbackup = "https://www.googleapis.com/drive/v3/files/".$file_id_backup."?alt=media&key=AIzaSyDdoetN4aDmDBc6Y11CUGK4nhZ0pvZbXOw";
			$backup_source = 'sources:[{file: "redirector.php?'.split_link(encrypte($cbackup,'uplaycrypt')).'",label: "ORIGINAL","type" : "video/mp4"}]';
			//$linkhls = curl("https://ancokplayer.win/mirror/index.php?url=".$backup."&sub=".$sub."");			
			$linkhls = curl("https://ancokplayer.win/mirror/index.php?url=".$backup."&sub=".$sub."");
			//$linkhlsx = 'redirector.php?'.split_link(encrypte(''.$linkhls.'?sub='.$sub.'&cv='.$kimak.'','uplaycrypt')).'';
			$linkhlsx = 'redirector.php?'.split_link(encrypte($linkhls,'uplaycrypt')).'';
			$cbackup = curl('https://ancokplayer.win/mirror/index.php?url='.$backup.'&sub='.$sub.''); 
                        $linkhlsx2 = 'redirector.php?'.split_link(encrypte($cbackup,'uplaycrypt')).'';  
                        $cbackup = curl('https://ancokplayer.win/mirror/index.php?url='.$backup.'&sub='.$sub.'');  
                        $linkhlsx3 = 'redirector.php?'.split_link(encrypte($cbackup,'uplaycrypt')).'';
                        $images = "https://drive.google.com/thumbnail?sz=w900-h500-n&id=$file_id_backup";                                 
                        $poster = 'redirector.php?'.split_link(encrypte($images,'uplaycrypt')).'';
			$result = '
<script src="assets/js/jwplayer.js"></script><script src="assets/js/ancok.min.js"></script><script>jwplayer.key="wpQXdESCunE0nwJMhdMB1ryBqrfiOKyLNtRY/5vR0JCTrZ+B";</script><div id="list-server-more"><a href="javascript:void(0)" id="show-server" title="Alternative Servers"></a><ul class="list-server-items"><li class="active"  data-status="0" data-video="">Main Server</li><li data-status="1" data-video="'.$linkhlsx.'">Server HD1</li><li data-status="1" data-video="'.$linkhlsx2.'">Server HD2</li><li data-status="1" data-video="'.$linkhlsx3.'">Server HD3</li><li data-status="1" data-video="'.$link3.'">Server Alt1</li><li data-status="1" data-video="'.$link6.'">Server Alt2</li><li data-status="1" data-video="'.$link7.'">Server Alt3</li></ul></div>
<div id="load-iframe"><iframe id="embedvideo" src="" allowfullscreen="true" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" style="width:100%;height:100%"></iframe></div><div id="video_player"></div>';
			$data = '
            var playerInstance = jwplayer("video_player");
            var countplayer = 1;
            var countcheck = 0;
            playerInstance.setup({
                sources:['.$link5_source.'],image:"'.$kimak.'",stretching:"uniform",aspectratio: "",width:"100%",height:"100%",autostart:"false",tracks: [{ 
            file: "getsub.php?sub='.$sub.'", 
            label: "'.$player_mode.'",
            kind: "captions",
            "default": true 
        }],
        advertising:
		{
		client:"vast",admessage:"This is an ad pod. This ad ends in xx seconds.",schedule:
			{
			adbreak1:
				{
				offset:"pre",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,adbreak2:
				{
				offset:"50%",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,
		}
	},
        captions: {color: "#FFFF00",fontSize: 14, edgeStyle:"raised",backgroundOpacity: 0,},
                        });
            playerInstance.onError(function(){
                countcheck ++;
                console.log("countcheck:"+countcheck);
                console.log("countplayer:"+countplayer);
                if(countcheck < 4){
                    playerInstance.load();
                    playerInstance.play();
                }
                if(countplayer == 1 && countcheck== 2){
                    console.log("load link backup");
                    countcheck = 0;
                    countplayer ++;
                    playerInstance.load({
                        '.$backup_source.',image:"'.$kimak.'",stretching:"uniform",aspectratio: "",width:"100%",height:"100%",autostart:"false",
                        tracks: [{ 
            file: "getsub.php?sub='.$sub.'", 
            label: "'.$player_mode.'",
            kind: "captions",
            "default": true 
        }],
        advertising:
		{
		client:"vast",admessage:"This is an ad pod. This ad ends in xx seconds.",schedule:
			{
			adbreak1:
				{
				offset:"pre",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,adbreak2:
				{
				offset:"50%",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,
		}
	},
        captions: {color: "#FFFF00",fontSize: 14, edgeStyle:"raised",backgroundOpacity: 0,},
                                    });
                    playerInstance.play();
                }
				if(countplayer == 2 && countcheck== 2){
                    console.log("load link4");
                    countcheck = 0;
                    countplayer ++;
                    playerInstance.load({
                        '.$link2_source.',image:"'.$kimak.'",stretching:"uniform",aspectratio: "",width:"100%",height:"100%",autostart:"true",
                        tracks: [{ 
            file: "getsub.php?sub='.$sub.'", 
            label: "'.$player_mode.'",
            kind: "captions",
            "default": true 
        }],
        advertising:
		{
		client:"vast",admessage:"This is an ad pod. This ad ends in xx seconds.",schedule:
			{
			adbreak1:
				{
				offset:"pre",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,adbreak2:
				{
				offset:"50%",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,
		}
	},
        captions: {color: "#FFFF00",fontSize: 14, edgeStyle:"raised",backgroundOpacity: 0,},
                                    });
                    playerInstance.play();
                }
				if(countplayer == 3 && countcheck== 3){
                    console.log("load link5");
                    countcheck = 0;
                    countplayer ++;
                    playerInstance.load({
                        '.$link4_source.',image:"'.$kimak.'",stretching:"uniform",aspectratio: "",width:"100%",height:"100%",autostart:"true",
                        tracks: [{ 
            file: "'.$sub.'", 
            label: "'.$player_mode.'",
            kind: "captions",
            "default": true 
        }],
        advertising:
		{
		client:"vast",admessage:"This is an ad pod. This ad ends in xx seconds.",schedule:
			{
			adbreak1:
				{
				offset:"pre",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,adbreak2:
				{
				offset:"50%",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,
		}
	},
        captions: {color: "#FFFF00",fontSize: 14, edgeStyle:"raised",backgroundOpacity: 0,},
                                    });
                    playerInstance.play();
                }
                if(countplayer == 4 && countcheck== 4){
                    console.log("load source sv");

                    playerInstance.setup({
                        '.$link_source.',
                        image:"'.$kimak.'",stretching:"uniform",aspectratio: "",width:"100%",height:"100%",autostart:"true",tracks: [{ 
            file: "getsub.php?sub='.$sub.'", 
            label: "'.$player_mode.'",
            kind: "captions",
            "default": true 
        }],
        advertising:
		{
		client:"vast",admessage:"This is an ad pod. This ad ends in xx seconds.",schedule:
			{
			adbreak1:
				{
				offset:"pre",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,adbreak2:
				{
				offset:"50%",tag:""
			}
			,overlay:
				{
				offset:"5",tag:"overlay.xml",type:"nonlinear"
			}
			,
		}
	},
        captions: {color: "#FFFF00",fontSize: 14, edgeStyle:"raised",backgroundOpacity: 0,},
                                        });
                    playerInstance.on("error",function(){$("#video_player").html("<div class=\"ancok-iframe\"> <iframe src=\"'.$linkhlsx.'\" width=\"100%\" height=\"100%\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" class=\"ancok-box\"></iframe><div class=\"ancok-logo-top-right\"></div></div>")});                  
                    
                }

            });
            
            playerInstance.addButton(
                "https://ancokplayer.win/demo/openload/assets/img/download.svg",
                "Download Video",
                function() {
                    window.open(
                        "'.$download_link.'",
                        "_blank"
                    );
                },
                "download"
            );
       
	
	';

			$packer = new Packer($data, 'Normal', true, false, true);

			$packed = $packer->pack();

			$result .= '<script type="text/javascript">' . $packed . '</script>';

			echo $result;

		} else echo 'Empty link!';
?>
</div>    
</div>
</body>
</html>
<?php
//}
//else echo '<!DOCTYPE html><html><head><title>403 Forbidden</title><style>@import url("https://fonts.googleapis.com/css?family=Share+Tech+Mono|Montserrat:700");*{margin:0;padding:0;border:0;font-size: 100%;font:inherit;vertical-align:baseline;box-sizing:border-box;color:inherit;}body{  background-image: linear-gradient(120deg,#4f0088 0%,#000000 100%);height:100vh;}h1{font-size:45vw;text-align:center;position:fixed;width:100vw;z-index:1;color:#ffffff26;text-shadow:0 0 50px rgba(0, 0, 0, 0.07);top:50%;   transform: translateY(-50%);font-family:"Montserrat",monospace;}div{background:rgba(0, 0, 0, 0);width:70vw;    position: relative;top:50%;transform:translateY(-50%);margin:0 auto;padding:30px 30px 10px;box-shadow:0 0 150px -20px rgba(0, 0, 0, 0.5);z-index:3;}p{font-family:"Share Tech Mono", monospace;color:#f5f5f5;margin:0 0 20px;   font-size:17px;line-height:1.2;}span{color:#f0c674;}i{color:#8abeb7;}div a{text-decoration: none;}b{color:#81a2be;}a.avatar{position:fixed;bottom:15px;right: -100px;animation: slide 0.5s 4.5s forwards;display:block;z-index:4}a.avatar img {border-radius:100%;width:44px;border:2px solid white;}@keyframes slide{from{right:-100px;transform:rotate(360deg);opacity:0;}to{right:15px;transform:rotate(360deg);opacity:1;}}</style><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script></head><body><h1>403</h1><div><p>><span>ERROR CODE</span>: "<i>HTTP 403 Forbidden</i>"</p><p>> <span>ERROR DESCRIPTION</span>: "<i>Access Denied. You Do Not Have The Permission To Access This Page On This Server</i>"</p><p>> <span>ERROR POSSIBLY CAUSED BY</span>: [<b>Your domain not listed in our database!, execute access forbidden, read access forbidden, write access forbidden, ssl required, ssl 128 required, ip address rejected, client certificate required, site access denied, too many users, invalid configuration, password change, mapper denied access, client certificate revoked, directory listing denied, client access licenses exceeded, client certificate is untrusted or invalid, client certificate has expired or is not yet valid, passport logon failed, source access denied, infinite depth is denied, too many requests from the same client ip</b>...]</p><p>> <span>POWERED BY</span>: [<a href="https://ancokplayer.win" id="ancokplayer">ANCOKPLAYER.WIN</a>, <a href="https://ancokplayer.win/about">ABOUT US</a>, <a href="https://ancokplayer.win/contact">CONTACT US</a>...]</p><p>> <span>HAVE A NICE DAY SIR AXLEROD :-)</span></p></div><a class="avatar ancok-player" id="ancok-player" href="https://ancokplayer.win/" title="What are you looking for Sir AXLEROD?"><img src="https://i.imgur.com/7XWsEGy.png"/></a></body></html>';
?>