<?php
session_start();
/* DECLARE VARIABLES */
$username = 'admin';
$password = 'admin123';
$random1 = 'secret_key1';
$random2 = 'secret_key2';
$hash = md5($random1 . $password . $random2);
$self = $_SERVER['REQUEST_URI'];
/* USER LOGOUT */
if(isset($_GET['logout']))
{
	unset($_SESSION['login']);
}
/* USER IS LOGGED IN */
if (isset($_SESSION['login']) && $_SESSION['login'] == $hash)
{
	logged_in_msg($username);
}
/* FORM HAS BEEN SUBMITTED */
else if (isset($_POST['submit']))
{
	if ($_POST['username'] == $username && $_POST['password'] == $password)
	{
		//IF USERNAME AND PASSWORD ARE CORRECT SET THE LOGIN SESSION
		$_SESSION["login"] = $hash;
		header("Location: $_SERVER[PHP_SELF]");
	}
	else
	{
		// DISPLAY FORM WITH ERROR
		display_login_form();
		display_error_msg();
	}
}
/* SHOW THE LOGIN FORM */
else
{
	display_login_form();
}
/* TEMPLATES */
function display_login_form()
{
?><!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="https://cdn.staticaly.com/gh/domkiddie/drive/master/assets/img/favicon.png"> 
    <!-- Meta -->
    <meta name="description" content="Ancok Google Drive Player Multi Backup Function with Subtitles Manager Integrated">
    <meta name="author" content="AncokNamhay">
    <meta property="og:image" content="https://ancokplayer.win/wp-content/uploads/edd/2018/12/new-google-drive-player-with-multi-backup.jpg">
    <title>Google Drive Player With Multi Backup Function</title>    
     <link href="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <script src="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/jquery/jquery.min.js"></script>
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/dataTables.bootstrap.min.js"></script>
	<link href="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/datatables.net-dt/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css" rel="stylesheet">	
    <link rel="stylesheet" href="https://cdn.staticaly.com/gh/domkiddie/drive/master/css/bracket.css">
    <link rel="stylesheet" href="https://cdn.staticaly.com/gh/domkiddie/drive/master/css/bracket.simple-white.css">	
	<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>  
    <![endif]-->        
      </head>
 <body>
<div class="d-flex align-items-center justify-content-center bg-gray-200 ht-100v">
      <div class="login-wrapper wd-300 wd-xs-350 pd-25 pd-xs-40 bg-white rounded shadow-base">
        <div class="signin-logo tx-center tx-28 tx-bold tx-inverse"><span class="tx-normal">[</span> Gdrive <span class="tx-info">Player</span> <span class="tx-normal">]</span></div>
        <div class="tx-center mg-b-20">Ancok Google Drive Player Multi Backup Function with Subtitles Manager Integrated</div>		
<?php echo '<form action="' . isset($self) . '" method="post">' .
             '<div class="form-group">'.
			 '<input type="text" name="username" id="username" class="form-control" placeholder="Enter your username" required>' .
			 '</div>'.
			 '<div class="form-group">'.
			 '<input type="password" name="password" id="password" class="form-control" placeholder="Enter your password" required>' .
			 '</div>'.
			 '<button type="submit" name="submit" class="btn btn-info btn-block">Sign In</button>' .
			 '<center><p><br><span class="tx-success tx-13 tx-bold">No View Limit Anymore :) Enjoy !</span></p></center>'.
		 '</form>';
}
function logged_in_msg($username)
{
?><!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="https://cdn.staticaly.com/gh/domkiddie/drive/master/assets/img/favicon.png">    
    <!-- Meta -->
    <meta name="description" content="Ancok Google Drive Player Multi Backup Function with Subtitles Manager Integrated">
    <meta name="author" content="AncokNamhay">
    <meta property="og:image" content="https://ancokplayer.win/wp-content/uploads/edd/2018/12/new-google-drive-player-with-multi-backup.jpg">
    <title>Google Drive Player With Multi Backup Function</title>    
    <link href="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <script src="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/jquery/jquery.min.js"></script>
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/dataTables.bootstrap.min.js"></script>
	<link href="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/datatables.net-dt/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css" rel="stylesheet">	
    <link rel="stylesheet" href="https://cdn.staticaly.com/gh/domkiddie/drive/master/css/bracket.css">
    <link rel="stylesheet" href="https://cdn.staticaly.com/gh/domkiddie/drive/master/css/bracket.simple-white.css">	
	<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>  
    <![endif]-->        
      </head>
 <body>
    <div class="br-logo"><a href="<?php echo $domainServer;?>"><span>[</span>Gdrive <i>Player</i><span>]</span></a></div>
    <div class="br-sideleft sideleft-scrollbar">
      <label class="sidebar-label pd-x-10 mg-t-20 op-3">Navigation</label>
      <ul class="br-sideleft-menu">
        <li class="br-menu-item">
          <a href="<?php echo $actual_link;?>" class="br-menu-link active">
            <i class="menu-item-icon icon ion-ios-home-outline tx-24"></i>
            <span class="menu-item-label">Dashboard</span>
          </a><!-- br-menu-link -->
        </li><!-- br-menu-item --> 
        <li class="br-menu-item">
          <a href="<?php echo $actual_link;?>add_sub.php?action=add_subtitle" class="br-menu-link">
            <i class="menu-item-icon icon ion-ios-list-outline tx-24"></i>
            <span class="menu-item-label">Subtitle Manager</span>
          </a><!-- br-menu-link -->
        </li><!-- br-menu-item -->
      </ul><!-- br-sideleft-menu -->
      <br>
      <li class="br-menu-item">
          <a href="#" class="br-menu-link active">
            <i class="menu-item-icon icon ion-ios-gear-outline tx-24"></i>
            <span class="menu-item-label">How It Work:</span>
          </a><!-- br-menu-link -->
        </li><!-- br-menu-item --> 
        <br>
      <div class="info-list">
          <p><span class="tx-danger">No View Limit Anymore :) Enjoy</span></p>	  
<p>1. When <span class="tx-info">the first google drive url get an error</span>, it will immediately load the the second drive url</p>
<p>2. When <span class="tx-info">the second drive url get error</span> then it will instantly load the third google drive url</p>
<p>3. <span class="tx-info">When the third google drive url get an error</span> then it will load fourth google drive url</p>
<p>4. <span class="tx-info">When the fourth google drive url get an error</span> then it will load 
fifth google drive url</p>
<p>5. <span class="tx-info">When the fifth google drive url get an error</span> then it will load Sweet Alert Notificaton function! </p> </p>
<p>6. If 1, 2, 3, 4, 5 get an error the visitor still able to watch the movie by clicking button options on your player. </p>
<p>7. <span class="tx-danger font-weight-bold">If all video get an error just shutdown your Computer then go to sleep !</span> </p>
        <div class="info-list-item">
		<?php echo '<i class="menu-item-icon icon ion-ios-person"></i> <b>' . $username . '</b></p>';?> 
        </div><!-- info-list-item -->
      </div><!-- info-list -->
      <br>
    </div><!-- br-sideleft -->
    <div class="br-header">
      <div class="br-header-left">
        <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href=""><i class="icon ion-navicon-round"></i></a></div>
        <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href=""><i class="icon ion-navicon-round"></i></a></div>		
      </div><!-- br-header-left -->
      <div class="br-header-right">
        <nav class="nav">
          <div class="dropdown">
            <a href="" class="nav-link nav-link-profile" data-toggle="dropdown">
              <span class="logged-name hidden-md-down"><?php echo '<p>Welcome: <b>' . $username . '</b></p>';?></span>
              <img src="<?php echo $actual_link;?>assets/img/user.png" class="wd-32 rounded-circle" alt="">
              <span class="square-10 bg-success"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-header wd-250">          
              <ul class="list-unstyled user-profile-nav">               
                <li><a href="<?php echo $actual_link;?>?logout=true"><i class="icon ion-power"></i> Sign Out</a></li>
              </ul>
            </div><!-- dropdown-menu -->
          </div><!-- dropdown -->
        </nav>
        <div class="navicon-right">
          <a id="btnRightMenu" href="" class="pos-relative">
            <i class="icon ion-ios-time-outline"></i>
            <span class="square-8 bg-danger pos-absolute t-10 r--5 rounded-circle"></span>
          </a>
        </div><!-- navicon-right -->
      </div><!-- br-header-right -->
    </div><!-- br-header -->
     <div class="br-sideright">
      <ul class="nav nav-tabs sidebar-tabs" role="tablist">
        <li class="nav-item">
          <a class="nav-link" data-toggle="tab" role="tab" href="#calendar"><i class="icon ion-ios-timer-outline tx-24"></i></a>
        </li>
      </ul><!-- sidebar-tabs -->
      <div class="tab-content">
        <div class="tab-pane pos-absolute a-0 mg-t-60 schedule-scrollbar active" id="calendar" role="tabpanel">
          <label class="sidebar-label pd-x-25 mg-t-25">Time &amp; Date</label>
          <div class="pd-x-25">
            <h2 id="brTime" class="br-time"></h2>
            <h6 id="brDate" class="br-date"></h6>
          </div>		  
</div>
 </div><!-- tab-content -->
    </div><!-- br-sideright -->
     <div class="br-mainpanel">
      <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
          <a class="breadcrumb-item" href="<?php echo $actual_link;?>">Home</a>
          <span class="breadcrumb-item active">add-movie</span>
        </nav>
      </div><!-- br-pageheader -->
      <div class="br-pagetitle">
        <i class="icon icon ion-ios-play-outline"></i>
        <div class="pd-sm-l-20">
          <h4 class="tx-gray-800 mg-b-5">Add Movies</h4>
          <p class="mg-b-0">Google Drive Player With 5 different Google Drive urls as a backup.</p>
        </div>
      </div><!-- d-flex -->      
	  <div class="br-pagebody">	
	  <div class="form-group">
		<label class="font-weight-bold"><span class="tx-success">Sample Gdrive & GPhotos Url for Demo</span></label>
	<input type="text" class="form-control" placeholder="https://drive.google.com/file/d/1ObhuEDtafPYEKxu9R-8q9ksmLiPUfSTp/view" value="https://drive.google.com/file/d/1ob2IzjrEB5kodfwJ9zOGeXyn_wHQwXDN/view" onclick="this.select()">
	<input type="text" class="form-control" placeholder="https://photos.google.com/share/AF1QipO7g6Y3TJIolm68Hzx7pWe0VrPR9xtv5FA4sQbRnjygQKBkQyLz5Y3pW3S5qpPLxQ/photo/AF1QipO2PHgoKf6TGVp4ex1tR7v7CRz7mbKDPbH-OIdu?key=cF8zV3ZtcldrT21xbFNCaUp6UGhJajdjemNjZXdn" value="https://photos.google.com/share/AF1QipO7g6Y3TJIolm68Hzx7pWe0VrPR9xtv5FA4sQbRnjygQKBkQyLz5Y3pW3S5qpPLxQ/photo/AF1QipO2PHgoKf6TGVp4ex1tR7v7CRz7mbKDPbH-OIdu?key=cF8zV3ZtcldrT21xbFNCaUp6UGhJajdjemNjZXdn" onclick="this.select()">
		</div>
	  <form id="action-form" action="action.php" method="POST" accept-charset="utf-8">
	      <div class="row">
	        <div class="col-md-6">  
			<div class="form-group">
				<label class="font-weight-bold">Url google Drive or Google Photos: <span class="tx-danger">required</span></label>
				<input type="text" name="link5" class="form-control" placeholder="Google Drive or Google Photos Url Here" onclick="this.select()" required>
				</div>
			</div>	
			<div class="col-md-6"> 
			<div class="form-group">
				<label class="font-weight-bold">Url google Drive 2: <span class="tx-danger">required</span></label>
				<input type="text" name="backup" class="form-control" placeholder="Google Drive Url Here" onclick="this.select()" required>
			</div>
			</div>
		  </div>
		  <div class="row">
	        <div class="col-md-6">  
			<div class="form-group">
				<label class="font-weight-bold">Url google Drive 3: <span class="tx-info">optional!</span></label>
				<input type="text" name="link2" class="form-control" placeholder="Google Drive Url Here" onclick="this.select()">
				</div>
			</div>
			<div class="col-md-6">			
				<div class="form-group">
				<label class="font-weight-bold">Url google Drive 4: <span class="tx-info">optional!</span></label>
				<input type="text" name="link4" class="form-control" placeholder="Google Drive Url Here" onclick="this.select()">
				</div>
			</div>
		  </div>
		  <div class="row">
	        <div class="col-md-6"> 
			<div class="form-group">
				<label class="font-weight-bold">Url google Drive 5: <span class="tx-info">optional!</span></label>
				<input type="text" name="link" class="form-control" placeholder="Google Drive Url Here" onclick="this.select()">
				</div>
			</div>
			<div class="col-md-6">			
				<div class="form-group">
				<label class="font-weight-bold">External Embed Link (Server Alt1): <span class="tx-info">optional!</span></label>
				<input type="text" name="link3" class="form-control" placeholder="You Can Add Any External EMBED link Here" onclick="this.select()">
				</div>
		    </div>
		  </div>	
		  <div class="row">
		  <div class="col-md-6">
		  <div class="form-group">
				<label class="font-weight-bold">External Embed Link(Server Alt2): <span class="tx-info">optional!</span></label>
				<input type="text" name="link6" class="form-control" placeholder="You Can Add Any External EMBED link Here" onclick="this.select()">
				</div>
				</div>
				 <div class="col-md-6">
				<div class="form-group">
				<label class="font-weight-bold">External Embed Link (Server Alt3): <span class="tx-info">optional!</span></label>
				<input type="text" name="link7" class="form-control" placeholder="You Can Add Any External EMBED link Here" onclick="this.select()">
				</div>
				 </div>
				  </div>
				   <div class="row">
				   <div class="col-lg-6">
				 <div class="form-group">
				<label class="font-weight-bold">Subtitle <span class="tx-info">optional!</span></label>
				<input type="text" class="form-control" name="sub" placeholder="You Can Add Any External SRT link Here" onclick="this.select()"> 
				 </div>
				</div>
				<div class="col-lg-6">
                <div class="form-group mg-b-10-force">
                  <label class="font-weight-bold">Subtitle Label: <span class="tx-info">Optional!</span></label>
                  <select class="form-control select2" type="text" name="player_mode" data-placeholder="Select Subtitle Label">
                    <option label="Select Subtitle Label">On</option>
                    <option value="Thailand">HardSub</option>
					<option value="English">English</option>
                    <option value="Indonesian">Indonesian</option>
                    <option value="Arabic">Arabic</option>
                    <option value="China">China</option>
                    <option value="Thailand">Germany</option>
                    <option value="Thailand">Thailand</option>
                    <option value="Thailand">France</option>
                    <option value="Thailand">India</option>
                    <option value="Thailand">Vietnam</option>
                    <option value="Thailand">Others</option>
                  </select>
                </div>
              </div><!-- col-4 -->	
				</div> <!--row-->
				<div class="form-group">
				<label class="font-weight-bold">Download Link: <span class="tx-info">optional!</span></label>
				<input type="text" name="download_link" class="form-control" placeholder="Enter Your redirect download Url Here " onclick="this.select()">
				</div>
            <div class="col-md-2 tx-center">
			<div class="form-group">
				<button type="submit" id="action-submit" class="btn btn-lg btn-info btn-block"> <span id="loading"></span> <strong>Generate!</strong></div></button>
			</div>
		</form>
		
		<div class="form-group">
			<label class="font-weight-bold">Result For Encoding Url</label>
			<input type="text" id="url-encode" class="form-control" placeholder="" onclick="this.select()">
		</div>	
		<div class="form-group">
			<label class="font-weight-bold">Result Iframe Embed Code</label>
			<input type="text" id="iframe-embed" class="form-control" placeholder="" onclick="this.select()">
		</div>	
		<label class="font-weight-bold">Video Preview</label>
		<div class="embed-responsive embed-responsive-16by9">
		<div id="iframe-encode"></div>
        </div>		
		</div><!-- /.panel-primary -->  
      <footer class="br-footer">
        <div class="footer-left">
          <div class="tx-center">Copyright &copy; 2018. Gdrive Player. All Rights Reserved.</div>
          <div class="tx-center">Powered by Ancokplayer.win</div>
        </div>
        <div class="footer-right d-flex align-items-center">
          <span class="tx-uppercase mg-r-10">Socials:</span>
          <a target="_blank" class="pd-x-5" href="https://www.facebook.com/"><i class="fab fa-facebook tx-20"></i></a>
          <a target="_blank" class="pd-x-5" href="https://twitter.com/"><i class="fab fa-twitter tx-20"></i></a>
        </div>
      </footer>
	  
   </div><!-- /.page body -->	
<script src="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/jquery-ui/ui/widgets/datepicker.js"></script>
<script src="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/moment/min/moment.min.js"></script>
<script src="https://cdn.staticaly.com/gh/domkiddie/drive/master/lib/jquery/bracket.js"></script>	
	
		<?php 
			$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "https") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
			$actual_link = str_replace('index.php', '', $actual_link);
		?>
		<script type="text/javascript">
			jQuery(function ($) {
				$('#action-form').submit(function(e) {
					e.preventDefault();
					$('#action-submit').prop('disabled', !0);
					$('#loading').html('<i class="icon ion-ios-gear-outline"></i>');
		       		var b = $(this).serializeArray(), c = $(this).attr('action');
					$.ajax({
				        type: 'POST',
				        dataType: 'text',
				        url: c,
				        data: b,
						error: function (result) {
							alert("Something went wrongs. Please try again!");
							$('#loading').html('<i class="icon ion-ios-gear-outline"></i>');
							$('#action-submit').removeAttr('disabled');
						},
						success: function (result) {
							$('#url-encode').val('<?php echo $actual_link . 'videoplayback.php?id='?>'+result+'');
							$('#iframe-embed').val('<iframe src="<?php echo $actual_link.'videoplayback.php?id='?>'+result+'" width="100%" height="100%" frameborder="0" scrolling="no" allowfullscreen></iframe>');
							$('#iframe-encode').html('<iframe class="embed-responsive-item" src="<?php echo $actual_link.'videoplayback.php?id='?>'+result+'" width="100%" height="100%" frameborder="0" allowfullscreen></iframe>');
							$('#loading').html('<i class="icon ion-ios-gear-outline"></i>');
							$('#action-submit').removeAttr('disabled');
						}
					});
				});
			});
		</script>
		
</body>
</html>
<?php
	}
function display_error_msg()
{
	echo '<center><p class="error"><span class="tx-danger tx-13 tx-bold">Username or Password is Invalid!</span></p></center>';
}
?>
</div>
</body>
</html>