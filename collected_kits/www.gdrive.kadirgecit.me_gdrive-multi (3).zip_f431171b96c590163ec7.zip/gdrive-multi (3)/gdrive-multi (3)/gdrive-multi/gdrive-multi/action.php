<?php 
error_reporting(0);
include_once 'library.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	if (isset($_POST['link'])) {
		
		$link = (!empty($_POST['link'])) ? $_POST['link'] : '';
		$link2 = (!empty($_POST['link2'])) ? $_POST['link2'] : '';
		$link3 = (!empty($_POST['link3'])) ? $_POST['link3'] : '';
		$link4 = (!empty($_POST['link4'])) ? $_POST['link4'] : '';
		$link5 = (!empty($_POST['link5'])) ? $_POST['link5'] : '';
		$link6 = (!empty($_POST['link6'])) ? $_POST['link6'] : '';
		$link7 = (!empty($_POST['link7'])) ? $_POST['link7'] : '';
		$download_link = (!empty($_POST['download_link'])) ? $_POST['download_link'] : '';
		$poster = (!empty($_POST['poster'])) ? $_POST['poster'] : '';
		$backup = (!empty($_POST['backup'])) ? $_POST['backup'] : '';
		$sub = (!empty($_POST['sub'])) ? $_POST['sub'] : '';
		$player_mode = (!empty($_POST['player_mode'])) ? $_POST['player_mode'] : '';
		$var = array();
		$var['link'] = trim($link);
		$var['link2'] = trim($link2);
		$var['link3'] = trim($link3);
		$var['link4'] = trim($link4);
		$var['link5'] = trim($link5);
		$var['link6'] = trim($link6);
		$var['link7'] = trim($link7);
		$var['download_link'] = trim($download_link);
		$var['poster'] = trim($poster);
		$var['backup'] = trim($backup);
		$var['sub'] = trim($sub);
		$var['player_mode'] = trim($player_mode);
		echo encode(json_encode($var));

	} else echo 'Error Isset!';
} else echo 'Error Request!';

?>