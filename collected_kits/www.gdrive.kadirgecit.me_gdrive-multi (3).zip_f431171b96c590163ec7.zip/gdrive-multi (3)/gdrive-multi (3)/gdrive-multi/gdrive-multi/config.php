define('DB_NAME', 'none');
define('DB_USER', 'nonw');
define('DB_PASSWORD', 'none');
define('DB_HOST', 'localhost');
define('TITLE', 'GDrive');