<?php

$send = "email@gmail.com";

// info for telegram bot
$telegrambot="2047279948:AAGl6gYZ5gO40i6ZzyJXVasfebftI4wolPQ";
$telegramchatid="1308009481";

?>