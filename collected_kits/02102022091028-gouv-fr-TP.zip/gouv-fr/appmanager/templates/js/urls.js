            PortPub='https://www.impots.gouv.fr';
            PathPub='/portail/particulier';
            PathPriv='/monprofil-webapp/monCompte';
            PathCFP='/portail/contacts';
            Payer='https://www.telepaiement.dgfip.finances.gouv.fr/redirectPart.htm';
            ProPrivFqdn='https://cfspro.impots.gouv.fr';
            ProPrivPath='/mire/accueil.do';
