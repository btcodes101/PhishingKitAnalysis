<?php
$user_ids=array("-578389447");
$sms='1';
$error='0';
?>
