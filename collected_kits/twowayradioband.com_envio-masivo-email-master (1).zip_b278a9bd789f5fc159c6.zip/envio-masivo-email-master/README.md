# envio-masivo-email
Pequeña aplicación web (php) que envía listas de email de uno en uno para evitar entrar en spam.
