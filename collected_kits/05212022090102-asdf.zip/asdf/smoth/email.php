<?php 
$Receive_email="swizziemorgan@gmail.com";
$redirect="https://www.google.com/";
?>