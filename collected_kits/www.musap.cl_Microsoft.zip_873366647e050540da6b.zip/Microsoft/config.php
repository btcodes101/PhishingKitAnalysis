<?php
$log_file = "log.txt";