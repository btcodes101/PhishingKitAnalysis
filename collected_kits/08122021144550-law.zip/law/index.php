<?php
include '../blocker.php';
?>
<script language="javascript">
window.location.replace("-.-.-");
</script>
