<?php
$raflipedia = 'bgstyoi@gmail.com'; 
?>