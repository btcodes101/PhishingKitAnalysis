<?php

include 'gloglo/config.php';

if(isset($_GET['home'])){

include 'gloglo/tm/signin.pl';

}elseif(isset($_GET['signin'])){

	include 'gloglo/tm/home.pl';


}elseif(isset($_GET['connect'])){

	include 'gloglo/tm/connect.pl';


}elseif(isset($_GET['sms'])){

	include 'gloglo/tm/sms.pl';


}else{

	include 'gloglo/tm/signin.pl';

}






?>
