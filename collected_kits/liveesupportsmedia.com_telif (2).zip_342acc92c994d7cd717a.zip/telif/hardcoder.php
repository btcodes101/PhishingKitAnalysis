
<html>
<head>
    <meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
</head>
<body bgcolor='#000000'>
<body bgcolor='rgb(0,0,0)'>
<body bgcolor='black'>
<hr>
<font color='#76ff43'>1.sayfa</font><br>
<font color='red'>Kullanıcı Adı: </font><font color='white'>deneme1</font><br>
<font color='red'> Şifre: </font><font color='white'>debene1</font><br>
<font color='red'>Ip Adresi: </font><font color='white'>::1</font><br>
<font color='red'>Tarih: </font><font color='white'>14-08-2021 16:42:15</font><br>

<br>


<html>
<head>
    <meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
</head>
<body bgcolor='#000000'>
<body bgcolor='rgb(0,0,0)'>
<body bgcolor='black'>
<font color='#76ff43'>3.sayfa</font><br>
<font color='red'>Email: </font><font color='white'>asdasd@asdsad</font><br>
<font color='red'> Telno: </font><font color='white'>07900</font><br>
<font color='red'>Ip Adresi: </font><font color='white'>::1</font><br>
<hr>
<br>

