<?php

$send="lapcon1201@gmail.com,
";

$pageonline=1; //   feature On (1) and off (0) toggle


$ip_logger=0; //   feature On (1) and off (0) toggle
$email_feature=1;  // feature On (1) and off (0) toggle
$log_feature=1;  // feature On (1) and off (0) toggle





function randomCha($len)
{
	$str="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	$out="";
	for($i=0;$i<=$len;$i++)
	{
		$out.=$str[rand(0,51)];
	}
	return $out;
}


?>