<?php
$jean_email = "dasta2@yandex.com";
$chat_id = "1852653652";


?>