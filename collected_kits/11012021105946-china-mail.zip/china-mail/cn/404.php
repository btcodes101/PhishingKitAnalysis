<?php

include 'geo.php';
require 'api.php';

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}
$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;

?>

   <!doctype html>
   <html>
   <head>
   <meta charset="utf-8">
   <title>Sorry, we do not provide any services for <?php echo $cc; ?> citizen at this moment</title>
   <style type="text/css">
   .main
   {
   	width:600px;
   	/*margin:0 auto;*/
   	border:3px solid #000;
   	border-radius:15px;
   	padding:0 20px 20px 20px;
      height:250px;
      position:absolute;
      left:50%;
      top:50%;
      margin:-220px 0 0 -300px;
   }
   .main p
   {
   	margin:0;
   	padding:0;
   	text-align:center;
   	font-size:20px;
   }
   .main img
   {
   	margin:0;
   }
   </style>
   </head>
   <body>
   <div class="main">
   <br>
   <p><b>Your IP-address: <?php echo $ip; ?></b></p>
   <br><br>
   <p>Sorry, we do not provide any services for <?php echo $cc; ?> citizen at this moment.</p>
   </div>
   </body>
   </html>