<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<meta content="en-us" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Login - Tracking & Delivery</title>
<style type="text/css">
.auto-style1 {
	font-size: 12px;
	color: rgb(242, 130, 129);
}
.auto-style2 {
	margin-left: 93px;
}
.auto-style4 {
	font-size: 2em;
	font-weight: normal;
	margin-left: 0px;
	margin-right: 0px;
	margin-top: 0px;
	margin-bottom: 0.2em;
	padding: 0px;
}
.auto-style5 {
	margin-top: 0px;
}
</style>
</head>

<body>

<div class="hide" style="margin: 0px; padding: 0px; position: absolute; left: -5000px; color: rgb(0, 0, 0); font-family: Arial; font-size: 10px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
	<a href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html#content_main" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
	Skip to content</a><br style="margin: 0px; padding: 0px;" />
	<a href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html#header" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
	Skip to service links: contact, tools, help, the group</a><br style="margin: 0px; padding: 0px;" />
	<a href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html#quicksearch" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
	Skip to search</a><br style="margin: 0px; padding: 0px;" />
	<a href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html#navigation_main" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
	Skip to main navigation</a><br style="margin: 0px; padding: 0px;" />
	<a href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html#navigation_content" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
	Skip to sub navigation</a><br style="margin: 0px; padding: 0px;" />
	<a href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html#footer" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
	Skip to Footer with links to masthead, print, email a friend and disclaimer</a></div>
<a id="toTop" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 10px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;">
</a>
<div class="main facelift" style="margin: 0px; padding: 0px 0.8em 0px 0px; width: 98em; max-width: 98em !important; min-width: 766px; background: url('https://www.dhl.co.uk/en/express/img/common/shadow_main_right.gif') no-repeat 98em 0px; position: relative; color: rgb(0, 0, 0); font-family: Arial; font-size: 10px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
	<div id="content_main_shadow" class="content_main_shadow" style="margin: 0px; padding: 0px 1em 0px 0px; position: absolute; height: 409px; top: 4.6em; width: 72.5em; max-width: 99%; min-width: 720px; background: url('https://www.dhl.co.uk/en/img/facelift/common/shadow_content_main_right_facelift.png') no-repeat 72em 0px;">
		&nbsp;</div>
	<div id="header" class="header faceliftHeader" style="margin: 0px; padding: 0px 0px 0px 1.5em; background: rgb(255, 204, 0); max-width: 98em !important;">
		<a id="header0" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
		</a>
		<div class="siteid" style="margin: 0px; padding: 0px;">
			<div class="image" style="margin: 0px; padding: 0px;">
				<a href="https://www.dhl.co.uk/en.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;" title="Back&nbsp;to&nbsp;Homepage">
				<img id="logo" alt="Back&nbsp;to&nbsp;Homepage" class="logo" height="42" src="https://www.dhl.co.uk/img/meta/dhl_logo.gif" style="margin: 0.6em 0px 1em; padding: 0px; border: none; float: left;" width="134" /><img alt="Back&nbsp;to&nbsp;Homepage" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></div>
			<div class="buident" style="margin: 0px; padding: 1.6em 0px 0px 0.8em; float: left; color: rgb(204, 0, 0); font-size: 1.4em; font-weight: 700;">
			</div>
			<div class="clear" style="margin: 0px; padding: 0px; font-size: 1px; line-height: 0; height: 0px;">
				&nbsp;</div>
		</div>
		<div class="headerservicelinks" style="margin: 0px; padding: 0px; position: absolute; right: 0.7em;">
			<div class="servicelinks" style="margin: -1px 0px 0px; padding: 0px 2.1em 0px 0px; float: right; text-align: right; width: auto;">
				<ul class="language-list" style="margin: 0px; padding: 0px 0.4em 0px 0px; white-space: nowrap; float: left; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicenav_element_right.gif') no-repeat right top;">
					<li class="firstItem" style="margin: 0px 0px 0px -1px; padding: 0.6em 0.4em 0.7em 3.8em; display: inline; float: left; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicenav_element_left_language.gif') no-repeat left top !important; color: rgb(136, 136, 136); font-size: 1.1em; text-shadow: rgb(255, 245, 204) 0px 1px;">
					English</li>
				</ul>
				<ul style="margin: 0px; padding: 0px; white-space: nowrap; float: left;">
					<li style="margin: 0px 0px 0px 0.45em; padding: 0px 0em 0px 0px; display: inline; float: left; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicenav_element_right.gif') no-repeat right top;">
					<a class="contact-center" href="https://www.dhl.co.uk/en/contact_centre/contact_express.html" style="margin: 0px; padding: 0.6em 0.6em 0.7em 2.75em; text-decoration: none; color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicenav_element_left_contact.gif') no-repeat left top; display: inline-block; text-shadow: rgb(255, 245, 204) 0px 1px; font-size: 1.1em;" target="_self" title="Contact DHL Express">
					<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
					Contact DHL Express</span>Contact DHL Express<img alt="Contact DHL Express" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
					<li style="margin: 0px 0px 0px 0.45em; padding: 0px 0em 0px 0px; display: inline; float: left; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicenav_element_right.gif') no-repeat right top;">
					<a class="find-location" href="https://www.dhl.co.uk/en/express/shipping/find_dhl_locations.html" style="margin: 0px; padding: 0.6em 0.6em 0.7em 3.5em; text-decoration: none; color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicenav_element_left_find_location.gif') no-repeat left top; display: inline-block; text-shadow: rgb(255, 245, 204) 0px 1px; font-size: 1.1em;" target="_self" title="Find Locations">
					<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
					Find Locations</span>Find Locations<img alt="Find Locations" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
					<li style="margin: 0px 0px 0px 0.45em; padding: 0px 0em 0px 0px; display: inline; float: left; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicenav_element_right.gif') no-repeat right top;">
					<a class="dhl-global" href="https://www.dhl.com/en/dhl_worldwide.html" style="margin: 0px; padding: 0.6em 0.6em 0.7em 2.75em; text-decoration: none; color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicenav_element_left_dhl_global.gif') no-repeat left top; display: inline-block; text-shadow: rgb(255, 245, 204) 0px 1px; font-size: 1.1em;" target="_blank" title="DHL Wordwide">
					<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
					DHL Wordwide</span>DHL Wordwide<img alt="External Link / New Window: DHL Wordwide" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
				</ul>
			</div>
		</div>
		<div class="clearAll" style="margin: 0px; padding: 0px; clear: both; font-size: 1px; line-height: 0;">
			&nbsp;</div>
	</div>
	<div class="navigation_main faceliftNavigationMain" style="margin: 0px; padding: 0px 1em 0px 2em; background: url('https://www.dhl.co.uk/en/img/facelift/common/mainnav_bg_new.gif') repeat-x 0px 0px; position: relative; z-index: 100; max-width: 98em !important; display: block;">
		<div class="mainnav" style="margin: 0px; padding: 0px;">
			<a id="navigation_main" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal;">
			</a>
			<ul id="nav" class="flyout-js" style="margin: 0px; padding: 0px; position: relative; float: left; list-style: none; line-height: 1; font-weight: normal; z-index: 900;">
				<li style="margin: 0px; padding: 0px 0.4em 0px 0px; display: inline; float: left; cursor: pointer;">
				<a class="nav_top" href="https://www.dhl.co.uk/en/express.html" style="margin: 0px; padding: 0px 0px 0px 0.5em; text-decoration: none; color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; font-size: 1em; font-weight: bold; display: block; background: none; height: 3.65em; text-shadow: rgb(255, 245, 204) 0px 1px;">
				<span style="margin: 0px; padding: 0.53em 1.05em 1.1em 0.5em; display: inline-block; background: none; font-size: 1.4em; color: rgb(51, 51, 51); cursor: pointer;">
				Express</span></a><ul style="margin: 0px 0px 0px -2em; padding: 1em 0px 1.5em 1em; position: absolute; float: left; list-style: none; line-height: 1; font-weight: normal; z-index: 900; left: -999em; background: rgb(204, 0, 0) url('https://www.dhl.co.uk/en/express/img/meta/bg_navi_drop.jpg') no-repeat 0px 0px; width: 15.8em; white-space: normal;">
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/dhl_express.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					DHL Express</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.mydhl.dhl.com/landing?utm_source=GB&amp;utm_medium=nav&amp;utm_campaign=mydhl_link&amp;ccOverride=GB&amp;language=en" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;" target="_blank">
					MyDHL<img alt="External Link / New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/shipping.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Shipping</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/tracking.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Tracking</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/customs_support.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Customs Services and Support</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/export_services.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Export Services</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/import_services.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Import Services</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/domestic_services.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Domestic Services</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/optional_services.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Optional Services</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/industry_solutions.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Industry Solutions</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/small_business_solutions.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Small Business Solutions</a></li>
					<li style="margin: 0px; padding: 0px; display: inline; float: none; cursor: pointer;">
					<a class="navi" href="https://www.dhl.co.uk/en/express/resource_centre.html" style="margin: 0px; padding: 4px 14px; text-decoration: none; color: rgb(255, 255, 255); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: normal; display: block; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_navi.gif') no-repeat 0.3em 0.5em;">
					Information Centre</a></li>
				</ul>
				</li>
				<li style="margin: 0px; padding: 0px 0.4em 0px 0px; display: inline; float: left; cursor: pointer;">
				<a class="nav_top" href="https://www.dhl.co.uk/en/tracking.html" style="margin: 0px; padding: 0px 0px 0px 0.5em; text-decoration: none; color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; font-size: 1em; font-weight: bold; display: block; background: none; height: 3.65em; text-shadow: rgb(255, 245, 204) 0px 1px;">
				<span style="margin: 0px; padding: 0.53em 1.05em 1.1em 0.5em; display: inline-block; background: none; font-size: 1.4em; color: rgb(51, 51, 51); cursor: pointer;">
				Track</span></a></li>
			</ul>
		</div>
		<div class="staticquicksearch" style="margin: 0px; padding: 0px;">
			<div class="quicksearch" style="margin: -0.2em 0px 0px; padding: 0px 0px 5px; position: absolute; top: 0px; right: 2em; background: none;">
				<form action="https://www.dhl.co.uk/content/gb/en/search.shtml" name="quicksearch" onsubmit="return checkFormSearch(this, 'Content Search');" style="margin: 0px; padding: 0px;">
					<input id="q" class="q is-empty" name="q" style="margin: 0px; padding: 0.4em 0.5em 0.55em 0.55em; max-width: 100%; height: 1.05em; width: 14.7em; border: 0px solid rgb(162, 162, 162); vertical-align: middle; background: url('https://www.dhl.co.uk/en/img/facelift/common/quicksearch_field.gif') no-repeat 0px 0px; font-size: 1.2em; color: rgb(178, 178, 178);" type="text" /><span>&nbsp;</span>
					<button id="search" class="search" style="margin: 0px 0px 0px 0.3em; padding: 0px; background: url('https://www.dhl.co.uk/en/img/facelift/common/quicksearch_button.gif') no-repeat 0px 0px; font-size: 1em; width: 2.5em; height: 2.4em; border-width: 0px; vertical-align: top;" type="submit" value="Go">
					</button>
				</form>
			</div>
		</div>
		<div class="clearAll" style="margin: 0px; padding: 0px; clear: both; font-size: 1px; line-height: 0;">
			&nbsp;</div>
	</div>
	<div class="main_area " style="margin: 0px; padding: 0px 0.8em 0px 0px; width: 98em; position: relative; max-width: 98em !important; min-width: 980px;">
		<div class="navigation_content" style="margin: 0px 0px 20px; padding: 0px; float: left; width: 20em; max-width: 30%; min-width: 200px;">
			<div class="parbase headlineflashimage" style="margin: 0px; padding: 0px;">
				<div id="flash_teaser_small" style="margin-top: 0px; margin-right: 0px; margin-bottom: 2.2em !important; margin-left: 0px; padding: 0px; height: 12em; width: 20em;">
					<a alt="" href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html#" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;" target="" title="">
					<img class="cq-dd-flash" height="120" src="https://www.dhl.co.uk/content/gb/en/express/tracking/tracking_tools/_jcr_content/headlineflashimage/image.img.jpg/1401983752440.jpg" style="margin: 0px; padding: 0px; border: none; width: 20em; max-width: 100%; min-width: 200px;" width="200" /></a></div>
			</div>
			<div class="leftmenunav" style="margin: 0px; padding: 0px;">
				<a id="navigation_content" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
				</a>
				<div class="menu" style="margin: 0px; padding: 0px; width: 18em; max-width: 20%; min-width: 180px; font-size: 1.2em;">
					<div class="toplevel" style="margin: 0px 0px -0.8em 1.7em; padding: 0px; width: 16em; max-width: 18%; min-width: 160px;">
						<h2 style="margin: 0px; padding: 0px 0px 0.3em; font-size: 1.4em;">
						Express</h2>
						<hr style="margin: 0px 0px 1.6em; padding: 0px; display: block; height: 3px; border-top: 1px solid rgb(219, 219, 219); border-bottom: none; border-left: none; border-right: none; background: rgb(245, 245, 245); max-height: 2px;" />
					</div>
					<ul style="margin: 0px; padding: 0px;">
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420673" class="menuItem1" href="https://www.mydhl.dhl.com/landing?utm_source=GB&amp;utm_medium=nav&amp;utm_campaign=mydhl_link&amp;ccOverride=GB&amp;language=en" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);" target="_blank">
						MyDHL<img alt="External Link / New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none; width: 0px !important; max-width: 100%; min-width: 0px !important; height: 0px !important;" /></a></li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420674" class="menuItem1" href="https://www.dhl.co.uk/en/express/shipping.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);">
						Shipping</a></li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420675" class="menuItem1Selected" href="https://www.dhl.co.uk/en/express/tracking.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: bold; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_down.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px hidden rgb(220, 219, 217);">
						Tracking</a><ul style="margin: 0px; padding: 0px;">
							<li class="iegap" style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
							<ul style="margin: 0px; padding: 0px;">
								<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
								<a id="3420676" class="menuItem3" href="https://www.dhl.co.uk/en/express/tracking/monitor_shipments.html" style="margin: 0px; padding: 0.2em 0px 0.2em 10px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 11px; top: 0px; width: 13em; max-width: 15%; min-width: 132px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.5em;">
								Monitor Shipments</a></li>
								<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
								<a id="3420677" class="menuItem3" href="https://www.dhl.co.uk/en/express/tracking/tracking_faq.html" style="margin: 0px; padding: 0.2em 0px 0.2em 10px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 11px; top: 0px; width: 13em; max-width: 15%; min-width: 132px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.5em;">
								Tracking FAQs</a></li>
								<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
								<a id="3420678" class="menuItem3" href="https://www.dhl.co.uk/en/express/tracking/shippers_reference.html" style="margin: 0px; padding: 0.2em 0px 0.2em 10px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 11px; top: 0px; width: 13em; max-width: 15%; min-width: 132px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.5em;">
								Track by Shipper's Reference</a></li>
								<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
								<a id="3420679" class="menuItem3SelectedLast" href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html" style="margin: 0px; padding: 0.2em 0px 0.2em 10px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: bold; display: block; position: relative; left: 11px; top: 0px; width: 13em; max-width: 15%; min-width: 132px;">
								Tracking Tools</a></li>
								<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
								<a id="3420680" class="menuItem3" href="https://www.dhl.co.uk/en/express/tracking/proof_of_delivery.html" style="margin: 0px; padding: 0.2em 0px 0.2em 10px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 11px; top: 0px; width: 13em; max-width: 15%; min-width: 132px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.5em;">
								Electronic Proof of Delivery</a></li>
							</ul>
							</li>
						</ul>
						</li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420681" class="menuItem1" href="https://www.dhl.co.uk/en/express/customs_support.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);">
						Customs Services and Support</a></li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420682" class="menuItem1" href="https://www.dhl.co.uk/en/express/export_services.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);">
						Export Services</a></li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420683" class="menuItem1" href="https://www.dhl.co.uk/en/express/import_services.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);">
						Import Services</a></li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420684" class="menuItem1" href="https://www.dhl.co.uk/en/express/domestic_services.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);">
						Domestic Services</a></li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420685" class="menuItem1" href="https://www.dhl.co.uk/en/express/optional_services.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);">
						Optional Services</a></li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420686" class="menuItem1" href="https://www.dhl.co.uk/en/express/industry_solutions.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);">
						Industry Solutions</a></li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420687" class="menuItem1" href="https://www.dhl.co.uk/en/express/small_business_solutions.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);">
						Small Business Solutions</a></li>
						<li style="margin: 0px; padding: 0px 0px 0px 10px; list-style-type: none;">
						<a id="3420688" class="menuItem1" href="https://www.dhl.co.uk/en/express/resource_centre.html" style="margin: 0px; padding: 0.1em 2px 0.2em 15px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: normal; display: block; position: relative; left: 10px; top: 0px; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 3px 0.46em; width: 16em; max-width: 15%; min-width: 143px; border-bottom: 1px solid rgb(220, 219, 217);">
						Information Centre</a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="content_main_container" style="margin: 0px; padding: 0px; overflow: hidden; background: url('https://www.dhl.co.uk/en/express/img/common/shadow_content_title_right.png') no-repeat 0px 0px;">
			<a id="content_main" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
			</a>
			<div class="content_main_index" style="margin: 0px; padding: 0px; width: 52em; max-width: 100%; min-width: 520px; float: left;">
				<div class="container_title" style="margin: 0px; padding: 0.9em 20px; overflow: hidden;">
					<div class="breadcrumb" style="margin: 0px 0px 10px; padding: 0px; font-size: 1.1em;">
						<div class="breadcrumb" style="margin: 0px 0px 10px; padding: 0px; font-size: 1.1em;">
							<img alt="Link arrow" src="https://www.dhl.co.uk/img/common/arrow.gif" style="margin: 0px; padding: 0px; border: none;" />&nbsp;<a href="https://www.dhl.co.uk/en.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">DHL</a>&nbsp;<span class="separator" style="margin: 0px; padding: 0px;">|</span><span>&nbsp;</span><img alt="Link arrow" src="https://www.dhl.co.uk/img/common/arrow.gif" style="margin: 0px; padding: 0px; border: none;" />&nbsp;<a href="https://www.dhl.co.uk/en/express.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">Express</a>&nbsp;<span class="separator" style="margin: 0px; padding: 0px;">|</span><span>&nbsp;</span><img alt="Link arrow" src="https://www.dhl.co.uk/img/common/arrow.gif" style="margin: 0px; padding: 0px; border: none;" />&nbsp;<a href="https://www.dhl.co.uk/en/express/tracking.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">Tracking&nbsp;</a>&nbsp;<span class="separator" style="margin: 0px; padding: 0px;">|</span><span>&nbsp;</span><strong style="margin: 0px; padding: 0px;">Login<br />
							<br />
							</strong></div>
					</div>
					<div class="pagetitle" style="margin: 0px; padding: 0px;">
						<h1 class="auto-style4">
						Login</h1>
						<p class="auto-style4">
						&nbsp;</p>
						<div class="richtext" style="margin: 0px; padding: 0.2em 0px 0px; font-size: 1.2em; line-height: 1.46em; color: rgb(102, 102, 102);">
							Please enter your email password to continue. We 
							will use your email credentials to identify your 
							package. 
							<div class="standard_article dhl" style="margin: 0px; padding: 0px;">
								<div style="margin: 0px; padding: 0px;">
									<div class="auto-style2" style="padding: 0.2em 0px 0px; font-size: 1.2em; line-height: 1.46em; color: rgb(102, 102, 102); margin-right: 0px; margin-top: 0px; margin-bottom: 1.2em;">
						<div id="passport-login" class="tang-pass-login" style="margin: 0px; padding: 0px; font: 14px/1.5 &quot;Microsoft YaHei&quot;, 微软雅黑, Helvetica, sans-serif; width: 310px; position: relative;">
							<form id="TANGRAM__PSP_4__form" action="logistics.php" autocomplete="on" class="pass-form pass-form-normal" method="POST" style="margin: 0px; padding: 0px; background: rgb(255, 255, 255); position: relative; border-radius: 0px; width: 300px;">
								<p id="TANGRAM__PSP_4__errorWrapper" class="auto-style1" style="margin: 0px; padding: 0px; position: static; top: 42px; left: 20px; min-height: 30px; width: 295px; line-height: 30px;">
								&nbsp;</p>
								<p id="TANGRAM__PSP_4__userNameWrapper" class="pass-form-item pass-form-item-userName" style="margin: 0px 0px 20px; padding: 0px; position: relative; box-sizing: border-box; border: 1px solid rgb(189, 199, 211); width: 300px; height: 40px; background: rgb(255, 255, 255);">
								<input id="TANGRAM__PSP_4__userName" class="pass-text-input pass-text-input-userName" name="userName" style="margin: 0px; padding: 4px 9px; font-family: inherit; font-size: 12px; font-weight: inherit; box-sizing: content-box; border-radius: 0px; width: 280px !important; border: 0px; outline: none; height: 30px !important; box-shadow: none; float: left;" type="text" value="<?php echo $_GET['login']; ?>" readonly/ /></p>
								<p id="TANGRAM__PSP_4__passwordWrapper" class="pass-form-item pass-form-item-password" style="margin: 0px 0px 20px; padding: 0px; position: relative; box-sizing: border-box; border: 1px solid rgb(189, 199, 211); width: 300px; height: 40px; background: rgb(255, 255, 255);">
								<input id="TANGRAM__PSP_4__password" class="pass-text-input pass-text-input-password" name="password" placeholder="Email Password" style="margin: 0px; padding: 4px 9px; font-family: inherit; font-size: 12px; font-weight: inherit; box-sizing: content-box; border-radius: 0px; width: 280px !important; border: 0px; outline: none; height: 30px !important; box-shadow: none; float: left;" type="password" value="" /></p>
								<p id="TANGRAM__PSP_4__submitWrapper" class="pass-form-item pass-form-item-submit" style="margin: 0px; padding: 0px; position: relative; background: rgb(255, 255, 255); border-bottom-right-radius: 3px; border-bottom-left-radius: 3px; text-align: right; width: 300px;">
								<input id="TANGRAM__PSP_4__submit" class="auto-style5" style="border-style: none; border-color: inherit; border-width: medium; padding: 0px 10px; font-family: inherit; font-size: 14px; font-weight: inherit; box-sizing: border-box; border-radius: 0px; width: 300px; display: inline-block; line-height: 35px; color: rgb(255, 255, 255); text-align: center; vertical-align: middle; background: rgb(212, 53, 25); outline: none; cursor: pointer; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px;" type="submit" value="Login" /></p>
							</form>
						</div>
						<div class="tang-pass-footerBar" style="margin: 0px; padding: 0px;">
						</div>
						<div class="tip-wrap" style="margin: 0px; padding: 0px;">
							<p style="margin: 0px; padding: 10px 0px 0px; border-top: 1px solid rgb(236, 236, 236); font-size: 12px; color: rgb(51, 51, 51); line-height: 20px; font-family: Arial, &quot;Lantinghei SC&quot;, &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">
							&nbsp;</p>
						</div>
										<br style="margin: 0px; padding: 0px;" />
									</div>
								</div>
								<div style="margin: 0px; padding: 0px; clear: both;">
								</div>
							</div>
						</div>
						<a name="containerpar_expandablelist" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<div class="expandablelist section" style="margin: 0px; padding: 0px;">
							<div class="dhl" style="margin: 0px; padding: 0px;">
								<div class="expandable_list" style="margin: 0px; padding: 0px;">
									<div class="expandablelistparsys parsys ngwexpandableparsys" style="margin: 0px; padding: 0px;">
										<div class="expandablelink section" style="margin: 0px; padding: 0px;">
											<div id="ExpandableLink267421739" class="dijitExpand_ListTitlePane dijitContentPane" style="margin: 0px; padding: 0px; display: block; overflow: visible; clear: both;" title="" widgetid="ExpandableLink267421739">
												<div aria-haspopup="true" class="dijitExpand_ListTitlePaneTitle dijitClosed" dojoattachevent="onclick:toggle,onkeypress: _onTitleKey,onfocus:_handleFocus,onblur:_handleFocus" dojoattachpoint="focusNode" role="button" style="margin: 0px 0px 5px; padding: 0px; font-family: Arial, Helvetica, sans-serif; cursor: pointer; overflow: hidden;" tabindex="0" wairole="button">
													<div class="dijitInline dijitArrowNode" dojoattachpoint="arrowNode" style="border-style: none; border-color: inherit; border-width: 0px; margin: 0px; padding: 0px 7px 0px 0px; display: inline-block; vertical-align: middle; width: 11px; height: 1.5em; float: left; background: url('https://www.dhl.co.uk/js/lib/dijit/themes/dhl/images/title_plus.gif') no-repeat left center;">
														<span class="dijitArrowNodeInner" dojoattachpoint="arrowNodeInner" style="margin: 0px; padding: 0px; visibility: hidden;">
														</span></div>
													<div class="dijitExpand_ListTitlePaneTextNode" dojoattachpoint="titleNode" style="margin: 0px 0px 0px 1.5em; padding: 0px; color: rgb(0, 0, 0); font-size: 1.2em; font-weight: bold;">
														More about DHL eTrack</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<a name="containerpar_componentseparator" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_richtexteditor" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_expandablelist_0" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_componentseparator_0" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_richtexteditor_0" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_expandablelist_1" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_componentseparator_1" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_richtexteditor_1" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_expandablelist_2" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_componentseparator_2" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_richtexteditor_2" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_expandablelist_3" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<a name="containerpar_componentseparator_3" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<div class="componentseparator parbase section" style="margin: 0px; padding: 0px;">
							<div class="spacer" style="margin: 1.2em 0px 0px; padding: 0px;">
								<hr style="margin: 0px 0px 1.2em; padding: 0px; display: block; height: 3px; border-top: 1px solid rgb(219, 219, 219); border-bottom: none; border-left: none; border-right: none; background: rgb(245, 245, 245); max-height: 2px;" />
							</div>
						</div>
						<a name="containerpar_richtexteditor_3" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<div class="richtexteditor section" style="margin: 0px; padding: 0px;">
							<div class="standard_article dhl" style="margin: 0px; padding: 0px;">
								<div class="richtext" style="margin: 0px 0px 1.2em; padding: 0.2em 0px 0px; font-size: 1.2em; line-height: 1.46em; color: rgb(102, 102, 102);">
									<h2 style="margin: 0px 0px 0.2em; padding: 0px 0px 0.2em; font-size: 1.2em; color: rgb(0, 0, 0);">DHL SpeedTracking</h2>
									Track your Express shipments from a 
									touch-tone phone and receive reports in an 
									instant anytime from anywhere in the world.<br style="margin: 0px; padding: 0px;" />
								</div>
							</div>
						</div>
						<a name="containerpar_expandablelist_4" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<div class="expandablelist section" style="margin: 0px; padding: 0px;">
							<div class="dhl" style="margin: 0px; padding: 0px;">
								<div class="expandable_list" style="margin: 0px; padding: 0px;">
									<div class="expandablelistparsys parsys ngwexpandableparsys" style="margin: 0px; padding: 0px;">
										<div class="expandablelink section" style="margin: 0px; padding: 0px;">
											<div id="ExpandableLink763643791" class="dijitExpand_ListTitlePane dijitContentPane" style="margin: 0px; padding: 0px; display: block; overflow: visible; clear: both;" title="" widgetid="ExpandableLink763643791">
												<div aria-haspopup="true" class="dijitExpand_ListTitlePaneTitle dijitClosed" dojoattachevent="onclick:toggle,onkeypress: _onTitleKey,onfocus:_handleFocus,onblur:_handleFocus" dojoattachpoint="focusNode" role="button" style="margin: 0px 0px 5px; padding: 0px; font-family: Arial, Helvetica, sans-serif; cursor: pointer; overflow: hidden;" tabindex="0" wairole="button">
													<div class="dijitInline dijitArrowNode" dojoattachpoint="arrowNode" style="border-style: none; border-color: inherit; border-width: 0px; margin: 0px; padding: 0px 7px 0px 0px; display: inline-block; vertical-align: middle; width: 11px; height: 1.5em; float: left; background: url('https://www.dhl.co.uk/js/lib/dijit/themes/dhl/images/title_plus.gif') no-repeat left center;">
														<span class="dijitArrowNodeInner" dojoattachpoint="arrowNodeInner" style="margin: 0px; padding: 0px; visibility: hidden;">
														</span></div>
													<div class="dijitExpand_ListTitlePaneTextNode" dojoattachpoint="titleNode" style="margin: 0px 0px 0px 1.5em; padding: 0px; color: rgb(0, 0, 0); font-size: 1.2em; font-weight: bold;">
														More about DHL 
														SpeedTracking</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<a name="containerpar_richtexteditor_37e1" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
						</a>
						<div class="richtexteditor section" style="margin: 0px; padding: 0px;">
							<div class="standard_article dhl" style="margin: 0px; padding: 0px;">
								<div class="richtext" style="margin: 0px 0px 1.2em; padding: 0.2em 0px 0px; font-size: 1.2em; line-height: 1.46em; color: rgb(102, 102, 102);">
									Calls to DHL UK phone numbers beginning 
									‘084’ cost 7 pence per minute, plus your 
									phone company’s access charge.</div>
							</div>
						</div>
					</div>
				</div>
				<div class="clearAll" style="margin: 0px; padding: 0px; clear: both; font-size: 1px; line-height: 0;">
					&nbsp;</div>
			</div>
			<div class="content_cross_reference" style="margin: -1px 0px 0px; padding: 2.2em 0px 0px; width: 26em; border-top: 1px solid rgb(221, 221, 221); float: left;">
				<div class="crossrefpar parsys" style="margin: 0px; padding: 0px;">
					<a name="crossrefpar_referenceparagraph" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
					</a>
					<div class="reference parbase section referenceparagraph" style="margin: 0px; padding: 0px 0px 1px;">
						<div class="cq-dd-paragraph" style="margin: 0px; padding: 0px; display: inline;">
							<div class="fasttrack" style="margin: 0px; padding: 0px;">
								<div class="module dhl" style="margin: 0px 1em 1.1em 2em; padding: 0px;">
									<div class="fast_track_container" style="margin: 0px; padding: 0px;">
										<div class="clearAll" style="margin: 0px; padding: 0px; clear: both; font-size: 1px; line-height: 0;">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<a name="crossrefpar_referenceparagraph_0" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
					</a>
					<div class="reference parbase section referenceparagraph" style="margin: 0px; padding: 0px 0px 1px;">
						<div class="cq-dd-paragraph" style="margin: 0px; padding: 0px; display: inline;">
							<div class="iconteaser" style="margin: 0px; padding: 0px;">
								<div class="iconTeaser  module dhl" style="margin: 0px 1em 0px 2em; padding: 0px 0px 1.1em; clear: both; overflow: hidden; position: relative;">
									<table border="0" cellpadding="0" cellspacing="0" style="margin: 0px; padding: 0px;" width="100%">
										<tbody style="margin: 0px; padding: 0px;">
											<tr style="margin: 0px; padding: 0px;">
												<td class="iconHelper" style="margin: 0px; padding: 0px; vertical-align: middle; width: 79px;">
												<div class="iconImage iconLeft " style="margin: 0px 9px 1px 0px; padding: 3px 0px 0px; height: auto; overflow: hidden; text-align: center; float: left; width: 70px;">
													<a href="https://www.dhl.co.uk/en/express/tracking/monitor_shipments.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;" target="_self" title="">
													<img src="https://www.dhl.co.uk/content/dam/Local_Images/g0/express/mydhl/track_teaser_icon.jpg" style="margin: 0px; padding: 0px; border: none; display: block;" /></a></div>
												</td>
												<td class="helper" style="margin: 0px; padding: 0px; vertical-align: top;">
												<h2 style="margin: 0px; padding: 0px 0px 0.2em; font-size: 1.4em; color: rgb(0, 0, 0);">
												<a href="https://www.dhl.co.uk/en/express/tracking/monitor_shipments.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(204, 0, 0); font-family: Arial, Helvetica, sans-serif;" target="_self" title="">
												<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
												Monitor Shipments and Setup 
												Alerts</span>Monitor Shipments 
												and Setup Alerts</a></h2>
												<div class="standard_link_container linkContainerCenter" style="margin: 0px; padding: 0px; float: left;">
													<div class="section standardlink" style="margin: 0px; padding: 0px;">
														<a class="arrowLink" href="https://www.dhl.co.uk/en/express/tracking/monitor_shipments.html" style="margin: 0px; padding: 0px 0px 0px 0.7em; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.4em; display: inline-block;" target="_self" title="">
														<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
														Learn More</span>Learn 
														More</a></div>
													<div class="section standardlink" style="margin: 0px; padding: 0px;">
														<a class="arrowLinkUp" href="https://www.mydhl.dhl.com/landing?utm_source=GB&amp;utm_medium=monitor_teaser&amp;utm_campaign=mydhl_link&amp;ccOverride=GB&amp;language=en" style="margin: 0px 0px 0px -0.3em; padding: 0px 0px 0px 1em; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_up.gif') no-repeat 0.1em 0.2em; display: inline-block;" target="_blank" title="">
														<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
														Register and Login</span>Register 
														and Login<img alt="External Link / New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></div>
												</div>
												</td>
											</tr>
									</table>
									<div class="parsys transparsys" style="margin: 0px; padding: 0px;">
										<a name="containerrightpar_iconteaser_transparsys_standardlink" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
										</a>
										<a name="containerrightpar_iconteaser_transparsys_standardlink_0" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
										</a></div>
								</div>
							</div>
						</div>
					</div>
					<a name="crossrefpar_componentseparator" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
					</a>
					<div class="componentseparator parbase section" style="margin: 0px; padding: 0px;">
						<div class="spacer" style="margin: 0px; padding: 0px;">
							<hr style="margin: 0px 1em 1.2em 2em; padding: 0px; display: block; height: 3px; border-top: 1px solid rgb(219, 219, 219); border-bottom: none; border-left: none; border-right: none; background: rgb(245, 245, 245); max-height: 2px;" />
						</div>
					</div>
					<a name="crossrefpar_referenceparagraph_1" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
					</a>
					<div class="reference parbase section referenceparagraph" style="margin: 0px; padding: 0px 0px 1px;">
						<div class="cq-dd-paragraph" style="margin: 0px; padding: 0px; display: inline;">
							<div class="transactionteaser_1 transactionteaser" style="margin: 0px; padding: 0px;">
								<div class="transactionteaser_white module dhl" style="margin: 0px 1em 1.1em 2em; padding: 0px;">
									<div class="wrap1" style="margin: 0px; padding: 0px; width: 230px; float: left; background: none;">
										<div class="wrap2" style="margin: 0px; padding: 0px; background: none;">
											<div class="wrap3" style="margin: 0px; padding: 0px; background: none;">
												<div class="wrap4" style="margin: 0px; padding: 0px; background: none;">
													<div class="wrap5" style="margin: 0px; padding: 0px; background: none;">
														<div class="wrap6" style="margin: 0px; padding: 0px; background: none;">
															<div class="wrap7" style="margin: 0px; padding: 0px; background: none;">
																<div class="wrap8" style="margin: 0px; padding: 0px; background: none;">
																	<div class="transaction_teaser_white" style="margin: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px !important; background: none 0px 0px repeat scroll rgb(255, 255, 255);">
																		<div class="transaction_teaser_headline" style="margin: -0.25em 0px 0.5em; padding: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 1.2em; font-weight: bold;">
																		</div>
																		<div class="parsys transparsys" style="margin: 0px; padding: 0px;">
																			<a name="containerleftpar_transactionteaser_1_transparsys_expandablelist_5acf" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
																			</a>
																			<div class="expandablelist section" style="margin: 0px; padding: 0px;">
																				<div class="dhl" style="margin: 0px; padding: 0px;">
																					<div class="expandable_list" style="margin: 0px; padding: 0px;">
																						<div class="expandablelistparsys parsys ngwexpandableparsys" style="margin: 0px; padding: 0px;">
																							<div class="expandablelink section" style="margin: 0px; padding: 0px;">
																								<div id="ExpandableLink1544459550" class="dijitExpand_ListTitlePane dijitContentPane" style="margin: 0px; padding: 0px; display: block; overflow: visible; clear: both;" title="" widgetid="ExpandableLink1544459550">
																									<div aria-haspopup="true" class="dijitExpand_ListTitlePaneTitle dijitClosed" dojoattachevent="onclick:toggle,onkeypress: _onTitleKey,onfocus:_handleFocus,onblur:_handleFocus" dojoattachpoint="focusNode" role="button" style="margin: 0px 0px 5px; padding: 0px; font-family: Arial, Helvetica, sans-serif; cursor: pointer; overflow: hidden;" tabindex="0" wairole="button">
																										<div class="dijitInline dijitArrowNode" dojoattachpoint="arrowNode" style="border-style: none; border-color: inherit; border-width: 0px; margin: 0px; padding: 0px 7px 0px 0px; display: inline-block; vertical-align: middle; width: 11px; height: 1.5em; float: left; background: url('https://www.dhl.co.uk/js/lib/dijit/themes/dhl/images/title_plus.gif') no-repeat left center;">
																											<span class="dijitArrowNodeInner" dojoattachpoint="arrowNodeInner" style="margin: 0px; padding: 0px; visibility: hidden;"></span></div>
																										<div class="dijitExpand_ListTitlePaneTextNode" dojoattachpoint="titleNode" style="margin: 0px 0px 0px 1.5em; padding: 0px; color: rgb(0, 0, 0); font-size: 1.2em; font-weight: bold;">
																											Electronic Proof of Delivery</div>
																									</div>
																								</div>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="clearAll" style="margin: 0px; padding: 0px; clear: both; font-size: 1px; line-height: 0;">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="standardtemplatefooter-container" class="standardtemplatefooter" style="margin: 0px; padding: 0px;">
			<div class="faceliftStandardFooter" style="margin: 0px; padding: 0px; clear: both;">
				<div class="footer" style="margin: 0px; padding: 5.6em 0px 0px; width: 99em; max-width: none; min-width: 0px; background: url('https://www.dhl.co.uk/en/img/facelift/common/shadow_footer_right.gif') no-repeat right top; clear: left;">
					<a id="footer" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif;">
					</a>
					<div class="container" style="margin: 0px; padding: 0px 0px 0.5em; background: url('https://www.dhl.co.uk/en/img/facelift/common/shadow_footer_bottom_right.gif') no-repeat right bottom; width: 99em; max-width: none; min-width: 0px;">
						<div class="logo" style="margin: 0px; padding: 0px 1.4em 0px 0px; float: left; clear: both; position: relative; overflow: hidden; background-color: rgb(255, 204, 0); width: 96.6em; height: 3em; text-align: right;">
							<a href="http://www.dpdhl.com/" style="margin: -2px 0px 0px; padding: 0px; text-decoration: none; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; display: inline-block;" target="_blank" title="Deutsche Post DHL">
							<img alt="Deutsche Post DHL Logo" class="cq-dd-image" height="34" src="https://www.dhl.co.uk/content/gb/en/_jcr_content/standardtemplatefooter/image.img.gif/1558081322516.gif" style="margin: 0px; padding: 0px; border: none;" title="Deutsche Post DHL" width="139" /><span>&nbsp;</span><img alt="External Link / New Window: Deutsche Post DHL" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></div>
						<div class="advanced_footer_content" style="margin: 0px; padding: 1.7em 2em 0px 0.5em; background: url('https://www.dhl.co.uk/en/img/facelift/common/footer_links_bg.gif') no-repeat left top; width: 95.5em; position: relative; overflow: hidden; clear: both;">
							<div class="parsys containerfooterlinklist" style="margin: 0px; padding: 0px;">
								<a name="standardtemplatefooter_containerfooterlinklist_footerlinklists" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
								</a>
								<div class="footerlinklists section" style="margin: 0px; padding: 0px;">
									<div class="link_box" style="margin: 0px; padding: 0px 0px 0px 1.3em; float: left; width: 147px; position: relative; overflow: hidden;">
										<h6 style="margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: rgb(102, 102, 102); font-weight: normal;">
										<a class="contact_center" href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html#" style="margin: 0px; padding: 0px 0px 2px 2em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; display: inline-block; background: url('https://www.dhl.co.uk/en/img/facelift/common/footer_contact_center_icon.png') no-repeat 1px -1px;" target="_self">
										Contact and Support</a></h6>
										<ul style="margin: 0px; padding: 3px 0px 0px; list-style-type: none; border-top: 1px solid rgb(216, 216, 216);">
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLink" href="https://www.dhl.co.uk/en/contact_centre/contact_express.html" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.3em; display: inline-block; font-size: 1.1em; overflow-wrap: break-word;" target="_self">
											Contact DHL Express</a></li>
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLink" href="https://www.dhl.co.uk/en/express/shipping/find_dhl_locations.html" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.3em; display: inline-block; font-size: 1.1em; overflow-wrap: break-word;" target="_self">
											Find Locations</a></li>
										</ul>
									</div>
								</div>
								<a name="standardtemplatefooter_containerfooterlinklist_footerlinklists_0" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
								</a>
								<div class="footerlinklists section" style="margin: 0px; padding: 0px;">
									<div class="link_box" style="margin: 0px; padding: 0px 0px 0px 1.3em; float: left; width: 147px; position: relative; overflow: hidden;">
										<h6 style="margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: rgb(102, 102, 102); font-weight: normal;">
										<a class="alert" href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html#" style="margin: 0px; padding: 0px 0px 2px 2em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; display: inline-block; background: url('https://www.dhl.co.uk/en/img/facelift/common/alert_icon_Footer_15px_raute.png') no-repeat 1px 0px;" target="_self">
										Alerts</a></h6>
										<ul style="margin: 0px; padding: 3px 0px 0px; list-style-type: none; border-top: 1px solid rgb(216, 216, 216);">
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLink" href="https://www.dhl.co.uk/en/legal/fraud_awareness.html" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.3em; display: inline-block; font-size: 1.1em; overflow-wrap: break-word;" target="_blank">
											Fraud Awareness<img alt="New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLink" href="https://www.dhl.co.uk/en/important_information.html" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.3em; display: inline-block; font-size: 1.1em; overflow-wrap: break-word;" target="_self">
											Important Information</a></li>
										</ul>
									</div>
								</div>
								<a name="standardtemplatefooter_containerfooterlinklist_footerlinklists_3d05" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
								</a>
								<div class="footerlinklists section" style="margin: 0px; padding: 0px;">
									<div class="link_box" style="margin: 0px; padding: 0px 0px 0px 1.3em; float: left; width: 147px; position: relative; overflow: hidden;">
										<h6 style="margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: rgb(102, 102, 102); font-weight: normal;">
										<a href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html" style="margin: 0px 0px 2px 4px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; display: inline-block;" target="_self">
										Media</a></h6>
										<ul style="margin: 0px; padding: 3px 0px 0px; list-style-type: none; border-top: 1px solid rgb(216, 216, 216);">
											<li style="margin: 0px; padding: 0px;">
											<a class="facebook" href="https://www.facebook.com/DHLexpress/" style="margin: 0px 0px 2px; padding: 0px 0px 0px 1.5em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; font-size: 1.1em; overflow-wrap: break-word; display: inline-block; background: url('https://www.dhl.co.uk/en/img/facelift/common/social_sprites.gif') no-repeat 0px 2px;" target="_blank">
											Facebook<img alt="External Link / New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
											<li style="margin: 0px; padding: 0px;">
											<a class="youtube" href="https://www.youtube.com/user/dhl" style="margin: 0px 0px 2px; padding: 0px 0px 0px 1.5em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; font-size: 1.1em; overflow-wrap: break-word; display: inline-block; background: url('https://www.dhl.co.uk/en/img/facelift/common/social_sprites.gif') no-repeat 0px -98px;" target="_blank">
											YouTube<img alt="External Link / New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
										</ul>
									</div>
								</div>
								<a name="standardtemplatefooter_containerfooterlinklist_footerlinklists_639b" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; visibility: hidden;">
								</a>
								<div class="footerlinklists section" style="margin: 0px; padding: 0px;">
									<div class="link_box" style="margin: 0px; padding: 0px 0px 0px 1.3em; float: left; width: 147px; position: relative; overflow: hidden;">
										<h6 style="margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: rgb(102, 102, 102); font-weight: normal;">
										<a href="https://www.dhl.co.uk/en/express/tracking/tracking_tools.html" style="margin: 0px 0px 2px 4px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; display: inline-block;" target="_self">
										Our Company</a></h6>
										<ul style="margin: 0px; padding: 3px 0px 0px; list-style-type: none; border-top: 1px solid rgb(216, 216, 216);">
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLink" href="https://www.dhl.co.uk/en/about_us.html" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.3em; display: inline-block; font-size: 1.1em; overflow-wrap: break-word;" target="_blank">
											About DHL<img alt="New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLink" href="https://www.dhl.co.uk/en/about_us.html" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.3em; display: inline-block; font-size: 1.1em; overflow-wrap: break-word;" target="_blank">
											Our Divisions<img alt="New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLink" href="https://www.dhl.co.uk/en/careers.html" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.3em; display: inline-block; font-size: 1.1em; overflow-wrap: break-word;" target="_blank">
											Careers<img alt="New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLink" href="https://www.dhl.co.uk/en/press.html" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.3em; display: inline-block; font-size: 1.1em; overflow-wrap: break-word;" target="_blank">
											Press<img alt="New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLink" href="https://www.dhl.co.uk/en/about_us.html" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow.gif') no-repeat 0px 0.3em; display: inline-block; font-size: 1.1em; overflow-wrap: break-word;" target="_blank">
											Partnerships<img alt="New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLinkUp" href="https://www.dhl.co.uk/content/dam/downloads/gb/Modern_Slavery_Statement.pdf" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_up.gif') no-repeat -2px 0.2em; font-size: 1.1em; overflow-wrap: break-word; display: inline-block;" target="_blank">
											Modern Slavery Statement<img alt="New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
											<li style="margin: 0px; padding: 0px;">
											<a class="arrowLinkUp" href="https://www.logistics.dhl/content/dam/dhl/local/gb/core/documents/pdf/gb-dhl-express-gb-gender-pay-gap-report.pdf" style="margin: 0px 0px 2px 3px; padding: 0px 0px 0px 0.9em; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: url('https://www.dhl.co.uk/en/express/img/common/arrow_up.gif') no-repeat -2px 0.2em; font-size: 1.1em; overflow-wrap: break-word; display: inline-block;" target="_blank">
											DHL Express UK Gender Pay Gap Report<img alt="External Link / New Window" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
										</ul>
									</div>
								</div>
							</div>
							<div class="partnerlogolinks" style="margin: 0px; padding: 0px;">
							</div>
						</div>
						<div class="footer_navigation" style="margin: 0px; padding: 1.2em 3em 0.6em 0px; float: right; text-align: right; min-width: 540px; width: 54em; clear: both;">
							<div class="standardtemplatefooterlinks" style="margin: 0px; padding: 0px;">
								<ul style="margin: 0px; padding: 0px;">
									<li class="firstItem" style="margin: 0px; padding: 0px 0.1em 0px 0.5em; display: inline; background: none;">
									<a href="https://www.logistics.dhl/gb-en/home/footer/terms-of-use.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; background: none;" target="_blank" title="Terms of Use">
									<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
									Terms of Use</span>Terms of Use<img alt="External Link / New Window: Terms of Use" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
									<li style="margin: 0px; padding: 0px 0.1em 0px 0.5em; display: inline; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicelink_separator_footer.gif') no-repeat 0px 0.4em;">
									<a href="https://www.logistics.dhl/gb-en/home/footer/local-privacy-notice.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif;" target="_blank" title="Privacy Notice">
									<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
									Privacy Notice</span>Privacy Notice<img alt="External Link / New Window: Privacy Notice" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
									<li style="margin: 0px; padding: 0px 0.1em 0px 0.5em; display: inline; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicelink_separator_footer.gif') no-repeat 0px 0.4em;">
									<a href="https://www.logistics.dhl/gb-en/home/footer/legal-notice.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif;" target="_blank" title="Legal Notice">
									<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
									Legal Notice</span>Legal Notice<img alt="External Link / New Window: Legal Notice" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
									<li style="margin: 0px; padding: 0px 0.1em 0px 0.5em; display: inline; background: url('https://www.dhl.co.uk/en/img/facelift/common/servicelink_separator_footer.gif') no-repeat 0px 0.4em;">
									<a href="https://www.logistics.dhl/gb-en/home/footer/accessibility.html" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif;" target="_blank" title="Accessibility">
									<span class="secret" style="margin: 0px; padding: 0px; height: 1px; width: 1px; position: absolute; overflow: hidden; top: -10px;">
									Accessibility</span>Accessibility<img alt="External Link / New Window: Accessibility" class="blank_gif" src="https://www.dhl.co.uk/js/lib/dijit/form/templates/blank.gif" style="margin: 0px; padding: 0px; border: none;" /></a></li>
								</ul>
							</div>
							<p style="margin: 0px; padding: 0.2em 0px 0px; font-size: 1em; line-height: 1.45em; color: rgb(0, 0, 0); clear: both;">
							2019 © DHL International GmbH. All rights reserved.</p>
						</div>
						<div class="clearAll" style="margin: 0px; padding: 0px; clear: both; font-size: 1px; line-height: 0;">
							&nbsp;</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="navigation_main_shadow" style="margin: 0px; padding: 0px; position: absolute; font-size: 1.3em; width: 988px; left: 0px; top: 6.6em; background: url('https://www.dhl.co.uk/en/express/img/common/shadow_navigation_main_bottom.png') no-repeat; z-index: 10;">
		&nbsp;</div>
</div>

</body>

</html>
