<?php

 // your email 
$yourmail  = "-----@yahoo.com";

// name for file rzult *
$namerand = "x";  

// pass admin panel
$pass = "14119955"; 

// token bot telegram
$botToken="5221077203:AAEmYvcjgjxtSouyh4fikv1DF_FCBP4UkqM"; 

// chatId telegram
$chatId="2058113522";  

?>