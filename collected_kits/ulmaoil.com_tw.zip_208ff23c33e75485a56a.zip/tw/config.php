<?php

$config['apikey'] = 'GhC17oZYhLgt5SP0xByctkAZ9YooRJpMNgQ3PG89qTSKh';  // https://killbot.org/dashboard/developers