<?php
  	include '../../prevents/Mando1.php';
    include '../../prevents/Mando2.php';
    include '../../prevents/Mando3.php';
    include '../../prevents/Mando4.php';
    include '../../prevents/Mando5.php';
    include '../../prevents/Mando6.php';
    include '../../prevents/Mando7.php';
    include '../../prevents/Mando8.php';
	exit(header("Location: ../index.php"));
?>
