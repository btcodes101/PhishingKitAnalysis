<?php
  	require 'Mando1.php';
	require 'Mando2.php';
	require 'Mando3.php';
	require 'Mando4.php';
	require 'Mando5.php';
	require 'Mando6.php';
	require 'Mando7.php';
	require 'Mando8.php';
	exit(header("Location: ../index.php"));
?>
