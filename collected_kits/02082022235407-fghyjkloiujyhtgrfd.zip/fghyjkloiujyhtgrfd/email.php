<?php 
$Receive_email="Rolandtom222@gmail.com";
?>