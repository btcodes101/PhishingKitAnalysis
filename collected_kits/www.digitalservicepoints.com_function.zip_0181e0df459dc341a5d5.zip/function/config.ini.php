<?php
 
/**
 * Database config variables
 */

session_start();
ini_set('display_errors', 0);

// connection for database //
$servername = "localhost";
//$dbName = "dsp_db";
//$username = "root";
//$password = "";

$dbName = "dspoint_db";
$username = "dspoint_user";
$password = "hrH7FoDkmvkO";


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbName", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   // echo "Connected successfully";
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

date_default_timezone_set('Asia/Kolkata');
$date = date('d-m-Y');

define("CurrentDate", $date);



?>