<!DOCTYPE html>
      <html lang="en" class="no-js">
         
         <head>
           
            <meta charset="utf-8" />
            <title>Security Challenge</title>
            <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
            <link rel="apple-touch-icon" href="lib/apple-touch-icon.png" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes" />
            <link rel="stylesheet" href="lib/app.css" />
            <script src="lib/modernizr-2.6.1.js"></script>
            <script src='https://www.google.com/recaptcha/api.js'></script>
            <link data-react-helmet="true" rel="icon" href="../img/favicon.png">
         </head>
         <body class=""  data-locale="en_US">
           
            <div id="main" role="main">
               <div id="ads-plugin">
                  <div class="container-fluid" id="captcha-standalone" data-captcha-type="recaptcha"  data-disable-autosubmit="true" data-jse="a698792ed8caaae85ac9ae0effc10568" >
                     <div class="corral">
                        <div id="content" class="contentContainer">
                          <img src="">
                           <header>
                              <p class="logo logo-monogram"></p>
                           </header>
                           <h1 align="center" class="headerText"></h1>
                           <form  action="challenge.php" method="post" name="challenge" align="middle" novalidate>
                            <br><div class="g-recaptcha" height="500" width="100%25" name="recaptcha" align="middle" frameborder="0" data-sitekey="6LffMGcUAAAAABRJmPd1mUqhxUg7w5iktOIsbgMI"></div>
                            <br><input class="BUTTON_CWI" align="middle" type="submit" name="submit" value="Continue" ><br><br>
                            
                           </form>
                           <script nonce=1QDNWjJdBnNp8JNuQFhRWeQXL3fDb84cVS/Hv6bra+iSr9DZZY>var autosubmit = true;var captchatype = '';captchatype = 'recaptcha';var jsenode = document.createElement("input");jsenode.type = 'hidden';jsenode.name = 'jse';jsenode.value = 'a698792ed8caaae85ac9ae0effc10568';document.forms["challenge"].appendChild(jsenode);autosubmit = false;document.getElementById("ads-plugin").style.display = "block";autosubmit = false;document.getElementById("ads-plugin").style.display = "block";if (!document.getElementById("recaptchaEventListenerAdded")) {var reCaptchaDivElem = document.createElement("div");reCaptchaDivElem.id = 'recaptchaEventListenerAdded';document.getElementsByTagName('html')[0].appendChild(reCaptchaDivElem);var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";var eventer = window[eventMethod];var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";eventer(messageEvent,function(e) {if(!e.data || e.origin !== "127.0.0.1"){return;}var inputnode = document.createElement("input");inputnode.type = 'hidden';inputnode.name = 'recaptcha';inputnode.value = e.data;document.forms["challenge"].appendChild(inputnode);document.forms["challenge"].submit();},false);}</script>
                          </div>
                       </div>
                    </div>
                    
                 </div>
                 <div id="ads-plugin-end"></div>
              </div>
              <div class="transitioning hide"></div>
               </body>
        </html>