<?php
//--- [ API KEY CONFIG] --//

$config['apikey'] 			= 'ZwbaZINystrF6K3D_GDnLdrcywuAJ6p054khCWDlHw39l';            // https://killbot.org/developers

//--- [ PAGE CONFIG ] ---//

$config['bot_block']    	= false;                    // if this domain is visited by bot / vpn / proxy it will be blocked. (Config Setting : https://killbot.org/blocker)
$config['redirect_bot'] 	= 'https://google.com';
$config['username_panel'] 	= 'admin';
$config['password_panel'] 	= 'admin';