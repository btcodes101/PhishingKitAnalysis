<?

$to = "mankindlogz1@gmail.com";

?>