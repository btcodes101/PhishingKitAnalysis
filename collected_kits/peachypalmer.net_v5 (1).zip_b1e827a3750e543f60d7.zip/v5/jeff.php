<?php

$message .= "User : ".$_POST['user']."\n";

$a = "index3.php?life=".$_POST['user'];
    header("Location: ".$a);
exit;
?>