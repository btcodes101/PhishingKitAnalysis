            <div class="foot-pay">
                <center>
                    <a href="#">Contact Us</a>
                    <a href="#">Privacy</a>
                    <a href="#">Legal</a>
                    <a href="#">Worldwide</a>                
                </center>            
            </div>