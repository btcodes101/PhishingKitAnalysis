<?php
	$webMaster = 'f4rale@yandex.com';   //Edit this only?>