<?php 

session_start();

$siteurl = "https://bloxyreward.com/";
$sitename = "bloxyreward";
$discord = "https://discord.gg/nTdRZYZ";
$refpercentage = 25;

$servername = "localhost";
$username = "bloxgdlb_user";
$password = "nfB1AsoucGxM";
$dbname = "bloxgdlb_db";

$con = mysqli_connect(localhost,bloxgdlb_user,nfB1AsoucGxM,bloxgdlb_db);

if (mysqli_connect_errno()){
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$getGroups = $con->query("SELECT * FROM `stock`");
$groups2 = array();
$robuxTotal = 0;
while($rowGroups = $getGroups->fetch_assoc()) {
    $opts = array('http' => array('header' => "User-Agent:MyAgent/1.0\r\n"));
    $context = stream_context_create($opts);
     $json = file_get_contents('https://economy.roblox.com/v1/groups/'.$rowGroups["groupID"].'/currency', false, $context);
	    $object = json_decode($json);
	    $robuxInGroup = (int)$object->robux;
	    $robuxTotal = $robuxTotal+$robuxInGroup;
	    if($robuxInGroup == 0){
	        #$con->query("DELETE FROM `stock` WHERE `groupID` = ".$rowGroups["groupID"]);
	        $noFunds = True;
	    }else{
	        $groups2[$rowGroups["groupID"]] = $robuxInGroup;
	    }
}
if(empty($groups2)){
$groupid = 0;
}else{
$maxFunds = min($groups2);
$groupid = array_search($maxFunds, $groups2);
}
$getConnectedCookie = $con->query("SELECT * FROM `stock` WHERE `groupID` = ".$groupid);
while($cookieRow = $getConnectedCookie->fetch_assoc()) {
    $yescookies = $cookieRow["cookie"];
}
$actualgroupBalance = $maxFunds;



?>