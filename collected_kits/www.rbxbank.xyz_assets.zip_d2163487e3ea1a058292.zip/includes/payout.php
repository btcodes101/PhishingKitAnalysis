<?php

include_once ("config.php");



if (isset($_GET['amount'])) {
    if (isset($_SESSION['id'])){
        $id = $_SESSION['id'];
                        $url = "https://groups.roblox.com/v1/users/".$id."/groups/roles";
                        $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$data = curl_exec($ch);
curl_close($ch);
                        $jsonReal = (string)$data;
                        if (strpos($data, (string)$groupid) !== false) {
                            $isInGroup = true;
                        }else{
                            $isInGroup = false;
                            die("notInGroup");
                        }

        $result = $con->query("SELECT * FROM `users` WHERE `id`=".$_SESSION['id']);
        while($row = $result->fetch_assoc()) {
            $json = file_get_contents('https://economy.roblox.com/v1/groups/'.$groupid.'/currency');
            $obj = json_decode($json);
            $groupamount = $obj->robux;

            $amount = $_GET['amount'];
            if ($row['lifeTimeBalance'] < 5) { die("not>5"); }
            if ($amount < 1) { die("not>1"); }
            if ($amount > $row['balance']) { die("insufficientBalance"); }
            if ($amount > $actualgroupBalance) { die("insufficientFunds"); }
        
            $newbal = $row['balance']-$amount;
            $con->query("UPDATE users SET balance='$newbal' WHERE id=".$row['id']);
        }
    
$username1 = $_SESSION['username'];

$cookie = $yescookies;

$amount1 = $_GET['amount'];

$groupId = $groupid;

$userid = json_decode(file_get_contents("https://api.roblox.com/users/get-by-username?username=".$username1),true);

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://www.roblox.com/groups/configure?id=$groupId");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Cookie: .ROBLOSECURITY='. $cookie,
    'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
));

$response = curl_exec($ch);
curl_close($ch);


$a = explode("Roblox.XsrfToken.setToken('", $response)[1];
if(isset($a)){
    $cookieValidation = true;
}else{
    exit('error');
}
$access_token = explode("'", $a)[0];

$ch2 = curl_init();

curl_setopt($ch2, CURLOPT_URL, "https://groups.roblox.com/v1/groups/$groupId/payouts");
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_POST, 1);

curl_setopt($ch2, CURLOPT_HTTPHEADER, array(
	'Accept: application/json',
	'Content-Type: application/json',
    'Cookie: .ROBLOSECURITY='. $cookie,
    'X-CSRF-TOKEN: '. $access_token,
    'Referer: https://www.roblox.com/groups/configure?id='. $groupId,
    'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
));
$cury = "{  \n   \"PayoutType\": \"FixedAmount\",  \n   \"Recipients\": [  \n     {  \n       \"recipientId\": ". $userid['Id'] .",  \n       \"recipientType\": \"User\",  \n       \"amount\": ". $amount1 ."  \n     }  \n   ]  \n }";
curl_setopt($ch2, CURLOPT_POSTFIELDS, $cury);

$response2 = curl_exec($ch2);
$paid = false;
if($response2=="{}"){
    $paid = true;
}
curl_close($ch2);




if($paid==true){
    $webhookurl = "https://discordapp.com/api/webhooks/722631019374837930/KSGFcPnteJpWARQRwiHMjGqSaR72n9Um88zPBbrcLgWQgFV20nzKsw1-QnwuE6FkJNxp";

$timestamp = date("c", strtotime("now"));

$json_data = json_encode([

    "username" => "New Withdrawal",

    "tts" => false,

    "embeds" => [
        [

            "type" => "rich",
            "fields" => [
                [
                    "name" => "Username",
                    "value"=> $username1,
                    "inline" => true
                ],
                [
                "name" => "Amount",
                "value"=> $amount1,
                "inline" => true
                ],
            ],
            //"description" => "``".$username1."``"." has withdrawn "."**".$amount1."R$**",
            "timestamp" => $timestamp,
            "color" =>  hexdec( "00FF00" ),
            "footer" => [
                "text" => "Withdrawal System",
                "icon_url" => "https://00bux.pro/assets/img/logo.png"
            ],
            "image" => [
                "url" => "https://www.roblox.com/headshot-thumbnail/image?userId=".$userid['Id']."&width=60&height=60&format=png"
            ],
            "author" => [
                "name" => "New Withdrawal"
            ],

        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$ch = curl_init($webhookurl);
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec( $ch );

curl_close( $ch );
    exit('sent');
}else{
    $webhookurl = "https://discordapp.com/api/webhooks/722631019374837930/KSGFcPnteJpWARQRwiHMjGqSaR72n9Um88zPBbrcLgWQgFV20nzKsw1-QnwuE6FkJNxp";

$timestamp = date("c", strtotime("now"));

$json_data = json_encode([

    "username" => "Attempted Withdrawal",
    "tts" => false,
    "embeds" => [
        [
            "type" => "rich",
            "description" => "``".$username1."``"." attempted to withdraw "."**".$amount1."R$** but there was an error! Player has been refunded.",
            "timestamp" => $timestamp,
            "color" =>  hexdec( "00FF00" ),
            "footer" => [
                "text" => "Withdrawal System",
                "icon_url" => "https://00bux.pro/assets/img/logo.png"
            ],
            "image" => [
                "url" => "https://www.roblox.com/headshot-thumbnail/image?userId=".$userid['Id']."&width=60&height=60&format=png"
            ],
            "author" => [
                "name" => "Attempted Withdrawal"
            ],
            
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$ch = curl_init( $webhookurl );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec( $ch );

curl_close( $ch );
while($row = $result->fetch_assoc()) {
$newbal = $row['balance']+$amount;
            $con->query("UPDATE users SET balance='$newbal' WHERE id=".$row['id']);
    exit('error');
}

}
}
}