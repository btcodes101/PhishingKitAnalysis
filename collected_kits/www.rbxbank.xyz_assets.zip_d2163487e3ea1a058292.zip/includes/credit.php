<?php

include("config.php");

define('myip','92.5.48.50');

$req = file_get_contents("https://api.roblox.com/users/get-by-username?username=".$_GET['username']);
$a = json_decode($req, true);
$ip = $_SERVER['REMOTE_ADDR'];

if($ip === myip){

$result = $con-> query("SELECT * FROM users WHERE `id`=".$a['Id']);
if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()){
        $newbal = round($row['balance']+$_GET['amount']);
        $lifeTimeBalance = round($row['lifeTimeBalance']+$_GET['amount']);
        $con->query("UPDATE users SET balance='$newbal' WHERE id=".$row['id']);
        $con->query("UPDATE users SET lifeTimeBalance='$lifeTimeBalance' WHERE id=".$row['id']);        
        $usr = $row;

        $usernmae = $row['username'];
        $uID = $row['id'];

        $url = "https://discordapp.com/api/webhooks/740224279370793002/ptJIjd7b2cDjPkZSJIPhsTaHGC5IT3bsXRc4EcCF-QtK2XOD4QsNx7Fj2FXfUHOrRVR7";
    
        $timestamp = date("c", strtotime("now"));
        $json_data = json_encode([
            "username" => "Credited User",
            "tts" => false,
            "embeds" => [
                [
        
                    "type" => "rich",
                    "description" => "``".$_GET['username']."``"." was credited "."**".$_GET['amount']."R$**",
                    "timestamp" => $timestamp,
                    "color" =>  hexdec( "00FF00" ),
                    "footer" => [
                        "text" => "Credit System",
                        "icon_url" => "https://00bux.pro/assets/img/logo.png"
                    ],
                    "image" => [
                        "url" => "https://www.roblox.com/headshot-thumbnail/image?userId=".$userid['Id']."&width=60&height=60&format=png"
                    ],
                    "author" => [
                        "name" => "New Credit"
                    ],
        
                ]
            ]
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

$ch = curl_init($url);
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec( $ch );

curl_close( $ch );
echo '{"status":"credited"}';

exit();
    
    }
}else{
    echo '{"status":"notRegistered"}';
}
}else{
    exit("bad ip");
}
?>