<?php

include("config.php");

$req = file_get_contents("https://api.roblox.com/users/get-by-username?username=".$_GET['username']);
$a = json_decode($req, true);

$result = $con->query("SELECT * FROM users WHERE `id`=".$a['Id']);
if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        echo '{"status":"complete","refs":'.$row['refs'].'}';
    }
}else{
    echo '{"status":"notRegistered"}';
}

?>