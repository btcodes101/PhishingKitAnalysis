<?php

include("config.php");

$promocode= "bux"; 


$worth = 1;
$worth2 = 2;

if(isset($_GET['code'])){
    if($_GET['code'] == $promocode || $_GET['code'] == $promocode2 || $_GET['code'] == $promocode3 || $_GET['code'] == $promocode4 || $_GET['code'] == $promocode5){
        $result = $con->query("SELECT * FROM users WHERE 'id'=".$_SESSION['id']);
        
        if($_GET['code'] == $promocode){
            $result = $con->query("SELECT * FROM users WHERE `id`=".$_SESSION['id']);
            if($_GET['code'] == $promocode){
                $resultForPromo = $con->query("SELECT * FROM promocode WHERE `id`=".$_SESSION['id']);
            if ($resultForPromo->num_rows == 0) {
                while($row = $result->fetch_assoc()) {
                    $con->query("INSERT INTO promocode (username, id) VALUES ('".$row['username']."', '".$_SESSION['id']."')");
                    $newbal = $row['balance'] + $worth2;
                    $con->query("UPDATE users SET balance='$newbal' WHERE id=".$_SESSION['id']);
                }
                echo 'success';
            } else {
                echo 'redeemed';
            }
        }
        }
    }else{
    echo "invalid";
    }
}




?>