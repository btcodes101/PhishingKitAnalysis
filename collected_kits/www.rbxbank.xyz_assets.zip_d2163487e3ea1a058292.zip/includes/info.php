<?php
include("config.php");

if (isset($_SESSION['id'])){
	$result = $con->query("SELECT * FROM `users` WHERE `id`=".$_SESSION['id']);
	while($row = $result->fetch_assoc()) {
		$balance = $row['balance'];
		$lifeTimeRobux = $row['lifeTimeBalance'];
		$userID = $row['id'];
		$userName = $row['username'];
		$groups = file_get_contents("https://groups.roblox.com/v1/users/".$_SESSION['id']."/groups/roles");
		$str = $groups;
        $substr = $groupid;
		$refCount = $row["refs"];
        $refBalance = $row["refBalance"];

        if($row["linkedRef"]){
        	$reffed = false;
        }else{
        	$reffed = $row["linkedRef"];
		}
		if (strpos($str, $substr) == true) {
        	$inGroup = true;
        }else{
        	$inGroup = false;
        }
	}
}


    $robuxBal = $con->query("SELECT `lifeTimeBalance` FROM `users`") or die();
	$plrCount = $con->query("SELECT `username` FROM `users`") or die();
	$robuxCount = $con->query("SELECT `amount` FROM `offers`") or die();

	$amountOfUsers = 0;
    $offerscompleted = 0;
	$totalRobux = 0;

	while($row2=$plrCount->fetch_assoc())
	{
		$amountOfUsers = $amountOfUsers + 1;
    }
    while($row3=$robuxCount->fetch_assoc())
	{
		$offerscompleted = $offerscompleted + 1;
    }
    while($row4=$robuxBal->fetch_assoc()){
        $totalRobux=$totalRobux + $row4['lifeTimeBalance'];
    }

$globalUserCount = $amountOfUsers;
$globalOfferCount = $offerscompleted;
$globalEarnigns = $totalRobux;
$groupBalance = $robuxTotal;
$actualgroupbalance = $maxFunds;




?>