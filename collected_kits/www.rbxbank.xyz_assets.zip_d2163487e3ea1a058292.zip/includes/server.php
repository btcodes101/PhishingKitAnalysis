<?php 
include("config.php");
define('AyeT_IP1', '35.165.166.40');
define('AyeT_IP2', '35.166.159.131');
define('AyeT_IP3', '52.40.3.140');
define('myip','92.5.48.50');
define('offerToro_IP','54.175.173.245');
define('AdGate_IP', '104.130.7.162'); 
define('AdGate_IP2', '52.42.57.125');
$ip = $_SERVER['REMOTE_ADDR'];
function doNotify($username, $userid, $amount){
    $ok = "test";
}

function notifyRef($refsName, $refs2ndName, $refsID, $refsAmountEarned){
    $webhookurl = "https://discordapp.com/api/webhooks/722631019374837930/KSGFcPnteJpWARQRwiHMjGqSaR72n9Um88zPBbrcLgWQgFV20nzKsw1-QnwuE6FkJNxp";

    $timestamp = date("c", strtotime("now"));

    $json_data = json_decode([
        "username" => "New Referral Paid",
        "tts" => false,
        "embeds" => [
            "type" => "rich",
            "description" => "``".$refsName."``"." just earned "."**".$refsAmountEarned."R$** from referring ``".$refs2ndName."``",
            "timestamp" => $timestamp,
            "color" => hexdec("00FF00"),
            "footer" => [
                "text" => "Referral System",
                "icon_url" => "https://00bux.pro/assets/img/logo.png"
            ],
            "image" => [
                "url" => "https://www.roblox.com/headshot-thumbnail/image?userId=".$refsID."&width=60&height=60&format=png"

            ],
            "author" => [
                "name" => "New Referral Paid"
            ],
        ]
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

$ch = curl_init($webhookurl);
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec( $ch );
curl_close( $ch );

}

if($ip === myip || $ip === AyeT_IP1 || $ip === AyeT_IP2 || $ip === AyeT_IP3 || $ip === offerToro_IP || $ip === AdGate_IP || $ip === AdGate_IP2){
    if(isset($_GET['provider1'])){
        $result = $con->query("SELECT * FROM users WHERE `id`=".$_GET['userid']);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $newbal = round($row['balance']+$_GET['amount']);
        $query = "SELECT username from offers where TID='".$_GET['tx_id']."'";
$result2 = $con->query($query);

if($result2->num_rows > 0)
{
    exit("nosir");
}
        $lifeTimeBalance = round($row['lifeTimeBalance']+$_GET['amount']);
        $con->query("UPDATE users SET balance='$newbal' WHERE id=".$_GET['userid']);
        $con->query("UPDATE users SET lifeTimeBalance='$lifeTimeBalance' WHERE id=".$_GET['userid']);

        doNotify($row['username'],$row['id'],$_GET['amount']);

        $refCode = $row["linkedRef"];
        if($refCode==0){
            $reffed = false;
        }else{
            $result2 = $con->query("SELECT * FROM users WHERE `id`=".$refCode);
            if ($result2->num_rows > 0) {
                while($row2 = $result2->fetch_assoc()) {
                    $amountEarned = $_GET['amount'] * 0.15;
                    $amountEarnedRounded = round($amountEarned,0);
                    $newbal2 = round($row2['balance']+$amountEarnedRounded);

                    $newRefBalance = round($row2['refBalance']+$amountEarnedRounded);
                    $refCount = $row2['refs']+1;

                    $con->query("UPDATE users SET balance='$newbal2' WHERE id=".$refCode);
                    $con->query("UPDATE users SET refBalance='$newRefBalance' WHERE id=".$refCode);
                    $con->query("UPDATE users SET refs='$refCount' WHERE id=".$refCode);

                    $refsName = $row2['username'];
                    $refsID = $row2['id'];
                    $refsAmountEarned = $amountEarnedRounded;

                    notifyRef($refsName, $row['username'], $refsID, $refsAmountEarned);
                }
            }
        } 
        $usr = $row;
        
        
        $username = $row['username'];
        $IID = $row['id'];

        $con->query("INSERT INTO offers (username, id, amount, TID, offerwall) VALUES ('$username', '$IID', '".$_GET['amount']."', '".$_GET['tx_id']."', 'Offerwall')");
        
        
        $url = "https://discordapp.com/api/webhooks/722631019374837930/KSGFcPnteJpWARQRwiHMjGqSaR72n9Um88zPBbrcLgWQgFV20nzKsw1-QnwuE6FkJNxp";


$webhookurl = "https://discordapp.com/api/webhooks/722631019374837930/KSGFcPnteJpWARQRwiHMjGqSaR72n9Um88zPBbrcLgWQgFV20nzKsw1-QnwuE6FkJNxp";


$timestamp = date("c", strtotime("now"));

$json_data = json_encode([

    "username" => "New Conversion",
    "tts" => false,

    "embeds" => [
        [

            "type" => "rich",
            "fields" => [
                [
                    "name" => "Username",
                    "value"=> $username,
                    "inline" => true
                ],
                [
                "name" => "Amount",
                "value"=> $_GET['amount'],
                "inline" => true
                ],
            ],
            //"description" => "``".$username."``"." completed an offer worth "."**".$_GET['amount']."R$** on ``Offerwall``",
            "timestamp" => $timestamp,
            "color" =>  hexdec( "00FF00" ),
            "footer" => [
                "text" => "00bux.pro",
                "icon_url" => "https://00bux.pro/assets/img/logo.png"
            ],
            "image" => [
                "url" => "https://www.roblox.com/headshot-thumbnail/image?userId=".$IID."&width=60&height=60&format=png"
            ],
            "author" => [
                "name" => "New Conversion"
            ],   
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$ch = curl_init( $webhookurl );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec( $ch );
// If you need to debug, or find out why you can't send message uncomment line below, and execute script.
// echo $response;
curl_close( $ch );


header( "HTTP/1.1 200 OK" );
exit();
      
            }
        }
    }
}
if(!isset($_GET['provider'])){
    $result = $con->query("SELECT * FROM users WHERE `id`=".$_GET['userid']);
if ($result->num_rows > 0) {
while($row = $result->fetch_assoc()) {

            $query = "SELECT username from offers where TID='".$_GET['tx_id']."'";
$result2 = $con->query($query);

if($result2->num_rows > 0)
{
exit("nosir");
}
    $newbal = round($row['balance']+$_GET['amount']);
    $lifeTimeBalance = round($row['lifeTimeBalance']+$_GET['amount']);
    $con->query("UPDATE users SET balance='$newbal' WHERE id=".$_GET['userid']);
    $con->query("UPDATE users SET lifeTimeBalance='$lifeTimeBalance' WHERE id=".$_GET['userid']);



    doNotify($row['username'],$row['id'],$_GET['amount']);

    $refCode = $row["linkedRef"];
    if($refCode==0){
        $reffed = false;
    }else{
        $result2 = $con->query("SELECT * FROM users WHERE `id`=".$refCode);
        if ($result2->num_rows > 0) {
            while($row2 = $result2->fetch_assoc()) {
                $amountEarned = $_GET['amount'] * 0.15;
                $amountEarnedRounded = round($amountEarned,0);
                $newbal2 = round($row2['balance']+$amountEarnedRounded);

                $newRefBalance = round($row2['refBalance']+$amountEarnedRounded);
                $refCount = $row2['refs']+1;

                $con->query("UPDATE users SET balance='$newbal2' WHERE id=".$refCode);
                $con->query("UPDATE users SET refBalance='$newRefBalance' WHERE id=".$refCode);
                $con->query("UPDATE users SET refs='$refCount' WHERE id=".$refCode);

                $refsName = $row2['username'];
                $refsID = $row2['id'];
                $refsAmountEarned = $amountEarnedRounded;
                notifyRef($refsName, $row['username'], $refsID, $refsAmountEarned);
            }
        }
    }
    $usr = $row;
    
    
    $username = $row['username'];
    $IID = $row['id'];

    $con->query("INSERT INTO offers (username, id, amount, TID, offerwall) VALUES ('$username', '$IID', '".$_GET['amount']."', '".$_GET['tx_id']."', 'OfferToro')");
    
    
    $url = "https://discordapp.com/api/webhooks/722631019374837930/KSGFcPnteJpWARQRwiHMjGqSaR72n9Um88zPBbrcLgWQgFV20nzKsw1-QnwuE6FkJNxp";


$webhookurl = "https://discordapp.com/api/webhooks/722631019374837930/KSGFcPnteJpWARQRwiHMjGqSaR72n9Um88zPBbrcLgWQgFV20nzKsw1-QnwuE6FkJNxp";

//=======================================================================================================
// Compose message. You can use Markdown
// Message Formatting -- https://discordapp.com/developers/docs/reference#message-formatting
//========================================================================================================

$timestamp = date("c", strtotime("now"));

$json_data = json_encode([

"username" => "New Conversion",
"tts" => false,
"embeds" => [
    [
        "type" => "rich",
        "fields" => [
                [
                    "name" => "Username",
                    "value"=> $username,
                    "inline" => true
                ],
                [
                "name" => "Amount",
                "value"=> $_GET['amount'],
                "inline" => true
                ],
            ],
        //"description" => "``".$username."``"." completed an offer worth "."**".$_GET['amount']."R$** on ``Offerwall``",
        "timestamp" => $timestamp,
        "color" =>  hexdec( "00FF00" ),
        "footer" => [
            "text" => "00bux.pro",
            "icon_url" => "https://00bux.pro/assets/img/logo.png"
        ],
        "image" => [
            "url" => "https://www.roblox.com/headshot-thumbnail/image?userId=".$IID."&width=60&height=60&format=png"
        ],
        "author" => [
            "name" => "New Conversion"
        ],        
    ]
]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$ch = curl_init( $webhookurl );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec( $ch );
// If you need to debug, or find out why you can't send message uncomment line below, and execute script.
// echo $response;
curl_close( $ch );


echo 1;
        
        
  
    
}
}
}else{
    echo 'Not Whitelisted IP';

    $webhookurl = "https://discordapp.com/api/webhooks/730882281668870208/QL7KnaBXJucWNd6amfRSG5DAIdJb7nBMf69fMudeXbq-R9oJ16RQy-s5NHnfSPbZGDNe";

//=======================================================================================================
// Compose message. You can use Markdown
// Message Formatting -- https://discordapp.com/developers/docs/reference#message-formatting
//========================================================================================================

$timestamp = date("c", strtotime("now"));

$json_data = json_encode([


    "username" => "Unathorized Postback Attempt",
    "tts" => false,
    "embeds" => [
        [
            "type" => "rich",
            "description" => "**IP**:\n".$ip,
            "timestamp" => $timestamp,
            "color" =>  hexdec( "00FF00" ),
            "footer" => [
                "text" => "Unathorized",
                "icon_url" => "https://00bux.pro/assets/img/logo.png"
            ],
            "author" => [
                "name" => "Unathorized Postback Attempt"
            ],        
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$ch = curl_init( $webhookurl );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec( $ch );
curl_close( $ch );


}
?>