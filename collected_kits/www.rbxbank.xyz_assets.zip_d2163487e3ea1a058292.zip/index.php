<?php
   include("includes/config.php");
   include("includes/info.php");
    
    if(isset($_SESSION['id'])){
        header("location: dashboard");
    }else{
        $loggedIn = false;
    }
    $loggedin = false;
    if (isset($_POST['username'])) {
        $username = strip_tags(htmlentities(urldecode($_POST['username'])));
        $req = file_get_contents("https://api.roblox.com/users/get-by-username?username=".$username);
        if ($req != '{"success":false,"errorMessage":"User not found"}') {
            $aaa = json_decode($req, true);
            $result = $con->query("SELECT * FROM users WHERE `id`=".$aaa['Id']);
            if ($result->num_rows == 0) {
                $b = strtolower($username);
                if(isset($_GET["ref"])){
                    $ref = $_GET["ref"];
                    $result2 = $con->query("SELECT * FROM users WHERE `id`=".$ref);
                    if ($result2->num_rows == 0) {
                        $isref = "found";
                    }else{
                        $isref = "invalid ref found";
    
                    }
    
                    if($isref=="invalid ref found"){
                        while($row2 = $result2->fetch_assoc()) {
                                $con->query("INSERT INTO users (username, id, balance, lifeTimeBalance, discordLinkID, linkedRef) VALUES ('$b', '".$aaa['Id']."', 0, 0, '".hash('ripemd160', $aaa['Id'].$username)."', ".$ref.")");
    
                                $afterBalance = round($row2["refs"]+1);
                                $con->query("UPDATE users SET refs='$afterBalance' WHERE id=".$_GET["ref"]);
                        }
                    }else{
                        $con->query("INSERT INTO users (username, id, balance, lifeTimeBalance, discordLinkID) VALUES ('$b', '".$aaa['Id']."', 0, 0, '".hash('ripemd160', $aaa['Id'].$username)."')");
                    }
                }else{
                    $con->query("INSERT INTO users (username, id, balance, lifeTimeBalance, discordLinkID) VALUES ('$b', '".$aaa['Id']."', 0, 0, '".hash('ripemd160', $aaa['Id'].$username)."')");
                }
                $_SESSION['username'] = $username;
                $usr['id'] = $aaa['Id'];
                $usr['username'] = strtolower($username);
                $usr['balance'] = 0;
                $_SESSION['id'] = $aaa['Id'];
                $loggedin= true;
                $new = true;
                if($loggedin==true){
                    header("Location: dashboard.php");
                }
            } else {
                while($row = $result->fetch_assoc()) {
                    $_SESSION['username'] = $username;
                    $_SESSION['id'] = $aaa['Id'];
                    $loggedin = true;
                    if($loggedin==true){
                        header("Location: dashboard.php");
                    }
                }
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>00Bux - Earn Robux</title>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="description" content="00Bux is the #1 place to earn 100% FREE ROBUX by completing simple tasks with instant group funds payouts! ">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="theme-color" content="purple">
  <meta name="author" content="00Bux">
  <meta name="keywords" content="00bux,rblx,free robux,roblox,earn robux,robux promocodes,robux hack,roblox hack,roblox free,roblox,claim robux, robux generator">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
  <link rel="icon" type="image/png" href="/assets/img/logo.png">
<style>
  @keyframes float{
    0% {transform: translateY(0px);}
    50% {transform: translateY(-15px);}
    100% {transform: translateY(0px);}
  }
</style>

</head>
<body style="background-color: #242424;">

<div class="modal fade" id="myModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #343A40;">
                <h4 class="modal-title" style="color: white;">Login to 00Bux</h4>
                <button name="close" type="button" class="close" data-dismiss="modal">x</button>
            </div>
            <div class="modal-body" style="background-color: #343A40;">
                <form method="POST">
                    <h1 style="font-size: 25px; text-align: center; color: white;">Enter Roblox Username</h1>
                    <input style="border-bottom:1px solid white;box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);" type="text" name="username" placeholder="Roblox Username" class="form-control form-control-sm validate ml-0 valid">
                    <center>
                        <p style="color: red;">We will NEVER ask for your roblox password!</p>
                    </center>
                    <div class="waves-input-wrapper waves-effects waves-light" style="margin-top: 20px;">
                        <center>
                            <button type="submit" class="btn" value="Submit" style="background-color: purple; color: white;">Login</button>
                        </center>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top" style="box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);">
<a class="navbar-brand" href="#"><img alt="Brand" src="assets/img/logo.png" class="img-responsive" style="max-width: 54px;"></a>          
        <button class ="navbar-toggler" type ="button" data-toggle ="collapse" data-target ="#colNav">
        <span class ="navbar-toggler-icon"></span>
        </button>
        <div class ="collapse navbar-collapse" id ="colNav">

        <ul class="navbar-nav mr-auto">
          <li class="nav-item"><a class="nav-link" href="index">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="earn">Earn</a></li>
          <li class="nav-item"><a class="nav-link" href="referral">Referrals</a></li>
          <li class="nav-item"><a class="nav-link" href="withdraw">Withdraw</a></li>
          <li class="nav-item"><a class="nav-link" href="promocodes">PromoCode</a></li>          
      </ul>
      
        <button id="myBtn" data-toggle="modal" data-target="#myModal" class="btn my-2 my-sm-0" style="background-color: purple; color:white;">Login</button>

    </div>
</nav>

<div style="width: 100%; background: purple; box-shadow: 1px 1px 4px rgba(0,0,0,.3)">
  <h5 style="color: White; font-weight:350px; font-size: 18px; text-align: center; padding: 8px;">JOIN OUR DISCORD SERVER TO PARTICIPATE IN EVENTS AND GIVEAWAYS</h5>
</div>

<div class="main-content pt-0">
<div class="container">

<div class="page-header"><br><br>
<div class="container">
<center>
<section>
<div class="container">
    <div class="row align-items-center justify-content-around">
        <div class="col-md-7 mt-0">
            <h4 style="color: white;">Earn Free Robux</h4>
            <p style="color: white;">by watching videos, doing surveys, downloading apps</p>
            <button id="myBtn" data-toggle="modal" data-target="#myModal"style="width: 75%; background-color: purple!important; color: white;" class="btn"><a style="font-size: 15px;">GET STARTED</a></button>
        </div>
    <div class="col-md-5" style="text-align:center">
        <img style="animation: float 6s ease-in-out infinite; width:100%;" alt="Image" src="/assets/img/bux.png">
    </div>
</div>

</div>

</section>
</div>
</div>
</div>

</div>



   <main class="pt-5 mx-lg-5 ">

   <div class="row mt-lg-5">

            <div class="col-sm-12 col-md-6">
                <div class="card bg-dark mb-3">
                    <div class="card-body" style="border-radius: 5px;">
                        <h5 class="card-title" style="color: white;">Registered Users<i class="fa fa-user-friends" style="
                                    font-size: 55px;
                                    float: right;
                                    padding-right: 10px;
                                    color: white;
                                    "></i></h5>
                        <p class="card-text" style="color: white;"><?php echo $globalUserCount; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-6">
                <div class="card bg-dark mb-3">
                    <div class="card-body" style="border-radius: 5px;">
                        <h5 class="card-title" style="color: white;">Total Robux Earned <i class="fa fa-money-bill-wave-alt" style="
                                    font-size: 55px;
                                    float: right;
                                    padding-right: 10px;
                                    color: white;
                                    "></i></h5>
                        <p class="card-text" style="color: white;"><?php echo $globalEarnigns; ?> R$</p>
                    </div>
                </div>
            </div>
        </div> 
        <center style="margin-top: 25px;">

        <div class="row" style="border-radius: 10px; margin-top: 25px;">
        <div class="col-sm-12 col-md-4" style="
        box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);
        background-color: #343A40;">
            <div style="padding: 60px; border-radius: 3px;">
            <img src="/assets/svg/register.svg" style="height: 100px;">
            <br><br>
            <h5 style="font-weight: 900; color: white;">1. Link your Roblox account</h5>
            <p style="color: white;">Link your Roblox account to start earning Robux</p>
            </div>
        </div>
        <div class="col-sm-12 col-md-4" style="
        box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);
        background-color: #343A40;">
            <div style="padding: 60px; border-radius: 3px">
            <img src="/assets/img/laptop.png" style="height: 100px;">
            <br><br>
            <h5 style="font-weight: 900; color: white;">2. Earn  Robux</h5>
            <p style="color: white;">Earn Robux by completing offers</p>
            </div>
        </div>
        <div class="col-sm-12 col-md-4" style="
        box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);
        background-color: #343A40;">
            <div style="padding: 60px; border-radius: 3px">
            <img src="/assets/svg/withdraw.svg" style="height: 100px;">
            <br><br>
            <h5 style="font-weight: 900; color: white;">3. Withdraw</h5>
            <p style="color: white;">Instantly withdraw the Robux to your Roblox account</p>
            </div>
        </div> 
        </div>
    <br>    
        </center>
        

        </main>

<script type="text/javascript" src="assets/js/frameworks.js"></script>
<script src="includes/main.js"></script>

</body>

</html>
