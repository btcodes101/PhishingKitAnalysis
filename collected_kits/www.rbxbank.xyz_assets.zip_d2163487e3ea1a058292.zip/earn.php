<?php
include("includes/info.php");
include("includes/auth_session.php");
?>

<!DOCTYPE html>
<html>
<head>
  <title>bloxyreward - Earn</title>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="description" content="00Bux is the #1 place to purchase or earn 100% FREE ROBUX by completing simple tasks with instant group funds payouts! ">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="theme-color" content="purple">
  <meta name="author" content="00Bux">
  <meta name="keywords" content="00bux,rblx,free robux,roblox,earn robux,robux promocodes,robux hack,roblox hack,roblox free,roblox,claim robux, robux generator">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
  <link rel="icon" type="image/png" href="/assets/img/logo.png">
</head>
<body style="background-color: #242424;">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top" style="box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);">
<a class="navbar-brand" href="#"><img alt="Brand" src="assets/img/logo.png" class="img-responsive" style="max-width: 54px;"></a>          
        <button class ="navbar-toggler" type ="button" data-toggle ="collapse" data-target ="#colNav">
        <span class ="navbar-toggler-icon"></span>
        </button>
        <div class ="collapse navbar-collapse" id ="colNav">

        <ul class="navbar-nav mr-auto">
          <li class="nav-item"><a class="nav-link" href="index">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="earn">Earn</a></li>
          <li class="nav-item"><a class="nav-link" href="referral">Referrals</a></li>
          <li class="nav-item"><a class="nav-link" href="withdraw">Withdraw</a></li>
          <li class="nav-item"><a class="nav-link" href="promocodes">PromoCode</a></li>          
      </ul>
        <li class="nav-item" style="list-style-type: none; border-radius: 10px; max-width: 30%;">
            <center>
            <h style="font-size: 15px;" class="yourButton"><img id="plrPFP" style="
                max-width: 35px;
                position: relative;
                top: 1px;
                border-radius: 50%;
                border-color: white;
                margin-right: 10px;"
                src="https://www.roblox.com/headshot-thumbnail/image?userId=<?php
                if(isset($userID)){
                    echo $userID;
                }else{
                    echo '1';
                } ?>&amp;width=60&amp;height=60&amp;format=png">
                <h style="position:relative;
                right:10px;
                z-index: 1;
                font-weight: bold;
                color: white;
                text-transform: capitalize;"><?php echo $userName?></h>
                <h style="
                position:relative;
                right:10px;
                z-index: 1;
                color: white;
                " id="rbxBal"><img src="assets/img/robuxicon.png" width="15px" style="
                max-width: 15px;"><?php
                if(isset($balance)){
                    echo $balance;
                }else{
                    echo '0';
                } ?></h></h>
            </center>
        </li>
        <form class="form-inline my-2 my-lg-0">
            <a href="logout.php" class="btn my-2 my-sm-0" style="background-color: purple; color: white;">Logout</a>
        </form>
    </div>
</nav>
    <div class="container-fluid mt-5">
      <section>
          <center>
            <br>
          <div class="card text-center" style="background-color: #343A40;">
              <h4 class="card-title" style="padding-top: 30px; font-size: 30px; font-weight: bold; color:white;">Offerwalls</h4>
            <br>
            <div class="row justify-content-around">
              <div class="col-sm-10 cold-md-5">
              <ul class="nav md-pills nav-justified pills-secondary">
          <li class="nav-item">
          <a style="color:white!important;background-color: purple!important;max-width: 96%;border-radius: 20px; font-weight: bold;" class="nav-link btn ripple btn-lg btn-block waves-effect waves-light active show" data-toggle="tab" href="#panel1" role="tab" aria-selected="true">AdGate</a>
          </li>
          <li class="nav-item">
              <a style="color:white!important;background-color: purple!important;max-width: 96%;border-radius: 20px; font-weight: bold;" class="nav-link btn ripple btn-lg btn-block waves-effect waves-light" data-toggle="tab" href="#panel2" role="tab" aria-selected="false">Offertoro</a>
          </li>
          <li class="nav-item">
              <a style="color:white!important;background-color: purple!important;max-width: 96%;border-radius: 20px; font-weight: bold;" class="nav-link btn ripple btn-lg btn-block waves-effect waves-light" data-toggle="tab" href="#panel3" role="tab" aria-selected="false">Ayet Studios</a>
          </li>
        </ul>
        <p style="color: white;">Sometimes it may take up to 24 hours for an offer to credit to your account! If it hasn't then please contact offerwall support before you contact us!</p>
              </div>

            </div>
            <div class="card-body">
            <div class="tab-content">
        <div class="tab-pane fade in active show" id="panel1" role="tabpanel">
          <center>
          <iframe src="https://wall.adgaterewards.com/n6ebrA/<?php echo $_SESSION['id']; ?>" frameborder="0" width="100%" height="1200" ></iframe>
          </center>
          </div>
          <br>
          <div class="tab-pane fade" id="panel2" role="tabpanel">
          <center>
          <iframe src="https://www.offertoro.com/ifr/show/24512/<?php echo $_SESSION['id']; ?>/10175" frameborder="0" width="100%" height="1200" ></iframe> 
          </center>
          </div>
          <div class="tab-pane fade" id="panel3" role="tabpanel">
          <center>
          <iframe src="https://www.ayetstudios.com/offers/web_offerwall/1986/00Bux?external_identifier=<?php echo $_SESSION['id']; ?>" frameborder="0" width="100%" height="1200" ></iframe> 
          </center>
          </div>
            </div>
          </div>
        
        </div>
        </center>
      </section>
    </div>  

<script type="text/javascript" src="assets/js/frameworks.js"></script>
</body>
</html>