<?php
include("includes/info.php");
include("includes/auth_session.php");
?>

<!DOCTYPE html>
<html>
<head>
<title>00Bux - Referrals</title>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="description" content="00Bux is the #1 place to purchase or earn 100% FREE ROBUX by completing simple tasks with instant group funds payouts! ">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="theme-color" content="purple">
  <meta name="author" content="00Bux">
  <meta name="keywords" content="00bux,rblx,free robux,roblox,earn robux,robux promocodes,robux hack,roblox hack,roblox free,roblox,claim robux, robux generator">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
  <link rel="icon" type="image/png" href="/assets/img/logo.png">

</head>
<body style="background-color: #242424;">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top" style="box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);">
<a class="navbar-brand" href="#"><img alt="Brand" src="assets/img/logo.png" class="img-responsive" style="max-width: 54px;"></a>          
        <button class ="navbar-toggler" type ="button" data-toggle ="collapse" data-target ="#colNav">
        <span class ="navbar-toggler-icon"></span>
        </button>
        <div class ="collapse navbar-collapse" id ="colNav">

      <ul class="navbar-nav mr-auto">
          <li class="nav-item"><a class="nav-link" href="index">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="earn">Earn</a></li>
          <li class="nav-item"><a class="nav-link" href="referral">Referrals</a></li>
          <li class="nav-item"><a class="nav-link" href="withdraw">Withdraw</a></li>
          <li class="nav-item"><a class="nav-link" href="promocodes">PromoCode</a></li>          
      </ul>
        <li class="nav-item" style="list-style-type: none; border-radius: 10px; max-width: 30%;">
            <center>
            <h style="font-size: 15px;" class="yourButton"><img id="plrPFP" style="
                max-width: 35px;
                position: relative;
                top: 1px;
                border-radius: 50%;
                border-color: white;
                margin-right: 10px;"
                src="https://www.roblox.com/headshot-thumbnail/image?userId=<?php
                if(isset($userID)){
                    echo $userID;
                }else{
                    echo '1';
                } ?>&amp;width=60&amp;height=60&amp;format=png">
                <h style="position:relative;
                right:10px;
                z-index: 1;
                font-weight: bold;
                color: white;
                text-transform: capitalize;"><?php echo $userName?></h>
                <h style="
                position:relative;
                right:10px;
                z-index: 1;
                color: white;
                " id="rbxBal"><img src="assets/img/robuxicon.png" width="15px" style="
                max-width: 15px;"><?php
                if(isset($balance)){
                    echo $balance;
                }else{
                    echo '0';
                } ?></h></h>
            </center>
        </li>
        <form class="form-inline my-2 my-lg-0">
            <a href="logout.php" class="btn my-2 my-sm-0" style="background-color: purple; color: white;">Logout</a>
        </form>
    </div>
</nav>
<center>
<div class="container-fluid mt-5">
<section>
    <div class="card" style="top:10px; background-color: #343A40;">
              <div class="card-body">
                <h4 class="card-title" style="color: white;">Referrals</h4>
                <div class="text-center" style="text-align: center!important;">
                <label style="color: white;">Your referral Link:</label>
                <center>
                  <input id="userRefCode" name="code" type="text" min="1" max="100000" class="form-control col-md-6" style="height: 35;background-color: purple!important;border-color: purple!important;color: white;" value="https://00bux.pro?ref=<?php if(isset($userID)){ echo $userID;}else{echo 'none';}?>" readonly="">
                    </center>
                    <br>
                  <a class="btn btn-danger btn-md fa fa-clipboard waves-effect waves-light" style="margin-left: 10px;display: inline-block;font-weight: 400;color: #212529;text-align: center;vertical-align: middle;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-color: purple!important;border: 1px solid transparent;padding: .375rem .75rem;font-size: 1rem;line-height: 1.5;border-radius: .25rem;transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;color: white;margin-top: 5;" href="javascript:copyReferralStuff()"></a>
                  <p style="color: white;">Earn 25% of referral earnings for life from every single person you have referred! (Only new 00Bux users can use your link)</p>                                        
                </div>                                       
              </div>
            </div>
<br>
            <div class="card" style="top:20px; background-color: #343A40;">
              <div class="card-body">
              <center>
                <div style="font-weight: bold; font-size:20px;">
                  <p style="color: white;">Your referred users: <?php if(isset($refCount)){ echo $refCount;}else{echo 'none';}?></p>
                  <p style="color: white;">Your referral balance: <?php if(isset($refBalance)){ echo $refBalance;}else{echo 'none';}?> R$</p>                                          
                </div>                                       
              </center>
              </div>
            </div>
    </div>
</section>

            </center>

            <script type="text/javascript" src="assets/js/frameworks.js"></script>

<script type="text/javascript">

function httpGet(e) {
    var t = new XMLHttpRequest;
    return t.open("GET", e, !1), t.send(null), t.responseText
}

function copyReferralStuff(){
  $("#userRefCode").select();
  document.execCommand("Copy");
}

</script>
</body>
</html>