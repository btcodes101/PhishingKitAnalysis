<?php include("includes/info.php"); ?>

<!DOCTYPE html>

<body>
    <!--Navbar-->
    
<nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top" style="box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);">
<a class="navbar-brand" href="#"><img alt="Brand" src="assets/img/logo.png" class="img-responsive" style="max-width: 54px;"></a>          
        <button class ="navbar-toggler" type ="button" data-toggle ="collapse" data-target ="#colNav">
        <span class ="navbar-toggler-icon"></span>
        </button>
        <div class ="collapse navbar-collapse" id ="colNav">

      <ul class="navbar-nav mr-auto">
          <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="earn.php">Earn</a></li>
          <li class="nav-item"><a class="nav-link" href="withdraw.php">Withdraw</a></li>
          <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
      </ul> 
        <li class="nav-item" style="list-style-type: none; border-radius: 10px; max-width: 30%;">
            <center>
                <h style="font-size: 15px;" class="yourButton"><img id="plrPFP" style="
                max-width: 35px;
                position: relative;
                top: 1px;
                border-radius: 50%;
                border-color: black;
                margin-right: 10px;"
                src="https://www.roblox.com/headshot-thumbnail/image?userId=<?php
                if(isset($userID)){
                    echo $userID;
                }else{
                    echo '1';
                } ?>&amp;width=60&amp;height=60&amp;format=png">
                <h style="
                position:relative;
                right:10px;
                z-index: 1;
                color: black;
                " id="rbxBal"><img src="assets/img/robuxicon.png" width="15px" style="
                max-width: 15px;"><?php
                if(isset($balance)){
                    echo $balance;
                }else{
                    echo '0';
                } ?></h></h>
            </center>
        </li>
        <form class="form-inline my-2 my-lg-0">
            <a href="logout.php" class="btn btn-outline-danger my-2 my-sm-0" style="background-color: #d0043b; color: white;">Logout</a>
        </form>
    </div>
</nav>
</body>
