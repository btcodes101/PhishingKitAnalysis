<?php
include("includes/info.php");
include("includes/auth_session.php");
?>

<!DOCTYPE html>
<html>
<head>
<title>00Bux - Promocodes</title>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="description" content="00Bux is the #1 place to purchase or earn 100% FREE ROBUX by completing simple tasks with instant group funds payouts! ">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="theme-color" content="purple">
  <meta name="author" content="00Bux">
  <meta name="keywords" content="00bux,rblx,free robux,roblox,earn robux,robux promocodes,robux hack,roblox hack,roblox free,roblox,claim robux, robux generator">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
  <link rel="icon" type="image/png" href="/assets/img/logo.png">

</head>
<body style="background-color: #242424;">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top" style="box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);">
<a class="navbar-brand" href="#"><img alt="Brand" src="assets/img/logo.png" class="img-responsive" style="max-width: 54px;"></a>          
        <button class ="navbar-toggler" type ="button" data-toggle ="collapse" data-target ="#colNav">
        <span class ="navbar-toggler-icon"></span>
        </button>
        <div class ="collapse navbar-collapse" id ="colNav">

        <ul class="navbar-nav mr-auto">
          <li class="nav-item"><a class="nav-link" href="index">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="earn">Earn</a></li>
          <li class="nav-item"><a class="nav-link" href="referral">Referrals</a></li>
          <li class="nav-item"><a class="nav-link" href="withdraw">Withdraw</a></li>
          <li class="nav-item"><a class="nav-link" href="promocodes">PromoCode</a></li>          
      </ul>
        <li class="nav-item" style="list-style-type: none; border-radius: 10px; max-width: 30%;">
            <center>
            <h style="font-size: 15px;" class="yourButton"><img id="plrPFP" style="
                max-width: 35px;
                position: relative;
                top: 1px;
                border-radius: 50%;
                border-color: white;
                margin-right: 10px;"
                src="https://www.roblox.com/headshot-thumbnail/image?userId=<?php
                if(isset($userID)){
                    echo $userID;
                }else{
                    echo '1';
                } ?>&amp;width=60&amp;height=60&amp;format=png">
                <h style="position:relative;
                right:10px;
                z-index: 1;
                font-weight: bold;
                color: white;
                text-transform: capitalize;"><?php echo $userName?></h>
                <h style="
                position:relative;
                right:10px;
                z-index: 1;
                color: white;
                " id="rbxBal"><img src="assets/img/robuxicon.png" width="15px" style="
                max-width: 15px;"><?php
                if(isset($balance)){
                    echo $balance;
                }else{
                    echo '0';
                } ?></h></h>
            </center>
        </li>
        <form class="form-inline my-2 my-lg-0">
            <a href="logout.php" class="btn my-2 my-sm-0" style="background-color: purple; color: white;">Logout</a>
        </form>
    </div>
</nav>
<center>
<div class="container-fluid mt-5">
      <section>
    <div class="card" style="top:10px; background-color: #343A40;">
              <div class="card-body">
                  <h4 class="card-title" style="color: white;">Redeem Promo Codes</h4>
                  <div class="text-center" style="text-align: center!important;">
                    <label style="color: white;">Promo code:</label>
                    <center>
                    <input style="display: block;" id="codeEntry" name="code" type="text" min="1" max="100000" class="form-control col-md-6">
                    </center>
                    <h id="errorPopup" style="display:none;color:red">Invalid Promo Code!</h>
                    <br>
                    <button id="promoSubmit" style="width: 40%; background-color: purple; color: white;" type="submit" class="btn waves-effect waves-light">Submit</button>
                    <br>
                    <br>
                    <p style="color: white;">Join our Discord and follow our Twitter to get notified on when we drop promo codes</p>
                    <a href="https://discord.gg/2BvB9Aq"><img src="assets/svg/discord.svg"></a>
                    <a href="https://twitter.com/00_bux"><img src="assets/svg/twitter.svg"></a>
                    </div>
              </div>
          </div>
      </section>
            </div>
</center>

<script type="text/javascript" src="assets/js/frameworks.js"></script>
<script type="text/javascript">

function httpGet(e) {
    var t = new XMLHttpRequest;
    return t.open("GET", e, !1), t.send(null), t.responseText
}

    $("#promoSubmit").click(function() {
        var e = $("#codeEntry").val();
        document.getElementById("errorPopup").style.display = "none"

        $.ajax({
            url: "includes/promo.php?code=" + e,
            success: function(e) {

                "success" === e && (document.getElementById("errorPopup").innerHTML = "Successfully Redeemed!", document.getElementById("errorPopup").style.display = "block", document.getElementById("errorPopup").style.color = "green")
                "redeemed" === e && (document.getElementById("errorPopup").innerHTML = "You already redeemed this code!", document.getElementById("errorPopup").style.display = "block", document.getElementById("errorPopup").style.color = "red")
                "invalid" === e && (document.getElementById("errorPopup").innerHTML = "Invalid promocode!", document.getElementById("errorPopup").style.display = "block", document.getElementById("errorPopup").style.color = "red")
            }
        })
    })
</script>
</body>
</html>