<?php
/*
  //||~~ By ~~ saradauchia ~~\\         			       	                
 // Telegram Id: @saradauchia \\	
*/

$send ="mark.mcgraw111@gmail.com,markmcgraw111@vivaldi.net"; 

//telgram rzlt
$api = "Bot token";
$chatid = "Chat ID";


?>