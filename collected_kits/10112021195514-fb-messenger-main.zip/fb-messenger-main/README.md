# fb-messenger
This repository made for hack facebook messenger by phishing.  Here is available fb-messenger [login/home] (html page) with  php file which can help us to get credentials from victims. 


- Screenshot:
<br>
<p align="center">
<img width="60%" src="https://github.com/fh-rabbi/fb-messenger/blob/main/img/Screenshot_20210408-223936.png"/>
<h2><font color="red">Warning:</font></h2>
<p>It's just made for educational purpose, so don't use it illegal purpose 
