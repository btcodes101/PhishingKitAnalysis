<?php 

	// Your Mail Here
	$yours = "Leeroyy777@yahoo.com";
	

	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}?>
