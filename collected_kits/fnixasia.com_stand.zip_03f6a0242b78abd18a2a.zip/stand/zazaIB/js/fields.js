function validNumberField(field, e, nextField) {
    var key;
    var keychar;
    if (window.event) {
        key = window.event.keyCode;
    } else if (e) {
        key = e.which;
    } else {
        return true;
    }
    keychar = String.fromCharCode(key);
    if ( (key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) ) {
        return true;
    } else if ( ("0123456789").indexOf(keychar) > -1 ) {
        return true;
    } else if ( nextField && (keychar == ".") ) {
        nextField.focus();
        nextField.select();
        return false;
    }
    return false;
}
function NumbersOnly(field, e, nextField) {
    return validNumberField(field, e, nextField);
}
function validDateField(field, e) {
    var key;
    var keychar;
    if (window.event) {
        key = window.event.keyCode;
    } else if (e) {
        key = e.which;
    } else {
        return true;
    }
    keychar = String.fromCharCode(key);
    if ( (key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) ) {
        return true;
    } else if ( ("0123456789-").indexOf(keychar) > -1 ) {
        return true;
    }
    return false;
}

function toggleCheckBoxes( field, on_off ) {

	var browserType;
	
	if (document.layers) {browserType = "nn4"}
	if (document.all) {browserType = "ie"}
	if (window.navigator.userAgent.toLowerCase().match("gecko")) {
	   browserType= "gecko"
	}
	
	if (browserType == "gecko" )
     	selDiv = eval('document.getElementById("manageList")');
  	else if (browserType == "ie")
     	selDiv = eval('document.getElementById("manageList")');
  	else
     	selDiv = eval('document.layers["manageList"]');
	
	var checkboxs = selDiv.getElementsByTagName('input');
	for(var i = 0, inp; inp = checkboxs[i]; i++) if(inp.type.toLowerCase() == 'checkbox') inp.checked = on_off;
	
}

function selectoneCheckBox(field, index ){
    var i =  0;
    do {
        fieldname = field + '['+ i +'].checked';
        if (document.forms[0].elements[ fieldname ]) {
            document.forms[0].elements[ fieldname ].checked = (i== index);
        }
        i++;
    } while ( document.forms[0].elements[ fieldname ] );

}

function selectCheckBox(field, index ) {
    fieldname = field + '['+ index +'].checked';
    if (document.forms[0].elements[ fieldname ]) {
        document.forms[0].elements[ fieldname ].checked = true;
    }
}

submitcount = 0;
function submitOnce() {                     
    if (submitcount == 0) {
        submitcount++;
        return true;
    } else {
        alert("This form has already been submitted.");
        return false;
    }
}
