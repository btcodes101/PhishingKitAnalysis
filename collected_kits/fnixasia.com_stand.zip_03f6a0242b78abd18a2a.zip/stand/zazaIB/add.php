<?php
error_reporting(0);
define ("EMAIL", "owonla1403@gmail.com");
?>
