<!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="navbar-collapse">
      <ul class="nav navbar-nav">
      	<li id="accounts_li" class="active">
          <a href="#"><i class="fa fa-home"></i>&nbsp;Home</a>          
        </li>
        
        <li id="statements_li" class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
			  <i class="fa fa-file-text"></i>&nbsp;Statements</a>
        </li>
        
        <li id="payments_li" class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-credit-card"></i>&nbsp;Payments</a>
        </li>
        
        <li id="accountservices_li" class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cog"></i>&nbsp;Account Services</a>
          
        </li>
        
        <li id="prepaid_li" class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-mobile"></i>&nbsp;Pre-paid</a>
          
        </li>
        <li id="unittrusts_li" class="dropdown">
          <a href="#"><i class="fa fa-pie-chart"></i>&nbsp;Unit Trusts</a>
          
        </li>
        <li id="asi_li" class="dropdown">
          <a href="#"><i class="fa fa-line-chart"></i>&nbsp;Auto Share Invest</a>
          
        </li>
        <li>
          <a href="#"><i class="fa fa-user"></i>&nbsp;Profile</a>
        </li>
        <?php
        if(basename($_SERVER['PHP_SELF']) == 'connected.php')
        {
		?>        
        <li>
			<a href="https://www.standardbank.co.za/site/ib_logoff/logoffpage.html?"><i class="fa fa-arrow-circle-right" style="color: red;"></i>&nbsp;Log out</a>
		</li>
		<?php } else { ?>
			<li>
			<a href="#"><i class="fa fa-arrow-circle-right" style="color: red;"></i>&nbsp;Log out</a>
		</li>
		<?php } ?>
      </ul>
    </div>
    </div>
  </div>
