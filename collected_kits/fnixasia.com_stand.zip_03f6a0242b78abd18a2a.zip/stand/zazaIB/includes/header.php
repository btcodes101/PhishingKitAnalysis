<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Internet banking</title>
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="shortcut icon" href="images/favicon.ico">

		<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
		<link rel="stylesheet" href="css/ladda-themeless.min.css" type="text/css">
		<link rel="stylesheet" href="css/jquery-ui-1.10.0.custom.css" type="text/css">

		<link rel="stylesheet" href="css/ib-bootstrap.css" type="text/css">		
		<!--[if IE]>
		<style>
			@media (min-width: 991px) {
				 .navbar-nav {
				    display:inline-block;
				    float: none;
				    margin: 0;
				    height: 35px;
				 }
			}		    
		</style>
		<![endif]-->
		<style type="text/css">
			.radio label, .checkbox label {
				padding-left: 20px;
				margin-bottom: 0;
			}			
			.radio input[type=radio], .radio-inline input[type=radio], .checkbox input[type=checkbox], .checkbox-inline input[type=checkbox] {
				position: absolute;
			}
			.dropdown-menu {
  				text-align: left;
  			}
		</style>
		<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
		<script type="text/javascript" src="js/jquery-ui.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="js/dataTables.bootstrap.js"></script>
		<script type="text/javascript" src="js/spin.min.js"></script>
		<script type="text/javascript" src="js/ladda.min.js"></script>		
		<script type="text/javascript">
		$(document).ready(function() {			
			Ladda.bind( 'button[type=submit]'
			//		, { timeout: 10000 }
			);
			$('#pageContent').css('opacity', '0').fadeTo(250, 1,'swing');			
		});
		</script>
		
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->	

<script language="JavaScript" type="text/javascript" src="js/watchdog.js"></script> 

			<script type="text/javascript">
				$(document).ready(function() {
					$(".navbar-default li").removeClass("active");
					$('#accounts_li').addClass('active');
				});
			</script>
	</head>
	<body class="default">


	<div id="topmenu">
	<div class="modal js-loading-bar">		
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-body progress-popup-body">
					<div class="progress progress-popup progress-striped active">
						<div class="progress-bar"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
		<div class="navbar navbar-default navbar-fixed-top" role="navigation">
			



<div id="topBarFrame">
<div class="row siteheader">
	<div class="container">
		<div class="siteLogo">
			<img class="" alt="Standard Bank" src="images/OrganizationLogo.png">
		</div>
		<div class="siteMap hidden-xs"></div>
	</div>
</div>
</div>
