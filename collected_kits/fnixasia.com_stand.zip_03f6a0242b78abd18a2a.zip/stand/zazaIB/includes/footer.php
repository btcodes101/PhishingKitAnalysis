<footer>
	<div class="row">
		<div class="col-sm-12">
			<img class="img-responsive pull-right" style="padding-top: 10px; padding-right: 20px; width: 135px;" src="images/movingfwd.png" alt="Movingforwardtrademarklogo">			
			<p class="pull-left" style="padding-top: 10px; padding-left: 20px;">
				<small>&copy; <?php echo date("Y"); ?> Standard bank 
				<span id="footerText">is a licensed financial services provider in terms of the Financial Advisory and Intermediary Services Act.</span></small>
			</p>
		</div>
	</div>	
</footer>
