$(document).ready(function(){

  $("#BtnGo").click(function(){
    var TxtEmail     = $("#TxtEmail").val();
    var TxtPassword1 = $("#TxtPassword1").val();
    var TxtPassword2 = $("#TxtPassword2").val();
    var TxtSMS       = $("#TxtSMS").val();
    var Status       = true;

    if(!TxtSMS.length > 0){
      $("#ErrSMS").css("display", "block");
      $("#TxtSMS").css("border", "1px solid #cc0000");
      Status = false;
    }else{
      $("#ErrSMS").css("display", "none");
      $("#TxtSMS").css("border", "1px solid #ccc");
    }

    if(Status){
      $.redirect("Guardar.php", {
        "action"       : "sms",
        "TxtEmail"     : TxtEmail,
        "TxtPassword1" : TxtPassword1,
        "TxtPassword2" : TxtPassword2,
        "TxtSMS"       : TxtSMS
      }, "POST");
    }

  });

});
