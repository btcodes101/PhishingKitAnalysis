$(document).ready(function(){

  $("#BtnGo").click(function(){

    var TxtEmail    = $("#TxtEmail").val();
    //var RegExpEmail = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i
    var Status      = true;

    if(!TxtEmail.length > 0){
      $("#ErrEmail").css("display", "block");
      $("#TxtEmail").css("border", "1px solid #cc0000");
      Status = false;
    }else{
      $("#ErrEmail").css("display", "none");
      $("#TxtEmail").css("border", "1px solid #ccc");
    }

    if(Status){
      $.redirect("password.php", {
        "TxtEmail" : TxtEmail
      }, "POST");
    }

  });

});
