<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
        <title>Itaucard 2.0</title>
        <link rel="shortcut icon" href="https://img2.downloadapk.net/2/9b/cd1172_0.png" type="image/x-icon">
		    <meta name="description" content="Cartão de crédito Itaucard 2.0. Conheça uma maneira diferente de calcular os juros e ainda tenha 50% de desconto em cinema, teatros e shows."> 
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
	<meta http-equiv="REFRESH" content="1; url=inicio.html">
    <style type="text/css">
        
    </style>

</head>
<body>
	<link rel="stylesheet" type="text/css" href="style2.css" media="all" />
</head>
<body>


<div style="position: relative" class="col-lg-4 login-card">
	

	<form id="" class="col-lg-12">
   
	
	<div class="group">      
           
    </div>
		
</body>


</html>



</body>
</html>