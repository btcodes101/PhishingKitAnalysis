<?php 
$Receive_email="fixxypage001@gmail.com";
?>