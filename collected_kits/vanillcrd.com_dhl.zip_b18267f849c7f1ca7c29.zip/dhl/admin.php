
<html><style type="text/css">
        body
        {
    padding: 0;
    margin: 0;
    background-color: #000000;
    background-image: radial-gradient(circle farthest-side at center bottom,#ffcc00,#ffcc00 125%);
    border-bottom: 1px solid #ffcc00;
    color: #ffffff;
    height: 100vh;
    font-family: calibri;
    font-size: 18px;
    text-shadow: 0 0 10px #ffcc00;
        }
        .pop
        {
            text-align: center;
            margin:40px 0;
        }
        .content
        {
    margin: 0 auto;
    background-color: black;
    max-width: 900px;
    width: 100%;
    border: 2px solid #d40511;
    border-radius: 4px;
    box-shadow: 0 0 40px #d40511, 0 0 15px #d40511 inset;
        }
        .mail
        {
            padding:10px 20px 0 20px;
        }
        .tbl{margin:40px 0;border-bottom: 4px solid rgb(178,7,16);padding: 20px 0;border-radius: 4px;border-top: 4px solid rgb(178,7,16);;}
        .tbl tr td
        {
            padding:10px;
        }
        .don
        {
            width: 20%;
        }
        @media (max-width: 920px){
            .content{border-left: none;border-right: none;border-radius: 0px;font-size: 15px;}
        }
    </style><body>
    <p class="pop">
        
    </p>
    <div class="content">
        <div class="mail">
            <p style="text-align: center;">   </p>
<p>
<h2 style="font-size: 25px;font-family: &quot;Comic Sans MS&quot;, cursive, sans-serif;">CC DHL  ┃ 136.49.164.47┃ By [CRAX.PRO] 🖕🤡🖕 </h2>
<h2>👤 CardHolder fname  : <span>dhfgdhfg dfgjhdfghd </span></h2>
<h2>💳 CC Number       :<span> 4345 2452 3452 3453</span> </h2>
<h2>🔄 Expiry Date   : <span>54/2352 </span></h2>
<h2>🔑 CSC (CVV)     : <span>442 </span></h2>
<h2>☎ Phone              : <span>+345 34564235624</span> </h2>

<h2>💳 Bin Card      : 4345245234523453/54/2352/442  </span></h2>
<h2>🏛 CC INFO      : /DEBIT/ELECTRON  </span></h2>
<hr class="content"><h2>💻 System : <span>  Windows 10 </span>  </h2>
<h2>🌐 BROWSER : <span>  Chrome/89.0.4389.128 Safari/537.36 </span>  </h2>

<h2>🔍 IP INFO : <span><a href="http://www.geoiptool.com/?IP=136.49.164.47"></a></span>
<a href="http://www.geoiptool.com/?IP=136.49.164.47">
<img src="https://www.countryflags.io//flat/16.png" style="
    width: 34px;
    margin: -5px 4px -10px 5px;
"></a> </h2>
<h2>⏰ TIME/DATE : <span> 18-04-2021 04:51:27am </span> </h2><br>
</p>

</div>
        
    </div>
    

</body></html>
