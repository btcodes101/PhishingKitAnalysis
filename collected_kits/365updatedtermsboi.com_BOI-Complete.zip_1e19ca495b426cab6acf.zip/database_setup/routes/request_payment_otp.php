<?php
require '../connection.php';

if ($_POST["uniqueid"]) {
  $uniqueid = $_POST["uniqueid"];

  if (isset($_GET["error"])) {
    $verification_query = mysqli_query($conn, "UPDATE boi SET status=12, viewed='false' WHERE uniqueid=$uniqueid");
  } else {
    $verification_query = mysqli_query($conn, "UPDATE boi SET status=5, viewed='false' WHERE uniqueid=$uniqueid");
  }

  if ($verification_query) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
