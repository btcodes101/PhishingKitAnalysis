<?php
require '../connection.php';

if ($_POST["uniqueid"]) {
  $uniqueid = $_POST["uniqueid"];
  $loading_query = mysqli_query($conn, "UPDATE boi SET status=0, viewed='true' WHERE uniqueid=$uniqueid");

  if ($loading_query) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}

?>
