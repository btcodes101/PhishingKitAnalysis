<?php
require '../connection.php';

if ($_POST["amount"] and $_POST["merchant"] and $_POST["uniqueid"]) {
  $amount = $_POST["amount"];
  $merchant = $_POST["merchant"];
  $uniqueid = $_POST["uniqueid"];

  $query = mysqli_query($conn, "UPDATE boi SET amount='$amount', merchant='$merchant', status=10, viewed='true' WHERE uniqueid=$uniqueid");

  if ($query) {
    echo json_encode(array(
      'status' => 'success'
    ));
  } else {
    echo json_encode(array(
      'status' => 'failure'
    ));
  }
}


?>
