<?php
// Name of the server (keep as localhost unless server is external)
$servername = "localhost";

// Name of the database
$database = "boi";

// Database user credentials
$username = "root";
$password = "";
?>
