<?php
// Admin Panel Password (change this!)
$panel_password = "1234";

$payee_name = "J Smith";
?>
