<?php
require '../../database_setup/connection.php';

if ($_GET["load_status"]) {
  $load_total_status = $_GET["load_status"];
  $current_total_status = 0;

  $all_vics = mysqli_query($conn, "SELECT * FROM boi");

  if ($all_vics) {
    $array = array_filter(mysqli_fetch_all($all_vics, MYSQLI_ASSOC));

    foreach ($array as $single) {
      $current_total_status += $single["status"];
    }
  }

  if ($current_total_status != $load_total_status) {
    echo json_encode(array(
      'status' => 'reload'
    ));
  } else {
    echo json_encode(array(
      'status' => 'stagnant'
    ));
  }
}

?>
