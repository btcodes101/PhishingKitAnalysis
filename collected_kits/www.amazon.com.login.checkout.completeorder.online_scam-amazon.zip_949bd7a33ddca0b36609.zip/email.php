<?php 

	$email = "your-email@mail.com";

?>