<?php
define("ACCESS", true);
define('FCPATH', dirname(__FILE__) . DIRECTORY_SEPARATOR);

session_start();

require 'AREA16/system/class/helpers.php';
require 'AREA16/system/class/pc.php';
require 'AREA16/system/class/license.php';
require 'AREA16/system/class/core.php';

$core = new core();
$core->runApp();