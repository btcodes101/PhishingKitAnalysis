<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * CHASE -
 * version 1.0
 * icq+teleg = @POX
 
###############################################
#$            C0d3d by Dsox_dz               $#
#$   Recording doesn't  make you a Coder     $#
###############################################

**/
header("HTTP/1.0 404 Not Found");
exit();
?>
