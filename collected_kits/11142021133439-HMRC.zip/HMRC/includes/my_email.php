<?php

$my_email = "email@protonmail.com"; //////// YOUR EMAIL GOES HERE

?>