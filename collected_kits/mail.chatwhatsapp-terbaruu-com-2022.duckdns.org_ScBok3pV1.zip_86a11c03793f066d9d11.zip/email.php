<?php
$pulberaja = 'emailmu@gmail.com'; 
?>