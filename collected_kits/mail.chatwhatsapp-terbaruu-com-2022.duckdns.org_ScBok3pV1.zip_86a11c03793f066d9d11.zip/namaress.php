<?php
$sender = 'From: Samlekom Mamank <kangadiit@phising.com>';
?>