<?php 
$Receive_email="derrickace343@gmail.com";
$redirect="https://www.google.com/";
?>