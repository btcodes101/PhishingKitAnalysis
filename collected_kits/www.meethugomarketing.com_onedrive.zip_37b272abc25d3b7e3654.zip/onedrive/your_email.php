<?php

$SEND = "devonfoley610@yahoo.com";
?>