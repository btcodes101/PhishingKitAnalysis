<?php
require_once('../inc/functions.php');

$token = $query['access_token'];
$query = array(
    "Content-type" => "application/json"
);
$order_id = $_POST['orderId'];
$get_order = shopify_call($token, $shop, "/admin/api/2019-10/orders/".$order_id.".json", array(), 'GET');
$get_order = json_decode($get_order['response'], TRUE);

$order_attr = $get_order['order']['note_attributes'];

$key = $value = [];
$i = 0;
foreach($order_attr as $orderattr){
	$key[$i] = $orderattr['name'];
	$value[$i] = $orderattr['value'];
	$i++;
}
$old_attr = array_combine($key, $value);
if(isset($_POST['action']) and $_POST['action']=='picked'){
	$new_attr = array(
		"Packed-by-Id" => $_POST['option'],
		"Packed-by"=> $_POST['picked_by']
	);
}
elseif(isset($_POST['action']) and $_POST['action']=='delivered'){
	$new_attr = array(
		"Delivered-by-Id" => $_POST['option'],
		"Delivered-by"=> $_POST['delivered_by']
	);
}
elseif(isset($_POST['action']) and $_POST['action']=='pickedup_by'){
	$new_attr = array(
		"Pickedup-by"=> $_POST['pickedup_by']
	);
}
elseif(isset($_POST['action']) and $_POST['action']=='mark_ready'){
	$new_attr = array(
		"Status"=> 'Ready'
	);
}
$attr = array_merge($old_attr, $new_attr);
// echo "<pre>";
// print_r ($attr);
// echo "</pre>";


//exit;
// Modify order data
$modify_data = array(
	"order" => array(
		"id" => $order_id,
		"note_attributes" => $attr
	)
);

$p = shopify_call($token, $shop, "/admin/api/2019-10/orders/".$order_id.".json", $modify_data, 'PUT');
print_r($p['response'],true);
?>