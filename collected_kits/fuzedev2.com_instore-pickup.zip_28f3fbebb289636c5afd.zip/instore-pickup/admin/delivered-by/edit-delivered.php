<?php
require_once('../../inc/functions.php');
?>
<?php
$id = $_GET['id'];
$getdelivered = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM delivered_by WHERE id = '".$id."'"));

if(isset($_POST['submit'])){
	extract($_POST);

	$row = mysqli_num_rows(mysqli_query($con, "SELECT name FROM delivered_by WHERE name = '".$name."' AND id!='".$id."'"));
	if($row>0){
		$msg = '<div class="alert alert-danger"><b>'.$name.'</b> already exist.</div>';
	}
	else{
		$query = mysqli_query($con, "UPDATE delivered_by SET name='".mysqli_real_escape_string($con,trim($name))."' WHERE id = '".$id."'");
		if($query==1){
			unset($_POST);
			$msg = '<div class="alert alert-success">Name updated successfully.</div>';
		}
		else{
			$msg = '<div class="alert alert-danger">Something went wrong! Please try again.</div>';
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Delivered By</title>
    <?php require_once("../../inc/mycss.php");?>
</head>
<body>
    <div class="container-fluid">
        <h3>Edit Delivered By</h3>
        <br>
        <div class="row">
        	<div class="col-md-4"><a href="../delivered-by.php" class="btn btn-sm btn-primary pull-right"><i class="fa fa-angle-left" aria-hidden="true"></i> Back</a></div>
        </div>
        <div class="clearfix"></div>
        <br>
        <div class="row">
        	<div class="col-md-4">
        		<?php echo isset($msg)?$msg:'';?>
		        <form name="delivered" id="delivered" method="post">
		        	<div class="form-group">
		        		<input type="text" name="name" id="name" class="form-control" value="<?php echo isset($_POST['name'])?$_POST['name']:$getdelivered['name']?>">
		        	</div>
		        	<div class="form-group">
		        		<button type="submit" name="submit" class="add_button btn btn-md btn-success">Save</button>
		        	</div>
		        </form>
	        </div>
		</div>
	</div>
	<?php require_once("../../inc/myjs.php");?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
	<script>
		$( "#delivered" ).validate({
			rules: {
				name: {
					required: true
				}
			}
		});
		ShopifyApp.Bar.initialize({
	        title: 'Edit Delivered By',
	        breadcrumb: {
	            label: "Delivered By",
	            href: "<?php echo APP_URL;?>admin/delivered-by.php",
	            target: 'app',
	            loading: true
	        }
	    });
	</script>
</body>
</html>