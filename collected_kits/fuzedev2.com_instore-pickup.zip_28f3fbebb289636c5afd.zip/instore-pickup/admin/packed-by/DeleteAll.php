<?php
require_once('../../inc/functions.php');
?>
<?php
extract($_POST);

$Total=json_decode($_POST['Selected']);
$count=count($Total);

if($count==0)
{
	echo 2;
}
else
{
	for($i=0;$i<$count;$i++)
	{
		//for delete all record
		$status=mysqli_query($con,"delete from packed_by where id='".$Total[$i]."'");
   
		if($status)
		{
   			$flag=1;
   		}
   		else
   		{
   			$flag=0;		
   		}
	}

	if($flag==1)
	{
		echo 1;
	}
	else
	{
		echo 0;
	}
}
?>