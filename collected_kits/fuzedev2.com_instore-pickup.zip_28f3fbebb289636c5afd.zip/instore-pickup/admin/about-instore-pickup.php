<?php
require_once("../inc/functions.php");
$get_about_info = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM instore_about_popup WHERE store_id = '".$store_id."'"));
if(isset($_POST['submit'])){
	if(empty($get_about_info)){
		$query = mysqli_query($con, "INSERT INTO instore_about_popup SET 
									store_id='".$store_id."', 
									about = '".mysqli_real_escape_string($con,trim($_POST['about-instorepickup']))."'
							");
		if($query==1){
			$msg = '<div class="alert alert-success">Record inserted successfully.</div>';
		}
		else{
			$msg = '<div class="alert alert-danger">Please try again...</div>';	
		}
	}
	else{
		$query = mysqli_query($con, "UPDATE instore_about_popup SET 
									about = '".mysqli_real_escape_string($con,trim($_POST['about-instorepickup']))."'
									WHERE 
									store_id='".$store_id."'
							");
		if($query==1){
			$msg = '<div class="alert alert-success">Record updated successfully.</div>';
		}
		else{
			$msg = '<div class="alert alert-danger">Please try again...</div>';	
		}
	}
}
?>
	<?php require_once("../inc/mycss.php");?>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script> 
    

    <!-- include summernote css/js -->
    <link href="//cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css" rel="stylesheet">
    <script src="//cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.js"></script>
	

<div class="container-fluid">
    <h3>About In-store Pickup</h3>
    <br>
    <form method="post">
		<div class="row">
			<div class="col-md-5">
			    <?php echo isset($msg)?$msg:'';?>
				<div class="form-group">
					<textarea name="about-instorepickup" id="" class="summernote"><?php echo isset($_POST['about-instorepickup'])?$_POST['about-instorepickup']:$get_about_info['about'];?></textarea>
    			</div>
    			<div class="form-group">
    				<button class="btn btn-primary" type="submit" name="submit">Save</button>
    			</div>
    		</div>
    	</div>
    </form>
</div>

<?php require_once("../inc/myjs.php");?>
<script>
    $(document).ready(function(){    	
        $('.summernote').summernote();
   	});
   	ShopifyApp.Bar.initialize({
        title: 'About In-store Pickup',
    });
</script>