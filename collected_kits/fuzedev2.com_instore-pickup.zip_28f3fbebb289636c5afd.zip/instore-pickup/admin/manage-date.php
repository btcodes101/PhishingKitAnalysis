<?php
require_once("../inc/functions.php");
$row_disabled_dates = mysqli_fetch_assoc(mysqli_query($con,"SELECT dates FROM disabled_dates WHERE store_id = '".$store_id."'"));
if(isset($_POST['submit'])){
	extract($_POST);

	if(!empty($row_disabled_dates)){
        mysqli_query($con, "DELETE FROM disabled_dates WHERE store_id = '".$store_id."'");
		$sql = mysqli_query($con, "INSERT INTO disabled_dates SET
									dates = '".mysqli_real_escape_string($con,implode(',',$disabled_date))."',
									store_id = '".$store_id."'
							");
		if($sql==1){
			$msg = '<div class="alert alert-success">Dates updated successfully.</div>';
		}
		else{
			$msg = '<div class="alert alert-danger">Something went wrong! Please try again.</div>';
		}
	}
	else{
		$sql = mysqli_query($con, "INSERT INTO disabled_dates SET
									store_id = '".mysqli_real_escape_string($con,$store_id)."',
									dates = '".mysqli_real_escape_string($con,implode(',',$disabled_date))."'
							");
		if($sql==1){
			$msg = '<div class="alert alert-success">Date added successfully.</div>';
		}
		else{
			$msg = '<div class="alert alert-danger">Something went wrong! Please try again.</div>';
		}
	}
}
?>
    <?php require_once("../inc/mycss.php");?>
	<link rel='stylesheet' id='datepicker.css-css'  href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css?ver=4.9.13' type='text/css' media='all' />
    
    <div class="container-fluid">
    	<h3>Manage Disabled Dates</h3>
    	<form action="" method="post">
    		<div class="row">
    			<div class="col-md-4">
    				<?php echo isset($msg)?$msg:'';?>
    				<div class="field_wrapper">
    					<?php
    					$disabled_dates = mysqli_fetch_assoc(mysqli_query($con,"SELECT dates FROM disabled_dates WHERE store_id = '".$store_id."'"));
    					$no = 0;
    					if(!empty($disabled_dates)){
    						$disabled_dates = explode(',',$disabled_dates['dates']);
    						foreach($disabled_dates as $disabled_date){
    							if($no==0){
    								?>
    								<div>
    									<div class="form-group">
    										<div class="col-md-8">
    											<input type="text" name="disabled_date[]" class="form-control disabled_date" value="<?= $disabled_date;?>"/>
    										</div>
    										<div class="col-md-4">
    											<button type="button" class="add_button btn btn-sm btn-success">Add</button>
    										</div>
    									</div>
    									<div class="clearfix"></div>
    								</div>
    								<?php
    							}
    							else{
    								?>
    								<div>
    									<div class="form-group">
    										<div class="col-md-8">
    											<input type="text" name="disabled_date[]" class="form-control disabled_date" value="<?= $disabled_date;?>"/>
    										</div>
    										<div class="col-md-4">
    											<button type="button" class="remove_button btn btn-sm btn-danger">Remove</button>
    										</div>
    									</div>
    									<div class="clearfix"></div>
    								</div>
    								<?php
    							}
    							$no++;
    						}
    					}
    					else{
    						?>
    						<div>
    							<div class="form-group">
    								<div class="col-md-8">
    									<input type="text" name="disabled_date[]" class="form-control disabled_date"/>
    								</div>
    								<div class="col-md-4">
    									<button type="button" class="add_button btn btn-sm btn-success">Add</button>
    								</div>
    							</div>
    							<div class="clearfix"></div>
    						</div>
    						<?php
    					}
    					?>
    				</div>
    				<br>
    				<div class="form-group">
    					<div class="col-md-8">
    						<button class="btn btn-primary" type="submit" name="submit">Save</button>
    					</div>
    				</div>
    			</div>
    			<div class="clearfix"></div>
    		</div>
    	</form>
    </div>

	<?php require_once("../inc/myjs.php");?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.0/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	$(document).ready(function(){
	    var maxField = 10;
	    var addButton = $('.add_button');
	    var wrapper = $('.field_wrapper');
	    var fieldHTML = '<div><div class="form-group"><div class="col-md-8"> <input type="text" name="disabled_date[]" class="form-control disabled_date"/></div><div class="col-md-4"> <button type="button" class="remove_button btn btn-sm btn-danger">Remove</button></div></div><div class="clearfix"></div></div>';
	    var x = 1;
	    
	    $(addButton).click(function(){
	        if(x < maxField){ 
	            x++;
	            $(wrapper).append(fieldHTML);
	        }
	    });
	    
	    $(wrapper).on('click', '.remove_button', function(e){
	        e.preventDefault();
	        $(this).parent('div').parent('div').parent('div').remove();
	        x--;
	    });
	});
	jQuery(document).on('click','.disabled_date',function (e) {
		jQuery(this).datepicker({
			format: 'yyyy-mm-dd',
			autoclose:true,
			startDate: "+0d",
		});
		jQuery( this ).datepicker("show");
	});
    ShopifyApp.Bar.initialize({
        title: 'Disabled Dates'
    });
	</script>
