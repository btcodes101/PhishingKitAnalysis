<?php
require_once('../../inc/functions.php');
?>
<?php
if(isset($_POST['submit'])){
	extract($_POST);

	$row = mysqli_num_rows(mysqli_query($con, "SELECT name FROM locations WHERE name = '".$name."' AND store_id='".$store_id."'"));
	if($row>0){
		$msg = '<div class="alert alert-danger"><b>'.$name.'</b> already exist.</div>';
	}
	else{
		$query = mysqli_query($con, "INSERT INTO locations SET 
									company_name='".mysqli_real_escape_string($con,trim($company_name))."',
									address_line_1='".mysqli_real_escape_string($con,trim($address_line_1))."',
									address_line_2='".mysqli_real_escape_string($con,trim($address_line_2))."',
									city='".mysqli_real_escape_string($con,trim($city))."',
									country='".mysqli_real_escape_string($con,trim($country))."',
									state='".mysqli_real_escape_string($con,trim($state))."',
									zip_code='".mysqli_real_escape_string($con,trim($zip_code))."',
									store_id='".$store_id."'
							");
		if($query==1){
			unset($_POST);
			$msg = '<div class="alert alert-success">Location added successfully.</div>';
		}
		else{
			$msg = '<div class="alert alert-danger">Something went wrong! Please try again.</div>';
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Location</title>
    <?php require_once("../../inc/mycss.php");?>
</head>
<body>
    <div class="container-fluid">
        <h3>Add Location</h3>
        <br>
        <div class="row">
        	<div class="col-md-4"><a href="../locations.php" class="btn btn-sm btn-primary pull-right"><i class="fa fa-angle-left" aria-hidden="true"></i> Back</a></div>
        </div>
        <div class="clearfix"></div>
        <br>
        <div class="row">
        	<div class="col-md-4">
        		<?php echo isset($msg)?$msg:'';?>
		        <form name="location" id="location" method="post">
		        	<div class="row">
			        	<div class="col-md-6">
				        	<div class="form-group">
				        		<label for="company_name">Company Name</label>
				        		<input type="text" name="company_name" id="company_name" class="form-control" value="<?php echo isset($_POST['company_name'])?$_POST['company_name']:''?>">
				        	</div>
			        	</div>
						<div class="col-md-6">
				        	<div class="form-group">
				        		<label for="address_line_1">Address line 1</label>
				        		<input type="text" name="address_line_1" id="address_line_1" class="form-control" value="<?php echo isset($_POST['address_line_1'])?$_POST['address_line_1']:''?>">
				        	</div>
			        	</div>
			        </div>
			        <div class="row">
			        	<div class="col-md-6">
				        	<div class="form-group">
				        		<label for="address_line_2">Address line 2</label>
				        		<input type="text" name="address_line_2" id="address_line_2" class="form-control" value="<?php echo isset($_POST['address_line_2'])?$_POST['address_line_2']:''?>">
				        	</div>
			        	</div>
			        	<div class="col-md-6">
				        	<div class="form-group">
				        		<label for="city">City</label>
				        		<input type="text" name="city" id="city" class="form-control" value="<?php echo isset($_POST['city'])?$_POST['city']:''?>">
				        	</div>
			        	</div>
			        </div>
			        <div class="row">
			        	<div class="col-md-6">
				        	<div class="form-group">
				        		<label for="country">Country</label>
				        		<input type="text" name="country" id="country" class="form-control" value="<?php echo isset($_POST['country'])?$_POST['country']:''?>">
				        	</div>
			        	</div>
			        	<div class="col-md-6">
				        	<div class="form-group">
				        		<label for="state">State</label>
				        		<input type="text" name="state" id="state" class="form-control" value="<?php echo isset($_POST['state'])?$_POST['state']:''?>">
				        	</div>
			        	</div>
			        </div>
			        <div class="row">
			        	<div class="col-md-12">
				        	<div class="form-group">
				        		<label for="zip_code">Zip code</label>
				        		<input type="text" name="zip_code" id="zip_code" class="form-control" value="<?php echo isset($_POST['zip_code'])?$_POST['zip_code']:''?>">
				        	</div>
			        	</div>
			        	<div class="col-md-12">
				        	<div class="form-group">
				        		<button type="submit" name="submit" class="add_button btn btn-md btn-success">Save</button>
				        	</div>
			        	</div>
			        </div>
		        </form>
	        </div>
		</div>
	</div>
	<?php require_once("../../inc/myjs.php");?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
	<script>
		$( "#location" ).validate({
			rules: {
				company_name: {
					required: true
				},
				address_line_1: {
					required: true
				},
				city: {
					required: true
				},
				country: {
					required: true
				},
				state: {
					required: true
				},
				zip_code: {
					required: true,
					digits: true
				}
			}
		});
		ShopifyApp.Bar.initialize({
	        title: 'Add Location',
	        breadcrumb: {
	            label: "Locations",
	            href: "<?php echo APP_URL;?>locations.php",
	            target: 'app',
	            loading: true
	        }
	    });
	</script>
</body>
</html>