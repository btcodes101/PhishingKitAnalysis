<?php
require_once('../../inc/functions.php');
?>
<?php
extract($_POST);

$query=mysqli_query($con,"delete from locations where id='".$Id."'");
   
if($query)
{
	$flag=1;
}
else
{
	$flag=0;		
}

echo $flag;
?>