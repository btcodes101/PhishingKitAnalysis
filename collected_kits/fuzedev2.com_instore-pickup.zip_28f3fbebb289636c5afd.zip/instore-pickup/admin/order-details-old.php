<?php
session_start();
require_once("../inc/functions.php");
$token = $query['access_token'];
$query = array(
    "Content-type" => "application/json"
);
$order_id = $_GET['id'];
$get_order = shopify_call($token, $shop, "/admin/api/2019-10/orders/".$order_id.".json", array(), 'GET');
$get_order = json_decode($get_order['response'], TRUE);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Orders Details</title>
    <?php require_once("../inc/mycss.php");?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.shopify.com/s/assets/admin/style-669a145e7a2a8fc9d5c481e4b36ae360e66a82bd6677984d61a2a7b98e3941c8.css">
    <style type="text/css">
        body{
            background: transparent;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <br>
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <a href="../orders.php" class="btn btn-sm btn-primary"><i class="fa fa-angle-left" aria-hidden="true"></i> Back</a>
                <div class="ui-layout">
                    <div class="ui-layout__sections">
                        <div class="ui-layout__section ui-layout__section--primary">
                            <div class="ui-layout__item" id="fulfillment-section" data-tg-refresh="fulfillment-section">
                                <section class="ui-card fulfillment-card fulfillment-card--unfulfilled" id="unfulfilled-card-0" data-tg-refresh="unfulfilled-card-0">
                                    <div>
                                        <div class="ui-card__header">
                                            <div class="ui-stack ui-stack--wrap ui-stack--vertical">
                                                <div class="ui-stack ui-stack--wrap ui-stack--alignment-baseline ui-stack--spacing-tight">
                                                    <div class="ui-stack-item hide-when-printing">
                                                        <svg class="next-icon next-icon--size-24 halo-icon fulfillment-card-primary-icon fulfillment-card-primary-icon--unfulfilled" aria-hidden="true" focusable="false">
                                                            <use xlink:href="#halo-fulfillment-unfulfilled"></use>
                                                        </svg>
                                                    </div>
                                                    <div class="ui-stack-item ui-stack-item--fill">
                                                        <div class="ui-stack ui-stack--wrap ui-stack--alignment-center ui-stack--spacing-tight">
                                                            <div class="ui-stack-item ui-stack-item--fill">
                                                                <div class="ui-stack ui-stack--wrap ui-stack--alignment-baseline ui-stack--spacing-tight">
                                                                    <div class="ui-stack-item">
                                                                        <h2 class="ui-heading fulfillment-card__title">Unfulfilled (1)</h2>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ui-card__section line-items-section">
                                        <div class="ui-type-container">
                                            <div class="ui-type-container">

                                                <div class="ui-stack ui-stack--alignment-center ui-stack--spacing-tight unfulfilled-card__line_item" horizontal="true">
                                                    <div class="ui-stack-item line-item-image">
                                                        <span class="badge line-item__badge">1</span>
                                                        <div class="aspect-ratio aspect-ratio--square aspect-ratio--square--50">
                                                            <img title="adidas Miami HEAT 2016 On Court Short Sleeve Shooting Shirt" class="block aspect-ratio__content" src="//cdn.shopify.com/s/files/1/0040/7237/4339/products/4591A_MHE_7MHEWZQ_BDH_MF.high.res_small.jpg?v=1536385043">
                                                        </div>
                                                    </div>
                                                    <div class="ui-stack-item ui-stack-item--fill">
                                                        <div class="ui-stack ui-stack--wrap ui-stack--vertical ui-stack--spacing-none">
                                                            <div class="ui-stack-item">
                                                                <?php
                                                                foreach($get_order['order']['line_items'] as $product){
                                                                    ?>
                                                                    <div class="ui-stack ui-stack--alignment-center ui-stack--spacing-tight unfulfilled-card__line_item__details" horizontal="true">
                                                                        <div class="ui-stack-item ui-stack-item--fill">
                                                                            <p>
                                                                                <a href=""><?php echo $product['title']?></a>
                                                                            </p>
                                                                            <div class="unfulfilled-card__line_item__secondary-details">
                                                                                <span class="ui-text-style ui-text-style--variation-subdued">
                                                                                    <p><?php echo $product['variant_title']?></p>
                                                                                </span>
                                                                                <span class="ui-text-style ui-text-style--variation-subdued">
                                                                                    <p>SKU: <?php echo $product['sku']?></p>
                                                                                </span>
                                                                                <div class="order-details__price-by-quantity order-details__price-by-quantity--wrapped hide-when-printing">
                                                                                    <?php echo getCurrencySymbol('USD'),$product['price'];?>
                                                                                    <span><span class="line-item-quantity-symbol">×</span></span>
                                                                                    <span class="order-details__quantity"><?php echo $product['quantity']?></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="ui-stack-item">
                                                                            <div class="order-details__price-by-quantity show-when-printing">
                                                                                <?php echo getCurrencySymbol('USD'),$product['price'];?>
                                                                                <span><span class="line-item-quantity-symbol">×</span></span>
                                                                                <span class="order-details__quantity"><?php echo $product['quantity']?></span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="ui-stack-item">
                                                                            <div class="order-details__line-item-total-price type--right">
                                                                                <?php echo getCurrencySymbol('USD'),$product['price']*$product['quantity']?>;?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr class="line-item-row-separator">
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                            <div class="ui-layout__item" style="display:none">
                                <section class="ui-card" id="order_card" data-tg-refresh="order-card">
                                    <div class="ui-card__header hide-when-printing">
                                        <div class="ui-stack ui-stack--wrap ui-stack--alignment-baseline ui-stack--spacing-tight">
                                            <div class="ui-stack-item">

                                            </div>
                                            <div class="ui-stack-item">
                                                <h2 class="ui-heading">Payment authorized</h2>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ui-card__section"><div class="ui-type-container">
                                        <div class="ui-stack ui-stack--wrap ui-stack--vertical ui-stack--spacing-tight">
                                            <div class="order-details__summary">
                                                <table class="order-details-summary-table" role="table">
                                                    <tbody>
                                                        <tr>
                                                            <td>Subtotal</td>
                                                            <td>
                                                                1 item
                                                            </td>
                                                            <td>$10.00</td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody class="order-details__summary__shipping">
                                                        <tr class="order-details__summary__detail-line-row">
                                                            <td>
                                                                Shipping
                                                            </td>
                                                            <td>International Shipping (0.227 kg)</td>
                                                            <td>
                                                                $20.00
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody class="order-details__summary__tax">
                                                        <tr>
                                                            <td colspan="2">Tax</td>
                                                            <td>$0.00</td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody>
                                                        <tr>
                                                            <td class="type--bold" colspan="2">Total</td>
                                                            <td class="type--bold">$30.00</td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody class="order-details__summary__paid_by_customer">
                                                        <tr>
                                                            <td colspan="3" class="order-details-summary-table__separator"><hr></td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">Paid by customer</td>
                                                            <td>$0.00</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                    <div class="ui-layout__section ui-layout__section--secondary" id="order-sidebar" refresh="order-sidebar">
                        <div class="ui-layout__item">
                            <section class="ui-card">
                                <div class="ui-card__section hide-when-printing" id="order-notes" data-tg-refresh="order-notes">

                                    <div class="ui-stack ui-stack--wrap ui-stack--vertical">
                                        <div class="ui-stack-item">
                                            <div class="ui-stack ui-stack--wrap ui-stack--alignment-baseline">
                                                <div class="ui-stack-item ui-stack-item--fill">
                                                    <h2 class="ui-heading">Notes</h2>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="ui-stack-item">
                                            <p class="order-notes__default-text type--subdued">No notes from customer</p>
                                        </div>
                                    </div>
                                </div>
                                <section class="ui-card__section" id="note-attributes" data-tg-refresh="note-attributes">

                                    <div class="ui-stack ui-stack--vertical">
                                        <div class="ui-stack-item">
                                            <div class="ui-stack ui-stack--wrap ui-stack--alignment-baseline">
                                                <div class="ui-stack-item ui-stack-item--fill">
                                                    <div class="ui-card__section-header">
                                                        <h3 class="ui-subheading">Additional details</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ui-stack-item">
                                            <div class="ui-type-container ui-type-container--spacing-loose">
                                                <div class="ui-type-container ui-type-container--spacing-extra-tight">
                                                    <p class="order-notes-attrs__display-name">Checkout-Method</p>
                                                    <div class="order-notes-attrs__display-value type--subdued">Pickup</div>
                                                </div>
                                                <?php
                                                foreach($get_order['order']['note_attributes'] as $attributes){
                                                    ?>
                                                    <div class="ui-type-container ui-type-container--spacing-extra-tight">
                                                        <p class="order-notes-attrs__display-name"><?php echo $attributes['name'];?></p>
                                                        <div class="order-notes-attrs__display-value type--subdued"><?php echo $attributes['value'];?></div>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="order-details">
                <?php
                echo "<pre>";
                print_r ($get_order);
                echo "</pre>";
                ?>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
</body>
<?php
require_once("../inc/myjs.php");
?>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).on('change','.picked_by',function(){
        var orderId = $(this).attr('data-orderid');
        var picked_by = $(this).val();
        var option = $('option:selected', this).attr('data-id');
        if(confirm("are you sure?")==true){
            $.ajax({
                method:"POST",
                url:"./add_by.php",
                data:{action:"picked", orderId:orderId, picked_by:picked_by, option:option},
                beforeSend:function(){
                    toastr.options = {
                        closeButton: false,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.info("Please Wait ...",'');
                },
                success:function(response){
                    toastr.clear();
                    toastr.options = {
                        closeButton: true,
                        progressBar: true,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.success('<b>'+picked_by+'</b> assigned successfully', '');
// $('#'+orderId).load(location.href + ' #'+orderId+">*","");
}
});
        }
        else{
            $('#'+orderId).load(location.href + ' #'+orderId+">*","");
        }
    });
    $(document).on('change','.delivered_by',function(){
        var orderId = $(this).attr('data-orderid');
        var delivered_by = $(this).val();
        var option = $('option:selected', this).attr('data-id');
        if(confirm("are you sure?")==true){
            $.ajax({
                method:"POST",
                url:"./add_by.php",
                data:{action:"delivered", orderId:orderId, delivered_by:delivered_by, option:option},
                beforeSend:function(){
                    toastr.options = {
                        closeButton: false,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.info("Please Wait ...",'');
                },
                success:function(response){
                    toastr.clear();
                    toastr.options = {
                        closeButton: true,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.success('<b>'+delivered_by+'</b> assigned successfully', '');
// $('#'+orderId).load(location.href + ' #'+orderId+">*","");
}
});
        }
        else{
            $('#'+orderId).load(location.href + ' #'+orderId+">*","");
        }
    });
    ShopifyApp.Bar.initialize({
        title: 'Orders'
    });
</script>
</html>