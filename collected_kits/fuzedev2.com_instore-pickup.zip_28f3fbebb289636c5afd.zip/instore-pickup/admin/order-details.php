<?php
session_start();
require_once("../inc/functions.php");
$token = $query['access_token'];

$order_id = $_GET['id'];
$get_order = shopify_call($token, $shop, "/admin/api/2019-10/orders/".$order_id.".json", array(), 'GET');
$get_order = json_decode($get_order['response'], TRUE);
$order = $get_order['order'];

foreach($get_order['order']['note_attributes'] as $attribute){
    if($attribute['name']=='Pickup-Location-Company'){
        $company = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Address-Line-1'){
        $address_1 = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Address-Line-2'){
        $address_2 = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-City'){
        $city = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Region'){
        $state = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Postal-Code'){
        $post_code = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Country'){
        $country = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Date'){
        $pickup_date = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Time'){
        $pickup_time = $attribute['value'];
    }
    if($attribute['name']=='Delivered-by-Id'){
        $delivered_by_id = $attribute['value'];
    }
    if($attribute['name']=='Packed-by-Id'){
        $packed_by_id = $attribute['value'];
    }
    if($attribute['name']=='Pickedup-by'){
        $pickedup_by = $attribute['value'];
    }
    if($attribute['name']=='Status'){
        $status = $attribute['value'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Orders Details</title>
        <?php require_once("../inc/mycss.php");?>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="<?php echo APP_URL.'assets/css/order-details.css'?>" rel="stylesheet">
        
        <style type="text/css">
        body{
            background: transparent;
        }
        #packing-slip{
        	display: none;
        }
        </style>
    </head>
    <body>
        <div class="container-fluid">
            <br>
            <div class="">
                <div class="">
                    <div class="Polaris-Page">
                        <div class="Polaris-Page-Header Polaris-Page-Header--hasNavigation Polaris-Page-Header--hasActionMenu">
                            <div class="Polaris-Page-Header__Navigation">
                                <div class="Polaris-Page-Header__BreadcrumbWrapper">
                                    <nav role="navigation">
                                        <a class="Polaris-Breadcrumbs__Breadcrumb" href="../orders.php" data-polaris-unstyled="true">
                                            <span class="Polaris-Breadcrumbs__Icon">
                                                <span class="Polaris-Icon">
                                                    <svg viewBox="0 0 20 20" class="Polaris-Icon__Svg" focusable="false" aria-hidden="true">
                                                    <path d="M12 16a.997.997 0 0 1-.707-.293l-5-5a.999.999 0 0 1 0-1.414l5-5a.999.999 0 1 1 1.414 1.414L8.414 10l4.293 4.293A.999.999 0 0 1 12 16" fill-rule="evenodd"></path>
                                                    </svg>
                                                </span>
                                            </span>
                                            <span class="Polaris-Breadcrumbs__Content">Orders</span>
                                        </a>
                                    </nav>
                                </div>
                            </div>
                            <div class="Polaris-Page-Header__MainContent">
                                <div class="Polaris-Page-Header__TitleActionMenuWrapper">
                                    <div class="Polaris-Page-Header__Title">
                                        <div>
                                            <h1 class="Polaris-DisplayText Polaris-DisplayText--sizeLarge"><?php echo $get_order['order']['name'];?></h1>
                                        </div>
                                        <div>
                                            <?php if(empty($status)){?>
                                            <span class="Status Polaris-Badge Polaris-Badge--statusAttention Polaris-Badge--progressIncomplete">
                                                <span class="Polaris-VisuallyHidden">Attention</span>
                                                <span class="Polaris-Badge__Pip">
                                                    <span class="Polaris-VisuallyHidden">Incomplete</span>
                                                </span>
                                                Not Ready
                                            </span>
                                            <?php }else{?>
                                            <span class="Polaris-Badge Polaris-Badge--statusSuccess Polaris-Badge--progressComplete">
                                                <span class="Polaris-VisuallyHidden">Attention</span>
                                                <span class="Polaris-Badge__Pip">
                                                    <span class="Polaris-VisuallyHidden">Incomplete</span>
                                                </span>
                                                Ready
                                            </span>
                                            <?php }?>
                                        </div>
                                    </div>
                                    <div class="Polaris-Page-Header__ActionMenuWrapper">
                                        <div class="Polaris-ActionMenu">
                                            <div class="Polaris-ActionMenu__ActionsLayout"><button type="button" class="Polaris-ActionMenu-MenuAction" onclick="window.open('<?php echo $shop_url.'admin/orders/'.$order["id"];?>')">View order</button></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="Polaris-Page-Header__PrimaryActionWrapper">
                                    <button type="button" class="Polaris-Button Polaris-Button--primary Polaris-Button--sizeMedium mark_ready" data-orderId="<?php echo $get_order['order']['id'];?>">
                                    <span class="Polaris-Button__Content">
                                        <span class="Polaris-Button__Text">
                                            <div class="Polaris-Stack Polaris-Stack--spacingTight Polaris-Stack--alignmentCenter">
                                                <div class="Polaris-Stack__Item"><i class="material-icons">shopping_basket</i></div>
                                                <div class="Polaris-Stack__Item"><span>Mark as ready for pickup</span></div>
                                            </div>
                                        </span>
                                    </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <div class="Polaris-Page__Content">
                        <div class="Polaris-Layout">
                            <div class="Polaris-Layout__Section">
                                <div class="Polaris-Banner Polaris-Banner--statusWarning Polaris-Banner--withinPage" tabindex="0" role="alert" aria-live="polite" aria-labelledby="Banner1Heading" aria-describedby="Banner1Content">
                                    <div class="Polaris-Banner__Ribbon">
                                        <span class="Polaris-Icon Polaris-Icon--colorYellowDark Polaris-Icon--isColored Polaris-Icon--hasBackdrop">
                                            <svg viewBox="0 0 20 20" class="Polaris-Icon__Svg" focusable="false" aria-hidden="true">
                                                <circle fill="currentColor" cx="10" cy="10" r="9"></circle>
                                            <path d="M10 0C4.486 0 0 4.486 0 10s4.486 10 10 10 10-4.486 10-10S15.514 0 10 0m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8m0-13a1 1 0 0 0-1 1v4a1 1 0 1 0 2 0V6a1 1 0 0 0-1-1m0 8a1 1 0 1 0 0 2 1 1 0 0 0 0-2"></path>
                                        </svg>
                                    </span>
                                </div>
                                <div>
                                    <div class="Polaris-Banner__Heading" id="Banner1Heading">
                                        <p class="Polaris-Heading">Payment notice</p>
                                    </div>
                                    <div class="Polaris-Banner__Content" id="Banner1Content"> Ensure full payment has been made before allowing customer to pick up.</div>
                                </div>
                            </div>
                        </div>
                        <div class="Polaris-Layout__Section">
                        	<div class="row" id="<?php echo $get_order['order']['id'];?>">
                        		<div class="col-md-3">
                        			<div class="form-group">
                        				<label for="picked_by">Packed By</label>
                        				<select class="form-control picked_by" name="picked_by" data-orderId="<?php echo $get_order['order']['id'];?>">
			                            <option value="">Select</option>
			                            <?php
			                            $query = mysqli_query($con,"SELECT * FROM packed_by WHERE store_id = '".$store_id."' ORDER BY name ASC");
			                            while($row=mysqli_fetch_assoc($query)){
			                                if($row['id'] == $packed_by_id){
			                                    $selected = 'selected';
			                                }
			                                else{
			                                    $selected = '';
			                                }
			                                echo '<option value="'.$row['name'].'" data-id="'.$row['id'].'" '.$selected.'>'.$row['name'].'</option>';
			                            }
			                            ?>
			                        </select>
                        			</div>
                        		</div>
                        		<div class="col-md-3">
                        			<label for="delivered_by">Delivered By</label>
                        			<select class="form-control delivered_by" name="delivered_by" data-orderId="<?php echo $get_order['order']['id'];?>">
			                            <option value="">Select</option>
			                            <?php
			                            $query = mysqli_query($con,"SELECT * FROM delivered_by WHERE store_id = '".$store_id."' ORDER BY name ASC");
			                            while($row=mysqli_fetch_assoc($query)){
			                                if($row['id'] == $delivered_by_id){
			                                    $selected = 'selected';
			                                }
			                                else{
			                                    $selected = '';
			                                }
			                                echo '<option value="'.$row['name'].'" data-id="'.$row['id'].'" '.$selected.'>'.$row['name'].'</option>';
			                            }
			                            ?>
			                        </select>
                        		</div>
                                <div class="col-md-3">
                                    <label for="pickedup_by_<?php echo $get_order['order']['id'];?>">Picked Up By</label>
                                    <div class="row">
                                        <div class="col-md-9" style="padding-right:0">
                                            <input type="text" name="pickedup_by" id="pickedup_by_<?php echo $get_order['order']['id'];?>" class="form-control" value="<?php echo $pickedup_by;?>">
                                        </div>
                                        <div class="col-md-3">
                                            <?php 
                                            if($pickedup_by==''){
                                                $label = 'Add';
                                            }
                                            else{
                                                $label = 'Edit';
                                            }
                                            ?>
                                            <button type="button" class="btn btn-sm btn-primary pickedup_by" data-orderId="<?php echo $get_order['order']['id'];?>"> <?php echo $label;?> </button>
                                        </div>
                                    </div>
                                </div>
                        		<div class="col-md-3">
                        		    <div class="printing_button">
                            		    <button type="button" class="Polaris-Button Polaris-Button--primary Polaris-Button--sizeMedium printSlip" data-orderId="<?php echo $get_order['order']['id'];?>">
                                        <span class="Polaris-Button__Content">
                                            <span class="Polaris-Button__Text">
                                                <div class="Polaris-Stack Polaris-Stack--spacingTight Polaris-Stack--alignmentCenter">
                                                    <div class="Polaris-Stack__Item"><i class="material-icons">print</i></div>
                                                    <div class="Polaris-Stack__Item"><span>Print Picking Slip</span></div>
                                                </div>
                                            </span>
                                        </span>
                                        </button>
                                    </div>
                        		</div>
                        	</div>
                        </div>
                        <div class="Polaris-Layout__Section">
                            <div class="Polaris-Card">
                                <div class="Polaris-Card__Header">
                                    <h2 class="Polaris-Heading">Products</h2>
                                </div>
                                <div class="Polaris-Card__Section">
                                    <div class="Polaris-Stack Polaris-Stack--vertical">
                                        
                                        <?php
                                            $separator = count($get_order['order']['line_items']);
                                            $no=1;
                                            foreach($get_order['order']['line_items'] as $product){
                                                $product_image = shopify_call($token, $shop, "/admin/api/2020-01/products/".$product['product_id']."/images.json", array(), 'GET');
                                                $product_image = json_decode( $product_image['response'], true );
                                                // echo "<pre>";
                                                // print_r ($product_image);
                                                // echo "</pre>";
                                        ?>

                                            <div class="Polaris-Stack__Item">
                                                <div class="Polaris-Stack Polaris-Stack--spacingExtraLoose">
                                                    <div class="Polaris-Stack__Item">
                                                        <button type="button" class="Polaris-Link">
                                                        <div class="productThumbnail andy123">
                                                            <span class="Polaris-Thumbnail Polaris-Thumbnail--sizeMedium">
                                                                <img src="<?php echo $product_image['images'][0]['src']?>" class="Polaris-Thumbnail__Image">
                                                            </span>
                                                            <div class="quantityBadge">
                                                                <?php echo $product['quantity']?>
                                                            </div>
                                                        </div>
                                                        </button>
                                                    </div>
                                                    <div class="Polaris-Stack__Item Polaris-Stack__Item--fill">
                                                        <div class="Polaris-Stack Polaris-Stack--vertical Polaris-Stack--spacingTight">
                                                            <div class="Polaris-Stack__Item">
                                                                <h3><button type="button" class="Polaris-Link"><?php echo $product['title']?></button></h3>
                                                                <span class="Polaris-TextStyle--variationSubdued"><?php echo $product['variant_title']?></span>
                                                                <br>
                                                                <span class="Polaris-TextStyle--variationSubdued">SKU: <?php echo $product['sku']?></span>
                                                                <br>
                                                                <span class="Polaris-TextStyle--variationSubdued">PRICE: <?php echo getCurrencySymbol($product['currency']).$product['price'] .' &times; '. $product['quantity'] .' = '.getCurrencySymbol($product['currency']).number_format($product['quantity']*$product['price'],2) ?></span>
                                                            </div>
                                                            <div class="Polaris-Stack__Item"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php if($separator!=$no){
                                                    ?>
                                                <hr class="line-item-row-separator">
                                                <?php }?>
                                            </div>
                                        <?php
                                        $no++;
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="Polaris-Card">
                                <div class="Polaris-Card__Header">
                                    <h2 class="Polaris-Heading">Payment Details</h2>
                                </div>
                                <div class="Polaris-Card__Section">
                                    <div class="Polaris-Stack Polaris-Stack--vertical">
                                        <div class="Polaris-Stack__Item">
                                            <div class="Polaris-Stack Polaris-Stack--spacingExtraLoose">
                                                <div class="Polaris-Stack__Item">
                                                    
                                                </div>
                                                <div class="Polaris-Stack__Item Polaris-Stack__Item--fill">
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                        <div class="Polaris-Layout__Section Polaris-Layout__Section--secondary">
                            <div class="Polaris-Card">
                                <div class="Polaris-Card__Header">
                                    <div class="Polaris-Stack Polaris-Stack--alignmentBaseline">
                                        <div class="Polaris-Stack__Item Polaris-Stack__Item--fill">
                                            <h2 class="Polaris-Heading">Pickup details</h2>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="Polaris-Card__Section">
                                    <div class="Polaris-Stack Polaris-Stack--vertical">
                                        <div class="Polaris-Stack__Item">
                                            <div class="Polaris-Stack Polaris-Stack--spacingTight Polaris-Stack--alignmentCenter">
                                                <div class="Polaris-Stack__Item"><span><i class="material-icons inkLightest">date_range</i></span></div>
                                                <div class="Polaris-Stack__Item"><span><?php echo date('l, F d, Y',strtotime($pickup_date))?></span></div>
                                            </div>
                                        </div>
                                        <div class="Polaris-Stack__Item">
                                            <div class="Polaris-Stack Polaris-Stack--spacingTight Polaris-Stack--alignmentCenter">
                                                <div class="Polaris-Stack__Item"><i class="material-icons inkLightest">schedule</i></div>
                                                <div class="Polaris-Stack__Item"><span><?php echo $pickup_time;?></span></div>
                                            </div>
                                        </div>
                                        <div class="Polaris-Stack__Item">
                                            <div class="Polaris-Stack Polaris-Stack--spacingTight">
                                                <div class="Polaris-Stack__Item"><i class="material-icons inkLightest">location_city</i></div>
                                                <div class="Polaris-Stack__Item">
                                                    <span>
                                                        <p>
                                                            <?php echo $company;?><br>
                                                            <span class="Polaris-TextStyle--variationSubdued">
                                                                <?php 
                                                                echo $address_1,', ';
                                                                if(isset($address_2)){
                                                                    echo $address_2,', ';
                                                                }
                                                                echo $city,' <br>',$state,' ',$post_code;
                                                                ?>
                                                            </span>
                                                        </p>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="Polaris-Card__Section">
                                    <div class="Polaris-Card__SectionHeader">
                                        <h3 aria-label="Customer notes" class="Polaris-Subheading">Customer notes</h3>
                                    </div>
                                    <p>
                                    	<span class="Polaris-TextStyle--variationSubdued">
                                    		<?php 
                                    		$customer_note = $get_order['order']['customer']['note'];
                                    		echo empty($customer_note)?'No notes from customer':$customer_note;
                                    		?>
	                                    </span>
                                    </p>
                                </div>
                            </div>
                            <div class="Polaris-Card">
                                <div class="Polaris-Card__Section">
                                    <div class="Polaris-Stack Polaris-Stack--vertical">
                                        <div class="Polaris-Stack__Item">
                                            <div class="Polaris-Stack Polaris-Stack--alignmentCenter">
                                                <div class="Polaris-Stack__Item Polaris-Stack__Item--fill">
                                                    <h2 class="Polaris-Heading">Customer</h2>
                                                </div>
                                                <div class="Polaris-Stack__Item">
                                                    <span aria-label="<?php echo $get_order['order']['customer']['first_name'].' '.$get_order['order']['customer']['last_name'];?>" role="img" class="Polaris-Avatar Polaris-Avatar--styleFive Polaris-Avatar--sizeMedium Polaris-Avatar--hasImage">
                                                        <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48cGF0aCBmaWxsPSIjZmZlZGI5IiBkPSJNMCAwaDEwMHYxMDBIMHoiLz48cGF0aCBkPSJNNjQuNjMgMTcuMzNhMTcgMTcgMCAwMTUgMjkuNzIgMTYuNzUgMTYuNzUgMCAwMS01IDIuNjIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBmaWxsPSIjZmZjMDRkIiBkPSJNMCAwaDY5LjAydjEwMEgweiIvPjxjaXJjbGUgY3g9IjQ1LjExIiBjeT0iMzMuNDkiIHI9IjE2Ljk4IiBmaWxsPSJub25lIiBzdHJva2U9IiNmZmYiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLXdpZHRoPSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgtMzcuMDIgNDUuMTI0IDMzLjQ5MykiLz48cGF0aCBmaWxsPSIjNWQ2Y2MxIiBkPSJNNjkuMDIgMzQuNDhsMTkuNDcgMzguNzQtMTkuNDcgMS41M1YzNC40OHoiLz48cGF0aCBkPSJNNjEuNiAzMy42N2ExMC4xNyAxMC4xNyAwIDAxMTUuNC4wOCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZmZmIiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS13aWR0aD0iNSIvPjwvc3ZnPgo=" class="Polaris-Avatar__Image" alt="" role="presentation">
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="Polaris-Stack__Item">
                                            <div class="Polaris-Stack Polaris-Stack--vertical Polaris-Stack--spacingTight">
                                                <div class="Polaris-Stack__Item">
                                                    <span>
                                                        <p><?php echo $get_order['order']['customer']['first_name'].' '.$get_order['order']['customer']['last_name'];?></p>
                                                        <p></p>
                                                        <p><a target="_blank" class="Polaris-Link" href="mailto:<?php echo $get_order['order']['customer']['email'];?>"><?php echo $get_order['order']['customer']['email'];?></a></p>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="clearfix"></div>
</div>
</div>


<div id="packing-slip">
	<div class="header">
			<div class="title-container">
				<h1 class="title">Packing Slip</h1>
			</div>
		<div class="logo-container">
			<img style="" src="<?php echo APP_URL.'assets/images/NewMHS-logo.png'?>" alt="Logo">
		</div>
	</div>
	<table width="100%" cellpadding="10">
		<tr class="border">
			<td width="50%">
				<table>
					<tr>
                        <td class="right"><p>Bill To</p></td>
                        <td class="left">
                        	<p class="address">
                        	<?php

                        	echo $order['billing_address']['name'],'<br>',
                        	$order['billing_address']['address1'],'<br>',
                        	$order['billing_address']['address2']?$order['billing_address']['address2'].'<br>':'',
                        	$order['billing_address']['city'],', ',
                        	$order['billing_address']['province_code'],' ',$order['billing_address']['zip'];
                        	?>
                        	</p>
                        </td>
                    </tr>
                    <tr>
                    	<td class="right">&nbsp;</td>
                    	<td class="left">&nbsp;</td>
                    </tr>
                    <tr>
                    	<td class="right">&nbsp;</td>
                    	<td class="left">&nbsp;</td>
                    </tr>
                    <tr>
                    	<td class="right">&nbsp;</td>
                    	<td class="left">&nbsp;</td>
                    </tr>
				</table>
			</td>
			<td width="50%" align="right">
				<table>
                    <tr>
                        <td class="right"><p>Order #</p></td>
                        <td class="left"><p><?php echo $get_order['order']['order_number']?></p></td>
                    </tr>
                    <tr>
                        <td class="right"><p>Order Date </p></td>
                        <td class="left"><p><?php echo date('m/d/Y', strtotime($order['created_at']));?></p></td>
                    </tr>
                    <tr>
                        <td class="right"><p>Pickup Date </p></td>
                        <td class="left"><p><?php echo date('m/d/Y',strtotime($pickup_date))?></p></td>
                    </tr>
                    <tr>
                        <td class="right"><p>Pickup Time </p></td>
                        <td class="left"><p><?php echo $pickup_time;?></p></td>
                    </tr>
                    <tr>
                        <td class="right"><p>Pickup Location</p></td>
                        <td class="left">
                        	<p class="address">
                        		<?php echo $company,' <br> ',$address_1,'<br>',$city,', ',$state,' ',$post_code;?>
                        	</p>
                        </td>
                    </tr>
                </table>
            </td>
    	</tr>
    	<tr>
    		<td width="50%">
    			<table>
					<tr>
                        <td class="right"><p>Phone</p></td>
                        <td class="left"><p><?php echo $order['billing_address']['phone']?></p></td>
                    </tr>
				</table>
    		</td>
    	</tr>
	</table>
	
	<table class="items" width="100%" cellpadding="8">
		<thead>
			<tr>
				<td width="20%">Item</td>
				<td width="40%">Description</td>
				<td width="12%" align="right">Price</td>
				<td width="12%" align="right">Qty</td>
				<td width="16%" align="right">Ext. Price</td>
			</tr>
		</thead>
		<tbody>
			<!-- ITEMS HERE -->
			<?php
			foreach($order['line_items'] as $product){
                $product_image = shopify_call($token, $shop, "/admin/api/2020-01/products/".$product['product_id']."/images.json", array(), 'GET');
                $product_image = json_decode( $product_image['response'], true );
				?>
				<tr>
					<td style="text-align:left;"><img src="<?php echo $product_image['images'][0]['src']?>"> <span><?php echo $product['sku']?></span></td>
					<td><?php echo $product['title']?></td>
					<td class="cost"><?php echo getCurrencySymbol($product['currency']).$product['price']?></td>
					<td class="cost"><?php echo $product['quantity']?></td>
					<td class="cost"><?php echo getCurrencySymbol($product['currency']).number_format($product['quantity']*$product['price'],2);?></td>
				</tr>
				<?php
			}
			?>
			<!-- END ITEMS HERE -->
		</tbody>
	</table>
	<table class="footer" width="100%">
		<tr>
			<td class="service_address" width="50%"></td>
			<td width="50%" align="right">
				<table>
					<tr>
						<td class="right"><p>Subtotal</p></td>
						<td class="left"><p><?php echo getCurrencySymbol($order['currency']).$order['subtotal_price']?></p></td>
					</tr>
					<tr>
						<td class="right"><p>Discounts</p></td>
						<td class="left"><p>-<?php echo getCurrencySymbol($order['currency']).$order['total_discounts']?></p></td>
					</tr>
					<tr>
						<td class="right"><p>In-Store Pickup</p></td>
						<td class="left"><p>Free</p></td>
					</tr>
                    <?php if($order['total_tax']!='0.00'){?>
                    <tr>
                        <td class="right"><p>Tax</p></td>
                        <td class="left"><p><?php echo getCurrencySymbol($order['currency']).$order['total_tax']?></p></td>
                    </tr>
                    <?php }?>
					<tr>
						<td class="right"><p>Total</p></td>
						<td class="left"><p><?php echo getCurrencySymbol($order['currency']).$order['total_price']?></p></td>
					</tr>
				</table>
			</td>
		</tr>
    </table>
</div>

</body>
<?php
require_once("../inc/myjs.php");
?>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).on('change','.picked_by',function(){
        var orderId = $(this).attr('data-orderid');
        var picked_by = $(this).val();
        var option = $('option:selected', this).attr('data-id');
        if(confirm("are you sure?")==true){
            $.ajax({
                method:"POST",
                url:"./add_by.php",
                data:{action:"picked", orderId:orderId, picked_by:picked_by, option:option},
                beforeSend:function(){
                    toastr.options = {
                        closeButton: false,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.info("Please Wait ...",'');
                },
                success:function(response){
                    toastr.clear();
                    toastr.options = {
                        closeButton: true,
                        progressBar: true,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.success('<b>'+picked_by+'</b> assigned successfully', '');
                }
            });
        }
        else{
            $('#'+orderId).load(location.href + ' #'+orderId+">*","");
        }
    });
    $(document).on('change','.delivered_by',function(){
        var orderId = $(this).attr('data-orderid');
        var delivered_by = $(this).val();
        var option = $('option:selected', this).attr('data-id');
        if(confirm("are you sure?")==true){
            $.ajax({
                method:"POST",
                url:"./add_by.php",
                data:{action:"delivered", orderId:orderId, delivered_by:delivered_by, option:option},
                beforeSend:function(){
                    toastr.options = {
                        closeButton: false,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.info("Please Wait ...",'');
                },
                success:function(response){
                    toastr.clear();
                    toastr.options = {
                        closeButton: true,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.success('<b>'+delivered_by+'</b> assigned successfully', '');
                }
            });
        }
        else{
            $('#'+orderId).load(location.href + ' #'+orderId+">*","");
        }
    });
    $(document).on('click','.pickedup_by',function(){
        var orderId = $(this).attr('data-orderid');
        var pickedup_by = $('#pickedup_by_'+orderId).val();
        if($.trim(pickedup_by)!=''){
            $.ajax({
                method:"POST",
                url:"./add_by.php",
                data:{action:"pickedup_by", orderId:orderId, pickedup_by:pickedup_by},
                beforeSend:function(){
                    toastr.options = {
                        closeButton: false,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.info("Please Wait ...",'');
                },
                success:function(response){
                    toastr.clear();
                    toastr.options = {
                        closeButton: true,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.success('<b>'+pickedup_by+'</b> name saved successfully', '');
                    // $('#'+orderId).load(location.href + ' #'+orderId+">*","");
                }
            });
        }
        else{
             toastr.clear();
                toastr.options = {
                    closeButton: true,
                    progressBar: false,
                    showMethod: 'slideDown',
                    hideMethod: 'slideUp',
                    timeOut: 3000
                };
                toastr.error('Enter Picked Up By', 'Error');
        }
    });

    // mark as ready
    $(document).on('click','.mark_ready',function(){
        var orderId = $(this).attr('data-orderid');
        
        $.ajax({
            method:"POST",
            url:"./add_by.php",
            data:{action:"mark_ready", orderId:orderId},
            beforeSend:function(){
                toastr.options = {
                    closeButton: false,
                    progressBar: false,
                    showMethod: 'slideDown',
                    hideMethod: 'slideUp',
                    timeOut: 3000
                };
                toastr.info("Please Wait ...",'');
            },
            success:function(response){
                toastr.clear();
                toastr.options = {
                    closeButton: true,
                    progressBar: false,
                    showMethod: 'slideDown',
                    hideMethod: 'slideUp',
                    timeOut: 3000
                };
                toastr.success('Order is ready to Pickup', '');
                // $('#'+orderId).load(location.href + ' #'+orderId+">*","");
                $('.Status').removeClass('Polaris-Badge--statusAttention');
                $('.Status').removeClass('Polaris-Badge--statusAttention');
                $('.Status').addClass('Polaris-Badge--statusSuccess');
                $('.Status').addClass('Polaris-Badge--progressComplete');
                $('.Status').html('<span class="Polaris-VisuallyHidden">Attention</span><span class="Polaris-Badge__Pip"><span class="Polaris-VisuallyHidden">Incomplete</span></span>Ready');
            }
        });
        
    });
    
    $(document).on('click','.printSlip',function(){
    	PrintDiv();
    });

	function PrintDiv() {    
		var divToPrint = document.getElementById('packing-slip');
		var popupWin = window.open('', '_blank');
		//popupWin.document.open();
		popupWin.document.write('<html><head><title>Order-#<?php echo $get_order['order']['order_number']?></title><link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&display=swap" rel="stylesheet"><style>body{font-family:"Open Sans",sans-serif;color:#000}div#packing-slip{max-width:790px;width:100%;margin:0 auto}.title-container{text-align:left;width:50%;float:left}.logo-container{text-align:right;width:50%;float:right;margin-bottom:30px}.logo-container img{ width: 100%; }.title{font:bold 16px Arial;color:#000;text-align:left}.address{line-height:1.3}table{border-collapse:collapse}.center{text-align:center}.right{text-align:right;font:bold 16px "Open Sans";color:#000;padding:2px 7px}.left{text-align:left;font:15px "Open Sans";color:#000;padding:2px 7px}.border .left{border-left:1px solid #000}p{margin:0}table.items{border-bottom:2px solid #000}table.items td{ vertical-align: middle;}td{vertical-align:top;font:15px "Open Sans";position: relative;}table thead td{border:2px solid #000;font-weight:700;font-family:"Open Sans";font-size:18px!important;padding:2px 5px}.items td.totals{text-align:right;border-top:1px solid #000}.items td.cost{text-align:right}.items td img{max-width:40px;width:100%;/* margin-bottom:13px; */margin-right: 8px;}.footer{margin-top:3px}.footer .left{text-align:right;width:85px}span{ position: absolute;align-items: center;justify-content: center;display: inline-flex;bottom: 0;top: 0;}</style></head><body onload="window.print()"><div id="packing-slip">' + divToPrint.innerHTML + '</div></html>');
		popupWin.document.close();
	}
 
    ShopifyApp.Bar.initialize({
        title: 'Orders'
    });
</script>
</html>
<?php
/*echo "<pre>";
print_r ($get_order);
echo "</pre>";*/