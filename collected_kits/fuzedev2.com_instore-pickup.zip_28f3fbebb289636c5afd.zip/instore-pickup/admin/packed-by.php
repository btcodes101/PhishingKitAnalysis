<?php
require_once('../inc/functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Packed By</title>
    <?php require_once("../inc/mycss.php");?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap.min.css">    
</head>
<body>
    <div class="container-fluid">
        <h3>Manage Packed By</h3>
        <br>
   		<div class="row">
			<div class="col-md-8">
				<div class="table-responsive">
					<span style="clear:both" id="id1"></span><label class="error" id="box_error"></label>
					<span id="message"></span>
			        <table id="orders" class="table table-striped table-bordered">
			            <thead>
			                <tr>
								<th><input type="checkbox" id="selectall"></th>
								<th>Name</th>                    
			                    <th>Action</th>
							</tr>
			            </thead>
			            <tbody>
			            	<?php
			            	$query = mysqli_query($con,"SELECT * FROM packed_by WHERE store_id = '".$store_id."'");
		            		while($row=mysqli_fetch_assoc($query)){
			            	?>
				            	<tr class="gradeX" id="<?php echo "tr_".$row['id'];?>">
									<td><input value="<?php echo $row['id'];  ?>" type="checkbox" onClick="count()" name="packed[]" class="boxes" ></td>
									<td><?php echo $row['name'];?></td>
									<td>
										<a class="btn-success btn btn-xs" href="./packed-by/edit-packed.php?id=<?php echo $row['id'];?>">Edit</a> 
										<a class="btn-danger btn btn-xs" id="<?php echo $row['id'];?>" onClick="Delete(this.id);">Delete</a>
									</td>
								</tr>
								<?php
							}						
							?>
			            </tbody>
			            <tfoot>
			            	<div>
						        <div class="col-md-6" style="padding-left: 0;">
					            	<a class="btn btn-sm btn-danger" style="color:#FFFFFF;" onClick="DeleteAll();"><b><i class="fa fa-remove"></i> Delete</b></a>					        	
						        </div>
					        	<div class="col-md-6" style="padding-right: 0;">
							        <a href="./packed-by/index.php" class="btn btn-sm btn-success pull-right" style="color:#FFFFFF"><b><i class="fa fa-plus"></i> Add Packed By</b></a>
						        </div>
						    </div>
						    <div class="clearfix"></div>
							<br>
			            </tfoot>
			        </table>
		        </div>
		    </div>
		</div>
    </div>
    <?php
	require_once("../inc/myjs.php");
	?>
	<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap.min.js"></script>
	<script>
	    $(document).ready(function() {
	        $('#orders').DataTable({
	        	"order": [[ 1, "desc" ]]
	        });
	    });

	    function count()
		{
			document.getElementById("box_error").innerHTML = '';
			var packed = document.getElementsByName("packed[]");
			var n=0;
			for (var i = 0; i < packed.length; i++) 
			{       
				if (packed[i].checked) 
				{
				   n=n+1;
				}
			}
			$('#id1').html("<b>"+n+" item selected");
		}			
			 	
	    $('#selectall').click(function(event) {
		  //on click 
	        if(this.checked) { // check select status
	            $('.boxes').each(function() { //loop through each checkbox
	                this.checked = true;  //select all checkboxes with class "checkbox1"               
	            	count();
				});
	        }else{
	            $('.boxes').each(function() { //loop through each checkbox
	                this.checked = false; //deselect all checkboxes with class "checkbox1"                       
	          		count();
			    });         
	        }
	    });

	    function DeleteAll()
		{
			if (confirm("Are you Sure to Delete?")==true)
			{	
				var All = document.getElementsByName("packed[]");
				var Allpacked=[];
				for (var i = 0; i < All.length; i++) {       
				   if (All[i].checked) {
					 
						Allpacked.push(All[i].value);	
					}
				}
				if(Allpacked.length>0){
					var jsonString=JSON.stringify(Allpacked);
					
					$.ajax({
						type:"POST", 
						url:"./packed-by/DeleteAll.php",
						data: "Selected="+jsonString,
						success:function(msg){
						
							if(msg==1)
							{
								toastr.options = {
									closeButton: true,
									progressBar: false,
									showMethod: 'slideDown',
									timeOut: 3000
								};
								toastr.success('Selected Record Deleted Successfully', 'Deleted');
								$.each(Allpacked,function(index,val){
									setTimeout(function(){ document.getElementById("tr_"+val).innerHTML="";},300);
								});
								//$('.table-responsive').load(location.href+" .table-responsive>*","");
							}
							else{
								toastr.options = {
									closeButton: true,
									progressBar: false,
									showMethod: 'slideDown',
									hideMethod: 'slideUp',
									timeOut: 3000
								};
								toastr.error('Something wrong! Please try again...', '');
							}
						}
					});
				}
				else{
					toastr.options = {
						closeButton: true,
						progressBar: false,
						showMethod: 'slideDown',
						hideMethod: 'slideUp',
						timeOut: 3000
					};
					toastr.info('Please Select Atleast One Record', '');
				}
			}
		}
		function Delete(Id)
		{
			var condition = confirm("Are you sure you want to Delete?");
	                
	      	if(condition == true)
		  	{
		  		$.ajax({
					type:"POST",
					url:"./packed-by/deletepacked.php",
					data:"Id="+Id,
					success: function(msg)
					{	
						if(msg==1)
						{
							toastr.options = {
								closeButton: true,
								progressBar: false,
								showMethod: 'slideDown',
								hideMethod: 'slideUp',
								timeOut: 3000
							};
							toastr.success('Record Deleted Successfully', 'Deleted');
							setTimeout(function(){ document.getElementById("tr_"+Id).innerHTML="";},300);
						}
						else{
							toastr.options = {
								closeButton: true,
								progressBar: false,
								showMethod: 'slideDown',
								hideMethod: 'slideUp',
								timeOut: 3000
							};
							toastr.error('Something wrong! Please try again...', '');
						}
					}
				});
			}
		}
		ShopifyApp.Bar.initialize({
	        title: 'Picked By'
	    });
	</script>
</body>
</html>