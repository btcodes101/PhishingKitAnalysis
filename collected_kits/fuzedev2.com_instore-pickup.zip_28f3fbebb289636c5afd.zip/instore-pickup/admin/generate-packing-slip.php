<?php
session_start();
require_once("../inc/functions.php");
$token = $query['access_token'];

$order_id = '1935825862723';//$_GET['id'];
$get_order = shopify_call($token, $shop, "/admin/api/2019-10/orders/".$order_id.".json", array(), 'GET');
$get_order = json_decode($get_order['response'], TRUE);
$order = $get_order['order'];
foreach($order['note_attributes'] as $attribute){
    if($attribute['name']=='Pickup-Location-Company'){
        $company = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Address-Line-1'){
        $address_1 = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Address-Line-2'){
        $address_2 = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-City'){
        $city = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Region'){
        $state = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Postal-Code'){
        $post_code = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Location-Country'){
        $country = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Date'){
        $pickup_date = $attribute['value'];
    }
    if($attribute['name']=='Pickup-Time'){
        $pickup_time = $attribute['value'];
    }
    if($attribute['name']=='Delivered-by-Id'){
        $delivered_by_id = $attribute['value'];
    }
    if($attribute['name']=='Packed-by-Id'){
        $packed_by_id = $attribute['value'];
    }
}
// echo __DIR__."/mpdf57/mpdf.php";
// require_once __DIR__."/mpdf57/mpdf.php";
// exit();
?>
<html>
	<head>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&display=swap" rel="stylesheet">
		<style>
		body{font-family:"Open Sans",sans-serif;color:#000}div#packing-slip{max-width:790px;width:100%;margin:0 auto}.title-container{text-align:left;width:50%;float:left}.logo-container{text-align:right;width:50%;float:right;margin-bottom:30px}.logo-container img{ width: 100%; }.title{font:bold 16px Arial;color:#000;text-align:left}.address{line-height:1.3}table{border-collapse:collapse}.center{text-align:center}.right{text-align:right;font:bold 16px "Open Sans";color:#000;padding:2px 7px}.left{text-align:left;font:15px "Open Sans";color:#000;padding:2px 7px}.border .left{border-left:1px solid #000}p{margin:0}table.items{border-bottom:2px solid #000}table.items td{ vertical-align: middle;}td{vertical-align:top;font:15px "Open Sans";position: relative;}table thead td{border:2px solid #000;font-weight:700;font-family:"Open Sans";font-size:18px!important;padding:2px 5px}.items td.totals{text-align:right;border-top:1px solid #000}.items td.cost{text-align:right}.items td img{max-width:40px;width:100%;/* margin-bottom:13px; */margin-right: 8px;}.footer{margin-top:3px}.footer .left{text-align:right;width:85px}span{ position: absolute;align-items: center;justify-content: center;display: inline-flex;bottom: 0;top: 0;}

		</style>

	</head>
	<body>
		<div id="packing-slip">
		<div class="header">
			<div class="title-container">
				<h1 class="title">Packing Slip</h1>
			</div>
		<div class="logo-container">
			<img style="" src="<?php echo APP_URL.'assets/images/NewMHS-logo.png'?>" alt="Logo">
		</div>
	</div>
	<table width="100%" cellpadding="10">
		<tr class="border">
			<td width="50%">
				<table>
					<tr>
                        <td class="right"><p>Bill To</p></td>
                        <td class="left">
                        	<p class="address">
                        	<?php

                        	echo $order['billing_address']['name'],'<br>',
                        	$order['billing_address']['address1'],'<br>',
                        	$order['billing_address']['address2']?$order['billing_address']['address2'].'<br>':'',
                        	$order['billing_address']['city'],', ',
                        	$order['billing_address']['province_code'],' ',$order['billing_address']['zip'];
                        	?>
                        	</p>
                        </td>
                    </tr>
                    <tr>
                    	<td class="right">&nbsp;</td>
                    	<td class="left">&nbsp;</td>
                    </tr>
                    <tr>
                    	<td class="right">&nbsp;</td>
                    	<td class="left">&nbsp;</td>
                    </tr>
                    <tr>
                    	<td class="right">&nbsp;</td>
                    	<td class="left">&nbsp;</td>
                    </tr>
				</table>
			</td>
			<td width="50%" align="right">
				<table>
                    <tr>
                        <td class="right"><p>Order #</p></td>
                        <td class="left"><p><?php echo $get_order['order']['order_number']?></p></td>
                    </tr>
                    <tr>
                        <td class="right"><p>Order Date </p></td>
                        <td class="left"><p><?php echo date('m/d/Y', strtotime($order['created_at']));?></p></td>
                    </tr>
                    <tr>
                        <td class="right"><p>Pickup Date </p></td>
                        <td class="left"><p><?php echo date('m/d/Y',strtotime($pickup_date))?></p></td>
                    </tr>
                    <tr>
                        <td class="right"><p>Pickup Time </p></td>
                        <td class="left"><p><?php echo $pickup_time;?></p></td>
                    </tr>
                    <tr>
                        <td class="right"><p>Pickup Location</p></td>
                        <td class="left">
                        	<p class="address">
                        		<?php echo $company,' <br> ',$address_1,'<br>',$city,', ',$state,' ',$post_code;?>
                        	</p>
                        </td>
                    </tr>
                </table>
            </td>
    	</tr>
    	<tr>
    		<td width="50%">
    			<table>
					<tr>
                        <td class="right"><p>Phone</p></td>
                        <td class="left"><p><?php echo $order['billing_address']['phone']?></p></td>
                    </tr>
				</table>
    		</td>
    	</tr>
	</table>
	
	<table class="items" width="100%" cellpadding="8">
		<thead>
			<tr>
				<td width="20%">Item</td>
				<td width="40%">Description</td>
				<td width="12%" align="right">Price</td>
				<td width="12%" align="right">Qty</td>
				<td width="16%" align="right">Ext. Price</td>
			</tr>
		</thead>
		<tbody>
			<!-- ITEMS HERE -->
			<?php
			foreach($order['line_items'] as $product){
                $product_image = shopify_call($token, $shop, "/admin/api/2020-01/products/".$product['product_id']."/images.json", array(), 'GET');
                $product_image = json_decode( $product_image['response'], true );
				?>
				<tr>
					<td style="text-align:left;"><img src="<?php echo $product_image['images'][0]['src']?>"> <span><?php echo $product['sku']?></span></td>
					<td><?php echo $product['title']?></td>
					<td class="cost"><?php echo getCurrencySymbol($product['currency']).$product['price']?></td>
					<td class="cost"><?php echo $product['quantity']?></td>
					<td class="cost"><?php echo getCurrencySymbol($product['currency']).number_format($product['quantity']*$product['price'],2);?></td>
				</tr>
				<?php
			}
			?>
			<!-- END ITEMS HERE -->
		</tbody>
	</table>
	<table class="footer" width="100%">
		<tr>
			<td class="service_address" width="50%"></td>
			<td width="50%" align="right">
				<table>
					<tr>
						<td class="right"><p>Subtotal</p></td>
						<td class="left"><p><?php echo getCurrencySymbol($order['currency']).$order['subtotal_price']?></p></td>
					</tr>
                    <tr>
						<td class="right"><p>Discounts</p></td>
						<td class="left"><p>-<?php echo getCurrencySymbol($order['currency']).$order['total_discounts']?></p></td>
					</tr>
					<tr>
						<td class="right"><p>Shipping</p></td>
						<td class="left"><p><?php echo getCurrencySymbol($order['currency']).$order['total_shipping_price_set']['shop_money']['amount']?></p></td>
					</tr>
                    <?php if($order['total_tax']!='0.00'){?>
                    <tr>
                        <td class="right"><p>Tax</p></td>
                        <td class="left"><p><?php echo getCurrencySymbol($order['currency']).$order['total_tax']?></p></td>
                    </tr>
                    <?php }?>
					<tr>
						<td class="right"><p>Total</p></td>
						<td class="left"><p><?php echo getCurrencySymbol($order['currency']).$order['total_price']?></p></td>
					</tr>
				</table>
			</td>
		</tr>
    </table>
</div>

        <button onclick="PrintDiv()">Print</button>
	</body>
</html>

<script>
function PrintDiv() {    
		var divToPrint = document.getElementById('packing-slip');
		var popupWin = window.open('', 'Ravi');
		//popupWin.document.open();
		popupWin.document.write('<html><head><title>Order-<?php echo $get_order['order']['order_number']?></title><link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&display=swap" rel="stylesheet"><style>body{font-family:"Open Sans",sans-serif;color:#000}div#packing-slip{max-width:790px;width:100%;margin:0 auto}.title-container{text-align:left;width:50%;float:left}.logo-container{text-align:right;width:50%;float:right;margin-bottom:30px}.logo-container img{ width: 100%; }.title{font:bold 16px Arial;color:#000;text-align:left}.address{line-height:1.3}table{border-collapse:collapse}.center{text-align:center}.right{text-align:right;font:bold 16px "Open Sans";color:#000;padding:2px 7px}.left{text-align:left;font:15px "Open Sans";color:#000;padding:2px 7px}.border .left{border-left:1px solid #000}p{margin:0}table.items{border-bottom:2px solid #000}table.items td{ vertical-align: middle;}td{vertical-align:top;font:15px "Open Sans";position: relative;}table thead td{border:2px solid #000;font-weight:700;font-family:"Open Sans";font-size:18px!important;padding:2px 5px}.items td.totals{text-align:right;border-top:1px solid #000}.items td.cost{text-align:right}.items td img{max-width:40px;width:100%;/* margin-bottom:13px; */margin-right: 8px;}.footer{margin-top:3px}.footer .left{text-align:right;width:85px}span{ position: absolute;align-items: center;justify-content: center;display: inline-flex;bottom: 0;top: 0;}</style></head><body onload="window.print()"><div id="packing-slip">' + divToPrint.innerHTML + '</div></html>');
		popupWin.document.close();
}
</script>
<?php
/*echo "<pre>";
print_r ($order);
echo "</pre>";*/