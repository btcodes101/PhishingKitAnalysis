<script src="//netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script> 
<script src="//cdn.shopify.com/s/assets/external/app.js"></script>
<script src="<?php echo APP_URL.'assets/js/toastr.min.js'?>"></script> 
<script type="text/javascript">
	ShopifyApp.init({
		apiKey: "<?php echo $token;?>",
		shopOrigin: "https://miamiheatstore.myshopify.com/",
		debug: false,
		forceRedirect: true
	});
</script>