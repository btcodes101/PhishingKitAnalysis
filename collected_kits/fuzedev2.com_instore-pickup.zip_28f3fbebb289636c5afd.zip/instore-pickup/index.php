<?php
require_once("inc/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <?php require_once("inc/mycss.php");?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap.min.css">    
</head>
<body>
    
    <?php
        include_once 'orders.php';
    ?>   
    
</body>
<?php
require_once("inc/myjs.php");
?>
<script>
    ShopifyApp.Bar.initialize({        
        title: 'Dashboard'
    });
</script>
</html>