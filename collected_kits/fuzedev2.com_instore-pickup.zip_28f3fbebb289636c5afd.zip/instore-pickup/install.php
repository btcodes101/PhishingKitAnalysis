<?php

// Set variables for our request
if(isset($_GET['shop'])){
	$shop = $_GET['shop'];
}
else{
	$shop = 'miamiheatstore';
}
$api_key = "e0ec6f30847370236a986bf1f3531414";
$scopes = "read_orders,write_orders,read_all_orders,write_products";
$redirect_uri = "https://clickthedemo.com/instore-pickup/generate_token.php";

// Build install/approval URL to redirect to
$install_url = "https://" . $shop . "/admin/oauth/authorize?client_id=" . $api_key . "&scope=" . $scopes . "&redirect_uri=" . urlencode($redirect_uri);

// Redirect
header("Location: " . $install_url);
die();