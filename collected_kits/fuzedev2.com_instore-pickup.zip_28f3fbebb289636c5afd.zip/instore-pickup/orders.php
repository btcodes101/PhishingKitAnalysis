<?php
session_start();
require_once("inc/functions.php");
$token = $query['access_token'];
$query = array(
    "Content-type" => "application/json"
);
$products = shopify_call($token, $shop, "/admin/api/2019-10/orders.json", array(), 'GET');
$products = json_decode($products['response'], TRUE);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Orders</title>
    <?php require_once("inc/mycss.php");?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap.min.css">    
</head>
<body>
    <div class="container-fluid">
        <h3>Orders</h3>
        <br>
        <table id="orders" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>Orders</th>
                    <th>Date</th>
                    <th>Customer</th>
                    <th>Pickup Location</th>
                    <th>Pickup Date</th>
                    <th>Pickup Time</th>
                    <th>Payment Status</th>
                    <!-- <th>Fulfillment</th> -->
                    <th style="width:75px">Status</th>
                    <th>Total</th>
                    <th>Packed By</th>
                    <th>Delivered By</th>
                    <th>Picked Up By</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach($products['orders'] as $product){
                    if(!empty($product['note_attributes']) and strtolower($product['note_attributes'][0]['value'])=='pickup'){

                        echo '<tr id="'.$product['id'].'">
                        <td><a href="'.APP_URL.'admin/order-details.php?id='.$product['id'].'" class="_1Bu1z">'.$product['name'].'</a></td>
                        <td>'.date('d M Y',strtotime($product['created_at'])).' at '.date('h:i a',strtotime($product['created_at'])).'</td>
                        <td>'.$product['customer']['first_name'].' '.$product['customer']['last_name'].'</td>';

                        $delivered_by_id = $packed_by_id = $pickedup_by = $status = '';
                        foreach($product['note_attributes'] as $attribute){

                            if($attribute['name']=='Pickup-Location-Company'){
                                $company = $attribute['value'];
                            }
                            if($attribute['name']=='Pickup-Date'){
                                $pickup_date = $attribute['value'];
                            }
                            if($attribute['name']=='Pickup-Time'){
                                $pickup_time = $attribute['value'];
                            }
                            if($attribute['name']=='Delivered-by-Id'){
                                $delivered_by_id = $attribute['value'];
                            }
                            if($attribute['name']=='Packed-by-Id'){
                                $packed_by_id = $attribute['value'];
                            }
                            if($attribute['name']=='Pickedup-by'){
                                $pickedup_by = $attribute['value'];
                            }
                            if($attribute['name']=='Status'){
                                $status = $attribute['value'];
                            }
                        }
                        echo '<td>'.$company.'</td>';
                        echo '<td>'.date('M d, Y',strtotime($pickup_date)).'</td>';
                        echo '<td>'.$pickup_time.'</td>';

                        if($product['financial_status']=='paid'){                            
                            echo '<td><span class="_21Z9T _1EPFc"><span class="-EFlq"></span>'.ucwords($product['financial_status']).'</span></td>';
                        }
                        else{
                            echo '<td><span class="_21Z9T i4fQI _33uWB"><span class="-EFlq"></span>'.ucwords($product['financial_status']).'</span></td>';
                        }

                        /*if(empty($product['fulfillment_status'])){
                            echo '<td><span class="_21Z9T i4fQI _33uWB"><span class="-EFlq"></span>Unfulfilled</span></td>';
                        }
                        else{
                            echo '<td><span class="_21Z9T _1EPFc"><span class="-EFlq"></span>Fulfilled</span></td>';
                        }*/
                        if(empty($status)){
                            echo '<td><span class="_21Z9T i4fQI _33uWB"><span class="-EFlq"></span>Not Ready</span></td>';
                        }
                        else{
                            echo '<td><span class="_21Z9T _1EPFc"><span class="-EFlq"></span>Ready</span></td>';
                        }

                        echo '<td>'.getCurrencySymbol($product['currency']).' '.$product['total_price'].'</td>
                        <td>';
                        ?>
                        <select class="form-control picked_by" name="picked_by" data-orderId="<?php echo $product['id'];?>">
                            <option value="">Select</option>
                            <?php
                            $query = mysqli_query($con,"SELECT * FROM packed_by WHERE store_id = '".$store_id."' ORDER BY name ASC");
                            while($row=mysqli_fetch_assoc($query)){
                                if($row['id'] == $packed_by_id){
                                    $selected = 'selected';
                                }
                                else{
                                    $selected = '';
                                }
                                echo '<option value="'.$row['name'].'" data-id="'.$row['id'].'" '.$selected.'>'.$row['name'].'</option>';
                            }
                            ?>
                        </select>
                        <?php
                        echo '</td>
                        <td>';
                        ?>
                        <select class="form-control delivered_by" name="delivered_by" data-orderId="<?php echo $product['id'];?>">
                            <option value="">Select</option>
                            <?php
                            $query = mysqli_query($con,"SELECT * FROM delivered_by WHERE store_id = '".$store_id."' ORDER BY name ASC");
                            while($row=mysqli_fetch_assoc($query)){
                                if($row['id'] == $delivered_by_id){
                                    $selected = 'selected';
                                }
                                else{
                                    $selected = '';
                                }
                                echo '<option value="'.$row['name'].'" data-id="'.$row['id'].'" '.$selected.'>'.$row['name'].'</option>';
                            }
                            ?>
                        </select>
                        <?php
                        echo '</td>
                        <td>
                            <div class="col-md-9" style="padding-right:0">
                                <input type="text" name="pickedup_by" id="pickedup_by_'.$product['id'].'" class="form-control" value="'.$pickedup_by.'">
                            </div>
                            <div class="col-md-3">';
                                if($pickedup_by==''){
                                    $label = 'Add';
                                }
                                else{
                                    $label = 'Edit';
                                }
                                ?>
                                <button type="button" class="btn btn-sm btn-primary pickedup_by" data-orderId="<?php echo $product['id'];?>"> <?php echo $label;?> </button>
                                <?php 

                            echo '</div>
                        </td>
                        </tr>';
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
<?php
require_once("inc/myjs.php");
?>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('#orders').DataTable({
            "order": [[ 0, "desc" ]]
        });
    } );

    $(document).on('change','.picked_by',function(){
        var orderId = $(this).attr('data-orderid');
        var picked_by = $(this).val();
        var option = $('option:selected', this).attr('data-id');

        if(confirm("are you sure?")==true){
            $.ajax({
                method:"POST",
                url:"./admin/add_by.php",
                data:{action:"picked", orderId:orderId, picked_by:picked_by, option:option},
                beforeSend:function(){
                    toastr.options = {
                        closeButton: false,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.info("Please Wait ...",'');
                },
                success:function(response){
                    toastr.clear();
                    toastr.options = {
                        closeButton: true,
                        progressBar: true,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.success('<b>'+picked_by+'</b> assigned successfully', '');
                    // $('#'+orderId).load(location.href + ' #'+orderId+">*","");
                }
            });
        }
        else{
            $('#'+orderId).load(location.href + ' #'+orderId+">*","");
        }
    });

    $(document).on('change','.delivered_by',function(){
        var orderId = $(this).attr('data-orderid');
        var delivered_by = $(this).val();
        var option = $('option:selected', this).attr('data-id');
        
        if(confirm("are you sure?")==true){
            $.ajax({
                method:"POST",
                url:"./admin/add_by.php",
                data:{action:"delivered", orderId:orderId, delivered_by:delivered_by, option:option},
                beforeSend:function(){
                    toastr.options = {
                        closeButton: false,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.info("Please Wait ...",'');
                },
                success:function(response){
                    toastr.clear();
                    toastr.options = {
                        closeButton: true,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.success('<b>'+delivered_by+'</b> assigned successfully', '');
                    // $('#'+orderId).load(location.href + ' #'+orderId+">*","");
                }
            });
        }
        else{
            $('#'+orderId).load(location.href + ' #'+orderId+">*","");
        }
    });
    $(document).on('click','.pickedup_by',function(){
        var orderId = $(this).attr('data-orderid');
        var pickedup_by = $('#pickedup_by_'+orderId).val();
        if($.trim(pickedup_by)!=''){
            $.ajax({
                method:"POST",
                url:"./admin/add_by.php",
                data:{action:"pickedup_by", orderId:orderId, pickedup_by:pickedup_by},
                beforeSend:function(){
                    toastr.options = {
                        closeButton: false,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.info("Please Wait ...",'');
                },
                success:function(response){
                    toastr.clear();
                    toastr.options = {
                        closeButton: true,
                        progressBar: false,
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        timeOut: 3000
                    };
                    toastr.success('<b>'+pickedup_by+'</b> name saved successfully', '');
                    // $('#'+orderId).load(location.href + ' #'+orderId+">*","");
                }
            });
        }
        else{
             toastr.clear();
                toastr.options = {
                    closeButton: true,
                    progressBar: false,
                    showMethod: 'slideDown',
                    hideMethod: 'slideUp',
                    timeOut: 3000
                };
                toastr.error('Enter Picked Up By', 'Error');
        }
    });
    ShopifyApp.Bar.initialize({        
        title: 'Orders'
    });
</script>
</html>
<?php
/*
echo "<pre>";
print_r($products);
exit;
/*foreach($products['orders'] as $product){
    echo $product['name'];
    print_r ($product['note_attributes']);
}
echo "</pre>";
*/
?>