<?php
include_once ('inc/functions.php');
?>
<link rel="stylesheet" type="text/css" href="<?php echo APP_URL?>assets/css/front-style.css">
<div id="storepickupapp">
	<div class="checkout-method-container">
		<div class="checkout-method delivery active">
			<span>Delivery</span>
		</div>
		<div class="checkout-saperator">or</div>
		<div class="checkout-method pickup">
			<span>Curbside Pickup (Free)</span>
		</div>
	</div>
	<div class="checkout-method-container pickup">
		<input type="hidden" name="attributes[Checkout-Method]" value="Delivery"> 
		<div class="location-container">
			<div class="checkoutLocation">
				<?php
				$sql_location = mysqli_query($con,"SELECT * FROM locations WHERE store_id='".$store_id."'");
				$row_location = mysqli_fetch_assoc($sql_location);
				?>
				<input type="hidden" name="miami_pickup_location" value="<?php echo $row_location['company_name']?>"> 
				<input type="hidden" name="miami_pickup_address_1" value="<?php echo $row_location['address_line_1']?>"> 
				<input type="hidden" name="miami_pickup_city" value="<?php echo $row_location['city']?>"> 
				<input type="hidden" name="miami_pickup_region" value="<?php echo $row_location['state']?>"> 
				<input type="hidden" name="miami_pickup_postal_code" value="<?php echo $row_location['zip_code']?>"> 
				<input type="hidden" name="miami_pickup_country" value="<?php echo $row_location['country']?>"> 
				<span class="block">
					<span class="name">
						<strong>Pickup at <?php echo $row_location['company_name']?></strong>
					</span>
					<span class="address">
						<?php
						echo $row_location['address_line_1'].', ';
						if($row_location['address_line_2']!=''){
							echo $row_location['address_line_2'],', ';
						}
						echo $row_location['city'].', 
						'.$row_location['state'].' 
						'.$row_location['zip_code']
						?>
					</span>
				</span>
				<div class="locationInfo">
					<a href="javascript:void(0);">?</a>
				</div>
				<div class="loctionPopup">
					<div class="loctionPopup-container">
						<div class="title">
							About In-Store Pickup
							<a href="javascript:void(0);" class="info-close"><img src="<?php echo APP_URL.'assets/images/close.png'?>" alt=""></a>
						</div>
						<div class="info-content">
							<?php
							$about = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM instore_about_popup WHERE store_id = '".$store_id."'"));

							echo $about['about'];
							?>							
						</div>
					</div>
				</div>
			</div>
			<hr>
			<div class="checkoutTimeslot">
				<span class="block">
					<span class="name">
						<strong>Choose pickup time</strong>
					</span>
					<span class="address">Mon - Fri: 10am - 4pm</span>
				</span>
				<div class="pickup-date-container">
					<ul class="dates">
						<?php
						$row_disabled_dates = mysqli_fetch_assoc(mysqli_query($con,"SELECT dates FROM disabled_dates WHERE store_id = '".$store_id."'"));
						$disabled_dates = [];
						if(!empty($row_disabled_dates)){
							$disabled_dates = explode(',',$row_disabled_dates['dates']);
						}

						$no = 5;
						for($i = 0; $i<$no; $i++){
							$dayname = date('D',strtotime('+'.$i.' day'));
							$date = date('Y-m-d',strtotime('+'.$i.' day'));
							$inactiveDay = array('Sun', 'Sat');

							$disabled = "";
							$class = "";
							if(in_array($dayname, $inactiveDay)){
								// $disabled = "disabled";
								// $class = "disabled";
								$no++;
								continue;
							}

							if(!empty($disabled_dates)){
								if(in_array($date, $disabled_dates)){
									// $disabled = "disabled";
									// $class = "disabled";
									$no++;
									continue;
								}
							}
							?>
						<li>
							<input type="radio" name="miami_pickup_date" value="<?php echo $date;?>" id="<?php echo $dayname;;?>" <?php echo ($i==0)?'checked':''; echo $disabled;?>>
							<label for="<?php echo $dayname;?>" class="<?php if($i==0){ ?>active <?php } echo $class;?>">
								<span class="day-name"><?php echo $dayname;?></span>
								<span class="day-date"><?php echo date('M d',strtotime('+'.$i.' day'));?></span>
							</label>
						</li>
							<?php	
						}
						?>
					</ul>
					<span class="error pickup_date_error"></span>
				</div>
				<div class="pickup-time-container">
					<ul class="timeslot">
						<li>
							<label class="radio-container">10am - 12pm
								<input type="radio" name="miami_pickup_time" id="am10-pm12" value="10am - 12pm">
								<span class="checkmark"></span>
							</label>
						</li>
						<li>
							<label class="radio-container">12pm - 2pm
								<input type="radio" name="miami_pickup_time" id="pm12-pm2" value="12pm - 2pm">
								<span class="checkmark"></span>
							</label>
						</li>
						<li>
							<label class="radio-container">2pm - 4pm
								<input type="radio" name="miami_pickup_time" id="pm2-pm4" value="2pm - 4pm">
								<span class="checkmark"></span>
							</label>
						</li>
					</ul>
					<span class="error pickup_time_error"></span>
				</div>
				<div>
					<input type="hidden" name="attributes[Pickup-Date]" value="" style="display: none;"> 
					<input type="hidden" name="attributes[Pickup-Time]" value="" style="display: none;"> 
					<input type="hidden" name="attributes[Pickup-Location-Company]" value="" style="display: none;"> 
					<input type="hidden" name="attributes[Pickup-Location-Address-Line-1]" value="" style="display: none;"> 
					<input type="hidden" name="attributes[Pickup-Location-Address-Line-2]" value="" style="display: none;"> 
					<input type="hidden" name="attributes[Pickup-Location-City]" value="" style="display: none;"> 
					<input type="hidden" name="attributes[Pickup-Location-Region]" value="" style="display: none;"> 
					<input type="hidden" name="attributes[Pickup-Location-Postal-Code]" value="" style="display: none;"> 
					<input type="hidden" name="attributes[Pickup-Location-Country]" value="" style="display: none;"> 
					
					<input type="hidden" name="step" value="contact_information"> 
					<input type="hidden" name="method" value="pickup"> 
					<input type="hidden" name="checkout[shipping_address][company]" value="American Airline"> 
					<input type="hidden" name="checkout[shipping_address][address1]" value="601 Biscayne Blvd"> 
					<input type="hidden" name="checkout[shipping_address][address2]" value=""> 
					<input type="hidden" name="checkout[shipping_address][city]" value="Miami"> 
					<input type="hidden" name="checkout[shipping_address][country]" value="United States"> 
					<input type="hidden" name="checkout[shipping_address][zip]" value="33132"> 
					<input type="hidden" name="checkout[shipping_address][province]" value="Florida"> 
					<input type="hidden" name="locale" value="en-CA">
					<input type="hidden" name="old_form" value="">
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$(document).on('click','.checkout-method',function(){
		var $this = $(this);
		$('.checkout-method').removeClass('active');
		$this.addClass('active');
		if($('.checkout-method.active').hasClass('pickup')){
			$('.checkout-method-container.pickup').css('display','inline-flex');
			$("input[name='attributes[Checkout-Method]']").val('Pickup');
			$('input[name=discount]').val('FREECURBSIDEPICKUP');
		}
		else{
			$('.checkout-method-container.pickup').hide();
			$("input[name='attributes[Checkout-Method]']").val('Delivery');
			$("input[name='attributes[Pickup-Date]']").val('');
			$("input[name='attributes[Pickup-Time]']").val('');
			$("input[name='attributes[Pickup-Location-Company]']").val('');
			$("input[name='attributes[Pickup-Location-Address-Line-1]']").val('');
			$("input[name='attributes[Pickup-Location-City]']").val('');
			$("input[name='attributes[Pickup-Location-Region]']").val('');
			$("input[name='attributes[Pickup-Location-Postal-Code]']").val('');
			$("input[name='attributes[Pickup-Location-Country]']").val('');
			$("input[name='miami_pickup_time']").attr('checked',false);
			$("input[name='old_form']").val('');
			$('input[name=discount]').val('');
		}
	});
	$(document).on('click','.locationInfo > a',function(){
		$('.loctionPopup').show();
	});
	$(document).on('click','.info-close',function(){
		$('.loctionPopup').hide();
	});
	$(document).on('click','.pickup-date-container .dates label',function(){
		$('.pickup-date-container .dates label').removeClass('active');
		$(this).addClass('active');
		var dateInput = $(this).siblings('input');
		var dateID = dateInput.attr('id');
		$('.pickup-date-container .dates label').siblings('input').removeAttr('checked');
		$('#'+dateID).attr('checked',true);
		var pickup_date = $('#'+dateID).val();
		$("input[name='attributes[Pickup-Date]']").val(pickup_date);
	});

	$(document).on("click","input[name='miami_pickup_time']:checked",function(){
		let pickup_time = $(this).val();
		let pickup_date = $("input[name='miami_pickup_date']:checked").val();
		let pickup_location = $("input[name='miami_pickup_location']").val();
		let pickup_address_1 = $("input[name='miami_pickup_address_1']").val();
		let pickup_city = $("input[name='miami_pickup_city']").val();
		let pickup_region = $("input[name='miami_pickup_region']").val();
		let pickup_postal_code = $("input[name='miami_pickup_postal_code']").val();
		let pickup_country = $("input[name='miami_pickup_country']").val();

		$("input[name='attributes[Pickup-Date]']").val(pickup_date);
		$("input[name='attributes[Pickup-Time]']").val(pickup_time);
		$("input[name='attributes[Pickup-Location-Company]']").val(pickup_location);
		$("input[name='attributes[Pickup-Location-Address-Line-1]']").val(pickup_address_1);
		$("input[name='attributes[Pickup-Location-City]']").val(pickup_city);
		$("input[name='attributes[Pickup-Location-Region]']").val(pickup_region);
		$("input[name='attributes[Pickup-Location-Postal-Code]']").val(pickup_postal_code);
		$("input[name='attributes[Pickup-Location-Country]']").val(pickup_country);

		var old_url = $('.cart form').attr('action');
		var oldVal = $("input[name='old_form']").val();
		if(oldVal==''){
			$("input[name='old_form']").val(old_url);			
		}
		newUrl = replaceUrlParam(old_url,'step','contact_information');
		$('.cart form').attr('action',newUrl);
		
		var old_url = $('.cart form').attr('action');
		newUrl = replaceUrlParam(old_url,'method','pickup');
		$('.cart form').attr('action',newUrl);
		
		var old_url = $('.cart form').attr('action');
		newUrl = replaceUrlParam(old_url,'checkout[shipping_address][company]',pickup_location);
		$('.cart form').attr('action',newUrl);
		
		var old_url = $('.cart form').attr('action');
		newUrl = replaceUrlParam(old_url,'checkout[shipping_address][address1]',pickup_address_1);
		$('.cart form').attr('action',newUrl);
		
		var old_url = $('.cart form').attr('action');
		newUrl = replaceUrlParam(old_url,'checkout[shipping_address][city]',pickup_city);
		$('.cart form').attr('action',newUrl);
		
		var old_url = $('.cart form').attr('action');
		newUrl = replaceUrlParam(old_url,'checkout[shipping_address][country]',pickup_country);
		$('.cart form').attr('action',newUrl);
		
		var old_url = $('.cart form').attr('action');
		newUrl = replaceUrlParam(old_url,'checkout[shipping_address][zip]',pickup_postal_code);
		$('.cart form').attr('action',newUrl);
		
		var old_url = $('.cart form').attr('action');
		newUrl = replaceUrlParam(old_url,'checkout[shipping_address][province]',pickup_region);
		$('.cart form').attr('action',newUrl);
		
		var old_url = $('.cart form').attr('action');
		newUrl = replaceUrlParam(old_url,'locale','en-CA');
		$('.cart form').attr('action',newUrl);
	});

	$(document).on('submit','form',function(){
		var pickup_type = $("input[name='attributes[Checkout-Method]']").val();
		var flag = 0;
		if(pickup_type=='Pickup'){
			var pickup_date = $("input[name='miami_pickup_date']:checked").val();
			var pickup_time = $("input[name='miami_pickup_time']:checked").val();

			if(pickup_date == '' || typeof pickup_date == 'undefined'){
				$('.pickup_date_error').html('Please choose pickup date');
				flag++;
			}
			else{
				$('.pickup_date_error').html('');
			}

			if(pickup_time == '' || typeof pickup_time == 'undefined'){
				$('.pickup_time_error').html('Please choose pickup time');
				flag++;
			}
			else{
				$('.pickup_time_error').html('');
			}
		}
		
		if(flag==0){
			return true;
		}
		else{
			return false;
		}
	});

	function replaceUrlParam(url, paramName, paramValue)
	{
	    if (paramValue == null) {
	        paramValue = '';
	    }
	    var pattern = new RegExp('\\b('+paramName+'=).*?(&|#|$)');
	    if (url.search(pattern)>=0) {
	        return url.replace(pattern,'$1' + paramValue + '$2');
	    }
	    url = url.replace(/[?#]$/,'');
	    return url + (url.indexOf('?')>0 ? '&' : '?') + paramName + '=' + paramValue;
	}
</script>