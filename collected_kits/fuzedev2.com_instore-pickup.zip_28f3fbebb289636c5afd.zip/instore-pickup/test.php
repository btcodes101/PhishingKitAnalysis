<?php
	header('Access-Control-Allow-Origin: *');
?>
<div>
	<input type="hidden" name="attributes[Checkout-Method]" value="pickup" style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Location-Id]" value="55753" style="display: none;"> 
	<input type="hidden" name="attributes[Delivery-Location-Id]" value="" style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Date]" value="2019/12/31" style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Time]" value="4:40 PM" style="display: none;"> 
	<input type="hidden" name="attributes[Delivery-Date]" value="" style="display: none;"> 
	<input type="hidden" name="attributes[Delivery-Time]" value="" style="display: none;"> 
	<input type="hidden" name="attributes[Shipping-Date]" value="" style="display: none;"> 
	<input type="hidden" name="attributes[Shipping-Time]" value="" style="display: none;"> 
	<input type="hidden" name="attributes[Custom-Attribute-1]" value="" style="display: none;"> 
	<input type="hidden" name="attributes[Custom-Attribute-2]" value="" style="display: none;"> 
	<input type="hidden" name="attributes[Custom-Attribute-3]" value="" style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Location-Company]" value="address 2" style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Location-Address-Line-1]" value="268 S. Brookside St." style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Location-Address-Line-2]" value="" style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Location-City]" value="Daytona Beach" style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Location-Region]" value="Florida" style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Location-Postal-Code]" value="32114" style="display: none;"> 
	<input type="hidden" name="attributes[Pickup-Location-Country]" value="United States" style="display: none;"> 
	<input type="hidden" name="attributes[Delivery-Slot-Id]" value="" style="display: none;">
</div>