<head>
  <meta http-equiv="refresh" content="5">
</head>
<?
include_once "./../db.php";
$query = "select * from port365 order by id desc limit 0,1";
$result = mysqli_query($db,$query) or die ('Could not select data records because: '.mysqli_error($db));
echo "<table width=100% height=100%><tr valign=middle><td style=text-align:center><center><table width=50% cellpadding=50 cellspacing=20>";
while($row=mysqli_fetch_array($result)){
    echo "<tr valign=middle><td height=30% style=text-align:center";
    if($row['led1']==1){
        echo " bgcolor=green ";
    }else{
        echo " bgcolor=red ";
    }
    echo "><font color=white size=+5>LED-1</font></td></tr>";
    //echo "</br>";
    echo "<tr valign=middle><td height=30% style=text-align:center";
    if($row['led2']==1){
        echo " bgcolor=green ";
    }else{
        echo " bgcolor=red ";
    }
     echo "><font color=white size=+5>LED-2</font></td></tr>";
    //echo "</br>";
    echo "<tr valign=middle><td height=30% style=text-align:center";
    if($row['led3']==1){
        echo " bgcolor=green ";
    }else{
        echo " bgcolor=red ";
    }
     echo "><font color=white size=+5>LED-3</font></td></tr>";
    //echo "</br>";
    echo "<tr valign=middle><td height=30% style=text-align:center";
    if($row['led4']==1){
        echo " bgcolor=green ";
    }else{
        echo " bgcolor=red ";
    }
    echo "><font color=white size=+5>LED-4</font></td></tr>";
}
echo "</table></center></td></tr></table>";
?>