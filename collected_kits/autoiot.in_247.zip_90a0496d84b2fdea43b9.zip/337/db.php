<?
$db=mysqli_connect("localhost", "autoiot_root", "9697@Chennai4MyS", "autoiot_ports");

date_default_timezone_set('Asia/Kolkata');

Function IndDate($dt){
$strDt = '';
If (Substr($dt,0,4)=='0000'){
} Else {
$strDt = $strDt . Substr($dt,8,2);
$strDt = $strDt . "-".Substr($dt,5,2);
$strDt = $strDt . "-".Substr($dt,0,4);
}
Return $strDt;
}

Function UniDate($dt){
If (strlen($dt)>'5'){
$strDt = '';
$strDt = $strDt . Substr($dt,6,4);
$strDt = $strDt . "-".Substr($dt,3,2);
$strDt = $strDt . "-".Substr($dt,0,2);
Return $strDt;
}
}

Function UniTime($dt){
    If (strlen($dt)>'5'){
        $strTm = '';
        $strTm = $strTm . Substr($dt,11,9);
        Return $strTm;
    }
}

Function IndTime($dt){
    If (strlen($dt)>'5'){
        $strTm = '';
        $strTm = $strTm . Substr($dt,11,5);
        Return $strTm;
    }
}


Function UsToUniDate($dt){
If (strlen($dt)>'5'){
$strDt = '';
$strDt = $strDt . Substr($dt,6,4);
$strDt = $strDt . "-".Substr($dt,0,2);
$strDt = $strDt . "-".Substr($dt,3,2);
Return $strDt;
}
}
?>