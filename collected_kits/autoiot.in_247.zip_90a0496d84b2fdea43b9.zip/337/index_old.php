<?
include_once "db.php";
if(isset($_GET['led1'])){
    $led1=$_GET['led1'];
    $led2=$_GET['led2'];
    $led3=$_GET['led3'];
    $led4=$_GET['led4'];
    $query = "insert into port365 (led1, led2, led3, led4) values ('$led1', '$led2', '$led3', '$led4')";
    $result = mysqli_query($db, $query) or die ('Could not insert data records because: '.mysqli_error($db));
}
$query = "select * from port365 order by id desc limit 0,1";
$result = mysqli_query($db,$query) or die ('Could not select data records because: '.mysqli_error($db));
while($row=mysqli_fetch_array($result)){
    echo $row['led1'];
    echo "</br>";
    echo $row['led2'];
    echo "</br>";
    echo $row['led3'];
    echo "</br>";
    echo $row['led4'];
}
?>