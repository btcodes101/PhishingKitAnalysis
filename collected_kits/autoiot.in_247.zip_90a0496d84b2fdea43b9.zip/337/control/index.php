<?
include_once "./../db.php";

if(isset($_POST['switch1'])){
    $query = "insert into port337(status) values('1')";
    $result =  mysqli_query($db,$query) or die ('Could not insert data records because: '.mysqli_error($db));
}
if(isset($_POST['switch2'])){
    $query = "insert into port337(status) values('0')";
    $result =  mysqli_query($db,$query) or die ('Could not insert data records because: '.mysqli_error($db));
}

$query = "select * from port337 order by id desc limit 0,1";
$result = mysqli_query($db,$query) or die ('Could not select data records because: '.mysqli_error($db));
while($row=mysqli_fetch_array($result)){
    $status=$row['status'];
}
echo "<center><table width=300 height=300><tr>";
if($status==1){
    echo "<td bgcolor=green> &nbsp; </td>";
}else{
    echo "<td bgcolor=red> &nbsp; </td>";
}
echo "</tr></table><br>";


echo "<form name=switch method=post action=./>";
echo "<table><tr><td><input type=submit name=switch1 value=ON ";
if($status==1){
    echo "disabled";
}
echo " style='font-size:50px;'></td><td></td><td><input type=submit name=switch2 value=OFF ";
if($status==0){
    echo "disabled";
}
echo " style='font-size:50px;'></td></tr></table>";
echo "</form></center>";
?>

