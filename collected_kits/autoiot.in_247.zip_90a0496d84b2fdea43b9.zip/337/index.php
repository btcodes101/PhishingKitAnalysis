<?
include_once "./db.php";
$query = "select * from port337 order by id desc limit 0,1";
//echo $query;
$result = mysqli_query($db,$query) or die ('Could not select data records because: '.mysqli_error($db));
while($row=mysqli_fetch_array($result)){
    $status=$row['status'];
}
echo $status;
?>