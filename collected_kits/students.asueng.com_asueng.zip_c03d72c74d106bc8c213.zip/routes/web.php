<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/request_Login','UsersController@requestLogin')->name('RequestLogin');
Route::post('/requestLogin','UsersController@requestLoginPost')->name('request_login_post');
Route::get('/epr', 'UsersController@externalPasswordReset')->name('external_password_reset');
Route::get('/requestLogin/ticket/{id}','UsersController@signInTicketsShow')->name('signInTicketsShow');
Route::post('/requestLogin/ticket/{ticket}','UsersController@signInTicketsComment')->name('signInTicketsComment');

//Auth::routes();
//home
Route::get('/dashboard', 'DashboardController@index')->name('dashboard');

//Archive Dashboard
Route::get('/dashboard/archive', 'DashboardController@archive')->name('dashboard_archive');

Route::get('/dashboard/examination', 'DashboardController@examination')->name('dashboard_examination');
Route::get('/dashboard/quality', 'DashboardController@quality')->name('dashboard_quality');
Route::get('help', 'DashboardController@help')->name("help");
Route::get('manage', 'FacultyController@index')->name("manage");
Route::get('viewerror/{code?}', 'FacultyController@error')->name("error");
Route::get('/dashboard/financial', 'DashboardController@financial')->name('dashboard_financial');
Route::get('/dashboard/archive', 'DashboardController@archive')->name('dashboard_archive');
Route::get('/dashboard/archive/show/{archive}', 'DashboardController@showArchive')->name('dashboard_show_archive');

//Archive Dashboard
Route::get('/dashboard/my_archive', 'DashboardController@myArchive')->name('my_archive');
Route::get('/dashboard/my_services', 'DashboardController@myServices')->name('my_services');
Route::get('/dashboard/payments/get_amount/{id?}' ,'DashboardController@getPaymentAmount')->name('get_payment_amount');


//Payments
Route::get('/payments/student_fees', 'PaymentsController@studentFees')->name('student_fees');
Route::post('/payments/pay_student_fee','PaymentsController@payStudentFee')->name('pay_student_fee');
Route::get('/payments/payment_confirmation/{userRequest}','PaymentsController@studentPaymentConfirmation')->name('student_payment_confirmation');
Route::post('/payments/pay_with_student_credit/{userRequest}','PaymentsController@payWithStudentCredit')->name('pay_with_student_credit');
Route::get('/payments/student_credits','PaymentsController@studentCredits')->name('student_credits');
Route::post('/payments/charge_student_credit','PaymentsController@chargeStudentCredit')->name('charge_student_credit');

//User Requests
Route::get('/fawrytrans','UsersRequestsController@fawrytrans')->name('fawrytrans');
Route::match(['get', 'post'], '/bankmisrtranscreditcard','UsersRequestsController@bankMisrTransCreditCard')->name('bank_misr_trans_credit_card');
Route::match(['get', 'post'], '/bankmisrtransmeeza','UsersRequestsController@bankMisrTransMeeza')->name('bank_misr_trans_meeza');


Route::get('/dashboard/my_courses/{year?}', 'DashboardController@myCourses')->name('my_courses');
Route::get('/dashboard/courses/show/{course}' , 'DashboardController@showCourse')->name('show_course');
Route::post('/dashboard/applyto_external_program' , 'DashboardController@saveExternalProgram');
Route::get('/dashboard/applyto_external_program' , 'DashboardController@applyToExternalProgram')->name('applyto_external_program');
Route::get('/dashboard/upload_external_program_docs' , 'DashboardController@uploadExternalProgramDocs')->name('upload_external_program_docs');
Route::post('/dashboard/save_external_program_docs' , 'DashboardController@saveExternalProgramDocs')->name('save_external_program_docs');
Route::get('dashboard/show_external_program' , 'DashboardController@showExternalProgram')->name('show_external_program');
Route::post('/dashboard/update_module_course/{module}/{course}/{term}' , 'DashboardController@updateModuleCourse')->name('update_module_course');
Route::get('study/studies/courses', 'StudiesController@showStudentCourses')->name('showStudentCourses');
Route::get('/users/names' , 'UsersController@names')->name('users_names');
Route::get('/dashboard/control', 'DashboardController@control')->name('control');

//Profile
Route::get('/users/{user}/profile' , 'UsersController@profile')->name('show_profile');
Route::get('/students/{student}' , 'StudentsController@show')->name('show_student');
Route::get('/student_update/{student}' , 'StudentsController@updateStudent')->name('update_student');
Route::post('/student_update/{student}' , 'StudentsController@updateStudentPost')->name('update_student_post');
Route::get('study/studies/student_courses', 'StudiesController@studentCourses')->name('student_courses');
Route::get('study/studies/discuss', 'StudiesController@discuss')->name('academic_discuss');
Route::get('study/studies/registration_report', 'StudiesController@registrationReport')->name('registration_report');

Route::get('study/studies/student_sections/{committee}', 'StudiesController@getSections')->name('student_sections');
Route::post('study/studies/student_courses_action/{action}', 'StudiesController@coursesActions')->name('student_courses_actions');
Route::post('study/studies/select_elective_studies', 'StudiesController@selectElective')->name('select_elective_studies');

//exam details 
Route::get('/study/print_course_exam_details/{study}', 'StudiesController@printCourseExamDetails')->name('print_course_exam_details');

//logging in and signing out
Route::get('external','SessionsController@external');
Route::get('login', 'SessionsController@index')->name('login');
Route::post('login', 'SessionsController@login');
Route::get('logout', 'SessionsController@logout')->name('logout');
Route::get('reset', 'SessionsController@reset')->name('activation_link');
Route::post('reset', 'SessionsController@reset');
Route::get('request', 'SessionsController@request');

//Archive
Route::get('file/{archive}' , 'ArchiveController@download')->name('download_file');
Route::get('download' , 'ArchiveController@secureDownload')->name('secure_download_file');
Route::post('file/upload/{archive}' , 'ArchiveController@upload')->name('upload_file');
Route::post('file/delete/{archive}' , 'ArchiveController@delete')->name('delete_file');

//Archive Routes
Route::get('archive/add' , 'ArchiveController@edit')->name('add_archive');
Route::get('archive/0','ArchiveController@index');
Route::get('archive/{archive?}','ArchiveController@index')->name('archive');
Route::get('archive/order/{archive}/{position}/{neighbour_id}','ArchiveController@order')->name('order');
Route::get('archive/{archive}/edit/{from}' , 'ArchiveController@edit')->name('edit_archive');
Route::post('archive/0/save/{from}' , 'ArchiveController@save');
Route::post('archive/{archive}/save/{from}' , 'ArchiveController@save')->name('save_archive');
Route::get('archive/{archive}/images' , 'ArchiveController@getImages')->name('get_images');
Route::get('archive/download/{archive}' , 'ArchiveController@download')->name('download_file');
Route::post('archive/upload_files/0' , 'ArchiveController@uploadFiles');
Route::post('archive/upload_files/{archive}' , 'ArchiveController@uploadFiles')->name('upload_files');
Route::get('archive/export/{archive}' , 'ArchiveController@export')->name('export_archive');
Route::post('archive/import/{archive}' , 'ArchiveController@import')->name('import_archive');
Route::get('archive/download_files/{archive}' , 'ArchiveController@downloadFiles')->name('download_files');
Route::get('archive/download_all/{archive}' , 'ArchiveController@downloadAll')->name('download_all');
Route::post('archive/update_file/{archive}' , 'ArchiveController@updateFile')->name('update_file');
Route::post('archive/paste_to/0' , 'ArchiveController@pasteTo');
Route::post('archive/paste_to/{archive}' , 'ArchiveController@pasteTo')->name('paste_to_archive');
Route::post('archive/move_to/0' , 'ArchiveController@moveTo');
Route::post('archive/move_to/{archive}' , 'ArchiveController@moveTo')->name('move_to_archive');
Route::post('archive/delete/{archive}' , 'ArchiveController@delete')->name('delete_archive');
Route::get('archive/parents/0/{parent?}' , 'ArchiveController@parents');
Route::get('archive/parents/{archive?}/{root_id?}' , 'ArchiveController@parents')->name('archive_parents');
Route::get('archive/short_name/check/{short_name}' , 'ArchiveController@checkShortName')->name('check_archive_short_name');

//Tickets Routes
Route::get('/tickets','TicketsController@index')->name('tickets');
Route::get('/tickets/add','TicketsController@add')->name('add_ticket');
Route::post('/tickets/save','TicketsController@save')->name('save_ticket');
Route::post('/tickets/{ticket}/delete','TicketsController@delete')->name('delete_ticket');
Route::post('/tickets/{ticket}/comment','TicketsController@comment')->name('add_ticket_comment');
Route::post('/tickets/{ticket}/changeStatus','TicketsController@changeStatus')->name('change_ticket_status');
Route::match(['get', 'post'], '/tickets/{ticket}/close','TicketsController@close')->name('close_ticket');
Route::get('/tickets/external','TicketsController@showExternal')->name('show_external_ticket');
Route::get('/tickets/{ticket}','TicketsController@show')->name('show_ticket');
Route::post('/tickets/{ticket}/feedbak','TicketsController@userFeedbak')->name('user_ticket_feedbak');


//Activities
Route::get('/manage/activities/get_activities','ActivitiesController@activities')->name('activities_names');
Route::post('/manage/activities/0/save','ActivitiesController@save')->name('save_activities');

//Applicants
Route::post('/applicants/save/{type}/{applicant}','ApplicantsController@saveApplicant')->name('save_applicant');
Route::get('/applicants/download/{applicant}/{type}/{rand}','ApplicantsController@downloadApplicantFile')->name('download_applicant_file');
Route::get('/applicants/feedback/{applicant}','ApplicantsController@feedback')->name('feedback_applicant');
Route::get('/applicants/discuss/{applicant}','ApplicantsController@discuss')->name('discuss_applicant');
Route::post('/applicants/pg_specializations/{department}','ApplicantsController@pgSpecializations')->name('applicants_pg_specializations');
Route::post('/applicants/pg_programs/{term}/{department}','ApplicantsController@pgPrograms')->name('applicants_pg_programs');
Route::post('/applicants/delete/{applicant}','ApplicantsController@deleteApplicant')->name('delete_applicant');
Route::post('/applicants/email_verify','ApplicantsController@emailVerify')->name('applicant_email_verify');

//Routes Settings
Route::get('/manage/applicants','ApplicantsController@index')->name('applicants');
Route::get('/manage/applicants/{applicant}','ApplicantsController@show')->name('show_applicant');
Route::post('/manage/applicants/sheet','ApplicantsController@sheet')->name('applicants_sheet');
Route::post('/manage/applicants/actions','ApplicantsController@actions')->name('ApplicantActions');

//StudentsAffairs
Route::get('/students/services/change_track','StudentsServicesController@changeTrack')->name('change_track');
Route::post('/students/services/change_track','StudentsServicesController@saveChangeTrack')->name('save_change_track');
Route::get('/students/services/confirm_change_track/{token}','StudentsServicesController@confirmChangeTrack')->name('confirm_change_track');

Route::get('/students/services/select_track','StudentsServicesController@selectTrack')->name('select_track');
Route::post('/students/services/save_select_track','StudentsServicesController@saveSelectTrack')->name('save_select_track');
Route::get('/students/services/select_track_result','StudentsServicesController@trackPreferencesResultDisplay')->name('select_track_result');

//transfer between programs/plans
Route::get('/students/services/transfer_plan','StudentsServicesController@transferPlan')->name('transfer_to_plan');
Route::post('/students/services/save_transfer_plan','StudentsServicesController@saveTransferPlan')->name('save_transfer_to_plan');



//Courses Registration
Route::get('/students/services/courses_registration','StudentsServicesController@coursesRegistration')->name('courses_registration');
Route::post('/students/services/courses_registration','StudentsServicesController@saveCoursesRegistration')->name('save_courses_registration');

//Student Questionnaires
Route::get('/questionnaires/student' , 'QuestionnairesController@applyIndex')->name('questionnaire_apply_index');
Route::get('/questionnaires/show/{questionnaireTask}' , 'QuestionnairesController@applyShow')->name('questionnaire_apply_show');
Route::post('/questionnaires/{questionnaireTask}/save' , 'QuestionnairesController@applySave')->name('questionnaire_apply_save');
Route::get('/graduation/survey' , 'QuestionnairesController@graduationSurvey')->name('graduation_survey');
Route::post('/graduation/survey/save' , 'QuestionnairesController@saveGraduationSurvey')->name('save_graduation_survey');
Route::get('/training/questionnaire/{questionnaireTask?}' , 'QuestionnairesController@trainingQuestionnaire')->name('training_questionnaire');
Route::post('/training/questionnaire/save' , 'QuestionnairesController@saveTrainingQuestionnaire')->name('save_training_survey');

//Advisor Questionnaires 
Route::get('/advisor/questionnaires' , 'AdvisorQuestionnairesController@index')->name('advisor_questionnaire_index');
Route::post('/advisor/questionnaires/save' , 'AdvisorQuestionnairesController@saveAdvisorQuestionnaire')->name('save_advisor_questionnaire');

//Students grades
Route::get('/my_grades','StudentsServicesController@my_grades')->name('my_grades');

//Advisors Area
Route::get('/advisors/courses/registration/{student_id}','AdvisorsController@coursesRegistration')->name('advisor_courses_registration');
Route::post('/advisors/courses/registration/{student_id}','AdvisorsController@saveCoursesRegistration')->name('advisor_save_courses_registration');


//Student Questionnaires
Route::get('/questionnaires/student' , 'QuestionnairesController@applyIndex')->name('questionnaire_apply_index');
Route::get('/questionnaires/show/{questionnaireTask}' , 'QuestionnairesController@applyShow')->name('questionnaire_apply_show');
Route::post('/questionnaires/{questionnaireTask}/save' , 'QuestionnairesController@applySave')->name('questionnaire_apply_save');

//Student Research Plan
Route::get('/study/research/show', 'StudentsResearchController@show')->name('show_research');
Route::get('/study/research/edit', 'StudentsResearchController@edit')->name('edit_research');
Route::post('/study/research/save', 'StudentsResearchController@save')->name('save_research');
Route::get('/study/research/print', 'StudentsResearchController@print')->name('print_research');

//Save student Summer Term Decision
Route::post('/students/summer_term_decision','StudentsController@summerTermDecision')->name('summer_term_decision');



//student special requests
Route::get('/students/special_requests/submit','StudentsSpecialRequestsController@finalExamSpecialRequests')->name('exam_special_requests');
Route::post('/students/special_requests/submit','StudentsSpecialRequestsController@store')->name('save_exam_special_requests');


Route::post('/newsSearch','WebsiteController@newsSearch')->name('newsSearch');

//Website
Route::get('/staff','StaffProfileController@index')->name('staff');
Route::get('/staff/search','StaffProfileController@search')->name('staff_search');
Route::get('/staff/{instructor}','StaffProfileController@show')->name('staff_profile');

 
//Check Certificate
Route::get('/students/certificates/{studentCertificate}/{secrete}/check/{order?}' , 'StudentsCertificatesController@check')->name('check_certificate');
//Applicants Forms
Route::get('/home/applyto/{applyto}/{applicant?}/{secret?}','ApplicantsController@applyTo')->name('applyto');

//Internal Certificates Forms
Route::get('/students/certificates/my_requests', 
	'StudentsCertificatesController@myRequests')->name('my_certificates_requests');
Route::get('/students/certificates/request/edit/{userRequest?}',
	'StudentsCertificatesController@editRequest')->name('edit_certificate_request');
Route::get('/students/certificates/request/confirm/{userRequest}', 
	'StudentsCertificatesController@confirmRequest')->name('confirm_certificate_request');



//Students online exams 
Route::get('/students/services/online_exams_method','StudentsServicesController@selectOnlineExamsMethod')->name('online_exams_method');
Route::post('/students/services/online_exams_method/save' , 'StudentsServicesController@saveOnlineExamsMethod')->name('save_online_exams_method');

//Common
Route::post('/students/certificates/request/save/{userRequest?}', 
	'StudentsCertificatesController@saveRequest')->name('save_certificate_request');

//External Certificates Forms
Route::get('/home/certificates/request/verify', 
	'StudentsCertificatesController@verifyExternalRequest');
Route::post('/home/certificates/requests/external/verify', 
	'StudentsCertificatesController@verifyExternalRequestPost')->name('verify_external_certificate_request');
Route::get('/home/certificates/requests/edit/{token}', 
	'StudentsCertificatesController@editExternalRequest')->name('edit_external_certificate_request');
Route::get('/home/certificates/requests/confirm/{token}',
	'StudentsCertificatesController@confirmExternalRequest')->name('confirm_external_certificate_request');
Route::get('/home/certificates/requests/view/{token?}', 
	'StudentsCertificatesController@viewExternalRequest')->name('view_external_certificate_request');

//getActionPlanFile
Route::get('/getActionPlanFile', 'StudentsServicesController@getActionPlanFile');

//Studens Appeals
Route::match(['get', 'post'], '/control/apply_appeal', 'ControlController@applyAppeal')->name('std_apply_control_appeal');
Route::get('/control/apply_appeal/confirm/{userRequest}', 'ControlController@paymentConfirmation')->name('std_apply_control_appeal_confirm');
Route::post('/control/apply_appeal/cancel', 'ControlController@cancelAppealForCourse')->name('cancel_appeal_for_course');
Route::get('/control/appeal_result', 'ControlController@appealResult')->name('appeal_result');

//Studens Excuses
Route::get('/excuses', 'ExcuseController@index')->name('excuses');
Route::get('/excuses/submit', 'ExcuseController@create')->name('submit_excuse');
Route::post('/excuses/submit', 'ExcuseController@store')->name('save_excuse');
Route::get('/excuses/{excuse}/show', 'ExcuseController@show')->name('show_excuse');
Route::post('/excuses/{excuse}/comment','ExcuseController@comment')->name('add_excuse_comment');
Route::post('/excuses/{excuse}/add_files','ExcuseController@add_files')->name('excuse_add_files');
Route::post('/excuses/{excuse}/cancel_excuse','ExcuseController@cancel_excuse')->name('cancel_excuse');
Route::post('/excuses/get_term_courses','ExcuseController@getTermCourses')->name('get_term_courses');

//Students Trainings
Route::get('/trainings', 'StudentsTrainingsController@index')->name('trainings');
Route::get('/trainings/list', 'StudentsTrainingsController@list')->name('studentstrainings');
Route::get('/trainings/my', 'StudentsTrainingsController@myTrainings')->name('my_trainings');
Route::get('/trainings/follow_up/{studentTraining}', 'StudentsTrainingsController@trainingsFollowUp')->name('trainings_follow_up');
Route::post('/trainings/{studentTraining}/comment','StudentsTrainingsController@comment')->name('add_student_training_comment');
Route::get('/trainings/{id}/show', 'StudentsTrainingsController@show')->name('studentstrainings_show');
Route::post('/trainings/{id}/apply', 'StudentsTrainingsController@apply')->name('apply');
Route::get('/trainings/create', 'StudentsTrainingsController@create')->name('create_training_request');
Route::post('/trainings/store', 'StudentsTrainingsController@store')->name('store_training_request');
Route::get('/studentsTrainings/plans_by_bylaw/{bylaw}', 'StudentsTrainingsController@getPlansByBylaw')->name('plans_by_bylaw');

//Arch Aptitude Test
Route::get('/students/arch_aptitude_test/payment_confirmation','StudentsServicesController@archAptitudeTestPaymentConfirmation')->name('arch_aptitude_test_payment_confirmation');

Route::get('/excuses/payment_confirmation/{user_request_id}','ExcuseController@paymentConfirmation')->name('confirmation_excuses_fees_payment');


//External Students Re-registration Request
// Route::get('/ExternalRequests/Re-registration', 'StudentsExternalRequestsController@index')->name('external_requests_re_registration');
// Route::post('/ExternalRequests/Re-registration/store', 'StudentsExternalRequestsController@storeReRegistrationRequest')->name('store_external_re_registration_request');

//Request to be transferred from Interdisciplinary Program to Specialized Programs
Route::post('/transfer_ip_to_sp/store', 'StudentsServicesController@storeTransferIPToSPRequest')->name('store_transfer_ip_to_sp_requests');
//Request to be transferred from Specialized Program to Interdisciplinary Programs
Route::post('/transfer_sp_to_ip/store', 'StudentsServicesController@storeTransferSPToIPRequest')->name('store_transfer_sp_to_ip_requests');

//Takaful
Route::get('/takaful', 'TakafulRequestsController@index')->name('takaful');
Route::post('/takaful/submit', 'TakafulRequestsController@store')->name('takaful_submit');
Route::get('/takaful/payment_confirmation/{userRequest}', 'TakafulRequestsController@paymentConfirmation')->name('takaful_payment_confirmation');
Route::get('/takaful/edit/{takafulRequest}', 'TakafulRequestsController@edit')->name('takaful_edit');
Route::post('/takaful/save/{takafulRequest}', 'TakafulRequestsController@update')->name('takaful_save');

//Pages
Route::get('/education/undergraduates/bylaws/{blyaw}/{section?}/{sub_section?}', 'WebsiteController@viewBylaw')->name('view_bylaw');
Route::get('/', 'WebsiteController@index')->name('home');
Route::get('/{id1?}/{id2?}/{id3?}/{id4?}/{id5?}/{id6?}/{id7?}/{id8?}/{id9?}','WebsiteController@index')->name('index');
//Postgraduate
Route::get('/postgraduate/{id1?}/{id2?}/{id3?}/{id4?}/{id5?}/{id6?}/{id7?}/{id8?}/{id9?}', 'WebsiteController@postgraduate');
