<?php

namespace App;

use BaseModel\Model;

class StudentResearchStage extends BaseModel {

    protected $table = 'students_research_stages';

    protected $guarded = [];

    public $timestamps = false;

    public function submittedBy() {
        return $this->belongsTo('App\User', 'submitted_by', 'id');
    }

    public function reportedBy() {
        return $this->belongsTo('App\User', 'offical_approval_reported_by', 'id');
    }

    public function statusLabel() {
    	switch($this->stage_code) {
    		case 'registration': return __('tr.Registered');
    		case 'discussion': return __('tr.Discussed');
    		case 'change': return __('tr.Changed');
    	}
    	return '???';
    }
}
