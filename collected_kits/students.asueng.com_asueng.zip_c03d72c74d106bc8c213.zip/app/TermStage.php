<?php

namespace App;

use App\BaseModel;
use Carbon\Carbon;

class TermStage extends BaseModel
{
    protected $table = 'terms_stages';
    public $timestamps = false;

    public function bylaw() {
        return $this->belongsTo('App\Bylaw', 'bylaw_code', 'code');
    }

    public function term() {
        return $this->belongsTo('App\Term', 'term_id', 'id');
    }

    public function isOpen() {
    	$now = Carbon::now();
    	$start = Carbon::parse($this->start_date);
    	$end = Carbon::parse($this->end_date)->addDays(1);
        return ($now>=$start && $now<=$end);
    }

    public function isStarted() {
    	$now = Carbon::now();
    	$start = Carbon::parse($this->start_date);
        return ($now>=$start);
    }

    public static function isAnyOpen($stage_code, $bylaw){
         
        $stages = self::where('stage_code', $stage_code)->where('bylaw_code', $bylaw)->get();
        foreach($stages as $stage)
            if($stage->isOpen())
                return true;

        return false;
    }
}
