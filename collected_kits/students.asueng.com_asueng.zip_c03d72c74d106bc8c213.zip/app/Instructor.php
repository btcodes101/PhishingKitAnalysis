<?php

namespace App;

use App\BaseModel;

class Instructor extends BaseModel {

    protected $fillable = [
        'current_status',
    ];

    public function department(){
        return $this->belongsTo('App\Department');
    }

    public function instructorDegree(){
        return $this->belongsTo('App\InstructorDegree', 'degree', 'code');
    }

    public function user() {

        return $this->belongsTo('App\User','id','id');
    }

    public static function contentsTypes() {
        return [
            'Personal Photo' => __('tr.Personal Photo'),
            'Resume' => __('tr.Resume'),
        ];
    }

    public function canEditFiles() {
        $user = auth()->user();
        if($user->hasPermissionTo('edit_instructors'))
            return true;
        return ($user->id==$this->id);
    }

    public function canEditWork() {
        return auth()->user()->hasPermissionTo('edit_instructors');
    }

    public function canEditAcademic() {
        return (auth()->user()->hasPermissionTo('admin_system') || auth()->user()->id==$this->id);
    }

    public static function normalizeSeniority($instructor) {
        $otherInstructors = Instructor::select('instructors.*')
            ->join('users', 'users.id', '=', 'instructors.id')
            ->where('instructors.id', '!=', $instructor->id)
            ->where('instructors.degree', $instructor->degree)
            ->where('users.active', 1)
            ->orderBy('instructors.seniority')->get();
        $seniority = 1;
        $processed = false;
        foreach ($otherInstructors as $otherInstructor) {
            if($otherInstructor->seniority>=$instructor->seniority && !$processed) {
                $instructor->seniority = $seniority++;
                $instructor->save();
                $processed = true;
            }
            $otherInstructor->seniority = $seniority++;
            $otherInstructor->save();
        }

        if(!$processed) {
            $instructor->seniority = $seniority;
            $instructor->save();
        }
    }

    public function proctoringStaffPositions(){

        return $this->belongsTo('App\ProctoringStaffPosition','id','staff_id')->where('exams_id','=',Exams::current()->id);
    }
}
