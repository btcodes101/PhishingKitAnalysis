<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransferToPlanRequest extends Model
{
    //
    protected $table = 'transfer_to_plans_requests';
    protected $fillable = ['student_id', 'term_id',  'original_plan_id', 'current_plan_id', 'new_plan_id'];

    protected static function boot(){
        parent::boot();

        static::creating(function ($query) {
            $query->status = 1;
            $query->student_id = auth()->id();
            
        });
        
        static::updating(function ($query) {
            $query->status = 1;
        });
    }
}
