<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlanQuota extends Model
{
    protected $table = 'plans_quota';
    public $timestamps = false;
}
