<?php

namespace App;

use BaseModel\Model;

class Activities extends BaseModel
{
    protected $table = 'ico_cb_activities';
}
