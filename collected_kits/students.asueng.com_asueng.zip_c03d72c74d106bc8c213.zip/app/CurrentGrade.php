<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CurrentGrade extends Model
{
    protected $table = 'grades_current';

}
