<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FacultyBuilding extends Model
{
    protected $table = 'faculty_buildings';

    protected $fillable = [
        'id',
        'name',
        'status' ];

    public function locations(){
        return $this->hasMany('App\FacultyLocation', 'building_id', 'id');
    }

    public static function statusLabels() {
    	return [
    		0 => __("tr.Not Working"),
    		1 => __("tr.Working"),
    	];
    }
}
