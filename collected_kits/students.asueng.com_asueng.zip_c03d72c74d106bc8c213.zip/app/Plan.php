<?php

namespace App;

use App\BaseModel;
use App\Year;

class Plan extends BaseModel
{

    const DIPLOMA_PLAN = 1;
    const MASTER_PLAN = 2;
    const PHD_PLAN = 3;

    public function courses(){
        return $this->hasMany('App\Course');
    }

    public function year(){
        return $this->belongsTo('App\Year');
    }

    public function getBylaw(){
        return $this->belongsTo('App\Bylaw', 'bylaw', 'code');
    }

    public function minor(){
        if (\App::isLocale('en')) {
            return $this->en_minor;
        } else {
            return $this->ar_minor;
        }
    }

    public function major(){
        if (\App::isLocale('en')) {
            return $this->en_major;
        } else {
            return $this->ar_major;
        }
    }

    public function name() {
        $year = $this->year->lang('name');
        $program = $this->lang('program');
        $name = strtoupper($this->bylaw).", ".$year;
        if($program)$name .= ", ".$program;
        $name .= ", ".$this->lang('major');
        $name .= ", ".$this->lang('minor');
        return $name;
    }

    public function longName() {
        $year = $this->year->lang('name');
        $program = $this->lang('program');
        $name = $this->getBylaw->en_name.", ".$year;
        if($program)$name .= ", ".$program;
        $name .= ", ".$this->lang('major');
        $name .= ", ".$this->lang('minor');
        return $name;
    }

    public function isCreditHours() {
        return ($this->year_id>=Year::CREDIT_HOURS);
    }

    public static $cashedPlans = [];
    public static function getOLDCashed($oldMajorCode, $oldMinorCode, $oldYearCode) {
        
        $key = "$oldMajorCode:$oldMinorCode:$oldYearCode";

        if(array_key_exists($key, Plan::$cashedPlans))
            return Plan::$cashedPlans[$key];

        $plan = Plan::where('old_major_code', $oldMajorCode)->where('old_minor_code', $oldMinorCode)->where('year_id', $oldYearCode)->first();

        Plan::$cashedPlans[$key] = $plan;

        return $plan;
    }    

    public static function tracksList() {
        return [
            'specialized' => __('tr.Specialized (Formally Named as Mainstream)'),
            'interdisciplinary' => __('tr.Interdisciplinary (Formally Named as CHEP)'),
        ];
    }

    public static function programsList($track, $bylaw) {
        
        $query = Plan::where('bylaw', $bylaw);
        if($track=="interdisciplinary") {
            $query->where('code', 'like', '%_IDP%');
            $query->where('code', 'not like', '%_IDP0%');
        }
        else if($track=="specialized") {
            $query->where('code', 'like', '%_SP%');
            $query->where('code', 'not like', '%_SP0%');
        }

        return $query->orderBy(lang().'_minor')->pluck(lang().'_minor', 'id')->toArray();
    }

    static $parentsIDsCash = null;
    public static function getParentID($planID) {
        if(Plan::$parentsIDsCash === null ) {
            Plan::$parentsIDsCash = Plan::pluck('parent_id', 'id')->toArray();
        }
        return Plan::$parentsIDsCash[$planID];
    }

    public static function isOneOfParentsIDs($testPlanID, $planID) {

        while($planID) {
            if($planID==$testPlanID) {
                return true;
            }
            $planID = Plan::getParentID($planID);
        }
        return false;
    }

    public function getType()
    {
        /*
            TDT or PD for diploma which are Technical Diploma and Postgrad Diploma.
            ME or MC  or MR or MIE or PR for Master which are Master of Engineering and Master of Science and preparatory year.
            PH for Doctorate which is Doctor of Philosophy.
        */

        $short_name = substr($this->short_name, 4); //trim the first 4 chars 
        

        if(substr($short_name, 0, 3) === "TDT")
            return Plan::DIPLOMA_PLAN;
        elseif(substr($short_name, 0, 2) === "PD")
            return Plan::DIPLOMA_PLAN;
        elseif(substr($short_name, 0, 2) === "ME")
            return Plan::MASTER_PLAN;
        elseif(substr($short_name, 0, 2) === "MC")
            return Plan::MASTER_PLAN;
        elseif(substr($short_name, 0, 2) === "MR")
            return Plan::MASTER_PLAN;
        elseif(substr($short_name, 0, 3) === "MIE")
            return Plan::MASTER_PLAN;
        elseif(substr($short_name, 0, 2) === "PR")
            return Plan::MASTER_PLAN;
        elseif(substr($short_name, 0, 2) === "MS")
            return Plan::MASTER_PLAN;
        elseif(substr($short_name, 0, 2) === "PH")
            return Plan::PHD_PLAN;
        else
            return NULL;
    }
    
    public function isFinalPlan() {
        return !Plan::where('parent_id', $this->id)->exists();
    }
}
 