<?php

namespace App;

use App\BaseModel;

class Year extends BaseModel
{
	const CREDIT_HOURS = 100;
	
    public function name(){
	    if (\App::isLocale('en')) {
	        return $this->en_name;
	    } else {
	        return $this->ar_name;
	    }
	}

	public function next(){
		return Year::find($this->id+1);
	}
}
