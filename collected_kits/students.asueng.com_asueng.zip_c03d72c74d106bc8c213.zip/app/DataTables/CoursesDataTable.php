<?php

namespace App\DataTables;

use App\Grade;
use App\User;
use Yajra\DataTables\Services\DataTable;

class CoursesDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param mixed $query Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables($query)->setRowId('id');
          //  ->addColumn('action', 'courses.action');
    }

    /**
     * Get query source of dataTable.
     *
     * @param \App\User $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(Grade $model)
    {
        return $model->newQuery()->select(\DB::raw("users.en_name as student_name ,users.id as student_id,grade.id,grade.exam,grade.work,grade.total,grade.total_max"))
          ->join('users','users.code','=','grade.student_code');
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
                    ->columns($this->getColumns())
                    ->minifiedAjax()
                    ->addAction(['width' => '80px'])
                    ->parameters([
                      'dom' => 'Bfrtip',
                      'order' => [1, 'asc'],
                      'select' => [
                        'style' => 'os',
                        'selector' => 'td:first-child',
                      ],
                      'buttons' => [
                        ['extend' => 'create', 'editor' => 'editor'],
                        ['extend' => 'edit', 'editor' => 'editor'],
                        ['extend' => 'remove', 'editor' => 'editor'],
                      ]
                    ]);
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
      return [
        [
          'data' => null,
          'defaultContent' => '',
          'className' => 'select-checkbox',
          'title' => '',
          'orderable' => false,
          'searchable' => false
        ],
        'student_name',
        'total',
        'total_max',
        'exam',
        'work'
      ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'Courses_' . date('YmdHis');
    }
}
