<?php

namespace App;

use App\CertificateSerial;
use App\CertificateType;
use App\TokenSigner\TokenSigner;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class StudentCertificate extends Model
{
    protected $table = 'students_certificates';

    protected $guarded = [];

    const REPLACEMENTS = [
        '{{ARABIC_NAME}}' => 'ar_name',
        "{{ENGLISH_NAME}}" => 'en_name',
        '{{AR_MINOR}}' => 'ar_minor',
        '{{EN_MINOR}}' => 'en_minor',
        '{{EN_MAJOR}}' => 'en_major',
        '{{AR_MAJOR}}' => 'ar_major',
        '{{STUDY_AR_YEAR}}' => 'year_ar_name',
        '{{STUDY_EN_YEAR}}' => 'year_en_name',
        '{{STUDY_YEARS}}' => 'years',
        '{{TERM_AR_NAME}}' => 'term_ar_name',
        '{{TERM_EN_NAME}}' => 'term_en_name',
        '{{PROJECT_EN_GRADE}}' => 'project_en_grade',
        '{{PROJECT_AR_GRADE}}' => 'project_ar_grade',
        '{{FINAL_EN_GRADE}}' => 'final_en_grade',
        '{{FINAL_AR_GRADE}}' => 'final_ar_grade',
        '{{STUDENT_TOTAL}}' => 'total',
        '{{FINAL_TOTAL}}' => 'final_total',
        '{{STUDENT_NATIONAL_ID}}' => 'student_national_id',
        '{{STUDENT_PERCENT}}' => 'student_Percent',
        '{{STUDENT_BIRTH_DATE}}' => 'student_birth_data',
        '{{STUDENT_NATIONALITY_AR_NAME}}' => 'nationality_ar_name',
        '{{STUDENT_NATIONALITY_EN_NAME}}' => 'nationality_en_name',
        '{{BIRTH_CITY_AR_NAME}}' => 'birth_city_ar_name',
        '{{BIRTH_CITY_EN_NAME}}' => 'birth_city_en_name',
        '{{BIRTH_COUNTRY_EN_NAME}}' => 'birth_country_en_name',
        '{{BIRTH_COUNTRY_AR_NAME}}' => 'birth_country_ar_name',
        '{{STUDENT_CODE}}' => 'student_code',
        '{{STUDENT}}' => 'user',
    ];

    const STATUS_NEW = 0;
    const STATUS_PREPARED = 1;
    const STATUS_REVIEWED = 2;
    const STATUS_APPROVED = 3;
    const STATUS_READY = 5;
    const STATUS_NEED_UPDATE = 6;
    const STATUS_UPDATED = 7;
    const STATUS_REJECTED = 8;
    const STATUS_DATA_CHANGED = 9;
    const STATUS_SUBMIT_BY_MAIL = 10;
    const STATUS_ERROR = 20;

    public function student(){
        return $this->belongsTo(Student::class , 'student_id','id');
    }

    public function user(){
        return $this->belongsTo(User::class , 'student_id','id');
    }

    public function requestedBy(){
        return $this->belongsTo(User::class , 'requested_by' , 'id');
    }

    public function preparedBy(){
        return $this->belongsTo(User::class , 'prepared_by' , 'id');
    }

    public function reviewedBy(){
        return $this->belongsTo(User::class , 'reviewed_by' , 'id');
    }

    public function approvedBy(){
        return $this->belongsTo(User::class , 'approved_by' , 'id');
    }

    public function rejectedBy(){
        return $this->belongsTo(User::class , 'rejected_by' , 'id');
    }

    public function serials($order){
        return CertificateSerial::where('certificate_id', $this->id)->where('print_order', $order)->get();
    }

    public function printAt($order){
        return CertificateSerial::where('certificate_id', $this->id)->where('print_order', $order)->first()->printed_at;
    }

    public function canDeliver() {
        return ($this->status == StudentCertificate::STATUS_PREPARED || $this->status == StudentCertificate::STATUS_REVIEWED || $this->status == StudentCertificate::STATUS_APPROVED);
    }

    public function isSecurePrintReady() {

        if($this->status == StudentCertificate::STATUS_APPROVED) {
            return true;
        }

        return false;
    }

    public function canAccept($user = null)
    {
        if(empty($user)) {
            $user = auth()->user();
            $user->canRequest = $user->hasPermissionTo('request_certificates');
            $user->canReview = $user->hasPermissionTo('review_certificates');
            $user->canApprove = $user->hasPermissionTo('approve_certificates');
        }

        $status = false;
        if ($user->canRequest && ($this->status == StudentCertificate::STATUS_DATA_CHANGED || $this->status == StudentCertificate::STATUS_NEW || $this->status == StudentCertificate::STATUS_REJECTED || $this->status == StudentCertificate::STATUS_NEED_UPDATE || $this->status == StudentCertificate::STATUS_UPDATED)) $status = true;
        if ($user->canReview && ($this->status == StudentCertificate::STATUS_PREPARED || $this->status == StudentCertificate::STATUS_REJECTED || $this->status == StudentCertificate::STATUS_UPDATED || $this->status == StudentCertificate::STATUS_NEED_UPDATE)) $status = true;
        if ($user->canApprove && ($this->status == StudentCertificate::STATUS_REVIEWED || $this->status == StudentCertificate::STATUS_REJECTED || $this->status == StudentCertificate::STATUS_UPDATED || $this->status == StudentCertificate::STATUS_NEED_UPDATE)) $status = true;
        return $status;
    }

    public function accept() {

        switch ($this->status) {
            case StudentCertificate::STATUS_NEW:
            case StudentCertificate::STATUS_UPDATED:
            case StudentCertificate::STATUS_NEED_UPDATE:
            case StudentCertificate::STATUS_REJECTED:
            case StudentCertificate::STATUS_DATA_CHANGED:
                $this->status = StudentCertificate::STATUS_PREPARED;
                $this->prepared_by = auth()->id();
                $this->prepared_at = Carbon::now();
                break;
            case StudentCertificate::STATUS_PREPARED:
                $this->status = StudentCertificate::STATUS_REVIEWED;
                $this->reviewed_by = auth()->id();
                $this->reviewed_at = Carbon::now();
                break;
            case StudentCertificate::STATUS_REVIEWED:
                $this->status = StudentCertificate::STATUS_APPROVED;
                $this->approved_by = auth()->id();
                $this->approved_at = Carbon::now();
                break;
        }
        $this->save();
    }

    public  function canReject($user = null)
    {
        if(empty($user)) {
            $user = auth()->user();
            $user->canRequest = $user->hasPermissionTo('request_certificates');
            $user->canReview = $user->hasPermissionTo('review_certificates');
            $user->canApprove = $user->hasPermissionTo('approve_certificates');
        }

        $status = false;
        if ($user->canRequest && ($this->status == StudentCertificate::STATUS_DATA_CHANGED || $this->status == StudentCertificate::STATUS_NEW || $this->status == StudentCertificate::STATUS_PREPARED)) $status = true;
        if ($user->canReview && ($this->status == StudentCertificate::STATUS_PREPARED || $this->status == StudentCertificate::STATUS_REVIEWED)) $status = true;
        if ($user->canApprove &&($this->status == StudentCertificate::STATUS_REVIEWED || $this->status == StudentCertificate::STATUS_APPROVED)) $status = true;
        return $status;
    }

    public function archive() {
        return $this->belongsTo('App\Archive');
    }

    public static function certificatesTypes($student, $idsOnly = false) {

        $query = CertificateType::where('user_type', $student->user->type)->where('active', 1);

        $studentType = $student->getBylaw->type;
        $studentTypes = [];
        $studentTypes[] = 0;
        if($studentType == "undergraduate") {
            $studentTypes[] = 1;
        } else if($studentType == "postgraduate") {
            $studentTypes[] = 2;
        }

        $studyTypes = [];
        $studyTypes[] = CertificateType::STUDY_TYPE_BOTH;
        if($student->isCreditHours()) {
            $studyTypes[] = CertificateType::STUDY_TYPE_CREDIT;
        }
        else {
            $studyTypes[] = CertificateType::STUDY_TYPE_TERMS;
        }

        $graduationTypes = [];
        $graduationTypes[] = CertificateType::GRADUATION_TYPE_BOTH;
        $graduationTypes[] = CertificateType::GRADUATION_TYPE_BOTH;
        $graduationPublished = false;
        if($student->gradeTotal && $student->gradeTotal->published) $graduationPublished = true;
        if ($student->isGraduated() && $graduationPublished) {
            $graduationTypes[] = CertificateType::GRADUATION_TYPE_YES;
        } else if ($student->isSemiGraduated() && $graduationPublished) {
            $graduationTypes[] = CertificateType::GRADUATION_TYPE_PREYES;
        } 
        else {
            $graduationTypes[] = CertificateType::GRADUATION_TYPE_NO;
        }

        $genderOptions = [];
        $genderOptions[] = CertificateType::GENDER_FOR_BOTH;
        if ($student->user->gender==User::MALE){
            $genderOptions[] = CertificateType::GENDER_FOR_MALE_ONLY;
        } 
        else {
            $genderOptions[] = CertificateType::GENDER_FOR_FEMALE_ONLY;
        }

        $query->whereIn('gender', $genderOptions);
        $query->whereIn('study_type', $studyTypes);
        $query->whereIn('graduation_type', $graduationTypes);
        $query->whereIn('student_type', $studentTypes);

        if($idsOnly) {
            return $query->pluck('id')->toArray();
        }

        return $query->get();
    }

    public function certificateType(){
        
        return $this->belongsTo(CertificateType::class , 'certificate_type_id','id');
    }

    public static function statusLabels(){
        return [
            StudentCertificate::STATUS_NEW => __('tr.New'),
            StudentCertificate::STATUS_PREPARED => __('tr.Prepared'),
            StudentCertificate::STATUS_REVIEWED => __('tr.Reviewed'),
            StudentCertificate::STATUS_APPROVED => __('tr.Approved'),
            StudentCertificate::STATUS_READY => __('tr.Ready to Deliver Manually'),
            StudentCertificate::STATUS_SUBMIT_BY_MAIL => __('tr.Ready to Deliver by Mail'),
            StudentCertificate::STATUS_REJECTED => __('tr.Rejected'),
            StudentCertificate::STATUS_NEED_UPDATE => __('tr.Need Update'),
            StudentCertificate::STATUS_UPDATED => __('tr.Updated'),
            StudentCertificate::STATUS_DATA_CHANGED => __('tr.Data Changed'),
            StudentCertificate::STATUS_ERROR => __('tr.Error'),
        ];
    }

    public static function rejectStatusLabels(){
        return [
            StudentCertificate::STATUS_REJECTED => __('tr.Rejected'),
            StudentCertificate::STATUS_NEED_UPDATE => __('tr.Need Update'),
        ];
    }

    public static function statusBadges(){
        return [
            StudentCertificate::STATUS_NEW => 'new',
            StudentCertificate::STATUS_PREPARED => 'prepared',
            StudentCertificate::STATUS_REVIEWED => 'reviewed',
            StudentCertificate::STATUS_APPROVED => 'approved',
            StudentCertificate::STATUS_READY => 'ready manually',
            StudentCertificate::STATUS_SUBMIT_BY_MAIL => 'ready by mail',
            StudentCertificate::STATUS_REJECTED => 'rejected',
            StudentCertificate::STATUS_NEED_UPDATE => 'need-update',
            StudentCertificate::STATUS_UPDATED => 'updated',
            StudentCertificate::STATUS_DATA_CHANGED => 'data-changed',
            StudentCertificate::STATUS_ERROR => 'error',
        ];
    }

    public function statusLabel(){
        return StudentCertificate::statusLabels()[$this->status];
    }

    public function statusBadge(){
        return StudentCertificate::statusBadges()[$this->status];
    }

    public function isPrepared() {
        return ($this->status==StudentCertificate::STATUS_PREPARED||$this->status==StudentCertificate::STATUS_READY||$this->status==StudentCertificate::STATUS_SUBMIT_BY_MAIL);
    }

    public function isReviewed() {
        return ($this->status==StudentCertificate::STATUS_REVIEWED||$this->status==StudentCertificate::STATUS_READY||$this->status==StudentCertificate::STATUS_SUBMIT_BY_MAIL);
    }

    public function isApproved() {
        return ($this->status==StudentCertificate::STATUS_APPROVED||$this->status==StudentCertificate::STATUS_READY||$this->status==StudentCertificate::STATUS_SUBMIT_BY_MAIL);
    }

    public function isRejected() {
        return ($this->status==StudentCertificate::STATUS_REJECTED);
    }

    public function isUpdateRequired() {
        return ($this->status==StudentCertificate::STATUS_NEED_UPDATE);
    }

    public function signature($user) {

        if($user &&  $user->publicCertificate()) {
            if($this->certificateType->language=="en")
                return $user->archive->findChildByContentType('English Signature');
            else if($this->certificateType->language=="ar")
                return $user->archive->findChildByContentType('Arabic Signature');
        }

        return null;
    }

    public function signatures() {

        $signatures = (object)[];
        
        $signingInformation = $this->signingInformation();

        $signatures->preparation = (isset($signingInformation->preparation) && $signingInformation->preparation) ? $this->signature($this->preparedBy, $this->certificateType->language) : null;
        $signatures->reviewing = (isset($signingInformation->reviewing) && $signingInformation->reviewing) ? $this->signature($this->reviewedBy, $this->certificateType->language) : null;
        $signatures->approval = (isset($signingInformation->approval) && $signingInformation->approval) ? $this->signature($this->approvedBy, $this->certificateType->language) : null;

        if(empty($signatures->preparation) && empty($signatures->reviewing) && empty($signatures->approval))
            return null;

        return $signatures;
    }

    public function signingInformation() {
        $signingInformation = (object)[];
        if($this->signing_information)
            $signingInformation = (object)json_decode($this->signing_information);
        return $signingInformation;
    }

    public function getParameters() {

        $parameters = (object)[];
        if($this->parameters)
            $parameters = (object)json_decode($this->parameters);
        return $parameters;    
    }

    public static function getCertificate($id){
        return StudentCertificate::where('id',$id)->first();
    }

    public static function employees($type) {
        $name = lang()."_name";
        $users = User::join('students_certificates', "students_certificates.$type", 'users.id')->distinct()->pluck("users.$name", 'users.id')->toArray();
        if($type=="requested_by")
            return [0=>__('tr.External Request')] + $users;
        return $users;
    }

    public function checkSignature($type) {
        
        $signingInformation = $this->signingInformation();
        if(empty($signingInformation))return null;

        $signature = null;
        $signer = null;
        
        if($type=="preparation" && isset($signingInformation->preparation) && $signingInformation->preparation && $this->preparedBy) {
            $signature = $signingInformation->preparation;
            $signer = $this->preparedBy;
        }

        if($type=="reviewing" && isset($signingInformation->reviewing) && $signingInformation->reviewing && $this->reviewedBy) {
            $signature = $signingInformation->reviewing;
            $signer = $this->reviewedBy;
        }

        if($type=="approval" && isset($signingInformation->approval) && $signingInformation->approval && $this->approvedBy) {
            $signature = $signingInformation->approval;
            $signer = $this->approvedBy;
        }

        if(empty($signature) && empty($signer))
            return null;

        if(empty($signature) || empty($signer))
            return false;

        $certificate = $signer->publicCertificate();
        if(empty($certificate))
            return false;

        if(TokenSigner::verify($signer->publicCertificate(), $signingInformation->data, $signature))
            return $signature;

        return false;
    }

    public static function internalStudentCertifcateStatus($userId,$requestId){
        $lang = lang();
        return \DB::select('SELECT students_certificates.student_id,students_certificates.notes as "notes",students_certificates.parameters,students_certificates.status,certificates_types.'.$lang.'_name as "name" FROM students_certificates INNER JOIN certificates_types ON certificates_types.id = students_certificates.certificate_type_id WHERE students_certificates.student_id = '.$userId.' AND students_certificates.request_id = '.$requestId);
    }
}
