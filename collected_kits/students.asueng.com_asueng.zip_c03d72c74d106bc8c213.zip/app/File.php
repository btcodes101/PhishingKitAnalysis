<?php

namespace App;

use App\BaseModel;

class File extends BaseModel
{

}
