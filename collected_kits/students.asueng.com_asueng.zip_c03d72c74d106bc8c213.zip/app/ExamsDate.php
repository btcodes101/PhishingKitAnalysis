<?php

namespace App;

use App\FacultyLocation;
use App\Course;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use App\ProctoringCommitteeProctor;

class ExamsDate extends Model
{
    protected $table = 'exams_dates';

    protected $fillable = [
        'id',
        'exams_id',
        'day_date',
        'period_1',
        'period_2',
        'period_3',
        ];

    public function exams(){
        return $this->belongsTo('App\Exams' , 'exams_id','id');
    }

    public function preferences() {
        return $this->hasMany('App\ProctoringStaffPreference', 'exams_date_id','id');
    }

    public function examsCommittees() {
        return $this->hasMany('App\ExamsCommittee', 'exams_date_id', 'id');
    }

    public function userPreference($user) {
        return $this->preferences()->where('staff_id', $user->id)->first();
    }

    public function date() {
        return Carbon::parse($this->day_date);
    }

    public function passed() {
        //DISABLE_DAYS_CHECK
        return false; 
        return $this->date()->addDays(-2)->lte(Carbon::now());
    }

    public function dayLabel() {
        return weekDay($this->date()->dayOfWeek);
    }

    public function nPeriods(){
        
        $counter = 0;
        
        if ($this->period_1 == 1)$counter++;
        if ($this->period_2 == 1)$counter++;
        if ($this->period_3 == 1)$counter++;

        return $counter;
    }

    public static function periodName($period) {
        switch ($period) {
            case 1: return __("tr.First Period");
            case 2: return __("tr.Second Period");
            case 3: return __("tr.Third Period");
        }
    }

    public function required($period, $all) {

        if($all) {
            $filter = "1 as vice_chiefs, 1 as chiefs, 1 as proctors";
        } else {
            $filter = "(CASE WHEN T.study = 'pg' AND students>=70 THEN 2 WHEN T.study = 'pg' AND students<70 THEN 1 WHEN students>=70 THEN 1 ELSE 0 END) as vice_chiefs, 1 as chiefs, (CASE WHEN T.study = 'pg' THEN 0 ELSE T.initial_proctors END) AS proctors";
        }

        $committees = \DB::select(\DB::raw("SELECT T.*, $filter 
            FROM ( 
            SELECT exams_committees.location_id, SUBSTRING(courses.bylaw,1,2) as study, faculty_locations.name, 
                faculty_locations.capacity, faculty_locations.sectors, 
                max(exams_committees.extended_periods) as max_extended_periods, 
                min(exams_committees.extended_periods) as min_extended_periods, 
                sum(exams_committees.num_students) as students, 
                faculty_locations.sectors as initial_proctors,
                linked_id 
                FROM exams_committees 
                INNER JOIN faculty_locations ON faculty_locations.id  = exams_committees.location_id 
                INNER JOIN courses ON courses.id  = exams_committees.course_id
                WHERE exams_committees.exams_id = $this->exams_id AND
                    exams_committees.exams_date_id = $this->id AND
                    exams_committees.period = $period 
                GROUP BY exams_committees.location_id, study) AS T ORDER BY T.name;"));

        $result = (object)[
            'committees' => $committees,
            'chiefs' => 0,
            'vice_chiefs' => 0,
            'proctors' => 0,
            'chiefs_backup' => 0,
            'vice_chiefs_backup' => 0,
            'proctors_backup' => 0,
        ];

        foreach ($committees as $committee) {
            $result->chiefs += $committee->chiefs;
            $result->vice_chiefs += $committee->vice_chiefs;
            $result->proctors += $committee->proctors;
        }

        $result->chiefs_backup = ceil($result->chiefs*0.25);
        $result->vice_chiefs_backup = ceil($result->vice_chiefs*0.25);
        $result->proctors_backup = ceil($result->proctors*0.25);

        if($result->chiefs_backup<1 && $result->chiefs>0)
            $result->chiefs_backup = 1;
        if($result->vice_chiefs_backup<1 && $result->vice_chiefs>0)
            $result->vice_chiefs_backup = 1;
        if($result->proctors_backup<1 && $result->proctors>0)
            $result->proctors_backup = 1;

        return $result;
    }

    public function taken($period) {

        $committees = \DB::select(\DB::raw("SELECT location_id, 
            SUM(case when position = 1 then 1 else 0 end) as chiefs, 
            SUM(case when position = 2 then 1 else 0 end) as vice_chiefs, 
            SUM(case when position = 3 then 1 else 0 end) as proctors
            FROM proctoring_committees_proctors
            WHERE proctoring_committees_proctors.exams_id = $this->exams_id AND
                proctoring_committees_proctors.exams_date_id = $this->id AND
                proctoring_committees_proctors.period = $period
            GROUP BY location_id"));

        $result = (object)[
            'committees' => $committees,
            'chiefs' => 0,
            'vice_chiefs' => 0,
            'proctors' => 0,
            'chiefs_backup' => 0,
            'vice_chiefs_backup' => 0,
            'proctors_backup' => 0,
        ];

        foreach ($committees as $committee) {
            if($committee->location_id==-1) {
                $result->chiefs_backup += $committee->chiefs;
                $result->vice_chiefs_backup += $committee->vice_chiefs;
                $result->proctors_backup += $committee->proctors;
            } else {
                $result->chiefs += $committee->chiefs;
                $result->vice_chiefs += $committee->vice_chiefs;
                $result->proctors += $committee->proctors;
            }
        }

        return $result;
    }

    public function proctors($period, $all) {

        $required = $this->required($period, $all);
        $taken = $this->taken($period);

        $committees = [];

        foreach ($required->committees as $requiredCommittee) {

            $committee = clone $requiredCommittee;

            foreach ($taken->committees as $takenCommittee) {
                if($requiredCommittee->location_id == $takenCommittee->location_id) {
                    $committee->chiefs -= $takenCommittee->chiefs;
                    $committee->vice_chiefs -= $takenCommittee->vice_chiefs;
                    $committee->proctors -= $takenCommittee->proctors;
                }
            }

            $committees[] = $committee;
        }

        $available = (object)[
            'committees' => $committees,
            'chiefs' => 0,
            'vice_chiefs' => 0,
            'proctors' => 0,
            'chiefs_backup' => 0,
            'vice_chiefs_backup' => 0,
            'proctors_backup' => 0,
        ];

        foreach ($committees as $committee) {
            $available->chiefs += $committee->chiefs;
            $available->vice_chiefs += $committee->vice_chiefs;
            $available->proctors += $committee->proctors;
        }

        $available->chiefs_backup = $required->chiefs_backup - $taken->chiefs_backup;
        $available->vice_chiefs_backup = $required->vice_chiefs_backup - $taken->vice_chiefs_backup;
        $available->proctors_backup = $required->proctors_backup - $taken->proctors_backup;

        $result = (object) [
            'required' => $required,
            'taken' => $taken,
            'available' => ($all)?$required:$available,
        ];

        return $result;
    }

    public function available($period, $position) {

        $proctors = $this->proctors($period, false);

        $main = 0; 
        $backup = 0; 
        if($position==1) {
            $backup = $proctors->available->chiefs_backup;
            $main = $proctors->available->chiefs;
        }
        if($position==2) {
            $backup = $proctors->available->vice_chiefs_backup;
            $main = $proctors->available->vice_chiefs;
        }
        if($position==3) {
            $backup = $proctors->available->proctors_backup;
            $main = $proctors->available->proctors;
        }

        $result = (object) [
            'main' => $main,
            'backup' => $backup,
        ];

        return $result;
    }

    public function proctor($user, $period){
        return ProctoringCommitteeProctor::where('staff_id', $user->id)
            ->where('exams_id', $this->exams_id)
            ->where('exams_date_id', $this->id)
            ->where('period', $period)
            ->first();
    } 
}
