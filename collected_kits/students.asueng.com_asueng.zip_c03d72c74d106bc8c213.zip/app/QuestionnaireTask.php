<?php

namespace App;

use App\User;
use App\Archive;
use App\BaseModel;
use Auth;

class QuestionnaireTask extends BaseModel
{
    protected $table = "questionnaires_tasks";
    protected $fillable = [
        'status'
    ];

    public function term() {
    	return $this->belongsTo('App\Term');
    }

    public function questionnaire() {
        return $this->belongsTo('App\Questionnaire');
    }

    public function course() {
    	return $this->belongsTo('App\Course');
    }

    public function instructor() {
        return $this->belongsTo('App\User');
    }

    public function questionnaireAnswers() {
        return $this->hasMany('App\QuestionnaireAnswer','task_id','id');
    }

    public function questionnaireQuestions() {
        return $this->hasMany('App\QuestionnaireQuestion','questionnaire_id','questionnaire_id');
    }

    public function questionnaireQuestionsAnswers() {
        return \DB::table('questionnaires_answers')
            ->select(\DB::raw("questionnaires_questions.en_question, questionnaires_questions.ar_question, CONVERT(AVG(questionnaires_answers.score), SIGNED) as average_score"))
            ->join('questionnaires_questions', 'questionnaires_questions.id','=','questionnaires_answers.question_id')
            ->where('questionnaires_questions.type', '=', 0)
            ->where('questionnaires_answers.score', '>=', 0)
            ->where('questionnaires_answers.task_id', '=', $this->id)
            ->groupBy('questionnaires_answers.question_id')
            ->orderBy('questionnaires_questions.order')
            ->get();
    }

    public function questionnaireQuestionsComments() {
        $query = \DB::table('questionnaires_comments')
            ->select('questionnaires_comments.id', 'questionnaires_questions.en_question as question', 'questionnaires_comments.comment')
            ->join('questionnaires_questions', 'questionnaires_questions.id','=','questionnaires_comments.question_id')
            ->where('questionnaires_questions.type', '=', 1)
            ->where('questionnaires_comments.task_id', '=', $this->id);

        if(!auth()->user()->hasPermissionTo('edit_questionnaires')) {
            $query->where(function($subQuery){
                $subQuery->orWhereNull('review_status');
                $subQuery->orWhere('review_status', 1);
            });
        }

        return $query->get();
    }

    public function comments()
    {
        return $this->QuestionnaireComment()->select('comment')->whereNotNull('comment')->get();
    }

    public function questions($questionnaireID)
    {
        return $this->questionnaireQuestions()->select('question')
            ->where('questionnaire_id','=',$questionnaireID)
            ->where('type','=','0')->orderBy('order')->get();
    }

    public function score()
    {
        return $this->questionnaireAnswers()->select('comment')->whereNotNull('comment')->get();
    }

    public function instructors() {
        return User::select('users.id', 'users.en_name')
            ->whereIn('users.type', [User::TYPE_INSTRUCTOR, User::TYPE_EXTERNAL_INSTRUCTOR])
            ->whereRaw(\DB::raw("id IN(SELECT user_id FROM studies 
                WHERE term_id = $this->term_id AND course_id = $this->course_id)"))
            ->orWhereRaw(\DB::raw("id IN(SELECT instructor_id FROM questionnaires_tasks 
                WHERE term_id = $this->term_id AND questionnaire_id = $this->questionnaire_id AND course_id = $this->course_id AND instructor_id!=0)"))
            ->get();
    }

    public function canView() {
        if(auth()->user()->hasPermissionTo('show_questionnaires'))
            return true;
        
        $questionnaireTask = $this;
        return User::select('users.id', 'users.en_name')
            ->where(function($query) use ($questionnaireTask){
                $query->whereRaw(\DB::raw("id IN(SELECT user_id FROM studies 
                    WHERE term_id = $questionnaireTask->term_id AND course_id = $questionnaireTask->course_id)"));
                $query->orWhereRaw(\DB::raw("id IN(SELECT instructor_id FROM questionnaires_tasks 
                    WHERE term_id = $questionnaireTask->term_id AND questionnaire_id = $questionnaireTask->questionnaire_id AND course_id = $questionnaireTask->course_id AND instructor_id!=0)"));
            })
            ->where('users.id', '=', auth()->user()->id)
            ->count()>0;
    }

    public function title() {
        if($this->course_id==0){
            if (lang() == 'en') {
                return 'General Questionnaire';
            }else{
                return 'استبيانات عامة';
            }
        }

        return $this->course->lang('name');
    }

    public function isAnswered(){
        $query = QuestionnaireAnswer::where('student_id',Auth::user()->id)->where('task_id',$this->id)->limit(1)->get()->count();
        if($query > 0)
            return true;
        else
            return false;
    }
}