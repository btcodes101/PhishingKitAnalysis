<?php

namespace App;

use App\BaseModel;

class CourseInfoOld extends BaseModel
{
    protected $table = 'courses_info_old';
    public $timestamps = false;

    public  function plan() {
        return Plan::where('old_major_code', $this->main_spec)->where('old_minor_code', $this->minor_spec)->where('year_id', $this->year)->first();
    }

    public  function code() {
        return $this->department->code."".$this->code;
    }

    public  function ar_code() {
        return $this->department->ar_code."".$this->code;
    }

    public  function department() {
        return $this->belongsTo(Department::class , 'dept', 'old_id');
    }
}
