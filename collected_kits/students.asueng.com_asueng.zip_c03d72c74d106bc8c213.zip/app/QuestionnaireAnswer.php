<?php

namespace App;

use App\User;
use App\Archive;
use App\QuestionnaireTask;
use App\BaseModel;

class QuestionnaireAnswer extends BaseModel
{
    protected $table = "questionnaires_answers";

    public   $timestamps = false;

    protected $fillable = [
        'review_status'
    ];

    public function questionnaireTask(){
        return $this->belongsTo('App\QuestionnaireTask', 'task_id', 'id');
    }

    public static function reviewStatus() {
        return [
            2 => 'Not Reviewed',
            1 => 'Approved',
            0 => 'Rejected'
        ];
    }
}