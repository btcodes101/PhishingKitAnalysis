<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentPenaltyStatus extends Model
{
    protected $table = 'student_penalties_status';
    protected $fillable = ['student_id', 'term_id', 'comment', 'created_by', 'created_at', 'updated_at'];

    public function term(){
        return $this->belongsTo('App\Term','term_id');
    }

    public function student(){
        return $this->belongsTo('App\Student','student_id');
    }
}
