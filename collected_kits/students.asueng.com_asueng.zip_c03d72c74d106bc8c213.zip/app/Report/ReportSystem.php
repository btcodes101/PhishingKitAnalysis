<?php
/**
 * Created by PhpStorm.
 * User: Eng _ Abdulrahman
 * Date: 1/27/2019
 * Time: 4:21 PM
 */

namespace App\Report;

use App\Archive;
use App\StudentCertificate;
use Elibyy\TCPDF\Facades\TCPDF;

class ReportSystem extends TCPDF
{

    protected $archive;
    protected $replaceArray;
    protected $language;
    protected $date;
    protected $view;
    protected $pageType;
    protected $pageView;
    protected $margins;
    protected $signatures;
    protected $checkURL;

    public function __construct($language, $data, $view, $title, $signatures = null, $checkURL = null, $margins = ['left_right' => 20, 'top' => 65, 'header' => 10, 'footer' => 20], $fontSize = 15, $pageType = 'A4', $pageView = 'P', $archive = null, $replaceArray = [])
    {
        $this->archive = $archive;
        $this->replaceArray = $replaceArray;
        $this->language = $language;
        $this->data = $data;
        $this->fileTitle = $view;
        $this->view = "students.certificates.templates.$view";
        $this->pageType = $pageType;
        $this->pageView = $pageView;
        $this->fontSize = $fontSize;
        $this->margins = (object)$margins;
        $this->title = $title;
        $this->signatures = $signatures;
        $this->checkURL = $checkURL;
    }

    public function header()
    {
        $this::setHeaderCallback(function ($pdf) {

            $this::SetMargins($this->margins->left_right, $this->margins->top, $this->margins->left_right);

            // set style for barcode
            $style = array(
                'border' => 0,
                'vpadding' => '0',
                'hpadding' => '0',
                'fgcolor' => array(0, 0, 0),
                'bgcolor' => false, //array(255,255,255)
                'module_width' => 1, // width of a single module in points
                'module_height' => 1 // height of a single module in points
            );

            if ($this->language == 'ar') {
                $this::SetFont('arial', '', $this->fontSize);
            }
            else {
                $this::SetFont('calibri', '', $this->fontSize);
            }

            $padding = ($this->margins->top-55); //55 default margin 
            $title = $this->title;
            $data = $this->data;
            $signatures = $this->signatures;
            $section = "header";
            $lang = $this->language;
            $view = $view = \View::make("$this->view", compact('data', 'section', 'title', 'signatures', 'lang', 'padding'));
            $html = $view->render();
            $pdf->writeHTML($html);

            $image = public_path() . '/img/logo.png';

            if(false && empty($signatures)) {
                
                if ($this->language == 'ar') {
                    
                    $pdf->Image($image, 195, 10 + $padding, 25, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);

                    if($this->checkURL) {
                        $pdf->write2DBarcode($this->checkURL, 'QRCODE,H', 37, 12 + $padding, 24, 24, $style, 'N');
                    }
                } 
                else {

                    $pdf->Image($image, 10, 10 + $padding, 26, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);

                    if($this->checkURL) {
                        $pdf->write2DBarcode($this->checkURL, 'QRCODE,H', 171, 12 + $padding, 24, 24, $style, 'N');
                    }
                }                
            } 
            else {
                
                if ($this->language == 'ar') {
                    if($this->checkURL) {
                        $pdf->write2DBarcode($this->checkURL, 'QRCODE,H', 37, 12 + $padding, 24, 24, $style, 'N');
                    }
                }
                else {
                    if($this->checkURL) {
                        $pdf->write2DBarcode($this->checkURL, 'QRCODE,H', 12, 12 + $padding, 24, 24, $style, 'N');
                    }
                }
            }

        });
    }


    public function footer()
    {
        $this::setFooterCallback(function ($pdf) {
            if ($this->language == 'ar') {
                $this::SetFont('arial', '', $this->fontSize);
            }
            else {
                $this::SetFont('calibri', '', $this->fontSize);
            }
            $data = $this->data;
            $signatures = $this->signatures;
            $section = "footer";
            $lang = $this->language;
            $pageNumber = $pdf->getAliasNumPage().'/'.$pdf->getAliasNbPages();
            $view = $view = \View::make("$this->view", compact('data', 'section', 'signatures','lang', 'pageNumber'));
            $html = $view->render();
            $pdf->writeHTML($html);
        });
    }


    public function build()
    {
        if ($this->language == 'ar') {
            $setting = ['a_meta_charset' => 'UTF-8', 'a_meta_dir' => 'rtl', 'a_meta_language' => 'ar', 'w_page' => 'page'];
        } else {
            $setting = ['a_meta_charset' => 'UTF-8', 'a_meta_dir' => 'ltr', 'a_meta_language' => 'en', 'w_page' => 'page'];
        }
        app()->setlocale($this->language);

        $this->header();
        $this->footer();
        $this::SetMargins($this->margins->left_right, $this->margins->top, $this->margins->left_right);
        $this::SetHeaderMargin($this->margins->header);
        $this::SetFooterMargin($this->margins->footer);
        $this::setLanguageArray($setting);
        if ($this->language == 'ar')
            $this::SetFont('arial', '', $this->fontSize);
        else
            $this::SetFont('calibri', '', $this->fontSize);

        $this::SetTitle($this->title);
        $this::AddPage($this->pageView, $this->pageType);
        $data = $this->data->toArray();

        if($this->archive) {
            $content = $this->archive->getContent();
            if (!empty($this->replaceArray)) {
                foreach ($this->replaceArray as $key => $value) {
                    if (isset($data[$value]) || $data[$value] == null) {
                        $content = mb_ereg_replace($key, $data[$value], $content);
                    }
                }
            }
        }

        if ($this->view != null) {
            $title = $this->title;
            $data = $this->data;
            $lang = $this->language;
            $signatures = $this->signatures;
            $view = $view = \View::make("$this->view", compact('data', 'title', 'signatures','lang'));
        }
        $html = $view->render();
        $this::writeHTML($html, true, false, true, false, '');
        $code = (isset($this->data->user))? $this->data->user->code : '';
        $this::Output($this->fileTitle."_".$code.".pdf", 'I');
    }
}
