<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentSummerTermDecision extends Model
{
    protected $table = 'student_summer_term_decision';

    protected $fillable = ['student_id', 'term_id', 'decision'];
}
