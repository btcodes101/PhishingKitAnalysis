<?php

namespace App;
use App\User;

use BaseModel\Model;

class CommitteeInstructor extends BaseModel
{
    protected $table = 'committees_instructors';
    protected $guarded = [];
    public $timestamps = false;

    public function user(){
        return $this->belongsTo('App\User', 'instructor_id', 'id');
    }

    public function committee(){
        return $this->belongsTo('App\Committee');
    }

    public function canView() {
    	return true;
    }

    public function canEditFinal() {
    	return ($this->role==Study::ROLE_TEACHER);
    }

    public function canEditWork() {
    	return ($this->role==Study::ROLE_TEACHER || $this->role==Study::ROLE_TEACHING_ASSISTANT);
    }

    public function canEditAny() {
    	return ($this->role==Study::ROLE_TEACHER || $this->role==Study::ROLE_TEACHING_ASSISTANT);
    }

    public function instructorProfileLink($id){
        $user = User::where('type', User::TYPE_INSTRUCTOR)->where('id', $id)->first();
        if(empty($user))
            return '#';
        else
            return route('staff_profile', $user->shortName());
    }
}
