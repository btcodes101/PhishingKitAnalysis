<?php

namespace App;

use App\BaseModel;
use App\NewGrade;
use App\Excuse;

class GradeTerm extends BaseModel
{
	protected $table = 'grades_terms';

	public function student() {
        return $this->belongsTo('App\Student');
    }

    public function term() {
        return $this->belongsTo('App\Term');
    }

    public function plan() {
        return $this->belongsTo('App\Plan');
    }

    public function getYear(){
        return $this->belongsTo('App\Year','year','id');
    }

    public function getLevel() {
        return $this->belongsTo('App\Level','level','id');
    }

    public function gradeType() {
        return $this->belongsTo('App\GradeType','grade_type','id')->withDefault([
            'en_name' => '-',
            'ar_name' => '-',
        ]);
    }

    public function status() {
        return $this->belongsTo('App\StudentStatus', 'student_status', 'code')->withDefault([
            'en_name' => '-',
            'ar_name' => '-',
        ]);
    }

    public function facultyStatus() {
        return $this->belongsTo('App\StudentStatus','faculty_student_status', 'code')->withDefault([
            'en_name' => '-',
            'ar_name' => '-',
        ]);
    }

    public function getGrades($orderColumn="courses.code") {
        if($this->term->sis_term_id=="500") {
            return Grade::select('grades.*')
                ->join('terms', 'grades.term_id', 'terms.id')
                ->join('courses', 'courses.id', 'grades.course_id')
                ->where('terms.sis_term_id','LIKE', '5%')
                ->where('grades.student_id', $this->student_id)
                ->orderBY($orderColumn)
                ->get();
        }

        return Grade::select('grades.*')
            ->join('grades_terms', function($join){
            	$join->on('grades_terms.student_id', 'grades.student_id');
            	$join->on('grades_terms.term_id', 'grades.term_id');
            })
            ->join('courses', 'courses.id', 'grades.course_id')
            ->where('grades_terms.id','=',$this->id)
            ->orderBY($orderColumn)
            ->get();
    }

    public function isSucceeded() {

        if(in_array($this->grade_type, [1,2,3,4,5]))
            return true;

        return false;
    }

}
