<?php

namespace App;

use App\UserRequest;
use App\BaseModel;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use DB;

class StudentCredit extends BaseModel
{
    public $table = 'students_credits';

    const TYPE_DEPOSIT = 1;
    const TYPE_WITHDRAW = 2;
   
    public static function typesList() {
        return [
            StudentCredit::TYPE_DEPOSIT => 'Deposit',
            StudentCredit::TYPE_WITHDRAW => 'Withdraw',            
        ];
    }
}
