<?php

namespace App;

use App\BaseModel;

class CourseGroup extends BaseModel
{
    protected  $table = 'courses_groups';
    public $timestamps = false;

    public function course() {
        return $this->belongsTo('App\Course');
    }

    public function plan() {
        return $this->belongsTo('App\Plan', 'program', 'id');
    }

    public function compulsoryGroup() {
    	$courseGroup = strtolower($this->group_parent);
    	if(stristr($courseGroup, 'compulsory')) return ucwords($courseGroup);
    	return null;
    }

    public function relatedCoursesGroups() {

    	$index = $this->index;
    	$query = CourseGroup::where('bylaw', $this->bylaw);
    	$courseGroup = strtolower($this->course_group);
    	$plan = Plan::where('short_name', $courseGroup)->first();
    	if(	startsWith($courseGroup, 'university') || 
    		startsWith($courseGroup, 'faculty') || 
    		$plan) {
    		$query->where('program', $this->course_group);
    		$query->where('group', 'default');
    	}
    	else if(stristr($courseGroup, 'concentration')) {
    		$query->where(function($query) use($courseGroup) {
    			$query->orWhere('group_parent', $courseGroup);
    			$query->orWhere('group', $courseGroup);
    		});
    		$index = 1;
    	}
    	else if(stristr($courseGroup, 'compulsory')) {
    		$groups = CourseGroup::where('bylaw', $this->bylaw)
    		->where('program', $this->program)
    		->where('group_parent', $this->course_group)    		
    		->distinct('group')
    		->pluck('group')
    		->toArray();
    		if(count($groups)>0)
    			$query->where('group', $groups[0]);
    		else
    			return [];
    	}
    	else if(stristr($courseGroup, 'elective')) {
    		$query->where('group', $this->course_group);
    		$index = 1;
    	}
    	else {
    		return [];
    	}

    	if($this->modifier) {
    		$query->where('group_modifier', $this->modifier);
    	}

    	if($index) {
    		$query->offset($this->index-1)->limit(1);
    	}
    	
    	$coursesGroups = $query->orderBy('id')->get();

    	$finalCoursesGroups = [];
    	foreach ($coursesGroups as $courseGroup) {
    		if($courseGroup->course_id) {
    			$finalCoursesGroups[] = $courseGroup;
    		} else {
    			foreach ($courseGroup->relatedCoursesGroups() as $relatedCourseGroup) {
    				$finalCoursesGroups[] = $relatedCourseGroup;
    			};
    		}
    	}

    	return $finalCoursesGroups;
    }    

    public function courseGroupCourse() {
    	$relatedCoursesGroups = $this->relatedCoursesGroups();
    	if(count($relatedCoursesGroups)>0) {
    		$relatedCourseGroup = $relatedCoursesGroups[0];
    		if($relatedCourseGroup->course_id) return $relatedCourseGroup->course;
    	}
    	return null;
    }

	public function courseGroupName() {

    	$courseGroup = strtolower($this->course_group);
    	$plan = Plan::where('short_name', $courseGroup)->first();
    	if(	startsWith($courseGroup, 'university') || 
    		startsWith($courseGroup, 'faculty')) {
    		$name = ucwords($courseGroup)." Requirements Courses";
    	} else if($plan) {
    		$name = "$plan->en_minor Requirements Courses";
    	} else if(stristr($courseGroup, 'compulsory') && empty($this->course_index)) {
    		$name = ucwords($courseGroup)." Courses";
    	} else {
    		$name = ucwords($courseGroup)." Course";
    	}
		    	
    	if($this->course_modifier) $name .= ", Pool ".ucwords($this->course_modifier);
    	if($this->course_level) $name .= ", Level $this->course_level";
		if($this->course_index) $name .= " ($this->course_index)";

		return $name;
    }
}