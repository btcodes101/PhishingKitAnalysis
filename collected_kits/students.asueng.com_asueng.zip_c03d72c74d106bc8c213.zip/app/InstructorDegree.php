<?php

namespace App;

use App\BaseModel;

class InstructorDegree extends BaseModel
{

    protected $table = 'instructors_degrees';

    protected $guarded = [];

    public $timestamps = false;
}
