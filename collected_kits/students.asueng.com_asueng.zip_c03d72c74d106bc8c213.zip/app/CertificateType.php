<?php

namespace App;

use App\BaseModel;

class CertificateType extends BaseModel
{
    protected $table = 'certificates_types';

    const STUDY_TYPE_BOTH = 0;
    const STUDY_TYPE_CREDIT = 1;
    const STUDY_TYPE_TERMS = 2;
    
    const GENDER_FOR_BOTH = 0;
    const GENDER_FOR_MALE_ONLY = 1;
    const GENDER_FOR_FEMALE_ONLY = 2;

    const FIELDS_NONE = 0;
    const FIELDS_APPLY_TO = 1;
    const FIELDS_APPLY_TO_AND_DATES = 2;

    const GRADUATION_TYPE_NO = 0;
    const GRADUATION_TYPE_YES = 1;
    const GRADUATION_TYPE_BOTH = 2;
    const GRADUATION_TYPE_PREYES = 3;

    public static function fileTypes($from = 0) { //0=> both , 1=> internal , 2 => external
        
        $types =  [];

        if($from==0 || $from==1 || $from==2) {
            $types['national_id_img'] = (object)[ 'title' => __("tr.National ID or Passport Copy"), 'required' => true, 'for'=> 'both' ];
        }

        if($from==0 || $from==2) {
            $types['latest_certification_image'] = (object)[ 'title' => __("tr.Certificate Copy"), 'required' => false, 'for'=> 'both', 'note' => "Copy of any old certificate of any type." ];
        }

        return $types;
    }

}
