<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Log extends Model
{
    protected $table = "";

    public $timestamps = false;

    const TYPE_NORMAL = 1;
    const TYPE_ERROR = 2;
    const CAN_BE_VIEWED=1;
    const CAN_NOT_BE_VIEWED =0;

    const TYPE_ADD = 1;
    const TYPE_EDIT = 2;
    const TYPE_DELETE =3;
    const TYPE_VIEW = 4;
    const TYPE_LIST = 5;
    const TYPE_LOGIN = 6;
    const TYPE_LOGOUT =7;
    const TYPE_REGISTER = 8;
    const TYPE_APPLY =9;

    function __construct() {
        $this->table = env('DB_LOGS').'.logs';
    }

    public static function log($type, $model, $newData = null, $oldData = null) {
        if($oldData == null)
            $oldData = $model->getAttributes();
        
        $modelType = get_class($model);

        $modelID = $model->id;

        $description = "";

        switch ($modelType) {
            case 'App\Instructor':
            case 'App\Student':
                $user = $model->user;
                $code = $user->code;
                $name = $user->lang('name');
                $description = "$code: $name";
                break;
            case 'App\Employee':
            case 'App\User':
                $code = $model->code;
                $name = $model->lang('name');
                $description = "$code: $name";
                break;
            case 'App\Archive':
                $description = $model->name();
                break;
            case 'App\Study':
                $user = $model->user;
                $term = $model->committee->term;
                $course = $model->committee->course;
                $courseCode = $course->short_name;
                $termName = $term->lang('name');
                $userCode = $user->code;
                $userName = $user->lang('name');
                $description = "$userCode: $userName, $courseCode, $termName";
                break;
        }

        if($newData==="new") {
            $newData = $oldData;
            $oldData = ["data"=>"none"];
        }

        return Log::add($type, $modelType, $modelID, $description, $oldData, $newData);
    }

    public static function add($type, $modelType, $modelId, $description, $oldData = null, $newData = null) {

        if(!empty($oldData)) {
            $oldData = json_encode($oldData);
        }

        if(!empty($newData)) {
            $newData = json_encode($newData);
        }

        $log = new Log();
        $log->user_id = auth()->id();
        $log->type = $type;
        $log->description = $description;
        $log->url = request()->path();
        $log->old_data = $oldData;
        $log->new_data = $newData;
        $log->model_type = $modelType;
        $log->model_id = $modelId;
        $log->save();
    }

    public function user(){
        return $this->belongsTo('App\User','user_id','id');
    }

    public function resolve() {
        switch ($this->model_type) {
            case 'App\Instructor':
            case 'App\Student':
            case 'App\Employee':
            case 'App\User':
                return route('show_profile', ['id'=>$this->model_id]);
            break;
        }

        return route('show_log', ['id'=>$this->id]);
    }

    public static function dashReport() {
        $report = (object)[];
        $date = Carbon::now()->subYears(1);
        $report->monthlyCount = [];
        $average = 0;
        for($i=0; $i<12; $i++) {
            $start = $date->copy();
            $average += $report->monthlyCount[] = Log::where('created_at', '>', $start)->where('created_at', '<', $date->addMonths(1))->count();
        }
        $average /= 12;
        if($average>0)
            $report->change = 100 * ($report->monthlyCount[11]-$average)/$average;
        else
            $report->change = 0;
        if($report->change<1)
            $report->change = 0;
        $report->changeLabel = number_format($report->change, 1)."%";
        
        $report->plot = "";
        if($average>0) {
            for($i=0;$i<12;$i++) {
                $count = $report->monthlyCount[$i];
                $report->plot .= "".($i*10)." ".(30-15*$count/$average)." ";
                $report->monthlyCount[] = $count;
            }
        }

        $report->activeCount = $report->monthlyCount[11];

        return $report;
    }
}
