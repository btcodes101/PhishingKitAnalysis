<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TuitionFeeExemption extends Model
{
    protected $table = 'tuition_fees_exemption';
}
