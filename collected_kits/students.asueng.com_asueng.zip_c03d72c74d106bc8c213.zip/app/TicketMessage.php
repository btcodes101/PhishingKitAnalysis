<?php

namespace App;

use App\ProjectStatus;
use Illuminate\Database\Eloquent\Model;

class TicketMessage extends Model
{
    protected $table = 'tickets_messages';

    public function ticket(){
        return $this->belongsTo('App\Ticket');
    }

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function files(){
        return $this->hasMany('App\Archive', 'parent_id', 'archive_id')->orderBy('order', 'asc')->orderBy('id', 'asc');
    }

    public function createdFrom() {

        $created = strtotime($this->created_at);
        $today = strtotime(date('Y-m-d H:i:s'));
        $time_differnce = $today-$created;
        $years = 60*60*24*365;
        $months = 60*60*24*30;
        $days = 60*60*24;
        $hours = 60*60;
        $minutes = 60;
        if(intval($time_differnce/$years) > 1) {
            return intval($time_differnce/$years)." years ago";
        } else if(intval($time_differnce/$years) > 0) {
            return intval($time_differnce/$years)." year ago";
        } else if(intval($time_differnce/$months) > 1) {
            return intval($time_differnce/$months)." months ago";
        } else if(intval(($time_differnce/$months)) > 0) {
            return intval(($time_differnce/$months))." month ago";
        } else if(intval(($time_differnce/$days)) > 1) {
            return intval(($time_differnce/$days))." days ago";
        } else if (intval(($time_differnce/$days)) > 0) {
            return intval(($time_differnce/$days))." day ago";
        } else if (intval(($time_differnce/$hours)) > 1) {
            return intval(($time_differnce/$hours))." hours ago";
        } else if (intval(($time_differnce/$hours)) > 0) {
            return intval(($time_differnce/$hours))." hour ago";
        } else if (intval(($time_differnce/$minutes)) > 1) {
            return intval(($time_differnce/$minutes))." minutes ago";
        } else if (intval(($time_differnce/$minutes)) > 0) {
            return intval(($time_differnce/$minutes))." minute ago";
        } else if (intval(($time_differnce)) > 1) {
            return intval(($time_differnce))." seconds ago";
        } else {
            return "few seconds ago";
        }
    }

    public function decision() {
        switch ($this->pi_status) {
            case ProjectStatus::STATUS_REJECTED: return "Reject";
            case ProjectStatus::STATUS_ACCEPTED: return "Accept";
            case ProjectStatus::STATUS_CONDITIONALLY_ACCEPTED: return "Conditionally Accept";
            case ProjectStatus::STATUS_AMENDMENT_REQUIRED: return "Amendment Required";
        }
        return "";
    }

    public function echo() {
        
        switch($this->ticket->ticket_type_id) {
            case 9: {
                if($this->ticket->applicant) {
                    $this->ticket->applicant->notify($this->comment, $this->files);
                }
            } break;
            case 11: {
                if($this->ticket->user) {
                    $student = $this->ticket->user->student;
                    $student->status = Student::STATUS_ACADEMIC_REQUEST;
                    $student->save();
                }
            } break;
            case 12: { // Login Issues
                /*$link = URL::to('/tickets/external/').encryptData($ticket->id,env("WEBSITE_SHARED_KEY", null));
                $parameters = json_decode($this->ticket->description, true);

                $title = "ASUENG - SIS Request Login";                    
                $systemMail = new SystemMail("application_feedback", ['title'=>$title, 'values' => ['feedback_message' => $this->comment,'update_link' => $link]]);
                $systemMail->submit($parameters->email, false, Setting::value("email"), [], false);*/
            } break;
        }
    }
}