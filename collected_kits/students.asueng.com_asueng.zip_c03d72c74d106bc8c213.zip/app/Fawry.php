<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fawry extends Model
{
    protected $table = "fawry";
}
