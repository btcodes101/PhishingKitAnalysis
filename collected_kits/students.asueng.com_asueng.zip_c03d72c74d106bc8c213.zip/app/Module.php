<?php

namespace App;

use App\ModuleSample;
use BaseModel\Model;

class Module extends BaseModel
{
    protected $table = 'modules';

    public function courses() {
        return $this->belongsToMany( 'App\Course', 'modules_courses', 'module_id', 'course_id')->orderBY('courses.bylaw')->orderBY('courses.short_name');
    }

    public function mainCourses() {
        return $this->belongsToMany( 'App\Course', 'modules_courses', 'module_id', 'course_id')->orderBY('courses.bylaw')->orderBY('courses.short_name');
    }

    public function coursesGroupedByBylaw($termYear) {

        $plansIDs = $this->externalProgram->plans()->pluck('plans.id')->toArray();

        $mainCoursesIDs = $this->mainCourses()->pluck('courses.id');

        $all = Course::select('courses.id as course_id', 'courses.short_name as course_code', 'courses.bylaw as course_bylaw', 'courses.en_name as course_name', 'plans.short_name as plan_code', 'committees.id as committee_id', 'committees.term_id as term_id', 'terms.en_name as term_name')
        ->where(function($query) use($mainCoursesIDs) {
            $query->orWhereIn('courses.id', $mainCoursesIDs);
            $query->orWhereIn('courses.base_course_id', $mainCoursesIDs);
        })
        ->where('courses.active', 1)
        ->join('committees', function($join) {
            $join->on('committees.course_id', 'courses.id');
            $join->where('committees.type', Committee::TYPE_CHEP);
        })
        ->join('terms', 'terms.id', 'committees.term_id')
        ->leftJoin('plans', 'plans.id', 'courses.plan_id')
        ->where(function($query) use($termYear) {
            
            $query->orWhere(function($query) use($termYear) {
                $query->where('terms.term_year', $termYear);
                $query->where('terms.short_name', 'NOT LIKE', 'M%');
            });

            $query->orWhere(function($query) use($termYear) {
                $query->where('terms.term_year', $termYear-1);
                $query->where('terms.short_name', 'LIKE', 'M%');
            });

        })
        ->orderBY('courses.id')
        ->get();

        $committees = [];
        foreach ($all as $committee){
            $tempCommittee = Committee::find($committee->committee_id);
            $committeesPlansIDs = $tempCommittee->plans()->pluck('committees_plans.plan_id')->toArray();
            if(count($committeesPlansIDs)>0) {
                $modulePlansIDs = array_intersect($committeesPlansIDs, $plansIDs);
                if(count($modulePlansIDs)==0) continue;
            }
            $committees[$committee->course_bylaw][] = $committee;
        }
        foreach ($committees as $key => $list){
            if(count($list)==0) unset($committees[$key]);
        }

        return $committees;
    }

    public function externalProgram(){
        return $this->belongsTo('App\ExternalProgram');
    }

    public function moduleCommittee(){
        return $this->hasMany('App\ModuleCourse');
    }

    public function term(){
        return $this->belongsTo('App\Term');
    }

    public function folder($type, $termYears, $studentCode = null) {

        $folder = "External Programs/East London/Academic Year $termYears/".$this->externalProgram->code;
        if($type=="specifications")
            $path = "$folder/$this->code/01 Module Specifications";
        else if($type=="assessment")
            $path = "$folder/$this->code/02 Assessment Specification";
        else if($type=="samples")
            $path = "$folder/$this->code/03 Students' Samples";
        else if($type=="activities")
            $path = "$folder/$this->code/03 Students' Samples/$studentCode/Activities";
        else if($type=="answer_sheet")
            $path = "$folder/$this->code/03 Students' Samples/$studentCode/Answer Sheet";
        else if($type=="results")
            $path = "$folder/$this->code/04 Module Results and Review";

        return Archive::get($path);
    }

    public function data($term) {
        
        $data = (object)[];

        $thisCoursesIDs = $this->courses()->pluck('courses.id')->toArray();
        
        $instructorCoursesIDs = CommitteeInstructor::join('committees', 'committees.id', 'committees_instructors.committee_id')
        ->join('terms', 'terms.id', 'committees.term_id')
        ->where('committees_instructors.instructor_id', auth()->id())
        ->where('committees_instructors.role', Study::ROLE_TEACHER)
        ->where('terms.years', $term->years)
        ->pluck('committees.course_id')
        ->toArray();        

        $year = $term->shortYear();
        if($term->isSummer()) $year++;
        $data->termYears = ($year)."-".($year+1);

        $data->specifications = $this->folder("specifications", $data->termYears);
        $data->assessment = $this->folder("assessment", $data->termYears);
        $data->samples = $this->folder("samples", $data->termYears);
        $data->results = $this->folder("results", $data->termYears);
        $data->courses = $this->coursesGroupedByBylaw($term->term_year);
        
        $data->canAdmin = auth()->user()->hasPermissionTo('admin_external_programs');
        $data->canEdit = $data->canAdmin || array_intersect($instructorCoursesIDs, $thisCoursesIDs);
        $data->canView = (auth()->user()->hasPermissionTo('operate_external_programs') || auth()->user()->hasPermissionTo('show_external_programs'));

        if($data->canEdit) {
            $data->assessment->setTempOwner();
            $data->samples->setTempOwner();
        }

        if($data->canAdmin) {
            $data->specifications->setTempOwner();
            $data->results->setTempOwner();
        }

        return $data;
    }

    public function genFileName($type, $term = null, $courseCode = null, $studentCode = null) {

        $termLetter = substr($term->short_name, 0, 1);
        $termNumber = 0;
        if($termLetter=="F")$termNumber = 2;
        else if($termLetter=="S")$termNumber = 3;
        else if($termLetter=="M")$termNumber = 1;

        $year = $term->shortYear();
        $years = ($year)."_".($year+1);
        
        if($type=="specifications")
            return $this->code."_".$courseCode;        
        else if($type=="assessment")
            return $this->code."_".$courseCode."_".$term->en_name;
        else if($type=="results")
            return $this->code."_Results";
        else if($type=="activities")
            return $studentCode."_".$this->externalProgram->num."_".$courseCode."_".$year."_".$termNumber;
        else if($type=="answer_sheet")
            return $studentCode."_".$this->externalProgram->num."_".$courseCode."_".$year."_".$termNumber."_FE";

        return "";
    }

    public function sample($termID, $courseID, $studentID) {
        
        $moduleSample = ModuleSample::where('module_id', $this->id)
        ->where('term_id', $termID)
        ->where('student_id', $studentID)
        ->where('course_id', $courseID)
        ->first();

        if(empty($moduleSample)) {
            $moduleSample = new ModuleSample();
            $moduleSample->status = 0;
            $moduleSample->module_id = $this->id;
            $moduleSample->term_id = $termID;
            $moduleSample->course_id = $courseID;
            $moduleSample->student_id = $studentID;
            $moduleSample->save();
        }

        return $moduleSample;
    }
}
