<?php

namespace App;

use App\BaseModel;

class InstructorStatus extends BaseModel {

    protected $table = 'instructors_status';
    public   $timestamps = false;
}
