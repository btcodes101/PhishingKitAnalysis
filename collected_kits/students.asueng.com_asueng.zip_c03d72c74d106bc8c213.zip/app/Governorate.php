<?php

namespace App;

use App\BaseModel;

class Governorate extends BaseModel
{
  protected $table = 'governorates';
  protected $casts = ['id' =>'string'];
}
