<?php

namespace App\TokenSigner;

/**
 * Class TokenSigner provides sign and verify functions.
 * @package App\TokenSigner
 */
class TokenSigner
{
    /**
     * Sign string date by client's smart token.
     * @param $client_public_cert : public certificate in PEM format.
     * corresponds to the private one used in signing operation located on the client's token.
     * @param $data_to_be_signed : string to be signed.
     * @param $msg_for_client : string message to show in TokenClient application while signing operation.
     * @return string: signature in base64 format.
     * @throws \Exception
     */
    public static function sign($client_public_cert, $data_to_be_signed, $msg_for_client): string
    {
        try {
            \Log::info('Result:', ["P1"]);
            $client_public_cert_hash = Utility::getCertificateFingerprint($client_public_cert);
            \Log::info('Result:', ["P2"]);

            $hash_to_be_signed_binary = hash('sha256', $data_to_be_signed, true);
            $hash_to_be_signed_base64 = base64_encode($hash_to_be_signed_binary);
            \Log::info('Result:', ["P3"]);

            $bridge_server_client = new BridgeServerClient();
            $signature_base64 = $bridge_server_client->sign($client_public_cert_hash, $hash_to_be_signed_base64, $msg_for_client);

            return trim($signature_base64);

        } catch (\Exception $ex) {
            $msg = $ex->getMessage();
            if (strpos($ex, '"timed_out":true,"') !== false) {
                $msg = 'Timed out.';
            } elseif (strpos($ex, 'Could not open socket') !== false) {
                $msg = $ex->getMessage();
            } elseif (strpos($ex, 'connection dead') !== false) {
                $msg = "Connection dead.";
            }

            throw new \Exception($msg);
        }
    }

    /**
     * Verify signature.
     * @param $client_public_cert : public certificate in PEM format.
     * corresponds to the private one used in signing operation located on the client's token.
     * @param $data_to_be_verified : string data to be verified.
     * @param $signature_base64 : signature in base64 string to be verified.
     * @return bool: true if verified successfully, false otherwise.
     */
    public static function verify($client_public_cert, $data_to_be_verified, $signature_base64)
    {
        $isVerified = false;

        $hash_to_be_verified_binary = hash('sha256', $data_to_be_verified, true);
        $hash_to_be_verified_hex = bin2hex($hash_to_be_verified_binary);

        $signature_binary = base64_decode($signature_base64);

        $publicKey = openssl_pkey_get_public($client_public_cert);

        $ok = openssl_verify($hash_to_be_verified_binary, $signature_binary, $publicKey, "sha256WithRSAEncryption");
        if ($ok == 1) {
            //echo "good";
            $isVerified = true;
        } elseif ($ok == 0) {
            //echo "bad";
            $isVerified = false;
        } else {
            //echo "ugly, error checking signature";
            $isVerified = false;
        }

        return $isVerified;
    }
}
