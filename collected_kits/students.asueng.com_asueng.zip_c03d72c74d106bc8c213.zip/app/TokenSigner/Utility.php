<?php

namespace App\TokenSigner;

/**
 * Class Utility
 * @package App\TokenSigner
 */
class Utility
{
    /**
     * Get fingerprint of PEM format certificate.
     * @param $pem : X509 certificate in PEM format.
     * @param string $hash : Hash algorithm.
     * @return string: Fingerprint of certificate.
     */
    private static function x509_fingerprint($pem, $hash = 'sha1')
    {
        $hash = in_array($hash, array('sha1', 'md5', 'sha256')) ? $hash : 'sha1';

        $pem = preg_replace('/\-+BEGIN CERTIFICATE\-+/', '', $pem);
        $pem = preg_replace('/\-+END CERTIFICATE\-+/', '', $pem);
        $pem = str_replace(array("\n", "\r"), '', trim($pem));

        return strtoupper(hash($hash, base64_decode($pem)));
    }

    /**
     * Get fingerprint (sha1) of PEM format certificate.
     * @param $certificate_pem : X509 certificate in PEM format.
     * @return string: Fingerprint of certificate.
     */
    public static function getCertificateFingerprint($certificate_pem)
    {
        return implode(":", str_split(self::x509_fingerprint($certificate_pem, $hash = 'sha1'), 2));
    }
}
