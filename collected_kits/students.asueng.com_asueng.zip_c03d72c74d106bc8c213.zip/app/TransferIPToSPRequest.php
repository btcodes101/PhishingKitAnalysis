<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransferIPToSPRequest extends Model
{
    protected $table = 'transfer_ip_to_sp_requests';
    protected $fillable = ['student_id', 'year', 'status'];
 
    const STATUS_IN_PROGRESS = 1;

    const STATUS_ACCEPTED_BY_STUDENTS_AFFAIRS = 2;
    const STATUS_REJECTED_BY_STUDENTS_AFFAIRS = 3;

    const STATUS_ACCEPTED_BY_STUDENTS_AFFAIRS_DIRECTOR = 4;
    const STATUS_REJECTED_BY_STUDENTS_AFFAIRS_DIRECTOR = 5;

   
    const STATUS_ACCEPTED_BY_VICE_DEANS_STUDENTS_AFFAIRS_DIRECTOR = 6;
    const STATUS_REJECTED_BY_VICE_DEANS_AFFAIRS_DIRECTOR = 7;


    public static function statusLabels() {
        return [
            TransferIPToSPRequest::STATUS_IN_PROGRESS => __('tr.In Progress'),

            TransferIPToSPRequest::STATUS_ACCEPTED_BY_STUDENTS_AFFAIRS => __('tr.Accepted by the Students Affairs'),
            TransferIPToSPRequest::STATUS_REJECTED_BY_STUDENTS_AFFAIRS => __('tr.Rejected by the Students Affairs'),

            TransferIPToSPRequest::STATUS_ACCEPTED_BY_STUDENTS_AFFAIRS_DIRECTOR => __('tr.Accepted by Students Affairs Director'),
            TransferIPToSPRequest::STATUS_REJECTED_BY_STUDENTS_AFFAIRS_DIRECTOR => __('tr.Rejected by Students Affairs Director'),

            TransferIPToSPRequest::STATUS_ACCEPTED_BY_VICE_DEANS_STUDENTS_AFFAIRS_DIRECTOR => __('tr.Accepted by Vice Deans for Education and Students Affairs'),
            TransferIPToSPRequest::STATUS_REJECTED_BY_VICE_DEANS_AFFAIRS_DIRECTOR => __('tr.Rejected by Vice Deans for Education and Students Affairs')
        ];
    }


    public static function statusBadges() {
        return [
            TransferIPToSPRequest::STATUS_IN_PROGRESS => 'light',

            TransferIPToSPRequest::STATUS_ACCEPTED_BY_STUDENTS_AFFAIRS => 'secondary',
            TransferIPToSPRequest::STATUS_REJECTED_BY_STUDENTS_AFFAIRS => 'danger',
            
            TransferIPToSPRequest::STATUS_ACCEPTED_BY_STUDENTS_AFFAIRS_DIRECTOR => 'primary',
            TransferIPToSPRequest::STATUS_REJECTED_BY_STUDENTS_AFFAIRS_DIRECTOR => 'danger',
            
            TransferIPToSPRequest::STATUS_ACCEPTED_BY_VICE_DEANS_STUDENTS_AFFAIRS_DIRECTOR => 'success',
            TransferIPToSPRequest::STATUS_REJECTED_BY_VICE_DEANS_AFFAIRS_DIRECTOR => 'danger' 
        ];
    }

    
 
 

}
