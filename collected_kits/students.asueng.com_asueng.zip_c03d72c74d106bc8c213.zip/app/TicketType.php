<?php

namespace App;

use App\BaseModel;

class TicketType extends BaseModel {

	protected $table = 'tickets_types';
    public   $timestamps = false;

}
