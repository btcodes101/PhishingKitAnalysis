<?php

namespace App;

use BaseModel\Model;

class TermPlan extends BaseModel
{
    protected $table = 'terms_plans';
    protected $guarded = [];
    public $timestamps = false;
}
