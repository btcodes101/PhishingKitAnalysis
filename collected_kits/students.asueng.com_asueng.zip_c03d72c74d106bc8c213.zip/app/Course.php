<?php

namespace App;

use App\BaseModel;

function addDegreeData(&$degreesData, $field, $label, $shortLabel, $maxValue, $affectTotal, $exam) {
    $degreeLabel = (object)[];
    $degreeLabel->field = $field;
    $degreeLabel->label = $label;
    $degreeLabel->short_label = $shortLabel;
    $degreeLabel->excelLabel = strtolower(str_replace(" ", "_", $label));
    $degreeLabel->max_value = (int)$maxValue;
    $degreeLabel->affect_total = $affectTotal;
    $degreeLabel->exam = $exam;
    $degreesData[$degreeLabel->field] = $degreeLabel;
}   

class Course extends BaseModel
{
    const CLASSIFICATION_DR = 0x00000001;
    const CLASSIFICATION_FR = 0x00000002;
    const CLASSIFICATION_PR = 0x00000004;
    const CLASSIFICATION_UR = 0x00000008;

    protected $fillable = [
        'en_name',
        'ar_name',
        'code', 
        'offering_department_id', 
        'plan_id',
        'bylaw',
        'term_type',
        'max_first_work',
        'max_first_oral',
        'max_first_exam',
        'max_final_work',
        'max_final_oral',
        'max_final_exam',
        'max_total',
        'credit_hours',
        'first_lecture',
        'first_tutorial',
        'first_laboratory',
        'final_lecture',
        'final_tutorial',
        'final_laboratory',
        'en_describtion',
        'ar_describtion',
        'edit_status',
        'references'
    ];

    public function plan()
    {
        return $this->belongsTo('App\Plan');
    }

    public function department(){
        return $this->belongsTo('App\Department','offering_department_id','id');
    }

    public function electiveParent(){
        return $this->belongsTo('App\Course','elective_course_id','id');
    }

    public function electiveChildren(){
        return $this->hasMany('App\Course', 'elective_course_id','id');
    }

    public function getBylaw(){
        return $this->belongsTo('App\Bylaw','bylaw','code');
    }

    public function courseUser(){
        return $this->hasMany('App\CourseUser');
    }

    public function describtion(){
        if (\App::isLocale('en')) {
            return $this->en_describtion;
        } else {
            return $this->ar_describtion;
        }
    }

    public function termType() {
        switch ($this->term_type) {
            case 1: return __('tr.FirstTerm');
            case 2: return __('tr.SecondTerm');
            case 3: return __('tr.Continuous');
        }

        return "";
    }

    public function allReferences() {
        return explode("\n", $this->references);
    }

    public static function termTypes(){
        return [
            0 => "Single (Credit Hours)",
            1 => "First Term",
            2 => "Second Term",
            3 => "Continous",
        ];
    }

    public static function editStatusLabels(){
        return [
            0 => "Draft",
            1 => "Updated",
            2 => "Reviewed",
            3 => "Approved",
        ];
    }

    public function editStatusLabel(){
        return Course::editStatusLabels()[$this->edit_status];
    }

    public function qualityTasks()
    {
        return $this->hasMany('App\QuestionnaireTask');
    }

    public function updateFTS() {
        $text = "$this->id, $this->en_name, $this->ar_name";
        $this->ar_code = $this->code;
        if($this->department){
            $this->ar_code = str_replace($this->department->code, $this->department->ar_code, $this->ar_code);
        }
        $text = getFTS($text).", $this->bylaw, $this->code, $this->ar_code";
        $this->search_text = $text;
        $this->save();
    }

    public function isOfferedByMultipleDepartments() {
        return (strpos(strtoupper($this->code), "HUMX")!==false);
    }

    public function weeks() {
        if($this->term_type==3)
            return 28;
        return 14;
    }

    public function lecture() {
        return $this->first_lecture + $this->final_lecture;
    }

    public function tutorial() {
        return $this->first_tutorial + $this->final_tutorial;
    }

    public function laboratory() {
        return $this->first_laboratory + $this->final_laboratory;
    }

    public function getCode() {
        if(lang()=="ar")
            return $this->ar_code;

        return $this->code;
    }

    public static $cashedCoursesByID = [];
    public static function getCashedByID($id) {
        
        $key = $id;
        if(array_key_exists($key, Course::$cashedCoursesByID))
            return Course::$cashedCoursesByID[$key];

        $course = Course::find($id);

        Course::$cashedCoursesByID[$key] = $course;

        return $course;
    }

    public static $cashedCoursesByCode = [];
    public static function getCashed($bylaw, $code) {
        
        $key = "$bylaw-$code";
        if(array_key_exists($key, Course::$cashedCoursesByCode))
            return Course::$cashedCoursesByCode[$key];

        $course = Course::where('bylaw', $bylaw)->where('code', $code)->where('current', 1)->first();

        Course::$cashedCoursesByCode[$key] = $course;

        return $course;
    }

    public static $oldCashedCourses = [];
    public static function getOLDCashed($bylaw, $oldDepartmentID, $oldCode) {
        
        $key = "$bylaw:$oldDepartmentID:$oldCode";
        if(array_key_exists($key, Course::$oldCashedCourses))
            return Course::$oldCashedCourses[$key];

        $department = Department::select('code')->where('old_id', $oldDepartmentID)->first();
        $code = "$department->code$oldCode";

        $course = Course::where('bylaw', $bylaw)->where('code', $code)->where('current', 1)->first();

        Course::$oldCashedCourses[$key] = $course;

        return $course;
    }

    public function isCreditHours() {
        if($this->getBylaw->credit_hours==1)
            return true;

        return false;
    }

    public static function search($shortName, $bylaw) {
        return Course::where('short_name', $shortName)->where('bylaw', $bylaw)->where('current', 1)->where('active', 1)->first();
    }

    public function getDegreesData($showExams, $maxFirstMcqExam, $maxFinalMcqExam) {

        $first = $final = '';
        $firstShort = $finalShort = '';
        if($this->term_type == 3) {
            $first = "First ";
            $final = "Final ";
            $firstShort = "1";
            $finalShort = "2";
        }

        $degreesData = [];

        if ($this->max_first_work>0) {
            addDegreeData($degreesData, 'first_work', $first."Work", "W".$firstShort, $this->max_first_work, true, false);
        }

        if ($this->max_midterm>0 || $this->max_activities>0 || $this->max_practical>0) {
            
            if ($this->max_midterm>0) {
                addDegreeData($degreesData, 'midterm', "Midterm", "MT", $this->max_midterm, true, false);
            }

            if ($this->max_activities>0) {
                addDegreeData($degreesData, 'activities', "Activities", "SA", $this->max_activities, true, false);
            }

        } 
        else if ($this->max_final_work>0 ) {
            addDegreeData($degreesData, 'final_work', $final."Work", "W".$finalShort, $this->max_final_work, true, false);
        }

        if($showExams) {

            if ($this->max_practical>0) {
                addDegreeData($degreesData, 'practical', "Practical", "PE", $this->max_practical, true, false);
            }

            if ($this->max_first_oral>0) {
                addDegreeData($degreesData, 'first_oral', $first."Oral", "O".$firstShort, $this->max_first_oral, true, false);
            }

            if ($this->max_final_oral>0) {
                addDegreeData($degreesData, 'final_oral', $final."Oral", "O".$finalShort, $this->max_final_oral, true, false);
            }

            if ($maxFirstMcqExam>0) {
                addDegreeData($degreesData, 'first_mcq_exam', $first."MCQ Exam", "MCQ".$firstShort, $maxFirstMcqExam, true, true);
            }

            if ($maxFinalMcqExam>0) {
                addDegreeData($degreesData, 'final_mcq_exam', $final."MCQ Exam", "MCQ".$finalShort, $maxFinalMcqExam, true, true);
            }

            if (($this->max_first_exam-$maxFirstMcqExam)>0) {
                addDegreeData($degreesData, 'first_exam', $first."Exam", "E".$firstShort, $this->max_first_exam-$maxFirstMcqExam, true, true);
            }

            if (($this->max_final_exam-$maxFinalMcqExam)>0) {
                addDegreeData($degreesData, 'final_exam', $final."Exam", "E".$finalShort, $this->max_final_exam-$maxFinalMcqExam, true, true);
            }
        }

        return $degreesData;
    }

    public function generateGradesCards(){
        
        $grades = [];
        
        $student = auth()->user()->student;
        $term = Setting::currentTerm();

        $study = Study::select('studies.*')->join('courses','courses.id','=','studies.course_id')
        ->where('studies.term_id', $term->id)
        ->where('studies.course_id', $this->id)
        ->where('studies.user_id', $student->id)
        ->get()
        ->first();

        $first = $final = "";
        if($this->term_type==3) {
            $first = "First ";
            $final = "Final ";
        }

        $fields = ['midterm' => 'Midterm', 'activities'=>'Activities', 'practical'=>'Practical', 'first_work'=>$first.'Work', 'final_work'=>$final.'Work', 'first_oral'=>$first.'Oral', 'final_oral'=>$final.'Oral'];
        $grades = [];
        foreach ($fields as $field=>$label) {
            if(!empty($this->{'max_'.$field})) {
                $grade = (object)[];
                $grade->label = $label;
                $grade->value = $study->{$field};
                $grade->max = $this->{'max_'.$field};
                $grades[] = $grade;
            }
        }

        return $grades;
    }

    public function isCorona() {
        return startsWith($this->short_name, "CRN");
    }

    public function plainCode() {
        return rtrim($this->short_name, "s");
    }

    public function coursePlans() {
        return $this->hasMany('App\CoursePlan', 'course_id', 'id');
    }

    public function group() {
        return $this->hasMany('App\CourseGroup', 'course_id', 'id');
    }

    public function planGroupName($programName=null) {
        if(empty($programName) && $this->classification&Course::CLASSIFICATION_UR) $programName = 'university';
        else if(empty($programName) && $this->classification&Course::CLASSIFICATION_FR) $programName = 'faculty';
        else if(empty($programName)) return "";
        $group =  $this->group()->where('program', $programName)->first();
        if($group && $group->group_name!='root') return $group->course_group;
        return "";
    }

    public function isUR() {
        return ($this->classification&Course::CLASSIFICATION_UR)!=0;
    }

    public function isFR() {
        return ($this->classification&Course::CLASSIFICATION_FR)!=0;
    }

    public function isPR() {
        return ($this->classification&Course::CLASSIFICATION_PR)!=0;
    }

    public function isDR() {
        return ($this->classification&Course::CLASSIFICATION_DR)!=0;
    }

    public function classificationsText() {
        $text = "";
        if($this->classification&Course::CLASSIFICATION_UR) {
            if(!empty($text)) $text .= ",";
            $text .= "University Requirement";
        }
        if($this->classification&Course::CLASSIFICATION_FR) {
            if(!empty($text)) $text .= ",";
            $text .= "Faculty Requirement";
        }
        if($this->classification&Course::CLASSIFICATION_DR) {
            if(!empty($text)) $text .= ",";
            $text .= "Discipline Requirement";
        }
        if($this->classification&Course::CLASSIFICATION_PR) {
            if(!empty($text)) $text .= ",";
            $text .= "Program Requirement";
        }

        return $text;
    }

    public function totalHours() {
        $total = intval($this->final_lecture);
        $total += intval($this->final_tutorial);
        $total += intval($this->final_laboratory);
        return $total;
    }
}