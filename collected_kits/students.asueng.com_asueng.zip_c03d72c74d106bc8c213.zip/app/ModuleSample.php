<?php

namespace App;

use BaseModel\Model;

class ModuleSample extends BaseModel
{
    protected $table = 'modules_samples';
    protected $guarded = [];
    public $timestamps = false;

    const STATUS_SHOW		= 0x00000001;
    const STATUS_ACCEPTED	= 0x00000002;
    const STATUS_REJECTED	= 0x00000004;
}
