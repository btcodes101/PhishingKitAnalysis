<?php

namespace App\Http\Middleware;

use Closure;
use  App\Http\Controllers\StudentsPaymentsController;
use  App\Http\Controllers\PaymentsController;

class checkStdPaymentStatus
{
    //use StudentsPaymentsController;
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {  
        $studentsPaymentsOBJ = new PaymentsController();

        $user = \Auth::user();

        if(!$user){
            return $next($request);
        }elseif(isset($user->student) && ($user->student->isGraduated() || $user->student->isPostgraduate())){
            return $next($request);
        }elseif($studentsPaymentsOBJ->checkStdPaymentStatus()){
            return $next($request);
        }else{
           

            if($request->ajax()){
                return response()->json(['state' => 'error','msg' => __('tr.You cannot use this service, unless you pay the tuition fees.')], 200);
            }

            session()->push('alert', __('tr.You cannot use this service, unless you pay the tuition fees.'));
            return redirect()->route('student_fees');
        }
        
        
       
    }
}
