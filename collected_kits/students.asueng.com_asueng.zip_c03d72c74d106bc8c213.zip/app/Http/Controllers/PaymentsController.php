<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Spatie\Permission\Models\Role;
use Carbon\Carbon;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Session;
use App\Student;
use App\UserRequest;
use App\Term;
use App\Archive;
use App\TermStage;
use App\StudentFee;
use App\StudentCredit;
use App\Service;
use App\Log;
use Auth;
use Validator;
use DB;

class PaymentsController extends Controller
{

    use ResponseTrait;

    public function __construct(){

        $this->middleware('auth')->except([]);
    }

    public function payWithStudentCredit(UserRequest $userRequest) {
        
        $student = Auth::user()->student;
        if(!$student)
            abort(404);

        if($student->id != $userRequest->user_id)
            abort(401);

        if($student->financialCredit() < $userRequest->total_amount){
            return response()->json([
                'state' => 'Error',
                'msg' => 'Your Credit Is Not enough !'
            ], 200); 
        }

        $userRequest->order_status= "PAID";
        $userRequest->updated_by = $student->id;
        $userRequest->payment_provider = "credit";
        $userRequest->paid_amount = $userRequest->total_amount;
        $userRequest->save();

        $userRequest->apply();

        Log::log("Std Credit Pay", $student, $userRequest);

        $studentCredit = new StudentCredit();
        $studentCredit->student_id = $student->id;
        $studentCredit->request_id = $userRequest->id;
        $studentCredit->type = StudentCredit::TYPE_WITHDRAW;
        $studentCredit->amount = $userRequest->total_amount;
        $studentCredit->notes = str_replace ('_', ' ', $userRequest->type);
        $studentCredit->created_by = $student->id;
        $studentCredit->save();

        return response()->json([
            'state' => 'accepted',
            'msg' => 'Your request has been completed successfully.'
        ], 200);
    }

    public function payStudentFee(Request $request) {

        $total_amount = 0;
        
        $studentFee = StudentFee::find($request->studentPaymentId);

        $requestData=(object)[];
        $requestData->term_id = $studentFee->term_id;
        $requestData->term_name = Term::find($studentFee->term_id)->en_name;
        $requestData->notes = $studentFee->notes;

        

        $userRequest = new UserRequest();
        $userRequest->user_id = auth()->id();
        $userRequest->type = $studentFee->service->type;
        $userRequest->target_id = $request->studentPaymentId;
        $userRequest->created_at = Carbon::now();
        $userRequest->target_id = $request->studentPaymentId;
        $userRequest->data = json_encode($requestData);
        $userRequest->save();
        $userRequest->refresh();
        
        //generate the merchantRefNo
        $merchantRefNo = $userRequest->id.'_'.time(). '@stdfees';

        $total_amount= $request->total_amount;
        //dd($userRequest);
        $session_id =  $this->createCheckoutSession($merchantRefNo, $userRequest);    
        $userRequest->session_id = $session_id;

        //for bank misr pay with Meeza Card transactions only
        $meeza_msg_signature =  $this->createMsgSignature($total_amount, $userRequest->created_at);
        $userRequest->meeza_msg_signature = $meeza_msg_signature;

        $userRequest->total_amount = $total_amount; //$student_payments->total_amount;
        $userRequest->merchant_reference_no = $merchantRefNo;
        $userRequest->payment_provider = '';
        $userRequest->order_status = 'INCOMPLETE';
        $userRequest->save();

        $userRequest->refresh();
        if(empty($userRequest->archive_id)) {
            $archive = Archive::get("users_requests/$userRequest->id");
            $userRequest->archive_id = $archive->id;
            $userRequest->save();
            $userRequest->refresh();
        }
          
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];
        
        return redirect()->route('student_payment_confirmation', ['id' => $userRequest->id])->with( ['total_credit' => $request->total_credit] );
    }

    public function checkStdPaymentStatus(){   
 
        $unPaidFees = $this->unPaidFees();

        if($unPaidFees == true) 
            return false;

        return true;
    }

    public function unPaidFees(){
        
        $student = Auth::user()->student;
         
        $lang = lang();  
        $query = StudentFee::select('students_fees.amount')
        ->join('users', 'users.id', 'students_fees.student_id')
        ->leftjoin('takaful_requests',  function($join) {
            $join->on('takaful_requests.student_id', 'students_fees.student_id');
            $join->on('takaful_requests.term_id', 'students_fees.term_id');
            $join->where('students_fees.first', 1);
            $join->where('takaful_requests.status', 2);
        })
        ->leftJoin('services', 'services.id', 'students_fees.service_id')
        ->leftjoin('users_requests', function($join) {
            $join->on('users_requests.target_id', 'students_fees.id');
            $join->on('users_requests.user_id', 'students_fees.student_id');
            $join->on('users_requests.type', 'services.type');
            $join->whereIn('users_requests.order_status', ['PAID', 'MANUALPAID', 'INTERNALLYPAID']);
        })
        ->where('students_fees.active', 1)
        ->where('students_fees.student_id', $student->id)
        ->where('students_fees.due_date', '<=', Carbon::now())
        ->groupBy('students_fees.id');

        $query->addSelect(DB::raw("IFNULL(sum(users_requests.paid_amount), 0) + IFNULL(sum(takaful_requests.discount_amount), 0)  as paid"));
        
        $results = $query->get();
        $haveUnPaidFees=false;
        if($results != null)
        {
            foreach($results as $result)
            {
                if($result->paid < $result->amount)
                {
                    $haveUnPaidFees=true;
                    break;
                }
            }
        }

        return $haveUnPaidFees;
    }

    public function studentPaymentConfirmation(UserRequest $userRequest) {

        $totalCredit = Session::get('total_credit');

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];
 
        return view('payments.fees.confirm', compact('path', 'userRequest', 'totalCredit'));
    }

    public function feesQuery($parameters = null) {

        $lang = lang();   
        
        $query = StudentFee::select('students_fees.id',
        'students_fees.student_id',
        'students_fees.term_id',
        'students_fees.service_id',
        'students_fees.amount',
        'students_fees.method',
        'students_fees.due_date',
        'students_fees.notes',
        'students_fees.created_at',
        'students_fees.updated_at',
        'users.en_name as user_name',
        'users.code as user_code',
        'services.name as service_name',
        'users_requests.paid_amount',
        'takaful_requests.discount_amount as takaful_discount_amount',
        'terms.'.$lang.'_name as term_name')
        ->join('users', 'users.id', 'students_fees.student_id')
        ->leftjoin('takaful_requests',  function($join) {
            $join->on('takaful_requests.student_id', 'students_fees.student_id');
            $join->on('takaful_requests.term_id', 'students_fees.term_id');
            $join->where('students_fees.first', 1);
            $join->where('takaful_requests.status', 2);
        })
        ->leftJoin('services', 'services.id', 'students_fees.service_id')
        ->leftjoin('users_requests', function($join) {
            $join->on('users_requests.target_id', 'students_fees.id');
            $join->on('users_requests.user_id', 'students_fees.student_id');
            $join->on('users_requests.type', 'services.type');
            $join->whereIn('users_requests.order_status', ['PAID', 'MANUALPAID', 'INTERNALLYPAID']);
        })        
        ->leftJoin('terms','terms.id','students_fees.term_id')
        ->where('students_fees.active', 1)
        ->groupBy('students_fees.id');

        $query->addSelect(DB::raw("IFNULL(sum(users_requests.paid_amount), 0) + IFNULL(sum(takaful_requests.discount_amount), 0)  as paid"));
        $query->addSelect(DB::raw("count(users_requests.id) as paid_count"));

        if ($parameters->textSearch) {
            $textSearch = mb_ereg_replace(" ", "%", getFTS($parameters->textSearch));
            $query->where(DB::raw("CONCAT(COALESCE(students_fees.amount,''), ' ', COALESCE(students_fees.notes,''), ' ', COALESCE(users.search_text,''), ' ', COALESCE(terms.".$lang."_name,''), ' ', COALESCE(students_fees.id,''), ' ', COALESCE(services.name,''))"), "like", "%$textSearch%");
        }        

        if($parameters->serviceID){
            $query->where('students_fees.service_id', $parameters->serviceID);
        }

        if($parameters->termID){
            $query->where('students_fees.term_id', $parameters->termID);
        }

        if($parameters->studenID){
            $query->where('students_fees.student_id', $parameters->studenID);
        }

        $query->orderBy('students_fees.created_at', 'desc');

        $query = DB::table( DB::raw("({$query->toSql()}) as sub") )
        ->mergeBindings($query->getQuery());

        $paid = StudentFee::STATUS_PAID;
        $unPaid = StudentFee::STATUS_UN_PAID;
        $partialyPaid = StudentFee::STATUS_PARTIALLY_PAID;

        $statusField = "(CASE WHEN amount<=paid THEN $paid WHEN paid = 0 THEN $unPaid ELSE $partialyPaid END)";
        $creditField = "(CASE WHEN amount <= paid THEN paid-amount ELSE 0 END)";

        $query->addSelect('*');
        $query->addSelect(DB::raw("$statusField as status"));
        $query->addSelect(DB::raw("$creditField as credit"));

        if($parameters->status!==null){
            $query->whereRaw("$statusField = $parameters->status");
        }

        if($parameters->credit!==null){
            if($parameters->credit) $query->whereRaw("$creditField > 0");
            else $query->whereRaw("$creditField = 0");
        }

        return $query;
    }

    public function studentFees(Request $request) {
       
        $student = auth()->user()->student;

        $parameters = (object)[];

        $parameters->textSearch = null; 
        $parameters->serviceID = null;
        $parameters->termID = null;
        $parameters->status = null;
        $parameters->studenID = auth()->id();
        $parameters->credit = null;
        
        $query = $this->feesQuery($parameters);

        $payments = $query->get();

        $statistics = (object)[];
        $statistics->total_amount = 0;

        $unPaidPayments = [];

        foreach ($payments as $payment) {
            
            if($payment->amount > $payment->paid && $payment->amount > 0) {
                $amount = $payment->amount - $payment->paid;
                $statistics->total_amount += $amount;
                $unPaidPayments[] = $payment;
            }

        }
        
        $calculatePayWithCredit = UserRequest::where('user_id', $student->id)->where('payment_provider', 'credit')->sum('paid_amount');
       

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];

        $services = Service::select('id', 'name')
        ->where('fees', 1)
        ->pluck('name', 'id')
        ->toArray();
        
        $terms = Term::select('id', 'en_name as name')->where('active', '=', 1)->orderBy('start_date', 'desc')->pluck('name', 'id')->toArray();

        return view('payments.fees.index', compact('path', 'student', 'payments', 'statistics', 'unPaidPayments', 'services', 'terms'));
    }   

    public function studentCredits(Request $request) {

        $student = Auth::user()->student;
        if(!$student)
            abort(404);
         
        if ($request->ajax()){

            $columns = $request->columns;
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;

            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            
            \Log::info('Request:', $request->all());
    
            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $result = StudentCredit::select('*')
            ->where('student_id', $student->id)
            ->orderBy($orderBy, $orderDir)
            ->paginate($length);

            return [
                'draw' => $draw,
                'recordsTotal' => $result->total(),
                'recordsFiltered' => $result->total(),
                'data' => $result
            ];

        }

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];
    
        return view('payments.credits.index', compact('path', 'student'));
         
    }
    

    public function chargeStudentCredit(Request $request){
        
        $student = Auth::user()->student;
        if(!$student)
            abort(404);

        $this->validate($request, [
            'amount' => 'required|numeric',
        ]);

        $amount = $request->amount;

        //Add new record to the user requests table
        $userRequest = new UserRequest();
        $userRequest->user_id = $student->id;
        $userRequest->updated_by = $student->id;
        $userRequest->type = "Charge_my_credit";
        $userRequest->save();
        $userRequest->refresh();

        //generate the merchantRefNo
        $merchantRefNo = $userRequest->id.'_'.time(). '@chrgcr';

        $data = [
            'Amount' => $amount,
            'transaction_type' => StudentCredit::TYPE_DEPOSIT,
            'comment' => 'Charged with the student'
        ];

        $userRequest->data = json_encode($data);
        $userRequest->total_amount = $amount; //$student_payments->total_amount;
        $userRequest->merchant_reference_no = $merchantRefNo;
        $userRequest->payment_provider = 'fawry';
        $userRequest->order_status = 'INCOMPLETE';
        $userRequest->save();

        $userRequest->refresh();

        //for bank misr pay with Credit Card transactions only
        $session_id =  $this->createCheckoutSession($merchantRefNo, $userRequest);
        $userRequest->session_id = $session_id;

        //for bank misr pay with Meeza Card transactions only
        $meeza_msg_signature =  $this->createMsgSignature( $amount, $userRequest->created_at);
        $userRequest->meeza_msg_signature = $meeza_msg_signature;

        $userRequest->save();

        if(empty($userRequest->archive_id)) {
            $archive = Archive::get("users_requests/$userRequest->id");
            $userRequest->archive_id = $archive->id;
            $userRequest->save();
            $userRequest->refresh();
        }

     
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];
 
        return view('payments.fees.confirm', compact('path', 'userRequest'));
    }
}
