<?php

namespace App\Http\Controllers;

use App\Archive;
use App\ArchiveRole;
use App\ArchiveUser;
use App\User;
use App\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Pagination\Paginator;
use Spatie\Permission\Models\Role;
use ZipArchive;
use DB;


class ArchiveController extends Controller
{ 
    public $user = null;

    public function __construct() {
        $this->middleware('auth')->except('download', 'secureDownload');
    }

    /**
     * List archive files and folders.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, Archive $archive) {

        if(empty($archive) || empty($archive->id)) {
            if(!auth()->user()->hasPermissionTo('admin_archive'))
                abort(401);
            $archive = Archive::root();
        }

        if(!$archive->canAccess()) {
            abort(401);
        }

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $parentId = $columns[0]["search"]["value"];
            $searchType = $columns[1]["search"]["value"];
            $type = $columns[2]["search"]["value"];
            $contentType = $columns[3]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = Archive::orderBy($orderBy, $orderDir);

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $query->where(\DB::raw("COALESCE(archive.search_text,'')") , "like", "%$textSearch%");
            }

            if ($searchType=="1") {
                $parent = Archive::find($parentId);
                $path = ($parent)?"$parent->path/$parent->title":"";
                $path = str_replace("/", "%", $path);
                $path = str_replace("\\", "%", $path);
                $query->where('archive.path', 'LIKE', "$path%");
            } else if ($parentId!==null) {
                $query->where('archive.parent_id', '=', $parentId);
            }
            else {
                die();
            }
            
            if ($type!==null) {
                $query->where('archive.type', '=', $type);
            }

            if ($contentType!==null) {
                $query->where('archive.content_type', '=', $contentType);
            }

            if (!auth()->user()->hasPermissionTo('admin_archive')) {
                $query->whereRaw(\DB::raw('flags&1'));
            }

            $query->where('related_id', 0);

            \Log::info('Request:', [$query->toSql()]);

            $rows = $query->paginate($length);

            $rows->getCollection()->transform(function ($value) {
                
                $archive = Archive::find($value->id);
                $value->en_title = $archive->title;
                $archive = $archive->getLocale();
                $value->title = $archive->title;
                $value->sid = $archive->secret();
                $value->sub_title = $archive->sub_title;
                $value->description = $archive->description;
                $value->size = $archive->size;

                return $value;
            });

            $rows->getCollection()->transform(function ($value) {

                $users = ArchiveUser::select('users.id', 'users.'.lang().'_name as name', DB::raw("(CASE WHEN users.type = 1 THEN departments.code WHEN users.type = 2 THEN '".__("tr.Employee")."' WHEN users.type = 4 THEN '".__("tr.External Instructor")."' ELSE '' END) AS code"))
                    ->where('archive_users.archive_id', $value->id)
                    ->join('users', 'users.id', '=', 'archive_users.user_id')
                    ->leftJoin('instructors', 'instructors.id', '=', 'users.id')
                    ->leftJoin('departments', 'departments.id', '=', 'instructors.department_id')
                    ->get()->toArray();

                $roles = ArchiveRole::select('roles.id', 'roles.name as name')
                    ->where('archive_roles.archive_id', $value->id)
                    ->join('roles', 'roles.id', '=', 'archive_roles.role_id')
                    ->get();

                $value->users = $users;
                $value->roles = $roles;
                return $value;
            });

            return [
                    'draw' => $draw,
                    'recordsTotal' => $rows->total(),
                    'recordsFiltered' => $rows->total(),
                    'data' => $rows
                ];
        }

        $path = [];

        $roles = Role::all();

        return view('system.archive.index', compact('path', 'archive','roles'));
    }

  /**
   * Change The Order of the Content
   *
   * @param Archive $archive
   * @param $position
   * @param $neighbour_id
   * @return \Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\JsonResponse|\Illuminate\Http\Response
   */
    public function order($id, $position, $neighbour_id) {

        $neighbour = Archive::find($neighbour_id);
        $archive  = Archive::find($id);

        if(!$archive->canEdit())
            return response('', 401);

        if($neighbour->parent_id!=$archive->parent_id)
            return response('', 500);

        \DB::statement("UPDATE archive SET archive.order = archive.order + 1, updated_at = now() WHERE parent_id = $archive->parent_id AND archive.order > $neighbour->order AND id != $neighbour->id;");

        \DB::statement("UPDATE archive SET archive.order = $neighbour->order + 2, updated_at = now() WHERE parent_id = $archive->parent_id AND archive.order = $neighbour->order AND id > $neighbour->id;");

        if($position=="before") {
            $archive->order = $neighbour->order;
            $neighbour->order++;
            $archive->save();
            $neighbour->save();
        }
        else if($position=="after"){
            $order = $neighbour->order;
            $archive->order =$order+1;
            $archive->save();
            $neighbour->save();
        }

        $order = 1;
        foreach($archive->parent->children as $child) {
            $child->order = $order++;
            $child->save();
        }

        return response('Done');
    }

  /**
   * Edit The Archive
   * @param Archive $archive
   * @param Request $request
   * @return \Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Contracts\View\Factory|\Illuminate\Http\Response|\Illuminate\View\View
   */
    public function edit(Archive $archive, Request $request, $from = 'main') {

        if(empty($archive->id)) {
            $archive->id = 0;
        }

        if(!$archive->canEdit())
            abort(401);

        $path = [
            (object) [
                'link' => route('archive'),
                'title' => 'Archive'
            ]
        ];

        return view('system.archive.edit', compact('path', 'archive', 'from'));
    }

    public function canEdit($archive, $parent) {

        if($archive && $archive->id) {
            return $archive->canEdit();
        } else if($parent && $parent->id) {
            return $parent->canEdit();
        } else {
            return auth()->user()->hasPermissionTo('admin_archive');
        } 

        return true;
    }

    /**
    * Save The Archive After Update
    * @param Archive $archive
    * @param Request $request
    * @return \Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse|\Illuminate\Http\Response|\Illuminate\Routing\Redirector
    */
    public function save(Archive $archive, Request $request, $from = 'main') {

        if(!$this->canEdit($archive, Archive::find($request->parent_id))) {
            return response()->json(['error'=>['Failed to create new archive. Permission denied.']], 500);
        }        

        $oldData = (empty($archive->id))?null:$archive->getAttributes();

        $new = ($archive->id==0);

        if($request->ajax()) {

            $validatedData = $request->validate([
                'title' => 'required|max:255',
                'parent_id' => 'required',
                'short_name' => 'max:256',
            ]);

            if(!empty($request->short_name)) {
                $count = Archive::where('short_name', '=', $request->short_name)
                ->where('version', '=', $archive->version)
                ->where('language', '=', $archive->language)
                ->where('parent_id', '=', $archive->parent_id)
                ->where('id', '!=', $archive->id)->count();
                if($count>0) {
                    return response()->json(['error' => array('Short name already exist, provide another name.')], 404);
                }
            }

            if($archive->id==0) {
                $archive->user_id = auth()->id();
                $archive->title = "".rand();
                $archive->language = "en";                
            }

            $archive->fill($request->all());
            $archive->flags = 0;
            if($request->visible)$archive->flags |= 0x1;
            if($request->writable)$archive->flags |= 0x2;
            $archive->apply();
            $archive->rename($request->title);

            $locale = $archive->getLocale();
            $locale->description = $request->description;
            $locale->sub_title = $request->sub_title;
            $locale->save();
            $archive->saveFTS();

            if ($request->users_ids){
                $users = $request->users_ids;
                $usersData = [];
                foreach ($users as $user){
                    $usersData[] = $user;

                }
                $archive->users()->sync($usersData);
            } else {
                $archive->users()->sync([]);
            }

            if ($request->roles){
                $roles = $request->roles;
                $rolesData = [];
                foreach ($roles as $role){
                    $rolesData[] = $role;

                }
                $archive->roles()->sync($rolesData);
            } else {
                $archive->roles()->sync([]);
            }

            return response()->json();
        }

        $archive->updatePage($request->content);

        if ($from == 'main'){
            return redirect(route('archive', ['id'=>$archive->parent_id]));
        } else {
            return redirect(route('dashboard_show_archive', ['id'=>$archive->parent_id]));
        }
    }

    /**
    * Check if The ShortName is Unique
    * @param $shortName
    */
    public function checkShortName(Archive $archive, $shortName)
    {
        $count = Archive::where('short_name', '=', $shortName)
            ->where('version', '=', $archive->version)
            ->where('language', '=', $archive->language)
            ->where('parent_id', '=', $archive->parent_id)
            ->where('id', '!=', $archive->id)->count();
            if($count>0) {
                die("exists");
            }

        die("none");
    }

    /**
    *  Return the parents of the spcific Archive
    * @param Archive $archive
    * @param int $root_id
    * @return \Illuminate\Http\JsonResponse
    */
    public function parents(Archive $archive, $root_id = 0){
        $result = [];

        if($archive->id==null) {
            $archive = Archive::root();
        }

        while (true) {

            if(!$archive->canAccess())
                break;

            if($archive->id==0)
                array_unshift($result, (object)['id'=>0, 'title'=>'Archive', 'en_title'=>'Archive']);
            else
                array_unshift($result, (object)['id'=>$archive->id, 'title'=>$archive->getLocale()->title, 'en_title'=>$archive->title]);

            if($archive->id==$root_id)break;

            $archive = $archive->parent;
            if(!$archive->canAccess())break;
        }

        return response()->json($result);
    }

    /**
     * Downlaod a file from archive.
     * @return void
     */
    public function download(Archive $archive)
    {
        if(!$archive->canDownload())
            abort(404);

        try{

            return $archive->download();
        } catch (\Throwable $e) {
            abort(404);
        }
    }

    public function secureDownload(Request $request) {
        try{
            $value = decryptData($request->sid, env("WEBSITE_SHARED_KEY", NULL));
            $list = explode(",", $value);
            $id = $list[0];

            $archive = Archive::where('id', $id)->first();
            return $archive->download();
        } catch (\Throwable $e) {
            abort(404);
        }
    }

    public function export(Archive $archive) {

        return $archive->export();
        if(!auth()->user()->hasPermissionTo('admin_archive'))
            abort(404);

        try {

        } catch (\Throwable $e) {
            abort(500);
        }
    }

    public function import(Archive $archive, Request $request) {
        
        if(!auth()->user()->hasPermissionTo('admin_archive'))
            abort(404);

        try {

            $path = $_FILES['file']['tmp_name'];
            $archive->import($path);
            return response()->json();
        } catch (\Throwable $e) {
            dbg($e->getMessage());
            return response()->json(['error'=>$e->getMessage(), 'code'=>$e->getCode()], 500);
        }
    }

    /**
     * Delete archive.
     * @return void
     */
    public function delete(Archive $archive) {

        if(!$archive->canDelete()) {
            return response()->json(['error'=>'Failed to delete archive. Permission denied.'], 500);
        }

        Log::log("Delete Archive", $archive, ['action'=>'delete']);

        ArchiveUser::where('archive_id', $archive->id)->delete();
        ArchiveRole::where('archive_id', $archive->id)->delete();

        $archive->delete();

        return response()->json();
    }

    /**
     * Update a file to archive.
     * @return void
     */
    public function updateFile(Archive $archive, Request $request)
    {
        if($request->ajax())
        {
            $filesInfos = [];

            $archive->updateFile($request->file('file'));

            $filesInfos[] = (object) [
                        'id' => $archive->id,
                        'name' => $archive->name(),
                    ];

            return [
                "isSuccess" => true,
                "files" => $filesInfos
            ];
        }
    }

    /**
     * Upload a file to archive.
     * @return void
     */
    public function uploadFiles(Archive $archive, Request $request)
    {
        if(!$this->canEdit($archive, Archive::find($request->parent_id))) {
            return response()->json(['error'=>['Failed to create new archive. Permission denied.']], 500);
        }

        if($request->ajax())
        {
            if(empty($archive->id))
            {
                $archive = new Archive();
                $archive->id = 0;
            }

            $files = $request->file('files');
            $file = $request->file('file');
            if(empty($files) && !empty($file)) {
                $files = [$file];
            }

            $filesInfos = [];

            if(!empty($files))
            {
                foreach ( $files as $file )
                {
                    if(!empty($request->folder)) {
                        $path = $archive->calculatePath().'/'.$request->folder;
                        $archive = Archive::get($path);
                    }

                    $oldFile = null;
                    if(!empty($request->title) && $request->replace=="yes") {
                        $oldFile = $archive->findChildByTitle($request->title);
                    }

                    $archiveFile  = $archive->addFile($file, $request->content_type);
                    if($archiveFile) {
                        if($oldFile) {
                            Log::log("Autodel Archive", $oldFile, ['action'=>'autodel']);
                            $oldFile->delete();
                        }
                        if(!empty($request->title)) {
                            $archiveFile->rename($request->title);
                        }
                        Log::log("Upload Archive", $archiveFile, ['action'=>'done']);
                    } else {
                        Log::log("Upload Failed", $archiveFile, ['action'=>'failed']);
                    }

                    $filesInfos[] = (object) [
                        'id' => $archiveFile->id,
                        'name' => $archiveFile->name(),
                    ];
                }
            }

            return [
                "isSuccess" => true,
                "files" => $filesInfos
            ];
        }
    }

    public function pasteTo(Archive $archive, Request $request) {

        if(!auth()->user()->hasPermissionTo('edit_archive'))
            return response('', 401);

        foreach ($request->marked_ids as $id) {
            $markedArchive = Archive::find($id);
            $markedArchive->copy($archive->id);
        }

        return response()->json();
    }

    public function moveTo(Archive $archive, Request $request) {

        if(!auth()->user()->hasPermissionTo('edit_archive'))
            return response('', 401);

        foreach ($request->marked_ids as $id) {
            $markedArchive = Archive::find($id);
            $markedArchive->move($archive->id);
        }

        return response()->json();
    }

    public function getImages(Archive $archive) {

        $data = [];
        $imagesFolder = $archive->parent->findChildByContentType("images");
        if($imagesFolder) {
            $files  = $imagesFolder->subChildren(Archive::TYPE_FILE);
            foreach ($files as $file){
                $data[] = [
                    "image" => route('download_file',['archive'=>$file->id]),
                    "folder" => $file->parent->locale->title,
                ];
            }
        }        

        return response()->json($data);
    }

    public function downloadFiles(Archive $archive) {

        $zipPath = "/temp_folders/".ucfirst($archive->title).".zip";
        Storage::disk('local')->delete($zipPath);
        $zipPath = storage_path('app').$zipPath;

        $zip = new ZipArchive();
        if (!$zip->open($zipPath, ZipArchive::CREATE))
            abort(500);

        $files = $archive->children;

        $nFiles = 0;
        foreach ($files as $file){
            if($file->isPage()||$file->isFile()) {
                $destPath = "$file->title.$file->extension";
                $zip->addFile($file->physicalPath(),  $destPath);
                $nFiles++;
            }
        }
        if($nFiles==0) {
            return redirect()->back();
        }
        $zip->close();

        if (count($files)){
            return response()->download(
                $zipPath,
                "$archive->title.zip",
                array('Content-Type: '.mime_content_type($zipPath)));
        } else {
            return redirect()->back();
        }
    }

    public function downloadAll(Archive $archive){
        
        $zipPath = "/temp_folders/".ucfirst($archive->title).".zip";
        Storage::disk('local')->delete($zipPath);
        $zipPath = storage_path('app').$zipPath;

        try {
            $zip = new \ZipArchive();
            $zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);

            $path = $archive->physicalPath();
            $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path));

            // dd($files);
            foreach ($files as $name => $file)
            {
                if (!$file->isDir()) {
                    $filePath     = $file->getRealPath();

                    $relativePath = '' . substr($filePath, strlen($path) + 1);

                    $zip->addFile($filePath, $relativePath);
                }
            }
            $zip->close();
            return response()->download($zipPath);
        } catch (\Throwable $th) {
            
            return back();
        }
    }
}
