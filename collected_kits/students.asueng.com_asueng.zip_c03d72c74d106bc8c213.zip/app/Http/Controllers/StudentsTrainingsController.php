<?php

namespace App\Http\Controllers;

use App\User;
use App\Student;
use App\Bylaw;
use App\Plan;
use App\Term;
use App\Log;
use App\Training;
use App\StudentTraining;
use App\Archive;
use App\StudentTrainingMessage;
use App\QuestionnaireTask;
use Auth;
use DB;
use Exception;
use Response;
use Validator;
use Redirect;
use App\Setting;
use App\QuestionnaireComment;
use App\QuestionnaireAnswer;

use Illuminate\Pagination\Paginator;

use Illuminate\Http\Request;

class StudentsTrainingsController extends Controller
{
    public function __construct(){

        $this->middleware('auth');
    }

    public function index(){

        if(!auth()->user()->hasPermissionTo('access_trainings'))
            abort(401);

        $path = [];
        return view('trainings.index', compact('path'));
       
    }

     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function list(Request $request){
        
        if(!auth()->user()->hasPermissionTo('access_trainings'))
            abort(401);

      
        $path[] = (object) ['link' => route('trainings'), 'title' => __('tr.Student Trainings')];


        $lang = lang();

        $student = auth()->user()->student;


        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;

            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];

            $term_id = $columns[0]["search"]["value"];
            $bylaw = $columns[1]["search"]["value"];
            $type = $columns[2]["search"]["value"];
            $start_date = $columns[3]["search"]["value"];
           

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });


            $query = Training::select("trainings.*", "terms.".$lang."_name as term_name")
                                        ->leftJoin('student_training_plans', 'student_training_plans.training_id', 'trainings.id')
                                        ->leftJoin('terms', 'terms.id', '=', 'trainings.term_id')
                                        ->where('trainings.target', 'Students')
                                        ->where('trainings.approved', '1')
                                        ->whereRaw("(plan_id = $student->last_plan_id OR all_plans = 1)");

            if ($term_id) {
                $query->where('trainings.term_id', $term_id);
            }

            if ($bylaw) {
                $query->whereIn('trainings.bylaw', [$bylaw, 'All']);
            }
    
            if ($type) {
                $query->where('trainings.type', $type);
            }
    
            if ($start_date) {
                $query->where('trainings.start_date', $start_date);
            }
            
            $rows = $query->orderBy('trainings.start_date', 'DESC')->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }


         
        $terms = Term::orderBy('id', 'DESC')->pluck($lang."_name as name", "id")->toArray();
        $types = Training::types;

        return view('trainings.list', compact('path', 'terms', 'types'));

    }

     /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id){

        if(!auth()->user()->hasPermissionTo('access_trainings'))
            abort(401);

        $training = Training::with('plans')->with('term')->where('target', 'Students')->findOrFail($id);

        if(!$training->canApply())
            abort(401);


        $student = auth()->user()->student;
        $studentTraining =  $student->studentTraining->where('training_id', $id)->first();
        

        $path[] = (object)[
            'link' => route('trainings'),
            'title' =>  __('tr.Student Trainings')
        ];
        
        $path[] = (object)[
            'link' => route('studentstrainings'),
            'title' =>  __('tr.Available Trainings')
        ];

        return view('trainings.show', compact('path', 'training', 'studentTraining'));
    }


    public function apply(Request $request, $id)
    {
        if(!auth()->user()->hasPermissionTo('access_trainings'))
            abort(401);

        $training = Training::where('target', 'Students')->findOrFail($id);

        if(!$training->canApply())
            abort(401);

        $student = auth()->user()->student;

        $appliedBefore =  ($student->studentTraining->where('training_id', $id)->count()) > 0 ? true:false;
        if($appliedBefore)
            abort(401);

        /*if($student->reachedTrainingsWeeksLimit($training->term_id)){
            return Redirect::back()->withErrors([__('tr.You have exceeded the maximum number of weeks')]);
        }*/

        if($training->cv_required == 1 || $request->hasFile('cv')){
            $this->validate($request, [
                'cv'=> 'required|mimes:jpeg,jpg,png,gif,pdf,doc,docx,odt|max:10240',
            ]);
        }

        $StudentTraining = new StudentTraining();
        $StudentTraining->student_id = $student->id;
        $StudentTraining->training_id = $training->id;
        $StudentTraining->save();

        if($request->hasFile('cv'))
        {
            $archive = Archive::get('studentstrainings/training_'.$StudentTraining->id);
            $StudentTraining->archive_id = $archive->id;
            $StudentTraining->save();
            $cv = $request->file('cv');
            $archive->addFile($cv);
          
        }

        return redirect()->route('studentstrainings_show', ['id' => $training->id]);

        
    }

     /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(){

        if(!auth()->user()->hasPermissionTo('add_trainings'))
            abort(401);

        $terms = Term::currentAndNextTermsList();
        $types = Training::types;
        $bylaws = Bylaw::undergradbylawsList();

     
        $path[] = (object)[
            'link' => route('studentstrainings'),
            'title' =>  __('tr.Students Trainings')
        ];

        return view('trainings.create', compact('path', 'terms', 'types', 'bylaws'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){ 

        if(!auth()->user()->hasPermissionTo('add_trainings'))
            abort(401);

        $this->validate($request, [
            'term_id' => 'required|numeric',
            'type' => 'required|string',
            'title' => 'required|string',
            'description' => 'required|string',
            'provider' => 'required|string',
            'num_of_weeks' => 'required|numeric',
            'num_of_students' => 'required|numeric',
            'acceptance_criteria' => 'required|string',
            //'plans_ids' => 'required|array',
            
            'start_date' => 'required|date|after:today',
            'end_date' => 'required|date|after_or_equal:start_date',

            'application_start_date' => 'required|date',
            'application_end_date' => 'required|date|after_or_equal:application_start_date',

            'contact_person' => 'required|string',
        ]);

        $training = Training::create($request->all());

        $training->created_by = auth()->id();
        $training->approved = 0;
        $training->source = 'Student';
        $training->save();

        //
        $training->all_plans = 1;
        $training->bylaw = 'All';
        $training->save();

        $StudentTraining = new StudentTraining();
        $StudentTraining->student_id = auth()->id();
        $StudentTraining->status = -1;
        $StudentTraining->training_id = $training->id;
        $StudentTraining->save();
      
        return redirect()->route('create_training_request')->with('msg', __('tr.Your request has been submitted successfully')); 
    }

    public function getPlansByBylaw($bylaw){

        if(!auth()->user()->hasPermissionTo('access_trainings'))
            abort(401);
        
        $lang = lang();
        $plans = Plan::select(DB::raw("CONCAT(CASE WHEN ".$lang."_program IS NULL THEN 'Specialized Programs' ELSE ".$lang."_program END,': ',".$lang."_minor) AS name"),'id')
                        ->where('bylaw', $bylaw)
                        ->pluck("name", "id");
        return response()->json($plans, 200);
        
    }


    public function myTrainings(Request $request){

        if(!auth()->user()->hasPermissionTo('access_trainings'))
            abort(401);
        
        $path[] = (object)[
            'link' => route('trainings'),
            'title' =>  __('tr.Student Trainings')
        ];

        $lang = lang();

        $student = auth()->user()->student;


        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;

            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];

            $term_id = $columns[0]["search"]["value"];
            $bylaw = $columns[1]["search"]["value"];
            $type = $columns[2]["search"]["value"];
            $start_date = $columns[3]["search"]["value"];
            $status = $columns[4]["search"]["value"];
           

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });


            $query = StudentTraining::select('students_trainings.id', 
                                                'trainings.title', 
                                                'trainings.id as training_id', 
                                                'terms.'.$lang. '_name as term_name', 
                                                'num_of_weeks', 
                                                'students_trainings.status', 
                                                'trainings.start_date',
                                                'trainings.end_date',
                                                'trainings.type'
                                            )
                                        ->leftJoin('students', 'students.id', '=', 'students_trainings.student_id')
                                        ->leftJoin('trainings', 'trainings.id', '=', 'students_trainings.training_id')
                                        ->leftJoin('terms', 'terms.id', '=', 'trainings.term_id')
                                        ->where('students.id', '=', auth()->id())
                                        //->whereIn('students_trainings.status', [StudentTraining::ACCEPTED , StudentTraining::APPROVED, StudentTraining::REJECTED, StudentTraining::MEETING ])
                                        ->orderBy('trainings.term_id', 'DESC')
                                        ->orderBy('students.id', 'ASC');

            if ($term_id) {
                $query->where('trainings.term_id', $term_id);
            }

            if ($bylaw) {
                $query->whereIn('trainings.bylaw', [$bylaw, 'All']);
            }
    
            if ($type) {
                $query->where('trainings.type', $type);
            }
    
            if ($start_date) {
                $query->where('trainings.start_date', $start_date);
            }
            
            if (isset($status)) {
                $query->where('students_trainings.status', $status);
            }
            
            $rows = $query->orderBy('trainings.start_date', 'DESC')->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }


         
        $terms = Term::orderBy('id', 'DESC')->pluck($lang."_name as name", "id")->toArray();
        $types = Training::types;

        return view('trainings.my', compact('path', 'terms', 'types'));
    }

    public function trainingsFollowUp(StudentTraining $studentTraining)
    {
        if(!auth()->user()->hasPermissionTo('access_trainings'))
            abort(401);

        $path = [
            (object)[
                'link' => route('trainings'),
                'title' =>  __('tr.Trainings')
            ],
            (object)[
                'link' => route('my_trainings'),
                'title' =>  __('tr.My Trainings')
            ],
        ];
    
        $training = $studentTraining->training;

        $questionnaireID = Setting::where('name','training_questionnaire_id')->first()->value;
        $questionnaireTask = QuestionnaireTask::where('questionnaire_id', $questionnaireID)
        ->where('term_id', $training->term_id)
        ->where('training_id', $training->id)
        ->first();
        
        $hasQuestionaire = false;
        if(empty($questionnaireTask))
        {
            $totalStudents = StudentTraining::where('training_id',$training->id)->count();

            $questionnaireTask = new QuestionnaireTask();
            $questionnaireTask->term_id = $training->term_id;
            $questionnaireTask->questionnaire_id = $questionnaireID;
            $questionnaireTask->training_id = $training->id;
            $questionnaireTask->total= $totalStudents;
            $questionnaireTask->count= 0;
            $questionnaireTask->save();
            $hasQuestionaire = true;
        }
        else
        {
            $answer = QuestionnaireAnswer::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->get()->count();
            $comment = QuestionnaireComment::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->get()->count();
            if($answer == 0 && $comment == 0)
                $hasQuestionaire = true;
            
        }
        
        if($hasQuestionaire == true)
            return redirect(route("training_questionnaire", ['questionnaireTask'=>$questionnaireTask]));
        $lang = lang();

        $studentTrainingInfo = StudentTraining::select('students_trainings.*', 'trainings.title', 'trainings.provider', 
                                                        'trainings.description', 'trainings.num_of_weeks', 'trainings.start_date', 
                                                        'trainings.end_date', 'trainings.type')
                                    ->leftJoin('students', 'students.id', '=', 'students_trainings.student_id')
                                    ->leftJoin('trainings', 'trainings.id', '=', 'students_trainings.training_id')
                                    ->where('students.id', '=', auth()->id())
                                    ->where('students_trainings.id', $studentTraining->id)
                                    ->first();

        if(!$studentTrainingInfo)
            abort(401);


        //dd($studentTrainingInfo->toArray());
        //dd($studentTrainingInfo->studentTrainingMessages);
         
        return view('trainings.followup', compact('path', 'studentTrainingInfo'));
    }

    public function comment(StudentTraining $studentTraining, Request $request) {
        
        if(!auth()->user()->hasPermissionTo('access_trainings'))
            abort(401);

        if(!$studentTraining->canDiscuss())
            abort(401);

    
        $validator = Validator::make($request->all(), [
            'comment' => 'required',
            'attachments.*' => 'mimes:jpeg,png,jpg,pdf,doc,docx|max:2048',
        ]);


        if ($validator->fails()) {
            return response()->json(['Errors' => $validator->errors()->all()], 401);
        }

        $studentTrainingMessage = new StudentTrainingMessage();
        $studentTrainingMessage->student_training_id = $studentTraining->id;
        $studentTrainingMessage->comment = strip_tags($request->comment);
        $studentTrainingMessage->user_id = auth()->user()->id;
        $studentTrainingMessage->save();


        $files = $request->file('attachments');

        $filesInfos = [];

        if(!empty($files))
        {
            $archive = Archive::get('studentsTrainingsFollowUp/studentsTrainingFollowUp_'.$studentTraining->id.'/message_'.$studentTrainingMessage->id);
            $studentTrainingMessage->archive_id = $archive->id;
            $studentTrainingMessage->save();

            foreach ( $files as $file )
            {
                $file  = $archive->addFile($file);

                $filesInfos[] = (object) [
                    'id' => $file->id,
                    'name' => $file->name(),
                    'url' => route('download_file', ['archive_id'=>$file->id]),
                ];
            }
        }
        
        $results = [
            'id' =>  $studentTrainingMessage->id,
            'comment' =>  $studentTrainingMessage->comment,
            'user_id' =>  $studentTrainingMessage->user_id,
            'user_name' =>  $studentTrainingMessage->user->lang('name'),
            'created_from' =>  $studentTrainingMessage->created_at,
            'files_infos' =>  $filesInfos,
        ];
        
       
        return response()->json($results);
    }
}
