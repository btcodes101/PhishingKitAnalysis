<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\StudentSpecialRequest;
use App\StudentSpecialRequestCourse;
use App\Student;
use App\Study;
use App\Term;
use App\Archive;

use Validator;
use Auth;
use DB;

class StudentsSpecialRequestsController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    
    private function getPath() {
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];
        return $path;
    }

    public function finalExamSpecialRequests(){  

        $student = auth()->user()->student;
        if(!$student->canApplyExamSpecialRequests())
            abort(401);
        
        $student_id = $student->id;

        $lang = lang();

        //get the courses of the current exam term 
        $term = Term::currentExamTerm();
        $studies = Study::leftJoin('courses', 'courses.id', 'studies.course_id')
                        ->where('user_id', $student_id)
                        ->where('term_id', $term->id)
                        ->pluck('courses.'.$lang.'_name', 'courses.id');
        
        $specialRequest = StudentSpecialRequest::with('courses:courses.id')
                            ->where('student_id', $student_id)
                            ->where('term_id', $term->id)
                            ->first();
        if($specialRequest && $specialRequest->courses){
            $requestedCourses = $specialRequest->courses->makeHidden('pivot');
            $requestedCourses = $requestedCourses->map(function ($item, $key) {
                return $item->id;
            })->toArray();
        }else{
            $requestedCourses = [];
        }

        $path = $this->getPath();
        return view('students.services.exam_special_requests', compact('path', 'requests', 'studies', 'term', 'specialRequest', 'requestedCourses'));

    }

    public function store(Request $request){

        $student = auth()->user()->student;
        if(!$student->canApplyExamSpecialRequests())
            abort(401);
        
        $student_id = $student->id;

        $request->validate([
            'courses' => 'required',
            'type' => 'required',
            'description' => 'required',
            'attachments.*' => 'required|mimes:jpeg,png,jpg,pdf,doc,docx|max:2048'
        ]);

        $term = Term::currentExamTerm();

        $specialRequest = StudentSpecialRequest::updateOrCreate(
            [
                'student_id' => $student_id,
                'term_id' => $term->id,
            ],
            [
                'request' => $request->type,
                'description' => $request->description
            ]
        );

        $courses = $request->courses;
        $specialRequest->courses()->sync($courses);
        

        $files = $request->file('attachments');

        if(!empty($files))
        {
            $archive = Archive::get('specialRequests/Request_'.$specialRequest->id);
            $specialRequest->archive_id = $archive->id;
            $specialRequest->save();
            
            foreach ( $files as $file )
            {
                $file  = $archive->addFile($file);
                
                $filesInfos[] = (object) [
                    'id' => $file->id,
                    'name' => $file->name(),
                    'url' => route('download_file', ['archive_id'=>$file->id]),
                ];
            }
        }
       
        return redirect()->back()->with('success', __('tr.Your request has been submitted successfully'));
    }
}
