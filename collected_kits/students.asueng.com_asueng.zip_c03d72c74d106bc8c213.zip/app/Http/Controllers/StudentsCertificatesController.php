<?php

namespace App\Http\Controllers;

use App\Archive;
use App\Bylaw;
use App\CertificateType;
use App\PrintOperation;
use App\Report\ReportSystem;
use App\Student;
use App\StudentCertificate;
use App\TokenSigner\TokenSigner;
use App\User;
use App\CertificateSerial;
use App\Website;
use App\UserRequest;
use App\Plan;
use DB;
use Auth;
use Illuminate\Support\Str;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use PDF;
use App\Mail\SystemMail;
use App\Setting;


class StudentsCertificatesController extends Controller
{

    public function __construct()
    {        
        \Artisan::call('cache:clear'); 
        $this->middleware('auth')->except('check', 'viewExternalRequest', 'editExternalRequest', 'confirmExternalRequest', 'verifyExternalRequestPost', 'verifyExternalRequest', 'saveRequest');        
        $this->middleware('checkStdPaymentStatus');
    }    

    public function check(StudentCertificate $studentCertificate, $secrete, $order = null) {
        
        if(empty($studentCertificate) || $studentCertificate->secrete!=$secrete) {
            die("invalid certificate");
        }

        echo "<p>Status: valid certificate";

        echo "<p>Name:";
        echo $studentCertificate->user->en_name;

        if($order) { 
            $serials = $studentCertificate->serials($order);
            echo "<p>Paper Serials:";
            foreach ($serials as $serial) {
                echo "$serial->serial ($serial->printed_at) ";
            }
        }

        die();
    }
    
    public function saveRequest(Request $request, UserRequest $userRequest = null) {

        $user = auth()->user();
        
        $validators = [
            'en_name' => 'required|string|max:256',
            //'ar_name' => 'required|string|max:256',
            //'plan_id' => 'required|numeric',
            //'apply_to' => 'required|string',
        ];    
        
       
        if($request->has('plan_id')){
            $plan = Plan::find($request->plan_id);
            if(!$plan)
                abort(404);

            $ar_name = $request->ar_name;
            $plan_id = $plan->id;
            $plan_en_minor = $plan->en_minor;
            $plan_ar_minor = $plan->ar_minor;

        }else{
            $ar_name = '';
            $plan_id = '';
            $plan_en_minor = '';
            $plan_ar_minor = '';
            
        }

        foreach(CertificateType::fileTypes(0) as $fileContentType => $fileInfo) {
            $validators[$fileContentType] = 'mimes:jpeg,jpg,png,gif,pdf,doc,docx,odt|max:10240';
        }

        $request->validate($validators);

        if(empty($userRequest)) {
            $userRequest = new UserRequest();
            $data = (object)[];
            $data->email = $request->email;            
            $userRequest->order_status = "EMPTY";
        }
        else {
            $data = json_decode($userRequest->data);
        }

        if($request->request_type==1)
            $userRequest->user_id = 0;
        else
            $userRequest->user_id = ($user && !$user->isGuest())?$user->id:0;
        
        if($request->request_type==3) {
            $userRequest->type = "financial_aid_request";
        }else{
            $userRequest->type = "students_certificates";
        }
        
        $userRequest->save();
        $userRequest->refresh();

        $data->en_name = $request->en_name;
        $data->ar_name = $ar_name;
        $data->plan_id = $plan_id;
        $data->en_plan = $plan_en_minor;
        $data->ar_plan = $plan_ar_minor;
        $data->apply_to = ($request->has('apply_to'))?$request->apply_to:'';
        $data->student_code = $request->student_code;
        $data->graduation_date = $request->graduation_date;
        $data->mobile = $request->mobile;

        $postCost = 0;

        if($request->mail == 1){
            $data->mail = $request->mail;
            $data->mail_address = $request->mail_address;
            $data->mail_barcode = null;
            $postCost = (int)Setting::where('name', 'post_cost')->first()->value;
            $data->cost = $postCost;
        }
        else
            $data->mail = 0;
        
        if($userRequest->order_status == "EMPTY") {
            $data->type = $request->type;
            $data->quantity = $request->quantity;
            $totalAmount = 0;
            for ($i=0;$i<count($request->type);$i++) {
                if($request->quantity[$i]==0)continue;
                $certificateType = CertificateType::find($request->type[$i]);
                if($certificateType) {
                    $totalAmount += $certificateType->cost * $request->quantity[$i];
                }
            }
            $userRequest->total_amount = (int)$totalAmount + $postCost;

            $merchantRefNo = $userRequest->id.'_'.time().'@studentsAffairs';
            $userRequest->merchant_reference_no = $merchantRefNo; 

            $userRequest->save();
            $userRequest->refresh();


            //for bank misr pay with Credit Card transactions only
            $session_id =  $this->createCheckoutSession($merchantRefNo, $userRequest);
            $userRequest->session_id = $session_id;

            //for bank misr pay with Meeza Card transactions only
            $meeza_msg_signature =  $this->createMsgSignature( $totalAmount, $userRequest->created_at);
            $userRequest->meeza_msg_signature = $meeza_msg_signature;

            
        }

        $student_certificates = DB::select('SELECT * FROM students_certificates WHERE request_id ='.$userRequest->id);
        foreach($student_certificates as $student_certificate){
            if ($student_certificate->status == 6){
                DB::select('UPDATE `students_certificates` SET status = '.StudentCertificate::STATUS_UPDATED.' WHERE request_id = '.$userRequest->id.' AND status = 6');
            }
        }

        $userRequest->data = json_encode($data, JSON_UNESCAPED_UNICODE);

        

        $userRequest->save();

        if(empty($userRequest->archive_id)) {
            $archive = Archive::get("users_requests/$userRequest->id");
            $userRequest->archive_id = $archive->id;
            $userRequest->save();
            $userRequest->refresh();
        }

        foreach(CertificateType::fileTypes(0) as $fileContentType => $fileInfo) {
         
            if(isset($request[$fileContentType])) {
                $file = $userRequest->archive->findChildByContentType($fileContentType);
                if($file) {
                    $file->updateFile($request[$fileContentType]);
                } else {
                    $file = $userRequest->archive->addFile($request[$fileContentType], $fileContentType);
                }
                $file->rename($fileContentType);
                $file->save();
            } else {
                if(!$fileInfo->required && !isset($request[$fileContentType."_file_id"])) {
                    $file = $userRequest->archive->findChildByContentType($fileContentType);
                    if($file)$file->delete();
                }
            }
        }

        if($userRequest->order_status == "EMPTY" && $userRequest->user_id==0) {
            $message = 'Code: '.$data->student_code.'<br>Email: '.$data->email.'<br>Mobile: '.$data->mobile/*.'<br>Apply To: '.$data->apply_to*/;

            $title = "ASUENG - Certificates Request";        
            $systemMail = new SystemMail("certificates_request", ['title'=>$title, 'values' => ['request_data' => $message,'request_link' => $userRequest->externalLink('view'), 'request_user'=>$data->en_name]]);
            $systemMail->submit($data->email, false, Setting::value("email"),[],false);
        }

        if($userRequest->order_status == "EMPTY"){
            $userRequest->order_status = "INCOMPLETE";
            $userRequest->save();
        }

        if($userRequest->order_status == "INCOMPLETE"){
            if($request->request_type==1) {
                return redirect()->route('confirm_external_certificate_request', ['token'=>encrypt($userRequest->id)]);
            }
            else if($request->request_type==2) {
                return redirect()->route('confirm_certificate_request', [$userRequest->id]);
            }
        }
        else {
            if($request->request_type==1) {
                return redirect()->route('view_external_certificate_request', ['token'=>encrypt($userRequest->id)]);
            }
            else if($request->request_type==2) {
                return redirect()->route('my_certificates_requests');
            }
        }        
    }    

    public function verifyExternalRequest() {
        $website = new Website(Archive::locate('home'));
        return view('website.home.certificates.verify', compact('website'));
    }

    public function verifyExternalRequestPost(Request $request) {

        $validators = [
            'email' => 'required|email',
        ];

        if(env('APP_DEBUG') == false) {

            $ip = $_SERVER['REMOTE_ADDR'];
            $secretKey = '6Lf17rUUAAAAAGFFZ4GsZ1CZJJwAYkdEaEDC-EI5';
            $captcha = $request["g-recaptcha-response"];
            $url = "https://www.google.com/recaptcha/api/siteverify?secret=".$secretKey."&response=".$captcha."&remoteip=".$ip;
            dbg($url, "recaptcha");
            $response=file_get_contents($url);
            $responseKeys = json_decode($response,true);
            if(intval($responseKeys["success"]) !== 1)
                return response()->json(['error'=>"Server error, invalid request."], 500);
        }
        
        $userRequest = new UserRequest();
        $data = (object)[];
        $data->email = $request->email;
        $userRequest->data = json_encode($data, JSON_UNESCAPED_UNICODE);
        $userRequest->order_status = "NOT_VERIFIED";
        $userRequest->save();
    
        
        $title = "ASUENG - Email Verification";        
        $systemMail = new SystemMail("cerificate_verify_email", ['title'=>$title, 'values' => ['update_link' => $userRequest->externalLink('view')]]);
        $systemMail->submit($request->email, false, Setting::value("email"),[],false);
        
        return response()->json();
    }

    public function editExternalRequest(Request $request, $token) {

        $lang = lang();

        $id = decrypt($token);

        $userRequest = UserRequest::findOrfail($id);

        $website = new Website(Archive::locate('home'));

        $certificatesTypes = CertificateType::whereIn('graduation_type', [1, 2])->get();

        $fileTypes = CertificateType::fileTypes(2);

        $archive = $userRequest->archive;

        $userRequest->data = json_decode($userRequest->data);

        $plans_2003 = Plan::where('bylaw', 'UG2003')->where('year_id', 4)->get(['id', $lang.'_minor as name']);
        $plans_2013 = Plan::where('bylaw', 'UG2013')->where('year_id', 100)->get(['id', $lang.'_minor as name']);

        $postCost = (int)Setting::where('name', 'post_cost')->first()->value;

        return view('website.home.certificates.request', compact('website', 'certificatesTypes', 'fileTypes','userRequest','archive', 'plans_2003', 'plans_2013', 'postCost'));
    }

    public function confirmExternalRequest(Request $request, $token) {

        $id = decrypt($token);

        $userRequest = UserRequest::findOrfail($id);

        $website = new Website(Archive::locate('home'));

        $userRequest->data = json_decode($userRequest->data);

        return view('website.home.certificates.confirm', compact('website', 'userRequest'));
    }

    public function viewExternalRequest(Request $request, $token = null) {

        $id = null;
        if($token)$id = decrypt($token);
        else $id = decryptData($request->secret, env("WEBSITE_SHARED_KEY", null));

        $userRequest = UserRequest::findOrfail($id);

        if($userRequest->order_status == "NOT_VERIFIED"){
            $userRequest->order_status = "EMPTY";
            $userRequest->save();
        }

        if($userRequest->order_status=="EMPTY" || $userRequest->order_status=="INCOMPLETE") {
            return redirect()->route('edit_external_certificate_request', ['token'=>encrypt($userRequest->id)]);
        }

        $userRequest = UserRequest::find($id);

        $website = new Website(Archive::locate('home'));

        $userRequest->data = json_decode($userRequest->data);

        return view('website.home.certificates.view', compact('website', 'userRequest'));
    }

    public function myRequests() {

        $user = Auth::user();
        $lang = lang();
        $users_requests = UserRequest::select('*')->where('user_id',$user->id)->where('type',"students_certificates")->orderBy("created_at","DESC")->get();

        $students_certifications = StudentCertificate::select('students_certificates.id', 'print_count', 'request_id', 'student_id','notes','parameters','status',''.$lang.'_name as name')
                                    ->join('certificates_types','certificates_types.id','students_certificates.certificate_type_id')
                                    ->where('students_certificates.student_id',$user->id)
                                    ->get();


        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];

        return view('students.certificates.myrequests', compact('user', 'path', 'users_requests','students_certifications'));
    }
    
    public function editRequest(Request $request, UserRequest $userRequest = null) {

        $user = auth()->user();
        $lang = lang();
        $student = $user->student;
        if($student->hasGraduationSurvey())
            return redirect()->route('graduation_survey');
        $archive = null;

        if(empty($userRequest)) {
            $userRequest = new UserRequest();
            $userRequest->id = 0;
            $userRequest->data = (object)[];
            $userRequest->data->en_name = $user->en_name;
            $userRequest->data->mobile = $user->mobile;
            $userRequest->order_status = "EMPTY";
        }
        else if($user->id!=$userRequest->user_id){
            abort(401);
        }
        else {
            $archive = $userRequest->archive;
            $userRequest->data = json_decode($userRequest->data);
        }

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];

        $certificatesTypes = StudentCertificate::certificatesTypes($user->student);

        $fileTypes = CertificateType::fileTypes(1);

        $postCost = (int)Setting::where('name', 'post_cost')->first()->value;

        return view('students.certificates.request', compact('user', 'path', 'userRequest', 'certificatesTypes', 'archive', 'fileTypes', 'postCost'));
    }

    public function confirmRequest(Request $request, UserRequest $userRequest) {

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];

        $userRequest->data = json_decode($userRequest->data);

        return view('students.certificates.confirm', compact('path', 'userRequest'));
    }
}
