<?php

namespace App\Http\Controllers;

use App\StudyTerm;
use Illuminate\Http\Request;

class FacultyController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the setting page.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!auth()->user()->hasPermissionTo('access_system'))
            abort(401);
        
        $path = [];
        return view('manage/index', compact('path'));
    }

    /**
     * Show the setting page.
     *
     * @return \Illuminate\Http\Response
     */
    public function error($code)
    {
        $message = "Error, please try later.";
        switch($code) {
            case 401: $message = "You don't have permission to access this page."; break;
            case 404: $message = "The requested page is not found."; break;
        }

        return view('error', compact('code', 'message'));
    }

    function switchLang($lang = "") {
        $url   = url()->previous();
        $url_explode = explode('/',$url);
        $new_array = [];
        $flag = 0;
        if ($url_explode[3] == 'en' || $url_explode[3] == 'ar'){
            $redir = str_replace('/'.app()->getLocale(), '/'.$lang, $url);
        } else {
            $flag = 1;
            foreach ($url_explode as $key => $value){
                if ($key >= 3){
                    if ($key == 3){
                        $new_array[$key] = $lang;
                    }
                    if ($value != "" && $key >= 3){
                        $new_array[$key+1] = $value;
                    }
                }else {
                    $new_array[$key] = $value;
                }
            }
        }

        app()->setLocale($lang);
        if($flag == 0){
            return redirect()->to($redir);
        } else {
            $redir = implode('/', $new_array);
            return redirect()->to($redir);
        }
    }
}