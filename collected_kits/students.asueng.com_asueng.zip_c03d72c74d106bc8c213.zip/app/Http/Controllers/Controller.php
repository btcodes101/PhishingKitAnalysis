<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use App\Student;
use App\UserRequest;
use App\Archive;
use Auth;
use Exception;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    /**
     * A function to get a session id for a payment transaction [Bank Misr credit card account]
     */
    public function createCheckoutSession($merchantRefNo, $userRequest){

        $merchant = $userRequest->service->bank_misr_credit_card_account->merchant_number;
        $api_user_name = $userRequest->service->bank_misr_credit_card_account->api_user_name;
        $api_password = $userRequest->service->bank_misr_credit_card_account->api_password;

         
        $URL = "https://banquemisr.gateway.mastercard.com/api/rest/version/54/merchant/$merchant/session";


        try{

            $client = new \GuzzleHttp\Client();

            $data = [
                'apiOperation'=> 'CREATE_CHECKOUT_SESSION',
                'interaction' => [
                    'operation'=> 'PURCHASE'
                ],
                'order'=> [
                    'currency'=> 'EGP',
                    'id'=> $merchantRefNo
                ]
            ];
            

            $request = $client->request('POST', $URL, [
                'headers' => [
                    'Access-Control-Allow-Origin: *',
                    "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.0.8) Gecko/20061025 Firefox/1.5.0.8"
                ],
                json_encode($data)
                ,
                'auth' => [$api_user_name, $api_password]
            ]);

            
            $response = json_decode($request->getBody()->getContents());
           
            $session_id = $response->session->id? $response->session->id:0;
             
            return $session_id; 
            
        }catch(Exception $e){

            \Log::error('Exception [Controller:createCheckoutSession()]: ', [$e]);
            
            return 0; 
        }
    }



    /**
     * A function to check the payment status of bank Misr online payment [Credit Card] , using the order id
     */
    public function checkBankMisrPaymentStatus($orderId, $userRequest){

        $merchant = $userRequest->service->bank_misr_credit_card_account->merchant_number;
        $api_user_name = $userRequest->service->bank_misr_credit_card_account->api_user_name;
        $api_password = $userRequest->service->bank_misr_credit_card_account->api_password;
        
        $URL = "https://banquemisr.gateway.mastercard.com/api/rest/version/54/merchant/$merchant/order/$orderId";

        try{

            //Send a request to verify the payment
            $client = new \GuzzleHttp\Client();
            $request = $client->request('GET', $URL, [
                'headers' => [
                    'Access-Control-Allow-Origin: *',
                    "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.0.8) Gecko/20061025 Firefox/1.5.0.8"
                ],
                'auth' => [$api_user_name, $api_password]
            ]);

            //
            $response = json_decode($request->getBody()->getContents());
           
            //log whatever returned
            \Log::info('bankMisr Request Credit Card [checkBankMisrPaymentStatus]: ', [$response]);

            if(!$response)
                return false;

            if(!isset($response->result) || $response->result != 'SUCCESS')
                return false;

            if(!isset($response->status) || $response->status != 'CAPTURED')
                return false;

            if(!isset($response->amount) || $response->amount <= 0) 
                return false;

            if(isset($response->totalRefundedAmount) && $response->totalRefundedAmount > 0) 
                return false;
          
            //return th paid amount
            if(isset($response->amount)){
                return floor($response->amount / 1.0147134);
            }

            return false;
            

        }catch(Exception $e){

            \Log::error('Exception [Controller:checkBankMisrPaymentStatus()]: ', [$e]);
            
            return false; 
        }

        /*
        $response->result ;
        $response->amount ;
        $response->totalCapturedAmount ;
        $response->totalAuthorizedAmount ;
        $response->totalRefundedAmount ;
        $response->id ;
        $response->description ;
        $response->transaction[0]->result ;
        $response->transaction[0]->authorizationResponse->responseCode ; 
        */
       
    }

    
    /**
     * A function to create a message signature for the Meeza card [Bank Misr]
     */
    public function createMsgSignature($amount, $date){

        try{
            
            $datetime = \Carbon\Carbon::parse($date)->format('ymdHis');
            $amount = $amount * 100; //convert the amount to piasters
            return hash_hmac('sha256', "Amount=$amount&DateTimeLocalTrxn=$datetime&MerchantId=10349047849&TerminalId=88053534", hex2bin('65363934326264662D636639322D343636332D396336342D616363633034336134303666'));

        }catch(Exception $e){

            \Log::error('Exception [Controller:createMsgSignature()]: ', [$e]);
            
            return 0; 
        }
    }


    public function createUserRequest($service_name, $service_abbreviation, $total_amount, $data, $target_id = NULL)
    {
        $user = auth()->user();
       
        $user_id = ($user && !$user->isGuest())?$user->id:0;

        //Add new record to the user requests table
        $userRequest = new UserRequest();
        $userRequest->user_id = $user_id;
        $userRequest->type = $service_name;
        $userRequest->total_amount = $total_amount;
        $userRequest->target_id = $target_id;
        $userRequest->save();
        $userRequest->refresh();
  
  
        //generate the merchantRefNo
        $merchantRefNo = $userRequest->id.'_'.time(). '@' . $service_abbreviation;
  
        $userRequest->data = json_encode($data);
        $userRequest->merchant_reference_no = $merchantRefNo;
        $userRequest->payment_provider = '';
        $userRequest->order_status = 'INCOMPLETE';
        $userRequest->save();
  
        $userRequest->refresh();
  
        //for bank misr pay with Credit Card transactions only
        $session_id =  $this->createCheckoutSession($merchantRefNo, $userRequest);
        $userRequest->session_id = $session_id;
  
        //for bank misr pay with Meeza Card transactions only
        $meeza_msg_signature =  $this->createMsgSignature($total_amount, $userRequest->created_at);
        $userRequest->meeza_msg_signature = $meeza_msg_signature;

        $userRequest->save();
  
  
        if(empty($userRequest->archive_id)) {
            $archive = Archive::get("users_requests/$userRequest->id");
            $userRequest->archive_id = $archive->id;
            $userRequest->save();
            $userRequest->refresh();
        }

        return $userRequest;
    }
}

