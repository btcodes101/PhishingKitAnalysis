<?php

namespace App\Http\Controllers;

use App\Project;
use App\Ticket;
use App\TicketMessage;
use App\Archive;
use App\Log;
use App\Notification;
use App\TicketType;
use Illuminate\Http\Request;
use DataTables;
use Auth;
use App\Mail\SystemMail;
use App\Setting;
use Session;
use Illuminate\Http\Response;
use Illuminate\Pagination\Paginator;

use Validator;


class TicketsController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {

        $this->middleware('auth')->except('showExternal');
    }

    /**
     *  
     */
    public function index(Request $request) {
        
        if(!auth()->user()->hasPermissionTo('access_tickets'))
            abort(401);

        $path = [];

        $lang = lang();
        
        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];

            $type = $columns[0]["search"]["value"];
            $status = $columns[1]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = Ticket::select('tickets.*', 'tickets_types.'.$lang.'_name as ticket_type', 'tickets.related_id', 'tickets.description', 'users.'.$lang.'_name as staff_name')
                            ->leftjoin('tickets_types', 'tickets_types.id', 'tickets.ticket_type_id')
                            ->leftjoin('users', 'users.id', 'tickets.staff_id')
                            ->where('tickets.user_id', auth()->user()->id);


            if ($type){
                $query->where('tickets.ticket_type_id', $type);
            }

            if ($status || $status === "0"){
                $query->where('tickets.status', $status);
            } 
            
            $rows = $query->orderBy($orderBy, $orderDir)->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $ticketTypes = TicketType::where('internal_type', 0)->pluck($lang."_name as name", "id")->toArray();

        $ticketStatus = Ticket::statusLabels();
        foreach ($ticketStatus as $key => $status){
            $ticketStatus[$key] = str_replace('_', ' ', ucfirst($status));
        }


        return view('tickets.index', compact('path', 'ticketStatus', 'ticketTypes'));

    }

    public function showExternal() {

        $data = decryptData(request()->secrete, env("WEBSITE_SHARED_KEY", null));
        $_SESSION["ticket_guest"] =$data;
        Auth::loginUsingId(env("GUEST_USER_ID", null), true);
        
        $ticketData = Ticket::findOrfail($data);
        if($ticketData->status == -1){
            $ticketData->status = 0;
            $ticketData->save();
        }
        request()->session()->put('ticket_id', $data);
        return redirect()->route('show_ticket', ['id'=>$data]);
    }

    /**
     * Display the ticket.
     *
     * @param  \App\ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function show(Ticket $ticket)
    {
        if(!auth()->user()->hasPermissionTo('show_tickets'))
            abort(401);

        if(!$ticket->canOpen())
            abort(401);

        if(request()->session()->has('ticket_id')) {
            $externalTicketID = request()->session()->get('ticket_id');
            if($externalTicketID!=$ticket->id) {
                abort(401);
            }
        }

        $path[] = (object) [
            'link' => route('tickets'),
            'title' => 'Tickets'
        ];

        return view('tickets.show', compact('path', 'ticket'));
    }
    
    public function close(Ticket $ticket, Request $request) {

        if(!auth()->user()->hasPermissionTo('close_tickets'))
            abort(401);


        if(!$ticket->canOpen())
            abort(401);


        $validatedData = $request->validate([
            'action_comment'=>'required|string|min:4',
        ]);

        $ticket->status = Ticket::STATUS_CLOSED;
        $ticket->save();

        $ticket->logTicketAction(Ticket::ACTION_CLOSED, $request->action_comment);
        
        return redirect(route('show_ticket', ['id'=>$ticket->id]));
    }
    
    /**
     *add comment by ajax
     * @param Ticket $ticket
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function comment(Ticket $ticket, Request $request) {
        
        if(!auth()->user()->hasPermissionTo('edit_tickets'))
            abort(401);


        if(!$ticket->canOpen())
            abort(401);

        $validator = Validator::make($request->all(), [
            'comment' => 'required',
            'attachments.*' => 'mimes:jpeg,png,jpg,pdf,txt,doc,docx|max:2048',
        ]);


        if ($validator->fails()) {
            return response()->json(['Errors' => $validator->errors()->all()], 401);
        }

        $ticketMessage = new TicketMessage();
        $ticketMessage->ticket_id = $ticket->id;
        $ticketMessage->comment = strip_tags($request->comment_line);
        $ticketMessage->user_id = auth()->user()->id;
        $ticketMessage->save();
        
        $files = $request->file('attachments');
        
        $filesInfos = [];
        
        if(!empty($files))
        {
            $archive = Archive::get('tickets/ticket_'.$ticket->id.'/message_'.$ticketMessage->id);
            $ticketMessage->archive_id = $archive->id;
            $ticketMessage->save();
            
            foreach ( $files as $file )
            {
                $file  = $archive->addFile($file);
                
                $filesInfos[] = (object) [
                    'id' => $file->id,
                    'name' => $file->name(),
                    'url' => route('download_file', ['archive_id'=>$file->id]),
                ];
            }
        }

        $ticketMessage->echo();
        
        $results = [
            'id' =>  $ticketMessage->id,
            'comment' =>  $ticketMessage->comment,
            'user_id' =>  $ticketMessage->user_id,
            'user_name' =>  $ticketMessage->user->lang('name'),
            'created_from' =>  $ticketMessage->createdFrom(),
            'files_infos' =>  $filesInfos,
        ];
        
        $ticket->status = Ticket::STATUS_OPEN;
        $ticket->save();
        
        return response()->json($results);
    }
    
    /**
     *  Not Used [view not found]
     */
    public function add() {
        
        if(!auth()->user()->hasPermissionTo('add_tickets'))
            abort(401);

        $path = [
            (object) [
                'link' => route('tickets'),
                'title' => 'Tickets',
            ]
        ];

        $ticketTypes = TicketType::select('id', lang()."_name")->where('internal_type', 0)->pluck(lang().'_name', 'id')->toArray();
        
        return view('tickets.add', compact('path','ticketTypes'));
    }
        
    public function save(Request $request) { //dd($request->all());
        
            if(!auth()->user()->hasPermissionTo('add_tickets'))
                abort(401);
            
            $validatedData = $request->validate([
                'title'=>'required|string|max:256|min:4',
                'description'=>'nullable|string|max:1024',
                'ticket_type_id'=>'required|numeric',
                'attachments.*' => 'mimes:jpeg,png,jpg,pdf,doc,docx|max:2048'
            ]);

           
            
            $ticket = new Ticket();
            $ticket->fill($request->all());
            $ticket->status = 0;
            $ticket->user_id = auth()->id();
            $ticket->save();

            $files = $request->file('attachments');
        
            $filesInfos = [];
            
            if(!empty($files))
            {
                $archive = Archive::get('tickets/ticket_'.$ticket->id);
                $ticket->archive_id = $archive->id;
                $ticket->save();
                
                foreach ( $files as $file )
                {
                    $file  = $archive->addFile($file);
                    
                    $filesInfos[] = (object) [
                        'id' => $file->id,
                        'name' => $file->name(),
                        'url' => route('download_file', ['archive_id'=>$file->id]),
                    ];
                }
            }
         
            
            return redirect(route('show_ticket', ['id'=>$ticket->id]));
    }

    
    public function userFeedbak(Ticket $ticket, Request $request) {
        
        if(!$ticket->canOpen())
            abort(401);


        $validatedData = $request->validate([
            'user_satisfaction_level'=>'required|numeric',
            'user_feedback'=>'required|string|min:10',
        ]);
 
        $ticket->user_satisfaction_level = $request->user_satisfaction_level;
        $ticket->user_feedback = $request->user_feedback;
        $ticket->save();

        $ticket->logTicketAction(Ticket::ACTION_User_Feedback, $request->user_feedback);

        return redirect(route('tickets'));
    }
            
    public function delete(Ticket $ticket, Request $request) {
        
        if(!$ticket->canOpen())
            abort(401);

        if($ticket->messages()->count()==0) {
            $ticket->delete();
            
            return response()->json();
        } else {
            return response()->json(['error'=>true, 'message'=>'Ticket is not empty.']);
        }
    }
    
    public function signInTickets(){
        $path = [];
        
        $tickets = Ticket::orderBy('updated_at', 'desc')->where('user_id',\Auth::user()->id)->get();
        
        $lang = lang();
        $tickesTypes = TicketType::where('internal_type', 0)->pluck($lang."_name as name", "id")->toArray();
        
        return view('tickets.signin_tickets', compact('path', 'tickets', 'tickesTypes'));
    }
    
   

   
}
