<?php

namespace App\Http\Controllers;

use App;
use App\Bylaw;
use App\Country;
use App\Plan;
use App\Student;
use App\Term;
use App\User;
use App\Grade;
use App\GradeType;
use App\StudentSummerTermDecision;
use DB;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Maatwebsite\Excel\Facades\Excel;
use Spatie\Permission\Models\Role;
use Illuminate\Validation\Rule;
use Validator;

class StudentsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkStdPaymentStatus')->only(['show']);
    }

    public function main()
    {
        $path = [];

        return view('students.main', compact('path'));
    }

    public function buildQuery($parameters) {

        $lang = lang();

        $query = \DB::table('users')->select('users.id',
            'users.code',
            'users.email',
            'users.'.$lang.'_name as name',
            'plans.id as plan_id',
            'plans.bylaw',
            'students.graduated',
            'plans.'.$lang.'_major as major_name',
            'plans.'.$lang.'_minor as minor_name',
            'plans.'.$lang.'_program as program_name',
            'terms.id as term_id',
            'terms.'.$lang.'_name as term',
            'users.birth_date',
            'users.mobile')
            ->leftJoin('students', 'users.id', '=', 'students.id')
            ->leftJoin('plans', 'plans.id', '=', 'students.last_plan_id')
            ->leftJoin('terms', 'terms.id', '=', 'students.last_term_id')            
            ->leftJoin('years', 'years.id', '=', 'students.last_year_id')
            ->leftJoin('levels', 'levels.id', '=', 'students.last_level')
            ->orderBy($parameters->orderBy, $parameters->orderDir);

        $query->addSelect(\DB::raw('(CASE WHEN students.last_year_id<100 THEN years.'.$lang.'_name ELSE levels.'.$lang.'_name END) as stage_name'));

        /**/
        $query->leftJoin('grades_total', 'grades_total.student_id', '=', 'students.id');
        $query->addSelect('grades_total.total', 'grades_total.grade', 'grades_total.grade_gpa', 'grades_total.honour');
        $query->leftJoin('grades_terms', function($join) {
            $join->on('grades_terms.term_id', '=', 'students.last_term_id');
            $join->on('grades_terms.student_id', '=', 'students.id');
        });
        $query->addSelect('grades_terms.total as term_total', 'grades_terms.grade_type as term_grade', 'grades_terms.grade_gpa  as term_gpa', 'grades_terms.cumulative_gpa as term_cumulative_gpa', 'payment as term_payment');

        if ($parameters->textSearch) {
            $textSearch = mb_ereg_replace(" ", "%", getFTS($parameters->textSearch));
            $query->Where(\DB::raw("COALESCE(users.search_text,'')"), "like", "%$textSearch%");
        }

        if ($parameters->termId) {
            $query->Where('students.last_term_id', '=', $parameters->termId);
        }

        if ($parameters->graduated!==null) {
            $query->Where('students.graduated', '=', $parameters->graduated);
        }

        if ($parameters->bylaw) {
            $query->Where('plans.bylaw', '=', $parameters->bylaw);
        }

        if ($parameters->planId) {
            $query->Where('students.last_plan_id', '=', $parameters->planId);
        }

        if ($parameters->searchBirthFrom) {
            $query->where('users.birth_date', '>=', $parameters->searchBirthFrom);
        }

        if ($parameters->searchBirthTo) {
            $query->where('users.birth_date', '<=', $parameters->searchBirthTo);
        }

        if ($parameters->searchMilitaryStatus) {
            $query->where('students.military_status', '=', $parameters->searchMilitaryStatus);
        }

        $query->Where('users.type', '=', 3)->Where('users.active', '=', 1);

        return $query;
    }

    public function index(Request $request)
    {
        if (!auth()->user()->hasPermissionTo('access_students'))
            abort(401);

        if ($request->ajax()) {

            $parameters = (object)[];

            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];

            $parameters->orderBy = $columns[$order]["name"];
            $parameters->orderDir = $request->order[0]['dir'];

            $parameters->textSearch = $request->search['value'];
            $parameters->termId = $columns[0]["search"]["value"];
            $parameters->planId = $columns[1]["search"]["value"];
            $parameters->bylaw = $columns[2]["search"]["value"];
            $parameters->graduated = $columns[3]["search"]["value"];
            $parameters->searchBirthFrom = $columns[4]["search"]["value"];
            $parameters->searchBirthTo = $columns[5]["search"]["value"];
            $parameters->searchMilitaryStatus = $columns[6]["search"]["value"];

            $query = $this->buildQuery($parameters);

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            \Log::info('Result123:', [$query->toSql()]);

            $rows = $query->paginate($length);

            \Log::info('Result:', [$rows]);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $path[] = (object)[
            'link' => route("students_affairs"),
            'title' => __('tr.StudentsAffairs'),
        ];

        $terms = Term::select('id', 'en_name as name')->where('active', '=', 1)->orderBy('start_date', 'desc')->pluck('name', 'id')->toArray();

        $bylaws = Bylaw::orderBy('code', 'DESC')->get();

        return view('students.index', compact('path', 'terms', 'bylaws'));
    }

    public function show(Student $student)
    {
        

        if (!($student->id == auth()->user()->id || auth()->user()->hasPermissionTo('access_students')))
            abort(401);

        $path = [];

        if (auth()->user()->hasPermissionTo('access_students')) {
            $path[] = (object)[
                'link' => route("students"),
                'title' => __('tr.Students'),
            ];
        }

        $user = $student->user;

        $minorField = lang() . "_minor";
        $nameField = lang() . "_name";

        $plan = Plan::select(DB::raw("CONCAT(UPPER(plans.bylaw),',', ',',years.$nameField , plans.$minorField) as name"))
            ->leftJoin('years', 'plans.year_id', '=', 'years.id')
            ->where('plans.id', $student->last_plan_id)->first();

        $yearsGrades = $student->yearsGrades();

        $errors = [];

        $errors['code'] = ($student->user->code)?'':__('tr.Code');
        $errors['en_name'] = ($student->user->en_name)?'':__('tr.EnglishName');
        $errors['ar_name'] = ($student->user->ar_name)?'':__('tr.ArabicName');
        $errors['address'] = ($student->user->address)?'':__('tr.Address');
        $errors['birth_date'] = ($student->user->birth_date)?'':__('tr.BirthDate');
        $errors['en_country'] = ($student->birthCountry->en_name)?'':__('tr.English Country Name');
        $errors['ar_country'] = ($student->birthCountry->ar_name)?'':__('tr.Arabic Country Name');
        $errors['en_nationality'] = ($student->birthCountry->en_nationality)?'':__('tr.English Nationality Name');
        $errors['ar_nationality'] = ($student->birthCountry->ar_nationality)?'':__('tr.Arabic Nationality Name');
        $errors['grades_info'] = ($student->gradeTotal)?'':__('tr.No Grade Information');

        $errors['school_study_type'] = ($student->school_study_type)?'':__('tr.School Study Type');
        $errors['school_name'] = ($student->school_name)?'':__('tr.School Name');
        $errors['school_certificate_type'] = ($student->school_certificate_type)?'':__('tr.School Certificate Type');
        $errors['school_marks'] = ($student->school_marks)?'':__('tr.School Total Mark');

        if ($student->gradeTotal){
            $errors['faculty_approval_at'] = ($student->gradeTotal->faculty_approval_at)?'':__('tr.Faculty Approval');
            $errors['university_approval_at'] = ($student->gradeTotal->university_approval_at)?'':__('tr.University Approval');
        } else {
            $errors['faculty_approval_at'] = __('tr.Faculty Approval');
            $errors['university_approval_at'] = __('tr.University Approval');
        }

        if ($student->user->gender != '2'){
            $errors['military_age'] = ($student->military_age)?'':__('tr.Military Age');
            $errors['military_order_date'] = ($student->military_order_date)?'':__('tr.Military Order Date');
            $errors['military_order'] = ($student->military_order)?'':__('tr.Military Order');
        }

        if ($student->graduated){
            if ($student->gradeTotal){
                $errors['graduation_info'] = ($student->gradeTotal->termYear)?'':__('tr.Graduation Information');
                if (!$student->isCreditHours()){
                    $errors['cumulative_grade'] = ($student->gradeTotal->gerneralGrade)?'':__('tr.Cumulative Grade');
                    $errors['project_grade'] = ($student->gradeTotal->projectGrade)?'':__('tr.Project Grade');
                } else {
                    $errors['grade_gpa'] = ($student->gradeTotal->grade_gpa)?'':__('tr.Grade GPA');
                    $errors['project_gpa'] = ($student->gradeTotal->project_grade_gpa)?'':__('tr.Project GPA');
                }
            } else {
                $errors['graduation_info'] = __('tr.Graduation Information');
                if (!$student->isCreditHours()){
                    $errors['cumulative_grade'] = __('tr.Cumulative Grade');
                    $errors['project_grade'] = __('tr.Project Grade');
                } else {
                    $errors['grade_gpa'] = __('tr.Grade GPA');
                    $errors['project_gpa'] = __('tr.Project GPA');
                }
            }
        }

        if (!$student->isCreditHours()){
            if ($student->plan){
                $errors['current_year'] = ($student->plan)?'':__('tr.Current Year Information');
                $errors['current_specialization'] = ($student->plan)?'':__('tr.Speciality');
                $errors['program'] = ($student->plan)?'':__('tr.Program');
            } else {
                $errors['current_year'] = __('tr.Current Year Information');
                $errors['current_specialization'] = __('tr.Speciality');
                $errors['program'] = __('tr.Program');
            }
        } else{
            if (count($student->gradesTerms)){
                $errors['current_year'] = ($student->gradesTerms[count($student->gradesTerms)-1]->plan->year)?'':__('tr.Current Year Information');
            } else {
                $errors['current_year'] = __('tr.Current Year Information');
            }
            if ($student->gradeTotal){
                $errors['current_specialization'] = ($student->gradeTotal->plan)?'':__('tr.Speciality');
                $errors['division'] = ($student->gradeTotal->plan)?'':__('tr.Division');
            } else {
                $errors['current_specialization'] = __('tr.Speciality');
                $errors['division'] = __('tr.Division');
            }

        }

        $roles = Role::all();
        

        if(\Auth::user()->hasRole('Student')){
            Student::findOrfail(\Auth::user()->id);
            $checkStudent = 1;
        }else{
            $checkStudent = 0;
        }

        return view('students.show', compact('path', 'user', 'student', 'yearsGrades', 'plan','errors','roles','checkStudent'));
    }

    public function editInformation(Student $student)
    {
        if (!($student->id == auth()->user()->id || auth()->user()->hasPermissionTo('edit_students')))
            abort(401);

        $user = $student->user;
        $nameField = lang() . "_name";

        $bylaws = Bylaw::where('current', 1)->orderBy('code', 'DESC')->get();

        $countries = Country::select("id", lang() . "_name as name")->pluck('name', 'id')->toArray();

        $path[] = (object)[
            'link' => route('show_student', ['id' => $user->id]),
            'title' => $user->lang('name')
        ];

        return view('students.edit_information', compact('path', 'user', 'student', 'bylaws', 'countries'));
    }

    public function editParentInformation(Student $student)
    {
        if (!($student->id == auth()->user()->id || auth()->user()->hasPermissionTo('edit_students')))
            abort(401);

        $user = $student->user;

        $path[] = (object)[
            'link' => route('show_student', ['id' => $user->id]),
            'title' => $user->lang('name')
        ];

        return view('students.edit_parent_information', compact('path', 'user', 'student'));
    }

    public function saveInformation(Student $student, Request $request)
    {

        $user = $student->user;

        $this->validate($request, [
            'en_name' => 'required|max:255|min:7',
            'email' => 'required|email',
            'code' => 'required|alpha_num',
            'ar_name' => 'required|string',
        ]);

        $user->code = $request->code;
        $user->email = $request->email;
        $user->en_name = $request->en_name;
        $user->ar_name = $request->ar_name;
        $user->national_id = $request->national_id;
        $user->email_alt = $request->email_alt;
        $user->phone = $request->phone;
        $user->mobile = $request->mobile;
        $user->birth_date = $request->birth_date;
        $user->address = $request->address;
        $user->gender = $request->gender;
        $user->religion = $request->religion;
        $user->save();
        $user->updateFTS();

        $student->other_nationalities = $request->other_nationalities;
        $student->nationality_country_id = $request->nationality_country_id;
        $student->status = $request->status;
        $student->school_certificate_type = $request->school_certificate_type;
        $student->school_study_type = $request->school_study_type;
        $student->school_name = $request->school_name;
        $student->school_marks = $request->school_mark;
        $student->foreign_status = $request->foreign_status;
        $student->transferred_from_university = $request->transferred_from_university;
        $student->transferred_from_faculty = $request->transferred_from_faculty;
        $student->birth_country_id = $request->birth_country_id;
        $student->en_birth_city = $request->en_birth_city;
        $student->ar_birth_city = $request->ar_birth_city;
        $student->military_status = $request->military_status;
        $student->military_status_info = $request->military_status_info;
        $student->military_no = $request->military_no;
        $student->military_order = $request->military_order;
        $student->military_order_date = $request->military_order_date;
        $student->military_age = $request->military_age;
        $student->military_education_status = $request->military_education_status;
        $student->notes = $request->note;
        $student->parent_name = $request->parent_name;
        $student->parent_phone = $request->parent_phone;
        $student->parent_email = $request->parent_email;
        $student->parent_relation = $request->parent_relation;
        $student->parent_national_id = $request->parent_national_id;
        $student->save();

        if($student->graduated) {
            $student->gradeTotal->faculty_approval_at = $request->faculty_approval_at;
            $student->gradeTotal->university_approval_at = $request->university_approval_at;
            $student->gradeTotal->save();
        }


        return redirect(route('show_student', ['id' => $user->id]));
    }

    public function saveParentInformation(Student $student, Request $request)
    {

        $validatedData = $request->validate([
            'parent_name'=>'nullable|string|min:8',
            'parent_relation'=>'nullable|string',
            'parent_phone'=>'nullable|string',
            'parent_email'=>'nullable|email',
        ]);

        $user = $student->user;

        $student->parent_name = $request->parent_name;
        $student->parent_phone = $request->parent_phone;
        $student->parent_email = $request->parent_email;
        $student->parent_relation = $request->parent_relation;

        $student->save();

        return redirect(route('show_student', ['id' => $user->id]));
    }

    public function sheet(Request $request) {

        $parameters = (object)[];
        $parameters->orderBy = "students.id";
        $parameters->orderDir = "ASC";
        $parameters->textSearch = $request->text_search;
        $parameters->termId = $request->search_term_id;
        $parameters->planId = $request->search_plan_id;
        $parameters->bylaw = $request->search_bylaw;
        $parameters->graduated = $request->search_graduated;
        $parameters->searchBirthFrom = $request->search_birth_from;
        $parameters->searchBirthTo = $request->search_birth_to;
        $parameters->searchMilitaryStatus = $request->search_military_status;

        $query = $this->buildQuery($parameters);

        $data = $query->get();

        \Log::info('Request:', [$query->toSql()]);

        $gradesTypes = GradeType::labels();

        return Excel::create('Students Sheet', function($excel) use ($data, $gradesTypes) {

            $excel->sheet('Students Sheet', function($sheet) use ($data, $gradesTypes) {

                $cell = 'A';

                $sheet->setCellValue(($cell++).'1', 'code');
                $sheet->setCellValue(($cell++).'1', 'name');
                $sheet->setCellValue(($cell++).'1', 'email');
                $sheet->setCellValue(($cell++).'1', 'mobile');
                $sheet->setCellValue(($cell++).'1', 'birth date');
                $sheet->setCellValue(($cell++).'1', 'bylaw');
                $sheet->setCellValue(($cell++).'1', 'major');
                $sheet->setCellValue(($cell++).'1', 'minor');
                $sheet->setCellValue(($cell++).'1', 'stage');
                $sheet->setCellValue(($cell++).'1', 'track');
                $sheet->setCellValue(($cell++).'1', 'term');
                $sheet->setCellValue(($cell++).'1', 'term total');
                $sheet->setCellValue(($cell++).'1', 'term grade');
                $sheet->setCellValue(($cell++).'1', 'term gpa');
                $sheet->setCellValue(($cell++).'1', 'term cumulative gpa');
                $sheet->setCellValue(($cell++).'1', 'term payment');
                $sheet->setCellValue(($cell++).'1', 'graduated');
                $sheet->setCellValue(($cell++).'1', 'graduation total');
                $sheet->setCellValue(($cell++).'1', 'graduation grade');
                $sheet->setCellValue(($cell++).'1', 'graduation gpa');
                $sheet->setCellValue(($cell++).'1', 'honour');

                $i = 2;
                foreach ($data as $item){

                    $cell = 'A';

                    $sheet->setCellValue(($cell++).$i, $item->code);
                    $sheet->setCellValue(($cell++).$i, $item->name);
                    $sheet->setCellValue(($cell++).$i, $item->email);
                    $sheet->setCellValue(($cell++).$i, $item->mobile);
                    $sheet->setCellValue(($cell++).$i, $item->birth_date);
                    $sheet->setCellValue(($cell++).$i, $item->bylaw);
                    $sheet->setCellValue(($cell++).$i, $item->major_name);
                    $sheet->setCellValue(($cell++).$i, $item->minor_name);
                    $sheet->setCellValue(($cell++).$i, $item->stage_name);
                    $sheet->setCellValue(($cell++).$i, $item->program_name);
                    $sheet->setCellValue(($cell++).$i, $item->term);
                    $sheet->setCellValue(($cell++).$i, $item->term_total);
                    $sheet->setCellValue(($cell++).$i, ($item->term_grade)?$gradesTypes[$item->term_grade]:"");
                    $sheet->setCellValue(($cell++).$i, $item->term_gpa);
                    $sheet->setCellValue(($cell++).$i, $item->term_cumulative_gpa);
                    $sheet->setCellValue(($cell++).$i, $item->term_payment);
                    $sheet->setCellValue(($cell++).$i, $item->graduated);
                    $sheet->setCellValue(($cell++).$i, $item->total);
                    $sheet->setCellValue(($cell++).$i, ($item->grade)?$gradesTypes[$item->grade]:"");
                    $sheet->setCellValue(($cell++).$i, $item->grade_gpa);
                    $sheet->setCellValue(($cell++).$i, $item->honour);
                    $i++;
                }
            });

        })->download('xlsx');
    }

    public function report(Term $term, Plan $plan, Request $request)
    {

        $data = User::select('users.ar_name as name', 'plans.ar_minor', 'users.national_id as student_national_id',
            DB::raw("(CASE WHEN users.id IN (SELECT grades_terms.student_id FROM grades_terms ) THEN main_stream.ar_name 
                                 WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN graduate.ar_name
                                   END ) as grade"),
            DB::raw("(CASE WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN CASE WHEN grades_total.last_year_id = 100 THEN grades_total.grade_gpa ELSE grades_total.total END
                                 WHEN users.id IN (SELECT grades_terms.student_id FROM grades_terms ) THEN  grades_terms.total
                                 WHEN users.id IN (SELECT grades_current.student_id FROM grades_current ) THEN grades_current.grade_gpa
                                   END ) as total"),
            \DB::raw("(CASE WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN CASE WHEN grades_total.last_year_id = 100 THEN CONCAT(round((grades_total.grade_gpa/4)*100,2),'%') ELSE CONCAT(round((grades_total.total/(grades_total.year0_max+grades_total.year1_max+grades_total.year2_max+grades_total.year3_max+grades_total.year3_max))*100,2),'%') END 
                                   WHEN users.id IN (SELECT grades_terms.student_id FROM grades_terms ) THEN CONCAT(round((grades_terms.total/1500)*100,2),'%')
                                   WHEN users.id IN (SELECT grades_current.student_id FROM grades_current ) THEN CONCAT(round((grades_current.grade_gpa/4)*100,2),'%')
                                   END ) as student_Percent"),
            'countries.ar_name as nationality_ar_name', 'users.birth_date', 'cities.ar_name as birth_place', 'users.mobile', 'users.address', 'users.email', 'plans.year_id', 'users.gender')
            ->leftJoin('students', 'students.id', 'users.id')
            ->leftJoin('plans', 'students.last_plan_id', '=', 'plans.id')
            ->leftJoin('terms', 'students.last_term_id', '=', 'terms.id')
            ->leftJoin('grades_terms', 'grades_terms.student_id', '=', 'students.id')
            ->leftJoin('grades_total', 'grades_total.student_id', '=', 'students.id')
            ->leftJoin('grades_current', 'grades_current.student_id', '=', 'students.id')
            ->leftJoin('grades_types as main_stream', 'main_stream.id', '=', 'grades_terms.grade_type')
            ->leftJoin('grades_types as graduate', 'graduate.id', '=', 'grades_total.grade')
            ->leftJoin('countries', 'countries.id', '=', 'students.nationality_country_id')
            ->where('students.last_plan_id', $plan->id)
            ->where('students.last_term_id', $term->id)
            ->orderBy('total', 'DESC');
        if ($plan->year_id != 100) {
            $data = $data->where('grades_terms.plan_id', $plan->id)
                ->where('grades_terms.term_id', $term->id);
        }
        $data = $data->get();
        $title = "Students Report - $term->en_name - $plan->bylaw - " . $plan->year->en_name . " - $plan->en_minor";
        $data->students = $data;
        $data->term = $term;
        $data->plan = $plan;
        $data->columns = $request->columns;
        if ($plan->year_id == 100) {
            $report = new  App\Report\ReportSystem(null, null, 'ar', $data, 'students.Reports.creditStudent', 'A3', 'L', 'Header3' ,'','',$title);
        } else {
            $report = new  App\Report\ReportSystem(null, null, 'ar', $data, 'students.Reports.studentReport', 'A3', 'L', 'Header3','','',$title);
        }
        $report->build();

    }

    public function generalFirstStudent(Term $term, $limit = 1, $isCredit = 1)
    {
        $data = User::select('users.ar_name as name', 'plans.ar_minor', 'users.national_id as student_national_id',
            DB::raw("(CASE WHEN users.id IN (SELECT grades_terms.student_id FROM grades_terms ) THEN main_stream.ar_name 
                                 WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN graduate.ar_name
                                   END ) as grade"),
            DB::raw("(CASE WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN CASE WHEN grades_total.last_year_id = 100 THEN grades_total.grade_gpa ELSE grades_total.total END
                                 WHEN users.id IN (SELECT grades_terms.student_id FROM grades_terms ) THEN  grades_terms.total
                                 WHEN users.id IN (SELECT grades_current.student_id FROM grades_current ) THEN grades_current.grade_gpa
                                   END ) as total"),
            \DB::raw("(CASE WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN CASE WHEN grades_total.last_year_id = 100 THEN CONCAT(round((grades_total.grade_gpa/4)*100,2),'%') ELSE CONCAT(round((grades_total.total/(grades_total.year0_max+grades_total.year1_max+grades_total.year2_max+grades_total.year3_max+grades_total.year3_max))*100,2),'%') END 
                                   WHEN users.id IN (SELECT grades_terms.student_id FROM grades_terms ) THEN CONCAT(round((grades_terms.total/1500)*100,2),'%')
                                   WHEN users.id IN (SELECT grades_current.student_id FROM grades_current ) THEN CONCAT(round((grades_current.grade_gpa/4)*100,2),'%')
                                   END ) as student_Percent"),
            'countries.ar_name as nationality_ar_name', 'users.birth_date', 'cities.ar_name as birth_place', 'users.mobile', 'users.address', 'users.email', 'plans.year_id', 'users.gender' , 'users.code')
            ->leftJoin('students', 'students.id', 'users.id')
            ->leftJoin('plans', 'students.last_plan_id', '=', 'plans.id')
            ->leftJoin('terms', 'students.last_term_id', '=', 'terms.id')
            ->leftJoin('grades_terms', 'grades_terms.student_id', '=', 'students.id')
            ->leftJoin('grades_total', 'grades_total.student_id', '=', 'students.id')
            ->leftJoin('grades_current', 'grades_current.student_id', '=', 'students.id')
            ->leftJoin('grades_types as main_stream', 'main_stream.id', '=', 'grades_terms.grade_type')
            ->leftJoin('grades_types as graduate', 'graduate.id', '=', 'grades_total.grade')
            ->leftJoin('countries', 'countries.id', '=', 'students.nationality_country_id')
            ->where('students.last_term_id', $term->id)
            ->limit($limit)
            ->orderBy('total', 'DESC');
        if ($isCredit == 2) {
            $data = $data->where('plans.year_id', '=', 100)
                ->where('grades_total.grade_gpa', '!=', null)
                ->where('plans.bylaw', '=', 'UG2013')
                ->get();
        } else {
            $data = $data->where('grades_terms.term_id', $term->id)->get();
        }
        $title = "Students Report - $term->en_name ";
        $data->students = $data;
        $data->term = $term;
        $data->plan = null;
        if (!empty($data)) {
            if ($isCredit == 2) {
                $report = new  App\Report\ReportSystem(null, null, 'ar', $data, 'students.Reports.creditStudent', 'A3', 'L', 'Header3','','','First Student Report');
            } else {
                $report = new  App\Report\ReportSystem(null, null, 'ar', $data, 'students.Reports.studentReport', 'A3', 'L', 'Header3' , '','','First Student Report');
            }
            $report->build();
        }
    }

    public function firstStudent(Term $term, $isCredit = 1)
    {
        $plans = Student::select('students.last_plan_id', 'plans.id')
            ->leftJoin('plans', 'plans.id', '=', 'students.last_plan_id')
            ->leftJoin('terms', 'students.last_term_id', '=', 'terms.id')
            ->leftJoin('grades_total', 'grades_total.student_id', '=', 'students.id')
            ->groupBy('students.last_plan_id')
            ->where('students.last_term_id', '=', $term->id);
        if ($isCredit == 2) {
            $plans = $plans->where('plans.year_id', '=', 100)
                ->where('grades_total.grade_gpa', '!=', null)
                ->where('plans.bylaw', '=', 'UG2013')
                ->get();
        } else {
            $plans = $plans->where('plans.year_id', '=', 4)->get();
        }
        $student = [];
        foreach ($plans as $plan) {
            $data = Student::select('users.ar_name as name', 'plans.id', 'plans.ar_minor', 'grades_types.ar_name as grade', 'grades_total.honour',
                'countries.ar_name as nationality_ar_name', 'users.birth_date', 'cities.ar_name as birth_place', 'users.national_id as student_national_id', 'users.mobile', 'users.address',
                'users.gender', 'users.email', 'plans.year_id', 'users.code',
                DB::raw("(CASE WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN CASE WHEN grades_total.last_year_id = 100 THEN grades_total.grade_gpa ELSE grades_total.total END END ) as total"),
                \DB::raw("(CASE WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN CASE WHEN grades_total.last_year_id = 100 THEN CONCAT(round((grades_total.grade_gpa/4)*100,2),'%') ELSE CONCAT(round((grades_total.total/(grades_total.year0_max+grades_total.year1_max+grades_total.year2_max+grades_total.year3_max+grades_total.year3_max))*100,2),'%') END END ) as student_Percent"))
                ->leftJoin('users', 'students.id', '=', 'users.id')
                ->leftJoin('plans', 'plans.id', '=', 'students.last_plan_id')
                ->leftJoin('terms', 'students.last_term_id', '=', 'terms.id')
                ->leftJoin('grades_total', 'grades_total.student_id', '=', 'students.id')
                ->leftJoin('grades_types', 'grades_types.id', '=', 'grades_total.grade')
                ->leftJoin('countries', 'countries.id', '=', 'students.nationality_country_id')
                ->where('students.last_term_id', '=', $term->id)
                ->where('students.last_plan_id', '=', $plan->last_plan_id)
                ->orderBy('total', 'DESC')
                ->first();
            $student[] = $data;
        }

        if (!empty($data)) {
            $data->students = $student;
            $data->term = $term;
            $report = new  App\Report\ReportSystem(null, null, 'ar', $data, 'students.Reports.topStudentReport', 'A3', 'L', 'Header3','','','First Student Report');
            $report->build();
        }
    }

    public function cities(Country $country) {
        $result = $country->cities()->select('id', lang().'_name as name')->get()->toArray();
        return response()->json($result);
    }

    public function statistics(Request $request)
    {

        if ($request->ajax()) {
            $minorField = lang() . "_minor";
            $nameField = lang() . "_name";

            $statisticsData = User::select(DB::raw('COUNT(case when users.gender="0" then 1 end) as male'), DB::raw('COUNT(case when users.gender="1" then 1 end) as female'),
                DB::raw("CONCAT(UPPER(plans.bylaw),',', ',',years.$nameField , plans.$minorField) as name"), "years.ar_name", 'plans.ar_major', 'plans.ar_minor')
                ->leftJoin('students', 'students.id', '=', 'users.id')
                ->leftJoin('plans', 'plans.id', '=', 'students.last_plan_id')
                ->leftJoin('years', 'years.id', '=', 'plans.year_id')
                ->where('students.last_term_id', '=', 69)
                ->where('plans.year_id', '!=', 100)
                ->groupBy('students.last_plan_id')->get();
            return response()->json($statisticsData);
        }

        $path = [];

        $terms = Term::select('id', 'en_name as name')->where('active', '=', 1)->orderBy('start_date', 'desc')->pluck('name', 'id')->toArray();

        $bylaws = Bylaw::orderBy('code', 'DESC')->get();

        return view('students.statistics', compact('path', 'terms', 'bylaws'));
    }

    public function foreignStudentReport(Term $term)
    {

        $students = User::select('users.ar_name as name', 'countries.ar_name as nationality'/*, 'students.faculty'*/,
            'plans.ar_major', 'years.ar_name as year_name', 'users.mobile', 'users.address', 'students.foreign_status')
            ->leftJoin('students', 'students.id', '=', 'users.id')
            ->leftJoin('plans', 'plans.id', '=', 'students.last_plan_id')
            ->leftJoin('years', 'years.id', '=', 'plans.year_id')
            ->leftJoin('countries', 'countries.id', '=', 'students.nationality_country_id')
            ->where('students.status', '=', 2)
            ->where('students.last_term_id', '=', $term->id)
            ->get();

        $report = new  App\Report\ReportSystem(null, null, 'ar', $students, 'students.Reports.foreignStudentReport', 'A4', 'L', 'Header3','','','Foreign Student Report');
        $report->build();


    }

    public function updateStudent($id){
        
        $path = [];
        $student = Student::findOrfail($id);

        if(!$student->isThisMyInfo())
            abort(401);

        $user = User::findOrfail($id);
        $data = (object)[];
        $data->ar_name = $user->ar_name;
        $data->en_name = $user->en_name;
        $data->birth_date = $user->birth_date;
        $data->email_alt = $user->email_alt;
        $data->gender = $user->gender;
        $data->address = $user->address;
        $data->mobile = $user->mobile;
        $data->phone = $user->phone;
        $data->first_name = $user->first_name;
        $data->middle_name = $user->middle_name;
        $data->last_name = $user->last_name;
        $data->second_address_line = $user->second_address_line;
        $data->postal_code = $user->postal_code;
        $data->passport = $student->passport;
        $data->more = "";        

        if($student->modifications != null) {
            $modifications = json_decode($student->modifications);
            if(isset($modifications->ar_name)) $data->ar_name = $modifications->ar_name;
            if(isset($modifications->en_name)) $data->en_name = $modifications->en_name;
            if(isset($modifications->birth_date)) $data->birth_date = $modifications->birth_date;
            if(isset($modifications->email_alt)) $data->email_alt = $modifications->email_alt;
            if(isset($modifications->gender)) $data->gender = $modifications->gender;
            if(isset($modifications->address)) $data->address = $modifications->address;
            if(isset($modifications->mobile)) $data->mobile = $modifications->mobile;
            if(isset($modifications->phone)) $data->phone = $modifications->phone;
            if(isset($modifications->more)) $data->more = $modifications->more;
            if(isset($modifications->first_name)) $data->first_name = $modifications->first_name;
            if(isset($modifications->middle_name)) $data->middle_name = $modifications->middle_name;
            if(isset($modifications->last_name)) $data->last_name = $modifications->last_name;
            if(isset($modifications->second_address_line)) $data->second_address_line = $modifications->second_address_line;
            if(isset($modifications->postal_code)) $data->postal_code = $modifications->postal_code;
            if(isset($modifications->passport)) $data->passport = $modifications->passport;

        }

        $data = (array)$data;
        return view('students.edit_student',compact('path', 'student', 'user', 'data'));
    }

    public function updateStudentPost(Request $request, Student $student) {

        if(!$student->isThisMyInfo())
            abort(401);

        $this->validate($request, [
            'email_alt' => 'required|email|max:255|min:7',
            'birth_date' => 'required|date|before:today',
            'en_name' => 'required|max:255|min:7',
            'ar_name' => 'required|string|max:255|min:7',
            'mobile' => 'required|string|max:64|min:7',
            'phone' => 'nullable|string|max:64|min:7',
            'address' => 'nullable|string|max:255|min:7',
            'more' => 'nullable|string|max:255|min:7',
            'first_name' => 'required|max:255|min:2',
            'middle_name' => 'required|max:255|min:2',
            'last_name' => 'required|max:255|min:2',
        ]);

        $modifications = $request->all();

        unset($modifications['_token']);
        $student->modifications = json_encode($modifications, JSON_UNESCAPED_UNICODE);
        $student->status |= Student::STATUS_MODIFY_REQUEST;
        $student->save();
        
        return redirect()->route('show_student', $student->id);
    }

    public function summerTermDecision(Request $request)
    {
        $student = auth()->user()->student;

        if(!$student->askForSummerTermDecision())
            return response()->json(['You are not permitted to do this action at this time'], 401);


        $validator = Validator::make($request->all(), [
            'decision' => 'required|numeric|'. Rule::in([0,1]),
        ]);


        if ($validator->fails()) {
            return response()->json($validator->errors()->all(), 401);
        }

        $summerTerm = Term::where('term_type', Term::SUMMER)->orderBy('id', 'DESC')->first();
        $decision = $request->decision;

        StudentSummerTermDecision::create([
            'student_id' => auth()->id(),
            'term_id' => $summerTerm->id,
            'decision' => $decision ,
        ]);

        if($decision == 1){
            $student->last_term_id = $summerTerm->id;
            $student->save();
        }
        

        return response()->json(['status' => 'success', 'msg'=> 'Your decision has been registered successfully'], 200);

    }

}
