<?php

namespace App\Http\Controllers;

use App\Bylaw;
use App\Course;
use App\Plan;
use App\Student;
use App\Study;
use App\Grade;
use App\Section;
use App\Term;
use App\Ticket;
use App\Setting;
use App\User;
use App\Department;
use App\Committee;
use App\CoursePrerequisite;
use App\ExamsCommittee;
use App\Exams;
use App\FacultyLocation;
use DB;
use PDF;
use App\Archive;
use TCPDF_FONTS;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Carbon;
use Maatwebsite\Excel\Facades\Excel;

class StudiesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkStdPaymentStatus')->only('studentCourses','coursesActions');
    }

    public function main(){
        $path = [];
        return view('study.home',compact('path'));
    }

    /**
     * Show the study course page.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (!auth()->user()->hasPermissionTo('access_studies'))
            abort(401);

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $termId = $columns[0]["search"]["value"];
            $role = $columns[1]["search"]["value"];
            $bylaw = $columns[2]["search"]["value"];
            $planId = $columns[3]["search"]["value"];
            $courseId = $columns[4]["search"]["value"];
            $userId = $columns[5]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $lang = lang();

            $query = \DB::table('studies')
                ->select(\DB::raw("studies.id, studies.user_id, users.type, CONCAT(users.code,': ', users.en_name) as user, studies.course_id, CONCAT(UPPER(courses.bylaw), ':', courses.code, ': ', courses.en_name) as course, studies.role, studies.term_id, studies.plan_id, CONCAT(UPPER(plans.bylaw), ':', CASE WHEN plans.year_id<100 THEN years.".$lang."_name ELSE plans.".$lang."_program END, ', ',plans.".$lang."_minor) as plan_name, terms.".$lang."_name as term_name, CONCAT('G:', COALESCE(studies.group,'-'), ', S:', COALESCE(studies.section,'-')) as group_section"))
                ->leftjoin('plans','studies.plan_id','=','plans.id')
                ->leftjoin('years','years.id','=','plans.year_id')
                ->leftjoin('users','studies.user_id','=','users.id')
                ->leftjoin('courses','studies.course_id','=','courses.id')
                ->leftjoin('terms','studies.term_id','=','terms.id')
                ->orderBy($orderBy, $orderDir);

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $query->Where(\DB::raw("CONCAT(COALESCE(users.search_text,''), ' ', COALESCE(courses.search_text,''))") , "like", "%$textSearch%");
            }

            if ($role) {
                $query->where('studies.role', '=', $role);
            }

            if ($bylaw) {
                $query->where('courses.bylaw', '=', $bylaw);
            }

            if ($planId) {
                $query->where('studies.plan_id', '=', $planId);
            }

            if ($userId) {
                $query->where('studies.user_id', '=', $userId);
            }

            if ($courseId) {
                $query->where('studies.course_id', '=', $courseId);
            }

            if ($termId) {
                $query->where('studies.term_id', '=', $termId);
            }

            \Log::info('Request:', [$query->toSql()]);

            $rows = $query->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $path = [
            (object)[
                'link' => route('study'),
                'title' => __('tr.Study'),
            ],
        ];

        $terms = Term::select('id', 'en_name as name')->where('active', '=', 1)->orderBy('start_date', 'desc')->pluck('name', 'id')->toArray();

        $openTerms = Term::select('id', 'en_name as name')
                        ->whereRaw(\DB::raw('(end_date >= NOW() AND start_date <= NOW()) OR (start_date >= NOW() AND end_date >= NOW())'))
                        ->where('active', '=', 1)
                        ->orderBy('start_date', 'desc')
                        ->pluck('name', 'id')->toArray();

        $roles = Study::roles();

        $currentTermId = Term::currentTerm()->id;

        $bylaws = Bylaw::where('current', 1)->orderBy('code', 'DESC')->get();

        return view('study.studies.index', compact('path', 'terms', 'openTerms', 'roles', 'currentTermId', 'bylaws'));
    }

    public function add(Request $request)
    {
        if (!auth()->user()->hasPermissionTo('edit_studies'))
            abort(401);

        $validatedData = $request->validate([
            'term_id'=>'required|numeric',
            'role'=>'required|numeric',
            'course_id'=>'required|numeric',
        ]);

        $usersIDs = $request->users_ids;
        $plansIds = $request->plans_ids;

        $result = (object) [
            'plan_id'=>$request->plan_id,
            'term_id'=>$request->term_id,
            'role'=>$request->role,
        ];

        foreach ($plansIds as $planId) {
            foreach ($usersIDs as $userId) {

                if(Study::where('term_id', $request->term_id)
                    ->where('role', $request->role)
                    ->where('course_id', $request->courseId)
                    ->where('plan_id', $planId)
                    ->where('user_id', $userId)
                    ->exists()) continue;

                $study = new Study();
                $study->term_id = $request->term_id;
                $study->role = $request->role;
                $study->course_id = $request->course_id;
                $study->plan_id = $planId;
                $study->user_id = $userId;
                $study->save();
            }
        }

        return response()->json($result);
    }

    /**
     * Delete the study record
     *
     * @return \Illuminate\Http\Response
     */
    public function delete(Study $study)
    {
        if (!auth()->user()->hasPermissionTo('delete_studies'))
            abort(401);

        $study->delete();
        die('done');
    }

    public function courses(Term $term, Plan $plan)
    {
        $nameField = lang()."_name";
        if(lang()=="ar")
            $otherNameField = "en_name";
        else
            $otherNameField = "ar_name";
        $student = __('tr.Student');
        $role = Study::ROLE_STUDENT;

        $sql = "SELECT studies.course_id as id, CONCAT(courses.code, ': ', courses.$nameField, ' (', count(*), ' $student)', ' - ', courses.$otherNameField) as name FROM studies INNER JOIN courses ON courses.id = studies.course_id WHERE studies.role = $role  AND studies.term_id = $term->id AND studies.plan_id = $plan->id GROUP BY course_id ORDER BY courses.code ASC, count(*) DESC";

        \Log::info('SQL:', [$sql]);

        $result = \DB::select($sql);


        return response()->json($result);
    }

    public function bylawsPlans($bylaw) {

        $lang = lang();

        $sql = "SELECT plans.id, CONCAT(CASE WHEN plans.year_id<100 THEN years.".$lang."_name ELSE COALESCE(plans.".$lang."_program, '') END, ', ',plans.".$lang."_minor) as name FROM plans INNER JOIN years ON plans.year_id = years.id WHERE plans.bylaw = '$bylaw' ORDER BY plans.year_id, plans.code ASC";

        $result = \DB::select($sql);

        return response()->json($result);
    }

    public function bylawsDepartmentsPlans($bylaw, $departmentId) {
        
        $lang = lang();

        $department = Department::find($departmentId);

        $sqlDepartments = "";// = "AND minor_department_id is null";
        if($department)
            $sqlDepartments = "AND minor_department_id = $department->id";

        $sql = "SELECT plans.id, CONCAT(CASE WHEN plans.year_id<100 THEN years.".$lang."_name ELSE COALESCE(plans.".$lang."_program, '') END, ', ',plans.".$lang."_minor) as name FROM plans INNER JOIN years ON plans.year_id = years.id WHERE plans.bylaw = '$bylaw' $sqlDepartments ORDER BY plans.year_id, plans.code ASC";

        $result = \DB::select($sql);

        return response()->json($result);
    }

    public function coursesPlans(Course $course)
    {
        $lang = lang();

        $result = \DB::select("SELECT plans.id, CONCAT(CASE WHEN plans.year_id<100 THEN years.".$lang."_name ELSE COALESCE(plans.".$lang."_program, '') END, ', ',plans.".$lang."_minor) as name FROM plans INNER JOIN years ON plans.year_id = years.id WHERE plans.bylaw = '$course->bylaw' ORDER BY plans.year_id, plans.code ASC");

        \Log::info('Request:', [$result]);

        return response()->json($result);
    }

    public function plans(Term $term, Course $course)
    {
        $majorField = lang()."_major";
        $minorField = lang()."_minor";
        $nameField = lang()."_name";
        $student = __('tr.Student');
        $role = Study::ROLE_STUDENT;

        $sql = "SELECT studies.plan_id as id, CONCAT(UPPER(plans.bylaw), ',', years.$nameField, ',', plans.$minorField, ' (', COUNT(*), ' $student)') as name FROM studies INNER JOIN courses ON courses.id = studies.course_id INNER JOIN plans ON plans.id = studies.plan_id INNER JOIN years ON plans.year_id = years.id WHERE studies.term_id = $term->id AND studies.role = $role AND courses.code = '$course->code' GROUP BY studies.plan_id ORDER BY name";

        \Log::info('SQL:', [$sql]);

        $result = \DB::select($sql);

        return response()->json($result);
    }

    public function userCourses(Term $term, User $user)
    {
        //dd($term->id. " - " .$user->id);
        $courseName = lang()."_name";
        $role = Study::ROLE_TEACHER;

        $result = Study::select('courses.id','courses.code',"courses.$courseName as name","studies.term_id","studies.plan_id","faculty_locations.name as location_name")
            ->join('courses','courses.id','studies.course_id')
            ->join('proctoring_committees_courses','proctoring_committees_courses.course_id','studies.course_id')
            ->join('faculty_locations','faculty_locations.id','proctoring_committees_courses.course_id')
            ->where('studies.user_id',$user->id)
            ->where('studies.term_id',$term->id)
            ->where('studies.role',$role)
            ->get();

        return response()->json($result);
    }

    public function locations(Term $term,Course $course) { 

        $role = Study::ROLE_STUDENT;

        $locations = \DB::select("SELECT faculty_locations.id as id, CONCAT(faculty_locations.name, ' (', proctoring_committees_courses.num_students ,')' ) AS name 
                FROM faculty_locations 
                INNER JOIN proctoring_committees_courses ON proctoring_committees_courses.location_id = faculty_locations.id 
                INNER JOIN studies ON studies.course_id = proctoring_committees_courses.course_id 
                WHERE proctoring_committees_courses.course_id = $course->id
                AND studies.term_id = $term->id
                AND studies.role = $role
                GROUP BY faculty_locations.id 
                ORDER BY name");

        /*$locations = FacultyLocation::select('faculty_locations.id','faculty_locations.name','proctoring_committees_courses.num_students')
            ->join('proctoring_committees_courses','proctoring_committees_courses.location_id','faculty_locations.id')
            ->join('studies','studies.course_id','proctoring_committees_courses.course_id')
            ->where('proctoring_committees_courses.course_id',$course->id)
            ->where('studies.term_id',$term->id)
            ->where('role',Study::ROLE_STUDENT)
            ->groupBy('faculty_locations.id')
            ->orderBy('name')
            ->get();*/


        return response()->json($locations);
    }

    public function getStudies(Request $request) {

        $textSearch = $request->text_search;
        $bylaw = $request->search_bylaw;
        $planId = $request->search_plan_id;
        $userId = $request->search_user_id;
        $courseId = $request->search_course_id;
        $termId = $request->search_term_id;

        $query = User::select('users.ar_name as name', 'users.code as user_code','courses.ar_name as course','plans.ar_minor', 'users.national_id as student_national_id',
            DB::raw("(CASE WHEN users.id IN (SELECT grades_terms.student_id FROM grades_terms ) THEN main_stream.ar_name
                WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN graduate.ar_name
                END ) as grade"),
            DB::raw("(CASE WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN CASE WHEN grades_total.last_year_id = 100 THEN grades_total.grade_gpa ELSE grades_total.total END
                WHEN users.id IN (SELECT grades_terms.student_id FROM grades_terms ) THEN  grades_terms.total
                WHEN users.id IN (SELECT grades_current.student_id FROM grades_current ) THEN grades_current.grade_gpa
                END ) as total"),
            \DB::raw("(CASE WHEN users.id IN (SELECT grades_total.student_id FROM grades_total ) THEN CASE WHEN grades_total.last_year_id = 100 THEN CONCAT(round((grades_total.grade_gpa/4)*100,2),'%') ELSE CONCAT(round((grades_total.total/(grades_total.year0_max+grades_total.year1_max+grades_total.year2_max+grades_total.year3_max+grades_total.year3_max))*100,2),'%') END
                WHEN users.id IN (SELECT grades_terms.student_id FROM grades_terms ) THEN CONCAT(round((grades_terms.total/1500)*100,2),'%')
                WHEN users.id IN (SELECT grades_current.student_id FROM grades_current ) THEN CONCAT(round((grades_current.grade_gpa/4)*100,2),'%')
                END ) as student_Percent"),
            'countries.ar_name as nationality_ar_name', 'users.birth_date', 'cities.ar_name as birth_place', 'users.mobile', 'users.address', 'users.email', 'plans.year_id', 'users.gender')
            ->leftJoin('students', 'students.id', 'users.id')
            ->leftJoin('studies', 'studies.user_id', 'users.id')
            ->leftjoin('courses','studies.course_id','=','courses.id')
            ->leftJoin('plans', 'students.last_plan_id', '=', 'plans.id')
            ->leftJoin('terms', 'students.last_term_id', '=', 'terms.id')
            ->leftJoin('grades_terms', 'grades_terms.student_id', '=', 'students.id')
            ->leftJoin('grades_total', 'grades_total.student_id', '=', 'students.id')
            ->leftJoin('grades_current', 'grades_current.student_id', '=', 'students.id')
            ->leftJoin('grades_types as main_stream', 'main_stream.id', '=', 'grades_terms.grade_type')
            ->leftJoin('grades_types as graduate', 'graduate.id', '=', 'grades_total.grade')
            ->leftJoin('countries', 'countries.id', '=', 'students.nationality_country_id')
            ->leftJoin('cities', 'cities.id', '=', 'students.birth_city_id')
            ->orderBy('users.ar_name', 'asc')
            ->groupBy('users.id')
            ->where('studies.role', '=', 1);

        if ($textSearch) {
            $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
            $query->Where(\DB::raw("CONCAT(COALESCE(users.search_text,''), ' ', COALESCE(courses.search_text,''))") , "like", "%$textSearch%");
        }

        if ($bylawId) {
            $query->where('courses.bylaw', '=', $bylawId);
        }

        if ($planId) {
            $year = Plan::find($planId)->year_id;
            if ($year != 100) {
                $query = $query->where('grades_terms.plan_id', $planId)
                    ->where('grades_terms.term_id', $termId);
            }
            $query->where('studies.plan_id', '=', $planId);
        }

        if ($userId) {
            $query->where('studies.user_id', '=', $userId);
        }

        if ($courseId) {
            $query->where('studies.course_id', '=', $courseId);
        }

        if ($termId) {
            $query->where('studies.term_id', '=', $termId);
        }

        return $query->get();
    }

    public function sheet(Request $request) {

        if (!auth()->user()->hasPermissionTo('access_studies'))
            abort(401);

        $data = $this->getStudies($request);

        //\Log::info('Request:', [$query->toSql()]);

        $collegeYear = Carbon::now();
        if ($collegeYear->month > 6){
            $collegeYear = $collegeYear->year.'/'.($collegeYear->year+1);
        } else {
            $collegeYear = ($collegeYear->year-1).'/'.$collegeYear->year;
        }

        return Excel::create('Students Sheet', function($excel) use ($collegeYear,$data){

            $excel->sheet('Students Sheet', function($sheet) use ($collegeYear,$data) {
                $sheet->mergeCells('B1:F1');
                $sheet->mergeCells('A2:B2');
                $sheet->mergeCells('A3:B3');
                $sheet->mergeCells('D2:G2');
                $sheet->mergeCells('D3:E3');
                $sheet->mergeCells('F3:G3');

                $sheet->getStyle('B1')->applyFromArray(['font' => ['bold' => true,'size' => 14]]);
                $sheet->getStyle('B1')->getAlignment()->applyFromArray(['horizontal' => 'center']);

                $sheet->getStyle('A2')->applyFromArray(['font' => ['bold' => true]]);
                $sheet->getStyle('A2')->getAlignment()->applyFromArray(['horizontal' => 'center']);

                $sheet->getStyle('A3')->applyFromArray(['font' => ['bold' => true]]);
                $sheet->getStyle('A3')->getAlignment()->applyFromArray(['horizontal' => 'center']);

                $sheet->getStyle('D2')->applyFromArray(['font' => ['bold' => true]]);
                $sheet->getStyle('D2')->getAlignment()->applyFromArray(['horizontal' => 'center']);

                $sheet->getStyle('D3')->getAlignment()->applyFromArray(['horizontal' => 'right']);
                $sheet->row(4, function($row) {
                    $row->setBackground('#c0c0c0');
                });


                $sheet->getStyle('A4:G4')->getAlignment()->applyFromArray(['horizontal' => 'center']);

                $sheet->setCellValue('B1', 'كشوف لرصد درجات أعمال السنة والشفوي/عملي');
                $sheet->setCellValue('A2', 'الفرقة: ');
                $sheet->setCellValue('A3', 'المادة: ');
                $sheet->setCellValue('C2', '');
                $sheet->setCellValue('C3', '');
                $sheet->setCellValue('D2', 'للعام الجامعي '.$collegeYear);
                $sheet->setCellValue('D3', 'النهاية العظمي');

                $sheet->setCellValue('A4', 'الكود');
                $sheet->setCellValue('B4', 'رقم الجلوس');
                $sheet->setCellValue('C4', 'الإسم');
                $sheet->setCellValue('D4', 'حالة القيد');
                $sheet->setCellValue('E4', 'الفصل');
                $sheet->setCellValue('F4', 'اعمال السنه');
                $sheet->setCellValue('G4', 'شفوى/عملي');

                $sheet->setRightToLeft(true);

                $i = 5;
                foreach ($data as $item){
                    $sheet->setCellValue("A$i", " ".(string)$item->user_code);
                    $sheet->setCellValue("B$i", '');
                    $sheet->setCellValue("C$i", $item->name);
                    $sheet->setCellValue("D$i", $item->grade);
                    $sheet->setCellValue("E$i", $item->section);
                    $sheet->setCellValue("F$i", '');
                    $sheet->setCellValue("G$i", '');
                    $i++;
                }

                $sheet->getStyle("A5:B$i")->getAlignment()->applyFromArray(['horizontal' => 'center']);
                $sheet->getStyle("D5:D$i")->getAlignment()->applyFromArray(['horizontal' => 'right']);
                $sheet->getStyle("D5:G$i")->getAlignment()->applyFromArray(['horizontal' => 'center']);
                //Inner Borders
                $sheet->cell("A2", function($cell){
                    $cell->setBorder('thin','thin','thin','thin');
                });
                $sheet->cell("A3", function($cell){
                    $cell->setBorder('thin','thin','thin','thin');
                });
                $sheet->cell("C2", function($cell){
                    $cell->setBorder('thin','thin','thin','thin');
                });
                $sheet->cell("C3", function($cell){
                    $cell->setBorder('thin','thin','thin','thin');
                });
                $sheet->cell("D2", function($cell){
                    $cell->setBorder('thin','thin','thin','thin');
                });
                $sheet->cell("D3", function($cell){
                    $cell->setBorder('thin','thin','thin','thin');
                });

                $char = 'A';
                for ($j=4;$j<=$i;$j++){
                    $sheet->cell($char.$j, function($cell){
                        $cell->setBorder('thin','thin','thin','thin');
                    });
                    if ($j==($i-1) && $char != 'G'){
                        $j=3;
                        $char++;
                    } elseif($char == 'G' && $j==($i-1)){
                        break;
                    }
                }

                //Outer Borders
                $sheet->cell("D2", function($cell){
                    $cell->setBorder('none','thick','none','none');
                });
                $sheet->cell("F3", function($cell){
                    $cell->setBorder('thin','thick','thin','thin');
                });
                $i--;
                $sheet->cell("A2:G$i", function($cell){
                    $cell->setBorder('thick','thick','thick','thick');
                });

            });
        })->download();
    }

    public function export(Request $request) {

        $textSearch = $request->text_search;
        $bylaw = $request->search_bylaw;
        $planId = $request->search_plan_id;
        $userId = $request->search_user_id;
        $courseId = $request->search_course_id;
        $termId = $request->search_term_id;
        $role = $request->search_role;
        $lang = lang();

        $query = \DB::table('studies')
            ->select(\DB::raw("studies.id, users.code as code, users.email as email, users.".$lang."_name as name,  courses.code as course_code, courses.".$lang."_name as course_name, role, courses.bylaw, plans.code as plan_code, plans.".$lang."_major as major, plans.".$lang."_minor as minor, years.".$lang."_name as year, departments.code as department"))
            ->leftjoin('plans','studies.plan_id','=','plans.id')
            ->leftjoin('years','years.id','=','plans.year_id')
            ->leftjoin('users','studies.user_id','=','users.id')
            ->leftjoin('courses','studies.course_id','=','courses.id')
            ->leftjoin('terms','studies.term_id','=','terms.id')
            ->leftjoin('departments','departments.id','=','courses.offering_department_id')
            ->orderBy('department','plan_code', 'course_code', 'role', 'code');

        if ($textSearch) {
            $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
            $query->Where(\DB::raw("CONCAT(COALESCE(users.search_text,''), ' ', COALESCE(courses.search_text,''))") , "like", "%$textSearch%");
        }

        if ($role) {
            $query->where('studies.role', '=', $role);
        }

        if ($bylaw) {
            $query->where('courses.bylaw', '=', $bylaw);
        }

        if ($planId) {
            $query->where('studies.plan_id', '=', $planId);
        }

        if ($userId) {
            $query->where('studies.user_id', '=', $userId);
        }

        if ($courseId) {
            $query->where('studies.course_id', '=', $courseId);
        }

        if ($termId) {
            $query->where('studies.term_id', '=', $termId);
        }

        $data = $query->get();

        \Log::info('Request:', [$query->toSql()]);

        return Excel::create('Students Sheet', function($excel) use ($data) {

            $excel->sheet('Students Sheet', function($sheet) use ($data) {

                $sheet->setCellValue('A1', 'code');
                $sheet->setCellValue('B1', 'email');
                $sheet->setCellValue('C1', 'name');
                $sheet->setCellValue('D1', 'course_code');
                $sheet->setCellValue('E1', 'course_name');
                $sheet->setCellValue('F1', 'role');
                $sheet->setCellValue('G1', 'bylaw');
                $sheet->setCellValue('H1', 'plan_code');
                $sheet->setCellValue('I1', 'year');
                $sheet->setCellValue('J1', 'major');
                $sheet->setCellValue('K1', 'minor');
                $sheet->setCellValue('L1', 'offering_department_code');

                $i = 2;
                foreach ($data as $item){
                    $sheet->setCellValue('A'.$i, $item->code);
                    $sheet->setCellValue('B'.$i, $item->email);
                    $sheet->setCellValue('C'.$i, $item->name);
                    $sheet->setCellValue('D'.$i, $item->course_code);
                    $sheet->setCellValue('E'.$i, $item->course_name);
                    $sheet->setCellValue('F'.$i, Study::roleTextId($item->role));
                    $sheet->setCellValue('G'.$i, $item->bylaw);
                    $sheet->setCellValue('H'.$i, $item->plan_code);
                    $sheet->setCellValue('I'.$i, $item->year);
                    $sheet->setCellValue('J'.$i, $item->major);
                    $sheet->setCellValue('K'.$i, $item->minor);
                    $sheet->setCellValue('L'.$i, $item->department);
                    $i++;
                }
            });

        })->download('xlsx');
    }


    private static $usersIds = [];

    private static function getCashedUserId($code, $email = null, $name = null, $role = null) {

        $key = "";
        if($code) $key .= ".".$code;
        if($email) $key .= ".".$email;

        if(array_key_exists($key, StudiesController::$usersIds))
            return StudiesController::$usersIds[$key];

        $userId = null;
        if($code)
            $userId = User::where('code', $code)->value('id');
        else if($email)
            $userId = User::where('email', $email)->value('id');

        if(empty($userId) && $name && $role) {
            if($role=="student") {
                $student = Student::add(strtoupper($code), $name);
                if($student)$userId = $student->id;
            } else if(substr(strtolower($code), 0, 1)=="e") {
                $user = User::add(strtoupper($code), $name, $name, $email, User::TYPE_EXTERNAL_INSTRUCTOR);
                if($user)$userId = $user->id;
            }
        }

        StudiesController::$usersIds[$key] = $userId;

        return $userId;
    }

    public static $coursesIds = [];

    public static function getCashedCourseId($code, $bylaw) {

        $key = "$code.$bylaw";

        if(array_key_exists($key, StudiesController::$coursesIds))
            return StudiesController::$coursesIds[$key];

        $courseId = Course::where('code', $code)->where('bylaw', $bylaw)->value('id');

        StudiesController::$coursesIds[$key] = $courseId;

        return $courseId;
    }

    public static $plansIds = [];

    public static function getCashedPlanId($code, $yearId = null, $oldMajorCode = null, $oldMinorCode = null) {

        $key = "";
        if($code) $key .= ".".$code;
        if($yearId) $key .= ".".$yearId;
        if($oldMajorCode) $key .= ".".$oldMajorCode;
        if($oldMinorCode) $key .= ".".$oldMinorCode;

        if(array_key_exists($key, StudiesController::$plansIds))
            return StudiesController::$plansIds[$key];

        $planId = null;
        if($code)
            $planId = Plan::where('code', $code)->value('id');
        else if($yearId!==null && $oldMajorCode!==null && $oldMinorCode!==null)
            $planId = Plan::where('year_id', $yearId)->where('old_major_code', $oldMajorCode)->where('old_minor_code', $oldMinorCode)->value('id');

        StudiesController::$plansIds[$key] = $planId;

        return $planId;
    }

    public function translateRole($role) {
        switch($role) {
            case "student": return Study::ROLE_STUDENT;
            case "teacher": return Study::ROLE_TEACHER;
            case "committee": return Study::ROLE_EXAMINAR_COMMITTEE;
            case "assistant": return Study::ROLE_TEACHING_ASSISTANT;
        }
        return null;
    }

    public function import(Request $request) {

        $path = $_FILES['file']['tmp_name'];
        \Log::info('Request:', [$path]);

        $nRows = 0;
        $nDuplicates = 0;

        try {
            Excel::load($path, function ($reader) use($request, &$nRows, &$nDuplicates) {

                $termId = $request->term_id;

                for($try=0;$try<2;$try++) {

                    foreach ($reader->toArray() as $row) {

                        $row = (object)$row;
                        if( empty($row->code) || empty($row->course_code))
                            continue;

                        if(!isset($row->code)) $row->code = null;
                        if(!isset($row->email)) $row->email = null;
                        if(!isset($row->plan_code)) $row->plan_code = null;
                        if(!isset($row->year)) $row->year = null;
                        if(!isset($row->old_major_code)) $row->old_major_code = null;
                        if(!isset($row->old_minor_code)) $row->old_minor_code = null;
                        if(!isset($row->name)) $row->name = null;
                        if(!isset($row->course_name)) $row->course_name = null;

                        $userId = StudiesController::getCashedUserId($row->code, $row->email, $row->name, $row->role);
                        $courseId = StudiesController::getCashedCourseId($row->course_code, $row->bylaw);
                        $planId = StudiesController::getCashedPlanId($row->plan_code, $row->year, $row->old_major_code, $row->old_minor_code);
                        $role = StudiesController::translateRole($row->role);

                        $type = null;
                        if(!isset($row->type)) {
                            if($role==1)
                                $type = 1;
                            else
                                $type = null;
                        } else {
                            $type = $row->type;
                        }


                        if( empty($userId) ||
                            empty($courseId) ||
                            ($role==Study::ROLE_STUDENT && empty($planId)) ||
                            empty($role) ) {


                            $planId = StudiesController::getCashedPlanId($row->plan_code, $row->year, $row->old_major_code, $row->old_minor_code);

                            if(empty($userId)) {
                                $msg = "code($row->code), email($row->email), name($row->name)";
                                \Log::info('Missing User:', [$msg]);
                            }
                            else if(empty($courseId)) {
                                $msg = "code($row->course_code), name($row->course_name), bylaw($row->bylaw)";
                                \Log::info('Missing Course:', [$msg]);
                            } else {
                                $msg = "user($row->code, $row->email), course($row->course_code), plan($row->bylaw), plan($row->plan_code), role($row->role)";
                                \Log::info('Invalid Data:', [$msg]);
                                //\Log::info('Request:', [$row]);
                                //$msg = "<p>================</p>";
                                //\Log::info('Request:', [$msg]);
                            }
                        }

                        if(empty($planId)) {
                            $planId = 0;
                        }

                        $state = isset($row->state)?$row->state:0;
                        $bn = isset($row->bn)?$row->bn:null;

                        if($try==1) {

                            try {

                                $study = new Study();
                                $study->user_id = $userId;
                                $study->course_id = $courseId;
                                $study->plan_id = $planId;
                                $study->role = $role;
                                $study->term_id = $termId;
                                $study->state = $state;
                                $study->bn = $bn;
                                $study->type = $type;
                                $study->save();
                                $nRows++;
                            } catch (\Exception $e) {
                                $nDuplicates++;
                                $msg = "user($row->code, $row->email), course($row->course_code), plan($row->bylaw), plan($row->plan_code), role($row->role)";
                                \Log::info('Duplicate Record:', [$msg]);
                                //\Log::info('Request:', [$row]);
                            }
                        }
                    }
                }

                $msg = "done Rows($nRows)";
                \Log::info('Request:', [$msg]);
            });
        } catch (\Exception $e) {
            $msg = "failed";
            \Log::info('Request:', [$e]);
        }

        $result = (object) [
            'term_id' => $request->term_id,
            'rows' => $nRows,
            'duplicates' => $nDuplicates,
        ];

        return response()->json($result);
    }

    public function getTerms(){

        $url = "http://172.16.104.117/apis/getTerms"; //SIS URL
        $token = urlencode($this->encryptData('Good_To_gO', 'XXXn%@9kud$3@uyx6$A5%Usd3'));


        $data = array(
            'token' => $token
        );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        $result = curl_exec($ch);

        $response = json_decode($result);


        if($response->Code == 200){ //successful request

            foreach ($response->data as $row) {
                $year=substr($row->Term, -2);
                $syear=substr($row->Term, -3, 1);
                if(($syear==0) ||($syear==5)) continue;
                else if($syear==1) $value="Fall 20".$year;
                elseif ($syear==2) {
                    if($year<9) $value="Spring 200".($year+1);
                    else $value="Spring 20".($year+1);
                } else {
                    if($year < 9) $value = "Summer 200".($year+1);
                    else  $value = "Summer 20".($year+1);
                }
                $terms[] = array('code' => $row->Term, 'term' => $value);
            }

            dd($terms); //All terms from SIS
            /*foreach ($terms as $term){
                DB::table('sis_terms')->insert(
                    ['code' => $term['code'], 'term' => $term['term']]
                );
            }*/

        }else{
            echo $error_msg = $response->msg;
        }

    }

    public function getCurrentTerm(){


        $url = "http://172.16.104.117/apis/getCurrentTerm"; //SIS URL
        $token = urlencode($this->encryptData('good_to_go', 'XXXn%@9kud$3@uyx6$A5%Usd3'));


        $data = array(
            'token' => $token
        );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        $result = curl_exec($ch);

        $response = json_decode($result);



        if($response->Code == 200){ //successful request

            dd($response->data); //All terms from SIS

        }else{
            echo $error_msg = $response->msg;
        }

    }

    private function decrypt($input, $password) {
        $cipher = base64_decode($input);
        $text = openssl_decrypt($cipher, "AES-256-ECB", hash('sha256', $password, true), OPENSSL_RAW_DATA);
        return $text;
    }

    private function encryptData($text, $password) {
        $cipher = openssl_encrypt($text, "AES-256-ECB", hash('sha256', $password, true), OPENSSL_RAW_DATA);
        $output = base64_encode($cipher);
        return $output;
    }

    public function getStudents(){

        $url = "http://172.16.104.117/apis/getStudents"; //SIS URL
        $token = urlencode($this->encryptData('good_to_go', 'XXXn%@9kud$3@uyx6$A5%Usd3'));


        $data = array(
            'token' => $token
        );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        $result = curl_exec($ch);

        $response = json_decode($result);



        if($response->Code == 200){ //successful request

            dd($response->data); //All terms from SIS
//            foreach ( $response->data as $student){
//                  dd($student);
//                DB::table('sis_students')->insert(
//                    ['code' => $student->Code]
//                );
//            }

        }else{
            echo $error_msg = $response->msg;
        }

    }

    public function getStudentInfo(){


        $url = "http://172.16.104.117/apis/getStudentInfo"; //SIS URL
        $token = urlencode($this->encryptData('good_to_go', 'XXXn%@9kud$3@uyx6$A5%Usd3'));
        $stdCode =  '18W3236'; //Auth::user()->code;


        $data = array(
            'token' => $token,
            'code' => $stdCode
        );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        $result = curl_exec($ch);

        $response = json_decode($result);

        dd($response); //

        if($response->Code == 200){ //successful request

            dd($response->data); //All terms from SIS

        }else{
            echo $error_msg = $response->msg;
        }

    }

    public function getStdGrade(){
        $students = DB::table('sis_students')->get();

        foreach ($students as $student){

//            dd($student->code);
//            $stdCode =  '18W3236'; //Auth::user()->code;
            $stdCode =  $student->code; //Auth::user()->code;
            $studentTerms = $this->getStudentTerms($stdCode);
//            $term = 318; //temp for now (Fall 2018 first term)
            $email =  $stdCode . '@eng.asu.edu.eg';
            $url = "http://172.16.104.117/apis/getMyGrade";  //SIS URL
            $token = urlencode($this->encryptData($email, 'XXXn%@9kud$3@uyx6$A5%Usd3'));




            $studentGrades = [];


            foreach ($studentTerms as $studentTerm){
                $data = array(
                    'email' => $email,
                    'token' => $token,
                    'term' => $studentTerm,
                );

                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

                $result = curl_exec($ch);
                $studentGrades[] = $result;
            }

            dd($studentGrades);
            $response = json_decode($result);

            if($response->Code == 200){ //successful request
                dd($response);
//                foreach ($terms as $term){
//                    DB::table('sis_terms')->insert(
//                        ['code' => $term['code'], 'term' => $term['term']]
//                    );
//                }
            }else{
                echo $error_msg = $response->msg;
                dd('sss');
            }
        }
    }

    public function getStudentTerms($code){


        $url = "http://172.16.104.117/apis/getStudentTerms"; //SIS URL
        $token = urlencode($this->encryptData('good_to_go', 'XXXn%@9kud$3@uyx6$A5%Usd3'));
        $stdCode =  $code; //Auth::user()->code;


        $data = array(
            'token' => $token,
            'code' => $stdCode
        );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        $result = curl_exec($ch);

        $response = json_decode($result);



        if($response->Code == 200){ //successful request

            dd($response->data); //All terms from SIS

        }else{
            echo $error_msg = $response->msg;
        }
    }

    public function discuss(Request $request) {

        $student = auth()->user()->student;

        if(empty($student->academic_discuss_id)) {
            
            $ticket = new Ticket();
            $ticket->ticket_type_id = 11;
            $ticket->title = "Academic Discussion #".$student->user->code;
            $ticket->description = "Academic Discussion #".$student->user->code;
            $ticket->status = 0;
            $ticket->user_id = $student->id;
            $ticket->save();
            $student->academic_discuss_id = $ticket->id;
            $student->save();
        }

        if($student->academic_discuss_status==2) {
            $student->academic_discuss_status = 0;
            $student->save();
        }

        return redirect(route('show_ticket', ['id'=>$student->academic_discuss_id]));
    }

    public function studentCourses(Request $request){

        $student = auth()->user()->student;

        if ($student->id!=auth()->id() && !auth()->user()->hasPermissionTo('advise_students') && !auth()->user()->hasPermissionTo('access_studies'))
            abort(401);

        $currentTermID = Setting::currentTerm()->id;

        $lang = lang();

        if($request->ajax() && $request->type == 'student_courses')
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];

            \Log::info('Request:', $request->all());

            $query = Study::leftJoin('courses', 'courses.id', '=', 'studies.course_id')
                ->leftJoin('students', 'students.id', '=', 'studies.user_id')
                ->leftJoin('sections', 'sections.id', '=', 'studies.section_id')
                ->where('studies.user_id', $student->id)
                ->where('studies.role', 1)
                ->where('studies.term_id', $currentTermID)
                ->orderBy($orderBy, $orderDir);

            \Log::info('Request:', [$query->toSql()]);

            $resultQuery = clone $query;
            $statisticsQuery = clone $query;

            $rows = $resultQuery->select('courses.id', 'studies.plan_id', 'studies.committee_id', 'studies.status', DB::raw('(studies.status>>32) as upper_status'), 'courses.'.$lang.'_name as name', 'courses.short_name', 'courses.max_total', 'courses.min_total', 'courses.credit_hours', 'studies.section_id', 'sections.plan_id as section_plan_id', 'sections.section_no', 'sections.group_no', 'taken_courses.id as taken_course_id',  'taken_courses.short_name as taken_course_code', 'taken_courses.'.$lang.'_name as taken_course_name', 'students.section_id as default_section_id')
            ->leftjoin('courses as taken_courses', 'taken_courses.id', 'studies.override_taken_course_id')
            ->paginate(99999);

            $rows->getCollection()->transform(function ($value) {
                $committee = Committee::find($value->committee_id);
                $value->has_sections = $committee->isSectionsEnabled();
                if($value->section_id) { 
                    $value->section_plan = $value->section->plan->lang('minor');
                }
                return $value;
            });

            $statistics = $statisticsQuery->select(DB::raw('sum(credit_hours) as total_credit_hours, count(*) as courses_count'))->first();

            if(empty($statistics->total_credit_hours))
                $statistics->total_credit_hours = 0;

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows,
                'total_credit_hours' => $statistics->total_credit_hours,
                'max_credit_hours' => $student->maxCoursesCreditHours(),
                'courses_count' => $statistics->courses_count,
                'max_courses_count' => $student->maxCourses(),
                'advisor_approved' => $student->advisor_approved,
                'registered' => $student->registered,
            ];

            return $result;
        }

        if($request->ajax() && $request->type == 'all_courses') {

            dbg('all_courses');
            
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $coursesIDs = Study::select('courses.id')
            ->leftJoin('courses', 'courses.id', '=', 'studies.course_id')
            ->leftJoin('users', 'users.id', '=', 'studies.user_id')
            ->where('users.id', $student->id)
            ->where('studies.role', 1)
            ->where('studies.term_id', $currentTermID)
            ->get()->toArray();

            $plansIDs = [$student->last_plan_id];

            $query = Committee::distinct('committees.id')
            ->leftJoin('courses', 'committees.course_id', 'courses.id')
            ->leftJoin('committees_plans', 'committees_plans.committee_id', 'committees.id')
            ->where('term_id', $currentTermID)
            ->where('courses.bylaw', $student->bylaw)            
            ->where(function($query) use($student, $plansIDs) {
                $query->orWhereIn('committees_plans.plan_id', $plansIDs);
                $query->orWhereNull('committees_plans.plan_id');
            });

            if($student->isChep()) {
                $query->whereIn('committees.type', [Committee::TYPE_CHEP]);
            }
            else {
                $query->whereIn('committees.type', [Committee::TYPE_REGULARE, Committee::TYPE_TAKHALOF]);
            }

            $committeesIDs = $query->pluck('committees.id')->toArray();            

            $query = Course::select(DB::raw("courses.id, courses.".$lang."_name as name, courses.short_name, courses.max_total, courses.min_total, courses.credit_hours, courses.plan_id, plans.short_name as plan_short_name, committees.id as committee_id"))
            ->join('committees', 'committees.course_id', 'courses.id')
            ->leftJoin('plans','plans.id', 'courses.plan_id')
            ->whereIn('committees.id', $committeesIDs)
            ->where('committees.term_id', $currentTermID)
            ->where('courses.bylaw', $student->bylaw)
            ->whereNotIn('courses.id', $coursesIDs)                
            ->orderBy($orderBy, $orderDir);

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $textSearch = mb_ereg_replace("_", "\_", $textSearch);
                $query->Where(\DB::raw("CONCAT(COALESCE(search_text,''))"), "like", "%$textSearch%");
            }

            \Log::info('Request:', [$query->toSql()]);

            $rows = $query->paginate($length);

            $rows->transform(function ($value) use($student) {

                $coursePrerequisite = CoursePrerequisite::where('course_code', $value->short_name)
                ->where('bylaw', $student->bylaw)
                ->first();

                if($coursePrerequisite) {
                    $value->prerequisites = $coursePrerequisite->prerequisites;
                    $value->allowed = $student->canTakeCourse($coursePrerequisite);
                }
                else {
                    $value->allowed = 1;
                    $value->prerequisites = "";
                }
                
                return $value;
            });

            return [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];
        }

        if($request->ajax() && $request->type == 'taken_courses')
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = Course::select(DB::raw("courses.id, courses.".$lang."_name as name, courses.short_name, courses.max_total, courses.min_total, courses.credit_hours, courses.plan_id, plans.short_name as plan_short_name, grades.total, grades.max_total, grades.grade_gpa, grades.grade_letter, terms.".$lang."_name as term_name"))
                ->leftJoin('plans','plans.id', 'courses.plan_id')
                ->join('grades','grades.course_id', 'courses.id')
                ->join('terms','grades.term_id', 'terms.id')
                ->where('grades.student_id', $student->id)
                ->orderBy('courses.code', 'ASC')
                ->orderBy('terms.start_date', 'DESC');

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $textSearch = mb_ereg_replace("_", "\_", $textSearch);
                $query->Where(\DB::raw("CONCAT(COALESCE(search_text,''))"), "like", "%$textSearch%");
            }

            \Log::info('Request:', [$query->toSql()]);

            $result = $query->paginate($length);

            return [
                'draw' => $draw,
                'recordsTotal' => $result->total(),
                'recordsFiltered' => $result->total(),
                'data' => $result
            ];
        }

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];

        $termStage = $student->termStage('studies');

        $repeatedElectiveCoursesIDs = Study::where('studies.term_id', $currentTermID)
        ->join('committees', 'committees.id', 'studies.committee_id')
        ->join('courses', 'courses.id', 'committees.course_id')
        ->where('studies.user_id', $student->id)
        ->where('studies.status', '&', Study::STATUS_REPEAT)
        ->pluck('courses.elective_course_id')
        ->toArray();

        $takenElectiveCoursesIDs = Grade::join('courses', 
            'courses.id', 'grades.course_id')
        ->where('grades.student_id', $student->id)
        ->where('courses.elective', 1)
        ->distinct('courses.elective_course_id')
        ->pluck('courses.elective_course_id')
        ->toArray();

        $ignoreElectiveCoursesIDs = [];
        
        if($termStage && $termStage->stage_code=='late_elective_selection') {

            $ignoreElectiveCoursesIDs = Study::selectRaw('courses.elective_course_id, count(*) as count')
             ->where('studies.term_id', $currentTermID)
            ->where('studies.user_id', $student->id)
            ->whereNotNull('courses.elective_course_id')
            ->join('courses', 'courses.id', 'studies.course_id')
            ->groupBy('courses.elective_course_id')
            ->having('count', '=', 1)
            ->pluck('courses.elective_course_id')
            ->toArray();            
        }

        $selectedCommitteesIDs = Study::where('term_id', $currentTermID)
        ->where('user_id', $student->id)
        ->whereRaw('NOT(status&'.Study::STATUS_REPEAT.')')
        ->pluck('committee_id')
        ->toArray();

        $committees = Committee::select('committees.*')
        ->join('committees_plans', 'committees_plans.committee_id', 'committees.id')
        ->where('committees.term_id', $currentTermID)
        ->where('committees_plans.plan_id', $student->last_plan_id)
        ->get();
        
        $electiveGroups = [];
        foreach ($committees as $committee) {
            if($committee->course->elective && 
                !in_array($committee->course->elective_course_id, $repeatedElectiveCoursesIDs) &&
                !in_array($committee->course->elective_course_id, $takenElectiveCoursesIDs)) {
                $electiveCommittees = [];
                if(in_array($committee->course->elective_course_id, $ignoreElectiveCoursesIDs)) {
                    continue;
                }
                if(array_key_exists($committee->course->elective_course_id, $electiveGroups)) {
                    $electiveCommittees = $electiveGroups[$committee->course->elective_course_id];
                }
                $electiveCommittees[] = $committee;
                $electiveGroups[$committee->course->elective_course_id] = $electiveCommittees;
            }
        }

        if($termStage && !$termStage->isOpen()) {
            $electiveGroups = [];
            $selectedCommitteesIDs = [];
        }

        return view('study.studies.student_courses', compact('path', 'student', 'termStage', 'electiveGroups', 'selectedCommitteesIDs'));
    }

    public function getSections(Request $request, Committee $committee) {

        $student = auth()->user()->student;

        if($student->section_id!==null) {            
            if($committee->isSectionExist($student->section_id)) {
                return response()->json([
                    'data' => 'defaultsection'
                ]);
            }
            else {
                return response()->json([
                    'data' => []
                ]);
            }
        }

        if($committee->isSectionsEnabled()===false) {
            return response()->json([
                'data' => 'nosections'
            ]);
        }

        $sections = $committee->sections(null, true, false);

        return response()->json([
            'data' => $sections
        ]);
    }

    public function coursesActions(Request $request, $action) {

        $student = auth()->user()->student;

        dbg("P0");

        if ($student->id!=auth()->id() && !auth()->user()->hasPermissionTo('advise_students') && !auth()->user()->hasPermissionTo('access_studies'))
            abort(401);

        dbg($action, "P00");

        $committee = ($request->committee_id)?Committee::findOrFail($request->committee_id):null;
        $section = ($request->section_id)?Section::findOrFail($request->section_id):null;
        $currentTermId = Setting::currentTerm()->id;

        if ($action == 'submit_courses' ) {

            $data = Study::select(DB::raw('sum(credit_hours) as total_credit_hours, count(*) as courses_count'))
            ->leftJoin('courses', 'courses.id', '=', 'studies.course_id')
            ->leftJoin('users', 'users.id', '=', 'studies.user_id')
            ->where('users.id', $student->id)
            ->where('studies.role', Study::ROLE_STUDENT)
            ->where('studies.term_id', $currentTermId)
            ->first();

            if($student->checkCreditLimits($data->total_credit_hours, $data->courses_count)) {
                $student->advising_status = 1;
                $student->save();
            }
            else {
                return response()->json([
                    'error' => __('tr.Number of courses or credit hours exceeds limits.')
                ],401);
            }

        } else if ($action == 'update_courses') {

            $student->advising_status = 0;
            $student->save();

        }
        elseif ($action == 'remove_course') {

            if(!$student->isStudiesRemoveAllowed()) abort(401);
            Study::unenroll($committee, $student);
        } 
        elseif ($action == 'undo_course') {

            if(!$student->isStudiesRemoveAllowed()) abort(401);            
            Study::unenrollUndo($committee, $student);
        } 
        elseif ($action == 'add_course' || $action == 'edit_section') {

            if(!$student->isStudiesAddAllowed()) abort(401);

            $coursePrerequisite = CoursePrerequisite::where('bylaw', $student->bylaw)
            ->where('course_code', $committee->course->short_name)
            ->first();

            if($coursePrerequisite && !$student->canTakeCourse($coursePrerequisite)) {
                return response()->json([
                    'error' => __('tr.Course not allowed.')
                ],401);
            }

            $force = false;
            if($committee->isSectionExist($student->section_id)) {
                $section = Section::find($student->section_id);
                $force = true;
            }

            $result = Study::enroll($committee, $student, $section, $force);
            
            if(!$result) {
                return response()->json([
                    'error' => __('tr.Number of student per seaction exceeds the limit.')
                ],401);
            }
        }

        return response()->json('done');
    }

    public function registrationReport(Request $request) {

        $student = auth()->user()->student;

        $currentTermId = Setting::currentTerm()->id;

        $lang = lang();

        $studies = Study::select('studies.*', 'sections_plans.'.$lang.'_minor as section_plan_minor', 'sections.plan_id as section_plan_id', 'sections.group_no', 'sections.section_no')->leftJoin('courses', 'courses.id', '=', 'studies.course_id')
                ->leftJoin('users', 'users.id', '=', 'studies.user_id')
                ->leftJoin('sections', 'sections.id', '=', 'studies.section_id')
                ->leftJoin('plans as sections_plans', 'sections_plans.id', '=', 'sections.plan_id')
                ->where('users.id', $student->id)
                ->where('studies.status', '&', Study::STATUS_WITHDRAWN|Study::STATUS_EXCUSED|Study::STATUS_REGISTERED)
                ->where('studies.term_id', $currentTermId)
                ->orderBy('courses.short_name')
                ->get();

        PDF::setHeaderCallback(function($pdf) {
            $html = '
               <table>
                 <tr><th></th></tr>
                 <tr><th>Registartion Form</th></tr>
                 <tr><th></th></tr>
              </table>
            ';
            $pdf->writeHTML($html);            
            $pdf->Image(public_path('/img/logo.png'), 95, 10, 25, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
            $html = '
               <table style="text-align: right">
                 <tr><th style="text-align: right">Ain-Shams University</th></tr>
                 <tr><th style="text-align: right">Faculty of Engineering</th></tr>
                 <tr><th style="text-align: right">Studies and Examinations</th></tr>
              </table>
            ';
            $pdf->writeHTML($html);
        });
        $code = $student->user->code;
        PDF::SetTitle("Registartion Form - $code");
        PDF::SetMargins(14, 42, 14);
        PDF::SetHeaderMargin(10);
        PDF::SetFooterMargin(10);
        $setting = ['a_meta_charset' => 'UTF-8', 'a_meta_dir' => 'ltr', 'a_meta_language' => 'en', 'w_page' =>  'page' ];
        PDF::setLanguageArray($setting);
        PDF::setFontSubsetting(true);
        PDF::SetAutoPageBreak(true,12);
        $fontname = TCPDF_FONTS::addTTFfont(public_path().'/arial.ttf', 'TrueTypeUnicode', '', 32);
        PDF::SetFont($fontname,'', 12);
        PDF::AddPage('P', 'A4');
        $view = \View::make("study.studies.student_report", compact('student','studies'));
        $html = $view->render();
        PDF::writeHTML($html);
        PDF::Output("Registartion Form $code.pdf",'I');
    }

    public function showStudentCourses(){
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];

        $student = auth()->user()->student;
        $lang = lang();
        $currentTermId = Setting::currentTerm()->id;
        $query = Study::leftJoin('courses', 'courses.id', '=', 'studies.course_id')
                        ->leftJoin('users', 'users.id', '=', 'studies.user_id')
                        ->leftJoin('sections', 'sections.id', '=', 'studies.section_id')
                        ->where('users.id', $student->id)
                        ->where('studies.role', 1)
                        ->where('studies.term_id', $currentTermId);
        $course_ids = [];
        $resultQuery = clone $query;
        $courses = $resultQuery->select('courses.id', 'studies.bn', 'studies.plan_id', 'studies.committee_id', 'courses.'.$lang.'_name as name', 'courses.short_name', 'courses.max_total', 'courses.min_total', 'courses.credit_hours', 'studies.section_id', 'sections.plan_id as section_plan_id', 'sections.section_no', 'sections.group_no')->paginate(99999);
        foreach($courses as $course){
            array_push($course_ids,$course->id);
        }

        if(count($course_ids) > 0){
            $instructors = DB::select('SELECT committees.course_id,users.'.$lang.'_name as "instructor_name",committees.id FROM `committees` INNER JOIN committees_instructors ON committees_instructors.committee_id = committees.id INNER JOIN users ON users.id = committees_instructors.instructor_id  WHERE `course_id` in ('.implode(",",$course_ids).') AND committees_instructors.role in (2,4) AND committees.term_id = '.$currentTermId);
        }

        $committees = Committee::select('committees.id', 'committees.course_id', 'committees.term_id')
                                ->join('committees_instructors', 'committees_instructors.committee_id', 'committees.id')
                                ->where('committees_instructors.instructor_id', auth()->id())
                                ->where('committees.term_id', $currentTermId)
                                ->groupBy(['committees.id', 'committees.course_id', 'committees.term_id'])
                                ->get();

        return view('students.courses',compact('path', 'courses','student','committees','instructors'));

    }

    public function showCourses(Request $request, $id) {
        
        $course = Course::findOrfail($id);
        $course_term = $course->term_type;

        $lang = lang();

        if ($request->ajax() && $request->ajax_separator == 1){

            $draw = $request->draw;
            $columns = $request->columns;
            $termID = $columns[0]["search"]["value"];
            $planID = $columns[1]["search"]["value"];

            \Log::info('Request:', $request->all());

            $instructors = User::select('users.'.$lang.'_name as name','users.mobile','users.email',
                'committees_instructors.role','committees_plans.plan_id', 'plans.'.$lang.'_minor as minor',
                'plans.'.$lang.'_major as major', 'terms.'.$lang.'_name as term_name')
                ->join('instructors','instructors.id','users.id')
                ->join('committees_instructors','committees_instructors.instructor_id','instructors.id')
                ->join('committees','committees.id','committees_instructors.committee_id')
                ->join('terms', 'terms.id', 'committees.term_id')
                ->join('committees_plans', 'committees_plans.committee_id', 'committees.id')
                ->join('plans', 'plans.id', 'committees_plans.plan_id')
                ->where('committees.course_id',$course->id)
                ->groupBy('committees_instructors.instructor_id');

            if ($termID){
                $instructors->where('committees.term_id', $termID);
            }

            if ($planID){
                $instructors->where('committees_plans.plan_id', $planID);
            }

            $instructors = $instructors->paginate(99999);

            return [
                'draw' => $draw,
                'data' => $instructors
            ];
        }

        $path = [];
        $path[] = (object) ['link' => route('showStudentCourses'), 'title' => __('tr.My Courses')];

        if ($request->ajax() && $request->ajax_separator == 2) {

            $termID = $request->term_id;
            $committeeId = $request->committee_id;
            $committee = Committee::find($committeeId);
            if(empty($committee)){
                $result = [
                    'data' => [],
                    'edit' => false,
                    'view' => false,
                    'edit_work' => false,
                    'edit_final' => false,
                ];

                return response()->json($result);
            }
            $committeeInstructor = $committee->committeeInstructor(auth()->id());
            
            $planID = $request->plan_id;
            $plansIDs = [];
            if($planID===null) {
                $plansIDs = $committee->committeesPlans()->pluck('plan_id')->toArray();
            }
            else {
                $plansIDs[] = $planID;
            }

            $status = "(CASE ";
            foreach (Study::getStatusLabels() as $key => $value) {
                $status .= "WHEN studies.status = $key THEN '$value' ";
            }
            $status .= "ELSE '-' END) as status";

            $studies = Study::select('users.id as student_id', 'studies.course_id as course_id', 'studies.plan_id', DB::raw($status), 'users.code as student_code',
                'users.'.$lang.'_name as student_name', 'studies.first_oral', 'studies.first_work', 'studies.first_exam', 'studies.final_oral', 'studies.final_work', 'studies.final_exam', "courses.max_total", "total", DB::raw("CONCAT(ROUND((100*total)/courses.max_total, 0), '%') as percentage"))
                ->where('studies.course_id', $course->id)
                ->where('studies.term_id', $termID)
                ->where('studies.role', 1)
                ->leftJoin('users', 'users.id', 'studies.user_id')
                ->leftJoin('courses', 'courses.id', 'studies.course_id')
                ->orderBy('users.en_name');

            if (count($plansIDs)>0){
                $studies->whereIn('studies.plan_id', $plansIDs);
            }

            $studies = $studies->get();

            $result = [
                'data' => $studies,
                'edit' => $studies[0]->control_status,
                'view' => (empty($committeeInstructor))?true:$committeeInstructor->canView(),
                'edit_work' => (empty($committeeInstructor))?false:$committeeInstructor->canEditWork(),
                'edit_final' => (empty($committeeInstructor))?false:$committeeInstructor->canEditFinal(),
            ];

            return response()->json($result);
        }

        $all_courses = DB::select('select max_first_work,max_first_oral,max_first_exam,max_final_work,max_final_oral,max_final_exam from courses where id = '.$course->id);

        $all_courses = array_map(function ($value) {
            return (array)$value;
        }, $all_courses);

        $course_grade = $all_courses[0];

        $bylaws = Bylaw::where('current', 1)->orderBy('code', 'DESC')->get();
        $terms = Term::select('id' ,$lang.'_name as name' ,'years', 'start_date', 'end_date','active')
            ->where('active','=','1')
            ->orderBy('start_date', 'desc')
            ->get();

        $currentTermID = Setting::currentTerm()->id;

        if ($request->ajax() && $request->ajax_separator == 3){

            $plans = Committee::select('*')
                ->where('committees.course_id', $course->id)
                ->where('committees.term_id', $request->term_id)
                ->get();

            return [
                'data' => $plans
            ];
        }

        if ($request->ajax() && $request->ajax_separator == 4){

            $plans = Committee::select('plans.id', 'plans.'.$lang.'_minor as minor', 'plans.'.$lang.'_major as major',
                'years.'.$lang.'_name as year_name')
                ->where('committees.course_id', $course->id)
                ->where('committees.term_id', $request->term_id)
                ->where('committees.id', $request->committee_id)
                ->leftjoin('committees_plans', 'committees_plans.committee_id', 'committees.id')
                ->leftjoin('plans', 'plans.id', 'committees_plans.plan_id')
                ->leftjoin('years', 'years.id', 'plans.year_id')
                ->get();

            return [
                'data' => $plans
            ];
        }

        $committeeID = $request->committee_id;

        return view('students.course_details',compact('path', 'course', 'course_grade','course_term', 'bylaws', 'terms', 'currentTermID', 'committeeID'));
    }

    public function selectElective(Request $request) {

        $student = auth()->user()->student;
        $term = Setting::currentTerm();        

        foreach ($request->committees_ids as $committeeID) {
            $committee = Committee::find($committeeID);
            foreach($committee->course->electiveParent->electiveChildren as $childCourse) {

                $childCommittee = Committee::select('committees.*')
                ->join('committees_plans', 'committees_plans.committee_id', 'committees.id')
                ->where('committees.term_id', $term->id)
                ->where('committees.course_id', $childCourse->id)
                ->where('committees_plans.plan_id', $student->last_plan_id)
                ->first();

                if($childCommittee) {
                    d("unenroll");
                    Study::unenroll($childCommittee, $student, 'remove_course');
                }                                
            }

            d("enroll");
            Study::enroll($committee, $student, Section::find($student->section_id), true);
        }

        dd($request->committees_ids);

        return redirect()->back();
    }

    /**
     * 
     */
    public function printCourseExamDetails(Study $study)
    {
        if($study->user_id != auth()->id())
            abort(401);
       
        $student = auth()->user()->student;

        $courseCode = $study->course->short_name;
        
        $exam = Exams::current();

        $location = FacultyLocation::find($study->exam_location_id);
        
        if($location && $location->exams_entry_gate)
            $gateName = $location->exams_entry_gate;
        else
            $gateName = '';

        PDF::setHeaderCallback(function($pdf) use($courseCode, $gateName){
    
            $html = "
                <table>
                    <tr><th></th></tr>
                    <tr><th>Course: $courseCode </th></tr>
                    <tr><th></th></tr>
                </table>
            ";
            $pdf->writeHTML($html);
            
            $pdf->SetXY(13, 15);
            $pdf->SetFont ('', '', $pdf->pixelsToUnits('70') , '', 'default', true );
                $html = "
                <table>
                    <tr><th></th></tr>
                    <tr><th>$gateName </th></tr>
                    <tr><th></th></tr>
                </table>
            ";
            $pdf->writeHTML($html);   
            
                
            $pdf->SetFont ('', '', $pdf->pixelsToUnits('35') , '', 'default', true );
            $pdf->Image(public_path('/img/logo.png'), 95, 10, 25, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
            $html = '
                <table style="text-align: right">
                    <tr><th style="text-align: right">Ain-Shams University</th></tr>
                    <tr><th style="text-align: right">Faculty of Engineering</th></tr>
                    <tr><th style="text-align: right">Studies and Examinations</th></tr>
                </table>
            ';
            $pdf->writeHTML($html);
        });
        
        
        // set style for barcode
        $style = array(
            'border' => true,
            'vpadding' => 'auto',
            'hpadding' => 'auto',
            'fgcolor' => array(0,0,0),
            'bgcolor' => false, //array(255,255,255)
            'module_width' => 1, // width of a single module in points
            'module_height' => 1 // height of a single module in points
        );
       
        $url = "https://portal.eng.asu.edu.eg/study/set_attendance/".auth()->id()."/$study->id";

        PDF::SetTitle("Course: $courseCode");
        PDF::SetMargins(14, 42, 14);
        PDF::SetHeaderMargin(10);
        PDF::SetFooterMargin(10);
        $setting = ['a_meta_charset' => 'UTF-8', 'a_meta_dir' => 'ltr', 'a_meta_language' => 'en', 'w_page' =>  'page' ];
        PDF::setLanguageArray($setting);
        PDF::setFontSubsetting(true);
        PDF::SetAutoPageBreak(true,12);
        $fontname = TCPDF_FONTS::addTTFfont(public_path().'/arial.ttf', 'TrueTypeUnicode', '', 32);
        PDF::SetFont($fontname,'', 12);
        PDF::AddPage('P', 'A4');
        
        $view = \View::make("study.studies.print_course_exam_details", compact('student', 'study', 'gateName'));
        $html = $view->render();
        PDF::writeHTML($html);
        
        PDF::write2DBarcode($url, 'QRCODE,H', 24, 120, 165, 165, $style, 'N');
        
        if($gateName) {
            PDF::Image(public_path("/img/gates/$gateName.png"));
        }
        

        PDF::Output("Final Exam - $courseCode.pdf",'I');
    }

    
}