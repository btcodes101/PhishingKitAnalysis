<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Student;
use App\Bylaw;
use App\User;
use App\BranchingPreference;
use App\Plan;
use App\Study;
use App\UserRequest;
use App\ChangeTrackPreference;
use App\Term;
use App\Committee;
use App\Group;
use App\Grade;
use App\GradeTerm;
use App\CourseSection;

use Illuminate\Support\Facades\Validator;

use Spatie\Permission\Models\Role;

use Exception;
use Auth;
use DB;


class AdvisorsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    private function getPath() {
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => '#', 'title' => __('tr.Advising')];
        return $path;
    }

    /**
     * A function to get the courses of the student to register them
     * @param:  
     * @return: 
     */
    public function coursesRegistration($id){   
        
       

        //first make sure the logged user is an advisor for this student
        $user = Auth::user();
        if($user->code != "0301519")
         abort(404);
        //make sure that the $id belongs to a student
        $student = User::find($id)->student;
        if(empty($student))
            abort(404);

        // if(!isset($student->advisor->en_name))
        // abort(404);

        //make sure that we can display the result based on the dates
        /*if(!$student->canRegisterCourses())
             abort(404);*/


        if(empty($student->last_plan_id) || $student->last_plan_id == null)
            abort(404);

        $currentTermId = Term::currentTerm()->id; //return wrong term
     
       //we need to make this dynamic to offer to the students all courses of his previous plans
       $firatTimeFrahman = $student->firstTime();

       if($firatTimeFrahman){
           $plansIDs = [$student->last_plan_id];
       }else{
           $plansIDs = [179, $student->last_plan_id, -1];
       }
       

       //Get all courses for this plan
       $courses = Committee::select("committees_plans.plan_id as planID", "committees.term_id", "courses.*", 'studies.id as studies',  'studies.group', 'committees.id as committee_id', 'committees_plans.quota', 'committees_plans.set_number', 'committees_plans.elective', 'groups.section_name', 'plans.en_minor')
                           ->join("committees_plans","committees.id","committees_plans.committee_id")
                           ->leftJoin('courses', 'courses.id', '=', 'committees.course_id')
                           ->leftJoin('studies', function($join) use($currentTermId, $student){
                               $join->on('studies.course_id', '=', 'courses.id')
                                       ->where('studies.term_id', '=', $currentTermId)
                                       ->where('studies.user_id', '=', $student->id)
                                       ->where('studies.plan_id', '=', $student->last_plan_id);
                           })
                           ->leftJoin('groups', 'groups.id', '=', 'studies.group')
                           ->leftJoin('plans', 'plans.id', '=', 'groups.plan_id')
                           ->where("committees.term_id",$currentTermId)
                           ->whereIn('committees_plans.plan_id', $plansIDs)
                           ->orderBy('committees_plans.plan_id')
                           ->get();

       
        if(!$courses)
           abort(404);                 
       
 
        //Get the max allowed courses and credit hours
        $maxCoursesAndCHR = $student->maxAllowedCoursesAndCHR();

        $groups = Group::where('plan_id', $student->last_plan_id)
                        ->whereRaw('taken_quota < quota')->get();
        
        $path = $this->getPath();
        return view('advisors.std_course_registration',compact('path','courses', 'maxCoursesAndCHR', 'groups', 'student'));
              
    }



     /**
     * A function to save the selected courses and the sections chosen by the advisor
     * @param:  
     * @return: 
     */
    public function SaveCoursesRegistration(Request $request, $id){
         
       
        //first make sure the logged user is an advisor for this student
        $user = Auth::user();

        //make sure that the $id belongs to a student
        $student = User::find($id)->student;
        if(empty($student))
            abort(404);
        
        //make sure that we can display the result based on the dates
        /*if(!$student->canRegisterCourses())
           abort(404);*/

         //temp condition 
        $firatTimeFrahman = $student->firstTime();
         

        $currentTermId = Term::currentTerm()->id; //return wrong term
        

    
        if(!$request->has('courses') || !$request->has('sections'))
            return response()->json(['error' => array('Some data are invalid, please try again later')], 404);
            
        $courses = $request->courses;
        $sections = $request->sections;
        
        if(empty($courses) || empty($sections))
            return response()->json(['error' => array('.Please select at least one course to register')], 404);
        
        //Delete the  previous registraion and decrease the taken quota by one
        //A- decrease the taken quota by one
        $studies = Study::where('user_id', $student->id)->where('term_id', $currentTermId)->get();
        foreach($studies as $study){

            $section = CourseSection::where('group_id', $study->group)
                                        ->where('course_id', $study->course_id)
                                        ->where('term_id', $study->term_id)
                                        ->first();
            $section->taken = $section->taken-1;
            $section->save();
        }

        //B- delete the previous registraion
        Study::where('user_id', $student->id)->where('term_id', $currentTermId)->delete();

        //Add the courses to the studies table
        foreach($courses as $key=>$course){
            
            //make sure that the saction still has places
            $section = CourseSection::where('group_id', $sections[$key])
                                        ->where('course_id', $course)
                                        ->first();
            if($section){

                $section->taken = $section->taken+1;
                $section->save();

            }else{ //we could not find the section
                continue;
            }

            $study = new Study();
            $study->user_id = $student->id;
            $study->course_id = $course;
            $study->role = Study::ROLE_STUDENT;
            $study->type = Study::TYPE_FRESH;
            $study->term_id = $currentTermId;
            $study->plan_id =$student->last_plan_id;
            $study->group = $sections[$key];
            $study->save();

        }

        return response()->json([], 200);
            
       
    }
}
