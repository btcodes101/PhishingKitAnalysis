<?php

namespace App\Http\Controllers;

use App\Applicant;
use App\Applicant_Type;
use App\Archive;
use App\OpenPosition;
use App\User;
use App\Website;
use App\Setting;
use App\PageAccess;
use App\StudentCertificate;
use App\Http\Controllers\ApplicantsController;
use App\Http\Controllers\StudentsCertificatesController;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Mail;
use Session;
use URL;
use Carbon\Carbon;

class WebsiteController extends Controller
{
    public function __construct()
    {
    }

    public function custom($view, $website) {

        $request = request();
        
        $text = "website.home.applyto.";
        if(strpos($view, $text)===0) {
            $applyTo = str_replace($text, "", $view);
            return redirect()->route('applyto', ['applicantType'=>$applyTo, 'id'=>$request->id, 'secret'=>$request->secret]);
        }

        $text = "website.home.request.certificate";
        if(strpos($view, $text)===0) {
            return redirect()->route('show_external_certificate_request', ['id'=>$request->id, 'secret'=>$request->secret]);
        }

        abort(404);
    }

    public function index(...$ids) {
                
        PageAccess::log();

        $newsSearch = null;
        $mainSection = $page = Archive::locate('home');
        foreach ($ids as $id) {

            if($id=="website")
                continue;
            
            if($id=="home")
                continue;

            $fastPage = $page->findFarChildByShortName('#'.$id);
            if($fastPage) {
                $page = $fastPage;
            }
            else  {
                $page = $page->locateChild($id);
            }            
            if(empty($page)){

                $view = "website.$mainSection->short_name.$id";
                
                $website = new Website($mainSection);
                
                //To support old applyto urls
                $view = str_replace("applyto_", "applyto.", $view);
                
                if(view()->exists($view))
                return $this->custom($view, $website);
                
                abort(404);
            }
            else if($page->content_type=="mainsection"){
                $mainSection = $page;
            }
        }

        if($page->content_type=='mainsection' || $page->content_type=='section'  || (empty($page->content_type) && $page->isFolder())) {
            $child = $page->locateChild('index');
            if($child)
                $page = $child;
        }

        //Initialize Website Object
        $website = new Website($mainSection);

        if($page->content_type!='mainsection') {            

            if(!empty($page->content_type) && view()->exists("website.pages.$page->content_type")){
                return view("website.pages.$page->content_type", compact('website', 'page'));
            }
            else if(!empty($page->short_name) && view()->exists("website.pages.$page->short_name")){
                return view("website.pages.$page->short_name", compact('website', 'page'));
            }

            $page->access();
            $page = $page->findNonEmptyPage();
            return view("website.pages.page", compact('website', 'page'));
        }

        $view = "website.$mainSection->short_name.$page->short_name";
        
        if(view()->exists($view))
            return view($view, compact('website', 'page'));

        
        $page->access();
        return view("website.index", compact('website','page'));
    }

    public function image(Archive $archive)
    {
        if(empty(strstr($archive->path, "cms/")))
            abort(401);

        try{
            $response = response()->make(\File::get($archive->physicalPath()), 200);
            $response->header("Content-Type", $archive->application_type);
            return $response;
        } catch (\Throwable $e) {
            abort(401);
        }
    }

    public function loginView()
    {
        $website = new Website();
        if (Session::has('userData')) {
            $user_id = Session::get('userData')->id;
            return redirect()->route('questionnaire');
        } else {
            return view('website.login', compact('website'));
        }

    }

    public function login(Request $request)
    {
        $checkUser = DB::connection('portal')->table('users')
            ->where('email', $request['email'])
            ->first();
        $checkPass = false;
        if ($checkUser) {
            $checkPass = \Hash::check($request['password'], $checkUser->password);
        }
        if ($checkPass) {
            $user = $checkUser;
            \Session::put('userData', $checkUser);
            return redirect()->route('web_questineer', ['user_id' => $user->id]);
        } else {
            return redirect()->back()->withErrors(['Errors' => 'Your password or Email incorrect']);
        }
    }

    public function logout()
    {
        \Session::flush();
        return redirect()->route('index');
    }

    public function postgraduate() {
        return redirect('/website/education/postgraduate');
    }

    public function newsSearch(Request $request){
        $mainSection = json_decode($request->mainSection);
        $searchTxt = $request->search;
        //dd($mainSection);
        $newsSearch = $mainSection->childrenPages('created_at', 'DESC')->where('search_text','like',"%".$searchTxt."%")->get();
        return view('website.pages.news',compact('newsSearch','website','searchTxt','page'));       
    }

    public function viewBylaw($bylaw, $section = null, $sub_section = null) {        

        $website = new Website(Archive::locate('home'));
        $website->baseSections = "education/undergraduates/bylaws";

        $page = Archive::locate($bylaw);
        if($section) {            
            $page = $page->locateChild($section);            
            if($sub_section) {
                $page = $page->locateChild($sub_section);
            }            
        }
        if($page->isFolder()) {
            $index = $page->locateChild('index');
            if($index) $page = $index;
        }

        return view("website.home.education.bylaw", compact('website', 'bylaw', 'page'));
    }
}
