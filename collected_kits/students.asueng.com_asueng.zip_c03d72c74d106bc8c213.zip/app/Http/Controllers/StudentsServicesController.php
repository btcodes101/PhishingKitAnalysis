<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Student;
use App\Bylaw;
use App\User;
use App\BranchingPreference;
use App\Plan;
use App\Study;
use App\UserRequest;
use App\ChangeTrackPreference;
use App\Term;
use App\Committee;
use App\Group;
use App\Grade;
use App\GradeTerm;
use App\CourseSection;
use App\OnlineExamsMethodConfirmation;
use App\Setting;
use App\Archive;
use App\TransferIPToSPRequest;
use App\TransferSPToIPRequest;
use App\TransferToPlanRequest;
use App\PlanQuota;

use Illuminate\Support\Facades\Validator;

use Spatie\Permission\Models\Role;

use Exception;
use Auth;
use DB;
use Response;


class StudentsServicesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkStdPaymentStatus')->only(['archAptitudeTestPaymentConfirmation', 'storeTransferSPToIPRequest']);
    }

    private function getPath() {
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];
        return $path;
    }

    /**
     * A function to get the student department and the permitted departments to change the track to
     * @param:  none
     * @return: 
     */
    public function changeTrack() {

        $student = Auth::user()->student;
        if(!$student->canChangeTrack())
            abort(404);

        $changeTrackPreference = ChangeTrackPreference::where('user_id', $student->id)
                                                    ->where('from_plan_id', $student->last_plan_id)
                                                    ->first();

        $plans = Plan::join("change_track_rules", "plans.id", "change_track_rules.to_plan_id")
                    ->where("change_track_rules.from_plan_id", $student->last_plan_id)
                    ->pluck(lang().'_minor as name', 'plans.id')->toArray();

        $path = $this->getPath();
        return view('students.services.change_track', compact('path', 'plans', 'changeTrackPreference'));
    }


    /**
     * A function to get the student department and the permitted departments to change the track to
     * @param:  
     * @return: 
     */
    public function saveChangeTrack(Request $request) {

        $nextTermID = Setting::value('next_term_id');
        
        $student = Auth::user()->student;
        if(!$student->canChangeTrack())
            abort(404);

        $validators = [
            'plan_id' => 'required|numeric',
            'first_attempt' => 'required',
            //Commented till next year 2021/2022 inshallah
            //  'change_to_2018' => 'required',
        ];

        $request->validate($validators);

        $total_amount = Setting::value('change_track_cost');

        if($request->request_id) {
            $userRequest = UserRequest::where('id', $request->request_id)->where('user_id', $student->id)->first();
        } 
        else {
            $userRequest = new UserRequest();
            $userRequest->user_id = auth()->id();
            $userRequest->type = "change_track";
            $userRequest->save();
        }        

        $data = [
            'term_id' => $nextTermID,
            'to_plan_id' => $request->plan_id,
             
        ];

        $userRequest->data = json_encode($data);
        $userRequest->merchant_reference_no = $userRequest->id.'_'.time(). '@studentsServices';
        $userRequest->total_amount = $total_amount;

        $userRequest->save();

        return redirect()->route('confirm_change_track', ['token'=>encrypt($userRequest->id)]);
    }

    public function confirmChangeTrack($token, Request $request) {

        $student = Auth::user()->student;
        if(!$student->canChangeTrack())
            abort(404);

        $id = decrypt($token);
        $userRequest = UserRequest::find($id);

        $data = (object)json_decode($userRequest->data);

        $plan = Plan::find($data->to_plan_id);

        $path = $this->getPath();
        return view('students.services.confirm_change_track', compact('path', 'plan', 'userRequest'));
    }


     /**
     * A function to get the permitted departments to set his Preferences
     * @param:  
     * @return: 
     */
    public function selectTrack() {

        $nextTermID = Setting::value('next_term_id');
        $student = Auth::user()->student;
        if(empty($student))
           abort(404);

        if(!$student->canSelectTrack())
           abort(404);
        $gradesTerm = $student->gradesTerms('DESC')->first();

        $plans = Plan::select("plans.*")
                    ->join("branching_preferences", "plans.id", "branching_preferences.to_plan_id")
                    ->where("branching_preferences.from_plan_id", $student->last_plan_id)
                    ->where("branching_preferences.user_id", $student->id)
                    ->where("branching_preferences.term_id", $nextTermID)
                    ->orderBy('branching_preferences.id')
                    ->get();

        if(count($plans)==0){

           $allPlans = Plan::select("plans.*")
                       ->join("branching_rules", "plans.id", "branching_rules.to_plan_id")
                       ->where("branching_rules.from_plan_id", $student->last_plan_id)
                       ->where("branching_rules.required_credit_hours",'<=',$gradesTerm->final_cumulative_passed_hours )
                       ->get();
                       
           //make sure that the student satisfy the prerequisites of each plan
           $plans = [];
           foreach($allPlans as $plan) {
                if($student->checkPrerequisites($plan))
                   $plans[] = $plan;           
           }
        }

       $path = $this->getPath();
       return view('students.services.select_track', compact('path', 'plans'));
    }

   /**
    * A function to store the Preferences of the students[2003 bylaw]
    * @param:  
    * @return: 
    */
   public function saveSelectTrack(Request $request)
   {  
       $nextTermID = Setting::value('next_term_id');
       $student = Auth::user()->student;
       if(!$student->canSelectTrack())
           return response()->json(['error' => array('Opertaion failed, service is closed.')], 404);

       BranchingPreference::where('user_id', $student->id)->where('from_plan_id', $student->last_plan_id)->where('term_id', $nextTermID)->delete();
       $order = 1;
       foreach ($request->preferences as $toPlanId) {

           $branchingPreference = new BranchingPreference();
           $branchingPreference->user_id = auth()->id();
           $branchingPreference->from_plan_id = $student->last_plan_id;
           $branchingPreference->to_plan_id = $toPlanId;
           $branchingPreference->term_id = $nextTermID;
           $branchingPreference->pref_order = $order;
           $branchingPreference->save();
           $order++;
       }

       return response()->json();
   }

     /**
     * A function to display the result of the students preferences
     * @param:  
     * @return: 
     */
    public function trackPreferencesResultDisplay(){

        $student = Auth::user()->student;
      
        if(empty($student))
            abort(404);
      
        //make sure that we can display the result based on the dates
        if(!$student->canDisplaySelectTrackResult())
            abort(404);
        

        //check student's payment status
        //It is a temp solution for this term
        $grades = GradeTerm::where('student_id', $student->id)
                            ->where('term_id', 121) //Summer 2019
                            ->get();

        if($student->last_level == 1 && count($grades) <= 0 ){ //freshmen
            $payment_status = 'Paid';
        }else{
            $student_code = Auth::user()->code;
            $payment_status = DB::table('payment_status')
                                ->where('student_code',$student_code)
                                ->first();
            if(!$payment_status || empty($payment_status))
                $payment_status = 'Not Paid';
            else
                $payment_status = 'Paid';
        }
       

        
        //get the student's new plan Preferences 
        $newPlan = Plan::select("*")
                        ->join("branching_preferences", "plans.id", "branching_preferences.moved_to")
                        ->where("branching_preferences.user_id", $student->id)
                        ->first();
                       
        $path = $this->getPath(); 
        return view('students.services.select_track_result', compact('path', 'newPlan','payment_status'));
    }

    /**
     * A function to get the permitted plans for a student to transfer between them
     * @param:  
     * @return: 
     */
    public function transferPlan(){

        $nextTermID = Setting::value('next_term_id');
        $student = Auth::user()->student;
        if(empty($student))
           abort(404);

        if(!$student->canTransfer())
           abort(404);

        $gradesTerm = $student->gradesTerms('DESC')->first();


        $allPlans = Plan::select("plans.*", "plans_quota.min_grade")
                    ->join("branching_rules", "plans.id", "branching_rules.to_plan_id")
                    ->leftJoin('plans_quota', function($join) use($nextTermID){
                        $join->on('plans.id', '=', 'plans_quota.plan_id')
                            ->where('plans_quota.term_id', '=', $nextTermID);
                    })
                    ->where("branching_rules.from_plan_id", $gradesTerm->plan_id)
                    ->where("branching_rules.required_credit_hours",'<=',$gradesTerm->final_cumulative_passed_hours )
                    ->get();
                    
        //make sure that the student satisfy the prerequisites of each plan
        $plans = [];
        foreach($allPlans as $plan) {
            if($student->checkPrerequisites($plan))
                $plans[] = $plan;           
        }


        $path = $this->getPath();
        return view('students.services.transfer_plan', compact('path', 'plans'));
        
    }

    public function saveTransferPlan(Request $request){ 

        $nextTermID = Setting::value('next_term_id');

        $student = Auth::user()->student;
        if(empty($student))
           abort(404);

        if(!$student->canTransfer())
           abort(404);

        $request->validate([
            'plan_id' => 'required|numeric',
        ]);

        $plan_id = $request->plan_id;

        $gradesTerm = $student->gradesTerms('DESC')->first();
        if(!$gradesTerm)
            abort(404);
 
         
        TransferToPlanRequest::updateOrCreate(
            ['student_id' => $student->id, 'term_id' => $nextTermID],
            [
                'original_plan_id' => $gradesTerm->plan_id,
                'current_plan_id' => $student->last_plan_id,
                'new_plan_id' => $plan_id
            ]
        );
       

        return redirect()->back()->with('message', __('tr.Your request is submitted successfully'));
        
    }



    /**
     * A function to get the courses of the student to choose and register them
     * @param:  
     * @return: 
     */
    public function coursesRegistration(){   

        $student = Auth::user()->student;
        if(empty($student))
           abort(404);

        if(!isset($student->advisor->en_name))
            abort(404);

            //temp


        //check student's payment status
        //It is a temp solution for this term
        $grades = GradeTerm::where('student_id', $student->id)
                           ->where('term_id', 121) //Summer 2019
                           ->get();

        if(count($grades) > 0 ){ //freshmen

           $student_code = Auth::user()->code;
           $payment_status = DB::table('payment_status')
                               ->where('student_code',$student_code)
                               ->first();
           if(!$payment_status || empty($payment_status))
               abort(404);

        }    

        //Open registration only to some special students that having some issues
        $student_code = Auth::user()->code;
        $force_reg_status = DB::table('force_registration')
                               ->where('student_code',$student_code)
                               ->first();
        if(!$force_reg_status || empty($force_reg_status))
            abort(404);
        //The student who is approved for registration by advisor caanot enter again
        if($student->registered == 1)
            abort(404);

        //temp condition
        //$grades = Grade::where('student_id', $student->id)->get(); 
        //  if(count($grades) > 0)
         //    abort(404);

        // cancelled condition who registered before cannot enter
        //  $studies = Study::where('user_id', $student->id)->where('term_id', 125) ->get(); 
        //  if(count($studies) > 0)
        //    abort(404);

          //temp condition   
        $firatTimeFrahman = $student->firstTime();

        //temp condition
        if($firatTimeFrahman){
            if(!($student->school_study_type == 1 || $student->school_study_type == 3 || $student->school_study_type == 5 || $student->school_study_type == 7 || $student->school_study_type == 9)){
                abort(404);
            }
        }

       //make sure that we can display the result based on the dates
       if(!$student->canRegisterCourses())
          abort(404);

       if(empty($student->last_plan_id) || $student->last_plan_id == null)
           abort(404);

       $currentTerm = Term::currentTerm(); //return wrong term
       $currentTermId = 125;

        //we need to make this dynamic to offer to the students all courses of his previous plans
        if($firatTimeFrahman){
            $plansIDs = [$student->last_plan_id];
        }else{
            $plansIDs = [179, $student->last_plan_id, -1];
        }
        

        //Get all courses for this plan
        $allCourses = Committee::select("committees_plans.plan_id as planID", "committees.term_id", "courses.*", 'studies.id as studies',  'studies.group', 'committees.id as committee_id', 'committees_plans.quota', 'committees_plans.set_number', 'committees_plans.elective', 'groups.section_name', 'plans.en_minor')
                            ->join("committees_plans","committees.id","committees_plans.committee_id")
                            ->leftJoin('courses', 'courses.id', '=', 'committees.course_id')
                            ->leftJoin('studies', function($join) use($currentTermId, $student){
                                $join->on('studies.course_id', '=', 'courses.id')
                                        ->where('studies.term_id', '=', $currentTermId)
                                        ->where('studies.user_id', '=', $student->id)
                                        ->where('studies.plan_id', '=', $student->last_plan_id);
                            })
                            ->leftJoin('groups', 'groups.id', '=', 'studies.group')
                            ->leftJoin('plans', 'plans.id', '=', 'groups.plan_id')
                            ->where("committees.term_id",$currentTermId)
                            ->whereIn('committees_plans.plan_id', $plansIDs)
                            ->orderBy('committees_plans.plan_id')
                            ->get();

        
        if(!$allCourses)
            abort(404);                 
        
        if($firatTimeFrahman){
            //Check the prerequisites of the courses 
            $courses = [];
            foreach($allCourses as $course) {
                if($student->checkPrerequisitesCourse($course->id))
                    $courses[] = $course;
            }
        }else{
            $courses = $allCourses;
        }
        
 
         //dd($courses);
        if($firatTimeFrahman){ //freshmen level

            return $this->freshmenCoursesRegistration($courses, $currentTermId, $student);

        }else{ //for all other levels

            //Get the max allowed courses and credit hours
            $maxCoursesAndCHR = $student->maxAllowedCoursesAndCHR();

            $groups = Group::where('plan_id', $student->last_plan_id)
                            ->whereRaw('taken_quota < quota')->get();
            
            $path = $this->getPath();
            
            return view('students.services.registration',compact('path','courses', 'maxCoursesAndCHR', 'groups', 'student'));
        } 

        
    }


     /**
     * A function to get the courses of the student to register them [Only for freshmen]
     * @param:  
     * @return: 
     */
    private function freshmenCoursesRegistration($courses, $currentTermId, $student){                 
        
        //check if this the first time to the student
        $checkStudies = Study::where('user_id', $student->id)->where('term_id', $currentTermId)->first();

        if($checkStudies && !empty($checkStudies)){//Not the first time

            //get the student set 
            $group = Group::find($checkStudies->group);
            if(!$group)
                abort(404);
            
            $set = $group->set_number;

        }else{ //the first time, so save the courses

            //Here we will divide the students between two sets 
            //Group 1,2,3 first set [S1]
            //Group 4,5,6 second set [S2]
            $group = Group::where('flag', 0)->first();
            if(!$group){ //for the first run if no flag = 0
                //no set found so update all to 0
                DB::select('UPDATE groups SET flag = 0');
                //pick a random set
                $group = Group::where('flag', 0)->first();
            }

            //get the set 
            $set = $group->set_number;
            
            Group::where('set_number','!=', $set)->update(['flag'=>1]);
                
            $this->savefreshmenCoursesRegistration($courses, $set, $currentTermId, $student);
        }

        //find student group 
        $study = Study::where('user_id', $student->id)->where('term_id', $currentTermId)->first();
        if($study)
            $groupSection = Group::where('id', $study->group)->first();
        else
            $groupSection = null;

        if($groupSection)
            $groupSectionName = $groupSection->group_name . ' ' .  $groupSection->section_name;
        else
            $groupSectionName = '';
        
        $path = $this->getPath();
        $groups = [];
        return view('students.services.registration',compact('path','courses', 'student', 'set', 'groups', 'groupSectionName')); 
        
    }

     
     /**
     * A function to save the student's courses [Only for freshmen]
     * @param:  
     * @return: 
     */
    private function savefreshmenCoursesRegistration($courses, $set, $currentTermId, $student){

       
 
        //update the quota of the section
        $groups = Group::where('set_number', $set)->get();
         
        foreach($groups as $group){

            //search for the section
            if($group->quota <= $group->taken_quota)
                continue;

            $groupSectioId = $group->id;
            $group_name = $group->group_name;
            Group::where('id', $groupSectioId)->update(['taken_quota'=> ($group->taken_quota+1)]);
            break;

        }

        //update the flag of the set
        $groupQuotaSum = Group::where('group_name', $group_name)->sum('quota');
        $groupTakenQuotaSum = Group::where('group_name',  $group_name)->sum('taken_quota');

        if($groupTakenQuotaSum == $groupQuotaSum){ 
            //update the flag to 1
            Group::where('set_number', $set)->update(['flag'=>1]);
            //the other set to 0
            Group::where('set_number', '!=' ,$set)->update(['flag'=>0]);
        }
        
 
        //Add the courses to the studies table
        foreach($courses as $course){

            if($course->elective == 1 && $course->set_number != $set) //if the course is elective, check the set number [s1 to s2] 
                continue;
           
            $study = new Study();
            $study->user_id = $student->id;
            $study->course_id = $course->id;
            $study->role = Study::ROLE_STUDENT;
            $study->type = Study::TYPE_FRESH;
            $study->term_id = $currentTermId;
            $study->plan_id =$student->last_plan_id;
            $study->group = $groupSectioId;
            $study->save();
        }

        //update the student's section in the student table
        //Student::where('id', $student->id)->update(['group_id'=> $groupSectioId]);


        return response()->json([], 200);
    }


    public function SaveCoursesRegistration(Request $request){
         
        $student = Auth::user()->student;
        if(empty($student))
            abort(404);
        
        //make sure that we can display the result based on the dates
        if(!$student->canRegisterCourses())
           abort(404);

         //temp condition 
        $firatTimeFrahman = $student->firstTime();
         

        $currentTerm = Term::currentTerm(); //return wrong term
        $currentTermId = 125;

       if($firatTimeFrahman){ //freshmen level
            //As per the requirements just just return success, if the student is freshmen
            return response()->json([], 200);
        }else{

            if(!$request->has('courses') || !$request->has('sections'))
                return response()->json(['error' => array('Some data are invalid, please try again later')], 404);
               
            $courses = $request->courses;
            $sections = $request->sections;
            
            if(empty($courses) || empty($sections))
                return response()->json(['error' => array('.Please select at least one course to register')], 404);
         
            //Delete the  previous registraion and decrease the taken quota by one
            //A- decrease the taken quota by one
            $studies = Study::where('user_id', $student->id)->where('term_id', $currentTermId)->get();
            foreach($studies as $study){

                $section = CourseSection::where('group_id', $study->group)
                                            ->where('course_id', $study->course_id)
                                            ->where('term_id', $study->term_id)
                                            ->first();
                $section->taken = $section->taken-1;
                $section->save();
            }

            //B- delete the previous registraion
            Study::where('user_id', $student->id)->where('term_id', $currentTermId)->delete();

            //Add the courses to the studies table
            foreach($courses as $key=>$course){
                
                //make sure that the saction still has places
                $section = CourseSection::where('group_id', $sections[$key])
                                            ->where('course_id', $course)
                                            ->first();
                if($section){

                    if($section->taken >= $section->quota) //if not so do not register this course for this student
                        continue;

                    $section->taken = $section->taken+1;
                    $section->save();

                }else{ //we could not find the section
                    continue;
                }

                $study = new Study();
                $study->user_id = $student->id;
                $study->course_id = $course;
                $study->role = Study::ROLE_STUDENT;
                $study->type = Study::TYPE_FRESH;
                $study->term_id = $currentTermId;
                $study->plan_id =$student->last_plan_id;
                $study->group = $sections[$key];
                $study->save();

               


            }

            return response()->json([], 200);
            
        } 

        //for later
        /*if($course->quota != -1 )
        {
            if($course->quota <= $course->taken_quota) //all places taken
                continue;
           
            $taken_quota = $course->taken_quota + 1;
            $committee_id = $course->committee_id;
            $plan_id = $student->last_plan_id;

            DB::select("UPDATE committees_plans SET taken_quota = $taken_quota WHERE committee_id = $committee_id AND plan_id = $plan_id");
        }*/

       
    }

     public function my_grades(){ 
  

        $user =  Auth::user();
        $student = $user->student;
        if(empty($student))
            abort(404);

        $path = [];


        $minorField = lang() . "_minor";
        $nameField = lang() . "_name";
        
        $plan = Plan::select(DB::raw("CONCAT(UPPER(plans.bylaw),',', ',',years.$nameField , plans.$minorField) as name"))
            ->leftJoin('years', 'plans.year_id', '=', 'years.id')
            ->where('plans.id', $student->last_plan_id)->first();

        $yearsGrades = $student->yearsGrades();


       //dd($student->gradesTerms);

        $roles = Role::all();

        return view('students.services.my_grades', compact('path', 'user', 'student', 'yearsGrades', 'plan','roles'));
       
    }

    public function selectOnlineExamsMethod() {

        $user =  Auth::user();
        $student = $user->student;
        $currentTerm = Term::currentTerm();
        $status = [] ;

        if(!$student->canChangeOnlineExamMethod())
            abort(401);

        if(empty($student))
            abort(404);

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];

        $minorField = lang() . "_minor";
        $nameField = lang() . "_name";

        $choice = OnlineExamsMethodConfirmation::where('student_id', $student->id)->where('term_id', $currentTerm->id)->first();
        if($choice){
            $oldChoice = $choice->status;
        }else{
            $oldChoice = 0;
        }

        return view('students.services.online_exam_method', compact('path', 'user','student','currentTerm','status', 'oldChoice'));
       
    }

    public function saveOnlineExamsMethod(Request $request) {
        
        $request->validate([
            'student_id' => 'required|numeric',
            'term_id' => 'required|numeric',
            'status' => 'required',
        ]);

        $student_id = $request->student_id;
        $term_id = $request->term_id;
        $status = $request->status;

        $online_exams_method_confirmation =  OnlineExamsMethodConfirmation::updateOrCreate(
            ['student_id' => $student_id, 'term_id' => $term_id],
            ['status' => $status]
            
        );

        if(!$online_exams_method_confirmation)
            abort(404);
         
        return back();
    }

    /**
     * Arch Aptitude Test
     */
    public function archAptitudeTestPaymentConfirmation(){

        $student = Auth::user()->student;
        if(!$student)
            abort(404);

        if(!$student->canAccessArchAptitudeTest())
            abort(401);

        $aptitude_test_term = $student->termStageWithStageCode('arch_aptitude_test');

        $amount = Setting::archAptitudeTestCost();
        $course_id = Setting::value('arch_aptitude_test_course_id'); //

        $committee = Committee::where('course_id', $course_id)->where('term_id', $aptitude_test_term->term_id)->first();
        if(!$committee)
            abort(401);
      
        //Add new record to the user requests table
        $userRequest = new UserRequest();
        $userRequest->user_id = $student->id;
        $userRequest->updated_by = $student->id;
        $userRequest->type = "Arch_aptitude_test";
        $userRequest->save();
        $userRequest->refresh();

        //generate the merchantRefNo
        $merchantRefNo = $userRequest->id.'_'.time(). '@archaptst';

        $data = [
            'term_id' => $aptitude_test_term->term_id,
            'course_id' => $course_id,
            'committee_id' => $committee->id,
            'plan_id' => $student->last_plan_id,
        ];

        $userRequest->data = json_encode($data);
        $userRequest->total_amount = $amount; //$student_payments->total_amount;
        $userRequest->merchant_reference_no = $merchantRefNo;
        $userRequest->payment_provider = '';
        $userRequest->order_status = 'INCOMPLETE';
        $userRequest->save();

        $userRequest->refresh();

        //for bank misr pay with Credit Card transactions only
        $session_id =  $this->createCheckoutSession($merchantRefNo, $userRequest);
        $userRequest->session_id = $session_id;

        //for bank misr pay with Meeza Card transactions only
        $meeza_msg_signature =  $this->createMsgSignature( $amount, $userRequest->created_at);
        $userRequest->meeza_msg_signature = $meeza_msg_signature;

        $userRequest->save();

        if(empty($userRequest->archive_id)) {
            $archive = Archive::get("users_requests/$userRequest->id");
            $userRequest->archive_id = $archive->id;
            $userRequest->save();
            $userRequest->refresh();
        }

     
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];
        
        return view('students/arch_aptitude_test/payment_confirmation', compact('path', 'userRequest'));
    }


    public function  storeTransferIPToSPRequest(Request $request)
    {
        $student = auth()->user()->student;

        if(!$student->isChep())
            abort(401);

        $existing_request = TransferIPToSPRequest::where('student_id', $student->id)->first();
        
        if($existing_request){
           $status = TransferIPToSPRequest::statusLabels()[$existing_request->status];
           return response()->json(['state' => 'success','msg' =>  'You have already submitted an earlier request, and the current status is `'.$status.'` '], 200);
        }

        TransferIPToSPRequest::create([
           'student_id' => auth()->id(),
            'year' => Term::currentTerm()->years,
            'status' => TransferIPToSPRequest::STATUS_IN_PROGRESS
        ]);

        

        return response()->json(['state' => 'success','msg' => __('tr.Your request is submitted successfully')], 200);

           
    }

    public function  storeTransferSPToIPRequest(Request $request)
    {
        $student = auth()->user()->student;

        if($student->isChep())
            abort(401);

        $existing_request = TransferSPToIPRequest::where('student_id', $student->id)->first();
        
        if($existing_request){
           $status = TransferSPToIPRequest::statusLabels()[$existing_request->status];
           return response()->json(['state' => 'success','msg' =>  'You have already submitted an earlier request, and the current status is `'.$status.'` '], 200);
        }

        TransferSPToIPRequest::create([
           'student_id' => auth()->id(),
            'year' => Term::currentTerm()->years,
            'status' => TransferSPToIPRequest::STATUS_IN_PROGRESS
        ]);

        

        return response()->json(['state' => 'success','msg' => __('tr.Your request is submitted successfully')], 200);

           
    }

   

    
}
