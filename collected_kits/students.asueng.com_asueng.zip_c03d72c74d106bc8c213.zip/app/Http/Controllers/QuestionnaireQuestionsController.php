<?php

namespace App\Http\Controllers;

use App\Course;
use App\Questionnaire;
use App\QuestionnaireComment;
use App\QuestionnaireAnswer;
use App\QuestionnaireQuestion;
use App\User;
use App\Department;
use App\QuestionnaireTask;
use App\Plan;
use App\Study;
use App\Term;
use App\Security;
use App\Bylaw;
use App\Quality;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use PDF;
use DB;

class QuestionnaireQuestionsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Questionnaire $questionnaire ,Request $request){

        $lang = lang();

        if ($request->ajax()) {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $section = $columns[0]["search"]["value"];
            $type = $columns[1]["search"]["value"];
            $group = $columns[2]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = \DB::table('questionnaires_questions')->select('*')
                ->orderBy($orderBy, $orderDir);


            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", $textSearch);
                $query->Where(\DB::raw("CONCAT(COALESCE(questionnaires_questions.en_question,''),
                    ' ', COALESCE(questionnaires_questions.ar_question,''),
                    ' ', COALESCE(questionnaires_questions.en_section,''),
                    ' ', COALESCE(questionnaires_questions.ar_section,''))"), "like", "%$textSearch%");
            }

            if ($section) {
                if ($section != 'Empty'){
                    $section = mb_ereg_replace(" ", "%", $section);
                    $query->Where(\DB::raw("CONCAT(COALESCE(questionnaires_questions.en_section,''),
                    ' ', COALESCE(questionnaires_questions.ar_section,''))"), "like", "%$section%");
                } else {
                    $query->Where('questionnaires_questions.'.$lang.'_section',null);
                }
            }

            if ($type) {
                $query->Where('questionnaires_questions.type',$type);
            }

            if ($group != null) {
                $text = lcfirst(QuestionnaireQuestion::questionGroup()[(int)$group]);
                $query->Where('questionnaires_questions.question_group', '=', "$text");
            }

            $result = $query->orderBy('order','asc')
                ->where('questionnaire_id',$questionnaire->id)
                ->paginate($length);

            return [
                'draw' => $draw,
                'recordsTotal' => $result->total(),
                'recordsFiltered' => $result->total(),
                'data' => $result,
            ];
        }

        $path = [
            (object) [
                'link' => route('quality'),
                'title' => __('tr.Quality'),
            ],
            (object) [
                'link' => route('questionnaires'),
                'title' => __('tr.Questionnaires'),
            ],
            (object) [
                'link' => route('manage_questionnaires'),
                'title' => __('tr.Manage Questionnaires'),
            ],
        ];

        $sections = QuestionnaireQuestion::select($lang.'_section')->where('questionnaire_id',$questionnaire->id)->distinct()->get();

        return view('quality.questionnaires.manage.show', compact('path', 'questionnaire','sections'));
    }

    public function save(Questionnaire $questionnaire,QuestionnaireQuestion $question, Request $request){

        if(!auth()->user()->hasPermissionTo('edit_lookups'))
            abort(401);

        $validatedData = $request->validate([
            'en_question'=>'required|string|max:256|min:4',
            'ar_question'=>'required|string|max:256|min:4',
            'type' => 'required|numeric'
        ]);

        \Log::info('Request:', $request->all());

        $question->questionnaire_id = $questionnaire->id;
        if ($request->type == 0){
            $question->type = 0;
            $question->answer1 = 'Strongly Disagree';
            $question->answer2 = 'Disagree';
            $question->answer3 = 'Not Sure';
            $question->answer4 = 'Agree';
            $question->answer5 = 'Strongly Agree';

            $question->required = 1;
        } elseif ($request->type == 1) {
            $question->type = 1;
        } elseif ($request->type == 2) {
            $question->type = 0;
            $question->required = 1;
            $question->answer1 = 'Female';
            $question->answer2 = 'Male';
        }
        $question->en_section = $request->en_section;
        $question->ar_section = $request->ar_section;
        $question->question_group = lcfirst(QuestionnaireQuestion::questionGroup()[$request->question_group]);
        $question->en_question = $request->en_question;
        $question->ar_question = $request->ar_question;

        $question->save();

        if($request->ajax()) {
            $result = [
                'id' => $question->id,
                'en_question' => $question->en_question,
                'ar_question' => $question->ar_question,
            ];
            return response()->json($result);
        }
    }

    public function delete(Questionnaire $questionnaire, QuestionnaireQuestion $question){

        if(!auth()->user()->hasPermissionTo('delete_lookups'))
            abort(401);
        $check_answers = QuestionnaireAnswer::where('question_id', $question->id)->get();

        if (count($check_answers)){
            $response = [
                'status' => 'failed',
                'msg' => "Answers related to this question where found. Operation can't be done!"
            ];
            return response()->json($response);
        }else{
            $question->delete();
            return response()->json('Done');
        }
    }

    public function reorder($id ,$position ,$neighbourID){


        $current  = QuestionnaireQuestion::find($id);
        $neighbour = QuestionnaireQuestion::find($neighbourID);

        if($position == "before") {
            $currentOrder = $current->order;
            $current->order = $neighbour->order?$neighbour->order:($neighbour->order+1);
            $neighbour->order = $currentOrder?$currentOrder:($currentOrder+2);
            $current->save();
            $neighbour->save();
        }
        elseif($position == "after"){
            $currentOrder = $current->order;
            $current->order = $neighbour->order?$neighbour->order:($neighbour->order+2);
            $neighbour->order = $currentOrder?$currentOrder:($currentOrder+1);
            $current->save();
            $neighbour->save();
        }

        $order = ($current->order>$neighbour->order)?($order = $current->order+1) : ($order = $neighbour->order+1);

        $questions = QuestionnaireQuestion::where('questionnaire_id',$current->questionnaire_id)
            ->where(function($q) use($order){
                $q->where('order', '>',$order)
                ->orWhere('order', 0);
            })
            ->get();

        foreach ($questions as $question){
            $question->order = $order;
            $question->save();
            $order++;
        }

        return response('Done');
    }
}