<?php

namespace App\Http\Controllers;

use App\Course;
use App\Questionnaire;
use App\QuestionnaireComment;
use App\QuestionnaireAnswer;
use App\QuestionnaireQuestion;
use App\User;
use App\Department;
use App\QuestionnaireTask;
use App\Training;
use App\StudentTraining;
use App\Plan;
use App\Study;
use App\Term;
use App\Security;
use App\Bylaw;
use App\Quality;
use App\Student;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use PDF;
use DB;
use App\Website;
use App\Setting;

class QuestionnairesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }    

    public function applyIndex() {
        $user = auth()->user();
        $student = $user->student;
        $termId = QuestionnaireTask::max('term_id');

        $term = Setting::currentTerm();

        if($term->questionnaire_id != null && $term->questionnaire_message != null && $term->questionnaire_start_date != null && $term->questionnaire_due_date != null && $term->questionnaire_publish_status != null && $term->active == 1){
            $termId = $term->id;
        }

        

        if(empty($termId) || empty($student)) {
            return redirect()->route('logout');
        }

        $questionnaireId = 0;
        $term = Term::find($termId);
        if($student->bylaw=="UG2013"||$student->bylaw=="UG2007")
            $questionnaireId = $term->questionnaire_id;
        else if($student->bylaw=="UG2003"||$student->bylaw=="UG2018")
            $questionnaireId = $term->questionnaire_id;        

        $questionnaire = Questionnaire::find($questionnaireId);


        $coursesTasks = QuestionnaireTask::select('questionnaires_tasks.*')
            ->join('studies', 'studies.committee_id', 'questionnaires_tasks.committee_id')
            ->where('questionnaires_tasks.term_id', $termId)
            ->where('studies.user_id', $user->id)
            ->where('questionnaires_tasks.questionnaire_id', $questionnaireId)
            ->get();

        $tasks = [];
        $tasks[] = QuestionnaireTask::where('questionnaire_id', $questionnaireId)
            ->where('questionnaires_tasks.committee_id', 0)
            ->where('questionnaires_tasks.term_id', $termId)
            ->where('questionnaires_tasks.questionnaire_id', $questionnaireId)
            ->first();
        

        foreach ($coursesTasks as $task) {
            $tasks[] = $task;
        }

        $path = [
            (object) [
                'link' => route('dashboard'),
                'title' => __('tr.Dashboard'),
            ],
            (object) [
                'link' => route('my_services'),
                'title' => __('tr.My Services'),
            ],
        ];
        return view('quality.questionnaires.apply.index',compact('term','tasks','path'));
    }

    public function applyShow(QuestionnaireTask $questionnaireTask, Request $request) {
        $user = auth()->user();
        $student = $user->student;
        if(empty($student)) {
            return redirect()->route('logout');
        }

        $questionnaire = $questionnaireTask->questionnaire;

        $group = ($questionnaireTask->course_id==0)?'general':'courses';

        $path = [
            (object) [
                'link' => route('dashboard'),
                'title' => __('tr.Quality'),
            ],
        ];

        return view('quality.questionnaires.apply.show', compact( 'student', 'questionnaire', 'questionnaireTask', 'group','path'));
    }

    public function applySave(QuestionnaireTask $questionnaireTask, Request $request) {
        foreach($request->questions_ids as $questionId) {
            $question = QuestionnaireQuestion::find($questionId);

            if($question->type==0) {
                $answer = QuestionnaireAnswer::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->where('question_id', $question->id)->first();
                if(empty($answer)) {
                    $answer = new QuestionnaireAnswer();
                    $answer->task_id = $questionnaireTask->id;
                    $answer->question_id = $question->id;
                    $answer->student_id = auth()->id();
                }
                $answer->answer = $request->answers[$questionId][0];
                if($questionnaireTask->score_factor==1) {
                    switch($answer->answer) {
                        case 1: $answer->score = 25; break;
                        case 2: $answer->score = 50; break;
                        case 3: $answer->score = -1; break;
                        case 4: $answer->score = 76; break;
                        case 5: $answer->score = 100; break;
                    }
                }
                else {
                    $answer->score = null;
                }
                $answer->save();
            } else {
                $answer = QuestionnaireComment::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->where('question_id', $question->id)->first();
                if(empty($answer)) {
                    $answer = new QuestionnaireComment();                
                    $answer->task_id = $questionnaireTask->id;
                    $answer->question_id = $question->id;
                    $answer->student_id = auth()->id();
                }
                $answer->comment = $request->answers[$questionId];
                $answer->save();
            }
        }

        return redirect()->route('questionnaire_apply_index');
    }


    public function graduationSurvey() {

        $user = auth()->user();
        $student = $user->student;
        if(empty($student)) {
            return redirect()->route('logout');
        }
      
        $questionnaireID = Setting::where('name','graduation_questionnaire_id')->first()->value;
        $term = Setting::currentTerm();

        $questionnaireTask = QuestionnaireTask::where('questionnaire_id', $questionnaireID)->where('term_id', $student->last_term_id)->first();
        
        if($questionnaireTask == null){
            $totalStudents = Student::where(function($query) {
                $query->orWhere('status', '&', Student::STATUS_SEMI_GRADUATED);
                $query->orWhere('status', '&', Student::STATUS_GRADUATED);
            })->where('last_term_id', $student->last_term_id)->get()->count();
            
            $questionnaireTask = new QuestionnaireTask();
            $questionnaireTask->term_id = $student->last_term_id;
            $questionnaireTask->questionnaire_id = $questionnaireID;
            $questionnaireTask->count= 0;
            $questionnaireTask->total= $totalStudents;
            $questionnaireTask->save();
        }
        
        $questionnaire = $questionnaireTask->questionnaire;

        $group = 'general';

        $path = [
            (object) [
                'link' => route('dashboard'),
                'title' => __('tr.Dashboard'),
            ],
            (object) [
                'link' => route('my_services'),
                'title' => __('tr.My Services'),
            ],
        ];

        return view('quality.questionnaires.graduation.graduation_survey', compact( 'student', 'questionnaire', 'questionnaireTask', 'group', 'path'));
    }

    public function saveGraduationSurvey(Request $request) {

        $user = auth()->user();
        $student = $user->student;
        
        if(empty($student)) {
            return redirect()->route('logout');
        }

        $questionnaireID = Setting::where('name','graduation_questionnaire_id')->first()->value;
        $term = Setting::currentTerm();
        $questionnaireTask = QuestionnaireTask::where('questionnaire_id', $questionnaireID)->where('term_id', $student->last_term_id)->first();
        $answer = QuestionnaireAnswer::where('student_id', $student->id)->where('task_id', $questionnaireTask->id)->first();
        
        if($answer == null) {
            $questionnaireTask->count += 1;
            $questionnaireTask->save();
        }
        
        foreach($request->questions_ids as $questionId) {
            $question = QuestionnaireQuestion::find($questionId);

            if($question->type==0) {
                $answer = QuestionnaireAnswer::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->where('question_id', $question->id)->first();
                if(empty($answer)) {
                    $answer = new QuestionnaireAnswer();
                    $answer->task_id = $questionnaireTask->id;
                    $answer->question_id = $question->id;
                    $answer->student_id = auth()->id();
                }
                $answer->answer = $request->answers[$questionId][0];

                switch($answer->answer) {
                    case 1: $answer->score = 25; break;
                    case 2: $answer->score = 50; break;
                    case 3: $answer->score = -1; break;
                    case 4: $answer->score = 76; break;
                    case 5: $answer->score = 100; break;
                }

                $answer->save();
            } else {
                $answer = QuestionnaireComment::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->where('question_id', $question->id)->first();
                if(empty($answer)) {
                    $answer = new QuestionnaireComment();                
                    $answer->task_id = $questionnaireTask->id;
                    $answer->question_id = $question->id;
                    $answer->student_id = auth()->id();
                }
                $answer->comment = $request->answers[$questionId];
                $answer->save();
            }
        }
        
        \DB::statement("UPDATE questionnaires_tasks 
            INNER JOIN (SELECT task_id, count(DISTINCT student_id) as count, AVG(score) as average_score, STDDEV(score) as stddev_score  FROM questionnaires_answers WHERE score>=0 GROUP BY task_id) AS T 
            ON questionnaires_tasks.id = T.task_id 
            SET questionnaires_tasks.status = 0, questionnaires_tasks.count = T.count, questionnaires_tasks.average_score = convert(T.average_score, SIGNED), questionnaires_tasks.stddev_score = convert(T.stddev_score, SIGNED)
            WHERE task_id = ($questionnaireTask->id)");

        return redirect()->route('my_services');
    }

    public function trainingQuestionnaire(QuestionnaireTask $questionnaireTask) {
        
        $user = auth()->user();
        $student = $user->student;
        if(empty($student)) {
            return redirect()->route('logout');
        }

        $questionnaire = $questionnaireTask->questionnaire;

        $group = 'general';

        $path = [
            (object) [
                'link' => route('dashboard'),
                'title' => __('tr.Dashboard'),
            ],
            (object) [
                'link' => route('my_services'),
                'title' => __('tr.My Services'),
            ],
        ];

        return view('quality.questionnaires.training.training', compact( 'student', 'questionnaire', 'questionnaireTask', 'group', 'path'));
    }

    public function saveTrainingQuestionnaire(Request $request) {

        $user = auth()->user();
        $student = $user->student;
        
        if(empty($student)) {
            return redirect()->route('logout');
        }
  
        $questionnaireTask = QuestionnaireTask::where('id', $request->task_id)->first();

        $answer = QuestionnaireAnswer::where('student_id', $student->id)->where('task_id', $questionnaireTask->id)->first();
        
        if($answer == null) {
            $questionnaireTask->count += 1;
            $questionnaireTask->save();
        }
        
        foreach($request->questions_ids as $questionId) {
            $question = QuestionnaireQuestion::find($questionId);

            if($question->type==0) {
                $answer = QuestionnaireAnswer::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->where('question_id', $question->id)->first();
                if(empty($answer)) {
                    $answer = new QuestionnaireAnswer();
                    $answer->task_id = $questionnaireTask->id;
                    $answer->question_id = $question->id;
                    $answer->student_id = auth()->id();
                }
                $answer->answer = $request->answers[$questionId][0];

                switch($answer->answer) {
                    case 1: $answer->score = 25; break;
                    case 2: $answer->score = 50; break;
                    case 3: $answer->score = -1; break;
                    case 4: $answer->score = 76; break;
                    case 5: $answer->score = 100; break;
                }

                $answer->save();
            } else {
                $answer = QuestionnaireComment::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->where('question_id', $question->id)->first();
                if(empty($answer)) {
                    $answer = new QuestionnaireComment();                
                    $answer->task_id = $questionnaireTask->id;
                    $answer->question_id = $question->id;
                    $answer->student_id = auth()->id();
                }
                $answer->comment = $request->answers[$questionId];
                $answer->save();
            }
        }
        
        \DB::statement("UPDATE questionnaires_tasks 
            INNER JOIN (SELECT task_id, count(DISTINCT student_id) as count, AVG(score) as average_score, STDDEV(score) as stddev_score  FROM questionnaires_answers WHERE score>=0 GROUP BY task_id) AS T 
            ON questionnaires_tasks.id = T.task_id 
            SET questionnaires_tasks.status = 0, questionnaires_tasks.count = T.count, questionnaires_tasks.average_score = convert(T.average_score, SIGNED), questionnaires_tasks.stddev_score = convert(T.stddev_score, SIGNED)
            WHERE task_id = ($questionnaireTask->id)");

        return redirect()->route('my_services');
    }

}