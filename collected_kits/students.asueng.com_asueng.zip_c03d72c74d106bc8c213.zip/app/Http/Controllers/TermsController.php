<?php

namespace App\Http\Controllers;

use App\Bylaw;
use App\Course;
use App\CourseFilesTask;
use App\Exams;
use App\Grade;
use App\GradeTotal;
use App\Plan;
use App\Study;
use App\Term;
use App\Questionnaire;
use App\TermPlanCourse;
use App\TermPlan;
use App\Year;
use App\Department;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Pagination\Paginator;
use Illuminate\Validation\Rule;
use Maatwebsite\Excel\Facades\Excel;

class TermsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the terms page.
     *
     * @return Response
     */
    public function index(Request $request)
    {

        if(!auth()->user()->hasPermissionTo('access_terms'))
            abort(401);

        if ($request->ajax()){

            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $lang = lang();
            $terms = Term::select('id' ,$lang.'_name as name' ,'years', 'start_date', 'end_date','active')
                ->where('active','=','1')
                ->orderBy($orderBy, $orderDir);

            if ($textSearch){
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $terms->where(\DB::raw("CONCAT(COALESCE(en_name,''), ' ', COALESCE(ar_name,''))"), "like", "%$textSearch%");
            }

            $terms = $terms->paginate($length);

            $terms->getCollection()->transform(function ($value) {
                $courseFilesTask = CourseFilesTask::where('term_id', $value->id)->first();
                $exams = Exams::where('term_id', $value->id)->first();
//                $grades = Grade::where('term_id', $value->id)->first();       //Still slow even after making index
                $gradesTotal = GradeTotal::where('term_id', $value->id)->first();
                $students = Study::where('term_id', $value->id)->where('role',1)->first();

                $check = 1;
                if (empty($courseFilesTask) && empty($exams) && empty($grades) && empty($gradesTotal) && empty($students)) {
                    $check = 0;
                }

                $value->check = $check;
                return $value;
            });

            $result = [
                'draw' => $draw,
                'recordsTotal' => $terms->total(),
                'recordsFiltered' => $terms->total(),
                'data' => $terms
            ];

            return $result;
        }

        $path = [
            (object)[
                'link' => route('manage'),
                'title' => __('tr.Manage')
            ],
        ];

        return view('terms.index', compact('path'));
    }

    /**
     * Show the term page.
     *
     * @param Term $term
     * @return Response
     */
    public function show(Term $term, Request $request)
    {
        if(!auth()->user()->hasPermissionTo('show_terms'))
            abort(401);

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $bylaw = $columns[0]["search"]["value"];
            $departmentId = $columns[1]["search"]["value"];
            $yearID = $columns[2]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = null;

            $lang = lang();
            $query = Plan::select('plans.id', 'plans.bylaw', 'plans.'.$lang.'_major as major_name', 'plans.'.$lang.'_program as program_name', 'plans.'.$lang.'_minor as minor_name' ,
                'years.'.$lang.'_name as year_name')
                ->join('years','years.id','=','plans.year_id')
                ->join('terms_plans', 'terms_plans.plan_id', '=', 'plans.id')
                ->join('terms', 'terms.id', '=', 'terms_plans.term_id')
                ->where('terms.id', '=', $term->id)
                ->orderBy($orderBy, $orderDir);

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $query->where(\DB::raw("CONCAT(COALESCE(plans.bylaw,''), ' ', COALESCE(plans.en_major,''), ' ', COALESCE(plans.en_minor,''), ' ', COALESCE(plans.ar_major,''), ' ', COALESCE(plans.ar_minor,''), ' ', COALESCE(years.en_name,''), ' ', COALESCE(years.ar_name,''))"), "like", "%$textSearch%");
            }

            if ($bylaw){
                $query->where('plans.bylaw', $bylaw);
            }

            if ($departmentId!==null) {
                $department = Department::find($departmentId);
                if($department->parent_id==0)
                    $query->where('plans.major_department_id', $departmentId);
                else
                    $query->where('plans.minor_department_id', $departmentId);
            }

            if ($yearID!==null){
                $query->where('plans.year_id', $yearID);
            }

            \Log::info('Request:', [$query->toSql()]);

            $rows = $query->paginate($length);

            $rows->getCollection()->transform(function ($value) use($term) {
                $checkStudents = Study::where('plan_id', '=', $value->id)->where('term_id', '=', $term->id)->where('role', '=', 1)->first();
                $courseFilesTask = CourseFilesTask::where('plan_id', '=', $value->id)->where('term_id', $value->id)->first();
                $gradesTotal = GradeTotal::where('plan_id', '=', $value->id)->where('term_id', $value->id)->first();

                if (empty($checkStudents) && empty($courseFilesTask) && empty($gradesTotal)){
                    $value->check_students = 1;
                } else {
                    $value->check_students = 0;
                }

                return $value;
            });

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $bylaws = Bylaw::where('current', 1)->orderBy('code', 'DESC')->get();

        $path = [
            (object)[
                'link' => route('manage'),
                'title' => __('tr.Manage')
            ],
            (object)[
                'link' => route('terms'),
                'title' => __('tr.Terms')
            ],
        ];

        $closeAddPlan = empty(GradeTotal::where('term_id', $term->id)->first());

        $years = Year::all();
        $departments = Department::orderBY('code')->get();

        return view('terms.show', compact('path', 'term', 'bylaws', 'closeAddPlan', 'years', 'departments'));
    }

    /**
     * Edit the term.
     *
     * @param Term $term
     * @param null $section
     * @return Response
     */
    public function edit(Term $term, $section = null)
    {
        if($section=="course_files" && !auth()->user()->hasPermissionTo('edit_coursefiles'))
            abort(401);
        else if($section=="questionnaires" && !auth()->user()->hasPermissionTo('edit_questionnaires'))
            abort(401);
        else if($section=="general" && !auth()->user()->hasPermissionTo('edit_terms'))
            abort(401);

        $path = [
            (object)[
                'link' => route('manage'),
                'title' => __('tr.Manage')
            ],
            (object)[
                'link' => route('terms'),
                'title' => __('tr.Terms')
            ]
        ];

        if(empty($term->id))
        {
            $term->id = 0;
        }
        else
        {
            $path[] = (object)[
                'link' => route('show_term', ['id'=>$term->id]),
                'title' => $term->lang('name')];
        }

        if($section=="course_files") {

            return view('terms/edit_course_files', compact('path', 'term'));
        } else if($section=="questionnaire") {

            $questionnaires = Questionnaire::select('id', 'en_name as name')->orderBy('id', 'desc')->pluck('name', 'id')->toArray();
            return view('terms/edit_questionnaire', compact('path', 'term', 'questionnaires'));
        }

        $copyTerms = Term::where('active','=','1')->orderBy('start_date', 'desc')->get();

        return view('terms/edit', compact('path', 'term', 'copyTerms'));
    }

    /**
     * Save the term.
     *
     * @param Term $term
     * @param Request $request
     * @param null $section
     * @return Response
     */
    public function save(Term $term, Request $request, $section = null)
    {
        $id = $term->id;

        if($section=="course_files" && !auth()->user()->hasPermissionTo('edit_coursefiles'))
            abort(401);
        else if($section=="questionnaires" && !auth()->user()->hasPermissionTo('edit_questionnaires'))
            abort(401);
        else if($section=="general" && !auth()->user()->hasPermissionTo('edit_terms'))
            abort(401);

        $termsIDs = Term::select('id')->pluck('id')->toArray();

        if($section == "course_files") {
            $term->course_files_start_date = $request->course_files_start_date;
            $term->course_files_due_date = $request->course_files_due_date;
            $term->course_files_message = $request->course_files_message;
            $term->course_file_super_edit_mode = $request->course_file_super_edit_mode;
            $term->active = 1;
            $term->save();
        } else if($section == "questionnaire") {
            $term->questionnaire_id = $request->questionnaire_id;
            $term->questionnaire_start_date = $request->questionnaire_start_date;
            $term->questionnaire_due_date = $request->questionnaire_due_date;
            $term->questionnaire_message = $request->questionnaire_message;
            $term->questionnaire_publish_status = $request->questionnaire_publish_status;
            $term->active = 1;
            $term->save();

        } else {

            $validate = [
                'en_name' => 'required|unique:terms,en_name,en_old_name|string|max:50'.($id)?Rule::unique('terms','en_name')->ignore($id):'',
                'ar_name' => 'required|unique:terms,ar_name,ar_old_name|string|max:50'.($id)?Rule::unique('terms','ar_name')->ignore($id):'',
                'years' => 'required|min:9|max:9',
                'start_date' => 'required|date|after:yesterday',
                'end_date' => 'required|date|after:start_date',
                'copy_term' => Rule::in($termsIDs),
            ];

            $messages = [
                'en_name.*' => __('tr.English Name is required and must be unique'),
                'ar_name.*' => __('tr.Arabic Name is required and must be unique'),
                'years.*' => __('tr.Years is required and must be in format of (yyyy/yyyy)'),
                'start_date.*' => __('tr.Start Date is required'),
                'end_date.*' => __('tr.End Date is required and must be date after Start Date'),
                'copy_term.*' => __('tr.You should Copy from displayed terms list'),
            ];

            if ($request->copy_term == null){
                array_pop($validate);
                array_pop($messages);
            }

            $validatedData = $request->validate($validate,$messages);

            $term->fill($request->all());
            $term->active = 1;
            $term->save();
        }

        if ($request->copy_term != null){
            $plans = null;
            $courses = null;
            $studies = null;
            if($request->copy_term < 120){
                $plans = Study::where('term_id', '=', $request->copy_term)
                    ->where('role', '!=', 1)
                    ->where('plan_id', '!=', 0)
                    ->groupBy('plan_id')
                    ->get();

                $courses = Study::select('studies.*', 'courses.elective')
                    ->where('term_id', '=', $request->copy_term)
                    ->join('courses', 'courses.id', '=', 'studies.course_id')
                    ->where('role', '!=', 1)
                    ->where('studies.plan_id', '!=', 0)
                    ->groupBy('course_id')
                    ->get();

                $studies = Study::where('term_id', '=', $request->copy_term)
                    ->where('role', '!=', 1)
                    ->where('plan_id', '!=', 0)
                    ->get();
            } else {
                $plans = TermPlan::where('term_id', '=', $request->copy_term)
                    ->where('plan_id', '!=', 0)
                    ->groupBy('plan_id')
                    ->get();

                $courses = TermPlanCourse::select('*')
                    ->where('term_id', '=', $request->copy_term)
                    ->where('plan_id', '!=', 0)
                    ->groupBy('course_id')
                    ->get();
            }
            $plansData = [];
            $coursesData = [];
            $studiesData = [];

            foreach ($plans as $plan){
                $plansData[] = [
                    'term_id' => $term->id,
                    'plan_id' => $plan->plan_id
                ];
            }

            foreach ($courses as $course){
                $coursesData[] = [
                    'term_id' => $term->id,
                    'course_id' => $course->course_id,
                    'plan_id' => $course->plan_id,
                    'elective' => $course->elective
                ];
            }
            if ($studies != null){
                foreach ($studies as $study){
                    $studiesData[] = [
                        'term_id' => $term->id,
                        'course_id' => $study->course_id,
                        'plan_id' => $study->plan_id,
                        'user_id' => $study->user_id,
                        'role' => $study->role,
                    ];
                }
            }

            \DB::table('terms_plans')->insert($plansData);
            \DB::table('terms_plans_courses')->insert($coursesData);
            if ($studies != null){
                \DB::table('studies')->insert($studiesData);
            }
            $term->save();
        }

        return redirect(route('show_term', ['id'=>$term->id]));

    }

    /**
     * Show the terms page.
     *
     * @param Term $term
     * @return void
     * @throws Exception
     */
    public function delete(Term $term)
    {
        if(!auth()->user()->hasPermissionTo('delete_terms'))
            abort(401);

        $studentsExists = Study::where('term_id', '=', $term->id)->where('role', '=', 1)->get();
        if (count($studentsExists)){
            return response()->json([
                'error' => __("tr.Term Can't be deleted")
            ],404);
        } else {
            \DB::table('terms_plans')->where('term_id', '=', $term->id)->delete();
            \DB::table('terms_plans_courses')->where('term_id', '=', $term->id)->delete();
            \DB::table('studies')->where('term_id', '=', $term->id)->delete();
            $term->delete();
        }

        die('done');
    }

    public function savePlan(Request $request, Term $term)
    {
//        if(!auth()->user()->hasPermissionTo('delete_terms'))
//            abort(401);

        $plans = [];
        if ($request->plans_ids){

            foreach ($request->plans_ids as $plan){
                $checkPlan = \DB::table('terms_plans')->where('term_id', $term->id)->where('plan_id', $plan)->first();
                if (!$checkPlan){
                    $plans[] = $plan;
                }
            }

            if (count($plans)) {
                $gradesTotal = GradeTotal::where('term_id', $term->id)->first();
                if (empty($gradesTotal)){
                    foreach ($plans as $plan){
                        \DB::table('terms_plans')->insert([
                            'term_id' => $term->id,
                            'plan_id' => $plan
                        ]);
                    }
                    return response()->json('Done');
                }

                return response()->json([
                    'errors' => [
                        'exist' => __('tr.Term is closed, no plans can be added')
                    ]
                ],404);
            } else {
                return response()->json([
                    'errors' => [
                        'exist' => __('tr.All selected plans already assigned to this term')
                    ]
                ],404);
            }
        } else {
            return response()->json([
                'errors' => [
                    'exist' => __('tr.Please choose plan first')
                ]
            ],404);
        }
    }

    /**
     * @param Term $term
     * @param Plan $plan
     * @return JsonResponse
     */
    public function deletePlan(Term $term, Plan $plan)
    {
        if(!auth()->user()->hasPermissionTo('delete_studies'))
            abort(401);

        $checkStudents = Study::where('term_id', '=', $term->id)
            ->where('plan_id', '=', $plan->id)
            ->where('role', '=', 1)
            ->first();

        if (empty($checkStudents)){
            \DB::table('terms_plans')
                ->where('term_id', '=', $term->id)
                ->where('plan_id', '=', $plan->id)
                ->delete();

            Study::where('term_id', '=', $term->id)
                ->where('plan_id', '=', $plan->id)
                ->delete();

            die('Done');
        } else {
            return response()->json([
                'errors' => [
                    'exist' => __("tr.Students already assigned to this plan, it can't deleted")
                ]
            ]);
        }

    }

    public function viewPlan(Term $term, Plan $plan, Request $request){
        $lang = lang();

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = Course::select('courses.id as course_id', 'courses.code', 'courses.'.$lang.'_name as name',
                'departments.'.$lang.'_name as department', 'bylaws.'.$lang.'_name as bylaw_title',
                'bylaws.code as bylaw_code','terms_plans_courses.term_id', 'terms_plans_courses.plan_id', 'terms_plans_courses.elective as elective_course')
                ->join('departments','departments.id','=','courses.offering_department_id')
                ->join('bylaws', 'bylaws.code', '=', 'courses.bylaw')
                ->join('terms_plans_courses', 'terms_plans_courses.course_id', '=', 'courses.id')
                ->join('terms', 'terms.id', '=', 'terms_plans_courses.term_id')
                ->where('terms_plans_courses.term_id', '=', $term->id)
                ->where('terms_plans_courses.plan_id', '=', $plan->id)
                ->orderBy($orderBy, $orderDir);


            \Log::info('Request:', [$query->toSql()]);

            $rows = $query->paginate($length);

            $rows->getCollection()->transform(function ($value) {

                $teachers = Study::select('users.id as user_id', 'departments.code', 'users.en_name')
                    ->join('instructors' ,'instructors.id', '=', 'studies.user_id')
                    ->join('users', 'users.id', '=', 'instructors.id')
                    ->join('departments', 'departments.id', '=', 'instructors.department_id')
                    ->where('term_id', '=', $value->term_id)
                    ->where('course_id', '=', $value->course_id)
                    ->where('plan_id', '=', $value->plan_id)
                    ->where('role', '=', 2)
                    ->get()->toArray();

                $teachingAssistants = Study::select('users.id as user_id', 'departments.code', 'users.en_name')
                    ->join('instructors' ,'instructors.id', '=', 'studies.user_id')
                    ->join('users', 'users.id', '=', 'instructors.id')
                    ->join('departments', 'departments.id', '=', 'instructors.department_id')
                    ->where('term_id', '=', $value->term_id)
                    ->where('course_id', '=', $value->course_id)
                    ->where('plan_id', '=', $value->plan_id)
                    ->where('role', '=', 4)
                    ->get()->toArray();

                $examiners = Study::select('users.id as user_id', 'departments.code', 'users.en_name')
                    ->join('instructors' ,'instructors.id', '=', 'studies.user_id')
                    ->join('users', 'users.id', '=', 'instructors.id')
                    ->join('departments', 'departments.id', '=', 'instructors.department_id')
                    ->where('term_id', '=', $value->term_id)
                    ->where('course_id', '=', $value->course_id)
                    ->where('plan_id', '=', $value->plan_id)
                    ->where('role', '=', 3)
                    ->get()->toArray();

                $value->teachers = $teachers;
                $value->teaching_assistants = $teachingAssistants;
                $value->examiners = $examiners;

                $checkStudents = Study::where('plan_id', '=', $value->plan_id)
                    ->where('term_id', '=', $value->term_id)
                    ->where('course_id', '=', $value->course_id)
                    ->where('role', '=', 1)
                    ->first();

                if (empty($checkStudents)){
                    $value->check_students = 1;
                } else {
                    $value->check_students = 0;
                }

                return $value;
            });

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $path = [
            (object)[
                'link' => route('manage'),
                'title' => __('tr.Manage')
            ],
            (object)[
                'link' => route('terms'),
                'title' => __('tr.Terms')
            ],
            (object)[
                'link' => route('show_term',['id'=>$term->id]),
                'title' => $term->lang('name')
            ],
        ];

        $closeAddCourse = empty(GradeTotal::where('term_id', $term->id)->first());
        /*$bylaw = $plan->getBylaw;
        $code = "code";
        if($lang=="ar")$code = "ar_code";

        $planCourses = \DB::table('courses')
            ->select(\DB::raw("courses.id, courses.plan_id as course_plan_id,courses.".$lang."_name as name,
                    (CASE WHEN courses.$code>'' THEN courses.$code ELSE courses.code END) as code,
                    departments.".$lang."_name as department, courses.bylaw, bylaws.".$lang."_name as bylaw_title , 
                    CONCAT(UPPER(plans.bylaw), ':', CASE WHEN plans.year_id<100 THEN years.".$lang."_name 
                    ELSE plans.".$lang."_program END, ', ',plans.".$lang."_minor) as plan_name"))
            ->leftJoin('plans','plans.id','=', 'courses.plan_id')
            ->leftjoin('departments','courses.offering_department_id','=','departments.id')
            ->leftjoin('years','years.id','=', 'plans.year_id')
            ->leftjoin('bylaws','bylaws.code','=','courses.bylaw')
            ->where('courses.bylaw', $bylaw->code)
//            ->whereNotNull('courses.plan_id')
            ->whereNull('courses.base_course_id')
            ->Where('courses.active', '=', 1)
            ->get();

//        dd($planCourses);*/
        return view('terms.add_courses',compact('path','plan', 'term', 'closeAddCourse'/*, 'planCourses'*/));
    }

    public function saveCourse(Request $request, Term $term, Plan $plan, Course $course)
    {
        if(!auth()->user()->hasPermissionTo('add_studies'))
            abort(401);

        if (!$course->id && empty($request->courses_ids)){
            $checkStudies = Study::where('plan_id', $plan->id)->where('term_id', $term->id)->where('course_id', $request->course_id)->first();
            $checkTermsPlans = \DB::table('terms_plans_courses')->where('plan_id', $plan->id)
                ->where('term_id', $term->id)->where('course_id', $request->course_id)->first();

            if ($checkStudies || $checkTermsPlans) {
                return response()->json([
                    'errors' => [
                        'exist' => __('tr.Course Already assigned to this plan')
                    ]
                ], 404);
            } else {
                $checkTermStatus = Study::where('term_id', $term->id)->where('role', 1)->first();
                if (empty($checkTermStatus)){
                    $gradesTotal = GradeTotal::where('term_id', $term->id)->first();
                    if (empty($gradesTotal)){
                        TermPlanCourse::create([
                            'term_id' => $term->id,
                            'course_id' => $request->course_id,
                            'plan_id' => $plan->id,
                            'elective' => $request->elective=='true'?1:0
                        ]);

                        $this->addUsersToCourses($term, $plan, $request->course_id, $request);
                        return response()->json('Done');
                    }
                }

                return response()->json([
                    'errors' => [
                        'exist' => __('tr.Term is closed, no courses can be added')
                    ]
                ],404);
            }
        } elseif(!$request->course_id && !empty($request->courses_ids)){
            $coursesIDs = $request->courses_ids;
            $courses = [];
            foreach ($coursesIDs as $coursesID){
                $checkStudies = Study::where('plan_id', $plan->id)->where('term_id', $term->id)->where('course_id', $coursesID)->first();
                $checkTermsPlans = \DB::table('terms_plans_courses')->where('plan_id', $plan->id)
                    ->where('term_id', $term->id)->where('course_id', $coursesID)->first();

                if (!$checkStudies && !$checkTermsPlans){
                    $courses[] = $coursesID;
                }
            }

            if (count($courses)){
                $checkTermStatus = Study::where('term_id', $term->id)->where('role', 1)->first();
                if (empty($checkTermStatus)){
                    $gradesTotal = GradeTotal::where('term_id', $term->id)->first();
                    if (empty($gradesTotal)){
                        foreach ($courses as $courseID){
                            TermPlanCourse::create([
                                'term_id' => $term->id,
                                'course_id' => $courseID,
                                'plan_id' => $plan->id,
                            ]);
                        }
                        return response()->json('Done');
                    }
                }

                return response()->json([
                    'errors' => [
                        'exist' => __('tr.Term is closed, no courses can be added')
                    ]
                ],404);
            } else {
                return response()->json([
                    'errors' => [
                        'exist' => __('tr.All Selected Courses already assigned to this plan.')
                    ]
                ],404);
            }
        } else {
            $result = $this->addUsersToCourses($term, $plan, $course->id, $request);

            if ($result == false){
                return response()->json([
                    'errors' => [
                        'update' => __('tr.Please update some fields first'),
                    ]
                ], 404);
            }

            return response()->json('Done');
        }

    }

    public function addUsersToCourses($term, $plan, $course, $request) {

        $flag = false;
        $check = TermPlanCourse::where('term_id', $term->id)->where('plan_id', $plan->id)->where('course_id', $course)->first()->elective;

        $elective = ($request->elective=='on')?1:0;
        if ($elective != $check){
            TermPlanCourse::where('term_id', $term->id)->where('plan_id', $plan->id)->where('course_id', $course)->update([
                'elective' => $elective
            ]);
            $flag = true;
        }

        $usersRoles = [2,3,4];
        $anyUser = Study::where('term_id', $term->id)->where('plan_id', $plan->id)->where('course_id', $course)->whereIn('role', $usersRoles)->first();

        if (($request->teachers || $request->teaching_assistants || $request->examiners) || !empty($anyUser)){
            $data = [];
            $countTeachers = 0;
            $countExaminers = 0;
            $countTeachingAssistants = 0;

            if ($request->teachers){
                foreach ($request->teachers as $teacher){
                    $data[] = array('user_id'=>$teacher, 'term_id'=> $term->id, 'plan_id'=> $plan->id, 'course_id' => $course, 'role' => 2);
                    $countTeachers++;
                }
            }

            if ($request->examiners){
                foreach ($request->examiners as $examiner){
                    $data[] = array('user_id' => $examiner, 'term_id' => $term->id, 'plan_id' => $plan->id, 'course_id' => $course, 'role' => 3);
                    $countExaminers++;
                }
            }

            if ($request->teaching_assistants) {
                foreach ($request->teaching_assistants as $teaching_assistants) {
                    $data[] = array('user_id' => $teaching_assistants, 'term_id' => $term->id, 'plan_id' => $plan->id, 'course_id' => $course, 'role' => 4);
                    $countTeachingAssistants++;
                }
            }

            if (!empty($data)){
                Study::where('term_id', $term->id)->where('plan_id', $plan->id)->where('course_id', $course)->whereIn('role', $usersRoles)->delete();
                foreach ($data as $item){
                    Study::updateOrCreate($item);
                }
                $flag = true;
            } else {
                Study::where('term_id', $term->id)->where('plan_id', $plan->id)->where('course_id', $course)->whereIn('role', $usersRoles)->delete();
                $flag = true;
            }
        }

        return $flag;
    }

    public function deleteCourse(Term $term, Plan $plan,Course $course)
    {
        if(!auth()->user()->hasPermissionTo('delete_studies'))
            abort(401);

        $checkStudents = Study::where('term_id', '=', $term->id)
            ->where('plan_id', '=', $plan->id)
            ->where('course_id', '=', $course->id)
            ->where('role', '=', 1)
            ->first();

        if (empty($checkStudents)) {

            \DB::table('terms_plans_courses')
                ->where('term_id', '=', $term->id)
                ->where('course_id', '=', $course->id)
                ->where('plan_id', '=', $plan->id)
                ->delete();

            Study::where('term_id', '=', $term->id)
                ->where('plan_id', '=', $plan->id)
                ->where('course_id', '=', $course->id)
                ->delete();

            return response()->json();
        }

        return response()->json(['errors' => ['exist' => __("tr.Students already assigned to this course, it can't deleted") ]]);
    }

    public function exportCourses(Term $term, Plan $plan){
        $lang = lang();
        $query = Course::select('courses.id as course_id', 'courses.code', 'courses.'.$lang.'_name as name',
            'departments.'.$lang.'_name as department', 'bylaws.'.$lang.'_name as bylaw_title',
            'bylaws.code as bylaw_code','terms_plans_courses.term_id', 'terms_plans_courses.plan_id', 'terms_plans_courses.elective as elective_course')
            ->join('departments','departments.id','=','courses.offering_department_id')
            ->join('bylaws', 'bylaws.code', '=', 'courses.bylaw')
            ->join('terms_plans_courses', 'terms_plans_courses.course_id', '=', 'courses.id')
            ->join('terms', 'terms.id', '=', 'terms_plans_courses.term_id')
            ->where('terms_plans_courses.term_id', '=', $term->id)
            ->where('terms_plans_courses.plan_id', '=', $plan->id)
            ->get();

        $query->transform(function ($value) {

            $teachers = Study::select('users.id as user_id', 'departments.code', 'users.en_name')
                ->join('instructors' ,'instructors.id', '=', 'studies.user_id')
                ->join('users', 'users.id', '=', 'instructors.id')
                ->join('departments', 'departments.id', '=', 'instructors.department_id')
                ->where('term_id', '=', $value->term_id)
                ->where('course_id', '=', $value->course_id)
                ->where('plan_id', '=', $value->plan_id)
                ->where('role', '=', 2)
                ->get()->toArray();

            $teachingAssistants = Study::select('users.id as user_id', 'departments.code', 'users.en_name')
                ->join('instructors' ,'instructors.id', '=', 'studies.user_id')
                ->join('users', 'users.id', '=', 'instructors.id')
                ->join('departments', 'departments.id', '=', 'instructors.department_id')
                ->where('term_id', '=', $value->term_id)
                ->where('course_id', '=', $value->course_id)
                ->where('plan_id', '=', $value->plan_id)
                ->where('role', '=', 4)
                ->get()->toArray();

            $examiners = Study::select('users.id as user_id', 'departments.code', 'users.en_name')
                ->join('instructors' ,'instructors.id', '=', 'studies.user_id')
                ->join('users', 'users.id', '=', 'instructors.id')
                ->join('departments', 'departments.id', '=', 'instructors.department_id')
                ->where('term_id', '=', $value->term_id)
                ->where('course_id', '=', $value->course_id)
                ->where('plan_id', '=', $value->plan_id)
                ->where('role', '=', 3)
                ->get()->toArray();

            $value->teachers = $teachers;
            $value->teaching_assistants = $teachingAssistants;
            $value->examiners = $examiners;

            $checkStudents = Study::where('plan_id', '=', $value->plan_id)
                ->where('term_id', '=', $value->term_id)
                ->where('course_id', '=', $value->course_id)
                ->where('role', '=', 1)
                ->first();

            if (empty($checkStudents)){
                $value->check_students = 1;
            } else {
                $value->check_students = 0;
            }

            return $value;
        });

        return Excel::create('Courses Report', function ($excel) use ($query) {
            $excel->sheet('Courses', function ($sheet) use ($query) {
                $result = [];
                foreach ($query as $item) {
                    $teachers = '';
                    $teaching_assistants = '';
                    $examiners = '';

                    if (count($item->teachers)){
                        foreach ($item->teachers as $teacher){
                            $teachers .= ($teachers=='') ? $teacher['en_name'] : (', '.$teacher['en_name']);
                        }
                    }

                    if (count($item->teaching_assistants)) {
                        foreach ($item->teaching_assistants as $teaching_assistant) {
                            $teaching_assistants .= ($teaching_assistants == '') ? $teaching_assistant['en_name'] : (', ' . $teaching_assistant['en_name']);
                        }
                    }

                    if (count($item->examiners)) {
                        foreach ($item->examiners as $examiner) {
                            $examiners .= ($examiners == '') ? $examiner['en_name'] : (', ' . $examiner['en_name']);
                        }
                    }
                    $teachers = ($teachers!="") ? $teachers : 'No Data';
                    $teaching_assistants = ($teaching_assistants!="") ? $teaching_assistants : 'No Data';
                    $examiners = ($examiners!="") ? $examiners : 'No Data';
                    $result[] = array(
                        'Course Code' => $item->code,
                        'Course Name' => $item->name,
                        'Offered By' => $item->department,
                        'Bylaw' => $item->bylaw,
                        'Elective' => ($item->elective_course!=0)?'Elective':'Mandatory',
                        'Teachers' => $teachers,
                        'Teaching Assistants' => $teaching_assistants,
                        'Examiner Committee' => $examiners,
                    );
                }
                $sheet->fromArray($result);
            });
        })->download('xlsx');
    }
}