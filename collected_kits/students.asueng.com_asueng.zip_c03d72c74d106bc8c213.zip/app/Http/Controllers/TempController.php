<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Student;
use App\Bylaw;
use App\User;
use App\BranchingPreference;
use App\Plan;
use App\Study;
use App\UserRequest;
use App\ChangeTrackPreference;
use App\Term;
use App\Committee;
use App\Group;
use App\Grade;
use App\GradeTerm;
use App\CourseSection;

use Illuminate\Support\Facades\Validator;

use Spatie\Permission\Models\Role;

use Exception;
use Auth;
use DB;

class TempController extends Controller
{
    //
}
