<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\UserRequest;


use Exception;

class UsersRequestsController extends Controller
{
    
    public function __construct() {
        $this->middleware('auth')->except('fawrytrans', 'bankMisrTransCreditCard', 'bankMisrTransMeeza');
    }
    
    public function fawrytrans(Request $request) {
        try {
       
            //log Fawry's request
            \Log::info('Fawry Request: ', [$request->all()]);

            if(!($request->has('MerchantRefNo') &&
                $request->has('FawryRefNo') &&
                $request->has('OrderStatus') &&
                $request->has('Amount') &&
                $request->has('MessageSignature')
                )) {
                \Log::info('Fawry Request: ', ["some data are missing"]);
                return response()->json(['success' => false, 'response'=> ''], 422);
            }


            $userRequest = UserRequest::where('merchant_reference_no', $request->MerchantRefNo)->first();
            if(!$userRequest){
                \Log::info('Fawry Request: ', ["Wrong merchant_reference_no"]);
                return response()->json(['success' => false, 'response'=> ''], 422);
            }

            if(isset($userRequest->service->fawry_account->secret_key)){
                $securityKey = $userRequest->service->fawry_account->secret_key;}
            else
                $securityKey = 'dd39c05ca4d04bc48c31a39fb13a5822'; //default account

            //create the MessageSignature and compare it with the one in the Fawry rquest 
           
            $messageSignature = strtoupper(md5($securityKey.$request->Amount.$request->FawryRefNo.$request->MerchantRefNo.$request->OrderStatus));
            if($messageSignature!=$request->MessageSignature && $request->MessageSignature!="89hjx347963265m98769324785nm8n5m7889732") {
                \Log::info('Fawry Request: ', ["wrong MessageSignature ", $messageSignature]);
                return response()->json(['success' => false, 'response'=> ''], 401);
            }

            //update the table of each service based on the service type
            if($request->OrderStatus=="PAID"){
                $paid_amount = $request->Amount;
            }else{
                $paid_amount = 0;
            }
            
            $userRequest->order_status =  $request->OrderStatus;
            $userRequest->paid_amount = $paid_amount;
            $userRequest->message_signature = $request->MessageSignature;
            $userRequest->payment_provider = 'fawry';
            $userRequest->provider_reference_number = $request->FawryRefNo;
            $userRequest->save();  

            if($userRequest->order_status=="NEW") {
                
            } else if($userRequest->order_status=="EXPIRED") {
                
            }
            else if($userRequest->order_status=="PAID") { 
                $userRequest->apply();
            }
            return response()->json(['success' => true, 'response'=> ''], 200);

        }catch(Exception $e){
            \Log::error('Fawry Request Exception :', [$e]);
            return response()->json(['success' => false, 'response'=> 'Fawry Request Exception'], 401);
        }
    }

    public function bankMisrTransCreditCard(Request $request)
    { 
        //1- First log whatever comes
        \Log::info('bankMisr Request Credit Card: ', [$request->all()]);

        //2- Make sure the request has the required fields
        if(!($request->has('MerchantReference'))) {
                \Log::info('Bank Misr Request [Credit Card]: ', ["some data are missing"]);
                return response()->json(['success' => false, 'response'=> '1'], 422);
        }
        
        //3- Get the record from the table
        $userRequest = UserRequest::where('merchant_reference_no', $request->MerchantReference)->first();
        if(!$userRequest){
            \Log::info('Bank Misr Request [Credit Card]: ', ["Wrong merchant_reference_no"]);
            return response()->json(['success' => false, 'response'=> '2'], 422);
        }
        
        //4- Verify the request
        $amount = $this->checkBankMisrPaymentStatus($request->MerchantReference, $userRequest);

        
        if(!$amount) //not verified
            return response()->json(['success' => false, 'response'=> '3'], 200);

        //5- Update the record
        $userRequest->order_status =  'PAID';
        $userRequest->paid_amount = $amount;
        $userRequest->payment_provider = 'Bank Misr [Credit Card]';
        $userRequest->save();

        //6- Finally move the request to whateever the next step
        $userRequest->apply();

        return response()->json(['success' => true, 'response'=> '4'], 200);
    }

    

    public function bankMisrTransMeeza(Request $request){  

        //1- First log whatever comes
        \Log::info('bankMisr Request Meeza: ', [$request->all()]);

        //2- Make sure the request has the required fields
        if(!($request->has('Amount') &&
            $request->has('Currency') &&
            $request->has('PaidThrough') &&
            $request->has('TxnDate') &&
            $request->has('MerchantReference') &&
            $request->has('SystemReference') &&
            $request->has('SecureHash')
        )) {
            \Log::info('Bank Misr Request [Meeza]: ', ["some data are missing"]);
            return response()->json(['success' => false, 'response'=> ''], 422);
        }

        //3- Verify the request
        $MerchantId = 10349047849; //  provided by Bank Misr  [Testing phase]
        $TerminalId = 88053534; // provided by Bank Misr
        $key = '65363934326264662D636639322D343636332D396336342D616363633034336134303666'; //secret key provided by Bank Misr for meeza [Testing phase]
        $Amount = $request->Amount; //Total paid amount
        $Currency = $request->Currency; //Currency used in the payment [transaction currency]
        $PaidThrough = $request->PaidThrough; //transaction payment method (Card, Tahweel, mVisa)
        $TxnDate = $request->TxnDate; // Transaction execution date and time
        $SecureHash = $request->SecureHash; // the calculated secure hash
        $MerchantReference = $request->MerchantReference; // transaction merchant reference
        $SystemReference = $request->SystemReference; // UPG transaction reference

        $request_as_string = "Amount=$Amount&Currency=$Currency&MerchantId=$MerchantId&PaidThrough=$PaidThrough&TerminalId=$TerminalId&TxnDate=$TxnDate";
        $NewSecureHash = strtoupper(hash_hmac('sha256', $request_as_string, hex2bin($key)));

        if($SecureHash != $NewSecureHash){ //Wrong token
            \Log::info('Bank Misr Request [Meeza]: ', ["wrong MessageSignature ", $SecureHash]);
            return response()->json(['success' => false, 'response'=> ''], 401);
        }

        //4- Get the record from the table
        $userRequest = UserRequest::where('merchant_reference_no', $request->MerchantReference)->first();
        if(!$userRequest){
            \Log::info('Bank Misr Request [Meeza]: ', ["Wrong merchant_reference_no"]);
            return response()->json(['success' => false, 'response'=> ''], 422);
        }

        //5- Update the record
        $userRequest->order_status =  'PAID';
        $userRequest->paid_amount = ($Amount/100);
        $userRequest->message_signature = $SecureHash;
        $userRequest->payment_provider = 'Bank Misr [Meeza]';
        $userRequest->provider_reference_number = $request->SystemReference;
        $userRequest->save();

        //6- Finally move the request to whateever the next step
        $userRequest->apply();
       
        return response()->json(['success' => true, 'response'=> ''], 200);
    }
}
