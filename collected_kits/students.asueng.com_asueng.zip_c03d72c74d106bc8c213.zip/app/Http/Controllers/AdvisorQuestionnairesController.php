<?php

namespace App\Http\Controllers;

use App\Course;
use App\Questionnaire;
use App\QuestionnaireComment;
use App\QuestionnaireAnswer;
use App\QuestionnaireQuestion;
use App\User;
use App\Department;
use App\QuestionnaireTask;
use App\Plan;
use App\Study;
use App\Term;
use App\QuestionnaireFaculty;
use App\Student;
use App\Bylaw;  
use App\Quality;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use PDF;
use DB;
use App\Website;
use App\Setting;

class AdvisorQuestionnairesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index() {

        $user = auth()->user();
        $student = $user->student;
        if(empty($student)) {
            return redirect()->route('logout');
        }

        $term = Setting::currentTerm();
        $questionnaireTask = QuestionnaireTask::where('instructor_id', $student->advisor->id)->where('term_id', $term->id)->first();
        if($questionnaireTask == null){
            $totalStudents = Student::where('advisor_id', $student->advisor->id)->where('last_term_id', $term->id)->get()->count();
            $questionnaireTask = new QuestionnaireTask();
            $questionnaireTask->instructor_id = $student->advisor->id;
            $questionnaireTask->term_id= $term->id;
            $questionnaireTask->questionnaire_id= $term->advisor_questionnaire_id;
            $questionnaireTask->count= 0;
            $questionnaireTask->total= $totalStudents;
            $questionnaireTask->save();
        }
        
        $questionnaire = $questionnaireTask->questionnaire;
   
        $group = 'general';

        $path = [
            (object) [
                'link' => route('dashboard'),
                'title' => __('tr.Dashboard'),
            ],
            (object) [
                'link' => route('my_services'),
                'title' => __('tr.My Services'),
            ],
        ];

        return view('advisor_questionnaire.index', compact( 'student', 'questionnaire', 'questionnaireTask', 'group', 'path'));
    }

    public function saveAdvisorQuestionnaire(Request $request) {

        $user = auth()->user();
        $student = $user->student;
        
        if(empty($student)) {
            return redirect()->route('logout');
        }
        
        $term = Setting::currentTerm();
        $questionnaireTask = QuestionnaireTask::where('instructor_id', $student->advisor->id)->where('term_id', $term->id)->first();        
        $answer = QuestionnaireAnswer::where('student_id', $student->id)->where('task_id', $questionnaireTask->id)->first();
        
        if($answer == null) {
            $questionnaireTask->count += 1;
            $questionnaireTask->save();
        }
        
        foreach($request->questions_ids as $questionId) {
            $question = QuestionnaireQuestion::find($questionId);

            if($question->type==0) {
                $answer = QuestionnaireAnswer::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->where('question_id', $question->id)->first();
                if(empty($answer)) {
                    $answer = new QuestionnaireAnswer();
                    $answer->task_id = $questionnaireTask->id;
                    $answer->question_id = $question->id;
                    $answer->student_id = auth()->id();
                }
                $answer->answer = $request->answers[$questionId][0];

                switch($answer->answer) {
                    case 1: $answer->score = 25; break;
                    case 2: $answer->score = 50; break;
                    case 3: $answer->score = -1; break;
                    case 4: $answer->score = 76; break;
                    case 5: $answer->score = 100; break;
                }

                $answer->save();
            } else {
                $answer = QuestionnaireComment::where('task_id', $questionnaireTask->id)->where('student_id', auth()->id())->where('question_id', $question->id)->first();
                if(empty($answer)) {
                    $answer = new QuestionnaireComment();                
                    $answer->task_id = $questionnaireTask->id;
                    $answer->question_id = $question->id;
                    $answer->student_id = auth()->id();
                }
                $answer->comment = $request->answers[$questionId];
                $answer->save();
            }
        }
        
        \DB::statement("UPDATE questionnaires_tasks 
            INNER JOIN (SELECT task_id, count(DISTINCT student_id) as count, AVG(score) as average_score, STDDEV(score) as stddev_score  FROM questionnaires_answers WHERE score>=0 GROUP BY task_id) AS T 
            ON questionnaires_tasks.id = T.task_id 
            SET questionnaires_tasks.status = 0, questionnaires_tasks.count = T.count, questionnaires_tasks.average_score = convert(T.average_score, SIGNED), questionnaires_tasks.stddev_score = convert(T.stddev_score, SIGNED)
            WHERE task_id = ($questionnaireTask->id)");

        return redirect()->route('my_services');
    }
   
}