<?php

namespace App\Http\ApiControllers;

use App;
use App\Student;
use App\Setting;
use Auth;
use DB;
use App\Course;
use App\ModuleCourse;
use App\Exams;
use App\Study;
use App\Term;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\Paginator;

class StudentsController extends Controller
{
    use ResponseTrait;

    public function __construct() {

       $this->middleware('auth:api');
    }
    
    public function myResults() {

        $user = auth()->user();
        //$user = User::find(131206);
        $student = $user->student;

        $gradesTerms = $student->gradesTerms;

        $results = [];

        if($student->isCreditHours()) {

            foreach($gradesTerms as $gradeTerm){

                $term = (object)[];
                $term->bylaw = $gradeTerm->plan->bylaw;
                $term->en_minor = $gradeTerm->plan->en_minor;
                $term->ar_minor = $gradeTerm->plan->ar_minor;
                $term->en_major = $gradeTerm->plan->en_major;
                $term->ar_major = $gradeTerm->plan->ar_major;
                $term->en_program = $gradeTerm->plan->en_program;
                $term->ar_program = $gradeTerm->plan->ar_program;
                $term->en_term = $gradeTerm->term->en_name;
                $term->ar_term = $gradeTerm->term->ar_name;
                $term->years = $gradeTerm->term->years;
                $term->en_level = $gradeTerm->getLevel->en_name;
                $term->ar_level = $gradeTerm->getLevel->ar_name;
                $term->cumulative_gpa = $gradeTerm->final_cumulative_gpa;
                $term->cumulative_credit_hours = $gradeTerm->final_cumulative_credit_hours;
                $term->cumulative_passed_hours = $gradeTerm->final_cumulative_passed_hours;

                foreach($gradeTerm->getGrades() as $grade) {
                    
                    $courseGrade = (object)[];
                    $courseGrade->code = $grade->course->short_name;
                    $courseGrade->en_name = $grade->course->en_name;
                    $courseGrade->ar_name = $grade->course->ar_name;
                    $courseGrade->credit_hours = $grade->course->credit_hours;
                    $courseGrade->grade_letter = $grade->gradeLetter();
                    $courseGrade->grade_gpa = $grade->displayGPA();

                    $grades[] = $courseGrade;
                }

                $term->grades = $grades;
                $results[] = $term;
            }

        } else {

            for($i=0;$i<count($gradesTerms);$i++)
            {
                $gradeTerm = $gradesTerms[$i];
                if(($gradeTerm->year<4 && in_array($gradeTerm->grade_type, [0,1,2,3,4,5]))||$i==(count($gradesTerms)-1))
                {
                    $term = (object)[];
                    $term->bylaw = $gradeTerm->plan->bylaw;
                    $term->en_minor = $gradeTerm->plan->en_minor;
                    $term->ar_minor = $gradeTerm->plan->ar_minor;
                    $term->en_major = $gradeTerm->plan->en_major;
                    $term->ar_major = $gradeTerm->plan->ar_major;
                    $term->en_term = $gradeTerm->term->en_name;
                    $term->ar_term = $gradeTerm->term->ar_name;
                    $term->years = $gradeTerm->term->years;
                    $term->en_year = $gradeTerm->getYear->en_name;
                    $term->ar_year = $gradeTerm->getYear->ar_name;
                    $term->en_grade = $gradeTerm->gradeType->en_name;
                    $term->ar_grade = $gradeTerm->gradeType->ar_name;

                    $grades = [];
                    foreach($student->grades($gradeTerm->year)->get() as $grade)
                    {
                        $courseGrade = (object)[];
                        $courseGrade->code = $grade->course->short_name;
                        $courseGrade->en_name = $grade->course->en_name;
                        $courseGrade->ar_name = $grade->course->ar_name;
                        $courseGrade->elective = $grade->course->elective;
                        $courseGrade->en_grade = $grade->gradeNote->en_name;
                        $courseGrade->ar_grade = $grade->gradeNote->ar_name;

                        $grades[] = $courseGrade;
                    }

                    $term->grades = $grades;
                    $results[] = $term;
                }
            }
        }        
        
        return $this->ApiResponse($results);
    }

}
