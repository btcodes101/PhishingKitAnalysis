<?php

use App\Instructor;
use App\User;
use Carbon\Carbon;

if (! function_exists('lang')) {
    function lang($name = null) {
        $language = app()->getLocale();
        if(empty($language)) $language = "en";
        if(empty($name)) return $language;
        return $language."_".$name;
    }
}

if (! function_exists('left')) {
    function left() {
        return (app()->getLocale()=="ar")?"right":"left";
    }
}

if (! function_exists('right')) {
    function right() {
        return (app()->getLocale()=="ar")?"left":"right";
    }
}

if (! function_exists('isEn')) {
    function isEn() {
        $locale = app()->getLocale();
        if(empty($locale)||$locale=="en")
            return true;
        return false;
    }
}

if (! function_exists('urlLocale')) {
    function urlLocale($language = null) {

        $locale = ($language=="en"||empty($language))?"/":"/".$language."/";
        $uri = request()->getRequestUri();
        $find = "/".app()->getLocale()."/";
        if(strpos($uri, $find)===0) {
            $uri = str_replace($find, $locale, $uri);
        } 
        else if($uri=="/".app()->getLocale()) {
            $uri = "";
        }
        else {
            $locale = ($language=="en"||empty($language))?"":"/".$language;
            $uri = $locale.$uri;
        }

        return url($uri);
    }
}

if (! function_exists('formatUTCS')) {
    function formatUTCS($date) {
        return $date->format('Y-m-dTH:i:s.000Z');
    }
}

if (! function_exists('weekArabicDays')) {
    function weekArabicDays() {
      return   [
            0 => 'الأحد',
            1 => 'الأثنين',
            2 => 'الثلاثاء',
            3 => 'الأربعاء',
            4 => 'الخميس',
            5 => 'الجمعة',
            6 => 'السبت'
        ];
    }
}

if (! function_exists('digits')) {
    function digits($text, $fixArabicNumbersSpaces = true) {
        if(app()->getLocale()=="ar") {
            $arabic = [',','٠','١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩', " \\ "];
            $english = ['.','0','1', '2', '3', '4', '5', '6', '7', '8', '9', '/'];
            $text = str_replace($english, $arabic, $text);
            if($fixArabicNumbersSpaces)$text = str_replace(" ", "&nbsp;", $text);
            return $text;
        }
        return $text;
    }
}

if (! function_exists('arabicDigits')) {
    function arabicDigits($searchText) {
        $arabic = ['٠','١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        $english = ['0','1', '2', '3', '4', '5', '6', '7', '8', '9'];
        return str_replace($english,$arabic,$searchText);
    }
}

if (! function_exists('weekDays')) {
    function weekDays() {
        return [
        	0 => __('tr.Sunday'),
        	1 => __('tr.Monday'),
        	2 => __('tr.Tuesday'),
        	3 => __('tr.Wednesday'),
        	4 => __('tr.Thursday'),
        	5 => __('tr.Friday'),
            6 => __('tr.Saturday'),
        ];
    }
}

if (! function_exists('weekDay')) {
    function weekDay($day) {
        switch ($day) {
            case 0: return __('tr.Sunday');
            case 1: return __('tr.Monday');
            case 2: return __('tr.Tuesday');
            case 3: return __('tr.Wednesday');
            case 4: return __('tr.Thursday');
            case 5: return __('tr.Friday');
            case 6: return __('tr.Saturday');
         }
         return "";
    }
}

if (! function_exists('getFTS')) {
    function getFTS($searchText) {

        if (filter_var($searchText, FILTER_VALIDATE_EMAIL)) {
            return $searchText;
        }
        
        $searchText = preg_replace('/[ ]{2,}|[\t]/', ' ', trim($searchText));
        $searchText = preg_replace('/[^\p{L}0-9\s]+/u', ' ', $searchText);
        $patterns = array( "/(ا|أ|إ|آ)/", "/(ه|ة)/", "/(ـ)/", "/(ى)/");
        $replacements = array( "ا",   "ه" , "", "ي");
        $searchText = preg_replace($patterns, $replacements, $searchText);

        return $searchText;
    }
}

if (! function_exists('formatMultiline')) {
    function formatMultiline($text) {
        $lines = explode("\n", $text);
        $text = "";
        foreach ($lines as $line) {
            $text .= "$line<br/>\n";
        }
        return $text;
    }
}

if (! function_exists('shortText')) {
    function shortText($text, $maxLength) {
        if(mb_strlen($text)<$maxLength)return $text;
        return mb_substr($text, 0, $maxLength-3, "utf-8")."...";
    }
}

if (! function_exists('instructorPosition')) {
    function instructorPosition() {
        return   [
           1 => 'Chairman',
           2 => 'Assistant',
           3 => 'Proctor',
        ];
    }
}


if (! function_exists('instructorNickName')) {
    function instructorNickName() {
        return   [
            "professor" => 'Prof. Dr. ',
            "assistant_professor" => 'Dr. ',
            "teacher" => 'Dr. ',
            "teacher_assistant" => 'Eng. ',
            "demonstrator" => 'Eng. ',
        ];
    }
}

if (! function_exists('degreePrefix')) {

    function degreePrefix($degree, $language) {
        $prefixes = [];
        if($language=="en") {
            $prefixes = [
                "emeritus_professor" => 'Prof. Dr.',
                "professor" => 'Prof. Dr.',
                "assistant_professor" => 'Dr.',
                "teacher" => 'Dr.',
                "teacher_assistant" => 'Eng.',
                "demonstrator" => 'Eng.',
            ];
        }
        else if($language=="ar") {
            $prefixes = [
                "emeritus_professor" => 'ا.د.',
                "professor" => 'ا.د.',
                "assistant_professor" => 'د.',
                "teacher" => 'د.',
                "teacher_assistant" => 'م.',
                "demonstrator" => 'م.',
            ];
        }

        if(!array_key_exists($degree, $prefixes)) {
            return "";
        }

        return  $prefixes[$degree];
    }
}

if (! function_exists('TransformArabicMonth')) {
    function TransformArabicMonth($Date,$lang = null) {
        $englishMonth = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        $arabicMonth = [ "يناير" , "فبراير" ,"مارس","أبريل","مايو", "يونيو" ,"يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];
        if ($lang == null){
            if (lang() == 'en'){
                return $Date;
            }elseif (lang() == 'ar'){
                $Date = str_replace($englishMonth , $arabicMonth , $Date);
                return $Date;
            }
        } else {
            if ($lang == 'en'){
                return $Date;
            }elseif ($lang == 'ar'){
                $Date = str_replace($englishMonth , $arabicMonth , $Date);
                return $Date;
            }
        }
    }
}

    
if (! function_exists('formatDate')) {
    function formatDate($date, $format = 'j-n-Y') {
        if(empty($date))return "";
        if(is_string($date))
            $date = new Carbon($date);
        return digits($date->format($format));
    }
}

if (! function_exists('todayDate')) {
    function todayDate() {
        return digits(Carbon::now()->format('j-n-Y'));
    }
}

if (! function_exists('timeFrom')) {
    function timeFrom($time) {

        $years = Carbon::now()->diffInYears($time);
        if($years>0)
            return $years." years";

        $months = Carbon::now()->diffInMonths($time);
        if($months>0)
            return $months." months";

        $days = Carbon::now()->diffInDays($time);
        if($days>0)
            return $days." days";

        $hours = Carbon::now()->diffInHours($time);
        if($hours>0)
            return $hours." hours";

        $minutes = Carbon::now()->diffInMinutes($time);
        if($minutes>0)
            return $minutes." minutes";

        $seconds = Carbon::now()->diffInSeconds($time);
        return $seconds." seconds";
    }
}

if (! function_exists('toId')) {
    function toId($text) {
        $text = str_replace(' ', '-', $text);
        $text = strtolower($text);
        return $text;
    }
}

if (! function_exists('encryptData')) {
    function encryptData($text, $password) {
        $cipher = openssl_encrypt($text, "AES-256-ECB", hash('sha256', $password, true), OPENSSL_RAW_DATA);
        $output = base64_encode($cipher);
        return urlencode($output);
    }
}

if (! function_exists('decryptData')) {
    function decryptData($input, $password) {
        $cipher = base64_decode($input);
        $text = openssl_decrypt($cipher, "AES-256-ECB", hash('sha256', $password, true), OPENSSL_RAW_DATA);
        return urldecode($text);
    }
}

if (! function_exists('newsDate')) {
    function newsDate($time) {

        $time = Carbon::parse($time);

        $days = Carbon::now()->diffInDays($time);
        if($days>0) {
            return $time->format('Y-n-j');
        }

        $hours = Carbon::now()->diffInHours($time);
        if($hours>0)
            return $hours." hours";

        $minutes = Carbon::now()->diffInMinutes($time);
        if($minutes>0)
            return $minutes." minutes";

        $seconds = Carbon::now()->diffInSeconds($time);
        return $seconds." seconds";
    }
}

if (! function_exists('mobile')) {
    function mobile($text) {
        $text = substr(preg_replace('/[^0-9.]+/', '', $text),0,12);
        if(empty($text))return null;
        return "2".$text;
    }
}

if (! function_exists('studyYears')) {
    function studyYears() {
        return [
            0 => __('tr.Preparatory'),
            1 => __('tr.First Year'),
            2 => __('tr.Second Year'),
            3 => __('tr.Third Year'),
            4 => __('tr.Fourth Year'),
        ];
    }
}

if (! function_exists('dateView')) {
    function dateView($date) {
        if(app()->getLocale()=="ar") {
            $dateArray = explode('-',$date);

            if ($dateArray[0] > 32){
                $date = $dateArray[2].'\\'.$dateArray[1].'\\'.$dateArray[0];
            } else {
                $date = $dateArray[0].'\\'.$dateArray[1].'\\'.$dateArray[2];
            }
            return $date;
        }
        $date = str_replace('-','/',$date);
        return $date;
    }
}

if (! function_exists('field')) {
    function field($obj, $name) {
        if(Session::has('errors'))
            return old($name);
        return $obj[$name];
    }
}

if (! function_exists('dataField')) {
    function dataField($obj, $name) {
        if(Session::has('errors'))
            return old($name);
        if(isset($obj->data->{$name}))
            return $obj->data->{$name};

        return null;
    }
}

if (! function_exists('isEnglish')) {
    function isEnglish($text) {
        return !preg_match('/[^A-Za-z0-9]/', $text);
    }
}

if (! function_exists('gpaRound')) {
    function gpaRound($gpa) {
        return round($gpa, 2);
    }
}

if (! function_exists('sisRound')) {
    function sisRound($gpa) {
        return round($gpa, 2);
        //return round(floor($gpa*100)/100, 2);
    }
}

if (! function_exists('validDate')) {
    function validDate($date) {
        $date = Carbon::parse($date);
        if($date && $date->year<0)return null;
        return $date;
    }
}

if (! function_exists('d')) {
    function d($in) {
        echo "<div style='background-color:darkgray; color:white;padding:5px;margin:2px;'>";print_r($in);echo "</div>";
    }
}

if (! function_exists('em')) {
    function em($in) {
        echo "<div style='background-color:red; color:white;padding:5px;margin:2px;'>";print_r($in);echo "</div>";
    }
}

if (! function_exists('dbg')) {
    function dbg($value, $title = "DEBUG:") {
        \Log::info($title, [$value]);
    }
}

if (! function_exists('dbgTime')) {
    function dbgTime($message = "", $previousTime = null) {
        $time = microtime(true);
        if($previousTime!==null) {
            $period = $time - $previousTime;
            dbg($period, "Duration ($message):");
        }
        return $time;
    }
}

if (! function_exists('numValue')) {
    function numValue($value) {
        if(empty($value)) return 0;
        return $value;
    }
}

if (! function_exists('startsWith')) {
    function startsWith($haystack, $needle) {
        return substr_compare($haystack, $needle, 0, strlen($needle)) === 0;
    }
}

if (! function_exists('endsWith')) {
    function endsWith($haystack, $needle) {
        return substr_compare($haystack, $needle, -strlen($needle)) === 0;
    }
}

if (! function_exists('createdFrom')) {
    
    function createdFrom($created_at) {

        $created = strtotime($created_at);
        $today = strtotime(date('Y-m-d H:i:s'));
        $time_differnce = $today-$created;
        $years = 60*60*24*365;
        $months = 60*60*24*30;
        $days = 60*60*24;
        $hours = 60*60;
        $minutes = 60;
        if(intval($time_differnce/$years) > 1) {
            return intval($time_differnce/$years)." years ago";
        } else if(intval($time_differnce/$years) > 0) {
            return intval($time_differnce/$years)." year ago";
        } else if(intval($time_differnce/$months) > 1) {
            return intval($time_differnce/$months)." months ago";
        } else if(intval(($time_differnce/$months)) > 0) {
            return intval(($time_differnce/$months))." month ago";
        } else if(intval(($time_differnce/$days)) > 1) {
            return intval(($time_differnce/$days))." days ago";
        } else if (intval(($time_differnce/$days)) > 0) {
            return intval(($time_differnce/$days))." day ago";
        } else if (intval(($time_differnce/$hours)) > 1) {
            return intval(($time_differnce/$hours))." hours ago";
        } else if (intval(($time_differnce/$hours)) > 0) {
            return intval(($time_differnce/$hours))." hour ago";
        } else if (intval(($time_differnce/$minutes)) > 1) {
            return intval(($time_differnce/$minutes))." minutes ago";
        } else if (intval(($time_differnce/$minutes)) > 0) {
            return intval(($time_differnce/$minutes))." minute ago";
        } else if (intval(($time_differnce)) > 1) {
            return intval(($time_differnce))." seconds ago";
        } else {
            return "few seconds ago";
        }
    }
}

if (! function_exists('uword')) {
    function uword($d) {
        return $d>>32;
    }
}

if (! function_exists('isJson')) {
    function isJson($string) {
        json_decode($string);
        return (json_last_error() == JSON_ERROR_NONE);
   }
}
