<?php

namespace App;

use App\CourseGroup;

class Website
{
	public $mainSection = null;
	public $section = null;
	public $modules = null;
	public $baseSections = null;
    
    public function __construct($section) {

        $this->section = $section;
        $this->mainSection = $this->section;
		while($this->mainSection->parent_id!=0) {
			if($this->mainSection->content_type=="mainsection")
				break;
			$this->mainSection = $this->mainSection->parent;
		}
		if($this->mainSection->parent_id==0)
			$this->mainSection = Archive::locate('home');
        $this->modules = $this->section->childrenWithContentType('modules')->first();
    }

    public function isHomePage($page) {
        return ($page->short_name == "home");
    }

    public function isSectionPage($page) {
        return ($page->id == $this->mainSection->id);
    }

    public function isHomeSection() {
        return ($this->mainSection->short_name == "home");
    }

	public function resolve($page) {

		//If wrong call show error
		if($page->isFile())
			return "#";

		//if($page->content_type=="folder")
		//	return "#";

		if($page->content_type=="link") {
			if(strpos($page->short_name,"http")===0)
				return $page->short_name;
			
			return route('index', ['sections'=>$page->short_name]);
		}

		//Find mainsection/section in self then parents
		$sections = $page->shortNameId();
		$section = $page->parent;
		while($section->parent_id!=0) {
			if(startsWith($sections, '#')) {
				$sections = str_replace('#', '', $sections);
				break;
			}

			if($section->short_name=="home") {
				break;
			}
			
			$sections = $section->shortNameId()."/".$sections;
			$section = $section->parent;
		}

		$sections = trim($sections, "/");
		if(isset($this->baseSections)) $sections = "$this->baseSections/$sections";

		return route('index', ['sections'=>$sections]);
	}

	public function menu() {

		return  $this->mainSection->children()->where(function($query) {

			$query->orWhere('type', Archive::TYPE_PAGE);
			$query->orWhereNotNull('content_type');
			$query->orWhereNotNull('short_name');
		})->where(function($query) {

			$query->orWhereNull('content_type');
			$query->orWhereNotIn('content_type', ['modules', 'images']);
		})->where('type', '!=', Archive::TYPE_FILE)->get();
    }

    public function headerMenu() {

		return Archive::locate('header_menu')->children;
	}

	public function topics($archive, $limit = -1) {
		if($archive->content_type=="link")return [];
		return $archive
			->children()
			->whereIn('type', [Archive::TYPE_PAGE, Archive::TYPE_FOLDER,Archive::TYPE_FILE])
			->where(function($query) {
				$query->orWhereNotIn('content_type', ['images','files']);
				$query->orWhereNull('content_type');
			})			
			->limit($limit)
			->get();
	}

	public function footerMenu() {

		return Archive::locate('footer_menu')->children;
	}

	public function parents($page) {

		$result = [];
		$parent = $page->parent;
		while($parent->parent_id!=0) {
			array_unshift($result, $parent);
			if($parent->content_type=="mainsection") break;
			$parent = $parent->parent;
		}

		return $result;
	}

	private $infoCash = null;

	public function info() {
		if(empty($infoCash)) {
			$infoCash = json_decode(Archive::get('cms/information')->description);
        }
		return $infoCash;
	}

	public function page($path) {
		$archive = Archive::get($path);
		return $archive->page();
	}

	public function file($path) {
		$archive = Archive::get($path);
		if(empty($archive))return "#";
		return route('download_file', ['id'=>$archive->id]);
	}

	public function moduleSections($type, $limit = 1000) {
		if(empty($this->modules))return null;
		$result = (object)[];
		$result->module = $this->modules->childrenWithContentType($type)->first();
		if(empty($result->module))return null;
		$result->logo = $result->module->childrenWithContentType('logo')->first();
		$result->message = $result->module->childrenWithContentType('message')->first();
		$result->sections = $result->module->childrenWithContentType('link')->limit($limit)->get();
		return $result;
	}

	public function banner() {

		if(empty($this->modules))return null;
		return $this->modules->childrenWithContentType('banner')->first();
	}

	public function news($page = null) {

		$section = $this->section;
		if($page && $page->short_name=="news") return $page;
		else if($page) $section = $this->section($page);
		return $section->findChildByShortName('news');
	}

	public function partners() {

		if(empty($this->modules))return null;
		return $this->modules->childrenWithContentType('partners')->first();
	}

	public function events() {

		if(empty($this->modules))return null;
		return $this->modules->childrenWithContentType('events')->first();
	}

	public function vision() {

		if(empty($this->modules))return null;
		return $this->modules->childrenWithContentType('vision')->first();
	}

	public function announcement() {

		if(empty($this->modules))return null;
		return $this->modules->childrenWithContentType('announcement')->first();
	}

	public static function asset($shortName) {

		return Archive::locate('website')->locate('assets')->findChildByShortName($shortName);
	}

	public static function value($name) {

		return Setting::value($name);
	}

	public static function folder($archive) {

		if($archive->isFolder()) return $archive;
		return $archive->parent;
	}

	public static function section($archive) {

		$orgArchive = $archive;

		while($archive->id!=0) {
			
			if($archive->content_type=="gallery" || $archive->content_type=="section" || $archive->content_type=="mainsection") {
				if($archive->short_name!='home'){
					return $archive;
				}
			}
			
			$archive = $archive->parent;
		}

		if($orgArchive->isFolder())
			return $orgArchive;

		return $orgArchive->parent;
	}

	public function title($archive) {
		
		$parents = $this->parents($archive);
		$parents = array_reverse($parents);

		$title = "";
		if($archive->short_name!="index")
			$title = $archive->locale->title;

		if($archive->content_type=="mainsection") return $title;

		$sectionTitle = null;
		$mainSectionTitle = null;
		foreach ($parents as $parent) {
			if($parent->content_type=="section")
				$title = $parent->locale->title."$".$title;
			if($parent->content_type=="mainsection") {
				$title = $parent->locale->sub_title."$".$title;
				break;
			}
		}

		$title = trim($title);
		$title = str_replace("$", ", ", $title);
		return $title;
	}

	public function isComponent($page, $fields = ['short_name', 'content_type']) {
		
		if(!is_array($fields)) $fields = [$fields];
		foreach ($fields as $field) {
			if(!empty($page->{$field}) && view()->exists("website.components.".$page->{$field})){
	            return true;
	        }
		}
		
        return false;
	}

	public function departmentCourses($bylaw, $code) {
		return Course::where('bylaw', $bylaw)
		->where('short_name', 'like', "$code%")
		->where('active', 1)
		->where('current', 1)
		->whereNull('plan_id')
		->orderBy('group_name')
		->orderBy('short_name')
		->get();
	}

    public function programCoursesGroups($bylaw, $code) {

    	$coursesGroups = CourseGroup::where('bylaw', $bylaw)
    	->where('program', $code)
    	->whereNotNull('group')
    	->orderBy('id')
    	->get();

        return $coursesGroups;
    }

    public function programStudyPlan($bylaw, $code) {

    	$coursesGroups = CourseGroup::where('bylaw', $bylaw)
    	->where('program', $code)
    	->whereNotNull('course_semester')
    	->orderBy('course_semester')
    	->orderBy('id')
    	->get();

        return $coursesGroups;
    }

    public function programCoursesPlan($bylaw, $code) {

    	return Plan::where('bylaw', $bylaw)
    	->where('short_name', $code)    	
    	->first();
    }

}
