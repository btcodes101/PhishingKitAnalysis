<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExternalStudentsRequest extends Model
{
    protected $table = 'external_students_requests';
    protected $fillable = ['student_id', 'year', 'status','agreed_to_change_to_2018'];

    const STATUS_IN_PROGRESS = __('tr.In Progress');

    const STATUS_VALIDATED_BY_STUDENTS_AFFAIRS = 2;
    const STATUS_REJECTED_BY_STUDENTS_AFFAIRS = 3; 

    const STATUS_ACCEPTED_BY_STUDENTS_AFFAIRS_COMMITTEE = 4;
    const STATUS_REJECTED_BY_STUDENTS_AFFAIRS_COMMITTEE = 5;

    const STATUS_ACCEPTED_BY_FACULTY_COUNCIL = 6;
    const STATUS_REJECTED_BY_FACULTY_COUNCIL = 7;

    public static function statusLabels() {
        return [
            ExternalStudentsRequest::STATUS_IN_PROGRESS => __('tr.In Progress'),
            ExternalStudentsRequest::STATUS_VALIDATED_BY_STUDENTS_AFFAIRS => __('tr.Validated by the Students Affairs'),
            ExternalStudentsRequest::STATUS_REJECTED_BY_STUDENTS_AFFAIRS => __('tr.Rejected by the Students Affairs'),
            ExternalStudentsRequest::STATUS_ACCEPTED_BY_STUDENTS_AFFAIRS_COMMITTEE => __('tr.Accepted by Students Affairs Committee'),
            ExternalStudentsRequest::STATUS_REJECTED_BY_STUDENTS_AFFAIRS_COMMITTEE => __('tr.Rejected by Students Affairs Committee'),
            ExternalStudentsRequest::STATUS_ACCEPTED_BY_FACULTY_COUNCIL => __('tr.Accepted by Faculty Council'),
            ExternalStudentsRequest::STATUS_REJECTED_BY_FACULTY_COUNCIL => __('tr.Rejected by Faculty Council')
        ];
    }

    public static function statusBadges() {
        return [
            ExternalStudentsRequest::STATUS_IN_PROGRESS => 'light',

            ExternalStudentsRequest::STATUS_VALIDATED_BY_STUDENTS_AFFAIRS => 'secondary',
            ExternalStudentsRequest::STATUS_REJECTED_BY_STUDENTS_AFFAIRS => 'danger',
            
            ExternalStudentsRequest::STATUS_ACCEPTED_BY_STUDENTS_AFFAIRS_COMMITTEE => 'primary',
            ExternalStudentsRequest::STATUS_REJECTED_BY_STUDENTS_AFFAIRS_COMMITTEE => 'danger',
            
            ExternalStudentsRequest::STATUS_ACCEPTED_BY_FACULTY_COUNCIL => 'success',
            ExternalStudentsRequest::STATUS_REJECTED_BY_FACULTY_COUNCIL => 'danger' 
        ];
    }

    protected static function boot(){
        parent::boot();
        static::creating(function ($query) {
            $query->student_id = auth()->id();
            $query->status = ExternalStudentsRequest::STATUS_IN_PROGRESS;
           
        });
    }
    
}
