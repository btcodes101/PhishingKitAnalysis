<?php

namespace App;

use App\Student;
use App\StudentCertificate;
use App\CertificateType;
use App\ChangeTrackPreference;
use App\StudentControlAppeal;
use App\Excuse;
use App\Study;
use App\TakafulRequest;
use App\Applicant;
use App\StudentCredit;
use Carbon\Carbon;


use Illuminate\Database\Eloquent\Model;

class UserRequest extends Model
{
	protected $table = 'users_requests';
    protected $fillable = ['user_id', 'type', 'target_id', 'data', 'total_amount', 'merchant_reference_no', 'payment_provider', 'paid_amount', 'provider_reference_number', 'order_status', 'session_id', 'meeza_msg_signature', 'message_signature'];
	
	const STATUS_INCOMPLETE = 'INCOMPLETE';
    const STATUS_NEW = 'NEW';
    const STATUS_PAID = 'PAID';
    const STATUS_INTERNALLYPAID = 'INTERNALLYPAID';
    const STATUS_MANUALPAID = 'MANUALPAID';
    const STATUS_EXPIRED = "EXPIRED";
    const STATUS_REJECTED = 'REJECTED';
    const STATUS_PARTIALLY_PAID = 'PARTIALLYPAID';
    const STATUS_MANUALLY_EXPIRED = 'MANUALLYEXPIRED';

    public static function statusTypes(){
        return [
            UserRequest::STATUS_INCOMPLETE => __("tr.Incomplete"),
            UserRequest::STATUS_NEW => __("tr.New"),
            UserRequest::STATUS_PAID => __("tr.Paid"),
            UserRequest::STATUS_MANUALPAID => __("tr.Manual Paid"),
            UserRequest::STATUS_EXPIRED => __("tr.Expired"),
            UserRequest::STATUS_REJECTED => __("tr.Rejected"),
            UserRequest::STATUS_INTERNALLYPAID => __("tr.Internally Paid"),
            UserRequest::STATUS_PARTIALLY_PAID => __("tr.Partially Paid"),
            UserRequest::STATUS_MANUALLY_EXPIRED => __("tr.Manually Expired"),
        ];
    }

    public function archive() {
        if(empty($this->archive_id)) {
        	$archive = Archive::get("users_requests/$this->id");
            $this->archive_id = $archive->id;
            $this->save();
        }
        return $this->belongsTo('App\Archive', 'archive_id', 'id');
    }

    public function externalLink() {
    	$secret = encryptData($this->id, env("WEBSITE_SHARED_KEY", null));
        $link = route('view_external_certificate_request')."?secret=$secret";
        return $link;
    }

    public function apply() {
		
    	if($this->type == "students_certificates") {
    		
    		$data = json_decode($this->data);

    		for($i=0;$i<count($data->type);$i++) {

	            $quantity = $data->quantity[$i];
	            if($quantity==0) continue;
	            $certificateTypeId = $data->type[$i];

	            $parameters = clone (object)$data;
	            unset($parameters->type);
	            unset($parameters->quantity);
	            unset($parameters->fees);
				$parameters = json_encode($parameters, JSON_UNESCAPED_UNICODE);
				
				$certificateType = CertificateType::find($certificateTypeId);
				if(!$certificateType)
					continue;

	            $studentCertificate = StudentCertificate::where('request_id', $this->id)->where('certificate_type_id', $certificateTypeId)->first();

	            if($studentCertificate) {
	            	continue;
	            }
	            
            	$studentCertificate = new studentCertificate();
	            $studentCertificate->student_id = $this->user_id;
	            $studentCertificate->certificate_type_id = $certificateTypeId;
	            $studentCertificate->print_count = $quantity;
	            $studentCertificate->fees = $certificateType->cost;
	            $studentCertificate->status = StudentCertificate::STATUS_NEW;
	            $studentCertificate->parameters = $parameters;
	            $studentCertificate->external_id = null;
	            $studentCertificate->request_id = $this->id;
	            $studentCertificate->requested_by = 0;
	            $studentCertificate->save();
	        }
    	}else if($this->type == "change_track") {

    		$student = Student::find($this->user_id);
			
			$data = (object)json_decode($this->data);

    		$toPlanId = $data->to_plan_id;
    		$term_id = $data->term_id;

    		ChangeTrackPreference::where('request_id', $this->id)->delete();

	        $changeTrackPreference = new ChangeTrackPreference();
	        $changeTrackPreference->user_id = $this->user_id;
	        $changeTrackPreference->request_id = $this->id;
	        $changeTrackPreference->from_plan_id = $student->last_plan_id;
	        $changeTrackPreference->to_plan_id = $toPlanId;
	        $changeTrackPreference->term_id = $term_id;
			$changeTrackPreference->save();
			
		} else if($this->type == "Tuition_Fees_Payment") {

    	} else if($this->type == "Charge_my_credit") {

			//Add the transaction to students_credit table
			
			$studentCredit = new StudentCredit();
			$studentCredit->request_id = $this->id;
			$studentCredit->student_id = $this->user_id;
			$studentCredit->type = StudentCredit::TYPE_DEPOSIT;
			$studentCredit->amount = $this->paid_amount;
			$studentCredit->notes = 'Charged by Student';
			$studentCredit->save();

		} else if($this->type == "Student_Control_Appeals") {

			$data = json_decode($this->data);

			if(is_array($data->courses)) {
				foreach($data->courses as $key => $course) {
					StudentControlAppeal::create(
						[
							'merchantRefNo' => $this->merchant_reference_no,
							'student_id' => $this->user_id,
							'term_id' => $data->term_id,
							'request_id' => $this->id, 
							'course_id' => $course,
							'student_comment' => $data->stdComments[$key],
							'control_decision' => 1,
							
						]
					);
				} //end of foreach
			} //end of is_array
			
		} else if($this->type == "Student_Excuse") {

			$excuse = Excuse::find($this->target_id);
			$excuse->payment_status = 'PAID';
            $excuse->save();
			
		} else if($this->type == "Arch_aptitude_test") {

			$data = json_decode($this->data);

			if(isset($data->term_id) && 
				isset($data->course_id) && 
				isset($data->plan_id) && 
				isset($data->committee_id) 
				) {
				$study = new Study();
				$study->course_id = $data->course_id;
				$study->user_id = $this->user_id;
				$study->role = Study::ROLE_STUDENT;
				$study->term_id = $data->term_id;
				$study->plan_id = $data->plan_id;
				$study->committee_id = $data->committee_id;
				$study->status = Study::STATUS_REGISTERED|Study::STATUS_MANDATORY|Study::STATUS_CREDIT|Study::STATUS_FRESH;
				$study->save();
			}

		} else if($this->type == 'financial_aid_request') {
			
			$data = (array)json_decode($this->data);
			TakafulRequest::create($data);

		} else if($this->type == 'postgrad_admission_fees' || $this->type == 'international_admission_fees') {

			$applicant = Applicant::find($this->target_id);

			if($this->total_amount <= $this->paid_amount) {
				$applicant->payment_status = UserRequest::STATUS_PAID;
			} else {
				$applicant->payment_status = UserRequest::STATUS_PARTIALLY_PAID;
			}
			
			$applicant->save();
		}
	}
	
	public function internalStudentCertifcateStatus($userId,$requestId){
        $lang = lang();
        return StudentCertificate::select('students_certificates.student_id','students_certificates.notes as notes','students_certificates.parameters','students_certificates.status','certificates_types.'.$lang.'_name as name')->join('certificates_types','certificates_types.id','=','students_certificates.certificate_type_id')->where('students_certificates.student_id',$userId)->where('students_certificates.request_id',$requestId)->get();
	}
	
	public function service(){
		return $this->belongsTo(Service::class, 'type', 'type');
	}
}
