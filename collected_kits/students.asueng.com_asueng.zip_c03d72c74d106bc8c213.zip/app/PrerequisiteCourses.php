<?php

namespace App;

use BaseModel\Model;

class PrerequisiteCourses extends BaseModel
{
    protected $table = 'prerequisites_courses';
    protected $guarded = [];
    public $timestamps = false;
}
