<?php

namespace App;

use BaseModel\Model;

class StudentResearchMember extends BaseModel {

    protected $table = 'students_research_members';

    protected $guarded = [];

    public $timestamps = false;

    public function user() {
        return $this->belongsTo('App\User','member_id', 'id');
    }
}
