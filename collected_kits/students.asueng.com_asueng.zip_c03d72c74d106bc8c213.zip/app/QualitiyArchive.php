<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QualitiyArchive extends Model
{
    protected $table = 'qualities_archive';
}
