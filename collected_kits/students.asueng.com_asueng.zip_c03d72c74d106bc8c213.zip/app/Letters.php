<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Letters extends Model
{
    protected $guarded = [];

    const REPLACEMENTS = [
        '{{USER_ARABIC_NAME}}' => 'user_ar_name',
        "{{USER_ENGLISH_NAME}}" => 'user_en_name',
        '{{NATIONAL_ID}}' => 'national_id',
        '{{BIRTH_DATE}}' => 'birth_data',
        '{{USER_CODE}}' => 'user_code',
        '{{USER_ADDRESS}}' => 'user_address',
        '{{USER_EMAIL}}' => 'user_email',
        '{{USER}}' => 'user',
        '{{NOW}}' => 'now',
        '{{USER_DEGREE}}' => 'user_degree',
        '{{DEPARTMENT_AR_NAME}}' => 'department_ar_name',
        '{{DEPARTMENT_EN_NAME}}' => 'department_en_name',
        '{{USER_AGE}}' => 'user_age',
        '{{DEMONSTRATOR_AT}}' => 'demonstrator_at',
        '{{TEACHER_ASSISTANT_AT}}' => 'teacher_assistant_at',
        '{{TEACHER_AT}}' => 'teacher_at',
        '{{ASSISTANT_PROFESSOR_AT}}' => 'assistant_professor_at',
        '{{PROFESSOR_AT}}' => 'professor_at',
        '{{EMERITUS_PROFESSOR_AT}}' => 'emeritus_professor_at',
        '{{ACADEMIC_YEAR}}' => 'academic_year',
    ];
}
