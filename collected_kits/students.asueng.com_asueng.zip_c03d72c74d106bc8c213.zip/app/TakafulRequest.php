<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TakafulRequest extends Model
{
    protected $table = 'takaful_requests';
    protected $fillable = ['student_id', 'term_id', 'status', 'guardian_name', 'guardian_occupation', 'guardian_net_income', 'guardian_mobile_number', 'mother_occupation', 'mother_net_income', 'number_of_family_members_living_with_you'];
     
   
    
    const STATUS_IN_PROGRESS = 1;
    const STATUS_ACCEPTED = 2;
    const STATUS_REJECTED = 3;
    const STATUS_REVIEWED = 4;


    const TYPE_TAKAFUL = 1;
    const TYPE_CHARITY = 2;


    public static function statusLabels() {
        return [
            TakafulRequest::STATUS_IN_PROGRESS => __('tr.In Progress'),
            TakafulRequest::STATUS_ACCEPTED => __('tr.Accepted'),
            TakafulRequest::STATUS_REJECTED => __('tr.Rejected'),
            TakafulRequest::STATUS_REVIEWED => __('tr.Reviewed')
        ];
    }


    public static function statusBadges() {
        return [
            
            TakafulRequest::STATUS_IN_PROGRESS => 'primary',
            TakafulRequest::STATUS_ACCEPTED => 'success',
            TakafulRequest::STATUS_REJECTED => 'danger',
            TakafulRequest::STATUS_REVIEWED => 'primary'
        ];
    }

    public static function takafulTypeLabels() {
        return [
            
            TakafulRequest::TYPE_TAKAFUL => __('tr.Takaful'),
            TakafulRequest::TYPE_CHARITY => __('tr.Charity')
        ];
    }

    protected static function boot(){
        parent::boot();

        static::creating(function ($query) {
            $query->status = TakafulRequest::STATUS_IN_PROGRESS;
            
        });
        
        static::updating(function ($query) {
            $query->status = TakafulRequest::STATUS_IN_PROGRESS;
        });
    }
}
