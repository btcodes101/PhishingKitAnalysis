<?php

namespace App;

use App\BaseModel;
use App\Setting;
use App\Exams;

use Carbon\Carbon;

class Term extends BaseModel
{
    protected $fillable = [
        'en_name',
        'ar_name',
        'years',
        'start_date',
        'end_date'
    ];

    const FALL = 'Fall';
    const SPRING = 'Spring';
    const SUMMER = 'Summer';
    const ADMISSION = 'Admission';
    const OTHER = 'Other';
    const TRANSFER = 'Transfer';
 
    public function questionnaire(){
        return $this->belongsTo('App\Questionnaire');
    }

    public function startDate()
    {
        return Carbon::parse($this->start_date);
    }

    public function endDate()
    {
        return Carbon::parse($this->due_date);
    }

    public function isCourseFilesScheduled() {
        return !empty($this->course_files_start_date);
    }

    public function courseFilesStartDate() {
        if(empty($this->course_files_start_date))return false;
        return Carbon::parse($this->course_files_start_date);
    }

    public function courseFilesDueDate() {
        return Carbon::parse($this->course_files_due_date);
    }

    public function courseFilesDueTime() {
        return Carbon::parse($this->course_files_due_date)->addDays(1);
    }

    public function isCourseFilesOpenSoon() {
        if(empty($this->course_files_start_date))return false;
        return $this->courseFilesStartDate()->gt(Carbon::now());
    }

    public function isCourseFilesOpened() {
        if(empty($this->course_files_start_date))return false;
        return $this->courseFilesStartDate()->lte(Carbon::now());
    }

    public function isCourseFilesOpen() {
        return $this->isCourseFilesOpened() && !$this->isCourseFilesClosed();
    }

    public function isCourseFilesClosed() {
        if(empty($this->course_files_due_date))return false;
        return $this->courseFilesDueDate()->lt(Carbon::now()->subDays(1));
    }

    public function questionersStartDate()
    {
        return Carbon::parse($this->questioner_start_date);
    }

    public function questionerDueDate()
    {
        return Carbon::parse($this->questioner_due_date);
    }

    public static function questionnaireStatusList() {
        return [
                0 => __("tr.Not Published"),
                1 => __("tr.Published without Comments"),
                2 => __("tr.Published"),
            ];
    }

    public static function courseFilesSuperEditModes() {
        return [
                0 =>  __("tr.Quality Management"),
                1 => __("tr.Quality Team"),
            ];
    }

    public function questionnaireStatusLabel() {
        return Term::questionnaireStatusList()[$this->questionnaire_publish_status];
    }

    public function oldName() {

        $name = $this->lang('name');
        $name = mb_ereg_replace('Spring', 'June', $name);
        $name = mb_ereg_replace('Fall', 'January', $name);
        $name = mb_ereg_replace('خريف', 'يناير', $name);
        $name = mb_ereg_replace('ربيع', 'يونيو', $name);
        $name = mb_ereg_replace('تخلفات', '', $name);
        $name = mb_ereg_replace('\(', '', $name);
        $name = mb_ereg_replace('\)', '', $name);
        $name = mb_ereg_replace('-', ' ', $name);
        $name = mb_ereg_replace('  ', '', $name);

        return $name;
   }

   public function newName() {

        $name = $this->lang('name');
        $name = mb_ereg_replace('June', 'Spring', $name);
        $name = mb_ereg_replace('January', 'Fall', $name);
        $name = mb_ereg_replace('يناير', 'خريف', $name);
        $name = mb_ereg_replace('يونيو', 'ربيع', $name);
        $name = mb_ereg_replace('تخلفات', '', $name);
        $name = mb_ereg_replace('\(', '', $name);
        $name = mb_ereg_replace('\)', '', $name);
        $name = mb_ereg_replace('-', ' ', $name);
        $name = mb_ereg_replace('  ', '', $name);

        return $name;
    }

    public function termPlans(){
        return $this->belongsToMany('App\Plan','terms_plans');
    }

    public function termCourses(){
        return $this->belongsToMany('App\Course','terms_plans_courses');
    }

    public static $cashedTerms = [];
    public static function getCashed($code) {
        
        if(array_key_exists($code, Term::$cashedTerms))
            return Term::$cashedTerms[$code];

        $term = Term::where('code', $code)->first();

        Term::$cashedTerms[$code] = $term;

        return $term;
    }

    public static function nextTermsList() {
        return Term::where('id', Setting::value('next_term_id'))->where('active', 1)->whereRaw(\DB::raw('end_date>NOW()'))->pluck(lang().'_name', 'id')->toArray();
    }

    public static function currentAndNextTermsList() {  
        return Term::where('active', 1)->where('start_date', '>=', Term::currentTerm()->start_date)->pluck(lang().'_name', 'id')->toArray();
    }

    public function nextYears() {
        $years = str_replace("\\", "/", $this->years);
        $years = explode("/", $years);
        $nextYears = [];
        foreach ($years as $year) {
            $nextYears[] = $year + 1;
        }
        return "".$nextYears[0]."/".$nextYears[1];
    }

    public function previousYears() {
        $years = str_replace("\\", "/", $this->years);
        $years = explode("/", $years);
        $nextYears = [];
        foreach ($years as $year) {
            $nextYears[] = $year - 1;
        }
        return "".$nextYears[0]."/".$nextYears[1];
    }

    public static function currentTerm() {
        
        $currentTermId = Setting::value('current_term_id');
        return Term::find($currentTermId);
    }

    public static function findOpenStudentsPreferences() { 

        $currentTermId = Setting::value('next_term_id');
        return Term::where("id", $currentTermId)->whereRaw(\DB::raw('(ms_preferences_start_date <= NOW() AND ms_preferences_due_date>=NOW())'))->orderBy('start_date', 'DESC')->first();
    }
    
    public static function findOpenStudentsPreferencesCh() { 

        $nextTermID = Setting::value('next_term_id');
        return Term::where("id", $nextTermID)->whereRaw(\DB::raw('(ch_preferences_start_date <= NOW() AND ch_preferences_due_date>=NOW())'))->orderBy('start_date', 'DESC')->first();
    }

    //check the date to dispaly the selection result for main stream
    public static function findOpenStudentsPreferencesResult() { 

        $currentTermId = Setting::value('current_term_id');
        return Term::where("id", $currentTermId)->whereRaw(\DB::raw('(display_ms_preferences_date<=NOW())'))->orderBy('start_date', 'DESC')->first();
    }
    
    //check the date to dispaly the selection result for credit hours
    public static function findOpenStudentsPreferencesChResult() { 

        $currentTermId = Setting::value('current_term_id');
        return Term::where("id", $currentTermId)->whereRaw(\DB::raw('(display_ch_preferences_date<=NOW())'))->orderBy('start_date', 'DESC')->first();
    }
    
    public static function findOpenStudentsChangeTrack() {

        $currentTermId = Setting::value('current_term_id');
        return Term::where("id", $currentTermId)->whereRaw(\DB::raw('(change_track_start_date <= NOW() AND change_track_due_date>=NOW())'))->orderBy('start_date', 'DESC')->first();
    }

    public static function findOpenStudentsCoursesRegistration() {

        $currentTermId = Setting::value('current_term_id');
        return Term::where("id", $currentTermId)->whereRaw(\DB::raw('(courses_registeration_start_date <= NOW() AND courses_registeration_due_date>=NOW())'))->orderBy('start_date', 'DESC')->first();
    }

    public function questionnaireStartDate()
    {
        return Carbon::parse($this->questionnaire_start_date);
    }

    public function advisorQuestionnaireStartDate()
    {
        return Carbon::parse($this->advisor_questionnaire_start_date);
    }

    public function questionnaireDueDate()
    {
        return Carbon::parse($this->questionnaire_due_date);
    }

    public function advisorQuestionnaireDueDate()
    {
        return Carbon::parse($this->advisor_questionnaire_due_date);
    }

    public function questionnaireDueTime()
    {
        return Carbon::parse($this->questionnaire_due_date)->addDays(1);
    }

    public function isQuestionnaireOpen()
    {
        return Carbon::now()->gte($this->questionnaireStartDate()) && Carbon::now()->lte($this->questionnaireDueTime());
    }

    public function isAdvisorQuestionnaireOpen()
    {
        return Carbon::now()->gte($this->advisorQuestionnaireStartDate()) && Carbon::now()->lte($this->advisorQuestionnaireDueDate());
    }

    public function type() {
        if(empty($this->short_name))return null;
        return substr(strtoupper($this->short_name), 0, 1);
    }

    public static $cashedTermsByID = [];
    public static function getCashedByID($id) {
        
        $key = $id;
        if(array_key_exists($key, Term::$cashedTermsByID))
            return Term::$cashedTermsByID[$key];

        $term = Term::find($id);

        Term::$cashedTermsByID[$key] = $term;

        return $term;
    }
    
    public static $cashedTermsByCode = [];
    public static function getCashedByCode($code) {
        
        if(array_key_exists($code, Term::$cashedTermsByCode))
            return Term::$cashedTermsByCode[$code];

        $term = Term::where('code', $code)->first();

        Term::$cashedTermsByCode[$code] = $term;

        return $term;
    }

    public function shortYear() {
        return (int)substr("".$this->term_year, 2, 2);
    }

    public function isFall() {
        return ($this->type()=="F");
    }

    public function isSpring() {
        return ($this->type()=="S");
    }

    public function isNovember() {
        return ($this->type()=="N");
    }

    public function isAdmission() {
        return ($this->type()=="A");
    }

    public function isSummer() {
        return ($this->type()=="M");
    }

    public function isTransfer() {
        return ($this->type()=="T");
    }

    public function isOther() {
        return !in_array($this->type(), ['F', 'S', 'M', 'T', 'A', 'N']);
    }


    /**
     * A function to get all terms where the dates are still open
     */
    public static function getOpenedGradesRecheckTerms($bylaw) {

        return Term::select('terms.*')
                    ->join('terms_stages', 'terms_stages.term_id', 'terms.id')
                    ->whereRaw(\DB::raw('(terms_stages.start_date <= NOW() AND DATE_ADD(terms_stages.end_date, INTERVAL 1 DAY)>=NOW())'))
                    ->where('terms_stages.stage_code', 'grades_recheck')
                    ->where('terms_stages.bylaw_code', $bylaw)
                    ->orderBy('start_date', 'ASC')
                    ->get();
    }


    public function stage($stageCode, $bylawCode) {

        return TermStage::select('*')
        ->where('stage_code', $stageCode)
        ->where('bylaw_code', $bylawCode)
        ->where('term_id', $this->id)
        ->first();
    }

    public static function currentExamTerm() {
        
        $termId = Exams::current()->term_id;
        return Term::find($termId);
    }
}