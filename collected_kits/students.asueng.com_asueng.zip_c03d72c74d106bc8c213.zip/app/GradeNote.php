<?php

namespace App;

use App\BaseModel;

class GradeNote extends BaseModel
{
	protected $table = 'grades_notes';
}
