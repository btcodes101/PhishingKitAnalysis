<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentSpecialRequestCourse extends Model
{
    protected $table = 'student_special_requests_courses';
    protected $fillable = ['special_request_id', 'course_id', 'created_at', 'updated_at'];

}
