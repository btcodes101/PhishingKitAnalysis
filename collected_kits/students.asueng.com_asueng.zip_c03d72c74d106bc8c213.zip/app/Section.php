<?php

namespace App;

use App\BaseModel;

class Section extends BaseModel
{
    protected  $table = 'sections';
    public $timestamps = false;

    public function plan() {
        return $this->belongsTo('App\Plan', 'plan_id', 'id');
    }
}
