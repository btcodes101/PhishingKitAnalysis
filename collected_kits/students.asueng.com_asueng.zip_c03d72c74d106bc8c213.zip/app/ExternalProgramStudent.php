<?php

namespace App;

use BaseModel\Model;

class ExternalProgramStudent extends BaseModel {

    protected $table = 'external_programs_students';
    
    const STATUS_PENDING            = 0;   
    const STATUS_PENDING_ACCEPTED   = 1;    
    const STATUS_ACCEPTED           = 2;
    const STATUS_REJECTED           = 3;
    const STATUS_FREEZED            = 4;
    const STATUS_DOCS_REQUIRED      = 5;

    public function externalProgram(){
        return $this->belongsTo('App\ExternalProgram');
    }

    public function coordinator() {
        return $this->belongsTo('App\User', 'coordinator_id', 'id');
    }

    public function head() {
        return $this->belongsTo('App\User', 'head_id', 'id');
    }

    public static function statusList() {
        return [
            ExternalProgramStudent::STATUS_PENDING => 'Pending',
            ExternalProgramStudent::STATUS_PENDING_ACCEPTED => 'Pending Accepted',
            ExternalProgramStudent::STATUS_ACCEPTED => 'Accepted',
            ExternalProgramStudent::STATUS_REJECTED => 'Rejected',
            ExternalProgramStudent::STATUS_FREEZED => 'Freezed',
            ExternalProgramStudent::STATUS_DOCS_REQUIRED => 'Docs Required',
        ];
    }

    public function statusName() {
        return $this->statusList()[$this->status];
    }

    public function canChange() {
        return ($this->status == ExternalProgramStudent::STATUS_PENDING);
    }

    public function canCoordinatorApprove() {
        return ($this->status == ExternalProgramStudent::STATUS_PENDING && $this->coordinator_approve_at==null && auth()->id()==$this->externalProgram->head_id);
    }

    public function canHeadApprove() {
        return ($this->status == ExternalProgramStudent::STATUS_PENDING_ACCEPTED && $this->coordinator_approve_at && $this->head_approve_at==null && auth()->user()->hasPermissionTo('admin_external_programs'));   
    }
    public function canUploadDocs() {
        return ($this->status == ExternalProgramStudent::STATUS_DOCS_REQUIRED);   
    }
    public function canUpdateDocs() {
        return ($this->status == ExternalProgramStudent::STATUS_PENDING_ACCEPTED);   
    }
    public function canShowUploadedDocs() {
        return ($this->status == ExternalProgramStudent::STATUS_PENDING_ACCEPTED||
        $this->status == ExternalProgramStudent::STATUS_ACCEPTED);   
    }

}
