<?php

namespace App;

use App\Plan;
use App\BaseModel;

class Bylaw extends BaseModel
{
	public function plans() {

    	return $this->hasMany('App\Plan', 'bylaw', 'code')->orderBy('code');
    }

    public function studiesPlans($termId) {

    	return Plan::where('bylaw', $this->code)->whereRaw(\DB::raw("id IN (SELECT DISTINCT plan_id FROM studies WHERE term_id = $termId)"))->orderBy('code')->get();
    }

    public function isCreditHours() {
    	return ($this->credit_hours==1);
    }

    public static function undergradbylawsList() {
    	return Bylaw::where('type', 'undergraduate')->pluck(lang().'_name', 'code')->toArray();
    }

    public function useLastGrade() {
        if($this->code == 'UG2018') return false;
        return true;
    }
}
