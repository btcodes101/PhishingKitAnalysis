<?php

namespace App;

use App\ProctoringStaffQuota;
use App\BaseModel;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class StudentFee extends BaseModel
{
    public $table = 'students_fees';

    const STATUS_UN_PAID = 0; 
    const STATUS_PAID = 1;
    const STATUS_PARTIALLY_PAID = 2;
    const STATUS_PAID_WITH_CREDIT = 3;
    
    const METHOD_ONE_TIME = 0;
    const METHOD_INSTALLMENT = 1; 

    const INACTIVE_PAYMENT = 0; 
    const ACTIVE_PAYMENT = 1; 

    public static function statusList() {
        return [
            StudentFee::STATUS_PAID => 'Paid',
            StudentFee::STATUS_PARTIALLY_PAID => 'Partially Paid',
            StudentFee::STATUS_UN_PAID => 'Un-Paid'
        ];
    }

    public static function methodsList() {
        return [
            StudentFee::METHOD_ONE_TIME => 'One Time',
            StudentFee::METHOD_INSTALLMENT => 'Installments',
        ];
    }


    public function service(){
        return $this->belongsTo('App\Service');
    }
}
