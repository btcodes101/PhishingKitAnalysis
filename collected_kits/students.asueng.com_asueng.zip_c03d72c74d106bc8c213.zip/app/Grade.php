<?php

namespace App;

use App\BaseModel;
use App\CSVReader;

use Illuminate\Support\Facades\DB;


class Grade extends BaseModel
{
    protected $table = 'grades';

    const STATE_REPETITION = 0x11;
    const STATE_IMPROVEMENT = 0x12;
    const STATE_EXAMINED_AGAIN = 0x14;    

    protected $guarded = [];

    public function gradeTotal(){
        return $this->belongsTo(GradeTotal::class, 'student_code', 'code');
    }

    public  function user(){
        return $this->belongsTo(User::class , 'student_id', 'id');
    }

    public  function student(){
        return $this->belongsTo(Student::class , 'student_id', 'id');
    }

    public  function course(){
        return $this->belongsTo(Course::class , 'course_id', 'id');
    }

    public  function originalCourse(){
        return $this->belongsTo(Course::class , 'original_course_id', 'id');
    }

    public  function plan(){
        return $this->belongsTo(Plan::class , 'plan_id', 'id');
    }

    public  function term(){
        return $this->belongsTo(Term::class , 'term_id', 'id');
    }

    public function gradeNote(){
        return $this->belongsTo(GradeNote::class , 'grade', 'id')->withDefault([
            'en_name' => '',
            'ar_name' => '',
        ]);
    }

    public function gradeState(){
        return $this->belongsTo(GradeState::class , 'state', 'id')->withDefault([
            'en_name' => '',
            'ar_name' => '',
        ]);
    }

    public function gradeControlAction(){
        return $this->belongsTo(GradeControlAction::class, 'control_action', 'id')->withDefault([
            'code' => '',
            'en_name' => '',
            'ar_name' => '',
        ]);
    }

    public function getGrade() {
        if($this->grade)
            return $this->gradeNote->ar_name;
        else if($this->grade_letter)
            return $this->grade_letter;
        else if($this->grade_gpa)
            return $this->grade_gpa;
        return '-';
    }

    public function graduatedGrade() {
        if($this->grade>=1 && $this->grade<=4)
            return $this->gradeNote->lang('name');
        else if($this->grade)
            return GradeNote::find(4)->lang('name');
        else if($this->grade=="0")
            return __('tr.Succeeded');

        if($this->grade_letter)
            return $this->grade_letter;
        
        return "-";
    }

    public function gradeLetter() {
        if($this->status&Study::STATUS_EXCLUDE) return "X"; 
        return $this->grade_letter;
    }

    public function gradeGPA() {
        return $this->grade_gpa;
    }

    public function creditHours() {
        return $this->course->credit_hours;
    }

    public function creditPoints() {
        return $this->creditHours()*$this->gradeGPA();
    }

    public function termIgnoreGrade() {
        if($this->grade_letter=='W'||$this->grade_letter=='P'||$this->grade_letter=='AU')
            return true;
        return false;
    }

    public function ignoreGrade() {
        if($this->grade_letter=='W'||$this->grade_letter=='P'||$this->grade_letter=='AU')
            return true;
        if(($this->state&Grade::STATE_EXAMINED_AGAIN)==Grade::STATE_EXAMINED_AGAIN)
            return true;
        return false;
    }

    public function examinedAgain() {
        return (($this->state&Grade::STATE_EXAMINED_AGAIN)==Grade::STATE_EXAMINED_AGAIN);
    }

    public function repetition() {
        return (($this->state&Grade::STATE_REPETITION)==Grade::STATE_REPETITION);
    }

    public function attempts() {
        return Grade::where('course_id', $this->course_id)->where('student_id', $this->student_id)->where('id', '<', $this->id)->count();
    }

    public function improvement() {
        return (($this->state&Grade::STATE_IMPROVEMENT)==Grade::STATE_IMPROVEMENT);
    }

    public static function importUGGrades($filePath) {

        $csv = CSVReader::open($filePath);
        if(empty($csv))dd("open failed");

        $nUpdated = $nAdded = 0;
        while ($row = $csv->next()) {

            $user = User::getCashed($row->student_code);
            if(empty($user)){ echo "<p>$row->student_code</p>"; continue; }

            $plan = Plan::select('id')->where('year_id', $row->year)->where('old_major_code', $row->old_major_code)->where('old_minor_code', $row->old_minor_code)->first();
            if(empty($plan)){echo("plan"); dd($row);}

            $course = Course::getCashed('UG2003', $row->course_code);
            if(empty($course)){
                $course = Course::getCashed('UG1996', $row->course_code);
                if(empty($course)){echo("course $courseCode"); dd($row);}
            }

            $grade = Grade::where('student_id', $user->id)->where('term_id', $row->term_id)->where('course_id', $course->id)->first();
            if(empty($grade)){ 
                $grade = new Grade();
                $nAdded++;
            } else {
                $nUpdated++;
            }

            $grade->student_id = $user->id;
            $grade->term_id = $row->term_id;
            $grade->course_id = $course->id;
            $grade->plan_id = $plan->id;
            $grade->year = $row->year;
            $grade->grade = $row->course_grade;
            $grade->save();        
        }

        dd("done nAdded:$nAdded, nUpdated:$nUpdated");        
    }

    public static function importNPGrades($filePath) {

        $csv = CSVReader::open($filePath);
        if(empty($csv))dd("open failed");

        $nUpdated = $nAdded = 0;
        while ($row = $csv->next()) {            
            
            $user = User::getCashed($row->student_code);
            if(empty($user)){ /*echo "<p>Student Not Found: $row->student_code</p>";*/ continue; }
            $student = $user->student;
            if(empty($student->bylaw)){ /*echo "<p>Bylaw Empty: $row->student_code</p>";*/ continue; }

            $course = Course::getCashed($student->bylaw, $row->course_code);
            if(empty($course)){ 
                $course = Course::getCashed('UG2018', $row->course_code);
                if(empty($course)){ 
                    $course = Course::getCashed('UG2013', $row->course_code);
                    if(empty($course)){ 
                        dd($row);
                        //echo "<p>$student->bylaw, $row->course_code</p>"; continue; 
                    }
                }
            }

            \Log::info('Garde:', [$row]);

            $grade = Grade::where('student_id', $user->id)->where('term_id', $row->term_id)->where('course_id', $course->id)->first();
            if(empty($grade)){ 
                $grade = new Grade();
                $nAdded++;
            } else {
                $nUpdated++;
            }

            $grade->student_id = $user->id;
            $grade->term_id = $row->term_id;
            $grade->course_id = $course->id;
            $grade->plan_id = $student->last_plan_id;
            $grade->year = 100;
            $grade->grade_letter = $row->grade_letter;
            $grade->save();            
        }

        dd("done nAdded:$nAdded, nUpdated:$nUpdated");
    }

    public function displayGPA() {

        if($this->grade_letter == 'P') {
            return '-';
        }
        
        return gpaRound($this->grade_gpa);
    }

    public function calculateGPA() {

        if($this->grade_letter == 'P') {
            return 0;
        }
        
        return $this->grade_gpa;
    }

    public function calculateCreditPoints() {

        $gpa = $this->calculateGPA();
        if($gpa) {
            return $this->calculateGPA() * $this->course->credit_hours;
        }

        return 0;
    }

    public static function letterToGPA($letter) {

        switch(strtoupper($letter)) {
            case "A+": return 4.0;
            case "A": return 4.0;
            case "A-": return 3.7;
            case "B+": return 3.3;
            case "B": return 3.0;
            case "B-": return 2.7;
            case "C+": return 2.3;
            case "C": return 2.0;
            case "C-": return 1.7;
            case "D+": return 1.3;
            case "D": return 1.0;
            case "F": return 0.0;
        }

        return null;
    }

    public static function GPAToLetter($gpa) {
        
        if($gpa<1)return "F";
        if($gpa<1.3)return "D";
        if($gpa<1.7)return "D+";
        if($gpa<2.0)return "C-";
        if($gpa<2.3)return "C";
        if($gpa<2.7)return "C+";
        if($gpa<3.0)return "B-";
        if($gpa<3.3)return "B";
        if($gpa<3.7)return "B+";
        if($gpa<4.0)return "A-";

        return "A";
    }

    public static function percentageToLetter($bylaw, $percentage) {

        if(in_array($bylaw, ['PG2015'])) {

            if($percentage<50)return "F";
            if($percentage<53)return "D";
            if($percentage<55)return "D+";
            if($percentage<60)return "C-";
            if($percentage<65)return "C";
            if($percentage<70)return "C+";
            if($percentage<75)return "B-";
            if($percentage<80)return "B";
            if($percentage<85)return "B+";
            if($percentage<90)return "A-";
            return "A";

        }
        else {

            if($percentage<60)return "F";
            if($percentage<64)return "D";
            if($percentage<67)return "D+";
            if($percentage<70)return "C-";
            if($percentage<73)return "C";
            if($percentage<76)return "C+";
            if($percentage<80)return "B-";
            if($percentage<84)return "B";
            if($percentage<89)return "B+";
            if($percentage<93)return "A-";
            if($percentage<97)return "A";
            return "A+";

        }
    }

    public static function percentageToGPA($bylaw, $percentage) {

        if(in_array($bylaw, ['PG2015'])) {

            if($percentage<50)return "0.0";
            if($percentage<53)return "1.0";
            if($percentage<55)return "1.3";
            if($percentage<60)return "1.7";
            if($percentage<65)return "2.0";
            if($percentage<70)return "2.3";
            if($percentage<75)return "2.7";
            if($percentage<80)return "3.0";
            if($percentage<85)return "3.3";
            if($percentage<90)return "3.7";
            return "4.0";

        }
        else {

            if($percentage<60)return "0.0";
            if($percentage<64)return "1.0";
            if($percentage<67)return "1.3";
            if($percentage<70)return "1.7";
            if($percentage<73)return "2.0";
            if($percentage<76)return "2.3";
            if($percentage<80)return "2.7";
            if($percentage<84)return "3.0";
            if($percentage<89)return "3.3";
            if($percentage<93)return "3.7";
            return "4.0";

        }        
    }

    public static function gpaToPercentage($bylaw, $gpa) {

        $gpas = [];

        if(in_array($bylaw, ['PG2015'])) {
            $gpas[] = (object)['gpa'=>0.0, 'percentage'=>0];
            $gpas[] = (object)['gpa'=>1.0, 'percentage'=>50];
            $gpas[] = (object)['gpa'=>1.3, 'percentage'=>53];
            $gpas[] = (object)['gpa'=>1.7, 'percentage'=>55];
            $gpas[] = (object)['gpa'=>2.0, 'percentage'=>60];
            $gpas[] = (object)['gpa'=>2.3, 'percentage'=>65];
            $gpas[] = (object)['gpa'=>2.7, 'percentage'=>70];
            $gpas[] = (object)['gpa'=>3.0, 'percentage'=>75];
            $gpas[] = (object)['gpa'=>3.3, 'percentage'=>80];
            $gpas[] = (object)['gpa'=>3.7, 'percentage'=>85];
            $gpas[] = (object)['gpa'=>4.0, 'percentage'=>90];
        }
        else {
            $gpas[] = (object)['gpa'=>0.0, 'percentage'=>0];
            $gpas[] = (object)['gpa'=>1.0, 'percentage'=>60];
            $gpas[] = (object)['gpa'=>1.3, 'percentage'=>64];
            $gpas[] = (object)['gpa'=>1.7, 'percentage'=>67];
            $gpas[] = (object)['gpa'=>2.0, 'percentage'=>70];
            $gpas[] = (object)['gpa'=>2.3, 'percentage'=>73];
            $gpas[] = (object)['gpa'=>2.7, 'percentage'=>76];
            $gpas[] = (object)['gpa'=>3.0, 'percentage'=>80];
            $gpas[] = (object)['gpa'=>3.3, 'percentage'=>84];
            $gpas[] = (object)['gpa'=>3.7, 'percentage'=>89];
            $gpas[] = (object)['gpa'=>4.0, 'percentage'=>93];
        }

        for($i=0;$i<count($gpas)-1;$i++) {
            $previous = $gpas[$i]->gpa;
            $next = $gpas[$i+1]->gpa;
            if($gpa>=$previous && $gpa<$next) {
                $previousPercentage = $gpas[$i]->percentage;
                $nextPercentage = $gpas[$i+1]->percentage;
                return $previousPercentage + (($nextPercentage - $previousPercentage) * ($gpa - $previous))/($next - $previous);
            }
        }

        return 100;
    }

    public function details() {

        $details = "";
        $course = $this->course;
        $maxOral = 0;
        if($course->max_first_oral)$maxOral += $course->max_first_oral;
        if($course->max_final_oral)$maxOral += $course->max_final_oral;
        $maxWork = 0;
        if($course->max_first_work)$maxWork += $course->max_first_work;
        if($course->max_final_work)$maxWork += $course->max_final_work;
        $maxExam = 0;
        if($course->max_first_exam)$maxExam += $course->max_first_exam;
        if($course->max_final_exam)$maxExam += $course->max_final_exam;
        if($maxOral>0)$maxOral = "/$maxOral"; else $maxOral ="";
        if($maxWork>0)$maxWork = "/$maxWork"; else $maxWork ="";
        if($maxExam>0)$maxExam = "/$maxExam"; else $maxExam ="";

        $maxTotal = 0;
        if($this->max_total)$maxTotal = $this->max_total;
        if($maxTotal>0)$maxTotal = "/$maxTotal"; else $maxTotal ="";

        if($this->oral) $details .= "O($this->oral$maxOral) ";
        if($this->work) $details .= "W($this->work$maxWork) ";
        if($this->exam) $details .= "E($this->exam$maxExam) ";
        if($this->total) $details .= "T($this->total$maxTotal) ";
        $gradeState = $this->gradeState->lang('name');
        if(!empty($gradeState)) $details .= "($gradeState)";
        $gradeControlAction = $this->gradeControlAction->lang('name');
        if(!empty($gradeControlAction)) $details .= "($gradeControlAction)";

        return $details;
    }

    public function failed() {
        return ($this->status&Study::STATUS_FAILED)==Study::STATUS_FAILED;
    }

    public function none() {
        if($this->status&Study::STATUS_SUCCEEDED) return false;
        if($this->status&Study::STATUS_FAILED) return false;
        return true;
    }

    public function summery() {
        if($this->grade_gpa) return "GPA:".round($this->grade_gpa, 2);
        else if($this->grade_letter) return $this->grade_letter;
        else if($this->total!==null && !empty($this->max_total)) {
            if(in_array($this->grade, ['7','8','9'])) return "-";
            return $this->total." / ".$this->max_total;
        }
    }

    public function isTaken() {
        if($this->isExclude()) return false;
        if($this->isSucceeded()) return true;
        if($this->isFailed()) return true;
        return false;
    }

    public function isIncomplete() {
        return (($this->status&Study::STATUS_INCOMPLETE)!=0);
    }

    public function isFailed() {
        return (($this->status&Study::STATUS_FAILED)!=0);
    }

    public function isSucceeded() {
        return (($this->status&Study::STATUS_SUCCEEDED)!=0);
    }

    public function isExclude() {
        return (($this->status&Study::STATUS_EXCLUDE)!=0);
    }

    public function isFreezed() {
        return (($this->status&Study::STATUS_FREEZED)!=0);
    }
}
