<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentControlAppeal extends Model
{
    protected $table = 'students_control_appeals';
    protected $fillable = ['student_id', 'term_id', 'request_id', 'merchantRefNo', 'course_id', 'control_decision', 'student_comment', 'user_id', 'created_at', 'updated_at'];

    const WAITING_FOR_DECISION = 1;
    const ACCEPTED = 2;
    const REJECTED = 3;
    const APPROVED_BY_CONTROL = 4;
}
