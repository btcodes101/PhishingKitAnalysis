<?php
namespace App\Mail;

use App\Archive;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\User;
use App\SMSJob;
use Mail;

//you should the queue with: php artisan queue:listen or php artisan queue:work
//nohup php artisan queue:listen --tries=3 > /dev/null 2>&1 &

//In WHM go Server Configuration/Tweak Settings/Restrict outgoing SMTP to root --> off

class SystemMail extends Mailable
{
    use Queueable, SerializesModels;

    protected $archive;
    protected $data;
    protected $language;
    protected $rejectToken=null;
    protected $acceptToken=null;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($templateId, $data = null, $language = 'en')
    {
        $this->archive = Archive::locate($templateId);
        $this->data = $data;
        $this->language = $language;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {

        if($this->archive != null)
            $body = $this->archive->page();

        if($this->data && array_key_exists("values", $this->data)) {
            foreach ($this->data["values"] as $key => $value) {                
                $body = mb_ereg_replace($key, $value, $body);  
            }
        }

        $title = "";
        if($this->data && array_key_exists("title", $this->data)) {
            $title = $this->data["title"];
        } 
        else if($this->archive->sub_title) {
            $title = $this->archive->sub_title;
        }

        $language = $this->language;

        return $this->subject($title)->view('emails.template', compact('body', 'language'));
    }

    private static function httpPost($url, $data)
    {
        $query = http_build_query($data);
        $curl = curl_init($url.$query);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    private static $smsErrorCodes = [
            1901 => 'Success, Message Submitted Successfully',
            1902 => 'Invalid URL , This means that one of the parameters was not provided',
            9999 => 'Please Wait For A While , This means You Sent Alot Of API Request At The Same Time',
            1903 => 'Invalid value in username or password field',
            1904 => 'Invalid value in "sender" field',
            1905 => 'Invalid value in "mobile" field',
            1906 => 'Insufficient Credit selected.',
            1907 => 'Server under updating',
            1908 => 'Invalid Date & Time format in “DelayUntil=” parameter',
            1909 => 'Error In Message',
            8001 => 'Mobile IS Null',
            8002 => 'Message IS Null',
            8003 => 'Language IS Null',
            8004 => 'Sender IS Null',
            8005 => 'Username IS Null',
            8006 => 'Password IS Null',
            6000 => 'Success, Request Submitted Successfully',
            "Error" => 'Invalid URL , This means that one of the parameters was not provided or wrong information'
        ];

    public static function sendSMS($mobiles, $message, $senderId, $language = 'en') {

        if(env('APP_DEBUG')===true) {
            $mobiles = "01111589933";
        }

        if(!is_array($mobiles))$mobiles = [$mobiles];

        $data = [
            'username' => 'hisham',
            'password' => 'Farag1956',
            'language' => ($language == "en")?1:2,
            'sender' => $senderId,
            'mobile' => implode(",", $mobiles),
            'message' => $message,
        ];

        try{
            $url = "https://smsmisr.com/api/webapi/?";
            $response = SystemMail::httpPost($url, $data);

            if ((json_decode($response)->code != "1901" || json_decode($response)->code != 1901) && (json_decode($response)->code != "6000" || json_decode($response)->code != 6000)) {
                    throw new \Exception(SystemMail::$smsErrorCodes[json_decode($response)->code]);
                }
        } catch(\Exception $e) {
            return $e->getMessage();
        }

        return true;
    }

    public function submitSMS($mobiles)
    {
        $description = $this->archive->description;

        if($this->data && array_key_exists("values", $this->data)) {
            foreach ($this->data["values"] as $key => $value) {                
                $description = mb_ereg_replace($key, $value, $description);  
            }
        }

        SystemMail::sendSMS($mobiles, $description, $this->data["SMSSenderId"], $this->language);
    }


    public function submit($to, $sms = false, $cc = [], $bcc = [], $notification = true) {

        if(env('APP_DEBUG') === true && $notification === true) {
            $to =  env("DEV_EMAIL", null); $cc = []; $bcc = [];
        }

        if(empty($to) && empty($bcc))return false;
        if(empty($cc))$cc = [];
        if(empty($bcc))$bcc = [];

        if(!is_array($to))$to = [$to];
        if(!is_array($cc))$cc = [$cc];
        if(!is_array($bcc))$bcc = [$bcc];
        
        try{
            \Log::info('SEND:', [$to, $cc, $bcc]);
            Mail::to($to)->cc($cc)->bcc($bcc)->send($this);
        } catch(\Exception $e) {
            \Log::info('ERROR:', [$e]);
            return $e->getMessage();
        }

        if($sms) {

            $mobiles = [];
            foreach ($to as $email) {
                $user = User::where("email", $email)->first();
                if(empty($user))continue;
                $mobile = mobile($user->mobile);
                if(!empty($mobile)) {
                    $mobiles[] = $mobile;
                }
            }

            if(count($mobiles)>0)
                $this->submitSMS($mobiles);
        }

        return true;
    }

    public static $lastEmailSetupError = "";

    public static function setupEmailAccount($email, $firstName, $lastName = "") {

        SystemMail::$lastEmailSetupError = "";

        //The password lenght is fixed to 8
        //We depend here on forming an array of characters that is being converted later to a string which is the return of this function.
        //The array consists of 8 elements (0-7), it contains two of each of uppercase, lowercase, numeric and non alphanumeric (special) characters.
        //They are ordered in a sequence so that not two similar types are successive most of times, please note that Microsoft is not accepting a lot of special characters types so there is no more of them, there is the guaranteed to be accepted.
        $password = [];
        $uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $lowercase = "abcdefghijklmnopqrstuvwxyz";
        $numeric = "0123456789";
        $specialchars = "@_";
        //Insert 2 Upper Case Letters.
        $password[0] = $uppercase[rand(0, strlen($uppercase)-1)];
        $password[2] = $uppercase[rand(0, strlen($uppercase)-1)];
        //Insert 2 Lower Case Letters.
        $password[1] = $lowercase[rand(0, strlen($lowercase)-1)];
        $password[3] = $lowercase[rand(0, strlen($lowercase)-1)];
        //Insert 2 Numbers.
        $password[4] = $numeric[rand(0, strlen($numeric)-1)];
        $password[6] = $numeric[rand(0, strlen($numeric)-1)];
        //Insert 2 Special Characters.
        $password[5] = $specialchars[rand(0, strlen($specialchars)-1)];
        $password[7] = $specialchars[rand(0, strlen($specialchars)-1)];
        //Convert Password Array to String
        sort($password);
        $password = implode($password);
        //Send the Curl request to outlook365 emails system.
        //Get cURL resource
        $curl = curl_init();
        // Set some options - we are passing in a useragent too here
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1, //Return in string forma
            CURLOPT_URL => 'http://213.131.95.195:8080/azuread/setnewpass.php',
            CURLOPT_USERAGENT => 'Codular Sample cURL Request'
        ));

        $data = array('myemail' => $email, 'mynewpass' => $password, 'myfirstname' => $firstName, 'mylastname' => $lastName); //input is student code
        curl_setopt($curl, CURLOPT_POSTFIELDS, ($data));

        $result = curl_exec($curl);

        // Send the request & save response to $resp
        if($result!="success") {
            SystemMail::$lastEmailSetupError = $result;
            return false;
        }

        return $password;
    }
}
