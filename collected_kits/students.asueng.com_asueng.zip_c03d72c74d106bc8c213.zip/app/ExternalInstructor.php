<?php

namespace App;

use App\BaseModel;

class ExternalInstructor extends BaseModel {

    protected $fillable = [
        'degree_code',
        'department',
        'faculty',
        'university',
    ];

    public function degree(){
        return $this->belongsTo('App\InstructorDegree', 'degree_code', 'code');
    }

    public function user() {

        return $this->belongsTo('App\User','id','id');
    }

}
