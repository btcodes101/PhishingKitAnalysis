<?php

namespace App;

use App\BaseModel;
use App\Department;
use App\Term;
use App\Plan;
use App\Mail\SystemMail;
use URL;

class Applicant extends BaseModel
{
    const STATUS_INCOMPLETE = -1;
    const STATUS_NEW = 0;
    const STATUS_ACCEPTED = 1;
    const STATUS_REJECTED = 2;
    const STATUS_FEEDBACK = 3;
    const STATUS_UPDATED = 4;
    const STATUS_APPROVED = 5;

    protected $table = 'applicants';

    public static function statusTypes(){
        return [
            Applicant::STATUS_INCOMPLETE => __("tr.Incomplete"),
            Applicant::STATUS_NEW => __("tr.New"),
            Applicant::STATUS_ACCEPTED => __("Accepted"),
            Applicant::STATUS_REJECTED => __("tr.Rejected"),
        ];
    }

    public static function statusBadges(){
        return [
            Applicant::STATUS_INCOMPLETE => "incomplete",
            Applicant::STATUS_NEW => "new",
            Applicant::STATUS_ACCEPTED => "accepted",
            Applicant::STATUS_REJECTED => "rejected",
        ];
    }

    public $fillable = [
        'en_full_name',
        'ar_full_name',
        'gender',
        'birth_date',
        'address',
        'mobile',
        'nationality_code',
        'national_id',
        'comment',
        'plan_id',
    ];

    public function archive() {
        return $this->belongsTo('App\Archive', 'archive_id', 'id');
    }

    public function feedback() {
        return $this->belongsTo('App\Ticket', 'feedback_ticket_id', 'id');
    }

    public function applicantType() {
        return $this->belongsTo('App\ApplicantType', 'apply_to', 'code');
    }

    public function discussion() {
        return $this->belongsTo('App\Ticket', 'discussion_ticket_id', 'id');
    }

    public function name(){
        if (app()->getLocale() == 'ar') return $this->ar_full_name;
        return $this->en_first_name .' '. $this->en_last_name;
    }

    public function nationality(){
        return $this->belongsTo(Country::class , 'nationality_code', 'code');
    }

    private static $cashedCountries = null;

    public static function countries() {
        if(Applicant::$cashedCountries)return Applicant::$cashedCountries;
        Applicant::$cashedCountries = Country::orderBy(lang()."_name")->pluck(lang()."_name as name", 'code')->toArray();
        return Applicant::$cashedCountries;
    }
    
    public static function grades(){
        return [
            4 => __('tr.Pass'),
            3 => __('tr.Good'),
            2 => __('tr.Very Good'),
            1 => __('tr.Excellent'),
        ];
    }

    public static function universities(){
        $items =  [
            'Ain Shams University' => 'Ain Shams University',
            'Mansoura University' => 'Mansoura University',
            'Aswan University' => 'Aswan University',
            'Alexandria University' => 'Alexandria University',
            'Assiut University' => 'Assiut University',
            'Aswan University' => 'Aswan University',
            'Banha University' => 'Banha University',
            'Beni Suef University' => 'Beni Suef University',
            'Cairo University' => 'Cairo University',
            'Damanhur University' => 'Damanhur University',
            'Damietta University' => 'Damietta University',
            'Egypt-Japan University of Science and Technology' => 'Egypt-Japan University of Science and Technology',
            'Fayoum University' => 'Fayoum University',
            'Helwan University' => 'Helwan University',
            'Higher Institute of Cooperative Studies and administrative Mounarh' => 'Higher Institute of Cooperative Studies and administrative Mounarh',
            'Institute of Engineering and Aviation Technology' => 'Institute of Engineering and Aviation Technology',
            'Kafr El Sheikh University' => 'Kafr El Sheikh University',
            'Mansoura University' => 'Mansoura University',
            'Menoufia University' => 'Menoufia University',
            'Minia University' => 'Minia University',
            'Port Said University' => 'Port Said University',
            'Qena University' => 'Qena University',
            'Sadat Academy for Administrative Sciences' => 'Sadat Academy for Administrative Sciences',
            'Sohag University' => 'Sohag University',
            'South Valley University' => 'South Valley University',
            'Suez Canal University' => 'Suez Canal University',
            'Suez University' => 'Suez University',
            'Tanta University' => 'Tanta University',
            'The Egyptian Center for Theoretical Physics' => 'The Egyptian Center for Theoretical Physics',
            'Workers University' => 'Workers University',
            'Zagazig University' => 'Zagazig University',
            'Academy News Today' => 'Academy News Today',
            'Academy of transit technology' => 'Academy of transit technology',
            'Ahram Canadian University' => 'Ahram Canadian University',
            'AL Ashr University' => 'AL Ashr University',
            'American University' => 'American University',
            'Arab Academy for Science, Technology and Maritime Transport' => 'Arab Academy for Science, Technology and Maritime Transport',
            'Arab Open University' => 'Arab Open University',
            'British University' => 'British University',
            'Canadian International College' => 'Canadian International College',
            'Delta University for Science and Technology' => 'Delta University for Science and Technology',
            'Egypt International University' => 'Egypt International University',
            'Egyptian Russian University' => 'Egyptian Russian University',
            'El Alamein University' => 'El Alamein University',
            'French University' => 'French University',
            'Future University' => 'Future University',
            'German University' => 'German University',
            'Heliopolis University' => 'Heliopolis University',
            'Higher Institute of Technology' => 'Higher Institute of Technology',
            'Integrated Thebes Academy of Sciences' => 'Integrated Thebes Academy of Sciences',
            'International Academy of Engineering and Information Sciences' => 'International Academy of Engineering and Information Sciences',
            'Misr University for Science and Technology' => 'Misr University for Science and Technology',
            'Modern Academy in Maadi' => 'Modern Academy in Maadi',
            'Modern University for Technology and Information' => 'Modern University for Technology and Information',
            'Nahda University' => 'Nahda University',
            'Academy of Sciences in Mansoura' => 'Academy of Sciences in Mansoura',
            'Nile University' => 'Nile University',
            'October 6 University' => 'October 6 University',
            'October University of Science and Modern optionterature' => 'October University of Science and Modern optionterature',
            'Pharos University in Alexandria' => 'Pharos University in Alexandria',
            'Sinai University' => 'Sinai University',
            'Singur University' => 'Singur University',
            'Sunrise Academy' => 'Sunrise Academy',
        ];

        ksort($items);

        return $items;
    }

    public static function idTypes() {
        return [
            'national_id' => __('tr.National ID'),
            'passport' => __('tr.Passport No.'),
        ];
    }

    public static function coeenergyFileTypes() {
        return (object) [
                'national_id_copy' => (object)[ 'title' => __("tr.national_id_copy"), 'required' => true, 'for'=> 'both' ],
                'transcript_copy' => (object)[ 'title' => __("tr.transcript_copy"), 'required' => true, 'for'=> 'both' ],
                'thanaweya_copy' => (object)[ 'title' => __("tr.thanaweya_copy"), 'required' => true, 'for'=> 'both' ],
                'cv_file' => (object)[ 'title' => __("tr.cv_file"), 'required' => true, 'for'=> 'both' ],
                'english_certificate_copy' => (object)[ 'title' => __("tr.english_certificate_copy"), 'required' => true, 'for'=> 'both' ],
                'activities_certificate_copy' => (object)[ 'title' => __("tr.activities_certificate_copy"), 'required' => true, 'for'=> 'both' ],
                'recommendation_letter_copy' => (object)[ 'title' => __("tr.recommendation_letter_copy"), 'required' => true, 'for'=> 'both' ],
                'motivation_letter_copy' => (object)[ 'title' => __("tr.motivation_letter_copy"), 'required' => true, 'for'=> 'both' ],
                'financial_aid_copy' => (object)[ 'title' => __("tr.financial_aid_copy"), 'required' => false, 'for'=> 'both' ],
                'disability_copy' => (object)[ 'title' => __("tr.disability_copy"), 'required' => false, 'for'=> 'both' ],
            ];
    }

    public static function lubanFileTypes() {
        return (object) [
                'national_id_copy' => (object)[ 'title' => __("tr.national_id_copy"), 'required' => true, 'for'=> 'both' ],
                'transcript_copy' => (object)[ 'title' => __("tr.transcript_copy"), 'required' => true, 'for'=> 'both' ],
                'thanaweya_copy' => (object)[ 'title' => __("tr.thanaweya_copy"), 'required' => true, 'for'=> 'both' ],
                'cv_file' => (object)[ 'title' => __("tr.cv_file"), 'required' => true, 'for'=> 'both' ],
                'english_certificate_copy' => (object)[ 'title' => __("tr.english_certificate_copy"), 'required' => true, 'for'=> 'both' ],
                'activities_certificate_copy' => (object)[ 'title' => __("tr.activities_certificate_copy"), 'required' => true, 'for'=> 'both' ],
                'recommendation_letter_copy' => (object)[ 'title' => __("tr.recommendation_letter_copy"), 'required' => true, 'for'=> 'both' ],
                'motivation_letter_copy' => (object)[ 'title' => __("tr.motivation_letter_copy"), 'required' => true, 'for'=> 'both' ],
                'financial_aid_copy' => (object)[ 'title' => __("tr.financial_aid_copy"), 'required' => false, 'for'=> 'both' ],
                'disability_copy' => (object)[ 'title' => __("tr.disability_copy"), 'required' => false, 'for'=> 'both' ],
            ];
    }

    public static function postgraduateFileTypes() {
        return (object) [
                'personal_photo' => (object)[ 'title' => __("tr.Personal Photo"), 'required' => true, 'for'=> 'both', 'note' => __("tr.Please use Professional Photo (No Selfie or Casual Photos Allowed)") ],
                'national_id_copy' => (object)[ 'title' => __("tr.National ID or Passport Copy"), 'required' => true, 'for'=> 'both' ],
                'certification_copy' => (object)[ 'title' => __("tr.Latest Certificate Copy"), 'required' => true, 'for'=> 'both' ],
                'foreign_managment_acceptance' => (object)[ 'title' => __("tr.Study Acceptance for Foreign Only"), 'required' => false, 'for'=> 'both', 'note'=>'موافقة إدارة رعاية الوافدين ومكتب هيئة الشئون العربية على التسجيل' ],
            ];
    }

    public static function undergraduateFileTypes() {
        return (object) [
                'personal_photo' => (object)[ 'title' => __("tr.Personal Photo"), 'required' => true, 'for'=> 'both', 'note' => __("tr.Please use Professional Photo (No Selfie or Casual Photos Allowed)") ],
                'national_id_copy' => (object)[ 'title' => __("tr.National ID or Passport for Non-Egyptians"), 'required' => true, 'for'=> 'both' ],
                'nomination_card_copy' => (object)[ 'title' => __("tr.Nomination Card or Transfer Letter"), 'required' => true, 'for'=> 'both' ],
                'birth_certificate_copy' => (object)[ 'title' => __("tr.Birth Certificate"), 'required' => true, 'for'=> 'both' ],
                'certification_copy' => (object)[ 'title' => __("tr.Egyptian High School Certificate or Equivalent"), 'required' => true, 'for'=> 'both' ],
                'military_form_copy' => (object)[ 'title' => __("tr.For Egyptian males, Form 2/3 from military"), 'required' => false, 'for'=> 'both' ],
                'military_form_copy' => (object)[ 'title' => __("tr.For Egyptian males born 2001 or before, Form 6 military"), 'required' => false, 'for'=> 'both' ],
                'sports_achievement_copy' => (object)[ 'title' => __("tr.Any Sports Achievement, if applicable"), 'required' => false, 'for'=> 'both' ],
                'virus_c_examination_copy' => (object)[ 'title' => __("tr.Virus C Examination Certificate"), 'required' => false, 'for'=> 'both', 'note'=> __('tr.Upload it after getting from the faculty through medical check up.') ],
            ];
    }

    public function updateFTS() {
        $text = "$this->id, $this->en_full_name, $this->ar_full_name";
        $mobile = ($this->mobile)?str_replace(" ", "", $this->mobile):"";
        $nationalId = ($this->national_id)?str_replace(" ", "", $this->national_id):"";
        $address = ($this->address)?str_replace(" ", "", $this->address):"";
        $email = ($this->email)?$this->email:"";
        $nationality_code = ($this->nationality_code)?$this->nationality_code:"";
       
        $text = getFTS($text).", $email, $address, $nationality_code, $nationalId, $mobile ,";
        $this->search_text = $text;
        $this->save();
    }

    public static function getSpecialization(){
        $sepcializationArray = [];
        $sepcialization = Department::select(lang().'_name as name', 'id')->get()->toArray();
        for ($i = 0; $i < count($sepcialization); $i++){
            $sepcializationArray[$sepcialization[$i]['id']] = $sepcialization[$i]['name'];
        }
        return $sepcializationArray;
    }
    
    public static function getPlans(){
        $plansArray = [];
        $plans = Plan::select(lang().'_minor as name', 'id')
                        ->join('terms_plans', 'terms_plans.plan_id', 'plans.id')
                        ->get()
                        ->toArray();
        for ($i = 0; $i < count($plans); $i++){
            $plansArray[$plans[$i]['id']] = $plans[$i]['name'];
        }
        return $plansArray;
    }

    public static function getDataValue($key, $value) {
        switch ($key) {
            case 'governorate':
                $governorate = Governorate::find($value);
                if($governorate)
                    return $governorate->lang('name');
                break;
            case 'university':
                $universities = Applicant::universities();
                if(array_key_exists($value, $universities)) 
                    return $universities[$value];
                break;
            case 'school_study_type':
                $schoolTypes = Student::schoolStudyType();
                if(array_key_exists($value, $schoolTypes)) 
                    return $schoolTypes[$value];
                break;
            case 'military_status':
                $militaryStatus = Student::militaryStatusLabels();
                if(array_key_exists($value, $militaryStatus)) 
                    return $militaryStatus[$value];
                break;
            case 'graduation_grade':
                $graduationGrade = Applicant::grades();
                if(array_key_exists($value, $graduationGrade)) 
                    return $graduationGrade[$value];
                break;
            case 'graduation_project_grade':
                $graduationProjectGrade = Applicant::grades();
                if(array_key_exists($value, $graduationProjectGrade)) 
                    return $graduationProjectGrade[$value];
                break;
            case 'diploma_grade':
                $diplomaGrade = Applicant::grades();
                if(array_key_exists($value, $diplomaGrade)) 
                    return $diplomaGrade[$value];
                break;
            case 'apply_to_department':
                $applyToDepartment = Department::mainDepartmentsList();
                if(array_key_exists($value, $applyToDepartment)) 
                    return $applyToDepartment[$value];
                break;
            case 'apply_to_specialization':
                $applyToSpecialization = Applicant::getSpecialization();
                if(array_key_exists($value, $applyToSpecialization)) 
                    return $applyToSpecialization[$value];
                break;
            case 'apply_to_term':
                $applyToTerm = Term::where('active', 1)->whereRaw(\DB::raw('start_date>NOW()'))->pluck(lang().'_name', 'id')->toArray();
                if(array_key_exists($value, $applyToTerm)) 
                    return $applyToTerm[$value];
                break;
            case 'apply_to_program':
                $applyToProgram = Applicant::getPlans();
                if(array_key_exists($value, $applyToProgram)) 
                    return $applyToProgram[$value];
                break;
            case 'first_program':
                $firstProgram = Plan::programsList('interdisciplinary', 'UG2018');
                if(array_key_exists($value, $firstProgram)) 
                    return $firstProgram[$value];
                break;
            case 'second_program':
                $secondProgram = Plan::programsList('interdisciplinary', 'UG2018');
                if(array_key_exists($value, $secondProgram)) 
                    return $secondProgram[$value];
                break;
            case 'marital_status':
                $labels = User::maritalStatusLabels();
                if(array_key_exists($value, $labels)) 
                    return $labels[$value];
                break;                
            case 'religion':
                $labels = User::religionsLabels();
                if(array_key_exists($value, $labels)) 
                    return $labels[$value];
                break;
            case 'father_nationality':
                $labels = Applicant::countries();
                if(array_key_exists($value, $labels)) 
                    return $labels[$value];
                break;
            case 'mother_nationality':
                $labels = Applicant::countries();
                if(array_key_exists($value, $labels)) 
                    return $labels[$value];
                break;
            case 'spouse_nationality':
                $labels = Applicant::countries();
                if(array_key_exists($value, $labels)) 
                    return $labels[$value];
                break;
            case 'passport_type':
                $labels = Student::passportsTypes();
                if(array_key_exists($value, $labels)) 
                    return $labels[$value];
                break;
        }
        return $value;
    }

    public function updateLink() {

        return route('applyto', ['applicantType'=>$this->apply_to, 'id'=>$this->id, 'secret'=>$this->secret]);
    }

    public function notify($message, $files) {

        //dd($this->updateLink());
        \Log::info('Request:', [$message]);

        $infoEmail = Setting::value("email");
        $title = "Feedback! - Application to ($this->apply_to)";
        $systemMail = new SystemMail("application_feedback", ['title'=>$title, 'values' => ['update_link' => $this->updateLink(), 'feedback_message'=>$message]]);
        if ($files && count($files)>0) {
            foreach ($files as $file) {
                $systemMail->attach($file->physicalPath(), array(
                    'as' => $file->title . '.' . $file->extension,
                    'mime' => $file->application_type));
            }
        }
        $systemMail->submit($this->email, false, $infoEmail);
    }

    public function needFeedback() {
        if($this->status==Applicant::STATUS_INCOMPLETE || !$this->feedback)
            return false;

        $message = $this->feedback->messages()->first();
        return ($message && $message->user_id);
    }

    public function getLastFeedbackMessage() {
        if($this->feedback) {
            foreach($this->feedback->messages as $message) { 
                if($message->user_id!=0) {
                    return $message;
                }
            }
        }
    }

    public function isNew() {
        return ($this->status==Applicant::STATUS_NEW);
    }

    public function isDraft() {
        return ($this->status==Applicant::STATUS_INCOMPLETE);
    }

    public function fileTypes() {

        switch($this->apply_to) {
            case "coeenergy": return $this->coeenergyFileTypes();
            case "postgraduate": return $this->postgraduateFileTypes();
            case "undergraduate": return $this->undergraduateFileTypes();
            case "luban": return $this->lubanFileTypes();
        }

        return [];
    }

    public function canUpdate() {

        if(!in_array($this->status, [Applicant::STATUS_INCOMPLETE, Applicant::STATUS_NEW, Applicant::STATUS_FEEDBACK, Applicant::STATUS_UPDATED]))
            return false;

        return true;
    }
    
}
