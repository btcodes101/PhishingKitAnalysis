<?php

namespace App;

use App\BaseModel;
use App\GradeType;
use App\CSVReader;

use Carbon\Carbon;
use \Illuminate\Support\Facades\DB;

class GradeTotal extends BaseModel
{

    protected $table = 'grades_total';

    public function gerneralGrade(){
        return $this->belongsTo(GradeType::class , 'grade', 'id');
    }

    public function lastYearGrade(){
        return $this->belongsTo(GradeType::class , 'year4_grade','id');
    }    

    public function projectGrade(){
        return $this->belongsTo(GradeType::class , 'project_grade','id');
    }    

    public function plan(){
        return $this->belongsTo(Plan::class);
    }

    public function termYear(){
        return $this->belongsTo(Term::class , 'term_id','id');
    }

    public function term(){
        return $this->belongsTo(Term::class , 'term_id','id');
    }

    public function totalSum(){
        return ($this->year0_max+$this->year1_max+$this->year2_max+$this->year3_max+$this->year4_max);
    }

    public function precent(){
        return round(($this->total_f/$this->totalSum())*100,2);
    }

    public function lastYearPrecent(){
        return round(($this->year4_total/$this->year4_max)*100,2);
    }

    public function lastYear(){
        return $this->belongsTo(Year::class,'last_year_id','id');
    }

    public function student() {
        return $this->belongsTo('App\Student','student_id','id');
    }

    public function updateProjectGPA() {

        $projectGrades = Grade::select('grades.*')->join('courses', 'courses.id', 'grades.course_id')->where('student_id', $this->student_id)->where('courses.project', 1)->get();
        
        $totalProuct = $totalCreditHours = 0;
        foreach ($projectGrades as $projectGrade) {
            $totalProuct += $projectGrade->calculateGPA()*$projectGrade->course->credit_hours;
            $totalCreditHours += $projectGrade->course->credit_hours;
        }
        if($totalCreditHours<=0)return null;

        $this->project_grade_gpa = (real)sprintf("%.2f",$totalProuct/$totalCreditHours);
        echo "<p>project_grade_gpa:$this->project_grade_gpa</p>";
        $this->save();
    }

    public static function calculateAccumlatedGPA($student) {

        $grades = $student->allGrades()
            ->select('grades.*')
            ->join('courses','courses.id','grades.course_id')
            ->join('terms','terms.id','grades.term_id')
            ->orderBy('terms.start_date')
            ->orderBy('courses.sis_course_id')
            ->orderBy('grades.grade_letter')->get();

        $nGrades = count($grades);
        if($nGrades==0)return null;

        $totalCreditPoints = $totalCreditHours = 0;
        $projectCreditPoints = $projectCreditHours = 0;
        $cumulativeCreditPoints = $cumulativeCreditHours = 0;
        $termCreditPoints = $termCreditHours = 0;
        $currentTermId = 0;

        $lastGrade = $grades[$nGrades-1];
        $termGrades = [];
        for ($i=0;$i<$nGrades;$i++) {

            $grade = $grades[$i];
            $nextGrade = ($i<($nGrades-1))?$grades[$i+1]:null;

            if($grade->term_id!=$currentTermId) {
                $termCreditPoints = 0;
                $termCreditHours = 0;
                $currentTermId = $grade->term_id;
                $termGrades = [];
            }

            $termGrades[$grade->course_id] = $grade;

            $gpa = $grade->calculateGPA();
            $creditHours = $grade->course->credit_hours;
            $creditPoints = $gpa * $creditHours;

            if(!$grade->termIgnoreGrade()) {
                
                $termCreditPoints += $creditPoints;
                $termCreditHours += $creditHours;
            }

            if(!$grade->ignoreGrade()) {
                
                $cumulativeCreditPoints += $creditPoints;
                $cumulativeCreditHours += $creditHours;
                $totalCreditPoints += $creditPoints;
                $totalCreditHours += $creditHours;
                
                if($grade->course->project==1) {
                    $projectCreditPoints += $creditPoints;
                    $projectCreditHours += $creditHours;
                }
            }

            //If last grade or next term is different, close current term
            if($grade->id==$lastGrade->id || $grade->term_id!=$nextGrade->term_id) {
                    
                $termGPA = ($termCreditHours>0)?($termCreditPoints/$termCreditHours):0;
                $cumulativeGPA = ($cumulativeCreditHours>0)?($cumulativeCreditPoints/$cumulativeCreditHours):0;

                $termsGPAs[$grade->term_id] = (object)[];
                $termsGPAs[$grade->term_id]->grades = $termGrades;

                $termsGPAs[$grade->term_id]->gpa = $termGPA;
                $termsGPAs[$grade->term_id]->credit_points = $termCreditPoints;
                $termsGPAs[$grade->term_id]->credit_hours = $termCreditHours;
                $termsGPAs[$grade->term_id]->cumulative_gpa = $cumulativeGPA;
                $termsGPAs[$grade->term_id]->cumulative_credit_hours = $cumulativeCreditPoints;
                $termsGPAs[$grade->term_id]->cumulative_credit_points = $cumulativeCreditHours;
            }

            //If last grade, close total
            if($grade->id==$lastGrade->id) {
                    
                $totalGPA = ($totalCreditHours>0)?($totalCreditPoints/$totalCreditHours):0;
                $projectGPA = ($projectCreditHours>0)?($projectCreditPoints/$projectCreditHours):0;
            }
        }

        return (object)[
            'project_gpa' => $projectGPA,
            'project_credit_hours' => $projectCreditHours,
            'project_credit_points' => $projectCreditPoints,
            'total_gpa' => $totalGPA,
            'total_credit_hours' => $totalCreditHours,
            'total_credit_points' => $totalCreditPoints,
            'termsGPAs' => $termsGPAs,
            'grades' => $grades,
        ];
    }

    public static function oldCalculateAccumlatedGPA($student) {

        $grades = [];
        $tempGrades = $student->allGrades()
            ->select('grades.*')
            ->join('courses','courses.id','grades.course_id')
            ->join('terms','terms.id','grades.term_id')
            ->orderBy('terms.start_date')
            ->orderBy('courses.sis_course_id')
            ->orderBy('grades.grade_letter')->get();

        $termsGPAs = [];
        foreach ($tempGrades as $grade) {

            if(!isset($termsGPAs[$grade->term_id])) {
                $termsGPAs[$grade->term_id] = (object)['cumulative_gpa'=>0, 'cumulative_credit_points'=>0, 'cumulative_credit_hours'=>0, 'gpa'=>0, 'credit_points'=>0, 'credit_hours'=>0];
            }

            if(array_key_exists($grade->course_id, $grades)) {
                
                $oldGrade = $grades[$grade->course_id];
                $grades[$grade->course_id] = $grade;

                if($grade->calculateGPA()>$oldGrade->calculateGPA()) {
                    if($oldGrade->failed()) {
                        //if failed in old grade and new grade is better
                        $oldGrade->state = Grade::STATE_EXAMINED_AGAIN;
                        $grade->state = Grade::STATE_REPETITION;
                    } else {
                        //if old grade is success and new grade is better
                        $oldGrade->state = Grade::STATE_EXAMINED_AGAIN;
                        $grade->state = Grade::STATE_IMPROVEMENT;
                    }

                    //$grades[$grade->course_id] = $grade;
                } else {
                    if($oldGrade->failed()) {
                        //if failed old grade and new grade is also failed
                        $oldGrade->state = Grade::STATE_EXAMINED_AGAIN;
                        $grade->state = Grade::STATE_REPETITION;
                    } else {
                        $oldGrade->state = Grade::STATE_EXAMINED_AGAIN;
                        $grade->state = Grade::STATE_IMPROVEMENT;
                    }
                }
                $oldGrade->save();
                $grade->save();
            } else {
                $grades[$grade->course_id] = $grade;
            }
        }

        $totalCreditPoints = $totalCreditHours = 0;
        foreach ($tempGrades as $grade) {

            if($grade->ignoreGrade())continue;

            $gpa = $grade->calculateGPA();

            echo "<p>$grade->term_id, $grade->course_id, ".$grade->course->code.", ".$grade->course->sis_course_id.", $grade->grade_letter, $gpa,".$grade->course->credit_hours."</p>";

            $creditHours = $grade->course->credit_hours;
            $creditPoints = $gpa * $creditHours;
            $totalCreditPoints += $creditPoints;
            $totalCreditHours += $creditHours;
            $cumulativeGPA = ($totalCreditHours>0)?($totalCreditPoints/$totalCreditHours):0;

            //echo "<p>($creditHours, $creditPoints) ($totalCreditHours, $totalCreditPoints)</p>";

            
            $termsGPAs[$grade->term_id]->credit_points += $creditPoints;
            $termsGPAs[$grade->term_id]->credit_hours += $creditHours;
            $termsGPAs[$grade->term_id]->cumulative_gpa = $cumulativeGPA;
            $termsGPAs[$grade->term_id]->cumulative_credit_hours = $totalCreditHours;
            $termsGPAs[$grade->term_id]->cumulative_credit_points = $totalCreditPoints;

            //echo "<p>(".$termsGPAs[$grade->term_id]->credit_points.") (".$termsGPAs[$grade->term_id]->credit_hours.")</p>";
        }

        $totalCreditPoints = $totalCreditHours = 0;
        $totalProjectCreditPoints = $totalProjectCreditHours = 0;
        foreach ($grades as $grade) {
            
            if($grade->course->credit_hours>0) {

                $gpa = $grade->calculateGPA();
                //echo "<p>$grade->term_id, $grade->course_id, ".$grade->course->code.", ".$grade->course->sis_course_id.", $grade->grade_letter, $gpa,".$grade->course->credit_hours."</p>";

                $creditHours = $grade->course->credit_hours;
                $creditPoints = $gpa * $creditHours;

                $totalCreditPoints += $creditPoints;
                $totalCreditHours += $creditHours;
                
                if($grade->course->project==1) {
                    $totalProjectCreditPoints += $gpa * $creditHours;
                    $totalProjectCreditHours += $creditHours;
                }

                //echo "<p>($creditHours, $creditPoints) ($totalCreditHours, $totalCreditPoints)</p>";
            }
        }

        if($totalCreditHours==0)return (object)[
            'project_grade' => 0,
            'grade' => 0,
            'credit_hours' => 0,
            'termsGPAs' => $termsGPAs,
        ];

        $projectGrade = ($totalProjectCreditHours>0)?($totalProjectCreditPoints/$totalProjectCreditHours):null;
        $grade = ($totalCreditPoints/$totalCreditHours);

        return (object)[
            'project_grade' => $projectGrade,
            'project_credit_hours' => $totalProjectCreditHours,
            'project_credit_points' => $totalProjectCreditPoints,
            'grade' => $grade,
            'credit_hours' => $totalCreditHours,
            'termsGPAs' => $termsGPAs,
        ];
        
    }

    public static function importUGGradesTotal($filePath) {

        $csv = CSVReader::open($filePath);
        if(empty($csv))dd("open failed");

        $nUpdated = $nAdded = 0;
        $nTotalUpdated = $nTotalAdded = 0;
        while ($row = $csv->next()) {

            $user = User::select('id')->where('code', $row->student_code)->first();
            if(empty($user)){echo("user"); dd($row);}
            $student = $user->student;

            $plan = Plan::select('id')->where('year_id', $row->year)->where('old_major_code', $row->old_major_code)->where('old_minor_code', $row->old_minor_code)->first();
            if(empty($plan)){echo("plan"); dd($row);}

            $finalGradeTerm = GradeTerm::where('student_id', $user->id)->where('term_id', $row->term_id)->first();
            if(empty($finalGradeTerm)){ 
                $finalGradeTerm = new GradeTerm();
                $nAdded++;
            } else {
                $nUpdated++;
            }

            $finalGradeTerm->student_id = $user->id;
            $finalGradeTerm->term_id = $row->term_id;
            $finalGradeTerm->plan_id = $plan->id;
            $finalGradeTerm->year = $row->year;
            $finalGradeTerm->total = $row->total;
            $finalGradeTerm->grade_type = $row->grade;
            $finalGradeTerm->save();

            if($finalGradeTerm->year==4 && in_array($finalGradeTerm->grade_type, [1,2,3,4])) {

                $finalGradeTerms = GradeTerm::where('student_id', $user->id)
                    ->where(function($query) {
                        $query->orWhere(function ($query) {
                            $query->whereIn('year', [0,1,2,3]);
                            $query->whereIn('grade_type', [1,2,3,4,5])->orderBy('year');
                        });
                        $query->orWhere(function ($query) {
                            $query->where('year', 4);
                            $query->whereIn('grade_type', [1,2,3,4])->orderBy('year');
                        });
                    })->get();

                $finalGradeTotal = GradeTotal::where('student_id', $user->id)->first();
                if(empty($finalGradeTotal)){ 
                    $finalGradeTotal = new GradeTotal();
                    $nTotalAdded++;
                } else {
                    $nTotalUpdated++;
                }

                $finalGradeTotal->student_id = $user->id;
                $finalGradeTotal->term_id = $row->term_id;
                $finalGradeTotal->plan_id = $plan->id;
                $finalGradeTotal->last_year_id = $row->year;

                $total = 0;
                $maxTotal = 0;
                $nHonours = 0;
                $nGrades = 0;
                foreach ($finalGradeTerms as $gradeTerm) {
                    $finalGradeTotal->{"year".$gradeTerm->year."_total"} = $gradeTerm->total;
                    $finalGradeTotal->{"year".$gradeTerm->year."_max"} = 1500;
                    $finalGradeTotal->{"year".$gradeTerm->year."_grade"} = $gradeTerm->grade_type;
                    $total += $gradeTerm->total;
                    $maxTotal += 1500;
                    if($gradeTerm->grade_type==1||$gradeTerm->grade_type==2)
                        $nHonours++;
                    if(in_array($gradeTerm->grade_type, [1,2,3,4]) && $gradeTerm->total>0)
                        $nGrades++;
                }

                echo "<p>nGrades: $nGrades</p>";

                if($nGrades==5) {

                    $gradeType = 4;
                    $percentage = ($total*100.0)/$maxTotal;
                    if($percentage>=84.0) $gradeType = 1;
                    else if($percentage>=74.0) $gradeType = 2;
                    else if($percentage>=64.0) $gradeType = 3;

                    $finalGradeTotal->total = $total;
                    $finalGradeTotal->total_f = $total;
                    $finalGradeTotal->honour = ($nHonours==5)?1:0;
                    $finalGradeTotal->grade = $gradeType;                        
                }

                $projectGrade = Grade::select('grades.*')->join('courses', 'courses.id', 'grades.course_id')->where('student_id', $user->id)->where('courses.project', 1)->whereIn('grades.grade', [1,2,3,4])->first();
                if($projectGrade) {
                    $finalGradeTotal->project_total = $projectGrade->total;
                    $finalGradeTotal->project_max = $projectGrade->max_total;
                    $finalGradeTotal->project_grade = $projectGrade->grade;
                }

                $finalGradeTotal->save();

                $user->student->last_term_id = $row->term_id;
                $user->student->graduated = 1;
                $user->student->save();         
            }
        }

        dd("done nRows:$csv->nRows nAdded:$nAdded, nUpdated:$nUpdated");
    }

    public static function importNPGradesTotal($filePath) {

        $csv = CSVReader::open($filePath);
        if(empty($csv))dd("open failed");

        $nUpdated = $nAdded = 0;
        while ($row = $csv->next()) {

            $user = User::getCashed($row->student_code);
            if(empty($user)){ echo "<p>$row->student_code</p>"; continue; }
            $student = $user->student;

            $gradeTotal = GradeTotal::where('student_id', $user->id)->first();
            if(empty($gradeTotal)){ 
                $gradeTotal = new GradeTotal();
                $nAdded++;
            } else {
                $nUpdated++;
            }

            $student->graduated = 1;
            $student->last_term_id = $row->term_id;
            $student->save();

            $gradeTotal->student_id = $user->id;
            $gradeTotal->term_id = $row->term_id;
            $gradeTotal->plan_id = $student->last_plan_id;
            $gradeTotal->last_year_id = 100;
            $gradeTotal->grade_gpa = $row->grade_gpa;
            $gradeTotal->credit_hours = $row->credit_hours;
            $gradeTotal->save();  
            $gradeTotal->project_grade_gpa = $gradeTotal->calculateProjectGPA();
            $gradeTotal->save();  
        }

        dd("done nRows:$csv->nRows nAdded:$nAdded, nUpdated:$nUpdated");
    }

    public function isOfficiallyGraduated() {

        if($this->faculty_approval_at===null || $this->university_approval_at===null)
            return false;

        if($this->last_year_id<100 && ($this->project_grade===null || $this->year4_total===null))
            return false;

        if($this->last_year_id==100 && ($this->project_grade_gpa===null))
            return false;

        return true;
    }
}
