<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OnlineExamsMethodConfirmation extends Model
{
     protected $table = 'online_exams_method_confirmation';
     protected $fillable = ['student_id','term_id','status'];
}
