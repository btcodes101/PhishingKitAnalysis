<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Failed extends Model
{
	protected $table = 'failed';
	public   $timestamps = false;
}
