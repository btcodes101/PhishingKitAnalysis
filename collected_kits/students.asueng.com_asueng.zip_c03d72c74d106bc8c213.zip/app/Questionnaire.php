<?php

namespace App;

use App\BaseModel;
use App\QuestionnaireTask;

class Questionnaire extends BaseModel
{
    protected $table = "questionnaires";
    protected $guarded = [];

    public function sections($group) {
        return QuestionnaireQuestion::where('questionnaire_id', $this->id)->where('question_group', $group)->distinct('question_section')->pluck('question_section')->toArray();
    }

    public function questions($group, $section) {
        return $this->hasMany('App\QuestionnaireQuestion','questionnaire_id', 'id')->where('question_group', $group)->where('question_section', $section)->orderBy('order')->orderBy('id');
    }

    
}