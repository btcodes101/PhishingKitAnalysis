<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FacultyLocation extends Model 
{

    protected $table = 'faculty_locations';

    protected $fillable = [
        'id',
        'name',
        'building_id',
        'floor',
        'capacity',
        'status',
        'sectors' ];

    public function building(){
        return $this->belongsTo('App\FacultyBuilding', 'building_id','id');
    }

    public static function statusLabels() {
        return [
            0 => __("tr.Not Working"),
            1 => __("tr.Working"),
        ];
    }
}
