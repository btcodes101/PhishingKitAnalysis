<aside class="app-side" id="app-side">
    <!-- BEGIN .side-content -->
    <div class="side-content" style="height: 1000px; background-color: #2b394c;">
        <!-- BEGIN .user-profile -->
        <div class="user-profile">
            @php($file = Auth::user()->archive->findChildByContentType("Personal Photo"))
            @if($file)
                <img class="profile-thumb" src="{{ route('download_file', ['id'=>$file->id]) }}" alt="{{ Auth::user()->lang('name') }}">
            @else
                <img src="/img/user.png" class="profile-thumb" alt="{{ Auth::user()->lang('name') }}">
            @endif
            
            <h6 class="profile-name">{{ Auth::user()->lang('name') }}</h6>

        </div>
        <!-- END .user-profile -->
        <!-- BEGIN .side-nav -->
        @if(!Auth::user()->hasRole('Guest'))
        <nav class="side-nav">
            <!-- BEGIN: side-nav-content -->
            <ul class="unifyMenu" id="unifyMenu">

                <li class="active">
                    <a href="{{ route('dashboard') }}">
                        <span class="has-icon">
                            <i class="icon-laptop_windows"></i>
                        </span>
                        <span class="nav-title">@lang('tr.Dashboard')</span>
                    </a>
                </li>

                <li>
                    <a href="{{ route('help') }}">
                        <span class="has-icon">
                            <i class="icon-help"></i>
                        </span>
                        <span class="nav-title">@lang('tr.Help')</span>
                    </a>
                </li>
                
            </ul>
            <!-- END: side-nav-content -->
        </nav>
        @endif
        <!-- END: .side-nav -->
    </div>
    <!-- END: .side-content -->
</aside>
