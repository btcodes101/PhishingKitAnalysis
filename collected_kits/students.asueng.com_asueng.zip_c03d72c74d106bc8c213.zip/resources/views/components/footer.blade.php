<footer class="main-footer fixed-btm">
    @lang('tr.Copyright')
    , <a href="http://isc.eng.asu.edu.eg" title="{{ __('tr.isc') }}">{{ __('tr.isc') }}</a>
    , <a href="https://eng.asu.edu.eg" title="{{ __('tr.faculty') }}">{{ __('tr.faculty') }}</a>
    , <a href="http://asu.edu.eg" title="{{ __('tr.universityASU') }}">{{ __('tr.universityASU') }}</a>.
</footer>
