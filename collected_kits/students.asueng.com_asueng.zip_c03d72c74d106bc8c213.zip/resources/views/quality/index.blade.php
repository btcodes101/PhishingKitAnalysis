@extends('layouts.master')

@section('title', __("tr.Quality"))
@section('subtitle', __("tr.Quality Unit") )
@section('titleicon', "icon-point-of-interest-outline")

@section('content')
    <!-- BEGIN .main-content -->
    <div class="main-content">
        <div class="row gutters">
            
            @can('access_coursefiles')
            <div class="col-md-3">
                <a href="{{ route('course_files') }}" class="setting-box">
                    <div class="title">@lang('tr.Course Files')</div>
                    {{--<div class="static"></div>--}}
                    <div class="icon">
                        <span class="icon-files-empty"></span>
                    </div>
                </a>
            </div>
            @endcan

            @can('access_questionnaires')
            <div class="col-md-3">
                <a href="{{ route('questionnaires') }}" class="setting-box">
                    <div class="title">@lang('tr.Questionnaires')</div>
                    <div class="icon">
                        <span class="icon-help-with-circle"></span>
                    </div>
                </a>
            </div>
            @endcan

            @can('access_quality')
            <div class="col-md-3">
                <a href="{{ route("quality_team") }}" class="setting-box">
                    <div class="title">@lang('tr.Quality Team')</div>
                    <div class="icon">
                        <span class="icon-users"></span>
                    </div>
                </a>
            </div>
            @endcan

            @can('access_studies')
            <div class="col-md-3">
                <a href="{{ route('studies') }}" class="setting-box">
                    <div class="title">@lang('tr.Studies')</div>
                    <div class="icon">
                        <span class="icon-contacts"></span>
                    </div>
                </a>
            </div>
            @endcan
        </div>
    </div>
    <!-- END: .main-content -->
@endsection