@extends('layouts.master')

@section('title', ($questionnaireTask->course_id==0)?"General Questionnaire":__("tr.QuestionnaireOf").$questionnaireTask->course->code)
@section('subtitle', __("tr.QuestionnaireDetails"))
@section('titleicon', "icon-point-of-interest-outline" )

@section('advancedaction')
<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
    <a href="{{ route('download_questionnaire',['id'=> $questionnaireTask->id]) }}" class="btn btn-primary float-right">
        <i class="icon-download"></i>
    </a>
    <a id='btn' onclick='printDiv();' href="#" class="btn btn-primary float-right">
        <i class="icon-print"></i>
    </a>
</div>
@stop

<?php
		function scoreBadge($score) {
		    if ($score<50)return "danger";
            if ($score<65)return "info";
            if ($score<75)return "primary";
            if ($score<85)return "secondary";
            return "success";
		}
?>

@section('content')
<div class="main-content">
	<div class="row gutters ComBody" id="mainContetnt">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header">
					@lang('tr.GeneralInformation')
				</div>
				<div class="row gutters col-xl-12 col-lg-12 col-md-12 col-sm-12">
					<div class="card-body col-xl-9 col-lg-9 col-md-9 col-sm-9">
						<table class="table table-striped m-0">
							<tbody>
							<tr>
								<th scope="row" width="150px">@lang('tr.Course')</th>
								<td>{{ ($questionnaireTask->course_id==0)?"General Questionnaire":$questionnaireTask->course->code.":".$questionnaireTask->course->lang('name') }}</td>
							</tr>
							<tr>
								<th scope="row" width="150px">@lang('tr.Instructors')</th>
								<td>
									@foreach($instructors as $instructor)
										<a href="#instructor{{ $instructor->id }}">{{ $instructor->lang('name') }}</a>
										@if($instructor !== $instructors[count($instructors)-1])
										,
										@endif
									@endforeach
								</td>
							</tr>
							</tbody>
						</table>
					</div>
					<div class="card-body col-xl-3 col-lg-3 col-md-3 col-sm-3">
						<div class="card-body">
							<ul class="social-stats">
								<li class="clearfix">
									<div class="month-type svg-container" id="total"></div>
									<div class="social-info">
										<h4>{{ $questionnaireTask->count }}</h4>
										<p class="text-truncate">@lang('tr.Participants')</p>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>

		@foreach( $questionnairesTasks as $tempQuestionnaireTask)
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" id="instructor{{ $tempQuestionnaireTask->instructor_id }}">
			<div class="card">
				<div class="card-header" role="tab" id="cardheading{{ $tempQuestionnaireTask->instructor_id }}">
					<a data-toggle="collapse" href="#collapseCard{{ $tempQuestionnaireTask->instructor_id }}" aria-expanded="true" aria-controls="collapseCard{{ $tempQuestionnaireTask->instructor_id }}" class="">
						@if( $tempQuestionnaireTask->instructor_id ==0 )
							<span class="icon-media-play"></span> @lang('tr.CourseEvaluation') ({{$tempQuestionnaireTask->count}} @lang('tr.Participants'))
						@else
							<span class="icon-media-play"></span> @lang('tr.InstructorEvaluation') : {{ $tempQuestionnaireTask->instructor->lang('name') }} ({{ $tempQuestionnaireTask->count }} @lang('tr.Participants'))
						@endif
					</a>
					<div class="badge badge-pill badge-{{ scoreBadge($tempQuestionnaireTask->average_score) }} float-right" title="Average Score of all Questions">
						{{ round($tempQuestionnaireTask->average_score) }} %
					</div>
				</div>

				<div id="collapseCard{{ $tempQuestionnaireTask->instructor_id }}" class="collapse show" role="tabpanel" aria-labelledby="cardheading{{ $tempQuestionnaireTask->instructor_id }}" style="">
					<div class="row gutters col-xl-12 col-lg-12 col-md-12 col-sm-12">
						<div class="card-body">
							<table class="table table-striped m-0">
								<thead>
									<tr>
										<th class="col-xl-6 col-lg-6 col-md-6 col-sm-6">@lang('tr.Question')</th>
										<th class="col-xl-6 col-lg-6 col-md-6 col-sm-6">@lang('tr.Score')</th>
									</tr>
								</thead>
								<tbody>
								@foreach($tempQuestionnaireTask->questionnaireQuestionsAnswers() as $questionnaireQuestionAnswer)
									<tr>
										<td class="icon-help-with-circle" scope="row" width="150px"> {{ (lang()=='en')?$questionnaireQuestionAnswer->en_question:$questionnaireQuestionAnswer->ar_question }}</td>
										<td>{{ $questionnaireQuestionAnswer->average_score }}%</td>
									</tr>
								@endforeach
								</tbody>
							</table>
							<br>
							@if(auth()->user()->hasPermissionTo('edit_questionnaires') || $tempQuestionnaireTask->term->questionnaire_publish_status==2)
							@foreach($tempQuestionnaireTask->questionnaireQuestionsComments() as $questionnaireQuestionComment)
								@if(!empty($questionnaireQuestionComment->comment))
								<div class="alert alert-warning">
									<span style="color:gray;">
										{{ $questionnaireQuestionComment->question }}
									</span><br/>
									{{ $questionnaireQuestionComment->comment }}
								</div>
								@endif
							@endforeach
							@endif
						</div>
					</div>
				</div>
			</div>
		</div>
		@endforeach
	</div>
</div>

<script src="/js/circliful/circliful.min.js"></script>
<script src="/js/printThis.js"></script>
<script type="text/javascript">
    $( document ).ready(function() {
        $("#total").circliful({
            animation: 1,
            animationStep: 5,
            foregroundBorderWidth: 15,
            backgroundBorderWidth: 7,
            percent: '{{ round($questionnaireTask->average_score) }}',
            fontColor: '#000000',
            percentageTextSize: 36,
            foregroundColor: '#4266b2',
            backgroundColor: '#f5f6fa',
            multiPercentage: 1,
            percentages: [10, 20, 30],
        });
    });

    function printDiv()
    {
        $('#mainContetnt').printThis({
            debug: false,               // show the iframe for debugging
            importCSS: true,            // import parent page css
            importStyle: true,         // import style tags
            printContainer: true,       // print outer container/$.selector
            removeInline: false,        // remove inline styles from print elements
            printDelay: 333,            // variable print delay
            header: null,               // prefix to html
            footer: null,               // postfix to html
            base: false,                // preserve the BASE tag or accept a string for the URL
            formValues: true,           // preserve input/form values
            canvas: false,              // copy canvas content
            doctypeString: '',       // enter a different doctype for older markup
            removeScripts: false,       // remove script tags from print content
            copyTagClasses: false,      // copy classes from the html & body tag
            beforePrintEvent: null,     // function for printEvent in iframe
            beforePrint: null,          // function called before iframe is filled
            afterPrint: null            // function called before iframe is removed
        });
    }
</script>
@stop