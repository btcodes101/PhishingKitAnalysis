@extends('layouts.master')

@section('title',  __('tr.Show Questionnaire Questions') )
@section('subtitle', __('tr.Manage Questionnaire Questions') )
@section('titleicon', "icon-point-of-interest-outline" )

@section('advancedaction')
    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 mt-1">
        <div class="btn-group float-right">
            <div class="btn-group">
                <button type="button" class="btn btn-primary">@lang('tr.More')</button>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="sr-only">Toggle Dropdown</span>
                </button>
                <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-start" style="position: absolute; transform: translate3d(71px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                    @can('review_questionnaires')
                        <a class="dropdown-item" id="add_question" href="javascript:void(0)">@lang('tr.Add Question')</a>
                    @endcan
                </div>
            </div>
        </div>
    </div>
@stop

@section('content')
    <div class='modal fade' id='edit_modal' tabindex='-1' role='dialog' aria-labelledby='edit_modal' aria-hidden='true'>
        <form action="" method="post" enctype='multipart/form-data'>
            {{ csrf_field() }}
            <div class='modal-dialog' role='document'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <h5 class='modal-title' id='modal_label'></h5>
                        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                        </button>
                    </div>
                    <div class='modal-body'>
                        <div class="form-group">
                            <input required type="text" class="form-control" id="en_question" name="en_question" title="@lang('tr.EnglishName')" placeholder="@lang('tr.English Question')">
                        </div>

                        <div class="form-group">
                            <input required type="text" class="form-control" id="ar_question" name="ar_question" title="@lang('tr.ArabicName')" placeholder="@lang('tr.Arabic Question')" style="direction: rtl">
                        </div>

                        {{--Text search[en_name, ar_name, code]--}}
                        <div class="form-group">
                            {!! Form::select('type', array(''=>__('tr.Select Question Type'))+(\App\QuestionnaireQuestion::questionType()),null, array('id'=> 'type', 'class'=>'form-control', 'required'=>'required')) !!}
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" id="en_section" name="en_section" title="@lang('tr.Question Section English')" placeholder="@lang('tr.Question Section English')">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" id="ar_section" name="ar_section" title="@lang('tr.Question Section Arabic')" placeholder="@lang('tr.Question Section Arabic')" style="direction: rtl">
                        </div>

                        <div class="form-group">
                            {!! Form::select('question_group', array(''=>__('tr.Select Question Group'))+(\App\QuestionnaireQuestion::questionGroup()),null, array('id'=> 'question_group', 'class'=>'form-control', 'required'=>'required')) !!}
                        </div>
                    </div>
                    <div>
                        <div id='progress_bar' style="background-color: green; width: 0%; height: 2px;"></div>
                    </div>
                    <div class='modal-footer'>
                        <button type='submit' class='btn btn-primary' id='action'>@lang('tr.Submit') <span id="progress_text"></span></button>
                        <button type='button' class='btn btn-light' id='close' data-dismiss='modal'>@lang('tr.Cancel')</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- BEGIN .main-content -->
    <div class="main-content">

        <div class="card">
            <div class="card-body pb-0">
                <div class="row filter-box">
                    {{--Text search[en_name, ar_name, code]--}}
                    <div class="col-md-2">
                        {{ Form::text('text_search', null, ['id'=>'text_search', 'data-placement'=>'top', 'title'=> __('tr.TextSearch'), 'placeholder'=>__('tr.TextSearch')]) }}
                    </div>
                    {{--English Section--}}
                    <div class="col-md-2">
                        <select name="question_section_search" id="question_section_search">
                            <option value="">@lang('tr.Select Question Section')</option>
                            <option value="Empty">@lang('tr.Empty')</option>
                            @foreach($sections as $section)
                                @if($section->en_section != null)
                                    <option value="{{ $section }}">{{ $section->en_section }}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                    {{--Question Type--}}
                    <div class="col-md-2">
                        <select name="question_type" id="question_type_search">
                            <option value="">@lang('tr.Select Question Type')</option>
                            @foreach(\App\QuestionnaireQuestion::questionType() as $key => $type)
                                <option value="{{ $key }}">{{ $type }}</option>
                            @endforeach
                        </select>
                    </div>
                    {{--Question Group--}}
                    <div class="col-md-2">
                        <select name="question_group_search" id="question_group_search">
                            <option value="">@lang('tr.Select Question Group')</option>
                            @foreach(\App\QuestionnaireQuestion::questionGroup() as $key => $group)
                                <option value="{{ $key }}">{{ $group }}</option>
                            @endforeach
                        </select>
                    </div>
                    {{--Button--}}
                    <div class="col-md-2 float">
                        <button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
                    </div>

                    {{--Button--}}
                    <div class="col-md-2 float">
                        <button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- TABLE -->
        <div class="card">
            <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                <div class="card-body">
                    <table id="data_table" class="display" style="width:100%">
                        <thead>
                        <tr>
                            <th >#</th>
                            <th >#</th>
                            <th >@lang('tr.English Question')</th>
                            <th >@lang('tr.Arabic Question')</th>
                            <th >@lang('tr.English Section')</th>
                            <th >@lang('tr.Arabic Section')</th>
                            <th >@lang('tr.Type')</th>
                            <th >@lang('tr.Group')</th>
                            <th ></th>
                        </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- END: .main-content -->

    <script type="text/javascript">

        $(document).ready(function() {
            var questionnaireTypes = [];
            @foreach (\App\QuestionnaireQuestion::questionType() as $key => $type)
                    questionnaireTypes[{{ $key }}] = '{{ $type }}';
            @endforeach

            var questionnaireGroups = [];
            @foreach (\App\QuestionnaireQuestion::questionGroup() as $key => $group)
                questionnaireGroups['{{ lcfirst($group) }}'] = '{{ $group }}';
            @endforeach

            var table = $('#data_table').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                stateSave: false,
                rowId: 'id',
                rowReorder: {
                    dataSrc: 'id',
                },
                "order": [[ 0, "asc" ]],
                "ajax": {
                    "url": '{{ route('show_questions',['questionnaire'=>$questionnaire->id]) }}',
                    "dataSrc": "data.data"
                },
                "columns": [
                    { "data": "order", "name": "order","className": "reorder"},
                    { "data": "id", "name": "id"},
                    { "data": "en_question", "name": "en_question"},
                    { "data": "ar_question", "name": "ar_question"},
                    { "data": "en_section", "name": "en_section"},
                    { "data": "ar_section", "name": "ar_section"},
                    { "data": "type", "name": "type",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            html += questionnaireTypes[oData.type];
                            $(nTd).html("<span class='action-column'>"+html+"</a>");
                        }
                    },
                    { "data": "question_group", "name": "question_group",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            html += questionnaireGroups[oData.question_group];
                            $(nTd).html("<span class='action-column'>"+html+"</a>");
                        }
                    },
                    { "data": "id", "name": "id",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";

                            {{-- @can('edit_lookups')
                                html += "<a title='@lang('tr.Edit')' href='javascript:void(0)' class='edit_question'><i class='icon-edit'></i></a>&nbsp;";
                            @endcan

                                    @can('delete_lookups')
                                html += "<a title='@lang('tr.Delete')' href='javascript:void(0)' class='delete_question'><i class='icon-delete'></i></a>";
                            @endcan --}}

                            $(nTd).html("<span class='action-column'>"+html+"</a>");
                        }
                    },
                ],
            });

            $(".dataTables_filter").hide();


            table.on( 'row-reorder', function ( e, diff, edit ) {
                console.log(diff[0]);
                var id = diff[0].oldData;
                var neighbour_id = diff[0].newData;
                var position = (diff[0].newPosition < diff[0].oldPosition)? 'before' : 'after';
                var url = '{{ route('reorder_questions',['questionnaire'=>'#id','position'=>'#position','neighbour_id'=>'#neighbour']) }}';
                url = url.replace('#id',id).replace('#position',position).replace('#neighbour',neighbour_id);
                $.ajax({
                    type: 'get',
                    url: url,
                    success: function (data) {
                        console.log(data);
                        table.draw();
                    }
                });
            });

            $('#search_button').on('click', function () {
                table.search($("#text_search").val());
                // table.columns(0).search($("#question_section_search").val());
                table.columns(1).search($("#question_type_search").val());
                table.columns(2).search($("#question_group_search").val());
                table.draw();
            } );

            $('#text_search').on('keyup', function (e){
                if(e.keyCode == 13)
                    $('#search_button').trigger('click');
            });

            $('#reset_button').on('click', function () {
                $("#text_search").val("");
                // $("#question_section_search").val("");
                $("#question_type_search").val("");
                $("#question_group_search").val("");
                $('#search_button').trigger('click');
            });
            var array = [];
            @foreach(\App\QuestionnaireQuestion::questionGroup() as $item)
            array.push('{{ $item }}');
            @endforeach

            function edit(row) {
                var modal = $('#edit_modal');
                var data = null;
                modal.find('form')[0].reset();
                modal.find("option:selected").removeAttr("selected");
                if(row) {
                    data = table.row(row).data();
                    modal.find('#en_question').val(data.en_question);
                    modal.find('#ar_question').val(data.ar_question);
                    if (data.type === 0 && data.answer1 === 'Female'){
                        modal.find('#type option[value='+2+']').attr('selected', 'selected');
                    } else {
                        modal.find('#type option[value='+data.type+']').attr('selected', 'selected');
                    }
                    modal.find('#en_section').val(data.en_section);
                    modal.find('#ar_section').val(data.ar_section);

                    var val = 0;
                    var text = data.question_group[0].toUpperCase() + data.question_group.slice(1);
                    for (var i=0;i<array.length;i++){
                        if (array[i] === text){
                            val = i;
                        }
                    }
                    modal.find('#question_group option[value='+val+']').attr('selected', 'selected');
                }

                var action = '{{ route('save_question', ['questionnaire'=> $questionnaire->id, 'question'=>'#id']) }}';
                modal.find('#modal_label').text((data)?'@lang("tr.Edit Question")':'@lang("tr.Add Question")');
                action = action.replace('#id', (data)?data.id:0);
                modal.find('form').attr('action', action);
                modal.execModal({
                    progressBar: 'progress_bar',
                    progressText: 'progress_text',
                }, function(response){
                    if(row) {
                        table.draw(false);
                    } else {
                        table.page('last').draw('page');
                    }
                }, function(response){
                    var errorString = '';
                    $.each( response.errors, function( key, value) {
                        errorString += key + ', ' + value + ',';
                    });
                    errorBox(errorString);
                });
            }

            $(document).on("click", ".delete_question", function () {
                var deleteURL = '{{ route('delete_question', ['questionnaire'=> $questionnaire->id, 'question'=>'#id']) }}';
                var row = $(this).closest('tr');
                var data = table.row(row).data();
                var url = deleteURL.replace('#id', data.id);
                var message = "Are you sure you want to delete (<B>"+data.{{ lang() }}_question+"</B>) ?";

                warningBox(message, function() {
                    $.post(url, {"_token": '{{ csrf_token() }}' }, function(data, status){
                        if(data.msg){
                            errorBox(data.msg);
                        } else {
                            table.row("#"+data.id).remove().draw(false);
                            infoBox('@lang('tr.DeletedSuccessfully')');
                        }
                    });
                });
            });

            $('#add_question').on('click', function () {
                edit(null);
            });

            $(document).on("click", ".edit_question", function () {
                edit($(this).closest('tr'));
            });
        });
    </script>
@stop