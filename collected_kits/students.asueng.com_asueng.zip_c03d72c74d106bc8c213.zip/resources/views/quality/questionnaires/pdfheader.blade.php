<table width="100%" cellpadding="5px" cellspacing="0px">
    <tr>
        <td align="center" height="24px">
            <FONT SIZE="16px"><B>Ain Shams University</B></FONT>
        </td>
    </tr>
    <tr>
        <td align="center" height="24px">
            <FONT SIZE="14px"><B>Faculty of Engineering</B></FONT>
        </td>
    </tr>
    <tr>
        <td align="center" height="22px">
            &nbsp;
        </td>
    </tr>
    <tr>
        <td align="center" height="22px">
            <FONT SIZE="14px">Quality Unit</FONT>
        </td>
    </tr>
</table>