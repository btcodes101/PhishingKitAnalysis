@extends('layouts.master')

@section('title', __("tr.ReviewComments"))
@section('subtitle', __("tr.ReviewStudentsComments") )
@section('titleicon', "icon-point-of-interest-outline" )

@section('advancedaction')
    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 mt-1">
        <h4 class="total">
            <span id="comments_count">-</span> @lang('tr.Comment')
        </h4>
    </div>
@endsection

@section('content')
    <div class="main-content">
        <div class="card">
            <div class="card-body pb-0">
                <div class="filter-box">
                    <div class="row">
                        {{--Term--}}
                        <div class="col-md-2">
                            {!! Form::select('term_id', array(""=>__("tr.AllTerms"))+$terms, $currentTermID, array('id'=> 'term_id', 'data-placement'=>'top', 'title'=> __('tr.Term'))) !!}
                        </div>

                        {{--Status--}}
                        <div class="col-md-2">
                            {!! Form::select('review_status', $reviewStatus, 2, array('id'=> 'review_status', 'data-placement'=>'top', 'title'=> __('tr.Status'))) !!}
                        </div>

                        {{--Text search[en_name, ar_name, code]--}}
                        <div class="col-md-2">
                            {{ Form::text('text_search', null, ['id'=>'text_search', 'data-placement'=>'top', 'title'=> __('tr.TextSearch'), 'placeholder'=>__('tr.TextSearch')]) }}
                        </div>

                        {{--Button--}}
                        <div class="col-md-2 float">
                            <button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
                        </div>

                        {{--Button--}}
                        <div class="col-md-2 float">
                            <button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div id="comments"></div>
        <div id="more">
            <div class="card">
                <button type="button" class="btn btn-info" id="show_more" style="display: none">@lang('tr.More')</button>
            </div>
        </div>

        <div class="alert" id="template_comment_card" style="display: none">
            <a class="reject_action comment_action" href='javascript:void(0)'><i class="icon-times float-right" style="color:red;"></i></a>
            <a class="accept_action comment_action" href='javascript:void(0)'><i class="icon-tick float-right" style="color:green;"></i></a>
            @hasanyrole('QA|Admin')
            <a class="spy_action comment_action" href='javascript:void(0)'><i class="icon-eye2 float-right"></i></a>
            @endhasanyrole
            <span class="comment_text"></span>
        </div>

    </div>
    <script type="text/javascript">
        var firstId = null;
        function loadMoreCommnets(done){
            var termId = $('#term_id').val();
            var reviewStatus = $('#review_status').val();
            var textSearch = $('#text_search').val();
            var submitToken = "{{ csrf_token() }}";
            var submitUrl = "{{ route('comments') }}";
            var commentUrl = "{{ route('review_comment', ['questionnaire_answer_id'=>'#id','action'=>'#action']) }}";

            var showQuestionnaireTaskUrl = "{{ route('show_questionnaire', ['id'=>'#id']) }}";
            var showUserUrl = "{{ route('show_student', ['id'=>'#id']) }}";

            $.post(submitUrl,  {
                "_token": submitToken,
                "term_id": termId,
                "review_status": reviewStatus,
                "text_search": textSearch ,
                "first_id": firstId
            }, function(data, status){
                var commentCard = $('#template_comment_card').clone();
                commentCard.attr('id', 'comment_card');
                commentCard.css('display','');
                var comments = data.comments;
                if ($('#review_status').val()==2){
                    $("#comments_count").text(data.count);
                } else if($('#review_status').val()==1){
                    $("#comments_count").text(data.approved_count+"/"+data.count);
                } else if ($('#review_status').val()==0){
                    $("#comments_count").text(data.rejected_count+"/"+data.count);
                }

                for(var i =0 ; i< comments.length; i++){
                    commentCard.clone().appendTo( "#comments" ).each(function () {

                        $(this).find('.comment_text').text(comments[i].comment);

                        $(this).find('.spy_action').attr("url", commentUrl.replace("#id", comments[i].id).replace("#action", "spy"));

                        $(this).find('.reject_action').attr("url", commentUrl.replace("#id", comments[i].id).replace("#action", "reject"));

                        $(this).find('.accept_action').attr("url", commentUrl.replace("#id", comments[i].id).replace("#action", "accept"));

                        if (comments[i].review_status==1)
                            $(this).find('.accept_action').css('display','none');
                        else if (comments[i].review_status==0)
                            $(this).find('.reject_action').css('display','none');

                        $(this).find(".comment_action").on('click', function (event) {
                            var actionElement = $(this);
                            $.post(
                                actionElement.attr('url'), {
                                    "_token": submitToken,
                                    "term_id": $('#term_id').val()
                                }, function (data) {

                                    if(data.action==1 && (actionElement.parents('#comment_card').find('div').text() != "Questionnaire, Student")) {
                                        actionElement.parents('#comment_card').append("<hr><div><a target='_blank' href='"+showQuestionnaireTaskUrl.replace('#id', data.questionnaire_task_id)+"'>Questionnaire</a>, <a target='_blank' href='"+showUserUrl.replace('#id', data.student_id)+"'>Student</a></div>");
                                    } else if(data.action==0 && data.update_count>1) {
                                        swal('Update '+data.update_count+' similer records.', {icon: "success"}).then(function(){
                                            var comments_count = parseInt($("#comments_count").text())-data.update_count;
                                            $("#comments_count").text(comments_count);
                                            $('#search_button').trigger('click');
                                        });
                                    }  else if(data.action==0 && data.update_count==1) {
                                        var comments_count = parseInt($("#comments_count").text())-data.update_count;
                                        $("#comments_count").text(comments_count);
                                        $('#search_button').trigger('click');
                                    } else if(data.action==0) {
                                        actionElement.parents('#comment_card').fadeOut('fast',null,function () {
                                            $(this).remove();
                                        });
                                    }
                                }, 'json'
                            );
                            event.preventDefault();
                        });

                        firstId = comments[i].id;
                    });
                }

                if(done)done(data.hasMore);
            }, 'json');
        }
        $(document).ready(function() {
            $('#search_button').on('click',function () {
                $('#show_more').hide();
                $('#search_button').attr('disabled','disabled');
                $('#reset_button').attr('disabled','disabled');
                firstId = null;
                $("#comments").html("");
                loadMoreCommnets(function(hasMore){
                    $('#search_button').removeAttr('disabled');
                    $('#reset_button').removeAttr('disabled');
                    if(hasMore)$('#show_more').fadeIn('fast');
                });
            });

            $('#text_search').keyup(function (e){
                if(e.keyCode == 13)
                    $('#search_button').trigger('click');
            });

            $('#reset_button').on('click',function () {
                $('#show_more').hide();
                $('#search_button').attr('disabled','disabled');
                $('#reset_button').attr('disabled','disabled');
                firstId = null;
                $("#comments").html("");
                $('#term_id').val("{{$currentTermID}}");
                $('#comment_status').val(2);
                $('#text_search').val("");
                $('#review_status').val(2);
                loadMoreCommnets(function(hasMore){
                    $('#search_button').removeAttr('disabled');
                    $('#reset_button').removeAttr('disabled');
                    if(hasMore)$('#show_more').fadeIn('fast');
                });
            });

            $('#search_button').trigger('click');

            $('#show_more').on('click', function () {
                $('#show_more').fadeOut('fast');
                loadMoreCommnets(function(hasMore){
                    if(hasMore)$('#show_more').fadeIn('fast');
                });
            });
        });
    </script>
@stop