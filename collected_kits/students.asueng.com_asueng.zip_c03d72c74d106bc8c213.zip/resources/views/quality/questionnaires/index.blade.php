@extends('layouts.master')

@section('title',  __('tr.Questionnaires') )
@section('subtitle', __('tr.Questionnaires Information') )
@section('titleicon', "icon-point-of-interest-outline" )

@section('advancedaction')
    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 mt-1">
        <div class="btn-group float-right">
            <div class="btn-group">
                <button type="button" class="btn btn-primary">@lang('tr.More')</button>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="sr-only">Toggle Dropdown</span>
                </button>
                <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-start" style="position: absolute; transform: translate3d(71px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                    @can('review_questionnaires')
                    <a class="dropdown-item" href="{{ route("review_comments") }}">@lang('tr.Review Comments')</a>
                    @endcan
                    @can('develop_system')
                    <a class="dropdown-item" href="{{ route("manage_questionnaires") }}">@lang('tr.Manage Questionnaires')</a>
                    @endcan
                </div>
            </div>
        </div>
    </div>
@stop

@section('content')

<?php
$statusBadges = [
	'badge-warning',
	'badge-danger',
	'badge-primary',
	'badge-info',
	'badge-secondary',
	'badge-success',
]
?>

<!-- BEGIN .main-content -->
<div class="main-content">
    
    <div class="card">
        <div class="card-body pb-0">
            <div class="row filter-box">
                {{--Term--}}
                <div class="col-md-2">
                    {!! Form::select('term_id', array(""=>__("tr.SelectTerm"))+$terms, $currentTermID, array('id'=> 'term_id', 'data-placement'=>'top', 'title'=> __('tr.Term'))) !!}
                </div>

                {{--By Law--}}
                <div class="col-md-2">
                    <select name="bylaw_id" id="bylaw_id">
                        <option value="">@lang('tr.Select Bylaw')</option>
                        @foreach($allBylaws as $item)
                            <option value="{{ $item->code }}">{{ $item->lang('name') }}</option>
                        @endforeach
                    </select>
                </div>

                {{--Offered From--}}
                <div class="col-md-2">
                    {!! Form::select('offering_department_id', array(""=>__("tr.OfferedBy"))+$departments, null, array('id'=> 'offering_department_id', 'data-placement'=>'top', 'title'=> __('tr.OfferedBy'))) !!}
                </div>

                {{--Offered To--}}
                <div class="form-group col-md-4">
                    @include('components.select_plan', ['bylaws'=>$bylaws, 'className'=>''])                                        
                </div>
                

                {{--Text search[en_name, ar_name, code]--}}
                <div class="col-md-2">
                    {{ Form::text('text_search', null, ['id'=>'text_search', 'data-placement'=>'top', 'title'=> __('tr.TextSearch'), 'placeholder'=>__('tr.TextSearch')]) }}
                </div>

                {{--Button--}}
                <div class="col-md-2 float">
                    <button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
                </div>

                {{--Button--}}
                <div class="col-md-2 float">
                    <button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
                </div>
            </div>
        </div>
    </div>

    <div id="term_statistics" class="row gutters">
        
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
            <div class="card" id="students">
                <div class="card-body">
                    
                    <div class="stats-widget">
                        <div class="stats-widget-header">
                            <i class="icon-users"></i>
                        </div>
                        <div class="stats-widget-body">
                            <!-- Row start -->
                            <ul class="row no-gutters">
                                <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                    <h6 class="blog-title">@lang('tr.Students')</h6>
                                </li>
                                <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                    <h4 class="total"></h4>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
            <div class="card" id="courses">
                <div class="card-body">
                    <div class="stats-widget">
                        <div class="stats-widget-header">
                            <i class="icon-file-text"></i>
                        </div>
                        <div class="stats-widget-body">
                            <!-- Row start -->
                            <ul class="row no-gutters">
                                <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                    <h6 class="blog-title">@lang('tr.Courses')</h6>
                                </li>
                                <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                    <h4 class="total"></h4>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> 

        </div>
    </div>

    <!-- TABLE -->
    <div class="card">
        <div class="card-header">
            <span id="term_name">@lang('tr.AllTerms')</span>
            <span id="term_action">
                @can('edit_questionnaires')
                    <a id="term_edit_action" class="btn stdf-btn  btn-sm float-right">
                        <span class="icon-edit"></span> @lang('tr.Update')
                    </a>
                @endcan
            </span>
        </div>

        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
            <div class="card-body">
                <table id="data_table" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>@lang('tr.CourseID')</th>
                            <th width="40%">@lang('tr.Course')</th>
                            <th>@lang('tr.Count')</th>
                            <th>@lang('tr.Score')</th>
                            <th>STD</th>
                            <th>@lang('tr.TermID')</th>
                            <th>@lang('tr.Term')</th>
                            <th>@lang('tr.DepartmentID')</th>
                            <th>@lang('tr.PlanID')</th>
                            <th>@lang('tr.Status')</th>
                            <th></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- END: .main-content -->

<script type="text/javascript">

    var showURL = '{{ route('show_questionnaire', ['id'=>'#id']) }}';
    var showCourseURL = '{{ route('show_course', ['id'=>'#id']) }}';

    $(document).ready(function() {

        $('#plan_id').selectize({
            plugins: ['remove_button'],
        });

        var table = $('#data_table').DataTable({
            processing: true,
            serverSide: true,
            scrollX: true,
            stateSave: false,
            rowId: 'id',
            "order": [[ 0, "desc" ]],
            "ajax": {
                "url": '{{ route('questionnaires') }}',
                "dataSrc": "data.data"
            },
            "columns": [
                { "data": "course_id", "name": "course_id", "visible": false },
                { "data": "course", "name": "course",
                    fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                        $(nTd).html("<a href='"+showCourseURL.replace('#id', oData.course_id)+"'>"+oData.course+"</a>");
                    }},
                { "data": "count", "name": "count",
                    fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                        $(nTd).html(""+oData.count+" Student");
                    }},
                { "data": "average_score", "name": "average_score",
                    fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                        if(oData.average_score!=null)$(nTd).html(""+oData.average_score+"%");
                    }},
                { "data": "stddev_score", "name": "stddev_score",
                    fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                        if(oData.stddev_score!=null)$(nTd).html("&PlusMinus;"+oData.stddev_score+"%");
                    }},
                { "data": "term_id", "name": "term_id", "visible": false },
                { "data": "term", "name": "term" },
                { "data": "offering_department_id", "name": "offering_department_id", "visible": false },
                { "data": "plan_id", "name": "plan_id", "visible": false },
                { "data": "questionnaire_publish_status", "name": "questionnaire_publish_status",
                    fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                        $(nTd).html((oData.questionnaire_publish_status)?"Published":"Draft");
                    }},
                { "data": "id", "name": "id",
                    fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                        var html = "";
                        @can('show_questionnaires')
                        html += "<a title='@lang('tr.View')' href='"+showURL.replace('#id', oData.id)+"'><i class='icon-eye'></i></i>"
                        @endcan
                        $(nTd).html("<span class='action-column'>"+html+"</a>");
                    }
                },
            ],
            "searchCols": [
                { "search": "{{ $currentTermID }}" },
            ]
        });

        function showStatistics(item, value) {
            item.find('.stats-label').css('display', 'none');
            item.find('.total').html(value);
        }

        table.on('xhr.dt', function ( e, settings, json, xhr ) {

            showStatistics($('#students'), json.students_count);
            showStatistics($('#courses'), json.courses_count);            
        });

        $(".dataTables_filter").hide();

        $('#search_button').on('click', function () {
            table.search($("#text_search").val());
            table.columns(0).search($("#term_id").val());
            table.columns(1).search($("#bylaw_id").val());
            table.columns(2).search($("#offering_department_id").val());
            table.columns(3).search($("#plan_id").val());            
            table.draw();
        } );

        $('#text_search').on('keyup', function (e){
            if(e.keyCode == 13)
                $('#search_button').trigger('click');
        });

        $('#reset_button').on('click', function () {
            $("#text_search").val("")
            $("#offering_department_id").val("");
            $("#plan_id")[0].selectize.clear();
            $("#term_id").val({{$currentTermID}});
            $("#bylaw_id").val("");
            $('#search_button').trigger('click');
        } );

         $('#term_id').on('change', function () {            
            if($(this).val()=="") {
                $("#term_action").hide();
                $("#term_statistics").hide();
                $("#term_name").text('@lang('tr.All')');
                $('#search_button').trigger('click');
            } else {
                $("#term_action").show();
                $("#term_statistics").show();
                $("#term_name").text($(this).find(":selected").text());
                var editLink = '{{ route('edit_term', ['id'=>'#term_id', 'section'=>'questionnaire']) }}';                
                $("#term_edit_action").attr('href', editLink.replace('#term_id', $(this).val()));
                $("#term_download_action").attr('term', $(this).val());
                $('#search_button').trigger('click');
            }
        });

        $('#term_download_action').on('click', function () {
            alert("Download all course files");
        });

        $('#term_id').trigger('change');
    });
</script>
@stop