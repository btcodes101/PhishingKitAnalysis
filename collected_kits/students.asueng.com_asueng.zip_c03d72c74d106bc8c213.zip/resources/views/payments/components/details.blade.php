@if(!empty($items))
<br>
<div class="card">
    <div class="card-header"><strong>@lang('tr.Payment Details')</strong></div>
    <div class="card-body">
        <table class="table">
            <thead >
                <tr>
                    <td><strong>@lang('tr.Item')</strong></td>
                    <td><strong>@lang('tr.Fees')</strong></td>
                </tr>
            </thead>
            @foreach($items as $item)
                <tr>
                    <td>@lang($item[0]) </td>
                    <td>{{$item[1] or ''}}</td>
                </tr>
            @endforeach
        </table>
    </div>
</div>
@endif