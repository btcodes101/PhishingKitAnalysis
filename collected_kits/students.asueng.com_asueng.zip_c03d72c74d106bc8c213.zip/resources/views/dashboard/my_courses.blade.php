@extends('layouts.master')

@section('title',__('tr.My Courses'))
@section('subtitle', __('tr.StudentCourses') )
@section('titleicon', "icon-user")

@section('content')
    <style>
        .eastLondonClass{
            float:'{{ right() }}';
            background-color: #1e8831;
            color: white;
            text-align: center;
            padding: 7px;
            height: 29px;
            line-height: 16px;
        }        
    </style>

    <div class="main-content">

        @if($student->hasPendingRequest())
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <div class="alert alert-danger">
                <i class="icon-flash"></i><strong>Warning!</strong> Dear student, it seems one or more courses is not registered yet, or you may have pending request. Please contact directly your <b>academic advisor</b> to get the approval. It is important to do this <b>as soon as possible</b>. For more details visit (<a href="{{ route('student_courses', ['id'=>$student->id]) }}" style="text-decoration: underline;">Courses Registration</a>) page under "My Services".
            </div>
        </div>
        @endif
        
        <div class="form-group row gutters">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        
                        <form method="get" action="{{route('my_courses')}}">
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <select class="form-control form-control-lg" name='years'>
                                        <option value="{{$selectedYears or __('tr.Select Year') }}">{{$selectedYears or __('tr.Select Year') }}</option>
                                        @foreach($years as $year)
                                            <option value='{{ $year->years }}'>{{$year->years}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">@lang('tr.Submit')</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>

        <div class="row gutters">
            @foreach ($studies as $study)            
            @php($examsCommittee = $study->exam())
            <div class="col-md-12">
                    <div class="card">
                        <div class="card-header"><span class="icon-file-text"></span>
                            <a href="{{ route('show_course', ['id'=>$study->course->id])."?committee_id=$study->committee_id" }}">{{ $study->course->short_name  }}: {{ $study->course->lang('name') }} ({{$study->term->lang('name')}})</a>
                            @if(in_array($study->course->id, $modulesCoursesIDs))
                            <span class="badge badge-success" style="float:right">@lang('tr.East London')</span>
                            @endif
                        </div>
                        <div class="card-body">
                            <div class="alert custom alert-info">
                                @if($examsCommittee)
                                <i class="icon-info-large"></i><strong style="color: green;">@lang('tr.Exam Date'): {{ $examsCommittee->examsDate->date()->format('d F Y') }}, {{$examsCommittee->examsDate->periodName($examsCommittee->period) }}, {{$examsCommittee->location->name}}, @lang('tr.BN') (#{{$study->exam_position}}), <a style="color: blue;" target="_blank" href="{{route('print_course_exam_details', ['examsCommittee'=> $study->id])}}">@lang('tr.Print')</a></strong>
                                @elseif($study->bn)
                                <i class="icon-info-large"></i><strong>@lang('tr.BN')</strong>: <strong>{{sprintf("%04d", $study->bn)}}</strong>
                                @endif
                            </div>
                            <p class="card-text">
                                <span class="badge-course"></span>
                                <span style="font-weight:bold;">Teacher(s):</span>
                                @php($committee_instructors = $study->committee->committeesInstructors)
                                @foreach ($committee_instructors as $committee_instructor)
                                    @if($committee_instructor->instructorProfileLink($committee_instructor->user->id) != '#')                                           
                                    <a href="{{ $committee_instructor->instructorProfileLink($committee_instructor->user->id) }}" target="_blank">{{ $committee_instructor->user->lang('name') }}</a><span style="font-weight:bold;font-size:15px;"> , </span>
                                    @else
                                    {{ $committee_instructor->user->lang('name') }}<span style="font-weight:bold;font-size:15px;"> , </span>
                                    @endif
                                @endforeach
                            </p>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection