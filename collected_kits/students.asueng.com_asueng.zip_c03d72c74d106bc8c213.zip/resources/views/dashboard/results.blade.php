@extends('layouts.master')

@section('title',  __('tr.Results'))
@section('subtitle', __('tr.Exam Results') )
@section('titleicon', "icon-file-text")

 

@section('content')
	<div class="main-content">
        
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">@lang('tr.Cumulative')</div>
                    <div class="card-body pb-0">
                        <div class="row filter-box">
                            
                            <div class="col-md-12">
                                <div class="card">
                                    @if(auth()->user()->student->isCreditHours())
                                        <div class="card-header" style='background:#d7dde4;'>
                                            @lang('tr.From') 
                                            <strong>{{ auth()->user()->student->lastPublishedGradeTerm()->first_term_name }}</strong>
                                            @lang('tr.To') 
                                            <strong>{{ auth()->user()->student->lastPublishedGradeTerm()->last_term_name }}</strong>
                                        </div>
                                    @endif
                                    <div class="card-body">
                                        <table style="width: 100%;" class='table-striped m-0'>
                                            <tbody>
                                                @if(auth()->user()->student->isCreditHours())
                                                    <tr>
                                                        <th scope="row" style="width: 50%;">@lang('tr.Passed Hours')</th>
                                                        <td>{{ auth()->user()->student->lastPublishedGradeTerm()->passed_hours }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" style="width: 50%;">@lang('tr.Cumulative GPA')</th>
                                                        <td>{{ auth()->user()->student->lastPublishedGradeTerm()->cumulative_gpa }}</td>
                                                    </tr>
                                                @elseif(!auth()->user()->student->isCreditHours())
                                                    <tr>
                                                        <th scope="row" style="width: 50%;">@lang('tr.Total')</th>
                                                        @if(auth()->user()->student->isGraduated())
                                                            <td>{{ auth()->user()->student->gradeTotal->total }}</td>
                                                        @else
                                                            <td> - </td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" style="width: 50%;">@lang('tr.Grade')</th>
                                                        @if(auth()->user()->student->isGraduated())
                                                            <td>{{ auth()->user()->student->gradeTotal->gerneralGrade->{lang('name')} }}</td>
                                                        @else
                                                            <td> - </td>
                                                        @endif
                                                    </tr>
                                                @endif
        
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                                                        
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body pb-0">
                <div class="row filter-box">
                    
                    <div class="form-group col-md-4">
                        <select name="term_id" id="term_id" class="form-control">
                            @foreach($terms as $row)
                                <option @if($row->id == $term->id) selected @endif data-url="{{route('show_exam_results', [$row->id])}}" value="{{$row->id}}">
                                    {{ $row->{lang('name')} }}
                                </option>
                            @endforeach
                        </select>
                    </div>  
                                                
                </div>
            </div>
        </div>

        

		<div class="card">
			<div class="card-header">{{$term->en_name}}</div>
			<div class="card-body">
				
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header" style='background:#d7dde4;'>@lang('tr.Total')</div>
                            <div class="card-body">
                                <table style="width: 100%;" class='table-striped m-0'>
                                    <tbody>

                                        @if(auth()->user()->student->isCreditHours())
                                            <tr>
                                                <th scope="row" style="width: 50%;">@lang('tr.Semester GPA')</th>
                                                @if(auth()->user()->student->gradesTerms()->where('term_id', $term->id)->first())
                                                    <td>{{ auth()->user()->student->gradesTerms()->where('term_id', $term->id)->first()->grade_gpa  }}</td>
                                                @else
                                                    <td> - </td>
                                                @endif
                                            </tr>
                                            <tr>
                                                <th scope="row" style="width: 50%;">@lang('tr.Credit Hours')</th>
                                                @if(auth()->user()->student->gradesTerms()->where('term_id', $term->id)->first())
                                                    <td>{{ auth()->user()->student->gradesTerms()->where('term_id', $term->id)->first()->credit_hours  }}</td>
                                                @else
                                                    <td> - </td>
                                                @endif
                                            </tr>
                                        @else
                                            <tr>
                                                <th scope="row" style="width: 50%;">@lang('tr.Year Grade')</th>
                                                @if(auth()->user()->student->gradesTerms()->where('term_id', $term->id)->first())
                                                    <td>{{ auth()->user()->student->gradesTerms()->where('term_id', $term->id)->first()->gradeType->en_name  }}</td>
                                                @else
                                                    <td> - </td>
                                                @endif
                                            </tr>
                                            <tr>
                                                <th scope="row" style="width: 50%;">@lang('tr.Year Mark')</th>
                                                @if(auth()->user()->student->gradesTerms()->where('term_id', $term->id)->first())
                                                    <td>{{ auth()->user()->student->gradesTerms()->where('term_id', $term->id)->first()->total  }}</td>
                                                @else
                                                    <td> - </td>
                                                @endif
                                            </tr>
                                        @endif                                     
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

				<div class="row">
                    @foreach($coursesDegreesData as $course)
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header" style='background:#d7dde4;'>{{$course['course_name']}}</div>
                                <div class="card-body">
                                    <table style="width: 100%;" class='table-striped m-0'>
                                        <tbody>
                                            <tr>
                                                <th scope="row" style="width: 50%;">@lang('tr.Code')</th>
                                                <td>{{ $course['short_name'] }}</td>
                                            </tr>
                                            @foreach($course['degrees'] as $degree)
                                                <tr>
                                                    <th scope="row">{{ $degree->label }}</th>
                                                    <td>
                                                        {{ ($degree->degree===null)?'-':$degree->degree }} / {{ $degree->max_value }}
                                                    </td>
                                                </tr>
                                            @endforeach
                                            @if($course['published'])
                                                <tr>
                                                    <th scope="row">@lang("tr.Total")</th>
                                                    <td>
                                                        {{ $course['grade_letter'] }}
                                                    </td>
                                                </tr>
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
			</div>
		</div>
			 
	</div>
    <script>
        $( document ).ready(function() {
            
            $('#term_id').on('change', function(){
                var url = $('#term_id').find(':selected').data('url');
                window.location.replace(url);
            })

        });
    </script>
@endsection

 