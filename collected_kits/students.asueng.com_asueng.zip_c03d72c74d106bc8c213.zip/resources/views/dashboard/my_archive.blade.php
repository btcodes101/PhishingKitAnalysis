@extends('layouts.master')

@section('title', __('tr.My Archive') )
@section('titleicon', "icon-tabs-outline" )
@section('content')
	<!-- BEGIN .main-content -->
    <div class="main-content">
        <div class="row gutters">
        @foreach($availableArchives as $archive)
            @if($archive->title == ('user_'.auth()->id()))
            <div class="col-md-3">
                <a href="{{ route('dashboard_show_archive',['archive'=>$archive->id]) }}" class="setting-box">
                    <div style="font-size: 120%;">@lang('tr.My Personal Archive')</div>
                    <div class="icon">
                        <span class="icon-folder"></span>
                    </div>
                </a>
            </div>
            @else
                <div class="col-md-3">
                    <a href="{{ route('dashboard_show_archive',['archive'=>$archive->id]) }}" class="setting-box">
                        <div style="font-size: 120%;">{{ ucfirst($archive->title) }}</div>
                        <div class="icon">
                            <span class="icon-folder"></span>
                        </div>
                    </a>
                </div>
            @endif
        @endforeach
        </div>
    </div>
    <!-- END: .main-content -->
@endsection

@section('pagejs')
	<script type="text/javascript">
		
		$(document).ready(function() {

		});
	</script>
@endsection
