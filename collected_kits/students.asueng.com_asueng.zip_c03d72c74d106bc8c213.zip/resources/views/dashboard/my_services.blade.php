@extends('layouts.master')
@section('title', __("tr.My Services"))
@section('titleicon', "icon-cog3" )

@section('content')
    <!-- BEGIN .main-content -->
    <div class="main-content">
        
        <div class="row gutters">
            <div class="col-xl-12 col-lg-6 col-md-6 col-sm-6">
                <div class="card">
                    <div class="card-header">@lang('tr.Student Services')</div>
                    
                    @if(Session::has('alert'))
                        <div class="card-header">
                            <div class="alert alert-danger" role="alert">
                               {{session()->pull('alert')[0]}}
                            </div>
                        </div>
                    @endif

                    <div class="card-body">
                        <ul class="stats">
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('edit_certificate_request') }}">@lang('tr.Request Certificate')</A>
                            </li>
                            
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('my_certificates_requests') }}">@lang('tr.Certificates Requests Status')</A>
                            </li>

                            @if($student->canApplyToQuestionnaire())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-file-text"></i>
                                </span>
                                <A href="{{ route('questionnaire_apply_index') }}">@lang('tr.Questionnaire')</A>
                            </li>
                            @endif

                            @if($student->canRegisterResearchPlan())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('edit_research') }}">@lang('tr.Register Research Plan')</A>
                            </li>
                            @endif

                            @if($student->canChangeTrack())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('change_track') }}">@lang('tr.Change Track Preferences')</A>
                            </li>
                            @endif

                            @if($student->canSelectTrack())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('select_track') }}">@lang('tr.Select Track Preferences')</A>
                            </li>
                            @endif

                            @if($student->canRegister())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('student_courses') }}">@lang('tr.Courses registration')</A>
                            </li>
                            @endif

                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('student_fees') }}">@lang('tr.Tuition Fees Payment')</A>
                            </li>

                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('student_credits') }}">@lang('tr.Charge my Credit')</A>
                            </li>


                            @if($student->canRequestGradesRecheck())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('std_apply_control_appeal') }}">@lang('tr.Grades Recheck Request')</A>
                            </li>                            
                            @endif
                            
                            @if($student->canChangeOnlineExamMethod())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('online_exams_method') }}">@lang('tr.Online Exams Method Confirmation')</A>
                            </li>
                            @endif
                            
                            @if($student->canApplyExamSpecialRequests())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('exam_special_requests') }}">@lang('tr.Final Exam Special Requests')</A>
                            </li>
                            @endif


                            @if($student->canAccessArchAptitudeTest())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <a href="javascript:void(0)" id="arch_aptitude_test">@lang('tr.Arch Aptitude Test')</a>
                               
                            </li>
                            @endif 
                            
                            @if($student->canTransferToSpecialized())
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <a href="javascript:void(0)" id="transfer_ip_to_sp">@lang('tr.Request to be transferred from Interdisciplinary Program to Specialized Programs')</a>
                               
                            </li>
                            @endif 

                            @if($student->canTransferToChep())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <a href="javascript:void(0)" id="transfer_sp_to_ip">@lang('tr.Request to be transferred from Specialized Program to Interdisciplinary Programs')</a>
                            </li>
                            @endif 
                            
                            @if($student->canApplyTakafulRequest())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <A href="{{ route('takaful') }}">@lang('tr.Financial Aid Request [Takaful]')</A>
                            </li>
                            @endif 
                            

                            @if($student->canTransfer())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <a href="{{ route('transfer_to_plan') }}" id="">@lang('tr.Transfer Between Programs')</a>
                               
                            </li>
                            @endif

                            @if($student->canApplyToExternalProgram())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <a href="{{ route('applyto_external_program') }}">@lang('tr.Apply to UEL')</a>
                            </li>
                            @endif
                            
                            @if($student->canMakeAdvisorQuestionnaire())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <a href="{{ route('advisor_questionnaire_index') }}">@lang('tr.Advisor Questionnaire')</a>
                            </li>
                            @endif

                            @if($student->hasGraduationSurvey())
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-cog3"></i>
                                </span>
                                <a href="{{ route('graduation_survey') }}">@lang('tr.Graduation Survey')</a>
                            </li>
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </div>
         
    </div>
    <!-- END: .main-content -->
@endsection

@section('pagejs')
    <script type="text/javascript">
        
        $(document).ready(function() {

            @if($student != null && $student->canAccessArchAptitudeTest())
            var cost = '{{\App\Setting::archAptitudeTestCost()}}';
            $('#arch_aptitude_test').on('click', function(){
               
                var message = "@lang('tr.Do you want to register in Arch aptitude test?') " + "@lang('tr.Please note that it will cost you :value EGP.', ['value' => \App\Setting::archAptitudeTestCost() ])";
                warningBox(message, function() {
                    window.location.href = '{{route('arch_aptitude_test_payment_confirmation')}}';
                });
            });
            @endif



            @if($student != null && $student->isChep())
            $('#transfer_ip_to_sp').on('click', function(){
               
                var message = "@lang('tr.transfer_ip_to_sp_txt')";
                var submitToken = '{{ csrf_token() }}';
                var url = '{{route('store_transfer_ip_to_sp_requests')}}';
                warningBox(message, function() {

                    $.post(url,{'_token': submitToken},function(data, status){
                
                        infoBox(data.msg);
                       
                    }).fail(function(error) {
                        var message = '@lang('tr.General Error')';
                        errorBox(message);
                    });
                });
            });
            @endif 
            
            @if($student != null && !$student->isChep())
            $('#transfer_sp_to_ip').on('click', function(){
               
                var message = "@lang('tr.Are you sure?')";
                var submitToken = '{{ csrf_token() }}';
                var url = '{{route('store_transfer_sp_to_ip_requests')}}';
                warningBox(message, function() {

                    $.post(url,{'_token': submitToken},function(data, status){ 
                        
                        if(data.state == 'success')
                            infoBox(data.msg);
                        else
                            errorBox(data.msg);
                       
                    }).fail(function(error) {
                        var message = '@lang('tr.General Error')';
                        errorBox(message);
                    });
                });
            });
            @endif


            @if($student != null && $student->firstTime())
            $('#financial_aid_request').on('click', function(e){

                e.preventDefault();

                var data = {"_token": '{{ csrf_token() }}'};

                data['en_name'] = '{{$user->en_name}}';
                data['request_type'] = 3;
                data['email'] = null;
                data['apply_to'] = 'Financial Aid [Takafol]';
                data['student_code'] = '{{$user->code}}';
                data['graduation_date'] = null;
                data['mobile'] = '{{$user->mobile}}';
                data['type'] = [19];
                data['quantity'] = [1];

                var submitUrl = "{{ route('save_certificate_request') }}";
                $.post(submitUrl, data,
                function (response) {
                        infoBox("@lang('tr.Please go to any fawry payment outlet and pay 10EGP for the reference number ##### at fawry pay')", function () {});
                }).fail(function (response) {
                    showRepsonseErrors(response);
                });

            });
            @endif

        });
    </script>
@endsection
