@extends('website.layouts.master')

@section('title', $website->title($page))

@section('pagecss')

@section('content')

@include('website.layouts.title')

<section>
    <div class="section-wrapper p-t-50 p-b-20">    
        <div class="container">
            <div class="row">
                <style type="text/css">
                    div.page div, div.page p, div.page li, div.page strong, div.page a {
                        font-size: 18px;
                    }

                    div.page li {
                        padding-top: 5px;
                    }
                    div.page ul, div.page ol {
                        padding-bottom: 20px;
                    }

                    div.page ul {
                        list-style: square;
                    }

                    div.page ol {
                        list-style: decimal;
                    }

                    div.page ul ul, div.page ol ul {
                        list-style: circle;
                    }

                    div.page ol ol, div.page ul ol {
                        list-style: decimal;
                    }

                    div.page ul {
                        padding-{{left()}}: 40px;
                    }
                </style>
                <div class="col-md-9 page">
                    @include('website.components.tree', ['parent'=>$page])
                </div>
                <div class="col-md-3">
                    <div class="au-widget">
                        @include('website.components.topics')
                        @include('website.components.news', ['style'=>2])
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection

@section('pagejs')

@endsection
