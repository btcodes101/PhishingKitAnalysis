<!-- Footer -->
<footer>
    <div class="footer-wrapper">
        <div class="footer-style-1">
            <div class="main-footer py-45">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="footer-item">
                                <div class="footer-title">
                                    <div class="logo">
                                        <img src="{{route('download_file', ['id'=>$website->asset('light_logo')->id])}}">
                                    </div>
                                </div>                                                              
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="footer-item">
                                <div class="footer-title">
                                    @lang('tr.Services')
                                </div>
                                <ul class="list-style">
                                @foreach($website->footerMenu() as $item)
                                    <li>
                                        <a href="{{ $website->resolve($item) }}">{{ shortText($item->locale->title, 15) }}</a>
                                    </li>
                                @endforeach
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="footer-item">
                                <div class="footer-title">
                                    @lang('tr.Contact Us')
                                </div>
                                <div class="footer-content">
                                    <p>@lang('tr.Address'): {{$website->value(lang('title'))}}</p>
                                    <p>@lang('tr.Email'): {{$website->value('email')}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sub-footer">
                <p>@lang('tr.Copyright') {{digits(2019)}} {{$website->value(lang('title'))}}, @lang('tr.Developed By') <a title="@lang('tr.ISC Info')">@lang('tr.ISC Unit')</a>.</p>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->
@php($news = $website->mainSection->findChildByShortName('news'))
<!-- Modal Search -->
<div class="modal fade" id="search-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="{{ $website->resolve($news) }}" method="GET">
                <input type="text" id="searchNewsTxt" placeholder="@lang('tr.Search News here')" name="search">
                <button type="submit" id="searchNewsTxt">
                    <i class="fa fa-search"></i>
                </button>
            </form>
        </div>
    </div>
</div>
