<head>
    <meta charset="UTF-8">
    <meta name="_token" content="{{ csrf_token() }}"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/png" href="{{route('download_file', ['id'=>$website->asset('icon')->id])}} ">
    <title>@yield('title')</title>

    <script src="/web/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="/web/vendor/bootstrap/css/bootstrap.min.css">

    <!-- Revolution Banner -->
    <link rel="stylesheet" href="/web/vendor/revolution/css/settings.css">
    <link rel="stylesheet" href="/web/vendor/revolution/css/layers.css">
    <link rel="stylesheet" href="/web/vendor/revolution/css/navigation.css">

    <!-- Fontawesome -->
    <link rel="stylesheet" href="/web/vendor/fontawesome/css/all.css">

    <!-- Carousel Slider -->
    <link rel="stylesheet" href="/web/vendor/owlcarousel/dist/css/owl.carousel.min.css">

    {{--Selectize--}}
    <link rel="stylesheet" href="/css/selectize.css">

    <!-- Theme -->
    @if( Lang::locale() == 'en' )
        <link rel="stylesheet" href="/web/css/theme.min.css">
    @elseif( Lang::locale() == 'ar' )
        <link rel="stylesheet" href="/web/css/theme.min.css">
        <link rel="stylesheet" href="/web/css/style-ar.css" />
    @endif

    <link rel="stylesheet" href="/web/css/website.css" />
    <link rel="stylesheet" href="/css/factory.css" />

    <link rel="stylesheet" href="/web/css/{{$website->value('theme')}}.css" />

    @yield('pagecss')
</head>
