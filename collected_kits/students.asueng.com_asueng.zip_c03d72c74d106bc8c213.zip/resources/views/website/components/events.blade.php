@if($events = $website->events())
<div class="section-title justify-content-start js-owl-nav-1">
    <h3 class="text-left">{{$events->locale->title}}
        @if(isEn())
        <span class="au-owl-prev">
            <i class="fa fa-angle-left"></i>
        </span>
        <span class="au-owl-next">
            <i class="fa fa-angle-right"></i>
        </span>
        @else
        <span class="au-owl-next">
            <i class="fa fa-angle-right"></i>
        </span>
        <span class="au-owl-prev">
            <i class="fa fa-angle-left"></i>
        </span>
        @endif
    </h3>
    <div class="title-border m-b-27"></div>
    <div class="owl-carousel" data-items="1" data-loop="true">
        @foreach($events->childrenFiles()->orderBy('created_at', 'DESC')->limit(5)->get() as $item)
        <div class="testimonial testi-style-1">
            <div class="testi-container">
                <div class="testi-content">
                    <p>{{$item->locale->description}}</p>
                </div>
                <div class="testi-author">
                    <div class="testi-author-image">
                        <img src="{{route('secure_download_file')."?sid=".$item->secret()}}" alt="Alex">
                    </div>
                    <div class="testi-author-content">
                        <a href="{{$item->url()}}" class="testi-author-name">{{$item->locale->title}}</a>
                        <p class="testi-author-job">{{$item->locale->sub_title}}</p>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif