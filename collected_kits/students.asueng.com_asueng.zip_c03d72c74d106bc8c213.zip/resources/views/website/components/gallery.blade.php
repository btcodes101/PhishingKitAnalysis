<link rel="stylesheet" href="/web/vendor/fancybox/css/jquery.fancybox.min.css">
    
<style type="text/css">
    .thumb{
        margin-bottom: 30px;
    }      
    img.zoom {
        width: 100%;
        height: 200px;
        border-radius:5px;
        object-fit:cover;
        -webkit-transition: all .3s ease-in-out;
        -moz-transition: all .3s ease-in-out;
        -o-transition: all .3s ease-in-out;
        -ms-transition: all .3s ease-in-out;
    }       
     
    .transition {
        -webkit-transform: scale(1.2); 
        -moz-transform: scale(1.2);
        -o-transform: scale(1.2);
        transform: scale(1.2);
    }
    .modal-header {
       
         border-bottom: none;
    }
    .modal-title {
        color:#000;
    }
    .modal-footer{
      display:none;  
    }
</style>
<div class="row">
    @foreach($page->children as $image)
    @if($image->isFile())
    <div class="col-lg-3 col-md-4 col-xs-6 thumb">
        <a href="{{route('download_file', ['id'=>$image->id])}}" class="fancybox" rel="ligthbox">
            <img  src="{{route('download_file', ['id'=>$image->id])}}" class="zoom img-fluid " alt="">
           <div class='text-right'>
                <small class='text-muted'>{{$image->locale->title}}</small>
            </div>
        </a>
    </div>
    @endif
    @endforeach
</div>

<script src="/web/vendor/fancybox/js/jquery.fancybox.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){

        $(".fancybox").fancybox({
            openEffect: "none",
            closeEffect: "none",
            type: 'image',
        });
        
        $(".zoom").hover(function(){            
            $(this).addClass('transition');
        }, function(){       
            $(this).removeClass('transition');
        });
    });
</script>
