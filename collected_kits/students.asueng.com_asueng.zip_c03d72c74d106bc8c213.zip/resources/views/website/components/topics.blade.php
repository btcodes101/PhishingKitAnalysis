@php($section = $website->section($page))
@if($section->short_name!="news")
@php($topics = $website->topics($section))
@if(count($topics)>1)
<div class="catalog">
    <div class="section-title justify-content-start">
        <h3 class="text-left">@lang('tr.Topics')</h3>
        <div class="title-border m-b-24"></div>
    </div>                        
    <ul>
    @foreach($topics as $topic)
        @if($topic->type == 2)
        <li style="font-size: 120%;">
                <i class="fa fa-angle-{{ left() }}" style="margin-top:8px;"></i>&nbsp;<a href="{{ route('download_file',$topic->id) }}">{{$topic->title}}</a></li>
        </li>
        @else
        <li style="font-size: 120%;">
            <a href="{{ $website->resolve($topic) }}">
                <i class="fa fa-angle-{{  left() }}" ></i>&nbsp;{{$topic->locale->title}}
            </a>
        </li>
        @endif
    @endforeach
    </ul>
</div>
@endif
@endif