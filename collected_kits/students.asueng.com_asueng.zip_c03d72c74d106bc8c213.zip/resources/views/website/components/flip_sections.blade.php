@if($data = $website->moduleSections('flip-sections', 3))

<section>
    <div class="section-wrapper">
        <div class="container py-50">
            <div class="row justify-content-center">
                @foreach($data->sections as $section)
                <div class="col-lg-4 col-md-8">
                    <div class="iconbox iconbox-style-1">
                        <div class="iconbox-container">
                            <div class="iconbox-image">
                                <img src="{{route('download_file', ['id'=>$section->id])}}">
                            </div>
                            <div class="iconbox-content">
                                <h4 class="iconbox-content-heading">
                                    <i class="fa fa-book"></i>
                                    {{$section->locale->title}}
                                </h4>
                                <div class="iconbox-content-body">
                                    <p>{{$section->locale->description}}</p>
                                    <a href="{{$section->url()}}">
                                        <i class="fa fa-plus-square"></i>@lang('tr.Read more')</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</section>

@endif