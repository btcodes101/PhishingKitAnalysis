@if($data = $website->moduleSections('announcement'))

<!-- Hire Us -->
<section>
    <div class="section-wrapper bg-gray">
        <div class="hire-us hire-us-style-1">
            <div class="container" style="padding: 20px 0px 20px 0px;">
                <div class="row">
                    <div class="col-md-7 d-flex align-items-center">
                        <div class="hire-us-container">
                            <div class="section-title">
                                <h3>{{$data->module->locale->title}}</h3>
                                <div class="title-border m-b-30"></div>
                            </div>
                            <div class="hire-us-text">
                                <p>{!!$data->message->locale->page()!!}</p>
                            </div>
                            @if(!empty($data->message->short_name))
                            <div class="hire-us-button">
                                <a href="{{$data->message->url()}}">{{$data->message->locale->title}}</a>
                            </div>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-5" style="text-align: center;">                        
                        <div class="hire-us-image" style="height: 100%">
                            <span style="display: inline-block;height: 100%;vertical-align: middle;"></span>
                            <img src="{{route('secure_download_file')."?sid=".$data->logo->secret()}}" style="max-height: 450px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Hire Us -->
@endif