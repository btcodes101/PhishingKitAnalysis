@if(!isset($style))
    @php($style = 1)
@endif

@if($news = $website->news())
<div class="section-title justify-content-start js-owl-nav-1">
    <h3 class="text-left"><a href="{{$website->resolve($news)}}">{{$news->locale->title}}</a>
        @if(isEn())
        <span class="au-owl-prev">
            <i class="fa fa-angle-left"></i>
        </span>
        <span class="au-owl-next">
            <i class="fa fa-angle-right"></i>
        </span>
        @else
        <span class="au-owl-next">
            <i class="fa fa-angle-right"></i>
        </span>
        <span class="au-owl-prev">
            <i class="fa fa-angle-left"></i>
        </span>
        @endif
    </h3>
    <div class="title-border m-b-10"></div>
    <div class="owl-carousel" data-items="1" data-loop="true">
        @foreach($news->childrenPages('created_at', 'DESC')->limit(5)->get() as $item)
        @php($image = $item->getPageImage())
        <div class="blog blog-style-{{$style}}">
            <div class="blog-container">
                @if($image)
                <div class="blog-image">
                    <div class="blog-image-container">
                        <img src="{{route('download_file', ['id'=>$image->id])}}" alt="Blog">
                    </div>
                </div>
                @endif
                <div class="blog-content">
                    <a href="{{$website->resolve($item)}}" class="blog-content-title">{{ $item->locale->title }}</a>
                    <p class="blog-content-text">{{ $item->locale->description }}</p>
                    <div class="blog-button">
                        <div class="blog-readmore">
                            <i class="fa fa-calendar-alt"></i>{{ newsDate($item->created_at) }}
                        </div>
                        <div class="blog-readmore">
                            <a href="{{$website->resolve($item)}}"><i class="fa fa-plus-square"></i>@lang('tr.Read more')</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif