<table style="width:100%; color: black; text-align: center;font-size: 11px;" cellpadding="4px" cellspacing="0px" border="1px">
	<tr style="background-color: #B4C6E7;">
		<td width="5%" rowspan="2">#</td>
		<td width="5%" rowspan="2">Lvl</td>
		<td width="10%" rowspan="2">Code</td>
		<td width="5%" rowspan="2">Course Title</td>
		<td width="5%" colspan="3">Credits and SWL</td>
		<td width="5%" colspan="4">Contact Hours</td>
		<td width="5%" colspan="4">Classification</td>
		<td width="5%" colspan="4">Assessment (%)</td>
		<td width="5%" colspan="2" rowspan="2">Prerequisites</td>
	</tr>
	<tr style="background-color: #B4C6E7;">
		<td width="5%">CH</td>
		<td width="5%">ECTS</td>
		<td width="5%">SWL</td>
		<td width="5%">Lec</td>
		<td width="5%">Tut</td>
		<td width="5%">Lab</td>
		<td width="5%">TT</td>
		<td width="5%">UR</td>
		<td width="5%">FR</td>
		<td width="5%">DR</td>
		<td width="5%">PR</td>
		<td width="5%">SA</td>
		<td width="5%">MT</td>
		<td width="5%">PE</td>
		<td width="5%">FE</td>
	</tr>
	@php($courseGroup="")
	@php($i=1)
	@foreach($website->departmentCourses($bylaw, $page->short_name) as $course)
		@if($course->group_name!=$courseGroup)
		<tr style="background-color: #F4B083;">
			<td colspan="21" style="text-align: left;">{{$course->group_name}}</td>
		</tr>
		@php($courseGroup=$course->group_name)
		@endif
		<tr>
			<td>{{$i}}</td>
			<td>{{$course->level}}</td>
			<td>{{str_replace("_", "", $course->short_name)}}</td>
			<td>{{$course->en_name}}</td>
			<td>{{$course->credit_hours}}</td>
			<td>{{$course->equivalent_ects}}</td>
			<td>{{$course->required_swl}}</td>
			<td>{{$course->final_lecture}}</td>
			<td>{{$course->final_tutorial}}</td>
			<td>{{$course->final_laboratory}}</td>
			<td>{{$course->totalHours()}}</td>
			<td>{{($course->isUR())?'x':''}}</td>
			<td>{{($course->isFR())?'x':''}}</td>
			<td>{{($course->isDR())?'x':''}}</td>
			<td>{{($course->isPR())?'x':''}}</td>
			<td>{{$course->max_activities}}</td>
			<td>{{$course->max_midterm}}</td>
			<td>{{$course->max_practical}}</td>
			<td>{{$course->max_final_exam}}</td>
			<td>{{str_replace("_", "", $course->prerequisites)}}</td>
		</tr>
	@endforeach
</table>
