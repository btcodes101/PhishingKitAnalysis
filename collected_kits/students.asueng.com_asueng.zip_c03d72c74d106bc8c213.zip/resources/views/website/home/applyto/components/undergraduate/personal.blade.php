<div class="thick_header">
    <h3>@lang('tr.Personal Information')</h3>
</div>

<hr>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.English Name') <span class="required_field">*</span></label>
            <input id="en_full_name" name="en_full_name" value="{{ field($applicant, 'en_full_name') }}" type="text" class="form-control" required maxlength="256" style="direction: ltr;" />
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Arabic Name') <span class="required_field">*</span></label>
            <input id="ar_full_name" name="ar_full_name" value="{{ field($applicant, 'ar_full_name') }}" type="text" class="form-control" required maxlength="256" style="direction: rtl;" />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Gender') <span class="required_field">*</span></label>
            {!! Form::select('gender', array(''=>__('tr.Select Gender'))+'App\User'::gendersLabels(), field($applicant, 'gender'), array('id'=> 'gender', 'class'=>'form-control', 'required' => 'required')) !!}
        </div>        
        <div class="col-lg-6">
            <label for="Email">@lang('tr.Email') <span class="required_field">*</span></label>
            <p style="display: block; width: 100%; padding: .375rem .75rem; font-size: 1rem; line-height: 1.5; color: #495057; background-color: #fff; background-clip: padding-box; border: 1px solid #ced4da; border-radius: .25rem; transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;">{{ field($applicant, 'email') }}</p>
            <input type="hidden" value="{{ field($applicant, 'email') }}" class="form-control"style="direction: ltr;" readonly />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Birthdate') <span class="required_field">*</span></label>
            <input type="date" id="birth_date" name="birth_date" class="form-control" required value="{{ field($applicant, 'birth_date') }}" max="2014-01-01" min="1950-01-01"/>
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Birth Place in Arabic') <span class="required_field">*</span></label>
            <input type="text" id="birth_place" name="birth_place" class="form-control"  required value="{{ dataField($applicant, 'birth_place') }}" style="direction: rtl;" />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Mobile') <span class="required_field">*</span></label>
            <input type="text" id="mobile" name="mobile" class="form-control" maxlength="16" value="{{ field($applicant, 'mobile') }}" maxlength="16" style="direction: ltr;" required  />
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Home Phone')</label>
            <input type="text" id="home_phone" name="home_phone"  class="form-control" value="{{ dataField($applicant, 'home_phone') }}" maxlength="16" style="direction: ltr;" />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-9">
            <label>@lang('tr.Home Address in Arabic') <span class="required_field">*</span></label>
            <input type="text" id="home_address" name="home_address" class="form-control" required value="{{ dataField($applicant, 'home_address') }}" placeholder="@lang('tr.Please Enter Address In Arabic')" maxlength="256" style="direction: rtl;" />
        </div>
       <div class="col-lg-3">
            <label>@lang('tr.Religion')<span class="required_field">*</span></label>
            {!! Form::select('religion', array(''=>__('tr.Select Religion'))+'App\User'::religionsLabels(), dataField($applicant, 'religion'), array('id'=> 'religion', 'class'=>'form-control', 'required'=>'required')) !!}
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Nationality') <span class="required_field">*</span></label>
            {!! Form::select('nationality_code', array(''=>__('tr.Select Nationality'))+'App\Applicant'::countries(), field($applicant, 'nationality_code'), array('id'=> 'nationality_code', 'class'=>'form-control', 'required'=>'required')) !!}
        </div>
    </div>
</div>


<div id="egyptian">
    <div class="thick_header">
        <h3>@lang('tr.Egyptian Student Information')</h3>
    </div>
    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-6">
                <label>@lang('tr.NationalID') <span class="required_field">*</span></label>
                <input type="text" id="national_id" name="national_id" class="form-control national_id_class" maxlength="14" value="{{ field($applicant, 'national_id') }}" required style="direction: ltr;" />
            </div>
            <div class="col-lg-6">
                <label>@lang('tr.Date Issues') <span class="required_field">*</span></label>
                <input type="date" id="national_id_issue_date" name="national_id_issue_date" class="form-control" required value="{{ dataField($applicant, 'national_id_issue_date') }}" max="2050-01-01" min="1950-01-01"/>
            </div>
        </div>
    </div>

    <div class="form-group" id="military_status_div">
        <label>@lang('tr.Military Service Status')<span class="required_field">*</span></label>
        {!! Form::select('military_status', array(''=>__('tr.Select Military Service Status'))+'App\Student'::militaryStatusLabels(), dataField($applicant, 'military_status'), array('id'=> 'military_status', 'class'=>'form-control','required' )) !!}
    </div>

    <div id="military_information_div">
        <div class="form-group">
            <div class="form-row">
                <div class="col-lg-6">
                    <label>@lang('tr.Military Number')</label>
                    <input type="text" id="military_no" name="military_no" class="form-control"  value="{{ dataField($applicant, 'military_no') }}" style="direction: ltr;" maxlength="128">
                </div>
                <div class="col-lg-6">
                    <label>@lang('tr.Military Order')</label>
                    <input type="text" id="military_order" name="military_order" class="form-control"  value="{{ dataField($applicant, 'military_order') }}" style="direction: ltr;"  maxlength="128">
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="form-row">
                <div class="col-lg-6">
                    <label>@lang('tr.Military Order Year/Month')</label>                
                    <input type="text" id="military_order_date" name="military_order_date" class="form-control"  value="{{ dataField($applicant, 'military_order_date') }}" style="direction: ltr;" maxlength="128">
                </div>
                <div class="col-lg-6">
                    <label>@lang('tr.Military Age')</label>                
                    <input type="text" id="military_age" name="military_age" class="form-control"  value="{{ dataField($applicant, 'military_age') }}" style="direction: ltr;"  maxlength="128">
                </div>
            </div>
        </div>
    </div>
</div>

<div id="foreign">
    <div class="thick_header">
        <h3>@lang('tr.Foreign Student Information')</h3>
    </div>
    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-6">
                <label>@lang('tr.Father Nationality') <span class="required_field">*</span></label>
                {!! Form::select('father_nationality', array(''=>__('tr.Select Nationality'))+'App\Applicant'::countries(), dataField($applicant, 'father_nationality'), array('id'=> 'father_nationality', 'class'=>'form-control', 'required'=>'required')) !!}
            </div>
            <div class="col-lg-6">
                <label>@lang('tr.Mother Nationality') <span class="required_field">*</span></label>
                {!! Form::select('mother_nationality', array(''=>__('tr.Select Nationality'))+'App\Applicant'::countries(), dataField($applicant, 'mother_nationality'), array('id'=> 'mother_nationality', 'class'=>'form-control', 'required'=>'required')) !!}
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-6">
                <label>@lang('tr.Passport Number') <span class="required_field">*</span></label>
                <input type="text" id="national_id" name="national_id" class="form-control passport_no" maxlength="32" value="{{ field($applicant, 'national_id') }}" required style="direction: ltr;" />
            </div>
            <div class="col-lg-6">
                <label>@lang('tr.Passport Type') <span class="required_field">*</span></label>
                {!! Form::select('passport_type', array(''=>__('tr.Select Passport Type'))+'App\Student'::passportsTypes(), dataField($applicant, 'passport_type'), array('id'=> 'passport_type', 'class'=>'form-control', 'required'=>'required')) !!}
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-6">
                <label>@lang('tr.Passport Issuer') <span class="required_field">*</span></label>
                <input type="text" id="passport_issuer" name="passport_issuer" class="form-control" value="{{ dataField($applicant, 'passport_issuer') }}" required maxlength="128" />
            </div>
            <div class="col-lg-6">
                <label>@lang('tr.Date Issues') <span class="required_field">*</span></label>
                <input type="date" id="national_id_issue_date" name="national_id_issue_date" class="form-control national_issue_date" required value="{{ dataField($applicant, 'national_id_issue_date') }}" max="2050-01-01" min="1977-01-01"/>
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-6">
                <label>@lang('tr.Residency Type') <span class="required_field">*</span></label>
                <input type="text" id="residency_type" name="residency_type" class="form-control" maxlength="14" value="{{ dataField($applicant, 'residency_type') }}" required />
            </div>
            <div class="col-lg-6" id="endDate">
                <label>@lang('tr.Residency End Date') <span class="required_field">*</span></label>
                <input type="date" id="residency_end_date" name="residency_end_date" class="form-control" required value="{{ dataField($applicant, 'residency_end_date') }}" max="2050-01-01" min="1977-01-01" />
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="form-row">
            <label>@lang('tr.Address at Home Country') <span class="required_field">*</span></label>
            <input type="text" id="address_at_home_country" name="address_at_home_country" class="form-control" required value="{{ dataField($applicant, 'address_at_home_country') }}" maxlength="256" />
        </div>
    </div>

</div>

<div class="thick_header">
    <h3>@lang('tr.Parent Information')</h3>
</div>

<div class="form-group">
    <label>@lang('tr.Parent Name')<span class="required_field">*</span></label>
    <input type="text" id="parent_name" name="parent_name" class="form-control" required value="{{ dataField($applicant, 'parent_name') }}" maxlength="256" />
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Parent Relation') <span class="required_field">*</span></label>
            {!! Form::select('parent_relation', array(''=>__('tr.Parent Relation'))+'App\Student'::getParentRelation(), dataField($applicant, 'parent_relation'), array('id'=> 'parent_relation', 'class'=>'form-control','required' )) !!}
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.National ID') <span class="required_field">*</span></label>
            <input type="text" id="parent_national_id" name="parent_national_id" class="form-control" required value="{{ dataField($applicant, 'parent_national_id') }}" maxlength="14" />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Phone') <span class="required_field">*</span></label>
            <input type="text" id="parent_phone" name="parent_phone" class="form-control" required value="{{ dataField($applicant, 'parent_phone') }}" maxlength="256" />
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Email') <span class="required_field">*</span></label>
            <input type="email" id="parent_email" name="parent_email" class="form-control" required value="{{ dataField($applicant, 'parent_email') }}" maxlength="256" />
        </div>
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function() {

        function updateControls() {

            if($("#nationality_code").val() == 'EG') {
                $('#egyptian').show();
                $('#egyptian :input').prop('disabled', false);
                $('#foreign').hide();
                $('#foreign :input').prop('disabled', true);
            } else if($("#nationality_code").val() != '') {
                $('#foreign').show();
                $('#foreign :input').prop('disabled', false);
                $('#egyptian').hide();
                $('#egyptian :input').prop('disabled', true);
            } else {
                $('#foreign').hide();
                $('#foreign :input').prop('disabled', true);
                $('#egyptian').hide();
                $('#egyptian :input').prop('disabled', true);
            }

            if($('#gender').val() == '1' && $('#nationality_code').val() == 'EG') {
                $('#military_status_div').show();
                $('#military_status_div :input').prop('disabled', false);
            } else {
                $('#military_status_div').hide();
                $('#military_status_div :input').prop('disabled', true);
            }

            if($('#gender').val() == '1' && $('#nationality_code').val() == 'EG' && $('#military_status').val() != ''){
                $('#military_information_div').show();
                $('#military_information_div :input').prop('disabled', false);
            } else {
                $('#military_information_div').hide();
                $('#military_information_div :input').prop('disabled', true);
            }

        }

        $('#gender').on('change', () => {
            updateControls();
        });
        
        $('#military_status').on('change', () => {
            updateControls();
        });

        $("#nationality_code").change(function () {            
            updateControls();
        });
        
        $("#military_status").trigger('change');
        $("#nationality_code").trigger('change');
        $("#gender").trigger('change');

    });
</script>