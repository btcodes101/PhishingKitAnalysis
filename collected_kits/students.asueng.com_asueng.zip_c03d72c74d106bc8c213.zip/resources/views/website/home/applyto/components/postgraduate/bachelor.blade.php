<div class="thick_header">
    <h3>@lang('tr.Graduation')</h3>
</div>
<hr>
<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Graduation Date') <span class="required_field">*</span></label>
            <input type="date" id="graduation_date" name="graduation_date" class="form-control" value="{{ dataField($applicant, 'graduation_date') }}" required max="<?php echo date('Y-m-d'); ?>" min="1977-01-01"/>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Graduation Grade') <span class="required_field">*</span></label>
            {!! Form::select('graduation_grade', array(''=>__('tr.Select Grade'))+'App\Applicant'::grades(), dataField($applicant, 'graduation_grade'), array('id'=> 'graduation_grade', 'class'=>'form-control', 'required' => 'required')) !!}
        </div>
    </div>
</div>

<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Graduation Project Name') <span class="required_field">*</span></label>
            <input type="text" id="graduation_project_name" name="graduation_project_name" class="form-control" value="{{dataField($applicant, 'graduation_project_name') }}" required maxlength="256" />
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Graduation Project Grade') <span class="required_field">*</span></label>
            {!! Form::select('graduation_project_grade', array(''=>__('tr.Select Grade'))+'App\Applicant'::grades(), dataField($applicant, 'graduation_project_grade'), array('id'=> 'graduation_project_grade', 'class'=>'form-control', 'required' => 'required')) !!}
        </div>           
    </div>
</div>
<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Department') <span class="required_field">*</span></label>
            <input id="graduation_department" name="graduation_department" type="text" class="form-control" value="{{dataField($applicant, 'graduation_department') }}" required maxlength="256" />
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Faculty') <span class="required_field">*</span></label>
            <input type="text" id="graduation_faculty" name="graduation_faculty" class="form-control" value="{{dataField($applicant, 'graduation_faculty') }}" required maxlength="256" />
        </div>
    </div>
</div>

<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.University')</label> <span class="required_field">*</span>
            {!! Form::select('graduation_university', array(''=>__('tr.Select University'))+'App\Applicant'::universities()+array('other'=>__('tr.Other')), dataField($applicant, 'graduation_university'), array('id'=> 'graduation_university', 'class'=>'form-control', 'required' => 'required')) !!}
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group" id="graduation_university_other_div">
            <label>@lang('tr.Other') <span class="required_field">*</span></label>
            <input type="text" id="graduation_university_other" name="graduation_university_other" class="form-control" value="{{dataField($applicant, 'graduation_university_other') }}" required maxlength="256" />
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#graduation_university").change(function () {
            if($(this).val() == 'other'){
                $('#graduation_university_other_div').show();
                $('#graduation_university_other').prop('disabled', false);
            } else {
                $('#graduation_university_other_div').hide();
                $('#graduation_university_other').prop('disabled', true);
            }
        });
        $("#graduation_university").trigger('change');
    });
</script>