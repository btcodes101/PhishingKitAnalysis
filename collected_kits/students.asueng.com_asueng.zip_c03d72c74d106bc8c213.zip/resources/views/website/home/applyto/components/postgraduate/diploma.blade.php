<div class="thick_header">
    <h3>@lang('tr.Diploma')</h3>
</div>

<hr/>

<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Diploma Name') </label>
            <input type="text" id="diploma_name" name="diploma_name" class="form-control" value="{{ dataField($applicant, 'diploma_name') }}" maxlength="256" />
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Date Obtained') </label>
            <input type="date" id="diploma_date_obtained" name="diploma_date_obtained" class="form-control" value="{{ dataField($applicant, 'diploma_date_obtained') }}" />
        </div>
    </div>
</div>
<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Grade')</label>
            {!! Form::select('diploma_grade', array(''=>__('tr.Select Grade'))+'App\Applicant'::grades(), dataField($applicant, 'diploma_grade'), array('id'=> 'diploma_grade', 'class'=>'form-control')) !!}
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Faculty') </label>
            <input type="text" id="diploma_faculty" name="diploma_faculty" class="form-control" value="{{ dataField($applicant, 'diploma_faculty') }}" maxlength="256" />
        </div>
    </div>
</div>

<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.University')</label></span>
            {!! Form::select('diploma_university', array(''=>__('tr.Select University'))+'App\Applicant'::universities()+array('other'=>__('tr.Other')), dataField($applicant, 'diploma_university'), array('id'=> 'diploma_university', 'class'=>'form-control')) !!}
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group" id="diploma_university_other_div">
            <label>@lang('tr.Other')</label>
            <input type="text" id="diploma_university_other" name="diploma_university_other" class="form-control" value="{{dataField($applicant, 'diploma_university_other') }}" maxlength="256" />
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#diploma_university").change(function () {
            if($(this).val() == 'other'){
                $('#diploma_university_other_div').show();
                $('#diploma_university_other').prop('disabled', false);
            } else {
                $('#diploma_university_other_div').hide();
                $('#diploma_university_other').prop('disabled', true);
            }
        });
        $("#diploma_university").trigger('change');
    });
</script>