<div class="thick_header">
    <h3>@lang('tr.Personal Information')</h3>
</div>

<hr>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.English Name') <span class="required_field">*</span></label>
            <input id="en_full_name" name="en_full_name" value="{{ field($applicant, 'en_full_name') }}" type="text" class="form-control" required maxlength="256" style="direction: ltr;" />
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Arabic Name') <span class="required_field">*</span></label>
            <input id="ar_full_name" name="ar_full_name" value="{{ field($applicant, 'ar_full_name') }}" type="text" class="form-control" required maxlength="256" style="direction: rtl;" />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Gender') <span class="required_field">*</span></label>
            {!! Form::select('gender', array(''=>__('tr.Select Gender'))+'App\User'::gendersLabels(), field($applicant, 'gender'), array('id'=> 'gender', 'class'=>'form-control', 'required' => 'required')) !!}
        </div>        
        <div class="col-lg-6">
            <label for="Email">@lang('tr.Email') <span class="required_field">*</span></label>
            
            <input type="email" value="{{ field($applicant, 'email') }}" class="form-control"style="direction: ltr;" readonly />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">

            <label>@lang('tr.Military Status')<span class="required_field">*</span></label>


            {!! Form::select('military_status', array(''=>__('tr.Select Military Status'))+'App\Student'::militaryStatusLabels(), dataField($applicant, 'military_status'), array('id'=> 'gender', 'class'=>'form-control', 'required' => 'required')) !!}
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Job')</label>
            <input type="text" id="job" name="job" class="form-control" value="{{ dataField($applicant, 'job') }}" maxlength="256" />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Work Place')</label>
            <input type="text" id="work_place" name="work_place" class="form-control" value="{{ dataField($applicant, 'work_place') }}" maxlength="256" />
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Work Phone')</label>
            <input type="text" id="work_phone" name="work_phone" class="form-control" value="{{ dataField($applicant, 'work_phone') }}" maxlength="16" style="direction: ltr;" />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Marital Status')<span class="required_field">*</span></label>
            {!! Form::select('marital_status', array(''=>__('tr.Select Marital Status'))+'App\User'::maritalStatusLabels(), dataField($applicant, 'marital_status'), array('id'=> 'marital_status', 'class'=>'form-control', 'required'=>'required')) !!}
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Religion')<span class="required_field">*</span></label>
            {!! Form::select('religion', array(''=>__('tr.Select Religion'))+'App\User'::religionsLabels(), dataField($applicant, 'religion'), array('id'=> 'religion', 'class'=>'form-control', 'required'=>'required')) !!}
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Birthdate') <span class="required_field">*</span></label>
            <input type="date" id="birth_date" name="birth_date" class="form-control" required value="{{ field($applicant, 'birth_date') }}"  max="2014-01-01" min="1950-01-01"/>
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Birthplace') <span class="required_field">*</span></label>
            <input type="text" id="birth_place" name="birth_place" class="form-control"  required value="{{ dataField($applicant, 'birth_place') }}" />
        </div>
    </div>
</div>

<div class="form-group">
    <div class="form-row">
        <div class="col-lg-6">
            <label>@lang('tr.Mobile') <span class="required_field">*</span></label>
            <input type="text" id="mobile" name="mobile" class="form-control" maxlength="16" value="{{ field($applicant, 'mobile') }}" maxlength="16" style="direction: ltr;" required  />
        </div>
        <div class="col-lg-6">
            <label>@lang('tr.Home Phone')</label>
            <input type="text" id="home_phone" name="home_phone"  class="form-control" value="{{ dataField($applicant, 'home_phone') }}" maxlength="16" style="direction: ltr;" />
        </div>
    </div>
</div>

<div class="form-group">
    <label>@lang('tr.Home Address') </label>
    <input type="text" id="home_address" name="home_address" class="form-control" value="{{ dataField($applicant, 'home_address') }}" maxlength="256" />
</div>

<div class="form-group">
    <label>@lang('tr.Nationality') <span class="required_field">*</span></label>
    {!! Form::select('nationality_code', array(''=>__('tr.Select Nationality'))+'App\Applicant'::countries(), field($applicant, 'nationality_code'), array('id'=> 'nationality_code', 'class'=>'form-control', 'required'=>'required')) !!}
</div>

<div id="egyptian">
    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-6">
                <label>@lang('tr.NationalID') <span class="required_field">*</span></label>
                <input type="text" id="national_id" name="national_id" class="form-control national_id_class" maxlength="14" value="{{ field($applicant, 'national_id') }}" required style="direction: ltr;" />
            </div>
            <div class="col-lg-6">
                <label>@lang('tr.Date Issues') <span class="required_field">*</span></label>
                <input type="date" id="national_id_issue_date" name="national_id_issue_date" class="form-control" required value="{{ dataField($applicant, 'national_id_issue_date') }}" required max="2050-01-01" min="1977-01-01"/>
            </div>
        </div>
    </div>
</div>

<div id="foreign">
    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-4">
                <label>@lang('tr.Father Nationality') <span class="required_field">*</span></label>
                {!! Form::select('father_nationality', array(''=>__('tr.Select Nationality'))+'App\Applicant'::countries(), dataField($applicant, 'father_nationality'), array('id'=> 'father_nationality', 'class'=>'form-control', 'required'=>'required')) !!}
            </div>
            <div class="col-lg-4">
                <label>@lang('tr.Mother Nationality') <span class="required_field">*</span></label>
                {!! Form::select('mother_nationality', array(''=>__('tr.Select Nationality'))+'App\Applicant'::countries(), dataField($applicant, 'mother_nationality'), array('id'=> 'mother_nationality', 'class'=>'form-control', 'required'=>'required')) !!}
            </div>
            <div class="col-lg-4">
                <label>@lang('tr.Spouse Nationality')</label>
                {!! Form::select('spouse_nationality', array(''=>__('tr.Select Nationality'))+'App\Applicant'::countries(), dataField($applicant, 'spouse_nationality'), array('id'=> 'spouse_nationality', 'class'=>'form-control')) !!}
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-6">
                <label>@lang('tr.Passport Number') <span class="required_field">*</span></label>
                <input type="text" id="national_id" name="national_id" class="form-control passport_no" maxlength="32" value="{{ field($applicant, 'national_id') }}" required style="direction: ltr;" />
            </div>
            <div class="col-lg-6">
                <label>@lang('tr.Passport Type') <span class="required_field">*</span></label>
                <input type="text" id="passport_type" name="passport_type" class="form-control" required value="{{ dataField($applicant, 'passport_type') }}" maxlength="128" />
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-6">
                <label>@lang('tr.Passport Issuer') <span class="required_field">*</span></label>
                <input type="text" id="passport_issuer" name="passport_issuer" class="form-control" value="{{ dataField($applicant, 'passport_issuer') }}" required maxlength="128" />
            </div>
            <div class="col-lg-6">
                <label>@lang('tr.Date Issues') <span class="required_field">*</span></label>
                <input type="date" id="national_id_issue_date" name="national_id_issue_date" class="form-control" required value="{{ dataField($applicant, 'national_id_issue_date') }}" required max="2050-01-01" min="1977-01-01"/>
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="form-row">
            <div class="col-lg-6">
                <label>@lang('tr.Residency Type') <span class="required_field">*</span></label>
                <input type="text" id="residency_type" name="residency_type" class="form-control" maxlength="14" value="{{ dataField($applicant, 'residency_type') }}" required />
            </div>
            <div class="col-lg-6">
                <label>@lang('tr.Residency End Date') <span class="required_field">*</span></label>
                <input type="date" id="residency_end_date" name="residency_end_date" class="form-control" required value="{{ dataField($applicant, 'residency_end_date') }}" required max="2050-01-01" min="1977-01-01"/>
            </div>
        </div>
    </div>

    <div class="form-group">
        <label>@lang('tr.Address at Home Country') <span class="required_field">*</span></label>
        <input type="text" id="address_at_home_country" name="address_at_home_country" class="form-control" required value="{{ dataField($applicant, 'address_at_home_country') }}" maxlength="256" />
    </div>

</div>


<script type="text/javascript">
    $(document).ready(function() {

        $("#nationality_code").change(function () {
            if($(this).val() == 'EG'){
                $('#egyptian').show();
                $('#egyptian input').prop('disabled', false);
                $('#egyptian select').prop('disabled', false);
                $('#foreign').hide();
                $('#foreign input').prop('disabled', true);
                $('#foreign select').prop('disabled', true);
            } else {
                $('#foreign').show();
                $('#foreign input').prop('disabled', false);
                $('#foreign select').prop('disabled', false);
                $('#egyptian').hide();
                $('#egyptian input').prop('disabled', true);
                $('#egyptian select').prop('disabled', true);
            }
        });

        $("#nationality_code").trigger('change');        
    });
</script>