
<div class="thick_header">
    <h3>@lang('tr.Personal Information')</h3>
</div>

<hr>

<div class="form-group">
    <label>@lang('tr.English Name') <span class="required_field">*</span></label>
    <input type="text" class="form-control" name="en_full_name" placeholder="@lang('tr.Full english name')" required style="direction: ltr;" maxlength="256" value="{{ field($applicant, 'en_full_name') }}">
</div>
<div class="form-group">
    <label>@lang('tr.Arabic Name') <span class="required_field">*</span></label>
    <input type="text" class="form-control" name="ar_full_name" placeholder="@lang('tr.Full arabic name')" maxlength="256" style="direction: rtl;" value="{{ field($applicant, 'ar_full_name') }}" required>
</div>
<div class="form-group">
    <label>@lang('tr.Gender') <span class="required_field">*</span></label>
    {!! Form::select('gender', array(''=>__('tr.Select Gender'))+'App\User'::gendersLabels(), field($applicant, 'gender'), array('id'=> 'gender', 'class'=>'form-control', 'required' => 'required')) !!}
</div>
<div class="form-group">
    <label>@lang('tr.Address')</label>
    <textarea class="form-control" name="address" placeholder="@lang('tr.Address')" maxlength="512">{{ field($applicant, 'address') }}</textarea>
</div>
<div class="form-group">
    <label>@lang('tr.Email') <span class="required_field">*</span></label>
    <input type="email" value="{{ field($applicant, 'email') }}" class="form-control"style="direction: ltr;" readonly />
</div>

<div class="form-group">
    <label>@lang('tr.Mobile Number') <span class="required_field">*</span></label>
    <input type="phone" class="form-control" name="mobile" id="mobile" placeholder="Personal Mobile: +20 1111 22 33 22" required maxlength="32" style="direction: ltr;"  value="{{ field($applicant, 'mobile') }}">
</div>
<div class="form-group">
    <div class="form-row">
        <div class="col-md-6">
            <label>@lang('tr.Birthdate') <span class="required_field">*</span></label>
            <input type="date" class="form-control" name="birth_date" placeholder=">@lang('tr.BirthDate')" required value="{{ field($applicant, 'birth_date') }}" max="2014-01-01" min="1950-01-01">
        </div>                            
        <div class="col-md-6">
            <label>@lang('tr.Nationality') <span class="required_field">*</span></label>
            {!! Form::select('nationality_code', array(''=>__('tr.Select Nationality'))+'App\Applicant'::countries(), 'EG', array('id'=> 'nationality_code', 'class'=>'form-control', 'required'=>'required')) !!}
        </div>
    </div>
</div>
<div class="form-group">
    <div class="form-row">
        <label>@lang('tr.National ID') <span class="required_field">*</span></label>
        <input type="text" class="form-control" name="national_id" placeholder="@lang('tr.National ID')" required value="{{ field($applicant, 'national_id') }}" maxlength="14"  id="pin" pattern="\d{14}" title="14 numeric digits" style="direction: ltr;" >
    </div>
</div>

@php( $governorates = 'App\Governorate'::pluck(lang().'_name', 'id')->toArray() )
<div class="form-group">
    <label>@lang('tr.Governorate') <span class="required_field">*</span></label>
    <div class="form-row">
        <div class="form-group col-md-6">
            {!! Form::select('governorate', array(''=>__('tr.Select Governorate'))+$governorates+array('other'=>__('tr.Other')), dataField($applicant, 'governorate'), array('id'=> 'governorate', 'class'=>'form-control', 'required' => 'required')) !!}
        </div>
        <div class="form-group col-md-6" style="display: {{(isset($applicant->data->governorate) && $applicant->data->governorate=='other')?"":"none"}};" id="governorate_other_div">
            <input type="text" class="form-control" name="governorate_other"  placeholder="@lang('tr.Other Governorate?')" maxlength="256" value="{{ dataField($applicant, 'governorate_other') }}">
        </div>
    </div>
</div>
<div class="form-group">    
    <div class="form-row">
        <div class="col-md-6">
            <label>@lang('tr.University') <span class="required_field">*</span></label>
            {!! Form::select('university', array(''=>__('tr.Select University'))+'App\Applicant'::universities()+array('other'=>__('tr.Other')), dataField($applicant, 'university'), array('id'=> 'university', 'class'=>'form-control', 'required' => 'required')) !!}
        </div>
        <div class="col-md-6" style="display: {{(isset($applicant->data->university) && $applicant->data->university=='other')?"":"none"}};" id="university_other_div">
            <label>@lang('tr.Other University')</label>
            <input type="text" class="form-control" name="university_other" placeholder="@lang('tr.Other University')" maxlength="256" value="{{ dataField($applicant, 'university_other') }}">
        </div>
    </div>
</div>
<div class="form-group">
    <div class="form-row">
        <div class="col-md-6">
            <label>@lang('tr.Faculty') <span class="required_field">*</span></label>
            <input type="text" class="form-control" name="faculty" placeholder="@lang('tr.Faculty')" maxlength="256" value="{{ dataField($applicant, 'faculty') }}" required>
        </div>
        <div class="col-md-6">
            <label>@lang('tr.Student Code') <span class="required_field">*</span></label>
            <input type="text" class="form-control" name="student_code" id="student_code" placeholder="@lang('tr.Student Code')" maxlength="256" value="{{ dataField($applicant, 'student_code') }}" required>
        </div>
    </div>
</div>
<div class="form-group">
    <label>How did you know about this scholarship? <span class="required_field">*</span></label>
    <input type="text" class="form-control" name="how_did_you_know" id="how_did_you_know" placeholder="Please specify ..." maxlength="512" value="{{ dataField($applicant, 'how_did_you_know') }}" required >
</div>

<br><br>

<script type="text/javascript">
    $(document).ready(function() {

        $('#governorate').on('change',function () {

            if ($('#governorate').val() == 'other') {
                $('#governorate_other_div').show();
            } else {
                $('#governorate_other_div').hide();
            }
        });

        $('#university').on('change',function () {

            if ($('#university').val() == 'other') {
                $('#university_other_div').show();
            } 
            else {
                $('#university_other_div').hide();
            }
        });

    });

</script>