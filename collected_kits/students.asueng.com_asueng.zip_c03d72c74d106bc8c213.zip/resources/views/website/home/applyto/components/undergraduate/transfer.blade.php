<div class="thick_header">
    <h3>
        @lang('tr.Transfer Information')
        <br/>
        <small style="font-size: 15px;"> @lang('tr.Transfer Information Hint')</small>
    </h3>
    
</div>
<hr>
<div class="form-row">
    <div class="col-lg-3">
        <div class="form-group">
            <label>@lang('tr.Status') <span class="required_field">*</span></label>
            {!! Form::select('transfer_status', array(''=>__('tr.Select Status'))+'App\Student'::transferTypes(), dataField($applicant, 'transfer_status'), array('id'=> 'school_study_type', 'class'=>'form-control', 'required' => 'required')) !!}            
        </div>
    </div>
    <div class="col-lg-3">
        <div class="form-group">
            <label>@lang('tr.Department')</label>
            <input type="text" class="form-control" id="transfer_from_department" name="transfer_from_department" value="{{ dataField($applicant, 'transfer_from_department') }}">
        </div>
    </div>
    <div class="col-lg-3">
        <div class="form-group">
            <label>@lang('tr.Faculty')</label>
            <input type="text" class="form-control" id="transfer_from_faculty" name="transfer_from_faculty" value="{{ dataField($applicant, 'transfer_from_faculty') }}">
        </div>
    </div>
    <div class="col-lg-3">
        <div class="form-group">
            <label>@lang('tr.University')</label>
            <input type="text" class="form-control" id="transfer_from_university" name="transfer_from_university" value="{{ dataField($applicant, 'transfer_from_university') }}">
        </div>
    </div>    
</div>


<script type="text/javascript">
    $(document).ready(function() {        
    });
</script>