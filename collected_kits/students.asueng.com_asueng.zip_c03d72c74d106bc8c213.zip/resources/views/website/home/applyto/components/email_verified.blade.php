@if($applicant->isDraft())
    <div class="alert alert-success" style="margin-top: 50px; width: 100%;">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
        <i class="icon-tick"></i>@lang("tr.Your email is verified")
    </div>
@else
    <br/>
    <br/>
@endif