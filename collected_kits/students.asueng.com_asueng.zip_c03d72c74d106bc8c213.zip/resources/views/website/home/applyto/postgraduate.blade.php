@extends('website.layouts.master')
@section('title', $applicant->applicantType->lang('name'))

@section('content')

@include('website.layouts.title', ['simple'=>true])

<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-9">

                @include('website.home.applyto.components.email_verified')

                <form id="submit_form"  autocomplete="off" action="{{ route('save_applicant', ['type'=>'postgraduate', 'id'=>$applicant->id]) }}" method="POST" enctype="multipart/form-data">
                    {{ csrf_field() }}

                    <div style="border: 1px solid #dadada; padding: 20px;">

                        @include('website.home.applyto.components.postgraduate.personal')
                        @include('website.home.applyto.components.postgraduate.bachelor')
                        @include('website.home.applyto.components.postgraduate.diploma')
                        @include('website.home.applyto.components.postgraduate.master')
                        @include('website.home.applyto.components.postgraduate.admission')
                        @include('system.components.documents', ['fileTypes'=>$applicant->fileTypes(), 'archive'=>$applicant->archive])
                        @include('website.home.components.feedback')

                    </div>

                    @if($applicant->canUpdate())
                        @include('system.components.submit', ['isNew'=>$applicant->isNew()])
                    @elseif($applicant->status == \App\Applicant::STATUS_ACCEPTED && $applicant->payment_status != 'PAID' && $applicant->payment_status != 'EXEMPTED')
                        @if(isJson($userRequest->data))
                            @include('payments.components.details', ['items'=> json_decode($userRequest->data)])
                        @endif
                        @include('payments.components.pay')
                    @endif

                    <br/>

                </form>
            </div>

            <div class="col-lg-3">
                <div style="margin-top:50px;"></div>
                @include('website.components.news', ['style'=>2])
            </div>
        </div>
    </div>
</section>

@endsection
@section('pagejs')
<script>
    if({{$userRequest}} != null){
        console.log({{$userRequest}});
        // if({{$userRequest->type}} == "postgrad_admission_fees")
	    //     $("#pay_with_student_credit").remove();
    }
	
</script>
@endsection