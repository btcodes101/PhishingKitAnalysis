@extends('website.layouts.master')
@section('title', __('tr.View Certificates Request'))

@section('content')

@include('website.layouts.title', ['simple'=>true])

<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <br/>
                <br/>
                <h3>@lang('tr.General Information')</h3>
                <hr/>
                <div class="alert alert-warning">@lang('tr.Status'): {{ $userRequest->order_status }}</div>
                <table class="table table-striped m-0">
                    <tr><td width="150px"><b>@lang('tr.English Name'):</b></td><td>{{$userRequest->data->en_name}}</td></tr>
                    <tr><td width="150px"><b>@lang('tr.Arabic Name'):</b></td><td>{{$userRequest->data->ar_name}}</td></tr>
                    <tr><td><b>@lang('tr.Email'):</b></td><td>{{$userRequest->data->email}}</td></tr>
                    <tr><td><b>@lang('tr.Mobile'):</b></td><td>{{$userRequest->data->mobile}}</td></tr>
                    <tr><td><b>@lang('tr.Graduation Date'):</b></td><td>{{$userRequest->data->graduation_date}}</td></tr>
                    <tr><td><b>@lang('tr.Student Code'):</b></td><td>{{$userRequest->data->student_code}}</td></tr>
                    <tr><td><b>@lang('tr.Student Program'):</b></td><td>{{ $userRequest->data->{lang('plan')} }}</td></tr>
                    <tr>
                        <td><b>@lang('tr.Documents'):</b></td>
                        <td>
                            @foreach($userRequest->archive->childrenFiles as $file)
                                <a href="{{ route('secure_download_file')."?sid=".$file->secret() }}">{{$file->name()}}</a>, 
                            @endforeach
                        </td>
                    </tr>
                </table>
                <br/>
                <h3>@lang('tr.Certificates')</h3>
                <table id='certificates_table' class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>@lang('tr.Certificate Type')</th>
                            <th width="5%">@lang('tr.Count')</th>
                            <th width="5%">@lang('tr.Cost')</th>
                            <th width="10%">@lang('tr.Total')</th>
                            <?php $student_certificates = \DB::select('SELECT * FROM students_certificates WHERE request_id ='.$userRequest->id); ?>
                            
                            <?php
                            if(count($student_certificates) > 0){
                            ?>
                            <th>@lang('tr.Status')</th>
                            <th>@lang('tr.Feedback')</th>
                            <?php
                            }
                            ?>
                        </tr>
                    </thead>
                    <tbody>
                        @php($j = 1)
                        @php($total = 0)
                        @for($i=0; $i<count($userRequest->data->type); $i++)
                        @if($userRequest->data->quantity[$i]>0)
                        @php($certificateType = 'App\CertificateType'::find($userRequest->data->type[$i]))
                        @php($total+=$certificateType->cost*$userRequest->data->quantity[$i])
                        <tr>
                            <td width="5%">{{ $j++ }}</td>
                            <td width="20%">{{ $certificateType->lang('name') }}</td>
                            <td width="5%">{{ $userRequest->data->quantity[$i] }}</td>
                            <td width="5%">{{ $certificateType->cost }}</td>
                            <td width="5%">{{ $certificateType->cost*$userRequest->data->quantity[$i] }}</td>
                            
                            <?php
                            
                            if(count($student_certificates) > 0){
                                foreach($student_certificates as $student_certificate){
                                    if($student_certificate->certificate_type_id == $certificateType->id){
                                        if ($student_certificate->status == 'App\StudentCertificate'::STATUS_READY){
                                            echo '<td width="25%"><span style="padding: 0.4em 1em 0.4em 1em; border-radius: 0; font-weight: 400; font-size: .75rem; background-color: green; color: white; border: 1px solid green;">'.__("tr.Ready to Deliver Manually").'</span></td>';
                                            echo '<td width="30%"><span></span></td>';
                                            break;
                                        }
                                        if($student_certificate->status == 'App\StudentCertificate'::STATUS_NEED_UPDATE){
                                            echo '<td width="25%"><span style="padding: 0.4em 1em 0.4em 1em; border-radius: 0; font-weight: 400; font-size: .75rem; background-color: #d49814; color: white; border: 1px solid #d49814;">'.__("tr.Need Update").'</span></td>';
                                            echo '<td width="30%"><span>'.$student_certificate->notes.'</span></td>';
                                            break;
                                        }
                                        if($student_certificate->status == 'App\StudentCertificate'::STATUS_REJECTED){
                                            echo '<td width="25%"><span style="padding: 0.4em 1em 0.4em 1em; border-radius: 0; font-weight: 400; font-size: .75rem; background-color: #da3333; color: white; border: 1px solid #da3333;">'.__("tr.Rejected").'</span></td>';
                                            echo '<td width="30%"><span>'.$student_certificate->notes.'</span></td>';
                                            break;
                                        }
                                        if ($student_certificate->status == 'App\StudentCertificate'::STATUS_SUBMIT_BY_MAIL){
                                            echo '<td width="25%"><span title="Address: '.$userRequest->data->mail_address.'" style="padding: 0.4em 1em 0.4em 1em; border-radius: 0; font-weight: 400; font-size: .75rem; background-color: green; color: white; border: 1px solid green;">'.__("tr.Ready to Deliver by Mail").'</span></td>';
                                            echo '<td width="30%"><span></span></td>';
                                            break;
                                        }
                                        else{
                                            echo '<td width="25%"><span style="padding: 0.4em 1em 0.4em 1em; border-radius: 0; font-weight: 400; font-size: .75rem; background-color: #065f9f; color: white; border: 1px solid #065f9f;">'.__("tr.inprogress").'</span></td>';
                                            echo '<td width="30%"><span></span></td>';
                                            break;
                                        }
                                    }
                                    
                                }
                            }
                            
                            ?>  

                        </tr>
                        @endif
                        @endfor
                    </tbody>
                </table>
                <div><b>@lang('tr.Total')</b>: {{$total}} @lang('tr.Egyptian Pound')</div>
                <br/>
                <hr/>
                <a href="{{ route('edit_external_certificate_request', [encrypt($userRequest->id)]) }}"  class="btn btn-bggreen" style="float:{{right()}}"> @lang('tr.Update')</a>
            </div>

            <div class="col-lg-3">
                <div style="margin-top:50px;"></div>
                @include('website.components.news', ['style'=>2])
            </div>
        </div>
    </div>
</section>
@endsection
