@extends('website.layouts.master')
@section('title', __('tr.Request Certificate'))

@section('content')

@include('website.layouts.title', ['simple'=>true])


<section>

    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <br/>
                <br/>
               
                <form id="submit_form"  autocomplete="off" action="{{ route('save_certificate_request',[$userRequest->id]) }}" method="POST" enctype="multipart/form-data">
                    
                    {{ csrf_field() }}

                    <input type="hidden" name="request_type" value="1">

                    <div style="border: 1px solid #dadada; padding: 20px;">

                        <div class="thick_header">
                            <h3>@lang('tr.General Information')</h3>
                        </div>

                        <hr/>

                        <div class="form-group">
                            <label>@lang('tr.English Name') <span class="required_field">*</span></label>
                            <input name="en_name" value="{{ dataField($userRequest, 'en_name') }}" type="text" class="form-control" required maxlength="256" style="direction: ltr;" />
                        </div>

                        <div class="form-group">
                            <label>@lang('tr.Arabic Name') <span class="required_field">*</span></label>
                            <input name="ar_name" value="{{ dataField($userRequest, 'ar_name') }}" type="text" class="form-control" required maxlength="256" style="direction: ltr;" />
                        </div>

                        <div class="form-group">
                            <div class="form-row">                                
                                <div class="col-lg-6">
                                    <label>@lang('tr.Email')</label>
                                    <p style="border: 1px solid #ced4da; padding: 5px; border-radius: 5px; padding-left: 12px; height: 39px;">{{ dataField($userRequest, 'email') }}</p>
                                    
                                </div>
                                <div class="col-lg-6">
                                    <label>@lang('tr.Mobile') <span class="required_field">*</span></label>
                                    <input name="mobile" value="{{ dataField($userRequest, 'mobile') }}" type="phone"  class="form-control" required maxlength="256" />
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-lg-6">
                                    <label>@lang('tr.Graduation Year') <span class="required_field">*</span></label>
                                    <input type="number" name="graduation_date" class="form-control" required value="{{ dataField($userRequest, 'graduation_date') }}" min="1900-01-01" max="<?php echo date('Y-m-d'); ?>"/>
                                </div>
                                <div class="col-lg-6">
                                    <label>@lang('tr.Student Code or National ID') <span class="required_field">*</span></label>
                                    <input name="student_code" value="{{ dataField($userRequest, 'student_code') }}" type="text" class="form-control" required maxlength="256" />
                                </div>
                            </div>
                        </div>             

                        <div class="form-group">
                            <label>@lang('tr.Program') <span class="required_field">*</span></label>
                            <select name="plan_id" id="plan_id" class="form-control" required>
                                <option value="">@lang('tr.Select Program')</option>
                                <optgroup label="@lang('tr.Main Stream')">
                                    @foreach($plans_2003 as $row)
                                        <option @if(dataField($userRequest, 'plan_id') == $row->id) selected @endif value="{{$row->id}}">{{$row->name}}</option>
                                    @endforeach
                                </optgroup>
                                <optgroup label="@lang('tr.Credit Hours')">
                                    @foreach($plans_2013 as $row)
                                        <option @if(dataField($userRequest, 'plan_id') == $row->id) selected @endif value="{{$row->id}}">{{$row->name}}</option>
                                    @endforeach
                                </optgroup>
                            </select>
                        </div>           
                        
                        @if($userRequest->order_status=="EMPTY")
                            <div class="thick_header">
                                <h3>@lang('tr.Certificates')</h3>
                            </div>
                            @include('system.components.certificates')
                        @endif

                        <div class="thick_header">
                            <h3>@lang('tr.Request Information')</h3>
                        </div>

                        <hr/>

                        <!-- <div class="form-group">
                            <label>@lang('tr.Provided to') <span class="required_field">*</span></label>
                            <input id="apply_to" name="apply_to" value="{{ dataField($userRequest, 'apply_to') }}" type="text" class="form-control" required maxlength="256" />
                        </div> -->

                        @include('website.components.certifications_request_document')

                        <input type="checkbox" id="mail" name="mail" value="1" {{isset($userRequest->data->mail) && $userRequest->data->mail == 1 ? 'checked disabled' : ''}}/>
                        <label for="mail">@lang('tr.Send By Mail')</label>
                    </div><br>

                    <div id="mail_information" class="card">
                        <div class="card-header">@lang('tr.Mail Information')</div>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="form-group">
                                    <label>@lang('tr.Address') <span class="required_field">*</span></label> {{(isset($user->address))?"($user->address)":""}}
                                    <input type="text" id="mail_address" name="mail_address" class="form-control" placeholder="@lang('tr.Address')" value="{{isset($userRequest->data->mail) && $userRequest->data->mail == 1 ? $userRequest->data->mail_address : ''}}"/>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr/>
                    <button type="submit" id="btnSubmitRequest" class="btn  btn-bggreen" style="float: {{right()}}" > @lang('tr.Submit')</button>

                </form>
            </div>

            <div class="col-lg-3">
                <div style="margin-top:50px;"></div>
                @include('website.components.news', ['style'=>2])
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    $(document).ready(function() {

        if($('#mail').is(':checked'))
        {
            $('#mail_information').show();
        }
        else
        {
            $('#mail_information').hide();
        }

        $('#mail').on('click', function () {
            if($('#mail').is(':checked'))
            {
                $('#mail_information').show();
            }
            else
            {
                $('#mail_information').hide();
            }

        });        
    });
</script>


@endsection

