@if($applicant->needFeedback())
    
    <br>
    <br>
    <div class="thick_header">
        <h3>@lang('tr.Feedback')</h3>
    </div>

    <hr/>
    
    <div class="form-group">    
        @php($message = $applicant->getLastFeedbackMessage())
        @if($message)
        <div class="alert alert-warning" role="alert">
            {{$message->comment}}
            @if(count($message->files)>0)<hr>@endif
            @foreach($message->files as $file)
            <a href="{{ route('download_file', ['id'=>$file->id]) }}">{{$file->name()}}</a>,
            @endforeach                                        
        </div>                                        
        @endif
        <textarea class="form-control" name="comment" placeholder="@lang('tr.Comment')" required maxlength="256">{{ field($applicant, 'comment') }}</textarea>
    </div>
@endif