@extends('website.layouts.master')

@section('title', "Login")

@section('pagecss')
@endsection

@section('content')
<section>
    <div class="section-wrapper p-t-57 p-b-60">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-7">
                    <div class="contact">
                        <div class="title">
                            <h2>@lang('tr.Login')</h2>
                            @if($errors->any())
                                <ul>
                                @foreach ($errors->all() as $error)
                                    <li style="color:red">*{{ $error }}</li>
                                @endforeach
                                </ul>
                            @endif
                        </div>
                        <div class="messages" id="status"></div>
                        <form class="contact-form" id="contact-form" method="POST" action="{{ route('web_login') }}">
                            {{ csrf_field() }}

                            <div class="form-group au-form w-100">
                                <div class="help-block with-errors"></div>
                                <input type="email" placeholder="@lang('tr.Email')" id="email" name="email" required="" oninvalid="this.setCustomValidity('@lang('tr.Reqired')')"
                                        oninput="setCustomValidity('')">
                            </div>
                            <div class="form-group au-form w-100">
                                <div class="help-block with-errors"></div>
                                <input type="password" placeholder="@lang('tr.Password')" id="password" name="password" required="" oninvalid="this.setCustomValidity('@lang('tr.Reqired')')"
                                        oninput="setCustomValidity('')">
                            </div>
                            <div class="form-group au-form w-10">
                                <button class="btn btn-primary waves-effect waves-light" id="contactBtn" type="submit">@lang('tr.Login')</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection

@section('pagejs')
@endsection
