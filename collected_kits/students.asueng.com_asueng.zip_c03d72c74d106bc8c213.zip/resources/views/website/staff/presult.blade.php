
<style>
    .page-link{
    border-radius: 50%;
    margin-left: 5px;
    margin-right: 5px;
    }
</style>



<div class="row" id="profile-cards">

@foreach ($instructors as $instructor)
    
    @php($url = route('staff_profile', $instructor->shortName()))
    
    <div class="col-lg-4" id="profile-card" style="margin-bottom: 20px;">
        <div class="panel panel-defualt">
            <div class="panel-body" style="height:280px;border: 1px solid #d8d7d745; padding: 4px; box-shadow: 0 0 5px 5px #00000008; display: block; margin-left: auto; margin-right: auto;">
                    @php($file = $instructor->archive->findChildByContentType("Personal Photo"))
                    @if($file)
                        <a href="{{ $url }}"><img src="{{ route('secure_download_file')."?sid=".$file->secret() }}" style="border: 2px solid #d8d7d7; padding: 4px; box-shadow: 0 0 1px 1px transparent; display: block; margin-left: auto; margin-right: auto; border-radius: 50%; width: 150px; height: 150px; margin-top: 30px;" width="60%"></a>
                    @else
                        <a href="{{ $url }}"><img src="/img/user.png" style="border: 2px solid #d8d7d7; padding: 4px; box-shadow: 0 0 1px 1px transparent; display: block; margin-left: auto; margin-right: auto; border-radius: 50%; width: 150px; height: 150px; margin-top: 30px;" width="85%"></a>
                    @endif
                    <h6 style="text-align: center;  color: black;margin-top:20px;" id="profile-name">
                        <a href="{{ $url }}">{{ $instructor->lang('name') }}</a>
                    </h6>
                    <div class="panel-footer" style="top: 0; position: absolute; left: 17px;">
                        <a href="{{ $url }}" id="profile-link" style="text-align: center; display: block; color: white; background: #007bff; padding: 6px; width: 100%; font-weight: bold; border-bottom-right-radius: 10px;">@lang("tr.More")</a>
                    </div>
            </div>
        </div>
    </div>

@endforeach
</div>

<div class="row" style="margin-bottom:50px;">
    <div class="col-lg-12">
        {!! $instructors->render() !!}
    </div>
</div>
