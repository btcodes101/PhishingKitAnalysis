@extends('layouts.master')
@section('title', __("tr.Upload Documents"))
@section('titleicon', "icon-cog3" )

@section('content')
	<!-- BEGIN .main-content -->
  
 <div class="main-content">
        <form method='post' action="{{ route('save_external_program_docs') }}" enctype="multipart/form-data">
        {{ csrf_field() }}
        
        <div class="row">
            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header"><b>@lang('tr.Upload Documents')</b></div>
                    <div class="card-body">
                        
                        <table class="table table-striped m-0">
                            <tbody>
                            <tr>
                                <th scope="row" >@lang('tr.Birthdate')</th>
                                <td>
                                    <input required="" type="file" name="birthDate" id="birthDateId">
                                </td>
                            </tr> 
                            <tr>
                                <th scope="row" >@lang('tr.Certificate of Secondary Education')</th>
                                <td>
                                    <input required type="file" name="secondaryCertificate" id="secondaryCertificateId">
                                </td>
                            </tr> 
                            <tr>
                                <th scope="row" >@lang('tr.tr.English Language Certificate (ielts)')</th>
                                <td>
                                    <input required type="file" name="englishLanguage" id="englishLanguageId">
                                </td>
                            </tr> 
                            <tr>
                                <th scope="row" >@lang('tr.National ID or Passport')</th>
                                <td>
                                    <input required type="file" name="nationalId" id="nationalId">
                                </td>
                            </tr>    
                             </tbody>
                             </table>          
                        
                        
                   
                    </div>
                </div>
                <hr/>
              

                <button type="submit" id="btnSubmitRequest" class="btn btn-primary btn-md" style="float: {{right()}}"> @lang('tr.Submit')</button>
               
            </div>

        </div>
        <br/>
        <br/>
    </form>
    </div>
    <!-- END: .main-content -->
@endsection

@section('pagejs')
	<script type="text/javascript">		
		$(document).ready(function() {
		});
	</script>
@endsection
