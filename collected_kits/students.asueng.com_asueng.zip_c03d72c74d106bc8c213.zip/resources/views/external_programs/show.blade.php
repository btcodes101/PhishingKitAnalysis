@extends('layouts.master')
@section('title', __("tr.East London"))
@section('titleicon', "icon-library" )

@section('content')
	<!-- BEGIN .main-content -->
    <div class="main-content">
        
        @if (session('status'))
        <div class="alert alert-success">
            <i class="icon-info-large"></i><strong>{{ session('status') }}</strong><br/>
        </div>
        @endif

        @php($externalProgramRegisteration = $student->externalProgramRegisteration())
        @php($externalProgram = $externalProgramRegisteration->externalProgram)

        <div class="row">

            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header"><b>@lang('tr.UEL Status')</b></div>
                    <div class="card-body">
                        <table class="table table-striped m-0">
                            <tbody>
                            <tr>
                                <th scope="row" width="180px">@lang('tr.Name')</th>
                                <td>{{$student->user->lang('name')}}</td>
                            </tr>
                            <tr>
                                <th scope="row" width="180px">@lang('tr.Program')</th>
                                <td>{{$externalProgram->name}}</td>
                            </tr>
                            <tr>
                                <th scope="row" width="180px">@lang('tr.Status')</th>
                                <td>{{$externalProgramRegisteration->statusName()}}</td>
                            </tr>
                            @if($student->externalProgramRegisteration()->comment)
                            <tr>
                                <th scope="row" width="180px">@lang('tr.Comment')</th>
                                <td>
                                    {{$student->externalProgramRegisteration()->comment}}
                                </td>
                            </tr>
                            @endif
                            <tr>
                                <th scope="row" width="180px">@lang('tr.Applied at')</th>
                                <td>{{$externalProgramRegisteration->created_at}}</td>
                            </tr>
                            @if($externalProgramRegisteration->coordinator_approve_at)
                            <tr>
                                <th scope="row" width="180px">@lang('tr.Coordinator Approval')</th>
                                <td>approve at {{$externalProgramRegisteration->coordinator_approve_at}}</td>
                            </tr>
                            @endif
                            @if($externalProgramRegisteration->canShowUploadedDocs())
                            @if(isset($archive) != null)
                            <th scope="row">@lang('tr.files')</th>
                            <td>
                                @foreach ($archive->childrenFiles as $app_file)
                                    <a target="_blank" href="{{ route('download_file',$app_file->id) }}" style="color: #4266b2; display: inline-block; margin-bottom: 9px;"><i class="icon-download-outline"></i>&nbsp;{{ $app_file->content_type.'.'.$app_file->extension }}</a> ,
                                @endforeach
                            </td>
                            @endif
                            @endif
                            
                            @if($externalProgramRegisteration->head_approve_at)
                            <tr>
                                <th scope="row" width="180px">@lang('tr.Program Head Approval')</th>
                                <td>approve at {{$externalProgramRegisteration->head_approve_at}}</td>
                            </tr>
                            @endif
                           
                        </tbody>
                    </table>
                    <hr>
                    <div style="text-align: right;">
                        @if($student->externalProgramRegisteration()->canUploadDocs())
                            <a  class="btn btn-primary btn-md" href="{{ route('upload_external_program_docs') }}">@lang('tr.Upload Documents')</a>
                            @endif
                            @if($student->externalProgramRegisteration()->canUpdateDocs())
                          
                              <a  class="btn btn-primary btn-md" href="{{ route('upload_external_program_docs') }}">@lang('tr.Update Documents')</a>
                          
                            @endif
                            @if($externalProgramRegisteration->canChange())
                                <a href="{{route('applyto_external_program')}}" class="btn btn-primary btn-md"> @lang('tr.Change')</a>
                            @endif 
                    </div>
                                               
                    </div>
                </div>
            </div>
        </div>
      
    
    </div>

    <!-- END: .main-content -->
@endsection

@section('pagejs')
	<script type="text/javascript">
		
		$(document).ready(function() {

		});
	</script>
@endsection
