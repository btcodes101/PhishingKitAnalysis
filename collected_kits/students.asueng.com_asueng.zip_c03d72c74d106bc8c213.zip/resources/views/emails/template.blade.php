<html>
<head></head>
<body dir="{{(!empty($language) && $language=="ar")?"rtl":"ltr"}}">
{!! $body !!}
</body>
</html>