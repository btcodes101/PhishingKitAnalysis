<!doctype html>
<html lang="en">

@include('components.head')

<body class="error-bg">
<div class="error-screen">
    <h1>{{ $code }}</h1>
    <h3>{{ $message }}</h3>
    <a href="{{ route('dashboard') }}" class="btn btn-info">Take me Away</a>
</div>

@include('components.footer')

@include('components.script')

</body>

</html>