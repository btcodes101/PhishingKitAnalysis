@if(!isset($isNew))
    @php($isNew = true)
@endif

@php($submit = "btn btn-primary btn-md")
@php($home = route('dashboard'))
@if(isset($website))
    @php($submit = "btn float-".right()." btn-bggreen")
    @php($home = route('home'))
@endif

<div id='ajax_form_progress_bar' style="background-color: green; width: 0%; height: 2px;"></div>
<hr/>
<button type="submit" class="{{ $submit }}"> {{ $isNew?__('tr.Submit'):__('tr.Update') }} <span id="ajax_form_progress_text"></span></button>

<script type="text/javascript">
    $(document).ready(function() {

    	$('#submit_form').ajaxForm({
            progressBar: $('#ajax_form_progress_bar'),
            progressText: $('#ajax_form_progress_text'),
        },function(response){
            infoBox("@lang('tr.Your request is submitted successfully')", function() {
                if(response.redirect_url)
                    window.location.href = response.redirect_url;
                else
                    window.location.href = "{{$home}}";
            });
        }, function(response){            
            $('#submit_form').showErrors(response, function() {
                var firstError = $('.form-error:visible:first').first();
                if(firstError.length==1)
                    $('html, body').animate({scrollTop: ( firstError.offset().top - 140 )}, 1000);
            });
        });    
        
    });
</script>