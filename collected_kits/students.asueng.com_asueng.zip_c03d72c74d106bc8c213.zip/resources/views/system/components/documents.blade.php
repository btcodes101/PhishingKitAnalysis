@if(!isset($archive))
    @php($archive = null)
@endif

@if(!isset($showTitle))
    @php($showTitle = true)
@endif

@if($showTitle)
<div class="thick_header">
    <h3>@lang('tr.Documents')
    <br/>
    <small style="font-size: 15px;">Permitted Extension: jpeg,jpg,png,gif,pdf,doc, and docx. - </small>
    <small style="font-size: 15px;">Max file size: 10 MB</small>
    </h3>
    
</div>

<hr/>
@endif

@foreach($fileTypes as $contentType=>$fileInfo)
    @if($archive)
        @php($file = $archive->findChildByContentType($contentType))
    @else
        @php($file = null)
    @endif


    <div class="form-group">
        <label>{{$fileInfo->title}} <span class="required_field">{{$fileInfo->required?"*":""}}</span> 
        @if(isset($fileInfo->note)) <br/><span style="color: darkgray;">{{$fileInfo->note}}<span> @endif</label>
    
        @if($file)
        <div class="alert alert-info" id="{{$contentType}}" role="alert">
            <a href="{{ route('secure_download_file')."?sid=".$file->secret() }}">{{$file->name()}}</a>
            <a class="{{ (lang() == 'en')?'float-right':'float-left' }}" id="change_{{$contentType}}" href="javascript:void(0)" title="@lang('tr.Edit')">
                <i class="fa fa-edit"></i>
            </a>
            <input type="hidden" name="{{$contentType}}_file_id" value="{{$file->id}}">
        </div>
        @endif
        
        <div id="edit_{{$contentType}}" style="display: {{($file)?"none":""}}">
            <div class="form-group">
                
                <input type="file" class="form-control" name="{{$contentType}}" placeholder="{{$fileInfo->title}}" {{($fileInfo->required)?"required":""}}  {{($file)?"disabled":""}} accept='.jpg,.png,.gif,.pdf'>                
            </div>                            
        </div>
    </div>
@endforeach

<script type="text/javascript">
    $(document).ready(function() {
        var filesContentsTypes = [
        @foreach($fileTypes as $contentType=>$fileInfo)
        '{{ $contentType }}',
        @endforeach
        ];

        $.each( filesContentsTypes, function( key, value) {
            $('#change_'+value).click(function() {
                $('#'+value).hide('fast', function() {
                    $(this).remove();
                    $('#edit_'+value).show('fast', function() {
                        $(this).find('input').prop('disabled', false);
                    })
                })
            });
        });
    });
</script>