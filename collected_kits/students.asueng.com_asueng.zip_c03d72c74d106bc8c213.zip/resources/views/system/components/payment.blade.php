@if(isset($userRequest))
    <br>
    <div class="card">
        <div class="card-header">@lang('tr.Extra Fees')</div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item">Credit Card: 1.45%</li>
            <li class="list-group-item">Fawry: Check while requesting</li>
        </ul>
    </div>

    @php($confirm = "btn btn-primary btn-md")
    @php($home = route('dashboard'))
    @if(isset($website))
        @php($home = route('home'))
        @php($confirm = "btn float-".right()." btn-bggreen")
    @endif
    <br>
    <?php $align = ''; if(lang() == 'ar') $align = 'float:left'; else $align = 'float:right'; ?>
    <button type="button" id="confirm" class="btn" style="<?= $align; ?>;background: #4266b2;color: white;"> @lang('tr.Pay with Fawry')</button>
    @auth
    <!-- Pay with Credit Card: this service offered only to the logged in users -->
    <button type="button" id="pay_with_my_credit" class="btn" style="<?= $align; ?>;background: #4266b2;color: white;margin-right: 19px !important;"> @lang('tr.Pay with my credit')</button>
    @endauth
    <button type="button" id="pay_with_bank_misr_credit_card" class="btn" style="<?= $align; ?>;background: #4266b2;color: white;margin-right: 19px !important;"> @lang('tr.Pay with Credit Card')</button>
    <button type="button" id="pay_with_bank_misr_meeza" class="btn" style="display:none !important;<?= $align; ?>;background: #4266b2;color: white;margin-right: 19px !important;"> @lang('tr.Pay with Meeza Card')</button>

    <script src="https://www.atfawry.com/ECommercePlugin/scripts/fawryPlugin.js"></script>
    <script src="https://banquemisr.gateway.mastercard.com/checkout/version/54/checkout.js" data-error="errorCallback"
            data-cancel="cancelCallback" data-complete='completeCallback'>
    </script>
    <script src="https://upgstaging.egyptianbanks.com:3006/js/Lightbox.js"></script> 

    <script type="text/javascript">

        redirectTo = '{{ $home }}';

        function fawryCallbackFunction(paid, billUploadBillAccNum, paymentAuthId, merchantRefNum, messageSignature) {
                var message = false;
                if(paid) {
                    message = '@lang('tr.Request is submitted successfully.')';
                } else {
                    message = '@lang('tr.Request is submitted successfully. Waiting for payment authority confirmation.')';
                }
                infoBox(message, function() {
                    window.location.href = window.redirectTo;
                });
            
        }

        $(document).ready(function() {
            
            $('#confirm').click(function() {
            
                var product = {};
                product.productSKU = '<?php echo str_replace ('_', ' ', $userRequest->type); ?>';
                product.description = '<?php echo str_replace ('_', ' ', $userRequest->type); ?>';
                product.price =  {{ $userRequest->total_amount }}; // you can replace it with static value
                @if(isset($userRequest->service->fawry_account->merchant_number))
                    var merchant = '{{$userRequest->service->fawry_account->merchant_number}}'; // Required
                @else
                    var merchant = 'FskXOLNYaCBKitmTMhLsqw=='; // default
                @endif
                var merchantReferenceNo = '{{ $userRequest->merchant_reference_no }}'
                var locale = 'ar-eg'; // Required
                product.quantity = 1;
                var products = [];
                products.push(product);
                var fawryProductsJSON = JSON.stringify(products);
                loadFawryPluginPopup(merchant, locale, merchantReferenceNo, fawryProductsJSON, '', '', '', 'null', 'null', 'null');
            });


            $('#pay_with_my_credit').click(function() {
                    var url = '{{ route('pay_with_my_credit', ['userRequest'=>$userRequest->id]) }}';
                    var submitToken = '{{ csrf_token() }}';

                    $.post(url,{'_token': submitToken},function(data, status){
                        if(data.state == 'accepted'){
                            infoBox(data.msg, function() {
                                window.location.href = window.redirectTo;
                            });
                        }else{
                            errorBox(data.msg);
                        }
                    }).fail(function(error) {
                        var message = '@lang('tr.General Error')';
                        errorBox(message);
                    });
                    
               
            });

            $('#pay_with_bank_misr_credit_card').click(function() {
                $('#pay_with_bank_misr_credit_card').text('Please wait ...')
                Checkout.showLightbox();
            });

            
            $('#pay_with_bank_misr_meeza').click(function() {
                callUPGMeeza();
            });


        });
    
    

        //Start: Meeza Card
        function callUPGMeeza() {
            var orderId = '';
            var paymentMethodFromLightBox = null;
            var amount = {{ $userRequest->total_amount }}; 
            var mID = 10349047849;
            var tID = 88053534;
            var MerchantReference = "{{ $userRequest->merchant_reference_no }}";
            var securehash = "{{ $userRequest->meeza_msg_signature }}";
            var trxdatetime= "{{ \Carbon\Carbon::parse($userRequest->created_at)->format('ymdHis') }}";
            Lightbox.Checkout.configure = {
                OrderId: orderId,
                paymentMethodFromLightBox: paymentMethodFromLightBox,
                MID: mID,
                TID: tID,
                AmountTrxn: (amount * 100),
                SecureHash: securehash,
                TrxDateTime: trxdatetime,
                MerchantReference: MerchantReference,
                completeCallback: function(response) {
                    
                    console.log('completed'); 
                    console.log(response);

                    var url = '{{ route('bank_misr_trans_meeza') }}';
                    var submitToken = '{{ csrf_token() }}';
                    
                    response['_token'] = submitToken;

                    $.post(url, response, function(data, status){

                        Lightbox.Checkout.closeLightbox();
                        
                        message = '@lang('tr.Your payment was successful')';
                        infoBox(message, function() {
                            window.location.href = window.redirectTo;
                        });
                    
                    }).fail(function(error) {
                        var message = '@lang('tr.General Error')';
                        errorBox(message, function() {
                                window.location.href = '{{route('my_services')}}';
                        });
                    });
                },
                errorCallback: function(error) {
                    errorBox('Something went wrong, please try again later or with different payment option', function() {
                                window.location.href = '{{route('my_services')}}';
                    });
                },
                cancelCallback: function() {
                    console.log('cancel'); 
                } 
            }; 
            Lightbox.Checkout.showLightbox(); 
        } 
        //End: Meeza Card


        //Bank Misr Credit Card  
        Checkout.configure({
                merchant: '{{$userRequest->service->bank_misr_credit_card_account->merchant_number}}' ,
                order: {
                    amount:  <?php echo ceil($userRequest->total_amount * 1.0147134); ?>,
                    currency: 'EGP',
                    description: '<?php echo str_replace ('_', ' ', $userRequest->type); ?>',
                    id: '{{ $userRequest->merchant_reference_no }}'
                },
                interaction: {
                    operation: 'PURCHASE', // set this field to 'PURCHASE' for Hosted Checkout to perform a Pay Operation.
                    merchant: {
                        name: 'ASU Faculty Of Engineering',

                    },

                },
                session: {
                    id: '{{ $userRequest->session_id }}'
                }
        });

        function errorCallback(error) {
            
            errorBox('Your Seesion has been expired', function() {
                    window.location.href = '{{route('my_services')}}';
            });
            console.log(JSON.stringify(error));
        }

        function completeCallback(data) {
            
            console.log('completed'); 

            var url = '{{ route('bank_misr_trans_credit_card') }}';
            var submitToken = '{{ csrf_token() }}';
            

            $.post(url, {'_token':submitToken, 'number':data,  'MerchantReference': "{{$userRequest->merchant_reference_no}}" }, function(data, status){
                
                if(data.success == true){
                    message = '@lang('tr.Your payment was successful')';
                    infoBox(message, function() {
                        window.location.href = window.redirectTo;
                    });
                }else{
                    message = '@lang('tr.Your payment rejected.')';
                    errorBox(message);
                }
                
            
            }).fail(function(error) {
                var message = '@lang('tr.General Error')';
                errorBox(message);
            });
        }

        function cancelCallback() {
            console.log('Payment cancelled');
            location.reload();
        }

        /*Checkout.saveFormFields(function(){
            console.log('saveFormFields');
        });

        function restoreFormFields() {
            console.log('restoreFormFields');
        }*/

    

    </script>
@endif