<table id='certificates_table' class="table table-striped">
    <thead>
        <tr>
            <th>#</th>
            <th>@lang('tr.Certificate Type')</th>
            <th width="15%">@lang('tr.Number')</th>
            <th width="10%">@lang('tr.Cost')</th>
            <th width="10%">@lang('tr.Total')</th>
        </tr>
    </thead>
    <tbody>
        @php($i = 1)
        @foreach($certificatesTypes as $certificateType)
        @if(!empty($certificateType->cost))
        <tr>
            <td>{{ $i++ }}</td>
            <td>{{ $certificateType->lang('name') }}</td>
            <td>
                <input type="hidden" name="type[]" value="{{$certificateType->id}}">
                <input type="number" class="quantity" id="quantity_{{$certificateType->id}}" name="quantity[]" value="0" style="width: 75px;" min="0" max="10">
            </td>
            <td class="cost">{{$certificateType->cost}}</td>
            <td class="total">0</td>
        </tr>
        @endif
        @endforeach
        <tr>
            <td colspan="4" style="text-align: {{right()}}; font-weight: bold;">@lang('tr.Total')</td>
            <td id="total_final">0</td>
        </tr>
    </tbody>                                
</table>

<div class="form-check">
    <input type="checkbox" class="form-check-input" id="Agreement" required>
    <label class="form-check-label" for="Agreement">@lang('tr.Agreement')</label>
    <label class="form-check-label" for="Agreement"><strong>@lang('tr.certificates_Processing_time')</strong></label>
  </div>
<script type="text/javascript">
    $(document).ready(function() {
        
        var counter = 0;

        $('#mail').on('click', function () {
            if($('#mail').is(':checked'))
                $('#total_final').text(parseInt($('#total_final').text()) + {{$postCost}});
            else
                $('#total_final').text(parseInt($('#total_final').text()) - {{$postCost}});

        });

        $('.quantity').each(function() {
            $(this).on('change', function() {

                $('#total_final').text(0);
                
                if($('#mail').is(':checked'))
                    $('#total_final').text({{$postCost}});
                else
                    $('#total_final').text(0);

                var quantity = $(this).val();
                var cost = $(this).closest('tr').find('.cost').text();
                $(this).closest('tr').find('.total').text(cost*quantity);
                $('.total').each(function() {
                    var totalFinal = parseInt($('#total_final').text());
                    totalFinal += parseInt($(this).text());
                    $('#total_final').text(totalFinal);
                });
            });
        });

            $('#btnSubmitRequest').on('click',function(e){
                $('.quantity').each(function() {
                    counter = counter + $(this).val();
                });
                if(counter <= 0){
                    alert('{{ __("tr.Please Choose At Least One of Certificates") }}');
                    
                    return false;
                }
            });

            
        
    });
</script>