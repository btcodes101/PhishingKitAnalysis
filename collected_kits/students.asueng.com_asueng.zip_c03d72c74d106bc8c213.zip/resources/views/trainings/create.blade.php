@extends('layouts.master')

@section('title',  __('tr.Submit Training Request'))
@section('subtitle', __('tr.Add Training'))
@section('titleicon', "icon-file-text")

@section('content')
    


    <div class="main-content">
        @if(!empty($errors->all()))
            <div class="alert alert-danger text-white bg-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (\Session::has('msg'))
            <div class="alert alert-danger text-white bg-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <ul>
                    <li>{!! \Session::get('msg') !!}</li>
                </ul>
            </div>
        @endif
        <form id="submit_form"  action="{{ route('store_training_request') }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }} 
            <div class="row gutters">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                    <div class="card">
                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                            <div class="card-header" role="tab">
                                <p>@lang('tr.Training Information')</p>
                            </div>
                            <div class="card-body">
                        
                                <div class="form-group">
                                    <label>@lang('tr.Term') <span class="required_field">*</span></label>
                                    <select name="term_id" id="term_id" class="form-control" required>
                                        <option value="">@lang('Select the term')</option>
                                        @foreach($terms as $key => $value)
                                            <option @if(old('term_id') == $key) selected @endif value="{{$key}}">{{$value}}</option>
                                        @endforeach
                                    </select>
                                </div>      
                                <div class="form-group">
                                    <label>@lang('tr.Training Type') <span class="required_field">*</span></label>
                                    <select name="type" id="type" class="form-control" required>
                                        <option value="">@lang('Select the training type')</option>
                                        @foreach($types as $type)
                                            <option @if(old('type') == $type) selected @endif value="{{$type}}">{{$type}}</option>
                                        @endforeach
                                    </select>
                                </div>       
                                <div class="form-group">
                                    <label>@lang('tr.Title') <span class="required_field">*</span></label>
                                    <input name="title" value="{{ old('title') }}" placeholder="@lang('The title of the training')" type="text" class="form-control" required maxlength="256" />
                                </div> 
                                <div class="form-group">
                                    <label>@lang('tr.Description') <span class="required_field">*</span></label>
                                    <textarea name="description" placeholder="@lang('The description of the training')" id="" class="form-control" cols="10" rows="10" required>{{ old('description') }}</textarea>
                                </div>
                                <div class="form-group">
                                    <label>@lang('tr.Training Provider') <span class="required_field">*</span></label>
                                    <input name="provider" value="{{ old('provider') }}" placeholder="@lang('Training Provider')" type="text" class="form-control" required maxlength="256" />
                                </div> 
                                <div class="form-group">
                                    <div class="form-row">
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Number of weeks') <span class="required_field">*</span></label>
                                            <input type="number" placeholder="Number of weeks" name="num_of_weeks" class="form-control" required value="{{ old('num_of_weeks') }}" />
                                        </div>
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Number of Students') <span class="required_field">*</span></label>
                                            <input type="number" placeholder="Number of Students"  name="num_of_students" class="form-control" required value="{{ old('num_of_students') }}" />
                                        </div>
                                    </div>
                                </div> 
                                <div class="form-group">
                                    <label>@lang('tr.Acceptance Criteria') <span class="required_field">*</span></label>
                                    <textarea name="acceptance_criteria" placeholder="@lang('The acceptance criteria of the training')" id="" class="form-control" cols="5" rows="10" required>{{ old('acceptance_criteria') }}</textarea>
                                </div> 
                                <div class="form-group">
                                    <div class="form-row">
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Start Date') <span class="required_field">*</span></label>
                                            <input type="date" name="start_date" class="form-control" required value="{{ old('start_date') }}" min="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                        <div class="col-lg-6">
                                            <label>@lang('tr.End Date') <span class="required_field">*</span></label>
                                            <input type="date" name="end_date" class="form-control" required value="{{ old('end_date') }}"  min="<?php echo date('Y-m-d'); ?>"/>
                                        </div>
                                    </div>
                                </div> 
                                <!-- <div class="form-group">
                                    <label>@lang('tr.Bylaw')</label>
                                    <select name="bylaw" id="bylaw" class="form-control">
                                        <option value="All">@lang('Select the Bylaw')</option>
                                        @foreach($bylaws as $key => $value)
                                            <option @if(old('bylaw') == $key) selected @endif value="{{$key}}">{{$value}}</option>
                                        @endforeach
                                    </select>
                                </div>   -->
                                <!-- <div class="form-group" id=''>
                                    <label>@lang('tr.Plans') <span class="required_field">*</span></label>
                                    <select name="plans_ids[]" id="plans" class="form-control" required multiple>
                                        <option value="0" selected>@lang('All Plans')</option>
                                    </select>
                                </div> -->
                                <div class="form-group">
                                    <div class="form-row">
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Application Start Date') <span class="required_field">*</span></label>
                                            <input type="date" name="application_start_date" class="form-control" required value="{{ old('application_start_date') }}" min="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Application End Date') <span class="required_field">*</span></label>
                                            <input type="date" name="application_end_date" class="form-control" required value="{{ old('application_end_date') }}"  min="<?php echo date('Y-m-d'); ?>"/>
                                        </div>
                                    </div>
                                </div>  
                                <div class="form-group">
                                    <label>@lang('tr.Contact Person Details') <span class="required_field">*</span></label>
                                    <textarea name="contact_person" placeholder="@lang('Contact Person Details')" id="" class="form-control" cols="5" rows="10" required>{{ old('contact_person') }}</textarea>
                                </div> 
                                <div class="form-group">
                                    <label>@lang('tr.The CV is required')</label>
                                    <input type="checkbox" @if(old('cv_required') == 1) checked @endif name="cv_required" value="1">
                                </div> 

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <button  type="submit" class="btn btn-primary btn-md" >@lang('Save')</button>
                </div>
            </div>
            <br>
        </form>
    </div>
@endsection

@section('pagejs')
    <script type="text/javascript">
        $(document).ready(function () {

            $('#plans').selectize({
                placeholder: 'Select Plan/s'
            });

            function getPlans(){
                var bylaw = $('#bylaw').val();
                var url = "{{route('plans_by_bylaw', ['bylaw'=>'#bylaw'])}}";
                var selectize = $('#plans')[0].selectize;
                
                if(bylaw != ''){
                    $.get(url.replace('#bylaw', bylaw), function(data, status){

                        if(!$.isEmptyObject(data)){

                            $('#plans').empty();
                            $("#plans").prop("multiple", "multiple");

                            $.each(data, function(index, val) {
                                selectize.clear('silent')
                                selectize.addOption({value:index,text:val});
                                selectize.refreshOptions();
                            });
                        }else{
                            $('#plans').empty();
                            $("#plans").prop("multiple", "");
                            $('#plans').append('<option value=0>@lang("All Plans")</option>');
                        }
                    

                    }).fail(function(erroe){
                        errorBox("@lang('tr.General Error')");
                    });
                }
            }
            
            $(document).on("change", '#bylaw', function () {
                getPlans();
            });

            getPlans();
        })
    </script>
@endsection
