@extends('layouts.master')

@section('title', __("tr.My Trainings"))
@section('subtitle', __("tr.My Trainings" ) )
@section('titleicon', "icon-file-text")


@section('content')
<style>
hr {
    margin-top: 0;
    margin-bottom: 0;
    border-top: 1px solid #000;
}
.status_tag {
            padding: 6px;
            color: white;
            border-radius: 8px;
        }
</style>
	<!-- BEGIN .main-content -->
	<div class="main-content">
		<div class="row gutters">
			<div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
				 
			<div class="card">
					<div class="card-body pb-0">
						<div class="filter-box">
							<div class="row">
                                 
                                <div class="col-md-3">
									<div class="form-group">
										{!! Form::select('term_id', array(""=>__("tr.Term"))+$terms, null, array('id'=> 'term_id', 'class'=>'form-control', 'data-placement'=>'top', 'title'=> __('tr.Term'))) !!}
									</div>
								</div>

							 
                                <div class="col-md-3">
									<div class="form-group">
										<select name="type" id="type" class="form-control">
											<option value=''>@lang("tr.Select Type")</option>
											@foreach($types as $type)
												<option value='{{$type}}'>{{$type}}</option>
											@endforeach
										</select>
									</div>
								</div>

								<div class="col-md-3">
									<div class="form-group">
										<select id="status" class="form-control">
											<option value="">@lang('tr.Select Status')</option>
											@foreach(App\StudentTraining::STATUSES as $key => $value)
												<option value="{{$key}}">{{$value}}</option>
											@endforeach                                       
										</select>
									</div>
                                </div>
                                 
                                <div class="col-md-2">
									<div class="form-group">
										<input type="date" id='start_date' namw='start_date' class="form-control" title='Start Date'>
									</div> 
                                </div> 
                                
                                

								{{--Button--}}
								<div class="col-md-2 float">
									<div class="form-group">
										<button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
									</div>
								</div>

								{{--Button--}}
								<div class="col-md-2 float">
									<div class="form-group">
										<button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
									</div>
                                </div>
                                
							</div>
						</div>

					</div>
				</div>

				<div class="card">
					<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
						<div class="card-body">
							<table id="data_table" class="display" style="width:100%">
								<thead>
								<tr>
									<th>@lang('tr.Term')</th>
									<th>@lang('tr.Type')</th>
									<th>@lang('tr.Title')</th>
									<th>@lang('tr.Status')</th>
									<th>@lang('tr.Weeks')</th>
									<th>@lang('tr.Start Date')</th>
									<th>@lang('tr.End Date')</th>
									<th></th>
								</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Row end -->
	</div>
	<!-- END: .main-content -->

	<script type="text/javascript">
		
        var showURL = '{{ route('studentstrainings_show', ['id'=>'#id']) }}';
        var trainingFollowUpURL = '{{ route('trainings_follow_up', ['id'=>'#id']) }}';

		var statuses = [];
		var statuses_color = [];

		@foreach(App\StudentTraining::STATUSES as $key => $value)
			statuses['{{$key}}'] = '{{$value}}';
		@endforeach

		@foreach(App\StudentTraining::STATUSES_COLORS as  $key => $value)
			statuses_color['{{$key}}'] = '{{$value}}';
		@endforeach

		$(document).ready(function() {
			var table = $('#data_table').DataTable({
				processing: true,
				serverSide: true,
				scrollX: true,
				stateSave: false,
				rowId: 'id',
				order: [
					[ 0, "desc" ]
				],
				"ajax": {
					"url": '{{ route('my_trainings') }}',
					"dataSrc": "data.data"

				},
				"columns": [
					{ "data": "term_name", "name": "term_name"},
					{ "data": "type", "name": "type"},
					{ "data": "title", "name": "title"},
					{ "data": "status", "name": "status",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) { 
                            
                            var html = "<span class='status_tag badge badge-"+statuses_color[oData.status]+"'>" + statuses[oData.status] + "</span>";
                            $(nTd).html(html);
			            }
                    },
					{ "data": "num_of_weeks", "name": "num_of_weeks"},
					{ "data": "start_date", "name": "start_date"},
					{ "data": "end_date", "name": "end_date"},
					{ "data": "id", "name": "id",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							var html = "";
							if(oData.status == {{App\StudentTraining::ACCEPTED}} || oData.status == {{App\StudentTraining::APPROVED}} || oData.status == {{App\StudentTraining::MEETING}} || oData.status == {{App\StudentTraining::DISAPPROVED}}){

                            	html = "<a target='_blank' href='" + trainingFollowUpURL.replace('#id', oData.id) + "' title='Training Follow Up' href='#'><i class='icon-open_in_new'></i></a>";
							}
                            $(nTd).html("<span class='action-column'>"+html+"</span>");
						}
					},
				]
			});

			$(".dataTables_filter").hide();

			$('#search_button').on( 'click', function () {
				table.columns(0).search($("#term_id").val());
				table.columns(2).search($("#type").val()); 
				table.columns(3).search($("#start_date").val()); 
				table.columns(4).search($("#status").val()); 
				table.draw();
			} );

		 

			$('#reset_button').on( 'click', function () {
				$("#term_id").val("");
				$("#type").val("");
				$("#start_date").val("");
				$("#status").val("");
				$('#search_button').trigger('click');
			});


		});
	</script>
@stop
