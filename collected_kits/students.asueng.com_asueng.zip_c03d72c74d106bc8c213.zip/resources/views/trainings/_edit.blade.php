@extends('layouts.master')

@section('title',  __('tr.Edit Training'))
@section('subtitle', __('tr.Edit new training'))
@section('titleicon', "icon-file-text")

@section('content')
    


    <div class="main-content">
        @if(!empty($errors->all()))
            <div class="alert alert-danger text-white bg-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form id="submit_form"  action="{{ route('studentsTrainings.update', ['id' => $training->id]) }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }} 
            {{ method_field('PATCH') }}
            <div class="row gutters">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                    <div class="card">
                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                            <div class="card-header" role="tab">
                                <p>@lang('tr.Training Information')</p>
                            </div>
                            <div class="card-body">
                        
                                <div class="form-group">
                                    <label>@lang('tr.Term') <span class="required_field">*</span></label>
                                    <select name="term_id" id="term_id" class="form-control" required>
                                        <option value="">@lang('Select the term')</option>
                                        @foreach($terms as $key => $value)
                                            <option @if($training->term_id == $key) selected @endif value="{{$key}}">{{$value}}</option>
                                        @endforeach
                                    </select>
                                </div>      
                                <div class="form-group">
                                    <label>@lang('tr.Training Type') <span class="required_field">*</span></label>
                                    <select name="type" id="type" class="form-control" required>
                                        <option value="">@lang('Select the training type')</option>
                                        @foreach($types as $type)
                                            <option @if($training->type == $type) selected @endif value="{{$type}}">{{$type}}</option>
                                        @endforeach
                                    </select>
                                </div>       
                                <div class="form-group">
                                    <label>@lang('tr.Title') <span class="required_field">*</span></label>
                                    <input name="title" value="{{ $training->title }}" type="text" class="form-control" required maxlength="256" />
                                </div> 
                                <div class="form-group">
                                    <label>@lang('tr.Description') <span class="required_field">*</span></label>
                                    <textarea name="description" class="form-control" cols="10" rows="10" required>{{ $training->description }}</textarea>
                                </div>
                                <div class="form-group">
                                    <label>@lang('tr.Training Provider') <span class="required_field">*</span></label>
                                    <input name="provider" value="{{ $training->provider }}" type="text" class="form-control" required maxlength="256" />
                                </div> 
                                <div class="form-group">
                                    <div class="form-row">
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Number of weeks') <span class="required_field">*</span></label>
                                            <input type="number" name="num_of_weeks" class="form-control" required value="{{ $training->num_of_weeks }}" />
                                        </div>
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Number of Students') <span class="required_field">*</span></label>
                                            <input type="number" name="num_of_students" class="form-control" required value="{{ $training->num_of_students }}" />
                                        </div>
                                    </div>
                                </div> 
                                <div class="form-group">
                                    <label>@lang('tr.Acceptance Criteria') <span class="required_field">*</span></label>
                                    <textarea name="acceptance_criteria" class="form-control" cols="5" rows="10" required>{{ $training->acceptance_criteria }}</textarea>
                                </div> 
                                <div class="form-group">
                                    <div class="form-row">
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Start Date') <span class="required_field">*</span></label>
                                            <input type="date" name="start_date" class="form-control" required value="{{ $training->start_date }}" min="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                        <div class="col-lg-6">
                                            <label>@lang('tr.End Date') <span class="required_field">*</span></label>
                                            <input type="date" name="end_date" class="form-control" required value="{{ $training->end_date }}"  min="<?php echo date('Y-m-d'); ?>"/>
                                        </div>
                                    </div>
                                </div> 
                                <div class="form-group">
                                    <label>@lang('tr.Bylaw')</label>
                                    <select name="bylaw" id="bylaw" class="form-control">
                                        <option value="All">@lang('Select the Bylaw')</option>
                                        @foreach($bylaws as $key => $value)
                                            <option @if($training->bylaw == $key) selected @endif value="{{$key}}">{{$value}}</option>
                                        @endforeach
                                    </select>
                                </div>  
                                <div class="form-group" id=''>
                                    <label>@lang('tr.Plans') <span class="required_field">*</span></label>
                                    <select name="plans_ids[]" id="plans" class="form-control" required multiple>
                                        @if($training->all_plans == 1)
                                            <option value="0" selected>@lang('All Plans')</option>
                                        @else
                                            @foreach($training->plans as $plan)
                                                <option value="{{$plan->id}}" selected>{{$plan->lang('minor')}}</option>
                                                <option value="0">@lang('All Plans')</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                                <div class="form-group">
                                    <div class="form-row">
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Application Start Date') <span class="required_field">*</span></label>
                                            <input type="date" name="application_start_date" class="form-control" required value="{{ $training->application_start_date }}" min="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                        <div class="col-lg-6">
                                            <label>@lang('tr.Application End Date') <span class="required_field">*</span></label>
                                            <input type="date" name="application_end_date" class="form-control" required value="{{ $training->application_end_date }}"  min="<?php echo date('Y-m-d'); ?>"/>
                                        </div>
                                    </div>
                                </div>  
                                <div class="form-group">
                                    <label>@lang('tr.Contact Person Details') <span class="required_field">*</span></label>
                                    <textarea name="contact_person" class="form-control" cols="5" rows="10" required>{{ $training->contact_person }}</textarea>
                                </div> 
                                <div class="form-group">
                                    <label>@lang('tr.The CV is required')</label>
                                    <input type="checkbox" @if($training->cv_required) == 1) checked @endif name="cv_required" value="1">
                                </div> 

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <button  type="submit" class="btn btn-primary btn-md" >@lang('Update')</button>
                </div>
            </div>
            <br>
        </form>
    </div>
@endsection

@section('pagejs')
    <script type="text/javascript">
        $(document).ready(function () {

            $('#plans').selectize({
                placeholder: 'Select Plan/s'
            });

            function getPlans(){
                var bylaw = $('#bylaw').val();
                var url = "{{route('plans_by_bylaw', ['bylaw'=>'#bylaw'])}}";
                var selectize = $('#plans')[0].selectize;
                
                if(bylaw != ''){
                    $.get(url.replace('#bylaw', bylaw), function(data, status){

                        if(!$.isEmptyObject(data)){

                            //$('#plans').empty();
                            $("#plans").prop("multiple", "multiple");

                            $.each(data, function(index, val) {
                                selectize.addOption({value:index,text:val});
                                selectize.refreshOptions();
                            });
                        }else{
                            $('#plans').empty();
                            $("#plans").prop("multiple", "");
                            $('#plans').append('<option value=0>@lang("All Plans")</option>');
                        }
                    

                    }).fail(function(erroe){
                        errorBox("@lang('tr.General Error')");
                    });
                }
            }
            
            $(document).on("change", '#bylaw', function () {
                getPlans();
            });

            getPlans();
        })
    </script>
@endsection
