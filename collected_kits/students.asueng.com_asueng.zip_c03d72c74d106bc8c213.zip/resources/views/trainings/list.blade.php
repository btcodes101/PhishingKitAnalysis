@extends('layouts.master')

@section('title', __("tr.Available Trainings"))
@section('subtitle', __("tr.List Trainings" ) )
@section('titleicon', "icon-file-text")


@section('content')
<style>
hr {
    margin-top: 0;
    margin-bottom: 0;
    border-top: 1px solid #000;
}
</style>
	<!-- BEGIN .main-content -->
	<div class="main-content">
		<div class="row gutters">
			<div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
				 
			<div class="card">
					<div class="card-body pb-0">
						<div class="filter-box">
							<div class="row">
                                 
                                <div class="col-md-3">
									{!! Form::select('term_id', array(""=>__("tr.Term"))+$terms, null, array('id'=> 'term_id', 'class'=>'form-control', 'data-placement'=>'top', 'title'=> __('tr.Term'))) !!}
								</div>

							 
                                <div class="col-md-3">
                                    <select name="type" id="type" class="form-control">
                                        <option value=''>@lang("tr.Select Type")</option>
                                        @foreach($types as $type)
                                            <option value='{{$type}}'>{{$type}}</option>
                                        @endforeach
                                    </select>
								</div>
                                 
                                <div class="col-md-2">
                                    <input type="date" id='start_date' namw='start_date' class="form-control" title='Start Date'>
                                </div> 
                                
                                

								{{--Button--}}
								<div class="col-md-2 float">
									<button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
								</div>

								{{--Button--}}
								<div class="col-md-2 float">
									<button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
                                </div>
                                
							</div>
						</div>

					</div>
				</div>

				<div class="card">
					<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
						<div class="card-body">
							<table id="data_table" class="display" style="width:100%">
								<thead>
								<tr>
									<th>@lang('tr.Term')</th>
									<th>@lang('tr.Type')</th>
									<th>@lang('tr.Title')</th>
									<th>@lang('tr.Weeks')</th>
									<th>@lang('tr.Start Date')</th>
									<th>@lang('tr.Application Start Date')</th>
									<th></th>
								</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Row end -->
	</div>
	<!-- END: .main-content -->

	<script type="text/javascript">
		
        var showURL = '{{ route('studentstrainings_show', ['id'=>'#id']) }}';
		 

		$(document).ready(function() {
			var table = $('#data_table').DataTable({
				processing: true,
				serverSide: true,
				scrollX: true,
				stateSave: false,
				rowId: 'id',
				order: [
					[ 0, "desc" ]
				],
				"ajax": {
					"url": '{{ route('studentstrainings') }}',
					"dataSrc": "data.data"

				},
				"columns": [
					{ "data": "term_name", "name": "term_name"},
					{ "data": "type", "name": "type"},
					{ "data": "title", "name": "title"},
					{ "data": "num_of_weeks", "name": "num_of_weeks"},
					{ "data": "start_date", "name": "start_date"},
					{ "data": "application_start_date", "name": "application_start_date"},
					{ "data": "id", "name": "id",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							var html = "";
                            html += "<a title='@lang('tr.View Details')' target='_blank' href='"+showURL.replace('#id', oData.id)+"'><i class='icon-eye'></i></a>&nbsp;";
							$(nTd).html("<span class='action-column'>"+html+"</span>");
						}
					},
				]
			});

			$(".dataTables_filter").hide();

			$('#search_button').on( 'click', function () {
				table.columns(0).search($("#term_id").val());
				table.columns(2).search($("#type").val()); 
				table.columns(3).search($("#start_date").val()); 
				table.draw();
			} );

		 

			$('#reset_button').on( 'click', function () {
				$("#term_id").val("");
				$("#type").val("");
				$("#start_date").val("");
				$('#search_button').trigger('click');
			});


		});
	</script>
@stop
