@extends('layouts.master')

@section('title',  __('tr.Training Follow Up'))
@section('subtitle', __('tr.Training'))
@section('titleicon', "icon-file-text")

@section('content')
    <style>
        label {
            font-weight: 700;
        }
        .form-group {
            border-bottom: 1px solid white;
        }
        #plans > p{
            background: #4266b2;
            padding: 10px;
            color: white;
            
        }
        .status_tag {
            padding: 6px;
            color: white;
            border-radius: 8px;
        }
        .trainingInfo_avatar {
            vertical-align: middle;
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }

        textarea
            {
                resize: none;
                overflow: hidden;
            }
    </style>

    <div class="main-content">
        <div class="row gutters">
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                <div class="card">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-header" role="tab">
                            <p>@lang('tr.Training Information')</p>
                        </div>
                        <div class="card-body">

                            <table class='table table-striped'>
                                <tbody>
                                    <tr>
                                        <th style='width: 20%'>@lang('tr.Title')</th>
                                        <td><a href='{{route("studentstrainings_show", [$studentTrainingInfo->training_id])}}' target='_blank'>{{$studentTrainingInfo->title}}</a></td>
                                    </tr>
                                    <tr style='text-align: justify;'>
                                        <th>@lang('tr.Description')</th>
                                        <td>{{$studentTrainingInfo->description}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Training provider')</th>
                                        <td>{{$studentTrainingInfo->provider}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Number of weeks')</th>
                                        <td>{{$studentTrainingInfo->num_of_weeks}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Start Date')</th>
                                        <td>{{$studentTrainingInfo->start_date}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.End Date')</th>
                                        <td>{{$studentTrainingInfo->end_date}}</td>
                                    </tr>
                                    
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <p>
                                <strong>@lang('tr.Status'):</strong>
                                <span class='badge badge-{{App\StudentTraining::STATUSES_COLORS[$studentTrainingInfo->status]}}'>
                                    {{App\StudentTraining::STATUSES[$studentTrainingInfo->status]}}  
                                </span> 
                                @if($studentTrainingInfo->status == App\StudentTraining::MEETING) : {{$studentTrainingInfo->meeting_time}} @endif
                            </p>
                    </div>
                </div>
            </div>
        </div>


        @if($studentTrainingInfo->canDiscuss())
            <div class="row gutters">
                <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                    <!-- Form's comment -->
                    <div class="card">
                        <div class="card-body">
                            <form class="ajax_form" enctype="multipart/form-data" action="{{ route('add_student_training_comment', [$studentTrainingInfo->id]) }}" method="POST">
                                {{ csrf_field() }}
                                <div class="form-group" >
                                    <textarea id="comment" name="comment" required class="form-control" style="height: auto;" rows="1" placeholder="Write your comment..."></textarea>
                                </div>
                                <div class="row gutters">
                                    <div class="col-3">
                                        <input type="file" class="filestyle" name="attachments[]" data-icon="true" multiple accept=".jpeg,.png,.jpg,pdf,.doc,.docx">
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <button type="submit" id="send_comment" class="btn btn-primary float-right">@lang('tr.Send')</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- // End -->    
                </div>
            </div>
        @endif
        @if(count($studentTrainingInfo->studentTrainingMessages)!=0)
            <div class="row">
                <div class="col-9">
                    <div class="card">
                    <div class="card-header"> @lang('tr.Training Comments')</div>
                        <div class="card-body">
                            <div class="media overflow-scroll">
                                <div class="media-body" id="comments">
                                        
                                    @foreach($studentTrainingInfo->studentTrainingMessages as $message)

                                    <div class="media mt-3">
                                        <div class="mr-3">
                                            <a href="#">
                                                <span class="media-object">
                                                @php($file = ($message->user)?$message->user->archive->findChildByContentType("Personal Photo"):null)
                                                @if($file)
                                                    <img class="trainingInfo_avatar" alt="48x48" src="/img/user.png">
                                                @else
                                                    <img class="trainingInfo_avatar" alt="48x48" src="/img/user.png">
                                                @endif
                                                </span>
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <h5 class="mt-0 media-heading">
                                                <a style="color: #4266b2" href="{{ route('show_profile',['id' => $message->user->id]) }}">{{ $message->user->en_name }}</a>
                                                <span class="date" style="border: none;padding: 0px;">
                                                    {{ date('Y-m-d', strtotime($message->created_at)) }}
                                                </span>
                                            </h5>
                                            <p>{!! nl2br(htmlspecialchars($message->comment)) !!}</p>
                                            <div class="comments-footer clearfix">
                                                @foreach($message->files as $file)
                                                    <span>
                                                    <i class="icon-file-empty"></i> <a href="{{ route('download_file', ['archive_id'=>$file->id]) }}">{{ $file->name() }}</a>
                                                    </span>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                    <div style="display: none;">
                                        <div class="media mt-3" id="comment_template">
                                            <div class="mr-3">
                                                <a href="#">
                                                    <span class="media-object">
                                                        <img class="trainingInfo_avatar" alt="48x48" src="/img/user.png">
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <h5 class="mt-0 media-heading">
                                                    <span class="user_name"></span>
                                                    <span class="date created_from" style="border: none;padding: 0px;"></span>
                                                </h5>
                                                <p class="comment"></p>
                                                <div class="comments-footer clearfix">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="display: none;">
                                        <span id="comment_file_template">
                                            <i class="icon-file-empty"></i> <a></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                </div>
            </div>
        @endif
 
    </div>
   
@endsection



@section('pagejs')
<script type="text/javascript">
    $(document).ready(function() {
        $(".ajax_form").ajaxForm([], function(response){
            var commentElement = $("#comment_template").clone();
            commentElement.attr('id', '');
            commentElement.find('.user_name').text(response.user_name);
            commentElement.find('.created_from').text(response.created_from.date);
            commentElement.find('.comment').html(response.comment);

            for(var i=0;i<response.files_infos.length;i++) {
                var commentFileElement = $("#comment_file_template").clone();
                commentFileElement.find('a').attr('href', response.files_infos[i].url);
                commentFileElement.find('a').text(response.files_infos[i].name);
                commentFileElement.appendTo(commentElement.find('.comments-footer'));
            }
            commentElement.prependTo('#comments');
            $('#comment').css('height', 'auto');

            console.log(response.created_from.date);
        });


        initTextArea();
    });

    var observe;
    if (window.attachEvent) {
        observe = function (element, event, handler) {
            element.attachEvent('on'+event, handler);
        };
    }
    else {
        observe = function (element, event, handler) {
            element.addEventListener(event, handler, false);
        };
    }

    function initTextArea() {
        var text = document.getElementById('comment');
        function resize () {
            text.style.height = 'auto';
            text.style.height = text.scrollHeight+'px';
        }
        /* 0-timeout to get the already changed text */
        function delayedResize () {
            window.setTimeout(resize, 0);
        }
        observe(text, 'change',  resize);
        observe(text, 'cut',     delayedResize);
        observe(text, 'paste',   delayedResize);
        observe(text, 'drop',    delayedResize);
        observe(text, 'keydown', delayedResize);

        text.focus();
        text.select();
        resize();
    }
</script>
@endsection


 
