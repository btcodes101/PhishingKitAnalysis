@extends('layouts.master')

@section('title',  __('tr.Training Opportunity Details'))
@section('subtitle', '')
@section('titleicon', "icon-file-text")


@section('content')
    <style>
        label {
            font-weight: 700;
        }
        .form-group {
            border-bottom: 1px solid white;
        }
           
        }
       
    </style>

    <div class="main-content">
        <div class="row gutters">
            <div class="col-md-8">
                <div class="card">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-header" role="tab">
                            <p>@lang('tr.Training Information')</p>
                        </div>
                        <div class="card-body">

                            <table class='table table-striped'>
                                <tbody>
                                    <tr>
                                        <th style='width:30%'>@lang('tr.Term')</th>
                                        <td>{{$training->term->lang('name')}}</td>
                                    </tr> 
                                    <tr>
                                        <th>@lang('tr.Training Type')</th>
                                        <td>{{$training->type}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Title')</th>
                                        <td>{{$training->title}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Description')</th>
                                        <td>{{$training->description}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Training provider')</th>
                                        <td>{{$training->provider}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Number of weeks')</th>
                                        <td>{{$training->num_of_weeks}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Number of Students')</th>
                                        <td>{{$training->num_of_students}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Acceptance Criteria')</th>
                                        <td>{{$training->acceptance_criteria}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Start Date')</th>
                                        <td>{{$training->start_date}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.End Date')</th>
                                        <td>{{$training->end_date}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Bylaw')</th>
                                        <td>{{$training->bylaw}}</td>
                                    </tr>
                                    @if($training->plans->count() > 0) 
                                    <tr>
                                        <td>@lang('tr.Plans')</td>
                                        <td>
                                            @foreach($training->plans as $plan)
                                                <p>{{$plan->lang('minor')}}</p>
                                            @endforeach
                                        </td>
                                    </tr>
                                    @endif
                                    <tr>
                                        <th>@lang('tr.Application Start Date')</th>
                                        <td>{{$training->application_start_date}}</td>
                                    </tr>
                                    <tr>
                                        <th>@lang('tr.Application End Date')</th>
                                        <td>{{$training->application_end_date}}</td>
                                    </tr>
                                     
                                    <tr>
                                        <th>@lang('tr.The CV is required')</th>
                                        <td>@if($training->cv_required == 1) Yes @else No  @endif</td>
                                    </tr>
                                    
                                </tbody>
                            </table>

                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                   
                    <div class="card-body">
                        @if($studentTraining == null)
                            @if(!empty($errors->all()))
                                <div class="alert alert-danger text-white bg-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    <ul>
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            <form method='post' action="{{route('apply', ['id' => $training->id])}}" enctype="multipart/form-data">
                                {{ csrf_field() }} 
                                <div class="form-group">
                                    <label>@lang('tr.CV') @if($training->cv_required == 1)<span class="required_field">*</span>@endif </label>
                                    <input type="file" name="cv" class="form-control" accept=".jpeg,.png,.jpg,pdf,.doc,.docx" @if($training->cv_required == 1) required @endif >
                                </div> 
                                
                                <button type="submit" class="btn btn-primary btn-md">@lang('tr.Apply')</button>
                            </form>
                        @else
                            <h5>
                                @lang('tr.You already applied to this training.')
                            </h5>
                            <hr>
                            <p>
                                <strong>@lang('tr.Status'):</strong>
                                <span class='badge badge-{{App\StudentTraining::STATUSES_COLORS[$studentTraining->status]}}'>
                                    {{App\StudentTraining::STATUSES[$studentTraining->status]}}  
                                </span> 
                            </p>
                        @endif

                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection

 
