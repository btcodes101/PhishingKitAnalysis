<!doctype html>
<html lang="en">
@section('title', __('tr.Login') )
@include('components.head')

<body>
<div class="container">
    <div class="login-screen row align-items-center">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <form method="post" action="reset" aria-label="{{ __('tr.Login') }}">
                {{ csrf_field() }}
                <input type="hidden" name="email" value="{{$user->email}}">
                <div class="login-container">
                    <div class="row no-gutters">
                        <div class="col-xl-5 col-lg-5 col-md-6 col-sm-12">
                            <div class="login-box">                                
                                <a href="/login" class="login-logo">
                                    <img src="{{asset('img/asueng-b.png')}}" />
                                </a>
                                <h5 style="text-align: center;">Password Reset</h5>
                                <p style="text-align: center;"><strong>{{$user->email}}</strong></p>
                                <div class="input-group">
                                    <span class="input-group-addon btn-lg" id="password"><i class="icon-verified_user"></i></span>
                                    <input placeholder="Password" id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>
                                </div>
                                <br>
                                <div class="input-group">
                                    <span class="input-group-addon btn-lg" id="password" name="password"><i class="icon-verified_user"></i></span>
                                    <input placeholder="Confirm Password" id="confirm_password" type="password" class="form-control{{ $errors->has('confirm_password') ? ' is-invalid' : '' }}" name="confirm_password" required>
                                </div>

                                @if($errors->getMessages() != [])
                                    &ensp;
                                    <div class="alert alert-danger" style="color: darkred">
                                        {{ $errors->getMessages()['message'][0] }}
                                    </div>
                                @endif

                                <div class="actions clearfix">
                                    <button type="submit" class="btn btn-primary">@lang('tr.Reset')</button>
                                </div>                                
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-7 col-md-6 col-sm-12">
                            <div class="login-slider"></div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>