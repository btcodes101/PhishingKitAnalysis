@extends('layouts.master')

@section('title', __('tr.Write Email') )
@section('titleicon', "icon-edit2")

@section('content')
@php($messagePage = ($emailMessage->id==0)?null:$emailMessage->archive->findChildByContentType("message"))
@php($messagePage = (empty($messagePage) || $messagePage->exists())?$messagePage:$messagePage->getLocale('en'))

    <div class="main-content" id="app">

        <form action="{{ route('save_email',['id'=>$emailMessage->id]) }}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
            <!--Start: Edit Page-->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-6 col-md-6 col-sm-6">
                    <div class="card" id="email_message" 
                    @if($emailMessage->language=='ar')
                    style="direction: rtl;text-align: right;"
                    @else
                    style="direction: ltr;text-align: left;"
                    @endif
                    >
                        <div class="card-body">
                            <div class="row form-group">
                                <div class="col-md-4">
                                    {!! Form::select('send_to', array(''=>__('tr.Send to ...')) + $sendToTypes, $emailMessage->send_to, array('id'=> 'send_to', 'class'=>'form-control', 'required'=>'required' )) !!}
                                </div>
                                <div class="col-md-2">
                                    <select id='language' name='language' class="form-control">
                                        <option {{($emailMessage->language=='ar')?'':'selected'}} value="en">English</option>
                                        <option {{($emailMessage->language=='ar')?'selected':''}} value="ar">عربي</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-6">
                                    <input type="text" name="title" class="form-control" placeholder="@lang('tr.Title')" value="{{ $emailMessage->title }}">
                                </div>
                            </div>

                            <textarea name="message" id="summernote" required>{!!($messagePage)?$messagePage->page():''!!}</textarea>
                            &ensp;
                            <div class="row form-group">
                                @if($emailMessage->id==0)
                                <div class="col-3">
                                    <input type="file" class="filestyle" name="attachments[]" data-icon="true" multiple value="">
                                </div>
                                @endif
                            </div>
                            <div class="row form-group" dir="ltr">
                                <div class="col-md-6">
                                    <input type="email" name="sender_email" class="form-control" placeholder="Sender Email (Leave empty to use system email)" value="{{ $emailMessage->sender_email }}">
                                </div>
                                <div class="col-md-6">
                                    <input type="password" name="sender_password" class="form-control" placeholder="Sender Email Password" value="{{($emailMessage->sender_password)?"nochange":""}}">
                                </div>
                            </div>
                            <hr>
                            <button type="submit" class="btn btn-primary btn-md float-right">
                                <span class="icon-edit"></span>
                                @if($emailMessage->id==0)
                                    @lang('tr.Send')
                                @else
                                    @lang('tr.Save')
                                @endif
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <br/>

        @if($emailMessage->id!=0)
            @include('system.archive.component', ['name'=>'archive1', 'archive'=>$emailMessage->archive->findChildByContentType('attachments'), 'addFolders'=>false , 'addPages'=>false, 'otherFiles'=>true , 'pathName'=>'Email Attachments', 'actAsOwner'=>true])
        @endif

    </div>
@endsection

@section('pagejs')
    <script type="text/javascript">

        $(document).ready(function() {

            function init() {
                $('#summernote').summernote({
                height: '300px',
                toolbar: [
                    ['style', ['style','bold', 'italic', 'underline', 'clear']],
                    ['font', ['fontsize','strikethrough', 'superscript', 'subscript']],
                    ['paragraph', ['ul', 'ol', 'paragraph','height']],
                    ['insert', ['ltr','rtl']],
                    ['insert', ['picture','link','video', 'table', 'hr']],
                    ['misc', ['fullscreen','codeview','undo', 'redo', 'help']]
                ]
                });
            }

            $('#language').change(function(event) {
                
                if($(this).val()=="ar") {
                    $('#email_message').css('direction', 'rtl');
                    $('#email_message').css('text-align', 'right');
                } else {
                    $('#email_message').css('direction', 'ltr');
                    $('#email_message').css('text-align', 'left');
                }
            });

            init();
        });

    </script>
@endsection
