@extends('layouts.master')

@section('title', __('tr.Emails Center') )
@section('subtitle', __('tr.Tracking Email Operations'))
@section('titleicon', "icon-mail6")

@can('access_emails')
@section('advancedaction')
    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
        <div class="right-actions">
            <div class="btn-group float-right">
                <div class="btn-group">
                    <a href="{{ route('add_email') }}" class="btn btn-primary">
                        <i class="icon-plus"></i> @lang('tr.Write Email')
                    </a>
                </div>
            </div>
        </div>
    </div>
@endsection
@endcan

@section('content')
    <!-- BEGIN .main-content -->
    <div class="main-content">
        <div class="row gutters">
            <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-body">
                            <table id="emails_messages" class="display" style="width:100%">
                                <thead>
                                <tr>
                                    <th width="8%">@lang('tr.Id')</th>
                                    <th width="20%">@lang('tr.Title')</th>
                                    <th width="20%">@lang('tr.From')</th>
                                    <th width="10%">@lang('tr.To')</th>
                                    <th width="8%">@lang('tr.Status')</th>
                                    <th width="13%">@lang('tr.Created at')</th>
                                    <th width="13%">@lang('tr.Updated at')</th>
                                    <th width="8%"></th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->
    </div>
    <!-- END: .main-content -->

    <script type="text/javascript">

        $(document).ready(function() {

            var editUrl = '{{route('edit_email', ['id'=>'#id'])}}';

            var sendToTypes = [];
            @foreach($sendToTypes as $key=>$value)
            sendToTypes[{{ $key }}] = '{{ $value }}';
            @endforeach


            var table = $('#emails_messages').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                stateSave: false,
                rowId: 'id',
                language: dataTableLanguage,
                "ajax": {
                    "url": '{{ route('emails_center') }}',
                    "dataSrc": "data.data"
                },
                order: [[ 5, "desc" ]],
                "columns": [
                    { "data": "id", "name": "id"},
                    { "data": "title", "name": "title"},
                    { "data": "name", "name": "name"},
                    { "data": "send_to", "name": "send_to",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = sendToTypes[oData.send_to];
                            $(nTd).html(html);
                        }
                    },
                    { "data": "completion", "name": "completion",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var style = "";
                            if(oData.status == 0) style = "style='color:lightgray'";
                            var html = "<span "+style+">"+oData.completion+"</span>";
                            $(nTd).html(html);
                        }
                    },
                    { "data": "created_at", "name": "created_at"},
                    { "data": "updated_at", "name": "updated_at"},
                    { "data": "id", "name": "id",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            html += "<a title='@lang('tr.Edit')' href='"+editUrl.replace('#id', oData.id)+"' class='edit_email'><i class='icon-edit2'></i></a>&nbsp;";
                            if(oData.status==0) {
                                html += "<a title='@lang('tr.Resume')' href='javascript:void(0)' class='action_email' action='resume'><i class='icon-media-play'></i></a>&nbsp;";

                                html += "<a title='"+oData.status_message+"' href='javascript:void(0)' class='status_message'><i class='icon-help'></i></a>&nbsp;";
                            }
                            else {
                                html += "<a title='@lang('tr.Pause')' href='javascript:void(0)'  class='action_email' action='pause'><i class='icon-media-pause'></i></a>&nbsp;";
                            }

                            html += "<a title='@lang('tr.Delete')' href='javascript:void(0)' class='action_email' action='delete'><i class='icon-delete'></i></a>&nbsp;";
                            $(nTd).html("<span class='action-column'>"+html+"</span>");
                        }
                    },
                ]
            });

            $(".dataTables_filter").hide();

            $('#search_button').on( 'click', function () {
                table.search($("#text_search").val());
                table.columns(0).search($("#search_status").val());
                table.draw();
            } );

            $('#text_search').keyup(function (e){
                if(e.keyCode == 13)
                    $('#search_button').trigger('click');
            });

            $('#reset_button').on( 'click', function () {
                $("#text_search").val("");
                $("#search_status").val("");
                $('#search_button').trigger('click');
            } );

            $(document).on("click", ".status_message", function () {
                errorBox($(this).attr('title'));
            });

            $(document).on("click", ".action_email", function () {
                var deleteURL = '{{ route('action_email', ['id'=>'#id', 'action'=>'#action']) }}';
                var row = $(this).closest('tr');
                var action = $(this).attr('action');
                var data = table.row(row).data();
                var url = deleteURL.replace('#id', data.id).replace('#action', action);
                var message = "Are you sure you want to "+action+" (<B>"+data.title+"</B>) ?";

                warningBox(message, function() {
                    $.post(url, {"_token": '{{ csrf_token() }}' }, function(data, status){
                        table.draw(false);
                    });
                });
            });
        });
    </script>
@stop
