@extends('layouts.master')

@section('title', __('tr.Applicants'))
@section('subtitle', __('tr.Applicants Information'))
@section('titleicon', "icon-file-text")

@section('content')

	<!-- BEGIN .main-content -->
	<div class="main-content">
		<div class="row gutters">
			<div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
				<div class="card">
                    <div class="card-body pb-0">
                        <form action="" method="post" id="filter_form">
                            {{ csrf_field() }}

							<div class="filter-box">
								<div class="row">
									<div class="col-md-2">
                                        {!! Form::select('search_applicant', array(''=>__('tr.Select Apply To'))+$applicantsTypes, null, array('id'=> 'search_applicant' )) !!}
									</div>

                                    <div class="col-md-2">
                                        {!! Form::select('search_status', array(''=>__('tr.Select Status'))+'App\Applicant'::statusTypes(), null, array('id'=> 'search_status' )) !!}
									</div>

                                    <div class="col-md-4">
                                        {{ Form::text('text_search', null, ['id'=>'text_search', 'placeholder'=>__('tr.TextSearch')]) }}
                                    </div>

									<div class="col-md-2 float">
                                        <button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
									</div>

									<div class="col-md-2 float">
										<button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
									</div>
								</div>
							</div>
                        </form>
                    </div>
                </div>

                <!-- Statistics -->
                <div id="term_statistics" class="row gutters">
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                        <div class="card" id="visitors">
                            <div class="card-body">
                                <div class="stats-widget">
                                    <a href="#" class="stats-label" data-placement="top">-</a>
                                    <div class="stats-widget-header">
                                        <i class="icon-users"></i>
                                    </div>
                                    <div class="stats-widget-body">
                                        <!-- Row start -->
                                        <ul class="row no-gutters">
                                            <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                                <h6 class="blog-title">@lang('tr.Visitors')</h6>
                                            </li>
                                            <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                               <h4 class="total">-</h4>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                        <div class="card" id="applicants">
                            <div class="card-body">
                                <div class="stats-widget">
                                    <a href="#" class="stats-label" data-placement="top">-</a>
                                    <div class="stats-widget-header">
                                        <i class="icon-users"></i>
                                    </div>
                                    <div class="stats-widget-body">
                                        <!-- Row start -->
                                        <ul class="row no-gutters">
                                            <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                                <h6 class="blog-title">@lang('tr.Applicants')</h6>
                                            </li>
                                            <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                                <h4 class="total">-</h4>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
				<div class="card">

					<div class="card-header">
						<span id="transactions">@lang('tr.Applicants')</span>						
						<div id="applicants_action" class="btn-group float-right" style="display: none">
							<div class="btn-group">
								<button type="button" class="btn btn-primary btn-sm">@lang('tr.Reports')</button>
								<button type="button" class="btn btn-primary btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<span class="sr-only">Toggle Dropdown</span>
								</button>
								<div class="dropdown-menu dropdown-menu-right" x-placement="bottom-start" style="position: absolute; transform: translate3d(71px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
									<a class="dropdown-item" id="applicants_sheet" href="javascript:void(0)" >@lang('tr.Excel Export')</a>
								</div>
							</div>
						</div>
					</div>

					<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
						<div class="card-body">
                            <table id="datatable" class="display" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>@lang('tr.Name')</th>
                                        <th>@lang('tr.Apply To')</th>
                                        <th>@lang('tr.Email')</th>
                                        <th>@lang('tr.Status')</th>
                                        <th>@lang('tr.Created at')</th>
                                        <th></th>
                                    </tr>
                                </thead>
                            </table>
					    </div>
					</div>
				</div>
			</div>
		</div>
		<!-- Row end -->
	</div>
	<!-- END: .main-content -->
@endsection

@section('pagejs')
    <script type="text/javascript">

        $(document).ready(function(){
            
            var editURL = '{{ route('applyto', ['type' => '#type', 'id'=>'#id', 'secret'=>'#secret']) }}';
            var showURL = '{{ route("show_applicant", ['id' => '#id']) }}';

            var statusTypes = {
            @foreach('App\Applicant'::statusTypes() as $key=>$value)
            '{{$key}}': '{{$value}}',
            @endforeach
            };

            var statusBadges = {
            @foreach('App\Applicant'::statusBadges() as $key=>$value)
            '{{$key}}': '{{$value}}',
            @endforeach
            };

            var table = $('#datatable').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                stateSave: false,
                rowId: 'id',
                "ajax": {
                    "url": '{{ route('applicants') }}',
                    "dataSrc": "data.data"
                },
                order: [[ 0, "desc" ]],
                "columns": [
                    { "data": "id", "name": "id" },
                    { "data": "name", "name": "name" },
                    { "data": "apply_to", "name": "apply_to"},
                    { "data": "email", "name": "email"},
                    { "data": "status", "name": "status",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            $(nTd).html("<span class='badge badge-general-"+statusBadges[oData.status]+"'>"+ statusTypes[oData.status]+"</span>");
                        }
                    },
                    { "data": "created_at", "name": "created_at"},
                    { "data": "id", "name": "id",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            @can(['access_applicants','access_applicants'])
                                html += "<a title='@lang('tr.View')' href='"+showURL.replace('#id',oData.id)+"'><i class='icon-eye'></i></i></a>&nbsp;";
                            @endcan

                            @can(['operate_applicants'])
                                html += "<a title='@lang('tr.Edit')' target='_blank' href='"+editURL.replace('#type', oData.apply_to).replace('#id', oData.id).replace('#secret', oData.secret)+"' class='edit_applicant'><i class='icon-edit'></i></i></a>&nbsp;"
                            @endcan

                            @can(['admin_applicants'])
                                html += "<a title='@lang('tr.Delete')' href='javascript:void(0)' class='delete_applicant'><i class='icon-times-outline'></i></i></a>&nbsp;";
                            @endcan

                            $(nTd).html("<span class='action-column'>"+html+"</span>");
                        }
                    },
                  ]
                  
            });

            function showStatistics(item, value, total) {
                item.find('.total').html(value);
            }

            table.on('xhr.dt', function ( e, settings, json, xhr ) {
                
                showStatistics($('#applicants'), json.count_applicants);
                showStatistics($('#visitors'), json.count_visitors);
            });
    
            $(".dataTables_filter").hide();

            $('#search_button').on('click', function () {
               table.search($("#text_search").val());
               table.columns(0).search($("#search_applicant").val());
               table.columns(1).search($("#search_status").val());
               table.draw();
            } );

            $('#text_search').on('keyup', function (e){
               if(e.keyCode == 13)
                   $('#search_button').trigger('click');
            });

            $('#reset_button').on('click', function () {
               $("#text_search").val("")
               $("#search_applicant").val("")
               $("#search_status").val("")
               $('#search_button').trigger('click');
            } );

            $(document).on("click", ".delete_applicant", function () {
                var deleteURL = '{{ route("delete_applicant", ['id' => '#id']) }}';
                var row = $(this).closest('tr');
                var data = table.row(row).data();
                var url = deleteURL.replace('#id', data.id);
                var message = "Are you sure you want to delete (<B>"+data.id+":"+data.name+"</B>) ?";

                warningBox(message, function() {
                    $.post(url, {"_token": '{{ csrf_token() }}' }, function(data, status){
                        table.row("#"+data.id).remove().draw(false);
                        infoBox('@lang('tr.Item Deleted Successfully')');
                    });
                });

            });

            $('#search_applicant').on('change', function () {
            
                if($(this).val()=="") {
                    $("#applicants_action").hide();
                    $('#search_button').trigger('click');
                } else {
                    $("#applicants_action").show();
                    $('#search_button').trigger('click');
                }
            });

            $allowSubmit = false;

            $('#filter_form').on('submit', function(event) {
                if(!$allowSubmit)event.preventDefault();
            })

            $('#applicants_sheet').on("click", function () {
                
                var count = table.page.info().recordsTotal;
                if(count>20000) {
                    infoBox("Too many records ("+count+"), unable to render report. Try make some filters.");
                    return;
                }

                var action = '{{ route('applicants_sheet') }}';
                $('#filter_form').attr('action', action);
                $allowSubmit = true;
                $('#filter_form').submit();
                $allowSubmit = false;
            });
        })
    </script>
@endsection