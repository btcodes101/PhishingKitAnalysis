@extends('layouts.master')

@section('title',$applicant->en_full_name)
@section('subtitle', __('tr.Applicants Information'))
@section('titleicon', "icon-user")

@section('advancedaction')
    @can('operate_applicants')
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 mt-2">
            <div class="btn-group float-right">
                <div class="btn-group">
                    <button type="button" class="btn btn-primary">@lang('tr.More')</button>
                    <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-start" style="position: absolute; transform: translate3d(71px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                        @can('operate_applicants')
                        <a class="dropdown-item" href="{{route('feedback_applicant', ['id'=>$applicant->id])}}"><i class="icon-chat archive-icon"></i> @lang('tr.Feedback')</a>                        
                        <a class="dropdown-item" href="{{route('discuss_applicant', ['id'=>$applicant->id])}}"><i class="icon-chat archive-icon"></i> @lang('tr.Discuss')</a>
                        @endcan
                    </div>
                </div>
            </div>
        </div>
    @endcan
@endsection

@section('content')
    <div class="main-content">
        <div class="card">
            <div class="card-header">
                @lang('tr.Main Information')
            </div>

            <div class="card-body">
                <table class="table table-striped m-0">
                    <tbody>
                    <tr>
                        <th scope="row" width="180px">@lang('tr.EnglishName')</th>
                        <td>{{ $applicant->en_full_name }}</td>
                    </tr>

                    <tr>
                        <th scope="row">@lang('tr.ArabicName')</th>
                        <td> {{ $applicant->ar_full_name }} </td>
                    </tr>

                    <tr>
                        <th scope="row">@lang('tr.Email')</th>
                        <td> {{ $applicant->email }}  </td>
                    </tr>

                    <tr>
                        <th scope="row">@lang('tr.Gender')</th>
                        <td> {{ ($applicant->gender)?'App\User'::gendersLabels()[$applicant->gender]:"" }} </td>
                    </tr>

                    @if($applicant->address != null)
                    <tr>
                        <th scope="row">@lang('tr.Address')</th>
                        <td> {{ $applicant->address }} </td>
                    </tr>
                    @endif

                    <tr>
                        <th scope="row">@lang('tr.Mobile')</th>
                        <td> {{ $applicant->mobile }} </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">@lang('tr.apply_to')</th>
                        <td>{{ $applicant->apply_to }}</td>
                    </tr>
                    
                    <tr>
                        <th scope="row">@lang('tr.Birthdate')</th>
                        <td> {{ $applicant->birth_date }} </td>
                    </tr>                              
                    
                    @if($applicant->nationality_code != null)
                    <tr>
                        <th scope="row">@lang('tr.nationality_code')</th>
                        <td>{{ $applicant->nationality_code }}</td>
                    </tr>  
                    @endif
                                                  
                    
                    <tr>
                        <th scope="row">@lang('tr.NationalID')</th>
                        <td>{{ $applicant->national_id }}</td>
                    </tr>
                    
                    <tr>
                        <th scope="row">@lang('tr.files')</th>
                        <td>
                            @foreach ($applicant->archive->files() as $app_file)
                                <a href="{{ route('download_file',$app_file->id) }}" style="color: #4266b2; display: inline-block; margin-bottom: 9px;"><i class="icon-download-outline"></i>&nbsp;{{ $app_file->title.'.'.$app_file->extension }}</a> , 
                            @endforeach
                        </td>
                    </tr>
                    
                    </tbody>
                </table>
            </div>
        </div>


        <div class="card">
            <div class="card-header">
                @lang('tr.Other Information')
            </div>

            <div class="card-body">
                <table class="table table-striped m-0">
                    <tbody>
                    <?php $data = ($applicant->data)?json_decode($applicant->data):[]; ?>

                        @foreach ($data as $key => $value)
                            @if($value != null)
                            <tr>
                                <th scope="row" width="180px">{{ ucfirst(str_replace('_',' ',$key)) }}</th>
                                <td>{{ $applicant->getDataValue($key, $value) }}</td>
                            </tr>
                            @endif
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @include('manage.applicants.reason_modal')
@endsection

@section('js')
    <script type="text/javascript">
        $(document).ready(function () {

        })
    </script>
@endsection
