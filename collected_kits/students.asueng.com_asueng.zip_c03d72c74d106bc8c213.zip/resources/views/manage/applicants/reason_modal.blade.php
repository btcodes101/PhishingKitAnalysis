<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel2" aria-hidden="true" style="display: none;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel2">@lang('tr.Reason')</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                        <form action="{{ route('ApplicantActions') }}" method="post">
                        @csrf
                        <input type="hidden" name="applicant_id" value="{{ $applicant->id }}">
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">@lang('tr.Reason'):</label>
                            <textarea class="form-control" required placeholder="@lang('tr.Write Reason')" name="notes" id="message-text"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">@lang('tr.Close')</button>
                        <button type="submit" name="reject_applicant" value="reject_applicant" class="btn btn-primary">@lang('tr.OK')</button>
                    </div>
                </form>
            </div>
        </div>
    </div>