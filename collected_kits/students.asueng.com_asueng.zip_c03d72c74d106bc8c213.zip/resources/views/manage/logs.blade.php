@extends('layouts.master')

@section('title', __("tr.Log"))
@section('subtitle', __("tr.Show system log") )
@section('titleicon', "icon-th-list")

@section('content')
    <div class="main-content">
        <div class="row gutters">
            <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-body pb-0">
                        <div class="filter-box">
                            <div class="row">

                                <div class="form-group  col-md-3">
                                    <label><i class="icon icon-date_range" ></i>From</label>
                                    <input type="date" class="form-control" style="display: inline-block; width: 76%;" name="from" id="from">
                                </div>

                                <div class="form-group  col-md-3">
                                    <label><i class="icon icon-date_range"></i>To</label>
                                    <input type="date" class="form-control" style="display: inline-block; width: 76%;" name="to" id="to">
                                </div>

                                <div class="form-group col-md-2">
                                    <input type="text" class="form-control"  name="text_search" id="text_search"  placeholder="Text Search">
                                </div>
                                {{--Button--}}
                                <div class="col-md-2 float">
                                    <button class="btn btn-primary" type="button" id="search_button">Search</button>
                                </div>
                                {{--Button--}}
                                <div class="col-md-2 float">
                                    <button class="btn btn-danger" type="button" id="reset_button">Reset</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="card">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-body">
                            <table id="log_table" class="display" style="width:100%">
                                <thead>
                                <tr>
                                    <td>@lang('tr.Type')</td>
                                    <td>@lang('tr.Description')</td>
                                    <td>@lang('tr.By')</td>
                                    <td>@lang('tr.Date')</td>
                                    <td></td>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            var show = '{{ route('show_log', ['id'=>'#id']) }}';
            var table = $('#log_table').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                stateSave: false,
                order: [[ 0, "desc" ]],
                rowId: 'id',
                "ajax": {
                    "url": '{{ route('log') }}',
                    "dataSrc": "data.data"
                },
                "columns": [

                    {"data": "type", "name": "type"},
                    {"data": "description", "name": "description"},
                    {"data": "user", "name": "user"},
                    {"data": "date", "name": "date"},
                    {"data": "id", "name": "id" ,
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            if(oData.can_be_viewed==1){
                                var url = show.replace('#id', oData.id);
                                html = "<a href='"+url+"'><i class='icon-eye'></i></a>";
                                $(nTd).html(html);
                            }else{
                                $(nTd).html(html);
                            }
                        }
                    },
                ],
            });

            $(".dataTables_filter").hide();

            $('#search_button').on('click', function () {
                table.search($("#text_search").val());
                table.columns(1).search($("#from").val());
                table.columns(2).search($("#to").val());
                table.draw();
            });

            $('#text_search').on('keyup', function (e) {
                if (e.keyCode == 13)
                    $('#search_button').trigger('click');
            });

            $('#reset_button').on('click', function () {
                $("#from").val("")
                $("#to").val("");
                $("#text_search").val("");
                $('#search_button').trigger('click');
            });
        });
    </script>
@endsection
