@extends('layouts.master')

@section('title',  __('tr.Excuses'))
@section('subtitle', __('tr.Student Excuses') )
@section('titleicon', "icon-coin-pound")


@section('content')
<div class="main-content">
	<div class="row">
        <div class="col-lg-8 col-xs-12 col-md-12 col-sm-12">
        	
        	<div class="card">
				<div class="card-header">@lang('tr.You are about to pay <b>:amount </b>', ['amount' => $userRequest->total_amount])</div>
				 
			</div>
	 
	 
		@include('payments.components.pay')

		</div>
	</div>
	
	<br/>
	<br/>
</div>
@endsection
