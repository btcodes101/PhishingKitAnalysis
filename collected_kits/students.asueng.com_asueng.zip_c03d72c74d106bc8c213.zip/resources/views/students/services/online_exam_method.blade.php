@extends('layouts.master')

@section('title', __('tr.Online Exams Method Confirmation'))
{{-- @section('subtitle', __('tr.Online Exams Method Confirmation') ) --}}
@section('titleicon', "icon-user")


@section('content')
    <div class="main-content">
        
      @if(!empty($errors->all()))
            <div class="alert alert-danger text-white bg-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <ol>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ol>
            </div>
        @endif

      
        <form  action="{{ route('save_online_exams_method') }}" method="POST">
            {{ csrf_field() }}
            <div class="col-lg-6 col-xs-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                            <div class="card-header">
                                @lang('tr.Online Exams Method Confirmation')
                            </div>
                            <div class="card-body">
                               
                                    <div class="form-check">
                                        <input type="radio" name="status" class="form-check-input" @if($oldChoice == 1) checked @endif value="1" >
                                        <label class="form-check-label" ></label><b>@lang('tr.I need to use on-campus computer Labs')</b>
                                    </div>
                                    <br>
                                    <input type="hidden" name="term_id" value="{{$currentTerm->id}}">
                                    <input type="hidden" name="student_id" value="{{$student->id}}">
                                    <div class="card">
                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                                            <div class="card-header">
                                                <p>@lang('tr.under the following conditions:')</p>
                                            </div>
                                            <div class="card-body">
                                                <ol>
                                                    <li>@lang('tr.I will follow the procedures of Sit-in Exams regarding the process and medical condition.')</li>
                                                    <li>@lang('tr.I will follow the same timing announced for the exam.')</li>
                                                </ol>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="form-check">
                                        <input type="radio" name="status" class="form-check-input" @if($oldChoice == 2) checked @endif value="2" >
                                        <label class="form-check-label" ></label><b>@lang('tr.I can manage to take the online exam at home')</b>
                                    </div>

                                    <br>
                                    <div class="card">
                                        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                                            <div class="card-header">
                                                <p>@lang('tr.under the following constraints:')</p>
                                            </div>

                                            <div class="card-body">
                                                <ol>
                                                    <li>@lang('tr.I have a computer.')</li>
                                                    <li>@lang('tr.I have a stable land-line internet connection. An IP detection will be performed, and it will not be allowed that two students connect using the same IP. No use of cellolar internet connection will be allowed.')</li>
                                                    <li>@lang('tr.I have access to a webcam which will be active the whole exam duration.')</li>
                                                    <li>@lang('tr.I confirm to comply with all online exam requirements.')</li>
                                                    <li>@lang('tr.I am totally responsible for the above. In case of failure to take the exam online, I will submit an excuse to re-take the exam later.')</li>
                                                
                                                </ol>
                                            </div>
                                        </div>
                                    </div>

                                
                              
                                <br>
                                 <button type="submit" id='submit_btn' class="btn btn-primary btn-md" >
                                    <span class="icon-edit"></span>  @lang('tr.Submit')
                                </button>
                               
                            </div>
                        </div>
                    </div>
                </div>
        </form>




       

    </div>
@endsection
