@extends('layouts.master')

@section('title',  __('tr.Select Track Preferences'))
@section('titleicon', "icon-file-text")

@section('content')
<div class="main-content">

        <div class="row">
            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
            	<div class="card">
					<div class="card-header">@lang('tr.Select Track Preferences')</div>
					<div class="card-header">@lang('tr.Select Track Preferences Instructions')</div>
					<div class="card-body">

				        <ul id="sortable">
			                @foreach($plans as $plan)
			                <li id="{{$plan->id}}" class="ui-state-default">
			                    <span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
			                    <center>{{$plan->lang('minor')}}</center>
			                </li>
			                @endforeach
			            </ul>
			        </div>
			        <div id='ajax_form_progress_bar' style="background-color: green; width: 0%; height: 2px;"></div>
			    </div>
			</div>
		</div>        

		
		<div class="row gutters">
		    <div class="col-md-12">
		        <button type="button" id="submit" class="btn btn-primary btn-md">
		        <span class="icon-edit"></span>@lang('tr.Submit') <span id="ajax_form_progress_text"></span></button>
		    </div>
		</div>

		<br/>
		<br/>
</div>

<script type="text/javascript">
    $(document).ready(function() {

    	$("#sortable").sortable();
        $("#sortable").disableSelection();

        $('#submit').click(function() {
        	var submitUrl = '{{ route('save_select_track') }}';
        	$.post(submitUrl, 
        		{"_token": '{{ csrf_token() }}', preferences: $("#sortable").sortable('toArray') }, 
        		function(response) {
	                infoBox("@lang('tr.Your request is submitted successfully')", function() {
		                window.location.href = '{{route('dashboard')}}';
		            });
	            }).fail(function(response){
	            	showRepsonseErrors(response);
	            });
        });        
    });
</script>
@endsection
