@extends('layouts.master')

@section('title', 'Final Exam Special Requests')
@section('subtitle', __('tr.Final Exam Special Requests') )
@section('titleicon', "icon-file-text")


@section('content')
<div class="main-content">
    @if(!empty($errors->all()))
        <div class="alert alert-danger text-white bg-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif   
    @if (\Session::has('success'))
        <div class="alert alert-success text-white bg-success">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <ul>
                <li>{!! \Session::get('success') !!}</li>
            </ul>
        </div>
    @endif
<div class="row">
    <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
        <form method="post" action="{{ route('save_exam_special_requests')}}" id="" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="card">
                <div class="card-header"><strong>{{$term->lang('name')}}:</strong></div>
                    <div class="card-body">
                        
                        <div class="form-group">
                            <label class="col-form-label">@lang('tr.Courses')</label>
                            @foreach($studies as $key => $value)
                                <div class="form-check">
                                    <input type="checkbox" @if(in_array($key, $requestedCourses)) checked @endif id="{{$key}}" name="courses[]" value="{{$key}}" class='form-check-input'>
                                    <label class="form-check-label" for="{{$key}}">{{$value}}</label>
                                </div>
                            @endforeach
                        </div>
                        

                        <div class="form-group">
                                <label class="col-form-label">@lang('tr.Request')</label>
                                <select name="type" id="request" class='form-control' required>
                                    <option value=''>@lang('tr.Select')</option>
                                    @foreach(App\StudentSpecialRequest::TYPES as $type)
                                        <option {{($specialRequest && $specialRequest->request == $type)?'selected':''}} value="{{$type}}">{{$type}}</option>
                                    @endforeach
                                </select>
                        </div>

                        <div class="form-group">
                            <label class="col-form-label">@lang('tr.Case')</label>
                            <textarea required name="description" id="description" cols="30" rows="10" class='form-control' >@if($specialRequest) {{$specialRequest->description}} @endif</textarea>
                        </div>

                        <div class="form-group">
                            <label class="col-form-label">@lang('tr.Supporting Documents')</label>
                            <input type="file" class="filestyle form-control" name="attachments[]" data-icon="true" multiple>
                        </div>

                        <div class="form-group">
                            @if($specialRequest)
                                @foreach($specialRequest->files as $file)
                                <span>
                                <i class="icon-file-empty"></i> 
                                    <a target='_blank' href="{{ route('download_file', ['archive_id'=>$file->id]) }}">{{ $file->name() }}</a><br>
                                </span>
                                @endforeach
                            @endif
                        </div>

                        <div class="card">
        
                    </div>
                <div id='ajax_form_progress_bar' style="background-color: green; width: 0%; height: 2px;"></div>
            </div>

            <div class="row gutters">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary btn-md">
                    <span class="icon-edit"></span> Submit</button>
                </div>
            </div>

        </form>
    </div>
</div>        

<br/>
<br/>
</div>

@endsection

@section('js')
    <script type="text/javascript">
        $(document).ready(function () {
             
             
        	
                

        }); 

        })
    </script>
@endsection
