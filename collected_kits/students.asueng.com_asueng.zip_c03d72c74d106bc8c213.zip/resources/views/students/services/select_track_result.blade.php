@extends('layouts.master')

@section('title',  __('tr.Enrolled in Program'))
@section('titleicon', "icon-file-text")

@section('content')
<div class="main-content">

         <div class="row">
            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
            	<div class="card">
					<div class="card-header">@lang('tr.Enrolled in Program'):</div>
					<div class="card-body">

						@if ($payment_status == 'Paid')
							<div class="form-group">
								@if($newPlan)
									<label class="col-form-label">{{$newPlan->lang('minor')}}</label>
								@else
									<label class="col-form-label">@lang('tr.Out of Preferences')</label>
								@endif
                       		 </div>
						@else
						<p> @lang('tr.Please pay tuition fees')</p>
 						@endif
					</div>
			        
			    </div>
			    <hr/>
			</div>
		</div>        
  	<br/>
	<br/>
</div>

@endsection
