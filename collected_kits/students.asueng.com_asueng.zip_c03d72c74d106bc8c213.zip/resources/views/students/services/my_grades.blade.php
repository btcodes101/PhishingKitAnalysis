@extends('layouts.master')

@section('title', $student->user->lang('name'))
@section('subtitle', __('tr.StudentInfo') )
@section('titleicon', "icon-user")


@section('content')
    <div class="main-content">
        
       

       

        
        @if($student->last_plan_id)
            <div class="row gutters ComBody">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-header" role="tab" id="cardheadingTwo">
                            <a data-toggle="collapse" href="#collapseCardTwo" aria-expanded="true"
                               aria-controls="collapseCardTwo" class="">
                                <span class="icon-media-play"></span>
                                @lang('tr.Study Grades')
                            </a>
                            
                            <label class="float-right">
                                <input type="checkbox" class="success-year">
                                <i class="icon icon-bookmarks2"></i> @lang('tr.Success Courses')
                            </label>
                        </div>

                        <div id="collapseCardTwo" class="collapse show" role="tabpanel"
                             aria-labelledby="cardheadingTwo" style="">
                        @if($student->isCreditHours())
                            <div class="card-body">
                                @lang('tr.Study Plan'): {{$student->plan->lang('major')}}, {{$student->plan->lang('minor')}}, @lang('tr.Credit Hours'),
                                @if($student->gradeTotal)
                                    @lang('tr.General Grade') <span class="badge badge-pill badge-info">{{$student->gradeTotal->grade_gpa}}</span>, @lang('tr.Project Grade') <span class="badge badge-pill badge-info">{{$student->gradeTotal->project_gpa}}</span>, @lang('tr.Credit Hours') ({{$student->gradeTotal->credit_hours}}) 
                                @endif
                            </div>
                            <div class="card-body">
                                <table class="table m-0" style="width:100%; border-collapse:collapse;">
                                    <thead class="thead-default">
                                    <tr>
                                        <th width="25%">@lang('tr.StudyPlan')</th>
                                        <th width="15%">@lang('tr.Term')</th>
                                        <th width="10%">@lang('tr.StudyYear')</th>
                                        <th width="15%">@lang('tr.Level')</th>
                                        <th width="15%">@lang('tr.Grade')</th>
                                        <th width="15%">@lang('tr.Cumulative')</th>
                                        <th width="5%"></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($student->gradesTerms as $gradeTerm)
                                        @if($gradeTerm->level)
                                        <tr>
                                            <td>{{$gradeTerm->plan->lang('minor')}}</td>
                                            <td>{{$gradeTerm->term->lang('name')}}</td>
                                            <td>{{$gradeTerm->term->years}}</td>
                                            <td>{{$gradeTerm->getLevel->lang('name')}}</td>
                                            <td>{{gpaRound($gradeTerm->grade_gpa)}} / {{$gradeTerm->credit_hours}} @lang('tr.Hours')</td>
                                            <td>{{gpaRound($gradeTerm->cumulative_gpa)}} / {{$gradeTerm->cumulative_credit_hours}} @lang('tr.Hours')</td>
                                            <td class="show" style="cursor: pointer"><i class="icon-eye"></i></td>
                                        </tr>
                                        <tr style="display: none;">
                                            <td colspan="8" style="padding: 0px;">
                                                <table class="table table-sm m-0">
                                                    <thead class="thead-default">
                                                    <tr>
                                                        <th width="10%">@lang('tr.CourseCode')</th>
                                                        <th width="35%">@lang('tr.CourseName')</th>
                                                        <th width="15%">@lang('tr.Term')</th>
                                                        <th width="5%">@lang('tr.Grade')</th>
                                                        <th width="15%">@lang('tr.Credit Hours')</th>
                                                        <th width="5%">@lang('tr.Status')</th>
         
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    @foreach($gradeTerm->getGrades() as $grade)
                                                        <tr @if( $grade->failed()) class="hide" @endif>
                                                            <td>{{$grade->course->getCode()}}</td>
                                                            <td>{{$grade->course->lang('name')}}</td>
                                                            <td>@if($grade->term){{$grade->term->lang('name')}} @endif</td>
                                                            <td>{{ $grade->calculateGradeLetter() }}</td>
                                                            <td>{{$grade->course->credit_hours}} @lang('tr.Hours')</td>
                                                            <td>{{$grade->gradeState->lang('name')}}</td>
            
                                                        </tr>
                                                    @endforeach
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        @endif
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <div class="card-body">
                                @lang('tr.Study Plan'): {{$student->plan->lang('major')}}, {{$student->plan->lang('minor')}} 

                                @if($student->gradeTotal && $student->gradeTotal->gerneralGrade)
                                    @lang('tr.General Grade') <span class="badge badge-pill badge-info">{{$student->gradeTotal->gerneralGrade->lang('name')}}</span>, @lang('tr.Project Grade') <span class="badge badge-pill badge-info">{{$student->gradeTotal->projectGrade->lang('name')}}</span>
                                @endif
                            </div>
                            <div class="card-body">
                                <table class="table m-0" style="width:100%; border-collapse:collapse;">
                                    <thead class="thead-default">
                                    <tr>
                                        <th>@lang('tr.Study Plan')</th>
                                        <th>@lang('tr.Group')</th>
                                        <th>@lang('tr.StudyYear')</th>
                                        <th>@lang('tr.Total')</th>
                                        <th>@lang('tr.MaxDegree')</th>
                                        <th>@lang('tr.Grade')</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @php($gradesTerms = $user->student->gradesTerms)
                                    @for($i=0;$i<count($gradesTerms);$i++)
                                        @php($gradeTerm = $gradesTerms[$i])
                                        @if(($gradeTerm->year<4 && in_array($gradeTerm->grade_type, [0,1,2,3,4,5]))||$i==(count($gradesTerms)-1))
                                        <tr>
                                            <td>{{$gradeTerm->plan->name()}}</td>
                                            <td>{{$gradeTerm->term->years}}</td>
                                            <td>{{$gradeTerm->term->lang('name')}}</td>
                                            <td>{{$gradeTerm->total}}</td>
                                            <td>{{$gradeTerm->max_total}}</td>
                                            <td>{{$gradeTerm->gradeType->lang('name')}}</td>
                                            <td class="show" style="cursor: pointer"><i class="icon-eye"></i></td>
                                        </tr>
                                        <tr style="display: none;">
                                            <td colspan="8" style="padding: 0px;">
                                                <table class="table table-sm m-0">
                                                    <thead class="thead-default">
                                                    <tr>
                                                        <th>@lang('tr.CourseCode')</th>
                                                        <th>@lang('tr.CourseName')</th>
                                                        <th>@lang('tr.Term')</th>
                                                        <th>@lang('tr.Grade')</th>
                                                        <th>@lang('tr.Status')</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    @foreach($user->student->grades($gradeTerm->year)->get() as $grade)
                                                        @if($grade->course->elective_base==0)
                                                        <tr @if( $gradeTerm->term_id != $grade->term_id) class="hide" @endif>
                                                            <td style="text-decoration: {{($grade->course->elective)?"underline":""}}">{{$grade->course->getCode()}}</td>
                                                            <td>{{$grade->course->lang('name')}}</td>
                                                            <td>{{$grade->term->lang('name')}}</td>
                                                            <td>{{$grade->gradeNote->lang('name')}}</td>
                                                            <td>{{$grade->gradeState->lang('name')}}</td>
                                                        </tr>
                                                        @endif
                                                    @endforeach
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        @endif
                                    @endfor
                                    </tbody>
                                </table>
                            </div>
                        @endif
                        </div>
                    </div>
                </div>
            </div>

            @if(!$student->isCreditHours())
            <div class="row gutters ComBody">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-header" role="tab" id="cardheadingThree">
                            <a data-toggle="collapse" href="#collapseCardThree" aria-expanded="true"
                               aria-controls="collapseCardThree" class="">
                                <span class="icon-media-play"></span> Examinations Details
                            </a>
                        </div>

                        <div id="collapseCardThree" class="collapse show" role="tabpanel"
                             aria-labelledby="cardheadingThree" style="">                            
                            <div class="card-body">
                                <table class="table m-0" style="width:100%; border-collapse:collapse;">
                                    <thead class="thead-default">
                                    <tr>
                                        <th>@lang('tr.BenchNumber')</th>
                                        <th>@lang('tr.Group')</th>
                                        <th>@lang('tr.StudyYear')</th>
                                        <th>@lang('tr.Total')</th>
                                        <th>@lang('tr.Grade')</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($user->student->gradesTerms as $gradeTerm)
                                        <tr>
                                            <td>{{$gradeTerm->bn}}</td>
                                            <td>{{$gradeTerm->term->years}}</td>
                                            <td>{{$gradeTerm->term->lang('name')}}</td>
                                            <td>{{$gradeTerm->total}}</td>
                                            <td>{{$gradeTerm->gradeType->lang('name')}}</td>
                                            <td class="show" style="cursor: pointer"><i class="icon-eye"></i></td>
                                        </tr>
                                        <tr style="display: none;">
                                            <td colspan="8" style="padding: 0px;">
                                                <table class="table table-sm m-0">
                                                    <thead class="thead-default">
                                                    <tr>
                                                        <th>@lang('tr.CourseCode')</th>
                                                        <th>@lang('tr.CourseName')</th>
                                                        <th>@lang('tr.Grade')</th>
                                                        <th>@lang('tr.Status')</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    @foreach($gradeTerm->getGrades() as $grade)
                                                        @if($grade->course->elective_base==0)
                                                        <tr>
                                                            <td style="text-decoration: {{($grade->course->elective)?"underline":""}}">{{$grade->course->getCode()}}</td>
                                                            <td>{{$grade->course->lang('name')}}</td>
                                                            <td>{{$grade->gradeNote->lang('name')}}</td>
                                                            <td>{{$grade->gradeState->lang('name')}}</td>
                                                        </tr>
                                                        @endif
                                                    @endforeach
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif            
        
        @endif
    </div>
@endsection

@section('js')
    <script type="text/javascript">
        $(document).ready(function () {
            $(document).on('click', '.show', function () {
                $(this).parent().next('tr').toggle(300);
                $(this).nextAll('i').toggleClass('icon-eye').toggleClass('icon-eye-blocked')
            });
            $(document).on('click', '.success-year', function () {
                if ($(this).is(':checked')) {
                    $('.hide').hide();
                } else {
                    $('.hide').show();
                }
            })
        })
    </script>
@endsection
