@extends('layouts.master')

@section('title',  __('tr.Transfer Between Programs'))
@section('titleicon', "icon-file-text")

@section('content')
<div class="main-content">

    <form action='{{route("save_transfer_to_plan")}}' method='post'>
        @csrf
        <div class="row">
            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">@lang('tr.Transfer Between Programs')</div>
                        @if(Session::has('message'))
                            <div class="card-header">
                                <div class="alert alert-danger" role="alert">
                                {{ session()->get('message') }}
                                </div>
                            </div>
                        @endif
                        <div class="card-body">

                            <div class="form-group">
                                <select class="form-control" name='plan_id' required>
                                    <option value="">@lang('tr.Select')</option>
                                    @foreach($plans as $plan)
                                        <option value="{{$plan->id}}">{{$plan->lang('minor')}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
			</div>
		</div>        
		
		<div class="row gutters">
		    <div class="col-md-12">
                <input type="submit" value="@lang('tr.Submit')" class="btn btn-primary btn-md">
		    </div>
		</div>
    </form>
 
</div>

 
@endsection
