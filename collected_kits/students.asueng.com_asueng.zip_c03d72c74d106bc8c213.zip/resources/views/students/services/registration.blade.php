@extends('layouts.master')

@section('title',  __('tr.Courses registration'))
@section('titleicon', "icon-file-text")

<style type="text/css">
    label {
        margin-left: 2%;
    }
</style>

@section('content')
<div class="main-content">
    <form id='submit_form' action="#" method="POST" >
        
        {{ csrf_field() }}
        
       
        <div class="row">

            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
            
                
                <div class="card">
                    <div class="card-header">
                        @lang('tr.Courses')
                    </div>
                    <div class="card-body">
                    @php
                        $firatTimeFrahman = $student->firstTime();
                    @endphp
                    <!-- For freshman only -->
                    @if($firatTimeFrahman)
                        @if(count($courses) > 0)
                            @foreach ($courses as $course)
                                @php
                                if($course->elective == 1 && $course->set_number != $set) 
                                    continue;
                                @endphp
                                <div class="form-check">
                                    <input type="hidden" value="{{$set}}"  name="set"  id="set">
                                    <label class="form-check-label" for="defaultCheck1">
                                        {{$course->en_name}} 
                                    </label>
                                </div>
                            @endforeach
                        @else
                         <p>@lang('tr.You have no courses to register')</p>
                        @endif
                    @endif
                    <!-- /For freshman only -->
                    

                    <!-- For the rest of plans-->
                    @if(!$firatTimeFrahman)
                        @if(count($courses) > 0)
                            @foreach ($courses as $course)
                                @php
                                    //get all sections for this course
                                    $sections = $course->getSections($course->planID);
                                   

                                    if($course->studies != null)
                                        $checked = 'checked';
                                    else
                                        $checked = '';

                                    if(empty($sections) && $checked == '') //this courses has no empty sections
                                        continue;
                                @endphp
                                
                                <div class="form-check">
                                    <input class="form-check-input" {{$checked}} type="checkbox" value="{{$course->id}}"  name="course_id">
                                    <label class="form-check-label" for="defaultCheck1">
                                        {{$course->en_name}} : {{$course->short_name}}
                                    </label>
                                </div>
                                <div class="form-group">
                                    <select id="{{$course->id}}" name="{{$course->id}}"  class="form-control sections" required>
                                            @if($course->group != null && $course->section_name  != null)
                                                <option selected value='{{$course->group}}'>{{$course->en_minor}} : {{$course->section_name}}</option>
                                            @else
                                                <option value='0'>@lang('tr.Select section')</option>
                                            @endif
                                            @foreach ($sections as $section)
                                                @if($course->group != $section->group_id)
                                                     <option value='{{$section->group_id}}'>{{$section->en_minor}} : {{$section->section_name}}</option>
                                                @endif
                                            @endforeach
                                    </select>
                                </div>
                                <br>
                            @endforeach
                        @else
                            <p>@lang('tr.You have no courses to register')</p>
                        @endif
                        </div>
                    @endif
                    <!-- /For the rest of plans-->

                </div>
                <hr/>






                <div class="card">
                    <div class="card-header">
                        @lang('tr.GeneralInformation'):  
                    </div>
                    <div class="card-body">
                                <p>Advisor: 
                                    @php
                                        if(isset($student->advisor->en_name)){echo $student->advisor->en_name;}
                                    @endphp
                                </p>
                                @if($firatTimeFrahman)
                                    <p>{{$groupSectionName}}</p>
                                @endif
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        @lang('tr.Time Tables'):  
                    </div>
                    <div class="card-body">
                        <p><a target="blank" href="https://portal.eng.asu.edu.eg/archive/download/240107">Freshman</a></p>
                        <p><a target="blank" href="https://portal.eng.asu.edu.eg/archive/download/240108">Mechanical</a></p>
                        <p><a target="blank" href="https://portal.eng.asu.edu.eg/archive/download/240109">Architecture</a></p>
                        <p><a target="blank" href="https://portal.eng.asu.edu.eg/archive/download/240110">Civil</a></p>
                        <p><a target="blank" href="https://portal.eng.asu.edu.eg/archive/download/240111">Electrical</a></p>
                    </div>
                </div>

                
                <hr/>
                @if(count($courses) > 0)
                <button id='submit' type="submit" class="btn btn-primary btn-md"> @lang('tr.Submit')</button>
                @endif
           
                

            </div>

        </div>

        <br/>
        <br/>

    </form>
</div>


@endsection

@section('pagejs')
<script type="text/javascript">
    $(document).ready(function () {
        $("#submit_form").submit(function(e){

            e.preventDefault();


            var courses = [];
            var sections = [];
            var errorNumner = 0;

            $.each($("input[name='course_id']:checked"), function(){  
                sectionID = $('#'+$(this).val()).val(); 
                
                if(sectionID == 0){
                    errorNumner = 1;
                }

                courses.push($(this).val());
                sections.push($('#'+$(this).val()).val());
            });

            if(courses.length === 0){
                errorNumner = 2;
            }
            $set = $('#set').val();
            if($set) { //disable the submission of the new freshmen
                errorNumner =3; 
            } 
          
            if(errorNumner == 0){
                $("#submit").attr("disabled", true);
                var submitUrl = '{{ route('save_courses_registration') }}';
                $.post(submitUrl, {"_token": '{{ csrf_token() }}', "set": $('#set').val(), "sections": sections, 'courses':  courses},
                    function (response) {
                        infoBox("@lang('tr.Your request is submitted successfully')", function () {
                            $("#submit").attr("disabled", false);
                            window.location.reload(); 
                        });
                }).fail(function (response) {
                    showRepsonseErrors(response);
                    $("#submit").attr("disabled", false);
                });
            }else if(errorNumner == 1){
                errorBox("@lang('tr.Please choose the section for each course you registered')", function () {
                            $("#submit").attr("disabled", false);
                });
            }else if(errorNumner == 2){
                errorBox("@lang('tr.Please select at least one course to register')", function () {
                            $("#submit").attr("disabled", false);
                });
            }else if(errorNumner == 3){
                infoBox("@lang('tr.Your request is submitted successfully')", function () {
                            $("#submit").attr("disabled", false);
                            window.location.reload(); 
                        });
            }

        });
    });
</script>
@endsection
