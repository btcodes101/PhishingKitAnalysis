@extends('layouts.master')

@section('title', $student->user->lang('name'))
@section('subtitle', __('tr.StudentInfo') )
@section('titleicon', "icon-user")


@section('content')
    <div class="main-content">

        <style type="text/css">
            required {
                color: red;
                font-weight: bold;
                font-size: 120%;
            }
        </style>

        @if(!empty($errors->all()))
            <div class="alert alert-danger text-white bg-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="row">
            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                <div class="card">
                    <div class="card-header">@lang('tr.Student Information')</div>
                    <div class="card-body">
                        <form action="{{ route('update_student_post', $student->id) }}" method="POST">
                            {{ csrf_field() }}
                           
                            <div>
                               <label class="col-form-label">@lang('tr.Name') <required>*</required></label>
                            </div>
                                <div class="form-group row row gutters">
                                    
                                <div class="col-4">
                                    <input type="text" name="first_name" id="first_name" placeholder="First Name" value="{{ field($data, 'first_name') }}" class="form-control" required style="direction: ltr;">
                                </div>
                                 <div class="col-4">
                                    <input type="text" name="middle_name" id="middle_name" placeholder="Middle Name" value="{{ field($data, 'middle_name') }}" class="form-control" required style="direction: ltr;">
                                </div>
                                 <div class="col-4">
                                    <input type="text" name="last_name" id="last_name" placeholder="Last Name" value="{{ field($data, 'last_name') }}" class="form-control" required style="direction: ltr;">
                                </div>
                            </div>
                           
                         
                         
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.EnglishName') <required>*</required></label>
                                <div class="col-sm-9">
                                    <input type="text" name="en_name" id="en_name" value="{{ field($data, 'en_name') }}" class="form-control" required style="direction: ltr;">
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.ArabicName') <required>*</required></label>
                                <div class="col-sm-9">
                                    <input type="text" name="ar_name" id="ar_name" value="{{ field($data, 'ar_name') }}" class="form-control" required style="direction: rtl;">
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.Birthdate') <required>*</required></label>
                                <div class="col-sm-9">
                                    <input type="date" name="birth_date" id="birth_date" value="{{ field($data, 'birth_date') }}" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.Personal Email') <required>*</required></label>
                                <div class="col-sm-9">
                                    <input type="email" name="email_alt" id="email_alt" value="{{ field($data, 'email_alt') }}" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.Gender') <required>*</required></label>
                                <div class="col-sm-9">
                                    {!! Form::select('gender', array(''=>__('tr.Select Gender'))+$user::gendersLabels(), $user->gender, array('id'=> 'gender', 'title'=> __('tr.Select Gender'), 'class'=>'form-control' )) !!}
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.Address')</label>
                                <div class="col-sm-9">
                                    <input type="text" name="address" id="address" value="{{ field($data, 'address') }}" class="form-control" style="direction: rtl;">
                                </div>
                            </div>
                          
                                <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.Second Address')</label>
                                <div class="col-sm-9">
                                    <input type="text" placeholder="Second Address" name="second_address_line" id="second_address_line" value="{{ field($data, 'second_address_line') }}" class="form-control" style="direction: rtl;">
                                </div>
                            </div>
                            
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.Postal Code')</label>
                                <div class="col-sm-9">
                                    <input type="text" placeholder="Postal Code" name="postal_code" id="postal_code" value="{{ field($data, 'postal_code') }}" class="form-control" style="direction: ltr;">
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.Passport Number') </label>
                                <div class="col-sm-9">
                                    <input type="text" placeholder="Passport Number" name="passport" id="passport" value="{{ field($data, 'passport') }}" class="form-control" style="direction: ltr;">
                                </div>
                            </div>
                           
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.Mobile') <required>*</required></label>
                                <div class="col-sm-9">
                                    <input type="text" name="mobile" id="mobile" value="{{ field($data, 'mobile') }}" class="form-control" required style="direction: ltr;">
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.Phone')</label>
                                <div class="col-sm-9">
                                    <input type="text" name="phone" id="phone" value="{{ field($data, 'phone') }}" class="form-control" style="direction: ltr;">
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <label class="col-sm-3 col-form-label">@lang('tr.More')</label>
                                <div class="col-sm-9">
                                    <textarea type="text" name="more" id="more" value="" class="form-control"  style="direction: rtl;">{{ field($data, 'more') }}</textarea>
                                </div>
                            </div>
                            <hr>
                            <div class="form-group">
                                <input type="submit" value="Update" class="btn btn-primary float-right">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script type="text/javascript">
        $(document).ready(function () {
            
        })
    </script>
@endsection
