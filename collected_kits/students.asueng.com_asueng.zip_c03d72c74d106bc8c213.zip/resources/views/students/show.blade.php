@extends('layouts.master')

@section('title', $student->user->lang('name'))
@section('subtitle', __('tr.StudentInfo') )
@section('titleicon', "icon-user")


@section('content')
    <div class="main-content">

        <div class="alert alert-warning">
            <i class="icon-flash"></i><strong>@lang('tr.Heads up!')</strong> @lang('tr.These information are missing and need to be provided.')
            <br>
            @foreach($errors as $error)
                @if($error != '')
                    {{ $error }},
                @endif
            @endforeach
        </div>
        
        @include('users.components.info',['user'=>$user, 'from'=>'students'])

        <div class="row gutters ComBody">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    @if($student->hasModificationRequest())
                    <div class="alert alert-warning">
                        <i class="icon-warning2"></i>
                        @lang('tr.Your modification request is submitted, soon it will be checked.')
                    </div>
                    @endif
                @php($externalProgramRegisteration = $student->externalProgramRegisteration())
                
                <div class="card">
                    
                    <div class="card-header" role="tab" id="cardheadingTwo">
                        <a data-toggle="collapse" href="#collapseStudentInformation" aria-expanded="true"
                           aria-controls="collapseCardTwo" class="">
                            <span class="icon-media-play"></span> @lang('tr.Student Information')
                        </a>

                        @if($checkStudent == 1)
                        <a href="{{route('update_student',['id'=> $student->id])}}"
                           class="btn stdf-btn  btn-sm float-right">
                            <span class="icon-edit"></span> @lang('tr.Edit')
                        </a>
                        @endif

                    </div>

                    <div id="collapseStudentInformation" class="collapse show" role="tabpanel"
                         aria-labelledby="cardheadingTwo"
                         style="">
                        <div class="card-body">
                            <table class="table table-striped m-0">
                                <tbody>
                                <tr>
                                    <th scope="row" width="180px">@lang('tr.Code')</th>
                                    <td>{{ $user->code }}</td>
                                </tr>
                                @if($user->first_name)
                                <tr>
                                   <th scope="row" width="180px">@lang('tr.First Name')</th>
                                  
                                    <td>
                                       {{$user->first_name }}
                                    </td>    
                                </tr>
                                @endif
                                @if($user->middle_name)
                                <tr>
                                   <th scope="row" width="180px">@lang('tr.Middle Name')</th>
                                    <td>{{ $user->middle_name }}</td>
                               
                                </tr>
                                @endif
                                @if($user->last_name)
                                <tr>
                                   <th scope="row" width="180px">@lang('tr.Last Name')</th>
                                    <td>{{ $user->last_name }}</td>
                               
                                </tr>
                                @endif
                                <tr>
                                    <th scope="row">@lang('tr.ArabicName')</th>
                                    <td>
                                        <div style="direction: rtl">{{ $user->ar_name }}</div>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">@lang('tr.Plan')</th>
                                    <td>@if($student->last_plan_id){{ $student->plan->getBylaw->lang('name') }}, {{ $student->plan->name() }}@endif</td>
                                </tr>
                                @if($externalProgramRegisteration)
                                <tr>
                                <th scope="row" width="180px">@lang('tr.East London')</th>
                                <td>{{$externalProgramRegisteration->externalProgram->name}},
                                    {{$externalProgramRegisteration->statusName()}}
                                    @if($externalProgramRegisteration->comment)
                                     :{{$externalProgramRegisteration->comment}}
                                    @endif
                                </td>
                                </tr>   
                                @endif
                                
                                <tr>
                                    <th scope="row">@lang('tr.Birthdate')</th>
                                    <td>
                                        <div style="direction: rtl">{{ $user->birth_date }}, {{ ($student->birthCountry)?$student->birthCountry->lang('name'):'' }}, {{ $student->lang('birth_city') }}</div>
                                    </td>
                                <tr>
                                    <th scope="row">@lang('tr.Gender')</th>
                                    <td>{{$user->genderLabel()}}</td>
                                </tr>                                
                                @if($student->nationality_country_id=="EGY")
                                <tr>
                                    <th scope="row">@lang('tr.NationalID')</th>
                                    <td>{{ $user->national_id }}</td>
                                </tr>
                                @else
                                <tr>
                                    <th scope="row">@lang('tr.Passport No.')</th>
                                    <td>{{ $user->national_id }}</td>
                                </tr>
                                @endif
                                @if($student->nationality_country_id)
                                <tr>
                                    <th scope="row">@lang('tr.Nationality')</th>
                                    <td>
                                        {{ $student->nationality->lang('name') }}
                                        @if($student->other_nationalities)
                                        , {{$student->other_nationalities}}
                                        @endif
                                    </td>
                                </tr>
                                @endif
                                <tr>
                                    <th scope="row">@lang('tr.Email')</th>
                                    <td style="direction: ltr;">{{ $user->email }}, {{ $user->email_alt }}</td>
                                </tr>
                                <tr>
                                    <th scope="row">@lang('tr.High School')</th>
                                    <td>{{ $student->school_certificate_type }}, {{ $student->school_name }}, {{ $student->school_marks }}</td>
                                </tr>
                                @if($student->military_education_status!==null)
                                <tr>
                                    <th scope="row">@lang('tr.Military Education Status')</th>
                                    <td>
                                        @if($student->military_education_status==1)
                                            @lang('tr.Done')
                                        @else
                                            @lang('tr.Not Yet')
                                        @endif
                                    </td>
                                </tr>
                                @endif
                                @if($student->military_status)
                                <tr>
                                    <th scope="row">@lang('tr.Military Status')</th>
                                    <td>
                                        <B>@lang('tr.Status')</B>: {{$student->militaryStatusLabel()}}<br/>
                                        @if($student->military_no)
                                        <B>@lang('tr.Military Number')</B>: {{$student->military_no}}<br/>
                                        @endif
                                        @if($student->military_order)
                                        <B>@lang('tr.Military Order')</B>: {{$student->military_order}}<br/>
                                        @endif
                                        @if($student->military_order_date)
                                        <B>@lang('tr.Military Order Year/Month')</B>: {{$student->military_order_date}}<br/>
                                        @endif
                                        @if($student->military_age)
                                        <B>@lang('tr.Military Age')</B>: {{$student->military_age}}<br/>
                                        @endif
                                    </td>
                                </tr>
                                @endif
                                @if($student->status == 1)
                                    <tr>
                                        <th scope="row">@lang('tr.Student Status')</th>
                                        <td>@lang('tr.Transferred from'), {{$student->transferred_from_university}}, {{$student->transferred_from_faculty}}</td>
                                    </tr>
                                @elseif($student->status == 2)
                                    <tr>
                                        <th scope="row">@lang('tr.Student Status')</th>
                                        <td>@lang('tr.Foreign'), {{$student->foreignStatusLabel()}}</td>
                                    </tr>
                                @endif
                                <tr>
                                    <th scope="row">@lang('tr.Phone')</th>
                                    <td>
                                        @if($user->phone)
                                            <strong>@lang('tr.Phone')</strong>: {{ $user->phone }},
                                        @endif

                                        @if($user->mobile)
                                            <strong>@lang('tr.Mobile')</strong>: {{ $user->mobile }}</td>
                                    @endif
                                </tr>
                                <tr>
                                    <th scope="row">@lang('tr.Address')</th>
                                    <td>
                                        <div style="direction: rtl">{{ $user->address }}</div>
                                    </td>
                                </tr>
                                @if($user->second_address_line)
                                <tr>
                                    <th scope="row">@lang('tr.Second Address')</th>
                                    <td>
                                        <div style="direction: rtl">{{ $user->second_address_line }}</div>
                                    </td>
                                </tr>
                                @endif
                                @if($student->passport)
                                <tr>
                                   <th scope="row" width="180px">@lang('tr.Passport Number')</th>
                                    <td>{{ $student->passport}}</td>
                               
                                </tr>
                                @endif

                                @if($user->postal_code)
                                <tr>
                                   <th scope="row" width="180px">@lang('tr.Postal Code')</th>
                                    <td>{{ $user->postal_code}}</td>
                               
                                </tr>
                                @endif
                                @if($student->graduated)
                                    @if($student->gradeTotal)
                                    <tr>
                                        <th scope="row">@lang('tr.Faculty Approval')</th>
                                        <td>
                                            <div>{{ TransformArabicMonth(\Carbon\Carbon::parse($student->gradeTotal->faculty_approval_at)->format('d M Y')) }}</div>
                                        </td>
                                    </tr>
                                    @endif
                                    @if($student->gradeTotal)
                                    <tr>
                                        <th scope="row">@lang('tr.University Approval')</th>
                                        <td>
                                            <div>{{ TransformArabicMonth(\Carbon\Carbon::parse($student->gradeTotal->university_approval_at)->format('d M Y')) }}</div>
                                        </td>
                                    </tr>
                                    @endif
                                @endif

                                @if($student->parent_name)
                                <tr>
                                    <th scope="row">@lang('tr.Parent Information')</th>
                                    <td>
                                        <B>@lang('tr.Parent Name')</B>: {{$student->parent_name}}<br/>
                                        @if($student->parent_relation)
                                        <B>@lang('tr.Parent Relation')</B>: {{ \App\Student::getParentRelation()[$student->parent_relation]}}<br/>
                                        @endif
                                        @if($student->parent_national_id)
                                        <B>@lang('tr.NationalID')</B>: {{$student->parent_national_id}}<br/>
                                        @endif
                                        @if($student->parent_phone)
                                        <B>@lang('tr.Phone')</B>: {{$student->parent_phone}}<br/>
                                        @endif
                                        @if($student->parent_email)
                                        <B>@lang('tr.Email')</B>: {{$student->parent_email}}<br/>
                                        @endif
                                    </td>
                                </tr>
                                @endif
                                <tr>
                                    <th scope="row" width="180px">@lang('tr.Advisor')</th>
                                    @if($student->advisor)
                                        <td><u>{{$student->advisor->lang('name')}}</u>, {{$student->advisor->email}}, {{$student->advisor->instructor->department->lang('name')}}.</td>
                                    @else
                                        <td>No Advisor</td>    
                                    @endif
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @include('students.components.study_grades')
    </div>
@endsection

@section('js')
    <script type="text/javascript">
        $(document).ready(function () {
            
        })
    </script>
@endsection
