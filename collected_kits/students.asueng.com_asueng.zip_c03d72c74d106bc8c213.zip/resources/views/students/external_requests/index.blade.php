@extends('layouts.master')

@section('title', __("tr.External Students Re-registration Requests"))
@section('subtitle', __("tr.Show Student's External Re-registration Requests" ) )
@section('titleicon', "icon-files-empty")


@section('advancedaction')
<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
    <div class="right-actions">
        <a href="#submit_new_request" class="btn btn-primary float-right" data-target="#submit_new_request" data-toggle="modal" >
            <i class="icon-plus"></i> @lang('tr.Submit New Request')
        </a>
    </div>
</div>
@stop

@section('content')
	<!-- BEGIN .main-content -->
	<div class="main-content">

        @if($errors->any() || session()->has('message'))
            <div class="row gutters">
                <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-body pb-0">
                            <div class="filter-box">
                                <div class="row">
                                    <div class="col-md-12">
                                        @if($errors->any())
                                            @foreach ($errors->all() as $error)
                                                <div class="alert alert-danger-bootstrap" role="alert">
                                                {{ $error }}
                                                </div>
                                            @endforeach
                                        @elseif(session()->has('message'))
                                            <div class="alert alert-success-bootstrap" role="alert">
                                                {{ session()->get('message') }}
                                            </div>
                                        @endif
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif

		<div class="row gutters">
			<div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
				 
			<div class="card">
					<div class="card-body pb-0">
						<div class="filter-box">
							<div class="row">
								<div class="col-md-4">
									{!! Form::select('', array(""=>__("tr.Select Year"))+$years, null, array('id'=> 'year', 'data-placement'=>'top', 'class'=>'form-control', 'title'=> __('tr.Year'))) !!}
								</div>

								<div class="col-md-4">
									{!! Form::select('status', array(""=>__("tr.Select Status"))+$status, null, array('id'=> 'status', 'data-placement'=>'top', 'class'=>'form-control', 'title'=> __('tr.Status'))) !!}
								</div>
								 

								{{--Button--}}
								<div class="col-md-2 float">
									<button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
								</div>

								{{--Button--}}
								<div class="col-md-2 float">
									<button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
								</div>
							</div>
						</div>

					</div>
				</div>

				<div class="card">
					<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
						<div class="card-body">
							<table id="data_table" class="display" style="width:100%">
								<thead>
								<tr>
									<th width="16%">@lang('tr.Modified')</th>
									<th width="25%">@lang('tr.Year')</th>
									<th>@lang('tr.Status')</th>
									<th>@lang('tr.Created At')</th>
									 
								</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Row end -->

        <!-- Modal: submit_new_request -->
        <div class="modal fade" id="submit_new_request" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="">
                        @lang('tr.Submit New Re-re-registration Request')
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post"  action="{{ route('store_external_re_registration_request') }}">
                        {{ csrf_field() }}
                        
                        @if(auth()->user()->student->forceToChangeBylaw())
                        <div class="form-check" style="padding-bottom: 15px;">
                            <input type="checkbox" name='agreed_to_change_to_2018' value='1' class="form-check-input" id="change_to_2018_txt" required>
                            <label style='text-align: justify;' class="form-check-label" for="change_to_2018_txt">
                              {!! __('tr.change_to_2018_txt') !!}
                            </label>
                        </div>
                        @endif

                         <div class="form-group">
                            {!! Form::select('year', array(""=>__("tr.Select Year"))+$years, null, array('name'=> 'year', 'class'=>'form-control', 'required'=> 'required', 'data-placement'=>'top', 'title'=> __('tr.Year'))) !!}
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            <button type="submit" id='submit_new_request_btn' class="btn btn-primary" id=''>@lang('tr.Submit')</button>
                        </div>
                    </form>
                </div>
                </div>
            </div>
        </div>

	</div>
	<!-- END: .main-content -->
    <script type="text/javascript">
	 
		var statusLabels = [];
		var statusBadges = [];

		@foreach(\App\ExternalStudentsRequest::statusLabels() as $key => $label)
				statusLabels[{{ $key }}] = '{{ str_replace('_', ' ', ucfirst($label)) }}';
		@endforeach

		@foreach(\App\ExternalStudentsRequest::statusBadges() as $key => $badge)
			statusBadges[{{ $key }}] = '{{ $badge }}';
		@endforeach

		 

		$(document).ready(function() {
			var table = $('#data_table').DataTable({
				processing: true,
				serverSide: true,
				scrollX: true,
				stateSave: false,
				rowId: 'id',
				order: [
					[ 0, "desc" ]
				],
				"ajax": {
					"url": '{{ route('external_requests_re_registration') }}',
					"dataSrc": "data.data"
				},
				"columns": [
					{ "data": "updated_at", "name": "updated_at"},
					{ "data": "year", "name": "year"},
 					{ "data": "status", "name": "status",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							var html = '';
							html += "<span class='badge badge-" + statusBadges[oData.status] + "'>" + statusLabels[oData.status] + "</span>";
							$(nTd).html(html);
						}
					},
                    { "data": "created_at", "name": "created_at"},
					 
				]
			});

			$(".dataTables_filter").hide();

			$('#search_button').on( 'click', function () {
				table.columns(0).search($("#year").val());
				table.columns(1).search($("#status").val());
				table.draw();
			} );

		 

			$('#reset_button').on( 'click', function () {
				$("#year").val("");
				$("#status").val("");
				$('#search_button').trigger('click');
			});


		});

        

	</script>
	
@stop
