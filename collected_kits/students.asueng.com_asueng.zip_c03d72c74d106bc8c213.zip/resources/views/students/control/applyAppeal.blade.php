@extends('layouts.master')

@section('title', __("tr.Grades Recheck Request"))
@section('subtitle', __("tr.Grades Recheck Request") )
@section('titleicon', "icon-file-text")

@section('content')
<div class="main-content">
    <!-- BEGIN .main-content -->
    <!-- Button trigger modal -->
    <br>
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    @foreach($data as $key => $courses)
        @if(!empty($courses) && count($courses) > 0)
            <div class="row">
                <div class="col-lg-8 col-xs-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header"> <strong>{{$key}}:</strong></div>
                        <div class="card-body">
                            <table class="table table-striped m-0">
                                <thead>
                                    <tr>
                                        <th>@lang('tr.CourseName')</th>
                                        <th>@lang('tr.CourseCode')</th>
                                        <th>@lang('tr.Action')</th>                                
                                        <th>
                                            <span class='d-none' id='feed_{{str_replace(" ", "", $key)}}'>@lang('tr.Your Comment') <br>
                                                <small style='color:red'><i >This text will be displayed to the control</i></small>
                                            </span>
                                        </th>                                
                                        <th>@lang('tr.Feedback')</th>                                
                                    </tr>
                                </thead>
                                <body>
                                        @foreach($courses as $course)
                                            <tr>
                                                <td>{{$course->en_name}}</td>
                                                <td>{{$course->short_name}}</td>
                                                <td>
                                                    @if($course->control_decision == null)
                                                        <input autocomplete="off"  
                                                            type="checkbox" 
                                                            data-study_id="{{$course->id}}" 
                                                            value="{{$course->course_id}}" 
                                                            data-id='{{$course->id}}' 
                                                            data-term_id='{{$course->term_id}}' 
                                                            data-term_name='{{str_replace(" ", "", $key)}}' 
                                                            class='courses courses_{{str_replace(" ", "", $key)}}' />

                                                    @elseif($course->control_decision == 1)
                                                        <button type="submit" 
                                                            class="btn btn-danger btn-sm cancel" 
                                                            data-course_name="{{$course->en_name}}" 
                                                            data-appeal_id='{{$course->appeal_id}}'  
                                                            data-id='{{$course->id}}' 
                                                            data-term_id='{{$course->term_id}}' 
                                                            data-term_name='{{str_replace(" ", "", $key)}}'
                                                        >
                                                            @lang('tr.Cancel')
                                                        </button>
                                                    @endif
                                                </td>
                                                <td>
                                                    <input id='{{$course->id}}' class='form-control d-none' type="text" placeholder='Your Comment'>
                                                </td>
                                                <td>
                                                    @if($course->control_decision == 1)
                                                        <p>@lang('tr.In Review')</p>
                                                    @elseif($course->control_decision == 2)
                                                        <p>@lang('tr.Accepted')</p>
                                                    @elseif($course->control_decision == 3)
                                                        <p>@lang('tr.Rejected')</p>
                                                    @endif
                                                </td>
                                            </tr>
                                        
                                        @endforeach
                                </body>           
                            </table>
                            <br>
                            <button disabled='disabled' autocomplete="off" type="submit" 
                                id='submit_{{str_replace(" ", "", $key)}}' 
                                class="btn btn-primary btn-md submit_btn"  
                                data-term_name='{{str_replace(" ", "", $key)}}'>
                                @lang('tr.Submit')
                                <span id="ajax_form_progress_text"></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    @endforeach
      
</div>  
<!-- END: .main-content -->

 
<script type="text/javascript">
    $(document).ready(function () {

        $('.cancel').on('click', function(e){
            
            var course_name = $(this).data('course_name');
            var appeal_id = $(this).data('appeal_id');
            var deleteUrl = '{{route('cancel_appeal_for_course')}}';
            
            swal({
                title: "Are you sure!",
                text: "This action will delete the appeal of '" + course_name + "' course?",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    
                    $.post(deleteUrl, {"_token": '{{ csrf_token() }}', "appeal_id": appeal_id},
                        function (response) {
                          
                            infoBox("@lang('tr.Your request is submitted successfully')", function () {
                                location.reload()
                            });                      
                        
                    }).fail(function (response) {
                        showRepsonseErrors(response);
                    });
                    
                }  
            });
        });

        $(".submit_btn").on('click' ,function(e){

            var submit_btn = this;
            var term_name = $(this).data('term_name');
            $(submit_btn).attr("disabled", true);

            var totalCost = 0;
            var courses = [];
            var stdComments = [];
            var term_id = 0;
            //var coustPerCourse = {{$coustPerCourse}};

            $(".courses_"+term_name).each(function() {
                var inputId = $(this).data('id');
                term_id = $(this).data('term_id');
                console.log(term_id);
                if($(this).is(":checked")){
                    courses.push( $(this).val());
                    stdComments.push( $("#"+inputId).val());
                }
            });
            
            console.log(term_id);

            var submitUrl = '{{route('std_apply_control_appeal')}}';
            $.post(submitUrl, 
                {"_token": '{{ csrf_token() }}', "courses": courses, 'stdComments': stdComments, 'term_id':term_id},
                function (response) {
                    if(response.status == 'success'){
                        infoBox("@lang('tr.Your request is submitted successfully, please complete the payment to proceed with the appeal.')", function () {
                            $(submit_btn).attr("disabled", false);
                        
                                var requestURL = '{{ route('std_apply_control_appeal_confirm', ['userRequest'=>'#userRequest']) }}';
                                requestURL = requestURL.replace('#userRequest', response.userRequestId);
                                window.location.href = requestURL;      
                        });                      
                    }else{
                        location.reload();
                    }
                   
            }).fail(function (response) {
                showRepsonseErrors(response);
                $("submit_btn").attr("disabled", false);
            });

        });

        $(".courses").on('click', function(e){
            var found = 0;
            var term_name = $(this).data('term_name');
            $(".courses_"+term_name).each(function() {

                var inputId = $(this).data('id');
                

                if($(this).is(":checked")){
                    found++;
                    $('#'+inputId).removeClass('d-none');

                }else{
                    $('#'+inputId).addClass('d-none');
                }
            });

            if(found > 0){
                $('#submit_'+term_name).attr('disabled', false);
                $('#feed_'+term_name).removeClass('d-none');
                
            }else{
                $("#submit_"+term_name).attr("disabled", true);
                $('#feed_'+term_name).addClass('d-none');
                
            }
        })
    });
</script>
@endsection
