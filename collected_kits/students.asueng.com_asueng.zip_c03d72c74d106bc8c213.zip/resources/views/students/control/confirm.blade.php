@extends('layouts.master')

@section('title', __("tr.Appeals") .': '. __("tr.Confirmation"))
@section('subtitle', __("tr.Control Appeals") )
@section('titleicon', "icon-file-text")


@section('content')
<div class="main-content">
	<div class="row">
        <div class="col-lg-8 col-xs-12 col-md-12 col-sm-12">
        	
        	<div class="card">
				<div class="card-header">@lang('tr.You are about to pay <b>:amount </b>', ['amount' => $userRequest->total_amount])</div>
				 
			</div>

		<hr/>
		@include('payments.components.pay')

		</div>
	</div>
	
	<br/>
	<br/>
</div>
@endsection
