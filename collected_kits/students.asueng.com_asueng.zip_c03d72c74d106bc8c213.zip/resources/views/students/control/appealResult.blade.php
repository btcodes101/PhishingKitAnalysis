@extends('layouts.master')

@section('title', __("tr.Appeals Results"))
@section('subtitle', __("tr.Control Appeals") )
@section('titleicon', "icon-file-text")

@section('content')
<style>
    .in_review {
        background-color:orange;
        padding: 10px;
    }
    .accepted {
        background-color: green;
        color: white;
        padding: 10px;
    }
    .rejected {
        background-color: #da3333;
        color: white;
        padding: 10px;
    }

</style>
<div class="main-content">
    <!-- BEGIN .main-content -->
    <br>

    <div class="row">
    @if(count($appelas) > 0)
        @foreach($appelas as $key => $values)
        <div class="col-lg-8 col-xs-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="card-header"> 
                    <strong>{{$key}}:</strong>
                </div>
                <div class="card-body">
                  
                    <table class="table table-striped m-0">
                        <thead>
                            <tr>
                                <th style='width:40%'>@lang('tr.CourseName')</th>
                                <th style='width:30%'>@lang('tr.CourseCode')</th>
                                <th>@lang('tr.Result')</th>                                
                            </tr>
                        </thead>
                        <body> 
                                @foreach($values as $course)
                                    <tr>
                                        <td>{{$course->course_name}}</td>
                                        <td>{{$course->short_name}}</td>
                                        <td>
                                            @if($course->control_decision == 1)
                                                <span class='in_review'>@lang('tr.In Review')</span>
                                            @elseif($course->control_decision == 2)
                                                <span class='accepted'>@lang('tr.Accepted')</span>
                                            @elseif($course->control_decision == 3)
                                               <span class='rejected'>@lang('tr.Rejected')</span>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                        </body>           
                    </table>        
                    
                </div>
            </div>
        </div>
        @endforeach
    @else
    <div class="col-lg-8 col-xs-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="card-header">@lang('tr.You have no appeals.')</div>
                
        </div>
		<hr/>
    @endif
    </div>

      
</div>  
<!-- END: .main-content -->
 
@endsection
