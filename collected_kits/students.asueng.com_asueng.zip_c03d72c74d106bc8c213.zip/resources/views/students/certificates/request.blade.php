@extends('layouts.master')

@section('title',  __('tr.Request Certificate'))
@section('titleicon', "icon-file-text")

@section('content')

<div class="main-content">
	<form id="submit_form"  autocomplete="off" action="{{ route('save_certificate_request', ($userRequest->id!=0)?$userRequest->id:null) }}" method="POST" enctype="multipart/form-data">      
        {{ csrf_field() }}
        
        <input type="hidden" name="request_type" value="2">

		<div class="row">

            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
            	<div class="card">
					<div class="card-header">@lang('tr.General Information')</div>
					<div class="card-body">

						<div class="form-group">
		                    <label>@lang('tr.English Name') <span class="required_field">*</span></label>
		                    <input name="en_name" value="{{dataField($userRequest, 'en_name')}}" type="text" class="form-control" required maxlength="256" style="direction: ltr;" />
		                </div>

		                <div class="form-group">
		                    <label>@lang('tr.Mobile') <span class="required_field">*</span></label>
                            <input name="mobile" value="{{dataField($userRequest, 'mobile')}}" type="text" class="form-control" required maxlength="256"  />
		                </div>
		                
		            </div>
		        </div>

		        <div class="card">
					<div class="card-header">@lang('tr.Request Information')</div>
					<div class="card-body">
						<div class="form-group">
                            <label>@lang('tr.Provided to') <span class="required_field">*</span></label>
                            <input id="apply_to" name="apply_to" value="{{dataField($userRequest, 'apply_to')}}" type="text" class="form-control" required maxlength="256"  />
                        </div>

                        @include('system.components.documents', ['showTitle'=>false])

                        <input type="checkbox" id="mail" name="mail" value="1" {{isset($userRequest->data->mail) && $userRequest->data->mail == 1 ? 'checked disabled' : ''}}/>
                        <label for="mail">@lang('tr.Send By Egypt Post')</label>
		            </div>
		        </div>

		        <div id="shipping_information" class="card">
					<div class="card-header">@lang('tr.Shipping Information')</div>
					<div class="card-body">
						<div class="form-group">
	                        <div class="form-group">
	                            <label>@lang('tr.Shipping Address') <span class="required_field">*</span></label> {{(isset($user->address))?"($user->address)":""}}
	                            <input type="text" id="mail_address" name="mail_address" class="form-control" placeholder="@lang('tr.Address')" value="{{isset($userRequest->data->mail) && $userRequest->data->mail == 1 ? $userRequest->data->mail_address : ''}}"/>
	                        </div>
			            </div>
			        </div>
		        </div>

		        @if($userRequest->order_status=="EMPTY")
				<div class="card">
					<div class="card-header">@lang('tr.Certificates')</div>
					<div class="card-body">
						@include('system.components.certificates')
		            </div>
		        </div>
		        @endif

				<hr/>
		        <button type="submit" id="btnSubmitRequest" class="btn btn-primary btn-md" style="float: {{right()}}"> @lang('tr.Submit')</button>
			</div>

		</div>

		<br/>
		<br/>

	</form>
</div>

<script type="text/javascript">
    $(document).ready(function() {

    	if($('#mail').is(':checked'))
        {
            $('#shipping_information').show();
        }
        else
        {
            $('#shipping_information').hide();
        }

        $('#mail').on('click', function () {
            if($('#mail').is(':checked'))
            {
                $('#shipping_information').show();
            }
            else
            {
                $('#shipping_information').hide();
                $('#mail_address').val("");
            }
        });
        
    });
</script>


@endsection
