@extends('layouts.master')

@section('title',  __('tr.Certificates Requests Status'))
@section('titleicon', "icon-file-text")

@section('content')

<style>
    .userRequestTxt{
        font-size: 15px;
        text-align: left;
        line-height: 40px;   
        cursor:pointer; 
    }

    .table td, .table th{
        padding: 0;
    }

    .card .card-header{
        border-bottom: 0; 
    }

    .card-header{
        border-bottom: 0;
    }

    div.collapse.show, div.collapse{
        background-color: white !important;
    }
</style>

<div class="main-content">
	<div class="row-gutter">
        @php($count = 100)
        @if(count($students_certifications) > 0)
            @foreach ($students_certifications as $certificate)
            @php($count = $certificate->status)
            @endforeach
        @endif

        {{--  Request  --}}
        @foreach($users_requests as $request)
        <div class="accordion" id="accordionExample">
            <div class="card">
                <div class="card-header">
                    <table class="table">
                        <thead>
                            <th class="userRequestTxt" id="heading{{ $request->id }}" data-toggle="collapse" data-target="#collapse{{ $request->id }}" aria-expanded="true" aria-controls="collapse{{ $request->id }}">@lang('tr.Request Name')</th>
                            <th class="userRequestTxt" id="heading{{ $request->id }}" data-toggle="collapse" data-target="#collapse{{ $request->id }}" aria-expanded="true" aria-controls="collapse{{ $request->id }}">@lang('tr.Status')</th>
                            <th class="userRequestTxt" id="heading{{ $request->id }}" data-toggle="collapse" data-target="#collapse{{ $request->id }}" aria-expanded="true" aria-controls="collapse{{ $request->id }}">@lang('tr.Total Amount')</th>
                            <th class="userRequestTxt" >@lang('tr.Count')</th>
                            <th class="userRequestTxt" id="heading{{ $request->id }}" data-toggle="collapse" data-target="#collapse{{ $request->id }}" aria-expanded="true" aria-controls="collapse{{ $request->id }}">@lang('tr.Date')</th>
                            <th class="userRequestTxt" id="heading{{ $request->id }}" data-toggle="collapse" data-target="#collapse{{ $request->id }}" aria-expanded="true" aria-controls="collapse{{ $request->id }}">@lang('tr.Action')</th>
                        </thead>
                    
                        <tbody>
                            <tr>
                                <td class="userRequestTxt" >{{ ucwords(str_replace('_',' ',$request->type)) }}</td>
                                <td class="userRequestTxt" ><span class="badge badge-pill  badge-certificate-status-new show-note" data-value="">{{ ucwords($request->order_status) }}</span></td>
                                <td class="userRequestTxt" >{{ $request->total_amount }}</td>
                                <td class="userRequestTxt" >{{ $students_certifications->where('request_id', $request->id)->sum('print_count') }}</td>
                               <td class="userRequestTxt" >{{ explode(' ',$request->created_at)[0] }}</td>
                                <td class="userRequestTxt">
                                     <a href="{{ route('edit_certificate_request', [$request->id]) }}"><i class="icon-edit"></i></a>
                                    <a href="#" id="heading{{ $request->id }}" data-toggle="collapse" data-target="#collapse{{ $request->id }}" aria-expanded="true" aria-controls="collapse{{ $request->id }}"><i id="show_hide" class="icon-eye-blocked"></i></a>
                                 </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            
                <div id="collapse{{ $request->id }}" class="collapse show" aria-labelledby="heading{{ $request->id }}" data-parent="#accordionExample" style="margin-top: -20px;">
                <div class="card-body">
                    @php($internalStudentCertifcate = $request->internalStudentCertifcateStatus($user->id,$request->id))
                    
                    @if(count($internalStudentCertifcate) > 0)
                    <table class="table">
                        <thead>
                            <th class="userRequestTxt">@lang('tr.Certificate Name')</th>
                            <th class="userRequestTxt">@lang('tr.Status')</th>
                            <th class="userRequestTxt">@lang('tr.Notes')</th>
                        </thead>
                        
                        <tbody>
                            @foreach ($internalStudentCertifcate as $studentCertificate)
                            <tr>
                                <td class="userRequestTxt" width="40%">{{  $studentCertificate->name }}</span></td>
                               <td class="userRequestTxt" width="20%"><span title="" class="badge badge-pill  badge-certificate-status-{{ $studentCertificate->statusBadge() }} show-note" data-value="">{{ $studentCertificate->statusLabel() }}</span></td>
                                <td class="userRequestTxt" width="40%"><span>{{ $studentCertificate->notes }}</span></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @else
                    No Certificates
                    @endif
                </div>
                </div>
            </div>
        </div>
        @endforeach
          

        
    </div>
</div>


@endsection

@section('pagejs')

<script>
    $(document).ready(function(){

        $('#show_hide').on('click',function(){
            if($(this).attr('class') == 'icon-eye-blocked'){
                $(this).removeClass('icon-eye-blocked');
                $(this).addClass('icon-eye');
            } else {
                $(this).removeClass('icon-eye');
                $(this).addClass('icon-eye-blocked');
            }
        });
    
    });
</script>

@endsection