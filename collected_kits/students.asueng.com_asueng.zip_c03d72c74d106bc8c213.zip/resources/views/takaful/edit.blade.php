@extends('layouts.master')

@section('title', __("tr.Edit Takaful info"))
@section('subtitle', __("tr.Edit Takaful info" ) )
@section('titleicon', "icon-file-text")

@section('content')
<style>
 
</style>
	<!-- BEGIN .main-content -->
	<div class="main-content">
		<div class="row gutters">
			<div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
                @include('system.components.notifications')
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                @lang('tr.Request Details')
                            </div>
                            <div class="card-body">
                            <form method="post"  action="{{route('takaful_save', [$takafulRequest->id])}}">
                                {{ csrf_field() }}

                                <div class="form-group">
                                    <label for="">@lang("tr.Guardian Name")</label>
                                    <input type="text" class="form-control" name='guardian_name' value="{{$takafulRequest->guardian_name}}" required>
                                </div>

                                <div class="form-group">
                                    <label for="">@lang("tr.Guardian Occupation")</label>
                                    <input type="text" class="form-control" name='guardian_occupation' value="{{$takafulRequest->guardian_occupation}}" required>
                                </div>

                                <div class="form-group">
                                    <label for="">@lang("tr.Guardian Net Income")</label>
                                    <input type="number" class="form-control" name='guardian_net_income' value="{{$takafulRequest->guardian_net_income}}" required>
                                </div>

                                <div class="form-group">
                                    <label for="">@lang("tr.Guardian Mobile Number")</label>
                                    <input type="text" class="form-control" name='guardian_mobile_number' value="{{$takafulRequest->guardian_mobile_number}}" required>
                                </div>

                                <div class="form-group">
                                    <label for="">@lang("tr.Mother’s Occupation")</label>
                                    <input type="text" class="form-control" name='mother_occupation' value="{{$takafulRequest->mother_occupation}}" required>
                                </div>

                                <div class="form-group">
                                    <label for="">@lang("tr.Mother’s Net Income")</label>
                                    <input type="number" class="form-control" name='mother_net_income' value="{{$takafulRequest->mother_net_income}}" required>
                                </div>


                                <div class="form-group">
                                    <label for="">@lang("tr.Number of Family Members Living with you")</label>
                                    <input type="number" class="form-control" name='number_of_family_members_living_with_you' value="{{$takafulRequest->number_of_family_members_living_with_you}}" required>
                                </div>

                                
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary" id=''>@lang('tr.Submit')</button>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div> 
                </div>
			</div>
		</div>
		<!-- Row end -->
	</div>
	<!-- END: .main-content -->
@stop
