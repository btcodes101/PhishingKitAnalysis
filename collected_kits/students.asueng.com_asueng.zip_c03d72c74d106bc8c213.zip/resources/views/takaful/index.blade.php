@extends('layouts.master')

@section('title', __("tr.Takaful"))
@section('subtitle', __("tr.Takaful Requests List" ) )
@section('titleicon', "icon-file-text")


@section('actiontitle', __('tr.Submit Takaful Request'))
@section('actionlink', '#submit_takaful_request')
@section('dataTarget', '#submit_takaful_request')
@section('dataToggle', 'modal')
@section('actionicon', "icon-plus")

@section('content')
<style>
hr {
    margin-top: 0;
    margin-bottom: 0;
    border-top: 1px solid #000;
}
</style>
	<!-- BEGIN .main-content -->
	<div class="main-content">
		<div class="row gutters">
			<div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">

				@if ($errors->any())
				<div class="card">
					<div class="card-body pb-0">
						<div class="filter-box">
							<div class="row">
								@foreach ($errors->all() as $error)
									<div class="col-md-12">
										<div class="alert alert-danger" role="alert">
											{{$error}}
										</div>
									</div>
								@endforeach
							</div>
						</div>
					</div>
				</div>
				@endif
				 
				<div class="card">
					<div class="card-body pb-0">
						<div class="filter-box">
							<div class="row">
                                 
                                <div class="col-md-3">
									{!! Form::select('term_id', array(""=>__("tr.Term"))+$terms, null, array('id'=> 'term_id', 'class'=>'form-control', 'data-placement'=>'top', 'title'=> __('tr.Term'))) !!}
								</div>

							 
                                <div class="col-md-3">
                                    <select name="status" id="status" class="form-control">
                                        <option value=''>@lang("tr.Select Status")</option>
                                        @foreach(App\TakafulRequest::statusLabels() as $key => $labe)
                                            <option value='{{$key}}'>{{$labe}}</option>
                                        @endforeach
                                    </select>
								</div>
                              
								{{--Button--}}
								<div class="col-md-2 float">
									<button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
								</div>

								{{--Button--}}
								<div class="col-md-2 float">
									<button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
                                </div>
                                
							</div>
						</div>

					</div>
				</div>

				<div class="card">
					<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
						<div class="card-body">
							<table id="data_table" class="display" style="width:100%">
								<thead>
                                    <tr>
                                        <th>@lang('tr.Term')</th>
                                        <th>@lang('tr.Status')</th>
                                        <th>@lang('tr.Discount Amount')</th>
                                        <th>@lang('tr.Discount Type')</th>
                                        <th></th>
                                    </tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Row end -->

        <!-- Modal -->
        <div class="modal fade" id="submit_takaful_request" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="">
                        @lang('tr.Submit Takaful Request')
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post"  action="{{route('takaful_submit')}}">
                        {{ csrf_field() }}
                        <div class="form-group">
							{!! Form::select('term_id', array(""=>__("tr.Term"))+$terms, null, array('id'=> 'term_id', 'class'=>'form-control', 'data-placement'=>'top', 'title'=> __('tr.Term'), 'required'=>'required' )) !!}
                        </div>

						<div class="form-group">
							<input type="text" class="form-control" name='guardian_name' placeholder='@lang("tr.Guardian Name")' required>
						</div>

						<div class="form-group">
							<input type="text" class="form-control" name='guardian_occupation' placeholder='@lang("tr.Guardian Occupation")' required>
						</div>

						<div class="form-group">
							<input type="number" class="form-control" name='guardian_net_income' placeholder='@lang("tr.Guardian Net Income")' required>
						</div>

						<div class="form-group">
							<input type="text" class="form-control" name='guardian_mobile_number' placeholder='@lang("tr.Guardian Mobile Number")' required>
						</div>

						<div class="form-group">
							<input type="text" class="form-control" name='mother_occupation' placeholder='@lang("tr.Mother’s Occupation")' required>
						</div>

						<div class="form-group">
							<input type="number" class="form-control" name='mother_net_income' placeholder='@lang("tr.Mother’s Net Income")' required>
						</div>


						<div class="form-group">
							<input type="number" class="form-control" name='number_of_family_members_living_with_you' placeholder='@lang("tr.Number of Family Members Living with you")' required>
						</div>

						@if(lang() != 'ar')
						<div class="form-group" style='text-align: right;'>
							<span style='color: red;'>إذا أردت تحميل الصفحة باللغة العربية اضغط عربي في الأعلى</span>
						</div>
						@endif

                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" id=''>@lang('tr.Submit')</button>
                        </div>
                    </form>
                </div>
                </div>
            </div>
        </div>
       
	</div>
	<!-- END: .main-content -->

	<script type="text/javascript">
		
        var statusLabels = [];
		var statusBadges = [];

        @foreach(\App\TakafulRequest::statusLabels() as $key => $label)
				statusLabels[{{ $key }}] = '{{ str_replace('_', ' ', ucfirst($label)) }}';
		@endforeach

		@foreach(\App\TakafulRequest::statusBadges() as $key => $badge)
			statusBadges[{{ $key }}] = '{{ $badge }}';
		@endforeach
		 
		var editTakafulURL = '{{ route('takaful_edit', ['id'=>'#id']) }}';

		$(document).ready(function() {
			var table = $('#data_table').DataTable({
				processing: true,
				serverSide: true,
				scrollX: true,
				stateSave: false,
				rowId: 'id',
				order: [
					[ 0, "desc" ]
				],
				"ajax": {
					"url": '{{ route('takaful') }}',
					"dataSrc": "data.data"

				},
				"columns": [
					{ "data": "term_name", "name": "term_name"},
					{ "data": "status", "name": "status",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							var html = '';
							html += "<span class='badge badge-" + statusBadges[oData.status] + "'>" + statusLabels[oData.status] + "</span>";
							$(nTd).html(html);
						}
					},
					{ "data": "discount_amount", "name": "discount_amount",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							var html = '';
							if(oData.status == {{App\TakafulRequest::STATUS_ACCEPTED}}){
								html = oData.discount_amount;
							}else{
								html = '-';
							}
							$(nTd).html(html);
						}
					},
					{ "data": "discount_type", "name": "discount_type",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							var html = '';
							if(oData.status == {{App\TakafulRequest::STATUS_ACCEPTED}}){
								html = oData.discount_type;
							}else{
								html = '-';
							}
							$(nTd).html(html);
						}
					},
					{
                        "data": "id", "name": "id",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            if(oData.status == {{App\TakafulRequest::STATUS_IN_PROGRESS}}){
								html += "<a title='@lang('tr.Edit')' target='_blank' href='" + editTakafulURL.replace('#id', oData.id) + "'><i class='icon-edit'></i></a>&nbsp;";
							}
							$(nTd).html("<span class='action-column'>" + html + "</span>");
                        }
                    }
				]
			});

			$(".dataTables_filter").hide();

			$('#search_button').on( 'click', function () {
				table.columns(0).search($("#term_id").val());
				table.columns(1).search($("#status").val()); 
				table.draw();
			} );

		 

			$('#reset_button').on( 'click', function () {
				$("#term_id").val("");
				$("#status").val("");
				$('#search_button').trigger('click');
			});


		});
	</script>
@stop
