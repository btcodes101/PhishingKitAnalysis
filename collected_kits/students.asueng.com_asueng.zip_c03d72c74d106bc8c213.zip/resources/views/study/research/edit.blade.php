@extends('layouts.master')

@section('title',  __('tr.My Research') )
@section('titleicon', "icon-lab" )

@section('content')

<!-- BEGIN .main-content -->
<div class="main-content">

    @if(!empty($errors->all()))
        <div class="alert alert-danger text-white bg-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    
    <form action="{{ route('save_research') }}" method="POST">
        {{ csrf_field() }}

    <div class="card">
        <div class="card-header">                
            @lang('tr.My Research Plan')
        </div>

        <div class="card-body">
            <div class="form-group">
                <lable>@lang('tr.Research Plan')</lable>
                {!! Form::select('research_plan_id', array(''=>__('tr.Select Research Plan'))+$researchPlans, ($research)?$research->research_plan_id:null, array('id'=> 'research_plan_id', 'class'=>'', 'required'=>'required' )) !!}
            </div>

            <div class="form-group">
                <lable>@lang('tr.English Title')</lable>
                <input class="form-control" type="text" name="en_title" id="en_title" value="{{field($research, 'en_title')}}" minlength="8" maxlength="512" required>
            </div>

            <div class="form-group">
                <lable>@lang('tr.Arabic Title')</lable>
                <input class="form-control" style="direction: rtl;" type="text" name="ar_title" id="ar_title" value="{{field($research, 'ar_title')}}" minlength="8" maxlength="512" required>
            </div>

            @php($archive = $student->user->archive->findChildByContentType('Research Plan'))
            <div class="form-group">
                <lable>@lang('tr.English Abstract')</lable>
                <textarea name="en_abstract" id="en_abstract" required>@if($archive) {!! $archive->getLocale('en')->page() !!}@endif</textarea>
            </div>

            <div class="form-group">
                <lable>@lang('tr.Arabic Abstract')</lable>
                <textarea name="ar_abstract" id="ar_abstract" required>@if($archive) {!! $archive->getLocale('ar')->page() !!}@endif</textarea>
            </div>
            
        </div>
    </div>
    <hr/>
    <button type="submit" class="btn btn-primary btn-md"> @lang('tr.Submit')</button>
    <br/>
    <br/>
    </form>
</div>
@endsection

@section('pagejs')
    <script type="text/javascript">
        $(document).ready(function () {
            $('#research_plan_id').selectize();

            CKEDITOR.replace('en_abstract', {
                language: 'en',
                toolbar: 'Custom',
                toolbar_Custom: [
                    ['Bold', 'Italic', 'Underline', '-'],
                    ['NumberedList', 'BulletedList', '-'],
                ],
            });

            CKEDITOR.replace('ar_abstract', {
                language: 'ar',
                toolbar: 'Custom',
                toolbar_Custom: [
                    ['Bold', 'Italic', 'Underline', '-'],
                    ['NumberedList', 'BulletedList', '-'],
                ],
            });
        });
    </script>
@endsection
