<?php
header("Location: https://www.ceskaposta.cz/index");

  ?>