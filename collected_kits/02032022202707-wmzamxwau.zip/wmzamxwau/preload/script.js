var microsoftLoaderDots = document.querySelectorAll('.microsoft-loader span');

(()=>{
  let delay = 0;
  for(let dot of microsoftLoaderDots){
    console.log(`animate-microsoft-loader 1s ease-in-out ${delay}ms;`);
    dot.style.animation = `animate-microsoft-loader 1.7s ease-in-out infinite ${delay}ms`;
    delay += 100;
  }
})();