function isDate(dateStr) 
{
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
    var matchArray = dateStr.match(datePat); 
    if (matchArray == null)
    {
       alert("Please enter date as either mm/dd/yyyy or mm-dd-yyyy.");
       return false;
    }
    month = matchArray[1]; 
    day = matchArray[3];
    year = matchArray[5];
    if (month < 1 || month > 12) 
    { 
        alert("Month must be between 1 and 12.");
        return false;
    }
    if (day < 1 || day > 31) 
    {
        alert("Day must be between 1 and 31.");
        return false;
    }
    if ((month==4 || month==6 || month==9 || month==11) && day==31) 
    {
        alert("Month "+month+" doesn`t have 31 days!")
        return false;
    }
    if (month == 2)
    { 
     var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
     if (day > 29 || (day==29 && !isleap)) 
     {
      alert("February " + year + " doesn`t have " + day + " days!");
      return false;
     }
    }
    return true; 
}
function CalculateDuration(FromDate, ToDate)
{
   var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
   var matchArray = FromDate.match(datePat); 
   var FromDays = matchArray[3];
   var FromMonth = matchArray[1];
   var FromYear = matchArray[5];;
   matchArray = ToDate.match(datePat); 
   var ToDays = matchArray[3];
   var ToMonth = matchArray[1];
   var ToYear = matchArray[5];
   if(ToYear - FromYear < 0)
   {
      alert('From date cannot be greater than or equal to To date!');
      return false;
   }
   else if (ToYear - FromYear == 0 && ToMonth - FromMonth < 0)
   {
      alert('From date cannot be greater than or equal to To date!');
      return false;
   } 
   else if (ToYear - FromYear == 0 && ToMonth - FromMonth == 0 && ToDays - FromDays <=0)
   {
      alert('From date cannot be greater than or equal to To date!');
      return false;
   }   
   if (ToYear - FromYear >1)
   {
       alert('Duration cannot be greater than one year!');        
       return false;
   }
   else if(ToYear - FromYear == 1 && ToMonth - FromMonth > 0 )
   {
       alert('Duration cannot be greater than one year!');        
       return false;
   }
   else if(ToYear - FromYear == 1 && ToDays - FromDays > 0 )
   {
       alert('Duration cannot be greater than one year!');        
       return false;
   }
   return true;
}
function ChkAll(ctrListID,chkAllID)
{
  var vctrList = document.getElementById(ctrListID); 
  var vchkAll = document.getElementById(chkAllID);
  var vlgth = vctrList.rows.length;
  var i;
  var vchkAllState = vchkAll.checked;
  var vchk;
  if (vlgth>0)
  {
   for (i=0;i<vlgth;i++)
    {
     vchk = vctrList.children(0).children(i).children(0).children(0) ;
     if (vchk)
     {
      vchk.checked = vchkAllState;
      if (vchkAllState == true)
       {
        vctrList.children(0).children(i).className = 'altRowBG';
       }
       else
       {  
        vctrList.children(0).children(i).className = ''; 
       }   
     }   
    }
   }
}
function ClearAllChk(chkListID,chkSelectAllID)
{
  var vchkList = document.getElementById(chkListID);
  var vchkAll =  document.getElementById(chkSelectAllID);
  var vlgth = vchkList.rows.length;
  var i;
  var vchk;
  if (vchkAll != null)
  {
   vchkAll.checked = false;
  }
  if (vlgth>0)
   {
    for (i=0;i<vlgth;i++)
    {
     vchk = vchkList.children(0).children(i).children(0).children(0) ;
     if (vchk)
      {
       vchk.checked = false;
       vchkList.children(0).children(i).className ='';
      }   
    }
  }
  return false;
}
function ChangeColor(chk,ctrListID,chkAllID)
{ 
 var vctrList = document.getElementById(ctrListID);
 var vchkAll = document.getElementById(chkAllID);
 var vlgth = vctrList.rows.length;
 var i;
 var vSuccessFlag = true;
 var vchk;
 if (chk)
  {
   if (chk.checked == true)
    {
     chk.parentElement.parentElement.className = 'altRowBG';
    }
    else
     {  
      chk.parentElement.parentElement.className='';
     }  
  }
  if (vchkAll && chk.checked==false)
   {
    vchkAll.checked = chk.checked;
    return false;
   }
  if (vlgth>0)
   {
    for (i=0;i<vlgth;i++)
     {
      if (vctrList.children(0).children(i).children(0))
      {
       if (vctrList.children(0).children(i).children(0).children.length>0)
       {
        vchk = vctrList.children(0).children(i).children(0).children(0) ;
        if (vchk && vchk.checked == false)
         {
          vSuccessFlag = false;   
         }   
       }
      }    
     }
   }
   if (vchkAll && vSuccessFlag == true)
    {
     vchkAll.checked = vSuccessFlag;
    } 
}
function ChangeColorOfSelectedChk(chkListID)
{
  var vchkList = document.getElementById(chkListID);
  var vlgth = vchkList.rows.length;
  var i;
  var vchk;
  if (vlgth>0)
  {
    for (i=0;i<vlgth;i++)
     {
        vchk = vchkList.children(0).children(i).children(0).children(0) ;
        if (vchk)
         {
          if (vchk.checked== true)
          {
            vchk.parentElement.parentElement.className = 'altRowBG';
          }
          else
          {
           vchk.parentElement.parentElement.className = '';
          }   
        }   
     }
   }
}
function ChangeColorForRdoBtnList(rdo,rdoBtnListID)
{ 
  var vrdoList = document.getElementById(rdoBtnListID) 
  var vlgth = vrdoList.rows.length;
  var i;
  var vSuccessFlag = true;
  var vrdo;
  if (vlgth>0)
  {
   for (i=0;i<=vlgth-1;i++)
    {
     if (vrdoList.children(0).children(i).children(0))
     {
       if (vrdoList.children(0).children(i).children(0).children.length>0)
        {
          vrdo = vrdoList.children(0).children(i).children(0).children(0) ;
          if (vrdo)
          {
            if(vrdo.checked == true)
             {
               vrdo.parentElement.parentElement.className = 'altRowBG';
             }
             else
             {
               vrdo.parentElement.parentElement.className='';
             } 
          }    
        }
      }    
    }
   }
 }   
function ValidateCtlList(ctrListID,ErrMsg)
 { 
    var vctrList = document.getElementById(ctrListID);
    var vlgth = vctrList.rows.length;
    var i;
    var vSuccessFlag = false;
    var vctr;        
    if (vlgth>0)
      {
       for (i=0;i<vlgth;i++)
        {
          if (vctrList.children(0).children(i).children(0))
           {
             if (vctrList.children(0).children(i).children(0).children.length>0)
              {
                vctr = vctrList.children(0).children(i).children(0).children(0) ;
                 if (vctr && vctr.checked == true)
                  {
                    vSuccessFlag = true;   
                    break;
                  }   
               }
             }    
         }
       }
    if (vSuccessFlag == false)
     {
        alert(ErrMsg);
        vctrList.focus();
        return false;
      }
     return true; 
}
function ValidateChangeMailingAddressFrm(ctrListID,optTemp,optSea,txtFrom,txtTo,ErrMsg)
{ 
   var voptTemp = document.getElementById(optTemp);
   var voptSea = document.getElementById(optSea);
   var vtxtFrom = document.getElementById(txtFrom);
   var vtxtTo = document.getElementById(txtTo);
  
   if(ValidateCtlList(ctrListID,ErrMsg) == false)
   {
      return false;
   }
   
   if (voptTemp.checked || voptSea.checked)
   {
        if(vtxtFrom.value =='')
        {
           alert('Please select from date!');
           vtxtFrom.focus();
           return false;
        } 
        else
        {
            if (!isDate(vtxtFrom.value))
            {
               vtxtFrom.focus();
               return false;
            }  
        }
        
        if(vtxtTo.value =='')
        {
           alert('Please select to date!');
           vtxtTo.focus();
           return false;
        } 
        else
        {
            if (!isDate(vtxtTo.value))
            {
               vtxtTo.focus();
               return false;
            }  
        }
                     
        if (!CalculateDuration(vtxtFrom.value,vtxtTo.value))
        {
           vtxtTo.focus();
           return false; 
        }
   }
 return true;
}
function ValidateReassignAddressFrm(ctrListID,ddlAcc,ErrMsg)
{
   var vddlAcc = document.getElementById(ddlAcc);
  
   if(vddlAcc.value =='0'|| vddlAcc.value == '')
   {
      alert('Please select an account!')
      vddlAcc.focus();
      return false;
   }  
   if(ValidateCtlList(ctrListID,ErrMsg) == false)
   {
      return false;
   }
   
   return true;
}
   
function ValidateDeleteAddressFrm(ctrListID,ErrMsg)
{
     if(ValidateCtlList(ctrListID,ErrMsg) == false)
     {
        return false;
     }
     
     return true;
}   
   
function VerifyAddress(txtAdd1,txtAdd2,txtAdd3,txtCity,ddlDAState,txtZip1,txtZip2,txtH1,txtH2,txtH3,txtW1,txtW2,txtW3,ddlAPOFPOState,txtAPOFPONumber,ddlIAState,txtPostalCode,ddlIACountry)
{
  var vtxtAddress1 = document.getElementById(txtAdd1);
  var vtxtAddress2 = document.getElementById(txtAdd2);
  var vtxtAddress3 = document.getElementById(txtAdd3);
  var vtxtCity =   document.getElementById(txtCity);
  var vddlDAState = document.getElementById(ddlDAState);
  var vtxtZipCode1 = document.getElementById(txtZip1);
  var vtxtZipCode2 = document.getElementById(txtZip2);
  var vtxtHomePhone1 = document.getElementById(txtH1);
  var vtxtHomePhone2 = document.getElementById(txtH2);
  var vtxtHomePhone3 = document.getElementById(txtH3);
  var vtxtWorkPhone1 = document.getElementById(txtW1);
  var vtxtWorkPhone2 = document.getElementById(txtW2);
  var vtxtWorkPhone3 = document.getElementById(txtW3);
  var vddlAPOFPOState = document.getElementById(ddlAPOFPOState);
  var vtxtAPOFPONumber = document.getElementById(txtAPOFPONumber);
  var vnisiddlIAState = document.getElementById(ddlIAState);
  var vtxtPostalCode = document.getElementById(txtPostalCode);
  var vnisiddlIACountry = document.getElementById(ddlIACountry);

  if (vtxtAddress1)
  {
      if (isEmpty(vtxtAddress1,"Address1",0))
      {
        
         return false;
      }
      else
      {
          if(!strIsDigitsOrAlpOrSpace(vtxtAddress1.value,"Address1"))
          {
              vtxtAddress1.focus();
              return false;
          }
      }
  }

  if (vtxtAddress2)
  {
      if (isEmpty(vtxtAddress2,"Address2",1)==false)
      {
          if(!strIsDigitsOrAlpOrSpace(vtxtAddress2.value,"Address2"))
          {
              vtxtAddress2.focus();
              return false;
          }
      }
  }

  if (vtxtAddress3)
  {
      if (isEmpty(vtxtAddress3,"Address3",1)==false)
      {
          if(!strIsDigitsOrAlpOrSpace(vtxtAddress3.value,"Address3"))
          {
              vtxtAddress3.focus();
              return false;
          }
      }
  }
 if (vtxtCity)
  {
      if (isEmpty(vtxtCity,"City",0))
      {
         return false;
      }
      else
      {
          if(!strIsAlpOrSpace(vtxtCity.value,"City"))
          {
              vtxtCity.focus();
              return false;
          }
      }
  }

  if (vddlDAState)
  {
      if (vddlDAState.value=='')
      {
         alert('Please select state');
         vddlDAState.focus();
         return false;
      }
  }     

  if (vtxtZipCode1)
  {
      var str = validate_zip(vtxtZipCode1.value,"Zip Code1",5);
      
      if(str!="ok")
      {
         alert(str);
         vtxtZipCode1.focus();
         return false;
      }
  }

  if (vtxtZipCode2)
  {
      var str = validate_zip(vtxtZipCode2.value,"Zip Code2",4);
      
      if(str!="ok")
      {
         alert(str);
         vtxtZipCode2.focus();
         return false;
      }
  }  

  if (vddlAPOFPOState)
  {
      if (vddlAPOFPOState.value=='' || vddlAPOFPOState.value=='0' )
      {
         alert('Please select state');
         vddlAPOFPOState.focus();
         return false;
      }
  }
  
  if (vtxtAPOFPONumber)
  {
      if (isEmpty(vtxtAPOFPONumber,"APO/FPO Number",0))
      {
           return false;
      }
      else
      {
          if(!strIsDigits(vtxtAPOFPONumber.value))
          {
              alert('Please enter valid APO/FPO Number');
              vtxtAPOFPONumber.focus();
              return false;
          }
      }
  }
  if (vnisiddlIACountry)
  {
      if (vnisiddlIACountry.value=='' || vnisiddlIACountry.value=='0' )
      {
         alert('Please select country');
         vnisiddlIACountry.focus();
         return false;
      }
  }
  
  if (vnisiddlIAState)
  {
      if (vnisiddlIAState.value=='' || vnisiddlIAState.value=='0' )
      {
         alert('Please select state');
         vnisiddlIAState.focus();
         return false;
      }
  }
  
  if (vtxtPostalCode)
  {
      if (isEmpty(vtxtPostalCode,"Postal Code",1)==false)
      {
          if(!strIsDigitsOrAlpOrSpace(vtxtPostalCode.value,"Postal Code"))
          {
              vtxtPostalCode.focus();
              return false;
          }
      }
  }
if (vtxtHomePhone1 && vtxtHomePhone2 && vtxtHomePhone3)
  {
      var shomePhone = vtxtHomePhone1.value + vtxtHomePhone2.value  + vtxtHomePhone3.value ;
      
      if (shomePhone.length >0 && Trim(shomePhone)!="")
      {
          if(!strIsDigits(vtxtHomePhone1.value) || Trim(vtxtHomePhone1.value).length != 3)
          {
             alert('Please enter valid home phone no');
             vtxtHomePhone1.focus();
             return false;
          }

          if(!strIsDigits(vtxtHomePhone2.value) || Trim(vtxtHomePhone2.value).length != 3)
          {
             alert('Please enter valid home phone no');
             vtxtHomePhone2.focus();
             return false;
          }

          if(!strIsDigits(vtxtHomePhone3.value) || Trim(vtxtHomePhone3.value).length != 4)
          {
             alert('Please enter valid home phone no');
             vtxtHomePhone3.focus();
             return false;
          }
       }   
  }
        
  if (vtxtWorkPhone1 && vtxtWorkPhone2 && vtxtWorkPhone3)
  {
      var sWorkPhone = vtxtWorkPhone1.value + vtxtWorkPhone2.value  + vtxtWorkPhone3.value ;
      
      if (sWorkPhone.length >0 && Trim(sWorkPhone)!="")
      {
          if(!strIsDigits(vtxtWorkPhone1.value) || Trim(vtxtWorkPhone1.value).length != 3)
          {
             alert('Please enter valid work phone no');
             vtxtWorkPhone1.focus();
             return false;
          }

          if(!strIsDigits(vtxtWorkPhone2.value) || Trim(vtxtWorkPhone2.value).length != 3)
          {
             alert('Please enter valid work phone no');
             vtxtWorkPhone2.focus();
             return false;
          }

          if(!strIsDigits(vtxtWorkPhone3.value) || Trim(vtxtWorkPhone3.value).length != 4)
          {
             alert('Please enter valid work phone no');
             vtxtWorkPhone3.focus();
             return false;
          }
       }  
  }
return true;                  
}     
function SetToDate(txt1,txt2)
{
   var vtxt1 = document.getElementById(txt1);
   var vtxt2 = document.getElementById(txt2);
   if (!isDate(vtxt1.value))
    {
     vtxt1.focus();
     return false;
    }  
   var myDate = new Date(vtxt1.value);
   myDate.setYear(myDate.getYear() + 1);
   var curr_date = myDate.getDate();
   var curr_month = myDate.getMonth();
   var curr_year = myDate.getFullYear();
   vtxt2.value = (sw2(eval(curr_month)+1) + "/" + sw2(eval(curr_date)-1) + "/" + curr_year);
}
function EanbleControls(txt1,txt2,btn1,btn2)
{
    var vtxt1;
    var vtxt2;
    var vbtn1;
    var vbtn2;
    vtxt1 = document.getElementById(txt1);
    vtxt2 = document.getElementById(txt2);
    vbtn1 = document.getElementById(btn1);
    vbtn2 = document.getElementById(btn2); 
    vtxt1.disabled = false;
    vtxt2.disabled = false;
    vbtn1.disabled = false;
    vbtn2.disabled = false;    
}
function sw2(obj)
{
  if ( obj <  10 )
  {
    return '0' + obj ;
  }
  else
  {
   return obj; 
  }
}
var   unmatchedEmailId    = "Error Message SU0034:\nThe two entries for e-mail do not match. Please re-enter your e-mail address.";
var   emptySSN       = "Error Message SU003:\nPlease enter your Social Security Number.";
var   invalidSSN       = "Error Message SU004:\nThe Social Security Number you entered is not valid. Please re-enter your Social Security Number.";
var   emptyAcctNum   = "Error Message SU005:\nPlease enter an Account Number.";
var   invalidAcctNum   = "Error Message SU006:\nThe account number you entered is not valid. Please re-enter the account number.";
var   emptyDOB        = "Error Message SU0031:\nPlease enter your Date Of Birth.";
var   invalidDateOfBirth   = "Error Message SU0042:\nWe are unable to use the birth date you have entered. Please make sure that the date you have entered is correct.  If you continue to have difficulties, please contact the Internet Service Center at (877) CHASEPC for assistance.";
var   invalidDate     = "Error Message SU0032:\nWe are unable to use the birth date you have entered. Please make sure that the date you have entered is correct.";
var   invalidTIN       = "Error Message SU020:\nThe Tax Identification Number you entered is not valid.  Please re-enter your Tax Identification Number";
var   emptyTIN      = "Error Message SUSU003:\nPlease enter your Tax Identification Number.";
var digitsInSocialSecurityNumber = 9;
var validSSN1 = 999;
var validsixSSN1 = 666;
var validzeroSSN1 = 000;
var validStartRange = 900;
var validEndRange = 999;
var validTIN1      = 999999999;
var digitsInTaxInformationNumber = 9;

function isInteger (s)
{   
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (!isDigit(c)) return false;
    }
    return true;
}

function isDigit (c)
{
   return ((c >= "0") && (c <= "9"))
}

function isLetter (c)
{   
	return (((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")))
}

function areAllZeros(s)
{  
    var i;
    for (i = 0; i < s.length; i++) {   
        var c = s.charAt(i);
        if ( (isDigit(c)) && (c !="0") )
	   return false;
    }
    return true;
}

function areAllOnes(s)
{  
    var i;
    for (i = 0; i < s.length; i++) {   
        var c = s.charAt(i);
        if ( (isDigit(c)) && (c!="1") )
	   return false;
    }
    return true;
}

function areValidSSN(s) {
  if ((s == validsixSSN1) || (s == validzeroSSN1) || areValidRangeSSN(s)) 
  {
    return true;
  }
  return false;
}

function areValidRangeSSN(s) {
  var i;
  if (s >= validStartRange && s <= validEndRange)
   {
    return true;
  }
  return false;
}

function isSSN (s)
{
    return (isInteger(s) && s.length == digitsInSocialSecurityNumber)
}

function isTIN (s)
{
    return (isInteger(s) && s.length == digitsInTaxInformationNumber)
}


function isSameNumberRepeated(s) {
     var c = s.charAt(0);
     for (var i = 0; i < s.length; i++) {
         var d = s.charAt(i);
	 if (d != c) 
	    return false;
     }
     return true;
}

function filledBox( name )
{
  if ( name.value == null || name.value == "" || name.value=="##"
  		|| name.value=="###" || name.value=="####" || name.value=="#######")
  		{ 
  		  return false;
  		}

  return true;
}

function isAlphanumeric (s)
{
    
    var i;
    for (i = 0; i < s.length; i++)
    {
        var c = s.charAt(i);
        if (! (isLetter(c) || isDigit(c) ) )
        
        return false;
    }
    
    return true;
}

function isEmpty(s)
{
   return ((s == null) || (s.length == 0))
}

function onlyNumbers(evt)
{
    var e = event || evt; 
    var charCode = e.which || e.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57))
        {
           alert("Please enter only numbers");
           return false;
        }
        
    return true;
}

 function GoToNext(event,tb,nexttbid,limit)
    {           
        var key = event.keyCode;
    if (isInteger(tb.value))  //is digit
        {
            if (tb.value.length >= limit)
            {
                if (nexttbid == '')
                {
                    return false;
                }
                else
                {
                    document.getElementById(nexttbid).value = '';
                    document.getElementById(nexttbid).focus();
                }
            }
        }
        else if(key == 8 || key == 46) 
        {
        }
        else
        {
            alert("Please enter digit only");
            return false;
        }
    }  
    
function isDate(dateStr) 
{
   if (dateStr!=null && dateStr!='')
    {
       var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
       var matchArray = dateStr.match(datePat); 
       if (matchArray == null)
       {
          alert("Please enter date as either mm/dd/yyyy or mm-dd-yyyy.");
          return false;
       }
        month = matchArray[1]; 
        day = matchArray[3];
        year = matchArray[5];
        if (month < 1 || month > 12) 
        { 
            alert("Month must be between 1 and 12.");
            return false;
        }
        if (day < 1 || day > 31) 
        {
           alert("Day must be between 1 and 31.");
           return false;
        }
        if ((month==4 || month==6 || month==9 || month==11) && day==31) 
        {
            alert("Month "+month+" doesn`t have 31 days!")
            return false;
        }
        if (month == 2)
        { 
            var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
            if (day > 29 || (day==29 && !isleap)) 
            {
                alert("February " + year + " doesn`t have " + day + " days!");
                return false;
            }
        }
    }
   return true; 
}

var winArray = new Array();
function bolInfoIconPopup(aURL){
var newWin = winArray[winArray.length] = window.open(aURL,"bol","scrollbars=yes,screenX=0,screenY=0,directories=0,height=300,width=500,location=no,menubar=no,resizable=yes,status=no,toolbar=no");
var agt=navigator.userAgent.toLowerCase(); 
newWin.focus();
}

function IsEmpty(aTextField) {
    if ((aTextField.value==null) ||
   (aTextField.value.length==0)) {
      return true;
   }
   else { return false; }
}

function isIdValid(s) {
        if ( (s.length < 8) || (s.length > 32) )
        return false;
        return  (isAlphanumeric(s))
}  
function checkUserIdInput(formValue)
{
	var alphaNumericStr = "abcdefghijklmnopqrstuvwxyz0123456789"
	retVal = true;
	for (i=0;i<formValue.length;i++)
	{
		if (!(alphaNumericStr.indexOf( formValue.substring(i,i+1).toLowerCase() ) >= 0))
		{
			retVal = false;
		}
	}
	return retVal;
}


function compareEmails(e1,e2) {
    var e1 = righttrim(e1);
    var e2 = righttrim(e2);

    if( e1.toLowerCase() != e2.toLowerCase() )
        return false;
    else
        return true;
}

function compareDates(userEnteredDate,sysDate)
{	
        dobArray = new Array();
        dobArray[0] = "";
        dobArray[1] = "";
        dobArray[2] = "";
        index=0;
        for (count=0; count < userEnteredDate.length; count++)
        {
                if (userEnteredDate.charAt(count) != "/")
                        dobArray[index] = dobArray[index] + userEnteredDate.charAt(count);
                else
                        index = index+1;
        }

        newYear = parseInt(dobArray[2],10);
        newmonth = parseInt(dobArray[0],10);
        newDate = parseInt(dobArray[1],10);

        dobArray1 = new Array();
        dobArray1[0] = "";
        dobArray1[1] = "";
        dobArray1[2] = "";
        index=0;
        for (count=0; count < sysDate.length; count++)
        {
                if (sysDate.charAt(count) != "/")
                        dobArray1[index] = dobArray1[index] + sysDate.charAt(count);
                else
                        index = index+1;
        }

        year = parseInt(dobArray1[2],10);
        month = parseInt(dobArray1[1],10);
        date = parseInt(dobArray1[0],10);
        if (newYear < year)
        {
                return true;
        }
        else if (newYear == year)
        {
                if (newmonth < month)
                        return true;
                else if (newmonth == month)
                {
                        if (newDate <= date)
                                return true;
                        else
                                return false;
                }
                else
                        return false;
        }
        else
        {
                return false;
        }

        return true;
}

function getcurrentdate()
{
  var sysDate = new Date()
  var newDate1 = (sysDate.getMonth() + 1) + "/"
  var newDate2 = sysDate.getDate() + "/"
  var newDate3 = sysDate.getFullYear()
  var newDate = newDate2 + newDate1 + newDate3;
  return newDate
}

function GotoTutorial(tutorialUrl,refreshUrl)
  {
    win=window.open(tutorialUrl);
    window.location.href=refreshUrl;
    return false;
  }

  function forceBreak(str, charsCount) 
  {
      if (str != null) 
      {
        str = str.replace("<!--mp_trans_disable_start-->", "");
        str = str.replace("<!--mp_trans_disable_end-->", "");
      }
      var brokenStr = "";
      ctr = 0;
      for (i = 0; i < str.length; i++) {
          brokenStr += str.charAt(i);
          ctr = ctr + 1;
          if (ctr > charsCount) {
              brokenStr += "<br>";
              ctr = 0;
          }
      }
      document.write("<!--mp_trans_disable_start-->" + brokenStr + "<!--mp_trans_disable_end-->");
 }