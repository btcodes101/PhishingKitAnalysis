var errMsgNoRepeats = "Password must not include more than 2 identical characters (for example: 111 or aaa). Please re-create your Password.";
// no sequences error msg
var errMsgNoSequence = "Password must not include more than 2 consecutive characters (for example: 123 or abc). Please re-create your Password.";
function DigitKeyUp(currentControlId, nextControlId, length) {
    var next;
    if (exists(currentControlId)) {
        var current = ge(currentControlId);

        if (current.value.length == length) {
            if (exists(nextControlId)) {
                ge(nextControlId).focus();
            }
        }
    }
    return true;
}

function DigitKeyUpMobile(currentControlId, nextControlId, length, cellareaControlId, CellPrefixControlId, CellSuffixControlId) {
    Show("trTCPAMobileDisclosure");
    var cellarea = document.getElementById(cellareaControlId).value;
    var cellPrefix = document.getElementById(CellPrefixControlId).value;
    var cellSuffix = document.getElementById(CellSuffixControlId).value;
    if (cellarea == "" && cellPrefix == "" && cellSuffix == "") {
        Hide("trTCPAMobileDisclosure");
    }
    var next;
    if (exists(currentControlId)) {
        var current = ge(currentControlId);

        if (current.value.length == length) {
            if (exists(nextControlId)) {
                ge(nextControlId).focus();
            }
        }
    }
    return true;
}

function DigitKeyUpMobileAlert(currentControlId, nextControlId, length, cellareaControlId, CellPrefixControlId, CellSuffixControlId) {
    Show("trMobileAlertTCPADisclosure");
    var cellarea = ge(cellareaControlId).value;
    var CellPrefix = ge(CellPrefixControlId).value;
    var CellSuffix = ge(CellSuffixControlId).value;
    if (cellarea == "" && CellPrefix == "" && CellSuffix == "") {
        Hide("trMobileAlertTCPADisclosure");
    }
    var next;
    if (exists(currentControlId)) {
        var current = ge(currentControlId);

        if (current.value.length == length) {
            if (exists(nextControlId)) {
                ge(nextControlId).focus();
            }
        }
    }
    return true;
}

function DigitKeyUpPassword(currentControlId, nextControlId, length) {
    Show("trTCPADisclosure");
    Show("trTCPACheckbox");
    var cellarea = ge("txtCellArea").value;
    var CellPrefix = ge("txtCellPrefix").value;
    var CellSuffix = ge("txtCellSuffix").value;
    var tcpaCellarea = ge("tcpa_txtCellArea").value;
    var tcpaCellPrefix = ge("tcpa_txtCellPrefix").value;
    var tcpaCellSuffix = ge("tcpa_txtCellSuffix").value;
    if ((cellarea.trim() == "" && CellPrefix.trim() == "" && CellSuffix.trim() == "")
        || (cellarea == tcpaCellarea && CellPrefix == tcpaCellPrefix && CellSuffix == tcpaCellSuffix)) {
        Hide("trTCPADisclosure");
        Hide("trTCPACheckbox");
        Hide("trTCPADisclosureError");
        ge("spanTCPACheckbox").className = "";
    }

    if (cellarea.trim() == "" && CellPrefix.trim() == "" && CellSuffix.trim() == "") {
        ClearText("txtConfCellArea");
        ClearText("txtConfCellPrefix");
        ClearText("txtConfCellSuffix");
        Hide("trConfirmCell");
    }
    else
        Show("trConfirmCell");

    var next;
    if (exists(currentControlId)) {
        var current = ge(currentControlId);

        if (current.value.length == length) {
            if (exists(nextControlId)) {
                ge(nextControlId).focus();
            }
        }
    }

    return true;
}

function displayToggle(boolResult, errTR, errSpan) {
    if (boolResult) {
        ge(errTR).style.display = "none";
        ge(errSpan).style.display = "none";
    }
    else {
        ge(errTR).style.display = "";
        ge(errSpan).style.display = "";
    }
}

function setResult(resultTopass, errTR, errSpan, strInnerHTML, errElement) {
    displayToggle(resultTopass, errTR, errSpan);
    if (resultTopass == true)
        ge(errElement).className = "inputTextBox";
    else
        ge(errElement).className = "inputTextBoxE"; //icored
    ge(errSpan).innerHTML = strInnerHTML;
    return resultTopass;
}


function setResultGroup(resultTopass, errTR, errSpan, strInnerHTML, errElement) {
    displayToggle(resultTopass, errTR, errSpan);
    if (errSpan) {
        var txt_array = errElement.split(",");
        var i;
        for (i = 0; i < txt_array.length; i++) {
            var errspanx = txt_array[i];
            if (resultTopass == true) {
                ge(errspanx).className = "inputTextBox";
            }
            else {
                ge(errspanx).className = "inputTextBoxE";  //icored
            }
        }
    }
    ge(errSpan).innerHTML = strInnerHTML;
    return resultTopass;
}

function isValidPassword(formElt, isRSA) {
    var txtPwd = ge(formElt).value;
        if (isRSA == "True" || isRSA == "true") {
            if (!isRsaPwValid(txtPwd)) {
                return setResult(false, "errTRpwd", "errSpanpwd", PwErrorMsg, formElt);
            }
            else {
                setResult(true, "errTRpwd", "errSpanpwd", "", formElt);
            }
        }
        else {
            if (!isPwValid(txtPwd)) {
                return setResult(false, "errTRpwd", "errSpanpwd", PwErrorMsg, formElt);
            }
            else {
                setResult(true, "errTRpwd", "errSpanpwd", "", formElt);
            }
        }
    return true;
}

function validateConfirmPassword(formElt, flowName) {
    var txtConfirmPwd = ge(formElt).value;
    var pwdLength = txtConfirmPwd.length;
    if (pwdLength == 0) {
        if (flowName == "ReIdentify") {
            return setResult(false, "errTRcpwd", "errSpancpwd", ErrNoConfirmPw, 'txtConfirmPassword');
        }
        else {
            return setResult(false, "errTRcpwd", "errSpancpwd", ErrNoConfirmPw, 'txtConfirmPassword');
        }
    }
    else {
        setResult(true, "errTRcpwd", "errSpancpwd", "", 'txtConfirmPassword');
    }
    if (txtConfirmPwd != ge("txtPassword").value) {
        return setResult(false, "errTRcpwd", "errSpancpwd", ErrPwConfirmMismatch, 'txtConfirmPassword');
    }
    else {
        setResult(true, "errTRcpwd", "errSpancpwd", "", 'txtConfirmPassword');
    }

    return true;
}

function clearEmailConfirm() {
    ge('txtConfEmailAddress').value = "";
}

function isValidEmailAddress(emailAddress) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(emailAddress);
}

function chkEmail(obj) {
    if (!(isValidEmailAddress(obj.value))) {
        return setResult(false, "errTRmail", "errSPANmail", "Enter valid E-mail Address", 'txtEmailAddress');
    }
    else {
        return setResult(true, "errTRmail", "errSPANmail", "", 'txtEmailAddress');
    }
    return true;
}

function chkConfirmEmail(obj) {
    var emailAddress = ge('txtEmailAddress').value;

    if (obj.value != emailAddress) {
        return setResult(false, "errTRcmail", "errSPANcmail", "E-mail Address and Confirm E-mail Address do not match.", 'txtConfEmailAddress');
    }
    else {
        return setResult(true, "errTRcmail", "errSPANcmail", "", 'txtConfEmailAddress');
    }
    return true;
}

// onclick - NEXT button - ENROLL
function validateEnrollPasswordFormData() {
    var isValidPassword = validatePasswordFormData('Enroll');
    if (isValidPassword == true) {
        var mbl = getCellPhoneFormData("txtCellArea", "txtCellPrefix", "txtCellSuffix");
        var mblcnf = getCellPhoneFormData("txtConfCellArea", "txtConfCellPrefix", "txtConfCellSuffix");

        if (mbl) {
            if (isValidPhoneNumber(mbl)) {
                if (mblcnf != mbl) {
                    return dispCellPhoneErr();
                }
                else {
                    if (!ValidateTCPADiclosure())
                        return false;
                    return dispCellPhoneSuccess();
                }
            }
            else {
                return dispCellPhoneErr();
            }
        }
        else if (mblcnf) {
            return dispCellPhoneErr();
        }
        else {
            if (!ValidateTCPADiclosure())
                return false;
            return dispCellPhoneSuccess();
        }
    }
    return false;
}

function ValidateTCPADiclosure() {
    var mbl = getCellPhoneFormData("txtCellArea", "txtCellPrefix", "txtCellSuffix");
    var mblcnf = getCellPhoneFormData("txtConfCellArea", "txtConfCellPrefix", "txtConfCellSuffix");
    var cellarea = document.getElementById("txtCellArea").value;
    var CellPrefix = document.getElementById("txtCellPrefix").value;
    var CellSuffix = document.getElementById("txtCellSuffix").value;
    var tcpaCellarea = document.getElementById("tcpa_txtCellArea").value;
    var tcpaCellPrefix = document.getElementById("tcpa_txtCellPrefix").value;
    var tcpaCellSuffix = document.getElementById("tcpa_txtCellSuffix").value;
    if (mbl != "" && mblcnf != "" && ge("tcpaDisclosureCheckBox").checked != true &&
            ((cellarea != tcpaCellarea || CellPrefix != tcpaCellPrefix || CellSuffix != tcpaCellSuffix))) {
        ge("spanTCPACheckbox").className = "checkboxerrorTCPA";
        ge("trTCPADisclosureError").style.display = "";
        return false;
    }
    return true;
}

function dispCellPhoneSuccess() {
    setResultGroup(true, "errCellPhone", "errSpanCell", "", "txtCellArea,txtCellPrefix,txtCellSuffix");
    return setResultGroup(true, "errCfmCell", "errSpanCfmCell", "", "txtConfCellArea,txtConfCellPrefix,txtConfCellSuffix");
}

var CELL_PHONE_ERR_MSG = "Please enter a valid mobile phone number (555-555-5555)";
var CELL_CFRM_ERR_MSG = "Please confirm the mobile phone number.";

function dispCellPhoneErr() {
    setResultGroup(false, "errCellPhone", "errSpanCell", CELL_PHONE_ERR_MSG, "txtCellArea,txtCellPrefix,txtCellSuffix");
    return setResultGroup(false, "errCfmCell", "errSpanCfmCell", CELL_CFRM_ERR_MSG, "txtConfCellArea,txtConfCellPrefix,txtConfCellSuffix");
}



function isValidPhoneNumber(phonenumber) {
    if (phonenumber) {
        if (phonenumber.length != 10) {
            return false;
        }
        var nxx = phonenumber.substring(4, 5);
        if (nxx == "11") {
            return false;
        }
        var isValid = validPhone.test(phonenumber);
        if (!isValid) {
            return false;
        }
        return true;
    }
    else {
        return false;
    }
}

function getCellPhoneFormData(area, prefix, suffix) {
    var phoneNumber = ge(area).value + ge(prefix).value + ge(suffix).value;
    return phoneNumber;
}

function append(txt, len, s) {
    if (txt) {
        var v = txt.value;
        if (v) {
            if (v.length == len && hasOnlyNumbers(v)) {
                if (len == 4 || parseInt(v) >= 100) {
                    return s.concat(v);
                }
            }
        }
    }
    return s;
}
function validatePasswordFormData(flowName) {
    var password = document.frmPassword.txtPassword;
    var confirmPassword = document.frmPassword.txtConfirmPassword;
    //var userId = document.frmPassword.hidOldUserId;
    var emailAddress = document.frmPassword.txtEmailAddress;
    var confEmailAddress = document.frmPassword.txtConfEmailAddress;
    
    if (confirmPassword.value == "") {
        confirmPassword.className = "inputTextBoxE";
        confirmPassword.focus();
        return setResult(false, "errTRcpwd", "errSpancpwd", ErrNoConfirmPw, "txtConfirmPassword");
    }
    else if (password.value != confirmPassword.value) {
        confirmPassword.className = "inputTextBoxE";
        confirmPassword.focus();
        return setResult(false, "errTRcpwd", "errSpancpwd", ErrPwConfirmMismatch, "txtConfirmPassword");
    }

    if (flowName != "ReIdentify") {
        if (emailAddress.value == "") {
            emailAddress.className = "inputTextBoxE";
            emailAddress.focus();
            return setResult(false, "errTRmail", "errSPANmail", "Enter valid E-mail Address.", "txtEmailAddress");
        }

        if (confEmailAddress.value == "") {
            confEmailAddress.className = "inputTextBoxE";
            confEmailAddress.focus();
            return setResult(false, "errTRcmail", "errSPANcmail", "Enter valid Confirm E-mail Address", "txtConfEmailAddress");
        }

        if (emailAddress.value != confEmailAddress.value) {
            confEmailAddress.className = "inputTextBoxE";
            return setResult(false, "errTRcmail", "errSPANcmail", "E-mail Address and Confirm E-mail Address do not match.", "txtConfEmailAddress");
        }
    }
    return true;
}

function isAlphanumericCheck(s) {
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (!(isLetter(c) || isDigit(c)))
            return false;
    }
    return true;
}

function isAnyCharacterCheck(s) {
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (isLetter(c))
            return true;
    }
    return false;
}

function checkUserId(txtObj) {
    var userVal = txtObj.value;
    ge('icogreen').style.display = "none";
    ge('msgText').style.display = "none";
    document.forms[0].txtUserID.className = "inputTextBox";

    if (txtObj.value != "") {
        if (/\W/.test(txtObj.value)) {
            ge('msgText').style.display = "";
            ge('msgText').innerHTML = "Special characters <br>(e.g. #,@,$) are not allowed";
            document.forms[0].txtUserID.className = "inputTextBoxE";
            return false;
        }

        ge('icored').style.display = "none";
        ge('msgText').style.display = "none";
        ge('msgText').innerHTML = "";
        document.forms[0].txtUserID.className = "inputTextBox";
        return true;
    }
}

function ValidateCreateUserIDFormData() {
    ge('msgText').style.display = "none";

    var userid = document.forms[0].txtUserID.value;
    if (userid == "" || userid.length < 8) {
        ge('msgText').style.display = "";
        ge('msgText').innerHTML = "Minimum 8 characters are required";
        document.forms[0].txtUserID.className = "inputTextBoxE";
        return false;
    }

    if (hasOnlyCharacters(userid)) {
        ge('msgText').style.display = "";
        ge('msgText').innerHTML = "Your User ID must have at least one number";
        document.forms[0].txtUserID.className = "inputTextBoxE"
        return false;
    }

    if (hasOnlyNumbers(userid)) {
        ge('msgText').style.display = "";
        ge('msgText').innerHTML = "Your User ID must have at least one letter";
        document.forms[0].txtUserID.className = "inputTextBoxE"
        return false;
    }

    if (ge('msgText').style.display == "") {
        return false;
    }
    ge('icored').style.display = "none";
    ge('msgText').style.display = "none";
    ge('msgText').innerHTML = "none";
    document.forms[0].txtUserID.className = "inputTextBox";
    if (!ValidateCreateUserIDForm()) //This function is in IdentifyUser.js file
    {
        return false;
    }
    else {
        return true;
    }
}

//Start - Validations for Activation code 
function validateActivationCode(txtObj) {
    var userid = "";
    ge('icogreen').style.display = "none";
    ge('icored').style.display = "none";
    ge('msgText').style.display = "none";
    ge('msgText').innerHTML = "";
    document.forms[0].txtActivationCode.className = "inputTextBox"
    ge('msgTextRow').style.display = "";

    if (txtObj.value != "") {
        if (/\W/.test(txtObj.value)) {
            ge('msgText').style.display = "";
            ge('msgTextRow').style.display = "";
            ge('msgText').innerHTML = "Special characters (e.g. #,@,$) are not allowed";
            document.forms[0].txtActivationCode.className = "inputTextBoxE";
            return false;
        }

        if (isNaN(txtObj.value)) {
            ge('msgText').style.display = "";
            ge('msgTextRow').style.display = "";
            ge('msgText').innerHTML = "Please enter a valid Identification Code";
            document.forms[0].txtActivationCode.className = "inputTextBoxE";
            return false;
        }

        ge('icored').style.display = "none";
        ge('msgText').style.display = "none";
        ge('msgText').innerHTML = "";
        document.forms[0].txtActivationCode.className = "inputTextBox";
        ge('msgTextRow').style.display = "none";
    }
}

function validateTokenCode(txtObj) {
    var userid = "";
    ge('icogreen').style.display = "none";
    ge('icored').style.display = "none";
    ge('msgText').style.display = "none";
    ge('msgText').innerHTML = "";
    document.forms[0].txtReIdentifyTokenCode.className = "inputTextBox"
    ge('msgTextRow').style.display = "";

    if (txtObj.value != "") {
        if (/\W/.test(txtObj.value)) {
            ge('msgText').style.display = "";
            ge('msgTextRow').style.display = "";
            ge('msgText').innerHTML = "Special characters (e.g. #,@,$) are not allowed";
            document.forms[0].txtReIdentifyTokenCode.className = "inputTextBoxE";
            return false;
        }
        if (isNaN(txtObj.value)) {
            ge('msgText').style.display = "";
            ge('msgTextRow').style.display = "";
            ge('msgText').innerHTML = "Please enter a valid Token Code";
            document.forms[0].txtReIdentifyTokenCode.className = "inputTextBoxE";
            return false;
        }
        ge('icored').style.display = "none";
        ge('msgText').style.display = "none";
        ge('msgText').innerHTML = "";
        document.forms[0].txtReIdentifyTokenCode.className = "inputTextBox";
        ge('msgTextRow').style.display = "none";
    }
}

function ValidateFormData() {
    if (document.frmValidateOTP.txtActivationCode) {
        var actcode = document.forms[0].txtActivationCode.value;
        if (isNaN(actcode)) {
            ge('msgText').style.display = "";
            ge('msgTextRow').style.display = "";
            ge('msgText').innerHTML = "Please enter a valid Identification Code";
            document.forms[0].txtActivationCode.className = "inputTextBoxE";
            return false;
        }
        if (actcode.length < 8) {
            ge('msgText').style.display = "";
            ge('msgTextRow').style.display = "";
            ge('msgText').innerHTML = "Please enter a valid Identification Code";
            document.forms[0].txtActivationCode.className = "inputTextBoxE";
            return false;
        }
        ge('icored').style.display = "none";
        ge('msgText').style.display = "none";
        ge('msgText').innerHTML = "";
        document.forms[0].txtActivationCode.className = "inputTextBox";
        ge('msgTextRow').style.display = "none";
    }

    if (document.frmValidateOTP.txtPassword) {
        if (document.frmValidateOTP.txtPassword.value == "") {
            document.frmValidateOTP.txtPassword.className = "inputTextBoxE";
            document.frmValidateOTP.txtPassword.focus();
            return setResult(false, "errTRpwd", "errSpanpwd", "Please enter a Password.", "txtPassword");
            return false;
        }
    }
    if (document.frmValidateOTP.txtTokenCode) {
        if (document.frmValidateOTP.txtTokenCode.value == "") {
            document.frmValidateOTP.txtTokenCode.className = "inputTextBoxE";
            document.frmValidateOTP.txtTokenCode.focus();
            return setResult(false, "errTRTokenCode", "errSpanTokenCode", "Please enter token code.", "txtTokenCode");
            return false;
        }
    }

    if (document.frmValidateOTP.txtReIdentifyTokenCode) {
        var actcode = document.forms[0].txtReIdentifyTokenCode.value;
        if (actcode == "") {
            ge('msgText').style.display = "";
            ge('msgTextRow').style.display = "";
            ge('msgText').innerHTML = "Please enter token Code.";
            document.forms[0].txtReIdentifyTokenCode.className = "inputTextBoxE";
            return false;
        }
        if (isNaN(actcode)) {
            ge('msgText').style.display = "";
            ge('msgTextRow').style.display = "";
            ge('msgText').innerHTML = "Please enter a valid token Code.";
            document.forms[0].txtReIdentifyTokenCode.className = "inputTextBoxE";
            return false;
        }
        if (actcode.length < 6) {
            ge('msgText').style.display = "";
            ge('msgTextRow').style.display = "";
            ge('msgText').innerHTML = "Please enter a valid token Code - it should be minimum 6 digits.";
            document.forms[0].txtReIdentifyTokenCode.className = "inputTextBoxE";
            return false;
        }
        ge('icored').style.display = "none";
        ge('msgText').style.display = "none";
        ge('msgText').innerHTML = "";
        document.forms[0].txtReIdentifyTokenCode.className = "inputTextBox";
        ge('msgTextRow').style.display = "none";
    }
}

function submitToLogin(otp, otpPreFix, otpKey, password, rsatokencode, url) {
    if (ValidateFormData() == false)
        return false;

    var _otp = "";
    if (exists(otp))
        _otp = ge(otp).value;

    var _password = "";
    if (exists(password))
        _password = ge(password).value;

    var _rsatokencode = "";
    if (exists(rsatokencode))
        _rsatokencode = ge(rsatokencode).value;

    postToAuthServlet(_password, _otp, _rsatokencode, otpPreFix, url);
}

function postToAuthServlet(password, otp, rsatokencode, otpPreFix, url) {
    if (document.frmValidateOTP.auth_passwd && password != null) {
        document.frmValidateOTP.auth_passwd.value = password;
    }

    document.frmValidateOTP.auth_otp.value = otp;

    if (document.frmValidateOTP.auth_tokencode) {
        document.frmValidateOTP.auth_tokencode.value = rsatokencode;
    }

    document.frmValidateOTP.auth_otpprefix.value = otpPreFix;
    document.frmValidateOTP.auth_deviceId.value = deviceId();
    document.frmValidateOTP.auth_deviceSignature.value = deviceSignature();
    document.frmValidateOTP.auth_deviceCookie.value = deviceCookie();
    document.frmValidateOTP.action = url;
    document.frmValidateOTP.method = "post";
    document.frmValidateOTP.submit();
    return true;
}
//End - Validations for Activation code 

//Start - Legal agreement funtions

function enableChkBox() {
    var cbCOLSA = document.getElementById('chkCOLSA');
    var cbAM = document.getElementById('chkAM');

    cbCOLSA.disabled = false;
    cbCOLSA.checked = false;

    if (cbAM != null) {

        cbAM.disabled = false;
        cbAM.checked = false;
    }
}

function disableChkBox() {

    var cbCOLSA = document.getElementById('chkCOLSA');
    var cbAM = document.getElementById('chkAM');

    cbCOLSA.disabled = true;
    cbCOLSA.checked = false;

    if (cbAM != null) {

        cbAM.disabled = true;
        cbAM.checked = false;
    }
}

function enableAgreement(rdObj) {
    if (rdObj.checked == true) {
        if (rdObj.id == "rdoECDAgree") {
            enableChkBox();
        }
        else {
            disableChkBox();
        }
    }
}

function checkAll(chkObj, str) {
    if (str == "Required") {
        if (exists("trCOLSA")) {
            document.forms[0].chkCOLSA.checked = true;
        }
    }
    else {
        if (exists("trAM")) {
            document.forms[0].chkAM.checked = true;
        }
    }

    if (chkObj.checked == false) {
        if (str == "Required") {
            if (exists("trCOLSA")) {
                document.forms[0].chkCOLSA.checked = false;
            }
        }
        else {
            if (exists("trAM")) {
                document.forms[0].chkAM.checked = false;
            }
        }
    }
}

function enabledisableChkBox(ctrListID, ctrListAM, objself, objAM) {
    var varobjAM = document.getElementById(objAM);
    var varobjself = document.getElementById(objself);
    var vctrList = document.getElementById(ctrListID);

    if (varobjAM != null) {
        var vctrListAM = document.getElementById(ctrListAM);
    }

    if (varobjself != null) {
        var areAllECDAgreementsAccepted = areECDAgreementsAccepted(varobjself);

        if (areAllECDAgreementsAccepted == true) {
            vctrList.disabled = false;

            if (varobjAM != null) {
                vctrListAM.disabled = false;
            }
        }
        else if (areAllECDAgreementsAccepted == false) {
            vctrList.checked = false;
            vctrList.disabled = true;

            if (varobjAM != null) {
                vctrListAM.checked = false;
                vctrListAM.disabled = true;
            }
        }
    }
}


function ValidateLAFormData() {
    if (exists("trECD") && exists("trCOLSA")) {
        if (areECDAgreementsAccepted(document.getElementById('trECD')) == false || ge("chkCOLSA").checked == false) {
            alert("You must agree to all of the disclosures before proceeding. (Message SU031)");
            return false;
        }
        return true;
    }
}

function areECDAgreementsAccepted(cblList) {
    var cbArray = cblList.getElementsByTagName('input');
    var areAllCkeched = true;

    for (var i = 0; i < cbArray.length; i++) {

        var cb = cbArray[i];

        if (cb.type.substr(0, 8) == 'checkbox') {

            if (cb.checked == false) {
                areAllCkeched = false;
                return areAllCkeched;
            }
        }
    }

    return areAllCkeched;
}

//End - Legal agreement functions

function ancHavActivationCode_Click() {
    document.frmOTPDeliveryMode.hdnRHSLinkClicked.value = "true";
    document.frmOTPDeliveryMode.action = "OTPDeliveryMode.aspx";
    document.frmOTPDeliveryMode.method = "post";
    document.frmOTPDeliveryMode.submit();
    return true;
}

function lbNotRecieved_Click() {
    document.frmValidateOTP.hdnRHSLinkClicked.value = "true";
    document.frmValidateOTP.action = "ValidateOTP.aspx";
    document.frmValidateOTP.method = "post";
    document.frmValidateOTP.submit();
    return true;
}

function ancAffiliate_Click() {
    document.formIdentifyUser.hdnRHSLinkClicked.value = "true";
    document.formIdentifyUser.action = "IdentifyUser.aspx";
    document.formIdentifyUser.method = "post";
    document.formIdentifyUser.submit();
    return true;
}

function checkEandARadio(bpenrolluser) {
    var chkRad = document.frmOTPDeliveryMode.rdoDelMethod;
    var chkYes = false;
    if (chkRad == null) {
        alert("No delivery method exists to receive your Identification Code.");
        return chkYes;
    }
    if (chkRad.length == null) {
        if (chkRad.checked) {
            chkYes = true;
        }
    }
    else {
        for (var i = 0; i < chkRad.length; i++) {
            if (chkRad[i].checked) {
                chkYes = true;
            }
        }
    }

    if (!chkYes) {
        if (!bpenrolluser)
            alert("Please select one delivery method to receive your Identification Code.");
        else
            alert("Please select the phone number where you want to receive your Identification Code.");
        if (chkRad.length == null)
            chkRad.focus();
        else
            chkRad[0].focus();
        return false;
    }
}

function isValidTokenCode(formElt) {
    var txtTokenCode = ge(formElt).value;
    var tokenLength = txtTokenCode.length;
    if (tokenLength == 0) {
        return setResult(false, "errTRTokenCode", "errSpanTokenCode", "Please enter Token Code.", 'txtTokenCode');
    }
    if (tokenLength > 0) {
        if (tokenLength < 6) {
            return setResult(false, "errTRTokenCode", "errSpanTokenCode", "Minimum 6 characters are required", 'txtTokenCode');
        }
        else {
            setResult(true, "errTRTokenCode", "errSpanTokenCode", "", 'txtTokenCode');
        }
        if ((!isAlphanumericCheck(txtTokenCode))) {
            return setResult(false, "errTRTokenCode", "errSpanTokenCode", "Token must not contain special characters.  Please enter correct token code.", 'txtTokenCode');
        }
        else {
            setResult(true, "errTRTokenCode", "errSpanTokenCode", "", 'txtTokenCode');
        }
        if ((isAnyCharacterCheck(txtTokenCode))) {
            return setResult(false, "errTRTokenCode", "errSpanTokenCode", "Token must not contain alphabets.  Please enter correct token code.", 'txtTokenCode');
        }
        else {
            setResult(true, "errTRTokenCode", "errSpanTokenCode", "", 'txtTokenCode');
        }
    }
    return true;
}

function isRSAPasswordValidCheck() {
    var valPwd, confValPwd, valUserId;
    var txtPwd = document.getElementById(('txtPassword'));
    if (txtPwd != null) {
        valPwd = txtPwd.value;
    }
    var txtConfPwd = document.getElementById(('txtConfirmPassword'));
    if (txtConfPwd != null) {
        confValPwd = txtConfPwd.value;
    }
    var txtUserId = document.getElementById("hidOldUserId");
    if (txtUserId != null) {
        valUserId = txtUserId.value;
    }
    if (valPwd != "" && confValPwd != "" && valUserId != "") {
        if (!isRsaPwValid(valPwd)) {
            alert(PwErrorMsg);
            txtPwd.focus();
            return false;
        }
        if (valPwd != confValPwd) {
            alert("Password & confirm Password must be same.");
            txtPwd.focus();
            return false;
        }
        if (valPwd == valUserId) {
            alert("Your Password cannot be the same as your User ID. Please choose a different Password.");
            txtPwd.focus();
            return false;
        }
    }
    else {
        alert("All fields are required on this page. Please enter your information in every field.");
        if (txtPwd != null) {
            txtPwd.focus();
        }
        return false;
    }
    return true;
}

