var   emptySSN       = "Error Message SU003:\nPlease enter your Social Security Number.";
var emptyAccountNumber = "Error Message SU005:\nPlease enter an Account Number.";
var invalidLoanCustomerId = "Error Message SU005:\nPlease check the Customer ID number you entered and try again.  The Customer ID should have eight digits.";
var   invalidSSN       = "Error Message SU004:\nThe Social Security Number you entered is not valid. Please re-enter your Social Security Number.";
var   invalidTin       = "The Tax Identification Number you entered is not valid. Please re-enter your Tax Identification Number.";
var   emptyTIN         = "Error Message SU019:\nPlease enter your Tax Identification Number.";
var emptyFirstName= "Error Message SU001:\nPlease enter your first name.";
var emptyLastName= "Error Message SU002:\nPlease enter your last name.";
var   invalidFirstName      = "Error Message SU031:\nPlease enter a valid First Name. Your entry cannot contain special characters.";
var   invalidLastName       = "Error Message SU032:\nPlease enter a valid Last Name. Your entry cannot contain special characters.";
var emptyBrkDlrType= "Error Message:\nPlease select a broker dealer.";
var emptyDOB= "Error Message SU0031:\nPlease enter your Date Of Birth.";
var emptyEmail= "Error Message SU021:\nPlease enter your e-mail address.";
var emptyReEmail    = "Error Message SU0033:\nPlease re-enter your e-mail address.";
var invalidReEmail     = "Error Message SU035:\nThe re-entered e-mail address is not valid. Please re-enter your e-mail address.";
var invalidEmail     = "Error Message SU008:\nThe e-mail address you entered is not valid. Please re-enter your e-mail address.";
var whitespace = " ";
var mmLength = 2;
var ddLength = 2;
var yyLength = 4;
var ph1Length =3;
var ph2Length =3;
var ph3Length =4;
var usZipCode1Length = 5;
var emptyAdd1           ="Please enter Address1.";
var emptyCity           ="Please enter City Name.";
var emptyState          ="Please select State.";
var emptyCountry        ="Please select Country.";
var emptyBirthMM        ="Please enter Birth Month.";
var emptyBirthDD        ="Please enter Birth Day.";
var emptyBirthYY        ="Please enter Birth Year.";
var emptyPhoneNo        ="Please enter Daytime phone.";
var emptyPIN            ="Please enter your Postal Code.";
var emptyAffiliateDOB   = "Please enter your Date Of Birth.";
var invalidPhoneN0      ="Please enter Valid Daytime phone.";
var AlphanumericPhoneNo ="Please enter Numeric number.";
var emptyPrimHolderName     ="Please enter Primary account holder name.";
var invalidPin              ="Please enter Valid postal code.";
var emptyAcctRel		="Please select the account relationship.";
var strInvalidChars1="`~!@#$%^&*()=+[]{}|;,.<>?:/\\";
var strValidChars="1234567890";
var ssn1Length = 3;
var ssn2Length = 2;
var ssn3Length = 4;
var tin1Length = 2;
var tin2Length = 7;
var ddLength = 2;
var mmLength = 2;
var yydLength = 4;
var state=0;
var isStatus = false;
var digitsInTaxInformationNumber = 9;

var browserName = navigator.appName;
var browserRealnum = navigator.appVersion;
var browserNum = parseInt(navigator.appVersion);
var browserParsed = browserRealnum.substring(0,4);
var cipher = navigator.cipher;
var keySize = navigator.keySize;
var userAgent = navigator.userAgent;
var msBrowserVersion = browserParsed
if(browserName == "Microsoft Internet Explorer") 
{
  p = browserRealnum.indexOf("MSIE") + 5;
  f = browserRealnum.substring(p,p+2);
  if((f.indexOf(" ")!=-1) || (f.indexOf(";")!=-1))
  {
    f = browserRealnum.substring(p,p+3);
  }
  if (f >= 5.0)
  {
    tin1Length = 2
    tin2Length = 7
    ssn1Length = 3
    ssn2Length = 2
    ssn3Length = 4
  }
}
else if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
    var userInfo = navigator.userAgent.split("/");

    if (userInfo[3].substring(0, 3) >= 6.0) {
        ssn1Length = 3
        ssn2Length = 2
        ssn3Length = 4
    }
}

function areAllZeros(s)
{
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if ( (isDigit(c)) && (c!="0") )
	   return false;
    }
    return true;
}

function areAllOnes(s)
{
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if ( (isDigit(c)) && (c!="1") )
	   return false;
    }
    return true;
}
function areAllNines(s)
{
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if ( (isDigit(c)) && (c!="9") )
	   return false;
    }
    return true;
}


function NOSSN()
{   
  document.getElementById("trSSN").style.display="none";
  document.getElementById("trDOB").style.display="";    
  document.getElementById("txtSSN1").value="";
  document.getElementById("txtSSN2").value="";
  document.getElementById("txtSSN3").value="";
  
}

function haveSSN()
{
  document.getElementById("trDOB").style.display="none";
  document.getElementById("trSSN").style.display="";
  document.getElementById("txtMM").value = "";
  document.getElementById("txtDD").value = "";
  document.getElementById("txtYYD").value = "";
}

function GoToNextSSN(event,tb,nexttbid,limit)
{           
        var key = event.keyCode;
        if (isInteger(tb.value))  //is digit
        {
            if (tb.value.length >= limit)
            {
                if (nexttbid == '')
                {
                    return false;
                }
                else
                {
                    document.getElementById(nexttbid).value = '';
                    document.getElementById(nexttbid).focus();
                }
            }
        }
        else if(key==8 || key==46)
        {
               
        }
        else
        {
            alert(invalidSSN);
            return false;
        }
}  
    
function AllowOnlyNumbers(event,evt)
{
    var key = event.keyCode;
    if (isInteger(evt.value))  //is digit
    {
        return true
    }
    else if(key==8 || key==46)
    {
           
    }
    else
        {
           alert(invalidSSN);
           return false;
        }
        
}
function onlyDigitNumbers(event,evt)
{
    var key = event.keyCode;
    if (isInteger(evt.value))  //is digit
    {
        return true
    }
    else if(key==8 || key==46)
    {
           
    }
    else
    {
      alert("Please enter only numbers");
      return false;
    }
    
}

var rdoPersonalAccts = "rdoPersonalAccts";
var rdoBusinessAccts = "rdoBusinessAccts";
var PerAcctNumber = "txtPerAcctNumber";
var BusAcctNumber = "txtBusAcctNumber";
var CblCustomerId = "txtLoanCustomerIdNumber";
var PerSSN1 = "txtPerSSN1";
var PerSSN2 = "txtPerSSN2";
var PerSSN3 = "txtPerSSN3";
var BusSSN1 = "txtBusSSN1";
var BusSSN2 = "txtBusSSN2";
var BusSSN3 = "txtBusSSN3";
var BusTIN1 = "txtBusTIN1";
var BusTIN2 = "txtBusTIN2";

function identifyUser()
{
  var isPerChecked = false;
  var isBusChecked = false;
  var rdoName;
  var txtAcctNumber;
  var txtSSN1;
  var txtSSN2;
  var txtSSN3;
  var txtTIN1 = "";
  var txtTIN2 = "";
  
  if(document.getElementById(rdoPersonalAccts).checked)
  {
    isPerChecked = true;
    rdoName = rdoPersonalAccts;
    txtAcctNumber = PerAcctNumber;
    txtSSN1 = PerSSN1;
    txtSSN2 = PerSSN2;
    txtSSN3 = PerSSN3;
  }
  else if(document.getElementById(rdoBusinessAccts).checked)
  {
    isBusChecked = true;
    rdoName = rdoBusinessAccts;
    txtAcctNumber = BusAcctNumber;
    txtSSN1 = BusSSN1;
    txtSSN2 = BusSSN2;
    txtSSN3 = BusSSN3;
    txtTIN1 = BusTIN1;
    txtTIN2 = BusTIN2;
  }
      
  if ((isPerChecked == false) && (isBusChecked == false)) 
  {
    alert("Please select either a business or a personal account to enroll");
    return false;
  }
  else if(validateData(rdoName, txtAcctNumber, txtSSN1, txtSSN2, txtSSN3, txtTIN1, txtTIN2) == false)
  {
    return false;
  }
  return true;
}

function identify() {
  //AccountNumber Validation
  var txtAcctNumber = document.getElementById(BusAcctNumber).value;
  if (txtAcctNumber == "") {
    alert(emptyAccountNumber);
    return false;
  }
  if (txtAcctNumber.length > 0) {
    if (txtAcctNumber.search("[^0-9]") != -1 || txtAcctNumber < 1 || txtAcctNumber.length < 6) {
      alert(invalidAcctNum);
      return false;
    }
  }

  //CBL CustomerId Validation
  if (!document.getElementById(CblCustomerId).disabled) {
    var txtLoanCustomerId = document.getElementById(CblCustomerId).value;
    if (txtLoanCustomerId.length < 8 || txtLoanCustomerId.search("[^0-9]") != -1 || txtAcctNumber < 1) {
      alert(invalidLoanCustomerId);
      return false;
    }
  }

  //Tin Number Validation
  var tin_1 = document.getElementById(BusTIN1).value;
  var tin_2 = document.getElementById(BusTIN2).value;

  if (tin_1 == "" && tin_2 == "") {
    alert(emptyTIN);
    return false;
  }
  if (tin_1 != "" && tin_2 != "") {
    if (areAllZeros(tin_1) && areAllZeros(tin_2)) {
      alert(invalidTIN);
      return false;
    }
    if (areAllOnes(tin_1) && areAllOnes(tin_2)) {
      alert(invalidTIN);
      return false;
    }
    if (areAllNines(tin_1) && areAllNines(tin_2)) {
      alert(invalidTIN);
      return false;
    }
    if (!checkTIN(tin_1, tin_2)) {
      alert(invalidTIN);
      document.getElementById(BusTIN1).focus();
      document.getElementById(BusTIN1).select();
      return false;
    }
  }

  //UserId Validation
  var valUserID = document.getElementById('inptUserId').value;
  if (valUserID != "") {
    if ((valUserID.length < 8) || (valUserID.length > 32)) {
      alert("The User ID you entered is not valid.User IDs must be at least 8 characters long,must contain at least one letter and one number and cannot use special characters or spaces.");
      document.getElementById('inptUserId').focus();
      return false;
    }
    if (!isAlphanumericCheck(valUserID)) {
      alert("The User ID you entered is not valid.User IDs must be at least 8 characters long,must contain at least one letter and one number and cannot use special characters or spaces.");
      document.getElementById('inptUserId').focus();
      return false;
    }
    if (!isAnyDigitCheck(valUserID)) {
      alert("The User ID you entered is not valid.User IDs must be at least 8 characters long,must contain at least one letter and one number and cannot use special characters or spaces.");
      document.getElementById('inptUserId').focus();
      return false;
    }
    if (!isAnyCharacterCheck(valUserID)) {
      alert("The User ID you entered is not valid.User IDs must be at least 8 characters long,must contain at least one letter and one number and cannot use special characters or spaces.");
      document.getElementById('inptUserId').focus();
      return false;
    }
    return true;
  }
  else {
    alert("Please enter a User ID.");
    document.getElementById('inptUserId').focus();
    return false;
  }
  
  return true;
}

function ToggleCustomerId() {
  var loanAcctLength = document.getElementById(BusAcctNumber).value.length;
  var customerIdField = document.getElementById('txtLoanCustomerIdNumber');
  var customerIdLabel = document.getElementById('lblLoanCustomerId');
  var customerIdReq = document.getElementById('loanCustomerIdReqd');
  if (customerIdField) {
    if (loanAcctLength > 6) {
      customerIdField.style.backgroundColor = 'transparent';
      customerIdField.disabled = false;
      customerIdLabel.className = '';
      customerIdReq.className = 'alertText2';
    }
    else {
      customerIdField.style.backgroundColor = '#CCCCCC';
      customerIdField.value = '';
      customerIdField.disabled = true;
      customerIdLabel.className = 'greytext';
      customerIdReq.className = 'alertText2 greytext';
    }
  }
}

function oninit() 
{
    if (document.getElementById(rdoPersonalAccts).checked) 
    {
        rdoAcctTypeSelected(rdoPersonalAccts);
    }
    else if (document.getElementById(rdoBusinessAccts).checked) 
    {
        rdoAcctTypeSelected(rdoBusinessAccts);
    }
} 

function validateData(rdoName, acctNumber, SSN1, SSN2, SSN3, TIN1, TIN2)
{
  var ssn_1 = "";         
  var ssn_2 = "";
  var ssn_3 = "";
  var dob_1 = "";
  var dob_2 = "";
  var dob_3 = "";
  var tin_1 = "";
  var tin_2 = "";
  var tinEntry = false;
  var ssnEntry = false;

  if(rdoName == rdoPersonalAccts && document.getElementById("trPerDOB").style.display == "")
  {
   if(document.formIdentifyUser.txtMM.value.length > 0)
      dob_1 = document.formIdentifyUser.txtMM.value;
    if(document.formIdentifyUser.txtDD.value.length > 0)
      dob_2 = document.formIdentifyUser.txtDD.value;
    if(document.formIdentifyUser.txtYYD.value.length > 0)
      dob_3 = document.formIdentifyUser.txtYYD.value;
  } 
  else
  {
    if(document.getElementById(SSN1).value.length > 0)
      ssn_1 = document.getElementById(SSN1).value;
    if(document.getElementById(SSN2).value.length > 0)
      ssn_2 = document.getElementById(SSN2).value;
    if(document.getElementById(SSN3).value.length > 0)
      ssn_3 = document.getElementById(SSN3).value;
  } 
  
  if(rdoName == rdoBusinessAccts)
  {
    if(document.getElementById(TIN1).value.length > 0)
      tin_1 = document.getElementById(TIN1).value;
    if(document.getElementById(TIN2).value.length > 0)
      tin_2 = document.getElementById(TIN2).value;
  }  

 if(document.getElementById(acctNumber).value=="")
  {
    alert(emptyAccountNumber);
    return false;
  }
  if(document.getElementById(acctNumber).value.length > 0)
  {
    if(document.getElementById(acctNumber).value.search("[^0-9a-zA-Z]")!=-1 || document.getElementById(acctNumber).value < 1)	
    {
      alert(invalidAcctNum);	      
      return false;
    }	
  }

  if (rdoName == rdoPersonalAccts && document.getElementById("trPerDOB").style.display == "") 
  {
    if ((dob_1 == "") || (dob_2 == "") || (dob_3 == "")) 
    {
      alert(emptyDOB);
      return false;
    }
    else
    {
      var sysDate = getcurrentdate();
      var mm = document.formIdentifyUser.txtMM.value;
      var dd = document.formIdentifyUser.txtDD.value;
      var yy = document.formIdentifyUser.txtYYD.value;
      var com = mm+"/"+dd+"/"+yy;
      if ( !isBirthDate(com)) 
      {
        alert(invalidDateOfBirth)
        document.formIdentifyUser.txtMM.focus()
        document.formIdentifyUser.txtMM.select();
        return false;
      }
      else if(compareDates(com,sysDate) == false )
      {
        alert("Date Of Birth  cannot be later  than today's Date")
        document.formIdentifyUser.txtMM.focus()
        document.formIdentifyUser.txtMM.select();
        return false;
      }
    }
  }                   
  else
  {   
    if(ssn_1 != "" && ssn_2 != "" && ssn_3 != "")
      ssnEntry = true;
    else if (tin_1 != "" && tin_2 != "")
      tinEntry = true;
                 
    if ((ssn_1 == "" && ssn_2 == "" && ssn_3 == "") && tinEntry == false) 
    {
      alert (emptySSN); 
      return false;     
    }
    
    if ((ssn_1 != "") || (ssn_2 != "") || (ssn_3 != "")) 
    {
      if(areAllZeros(ssn_1) && areAllZeros(ssn_2) && areAllZeros(ssn_3) )
      {
        alert (invalidSSN); 
        return false; 
      }

      if(areAllOnes(ssn_1) && areAllOnes(ssn_2) && areAllOnes(ssn_3) )
      {
        alert (invalidSSN); 
        return false; 
      }

      if(areAllNines(ssn_1) && areAllNines(ssn_2) && areAllNines(ssn_3) )
      {
        alert (invalidSSN); 
        return false; 
      }
      if(checkSSN(ssn_1,ssn_2,ssn_3) == false )
      {
        document.getElementById(SSN1).focus();
        alert(invalidSSN);
        return false;
      }
    }

    if(rdoName == rdoBusinessAccts)
    {
      if (tin_1 == "" && tin_2 == "" && ssnEntry == false)
      {
        alert(emptyTIN);
        return false;
      }
      if (tin_1 != "" && tin_2 != "")
      {
        if(areAllZeros(tin_1) && areAllZeros(tin_2))
        {
          alert(invalidTIN); 
          return false; 
        }        
        if(areAllOnes(tin_1) && areAllOnes(tin_2))
        {
          alert(invalidTIN);
          return false; 
        }
        if(areAllNines(tin_1) && areAllNines(tin_2))
        {
          alert(invalidTIN);
          return false; 
        }
        if (!checkTIN(tin_1,tin_2)) 
        {
          alert(invalidTIN);
          document.getElementById(TIN1).focus();
          document.getElementById(TIN1).select();
          return false;
        }
      }
    }
  }
  return true;
}
  
function getDocumentDomain() 
{
  try
  {	
    var d = document.domain;
    if(d.indexOf(".") > -1)
    {
      var end = d.substring(d.lastIndexOf("."), d.length);
      d = d.substring(0, d.lastIndexOf("."));
      d = d.substring(d.lastIndexOf(".") + 1, d.length);
      d = d + end;
    }
    return d;
  }
  catch(e)
  {
   return null;
  }
}
      
function ClearAcctNumberAndSSN(AcctNumber, SSN1, SSN2, SSN3)
{
  document.getElementById(AcctNumber).value = "";
  document.getElementById(SSN1).value = "";
  document.getElementById(SSN2).value = "";
  document.getElementById(SSN3).value = "";
}

function ClearTIN(TIN1, TIN2)
{
  document.getElementById(TIN1).value = "";
  document.getElementById(TIN2).value = "";
}

function rdoAcctTypeSelected(rdoAccts)
{
  var AcctNumber = "";
  var SSN1 = "";
  var SSN2 = "";
  var SSN3 = "";
  var TIN1 = "";
  var TIN2 = "";
  var prevSelectedRadio = document.getElementById("hdnPrevSelectedRadio").value;
  var rdoControlName=document.getElementById(rdoAccts);
  
  if(rdoControlName.checked == true)
  {
    if(prevSelectedRadio == rdoPersonalAccts)
    {
      AcctNumber = document.getElementById(PerAcctNumber).value;
      SSN1 = document.getElementById(PerSSN1).value;
      SSN2 = document.getElementById(PerSSN2).value;
      SSN3 = document.getElementById(PerSSN3).value;
      
      ClearAcctNumberAndSSN(PerAcctNumber, PerSSN1, PerSSN2, PerSSN3);
    }
    else if (prevSelectedRadio == rdoBusinessAccts)
    {
      AcctNumber = document.getElementById(BusAcctNumber).value;
      SSN1 = document.getElementById(BusSSN1).value;
      SSN2 = document.getElementById(BusSSN2).value;
      SSN3 = document.getElementById(BusSSN3).value;
      TIN1 = document.getElementById(BusTIN1).value;
      TIN2 = document.getElementById(BusTIN2).value;
      
      ClearAcctNumberAndSSN(BusAcctNumber, BusSSN1, BusSSN2, BusSSN3);
      ClearTIN(BusTIN1, BusTIN2);
    }
    
    if (rdoControlName.value == rdoPersonalAccts) 
    {
      document.getElementById("trPersonalAccts").style.display = "";
      document.getElementById("trPerSSN").style.display = "";
      document.getElementById("trPerDOB").style.display = "none";
      document.getElementById("trBusinessAccts").style.display = "none";
      
      document.getElementById(PerAcctNumber).value = AcctNumber;
      document.getElementById(PerSSN1).value = SSN1;
      document.getElementById(PerSSN2).value = SSN2;
      document.getElementById(PerSSN3).value = SSN3;
    }                       
    else if (rdoControlName.value == rdoBusinessAccts) 
    {
      document.getElementById("trBusinessAccts").style.display = "";
      document.getElementById("trPersonalAccts").style.display = "none";
      
      document.getElementById(BusAcctNumber).value = AcctNumber;
      document.getElementById(BusSSN1).value = SSN1;
      document.getElementById(BusSSN2).value = SSN2;
      document.getElementById(BusSSN3).value = SSN3;
      document.getElementById(BusTIN1).value = TIN1;
      document.getElementById(BusTIN2).value = TIN2;
    }
    
    document.getElementById("hdnPrevSelectedRadio").value = rdoAccts;
  }
}

function DoNotHaveSSN()
{   
  document.getElementById("trPerDOB").style.display="";    
  document.getElementById("trPerSSN").style.display="none";
  document.getElementById(PerSSN1).value="";
  document.getElementById(PerSSN2).value="";
  document.getElementById(PerSSN3).value="";
}

function HaveSSN2Enroll()
{
  document.getElementById("trPerDOB").style.display="none";
  document.getElementById("trPerSSN").style.display="";
  document.getElementById("txtMM").value = "";
  document.getElementById("txtDD").value = "";
  document.getElementById("txtYYD").value = "";
}



function ValidateSSN(currentControl, nextControl, length, errorMessage)
{
  if ((!isInteger(document.getElementById(currentControl).value)))
  {
    alert(errorMessage);
    document.getElementById(currentControl).focus();
  }
  else if ((isInteger(document.getElementById(currentControl).value)) &&(document.getElementById(currentControl).value.length == length)) 
  {
    document.getElementById(nextControl).focus();
  }
}

function HandleKeyPress(rdoName, currentControl)
{
  var nextControl;
  var length;
  var errorMessage;
  
  if(rdoName == "rdoPersonalAccts" && document.getElementById("trPerDOB").style.display == "")
  {
    if (currentControl == "txtMM")
    {
      if ( ( !isInteger(document.getElementById("txtMM").value ) ) )
      {
        alert(invalidDate);
        document.getElementById("txtMM").focus();
      }
      
      if ((isInteger(document.getElementById("txtMM").value)) && (document.getElementById("txtMM").value.length == mmLength))
        document.getElementById("txtDD").focus()
    }
    if (currentControl == "txtDD")
    {
      if ( ( !isInteger(document.getElementById("txtDD").value ) ) )
      {
        alert(invalidDate);
        document.getElementById("txtDD").focus();
      }
      
      if (( isInteger(document.getElementById("txtDD").value)) &&( document.getElementById("txtDD").value.length == ddLength ))
        document.getElementById("txtYYD").focus()
    }
    if (currentControl == "txtYYD")
    {
      
      if ( ( !isInteger(document.getElementById("txtYYD").value ) ) )
      {
        alert(invalidDate);
        document.getElementById("txtYYD").focus();
      }
      
      if (( isInteger(document.getElementById("txtYYD").value)) &&( document.getElementById("txtYYD").value.length == yydLength ))
        document.getElementById("txtYYD").focus()
    }
  }
  else
  {
    if(rdoName == rdoPersonalAccts)
    {
      errorMessage = invalidSSN;
      if (currentControl == PerSSN1) 
      {
        nextControl = PerSSN2;
        length = ssn1Length;
      }
      else if (currentControl == PerSSN2) 
      {
        nextControl = PerSSN3;
        length = ssn2Length;
      }
      else if (currentControl == PerSSN3) 
      {
        nextControl = PerSSN3;
        length = ssn3Length;
      }
    }
    
    if(rdoName == rdoBusinessAccts)
    {
      if (currentControl == BusSSN1) 
      {
        nextControl = BusSSN2;
        length = ssn1Length;
        errorMessage = invalidSSN;
      }
      else if (currentControl == BusSSN2) 
      {
        nextControl = BusSSN3;
        length = ssn2Length;
        errorMessage = invalidSSN;
      }
      else if (currentControl == BusSSN3) 
      {
        nextControl = BusSSN3;
        length = ssn3Length;
        errorMessage = invalidSSN;
      }
      else if (currentControl == BusTIN1) 
      {
        nextControl = BusTIN2;
        length = tin1Length;
        errorMessage = invalidTIN;
      }
      else if (currentControl == BusTIN2) 
      {
        nextControl = BusTIN2;
        length = tin2Length;
        errorMessage = invalidTIN;
      }
    }
    
    ValidateSSN(currentControl, nextControl, length, errorMessage);
  }
}

function ValidateCreateUserIDForm()
{
    var msgerremptyaddress="Address is a required field. Please enter a valid address and try again.";
    var msgerraddress="Error Message 8:\nYou may use any characters in the Address 1 and Address 2 \nfields except:  *, /, \\, <, > and ~. Please re-enter your address and try again.";
    var msgerrcity="Error Message 10:\nCity is a required field. Please enter a City and try again."
    var msgerrCitym ="Error Message 10:\nYou have entered an invalid character in the city field. Please enter a valid City and try again."

    var msgerrstate = "Error Message 11:\nState is a required field. Please enter a State and try again."
    var msgerrstatem = "Error Message 11:\nYou have entered an invalid character in the state field. Please enter a valid State and try again."

    var msgerrzip="Error Message P003:\nZip Code is a required field. Please enter a Zip Code and try again.(for example: 12345 or 12345-1234).";
    var msgerrzipUS="Error Message 12:\nYou have entered an invalid character in the zip code field.\nPlease enter a valid zip code and try again."
        
    var errCountry = "Error Message 13:\nCountry is a required field. Please select a country and try again."

    var ddlcountry = document.getElementById("ddlCountry");
    
    if(document.getElementById("trEmail")) 
    {
      if(IsEmpty(document.getElementById("txtEmail")))
      {
        alert(emptyEmail);
        document.getElementById("txtEmail").focus();
        return false;
      } 
      else
      {
        if(!validateEmail(document.getElementById("txtEmail"),document.getElementById("txtConfirmMail")))
        {
          return false;
        }
      	
        if (!compareEmails(document.getElementById("txtEmail").value,document.getElementById("txtConfirmMail").value))
        {
          alert(unmatchedEmailId);
          document.getElementById("txtConfirmMail").value="";
          document.getElementById("txtConfirmMail").focus();
          return false;
        }
      }
    }
    return true;
}

function ValidateSelectAccountViewForm()
{
  var rdbPrimaryAccountList= document.getElementsByName("rdPrimaryAccounts");
  var chkYes = false;
  for(var i = 0;i < rdbPrimaryAccountList.length;i++)
  {
    if(rdbPrimaryAccountList[i].checked)
    {
      chkYes = true;    
    }
  }
  if(chkYes == false)
  {
    alert("Primary Billing Account is required.");
    return false;
  }
}

function isInvalidChars(strElementValue)
{
     strInvalidChars='<>"()=[];*$%^|';
     for (i=0; i < strElementValue.length; i++)
     {
       chrElementChar = strElementValue.substring(i, i+1);
        if ((strInvalidChars.indexOf(chrElementChar) != -1))
        {
            return true;
        }
     }
     return false;
}

function IdentifyAffiliateUser()
{   
 if(IsEmpty(document.getElementById("txtFirstName")))   
  {
    alert(emptyFirstName);
    document.getElementById("txtFirstName").focus();
    return false
  }
  else if (isInvalidChars(document.getElementById("txtFirstName").value))
  {
	alert(invalidFirstName);
    document.getElementById("txtFirstName").focus();
    return false;
  }
  
  if(IsEmpty(document.getElementById("txtLastName")))                
  {
    alert(emptyLastName);
    document.getElementById("txtLastName").focus();
    return false
  } 
  else if (isInvalidChars(document.getElementById("txtLastName").value))
  {
	alert(invalidLastName);
    document.getElementById("txtLastName").focus();
    return false;
  }
  
                 
  if(document.getElementById("trSSN").style.display == "")                
  {
    if (IsEmpty(document.getElementById("txtSSN1"))||IsEmpty(document.getElementById("txtSSN2"))|| IsEmpty(document.getElementById("txtSSN3")))
    {
      alert(emptySSN);
      document.getElementById("txtSSN1").focus();
      return false
    }        
    if(document.getElementById("txtSSN1").value!="" && document.getElementById("txtSSN2").value!="" && document.getElementById("txtSSN3").value!="")
    {
      if(areAllZeros(document.getElementById("txtSSN1").value) && areAllZeros(document.getElementById("txtSSN2").value) && areAllZeros(document.getElementById("txtSSN3").value) )
      {
        alert (invalidSSN); 
        return false; 
  }
      if(areAllOnes(document.getElementById("txtSSN1").value) && areAllOnes(document.getElementById("txtSSN2").value) && areAllOnes(document.getElementById("txtSSN3").value) )
      {
        alert (invalidSSN); 
        return false; 
      }    
      if(areAllNines(document.getElementById("txtSSN1").value) && areAllNines(document.getElementById("txtSSN2").value) && areAllNines(document.getElementById("txtSSN3").value) )
      {
        alert (invalidSSN); 
        return false; 
      }    
    if(checkSSN(document.getElementById("txtSSN1").value,document.getElementById("txtSSN2").value,document.getElementById("txtSSN3").value) == false )
    {
      document.getElementById("txtSSN1").focus();
      alert(invalidSSN);
      return false;
    }    
    }
  }
  else if (document.getElementById("trDOB").style.display == "")
  {
    if (IsEmpty(document.getElementById("txtDD"))||IsEmpty(document.getElementById("txtMM"))|| IsEmpty(document.getElementById("txtYYD")))
    {
      alert(emptyDOB);
      document.getElementById("txtMM").focus();
      return false;
  }      
  } 
  if(document.getElementById("trDOB").style.display == "")
  {
    var sysDate = getcurrentdate();
    var mm = document.frmIdentifyAffiliate.txtMM.value;
    var dd = document.frmIdentifyAffiliate.txtDD.value;
    var yy = document.frmIdentifyAffiliate.txtYYD.value;
    var com = mm+"/"+dd+"/"+yy;
    //Here we call isDate function which is a part of common.js
    if(!isBirthDate(com))
    {
        alert(invalidDateOfBirth)
        document.frmIdentifyAffiliate.txtMM.focus();
        document.frmIdentifyAffiliate.txtMM.select();
        return false;
    }
    else if(compareDates(com,sysDate) == false )
    {
        alert("Date Of Birth  cannot be later  than today's Date")
        document.frmIdentifyAffiliate.txtMM.focus()
        document.frmIdentifyAffiliate.txtMM.select();
        return false;
    }
  }  
 if(document.getElementById("BrokerDealerType_ddlBrokerDealerType").options[0].selected == true) 
  {   
    alert(emptyBrkDlrType);
    document.getElementById("BrokerDealerType_ddlBrokerDealerType").focus();
    return false;
  } 
  if (IsEmpty(document.getElementById("txtAccountNumber")))
  {    
    alert(emptyAccountNumber);
    document.getElementById("txtAccountNumber").focus();
    return false;
  }      
  if(document.getElementById("txtAccountNumber").value.length > 0)
  {
       if(document.getElementById("txtAccountNumber").value.search("[^0-9a-zA-Z]")!=-1 || document.getElementById("txtAccountNumber").value < 1)	
	     {
	       alert(invalidAcctNum);	      
	       return false;
}
  }  
}

function AffiliateUserCreation()
{
  if(IsEmpty(document.getElementById("txtAddressOne")))
  {
    alert(emptyAdd1);
    document.getElementById("txtAddressOne").focus();
    document.getElementById("txtAddressOne").select();
    return false;
  }
  else if(IsEmpty(document.getElementById("txtCity")))
  {
    alert(emptyCity);
    document.getElementById("txtCity").focus();
    document.getElementById("txtCity").select();
    return false;
  }
  else if(document.getElementById("ddlCountryList").options[0].selected == true) 
  {   
    alert(emptyCountry);
    document.getElementById("ddlCountryList").focus();
    return false;
  }   
  if(document.getElementById("ddlStateList").options[0].selected == true && document.getElementById('ddlCountryList').value == "US"  ) 
  {
    alert(emptyState);
    document.getElementById("ddlStateList").focus();
    return false;
  }
  else if(IsEmpty(document.getElementById("txtPIN")))
  {   
    alert(emptyPIN);
    document.getElementById("txtPIN").focus();
    document.getElementById("txtPIN").select();
    return false;
  }     
  else if(!isValidPIN(document.getElementById("txtPIN").value))
  {
     alert(invalidPin);
    return false;
  }
  else if ( (isEmpty(document.getElementById("txtDob1").value)) && (isEmpty(document.getElementById("txtDob2").value)) && (isEmpty(document.getElementById("txtDob3").value)))
  {
      document.getElementById("txtDob1").focus();
      document.getElementById("txtDob1").select();
      alert(emptyAffiliateDOB);
    return false;
  }
  else 
  {
      var sysDate = getcurrentdate();
    var mm = document.getElementById("txtDob1").value;
    var dd = document.getElementById("txtDob2").value;
    var yy = document.getElementById("txtDob3").value;
    var com = mm+"/"+dd+"/"+yy;
      if(!isBirthDate(com))
      {
        alert(invalidDateOfBirth)
        document.getElementById("txtDob1").focus();
        document.getElementById("txtDob1").select();
        return false;
      }
      else if(compareDates(com,sysDate) == false )
    {
        alert("Date Of Birth  cannot be later  than today's Date")
      document.getElementById("txtDob1").focus();
        document.getElementById("txtDob1").select();
      return false;
    }
  }
  if(IsEmpty(document.getElementById("txtDayPhone1")))
  {
    alert(emptyPhoneNo);
    document.getElementById("txtDayPhone1").focus();
    document.getElementById("txtDayPhone1").select();
    return false;
  }
  else if(document.getElementById("affiliateRelationship_ddlRelationType").options[0].selected == true) 
  {   
    alert(emptyAcctRel);
    document.getElementById("affiliateRelationship_ddlRelationType").focus();
    return false;
  }   
  else if(IsEmpty(document.getElementById("txtAccountHolderName")))
  {
    alert(emptyPrimHolderName);
    document.getElementById("txtAccountHolderName").focus();
    document.getElementById("txtAccountHolderName").select();
    return false;
  }
    
}



function isValidPIN(strPin)
{
  if (strPin.length !=5 &&  (strPin.length !=9 && ( strPin.indexOf("-") == -1 ) )) 
  {
      return false;
  } 
  else if(strPin.length != 10 && ( (strPin.indexOf("-") != -1 ) && strPin.indexOf("-") == 5 ) )
  {
      return false;
  }
  return true;
}

function handlePhone(textValue)
{
	for(i=0;i<textValue.value.length;i++)
	{
		var tempChar=textValue.value.substring(i,i+1);
			
		if( (strInvalidChars1.indexOf(tempChar) != -1) || ( (tempChar=="-" && i != 3 ) && (tempChar=="-" && i != 7 ) ))			
                  {
				  alert(invalidPhoneN0);
				  textValue.value="";
				  textValue.focus;
				  return false;
			  }
				
			  if( !isInteger(tempChar) )
			  {
				  if( tempChar=="-" && i==3 )
				    {
						}
				else if(tempChar=="-" && i==7)
				{
				
				}
				else
				{
          alert(AlphanumericPhoneNo);
          textValue.value="";
					textValue.focus;
          return false;
        }
			}
		}
	return true;
}
	
function handlePinTab(textValue)
{
		for(i=0;i<textValue.value.length;i++)
		{
			var tempChar=textValue.value.substring(i,i+1)
			
			if((strInvalidChars1.indexOf(tempChar) != -1) || (tempChar=="-" && i != 5)  )			
			{
				alert(invalidPin);
				textValue.value="";
				textValue.focus;
				return false;
			}
		}
  return true;
}

function AffiliateAddAccount()
{
  var emptyPrimHolderName     ="Please enter Primary account holder name.";
  if(document.getElementById("BrokerDealerType_ddlBrokerDealerType").selectedIndex==0)
  {
    alert(emptyBrkDlrType);
    document.getElementById("BrokerDealerType_ddlBrokerDealerType").focus();
    return false;
  }
  else if(IsEmpty(document.getElementById("txtAccountNumber")))
  {
    alert(emptyAccountNumber);
    document.getElementById("txtAccountNumber").focus();
    return false;
  }
  else if(document.getElementById("affiliateRelationship_ddlRelationType").selectedIndex==0)
  {
    alert(emptyAcctRel);
    document.getElementById("affiliateRelationship_ddlRelationType").focus();
    return false;
  }
  else if(IsEmpty(document.getElementById("txtAccountHolder")))
  {
    alert(emptyPrimHolderName);
    document.getElementById("txtAccountHolder").focus();
    return false;
  }
}

function ValidateAuthenticateForm() {
    var validChars = "0123456789.";
    if (IsEmpty(document.getElementById("textLastWithdrawl"))) {
        alert("Enter Date and Amount. Please enter the date and amount of the last transaction.");
        if (IsEmpty(document.getElementById("DateLastWithdrawl_Value"))) {
            document.getElementById("DateLastWithdrawl_Value").focus();
        }
        else if (IsEmpty(document.getElementById("textLastWithdrawl"))) {
            document.getElementById("textLastWithdrawl").focus();
        }
        return false;
    }
    if (!isAuthDate(document.getElementById("DateLastWithdrawl_Value").value)) {
        return false;
    }

    var str = document.getElementById("textLastWithdrawl").value;
    var isDigit = true;
    for (i = 0; i < str.length; i++) {
        var c = str.charAt(i);
        if ((isLetter(c))) {
            isDigit = false;
        }
    }
    if (!isValidChars(validChars, str)) {
        isDigit = false;
    }
    if (isDigit == false) {
        alert("Incorrect Amount Format. Please enter only numbers as the amount.");
        document.getElementById("textLastWithdrawl").value = "";
        document.getElementById("textLastWithdrawl").focus();
        return false;
    }


}
function ClickAuthQuesform() {
    var withdrawOption = document.getElementById('radBusinessWithdrawl');
    var withdrawDate = document.getElementById('DateLastWithdrawl_Value');
    var withdrawAmount = document.getElementById('textLastWithdrawl');
    var withdrawButton = document.getElementById('DateLastWithdrawl_Value_calendar')
    withdrawDate.className = "inputTextBox";
    withdrawAmount.className = "inputTextBox";

    withdrawDate.disabled = false;
    withdrawAmount.disabled = false;
    if (withdrawButton) {
        withdrawButton.href = "javascript:ShowCalendar('CalenderPage.ashx?Opt=SBS-US|true|00010101|99991231&Sel=', 'DateLastWithdrawl_Value');";
    }

    withdrawDate.focus();
}
function isLetter (c)
{   
  return ( ((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")) )
}
function isValidChars(validChars,isValue)
{
  var retVal = true;
  for (i=0;i<isValue.length;i++)
  {
    if (!(validChars.indexOf(isValue.substring(i,i+1).toLowerCase()) >= 0))
    {
      retVal = false;
      break;
    }
  }
  return retVal;
}
function isDigit (c)
{   
  return ((c >= "0") && (c <= "9"))
}

function ValidatePackageSelection()
{
    var radioChoice;
    var flagChecked = 0;

    var choice_len = document.frmSSOCMLPackageSelection.rbPlanChoice.length;
    for(i=0; i<choice_len; i++) 
    {
        radioChoice = document.getElementById('_rbPlanChoice'+i);
        if (radioChoice.checked == true) 
        {
            flagChecked = 1;
            return true;
        }
    }

    if(flagChecked == 0)
    {
        alert("Service Plan is required");
        radioChoice = document.getElementById('_rbPlanChoice'+0);
        radioChoice.focus();
        return false;
    }
}

function openChildWindow(mypage,myname){
  var settings='width=775,height=625,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=yes';
  win=window.open(mypage,myname,settings);
}
function isAuthDate(dateStr) 
{
  if (dateStr!=null && dateStr!='')
  {
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
    var matchArray = dateStr.match(datePat); 
    if (matchArray == null)
    {
      alert("Incorrect Date Format. Please enter the date in MM/DD/YYYY format only.");
      return false;
    }
    month = matchArray[1]; 
    day = matchArray[3];
    year = matchArray[5];
    if (month < 1 || month > 12) 
    { 
        alert("Incorrect Date Format. Please enter the date in MM/DD/YYYY format only.");
        return false;
    }
    if (day < 1 || day > 31) 
    {
     alert("Incorrect Date Format. Please enter the date in MM/DD/YYYY format only.");
     return false;
    }
    if ((month==4 || month==6 || month==9 || month==11) && day==31) 
    {
      alert("Incorrect Date Format. Please enter the date in MM/DD/YYYY format only.");
      return false;
    }
    if (month == 2)
    { // check for february 29th
      var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
      if (day > 29 || (day==29 && !isleap)) 
      {
        alert("Incorrect Date Format. Please enter the date in MM/DD/YYYY format only.");
        return false;
      }
    }
  }
  return true; // date is valid
}


function isBirthDate(dateStr) 
{
   if (dateStr!=null && dateStr!='')
    {
       var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
       var matchArray = dateStr.match(datePat); 
       if (matchArray == null)
       {
          return false;
       }
        month = matchArray[1]; 
        day = matchArray[3];
        year = matchArray[5];
        if (month < 1 || month > 12) 
        { 
            return false;
        }
        if (day < 1 || day > 31) 
        {
           return false;
        }
        if ((month==4 || month==6 || month==9 || month==11) && day==31) 
        {
            return false;
        }
        if (month == 2)
        { 
            var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
            if (day > 29 || (day==29 && !isleap)) 
            {
                return false;
            }
        }
    }
   return true; 
}



function handleState()
{
	state=document.getElementById('ddlStateList').selectedIndex;
	return true;
}

function handleCountryChange()
{
	var chooseSelect = document.getElementById('ddlCountryList').selectedIndex;
	if(document.getElementById('ddlCountryList'))
	{
    if (document.getElementById('ddlCountryList').value == "US")
    {
   	  document.getElementById('ddlStateList').disabled = false;
      document.getElementById('ddlStateList').value=document.getElementById('ddlStateList').options[state].value;
    }
	  else
	  {
 	 	  document.getElementById('ddlStateList').disabled = true;
      document.getElementById('ddlStateList').selectedIndex = 0;
	  }
	}
}
function DisplaySDFNote () {
    var obj = document.getElementById("optNonSigner");
    var NoteWithSADFLink = document.getElementById("trNotewithSADFLink1");
    if (NoteWithSADFLink)
    {
    if ( obj.checked == true ) 
    {
        NoteWithSADFLink.style.display="";
        }
        else
        {
        NoteWithSADFLink.style.display = "none";
        }
    }
    return true;
}

function DisplaySDFNoteWithTIN () {
    var obj = document.getElementById("optAllCompanyAccounts");
    var NoteWithSADFLink = document.getElementById("trNotewithSADFLink");
    var Tin = document.getElementById("trTin");

    if (NoteWithSADFLink)
{
    if ( obj.checked == true ) 
    {
        Tin.style.display="";
        NoteWithSADFLink.style.display="";
        }
        else
        {
        Tin.style.display = "none";
        NoteWithSADFLink.style.display = "none";
        }
    }
    return true;
}


function IsAuthoritySelected()
{
  var signer = document.getElementById('optSigner');
  var nonSigner = document.getElementById('optNonSigner');
  var allAccount = document.getElementById('optAllCompanyAccounts');
  var onlyMyAccount = document.getElementById('optAllMyAccounts');
  
  var tin1 = document.getElementById('txtTIN1');
  var tin2 = document.getElementById('txtTIN2');
  
  var flagChecked = 0;
  if ( signer != null )
  {
    if( signer.checked == true )
      flagChecked = 1; 
  }
  if ( nonSigner != null )
  {
    if( nonSigner.checked == true )
      flagChecked = 1; 
  }
  if ( allAccount != null )
  {
    if( allAccount.checked == true )
      flagChecked = 1; 
  }
  if ( onlyMyAccount != null )
  {
    if( onlyMyAccount.checked == true )
      flagChecked = 1;
  }       
  if ( flagChecked == 0 )
  {
    alert("Invalid Selection. Please choose from one of the options below.");
    return false;
  }
  if ( allAccount && allAccount.checked == true )
  {
    if ( !checkTIN(tin1.value,tin2.value) ) 
    {
      alert('Invalid Tax ID Number. Please enter the Tax ID Number again.');
      document.frmSSOCMLInstruction.txtTIN1.focus();
      document.frmSSOCMLInstruction.txtTIN1.select();
      return false;
    }  
  }
}

//Email Validation
function validateEmail(txtEmail,txtReEmail)
{
		if (!eMailValidator(txtEmail.value))
		{
			txtEmail.select();
			alert(invalidEmail);
			txtEmail.focus();
			return false;
		}
		if(txtReEmail != null)
		{
			if (isEmpty(txtReEmail.value))
			{
				txtReEmail.select();
				alert(emptyReEmail);
				txtReEmail.focus();
				return false;
			 }
			 else if (!eMailValidator(txtReEmail.value))
			 {
				txtReEmail.select();
				alert(invalidReEmail);
				txtReEmail.focus();
				return false;
			 }
		 }
		if (!isValidEmail(txtEmail, false)) 
		{
			txtEmail.select();
			alert(invalidEmail);
			txtEmail.focus();
			return false;
		}
		if(txtReEmail != null)
		{
			if (isEmpty(txtReEmail.value)) 
			{
				txtReEmail.select();
				alert(emptyReEmail);
				txtReEmail.focus();
				return false;
			} else if (!isValidEmail(txtReEmail, false)) 
			{
				txtReEmail.select();
				alert(invalidReEmail);
				txtReEmail.focus();
				return false;
			}
		}
	  return true;
}

function eMailValidator(strEMailId)
{
	isStatus = isDomain(strEMailId);
	if(isStatus == true)
	{
		isStatus = isValidLength(strEMailId);
	}
	if(isStatus == true)
	{
		isStatus = isValidSubDomain(strEMailId);
	}
	if(isStatus == true)
	{
		isStatus = isValidExtension(strEMailId);
	}
	if(isStatus == true)
	{
		isStatus = isValidAccount(strEMailId);
	}
	return isStatus;
}


function isValidEmail(theField,emptyOK)
{
    var theField = righttrim(theField.value);
    // The email field should not be empty
    if ((emptyOK == true) && (isEmpty(theField)))
       return true;
    // There should not any whitespace in the entered field
    else if (isWhitespace(theField))
       return false;
    // check the validity of the email format.
    else
       return isEmail(theField)
}
function checkEmailInput(formValue)
{
    var alphaNumericStr = "abcdefghijklmnopqrstuvwxyz0123456789@_ .-"
    retVal = true;
    for (i=0;i<formValue.length;i++)
    {
       if (!(alphaNumericStr.indexOf( formValue.substring(i,i+1).toLowerCase() ) >= 0))
       {
         retVal = false;
       }
     }
     return retVal;
}
function isWhitespace (s)
{   
  var i;
  if (isEmpty(s)) return true;
  for (i = 0; i < s.length; i++) {
    var c = s.charAt(i);
    if (whitespace.indexOf(c) == -1) {
       return false;
    }
  }
  return true;
}


function isDomain(strEMailId)
{
	var intTemp = strEMailId.indexOf("@");
	var intTemp1 = strEMailId.indexOf("@",intTemp+1);
	if(intTemp!=-1)
	{
		if(intTemp1==-1)//no multiple @
		{
			isStatus = true;//mail id success
		}
		else
		{
			isStatus = false;//mail id Syntax error
		}
	}
	else
	{
		isStatus = false;//mail id Syntax error
	}
	return isStatus;
}

function isValidLength(strEMailId)
{
	if(strEMailId.length <= 100 && strEMailId.length > 0)
	{
		isStatus = true;//Success
	}
	else
	{
		isStatus = false;//Error
	}
	return isStatus;
}

function isValidSubDomain(strEMailId)
{
	var strDomain=strEMailId.substring(strEMailId.indexOf("@")+1);
	if(strDomain.length > 0)
	{	//the domain is converted to lower case and compare only lower
		//case ASCII 97-122
		strDomain=strDomain.toLowerCase();
		if(strDomain.substring(0,1) == '.')
		//if(strDomain.startsWith("."))
		{
			isStatus = false;
			return isStatus;
		}
		for (var i = 0; i < strDomain.length; i++)
		{
			var c = strDomain.charCodeAt(i);
			if ((c > 96 & c < 123) | (c >47 & c <58)|(c==46)|(c==45))
			{
				isStatus = true;
			}
			else
			{
				isStatus = false;
				break;
			}
		}
		//This is to check if the subdomain is atleast 1 characters.
		for(var k=0;k<strDomain.length -2;k++)
		{
			//char chrTest =strDomain.charAt(k);
			//System.out.println("Char : "+chrTest);
			if(strDomain.charAt(k)==strDomain.charAt(k+1))
			{
				if(strDomain.charAt(k)=='.')
				{
					isStatus = false;
					break;
				}
			}
		}//subdomain check for atleast one character ends here
	}
	else//if the there is no domain
	{
		isStatus = false;
	}
	return isStatus;
}//end of isValidSubDomain()

function isValidExtension(strEMailId)
{
	var strExtension=strEMailId.substring(strEMailId.lastIndexOf(".")+1);
	if(strExtension.length<2||strExtension.length>6)
	{
		isStatus = false;
		return isStatus;
	}
	else
	{
		strExtension=strExtension.toLowerCase();
		for (var i = 0; i < strExtension.length; i++)
		{
			var c = strExtension.charCodeAt(i);

			if(c<97||c>122)
			{
				isStatus = false;
				return isStatus;
			}
		}
	}
	return isStatus;
}
function isValidAccount(strEMailId)
{
	if(strEMailId.indexOf("@")!=-1)
	{
		//if @ is present then procedd ahead
		var strAccount=strEMailId.substring(0,strEMailId.indexOf("@"));
		if(strAccount.length==0)
		{
			//if the coount does not exist
			isStatus = false;
			return isStatus;
		}
		else
		{
			if((strAccount.charAt(0)=='.') || (strAccount.charAt(strAccount.length-1) == '.'))//if  (.) dot is there in Account
			{
				isStatus = false;
				return isStatus;
			}
			else
			{
				for (var i = 0; i < strAccount.length; i++)
				{
					var intChar = strAccount.charCodeAt(i);
					//if(intChar==9||intChar==32||intChar==42||intChar==47||intChar==126||intChar==60||intChar==62||intChar==92)
					if(intChar==9||intChar==32||intChar==33||intChar==34||intChar==35||intChar==36||intChar==37
						||intChar==38||intChar==39||intChar==40||intChar==41||intChar==42||intChar==43
						||intChar==44||intChar==47||intChar==59||intChar==60||intChar==58||intChar==61
						||intChar==62||intChar==63||intChar==91||intChar==92||intChar==93||intChar==94
						||intChar==96||intChar==123||intChar==124||intChar==125||intChar==126||intChar==145
						||intChar==146||intChar==166)
					{
						isStatus = false;
						return isStatus;
					}
				}
			}
		}
	}
	else//if there is no @ in mail address.
	{
		isStatus = false;
		return isStatus;
	}
	return isStatus;
}//end of isValidAccount()

function isEmail (s)
{
  if (isWhitespace(s)) return false;
  var sLength = s.length;
  var i = 0;
  var atcnt=0;
  var dotcnt=0;
  var atcnttwo=0;
  var atcntdotcnt=0;
  var alpafterat =false;
	var alpafterdot =false;
	var underscore = 0;
	var t=0;
	var t2=0;
	var t3=0;
	var at=0;
	var at2=0;
	var oneat=false;
	var oneat2=false;
	var oneat3=false;
	var alpafterat2=false;
	var onedot = false;

	var alphaNumericString = "abcdefghijklmnopqrstuvwxyz0123456789"
    while (i < sLength) {
        var c = s.charAt(i);
		t++
		t2++
		t3++
		if(s.charAt(i) == "@") {
				at=t2;
		}
		if(s.charAt(i) == "@") {
				at2=t3;
		}
        if(t==1 && s.charAt(i) == "@") {
			oneat=true;
		}
		if((t==1 && s.charAt(i) == "_")) {
			oneat2=true;
		}
		if((t==1 && s.charAt(i) == ".")) {
			onedot=true;
		}
		if((t==2 && s.charAt(i) == "@") ) {
			oneat3=true;
		}
    if (whitespace.indexOf(c) != -1) {
        return false;
     }
    if(s.charAt(i) == "@"){
        atcnttwo++
     }

		if(atcnttwo == 1) {
            if(s.charAt(i) == "."){
                atcntdotcnt++
            }
        }

		if(atcnttwo == 1 && atcntdotcnt >1 && t== sLength) {

		if(s.charAt(i) == ".")
			return false;
		}

		if(atcnttwo==1 && atcntdotcnt<1) {
			for (j=0;j<alphaNumericString.length;j++) {
				if(s.toLowerCase().charAt(i) == (alphaNumericString.charAt(j))){
					alpafterat =true;
				 }
			}
		}

		if(atcntdotcnt==1) {
			for (j=0;j<alphaNumericString.length;j++) {
					if(s.toLowerCase().charAt(i) == (alphaNumericString.charAt(j)) ){
						alpafterdot =true;
					 }
			}
		}

        if(s.charAt(i) == "@"){
            atcnt++
        }

        i++
        }

		if(s.charAt(at-2) == ".") {
			return false;
		}

		if(s.charAt(at2) == ".") {
			return false;
		}

		if(onedot == true) {
			return false;
		}

		if(onedot == true && oneat3==true) {
			return false;
		}

		if(oneat == true) {
			return false;
		}

		if(oneat2 == true && oneat3==true) {
			return false;
		}

		if(atcnttwo >1) {
			return false;
		}
		if (hasSpace(s.value)) {
				return false;
		}

		if(alpafterdot== false || alpafterat== false) {
			return false;
		}

		if(alpafterat== false ) {
			return false;
		}

        if(atcnt>1) {
            return false;
        }

        if(atcntdotcnt<1) {
            return false;
        }

	    	if(atcntdotcnt >=1 && checkEmailInput(s)){
        	return true;
        }

    i = 1;

    while ((i < sLength) && (s.charAt(i) != "@")) {
       i++
    }
    if (!checkEmailInput(s)) {
        return false;
        }

    if ((i >= sLength) || (s.charAt(i) != "@"))
       return false;
    else
       i += 2;
    while ((i < sLength) && (s.charAt(i) != ".")) {
       i++
    }
    if ((i >= sLength - 1) || (s.charAt(i) != "."))
       return false;
    else
       return true;

    return true;
}

function hasSpace (s)
{   
  var i;
  if (isEmpty(s)) return false;
  for (i = 0; i < s.length; i++) 
  {
    var c = s.charAt(i);
    if (whitespace.indexOf(c) == 0) 
    {
      return true;
    }
  }
  return false;
}

function isSameNumberRepeated(s) 
{
     
     var c = s.charAt(0);
     for (var i = 0; i < s.length; i++) {
         var d = s.charAt(i);
	  if (d != c) 
	    return false;
     }
     return true;
}

function checkTIN(tin1,tin2)
{
    var tinValue = tin1 + tin2;
    if (checkTIN.arguments.length == 1)
    {
       return false;
    }
    if (isEmpty(tinValue)) {
       return false;
    }
    if (isSameNumberRepeated(tinValue)) {
       return false;
    }
    if (isTIN(tinValue)) 
       return true;
    else
       return false;
}

function isTIN (s)
{
  return (isInteger(s) && s.length == digitsInTaxInformationNumber)
}
function righttrim ( s ){
  return s.replace( /\s+$/, "" );
}

function DOBHandleFocus()
{
  if(document.getElementById("txtMM").value == "MM")
  {
    document.getElementById("txtMM").value = "";
    if(document.getElementById("txtDD").value == "DD")
    {
      document.getElementById("txtDD").value = "";
    }
    if(document.getElementById("txtYYD").value == "YYYY")
    {
      document.getElementById("txtYYD").value = "";
    }
  }
  else
  {
    document.getElementById("txtMM").select();
  }
  document.getElementById("txtMM").focus();
}

function handleTabs(name)
{
  if (name == "txtSSN1") 
  {
    if ( ( !isInteger(document.getElementById("txtSSN1").value)))
    {
      alert(invalidSSN);
      document.getElementById("txtSSN1").focus();
    }
    else if ((isInteger(document.getElementById("txtSSN1").value)) &&(document.getElementById("txtSSN1").value.length == ssn1Length)) 
    {
      document.getElementById("txtSSN2").focus();
    }
  }
  if (name == "txtSSN2")
  {
    if ( ( !isInteger(document.getElementById("txtSSN2").value)))
    {
      alert(invalidSSN);
      document.getElementById("txtSSN2").focus();
    }
    else if ( ( isInteger(document.getElementById("txtSSN2").value) ) &&( document.getElementById("txtSSN2").value.length == ssn2Length  ) ) 
    {
      document.getElementById("txtSSN3").focus();
    }
  }
  if (name == "txtSSN3")
  {
    if ( ( !isInteger(document.getElementById("txtSSN3").value ) ) )
    {
      alert(invalidSSN);
      document.getElementById("txtSSN3").focus();
    }
    else if ( ( isInteger(document.getElementById("txtSSN3").value) ) &&( document.getElementById("txtSSN3").value.length == ssn3Length ) ) 
    {
      document.getElementById("txtSSN3").focus();
    }
  }
  if (name == "txtMM")
  {
    if ( ( !isInteger(document.getElementById("txtMM").value ) ) )
    {
      alert(invalidDate);
      document.getElementById("txtMM").focus();
    }
    
    if ( (isInteger(document.getElementById("txtMM").value)) && (document.getElementById("txtMM").value.length == mmLength))
    {
      document.getElementById("txtDD").focus()
    }
  }
  if (name == "txtDD")
  {
    if ( ( !isInteger(document.getElementById("txtDD").value ) ) )
    {
      alert(invalidDate);
      document.getElementById("txtDD").focus();
    }
    
    if ( ( isInteger(document.getElementById("txtDD").value) ) &&( document.getElementById("txtDD").value.length == ddLength ))
    {
      document.getElementById("txtYYD").focus()
    }
  }
  if (name == "txtYYD")
  {
    
    if ( ( !isInteger(document.getElementById("txtYYD").value ) ) )
    {
      alert(invalidDate);
      document.getElementById("txtYYD").focus();
    }
    
    if ( ( isInteger(document.getElementById("txtYYD").value) ) &&( document.getElementById("txtYYD").value.length == yydLength ))
    {
      document.getElementById("txtYYD").focus()
    }
  }
  if (name == "txtTIN1") 
  {
    if ( ( !isInteger(document.getElementById("txtTIN1").value)))
    {
      alert(invalidTIN);
      document.getElementById("txtTIN1").focus();
    }
    else if ((isInteger(document.getElementById("txtTIN1").value)) &&(document.getElementById("txtTIN1").value.length == tin1Length)) 
    {
      document.getElementById("txtTIN2").focus();
    }
  }
  if (name == "txtTIN2")
  {
    if ( ( !isInteger(document.getElementById("txtTIN2").value ) ) )
    {
      alert(invalidTIN);
      document.getElementById("txtTIN2").focus();
    }
    else if ( ( isInteger(document.getElementById("txtTIN2").value) ) &&( document.getElementById("txtTIN2").value.length == tin2Length ) ) 
    {
      document.getElementById("txtTIN2").focus();
    }
  }
  
  if (name == "txtDob1")
  {
    if ( ( !isInteger(document.getElementById("txtDob1").value ) ) )
    {
      alert(invalidDate);
      document.getElementById("txtDob1").focus();
    }
    
    if ( (isInteger(document.getElementById("txtDob1").value)) && (document.getElementById("txtDob1").value.length == mmLength))
    {
      document.getElementById("txtDob2").focus()
    }
  }
  if (name == "txtDob2")
  {
    if ( ( !isInteger(document.getElementById("txtDob2").value ) ) )
    {
      alert(invalidDate);
      document.getElementById("txtDob2").focus();
    }
    
    if ( ( isInteger(document.getElementById("txtDob2").value) ) &&( document.getElementById("txtDob2").value.length == ddLength ))
    {
      document.getElementById("txtDob3").focus()
    }
  }
  if (name == "txtDob3")
  {
    
    if ( ( !isInteger(document.getElementById("txtDob3").value ) ) )
    {
      alert(invalidDate);
      document.getElementById("txtDob3").focus();
    }
    
    if ( ( isInteger(document.getElementById("txtDob3").value) ) &&( document.getElementById("txtDob3").value.length == yydLength ))
    {
      document.getElementById("txtDob3").focus()
    }
  }
  
  if (name == "txtDayPhone1")
  {
    if ((handlePhone(document.getElementById("txtDayPhone1") ))&& (document.getElementById("txtDayPhone1").value.length == ph1Length))
    {
     document.getElementById("txtDayPhone2").focus()
    }
  }
  if (name == "txtDayPhone2")
  {
    if ((handlePhone(document.getElementById("txtDayPhone2") ))&& (document.getElementById("txtDayPhone2").value.length == ph2Length))
    {
      document.getElementById("txtDayPhone3").focus()
    }
  }
  if (name == "txtDayPhone3")
  {
    if ((handlePhone(document.getElementById("txtDayPhone3") ))&& (document.getElementById("txtDayPhone3").value.length == ph3Length))
    {
      document.getElementById("txtDayPhone3").focus()
    }
  }
  if (name == "txtUSAZipCode2")
  {
    if (document.getElementById("txtUSAZipCode1").value.length == usZipCode1Length)
    {
      document.getElementById("txtUSAZipCode2").focus()
    }
  }
}

function checkSSN(ssn1,ssn2,ssn3)
{
  var ssnValue = ssn1 + ssn2 + ssn3
  if (checkSSN.arguments.length == 1)
  {
    return false;
  }
  if (isEmpty(ssnValue)) 
  {
    return false;
  }
  else
  {
    if ((ssn1 == validSSN1) || (areValidSSN(ssn1)) || (areAllZeros(ssn1)) || (areAllZeros(ssn2)) || (areAllZeros(ssn3)) || (areAllOnes(ssnValue)) || (!isSSN(ssnValue)))
    {
      return false;
    } 
    else
    {
      return true;
    }
  }
}

function GotoTutorial(tutorialUrl,refreshUrl)
  {
    win=window.open(tutorialUrl);
    window.location.href=refreshUrl;
    return false;
  }
  
  
  
function openPopupWin(theURL,winName,features) 
{ 
  window.open(theURL,winName,features);
}

// TODO: not used?
function showHide(layerId)
{
  var maintabStdServ = document.getElementById('stdServiceTab');
  var maintabPremServ = document.getElementById('premServiceTab');

  var tabStdServ = document.getElementById('stdServiceTab1');
  var lstStdCheckControls= tabStdServ.getElementsByTagName("input");

  var tabPremServ = document.getElementById('premServiceTab1');
  var lstPremCheckControls= tabPremServ.getElementsByTagName("input");

  if (layerId == 'premiumLayer')
  {
    tabStdServ.className='stdServiceOverlay';
    tabPremServ.className='premService';
    maintabStdServ.style.border='1px solid #FFF';
    maintabPremServ.style.border='2px solid #DEC872';

    for (i=0; i<lstStdCheckControls.length; i++)
    {
      lstStdCheckControls[i].disabled=false;
      lstStdCheckControls[i].checked=false;
    }

    for (j=0; j<lstPremCheckControls.length; j++)
    {
      lstPremCheckControls[j].disabled=false;
    }

    document.getElementById('NextButton').disabled=false;
  }
  else if (layerId == 'standardLayer')
  {
    tabPremServ.className='premServiceOverlay';
    tabStdServ.className='stdService';
    maintabStdServ.style.border='2px solid #DEC872';
    maintabPremServ.style.border='1px solid #FFF';

    for (i=0; i<lstStdCheckControls.length; i++)
    {
      lstStdCheckControls[i].disabled=false;
    }

    for (j=0; j<lstPremCheckControls.length; j++)
    {
      lstPremCheckControls[j].disabled=true;
      lstPremCheckControls[j].checked=false;
    }

    document.getElementById('NextButton').disabled=false;
  }
}

// TODO: not used?
function DisableCheckBoxes()
{
  var tabStdServ = document.getElementById('stdServiceTab1');
  var lstStdCheckControls= tabStdServ.getElementsByTagName("input");

  var tabPremServ = document.getElementById('premServiceTab1');
  var lstPremCheckControls= tabPremServ.getElementsByTagName("input");

  for (i=0; i<lstStdCheckControls.length; i++)
  {
    lstStdCheckControls[i].disabled=true;
  }

  for (j=0; j<lstPremCheckControls.length; j++)
  {
    lstPremCheckControls[j].disabled=true;
  }
  document.getElementById('NextButton').disabled=true;
}

function SelectCountry(Obj)
{
  SetCountryTrs(Obj.value);
}
function SetCountryTrs(valCountry)
{
  if(valCountry=='US')
	{ 
	  document.getElementById('trUSAStates').style.display="";
		document.getElementById('trCanadaStates').style.display="none";
		
		document.getElementById('trUSAZip').style.display="";
		document.getElementById('trOthersZip').style.display="none";
		
		document.getElementById('trUSPhone').style.display="";
		document.getElementById('trOthersPhone').style.display="none";
	}
	else if(valCountry=='CA')
	{
		document.getElementById('trUSAStates').style.display="none";
		document.getElementById('trCanadaStates').style.display="";	
		
		document.getElementById('trUSAZip').style.display="none";
		document.getElementById('trOthersZip').style.display="";
		
		document.getElementById('trUSPhone').style.display="none";
		document.getElementById('trOthersPhone').style.display="";
	}	
	else
	{
		document.getElementById('trUSAStates').style.display="none";
		document.getElementById('trCanadaStates').style.display="none";
		
		document.getElementById('trUSAZip').style.display="none";
		document.getElementById('trOthersZip').style.display="";
		
		document.getElementById('trUSPhone').style.display="none";
		document.getElementById('trOthersPhone').style.display="none";
  }
}
function isAlphanumericCheck(valUserID) {
  var i;
  for (i = 0; i < valUserID.length; i++) {
    var c = valUserID.charAt(i);
    if (!(isLetter(c) || isDigit(c)))
      return false;
  }
  return true;
}

function isAnyDigitCheck(valUserID) {
  var i;
  for (i = 0; i < valUserID.length; i++) {
    var c = valUserID.charAt(i);
    if (isDigit(c)) {
      return true;
    }
  }
  return false;
}

function isAnyCharacterCheck(valUserID) {
  var i;
  for (i = 0; i < valUserID.length; i++) {
    var c = valUserID.charAt(i);
    if (isLetter(c))
      return true;
  }
  return false;
}