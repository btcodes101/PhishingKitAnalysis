var requirejs, require, define;

!function(global) {
    function isFunction(it) {
        return "[object Function]" === ostring.call(it);
    }
    function isArray(it) {
        return "[object Array]" === ostring.call(it);
    }
    function each(ary, func) {
        if (ary) {
            var i;
            for (i = 0; i < ary.length && (!ary[i] || !func(ary[i], i, ary)); i += 1) ;
        }
    }
    function eachReverse(ary, func) {
        if (ary) {
            var i;
            for (i = ary.length - 1; i > -1 && (!ary[i] || !func(ary[i], i, ary)); i -= 1) ;
        }
    }
    function hasProp(obj, prop) {
        return hasOwn.call(obj, prop);
    }
    function getOwn(obj, prop) {
        return hasProp(obj, prop) && obj[prop];
    }
    function eachProp(obj, func) {
        var prop;
        for (prop in obj) if (hasProp(obj, prop) && func(obj[prop], prop)) break;
    }
    function mixin(target, source, force, deepStringMixin) {
        return source && eachProp(source, function(value, prop) {
            (force || !hasProp(target, prop)) && (deepStringMixin && "string" != typeof value ? (target[prop] || (target[prop] = {}), 
            mixin(target[prop], value, force, deepStringMixin)) : target[prop] = value);
        }), target;
    }
    function bind(obj, fn) {
        return function() {
            return fn.apply(obj, arguments);
        };
    }
    function scripts() {
        return document.getElementsByTagName("script");
    }
    function defaultOnError(err) {
        throw err;
    }
    function getGlobal(value) {
        if (!value) return value;
        var g = global;
        return each(value.split("."), function(part) {
            g = g[part];
        }), g;
    }
    function makeError(id, msg, err, requireModules) {
        var e = new Error(msg + "\nhttp://requirejs.org/docs/errors.html#" + id);
        return e.requireType = id, e.requireModules = requireModules, err && (e.originalError = err), 
        e;
    }
    function newContext(contextName) {
        function trimDots(ary) {
            var i, part;
            for (i = 0; ary[i]; i += 1) if (part = ary[i], "." === part) ary.splice(i, 1), i -= 1; else if (".." === part) {
                if (1 === i && (".." === ary[2] || ".." === ary[0])) break;
                i > 0 && (ary.splice(i - 1, 2), i -= 2);
            }
        }
        function normalize(name, baseName, applyMap) {
            var pkgName, pkgConfig, mapValue, nameParts, i, j, nameSegment, foundMap, foundI, foundStarMap, starI, baseParts = baseName && baseName.split("/"), normalizedBaseParts = baseParts, map = config.map, starMap = map && map["*"];
            if (name && "." === name.charAt(0) && (baseName ? (normalizedBaseParts = getOwn(config.pkgs, baseName) ? baseParts = [ baseName ] : baseParts.slice(0, baseParts.length - 1), 
            name = normalizedBaseParts.concat(name.split("/")), trimDots(name), pkgConfig = getOwn(config.pkgs, pkgName = name[0]), 
            name = name.join("/"), pkgConfig && name === pkgName + "/" + pkgConfig.main && (name = pkgName)) : 0 === name.indexOf("./") && (name = name.substring(2))), 
            applyMap && map && (baseParts || starMap)) {
                for (nameParts = name.split("/"), i = nameParts.length; i > 0; i -= 1) {
                    if (nameSegment = nameParts.slice(0, i).join("/"), baseParts) for (j = baseParts.length; j > 0; j -= 1) if (mapValue = getOwn(map, baseParts.slice(0, j).join("/")), 
                    mapValue && (mapValue = getOwn(mapValue, nameSegment))) {
                        foundMap = mapValue, foundI = i;
                        break;
                    }
                    if (foundMap) break;
                    !foundStarMap && starMap && getOwn(starMap, nameSegment) && (foundStarMap = getOwn(starMap, nameSegment), 
                    starI = i);
                }
                !foundMap && foundStarMap && (foundMap = foundStarMap, foundI = starI), foundMap && (nameParts.splice(0, foundI, foundMap), 
                name = nameParts.join("/"));
            }
            return name;
        }
        function removeScript(name) {
            isBrowser && each(scripts(), function(scriptNode) {
                return scriptNode.getAttribute("data-requiremodule") === name && scriptNode.getAttribute("data-requirecontext") === context.contextName ? (scriptNode.parentNode.removeChild(scriptNode), 
                !0) : void 0;
            });
        }
        function hasPathFallback(id) {
            var pathConfig = getOwn(config.paths, id);
            return pathConfig && isArray(pathConfig) && pathConfig.length > 1 ? (removeScript(id), 
            pathConfig.shift(), context.require.undef(id), context.require([ id ]), !0) : void 0;
        }
        function splitPrefix(name) {
            var prefix, index = name ? name.indexOf("!") : -1;
            return index > -1 && (prefix = name.substring(0, index), name = name.substring(index + 1, name.length)), 
            [ prefix, name ];
        }
        function makeModuleMap(name, parentModuleMap, isNormalized, applyMap) {
            var url, pluginModule, suffix, nameParts, prefix = null, parentName = parentModuleMap ? parentModuleMap.name : null, originalName = name, isDefine = !0, normalizedName = "";
            return name || (isDefine = !1, name = "_@r" + (requireCounter += 1)), nameParts = splitPrefix(name), 
            prefix = nameParts[0], name = nameParts[1], prefix && (prefix = normalize(prefix, parentName, applyMap), 
            pluginModule = getOwn(defined, prefix)), name && (prefix ? normalizedName = pluginModule && pluginModule.normalize ? pluginModule.normalize(name, function(name) {
                return normalize(name, parentName, applyMap);
            }) : normalize(name, parentName, applyMap) : (normalizedName = normalize(name, parentName, applyMap), 
            nameParts = splitPrefix(normalizedName), prefix = nameParts[0], normalizedName = nameParts[1], 
            isNormalized = !0, url = context.nameToUrl(normalizedName))), suffix = !prefix || pluginModule || isNormalized ? "" : "_unnormalized" + (unnormalizedCounter += 1), 
            {
                prefix: prefix,
                name: normalizedName,
                parentMap: parentModuleMap,
                unnormalized: !!suffix,
                url: url,
                originalName: originalName,
                isDefine: isDefine,
                id: (prefix ? prefix + "!" + normalizedName : normalizedName) + suffix
            };
        }
        function getModule(depMap) {
            var id = depMap.id, mod = getOwn(registry, id);
            return mod || (mod = registry[id] = new context.Module(depMap)), mod;
        }
        function on(depMap, name, fn) {
            var id = depMap.id, mod = getOwn(registry, id);
            !hasProp(defined, id) || mod && !mod.defineEmitComplete ? (mod = getModule(depMap), 
            mod.error && "error" === name ? fn(mod.error) : mod.on(name, fn)) : "defined" === name && fn(defined[id]);
        }
        function onError(err, errback) {
            var ids = err.requireModules, notified = !1;
            errback ? errback(err) : (each(ids, function(id) {
                var mod = getOwn(registry, id);
                mod && (mod.error = err, mod.events.error && (notified = !0, mod.emit("error", err)));
            }), notified || req.onError(err));
        }
        function takeGlobalQueue() {
            globalDefQueue.length && (apsp.apply(defQueue, [ defQueue.length - 1, 0 ].concat(globalDefQueue)), 
            globalDefQueue = []);
        }
        function cleanRegistry(id) {
            delete registry[id], delete enabledRegistry[id];
        }
        function breakCycle(mod, traced, processed) {
            var id = mod.map.id;
            mod.error ? mod.emit("error", mod.error) : (traced[id] = !0, each(mod.depMaps, function(depMap, i) {
                var depId = depMap.id, dep = getOwn(registry, depId);
                !dep || mod.depMatched[i] || processed[depId] || (getOwn(traced, depId) ? (mod.defineDep(i, defined[depId]), 
                mod.check()) : breakCycle(dep, traced, processed));
            }), processed[id] = !0);
        }
        function checkLoaded() {
            var map, modId, err, usingPathFallback, waitInterval = 1e3 * config.waitSeconds, expired = waitInterval && context.startTime + waitInterval < new Date().getTime(), noLoads = [], reqCalls = [], stillLoading = !1, needCycleCheck = !0;
            if (!inCheckLoaded) {
                if (inCheckLoaded = !0, eachProp(enabledRegistry, function(mod) {
                    if (map = mod.map, modId = map.id, mod.enabled && (map.isDefine || reqCalls.push(mod), 
                    !mod.error)) if (!mod.inited && expired) hasPathFallback(modId) ? (usingPathFallback = !0, 
                    stillLoading = !0) : (noLoads.push(modId), removeScript(modId)); else if (!mod.inited && mod.fetched && map.isDefine && (stillLoading = !0, 
                    !map.prefix)) return needCycleCheck = !1;
                }), expired && noLoads.length) return err = makeError("timeout", "Load timeout for modules: " + noLoads, null, noLoads), 
                err.contextName = context.contextName, onError(err);
                needCycleCheck && each(reqCalls, function(mod) {
                    breakCycle(mod, {}, {});
                }), expired && !usingPathFallback || !stillLoading || !isBrowser && !isWebWorker || checkLoadedTimeoutId || (checkLoadedTimeoutId = setTimeout(function() {
                    checkLoadedTimeoutId = 0, checkLoaded();
                }, 50)), inCheckLoaded = !1;
            }
        }
        function callGetModule(args) {
            hasProp(defined, args[0]) || getModule(makeModuleMap(args[0], null, !0)).init(args[1], args[2]);
        }
        function removeListener(node, func, name, ieName) {
            node.detachEvent && !isOpera ? ieName && node.detachEvent(ieName, func) : node.removeEventListener(name, func, !1);
        }
        function getScriptData(evt) {
            var node = evt.currentTarget || evt.srcElement;
            return removeListener(node, context.onScriptLoad, "load", "onreadystatechange"), 
            removeListener(node, context.onScriptError, "error"), {
                node: node,
                id: node && node.getAttribute("data-requiremodule")
            };
        }
        function intakeDefines() {
            var args;
            for (takeGlobalQueue(); defQueue.length; ) {
                if (args = defQueue.shift(), null === args[0]) return onError(makeError("mismatch", "Mismatched anonymous define() module: " + args[args.length - 1]));
                callGetModule(args);
            }
        }
        var inCheckLoaded, Module, context, handlers, checkLoadedTimeoutId, config = {
            waitSeconds: 7,
            baseUrl: "./",
            paths: {},
            pkgs: {},
            shim: {},
            config: {}
        }, registry = {}, enabledRegistry = {}, undefEvents = {}, defQueue = [], defined = {}, urlFetched = {}, requireCounter = 1, unnormalizedCounter = 1;
        return handlers = {
            require: function(mod) {
                return mod.require ? mod.require : mod.require = context.makeRequire(mod.map);
            },
            exports: function(mod) {
                return mod.usingExports = !0, mod.map.isDefine ? mod.exports ? mod.exports : mod.exports = defined[mod.map.id] = {} : void 0;
            },
            module: function(mod) {
                return mod.module ? mod.module : mod.module = {
                    id: mod.map.id,
                    uri: mod.map.url,
                    config: function() {
                        var c, pkg = getOwn(config.pkgs, mod.map.id);
                        return c = pkg ? getOwn(config.config, mod.map.id + "/" + pkg.main) : getOwn(config.config, mod.map.id), 
                        c || {};
                    },
                    exports: defined[mod.map.id]
                };
            }
        }, Module = function(map) {
            this.events = getOwn(undefEvents, map.id) || {}, this.map = map, this.shim = getOwn(config.shim, map.id), 
            this.depExports = [], this.depMaps = [], this.depMatched = [], this.pluginMaps = {}, 
            this.depCount = 0;
        }, Module.prototype = {
            init: function(depMaps, factory, errback, options) {
                options = options || {}, this.inited || (this.factory = factory, errback ? this.on("error", errback) : this.events.error && (errback = bind(this, function(err) {
                    this.emit("error", err);
                })), this.depMaps = depMaps && depMaps.slice(0), this.errback = errback, this.inited = !0, 
                this.ignore = options.ignore, options.enabled || this.enabled ? this.enable() : this.check());
            },
            defineDep: function(i, depExports) {
                this.depMatched[i] || (this.depMatched[i] = !0, this.depCount -= 1, this.depExports[i] = depExports);
            },
            fetch: function() {
                if (!this.fetched) {
                    this.fetched = !0, context.startTime = new Date().getTime();
                    var map = this.map;
                    return this.shim ? void context.makeRequire(this.map, {
                        enableBuildCallback: !0
                    })(this.shim.deps || [], bind(this, function() {
                        return map.prefix ? this.callPlugin() : this.load();
                    })) : map.prefix ? this.callPlugin() : this.load();
                }
            },
            load: function() {
                var url = this.map.url;
                urlFetched[url] || (urlFetched[url] = !0, context.load(this.map.id, url));
            },
            check: function() {
                if (this.enabled && !this.enabling) {
                    var err, cjsModule, id = this.map.id, depExports = this.depExports, exports = this.exports, factory = this.factory;
                    if (this.inited) {
                        if (this.error) this.emit("error", this.error); else if (!this.defining) {
                            if (this.defining = !0, this.depCount < 1 && !this.defined) {
                                if (isFunction(factory)) {
                                    if (this.events.error && this.map.isDefine || req.onError !== defaultOnError) try {
                                        exports = context.execCb(id, factory, depExports, exports);
                                    } catch (e) {
                                        err = e;
                                    } else exports = context.execCb(id, factory, depExports, exports);
                                    if (this.map.isDefine && (cjsModule = this.module, cjsModule && void 0 !== cjsModule.exports && cjsModule.exports !== this.exports ? exports = cjsModule.exports : void 0 === exports && this.usingExports && (exports = this.exports)), 
                                    err) return err.requireMap = this.map, err.requireModules = this.map.isDefine ? [ this.map.id ] : null, 
                                    err.requireType = this.map.isDefine ? "define" : "require", onError(this.error = err);
                                } else exports = factory;
                                this.exports = exports, this.map.isDefine && !this.ignore && (defined[id] = exports, 
                                req.onResourceLoad && req.onResourceLoad(context, this.map, this.depMaps)), cleanRegistry(id), 
                                this.defined = !0;
                            }
                            this.defining = !1, this.defined && !this.defineEmitted && (this.defineEmitted = !0, 
                            this.emit("defined", this.exports), this.defineEmitComplete = !0);
                        }
                    } else this.fetch();
                }
            },
            callPlugin: function() {
                var map = this.map, id = map.id, pluginMap = makeModuleMap(map.prefix);
                this.depMaps.push(pluginMap), on(pluginMap, "defined", bind(this, function(plugin) {
                    var load, normalizedMap, normalizedMod, name = this.map.name, parentName = this.map.parentMap ? this.map.parentMap.name : null, localRequire = context.makeRequire(map.parentMap, {
                        enableBuildCallback: !0
                    });
                    return this.map.unnormalized ? (plugin.normalize && (name = plugin.normalize(name, function(name) {
                        return normalize(name, parentName, !0);
                    }) || ""), normalizedMap = makeModuleMap(map.prefix + "!" + name, this.map.parentMap), 
                    on(normalizedMap, "defined", bind(this, function(value) {
                        this.init([], function() {
                            return value;
                        }, null, {
                            enabled: !0,
                            ignore: !0
                        });
                    })), normalizedMod = getOwn(registry, normalizedMap.id), void (normalizedMod && (this.depMaps.push(normalizedMap), 
                    this.events.error && normalizedMod.on("error", bind(this, function(err) {
                        this.emit("error", err);
                    })), normalizedMod.enable()))) : (load = bind(this, function(value) {
                        this.init([], function() {
                            return value;
                        }, null, {
                            enabled: !0
                        });
                    }), load.error = bind(this, function(err) {
                        this.inited = !0, this.error = err, err.requireModules = [ id ], eachProp(registry, function(mod) {
                            0 === mod.map.id.indexOf(id + "_unnormalized") && cleanRegistry(mod.map.id);
                        }), onError(err);
                    }), load.fromText = bind(this, function(text, textAlt) {
                        var moduleName = map.name, moduleMap = makeModuleMap(moduleName), hasInteractive = useInteractive;
                        textAlt && (text = textAlt), hasInteractive && (useInteractive = !1), getModule(moduleMap), 
                        hasProp(config.config, id) && (config.config[moduleName] = config.config[id]);
                        try {
                            req.exec(text);
                        } catch (e) {
                            return onError(makeError("fromtexteval", "fromText eval for " + id + " failed: " + e, e, [ id ]));
                        }
                        hasInteractive && (useInteractive = !0), this.depMaps.push(moduleMap), context.completeLoad(moduleName), 
                        localRequire([ moduleName ], load);
                    }), void plugin.load(map.name, localRequire, load, config));
                })), context.enable(pluginMap, this), this.pluginMaps[pluginMap.id] = pluginMap;
            },
            enable: function() {
                enabledRegistry[this.map.id] = this, this.enabled = !0, this.enabling = !0, each(this.depMaps, bind(this, function(depMap, i) {
                    var id, mod, handler;
                    if ("string" == typeof depMap) {
                        if (depMap = makeModuleMap(depMap, this.map.isDefine ? this.map : this.map.parentMap, !1, !this.skipMap), 
                        this.depMaps[i] = depMap, handler = getOwn(handlers, depMap.id)) return void (this.depExports[i] = handler(this));
                        this.depCount += 1, on(depMap, "defined", bind(this, function(depExports) {
                            this.defineDep(i, depExports), this.check();
                        })), this.errback && on(depMap, "error", bind(this, this.errback));
                    }
                    id = depMap.id, mod = registry[id], hasProp(handlers, id) || !mod || mod.enabled || context.enable(depMap, this);
                })), eachProp(this.pluginMaps, bind(this, function(pluginMap) {
                    var mod = getOwn(registry, pluginMap.id);
                    mod && !mod.enabled && context.enable(pluginMap, this);
                })), this.enabling = !1, this.check();
            },
            on: function(name, cb) {
                var cbs = this.events[name];
                cbs || (cbs = this.events[name] = []), cbs.push(cb);
            },
            emit: function(name, evt) {
                each(this.events[name], function(cb) {
                    cb(evt);
                }), "error" === name && delete this.events[name];
            }
        }, context = {
            config: config,
            contextName: contextName,
            registry: registry,
            defined: defined,
            urlFetched: urlFetched,
            defQueue: defQueue,
            Module: Module,
            makeModuleMap: makeModuleMap,
            nextTick: req.nextTick,
            onError: onError,
            configure: function(cfg) {
                cfg.baseUrl && "/" !== cfg.baseUrl.charAt(cfg.baseUrl.length - 1) && (cfg.baseUrl += "/");
                var pkgs = config.pkgs, shim = config.shim, objs = {
                    paths: !0,
                    config: !0,
                    map: !0
                };
                eachProp(cfg, function(value, prop) {
                    objs[prop] ? "map" === prop ? (config.map || (config.map = {}), mixin(config[prop], value, !0, !0)) : mixin(config[prop], value, !0) : config[prop] = value;
                }), cfg.shim && (eachProp(cfg.shim, function(value, id) {
                    isArray(value) && (value = {
                        deps: value
                    }), !value.exports && !value.init || value.exportsFn || (value.exportsFn = context.makeShimExports(value)), 
                    shim[id] = value;
                }), config.shim = shim), cfg.packages && (each(cfg.packages, function(pkgObj) {
                    var location;
                    pkgObj = "string" == typeof pkgObj ? {
                        name: pkgObj
                    } : pkgObj, location = pkgObj.location, pkgs[pkgObj.name] = {
                        name: pkgObj.name,
                        location: location || pkgObj.name,
                        main: (pkgObj.main || "main").replace(currDirRegExp, "").replace(jsSuffixRegExp, "")
                    };
                }), config.pkgs = pkgs), eachProp(registry, function(mod, id) {
                    mod.inited || mod.map.unnormalized || (mod.map = makeModuleMap(id));
                }), (cfg.deps || cfg.callback) && context.require(cfg.deps || [], cfg.callback);
            },
            makeShimExports: function(value) {
                function fn() {
                    var ret;
                    return value.init && (ret = value.init.apply(global, arguments)), ret || value.exports && getGlobal(value.exports);
                }
                return fn;
            },
            makeRequire: function(relMap, options) {
                function localRequire(deps, callback, errback) {
                    var id, map, requireMod;
                    return options.enableBuildCallback && callback && isFunction(callback) && (callback.__requireJsBuild = !0), 
                    "string" == typeof deps ? isFunction(callback) ? onError(makeError("requireargs", "Invalid require call"), errback) : relMap && hasProp(handlers, deps) ? handlers[deps](registry[relMap.id]) : req.get ? req.get(context, deps, relMap, localRequire) : (map = makeModuleMap(deps, relMap, !1, !0), 
                    id = map.id, hasProp(defined, id) ? defined[id] : onError(makeError("notloaded", 'Module name "' + id + '" has not been loaded yet for context: ' + contextName + (relMap ? "" : ". Use require([])")))) : (intakeDefines(), 
                    context.nextTick(function() {
                        intakeDefines(), requireMod = getModule(makeModuleMap(null, relMap)), requireMod.skipMap = options.skipMap, 
                        requireMod.init(deps, callback, errback, {
                            enabled: !0
                        }), checkLoaded();
                    }), localRequire);
                }
                return options = options || {}, mixin(localRequire, {
                    isBrowser: isBrowser,
                    toUrl: function(moduleNamePlusExt) {
                        var ext, index = moduleNamePlusExt.lastIndexOf("."), segment = moduleNamePlusExt.split("/")[0], isRelative = "." === segment || ".." === segment;
                        return -1 !== index && (!isRelative || index > 1) && (ext = moduleNamePlusExt.substring(index, moduleNamePlusExt.length), 
                        moduleNamePlusExt = moduleNamePlusExt.substring(0, index)), context.nameToUrl(normalize(moduleNamePlusExt, relMap && relMap.id, !0), ext, !0);
                    },
                    defined: function(id) {
                        return hasProp(defined, makeModuleMap(id, relMap, !1, !0).id);
                    },
                    specified: function(id) {
                        return id = makeModuleMap(id, relMap, !1, !0).id, hasProp(defined, id) || hasProp(registry, id);
                    }
                }), relMap || (localRequire.undef = function(id) {
                    takeGlobalQueue();
                    var map = makeModuleMap(id, relMap, !0), mod = getOwn(registry, id);
                    delete defined[id], delete urlFetched[map.url], delete undefEvents[id], mod && (mod.events.defined && (undefEvents[id] = mod.events), 
                    cleanRegistry(id));
                }), localRequire;
            },
            enable: function(depMap) {
                var mod = getOwn(registry, depMap.id);
                mod && getModule(depMap).enable();
            },
            completeLoad: function(moduleName) {
                var found, args, mod, shim = getOwn(config.shim, moduleName) || {}, shExports = shim.exports;
                for (takeGlobalQueue(); defQueue.length; ) {
                    if (args = defQueue.shift(), null === args[0]) {
                        if (args[0] = moduleName, found) break;
                        found = !0;
                    } else args[0] === moduleName && (found = !0);
                    callGetModule(args);
                }
                if (mod = getOwn(registry, moduleName), !found && !hasProp(defined, moduleName) && mod && !mod.inited) {
                    if (!(!config.enforceDefine || shExports && getGlobal(shExports))) return hasPathFallback(moduleName) ? void 0 : onError(makeError("nodefine", "No define call for " + moduleName, null, [ moduleName ]));
                    callGetModule([ moduleName, shim.deps || [], shim.exportsFn ]);
                }
                checkLoaded();
            },
            nameToUrl: function(moduleName, ext, skipExt) {
                var paths, pkgs, pkg, pkgPath, syms, i, parentModule, url, parentPath;
                if (req.jsExtRegExp.test(moduleName)) url = moduleName + (ext || ""); else {
                    for (paths = config.paths, pkgs = config.pkgs, syms = moduleName.split("/"), i = syms.length; i > 0; i -= 1) {
                        if (parentModule = syms.slice(0, i).join("/"), pkg = getOwn(pkgs, parentModule), 
                        parentPath = getOwn(paths, parentModule)) {
                            isArray(parentPath) && (parentPath = parentPath[0]), syms.splice(0, i, parentPath);
                            break;
                        }
                        if (pkg) {
                            pkgPath = moduleName === pkg.name ? pkg.location + "/" + pkg.main : pkg.location, 
                            syms.splice(0, i, pkgPath);
                            break;
                        }
                    }
                    url = syms.join("/"), url += ext || (/\?/.test(url) || skipExt ? "" : ".js"), url = ("/" === url.charAt(0) || url.match(/^[\w\+\.\-]+:/) ? "" : config.baseUrl) + url;
                }
                return config.urlArgs ? url + ((-1 === url.indexOf("?") ? "?" : "&") + config.urlArgs) : url;
            },
            load: function(id, url) {
                req.load(context, id, url);
            },
            execCb: function(name, callback, args, exports) {
                return callback.apply(exports, args);
            },
            onScriptLoad: function(evt) {
                if ("load" === evt.type || readyRegExp.test((evt.currentTarget || evt.srcElement).readyState)) {
                    interactiveScript = null;
                    var data = getScriptData(evt);
                    context.completeLoad(data.id);
                }
            },
            onScriptError: function(evt) {
                var data = getScriptData(evt);
                return hasPathFallback(data.id) ? void 0 : onError(makeError("scripterror", "Script error for: " + data.id, evt, [ data.id ]));
            }
        }, context.require = context.makeRequire(), context;
    }
    function getInteractiveScript() {
        return interactiveScript && "interactive" === interactiveScript.readyState ? interactiveScript : (eachReverse(scripts(), function(script) {
            return "interactive" === script.readyState ? interactiveScript = script : void 0;
        }), interactiveScript);
    }
    var req, s, head, baseElement, dataMain, src, interactiveScript, currentlyAddingScript, mainScript, subPath, version = "2.1.6", commentRegExp = /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/gm, cjsRequireRegExp = /[^.]\s*require\s*\(\s*["']([^'"\s]+)["']\s*\)/g, jsSuffixRegExp = /\.js$/, currDirRegExp = /^\.\//, op = Object.prototype, ostring = op.toString, hasOwn = op.hasOwnProperty, ap = Array.prototype, apsp = ap.splice, isBrowser = !("undefined" == typeof window || !navigator || !window.document), isWebWorker = !isBrowser && "undefined" != typeof importScripts, readyRegExp = isBrowser && "PLAYSTATION 3" === navigator.platform ? /^complete$/ : /^(complete|loaded)$/, defContextName = "_", isOpera = "undefined" != typeof opera && "[object Opera]" === opera.toString(), contexts = {}, cfg = {}, globalDefQueue = [], useInteractive = !1;
    if ("undefined" == typeof define) {
        if ("undefined" != typeof requirejs) {
            if (isFunction(requirejs)) return;
            cfg = requirejs, requirejs = void 0;
        }
        "undefined" == typeof require || isFunction(require) || (cfg = require, require = void 0), 
        req = requirejs = function(deps, callback, errback, optional) {
            var context, config, contextName = defContextName;
            return isArray(deps) || "string" == typeof deps || (config = deps, isArray(callback) ? (deps = callback, 
            callback = errback, errback = optional) : deps = []), config && config.context && (contextName = config.context), 
            context = getOwn(contexts, contextName), context || (context = contexts[contextName] = req.s.newContext(contextName)), 
            config && context.configure(config), context.require(deps, callback, errback);
        }, req.config = function(config) {
            return req(config);
        }, req.nextTick = "undefined" != typeof setTimeout ? function(fn) {
            setTimeout(fn, 4);
        } : function(fn) {
            fn();
        }, require || (require = req), req.version = version, req.jsExtRegExp = /^\/|:|\?|\.js$/, 
        req.isBrowser = isBrowser, s = req.s = {
            contexts: contexts,
            newContext: newContext
        }, req({}), each([ "toUrl", "undef", "defined", "specified" ], function(prop) {
            req[prop] = function() {
                var ctx = contexts[defContextName];
                return ctx.require[prop].apply(ctx, arguments);
            };
        }), isBrowser && (head = s.head = document.getElementsByTagName("head")[0], baseElement = document.getElementsByTagName("base")[0], 
        baseElement && (head = s.head = baseElement.parentNode)), req.onError = defaultOnError, 
        req.load = function(context, moduleName, url) {
            var node, config = context && context.config || {};
            if (isBrowser) return node = config.xhtml ? document.createElementNS("http://www.w3.org/1999/xhtml", "html:script") : document.createElement("script"), 
            node.type = config.scriptType || "text/javascript", node.charset = "utf-8", node.async = !0, 
            node.setAttribute("data-requirecontext", context.contextName), node.setAttribute("data-requiremodule", moduleName), 
            !node.attachEvent || node.attachEvent.toString && node.attachEvent.toString().indexOf("[native code") < 0 || isOpera ? (node.addEventListener("load", context.onScriptLoad, !1), 
            node.addEventListener("error", context.onScriptError, !1)) : (useInteractive = !0, 
            node.attachEvent("onreadystatechange", context.onScriptLoad)), node.src = url, currentlyAddingScript = node, 
            baseElement ? head.insertBefore(node, baseElement) : head.appendChild(node), currentlyAddingScript = null, 
            node;
            if (isWebWorker) try {
                importScripts(url), context.completeLoad(moduleName);
            } catch (e) {
                context.onError(makeError("importscripts", "importScripts failed for " + moduleName + " at " + url, e, [ moduleName ]));
            }
        }, isBrowser && eachReverse(scripts(), function(script) {
            return head || (head = script.parentNode), dataMain = script.getAttribute("data-main"), 
            dataMain ? (mainScript = dataMain, cfg.baseUrl || (src = mainScript.split("/"), 
            mainScript = src.pop(), subPath = src.length ? src.join("/") + "/" : "./", cfg.baseUrl = subPath), 
            mainScript = mainScript.replace(jsSuffixRegExp, ""), req.jsExtRegExp.test(mainScript) && (mainScript = dataMain), 
            cfg.deps = cfg.deps ? cfg.deps.concat(mainScript) : [ mainScript ], !0) : void 0;
        }), define = function(name, deps, callback) {
            var node, context;
            "string" != typeof name && (callback = deps, deps = name, name = null), isArray(deps) || (callback = deps, 
            deps = null), !deps && isFunction(callback) && (deps = [], callback.length && (callback.toString().replace(commentRegExp, "").replace(cjsRequireRegExp, function(match, dep) {
                deps.push(dep);
            }), deps = (1 === callback.length ? [ "require" ] : [ "require", "exports", "module" ]).concat(deps))), 
            useInteractive && (node = currentlyAddingScript || getInteractiveScript(), node && (name || (name = node.getAttribute("data-requiremodule")), 
            context = contexts[node.getAttribute("data-requirecontext")])), (context ? context.defQueue : globalDefQueue).push([ name, deps, callback ]);
        }, define.amd = {
            jQuery: !0
        }, req.exec = function(text) {
            return eval(text);
        }, req(cfg);
    }
}(this), define("requirejs", function() {}), define("mout/lang/kindOf", [], function() {
    function kindOf(val) {
        return null === val ? "Null" : val === UNDEF ? "Undefined" : _rKind.exec(_toString.call(val))[1];
    }
    var UNDEF, _rKind = /^\[object (.*)\]$/, _toString = Object.prototype.toString;
    return kindOf;
}), define("mout/lang/isKind", [ "./kindOf" ], function(kindOf) {
    function isKind(val, kind) {
        return kindOf(val) === kind;
    }
    return isKind;
}), define("mout/lang/isFunction", [ "./isKind" ], function(isKind) {
    function isFunction(val) {
        return isKind(val, "Function");
    }
    return isFunction;
}), define("jpmc/util/lang/isFunction", [ "mout/lang/isFunction" ], function(moutIsFunction) {
    var isFunction;
    return isFunction = moutIsFunction;
}), define("mout/lang/isString", [ "./isKind" ], function(isKind) {
    function isString(val) {
        return isKind(val, "String");
    }
    return isString;
}), define("jpmc/util/lang/isString", [ "mout/lang/isString" ], function(isString) {
    return isString;
}), define("jpmc/has/cache", [ "jpmc/util/lang/isFunction", "jpmc/util/lang/isString" ], function(isFunction, isString, undefined) {
    function Has(global, document, element) {
        global = global || window, document = document || global.document, element = element || document.createElement("has"), 
        defineProperty(this, "global", {
            value: global
        }), defineProperty(this, "document", {
            value: document
        }), defineProperty(this, "element", {
            value: element
        });
    }
    var slice = Array.prototype.slice, hasDefineProperty = function(object) {
        if ("defineProperty" in Object) try {
            return Object.defineProperty(object, "test", {
                configurable: !0,
                writable: !0,
                value: 1
            }), "test" in object;
        } catch (e) {}
    }, defineProperty = hasDefineProperty({}) ? Object.defineProperty : function(object, name, descriptor) {
        return object[name] = descriptor && descriptor.value, object;
    };
    return Has.prototype = {
        add: function(name) {
            for (var result, test, args = slice.call(arguments, 1), names = [ name ]; isString(test = args.shift()); ) names.push(test);
            result = isFunction(test) ? test(this.global, this.document, this.element) : test;
            for (var i = 0, j = names.length; j > i; i++) this[names[i]] === undefined && defineProperty(this, names[i], {
                value: result,
                enumerable: !0
            });
        }
    }, Has.constructor = Has.prototype.constructor = Has, Has;
}), define("jpmc/has", [ "jpmc/has/cache" ], function(Has, undefined) {
    function has(name) {
        return name !== undefined ? cache[name] : cache;
    }
    var global = this, document = global.document, element = document.createElement("has"), cache = new Has(global, document, element), isBrowser = window !== undefined && location !== undefined && document !== undefined && window.location === location && window.document === document;
    return has.cache = cache, has.add = function() {
        return cache.add.apply(cache, arguments);
    }, has.add("host-browser", isBrowser), has.add("dom", isBrowser), has.add("has-api", !0), 
    has.add("device-width", screen.availWidth || innerWidth), has.add("device-height", screen.availHeight || innerHeight), 
    has;
}), define("jpmc/has/detect/array", [ "jpmc/has", "jpmc/util/lang/isFunction" ], function(has, isFunction) {
    var EMPTY_ARRAY = [];
    return has.add("array-indexof", isFunction(EMPTY_ARRAY.indexOf)), has.add("array-isarray", isFunction(Array.isArray)), 
    has;
}), function(window) {
    function capitalize(string) {
        return string = String(string), string.charAt(0).toUpperCase() + string.slice(1);
    }
    function each(object, callback) {
        var index = -1, length = object.length;
        if (length == length >>> 0) for (;++index < length; ) callback(object[index], index, object); else forOwn(object, callback);
    }
    function format(string) {
        return string = trim(string), /^(?:webOS|i(?:OS|P))/.test(string) ? string : capitalize(string);
    }
    function forOwn(object, callback) {
        for (var key in object) hasKey(object, key) && callback(object[key], key, object);
    }
    function getClassOf(value) {
        return null == value ? capitalize(value) : toString.call(value).slice(8, -1);
    }
    function hasKey() {
        return hasKey = function(object, key) {
            var parent = null != object && (object.constructor || Object).prototype;
            return !!parent && key in Object(object) && !(key in parent && object[key] === parent[key]);
        }, "Function" == getClassOf(hasOwnProperty) ? hasKey = function(object, key) {
            return null != object && hasOwnProperty.call(object, key);
        } : {}.__proto__ == Object.prototype && (hasKey = function(object, key) {
            var result = !1;
            return null != object && (object = Object(object), object.__proto__ = [ object.__proto__, object.__proto__ = null, result = key in object ][0]), 
            result;
        }), hasKey.apply(this, arguments);
    }
    function isHostType(object, property) {
        var type = null != object ? typeof object[property] : "number";
        return !/^(?:boolean|number|string|undefined)$/.test(type) && ("object" == type ? !!object[property] : !0);
    }
    function qualify(string) {
        return String(string).replace(/([ -])(?!$)/g, "$1?");
    }
    function reduce(array, callback) {
        var accumulator = null;
        return each(array, function(value, index) {
            accumulator = callback(accumulator, value, index, array);
        }), accumulator;
    }
    function trim(string) {
        return String(string).replace(/^ +| +$/g, "");
    }
    function parse(ua) {
        function getLayout(guesses) {
            return reduce(guesses, function(result, guess) {
                return result || RegExp("\\b" + (guess.pattern || qualify(guess)) + "\\b", "i").exec(ua) && (guess.label || guess);
            });
        }
        function getManufacturer(guesses) {
            return reduce(guesses, function(result, value, key) {
                return result || (value[product] || value[/^[a-z]+(?: +[a-z]+\b)*/i.exec(product)] || RegExp("\\b" + (key.pattern || qualify(key)) + "(?:\\b|\\w*\\d)", "i").exec(ua)) && (key.label || key);
            });
        }
        function getName(guesses) {
            return reduce(guesses, function(result, guess) {
                return result || RegExp("\\b" + (guess.pattern || qualify(guess)) + "\\b", "i").exec(ua) && (guess.label || guess);
            });
        }
        function getOS(guesses) {
            return reduce(guesses, function(result, guess) {
                var pattern = guess.pattern || qualify(guess);
                return !result && (result = RegExp("\\b" + pattern + "(?:/[\\d.]+|[ \\w.]*)", "i").exec(ua)) && (data = {
                    "6.2": "8",
                    "6.1": "Server 2008 R2 / 7",
                    "6.0": "Server 2008 / Vista",
                    "5.2": "Server 2003 / XP 64-bit",
                    "5.1": "XP",
                    "5.01": "2000 SP1",
                    "5.0": "2000",
                    "4.0": "NT",
                    "4.90": "ME"
                }, /^Win/i.test(result) && (data = data[/[\d.]+$/.exec(result)]) && (result = "Windows " + data), 
                result = format(String(result).replace(RegExp(pattern, "i"), guess.label || guess).replace(/ ce$/i, " CE").replace(/hpw/i, "web").replace(/Macintosh/, "Mac OS").replace(/_PowerPC/i, " OS").replace(/(OS X) [^ \d]+/i, "$1").replace(/\/(\d)/, " $1").replace(/_/g, ".").replace(/(?: BePC|[ .]*fc[ \d.]+)$/i, "").replace(/x86\.64/gi, "x86_64").split(" on ")[0])), 
                result;
            });
        }
        function getProduct(guesses) {
            return reduce(guesses, function(result, guess) {
                var pattern = guess.pattern || qualify(guess);
                return !result && (result = RegExp("\\b" + pattern + " *\\d+[.\\w_]*", "i").exec(ua) || RegExp("\\b" + pattern + "(?:; *(?:[a-z]+[_-])?[a-z]+\\d+|[^ ();-]*)", "i").exec(ua)) && ((result = String(guess.label || result).split("/"))[1] && !/[\d.]+/.test(result[0]) && (result[0] += " " + result[1]), 
                guess = guess.label || guess, result = format(result[0].replace(RegExp(pattern, "i"), guess).replace(RegExp("; *(?:" + guess + "[_-])?", "i"), " ").replace(RegExp("(" + guess + ")(\\w)", "i"), "$1 $2"))), 
                result;
            });
        }
        function getVersion(patterns) {
            return reduce(patterns, function(result, pattern) {
                return result || (RegExp(pattern + "(?:-[\\d.]+/|(?: for [\\w-]+)?[ /-])([\\d.]+[^ ();/_-]*)", "i").exec(ua) || 0)[1] || null;
            });
        }
        function toStringPlatform() {
            return this.description || "";
        }
        ua || (ua = userAgent);
        var data, arch = ua, description = [], prerelease = null, useFeatures = ua == userAgent, version = useFeatures && opera && "function" == typeof opera.version && opera.version(), layout = getLayout([ {
            label: "WebKit",
            pattern: "AppleWebKit"
        }, "iCab", "Presto", "NetFront", "Tasman", "Trident", "KHTML", "Gecko" ]), name = getName([ "Adobe AIR", "Arora", "Avant Browser", "Camino", "Epiphany", "Fennec", "Flock", "Galeon", "GreenBrowser", "iCab", "Iceweasel", "Iron", "K-Meleon", "Konqueror", "Lunascape", "Maxthon", "Midori", "Nook Browser", "PhantomJS", "Raven", "Rekonq", "RockMelt", "SeaMonkey", {
            label: "Silk",
            pattern: "(?:Cloud9|Silk-Accelerated)"
        }, "Sleipnir", "SlimBrowser", "Sunrise", "Swiftfox", "WebPositive", "Opera Mini", "Opera", "Chrome", {
            label: "Chrome Mobile",
            pattern: "(?:CriOS|CrMo)"
        }, {
            label: "Firefox",
            pattern: "(?:Firefox|Minefield)"
        }, {
            label: "IE",
            pattern: "MSIE"
        }, {
            label: "IE",
            pattern: "rv:"
        }, "Safari" ]), product = getProduct([ "BlackBerry", {
            label: "Galaxy S",
            pattern: "GT-I9000"
        }, {
            label: "Galaxy S2",
            pattern: "GT-I9100"
        }, "Google TV", "iPad", "iPod", "iPhone", "Kindle", {
            label: "Kindle Fire",
            pattern: "(?:Cloud9|Silk-Accelerated)"
        }, "Nook", "PlayBook", "PlayStation Vita", "TouchPad", "Transformer", "Xoom" ]), manufacturer = getManufacturer({
            Apple: {
                iPad: 1,
                iPhone: 1,
                iPod: 1
            },
            Amazon: {
                Kindle: 1,
                "Kindle Fire": 1
            },
            Asus: {
                Transformer: 1
            },
            "Barnes & Noble": {
                Nook: 1
            },
            BlackBerry: {
                PlayBook: 1
            },
            Google: {
                "Google TV": 1
            },
            HP: {
                TouchPad: 1
            },
            LG: {},
            Motorola: {
                Xoom: 1
            },
            Nokia: {},
            Samsung: {
                "Galaxy S": 1,
                "Galaxy S2": 1
            },
            Sony: {
                "PlayStation Vita": 1
            }
        }), os = getOS([ "Android", "CentOS", "Debian", "Fedora", "FreeBSD", "Gentoo", "Haiku", "Kubuntu", "Linux Mint", "Red Hat", "SuSE", "Ubuntu", "Xubuntu", "Cygwin", "Symbian OS", "hpwOS", "webOS ", "webOS", "Tablet OS", "Linux", "Mac OS X", "Macintosh", "Mac", "Windows 98;", "Windows " ]);
        if (layout && (layout = [ layout ]), manufacturer && !product && (product = getProduct([ manufacturer ])), 
        (data = /Google TV/.exec(product)) && (product = data[0]), /\bSimulator\b/i.test(ua) && (product = (product ? product + " " : "") + "Simulator"), 
        /^iP/.test(product) ? (name || (name = "Safari"), os = "iOS" + ((data = / OS ([\d_]+)/i.exec(ua)) ? " " + data[1].replace(/_/g, ".") : "")) : "Konqueror" != name || /buntu/i.test(os) ? manufacturer && "Google" != manufacturer && /Chrome|Vita/.test(name + ";" + product) ? (name = "Android Browser", 
        os = /Android/.test(os) ? os : "Android") : (!name || (data = !/\bMinefield\b/i.test(ua) && /Firefox|Safari/.exec(name))) && (name && !product && /[\/,]|^[^(]+?\)/.test(ua.slice(ua.indexOf(data + "/") + 8)) && (name = null), 
        (data = product || manufacturer || os) && (product || manufacturer || /Android|Symbian OS|Tablet OS|webOS/.test(os)) && (name = /[a-z]+(?: Hat)?/i.exec(/Android/.test(os) ? os : data) + " Browser")) : os = "Kubuntu", 
        version || (version = getVersion([ "(?:Cloud9|CriOS|CrMo|Opera ?Mini|Raven|Silk(?!/[\\d.]+$))", "Version", qualify(name), "(?:Firefox|Minefield|NetFront)" ])), 
        "iCab" == layout && parseFloat(version) > 3 ? layout = [ "WebKit" ] : (data = /Opera/.test(name) && "Presto" || /\b(?:Midori|Nook|Safari)\b/i.test(ua) && "WebKit" || !layout && /\bMSIE\b/i.test(ua) && (/^Mac/.test(os) ? "Tasman" : "Trident")) && (layout = [ data ]), 
        useFeatures) {
            if (isHostType(window, "global")) if (java && (data = java.lang.System, arch = data.getProperty("os.arch"), 
            os = os || data.getProperty("os.name") + " " + data.getProperty("os.version")), 
            "object" == typeof exports && exports) if (thisBinding == oldWin && "object" == typeof system && (data = [ system ])[0]) {
                os || (os = data[0].os || null);
                try {
                    data[1] = require("ringo/engine").version, version = data[1].join("."), name = "RingoJS";
                } catch (e) {
                    data[0].global == freeGlobal && (name = "Narwhal");
                }
            } else "object" == typeof process && (data = process) && (name = "Node.js", arch = data.arch, 
            os = data.platform, version = /[\d.]+/.exec(data.version)[0]); else "Environment" == getClassOf(window.environment) && (name = "Rhino"); else "ScriptBridgingProxyObject" == getClassOf(data = window.runtime) ? (name = "Adobe AIR", 
            os = data.flash.system.Capabilities.os) : "RuntimeObject" == getClassOf(data = window.phantom) ? (name = "PhantomJS", 
            version = (data = data.version || null) && data.major + "." + data.minor + "." + data.patch) : "number" == typeof doc.documentMode && (data = /\bTrident\/(\d+)/i.exec(ua)) && (version = [ version, doc.documentMode ], 
            (data = +data[1] + 4) != version[1] && (description.push("IE " + version[1] + " mode"), 
            layout[1] = "", version[1] = data), version = "IE" == name ? String(version[1].toFixed(1)) : version[0]);
            os = os && format(os);
        }
        return version && (data = /(?:[ab]|dp|pre|[ab]\d+pre)(?:\d+\+?)?$/i.exec(version) || /(?:alpha|beta)(?: ?\d)?/i.exec(ua + ";" + (useFeatures && nav.appMinorVersion)) || /\bMinefield\b/i.test(ua) && "a") && (prerelease = /b/i.test(data) ? "beta" : "alpha", 
        version = version.replace(RegExp(data + "\\+?$"), "") + ("beta" == prerelease ? beta : alpha) + (/\d+\+?/.exec(data) || "")), 
        "Fennec" == name ? name = "Firefox Mobile" : "Maxthon" == name && version ? version = version.replace(/\.[\d.]+/, ".x") : "Silk" == name ? (/Mobi/i.test(ua) || (os = "Android", 
        description.unshift("desktop mode")), /Accelerated *= *true/i.test(ua) && description.unshift("accelerated")) : "IE" == name && (data = (/; *(?:XBLWP|ZuneWP)(\d+)/i.exec(ua) || 0)[1]) ? (name += " Mobile", 
        os = "Windows Phone OS " + data + ".x", description.unshift("desktop mode")) : "IE" != name && (!name || product || /Browser|Mobi/.test(name)) || "Windows CE" != os && !/Mobi/i.test(ua) ? "IE" == name && useFeatures && "object" == typeof external && !external ? description.unshift("platform preview") : /BlackBerry/.test(product) && (data = (RegExp(product.replace(/ +/g, " *") + "/([.\\d]+)", "i").exec(ua) || 0)[1] || version) ? (os = "Device Software " + data, 
        version = null) : this != forOwn && (useFeatures && opera || /Opera/.test(name) && /\b(?:MSIE|Firefox)\b/i.test(ua) || "Firefox" == name && /OS X (?:\d+\.){2,}/.test(os) || "IE" == name && (os && !/^Win/.test(os) && version > 5.5 || /Windows XP/.test(os) && version > 8 || 8 == version && !/Trident/.test(ua))) && !reOpera.test(data = parse.call(forOwn, ua.replace(reOpera, "") + ";")) && data.name && (data = "ing as " + data.name + ((data = data.version) ? " " + data : ""), 
        reOpera.test(name) ? (/IE/.test(data) && "Mac OS" == os && (os = null), data = "identify" + data) : (data = "mask" + data, 
        name = operaClass ? format(operaClass.replace(/([a-z])([A-Z])/g, "$1 $2")) : "Opera", 
        /IE/.test(data) && (os = null), useFeatures || (version = null)), layout = [ "Presto" ], 
        description.push(data)) : name += " Mobile", (data = (/\bAppleWebKit\/([\d.]+\+?)/i.exec(ua) || 0)[1]) && (data = [ parseFloat(data.replace(/\.(\d)$/, ".0$1")), data ], 
        "Safari" == name && "+" == data[1].slice(-1) ? (name = "WebKit Nightly", prerelease = "alpha", 
        version = data[1].slice(0, -1)) : (version == data[1] || version == (/\bSafari\/([\d.]+\+?)/i.exec(ua) || 0)[1]) && (version = null), 
        data = [ data[0], (/\bChrome\/([\d.]+)/i.exec(ua) || 0)[1] ], !useFeatures || /internal|\n/i.test(toString.toString()) && !data[1] ? (layout[1] = "like Safari", 
        data = data[0], data = 400 > data ? 1 : 500 > data ? 2 : 526 > data ? 3 : 533 > data ? 4 : 534 > data ? "4+" : 535 > data ? 5 : "5") : (layout[1] = "like Chrome", 
        data = data[1] || (data = data[0], 530 > data ? 1 : 532 > data ? 2 : 532.05 > data ? 3 : 533 > data ? 4 : 534.03 > data ? 5 : 534.07 > data ? 6 : 534.1 > data ? 7 : 534.13 > data ? 8 : 534.16 > data ? 9 : 534.24 > data ? 10 : 534.3 > data ? 11 : 535.01 > data ? 12 : 535.02 > data ? "13+" : 535.07 > data ? 15 : 535.11 > data ? 16 : 535.19 > data ? 17 : 536.05 > data ? 18 : 536.1 > data ? 19 : 537.01 > data ? 20 : "21")), 
        layout[1] += " " + (data += "number" == typeof data ? ".x" : /[.+]/.test(data) ? "" : "+"), 
        "Safari" == name && (!version || parseInt(version) > 45) && (version = data)), "Opera" == name && (data = /(?:zbov|zvav)$/.exec(os)) ? (name += " ", 
        description.unshift("desktop mode"), "zvav" == data ? (name += "Mini", version = null) : name += "Mobile") : "Safari" == name && /Chrome/.exec(layout[1]) && (description.unshift("desktop mode"), 
        name = "Chrome Mobile", version = null, /Mac OS X/.test(os) ? (manufacturer = "Apple", 
        os = "iOS 4.3+") : os = null), version && 0 == version.indexOf(data = /[\d.]+$/.exec(os)) && ua.indexOf("/" + data + "-") > -1 && (os = trim(os.replace(data, ""))), 
        layout && !/Avant|Nook/.test(name) && (/Browser|Lunascape|Maxthon/.test(name) || /^(?:Adobe|Arora|Midori|Phantom|Rekonq|Rock|Sleipnir|Web)/.test(name) && layout[1]) && (data = layout[layout.length - 1]) && description.push(data), 
        description.length && (description = [ "(" + description.join("; ") + ")" ]), manufacturer && product && product.indexOf(manufacturer) < 0 && description.push("on " + manufacturer), 
        product && description.push((/^on /.test(description[description.length - 1]) ? "" : "on ") + product), 
        os && (data = / ([\d.+]+)$/.exec(os), os = {
            architecture: 32,
            family: data ? os.replace(data[0], "") : os,
            version: data ? data[1] : null,
            toString: function() {
                var version = this.version;
                return this.family + (version ? " " + version : "") + (64 == this.architecture ? " 64-bit" : "");
            }
        }), (data = /\b(?:AMD|IA|Win|WOW|x86_|x)64\b/i.exec(arch)) && !/\bi686\b/i.test(arch) && (os && (os.architecture = 64, 
        os.family = os.family.replace(RegExp(" *" + data), "")), name && (/WOW64/i.test(ua) || useFeatures && /\w(?:86|32)$/.test(nav.cpuClass || nav.platform)) && description.unshift("32-bit")), 
        ua || (ua = null), {
            version: name && version && (description.unshift(version), version),
            name: name && (description.unshift(name), name),
            os: os ? (name && !(os == String(os).split(" ")[0] && (os == name.split(" ")[0] || product)) && description.push(product ? "(" + os + ")" : "on " + os), 
            os) : {
                architecture: null,
                family: null,
                version: null,
                toString: function() {
                    return "null";
                }
            },
            description: description.length ? description.join(" ") : ua,
            layout: layout && layout[0],
            manufacturer: manufacturer,
            prerelease: prerelease,
            product: product,
            ua: ua,
            parse: parse,
            toString: toStringPlatform
        };
    }
    var oldWin = window, freeExports = "object" == typeof exports && exports, freeGlobal = "object" == typeof global && global && (global == global.global ? window = global : global), reOpera = /Opera/, toString = {}.toString, java = /Java/.test(getClassOf(window.java)) && window.java, alpha = java ? "a" : "\u03b1", beta = java ? "b" : "\u03b2", doc = window.document || {}, hasOwnProperty = {}.hasOwnProperty, nav = window.navigator || {}, opera = window.operamini || window.opera, operaClass = reOpera.test(operaClass = getClassOf(opera)) ? operaClass : opera = null, thisBinding = this, userAgent = nav.userAgent || "";
    "function" == typeof define && "object" == typeof define.amd && define.amd ? define("platform", [], function() {
        return parse();
    }) : freeExports ? forOwn(parse(), function(value, key) {
        freeExports[key] = value;
    }) : window.platform = parse();
}(this), define("jpmc/util/object/VENDOR_PREFIXES", [], function() {
    return "Webkit Moz O ms";
}), define("jpmc/util/object/CLASS_PREFIXES", [ "./VENDOR_PREFIXES" ], function(VENDOR_PREFIXES) {
    return VENDOR_PREFIXES.split(" ");
}), define("jpmc/util/object/OBJECT_PREFIXES", [ "./VENDOR_PREFIXES" ], function(VENDOR_PREFIXES) {
    return VENDOR_PREFIXES.toLowerCase().split(" ");
}), define("jpmc/util/object/STYLE_PREFIXES", [ "./VENDOR_PREFIXES" ], function(VENDOR_PREFIXES) {
    return VENDOR_PREFIXES.split(" ");
}), define("mout/object/get", [], function() {
    function get(obj, prop) {
        for (var parts = prop.split("."), last = parts.pop(); prop = parts.shift(); ) if (obj = obj[prop], 
        "object" != typeof obj) return;
        return obj[last];
    }
    return get;
}), define("jpmc/util/object/getProperty", [ "mout/object/get" ], function(get) {
    return get;
}), define("jpmc/util/object/getPrefixed", [ "./CLASS_PREFIXES", "./OBJECT_PREFIXES", "./STYLE_PREFIXES", "./getProperty", "../lang/isFunction" ], function(CLASS_PREFIXES, OBJECT_PREFIXES, STYLE_PREFIXES, getProperty, isFunction, undefined) {
    var getPrefixed;
    return getPrefixed = function(object, propName) {
        var parts, prop, upperCasePropName = propName.charAt(0).toUpperCase() + propName.slice(1);
        propName === undefined && (propName = object, object = window), parts = "CSSStyleDeclaration" in window && object instanceof CSSStyleDeclaration ? (propName + " " + STYLE_PREFIXES.join(upperCasePropName + " ") + upperCasePropName).split(" ") : object === window ? (propName + " " + CLASS_PREFIXES.join(upperCasePropName + " ") + OBJECT_PREFIXES.join(upperCasePropName + " ") + upperCasePropName).split(" ") : (propName + " " + OBJECT_PREFIXES.join(upperCasePropName + " ") + upperCasePropName).split(" ");
        for (var i = 0, j = parts.length; j > i; i++) if (prop = getProperty(object, parts[i]), 
        prop !== undefined) return isFunction(prop) ? function() {
            return prop.apply(object, arguments);
        } : prop;
        return prop;
    };
}), define("jpmc/util/object/hasPrefixed", [ "./getPrefixed" ], function(getPrefixed, undefined) {
    var hasPrefixed;
    return hasPrefixed = function(object, propName) {
        return getPrefixed(object, propName) !== undefined;
    };
}), define("jpmc/has/detect/native", [ "jpmc/has", "jpmc/util/object/hasPrefixed" ], function(has, hasPrefixed) {
    return has.add("activex", function(g) {
        return "ActiveXObject" in g;
    }), has.add("activex-enabled", function() {
        var supported = !1;
        if (has("activex")) try {
            supported = !!new ActiveXObject("htmlfile");
        } catch (e) {
            supported = !1;
        }
        return supported;
    }), has.add("native-matchmedia", function(g) {
        return hasPrefixed(g, "matchMedia");
    }), has.add("native-navigator", function(g) {
        return "navigator" in g;
    }), has.add("native-orientation", function(g) {
        return "orientation" in g;
    }), has.add("native-crosswindowmessaging", "postmessage", function(g) {
        return "postMessage" in g;
    }), has.add("native-geolocation", function(g) {
        return !0 && "geolocation" in g.navigator;
    }), has.add("native-xhr", function(g) {
        return "XMLHttpRequest" in g;
    }), has.add("xhr", function() {
        return has("native-xhr") || has("activex") && has("activex-enabled");
    }), has.add("native-cors", "xhr-cors", function() {
        var xmlHttp = window.XMLHttpRequest ? "withCredentials" in new XMLHttpRequest() : !1;
        return has("native-xhr") && xmlHttp;
    }), has;
}), define("jpmc/has/detect/unsecureBrowserArray", [ "require" ], function() {
    return [ "browser-ie-6", "browser-ie-7", "browser-ie-8", "browser-ie-9", "browser-ie-10" ];
}), define("jpmc/has/detect/browser", [ "platform", "./native", "jpmc/has/detect/unsecureBrowserArray" ], function(platform, has, unsecureBrowserArray, undefined) {
    var name, parseFloat = window.parseFloat, osFamily = (window.navigator, {
        Android: "android",
        "FreeBSD|Haiku": "bsd",
        "CentOS|Debian|Fedora|Gentoo|buntu|Linux|Red Hat|SuSE|Cygwin": "linux",
        webOS: "webos",
        "Mac|Darwin": "macintosh",
        iOS: "ios",
        Symbian: "symbian",
        "Device Software|Tablet OS": "blackberry",
        Windows: "windows"
    }), nameRegex = /[\s&]+/g, formatName = function(prefix, name) {
        name === undefined && (name = prefix, prefix = undefined);
        var formattedName = [];
        return prefix && formattedName.push(prefix), formattedName.push(name && name.replace(nameRegex, "").toLowerCase()), 
        formattedName.join("-");
    }, findOSFamily = function(family, callback) {
        var name, regex, supported;
        for (var key in osFamily) !function(pattern, os) {
            regex = new RegExp(pattern), supported = regex.test(family), name = formatName("os", os), 
            callback(name, supported);
        }(key, osFamily[key]);
    }, version = platform.version !== undefined && parseFloat(platform.version);
    if (platform.name) {
        name = formatName("browser", platform.name), has.add(name, version || !0), version && has.add(name + "-" + version, !0);
        for (var unsecureBrowser = !1, i = 0; i < unsecureBrowserArray.length; i++) has(unsecureBrowserArray[i]) && (unsecureBrowser = !0);
        has.add("browser-unsecure", unsecureBrowser);
    }
    return platform.manufacturer && (name = formatName("manufacturer", platform.manufacturer), 
    has.add(name, !0)), platform.os && platform.os.family && findOSFamily(platform.os.family, function(name, supported) {
        has.add(name, supported);
    }), platform.product && (name = formatName("product", platform.product), has.add(name, !0)), 
    platform.layout && (name = formatName("layout", platform.layout), has.add(name, !0)), 
    has;
}), define("jpmc/has/detect/console", [ "jpmc/has" ], function(has) {
    var methods = "assert clear count debug dir dirxml error group groupCollapsed groupEnd info log markTimeline memoryProfile memoryProfileEnd profile profileEnd table time timeEnd timeStamp trace warn".split(" ");
    has.add("console", function(g) {
        return "console" in g;
    });
    for (var i = 0, j = methods.length; j > i; i++) !function(m) {
        has.add("console-" + m.toLowerCase(), function(g) {
            return has("console") && m in g.console;
        });
    }(methods[i]);
    return has.add("native-console", function(g) {
        return has("console") && g.console instanceof Object;
    }), has;
}), define("jpmc/util/dom/hasEvent", [ "../lang/isFunction", "../lang/isString" ], function(isFunction, isString, undefined) {
    var hasEvent, document = window.document, isDetectable = "onblur" in document.documentElement, mutationRegex = /^DOM\w+$/, TAGNAMES = {
        select: "input",
        change: "input",
        submit: "form",
        reset: "form",
        error: "img",
        load: "img",
        abort: "img"
    };
    return hasEvent = function(tag, eventType) {
        eventType === undefined && (eventType = tag, tag = undefined);
        var element, isSupported = !1, isMutation = mutationRegex.test(eventType), onEventType = "on" + eventType;
        if (eventType) {
            if (element = !tag || isString(tag) ? document.createElement(tag || TAGNAMES[eventType] || "div") : tag, 
            isSupported = onEventType in element, !isSupported && (element.setAttribute || (element = document.createElement("div")), 
            element.setAttribute && element.removeAttribute)) if (isMutation) {
                var callback;
                element.addEventListener && (callback = function() {
                    element.removeEventListener(eventType, callback, !1), isSupported = !0;
                }, element.addEventListener(eventType, callback, !1), element.setAttribute("___TEST___", !0), 
                element.removeAttribute("___TEST___"));
            } else isDetectable || (element.setAttribute(onEventType, ""), isSupported = isFunction(element[onEventType]), 
            element[onEventType] !== undefined && (element[onEventType] = undefined), element.removeAttribute(onEventType));
            element = undefined;
        }
        return isSupported;
    };
}), define("jpmc/has/detect/dom", [ "jpmc/has", "jpmc/util/dom/hasEvent", "jpmc/util/object/hasPrefixed" ], function(has, hasEvent, hasPrefixed) {
    return has.add("dom-cookies", "cookies", function(g, d) {
        var supported = !1;
        return "cookie" in d && (d.cookie = "cookietest=1", supported = -1 !== d.cookie.indexOf("cookietest="), 
        d.cookie = "cookietest=1; expires=Thu, 01-Jan-1970 00:00:01 GMT"), supported;
    }), has.add("dom-quirks", "quirks", function(g, d, el) {
        var isSupported = !1;
        return "documentMode" in d ? isSupported = 5 === d.documentMode : "compatMode" in d ? isSupported = "BackCompat" === d.compatMode : (el.style.width = "1", 
        isSupported = "1px" === el.style.width, el.style.width = ""), isSupported;
    }), has.add("dom-addeventlistener", function(g, d) {
        return "addEventListener" in d;
    }), has.add("dom-mutationobserver", function(g) {
        return hasPrefixed(g, "MutationObserver");
    }), has.add("dom-attrmodified", function(g, d, el) {
        return hasEvent(el, "DOMAttrModified");
    }), has.add("dom-propertychange", function(g, d, el) {
        return hasEvent(el, "propertychange");
    }), has.add("dom-touchstart", "touch", function(g, d) {
        return "ontouchstart" in g || g.DocumentTouch && d instanceof DocumentTouch;
    }), has;
}), define("mout/object/has", [ "./get" ], function(get) {
    function has(obj, prop) {
        return get(obj, prop) !== UNDEF;
    }
    var UNDEF;
    return has;
}), define("jpmc/util/object/hasProperty", [ "mout/object/has" ], function(has) {
    var hasProperty;
    return hasProperty = has;
}), define("jpmc/has/detect/css", [ "./dom", "jpmc/util/object/hasProperty" ], function(has, hasProperty) {
    return has.add("css-border-radius", function(g, d, e) {
        return hasProperty(e.style, "borderRadius");
    }), has.add("css-box-shadow", function(g, d, e) {
        return hasProperty(e.style, "boxShadow");
    }), has.add("css-box-sizing", function(g, d, e) {
        return !has("dom-quirks") && hasProperty(e.style, "boxSizing");
    }), has;
}), define("jpmc/has/detect/framed", [ "jpmc/has" ], function(has) {
    return has.add("framed", function(g) {
        return g.self !== g.top;
    }), has;
}), define("jpmc/has/detect/function", [ "jpmc/has", "jpmc/util/lang/isFunction" ], function(has, isFunction) {
    return has.add("function-bind", isFunction(Function.prototype.bind)), has;
}), define("jpmc/has/detect/history", [ "./browser", "platform" ], function(has, platform) {
    return has.add("native-history", "history", function(g) {
        return has("browser-androidbrowser") && platform.os && 2 === g.parseInt(platform.os.version) ? !1 : "history" in g && "pushState" in g.history;
    }), has;
}), define("jpmc/has/INPUT_TYPES", [], function() {
    return "search tel url email datetime date month week time datetime-local number range color".split(" ");
}), define("jpmc/has/detect/input", [ "jpmc/has", "../INPUT_TYPES" ], function(has, INPUT_TYPES) {
    for (var defaultView, type, document = has.cache.document, documentElement = document.documentElement, input = document.createElement("input"), rangeRegex = /^range$/, searchAndTelRegex = /^(search|tel)$/, urlAndEmailRegex = /^(url|email)$/, supported = !1, TEST_VALUE = "__TEST__", i = 0, j = INPUT_TYPES.length; j > i; i++) input.setAttribute("type", type = INPUT_TYPES[i]), 
    supported = "text" !== input.type, supported && (input.value = TEST_VALUE, input.style.cssText = "position:absolute;visibility:hidden;", 
    rangeRegex.test(type) && void 0 !== input.style.WebkitAppearance ? (documentElement.appendChild(input), 
    defaultView = document.defaultView, supported = defaultView.getComputedStyle && "textfield" !== defaultView.getComputedStyle(input, null).WebkitAppearance && 0 !== input.offsetHeight, 
    documentElement.removeChild(input)) : searchAndTelRegex.test(type) || (supported = urlAndEmailRegex.test(type) ? input.checkValidity && input.checkValidity() === !1 : input.value !== TEST_VALUE)), 
    has.add("dom-input" + type, !!supported);
    return input = void 0, has;
}), define("jpmc/has/detect/object", [ "jpmc/has", "jpmc/util/lang/isFunction" ], function(has, isFunction) {
    var hasDefineProperty = function(object) {
        if ("defineProperty" in Object) try {
            return Object.defineProperty(object, "test", {
                configurable: !0,
                writable: !0,
                value: 1
            }), "test" in object;
        } catch (e) {}
    };
    return has.add("object-__proto__", function() {
        var supported = !1, arr = [], obj = {}, backup = arr.__proto__;
        return arr.__proto__ === Array.prototype && obj.__proto__ === Object.prototype && (arr.__proto__ = obj, 
        supported = "undefined" == typeof arr.push, arr.__proto__ = backup), supported && isFunction(arr.push);
    }), has.add("object-create", isFunction(Object.create)), has.add("object-defineproperty-obj", function() {
        return hasDefineProperty({});
    }), has.add("object-defineproperty-dom", function(g, d, el) {
        var supported = hasDefineProperty(el);
        if (supported) {
            el.test = void 0;
            try {
                delete el.test;
            } catch (e) {}
        }
        return supported;
    }), has.add("object-defineproperty", has("object-defineproperty-obj") && has("object-defineproperty-dom")), 
    has.add("object-defineproperties", isFunction(Object.defineProperties)), has.add("object-freeze", isFunction(Object.freeze)), 
    has.add("object-getownpropertydescriptor", isFunction(Object.getOwnPropertyDescriptor)), 
    has.add("object-getownpropertynames", isFunction(Object.getOwnPropertyNames)), has.add("object-getprototypeof", isFunction(Object.getPrototypeOf)), 
    has.add("object-isextensible", isFunction(Object.isExtensible)), has.add("object-isfrozen", isFunction(Object.isFrozen)), 
    has.add("object-issealed", isFunction(Object.isSealed)), has.add("object-keys", isFunction(Object.keys)), 
    has.add("object-preventextensions", isFunction(Object.preventExtensions)), has.add("object-seal", isFunction(Object.seal)), 
    has;
}), define("jpmc/has/detect/string", [ "jpmc/has", "jpmc/util/lang/isFunction" ], function(has, isFunction) {
    var EMPTY_STRING = "";
    return has.add("string-trim", isFunction(EMPTY_STRING.trim)), has.add("string-trimleft", isFunction(EMPTY_STRING.trimLeft)), 
    has.add("string-trimright", isFunction(EMPTY_STRING.trimRight)), has.add("string-endswith", isFunction(EMPTY_STRING.endsWith)), 
    has.add("string-startswith", isFunction(EMPTY_STRING.startsWith)), has;
}), define("jpmc/has/detect/time", [ "jpmc/has", "jpmc/util/lang/isFunction", "jpmc/util/object/hasPrefixed" ], function(has, isFunction, hasPrefixed) {
    return has.add("date-toisostring", isFunction(Date.prototype.toISOString)), has.add("date-tojson", isFunction(Date.prototype.toJSON)), 
    has.add("date-now", isFunction(Date.now)), has.add("performance", function(g) {
        return "performance" in g;
    }), has.add("performance-now", function(g) {
        return has("performance") && hasPrefixed(g.performance, "now");
    }), has;
}), define("jpmc/has/detect/all", [ "jpmc/has", "./array", "./browser", "./console", "./css", "./dom", "./framed", "./function", "./history", "./input", "./native", "./object", "./string", "./time" ], function(has) {
    return has;
}), define("jpmc/init", [ "jpmc/has/detect/all" ], function(has) {
    var html = window.document.documentElement, nameRegex = /^(browser|css|layout|manufacturer|os|product)\-.+|quirks|touch$/, noJsRegex = /(^|\s)no-js(\s|$)/, cache = has(), className = [ "js" ];
    for (var name in cache) nameRegex.test(name) && has(name) && className.push(name);
    html.className.length && (html.className = html.className.replace(noJsRegex, "$1$2") + " "), 
    html.className += className.length ? className.join(" ") : "";
}), function(window, undefined) {
    var document = window.document, define = window.define, require = window.require, isAMD = "function" == typeof require && "function" == typeof define && define.amd !== undefined, JPMC = {
        version: "20140720",
        buildDate: "20150724"
    };
    if (isAMD) {
        require.config({
            waitSeconds: 15,
            baseUrl: "/jpmcjs/",
            paths: {
                can: "can-1.1.6",
                jquery: "jquery-1.10.2",
                domReady: "domReady-2.0.1",
                easyXDM: "easyXDM-2.4.18.25",
                handlebars: "handlebars.runtime-1.0.0",
                jquerypp: "jquerypp-1.0.1",
                "jquery-bbq": "jquery.ba-bbq-1.2.1",
                "jquery-cookie": "jquery.cookie-1.2",
                "jquery-cycle": "jquery.cycle-2.9999.3",
                "jquery-imagesloaded": "jquery.imagesloaded-2.1.1",
                jquerytools: "jquerytools-1.2.7",
                jqueryui: "jqueryui-1.10.2",
                jqueryresize: "jquery.ba-resize-1.1",
                moment: "moment-2.1.0",
                mout: "mout-0.6.0",
                platform: "platform-1.0.0",
                regula: "regula-1.2.3",
                signals: "signals-1.0.0",
                stacktrace: "stacktrace-0.6.0",
                swfobject: "swfobject-2.2",
                taffy: "taffy-2.7.3",
                pdfobject: "pdfobject-1.2",
                text: "text-2.0.7",
                uri: "uri-1.10.2"
            },
            map: {
                "*": {
                    "can/util/library": "can/util/jquery",
                    "poly/json": "json",
                    "wire/domReady": "domReady",
                    "wire/debug": "jpmc/wire/debug"
                }
            },
            packages: [ {
                name: "meld",
                location: "meld-1.3.0",
                main: "meld"
            }, {
                name: "poly",
                location: "poly-0.5.2",
                main: "poly"
            }, {
                name: "when",
                location: "when-2.2.1",
                main: "when"
            }, {
                name: "wire",
                location: "wire-0.10.1",
                main: "wire"
            } ],
            shim: {
                easyXDM: {
                    exports: "easyXDM"
                },
                swfobject: {
                    exports: "swfobject"
                },
                pdfobject: {
                    exports: "PDFObject"
                }
            },
            deps: [ "jpmc/init" ]
        });
        for (var dataBase, baseUrl, script, scriptSrc, scripts = document.getElementsByTagName("script"), i = scripts.length, SLASH = "/"; i--; ) if (script = scripts[i], 
        dataBase = script.getAttribute("data-base")) {
            scriptSrc = script.src.split(SLASH), scriptSrc.pop(), baseUrl = (scriptSrc.length ? scriptSrc.join(SLASH) : ".") + SLASH, 
            require.config({
                baseUrl: baseUrl
            });
            break;
        }
        define("jpmc", JPMC);
    }
}(this), function(window, undefined) {
    function isArraylike(obj) {
        var length = obj.length, type = jQuery.type(obj);
        return jQuery.isWindow(obj) ? !1 : 1 === obj.nodeType && length ? !0 : "array" === type || "function" !== type && (0 === length || "number" == typeof length && length > 0 && length - 1 in obj);
    }
    function createOptions(options) {
        var object = optionsCache[options] = {};
        return jQuery.each(options.match(core_rnotwhite) || [], function(_, flag) {
            object[flag] = !0;
        }), object;
    }
    function internalData(elem, name, data, pvt) {
        if (jQuery.acceptData(elem)) {
            var ret, thisCache, internalKey = jQuery.expando, isNode = elem.nodeType, cache = isNode ? jQuery.cache : elem, id = isNode ? elem[internalKey] : elem[internalKey] && internalKey;
            if (id && cache[id] && (pvt || cache[id].data) || data !== undefined || "string" != typeof name) return id || (id = isNode ? elem[internalKey] = core_deletedIds.pop() || jQuery.guid++ : internalKey), 
            cache[id] || (cache[id] = isNode ? {} : {
                toJSON: jQuery.noop
            }), ("object" == typeof name || "function" == typeof name) && (pvt ? cache[id] = jQuery.extend(cache[id], name) : cache[id].data = jQuery.extend(cache[id].data, name)), 
            thisCache = cache[id], pvt || (thisCache.data || (thisCache.data = {}), thisCache = thisCache.data), 
            data !== undefined && (thisCache[jQuery.camelCase(name)] = data), "string" == typeof name ? (ret = thisCache[name], 
            null == ret && (ret = thisCache[jQuery.camelCase(name)])) : ret = thisCache, ret;
        }
    }
    function internalRemoveData(elem, name, pvt) {
        if (jQuery.acceptData(elem)) {
            var thisCache, i, isNode = elem.nodeType, cache = isNode ? jQuery.cache : elem, id = isNode ? elem[jQuery.expando] : jQuery.expando;
            if (cache[id]) {
                if (name && (thisCache = pvt ? cache[id] : cache[id].data)) {
                    jQuery.isArray(name) ? name = name.concat(jQuery.map(name, jQuery.camelCase)) : name in thisCache ? name = [ name ] : (name = jQuery.camelCase(name), 
                    name = name in thisCache ? [ name ] : name.split(" ")), i = name.length;
                    for (;i--; ) delete thisCache[name[i]];
                    if (pvt ? !isEmptyDataObject(thisCache) : !jQuery.isEmptyObject(thisCache)) return;
                }
                (pvt || (delete cache[id].data, isEmptyDataObject(cache[id]))) && (isNode ? jQuery.cleanData([ elem ], !0) : jQuery.support.deleteExpando || cache != cache.window ? delete cache[id] : cache[id] = null);
            }
        }
    }
    function dataAttr(elem, key, data) {
        if (data === undefined && 1 === elem.nodeType) {
            var name = "data-" + key.replace(rmultiDash, "-$1").toLowerCase();
            if (data = elem.getAttribute(name), "string" == typeof data) {
                try {
                    data = "true" === data ? !0 : "false" === data ? !1 : "null" === data ? null : +data + "" === data ? +data : rbrace.test(data) ? jQuery.parseJSON(data) : data;
                } catch (e) {}
                jQuery.data(elem, key, data);
            } else data = undefined;
        }
        return data;
    }
    function isEmptyDataObject(obj) {
        var name;
        for (name in obj) if (("data" !== name || !jQuery.isEmptyObject(obj[name])) && "toJSON" !== name) return !1;
        return !0;
    }
    function returnTrue() {
        return !0;
    }
    function returnFalse() {
        return !1;
    }
    function safeActiveElement() {
        try {
            return document.activeElement;
        } catch (err) {}
    }
    function sibling(cur, dir) {
        do cur = cur[dir]; while (cur && 1 !== cur.nodeType);
        return cur;
    }
    function winnow(elements, qualifier, not) {
        if (jQuery.isFunction(qualifier)) return jQuery.grep(elements, function(elem, i) {
            return !!qualifier.call(elem, i, elem) !== not;
        });
        if (qualifier.nodeType) return jQuery.grep(elements, function(elem) {
            return elem === qualifier !== not;
        });
        if ("string" == typeof qualifier) {
            if (isSimple.test(qualifier)) return jQuery.filter(qualifier, elements, not);
            qualifier = jQuery.filter(qualifier, elements);
        }
        return jQuery.grep(elements, function(elem) {
            return jQuery.inArray(elem, qualifier) >= 0 !== not;
        });
    }
    function createSafeFragment(document) {
        var list = nodeNames.split("|"), safeFrag = document.createDocumentFragment();
        if (safeFrag.createElement) for (;list.length; ) safeFrag.createElement(list.pop());
        return safeFrag;
    }
    function manipulationTarget(elem, content) {
        return jQuery.nodeName(elem, "table") && jQuery.nodeName(1 === content.nodeType ? content : content.firstChild, "tr") ? elem.getElementsByTagName("tbody")[0] || elem.appendChild(elem.ownerDocument.createElement("tbody")) : elem;
    }
    function disableScript(elem) {
        return elem.type = (null !== jQuery.find.attr(elem, "type")) + "/" + elem.type, 
        elem;
    }
    function restoreScript(elem) {
        var match = rscriptTypeMasked.exec(elem.type);
        return match ? elem.type = match[1] : elem.removeAttribute("type"), elem;
    }
    function setGlobalEval(elems, refElements) {
        for (var elem, i = 0; null != (elem = elems[i]); i++) jQuery._data(elem, "globalEval", !refElements || jQuery._data(refElements[i], "globalEval"));
    }
    function cloneCopyEvent(src, dest) {
        if (1 === dest.nodeType && jQuery.hasData(src)) {
            var type, i, l, oldData = jQuery._data(src), curData = jQuery._data(dest, oldData), events = oldData.events;
            if (events) {
                delete curData.handle, curData.events = {};
                for (type in events) for (i = 0, l = events[type].length; l > i; i++) jQuery.event.add(dest, type, events[type][i]);
            }
            curData.data && (curData.data = jQuery.extend({}, curData.data));
        }
    }
    function fixCloneNodeIssues(src, dest) {
        var nodeName, e, data;
        if (1 === dest.nodeType) {
            if (nodeName = dest.nodeName.toLowerCase(), !jQuery.support.noCloneEvent && dest[jQuery.expando]) {
                data = jQuery._data(dest);
                for (e in data.events) jQuery.removeEvent(dest, e, data.handle);
                dest.removeAttribute(jQuery.expando);
            }
            "script" === nodeName && dest.text !== src.text ? (disableScript(dest).text = src.text, 
            restoreScript(dest)) : "object" === nodeName ? (dest.parentNode && (dest.outerHTML = src.outerHTML), 
            jQuery.support.html5Clone && src.innerHTML && !jQuery.trim(dest.innerHTML) && (dest.innerHTML = src.innerHTML)) : "input" === nodeName && manipulation_rcheckableType.test(src.type) ? (dest.defaultChecked = dest.checked = src.checked, 
            dest.value !== src.value && (dest.value = src.value)) : "option" === nodeName ? dest.defaultSelected = dest.selected = src.defaultSelected : ("input" === nodeName || "textarea" === nodeName) && (dest.defaultValue = src.defaultValue);
        }
    }
    function getAll(context, tag) {
        var elems, elem, i = 0, found = typeof context.getElementsByTagName !== core_strundefined ? context.getElementsByTagName(tag || "*") : typeof context.querySelectorAll !== core_strundefined ? context.querySelectorAll(tag || "*") : undefined;
        if (!found) for (found = [], elems = context.childNodes || context; null != (elem = elems[i]); i++) !tag || jQuery.nodeName(elem, tag) ? found.push(elem) : jQuery.merge(found, getAll(elem, tag));
        return tag === undefined || tag && jQuery.nodeName(context, tag) ? jQuery.merge([ context ], found) : found;
    }
    function fixDefaultChecked(elem) {
        manipulation_rcheckableType.test(elem.type) && (elem.defaultChecked = elem.checked);
    }
    function vendorPropName(style, name) {
        if (name in style) return name;
        for (var capName = name.charAt(0).toUpperCase() + name.slice(1), origName = name, i = cssPrefixes.length; i--; ) if (name = cssPrefixes[i] + capName, 
        name in style) return name;
        return origName;
    }
    function isHidden(elem, el) {
        return elem = el || elem, "none" === jQuery.css(elem, "display") || !jQuery.contains(elem.ownerDocument, elem);
    }
    function showHide(elements, show) {
        for (var display, elem, hidden, values = [], index = 0, length = elements.length; length > index; index++) elem = elements[index], 
        elem.style && (values[index] = jQuery._data(elem, "olddisplay"), display = elem.style.display, 
        show ? (values[index] || "none" !== display || (elem.style.display = ""), "" === elem.style.display && isHidden(elem) && (values[index] = jQuery._data(elem, "olddisplay", css_defaultDisplay(elem.nodeName)))) : values[index] || (hidden = isHidden(elem), 
        (display && "none" !== display || !hidden) && jQuery._data(elem, "olddisplay", hidden ? display : jQuery.css(elem, "display"))));
        for (index = 0; length > index; index++) elem = elements[index], elem.style && (show && "none" !== elem.style.display && "" !== elem.style.display || (elem.style.display = show ? values[index] || "" : "none"));
        return elements;
    }
    function setPositiveNumber(elem, value, subtract) {
        var matches = rnumsplit.exec(value);
        return matches ? Math.max(0, matches[1] - (subtract || 0)) + (matches[2] || "px") : value;
    }
    function augmentWidthOrHeight(elem, name, extra, isBorderBox, styles) {
        for (var i = extra === (isBorderBox ? "border" : "content") ? 4 : "width" === name ? 1 : 0, val = 0; 4 > i; i += 2) "margin" === extra && (val += jQuery.css(elem, extra + cssExpand[i], !0, styles)), 
        isBorderBox ? ("content" === extra && (val -= jQuery.css(elem, "padding" + cssExpand[i], !0, styles)), 
        "margin" !== extra && (val -= jQuery.css(elem, "border" + cssExpand[i] + "Width", !0, styles))) : (val += jQuery.css(elem, "padding" + cssExpand[i], !0, styles), 
        "padding" !== extra && (val += jQuery.css(elem, "border" + cssExpand[i] + "Width", !0, styles)));
        return val;
    }
    function getWidthOrHeight(elem, name, extra) {
        var valueIsBorderBox = !0, val = "width" === name ? elem.offsetWidth : elem.offsetHeight, styles = getStyles(elem), isBorderBox = jQuery.support.boxSizing && "border-box" === jQuery.css(elem, "boxSizing", !1, styles);
        if (0 >= val || null == val) {
            if (val = curCSS(elem, name, styles), (0 > val || null == val) && (val = elem.style[name]), 
            rnumnonpx.test(val)) return val;
            valueIsBorderBox = isBorderBox && (jQuery.support.boxSizingReliable || val === elem.style[name]), 
            val = parseFloat(val) || 0;
        }
        return val + augmentWidthOrHeight(elem, name, extra || (isBorderBox ? "border" : "content"), valueIsBorderBox, styles) + "px";
    }
    function css_defaultDisplay(nodeName) {
        var doc = document, display = elemdisplay[nodeName];
        return display || (display = actualDisplay(nodeName, doc), "none" !== display && display || (iframe = (iframe || jQuery("<iframe frameborder='0' width='0' height='0'/>").css("cssText", "display:block !important")).appendTo(doc.documentElement), 
        doc = (iframe[0].contentWindow || iframe[0].contentDocument).document, doc.write("<!doctype html><html><body>"), 
        doc.close(), display = actualDisplay(nodeName, doc), iframe.detach()), elemdisplay[nodeName] = display), 
        display;
    }
    function actualDisplay(name, doc) {
        var elem = jQuery(doc.createElement(name)).appendTo(doc.body), display = jQuery.css(elem[0], "display");
        return elem.remove(), display;
    }
    function buildParams(prefix, obj, traditional, add) {
        var name;
        if (jQuery.isArray(obj)) jQuery.each(obj, function(i, v) {
            traditional || rbracket.test(prefix) ? add(prefix, v) : buildParams(prefix + "[" + ("object" == typeof v ? i : "") + "]", v, traditional, add);
        }); else if (traditional || "object" !== jQuery.type(obj)) add(prefix, obj); else for (name in obj) buildParams(prefix + "[" + name + "]", obj[name], traditional, add);
    }
    function addToPrefiltersOrTransports(structure) {
        return function(dataTypeExpression, func) {
            "string" != typeof dataTypeExpression && (func = dataTypeExpression, dataTypeExpression = "*");
            var dataType, i = 0, dataTypes = dataTypeExpression.toLowerCase().match(core_rnotwhite) || [];
            if (jQuery.isFunction(func)) for (;dataType = dataTypes[i++]; ) "+" === dataType[0] ? (dataType = dataType.slice(1) || "*", 
            (structure[dataType] = structure[dataType] || []).unshift(func)) : (structure[dataType] = structure[dataType] || []).push(func);
        };
    }
    function inspectPrefiltersOrTransports(structure, options, originalOptions, jqXHR) {
        function inspect(dataType) {
            var selected;
            return inspected[dataType] = !0, jQuery.each(structure[dataType] || [], function(_, prefilterOrFactory) {
                var dataTypeOrTransport = prefilterOrFactory(options, originalOptions, jqXHR);
                return "string" != typeof dataTypeOrTransport || seekingTransport || inspected[dataTypeOrTransport] ? seekingTransport ? !(selected = dataTypeOrTransport) : void 0 : (options.dataTypes.unshift(dataTypeOrTransport), 
                inspect(dataTypeOrTransport), !1);
            }), selected;
        }
        var inspected = {}, seekingTransport = structure === transports;
        return inspect(options.dataTypes[0]) || !inspected["*"] && inspect("*");
    }
    function ajaxExtend(target, src) {
        var deep, key, flatOptions = jQuery.ajaxSettings.flatOptions || {};
        for (key in src) src[key] !== undefined && ((flatOptions[key] ? target : deep || (deep = {}))[key] = src[key]);
        return deep && jQuery.extend(!0, target, deep), target;
    }
    function ajaxHandleResponses(s, jqXHR, responses) {
        for (var firstDataType, ct, finalDataType, type, contents = s.contents, dataTypes = s.dataTypes; "*" === dataTypes[0]; ) dataTypes.shift(), 
        ct === undefined && (ct = s.mimeType || jqXHR.getResponseHeader("Content-Type"));
        if (ct) for (type in contents) if (contents[type] && contents[type].test(ct)) {
            dataTypes.unshift(type);
            break;
        }
        if (dataTypes[0] in responses) finalDataType = dataTypes[0]; else {
            for (type in responses) {
                if (!dataTypes[0] || s.converters[type + " " + dataTypes[0]]) {
                    finalDataType = type;
                    break;
                }
                firstDataType || (firstDataType = type);
            }
            finalDataType = finalDataType || firstDataType;
        }
        return finalDataType ? (finalDataType !== dataTypes[0] && dataTypes.unshift(finalDataType), 
        responses[finalDataType]) : void 0;
    }
    function ajaxConvert(s, response, jqXHR, isSuccess) {
        var conv2, current, conv, tmp, prev, converters = {}, dataTypes = s.dataTypes.slice();
        if (dataTypes[1]) for (conv in s.converters) converters[conv.toLowerCase()] = s.converters[conv];
        for (current = dataTypes.shift(); current; ) if (s.responseFields[current] && (jqXHR[s.responseFields[current]] = response), 
        !prev && isSuccess && s.dataFilter && (response = s.dataFilter(response, s.dataType)), 
        prev = current, current = dataTypes.shift()) if ("*" === current) current = prev; else if ("*" !== prev && prev !== current) {
            if (conv = converters[prev + " " + current] || converters["* " + current], !conv) for (conv2 in converters) if (tmp = conv2.split(" "), 
            tmp[1] === current && (conv = converters[prev + " " + tmp[0]] || converters["* " + tmp[0]])) {
                conv === !0 ? conv = converters[conv2] : converters[conv2] !== !0 && (current = tmp[0], 
                dataTypes.unshift(tmp[1]));
                break;
            }
            if (conv !== !0) if (conv && s["throws"]) response = conv(response); else try {
                response = conv(response);
            } catch (e) {
                return {
                    state: "parsererror",
                    error: conv ? e : "No conversion from " + prev + " to " + current
                };
            }
        }
        return {
            state: "success",
            data: response
        };
    }
    function createStandardXHR() {
        try {
            return new window.XMLHttpRequest();
        } catch (e) {}
    }
    function createActiveXHR() {
        try {
            return new window.ActiveXObject("Microsoft.XMLHTTP");
        } catch (e) {}
    }
    function createFxNow() {
        return setTimeout(function() {
            fxNow = undefined;
        }), fxNow = jQuery.now();
    }
    function createTween(value, prop, animation) {
        for (var tween, collection = (tweeners[prop] || []).concat(tweeners["*"]), index = 0, length = collection.length; length > index; index++) if (tween = collection[index].call(animation, prop, value)) return tween;
    }
    function Animation(elem, properties, options) {
        var result, stopped, index = 0, length = animationPrefilters.length, deferred = jQuery.Deferred().always(function() {
            delete tick.elem;
        }), tick = function() {
            if (stopped) return !1;
            for (var currentTime = fxNow || createFxNow(), remaining = Math.max(0, animation.startTime + animation.duration - currentTime), temp = remaining / animation.duration || 0, percent = 1 - temp, index = 0, length = animation.tweens.length; length > index; index++) animation.tweens[index].run(percent);
            return deferred.notifyWith(elem, [ animation, percent, remaining ]), 1 > percent && length ? remaining : (deferred.resolveWith(elem, [ animation ]), 
            !1);
        }, animation = deferred.promise({
            elem: elem,
            props: jQuery.extend({}, properties),
            opts: jQuery.extend(!0, {
                specialEasing: {}
            }, options),
            originalProperties: properties,
            originalOptions: options,
            startTime: fxNow || createFxNow(),
            duration: options.duration,
            tweens: [],
            createTween: function(prop, end) {
                var tween = jQuery.Tween(elem, animation.opts, prop, end, animation.opts.specialEasing[prop] || animation.opts.easing);
                return animation.tweens.push(tween), tween;
            },
            stop: function(gotoEnd) {
                var index = 0, length = gotoEnd ? animation.tweens.length : 0;
                if (stopped) return this;
                for (stopped = !0; length > index; index++) animation.tweens[index].run(1);
                return gotoEnd ? deferred.resolveWith(elem, [ animation, gotoEnd ]) : deferred.rejectWith(elem, [ animation, gotoEnd ]), 
                this;
            }
        }), props = animation.props;
        for (propFilter(props, animation.opts.specialEasing); length > index; index++) if (result = animationPrefilters[index].call(animation, elem, props, animation.opts)) return result;
        return jQuery.map(props, createTween, animation), jQuery.isFunction(animation.opts.start) && animation.opts.start.call(elem, animation), 
        jQuery.fx.timer(jQuery.extend(tick, {
            elem: elem,
            anim: animation,
            queue: animation.opts.queue
        })), animation.progress(animation.opts.progress).done(animation.opts.done, animation.opts.complete).fail(animation.opts.fail).always(animation.opts.always);
    }
    function propFilter(props, specialEasing) {
        var index, name, easing, value, hooks;
        for (index in props) if (name = jQuery.camelCase(index), easing = specialEasing[name], 
        value = props[index], jQuery.isArray(value) && (easing = value[1], value = props[index] = value[0]), 
        index !== name && (props[name] = value, delete props[index]), hooks = jQuery.cssHooks[name], 
        hooks && "expand" in hooks) {
            value = hooks.expand(value), delete props[name];
            for (index in value) index in props || (props[index] = value[index], specialEasing[index] = easing);
        } else specialEasing[name] = easing;
    }
    function defaultPrefilter(elem, props, opts) {
        var prop, value, toggle, tween, hooks, oldfire, anim = this, orig = {}, style = elem.style, hidden = elem.nodeType && isHidden(elem), dataShow = jQuery._data(elem, "fxshow");
        opts.queue || (hooks = jQuery._queueHooks(elem, "fx"), null == hooks.unqueued && (hooks.unqueued = 0, 
        oldfire = hooks.empty.fire, hooks.empty.fire = function() {
            hooks.unqueued || oldfire();
        }), hooks.unqueued++, anim.always(function() {
            anim.always(function() {
                hooks.unqueued--, jQuery.queue(elem, "fx").length || hooks.empty.fire();
            });
        })), 1 === elem.nodeType && ("height" in props || "width" in props) && (opts.overflow = [ style.overflow, style.overflowX, style.overflowY ], 
        "inline" === jQuery.css(elem, "display") && "none" === jQuery.css(elem, "float") && (jQuery.support.inlineBlockNeedsLayout && "inline" !== css_defaultDisplay(elem.nodeName) ? style.zoom = 1 : style.display = "inline-block")), 
        opts.overflow && (style.overflow = "hidden", jQuery.support.shrinkWrapBlocks || anim.always(function() {
            style.overflow = opts.overflow[0], style.overflowX = opts.overflow[1], style.overflowY = opts.overflow[2];
        }));
        for (prop in props) if (value = props[prop], rfxtypes.exec(value)) {
            if (delete props[prop], toggle = toggle || "toggle" === value, value === (hidden ? "hide" : "show")) continue;
            orig[prop] = dataShow && dataShow[prop] || jQuery.style(elem, prop);
        }
        if (!jQuery.isEmptyObject(orig)) {
            dataShow ? "hidden" in dataShow && (hidden = dataShow.hidden) : dataShow = jQuery._data(elem, "fxshow", {}), 
            toggle && (dataShow.hidden = !hidden), hidden ? jQuery(elem).show() : anim.done(function() {
                jQuery(elem).hide();
            }), anim.done(function() {
                var prop;
                jQuery._removeData(elem, "fxshow");
                for (prop in orig) jQuery.style(elem, prop, orig[prop]);
            });
            for (prop in orig) tween = createTween(hidden ? dataShow[prop] : 0, prop, anim), 
            prop in dataShow || (dataShow[prop] = tween.start, hidden && (tween.end = tween.start, 
            tween.start = "width" === prop || "height" === prop ? 1 : 0));
        }
    }
    function Tween(elem, options, prop, end, easing) {
        return new Tween.prototype.init(elem, options, prop, end, easing);
    }
    function genFx(type, includeWidth) {
        var which, attrs = {
            height: type
        }, i = 0;
        for (includeWidth = includeWidth ? 1 : 0; 4 > i; i += 2 - includeWidth) which = cssExpand[i], 
        attrs["margin" + which] = attrs["padding" + which] = type;
        return includeWidth && (attrs.opacity = attrs.width = type), attrs;
    }
    function getWindow(elem) {
        return jQuery.isWindow(elem) ? elem : 9 === elem.nodeType ? elem.defaultView || elem.parentWindow : !1;
    }
    var readyList, rootjQuery, core_strundefined = typeof undefined, location = window.location, document = window.document, docElem = document.documentElement, _jQuery = window.jQuery, _$ = window.$, class2type = {}, core_deletedIds = [], core_version = "1.10.2", core_concat = core_deletedIds.concat, core_push = core_deletedIds.push, core_slice = core_deletedIds.slice, core_indexOf = core_deletedIds.indexOf, core_toString = class2type.toString, core_hasOwn = class2type.hasOwnProperty, core_trim = core_version.trim, jQuery = function(selector, context) {
        return new jQuery.fn.init(selector, context, rootjQuery);
    }, core_pnum = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source, core_rnotwhite = /\S+/g, rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/, rsingleTag = /^<(\w+)\s*\/?>(?:<\/\1>|)$/, rvalidchars = /^[\],:{}\s]*$/, rvalidbraces = /(?:^|:|,)(?:\s*\[)+/g, rvalidescape = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g, rvalidtokens = /"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g, rmsPrefix = /^-ms-/, rdashAlpha = /-([\da-z])/gi, fcamelCase = function(all, letter) {
        return letter.toUpperCase();
    }, completed = function(event) {
        (document.addEventListener || "load" === event.type || "complete" === document.readyState) && (detach(), 
        jQuery.ready());
    }, detach = function() {
        document.addEventListener ? (document.removeEventListener("DOMContentLoaded", completed, !1), 
        window.removeEventListener("load", completed, !1)) : (document.detachEvent("onreadystatechange", completed), 
        window.detachEvent("onload", completed));
    };
    jQuery.fn = jQuery.prototype = {
        jquery: core_version,
        constructor: jQuery,
        init: function(selector, context, rootjQuery) {
            var match, elem;
            if (!selector) return this;
            if ("string" == typeof selector) {
                if (match = "<" === selector.charAt(0) && ">" === selector.charAt(selector.length - 1) && selector.length >= 3 ? [ null, selector, null ] : rquickExpr.exec(selector), 
                !match || !match[1] && context) return !context || context.jquery ? (context || rootjQuery).find(selector) : this.constructor(context).find(selector);
                if (match[1]) {
                    if (context = context instanceof jQuery ? context[0] : context, jQuery.merge(this, jQuery.parseHTML(match[1], context && context.nodeType ? context.ownerDocument || context : document, !0)), 
                    rsingleTag.test(match[1]) && jQuery.isPlainObject(context)) for (match in context) jQuery.isFunction(this[match]) ? this[match](context[match]) : this.attr(match, context[match]);
                    return this;
                }
                if (elem = document.getElementById(match[2]), elem && elem.parentNode) {
                    if (elem.id !== match[2]) return rootjQuery.find(selector);
                    this.length = 1, this[0] = elem;
                }
                return this.context = document, this.selector = selector, this;
            }
            return selector.nodeType ? (this.context = this[0] = selector, this.length = 1, 
            this) : jQuery.isFunction(selector) ? rootjQuery.ready(selector) : (selector.selector !== undefined && (this.selector = selector.selector, 
            this.context = selector.context), jQuery.makeArray(selector, this));
        },
        selector: "",
        length: 0,
        toArray: function() {
            return core_slice.call(this);
        },
        get: function(num) {
            return null == num ? this.toArray() : 0 > num ? this[this.length + num] : this[num];
        },
        pushStack: function(elems) {
            var ret = jQuery.merge(this.constructor(), elems);
            return ret.prevObject = this, ret.context = this.context, ret;
        },
        each: function(callback, args) {
            return jQuery.each(this, callback, args);
        },
        ready: function(fn) {
            return jQuery.ready.promise().done(fn), this;
        },
        slice: function() {
            return this.pushStack(core_slice.apply(this, arguments));
        },
        first: function() {
            return this.eq(0);
        },
        last: function() {
            return this.eq(-1);
        },
        eq: function(i) {
            var len = this.length, j = +i + (0 > i ? len : 0);
            return this.pushStack(j >= 0 && len > j ? [ this[j] ] : []);
        },
        map: function(callback) {
            return this.pushStack(jQuery.map(this, function(elem, i) {
                return callback.call(elem, i, elem);
            }));
        },
        end: function() {
            return this.prevObject || this.constructor(null);
        },
        push: core_push,
        sort: [].sort,
        splice: [].splice
    }, jQuery.fn.init.prototype = jQuery.fn, jQuery.extend = jQuery.fn.extend = function() {
        var src, copyIsArray, copy, name, options, clone, target = arguments[0] || {}, i = 1, length = arguments.length, deep = !1;
        for ("boolean" == typeof target && (deep = target, target = arguments[1] || {}, 
        i = 2), "object" == typeof target || jQuery.isFunction(target) || (target = {}), 
        length === i && (target = this, --i); length > i; i++) if (null != (options = arguments[i])) for (name in options) src = target[name], 
        copy = options[name], target !== copy && (deep && copy && (jQuery.isPlainObject(copy) || (copyIsArray = jQuery.isArray(copy))) ? (copyIsArray ? (copyIsArray = !1, 
        clone = src && jQuery.isArray(src) ? src : []) : clone = src && jQuery.isPlainObject(src) ? src : {}, 
        target[name] = jQuery.extend(deep, clone, copy)) : copy !== undefined && (target[name] = copy));
        return target;
    }, jQuery.extend({
        expando: "jQuery" + (core_version + Math.random()).replace(/\D/g, ""),
        noConflict: function(deep) {
            return window.$ === jQuery && (window.$ = _$), deep && window.jQuery === jQuery && (window.jQuery = _jQuery), 
            jQuery;
        },
        isReady: !1,
        readyWait: 1,
        holdReady: function(hold) {
            hold ? jQuery.readyWait++ : jQuery.ready(!0);
        },
        ready: function(wait) {
            if (wait === !0 ? !--jQuery.readyWait : !jQuery.isReady) {
                if (!document.body) return setTimeout(jQuery.ready);
                jQuery.isReady = !0, wait !== !0 && --jQuery.readyWait > 0 || (readyList.resolveWith(document, [ jQuery ]), 
                jQuery.fn.trigger && jQuery(document).trigger("ready").off("ready"));
            }
        },
        isFunction: function(obj) {
            return "function" === jQuery.type(obj);
        },
        isArray: Array.isArray || function(obj) {
            return "array" === jQuery.type(obj);
        },
        isWindow: function(obj) {
            return null != obj && obj == obj.window;
        },
        isNumeric: function(obj) {
            return !isNaN(parseFloat(obj)) && isFinite(obj);
        },
        type: function(obj) {
            return null == obj ? String(obj) : "object" == typeof obj || "function" == typeof obj ? class2type[core_toString.call(obj)] || "object" : typeof obj;
        },
        isPlainObject: function(obj) {
            var key;
            if (!obj || "object" !== jQuery.type(obj) || obj.nodeType || jQuery.isWindow(obj)) return !1;
            try {
                if (obj.constructor && !core_hasOwn.call(obj, "constructor") && !core_hasOwn.call(obj.constructor.prototype, "isPrototypeOf")) return !1;
            } catch (e) {
                return !1;
            }
            if (jQuery.support.ownLast) for (key in obj) return core_hasOwn.call(obj, key);
            for (key in obj) ;
            return key === undefined || core_hasOwn.call(obj, key);
        },
        isEmptyObject: function(obj) {
            var name;
            for (name in obj) return !1;
            return !0;
        },
        error: function(msg) {
            throw new Error(msg);
        },
        parseHTML: function(data, context, keepScripts) {
            if (!data || "string" != typeof data) return null;
            "boolean" == typeof context && (keepScripts = context, context = !1), context = context || document;
            var parsed = rsingleTag.exec(data), scripts = !keepScripts && [];
            return parsed ? [ context.createElement(parsed[1]) ] : (parsed = jQuery.buildFragment([ data ], context, scripts), 
            scripts && jQuery(scripts).remove(), jQuery.merge([], parsed.childNodes));
        },
        parseJSON: function(data) {
            return window.JSON && window.JSON.parse ? window.JSON.parse(data) : null === data ? data : "string" == typeof data && (data = jQuery.trim(data), 
            data && rvalidchars.test(data.replace(rvalidescape, "@").replace(rvalidtokens, "]").replace(rvalidbraces, ""))) ? new Function("return " + data)() : void jQuery.error("Invalid JSON: " + data);
        },
        parseXML: function(data) {
            var xml, tmp;
            if (!data || "string" != typeof data) return null;
            try {
                window.DOMParser ? (tmp = new DOMParser(), xml = tmp.parseFromString(data, "text/xml")) : (xml = new ActiveXObject("Microsoft.XMLDOM"), 
                xml.async = "false", xml.loadXML(data));
            } catch (e) {
                xml = undefined;
            }
            return xml && xml.documentElement && !xml.getElementsByTagName("parsererror").length || jQuery.error("Invalid XML: " + data), 
            xml;
        },
        noop: function() {},
        globalEval: function(data) {
            data && jQuery.trim(data) && (window.execScript || function(data) {
                window.eval.call(window, data);
            })(data);
        },
        camelCase: function(string) {
            return string.replace(rmsPrefix, "ms-").replace(rdashAlpha, fcamelCase);
        },
        nodeName: function(elem, name) {
            return elem.nodeName && elem.nodeName.toLowerCase() === name.toLowerCase();
        },
        each: function(obj, callback, args) {
            var value, i = 0, length = obj.length, isArray = isArraylike(obj);
            if (args) {
                if (isArray) for (;length > i && (value = callback.apply(obj[i], args), value !== !1); i++) ; else for (i in obj) if (value = callback.apply(obj[i], args), 
                value === !1) break;
            } else if (isArray) for (;length > i && (value = callback.call(obj[i], i, obj[i]), 
            value !== !1); i++) ; else for (i in obj) if (value = callback.call(obj[i], i, obj[i]), 
            value === !1) break;
            return obj;
        },
        trim: core_trim && !core_trim.call("\ufeff\xa0") ? function(text) {
            return null == text ? "" : core_trim.call(text);
        } : function(text) {
            return null == text ? "" : (text + "").replace(rtrim, "");
        },
        makeArray: function(arr, results) {
            var ret = results || [];
            return null != arr && (isArraylike(Object(arr)) ? jQuery.merge(ret, "string" == typeof arr ? [ arr ] : arr) : core_push.call(ret, arr)), 
            ret;
        },
        inArray: function(elem, arr, i) {
            var len;
            if (arr) {
                if (core_indexOf) return core_indexOf.call(arr, elem, i);
                for (len = arr.length, i = i ? 0 > i ? Math.max(0, len + i) : i : 0; len > i; i++) if (i in arr && arr[i] === elem) return i;
            }
            return -1;
        },
        merge: function(first, second) {
            var l = second.length, i = first.length, j = 0;
            if ("number" == typeof l) for (;l > j; j++) first[i++] = second[j]; else for (;second[j] !== undefined; ) first[i++] = second[j++];
            return first.length = i, first;
        },
        grep: function(elems, callback, inv) {
            var retVal, ret = [], i = 0, length = elems.length;
            for (inv = !!inv; length > i; i++) retVal = !!callback(elems[i], i), inv !== retVal && ret.push(elems[i]);
            return ret;
        },
        map: function(elems, callback, arg) {
            var value, i = 0, length = elems.length, isArray = isArraylike(elems), ret = [];
            if (isArray) for (;length > i; i++) value = callback(elems[i], i, arg), null != value && (ret[ret.length] = value); else for (i in elems) value = callback(elems[i], i, arg), 
            null != value && (ret[ret.length] = value);
            return core_concat.apply([], ret);
        },
        guid: 1,
        proxy: function(fn, context) {
            var args, proxy, tmp;
            return "string" == typeof context && (tmp = fn[context], context = fn, fn = tmp), 
            jQuery.isFunction(fn) ? (args = core_slice.call(arguments, 2), proxy = function() {
                return fn.apply(context || this, args.concat(core_slice.call(arguments)));
            }, proxy.guid = fn.guid = fn.guid || jQuery.guid++, proxy) : undefined;
        },
        access: function(elems, fn, key, value, chainable, emptyGet, raw) {
            var i = 0, length = elems.length, bulk = null == key;
            if ("object" === jQuery.type(key)) {
                chainable = !0;
                for (i in key) jQuery.access(elems, fn, i, key[i], !0, emptyGet, raw);
            } else if (value !== undefined && (chainable = !0, jQuery.isFunction(value) || (raw = !0), 
            bulk && (raw ? (fn.call(elems, value), fn = null) : (bulk = fn, fn = function(elem, key, value) {
                return bulk.call(jQuery(elem), value);
            })), fn)) for (;length > i; i++) fn(elems[i], key, raw ? value : value.call(elems[i], i, fn(elems[i], key)));
            return chainable ? elems : bulk ? fn.call(elems) : length ? fn(elems[0], key) : emptyGet;
        },
        now: function() {
            return new Date().getTime();
        },
        swap: function(elem, options, callback, args) {
            var ret, name, old = {};
            for (name in options) old[name] = elem.style[name], elem.style[name] = options[name];
            ret = callback.apply(elem, args || []);
            for (name in options) elem.style[name] = old[name];
            return ret;
        }
    }), jQuery.ready.promise = function(obj) {
        if (!readyList) if (readyList = jQuery.Deferred(), "complete" === document.readyState) setTimeout(jQuery.ready); else if (document.addEventListener) document.addEventListener("DOMContentLoaded", completed, !1), 
        window.addEventListener("load", completed, !1); else {
            document.attachEvent("onreadystatechange", completed), window.attachEvent("onload", completed);
            var top = !1;
            try {
                top = null == window.frameElement && document.documentElement;
            } catch (e) {}
            top && top.doScroll && !function doScrollCheck() {
                if (!jQuery.isReady) {
                    try {
                        top.doScroll("left");
                    } catch (e) {
                        return setTimeout(doScrollCheck, 50);
                    }
                    detach(), jQuery.ready();
                }
            }();
        }
        return readyList.promise(obj);
    }, jQuery.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(i, name) {
        class2type["[object " + name + "]"] = name.toLowerCase();
    }), rootjQuery = jQuery(document), function(window, undefined) {
        function Sizzle(selector, context, results, seed) {
            var match, elem, m, nodeType, i, groups, old, nid, newContext, newSelector;
            if ((context ? context.ownerDocument || context : preferredDoc) !== document && setDocument(context), 
            context = context || document, results = results || [], !selector || "string" != typeof selector) return results;
            if (1 !== (nodeType = context.nodeType) && 9 !== nodeType) return [];
            if (documentIsHTML && !seed) {
                if (match = rquickExpr.exec(selector)) if (m = match[1]) {
                    if (9 === nodeType) {
                        if (elem = context.getElementById(m), !elem || !elem.parentNode) return results;
                        if (elem.id === m) return results.push(elem), results;
                    } else if (context.ownerDocument && (elem = context.ownerDocument.getElementById(m)) && contains(context, elem) && elem.id === m) return results.push(elem), 
                    results;
                } else {
                    if (match[2]) return push.apply(results, context.getElementsByTagName(selector)), 
                    results;
                    if ((m = match[3]) && support.getElementsByClassName && context.getElementsByClassName) return push.apply(results, context.getElementsByClassName(m)), 
                    results;
                }
                if (support.qsa && (!rbuggyQSA || !rbuggyQSA.test(selector))) {
                    if (nid = old = expando, newContext = context, newSelector = 9 === nodeType && selector, 
                    1 === nodeType && "object" !== context.nodeName.toLowerCase()) {
                        for (groups = tokenize(selector), (old = context.getAttribute("id")) ? nid = old.replace(rescape, "\\$&") : context.setAttribute("id", nid), 
                        nid = "[id='" + nid + "'] ", i = groups.length; i--; ) groups[i] = nid + toSelector(groups[i]);
                        newContext = rsibling.test(selector) && context.parentNode || context, newSelector = groups.join(",");
                    }
                    if (newSelector) try {
                        return push.apply(results, newContext.querySelectorAll(newSelector)), results;
                    } catch (qsaError) {} finally {
                        old || context.removeAttribute("id");
                    }
                }
            }
            return select(selector.replace(rtrim, "$1"), context, results, seed);
        }
        function createCache() {
            function cache(key, value) {
                return keys.push(key += " ") > Expr.cacheLength && delete cache[keys.shift()], cache[key] = value;
            }
            var keys = [];
            return cache;
        }
        function markFunction(fn) {
            return fn[expando] = !0, fn;
        }
        function assert(fn) {
            var div = document.createElement("div");
            try {
                return !!fn(div);
            } catch (e) {
                return !1;
            } finally {
                div.parentNode && div.parentNode.removeChild(div), div = null;
            }
        }
        function addHandle(attrs, handler) {
            for (var arr = attrs.split("|"), i = attrs.length; i--; ) Expr.attrHandle[arr[i]] = handler;
        }
        function siblingCheck(a, b) {
            var cur = b && a, diff = cur && 1 === a.nodeType && 1 === b.nodeType && (~b.sourceIndex || MAX_NEGATIVE) - (~a.sourceIndex || MAX_NEGATIVE);
            if (diff) return diff;
            if (cur) for (;cur = cur.nextSibling; ) if (cur === b) return -1;
            return a ? 1 : -1;
        }
        function createInputPseudo(type) {
            return function(elem) {
                var name = elem.nodeName.toLowerCase();
                return "input" === name && elem.type === type;
            };
        }
        function createButtonPseudo(type) {
            return function(elem) {
                var name = elem.nodeName.toLowerCase();
                return ("input" === name || "button" === name) && elem.type === type;
            };
        }
        function createPositionalPseudo(fn) {
            return markFunction(function(argument) {
                return argument = +argument, markFunction(function(seed, matches) {
                    for (var j, matchIndexes = fn([], seed.length, argument), i = matchIndexes.length; i--; ) seed[j = matchIndexes[i]] && (seed[j] = !(matches[j] = seed[j]));
                });
            });
        }
        function setFilters() {}
        function tokenize(selector, parseOnly) {
            var matched, match, tokens, type, soFar, groups, preFilters, cached = tokenCache[selector + " "];
            if (cached) return parseOnly ? 0 : cached.slice(0);
            for (soFar = selector, groups = [], preFilters = Expr.preFilter; soFar; ) {
                (!matched || (match = rcomma.exec(soFar))) && (match && (soFar = soFar.slice(match[0].length) || soFar), 
                groups.push(tokens = [])), matched = !1, (match = rcombinators.exec(soFar)) && (matched = match.shift(), 
                tokens.push({
                    value: matched,
                    type: match[0].replace(rtrim, " ")
                }), soFar = soFar.slice(matched.length));
                for (type in Expr.filter) !(match = matchExpr[type].exec(soFar)) || preFilters[type] && !(match = preFilters[type](match)) || (matched = match.shift(), 
                tokens.push({
                    value: matched,
                    type: type,
                    matches: match
                }), soFar = soFar.slice(matched.length));
                if (!matched) break;
            }
            return parseOnly ? soFar.length : soFar ? Sizzle.error(selector) : tokenCache(selector, groups).slice(0);
        }
        function toSelector(tokens) {
            for (var i = 0, len = tokens.length, selector = ""; len > i; i++) selector += tokens[i].value;
            return selector;
        }
        function addCombinator(matcher, combinator, base) {
            var dir = combinator.dir, checkNonElements = base && "parentNode" === dir, doneName = done++;
            return combinator.first ? function(elem, context, xml) {
                for (;elem = elem[dir]; ) if (1 === elem.nodeType || checkNonElements) return matcher(elem, context, xml);
            } : function(elem, context, xml) {
                var data, cache, outerCache, dirkey = dirruns + " " + doneName;
                if (xml) {
                    for (;elem = elem[dir]; ) if ((1 === elem.nodeType || checkNonElements) && matcher(elem, context, xml)) return !0;
                } else for (;elem = elem[dir]; ) if (1 === elem.nodeType || checkNonElements) if (outerCache = elem[expando] || (elem[expando] = {}), 
                (cache = outerCache[dir]) && cache[0] === dirkey) {
                    if ((data = cache[1]) === !0 || data === cachedruns) return data === !0;
                } else if (cache = outerCache[dir] = [ dirkey ], cache[1] = matcher(elem, context, xml) || cachedruns, 
                cache[1] === !0) return !0;
            };
        }
        function elementMatcher(matchers) {
            return matchers.length > 1 ? function(elem, context, xml) {
                for (var i = matchers.length; i--; ) if (!matchers[i](elem, context, xml)) return !1;
                return !0;
            } : matchers[0];
        }
        function condense(unmatched, map, filter, context, xml) {
            for (var elem, newUnmatched = [], i = 0, len = unmatched.length, mapped = null != map; len > i; i++) (elem = unmatched[i]) && (!filter || filter(elem, context, xml)) && (newUnmatched.push(elem), 
            mapped && map.push(i));
            return newUnmatched;
        }
        function setMatcher(preFilter, selector, matcher, postFilter, postFinder, postSelector) {
            return postFilter && !postFilter[expando] && (postFilter = setMatcher(postFilter)), 
            postFinder && !postFinder[expando] && (postFinder = setMatcher(postFinder, postSelector)), 
            markFunction(function(seed, results, context, xml) {
                var temp, i, elem, preMap = [], postMap = [], preexisting = results.length, elems = seed || multipleContexts(selector || "*", context.nodeType ? [ context ] : context, []), matcherIn = !preFilter || !seed && selector ? elems : condense(elems, preMap, preFilter, context, xml), matcherOut = matcher ? postFinder || (seed ? preFilter : preexisting || postFilter) ? [] : results : matcherIn;
                if (matcher && matcher(matcherIn, matcherOut, context, xml), postFilter) for (temp = condense(matcherOut, postMap), 
                postFilter(temp, [], context, xml), i = temp.length; i--; ) (elem = temp[i]) && (matcherOut[postMap[i]] = !(matcherIn[postMap[i]] = elem));
                if (seed) {
                    if (postFinder || preFilter) {
                        if (postFinder) {
                            for (temp = [], i = matcherOut.length; i--; ) (elem = matcherOut[i]) && temp.push(matcherIn[i] = elem);
                            postFinder(null, matcherOut = [], temp, xml);
                        }
                        for (i = matcherOut.length; i--; ) (elem = matcherOut[i]) && (temp = postFinder ? indexOf.call(seed, elem) : preMap[i]) > -1 && (seed[temp] = !(results[temp] = elem));
                    }
                } else matcherOut = condense(matcherOut === results ? matcherOut.splice(preexisting, matcherOut.length) : matcherOut), 
                postFinder ? postFinder(null, results, matcherOut, xml) : push.apply(results, matcherOut);
            });
        }
        function matcherFromTokens(tokens) {
            for (var checkContext, matcher, j, len = tokens.length, leadingRelative = Expr.relative[tokens[0].type], implicitRelative = leadingRelative || Expr.relative[" "], i = leadingRelative ? 1 : 0, matchContext = addCombinator(function(elem) {
                return elem === checkContext;
            }, implicitRelative, !0), matchAnyContext = addCombinator(function(elem) {
                return indexOf.call(checkContext, elem) > -1;
            }, implicitRelative, !0), matchers = [ function(elem, context, xml) {
                return !leadingRelative && (xml || context !== outermostContext) || ((checkContext = context).nodeType ? matchContext(elem, context, xml) : matchAnyContext(elem, context, xml));
            } ]; len > i; i++) if (matcher = Expr.relative[tokens[i].type]) matchers = [ addCombinator(elementMatcher(matchers), matcher) ]; else {
                if (matcher = Expr.filter[tokens[i].type].apply(null, tokens[i].matches), matcher[expando]) {
                    for (j = ++i; len > j && !Expr.relative[tokens[j].type]; j++) ;
                    return setMatcher(i > 1 && elementMatcher(matchers), i > 1 && toSelector(tokens.slice(0, i - 1).concat({
                        value: " " === tokens[i - 2].type ? "*" : ""
                    })).replace(rtrim, "$1"), matcher, j > i && matcherFromTokens(tokens.slice(i, j)), len > j && matcherFromTokens(tokens = tokens.slice(j)), len > j && toSelector(tokens));
                }
                matchers.push(matcher);
            }
            return elementMatcher(matchers);
        }
        function matcherFromGroupMatchers(elementMatchers, setMatchers) {
            var matcherCachedRuns = 0, bySet = setMatchers.length > 0, byElement = elementMatchers.length > 0, superMatcher = function(seed, context, xml, results, expandContext) {
                var elem, j, matcher, setMatched = [], matchedCount = 0, i = "0", unmatched = seed && [], outermost = null != expandContext, contextBackup = outermostContext, elems = seed || byElement && Expr.find.TAG("*", expandContext && context.parentNode || context), dirrunsUnique = dirruns += null == contextBackup ? 1 : Math.random() || .1;
                for (outermost && (outermostContext = context !== document && context, cachedruns = matcherCachedRuns); null != (elem = elems[i]); i++) {
                    if (byElement && elem) {
                        for (j = 0; matcher = elementMatchers[j++]; ) if (matcher(elem, context, xml)) {
                            results.push(elem);
                            break;
                        }
                        outermost && (dirruns = dirrunsUnique, cachedruns = ++matcherCachedRuns);
                    }
                    bySet && ((elem = !matcher && elem) && matchedCount--, seed && unmatched.push(elem));
                }
                if (matchedCount += i, bySet && i !== matchedCount) {
                    for (j = 0; matcher = setMatchers[j++]; ) matcher(unmatched, setMatched, context, xml);
                    if (seed) {
                        if (matchedCount > 0) for (;i--; ) unmatched[i] || setMatched[i] || (setMatched[i] = pop.call(results));
                        setMatched = condense(setMatched);
                    }
                    push.apply(results, setMatched), outermost && !seed && setMatched.length > 0 && matchedCount + setMatchers.length > 1 && Sizzle.uniqueSort(results);
                }
                return outermost && (dirruns = dirrunsUnique, outermostContext = contextBackup), 
                unmatched;
            };
            return bySet ? markFunction(superMatcher) : superMatcher;
        }
        function multipleContexts(selector, contexts, results) {
            for (var i = 0, len = contexts.length; len > i; i++) Sizzle(selector, contexts[i], results);
            return results;
        }
        function select(selector, context, results, seed) {
            var i, tokens, token, type, find, match = tokenize(selector);
            if (!seed && 1 === match.length) {
                if (tokens = match[0] = match[0].slice(0), tokens.length > 2 && "ID" === (token = tokens[0]).type && support.getById && 9 === context.nodeType && documentIsHTML && Expr.relative[tokens[1].type]) {
                    if (context = (Expr.find.ID(token.matches[0].replace(runescape, funescape), context) || [])[0], 
                    !context) return results;
                    selector = selector.slice(tokens.shift().value.length);
                }
                for (i = matchExpr.needsContext.test(selector) ? 0 : tokens.length; i-- && (token = tokens[i], 
                !Expr.relative[type = token.type]); ) if ((find = Expr.find[type]) && (seed = find(token.matches[0].replace(runescape, funescape), rsibling.test(tokens[0].type) && context.parentNode || context))) {
                    if (tokens.splice(i, 1), selector = seed.length && toSelector(tokens), !selector) return push.apply(results, seed), 
                    results;
                    break;
                }
            }
            return compile(selector, match)(seed, context, !documentIsHTML, results, rsibling.test(selector)), 
            results;
        }
        var i, support, cachedruns, Expr, getText, isXML, compile, outermostContext, sortInput, setDocument, document, docElem, documentIsHTML, rbuggyQSA, rbuggyMatches, matches, contains, expando = "sizzle" + -new Date(), preferredDoc = window.document, dirruns = 0, done = 0, classCache = createCache(), tokenCache = createCache(), compilerCache = createCache(), hasDuplicate = !1, sortOrder = function(a, b) {
            return a === b ? (hasDuplicate = !0, 0) : 0;
        }, strundefined = typeof undefined, MAX_NEGATIVE = 1 << 31, hasOwn = {}.hasOwnProperty, arr = [], pop = arr.pop, push_native = arr.push, push = arr.push, slice = arr.slice, indexOf = arr.indexOf || function(elem) {
            for (var i = 0, len = this.length; len > i; i++) if (this[i] === elem) return i;
            return -1;
        }, booleans = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped", whitespace = "[\\x20\\t\\r\\n\\f]", characterEncoding = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+", identifier = characterEncoding.replace("w", "w#"), attributes = "\\[" + whitespace + "*(" + characterEncoding + ")" + whitespace + "*(?:([*^$|!~]?=)" + whitespace + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + identifier + ")|)|)" + whitespace + "*\\]", pseudos = ":(" + characterEncoding + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + attributes.replace(3, 8) + ")*)|.*)\\)|)", rtrim = new RegExp("^" + whitespace + "+|((?:^|[^\\\\])(?:\\\\.)*)" + whitespace + "+$", "g"), rcomma = new RegExp("^" + whitespace + "*," + whitespace + "*"), rcombinators = new RegExp("^" + whitespace + "*([>+~]|" + whitespace + ")" + whitespace + "*"), rsibling = new RegExp(whitespace + "*[+~]"), rattributeQuotes = new RegExp("=" + whitespace + "*([^\\]'\"]*)" + whitespace + "*\\]", "g"), rpseudo = new RegExp(pseudos), ridentifier = new RegExp("^" + identifier + "$"), matchExpr = {
            ID: new RegExp("^#(" + characterEncoding + ")"),
            CLASS: new RegExp("^\\.(" + characterEncoding + ")"),
            TAG: new RegExp("^(" + characterEncoding.replace("w", "w*") + ")"),
            ATTR: new RegExp("^" + attributes),
            PSEUDO: new RegExp("^" + pseudos),
            CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + whitespace + "*(even|odd|(([+-]|)(\\d*)n|)" + whitespace + "*(?:([+-]|)" + whitespace + "*(\\d+)|))" + whitespace + "*\\)|)", "i"),
            bool: new RegExp("^(?:" + booleans + ")$", "i"),
            needsContext: new RegExp("^" + whitespace + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + whitespace + "*((?:-\\d)?\\d*)" + whitespace + "*\\)|)(?=[^-]|$)", "i")
        }, rnative = /^[^{]+\{\s*\[native \w/, rquickExpr = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/, rinputs = /^(?:input|select|textarea|button)$/i, rheader = /^h\d$/i, rescape = /'|\\/g, runescape = new RegExp("\\\\([\\da-f]{1,6}" + whitespace + "?|(" + whitespace + ")|.)", "ig"), funescape = function(_, escaped, escapedWhitespace) {
            var high = "0x" + escaped - 65536;
            return high !== high || escapedWhitespace ? escaped : 0 > high ? String.fromCharCode(high + 65536) : String.fromCharCode(high >> 10 | 55296, 1023 & high | 56320);
        };
        try {
            push.apply(arr = slice.call(preferredDoc.childNodes), preferredDoc.childNodes), 
            arr[preferredDoc.childNodes.length].nodeType;
        } catch (e) {
            push = {
                apply: arr.length ? function(target, els) {
                    push_native.apply(target, slice.call(els));
                } : function(target, els) {
                    for (var j = target.length, i = 0; target[j++] = els[i++]; ) ;
                    target.length = j - 1;
                }
            };
        }
        isXML = Sizzle.isXML = function(elem) {
            var documentElement = elem && (elem.ownerDocument || elem).documentElement;
            return documentElement ? "HTML" !== documentElement.nodeName : !1;
        }, support = Sizzle.support = {}, setDocument = Sizzle.setDocument = function(node) {
            var doc = node ? node.ownerDocument || node : preferredDoc, parent = doc.defaultView;
            return doc !== document && 9 === doc.nodeType && doc.documentElement ? (document = doc, 
            docElem = doc.documentElement, documentIsHTML = !isXML(doc), parent && parent.attachEvent && parent !== parent.top && parent.attachEvent("onbeforeunload", function() {
                setDocument();
            }), support.attributes = assert(function(div) {
                return div.className = "i", !div.getAttribute("className");
            }), support.getElementsByTagName = assert(function(div) {
                return div.appendChild(doc.createComment("")), !div.getElementsByTagName("*").length;
            }), support.getElementsByClassName = assert(function(div) {
                return div.innerHTML = "<div class='a'></div><div class='a i'></div>", div.firstChild.className = "i", 
                2 === div.getElementsByClassName("i").length;
            }), support.getById = assert(function(div) {
                return docElem.appendChild(div).id = expando, !doc.getElementsByName || !doc.getElementsByName(expando).length;
            }), support.getById ? (Expr.find.ID = function(id, context) {
                if (typeof context.getElementById !== strundefined && documentIsHTML) {
                    var m = context.getElementById(id);
                    return m && m.parentNode ? [ m ] : [];
                }
            }, Expr.filter.ID = function(id) {
                var attrId = id.replace(runescape, funescape);
                return function(elem) {
                    return elem.getAttribute("id") === attrId;
                };
            }) : (delete Expr.find.ID, Expr.filter.ID = function(id) {
                var attrId = id.replace(runescape, funescape);
                return function(elem) {
                    var node = typeof elem.getAttributeNode !== strundefined && elem.getAttributeNode("id");
                    return node && node.value === attrId;
                };
            }), Expr.find.TAG = support.getElementsByTagName ? function(tag, context) {
                return typeof context.getElementsByTagName !== strundefined ? context.getElementsByTagName(tag) : void 0;
            } : function(tag, context) {
                var elem, tmp = [], i = 0, results = context.getElementsByTagName(tag);
                if ("*" === tag) {
                    for (;elem = results[i++]; ) 1 === elem.nodeType && tmp.push(elem);
                    return tmp;
                }
                return results;
            }, Expr.find.CLASS = support.getElementsByClassName && function(className, context) {
                return typeof context.getElementsByClassName !== strundefined && documentIsHTML ? context.getElementsByClassName(className) : void 0;
            }, rbuggyMatches = [], rbuggyQSA = [], (support.qsa = rnative.test(doc.querySelectorAll)) && (assert(function(div) {
                div.innerHTML = "<select><option selected=''></option></select>", div.querySelectorAll("[selected]").length || rbuggyQSA.push("\\[" + whitespace + "*(?:value|" + booleans + ")"), 
                div.querySelectorAll(":checked").length || rbuggyQSA.push(":checked");
            }), assert(function(div) {
                var input = doc.createElement("input");
                input.setAttribute("type", "hidden"), div.appendChild(input).setAttribute("t", ""), 
                div.querySelectorAll("[t^='']").length && rbuggyQSA.push("[*^$]=" + whitespace + "*(?:''|\"\")"), 
                div.querySelectorAll(":enabled").length || rbuggyQSA.push(":enabled", ":disabled"), 
                div.querySelectorAll("*,:x"), rbuggyQSA.push(",.*:");
            })), (support.matchesSelector = rnative.test(matches = docElem.webkitMatchesSelector || docElem.mozMatchesSelector || docElem.oMatchesSelector || docElem.msMatchesSelector)) && assert(function(div) {
                support.disconnectedMatch = matches.call(div, "div"), matches.call(div, "[s!='']:x"), 
                rbuggyMatches.push("!=", pseudos);
            }), rbuggyQSA = rbuggyQSA.length && new RegExp(rbuggyQSA.join("|")), rbuggyMatches = rbuggyMatches.length && new RegExp(rbuggyMatches.join("|")), 
            contains = rnative.test(docElem.contains) || docElem.compareDocumentPosition ? function(a, b) {
                var adown = 9 === a.nodeType ? a.documentElement : a, bup = b && b.parentNode;
                return a === bup || !(!bup || 1 !== bup.nodeType || !(adown.contains ? adown.contains(bup) : a.compareDocumentPosition && 16 & a.compareDocumentPosition(bup)));
            } : function(a, b) {
                if (b) for (;b = b.parentNode; ) if (b === a) return !0;
                return !1;
            }, sortOrder = docElem.compareDocumentPosition ? function(a, b) {
                if (a === b) return hasDuplicate = !0, 0;
                var compare = b.compareDocumentPosition && a.compareDocumentPosition && a.compareDocumentPosition(b);
                return compare ? 1 & compare || !support.sortDetached && b.compareDocumentPosition(a) === compare ? a === doc || contains(preferredDoc, a) ? -1 : b === doc || contains(preferredDoc, b) ? 1 : sortInput ? indexOf.call(sortInput, a) - indexOf.call(sortInput, b) : 0 : 4 & compare ? -1 : 1 : a.compareDocumentPosition ? -1 : 1;
            } : function(a, b) {
                var cur, i = 0, aup = a.parentNode, bup = b.parentNode, ap = [ a ], bp = [ b ];
                if (a === b) return hasDuplicate = !0, 0;
                if (!aup || !bup) return a === doc ? -1 : b === doc ? 1 : aup ? -1 : bup ? 1 : sortInput ? indexOf.call(sortInput, a) - indexOf.call(sortInput, b) : 0;
                if (aup === bup) return siblingCheck(a, b);
                for (cur = a; cur = cur.parentNode; ) ap.unshift(cur);
                for (cur = b; cur = cur.parentNode; ) bp.unshift(cur);
                for (;ap[i] === bp[i]; ) i++;
                return i ? siblingCheck(ap[i], bp[i]) : ap[i] === preferredDoc ? -1 : bp[i] === preferredDoc ? 1 : 0;
            }, doc) : document;
        }, Sizzle.matches = function(expr, elements) {
            return Sizzle(expr, null, null, elements);
        }, Sizzle.matchesSelector = function(elem, expr) {
            if ((elem.ownerDocument || elem) !== document && setDocument(elem), expr = expr.replace(rattributeQuotes, "='$1']"), 
            !(!support.matchesSelector || !documentIsHTML || rbuggyMatches && rbuggyMatches.test(expr) || rbuggyQSA && rbuggyQSA.test(expr))) try {
                var ret = matches.call(elem, expr);
                if (ret || support.disconnectedMatch || elem.document && 11 !== elem.document.nodeType) return ret;
            } catch (e) {}
            return Sizzle(expr, document, null, [ elem ]).length > 0;
        }, Sizzle.contains = function(context, elem) {
            return (context.ownerDocument || context) !== document && setDocument(context), 
            contains(context, elem);
        }, Sizzle.attr = function(elem, name) {
            (elem.ownerDocument || elem) !== document && setDocument(elem);
            var fn = Expr.attrHandle[name.toLowerCase()], val = fn && hasOwn.call(Expr.attrHandle, name.toLowerCase()) ? fn(elem, name, !documentIsHTML) : undefined;
            return val === undefined ? support.attributes || !documentIsHTML ? elem.getAttribute(name) : (val = elem.getAttributeNode(name)) && val.specified ? val.value : null : val;
        }, Sizzle.error = function(msg) {
            throw new Error("Syntax error, unrecognized expression: " + msg);
        }, Sizzle.uniqueSort = function(results) {
            var elem, duplicates = [], j = 0, i = 0;
            if (hasDuplicate = !support.detectDuplicates, sortInput = !support.sortStable && results.slice(0), 
            results.sort(sortOrder), hasDuplicate) {
                for (;elem = results[i++]; ) elem === results[i] && (j = duplicates.push(i));
                for (;j--; ) results.splice(duplicates[j], 1);
            }
            return results;
        }, getText = Sizzle.getText = function(elem) {
            var node, ret = "", i = 0, nodeType = elem.nodeType;
            if (nodeType) {
                if (1 === nodeType || 9 === nodeType || 11 === nodeType) {
                    if ("string" == typeof elem.textContent) return elem.textContent;
                    for (elem = elem.firstChild; elem; elem = elem.nextSibling) ret += getText(elem);
                } else if (3 === nodeType || 4 === nodeType) return elem.nodeValue;
            } else for (;node = elem[i]; i++) ret += getText(node);
            return ret;
        }, Expr = Sizzle.selectors = {
            cacheLength: 50,
            createPseudo: markFunction,
            match: matchExpr,
            attrHandle: {},
            find: {},
            relative: {
                ">": {
                    dir: "parentNode",
                    first: !0
                },
                " ": {
                    dir: "parentNode"
                },
                "+": {
                    dir: "previousSibling",
                    first: !0
                },
                "~": {
                    dir: "previousSibling"
                }
            },
            preFilter: {
                ATTR: function(match) {
                    return match[1] = match[1].replace(runescape, funescape), match[3] = (match[4] || match[5] || "").replace(runescape, funescape), 
                    "~=" === match[2] && (match[3] = " " + match[3] + " "), match.slice(0, 4);
                },
                CHILD: function(match) {
                    return match[1] = match[1].toLowerCase(), "nth" === match[1].slice(0, 3) ? (match[3] || Sizzle.error(match[0]), 
                    match[4] = +(match[4] ? match[5] + (match[6] || 1) : 2 * ("even" === match[3] || "odd" === match[3])), 
                    match[5] = +(match[7] + match[8] || "odd" === match[3])) : match[3] && Sizzle.error(match[0]), 
                    match;
                },
                PSEUDO: function(match) {
                    var excess, unquoted = !match[5] && match[2];
                    return matchExpr.CHILD.test(match[0]) ? null : (match[3] && match[4] !== undefined ? match[2] = match[4] : unquoted && rpseudo.test(unquoted) && (excess = tokenize(unquoted, !0)) && (excess = unquoted.indexOf(")", unquoted.length - excess) - unquoted.length) && (match[0] = match[0].slice(0, excess), 
                    match[2] = unquoted.slice(0, excess)), match.slice(0, 3));
                }
            },
            filter: {
                TAG: function(nodeNameSelector) {
                    var nodeName = nodeNameSelector.replace(runescape, funescape).toLowerCase();
                    return "*" === nodeNameSelector ? function() {
                        return !0;
                    } : function(elem) {
                        return elem.nodeName && elem.nodeName.toLowerCase() === nodeName;
                    };
                },
                CLASS: function(className) {
                    var pattern = classCache[className + " "];
                    return pattern || (pattern = new RegExp("(^|" + whitespace + ")" + className + "(" + whitespace + "|$)")) && classCache(className, function(elem) {
                        return pattern.test("string" == typeof elem.className && elem.className || typeof elem.getAttribute !== strundefined && elem.getAttribute("class") || "");
                    });
                },
                ATTR: function(name, operator, check) {
                    return function(elem) {
                        var result = Sizzle.attr(elem, name);
                        return null == result ? "!=" === operator : operator ? (result += "", "=" === operator ? result === check : "!=" === operator ? result !== check : "^=" === operator ? check && 0 === result.indexOf(check) : "*=" === operator ? check && result.indexOf(check) > -1 : "$=" === operator ? check && result.slice(-check.length) === check : "~=" === operator ? (" " + result + " ").indexOf(check) > -1 : "|=" === operator ? result === check || result.slice(0, check.length + 1) === check + "-" : !1) : !0;
                    };
                },
                CHILD: function(type, what, argument, first, last) {
                    var simple = "nth" !== type.slice(0, 3), forward = "last" !== type.slice(-4), ofType = "of-type" === what;
                    return 1 === first && 0 === last ? function(elem) {
                        return !!elem.parentNode;
                    } : function(elem, context, xml) {
                        var cache, outerCache, node, diff, nodeIndex, start, dir = simple !== forward ? "nextSibling" : "previousSibling", parent = elem.parentNode, name = ofType && elem.nodeName.toLowerCase(), useCache = !xml && !ofType;
                        if (parent) {
                            if (simple) {
                                for (;dir; ) {
                                    for (node = elem; node = node[dir]; ) if (ofType ? node.nodeName.toLowerCase() === name : 1 === node.nodeType) return !1;
                                    start = dir = "only" === type && !start && "nextSibling";
                                }
                                return !0;
                            }
                            if (start = [ forward ? parent.firstChild : parent.lastChild ], forward && useCache) {
                                for (outerCache = parent[expando] || (parent[expando] = {}), cache = outerCache[type] || [], 
                                nodeIndex = cache[0] === dirruns && cache[1], diff = cache[0] === dirruns && cache[2], 
                                node = nodeIndex && parent.childNodes[nodeIndex]; node = ++nodeIndex && node && node[dir] || (diff = nodeIndex = 0) || start.pop(); ) if (1 === node.nodeType && ++diff && node === elem) {
                                    outerCache[type] = [ dirruns, nodeIndex, diff ];
                                    break;
                                }
                            } else if (useCache && (cache = (elem[expando] || (elem[expando] = {}))[type]) && cache[0] === dirruns) diff = cache[1]; else for (;(node = ++nodeIndex && node && node[dir] || (diff = nodeIndex = 0) || start.pop()) && ((ofType ? node.nodeName.toLowerCase() !== name : 1 !== node.nodeType) || !++diff || (useCache && ((node[expando] || (node[expando] = {}))[type] = [ dirruns, diff ]), 
                            node !== elem)); ) ;
                            return diff -= last, diff === first || diff % first === 0 && diff / first >= 0;
                        }
                    };
                },
                PSEUDO: function(pseudo, argument) {
                    var args, fn = Expr.pseudos[pseudo] || Expr.setFilters[pseudo.toLowerCase()] || Sizzle.error("unsupported pseudo: " + pseudo);
                    return fn[expando] ? fn(argument) : fn.length > 1 ? (args = [ pseudo, pseudo, "", argument ], 
                    Expr.setFilters.hasOwnProperty(pseudo.toLowerCase()) ? markFunction(function(seed, matches) {
                        for (var idx, matched = fn(seed, argument), i = matched.length; i--; ) idx = indexOf.call(seed, matched[i]), 
                        seed[idx] = !(matches[idx] = matched[i]);
                    }) : function(elem) {
                        return fn(elem, 0, args);
                    }) : fn;
                }
            },
            pseudos: {
                not: markFunction(function(selector) {
                    var input = [], results = [], matcher = compile(selector.replace(rtrim, "$1"));
                    return matcher[expando] ? markFunction(function(seed, matches, context, xml) {
                        for (var elem, unmatched = matcher(seed, null, xml, []), i = seed.length; i--; ) (elem = unmatched[i]) && (seed[i] = !(matches[i] = elem));
                    }) : function(elem, context, xml) {
                        return input[0] = elem, matcher(input, null, xml, results), !results.pop();
                    };
                }),
                has: markFunction(function(selector) {
                    return function(elem) {
                        return Sizzle(selector, elem).length > 0;
                    };
                }),
                contains: markFunction(function(text) {
                    return function(elem) {
                        return (elem.textContent || elem.innerText || getText(elem)).indexOf(text) > -1;
                    };
                }),
                lang: markFunction(function(lang) {
                    return ridentifier.test(lang || "") || Sizzle.error("unsupported lang: " + lang), 
                    lang = lang.replace(runescape, funescape).toLowerCase(), function(elem) {
                        var elemLang;
                        do if (elemLang = documentIsHTML ? elem.lang : elem.getAttribute("xml:lang") || elem.getAttribute("lang")) return elemLang = elemLang.toLowerCase(), 
                        elemLang === lang || 0 === elemLang.indexOf(lang + "-"); while ((elem = elem.parentNode) && 1 === elem.nodeType);
                        return !1;
                    };
                }),
                target: function(elem) {
                    var hash = window.location && window.location.hash;
                    return hash && hash.slice(1) === elem.id;
                },
                root: function(elem) {
                    return elem === docElem;
                },
                focus: function(elem) {
                    return elem === document.activeElement && (!document.hasFocus || document.hasFocus()) && !!(elem.type || elem.href || ~elem.tabIndex);
                },
                enabled: function(elem) {
                    return elem.disabled === !1;
                },
                disabled: function(elem) {
                    return elem.disabled === !0;
                },
                checked: function(elem) {
                    var nodeName = elem.nodeName.toLowerCase();
                    return "input" === nodeName && !!elem.checked || "option" === nodeName && !!elem.selected;
                },
                selected: function(elem) {
                    return elem.parentNode && elem.parentNode.selectedIndex, elem.selected === !0;
                },
                empty: function(elem) {
                    for (elem = elem.firstChild; elem; elem = elem.nextSibling) if (elem.nodeName > "@" || 3 === elem.nodeType || 4 === elem.nodeType) return !1;
                    return !0;
                },
                parent: function(elem) {
                    return !Expr.pseudos.empty(elem);
                },
                header: function(elem) {
                    return rheader.test(elem.nodeName);
                },
                input: function(elem) {
                    return rinputs.test(elem.nodeName);
                },
                button: function(elem) {
                    var name = elem.nodeName.toLowerCase();
                    return "input" === name && "button" === elem.type || "button" === name;
                },
                text: function(elem) {
                    var attr;
                    return "input" === elem.nodeName.toLowerCase() && "text" === elem.type && (null == (attr = elem.getAttribute("type")) || attr.toLowerCase() === elem.type);
                },
                first: createPositionalPseudo(function() {
                    return [ 0 ];
                }),
                last: createPositionalPseudo(function(matchIndexes, length) {
                    return [ length - 1 ];
                }),
                eq: createPositionalPseudo(function(matchIndexes, length, argument) {
                    return [ 0 > argument ? argument + length : argument ];
                }),
                even: createPositionalPseudo(function(matchIndexes, length) {
                    for (var i = 0; length > i; i += 2) matchIndexes.push(i);
                    return matchIndexes;
                }),
                odd: createPositionalPseudo(function(matchIndexes, length) {
                    for (var i = 1; length > i; i += 2) matchIndexes.push(i);
                    return matchIndexes;
                }),
                lt: createPositionalPseudo(function(matchIndexes, length, argument) {
                    for (var i = 0 > argument ? argument + length : argument; --i >= 0; ) matchIndexes.push(i);
                    return matchIndexes;
                }),
                gt: createPositionalPseudo(function(matchIndexes, length, argument) {
                    for (var i = 0 > argument ? argument + length : argument; ++i < length; ) matchIndexes.push(i);
                    return matchIndexes;
                })
            }
        }, Expr.pseudos.nth = Expr.pseudos.eq;
        for (i in {
            radio: !0,
            checkbox: !0,
            file: !0,
            password: !0,
            image: !0
        }) Expr.pseudos[i] = createInputPseudo(i);
        for (i in {
            submit: !0,
            reset: !0
        }) Expr.pseudos[i] = createButtonPseudo(i);
        setFilters.prototype = Expr.filters = Expr.pseudos, Expr.setFilters = new setFilters(), 
        compile = Sizzle.compile = function(selector, group) {
            var i, setMatchers = [], elementMatchers = [], cached = compilerCache[selector + " "];
            if (!cached) {
                for (group || (group = tokenize(selector)), i = group.length; i--; ) cached = matcherFromTokens(group[i]), 
                cached[expando] ? setMatchers.push(cached) : elementMatchers.push(cached);
                cached = compilerCache(selector, matcherFromGroupMatchers(elementMatchers, setMatchers));
            }
            return cached;
        }, support.sortStable = expando.split("").sort(sortOrder).join("") === expando, 
        support.detectDuplicates = hasDuplicate, setDocument(), support.sortDetached = assert(function(div1) {
            return 1 & div1.compareDocumentPosition(document.createElement("div"));
        }), assert(function(div) {
            return div.innerHTML = "<a href='#'></a>", "#" === div.firstChild.getAttribute("href");
        }) || addHandle("type|href|height|width", function(elem, name, isXML) {
            return isXML ? void 0 : elem.getAttribute(name, "type" === name.toLowerCase() ? 1 : 2);
        }), support.attributes && assert(function(div) {
            return div.innerHTML = "<input/>", div.firstChild.setAttribute("value", ""), "" === div.firstChild.getAttribute("value");
        }) || addHandle("value", function(elem, name, isXML) {
            return isXML || "input" !== elem.nodeName.toLowerCase() ? void 0 : elem.defaultValue;
        }), assert(function(div) {
            return null == div.getAttribute("disabled");
        }) || addHandle(booleans, function(elem, name, isXML) {
            var val;
            return isXML ? void 0 : (val = elem.getAttributeNode(name)) && val.specified ? val.value : elem[name] === !0 ? name.toLowerCase() : null;
        }), jQuery.find = Sizzle, jQuery.expr = Sizzle.selectors, jQuery.expr[":"] = jQuery.expr.pseudos, 
        jQuery.unique = Sizzle.uniqueSort, jQuery.text = Sizzle.getText, jQuery.isXMLDoc = Sizzle.isXML, 
        jQuery.contains = Sizzle.contains;
    }(window);
    var optionsCache = {};
    jQuery.Callbacks = function(options) {
        options = "string" == typeof options ? optionsCache[options] || createOptions(options) : jQuery.extend({}, options);
        var firing, memory, fired, firingLength, firingIndex, firingStart, list = [], stack = !options.once && [], fire = function(data) {
            for (memory = options.memory && data, fired = !0, firingIndex = firingStart || 0, 
            firingStart = 0, firingLength = list.length, firing = !0; list && firingLength > firingIndex; firingIndex++) if (list[firingIndex].apply(data[0], data[1]) === !1 && options.stopOnFalse) {
                memory = !1;
                break;
            }
            firing = !1, list && (stack ? stack.length && fire(stack.shift()) : memory ? list = [] : self.disable());
        }, self = {
            add: function() {
                if (list) {
                    var start = list.length;
                    !function add(args) {
                        jQuery.each(args, function(_, arg) {
                            var type = jQuery.type(arg);
                            "function" === type ? options.unique && self.has(arg) || list.push(arg) : arg && arg.length && "string" !== type && add(arg);
                        });
                    }(arguments), firing ? firingLength = list.length : memory && (firingStart = start, 
                    fire(memory));
                }
                return this;
            },
            remove: function() {
                return list && jQuery.each(arguments, function(_, arg) {
                    for (var index; (index = jQuery.inArray(arg, list, index)) > -1; ) list.splice(index, 1), 
                    firing && (firingLength >= index && firingLength--, firingIndex >= index && firingIndex--);
                }), this;
            },
            has: function(fn) {
                return fn ? jQuery.inArray(fn, list) > -1 : !(!list || !list.length);
            },
            empty: function() {
                return list = [], firingLength = 0, this;
            },
            disable: function() {
                return list = stack = memory = undefined, this;
            },
            disabled: function() {
                return !list;
            },
            lock: function() {
                return stack = undefined, memory || self.disable(), this;
            },
            locked: function() {
                return !stack;
            },
            fireWith: function(context, args) {
                return !list || fired && !stack || (args = args || [], args = [ context, args.slice ? args.slice() : args ], 
                firing ? stack.push(args) : fire(args)), this;
            },
            fire: function() {
                return self.fireWith(this, arguments), this;
            },
            fired: function() {
                return !!fired;
            }
        };
        return self;
    }, jQuery.extend({
        Deferred: function(func) {
            var tuples = [ [ "resolve", "done", jQuery.Callbacks("once memory"), "resolved" ], [ "reject", "fail", jQuery.Callbacks("once memory"), "rejected" ], [ "notify", "progress", jQuery.Callbacks("memory") ] ], state = "pending", promise = {
                state: function() {
                    return state;
                },
                always: function() {
                    return deferred.done(arguments).fail(arguments), this;
                },
                then: function() {
                    var fns = arguments;
                    return jQuery.Deferred(function(newDefer) {
                        jQuery.each(tuples, function(i, tuple) {
                            var action = tuple[0], fn = jQuery.isFunction(fns[i]) && fns[i];
                            deferred[tuple[1]](function() {
                                var returned = fn && fn.apply(this, arguments);
                                returned && jQuery.isFunction(returned.promise) ? returned.promise().done(newDefer.resolve).fail(newDefer.reject).progress(newDefer.notify) : newDefer[action + "With"](this === promise ? newDefer.promise() : this, fn ? [ returned ] : arguments);
                            });
                        }), fns = null;
                    }).promise();
                },
                promise: function(obj) {
                    return null != obj ? jQuery.extend(obj, promise) : promise;
                }
            }, deferred = {};
            return promise.pipe = promise.then, jQuery.each(tuples, function(i, tuple) {
                var list = tuple[2], stateString = tuple[3];
                promise[tuple[1]] = list.add, stateString && list.add(function() {
                    state = stateString;
                }, tuples[1 ^ i][2].disable, tuples[2][2].lock), deferred[tuple[0]] = function() {
                    return deferred[tuple[0] + "With"](this === deferred ? promise : this, arguments), 
                    this;
                }, deferred[tuple[0] + "With"] = list.fireWith;
            }), promise.promise(deferred), func && func.call(deferred, deferred), deferred;
        },
        when: function(subordinate) {
            var progressValues, progressContexts, resolveContexts, i = 0, resolveValues = core_slice.call(arguments), length = resolveValues.length, remaining = 1 !== length || subordinate && jQuery.isFunction(subordinate.promise) ? length : 0, deferred = 1 === remaining ? subordinate : jQuery.Deferred(), updateFunc = function(i, contexts, values) {
                return function(value) {
                    contexts[i] = this, values[i] = arguments.length > 1 ? core_slice.call(arguments) : value, 
                    values === progressValues ? deferred.notifyWith(contexts, values) : --remaining || deferred.resolveWith(contexts, values);
                };
            };
            if (length > 1) for (progressValues = new Array(length), progressContexts = new Array(length), 
            resolveContexts = new Array(length); length > i; i++) resolveValues[i] && jQuery.isFunction(resolveValues[i].promise) ? resolveValues[i].promise().done(updateFunc(i, resolveContexts, resolveValues)).fail(deferred.reject).progress(updateFunc(i, progressContexts, progressValues)) : --remaining;
            return remaining || deferred.resolveWith(resolveContexts, resolveValues), deferred.promise();
        }
    }), jQuery.support = function(support) {
        var all, a, input, select, fragment, opt, eventName, isSupported, i, div = document.createElement("div");
        if (div.setAttribute("className", "t"), div.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", 
        all = div.getElementsByTagName("*") || [], a = div.getElementsByTagName("a")[0], 
        !a || !a.style || !all.length) return support;
        select = document.createElement("select"), opt = select.appendChild(document.createElement("option")), 
        input = div.getElementsByTagName("input")[0], a.style.cssText = "top:1px;float:left;opacity:.5", 
        support.getSetAttribute = "t" !== div.className, support.leadingWhitespace = 3 === div.firstChild.nodeType, 
        support.tbody = !div.getElementsByTagName("tbody").length, support.htmlSerialize = !!div.getElementsByTagName("link").length, 
        support.style = /top/.test(a.getAttribute("style")), support.hrefNormalized = "/a" === a.getAttribute("href"), 
        support.opacity = /^0.5/.test(a.style.opacity), support.cssFloat = !!a.style.cssFloat, 
        support.checkOn = !!input.value, support.optSelected = opt.selected, support.enctype = !!document.createElement("form").enctype, 
        support.html5Clone = "<:nav></:nav>" !== document.createElement("nav").cloneNode(!0).outerHTML, 
        support.inlineBlockNeedsLayout = !1, support.shrinkWrapBlocks = !1, support.pixelPosition = !1, 
        support.deleteExpando = !0, support.noCloneEvent = !0, support.reliableMarginRight = !0, 
        support.boxSizingReliable = !0, input.checked = !0, support.noCloneChecked = input.cloneNode(!0).checked, 
        select.disabled = !0, support.optDisabled = !opt.disabled;
        try {
            delete div.test;
        } catch (e) {
            support.deleteExpando = !1;
        }
        input = document.createElement("input"), input.setAttribute("value", ""), support.input = "" === input.getAttribute("value"), 
        input.value = "t", input.setAttribute("type", "radio"), support.radioValue = "t" === input.value, 
        input.setAttribute("checked", "t"), input.setAttribute("name", "t"), fragment = document.createDocumentFragment(), 
        fragment.appendChild(input), support.appendChecked = input.checked, support.checkClone = fragment.cloneNode(!0).cloneNode(!0).lastChild.checked, 
        div.attachEvent && (div.attachEvent("onclick", function() {
            support.noCloneEvent = !1;
        }), div.cloneNode(!0).click());
        for (i in {
            submit: !0,
            change: !0,
            focusin: !0
        }) div.setAttribute(eventName = "on" + i, "t"), support[i + "Bubbles"] = eventName in window || div.attributes[eventName].expando === !1;
        div.style.backgroundClip = "content-box", div.cloneNode(!0).style.backgroundClip = "", 
        support.clearCloneStyle = "content-box" === div.style.backgroundClip;
        for (i in jQuery(support)) break;
        return support.ownLast = "0" !== i, jQuery(function() {
            var container, marginDiv, tds, divReset = "padding:0;margin:0;border:0;display:block;box-sizing:content-box;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;", body = document.getElementsByTagName("body")[0];
            body && (container = document.createElement("div"), container.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px", 
            body.appendChild(container).appendChild(div), div.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", 
            tds = div.getElementsByTagName("td"), tds[0].style.cssText = "padding:0;margin:0;border:0;display:none", 
            isSupported = 0 === tds[0].offsetHeight, tds[0].style.display = "", tds[1].style.display = "none", 
            support.reliableHiddenOffsets = isSupported && 0 === tds[0].offsetHeight, div.innerHTML = "", 
            div.style.cssText = "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;", 
            jQuery.swap(body, null != body.style.zoom ? {
                zoom: 1
            } : {}, function() {
                support.boxSizing = 4 === div.offsetWidth;
            }), window.getComputedStyle && (support.pixelPosition = "1%" !== (window.getComputedStyle(div, null) || {}).top, 
            support.boxSizingReliable = "4px" === (window.getComputedStyle(div, null) || {
                width: "4px"
            }).width, marginDiv = div.appendChild(document.createElement("div")), marginDiv.style.cssText = div.style.cssText = divReset, 
            marginDiv.style.marginRight = marginDiv.style.width = "0", div.style.width = "1px", 
            support.reliableMarginRight = !parseFloat((window.getComputedStyle(marginDiv, null) || {}).marginRight)), 
            typeof div.style.zoom !== core_strundefined && (div.innerHTML = "", div.style.cssText = divReset + "width:1px;padding:1px;display:inline;zoom:1", 
            support.inlineBlockNeedsLayout = 3 === div.offsetWidth, div.style.display = "block", 
            div.innerHTML = "<div></div>", div.firstChild.style.width = "5px", support.shrinkWrapBlocks = 3 !== div.offsetWidth, 
            support.inlineBlockNeedsLayout && (body.style.zoom = 1)), body.removeChild(container), 
            container = div = tds = marginDiv = null);
        }), all = select = fragment = opt = a = input = null, support;
    }({});
    var rbrace = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/, rmultiDash = /([A-Z])/g;
    jQuery.extend({
        cache: {},
        noData: {
            applet: !0,
            embed: !0,
            object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
        },
        hasData: function(elem) {
            return elem = elem.nodeType ? jQuery.cache[elem[jQuery.expando]] : elem[jQuery.expando], 
            !!elem && !isEmptyDataObject(elem);
        },
        data: function(elem, name, data) {
            return internalData(elem, name, data);
        },
        removeData: function(elem, name) {
            return internalRemoveData(elem, name);
        },
        _data: function(elem, name, data) {
            return internalData(elem, name, data, !0);
        },
        _removeData: function(elem, name) {
            return internalRemoveData(elem, name, !0);
        },
        acceptData: function(elem) {
            if (elem.nodeType && 1 !== elem.nodeType && 9 !== elem.nodeType) return !1;
            var noData = elem.nodeName && jQuery.noData[elem.nodeName.toLowerCase()];
            return !noData || noData !== !0 && elem.getAttribute("classid") === noData;
        }
    }), jQuery.fn.extend({
        data: function(key, value) {
            var attrs, name, data = null, i = 0, elem = this[0];
            if (key === undefined) {
                if (this.length && (data = jQuery.data(elem), 1 === elem.nodeType && !jQuery._data(elem, "parsedAttrs"))) {
                    for (attrs = elem.attributes; i < attrs.length; i++) name = attrs[i].name, 0 === name.indexOf("data-") && (name = jQuery.camelCase(name.slice(5)), 
                    dataAttr(elem, name, data[name]));
                    jQuery._data(elem, "parsedAttrs", !0);
                }
                return data;
            }
            return "object" == typeof key ? this.each(function() {
                jQuery.data(this, key);
            }) : arguments.length > 1 ? this.each(function() {
                jQuery.data(this, key, value);
            }) : elem ? dataAttr(elem, key, jQuery.data(elem, key)) : null;
        },
        removeData: function(key) {
            return this.each(function() {
                jQuery.removeData(this, key);
            });
        }
    }), jQuery.extend({
        queue: function(elem, type, data) {
            var queue;
            return elem ? (type = (type || "fx") + "queue", queue = jQuery._data(elem, type), 
            data && (!queue || jQuery.isArray(data) ? queue = jQuery._data(elem, type, jQuery.makeArray(data)) : queue.push(data)), 
            queue || []) : void 0;
        },
        dequeue: function(elem, type) {
            type = type || "fx";
            var queue = jQuery.queue(elem, type), startLength = queue.length, fn = queue.shift(), hooks = jQuery._queueHooks(elem, type), next = function() {
                jQuery.dequeue(elem, type);
            };
            "inprogress" === fn && (fn = queue.shift(), startLength--), fn && ("fx" === type && queue.unshift("inprogress"), 
            delete hooks.stop, fn.call(elem, next, hooks)), !startLength && hooks && hooks.empty.fire();
        },
        _queueHooks: function(elem, type) {
            var key = type + "queueHooks";
            return jQuery._data(elem, key) || jQuery._data(elem, key, {
                empty: jQuery.Callbacks("once memory").add(function() {
                    jQuery._removeData(elem, type + "queue"), jQuery._removeData(elem, key);
                })
            });
        }
    }), jQuery.fn.extend({
        queue: function(type, data) {
            var setter = 2;
            return "string" != typeof type && (data = type, type = "fx", setter--), arguments.length < setter ? jQuery.queue(this[0], type) : data === undefined ? this : this.each(function() {
                var queue = jQuery.queue(this, type, data);
                jQuery._queueHooks(this, type), "fx" === type && "inprogress" !== queue[0] && jQuery.dequeue(this, type);
            });
        },
        dequeue: function(type) {
            return this.each(function() {
                jQuery.dequeue(this, type);
            });
        },
        delay: function(time, type) {
            return time = jQuery.fx ? jQuery.fx.speeds[time] || time : time, type = type || "fx", 
            this.queue(type, function(next, hooks) {
                var timeout = setTimeout(next, time);
                hooks.stop = function() {
                    clearTimeout(timeout);
                };
            });
        },
        clearQueue: function(type) {
            return this.queue(type || "fx", []);
        },
        promise: function(type, obj) {
            var tmp, count = 1, defer = jQuery.Deferred(), elements = this, i = this.length, resolve = function() {
                --count || defer.resolveWith(elements, [ elements ]);
            };
            for ("string" != typeof type && (obj = type, type = undefined), type = type || "fx"; i--; ) tmp = jQuery._data(elements[i], type + "queueHooks"), 
            tmp && tmp.empty && (count++, tmp.empty.add(resolve));
            return resolve(), defer.promise(obj);
        }
    });
    var nodeHook, boolHook, rclass = /[\t\r\n\f]/g, rreturn = /\r/g, rfocusable = /^(?:input|select|textarea|button|object)$/i, rclickable = /^(?:a|area)$/i, ruseDefault = /^(?:checked|selected)$/i, getSetAttribute = jQuery.support.getSetAttribute, getSetInput = jQuery.support.input;
    jQuery.fn.extend({
        attr: function(name, value) {
            return jQuery.access(this, jQuery.attr, name, value, arguments.length > 1);
        },
        removeAttr: function(name) {
            return this.each(function() {
                jQuery.removeAttr(this, name);
            });
        },
        prop: function(name, value) {
            return jQuery.access(this, jQuery.prop, name, value, arguments.length > 1);
        },
        removeProp: function(name) {
            return name = jQuery.propFix[name] || name, this.each(function() {
                try {
                    this[name] = undefined, delete this[name];
                } catch (e) {}
            });
        },
        addClass: function(value) {
            var classes, elem, cur, clazz, j, i = 0, len = this.length, proceed = "string" == typeof value && value;
            if (jQuery.isFunction(value)) return this.each(function(j) {
                jQuery(this).addClass(value.call(this, j, this.className));
            });
            if (proceed) for (classes = (value || "").match(core_rnotwhite) || []; len > i; i++) if (elem = this[i], 
            cur = 1 === elem.nodeType && (elem.className ? (" " + elem.className + " ").replace(rclass, " ") : " ")) {
                for (j = 0; clazz = classes[j++]; ) cur.indexOf(" " + clazz + " ") < 0 && (cur += clazz + " ");
                elem.className = jQuery.trim(cur);
            }
            return this;
        },
        removeClass: function(value) {
            var classes, elem, cur, clazz, j, i = 0, len = this.length, proceed = 0 === arguments.length || "string" == typeof value && value;
            if (jQuery.isFunction(value)) return this.each(function(j) {
                jQuery(this).removeClass(value.call(this, j, this.className));
            });
            if (proceed) for (classes = (value || "").match(core_rnotwhite) || []; len > i; i++) if (elem = this[i], 
            cur = 1 === elem.nodeType && (elem.className ? (" " + elem.className + " ").replace(rclass, " ") : "")) {
                for (j = 0; clazz = classes[j++]; ) for (;cur.indexOf(" " + clazz + " ") >= 0; ) cur = cur.replace(" " + clazz + " ", " ");
                elem.className = value ? jQuery.trim(cur) : "";
            }
            return this;
        },
        toggleClass: function(value, stateVal) {
            var type = typeof value;
            return "boolean" == typeof stateVal && "string" === type ? stateVal ? this.addClass(value) : this.removeClass(value) : this.each(jQuery.isFunction(value) ? function(i) {
                jQuery(this).toggleClass(value.call(this, i, this.className, stateVal), stateVal);
            } : function() {
                if ("string" === type) for (var className, i = 0, self = jQuery(this), classNames = value.match(core_rnotwhite) || []; className = classNames[i++]; ) self.hasClass(className) ? self.removeClass(className) : self.addClass(className); else (type === core_strundefined || "boolean" === type) && (this.className && jQuery._data(this, "__className__", this.className), 
                this.className = this.className || value === !1 ? "" : jQuery._data(this, "__className__") || "");
            });
        },
        hasClass: function(selector) {
            for (var className = " " + selector + " ", i = 0, l = this.length; l > i; i++) if (1 === this[i].nodeType && (" " + this[i].className + " ").replace(rclass, " ").indexOf(className) >= 0) return !0;
            return !1;
        },
        val: function(value) {
            var ret, hooks, isFunction, elem = this[0];
            {
                if (arguments.length) return isFunction = jQuery.isFunction(value), this.each(function(i) {
                    var val;
                    1 === this.nodeType && (val = isFunction ? value.call(this, i, jQuery(this).val()) : value, 
                    null == val ? val = "" : "number" == typeof val ? val += "" : jQuery.isArray(val) && (val = jQuery.map(val, function(value) {
                        return null == value ? "" : value + "";
                    })), hooks = jQuery.valHooks[this.type] || jQuery.valHooks[this.nodeName.toLowerCase()], 
                    hooks && "set" in hooks && hooks.set(this, val, "value") !== undefined || (this.value = val));
                });
                if (elem) return hooks = jQuery.valHooks[elem.type] || jQuery.valHooks[elem.nodeName.toLowerCase()], 
                hooks && "get" in hooks && (ret = hooks.get(elem, "value")) !== undefined ? ret : (ret = elem.value, 
                "string" == typeof ret ? ret.replace(rreturn, "") : null == ret ? "" : ret);
            }
        }
    }), jQuery.extend({
        valHooks: {
            option: {
                get: function(elem) {
                    var val = jQuery.find.attr(elem, "value");
                    return null != val ? val : elem.text;
                }
            },
            select: {
                get: function(elem) {
                    for (var value, option, options = elem.options, index = elem.selectedIndex, one = "select-one" === elem.type || 0 > index, values = one ? null : [], max = one ? index + 1 : options.length, i = 0 > index ? max : one ? index : 0; max > i; i++) if (option = options[i], 
                    !(!option.selected && i !== index || (jQuery.support.optDisabled ? option.disabled : null !== option.getAttribute("disabled")) || option.parentNode.disabled && jQuery.nodeName(option.parentNode, "optgroup"))) {
                        if (value = jQuery(option).val(), one) return value;
                        values.push(value);
                    }
                    return values;
                },
                set: function(elem, value) {
                    for (var optionSet, option, options = elem.options, values = jQuery.makeArray(value), i = options.length; i--; ) option = options[i], 
                    (option.selected = jQuery.inArray(jQuery(option).val(), values) >= 0) && (optionSet = !0);
                    return optionSet || (elem.selectedIndex = -1), values;
                }
            }
        },
        attr: function(elem, name, value) {
            var hooks, ret, nType = elem.nodeType;
            if (elem && 3 !== nType && 8 !== nType && 2 !== nType) return typeof elem.getAttribute === core_strundefined ? jQuery.prop(elem, name, value) : (1 === nType && jQuery.isXMLDoc(elem) || (name = name.toLowerCase(), 
            hooks = jQuery.attrHooks[name] || (jQuery.expr.match.bool.test(name) ? boolHook : nodeHook)), 
            value === undefined ? hooks && "get" in hooks && null !== (ret = hooks.get(elem, name)) ? ret : (ret = jQuery.find.attr(elem, name), 
            null == ret ? undefined : ret) : null !== value ? hooks && "set" in hooks && (ret = hooks.set(elem, value, name)) !== undefined ? ret : (elem.setAttribute(name, value + ""), 
            value) : void jQuery.removeAttr(elem, name));
        },
        removeAttr: function(elem, value) {
            var name, propName, i = 0, attrNames = value && value.match(core_rnotwhite);
            if (attrNames && 1 === elem.nodeType) for (;name = attrNames[i++]; ) propName = jQuery.propFix[name] || name, 
            jQuery.expr.match.bool.test(name) ? getSetInput && getSetAttribute || !ruseDefault.test(name) ? elem[propName] = !1 : elem[jQuery.camelCase("default-" + name)] = elem[propName] = !1 : jQuery.attr(elem, name, ""), 
            elem.removeAttribute(getSetAttribute ? name : propName);
        },
        attrHooks: {
            type: {
                set: function(elem, value) {
                    if (!jQuery.support.radioValue && "radio" === value && jQuery.nodeName(elem, "input")) {
                        var val = elem.value;
                        return elem.setAttribute("type", value), val && (elem.value = val), value;
                    }
                }
            }
        },
        propFix: {
            "for": "htmlFor",
            "class": "className"
        },
        prop: function(elem, name, value) {
            var ret, hooks, notxml, nType = elem.nodeType;
            if (elem && 3 !== nType && 8 !== nType && 2 !== nType) return notxml = 1 !== nType || !jQuery.isXMLDoc(elem), 
            notxml && (name = jQuery.propFix[name] || name, hooks = jQuery.propHooks[name]), 
            value !== undefined ? hooks && "set" in hooks && (ret = hooks.set(elem, value, name)) !== undefined ? ret : elem[name] = value : hooks && "get" in hooks && null !== (ret = hooks.get(elem, name)) ? ret : elem[name];
        },
        propHooks: {
            tabIndex: {
                get: function(elem) {
                    var tabindex = jQuery.find.attr(elem, "tabindex");
                    return tabindex ? parseInt(tabindex, 10) : rfocusable.test(elem.nodeName) || rclickable.test(elem.nodeName) && elem.href ? 0 : -1;
                }
            }
        }
    }), boolHook = {
        set: function(elem, value, name) {
            return value === !1 ? jQuery.removeAttr(elem, name) : getSetInput && getSetAttribute || !ruseDefault.test(name) ? elem.setAttribute(!getSetAttribute && jQuery.propFix[name] || name, name) : elem[jQuery.camelCase("default-" + name)] = elem[name] = !0, 
            name;
        }
    }, jQuery.each(jQuery.expr.match.bool.source.match(/\w+/g), function(i, name) {
        var getter = jQuery.expr.attrHandle[name] || jQuery.find.attr;
        jQuery.expr.attrHandle[name] = getSetInput && getSetAttribute || !ruseDefault.test(name) ? function(elem, name, isXML) {
            var fn = jQuery.expr.attrHandle[name], ret = isXML ? undefined : (jQuery.expr.attrHandle[name] = undefined) != getter(elem, name, isXML) ? name.toLowerCase() : null;
            return jQuery.expr.attrHandle[name] = fn, ret;
        } : function(elem, name, isXML) {
            return isXML ? undefined : elem[jQuery.camelCase("default-" + name)] ? name.toLowerCase() : null;
        };
    }), getSetInput && getSetAttribute || (jQuery.attrHooks.value = {
        set: function(elem, value, name) {
            return jQuery.nodeName(elem, "input") ? void (elem.defaultValue = value) : nodeHook && nodeHook.set(elem, value, name);
        }
    }), getSetAttribute || (nodeHook = {
        set: function(elem, value, name) {
            var ret = elem.getAttributeNode(name);
            return ret || elem.setAttributeNode(ret = elem.ownerDocument.createAttribute(name)), 
            ret.value = value += "", "value" === name || value === elem.getAttribute(name) ? value : undefined;
        }
    }, jQuery.expr.attrHandle.id = jQuery.expr.attrHandle.name = jQuery.expr.attrHandle.coords = function(elem, name, isXML) {
        var ret;
        return isXML ? undefined : (ret = elem.getAttributeNode(name)) && "" !== ret.value ? ret.value : null;
    }, jQuery.valHooks.button = {
        get: function(elem, name) {
            var ret = elem.getAttributeNode(name);
            return ret && ret.specified ? ret.value : undefined;
        },
        set: nodeHook.set
    }, jQuery.attrHooks.contenteditable = {
        set: function(elem, value, name) {
            nodeHook.set(elem, "" === value ? !1 : value, name);
        }
    }, jQuery.each([ "width", "height" ], function(i, name) {
        jQuery.attrHooks[name] = {
            set: function(elem, value) {
                return "" === value ? (elem.setAttribute(name, "auto"), value) : void 0;
            }
        };
    })), jQuery.support.hrefNormalized || jQuery.each([ "href", "src" ], function(i, name) {
        jQuery.propHooks[name] = {
            get: function(elem) {
                return elem.getAttribute(name, 4);
            }
        };
    }), jQuery.support.style || (jQuery.attrHooks.style = {
        get: function(elem) {
            return elem.style.cssText || undefined;
        },
        set: function(elem, value) {
            return elem.style.cssText = value + "";
        }
    }), jQuery.support.optSelected || (jQuery.propHooks.selected = {
        get: function(elem) {
            var parent = elem.parentNode;
            return parent && (parent.selectedIndex, parent.parentNode && parent.parentNode.selectedIndex), 
            null;
        }
    }), jQuery.each([ "tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable" ], function() {
        jQuery.propFix[this.toLowerCase()] = this;
    }), jQuery.support.enctype || (jQuery.propFix.enctype = "encoding"), jQuery.each([ "radio", "checkbox" ], function() {
        jQuery.valHooks[this] = {
            set: function(elem, value) {
                return jQuery.isArray(value) ? elem.checked = jQuery.inArray(jQuery(elem).val(), value) >= 0 : void 0;
            }
        }, jQuery.support.checkOn || (jQuery.valHooks[this].get = function(elem) {
            return null === elem.getAttribute("value") ? "on" : elem.value;
        });
    });
    var rformElems = /^(?:input|select|textarea)$/i, rkeyEvent = /^key/, rmouseEvent = /^(?:mouse|contextmenu)|click/, rfocusMorph = /^(?:focusinfocus|focusoutblur)$/, rtypenamespace = /^([^.]*)(?:\.(.+)|)$/;
    jQuery.event = {
        global: {},
        add: function(elem, types, handler, data, selector) {
            var tmp, events, t, handleObjIn, special, eventHandle, handleObj, handlers, type, namespaces, origType, elemData = jQuery._data(elem);
            if (elemData) {
                for (handler.handler && (handleObjIn = handler, handler = handleObjIn.handler, selector = handleObjIn.selector), 
                handler.guid || (handler.guid = jQuery.guid++), (events = elemData.events) || (events = elemData.events = {}), 
                (eventHandle = elemData.handle) || (eventHandle = elemData.handle = function(e) {
                    return typeof jQuery === core_strundefined || e && jQuery.event.triggered === e.type ? undefined : jQuery.event.dispatch.apply(eventHandle.elem, arguments);
                }, eventHandle.elem = elem), types = (types || "").match(core_rnotwhite) || [ "" ], 
                t = types.length; t--; ) tmp = rtypenamespace.exec(types[t]) || [], type = origType = tmp[1], 
                namespaces = (tmp[2] || "").split(".").sort(), type && (special = jQuery.event.special[type] || {}, 
                type = (selector ? special.delegateType : special.bindType) || type, special = jQuery.event.special[type] || {}, 
                handleObj = jQuery.extend({
                    type: type,
                    origType: origType,
                    data: data,
                    handler: handler,
                    guid: handler.guid,
                    selector: selector,
                    needsContext: selector && jQuery.expr.match.needsContext.test(selector),
                    namespace: namespaces.join(".")
                }, handleObjIn), (handlers = events[type]) || (handlers = events[type] = [], handlers.delegateCount = 0, 
                special.setup && special.setup.call(elem, data, namespaces, eventHandle) !== !1 || (elem.addEventListener ? elem.addEventListener(type, eventHandle, !1) : elem.attachEvent && elem.attachEvent("on" + type, eventHandle))), 
                special.add && (special.add.call(elem, handleObj), handleObj.handler.guid || (handleObj.handler.guid = handler.guid)), 
                selector ? handlers.splice(handlers.delegateCount++, 0, handleObj) : handlers.push(handleObj), 
                jQuery.event.global[type] = !0);
                elem = null;
            }
        },
        remove: function(elem, types, handler, selector, mappedTypes) {
            var j, handleObj, tmp, origCount, t, events, special, handlers, type, namespaces, origType, elemData = jQuery.hasData(elem) && jQuery._data(elem);
            if (elemData && (events = elemData.events)) {
                for (types = (types || "").match(core_rnotwhite) || [ "" ], t = types.length; t--; ) if (tmp = rtypenamespace.exec(types[t]) || [], 
                type = origType = tmp[1], namespaces = (tmp[2] || "").split(".").sort(), type) {
                    for (special = jQuery.event.special[type] || {}, type = (selector ? special.delegateType : special.bindType) || type, 
                    handlers = events[type] || [], tmp = tmp[2] && new RegExp("(^|\\.)" + namespaces.join("\\.(?:.*\\.|)") + "(\\.|$)"), 
                    origCount = j = handlers.length; j--; ) handleObj = handlers[j], !mappedTypes && origType !== handleObj.origType || handler && handler.guid !== handleObj.guid || tmp && !tmp.test(handleObj.namespace) || selector && selector !== handleObj.selector && ("**" !== selector || !handleObj.selector) || (handlers.splice(j, 1), 
                    handleObj.selector && handlers.delegateCount--, special.remove && special.remove.call(elem, handleObj));
                    origCount && !handlers.length && (special.teardown && special.teardown.call(elem, namespaces, elemData.handle) !== !1 || jQuery.removeEvent(elem, type, elemData.handle), 
                    delete events[type]);
                } else for (type in events) jQuery.event.remove(elem, type + types[t], handler, selector, !0);
                jQuery.isEmptyObject(events) && (delete elemData.handle, jQuery._removeData(elem, "events"));
            }
        },
        trigger: function(event, data, elem, onlyHandlers) {
            var handle, ontype, cur, bubbleType, special, tmp, i, eventPath = [ elem || document ], type = core_hasOwn.call(event, "type") ? event.type : event, namespaces = core_hasOwn.call(event, "namespace") ? event.namespace.split(".") : [];
            if (cur = tmp = elem = elem || document, 3 !== elem.nodeType && 8 !== elem.nodeType && !rfocusMorph.test(type + jQuery.event.triggered) && (type.indexOf(".") >= 0 && (namespaces = type.split("."), 
            type = namespaces.shift(), namespaces.sort()), ontype = type.indexOf(":") < 0 && "on" + type, 
            event = event[jQuery.expando] ? event : new jQuery.Event(type, "object" == typeof event && event), 
            event.isTrigger = onlyHandlers ? 2 : 3, event.namespace = namespaces.join("."), 
            event.namespace_re = event.namespace ? new RegExp("(^|\\.)" + namespaces.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, 
            event.result = undefined, event.target || (event.target = elem), data = null == data ? [ event ] : jQuery.makeArray(data, [ event ]), 
            special = jQuery.event.special[type] || {}, onlyHandlers || !special.trigger || special.trigger.apply(elem, data) !== !1)) {
                if (!onlyHandlers && !special.noBubble && !jQuery.isWindow(elem)) {
                    for (bubbleType = special.delegateType || type, rfocusMorph.test(bubbleType + type) || (cur = cur.parentNode); cur; cur = cur.parentNode) eventPath.push(cur), 
                    tmp = cur;
                    tmp === (elem.ownerDocument || document) && eventPath.push(tmp.defaultView || tmp.parentWindow || window);
                }
                for (i = 0; (cur = eventPath[i++]) && !event.isPropagationStopped(); ) event.type = i > 1 ? bubbleType : special.bindType || type, 
                handle = (jQuery._data(cur, "events") || {})[event.type] && jQuery._data(cur, "handle"), 
                handle && handle.apply(cur, data), handle = ontype && cur[ontype], handle && jQuery.acceptData(cur) && handle.apply && handle.apply(cur, data) === !1 && event.preventDefault();
                if (event.type = type, !onlyHandlers && !event.isDefaultPrevented() && (!special._default || special._default.apply(eventPath.pop(), data) === !1) && jQuery.acceptData(elem) && ontype && elem[type] && !jQuery.isWindow(elem)) {
                    tmp = elem[ontype], tmp && (elem[ontype] = null), jQuery.event.triggered = type;
                    try {
                        elem[type]();
                    } catch (e) {}
                    jQuery.event.triggered = undefined, tmp && (elem[ontype] = tmp);
                }
                return event.result;
            }
        },
        dispatch: function(event) {
            event = jQuery.event.fix(event);
            var i, ret, handleObj, matched, j, handlerQueue = [], args = core_slice.call(arguments), handlers = (jQuery._data(this, "events") || {})[event.type] || [], special = jQuery.event.special[event.type] || {};
            if (args[0] = event, event.delegateTarget = this, !special.preDispatch || special.preDispatch.call(this, event) !== !1) {
                for (handlerQueue = jQuery.event.handlers.call(this, event, handlers), i = 0; (matched = handlerQueue[i++]) && !event.isPropagationStopped(); ) for (event.currentTarget = matched.elem, 
                j = 0; (handleObj = matched.handlers[j++]) && !event.isImmediatePropagationStopped(); ) (!event.namespace_re || event.namespace_re.test(handleObj.namespace)) && (event.handleObj = handleObj, 
                event.data = handleObj.data, ret = ((jQuery.event.special[handleObj.origType] || {}).handle || handleObj.handler).apply(matched.elem, args), 
                ret !== undefined && (event.result = ret) === !1 && (event.preventDefault(), event.stopPropagation()));
                return special.postDispatch && special.postDispatch.call(this, event), event.result;
            }
        },
        handlers: function(event, handlers) {
            var sel, handleObj, matches, i, handlerQueue = [], delegateCount = handlers.delegateCount, cur = event.target;
            if (delegateCount && cur.nodeType && (!event.button || "click" !== event.type)) for (;cur != this; cur = cur.parentNode || this) if (1 === cur.nodeType && (cur.disabled !== !0 || "click" !== event.type)) {
                for (matches = [], i = 0; delegateCount > i; i++) handleObj = handlers[i], sel = handleObj.selector + " ", 
                matches[sel] === undefined && (matches[sel] = handleObj.needsContext ? jQuery(sel, this).index(cur) >= 0 : jQuery.find(sel, this, null, [ cur ]).length), 
                matches[sel] && matches.push(handleObj);
                matches.length && handlerQueue.push({
                    elem: cur,
                    handlers: matches
                });
            }
            return delegateCount < handlers.length && handlerQueue.push({
                elem: this,
                handlers: handlers.slice(delegateCount)
            }), handlerQueue;
        },
        fix: function(event) {
            if (event[jQuery.expando]) return event;
            var i, prop, copy, type = event.type, originalEvent = event, fixHook = this.fixHooks[type];
            for (fixHook || (this.fixHooks[type] = fixHook = rmouseEvent.test(type) ? this.mouseHooks : rkeyEvent.test(type) ? this.keyHooks : {}), 
            copy = fixHook.props ? this.props.concat(fixHook.props) : this.props, event = new jQuery.Event(originalEvent), 
            i = copy.length; i--; ) prop = copy[i], event[prop] = originalEvent[prop];
            return event.target || (event.target = originalEvent.srcElement || document), 3 === event.target.nodeType && (event.target = event.target.parentNode), 
            event.metaKey = !!event.metaKey, fixHook.filter ? fixHook.filter(event, originalEvent) : event;
        },
        props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function(event, original) {
                return null == event.which && (event.which = null != original.charCode ? original.charCode : original.keyCode), 
                event;
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function(event, original) {
                var body, eventDoc, doc, button = original.button, fromElement = original.fromElement;
                return null == event.pageX && null != original.clientX && (eventDoc = event.target.ownerDocument || document, 
                doc = eventDoc.documentElement, body = eventDoc.body, event.pageX = original.clientX + (doc && doc.scrollLeft || body && body.scrollLeft || 0) - (doc && doc.clientLeft || body && body.clientLeft || 0), 
                event.pageY = original.clientY + (doc && doc.scrollTop || body && body.scrollTop || 0) - (doc && doc.clientTop || body && body.clientTop || 0)), 
                !event.relatedTarget && fromElement && (event.relatedTarget = fromElement === event.target ? original.toElement : fromElement), 
                event.which || button === undefined || (event.which = 1 & button ? 1 : 2 & button ? 3 : 4 & button ? 2 : 0), 
                event;
            }
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                trigger: function() {
                    if (this !== safeActiveElement() && this.focus) try {
                        return this.focus(), !1;
                    } catch (e) {}
                },
                delegateType: "focusin"
            },
            blur: {
                trigger: function() {
                    return this === safeActiveElement() && this.blur ? (this.blur(), !1) : void 0;
                },
                delegateType: "focusout"
            },
            click: {
                trigger: function() {
                    return jQuery.nodeName(this, "input") && "checkbox" === this.type && this.click ? (this.click(), 
                    !1) : void 0;
                },
                _default: function(event) {
                    return jQuery.nodeName(event.target, "a");
                }
            },
            beforeunload: {
                postDispatch: function(event) {
                    event.result !== undefined && (event.originalEvent.returnValue = event.result);
                }
            }
        },
        simulate: function(type, elem, event, bubble) {
            var e = jQuery.extend(new jQuery.Event(), event, {
                type: type,
                isSimulated: !0,
                originalEvent: {}
            });
            bubble ? jQuery.event.trigger(e, null, elem) : jQuery.event.dispatch.call(elem, e), 
            e.isDefaultPrevented() && event.preventDefault();
        }
    }, jQuery.removeEvent = document.removeEventListener ? function(elem, type, handle) {
        elem.removeEventListener && elem.removeEventListener(type, handle, !1);
    } : function(elem, type, handle) {
        var name = "on" + type;
        elem.detachEvent && (typeof elem[name] === core_strundefined && (elem[name] = null), 
        elem.detachEvent(name, handle));
    }, jQuery.Event = function(src, props) {
        return this instanceof jQuery.Event ? (src && src.type ? (this.originalEvent = src, 
        this.type = src.type, this.isDefaultPrevented = src.defaultPrevented || src.returnValue === !1 || src.getPreventDefault && src.getPreventDefault() ? returnTrue : returnFalse) : this.type = src, 
        props && jQuery.extend(this, props), this.timeStamp = src && src.timeStamp || jQuery.now(), 
        void (this[jQuery.expando] = !0)) : new jQuery.Event(src, props);
    }, jQuery.Event.prototype = {
        isDefaultPrevented: returnFalse,
        isPropagationStopped: returnFalse,
        isImmediatePropagationStopped: returnFalse,
        preventDefault: function() {
            var e = this.originalEvent;
            this.isDefaultPrevented = returnTrue, e && (e.preventDefault ? e.preventDefault() : e.returnValue = !1);
        },
        stopPropagation: function() {
            var e = this.originalEvent;
            this.isPropagationStopped = returnTrue, e && (e.stopPropagation && e.stopPropagation(), 
            e.cancelBubble = !0);
        },
        stopImmediatePropagation: function() {
            this.isImmediatePropagationStopped = returnTrue, this.stopPropagation();
        }
    }, jQuery.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    }, function(orig, fix) {
        jQuery.event.special[orig] = {
            delegateType: fix,
            bindType: fix,
            handle: function(event) {
                var ret, target = this, related = event.relatedTarget, handleObj = event.handleObj;
                return (!related || related !== target && !jQuery.contains(target, related)) && (event.type = handleObj.origType, 
                ret = handleObj.handler.apply(this, arguments), event.type = fix), ret;
            }
        };
    }), jQuery.support.submitBubbles || (jQuery.event.special.submit = {
        setup: function() {
            return jQuery.nodeName(this, "form") ? !1 : void jQuery.event.add(this, "click._submit keypress._submit", function(e) {
                var elem = e.target, form = jQuery.nodeName(elem, "input") || jQuery.nodeName(elem, "button") ? elem.form : undefined;
                form && !jQuery._data(form, "submitBubbles") && (jQuery.event.add(form, "submit._submit", function(event) {
                    event._submit_bubble = !0;
                }), jQuery._data(form, "submitBubbles", !0));
            });
        },
        postDispatch: function(event) {
            event._submit_bubble && (delete event._submit_bubble, this.parentNode && !event.isTrigger && jQuery.event.simulate("submit", this.parentNode, event, !0));
        },
        teardown: function() {
            return jQuery.nodeName(this, "form") ? !1 : void jQuery.event.remove(this, "._submit");
        }
    }), jQuery.support.changeBubbles || (jQuery.event.special.change = {
        setup: function() {
            return rformElems.test(this.nodeName) ? (("checkbox" === this.type || "radio" === this.type) && (jQuery.event.add(this, "propertychange._change", function(event) {
                "checked" === event.originalEvent.propertyName && (this._just_changed = !0);
            }), jQuery.event.add(this, "click._change", function(event) {
                this._just_changed && !event.isTrigger && (this._just_changed = !1), jQuery.event.simulate("change", this, event, !0);
            })), !1) : void jQuery.event.add(this, "beforeactivate._change", function(e) {
                var elem = e.target;
                rformElems.test(elem.nodeName) && !jQuery._data(elem, "changeBubbles") && (jQuery.event.add(elem, "change._change", function(event) {
                    !this.parentNode || event.isSimulated || event.isTrigger || jQuery.event.simulate("change", this.parentNode, event, !0);
                }), jQuery._data(elem, "changeBubbles", !0));
            });
        },
        handle: function(event) {
            var elem = event.target;
            return this !== elem || event.isSimulated || event.isTrigger || "radio" !== elem.type && "checkbox" !== elem.type ? event.handleObj.handler.apply(this, arguments) : void 0;
        },
        teardown: function() {
            return jQuery.event.remove(this, "._change"), !rformElems.test(this.nodeName);
        }
    }), jQuery.support.focusinBubbles || jQuery.each({
        focus: "focusin",
        blur: "focusout"
    }, function(orig, fix) {
        var attaches = 0, handler = function(event) {
            jQuery.event.simulate(fix, event.target, jQuery.event.fix(event), !0);
        };
        jQuery.event.special[fix] = {
            setup: function() {
                0 === attaches++ && document.addEventListener(orig, handler, !0);
            },
            teardown: function() {
                0 === --attaches && document.removeEventListener(orig, handler, !0);
            }
        };
    }), jQuery.fn.extend({
        on: function(types, selector, data, fn, one) {
            var type, origFn;
            if ("object" == typeof types) {
                "string" != typeof selector && (data = data || selector, selector = undefined);
                for (type in types) this.on(type, selector, data, types[type], one);
                return this;
            }
            if (null == data && null == fn ? (fn = selector, data = selector = undefined) : null == fn && ("string" == typeof selector ? (fn = data, 
            data = undefined) : (fn = data, data = selector, selector = undefined)), fn === !1) fn = returnFalse; else if (!fn) return this;
            return 1 === one && (origFn = fn, fn = function(event) {
                return jQuery().off(event), origFn.apply(this, arguments);
            }, fn.guid = origFn.guid || (origFn.guid = jQuery.guid++)), this.each(function() {
                jQuery.event.add(this, types, fn, data, selector);
            });
        },
        one: function(types, selector, data, fn) {
            return this.on(types, selector, data, fn, 1);
        },
        off: function(types, selector, fn) {
            var handleObj, type;
            if (types && types.preventDefault && types.handleObj) return handleObj = types.handleObj, 
            jQuery(types.delegateTarget).off(handleObj.namespace ? handleObj.origType + "." + handleObj.namespace : handleObj.origType, handleObj.selector, handleObj.handler), 
            this;
            if ("object" == typeof types) {
                for (type in types) this.off(type, selector, types[type]);
                return this;
            }
            return (selector === !1 || "function" == typeof selector) && (fn = selector, selector = undefined), 
            fn === !1 && (fn = returnFalse), this.each(function() {
                jQuery.event.remove(this, types, fn, selector);
            });
        },
        trigger: function(type, data) {
            return this.each(function() {
                jQuery.event.trigger(type, data, this);
            });
        },
        triggerHandler: function(type, data) {
            var elem = this[0];
            return elem ? jQuery.event.trigger(type, data, elem, !0) : void 0;
        }
    });
    var isSimple = /^.[^:#\[\.,]*$/, rparentsprev = /^(?:parents|prev(?:Until|All))/, rneedsContext = jQuery.expr.match.needsContext, guaranteedUnique = {
        children: !0,
        contents: !0,
        next: !0,
        prev: !0
    };
    jQuery.fn.extend({
        find: function(selector) {
            var i, ret = [], self = this, len = self.length;
            if ("string" != typeof selector) return this.pushStack(jQuery(selector).filter(function() {
                for (i = 0; len > i; i++) if (jQuery.contains(self[i], this)) return !0;
            }));
            for (i = 0; len > i; i++) jQuery.find(selector, self[i], ret);
            return ret = this.pushStack(len > 1 ? jQuery.unique(ret) : ret), ret.selector = this.selector ? this.selector + " " + selector : selector, 
            ret;
        },
        has: function(target) {
            var i, targets = jQuery(target, this), len = targets.length;
            return this.filter(function() {
                for (i = 0; len > i; i++) if (jQuery.contains(this, targets[i])) return !0;
            });
        },
        not: function(selector) {
            return this.pushStack(winnow(this, selector || [], !0));
        },
        filter: function(selector) {
            return this.pushStack(winnow(this, selector || [], !1));
        },
        is: function(selector) {
            return !!winnow(this, "string" == typeof selector && rneedsContext.test(selector) ? jQuery(selector) : selector || [], !1).length;
        },
        closest: function(selectors, context) {
            for (var cur, i = 0, l = this.length, ret = [], pos = rneedsContext.test(selectors) || "string" != typeof selectors ? jQuery(selectors, context || this.context) : 0; l > i; i++) for (cur = this[i]; cur && cur !== context; cur = cur.parentNode) if (cur.nodeType < 11 && (pos ? pos.index(cur) > -1 : 1 === cur.nodeType && jQuery.find.matchesSelector(cur, selectors))) {
                cur = ret.push(cur);
                break;
            }
            return this.pushStack(ret.length > 1 ? jQuery.unique(ret) : ret);
        },
        index: function(elem) {
            return elem ? "string" == typeof elem ? jQuery.inArray(this[0], jQuery(elem)) : jQuery.inArray(elem.jquery ? elem[0] : elem, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1;
        },
        add: function(selector, context) {
            var set = "string" == typeof selector ? jQuery(selector, context) : jQuery.makeArray(selector && selector.nodeType ? [ selector ] : selector), all = jQuery.merge(this.get(), set);
            return this.pushStack(jQuery.unique(all));
        },
        addBack: function(selector) {
            return this.add(null == selector ? this.prevObject : this.prevObject.filter(selector));
        }
    }), jQuery.each({
        parent: function(elem) {
            var parent = elem.parentNode;
            return parent && 11 !== parent.nodeType ? parent : null;
        },
        parents: function(elem) {
            return jQuery.dir(elem, "parentNode");
        },
        parentsUntil: function(elem, i, until) {
            return jQuery.dir(elem, "parentNode", until);
        },
        next: function(elem) {
            return sibling(elem, "nextSibling");
        },
        prev: function(elem) {
            return sibling(elem, "previousSibling");
        },
        nextAll: function(elem) {
            return jQuery.dir(elem, "nextSibling");
        },
        prevAll: function(elem) {
            return jQuery.dir(elem, "previousSibling");
        },
        nextUntil: function(elem, i, until) {
            return jQuery.dir(elem, "nextSibling", until);
        },
        prevUntil: function(elem, i, until) {
            return jQuery.dir(elem, "previousSibling", until);
        },
        siblings: function(elem) {
            return jQuery.sibling((elem.parentNode || {}).firstChild, elem);
        },
        children: function(elem) {
            return jQuery.sibling(elem.firstChild);
        },
        contents: function(elem) {
            return jQuery.nodeName(elem, "iframe") ? elem.contentDocument || elem.contentWindow.document : jQuery.merge([], elem.childNodes);
        }
    }, function(name, fn) {
        jQuery.fn[name] = function(until, selector) {
            var ret = jQuery.map(this, fn, until);
            return "Until" !== name.slice(-5) && (selector = until), selector && "string" == typeof selector && (ret = jQuery.filter(selector, ret)), 
            this.length > 1 && (guaranteedUnique[name] || (ret = jQuery.unique(ret)), rparentsprev.test(name) && (ret = ret.reverse())), 
            this.pushStack(ret);
        };
    }), jQuery.extend({
        filter: function(expr, elems, not) {
            var elem = elems[0];
            return not && (expr = ":not(" + expr + ")"), 1 === elems.length && 1 === elem.nodeType ? jQuery.find.matchesSelector(elem, expr) ? [ elem ] : [] : jQuery.find.matches(expr, jQuery.grep(elems, function(elem) {
                return 1 === elem.nodeType;
            }));
        },
        dir: function(elem, dir, until) {
            for (var matched = [], cur = elem[dir]; cur && 9 !== cur.nodeType && (until === undefined || 1 !== cur.nodeType || !jQuery(cur).is(until)); ) 1 === cur.nodeType && matched.push(cur), 
            cur = cur[dir];
            return matched;
        },
        sibling: function(n, elem) {
            for (var r = []; n; n = n.nextSibling) 1 === n.nodeType && n !== elem && r.push(n);
            return r;
        }
    });
    var nodeNames = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video", rinlinejQuery = / jQuery\d+="(?:null|\d+)"/g, rnoshimcache = new RegExp("<(?:" + nodeNames + ")[\\s/>]", "i"), rleadingWhitespace = /^\s+/, rxhtmlTag = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi, rtagName = /<([\w:]+)/, rtbody = /<tbody/i, rhtml = /<|&#?\w+;/, rnoInnerhtml = /<(?:script|style|link)/i, manipulation_rcheckableType = /^(?:checkbox|radio)$/i, rchecked = /checked\s*(?:[^=]|=\s*.checked.)/i, rscriptType = /^$|\/(?:java|ecma)script/i, rscriptTypeMasked = /^true\/(.*)/, rcleanScript = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g, wrapMap = {
        option: [ 1, "<select multiple='multiple'>", "</select>" ],
        legend: [ 1, "<fieldset>", "</fieldset>" ],
        area: [ 1, "<map>", "</map>" ],
        param: [ 1, "<object>", "</object>" ],
        thead: [ 1, "<table>", "</table>" ],
        tr: [ 2, "<table><tbody>", "</tbody></table>" ],
        col: [ 2, "<table><tbody></tbody><colgroup>", "</colgroup></table>" ],
        td: [ 3, "<table><tbody><tr>", "</tr></tbody></table>" ],
        _default: jQuery.support.htmlSerialize ? [ 0, "", "" ] : [ 1, "X<div>", "</div>" ]
    }, safeFragment = createSafeFragment(document), fragmentDiv = safeFragment.appendChild(document.createElement("div"));
    wrapMap.optgroup = wrapMap.option, wrapMap.tbody = wrapMap.tfoot = wrapMap.colgroup = wrapMap.caption = wrapMap.thead, 
    wrapMap.th = wrapMap.td, jQuery.fn.extend({
        text: function(value) {
            return jQuery.access(this, function(value) {
                return value === undefined ? jQuery.text(this) : this.empty().append((this[0] && this[0].ownerDocument || document).createTextNode(value));
            }, null, value, arguments.length);
        },
        append: function() {
            return this.domManip(arguments, function(elem) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var target = manipulationTarget(this, elem);
                    target.appendChild(elem);
                }
            });
        },
        prepend: function() {
            return this.domManip(arguments, function(elem) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var target = manipulationTarget(this, elem);
                    target.insertBefore(elem, target.firstChild);
                }
            });
        },
        before: function() {
            return this.domManip(arguments, function(elem) {
                this.parentNode && this.parentNode.insertBefore(elem, this);
            });
        },
        after: function() {
            return this.domManip(arguments, function(elem) {
                this.parentNode && this.parentNode.insertBefore(elem, this.nextSibling);
            });
        },
        remove: function(selector, keepData) {
            for (var elem, elems = selector ? jQuery.filter(selector, this) : this, i = 0; null != (elem = elems[i]); i++) keepData || 1 !== elem.nodeType || jQuery.cleanData(getAll(elem)), 
            elem.parentNode && (keepData && jQuery.contains(elem.ownerDocument, elem) && setGlobalEval(getAll(elem, "script")), 
            elem.parentNode.removeChild(elem));
            return this;
        },
        empty: function() {
            for (var elem, i = 0; null != (elem = this[i]); i++) {
                for (1 === elem.nodeType && jQuery.cleanData(getAll(elem, !1)); elem.firstChild; ) elem.removeChild(elem.firstChild);
                elem.options && jQuery.nodeName(elem, "select") && (elem.options.length = 0);
            }
            return this;
        },
        clone: function(dataAndEvents, deepDataAndEvents) {
            return dataAndEvents = null == dataAndEvents ? !1 : dataAndEvents, deepDataAndEvents = null == deepDataAndEvents ? dataAndEvents : deepDataAndEvents, 
            this.map(function() {
                return jQuery.clone(this, dataAndEvents, deepDataAndEvents);
            });
        },
        html: function(value) {
            return jQuery.access(this, function(value) {
                var elem = this[0] || {}, i = 0, l = this.length;
                if (value === undefined) return 1 === elem.nodeType ? elem.innerHTML.replace(rinlinejQuery, "") : undefined;
                if (!("string" != typeof value || rnoInnerhtml.test(value) || !jQuery.support.htmlSerialize && rnoshimcache.test(value) || !jQuery.support.leadingWhitespace && rleadingWhitespace.test(value) || wrapMap[(rtagName.exec(value) || [ "", "" ])[1].toLowerCase()])) {
                    value = value.replace(rxhtmlTag, "<$1></$2>");
                    try {
                        for (;l > i; i++) elem = this[i] || {}, 1 === elem.nodeType && (jQuery.cleanData(getAll(elem, !1)), 
                        elem.innerHTML = value);
                        elem = 0;
                    } catch (e) {}
                }
                elem && this.empty().append(value);
            }, null, value, arguments.length);
        },
        replaceWith: function() {
            var args = jQuery.map(this, function(elem) {
                return [ elem.nextSibling, elem.parentNode ];
            }), i = 0;
            return this.domManip(arguments, function(elem) {
                var next = args[i++], parent = args[i++];
                parent && (next && next.parentNode !== parent && (next = this.nextSibling), jQuery(this).remove(), 
                parent.insertBefore(elem, next));
            }, !0), i ? this : this.remove();
        },
        detach: function(selector) {
            return this.remove(selector, !0);
        },
        domManip: function(args, callback, allowIntersection) {
            args = core_concat.apply([], args);
            var first, node, hasScripts, scripts, doc, fragment, i = 0, l = this.length, set = this, iNoClone = l - 1, value = args[0], isFunction = jQuery.isFunction(value);
            if (isFunction || !(1 >= l || "string" != typeof value || jQuery.support.checkClone) && rchecked.test(value)) return this.each(function(index) {
                var self = set.eq(index);
                isFunction && (args[0] = value.call(this, index, self.html())), self.domManip(args, callback, allowIntersection);
            });
            if (l && (fragment = jQuery.buildFragment(args, this[0].ownerDocument, !1, !allowIntersection && this), 
            first = fragment.firstChild, 1 === fragment.childNodes.length && (fragment = first), 
            first)) {
                for (scripts = jQuery.map(getAll(fragment, "script"), disableScript), hasScripts = scripts.length; l > i; i++) node = fragment, 
                i !== iNoClone && (node = jQuery.clone(node, !0, !0), hasScripts && jQuery.merge(scripts, getAll(node, "script"))), 
                callback.call(this[i], node, i);
                if (hasScripts) for (doc = scripts[scripts.length - 1].ownerDocument, jQuery.map(scripts, restoreScript), 
                i = 0; hasScripts > i; i++) node = scripts[i], rscriptType.test(node.type || "") && !jQuery._data(node, "globalEval") && jQuery.contains(doc, node) && (node.src ? jQuery._evalUrl(node.src) : jQuery.globalEval((node.text || node.textContent || node.innerHTML || "").replace(rcleanScript, "")));
                fragment = first = null;
            }
            return this;
        }
    }), jQuery.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(name, original) {
        jQuery.fn[name] = function(selector) {
            for (var elems, i = 0, ret = [], insert = jQuery(selector), last = insert.length - 1; last >= i; i++) elems = i === last ? this : this.clone(!0), 
            jQuery(insert[i])[original](elems), core_push.apply(ret, elems.get());
            return this.pushStack(ret);
        };
    }), jQuery.extend({
        clone: function(elem, dataAndEvents, deepDataAndEvents) {
            var destElements, node, clone, i, srcElements, inPage = jQuery.contains(elem.ownerDocument, elem);
            if (jQuery.support.html5Clone || jQuery.isXMLDoc(elem) || !rnoshimcache.test("<" + elem.nodeName + ">") ? clone = elem.cloneNode(!0) : (fragmentDiv.innerHTML = elem.outerHTML, 
            fragmentDiv.removeChild(clone = fragmentDiv.firstChild)), !(jQuery.support.noCloneEvent && jQuery.support.noCloneChecked || 1 !== elem.nodeType && 11 !== elem.nodeType || jQuery.isXMLDoc(elem))) for (destElements = getAll(clone), 
            srcElements = getAll(elem), i = 0; null != (node = srcElements[i]); ++i) destElements[i] && fixCloneNodeIssues(node, destElements[i]);
            if (dataAndEvents) if (deepDataAndEvents) for (srcElements = srcElements || getAll(elem), 
            destElements = destElements || getAll(clone), i = 0; null != (node = srcElements[i]); i++) cloneCopyEvent(node, destElements[i]); else cloneCopyEvent(elem, clone);
            return destElements = getAll(clone, "script"), destElements.length > 0 && setGlobalEval(destElements, !inPage && getAll(elem, "script")), 
            destElements = srcElements = node = null, clone;
        },
        buildFragment: function(elems, context, scripts, selection) {
            for (var j, elem, contains, tmp, tag, tbody, wrap, l = elems.length, safe = createSafeFragment(context), nodes = [], i = 0; l > i; i++) if (elem = elems[i], 
            elem || 0 === elem) if ("object" === jQuery.type(elem)) jQuery.merge(nodes, elem.nodeType ? [ elem ] : elem); else if (rhtml.test(elem)) {
                for (tmp = tmp || safe.appendChild(context.createElement("div")), tag = (rtagName.exec(elem) || [ "", "" ])[1].toLowerCase(), 
                wrap = wrapMap[tag] || wrapMap._default, tmp.innerHTML = wrap[1] + elem.replace(rxhtmlTag, "<$1></$2>") + wrap[2], 
                j = wrap[0]; j--; ) tmp = tmp.lastChild;
                if (!jQuery.support.leadingWhitespace && rleadingWhitespace.test(elem) && nodes.push(context.createTextNode(rleadingWhitespace.exec(elem)[0])), 
                !jQuery.support.tbody) for (elem = "table" !== tag || rtbody.test(elem) ? "<table>" !== wrap[1] || rtbody.test(elem) ? 0 : tmp : tmp.firstChild, 
                j = elem && elem.childNodes.length; j--; ) jQuery.nodeName(tbody = elem.childNodes[j], "tbody") && !tbody.childNodes.length && elem.removeChild(tbody);
                for (jQuery.merge(nodes, tmp.childNodes), tmp.textContent = ""; tmp.firstChild; ) tmp.removeChild(tmp.firstChild);
                tmp = safe.lastChild;
            } else nodes.push(context.createTextNode(elem));
            for (tmp && safe.removeChild(tmp), jQuery.support.appendChecked || jQuery.grep(getAll(nodes, "input"), fixDefaultChecked), 
            i = 0; elem = nodes[i++]; ) if ((!selection || -1 === jQuery.inArray(elem, selection)) && (contains = jQuery.contains(elem.ownerDocument, elem), 
            tmp = getAll(safe.appendChild(elem), "script"), contains && setGlobalEval(tmp), 
            scripts)) for (j = 0; elem = tmp[j++]; ) rscriptType.test(elem.type || "") && scripts.push(elem);
            return tmp = null, safe;
        },
        cleanData: function(elems, acceptData) {
            for (var elem, type, id, data, i = 0, internalKey = jQuery.expando, cache = jQuery.cache, deleteExpando = jQuery.support.deleteExpando, special = jQuery.event.special; null != (elem = elems[i]); i++) if ((acceptData || jQuery.acceptData(elem)) && (id = elem[internalKey], 
            data = id && cache[id])) {
                if (data.events) for (type in data.events) special[type] ? jQuery.event.remove(elem, type) : jQuery.removeEvent(elem, type, data.handle);
                cache[id] && (delete cache[id], deleteExpando ? delete elem[internalKey] : typeof elem.removeAttribute !== core_strundefined ? elem.removeAttribute(internalKey) : elem[internalKey] = null, 
                core_deletedIds.push(id));
            }
        },
        _evalUrl: function(url) {
            return jQuery.ajax({
                url: url,
                type: "GET",
                dataType: "script",
                async: !1,
                global: !1,
                "throws": !0
            });
        }
    }), jQuery.fn.extend({
        wrapAll: function(html) {
            if (jQuery.isFunction(html)) return this.each(function(i) {
                jQuery(this).wrapAll(html.call(this, i));
            });
            if (this[0]) {
                var wrap = jQuery(html, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && wrap.insertBefore(this[0]), wrap.map(function() {
                    for (var elem = this; elem.firstChild && 1 === elem.firstChild.nodeType; ) elem = elem.firstChild;
                    return elem;
                }).append(this);
            }
            return this;
        },
        wrapInner: function(html) {
            return this.each(jQuery.isFunction(html) ? function(i) {
                jQuery(this).wrapInner(html.call(this, i));
            } : function() {
                var self = jQuery(this), contents = self.contents();
                contents.length ? contents.wrapAll(html) : self.append(html);
            });
        },
        wrap: function(html) {
            var isFunction = jQuery.isFunction(html);
            return this.each(function(i) {
                jQuery(this).wrapAll(isFunction ? html.call(this, i) : html);
            });
        },
        unwrap: function() {
            return this.parent().each(function() {
                jQuery.nodeName(this, "body") || jQuery(this).replaceWith(this.childNodes);
            }).end();
        }
    });
    var iframe, getStyles, curCSS, ralpha = /alpha\([^)]*\)/i, ropacity = /opacity\s*=\s*([^)]*)/, rposition = /^(top|right|bottom|left)$/, rdisplayswap = /^(none|table(?!-c[ea]).+)/, rmargin = /^margin/, rnumsplit = new RegExp("^(" + core_pnum + ")(.*)$", "i"), rnumnonpx = new RegExp("^(" + core_pnum + ")(?!px)[a-z%]+$", "i"), rrelNum = new RegExp("^([+-])=(" + core_pnum + ")", "i"), elemdisplay = {
        BODY: "block"
    }, cssShow = {
        position: "absolute",
        visibility: "hidden",
        display: "block"
    }, cssNormalTransform = {
        letterSpacing: 0,
        fontWeight: 400
    }, cssExpand = [ "Top", "Right", "Bottom", "Left" ], cssPrefixes = [ "Webkit", "O", "Moz", "ms" ];
    jQuery.fn.extend({
        css: function(name, value) {
            return jQuery.access(this, function(elem, name, value) {
                var len, styles, map = {}, i = 0;
                if (jQuery.isArray(name)) {
                    for (styles = getStyles(elem), len = name.length; len > i; i++) map[name[i]] = jQuery.css(elem, name[i], !1, styles);
                    return map;
                }
                return value !== undefined ? jQuery.style(elem, name, value) : jQuery.css(elem, name);
            }, name, value, arguments.length > 1);
        },
        show: function() {
            return showHide(this, !0);
        },
        hide: function() {
            return showHide(this);
        },
        toggle: function(state) {
            return "boolean" == typeof state ? state ? this.show() : this.hide() : this.each(function() {
                isHidden(this) ? jQuery(this).show() : jQuery(this).hide();
            });
        }
    }), jQuery.extend({
        cssHooks: {
            opacity: {
                get: function(elem, computed) {
                    if (computed) {
                        var ret = curCSS(elem, "opacity");
                        return "" === ret ? "1" : ret;
                    }
                }
            }
        },
        cssNumber: {
            columnCount: !0,
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            "float": jQuery.support.cssFloat ? "cssFloat" : "styleFloat"
        },
        style: function(elem, name, value, extra) {
            if (elem && 3 !== elem.nodeType && 8 !== elem.nodeType && elem.style) {
                var ret, type, hooks, origName = jQuery.camelCase(name), style = elem.style;
                if (name = jQuery.cssProps[origName] || (jQuery.cssProps[origName] = vendorPropName(style, origName)), 
                hooks = jQuery.cssHooks[name] || jQuery.cssHooks[origName], value === undefined) return hooks && "get" in hooks && (ret = hooks.get(elem, !1, extra)) !== undefined ? ret : style[name];
                if (type = typeof value, "string" === type && (ret = rrelNum.exec(value)) && (value = (ret[1] + 1) * ret[2] + parseFloat(jQuery.css(elem, name)), 
                type = "number"), !(null == value || "number" === type && isNaN(value) || ("number" !== type || jQuery.cssNumber[origName] || (value += "px"), 
                jQuery.support.clearCloneStyle || "" !== value || 0 !== name.indexOf("background") || (style[name] = "inherit"), 
                hooks && "set" in hooks && (value = hooks.set(elem, value, extra)) === undefined))) try {
                    style[name] = value;
                } catch (e) {}
            }
        },
        css: function(elem, name, extra, styles) {
            var num, val, hooks, origName = jQuery.camelCase(name);
            return name = jQuery.cssProps[origName] || (jQuery.cssProps[origName] = vendorPropName(elem.style, origName)), 
            hooks = jQuery.cssHooks[name] || jQuery.cssHooks[origName], hooks && "get" in hooks && (val = hooks.get(elem, !0, extra)), 
            val === undefined && (val = curCSS(elem, name, styles)), "normal" === val && name in cssNormalTransform && (val = cssNormalTransform[name]), 
            "" === extra || extra ? (num = parseFloat(val), extra === !0 || jQuery.isNumeric(num) ? num || 0 : val) : val;
        }
    }), window.getComputedStyle ? (getStyles = function(elem) {
        return window.getComputedStyle(elem, null);
    }, curCSS = function(elem, name, _computed) {
        var width, minWidth, maxWidth, computed = _computed || getStyles(elem), ret = computed ? computed.getPropertyValue(name) || computed[name] : undefined, style = elem.style;
        return computed && ("" !== ret || jQuery.contains(elem.ownerDocument, elem) || (ret = jQuery.style(elem, name)), 
        rnumnonpx.test(ret) && rmargin.test(name) && (width = style.width, minWidth = style.minWidth, 
        maxWidth = style.maxWidth, style.minWidth = style.maxWidth = style.width = ret, 
        ret = computed.width, style.width = width, style.minWidth = minWidth, style.maxWidth = maxWidth)), 
        ret;
    }) : document.documentElement.currentStyle && (getStyles = function(elem) {
        return elem.currentStyle;
    }, curCSS = function(elem, name, _computed) {
        var left, rs, rsLeft, computed = _computed || getStyles(elem), ret = computed ? computed[name] : undefined, style = elem.style;
        return null == ret && style && style[name] && (ret = style[name]), rnumnonpx.test(ret) && !rposition.test(name) && (left = style.left, 
        rs = elem.runtimeStyle, rsLeft = rs && rs.left, rsLeft && (rs.left = elem.currentStyle.left), 
        style.left = "fontSize" === name ? "1em" : ret, ret = style.pixelLeft + "px", style.left = left, 
        rsLeft && (rs.left = rsLeft)), "" === ret ? "auto" : ret;
    }), jQuery.each([ "height", "width" ], function(i, name) {
        jQuery.cssHooks[name] = {
            get: function(elem, computed, extra) {
                return computed ? 0 === elem.offsetWidth && rdisplayswap.test(jQuery.css(elem, "display")) ? jQuery.swap(elem, cssShow, function() {
                    return getWidthOrHeight(elem, name, extra);
                }) : getWidthOrHeight(elem, name, extra) : void 0;
            },
            set: function(elem, value, extra) {
                var styles = extra && getStyles(elem);
                return setPositiveNumber(elem, value, extra ? augmentWidthOrHeight(elem, name, extra, jQuery.support.boxSizing && "border-box" === jQuery.css(elem, "boxSizing", !1, styles), styles) : 0);
            }
        };
    }), jQuery.support.opacity || (jQuery.cssHooks.opacity = {
        get: function(elem, computed) {
            return ropacity.test((computed && elem.currentStyle ? elem.currentStyle.filter : elem.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : computed ? "1" : "";
        },
        set: function(elem, value) {
            var style = elem.style, currentStyle = elem.currentStyle, opacity = jQuery.isNumeric(value) ? "alpha(opacity=" + 100 * value + ")" : "", filter = currentStyle && currentStyle.filter || style.filter || "";
            style.zoom = 1, (value >= 1 || "" === value) && "" === jQuery.trim(filter.replace(ralpha, "")) && style.removeAttribute && (style.removeAttribute("filter"), 
            "" === value || currentStyle && !currentStyle.filter) || (style.filter = ralpha.test(filter) ? filter.replace(ralpha, opacity) : filter + " " + opacity);
        }
    }), jQuery(function() {
        jQuery.support.reliableMarginRight || (jQuery.cssHooks.marginRight = {
            get: function(elem, computed) {
                return computed ? jQuery.swap(elem, {
                    display: "inline-block"
                }, curCSS, [ elem, "marginRight" ]) : void 0;
            }
        }), !jQuery.support.pixelPosition && jQuery.fn.position && jQuery.each([ "top", "left" ], function(i, prop) {
            jQuery.cssHooks[prop] = {
                get: function(elem, computed) {
                    return computed ? (computed = curCSS(elem, prop), rnumnonpx.test(computed) ? jQuery(elem).position()[prop] + "px" : computed) : void 0;
                }
            };
        });
    }), jQuery.expr && jQuery.expr.filters && (jQuery.expr.filters.hidden = function(elem) {
        return elem.offsetWidth <= 0 && elem.offsetHeight <= 0 || !jQuery.support.reliableHiddenOffsets && "none" === (elem.style && elem.style.display || jQuery.css(elem, "display"));
    }, jQuery.expr.filters.visible = function(elem) {
        return !jQuery.expr.filters.hidden(elem);
    }), jQuery.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function(prefix, suffix) {
        jQuery.cssHooks[prefix + suffix] = {
            expand: function(value) {
                for (var i = 0, expanded = {}, parts = "string" == typeof value ? value.split(" ") : [ value ]; 4 > i; i++) expanded[prefix + cssExpand[i] + suffix] = parts[i] || parts[i - 2] || parts[0];
                return expanded;
            }
        }, rmargin.test(prefix) || (jQuery.cssHooks[prefix + suffix].set = setPositiveNumber);
    });
    var r20 = /%20/g, rbracket = /\[\]$/, rCRLF = /\r?\n/g, rsubmitterTypes = /^(?:submit|button|image|reset|file)$/i, rsubmittable = /^(?:input|select|textarea|keygen)/i;
    jQuery.fn.extend({
        serialize: function() {
            return jQuery.param(this.serializeArray());
        },
        serializeArray: function() {
            return this.map(function() {
                var elements = jQuery.prop(this, "elements");
                return elements ? jQuery.makeArray(elements) : this;
            }).filter(function() {
                var type = this.type;
                return this.name && !jQuery(this).is(":disabled") && rsubmittable.test(this.nodeName) && !rsubmitterTypes.test(type) && (this.checked || !manipulation_rcheckableType.test(type));
            }).map(function(i, elem) {
                var val = jQuery(this).val();
                return null == val ? null : jQuery.isArray(val) ? jQuery.map(val, function(val) {
                    return {
                        name: elem.name,
                        value: val.replace(rCRLF, "\r\n")
                    };
                }) : {
                    name: elem.name,
                    value: val.replace(rCRLF, "\r\n")
                };
            }).get();
        }
    }), jQuery.param = function(a, traditional) {
        var prefix, s = [], add = function(key, value) {
            value = jQuery.isFunction(value) ? value() : null == value ? "" : value, s[s.length] = encodeURIComponent(key) + "=" + encodeURIComponent(value);
        };
        if (traditional === undefined && (traditional = jQuery.ajaxSettings && jQuery.ajaxSettings.traditional), 
        jQuery.isArray(a) || a.jquery && !jQuery.isPlainObject(a)) jQuery.each(a, function() {
            add(this.name, this.value);
        }); else for (prefix in a) buildParams(prefix, a[prefix], traditional, add);
        return s.join("&").replace(r20, "+");
    }, jQuery.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function(i, name) {
        jQuery.fn[name] = function(data, fn) {
            return arguments.length > 0 ? this.on(name, null, data, fn) : this.trigger(name);
        };
    }), jQuery.fn.extend({
        hover: function(fnOver, fnOut) {
            return this.mouseenter(fnOver).mouseleave(fnOut || fnOver);
        },
        bind: function(types, data, fn) {
            return this.on(types, null, data, fn);
        },
        unbind: function(types, fn) {
            return this.off(types, null, fn);
        },
        delegate: function(selector, types, data, fn) {
            return this.on(types, selector, data, fn);
        },
        undelegate: function(selector, types, fn) {
            return 1 === arguments.length ? this.off(selector, "**") : this.off(types, selector || "**", fn);
        }
    });
    var ajaxLocParts, ajaxLocation, ajax_nonce = jQuery.now(), ajax_rquery = /\?/, rhash = /#.*$/, rts = /([?&])_=[^&]*/, rheaders = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm, rlocalProtocol = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/, rnoContent = /^(?:GET|HEAD)$/, rprotocol = /^\/\//, rurl = /^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/, _load = jQuery.fn.load, prefilters = {}, transports = {}, allTypes = "*/".concat("*");
    try {
        ajaxLocation = location.href;
    } catch (e) {
        ajaxLocation = document.createElement("a"), ajaxLocation.href = "", ajaxLocation = ajaxLocation.href;
    }
    ajaxLocParts = rurl.exec(ajaxLocation.toLowerCase()) || [], jQuery.fn.load = function(url, params, callback) {
        if ("string" != typeof url && _load) return _load.apply(this, arguments);
        var selector, response, type, self = this, off = url.indexOf(" ");
        return off >= 0 && (selector = url.slice(off, url.length), url = url.slice(0, off)), 
        jQuery.isFunction(params) ? (callback = params, params = undefined) : params && "object" == typeof params && (type = "POST"), 
        self.length > 0 && jQuery.ajax({
            url: url,
            type: type,
            dataType: "html",
            data: params
        }).done(function(responseText) {
            response = arguments, self.html(selector ? jQuery("<div>").append(jQuery.parseHTML(responseText)).find(selector) : responseText);
        }).complete(callback && function(jqXHR, status) {
            self.each(callback, response || [ jqXHR.responseText, status, jqXHR ]);
        }), this;
    }, jQuery.each([ "ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend" ], function(i, type) {
        jQuery.fn[type] = function(fn) {
            return this.on(type, fn);
        };
    }), jQuery.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: ajaxLocation,
            type: "GET",
            isLocal: rlocalProtocol.test(ajaxLocParts[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": allTypes,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": jQuery.parseJSON,
                "text xml": jQuery.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(target, settings) {
            return settings ? ajaxExtend(ajaxExtend(target, jQuery.ajaxSettings), settings) : ajaxExtend(jQuery.ajaxSettings, target);
        },
        ajaxPrefilter: addToPrefiltersOrTransports(prefilters),
        ajaxTransport: addToPrefiltersOrTransports(transports),
        ajax: function(url, options) {
            function done(status, nativeStatusText, responses, headers) {
                var isSuccess, success, error, response, modified, statusText = nativeStatusText;
                2 !== state && (state = 2, timeoutTimer && clearTimeout(timeoutTimer), transport = undefined, 
                responseHeadersString = headers || "", jqXHR.readyState = status > 0 ? 4 : 0, isSuccess = status >= 200 && 300 > status || 304 === status, 
                responses && (response = ajaxHandleResponses(s, jqXHR, responses)), response = ajaxConvert(s, response, jqXHR, isSuccess), 
                isSuccess ? (s.ifModified && (modified = jqXHR.getResponseHeader("Last-Modified"), 
                modified && (jQuery.lastModified[cacheURL] = modified), modified = jqXHR.getResponseHeader("etag"), 
                modified && (jQuery.etag[cacheURL] = modified)), 204 === status || "HEAD" === s.type ? statusText = "nocontent" : 304 === status ? statusText = "notmodified" : (statusText = response.state, 
                success = response.data, error = response.error, isSuccess = !error)) : (error = statusText, 
                (status || !statusText) && (statusText = "error", 0 > status && (status = 0))), 
                jqXHR.status = status, jqXHR.statusText = (nativeStatusText || statusText) + "", 
                isSuccess ? deferred.resolveWith(callbackContext, [ success, statusText, jqXHR ]) : deferred.rejectWith(callbackContext, [ jqXHR, statusText, error ]), 
                jqXHR.statusCode(statusCode), statusCode = undefined, fireGlobals && globalEventContext.trigger(isSuccess ? "ajaxSuccess" : "ajaxError", [ jqXHR, s, isSuccess ? success : error ]), 
                completeDeferred.fireWith(callbackContext, [ jqXHR, statusText ]), fireGlobals && (globalEventContext.trigger("ajaxComplete", [ jqXHR, s ]), 
                --jQuery.active || jQuery.event.trigger("ajaxStop")));
            }
            "object" == typeof url && (options = url, url = undefined), options = options || {};
            var parts, i, cacheURL, responseHeadersString, timeoutTimer, fireGlobals, transport, responseHeaders, s = jQuery.ajaxSetup({}, options), callbackContext = s.context || s, globalEventContext = s.context && (callbackContext.nodeType || callbackContext.jquery) ? jQuery(callbackContext) : jQuery.event, deferred = jQuery.Deferred(), completeDeferred = jQuery.Callbacks("once memory"), statusCode = s.statusCode || {}, requestHeaders = {}, requestHeadersNames = {}, state = 0, strAbort = "canceled", jqXHR = {
                readyState: 0,
                getResponseHeader: function(key) {
                    var match;
                    if (2 === state) {
                        if (!responseHeaders) for (responseHeaders = {}; match = rheaders.exec(responseHeadersString); ) responseHeaders[match[1].toLowerCase()] = match[2];
                        match = responseHeaders[key.toLowerCase()];
                    }
                    return null == match ? null : match;
                },
                getAllResponseHeaders: function() {
                    return 2 === state ? responseHeadersString : null;
                },
                setRequestHeader: function(name, value) {
                    var lname = name.toLowerCase();
                    return state || (name = requestHeadersNames[lname] = requestHeadersNames[lname] || name, 
                    requestHeaders[name] = value), this;
                },
                overrideMimeType: function(type) {
                    return state || (s.mimeType = type), this;
                },
                statusCode: function(map) {
                    var code;
                    if (map) if (2 > state) for (code in map) statusCode[code] = [ statusCode[code], map[code] ]; else jqXHR.always(map[jqXHR.status]);
                    return this;
                },
                abort: function(statusText) {
                    var finalText = statusText || strAbort;
                    return transport && transport.abort(finalText), done(0, finalText), this;
                }
            };
            if (deferred.promise(jqXHR).complete = completeDeferred.add, jqXHR.success = jqXHR.done, 
            jqXHR.error = jqXHR.fail, s.url = ((url || s.url || ajaxLocation) + "").replace(rhash, "").replace(rprotocol, ajaxLocParts[1] + "//"), 
            s.type = options.method || options.type || s.method || s.type, s.dataTypes = jQuery.trim(s.dataType || "*").toLowerCase().match(core_rnotwhite) || [ "" ], 
            null == s.crossDomain && (parts = rurl.exec(s.url.toLowerCase()), s.crossDomain = !(!parts || parts[1] === ajaxLocParts[1] && parts[2] === ajaxLocParts[2] && (parts[3] || ("http:" === parts[1] ? "80" : "443")) === (ajaxLocParts[3] || ("http:" === ajaxLocParts[1] ? "80" : "443")))), 
            s.data && s.processData && "string" != typeof s.data && (s.data = jQuery.param(s.data, s.traditional)), 
            inspectPrefiltersOrTransports(prefilters, s, options, jqXHR), 2 === state) return jqXHR;
            fireGlobals = s.global, fireGlobals && 0 === jQuery.active++ && jQuery.event.trigger("ajaxStart"), 
            s.type = s.type.toUpperCase(), s.hasContent = !rnoContent.test(s.type), cacheURL = s.url, 
            s.hasContent || (s.data && (cacheURL = s.url += (ajax_rquery.test(cacheURL) ? "&" : "?") + s.data, 
            delete s.data), s.cache === !1 && (s.url = rts.test(cacheURL) ? cacheURL.replace(rts, "$1_=" + ajax_nonce++) : cacheURL + (ajax_rquery.test(cacheURL) ? "&" : "?") + "_=" + ajax_nonce++)), 
            s.ifModified && (jQuery.lastModified[cacheURL] && jqXHR.setRequestHeader("If-Modified-Since", jQuery.lastModified[cacheURL]), 
            jQuery.etag[cacheURL] && jqXHR.setRequestHeader("If-None-Match", jQuery.etag[cacheURL])), 
            (s.data && s.hasContent && s.contentType !== !1 || options.contentType) && jqXHR.setRequestHeader("Content-Type", s.contentType), 
            jqXHR.setRequestHeader("Accept", s.dataTypes[0] && s.accepts[s.dataTypes[0]] ? s.accepts[s.dataTypes[0]] + ("*" !== s.dataTypes[0] ? ", " + allTypes + "; q=0.01" : "") : s.accepts["*"]);
            for (i in s.headers) jqXHR.setRequestHeader(i, s.headers[i]);
            if (s.beforeSend && (s.beforeSend.call(callbackContext, jqXHR, s) === !1 || 2 === state)) return jqXHR.abort();
            strAbort = "abort";
            for (i in {
                success: 1,
                error: 1,
                complete: 1
            }) jqXHR[i](s[i]);
            if (transport = inspectPrefiltersOrTransports(transports, s, options, jqXHR)) {
                jqXHR.readyState = 1, fireGlobals && globalEventContext.trigger("ajaxSend", [ jqXHR, s ]), 
                s.async && s.timeout > 0 && (timeoutTimer = setTimeout(function() {
                    jqXHR.abort("timeout");
                }, s.timeout));
                try {
                    state = 1, transport.send(requestHeaders, done);
                } catch (e) {
                    if (!(2 > state)) throw e;
                    done(-1, e);
                }
            } else done(-1, "No Transport");
            return jqXHR;
        },
        getJSON: function(url, data, callback) {
            return jQuery.get(url, data, callback, "json");
        },
        getScript: function(url, callback) {
            return jQuery.get(url, undefined, callback, "script");
        }
    }), jQuery.each([ "get", "post" ], function(i, method) {
        jQuery[method] = function(url, data, callback, type) {
            return jQuery.isFunction(data) && (type = type || callback, callback = data, data = undefined), 
            jQuery.ajax({
                url: url,
                type: method,
                dataType: type,
                data: data,
                success: callback
            });
        };
    }), jQuery.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /(?:java|ecma)script/
        },
        converters: {
            "text script": function(text) {
                return jQuery.globalEval(text), text;
            }
        }
    }), jQuery.ajaxPrefilter("script", function(s) {
        s.cache === undefined && (s.cache = !1), s.crossDomain && (s.type = "GET", s.global = !1);
    }), jQuery.ajaxTransport("script", function(s) {
        if (s.crossDomain) {
            var script, head = document.head || jQuery("head")[0] || document.documentElement;
            return {
                send: function(_, callback) {
                    script = document.createElement("script"), script.async = !0, s.scriptCharset && (script.charset = s.scriptCharset), 
                    script.src = s.url, script.onload = script.onreadystatechange = function(_, isAbort) {
                        (isAbort || !script.readyState || /loaded|complete/.test(script.readyState)) && (script.onload = script.onreadystatechange = null, 
                        script.parentNode && script.parentNode.removeChild(script), script = null, isAbort || callback(200, "success"));
                    }, head.insertBefore(script, head.firstChild);
                },
                abort: function() {
                    script && script.onload(undefined, !0);
                }
            };
        }
    });
    var oldCallbacks = [], rjsonp = /(=)\?(?=&|$)|\?\?/;
    jQuery.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var callback = oldCallbacks.pop() || jQuery.expando + "_" + ajax_nonce++;
            return this[callback] = !0, callback;
        }
    }), jQuery.ajaxPrefilter("json jsonp", function(s, originalSettings, jqXHR) {
        var callbackName, overwritten, responseContainer, jsonProp = s.jsonp !== !1 && (rjsonp.test(s.url) ? "url" : "string" == typeof s.data && !(s.contentType || "").indexOf("application/x-www-form-urlencoded") && rjsonp.test(s.data) && "data");
        return jsonProp || "jsonp" === s.dataTypes[0] ? (callbackName = s.jsonpCallback = jQuery.isFunction(s.jsonpCallback) ? s.jsonpCallback() : s.jsonpCallback, 
        jsonProp ? s[jsonProp] = s[jsonProp].replace(rjsonp, "$1" + callbackName) : s.jsonp !== !1 && (s.url += (ajax_rquery.test(s.url) ? "&" : "?") + s.jsonp + "=" + callbackName), 
        s.converters["script json"] = function() {
            return responseContainer || jQuery.error(callbackName + " was not called"), responseContainer[0];
        }, s.dataTypes[0] = "json", overwritten = window[callbackName], window[callbackName] = function() {
            responseContainer = arguments;
        }, jqXHR.always(function() {
            window[callbackName] = overwritten, s[callbackName] && (s.jsonpCallback = originalSettings.jsonpCallback, 
            oldCallbacks.push(callbackName)), responseContainer && jQuery.isFunction(overwritten) && overwritten(responseContainer[0]), 
            responseContainer = overwritten = undefined;
        }), "script") : void 0;
    });
    var xhrCallbacks, xhrSupported, xhrId = 0, xhrOnUnloadAbort = window.ActiveXObject && function() {
        var key;
        for (key in xhrCallbacks) xhrCallbacks[key](undefined, !0);
    };
    jQuery.ajaxSettings.xhr = window.ActiveXObject ? function() {
        return !this.isLocal && createStandardXHR() || createActiveXHR();
    } : createStandardXHR, xhrSupported = jQuery.ajaxSettings.xhr(), jQuery.support.cors = !!xhrSupported && "withCredentials" in xhrSupported, 
    xhrSupported = jQuery.support.ajax = !!xhrSupported, xhrSupported && jQuery.ajaxTransport(function(s) {
        if (!s.crossDomain || jQuery.support.cors) {
            var callback;
            return {
                send: function(headers, complete) {
                    var handle, i, xhr = s.xhr();
                    if (s.username ? xhr.open(s.type, s.url, s.async, s.username, s.password) : xhr.open(s.type, s.url, s.async), 
                    s.xhrFields) for (i in s.xhrFields) xhr[i] = s.xhrFields[i];
                    s.mimeType && xhr.overrideMimeType && xhr.overrideMimeType(s.mimeType), s.crossDomain || headers["X-Requested-With"] || (headers["X-Requested-With"] = "XMLHttpRequest");
                    try {
                        for (i in headers) xhr.setRequestHeader(i, headers[i]);
                    } catch (err) {}
                    xhr.send(s.hasContent && s.data || null), callback = function(_, isAbort) {
                        var status, responseHeaders, statusText, responses;
                        try {
                            if (callback && (isAbort || 4 === xhr.readyState)) if (callback = undefined, handle && (xhr.onreadystatechange = jQuery.noop, 
                            xhrOnUnloadAbort && delete xhrCallbacks[handle]), isAbort) 4 !== xhr.readyState && xhr.abort(); else {
                                responses = {}, status = xhr.status, responseHeaders = xhr.getAllResponseHeaders(), 
                                "string" == typeof xhr.responseText && (responses.text = xhr.responseText);
                                try {
                                    statusText = xhr.statusText;
                                } catch (e) {
                                    statusText = "";
                                }
                                status || !s.isLocal || s.crossDomain ? 1223 === status && (status = 204) : status = responses.text ? 200 : 404;
                            }
                        } catch (firefoxAccessException) {
                            isAbort || complete(-1, firefoxAccessException);
                        }
                        responses && complete(status, statusText, responses, responseHeaders);
                    }, s.async ? 4 === xhr.readyState ? setTimeout(callback) : (handle = ++xhrId, xhrOnUnloadAbort && (xhrCallbacks || (xhrCallbacks = {}, 
                    jQuery(window).unload(xhrOnUnloadAbort)), xhrCallbacks[handle] = callback), xhr.onreadystatechange = callback) : callback();
                },
                abort: function() {
                    callback && callback(undefined, !0);
                }
            };
        }
    });
    var fxNow, timerId, rfxtypes = /^(?:toggle|show|hide)$/, rfxnum = new RegExp("^(?:([+-])=|)(" + core_pnum + ")([a-z%]*)$", "i"), rrun = /queueHooks$/, animationPrefilters = [ defaultPrefilter ], tweeners = {
        "*": [ function(prop, value) {
            var tween = this.createTween(prop, value), target = tween.cur(), parts = rfxnum.exec(value), unit = parts && parts[3] || (jQuery.cssNumber[prop] ? "" : "px"), start = (jQuery.cssNumber[prop] || "px" !== unit && +target) && rfxnum.exec(jQuery.css(tween.elem, prop)), scale = 1, maxIterations = 20;
            if (start && start[3] !== unit) {
                unit = unit || start[3], parts = parts || [], start = +target || 1;
                do scale = scale || ".5", start /= scale, jQuery.style(tween.elem, prop, start + unit); while (scale !== (scale = tween.cur() / target) && 1 !== scale && --maxIterations);
            }
            return parts && (start = tween.start = +start || +target || 0, tween.unit = unit, 
            tween.end = parts[1] ? start + (parts[1] + 1) * parts[2] : +parts[2]), tween;
        } ]
    };
    jQuery.Animation = jQuery.extend(Animation, {
        tweener: function(props, callback) {
            jQuery.isFunction(props) ? (callback = props, props = [ "*" ]) : props = props.split(" ");
            for (var prop, index = 0, length = props.length; length > index; index++) prop = props[index], 
            tweeners[prop] = tweeners[prop] || [], tweeners[prop].unshift(callback);
        },
        prefilter: function(callback, prepend) {
            prepend ? animationPrefilters.unshift(callback) : animationPrefilters.push(callback);
        }
    }), jQuery.Tween = Tween, Tween.prototype = {
        constructor: Tween,
        init: function(elem, options, prop, end, easing, unit) {
            this.elem = elem, this.prop = prop, this.easing = easing || "swing", this.options = options, 
            this.start = this.now = this.cur(), this.end = end, this.unit = unit || (jQuery.cssNumber[prop] ? "" : "px");
        },
        cur: function() {
            var hooks = Tween.propHooks[this.prop];
            return hooks && hooks.get ? hooks.get(this) : Tween.propHooks._default.get(this);
        },
        run: function(percent) {
            var eased, hooks = Tween.propHooks[this.prop];
            return this.pos = eased = this.options.duration ? jQuery.easing[this.easing](percent, this.options.duration * percent, 0, 1, this.options.duration) : percent, 
            this.now = (this.end - this.start) * eased + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), 
            hooks && hooks.set ? hooks.set(this) : Tween.propHooks._default.set(this), this;
        }
    }, Tween.prototype.init.prototype = Tween.prototype, Tween.propHooks = {
        _default: {
            get: function(tween) {
                var result;
                return null == tween.elem[tween.prop] || tween.elem.style && null != tween.elem.style[tween.prop] ? (result = jQuery.css(tween.elem, tween.prop, ""), 
                result && "auto" !== result ? result : 0) : tween.elem[tween.prop];
            },
            set: function(tween) {
                jQuery.fx.step[tween.prop] ? jQuery.fx.step[tween.prop](tween) : tween.elem.style && (null != tween.elem.style[jQuery.cssProps[tween.prop]] || jQuery.cssHooks[tween.prop]) ? jQuery.style(tween.elem, tween.prop, tween.now + tween.unit) : tween.elem[tween.prop] = tween.now;
            }
        }
    }, Tween.propHooks.scrollTop = Tween.propHooks.scrollLeft = {
        set: function(tween) {
            tween.elem.nodeType && tween.elem.parentNode && (tween.elem[tween.prop] = tween.now);
        }
    }, jQuery.each([ "toggle", "show", "hide" ], function(i, name) {
        var cssFn = jQuery.fn[name];
        jQuery.fn[name] = function(speed, easing, callback) {
            return null == speed || "boolean" == typeof speed ? cssFn.apply(this, arguments) : this.animate(genFx(name, !0), speed, easing, callback);
        };
    }), jQuery.fn.extend({
        fadeTo: function(speed, to, easing, callback) {
            return this.filter(isHidden).css("opacity", 0).show().end().animate({
                opacity: to
            }, speed, easing, callback);
        },
        animate: function(prop, speed, easing, callback) {
            var empty = jQuery.isEmptyObject(prop), optall = jQuery.speed(speed, easing, callback), doAnimation = function() {
                var anim = Animation(this, jQuery.extend({}, prop), optall);
                (empty || jQuery._data(this, "finish")) && anim.stop(!0);
            };
            return doAnimation.finish = doAnimation, empty || optall.queue === !1 ? this.each(doAnimation) : this.queue(optall.queue, doAnimation);
        },
        stop: function(type, clearQueue, gotoEnd) {
            var stopQueue = function(hooks) {
                var stop = hooks.stop;
                delete hooks.stop, stop(gotoEnd);
            };
            return "string" != typeof type && (gotoEnd = clearQueue, clearQueue = type, type = undefined), 
            clearQueue && type !== !1 && this.queue(type || "fx", []), this.each(function() {
                var dequeue = !0, index = null != type && type + "queueHooks", timers = jQuery.timers, data = jQuery._data(this);
                if (index) data[index] && data[index].stop && stopQueue(data[index]); else for (index in data) data[index] && data[index].stop && rrun.test(index) && stopQueue(data[index]);
                for (index = timers.length; index--; ) timers[index].elem !== this || null != type && timers[index].queue !== type || (timers[index].anim.stop(gotoEnd), 
                dequeue = !1, timers.splice(index, 1));
                (dequeue || !gotoEnd) && jQuery.dequeue(this, type);
            });
        },
        finish: function(type) {
            return type !== !1 && (type = type || "fx"), this.each(function() {
                var index, data = jQuery._data(this), queue = data[type + "queue"], hooks = data[type + "queueHooks"], timers = jQuery.timers, length = queue ? queue.length : 0;
                for (data.finish = !0, jQuery.queue(this, type, []), hooks && hooks.stop && hooks.stop.call(this, !0), 
                index = timers.length; index--; ) timers[index].elem === this && timers[index].queue === type && (timers[index].anim.stop(!0), 
                timers.splice(index, 1));
                for (index = 0; length > index; index++) queue[index] && queue[index].finish && queue[index].finish.call(this);
                delete data.finish;
            });
        }
    }), jQuery.each({
        slideDown: genFx("show"),
        slideUp: genFx("hide"),
        slideToggle: genFx("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, function(name, props) {
        jQuery.fn[name] = function(speed, easing, callback) {
            return this.animate(props, speed, easing, callback);
        };
    }), jQuery.speed = function(speed, easing, fn) {
        var opt = speed && "object" == typeof speed ? jQuery.extend({}, speed) : {
            complete: fn || !fn && easing || jQuery.isFunction(speed) && speed,
            duration: speed,
            easing: fn && easing || easing && !jQuery.isFunction(easing) && easing
        };
        return opt.duration = jQuery.fx.off ? 0 : "number" == typeof opt.duration ? opt.duration : opt.duration in jQuery.fx.speeds ? jQuery.fx.speeds[opt.duration] : jQuery.fx.speeds._default, 
        (null == opt.queue || opt.queue === !0) && (opt.queue = "fx"), opt.old = opt.complete, 
        opt.complete = function() {
            jQuery.isFunction(opt.old) && opt.old.call(this), opt.queue && jQuery.dequeue(this, opt.queue);
        }, opt;
    }, jQuery.easing = {
        linear: function(p) {
            return p;
        },
        swing: function(p) {
            return .5 - Math.cos(p * Math.PI) / 2;
        }
    }, jQuery.timers = [], jQuery.fx = Tween.prototype.init, jQuery.fx.tick = function() {
        var timer, timers = jQuery.timers, i = 0;
        for (fxNow = jQuery.now(); i < timers.length; i++) timer = timers[i], timer() || timers[i] !== timer || timers.splice(i--, 1);
        timers.length || jQuery.fx.stop(), fxNow = undefined;
    }, jQuery.fx.timer = function(timer) {
        timer() && jQuery.timers.push(timer) && jQuery.fx.start();
    }, jQuery.fx.interval = 13, jQuery.fx.start = function() {
        timerId || (timerId = setInterval(jQuery.fx.tick, jQuery.fx.interval));
    }, jQuery.fx.stop = function() {
        clearInterval(timerId), timerId = null;
    }, jQuery.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    }, jQuery.fx.step = {}, jQuery.expr && jQuery.expr.filters && (jQuery.expr.filters.animated = function(elem) {
        return jQuery.grep(jQuery.timers, function(fn) {
            return elem === fn.elem;
        }).length;
    }), jQuery.fn.offset = function(options) {
        if (arguments.length) return options === undefined ? this : this.each(function(i) {
            jQuery.offset.setOffset(this, options, i);
        });
        var docElem, win, box = {
            top: 0,
            left: 0
        }, elem = this[0], doc = elem && elem.ownerDocument;
        if (doc) return docElem = doc.documentElement, jQuery.contains(docElem, elem) ? (typeof elem.getBoundingClientRect !== core_strundefined && (box = elem.getBoundingClientRect()), 
        win = getWindow(doc), {
            top: box.top + (win.pageYOffset || docElem.scrollTop) - (docElem.clientTop || 0),
            left: box.left + (win.pageXOffset || docElem.scrollLeft) - (docElem.clientLeft || 0)
        }) : box;
    }, jQuery.offset = {
        setOffset: function(elem, options, i) {
            var position = jQuery.css(elem, "position");
            "static" === position && (elem.style.position = "relative");
            var curTop, curLeft, curElem = jQuery(elem), curOffset = curElem.offset(), curCSSTop = jQuery.css(elem, "top"), curCSSLeft = jQuery.css(elem, "left"), calculatePosition = ("absolute" === position || "fixed" === position) && jQuery.inArray("auto", [ curCSSTop, curCSSLeft ]) > -1, props = {}, curPosition = {};
            calculatePosition ? (curPosition = curElem.position(), curTop = curPosition.top, 
            curLeft = curPosition.left) : (curTop = parseFloat(curCSSTop) || 0, curLeft = parseFloat(curCSSLeft) || 0), 
            jQuery.isFunction(options) && (options = options.call(elem, i, curOffset)), null != options.top && (props.top = options.top - curOffset.top + curTop), 
            null != options.left && (props.left = options.left - curOffset.left + curLeft), 
            "using" in options ? options.using.call(elem, props) : curElem.css(props);
        }
    }, jQuery.fn.extend({
        position: function() {
            if (this[0]) {
                var offsetParent, offset, parentOffset = {
                    top: 0,
                    left: 0
                }, elem = this[0];
                return "fixed" === jQuery.css(elem, "position") ? offset = elem.getBoundingClientRect() : (offsetParent = this.offsetParent(), 
                offset = this.offset(), jQuery.nodeName(offsetParent[0], "html") || (parentOffset = offsetParent.offset()), 
                parentOffset.top += jQuery.css(offsetParent[0], "borderTopWidth", !0), parentOffset.left += jQuery.css(offsetParent[0], "borderLeftWidth", !0)), 
                {
                    top: offset.top - parentOffset.top - jQuery.css(elem, "marginTop", !0),
                    left: offset.left - parentOffset.left - jQuery.css(elem, "marginLeft", !0)
                };
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var offsetParent = this.offsetParent || docElem; offsetParent && !jQuery.nodeName(offsetParent, "html") && "static" === jQuery.css(offsetParent, "position"); ) offsetParent = offsetParent.offsetParent;
                return offsetParent || docElem;
            });
        }
    }), jQuery.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function(method, prop) {
        var top = /Y/.test(prop);
        jQuery.fn[method] = function(val) {
            return jQuery.access(this, function(elem, method, val) {
                var win = getWindow(elem);
                return val === undefined ? win ? prop in win ? win[prop] : win.document.documentElement[method] : elem[method] : void (win ? win.scrollTo(top ? jQuery(win).scrollLeft() : val, top ? val : jQuery(win).scrollTop()) : elem[method] = val);
            }, method, val, arguments.length, null);
        };
    }), jQuery.each({
        Height: "height",
        Width: "width"
    }, function(name, type) {
        jQuery.each({
            padding: "inner" + name,
            content: type,
            "": "outer" + name
        }, function(defaultExtra, funcName) {
            jQuery.fn[funcName] = function(margin, value) {
                var chainable = arguments.length && (defaultExtra || "boolean" != typeof margin), extra = defaultExtra || (margin === !0 || value === !0 ? "margin" : "border");
                return jQuery.access(this, function(elem, type, value) {
                    var doc;
                    return jQuery.isWindow(elem) ? elem.document.documentElement["client" + name] : 9 === elem.nodeType ? (doc = elem.documentElement, 
                    Math.max(elem.body["scroll" + name], doc["scroll" + name], elem.body["offset" + name], doc["offset" + name], doc["client" + name])) : value === undefined ? jQuery.css(elem, type, extra) : jQuery.style(elem, type, value, extra);
                }, type, chainable ? margin : undefined, chainable, null);
            };
        });
    }), jQuery.fn.size = function() {
        return this.length;
    }, jQuery.fn.andSelf = jQuery.fn.addBack, "object" == typeof module && module && "object" == typeof module.exports ? module.exports = jQuery : "function" == typeof define && define.amd && define("jquery", [], function() {
        return jQuery;
    });
}(window), define("can/util/can", [], function() {
    var can = window.can || {};
    ("undefined" == typeof GLOBALCAN || GLOBALCAN !== !1) && (window.can = can), can.isDeferred = function(obj) {
        var isFunction = this.isFunction;
        return obj && isFunction(obj.then) && isFunction(obj.pipe);
    };
    var cid = 0;
    return can.cid = function(object, name) {
        return object._cid ? object._cid : object._cid = (name || "") + ++cid;
    }, can.VERSION = "@EDGE", can;
}), define("can/util/array/each", [ "can/util/can" ], function(can) {
    return can.each = function(elements, callback, context) {
        var key, i = 0;
        if (elements) if ("number" == typeof elements.length && elements.pop) for (elements.attr && elements.attr("length"), 
        key = elements.length; key > i && callback.call(context || elements[i], elements[i], i, elements) !== !1; i++) ; else if (elements.hasOwnProperty) for (key in elements) if (elements.hasOwnProperty(key) && callback.call(context || elements[key], elements[key], key, elements) === !1) break;
        return elements;
    }, can;
}), define("can/util/jquery", [ "jquery", "can/util/can", "can/util/array/each" ], function($, can) {
    $.extend(can, $, {
        trigger: function(obj, event, args) {
            obj.trigger ? obj.trigger(event, args) : $.event.trigger(event, args, obj, !0);
        },
        addEvent: function(ev, cb) {
            return $([ this ]).bind(ev, cb), this;
        },
        removeEvent: function(ev, cb) {
            return $([ this ]).unbind(ev, cb), this;
        },
        buildFragment: function(elems, context) {
            var ret, oldFragment = $.buildFragment;
            return elems = [ elems ], context = context || document, context = !context.nodeType && context[0] || context, 
            context = context.ownerDocument || context, ret = oldFragment.call(jQuery, elems, context), 
            ret.cacheable ? $.clone(ret.fragment) : ret.fragment || ret;
        },
        $: $,
        each: can.each
    }), $.each([ "bind", "unbind", "undelegate", "delegate" ], function(i, func) {
        can[func] = function() {
            var t = this[func] ? this : $([ this ]);
            return t[func].apply(t, arguments), this;
        };
    }), $.each([ "append", "filter", "addClass", "remove", "data", "get" ], function(i, name) {
        can[name] = function(wrapped) {
            return wrapped[name].apply(wrapped, can.makeArray(arguments).slice(1));
        };
    });
    var oldClean = $.cleanData;
    return $.cleanData = function(elems) {
        $.each(elems, function(i, elem) {
            elem && can.trigger(elem, "destroyed", [], !1);
        }), oldClean(elems);
    }, can;
}), define("jpmc/$", [ "can/util/library" ], function(can) {
    var $;
    return $ = can.$, $.fn && ($.fn.jpmc = !0), $;
}), define("can/util/bind", [ "can/util/library" ], function(can) {
    return can.bindAndSetup = function() {
        return can.addEvent.apply(this, arguments), this._init || (this._bindings ? this._bindings++ : (this._bindings = 1, 
        this._bindsetup && this._bindsetup())), this;
    }, can.unbindAndTeardown = function() {
        return can.removeEvent.apply(this, arguments), this._bindings--, this._bindings || this._bindteardown && this._bindteardown(), 
        this;
    }, can;
}), define("can/util/string", [ "can/util/library" ], function(can) {
    var strUndHash = /_|-/, strColons = /\=\=/, strWords = /([A-Z]+)([A-Z][a-z])/g, strLowUp = /([a-z\d])([A-Z])/g, strDash = /([a-z\d])([A-Z])/g, strReplacer = /\{([^\}]+)\}/g, strQuote = /"/g, strSingleQuote = /'/g, getNext = function(obj, prop, add) {
        var result = obj[prop];
        return void 0 === result && add === !0 && (result = obj[prop] = {}), result;
    }, isContainer = function(current) {
        return /^f|^o/.test(typeof current);
    };
    return can.extend(can, {
        esc: function(content) {
            var isInvalid = null === content || void 0 === content || isNaN(content) && "" + content == "NaN";
            return ("" + (isInvalid ? "" : content)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(strQuote, "&#34;").replace(strSingleQuote, "&#39;");
        },
        getObject: function(name, roots, add) {
            var current, i, container, rootsLength, parts = name ? name.split(".") : [], length = parts.length, r = 0;
            if (roots = can.isArray(roots) ? roots : [ roots || window ], rootsLength = roots.length, 
            !length) return roots[0];
            for (r; rootsLength > r; r++) {
                for (current = roots[r], container = void 0, i = 0; length > i && isContainer(current); i++) container = current, 
                current = getNext(container, parts[i]);
                if (void 0 !== container && void 0 !== current) break;
            }
            if (add === !1 && void 0 !== current && delete container[parts[i - 1]], add === !0 && void 0 === current) for (current = roots[0], 
            i = 0; length > i && isContainer(current); i++) current = getNext(current, parts[i], !0);
            return current;
        },
        capitalize: function(s) {
            return s.charAt(0).toUpperCase() + s.slice(1);
        },
        underscore: function(s) {
            return s.replace(strColons, "/").replace(strWords, "$1_$2").replace(strLowUp, "$1_$2").replace(strDash, "_").toLowerCase();
        },
        sub: function(str, data, remove) {
            var obs = [];
            return str = str || "", obs.push(str.replace(strReplacer, function(whole, inside) {
                var ob = can.getObject(inside, data, remove === !0 ? !1 : void 0);
                return void 0 === ob ? (obs = null, "") : isContainer(ob) && obs ? (obs.push(ob), 
                "") : "" + ob;
            })), null === obs ? obs : obs.length <= 1 ? obs[0] : obs;
        },
        replacer: strReplacer,
        undHash: strUndHash
    }), can;
}), define("can/construct", [ "can/util/string" ], function(can) {
    var initializing = 0;
    return can.Construct = function() {
        return arguments.length ? can.Construct.extend.apply(can.Construct, arguments) : void 0;
    }, can.extend(can.Construct, {
        newInstance: function() {
            var args, inst = this.instance();
            return inst.setup && (args = inst.setup.apply(inst, arguments)), inst.init && inst.init.apply(inst, args || arguments), 
            inst;
        },
        _inherit: function(newProps, oldProps, addTo) {
            can.extend(addTo || newProps, newProps || {});
        },
        _overwrite: function(what, oldProps, propName, val) {
            what[propName] = val;
        },
        setup: function(base) {
            this.defaults = can.extend(!0, {}, base.defaults, this.defaults);
        },
        instance: function() {
            initializing = 1;
            var inst = new this();
            return initializing = 0, inst;
        },
        extend: function(fullName, klass, proto) {
            function Constructor() {
                return initializing ? void 0 : this.constructor !== Constructor && arguments.length ? arguments.callee.extend.apply(arguments.callee, arguments) : this.constructor.newInstance.apply(this.constructor, arguments);
            }
            "string" != typeof fullName && (proto = klass, klass = fullName, fullName = null), 
            proto || (proto = klass, klass = null), proto = proto || {};
            var name, shortName, namespace, prototype, _super_class = this, _super = this.prototype;
            prototype = this.instance(), can.Construct._inherit(proto, _super, prototype);
            for (name in _super_class) _super_class.hasOwnProperty(name) && (Constructor[name] = _super_class[name]);
            if (can.Construct._inherit(klass, _super_class, Constructor), fullName) {
                var parts = fullName.split("."), shortName = parts.pop(), current = can.getObject(parts.join("."), window, !0), namespace = current, _fullName = can.underscore(fullName.replace(/\./g, "_")), _shortName = can.underscore(shortName);
                current[shortName] = Constructor;
            }
            can.extend(Constructor, {
                constructor: Constructor,
                prototype: prototype,
                namespace: namespace,
                _shortName: _shortName,
                fullName: fullName,
                _fullName: _fullName
            }), void 0 !== shortName && (Constructor.shortName = shortName), Constructor.prototype.constructor = Constructor;
            var t = [ _super_class ].concat(can.makeArray(arguments)), args = Constructor.setup.apply(Constructor, t);
            return Constructor.init && Constructor.init.apply(Constructor, args || t), Constructor;
        }
    }), can.Construct;
}), define("can/observe", [ "can/util/library", "can/util/bind", "can/construct" ], function(can) {
    var canMakeObserve = function(obj) {
        return obj && !can.isDeferred(obj) && (can.isArray(obj) || can.isPlainObject(obj) || obj instanceof can.Observe);
    }, unhookup = function(items, namespace) {
        return can.each(items, function(item) {
            item && item.unbind && item.unbind("change" + namespace);
        });
    }, hookupBubble = function(child, prop, parent, Ob, List) {
        return Ob = Ob || Observe, List = List || Observe.List, child instanceof Observe ? parent._bindings && unhookup([ child ], parent._cid) : child = can.isArray(child) ? new List(child) : new Ob(child), 
        parent._bindings && bindToChildAndBubbleToParent(child, prop, parent), child;
    }, bindToChildAndBubbleToParent = function(child, prop, parent) {
        child.bind("change" + parent._cid, function() {
            var args = can.makeArray(arguments), ev = args.shift();
            args[0] = ("*" === prop ? [ parent.indexOf(child), args[0] ] : [ prop, args[0] ]).join("."), 
            ev.triggeredNS = ev.triggeredNS || {}, ev.triggeredNS[parent._cid] || (ev.triggeredNS[parent._cid] = !0, 
            can.trigger(parent, ev, args));
        });
    };
    observeId = 0, serialize = function(observe, how, where) {
        return observe.each(function(val, name) {
            where[name] = canMakeObserve(val) && can.isFunction(val[how]) ? val[how]() : val;
        }), where;
    }, attrParts = function(attr, keepKey) {
        return keepKey ? [ attr ] : can.isArray(attr) ? attr : ("" + attr).split(".");
    }, batchNum = 1, transactions = 0, batchEvents = [], stopCallbacks = [], makeBindSetup = function(wildcard) {
        return function() {
            var parent = this;
            this._each(function(child, prop) {
                child && child.bind && bindToChildAndBubbleToParent(child, wildcard || prop, parent);
            });
        };
    };
    var Observe = can.Map = can.Observe = can.Construct({
        bind: can.bindAndSetup,
        unbind: can.unbindAndTeardown,
        id: "id",
        canMakeObserve: canMakeObserve,
        startBatch: function(batchStopHandler) {
            transactions++, batchStopHandler && stopCallbacks.push(batchStopHandler);
        },
        stopBatch: function(force, callStart) {
            if (force ? transactions = 0 : transactions--, 0 == transactions) {
                var items = batchEvents.slice(0), callbacks = stopCallbacks.slice(0);
                batchEvents = [], stopCallbacks = [], batchNum++, callStart && this.startBatch(), 
                can.each(items, function(args) {
                    can.trigger.apply(can, args);
                }), can.each(callbacks, function(cb) {
                    cb();
                });
            }
        },
        triggerBatch: function(item, event, args) {
            if (!item._init) {
                if (0 == transactions) return can.trigger(item, event, args);
                event = "string" == typeof event ? {
                    type: event
                } : event, event.batchNum = batchNum, batchEvents.push([ item, event, args ]);
            }
        },
        keys: function(observe) {
            var keys = [];
            Observe.__reading && Observe.__reading(observe, "__keys");
            for (var keyName in observe._data) keys.push(keyName);
            return keys;
        }
    }, {
        setup: function(obj) {
            this._data = {}, can.cid(this, ".observe"), this._init = 1, this.attr(obj), this.bind("change" + this._cid, can.proxy(this._changes, this)), 
            delete this._init;
        },
        _bindsetup: makeBindSetup(),
        _bindteardown: function() {
            var cid = this._cid;
            this._each(function(child) {
                unhookup([ child ], cid);
            });
        },
        _changes: function(ev, attr, how, newVal, oldVal) {
            Observe.triggerBatch(this, {
                type: attr,
                batchNum: ev.batchNum
            }, [ newVal, oldVal ]);
        },
        _triggerChange: function() {
            Observe.triggerBatch(this, "change", can.makeArray(arguments));
        },
        _each: function(callback) {
            var data = this.__get();
            for (var prop in data) data.hasOwnProperty(prop) && callback(data[prop], prop);
        },
        attr: function(attr, val) {
            var type = typeof attr;
            return "string" !== type && "number" !== type ? this._attrs(attr, val) : void 0 === val ? (Observe.__reading && Observe.__reading(this, attr), 
            this._get(attr)) : (this._set(attr, val), this);
        },
        each: function() {
            return Observe.__reading && Observe.__reading(this, "__keys"), can.each.apply(void 0, [ this.__get() ].concat(can.makeArray(arguments)));
        },
        removeAttr: function(attr) {
            var isList = this instanceof can.Observe.List, parts = attrParts(attr), prop = parts.shift(), current = isList ? this[prop] : this._data[prop];
            return parts.length ? current.removeAttr(parts) : (isList ? this.splice(prop, 1) : prop in this._data && (delete this._data[prop], 
            prop in this.constructor.prototype || delete this[prop], Observe.triggerBatch(this, "__keys"), 
            this._triggerChange(prop, "remove", void 0, current)), current);
        },
        _get: function(attr) {
            var value = "string" == typeof attr && !!~attr.indexOf(".") && this.__get(attr);
            if (value) return value;
            var parts = attrParts(attr), current = this.__get(parts.shift());
            return parts.length ? current ? current._get(parts) : void 0 : current;
        },
        __get: function(attr) {
            return attr ? this._data[attr] : this._data;
        },
        _set: function(attr, value, keepKey) {
            var parts = attrParts(attr, keepKey), prop = parts.shift(), current = this.__get(prop);
            if (canMakeObserve(current) && parts.length) current._set(parts, value); else {
                if (parts.length) throw "can.Observe: Object does not exist";
                this.__convert && (value = this.__convert(prop, value)), this.__set(prop, value, current);
            }
        },
        __set: function(prop, value, current) {
            if (value !== current) {
                var changeType = this.__get().hasOwnProperty(prop) ? "set" : "add";
                this.___set(prop, canMakeObserve(value) ? hookupBubble(value, prop, this) : value), 
                "add" == changeType && Observe.triggerBatch(this, "__keys", void 0), this._triggerChange(prop, changeType, value, current), 
                current && unhookup([ current ], this._cid);
            }
        },
        ___set: function(prop, val) {
            this._data[prop] = val, prop in this.constructor.prototype || (this[prop] = val);
        },
        bind: can.bindAndSetup,
        unbind: can.unbindAndTeardown,
        serialize: function() {
            return serialize(this, "serialize", {});
        },
        _attrs: function(props, remove) {
            if (void 0 === props) return serialize(this, "attr", {});
            props = can.extend({}, props);
            var prop, newVal, self = this;
            Observe.startBatch(), this.each(function(curVal, prop) {
                return newVal = props[prop], void 0 === newVal ? void (remove && self.removeAttr(prop)) : (self.__convert && (newVal = self.__convert(prop, newVal)), 
                newVal instanceof can.Observe ? self.__set(prop, newVal, curVal) : canMakeObserve(curVal) && canMakeObserve(newVal) && curVal.attr ? curVal.attr(newVal, remove) : curVal != newVal && self.__set(prop, newVal, curVal), 
                void delete props[prop]);
            });
            for (var prop in props) newVal = props[prop], this._set(prop, newVal, !0);
            return Observe.stopBatch(), this;
        },
        compute: function(prop) {
            return can.compute(this, prop);
        }
    }), splice = [].splice, list = Observe({
        setup: function(instances, options) {
            this.length = 0, can.cid(this, ".observe"), this._init = 1, can.isDeferred(instances) ? this.replace(instances) : this.push.apply(this, can.makeArray(instances || [])), 
            this.bind("change" + this._cid, can.proxy(this._changes, this)), can.extend(this, options), 
            delete this._init;
        },
        _triggerChange: function(attr, how, newVal, oldVal) {
            Observe.prototype._triggerChange.apply(this, arguments), ~attr.indexOf(".") || ("add" === how ? (Observe.triggerBatch(this, how, [ newVal, +attr ]), 
            Observe.triggerBatch(this, "length", [ this.length ])) : "remove" === how ? (Observe.triggerBatch(this, how, [ oldVal, +attr ]), 
            Observe.triggerBatch(this, "length", [ this.length ])) : Observe.triggerBatch(this, how, [ newVal, +attr ]));
        },
        __get: function(attr) {
            return attr ? this[attr] : this;
        },
        ___set: function(attr, val) {
            this[attr] = val, +attr >= this.length && (this.length = +attr + 1);
        },
        _each: function(callback) {
            for (var data = this.__get(), i = 0; i < data.length; i++) callback(data[i], i);
        },
        _bindsetup: makeBindSetup("*"),
        serialize: function() {
            return serialize(this, "serialize", []);
        },
        splice: function(index, howMany) {
            var i, args = can.makeArray(arguments);
            for (i = 2; i < args.length; i++) {
                var val = args[i];
                canMakeObserve(val) && (args[i] = hookupBubble(val, "*", this, this.constructor.Observe, this.constructor));
            }
            void 0 === howMany && (howMany = args[1] = this.length - index);
            var removed = splice.apply(this, args);
            return can.Observe.startBatch(), howMany > 0 && (this._triggerChange("" + index, "remove", void 0, removed), 
            unhookup(removed, this._cid)), args.length > 2 && this._triggerChange("" + index, "add", args.slice(2), removed), 
            can.Observe.stopBatch(), removed;
        },
        _attrs: function(items, remove) {
            return void 0 === items ? serialize(this, "attr", []) : (items = can.makeArray(items), 
            Observe.startBatch(), this._updateAttrs(items, remove), void Observe.stopBatch());
        },
        _updateAttrs: function(items, remove) {
            for (var len = Math.min(items.length, this.length), prop = 0; len > prop; prop++) {
                var curVal = this[prop], newVal = items[prop];
                canMakeObserve(curVal) && canMakeObserve(newVal) ? curVal.attr(newVal, remove) : curVal != newVal && this._set(prop, newVal);
            }
            items.length > this.length ? this.push.apply(this, items.slice(this.length)) : items.length < this.length && remove && this.splice(items.length);
        }
    }), getArgs = function(args) {
        return args[0] && can.isArray(args[0]) ? args[0] : can.makeArray(args);
    };
    return can.each({
        push: "length",
        unshift: 0
    }, function(where, name) {
        var orig = [][name];
        list.prototype[name] = function() {
            var res, val, args = [], len = where ? this.length : 0, i = arguments.length;
            for (this.constructor; i--; ) val = arguments[i], args[i] = canMakeObserve(val) ? hookupBubble(val, "*", this, this.constructor.Observe, this.constructor) : val;
            return res = orig.apply(this, args), (!this.comparator || args.length) && this._triggerChange("" + len, "add", args, void 0), 
            res;
        };
    }), can.each({
        pop: "length",
        shift: 0
    }, function(where, name) {
        list.prototype[name] = function() {
            var args = getArgs(arguments), len = where && this.length ? this.length - 1 : 0, res = [][name].apply(this, args);
            return this._triggerChange("" + len, "remove", void 0, [ res ]), res && res.unbind && res.unbind("change" + this._cid), 
            res;
        };
    }), can.extend(list.prototype, {
        indexOf: function(item) {
            return this.attr("length"), can.inArray(item, this);
        },
        join: [].join,
        reverse: [].reverse,
        slice: function() {
            var temp = Array.prototype.slice.apply(this, arguments);
            return new this.constructor(temp);
        },
        concat: function() {
            var args = [];
            return can.each(can.makeArray(arguments), function(arg, i) {
                args[i] = arg instanceof can.Observe.List ? arg.serialize() : arg;
            }), new this.constructor(Array.prototype.concat.apply(this.serialize(), args));
        },
        forEach: function(cb, thisarg) {
            can.each(this, cb, thisarg || this);
        },
        replace: function(newList) {
            return can.isDeferred(newList) ? newList.then(can.proxy(this.replace, this)) : this.splice.apply(this, [ 0, this.length ].concat(can.makeArray(newList || []))), 
            this;
        }
    }), can.List = Observe.List = list, Observe.setup = function() {
        can.Construct.setup.apply(this, arguments), this.List = Observe.List({
            Observe: this
        }, {});
    }, Observe;
}), define("jpmc/observe", [ "can/observe" ], function(canObserve) {
    var Observe;
    return Observe = canObserve;
}), define("jpmc/log/entries", [ "jpmc/observe" ], function(Observe) {
    var entries;
    return entries = new Observe.List([]);
}), define("jpmc/log/level", [], function() {
    function Level(level, name) {
        this.level = level, this.name = name;
    }
    var levels = [ "ALL", "TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL", "OFF" ];
    return Level.prototype = {
        eq: function(level) {
            return level && this.level === level.level;
        },
        gt: function(level) {
            return level && this.level > level.level;
        },
        gte: function(level) {
            return level && this.gt(level) || this.eq(level);
        },
        lt: function(level) {
            return level && this.level < level.level;
        },
        lte: function(level) {
            return level && this.lt(level) || this.eq(level);
        },
        toString: function() {
            return this.name;
        }
    }, Level.constructor = Level.prototype.constructor = Level, Level.prototype.valueOf = Level.prototype.toString, 
    Level.ALL = new Level(Number.MIN_VALUE, "ALL"), Level.TRACE = new Level(1e4, "TRACE"), 
    Level.DEBUG = new Level(2e4, "DEBUG"), Level.INFO = new Level(3e4, "INFO"), Level.WARN = new Level(4e4, "WARN"), 
    Level.ERROR = new Level(5e4, "ERROR"), Level.FATAL = new Level(6e4, "FATAL"), Level.OFF = new Level(Number.MAX_VALUE, "OFF"), 
    Level.forEach = function(callback) {
        for (var i = 0, j = levels.length; j > i; i++) callback(Level[levels[i]]);
    }, Level;
}), define("mout/function/bind", [], function() {
    function slice(arr, offset) {
        return Array.prototype.slice.call(arr, offset || 0);
    }
    function bind(fn, context) {
        var argsArr = slice(arguments, 2);
        return function() {
            return fn.apply(context, argsArr.concat(slice(arguments)));
        };
    }
    return bind;
}), define("jpmc/util/function/bind", [ "require", "jpmc/has/detect/function", "mout/function/bind" ], function(require) {
    var slice = Array.prototype.slice, bind = Function.prototype.bind, has = require("jpmc/has/detect/function");
    return has("function-bind") ? function(fn) {
        return bind.apply(fn, slice.call(arguments, 1));
    } : require("mout/function/bind");
}), define("jpmc/util/object/extend", [ "can/util/library" ], function(can) {
    return can.extend;
}), define("mout/lang/toString", [], function() {
    function toString(val) {
        return null == val ? "" : val.toString();
    }
    return toString;
}), define("mout/string/lowerCase", [ "../lang/toString" ], function(toString) {
    function lowerCase(str) {
        return str = toString(str), str.toLowerCase();
    }
    return lowerCase;
}), define("mout/string/upperCase", [ "../lang/toString" ], function(toString) {
    function upperCase(str) {
        return str = toString(str), str.toUpperCase();
    }
    return upperCase;
}), define("mout/string/sentenceCase", [ "../lang/toString", "./lowerCase", "./upperCase" ], function(toString, lowerCase, upperCase) {
    function sentenceCase(str) {
        return str = toString(str), lowerCase(str).replace(/(^\w)|\.\s+(\w)/gm, upperCase);
    }
    return sentenceCase;
}), define("jpmc/util/string/sentenceCase", [ "mout/string/sentenceCase" ], function(sentenceCase) {
    return sentenceCase;
}), define("mout/time/now", [], function() {
    var now = "function" == typeof Date.now ? Date.now : function() {
        return +new Date();
    };
    return now;
}), define("jpmc/util/time/now", [ "require", "jpmc/has/detect/time", "jpmc/util/object/getPrefixed", "mout/time/now" ], function(require) {
    var now, has = require("jpmc/has/detect/time"), getPrefixed = require("jpmc/util/object/getPrefixed");
    return now = has("performance-now") ? getPrefixed(performance, "now") : has("date-now") ? Date.now : require("mout/time/now");
}), define("jpmc/log", [ "jpmc/log/entries", "jpmc/log/level", "jpmc/util/function/bind", "jpmc/util/object/extend", "jpmc/util/string/sentenceCase", "jpmc/util/time/now" ], function(entries, Level, bind, extend, sentenceCase, now) {
    var Logger, addEntry = function(data) {
        entries.push(data);
    }, timers = {};
    return Logger = function(name) {
        name = name || "app";
        var loggers = {}, logger = loggers[name];
        if (!logger) {
            var shouldLog = function(args) {
                return !Logger.disabled && args.length;
            }, createEntry = function(data) {
                var url = "";
                try {
                    url = window.document.URL || window.location.href;
                } catch (e) {
                    url = "";
                }
                return extend(!0, {
                    name: name,
                    timestamp: now(),
                    url: url
                }, data);
            }, assert = function(expression, message, object) {
                return shouldLog(arguments) && expression !== !0 && addEntry(createEntry({
                    expression: expression,
                    message: message || "Assertion Failure",
                    object: object,
                    level: Level.ERROR,
                    type: "assert"
                })), entries;
            }, time = function(key) {
                if (shouldLog(arguments)) {
                    var entry = createEntry({
                        key: key,
                        level: Level.INFO,
                        type: "time"
                    });
                    timers[key] = entry.timestamp, addEntry(entry);
                }
                return entries;
            }, timeEnd = function(key) {
                if (shouldLog(arguments) && timers[key]) {
                    var entry = createEntry({
                        key: key,
                        level: Level.INFO,
                        start: timers[key],
                        type: "timeEnd"
                    });
                    entry.end = entry.timestamp, entry.elapsed = entry.timestamp - entry.start, delete timers[key], 
                    addEntry(entry);
                }
                return entries;
            };
            logger = {
                assert: assert,
                time: time,
                timeEnd: timeEnd
            }, Level.forEach(function(level) {
                level.eq(Level.ALL) || level.eq(Level.OFF) || (logger[level.name.toLowerCase()] = function() {
                    return shouldLog(arguments) && Logger.isLevelEnabled(level) && addEntry(createEntry({
                        message: Array.prototype.slice.call(arguments),
                        level: level,
                        type: "log"
                    })), entries;
                });
            }), logger.log = logger.debug, loggers[name] = logger;
        }
        return logger;
    }, Logger.Level = Level, Logger.disabled = !1, Logger.threshold = Level.DEBUG, Logger.isLevelEnabled = function(level) {
        return level.gte(Logger.threshold);
    }, Logger.isDisabled = function() {
        return Logger.disabled;
    }, Level.forEach(function(level) {
        Logger["is" + sentenceCase(level.name)] = bind(Logger.isLevelEnabled, Logger, level);
    }), Logger;
}), define("jquery-cookie", [ "jquery" ], function(jQuery) {
    return function($, document, undefined) {
        function raw(s) {
            return s;
        }
        function decoded(s) {
            return decodeURIComponent(s.replace(pluses, " "));
        }
        var pluses = /\+/g;
        $.cookie = function(key, value, options) {
            if (value !== undefined && !/Object/.test(Object.prototype.toString.call(value))) {
                if (options = $.extend({}, $.cookie.defaults, options), null === value && (options.expires = -1), 
                "number" == typeof options.expires) {
                    var days = options.expires, t = options.expires = new Date();
                    t.setDate(t.getDate() + days);
                }
                return value = String(value), document.cookie = [ encodeURIComponent(key), "=", options.raw ? value : encodeURIComponent(value), options.expires ? "; expires=" + options.expires.toUTCString() : "", options.path ? "; path=" + options.path : "", options.domain ? "; domain=" + options.domain : "", options.secure ? "; secure" : "" ].join("");
            }
            options = value || $.cookie.defaults || {};
            for (var parts, decode = options.raw ? raw : decoded, cookies = document.cookie.split("; "), i = 0; parts = cookies[i] && cookies[i].split("="); i++) if (decode(parts.shift()) === key) return decode(parts.join("="));
            return null;
        }, $.cookie.defaults = {}, $.removeCookie = function(key, options) {
            return null !== $.cookie(key, options) ? ($.cookie(key, null, options), !0) : !1;
        };
    }(jQuery, document), jQuery.cookie;
}), define("jpmc/cookie", [ "jpmc/$", "jpmc/log", "jquery-cookie", "jpmc/util/object/extend", "jpmc/has" ], function($, Logger, $cookie, extend) {
    var Cookie, domain = window.document.domain, protocol = window.location.protocol, isLocalEnvironment = /localhost|127\.0\.0\.1/.test(domain), isIPAddress = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(domain), isSecure = /https/.test(protocol), subdomain = function() {
        var subdomain;
        return isLocalEnvironment || (isIPAddress ? subdomain = domain : -1 !== domain.indexOf(".") && (subdomain = "." + domain.split(".").slice(-2).join("."))), 
        subdomain;
    }, cookieDomain = subdomain(), logger = Logger("cookie");
    return Cookie = function(key, options) {
        Cookie.cookies = Cookie.cookies || {};
        var cookie = key && Cookie.cookies[key];
        return cookie || (cookie = {
            settings: options || {},
            erase: function(eraseOptions) {
                var eraseSettings = extend({}, this.settings, eraseOptions || {});
                try {
                    $.removeCookie(key, eraseSettings);
                } catch (e) {
                    logger.error("Unable to erase:", key, ". Error:", e);
                }
            },
            read: function() {
                var value;
                try {
                    value = $.cookie(key);
                } catch (e) {
                    logger.error("Unable to read:", key, ". Error:", e);
                }
                return value;
            },
            write: function(value, writeOptions) {
                var writeSettings = extend({}, this.settings, writeOptions || {});
                try {
                    $.cookie(key, value, writeSettings);
                } catch (e) {
                    logger.error("Unable to write:", key, "=", value, ". Error:", e);
                }
            }
        }, key && (Cookie.cookies[key] = cookie)), cookie;
    }, $.cookie.defaults = extend({
        path: "/",
        secure: isSecure,
        raw: !0
    }, cookieDomain ? {
        domain: cookieDomain
    } : {}), Cookie;
}), define("jpmc/cookie/json", [ "jpmc/cookie", "jpmc/has" ], function(Cookie, has, undefined) {
    var JSONCookie;
    return JSONCookie = function(key) {
        var JC = Cookie(key), api = {
            erase: JC.erase,
            read: function() {
                var jsonValue, value = JC.read();
                try {
                    value && (jsonValue = JSON.parse(value));
                } catch (e) {
                    Cookie.errorTopic.publish(key, value, e);
                }
                return jsonValue;
            },
            write: function(value) {
                if (null !== value && value !== undefined) {
                    var jsonValue = value;
                    try {
                        "string" == typeof value && (jsonValue = JSON.parse(value)), value = JSON.stringify(jsonValue);
                    } catch (e) {
                        Cookie.errorTopic.publish(key, value, e);
                    }
                }
                JC.write(value);
            }
        };
        return api;
    };
}), define("mout/lang/isArray", [ "./isKind" ], function(isKind) {
    var isArray = Array.isArray || function(val) {
        return isKind(val, "Array");
    };
    return isArray;
}), define("jpmc/util/lang/isArray", [ "require", "jpmc/has/detect/array", "mout/lang/isArray" ], function(require) {
    var isArray, has = require("jpmc/has/detect/array");
    return isArray = has("array-isarray") ? Array.isArray : require("mout/lang/isArray");
}), define("jpmc/cookie/persona", [ "jpmc/$", "jpmc/cookie", "jpmc/log", "jpmc/util/lang/isArray", "jpmc/util/function/bind", "jpmc/has" ], function($, Cookie, Logger, isArray, bind, has, undefined) {
    var PersonaCookie, logger = Logger("cookie"), decodeURIComponent = (window.document, 
    window.decodeURIComponent), encodeURIComponent = window.encodeURIComponent, escape = window.escape, unescape = window.unescape, cookieKey = "PC_1_0", deleteAttributes = function(attrs, object) {
        attrs = attrs.split(" ");
        for (var i = 0, j = attrs.length; j > i; i++) object[attrs[i]] !== undefined && delete object[attrs[i]];
    }, isoDate = function() {
        var date, now = new Date();
        if (has("date-toisostring")) date = now.toISOString().split("T")[0]; else {
            var toPaddedString = function(number, length) {
                var string = "" + number;
                length = length || 2;
                for (var i = 0, j = length - string.length; j > i; i++) string = "0" + string;
                return string;
            }, year = now.getFullYear(), month = toPaddedString(now.getMonth() + 1), day = toPaddedString(now.getDate());
            date = [ year, month, day ].join("-");
        }
        return date;
    }, parseAccts = function(value) {
        var accounts = {};
        if (value) for (var i = 0, j = value.length; j > i; i++) {
            var acct = value[i];
            accounts[acct[0]] = {}, accounts[acct[0]].uratc = acct[1], accounts[acct[0]].rwdb = acct[2];
        }
        return accounts;
    }, parsePipedList = function(pipedList) {
        for (var params = trailingSplit(unescape(pipedList), "|"), object = {}, i = 0, j = params.length; j > i; i++) {
            var param = params[i].split("="), key = param[0], value = trailingSplit(decodeURIComponent(param[1]), "&");
            if (isArray(value)) for (var k = 0, l = value.length; l > k; k++) {
                var item = value.shift();
                item = item.split(","), value.push(item);
            } else value = trailingSplit(value, ",");
            object[key] = value;
        }
        return object;
    }, rollUp = function(key, value, object) {
        var entry = object[key];
        if (entry) for (var i = 0, j = entry.length; j > i; i++) if (value == entry[i]) return "Y";
        return "N";
    }, toPipedList = function(object) {
        var isArr, isTwoDimensionalArray, isValid, param, pipedList = [];
        return $.each(object, function(key, value) {
            if (isArr = isArray(value), isTwoDimensionalArray = isArr && !!value.length && isArray(value[0]), 
            isValid = validate(key, value)) {
                if (isTwoDimensionalArray) {
                    for (var i = 0, j = value.length; j > i; i++) {
                        var item = value.shift();
                        item = item.join(","), value.push(item);
                    }
                    value = trailingJoin(value, "&");
                }
                isArr && (value = trailingJoin(value, ",")), param = isTwoDimensionalArray ? escape(key + "=") + value : escape(key + "=" + encodeURIComponent(value)), 
                pipedList.push(param);
            } else logger.error("Invalid key or value:", key + "=" + value);
        }), trailingJoin(pipedList, "|");
    }, trailingJoin = function(array, c) {
        return isArray(array) ? array.join(c) + c : array;
    }, trailingSplit = function(string, c) {
        if (-1 !== string.indexOf(c)) {
            var isCharTrailing = string.charAt(string.length - 1) === c, isEmptyString = isCharTrailing && string.charAt(string.length - 2) === c;
            return (isCharTrailing && !isEmptyString ? string.substring(0, string.length - 1) : string).split(c);
        }
        return string;
    }, validate = function(name, value) {
        var aocRegex = /^([A-Za-z0-9]{1,5}|,)*$/, dateRegex = /^\d{4}-\d{2}-\d{2}$/, knownRegex = /^(Y|N)$/, rpcRegex = /^([A-Za-z0-9]{3,4}|,)*$/, zipRegex = /^\d{5}-?(\d{4})?$/, regexValidator = function(regex, value) {
            return regex.test(value);
        }, validators = {
            AOC: bind(regexValidator, this, aocRegex),
            GUID: bind(regexValidator, this, knownRegex),
            known: bind(regexValidator, this, knownRegex),
            lastSent: bind(regexValidator, this, dateRegex),
            lastUpdate: bind(regexValidator, this, dateRegex),
            RPC: bind(regexValidator, this, rpcRegex),
            segment: function(value) {
                return 3 === value.length;
            },
            source_code_applied: function(value) {
                return 4 === value.length;
            },
            zip: bind(regexValidator, this, zipRegex)
        }, valid = $.isFunction(validators[name]) ? validators[name](value) : !0;
        return valid;
    }, PC = bind(Cookie, this, cookieKey, {
        expires: 365
    });
    return PersonaCookie = function() {
        return {
            erase: function() {
                PC().erase();
            },
            read: function(raw) {
                raw = raw || !1;
                var ret, value = PC().read();
                if (raw) ret = value; else try {
                    value = parsePipedList(value), value.pplr = rollUp("ppl", "A", value), value.fieir = rollUp("fiei", "Y", value), 
                    value.fpeir = rollUp("fpei", "Y", value), value.sieir = rollUp("siei", "Y", value), 
                    value.tieir = rollUp("tiei", "Y", value), value.accounts = parseAccts(value.accts), 
                    ret = value;
                } catch (e) {
                    logger.error("Unable to read:", cookieKey, ". Error:", e);
                }
                return ret;
            },
            write: function(value) {
                try {
                    var lastUpdate = isoDate();
                    "string" == typeof value && (value = parsePipedList(value)), value.lastUpdate = lastUpdate, 
                    value.lastSent = value.lastSent || value.lastUpdate, value.segment && value.seg && delete value.seg, 
                    deleteAttributes("fieir fpeir pplr sieir tieir accounts", value), value = toPipedList(value), 
                    PC().write(value);
                } catch (e) {
                    logger.error("Unable to write:", cookieKey, "=", value, ". Error:", e);
                }
            }
        };
    };
}), define("jpmc/cookie/v1st", [ "jpmc/cookie", "jpmc/log", "jpmc/has" ], function(Cookie, Logger, has, undefined) {
    var VFirstCookie, cookieKey = "v1st", logger = Logger("cookie");
    return VFirstCookie = function() {
        var VC = Cookie(cookieKey), alphanumericRegex = /^\w+$/, api = {
            erase: VC.erase,
            read: function() {
                var value = VC.read();
                return alphanumericRegex.test(value) || (logger.error("Unable to read:", cookieKey, ". Cookie value is invalid."), 
                value = undefined), value;
            },
            write: function(value) {
                null !== value && value !== undefined && alphanumericRegex.test(value) ? VC.write(value) : logger.error("Unable to write:", cookieKey, "=", value, ". Cookie value is invalid.");
            }
        };
        return api;
    };
}), define("jpmc/util/lang/isPlainObject", [ "can/util/library" ], function(can) {
    var isPlainObject;
    return isPlainObject = can.isPlainObject;
}), define("jpmc/cookie/zipcode", [ "jpmc/$", "jpmc/cookie", "jpmc/util/lang/isPlainObject", "jpmc/util/function/bind", "jpmc/has" ], function($, Cookie, isPlainObject, bind) {
    var ZipCodeCookie, parseLocation = function(text) {
        for (var attr, location = {}, attrs = text ? text.split("&") : [], i = 0, j = attrs.length; j > i; i++) attr = attrs[i].split("="), 
        location[attr[0]] = attr[1];
        return location;
    }, ZC = bind(Cookie, this, "chasezip", {
        expires: 365
    });
    return ZipCodeCookie = function() {
        return {
            erase: function() {
                ZC().erase();
            },
            read: function(raw) {
                var value = ZC().read(), location = raw ? value : parseLocation(value);
                return location;
            },
            write: function(value) {
                var location = isPlainObject(value) ? $.param(value) : value;
                ZC().write(location);
            }
        };
    };
}), function(define, global) {
    define("when/when", [], function() {
        function when(promiseOrValue, onFulfilled, onRejected, onProgress) {
            return resolve(promiseOrValue).then(onFulfilled, onRejected, onProgress);
        }
        function Promise(then, inspect) {
            this.then = then, this.inspect = inspect;
        }
        function resolve(value) {
            return promise(function(resolve) {
                resolve(value);
            });
        }
        function reject(promiseOrValue) {
            return when(promiseOrValue, rejected);
        }
        function defer() {
            function makeDeferred(resolvePending, rejectPending, notifyPending) {
                deferred.resolve = deferred.resolver.resolve = function(value) {
                    return resolved ? resolve(value) : (resolved = !0, resolvePending(value), pending);
                }, deferred.reject = deferred.resolver.reject = function(reason) {
                    return resolved ? resolve(rejected(reason)) : (resolved = !0, rejectPending(reason), 
                    pending);
                }, deferred.notify = deferred.resolver.notify = function(update) {
                    return notifyPending(update), update;
                };
            }
            var deferred, pending, resolved;
            return deferred = {
                promise: undef,
                resolve: undef,
                reject: undef,
                notify: undef,
                resolver: {
                    resolve: undef,
                    reject: undef,
                    notify: undef
                }
            }, deferred.promise = pending = promise(makeDeferred), deferred;
        }
        function promise(resolver) {
            return _promise(resolver, monitorApi.PromiseStatus && monitorApi.PromiseStatus());
        }
        function _promise(resolver, status) {
            function then(onFulfilled, onRejected, onProgress) {
                var next = _promise(function(resolve, reject, notify) {
                    function run(p) {
                        p.then(onFulfilled, onRejected, onProgress).then(resolve, reject, notify);
                    }
                    handlers ? handlers.push(run) : enqueue(function() {
                        run(value);
                    });
                }, status && status.observed());
                return next;
            }
            function inspect() {
                return value ? value.inspect() : toPendingState();
            }
            function promiseResolve(val) {
                handlers && (value = coerce(val), scheduleHandlers(handlers, value), handlers = undef, 
                status && value.then(function() {
                    status.fulfilled();
                }, function(r) {
                    status.rejected(r);
                }));
            }
            function promiseReject(reason) {
                promiseResolve(rejected(reason));
            }
            function promiseNotify(update) {
                handlers && scheduleHandlers(handlers, progressing(update));
            }
            var self, value, handlers = [];
            self = new Promise(then, inspect);
            try {
                resolver(promiseResolve, promiseReject, promiseNotify);
            } catch (e) {
                promiseReject(e);
            }
            return self;
        }
        function coerce(x) {
            return x instanceof Promise ? x : x === Object(x) && "then" in x ? promise(function(resolve, reject, notify) {
                enqueue(function() {
                    try {
                        var untrustedThen = x.then;
                        "function" == typeof untrustedThen ? fcall(untrustedThen, x, resolve, reject, notify) : resolve(fulfilled(x));
                    } catch (e) {
                        reject(e);
                    }
                });
            }) : fulfilled(x);
        }
        function fulfilled(value) {
            var self = new Promise(function(onFulfilled) {
                try {
                    return "function" == typeof onFulfilled ? coerce(onFulfilled(value)) : self;
                } catch (e) {
                    return rejected(e);
                }
            }, function() {
                return toFulfilledState(value);
            });
            return self;
        }
        function rejected(reason) {
            var self = new Promise(function(_, onRejected) {
                try {
                    return "function" == typeof onRejected ? coerce(onRejected(reason)) : self;
                } catch (e) {
                    return rejected(e);
                }
            }, function() {
                return toRejectedState(reason);
            });
            return self;
        }
        function progressing(update) {
            var self = new Promise(function(_, __, onProgress) {
                try {
                    return "function" == typeof onProgress ? progressing(onProgress(update)) : self;
                } catch (e) {
                    return progressing(e);
                }
            });
            return self;
        }
        function scheduleHandlers(handlers, value) {
            enqueue(function() {
                for (var handler, i = 0; handler = handlers[i++]; ) handler(value);
            });
        }
        function isPromise(promiseOrValue) {
            return promiseOrValue && "function" == typeof promiseOrValue.then;
        }
        function some(promisesOrValues, howMany, onFulfilled, onRejected, onProgress) {
            return when(promisesOrValues, function(promisesOrValues) {
                function resolveSome(resolve, reject, notify) {
                    function rejecter(reason) {
                        rejectOne(reason);
                    }
                    function fulfiller(val) {
                        fulfillOne(val);
                    }
                    var toResolve, toReject, values, reasons, fulfillOne, rejectOne, len, i;
                    if (len = promisesOrValues.length >>> 0, toResolve = Math.max(0, Math.min(howMany, len)), 
                    values = [], toReject = len - toResolve + 1, reasons = [], toResolve) for (rejectOne = function(reason) {
                        reasons.push(reason), --toReject || (fulfillOne = rejectOne = identity, reject(reasons));
                    }, fulfillOne = function(val) {
                        values.push(val), --toResolve || (fulfillOne = rejectOne = identity, resolve(values));
                    }, i = 0; len > i; ++i) i in promisesOrValues && when(promisesOrValues[i], fulfiller, rejecter, notify); else resolve(values);
                }
                return promise(resolveSome).then(onFulfilled, onRejected, onProgress);
            });
        }
        function any(promisesOrValues, onFulfilled, onRejected, onProgress) {
            function unwrapSingleResult(val) {
                return onFulfilled ? onFulfilled(val[0]) : val[0];
            }
            return some(promisesOrValues, 1, unwrapSingleResult, onRejected, onProgress);
        }
        function all(promisesOrValues, onFulfilled, onRejected, onProgress) {
            return _map(promisesOrValues, identity).then(onFulfilled, onRejected, onProgress);
        }
        function join() {
            return _map(arguments, identity);
        }
        function settle(array) {
            return _map(array, toFulfilledState, toRejectedState);
        }
        function map(array, mapFunc) {
            return _map(array, mapFunc);
        }
        function _map(array, mapFunc, fallback) {
            return when(array, function(array) {
                function resolveMap(resolve, reject, notify) {
                    function resolveOne(item, i) {
                        when(item, mapFunc, fallback).then(function(mapped) {
                            results[i] = mapped, --toResolve || resolve(results);
                        }, reject, notify);
                    }
                    var results, len, toResolve, i;
                    if (toResolve = len = array.length >>> 0, results = [], !toResolve) return void resolve(results);
                    for (i = 0; len > i; i++) i in array ? resolveOne(array[i], i) : --toResolve;
                }
                return promise(resolveMap);
            });
        }
        function reduce(promise, reduceFunc) {
            var args = fcall(slice, arguments, 1);
            return when(promise, function(array) {
                var total;
                return total = array.length, args[0] = function(current, val, i) {
                    return when(current, function(c) {
                        return when(val, function(value) {
                            return reduceFunc(c, value, i, total);
                        });
                    });
                }, reduceArray.apply(array, args);
            });
        }
        function toFulfilledState(x) {
            return {
                state: "fulfilled",
                value: x
            };
        }
        function toRejectedState(x) {
            return {
                state: "rejected",
                reason: x
            };
        }
        function toPendingState() {
            return {
                state: "pending"
            };
        }
        function enqueue(task) {
            1 === handlerQueue.push(task) && nextTick(drainQueue);
        }
        function drainQueue() {
            for (var task, i = 0; task = handlerQueue[i++]; ) task();
            handlerQueue = [];
        }
        function identity(x) {
            return x;
        }
        when.promise = promise, when.resolve = resolve, when.reject = reject, when.defer = defer, 
        when.join = join, when.all = all, when.map = map, when.reduce = reduce, when.settle = settle, 
        when.any = any, when.some = some, when.isPromise = isPromise, Promise.prototype = {
            otherwise: function(onRejected) {
                return this.then(undef, onRejected);
            },
            ensure: function(onFulfilledOrRejected) {
                function injectHandler() {
                    return resolve(onFulfilledOrRejected());
                }
                return this.then(injectHandler, injectHandler)["yield"](this);
            },
            "yield": function(value) {
                return this.then(function() {
                    return value;
                });
            },
            spread: function(onFulfilled) {
                return this.then(function(array) {
                    return all(array, function(array) {
                        return onFulfilled.apply(undef, array);
                    });
                });
            },
            always: function(onFulfilledOrRejected, onProgress) {
                return this.then(onFulfilledOrRejected, onFulfilledOrRejected, onProgress);
            }
        };
        var reduceArray, slice, fcall, nextTick, handlerQueue, setTimeout, funcProto, call, arrayProto, monitorApi, undef;
        return handlerQueue = [], monitorApi = "undefined" != typeof console ? console : when, 
        setTimeout = global.setTimeout, nextTick = "function" == typeof setImmediate ? setImmediate.bind(global) : "object" == typeof process && process.nextTick ? process.nextTick : "object" == typeof vertx ? vertx.runOnLoop : function(task) {
            setTimeout(task, 0);
        }, funcProto = Function.prototype, call = funcProto.call, fcall = funcProto.bind ? call.bind(call) : function(f, context) {
            return f.apply(context, slice.call(arguments, 2));
        }, arrayProto = [], slice = arrayProto.slice, reduceArray = arrayProto.reduce || function(reduceFunc) {
            var arr, args, reduced, len, i;
            if (i = 0, arr = Object(this), len = arr.length >>> 0, args = arguments, args.length <= 1) for (;;) {
                if (i in arr) {
                    reduced = arr[i++];
                    break;
                }
                if (++i >= len) throw new TypeError();
            } else reduced = args[1];
            for (;len > i; ++i) i in arr && (reduced = reduceFunc(reduced, arr[i], i, arr));
            return reduced;
        }, when;
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory();
}, this), define("when", [ "when/when" ], function(main) {
    return main;
}), define("jpmc/jquery/ajax/cache", [ "jpmc/$", "jpmc/log", "when", "jpmc/util/object/extend", "jpmc/util/lang/isPlainObject", "jpmc/util/time/now", "jpmc/has/detect/native" ], function($, log, when, extend, isPlainObject, now, has, undefined) {
    var isValid = function(timestamp, ttl) {
        return now() - timestamp < ttl;
    }, logger = log("ajax"), cachedDataType = "cached", cache = {}, requests = {}, cacheTTL = 100;
    return $.ajaxPrefilter(function(options) {
        if (options.dataType === cachedDataType || options.cacheResponse || options.cacheTTL > 0) {
            options.cacheTTL !== undefined && (cacheTTL = options.cacheTTL), options.cacheResponse = options.cacheTTL = undefined;
            try {
                delete options.cacheResponse, delete options.cacheTTL;
            } catch (e) {}
            return cachedDataType;
        }
    }), $.ajaxTransport(cachedDataType, function(options) {
        options.dataTypes.shift();
        var id = [ options.type, options.url ].join(":"), dataType = options.dataType || options.dataTypes[0];
        return dataType === cachedDataType && (dataType = undefined), {
            send: function(headers, complete) {
                logger.debug("Cached request", id);
                var defer = when.defer(), callback = function(status, data) {
                    var response = {}, statusText = 200 === status ? "OK" : "Not Found";
                    response[dataType] = data, logger.debug(id + ' => "' + statusText + '"'), complete(status, statusText, response), 
                    defer.resolve();
                };
                when(requests[id]).then(function() {
                    requests[id] = defer.promise, cache[id] && (!cache[id].cacheTTL || cache[id].cacheTTL < 0 || isValid(cache[id].timestamp, cache[id].cacheTTL) ? callback(200, cache[id].data) : (cache[id] = null, 
                    delete cache[id])), cache[id] || $.ajax({
                        url: options.url,
                        data: options.data,
                        dataType: dataType
                    }).done(function(data) {
                        cache[id] || (logger.debug("Creating cache for " + id + " lasting " + cacheTTL + "ms"), 
                        cache[id] = {
                            data: data,
                            dataTypes: this.dataTypes,
                            cacheTTL: cacheTTL,
                            timestamp: now()
                        }), callback(200, cache[id].data);
                    }).fail(function(jqXHR, statusText, error) {
                        logger.error(error), callback(404, error);
                    });
                });
            },
            abort: function() {
                logger.debug("Aborting request", id), requests[id] = null, delete requests[id];
            }
        };
    }), $.cachedAjax = function(url, settings) {
        isPlainObject(url) ? (settings = url, url = undefined) : (settings = settings || {}, 
        settings.url = url);
        var options = extend({}, {
            dataType: cachedDataType,
            cacheRespone: !0,
            cacheTTL: 100
        }, settings);
        return $.ajax(options);
    }, $.cachedAjax;
}), function(define) {
    define("when/apply", [], function() {
        var toString = Object.prototype.toString;
        return function(f) {
            return function(array) {
                if ("[object Array]" != toString.call(array)) throw new Error("apply called with non-array arg");
                return f.apply(null, array);
            };
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), define("jpmc/jquery/ajax/cors", [ "jpmc/$", "when", "when/apply", "jpmc/util/object/extend", "jpmc/util/lang/isPlainObject", "jpmc/has/detect/native" ], function($, when, apply, extend, isPlainObject, has, undefined) {
    var slice = Array.prototype.slice, typeHeader = "Content-Type", corsDataType = "cors", defaults = {
        xhrFields: {
            withCredentials: !0
        }
    }, deferred = when.defer(), loaded = deferred.promise;
    return $.ajaxPrefilter(function(options) {
        return (options.dataType === corsDataType || options.crossDomain && options.async && "script" !== options.dataType && "jsonp" !== options.dataType) && (options = extend(!0, {}, defaults, options), 
        !has("xhr-cors") || options.useRPC) ? (require([ "jpmc/io/rpc", "jpmc/uri" ], function() {
            deferred.resolve(slice.call(arguments));
        }), corsDataType) : void 0;
    }), has("xhr-cors") || $.ajaxTransport(corsDataType, function(options, originalOptions, jqXHR) {
        var xhr, xdmDefaults = {
            localPath: "/xdm",
            remotePath: "/FA/xdm",
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        }, cleanUp = function() {
            xhr && xhr.destroy(), xhr = undefined;
        };
        return options.dataTypes.shift(), options = extend(!0, {}, xdmDefaults, options), 
        {
            send: function(requestHeaders, complete) {
                var callback = function(status, statusText, data, responseHeaders) {
                    cleanUp(), complete(status, statusText, data, responseHeaders);
                };
                requestHeaders[typeHeader] = options.contentType, loaded.then(apply(function(RPC, URI) {
                    var requestSettings, url = originalOptions.url, localURI = new URI().resource(""), remoteHref = new URI(url).resource("").pathname(options.remotePath).href(), localHelperHref = localURI.clone().directory(options.localPath).filename("name.html").href();
                    requestHeaders.Origin = localURI.href(), xhr = new RPC({
                        local: localHelperHref,
                        remote: remoteHref + "/cors/",
                        remoteHelper: remoteHref + "/name.html",
                        swf: remoteHref + "/easyxdm.swf"
                    }, {
                        remote: {
                            request: {}
                        }
                    }), requestSettings = {
                        corsPrefiltered: !0,
                        url: url,
                        method: options.type,
                        headers: requestHeaders,
                        type: options.type
                    }, options.timeout && (requestSettings.timeout = options.timeout), originalOptions.data && (requestSettings.data = originalOptions.data), 
                    xhr.request(requestSettings, function(response) {
                        for (var type, data = {}, status = response.status, statusText = 200 === status ? "OK" : "Not Found", contents = options.contents, dataTypes = options.dataTypes, responseHeaders = response.headers || {}, contentType = options.mimeType || responseHeaders[typeHeader] || jqXHR.getResponseHeader(typeHeader) || jqXHR.getResponseHeader(typeHeader.toLowerCase()); "*" === dataTypes[0]; ) dataTypes.shift();
                        if (contentType) {
                            for (type in contents) if (contents[type] && contents[type].test(contentType)) {
                                dataTypes.unshift(type);
                                break;
                            }
                        } else dataTypes.unshift("text");
                        options.dataType = dataTypes[0], data[dataTypes[0]] = response.data, callback(status, statusText, data, responseHeaders);
                    });
                }));
            },
            abort: function() {
                cleanUp();
            }
        };
    }), $.corsAjax = function(url, settings) {
        isPlainObject(url) ? (settings = url, url = undefined) : (settings = settings || {}, 
        settings.url = url);
        var options = extend({
            dataType: "html"
        }, settings);
        return $.ajax(options);
    }, $.corsAjax;
}), define("jpmc/jquery/ajax/css", [ "jpmc/$", "when", "jpmc/has/detect/native" ], function($, when, has, undefined) {
    var timer, clearInterval = window.clearInterval, setInterval = window.setInterval, setTimeout = window.setTimeout, $head = document.head || document.getElementsByTagName("head")[0] || document.documentElement, emptyURL = "data:text/css,", pollingId = 0, pollingCount = 0, polled = {}, poller = function() {
        var sheet;
        for (var id in polled) {
            sheet = polled[id].sheet;
            try {
                (sheet && !sheet.cssRules || !sheet.cssRules.length) && polled[id].onload();
            } catch (e) {
                (1e3 === e.code || /security|denied/.test(e.message)) && polled[id].onload();
            }
        }
    }, loadCSS = function(options, polling, callback) {
        var id, link = $("<link/>", {
            charset: options.scriptCharset || "",
            media: options.media || "all",
            rel: "stylesheet",
            type: "text/css"
        }).appendTo($head)[0];
        return polling && (polled[id = pollingId++] = link, pollingCount++ || (timer = setInterval(poller, 13))), 
        link.onload = function(cancel) {
            link.onload && (polling && (delete polled[id], !--pollingCount && clearInterval(timer)), 
            link.onload = null, cancel ? (link.href = emptyURL, $head.removeChild(link)) : callback(link));
        }, link.href = options.url, link.onload;
    }, needsPolling = function() {
        var deferred = when.defer(), onload = loadCSS({
            url: emptyURL
        }, !1, function() {
            deferred.resolve(!1);
        });
        return setTimeout(function() {
            onload(!0), deferred.resolve(!0);
        }), deferred.promise;
    }();
    return $.ajaxPrefilter("css", function(options) {
        options.cache = options.cache || !1, options.type = "GET", options.async = !0, options.global = !1;
    }), $.ajaxTransport("css", function(options) {
        var cancel;
        return {
            send: function(headers, complete) {
                cancel = $.noop, needsPolling.done(function(polling) {
                    cancel && (cancel = loadCSS(options, polling, function(link) {
                        cancel = undefined, complete(200, "OK", {
                            css: $(link)
                        });
                    }));
                });
            },
            abort: function() {
                if (cancel) {
                    var tmp = cancel;
                    cancel = undefined, tmp(!0);
                }
            }
        };
    }), $.getStyleSheet = function(url, callback) {
        return $.ajax({
            url: url,
            dataType: "css"
        }).done(function() {
            $.isFunction(callback) && callback();
        });
    }, $.getStyleSheet;
}), define("jpmc/jquery/ajax/image", [ "jpmc/$", "jpmc/has/detect/native" ], function($) {
    return $.ajaxPrefilter("image", function(options) {
        options.cache = null === options.cache ? !1 : !0, options.type = "GET", options.async = !0;
    }), $.ajaxTransport("image", function(options) {
        var image;
        return {
            send: function(headers, complete) {
                function callback(status) {
                    if (image) {
                        var img = image, statusText = 200 === status ? "OK" : "Not Found";
                        callback = image = image.onload = image.onreadystatechange = image.onerror = null, 
                        complete(status, statusText, {
                            image: img
                        });
                    }
                }
                image = new Image(), image.onreadystatechange = image.onload = function() {
                    callback(200);
                }, image.onerror = function() {
                    callback(404);
                }, image.src = options.url;
            },
            abort: function() {
                image && (image = image.onload = image.onreadystatechange = image.onerror = null);
            }
        };
    }), $.getImage = function(url, callback) {
        return $.ajax({
            url: url,
            dataType: "image"
        }).done(function() {
            $.isFunction(callback) && callback.apply(this, arguments);
        });
    }, $.getImage;
}), define("jpmc/jquery/ajax/manager", [ "jpmc/$", "jpmc/util/object/extend", "jpmc/util/lang/isPlainObject", "jpmc/has/detect/native" ], function($, extend, isPlainObject, has, undefined) {
    var parseInt = window.parseInt, requests = {}, managedDataType = "managed", abortXHR = function(xhr) {
        xhr && (xhr.abort(), xhr = undefined);
    }, onAbort = function(settings) {
        settings.abort && settings.abort.call(settings.context || settings);
    }, isXHRAborted = function(xhr) {
        return !(xhr && 0 !== xhr.readyState);
    }, createRequestKey = function(settings) {
        var type = settings.type, url = settings.url, data = settings.data || {}, params = isPlainObject(data) ? $.param(data) : data;
        return [ type, url, params ].join(":");
    }, addRequest = function(key, xhr) {
        var entry = requests[key] = requests[key] || [];
        return entry.push(xhr), key + ":" + entry.length;
    }, parseKeyFromId = function(id) {
        return id.slice(0, id.lastIndexOf(":"));
    }, removeRequest = function(id) {
        var index = parseInt(id.charAt(id.length - 1)) - 1, key = parseKeyFromId(id), entry = requests[key];
        entry && (entry.splice(index, 1), entry.length || (entry = requests[key] = undefined, 
        delete requests[key]));
    };
    return $.ajaxPrefilter(function(options, originalOptions, jqXHR) {
        if (options.dataType === managedDataType || options.preventDuplicates || options.abort || options.abortOld) {
            var key = createRequestKey(options), beforeSendCallback = options.beforeSend;
            if (!requests[key] || !options.preventDuplicates) {
                var id = options.requestId = addRequest(key, jqXHR);
                return beforeSendCallback && (options.beforeSend = function() {
                    var ret = beforeSendCallback.apply(options.context || options, arguments);
                    return ret === !1 && removeRequest(id), ret;
                }), managedDataType;
            }
            abortXHR(jqXHR);
        }
    }), $.ajaxTransport(managedDataType, function(options, originalOptions) {
        options.dataTypes.shift(), options.dataType = options.dataTypes[0];
        var id = options.requestId, key = parseKeyFromId(id), exclusions = /abort(Old)?|preventDuplicates|beforeSend|complete|dataFilter|error|success/, settings = {}, dataType = options.dataType || options.dataTypes[0] || "text";
        return $.each(originalOptions, function(name, value) {
            exclusions.test(name) || (settings[name] = value);
        }), settings.dataType = dataType, {
            send: function(headers, complete) {
                var callback = function(status, data) {
                    var statusText, response = {};
                    switch (status) {
                      case 0:
                        statusText = "Abort";
                        break;

                      case 200:
                        statusText = "Ok";
                        break;

                      case 404:
                        statusText = "Not Found";
                    }
                    response[dataType] = data, complete(status, statusText, response);
                };
                requests[key] && $.ajax(settings).done(function(data, statusText, jqXHR) {
                    if (isXHRAborted(jqXHR)) jqXHR = undefined, callback(0); else {
                        if (options.abortOld) {
                            var oldId;
                            $.each(requests, function(oldKey, oldXHRs) {
                                for (var i = 0, j = oldXHRs; j > i; i++) oldId = oldKey + ":" + (i + 1), id !== oldId && abortXHR(oldXHRs[i]);
                            });
                        }
                        callback(200, data);
                    }
                }).fail(function(jqXHR, statusText, error) {
                    callback(404, error);
                }).always(function(data, statusText, jqXHR) {
                    isXHRAborted(jqXHR) && (statusText = "Abort", onAbort(options)), removeRequest(id);
                });
            },
            abort: function() {
                onAbort(options), removeRequest(id);
            }
        };
    }), $.managedAjax = function(url, settings) {
        isPlainObject(url) ? (settings = url, url = undefined) : (settings = settings || {}, 
        settings.url = url);
        var options = extend({
            dataType: managedDataType,
            abortOld: !0,
            preventDuplicates: !0
        }, settings);
        return $.ajax(options);
    }, $.managedAjax;
}), define("mout/array/indexOf", [], function() {
    function indexOf(arr, item, fromIndex) {
        if (fromIndex = fromIndex || 0, null == arr) return -1;
        for (var len = arr.length, i = 0 > fromIndex ? len + fromIndex : fromIndex; len > i; ) {
            if (arr[i] === item) return i;
            i++;
        }
        return -1;
    }
    return indexOf;
}), define("jpmc/util/array/indexOf", [ "require", "jpmc/has/detect/array", "mout/array/indexOf" ], function(require) {
    var indexOf, has = require("jpmc/has/detect/array");
    return indexOf = has("array-indexof") ? function(array, item, fromIndex) {
        return Array.prototype.indexOf.call(array, item, fromIndex || 0);
    } : require("mout/array/indexOf");
}), define("jpmc/jquery/ajax/queue", [ "jpmc/$", "jpmc/util/object/extend", "jpmc/util/lang/isPlainObject", "jpmc/util/array/indexOf", "jpmc/has/detect/native" ], function($, extend, isPlainObject, indexOf, has, undefined) {
    var defaultQueueName = "ajax", queuedDataType = "queued", ajaxQueue = $({}), inProgress = 0;
    return $.ajaxPrefilter(function(options) {
        return options.dataType === queuedDataType || options.queue || options.queueName || options.maxRequests ? (options.queueName = options.queueName || defaultQueueName, 
        options.maxRequests = options.maxRequests || 1, options.clearQueue && ajaxQueue.clearQueue(options.queueName), 
        queuedDataType) : void 0;
    }), $.ajaxTransport(queuedDataType, function(options) {
        var request, queueName = options.queueName, maxRequests = options.maxRequests, exclusions = "beforeSend clearQueue complete error maxRequests queue queueName success".split(" "), settings = {};
        return options.dataTypes.shift(), $.each(options, function(key, value) {
            -1 === indexOf(exclusions, key) && (settings[key] = value);
        }), {
            send: function(headers, complete) {
                var callback = function(status, dataType, data, jqXHR) {
                    var response = {}, xml = jqXHR.responseXML, text = jqXHR.responseText, statusText = 200 === status ? "OK" : "Not Found";
                    response[dataType] = data, response.text = text, xml && xml.documentElement && (response.xml = jqXHR.responseXML), 
                    complete(status, statusText, response);
                }, request = function(next) {
                    inProgress++, $.ajax(settings).done(function(data, statusText, jqXHR) {
                        callback(200, settings.dataType || "text", data, jqXHR);
                    }).fail(function(jqXHR, statusText, error) {
                        callback(404, "error", error, jqXHR);
                    }).always(function() {
                        inProgress--, maxRequests > inProgress && ajaxQueue.queue(queueName).length && next();
                    });
                };
                ajaxQueue.queue(queueName, request), maxRequests > inProgress && ajaxQueue.queue(queueName).length && ajaxQueue.dequeue(queueName);
            },
            abort: function() {
                var queue = ajaxQueue.queue(queueName), index = indexOf(queue, request);
                index > -1 && queue.splice(index, 1);
            }
        };
    }), $.queuedAjax = function(url, settings) {
        isPlainObject(url) ? (settings = url, url = undefined) : (settings = settings || {}, 
        settings.url = url);
        var options = extend({
            dataType: queuedDataType,
            queue: !0,
            queueName: defaultQueueName,
            maxRequests: 1
        }, settings);
        return $.ajax(options);
    }, $.queuedAjax;
}), define("can/construct/super", [ "can/util/library", "can/construct" ], function(can) {
    var isFunction = can.isFunction, fnTest = /xyz/.test(function() {}) ? /\b_super\b/ : /.*/;
    return can.Construct._overwrite = function(addTo, base, name, val) {
        addTo[name] = isFunction(val) && isFunction(base[name]) && fnTest.test(val) ? function(name, fn) {
            return function() {
                var ret, tmp = this._super;
                return this._super = base[name], ret = fn.apply(this, arguments), this._super = tmp, 
                ret;
            };
        }(name, val) : val;
    }, can.Construct._inherit = function(newProps, oldProps, addTo) {
        addTo = addTo || newProps;
        for (var name in newProps) can.Construct._overwrite(addTo, oldProps, name, newProps[name]);
    }, can;
}), define("mout/object/hasOwn", [], function() {
    function hasOwn(obj, prop) {
        return Object.prototype.hasOwnProperty.call(obj, prop);
    }
    return hasOwn;
}), define("mout/object/forIn", [], function() {
    function checkDontEnum() {
        _dontEnums = [ "toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor" ], 
        _hasDontEnumBug = !0;
        for (var key in {
            toString: null
        }) _hasDontEnumBug = !1;
    }
    function forIn(obj, fn, thisObj) {
        var key, i = 0;
        null == _hasDontEnumBug && checkDontEnum();
        for (key in obj) if (exec(fn, obj, key, thisObj) === !1) break;
        if (_hasDontEnumBug) for (;(key = _dontEnums[i++]) && (obj[key] === Object.prototype[key] || exec(fn, obj, key, thisObj) !== !1); ) ;
    }
    function exec(fn, obj, key, thisObj) {
        return fn.call(thisObj, obj[key], key, obj);
    }
    var _hasDontEnumBug, _dontEnums;
    return forIn;
}), define("mout/object/forOwn", [ "./hasOwn", "./forIn" ], function(hasOwn, forIn) {
    function forOwn(obj, fn, thisObj) {
        forIn(obj, function(val, key) {
            return hasOwn(obj, key) ? fn.call(thisObj, obj[key], key, obj) : void 0;
        });
    }
    return forOwn;
}), define("jpmc/util/object/forOwn", [ "mout/object/forOwn" ], function(forOwn) {
    return forOwn;
}), define("jpmc/construct", [ "can/construct/super", "jpmc/util/lang/isPlainObject", "jpmc/util/object/extend", "jpmc/util/object/forOwn" ], function(can, isPlainObject, extend, forOwn, undefined) {
    var Construct = can.Construct({
        extend: function() {
            var superValue, Constructor = this._super.apply(this, arguments);
            return forOwn(Constructor.prototype, function(value, key) {
                if (superValue = this.prototype[key], isPlainObject(value) && value._super === !0) {
                    if (!isPlainObject(superValue)) throw new Error("No _super value for plain object: " + key);
                    extend(!0, value, superValue), value._super = undefined;
                    try {
                        delete value._super;
                    } catch (e) {}
                }
            }, this), Constructor;
        },
        newInstance: function() {
            var instance = this._super.apply(this, arguments);
            return instance.initialized && instance.initialized.call(instance, instance.options), 
            instance;
        }
    }, {});
    return Construct;
}), define("jpmc/error/implementation", [], function() {
    var name = "ImplementationError", message = "Required function not implemented";
    return ImplementationError = function(msg) {
        var err = new Error();
        this.name = name, this.message = message + (msg ? ": " + msg : ""), err.stack && (this.stack = err.stack);
    }, err = new Error(), ImplementationError.prototype = err, ImplementationError.constructor = ImplementationError, 
    ImplementationError;
}), define("jpmc/log/layout", [ "jpmc/util/object/extend", "jpmc/util/lang/isArray", "jpmc/util/lang/isPlainObject", "jpmc/construct", "jpmc/error/implementation" ], function(extend, isArray, isPlainObject, Construct, ImplementationError) {
    var Layout = Construct({
        defaults: {
            batchHeader: "",
            batchFooter: "",
            batchSeparator: ""
        },
        batchSupport: !0,
        contentType: "text/plain",
        postData: !1
    }, {
        setup: function(options) {
            return this.options = extend({}, this.constructor.defaults, options || {}), [ this.options ];
        },
        format: function() {
            throw new ImplementationError("format()");
        },
        getContentType: function() {
            return this.constructor.contentType;
        },
        isBatchSupported: function() {
            return this.constructor.batchSupport;
        },
        isPostData: function() {
            return this.constructor.postData;
        },
        stringify: function(value) {
            var result = "";
            if (isArray(value)) for (var i = 0, j = value.length; j > i; i++) result += this.stringify(value[i]), 
            result && (result += " "); else result = isPlainObject(value) ? JSON.stringify(value) : "" + value;
            return result;
        },
        toString: function() {
            return "Layout";
        }
    });
    return Layout.prototype.valueOf = Layout.prototype.toString, Layout;
}), define("jpmc/log/layout/null", [ "jpmc/log/layout" ], function(Layout) {
    var NullLayout = Layout({
        defaults: {
            contentType: "text/javascript"
        }
    }, {
        format: function(entry) {
            return entry;
        },
        toString: function() {
            return "NullLayout";
        }
    });
    return NullLayout.prototype.valueOf = NullLayout.prototype.toString, NullLayout;
}), define("jpmc/log/appender", [ "jpmc/util/object/extend", "jpmc/construct", "jpmc/log/layout/null", "jpmc/log/level", "jpmc/log/entries", "jpmc/error/implementation" ], function(extend, Construct, NullLayout, Level, entries, ImplementationError) {
    var Appender = Construct({
        defaults: {
            layout: new NullLayout(),
            threshold: Level.ALL
        }
    }, {
        enabled: !1,
        init: function(options) {
            this.start(options);
        },
        append: function() {
            throw new ImplementationError("append()");
        },
        destroy: function() {
            this.stop();
            var layout = this.getLayout();
            layout || layout.destroy();
        },
        _disable: function() {
            this.enabled = !1;
        },
        doAppend: function(entry) {
            this.enabled && entry.level.gte(this.options.threshold) && this.append(this.getLayout().format(entry), entry);
        },
        _enable: function() {
            this.enabled = !0;
        },
        getLayout: function() {
            return this.options.layout;
        },
        isEnabled: function() {
            return this.enabled;
        },
        start: function(options) {
            if (!this.isEnabled()) {
                this.options = extend({}, this.constructor.defaults, options || {});
                var that = this, appendHandler = this.appendHandler = function(event, entry) {
                    entry = entry[0].attr(), that.doAppend.call(that, entry);
                };
                entries.bind("add", appendHandler), this._enable();
            }
        },
        stop: function() {
            this.isEnabled() && (entries.unbind("add", this.appendHandler), delete this.appendHandler, 
            this._disable());
        },
        toString: function() {
            return "Appender";
        }
    });
    return Appender.prototype.valueOf = Appender.prototype.toString, Appender;
}), define("jpmc/log/appender/singleton", [ "jpmc/log/appender" ], function(Appender) {
    var SingletonAppender = Appender({
        enabled: !1
    }, {
        _disable: function() {
            this.constructor.enabled = !1;
        },
        _enable: function() {
            this.constructor.enabled = !0;
        },
        isEnabled: function() {
            return this.constructor.enabled;
        },
        toString: function() {
            return "SingletonAppender";
        }
    });
    SingletonAppender.prototype.valueOf = SingletonAppender.prototype.toString, SingletonAppender.prototype.enabled = void 0;
    try {
        delete SingletonAppender.prototype.enabled;
    } catch (e) {}
    return SingletonAppender;
}), define("jpmc/log/layout/simple", [ "jpmc/log/layout" ], function(Layout) {
    var SimpleLayout = Layout({
        format: function(entry) {
            var bracket = function(text) {
                return "[" + text + "]";
            }, timestamp = bracket(entry.timestamp), name = bracket(entry.name), types = {
                assert: function() {
                    var formattedEntry = [ timestamp, name, entry.message ];
                    return entry.object && formattedEntry.push(entry.object), formattedEntry;
                },
                log: function() {
                    return [ timestamp, name, entry.level ].concat(entry.message);
                },
                time: function() {
                    return [ timestamp, name, "Timing", entry.key ];
                },
                timeEnd: function() {
                    return [ timestamp, name, entry.key + ":", entry.elapsed + "ms" ];
                }
            };
            return types[entry.type] && types[entry.type]();
        }
    });
    return SimpleLayout.prototype.valueOf = SimpleLayout.prototype.toString, SimpleLayout;
}), define("jpmc/log/appender/console", [ "jpmc/util/lang/isFunction", "jpmc/has", "jpmc/log/appender/singleton", "jpmc/log/layout/simple", "jpmc/log/level" ], function(isFunction, has, SingletonAppender, SimpleLayout, Level) {
    {
        var ConsoleAppender, call = Function.prototype.call, console = (Array.prototype.join, 
        window.console);
        "debug log info warn error".split(" ");
    }
    return ConsoleAppender = SingletonAppender({
        defaults: {
            threshold: Level.DEBUG,
            layout: new SimpleLayout()
        }
    }, {
        append: function(formattedEntry, entry) {
            if (has("console-" + entry.type.toLowerCase())) {
                var types = {
                    assert: function() {
                        console && console.assert(entry.expression, entry.message, entry.object);
                    },
                    log: function() {
                        var method = entry.level.name.toLowerCase(), args = formattedEntry;
                        "fatal" === method ? method = "error" : "trace" === method && (method = "debug"), 
                        has("console-" + method) || (method = "log"), args.splice(2, 1), args.unshift(console);
                        try {
                            call.apply(console[method], args);
                        } catch (e) {
                            console[method](args.join(""));
                        }
                    },
                    time: function() {
                        console && console.time(entry.key);
                    },
                    timeEnd: function() {
                        console && console.timeEnd(entry.key);
                    }
                };
                return types[entry.type] && types[entry.type]();
            }
            if (console) try {
                call.apply(console.log, formattedEntry);
            } catch (e) {
                console.log(formattedEntry.join(""));
            }
        },
        toString: function() {
            return "ConsoleAppender";
        }
    }), ConsoleAppender.prototype.valueOf = ConsoleAppender.prototype.toString, ConsoleAppender;
}), define("mout/string/replaceAccents", [ "../lang/toString" ], function(toString) {
    function replaceAccents(str) {
        return str = toString(str), str.search(/[\xC0-\xFF]/g) > -1 && (str = str.replace(/[\xC0-\xC5]/g, "A").replace(/[\xC6]/g, "AE").replace(/[\xC7]/g, "C").replace(/[\xC8-\xCB]/g, "E").replace(/[\xCC-\xCF]/g, "I").replace(/[\xD0]/g, "D").replace(/[\xD1]/g, "N").replace(/[\xD2-\xD6\xD8]/g, "O").replace(/[\xD9-\xDC]/g, "U").replace(/[\xDD]/g, "Y").replace(/[\xDE]/g, "P").replace(/[\xE0-\xE5]/g, "a").replace(/[\xE6]/g, "ae").replace(/[\xE7]/g, "c").replace(/[\xE8-\xEB]/g, "e").replace(/[\xEC-\xEF]/g, "i").replace(/[\xF1]/g, "n").replace(/[\xF2-\xF6\xF8]/g, "o").replace(/[\xF9-\xFC]/g, "u").replace(/[\xFE]/g, "p").replace(/[\xFD\xFF]/g, "y")), 
        str;
    }
    return replaceAccents;
}), define("mout/string/removeNonWord", [ "../lang/toString" ], function(toString) {
    function removeNonWord(str) {
        return str = toString(str), str.replace(/[^0-9a-zA-Z\xC0-\xFF \-_]/g, "");
    }
    return removeNonWord;
}), define("mout/string/WHITE_SPACES", [], function() {
    return [ " ", "\n", "\r", "	", "\f", "", "\xa0", "\u1680", "\u180e", "\u2000", "\u2001", "\u2002", "\u2003", "\u2004", "\u2005", "\u2006", "\u2007", "\u2008", "\u2009", "\u200a", "\u2028", "\u2029", "\u202f", "\u205f", "\u3000" ];
}), define("mout/string/ltrim", [ "../lang/toString", "./WHITE_SPACES" ], function(toString, WHITE_SPACES) {
    function ltrim(str, chars) {
        str = toString(str), chars = chars || WHITE_SPACES;
        for (var i, c, start = 0, len = str.length, charLen = chars.length, found = !0; found && len > start; ) for (found = !1, 
        i = -1, c = str.charAt(start); ++i < charLen; ) if (c === chars[i]) {
            found = !0, start++;
            break;
        }
        return start >= len ? "" : str.substr(start, len);
    }
    return ltrim;
}), define("mout/string/rtrim", [ "../lang/toString", "./WHITE_SPACES" ], function(toString, WHITE_SPACES) {
    function rtrim(str, chars) {
        str = toString(str), chars = chars || WHITE_SPACES;
        for (var i, c, end = str.length - 1, charLen = chars.length, found = !0; found && end >= 0; ) for (found = !1, 
        i = -1, c = str.charAt(end); ++i < charLen; ) if (c === chars[i]) {
            found = !0, end--;
            break;
        }
        return end >= 0 ? str.substring(0, end + 1) : "";
    }
    return rtrim;
}), define("mout/string/trim", [ "../lang/toString", "./WHITE_SPACES", "./ltrim", "./rtrim" ], function(toString, WHITE_SPACES, ltrim, rtrim) {
    function trim(str, chars) {
        return str = toString(str), chars = chars || WHITE_SPACES, ltrim(rtrim(str, chars), chars);
    }
    return trim;
}), define("mout/string/slugify", [ "../lang/toString", "./replaceAccents", "./removeNonWord", "./trim" ], function(toString, replaceAccents, removeNonWord, trim) {
    function slugify(str, delimeter) {
        return str = toString(str), null == delimeter && (delimeter = "-"), str = replaceAccents(str), 
        str = removeNonWord(str), str = trim(str).replace(/ +/g, delimeter).toLowerCase();
    }
    return slugify;
}), define("mout/string/unCamelCase", [ "../lang/toString" ], function(toString) {
    function unCamelCase(str, delimiter) {
        function join(str, c1, c2) {
            return c1 + delimiter + c2;
        }
        return null == delimiter && (delimiter = " "), str = toString(str), str = str.replace(CAMEL_CASE_BORDER, join), 
        str = str.toLowerCase();
    }
    var CAMEL_CASE_BORDER = /([a-z\xE0-\xFF])([A-Z\xC0\xDF])/g;
    return unCamelCase;
}), define("mout/string/hyphenate", [ "../lang/toString", "./slugify", "./unCamelCase" ], function(toString, slugify, unCamelCase) {
    function hyphenate(str) {
        return str = toString(str), str = unCamelCase(str), slugify(str, "-");
    }
    return hyphenate;
}), define("jpmc/util/string/hyphenate", [ "mout/string/hyphenate" ], function(hyphenate) {
    return hyphenate;
}), define("mout/lang/isEmpty", [ "../object/forOwn", "./isArray" ], function(forOwn, isArray) {
    function isEmpty(val) {
        if (null == val) return !1;
        if ("string" == typeof val || isArray(val)) return !val.length;
        if ("object" == typeof val || "function" == typeof val) {
            var result = !0;
            return forOwn(val, function() {
                return result = !1, !1;
            }), result;
        }
        return !1;
    }
    return isEmpty;
}), define("jpmc/util/lang/isEmpty", [ "mout/lang/isEmpty" ], function(moutIsEmpty) {
    var isEmpty;
    return isEmpty = moutIsEmpty;
}), define("can/model", [ "can/util/library", "can/observe" ], function(can) {
    var pipe = function(def, model, func) {
        var d = new can.Deferred();
        return def.then(function() {
            var args = can.makeArray(arguments);
            args[0] = model[func](args[0]), d.resolveWith(d, args);
        }, function() {
            d.rejectWith(this, arguments);
        }), "function" == typeof def.abort && (d.abort = function() {
            return def.abort();
        }), d;
    }, modelNum = 0, getId = function(inst) {
        return can.Observe.__reading && can.Observe.__reading(inst, inst.constructor.id), 
        inst.__get(inst.constructor.id);
    }, ajax = function(ajaxOb, data, type, dataType, success, error) {
        var params = {};
        if ("string" == typeof ajaxOb) {
            var parts = ajaxOb.split(/\s+/);
            params.url = parts.pop(), parts.length && (params.type = parts.pop());
        } else can.extend(params, ajaxOb);
        return params.data = "object" != typeof data || can.isArray(data) ? data : can.extend(params.data || {}, data), 
        params.url = can.sub(params.url, params.data, !0), can.ajax(can.extend({
            type: type || "post",
            dataType: dataType || "json",
            success: success,
            error: error
        }, params));
    }, makeRequest = function(self, type, success, error, method) {
        var args;
        can.isArray(self) ? (args = self[1], self = self[0]) : args = self.serialize(), 
        args = [ args ];
        var deferred, jqXHR, model = self.constructor;
        return "destroy" == type && args.shift(), "create" !== type && args.unshift(getId(self)), 
        jqXHR = model[type].apply(model, args), deferred = jqXHR.pipe(function(data) {
            return self[method || type + "d"](data, jqXHR), self;
        }), jqXHR.abort && (deferred.abort = function() {
            jqXHR.abort();
        }), deferred.then(success, error), deferred;
    }, ajaxMethods = {
        create: {
            url: "_shortName",
            type: "post"
        },
        update: {
            data: function(id, attrs) {
                attrs = attrs || {};
                var identity = this.id;
                return attrs[identity] && attrs[identity] !== id && (attrs["new" + can.capitalize(id)] = attrs[identity], 
                delete attrs[identity]), attrs[identity] = id, attrs;
            },
            type: "put"
        },
        destroy: {
            type: "delete",
            data: function(id) {
                var args = {};
                return args.id = args[this.id] = id, args;
            }
        },
        findAll: {
            url: "_shortName"
        },
        findOne: {}
    }, ajaxMaker = function(ajaxMethod, str) {
        return function(data) {
            return data = ajaxMethod.data ? ajaxMethod.data.apply(this, arguments) : data, ajax(str || this[ajaxMethod.url || "_url"], data, ajaxMethod.type || "get");
        };
    };
    can.Model = can.Observe({
        fullName: "can.Model",
        _reqs: 0,
        setup: function(base) {
            if (this.store = {}, can.Observe.setup.apply(this, arguments), can.Model) {
                this.List = ML({
                    Observe: this
                }, {});
                var self = this, clean = can.proxy(this._clean, self);
                can.each(ajaxMethods, function(method, name) {
                    if (can.isFunction(self[name]) || (self[name] = ajaxMaker(method, self[name])), 
                    self["make" + can.capitalize(name)]) {
                        var newMethod = self["make" + can.capitalize(name)](self[name]);
                        can.Construct._overwrite(self, base, name, function() {
                            can.Model._reqs++;
                            var def = newMethod.apply(this, arguments), then = def.then(clean, clean);
                            return then.abort = def.abort, then;
                        });
                    }
                }), "can.Model" != self.fullName && self.fullName || (self.fullName = "Model" + ++modelNum), 
                can.Model._reqs = 0, this._url = this._shortName + "/{" + this.id + "}";
            }
        },
        _ajax: ajaxMaker,
        _makeRequest: makeRequest,
        _clean: function() {
            if (can.Model._reqs--, !can.Model._reqs) for (var id in this.store) this.store[id]._bindings || delete this.store[id];
            return arguments[0];
        },
        models: function(instancesRawData, oldList) {
            if (can.Model._reqs++, instancesRawData) {
                if (instancesRawData instanceof this.List) return instancesRawData;
                var self = this, tmp = [], res = oldList instanceof can.Observe.List ? oldList : new (self.List || ML)(), arr = can.isArray(instancesRawData), ml = instancesRawData instanceof ML, raw = arr ? instancesRawData : ml ? instancesRawData.serialize() : instancesRawData.data;
                return res.length && res.splice(0), can.each(raw, function(rawPart) {
                    tmp.push(self.model(rawPart));
                }), res.push.apply(res, tmp), arr || can.each(instancesRawData, function(val, prop) {
                    "data" !== prop && res.attr(prop, val);
                }), setTimeout(can.proxy(this._clean, this), 1), res;
            }
        },
        model: function(attributes) {
            if (attributes) {
                attributes instanceof this && (attributes = attributes.serialize());
                var id = attributes[this.id], model = (id || 0 === id) && this.store[id] ? this.store[id].attr(attributes, this.removeAttr || !1) : new this(attributes);
                return can.Model._reqs && (this.store[attributes[this.id]] = model), model;
            }
        }
    }, {
        isNew: function() {
            var id = getId(this);
            return !(id || 0 === id);
        },
        save: function(success, error) {
            return makeRequest(this, this.isNew() ? "create" : "update", success, error);
        },
        destroy: function(success, error) {
            if (this.isNew()) {
                var self = this, def = can.Deferred();
                return def.then(success, error), def.done(function(data) {
                    self.destroyed(data);
                }).resolve(self);
            }
            return makeRequest(this, "destroy", success, error, "destroyed");
        },
        _bindsetup: function() {
            return this.constructor.store[this.__get(this.constructor.id)] = this, can.Observe.prototype._bindsetup.apply(this, arguments);
        },
        _bindteardown: function() {
            return delete this.constructor.store[getId(this)], can.Observe.prototype._bindteardown.apply(this, arguments);
        },
        ___set: function(prop, val) {
            can.Observe.prototype.___set.call(this, prop, val), prop === this.constructor.id && this._bindings && (this.constructor.store[getId(this)] = this);
        }
    }), can.each({
        makeFindAll: "models",
        makeFindOne: "model",
        makeCreate: "model",
        makeUpdate: "model"
    }, function(method, name) {
        can.Model[name] = function(oldMethod) {
            return function() {
                var args = can.makeArray(arguments), oldArgs = can.isFunction(args[1]) ? args.splice(0, 1) : args.splice(0, 2), def = pipe(oldMethod.apply(this, oldArgs), this, method);
                return def.then(args[0], args[1]), def;
            };
        };
    }), can.each([ "created", "updated", "destroyed" ], function(funcName) {
        can.Model.prototype[funcName] = function(attrs) {
            var stub, constructor = this.constructor;
            stub = attrs && "object" == typeof attrs && this.attr(attrs.attr ? attrs.attr() : attrs), 
            can.trigger(this, "change", funcName), can.trigger(constructor, funcName, this);
        };
    });
    var ML = can.Model.List = can.Observe.List({
        setup: function(params) {
            can.isPlainObject(params) && !can.isArray(params) ? (can.Observe.List.prototype.setup.apply(this), 
            this.replace(this.constructor.Observe.findAll(params))) : can.Observe.List.prototype.setup.apply(this, arguments);
        },
        _changes: function(ev, attr) {
            if (can.Observe.List.prototype._changes.apply(this, arguments), /\w+\.destroyed/.test(attr)) {
                var index = this.indexOf(ev.target);
                -1 != index && this.splice(index, 1);
            }
        }
    });
    return can.Model;
}), define("jpmc/model", [ "jpmc/util/string/hyphenate", "jpmc/util/lang/isFunction", "jpmc/util/lang/isEmpty", "when", "can/construct/super", "can/model" ], function(hyphenate, isFunction, isEmpty, when, can, canModel, undefined) {
    var Model, encodeURIComponent = window.encodeURIComponent;
    return Model = canModel({
        identity: function(id) {
            return (this._fullName + "_" + (this.escapeIdentity ? encodeURIComponent(id) : id)).replace(/ /g, "_");
        },
        selector: function(id) {
            return hyphenate(this.identity(id));
        }
    }, {
        setup: function() {
            this._super.apply(this, arguments);
            var that = this, constructor = this.constructor;
            isFunction(constructor.findOne) && (this.findUpdate = function(params, success, error) {
                return isFunction(params) && (error = success, success = params, params = undefined), 
                this.attr("id") !== undefined && (params = params || {}, params.id = this.id), constructor.findOne(params, function(data) {
                    that.attr(data.attr()), success && success.call(that, data);
                }, error);
            });
        },
        selector: function() {
            return hyphenate(this.identity());
        }
    }), Model.List = canModel.List({}, {}), Model;
}), define("jpmc/rule", [ "jpmc/construct", "jpmc/log" ], function(Construct, Logger) {
    var logger = Logger("rule"), Rule = Construct({
        _loadedRules: {
            _rulesById: {}
        },
        getRules: function(ruleGroup) {
            return this._loadedRules[ruleGroup];
        },
        getRuleById: function(ruleId) {
            return this._loadedRules._rulesById[ruleId];
        },
        loadRules: function(ruleGroup, propertiesArray) {
            for (var i = 0; i < propertiesArray.length; i++) this.createRule(ruleGroup, propertiesArray[i]);
        },
        createRule: function(ruleGroup, properties) {
            var newRule = new Rule(properties);
            return this._loadedRules[ruleGroup] || (this._loadedRules[ruleGroup] = []), this._loadedRules[ruleGroup].push(newRule), 
            newRule.order = this._loadedRules[ruleGroup].length - 1, this._loadedRules._rulesById[properties.id] = newRule, 
            newRule;
        }
    }, {
        id: "",
        inputCount: 0,
        conditions: [],
        order: -1,
        skipIf: [],
        runIf: [],
        thisOrThat: [],
        result: function() {},
        setup: function(constructorArgs) {
            return "object" == typeof constructorArgs ? [ constructorArgs.id, constructorArgs.inputCount, constructorArgs.conditions, constructorArgs.result, constructorArgs.skipIf, constructorArgs.runIf, constructorArgs.thisOrThat ] : constructorArgs;
        },
        init: function(ruleId, numInputs, conditions, result, skipIf, runIf, thisOrThat) {
            this.id = ruleId, "number" == typeof numInputs && (this.inputCount = numInputs), 
            this._validateConditions(conditions) && (this.conditions = conditions), this._validateResult(result) && (this.result = result), 
            skipIf && (this.skipIf = skipIf), runIf && (this.runIf = runIf), thisOrThat && (this.thisOrThat = thisOrThat);
        },
        _validateResult: function(result) {
            return "function" != typeof result ? (this.ruleError("result is not a function but " + typeof result), 
            !1) : !0;
        },
        _validateConditions: function(conditions) {
            return conditions instanceof Array ? conditions.length > this.inputCount ? (this.ruleError("number of conditions do not match input count for rule.  Got " + conditions.length + " but expected " + this.inputCount), 
            !1) : !0 : (this.ruleError("conditions for rule are not an array"), !1);
        },
        hasRuleDependencies: function() {
            return this.skipIf && this.skipIf.length || this.runIf && this.runIf.length || this.thisOrThat && this.thisOrThat.length;
        },
        runRule: function(inputs) {
            inputs instanceof Array || this.ruleError("runRule needs to be passed an array of inputs.  Got " + typeof inputs);
            var numInputs = inputs ? inputs.length : 0;
            numInputs !== this.inputCount && this.ruleError("Only have [" + numInputs + "] but expected [" + this.inputCount + "]");
            for (var i = 0; i < inputs.length; i++) {
                var thisCondition = this.conditions[i], andResult = !0, orResult = !0;
                if (thisCondition.and) for (var a = 0; a < thisCondition.and.length; a++) thisCondition.and[a].call(this, inputs[i]) || (andResult = !1);
                if (andResult && thisCondition.or) for (var c = 0; c < thisCondition.or.length; c++) {
                    if (thisCondition.or[c].call(this, inputs[i])) {
                        orResult = !0;
                        break;
                    }
                    orResult = !1;
                }
            }
            return andResult && orResult;
        },
        ruleError: function(message) {
            logger.error("rule [" + this.id + "]: " + message);
        }
    });
    return Rule;
}), define("jpmc/rule/resultfrom", {
    FirstMatchingRule: {
        name: "FirstMatchingRule"
    },
    AndAllRules: {
        name: "AndAllRules"
    },
    OrAllRules: {
        name: "OrAllRules"
    }
}), define("jpmc/rule/engine", [ "jpmc/rule", "jpmc/log", "jpmc/rule/resultfrom", "when", "jpmc/construct" ], function(Rule, Logger, ResultFrom, when, Construct, undefined) {
    var RulesEngine = function() {
        function construct() {
            this._aggregate[ResultFrom.FirstMatchingRule.name] = this._aggregateFirstResult, 
            this._aggregate[ResultFrom.AndAllRules.name] = this._aggregateAndAllResults, this.logger = new Logger("RulesEngine");
        }
        var EvaluationContext = Construct({}, {
            data: {},
            init: function() {
                this.data = {
                    realDeferredResultsById: {},
                    aggregateResultPromiseStacks: [],
                    evaluatedResult: when.defer()
                }, this.logger = new Logger("RulesEngine");
            },
            addOrGetRuleResolverForRule: function(rule) {
                var ruleDeferred = this.data.realDeferredResultsById[rule.id];
                return ruleDeferred || (this.data.realDeferredResultsById[rule.id] = ruleDeferred = when.defer(), 
                this.data.aggregateResultPromiseStacks[rule.order] = [ ruleDeferred.promise ], this._updateAggregateResultPromisesForRule(rule)), 
                ruleDeferred;
            },
            pushOrPeekRuleResolverForRule: function(rule, resolverPromise) {
                this.addOrGetRuleResolverForRule(rule);
                var ruleResolverStack = this.data.aggregateResultPromiseStacks[rule.order], originalTopOfStack = this._peek(ruleResolverStack);
                return resolverPromise && ruleResolverStack.push(resolverPromise), originalTopOfStack;
            },
            deferredResult: function() {
                return this.data.evaluatedResult;
            },
            getAggregateResultPromises: function() {
                for (var aggregateResultPromises = [], k = 0; k < this.data.aggregateResultPromiseStacks.length; k++) aggregateResultPromises.push(this._peek(this.data.aggregateResultPromiseStacks[k]));
                return aggregateResultPromises;
            },
            _peek: function(stack) {
                return stack && stack.length ? stack[stack.length - 1] : undefined;
            },
            _updateAggregateResultPromisesForRule: function(rule) {
                if (rule.thisOrThat && rule.thisOrThat.length) {
                    var thisOrThatPromises = [], thisOrThatDeferred = when.defer(), engine = this;
                    thisOrThatPromises.push(this.pushOrPeekRuleResolverForRule(rule, thisOrThatDeferred.promise)), 
                    this.pushOrPeekRuleResolverForRule(rule, thisOrThatDeferred.promise);
                    for (var i = 0; i < rule.thisOrThat.length; i++) {
                        var latestPromise = this.pushOrPeekRuleResolverForRule(Rule.getRuleById(rule.thisOrThat[i]), thisOrThatDeferred.promise);
                        thisOrThatPromises.push(latestPromise);
                    }
                    when.all(thisOrThatPromises).then(function(results) {
                        var exclusiveResult = RulesEngine._OR(results);
                        engine.logger.debug("Resolving exclusive promises for [", rule.id, rule.thisOrThat, "] to: ", exclusiveResult), 
                        thisOrThatDeferred.resolve(exclusiveResult);
                    }, thisOrThatDeferred.reject);
                }
            },
            getRulerealDeferredResultsByIds: function(ruleIds) {
                for (var found = [], i = 0; i < ruleIds.length; i++) {
                    var deferred = this._getRulerealDeferredResultForId(ruleIds[i]);
                    found.push(deferred.promise);
                }
                return found;
            },
            _getRulerealDeferredResultForId: function(ruleId) {
                var rule = Rule.getRuleById(ruleId);
                if (!rule) throw "No such rule[" + i + "] exists with id [" + ruleIds[i] + "]";
                return this.addOrGetRuleResolverForRule(rule);
            }
        });
        return construct._AND = function(arrayOfBooleans) {
            for (var andResult, i = 0; i < arrayOfBooleans.length; i++) arrayOfBooleans[i] !== undefined && (andResult = andResult === undefined ? !0 : andResult, 
            andResult = andResult && arrayOfBooleans[i]);
            return andResult;
        }, construct._OR = function(arrayOfBooleans) {
            for (var orResult, i = 0; i < arrayOfBooleans.length; i++) arrayOfBooleans[i] !== undefined && (orResult = orResult === undefined ? !1 : orResult, 
            orResult = orResult || arrayOfBooleans[i]);
            return orResult;
        }, construct.prototype = {
            _evaluate: {},
            evaluate: function(rules, inputs, resultFrom) {
                var ctx = new EvaluationContext();
                if (!resultFrom && 3 == arguments.length) throw "invalid ResultFrom argument passed - got undefined";
                if (resultFrom = resultFrom || ResultFrom.FirstMatchingRule, !(rules instanceof Array)) throw "Rules are required and must be an array of rules";
                if (!(inputs instanceof Array)) throw "Inputs are required and must be an array of inputs";
                for (var r = 0, s = rules.length; s > r; r++) if (rules[r] instanceof Rule) {
                    if (rules[r].inputCount == inputs.length) {
                        var ruleDeferred = ctx.addOrGetRuleResolverForRule(rules[r]);
                        if (rules[r].hasRuleDependencies()) {
                            var runIfNotSkipped = this._buildCanRunRulePromiseChain(ctx.getRulerealDeferredResultsByIds(rules[r].skipIf), !1), canRun = this._buildCanRunRulePromiseChain(ctx.getRulerealDeferredResultsByIds(rules[r].runIf), !0);
                            when.all(runIfNotSkipped.concat(canRun)).then(function(thisRule, thisRuleDeferred, length) {
                                return function(dependencyResults) {
                                    var runIfNotSkippedResults = dependencyResults.slice(0, length), canRunResults = dependencyResults.slice(length);
                                    if (runIfNotSkippedResults.length && !RulesEngine._AND(runIfNotSkippedResults) || canRunResults.length && !RulesEngine._AND(canRunResults)) thisRuleDeferred.resolve(undefined); else {
                                        var thisRuleResult = thisRule.runRule(inputs);
                                        thisRuleDeferred.resolve(thisRuleResult);
                                    }
                                };
                            }(rules[r], ruleDeferred, runIfNotSkipped.length));
                        } else {
                            var currentResult = rules[r].runRule(inputs);
                            ruleDeferred.resolve(currentResult);
                        }
                    }
                } else this.logger.error("Rule[" + r + "] in the rules is not of type JPMC.Rule...skipping.  Got type" + typeof rules[r]);
                var aggregateResultPromises = ctx.getAggregateResultPromises(), engine = this;
                return when.all(aggregateResultPromises).then(this._aggregate[resultFrom.name](ctx.deferredResult(), engine, rules, inputs)), 
                ctx.deferredResult().promise;
            },
            _buildCanRunRulePromiseChain: function(resultPromises, canRunRuleWhenResultIs) {
                for (var chained = [], i = 0; i < resultPromises.length; i++) {
                    var handleResultPromise = when.defer();
                    chained.push(handleResultPromise.promise), when(resultPromises[i], function() {
                        return function(value) {
                            var canRunRule = value === canRunRuleWhenResultIs;
                            handleResultPromise.resolve(canRunRule);
                        };
                    }(i), handleResultPromise.reject);
                }
                return chained;
            },
            _aggregate: {},
            _aggregateAndAllResults: function(deferredResult, rulesEngine, rules, inputs) {
                return function(results) {
                    var aggregateResult = !0;
                    rulesEngine.logger.debug("Got results: ", results);
                    for (var i = 0; i < results.length; i++) results[i] !== undefined && (aggregateResult = rulesEngine.booleanAndResultAggregator(aggregateResult, results[i]), 
                    aggregateResult = rulesEngine.booleanAndResultAggregator(aggregateResult, rules[i].result(inputs)));
                    rulesEngine.logger.debug("Resolving result to be: ", aggregateResult), deferredResult.resolve(aggregateResult);
                };
            },
            _aggregateFirstResult: function(deferredResult, rulesEngine, rules, inputs) {
                return function(results) {
                    var aggregateresult;
                    rulesEngine.logger.debug("Got results: ", results);
                    for (var i = 0; i < results.length; i++) if (results[i]) {
                        var aggregateResult = rulesEngine.nullResultAggregator(aggregateresult, rules[i].result(inputs));
                        return rulesEngine.logger.debug("Resolving result to be results[", i, "]: ", aggregateResult), 
                        void deferredResult.resolve(aggregateResult);
                    }
                    deferredResult.resolve(undefined);
                };
            },
            booleanAndResultAggregator: function(original, currentResult) {
                return original && currentResult;
            },
            nullResultAggregator: function(original, currentResult) {
                return currentResult;
            }
        }, construct;
    }();
    return RulesEngine;
}), define("jpmc/when", [ "when" ], function(when) {
    return when;
}), define("jpmc/timer", [ "jpmc/has/detect/time", "jpmc/util/time/now", "jpmc/when" ], function(has, now) {
    function Timer() {}
    return Timer.prototype = {
        startTime: 0,
        stopTime: 0,
        start: function(time) {
            this.stopTime = 0, this.startTime = time || now();
        },
        stop: function() {
            this.stopTime = now(), 0 === this.startTime && (this.stopTime = 0);
        },
        microseconds: function() {
            return 1e3 * this.milliseconds();
        },
        milliseconds: function() {
            var stop = this.stopTime;
            return 0 === stop && 0 !== this.startTime && (stop = now()), Math.ceil(stop - this.startTime);
        },
        profile: function(fn, iterations) {
            for (this.start(); iterations--; ) fn();
            this.stop();
        },
        seconds: function() {
            return this.milliseconds() / 1e3;
        }
    }, Timer.constructor = Timer.prototype.constructor = Timer, Timer.now = now, Timer;
}), function(global) {
    function SignalBinding(signal, listener, isOnce, listenerContext, priority) {
        this._listener = listener, this._isOnce = isOnce, this.context = listenerContext, 
        this._signal = signal, this._priority = priority || 0;
    }
    function validateListener(listener, fnName) {
        if ("function" != typeof listener) throw new Error("listener is a required param of {fn}() and should be a Function.".replace("{fn}", fnName));
    }
    function Signal() {
        this._bindings = [], this._prevParams = null;
        var self = this;
        this.dispatch = function() {
            Signal.prototype.dispatch.apply(self, arguments);
        };
    }
    SignalBinding.prototype = {
        active: !0,
        params: null,
        execute: function(paramsArr) {
            var handlerReturn, params;
            return this.active && this._listener && (params = this.params ? this.params.concat(paramsArr) : paramsArr, 
            handlerReturn = this._listener.apply(this.context, params), this._isOnce && this.detach()), 
            handlerReturn;
        },
        detach: function() {
            return this.isBound() ? this._signal.remove(this._listener, this.context) : null;
        },
        isBound: function() {
            return !!this._signal && !!this._listener;
        },
        isOnce: function() {
            return this._isOnce;
        },
        getListener: function() {
            return this._listener;
        },
        getSignal: function() {
            return this._signal;
        },
        _destroy: function() {
            delete this._signal, delete this._listener, delete this.context;
        },
        toString: function() {
            return "[SignalBinding isOnce:" + this._isOnce + ", isBound:" + this.isBound() + ", active:" + this.active + "]";
        }
    }, Signal.prototype = {
        VERSION: "1.0.0",
        memorize: !1,
        _shouldPropagate: !0,
        active: !0,
        _registerListener: function(listener, isOnce, listenerContext, priority) {
            var binding, prevIndex = this._indexOfListener(listener, listenerContext);
            if (-1 !== prevIndex) {
                if (binding = this._bindings[prevIndex], binding.isOnce() !== isOnce) throw new Error("You cannot add" + (isOnce ? "" : "Once") + "() then add" + (isOnce ? "Once" : "") + "() the same listener without removing the relationship first.");
            } else binding = new SignalBinding(this, listener, isOnce, listenerContext, priority), 
            this._addBinding(binding);
            return this.memorize && this._prevParams && binding.execute(this._prevParams), binding;
        },
        _addBinding: function(binding) {
            var n = this._bindings.length;
            do --n; while (this._bindings[n] && binding._priority <= this._bindings[n]._priority);
            this._bindings.splice(n + 1, 0, binding);
        },
        _indexOfListener: function(listener, context) {
            for (var cur, n = this._bindings.length; n--; ) if (cur = this._bindings[n], cur._listener === listener && cur.context === context) return n;
            return -1;
        },
        has: function(listener, context) {
            return -1 !== this._indexOfListener(listener, context);
        },
        add: function(listener, listenerContext, priority) {
            return validateListener(listener, "add"), this._registerListener(listener, !1, listenerContext, priority);
        },
        addOnce: function(listener, listenerContext, priority) {
            return validateListener(listener, "addOnce"), this._registerListener(listener, !0, listenerContext, priority);
        },
        remove: function(listener, context) {
            validateListener(listener, "remove");
            var i = this._indexOfListener(listener, context);
            return -1 !== i && (this._bindings[i]._destroy(), this._bindings.splice(i, 1)), 
            listener;
        },
        removeAll: function() {
            for (var n = this._bindings.length; n--; ) this._bindings[n]._destroy();
            this._bindings.length = 0;
        },
        getNumListeners: function() {
            return this._bindings.length;
        },
        halt: function() {
            this._shouldPropagate = !1;
        },
        dispatch: function() {
            if (this.active) {
                var bindings, paramsArr = Array.prototype.slice.call(arguments), n = this._bindings.length;
                if (this.memorize && (this._prevParams = paramsArr), n) {
                    bindings = this._bindings.slice(), this._shouldPropagate = !0;
                    do n--; while (bindings[n] && this._shouldPropagate && bindings[n].execute(paramsArr) !== !1);
                }
            }
        },
        forget: function() {
            this._prevParams = null;
        },
        dispose: function() {
            this.removeAll(), delete this._bindings, delete this._prevParams;
        },
        toString: function() {
            return "[Signal active:" + this.active + " numListeners:" + this.getNumListeners() + "]";
        }
    };
    var signals = Signal;
    signals.Signal = Signal, "function" == typeof define && define.amd ? define("signals", [], function() {
        return signals;
    }) : "undefined" != typeof module && module.exports ? module.exports = signals : global.signals = signals;
}(this), define("jpmc/topic/channels", {}), define("jpmc/topic", [ "signals", "jpmc/topic/channels", "jpmc/util/object/forOwn", "jpmc/util/lang/isPlainObject" ], function(Signal, channels, forOwn, isPlainObject, undefined) {
    function Channel(name) {
        Signal.call(this), this.name = name || "", this.memorize = !0;
    }
    function topic(name) {
        var channel = name && channels[name];
        return channel || (channel = new Channel(name), name && (channels[name] = channel)), 
        channel;
    }
    return Channel.prototype = new Signal(), Channel.constructor = Channel.prototype.constructor = Channel, 
    Channel.prototype.clear = function() {
        return this.forget.apply(this, arguments);
    }, Channel.prototype.once = function() {
        return this.addOnce.apply(this, arguments);
    }, Channel.prototype.publish = function() {
        return this.dispatch.apply(this, arguments);
    }, Channel.prototype.subscribe = function() {
        return this.add.apply(this, arguments);
    }, Channel.prototype.unsubscribe = function() {
        return this.remove.apply(this, arguments);
    }, topic.Channel = Channel, topic.channels = channels, topic.exists = function(name) {
        return !!channels[name];
    }, topic.publish = function(name, args) {
        for (var topicNames = name.split(" "), i = 0, j = topicNames.length; j > i; i++) {
            var channel = topic(topicNames[i]);
            channel.publish.apply(channel, args || []);
        }
    }, topic.subscribe = function(name, fn, context) {
        var channel, callback, subscriptions = {}, callbacks = {}, size = 0;
        return isPlainObject(name) ? (subscriptions = name, context = Array.prototype.pop.call(arguments), 
        fn = undefined) : subscriptions[name] = fn, forOwn(subscriptions, function(fn, name) {
            channel = topic(name), context = context || channel, callback = function() {
                fn.apply(context, arguments);
            }, channel.subscribe(callback), callbacks[name] = callback, size++;
        }), 1 === size ? callbacks[name] : callbacks;
    }, topic.unsubscribe = function(name, callback) {
        var callbacks = {};
        isPlainObject(name) ? callbacks = name : callbacks[name] = callback, forOwn(callbacks, function(fn, name) {
            topic(name).unsubscribe(fn);
        });
    }, topic;
}), define("can/control", [ "can/util/library", "can/construct" ], function(can) {
    var basicProcessor, bind = function(el, ev, callback) {
        return can.bind.call(el, ev, callback), function() {
            can.unbind.call(el, ev, callback);
        };
    }, isFunction = can.isFunction, extend = can.extend, each = can.each, slice = [].slice, paramReplacer = /\{([^\}]+)\}/g, special = can.getObject("$.event.special", [ can ]) || {}, delegate = function(el, selector, ev, callback) {
        return can.delegate.call(el, selector, ev, callback), function() {
            can.undelegate.call(el, selector, ev, callback);
        };
    }, binder = function(el, ev, callback, selector) {
        return selector ? delegate(el, can.trim(selector), ev, callback) : bind(el, ev, callback);
    }, Control = can.Control = can.Construct({
        setup: function() {
            if (can.Construct.setup.apply(this, arguments), can.Control) {
                var funcName, control = this;
                control.actions = {};
                for (funcName in control.prototype) control._isAction(funcName) && (control.actions[funcName] = control._action(funcName));
            }
        },
        _shifter: function(context, name) {
            var method = "string" == typeof name ? context[name] : name;
            return isFunction(method) || (method = context[method]), function() {
                return context.called = name, method.apply(context, [ this.nodeName ? can.$(this) : this ].concat(slice.call(arguments, 0)));
            };
        },
        _isAction: function(methodName) {
            var val = this.prototype[methodName], type = typeof val;
            return "constructor" !== methodName && ("function" == type || "string" == type && isFunction(this.prototype[val])) && !!(special[methodName] || processors[methodName] || /[^\w]/.test(methodName));
        },
        _action: function(methodName, options) {
            if (paramReplacer.lastIndex = 0, options || !paramReplacer.test(methodName)) {
                var convertedName = options ? can.sub(methodName, [ options, window ]) : methodName;
                if (!convertedName) return null;
                var arr = can.isArray(convertedName), name = arr ? convertedName[1] : convertedName, parts = name.split(/\s+/g), event = parts.pop();
                return {
                    processor: processors[event] || basicProcessor,
                    parts: [ name, parts.join(" "), event ],
                    delegate: arr ? convertedName[0] : void 0
                };
            }
        },
        processors: {},
        defaults: {}
    }, {
        setup: function(element, options) {
            var arr, cls = this.constructor, pluginname = cls.pluginName || cls._fullName;
            return this.element = can.$(element), pluginname && "can_control" !== pluginname && this.element.addClass(pluginname), 
            (arr = can.data(this.element, "controls")) || can.data(this.element, "controls", arr = []), 
            arr.push(this), this.options = extend({}, cls.defaults, options), this.on(), [ this.element, this.options ];
        },
        on: function(el, selector, eventName, func) {
            if (!el) {
                this.off();
                var funcName, ready, cls = this.constructor, bindings = this._bindings, actions = cls.actions, element = this.element, destroyCB = can.Control._shifter(this, "destroy");
                for (funcName in actions) actions.hasOwnProperty(funcName) && (ready = actions[funcName] || cls._action(funcName, this.options)) && bindings.push(ready.processor(ready.delegate || element, ready.parts[2], ready.parts[1], funcName, this));
                return can.bind.call(element, "destroyed", destroyCB), bindings.push(function(el) {
                    can.unbind.call(el, "destroyed", destroyCB);
                }), bindings.length;
            }
            return "string" == typeof el && (func = eventName, eventName = selector, selector = el, 
            el = this.element), void 0 === func && (func = eventName, eventName = selector, 
            selector = null), "string" == typeof func && (func = can.Control._shifter(this, func)), 
            this._bindings.push(binder(el, eventName, func, selector)), this._bindings.length;
        },
        off: function() {
            var el = this.element[0];
            each(this._bindings || [], function(value) {
                value(el);
            }), this._bindings = [];
        },
        destroy: function() {
            if (null !== this.element) {
                var controls, Class = this.constructor, pluginName = Class.pluginName || Class._fullName;
                this.off(), pluginName && "can_control" !== pluginName && this.element.removeClass(pluginName), 
                controls = can.data(this.element, "controls"), controls.splice(can.inArray(this, controls), 1), 
                can.trigger(this, "destroyed"), this.element = null;
            }
        }
    }), processors = can.Control.processors, basicProcessor = function(el, event, selector, methodName, control) {
        return binder(el, event, can.Control._shifter(control, methodName), selector);
    };
    return each([ "change", "click", "contextmenu", "dblclick", "keydown", "keyup", "keypress", "mousedown", "mousemove", "mouseout", "mouseover", "mouseup", "reset", "resize", "scroll", "select", "submit", "focusin", "focusout", "mouseenter", "mouseleave", "touchstart", "touchmove", "touchcancel", "touchend", "touchleave" ], function(v) {
        processors[v] = basicProcessor;
    }), Control;
}), define("mout/lang/isBoolean", [ "./isKind" ], function(isKind) {
    function isBoolean(val) {
        return isKind(val, "Boolean");
    }
    return isBoolean;
}), define("jpmc/util/lang/isBoolean", [ "mout/lang/isBoolean" ], function(moutIsBoolean) {
    var isBoolean;
    return isBoolean = moutIsBoolean;
}), define("jpmc/util/lang/isConstruct", [ "can/construct", "jpmc/construct", "./isFunction" ], function(canConstruct, Construct, isFunction) {
    var isConstruct;
    return isConstruct = function(value) {
        return (value instanceof canConstruct || value instanceof Construct) && isFunction(value.constructor);
    };
}), define("jpmc/util/lang/isConstructor", [ "./isFunction" ], function(isFunction) {
    var isConstructor;
    return isConstructor = function(value) {
        return isFunction(value.constructor);
    };
}), define("jpmc/util/lang/isHTMLElement", [ "./isString" ], function(isString) {
    return function(value) {
        return "object" == typeof HTMLElement ? value instanceof HTMLElement : value && "object" == typeof value && 1 === value.nodeType && isString(value.nodeName);
    };
}), define("jpmc/util/lang/isKind", [ "mout/lang/isKind" ], function(isKind) {
    return isKind;
}), define("jpmc/util/lang/isMarkup", [], function() {
    var regex = /<\/?\w+((\s+\w+(\s*=\s*(?:".*?"|'.*?'|[^'">\s]+))?)+\s*|\s*)\/?>/;
    return function(text) {
        return text && regex.test(text);
    };
}), define("mout/lang/isNumber", [ "./isKind" ], function(isKind) {
    function isNumber(val) {
        return isKind(val, "Number");
    }
    return isNumber;
}), define("jpmc/util/lang/isNumber", [ "mout/lang/isNumber" ], function(isNumber) {
    return isNumber;
}), define("jpmc/util/lang/isNode", [ "./isNumber", "./isString" ], function(isNumber, isString) {
    return function(value) {
        return "object" == typeof Node ? value instanceof Node : value && "object" == typeof value && isNumber(value.nodeType) && isString(value.nodeName);
    };
}), define("mout/lang/isObject", [ "./isKind" ], function(isKind) {
    function isObject(val) {
        return isKind(val, "Object");
    }
    return isObject;
}), define("jpmc/util/lang/isObject", [ "mout/lang/isObject" ], function(isObject) {
    return isObject;
}), define("jpmc/util/lang/isPromise", [ "when" ], function(when) {
    return when.isPromise;
}), function(root) {
    function error(type) {
        throw RangeError(errors[type]);
    }
    function map(array, fn) {
        for (var length = array.length; length--; ) array[length] = fn(array[length]);
        return array;
    }
    function mapDomain(string, fn) {
        var glue = ".";
        return map(string.split(glue), fn).join(glue);
    }
    function ucs2decode(string) {
        for (var value, extra, output = [], counter = 0, length = string.length; length > counter; ) value = string.charCodeAt(counter++), 
        55296 == (63488 & value) && length > counter ? (extra = string.charCodeAt(counter++), 
        56320 == (64512 & extra) ? output.push(((1023 & value) << 10) + (1023 & extra) + 65536) : output.push(value, extra)) : output.push(value);
        return output;
    }
    function ucs2encode(array) {
        return map(array, function(value) {
            var output = "";
            return value > 65535 && (value -= 65536, output += stringFromCharCode(value >>> 10 & 1023 | 55296), 
            value = 56320 | 1023 & value), output += stringFromCharCode(value);
        }).join("");
    }
    function basicToDigit(codePoint) {
        return 10 > codePoint - 48 ? codePoint - 22 : 26 > codePoint - 65 ? codePoint - 65 : 26 > codePoint - 97 ? codePoint - 97 : base;
    }
    function digitToBasic(digit, flag) {
        return digit + 22 + 75 * (26 > digit) - ((0 != flag) << 5);
    }
    function adapt(delta, numPoints, firstTime) {
        var k = 0;
        for (delta = firstTime ? floor(delta / damp) : delta >> 1, delta += floor(delta / numPoints); delta > baseMinusTMin * tMax >> 1; k += base) delta = floor(delta / baseMinusTMin);
        return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
    }
    function decode(input) {
        var out, basic, j, index, oldi, w, k, digit, t, baseMinusT, output = [], inputLength = input.length, i = 0, n = initialN, bias = initialBias;
        for (basic = input.lastIndexOf(delimiter), 0 > basic && (basic = 0), j = 0; basic > j; ++j) input.charCodeAt(j) >= 128 && error("not-basic"), 
        output.push(input.charCodeAt(j));
        for (index = basic > 0 ? basic + 1 : 0; inputLength > index; ) {
            for (oldi = i, w = 1, k = base; index >= inputLength && error("invalid-input"), 
            digit = basicToDigit(input.charCodeAt(index++)), (digit >= base || digit > floor((maxInt - i) / w)) && error("overflow"), 
            i += digit * w, t = bias >= k ? tMin : k >= bias + tMax ? tMax : k - bias, !(t > digit); k += base) baseMinusT = base - t, 
            w > floor(maxInt / baseMinusT) && error("overflow"), w *= baseMinusT;
            out = output.length + 1, bias = adapt(i - oldi, out, 0 == oldi), floor(i / out) > maxInt - n && error("overflow"), 
            n += floor(i / out), i %= out, output.splice(i++, 0, n);
        }
        return ucs2encode(output);
    }
    function encode(input) {
        var n, delta, handledCPCount, basicLength, bias, j, m, q, k, t, currentValue, inputLength, handledCPCountPlusOne, baseMinusT, qMinusT, output = [];
        for (input = ucs2decode(input), inputLength = input.length, n = initialN, delta = 0, 
        bias = initialBias, j = 0; inputLength > j; ++j) currentValue = input[j], 128 > currentValue && output.push(stringFromCharCode(currentValue));
        for (handledCPCount = basicLength = output.length, basicLength && output.push(delimiter); inputLength > handledCPCount; ) {
            for (m = maxInt, j = 0; inputLength > j; ++j) currentValue = input[j], currentValue >= n && m > currentValue && (m = currentValue);
            for (handledCPCountPlusOne = handledCPCount + 1, m - n > floor((maxInt - delta) / handledCPCountPlusOne) && error("overflow"), 
            delta += (m - n) * handledCPCountPlusOne, n = m, j = 0; inputLength > j; ++j) if (currentValue = input[j], 
            n > currentValue && ++delta > maxInt && error("overflow"), currentValue == n) {
                for (q = delta, k = base; t = bias >= k ? tMin : k >= bias + tMax ? tMax : k - bias, 
                !(t > q); k += base) qMinusT = q - t, baseMinusT = base - t, output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0))), 
                q = floor(qMinusT / baseMinusT);
                output.push(stringFromCharCode(digitToBasic(q, 0))), bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength), 
                delta = 0, ++handledCPCount;
            }
            ++delta, ++n;
        }
        return output.join("");
    }
    function toUnicode(domain) {
        return mapDomain(domain, function(string) {
            return regexPunycode.test(string) ? decode(string.slice(4).toLowerCase()) : string;
        });
    }
    function toASCII(domain) {
        return mapDomain(domain, function(string) {
            return regexNonASCII.test(string) ? "xn--" + encode(string) : string;
        });
    }
    var punycode, key, freeDefine = "function" == typeof define && "object" == typeof define.amd && define.amd && define, freeExports = "object" == typeof exports && exports, freeModule = "object" == typeof module && module, maxInt = 2147483647, base = 36, tMin = 1, tMax = 26, skew = 38, damp = 700, initialBias = 72, initialN = 128, delimiter = "-", regexNonASCII = /[^ -~]/, regexPunycode = /^xn--/, errors = {
        overflow: "Overflow: input needs wider integers to process.",
        "not-basic": "Illegal input >= 0x80 (not a basic code point)",
        "invalid-input": "Invalid input"
    }, baseMinusTMin = base - tMin, floor = Math.floor, stringFromCharCode = String.fromCharCode;
    if (punycode = {
        version: "1.1.1",
        ucs2: {
            decode: ucs2decode,
            encode: ucs2encode
        },
        decode: decode,
        encode: encode,
        toASCII: toASCII,
        toUnicode: toUnicode
    }, freeExports) if (freeModule && freeModule.exports == freeExports) freeModule.exports = punycode; else for (key in punycode) punycode.hasOwnProperty(key) && (freeExports[key] = punycode[key]); else freeDefine ? define("punycode", punycode) : root.punycode = punycode;
}(this), define("uri/punycode", function() {}), function(root, factory) {
    "object" == typeof exports ? module.exports = factory() : "function" == typeof define && define.amd ? define("uri/IPv6", factory) : root.IPv6 = factory();
}(this, function() {
    function best(address) {
        var _address = address.toLowerCase(), segments = _address.split(":"), length = segments.length, total = 8;
        "" === segments[0] && "" === segments[1] && "" === segments[2] ? (segments.shift(), 
        segments.shift()) : "" === segments[0] && "" === segments[1] ? segments.shift() : "" === segments[length - 1] && "" === segments[length - 2] && segments.pop(), 
        length = segments.length, -1 !== segments[length - 1].indexOf(".") && (total = 7);
        var pos;
        for (pos = 0; length > pos && "" !== segments[pos]; pos++) ;
        if (total > pos) {
            for (segments.splice(pos, 1, "0000"); segments.length < total; ) segments.splice(pos, 0, "0000");
            length = segments.length;
        }
        for (var _segments, i = 0; total > i; i++) {
            _segments = segments[i].split("");
            for (var j = 0; 3 > j && ("0" === _segments[0] && _segments.length > 1); j++) _segments.splice(0, 1);
            segments[i] = _segments.join("");
        }
        var best = -1, _best = 0, _current = 0, current = -1, inzeroes = !1;
        for (i = 0; total > i; i++) inzeroes ? "0" === segments[i] ? _current += 1 : (inzeroes = !1, 
        _current > _best && (best = current, _best = _current)) : "0" == segments[i] && (inzeroes = !0, 
        current = i, _current = 1);
        _current > _best && (best = current, _best = _current), _best > 1 && segments.splice(best, _best, ""), 
        length = segments.length;
        var result = "";
        for ("" === segments[0] && (beststr = ":"), i = 0; length > i && (result += segments[i], 
        i !== length - 1); i++) result += ":";
        return "" === segments[length - 1] && (result += ":"), result;
    }
    return {
        best: best
    };
}), function(root, factory) {
    "object" == typeof exports ? module.exports = factory() : "function" == typeof define && define.amd ? define("uri/SecondLevelDomains", factory) : root.SecondLevelDomains = factory();
}(this, function() {
    var hasOwn = Object.prototype.hasOwnProperty, SLD = {
        list: {
            ac: "com|gov|mil|net|org",
            ae: "ac|co|gov|mil|name|net|org|pro|sch",
            af: "com|edu|gov|net|org",
            al: "com|edu|gov|mil|net|org",
            ao: "co|ed|gv|it|og|pb",
            ar: "com|edu|gob|gov|int|mil|net|org|tur",
            at: "ac|co|gv|or",
            au: "asn|com|csiro|edu|gov|id|net|org",
            ba: "co|com|edu|gov|mil|net|org|rs|unbi|unmo|unsa|untz|unze",
            bb: "biz|co|com|edu|gov|info|net|org|store|tv",
            bh: "biz|cc|com|edu|gov|info|net|org",
            bn: "com|edu|gov|net|org",
            bo: "com|edu|gob|gov|int|mil|net|org|tv",
            br: "adm|adv|agr|am|arq|art|ato|b|bio|blog|bmd|cim|cng|cnt|com|coop|ecn|edu|eng|esp|etc|eti|far|flog|fm|fnd|fot|fst|g12|ggf|gov|imb|ind|inf|jor|jus|lel|mat|med|mil|mus|net|nom|not|ntr|odo|org|ppg|pro|psc|psi|qsl|rec|slg|srv|tmp|trd|tur|tv|vet|vlog|wiki|zlg",
            bs: "com|edu|gov|net|org",
            bz: "du|et|om|ov|rg",
            ca: "ab|bc|mb|nb|nf|nl|ns|nt|nu|on|pe|qc|sk|yk",
            ck: "biz|co|edu|gen|gov|info|net|org",
            cn: "ac|ah|bj|com|cq|edu|fj|gd|gov|gs|gx|gz|ha|hb|he|hi|hl|hn|jl|js|jx|ln|mil|net|nm|nx|org|qh|sc|sd|sh|sn|sx|tj|tw|xj|xz|yn|zj",
            co: "com|edu|gov|mil|net|nom|org",
            cr: "ac|c|co|ed|fi|go|or|sa",
            cy: "ac|biz|com|ekloges|gov|ltd|name|net|org|parliament|press|pro|tm",
            "do": "art|com|edu|gob|gov|mil|net|org|sld|web",
            dz: "art|asso|com|edu|gov|net|org|pol",
            ec: "com|edu|fin|gov|info|med|mil|net|org|pro",
            eg: "com|edu|eun|gov|mil|name|net|org|sci",
            er: "com|edu|gov|ind|mil|net|org|rochest|w",
            es: "com|edu|gob|nom|org",
            et: "biz|com|edu|gov|info|name|net|org",
            fj: "ac|biz|com|info|mil|name|net|org|pro",
            fk: "ac|co|gov|net|nom|org",
            fr: "asso|com|f|gouv|nom|prd|presse|tm",
            gg: "co|net|org",
            gh: "com|edu|gov|mil|org",
            gn: "ac|com|gov|net|org",
            gr: "com|edu|gov|mil|net|org",
            gt: "com|edu|gob|ind|mil|net|org",
            gu: "com|edu|gov|net|org",
            hk: "com|edu|gov|idv|net|org",
            id: "ac|co|go|mil|net|or|sch|web",
            il: "ac|co|gov|idf|k12|muni|net|org",
            "in": "ac|co|edu|ernet|firm|gen|gov|i|ind|mil|net|nic|org|res",
            iq: "com|edu|gov|i|mil|net|org",
            ir: "ac|co|dnssec|gov|i|id|net|org|sch",
            it: "edu|gov",
            je: "co|net|org",
            jo: "com|edu|gov|mil|name|net|org|sch",
            jp: "ac|ad|co|ed|go|gr|lg|ne|or",
            ke: "ac|co|go|info|me|mobi|ne|or|sc",
            kh: "com|edu|gov|mil|net|org|per",
            ki: "biz|com|de|edu|gov|info|mob|net|org|tel",
            km: "asso|com|coop|edu|gouv|k|medecin|mil|nom|notaires|pharmaciens|presse|tm|veterinaire",
            kn: "edu|gov|net|org",
            kr: "ac|busan|chungbuk|chungnam|co|daegu|daejeon|es|gangwon|go|gwangju|gyeongbuk|gyeonggi|gyeongnam|hs|incheon|jeju|jeonbuk|jeonnam|k|kg|mil|ms|ne|or|pe|re|sc|seoul|ulsan",
            kw: "com|edu|gov|net|org",
            ky: "com|edu|gov|net|org",
            kz: "com|edu|gov|mil|net|org",
            lb: "com|edu|gov|net|org",
            lk: "assn|com|edu|gov|grp|hotel|int|ltd|net|ngo|org|sch|soc|web",
            lr: "com|edu|gov|net|org",
            lv: "asn|com|conf|edu|gov|id|mil|net|org",
            ly: "com|edu|gov|id|med|net|org|plc|sch",
            ma: "ac|co|gov|m|net|org|press",
            mc: "asso|tm",
            me: "ac|co|edu|gov|its|net|org|priv",
            mg: "com|edu|gov|mil|nom|org|prd|tm",
            mk: "com|edu|gov|inf|name|net|org|pro",
            ml: "com|edu|gov|net|org|presse",
            mn: "edu|gov|org",
            mo: "com|edu|gov|net|org",
            mt: "com|edu|gov|net|org",
            mv: "aero|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro",
            mw: "ac|co|com|coop|edu|gov|int|museum|net|org",
            mx: "com|edu|gob|net|org",
            my: "com|edu|gov|mil|name|net|org|sch",
            nf: "arts|com|firm|info|net|other|per|rec|store|web",
            ng: "biz|com|edu|gov|mil|mobi|name|net|org|sch",
            ni: "ac|co|com|edu|gob|mil|net|nom|org",
            np: "com|edu|gov|mil|net|org",
            nr: "biz|com|edu|gov|info|net|org",
            om: "ac|biz|co|com|edu|gov|med|mil|museum|net|org|pro|sch",
            pe: "com|edu|gob|mil|net|nom|org|sld",
            ph: "com|edu|gov|i|mil|net|ngo|org",
            pk: "biz|com|edu|fam|gob|gok|gon|gop|gos|gov|net|org|web",
            pl: "art|bialystok|biz|com|edu|gda|gdansk|gorzow|gov|info|katowice|krakow|lodz|lublin|mil|net|ngo|olsztyn|org|poznan|pwr|radom|slupsk|szczecin|torun|warszawa|waw|wroc|wroclaw|zgora",
            pr: "ac|biz|com|edu|est|gov|info|isla|name|net|org|pro|prof",
            ps: "com|edu|gov|net|org|plo|sec",
            pw: "belau|co|ed|go|ne|or",
            ro: "arts|com|firm|info|nom|nt|org|rec|store|tm|www",
            rs: "ac|co|edu|gov|in|org",
            sb: "com|edu|gov|net|org",
            sc: "com|edu|gov|net|org",
            sh: "co|com|edu|gov|net|nom|org",
            sl: "com|edu|gov|net|org",
            st: "co|com|consulado|edu|embaixada|gov|mil|net|org|principe|saotome|store",
            sv: "com|edu|gob|org|red",
            sz: "ac|co|org",
            tr: "av|bbs|bel|biz|com|dr|edu|gen|gov|info|k12|name|net|org|pol|tel|tsk|tv|web",
            tt: "aero|biz|cat|co|com|coop|edu|gov|info|int|jobs|mil|mobi|museum|name|net|org|pro|tel|travel",
            tw: "club|com|ebiz|edu|game|gov|idv|mil|net|org",
            mu: "ac|co|com|gov|net|or|org",
            mz: "ac|co|edu|gov|org",
            na: "co|com",
            nz: "ac|co|cri|geek|gen|govt|health|iwi|maori|mil|net|org|parliament|school",
            pa: "abo|ac|com|edu|gob|ing|med|net|nom|org|sld",
            pt: "com|edu|gov|int|net|nome|org|publ",
            py: "com|edu|gov|mil|net|org",
            qa: "com|edu|gov|mil|net|org",
            re: "asso|com|nom",
            ru: "ac|adygeya|altai|amur|arkhangelsk|astrakhan|bashkiria|belgorod|bir|bryansk|buryatia|cbg|chel|chelyabinsk|chita|chukotka|chuvashia|com|dagestan|e-burg|edu|gov|grozny|int|irkutsk|ivanovo|izhevsk|jar|joshkar-ola|kalmykia|kaluga|kamchatka|karelia|kazan|kchr|kemerovo|khabarovsk|khakassia|khv|kirov|koenig|komi|kostroma|kranoyarsk|kuban|kurgan|kursk|lipetsk|magadan|mari|mari-el|marine|mil|mordovia|mosreg|msk|murmansk|nalchik|net|nnov|nov|novosibirsk|nsk|omsk|orenburg|org|oryol|penza|perm|pp|pskov|ptz|rnd|ryazan|sakhalin|samara|saratov|simbirsk|smolensk|spb|stavropol|stv|surgut|tambov|tatarstan|tom|tomsk|tsaritsyn|tsk|tula|tuva|tver|tyumen|udm|udmurtia|ulan-ude|vladikavkaz|vladimir|vladivostok|volgograd|vologda|voronezh|vrn|vyatka|yakutia|yamal|yekaterinburg|yuzhno-sakhalinsk",
            rw: "ac|co|com|edu|gouv|gov|int|mil|net",
            sa: "com|edu|gov|med|net|org|pub|sch",
            sd: "com|edu|gov|info|med|net|org|tv",
            se: "a|ac|b|bd|c|d|e|f|g|h|i|k|l|m|n|o|org|p|parti|pp|press|r|s|t|tm|u|w|x|y|z",
            sg: "com|edu|gov|idn|net|org|per",
            sn: "art|com|edu|gouv|org|perso|univ",
            sy: "com|edu|gov|mil|net|news|org",
            th: "ac|co|go|in|mi|net|or",
            tj: "ac|biz|co|com|edu|go|gov|info|int|mil|name|net|nic|org|test|web",
            tn: "agrinet|com|defense|edunet|ens|fin|gov|ind|info|intl|mincom|nat|net|org|perso|rnrt|rns|rnu|tourism",
            tz: "ac|co|go|ne|or",
            ua: "biz|cherkassy|chernigov|chernovtsy|ck|cn|co|com|crimea|cv|dn|dnepropetrovsk|donetsk|dp|edu|gov|if|in|ivano-frankivsk|kh|kharkov|kherson|khmelnitskiy|kiev|kirovograd|km|kr|ks|kv|lg|lugansk|lutsk|lviv|me|mk|net|nikolaev|od|odessa|org|pl|poltava|pp|rovno|rv|sebastopol|sumy|te|ternopil|uzhgorod|vinnica|vn|zaporizhzhe|zhitomir|zp|zt",
            ug: "ac|co|go|ne|or|org|sc",
            uk: "ac|bl|british-library|co|cym|gov|govt|icnet|jet|lea|ltd|me|mil|mod|national-library-scotland|nel|net|nhs|nic|nls|org|orgn|parliament|plc|police|sch|scot|soc",
            us: "dni|fed|isa|kids|nsn",
            uy: "com|edu|gub|mil|net|org",
            ve: "co|com|edu|gob|info|mil|net|org|web",
            vi: "co|com|k12|net|org",
            vn: "ac|biz|com|edu|gov|health|info|int|name|net|org|pro",
            ye: "co|com|gov|ltd|me|net|org|plc",
            yu: "ac|co|edu|gov|org",
            za: "ac|agric|alt|bourse|city|co|cybernet|db|edu|gov|grondar|iaccess|imt|inca|landesign|law|mil|net|ngo|nis|nom|olivetti|org|pix|school|tm|web",
            zm: "ac|co|com|edu|gov|net|org|sch"
        },
        has_expression: null,
        is_expression: null,
        has: function(domain) {
            return !!domain.match(SLD.has_expression);
        },
        is: function(domain) {
            return !!domain.match(SLD.is_expression);
        },
        get: function(domain) {
            var t = domain.match(SLD.has_expression);
            return t && t[1] || null;
        },
        init: function() {
            var t = "";
            for (var tld in SLD.list) if (hasOwn.call(SLD.list, tld)) {
                var expression = "(" + SLD.list[tld] + ")." + tld;
                t += "|(" + expression + ")";
            }
            SLD.has_expression = new RegExp("\\.(" + t.substr(1) + ")$", "i"), SLD.is_expression = new RegExp("^(" + t.substr(1) + ")$", "i");
        }
    };
    return SLD.init(), SLD;
}), function(root, factory) {
    "object" == typeof exports ? module.exports = factory(require("./punycode"), require("./IPv6"), require("./SecondLevelDomains")) : "function" == typeof define && define.amd ? define("uri/URI", [ "./punycode", "./IPv6", "./SecondLevelDomains" ], factory) : root.URI = factory(root.punycode, root.IPv6, root.SecondLevelDomains);
}(this, function(punycode, IPv6, SLD) {
    function URI(url, base) {
        return this instanceof URI ? (void 0 === url && (url = "undefined" != typeof location ? location.href + "" : ""), 
        this.href(url), void 0 !== base ? this.absoluteTo(base) : this) : new URI(url, base);
    }
    function escapeRegEx(string) {
        return string.replace(/([.*+?^=!:${}()|[\]\/\\])/g, "\\$1");
    }
    function getType(value) {
        return String(Object.prototype.toString.call(value)).slice(8, -1);
    }
    function isArray(obj) {
        return "Array" === getType(obj);
    }
    function filterArrayValues(data, value) {
        var i, length, lookup = {};
        if (isArray(value)) for (i = 0, length = value.length; length > i; i++) lookup[value[i]] = !0; else lookup[value] = !0;
        for (i = 0, length = data.length; length > i; i++) void 0 !== lookup[data[i]] && (data.splice(i, 1), 
        length--, i--);
        return data;
    }
    function arrayContains(list, value) {
        var i, length;
        if (isArray(value)) {
            for (i = 0, length = value.length; length > i; i++) if (!arrayContains(list, value[i])) return !1;
            return !0;
        }
        var _type = getType(value);
        for (i = 0, length = list.length; length > i; i++) if ("RegExp" === _type) {
            if ("string" == typeof list[i] && list[i].match(value)) return !0;
        } else if (list[i] === value) return !0;
        return !1;
    }
    function arraysEqual(one, two) {
        if (!isArray(one) || !isArray(two)) return !1;
        if (one.length !== two.length) return !1;
        one.sort(), two.sort();
        for (var i = 0, l = one.length; l > i; i++) if (one[i] !== two[i]) return !1;
        return !0;
    }
    function strictEncodeURIComponent(string) {
        return encodeURIComponent(string).replace(/[!'()*]/g, escape).replace(/\*/g, "%2A");
    }
    var p = URI.prototype, hasOwn = Object.prototype.hasOwnProperty;
    URI._parts = function() {
        return {
            protocol: null,
            username: null,
            password: null,
            hostname: null,
            urn: null,
            port: null,
            path: null,
            query: null,
            fragment: null,
            duplicateQueryParameters: URI.duplicateQueryParameters
        };
    }, URI.duplicateQueryParameters = !1, URI.protocol_expression = /^[a-z][a-z0-9-+-]*$/i, 
    URI.idn_expression = /[^a-z0-9\.-]/i, URI.punycode_expression = /(xn--)/i, URI.ip4_expression = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/, 
    URI.ip6_expression = /^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/, 
    URI.find_uri_expression = /\b((?:[a-z][\w-]+:(?:\/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'".,<>?\xab\xbb\u201c\u201d\u2018\u2019]))/gi, 
    URI.defaultPorts = {
        http: "80",
        https: "443",
        ftp: "21",
        gopher: "70",
        ws: "80",
        wss: "443"
    }, URI.invalid_hostname_characters = /[^a-zA-Z0-9\.-]/, URI.encode = strictEncodeURIComponent, 
    URI.decode = decodeURIComponent, URI.iso8859 = function() {
        URI.encode = escape, URI.decode = unescape;
    }, URI.unicode = function() {
        URI.encode = strictEncodeURIComponent, URI.decode = decodeURIComponent;
    }, URI.characters = {
        pathname: {
            encode: {
                expression: /%(24|26|2B|2C|3B|3D|3A|40)/gi,
                map: {
                    "%24": "$",
                    "%26": "&",
                    "%2B": "+",
                    "%2C": ",",
                    "%3B": ";",
                    "%3D": "=",
                    "%3A": ":",
                    "%40": "@"
                }
            },
            decode: {
                expression: /[\/\?#]/g,
                map: {
                    "/": "%2F",
                    "?": "%3F",
                    "#": "%23"
                }
            }
        },
        reserved: {
            encode: {
                expression: /%(21|23|24|26|27|28|29|2A|2B|2C|2F|3A|3B|3D|3F|40|5B|5D)/gi,
                map: {
                    "%3A": ":",
                    "%2F": "/",
                    "%3F": "?",
                    "%23": "#",
                    "%5B": "[",
                    "%5D": "]",
                    "%40": "@",
                    "%21": "!",
                    "%24": "$",
                    "%26": "&",
                    "%27": "'",
                    "%28": "(",
                    "%29": ")",
                    "%2A": "*",
                    "%2B": "+",
                    "%2C": ",",
                    "%3B": ";",
                    "%3D": "="
                }
            }
        }
    }, URI.encodeQuery = function(string) {
        return URI.encode(string + "").replace(/%20/g, "+");
    }, URI.decodeQuery = function(string) {
        return URI.decode((string + "").replace(/\+/g, "%20"));
    }, URI.recodePath = function(string) {
        for (var segments = (string + "").split("/"), i = 0, length = segments.length; length > i; i++) segments[i] = URI.encodePathSegment(URI.decode(segments[i]));
        return segments.join("/");
    }, URI.decodePath = function(string) {
        for (var segments = (string + "").split("/"), i = 0, length = segments.length; length > i; i++) segments[i] = URI.decodePathSegment(segments[i]);
        return segments.join("/");
    };
    var _part, _parts = {
        encode: "encode",
        decode: "decode"
    }, generateAccessor = function(_group, _part) {
        return function(string) {
            return URI[_part](string + "").replace(URI.characters[_group][_part].expression, function(c) {
                return URI.characters[_group][_part].map[c];
            });
        };
    };
    for (_part in _parts) URI[_part + "PathSegment"] = generateAccessor("pathname", _parts[_part]);
    URI.encodeReserved = generateAccessor("reserved", "encode"), URI.parse = function(string, parts) {
        var pos;
        return parts || (parts = {}), pos = string.indexOf("#"), pos > -1 && (parts.fragment = string.substring(pos + 1) || null, 
        string = string.substring(0, pos)), pos = string.indexOf("?"), pos > -1 && (parts.query = string.substring(pos + 1) || null, 
        string = string.substring(0, pos)), "//" === string.substring(0, 2) ? (parts.protocol = "", 
        string = string.substring(2), string = URI.parseAuthority(string, parts)) : (pos = string.indexOf(":"), 
        pos > -1 && (parts.protocol = string.substring(0, pos), parts.protocol && !parts.protocol.match(URI.protocol_expression) ? parts.protocol = void 0 : "file" === parts.protocol ? string = string.substring(pos + 3) : "//" === string.substring(pos + 1, pos + 3) ? (string = string.substring(pos + 3), 
        string = URI.parseAuthority(string, parts)) : (string = string.substring(pos + 1), 
        parts.urn = !0))), parts.path = string, parts;
    }, URI.parseHost = function(string, parts) {
        var bracketPos, t, pos = string.indexOf("/");
        return -1 === pos && (pos = string.length), "[" === string.charAt(0) ? (bracketPos = string.indexOf("]"), 
        parts.hostname = string.substring(1, bracketPos) || null, parts.port = string.substring(bracketPos + 2, pos) || null) : string.indexOf(":") !== string.lastIndexOf(":") ? (parts.hostname = string.substring(0, pos) || null, 
        parts.port = null) : (t = string.substring(0, pos).split(":"), parts.hostname = t[0] || null, 
        parts.port = t[1] || null), parts.hostname && "/" !== string.substring(pos).charAt(0) && (pos++, 
        string = "/" + string), string.substring(pos) || "/";
    }, URI.parseAuthority = function(string, parts) {
        return string = URI.parseUserinfo(string, parts), URI.parseHost(string, parts);
    }, URI.parseUserinfo = function(string, parts) {
        var t, pos = string.indexOf("@"), firstSlash = string.indexOf("/");
        return pos > -1 && (-1 === firstSlash || firstSlash > pos) ? (t = string.substring(0, pos).split(":"), 
        parts.username = t[0] ? URI.decode(t[0]) : null, t.shift(), parts.password = t[0] ? URI.decode(t.join(":")) : null, 
        string = string.substring(pos + 1)) : (parts.username = null, parts.password = null), 
        string;
    }, URI.parseQuery = function(string) {
        if (!string) return {};
        if (string = string.replace(/&+/g, "&").replace(/^\?*&*|&+$/g, ""), !string) return {};
        for (var v, name, value, items = {}, splits = string.split("&"), length = splits.length, i = 0; length > i; i++) v = splits[i].split("="), 
        name = URI.decodeQuery(v.shift()), value = v.length ? URI.decodeQuery(v.join("=")) : null, 
        items[name] ? ("string" == typeof items[name] && (items[name] = [ items[name] ]), 
        items[name].push(value)) : items[name] = value;
        return items;
    }, URI.build = function(parts) {
        var t = "";
        return parts.protocol && (t += parts.protocol + ":"), parts.urn || !t && !parts.hostname || (t += "//"), 
        t += URI.buildAuthority(parts) || "", "string" == typeof parts.path && ("/" !== parts.path.charAt(0) && "string" == typeof parts.hostname && (t += "/"), 
        t += parts.path), "string" == typeof parts.query && parts.query && (t += "?" + parts.query), 
        "string" == typeof parts.fragment && parts.fragment && (t += "#" + parts.fragment), 
        t;
    }, URI.buildHost = function(parts) {
        var t = "";
        return parts.hostname ? (URI.ip6_expression.test(parts.hostname) ? t += parts.port ? "[" + parts.hostname + "]:" + parts.port : parts.hostname : (t += parts.hostname, 
        parts.port && (t += ":" + parts.port)), t) : "";
    }, URI.buildAuthority = function(parts) {
        return URI.buildUserinfo(parts) + URI.buildHost(parts);
    }, URI.buildUserinfo = function(parts) {
        var t = "";
        return parts.username && (t += URI.encode(parts.username), parts.password && (t += ":" + URI.encode(parts.password)), 
        t += "@"), t;
    }, URI.buildQuery = function(data, duplicates) {
        var unique, key, i, length, t = "";
        for (key in data) if (hasOwn.call(data, key) && key) if (isArray(data[key])) for (unique = {}, 
        i = 0, length = data[key].length; length > i; i++) void 0 !== data[key][i] && void 0 === unique[data[key][i] + ""] && (t += "&" + URI.buildQueryParameter(key, data[key][i]), 
        duplicates !== !0 && (unique[data[key][i] + ""] = !0)); else void 0 !== data[key] && (t += "&" + URI.buildQueryParameter(key, data[key]));
        return t.substring(1);
    }, URI.buildQueryParameter = function(name, value) {
        return URI.encodeQuery(name) + (null !== value ? "=" + URI.encodeQuery(value) : "");
    }, URI.addQuery = function(data, name, value) {
        if ("object" == typeof name) for (var key in name) hasOwn.call(name, key) && URI.addQuery(data, key, name[key]); else {
            if ("string" != typeof name) throw new TypeError("URI.addQuery() accepts an object, string as the name parameter");
            if (void 0 === data[name]) return void (data[name] = value);
            "string" == typeof data[name] && (data[name] = [ data[name] ]), isArray(value) || (value = [ value ]), 
            data[name] = data[name].concat(value);
        }
    }, URI.removeQuery = function(data, name, value) {
        var i, length, key;
        if (isArray(name)) for (i = 0, length = name.length; length > i; i++) data[name[i]] = void 0; else if ("object" == typeof name) for (key in name) hasOwn.call(name, key) && URI.removeQuery(data, key, name[key]); else {
            if ("string" != typeof name) throw new TypeError("URI.addQuery() accepts an object, string as the first parameter");
            void 0 !== value ? data[name] === value ? data[name] = void 0 : isArray(data[name]) && (data[name] = filterArrayValues(data[name], value)) : data[name] = void 0;
        }
    }, URI.hasQuery = function(data, name, value, withinArray) {
        if ("object" == typeof name) {
            for (var key in name) if (hasOwn.call(name, key) && !URI.hasQuery(data, key, name[key])) return !1;
            return !0;
        }
        if ("string" != typeof name) throw new TypeError("URI.hasQuery() accepts an object, string as the name parameter");
        switch (getType(value)) {
          case "Undefined":
            return name in data;

          case "Boolean":
            var _booly = Boolean(isArray(data[name]) ? data[name].length : data[name]);
            return value === _booly;

          case "Function":
            return !!value(data[name], name, data);

          case "Array":
            if (!isArray(data[name])) return !1;
            var op = withinArray ? arrayContains : arraysEqual;
            return op(data[name], value);

          case "RegExp":
            return isArray(data[name]) ? withinArray ? arrayContains(data[name], value) : !1 : Boolean(data[name] && data[name].match(value));

          case "Number":
            value = String(value);

          case "String":
            return isArray(data[name]) ? withinArray ? arrayContains(data[name], value) : !1 : data[name] === value;

          default:
            throw new TypeError("URI.hasQuery() accepts undefined, boolean, string, number, RegExp, Function as the value parameter");
        }
    }, URI.commonPath = function(one, two) {
        var pos, length = Math.min(one.length, two.length);
        for (pos = 0; length > pos; pos++) if (one.charAt(pos) !== two.charAt(pos)) {
            pos--;
            break;
        }
        return 1 > pos ? one.charAt(0) === two.charAt(0) && "/" === one.charAt(0) ? "/" : "" : (("/" !== one.charAt(pos) || "/" !== two.charAt(pos)) && (pos = one.substring(0, pos).lastIndexOf("/")), 
        one.substring(0, pos + 1));
    }, URI.withinString = function(string, callback) {
        return string.replace(URI.find_uri_expression, callback);
    }, URI.ensureValidHostname = function(v) {
        if (v.match(URI.invalid_hostname_characters)) {
            if (!punycode) throw new TypeError("Hostname '" + v + "' contains characters other than [A-Z0-9.-] and Punycode.js is not available");
            if (punycode.toASCII(v).match(URI.invalid_hostname_characters)) throw new TypeError("Hostname '" + v + "' contains characters other than [A-Z0-9.-]");
        }
    }, p.build = function(deferBuild) {
        return deferBuild === !0 ? this._deferred_build = !0 : (void 0 === deferBuild || this._deferred_build) && (this._string = URI.build(this._parts), 
        this._deferred_build = !1), this;
    }, p.clone = function() {
        return new URI(this);
    }, p.valueOf = p.toString = function() {
        return this.build(!1)._string;
    }, _parts = {
        protocol: "protocol",
        username: "username",
        password: "password",
        hostname: "hostname",
        port: "port"
    }, generateAccessor = function(_part) {
        return function(v, build) {
            return void 0 === v ? this._parts[_part] || "" : (this._parts[_part] = v, this.build(!build), 
            this);
        };
    };
    for (_part in _parts) p[_part] = generateAccessor(_parts[_part]);
    _parts = {
        query: "?",
        fragment: "#"
    }, generateAccessor = function(_part, _key) {
        return function(v, build) {
            return void 0 === v ? this._parts[_part] || "" : (null !== v && (v += "", v.charAt(0) === _key && (v = v.substring(1))), 
            this._parts[_part] = v, this.build(!build), this);
        };
    };
    for (_part in _parts) p[_part] = generateAccessor(_part, _parts[_part]);
    _parts = {
        search: [ "?", "query" ],
        hash: [ "#", "fragment" ]
    }, generateAccessor = function(_part, _key) {
        return function(v, build) {
            var t = this[_part](v, build);
            return "string" == typeof t && t.length ? _key + t : t;
        };
    };
    for (_part in _parts) p[_part] = generateAccessor(_parts[_part][1], _parts[_part][0]);
    p.pathname = function(v, build) {
        if (void 0 === v || v === !0) {
            var res = this._parts.path || (this._parts.urn ? "" : "/");
            return v ? URI.decodePath(res) : res;
        }
        return this._parts.path = v ? URI.recodePath(v) : "/", this.build(!build), this;
    }, p.path = p.pathname, p.href = function(href, build) {
        var key;
        if (void 0 === href) return this.toString();
        this._string = "", this._parts = URI._parts();
        var _URI = href instanceof URI, _object = "object" == typeof href && (href.hostname || href.path);
        if (!_URI && _object && void 0 !== href.pathname && (href = href.toString()), "string" == typeof href) this._parts = URI.parse(href, this._parts); else {
            if (!_URI && !_object) throw new TypeError("invalid input");
            var src = _URI ? href._parts : href;
            for (key in src) hasOwn.call(this._parts, key) && (this._parts[key] = src[key]);
        }
        return this.build(!build), this;
    }, p.is = function(what) {
        var ip = !1, ip4 = !1, ip6 = !1, name = !1, sld = !1, idn = !1, punycode = !1, relative = !this._parts.urn;
        switch (this._parts.hostname && (relative = !1, ip4 = URI.ip4_expression.test(this._parts.hostname), 
        ip6 = URI.ip6_expression.test(this._parts.hostname), ip = ip4 || ip6, name = !ip, 
        sld = name && SLD && SLD.has(this._parts.hostname), idn = name && URI.idn_expression.test(this._parts.hostname), 
        punycode = name && URI.punycode_expression.test(this._parts.hostname)), what.toLowerCase()) {
          case "relative":
            return relative;

          case "absolute":
            return !relative;

          case "domain":
          case "name":
            return name;

          case "sld":
            return sld;

          case "ip":
            return ip;

          case "ip4":
          case "ipv4":
          case "inet4":
            return ip4;

          case "ip6":
          case "ipv6":
          case "inet6":
            return ip6;

          case "idn":
            return idn;

          case "url":
            return !this._parts.urn;

          case "urn":
            return !!this._parts.urn;

          case "punycode":
            return punycode;
        }
        return null;
    };
    var _protocol = p.protocol, _port = p.port, _hostname = p.hostname;
    p.protocol = function(v, build) {
        if (void 0 !== v && v && (v = v.replace(/:(\/\/)?$/, ""), v.match(/[^a-zA-z0-9\.+-]/))) throw new TypeError("Protocol '" + v + "' contains characters other than [A-Z0-9.+-]");
        return _protocol.call(this, v, build);
    }, p.scheme = p.protocol, p.port = function(v, build) {
        if (this._parts.urn) return void 0 === v ? "" : this;
        if (void 0 !== v && (0 === v && (v = null), v && (v += "", ":" === v.charAt(0) && (v = v.substring(1)), 
        v.match(/[^0-9]/)))) throw new TypeError("Port '" + v + "' contains characters other than [0-9]");
        return _port.call(this, v, build);
    }, p.hostname = function(v, build) {
        if (this._parts.urn) return void 0 === v ? "" : this;
        if (void 0 !== v) {
            var x = {};
            URI.parseHost(v, x), v = x.hostname;
        }
        return _hostname.call(this, v, build);
    }, p.host = function(v, build) {
        return this._parts.urn ? void 0 === v ? "" : this : void 0 === v ? this._parts.hostname ? URI.buildHost(this._parts) : "" : (URI.parseHost(v, this._parts), 
        this.build(!build), this);
    }, p.authority = function(v, build) {
        return this._parts.urn ? void 0 === v ? "" : this : void 0 === v ? this._parts.hostname ? URI.buildAuthority(this._parts) : "" : (URI.parseAuthority(v, this._parts), 
        this.build(!build), this);
    }, p.userinfo = function(v, build) {
        if (this._parts.urn) return void 0 === v ? "" : this;
        if (void 0 === v) {
            if (!this._parts.username) return "";
            var t = URI.buildUserinfo(this._parts);
            return t.substring(0, t.length - 1);
        }
        return "@" !== v[v.length - 1] && (v += "@"), URI.parseUserinfo(v, this._parts), 
        this.build(!build), this;
    }, p.resource = function(v, build) {
        var parts;
        return void 0 === v ? this.path() + this.search() + this.hash() : (parts = URI.parse(v), 
        this._parts.path = parts.path, this._parts.query = parts.query, this._parts.fragment = parts.fragment, 
        this.build(!build), this);
    }, p.subdomain = function(v, build) {
        if (this._parts.urn) return void 0 === v ? "" : this;
        if (void 0 === v) {
            if (!this._parts.hostname || this.is("IP")) return "";
            var end = this._parts.hostname.length - this.domain().length - 1;
            return this._parts.hostname.substring(0, end) || "";
        }
        var e = this._parts.hostname.length - this.domain().length, sub = this._parts.hostname.substring(0, e), replace = new RegExp("^" + escapeRegEx(sub));
        return v && "." !== v.charAt(v.length - 1) && (v += "."), v && URI.ensureValidHostname(v), 
        this._parts.hostname = this._parts.hostname.replace(replace, v), this.build(!build), 
        this;
    }, p.domain = function(v, build) {
        if (this._parts.urn) return void 0 === v ? "" : this;
        if ("boolean" == typeof v && (build = v, v = void 0), void 0 === v) {
            if (!this._parts.hostname || this.is("IP")) return "";
            var t = this._parts.hostname.match(/\./g);
            if (t && t.length < 2) return this._parts.hostname;
            var end = this._parts.hostname.length - this.tld(build).length - 1;
            return end = this._parts.hostname.lastIndexOf(".", end - 1) + 1, this._parts.hostname.substring(end) || "";
        }
        if (!v) throw new TypeError("cannot set domain empty");
        if (URI.ensureValidHostname(v), !this._parts.hostname || this.is("IP")) this._parts.hostname = v; else {
            var replace = new RegExp(escapeRegEx(this.domain()) + "$");
            this._parts.hostname = this._parts.hostname.replace(replace, v);
        }
        return this.build(!build), this;
    }, p.tld = function(v, build) {
        if (this._parts.urn) return void 0 === v ? "" : this;
        if ("boolean" == typeof v && (build = v, v = void 0), void 0 === v) {
            if (!this._parts.hostname || this.is("IP")) return "";
            var pos = this._parts.hostname.lastIndexOf("."), tld = this._parts.hostname.substring(pos + 1);
            return build !== !0 && SLD && SLD.list[tld.toLowerCase()] ? SLD.get(this._parts.hostname) || tld : tld;
        }
        var replace;
        if (!v) throw new TypeError("cannot set TLD empty");
        if (v.match(/[^a-zA-Z0-9-]/)) {
            if (!SLD || !SLD.is(v)) throw new TypeError("TLD '" + v + "' contains characters other than [A-Z0-9]");
            replace = new RegExp(escapeRegEx(this.tld()) + "$"), this._parts.hostname = this._parts.hostname.replace(replace, v);
        } else {
            if (!this._parts.hostname || this.is("IP")) throw new ReferenceError("cannot set TLD on non-domain host");
            replace = new RegExp(escapeRegEx(this.tld()) + "$"), this._parts.hostname = this._parts.hostname.replace(replace, v);
        }
        return this.build(!build), this;
    }, p.directory = function(v, build) {
        if (this._parts.urn) return void 0 === v ? "" : this;
        if (void 0 === v || v === !0) {
            if (!this._parts.path && !this._parts.hostname) return "";
            if ("/" === this._parts.path) return "/";
            var end = this._parts.path.length - this.filename().length - 1, res = this._parts.path.substring(0, end) || (this._parts.hostname ? "/" : "");
            return v ? URI.decodePath(res) : res;
        }
        var e = this._parts.path.length - this.filename().length, directory = this._parts.path.substring(0, e), replace = new RegExp("^" + escapeRegEx(directory));
        return this.is("relative") || (v || (v = "/"), "/" !== v.charAt(0) && (v = "/" + v)), 
        v && "/" !== v.charAt(v.length - 1) && (v += "/"), v = URI.recodePath(v), this._parts.path = this._parts.path.replace(replace, v), 
        this.build(!build), this;
    }, p.filename = function(v, build) {
        if (this._parts.urn) return void 0 === v ? "" : this;
        if (void 0 === v || v === !0) {
            if (!this._parts.path || "/" === this._parts.path) return "";
            var pos = this._parts.path.lastIndexOf("/"), res = this._parts.path.substring(pos + 1);
            return v ? URI.decodePathSegment(res) : res;
        }
        var mutatedDirectory = !1;
        "/" === v.charAt(0) && (v = v.substring(1)), v.match(/\.?\//) && (mutatedDirectory = !0);
        var replace = new RegExp(escapeRegEx(this.filename()) + "$");
        return v = URI.recodePath(v), this._parts.path = this._parts.path.replace(replace, v), 
        mutatedDirectory ? this.normalizePath(build) : this.build(!build), this;
    }, p.suffix = function(v, build) {
        if (this._parts.urn) return void 0 === v ? "" : this;
        if (void 0 === v || v === !0) {
            if (!this._parts.path || "/" === this._parts.path) return "";
            var s, res, filename = this.filename(), pos = filename.lastIndexOf(".");
            return -1 === pos ? "" : (s = filename.substring(pos + 1), res = /^[a-z0-9%]+$/i.test(s) ? s : "", 
            v ? URI.decodePathSegment(res) : res);
        }
        "." === v.charAt(0) && (v = v.substring(1));
        var replace, suffix = this.suffix();
        if (suffix) replace = new RegExp(v ? escapeRegEx(suffix) + "$" : escapeRegEx("." + suffix) + "$"); else {
            if (!v) return this;
            this._parts.path += "." + URI.recodePath(v);
        }
        return replace && (v = URI.recodePath(v), this._parts.path = this._parts.path.replace(replace, v)), 
        this.build(!build), this;
    }, p.segment = function(segment, v, build) {
        var separator = this._parts.urn ? ":" : "/", path = this.path(), absolute = "/" === path.substring(0, 1), segments = path.split(separator);
        if ("number" != typeof segment && (build = v, v = segment, segment = void 0), void 0 !== segment && "number" != typeof segment) throw new Error("Bad segment '" + segment + "', must be 0-based integer");
        return absolute && segments.shift(), 0 > segment && (segment = Math.max(segments.length + segment, 0)), 
        void 0 === v ? void 0 === segment ? segments : segments[segment] : (null === segment || void 0 === segments[segment] ? isArray(v) ? segments = v : (v || "string" == typeof v && v.length) && ("" === segments[segments.length - 1] ? segments[segments.length - 1] = v : segments.push(v)) : v || "string" == typeof v && v.length ? segments[segment] = v : segments.splice(segment, 1), 
        absolute && segments.unshift(""), this.path(segments.join(separator), build));
    };
    var q = p.query;
    return p.query = function(v, build) {
        if (v === !0) return URI.parseQuery(this._parts.query);
        if ("function" == typeof v) {
            var data = URI.parseQuery(this._parts.query), result = v.call(this, data);
            return this._parts.query = URI.buildQuery(result || data, this._parts.duplicateQueryParameters), 
            this.build(!build), this;
        }
        return void 0 !== v && "string" != typeof v ? (this._parts.query = URI.buildQuery(v, this._parts.duplicateQueryParameters), 
        this.build(!build), this) : q.call(this, v, build);
    }, p.setQuery = function(name, value, build) {
        var data = URI.parseQuery(this._parts.query);
        if ("object" == typeof name) for (var key in name) hasOwn.call(name, key) && (data[key] = name[key]); else {
            if ("string" != typeof name) throw new TypeError("URI.addQuery() accepts an object, string as the name parameter");
            data[name] = void 0 !== value ? value : null;
        }
        return this._parts.query = URI.buildQuery(data, this._parts.duplicateQueryParameters), 
        "string" != typeof name && (build = value), this.build(!build), this;
    }, p.addQuery = function(name, value, build) {
        var data = URI.parseQuery(this._parts.query);
        return URI.addQuery(data, name, void 0 === value ? null : value), this._parts.query = URI.buildQuery(data, this._parts.duplicateQueryParameters), 
        "string" != typeof name && (build = value), this.build(!build), this;
    }, p.removeQuery = function(name, value, build) {
        var data = URI.parseQuery(this._parts.query);
        return URI.removeQuery(data, name, value), this._parts.query = URI.buildQuery(data, this._parts.duplicateQueryParameters), 
        "string" != typeof name && (build = value), this.build(!build), this;
    }, p.hasQuery = function(name, value, withinArray) {
        var data = URI.parseQuery(this._parts.query);
        return URI.hasQuery(data, name, value, withinArray);
    }, p.setSearch = p.setQuery, p.addSearch = p.addQuery, p.removeSearch = p.removeQuery, 
    p.hasSearch = p.hasQuery, p.normalize = function() {
        return this._parts.urn ? this.normalizeProtocol(!1).normalizeQuery(!1).normalizeFragment(!1).build() : this.normalizeProtocol(!1).normalizeHostname(!1).normalizePort(!1).normalizePath(!1).normalizeQuery(!1).normalizeFragment(!1).build();
    }, p.normalizeProtocol = function(build) {
        return "string" == typeof this._parts.protocol && (this._parts.protocol = this._parts.protocol.toLowerCase(), 
        this.build(!build)), this;
    }, p.normalizeHostname = function(build) {
        return this._parts.hostname && (this.is("IDN") && punycode ? this._parts.hostname = punycode.toASCII(this._parts.hostname) : this.is("IPv6") && IPv6 && (this._parts.hostname = IPv6.best(this._parts.hostname)), 
        this._parts.hostname = this._parts.hostname.toLowerCase(), this.build(!build)), 
        this;
    }, p.normalizePort = function(build) {
        return "string" == typeof this._parts.protocol && this._parts.port === URI.defaultPorts[this._parts.protocol] && (this._parts.port = null, 
        this.build(!build)), this;
    }, p.normalizePath = function(build) {
        if (this._parts.urn) return this;
        if (!this._parts.path || "/" === this._parts.path) return this;
        var _was_relative, _was_relative_prefix, _parent, _pos, _path = this._parts.path;
        for ("/" !== _path.charAt(0) && ("." === _path.charAt(0) && (_was_relative_prefix = _path.substring(0, _path.indexOf("/"))), 
        _was_relative = !0, _path = "/" + _path), _path = _path.replace(/(\/(\.\/)+)|\/{2,}/g, "/"); ;) {
            if (_parent = _path.indexOf("/../"), -1 === _parent) break;
            if (0 === _parent) {
                _path = _path.substring(3);
                break;
            }
            _pos = _path.substring(0, _parent).lastIndexOf("/"), -1 === _pos && (_pos = _parent), 
            _path = _path.substring(0, _pos) + _path.substring(_parent + 3);
        }
        return _was_relative && this.is("relative") && (_path = _path.substring(1)), _path = URI.recodePath(_path), 
        this._parts.path = _path, this.build(!build), this;
    }, p.normalizePathname = p.normalizePath, p.normalizeQuery = function(build) {
        return "string" == typeof this._parts.query && (this._parts.query.length ? this.query(URI.parseQuery(this._parts.query)) : this._parts.query = null, 
        this.build(!build)), this;
    }, p.normalizeFragment = function(build) {
        return this._parts.fragment || (this._parts.fragment = null, this.build(!build)), 
        this;
    }, p.normalizeSearch = p.normalizeQuery, p.normalizeHash = p.normalizeFragment, 
    p.iso8859 = function() {
        var e = URI.encode, d = URI.decode;
        return URI.encode = escape, URI.decode = decodeURIComponent, this.normalize(), URI.encode = e, 
        URI.decode = d, this;
    }, p.unicode = function() {
        var e = URI.encode, d = URI.decode;
        return URI.encode = strictEncodeURIComponent, URI.decode = unescape, this.normalize(), 
        URI.encode = e, URI.decode = d, this;
    }, p.readable = function() {
        var uri = this.clone();
        uri.username("").password("").normalize();
        var t = "";
        if (uri._parts.protocol && (t += uri._parts.protocol + "://"), uri._parts.hostname && (uri.is("punycode") && punycode ? (t += punycode.toUnicode(uri._parts.hostname), 
        uri._parts.port && (t += ":" + uri._parts.port)) : t += uri.host()), uri._parts.hostname && uri._parts.path && "/" !== uri._parts.path.charAt(0) && (t += "/"), 
        t += uri.path(!0), uri._parts.query) {
            for (var q = "", i = 0, qp = uri._parts.query.split("&"), l = qp.length; l > i; i++) {
                var kv = (qp[i] || "").split("=");
                q += "&" + URI.decodeQuery(kv[0]).replace(/&/g, "%26"), void 0 !== kv[1] && (q += "=" + URI.decodeQuery(kv[1]).replace(/&/g, "%26"));
            }
            t += "?" + q.substring(1);
        }
        return t += uri.hash();
    }, p.absoluteTo = function(base) {
        var basedir, i, p, resolved = this.clone(), properties = [ "protocol", "username", "password", "hostname", "port" ];
        if (this._parts.urn) throw new Error("URNs do not have any generally defined hierachical components");
        if (base instanceof URI || (base = new URI(base)), resolved._parts.protocol || (resolved._parts.protocol = base._parts.protocol), 
        this._parts.hostname) return resolved;
        for (i = 0, p; p = properties[i]; i++) resolved._parts[p] = base._parts[p];
        for (properties = [ "query", "path" ], i = 0, p; p = properties[i]; i++) !resolved._parts[p] && base._parts[p] && (resolved._parts[p] = base._parts[p]);
        return "/" !== resolved.path().charAt(0) && (basedir = base.directory(), resolved._parts.path = (basedir ? basedir + "/" : "") + resolved._parts.path, 
        resolved.normalizePath()), resolved.build(), resolved;
    }, p.relativeTo = function(base) {
        var common, _base, _this, _base_diff, _this_diff, relative = this.clone(), properties = [ "protocol", "username", "password", "hostname", "port" ];
        if (relative._parts.urn) throw new Error("URNs do not have any generally defined hierachical components");
        if (base instanceof URI || (base = new URI(base)), "/" !== relative.path().charAt(0) || "/" !== base.path().charAt(0)) throw new Error("Cannot calculate common path from non-relative URLs");
        common = URI.commonPath(relative.path(), base.path());
        for (var p, i = 0; p = properties[i]; i++) relative._parts[p] = null;
        if ("/" === common) return relative;
        if (!common) return this.clone();
        if (_base = base.directory(), _this = relative.directory(), _base === _this) return relative._parts.path = relative.filename(), 
        relative.build();
        if (_base_diff = _base.substring(common.length), _this_diff = _this.substring(common.length), 
        _base + "/" === common) return _this_diff && (_this_diff += "/"), relative._parts.path = _this_diff + relative.filename(), 
        relative.build();
        for (var parents = "../", _common = new RegExp("^" + escapeRegEx(common)), _parents = _base.replace(_common, "/").match(/\//g).length - 1; _parents--; ) parents += "../";
        return relative._parts.path = relative._parts.path.replace(_common, parents), relative.build();
    }, p.equals = function(uri) {
        var one_query, two_query, key, one = this.clone(), two = new URI(uri), one_map = {}, two_map = {}, checked = {};
        if (one.normalize(), two.normalize(), one.toString() === two.toString()) return !0;
        if (one_query = one.query(), two_query = two.query(), one.query(""), two.query(""), 
        one.toString() !== two.toString()) return !1;
        if (one_query.length !== two_query.length) return !1;
        one_map = URI.parseQuery(one_query), two_map = URI.parseQuery(two_query);
        for (key in one_map) if (hasOwn.call(one_map, key)) {
            if (isArray(one_map[key])) {
                if (!arraysEqual(one_map[key], two_map[key])) return !1;
            } else if (one_map[key] !== two_map[key]) return !1;
            checked[key] = !0;
        }
        for (key in two_map) if (hasOwn.call(two_map, key) && !checked[key]) return !1;
        return !0;
    }, p.duplicateQueryParameters = function(v) {
        return this._parts.duplicateQueryParameters = !!v, this;
    }, URI;
}), function(root, factory) {
    "object" == typeof exports ? module.exports = factory(require("./URI")) : "function" == typeof define && define.amd ? define("uri/URI.fragmentQuery", [ "./URI" ], factory) : factory(root.URI);
}(this, function(URI) {
    var p = URI.prototype, f = p.fragment;
    URI.fragmentPrefix = "?";
    var _parts = URI._parts;
    return URI._parts = function() {
        var parts = _parts();
        return parts.fragmentPrefix = URI.fragmentPrefix, parts;
    }, p.fragmentPrefix = function(v) {
        return this._parts.fragmentPrefix = v, this;
    }, p.fragment = function(v, build) {
        var prefix = this._parts.fragmentPrefix, fragment = this._parts.fragment || "";
        return v === !0 ? fragment.substring(0, prefix.length) !== prefix ? {} : URI.parseQuery(fragment.substring(prefix.length)) : void 0 !== v && "string" != typeof v ? (this._parts.fragment = prefix + URI.buildQuery(v), 
        this.build(!build), this) : f.call(this, v, build);
    }, p.addFragment = function(name, value, build) {
        var prefix = this._parts.fragmentPrefix, data = URI.parseQuery((this._parts.fragment || "").substring(prefix.length));
        return URI.addQuery(data, name, value), this._parts.fragment = prefix + URI.buildQuery(data), 
        "string" != typeof name && (build = value), this.build(!build), this;
    }, p.removeFragment = function(name, value, build) {
        var prefix = this._parts.fragmentPrefix, data = URI.parseQuery((this._parts.fragment || "").substring(prefix.length));
        return URI.removeQuery(data, name, value), this._parts.fragment = prefix + URI.buildQuery(data), 
        "string" != typeof name && (build = value), this.build(!build), this;
    }, p.addHash = p.addFragment, p.removeHash = p.removeFragment, {};
}), function(root, factory) {
    "object" == typeof exports ? module.exports = factory(require("./URI")) : "function" == typeof define && define.amd ? define("uri/URI.fragmentURI", [ "./URI" ], factory) : factory(root.URI);
}(this, function(URI) {
    var p = URI.prototype, f = p.fragment, b = p.build;
    URI.fragmentPrefix = "!";
    var _parts = URI._parts;
    return URI._parts = function() {
        var parts = _parts();
        return parts.fragmentPrefix = URI.fragmentPrefix, parts;
    }, p.fragmentPrefix = function(v) {
        return this._parts.fragmentPrefix = v, this;
    }, p.fragment = function(v, build) {
        var furi, prefix = this._parts.fragmentPrefix, fragment = this._parts.fragment || "";
        return v === !0 ? (furi = fragment.substring(0, prefix.length) !== prefix ? URI("") : new URI(fragment.substring(prefix.length)), 
        this._fragmentURI = furi, furi._parentURI = this, furi) : void 0 !== v && "string" != typeof v ? (this._fragmentURI = v, 
        v._parentURI = v, this._parts.fragment = prefix + v.toString(), this.build(!build), 
        this) : ("string" == typeof v && (this._fragmentURI = void 0), f.call(this, v, build));
    }, p.build = function(deferBuild) {
        var t = b.call(this, deferBuild);
        return deferBuild !== !1 && this._parentURI && this._parentURI.fragment(this), t;
    }, {};
}), define("jpmc/uri", [ "uri/URI", "uri/URI.fragmentQuery", "uri/URI.fragmentURI" ], function(URI) {
    return URI;
}), define("jpmc/util/lang/isURL", [ "jpmc/uri", "./isString" ], function(URI, isString) {
    return function(value) {
        var isURL = !1;
        if (isString(value)) try {
            var uri = new URI(value);
            isURL = uri.is("url");
        } catch (e) {}
        return isURL;
    };
}), define("jpmc/util/lang/kindOf", [ "mout/lang/kindOf" ], function(kindOf) {
    return kindOf;
}), define("jpmc/util/lang", [ "require", "./lang/isArray", "./lang/isBoolean", "./lang/isConstruct", "./lang/isConstructor", "./lang/isEmpty", "./lang/isFunction", "./lang/isHTMLElement", "./lang/isKind", "./lang/isMarkup", "./lang/isNode", "./lang/isNumber", "./lang/isObject", "./lang/isPlainObject", "./lang/isPromise", "./lang/isString", "./lang/isURL", "./lang/kindOf" ], function(require) {
    return {
        isArray: require("./lang/isArray"),
        isBoolean: require("./lang/isBoolean"),
        isConstruct: require("./lang/isConstruct"),
        isConstructor: require("./lang/isConstructor"),
        isEmpty: require("./lang/isEmpty"),
        isFunction: require("./lang/isFunction"),
        isHTMLElement: require("./lang/isHTMLElement"),
        isKind: require("./lang/isKind"),
        isMarkup: require("./lang/isMarkup"),
        isNode: require("./lang/isNode"),
        isNumber: require("./lang/isNumber"),
        isObject: require("./lang/isObject"),
        isPlainObject: require("./lang/isPlainObject"),
        isPromise: require("./lang/isPromise"),
        isString: require("./lang/isString"),
        isURL: require("./lang/isURL"),
        kindOf: require("./lang/kindOf")
    };
}), define("jpmc/event/handler", [ "can/construct/super", "can/control", "jpmc/util/object/extend", "jpmc/util/object/forOwn", "jpmc/util/lang" ], function(can, Control, extend, forOwn, lang) {
    var Handler;
    return Handler = Control({
        addClass: function(className) {
            this.className += " " + className;
        },
        setup: function() {
            if (this.pluginName = this.className, this.handles) for (var type, handles = lang.isString(this.handles) ? this.handles.split(" ") : this.handles, i = 0, j = handles.length; j > i; i++) type = handles[i], 
            Control.processors[type] || (Control.processors[type] = Control.processors.click);
            return this._super.apply(this, arguments);
        },
        bindings: function() {
            var bindings = {};
            return forOwn(this.actions, function(action, name) {
                bindings[name] = this[name];
            }, this.prototype), bindings;
        }
    }, {}), Handler.Factory = function() {
        for (var bindings, handler, stat = {
            defaults: {}
        }, prot = {}, i = 0, j = arguments.length; j > i; i++) lang.isPlainObject(arguments[i]) ? bindings = arguments[i] : (handler = arguments[i], 
        bindings = lang.isFunction(handler.bindings) && handler.bindings(), handler.defaults && !lang.isEmpty(handler.defaults) && extend(stat.defaults, handler.defaults)), 
        bindings && can.each(bindings, function(fn, type) {
            if (prot[type]) {
                var _fn = prot[type];
                prot[type] = function() {
                    _fn.apply(this, arguments), fn.apply(this, arguments);
                };
            } else prot[type] = fn;
        });
        return this(stat, prot);
    }, Handler.events = "change click contextmenu dblclick keydown keyup keypress mousedown mousemove mouseout mouseover mouseup reset resize scroll select submit focusin focusout mouseenter mouseleave touchstart touchmove touchcancel touchend touchleave play pause ended".split(" "), 
    Handler.processors.events = function(element, event, selector, callback, handler) {
        var $target = selector ? can.$(selector, element) : element, instance = new handler[callback]($target);
        return function() {
            null !== instance.element && instance.destroy.call(instance);
        };
    }, Handler;
}), define("jquery-bbq", [ "jquery", "jpmc/has/detect/browser" ], function(jQuery, Browser) {
    !function($, window) {
        "$:nomunge";
        function is_string(arg) {
            return "string" == typeof arg;
        }
        function curry(func) {
            var args = aps.call(arguments, 1);
            return function() {
                return func.apply(this, args.concat(aps.call(arguments)));
            };
        }
        function get_fragment(url) {
            return url.replace(/^[^#]*#?(.*)$/, "$1");
        }
        function get_querystring(url) {
            return url.replace(/(?:^[^?#]*\?([^#]*).*$)?.*/, "$1");
        }
        function jq_param_sub(is_fragment, get_func, url, params, merge_mode) {
            var result, qs, matches, url_params, hash;
            return params !== undefined ? (matches = url.match(is_fragment ? /^([^#]*)\#?(.*)$/ : /^([^#?]*)\??([^#]*)(#?.*)/), 
            hash = matches[3] || "", 2 === merge_mode && is_string(params) ? qs = params.replace(is_fragment ? re_trim_fragment : re_trim_querystring, "") : (url_params = jq_deparam(matches[2]), 
            params = is_string(params) ? jq_deparam[is_fragment ? str_fragment : str_querystring](params) : params, 
            qs = 2 === merge_mode ? params : 1 === merge_mode ? $.extend({}, params, url_params) : $.extend({}, url_params, params), 
            qs = jq_param(qs), is_fragment && (qs = qs.replace(re_no_escape, decode))), result = matches[1] + (is_fragment ? "#" : qs || !matches[1] ? "?" : "") + qs + hash) : result = get_func(url !== undefined ? url : window[str_location][str_href]), 
            result;
        }
        function jq_deparam_sub(is_fragment, url_or_params, coerce) {
            return url_or_params === undefined || "boolean" == typeof url_or_params ? (coerce = url_or_params, 
            url_or_params = jq_param[is_fragment ? str_fragment : str_querystring]()) : url_or_params = is_string(url_or_params) ? url_or_params.replace(is_fragment ? re_trim_fragment : re_trim_querystring, "") : url_or_params, 
            jq_deparam(url_or_params, coerce);
        }
        function jq_fn_sub(mode, force_attr, params, merge_mode) {
            return is_string(params) || "object" == typeof params || (merge_mode = params, params = force_attr, 
            force_attr = undefined), this.each(function() {
                var that = $(this), attr = force_attr || jq_elemUrlAttr()[(this.nodeName || "").toLowerCase()] || "", url = attr && that.attr(attr) || "";
                that.attr(attr, jq_param[mode](url, params, merge_mode));
            });
        }
        var undefined, jq_param_fragment, jq_deparam, jq_deparam_fragment, jq_bbq_pushState, jq_bbq_getState, jq_elemUrlAttr, re_no_escape, aps = Array.prototype.slice, decode = decodeURIComponent, jq_param = $.param, jq_bbq = $.bbq = $.bbq || {}, jq_event_special = $.event.special, str_hashchange = "hashchange", str_querystring = "querystring", str_fragment = "fragment", str_elemUrlAttr = "elemUrlAttr", str_location = "location", str_href = "href", str_src = "src", re_trim_querystring = /^.*\?|#.*$/g, re_trim_fragment = /^.*\#/, elemUrlAttr_cache = {};
        jq_param[str_querystring] = curry(jq_param_sub, 0, get_querystring), jq_param[str_fragment] = jq_param_fragment = curry(jq_param_sub, 1, get_fragment), 
        jq_param_fragment.noEscape = function(chars) {
            chars = chars || "";
            var arr = $.map(chars.split(""), encodeURIComponent);
            re_no_escape = new RegExp(arr.join("|"), "g");
        }, jq_param_fragment.noEscape(",/"), $.deparam = jq_deparam = function(params, coerce) {
            var obj = {}, coerce_types = {
                "true": !0,
                "false": !1,
                "null": null
            };
            return $.each(params.replace(/\+/g, " ").split("&"), function(j, v) {
                var val, param = v.split("="), key = decode(param[0]), cur = obj, i = 0, keys = key.split("]["), keys_last = keys.length - 1;
                if (/\[/.test(keys[0]) && /\]$/.test(keys[keys_last]) ? (keys[keys_last] = keys[keys_last].replace(/\]$/, ""), 
                keys = keys.shift().split("[").concat(keys), keys_last = keys.length - 1) : keys_last = 0, 
                2 === param.length) if (val = decode(param[1]), coerce && (val = val && !isNaN(val) ? +val : "undefined" === val ? undefined : coerce_types[val] !== undefined ? coerce_types[val] : val), 
                keys_last) for (;keys_last >= i; i++) key = "" === keys[i] ? cur.length : keys[i], 
                cur = cur[key] = keys_last > i ? cur[key] || (keys[i + 1] && isNaN(keys[i + 1]) ? {} : []) : val; else $.isArray(obj[key]) ? obj[key].push(val) : obj[key] = obj[key] !== undefined ? [ obj[key], val ] : val; else key && (obj[key] = coerce ? undefined : "");
            }), obj;
        }, jq_deparam[str_querystring] = curry(jq_deparam_sub, 0), jq_deparam[str_fragment] = jq_deparam_fragment = curry(jq_deparam_sub, 1), 
        $[str_elemUrlAttr] || ($[str_elemUrlAttr] = function(obj) {
            return $.extend(elemUrlAttr_cache, obj);
        })({
            a: str_href,
            base: str_href,
            iframe: str_src,
            img: str_src,
            input: str_src,
            form: "action",
            link: str_href,
            script: str_src
        }), jq_elemUrlAttr = $[str_elemUrlAttr], $.fn[str_querystring] = curry(jq_fn_sub, str_querystring), 
        $.fn[str_fragment] = curry(jq_fn_sub, str_fragment), jq_bbq.pushState = jq_bbq_pushState = function(params, merge_mode) {
            is_string(params) && /^#/.test(params) && merge_mode === undefined && (merge_mode = 2);
            var has_args = params !== undefined, url = jq_param_fragment(window[str_location][str_href], has_args ? params : {}, has_args ? merge_mode : 2);
            window[str_location][str_href] = url + (/#/.test(url) ? "" : "#");
        }, jq_bbq.getState = jq_bbq_getState = function(key, coerce) {
            return key === undefined || "boolean" == typeof key ? jq_deparam_fragment(key) : jq_deparam_fragment(coerce)[key];
        }, jq_bbq.removeState = function(arr) {
            var state = {};
            arr !== undefined && (state = jq_bbq_getState(), $.each($.isArray(arr) ? arr : arguments, function(i, v) {
                delete state[v];
            })), jq_bbq_pushState(state, 2);
        }, jq_event_special[str_hashchange] = $.extend(jq_event_special[str_hashchange], {
            add: function(handleObj) {
                function new_handler(e) {
                    var hash = e[str_fragment] = jq_param_fragment();
                    e.getState = function(key, coerce) {
                        return key === undefined || "boolean" == typeof key ? jq_deparam(hash, key) : jq_deparam(hash, coerce)[key];
                    }, old_handler.apply(this, arguments);
                }
                var old_handler;
                return $.isFunction(handleObj) ? (old_handler = handleObj, new_handler) : (old_handler = handleObj.handler, 
                void (handleObj.handler = new_handler));
            }
        });
    }(jQuery, this), function($, window, undefined) {
        "$:nomunge";
        function get_fragment(url) {
            return url = url || window[str_location][str_href], url.replace(/^[^#]*#?(.*)$/, "$1");
        }
        var fake_onhashchange, jq_event_special = $.event.special, str_location = "location", str_hashchange = "hashchange", str_href = "href", mode = document.documentMode, ieVer = Browser("browser-ie"), is_old_ie = (6 == ieVer || 7 == ieVer) && (mode === undefined || 8 > mode), supports_onhashchange = "on" + str_hashchange in window && !is_old_ie;
        $[str_hashchange + "Delay"] = 100, jq_event_special[str_hashchange] = $.extend(jq_event_special[str_hashchange], {
            setup: function() {
                return supports_onhashchange ? !1 : void $(fake_onhashchange.start);
            },
            teardown: function() {
                return supports_onhashchange ? !1 : void $(fake_onhashchange.stop);
            }
        }), fake_onhashchange = function() {
            function init() {
                set_history = get_history = function(val) {
                    return val;
                }, is_old_ie && (iframe = $('<iframe src="javascript:0"/>').hide().insertAfter("body")[0].contentWindow, 
                get_history = function() {
                    return get_fragment(iframe.document[str_location][str_href]);
                }, (set_history = function(hash, history_hash) {
                    if (hash !== history_hash) {
                        var doc = iframe.document;
                        doc.open().close(), doc[str_location].hash = "#" + hash;
                    }
                })(get_fragment()));
            }
            var timeout_id, iframe, set_history, get_history, self = {};
            return self.start = function() {
                if (!timeout_id) {
                    var last_hash = get_fragment();
                    set_history || init(), function loopy() {
                        var hash = get_fragment(), history_hash = get_history(last_hash);
                        hash !== last_hash ? (set_history(last_hash = hash, history_hash), $(window).trigger(str_hashchange)) : history_hash !== last_hash && (window[str_location][str_href] = window[str_location][str_href].replace(/#.*/, "") + "#" + history_hash), 
                        timeout_id = setTimeout(loopy, $[str_hashchange + "Delay"]);
                    }();
                }
            }, self.stop = function() {
                iframe || (timeout_id && clearTimeout(timeout_id), timeout_id = 0);
            }, self;
        }();
    }(jQuery, this);
}), define("jpmc/ui/control/browserHistory", [ "jpmc/$", "jpmc/topic", "jpmc/log", "jpmc/event/handler", "jquery-bbq" ], function($, Topic, Logger, Control) {
    var logger = Logger("BrowserHistory"), BrowserHistoryControl = Control({
        defaults: {},
        init: function() {
            $(function() {
                logger.debug("triggering hashchange once"), $(window).trigger("hashchange");
            });
        }
    }, {
        _handlers: {},
        _previousState: {
            states: {}
        },
        init: function() {},
        "{window} hashchange": function() {
            var context = this._getState();
            if ("undefined" == typeof context || !context || !context.states) return void this.clearState();
            var unhandledStates = this._findUnhandledStates(context);
            if (unhandledStates) {
                logger.debug("hashchange: new [" + this._stateToQueryString(context) + "], old [" + this._stateToQueryString(this._previousState) + "]");
                for (var handlerId in unhandledStates) logger.debug("Firing unhandled handler [" + handlerId + "]"), 
                Topic.publish("history." + handlerId, [ unhandledStates[handlerId] ]);
                this._savePreviousState(context);
            } else logger.debug("Ignoring hashchange with unchanged state [" + this._stateToQueryString(context) + "]");
        },
        _savePreviousState: function(state) {
            this._previousState = state;
        },
        _findUnhandledStates: function(state) {
            var unhandled = {};
            if (state && state.states && this._previousState.states) for (var handlerId in state.states) {
                var previousStateForHandler = this._previousState.states[handlerId];
                "undefined" != typeof previousStateForHandler && this._objectsIdentical(previousStateForHandler, state.states[handlerId]) || "object" == typeof state.states[handlerId] && (unhandled[handlerId] = state.states[handlerId]);
            }
            return $.isEmptyObject(unhandled) ? null : unhandled;
        },
        _objectsIdentical: function(obj1, obj2) {
            var p;
            for (p in obj1) {
                if ("undefined" == typeof obj2[p]) return !1;
                if (obj1[p]) switch (typeof obj1[p]) {
                  case "object":
                    if (!this._objectsIdentical(obj1[p], obj2[p])) return !1;
                    break;

                  case "function":
                    if ("undefined" == typeof obj2[p] || "equals" !== p && obj1[p].toString() !== obj2[p].toString()) return !1;
                    break;

                  default:
                    if (obj1[p] !== obj2[p]) return !1;
                } else if (obj2[p]) return !1;
            }
            for (p in obj2) if ("undefined" == typeof obj1[p]) return !1;
            return !0;
        },
        _getState: function() {
            return $.bbq.getState();
        },
        _stateToQueryString: function(state) {
            return $.param(state);
        },
        _queryStringToState: function(query) {
            return $.deparam(query);
        },
        registerHandler: function(handlerId, handler) {
            Topic.subscribe("history." + handlerId, handler);
        },
        pushState: function(handlerId, state) {
            var context = state;
            state.states || (context = {
                states: {}
            }, context.states[handlerId] = state), this._savePreviousState(context), $.bbq.pushState(context), 
            logger.debug("state pushed " + this._stateToQueryString(context));
        },
        appendState: function(handlerId, handlerState) {
            logger.debug("delaying append state"), setTimeout(function(control) {
                return function() {
                    var context = control._getState();
                    "undefined" != typeof context && context && context.states ? (control._savePreviousState(context), 
                    context.states[handlerId] = handlerState) : context = handlerState, control.pushState(handlerId, context), 
                    logger.debug("state appended: " + control._stateToQueryString(context));
                };
            }(this), 400);
        },
        clearState: function() {
            var context = this._getState();
            context && context.states && (window.location.hash = "#/", this._savePreviousState({
                states: {}
            })), Topic.publish("history.clearState", [ {} ]);
        }
    }), browserHistory = new BrowserHistoryControl(window);
    return logger.debug("created browser history control"), browserHistory;
}), define("handlebars", [], function() {
    var Handlebars = {};
    return function(Handlebars, undefined) {
        Handlebars.VERSION = "1.0.0", Handlebars.COMPILER_REVISION = 4, Handlebars.REVISION_CHANGES = {
            1: "<= 1.0.rc.2",
            2: "== 1.0.0-rc.3",
            3: "== 1.0.0-rc.4",
            4: ">= 1.0.0"
        }, Handlebars.helpers = {}, Handlebars.partials = {};
        var toString = Object.prototype.toString, functionType = "[object Function]", objectType = "[object Object]";
        Handlebars.registerHelper = function(name, fn, inverse) {
            if (toString.call(name) === objectType) {
                if (inverse || fn) throw new Handlebars.Exception("Arg not supported with multiple helpers");
                Handlebars.Utils.extend(this.helpers, name);
            } else inverse && (fn.not = inverse), this.helpers[name] = fn;
        }, Handlebars.registerPartial = function(name, str) {
            toString.call(name) === objectType ? Handlebars.Utils.extend(this.partials, name) : this.partials[name] = str;
        }, Handlebars.registerHelper("helperMissing", function(arg) {
            if (2 === arguments.length) return undefined;
            throw new Error("Missing helper: '" + arg + "'");
        }), Handlebars.registerHelper("blockHelperMissing", function(context, options) {
            var inverse = options.inverse || function() {}, fn = options.fn, type = toString.call(context);
            return type === functionType && (context = context.call(this)), context === !0 ? fn(this) : context === !1 || null == context ? inverse(this) : "[object Array]" === type ? context.length > 0 ? Handlebars.helpers.each(context, options) : inverse(this) : fn(context);
        }), Handlebars.K = function() {}, Handlebars.createFrame = Object.create || function(object) {
            Handlebars.K.prototype = object;
            var obj = new Handlebars.K();
            return Handlebars.K.prototype = null, obj;
        }, Handlebars.logger = {
            DEBUG: 0,
            INFO: 1,
            WARN: 2,
            ERROR: 3,
            level: 3,
            methodMap: {
                0: "debug",
                1: "info",
                2: "warn",
                3: "error"
            },
            log: function(level, obj) {
                if (Handlebars.logger.level <= level) {
                    var method = Handlebars.logger.methodMap[level];
                    "undefined" != typeof console && console[method] && console[method].call(console, obj);
                }
            }
        }, Handlebars.log = function(level, obj) {
            Handlebars.logger.log(level, obj);
        }, Handlebars.registerHelper("each", function(context, options) {
            var data, fn = options.fn, inverse = options.inverse, i = 0, ret = "", type = toString.call(context);
            if (type === functionType && (context = context.call(this)), options.data && (data = Handlebars.createFrame(options.data)), 
            context && "object" == typeof context) if (context instanceof Array) for (var j = context.length; j > i; i++) data && (data.index = i), 
            ret += fn(context[i], {
                data: data
            }); else for (var key in context) context.hasOwnProperty(key) && (data && (data.key = key), 
            ret += fn(context[key], {
                data: data
            }), i++);
            return 0 === i && (ret = inverse(this)), ret;
        }), Handlebars.registerHelper("if", function(conditional, options) {
            var type = toString.call(conditional);
            return type === functionType && (conditional = conditional.call(this)), !conditional || Handlebars.Utils.isEmpty(conditional) ? options.inverse(this) : options.fn(this);
        }), Handlebars.registerHelper("unless", function(conditional, options) {
            return Handlebars.helpers["if"].call(this, conditional, {
                fn: options.inverse,
                inverse: options.fn
            });
        }), Handlebars.registerHelper("with", function(context, options) {
            var type = toString.call(context);
            return type === functionType && (context = context.call(this)), Handlebars.Utils.isEmpty(context) ? void 0 : options.fn(context);
        }), Handlebars.registerHelper("log", function(context, options) {
            var level = options.data && null != options.data.level ? parseInt(options.data.level, 10) : 1;
            Handlebars.log(level, context);
        });
        var errorProps = [ "description", "fileName", "lineNumber", "message", "name", "number", "stack" ];
        Handlebars.Exception = function() {
            for (var tmp = Error.prototype.constructor.apply(this, arguments), idx = 0; idx < errorProps.length; idx++) this[errorProps[idx]] = tmp[errorProps[idx]];
        }, Handlebars.Exception.prototype = new Error(), Handlebars.SafeString = function(string) {
            this.string = string;
        }, Handlebars.SafeString.prototype.toString = function() {
            return this.string.toString();
        };
        var escape = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#x27;",
            "`": "&#x60;"
        }, badChars = /[&<>"'`]/g, possible = /[&<>"'`]/, escapeChar = function(chr) {
            return escape[chr] || "&amp;";
        };
        Handlebars.Utils = {
            extend: function(obj, value) {
                for (var key in value) value.hasOwnProperty(key) && (obj[key] = value[key]);
            },
            escapeExpression: function(string) {
                return string instanceof Handlebars.SafeString ? string.toString() : null == string || string === !1 ? "" : (string = string.toString(), 
                possible.test(string) ? string.replace(badChars, escapeChar) : string);
            },
            isEmpty: function(value) {
                return value || 0 === value ? "[object Array]" === toString.call(value) && 0 === value.length ? !0 : !1 : !0;
            }
        }, Handlebars.VM = {
            template: function(templateSpec) {
                var container = {
                    escapeExpression: Handlebars.Utils.escapeExpression,
                    invokePartial: Handlebars.VM.invokePartial,
                    programs: [],
                    program: function(i, fn, data) {
                        var programWrapper = this.programs[i];
                        return data ? programWrapper = Handlebars.VM.program(i, fn, data) : programWrapper || (programWrapper = this.programs[i] = Handlebars.VM.program(i, fn)), 
                        programWrapper;
                    },
                    merge: function(param, common) {
                        var ret = param || common;
                        return param && common && (ret = {}, Handlebars.Utils.extend(ret, common), Handlebars.Utils.extend(ret, param)), 
                        ret;
                    },
                    programWithDepth: Handlebars.VM.programWithDepth,
                    noop: Handlebars.VM.noop,
                    compilerInfo: null
                };
                return function(context, options) {
                    options = options || {};
                    var result = templateSpec.call(container, Handlebars, context, options.helpers, options.partials, options.data), compilerInfo = container.compilerInfo || [], compilerRevision = compilerInfo[0] || 1, currentRevision = Handlebars.COMPILER_REVISION;
                    if (compilerRevision !== currentRevision) {
                        if (currentRevision > compilerRevision) {
                            var runtimeVersions = Handlebars.REVISION_CHANGES[currentRevision], compilerVersions = Handlebars.REVISION_CHANGES[compilerRevision];
                            throw "Template was precompiled with an older version of Handlebars than the current runtime. Please update your precompiler to a newer version (" + runtimeVersions + ") or downgrade your runtime to an older version (" + compilerVersions + ").";
                        }
                        throw "Template was precompiled with a newer version of Handlebars than the current runtime. Please update your runtime to a newer version (" + compilerInfo[1] + ").";
                    }
                    return result;
                };
            },
            programWithDepth: function(i, fn, data) {
                var args = Array.prototype.slice.call(arguments, 3), program = function(context, options) {
                    return options = options || {}, fn.apply(this, [ context, options.data || data ].concat(args));
                };
                return program.program = i, program.depth = args.length, program;
            },
            program: function(i, fn, data) {
                var program = function(context, options) {
                    return options = options || {}, fn(context, options.data || data);
                };
                return program.program = i, program.depth = 0, program;
            },
            noop: function() {
                return "";
            },
            invokePartial: function(partial, name, context, helpers, partials, data) {
                var options = {
                    helpers: helpers,
                    partials: partials,
                    data: data
                };
                if (partial === undefined) throw new Handlebars.Exception("The partial " + name + " could not be found");
                if (partial instanceof Function) return partial(context, options);
                if (Handlebars.compile) return partials[name] = Handlebars.compile(partial, {
                    data: data !== undefined
                }), partials[name](context, options);
                throw new Handlebars.Exception("The partial " + name + " could not be compiled when running in runtime-only mode");
            }
        }, Handlebars.template = Handlebars.VM.template;
    }(Handlebars), Handlebars;
}), define("jpmc/template/modal", [ "handlebars" ], function(Handlebars) {
    return Handlebars.template(function(Handlebars, depth0, helpers, partials, data) {
        return this.compilerInfo = [ 4, ">= 1.0.0" ], helpers = this.merge(helpers, Handlebars.helpers), 
        data = data || {}, '<div class="chaseui-jpmc-modal">\r\n  <span class="chaseutil-hidevisual">Begin overlay</span>\r\n  <div class="chaseui-modalheader">\r\n    <h1></h1>\r\n    <a class="chasejs-modalclose chaseui-modalclose" href="#">\r\n      <span aria-hidden="true">&#215</span>\r\n      <span class="chaseutil-hidevisual accessible-text">&nbsp; Close overlay</span>\r\n    </a>\r\n  </div>\r\n  <div class="chaseui-modalbody"></div>\r\n  <span class="chaseutil-hidevisual">End overlay</span>\r\n</div>';
    });
}), define("jqueryui/core", [ "jquery" ], function(jQuery) {
    return function($, undefined) {
        function focusable(element, isTabIndexNotNaN) {
            var map, mapName, img, nodeName = element.nodeName.toLowerCase();
            return "area" === nodeName ? (map = element.parentNode, mapName = map.name, element.href && mapName && "map" === map.nodeName.toLowerCase() ? (img = $("img[usemap=#" + mapName + "]")[0], 
            !!img && visible(img)) : !1) : (/input|select|textarea|button|object/.test(nodeName) ? !element.disabled : "a" === nodeName ? element.href || isTabIndexNotNaN : isTabIndexNotNaN) && visible(element);
        }
        function visible(element) {
            return $.expr.filters.visible(element) && !$(element).parents().addBack().filter(function() {
                return "hidden" === $.css(this, "visibility");
            }).length;
        }
        var uuid = 0, runiqueId = /^ui-id-\d+$/;
        $.ui = $.ui || {}, $.extend($.ui, {
            version: "1.10.2",
            keyCode: {
                BACKSPACE: 8,
                COMMA: 188,
                DELETE: 46,
                DOWN: 40,
                END: 35,
                ENTER: 13,
                ESCAPE: 27,
                HOME: 36,
                LEFT: 37,
                NUMPAD_ADD: 107,
                NUMPAD_DECIMAL: 110,
                NUMPAD_DIVIDE: 111,
                NUMPAD_ENTER: 108,
                NUMPAD_MULTIPLY: 106,
                NUMPAD_SUBTRACT: 109,
                PAGE_DOWN: 34,
                PAGE_UP: 33,
                PERIOD: 190,
                RIGHT: 39,
                SPACE: 32,
                TAB: 9,
                UP: 38
            }
        }), $.fn.extend({
            focus: function(orig) {
                return function(delay, fn) {
                    return "number" == typeof delay ? this.each(function() {
                        var elem = this;
                        setTimeout(function() {
                            $(elem).focus(), fn && fn.call(elem);
                        }, delay);
                    }) : orig.apply(this, arguments);
                };
            }($.fn.focus),
            scrollParent: function() {
                var scrollParent;
                return scrollParent = $.ui.ie && /(static|relative)/.test(this.css("position")) || /absolute/.test(this.css("position")) ? this.parents().filter(function() {
                    return /(relative|absolute|fixed)/.test($.css(this, "position")) && /(auto|scroll)/.test($.css(this, "overflow") + $.css(this, "overflow-y") + $.css(this, "overflow-x"));
                }).eq(0) : this.parents().filter(function() {
                    return /(auto|scroll)/.test($.css(this, "overflow") + $.css(this, "overflow-y") + $.css(this, "overflow-x"));
                }).eq(0), /fixed/.test(this.css("position")) || !scrollParent.length ? $(document) : scrollParent;
            },
            zIndex: function(zIndex) {
                if (zIndex !== undefined) return this.css("zIndex", zIndex);
                if (this.length) for (var position, value, elem = $(this[0]); elem.length && elem[0] !== document; ) {
                    if (position = elem.css("position"), ("absolute" === position || "relative" === position || "fixed" === position) && (value = parseInt(elem.css("zIndex"), 10), 
                    !isNaN(value) && 0 !== value)) return value;
                    elem = elem.parent();
                }
                return 0;
            },
            uniqueId: function() {
                return this.each(function() {
                    this.id || (this.id = "ui-id-" + ++uuid);
                });
            },
            removeUniqueId: function() {
                return this.each(function() {
                    runiqueId.test(this.id) && $(this).removeAttr("id");
                });
            }
        }), $.extend($.expr[":"], {
            data: $.expr.createPseudo ? $.expr.createPseudo(function(dataName) {
                return function(elem) {
                    return !!$.data(elem, dataName);
                };
            }) : function(elem, i, match) {
                return !!$.data(elem, match[3]);
            },
            focusable: function(element) {
                return focusable(element, !isNaN($.attr(element, "tabindex")));
            },
            tabbable: function(element) {
                var tabIndex = $.attr(element, "tabindex"), isTabIndexNaN = isNaN(tabIndex);
                return (isTabIndexNaN || tabIndex >= 0) && focusable(element, !isTabIndexNaN);
            }
        }), $("<a>").outerWidth(1).jquery || $.each([ "Width", "Height" ], function(i, name) {
            function reduce(elem, size, border, margin) {
                return $.each(side, function() {
                    size -= parseFloat($.css(elem, "padding" + this)) || 0, border && (size -= parseFloat($.css(elem, "border" + this + "Width")) || 0), 
                    margin && (size -= parseFloat($.css(elem, "margin" + this)) || 0);
                }), size;
            }
            var side = "Width" === name ? [ "Left", "Right" ] : [ "Top", "Bottom" ], type = name.toLowerCase(), orig = {
                innerWidth: $.fn.innerWidth,
                innerHeight: $.fn.innerHeight,
                outerWidth: $.fn.outerWidth,
                outerHeight: $.fn.outerHeight
            };
            $.fn["inner" + name] = function(size) {
                return size === undefined ? orig["inner" + name].call(this) : this.each(function() {
                    $(this).css(type, reduce(this, size) + "px");
                });
            }, $.fn["outer" + name] = function(size, margin) {
                return "number" != typeof size ? orig["outer" + name].call(this, size) : this.each(function() {
                    $(this).css(type, reduce(this, size, !0, margin) + "px");
                });
            };
        }), $.fn.addBack || ($.fn.addBack = function(selector) {
            return this.add(null == selector ? this.prevObject : this.prevObject.filter(selector));
        }), $("<a>").data("a-b", "a").removeData("a-b").data("a-b") && ($.fn.removeData = function(removeData) {
            return function(key) {
                return arguments.length ? removeData.call(this, $.camelCase(key)) : removeData.call(this);
            };
        }($.fn.removeData)), $.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()), 
        $.support.selectstart = "onselectstart" in document.createElement("div"), $.fn.extend({
            disableSelection: function() {
                return this.bind(($.support.selectstart ? "selectstart" : "mousedown") + ".ui-disableSelection", function(event) {
                    event.preventDefault();
                });
            },
            enableSelection: function() {
                return this.unbind(".ui-disableSelection");
            }
        }), $.extend($.ui, {
            plugin: {
                add: function(module, option, set) {
                    var i, proto = $.ui[module].prototype;
                    for (i in set) proto.plugins[i] = proto.plugins[i] || [], proto.plugins[i].push([ option, set[i] ]);
                },
                call: function(instance, name, args) {
                    var i, set = instance.plugins[name];
                    if (set && instance.element[0].parentNode && 11 !== instance.element[0].parentNode.nodeType) for (i = 0; i < set.length; i++) instance.options[set[i][0]] && set[i][1].apply(instance.element, args);
                }
            },
            hasScroll: function(el, a) {
                if ("hidden" === $(el).css("overflow")) return !1;
                var scroll = a && "left" === a ? "scrollLeft" : "scrollTop", has = !1;
                return el[scroll] > 0 ? !0 : (el[scroll] = 1, has = el[scroll] > 0, el[scroll] = 0, 
                has);
            }
        });
    }(jQuery), jQuery.ui;
}), define("jpmc/event/handler/tabArea", [ "jpmc/event/handler", "jqueryui/core" ], function(Handler) {
    var TabArea, TAB_KEY_CODE = 9;
    return TabArea = Handler({
        keydown: function($element, event) {
            if (event.keyCode === TAB_KEY_CODE) {
                event.preventDefault();
                var $tabbables = $element.find(":focusable").filter(function() {
                    return event.target === this || this.tabIndex >= 0;
                });
                event.shiftKey ? $tabbables[($tabbables.index(event.target) + $tabbables.length - 1) % $tabbables.length].focus() : $tabbables[($tabbables.index(event.target) + 1) % $tabbables.length].focus();
            }
        }
    });
}), define("mout/function/partial", [], function() {
    function slice(arr, offset) {
        return Array.prototype.slice.call(arr, offset || 0);
    }
    function partial(fn) {
        var argsArr = slice(arguments, 1);
        return function() {
            return fn.apply(this, argsArr.concat(slice(arguments)));
        };
    }
    return partial;
}), define("jpmc/util/function/partial", [ "mout/function/partial" ], function(partial) {
    return partial;
}), define("mout/string/camelCase", [ "../lang/toString", "./replaceAccents", "./removeNonWord", "./upperCase", "./lowerCase" ], function(toString, replaceAccents, removeNonWord, upperCase, lowerCase) {
    function camelCase(str) {
        return str = toString(str), str = replaceAccents(str), str = removeNonWord(str).replace(/[\-_]/g, " ").replace(/\s[a-z]/g, upperCase).replace(/\s+/g, "").replace(/^[A-Z]/g, lowerCase);
    }
    return camelCase;
}), define("mout/string/pascalCase", [ "../lang/toString", "./camelCase", "./upperCase" ], function(toString, camelCase, upperCase) {
    function pascalCase(str) {
        return str = toString(str), camelCase(str).replace(/^[a-z]/, upperCase);
    }
    return pascalCase;
}), define("jpmc/util/string/pascalCase", [ "mout/string/pascalCase" ], function(pascalCase) {
    return pascalCase;
}), define("jpmc/mixin/publisher", [ "jpmc/topic", "jpmc/util/function/partial", "jpmc/util/lang/isPlainObject", "jpmc/util/object/forOwn", "jpmc/util/string/pascalCase" ], function(Topic, partial, isPlainObject, forOwn, pascalCase) {
    var PublisherMixin, createPublisher = function(instance, topicNames) {
        forOwn(topicNames, function(topic, name) {
            instance["publish" + pascalCase(name)] = partial(Topic.publish, name);
        });
    };
    return PublisherMixin = function() {
        var topicList = this.publisher;
        if (!isPlainObject(topicList)) throw "Invalid value " + topicList + " for publisher";
        createPublisher(this, topicList), this.createPublisher = function() {
            createPublisher(this, arguments);
        };
    };
}), function(define) {
    define("meld/meld", [], function() {
        function meld(target, pointcut, aspect) {
            var pointcutType, remove;
            return arguments.length < 3 ? addAspectToFunction(target, pointcut) : (isArray(pointcut) ? remove = addAspectToAll(target, pointcut, aspect) : (pointcutType = typeof pointcut, 
            "string" === pointcutType ? "function" == typeof target[pointcut] && (remove = addAspectToMethod(target, pointcut, aspect)) : remove = "function" === pointcutType ? addAspectToAll(target, pointcut(target), aspect) : addAspectToMatches(target, pointcut, aspect)), 
            remove);
        }
        function Advisor(target, func) {
            var orig, advisor, advised;
            this.target = target, this.func = func, this.aspects = {}, orig = this.orig = target[func], 
            advisor = this, advised = this.advised = function() {
                function callOrigAndOn(args) {
                    var result = callOrig(args);
                    return advisor._callSimpleAdvice("on", context, args), result;
                }
                function callAfter(afterType, args) {
                    advisor._callSimpleAdvice(afterType, context, args);
                }
                var context, joinpoint, args, callOrig, afterType;
                this instanceof advised ? (context = objectCreate(orig.prototype), callOrig = function(args) {
                    return applyConstructor(orig, context, args);
                }) : (context = this, callOrig = function(args) {
                    return orig.apply(context, args);
                }), args = slice.call(arguments), afterType = "afterReturning", joinpoint = pushJoinpoint({
                    target: context,
                    method: func,
                    args: args
                });
                try {
                    advisor._callSimpleAdvice("before", context, args);
                    try {
                        joinpoint.result = advisor._callAroundAdvice(context, func, args, callOrigAndOn);
                    } catch (e) {
                        joinpoint.result = joinpoint.exception = e, afterType = "afterThrowing";
                    }
                    if (args = [ joinpoint.result ], callAfter(afterType, args), callAfter("after", args), 
                    joinpoint.exception) throw joinpoint.exception;
                    return joinpoint.result;
                } finally {
                    popJoinpoint();
                }
            }, defineProperty(advised, "_advisor", {
                value: advisor,
                configurable: !0
            });
        }
        function addAspectToFunction(func, aspect) {
            var name, placeholderTarget;
            return name = func.name || "_", placeholderTarget = {}, placeholderTarget[name] = func, 
            addAspectToMethod(placeholderTarget, name, aspect), placeholderTarget[name];
        }
        function addAspectToMethod(target, method, aspect) {
            var advisor = Advisor.get(target, method);
            return advisor && advisor.add(aspect);
        }
        function addAspectToAll(target, methodArray, aspect) {
            var removers, added, f, i;
            for (removers = [], i = 0; f = methodArray[i++]; ) added = addAspectToMethod(target, f, aspect), 
            added && removers.push(added);
            return createRemover(removers);
        }
        function addAspectToMatches(target, pointcut, aspect) {
            var removers = [];
            for (var p in target) "function" == typeof target[p] && pointcut.test(p) && removers.push(addAspectToMethod(target, p, aspect));
            return createRemover(removers);
        }
        function createRemover(removers) {
            return {
                remove: function() {
                    for (var i = removers.length - 1; i >= 0; --i) removers[i].remove();
                }
            };
        }
        function adviceApi(type) {
            return function(target, method, adviceFunc) {
                var aspect = {};
                return 2 === arguments.length ? (aspect[type] = method, meld(target, aspect)) : (aspect[type] = adviceFunc, 
                meld(target, method, aspect));
            };
        }
        function insertAspect(aspectList, aspect) {
            var adviceType, advice, advices;
            for (adviceType in iterators) advice = aspect[adviceType], advice && (advices = aspectList[adviceType], 
            advices || (aspectList[adviceType] = advices = []), advices.push({
                aspect: aspect,
                advice: advice
            }));
        }
        function removeAspect(aspectList, aspect) {
            var adviceType, advices, remaining;
            remaining = 0;
            for (adviceType in iterators) if (advices = aspectList[adviceType]) {
                remaining += advices.length;
                for (var i = advices.length - 1; i >= 0; --i) if (advices[i].aspect === aspect) {
                    advices.splice(i, 1), --remaining;
                    break;
                }
            }
            return remaining;
        }
        function applyConstructor(C, instance, args) {
            try {
                defineProperty(instance, "constructor", {
                    value: C,
                    enumerable: !1
                });
            } catch (e) {}
            return C.apply(instance, args), instance;
        }
        function forEach(array, func) {
            for (var i = 0, len = array.length; len > i; i++) func(array[i]);
        }
        function forEachReverse(array, func) {
            for (var i = array.length - 1; i >= 0; --i) func(array[i]);
        }
        function joinpoint() {
            return currentJoinpoint;
        }
        function pushJoinpoint(newJoinpoint) {
            return joinpointStack.push(currentJoinpoint), currentJoinpoint = newJoinpoint;
        }
        function popJoinpoint() {
            return currentJoinpoint = joinpointStack.pop();
        }
        function definePropertyWorks() {
            try {
                return "x" in Object.defineProperty({}, "x", {});
            } catch (e) {}
        }
        meld.before = adviceApi("before"), meld.around = adviceApi("around"), meld.on = adviceApi("on"), 
        meld.afterReturning = adviceApi("afterReturning"), meld.afterThrowing = adviceApi("afterThrowing"), 
        meld.after = adviceApi("after"), meld.joinpoint = joinpoint, meld.add = function() {
            return meld.apply(null, arguments);
        }, Advisor.prototype = {
            _callSimpleAdvice: function(adviceType, context, args) {
                var iterator, advices;
                advices = this.aspects[adviceType], advices && (iterator = iterators[adviceType])(this.aspects[adviceType], function(aspect) {
                    var advice = aspect.advice;
                    advice && advice.apply(context, args);
                });
            },
            _callAroundAdvice: function(context, method, args, applyOriginal) {
                function callNext(i, args) {
                    return 0 > i ? applyOriginal(args) : callAround(aspects[i].advice, i, args);
                }
                function callAround(around, i, args) {
                    function proceedCount() {
                        return proceedCalled;
                    }
                    function proceedCall() {
                        return proceed(arguments.length > 0 ? slice.call(arguments) : args);
                    }
                    function proceedApply(newArgs) {
                        return proceed(newArgs || args);
                    }
                    function proceed(args) {
                        return proceedCalled++, callNext(i - 1, args);
                    }
                    var proceedCalled, joinpoint;
                    proceedCalled = 0, joinpoint = pushJoinpoint({
                        target: context,
                        method: method,
                        args: args,
                        proceed: proceedCall,
                        proceedApply: proceedApply,
                        proceedCount: proceedCount
                    });
                    try {
                        return around.call(context, joinpoint);
                    } finally {
                        popJoinpoint();
                    }
                }
                var len, aspects;
                return aspects = this.aspects.around, len = aspects ? aspects.length : 0, callNext(len - 1, args);
            },
            add: function(aspect) {
                var advisor, aspects;
                return advisor = this, aspects = advisor.aspects, insertAspect(aspects, aspect), 
                {
                    remove: function() {
                        var remaining = removeAspect(aspects, aspect);
                        remaining || advisor.remove();
                    }
                };
            },
            remove: function() {
                delete this.advised._advisor, this.target[this.func] = this.orig;
            }
        }, Advisor.get = function(target, methodName) {
            if (methodName in target) {
                var advisor, advised;
                if (advised = target[methodName], "function" != typeof advised) throw new Error("Advice can only be applied to functions: " + methodName);
                return advisor = advised._advisor, advisor || (advisor = new Advisor(target, methodName), 
                target[methodName] = advisor.advised), advisor;
            }
        };
        var currentJoinpoint, joinpointStack, ap, prepend, append, iterators, slice, isArray, defineProperty, objectCreate;
        return joinpointStack = [], ap = Array.prototype, prepend = ap.unshift, append = ap.push, 
        slice = ap.slice, isArray = Array.isArray || function(it) {
            return "[object Array]" == Object.prototype.toString.call(it);
        }, defineProperty = definePropertyWorks() ? Object.defineProperty : function(obj, prop, descriptor) {
            obj[prop] = descriptor.value;
        }, objectCreate = Object.create || function() {
            function F() {}
            return function(proto) {
                F.prototype = proto;
                var instance = new F();
                return F.prototype = null, instance;
            };
        }(), iterators = {
            before: forEachReverse,
            around: !1
        }, iterators.on = iterators.afterReturning = iterators.afterThrowing = iterators.after = forEach, 
        meld;
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory();
}), define("meld", [ "meld/meld" ], function(main) {
    return main;
}), define("jpmc/meld", [ "meld" ], function(meld) {
    return meld;
}), define("can/observe/compute", [ "can/util/library", "can/util/bind" ], function(can) {
    var getValueAndObserved = function(func, self) {
        var oldReading;
        can.Observe && (oldReading = can.Observe.__reading, can.Observe.__reading = function(obj, attr) {
            observed.push({
                obj: obj,
                attr: attr + ""
            });
        });
        var observed = [], value = func.call(self);
        return can.Observe && (can.Observe.__reading = oldReading), {
            value: value,
            observed: observed
        };
    }, computeBinder = function(getterSetter, context, callback, computeState) {
        var batchNum, observing = {}, matched = !0, data = {
            value: void 0,
            teardown: function() {
                for (var name in observing) {
                    var ob = observing[name];
                    ob.observe.obj.unbind(ob.observe.attr, onchanged), delete observing[name];
                }
            }
        }, onchanged = function(ev) {
            if (!(computeState && !computeState.bound || void 0 !== ev.batchNum && ev.batchNum === batchNum)) {
                var oldValue = data.value, newvalue = getValueAndBind();
                data.value = newvalue, newvalue !== oldValue && callback(newvalue, oldValue), batchNum = batchNum = ev.batchNum;
            }
        }, getValueAndBind = function() {
            var info = getValueAndObserved(getterSetter, context), newObserveSet = info.observed, value = info.value;
            matched = !matched, can.each(newObserveSet, function(ob) {
                observing[ob.obj._cid + "|" + ob.attr] ? observing[ob.obj._cid + "|" + ob.attr].matched = matched : (observing[ob.obj._cid + "|" + ob.attr] = {
                    matched: matched,
                    observe: ob
                }, ob.obj.bind(ob.attr, onchanged));
            });
            for (var name in observing) {
                var ob = observing[name];
                ob.matched !== matched && (ob.observe.obj.unbind(ob.observe.attr, onchanged), delete observing[name]);
            }
            return value;
        };
        return data.value = getValueAndBind(), data.isListening = !can.isEmptyObject(observing), 
        data;
    };
    return can.compute = function(getterSetter, context, eventName) {
        if (getterSetter && getterSetter.isComputed) return getterSetter;
        var computedData, computed, value, computeState = {
            bound: !1,
            hasDependencies: !1
        }, on = function() {}, off = function() {}, get = function() {
            return value;
        }, set = function(newVal) {
            value = newVal;
        }, canReadForChangeEvent = !0;
        if (computed = function(newVal) {
            if (arguments.length) {
                var old = value, setVal = set.call(context, newVal, old);
                return computed.hasDependencies ? get.call(context) : (value = void 0 === setVal ? get.call(context) : setVal, 
                old !== value && can.Observe.triggerBatch(computed, "change", [ value, old ]), value);
            }
            return can.Observe.__reading && canReadForChangeEvent && can.Observe.__reading(computed, "change"), 
            computeState.bound ? value : get.call(context);
        }, "function" == typeof getterSetter) set = getterSetter, get = getterSetter, canReadForChangeEvent = eventName === !1 ? !1 : !0, 
        computed.hasDependencies = !1, on = function(update) {
            computedData = computeBinder(getterSetter, context || this, update, computeState), 
            computed.hasDependencies = computedData.isListening, value = computedData.value;
        }, off = function() {
            computedData.teardown();
        }; else if (context) if ("string" == typeof context) {
            var propertyName = context, isObserve = getterSetter instanceof can.Observe;
            isObserve && (computed.hasDependencies = !0), get = function() {
                return isObserve ? getterSetter.attr(propertyName) : getterSetter[propertyName];
            }, set = function(newValue) {
                isObserve ? getterSetter.attr(propertyName, newValue) : getterSetter[propertyName] = newValue;
            };
            var handler;
            on = function(update) {
                handler = function() {
                    update(get(), value);
                }, can.bind.call(getterSetter, eventName || propertyName, handler), value = getValueAndObserved(get).value;
            }, off = function() {
                can.unbind.call(getterSetter, eventName || propertyName, handler);
            };
        } else if ("function" == typeof context) value = getterSetter, set = context; else {
            value = getterSetter;
            var options = context;
            get = options.get || get, set = options.set || set, on = options.on || on, off = options.off || off;
        } else value = getterSetter;
        computed.isComputed = !0, can.cid(computed, "compute");
        var updater = function(newValue, oldValue) {
            value = newValue, can.Observe.triggerBatch(computed, "change", [ newValue, oldValue ]);
        };
        return can.extend(computed, {
            _bindsetup: function() {
                computeState.bound = !0, on.call(this, updater);
            },
            _bindteardown: function() {
                off.call(this, updater), computeState.bound = !1;
            },
            bind: can.bindAndSetup,
            unbind: can.unbindAndTeardown
        });
    }, can.compute.binder = computeBinder, can.compute;
}), define("jpmc/observe/compute", [ "jpmc/observe", "can/observe/compute" ], function(Observe, compute) {
    return compute;
}), define("jpmc/mixin/state", [ "jpmc/meld", "jpmc/observe/compute", "jpmc/util/lang/isPlainObject", "jpmc/util/string/pascalCase", "jpmc/util/object/forOwn" ], function(meld, compute, isPlainObject, pascalCase, forOwn) {
    var StateMixin;
    return StateMixin = function() {
        var suffix, that = this, states = this.states, initRegex = /setup|init/;
        isPlainObject(states) && (this.stateful = !0, this.state = compute(null), this.state.is = function(name) {
            return that.state() === name;
        }, this.state.to = function(name) {
            that.state(name);
        }, forOwn(states, function(pattern, stateName) {
            suffix = pascalCase(stateName), this.state["is" + suffix] = function() {
                return that.state.is(stateName);
            }, this.state["to" + suffix] = function() {
                return that.state.to(stateName);
            }, meld.on(this, pattern, function() {
                this.state.to(stateName);
            }), initRegex.test(pattern) && this.state.to(stateName);
        }, this));
    };
}), define("jpmc/template/floater", [ "handlebars" ], function(Handlebars) {
    return Handlebars.template(function(Handlebars, depth0, helpers, partials, data) {
        return this.compilerInfo = [ 4, ">= 1.0.0" ], helpers = this.merge(helpers, Handlebars.helpers), 
        data = data || {}, '<div class="chaseui-floater"></div>';
    });
}), define("jpmc/error/unsupported", [], function() {
    var name = "UnsupportedError", message = "Unsupported command";
    return UnsupportedError = function(msg) {
        var err = new Error();
        this.name = name, this.message = message + (msg ? ": " + msg : ""), err.stack && (this.stack = err.stack);
    }, err = new Error(), UnsupportedError.prototype = err, UnsupportedError.constructor = UnsupportedError, 
    UnsupportedError;
}), define("jpmc/error/insertion", [], function() {
    var name = "InsertionError", message = "Failed to insert value";
    return InsertionError = function(msg, rootError) {
        var err = rootError || new Error();
        this.name = name, this.message = message + (msg ? ": " + msg : ""), err.stack && (this.stack = err.stack);
    }, err = new Error(), InsertionError.prototype = err, InsertionError.constructor = InsertionError, 
    InsertionError;
}), define("conf/ui/insertion", {
    after: {
        location: "outside"
    },
    append: {
        location: "inside"
    },
    appendTo: {
        location: "inside"
    },
    before: {
        location: "outside"
    },
    html: {
        location: "inside"
    },
    insertAfter: {
        location: "outside"
    },
    insertBefore: {
        location: "outside"
    },
    prepend: {
        location: "inside"
    },
    prependTo: {
        location: "inside"
    },
    text: {
        location: "inside"
    },
    wrap: {
        location: "around"
    },
    wrapAll: {
        location: "around"
    },
    wrapInner: {
        location: "around"
    }
}), define("jpmc/ui/insertion", [ "jpmc/$", "jpmc/util/lang", "jpmc/util/function/bind", "jpmc/error/unsupported", "jpmc/error/insertion", "conf/ui/insertion" ], function($, lang, bind, UnsupportedError, InsertionError, insertions) {
    var Insertion;
    return Insertion = {
        execute: function(method, element, value, success, error) {
            var $element = $(element), getContent = function(value) {
                var $content;
                try {
                    $content = $(value), $content = $content.length ? $content : $(document.createTextNode(value));
                } catch (e) {
                    $content = $(document.createTextNode(value));
                }
                return $content;
            }, insertContent = function(value) {
                var $content = getContent(value);
                $element[method]($content), success($content);
            };
            try {
                if (!insertions[method]) throw new UnsupportedError(method);
                lang.isConstruct(value) && lang.isFunction(value.insertTo) ? (value.insertTo($element, method), 
                value.contentLoaded.then(success, error)) : lang.isPromise(value) ? value.then(insertContent, function() {
                    var args = arguments;
                    if (lang.isObject(args[0]) && lang.isString(args[1]) && (args[2] instanceof Error || lang.isString(args[2]))) {
                        var e = args[2] instanceof Error ? args[2] : new Error(args[2]);
                        error && error(new InsertionError("Ajax", e), method, $element, value);
                    } else error && error(new InsertionError("Promise"), method, $element, value);
                }) : insertContent(value);
            } catch (e) {
                error && error(new InsertionError("Value", e), method, $element, value);
            }
        }
    }, $.each(insertions, function(name) {
        Insertion[name] = bind(Insertion.execute, this, name);
    }), Insertion;
}), define("mout/function/compose", [], function() {
    function compose() {
        var fns = arguments;
        return function(arg) {
            for (var n = fns.length; n--; ) arg = fns[n].call(this, arg);
            return arg;
        };
    }
    return compose;
}), define("jpmc/util/function/compose", [ "mout/function/compose" ], function(compose) {
    return compose;
}), define("mout/lang/toArray", [ "./kindOf" ], function(kindOf) {
    function toArray(val) {
        var n, ret = [], kind = kindOf(val);
        if (null != val) if (null == val.length || "String" === kind || "Function" === kind || "RegExp" === kind || val === _win) ret[ret.length] = val; else for (n = val.length; n--; ) ret[n] = val[n];
        return ret;
    }
    var _win = this;
    return toArray;
}), define("mout/string/replace", [ "../lang/toString", "../lang/toArray" ], function(toString, toArray) {
    function replace(str, search, replacements) {
        str = toString(str), search = toArray(search), replacements = toArray(replacements);
        var searchLength = search.length, replacementsLength = replacements.length;
        if (1 !== replacementsLength && searchLength !== replacementsLength) throw new Error("Unequal number of searches and replacements");
        for (var i = -1; ++i < searchLength; ) str = str.replace(search[i], replacements[1 === replacementsLength ? 0 : i]);
        return str;
    }
    return replace;
}), define("jpmc/util/string/replace", [ "mout/string/replace" ], function(replace) {
    return replace;
}), define("jpmc/util/object/defineProperty", [ "jpmc/has/detect/object" ], function(has) {
    var defineProperty;
    return defineProperty = has("object-defineproperty") ? Object.defineProperty : function(object, name, descriptor) {
        return object[name] = descriptor && descriptor.value, object;
    };
}), define("mout/object/keys", [ "./forOwn" ], function(forOwn) {
    var keys = Object.keys || function(obj) {
        var keys = [];
        return forOwn(obj, function(val, key) {
            keys.push(key);
        }), keys;
    };
    return keys;
}), define("jpmc/util/object/keys", [ "require", "jpmc/has/detect/object", "mout/object/keys" ], function(require) {
    var has = require("jpmc/has/detect/object");
    return has("object-keys") ? Object.keys : require("mout/object/keys");
}), define("jpmc/util/object/defineProperties", [ "jpmc/has/detect/object", "./defineProperty", "./keys" ], function(has, defineProperty, keys) {
    var defineProperties;
    return defineProperties = has("object-defineproperties") ? Object.defineProperties : function(object, descriptors) {
        for (var name, names = keys(descriptors); name = names.pop(); ) defineProperty(object, name, descriptors[name]);
        return object;
    };
}), define("mout/function/prop", [], function() {
    function prop(name) {
        return function(obj) {
            return obj[name];
        };
    }
    return prop;
}), define("mout/object/deepMatches", [ "./forOwn", "../lang/isArray" ], function(forOwn, isArray) {
    function containsMatch(array, pattern) {
        for (var i = -1, length = array.length; ++i < length; ) if (deepMatches(array[i], pattern)) return !0;
        return !1;
    }
    function matchArray(target, pattern) {
        for (var i = -1, patternLength = pattern.length; ++i < patternLength; ) if (!containsMatch(target, pattern[i])) return !1;
        return !0;
    }
    function matchObject(target, pattern) {
        var result = !0;
        return forOwn(pattern, function(val, key) {
            return deepMatches(target[key], val) ? void 0 : result = !1;
        }), result;
    }
    function deepMatches(target, pattern) {
        return target && "object" == typeof target ? isArray(target) && isArray(pattern) ? matchArray(target, pattern) : matchObject(target, pattern) : target === pattern;
    }
    return deepMatches;
}), define("mout/function/makeIterator_", [ "./prop", "../object/deepMatches" ], function(prop, deepMatches) {
    function makeIterator(src, thisObj) {
        switch (typeof src) {
          case "object":
            return null != src ? function(val) {
                return deepMatches(val, src);
            } : src;

          case "string":
          case "number":
            return prop(src);

          case "function":
            return "undefined" == typeof thisObj ? src : function(val, i, arr) {
                return src.call(thisObj, val, i, arr);
            };

          default:
            return src;
        }
    }
    return makeIterator;
}), define("mout/object/every", [ "./forOwn", "../function/makeIterator_" ], function(forOwn, makeIterator) {
    function every(obj, callback, thisObj) {
        callback = makeIterator(callback, thisObj);
        var result = !0;
        return forOwn(obj, function(val, key) {
            return callback(val, key, obj) ? void 0 : (result = !1, !1);
        }), result;
    }
    return every;
}), define("mout/object/equals", [ "./hasOwn", "./every", "../lang/isObject" ], function(hasOwn, every, isObject) {
    function defaultCompare(a, b) {
        return a === b;
    }
    function makeCompare(callback) {
        return function(value, key) {
            return hasOwn(this, key) && callback(value, this[key]);
        };
    }
    function checkProperties(value, key) {
        return hasOwn(this, key);
    }
    function equals(a, b, callback) {
        return callback = callback || defaultCompare, isObject(a) && isObject(b) ? every(a, makeCompare(callback), b) && every(b, checkProperties, a) : callback(a, b);
    }
    return equals;
}), define("mout/object/deepEquals", [ "../lang/isObject", "./equals" ], function(isObject, equals) {
    function defaultCompare(a, b) {
        return a === b;
    }
    function deepEquals(a, b, callback) {
        function compare(a, b) {
            return deepEquals(a, b, callback);
        }
        return callback = callback || defaultCompare, isObject(a) && isObject(b) ? equals(a, b, compare) : callback(a, b);
    }
    return deepEquals;
}), define("jpmc/util/object/deepEquals", [ "mout/object/deepEquals" ], function(deepEquals) {
    return deepEquals;
}), define("jpmc/util/object/equals", [ "mout/object/equals" ], function(equals) {
    return equals;
}), define("mout/object/filter", [ "./forOwn", "../function/makeIterator_" ], function(forOwn, makeIterator) {
    function filterValues(obj, callback, thisObj) {
        callback = makeIterator(callback, thisObj);
        var output = {};
        return forOwn(obj, function(value, key, obj) {
            callback(value, key, obj) && (output[key] = value);
        }), output;
    }
    return filterValues;
}), define("jpmc/util/object/filter", [ "mout/object/filter" ], function(filter) {
    return filter;
}), define("jpmc/util/object/forIn", [ "mout/object/forIn" ], function(forIn) {
    return forIn;
}), define("jpmc/util/object/getPrototypeOf", [ "jpmc/has/detect/object" ], function(has) {
    return has("object-getprototypeof") ? Object.getPrototypeOf : has("object-__proto__") ? function(value) {
        return value.__proto__;
    } : function(value) {
        return value.constructor && value.constructor.prototype || Object.prototype;
    };
}), define("jpmc/util/object/hasOwn", [ "mout/object/hasOwn" ], function(hasOwn) {
    return hasOwn;
}), define("mout/object/map", [ "./forOwn", "../function/makeIterator_" ], function(forOwn, makeIterator) {
    function mapValues(obj, callback, thisObj) {
        callback = makeIterator(callback, thisObj);
        var output = {};
        return forOwn(obj, function(val, key, obj) {
            output[key] = callback(val, key, obj);
        }), output;
    }
    return mapValues;
}), define("jpmc/util/object/map", [ "mout/object/map" ], function(map) {
    return map;
}), define("mout/array/forEach", [], function() {
    function forEach(arr, callback, thisObj) {
        if (null != arr) for (var i = -1, len = arr.length; ++i < len && callback.call(thisObj, arr[i], i, arr) !== !1; ) ;
    }
    return forEach;
}), define("mout/object/namespace", [ "../array/forEach" ], function(forEach) {
    function namespace(obj, path) {
        return path ? (forEach(path.split("."), function(key) {
            obj[key] || (obj[key] = {}), obj = obj[key];
        }), obj) : obj;
    }
    return namespace;
}), define("jpmc/util/object/namespace", [ "mout/object/namespace" ], function(namespace) {
    return namespace;
}), define("jpmc/util/object", [ "require", "./object/CLASS_PREFIXES", "./object/defineProperties", "./object/defineProperty", "./object/deepEquals", "./object/equals", "./object/extend", "./object/filter", "./object/forIn", "./object/forOwn", "./object/getPrefixed", "./object/getProperty", "./object/getPrototypeOf", "./object/hasOwn", "./object/hasPrefixed", "./object/hasProperty", "./object/map", "./object/namespace", "./object/keys", "./object/OBJECT_PREFIXES", "./object/STYLE_PREFIXES", "./object/VENDOR_PREFIXES" ], function(require) {
    return {
        CLASS_PREFIXES: require("./object/CLASS_PREFIXES"),
        defineProperties: require("./object/defineProperties"),
        defineProperty: require("./object/defineProperty"),
        deepEquals: require("./object/deepEquals"),
        equals: require("./object/equals"),
        extend: require("./object/extend"),
        filter: require("./object/filter"),
        forIn: require("./object/forIn"),
        forOwn: require("./object/forOwn"),
        getPrefixed: require("./object/getPrefixed"),
        getProperty: require("./object/getProperty"),
        getPrototypeOf: require("./object/getPrototypeOf"),
        hasOwn: require("./object/hasOwn"),
        hasPrefixed: require("./object/hasPrefixed"),
        hasProperty: require("./object/hasProperty"),
        map: require("./object/map"),
        namespace: require("./object/namespace"),
        keys: require("./object/keys"),
        OBJECT_PREFIXES: require("./object/OBJECT_PREFIXES"),
        STYLE_PREFIXES: require("./object/STYLE_PREFIXES"),
        VENDOR_PREFIXES: require("./object/VENDOR_PREFIXES")
    };
}), define("jpmc/pipeline", [ "can/construct/super", "jpmc/observe", "jpmc/util/array/indexOf", "jpmc/util/function/compose", "jpmc/util/lang", "jpmc/util/string/replace", "jpmc/util/object" ], function(can, Observe, indexOf, compose, lang, replace, object, undefined) {
    var Pipeline, window = this, reverse = function(array) {
        for (var k, results = [], i = 0, j = array.length; j / 2 > i; i++) k = j - 1 - i, 
        results[i] = array[k], results[k] = array[i];
        return results;
    };
    return Pipeline = Observe.List({
        isStep: function(fn) {
            return lang.isFunction(fn) && fn.isStep;
        }
    }, {
        _cache: undefined,
        _composed: undefined,
        _context: undefined,
        _first: undefined,
        _last: undefined,
        name: undefined,
        _source: undefined,
        _stepNames: undefined,
        _stepIndex: undefined,
        setup: function(name, functions) {
            lang.isArray(name) && (functions = name, name = undefined), this.name = name || "", 
            this.context(this);
            var steps, that = this;
            return functions && (steps = functions.map(this.createStep)), this._cache = {}, 
            this._stepIndex = -1, this._stepNames = [], this.bind("change", function() {
                that.clear();
            }), this._super.call(this, steps);
        },
        add: function(name, fn) {
            var step = this.createStep(name, fn);
            step && this.push(step);
        },
        compose: function() {
            if (!this._composed) {
                var first = this._first ? [ this._first ] : [], last = this._last ? [ this._last ] : [], steps = reverse(first.concat(this.attr(), last)), context = this.context();
                this._composed = function() {
                    return compose.apply(window, steps).apply(context, arguments);
                };
            }
            return this._composed;
        },
        clear: function() {
            this._composed = undefined, this._cache = {};
        },
        context: function(context) {
            return this.clear(), context !== undefined ? this._context = context : this._context;
        },
        createStep: function(name, fn) {
            lang.isFunction(name) && !fn && (fn = name, name = fn.stepName || "");
            var step;
            if (Pipeline.isStep(fn)) step = fn; else if (fn) {
                var pipeline = this;
                step = function(source) {
                    var stepType = name && replace(name, " ", "_"), event = {
                        pipeline: pipeline.name
                    }, stepEvent = object.extend({
                        type: "step",
                        step: name
                    }, event), stepTypeEvent = object.extend({
                        type: stepType,
                        step: name
                    }, event), completeEvent = object.extend({
                        type: "complete"
                    }, event), result = fn.call(this, source), index = ++pipeline._stepIndex;
                    if (result === undefined) throw new Error("Action" + (name ? " " + name : "") + " did not return a result.");
                    return stepType && Observe.triggerBatch(pipeline, stepTypeEvent, [ result, source ]), 
                    Observe.triggerBatch(pipeline, stepEvent, [ name, result, source, index ]), index === pipeline.length - 1 && Observe.triggerBatch(pipeline, completeEvent, [ result, pipeline._source ]), 
                    result;
                }, step.isStep = !0, name && (step.stepName = name);
            }
            return step;
        },
        execute: function(source) {
            this._source = source;
            var result;
            if (lang.isString(source) && this._cache[source] !== undefined) result = this._cache[source]; else {
                var fn = this.compose();
                result = this._cache[source] = fn(source);
            }
            return result;
        },
        first: function(name, fn) {
            return arguments.length ? void (this._first = this.createStep(name, fn)) : this._first;
        },
        indexOf: function(value) {
            return lang.isString(value) ? indexOf(this._stepNames, value) : this._super.apply(this, arguments);
        },
        last: function(name, fn) {
            return arguments.length ? void (this._last = this.createStep(name, fn)) : this._last;
        },
        pop: function() {
            return this._stepNames.pop(), this._super.apply(this, arguments);
        },
        push: function() {
            for (var i = 0, j = arguments.length; j > i; i++) this._stepNames.push(arguments[i].stepName);
            return this._super.apply(this, arguments);
        },
        shift: function() {
            return this._stepNames.shift(), this._super.apply(this, arguments);
        },
        splice: function(index, howMany) {
            for (var slice = Array.prototype.slice, splice = Array.prototype.splice, steps = slice.call(arguments, 2), stepNames = [], i = 0, j = steps.length; j > i; i++) stepNames.push(steps[i].stepName);
            return stepNames.unshift(index, howMany), splice.apply(this._stepNames, stepNames), 
            this._super.apply(this, arguments);
        },
        unshift: function() {
            for (var i = arguments.length; i--; ) this._stepNames.unshift(arguments[i].stepName);
            return this._super.apply(this, arguments);
        }
    });
}), define("jquery-imagesloaded", [ "jquery" ], function(jQuery) {
    var $ = jQuery;
    return function($, undefined) {
        var BLANK = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
        $.fn.imagesLoaded = function(callback) {
            function doneLoading() {
                var $proper = $(proper), $broken = $(broken);
                deferred && (broken.length ? deferred.reject($images, $proper, $broken) : deferred.resolve($images)), 
                $.isFunction(callback) && callback.call($this, $images, $proper, $broken);
            }
            function imgLoadedHandler(event) {
                imgLoaded(event.target, "error" === event.type);
            }
            function imgLoaded(img, isBroken) {
                img.src !== BLANK && -1 === $.inArray(img, loaded) && (loaded.push(img), isBroken ? broken.push(img) : proper.push(img), 
                $.data(img, "imagesLoaded", {
                    isBroken: isBroken,
                    src: img.src
                }), hasNotify && deferred.notifyWith($(img), [ isBroken, $images, $(proper), $(broken) ]), 
                $images.length === loaded.length && (setTimeout(doneLoading), $images.unbind(".imagesLoaded", imgLoadedHandler)));
            }
            var $this = this, deferred = $.isFunction($.Deferred) ? $.Deferred() : 0, hasNotify = $.isFunction(deferred.notify), $images = $this.find("img").add($this.filter("img")), loaded = [], proper = [], broken = [];
            return $.isPlainObject(callback) && $.each(callback, function(key, value) {
                "callback" === key ? callback = value : deferred && deferred[key](value);
            }), $images.length ? $images.bind("load.imagesLoaded error.imagesLoaded", imgLoadedHandler).each(function(i, el) {
                var src = el.src, cached = $.data(el, "imagesLoaded");
                return cached && cached.src === src ? void imgLoaded(el, cached.isBroken) : el.complete && el.naturalWidth !== undefined ? void imgLoaded(el, 0 === el.naturalWidth || 0 === el.naturalHeight) : void ((el.readyState || el.complete) && (el.src = BLANK, 
                el.src = src));
            }) : doneLoading(), deferred ? deferred.promise($this) : $this;
        };
    }(jQuery), $.fn.imagesLoaded;
}), define("jpmc/ui/widget", [ "jpmc/$", "jpmc/construct", "jpmc/meld", "jpmc/observe", "jpmc/observe/compute", "jpmc/pipeline", "jpmc/util/lang/isFunction", "jpmc/util/object/extend", "jpmc/util/object/getPrototypeOf", "jquery-imagesloaded", "when" ], function($, Construct, meld, Observe, compute, Pipeline, isFunction, extend, getPrototypeOf, $imagesloaded, when, undefined) {
    var Widget, classSuffix = function(suffix) {
        return suffix = suffix || "", suffix && "-" !== suffix.charAt(0) && (suffix = "-" + suffix), 
        suffix;
    }, isObserve = function(value) {
        return value && isFunction(value.attr);
    }, uuid = 0;
    return Widget = Construct({
        defaults: {
            lazy: !1,
            lazyRenderBefore: "insertTo",
            showBefore: "inserted"
        },
        newInstance: function() {
            var instance = this._super.apply(this, arguments);
            return !instance.options.lazy && instance.render.call(instance), instance;
        }
    }, {
        className: "jpmc-widget",
        contentLoaded: undefined,
        layout: undefined,
        pipeline: undefined,
        store: undefined,
        setup: function(data, settings) {
            data && !settings && (settings = data, data = undefined), this.uuid = ++uuid, this.drawn = !1;
            var that = this, options = this.options = extend(!0, {}, this.constructor.defaults, settings || {}), classes = this.classes = this._createClassTree(), pipeline = this.pipeline = new Pipeline("renderer"), store = this.store = new Observe({}), baseRenderer = function(data) {
                if (!that.view) throw new Error("No view declared");
                isFunction(that.view) || (that.rawView = that.view, that.view = function() {
                    return $(that.rawView);
                });
                var content = that.view(isObserve(data) ? data.attr() : data);
                return $(content);
            };
            return null !== options.showBefore && (this[options.showBefore] === undefined && (this[options.showBefore] = function() {}), 
            meld.before(this, options.showBefore, function() {
                this.show();
            })), (!this.view || options.lazy) && (options.lazy = !0, null !== options.lazyRenderBefore && (this[options.lazyRenderBefore] === undefined && (this[options.lazyRenderBefore] = function() {}), 
            meld.before(this, options.lazyRenderBefore, function() {
                !this.drawn && this.render();
            }))), this.rawData = data || options.data || {}, this.data = compute(function(value) {
                return value === undefined ? this.attr("data") : void this.attr("data", value);
            }, store), this.data.bind("change", function(event, newData) {
                newData.bind("change", function() {
                    that.drawn = !1, that.draw(newData);
                }), that.drawn = !1, that.draw(newData);
            }), pipeline.context(this), pipeline.first("render", baseRenderer), pipeline.add("markup", function($content) {
                return $content.addClass(classes.join(" ")).attr("data-widget-id", that.uuid);
            }), pipeline.add("rendered", function($content) {
                return this.rendered && this.rendered($content) || $content;
            }), pipeline.last("completed", function($content) {
                return this.completed && this.completed($content) || $content;
            }), this.content = compute(function(value) {
                if (isFunction(value)) {
                    var content = value(this.attr("content"));
                    return this.attr("content", content), content;
                }
                return value === undefined ? this.attr("content") : void this.attr("content", value);
            }, store), [ options ];
        },
        _createClassTree: function() {
            for (var classes = [], that = this, widget = this; widget && widget.className && (classes.push(widget.className), 
            widget = getPrototypeOf(widget.constructor.prototype), widget.className !== that.className); ) ;
            return classes;
        },
        destroy: function() {
            this.remove();
        },
        _doFailed: function($content) {
            this.failed && this.failed($content);
        },
        _doInsertTo: function($content, element, using) {
            this.element = element, this.$element = $(element)[using]($content), this.inserted && this.inserted($content, this.$element);
        },
        _doLoaded: function($content) {
            this.loaded && this.loaded($content);
        },
        draw: function(data) {
            var $content = this.pipeline.execute(data), isInDocument = $.isReady && $.contains(document.body, $content[0]), drawContent = function() {
                this.content($content), this._track($content), this.drawn = !0;
            };
            if (this.content()) {
                var element = this.element;
                element && this.remove(), drawContent.call(this), element && this.insertTo(element);
            } else if (isInDocument) {
                var $parent = $content.parent();
                this.element = $parent[0], this.$element = $parent, drawContent.call(this), this.inserted && this.inserted($content, this.$element);
            } else drawContent.call(this), this.hide();
        },
        getClassName: function(suffix) {
            return this.className + classSuffix(suffix);
        },
        getClassTree: function(suffix) {
            var nameSuffix = classSuffix(suffix);
            return this.classTree.join(nameSuffix + " ") + nameSuffix;
        },
        hide: function() {
            this.content().hide();
        },
        insertTo: function(element, using) {
            this._doInsertTo(this.content(), element, using || "append");
        },
        remove: function() {
            var $content = this.content();
            this.$element && $.contains(this.$element[0], $content[0]) && ($content.remove(), 
            this.element = this.$element = undefined);
        },
        render: function(view) {
            view && (this.view = view);
            var data = this.rawData;
            data ? (this.data(data), this.rawData = undefined) : this.draw(this.data());
        },
        show: function() {
            this.content().show();
        },
        _track: function($content) {
            var that = this, $img = $content.find("img"), deferred = when.defer();
            this.contentLoaded = deferred.promise, this.contentLoaded.then(function() {
                that._doLoaded.call(that, $content);
            }, function() {
                that._doFailed.call(that, $content);
            }), $img.length ? $img.imagesLoaded({
                done: deferred.resolve,
                fail: deferred.reject
            }) : deferred.resolve();
        }
    });
}), define("jpmc/ui/layout", [ "jpmc/$", "jpmc/ui/insertion", "jpmc/ui/widget", "jpmc/util/lang", "jpmc/util/object/forOwn", "jpmc/util/function/bind", "when" ], function($, Insertion, Widget, lang, forOwn, bind, when, undefined) {
    var Layout;
    return Layout = Widget({
        defaults: {
            lazy: !0,
            showBefore: "loaded"
        }
    }, {
        className: "jpmc-layout",
        insertsLoaded: undefined,
        insertUUID: undefined,
        targets: undefined,
        setup: function() {
            return this.insertUUID = 0, this._super.apply(this, arguments);
        },
        _doInsert: function(method, target, value) {
            value === undefined && (value = target, target = undefined);
            var deferred = when.defer(), name = "insert_" + ++this.insertUUID, fn = function($content) {
                var $targeted = target ? $content.filter(target).add($content.find(target)) : $content;
                return Insertion[method]($targeted, value, deferred.resolve, deferred.reject), $content;
            }, step = this.pipeline.createStep(name, fn), composedIndex = this.pipeline.indexOf("composed");
            this.insertsLoaded = this.insertsLoaded ? when.join(this.insertsLoaded, deferred.promise) : deferred.promise, 
            -1 !== composedIndex ? (this.pipeline.splice(composedIndex, 0, step), this.render()) : this.pipeline.push(step);
        },
        empty: function(target) {
            if (lang.isString(target)) {
                var selector = this.targets[target] || target;
                selector && this.content().find(selector).empty();
            } else this.content().empty();
        },
        insert: function() {
            for (var insertion, i = 0, j = arguments.length; j > i; i++) if (insertion = arguments[0], 
            lang.isPlainObject(insertion)) {
                var method, parts, selector, target;
                forOwn(insertion, function(value, key) {
                    -1 !== key.indexOf(" ") ? (parts = key.split(" "), method = parts.pop(), selector = parts.join(" "), 
                    method && !selector && (selector = method, method = "append")) : (method = "append", 
                    selector = key), target = this.targets[selector] || selector, this._doInsert(method, target, value);
                }, this);
            } else this._doInsert("append", insertion);
        },
        isTarget: function(name) {
            return this.targets[name] !== undefined;
        },
        render: function() {
            -1 === this.pipeline.indexOf("composed") && this.pipeline.add("composed", function($content) {
                return this.composed && this.composed($content) || $content;
            }), this._super.apply(this, arguments);
        },
        _track: function() {
            this._super.apply(this, arguments), this.insertsLoaded && this.contentLoaded && (this.contentLoaded = when.join(this.contentLoaded, this.insertsLoaded));
        }
    });
}), define("jpmc/ui/mixin/handler", [ "jpmc/event/handler", "jpmc/util/array/indexOf", "jpmc/util/lang", "jpmc/util/object/forOwn", "jpmc/util/function/bind" ], function(Handler, indexOf, lang, forOwn, bind) {
    var HandlerMixin, createHandler = function(element, config, options) {
        var eventType, fn, MixinHandler, types = [], bindings = {};
        return forOwn(config, function(value, key) {
            if (eventType = key.split(" ").pop(), -1 === indexOf(Handler.events, eventType) && -1 === indexOf(types, eventType) && types.push(eventType), 
            fn = lang.isString(value) ? lang.isFunction(this[value]) && this[value] : value, 
            !lang.isFunction(fn)) throw "Callback for " + key + " is undefined";
            bindings[key] = bind(fn, this);
        }, this), new (MixinHandler = Handler({
            handles: types
        }, bindings))(element, options);
    };
    return HandlerMixin = function() {
        this.pipeline.add("handler", function($content) {
            return lang.isPlainObject(this.handler) && !lang.isEmpty(this.handler) ? (this.handlerInstance = createHandler.call(this, $content, this.handler, {
                data: this.data(),
                "this": this
            }), this.handlerInstance.element) : $content;
        }), this.bindEvents = function(config) {
            return createHandler.call(this, this.content(), config, {
                data: this.data(),
                "this": this
            });
        };
    };
}), define("jpmc/util/dom/topZ", [], function() {
    var topZ, z = 3e4;
    return topZ = function() {
        return ++z;
    };
}), define("jquerypp/event/livehack", [ "jquery" ], function($) {
    var event = $.event, findHelper = function(events, types, callback, selector) {
        var t, type, typeHandlers, all, h, handle, namespaces, namespace, match;
        for (t = 0; t < types.length; t++) for (type = types[t], all = type.indexOf(".") < 0, 
        all || (namespaces = type.split("."), type = namespaces.shift(), namespace = new RegExp("(^|\\.)" + namespaces.slice(0).sort().join("\\.(?:.*\\.)?") + "(\\.|$)")), 
        typeHandlers = (events[type] || []).slice(0), h = 0; h < typeHandlers.length; h++) handle = typeHandlers[h], 
        match = all || namespace.test(handle.namespace), match && (selector ? handle.selector === selector && callback(type, handle.origHandler || handle.handler) : null === selector ? callback(type, handle.origHandler || handle.handler, handle.selector) : handle.selector || callback(type, handle.origHandler || handle.handler));
    };
    return event.find = function(el, types, selector) {
        var events = ($._data(el) || {}).events, handlers = [];
        return events ? (findHelper(events, types, function(type, handler) {
            handlers.push(handler);
        }, selector), handlers) : handlers;
    }, event.findBySelector = function(el, types) {
        var events = $._data(el).events, selectors = {}, add = function(selector, event, handler) {
            var select = selectors[selector] || (selectors[selector] = {}), events = select[event] || (select[event] = []);
            events.push(handler);
        };
        return events ? (findHelper(events, types, function(type, handler, selector) {
            add(selector || "", type, handler);
        }, null), selectors) : selectors;
    }, event.supportTouch = "ontouchend" in document, $.fn.respondsTo = function(events) {
        return this.length ? event.find(this[0], $.isArray(events) ? events : [ events ]).length > 0 : !1;
    }, $.fn.triggerHandled = function(event, data) {
        return event = "string" == typeof event ? $.Event(event) : event, this.trigger(event, data), 
        event.handled;
    }, event.setupHelper = function(types, startingEvent, onFirst) {
        onFirst || (onFirst = startingEvent, startingEvent = null);
        var add = function(handleObj) {
            var bySelector, selector = handleObj.selector || "", namespace = handleObj.namespace ? "." + handleObj.namespace : "";
            selector ? (bySelector = event.find(this, types, selector), bySelector.length || $(this).delegate(selector, startingEvent + namespace, onFirst)) : event.find(this, types, selector).length || event.add(this, startingEvent + namespace, onFirst, {
                selector: selector,
                delegate: this
            });
        }, remove = function(handleObj) {
            var bySelector, selector = handleObj.selector || "";
            selector ? (bySelector = event.find(this, types, selector), bySelector.length || $(this).undelegate(selector, startingEvent, onFirst)) : event.find(this, types, selector).length || event.remove(this, startingEvent, onFirst, {
                selector: selector,
                delegate: this
            });
        };
        $.each(types, function() {
            event.special[this] = {
                add: add,
                remove: remove,
                setup: function() {},
                teardown: function() {}
            };
        });
    }, $;
}), define("jquerypp/event/hover", [ "jquery", "jquerypp/event/livehack" ], function($) {
    $.Hover = function() {
        this._delay = $.Hover.delay, this._distance = $.Hover.distance, this._leave = $.Hover.leave;
    }, $.extend($.Hover, {
        delay: 100,
        distance: 10,
        leave: 0
    }), $.extend($.Hover.prototype, {
        delay: function(delay) {
            return this._delay = delay, this;
        },
        distance: function(distance) {
            return this._distance = distance, this;
        },
        leave: function(leave) {
            return this._leave = leave, this;
        }
    });
    var event = $.event, onmouseenter = (event.handle, function(ev) {
        var delegate = ev.delegateTarget || ev.currentTarget, selector = ev.handleObj.selector, pending = $.data(delegate, "_hover" + selector);
        if (pending) {
            if (!pending.forcing) {
                pending.forcing = !0, clearTimeout(pending.leaveTimer);
                var leaveTime = pending.leaving ? Math.max(0, pending.hover.leave - (new Date() - pending.leaving)) : pending.hover.leave, self = this;
                setTimeout(function() {
                    pending.callHoverLeave(), onmouseenter.call(self, ev);
                }, leaveTime);
            }
        } else {
            var timer, leaveTimer, loc = {
                pageX: ev.pageX,
                pageY: ev.pageY
            }, dist = 0, enteredEl = this, hovered = !1, lastEv = ev, hover = new $.Hover(), callHoverLeave = function() {
                $.each(event.find(delegate, [ "hoverleave" ], selector), function() {
                    this.call(enteredEl, ev, hover);
                }), cleanUp();
            }, mousemove = function(ev) {
                clearTimeout(leaveTimer), dist += Math.pow(ev.pageX - loc.pageX, 2) + Math.pow(ev.pageY - loc.pageY, 2), 
                loc = {
                    pageX: ev.pageX,
                    pageY: ev.pageY
                }, lastEv = ev;
            }, mouseleave = function() {
                clearTimeout(timer), hovered ? 0 === hover._leave ? callHoverLeave() : (clearTimeout(leaveTimer), 
                pending.leaving = new Date(), leaveTimer = pending.leaveTimer = setTimeout(function() {
                    callHoverLeave();
                }, hover._leave)) : cleanUp();
            }, cleanUp = function() {
                $(enteredEl).unbind("mouseleave", mouseleave), $(enteredEl).unbind("mousemove", mousemove), 
                $.removeData(delegate, "_hover" + selector);
            }, hoverenter = function() {
                $.each(event.find(delegate, [ "hoverenter" ], selector), function() {
                    this.call(enteredEl, lastEv, hover);
                }), hovered = !0;
            };
            pending = {
                callHoverLeave: callHoverLeave,
                hover: hover
            }, $.data(delegate, "_hover" + selector, pending), $(enteredEl).bind("mousemove", mousemove).bind("mouseleave", mouseleave), 
            $.each(event.find(delegate, [ "hoverinit" ], selector), function() {
                this.call(enteredEl, ev, hover);
            }), 0 === hover._delay ? hoverenter() : timer = setTimeout(function() {
                return dist < hover._distance && 0 == $(enteredEl).queue().length ? void hoverenter() : (dist = 0, 
                void (timer = setTimeout(arguments.callee, hover._delay)));
            }, hover._delay);
        }
    });
    return event.setupHelper([ "hoverinit", "hoverenter", "hoverleave", "hovermove" ], "mouseenter", onmouseenter), 
    $;
}), define("jqueryui/position", [ "jquery" ], function(jQuery) {
    return function($, undefined) {
        function getOffsets(offsets, width, height) {
            return [ parseFloat(offsets[0]) * (rpercent.test(offsets[0]) ? width / 100 : 1), parseFloat(offsets[1]) * (rpercent.test(offsets[1]) ? height / 100 : 1) ];
        }
        function parseCss(element, property) {
            return parseInt($.css(element, property), 10) || 0;
        }
        function getDimensions(elem) {
            var raw = elem[0];
            return 9 === raw.nodeType ? {
                width: elem.width(),
                height: elem.height(),
                offset: {
                    top: 0,
                    left: 0
                }
            } : $.isWindow(raw) ? {
                width: elem.width(),
                height: elem.height(),
                offset: {
                    top: elem.scrollTop(),
                    left: elem.scrollLeft()
                }
            } : raw.preventDefault ? {
                width: 0,
                height: 0,
                offset: {
                    top: raw.pageY,
                    left: raw.pageX
                }
            } : {
                width: elem.outerWidth(),
                height: elem.outerHeight(),
                offset: elem.offset()
            };
        }
        $.ui = $.ui || {};
        var cachedScrollbarWidth, max = Math.max, abs = Math.abs, round = Math.round, rhorizontal = /left|center|right/, rvertical = /top|center|bottom/, roffset = /[\+\-]\d+(\.[\d]+)?%?/, rposition = /^\w+/, rpercent = /%$/, _position = $.fn.position;
        $.position = {
            scrollbarWidth: function() {
                if (cachedScrollbarWidth !== undefined) return cachedScrollbarWidth;
                var w1, w2, div = $("<div style='display:block;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"), innerDiv = div.children()[0];
                return $("body").append(div), w1 = innerDiv.offsetWidth, div.css("overflow", "scroll"), 
                w2 = innerDiv.offsetWidth, w1 === w2 && (w2 = div[0].clientWidth), div.remove(), 
                cachedScrollbarWidth = w1 - w2;
            },
            getScrollInfo: function(within) {
                var overflowX = within.isWindow ? "" : within.element.css("overflow-x"), overflowY = within.isWindow ? "" : within.element.css("overflow-y"), hasOverflowX = "scroll" === overflowX || "auto" === overflowX && within.width < within.element[0].scrollWidth, hasOverflowY = "scroll" === overflowY || "auto" === overflowY && within.height < within.element[0].scrollHeight;
                return {
                    width: hasOverflowY ? $.position.scrollbarWidth() : 0,
                    height: hasOverflowX ? $.position.scrollbarWidth() : 0
                };
            },
            getWithinInfo: function(element) {
                var withinElement = $(element || window), isWindow = $.isWindow(withinElement[0]);
                return {
                    element: withinElement,
                    isWindow: isWindow,
                    offset: withinElement.offset() || {
                        left: 0,
                        top: 0
                    },
                    scrollLeft: withinElement.scrollLeft(),
                    scrollTop: withinElement.scrollTop(),
                    width: isWindow ? withinElement.width() : withinElement.outerWidth(),
                    height: isWindow ? withinElement.height() : withinElement.outerHeight()
                };
            }
        }, $.fn.position = function(options) {
            if (!options || !options.of) return _position.apply(this, arguments);
            options = $.extend({}, options);
            var atOffset, targetWidth, targetHeight, targetOffset, basePosition, dimensions, target = $(options.of), within = $.position.getWithinInfo(options.within), scrollInfo = $.position.getScrollInfo(within), collision = (options.collision || "flip").split(" "), offsets = {};
            return dimensions = getDimensions(target), target[0].preventDefault && (options.at = "left top"), 
            targetWidth = dimensions.width, targetHeight = dimensions.height, targetOffset = dimensions.offset, 
            basePosition = $.extend({}, targetOffset), $.each([ "my", "at" ], function() {
                var horizontalOffset, verticalOffset, pos = (options[this] || "").split(" ");
                1 === pos.length && (pos = rhorizontal.test(pos[0]) ? pos.concat([ "center" ]) : rvertical.test(pos[0]) ? [ "center" ].concat(pos) : [ "center", "center" ]), 
                pos[0] = rhorizontal.test(pos[0]) ? pos[0] : "center", pos[1] = rvertical.test(pos[1]) ? pos[1] : "center", 
                horizontalOffset = roffset.exec(pos[0]), verticalOffset = roffset.exec(pos[1]), 
                offsets[this] = [ horizontalOffset ? horizontalOffset[0] : 0, verticalOffset ? verticalOffset[0] : 0 ], 
                options[this] = [ rposition.exec(pos[0])[0], rposition.exec(pos[1])[0] ];
            }), 1 === collision.length && (collision[1] = collision[0]), "right" === options.at[0] ? basePosition.left += targetWidth : "center" === options.at[0] && (basePosition.left += targetWidth / 2), 
            "bottom" === options.at[1] ? basePosition.top += targetHeight : "center" === options.at[1] && (basePosition.top += targetHeight / 2), 
            atOffset = getOffsets(offsets.at, targetWidth, targetHeight), basePosition.left += atOffset[0], 
            basePosition.top += atOffset[1], this.each(function() {
                var collisionPosition, using, elem = $(this), elemWidth = elem.outerWidth(), elemHeight = elem.outerHeight(), marginLeft = parseCss(this, "marginLeft"), marginTop = parseCss(this, "marginTop"), collisionWidth = elemWidth + marginLeft + parseCss(this, "marginRight") + scrollInfo.width, collisionHeight = elemHeight + marginTop + parseCss(this, "marginBottom") + scrollInfo.height, position = $.extend({}, basePosition), myOffset = getOffsets(offsets.my, elem.outerWidth(), elem.outerHeight());
                "right" === options.my[0] ? position.left -= elemWidth : "center" === options.my[0] && (position.left -= elemWidth / 2), 
                "bottom" === options.my[1] ? position.top -= elemHeight : "center" === options.my[1] && (position.top -= elemHeight / 2), 
                position.left += myOffset[0], position.top += myOffset[1], $.support.offsetFractions || (position.left = round(position.left), 
                position.top = round(position.top)), collisionPosition = {
                    marginLeft: marginLeft,
                    marginTop: marginTop
                }, $.each([ "left", "top" ], function(i, dir) {
                    $.ui.position[collision[i]] && $.ui.position[collision[i]][dir](position, {
                        targetWidth: targetWidth,
                        targetHeight: targetHeight,
                        elemWidth: elemWidth,
                        elemHeight: elemHeight,
                        collisionPosition: collisionPosition,
                        collisionWidth: collisionWidth,
                        collisionHeight: collisionHeight,
                        offset: [ atOffset[0] + myOffset[0], atOffset[1] + myOffset[1] ],
                        my: options.my,
                        at: options.at,
                        within: within,
                        elem: elem
                    });
                }), options.using && (using = function(props) {
                    var left = targetOffset.left - position.left, right = left + targetWidth - elemWidth, top = targetOffset.top - position.top, bottom = top + targetHeight - elemHeight, feedback = {
                        target: {
                            element: target,
                            left: targetOffset.left,
                            top: targetOffset.top,
                            width: targetWidth,
                            height: targetHeight
                        },
                        element: {
                            element: elem,
                            left: position.left,
                            top: position.top,
                            width: elemWidth,
                            height: elemHeight
                        },
                        horizontal: 0 > right ? "left" : left > 0 ? "right" : "center",
                        vertical: 0 > bottom ? "top" : top > 0 ? "bottom" : "middle"
                    };
                    elemWidth > targetWidth && abs(left + right) < targetWidth && (feedback.horizontal = "center"), 
                    elemHeight > targetHeight && abs(top + bottom) < targetHeight && (feedback.vertical = "middle"), 
                    feedback.important = max(abs(left), abs(right)) > max(abs(top), abs(bottom)) ? "horizontal" : "vertical", 
                    options.using.call(this, props, feedback);
                }), elem.offset($.extend(position, {
                    using: using
                }));
            });
        }, $.ui.position = {
            fit: {
                left: function(position, data) {
                    var newOverRight, within = data.within, withinOffset = within.isWindow ? within.scrollLeft : within.offset.left, outerWidth = within.width, collisionPosLeft = position.left - data.collisionPosition.marginLeft, overLeft = withinOffset - collisionPosLeft, overRight = collisionPosLeft + data.collisionWidth - outerWidth - withinOffset;
                    data.collisionWidth > outerWidth ? overLeft > 0 && 0 >= overRight ? (newOverRight = position.left + overLeft + data.collisionWidth - outerWidth - withinOffset, 
                    position.left += overLeft - newOverRight) : position.left = overRight > 0 && 0 >= overLeft ? withinOffset : overLeft > overRight ? withinOffset + outerWidth - data.collisionWidth : withinOffset : overLeft > 0 ? position.left += overLeft : overRight > 0 ? position.left -= overRight : position.left = max(position.left - collisionPosLeft, position.left);
                },
                top: function(position, data) {
                    var newOverBottom, within = data.within, withinOffset = within.isWindow ? within.scrollTop : within.offset.top, outerHeight = data.within.height, collisionPosTop = position.top - data.collisionPosition.marginTop, overTop = withinOffset - collisionPosTop, overBottom = collisionPosTop + data.collisionHeight - outerHeight - withinOffset;
                    data.collisionHeight > outerHeight ? overTop > 0 && 0 >= overBottom ? (newOverBottom = position.top + overTop + data.collisionHeight - outerHeight - withinOffset, 
                    position.top += overTop - newOverBottom) : position.top = overBottom > 0 && 0 >= overTop ? withinOffset : overTop > overBottom ? withinOffset + outerHeight - data.collisionHeight : withinOffset : overTop > 0 ? position.top += overTop : overBottom > 0 ? position.top -= overBottom : position.top = max(position.top - collisionPosTop, position.top);
                }
            },
            flip: {
                left: function(position, data) {
                    var newOverRight, newOverLeft, within = data.within, withinOffset = within.offset.left + within.scrollLeft, outerWidth = within.width, offsetLeft = within.isWindow ? within.scrollLeft : within.offset.left, collisionPosLeft = position.left - data.collisionPosition.marginLeft, overLeft = collisionPosLeft - offsetLeft, overRight = collisionPosLeft + data.collisionWidth - outerWidth - offsetLeft, myOffset = "left" === data.my[0] ? -data.elemWidth : "right" === data.my[0] ? data.elemWidth : 0, atOffset = "left" === data.at[0] ? data.targetWidth : "right" === data.at[0] ? -data.targetWidth : 0, offset = -2 * data.offset[0];
                    0 > overLeft ? (newOverRight = position.left + myOffset + atOffset + offset + data.collisionWidth - outerWidth - withinOffset, 
                    (0 > newOverRight || newOverRight < abs(overLeft)) && (position.left += myOffset + atOffset + offset)) : overRight > 0 && (newOverLeft = position.left - data.collisionPosition.marginLeft + myOffset + atOffset + offset - offsetLeft, 
                    (newOverLeft > 0 || abs(newOverLeft) < overRight) && (position.left += myOffset + atOffset + offset));
                },
                top: function(position, data) {
                    var newOverTop, newOverBottom, within = data.within, withinOffset = within.offset.top + within.scrollTop, outerHeight = within.height, offsetTop = within.isWindow ? within.scrollTop : within.offset.top, collisionPosTop = position.top - data.collisionPosition.marginTop, overTop = collisionPosTop - offsetTop, overBottom = collisionPosTop + data.collisionHeight - outerHeight - offsetTop, top = "top" === data.my[1], myOffset = top ? -data.elemHeight : "bottom" === data.my[1] ? data.elemHeight : 0, atOffset = "top" === data.at[1] ? data.targetHeight : "bottom" === data.at[1] ? -data.targetHeight : 0, offset = -2 * data.offset[1];
                    0 > overTop ? (newOverBottom = position.top + myOffset + atOffset + offset + data.collisionHeight - outerHeight - withinOffset, 
                    position.top + myOffset + atOffset + offset > overTop && (0 > newOverBottom || newOverBottom < abs(overTop)) && (position.top += myOffset + atOffset + offset)) : overBottom > 0 && (newOverTop = position.top - data.collisionPosition.marginTop + myOffset + atOffset + offset - offsetTop, 
                    position.top + myOffset + atOffset + offset > overBottom && (newOverTop > 0 || abs(newOverTop) < overBottom) && (position.top += myOffset + atOffset + offset));
                }
            },
            flipfit: {
                left: function() {
                    $.ui.position.flip.left.apply(this, arguments), $.ui.position.fit.left.apply(this, arguments);
                },
                top: function() {
                    $.ui.position.flip.top.apply(this, arguments), $.ui.position.fit.top.apply(this, arguments);
                }
            }
        }, function() {
            var testElement, testElementParent, testElementStyle, offsetLeft, i, body = document.getElementsByTagName("body")[0], div = document.createElement("div");
            testElement = document.createElement(body ? "div" : "body"), testElementStyle = {
                visibility: "hidden",
                width: 0,
                height: 0,
                border: 0,
                margin: 0,
                background: "none"
            }, body && $.extend(testElementStyle, {
                position: "absolute",
                left: "-1000px",
                top: "-1000px"
            });
            for (i in testElementStyle) testElement.style[i] = testElementStyle[i];
            testElement.appendChild(div), testElementParent = body || document.documentElement, 
            testElementParent.insertBefore(testElement, testElementParent.firstChild), div.style.cssText = "position: absolute; left: 10.7432222px;", 
            offsetLeft = $(div).offset().left, $.support.offsetFractions = offsetLeft > 10 && 11 > offsetLeft, 
            testElement.innerHTML = "", testElementParent.removeChild(testElement);
        }();
    }(jQuery), jQuery.ui.position;
}), define("conf/ui/floater/position", {
    "right-center": {
        my: "left center",
        at: "right center",
        collision: "flipfit filpfit"
    },
    "left-center": {
        my: "right center",
        at: "left center",
        collision: "flipfit flipfit"
    },
    "bottom-center": {
        my: "center top",
        at: "center bottom",
        collision: "flipfit flipfit"
    },
    "top-center": {
        my: "center bottom",
        at: "center top",
        collision: "flipfit flipfit"
    },
    "right-top": {
        my: "left top",
        at: "right top",
        collision: "flipfit flipfit"
    },
    "right-bottom": {
        my: "left bottom",
        at: "right bottom",
        collision: "flipfit flipfit"
    },
    "left-top": {
        my: "right top",
        at: "left top",
        collision: "flipfit flipfit"
    },
    "left-bottom": {
        my: "right bottom",
        at: "left bottom",
        collision: "flipfit flipfit"
    },
    "bottom-right": {
        my: "right top",
        at: "right bottom",
        collision: "flipfit flipfit"
    },
    "bottom-left": {
        my: "left top",
        at: "left bottom",
        collision: "flipfit flipfit"
    },
    "top-right": {
        my: "right bottom",
        at: "right top",
        collision: "flipfit flipfit"
    },
    "top-left": {
        my: "left bottom",
        at: "left top",
        collision: "flipfit flipfit"
    },
    "bottom-left-none": {
        my: "left top",
        at: "left bottom",
        collision: "none"
    },
    "right-top-none": {
        my: "left top",
        at: "right top",
        collision: "none"
    },
    "right-top-none-quirks": {
        my: "left top",
        at: "right+3 top-2",
        collision: "none"
    },
    "bottom-center-none": {
        my: "center top",
        at: "center bottom",
        collision: "none"
    },
    viewportcenter: {
        my: "center",
        at: "center",
        collision: "fit",
        of: window
    },
    "center-center": {
        my: "center",
        at: "center",
        collisiont: "flipfit"
    }
}), define("jpmc/ui/floater", [ "jpmc/$", "jpmc/event/handler/tabArea", "jpmc/mixin/publisher", "jpmc/mixin/state", "jpmc/template/floater", "jpmc/ui/layout", "jpmc/ui/mixin/handler", "jpmc/util/dom/topZ", "jpmc/util/object/extend", "jquerypp/event/hover", "jqueryui/core", "jqueryui/position", "conf/ui/floater/position", "jpmc/has/detect/dom" ], function($, tabAreaHandler, PublisherMixin, StateMixin, FloaterView, Layout, HandlerMixin, topZ, extend, $hover, $core, $position, positions, has, undefined) {
    var Floater, document = window.document;
    return Floater = Layout({
        defaults: {
            closeOnDocumentClick: !1,
            preventTabOut: !1,
            focus: !1,
            positionTarget: undefined,
            initPosition: "center-center",
            offset: "0 0",
            repositionOnScroll: !1,
            width: undefined,
            maxHeight: undefined,
            closeSelector: ".chasejs-floaterclose",
            showBefore: null,
            zIndex: undefined
        }
    }, {
        className: "jpmc-floater",
        view: FloaterView,
        handler: {},
        states: {
            initialized: "init",
            displayed: "show",
            hidden: "hide",
            removed: "remove"
        },
        publisher: {
            floaterClose: !0
        },
        init: function(options) {
            var targets = this.targets;
            options.closeOnDocumentClick && (this.handler["{document} " + (has("touch") ? "touchstart" : "click")] = "onDocumentClick"), 
            options.preventTabOut && (this.handler = extend({}, this.handler, tabAreaHandler.bindings())), 
            this.handler[options.closeSelector + " click"] = "onCloseButtonClick", this.pipeline.bind("complete", function(event, $content) {
                if (targets = targets || {}, !targets.body) {
                    for (var $body = $content.children(); $body.length; ) $body = $body.children();
                    targets.body = $body;
                }
            });
        },
        initialized: function(options) {
            HandlerMixin.call(this, options), StateMixin.call(this, options), PublisherMixin.call(this, options);
        },
        adjustHeight: function(settings) {
            var $content = this.content(), contentHeight = $content.height();
            if (settings.maxHeight && contentHeight > settings.maxHeight && $(window).height() > contentHeight) {
                var $body = $content.find(this.targets.body);
                $body.css({
                    "overflow-y": "scroll",
                    height: settings.maxHeight + $content.offset().top - $body.offset().top
                });
            }
        },
        focus: function(settings) {
            var $content = this.content();
            settings.focus && $content && $content.find(":focusable").first().focus();
        },
        hide: function() {
            this.state.isHidden() || (this._super.apply(this), this._hidden()), $.contains(this.content()[0], document.activeElement) && this.$lastActive && this.$lastActive.length && this.$lastActive.is(":visible") && this.$lastActive.focus();
        },
        onCloseButtonClick: function($button, event) {
            event.preventDefault(), this.hide(), this.publishFloaterClose([ event, this ]);
        },
        onDocumentClick: function($document, event) {
            var $content = this.content(), $element = $(event.target);
            !this.options.closeOnDocumentClick || !this.state.isDisplayed() || $element.is(this.current.positionTarget) || $.contains(this.current.positionTarget[0], $element[0]) || $content.is($element) || $.contains($content[0], $element[0]) || (this.$lastActive = null, 
            this.hide());
        },
        _hidden: function() {
            this.current = undefined;
            try {
                delete this.current;
            } catch (e) {}
        },
        position: function(settings) {
            var $content = this.content(), position = extend({
                of: settings.positionTarget
            }, positions[settings.initPosition]), offset = settings.offset.split(" "), my = position.my.split(" "), offsetLeft = offset[0] ? /-/.test(offset[0]) ? offset[0] : "+" + offset[0] : "", offsetTop = offset[1] ? /-/.test(offset[1]) ? offset[1] : "+" + offset[1] : offsetLeft, myLeft = my[0] + offsetLeft, myTop = (my[1] || my[0]) + offsetTop;
            if (position.my = myLeft + " " + myTop, $content.position(position), "none" !== position.collision) {
                var $window = $(window), contentOffset = $content.offset(), contentPositionOffset = $content.position(), scrollTop = $window.scrollTop(), scrollLeft = $window.scrollLeft(), newTop = Math.max(contentOffset.top - Math.max(contentOffset.top + $content.height() - $window.height() - scrollTop, 0), scrollTop), newLeft = Math.max(contentOffset.left - Math.max(contentOffset.left + $content.width() - $window.width() - scrollLeft, 0), scrollLeft);
                newTop !== contentOffset.top && $content.css("top", newTop - contentOffset.top + contentPositionOffset.top), 
                newLeft !== contentOffset.left && $content.css("left", newLeft - contentOffset.left + contentPositionOffset.left);
            }
        },
        show: function(settings) {
            var current = this.current = extend(!0, {}, this.options, settings || {});
            this.$lastActive = document.activeElement && $(document.activeElement), this.state.isDisplayed() ? this.focus(current) : (this._super.apply(this, arguments), 
            this._shown(current));
        },
        _shown: function(current) {
            this.content().css({
                zIndex: this.zIndex(current),
                zoom: 1
            }).width(current.width), this.adjustHeight(current), this.position(current), this.focus(current);
        },
        zIndex: function(settings) {
            return settings.zIndex || topZ();
        }
    });
}), define("jpmc/template/overlay", [ "handlebars" ], function(Handlebars) {
    return Handlebars.template(function(Handlebars, depth0, helpers, partials, data) {
        return this.compilerInfo = [ 4, ">= 1.0.0" ], helpers = this.merge(helpers, Handlebars.helpers), 
        data = data || {}, '<div id="chaseui-overlay"></div>';
    });
}), define("jpmc/ui/overlay", [ "jpmc/$", "jpmc/has/detect/native", "jpmc/ui/floater", "jpmc/template/overlay" ], function($, has, Floater, OverlayView) {
    var Overlay, $document = $(document);
    return Overlay = Floater({
        defaults: {
            initPosition: "viewportcenter",
            lazy: !1,
            width: "100%",
            focus: !1
        }
    }, {
        className: "jpmc-overlay",
        view: OverlayView,
        init: function() {
            this._super.apply(this, arguments), has("quirks") && (this.handler["{window} resize"] = this.onResize);
        },
        inserted: function($content) {
            has("quirks") && ($content.css({
                position: "absolute"
            }), this.resize());
        },
        onResize: function() {
            this.resize();
        },
        position: function() {
            this.content().css({
                top: 0,
                left: 0
            });
        },
        resize: function() {
            var $content = this.content();
            $content && $content.css({
                height: $document.height(),
                width: $document.width()
            });
        }
    });
}), define("conf/ui/floater/modal/size", {
    "extra-small": {
        classname: "chaseui-modal-widthextrasmall"
    },
    small: {
        classname: "chaseui-modal-widthsmall"
    },
    "extra-medium": {
        classname: "chaseui-modal-widthextramedium"
    },
    medium: {
        classname: "chaseui-modal-widthmedium"
    },
    large: {
        classname: "chaseui-modal-widthlarge"
    },
    "extra-large": {
        classname: "chaseui-modal-widthextralarge"
    },
    "double-extra-large": {
        classname: "chaseui-modal-widthdoubleextralarge"
    }
}), define("conf/ui/floater/modal/style", {
    styles: [ "div.chaseui-jpmc-modal {border:5px solid #90A0A9;position:absolute;display:none;}", "div.chaseui-jpmc-modal div.chaseui-modalbody {position:relative;background-color:#FFFFFF;padding:0;margin:0;}", "div.chaseui-jpmc-modal div.chaseui-modalheader {height:auto;background: -moz-linear-gradient(top, #ffffff 0%, #f7f7f7 32%, #ccd8de 100%);background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ffffff), color-stop(32%,#f7f7f7), color-stop(100%,#ccd8de));background: -webkit-linear-gradient(top, #ffffff 0%,#f7f7f7 32%,#ccd8de 100%);background: -o-linear-gradient(top, #ffffff 0%,#f7f7f7 32%,#ccd8de 100%);background: -ms-linear-gradient(top, #ffffff 0%,#f7f7f7 32%,#ccd8de 100%);background: linear-gradient(to bottom, #ffffff 0%,#f7f7f7 32%,#ccd8de 100%);filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#ccd8de',GradientType=0 );*overflow:hidden;}", "div.chaseui-jpmc-modal div.chaseui-modalheader h1{line-height:0;padding:30px 0 30px 20px;margin:0;color:#43444E;font-size:22px;font-weight:bold;text-align:left}", "div.chaseui-jpmc-modal div.chaseui-modalheader a.chaseui-modalclose {position:absolute;top:0;right:0;overflow:hidden;color:#808086;margin:9px;line-height:12px;}", "div.chaseui-jpmc-modal div.chaseui-modalheader a.chaseui-modalclose span {padding:0; font-family:verdana;font-size:20px;}", "div.chaseui-jpmc-modal div.chaseui-modalheader a.chaseui-modalclose, a.chaseui-jpmc-modalclose:active, a.chaseui-jpmc-modalclose:hover {text-decoration:none;}", "div.chaseui-jpmc-modal div.chaseui-modalheader a.chaseui-modalclose:hover{color:#004566;}", "span.chaseutil-hidevisual {position:absolute;width:10px;height:1px;overflow:hidden;left:-99999px;}", "div.chaseui-jpmc-modal.chaseui-modal-widthdoubleextralarge{width:833px;}", "div.chaseui-jpmc-modal.chaseui-modal-widthextralarge{width:690px;}", "div.chaseui-jpmc-modal.chaseui-modal-widthlarge{width:630px;}", "div.chaseui-jpmc-modal.chaseui-modal-widthmedium{width:530px;}", "div.chaseui-jpmc-modal.chaseui-modal-widthextramedium{width:430px;}", "div.chaseui-jpmc-modal.chaseui-modal-widthsmall{width:330px;}", "div.chaseui-jpmc-modal.chaseui-modal-widthextrasmall{width:230px;}" ]
}), define("jqueryresize", [ "jquery" ], function(jQuery) {
    !function($, window, undefined) {
        "$:nomunge";
        function loopy() {
            timeout_id = window[str_setTimeout](function() {
                elems.each(function() {
                    var elem = $(this), width = elem.width(), height = elem.height(), data = $.data(this, str_data);
                    (width !== data.w || height !== data.h) && elem.trigger(str_resize, [ data.w = width, data.h = height ]);
                }), loopy();
            }, jq_resize[str_delay]);
        }
        var timeout_id, elems = $([]), jq_resize = $.resize = $.extend($.resize, {}), str_setTimeout = "setTimeout", str_resize = "resize", str_data = str_resize + "-special-event", str_delay = "delay", str_throttle = "throttleWindow";
        jq_resize[str_delay] = 250, jq_resize[str_throttle] = !0, $.event.special[str_resize] = {
            setup: function() {
                if (!jq_resize[str_throttle] && this[str_setTimeout]) return !1;
                var elem = $(this);
                elems = elems.add(elem), $.data(this, str_data, {
                    w: elem.width(),
                    h: elem.height()
                }), 1 === elems.length && loopy();
            },
            teardown: function() {
                if (!jq_resize[str_throttle] && this[str_setTimeout]) return !1;
                var elem = $(this);
                elems = elems.not(elem), elem.removeData(str_data), elems.length || clearTimeout(timeout_id);
            },
            add: function(handleObj) {
                function new_handler(e, w, h) {
                    var elem = $(this), data = $.data(this, str_data);
                    data.w = w !== undefined ? w : elem.width(), data.h = h !== undefined ? h : elem.height(), 
                    old_handler.apply(this, arguments);
                }
                if (!jq_resize[str_throttle] && this[str_setTimeout]) return !1;
                var old_handler;
                return $.isFunction(handleObj) ? (old_handler = handleObj, new_handler) : (old_handler = handleObj.handler, 
                void (handleObj.handler = new_handler));
            }
        };
    }(jQuery, this);
}), define("jpmc/ui/modal", [ "jpmc/$", "jpmc/template/modal", "jpmc/ui/floater", "jpmc/ui/overlay", "conf/ui/floater/modal/size", "conf/ui/floater/modal/style", "jqueryresize" ], function($, ModalView, Floater, Overlay, sizes, modalStyle) {
    var Modal, $window = $(window), document = window.document, head = document.head || document.getElementsByTagName("head")[0] || document.documentElement, $document = $(document);
    return $document.data("modal-styles-added") || ($(head).append('<style type="text/css">' + modalStyle.styles.join(" ") + "</style>"), 
    $document.data("modal-styles-added", !0)), Modal = Floater({
        defaults: {
            closeSelector: ".chasejs-modalclose",
            focus: !0,
            initPosition: "viewportcenter",
            maxHeight: 592,
            preventTabOut: !0,
            size: ""
        }
    }, {
        className: "jpmc-modal",
        view: ModalView,
        handler: {
            _super: !0,
            "{window} resize": "onWindowResizeAndScroll",
            "{window} scroll": "onWindowResizeAndScroll"
        },
        targets: {
            body: "div.chaseui-modalbody",
            title: "div.chaseui-modalheader>h1"
        },
        init: function() {
            this.overlay = new Overlay(), this._super.apply(this, arguments);
        },
        destroy: function() {
            this.overlay.destroy(), this._super.apply(this, arguments);
        },
        draw: function(data) {
            this._super.call(this, data), $.isReady && $.contains(document.body, this.content()[0]) && this.overlay.insertTo(document.body);
        },
        _shown: function(current) {
            this.sizeClassName = sizes[current.size] ? sizes[current.size].classname : "", this.sizeClassName && this.content().addClass(this.sizeClassName), 
            this.overlay.show();
            var that = this;
            this.content().bind("resize", function() {
                that.position();
            }), this._super.apply(this, arguments);
        },
        hide: function() {
            this.overlay.hide(), this._super.apply(this, arguments), this.sizeClassName && this.content().removeClass(this.sizeClassName), 
            this.content().unbind("resize");
        },
        insertTo: function() {
            this.overlay.insertTo(document.body), this._super.apply(this, arguments);
        },
        onWindowResizeAndScroll: function() {
            this.position();
        },
        position: function() {
            var viewPortWidth = window.innerWidth || document.documentElement.offsetWidth, viewPortHeight = window.innerHeight || document.documentElement.offsetHeight, scrollLeft = $window.scrollLeft(), scrollTop = $window.scrollTop(), $content = this.content();
            $content.css({
                top: Math.max(scrollTop + (viewPortHeight - $content.outerHeight()) / 2, scrollTop),
                left: Math.max(scrollLeft + (viewPortWidth - $content.outerWidth()) / 2, scrollLeft)
            });
        },
        remove: function() {
            this.overlay.remove(), this._super.apply(this, arguments);
        }
    });
}), define("jpmc/event/handler/toggle", [ "jpmc/$", "jpmc/event/handler", "jpmc/util/lang/isFunction", "jquerypp/event/hover" ], function($, Handler, isFunction, $hover, undefined) {
    function Action(action, pattern) {
        this.action = action, this.pattern = pattern;
    }
    var Toggle;
    return Action.prototype = {
        match: function(action) {
            return this.pattern.test(action.action);
        }
    }, Action.constructor = Action.prototype.constructor = Action, Action.BOTH = new Action("both", /click|hover/), 
    Action.CLICK = new Action("click", /click/), Action.HOVER = new Action("hover", /hover/), 
    Toggle = Handler({
        defaults: {
            disableHoverOnTargetClick: !1,
            displayOn: Action.BOTH,
            targetDelay: 0,
            targetDistance: 10,
            targetLeave: 400,
            toggleDelay: 100,
            toggleDistance: 10,
            toggleLeave: 100,
            closeOnToggleClick: !1,
            target: undefined
        }
    }, {
        setup: function(element, options) {
            options = options || {};
            var $element = $(element);
            if (options.target) {
                var target = options.target;
                if (isFunction(target.constructor) && isFunction(target.content)) options._target = target, 
                options.target = target.content(), this.hideTarget = function() {
                    target.hide(), this.targetDisplayed = !1;
                }, this.showTarget = function() {
                    target.show({
                        positionTarget: $element,
                        focus: !this.hoverTriggered
                    }), this.targetDisplayed = !0;
                }; else {
                    var $target = $(target);
                    this.hideTarget = function() {
                        $target.hide(), this.targetDisplayed = !1;
                    }, this.showTarget = function() {
                        $target.show(), this.targetDisplayed = !0;
                    };
                }
            }
            this._super($element, options);
        },
        init: function() {
            this.targetDisplayed = !1, this.targetHovered = !1, this.hoverTriggered = !1, this.hideOnTargetLeave = !0;
        },
        click: function() {
            this.displayOn().match(Action.CLICK) && (this.options.closeOnToggleClick && this.targetDisplayed && !this.hoverTriggered ? this.hideTarget() : (this.hoverTriggered = !1, 
            this.showTarget()));
        },
        hoverinit: function($toggle, event, hover) {
            this.displayOn().match(Action.HOVER) && (hover.delay(this.options.toggleDelay), 
            hover.leave(this.options.toggleLeave));
        },
        hoverenter: function() {
            this.displayOn().match(Action.HOVER) && ($(this.options.target).is(":visible") || (this.hoverTriggered = !0, 
            this.showTarget()));
        },
        hoverleave: function() {
            this.displayOn().match(Action.HOVER) && this.hoverTriggered && !this.targetHovered && this.hideTarget();
        },
        "{target} click": function() {
            this.hideOnTargetLeave = !this.options.disableHoverOnTargetClick, this.hoverTriggered = !1;
        },
        "{target} hoverenter": function() {
            this.hideOnTargetLeave = !0, this.targetHovered = !0;
        },
        "{target} hoverinit": function($target, event, hover) {
            hover.delay(this.options.targetDelay), hover.leave(this.options.targetLeave);
        },
        "{target} hoverleave": function() {
            this.hideOnTargetLeave && this.hoverTriggered && (this.hideTarget(), this.hideOnTargetLeave = undefined), 
            this.targetHovered = !1;
        },
        displayOn: function(action) {
            return action !== undefined ? this.options.displayOn = action : this.options.displayOn;
        }
    }), Toggle.Action = Action, Toggle;
}), define("jpmc/template/menu", [ "handlebars" ], function(Handlebars) {
    return Handlebars.template(function(Handlebars, depth0, helpers, partials, data) {
        function program1(depth0, data) {
            var stack1, stack2, buffer = "";
            return buffer += '\r\n<li id="', (stack1 = helpers.level) ? stack1 = stack1.call(depth0, {
                hash: {},
                data: data
            }) : (stack1 = depth0.level, stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1), 
            buffer += escapeExpression(stack1) + "-menuitem-" + escapeExpression((stack1 = data, 
            stack1 = null == stack1 || stack1 === !1 ? stack1 : stack1.index, typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + '" class="jpmc-menuitem">\r\n	<a id="', 
            (stack2 = helpers.level) ? stack2 = stack2.call(depth0, {
                hash: {},
                data: data
            }) : (stack2 = depth0.level, stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2), 
            buffer += escapeExpression(stack2) + "-menuitem-" + escapeExpression((stack1 = data, 
            stack1 = null == stack1 || stack1 === !1 ? stack1 : stack1.index, typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + 'Link" class="chaseui-menuitem-trigger" href="#">', 
            (stack2 = helpers.name) ? stack2 = stack2.call(depth0, {
                hash: {},
                data: data
            }) : (stack2 = depth0.name, stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2), 
            buffer += escapeExpression(stack2) + "</a>\r\n</li>\r\n";
        }
        this.compilerInfo = [ 4, ">= 1.0.0" ], helpers = this.merge(helpers, Handlebars.helpers), 
        data = data || {};
        var stack1, buffer = "", functionType = "function", escapeExpression = this.escapeExpression, self = this;
        return buffer += "<ul>\r\n", stack1 = helpers.each.call(depth0, depth0.items, {
            hash: {},
            inverse: self.noop,
            fn: self.program(1, program1, data),
            data: data
        }), (stack1 || 0 === stack1) && (buffer += stack1), buffer += "\r\n</ul>";
    });
}), define("jpmc/template/flyout", [ "handlebars" ], function(Handlebars) {
    return Handlebars.template(function(Handlebars, depth0, helpers, partials, data) {
        return this.compilerInfo = [ 4, ">= 1.0.0" ], helpers = this.merge(helpers, Handlebars.helpers), 
        data = data || {}, '<div class="chaseui-flyout">\r\n	<div class="chaseui-flyoutarrow"></div>\r\n	<div class="chaseui-flyoutbody">\r\n		<span class="chaseutil-hidevisual">Begin Overlay</span>\r\n			<a class="chaseui-flyoutclose chasejs-flyoutclose" href="#"><span class="chaseutil-hidevisual">Close Overlay</span></a>\r\n			<div class="chasejs-flyout-content"></div>\r\n		<span class="chaseutil-hidevisual">End Overlay</span>\r\n	</div>\r\n</div>';
    });
}), define("jpmc/ui/flyout", [ "jpmc/$", "jpmc/template/flyout", "jpmc/ui/floater", "jpmc/ui/overlay", "jpmc/util/dom/topZ", "jpmc/util/object/extend" ], function($, FlyoutView, Floater, Overlay, topZ, extend, undefined) {
    var Flyout, FlyoutOverlay, $window = $(window), document = window.document, horizontalRegex = /^(left|right)-?/, verticalRegex = /^(top|bottom)-?/;
    return FlyoutOverlay = Overlay({
        handler: {
            _super: !0,
            click: "onClick"
        },
        onClick: function() {
            this.hide();
        }
    }), Flyout = Floater({
        defaults: {
            arrowOffset: undefined,
            arrowSelector: "div.chaseui-flyoutarrow",
            clickAndStick: !1,
            closeOnDocumentClick: !0,
            closeSelector: ".chasejs-flyoutclose",
            focus: !0,
            initPosition: "right-center",
            positionTarget: undefined
        }
    }, {
        className: "jpmc-flyout",
        view: FlyoutView,
        targets: {
            body: "div.chasejs-flyout-content"
        },
        _addArrow: function($flyout, options) {
            var $flyoutArrow = $flyout.children(options.arrowSelector);
            if ($flyoutArrow.length) {
                var arrowDirection = "", $positionTarget = options.positionTarget, targetOffset = $positionTarget.offset(), flyoutOffset = $flyout.offset();
                this._removeArrow($flyout), horizontalRegex.test(options.initPosition) ? arrowDirection = targetOffset && flyoutOffset.left > targetOffset.left ? "left" : "right" : verticalRegex.test(options.initPosition) && (arrowDirection = targetOffset && flyoutOffset.top > targetOffset.top ? "top" : "bottom"), 
                this._arrowClass = arrowDirection, $flyout.addClass(this._arrowClass), horizontalRegex.test(arrowDirection) ? $flyoutArrow.css("top", this._getArrowOffsetTop(targetOffset.top, $positionTarget.height(), flyoutOffset.top, $flyout.height(), $flyoutArrow.height(), options)) : verticalRegex.test(arrowDirection) && $flyoutArrow.css("left", this._getArrowOffsetLeft(targetOffset.left, $positionTarget.width(), flyoutOffset.left, $flyout.width(), $flyoutArrow.width(), options));
            }
            return $flyout;
        },
        _getArrowOffsetTop: function(targetTop, targetHeight, flyoutTop, flyoutHeight, arrowHeight, options) {
            var maxTop, viewPortHeight = window.innerHeight || document.documentElement.offsetHeight, minTop = Math.max(targetTop, flyoutTop);
            return options.arrowOffset === undefined ? (maxTop = Math.min(Math.min(targetTop + targetHeight, flyoutTop + flyoutHeight), $window.scrollTop() + viewPortHeight), 
            Math.max(targetTop - flyoutTop, 0) + .5 * (maxTop - minTop - arrowHeight)) : (maxTop = Math.min(Math.min(targetTop + targetHeight, flyoutTop + flyoutHeight) + .5 * arrowHeight, $window.scrollTop() + viewPortHeight), 
            Math.max(Math.max(Math.min(targetTop + options.arrowOffset + .5 * arrowHeight, maxTop) - flyoutTop, 0) - arrowHeight, 0));
        },
        _getArrowOffsetLeft: function(targetLeft, targetWidth, flyoutLeft, flyoutWidth, arrowWidth, options) {
            var maxLeft, viewPortWidth = window.innerWidth || document.documentElement.offsetWidth, minLeft = Math.max(targetLeft, flyoutLeft);
            return options.arrowOffset === undefined ? (maxLeft = Math.min(Math.min(targetLeft + targetWidth, flyoutLeft + flyoutWidth), $window.scrollLeft() + viewPortWidth), 
            Math.max(targetLeft - flyoutLeft, 0) + .5 * (maxLeft - minLeft - arrowWidth)) : (maxLeft = Math.min(Math.min(targetLeft + targetWidth, flyoutLeft + flyoutWidth) + .5 * arrowWidth, $window.scrollLeft() + viewPortWidth), 
            Math.max(Math.max(Math.min(targetLeft + options.arrowOffset + .5 * arrowWidth, maxLeft) - flyoutLeft, 0) - arrowWidth, 0));
        },
        _shown: function(current) {
            current.clickAndStick && (this.overlay || (this.overlay = new FlyoutOverlay()), 
            this.overlay.insertTo(document.body)), this._super.apply(this, arguments), this._addArrow(this.content(), current);
        },
        _removeArrow: function($content) {
            this._arrowClass && $content.removeClass(this._arrowClass);
        }
    }), Flyout.Overlay = FlyoutOverlay, Flyout;
}), define("jpmc/util/string/trim", [ "require", "jpmc/has/detect/string", "mout/string/trim" ], function(require) {
    var trim, has = require("jpmc/has/detect/string");
    return trim = has("string-trim") ? function(string) {
        return String.prototype.trim.call(string);
    } : require("mout/string/trim");
}), define("jpmc/ui/menu", [ "jpmc/$", "jpmc/event/handler/toggle", "jpmc/template/menu", "jpmc/ui/flyout", "jpmc/ui/mixin/handler", "jpmc/ui/widget", "jpmc/util/object/extend", "jpmc/util/string/trim", "jqueryui/core" ], function($, Toggle, MenuView, Flyout, HandlerMixin, Widget, extend, trim, $core, undefined) {
    var Menu, MenuFlyout, TAB_KEY_CODE = 9, ESC_KEY_CODE = 27, focusableRegex = /input|\a\b|button|textarea/i, registry = {};
    return MenuFlyout = Flyout({
        defaults: {
            zIndex: 1e3
        }
    }, {
        className: "jpmc-menuflyout chaseui-sub-menu",
        hide: function() {
            for (var index in registry) if (!index.hasOwnProperty(registry) && index != this.uuid) {
                var flyoutMenu = registry[index];
                flyoutMenu.state.isDisplayed() && $.contains(this.content()[0], flyoutMenu.content()[0]) && flyoutMenu.hide();
            }
            this.content().siblings("a").removeClass("chaseui-menu-displayed"), this._super.apply(this, arguments);
        },
        show: function(settings) {
            var $content = this.content(), $parent = $content.parent("li"), currentFlyoutMenuTrigger = this.trigger;
            for (var index in registry) if (!index.hasOwnProperty(registry) && index != this.uuid) {
                var flyoutMenu = registry[index], flyoutMenuTrigger = flyoutMenu.trigger;
                if (flyoutMenu.state.isDisplayed()) {
                    if (currentFlyoutMenuTrigger.hoverTriggered && !flyoutMenuTrigger.hoverTriggered && $parent.parent().is(flyoutMenu.content().parent().parent())) return void (this.showAborted = !0);
                    $.contains(flyoutMenu.content()[0], $content[0]) || flyoutMenu.hide();
                }
            }
            settings = settings || {}, settings.width = Math.max($parent.outerWidth() - $content.outerWidth() + $content.width(), $content.width()), 
            $content.siblings("a").addClass("chaseui-menu-displayed"), this.showAborted && this.state.isDisplayed() && this.state.toHidden(), 
            this._super.call(this, settings), this.showAborted = !1;
        }
    }), Menu = Widget({
        defaults: {
            itemSelector: "li.chasejs-item",
            flyoutOffset: undefined,
            flyoutPosition: "bottom-left-none",
            menuText: "",
            accessibleOpenText: "Opens menu",
            menuSelector: "div.chaseui-sub-menu",
            addAccessibleText: !1,
            accessibleTextClass: "chaseutil-hidevisual"
        }
    }, {
        className: "jpmc-menu",
        view: MenuView,
        handler: {},
        init: function(options) {
            this.pipeline.add("register", function($content) {
                return this.register($content), $content;
            }), this.handler[options.menuSelector + " keydown"] = "onKeyDown";
        },
        initialized: function(options) {
            HandlerMixin.call(this, options);
        },
        _addAccessibleText: function($item, $link, hasFlyout, isFirst, isLast) {
            var options = this.options;
            if (options.addAccessibleText) {
                var $accessibleTextContainer = $('<span class="' + options.accessibleTextClass + '"/>'), accessibileText = "";
                isFirst && $item.prepend($accessibleTextContainer.html(" Begin " + options.menuText + ".")), 
                accessibileText = $item.hasClass("selected") ? " Current Section," : "", hasFlyout && (accessibileText += " " + options.accessibleOpenText), 
                isFirst ? accessibileText = accessibileText + ". First " + options.menuText + " item" : isLast && (accessibileText = accessibileText + ". Last " + options.menuText + "item"), 
                accessibileText && $accessibleTextContainer.html(accessibileText).appendTo($link.length ? $link : $item.children(":not(." + options.accessibleTextClass + ")").first());
            }
        },
        onKeyDown: function($menu, event) {
            if (event.keyCode === ESC_KEY_CODE || event.keyCode === TAB_KEY_CODE) {
                event.stopPropagation(), event.preventDefault();
                var $target = $(event.target), uuid = $menu.length && $menu.attr("data-widget-id"), flyout = uuid && registry[uuid];
                if (flyout) if (event.keyCode === TAB_KEY_CODE) {
                    var $focusables = $menu.find(":focusable"), currentIndex = $focusables.index($target), $elementToFocus = event.shiftKey ? $focusables.filter(function(index) {
                        return currentIndex > index && this.tabIndex >= 0;
                    }).last() : $focusables.filter(function(index) {
                        return index > currentIndex && this.tabIndex >= 0;
                    }).first();
                    $elementToFocus.length ? $elementToFocus.focus() : flyout.hide();
                } else flyout.hide();
            }
        },
        register: function($menu) {
            var that = this, options = this.options, $items = $menu.children(options.itemSelector), length = $items.length;
            $items.each(function(index) {
                var $item = $(this), $link = $item.children("a").first(), $flyout = $link.nextAll(options.menuSelector).first(), contentUrl = $link.attr("data-chase-menu-url"), hasFlyout = $flyout.length, isFirst = !index, isLast = index === length - 1;
                if (that._addAccessibleText($item, $link, hasFlyout, isFirst, isLast), hasFlyout) {
                    var flyout = new MenuFlyout({
                        initPosition: options.flyoutPosition,
                        offset: options.flyoutOffset
                    });
                    registry[flyout.uuid] = flyout, contentUrl && flyout.insert({
                        "ul:first": contentUrl
                    }), flyout.render($flyout), flyout.trigger = new Toggle($link, {
                        closeOnToggleClick: !0,
                        disableHoverOnTargetClick: !0,
                        target: flyout
                    }), flyout.content().children("ul:first").children(options.itemSelector + ":first").children("a:first").length || that._setTabIndex($flyout);
                }
            });
        },
        _setTabIndex: function($menu) {
            function setTabIndex($content) {
                !completed && $content.contents().each(function() {
                    var $this = $(this);
                    this.disabled || 8 == this.nodeType || (focusableRegex.test(this.nodeName) || $this.attr("tabindex") ? completed = !0 : "IMG" === this.nodeName && $this.attr("alt") ? ($this.attr("tabindex", "-1"), 
                    completed = !0) : 3 === this.nodeType ? trim($this.text()) && ($this.parent().attr("tabindex", "-1"), 
                    completed = !0) : $this.hasClass(self.options.accessibleTextClass) || setTabIndex($this));
                });
            }
            var self = this, completed = !1;
            setTabIndex($menu);
        }
    }), Menu.Flyout = MenuFlyout, Menu;
}), define("jpmc/ui/navigation", [ "jpmc/$", "jpmc/ui/menu", "jpmc/ui/widget", "jpmc/util/object/extend", "jpmc/util/string/trim", "jpmc/has/detect/dom" ], function($, Menu, Widget, extend, trim, has) {
    var Navigation;
    return Navigation = Widget({
        className: "jpmc-navigation",
        init: function() {
            this.registry = {}, this.pipeline.add("register", function($content) {
                return this.register($content), $content;
            });
        },
        register: function($navigation) {
            var that = this, menuDefaults = {
                lazy: this.options.lazy
            }, spacesRegex = /\s+/;
            $navigation.find("ul").each(function(index) {
                var menu, menuSettings, $this = $(this);
                if (index) {
                    var menuText = trim($this.parent("div").prev("a").contents().filter(function() {
                        return 3 === this.nodeType;
                    }).text()).replace(spacesRegex, " ") + " menu";
                    menuSettings = extend({}, menuDefaults, {
                        flyoutPosition: has("quirks") && has("browser-ie-7") ? "right-top-none-quirks" : "right-top-none",
                        flyoutOffset: "-1 -5",
                        accessibleOpenText: "Opens sub-menu",
                        menuText: menuText
                    });
                } else menuSettings = menuDefaults;
                menu = new Menu(menuSettings), that.registry[menu.uuid] = menu, menu.render(this);
            });
        }
    }), Navigation.Menu = Menu, Navigation;
}), define("jqueryui/widget", [ "jquery" ], function(jQuery) {
    return function($, undefined) {
        var uuid = 0, slice = Array.prototype.slice, _cleanData = $.cleanData;
        $.cleanData = function(elems) {
            for (var elem, i = 0; null != (elem = elems[i]); i++) try {
                $(elem).triggerHandler("remove");
            } catch (e) {}
            _cleanData(elems);
        }, $.widget = function(name, base, prototype) {
            var fullName, existingConstructor, constructor, basePrototype, proxiedPrototype = {}, namespace = name.split(".")[0];
            name = name.split(".")[1], fullName = namespace + "-" + name, prototype || (prototype = base, 
            base = $.Widget), $.expr[":"][fullName.toLowerCase()] = function(elem) {
                return !!$.data(elem, fullName);
            }, $[namespace] = $[namespace] || {}, existingConstructor = $[namespace][name], 
            constructor = $[namespace][name] = function(options, element) {
                return this._createWidget ? void (arguments.length && this._createWidget(options, element)) : new constructor(options, element);
            }, $.extend(constructor, existingConstructor, {
                version: prototype.version,
                _proto: $.extend({}, prototype),
                _childConstructors: []
            }), basePrototype = new base(), basePrototype.options = $.widget.extend({}, basePrototype.options), 
            $.each(prototype, function(prop, value) {
                return $.isFunction(value) ? void (proxiedPrototype[prop] = function() {
                    var _super = function() {
                        return base.prototype[prop].apply(this, arguments);
                    }, _superApply = function(args) {
                        return base.prototype[prop].apply(this, args);
                    };
                    return function() {
                        var returnValue, __super = this._super, __superApply = this._superApply;
                        return this._super = _super, this._superApply = _superApply, returnValue = value.apply(this, arguments), 
                        this._super = __super, this._superApply = __superApply, returnValue;
                    };
                }()) : void (proxiedPrototype[prop] = value);
            }), constructor.prototype = $.widget.extend(basePrototype, {
                widgetEventPrefix: existingConstructor ? basePrototype.widgetEventPrefix : name
            }, proxiedPrototype, {
                constructor: constructor,
                namespace: namespace,
                widgetName: name,
                widgetFullName: fullName
            }), existingConstructor ? ($.each(existingConstructor._childConstructors, function(i, child) {
                var childPrototype = child.prototype;
                $.widget(childPrototype.namespace + "." + childPrototype.widgetName, constructor, child._proto);
            }), delete existingConstructor._childConstructors) : base._childConstructors.push(constructor), 
            $.widget.bridge(name, constructor);
        }, $.widget.extend = function(target) {
            for (var key, value, input = slice.call(arguments, 1), inputIndex = 0, inputLength = input.length; inputLength > inputIndex; inputIndex++) for (key in input[inputIndex]) value = input[inputIndex][key], 
            input[inputIndex].hasOwnProperty(key) && value !== undefined && (target[key] = $.isPlainObject(value) ? $.isPlainObject(target[key]) ? $.widget.extend({}, target[key], value) : $.widget.extend({}, value) : value);
            return target;
        }, $.widget.bridge = function(name, object) {
            var fullName = object.prototype.widgetFullName || name;
            $.fn[name] = function(options) {
                var isMethodCall = "string" == typeof options, args = slice.call(arguments, 1), returnValue = this;
                return options = !isMethodCall && args.length ? $.widget.extend.apply(null, [ options ].concat(args)) : options, 
                this.each(isMethodCall ? function() {
                    var methodValue, instance = $.data(this, fullName);
                    return instance ? $.isFunction(instance[options]) && "_" !== options.charAt(0) ? (methodValue = instance[options].apply(instance, args), 
                    methodValue !== instance && methodValue !== undefined ? (returnValue = methodValue && methodValue.jquery ? returnValue.pushStack(methodValue.get()) : methodValue, 
                    !1) : void 0) : $.error("no such method '" + options + "' for " + name + " widget instance") : $.error("cannot call methods on " + name + " prior to initialization; attempted to call method '" + options + "'");
                } : function() {
                    var instance = $.data(this, fullName);
                    instance ? instance.option(options || {})._init() : $.data(this, fullName, new object(options, this));
                }), returnValue;
            };
        }, $.Widget = function() {}, $.Widget._childConstructors = [], $.Widget.prototype = {
            widgetName: "widget",
            widgetEventPrefix: "",
            defaultElement: "<div>",
            options: {
                disabled: !1,
                create: null
            },
            _createWidget: function(options, element) {
                element = $(element || this.defaultElement || this)[0], this.element = $(element), 
                this.uuid = uuid++, this.eventNamespace = "." + this.widgetName + this.uuid, this.options = $.widget.extend({}, this.options, this._getCreateOptions(), options), 
                this.bindings = $(), this.hoverable = $(), this.focusable = $(), element !== this && ($.data(element, this.widgetFullName, this), 
                this._on(!0, this.element, {
                    remove: function(event) {
                        event.target === element && this.destroy();
                    }
                }), this.document = $(element.style ? element.ownerDocument : element.document || element), 
                this.window = $(this.document[0].defaultView || this.document[0].parentWindow)), 
                this._create(), this._trigger("create", null, this._getCreateEventData()), this._init();
            },
            _getCreateOptions: $.noop,
            _getCreateEventData: $.noop,
            _create: $.noop,
            _init: $.noop,
            destroy: function() {
                this._destroy(), this.element.unbind(this.eventNamespace).removeData(this.widgetName).removeData(this.widgetFullName).removeData($.camelCase(this.widgetFullName)), 
                this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName + "-disabled ui-state-disabled"), 
                this.bindings.unbind(this.eventNamespace), this.hoverable.removeClass("ui-state-hover"), 
                this.focusable.removeClass("ui-state-focus");
            },
            _destroy: $.noop,
            widget: function() {
                return this.element;
            },
            option: function(key, value) {
                var parts, curOption, i, options = key;
                if (0 === arguments.length) return $.widget.extend({}, this.options);
                if ("string" == typeof key) if (options = {}, parts = key.split("."), key = parts.shift(), 
                parts.length) {
                    for (curOption = options[key] = $.widget.extend({}, this.options[key]), i = 0; i < parts.length - 1; i++) curOption[parts[i]] = curOption[parts[i]] || {}, 
                    curOption = curOption[parts[i]];
                    if (key = parts.pop(), value === undefined) return curOption[key] === undefined ? null : curOption[key];
                    curOption[key] = value;
                } else {
                    if (value === undefined) return this.options[key] === undefined ? null : this.options[key];
                    options[key] = value;
                }
                return this._setOptions(options), this;
            },
            _setOptions: function(options) {
                var key;
                for (key in options) this._setOption(key, options[key]);
                return this;
            },
            _setOption: function(key, value) {
                return this.options[key] = value, "disabled" === key && (this.widget().toggleClass(this.widgetFullName + "-disabled ui-state-disabled", !!value).attr("aria-disabled", value), 
                this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus")), 
                this;
            },
            enable: function() {
                return this._setOption("disabled", !1);
            },
            disable: function() {
                return this._setOption("disabled", !0);
            },
            _on: function(suppressDisabledCheck, element, handlers) {
                var delegateElement, instance = this;
                "boolean" != typeof suppressDisabledCheck && (handlers = element, element = suppressDisabledCheck, 
                suppressDisabledCheck = !1), handlers ? (element = delegateElement = $(element), 
                this.bindings = this.bindings.add(element)) : (handlers = element, element = this.element, 
                delegateElement = this.widget()), $.each(handlers, function(event, handler) {
                    function handlerProxy() {
                        return suppressDisabledCheck || instance.options.disabled !== !0 && !$(this).hasClass("ui-state-disabled") ? ("string" == typeof handler ? instance[handler] : handler).apply(instance, arguments) : void 0;
                    }
                    "string" != typeof handler && (handlerProxy.guid = handler.guid = handler.guid || handlerProxy.guid || $.guid++);
                    var match = event.match(/^(\w+)\s*(.*)$/), eventName = match[1] + instance.eventNamespace, selector = match[2];
                    selector ? delegateElement.delegate(selector, eventName, handlerProxy) : element.bind(eventName, handlerProxy);
                });
            },
            _off: function(element, eventName) {
                eventName = (eventName || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace, 
                element.unbind(eventName).undelegate(eventName);
            },
            _delay: function(handler, delay) {
                function handlerProxy() {
                    return ("string" == typeof handler ? instance[handler] : handler).apply(instance, arguments);
                }
                var instance = this;
                return setTimeout(handlerProxy, delay || 0);
            },
            _hoverable: function(element) {
                this.hoverable = this.hoverable.add(element), this._on(element, {
                    mouseenter: function(event) {
                        $(event.currentTarget).addClass("ui-state-hover");
                    },
                    mouseleave: function(event) {
                        $(event.currentTarget).removeClass("ui-state-hover");
                    }
                });
            },
            _focusable: function(element) {
                this.focusable = this.focusable.add(element), this._on(element, {
                    focusin: function(event) {
                        $(event.currentTarget).addClass("ui-state-focus");
                    },
                    focusout: function(event) {
                        $(event.currentTarget).removeClass("ui-state-focus");
                    }
                });
            },
            _trigger: function(type, event, data) {
                var prop, orig, callback = this.options[type];
                if (data = data || {}, event = $.Event(event), event.type = (type === this.widgetEventPrefix ? type : this.widgetEventPrefix + type).toLowerCase(), 
                event.target = this.element[0], orig = event.originalEvent) for (prop in orig) prop in event || (event[prop] = orig[prop]);
                return this.element.trigger(event, data), !($.isFunction(callback) && callback.apply(this.element[0], [ event ].concat(data)) === !1 || event.isDefaultPrevented());
            }
        }, $.each({
            show: "fadeIn",
            hide: "fadeOut"
        }, function(method, defaultEffect) {
            $.Widget.prototype["_" + method] = function(element, options, callback) {
                "string" == typeof options && (options = {
                    effect: options
                });
                var hasOptions, effectName = options ? options === !0 || "number" == typeof options ? defaultEffect : options.effect || defaultEffect : method;
                options = options || {}, "number" == typeof options && (options = {
                    duration: options
                }), hasOptions = !$.isEmptyObject(options), options.complete = callback, options.delay && element.delay(options.delay), 
                hasOptions && $.effects && $.effects.effect[effectName] ? element[method](options) : effectName !== method && element[effectName] ? element[effectName](options.duration, options.easing, callback) : element.queue(function(next) {
                    $(this)[method](), callback && callback.call(element[0]), next();
                });
            };
        });
    }(jQuery), jQuery.widget;
}), define("domReady", [], function() {
    function runCallbacks(callbacks) {
        var i;
        for (i = 0; i < callbacks.length; i += 1) callbacks[i](doc);
    }
    function callReady() {
        var callbacks = readyCalls;
        isPageLoaded && callbacks.length && (readyCalls = [], runCallbacks(callbacks));
    }
    function pageLoaded() {
        isPageLoaded || (isPageLoaded = !0, scrollIntervalId && clearInterval(scrollIntervalId), 
        callReady());
    }
    function domReady(callback) {
        return isPageLoaded ? callback(doc) : readyCalls.push(callback), domReady;
    }
    var isTop, testDiv, scrollIntervalId, isBrowser = "undefined" != typeof window && window.document, isPageLoaded = !isBrowser, doc = isBrowser ? document : null, readyCalls = [];
    if (isBrowser) {
        if (document.addEventListener) document.addEventListener("DOMContentLoaded", pageLoaded, !1), 
        window.addEventListener("load", pageLoaded, !1); else if (window.attachEvent) {
            window.attachEvent("onload", pageLoaded), testDiv = document.createElement("div");
            try {
                isTop = null === window.frameElement;
            } catch (e) {}
            testDiv.doScroll && isTop && window.external && (scrollIntervalId = setInterval(function() {
                try {
                    testDiv.doScroll(), pageLoaded();
                } catch (e) {}
            }, 30));
        }
        "complete" === document.readyState && pageLoaded();
    }
    return domReady.version = "2.0.1", domReady.load = function(name, req, onLoad, config) {
        config.isBuild ? onLoad(null) : domReady(onLoad);
    }, domReady;
});
//# sourceMappingURL=jpmc.js.map