(function() {
    function has(name) {
        var stringifySupported, parseSupported, value, serialized = '{"A":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}', all = "json" == name;
        if (all || "json-stringify" == name || "json-parse" == name) {
            if ("json-stringify" == name || all) {
                if (stringifySupported = "function" == typeof JSON3.stringify && isExtended) {
                    (value = function() {
                        return 1;
                    }).toJSON = value;
                    try {
                        stringifySupported = "0" === JSON3.stringify(0) && "0" === JSON3.stringify(new Number()) && '""' == JSON3.stringify(new String()) && JSON3.stringify(getClass) === undef && JSON3.stringify(undef) === undef && JSON3.stringify() === undef && "1" === JSON3.stringify(value) && "[1]" == JSON3.stringify([ value ]) && "[null]" == JSON3.stringify([ undef ]) && "null" == JSON3.stringify(null) && "[null,null,null]" == JSON3.stringify([ undef, getClass, null ]) && JSON3.stringify({
                            A: [ value, !0, !1, null, "\x00\b\n\f\r	" ]
                        }) == serialized && "1" === JSON3.stringify(null, value) && "[\n 1,\n 2\n]" == JSON3.stringify([ 1, 2 ], null, 1) && '"-271821-04-20T00:00:00.000Z"' == JSON3.stringify(new Date(-864e13)) && '"+275760-09-13T00:00:00.000Z"' == JSON3.stringify(new Date(864e13)) && '"-000001-01-01T00:00:00.000Z"' == JSON3.stringify(new Date(-621987552e5)) && '"1969-12-31T23:59:59.999Z"' == JSON3.stringify(new Date(-1));
                    } catch (exception) {
                        stringifySupported = !1;
                    }
                }
                if (!all) return stringifySupported;
            }
            if ("json-parse" == name || all) {
                if ("function" == typeof JSON3.parse) try {
                    if (0 === JSON3.parse("0") && !JSON3.parse(!1) && (value = JSON3.parse(serialized), 
                    parseSupported = 5 == value.A.length && 1 == value.A[0])) {
                        try {
                            parseSupported = !JSON3.parse('"	"');
                        } catch (exception) {}
                        if (parseSupported) try {
                            parseSupported = 1 != JSON3.parse("01");
                        } catch (exception) {}
                    }
                } catch (exception) {
                    parseSupported = !1;
                }
                if (!all) return parseSupported;
            }
            return stringifySupported && parseSupported;
        }
    }
    var isProperty, forEach, undef, getClass = {}.toString, isLoader = "function" == typeof define && define.amd, JSON3 = !isLoader && "object" == typeof exports && exports;
    JSON3 || isLoader ? "object" == typeof JSON && JSON ? isLoader ? JSON3 = JSON : (JSON3.stringify = JSON.stringify, 
    JSON3.parse = JSON.parse) : isLoader && (JSON3 = this.JSON = {}) : JSON3 = this.JSON || (this.JSON = {});
    var Escapes, toPaddedString, quote, serialize, fromCharCode, Unescapes, abort, lex, get, walk, update, Index, Source, floor, Months, getDay, isExtended = new Date(-0xc782b5b800cec);
    try {
        isExtended = -109252 == isExtended.getUTCFullYear() && 0 === isExtended.getUTCMonth() && 1 == isExtended.getUTCDate() && 10 == isExtended.getUTCHours() && 37 == isExtended.getUTCMinutes() && 6 == isExtended.getUTCSeconds() && 708 == isExtended.getUTCMilliseconds();
    } catch (exception) {}
    has("json") || (isExtended || (floor = Math.floor, Months = [ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 ], 
    getDay = function(year, month) {
        return Months[month] + 365 * (year - 1970) + floor((year - 1969 + (month = +(month > 1))) / 4) - floor((year - 1901 + month) / 100) + floor((year - 1601 + month) / 400);
    }), (isProperty = {}.hasOwnProperty) || (isProperty = function(property) {
        var constructor, members = {};
        return (members.__proto__ = null, members.__proto__ = {
            toString: 1
        }, members).toString != getClass ? isProperty = function(property) {
            var original = this.__proto__, result = property in (this.__proto__ = null, this);
            return this.__proto__ = original, result;
        } : (constructor = members.constructor, isProperty = function(property) {
            var parent = (this.constructor || constructor).prototype;
            return property in this && !(property in parent && this[property] === parent[property]);
        }), members = null, isProperty.call(this, property);
    }), forEach = function(object, callback) {
        var Properties, members, property, forEach, size = 0;
        (Properties = function() {
            this.valueOf = 0;
        }).prototype.valueOf = 0, members = new Properties();
        for (property in members) isProperty.call(members, property) && size++;
        return Properties = members = null, size ? forEach = 2 == size ? function(object, callback) {
            var property, members = {}, isFunction = "[object Function]" == getClass.call(object);
            for (property in object) isFunction && "prototype" == property || isProperty.call(members, property) || !(members[property] = 1) || !isProperty.call(object, property) || callback(property);
        } : function(object, callback) {
            var property, isConstructor, isFunction = "[object Function]" == getClass.call(object);
            for (property in object) isFunction && "prototype" == property || !isProperty.call(object, property) || (isConstructor = "constructor" === property) || callback(property);
            (isConstructor || isProperty.call(object, property = "constructor")) && callback(property);
        } : (members = [ "valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor" ], 
        forEach = function(object, callback) {
            var property, length, isFunction = "[object Function]" == getClass.call(object);
            for (property in object) isFunction && "prototype" == property || !isProperty.call(object, property) || callback(property);
            for (length = members.length; property = members[--length]; isProperty.call(object, property) && callback(property)) ;
        }), forEach(object, callback);
    }, has("json-stringify") || (Escapes = {
        "\\": "\\\\",
        '"': '\\"',
        "\b": "\\b",
        "\f": "\\f",
        "\n": "\\n",
        "\r": "\\r",
        "	": "\\t"
    }, toPaddedString = function(width, value) {
        return ("000000" + (value || 0)).slice(-width);
    }, quote = function(value) {
        for (var symbol, result = '"', index = 0; symbol = value.charAt(index); index++) result += '\\"\b\f\n\r	'.indexOf(symbol) > -1 ? Escapes[symbol] : Escapes[symbol] = " " > symbol ? "\\u00" + toPaddedString(2, symbol.charCodeAt(0).toString(16)) : symbol;
        return result + '"';
    }, serialize = function(property, object, callback, properties, whitespace, indentation, stack) {
        var className, year, month, date, time, hours, minutes, seconds, milliseconds, results, element, index, length, prefix, any, result, value = object[property];
        if ("object" == typeof value && value) if (className = getClass.call(value), "[object Date]" != className || isProperty.call(value, "toJSON")) "function" == typeof value.toJSON && ("[object Number]" != className && "[object String]" != className && "[object Array]" != className || isProperty.call(value, "toJSON")) && (value = value.toJSON(property)); else if (value > -1 / 0 && 1 / 0 > value) {
            if (getDay) {
                for (date = floor(value / 864e5), year = floor(date / 365.2425) + 1970 - 1; getDay(year + 1, 0) <= date; year++) ;
                for (month = floor((date - getDay(year, 0)) / 30.42); getDay(year, month + 1) <= date; month++) ;
                date = 1 + date - getDay(year, month), time = (value % 864e5 + 864e5) % 864e5, hours = floor(time / 36e5) % 24, 
                minutes = floor(time / 6e4) % 60, seconds = floor(time / 1e3) % 60, milliseconds = time % 1e3;
            } else year = value.getUTCFullYear(), month = value.getUTCMonth(), date = value.getUTCDate(), 
            hours = value.getUTCHours(), minutes = value.getUTCMinutes(), seconds = value.getUTCSeconds(), 
            milliseconds = value.getUTCMilliseconds();
            value = (0 >= year || year >= 1e4 ? (0 > year ? "-" : "+") + toPaddedString(6, 0 > year ? -year : year) : toPaddedString(4, year)) + "-" + toPaddedString(2, month + 1) + "-" + toPaddedString(2, date) + "T" + toPaddedString(2, hours) + ":" + toPaddedString(2, minutes) + ":" + toPaddedString(2, seconds) + "." + toPaddedString(3, milliseconds) + "Z";
        } else value = null;
        if (callback && (value = callback.call(object, property, value)), null === value) return "null";
        if (className = getClass.call(value), "[object Boolean]" == className) return "" + value;
        if ("[object Number]" == className) return value > -1 / 0 && 1 / 0 > value ? "" + value : "null";
        if ("[object String]" == className) return quote(value);
        if ("object" == typeof value) {
            for (length = stack.length; length--; ) if (stack[length] === value) throw TypeError();
            if (stack.push(value), results = [], prefix = indentation, indentation += whitespace, 
            "[object Array]" == className) {
                for (index = 0, length = value.length; length > index; any || (any = !0), index++) element = serialize(index, value, callback, properties, whitespace, indentation, stack), 
                results.push(element === undef ? "null" : element);
                result = any ? whitespace ? "[\n" + indentation + results.join(",\n" + indentation) + "\n" + prefix + "]" : "[" + results.join(",") + "]" : "[]";
            } else forEach(properties || value, function(property) {
                var element = serialize(property, value, callback, properties, whitespace, indentation, stack);
                element !== undef && results.push(quote(property) + ":" + (whitespace ? " " : "") + element), 
                any || (any = !0);
            }), result = any ? whitespace ? "{\n" + indentation + results.join(",\n" + indentation) + "\n" + prefix + "}" : "{" + results.join(",") + "}" : "{}";
            return stack.pop(), result;
        }
    }, JSON3.stringify = function(source, filter, width) {
        var whitespace, callback, properties, index, length, value;
        if ("function" == typeof filter || "object" == typeof filter && filter) if ("[object Function]" == getClass.call(filter)) callback = filter; else if ("[object Array]" == getClass.call(filter)) for (properties = {}, 
        index = 0, length = filter.length; length > index; value = filter[index++], ("[object String]" == getClass.call(value) || "[object Number]" == getClass.call(value)) && (properties[value] = 1)) ;
        if (width) if ("[object Number]" == getClass.call(width)) {
            if ((width -= width % 1) > 0) for (whitespace = "", width > 10 && (width = 10); whitespace.length < width; whitespace += " ") ;
        } else "[object String]" == getClass.call(width) && (whitespace = width.length <= 10 ? width : width.slice(0, 10));
        return serialize("", (value = {}, value[""] = source, value), callback, properties, whitespace, "", []);
    }), has("json-parse") || (fromCharCode = String.fromCharCode, Unescapes = {
        "\\": "\\",
        '"': '"',
        "/": "/",
        b: "\b",
        t: "	",
        n: "\n",
        f: "\f",
        r: "\r"
    }, abort = function() {
        throw Index = Source = null, SyntaxError();
    }, lex = function() {
        for (var symbol, value, begin, position, sign, source = Source, length = source.length; length > Index; ) if (symbol = source.charAt(Index), 
        "	\r\n ".indexOf(symbol) > -1) Index++; else {
            if ("{}[]:,".indexOf(symbol) > -1) return Index++, symbol;
            if ('"' == symbol) {
                for (value = "@", Index++; length > Index; ) if (symbol = source.charAt(Index), 
                " " > symbol) abort(); else if ("\\" == symbol) if (symbol = source.charAt(++Index), 
                '\\"/btnfr'.indexOf(symbol) > -1) value += Unescapes[symbol], Index++; else if ("u" == symbol) {
                    for (begin = ++Index, position = Index + 4; position > Index; Index++) symbol = source.charAt(Index), 
                    symbol >= "0" && "9" >= symbol || symbol >= "a" && "f" >= symbol || symbol >= "A" && "F" >= symbol || abort();
                    value += fromCharCode("0x" + source.slice(begin, Index));
                } else abort(); else {
                    if ('"' == symbol) break;
                    value += symbol, Index++;
                }
                if ('"' == source.charAt(Index)) return Index++, value;
                abort();
            } else {
                if (begin = Index, "-" == symbol && (sign = !0, symbol = source.charAt(++Index)), 
                symbol >= "0" && "9" >= symbol) {
                    for ("0" == symbol && (symbol = source.charAt(Index + 1), symbol >= "0" && "9" >= symbol) && abort(), 
                    sign = !1; length > Index && (symbol = source.charAt(Index), symbol >= "0" && "9" >= symbol); Index++) ;
                    if ("." == source.charAt(Index)) {
                        for (position = ++Index; length > position && (symbol = source.charAt(position), 
                        symbol >= "0" && "9" >= symbol); position++) ;
                        position == Index && abort(), Index = position;
                    }
                    if (symbol = source.charAt(Index), "e" == symbol || "E" == symbol) {
                        for (symbol = source.charAt(++Index), ("+" == symbol || "-" == symbol) && Index++, 
                        position = Index; length > position && (symbol = source.charAt(position), symbol >= "0" && "9" >= symbol); position++) ;
                        position == Index && abort(), Index = position;
                    }
                    return +source.slice(begin, Index);
                }
                if (sign && abort(), "true" == source.slice(Index, Index + 4)) return Index += 4, 
                !0;
                if ("false" == source.slice(Index, Index + 5)) return Index += 5, !1;
                if ("null" == source.slice(Index, Index + 4)) return Index += 4, null;
                abort();
            }
        }
        return "$";
    }, get = function(value) {
        var results, any;
        if ("$" == value && abort(), "string" == typeof value) {
            if ("@" == value.charAt(0)) return value.slice(1);
            if ("[" == value) {
                for (results = []; value = lex(), "]" != value; any || (any = !0)) any && ("," == value ? (value = lex(), 
                "]" == value && abort()) : abort()), "," == value && abort(), results.push(get(value));
                return results;
            }
            if ("{" == value) {
                for (results = {}; value = lex(), "}" != value; any || (any = !0)) any && ("," == value ? (value = lex(), 
                "}" == value && abort()) : abort()), ("," == value || "string" != typeof value || "@" != value.charAt(0) || ":" != lex()) && abort(), 
                results[value.slice(1)] = get(lex());
                return results;
            }
            abort();
        }
        return value;
    }, update = function(source, property, callback) {
        var element = walk(source, property, callback);
        element === undef ? delete source[property] : source[property] = element;
    }, walk = function(source, property, callback) {
        var length, value = source[property];
        if ("object" == typeof value && value) if ("[object Array]" == getClass.call(value)) for (length = value.length; length--; ) update(value, length, callback); else forEach(value, function(property) {
            update(value, property, callback);
        });
        return callback.call(source, property, value);
    }, JSON3.parse = function(source, callback) {
        var result, value;
        return Index = 0, Source = source, result = get(lex()), "$" != lex() && abort(), 
        Index = Source = null, callback && "[object Function]" == getClass.call(callback) ? walk((value = {}, 
        value[""] = result, value), "", callback) : result;
    })), isLoader && define([], function() {
        return JSON3;
    });
}).call(this);
//# sourceMappingURL=json3.js.map