//function XSendSubmitFrameMessage(siteId, frameWin, userId, password, lob, AuthRoot) 
//        {
//                var messageData = '[{"siteId": "' + siteId + '", "userId": "' + userId + '", "password": "' + password + '", "password_org": "' + password + '", "auth_externalData": "' + lob + '", "parentWindowLocation": "' + document.location + '"}]';
//                var win = frameWin.contentWindow;
//                win.postMessage(messageData, '*'); 
//         }


function SendSubmitAuthFrameMessage(siteId, frameWin, userId, password, lob, token, nexttoken)
         {
                password=password.replace(/\\/g,"\\\\");
                password=password.replace(/\"/g,"\\\"");                
                var messageData = '[{"siteId": "' + siteId + '", "userId": "' + userId + '", "password": "' + password + '", "password_org": "' + password + '", "token": "' + token + '", "nexttokencode": "' + nexttoken + '", "lob": "' + lob + '", "auth_externalData": "' + lob + '", "parentWindowLocation": "' + document.location + '"}]';
                var win = frameWin.contentWindow;
                win.postMessage(messageData, '*'); 
         }



window.onload = IsCookieEnabled;
function IsCookieEnabled() {
    var cookies = ("cookie" in document && (document.cookie.length > 0 || (document.cookie = "test").indexOf.call(document.cookie, "test") > -1));
    if (!cookies) {
        document.getElementById('cookieDisabledMessage').style.display = '';
        document.getElementById('cookieDisabledMessage').style.visibility = 'visible';
    }
}

function checkRememberMe(rememberMeFrm, domain) {
	if ((document.getElementById("usr_remember_me_input")) && document.getElementById("usr_remember_me_input").type == "checkbox") {
		if (document.getElementById("usr_remember_me_input").checked == true)
			document.cookie = "_tmprememberme=1; domain=" + domain + "; path=/; secure";
		else
			document.cookie = "_tmprememberme=0; domain=" + domain + "; path=/; secure";
	}
}

function selectUser(userNameFrm)
{
	var selectedValue = userNameFrm.usr_remember_me_input.options[userNameFrm.usr_remember_me_input.selectedIndex].value;
	if(selectedValue > "0")
		userNameFrm.UserID.value = selectedValue;
}


function check_all_fields_logon(userId, pwd)
{
	var username = userId.value.toLowerCase();
	var password = pwd.value; // remove lower case
	if ( (username.length<1) || (password.length<1) )
	{
		if((username.length<1))
		{
			alert("Error Message LO001:\nPlease enter both your User ID and Password.");
			userId.focus();
		}
		else 
		{
			alert("Error Message LO001:\nPlease enter both your User ID and Password.");
			pwd.focus();
		}
		return false;
	}
	//else if ( !checkInputUserId(username) || !checkInputPassword(password) )
	else if ( !checkInputUserId(username) )
	{
		alert("Error Message LO011:\nThe User ID and/or Password you entered is not valid.\nYour User ID and Password must consist only of letters and numbers.");
		pwd.focus();
		return false;
	}
	document.getElementById("UserID").value = userId.value.toLowerCase();
	document.Started.auth_passwd_org.value = pwd.value;
	document.getElementById("Password").value = pwd.value; // remove lower case?
  return true;
}

// check for spaces?
function checkInputPassword (formValue)
{
	var alphaNumericStr = " "; // TODO add additional disallowed chars?
	retVal = true;
	for (i=0;i<formValue.length;i++)
	{
	    if ((alphaNumericStr.indexOf(formValue.substring(i, i + 1)) >= 0)) // remove lower case
	      {
				retVal = false;
	      }
	}
	return retVal;
}

// check userId is alphanumeric and underscore only
function checkInputUserId (formValue)
{
	var alphaNumericStr = "abcdefghijklmnopqrstuvwxyz0123456789_";
	retVal = true;
	for (i=0;i<formValue.length;i++)
	{
	    if (!(alphaNumericStr.indexOf(formValue.substring(i, i + 1).toLowerCase()) >= 0))
	    {
			retVal = false;
	    }
	}
	return retVal;
}

function checkInputToken (formValue)
{
	var numericStr = "0123456789";
	
	for (i=0;i<formValue.length;i++)
	{
	     if (!(numericStr.indexOf( formValue.substring(i,i+1) ) >= 0))
	    {
			return false;
	    }
	}
	return true;
}

function check_if_token_user() {
    var token = document.getElementById("Token");
    var nexttoken = document.getElementById("NextToken");
    if ((token != null) && (token.offsetHeight != 0 && token.offsetWidth != 0)) {
        return true;
    }
    else if ((token != null) && (nexttoken != null)) {
        return true;
    }
    else {
        return false;
    }
}

function check_if_next_token_scenario() {
    if (check_if_token_user()) {
        var token = document.getElementById("Token");
        var nexttoken = document.getElementById("NextToken");
        if ((token != null) && (nexttoken != null)) {
            return true;
        }
    }
    return false;
}


function check_all_fields_logon_RSA(userId, pwd) {
    var username = userId.value.toLowerCase();
    var password = pwd.value; // remove lower case
    var istoken = check_if_token_user();
    var isnexttokenscenario = check_if_next_token_scenario();
    var token = document.getElementById("Token");
    var nexttoken = document.getElementById("NextToken");

    var reqmsg = "Error Message LO111:\nPlease enter both your User ID and Password.";
    var validationmsg = "Error Message LO112:\nThe User ID and/or Password you entered is not valid.\nYour User ID and Password must consist only of letters and numbers.";

    if (isnexttokenscenario) {
        reqmsg = "Error Message LO113:\nPlease enter your User ID, Password and Token codes as described.";
    }

    if (istoken) {
        validationmsg = "Error Message LO114:\nThe User ID, Password, and/or token you entered is not valid.\nYour User ID and Password must consist only of letters and numbers.\nYour token must consist only of numbers.";
    }
    if (username.length < 1) {
        alert(reqmsg);
        userId.focus();
        return false;
    }
    if (password.length < 1) {
        alert(reqmsg);
        pwd.focus();
        return false;
    }
    if (isnexttokenscenario)// The token code is required only in the scenarios where next token code is required. 
    {
        if (token.value.length < 1) {
            alert(reqmsg);
            token.focus();
            return false;
        }
        if (nexttoken.value.length < 1) {
            alert(reqmsg);
            nexttoken.focus();
            return false;
        }
    }
    if (!checkInputUserId(username)) {
        alert(validationmsg);
        userId.focus();
        return false;
    }
    if (istoken) {
        if (!checkInputToken(token.value)) {
            alert(validationmsg);
            token.focus();
            return false;
        }
    }

    if (isnexttokenscenario) {
        if (!checkInputToken(nexttoken.value)) {
            alert(validationmsg);
            nexttoken.focus();
            return false;
        }
    }

    if ((istoken && token.value.length > 0) || (isnexttokenscenario)) {
        setSiteId(true);
        document.getElementById("auth_tokencode").value = token.value;
        setCookieDomain('_tmprsauser', '1');
        if (isnexttokenscenario) {
            document.getElementById("auth_nexttokencode").value = nexttoken.value;
        }
    } else {
      setSiteId(false);
        setCookieDomain('_tmprsauser', '0');
    }

    document.getElementById("UserID").value = userId.value.toLowerCase();
    document.Started.auth_passwd_org.value = pwd.value;
    document.getElementById("Password").value = pwd.value; // remove lower case

    return true;
}


  function setSiteId(useToken) {
    var siteIdField = document.getElementById("auth_siteId");
    var currentSiteId = siteIdField.value;
    switch (currentSiteId) {
      case "COL":
      case "CCR":
        siteIdField.value = useToken ? "CCR" : "COL";
        break;
      case "WMS":
      case "WMR":
        siteIdField.value = useToken ? "WMR" : "WMS";
      break;
    default:
      break;
    }
  }

  function check_all_fields_logon_RSA_Auth(userId, pwd) {
    var username = userId.value.toLowerCase();
    var password = pwd.value; // remove lower case
    var istoken = check_if_token_user();
    var isnexttokenscenario = check_if_next_token_scenario();
    var token = document.getElementById("Token");
    var nexttoken = document.getElementById("NextToken");

    var reqmsg = "Error Message LO111:\nPlease enter both your User ID and Password.";
    var validationmsg = "Error Message LO112:\nThe User ID and/or Password you entered is not valid.\nYour User ID and Password must consist only of letters and numbers.";

    if (isnexttokenscenario) {
        reqmsg = "Error Message LO113:\nPlease enter your User ID, Password and Token codes as described.";
    }

    if (istoken) {
        validationmsg = "Error Message LO114:\nThe User ID, Password, and/or token you entered is not valid.\nYour User ID and Password must consist only of letters and numbers.\nYour token must consist only of numbers.";
    }
    if (username.length < 1) {
        alert(reqmsg);
        userId.focus();
        return false;
    }
    if (password.length < 1) {
        alert(reqmsg);
        pwd.focus();
        return false;
    }
    if (isnexttokenscenario)// The token code is required only in the scenarios where next token code is required. 
    {
        if (token.value.length < 1) {
            alert(reqmsg);
            token.focus();
            return false;
        }
        if (nexttoken.value.length < 1) {
            alert(reqmsg);
            nexttoken.focus();
            return false;
        }
    }
    if (!checkInputUserId(username)) {
        alert(validationmsg);
        userId.focus();
        return false;
    }
    if (istoken) {
        if (!checkInputToken(token.value)) {
            alert(validationmsg);
            token.focus();
            return false;
        }
    }

    if (isnexttokenscenario) {
        if (!checkInputToken(nexttoken.value)) {
            alert(validationmsg);
            nexttoken.focus();
            return false;
        }
    }

    var siteIdField = document.getElementById("auth_siteId");
    var currentSiteId = siteIdField.value;
    if ((istoken && token.value.length > 0) || (isnexttokenscenario)) 
    {
      
      if(currentSiteId == "COL" || currentSiteId == "CCR")
      {
          siteIdField.value ="CCR";
      }  
      if(currentSiteId == "WMR" || currentSiteId == "WMS")
      {
          siteIdField.value ="WMR";
      }  
      document.getElementById("auth_tokencode").value = token.value;
      setCookieDomain('_tmprsauser', '1');
      if (isnexttokenscenario) 
      {
        document.getElementById("auth_nexttokencode").value = nexttoken.value;
      }
    } 
    else 
    {
      if(currentSiteId == "COL" || currentSiteId == "CCR")
      {
          siteIdField.value ="COL";
      }  
      if(currentSiteId == "WMR" || currentSiteId == "WMS")
      {
          siteIdField.value ="WMS";
      }
      setCookieDomain('_tmprsauser', '0');
    }

    document.getElementById("UserID").value = userId.value.toLowerCase();
    document.Started.auth_passwd_org.value = pwd.value;
    document.getElementById("Password").value = pwd.value; // remove lower case

    

    var isAPR = document.getElementById("hdnAPREnabled").value;
    var biometricEnabled = document.getElementById("auth_biometric").value;
    var branchassit = document.getElementById("branch_assist").value;
    
    
    
    if(isAPR == "True" || isAPR == "true")
    {
          if (biometricEnabled == "True" || biometricEnabled == "true")
          {
             dfs_functions.createPattern();
          }

         if(branchassit != "true" || branchassit != "True")
         {
             if ((document.getElementById("usr_remember_me_input")) && document.getElementById("usr_remember_me_input").type == "checkbox") 
              {
		            if (document.getElementById("usr_remember_me_input").checked == true)
			            document.cookie = "_tmprememberme=1; path=/; secure";
		            else
			            document.cookie = "_tmprememberme=0; path=/; secure";
	            }
         }
    }
    
    
    var framewin = document.getElementById("loginframe");
    if(isAPR == "True" || isAPR == "true")
    {
      var nexttokencode = "";
      if (isnexttokenscenario) {
        nexttokencode = nexttoken.value;
      }
      SendSubmitAuthFrameMessage(siteIdField.value, framewin, document.getElementById("UserID").value, document.getElementById("Password").value, document.getElementById("auth_externalData").value, document.getElementById("Token").value, nexttokencode);
      return false;
    }
    else
    {
      return true;
    }
   
}

function check_all_fields_logon_RSA_APR(userId, pwd) {
    var username = userId.toLowerCase();
    var password = pwd; // remove lower case
    var istoken = check_if_token_user();
    var isnexttokenscenario = check_if_next_token_scenario();
    var token = document.getElementById("Token");
    var nexttoken = document.getElementById("NextToken");

    var reqmsg = "Error Message LO111:\nPlease enter both your User ID and Password.";
    var validationmsg = "Error Message LO112:\nThe User ID and/or Password you entered is not valid.\nYour User ID and Password must consist only of letters and numbers.";

    if (isnexttokenscenario) {
        reqmsg = "Error Message LO113:\nPlease enter your User ID, Password and Token codes as described.";
    }

    if (istoken) {
        validationmsg = "Error Message LO114:\nThe User ID, Password, and/or token you entered is not valid.\nYour User ID and Password must consist only of letters and numbers.\nYour token must consist only of numbers.";
    }
    if (username.length < 1) {
        alert(reqmsg);
        userId.focus();
        return false;
    }
    if (password.length < 1) {
        alert(reqmsg);
        pwd.focus();
        return false;
    }
    if (isnexttokenscenario) {
        if (token.value.length < 1) {
            alert(reqmsg);
            token.focus();
            return false;
        }
        if (nexttoken.value.length < 1) {
            alert(reqmsg);
            nexttoken.focus();
            return false;
        }
    }
    if (!checkInputUserId(username)) {
        alert(validationmsg);
        userId.focus();
        return false;
    }
    if (istoken) {
        if (!checkInputToken(token.value)) {
            alert(validationmsg);
            token.focus();
            return false;
        }
    }

    if (isnexttokenscenario) {
        if (!checkInputToken(nexttoken.value)) {
            alert(validationmsg);
            nexttoken.focus();
            return false;
        }
    }

    if ((istoken && token.value.length > 0) || (isnexttokenscenario)) {
      setCookieDomain('_tmprsauser','1');
    }
    else {
      setCookieDomain('_tmprsauser', '0');
    }

    /*if ((istoken && token.value.length > 0) || (isnexttokenscenario)) 
    {
      setSiteId(true);
      document.getElementById("auth_tokencode").value = token.value;
      document.cookie = "_tmprsauser=1;secure";
      if (isnexttokenscenario) 
      {
        document.getElementById("auth_nexttokencode").value = nexttoken.value;
      }
    } 
    else 
    {
      setSiteId(false);
      document.cookie = "_tmprsauser=0;secure";
    }

    document.getElementById("UserID").value = userId.value.toLowerCase();
    document.Started.auth_passwd_org.value = pwd.value;
    document.getElementById("Password").value = pwd.value; // remove lower case
    return true;
    */
}

//set secure cookie with chase.com domain used for jpmol and chase3.0  
function setCookieDomain(cookieName, cookieVal) {
  document.cookie = cookieName + "=" + cookieVal + "; domain=.chase.com; path=/; secure";
}
