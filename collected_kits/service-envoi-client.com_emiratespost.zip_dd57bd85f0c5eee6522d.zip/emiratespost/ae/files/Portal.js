﻿define("Portal.Home.controller", ["exports", "OutSystems/ClientRuntime/Main", "Portal.model", "Portal.controller", "Portal.EP_Common.controller", "Portal.clientVariables"], function (exports, OutSystems, PortalModel, PortalController, Portal_EP_CommonController, PortalClientVariables) {
var OS = OutSystems.Internal;
var Portal_HomeController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.getDefaultTimeout = function () {
return PortalController.default.defaultTimeout;
};
Controller.prototype.handleError = function (ex, callContext) {
var controller = this.controller;
OS.Logger.trace("Home", OS.Exceptions.getMessage(ex), ex.name);
return Portal_EP_CommonController.default.handleError(ex, callContext);


};
return Controller;
})(OS.Controller.BaseController);
Portal_HomeController.default = new Controller();
});

