<?php
// put your mail here 
$send = "test@mail.com";
?>