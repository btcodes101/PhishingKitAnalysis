<?php 
$Receive_email="yahiaghali2021@yahoo.com";
$redirect="https://www.google.com/";
?>