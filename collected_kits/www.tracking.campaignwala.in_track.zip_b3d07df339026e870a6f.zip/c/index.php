<?php

$aff=$_GET['a'];
$o = $_GET['o'];
$s1=$_GET['aff_click_id'];
$s2=$_GET['sub_aff_id'];
$date = date('Y-m-d'); 

$number=file_get_contents("../Aff/num/$aff.txt");


$file="../offer/$o/$o.json";

$data=file_get_contents($file);
$json=json_decode($data,true);
$link=$json['camptrk'];

$add=file_get_contents("../dclick/$date-$number.txt");
$adding='1';
$added=$add+$adding;
file_put_contents("../dclick/$date-$number.txt",$added);



 echo"<meta http-equiv='refresh' content='0;url=$link&aff_click_id=$s1&sub_aff_id=$s2&aff_sub2=$o&aff_sub1=$aff'>";
?>