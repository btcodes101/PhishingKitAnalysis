 <?php
$token=$_GET['token'];
$oid=$_GET['oid'];
$ref=$_GET['ref'];
$us=$_GET['us'];
$event=$_GET['event'];
$file="db/$token/$oid.json";
$file2="/db/$token/key.json";
$data2=file_get_contents($file2);
$json2=json_decode($data2,true);
$guid=$json2['guid'];
$mid=$json2['mid'];
$mkey=$json2['mkey'];


$data=file_get_contents($file);
$json=json_decode($data,true);
$userp=$json['userp'];
$peruser=$json['peruser'];
$user=$json['user'];
$refer=$json['refer'];
$comm=$json['comm'];
$tg=$json['tg'];
$rcomm=$json['rcomm'];

$bott=$json['bott'];
$a = mt_rand(1000000,9999999);
$a1 = mt_rand(1000000,9999999);
$com=urlencode("$comm");
$rcom=urlencode("$rcomm");


$add1=file_get_contents("db/$token/ref/$ref.txt");
$adding1='1';
$added1=$add1+$adding1;
file_put_contents("db/$token/ref/$ref.txt",$added1);



$tex='🚀New Conversation🚀

🔰Event : '.$event.'

🛡Paytm Number : '.$us.'
👉UserAmount : '.$user.'

🛡Paytm Number : '.$ref.'
👉Refer Amount : '.$refer.'

📊Status: success✅

⚡️Powered by:  Technocamp.co.in ⚡️';
 
 $text=urlencode("$tex");
 
$url99='https://api.telegram.org/bot'.$bott.'/sendMessage?chat_id='.$tg.'&text='.$text.'&parse_mode=markdown';

$headers[]='user-agent: Mozilla/5.0 (Linux; Android 10; TECNO KE6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36';

$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url99);
curl_setopt($ch,CURLOPT_POST,1);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);


    $output=curl_exec($ch);
    if($ref==$us){
    
$url5='https://earnfastpayments.com/api/walletpay/?paytm='.$us.'&amount='.$user.'&comment='.$com.'&guid='.$guid.'&orderid=adiins'.$a.'';


$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url5);
curl_setopt($ch,CURLOPT_POST,1);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
     curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);


    $output=curl_exec($ch);

    curl_close($ch);
    echo"$output";
    return;
    }else
    if(file_exists($claimfile1)){
    return;}else
    if(file_exists($claimfile)){
    return;}else{
    
    $url50='https://earnfastpayments.com/api/walletpay/?paytm='.$us.'&amount='.$refer.'&comment='.$com.'&guid='.$guid.'&orderid=adiins'.$a.'';


$ch1=curl_init();
curl_setopt($ch1,CURLOPT_URL,$url50);
curl_setopt($ch1,CURLOPT_POST,1);
    curl_setopt($ch1,CURLOPT_RETURNTRANSFER,1);
     curl_setopt($ch1,CURLOPT_SSL_VERIFYPEER,false);


    $output1=curl_exec($ch1);

    curl_close($ch1);
    
    $url00='https://earnfastpayments.com/api/walletpay/?paytm='.$ref.'&amount='.$refer.'&comment='.$rcom.'&guid='.$guid.'&orderid=adiinss'.$a.'';


$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url00);
curl_setopt($ch,CURLOPT_POST,1);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
     curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);


    $output2=curl_exec($ch);

    curl_close($ch);
    
    echo $url50;
    echo $url00;
    
    
echo $output1;
echo $output2;
    

    }
    
?>