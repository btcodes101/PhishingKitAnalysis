<?php
error_reporting(0);
session_start();

$session = $_SESSION['num'];

$json_object = file_get_contents('Aff/user'.$session.'.txt');

$aid1=file_get_contents('../Aff/aff_id/'.$session.'.txt');
$aid=base64_encode($aid1);

if(!isset($_SESSION['num'])){

echo" <div class='login-box'><h3 class='variablecolor' >Please Login";

echo"<meta http-equiv='refresh' content='0;url=login.php'>";
return;
}
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="https://telegram.im/img/@Cashback_Boosters" type="image/x-icon" />
    <title>Instant Payment Panel</title>
    <style>
    @import url('https://fonts.googleapis.com/css?family=Open+Sans:200,300,400,400i,500,600,700%7CMontserrat:300,400,500%7CRoboto');
    @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@700&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap');

    html{
         text-rendering: optimizeLegibility !important;
         -webkit-font-smoothing: antialiased;
         -moz-osx-font-smoothing: grayscale;
    }

    body{
        background: white;
        line-height: 1;
        webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    .form{
        position: relative;
        max-width: 420px;
        margin: 0 auto;
        margin-top: 30px;

    }
    h1,h2{
        font-size: 25px;
        font-weight: 400;
        color: black;
        max-width: 630px;
        margin: 0 auto;
        letter-spacing: 0;
        line-height: 1.6;
        margin-top: 10px;
        margin-bottom: 15px;
        font-family: 'Rajdhani', sans-serif;
    }
    h2{
        color: blue;
    }
    }
    p{
        font-size: 18px;
        font-weight: 400;
        color: black;
        max-width: 630px;
        margin: 0 auto;
        letter-spacing: 0;
        line-height: 1.6;
        margin-top: 10px;
        margin-bottom: 15px;
        font-family: 'Rajdhani', sans-serif;
    }

    .input{
        display: block;
        width: 100%;
        margin: 0 auto;
        color: #6d48e5;
        font-family: 'Montserrat';
        padding: 0;
        font-size: 13px;
        font-weight: 500;
        height: 50px;
        border: 1px solid #047aed;
        border-radius: 4px;
        background-color: #FFFFFF;
        outline: none;
        padding: 0 100px 0 5px;
        box-shadow: 0 5px 30px rgba(255, 255, 255, 0.1);
    }
    .submit{
        font-size:18px;color:#ffffff;position:relative;background-color:#7e12e3;outline:0;border-radius:5px;font-family:Bree Serif;text-align:center;padding:8px 5px;height:45px;border:solid 1px #7e12e3;margin-bottom:1%; margin-top:2%; box-shadow:4px 4px 10px #7e12e3;width:60%;
    }
    .head{
        font-size: 25px;
        font-family: 'Roboto', sans-serif;
        margin-top: 40px;
        margin-bottom: 40px;
    }
    span{
        font-family: 'Montserrat';
        color: grey;
        font-size: 10px;
        font-weight: bolder;

    }
    .access{
        font-size: 20px;
    }
    font{
        font-family: 'Bree Serif', serif;
    }
    hr{
    border:0;height:2px;
    text-align: center;
    background-image:linear-gradient(to right,rgba(0,0,0,0),#047aed,rgba(0,0,0,0));
    }
    .font{
            font-family: 'Bree Serif', serif;
    font-size: 20px;
    color: blue;
    }
    #loader {
      border: 12px solid
      #047aed;
      border-radius: 50%;
      border-top: 12px solid black;
      width: 100px;
      height: 100px;
      text-align: center;
      animation: spin 1s linear infinite;
      z-index: 9999;
    }
    @keyframes spin {
      100% {
      transform: rotate(360deg);
       }
    }
    .center {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;
    }
    </style>
<body>
  <div id='loader'class='center'></div>
  <script>
      document.onreadystatechange = function() {
          if (document.readyState !== "complete") {
              document.querySelector(
                "body").style.visibility = "hidden";
              document.querySelector("#loader").style.visibility = "visible";
          } else {
              document.querySelector(
                "#loader").style.display = "none";
              document.querySelector(
                "body").style.visibility = "visible";
          }
      };
  </script>
    <center><section class="home-section">
    <div class="form">
    <center>
            <div class='head'>
            <b>
            <h1 class='detial'>TECHNO CAMP</h1>
            </center>
            
            </b>
            </div>
<hr><center><font class='search'>Add Campagin =>  <font color='red'>Technocamp</font></font></center><hr>

<?php

if(!isset($_POST['submit'])){
echo '<div class="form">
<form action="" method="POST" >

<input type="text" name="oid" class="input" placeholder="Offer id"Required>
<br>
<input type="number" name="refer" class="input" placeholder="Per Refer"Required>
<br>
<input type="number" name="user" class="input" placeholder="Per User"Required>
<br>
<input type="text" name="comm" class="input" placeholder="user Payment Comment"Required>
<br>
<input type="text" name="rcomm" class="input" placeholder="Refer Payment Comment"Required>
<br>
<input type="text" name="guid" class="input" placeholder="Sub Guid"Required>
<br>
<input type="text" name="mid" class="input" placeholder="Enter mid"Required>
<br>
<input type="text" name="mkey" class="input" placeholder="Enter mkey"Required>

<br>

<input type="text" name="bott" class="input" placeholder="Bot Token "Required>
<br>
<input type="text" name="tgid" class="input" placeholder="Telegram Id"Required>

<input type="hidden" name="passs"  value="07">

<br>
<input type="submit" class="submit" name="submit" value="Make Link">';

  }


       if(isset($_POST['submit'])){
       	
        $tg=$_POST['tgid'];
        $oid=$_POST['oid'];
    	$bott=$_POST['bott'];
       	$refer=$_POST['refer'];
       	$user=$_POST['user'];
       	$comm=$_POST['comm'];
       	$guid=$_POST['guid'];
       	$pass=$_POST['passs'];
       	$rcom=$_POST['rcomm'];
       	$mid=$_POST['mid'];
       	$mkey=$_POST['mkey'];
       	$key='key';
       	$cor="07";
       	   	


       	
       	
       	if (file_exists($a)){
    echo "Try Again";
    
}else{
if($pass==$cor){
	
mkdir("db/$aid");


$p='{"refer":"'.$refer.'","user":"'.$user.'","comm":"'.$comm.'","bott":"'.$bott.'","tg":"'.$tg.'","rcomm":"'.$rcom.'"}';

$q='{"guid":"'.$guid.'","mid":"'.$mid.'","mkey":"'.$mkey.'"}';
 
file_put_contents('db/'.$aid.'/'.$oid.'.json', $p);
file_put_contents('db/'.$aid.'/'.$key.'.json', $q);

echo"<br><br><center><font class='search'>Here Is Your Instant Payment Url </font></center>";
echo '<div class="form">
  <input type="text" name="number" id="myInput" class="input" value="https://track.technocamp.co.in/panel/ins.php?token='.$aid.'&oid={offerid}&us={aff_click_id}&ref={sub_aff_id}&event={event_name}"><br>
  <button class="submit" onclick="myFunction()">Copy Your Reffer Link</button></div>
;
<script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
  alert("Copied the text: " + copyText.value);
}
</script>';
}else{
echo"Wrong Pass";}}}

?>