<?php
error_reporting(0);
session_start();

$session = $_SESSION['num'];
$date = date('Y-m-d'); 

$json_object = file_get_contents('Aff/user'.$session.'.txt');
$aff=file_get_contents('Aff/aff_id/'.$session.'.txt');

if(!isset($_SESSION['num'])){

echo" <div class='login-box'><h3 class='variablecolor' >Please Login";

echo"<meta http-equiv='refresh' content='0;url=login.php'>";
return;
}

$total=file_get_contents("dconver/$date-$aff.txt"); 
$clicks=file_get_contents("dclick/$date-$session.txt");
?>

<!DOCTYPE html>


  <head>
    <meta charset="UTF-8">
    <title>TechnoCamp affiliates </title>
    <script src="https://kit.fontawesome.com/65a36733a9.js" crossorigin="anonymous"></script><link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Technocamp</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="index.php" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li><br>
        <li>
          <a href="offer.php">
            <i class="fas fa-atom"></i>
            <span class="links_name">Offer</span>
          </a>
        </li><br>
        <li>
          <a href="report.php">
            <i class='bx bx-pie-chart-alt-2' ></i>
            <span class="links_name">Report</span>
          </a>
        </li><br>
        <li>
          <a href="postback.php">
            <i class="fas fa-charging-station"></i>
        <br>    <span class="links_name">Postback</span>
          </a>
        </li><br><li>
          <a href="panel/index.php">
            <i class='fa fa-flash' style='color: white'></i>
        <br>    <span class="links_name">Instant Panel</span>
          </a>
        </li><br>
        <li>
          
    <br></b>    <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
     <b> TechnoCamp</b>
      <div class="profile-details">
        <img src="images/techno.jpg" alt="">
        
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Conversion</div>
            <div class="number">0<?php echo $total; ?></div><br>
            <div class="indicator">
              
              <br><br>
            </div>
          </div>
          <i class='bx bx-cart-alt cart'></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total   Clicks  </div>
     <div class="number">0<?php echo $clicks; ?></div>
            <div class="indicator">
            
            </div><br><br>
          </div>
          <i class='bx bxs-cart-add cart two' ></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Revenue</div>
            <div class="number">00</div>
            <div class="indicator"><br><br>
              
            </div>
          </div>
         
      
          
          
        </div>
      </div>
    </div>
  </section>

  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>