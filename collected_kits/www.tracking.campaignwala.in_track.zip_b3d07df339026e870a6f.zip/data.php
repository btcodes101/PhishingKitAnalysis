<?php
error_reporting(0);
session_start();

$session = $_SESSION['num'];
$oid=$_GET['oid'];
$aid=file_get_contents('Aff/aff_id/'.$session.'.txt');
$json_object = file_get_contents('Aff/user'.$session.'.txt');
$report=file_get_contents('data/'.$oid.'-'.$aid.'.txt');
$total= file_get_contents('conver/'.$oid.'-'.$aid.'.txt');

if(!isset($_SESSION['num'])){

echo" <div class='login-box'><h3 class='variablecolor' >Please Login";

echo"<meta http-equiv='refresh' content='0;url=login.php'>";
return;
}
?>
<html>
<head> <meta charset="utf-8"> <title></title> <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap"> <link rel="stylesheet" href="cah.css"> <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script> <meta name="viewport" content="width=device-width"> </head>

<body>


<style>
table, th, td { width:60%;height:40px;
  border: 2px solid black; font-weight:bold;text-align:center;
  border-collapse: collapse; padding: 12px 20px; margin: 15px 0; 
}



hr{background-color:gold;  }
</style><br><br><center>
<h2> <font color="red">Total conversion:-0<?php echo $total; ?></font></h2>

<table><tr><th>aff_click_id</th><th>sub_aff_id</th><th>conversion</th></tr>
<?php echo $report; ?>

<hr></table>
</body>
</html>