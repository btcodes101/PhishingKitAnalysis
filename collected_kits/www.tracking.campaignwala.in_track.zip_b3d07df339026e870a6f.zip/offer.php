<?php
error_reporting(0);
session_start();

$session = $_SESSION['num'];

$json_object = file_get_contents('Aff/user'.$session.'.txt');

$o1=file_get_contents('offer/1.txt');
$o2=file_get_contents('offer/2.txt');
$o3=file_get_contents('offer/3.txt');
$o4=file_get_contents('offer/4.txt');
$o5=file_get_contents('offer/5.txt');
$o6=file_get_contents('offer/6.txt');
$o7=file_get_contents('offer/7.txt');
$o8=file_get_contents('offer/8.txt');
$o9=file_get_contents('offer/9.txt');
$o10=file_get_contents('offer/10.txt');



if(!isset($_SESSION['num'])){

echo" <div class='login-box'><h3 class='variablecolor' >Please Login";

echo"<meta http-equiv='refresh' content='0;url=login.php'>";
return;
}
?>
<html>
<head> <meta charset="utf-8"> <title></title> <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap"> <link rel="stylesheet" href="cah.css"> <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script> <meta name="viewport" content="width=device-width"> </head>

<body>


<style>
table, th, td { width:95%;height:50px;
  border: 2px solid black; font-weight:bold;text-align:left;
  border-collapse: collapse; padding: 12px 20px; margin: 15px 0; 
}

.logbtn{  width: 100%; height: 30px; border: 2px solid; background-color:#4BEBFA; font-weight:bold;background-size:100%; outline: 0px; none; cursor: pointer;  border-radius: 5px; margin-bottom: 0px; margin-top: 0px;}



.logbtn:hover{ background-position: right; cursor: pointer;}

hr{background-color:gold;  }
</style><br><br><center>
<h2> <font color="red">My offers</font></h2>
<hr>

<center>
<table>
  <tr>
    
  </tr>
  <tr>
    <td>Id</td>
    <td>Offer</td>
    <td>Payout</td>
    <td>Link</td>
  </tr>
  <?php echo $o1;
  
  echo $o2;
  echo $o3;
  echo $o4;
  echo $o5;
  echo $o6;
  
  ?>
  
  
</table>
<hr>
</body>
</html>