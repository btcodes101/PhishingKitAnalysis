<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="https://telegram.im/img/@Cashback_Boosters" type="image/x-icon" />
    <title>Campagin Adder Panel</title>
    <style>
    @import url('https://fonts.googleapis.com/css?family=Open+Sans:200,300,400,400i,500,600,700%7CMontserrat:300,400,500%7CRoboto');
    @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@700&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap');

    html{
         text-rendering: optimizeLegibility !important;
         -webkit-font-smoothing: antialiased;
         -moz-osx-font-smoothing: grayscale;
    }

    body{
        background: #5BFFE6;
        line-height: 1;
        webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    .form{
        position: relative;
        max-width: 420px;
        margin: 0 auto;
        margin-top: 30px;

    }
    h1,h2{
        font-size: 25px;
        font-weight: 400;
        color: black;
        max-width: 630px;
        margin: 0 auto;
        letter-spacing: 0;
        line-height: 1.6;
        margin-top: 10px;
        margin-bottom: 15px;
        font-family: 'Rajdhani', sans-serif;
    }
    h2{
        color: blue;
    }
    }
    p{
        font-size: 18px;
        font-weight: 400;
        color: black;
        max-width: 630px;
        margin: 0 auto;
        letter-spacing: 0;
        line-height: 1.6;
        margin-top: 10px;
        margin-bottom: 15px;
        font-family: 'Rajdhani', sans-serif;
    }

    .input{
        display: block;
        width: 100%;
        margin: 0 auto;
        color: #6d48e5;
        font-family: 'Montserrat';
        padding: 0;
        font-size: 13px;
        font-weight: 500;
        height: 50px;
        border: 1px solid #2C02FF;
        border-radius: 4px;
        background-color: #8FFFD3;
        outline: none;
        padding: 0 100px 0 5px;
        box-shadow: 0 5px 30px rgba(255, 255, 255, 0.1);
    }
    .submit{
        height: 50px;
        width: 100%;
        border: 0;
        border-radius: 4px;
        margin: 0 auto;
        margin: 15px 0;
        padding: 0 25px 0 25px;
        background: #077A3E;
        font-family: 'Montserrat';
        font-size: 14px;
        font-weight: 500;
        text-transform: capitalize;
        letter-spacing: 0;
        color: #FFFFFF;
        cursor: pointer;
        outline: none;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 100,.2);
    }
    .head{
        font-size: 25px;
        font-family: 'Roboto', sans-serif;
        margin-top: 40px;
        margin-bottom: 40px;
    }
    span{
        font-family: 'Montserrat';
        color: grey;
        font-size: 10px;
        font-weight: bolder;

    }
    .access{
        font-size: 20px;
    }
    font{
        font-family: 'Bree Serif', serif;
    }
    hr{
    border:0;height:2px;
    text-align: center;
    background-image:linear-gradient(to right,rgba(0,0,0,0),#047aed,rgba(0,0,0,0));
    }
    .font{
            font-family: 'Bree Serif', serif;
    font-size: 20px;
    color: blue;
    }
    #loader {
      border: 12px solid
      #047aed;
      border-radius: 50%;
      border-top: 12px solid black;
      width: 100px;
      height: 100px;
      text-align: center;
      animation: spin 1s linear infinite;
      z-index: 9999;
    }
    @keyframes spin {
      100% {
      transform: rotate(360deg);
       }
    }
    .center {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;
    }
    </style>
<body>
  <div id='loader'class='center'></div>
  <script>
      document.onreadystatechange = function() {
          if (document.readyState !== "complete") {
              document.querySelector(
                "body").style.visibility = "hidden";
              document.querySelector("#loader").style.visibility = "visible";
          } else {
              document.querySelector(
                "#loader").style.display = "none";
              document.querySelector(
                "body").style.visibility = "visible";
          }
      };
  </script>
    <center>
    <div class="form">
    <center>
            <div class='head'>
            <b>
            <h1 class='detial'>offer Adder Panel</h1>
            </center>
            </b>
            </div>
<hr><center><font class='search'>Web Devloper => <font color='red'>MR TECHNO</font></font></center><hr>

<?php

if(!isset($_GET['submit'])){
echo '<div class="form">
<form action="" method="GET" >
<select class="input" Required name="slot">
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option></option>
</select>
<input type="text" name="oid" class="input" placeholder="offer id"Required>

<input type="text" name="offer" class="input" placeholder="offer Name" Required>

<input type="text" name="model" class="input" placeholder="offer model" Required>

<input type="text" name="po" class="input" placeholder="Payout"Required>

<input type="text" name="camptrk" class="input" placeholder="Tracking link"Required>

<input type="submit" class="submit" name="submit" value="Add Campagin">';
  }


       if(isset($_GET['submit'])){
    $slot=$_GET['slot'];  	
    $oid=$_GET['oid'];
    $offer=$_GET['offer'];
    	$model=$_GET['model'];
       	$po=$_GET['po'];
       	$camptrk=$_GET['camptrk'];
       	
$a = mt_rand(100000,999999);
       	
       	$check="campdb/$campshrt";
       	if (file_exists($check)){
    echo "Campagin With Same Name Already Found Please Delete The $campname File Using Deleter Panel To Add New Campagin";
    
}else{
	
	$o=' <tr>
    <td>'.$oid.'</td>
    <td>'.$offer.'</td>
    <td>'.$po.'</td>
    <td><form action="trk.php" method="GET"><input type="hidden" name="oid" value="'.$oid.'"><input type="submit" class="logbtn" value ="Tracking Link" name="submit"></form></td>
  </tr>';
	
	
	$r=' <tr>
    <td>'.$oid.'</td>
    <td>'.$offer.'</td>
    <td>'.$po.'</td>
    <td><form action="data.php" method="GET"><input type="hidden" name="oid" value="'.$oid.'"><input type="submit" class="logbtn" value ="Report" name="submit"></form></td>
  </tr>';
	
	
	$data1="offer/$slot.txt";
$data2="repo/$slot.txt";
mkdir("offer/$oid");

$p='{"offer":"'.$offer.'","po":"'.$po.'","oid":"'.$oid.'","model":"'.$model.'","camptrk":"'.$camptrk.'"}';
 



file_put_contents($data1,$o);
file_put_contents($data2,$r);
 file_put_contents('offer/'.$oid.'/'.$oid.'.json', $p); 
echo"<br><br><center><font class='search'>Campagin Added Successfully";

}}

?>