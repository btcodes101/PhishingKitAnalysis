<?php
$id = $_GET['1'];
$id2=$_GET['2'];

 
$a='<tr><td>'.$id.'</td><td>'.$id2.'</td><td>1</td></tr></tr>';
	 
			$file=fopen("data.txt","a");
		fwrite($file,$a);
		fclose($file);
  
?>dn