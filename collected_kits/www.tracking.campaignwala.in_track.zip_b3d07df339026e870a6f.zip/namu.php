<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Campagin Deleter</title>
    <style>
    @import url('https://fonts.googleapis.com/css?family=Open+Sans:200,300,400,400i,500,600,700%7CMontserrat:300,400,500%7CRoboto');
    @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@700&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap');

    html{
         text-rendering: optimizeLegibility !important;
         -webkit-font-smoothing: antialiased;
         -moz-osx-font-smoothing: grayscale;
    }

    body{
        background: white;
        line-height: 1;
        webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    .form{
        position: relative;
        max-width: 420px;
        margin: 0 auto;
        margin-top: 30px;

    }
    h1,h2{
        font-size: 25px;
        font-weight: 400;
        color: black;
        max-width: 630px;
        margin: 0 auto;
        letter-spacing: 0;
        line-height: 1.6;
        margin-top: 10px;
        margin-bottom: 15px;
        font-family: 'Rajdhani', sans-serif;
    }
    h2{
        color: blue;
    }
    }
    p{
        font-size: 18px;
        font-weight: 400;
        color: black;
        max-width: 630px;
        margin: 0 auto;
        letter-spacing: 0;
        line-height: 1.6;
        margin-top: 10px;
        margin-bottom: 15px;
        font-family: 'Rajdhani', sans-serif;
    }

    .input{
        display: block;
        width: 100%;
        margin: 0 auto;
        color: #6d48e5;
        font-family: 'Montserrat';
        padding: 0;
        font-size: 13px;
        font-weight: 500;
        height: 50px;
        border: 1px solid #047aed;
        border-radius: 4px;
        background-color: #FFFFFF;
        outline: none;
        padding: 0 100px 0 5px;
        box-shadow: 0 5px 30px rgba(255, 255, 255, 0.1);
    }
    .submit{
        height: 50px;
        width: 100%;
        border: 0;
        border-radius: 4px;
        margin: 0 auto;
        margin: 15px 0;
        padding: 0 25px 0 25px;
        background: #047aed;
        font-family: 'Montserrat';
        font-size: 14px;
        font-weight: 500;
        text-transform: capitalize;
        letter-spacing: 0;
        color: #FFFFFF;
        cursor: pointer;
        outline: none;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 100,.2);
    }
    .head{
        font-size: 25px;
        font-family: 'Roboto', sans-serif;
        margin-top: 40px;
        margin-bottom: 40px;
    }
    span{
        font-family: 'Montserrat';
        color: grey;
        font-size: 10px;
        font-weight: bolder;

    }
    .access{
        font-size: 20px;
    }
    font{
        font-family: 'Bree Serif', serif;
    }
    hr{
    border:0;height:2px;
    text-align: center;
    background-image:linear-gradient(to right,rgba(0,0,0,0),#047aed,rgba(0,0,0,0));
    }
    .font{
            font-family: 'Bree Serif', serif;
    font-size: 20px;
    color: blue;
    }
    #loader {
      border: 12px solid
      #047aed;
      border-radius: 50%;
      border-top: 12px solid black;
      width: 100px;
      height: 100px;
      text-align: center;
      animation: spin 1s linear infinite;
      z-index: 9999;
    }
    @keyframes spin {
      100% {
      transform: rotate(360deg);
       }
    }
    .center {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;
    }
    </style>
<body>
  <div id='loader'class='center'></div>
  <script>
      document.onreadystatechange = function() {
          if (document.readyState !== "complete") {
              document.querySelector(
                "body").style.visibility = "hidden";
              document.querySelector("#loader").style.visibility = "visible";
          } else {
              document.querySelector(
                "#loader").style.display = "none";
              document.querySelector(
                "body").style.visibility = "visible";
          }
      };
  </script>
    <center>
    <div class="form">
    <center>
            <div class='head'>
            <b>
            <h1 class='detial'>Campagin Deleter</h1>
            </center>
            </b>
            </div>
<hr><center><font class='search'>Campagin <font color='red'>Deleter</font></font></center><hr>

<?php

error_reporting(0);

if(!isset($_POST['submit'])){
echo '<div class="form">
<form action="" method="POST" >

<select class="input" Required name="slot">
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option></option>
</select>


<input type="submit" class="submit" name="submit" value="Delete Campagin">';
  }


       if(isset($_POST['submit'])){
       	
    
    $id=$_POST['slot'];


 $files = glob('offer/'.$id.'.txt'); // get all file names
foreach($files as $file){ // iterate files
  if(is_file($file)) {
    unlink($file); // delete file
  }
}

$files1 = glob('repo/'.$id.'.txt'); // get all file names
foreach($files1 as $file1){ // iterate files
  if(is_file($file1)) {
    unlink($file1); // delete file
  }
}
echo '<script>alert("Deleted Successfully")</script>';

 }       
?>