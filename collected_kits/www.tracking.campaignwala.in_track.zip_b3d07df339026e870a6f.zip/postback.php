<?php
error_reporting(0);
session_start();

$session = $_SESSION['num'];

$json_object = file_get_contents('Aff/user'.$session.'.txt');


$aid=file_get_contents('Aff/aff_id/'.$session.'.txt');
$p=file_get_contents('postback/'.$aid.'.txt');


if(!isset($_SESSION['num'])){

echo" <div class='login-box'><h3 class='variablecolor' >Please Login";

echo"<meta http-equiv='refresh' content='0;url=login.php'>";
return;
}
?>

<html lang="en" dir="ltr"> <head> <title>Technocamp~affiliate</title><meta charset="utf-8"> <title></title> <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap"> <link rel="stylesheet" href="cah.css"><link rel="icon" type="image" href="techno.jpg"> <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script> <meta name="viewport" content="width=device-width"> </head> <body><center> <br><br><br><br> </div><div action="index.html" class="login-form"><br> <h2>Global Postback</h2><br>

<style> 
<?php function generateRandomString($length=10) { return substr(str_shuffle(str_repeat($x='abchde',ceil($length/strlen($x)))),1,$length); } 

$a='background-image: linear-gradient(135deg, #FCCF31 0%, #F55555 51%, #FCCF31 100%);';
$b='background-image: linear-gradient(135deg, #3C8CE7 0%, #00EAFF 51%, #3C8CE7 100%);';
$c='background-image: linear-gradient(135deg, #81FBB8 0%, #28C76F 51%, #81FBB8 100%);';
$d='background-image: linear-gradient(135deg, #F761A1 0%, #8C1BAB 51%, #F761A1 100%);';
$e='background-image: linear-gradient(135deg, #5EFCE8 0%, #736EFE 55%, #5EFCE8 100%);';

$h='background:linear-gradient( 135deg, #FF96F9 10%, #C32BAC 100%);';

$color=generateRandomString(1);

?>

@import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');*{ margin: 0; padding: 0; outline: 8px; box-sizing: border-box; font-family: 'Poppins', sans-serif;}body{ height: 115vh; width: 100%; <?php echo $$color ; ?>}




 .g-details{ background-color:#ffff ; border-radius:3px;width:89%; height:450;box-shadow: 0 0 4px black; border-radius: 1px;  padding: 10px; margin-left: 20px;margin-right: 20px;}
 
 .g-details input{ margin-bottom: 10px;}
 
.btn-grad { margin: 10px; padding: 15px 45px; text-align: center; text-transform: uppercase; transition: 0.5s; <?php echo $$color ; ?> background-size: 200% auto; color: white; box-shadow: 0 0 4px black; border-radius: 1px; display: block; font-family:Chakra Petch; }

.btn-grad:hover { background-position: right center; color: red; text-decoration: none; }

.field{ width:100%; border:3px; text-align: left; }

.login-form{ width: 95%; background: #ffffff; height:500px; padding: 15px; position:relative;margin-top: 50px;align:center; margin: 11px; align-content: center; align-items: center; border-radius: 1px; position: inherit; position:center; }


h1{ color:b; text-align: center; margin-top: 20px; margin-bottom: 20px; font-size: 38px; letter-spacing: 2px;m pzzi   font-family: 'Pushster', cursive; font-weight: 600; z-index: 100; }




.logbtn{ display: block; width: 70%; height: 50px; border: 1px solid; <?php echo $$color ; ?> background-size: 200%; color: #fff;font-weight:bold; outline: 70px;box-shadow: 0 0 4px black; none; cursor: pointer; transition: .5s; border-radius: 1px; margin-bottom: 15px; margin-top: 15px;}

.logbtn:hover{ background-position: right; cursor: pointer;}

input[type=text], select{ width: 95%; height: 50px; background-color: #ffffff; text-align: left; padding: 12px 20px; margin: 10px 0; display: inline-block; border: 2px solid black; border-radius:3px; } </style></body></html>
<style>
table, th, td { width:95%;height:50px;
  border: 2px solid black;text-align:left;
  border-collapse: collapse; padding: 12px 20px; margin: 10px 0; 
}
</style>

<br>


</body>
</html>

<form class="form" action="" method="post">
       <input type="text" name="pst"  placeholder="Enter postback url" required>
          
         
         
         <input type="hidden" name="email"  placeholder="Enter Your Email" required>
          
         
         
         <input type="hidden" name="num"  placeholder="Enter Mobile Number" required>
          
         
         <input type="hidden" name="tg"  placeholder="Enter telegram username" required>
          
         
         
                   <input type="hidden" id="adminpin" name="adminpin" value="1926">
          
         
          <button onclick="showmsg();" type="submit" id="submit" name="submit" class="logbtn" value="Submit">Update</button>
          
        
        </form>

        <script type="text/javascript">
  function showmsg()
  {

    var pin = "1926";
    var userName = document.getElementById('adminpin').value;
   

  if(userName == 1926) {
    swal("Good job!", "Login Success!", "success");
  }
  else{
    swal("Oops...", "Invalid credentials!", "error");
  }
}
</script>

  <script src="jquery-3.1.1.js"></script>
  <script src="js/bootstrap.min.js"></script>  
  
  
        <?php   
        error_reporting(0);
    if($_POST['submit']){

   $a = generateRandomString(8);
        $pwd= ''.$a.'';
        $pst=$_POST['pst'];
        $num=$_POST['num'];
        $tg=$_POST['tg'];
        $email=$_POST['email'];
        
        $adminpin=$_POST['adminpin'];
      $ip = $_SERVER['REMOTE_ADDR'];    
      $pin = "1926";

   $a1 = mt_rand(1000,9999);



      if ($adminpin == $pin)
      {
      
$data="postback/$aid.txt";




file_put_contents($data,$pst);




    echo '<script>alert("Postback Updated successfully")</script>';
 } 

else 
{
 echo "";
    }
  }
?> 
<br>

<p>current postback: <?php echo $p; ?></p>
<br><br>
 <p> Custom params {tid},{aff_click_id},{sub_aff_id},{offerid},{event}
</p>

       
       	</form><script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
  alert("Copied the text: " + copyText.value);
}
</script><br>
</body></html>