<?php
$s1=$_GET['s1'];
$s2=$_GET['s2'];
$aff=$_GET['s3'];
$oid=$_GET['s4'];
$event=$_GET['s5'];
$tid=$_GET['s6'];
$date = date('Y-m-d'); 

$add=file_get_contents("../conver/$oid-$aff.txt");
$adding='1';
$added=$add+$adding;
file_put_contents("../conver/$oid-$aff.txt",$added);


$add1=file_get_contents("../dconver/$date-$aff.txt");
$adding1='1';
$added1=$add1+$adding1;
file_put_contents("../dconver/$date-$aff.txt",$added1);



$a='<tr><td>'.$s1.'</td><td>'.$s2.'</td><td>1</td></tr></tr>';
	 
			$file=fopen("$oid-$aff.txt","a");
		fwrite($file,$a);
		fclose($file);

$postback=file_get_contents("../postback/$aff.txt");

$postback1='https://technocamp.co.in/bot.php?tid={tid}&a1={aff_click_id}&a2={sub_aff_id}&a4={offerid}';

$link= str_ireplace("{aff_click_id}",$s1,$postback);

$link2= str_ireplace("{sub_aff_id}",$s2,$link);

$link3= str_ireplace("{offerid}",$oid,$link2);


$link4= str_ireplace("{event}",$event,$link3);




$link5= str_ireplace("{tid}",$tid,$link4);

 
$url99=''.$link5.'';

$headers[]='user-agent: Mozilla/5.0 (Linux; Android 10; TECNO KE6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36';

$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url99);
curl_setopt($ch,CURLOPT_POST,1);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);


    $output1=curl_exec($ch);
    
    
    
    echo $output1;
    
    echo $link5;
  

?>