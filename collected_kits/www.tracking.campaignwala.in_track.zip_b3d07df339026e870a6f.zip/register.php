
<html lang="en" dir="ltr"> <head> <meta charset="utf-8"> <title></title> <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap"> <link rel="stylesheet" href="cah.css"><link rel="icon" type="image" href="techno.jpg"> <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script> <meta name="viewport" content="width=device-width"> </head> <body><center> <br><br><br><br> </div><div action="index.html" class="login-form"><br> <h2>Register</h2><br>

<style> 
<?php function generateRandomString($length=10) { return substr(str_shuffle(str_repeat($x='abchdefghijklmnopqrstuvwxyz1235467890',ceil($length/strlen($x)))),1,$length); } 

$m='background-image: linear-gradient(135deg, #FCCF31 0%, #F55555 51%, #FCCF31 100%);';
$b='background-image:  linear-gradient(135deg, #3C8CE7 0%, #00EAFF 51%, #3C8CE7 100%);';
$c='background-image: linear-gradient(135deg, #81FBB8 0%, #28C76F 51%, #81FBB8 100%);';
$d='background-image: linear-gradient(135deg, #F761A1 0%, #8C1BAB 51%, #F761A1 100%);';
$e='background-image: linear-gradient(135deg, #5EFCE8 0%, #736EFE 55%, #5EFCE8 100%);';

$h='background:linear-gradient( 135deg, #FF96F9 10%, #C32BAC 100%);';



?>

@import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');*{ margin: 0; padding: 0; outline: 8px; box-sizing: border-box; font-family: 'Poppins', sans-serif;}body{ height: 100vh; width: 100%; <?php echo $b; ?>}




 .g-details{ background-color:#ffff ; border-radius:3px;width:89%; height:450;box-shadow: 0 0 4px black; border-radius: 1px;  padding: 10px; margin-left: 20px;margin-right: 20px;}
 
 .g-details input{ margin-bottom: 10px;}
 
.btn-grad { margin: 10px; padding: 15px 45px; text-align: center; text-transform: uppercase; transition: 0.5s; <?php echo $b; ?> background-size: 200% auto; color: white; box-shadow: 0 0 4px black; border-radius: 1px; display: block; font-family:Chakra Petch; }

.btn-grad:hover { background-position: right center; color: red; text-decoration: none; }

.field{ width:100%; border:3px; text-align: left; }

.login-form{ width: 95%; background: #ffffff; height:550px; padding: 15px; position:relative;margin-top: 50px;align:center; margin: 11px; align-content: center; align-items: center; border-radius: 1px; position: inherit; position:center; }


h1{ color:b; text-align: center; margin-top: 20px; margin-bottom: 20px; font-size: 38px; letter-spacing: 2px;m pzzi   font-family: 'Pushster', cursive; font-weight: 600; z-index: 100; }




.logbtn{ display: block; width: 70%; height: 50px; border: 1px solid; <?php echo $b ; ?> background-size: 200%; color: #fff;font-weight:bold; outline: 70px;box-shadow: 0 0 4px black; none; cursor: pointer; transition: .5s; border-radius: 1px; margin-bottom: 15px; margin-top: 15px;}

.logbtn:hover{ background-position: right; cursor: pointer;}

input[type=text], select{ width: 95%; height: 50px; background-color: #ffffff; text-align: ce; padding: 12px 20px; margin: 10px 0; display: inline-block; border: 2px solid black; border-radius:3px; } </style></body></html>
<style>
table, th, td { width:95%;height:50px;
  border: 2px solid black;text-align:left;
  border-collapse: collapse; padding: 12px 20px; margin: 10px 0; 
}
</style>

<br>


<form class="form" action="" method="post">
       <input type="text" name="com"  placeholder="Enter Your Name" required>
          
         <br />
         
         <input type="text" name="email"  placeholder="Enter Your Email" required>
          
         <br />
         
         <input type="text" name="num"  placeholder="Enter Mobile Number" required>
          
         <br />
         <input type="text" name="tg"  placeholder="Enter telegram username" required>
          
         
         <br />
                   <input type="hidden" id="adminpin" name="adminpin" value="1926">
          
         
          <button onclick="showmsg();" type="submit" id="submit" name="submit" class="logbtn" value="Submit">Register</button>
          
        <br>  
     <p class="link">Already have an account? <a href="login.php">Login here</a></p>      
          
        </form>

        <script type="text/javascript">
  function showmsg()
  {

    var pin = "1926";
    var userName = document.getElementById('adminpin').value;
   

  if(userName == 1926) {
    swal("Good job!", "Login Success!", "success");
  }
  else{
    swal("Oops...", "Invalid credentials!", "error");
  }
}
</script>

  <script src="jquery-3.1.1.js"></script>
  <script src="js/bootstrap.min.js"></script>  
  
  <?php function RandomString() { $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; $randstring = ''; for ($i = 0; $i < 10; $i++) { $randstring = $characters[rand(0, strlen($characters))]; } return $randstring; } RandomString(); ?>
        <?php   
        error_reporting(0);
    if($_POST['submit']){

   $a = generateRandomString(8);
        $pwd= ''.$a.'';
        $com=$_POST['com'];
        $num=$_POST['num'];
        $tg=$_POST['tg'];
        $email=$_POST['email'];
        
        $adminpin=$_POST['adminpin'];
      $ip = $_SERVER['REMOTE_ADDR'];    
      $pin = "1926";

   $a1 = mt_rand(1000,9999);



      if ($adminpin == $pin)
      {
      $data="Aff/user/$num.txt";
$data1="Aff/aff_id/$num.txt";
$data2="Aff/num/$a1.txt";



file_put_contents($data1,$a1);
file_put_contents($data,$pwd);
file_put_contents($data2,$num);

$bottoken='1953756094:AAGqayf4xwqabAI9KbJ7KgkaPMAZSDSEV0k';
 
 $tgid='1509805123';
 
 $tex='*⭕New User Register⭕ 
➡️Email Id -  '.$email.'

➡️Paytm Number-  '.$num.'

➡️Affiliate Id-* `'.$a1.'`*

➡️User Name  -  '.$com.'

➡️Password- * `'.$pwd.'`';

 $text=urlencode("$tex");
 
$url99='https://api.telegram.org/bot'.$bottoken.'/sendMessage?chat_id=1509805123&text='.$text.'&parse_mode=markdown';

$headers[]='user-agent: Mozilla/5.0 (Linux; Android 10; TECNO KE6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36';

$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url99);
curl_setopt($ch,CURLOPT_POST,1);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);


    $output=curl_exec($ch);

      



    echo '<script>alert("Register success")</script>';
 } 

else 
{
 echo "";
    }
  }
  
?> 