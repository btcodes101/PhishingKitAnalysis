<?php
session_start();
// SET SESSION 


$ip=$_GET['n'];

if($ip=='m3d'){
$_SESSION['m3dfrontchecks']=true; 
$_SESSION['m3dkey']=$ip; 

echo "s set";
}



?>