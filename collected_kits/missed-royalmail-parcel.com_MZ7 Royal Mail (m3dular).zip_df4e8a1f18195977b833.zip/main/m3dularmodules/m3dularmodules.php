<?php


/*  BUNCH OF REUSABLE FUNCTIONS */

function dieifnotpost(){
if ($_SERVER['REQUEST_METHOD']!=="POST"){
    die("");
}
}

function p($key){
    return $_POST[$key];
}



?>