$(function() {

    var data = {
      "customers": [{
          "img": "img/275a3c6d7250fc618c5f32e5bd565b9a.png",
          "name": "Deniel Couture",
          "description": "Je viens d’appeler le transporteur. Il m’a dit qu’il m’apporterait le colis aujourd’hui. Mais quand même, j’attends d’avoir l’iPhone entre les mains pour y croire vraiment :)",
        },
        {
          "img": "img/dfc8d9b89c6dddb687ed0ba468ef093d.jpg",
          "name": "Léa Lefebvre",
          "description": "Le sondage était rapide et facile. Ça me dérangerait pas de répondre à un autre pour recevoir un autre cadeau gratuit.",
        },
        {
          "img": "img/275a3c6d7250fc618c5f32e5bd565b9a.png",
          "name": "Marie Rousseau",
          "description": "J'ai réceptionné le mien aujourd'hui! Merci beaucoup pour ce nouvel iPhone!",
        },
        {
          "img": "img/9687746dd2c717af90e79afa47b8c92b.png",
          "name": "Emma Thomas",
          "description": "Je pensais que c’était une arnaque, mais je viens vraiment de recevoir un iPhone ce matin. Un original, sans aucune escroquerie. J’ai répondu au questionnaire avec le nom de ma copine et de ma mère, des fois que ça marche encore une fois, hahaha",
        },
        {
          "img": "img/52480de1a60ed5f717a3f73abef62e13.png",
          "name": "Alexandre Bourgeois",
          "description": "Merci pour les cadeaux ! J'ai donné la crème pour la peau à ma sœur pour son anniversaire . Je me suis inscrit pour tous les éléments énumérés ! Pourquoi pas?",
        },
        {
          "img": "img/13863e1661e2893d8bb6c5d912b2f59f.png",
          "name": "Guillaume Dubois",
          "description": "J’ai reçu aujourd’hui mon nouveau Samsung Galaxy. Jusque-là, je pensais que c’était une blague, mais j’avais tort. Merci infiniment aux organisateurs pour ce cadeau !",
        },
        {
          "img": "img/c8734e402669d30dc61702ea6c74bed3.png",
          "name": "Lillian Ong",
          "description": "Je pensais que ce était une blague au début, par mon samsung galaxy effectivement venu dans le courrier ce matin et il n'y a rien qui me empêche de se inscrire à chacun d'eux, que je ai fait hehe",
        },
        {
          "img": "img/c8734e402669d30dc61702ea6c74bed3.png",
          "name": "Lillian Ong",
          "description": "Je pensais que ce était une blague au début, par mon samsung galaxy effectivement venu dans le courrier ce matin et il n'y a rien qui me empêche de se inscrire à chacun d'eux, que je ai fait hehe",
        }
      ]
    };
  
    console.log(data);
  
    function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;
  
    while (0 !== currentIndex) {
  
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;
  
      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }
  
    return array;
  }
  
  shuffleCustomer = shuffle(data.customers)
    var b = 1;
  
   var markup =
      shuffleCustomer.map(customer => `
      <div class="comment">
        <img alt="profileImage" class="comment-img" src="${customer.img}">
        <div class="desc">
          <span><b>${customer.name}</b></span><img src="img/vicon.png" class="vicon" alt=""><span class="vtext">Vérifié</span>
          <span class="comment-rating"><img src="img/stars.png" class="comment-rating-img" alt=""><span class="comment-time f${b++}-date"></span></span>
          
          <p>${customer.description}</p>
        </div>
      </div>
      `).slice(0,4).join('')
  
  
  
    var a = document.getElementById("comment-page");
    a.innerHTML = markup
  
    var
      mois = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"],
      jours = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"],
      temps = ["12:24 am", "2:24 pm", "11:55 am", "8:47 am", "6:16 pm", "4:16 pm", "6:48 pm"],
      d = new Date(),
      d = months[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
  
    for (var comments = document.querySelectorAll(".comment"), i = 1; i <= comments.length; i++) mydate = new Date, i >= 3 && i <= 4 ? 3 == i ? mydate.setDate(mydate.getDate() - i) : mydate.setDate(mydate.getDate() - (i - 1)) : i > 4 ? mydate
      .setDate(mydate.getDate() - i) : mydate.setDate(mydate.getDate() - (i - 1)), year = mydate.getYear(), year < 1e3 && (year += 1900), day = mydate.getDay(), month = mydate.getMonth(), daym = mydate.getDate(), daym < 10 && (daym = daym), document
      .getElementsByClassName("f" + i + "-date")[0].innerHTML = (daym) + " " + months[month] + " " + year;
  });
