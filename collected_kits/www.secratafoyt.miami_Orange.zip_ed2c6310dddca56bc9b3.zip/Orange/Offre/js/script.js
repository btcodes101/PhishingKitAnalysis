$(document).ready(function () {
    $(".remove_link").click(function () {
        var url = $(this).attr("id");

        var aff_id = "350353";
        var click_id = "525033156";
        var Brand = "1120";
        var lpid = "";
        var lpow = "38";

        url = replaceUrlParam(url, "s1", aff_id);
        url = replaceUrlParam(url, "s2", click_id);
        url = replaceUrlParam(url, "s3", Brand);
        url = replaceUrlParam(url, "s4", lpid);
        url = replaceUrlParam(url, "ow", lpow);

        window.open(url, "_blank");
    });
});

function replaceUrlParam(url, paramName, paramValue) {
    if (paramValue == null) {
        paramValue = "";
    }
    var pattern = new RegExp("\\b(" + paramName + "=).*?(&|#|$)");
    if (url.search(pattern) >= 0) {
        return url.replace(pattern, "$1" + paramValue + "$2");
    }
    url = url.replace(/[?#]$/, "");
    return url + (url.indexOf("?") > 0 ? "&" : "?") + paramName + "=" + paramValue;
}
