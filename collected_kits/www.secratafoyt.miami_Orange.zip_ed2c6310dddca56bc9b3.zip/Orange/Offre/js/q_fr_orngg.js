$( ".continue" ).click(function() {
	$(".modal-content").hide();
	$(".choices").show();
});


$( "#answers-1 .answerOption" ).click(function() {
	$("#answers-1").hide();
	$("#answers-2").show();
	$("#q").html('<b>Êtes-vous satisfait par Orange ?</b>');
	$('.progress li:first-child .circle').css('transform', 'scale(3)');
	$('.progress li:first-child').addClass('done');
	$('.progress li:first-child').removeClass('active');
	$('.progress li:nth-child(2)').addClass('active');
});

$( "#answers-2 .answerOption" ).click(function() {
	$("#answers-2").hide();
	$("#answers-3").show();
	$("#q").html('<b>Que préférez-vous chez Orange ?</b>');
	$('.progress li:nth-child(2) .circle').css('transform', 'scale(3)');
	$('.progress li:nth-child(2)').addClass('done');
	$('.progress li:nth-child(2)').removeClass('active');
	$('.progress li:nth-child(3)').addClass('active');
});

$( "#answers-3 .answerOption" ).click(function() {
	$("#answers-3").hide();
	$("#answers-4").show();
	$("#q").html("<b>Avez-vous déjà dû appeler l'assistance technique du Orange raison d'un problème ?</b>");
	$('.progress li:nth-child(3) .circle').css('transform', 'scale(3)');
	$('.progress li:nth-child(3)').addClass('done');
	$('.progress li:nth-child(3)').removeClass('active');
	$('.progress li:nth-child(4)').addClass('active');
});


$( "#answers-4 .answerOption" ).click(function() {
	$("#answers-4").hide();
	$("#answers-5").show();
	$("#q").html('<b>Comment évaluez-vous votre connexion Orange (y compris la fiabilité, la vitesse, les signaux occupés, la déconnexion, etc.) ?</b>');
	$('.progress li:nth-child(4) .circle').css('transform', 'scale(3)');
	$('.progress li:nth-child(4)').addClass('done');
	$('.progress li:nth-child(4)').removeClass('active');
	$('.progress li:nth-child(5)').addClass('active');
});


$( "#answers-5 .answerOption" ).click(function() {
	$("#answers-5").hide();
	$("#answers-6").show();
	$("#q").html('<b>Êtes-vous déjà resté(e) chez Orange pendant plus de 6 mois ?</b>');
	$('.progress li:nth-child(5) .circle').css('transform', 'scale(3)');
	$('.progress li:nth-child(5)').addClass('done');
	$('.progress li:nth-child(5)').removeClass('active');
	$('.progress li:nth-child(6)').addClass('active');
});

$( "#answers-6 .answerOption" ).click(function() {
	$("#answers-6").hide();
	$("#answers-7").show();
	$("#q").html('<b>A quel degré recommanderiez-vous Orange à un ami ?</b>');
	$('.progress li:nth-child(6) .circle').css('transform', 'scale(3)');
	$('.progress li:nth-child(6)').addClass('done');
	$('.progress li:nth-child(6)').removeClass('active');
	$('.progress li:nth-child(7)').addClass('active');
});

$( "#answers-7 .answerOption" ).click(function() {
	$("#answers-7").hide();
	$("#answers-8").show();
	$("#q").html("<b>D'après votre connaissance des services Orange, est-il mieux, identique ou pire que d'autres fournisseurs de services ?</b>");
	$('.progress li:nth-child(7) .circle').css('transform', 'scale(3)');
	$('.progress li:nth-child(7)').addClass('done');
	$('.progress li:nth-child(7)').removeClass('active');
	$('.progress li:nth-child(8)').addClass('active');
});



$( "#answers-8 .answerOption" ).click(function() {
	$(".comment-page,.footer,.choices").hide();
	$('#message-page').addClass('load');
	$('#message-page').html('<center>Envoi de vos réponses...</center>')
	$(".validate").show();

	setTimeout(function () {
		$("#v1a,#v1b").hide();
		$("#v1c,#v2b").show();
	}, 1500);
	setTimeout(function () {
		$("#v2a,#v2b").hide();
		$("#v2c,#v3b").show();
	}, 3500);
	setTimeout(function () {
		$("#v3a,#v3b").hide();
		$("#v3c,#vfinal").show();
	}, 4500);
	setTimeout(function () {
		$(".validate,#message-page").hide();
		$(".reward-page,.comment-page,.footer,#how_was_survey_text_container").show();

	}, 6000);
});
