<?php

/* Recipients, Supports multi values seperated by comma */
$penerima = 'inferno2chop@yahoo.com';
?>
