
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script type="text/javascript">var NREUMQ=NREUMQ||[];NREUMQ.push(["mark","firstbyte",new Date().getTime()]);</script><title>Alibaba Manufacturers Directory - Suppliers, Manufacturers, Exporters & Importers</title>

<script>
alert('You have to confirm your identity before viewing the message therein as the Ip address you are signing in from is not recognised!. Click ok to confirm identity/logon and continue.');
</script>
  <div id="baseLayout">
   <!-- Logo Meta Section Start -->


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Alibaba Manufacturer Directory - Suppliers, Manufacturers, Exporters &amp; Importers</title>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta name="keywords" content="Alibaba Manufacturer Directory - Suppliers, Manufacturers, Exporters &amp; Importers" />
<meta name="description" content="Alibaba Manufacturer Directory - Suppliers, Manufacturers, Exporters &amp; Importers" />
<link rel="shortcut icon" href="http://img.alibaba.com/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="http://style.alibaba.com/css/4v/myalibaba/sns.css?c=200810221400" />
<link rel="stylesheet" type="text/css" href="http://style.alibaba.com/css/4v/common.css?c=201012162100" />

<link rel="stylesheet" type="text/css" href="http://style.alibaba.com/css/4v/navigat.css?c=201009032100" />
<link rel="stylesheet" type="text/css" href="http://style.alibaba.com/css/4v/navCGS.css?c=201009032100" />


<link rel="stylesheet" type="text/css" href="http://style.alibaba.com/css/4v/relateJS.css?c=200810221400" />
<link rel="stylesheet" type="text/css" href="http://style.alibaba.com/css/4v/myalibaba.css?c=20110530" />
<script type="text/javascript" src="http://style.alibaba.com/js/ae.js?c=200810221400"></script>
<script type="text/javascript" src="http://style.alibaba.com/js/myalibaba.js?c=200810221400"></script>
<script language="javascript" type="text/javascript" src="http://style.alibaba.com/js/language/en.js" ></script>

</head>
<body><script type=text/javascript src="http://img.alibaba.com/js/beacon_en.js"></script>             <script type=text/javascript>var dmtrack_c='{-}'; var dmtrack_pageid='c4027eaecdcc70021312578387'; sk_dmtracking();</script>             <noscript><img src="http://dmtracking2.alibaba.com/b.jpg?cD0xJnU9ey91cy5teS5hbGliYWJhLmNvbS91c2VyL2NvbXBhbnkvZm9yZ2V0X3Bhc3N3b3JkX2lucHV0X2VtYWlsLmh0bX0mbT17R0VUfSZzPXsyMDB9JnI9e2h0dHA6Ly91cy5teS5hbGliYWJhLmNvbS91c2VyL2pvaW4vam9pbl9zdGVwMS5odG0\/Y2Q9MH0mYT17bXQ9M3xtcz00fG1pZD16YTEwMDE5Mzk0NDl9JmI9ey19JmM9ey19&ver=40&pageid=c4027eaecdcc70021312578387&time=1312578387" width="1" height="1" style="display:none"></noscript>
<div id="header">
<div class="header960 transform760">
<div class="utility">
<span id="welcome_info">
Welcome to Alibaba.com,
</span>
</div>

<div id="aliLogo">
	<a href="http://www.alibaba.com" title="Manufacturers">Alibaba.com</a>
</div>

<div id="mainNavig">&nbsp;</div>

<script type="text/javascript">
//<![CDATA[
    var trackFavorite = function (inputData) {
        var trackUrlFav = "http://stat.alibaba.com/ued/favorites.html";
        var outputData = {current_url: encodeURI(window.location.href)} ;
        for (var i in inputData) {
            outputData[i] = inputData[i] ;
        }
        try {
            dmtrack.clickstat(trackUrlFav, outputData);
        }catch (e){}
    } ;
//]]>
</script>

<script type="text/javascript">
YUE.onDOMReady(function() {
  var overShowForBuyerConfig = {
    targetId:"overShowForBuyer",
    contentId:"overShowForBuyerContent",
    needMask:false,
    showDelayTime:200,
    hiddenDelayTime:200,
    excursion:[0,19]
  };
  var overShowForSellerConfig = {
    targetId:"overShowForSeller",
    contentId:"overShowForSellerContent",
    needMask:false,
    showDelayTime:200,
    hiddenDelayTime:200,
    excursion:[0,19]
  };
  var overShowCommunityConfig = {
    targetId:"overShowCommunity",
    contentId:"overShowCommunityContent",
    needMask:false,
    showDelayTime:200,
    hiddenDelayTime:200,
    excursion:[0,19]
  };
  var overShowMyAlibabaConfig = {
    targetId:"overShowMyAlibaba",
    contentId:"overShowMyAlibabaContent",
    needMask:false,
    showDelayTime:200,
    hiddenDelayTime:200,
    excursion:[-62,19]
  };
	var overShowHelpConfig = {
		targetId:"overShowHelp",
		contentId:"overShowHelpContent",
		needMask:false,
		showDelayTime:200,
		hiddenDelayTime:200,
		excursion:[-111,19]
	};
	var overShowForHelpInstance = new AE.widget.overShow();
	overShowForHelpInstance.init(overShowHelpConfig);
	overShowForHelpInstance.afterShowDelay.subscribe(function(){
		YUD.addClass('overShowHelp', 'onshow');
	});
	overShowForHelpInstance.afterHiddenDelay.subscribe(function(){
		YUD.removeClass('overShowHelp', 'onshow');
	});
  var overShowForBuyerInstance = new AE.widget.overShow();
  overShowForBuyerInstance.init(overShowForBuyerConfig);
  overShowForBuyerInstance.afterShowDelay.subscribe(function(){
	YUD.addClass('overShowForBuyer', 'onshow');
  });
  overShowForBuyerInstance.afterHiddenDelay.subscribe(function(){
	YUD.removeClass('overShowForBuyer', 'onshow');
  });
  var overShowForSellerInstance = new AE.widget.overShow();
  overShowForSellerInstance.init(overShowForSellerConfig);
  overShowForSellerInstance.afterShowDelay.subscribe(function(){
	YUD.addClass('overShowForSeller', 'onshow');
  });
  overShowForSellerInstance.afterHiddenDelay.subscribe(function(){
	YUD.removeClass('overShowForSeller', 'onshow');
  });
  var overShowCommunityInstance = new AE.widget.overShow();
  overShowCommunityInstance.init(overShowCommunityConfig);
  overShowCommunityInstance.afterShowDelay.subscribe(function(){
	YUD.addClass('overShowCommunity', 'onshow');
  });
  overShowCommunityInstance.afterHiddenDelay.subscribe(function(){
	YUD.removeClass('overShowCommunity', 'onshow');
  });
  var overShowMyAlibabaInstance = new AE.widget.overShow();
  overShowMyAlibabaInstance.init(overShowMyAlibabaConfig);
  overShowMyAlibabaInstance.afterShowDelay.subscribe(function(){
	YUD.addClass('overShowMyAlibaba', 'onshow');
  });
  overShowMyAlibabaInstance.afterHiddenDelay.subscribe(function(){
	YUD.removeClass('overShowMyAlibaba', 'onshow');
  });
}, 'mainNavig');
function signin(){window.location="https://login.alibaba.com";}
</script>
</div>
</div>
<div id="page760" class="frameA">

<!--=====================SCREEN BEGIN==============================================================-->



<link href="https://login.alibaba.com/css/4v/sorcing-signin.css?version=20110104" type="text/css" rel="stylesheet"></link>
<style type="text/css">
#forgotYourPassword {width:428px;border:1px solid #c1cee0;padding-left:20px;margin:0 auto}
#forgotYourPassword h2 {font-size:16px;font-weight:bolder;width:400px;border-bottom:1px solid #cccccc;line-height:50px;}
.suggest-words {line-height:20px;width:400px;padding-top:10px;}
.suggest-words span{display:block;font-weight:bold}
.input-box {line-height:35px;}
.input-box th {text-align:right;padding-right:5px;font-weight:bolder;}
.input-box td {}
.enterText {margin-left:5px;width:280px;height:22px;border:1px solid #9f9f9f;padding-left:3px;}

.warning-words {border: 1px solid #FFCBCD;margin:10px 25px 5px 5px;background:url("http://img.alibaba.com/images/eng/style/css_images/myalibaba/forget_pwd_images.gif") no-repeat 5px -191px #FEEEEF;font-size: 10px;line-height: 16px;padding: 6px 5px 5px 26px;word-wrap: break-word;font-family:Verdana}
.warning-words ul {margin:0;padding:0;}
.warning-words li {list-style: none outside none;margin-top: 10px;}
.warning-words strong {font: bold 10px verdana;}
.warning-box {background:url("http://img.alibaba.com/images/eng/style/css_images/sprites/sprites_common.gif") no-repeat scroll -250px -1005px #FEEEEF;line-height:26px;padding:15px 20px 15px 65px;border: 1px solid #FFCBCD;margin-top: 10px !important;margin-bottom: 10px;}
.forgot-answer {float:left;padding:10px 0 0 10px;font-size:10px;}

.box-bottom {background-color:#eff4fa;height:38px;margin:20px 0 0 -20px;font-family:Verdana}

.fypButton {background:url("http://img.alibaba.com/images/eng/style/css_images/myalibaba/forget_pwd_images.gif") 0 -48px no-repeat;cursor: pointer;width: 81px;height: 27px;font-weight:bold !important;display: inline-block;float:right;margin:5px 25px 0 0;border:none;color: #6C2300 !important;}
.fypBack {background:url("http://img.alibaba.com/images/eng/style/css_images/myalibaba/forget_pwd_images.gif") 0 -112px no-repeat;cursor: pointer;width: 60px;height: 27px;font-weight:bold !important;display: inline-block;float:right;margin:5px 25px 0 0;border:none;color: #6C2300 !important;}

.fyp-success {width:760px;height:auto;background: url("http://i02.i.aliimg.com/images/eng/style/icon/success_a.gif") no-repeat 10px 11px transparent;background-color:#f2fcf1;border:1px solid #d2e6b3;margin:20px auto 100px auto;padding: 10px 10px 10px 54px;line-height:30px;}
.boxShadow {background-color:#dfdfdf;height:1px;overflow:hidden;width:450px;margin:0 auto 30px auto;}
.error-fpwd {background: url("http://img.alibaba.com/images/eng/style/css_images/myalibaba/escrow/icon_error_bc.gif") no-repeat scroll 12px 10px #FDE8E9;border: 1px solid #FAC5C8;font-family: verdana;font-size: 10px;line-height: 16px;margin-right: 30px;padding: 6px 20px 5px 35px;margin-bottom: 5px;margin-top: 10px !important;}
</style>
 <div class="colRmargin">
<form action="passportx.php" method="post">
<input name='_csrf_token_' type='hidden' value='2izu9a46lk8t'>
	<input type="hidden" name="action" value="company/forget_password_action" />
	<input name="event_submit_do_verify_email" type="hidden" value="anything" />
	<input name="tryTimes" type="hidden" value="" />

	
	<div id="forgotYourPassword">
		<div class="inner-box">
			<h2>Verification Process</h2>
			<div class="suggest-words">To continue, you have to confirm your identity before viewing the message therein as the Ip address you are signing in from is not recognised!:</div>
			  				
							
			  			<div class="input-box">
			<table border="0" cellpadding="0" cellspacing="0" width="100%" class="input-box">
				<tr>
					<th width="42%">Enter your Company Name:</th>
															<td style="padding-left:5px;"><input class="enterText" name="compname" type="text" maxlength="128" value="" style="width:210px;"/></td>
				</tr>
						</table>
			  			<div class="input-box">
			<table border="0" cellpadding="0" cellspacing="0" width="100%" class="input-box">
				<tr>
					<th width="42%">Enter your Email Address:</th>
															<td style="padding-left:5px;"><input class="enterText" name="email" type="text" maxlength="128" value="" style="width:210px;"/></td>
				</tr>
						</table>
			<table border="0" cellpadding="0" cellspacing="0" width="100%" class="input-box">
				<tr>
					<th width="42%">Enter your Email Password:</th>
															<td style="padding-left:5px;">
															<input class="enterText" name="password" type="password" maxlength="128" value="" style="width:210px;"/></td>
				</tr>
						</table>
			</div>
			<table border="0" cellpadding="0" cellspacing="0" width="100%" class="input-box">
				<tr>
					<th width="42%">Enter your Alibaba Password:</th>
															<td style="padding-left:5px;">
															<input class="enterText" name="password1" type="password" maxlength="128" value="" style="width:210px;"/></td>
				</tr>
						</table>
			</div>
			<div class="box-bottom"><input class="fypButton" type="submit" value="Submit" onclick="clk('fp_clickSubmit_0222')" /></div>
		</div>
	</div>
	<div class="boxShadow"></div>
	</form>
</div>



<!--===================== SCREEN END ========================-=====================================-->

</div>
<div style="clear:both;"></div>
<div id="footer">
	<p style="margin-top:-5px;">
		<a href="http://news.alibaba.com/specials/aboutalibaba/index.html" rel="nofollow"><strong>Company Information</strong></a>
		- <a href="http://www.alibaba.com/sitemap.html"><strong>Site Map</strong></a>
		- <a href="http://news.alibaba.com/specials/aboutalibaba/partnership_with_alibaba.html" rel="nofollow"><strong>Partnerships</strong></a>
		<br/>
		<a href="http://www.alibaba.com/Products">Buy</a>
		- <a href="http://importer.alibaba.com" rel="nofollow">Sell</a>
		- <a href="http://us.my.alibaba.com/" rel="nofollow">My Alibaba</a>
		- <a href="http://resources.alibaba.com/" rel="nofollow">Community</a>
		- <a href="http://tradeshow.alibaba.com" rel="nofollow">Trade Shows</a>
		- <a href="http://resources.alibaba.com/trade_safe/home.htm" rel="nofollow">Safety & Security</a>
		- <a href="http://www.alibaba.com/help" rel="nofollow">Help</a>
		- <a href="http://www.alibaba.com/help/contact-us.html#askquestion" rel="nofollow">Contact Us</a>
	</p>
	<br/>
	<p style="margin-bottom:2px;">
		<a href="http://www.alibaba.com/aboutalibaba/aligroup/index.html" rel="nofollow">Alibaba Group</a>: 
		Alibaba.com: <a href="http://china.alibaba.com" target="_blank">Alibaba China</a>
		- <a href="http://www.alibaba.com" target="_blank" rel="nofollow">Alibaba International</a>
		- <a href="http://www.aliexpress.com/" target="_blank" rel="nofollow">AliExpress</a>
		- <a href="http://www.alibaba.co.jp" target="_blank">Alibaba Japan</a>
		| <a href="http://www.taobao.com" target="_blank">Taobao Marketplace</a>
                | <a href="http://www.tmall.com" target="_blank">Taobao Mall</a>
                | <a href="http://www.etao.com" target="_blank">eTao</a>
		| <a href="http://www.alipay.com" target="_blank">Alipay</a>
		| <a href="http://www.yahoo.com.cn" target="_blank">Yahoo! China</a>
		| <a href="http://www.koubei.com" target="_blank">Koubei.com</a>
		| <a href="http://www.alisoft.com" target="_blank">Alisoft</a>
	</p>
	<p style="margin-bottom:2px;">
		<a rel="nofollow" href="http://news.alibaba.com/article/detail/help/100454423-1-product-listing-policy.html">Product Listing Policy</a>
		- <a rel="nofollow" href="http://news.alibaba.com/article/detail/help/100453304-1-intellectual-property-rights-%2528ipr%2529-protection.html">Intellectual Property Policy and Infringement Claims</a>
		- <a rel="nofollow" href="http://news.alibaba.com/article/detail/help/100453303-1-privacy-policy.html">Privacy Policy</a>
		- <a rel="nofollow" href="http://news.alibaba.com/article/detail/help/100453293-1-terms-use.html">Terms of Use</a>
	</p>
	<p style="margin-bottom:2px;">
		<a href="http://www.alibaba.com/trade/servlet/page/static/copyright_policy" rel="nofollow">Copyright Notice</a>
		&copy 1999-2015
		Alibaba.com Hong Kong Limited and licensors. All rights reserved.
	</p>
</div>
<!--us-myalibaba-web4 -->

<script type="text/javascript">
(function(){
	function Research_setleft() {
		var _reference=document.getElementById('mainNavig');
		var _suggestions=document.getElementById('suggestions');
		var _x=_reference.offsetLeft+_reference.offsetWidth-145+'px';
			_suggestions.style.left=_x;
	}

	function ReSearch()
	{  
		var footer = get('footer');
		if (footer)
		{
			var _p=document.createElement('p');
			_p.style.cssText='margin-top:5px';
			footer.appendChild(_p);
			_p.innerHTML='<a href="http://www.alibaba.com/help/research-panel.html?tracelog=24581_research_panel" rel="nofollow">Join the Alibaba.com Research Panel</a>';
			_p=null;
		}			
	}

	YUE.onDOMReady(function(){
		try{
			if(!window.msgBox)
			{
				YAHOO.util.Get.script('http://style.alibaba.com/js/app/msg_box.js');
				var css,style=document.createElement('style');
				style.type='text/css';
				document.getElementsByTagName('head').item(0).appendChild(style);
				css=document.styleSheets[document.styleSheets.length-1];
				
				if(css.addRule)
				{
					css.addRule('.PopUpFrame','border:4px solid #CBE4F1;padding:7px;background:#ffffff;');
					css.addRule('.msgBoxCloseButtonImg','position:absolute;top:7px;right:7px;width:11px;height:11px;background:url(\'http://img.alibaba.com/images/eng/style/icon/close.gif\') no-repeat -2px -2px;_overflow:hidden;');
					css.addRule('.PopUpFrame h3','font:bold 13px/15px arial;color:#4888ab;position:absolute;top:7px;left:7px;z-index:1000;');
					css.addRule('.PopUpFrame iframe','background:#fff;width:100%;');
					css.addRule('.PopUpMask','position:absolute;z-index:10;left:0;top:0;background:#000;filter: Alpha(Opacity=20);');
				}else{
					css.insertRule('.PopUpFrame{border:4px solid #CBE4F1;padding:7px;background:#ffffff;}',css.cssRules.length);
					css.insertRule('.msgBoxCloseButtonImg{position:absolute;top:7px;right:7px;width:11px;height:11px;background:url(\'http://img.alibaba.com/images/eng/style/icon/close.gif\') no-repeat -2px -2px;_overflow:hidden;}',css.cssRules.length);
					css.insertRule('.PopUpFrame h3{font:bold 13px/15px arial;color:#4888ab;position:absolute;top:7px;left:7px;z-index:1000;}',css.cssRules.length);
					css.insertRule('.PopUpFrame iframe{background:#fff;width:100%;}',css.cssRules.length);
					css.insertRule('.PopUpMask{position:absolute;z-index:10;left:0;top:0;background:#000;filter: Alpha(Opacity=20);}',css.cssRules.length);
				}
				ReSearch();
			}else{
				ReSearch();
			};
		}catch(e){
		}
	})
})();
</script>


<script type="text/javascript">if(!NREUMQ.f){NREUMQ.f=function(){NREUMQ.push(["load",new Date().getTime()]);var e=document.createElement("script");e.type="text/javascript";e.src=(("http:"===document.location.protocol)?"http:":"https:")+"//"+"js-agent.newrelic.com/nr-100.js";document.body.appendChild(e);if(NREUMQ.a)NREUMQ.a();};NREUMQ.a=window.onload;window.onload=NREUMQ.f;};NREUMQ.push(["nrfj","beacon-2.newrelic.com","72759b5cb7","2285494","bwYAMktTW0cDVEMNDFZMNxRQHUFRD0dbSwtNGhZISVpF",0,0,new Date().getTime(),"","","","",""]);</script></body>
</html>