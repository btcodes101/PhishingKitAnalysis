<?php
if(empty($_POST['imie'])&& empty($_POST['natow'])){
?>
<div style="background: #eceff1;" >
<form action="szablony/podziekowanie.php" method="POST">

<div style="background: #eceff1;" >
<br><center><div style="text-align: left; width: 450px; background: white; padding-left: 10px;margin-bottom: 7px;">
<div style="font-size: 23px;padding-bottom: 10px;padding-top: 15px;color: #ff6511;font-family: fantasy;"><b>allegro</b></div>
<span style="font-size: 23px;">Cześc <input type="text" name="imie" placeholder="Imie kupującego" required></span><br>
<div style="padding-bottom: 10px;">Kupiłeś <input style="width: 40px;" type="text" name="natow" placeholder="ilość" required> Przedmiot od <input type="text" name="odkogo" placeholder="nazwę sprzedającego" required></div>
</span></center>

<center><div style="text-align: left; width: 450px; background: white;padding-left: 10px;"><br>
<b style="font-size: 19px;">Metoda płatności</b><br>
<select  name="platnosc">
  <option value="Karta">Karta</option>
  <option value="BLIK">BLIK</option>
  <option value="Przelew">Przelew</option>
  <option value="Poczta polska">Poczta polska</option>
</select><br><br>

<b style="font-size: 19px;">numer zamówienia</b><br>
nr <input type="text" name="nrzam" placeholder="Podaj nr zamówienia" required><br><br>

<b style="font-size: 19px;">Dane odbiorcy</b><br> 
<input type="text" name="doimie" placeholder="Podaj imie i nazwisko" required><br> 
<input type="text" name="douli" placeholder="Podaj ulice" required><br> 
<input type="text" name="kodim" placeholder="Podaj kod pocztowy i miasto" required><br> 
<input type="text" name="nrte" placeholder="Podaj numer telefonu" required><br><br>

<b style="font-size: 19px;">Dane sprzedającego</b><br>
<input type="text" name="spimie" placeholder="Podaj imie i nazwisko" required><br> 
<input type="text" name="douli" placeholder="Podaj ulice" required><br>
<input type="text" name="pdoim" placeholder="Podaj kod pocztowy i miasto" required><br> 
<input type="text" name="nrteel" placeholder="Podaj numer telefonu" required> <br><br>

Pozdrawiamy<br> 
Allegro<br><br>
</div></center><br>
</div></div>
<br><center><input type="submit" value="pokaż"><br><br></center></form>
<?php
}
if(isset($_POST['imie'])&& isset($_POST['natow'])){
$cimie = $_POST['imie'];

$natowa = $_POST['natow'];
$odkog = $_POST['odkogo'];

$platnosci = $_POST['platnosc'];

$nrza = $_POST['nrzam'];

$dimie = $_POST['doimie'];
$doulic = $_POST['douli'];
$kodima = $_POST['kodim'];
$nrtel = $_POST['nrte'];

$spimiei = $_POST['spimie'];
$doulic = $_POST['douli'];
$pdoima = $_POST['pdoim'];
$nrteeli = $_POST['nrteel'];

$wiadomosc = '
<div style="background: #eceff1;" >
<br><center><div style="text-align: left; width: 450px; background: white; padding-left: 10px;margin-bottom: 7px;">
<div style="font-size: 23px;padding-bottom: 10px;padding-top: 15px;color: #ff6511;"><b>allegro</b></div>
<span style="font-size: 23px;">Cześc '.$cimie.'</span><br> 
<div style="padding-bottom: 10px;">Kupiłeś '.$natowa.' Przedmiot od <span style="color: #00a790;" >'.$odkog.'</span></div>
</div></center>

<center><div style="text-align: left; width: 450px; background: white;padding-left: 10px;"><br>
<b style="font-size: 19px;">Metoda płatności</b><br>
'.$platnosci.'
<br><br><b style="font-size: 19px;">numer zamówienia</b><br>
nr '.$nrza.'<br><br>

<b style="font-size: 19px;">Dane odbiorcy</b> <br>
'.$dimie.'<br> 
'.$doulic.'<br> 
'.$kodima.'<br> 
'.$nrtel.'<br><br>

<b style="font-size: 19px;">Dane sprzedającego</b><br>
'.$spimiei.'<br> 
'.$doulic.'<br>
'.$pdoima.'<br> 
'.$nrteeli.'<br><br>

Pozdrawiamy<br> 
Allegro <br><br>
</div></center>
<br></div>
';
?>
<center><div style="border: 1px solid black; width: 700px;" >
<?php
echo $wiadomosc;
?>
</div></center>
<?php
echo "<center><html><form action='../index.php' method='POST'><input type='hidden' name='wiadomosc' value='".$wiadomosc."'><input type='hidden' name='odkogo2' value='@allegromail.pl'><input type='hidden' name='temat2' value='przedmiot'><input type='submit' value='Wyśli'></form></html></center>";
echo "<center><html><form action='../index.php' method='POST'><input type='hidden' name='wzor' value='szablony/podziekowanie.php'><input type='submit' value='Popraw'></form></html></center>";
}

?>