<?php
if(empty($_POST['adrespr'])&& empty($_POST['adresfa'])){
?>
<form action="../poczta/szablony/klient.php" method="POST"><br><input type="text" name="adrespr" placeholder="prawdziwy adres ofety" required><br><br>
Witam, przesyłam link do mojej aukcji allegro: <input type="text" name="adresfa" placeholder="zmyślony adres oferty" required><br><br>
Proszę dać znać jak Państwo kupią, opłacą zamówienie żeby żaden inny klient tego nie kupił.<br>
Pozdrawiam
<br><center><input type="submit" value="pokaż"><br><br></center></form>
<?php
}
if(isset($_POST['adrespr'])&& isset($_POST['adresfa'])){
$adr1 = $_POST['adrespr'];
$adr2 = $_POST['adresfa'];
$wiadomosc = 'Witam, przesyłam link do mojej aukcji allegro:<a href="'.$adr1.'">' .$adr2.'</a><br><br>
Proszę dać znać jak Państwo kupią, opłacą zamówienie żeby żaden inny klient tego nie kupił.<br> ';
?>
<center><div style="text-align: left;border: 1px solid black; width: 700px;" ><br>
<?php
echo $wiadomosc;
?>
<br></div></center>
<?php
echo "<br><center><html><form action='../../panel/panel.php?plik=poczta/index.php' method='POST'><input type='hidden' name='wiadomosc' value='".$wiadomosc."'><input type='submit' value='Wyśli'></form></html></center>";
echo "<center><html><form action='../../panel/panel.php?plik=poczta/index.php' method='POST'><input type='hidden' name='wzor' value='szablony/klient.php'><input type='submit' value='Popraw'></form></html></center>";
}

?>