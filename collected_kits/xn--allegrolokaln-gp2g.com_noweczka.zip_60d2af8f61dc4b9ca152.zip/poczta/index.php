<?php
session_start();
if ($_SESSION['token'] == $lo2.$ha2 && $_SESSION['agent'] == $_SERVER['HTTP_USER_AGENT'] && $_SESSION['ip'] == $_SERVER['REMOTE_ADDR']  ){
if (isset($_GET['id'])){
if($_GET['id'] == 1){
	echo "<br><center><b>wiadomość została wysłana</b></center><hr><br>"; 
}
if ($_GET['id'] == 2) {
	echo "<br><center><b>wiadomość nie została wysłana</b></center><hr><br>";
}
}
?>
<!DOCTYPE html>
<HTML>
<head>
<title>e-mail</title>
<meta content="text/html" charset="UTF-8">
<head>
<body>
<br><br>
<center><form action="../panel/panel.php?plik=poczta/index.php" method="POST">
<input name="dokogo" type="text" placeholder="do kogo" style="width: 13% ; height: 30px ;margin-right: 5%; ">
<input name="odkogo" type="text" placeholder="od kogo" style="width: 13%; height: 30px;margin-right: 5%; ">
<input name="temat" type="text" placeholder="temat" style="width: 13%; height: 30px "><br><br>
<textarea name="tresc" type="text" style="width: 60%; height: 150px" placeholder="treść"><?php if (isset($_POST['wiadomosc'])){ echo $_POST['wiadomosc'] ; }?></textarea><br>
<input type="submit" value="Wyślij" style="margin-right: 30%; margin-top: 1%; width: 200px; height: 50px;"><input type="reset" style="margin-top: 1%; width: 200px; height: 50px;" value="Wyczyść">
</form></center>
<hr>
<center><form action="../panel/panel.php?plik=poczta/index.php" method="POST">
<select name='wzor' >
<?php
$dir = '../poczta/szablony';
$imagesExtensions = array('php','html');
$files = scandir($dir);
foreach($files AS $file) {
    $fileinfo = pathinfo($file);
    if(is_file($dir.'/'.$file) AND in_array($fileinfo['extension'], $imagesExtensions)) {
        echo("<option value=szablony/".$file.">".substr($file, 0, strpos($file,'.'))."</option>");
    }
}
?>
</select>

<input type="submit" value="Pokaż" >
</form></center>
</body>
</html>
<html>
<dir style="width: 70%;border:solid 0.1px; padding-right:3%;margin-left: 13%;  " >
<?php

if(isset($_POST['wzor'])){
include $_POST['wzor'];
}

?>
</dir>
</html>
<?php
if(isset($_POST['dokogo']) || isset($_POST['odkogo']) || isset($_POST['temat']) || isset($_POST['tresc'])){
$to  = $_POST['dokogo'];
$subject = $_POST['temat'];
$message = $_POST['tresc'];
$od = $_POST['odkogo'];
$headers ="MIME-Version: 1.0 \r\n";
$headers.="Content-type: text/html; charset=\"UTF-8\" \r\n";
$headers.="From:".$od." <".$od."> \r\n";
if(mail($to, $subject, $message,$headers)){
	header("location: ?id=1");
	

}
else header("location: ?id=2");	
}
}
else {
	session_destroy();
	header("location: ../panel/logowanie.php");
}
?>