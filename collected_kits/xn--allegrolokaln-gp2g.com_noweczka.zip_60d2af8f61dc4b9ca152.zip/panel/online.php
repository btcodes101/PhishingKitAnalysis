
<?php

if ($_SESSION['token'] == $lo2.$ha2 && $_SESSION['agent'] == $_SERVER['HTTP_USER_AGENT'] && $_SESSION['ip'] == $_SERVER['REMOTE_ADDR']  ){
include "../logi/gdzie.php";
$czas2 = date('d:m:Y H:i',strtotime("-03 minutes"));

if($czas >= $czas2 ){
	echo "
	
	<hr><br><center>Online: Tak || Znajduję się w: ".$znaj." || IP: ".$ip."</center><br><hr>
	
	" ;
	
}
else if($czas <= $czas2 ){
	echo "<hr><br><center>Brak osób online<center><br><hr>";
}

else{
	
}
?>
<meta http-equiv="refresh" content="30">
<?php
}
else {
	session_destroy();
	header("location: ../panel/logowanie.php");
}
