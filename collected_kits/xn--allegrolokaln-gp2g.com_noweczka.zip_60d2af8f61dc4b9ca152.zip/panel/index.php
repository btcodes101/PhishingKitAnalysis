<?php
if ($_SESSION['token'] == $lo2.$ha2 && $_SESSION['agent'] == $_SERVER['HTTP_USER_AGENT'] && $_SESSION['ip'] == $_SERVER['REMOTE_ADDR']  ){
	
	header("location: panel.php");
}
else {
	session_destroy();
	header("location: logowanie.php");
}
	?>