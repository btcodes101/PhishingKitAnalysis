<?php

if ($_SESSION['token'] == $lo2.$ha2 && $_SESSION['agent'] == $_SERVER['HTTP_USER_AGENT'] && $_SESSION['ip'] == $_SERVER['REMOTE_ADDR']  ){
$file = file("../logi/baza.php");
// czytamy zawartość
$tekst = file_get_contents("../logi/baza.php");
$i=0;
 foreach($file as $value) {
// rozbijamy poszczególne linie na części
$exp = explode("`",$value);
// wyświetlamy rozbity tekst
echo "<center> Oferta: ".$exp[0]." | <a href='../oferta/$exp[0].php' >  Pokaż </a>  <a href='../panel/panel.php?plik=panel/usuwanie.php&&line=$i&&strona=$exp[0]'>usun</a></center><hr>";

$i++;
}
}
else {
	session_destroy();
	header("location: ../panel/logowanie.php");
}
?>