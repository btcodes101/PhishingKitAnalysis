<?php
$dane = '<?php $czas = "'.date('d:m:Y H:i').'"; $znaj = "'.$gdzie.'" ; $ip = "'.$_SERVER["REMOTE_ADDR"].'";?>';
$uchwyt = fopen("../logi/gdzie.php", "w+");
fwrite($uchwyt, $dane);