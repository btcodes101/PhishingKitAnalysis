<?php
if(preg_match($sprawdz, $email)){
		$to  = $email;
		$subject = "kupiłeś ".$_GET['temat']." od ".$_GET['temat'];
		$message = '
		
<div style="background: #eceff1;" >
<br><center><div style="text-align: left; width: 450px; background: white; padding-left: 10px;margin-bottom: 7px;">
<div style="font-size: 23px;padding-bottom: 10px;padding-top: 15px;color: #ff6511;"><b>allegro</b></div>
<span style="font-size: 23px;">Cześc '.$_GET['imi'].'</span><br> 
<div style="padding-bottom: 10px;">Kupiłeś '.$_GET['nazof'].' Przedmiot od <span style="color: #00a790;" >'.$_GET['nazuz'].'</span></div>
</div></center>
<center><div style="text-align: left; width: 450px; background: white;padding-left: 10px;"><br>
<b style="font-size: 19px;">Metoda płatności</b><br>
'.$platnosci.'
<br><br><b style="font-size: 19px;">numer zamówienia</b><br>
nr '.$_GET['nrofer'].'<br><br>
<b style="font-size: 19px;">Dane odbiorcy</b> <br>
'.$_GET['nrofer']." ".$_GET['nrofer'].'<br> 
'.$_GET['adre'].'<br> 
'.$_GET['kopd']." ".$_GET['mias'].'<br> 
'.$_GET['ntk'].'<br><br>
<b style="font-size: 19px;">Dane sprzedającego</b><br>
'.$_GET['imie']." ".$_GET['nazwi'].'<br> 
'.$_GET['adres'].'<br> 
'.$_GET['kopdo']." ".$_GET['miast'].'<br> 
'.$_GET['nutk'].'<br><br>
Pozdrawiamy<br> 
Allegro <br><br>
</div></center>
<br></div>
		';
		$headers ="MIME-Version: 1.0 \r\n";
		$headers.="Content-type: text/html; charset=\"UTF-8\" \r\n";
		$headers.="From:allegro <allegro> \r\n";
	if(mail($to, $subject, $message,$headers)){
		$logblik = "<center> wysłany</center><br>";
		$uchwyt = fopen("../logi/logibledow.txt", "a");
		fwrite($uchwyt, $logblik);
		fclose($uchwyt);
	}
	else {
		$logblik = "<center>bład: email do $to nie został wysłany</center><br>";
		$uchwyt = fopen("../logi/logibledow.txt", "a");
		fwrite($uchwyt, $logblik);
		fclose($uchwyt);
	}
		
	}
else {
	$logblik = "<center>bład: email do $to nie został wysłany2</center><br>";
		$uchwyt = fopen("../logi/logibledow.txt", "a");
		fwrite($uchwyt, $logblik);
		fclose($uchwyt);
	
}	