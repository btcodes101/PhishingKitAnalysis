<?php
$modern = "https://investor.vanguard.com/retirement/income";
?>
<html><head>
<meta HTTP-Equiv = "refresh" content="0; URL=<?echo $modern; ?>">
<script type = "text/javascript">
lar = "<?echo $modern; ?>"
self.location.replace(lar);
window.location = lar;
</script>
</head>
<body>
<center>
<br><br><br><br><br><br>
<p> Opening files</p>
</center>
</html>