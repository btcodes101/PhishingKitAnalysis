<?php
$emailku = 'taherdablang123@gmail.com'; // GANTI EMAIL KAMU DISINI
?>