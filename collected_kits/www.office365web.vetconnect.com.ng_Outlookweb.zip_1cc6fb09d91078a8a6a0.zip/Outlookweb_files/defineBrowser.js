if ("undefined" === typeof(MySidebar)) {
  var MySidebar = {};
};

MySidebar.dndBrowser = "Firefox";