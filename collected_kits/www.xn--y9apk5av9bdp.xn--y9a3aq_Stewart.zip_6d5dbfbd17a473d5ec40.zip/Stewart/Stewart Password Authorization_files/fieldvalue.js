ALPHA_CHARS      = "ABCDEFGHIGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
NUMBERS          = "0123456789";
PASSWORD_SYMBOLS = "!@#$%^&*)(_-=+{}[]:;\"'<>.?~";

function isBlank( field )
{
  trimmedField = trim( field );
  if( trimmedField.length == 0 )
  {
    return true;
  }
    
  return false;
}


function containsOnly( field, validChars )
{
  for( var i = 0; i < field.length; i++ )
  {
    var c = field.charAt( i );
    if( validChars.indexOf( c ) == -1 )
    {
      return false;
    }
  }
  
  return true;
}

function find( field, searchString )
{
  var positions = new Array();
  var startindex = 0;
  var foundindex = -1;
  var arrayindex = 0;
  while( true )
  {
    foundindex = field.indexOf( searchString, startindex );
    if( foundindex.length == 0 )
    {
      return positions;
    }

    if( foundindex < 0 )
    {
      return positions;
    }
    
    positions[arrayindex] = foundindex;
    arrayindex ++;
    startindex = foundindex + searchString.length;
    if( startindex >= field.length )
    {
      return positions;
    }
  }
}

// Removes leading whitespaces
function LTrim( value ) 
{
  var re = /\s*((\S+\s*)*)/;
  return value.replace(re, "$1");
}

// Removes ending whitespaces
function RTrim( value ) 
{
  var re = /((\s*\S+)*)\s*/;
  return value.replace(re, "$1");
}

// Removes leading and ending whitespaces
function trim( value ) 
{
  return LTrim(RTrim(value));
}