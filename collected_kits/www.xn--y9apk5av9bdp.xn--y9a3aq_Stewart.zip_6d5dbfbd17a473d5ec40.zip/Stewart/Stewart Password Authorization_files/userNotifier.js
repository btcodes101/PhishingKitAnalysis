function issueClientWarning(inlineWarningText, elementID, displayInline)
{
    issueInlineAlert(inlineWarningText, elementID, false);
}

function issueServerWarning(inlineWarningText, elementID, displayInline)
{
  issueInlineAlert(inlineWarningText, elementID, false);
}

function issueClientLoginWarning(inlineWarningText, elementID, displayInline)
{
  issueInlineAlert(inlineWarningText, elementID, displayInline);
}

function issueInlineAlert(text, elementID, displayInline)
{
	if(text == null || text == "null")
    {
        return;
    }
	var displayText = trim(text);
    if(displayText == "")
    {
        return;
    }

    if( displayInline )
    {
      document.getElementById(elementID).innerHTML = '<div id="errortext">' + displayText + '</div>';
    }
    else
    {
      alert(displayText);
    }
}


function updateLastAction(text,isPositive)
{
    var div = document.getElementById('lastaction');
    div.style.position="";
    div.style.left="";
    div.setAttribute("class", isPositive ? "positive_action" : "negative_action");
    div.style.transition="";
    div.style.opacity=100;
    	div.innerHTML = text
    div.appendChild(createCloseSpan());
    clearTimeout(div.zixtimeout);
    var timeout = setTimeout(function()
    {
      var div = document.getElementById('lastaction');
      div.style.transition = "opacity 3s ease-out";
      div.style.opacity = "0";
      var move = setTimeout(function() { var elem = document.getElementById('lastaction'); elem.style.position='absolute'; elem.style.left='-999em';},3000);
      div.zixtimeout=move;
     },7000);
    div.zixtimeout=timeout;
}

function createCloseSpan()
{	
  var closeSpan = document.createElement('span');
  closeSpan.setAttribute("id","closelastaction");
  closeSpan.innerHTML = "x";
  closeSpan.onclick=function() { this.parentElement.parentElement.removeChild(this.parentElement); return false; };
  return closeSpan
}

function displayLastAction(siblingId,text, isPositive)
{
   if(document.getElementById("lastaction")!=null) { updateLastAction(text,isPositive); return; }
   var sibling = document.getElementById(siblingId);
   if(sibling==null) return;
    var newDiv = document.createElement('div');
    newDiv.setAttribute("id","lastaction");
    newDiv.setAttribute("role","alert");
    newDiv.setAttribute("aria-live","assertive");
    newDiv.setAttribute("aria-relevant","text");
    newDiv.innerHTML = text;
    newDiv.appendChild(createCloseSpan());
    sibling.insertAdjacentElement("afterEnd",newDiv);
    updateLastAction(text,isPositive);
}
