function isEmailValid(emailAddress)
{
  if( emailAddress.length < 5 )
  {
    return false;
  }
    
  // Exactly 1 @
  var atPositions = find( emailAddress, "@" );
  if( atPositions.length != 1 )
  {
    return false;
  }
    
  // Does not begin with @
  if( atPositions[0] == 0 )
  {
    return false;
  }
    
  // Has a dot after the @
  var dotPositions = find( emailAddress, "." );
  if( dotPositions.length == 0 )
  {
    return false;
  }
  
  if( dotPositions[dotPositions.length - 1] < atPositions[0] )
  {
    return false;
  }

  // But not immediately after the @
  if ( emailAddress.search(/\@\./) != -1 )
  {
	return false;
  }
  
  // Has at least 2 characters after the final .
  if( dotPositions[dotPositions.length - 1] >= emailAddress.length - 2 )
  {
    return false;
  }
  
  // Does not have 2 dots in a row
  if ( emailAddress.search(/\.\./) != -1 )
  {
	return false;
  }
    
  // Check mailbox and domain
  var mailbox = emailAddress.substring( 0, atPositions[0] ).toLowerCase(); 
  var domain  = emailAddress.substring( atPositions[0] + 1, emailAddress.length ).toLowerCase(); 
  
  var validEmailChars = "0123456789~!#$%^&*-_+={}|'?`/.abcdefghijklmnopqrstuvwxyz";
  
  var mailboxDotPositions = find( mailbox, "." );

  if( mailboxDotPositions.length > 0 )
  {
    // mailbox (localpart) Does not begin with dot
    if( mailboxDotPositions[0] == 0 )
    {
      return false;
    }

    // mailbox (localpart) Does not end with dot
    if( mailboxDotPositions[mailboxDotPositions.length-1] == mailbox.length -1 )
    {
      return false;
    }  
  }
  
  if( !containsOnly( mailbox, validEmailChars ) )
  {
    return false;  
  }

  if( !containsOnly( domain, validEmailChars ) )
  {
    return false;  
  }

  return true;
}

function getEmailList( fieldValue )
{
    var listString = fieldValue.toLowerCase(); 
    var emailAddresses = new Array();
    var commaPositions = find( listString, ",");
    var semiPositions  = find( listString, ";");
    var delimPositions = new Array();

    for( var i = 0; i < commaPositions.length; i++ )
    {
      delimPositions[delimPositions.length] = commaPositions[i];
    }

    for( var i = 0; i < semiPositions.length; i++ )
    {
      delimPositions[delimPositions.length] = semiPositions[i];
    }
     
    //return original string if there are no delimiters or empty array if list was empty
    if( delimPositions.length == 0 )
    {
      trimmedList = trim( listString );
      if( !isBlank( trimmedList ) )
      {
        emailAddresses[0] = trimmedList;
      }
      return emailAddresses;
    }
    
    delimPositions.sort( function(a, b) {return a - b;} );

    for( var i = 0; i < delimPositions.length; i++ )
    {
       var beginPos = 0;
       if( i > 0 )
       {
         beginPos = delimPositions[i - 1] + 1;
       }
       
       var emailAddress = listString.substring( beginPos, delimPositions[i] );
       emailAddress = trim( emailAddress );
       if( !isBlank( emailAddress ) )
       {
         emailAddresses[emailAddresses.length] = emailAddress;
       }
    }

// get last one
    var beginPos = 0;
    if( delimPositions.length > 0 )
    {
      beginPos = delimPositions[delimPositions.length - 1] + 1;
    }
    
    var emailAddress = listString.substring( beginPos, listString.length );
    emailAddress = trim( emailAddress );
    if( !isBlank( emailAddress ) )
    {
      emailAddresses[emailAddresses.length] = emailAddress;
    }
    
    return emailAddresses;
    
}

function areEmailsInListValid( emailAddresses )
{
  for( var i = 0; i < emailAddresses.length; i++ )
  {
    if( !isEmailValid( emailAddresses[i] ) )
    {
      return false;
    }
  }
  
  return true;
}

function getRecipientCount( emailAddresses )
{
  return emailAddresses.length;
}

function getRecipients( emailAddresses )
{
  return emailAddresses;
}

function hasDuplicates( emailAddresses )
{
  var theAddresses = new Array();
  theAddresses = theAddresses.concat( emailAddresses );
  theAddresses.sort();

  for( var i = 1; i < theAddresses.length; i++ )
  {
    if( theAddresses[i] == theAddresses[i - 1] )
    {
      return true;
    }
  }
  
  return false;
}

