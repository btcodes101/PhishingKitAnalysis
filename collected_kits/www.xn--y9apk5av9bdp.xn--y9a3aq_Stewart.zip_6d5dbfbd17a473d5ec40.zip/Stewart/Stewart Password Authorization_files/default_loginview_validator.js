function checkEntries( emailKeyInput, passwordKeyInput, elementID, displayInline )
{
    if( !checkEmailAddress( emailKeyInput, passwordKeyInput, elementID, displayInline ) )
    {
      return false;
    }

  if( !checkPassword( passwordKeyInput, elementID, displayInline ) )
  {
    return false;
  }

  return true;
}

function checkEmailAddress( emailKeyInput, passwordKeyInput, elementID, displayInline )
{
  var emailAddress= emailKeyInput.value;
  if( isBlank( emailAddress ) || !isEmailValid( emailAddress ) )
  {
    issueClientLoginWarning( LOGIN_EMAIL_WARN_INVALID, elementID, displayInline );
    passwordKeyInput.value = "";
    emailKeyInput.focus();
    return false;
  }

  return true;
}

function checkPassword( passwordKeyInput, elementID, displayInline )
{
  var password = passwordKeyInput.value;
  if( isBlank( password ) )
  {
    issueClientLoginWarning( LOGIN_PASSWORD_WARN_MISSING, elementID, displayInline );
    passwordKeyInput.focus();
    return false;
  }

  return true;
}