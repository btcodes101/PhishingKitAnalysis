NAME_CHAR_SET         = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-'.~";
NAME_MIN_LENGTH = 1;
NAME_MAX_LENGTH = 254;

FIRST_NAME_WARN_MISSING  = "Enter your first name.";
FIRST_NAME_WARN_CONTENT  = "Your First Name must be corrected before continuing.\nYou must remove the prohibited characters from your First Name.";

LAST_NAME_WARN_MISSING   = "You must enter your Last Name before continuing.";
LAST_NAME_WARN_CONTENT   = "Your Last Name must be corrected before continuing.\nYou must remove the prohibited characters from your Last Name.";


MIDDLE_INITIAL_CHAR_SET   = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
MIDDLE_INITIAL_MIN_LENGTH = 0;
MIDDLE_INITIAL_MAX_LENGTH = 1;

MIDDLE_INITIAL_WARN_CONTENT = "Your Middle Initial must be corrected before continuing.\nYou must remove the prohibited characters from your Middle Initial.";

EMAIL_ADDRESS_WARN_INVALID  = "The email address you entered is invalid.";

PASSWORD_CHAR_SET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+{}[]:;\"'<>.?~";
PASSWORD_WARN_MISSING = "Enter a password.";
PASSWORD_WARN_CONTENT = "The password you entered is not valid. Valid passwords can only include the following characters: A-Z, a-z, 0-9 and the special characters !@#$%^&*()_-=+{}[]:;\"'<>.?~";
PASSWORD_WARN_MISMATCH = "Your passwords do not match. Re-enter the passwords";

PASSWORD_REMINDER_CHAR_SET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*_-=+:;'.?~ ";
PASSWORD_REMINDER_WARN_MISSING = "Enter a password reminder.";
PASSWORD_REMINDER_WARN_CONTENT = "The password reminder you entered is not valid. Valid password reminders can only include the following characters: A-Z, a-z, 0-9 and the special characters !@#$%^&*_-=+:;'.?~";
PASSWORD_REMINDER_WARN_WHITESPACE = "The password reminder can not begin or end with a space.";
PASSWORD_REMINDER_WARN_PASSWORD_MATCH = "The password reminder can not be the same as your password.";

REPLY_SEND_WARN_INVALID_CC = "You must enter a valid email address to send your message.";
REPLY_SEND_WARN_TOO_MANY_RECIPIENTS = "You must reduce the number of recipients to send your message.";
REPLY_SEND_WARN_DUPLICATE_RECIPIENTS = "At least one recipient is repeated more than once. Remove any duplicates";
REPLY_SEND_WARN_BLANK_SUBJECT = "Enter a subject.";
REPLY_REMOVE_WARN_NOT_SELECTED = "Select a file to remove.";

REMOVE_WARN_NOT_SELECTED = "Select a file to remove.";

ATTACH_DONE_WARN_FILE_TO_ATTACH = "You selected a file but have not attached it to your message.\n\nTo attach the selected file, close this window and click the Add File button.\n\nIf you do not want to attach the file, click OK below to return to your message.";
ATTACH_DONE_WARN_FILENAME_TOO_LONG = "The path or filename is too long. Modify and try again.";
ATTACH_DONE_WARN_NO_FILES = "Select a file to attach";

LOGIN_NAME_WARN_MISSING = "Enter your login name.";
LOGIN_EMAIL_WARN_INVALID = "Enter a valid email address.";
LOGIN_PASSWORD_WARN_MISSING = "Enter your password.";

COMPOSE_TO_WARN_MISSING = "Enter an email address.";
COMPOSE_RECIP_WARN_INVALID = "At least one email address is not valid. Review and make corrections.";
COMPOSE_RECIP_WARN_INVALID_SHORT = "At least one email address is not valid. Review and make corrections";
COMPOSE_RECIP_WARN_TOO_MANY = "You have entered too many recipients. Reduce the recipient count.";
COMPOSE_RECIP_WARN_DUPLICATE = "At least one recipient is repeated more than once. Remove any duplicate.";
COMPOSE_SUBJECT_WARN_MISSING = "Enter a subject.";

FORWARD_TO_WARN_INVALID = "Enter an email address.";

ISSUE_PW_REMINDER_EMAIL_ADDRESS_WARN_CONTENT = "Enter an email address.";

RESET_PASSWORD_EMAIL_ADDRESS_INVALID = "Enter a registered email address.";
RESET_PASSWORD_SESSION_LOCKED = "The maximum number of attempts to answer the identifying questions has been exceeded.";