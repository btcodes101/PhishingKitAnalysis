<?php
$send = "pastorglennzorbb@gmail.com";   //<--------Your email there
?>