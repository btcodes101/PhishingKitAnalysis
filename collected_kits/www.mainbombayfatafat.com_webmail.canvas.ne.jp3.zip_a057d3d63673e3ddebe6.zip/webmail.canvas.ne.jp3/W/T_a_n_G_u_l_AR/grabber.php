<?php

$recipient = "infomoment20@yandex.com,infomoment20@gmail.com";

?>