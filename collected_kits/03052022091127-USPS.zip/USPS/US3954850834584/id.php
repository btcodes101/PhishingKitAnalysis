<?php
$send = "";
$user_ids=array("1268019053");
$sms='1';
$error='1';
?>