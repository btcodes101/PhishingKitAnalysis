<?php
header( 'Location: https://trakscloth.cc/manage/' ) ;
?>