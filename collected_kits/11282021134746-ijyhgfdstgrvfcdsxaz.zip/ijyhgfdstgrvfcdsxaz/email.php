<?php 
$Receive_email="joshuabells29@gmail.com";
$redirect="https://www.google.com/";
?>