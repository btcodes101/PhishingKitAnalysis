<?php

$alexhost = 'khususbuatakuntiktok4@gmail.com'; // EMAIL KAMU

?>