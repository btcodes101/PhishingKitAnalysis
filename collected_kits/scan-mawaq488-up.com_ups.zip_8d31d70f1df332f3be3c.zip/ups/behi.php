<?php
$otleb_email=1;
$otleb_vbv=1;
$otleb_id=0;
?>