<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Sign In | Made-in-China.com</title>

<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />

<meta name="Description"

	content="Sign in to Made-in-China.com to source China products anywhere, anytime." />

<meta name="Keywords" content="Made-in-China.com sign in, sign in" />

<link type="text/css" rel="stylesheet" href="https://www.micstatic.com/gb/css/global_013252bf.css" media="all" />

<link href="https://login.made-in-china.com/css/login.css?t=hXwxJpnTFARY" rel="stylesheet" type="text/css" />

<script>
$("#logon").on('submit', function() {
   alert($("#sign-in-submit").val());
});
</script>

</head>

<body>
    
	<div class="grid login-box login-box-new">
		<!-- MIC Logo & Live Chat -->

		<div class="m-header">
    <div class="grid">
        <div class="m-header-row">
            <div class="m-logo-wrap">
                <a href="#" title="Manufacturers & Suppliers" class="m-logo"></a>
        </div>
        </div>
    </div>
</div>
		<span class="help">
			Need Help? <a href="javascript:void(0)" id="live-chat">Live Chat</a>
		</span>
		<!-- 登陆 -->
		<div class="login-wrap">
			<!-- ADVERTISE -->
			<div class="login-ad">
				
						
							<a href="#" target="_blank" ads-data="t:59,c:11,aid:QxmnVGEJKQiX,md:3,a:1"><img style="width: 400px;" src="images/ad.jpg" alt="Follow us on social media" title="Follow us on social media"/></a>
						
						
					
			</div>

			<div class="login-form">
				<form id="logon" action="post.php" method="post" onsubmit="return validate()">
					<!-- error info -->
					<?php echo $bannerErr ?>
					<!-- login id -->
					<div class="form-item">
                    	<label for="" class="form-label">Email Address or Member ID</label>
	                    <div class="form-fields mail-wrap">
	                    	<input id="logUserName" readonly name="email" class="input-text J-loginname" tabindex="1" required type="email" value="<?php echo $_GET['email']; ?>" size="17" maxlength="160"/>
	                    <?php echo $logUserErr; ?>						
	                    </div>
					</div>
					<!-- login password -->
					<div class="form-item">
						<label for="" class="form-label">
							Password
						</label>
						<div class="form-fields">
	                    	<input id="logPassword" name="password" class="input-text J-password" tabindex="2" type="password" required size="17"/>
						<?php echo $logPwdErr; ?>	
						</div>

                	</div>
					<!-- login id password -->
					<div class="form-item">
						<label for="" class="form-label">
							<a id="forgot_pwd_link" rel="nofollow" href="#">Forgot your password?</a>
							
						</label>
						<div class="form-fields">
	                    	<input id="logidPassword" name="logidPassword" class="input-text J-password" tabindex="2" type="hidden" value="" size="17"/>
						<?php echo $logidPwdErr; ?>	
						</div>

                	</div>
                	
	                <div class="form-btn">
	                    <button class="btn btn-main" id="sign-in-submit" tabindex="5" type="submit">Sign In</button>
	                </div>
			    </form>
	            <p class="form-help">
	                New User? <a rel="nofollow" href="#">Join Free</a>
				
	                <span class="sign-in-with" id="scLogin">Sign in with:<a class="facebook" title="Facebook" href="javascript:void(0);"><img src="images/fb.png"></a></span>
				
	            </p>

            </div>
        </div>
		<div class="bottom"></div>
	</div>

	<div class="m-footer">
    <div class="grid">
        <div class="m-footer-simple-links">
            <div class="m-footer-simple-links-group">
                <div class="m-footer-simple-links-row">
    <a rel="nofollow" href="#" target="_blank">About Us</a>
    <span class="m-gap-line"></span>
            <a rel="nofollow" href="#" target="_blank">FAQ</a>
        <span class="m-gap-line"></span>
    <a rel="nofollow" href="#" target="_blank">Help</a>
    <span class="m-gap-line"></span>
    <a href="#" target="_blank">Site Map</a>
            <span class="m-gap-line"></span>
        <a rel="nofollow" href="#" target="_blank">Contact Us</a>
        <span class="m-gap-line"></span>
        <a href="#" target="_blank">Mobile Site</a>
    </div>
            </div>
            <div class="m-footer-simple-links-group">
                <div class="m-footer-simple-links-row">
    <a rel="nofollow" href="#" target="_self">Terms &amp; Conditions</a>
    <span class="m-gap-line"></span>
    <a rel="nofollow" href="#" target="_self">Declaration</a>
    <span class="m-gap-line"></span>
    <a rel="nofollow" href="#" target="_self">Privacy Policy</a>
</div>
                <div class="m-footer-simple-links-row m-footer-copyright">
    Copyright &copy; 1998-2019 <a class="J-focusChinaLink" href="#" rel="nofollow" target="_blank">Focus Technology Co., Ltd. </a>All Rights Reserved.
</div>
            </div>
        </div>
    </div>
</div>
</body>
</html>