<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registration</title>
<meta name="generator" content="WYSIWYG Web Builder 16 - https://www.wysiwygwebbuilder.com">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Alegreya:700,500,400" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Cairo:700" rel="stylesheet">
<link href="AAERO-DSAHBOARD.css" rel="stylesheet">
<link href="regOK.css" rel="stylesheet">
</head>
<body>
<div id="container">
</div>
<div id="wb_LayoutGrid1">
<div id="LayoutGrid1">
<div class="row">
<div class="col-1">
</div>
<div class="col-2">
</div>
<div class="col-3">
</div>
</div>
</div>
</div>
</body>
</html>