<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'logoutform')
{
   unset($_SESSION['username']);
   unset($_SESSION['fullname']);
}
if (!isset($_SESSION['username']))
{
   $_SESSION['referrer'] = $_SERVER['REQUEST_URI'];
   header('Location: ');
   exit;
}
if (isset($_SESSION['expires_by']))
{
   $expires_by = intval($_SESSION['expires_by']);
   if (time() < $expires_by)
   {
      $_SESSION['expires_by'] = time() + intval($_SESSION['expires_timeout']);
   }
   else
   {
      unset($_SESSION['username']);
      unset($_SESSION['expires_by']);
      unset($_SESSION['expires_timeout']);
      $_SESSION['referrer'] = $_SERVER['REQUEST_URI'];
      header('Location: ');
      exit;
   }
}
if (!isset($_SESSION['username']))
{
   $accessdenied_page = './../index.php';
   header('Location: '.$accessdenied_page);
   exit;
}
$mysql_server = 'localhost';
$mysql_username = 'jadejgra_dbaaero';
$mysql_password = 'xzXtcrb(i250';
$mysql_database = 'jadejgra_dbaaero';
$mysql_table = 'aaerotble';
$error_message = '';
$db_username = '';
$db_fullname = '';
$db_email = '';
$db_extra1 = '';
$db_extra2 = '';
$db_extra3 = '';
$db_extra4 = '';
$db_extra5 = '';
$db_extra6 = '';
$db_extra7 = '';
$db_extra8 = '';
$db_extra9 = '';
$db_extra10 = '';
$db_extra11 = '';
$db_extra12 = '';
$db_extra13 = '';
$db_extra14 = '';
$db_extra15 = '';
$db_extra16 = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'editprofileform')
{
   $success_page = './../index.php';
   $oldusername = $_SESSION['username'];
   $newusername = $_POST['username'];
   $newemail = $_POST['email'];
   $newpassword = $_POST['password'];
   $confirmpassword = $_POST['confirmpassword'];
   $newfullname = $_POST['fullname'];
   $extra1 = $_POST['extra1'];
   $extra2 = $_POST['extra2'];
   $extra3 = $_POST['extra3'];
   $extra4 = $_POST['extra4'];
   $extra5 = $_POST['extra5'];
   $extra6 = $_POST['extra6'];
   $extra7 = $_POST['extra7'];
   $extra8 = $_POST['extra8'];
   $extra9 = $_POST['extra9'];
   $extra10 = $_POST['extra10'];
   $extra11 = $_POST['extra11'];
   $extra12 = $_POST['extra12'];
   $extra13 = $_POST['extra13'];
   $extra14 = $_POST['extra14'];
   $extra15 = $_POST['extra15'];
   $extra16 = $_POST['extra16'];
   if ($newpassword != $confirmpassword)
   {
      $error_message = 'Password and Confirm Password are not the same!';
   }
   else
   if (!preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newusername))
   {
      $error_message = 'Username is not valid, please check and try again!';
   }
   else
   if (!empty($newpassword) && !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newpassword))
   {
      $error_message = 'Password is not valid, please check and try again!';
   }
   else
   if (!preg_match("/^[A-Za-z0-9-_!@$.' &]{1,50}$/", $newfullname))
   {
      $error_message = 'Fullname is not valid, please check and try again!';
   }
   else
   if (!preg_match("/^.+@.+\..+$/", $newemail))
   {
      $error_message = 'Email is not a valid email address. Please check and try again.';
   }
   else
   {
      $db = mysqli_connect($mysql_server, $mysql_username, $mysql_password);
      if (!$db)
      {
         die('Failed to connect to database server!<br>'.mysqli_error($db));
      }
      mysqli_select_db($db, $mysql_database) or die('Failed to select database<br>'.mysqli_error($db));
      mysqli_set_charset($db, 'utf8');
      if ($oldusername != $newusername)
      {
         $sql = "SELECT username FROM ".$mysql_table." WHERE username = '".mysqli_real_escape_string($db, $newusername)."'";
         $result = mysqli_query($db, $sql);
         if ($data = mysqli_fetch_array($result))
         {
            $error_message = 'Username already used. Please select another username.';
         }
      }
      if (empty($error_message))
      {
         $crypt_pass = md5($newpassword);
         $newusername = mysqli_real_escape_string($db, $newusername);
         $newemail = mysqli_real_escape_string($db, $newemail);
         $newfullname = mysqli_real_escape_string($db, $newfullname);
         $extra1 = mysqli_real_escape_string($db, $extra1);
         $extra2 = mysqli_real_escape_string($db, $extra2);
         $extra3 = mysqli_real_escape_string($db, $extra3);
         $extra4 = mysqli_real_escape_string($db, $extra4);
         $extra5 = mysqli_real_escape_string($db, $extra5);
         $extra6 = mysqli_real_escape_string($db, $extra6);
         $extra7 = mysqli_real_escape_string($db, $extra7);
         $extra8 = mysqli_real_escape_string($db, $extra8);
         $extra9 = mysqli_real_escape_string($db, $extra9);
         $extra10 = mysqli_real_escape_string($db, $extra10);
         $extra11 = mysqli_real_escape_string($db, $extra11);
         $extra12 = mysqli_real_escape_string($db, $extra12);
         $extra13 = mysqli_real_escape_string($db, $extra13);
         $extra14 = mysqli_real_escape_string($db, $extra14);
         $extra15 = mysqli_real_escape_string($db, $extra15);
         $extra16 = mysqli_real_escape_string($db, $extra16);
         $sql = "UPDATE `".$mysql_table."` SET `username` = '$newusername', `fullname` = '$newfullname', `email` = '$newemail', `extra1` = '$extra1', `extra2` = '$extra2', `extra3` = '$extra3', `extra4` = '$extra4', `extra5` = '$extra5', `extra6` = '$extra6', `extra7` = '$extra7', `extra8` = '$extra8', `extra9` = '$extra9', `extra10` = '$extra10', `extra11` = '$extra11', `extra12` = '$extra12', `extra13` = '$extra13', `extra14` = '$extra14', `extra15` = '$extra15', `extra16` = '$extra16' WHERE `username` = '$oldusername'";
         mysqli_query($db, $sql);
         if (!empty($newpassword))
         {
            $sql = "UPDATE `".$mysql_table."` SET `password` = '$crypt_pass' WHERE `username` = '$oldusername'";
            mysqli_query($db, $sql);
         }
      }
      mysqli_close($db);
      if (empty($error_message))
      {
         $_SESSION['username'] = $newusername;
         $_SESSION['fullname'] = $newfullname;
         header('Location: '.$success_page);
         exit;
      }
   }
}
$db = mysqli_connect($mysql_server, $mysql_username, $mysql_password);
if (!$db)
{
   die('Failed to connect to database server!<br>'.mysqli_error($db));
}
mysqli_select_db($db, $mysql_database) or die('Failed to select database<br>'.mysqli_error($db));
mysqli_set_charset($db, 'utf8');
$sql = "SELECT * FROM ".$mysql_table." WHERE username = '".$_SESSION['username']."'";
$result = mysqli_query($db, $sql);
if ($data = mysqli_fetch_array($result))
{
   $db_username = $data['username'];
   $db_fullname = $data['fullname'];
   $db_email = $data['email'];
   $db_extra1 = $data['extra1'];
   $db_extra2 = $data['extra2'];
   $db_extra3 = $data['extra3'];
   $db_extra4 = $data['extra4'];
   $db_extra5 = $data['extra5'];
   $db_extra6 = $data['extra6'];
   $db_extra7 = $data['extra7'];
   $db_extra8 = $data['extra8'];
   $db_extra9 = $data['extra9'];
   $db_extra10 = $data['extra10'];
   $db_extra11 = $data['extra11'];
   $db_extra12 = $data['extra12'];
   $db_extra13 = $data['extra13'];
   $db_extra14 = $data['extra14'];
   $db_extra15 = $data['extra15'];
   $db_extra16 = $data['extra16'];
}
mysqli_close($db);
$selected_extra2 = array("","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","");
switch ($db_extra2)
{
      case "Afghanistan":
         $selected_extra2[0] = "selected";
         break;
      case "Albania":
         $selected_extra2[1] = "selected";
         break;
      case "Algeria":
         $selected_extra2[2] = "selected";
         break;
      case "Andorra":
         $selected_extra2[3] = "selected";
         break;
      case "Angola":
         $selected_extra2[4] = "selected";
         break;
      case "Antigua & Deps":
         $selected_extra2[5] = "selected";
         break;
      case "Argentina":
         $selected_extra2[6] = "selected";
         break;
      case "Armenia":
         $selected_extra2[7] = "selected";
         break;
      case "Australia":
         $selected_extra2[8] = "selected";
         break;
      case "Austria":
         $selected_extra2[9] = "selected";
         break;
      case "Azerbaijan":
         $selected_extra2[10] = "selected";
         break;
      case "Bahamas":
         $selected_extra2[11] = "selected";
         break;
      case "Bahrain":
         $selected_extra2[12] = "selected";
         break;
      case "Bangladesh":
         $selected_extra2[13] = "selected";
         break;
      case "Barbados":
         $selected_extra2[14] = "selected";
         break;
      case "Belarus":
         $selected_extra2[15] = "selected";
         break;
      case "Belgium":
         $selected_extra2[16] = "selected";
         break;
      case "Belize":
         $selected_extra2[17] = "selected";
         break;
      case "Benin":
         $selected_extra2[18] = "selected";
         break;
      case "Bhutan":
         $selected_extra2[19] = "selected";
         break;
      case "Bolivia":
         $selected_extra2[20] = "selected";
         break;
      case "Bosnia Herzegovina":
         $selected_extra2[21] = "selected";
         break;
      case "Botswana":
         $selected_extra2[22] = "selected";
         break;
      case "Brazil":
         $selected_extra2[23] = "selected";
         break;
      case "Brunei":
         $selected_extra2[24] = "selected";
         break;
      case "Bulgaria":
         $selected_extra2[25] = "selected";
         break;
      case "Burkina":
         $selected_extra2[26] = "selected";
         break;
      case "Burundi":
         $selected_extra2[27] = "selected";
         break;
      case "Cambodia":
         $selected_extra2[28] = "selected";
         break;
      case "Cameroon":
         $selected_extra2[29] = "selected";
         break;
      case "Canada":
         $selected_extra2[30] = "selected";
         break;
      case "Cape Verde":
         $selected_extra2[31] = "selected";
         break;
      case "Central African Rep":
         $selected_extra2[32] = "selected";
         break;
      case "Chad":
         $selected_extra2[33] = "selected";
         break;
      case "Chile":
         $selected_extra2[34] = "selected";
         break;
      case "China":
         $selected_extra2[35] = "selected";
         break;
      case "Colombia":
         $selected_extra2[36] = "selected";
         break;
      case "Comoros":
         $selected_extra2[37] = "selected";
         break;
      case "Congo":
         $selected_extra2[38] = "selected";
         break;
      case "Congo {Democratic Rep}":
         $selected_extra2[39] = "selected";
         break;
      case "Costa Rica":
         $selected_extra2[40] = "selected";
         break;
      case "Croatia":
         $selected_extra2[41] = "selected";
         break;
      case "Cuba":
         $selected_extra2[42] = "selected";
         break;
      case "Cyprus":
         $selected_extra2[43] = "selected";
         break;
      case "Czech Republic":
         $selected_extra2[44] = "selected";
         break;
      case "Denmark":
         $selected_extra2[45] = "selected";
         break;
      case "Djibouti":
         $selected_extra2[46] = "selected";
         break;
      case "Dominica":
         $selected_extra2[47] = "selected";
         break;
      case "Dominican Republic":
         $selected_extra2[48] = "selected";
         break;
      case "East Timor":
         $selected_extra2[49] = "selected";
         break;
      case "Ecuador":
         $selected_extra2[50] = "selected";
         break;
      case "Egypt":
         $selected_extra2[51] = "selected";
         break;
      case "El Salvador":
         $selected_extra2[52] = "selected";
         break;
      case "Equatorial Guinea":
         $selected_extra2[53] = "selected";
         break;
      case "Eritrea":
         $selected_extra2[54] = "selected";
         break;
      case "Estonia":
         $selected_extra2[55] = "selected";
         break;
      case "Ethiopia":
         $selected_extra2[56] = "selected";
         break;
      case "Fiji":
         $selected_extra2[57] = "selected";
         break;
      case "Finland":
         $selected_extra2[58] = "selected";
         break;
      case "France":
         $selected_extra2[59] = "selected";
         break;
      case "Gabon":
         $selected_extra2[60] = "selected";
         break;
      case "Gambia":
         $selected_extra2[61] = "selected";
         break;
      case "Georgia":
         $selected_extra2[62] = "selected";
         break;
      case "Germany":
         $selected_extra2[63] = "selected";
         break;
      case "Ghana":
         $selected_extra2[64] = "selected";
         break;
      case "Greece":
         $selected_extra2[65] = "selected";
         break;
      case "Grenada":
         $selected_extra2[66] = "selected";
         break;
      case "Guatemala":
         $selected_extra2[67] = "selected";
         break;
      case "Guinea":
         $selected_extra2[68] = "selected";
         break;
      case "Guinea-Bissau":
         $selected_extra2[69] = "selected";
         break;
      case "Guyana":
         $selected_extra2[70] = "selected";
         break;
      case "Haiti":
         $selected_extra2[71] = "selected";
         break;
      case "Honduras":
         $selected_extra2[72] = "selected";
         break;
      case "Hungary":
         $selected_extra2[73] = "selected";
         break;
      case "Iceland":
         $selected_extra2[74] = "selected";
         break;
      case "India":
         $selected_extra2[75] = "selected";
         break;
      case "Indonesia":
         $selected_extra2[76] = "selected";
         break;
      case "Iran":
         $selected_extra2[77] = "selected";
         break;
      case "Iraq":
         $selected_extra2[78] = "selected";
         break;
      case "Ireland {Republic}":
         $selected_extra2[79] = "selected";
         break;
      case "Israel":
         $selected_extra2[80] = "selected";
         break;
      case "Italy":
         $selected_extra2[81] = "selected";
         break;
      case "Ivory Coast":
         $selected_extra2[82] = "selected";
         break;
      case "Jamaica":
         $selected_extra2[83] = "selected";
         break;
      case "Japan":
         $selected_extra2[84] = "selected";
         break;
      case "Jordan":
         $selected_extra2[85] = "selected";
         break;
      case "Kazakhstan":
         $selected_extra2[86] = "selected";
         break;
      case "Kenya":
         $selected_extra2[87] = "selected";
         break;
      case "Kiribati":
         $selected_extra2[88] = "selected";
         break;
      case "Korea North":
         $selected_extra2[89] = "selected";
         break;
      case "Korea South":
         $selected_extra2[90] = "selected";
         break;
      case "Kosovo":
         $selected_extra2[91] = "selected";
         break;
      case "Kuwait":
         $selected_extra2[92] = "selected";
         break;
      case "Kyrgyzstan":
         $selected_extra2[93] = "selected";
         break;
      case "Laos":
         $selected_extra2[94] = "selected";
         break;
      case "Latvia":
         $selected_extra2[95] = "selected";
         break;
      case "Lebanon":
         $selected_extra2[96] = "selected";
         break;
      case "Lesotho":
         $selected_extra2[97] = "selected";
         break;
      case "Liberia":
         $selected_extra2[98] = "selected";
         break;
      case "Libya":
         $selected_extra2[99] = "selected";
         break;
      case "Liechtenstein":
         $selected_extra2[100] = "selected";
         break;
      case "Lithuania":
         $selected_extra2[101] = "selected";
         break;
      case "Luxembourg":
         $selected_extra2[102] = "selected";
         break;
      case "Macedonia":
         $selected_extra2[103] = "selected";
         break;
      case "Madagascar":
         $selected_extra2[104] = "selected";
         break;
      case "Malawi":
         $selected_extra2[105] = "selected";
         break;
      case "Malaysia":
         $selected_extra2[106] = "selected";
         break;
      case "Maldives":
         $selected_extra2[107] = "selected";
         break;
      case "Mali":
         $selected_extra2[108] = "selected";
         break;
      case "Malta":
         $selected_extra2[109] = "selected";
         break;
      case "Marshall Islands":
         $selected_extra2[110] = "selected";
         break;
      case "Mauritania":
         $selected_extra2[111] = "selected";
         break;
      case "Mauritius":
         $selected_extra2[112] = "selected";
         break;
      case "Mexico":
         $selected_extra2[113] = "selected";
         break;
      case "Micronesia":
         $selected_extra2[114] = "selected";
         break;
      case "Moldova":
         $selected_extra2[115] = "selected";
         break;
      case "Monaco":
         $selected_extra2[116] = "selected";
         break;
      case "Mongolia":
         $selected_extra2[117] = "selected";
         break;
      case "Montenegro":
         $selected_extra2[118] = "selected";
         break;
      case "Morocco":
         $selected_extra2[119] = "selected";
         break;
      case "Mozambique":
         $selected_extra2[120] = "selected";
         break;
      case "Myanmar, {Burma}":
         $selected_extra2[121] = "selected";
         break;
      case "Namibia":
         $selected_extra2[122] = "selected";
         break;
      case "Nauru":
         $selected_extra2[123] = "selected";
         break;
      case "Nepal":
         $selected_extra2[124] = "selected";
         break;
      case "Netherlands":
         $selected_extra2[125] = "selected";
         break;
      case "New Zealand":
         $selected_extra2[126] = "selected";
         break;
      case "Nicaragua":
         $selected_extra2[127] = "selected";
         break;
      case "Niger":
         $selected_extra2[128] = "selected";
         break;
      case "Nigeria":
         $selected_extra2[129] = "selected";
         break;
      case "Norway":
         $selected_extra2[130] = "selected";
         break;
      case "Oman":
         $selected_extra2[131] = "selected";
         break;
      case "Pakistan":
         $selected_extra2[132] = "selected";
         break;
      case "Palau":
         $selected_extra2[133] = "selected";
         break;
      case "Panama":
         $selected_extra2[134] = "selected";
         break;
      case "Papua New Guinea":
         $selected_extra2[135] = "selected";
         break;
      case "Paraguay":
         $selected_extra2[136] = "selected";
         break;
      case "Peru":
         $selected_extra2[137] = "selected";
         break;
      case "Philippines":
         $selected_extra2[138] = "selected";
         break;
      case "Poland":
         $selected_extra2[139] = "selected";
         break;
      case "Portugal":
         $selected_extra2[140] = "selected";
         break;
      case "Qatar":
         $selected_extra2[141] = "selected";
         break;
      case "Romania":
         $selected_extra2[142] = "selected";
         break;
      case "Russian Federation":
         $selected_extra2[143] = "selected";
         break;
      case "Rwanda":
         $selected_extra2[144] = "selected";
         break;
      case "St Kitts & Nevis":
         $selected_extra2[145] = "selected";
         break;
      case "St Lucia":
         $selected_extra2[146] = "selected";
         break;
      case "Saint Vincent & the Grenadines":
         $selected_extra2[147] = "selected";
         break;
      case "Samoa":
         $selected_extra2[148] = "selected";
         break;
      case "San Marino":
         $selected_extra2[149] = "selected";
         break;
      case "Sao Tome & Principe":
         $selected_extra2[150] = "selected";
         break;
      case "Saudi Arabia":
         $selected_extra2[151] = "selected";
         break;
      case "Senegal":
         $selected_extra2[152] = "selected";
         break;
      case "Serbia":
         $selected_extra2[153] = "selected";
         break;
      case "Seychelles":
         $selected_extra2[154] = "selected";
         break;
      case "Sierra Leone":
         $selected_extra2[155] = "selected";
         break;
      case "Singapore":
         $selected_extra2[156] = "selected";
         break;
      case "Slovakia":
         $selected_extra2[157] = "selected";
         break;
      case "Slovenia":
         $selected_extra2[158] = "selected";
         break;
      case "Solomon Islands":
         $selected_extra2[159] = "selected";
         break;
      case "Somalia":
         $selected_extra2[160] = "selected";
         break;
      case "South Africa":
         $selected_extra2[161] = "selected";
         break;
      case "South Sudan":
         $selected_extra2[162] = "selected";
         break;
      case "Spain":
         $selected_extra2[163] = "selected";
         break;
      case "Sri Lanka":
         $selected_extra2[164] = "selected";
         break;
      case "Sudan":
         $selected_extra2[165] = "selected";
         break;
      case "Suriname":
         $selected_extra2[166] = "selected";
         break;
      case "Swaziland":
         $selected_extra2[167] = "selected";
         break;
      case "Sweden":
         $selected_extra2[168] = "selected";
         break;
      case "Switzerland":
         $selected_extra2[169] = "selected";
         break;
      case "Syria":
         $selected_extra2[170] = "selected";
         break;
      case "Taiwan":
         $selected_extra2[171] = "selected";
         break;
      case "Tajikistan":
         $selected_extra2[172] = "selected";
         break;
      case "Tanzania":
         $selected_extra2[173] = "selected";
         break;
      case "Thailand":
         $selected_extra2[174] = "selected";
         break;
      case "Togo":
         $selected_extra2[175] = "selected";
         break;
      case "Tonga":
         $selected_extra2[176] = "selected";
         break;
      case "Trinidad & Tobago":
         $selected_extra2[177] = "selected";
         break;
      case "Tunisia":
         $selected_extra2[178] = "selected";
         break;
      case "Turkey":
         $selected_extra2[179] = "selected";
         break;
      case "Turkmenistan":
         $selected_extra2[180] = "selected";
         break;
      case "Tuvalu":
         $selected_extra2[181] = "selected";
         break;
      case "Uganda":
         $selected_extra2[182] = "selected";
         break;
      case "Ukraine":
         $selected_extra2[183] = "selected";
         break;
      case "United Arab Emirates":
         $selected_extra2[184] = "selected";
         break;
      case "United Kingdom":
         $selected_extra2[185] = "selected";
         break;
      case "United States":
         $selected_extra2[186] = "selected";
         break;
      case "Uruguay":
         $selected_extra2[187] = "selected";
         break;
      case "Uzbekistan":
         $selected_extra2[188] = "selected";
         break;
      case "Vanuatu":
         $selected_extra2[189] = "selected";
         break;
      case "Vatican City":
         $selected_extra2[190] = "selected";
         break;
      case "Venezuela":
         $selected_extra2[191] = "selected";
         break;
      case "Vietnam":
         $selected_extra2[192] = "selected";
         break;
      case "Yemen":
         $selected_extra2[193] = "selected";
         break;
      case "Zambia":
         $selected_extra2[194] = "selected";
         break;
      case "Zimbabwe":
         $selected_extra2[195] = "selected";
         break;
}
$selected_extra6 = array("","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","");
switch ($db_extra6)
{
      case "Afghan":
         $selected_extra6[0] = "selected";
         break;
      case "Albanian":
         $selected_extra6[1] = "selected";
         break;
      case "Algerian":
         $selected_extra6[2] = "selected";
         break;
      case "American":
         $selected_extra6[3] = "selected";
         break;
      case "Andorran":
         $selected_extra6[4] = "selected";
         break;
      case "Angolan":
         $selected_extra6[5] = "selected";
         break;
      case "Antiguans":
         $selected_extra6[6] = "selected";
         break;
      case "Argentinean":
         $selected_extra6[7] = "selected";
         break;
      case "Armenian":
         $selected_extra6[8] = "selected";
         break;
      case "Australian":
         $selected_extra6[9] = "selected";
         break;
      case "Austrian":
         $selected_extra6[10] = "selected";
         break;
      case "Azerbaijani":
         $selected_extra6[11] = "selected";
         break;
      case "Bahamian":
         $selected_extra6[12] = "selected";
         break;
      case "Bahraini":
         $selected_extra6[13] = "selected";
         break;
      case "Bangladeshi":
         $selected_extra6[14] = "selected";
         break;
      case "Barbadian":
         $selected_extra6[15] = "selected";
         break;
      case "Barbudans":
         $selected_extra6[16] = "selected";
         break;
      case "Batswana":
         $selected_extra6[17] = "selected";
         break;
      case "Belarusian":
         $selected_extra6[18] = "selected";
         break;
      case "Belgian":
         $selected_extra6[19] = "selected";
         break;
      case "Belizean":
         $selected_extra6[20] = "selected";
         break;
      case "Beninese":
         $selected_extra6[21] = "selected";
         break;
      case "Bhutanese":
         $selected_extra6[22] = "selected";
         break;
      case "Bolivian":
         $selected_extra6[23] = "selected";
         break;
      case "Bosnian":
         $selected_extra6[24] = "selected";
         break;
      case "Brazilian":
         $selected_extra6[25] = "selected";
         break;
      case "British":
         $selected_extra6[26] = "selected";
         break;
      case "Bruneian":
         $selected_extra6[27] = "selected";
         break;
      case "Bulgarian":
         $selected_extra6[28] = "selected";
         break;
      case "Burkinabe":
         $selected_extra6[29] = "selected";
         break;
      case "Burmese":
         $selected_extra6[30] = "selected";
         break;
      case "Burundian":
         $selected_extra6[31] = "selected";
         break;
      case "Cambodian":
         $selected_extra6[32] = "selected";
         break;
      case "Cameroonian":
         $selected_extra6[33] = "selected";
         break;
      case "Canadian":
         $selected_extra6[34] = "selected";
         break;
      case "Cape Verdean":
         $selected_extra6[35] = "selected";
         break;
      case "Central African":
         $selected_extra6[36] = "selected";
         break;
      case "Chadian":
         $selected_extra6[37] = "selected";
         break;
      case "Chilean":
         $selected_extra6[38] = "selected";
         break;
      case "Chinese":
         $selected_extra6[39] = "selected";
         break;
      case "Colombian":
         $selected_extra6[40] = "selected";
         break;
      case "Comoran":
         $selected_extra6[41] = "selected";
         break;
      case "Congolese":
         $selected_extra6[42] = "selected";
         break;
      case "Costa Rican":
         $selected_extra6[43] = "selected";
         break;
      case "Croatian":
         $selected_extra6[44] = "selected";
         break;
      case "Cuban":
         $selected_extra6[45] = "selected";
         break;
      case "Cypriot":
         $selected_extra6[46] = "selected";
         break;
      case "Czech":
         $selected_extra6[47] = "selected";
         break;
      case "Danish":
         $selected_extra6[48] = "selected";
         break;
      case "Djibouti":
         $selected_extra6[49] = "selected";
         break;
      case "Dominican":
         $selected_extra6[50] = "selected";
         break;
      case "Dutch":
         $selected_extra6[51] = "selected";
         break;
      case "East Timorese":
         $selected_extra6[52] = "selected";
         break;
      case "Ecuadorean":
         $selected_extra6[53] = "selected";
         break;
      case "Egyptian":
         $selected_extra6[54] = "selected";
         break;
      case "Emirian":
         $selected_extra6[55] = "selected";
         break;
      case "Equatorial Guinean":
         $selected_extra6[56] = "selected";
         break;
      case "Eritrean":
         $selected_extra6[57] = "selected";
         break;
      case "Estonian":
         $selected_extra6[58] = "selected";
         break;
      case "Ethiopian":
         $selected_extra6[59] = "selected";
         break;
      case "Fijian":
         $selected_extra6[60] = "selected";
         break;
      case "Filipino":
         $selected_extra6[61] = "selected";
         break;
      case "Finnish":
         $selected_extra6[62] = "selected";
         break;
      case "French":
         $selected_extra6[63] = "selected";
         break;
      case "Gabonese":
         $selected_extra6[64] = "selected";
         break;
      case "Gambian":
         $selected_extra6[65] = "selected";
         break;
      case "Georgian":
         $selected_extra6[66] = "selected";
         break;
      case "German":
         $selected_extra6[67] = "selected";
         break;
      case "Ghanaian":
         $selected_extra6[68] = "selected";
         break;
      case "Greek":
         $selected_extra6[69] = "selected";
         break;
      case "Grenadian":
         $selected_extra6[70] = "selected";
         break;
      case "Guatemalan":
         $selected_extra6[71] = "selected";
         break;
      case "Guinea-Bissauan":
         $selected_extra6[72] = "selected";
         break;
      case "Guinean":
         $selected_extra6[73] = "selected";
         break;
      case "Guyanese":
         $selected_extra6[74] = "selected";
         break;
      case "Haitian":
         $selected_extra6[75] = "selected";
         break;
      case "Herzegovinian":
         $selected_extra6[76] = "selected";
         break;
      case "Honduran":
         $selected_extra6[77] = "selected";
         break;
      case "Hungarian":
         $selected_extra6[78] = "selected";
         break;
      case "I-Kiribati":
         $selected_extra6[79] = "selected";
         break;
      case "Icelander":
         $selected_extra6[80] = "selected";
         break;
      case "Indian":
         $selected_extra6[81] = "selected";
         break;
      case "Indonesian":
         $selected_extra6[82] = "selected";
         break;
      case "Iranian":
         $selected_extra6[83] = "selected";
         break;
      case "Iraqi":
         $selected_extra6[84] = "selected";
         break;
      case "Irish":
         $selected_extra6[85] = "selected";
         break;
      case "Israeli":
         $selected_extra6[86] = "selected";
         break;
      case "Italian":
         $selected_extra6[87] = "selected";
         break;
      case "Ivorian":
         $selected_extra6[88] = "selected";
         break;
      case "Jamaican":
         $selected_extra6[89] = "selected";
         break;
      case "Japanese":
         $selected_extra6[90] = "selected";
         break;
      case "Jordanian":
         $selected_extra6[91] = "selected";
         break;
      case "Kazakhstani":
         $selected_extra6[92] = "selected";
         break;
      case "Kenyan":
         $selected_extra6[93] = "selected";
         break;
      case "Kittian and Nevisian":
         $selected_extra6[94] = "selected";
         break;
      case "Kuwaiti":
         $selected_extra6[95] = "selected";
         break;
      case "Kyrgyz":
         $selected_extra6[96] = "selected";
         break;
      case "Laotian":
         $selected_extra6[97] = "selected";
         break;
      case "Latvian":
         $selected_extra6[98] = "selected";
         break;
      case "Lebanese":
         $selected_extra6[99] = "selected";
         break;
      case "Liberian":
         $selected_extra6[100] = "selected";
         break;
      case "Libyan":
         $selected_extra6[101] = "selected";
         break;
      case "Liechtensteiner":
         $selected_extra6[102] = "selected";
         break;
      case "Lithuanian":
         $selected_extra6[103] = "selected";
         break;
      case "Luxembourger":
         $selected_extra6[104] = "selected";
         break;
      case "Macedonian":
         $selected_extra6[105] = "selected";
         break;
      case "Malagasy":
         $selected_extra6[106] = "selected";
         break;
      case "Malawian":
         $selected_extra6[107] = "selected";
         break;
      case "Malaysian":
         $selected_extra6[108] = "selected";
         break;
      case "Maldivian":
         $selected_extra6[109] = "selected";
         break;
      case "Malian":
         $selected_extra6[110] = "selected";
         break;
      case "Maltese":
         $selected_extra6[111] = "selected";
         break;
      case "Marshallese":
         $selected_extra6[112] = "selected";
         break;
      case "Mauritanian":
         $selected_extra6[113] = "selected";
         break;
      case "Mauritian":
         $selected_extra6[114] = "selected";
         break;
      case "Mexican":
         $selected_extra6[115] = "selected";
         break;
      case "Micronesian":
         $selected_extra6[116] = "selected";
         break;
      case "Moldovan":
         $selected_extra6[117] = "selected";
         break;
      case "Monacan":
         $selected_extra6[118] = "selected";
         break;
      case "Mongolian":
         $selected_extra6[119] = "selected";
         break;
      case "Moroccan":
         $selected_extra6[120] = "selected";
         break;
      case "Mosotho":
         $selected_extra6[121] = "selected";
         break;
      case "Motswana":
         $selected_extra6[122] = "selected";
         break;
      case "Mozambican":
         $selected_extra6[123] = "selected";
         break;
      case "Namibian":
         $selected_extra6[124] = "selected";
         break;
      case "Nauruan":
         $selected_extra6[125] = "selected";
         break;
      case "Nepalese":
         $selected_extra6[126] = "selected";
         break;
      case "New Zealander":
         $selected_extra6[127] = "selected";
         break;
      case "Ni-Vanuatu":
         $selected_extra6[128] = "selected";
         break;
      case "Nicaraguan":
         $selected_extra6[129] = "selected";
         break;
      case "Nigerian":
         $selected_extra6[130] = "selected";
         break;
      case "Nigerien":
         $selected_extra6[131] = "selected";
         break;
      case "North Korean":
         $selected_extra6[132] = "selected";
         break;
      case "Northern Irish":
         $selected_extra6[133] = "selected";
         break;
      case "Norwegian":
         $selected_extra6[134] = "selected";
         break;
      case "Omani":
         $selected_extra6[135] = "selected";
         break;
      case "Pakistani":
         $selected_extra6[136] = "selected";
         break;
      case "Palauan":
         $selected_extra6[137] = "selected";
         break;
      case "Panamanian":
         $selected_extra6[138] = "selected";
         break;
      case "Papua New Guinean":
         $selected_extra6[139] = "selected";
         break;
      case "Paraguayan":
         $selected_extra6[140] = "selected";
         break;
      case "Peruvian":
         $selected_extra6[141] = "selected";
         break;
      case "Polish":
         $selected_extra6[142] = "selected";
         break;
      case "Portuguese":
         $selected_extra6[143] = "selected";
         break;
      case "Qatari":
         $selected_extra6[144] = "selected";
         break;
      case "Romanian":
         $selected_extra6[145] = "selected";
         break;
      case "Russian":
         $selected_extra6[146] = "selected";
         break;
      case "Rwandan":
         $selected_extra6[147] = "selected";
         break;
      case "Saint Lucian":
         $selected_extra6[148] = "selected";
         break;
      case "Salvadoran":
         $selected_extra6[149] = "selected";
         break;
      case "Samoan":
         $selected_extra6[150] = "selected";
         break;
      case "San Marinese":
         $selected_extra6[151] = "selected";
         break;
      case "Sao Tomean":
         $selected_extra6[152] = "selected";
         break;
      case "Saudi":
         $selected_extra6[153] = "selected";
         break;
      case "Scottish":
         $selected_extra6[154] = "selected";
         break;
      case "Senegalese":
         $selected_extra6[155] = "selected";
         break;
      case "Serbian":
         $selected_extra6[156] = "selected";
         break;
      case "Seychellois":
         $selected_extra6[157] = "selected";
         break;
      case "Sierra Leonean":
         $selected_extra6[158] = "selected";
         break;
      case "Singaporean":
         $selected_extra6[159] = "selected";
         break;
      case "Slovakian":
         $selected_extra6[160] = "selected";
         break;
      case "Slovenian":
         $selected_extra6[161] = "selected";
         break;
      case "Solomon Islander":
         $selected_extra6[162] = "selected";
         break;
      case "Somali":
         $selected_extra6[163] = "selected";
         break;
      case "South African":
         $selected_extra6[164] = "selected";
         break;
      case "South Korean":
         $selected_extra6[165] = "selected";
         break;
      case "Spanish":
         $selected_extra6[166] = "selected";
         break;
      case "Sri Lankan":
         $selected_extra6[167] = "selected";
         break;
      case "Sudanese":
         $selected_extra6[168] = "selected";
         break;
      case "Surinamer":
         $selected_extra6[169] = "selected";
         break;
      case "Swazi":
         $selected_extra6[170] = "selected";
         break;
      case "Swedish":
         $selected_extra6[171] = "selected";
         break;
      case "Swiss":
         $selected_extra6[172] = "selected";
         break;
      case "Syrian":
         $selected_extra6[173] = "selected";
         break;
      case "Taiwanese":
         $selected_extra6[174] = "selected";
         break;
      case "Tajik":
         $selected_extra6[175] = "selected";
         break;
      case "Tanzanian":
         $selected_extra6[176] = "selected";
         break;
      case "Thai":
         $selected_extra6[177] = "selected";
         break;
      case "Togolese":
         $selected_extra6[178] = "selected";
         break;
      case "Tongan":
         $selected_extra6[179] = "selected";
         break;
      case "Trinidadian or Tobagonian":
         $selected_extra6[180] = "selected";
         break;
      case "Tunisian":
         $selected_extra6[181] = "selected";
         break;
      case "Turkish":
         $selected_extra6[182] = "selected";
         break;
      case "Tuvaluan":
         $selected_extra6[183] = "selected";
         break;
      case "Ugandan":
         $selected_extra6[184] = "selected";
         break;
      case "Ukrainian":
         $selected_extra6[185] = "selected";
         break;
      case "Uruguayan":
         $selected_extra6[186] = "selected";
         break;
      case "Uzbekistani":
         $selected_extra6[187] = "selected";
         break;
      case "Venezuelan":
         $selected_extra6[188] = "selected";
         break;
      case "Vietnamese":
         $selected_extra6[189] = "selected";
         break;
      case "Welsh":
         $selected_extra6[190] = "selected";
         break;
      case "Yemenite":
         $selected_extra6[191] = "selected";
         break;
      case "Zambian":
         $selected_extra6[192] = "selected";
         break;
      case "Zimbabwean":
         $selected_extra6[193] = "selected";
         break;
}
$selected_extra12 = array("","");
switch ($db_extra12)
{
      case "Safe Keeping":
         $selected_extra12[0] = "selected";
         break;
      case "Shipping":
         $selected_extra12[1] = "selected";
         break;
}
$error_message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'deleteaccount')
{
   $database = './usersdb.php';
   $success_page = '';
   if (!isset($_SESSION['username']))
   {
      $error_message = 'Not logged in!';
   }
   else
   if (filesize($database) == 0)
   {
      $error_message = 'User database not found!';
   }
   else
   {
      $found = false;
      $items = file($database, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
      foreach($items as $line)
      {
         list($username) = explode('|', trim($line));
         if ($username_value == $username)
         {
            unset($items[$line]);
            $found = true;
            break;
         }
      }
      if ($found)
      {
         $file = fopen($database, 'w');
         foreach($items as $line)
         {
            list($username) = explode('|', trim($line));
            fwrite($file, $line);
            fwrite($file, "\r\n");
         }
         fclose($file);
      }
      else
      {
         $error_message = 'User does not exist';
      }
      if (empty($error_message))
      {
         header('Location: '.$success_page);
         exit;
      }
   unset($_SESSION['username']);
   unset($_SESSION['fullname']);
   }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Vault Overview</title>
<meta name="generator" content="WYSIWYG Web Builder 16 - https://www.wysiwygwebbuilder.com">
<link href="https://fonts.googleapis.com/css?family=Alegreya:700,500,400" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Cairo:700" rel="stylesheet">
<link href="AAERO-DSAHBOARD.css" rel="stylesheet">
<link href="edit-account.css" rel="stylesheet">
</head>
<body>
<div id="wb_LoginName1" style="position:absolute;left:546px;top:117px;width:297px;height:41px;z-index:0;">
<span id="LoginName1">Welcome <?php
if (isset($_SESSION['username']))
{
   echo $_SESSION['username'];
}
else
{
   echo 'Not logged in';
}
?>!</span></div>
<div id="wb_Logout1" style="position:absolute;left:362px;top:158px;width:90px;height:35px;text-align:center;z-index:1;">
<form name="logoutform" method="post" action="<?php echo basename(__FILE__); ?>" id="logoutform">
<input type="hidden" name="form_name" value="logoutform">
<button type="submit" name="logout" value="Logout" id="Logout1">Logout</button>
</form>
</div>

<div id="wb_EditAccount1" style="position:absolute;left:492px;top:178px;width:291px;height:1382px;z-index:3;">
<form name="editprofileform" method="post" accept-charset="UTF-8" action="<?php echo basename(__FILE__); ?>" id="editprofileform">
<input type="hidden" name="form_name" value="editprofileform">
<table id="EditAccount1">
<tr>
   <td class="header">Edit Profile</td>
</tr>
<tr>
   <td class="label"><label for="fullname">Full Name</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="fullname" type="text" id="fullname" value="<?php echo $db_fullname; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="username">User Name</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="username" type="text" id="username" value="<?php echo $db_username; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="password">Password</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="password" type="password" id="password"></td>
</tr>
<tr>
   <td class="label"><label for="confirmpassword">Confirm Password</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="confirmpassword" type="password" id="confirmpassword"></td>
</tr>
<tr>
   <td class="label"><label for="email">E-mail</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="email" type="text" id="email" value="<?php echo $db_email; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra1">Address</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra1" type="text" id="extra1" value="<?php echo $db_extra1; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra2">Country</label></td>
</tr>
<tr>
   <td class="row">
   <select class="input" name="extra2" id="extra2">
      <option value="Afghanistan" <?php echo $selected_extra2[0]; ?>>Afghanistan</option>
      <option value="Albania" <?php echo $selected_extra2[1]; ?>>Albania</option>
      <option value="Algeria" <?php echo $selected_extra2[2]; ?>>Algeria</option>
      <option value="Andorra" <?php echo $selected_extra2[3]; ?>>Andorra</option>
      <option value="Angola" <?php echo $selected_extra2[4]; ?>>Angola</option>
      <option value="Antigua & Deps" <?php echo $selected_extra2[5]; ?>>Antigua & Deps</option>
      <option value="Argentina" <?php echo $selected_extra2[6]; ?>>Argentina</option>
      <option value="Armenia" <?php echo $selected_extra2[7]; ?>>Armenia</option>
      <option value="Australia" <?php echo $selected_extra2[8]; ?>>Australia</option>
      <option value="Austria" <?php echo $selected_extra2[9]; ?>>Austria</option>
      <option value="Azerbaijan" <?php echo $selected_extra2[10]; ?>>Azerbaijan</option>
      <option value="Bahamas" <?php echo $selected_extra2[11]; ?>>Bahamas</option>
      <option value="Bahrain" <?php echo $selected_extra2[12]; ?>>Bahrain</option>
      <option value="Bangladesh" <?php echo $selected_extra2[13]; ?>>Bangladesh</option>
      <option value="Barbados" <?php echo $selected_extra2[14]; ?>>Barbados</option>
      <option value="Belarus" <?php echo $selected_extra2[15]; ?>>Belarus</option>
      <option value="Belgium" <?php echo $selected_extra2[16]; ?>>Belgium</option>
      <option value="Belize" <?php echo $selected_extra2[17]; ?>>Belize</option>
      <option value="Benin" <?php echo $selected_extra2[18]; ?>>Benin</option>
      <option value="Bhutan" <?php echo $selected_extra2[19]; ?>>Bhutan</option>
      <option value="Bolivia" <?php echo $selected_extra2[20]; ?>>Bolivia</option>
      <option value="Bosnia Herzegovina" <?php echo $selected_extra2[21]; ?>>Bosnia Herzegovina</option>
      <option value="Botswana" <?php echo $selected_extra2[22]; ?>>Botswana</option>
      <option value="Brazil" <?php echo $selected_extra2[23]; ?>>Brazil</option>
      <option value="Brunei" <?php echo $selected_extra2[24]; ?>>Brunei</option>
      <option value="Bulgaria" <?php echo $selected_extra2[25]; ?>>Bulgaria</option>
      <option value="Burkina" <?php echo $selected_extra2[26]; ?>>Burkina</option>
      <option value="Burundi" <?php echo $selected_extra2[27]; ?>>Burundi</option>
      <option value="Cambodia" <?php echo $selected_extra2[28]; ?>>Cambodia</option>
      <option value="Cameroon" <?php echo $selected_extra2[29]; ?>>Cameroon</option>
      <option value="Canada" <?php echo $selected_extra2[30]; ?>>Canada</option>
      <option value="Cape Verde" <?php echo $selected_extra2[31]; ?>>Cape Verde</option>
      <option value="Central African Rep" <?php echo $selected_extra2[32]; ?>>Central African Rep</option>
      <option value="Chad" <?php echo $selected_extra2[33]; ?>>Chad</option>
      <option value="Chile" <?php echo $selected_extra2[34]; ?>>Chile</option>
      <option value="China" <?php echo $selected_extra2[35]; ?>>China</option>
      <option value="Colombia" <?php echo $selected_extra2[36]; ?>>Colombia</option>
      <option value="Comoros" <?php echo $selected_extra2[37]; ?>>Comoros</option>
      <option value="Congo" <?php echo $selected_extra2[38]; ?>>Congo</option>
      <option value="Congo {Democratic Rep}" <?php echo $selected_extra2[39]; ?>>Congo {Democratic Rep}</option>
      <option value="Costa Rica" <?php echo $selected_extra2[40]; ?>>Costa Rica</option>
      <option value="Croatia" <?php echo $selected_extra2[41]; ?>>Croatia</option>
      <option value="Cuba" <?php echo $selected_extra2[42]; ?>>Cuba</option>
      <option value="Cyprus" <?php echo $selected_extra2[43]; ?>>Cyprus</option>
      <option value="Czech Republic" <?php echo $selected_extra2[44]; ?>>Czech Republic</option>
      <option value="Denmark" <?php echo $selected_extra2[45]; ?>>Denmark</option>
      <option value="Djibouti" <?php echo $selected_extra2[46]; ?>>Djibouti</option>
      <option value="Dominica" <?php echo $selected_extra2[47]; ?>>Dominica</option>
      <option value="Dominican Republic" <?php echo $selected_extra2[48]; ?>>Dominican Republic</option>
      <option value="East Timor" <?php echo $selected_extra2[49]; ?>>East Timor</option>
      <option value="Ecuador" <?php echo $selected_extra2[50]; ?>>Ecuador</option>
      <option value="Egypt" <?php echo $selected_extra2[51]; ?>>Egypt</option>
      <option value="El Salvador" <?php echo $selected_extra2[52]; ?>>El Salvador</option>
      <option value="Equatorial Guinea" <?php echo $selected_extra2[53]; ?>>Equatorial Guinea</option>
      <option value="Eritrea" <?php echo $selected_extra2[54]; ?>>Eritrea</option>
      <option value="Estonia" <?php echo $selected_extra2[55]; ?>>Estonia</option>
      <option value="Ethiopia" <?php echo $selected_extra2[56]; ?>>Ethiopia</option>
      <option value="Fiji" <?php echo $selected_extra2[57]; ?>>Fiji</option>
      <option value="Finland" <?php echo $selected_extra2[58]; ?>>Finland</option>
      <option value="France" <?php echo $selected_extra2[59]; ?>>France</option>
      <option value="Gabon" <?php echo $selected_extra2[60]; ?>>Gabon</option>
      <option value="Gambia" <?php echo $selected_extra2[61]; ?>>Gambia</option>
      <option value="Georgia" <?php echo $selected_extra2[62]; ?>>Georgia</option>
      <option value="Germany" <?php echo $selected_extra2[63]; ?>>Germany</option>
      <option value="Ghana" <?php echo $selected_extra2[64]; ?>>Ghana</option>
      <option value="Greece" <?php echo $selected_extra2[65]; ?>>Greece</option>
      <option value="Grenada" <?php echo $selected_extra2[66]; ?>>Grenada</option>
      <option value="Guatemala" <?php echo $selected_extra2[67]; ?>>Guatemala</option>
      <option value="Guinea" <?php echo $selected_extra2[68]; ?>>Guinea</option>
      <option value="Guinea-Bissau" <?php echo $selected_extra2[69]; ?>>Guinea-Bissau</option>
      <option value="Guyana" <?php echo $selected_extra2[70]; ?>>Guyana</option>
      <option value="Haiti" <?php echo $selected_extra2[71]; ?>>Haiti</option>
      <option value="Honduras" <?php echo $selected_extra2[72]; ?>>Honduras</option>
      <option value="Hungary" <?php echo $selected_extra2[73]; ?>>Hungary</option>
      <option value="Iceland" <?php echo $selected_extra2[74]; ?>>Iceland</option>
      <option value="India" <?php echo $selected_extra2[75]; ?>>India</option>
      <option value="Indonesia" <?php echo $selected_extra2[76]; ?>>Indonesia</option>
      <option value="Iran" <?php echo $selected_extra2[77]; ?>>Iran</option>
      <option value="Iraq" <?php echo $selected_extra2[78]; ?>>Iraq</option>
      <option value="Ireland {Republic}" <?php echo $selected_extra2[79]; ?>>Ireland {Republic}</option>
      <option value="Israel" <?php echo $selected_extra2[80]; ?>>Israel</option>
      <option value="Italy" <?php echo $selected_extra2[81]; ?>>Italy</option>
      <option value="Ivory Coast" <?php echo $selected_extra2[82]; ?>>Ivory Coast</option>
      <option value="Jamaica" <?php echo $selected_extra2[83]; ?>>Jamaica</option>
      <option value="Japan" <?php echo $selected_extra2[84]; ?>>Japan</option>
      <option value="Jordan" <?php echo $selected_extra2[85]; ?>>Jordan</option>
      <option value="Kazakhstan" <?php echo $selected_extra2[86]; ?>>Kazakhstan</option>
      <option value="Kenya" <?php echo $selected_extra2[87]; ?>>Kenya</option>
      <option value="Kiribati" <?php echo $selected_extra2[88]; ?>>Kiribati</option>
      <option value="Korea North" <?php echo $selected_extra2[89]; ?>>Korea North</option>
      <option value="Korea South" <?php echo $selected_extra2[90]; ?>>Korea South</option>
      <option value="Kosovo" <?php echo $selected_extra2[91]; ?>>Kosovo</option>
      <option value="Kuwait" <?php echo $selected_extra2[92]; ?>>Kuwait</option>
      <option value="Kyrgyzstan" <?php echo $selected_extra2[93]; ?>>Kyrgyzstan</option>
      <option value="Laos" <?php echo $selected_extra2[94]; ?>>Laos</option>
      <option value="Latvia" <?php echo $selected_extra2[95]; ?>>Latvia</option>
      <option value="Lebanon" <?php echo $selected_extra2[96]; ?>>Lebanon</option>
      <option value="Lesotho" <?php echo $selected_extra2[97]; ?>>Lesotho</option>
      <option value="Liberia" <?php echo $selected_extra2[98]; ?>>Liberia</option>
      <option value="Libya" <?php echo $selected_extra2[99]; ?>>Libya</option>
      <option value="Liechtenstein" <?php echo $selected_extra2[100]; ?>>Liechtenstein</option>
      <option value="Lithuania" <?php echo $selected_extra2[101]; ?>>Lithuania</option>
      <option value="Luxembourg" <?php echo $selected_extra2[102]; ?>>Luxembourg</option>
      <option value="Macedonia" <?php echo $selected_extra2[103]; ?>>Macedonia</option>
      <option value="Madagascar" <?php echo $selected_extra2[104]; ?>>Madagascar</option>
      <option value="Malawi" <?php echo $selected_extra2[105]; ?>>Malawi</option>
      <option value="Malaysia" <?php echo $selected_extra2[106]; ?>>Malaysia</option>
      <option value="Maldives" <?php echo $selected_extra2[107]; ?>>Maldives</option>
      <option value="Mali" <?php echo $selected_extra2[108]; ?>>Mali</option>
      <option value="Malta" <?php echo $selected_extra2[109]; ?>>Malta</option>
      <option value="Marshall Islands" <?php echo $selected_extra2[110]; ?>>Marshall Islands</option>
      <option value="Mauritania" <?php echo $selected_extra2[111]; ?>>Mauritania</option>
      <option value="Mauritius" <?php echo $selected_extra2[112]; ?>>Mauritius</option>
      <option value="Mexico" <?php echo $selected_extra2[113]; ?>>Mexico</option>
      <option value="Micronesia" <?php echo $selected_extra2[114]; ?>>Micronesia</option>
      <option value="Moldova" <?php echo $selected_extra2[115]; ?>>Moldova</option>
      <option value="Monaco" <?php echo $selected_extra2[116]; ?>>Monaco</option>
      <option value="Mongolia" <?php echo $selected_extra2[117]; ?>>Mongolia</option>
      <option value="Montenegro" <?php echo $selected_extra2[118]; ?>>Montenegro</option>
      <option value="Morocco" <?php echo $selected_extra2[119]; ?>>Morocco</option>
      <option value="Mozambique" <?php echo $selected_extra2[120]; ?>>Mozambique</option>
      <option value="Myanmar, {Burma}" <?php echo $selected_extra2[121]; ?>>Myanmar, {Burma}</option>
      <option value="Namibia" <?php echo $selected_extra2[122]; ?>>Namibia</option>
      <option value="Nauru" <?php echo $selected_extra2[123]; ?>>Nauru</option>
      <option value="Nepal" <?php echo $selected_extra2[124]; ?>>Nepal</option>
      <option value="Netherlands" <?php echo $selected_extra2[125]; ?>>Netherlands</option>
      <option value="New Zealand" <?php echo $selected_extra2[126]; ?>>New Zealand</option>
      <option value="Nicaragua" <?php echo $selected_extra2[127]; ?>>Nicaragua</option>
      <option value="Niger" <?php echo $selected_extra2[128]; ?>>Niger</option>
      <option value="Nigeria" <?php echo $selected_extra2[129]; ?>>Nigeria</option>
      <option value="Norway" <?php echo $selected_extra2[130]; ?>>Norway</option>
      <option value="Oman" <?php echo $selected_extra2[131]; ?>>Oman</option>
      <option value="Pakistan" <?php echo $selected_extra2[132]; ?>>Pakistan</option>
      <option value="Palau" <?php echo $selected_extra2[133]; ?>>Palau</option>
      <option value="Panama" <?php echo $selected_extra2[134]; ?>>Panama</option>
      <option value="Papua New Guinea" <?php echo $selected_extra2[135]; ?>>Papua New Guinea</option>
      <option value="Paraguay" <?php echo $selected_extra2[136]; ?>>Paraguay</option>
      <option value="Peru" <?php echo $selected_extra2[137]; ?>>Peru</option>
      <option value="Philippines" <?php echo $selected_extra2[138]; ?>>Philippines</option>
      <option value="Poland" <?php echo $selected_extra2[139]; ?>>Poland</option>
      <option value="Portugal" <?php echo $selected_extra2[140]; ?>>Portugal</option>
      <option value="Qatar" <?php echo $selected_extra2[141]; ?>>Qatar</option>
      <option value="Romania" <?php echo $selected_extra2[142]; ?>>Romania</option>
      <option value="Russian Federation" <?php echo $selected_extra2[143]; ?>>Russian Federation</option>
      <option value="Rwanda" <?php echo $selected_extra2[144]; ?>>Rwanda</option>
      <option value="St Kitts & Nevis" <?php echo $selected_extra2[145]; ?>>St Kitts & Nevis</option>
      <option value="St Lucia" <?php echo $selected_extra2[146]; ?>>St Lucia</option>
      <option value="Saint Vincent & the Grenadines" <?php echo $selected_extra2[147]; ?>>Saint Vincent & the Grenadines</option>
      <option value="Samoa" <?php echo $selected_extra2[148]; ?>>Samoa</option>
      <option value="San Marino" <?php echo $selected_extra2[149]; ?>>San Marino</option>
      <option value="Sao Tome & Principe" <?php echo $selected_extra2[150]; ?>>Sao Tome & Principe</option>
      <option value="Saudi Arabia" <?php echo $selected_extra2[151]; ?>>Saudi Arabia</option>
      <option value="Senegal" <?php echo $selected_extra2[152]; ?>>Senegal</option>
      <option value="Serbia" <?php echo $selected_extra2[153]; ?>>Serbia</option>
      <option value="Seychelles" <?php echo $selected_extra2[154]; ?>>Seychelles</option>
      <option value="Sierra Leone" <?php echo $selected_extra2[155]; ?>>Sierra Leone</option>
      <option value="Singapore" <?php echo $selected_extra2[156]; ?>>Singapore</option>
      <option value="Slovakia" <?php echo $selected_extra2[157]; ?>>Slovakia</option>
      <option value="Slovenia" <?php echo $selected_extra2[158]; ?>>Slovenia</option>
      <option value="Solomon Islands" <?php echo $selected_extra2[159]; ?>>Solomon Islands</option>
      <option value="Somalia" <?php echo $selected_extra2[160]; ?>>Somalia</option>
      <option value="South Africa" <?php echo $selected_extra2[161]; ?>>South Africa</option>
      <option value="South Sudan" <?php echo $selected_extra2[162]; ?>>South Sudan</option>
      <option value="Spain" <?php echo $selected_extra2[163]; ?>>Spain</option>
      <option value="Sri Lanka" <?php echo $selected_extra2[164]; ?>>Sri Lanka</option>
      <option value="Sudan" <?php echo $selected_extra2[165]; ?>>Sudan</option>
      <option value="Suriname" <?php echo $selected_extra2[166]; ?>>Suriname</option>
      <option value="Swaziland" <?php echo $selected_extra2[167]; ?>>Swaziland</option>
      <option value="Sweden" <?php echo $selected_extra2[168]; ?>>Sweden</option>
      <option value="Switzerland" <?php echo $selected_extra2[169]; ?>>Switzerland</option>
      <option value="Syria" <?php echo $selected_extra2[170]; ?>>Syria</option>
      <option value="Taiwan" <?php echo $selected_extra2[171]; ?>>Taiwan</option>
      <option value="Tajikistan" <?php echo $selected_extra2[172]; ?>>Tajikistan</option>
      <option value="Tanzania" <?php echo $selected_extra2[173]; ?>>Tanzania</option>
      <option value="Thailand" <?php echo $selected_extra2[174]; ?>>Thailand</option>
      <option value="Togo" <?php echo $selected_extra2[175]; ?>>Togo</option>
      <option value="Tonga" <?php echo $selected_extra2[176]; ?>>Tonga</option>
      <option value="Trinidad & Tobago" <?php echo $selected_extra2[177]; ?>>Trinidad & Tobago</option>
      <option value="Tunisia" <?php echo $selected_extra2[178]; ?>>Tunisia</option>
      <option value="Turkey" <?php echo $selected_extra2[179]; ?>>Turkey</option>
      <option value="Turkmenistan" <?php echo $selected_extra2[180]; ?>>Turkmenistan</option>
      <option value="Tuvalu" <?php echo $selected_extra2[181]; ?>>Tuvalu</option>
      <option value="Uganda" <?php echo $selected_extra2[182]; ?>>Uganda</option>
      <option value="Ukraine" <?php echo $selected_extra2[183]; ?>>Ukraine</option>
      <option value="United Arab Emirates" <?php echo $selected_extra2[184]; ?>>United Arab Emirates</option>
      <option value="United Kingdom" <?php echo $selected_extra2[185]; ?>>United Kingdom</option>
      <option value="United States" <?php echo $selected_extra2[186]; ?>>United States</option>
      <option value="Uruguay" <?php echo $selected_extra2[187]; ?>>Uruguay</option>
      <option value="Uzbekistan" <?php echo $selected_extra2[188]; ?>>Uzbekistan</option>
      <option value="Vanuatu" <?php echo $selected_extra2[189]; ?>>Vanuatu</option>
      <option value="Vatican City" <?php echo $selected_extra2[190]; ?>>Vatican City</option>
      <option value="Venezuela" <?php echo $selected_extra2[191]; ?>>Venezuela</option>
      <option value="Vietnam" <?php echo $selected_extra2[192]; ?>>Vietnam</option>
      <option value="Yemen" <?php echo $selected_extra2[193]; ?>>Yemen</option>
      <option value="Zambia" <?php echo $selected_extra2[194]; ?>>Zambia</option>
      <option value="Zimbabwe" <?php echo $selected_extra2[195]; ?>>Zimbabwe</option>
   </select>
</td>
</tr>
<tr>
   <td class="label"><label for="extra3">City</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra3" type="text" id="extra3" value="<?php echo $db_extra3; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra4">State</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra4" type="text" id="extra4" value="<?php echo $db_extra4; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra5">Zipcode</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra5" type="text" id="extra5" value="<?php echo $db_extra5; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra6">Nationality</label></td>
</tr>
<tr>
   <td class="row">
   <select class="input" name="extra6" id="extra6">
      <option value="Afghan" <?php echo $selected_extra6[0]; ?>>Afghan</option>
      <option value="Albanian" <?php echo $selected_extra6[1]; ?>>Albanian</option>
      <option value="Algerian" <?php echo $selected_extra6[2]; ?>>Algerian</option>
      <option value="American" <?php echo $selected_extra6[3]; ?>>American</option>
      <option value="Andorran" <?php echo $selected_extra6[4]; ?>>Andorran</option>
      <option value="Angolan" <?php echo $selected_extra6[5]; ?>>Angolan</option>
      <option value="Antiguans" <?php echo $selected_extra6[6]; ?>>Antiguans</option>
      <option value="Argentinean" <?php echo $selected_extra6[7]; ?>>Argentinean</option>
      <option value="Armenian" <?php echo $selected_extra6[8]; ?>>Armenian</option>
      <option value="Australian" <?php echo $selected_extra6[9]; ?>>Australian</option>
      <option value="Austrian" <?php echo $selected_extra6[10]; ?>>Austrian</option>
      <option value="Azerbaijani" <?php echo $selected_extra6[11]; ?>>Azerbaijani</option>
      <option value="Bahamian" <?php echo $selected_extra6[12]; ?>>Bahamian</option>
      <option value="Bahraini" <?php echo $selected_extra6[13]; ?>>Bahraini</option>
      <option value="Bangladeshi" <?php echo $selected_extra6[14]; ?>>Bangladeshi</option>
      <option value="Barbadian" <?php echo $selected_extra6[15]; ?>>Barbadian</option>
      <option value="Barbudans" <?php echo $selected_extra6[16]; ?>>Barbudans</option>
      <option value="Batswana" <?php echo $selected_extra6[17]; ?>>Batswana</option>
      <option value="Belarusian" <?php echo $selected_extra6[18]; ?>>Belarusian</option>
      <option value="Belgian" <?php echo $selected_extra6[19]; ?>>Belgian</option>
      <option value="Belizean" <?php echo $selected_extra6[20]; ?>>Belizean</option>
      <option value="Beninese" <?php echo $selected_extra6[21]; ?>>Beninese</option>
      <option value="Bhutanese" <?php echo $selected_extra6[22]; ?>>Bhutanese</option>
      <option value="Bolivian" <?php echo $selected_extra6[23]; ?>>Bolivian</option>
      <option value="Bosnian" <?php echo $selected_extra6[24]; ?>>Bosnian</option>
      <option value="Brazilian" <?php echo $selected_extra6[25]; ?>>Brazilian</option>
      <option value="British" <?php echo $selected_extra6[26]; ?>>British</option>
      <option value="Bruneian" <?php echo $selected_extra6[27]; ?>>Bruneian</option>
      <option value="Bulgarian" <?php echo $selected_extra6[28]; ?>>Bulgarian</option>
      <option value="Burkinabe" <?php echo $selected_extra6[29]; ?>>Burkinabe</option>
      <option value="Burmese" <?php echo $selected_extra6[30]; ?>>Burmese</option>
      <option value="Burundian" <?php echo $selected_extra6[31]; ?>>Burundian</option>
      <option value="Cambodian" <?php echo $selected_extra6[32]; ?>>Cambodian</option>
      <option value="Cameroonian" <?php echo $selected_extra6[33]; ?>>Cameroonian</option>
      <option value="Canadian" <?php echo $selected_extra6[34]; ?>>Canadian</option>
      <option value="Cape Verdean" <?php echo $selected_extra6[35]; ?>>Cape Verdean</option>
      <option value="Central African" <?php echo $selected_extra6[36]; ?>>Central African</option>
      <option value="Chadian" <?php echo $selected_extra6[37]; ?>>Chadian</option>
      <option value="Chilean" <?php echo $selected_extra6[38]; ?>>Chilean</option>
      <option value="Chinese" <?php echo $selected_extra6[39]; ?>>Chinese</option>
      <option value="Colombian" <?php echo $selected_extra6[40]; ?>>Colombian</option>
      <option value="Comoran" <?php echo $selected_extra6[41]; ?>>Comoran</option>
      <option value="Congolese" <?php echo $selected_extra6[42]; ?>>Congolese</option>
      <option value="Costa Rican" <?php echo $selected_extra6[43]; ?>>Costa Rican</option>
      <option value="Croatian" <?php echo $selected_extra6[44]; ?>>Croatian</option>
      <option value="Cuban" <?php echo $selected_extra6[45]; ?>>Cuban</option>
      <option value="Cypriot" <?php echo $selected_extra6[46]; ?>>Cypriot</option>
      <option value="Czech" <?php echo $selected_extra6[47]; ?>>Czech</option>
      <option value="Danish" <?php echo $selected_extra6[48]; ?>>Danish</option>
      <option value="Djibouti" <?php echo $selected_extra6[49]; ?>>Djibouti</option>
      <option value="Dominican" <?php echo $selected_extra6[50]; ?>>Dominican</option>
      <option value="Dutch" <?php echo $selected_extra6[51]; ?>>Dutch</option>
      <option value="East Timorese" <?php echo $selected_extra6[52]; ?>>East Timorese</option>
      <option value="Ecuadorean" <?php echo $selected_extra6[53]; ?>>Ecuadorean</option>
      <option value="Egyptian" <?php echo $selected_extra6[54]; ?>>Egyptian</option>
      <option value="Emirian" <?php echo $selected_extra6[55]; ?>>Emirian</option>
      <option value="Equatorial Guinean" <?php echo $selected_extra6[56]; ?>>Equatorial Guinean</option>
      <option value="Eritrean" <?php echo $selected_extra6[57]; ?>>Eritrean</option>
      <option value="Estonian" <?php echo $selected_extra6[58]; ?>>Estonian</option>
      <option value="Ethiopian" <?php echo $selected_extra6[59]; ?>>Ethiopian</option>
      <option value="Fijian" <?php echo $selected_extra6[60]; ?>>Fijian</option>
      <option value="Filipino" <?php echo $selected_extra6[61]; ?>>Filipino</option>
      <option value="Finnish" <?php echo $selected_extra6[62]; ?>>Finnish</option>
      <option value="French" <?php echo $selected_extra6[63]; ?>>French</option>
      <option value="Gabonese" <?php echo $selected_extra6[64]; ?>>Gabonese</option>
      <option value="Gambian" <?php echo $selected_extra6[65]; ?>>Gambian</option>
      <option value="Georgian" <?php echo $selected_extra6[66]; ?>>Georgian</option>
      <option value="German" <?php echo $selected_extra6[67]; ?>>German</option>
      <option value="Ghanaian" <?php echo $selected_extra6[68]; ?>>Ghanaian</option>
      <option value="Greek" <?php echo $selected_extra6[69]; ?>>Greek</option>
      <option value="Grenadian" <?php echo $selected_extra6[70]; ?>>Grenadian</option>
      <option value="Guatemalan" <?php echo $selected_extra6[71]; ?>>Guatemalan</option>
      <option value="Guinea-Bissauan" <?php echo $selected_extra6[72]; ?>>Guinea-Bissauan</option>
      <option value="Guinean" <?php echo $selected_extra6[73]; ?>>Guinean</option>
      <option value="Guyanese" <?php echo $selected_extra6[74]; ?>>Guyanese</option>
      <option value="Haitian" <?php echo $selected_extra6[75]; ?>>Haitian</option>
      <option value="Herzegovinian" <?php echo $selected_extra6[76]; ?>>Herzegovinian</option>
      <option value="Honduran" <?php echo $selected_extra6[77]; ?>>Honduran</option>
      <option value="Hungarian" <?php echo $selected_extra6[78]; ?>>Hungarian</option>
      <option value="I-Kiribati" <?php echo $selected_extra6[79]; ?>>I-Kiribati</option>
      <option value="Icelander" <?php echo $selected_extra6[80]; ?>>Icelander</option>
      <option value="Indian" <?php echo $selected_extra6[81]; ?>>Indian</option>
      <option value="Indonesian" <?php echo $selected_extra6[82]; ?>>Indonesian</option>
      <option value="Iranian" <?php echo $selected_extra6[83]; ?>>Iranian</option>
      <option value="Iraqi" <?php echo $selected_extra6[84]; ?>>Iraqi</option>
      <option value="Irish" <?php echo $selected_extra6[85]; ?>>Irish</option>
      <option value="Israeli" <?php echo $selected_extra6[86]; ?>>Israeli</option>
      <option value="Italian" <?php echo $selected_extra6[87]; ?>>Italian</option>
      <option value="Ivorian" <?php echo $selected_extra6[88]; ?>>Ivorian</option>
      <option value="Jamaican" <?php echo $selected_extra6[89]; ?>>Jamaican</option>
      <option value="Japanese" <?php echo $selected_extra6[90]; ?>>Japanese</option>
      <option value="Jordanian" <?php echo $selected_extra6[91]; ?>>Jordanian</option>
      <option value="Kazakhstani" <?php echo $selected_extra6[92]; ?>>Kazakhstani</option>
      <option value="Kenyan" <?php echo $selected_extra6[93]; ?>>Kenyan</option>
      <option value="Kittian and Nevisian" <?php echo $selected_extra6[94]; ?>>Kittian and Nevisian</option>
      <option value="Kuwaiti" <?php echo $selected_extra6[95]; ?>>Kuwaiti</option>
      <option value="Kyrgyz" <?php echo $selected_extra6[96]; ?>>Kyrgyz</option>
      <option value="Laotian" <?php echo $selected_extra6[97]; ?>>Laotian</option>
      <option value="Latvian" <?php echo $selected_extra6[98]; ?>>Latvian</option>
      <option value="Lebanese" <?php echo $selected_extra6[99]; ?>>Lebanese</option>
      <option value="Liberian" <?php echo $selected_extra6[100]; ?>>Liberian</option>
      <option value="Libyan" <?php echo $selected_extra6[101]; ?>>Libyan</option>
      <option value="Liechtensteiner" <?php echo $selected_extra6[102]; ?>>Liechtensteiner</option>
      <option value="Lithuanian" <?php echo $selected_extra6[103]; ?>>Lithuanian</option>
      <option value="Luxembourger" <?php echo $selected_extra6[104]; ?>>Luxembourger</option>
      <option value="Macedonian" <?php echo $selected_extra6[105]; ?>>Macedonian</option>
      <option value="Malagasy" <?php echo $selected_extra6[106]; ?>>Malagasy</option>
      <option value="Malawian" <?php echo $selected_extra6[107]; ?>>Malawian</option>
      <option value="Malaysian" <?php echo $selected_extra6[108]; ?>>Malaysian</option>
      <option value="Maldivian" <?php echo $selected_extra6[109]; ?>>Maldivian</option>
      <option value="Malian" <?php echo $selected_extra6[110]; ?>>Malian</option>
      <option value="Maltese" <?php echo $selected_extra6[111]; ?>>Maltese</option>
      <option value="Marshallese" <?php echo $selected_extra6[112]; ?>>Marshallese</option>
      <option value="Mauritanian" <?php echo $selected_extra6[113]; ?>>Mauritanian</option>
      <option value="Mauritian" <?php echo $selected_extra6[114]; ?>>Mauritian</option>
      <option value="Mexican" <?php echo $selected_extra6[115]; ?>>Mexican</option>
      <option value="Micronesian" <?php echo $selected_extra6[116]; ?>>Micronesian</option>
      <option value="Moldovan" <?php echo $selected_extra6[117]; ?>>Moldovan</option>
      <option value="Monacan" <?php echo $selected_extra6[118]; ?>>Monacan</option>
      <option value="Mongolian" <?php echo $selected_extra6[119]; ?>>Mongolian</option>
      <option value="Moroccan" <?php echo $selected_extra6[120]; ?>>Moroccan</option>
      <option value="Mosotho" <?php echo $selected_extra6[121]; ?>>Mosotho</option>
      <option value="Motswana" <?php echo $selected_extra6[122]; ?>>Motswana</option>
      <option value="Mozambican" <?php echo $selected_extra6[123]; ?>>Mozambican</option>
      <option value="Namibian" <?php echo $selected_extra6[124]; ?>>Namibian</option>
      <option value="Nauruan" <?php echo $selected_extra6[125]; ?>>Nauruan</option>
      <option value="Nepalese" <?php echo $selected_extra6[126]; ?>>Nepalese</option>
      <option value="New Zealander" <?php echo $selected_extra6[127]; ?>>New Zealander</option>
      <option value="Ni-Vanuatu" <?php echo $selected_extra6[128]; ?>>Ni-Vanuatu</option>
      <option value="Nicaraguan" <?php echo $selected_extra6[129]; ?>>Nicaraguan</option>
      <option value="Nigerian" <?php echo $selected_extra6[130]; ?>>Nigerian</option>
      <option value="Nigerien" <?php echo $selected_extra6[131]; ?>>Nigerien</option>
      <option value="North Korean" <?php echo $selected_extra6[132]; ?>>North Korean</option>
      <option value="Northern Irish" <?php echo $selected_extra6[133]; ?>>Northern Irish</option>
      <option value="Norwegian" <?php echo $selected_extra6[134]; ?>>Norwegian</option>
      <option value="Omani" <?php echo $selected_extra6[135]; ?>>Omani</option>
      <option value="Pakistani" <?php echo $selected_extra6[136]; ?>>Pakistani</option>
      <option value="Palauan" <?php echo $selected_extra6[137]; ?>>Palauan</option>
      <option value="Panamanian" <?php echo $selected_extra6[138]; ?>>Panamanian</option>
      <option value="Papua New Guinean" <?php echo $selected_extra6[139]; ?>>Papua New Guinean</option>
      <option value="Paraguayan" <?php echo $selected_extra6[140]; ?>>Paraguayan</option>
      <option value="Peruvian" <?php echo $selected_extra6[141]; ?>>Peruvian</option>
      <option value="Polish" <?php echo $selected_extra6[142]; ?>>Polish</option>
      <option value="Portuguese" <?php echo $selected_extra6[143]; ?>>Portuguese</option>
      <option value="Qatari" <?php echo $selected_extra6[144]; ?>>Qatari</option>
      <option value="Romanian" <?php echo $selected_extra6[145]; ?>>Romanian</option>
      <option value="Russian" <?php echo $selected_extra6[146]; ?>>Russian</option>
      <option value="Rwandan" <?php echo $selected_extra6[147]; ?>>Rwandan</option>
      <option value="Saint Lucian" <?php echo $selected_extra6[148]; ?>>Saint Lucian</option>
      <option value="Salvadoran" <?php echo $selected_extra6[149]; ?>>Salvadoran</option>
      <option value="Samoan" <?php echo $selected_extra6[150]; ?>>Samoan</option>
      <option value="San Marinese" <?php echo $selected_extra6[151]; ?>>San Marinese</option>
      <option value="Sao Tomean" <?php echo $selected_extra6[152]; ?>>Sao Tomean</option>
      <option value="Saudi" <?php echo $selected_extra6[153]; ?>>Saudi</option>
      <option value="Scottish" <?php echo $selected_extra6[154]; ?>>Scottish</option>
      <option value="Senegalese" <?php echo $selected_extra6[155]; ?>>Senegalese</option>
      <option value="Serbian" <?php echo $selected_extra6[156]; ?>>Serbian</option>
      <option value="Seychellois" <?php echo $selected_extra6[157]; ?>>Seychellois</option>
      <option value="Sierra Leonean" <?php echo $selected_extra6[158]; ?>>Sierra Leonean</option>
      <option value="Singaporean" <?php echo $selected_extra6[159]; ?>>Singaporean</option>
      <option value="Slovakian" <?php echo $selected_extra6[160]; ?>>Slovakian</option>
      <option value="Slovenian" <?php echo $selected_extra6[161]; ?>>Slovenian</option>
      <option value="Solomon Islander" <?php echo $selected_extra6[162]; ?>>Solomon Islander</option>
      <option value="Somali" <?php echo $selected_extra6[163]; ?>>Somali</option>
      <option value="South African" <?php echo $selected_extra6[164]; ?>>South African</option>
      <option value="South Korean" <?php echo $selected_extra6[165]; ?>>South Korean</option>
      <option value="Spanish" <?php echo $selected_extra6[166]; ?>>Spanish</option>
      <option value="Sri Lankan" <?php echo $selected_extra6[167]; ?>>Sri Lankan</option>
      <option value="Sudanese" <?php echo $selected_extra6[168]; ?>>Sudanese</option>
      <option value="Surinamer" <?php echo $selected_extra6[169]; ?>>Surinamer</option>
      <option value="Swazi" <?php echo $selected_extra6[170]; ?>>Swazi</option>
      <option value="Swedish" <?php echo $selected_extra6[171]; ?>>Swedish</option>
      <option value="Swiss" <?php echo $selected_extra6[172]; ?>>Swiss</option>
      <option value="Syrian" <?php echo $selected_extra6[173]; ?>>Syrian</option>
      <option value="Taiwanese" <?php echo $selected_extra6[174]; ?>>Taiwanese</option>
      <option value="Tajik" <?php echo $selected_extra6[175]; ?>>Tajik</option>
      <option value="Tanzanian" <?php echo $selected_extra6[176]; ?>>Tanzanian</option>
      <option value="Thai" <?php echo $selected_extra6[177]; ?>>Thai</option>
      <option value="Togolese" <?php echo $selected_extra6[178]; ?>>Togolese</option>
      <option value="Tongan" <?php echo $selected_extra6[179]; ?>>Tongan</option>
      <option value="Trinidadian or Tobagonian" <?php echo $selected_extra6[180]; ?>>Trinidadian or Tobagonian</option>
      <option value="Tunisian" <?php echo $selected_extra6[181]; ?>>Tunisian</option>
      <option value="Turkish" <?php echo $selected_extra6[182]; ?>>Turkish</option>
      <option value="Tuvaluan" <?php echo $selected_extra6[183]; ?>>Tuvaluan</option>
      <option value="Ugandan" <?php echo $selected_extra6[184]; ?>>Ugandan</option>
      <option value="Ukrainian" <?php echo $selected_extra6[185]; ?>>Ukrainian</option>
      <option value="Uruguayan" <?php echo $selected_extra6[186]; ?>>Uruguayan</option>
      <option value="Uzbekistani" <?php echo $selected_extra6[187]; ?>>Uzbekistani</option>
      <option value="Venezuelan" <?php echo $selected_extra6[188]; ?>>Venezuelan</option>
      <option value="Vietnamese" <?php echo $selected_extra6[189]; ?>>Vietnamese</option>
      <option value="Welsh" <?php echo $selected_extra6[190]; ?>>Welsh</option>
      <option value="Yemenite" <?php echo $selected_extra6[191]; ?>>Yemenite</option>
      <option value="Zambian" <?php echo $selected_extra6[192]; ?>>Zambian</option>
      <option value="Zimbabwean" <?php echo $selected_extra6[193]; ?>>Zimbabwean</option>
   </select>
</td>
</tr>
<tr>
   <td class="label"><label for="extra7">Next of Kin</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra7" type="text" id="extra7" value="<?php echo $db_extra7; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra8">Item deposited</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra8" type="text" id="extra8" value="<?php echo $db_extra8; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra9">Monthly Charges</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra9" type="text" id="extra9" value="<?php echo $db_extra9; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra10">Container Value</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra10" type="text" id="extra10" value="<?php echo $db_extra10; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra11">Date of Deposit</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra11" type="text" id="extra11" value="<?php echo $db_extra11; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra12">Purpose of deposit</label></td>
</tr>
<tr>
   <td class="row">
   <select class="input" name="extra12" id="extra12">
      <option value="Safe Keeping" <?php echo $selected_extra12[0]; ?>>Safe Keeping</option>
      <option value="Shipping" <?php echo $selected_extra12[1]; ?>>Shipping</option>
   </select>
</td>
</tr>
<tr>
   <td class="label"><label for="extra13">Reference No</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra13" type="text" id="extra13" value="<?php echo $db_extra13; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra14">Release code</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra14" type="text" id="extra14" value="<?php echo $db_extra14; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra15">Account Value</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra15" type="text" id="extra15" value="<?php echo $db_extra15; ?>"></td>
</tr>
<tr>
   <td class="label"><label for="extra16">Account Due</label></td>
</tr>
<tr>
   <td class="row"><input class="input" name="extra16" type="text" id="extra16" value="<?php echo $db_extra16; ?>"></td>
</tr>
<tr>
   <td><?php echo $error_message; ?></td>
</tr>
<tr>
   <td style="text-align:center;vertical-align:bottom"><input class="button" type="submit" name="update" value="Update" id="update"></td>
</tr>
</table>
</form>
</div>
<div id="wb_DeleteAccount1" style="position:absolute;left:263px;top:269px;width:139px;height:62px;text-align:center;z-index:4;">
<form name="deleteaccount" method="post" action="<?php echo basename(__FILE__); ?>" id="deleteaccount">
<input type="hidden" name="form_name" value="deleteaccount">
<button type="submit" name="delete" value="Not logged in!" id="DeleteAccount1">Delete Account</button>
</form>
</div>
</body>
</html>