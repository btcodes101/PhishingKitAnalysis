<?php
session_start();
if (!isset($_SESSION['username']))
{
   $accessdenied_page = './../index.php';
   header('Location: '.$accessdenied_page);
   exit;
}
$mysql_server = 'localhost';
$mysql_username = 'jadejgra_dbaaero';
$mysql_password = 'xzXtcrb(i250';
$mysql_database = 'jadejgra_dbaaero';
$mysql_table = 'aaerotble';
$error_message = '';
$db_username = '';
$db_fullname = '';
$db_email = '';
$db_extra1 = '';
$db_extra2 = '';
$db_extra3 = '';
$db_extra4 = '';
$db_extra5 = '';
$db_extra6 = '';
$db_extra7 = '';
$db_extra8 = '';
$db_extra9 = '';
$db_extra10 = '';
$db_extra11 = '';
$db_extra12 = '';
$db_extra13 = '';
$db_extra14 = '';
$db_extra15 = '';
$db_extra16 = '';
$db_extra17 = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'editprofileform')
{
   $success_page = './../index.php';
   $oldusername = $_SESSION['username'];
   $newusername = $_POST['username'];
   $newemail = $_POST['email'];
   $newpassword = $_POST['password'];
   $confirmpassword = $_POST['confirmpassword'];
   $newfullname = $_POST['fullname'];
   $extra1 = $_POST['extra1'];
   $extra2 = $_POST['extra2'];
   $extra3 = $_POST['extra3'];
   $extra4 = $_POST['extra4'];
   $extra5 = $_POST['extra5'];
   $extra6 = $_POST['extra6'];
   $extra7 = $_POST['extra7'];
   $extra8 = $_POST['extra8'];
   $extra9 = $_POST['extra9'];
   $extra10 = $_POST['extra10'];
   $extra11 = $_POST['extra11'];
   $extra12 = $_POST['extra12'];
   $extra13 = $_POST['extra13'];
   $extra14 = $_POST['extra14'];
   $extra15 = $_POST['extra15'];
   $extra16 = $_POST['extra16'];
   $extra17 = $_POST['extra17'];
   if ($newpassword != $confirmpassword)
   {
      $error_message = 'Password and Confirm Password are not the same!';
   }
   else
   if (!preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newusername))
   {
      $error_message = 'Username is not valid, please check and try again!';
   }
   else
   if (!empty($newpassword) && !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newpassword))
   {
      $error_message = 'Password is not valid, please check and try again!';
   }
   else
   if (!preg_match("/^[A-Za-z0-9-_!@$.' &]{1,50}$/", $newfullname))
   {
      $error_message = 'Fullname is not valid, please check and try again!';
   }
   else
   if (!preg_match("/^.+@.+\..+$/", $newemail))
   {
      $error_message = 'Email is not a valid email address. Please check and try again.';
   }
   else
   {
      $db = mysqli_connect($mysql_server, $mysql_username, $mysql_password);
      if (!$db)
      {
         die('Failed to connect to database server!<br>'.mysqli_error($db));
      }
      mysqli_select_db($db, $mysql_database) or die('Failed to select database<br>'.mysqli_error($db));
      mysqli_set_charset($db, 'utf8');
      if ($oldusername != $newusername)
      {
         $sql = "SELECT username FROM ".$mysql_table." WHERE username = '".mysqli_real_escape_string($db, $newusername)."'";
         $result = mysqli_query($db, $sql);
         if ($data = mysqli_fetch_array($result))
         {
            $error_message = 'Username already used. Please select another username.';
         }
      }
      if (empty($error_message))
      {
         $crypt_pass = md5($newpassword);
         $newusername = mysqli_real_escape_string($db, $newusername);
         $newemail = mysqli_real_escape_string($db, $newemail);
         $newfullname = mysqli_real_escape_string($db, $newfullname);
         $extra1 = mysqli_real_escape_string($db, $extra1);
         $extra2 = mysqli_real_escape_string($db, $extra2);
         $extra3 = mysqli_real_escape_string($db, $extra3);
         $extra4 = mysqli_real_escape_string($db, $extra4);
         $extra5 = mysqli_real_escape_string($db, $extra5);
         $extra6 = mysqli_real_escape_string($db, $extra6);
         $extra7 = mysqli_real_escape_string($db, $extra7);
         $extra8 = mysqli_real_escape_string($db, $extra8);
         $extra9 = mysqli_real_escape_string($db, $extra9);
         $extra10 = mysqli_real_escape_string($db, $extra10);
         $extra11 = mysqli_real_escape_string($db, $extra11);
         $extra12 = mysqli_real_escape_string($db, $extra12);
         $extra13 = mysqli_real_escape_string($db, $extra13);
         $extra14 = mysqli_real_escape_string($db, $extra14);
         $extra15 = mysqli_real_escape_string($db, $extra15);
         $extra16 = mysqli_real_escape_string($db, $extra16);
         $extra17 = mysqli_real_escape_string($db, $extra17);
         $sql = "UPDATE `".$mysql_table."` SET `username` = '$newusername', `fullname` = '$newfullname', `email` = '$newemail', `extra1` = '$extra1', `extra2` = '$extra2', `extra3` = '$extra3', `extra4` = '$extra4', `extra5` = '$extra5', `extra6` = '$extra6', `extra7` = '$extra7', `extra8` = '$extra8', `extra9` = '$extra9', `extra10` = '$extra10', `extra11` = '$extra11', `extra12` = '$extra12', `extra13` = '$extra13', `extra14` = '$extra14', `extra15` = '$extra15', `extra16` = '$extra16', `extra17` = '$extra17' WHERE `username` = '$oldusername'";
         mysqli_query($db, $sql);
         if (!empty($newpassword))
         {
            $sql = "UPDATE `".$mysql_table."` SET `password` = '$crypt_pass' WHERE `username` = '$oldusername'";
            mysqli_query($db, $sql);
         }
      }
      mysqli_close($db);
      if (empty($error_message))
      {
         $_SESSION['username'] = $newusername;
         $_SESSION['fullname'] = $newfullname;
         header('Location: '.$success_page);
         exit;
      }
   }
}
$db = mysqli_connect($mysql_server, $mysql_username, $mysql_password);
if (!$db)
{
   die('Failed to connect to database server!<br>'.mysqli_error($db));
}
mysqli_select_db($db, $mysql_database) or die('Failed to select database<br>'.mysqli_error($db));
mysqli_set_charset($db, 'utf8');
$sql = "SELECT * FROM ".$mysql_table." WHERE username = '".$_SESSION['username']."'";
$result = mysqli_query($db, $sql);
if ($data = mysqli_fetch_array($result))
{
   $db_username = $data['username'];
   $db_fullname = $data['fullname'];
   $db_email = $data['email'];
   $db_extra1 = $data['extra1'];
   $db_extra2 = $data['extra2'];
   $db_extra3 = $data['extra3'];
   $db_extra4 = $data['extra4'];
   $db_extra5 = $data['extra5'];
   $db_extra6 = $data['extra6'];
   $db_extra7 = $data['extra7'];
   $db_extra8 = $data['extra8'];
   $db_extra9 = $data['extra9'];
   $db_extra10 = $data['extra10'];
   $db_extra11 = $data['extra11'];
   $db_extra12 = $data['extra12'];
   $db_extra13 = $data['extra13'];
   $db_extra14 = $data['extra14'];
   $db_extra15 = $data['extra15'];
   $db_extra16 = $data['extra16'];
   $db_extra17 = $data['extra17'];
}
mysqli_close($db);
$selected_extra13 = array("","");
switch ($db_extra13)
{
      case "Safe Keeping":
         $selected_extra13[0] = "selected";
         break;
      case "Shipping":
         $selected_extra13[1] = "selected";
         break;
}
?>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'logoutform')
{
   unset($_SESSION['username']);
   unset($_SESSION['fullname']);
}
if (!isset($_SESSION['username']))
{
   $_SESSION['referrer'] = $_SERVER['REQUEST_URI'];
   header('Location: ');
   exit;
}
if (isset($_SESSION['expires_by']))
{
   $expires_by = intval($_SESSION['expires_by']);
   if (time() < $expires_by)
   {
      $_SESSION['expires_by'] = time() + intval($_SESSION['expires_timeout']);
   }
   else
   {
      unset($_SESSION['username']);
      unset($_SESSION['expires_by']);
      unset($_SESSION['expires_timeout']);
      $_SESSION['referrer'] = $_SERVER['REQUEST_URI'];
      header('Location: ');
      exit;
   }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Vault Overview</title>
<meta name="generator" content="WYSIWYG Web Builder 16 - https://www.wysiwygwebbuilder.com">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Alegreya:700,500,400" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Cairo:700" rel="stylesheet">
<link href="AAERO-DSAHBOARD.css" rel="stylesheet">
<link href="account.css" rel="stylesheet">
</head>
<body>
<div id="PageHeader" style="position:fixed;text-align:left;left:0;top:0;right:0;height:50px;z-index:41;">
<div id="wb_CssMenu2" style="position:absolute;left:8px;top:5px;width:161px;height:41px;z-index:0;">
<ul id="CssMenu2" role="menubar" class="nav">
<li class="nav-item firstmain"><a role="menuitem" class="nav-link" href="#top" target="_self">DSAHBOARD</a>
</li>
</ul>
</div>
</div>

<div id="wb_LayoutGrid5">
<div id="LayoutGrid5">
<div class="row">
<div class="col-1">
</div>
<div class="col-2">
<div id="wb_LoginName1" style="display:inline-block;width:100%;text-align:right;z-index:1;">
<span id="LoginName1">Welcome <?php
if (isset($_SESSION['username']))
{
   echo $_SESSION['fullname'];
}
else
{
   echo 'Not logged in';
}
?>!</span>
</div>
</div>
<div class="col-3">
<div id="wb_Logout1" style="display:inline-block;width:100%;text-align:center;z-index:2;">
<form name="logoutform" method="post" action="<?php echo basename(__FILE__); ?>" id="logoutform" style="display:inline">
<input type="hidden" name="form_name" value="logoutform">
<button type="submit" name="logout" value="Logout" id="Logout1">Logout</button>
</form>

</div>
</div>
</div>
</div>
</div>
<div id="wb_LayoutGrid1">
<div id="LayoutGrid1">
<div class="row">
<div class="col-1">
<div id="wb_LayoutGrid2">
<div id="LayoutGrid2">
<div class="row">
<div class="col-1">
<div id="wb_IconFont1" style="display:inline-block;width:10px;height:57px;text-align:center;z-index:3;">
<div id="IconFont1"><i class="fa fa-money"></i></div>
</div>
</div>
<div class="col-2">
<label for="extra16" id="Label22" style="display:block;width:100%;line-height:21px;z-index:4;">Account Value</label>
<input type="text" id="extra16" style="display:block;width: 100%;height:28px;z-index:5;" name="extra16" value="<?php echo $db_extra16; ?>" readonly disabled spellcheck="false">
</div>
</div>
</div>
</div>
<div id="wb_LayoutGrid3">
<div id="LayoutGrid3">
<div class="row">
<div class="col-1">
<label for="extra17" id="Label23" style="display:block;width:100%;line-height:21px;z-index:6;">Account Due</label>
<input type="text" id="extra17" style="display:block;width: 100%;height:28px;z-index:7;" name="extra17" value="<?php echo $db_extra17; ?>" spellcheck="false">
</div>
</div>
</div>
</div>
<label for="fullname" id="Label2" style="display:block;width:100%;line-height:21px;z-index:10;">Name of Depositor</label>
<input type="text" id="fullname" style="display:block;width: 100%;height:28px;z-index:11;" name="fullname" value="<?php echo $db_fullname; ?>" readonly disabled spellcheck="false">
<label for="extra9" id="Label15" style="display:block;width:100%;line-height:21px;z-index:12;">Item deposited</label>
<input type="text" id="extra9" style="display:block;width: 100%;height:28px;z-index:13;" name="extra9" value="<?php echo $db_extra9; ?>" readonly disabled spellcheck="false">
<label for="extra13" id="Label19" style="display:block;width:100%;line-height:16px;z-index:14;">Purpose of deposit</label>
<select name="extra13" size="1" id="extra13" style="display:block;width: 100%;height:33px;z-index:15;" disabled>
<option value="Safe Keeping" <?php echo $selected_extra13[0]; ?>>Safe Keeping</option>
<option value="Shipping" <?php echo $selected_extra13[1]; ?>>Shipping</option>
</select>
<label for="extra11" id="Label17" style="display:block;width:100%;line-height:16px;z-index:16;">Container Value</label>
<input type="text" id="extra11" style="display:block;width: 100%;height:28px;z-index:17;" name="extra11" value="<?php echo $db_extra11; ?>" readonly disabled spellcheck="false">
<label for="extra12" id="Label18" style="display:block;width:100%;line-height:16px;z-index:18;">Date of Deposit</label>
<input type="text" id="extra12" style="display:block;width: 100%;height:28px;z-index:19;" name="extra12" value="<?php echo $db_extra12; ?>" readonly disabled spellcheck="false">
<label for="extra10" id="Label16" style="display:block;width:100%;line-height:16px;z-index:20;">Monthly Charges</label>
<input type="text" id="extra10" style="display:block;width: 100%;height:28px;z-index:21;" name="extra10" value="<?php echo $db_extra10; ?>" spellcheck="false">
</div>
<div class="col-2">
</div>
<div class="col-3">
<div id="wb_LayoutGrid4">
<div id="LayoutGrid4">
<div class="row">
<div class="col-1">
<div id="wb_Heading1" style="display:inline-block;width:100%;z-index:22;">
<h1 id="Heading1">Important Details</h1>
</div>
</div>
</div>
</div>
</div>
<label for="extra8" id="Label14" style="display:block;width:100%;line-height:16px;z-index:24;">Next of Kin</label>
<input type="text" id="extra8" style="display:block;width: 100%;height:28px;z-index:25;" name="extra8" value="<?php echo $db_extra8; ?>" spellcheck="false">
<label for="extra14" id="Label20" style="display:block;width:100%;line-height:16px;z-index:26;">Reference No</label>
<input type="text" id="extra14" style="display:block;width: 100%;height:28px;z-index:27;" name="extra14" value="<?php echo $db_extra14; ?>" readonly disabled spellcheck="false">
<label for="extra15" id="Label21" style="display:block;width:100%;line-height:16px;z-index:28;">Release code</label>
<input type="text" id="extra15" style="display:block;width: 100%;height:28px;z-index:29;" name="extra15" value="<?php echo $db_extra15; ?>" readonly disabled spellcheck="false">
</div>
<div class="col-4">
</div>
</div>
</div>
</div>

</body>
</html>