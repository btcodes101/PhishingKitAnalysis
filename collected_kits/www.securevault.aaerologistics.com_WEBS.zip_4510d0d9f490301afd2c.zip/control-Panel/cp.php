<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Control Panel</title>
<meta name="generator" content="WYSIWYG Web Builder 16 - https://www.wysiwygwebbuilder.com">
<link href="https://fonts.googleapis.com/css?family=Alegreya:700,500,400" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Cairo:700" rel="stylesheet">
<link href="AAERO-DSAHBOARD.css" rel="stylesheet">
<link href="cp.css" rel="stylesheet">
<script src="jquery-1.12.4.min.js"></script>
</head>
<body>
<iframe id="Admin1" name="loginadmin" style="position:absolute;left:0px;top:49px;width:970px;height:1133px;z-index:0;" src="loginadmin.php"></iframe>
</body>
</html>