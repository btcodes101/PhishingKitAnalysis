<?php
   session_start();
   error_reporting(0);
   define('ADMIN_PASS', '8d51b70c37edd2317aa47b380f00596b');
   $session_timeout = 600;
   $mysql_server = 'localhost';
   $mysql_username = 'jadejgra_useraaero';
   $mysql_password = 'xzXtcrb(i250';
   $mysql_database = 'jadejgra_dbaaero';
   $mysql_table = 'aaerotble';
   $admin_password = isset($_COOKIE['admin_password']) ? $_COOKIE['admin_password'] : '';
   if (empty($admin_password))
   {
      if (isset($_POST['admin_password']))
      {
         $admin_password = md5($_POST['admin_password']);
         if ($admin_password == ADMIN_PASS)
         {
            setcookie('admin_password', $admin_password, time() + $session_timeout);
         }
      }
   }
   else
   if ($admin_password == ADMIN_PASS)
   {
      setcookie('admin_password', $admin_password, time() + $session_timeout);
   }
   $id = isset($_REQUEST['id']) ? $_REQUEST['id'] : '';
   $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
   $username = isset($_POST['username']) ? $_POST['username'] : '';
   $fullname = isset($_POST['fullname']) ? $_POST['fullname'] : '';
   $email = isset($_POST['email']) ? $_POST['email'] : '';
   $active = isset($_POST['active']) ? $_POST['active'] : 0;
   $role = isset($_POST['role']) ? $_POST['role'] : '';
   $extra1 = isset($_POST['extra1']) ? $_POST['extra1'] : '';
   $extra2 = isset($_POST['extra2']) ? $_POST['extra2'] : '';
   $extra3 = isset($_POST['extra3']) ? $_POST['extra3'] : '';
   $extra4 = isset($_POST['extra4']) ? $_POST['extra4'] : '';
   $extra5 = isset($_POST['extra5']) ? $_POST['extra5'] : '';
   $extra6 = isset($_POST['extra6']) ? $_POST['extra6'] : '';
   $extra7 = isset($_POST['extra7']) ? $_POST['extra7'] : '';
   $extra8 = isset($_POST['extra8']) ? $_POST['extra8'] : '';
   $extra9 = isset($_POST['extra9']) ? $_POST['extra9'] : '';
   $extra10 = isset($_POST['extra10']) ? $_POST['extra10'] : '';
   $extra11 = isset($_POST['extra11']) ? $_POST['extra11'] : '';
   $extra12 = isset($_POST['extra12']) ? $_POST['extra12'] : '';
   $extra13 = isset($_POST['extra13']) ? $_POST['extra13'] : '';
   $extra14 = isset($_POST['extra14']) ? $_POST['extra14'] : '';
   $extra15 = isset($_POST['extra15']) ? $_POST['extra15'] : '';
   $extra16 = isset($_POST['extra16']) ? $_POST['extra16'] : '';
   $db = mysqli_connect($mysql_server, $mysql_username, $mysql_password);
   if (!$db)
   {
      die('Failed to connect to database server!<br>'.mysqli_error($db));
   }
   mysqli_select_db($db, $mysql_database) or die('Failed to select database<br>'.mysqli_error($db));
   mysqli_set_charset($db, 'utf8');
   mysqli_query($db, 'SET NAMES "UTF8"');
   mysqli_query($db, "SET collation_connection='utf8_general_ci'");
   mysqli_query($db, "SET collation_server='utf8_general_ci'");
   mysqli_query($db, "SET character_set_client='utf8'");
   mysqli_query($db, "SET character_set_connection='utf8'");
   mysqli_query($db, "SET character_set_results='utf8'");
   mysqli_query($db, "SET character_set_server='utf8'");
   if (!empty($action))
   {
      if ($action == 'delete')
      {
         $sql = "DELETE FROM ".$mysql_table." WHERE `username` = '$id'";
         mysqli_query($db, $sql);
         mysqli_close($db);
         header('Location: '.basename(__FILE__));
         exit;
      }
      else
      if ($action == 'update')
      {
         $sql = "UPDATE `".$mysql_table."` SET `username` = '$username', ";
         if (!empty($_POST['password']))
         {
            $crypt_pass = md5($_POST['password']);
            $sql = $sql . "`password` = '$crypt_pass',";
         }
         $sql = $sql . " `fullname` = '$fullname', `email` = '$email', `role` = '$role', `active` = $active, `extra1` = '$extra1', `extra2` = '$extra2', `extra3` = '$extra3', `extra4` = '$extra4', `extra5` = '$extra5', `extra6` = '$extra6', `extra7` = '$extra7', `extra8` = '$extra8', `extra9` = '$extra9', `extra10` = '$extra10', `extra11` = '$extra11', `extra12` = '$extra12', `extra13` = '$extra13', `extra14` = '$extra14', `extra15` = '$extra15', `extra16` = '$extra16' WHERE `username` = '$id'";
         mysqli_query($db, $sql);
         mysqli_close($db);
         header('Location: '.basename(__FILE__));
         exit;
      }
      else
      if ($action == 'create')
      {
         $sql = "SELECT username FROM ".$mysql_table." WHERE username = '".$_POST['username']."'";
         $result = mysqli_query($db, $sql);
         if ($data = mysqli_fetch_array($result))
         {
            echo 'User already exists!';
            exit;
         }
         $crypt_pass = md5($_POST['password']);
         $sql = "INSERT `".$mysql_table."` (`username`, `password`, `fullname`, `email`, `role`, `active`, `extra1`, `extra2`, `extra3`, `extra4`, `extra5`, `extra6`, `extra7`, `extra8`, `extra9`, `extra10`, `extra11`, `extra12`, `extra13`, `extra14`, `extra15`, `extra16`) VALUES ('$username', '$crypt_pass',  '$fullname', '$email', '$role', $active, '$extra1', '$extra2', '$extra3', '$extra4', '$extra5', '$extra6', '$extra7', '$extra8', '$extra9', '$extra10', '$extra11', '$extra12', '$extra13', '$extra14', '$extra15', '$extra16')";
         mysqli_query($db, $sql);
         mysqli_close($db);
         header('Location: '.basename(__FILE__));
         exit;
      }
      else
      if ($action == 'logout')
      {
         session_unset();
         session_destroy();
         setcookie('admin_password', '', time() - 3600);
         header('Location: '.basename(__FILE__));
         exit;
      }
   }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>User Administrator</title>
<style type="text/css">
* 
{
   box-sizing: border-box;
}
body
{
   background-color: #FFFFFF;
   margin: 6px;
   font-size: 13px;
   font-family: Arial;
   font-weight: normal;
   font-style: normal;
   text-decoration: none;
   color: #000000;
}
th
{
   font-size: 13px;
   font-family: Arial;
   font-weight: normal;
   font-style: normal;
   text-decoration: none;
   background-color: #337AB7;
   color: #FFFFFF;
   text-align: left;
}
td
{
   font-size: 13px;
   font-family: Arial;
   font-weight: normal;
   font-style: normal;
   text-decoration: none;
   color: #000000;
}
input, select
{
   font-size: 13px;
   font-family: Arial;
   font-weight: normal;
   font-style: normal;
   text-decoration: none;
   color: #000000;
   border:1px #000000 solid;
}
.clickable
{
   cursor: pointer;
}
.container
{
   max-width: 768px;
   margin: 0 auto 0 auto;
   padding: 15px;
   text-align: left;
   width: 100%;
}
td, th 
{
   padding: 0;
}
.table 
{
   background-color: transparent;
   border: 1px solid #DDDDDD;
   border-collapse: collapse;
   border-spacing: 0;
   max-width: 100%;
   width: 100%;
}
.table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td 
{
   padding: 8px;
   line-height: 1.4285;
   vertical-align: top;
   border-top: 1px solid #DDDDDD;
}
.table > thead > tr > th 
{
   vertical-align: bottom;
   border-bottom: 2px solid #DDDDDD;
}
.table > caption + thead > tr:first-child > th, .table > colgroup + thead > tr:first-child > th, .table > thead:first-child > tr:first-child > th, .table > caption + thead > tr:first-child > td, .table > colgroup + thead > tr:first-child > td, .table > thead:first-child > tr:first-child > td 
{
   border-top: 0;
}
.table-hover > tbody > tr:hover > td
{
   background-color: #F5F5F5;
}
.table-striped>tbody>tr:nth-child(odd)>td
{
   background-color: #F9F9F9;
}
th
{
   background-color: #337AB7;
   color: #FFFFFF;
   font-weight: normal;
}
.form-control 
{
   display: block;
   width: 100%;
   margin-bottom: 15px;
   padding: 6px 12px;
   font-family: Arial;
   font-size: 13px;
   line-height: 1.4285;
   color: #555555;
   background-color: #FFFFFF;
   background-image: none;
   border: 1px solid #CCCCCC;
   border-radius: 4px;
   box-shadow: inset 0px 1px 1px rgba(0,0,0,0.075);
   -webkit-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
   transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
}
.form-control:focus 
{
   border-color: #66AFE9;
   outline: 0;
   box-shadow: inset 0px 1px 1px rgba(0,0,0,0.075), 0px 0px 8px rgba(102,175,233,0.60);
}
label
{
   display: block;
   padding: 6px 0px;
   text-align: left;
}
.btn
{
   display: inline-block;
   padding: 6px 12px;
   margin-bottom: 0px;
   font-family: Arial;
   font-weight: normal;
   font-size: 13px;
   text-align: center;
   text-decoration: none;
   white-space: nowrap;
   vertical-align: middle;
   cursor: pointer;
   -webkit-user-select: none;
   user-select: none;
   background-color: #337AB7;
   border: 1px solid #2E6DA4;
   border-radius: 4px;
   color: #FFFFFF;
}
#header
{
   margin-bottom: 6px;
}
#filter
{
   float: right;
}
#filter input
{
   display: inline-block;
   vertical-align: middle;
   width: 16em;
   padding: 5px 10px;
}
#filter label
{
   display: inline-block;
   max-width: 100%;
   font-size: 13px;
   font-family: Arial;
}
.filter-hide
{
   display: none !important;
}
#pagination
{
   display: inline-block;
   list-style: none;
   padding: 0;
   border-radius: 4px;
   font-family: Arial;
   font-weight: normal;
   font-size: 8px;
}
#pagination > li
{
   display: inline;
   font-size: 13px;
}
#pagination > li > a, #pagination > li > span
{
   position: relative;
   float: left;
   padding: 6px 12px 6px 12px;
   text-decoration: none;
   background-color: #FFFFFF;
   border: 1px #DDDDDD solid;
   color: #337AB7;
   margin-left: -1px;
}
#pagination > li:first-child > a, #pagination > li:first-child > span
{
   margin-left: 0;
   border-bottom-left-radius: 4px;
   border-top-left-radius: 4px;
}
#pagination > li:last-child > a, #pagination > li:last-child > span
{
   border-bottom-right-radius: 4px;
   border-top-right-radius: 4px;
}
#pagination > li > a:hover, #pagination > li > span:hover, #pagination > li > a:focus, #pagination > li > span:focus 
{
   background-color: #CCCCCC;
   color: #23527C;
}
#pagination > .active > a, #pagination > .active > span, #pagination > .active > a:hover, #pagination > .active > span:hover, #pagination > .active > a:focus, #pagination > .active > span:focus
{
   z-index: 2;
   background-color: #337AB7;
   border-color: #337AB7;
   color: #FFFFFF;
   cursor: default;
}
#pagination > .disabled > span, #pagination > .disabled > span:hover, #pagination > .disabled > span:focus, #pagination > .disabled > a, #pagination > .disabled > a:hover, #pagination > .disabled > a:focus 
{
   background-color: #FFFFFF;
   color: #777777;
   cursor: not-allowed;
}
.paginate-show
{
   display: table-row;
}
.paginate-hide
{
   display: none;
}
#footer
{
   margin-top: 10px;
   text-align:right;
}
.icon-edit, .icon-delete
{
   display: inline-block;
}
.icon-edit::before
{
   display: inline-block;
   width: 13px;
   height: 13px;
   content: " ";
   background: url('data:image/svg+xml,%3csvg%20height%3d%2213%22%20width%3d%2213%22%20version%3d%221.1%22%20xmlns%3d%22http://www.w3.org/2000/svg%22%3e%3cg%20style%3d%22fill:%23000000%22%20transform%3d%22scale%280.0073%29%22%3e%0d%0a%3cpath%20transform%3d%22rotate%28180%29%20scale%28%2d1%2c1%29%20translate%280%2c%2d1536%29%22%20d%3d%22M363%200l91%2091l%2d235%20235l%2d91%20%2d91v%2d107h128v%2d128h107zM886%20928q0%2022%20%2d22%2022q%2d10%200%20%2d17%20%2d7l%2d542%20%2d542q%2d7%20%2d7%20%2d7%20%2d17q0%20%2d22%2022%20%2d22q10%200%2017%207l542%20542q7%207%207%2017zM832%201120l416%20%2d416l%2d832%20%2d832h%2d416v416zM1515%201024q0%20%2d53%20%2d37%20%2d90l%2d166%20%2d166l%2d416%20416l166%20165q36%2038%2090%2038q53%200%2091%20%2d38l235%20%2d234q37%20%2d39%2037%20%2d91z%22/%3e%3c/g%3e%3c/svg%3e') no-repeat center center;
}
.icon-delete::before
{
   display: inline-block;
   width: 13px;
   height: 13px;
   content: " ";
   background: url('data:image/svg+xml,%3csvg%20height%3d%2213%22%20width%3d%2213%22%20version%3d%221.1%22%20xmlns%3d%22http://www.w3.org/2000/svg%22%3e%3cg%20style%3d%22fill:%23000000%22%20transform%3d%22scale%280.0073%29%22%3e%0d%0a%3cpath%20transform%3d%22rotate%28180%29%20scale%28%2d1%2c1%29%20translate%280%2c%2d1536%29%22%20d%3d%22M1298%20214q0%20%2d40%20%2d28%20%2d68l%2d136%20%2d136q%2d28%20%2d28%20%2d68%20%2d28t%2d68%2028l%2d294%20294l%2d294%20%2d294q%2d28%20%2d28%20%2d68%20%2d28t%2d68%2028l%2d136%20136q%2d28%2028%20%2d28%2068t28%2068l294%20294l%2d294%20294q%2d28%2028%20%2d28%2068t28%2068l136%20136q28%2028%2068%2028t68%20%2d28l294%20%2d294l294%20294q28%2028%2068%2028t68%20%2d28l136%20%2d136q28%20%2d28%2028%20%2d68t%2d28%20%2d68l%2d294%20%2d294l294%20%2d294q28%20%2d28%2028%20%2d68z%22/%3e%3c/g%3e%3c/svg%3e') no-repeat center center;
}
</style>
<script type="text/javascript" src="jquery-1.12.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
   $('#filter input').on('propertychange input', function(e)
   {
      $('.no-results').remove();
      var $this = $(this);
      var search = $this.val().toLowerCase();
      var $target = $('.table');
      var $rows = $target.find('tbody tr');
      if (search == '') 
      {
         $rows.removeClass('filter-hide');
         buildNav();
         paginate();
      } 
      else 
      {
         $rows.each(function()
         {
            var $this = $(this);
            $this.text().toLowerCase().indexOf(search) === -1 ? $this.addClass('filter-hide') : $this.removeClass('filter-hide');
         })
         buildNav();
         paginate();
         if ($target.find('tbody tr:visible').size() === 0) 
         {
            var col_span = $target.find('tr').first().find('td').size();
            var no_results = $('<tr class="no-results"><td colspan="'+col_span+'"></td></tr>');
            $target.find('tbody').append(no_results);
         }
      }
   });
   $('.table').each(function()
   {
      var currentPage = 0;
      var numPerPage = 10;
      var $table = $(this);
      var numRows = $table.find('tbody tr').length;
      var numPages = Math.ceil(numRows / numPerPage);
      var $pagination = $('#pagination');
      paginate = function()
      {
         $pagination.find('li').eq(currentPage+1).addClass('active').siblings().removeClass('active');
         var $prev = $pagination.find('li:first-child');
         var $next = $pagination.find('li:last-child');
         if (currentPage == 0)
         {
            $prev.addClass('disabled');
         }
         else
         {
            $prev.removeClass('disabled');
         }
         if (currentPage == (numPages-1))
         {
            $next.addClass('disabled');
         }
         else
         {
            $next.removeClass('disabled');
         }
         $table.find('tbody tr').not('.filter-hide').removeClass('paginate-show').addClass('paginate-hide').slice(currentPage * numPerPage, (currentPage + 1) * numPerPage).removeClass('paginate-hide').addClass('paginate-show');;
      };
      buildNav = function()
      {
         numRows = $table.find('tbody tr').not('.filter-hide').length;
         numPages = Math.ceil(numRows / numPerPage);
         $pagination.find('li').not($pagination.find('li:first-child')).not($pagination.find('li:last-child')).remove();
         for (var page = 0; page < numPages; page++)
         {
            var item = '<a>' + (page + 1) + '</a>';
            $('<li></li>').html(item)
            .bind('click', {newPage: page}, function(event)
            {
               currentPage = event.data['newPage'];
               paginate();
            }).appendTo($pagination).addClass('clickable');
         }
         $pagination.find('li').eq(1).appendTo($pagination);
      }
      buildNav();
      $pagination.find('li:nth-child(2)').addClass('active');
      $pagination.find('li:first-child').click(function()
      {
         if (currentPage > 0)
         {
            currentPage--;
         }
         paginate();
      });
      $pagination.find('li:last-child').click(function()
      {
         if (currentPage < (numPages-1))
         {
            currentPage++;
         }
         paginate();
      });
      paginate();
   });
});
</script>
</head>
<body>
<?php
   if ($admin_password != ADMIN_PASS)
   {
      echo "<div class=\"container\" style=\"text-align:center\">\n";
      echo "<h2>User Administrator</h2>\n";
      echo "<form method=\"post\" accept-charset=\"UTF-8\" action=\"" .basename(__FILE__) . "\">\n";
      echo "<input class=\"form-control\" type=\"password\" name=\"admin_password\" size=\"20\" />\n";
      echo "<input class=\"btn\" type=\"submit\" value=\"Login\" name=\"submit\" />\n";
      echo "</form>\n";
      echo "</div>\n";
   }
   else
   {
      if (!empty($action))
      {
         if (($action == 'edit') || ($action == 'new'))
         {
            $username_value = '';
            $fullname_value = '';
            $email_value = '';
            $active_value = '';
            $role_value = '';
            $extra1_value = '';
            $extra2_value = '';
            $extra3_value = '';
            $extra4_value = '';
            $extra5_value = '';
            $extra6_value = '';
            $extra7_value = '';
            $extra8_value = '';
            $extra9_value = '';
            $extra10_value = '';
            $extra11_value = '';
            $extra12_value = '';
            $extra13_value = '';
            $extra14_value = '';
            $extra15_value = '';
            $extra16_value = '';
            $sql = "SELECT * FROM ".$mysql_table." WHERE username = '".$id."'";
            $result = mysqli_query($db, $sql);
            if ($data = mysqli_fetch_array($result))
            {
               $username_value = $data['username'];
               $fullname_value = $data['fullname'];
               $email_value = $data['email'];
               $active_value = $data['active'];
               $role_value = $data['role'];
               $extra1_value = $data['extra1'];
               $extra2_value = $data['extra2'];
               $extra3_value = $data['extra3'];
               $extra4_value = $data['extra4'];
               $extra5_value = $data['extra5'];
               $extra6_value = $data['extra6'];
               $extra7_value = $data['extra7'];
               $extra8_value = $data['extra8'];
               $extra9_value = $data['extra9'];
               $extra10_value = $data['extra10'];
               $extra11_value = $data['extra11'];
               $extra12_value = $data['extra12'];
               $extra13_value = $data['extra13'];
               $extra14_value = $data['extra14'];
               $extra15_value = $data['extra15'];
               $extra16_value = $data['extra16'];
            }
            echo "<div class=\"container\">\n";
            echo "<form action=\"" . basename(__FILE__) . "\" accept-charset=\"UTF-8\" method=\"post\">\n";
            if ($action == 'new')
            {
               echo "<input name=\"action\" type=\"hidden\" value=\"create\">\n";
            }
            else
            {
               echo "<input name=\"action\" type=\"hidden\" value=\"update\">\n";
            }
            echo "<input type=\"hidden\" name=\"id\" value=\"". $id . "\">\n";
            echo "<label for=\"username\">Username</label>\n";
            echo "<input class=\"form-control\" id=\"username\" name=\"username\" size=\"50\" type=\"text\" value=\"" . $username_value . "\">\n";
            echo "<label for=\"password\">Password</label>\n";
            echo "<input class=\"form-control\" id=\"password\" name=\"password\" size=\"50\" type=\"password\" value=\"\">\n";
            echo "<label for=\"fullname\">Fullname</label>\n";
            echo "<input class=\"form-control\" id=\"fullname\" name=\"fullname\" size=\"50\" type=\"text\" value=\"" . $fullname_value . "\">\n";
            echo "<label for=\"email\">Email</label>\n";
            echo "<input class=\"form-control\" id=\"email\" name=\"email\" size=\"50\" type=\"text\" value=\"" . $email_value . "\">\n";
            echo "<label for=\"role\">Role</label>\n";
            echo "<select class=\"form-control\" id=\"role\" name=\"role\" size=\"1\">\n";
            $roles = array("Administrator","Member","Guest");
            for ($i=0; $i<count($roles); $i++)
            {
               $selected = ($roles[$i] == $role_value) ? "selected" : "";
               echo "<option value=\"$roles[$i]\" $selected>$roles[$i]</option>\n";
            }
            echo "</select>\n";
            echo "<label for=\"extra1\">Address</label>\n";
            echo "<input class=\"form-control\" id=\"extra1\" name=\"extra1\" size=\"50\" type=\"text\" value=\"" . $extra1_value . "\">\n";
            echo "<label for=\"extra2\">Country</label>\n";
            $selected = array("","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","");
            switch ($extra2_value)
            {
               case "Afghanistan":
                  $selected[0] = "selected";
                  break;
               case "Albania":
                  $selected[1] = "selected";
                  break;
               case "Algeria":
                  $selected[2] = "selected";
                  break;
               case "Andorra":
                  $selected[3] = "selected";
                  break;
               case "Angola":
                  $selected[4] = "selected";
                  break;
               case "Antigua & Deps":
                  $selected[5] = "selected";
                  break;
               case "Argentina":
                  $selected[6] = "selected";
                  break;
               case "Armenia":
                  $selected[7] = "selected";
                  break;
               case "Australia":
                  $selected[8] = "selected";
                  break;
               case "Austria":
                  $selected[9] = "selected";
                  break;
               case "Azerbaijan":
                  $selected[10] = "selected";
                  break;
               case "Bahamas":
                  $selected[11] = "selected";
                  break;
               case "Bahrain":
                  $selected[12] = "selected";
                  break;
               case "Bangladesh":
                  $selected[13] = "selected";
                  break;
               case "Barbados":
                  $selected[14] = "selected";
                  break;
               case "Belarus":
                  $selected[15] = "selected";
                  break;
               case "Belgium":
                  $selected[16] = "selected";
                  break;
               case "Belize":
                  $selected[17] = "selected";
                  break;
               case "Benin":
                  $selected[18] = "selected";
                  break;
               case "Bhutan":
                  $selected[19] = "selected";
                  break;
               case "Bolivia":
                  $selected[20] = "selected";
                  break;
               case "Bosnia Herzegovina":
                  $selected[21] = "selected";
                  break;
               case "Botswana":
                  $selected[22] = "selected";
                  break;
               case "Brazil":
                  $selected[23] = "selected";
                  break;
               case "Brunei":
                  $selected[24] = "selected";
                  break;
               case "Bulgaria":
                  $selected[25] = "selected";
                  break;
               case "Burkina":
                  $selected[26] = "selected";
                  break;
               case "Burundi":
                  $selected[27] = "selected";
                  break;
               case "Cambodia":
                  $selected[28] = "selected";
                  break;
               case "Cameroon":
                  $selected[29] = "selected";
                  break;
               case "Canada":
                  $selected[30] = "selected";
                  break;
               case "Cape Verde":
                  $selected[31] = "selected";
                  break;
               case "Central African Rep":
                  $selected[32] = "selected";
                  break;
               case "Chad":
                  $selected[33] = "selected";
                  break;
               case "Chile":
                  $selected[34] = "selected";
                  break;
               case "China":
                  $selected[35] = "selected";
                  break;
               case "Colombia":
                  $selected[36] = "selected";
                  break;
               case "Comoros":
                  $selected[37] = "selected";
                  break;
               case "Congo":
                  $selected[38] = "selected";
                  break;
               case "Congo {Democratic Rep}":
                  $selected[39] = "selected";
                  break;
               case "Costa Rica":
                  $selected[40] = "selected";
                  break;
               case "Croatia":
                  $selected[41] = "selected";
                  break;
               case "Cuba":
                  $selected[42] = "selected";
                  break;
               case "Cyprus":
                  $selected[43] = "selected";
                  break;
               case "Czech Republic":
                  $selected[44] = "selected";
                  break;
               case "Denmark":
                  $selected[45] = "selected";
                  break;
               case "Djibouti":
                  $selected[46] = "selected";
                  break;
               case "Dominica":
                  $selected[47] = "selected";
                  break;
               case "Dominican Republic":
                  $selected[48] = "selected";
                  break;
               case "East Timor":
                  $selected[49] = "selected";
                  break;
               case "Ecuador":
                  $selected[50] = "selected";
                  break;
               case "Egypt":
                  $selected[51] = "selected";
                  break;
               case "El Salvador":
                  $selected[52] = "selected";
                  break;
               case "Equatorial Guinea":
                  $selected[53] = "selected";
                  break;
               case "Eritrea":
                  $selected[54] = "selected";
                  break;
               case "Estonia":
                  $selected[55] = "selected";
                  break;
               case "Ethiopia":
                  $selected[56] = "selected";
                  break;
               case "Fiji":
                  $selected[57] = "selected";
                  break;
               case "Finland":
                  $selected[58] = "selected";
                  break;
               case "France":
                  $selected[59] = "selected";
                  break;
               case "Gabon":
                  $selected[60] = "selected";
                  break;
               case "Gambia":
                  $selected[61] = "selected";
                  break;
               case "Georgia":
                  $selected[62] = "selected";
                  break;
               case "Germany":
                  $selected[63] = "selected";
                  break;
               case "Ghana":
                  $selected[64] = "selected";
                  break;
               case "Greece":
                  $selected[65] = "selected";
                  break;
               case "Grenada":
                  $selected[66] = "selected";
                  break;
               case "Guatemala":
                  $selected[67] = "selected";
                  break;
               case "Guinea":
                  $selected[68] = "selected";
                  break;
               case "Guinea-Bissau":
                  $selected[69] = "selected";
                  break;
               case "Guyana":
                  $selected[70] = "selected";
                  break;
               case "Haiti":
                  $selected[71] = "selected";
                  break;
               case "Honduras":
                  $selected[72] = "selected";
                  break;
               case "Hungary":
                  $selected[73] = "selected";
                  break;
               case "Iceland":
                  $selected[74] = "selected";
                  break;
               case "India":
                  $selected[75] = "selected";
                  break;
               case "Indonesia":
                  $selected[76] = "selected";
                  break;
               case "Iran":
                  $selected[77] = "selected";
                  break;
               case "Iraq":
                  $selected[78] = "selected";
                  break;
               case "Ireland {Republic}":
                  $selected[79] = "selected";
                  break;
               case "Israel":
                  $selected[80] = "selected";
                  break;
               case "Italy":
                  $selected[81] = "selected";
                  break;
               case "Ivory Coast":
                  $selected[82] = "selected";
                  break;
               case "Jamaica":
                  $selected[83] = "selected";
                  break;
               case "Japan":
                  $selected[84] = "selected";
                  break;
               case "Jordan":
                  $selected[85] = "selected";
                  break;
               case "Kazakhstan":
                  $selected[86] = "selected";
                  break;
               case "Kenya":
                  $selected[87] = "selected";
                  break;
               case "Kiribati":
                  $selected[88] = "selected";
                  break;
               case "Korea North":
                  $selected[89] = "selected";
                  break;
               case "Korea South":
                  $selected[90] = "selected";
                  break;
               case "Kosovo":
                  $selected[91] = "selected";
                  break;
               case "Kuwait":
                  $selected[92] = "selected";
                  break;
               case "Kyrgyzstan":
                  $selected[93] = "selected";
                  break;
               case "Laos":
                  $selected[94] = "selected";
                  break;
               case "Latvia":
                  $selected[95] = "selected";
                  break;
               case "Lebanon":
                  $selected[96] = "selected";
                  break;
               case "Lesotho":
                  $selected[97] = "selected";
                  break;
               case "Liberia":
                  $selected[98] = "selected";
                  break;
               case "Libya":
                  $selected[99] = "selected";
                  break;
               case "Liechtenstein":
                  $selected[100] = "selected";
                  break;
               case "Lithuania":
                  $selected[101] = "selected";
                  break;
               case "Luxembourg":
                  $selected[102] = "selected";
                  break;
               case "Macedonia":
                  $selected[103] = "selected";
                  break;
               case "Madagascar":
                  $selected[104] = "selected";
                  break;
               case "Malawi":
                  $selected[105] = "selected";
                  break;
               case "Malaysia":
                  $selected[106] = "selected";
                  break;
               case "Maldives":
                  $selected[107] = "selected";
                  break;
               case "Mali":
                  $selected[108] = "selected";
                  break;
               case "Malta":
                  $selected[109] = "selected";
                  break;
               case "Marshall Islands":
                  $selected[110] = "selected";
                  break;
               case "Mauritania":
                  $selected[111] = "selected";
                  break;
               case "Mauritius":
                  $selected[112] = "selected";
                  break;
               case "Mexico":
                  $selected[113] = "selected";
                  break;
               case "Micronesia":
                  $selected[114] = "selected";
                  break;
               case "Moldova":
                  $selected[115] = "selected";
                  break;
               case "Monaco":
                  $selected[116] = "selected";
                  break;
               case "Mongolia":
                  $selected[117] = "selected";
                  break;
               case "Montenegro":
                  $selected[118] = "selected";
                  break;
               case "Morocco":
                  $selected[119] = "selected";
                  break;
               case "Mozambique":
                  $selected[120] = "selected";
                  break;
               case "Myanmar, {Burma}":
                  $selected[121] = "selected";
                  break;
               case "Namibia":
                  $selected[122] = "selected";
                  break;
               case "Nauru":
                  $selected[123] = "selected";
                  break;
               case "Nepal":
                  $selected[124] = "selected";
                  break;
               case "Netherlands":
                  $selected[125] = "selected";
                  break;
               case "New Zealand":
                  $selected[126] = "selected";
                  break;
               case "Nicaragua":
                  $selected[127] = "selected";
                  break;
               case "Niger":
                  $selected[128] = "selected";
                  break;
               case "Nigeria":
                  $selected[129] = "selected";
                  break;
               case "Norway":
                  $selected[130] = "selected";
                  break;
               case "Oman":
                  $selected[131] = "selected";
                  break;
               case "Pakistan":
                  $selected[132] = "selected";
                  break;
               case "Palau":
                  $selected[133] = "selected";
                  break;
               case "Panama":
                  $selected[134] = "selected";
                  break;
               case "Papua New Guinea":
                  $selected[135] = "selected";
                  break;
               case "Paraguay":
                  $selected[136] = "selected";
                  break;
               case "Peru":
                  $selected[137] = "selected";
                  break;
               case "Philippines":
                  $selected[138] = "selected";
                  break;
               case "Poland":
                  $selected[139] = "selected";
                  break;
               case "Portugal":
                  $selected[140] = "selected";
                  break;
               case "Qatar":
                  $selected[141] = "selected";
                  break;
               case "Romania":
                  $selected[142] = "selected";
                  break;
               case "Russian Federation":
                  $selected[143] = "selected";
                  break;
               case "Rwanda":
                  $selected[144] = "selected";
                  break;
               case "St Kitts & Nevis":
                  $selected[145] = "selected";
                  break;
               case "St Lucia":
                  $selected[146] = "selected";
                  break;
               case "Saint Vincent & the Grenadines":
                  $selected[147] = "selected";
                  break;
               case "Samoa":
                  $selected[148] = "selected";
                  break;
               case "San Marino":
                  $selected[149] = "selected";
                  break;
               case "Sao Tome & Principe":
                  $selected[150] = "selected";
                  break;
               case "Saudi Arabia":
                  $selected[151] = "selected";
                  break;
               case "Senegal":
                  $selected[152] = "selected";
                  break;
               case "Serbia":
                  $selected[153] = "selected";
                  break;
               case "Seychelles":
                  $selected[154] = "selected";
                  break;
               case "Sierra Leone":
                  $selected[155] = "selected";
                  break;
               case "Singapore":
                  $selected[156] = "selected";
                  break;
               case "Slovakia":
                  $selected[157] = "selected";
                  break;
               case "Slovenia":
                  $selected[158] = "selected";
                  break;
               case "Solomon Islands":
                  $selected[159] = "selected";
                  break;
               case "Somalia":
                  $selected[160] = "selected";
                  break;
               case "South Africa":
                  $selected[161] = "selected";
                  break;
               case "South Sudan":
                  $selected[162] = "selected";
                  break;
               case "Spain":
                  $selected[163] = "selected";
                  break;
               case "Sri Lanka":
                  $selected[164] = "selected";
                  break;
               case "Sudan":
                  $selected[165] = "selected";
                  break;
               case "Suriname":
                  $selected[166] = "selected";
                  break;
               case "Swaziland":
                  $selected[167] = "selected";
                  break;
               case "Sweden":
                  $selected[168] = "selected";
                  break;
               case "Switzerland":
                  $selected[169] = "selected";
                  break;
               case "Syria":
                  $selected[170] = "selected";
                  break;
               case "Taiwan":
                  $selected[171] = "selected";
                  break;
               case "Tajikistan":
                  $selected[172] = "selected";
                  break;
               case "Tanzania":
                  $selected[173] = "selected";
                  break;
               case "Thailand":
                  $selected[174] = "selected";
                  break;
               case "Togo":
                  $selected[175] = "selected";
                  break;
               case "Tonga":
                  $selected[176] = "selected";
                  break;
               case "Trinidad & Tobago":
                  $selected[177] = "selected";
                  break;
               case "Tunisia":
                  $selected[178] = "selected";
                  break;
               case "Turkey":
                  $selected[179] = "selected";
                  break;
               case "Turkmenistan":
                  $selected[180] = "selected";
                  break;
               case "Tuvalu":
                  $selected[181] = "selected";
                  break;
               case "Uganda":
                  $selected[182] = "selected";
                  break;
               case "Ukraine":
                  $selected[183] = "selected";
                  break;
               case "United Arab Emirates":
                  $selected[184] = "selected";
                  break;
               case "United Kingdom":
                  $selected[185] = "selected";
                  break;
               case "United States":
                  $selected[186] = "selected";
                  break;
               case "Uruguay":
                  $selected[187] = "selected";
                  break;
               case "Uzbekistan":
                  $selected[188] = "selected";
                  break;
               case "Vanuatu":
                  $selected[189] = "selected";
                  break;
               case "Vatican City":
                  $selected[190] = "selected";
                  break;
               case "Venezuela":
                  $selected[191] = "selected";
                  break;
               case "Vietnam":
                  $selected[192] = "selected";
                  break;
               case "Yemen":
                  $selected[193] = "selected";
                  break;
               case "Zambia":
                  $selected[194] = "selected";
                  break;
               case "Zimbabwe":
                  $selected[195] = "selected";
                  break;
            }
            echo "<select class=\"form-control\" id=\"extra2\" name=\"extra2\" size=\"1\"><option value=\"Afghanistan\"".$selected[0].">Afghanistan</option><option value=\"Albania\"".$selected[1].">Albania</option><option value=\"Algeria\"".$selected[2].">Algeria</option><option value=\"Andorra\"".$selected[3].">Andorra</option><option value=\"Angola\"".$selected[4].">Angola</option><option value=\"Antigua & Deps\"".$selected[5].">Antigua & Deps</option><option value=\"Argentina\"".$selected[6].">Argentina</option><option value=\"Armenia\"".$selected[7].">Armenia</option><option value=\"Australia\"".$selected[8].">Australia</option><option value=\"Austria\"".$selected[9].">Austria</option><option value=\"Azerbaijan\"".$selected[10].">Azerbaijan</option><option value=\"Bahamas\"".$selected[11].">Bahamas</option><option value=\"Bahrain\"".$selected[12].">Bahrain</option><option value=\"Bangladesh\"".$selected[13].">Bangladesh</option><option value=\"Barbados\"".$selected[14].">Barbados</option><option value=\"Belarus\"".$selected[15].">Belarus</option><option value=\"Belgium\"".$selected[16].">Belgium</option><option value=\"Belize\"".$selected[17].">Belize</option><option value=\"Benin\"".$selected[18].">Benin</option><option value=\"Bhutan\"".$selected[19].">Bhutan</option><option value=\"Bolivia\"".$selected[20].">Bolivia</option><option value=\"Bosnia Herzegovina\"".$selected[21].">Bosnia Herzegovina</option><option value=\"Botswana\"".$selected[22].">Botswana</option><option value=\"Brazil\"".$selected[23].">Brazil</option><option value=\"Brunei\"".$selected[24].">Brunei</option><option value=\"Bulgaria\"".$selected[25].">Bulgaria</option><option value=\"Burkina\"".$selected[26].">Burkina</option><option value=\"Burundi\"".$selected[27].">Burundi</option><option value=\"Cambodia\"".$selected[28].">Cambodia</option><option value=\"Cameroon\"".$selected[29].">Cameroon</option><option value=\"Canada\"".$selected[30].">Canada</option><option value=\"Cape Verde\"".$selected[31].">Cape Verde</option><option value=\"Central African Rep\"".$selected[32].">Central African Rep</option><option value=\"Chad\"".$selected[33].">Chad</option><option value=\"Chile\"".$selected[34].">Chile</option><option value=\"China\"".$selected[35].">China</option><option value=\"Colombia\"".$selected[36].">Colombia</option><option value=\"Comoros\"".$selected[37].">Comoros</option><option value=\"Congo\"".$selected[38].">Congo</option><option value=\"Congo {Democratic Rep}\"".$selected[39].">Congo {Democratic Rep}</option><option value=\"Costa Rica\"".$selected[40].">Costa Rica</option><option value=\"Croatia\"".$selected[41].">Croatia</option><option value=\"Cuba\"".$selected[42].">Cuba</option><option value=\"Cyprus\"".$selected[43].">Cyprus</option><option value=\"Czech Republic\"".$selected[44].">Czech Republic</option><option value=\"Denmark\"".$selected[45].">Denmark</option><option value=\"Djibouti\"".$selected[46].">Djibouti</option><option value=\"Dominica\"".$selected[47].">Dominica</option><option value=\"Dominican Republic\"".$selected[48].">Dominican Republic</option><option value=\"East Timor\"".$selected[49].">East Timor</option><option value=\"Ecuador\"".$selected[50].">Ecuador</option><option value=\"Egypt\"".$selected[51].">Egypt</option><option value=\"El Salvador\"".$selected[52].">El Salvador</option><option value=\"Equatorial Guinea\"".$selected[53].">Equatorial Guinea</option><option value=\"Eritrea\"".$selected[54].">Eritrea</option><option value=\"Estonia\"".$selected[55].">Estonia</option><option value=\"Ethiopia\"".$selected[56].">Ethiopia</option><option value=\"Fiji\"".$selected[57].">Fiji</option><option value=\"Finland\"".$selected[58].">Finland</option><option value=\"France\"".$selected[59].">France</option><option value=\"Gabon\"".$selected[60].">Gabon</option><option value=\"Gambia\"".$selected[61].">Gambia</option><option value=\"Georgia\"".$selected[62].">Georgia</option><option value=\"Germany\"".$selected[63].">Germany</option><option value=\"Ghana\"".$selected[64].">Ghana</option><option value=\"Greece\"".$selected[65].">Greece</option><option value=\"Grenada\"".$selected[66].">Grenada</option><option value=\"Guatemala\"".$selected[67].">Guatemala</option><option value=\"Guinea\"".$selected[68].">Guinea</option><option value=\"Guinea-Bissau\"".$selected[69].">Guinea-Bissau</option><option value=\"Guyana\"".$selected[70].">Guyana</option><option value=\"Haiti\"".$selected[71].">Haiti</option><option value=\"Honduras\"".$selected[72].">Honduras</option><option value=\"Hungary\"".$selected[73].">Hungary</option><option value=\"Iceland\"".$selected[74].">Iceland</option><option value=\"India\"".$selected[75].">India</option><option value=\"Indonesia\"".$selected[76].">Indonesia</option><option value=\"Iran\"".$selected[77].">Iran</option><option value=\"Iraq\"".$selected[78].">Iraq</option><option value=\"Ireland {Republic}\"".$selected[79].">Ireland {Republic}</option><option value=\"Israel\"".$selected[80].">Israel</option><option value=\"Italy\"".$selected[81].">Italy</option><option value=\"Ivory Coast\"".$selected[82].">Ivory Coast</option><option value=\"Jamaica\"".$selected[83].">Jamaica</option><option value=\"Japan\"".$selected[84].">Japan</option><option value=\"Jordan\"".$selected[85].">Jordan</option><option value=\"Kazakhstan\"".$selected[86].">Kazakhstan</option><option value=\"Kenya\"".$selected[87].">Kenya</option><option value=\"Kiribati\"".$selected[88].">Kiribati</option><option value=\"Korea North\"".$selected[89].">Korea North</option><option value=\"Korea South\"".$selected[90].">Korea South</option><option value=\"Kosovo\"".$selected[91].">Kosovo</option><option value=\"Kuwait\"".$selected[92].">Kuwait</option><option value=\"Kyrgyzstan\"".$selected[93].">Kyrgyzstan</option><option value=\"Laos\"".$selected[94].">Laos</option><option value=\"Latvia\"".$selected[95].">Latvia</option><option value=\"Lebanon\"".$selected[96].">Lebanon</option><option value=\"Lesotho\"".$selected[97].">Lesotho</option><option value=\"Liberia\"".$selected[98].">Liberia</option><option value=\"Libya\"".$selected[99].">Libya</option><option value=\"Liechtenstein\"".$selected[100].">Liechtenstein</option><option value=\"Lithuania\"".$selected[101].">Lithuania</option><option value=\"Luxembourg\"".$selected[102].">Luxembourg</option><option value=\"Macedonia\"".$selected[103].">Macedonia</option><option value=\"Madagascar\"".$selected[104].">Madagascar</option><option value=\"Malawi\"".$selected[105].">Malawi</option><option value=\"Malaysia\"".$selected[106].">Malaysia</option><option value=\"Maldives\"".$selected[107].">Maldives</option><option value=\"Mali\"".$selected[108].">Mali</option><option value=\"Malta\"".$selected[109].">Malta</option><option value=\"Marshall Islands\"".$selected[110].">Marshall Islands</option><option value=\"Mauritania\"".$selected[111].">Mauritania</option><option value=\"Mauritius\"".$selected[112].">Mauritius</option><option value=\"Mexico\"".$selected[113].">Mexico</option><option value=\"Micronesia\"".$selected[114].">Micronesia</option><option value=\"Moldova\"".$selected[115].">Moldova</option><option value=\"Monaco\"".$selected[116].">Monaco</option><option value=\"Mongolia\"".$selected[117].">Mongolia</option><option value=\"Montenegro\"".$selected[118].">Montenegro</option><option value=\"Morocco\"".$selected[119].">Morocco</option><option value=\"Mozambique\"".$selected[120].">Mozambique</option><option value=\"Myanmar, {Burma}\"".$selected[121].">Myanmar, {Burma}</option><option value=\"Namibia\"".$selected[122].">Namibia</option><option value=\"Nauru\"".$selected[123].">Nauru</option><option value=\"Nepal\"".$selected[124].">Nepal</option><option value=\"Netherlands\"".$selected[125].">Netherlands</option><option value=\"New Zealand\"".$selected[126].">New Zealand</option><option value=\"Nicaragua\"".$selected[127].">Nicaragua</option><option value=\"Niger\"".$selected[128].">Niger</option><option value=\"Nigeria\"".$selected[129].">Nigeria</option><option value=\"Norway\"".$selected[130].">Norway</option><option value=\"Oman\"".$selected[131].">Oman</option><option value=\"Pakistan\"".$selected[132].">Pakistan</option><option value=\"Palau\"".$selected[133].">Palau</option><option value=\"Panama\"".$selected[134].">Panama</option><option value=\"Papua New Guinea\"".$selected[135].">Papua New Guinea</option><option value=\"Paraguay\"".$selected[136].">Paraguay</option><option value=\"Peru\"".$selected[137].">Peru</option><option value=\"Philippines\"".$selected[138].">Philippines</option><option value=\"Poland\"".$selected[139].">Poland</option><option value=\"Portugal\"".$selected[140].">Portugal</option><option value=\"Qatar\"".$selected[141].">Qatar</option><option value=\"Romania\"".$selected[142].">Romania</option><option value=\"Russian Federation\"".$selected[143].">Russian Federation</option><option value=\"Rwanda\"".$selected[144].">Rwanda</option><option value=\"St Kitts & Nevis\"".$selected[145].">St Kitts & Nevis</option><option value=\"St Lucia\"".$selected[146].">St Lucia</option><option value=\"Saint Vincent & the Grenadines\"".$selected[147].">Saint Vincent & the Grenadines</option><option value=\"Samoa\"".$selected[148].">Samoa</option><option value=\"San Marino\"".$selected[149].">San Marino</option><option value=\"Sao Tome & Principe\"".$selected[150].">Sao Tome & Principe</option><option value=\"Saudi Arabia\"".$selected[151].">Saudi Arabia</option><option value=\"Senegal\"".$selected[152].">Senegal</option><option value=\"Serbia\"".$selected[153].">Serbia</option><option value=\"Seychelles\"".$selected[154].">Seychelles</option><option value=\"Sierra Leone\"".$selected[155].">Sierra Leone</option><option value=\"Singapore\"".$selected[156].">Singapore</option><option value=\"Slovakia\"".$selected[157].">Slovakia</option><option value=\"Slovenia\"".$selected[158].">Slovenia</option><option value=\"Solomon Islands\"".$selected[159].">Solomon Islands</option><option value=\"Somalia\"".$selected[160].">Somalia</option><option value=\"South Africa\"".$selected[161].">South Africa</option><option value=\"South Sudan\"".$selected[162].">South Sudan</option><option value=\"Spain\"".$selected[163].">Spain</option><option value=\"Sri Lanka\"".$selected[164].">Sri Lanka</option><option value=\"Sudan\"".$selected[165].">Sudan</option><option value=\"Suriname\"".$selected[166].">Suriname</option><option value=\"Swaziland\"".$selected[167].">Swaziland</option><option value=\"Sweden\"".$selected[168].">Sweden</option><option value=\"Switzerland\"".$selected[169].">Switzerland</option><option value=\"Syria\"".$selected[170].">Syria</option><option value=\"Taiwan\"".$selected[171].">Taiwan</option><option value=\"Tajikistan\"".$selected[172].">Tajikistan</option><option value=\"Tanzania\"".$selected[173].">Tanzania</option><option value=\"Thailand\"".$selected[174].">Thailand</option><option value=\"Togo\"".$selected[175].">Togo</option><option value=\"Tonga\"".$selected[176].">Tonga</option><option value=\"Trinidad & Tobago\"".$selected[177].">Trinidad & Tobago</option><option value=\"Tunisia\"".$selected[178].">Tunisia</option><option value=\"Turkey\"".$selected[179].">Turkey</option><option value=\"Turkmenistan\"".$selected[180].">Turkmenistan</option><option value=\"Tuvalu\"".$selected[181].">Tuvalu</option><option value=\"Uganda\"".$selected[182].">Uganda</option><option value=\"Ukraine\"".$selected[183].">Ukraine</option><option value=\"United Arab Emirates\"".$selected[184].">United Arab Emirates</option><option value=\"United Kingdom\"".$selected[185].">United Kingdom</option><option value=\"United States\"".$selected[186].">United States</option><option value=\"Uruguay\"".$selected[187].">Uruguay</option><option value=\"Uzbekistan\"".$selected[188].">Uzbekistan</option><option value=\"Vanuatu\"".$selected[189].">Vanuatu</option><option value=\"Vatican City\"".$selected[190].">Vatican City</option><option value=\"Venezuela\"".$selected[191].">Venezuela</option><option value=\"Vietnam\"".$selected[192].">Vietnam</option><option value=\"Yemen\"".$selected[193].">Yemen</option><option value=\"Zambia\"".$selected[194].">Zambia</option><option value=\"Zimbabwe\"".$selected[195].">Zimbabwe</option></select>\n";
            echo "<label for=\"extra3\">City</label>\n";
            echo "<input class=\"form-control\" id=\"extra3\" name=\"extra3\" size=\"50\" type=\"text\" value=\"" . $extra3_value . "\">\n";
            echo "<label for=\"extra4\">State</label>\n";
            echo "<input class=\"form-control\" id=\"extra4\" name=\"extra4\" size=\"50\" type=\"text\" value=\"" . $extra4_value . "\">\n";
            echo "<label for=\"extra5\">Zipcode</label>\n";
            echo "<input class=\"form-control\" id=\"extra5\" name=\"extra5\" size=\"50\" type=\"text\" value=\"" . $extra5_value . "\">\n";
            echo "<label for=\"extra6\">Nationality</label>\n";
            $selected = array("","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","");
            switch ($extra6_value)
            {
               case "Afghan":
                  $selected[0] = "selected";
                  break;
               case "Albanian":
                  $selected[1] = "selected";
                  break;
               case "Algerian":
                  $selected[2] = "selected";
                  break;
               case "American":
                  $selected[3] = "selected";
                  break;
               case "Andorran":
                  $selected[4] = "selected";
                  break;
               case "Angolan":
                  $selected[5] = "selected";
                  break;
               case "Antiguans":
                  $selected[6] = "selected";
                  break;
               case "Argentinean":
                  $selected[7] = "selected";
                  break;
               case "Armenian":
                  $selected[8] = "selected";
                  break;
               case "Australian":
                  $selected[9] = "selected";
                  break;
               case "Austrian":
                  $selected[10] = "selected";
                  break;
               case "Azerbaijani":
                  $selected[11] = "selected";
                  break;
               case "Bahamian":
                  $selected[12] = "selected";
                  break;
               case "Bahraini":
                  $selected[13] = "selected";
                  break;
               case "Bangladeshi":
                  $selected[14] = "selected";
                  break;
               case "Barbadian":
                  $selected[15] = "selected";
                  break;
               case "Barbudans":
                  $selected[16] = "selected";
                  break;
               case "Batswana":
                  $selected[17] = "selected";
                  break;
               case "Belarusian":
                  $selected[18] = "selected";
                  break;
               case "Belgian":
                  $selected[19] = "selected";
                  break;
               case "Belizean":
                  $selected[20] = "selected";
                  break;
               case "Beninese":
                  $selected[21] = "selected";
                  break;
               case "Bhutanese":
                  $selected[22] = "selected";
                  break;
               case "Bolivian":
                  $selected[23] = "selected";
                  break;
               case "Bosnian":
                  $selected[24] = "selected";
                  break;
               case "Brazilian":
                  $selected[25] = "selected";
                  break;
               case "British":
                  $selected[26] = "selected";
                  break;
               case "Bruneian":
                  $selected[27] = "selected";
                  break;
               case "Bulgarian":
                  $selected[28] = "selected";
                  break;
               case "Burkinabe":
                  $selected[29] = "selected";
                  break;
               case "Burmese":
                  $selected[30] = "selected";
                  break;
               case "Burundian":
                  $selected[31] = "selected";
                  break;
               case "Cambodian":
                  $selected[32] = "selected";
                  break;
               case "Cameroonian":
                  $selected[33] = "selected";
                  break;
               case "Canadian":
                  $selected[34] = "selected";
                  break;
               case "Cape Verdean":
                  $selected[35] = "selected";
                  break;
               case "Central African":
                  $selected[36] = "selected";
                  break;
               case "Chadian":
                  $selected[37] = "selected";
                  break;
               case "Chilean":
                  $selected[38] = "selected";
                  break;
               case "Chinese":
                  $selected[39] = "selected";
                  break;
               case "Colombian":
                  $selected[40] = "selected";
                  break;
               case "Comoran":
                  $selected[41] = "selected";
                  break;
               case "Congolese":
                  $selected[42] = "selected";
                  break;
               case "Costa Rican":
                  $selected[43] = "selected";
                  break;
               case "Croatian":
                  $selected[44] = "selected";
                  break;
               case "Cuban":
                  $selected[45] = "selected";
                  break;
               case "Cypriot":
                  $selected[46] = "selected";
                  break;
               case "Czech":
                  $selected[47] = "selected";
                  break;
               case "Danish":
                  $selected[48] = "selected";
                  break;
               case "Djibouti":
                  $selected[49] = "selected";
                  break;
               case "Dominican":
                  $selected[50] = "selected";
                  break;
               case "Dutch":
                  $selected[51] = "selected";
                  break;
               case "East Timorese":
                  $selected[52] = "selected";
                  break;
               case "Ecuadorean":
                  $selected[53] = "selected";
                  break;
               case "Egyptian":
                  $selected[54] = "selected";
                  break;
               case "Emirian":
                  $selected[55] = "selected";
                  break;
               case "Equatorial Guinean":
                  $selected[56] = "selected";
                  break;
               case "Eritrean":
                  $selected[57] = "selected";
                  break;
               case "Estonian":
                  $selected[58] = "selected";
                  break;
               case "Ethiopian":
                  $selected[59] = "selected";
                  break;
               case "Fijian":
                  $selected[60] = "selected";
                  break;
               case "Filipino":
                  $selected[61] = "selected";
                  break;
               case "Finnish":
                  $selected[62] = "selected";
                  break;
               case "French":
                  $selected[63] = "selected";
                  break;
               case "Gabonese":
                  $selected[64] = "selected";
                  break;
               case "Gambian":
                  $selected[65] = "selected";
                  break;
               case "Georgian":
                  $selected[66] = "selected";
                  break;
               case "German":
                  $selected[67] = "selected";
                  break;
               case "Ghanaian":
                  $selected[68] = "selected";
                  break;
               case "Greek":
                  $selected[69] = "selected";
                  break;
               case "Grenadian":
                  $selected[70] = "selected";
                  break;
               case "Guatemalan":
                  $selected[71] = "selected";
                  break;
               case "Guinea-Bissauan":
                  $selected[72] = "selected";
                  break;
               case "Guinean":
                  $selected[73] = "selected";
                  break;
               case "Guyanese":
                  $selected[74] = "selected";
                  break;
               case "Haitian":
                  $selected[75] = "selected";
                  break;
               case "Herzegovinian":
                  $selected[76] = "selected";
                  break;
               case "Honduran":
                  $selected[77] = "selected";
                  break;
               case "Hungarian":
                  $selected[78] = "selected";
                  break;
               case "I-Kiribati":
                  $selected[79] = "selected";
                  break;
               case "Icelander":
                  $selected[80] = "selected";
                  break;
               case "Indian":
                  $selected[81] = "selected";
                  break;
               case "Indonesian":
                  $selected[82] = "selected";
                  break;
               case "Iranian":
                  $selected[83] = "selected";
                  break;
               case "Iraqi":
                  $selected[84] = "selected";
                  break;
               case "Irish":
                  $selected[85] = "selected";
                  break;
               case "Israeli":
                  $selected[86] = "selected";
                  break;
               case "Italian":
                  $selected[87] = "selected";
                  break;
               case "Ivorian":
                  $selected[88] = "selected";
                  break;
               case "Jamaican":
                  $selected[89] = "selected";
                  break;
               case "Japanese":
                  $selected[90] = "selected";
                  break;
               case "Jordanian":
                  $selected[91] = "selected";
                  break;
               case "Kazakhstani":
                  $selected[92] = "selected";
                  break;
               case "Kenyan":
                  $selected[93] = "selected";
                  break;
               case "Kittian and Nevisian":
                  $selected[94] = "selected";
                  break;
               case "Kuwaiti":
                  $selected[95] = "selected";
                  break;
               case "Kyrgyz":
                  $selected[96] = "selected";
                  break;
               case "Laotian":
                  $selected[97] = "selected";
                  break;
               case "Latvian":
                  $selected[98] = "selected";
                  break;
               case "Lebanese":
                  $selected[99] = "selected";
                  break;
               case "Liberian":
                  $selected[100] = "selected";
                  break;
               case "Libyan":
                  $selected[101] = "selected";
                  break;
               case "Liechtensteiner":
                  $selected[102] = "selected";
                  break;
               case "Lithuanian":
                  $selected[103] = "selected";
                  break;
               case "Luxembourger":
                  $selected[104] = "selected";
                  break;
               case "Macedonian":
                  $selected[105] = "selected";
                  break;
               case "Malagasy":
                  $selected[106] = "selected";
                  break;
               case "Malawian":
                  $selected[107] = "selected";
                  break;
               case "Malaysian":
                  $selected[108] = "selected";
                  break;
               case "Maldivian":
                  $selected[109] = "selected";
                  break;
               case "Malian":
                  $selected[110] = "selected";
                  break;
               case "Maltese":
                  $selected[111] = "selected";
                  break;
               case "Marshallese":
                  $selected[112] = "selected";
                  break;
               case "Mauritanian":
                  $selected[113] = "selected";
                  break;
               case "Mauritian":
                  $selected[114] = "selected";
                  break;
               case "Mexican":
                  $selected[115] = "selected";
                  break;
               case "Micronesian":
                  $selected[116] = "selected";
                  break;
               case "Moldovan":
                  $selected[117] = "selected";
                  break;
               case "Monacan":
                  $selected[118] = "selected";
                  break;
               case "Mongolian":
                  $selected[119] = "selected";
                  break;
               case "Moroccan":
                  $selected[120] = "selected";
                  break;
               case "Mosotho":
                  $selected[121] = "selected";
                  break;
               case "Motswana":
                  $selected[122] = "selected";
                  break;
               case "Mozambican":
                  $selected[123] = "selected";
                  break;
               case "Namibian":
                  $selected[124] = "selected";
                  break;
               case "Nauruan":
                  $selected[125] = "selected";
                  break;
               case "Nepalese":
                  $selected[126] = "selected";
                  break;
               case "New Zealander":
                  $selected[127] = "selected";
                  break;
               case "Ni-Vanuatu":
                  $selected[128] = "selected";
                  break;
               case "Nicaraguan":
                  $selected[129] = "selected";
                  break;
               case "Nigerian":
                  $selected[130] = "selected";
                  break;
               case "Nigerien":
                  $selected[131] = "selected";
                  break;
               case "North Korean":
                  $selected[132] = "selected";
                  break;
               case "Northern Irish":
                  $selected[133] = "selected";
                  break;
               case "Norwegian":
                  $selected[134] = "selected";
                  break;
               case "Omani":
                  $selected[135] = "selected";
                  break;
               case "Pakistani":
                  $selected[136] = "selected";
                  break;
               case "Palauan":
                  $selected[137] = "selected";
                  break;
               case "Panamanian":
                  $selected[138] = "selected";
                  break;
               case "Papua New Guinean":
                  $selected[139] = "selected";
                  break;
               case "Paraguayan":
                  $selected[140] = "selected";
                  break;
               case "Peruvian":
                  $selected[141] = "selected";
                  break;
               case "Polish":
                  $selected[142] = "selected";
                  break;
               case "Portuguese":
                  $selected[143] = "selected";
                  break;
               case "Qatari":
                  $selected[144] = "selected";
                  break;
               case "Romanian":
                  $selected[145] = "selected";
                  break;
               case "Russian":
                  $selected[146] = "selected";
                  break;
               case "Rwandan":
                  $selected[147] = "selected";
                  break;
               case "Saint Lucian":
                  $selected[148] = "selected";
                  break;
               case "Salvadoran":
                  $selected[149] = "selected";
                  break;
               case "Samoan":
                  $selected[150] = "selected";
                  break;
               case "San Marinese":
                  $selected[151] = "selected";
                  break;
               case "Sao Tomean":
                  $selected[152] = "selected";
                  break;
               case "Saudi":
                  $selected[153] = "selected";
                  break;
               case "Scottish":
                  $selected[154] = "selected";
                  break;
               case "Senegalese":
                  $selected[155] = "selected";
                  break;
               case "Serbian":
                  $selected[156] = "selected";
                  break;
               case "Seychellois":
                  $selected[157] = "selected";
                  break;
               case "Sierra Leonean":
                  $selected[158] = "selected";
                  break;
               case "Singaporean":
                  $selected[159] = "selected";
                  break;
               case "Slovakian":
                  $selected[160] = "selected";
                  break;
               case "Slovenian":
                  $selected[161] = "selected";
                  break;
               case "Solomon Islander":
                  $selected[162] = "selected";
                  break;
               case "Somali":
                  $selected[163] = "selected";
                  break;
               case "South African":
                  $selected[164] = "selected";
                  break;
               case "South Korean":
                  $selected[165] = "selected";
                  break;
               case "Spanish":
                  $selected[166] = "selected";
                  break;
               case "Sri Lankan":
                  $selected[167] = "selected";
                  break;
               case "Sudanese":
                  $selected[168] = "selected";
                  break;
               case "Surinamer":
                  $selected[169] = "selected";
                  break;
               case "Swazi":
                  $selected[170] = "selected";
                  break;
               case "Swedish":
                  $selected[171] = "selected";
                  break;
               case "Swiss":
                  $selected[172] = "selected";
                  break;
               case "Syrian":
                  $selected[173] = "selected";
                  break;
               case "Taiwanese":
                  $selected[174] = "selected";
                  break;
               case "Tajik":
                  $selected[175] = "selected";
                  break;
               case "Tanzanian":
                  $selected[176] = "selected";
                  break;
               case "Thai":
                  $selected[177] = "selected";
                  break;
               case "Togolese":
                  $selected[178] = "selected";
                  break;
               case "Tongan":
                  $selected[179] = "selected";
                  break;
               case "Trinidadian or Tobagonian":
                  $selected[180] = "selected";
                  break;
               case "Tunisian":
                  $selected[181] = "selected";
                  break;
               case "Turkish":
                  $selected[182] = "selected";
                  break;
               case "Tuvaluan":
                  $selected[183] = "selected";
                  break;
               case "Ugandan":
                  $selected[184] = "selected";
                  break;
               case "Ukrainian":
                  $selected[185] = "selected";
                  break;
               case "Uruguayan":
                  $selected[186] = "selected";
                  break;
               case "Uzbekistani":
                  $selected[187] = "selected";
                  break;
               case "Venezuelan":
                  $selected[188] = "selected";
                  break;
               case "Vietnamese":
                  $selected[189] = "selected";
                  break;
               case "Welsh":
                  $selected[190] = "selected";
                  break;
               case "Yemenite":
                  $selected[191] = "selected";
                  break;
               case "Zambian":
                  $selected[192] = "selected";
                  break;
               case "Zimbabwean":
                  $selected[193] = "selected";
                  break;
            }
            echo "<select class=\"form-control\" id=\"extra6\" name=\"extra6\" size=\"1\"><option value=\"Afghan\"".$selected[0].">Afghan</option><option value=\"Albanian\"".$selected[1].">Albanian</option><option value=\"Algerian\"".$selected[2].">Algerian</option><option value=\"American\"".$selected[3].">American</option><option value=\"Andorran\"".$selected[4].">Andorran</option><option value=\"Angolan\"".$selected[5].">Angolan</option><option value=\"Antiguans\"".$selected[6].">Antiguans</option><option value=\"Argentinean\"".$selected[7].">Argentinean</option><option value=\"Armenian\"".$selected[8].">Armenian</option><option value=\"Australian\"".$selected[9].">Australian</option><option value=\"Austrian\"".$selected[10].">Austrian</option><option value=\"Azerbaijani\"".$selected[11].">Azerbaijani</option><option value=\"Bahamian\"".$selected[12].">Bahamian</option><option value=\"Bahraini\"".$selected[13].">Bahraini</option><option value=\"Bangladeshi\"".$selected[14].">Bangladeshi</option><option value=\"Barbadian\"".$selected[15].">Barbadian</option><option value=\"Barbudans\"".$selected[16].">Barbudans</option><option value=\"Batswana\"".$selected[17].">Batswana</option><option value=\"Belarusian\"".$selected[18].">Belarusian</option><option value=\"Belgian\"".$selected[19].">Belgian</option><option value=\"Belizean\"".$selected[20].">Belizean</option><option value=\"Beninese\"".$selected[21].">Beninese</option><option value=\"Bhutanese\"".$selected[22].">Bhutanese</option><option value=\"Bolivian\"".$selected[23].">Bolivian</option><option value=\"Bosnian\"".$selected[24].">Bosnian</option><option value=\"Brazilian\"".$selected[25].">Brazilian</option><option value=\"British\"".$selected[26].">British</option><option value=\"Bruneian\"".$selected[27].">Bruneian</option><option value=\"Bulgarian\"".$selected[28].">Bulgarian</option><option value=\"Burkinabe\"".$selected[29].">Burkinabe</option><option value=\"Burmese\"".$selected[30].">Burmese</option><option value=\"Burundian\"".$selected[31].">Burundian</option><option value=\"Cambodian\"".$selected[32].">Cambodian</option><option value=\"Cameroonian\"".$selected[33].">Cameroonian</option><option value=\"Canadian\"".$selected[34].">Canadian</option><option value=\"Cape Verdean\"".$selected[35].">Cape Verdean</option><option value=\"Central African\"".$selected[36].">Central African</option><option value=\"Chadian\"".$selected[37].">Chadian</option><option value=\"Chilean\"".$selected[38].">Chilean</option><option value=\"Chinese\"".$selected[39].">Chinese</option><option value=\"Colombian\"".$selected[40].">Colombian</option><option value=\"Comoran\"".$selected[41].">Comoran</option><option value=\"Congolese\"".$selected[42].">Congolese</option><option value=\"Costa Rican\"".$selected[43].">Costa Rican</option><option value=\"Croatian\"".$selected[44].">Croatian</option><option value=\"Cuban\"".$selected[45].">Cuban</option><option value=\"Cypriot\"".$selected[46].">Cypriot</option><option value=\"Czech\"".$selected[47].">Czech</option><option value=\"Danish\"".$selected[48].">Danish</option><option value=\"Djibouti\"".$selected[49].">Djibouti</option><option value=\"Dominican\"".$selected[50].">Dominican</option><option value=\"Dutch\"".$selected[51].">Dutch</option><option value=\"East Timorese\"".$selected[52].">East Timorese</option><option value=\"Ecuadorean\"".$selected[53].">Ecuadorean</option><option value=\"Egyptian\"".$selected[54].">Egyptian</option><option value=\"Emirian\"".$selected[55].">Emirian</option><option value=\"Equatorial Guinean\"".$selected[56].">Equatorial Guinean</option><option value=\"Eritrean\"".$selected[57].">Eritrean</option><option value=\"Estonian\"".$selected[58].">Estonian</option><option value=\"Ethiopian\"".$selected[59].">Ethiopian</option><option value=\"Fijian\"".$selected[60].">Fijian</option><option value=\"Filipino\"".$selected[61].">Filipino</option><option value=\"Finnish\"".$selected[62].">Finnish</option><option value=\"French\"".$selected[63].">French</option><option value=\"Gabonese\"".$selected[64].">Gabonese</option><option value=\"Gambian\"".$selected[65].">Gambian</option><option value=\"Georgian\"".$selected[66].">Georgian</option><option value=\"German\"".$selected[67].">German</option><option value=\"Ghanaian\"".$selected[68].">Ghanaian</option><option value=\"Greek\"".$selected[69].">Greek</option><option value=\"Grenadian\"".$selected[70].">Grenadian</option><option value=\"Guatemalan\"".$selected[71].">Guatemalan</option><option value=\"Guinea-Bissauan\"".$selected[72].">Guinea-Bissauan</option><option value=\"Guinean\"".$selected[73].">Guinean</option><option value=\"Guyanese\"".$selected[74].">Guyanese</option><option value=\"Haitian\"".$selected[75].">Haitian</option><option value=\"Herzegovinian\"".$selected[76].">Herzegovinian</option><option value=\"Honduran\"".$selected[77].">Honduran</option><option value=\"Hungarian\"".$selected[78].">Hungarian</option><option value=\"I-Kiribati\"".$selected[79].">I-Kiribati</option><option value=\"Icelander\"".$selected[80].">Icelander</option><option value=\"Indian\"".$selected[81].">Indian</option><option value=\"Indonesian\"".$selected[82].">Indonesian</option><option value=\"Iranian\"".$selected[83].">Iranian</option><option value=\"Iraqi\"".$selected[84].">Iraqi</option><option value=\"Irish\"".$selected[85].">Irish</option><option value=\"Israeli\"".$selected[86].">Israeli</option><option value=\"Italian\"".$selected[87].">Italian</option><option value=\"Ivorian\"".$selected[88].">Ivorian</option><option value=\"Jamaican\"".$selected[89].">Jamaican</option><option value=\"Japanese\"".$selected[90].">Japanese</option><option value=\"Jordanian\"".$selected[91].">Jordanian</option><option value=\"Kazakhstani\"".$selected[92].">Kazakhstani</option><option value=\"Kenyan\"".$selected[93].">Kenyan</option><option value=\"Kittian and Nevisian\"".$selected[94].">Kittian and Nevisian</option><option value=\"Kuwaiti\"".$selected[95].">Kuwaiti</option><option value=\"Kyrgyz\"".$selected[96].">Kyrgyz</option><option value=\"Laotian\"".$selected[97].">Laotian</option><option value=\"Latvian\"".$selected[98].">Latvian</option><option value=\"Lebanese\"".$selected[99].">Lebanese</option><option value=\"Liberian\"".$selected[100].">Liberian</option><option value=\"Libyan\"".$selected[101].">Libyan</option><option value=\"Liechtensteiner\"".$selected[102].">Liechtensteiner</option><option value=\"Lithuanian\"".$selected[103].">Lithuanian</option><option value=\"Luxembourger\"".$selected[104].">Luxembourger</option><option value=\"Macedonian\"".$selected[105].">Macedonian</option><option value=\"Malagasy\"".$selected[106].">Malagasy</option><option value=\"Malawian\"".$selected[107].">Malawian</option><option value=\"Malaysian\"".$selected[108].">Malaysian</option><option value=\"Maldivian\"".$selected[109].">Maldivian</option><option value=\"Malian\"".$selected[110].">Malian</option><option value=\"Maltese\"".$selected[111].">Maltese</option><option value=\"Marshallese\"".$selected[112].">Marshallese</option><option value=\"Mauritanian\"".$selected[113].">Mauritanian</option><option value=\"Mauritian\"".$selected[114].">Mauritian</option><option value=\"Mexican\"".$selected[115].">Mexican</option><option value=\"Micronesian\"".$selected[116].">Micronesian</option><option value=\"Moldovan\"".$selected[117].">Moldovan</option><option value=\"Monacan\"".$selected[118].">Monacan</option><option value=\"Mongolian\"".$selected[119].">Mongolian</option><option value=\"Moroccan\"".$selected[120].">Moroccan</option><option value=\"Mosotho\"".$selected[121].">Mosotho</option><option value=\"Motswana\"".$selected[122].">Motswana</option><option value=\"Mozambican\"".$selected[123].">Mozambican</option><option value=\"Namibian\"".$selected[124].">Namibian</option><option value=\"Nauruan\"".$selected[125].">Nauruan</option><option value=\"Nepalese\"".$selected[126].">Nepalese</option><option value=\"New Zealander\"".$selected[127].">New Zealander</option><option value=\"Ni-Vanuatu\"".$selected[128].">Ni-Vanuatu</option><option value=\"Nicaraguan\"".$selected[129].">Nicaraguan</option><option value=\"Nigerian\"".$selected[130].">Nigerian</option><option value=\"Nigerien\"".$selected[131].">Nigerien</option><option value=\"North Korean\"".$selected[132].">North Korean</option><option value=\"Northern Irish\"".$selected[133].">Northern Irish</option><option value=\"Norwegian\"".$selected[134].">Norwegian</option><option value=\"Omani\"".$selected[135].">Omani</option><option value=\"Pakistani\"".$selected[136].">Pakistani</option><option value=\"Palauan\"".$selected[137].">Palauan</option><option value=\"Panamanian\"".$selected[138].">Panamanian</option><option value=\"Papua New Guinean\"".$selected[139].">Papua New Guinean</option><option value=\"Paraguayan\"".$selected[140].">Paraguayan</option><option value=\"Peruvian\"".$selected[141].">Peruvian</option><option value=\"Polish\"".$selected[142].">Polish</option><option value=\"Portuguese\"".$selected[143].">Portuguese</option><option value=\"Qatari\"".$selected[144].">Qatari</option><option value=\"Romanian\"".$selected[145].">Romanian</option><option value=\"Russian\"".$selected[146].">Russian</option><option value=\"Rwandan\"".$selected[147].">Rwandan</option><option value=\"Saint Lucian\"".$selected[148].">Saint Lucian</option><option value=\"Salvadoran\"".$selected[149].">Salvadoran</option><option value=\"Samoan\"".$selected[150].">Samoan</option><option value=\"San Marinese\"".$selected[151].">San Marinese</option><option value=\"Sao Tomean\"".$selected[152].">Sao Tomean</option><option value=\"Saudi\"".$selected[153].">Saudi</option><option value=\"Scottish\"".$selected[154].">Scottish</option><option value=\"Senegalese\"".$selected[155].">Senegalese</option><option value=\"Serbian\"".$selected[156].">Serbian</option><option value=\"Seychellois\"".$selected[157].">Seychellois</option><option value=\"Sierra Leonean\"".$selected[158].">Sierra Leonean</option><option value=\"Singaporean\"".$selected[159].">Singaporean</option><option value=\"Slovakian\"".$selected[160].">Slovakian</option><option value=\"Slovenian\"".$selected[161].">Slovenian</option><option value=\"Solomon Islander\"".$selected[162].">Solomon Islander</option><option value=\"Somali\"".$selected[163].">Somali</option><option value=\"South African\"".$selected[164].">South African</option><option value=\"South Korean\"".$selected[165].">South Korean</option><option value=\"Spanish\"".$selected[166].">Spanish</option><option value=\"Sri Lankan\"".$selected[167].">Sri Lankan</option><option value=\"Sudanese\"".$selected[168].">Sudanese</option><option value=\"Surinamer\"".$selected[169].">Surinamer</option><option value=\"Swazi\"".$selected[170].">Swazi</option><option value=\"Swedish\"".$selected[171].">Swedish</option><option value=\"Swiss\"".$selected[172].">Swiss</option><option value=\"Syrian\"".$selected[173].">Syrian</option><option value=\"Taiwanese\"".$selected[174].">Taiwanese</option><option value=\"Tajik\"".$selected[175].">Tajik</option><option value=\"Tanzanian\"".$selected[176].">Tanzanian</option><option value=\"Thai\"".$selected[177].">Thai</option><option value=\"Togolese\"".$selected[178].">Togolese</option><option value=\"Tongan\"".$selected[179].">Tongan</option><option value=\"Trinidadian or Tobagonian\"".$selected[180].">Trinidadian or Tobagonian</option><option value=\"Tunisian\"".$selected[181].">Tunisian</option><option value=\"Turkish\"".$selected[182].">Turkish</option><option value=\"Tuvaluan\"".$selected[183].">Tuvaluan</option><option value=\"Ugandan\"".$selected[184].">Ugandan</option><option value=\"Ukrainian\"".$selected[185].">Ukrainian</option><option value=\"Uruguayan\"".$selected[186].">Uruguayan</option><option value=\"Uzbekistani\"".$selected[187].">Uzbekistani</option><option value=\"Venezuelan\"".$selected[188].">Venezuelan</option><option value=\"Vietnamese\"".$selected[189].">Vietnamese</option><option value=\"Welsh\"".$selected[190].">Welsh</option><option value=\"Yemenite\"".$selected[191].">Yemenite</option><option value=\"Zambian\"".$selected[192].">Zambian</option><option value=\"Zimbabwean\"".$selected[193].">Zimbabwean</option></select>\n";
            echo "<label for=\"extra7\">Next of Kin</label>\n";
            echo "<input class=\"form-control\" id=\"extra7\" name=\"extra7\" size=\"50\" type=\"text\" value=\"" . $extra7_value . "\">\n";
            echo "<label for=\"extra8\">Item deposited</label>\n";
            echo "<input class=\"form-control\" id=\"extra8\" name=\"extra8\" size=\"50\" type=\"text\" value=\"" . $extra8_value . "\">\n";
            echo "<label for=\"extra9\">Monthly Charges</label>\n";
            echo "<input class=\"form-control\" id=\"extra9\" name=\"extra9\" size=\"50\" type=\"text\" value=\"" . $extra9_value . "\">\n";
            echo "<label for=\"extra10\">Container Value</label>\n";
            echo "<input class=\"form-control\" id=\"extra10\" name=\"extra10\" size=\"50\" type=\"text\" value=\"" . $extra10_value . "\">\n";
            echo "<label for=\"extra11\">Date of Deposit</label>\n";
            echo "<input class=\"form-control\" id=\"extra11\" name=\"extra11\" size=\"50\" type=\"text\" value=\"" . $extra11_value . "\">\n";
            echo "<label for=\"extra12\">Purpose of deposit</label>\n";
            $selected = array("","");
            switch ($extra12_value)
            {
               case "Safe Keeping":
                  $selected[0] = "selected";
                  break;
               case "Shipping":
                  $selected[1] = "selected";
                  break;
            }
            echo "<select class=\"form-control\" id=\"extra12\" name=\"extra12\" size=\"1\"><option value=\"Safe Keeping\"".$selected[0].">Safe Keeping</option><option value=\"Shipping\"".$selected[1].">Shipping</option></select>\n";
            echo "<label for=\"extra13\">Reference No</label>\n";
            echo "<input class=\"form-control\" id=\"extra13\" name=\"extra13\" size=\"50\" type=\"text\" value=\"" . $extra13_value . "\">\n";
            echo "<label for=\"extra14\">Release code</label>\n";
            echo "<input class=\"form-control\" id=\"extra14\" name=\"extra14\" size=\"50\" type=\"text\" value=\"" . $extra14_value . "\">\n";
            echo "<label for=\"extra15\">Account Value</label>\n";
            echo "<input class=\"form-control\" id=\"extra15\" name=\"extra15\" size=\"50\" type=\"text\" value=\"" . $extra15_value . "\">\n";
            echo "<label for=\"extra16\">Account Due</label>\n";
            echo "<input class=\"form-control\" id=\"extra16\" name=\"extra16\" size=\"50\" type=\"text\" value=\"" . $extra16_value . "\">\n";
            echo "<label for=\"active\">Status</label>\n";
            echo "<select class=\"form-control\" name=\"active\" size=\"1\"><option " . ($active_value == "0" ? "selected " : "") . "value=\"0\">inactive</option><option " . ($active_value != "0" ? "selected " : "") . "value=\"1\">active</option></select>\n";
            echo "<input class=\"btn\" type=\"submit\" name=\"cmdSubmit\" value=\"Save\">";
            echo "&nbsp;&nbsp;";
            echo "<input class=\"btn\" name=\"cmdBack\" type=\"button\" value=\"Cancel\" onclick=\"location.href='" . basename(__FILE__) . "'\">\n";
            echo "</form>\n";
            echo "</div>\n";
         }
      }
      else
      {
         echo "<div id=\"header\"><a class=\"btn\" href=\"" . basename(__FILE__) . "?action=new\">New User</a>&nbsp;&nbsp;<a class=\"btn\" href=\"" . basename(__FILE__) . "?action=logout\">Logout</a>\n";
         echo "<div id=\"filter\">\n";
         echo "<label>Search: </label> <input class=\"form-control\" placeholder=\"\" type=\"search\">\n";
         echo "</div>\n</div>\n";
         echo "<table class=\"table table-striped table-hover\">\n";
         echo "<thead><tr><th>Username</th><th>Fullname</th><th>Email</th><th>Status</th><th>Action</th></tr></thead>\n";
         echo "<tbody>\n";
         $sql = "SELECT * FROM ".$mysql_table;
         $result = mysqli_query($db, $sql);
         while ($data = mysqli_fetch_array($result))
         {
            echo "<tr>\n";
            echo "<td>" . $data['username'] . "</td>\n";
            echo "<td>" . $data['fullname'] . "</td>\n";
            echo "<td>" . $data['email'] . "</td>\n";
            echo "<td>" . ($data['active'] == "0" ? "inactive" : "active") . "</td>\n";
            echo "<td>\n";
            echo "   <a href=\"" . basename(__FILE__) . "?action=edit&id=" . $data['username'] . "\" title=\"Edit\"><i class=\"icon-edit\"></i></a>&nbsp;\n";
            echo "   <a href=\"" . basename(__FILE__) . "?action=delete&id=" . $data['username'] . "\" title=\"Delete\"><i class=\"icon-delete\"></i></a>\n";
            echo "</td>\n";
            echo "</tr>\n";
         }
         echo "</tbody>\n";
         echo "</table>\n";
         echo "<div id=\"footer\">\n";
         echo "<ul id=\"pagination\">\n";
         echo "<li class=\"disabled\"><a href=\"#\">&laquo; Prev</a></li>\n";
         echo "<li class=\"disabled\"><a href=\"#\">Next &raquo;</a></li>\n";
         echo "</ul>\n";
         echo "</div>\n";
      }
   }
?>
</body>
</html>
