<?php


session_start();
include 'api.php';
echo "<script>window.location = 'login.php';</script>";
exit();

?>