<?php
$emailku = 'copetciroyom197@gmail.com'; // GANTI EMAIL KAMU DISINI
?>