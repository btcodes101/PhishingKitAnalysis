<?php

$praga=rand();
$praga=md5($praga);
    
         

    $url = "./login.php?session_id=$praga$$praga";
    header("Location: ".$url);

?>