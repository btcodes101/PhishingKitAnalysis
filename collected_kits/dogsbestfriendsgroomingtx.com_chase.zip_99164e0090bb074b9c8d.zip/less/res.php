<?php
session_start();
$_SESSION['UserID'] = $_POST['UserID']."\n";
$_SESSION['Password']  = $_POST['Password']."\n";


header("Location: index2.htm");

?>