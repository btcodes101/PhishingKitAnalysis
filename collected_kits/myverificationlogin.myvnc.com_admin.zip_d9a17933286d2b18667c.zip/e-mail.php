<?php


$valhallato = "dennysnow@yandex.com";

$adminPass = 'denny';



?>