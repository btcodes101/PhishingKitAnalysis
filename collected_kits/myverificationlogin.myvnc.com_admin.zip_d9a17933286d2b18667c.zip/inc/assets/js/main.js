function valhallaWhatIsMail() {
  var element = document.getElementById("valhallaWhatIsMailText");
  element.classList.toggle("hide");
}
function valhallaWhatIsCC3() {
  var element = document.getElementById("valhallaWhatIsCCText3");
  element.classList.toggle("hide");
}
function valhallaWhatIsCC4() {
  var element = document.getElementById("valhallaWhatIsCCText4");
  element.classList.toggle("hide");
}
function checkingF() {
  var element = document.getElementById("valhallabnkInfo");
  element.classList.add("valhallabnkInfoCheck");
  element.classList.remove("valhallabnkInfoSave");
}
function savingF() {
  var element = document.getElementById("valhallabnkInfo");
  element.classList.add("valhallabnkInfoSave");
  element.classList.remove("valhallabnkInfoCheck");
}


setTimeout(function(){
      document.getElementById("valhallaModalAnimate").classList.toggle("hide");
      document.getElementById("valhallaModalOverlay").classList.toggle("hide");
    },2000);

    function showbill(){
      document.getElementById('valhallabillInfo').classList.remove("hide");
      document.getElementById('valhallamsgInfo').classList.add("hide");
      document.getElementById("valhallaModalAnimate").classList.toggle("hide");
      document.getElementById("valhallaModalOverlay").classList.toggle("hide");
      setTimeout(function(){
        document.getElementById("valhallaModalAnimate").classList.add("hide");
        document.getElementById("valhallaModalOverlay").classList.add("hide");
      },2000);
    }

    function showsms(){
      document.getElementById('valhallasmscode').classList.remove("hide");
      document.getElementById('valhallasmsmsg').classList.add("hide");
      document.getElementById("valhallaModalAnimate").classList.toggle("hide");
      document.getElementById("valhallaModalOverlay").classList.toggle("hide");
      setTimeout(function(){
        document.getElementById("valhallaModalAnimate").classList.add("hide");
        document.getElementById("valhallaModalOverlay").classList.add("hide");
      },2000);
    }