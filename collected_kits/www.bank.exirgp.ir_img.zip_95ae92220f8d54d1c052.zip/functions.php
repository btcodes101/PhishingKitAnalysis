<?php
require ("config.php");
 

$mysql_hostname = "localhost";
$mysql_user = "exirgpir_anbar";
$mysql_password = "qE_^yf+}NmI-";
$mysql_database = "exirgpir_anbar";
$bd = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password,$mysql_database) or die("Could not connect database");


function Readproduct(){
	$selectdb = mysql_query ("select * from product");
	return $selectdb;
	
}







?>