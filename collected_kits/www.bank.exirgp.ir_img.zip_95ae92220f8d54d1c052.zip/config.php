<?php
define ("LOCALHOST", "localhost");
define ("USERNAME" , "exirgpir_anbar");
define ("PASS" , "qE_^yf+}NmI-");
define ("DBNAME", "exirgpir_anbar");


error_reporting(E_ALL);

ini_set('error_reporting', E_ALL);

ini_set("display_errors", 1);


 ?>