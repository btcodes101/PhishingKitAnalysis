<?php
require ("functions.php");
 
?>
<!doctype html>

<html>  
	<head> 
	<title>نرم افزار انبار </title>
	</head>
	<body>
		<style>  
			body{
				
				margin:0;
				direction:rtl;
			}
			#box{
				width:900px;
				height:600px;
				margin: 60px auto;
				
			}
			table,td{
				border: 1px solid red;
				text-align: center;
				padding: 4px 5px;
				border-collapse:collapse;
			}
		
		</style>
		<div id="box">
			<table width='100%'>
				<tr>
					<td>  نام کالا</td>
					<td> سایز</td>
					<td> رنگ</td>
					<td> گروه</td>
					<td>  قیمت فروش</td>
					<td> موجودی</td>
					<td> نوع کالا</td>
					<td> قیمت تولید</td>
					<td>برند </td>
					<td>کد کالا </td>
					<td>برند </td>
				</tr>
			</table>
			<?php
				
				$tesult=Readproduct();
				while($showRow = mysql_fetch_assoc($tesult)){
					echo $showRow['size'];
					
				}
				
			?>
		</div>
	</body>
</html>