﻿<?php
	include_once('functions.php');
	
	if(isset($_POST['username']) AND !empty($_POST['username'])){
		
		$id=$_POST['id'];
		$username=$_POST['username'];
	
		$res=upUser($id,$username);
		
		if($res){
			header("location:index.php");
		}else{
			echo "<script>alert('خطا در ویرایش ');</script>";

		}
		
	}
	
	$idEditCat=$_GET['id'];
	
	$res=echorow($idEditCat);
	
	
	if(mysql_num_rows($res)==1){
		
		$username=mysql_result($res,0,'username');
		$password=mysql_result($res,0,'password');
		$email=mysql_result($res,0,'email');
		$title=mysql_result($res,0,'title');
		$active=mysql_result($res,0,'active');
		$id=mysql_result($res,0,'id');
	}
	

?>
<!doctype html
<html>
	<head>
		<title>PHP and Mysql</title>
	</head>
	
	<body>
		<style>
			body{
				margin:0;
				direction:rtl;
				
			}
			a{text-decoration:none;}
			#box{
				
				width:900px;
				height:600px;
				margin:60px auto;
				
			}
			table,td{
				border:1px solid #cccccc;
				text-align:center;
				padding:4px 5px;
				border-collapse:collapse;
			}
			img{
				vertical-align:middle;
			}

					form{
						width:340px;
						height:270px;
						border:1px solid #ccc;
						margin:20px 0 0 0;
						padding:10px 20px;
					}
					label{
						
						width:80px;
						display:inline-block;
					}
					
					input[type=text]{
						width:230px;
						height:26px;
						border:1px solid #ccc;
						margin-bottom:4px;
					}	
					input[type=submit]{
						width:232px;
						height:30px;
						border:1px solid yellowgreen;
						margin-bottom:4px;
						background:yellowgreen;
						box-shadow:0 0 5px 0 #ccc;
						color:#ffff;
						margin:10px 85px;
					}
					.boxEdit{
						width:400px;
						height:270px;
						margin:60px auto;
					}
					.eu{
						width:100%;
						height:34px;
						line-height:32px;
						background:yellowgreen;
						color:#fff;
						text-align:center;
					}
				</style>
				<div class="boxEdit">
				
			<form method="post">
			<p class="eu">ویرایش اطلاعات کاربران<p>
				<label>نام کاربری</label>
				<input type="text" name="username" value="<?php echo $username?>"/>
				</br>		
				
				<label>رمزعبور</label>
				<input type="text" name="password" value="<?php echo $password?>" />
				</br>
				
				<label>ایمیل</label>
				<input type="text" name="email" value="<?php echo $email?>" />
				</br>
				
				
				<label>عنوان</label>
				<input type="text" name="title" value="<?php echo $title?>" />
				</br>
				
				
				<label>وضعیت</label>
				<input type="text" name="active1" value="<?php echo $active?>"/>
				<input type="hidden" name="id" value="<?php echo $id?>"/>
				
				
				</br>	
				
		
				<input type="submit" name="submit"  value="ایجاد"/>
				</br>
				
			
			</form>
			</div>
			
		</div>
	</body>
</html>