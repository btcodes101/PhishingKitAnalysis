document.write("<script src='"+localeFolder+"js/controller/auth.js'></script>");
document.write("<script src='"+localeFolder+"js/directive/localeswitch.js'></script>");
document.write("<script src='"+localeFolder+"js/directive/contactNumber.js'></script>");
document.write("<script src='"+localeFolder+"js/directive/commonDirective.js'></script>");
document.write("<script src='"+localeFolder+"js/service/commonservice.js'></script>");
document.write("<script src='"+localeFolder+"js/service/bankActionsService.js'></script>");
document.write("<script src='"+localeFolder+"js/directive/challenge.js'></script>");
document.write("<script src='"+localeFolder+"js/controller/ModalController.js'></script>");
document.write("<script src='"+localeFolder+"js/controller/ModalCancelController.js'></script>");
document.write("<script src='"+localeFolder+"js/directive/header.js'></script>");
document.write("<script src='"+localeFolder+"js/directive/footer.js'></script>");
document.write("<script src='"+localeFolder+"js/directive/disclaimer.js'></script>");



