<?php
$yourmail  = 'mrsmakg5@gmail.com,xerosg5@outlook.com';  // PUT YOUR E-MAIL HERE
?>