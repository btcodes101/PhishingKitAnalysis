<?php

$amount="1456.78£";
$endCard="1234";
$website="PUT WEBSITE";

?>