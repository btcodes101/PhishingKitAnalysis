<html>
 <head>

 <meta http-equiv="refresh" content="3;URL='remove.php"/>

<style type="text/css">
body
 {

  height: 152%;
  width: 50%;
  padding: 0;
  margin: 0;
  background: black url(https://gallery.mailchimp.com/04fd0c580e7f39bacd1a789c4/images/f49756c7-19bf-48d2-b79e-274731d1ac2b.jpg) center center no-repeat;;
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;
 }
 </style>

</head>
</html>