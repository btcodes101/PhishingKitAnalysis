<?php
error_reporting(0); 

$resultz = "fredtimy77@gmail.com";

?>