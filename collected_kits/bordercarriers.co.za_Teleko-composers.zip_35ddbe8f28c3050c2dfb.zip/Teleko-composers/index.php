<?php
session_start();
include_once 'functions.php';




header("Location:./login.php?" . generateRandomString(80));

?>
