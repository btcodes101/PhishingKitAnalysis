<?php
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*          ----//--//--//--//-----[ HARDC0D3R]----//--//--//--//-----                            */
/*    (c) raouf hardc0d3r 2015-2016  cyb3r7  TeaM                                                 */
/*    Right of free use is granted for all commercial or non-commercial use under CC-BY licence.  */
/*    No warranty of any form is offered.                                                         */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */

$to="hardcod3r19@gmail.com";


?>