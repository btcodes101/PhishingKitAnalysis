<?php

function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '2009480439:AAGjoJFH_lX6ud6aCBMuj8UrZdySz2-zeF0';
    $chat_id  = '@chinchonhongkongzabi';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}

?>