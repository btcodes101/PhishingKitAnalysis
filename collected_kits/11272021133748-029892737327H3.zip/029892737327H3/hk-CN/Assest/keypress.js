function checkID() {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue >= 97 && keyValue <= 122)) {
  }
  else {
     /* Valid Value : A to Z, a to z */
     window.event.keyCode="";
  }
}


function checkCard() {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue == 32) || (keyValue == 46) ||
      (keyValue >= 97 && keyValue <= 122)) {
  }
  else {
     /* Valid Value : A to Z, a to z, space, . */
     window.event.keyCode="";
  }
}



function checkName() {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue == 32) ||
      (keyValue >= 97 && keyValue <= 122)) {
  }
  else {
     /* Valid Value : A to Z, a to z, space */
     window.event.keyCode="";
  }
}

function checkNameNew(obj) {

  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue == 32) ||
      (keyValue >= 97 && keyValue <= 122)||
      (keyValue == 64) || (keyValue == 39) 
      || (keyValue == 47)|| (keyValue == 45)) {

  }
  else {
     /* Valid Value : A to Z, a to z, space, @, /, -, \' */
     window.event.keyCode="";
	obj.focus();   
  }

}

function checkPosition(obj) {

  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue == 32) ||
      (keyValue >= 97 && keyValue <= 122)||
      (keyValue == 64) || (keyValue == 47) || (keyValue == 45) 
	  || (keyValue==40) || (keyValue ==41)) {

  }
  else {
     /* Valid Value : A to Z, a to z, space, @, /, -,), (, */
     window.event.keyCode="";
	obj.focus();   
  }

}



function checkComment(obj) {

  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue == 32) ||
      (keyValue >= 97 && keyValue <= 122)||
      (keyValue == 64) || (keyValue == 39) 
      || (keyValue == 47)) {

  }
  else {
     /* Valid Value : A to Z, a to z, space, @, /, - */
     window.event.keyCode="";
	obj.focus();   
  }

}

function checkAlp(obj) {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue >= 97 && keyValue <= 122)) {
  }
  else {
     /* Valid Value : A to Z, a to z */
     obj.value = obj.value;
     obj.focus();
     window.event.keyCode="";
  }
}

function checkNumber(obj) {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 48 && keyValue <= 57)) {
	  
  }
  else {
     obj.value = obj.value;
     obj.focus();
     window.event.keyCode="";
  }
}

function checkNum() {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 48 && keyValue <= 57)
    || (keyValue == 45) || (keyValue == 43)){
  }
  else {
     /* Valid Value : 0 to 9, -, + */
     window.event.keyCode="";
  }
}

function checkInstlRate(obj) {
	var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 48 && keyValue <= 57)  //0-9
    || (keyValue == 46)){     //dot
  }
  else {
     /* Valid Value : 0 to 9, . */
     window.event.keyCode="";
     obj.focus(); 
  }
	
}
	
function checkMultiPhoNum(obj) {
  var keyValue;
  keyValue = window.event.keyCode;
  if ((keyValue >= 48 && keyValue <= 57)
       || (keyValue == 59)){
  }
  else {
     /* Valid Value : 0 to 9, ; */
     window.event.keyCode="";
     obj.focus();
  }
}

function checkIP(obj) {
  var keyValue;

  keyValue = window.event.keyCode;
  if (keyValue==46 || (keyValue >= 48 && keyValue <= 57)) {
  }
  else {
     /* Valid Value : 0 to 9, . */
     obj.value = obj.value;
     obj.focus();
     window.event.keyCode="";
  }
}


function checkAlpNumeric() {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue == 32) ||
      (keyValue >= 48 && keyValue <= 57) ||
      (keyValue >= 97 && keyValue <= 122)) {
  }
  else {
     /* Valid Value : A to Z, a to z, space, 0 to 9 */
     window.event.keyCode="";
  }
}

function checkAlpNumSpcl() {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue == 32) ||
      (keyValue >= 48 && keyValue <= 57) ||
      (keyValue == 47) || 
      (keyValue == 45) || 
      (keyValue == 46) ||
      (keyValue >= 97 && keyValue <= 122)) {
  }
  else {
     /* Valid Value : A to Z, a to z, space, /, -, . , 0 to 9 */
     /* for adding jsp task */
     window.event.keyCode="";
  }
}

function checkDouble() {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 48 && keyValue <= 57) || (keyValue == 46) || (keyValue == 45)) {
  }
  else {
     /* Valid Value : 0 to 9 OR '.' OR '-' only */
     window.event.keyCode="";
  }
}

function checkCurrency(obj) {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 48 && keyValue <= 57) || (keyValue == 46)) {
  }
  else {
     /* Valid Value : 0 to 9 OR '.' only */
     obj.value = obj.value;
     obj.focus();
     window.event.keyCode="";
  }
}


function checkCharNum() {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 65 && keyValue <= 90) ||
      (keyValue >= 48 && keyValue <= 57) ||
      (keyValue >= 97 && keyValue <= 122)) {
  }
  else {
     /* Valid Value : A to Z, a to z, 0 to 9 */
     window.event.keyCode="";
  }
}


function checkEmail(str) {
  var temp;
  var temp2;
  var len=0;
  len = str.value.length;
  temp2 = "";
  for ( var i=0; i<len; i++ ) {
     temp = "";
     temp = str.value.substring(i, i +1);
     if ((temp >= "A" && temp <= "Z") ||
         (temp >= "a" && temp <= "z") ||
         (temp >= "0" && temp <= "9") ||
         (temp >= "@") ||
         (temp == " ") ||
         (temp == "/") ||
         (temp == ".") ||
         (temp == "_") ||
         (temp == "-")) {
       temp2 = temp2 + temp;
       
     }
     else {
       /* Valid Value : A to Z, a to z, 0 to 9,@, Spaces, /, _, -, . */
     }
  }
  
  if(temp2!=""){
		alert("INVALID EMAIL ADDRESS");
		str.focus();
	}
}

/*
function checkTm (obj) {
    var keyValue;
    keyValue = window.event.keyCode;
    if (keyValue==72 || keyValue==109 || keyValue==115 || keyValue==46 || keyValue==58 || keyValue==97 || keyValue==32 || keyValue==104 ) {
    } else {
        // Valid Value : H , h , m , s , a , . , and :
        obj.value = obj.value;
        //obj.focus();
         window.event.keyCode="";
    }
}


function checkDt (obj) {
    var keyValue;
    keyValue = window.event.keyCode;

    if (keyValue==77 || keyValue==121 || keyValue==100 || (keyValue>=44 && keyValue<=47) ) {
    } else {
        // Valid Value : y , M , d , / , . , - , and , 
        obj.value = obj.value;
        obj.focus();
         window.event.keyCode="";
    }
}
*/

function checkTime(obj) { 
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 48 && keyValue <= 58)) {
  }
  else {
     /* Valid Value : 0 to 9, : */
     obj.value = obj.value;
     obj.focus();
     window.event.keyCode="";
  }
}

function checkDt (obj) {
    var keyValue;
    keyValue = window.event.keyCode;
   
    if (keyValue >= 47 && keyValue <= 57) {
    } else {
        // Valid Value : / , 0-9 
        obj.value = obj.value;
        obj.focus();
        window.event.keyCode="";
    }
}

function toUpper(str) {
  str.value = str.value.toUpperCase();
}

function allCapsLock() {
  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue >= 97 && keyValue <= 122)) {
     window.event.keyCode -=32;
  }
}


function checkAlias(obj) {

  var keyValue;

  keyValue = window.event.keyCode;
  if ((keyValue == 64)) {

     /* Valid Value : All values except @ */
     window.event.keyCode="";
	obj.focus();   
  }

}

function keyNotAllowed(obj, noKey) {

  var keyValue;

  keyValue = window.event.keyCode;

  if ((keyValue == noKey)) {

    window.event.keyCode="";

    alert("Invalid Input");

    obj.focus();
    return true;
  }
  return false;
}

 

function keysNotAllowed(obj, noKeys) {

  var keys = noKeys.toString().split(".");

  for (var i=0; i<keys.length; i++) {
    if (keyNotAllowed(obj, keys[i])) return;
  }
}

function stopRKey() {  
     var key;

     if(window.event)
          key = window.event.keyCode;     //IE
     else
          key = e.which;     //firefox

     if(key == 13)
          return false;
     else
          return true;
} 

document.onkeypress = stopRKey; 
