var pattern=new Object();
pattern.email=/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
//pattern.date=/^((0[1-9]|[1-2][0-9]|3[0-1])\/(0[1-9]|1[0-2])\/\d{4,4})|(00\/00\/0000)$/;
pattern.date=/^(00\/00\/0000)|((0[1-9]|[1-2][0-9]|3[0-1])\/(0[1-9]|1[0-2])\/\d{4,4})$/;
pattern.time=/^((0[0-9]|1[0-9]|2[0-3])\:(0[0-9]|[0-5][0-9]))$/;
pattern.blank=/./;
pattern.digit=/^\d+$/;
pattern.letter=/^\D+$/;
pattern.zipcode=/^\d{5,5}$/;
pattern.integer=/\d/;
pattern.currency=/((^\d{1,3}(,\d{3})*)|(^\d+)|(^\d{1,3}(\s\d{3})*))(\.\d{2,10})?$/;
pattern.currency1=/((^\-?\d{1,3}(,\d{3})*)|(^\-?\d+)|(^\-?\d{1,3}(\s\d{3})*))(\.\d{2,10})?$/;
pattern.nic=/^\d{6}-(0[1-9]|1[0-4])-\d{4}$/;
pattern.hmphoneareacode=/^([2-7]|8[1-9]|9)$/;
pattern.hmphone=/^\d{6,8}$/;
//pattern.mbphoneareacode=/^(01[1-4|6|7|9])$/;
pattern.mbphoneareacode=/^(01[0-9])$/;
pattern.mbphoneareacode1=/^(001[0-9])$/;
pattern.mbphone=/^\d{7,8}$/;
pattern.phoneareacode=/^([1-9]|1[0-9]|8[1-9])$/;
pattern.phone=/^\d{6,8}$/;
pattern.id=/^[A-Za-z]+$/;
pattern.charnum=/^[A-Za-z0-9]+$/;
pattern.number=/^[0-9]+$/;
pattern.alpnumeric=/^[A-Za-z0-9 ]+$/;
pattern.name=/^[A-Za-z@\/'\- )(]+$/;
pattern.comment=/^[^"><']+$/;
pattern.general=/^[^"><]+$/;
pattern.position=/^[A-Za-z@\/\-)(' ]+$/;
pattern.card = /^[A-Za-z. ]+$/;
pattern.embossname = /^[A-Za-z.\'\&\,\-\/ ]+$/;
pattern.url = /^[A-Za-z0-9.\/_@: ]+$/;
pattern.allareacode=/^([2-7]|8[1-9]|9|1[0-9])$/;
pattern.onusmerno=/^\d{10}$/;
/* for general param validation - added 22/01/05 by Jac */
pattern.cardno = /^((\d{4}\ ){3}\d{4})|(\d{3}\ (\d{4}\ ){3}\d{4})$/;
pattern.chqno = /^[A-Za-z0-9]{6}$/;		// also for apvcde
/* VER 1.2 [S] */
//pattern.expdt = /^(0[1-9]|1[0-2])\/\d{4,4}$/;
pattern.expdt = /^0|((0[1-9]|1[0-2])\/\d{4,4})$/;
pattern.expdt1 = /^00\/0000|((0[1-9]|1[0-2])\/\d{4,4})$/;
pattern.expdt2 = /^0|((0[1-9]|1[0-2])\/\d{2,2})$/;
/* VER 1.2 [E] */
pattern.prono = /^\d{7,8}$/;		// also for SlsSlpNo, DepNo
/* VER 1.2 [S] */
//pattern.bnslnk = /^(\d{4}\ ){3}\d{4}$/;
pattern.bnslnk = /^0|((\d{4}\ ){3}\d{4})$/;
/* VER 1.2 [E] */
pattern.slsofcde = /^[A-Za-z0-9]{5}$/;
pattern.ltrcde = /^[A-Za-z0-9]{4}$/;
pattern.stmtmsgcde = /^[A-Za-z0-9]{3}$/;
/* VER 1.2 [S] */
//pattern.merno = /^\d{10,15}$/;
pattern.merno = /^[A-Za-z0-9]{0,15}$/;
/* VER 1.2 [E] */pattern.trmid = /^[A-Za-z0-9]{8}$/;
pattern.arn = /^[A-Za-z0-9]{23}$/;
pattern.batchno = /^\d{4}$/;	//settlement batch no
pattern.stan = /^\d{6}$/; // also for TrcNo, terminal batch no
pattern.cbkref = /^[A-Za-z0-9]{10}$/;		// also for TcsRef
pattern.conno = /^\d{4}[A-Za-z0-9]{7}$/;
pattern.edno = /^[A-Za-z0-9]{13}$/;
/* end add general param */

var errmessage=new Object();
errmessage.email	=	"INVALID \'<fieldname>\'.\nVALID \'<fieldname>\' FORMAT IS xxnn@xxx.xxx";
errmessage.date = "INVALID \'<fieldname>\' FORMAT OR VALUE.\nVALID FORMAT SHOULD BE dd/mm/yyyy.";
errmessage.time = "INVALID \'<fieldname>\' FORMAT OR VALUE.\nVALID FORMAT SHOULD BE hh:mm.";
errmessage.blank	=	"\'<fieldname>\' MUST NOT BE BLANK.";
errmessage.digit	=	"\'<fieldname>\' ACCEPTS DIGITS/NUMBERS ONLY.\n PLEASE DO NOT ENTER \",\" OR \".\"";
errmessage.letter	=	"\'<fieldname>\' ACCEPTS LETTERS ONLY.";
errmessage.zipcode=	"INVALID \'<fieldname>\'. VALID \'<fieldname>\' FORMAT IS nnnnn.";
errmessage.integer=	"INVALID \'<fieldname>\' VALUE. IT SHOULD BE AN INTEGER.";
errmessage.currency=	"INVALID \'<fieldname>\' FORMAT/VALUE.";
errmessage.currency1=	"INVALID \'<fieldname>\' FORMAT/VALUE. IT SHOULD BE IN NUMERIC VALUE.";
errmessage.nic=	"INVALID \'<fieldname>\' FORMAT.";
errmessage.phoneareacode="INVALID \'<fieldname>\' FORMAT.";
errmessage.phone="INVALID \'<fieldname>\' FORMAT.";
errmessage.hmphoneareacode="INVALID \'<fieldname>\' FORMAT";
errmessage.hmphone="INVALID \'<fieldname>\' FORMAT.";
errmessage.mbphoneareacode="INVALID \'<fieldname>\' FORMAT.";
errmessage.mbphoneareacode1="INVALID \'<fieldname>\' FORMAT.";
errmessage.mbphone="INVALID \'<fieldname>\' FORMAT.";
errmessage.id="INVALID \'<fieldname>\'. VALID VALUES (A-Z, a-z).";
errmessage.charnum="INVALID \'<fieldname>\'. VALID VALUES (A-Z, a-z, 0-9).";
errmessage.name="INVALID \'<fieldname>\'. VALID VALUES (A-z, a-z, space, @, /, -, \').";
errmessage.number="INVALID \'<fieldname>\'. VALID VALUES (0-9).";
errmessage.alpnumeric="INVALID \'<fieldname>\'. VALID VALUES (A-Z, a-z, 0-9, space).";
errmessage.general="INVALID \'<fieldname>\' VALUES ( \" , > , < ).";
errmessage.comment="INVALID \'<fieldname>\' VALUES ( \" , > , < , \').";
errmessage.position="INVALID \'<fieldname>\'. VALID VALUES (A-Z, a-z, space, /, -, (, ))";
errmessage.card="INVALID \'<fieldname>\'. VALID VALUES (A-Z, a-z, space, . )";
errmessage.embossname="INVALID \'<fieldname>\'. VALID VALUES (A-Z, a-z, space, . \' \& \, \- \/)";
errmessage.url="INVALID \'<fieldname>\'. VALID VALUE (xxx@xxx.com).";
errmessage.allareacode="INVALID \'<fieldname>\'.";
errmessage.onusmerno="INVALID \'<fieldname>\'. IT SHOULD BE AN INTEGER(0-9) WITH ENTIRE LENGTH IS 10.";
/* fOR general param VALIDation - added 22/01/05 by Jac */
errmessage.cardno = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE INTEGER WITH LENGTH 16 OR 19.";
errmessage.chqno = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE ALPHANUMERIC WITH LENGTH 6.";
errmessage.expdt = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE mm/yyyy.";
errmessage.expdt1 = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE mm/yyyy.";
errmessage.expdt2 = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE mm/yy.";
errmessage.prono = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE INTEGER WITH LENGTH 7 OR 8.";
errmessage.bnslnk = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE INTEGER WITH LENGTH 16.";
errmessage.slsofcde = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE ALPHANUMERIC WITH LENGTH 5.";
errmessage.ltrcde = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE ALPHANUMERIC WITH LENGTH 4.";
errmessage.stmtmsgcde = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE ALPHANUMERIC WITH LENGTH 3.";
errmessage.merno = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE INTEGER WITH LENGTH 10 OR 15.";
errmessage.trmid = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE ALPHANUMERIC WITH LENGTH 8.";
errmessage.arn = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE ALPHANUMERIC WITH LENGTH 23.";
errmessage.batchno = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE INTEGER WITH LENGTH 4.";
errmessage.stan = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE INTEGER WITH LENGTH 6.";
errmessage.cbkref = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE ALPHANUMERIC WITH LENGTH 10.";
errmessage.conno = "INVALID \'<fieldname>\'. FORMAT SHOULD BE 9999xxxxxxx.";
errmessage.edno = "INVALID \'<fieldname>\'. VALID \'<fieldname>\' SHOULD BE ALPHANUMERIC WITH LENGTH 13.";
/* end add general param */
document.oncontextmenu = contextmenu;
function contextmenu(){
	//return false;
}

var hook = true;
var alertMessage = 'We are currently processing your transaction...\n\nThe transaction will be incomplete if you click on Back, Refresh or Closing the browser window.';

window.onbeforeunload = function (e)
{
	var e = e || window.event;

	if (hook)
	{
		if (e)
		{
			// For IE and Firefox
			e.returnValue = alertMessage;
		}
		else
		{
			//For Safari
			return alertMessage;
		}
	}
};

function unhook()
{
	hook = false;
}

/* for general param validation - added 22/01/05 by Jac */
function isParamValid(value, validator, paramName){
	var reg=null;
	reg=pattern[validator];

/*	if (value=="")
		return "";	*/
	if (reg==null) {
/* VER 1.2 [S] */
/*		showErrMsg(validator, paramName);
		return false;
*/		return "";
/* VER 1.2 [E] */
	}
	if (reg.test(Trim(value)) || value=="")
		return value;
	else {
/* VER 1.2 [S] */
/*		if(validator=="blank") {
			 alert(errmessage[validator].replace(/\<fieldname>/g, paramName));
		} else {
			 showErrMsg(validator, paramName);
		}
		return false;
*/		return "";
/* VER 1.2 [E] */
	}
}
function showErrMsg(validator, fieldName){
	if (validator!=null)
		alert(errmessage[validator].replace(/\<fieldname>/g, fieldName));
}
/* end validate general param */

function isValid(obj,validator){
	var reg=null;
	reg=pattern[validator];
	if (reg==null) {showInputError(obj); obj.focus();return false;}
	if (reg.test(Trim(obj.value))) return true;
	else{
		if(validator=="blank")
		   alert(errmessage[validator].replace(/\<fieldname>/g,obj.fieldName));
		else
		   showInputError(obj);
		obj.focus();
		return false;
	}
}


function validate(obj){
	var validator=obj.validator;
	if (validator==null) return true;
	return isValid(obj,validator);
}

function isDate(obj){
	var date=obj.value;
	var spr='/';

	if(date == '00/00/0000'){
		return false;
	}
	
	if(date.substring(2,3)!=spr) return false;
	else if(date.substring(5,6)!=spr) return false;	
	
	var day=date.substring(0,2);
	var month=date.substring(3,5);
	var year=date.substring(6,date.length);
	if(year.length < 4){
		return false;
	}
	if(parseInt(year,10) < 1900){
		return false;
	}

	var isLeapYear=false;
	if ((year % 4)==0) isLeapYear=true;

	var montharray=new Array();
	montharray[0]=31;
	if (isLeapYear){
		montharray[1]=29;
	}else{
		montharray[1]=28;
	}
	montharray[2]=31;
	montharray[3]=30;
	montharray[4]=31;
	montharray[5]=30;
	montharray[6]=31;
	montharray[7]=31;
	montharray[8]=30;
	montharray[9]=31;
	montharray[10]=30;
	montharray[11]=31;

	if(parseInt(month,10) < 1 || parseInt(month,10) > 12){
		return false;
	}else if (day>montharray[month-1] || day<=0){
		return false;
	}
	return true;
}

function dateAutoComplete(obj){
	if (obj.autocomplete!=null){
		var str=obj.value;
		if (str.length==2 || str.length==5) str+="/";
		obj.value=str;
	 }
}

function icAutoComplete(obj){
/*    not applicable for non-malaysia country
	if (obj.autocomplete!=null){
		var str=obj.value;
		str = str.replace(/\-/g,'');
		if(str.length>7){
			str=(str).substring(0,6)+"-"
			+(str).substring(6,8)+"-"+
				(str).substring(8,(str).length);
		}else if(str.length>5){
			str=(str).substring(0,6)+"-"
			+(str).substring(6,(str).length);
		}
		obj.value=str;
	 }
*/
}

function isNumberInRange(obj,min,max){
	if (isValid(obj,'digit') && (eval(obj.value)>=min && eval(obj.value)<=max))
			return true;
	alert("INVALID RANGE OF '"+obj.fieldName+ "'. VALID RANGE IS "+min+ " TO "+max+".");
	obj.focus();
	return false;
}

function showInputError(o){
	if (o.validator!=null)
	alert(errmessage[o.validator].replace(/\<fieldname>/g,o.fieldName));
}

function isBlank(obj){
	return !isValid(obj,'blank');
}

function check(obj){

	if (obj.value=='') return true;
	if (obj.validator==null) return true;
	if(obj.readOnly == true) return true;

	var validator=obj.validator;
	if (validator=='date'){
		var isok=isDate(obj);
            if(!isok){
               showInputError(obj);
               obj.focus();
            }
		return isok;
	}else
	if (validator=='numberinrange'){
		var min=obj.min;
		var max=obj.max;
		if (min==null || max==null) {alert("MINIMUM OR MAXIMUM NOT DEFINED."); obj.focus(); return false;}
		return isNumberInRange(obj,min,max);
	}else
		return validate(obj);


}

function closeWindow(){
    top.window.opener = top;
    top.window.open('','_parent','');
    top.window.close();
}

function checkAll(f){
	for (var x=0;x<f.elements.length;x++){
		var obj=f.elements[x];
		if (obj.type=='text') {
			if (obj.canblank!=null && obj.canblank=='false' && obj.value=='') {
				//alert("PLEASE FILL IN THIS INPUT.");
				alert(errmessage["blank"].replace(/\<fieldname>/g, obj.fieldName));
				obj.focus();
				return false;
			}else
			if (obj.value!='' && !check(obj)){
				obj.focus();
				return false;
			}
		}
	}

	return true;

}

function validRange(dtStrFrom, dtStrTo){

    var posmDFr1=dtStrFrom.indexOf(dtCh)
    var posmDFr2=dtStrFrom.indexOf(dtCh,posmDFr1+1)
    var strYearmDFr=dtStrFrom.substring(0,posmDFr1)
    var strMthmDFr=dtStrFrom.substring(posmDFr1+1,posmDFr2)
    var strDaymDFr=dtStrFrom.substring(posmDFr2+1)
    var strYrmDFr=strYearmDFr

    var posmDTo1=dtStrTo.indexOf(dtCh)
    var posmDTo2=dtStrTo.indexOf(dtCh,posmDTo1+1)
    var strYearmDTo=dtStrTo.substring(0,posmDTo1)
    var strMthmDTo=dtStrTo.substring(posmDTo1+1,posmDTo2)
    var strDaymDTo=dtStrTo.substring(posmDTo2+1)
    var strYrmDTo=strYearmDTo

	for (var i = 1; i <= 3; i++) {
        if (strYrmDFr.charAt(0)=="0" && strYrmDFr.length>1) strYrmDFr=strYrmDFr.substring(1);
    }
    if (strMthmDFr.charAt(0)=="0" && strMthmDFr.length>1) strMthmDFr=strMthmDFr.substring(1);
	if (strDaymDFr.charAt(0)=="0" && strDaymDFr.length>1) strDaymDFr=strDaymDFr.substring(1);

	for (var i = 1; i <= 3; i++) {
        if (strYrmDTo.charAt(0)=="0" && strYrmDTo.length>1) strYrmDTo=strYrmDTo.substring(1);
    }
    if (strMthmDTo.charAt(0)=="0" && strMthmDTo.length>1) strMthmDTo=strMthmDTo.substring(1);
    if (strDaymDTo.charAt(0)=="0" && strDaymDTo.length>1) strDaymDTo=strDaymDTo.substring(1);

    daymDFr=parseInt(strDaymDFr);
    mthmDFr=parseInt(strMthmDFr);
    yearmDFr=parseInt(strYrmDFr);

    daymDTo=parseInt(strDaymDTo);
    mthmDTo=parseInt(strMthmDTo);
    yearmDTo=parseInt(strYrmDTo);

    if (yearmDTo > yearmDFr)
        return true;
    else if ((yearmDTo == yearmDFr) && (mthmDTo > mthmDFr))
              return true;
    else if ((yearmDTo == yearmDFr) && (mthmDTo == mthmDFr) && (daymDTo > daymDFr))
              return true;
    else if ((yearmDTo == yearmDFr) && (mthmDTo == mthmDFr) && (daymDTo == daymDFr))
              return true;
    else  return false;
}

function checkLen(obj,len){
    if(obj.value.length != len){
        alert("'"+obj.fieldName+ "' LENGTH MUST BE " +len+".");
	obj.focus();
        return false;
    }

    return true;
}

function checkCrdNo(obj){
	var val = obj.value;
	val = mergeCrdNo(val);
    if(val.length == 0)
        return true;

    if(val.length != 16 && val.length != 19){
        alert("'"+obj.fieldName+ "' MUST BE EITHER 16 OR 19 DIGITS.");
	obj.focus();
        return false;
    }

    return true;
}

function Trim(str){
    if(str.length < 1){
        return"";
    }

    str = RTrim(str);
    str = LTrim(str);

    if(str==""){
        return "";
    }else{
        return str;
    }
}

function RTrim(str){
    var w_space = String.fromCharCode(32);
    var v_length = str.length;
    var strTemp = "";

    if(v_length < 0){
        return"";
    }

    var iTemp = v_length -1;

    while(iTemp > -1){
        if(str.charAt(iTemp) == w_space){
        }else{
            strTemp = str.substring(0,iTemp +1);
            break;
        }
        iTemp = iTemp-1;
    }
    return strTemp;
}

function LTrim(str){
    var w_space = String.fromCharCode(32);

    if(v_length < 1){
        return"";
    }

    var v_length = str.length;
    var strTemp = "";

    var iTemp = 0;

    while(iTemp < v_length){
        if(str.charAt(iTemp) == w_space){
        }else{
            strTemp = str.substring(iTemp,v_length);
            break;
        }
        iTemp = iTemp + 1;
    }
    return strTemp;
}

function mergeCrdNo(str){
    return Trim(str.replace(/\ /g,''));
}

function mergeIC(str){
    return Trim(str.replace(/\-/g,''));
}

function splitCrdNo(str){
    var crdNo = mergeCrdNo(str);
    var tmpCrdNo = "";

    while(crdNo.length != 0){
         tmpCrdNo = right(crdNo, 4) + " " + tmpCrdNo;
	 if (crdNo.length < 4)
	     crdNo = "";
         else
             crdNo = left(crdNo, crdNo.length - 4);
    }

    return Trim(tmpCrdNo);
}

function left(str, n){
	if (n <= 0)
	    return "";
	else if (n > String(str).length)
	    return str;
	else
	    return String(str).substring(0,n);
}

function right(str, n){
    if (n <= 0)
       return "";
    else if (n > String(str).length)
       return str;
    else {
       var iLen = String(str).length;
       return String(str).substring(iLen, iLen - n);
    }
}

function getCboField(cboTxt){
    var position = cboTxt.indexOf('-');

    if (position != -1)
        return "" + Trim(left(cboTxt, position)).toUpperCase();

    return "" + Trim(cboTxt).toUpperCase();

}

function getCboDesc(cboTxt){
    var position = cboTxt.indexOf('-');

    if (position != -1)
        return "" + Trim(right(cboTxt,cboTxt.length - position - 2)).toUpperCase();

    return "" + Trim(cboTxt).toUpperCase();

}

function convTmFromHst(tm){
    return left(tm, 2) + ":" + tm.substring(2, 4) + ":" + tm.substring(4, 6);

}

function isZeroes(str){
    var totZeroes=0;
    for(var i=0; i< Trim(str).length; i++){
        if (str.charAt(i) == '0')
            totZeroes ++;
    }

    if(totZeroes == Trim(str).length) return true;

    return false;

    return pattern.allzeroes.test(str);
}


/*should be put in onkeydown and onblur event*/
function formatCardNo(obj){
	var key = window.event.keyCode;
	var cardNo;
	var len = obj.value.length;

	if(key == 46 || //delete key is pressed
		key == 8 || //backspace
		key == 37 || //<-
		key == 39 || //->
		key == 36 || //Home key
		key == 35 	//End
		){
		return;
	}else{
		cardNo	= splitCrdNo(obj.value);
		obj.value = cardNo;
	}
}

/*should be put in onkeydown.control the decimal point*/

function keyDownDecimalPnt1(obj,maxLen){
	var key = window.event.keyCode;
//	obj.value = Trim(obj.value.replace(/\,/g,''));

	if(obj.value.length == maxLen){
			if(key == 190 || key == 110){
				obj.maxLength = obj.value.length + 3;
				return;
			}else{
				if(obj.value.indexOf(".") == -1) obj.maxLength = maxLen;

				window.event.keyCode = '';
				return;
			}
	}

	if (!window.event.shiftKey && !window.event.ctrlKey && !window.event.altKey) {
		if(key == 190 || key == 110){//if it is a dot
			if(obj.value.indexOf(".") == -1){// if dot is not found in existing obj.value
				obj.maxLength = obj.value.length + 3;
				return;
			}else {
				window.event.keyCode = 46 ;
				return;
			}
		}else if(key >= 96 && key<= 105){ // 0-9
			if(obj.value.indexOf(".") == -1){
				obj.maxLength = maxLen; // the original maxlength
				return;
			}
		}else if(key == 8){//delete
			if(obj.value.indexOf(".") == -1){
				obj.maxLength = maxLen;
				return;
			}
		}
	}
}

/*should be put in onkeydown.control the decimal point*/
function keyDownDecimalPnt(obj,maxLen){
	var key = window.event.keyCode;
	obj.value = Trim(obj.value.replace(/\,/g,''));
	if(obj.value.length == maxLen){
			if(key == 190 || key == 110){
				obj.maxLength = obj.value.length + 3;
				return;
			}else{
				if(obj.value.indexOf(".") == -1) obj.maxLength = maxLen;

				window.event.keyCode = '';
				return;
			}
	}

	if (!window.event.shiftKey && !window.event.ctrlKey && !window.event.altKey) {
		if(key == 190 || key == 110){//if it is a dot
			if(obj.value.indexOf(".") == -1){// if dot is not found in existing obj.value
				obj.maxLength = obj.value.length + 3;
				return;
			}else {
				window.event.keyCode = 46 ;
				return;
			}
		}else if(key >= 96 && key<= 105){ // 0-9
			if(obj.value.indexOf(".") == -1){
				obj.maxLength = maxLen; // the original maxlength
				return;
			}
		}else if(key == 8){//delete
			if(obj.value.indexOf(".") == -1){
				obj.maxLength = maxLen;
				return;
			}
		}
	}
}

function KeyDownMoneyInput(obj,maxLen){
	var key = window.event.keyCode;
	if (key >= 96 && key <= 105) key = chkInputKey(key);
	
	if (key == 110 || key == 190) {
		if (obj.value.length == 0) window.event.keyCode = 46;
		if (obj.value.indexOf(".")== -1){
			for (var i=1;i<=maxLen;i++){
				if (obj.value.length == i) {
					obj.maxLength = (i+3);
					break;
				}
			}
		}
		else {
			window.event.keyCode = 46;
		}
	}
	if (key >= 48 && key <= 57) {
		if (obj.value.indexOf(".")==-1) {
			if (obj.value.length >= maxLen) window.event.keyCode = 46;
			else if (obj.value.length < maxLen) obj.maxLength = maxLen;
		}
	}
}

function chkInputKey(key) {
	//This function will change the keyCode from 96 - 105 which is (0-9) to 48 - 57 which is also (0-9)
	for (var i=96;i<=105;i++) {
		if (key == i) {
			key -= 48;
			break;
		}
	}
	return key;
}

/** to be put in on key down event **/
function formatDate(obj,type){
	var key = window.event.keyCode;
	var value = obj.value;
	var tmpValue = "";

	if(key == 46 || //delete key is pressed
		key == 8 || //backspace
		key == 37 || //<-
		key == 39 || //->
		key == 36 || //Home key
		key == 35 	//End
		){
		return;
	}else if (!window.event.shiftKey && !window.event.ctrlKey && !window.event.altKey) {
		if((key > 47 && key < 58) ||  (key > 95 && key < 106)){
			value =	value.replace(/\//,'');
			if(type == "2"){ // format date in mm/yyyy format
				if(value.length == 2){
					obj.value = value + "/";
				}
			}else{ // format date in dd/mm/yyyy format
				if(value.length == 2){
					obj.value = value + "/";
				}else if(value.length == 4){
					obj.value = left(value,2) + "/" + right(value,2) + "/";
				}
			}
		}else if(key == 191 || key == 111){
				window.event.keyCode = 46;
		}
	}
}

function formatTimeObj(obj){
	var key = window.event.keyCode;
	var value = obj.value;

	if(key == 46 || //delete key is pressed
		key == 8 || //backspace
		key == 37 || //<-
		key == 39 || //->
		key == 36 || //Home key
		key == 35 	//End
		){
		return;
	}else if (!window.event.shiftKey && !window.event.ctrlKey && !window.event.altKey) {
		if((key > 47 && key < 58) ||  (key > 95 && key < 106)){
			//value =	value.replace(/\//,'');
			// format date in hh:ss format
				if(value.length == 2){
					obj.value = value + ":";
				}else if(value.length == 5){
					obj.value = left(value,2) + ":" + right(value,2);
				}
		}else if(key == 191 || key == 111){
				window.event.keyCode = 46;
		}
	}
}

function formatTime(orgTime){
	var newTime;
	var newTime2;
	if(orgTime == "" || orgTime == null){
		newTime2 = "";
	}else{
		if (orgTime.length==4) newTime=orgTime;
		else if (orgTime.length==3) newTime=("0").concat(orgTime);
		else if (orgTime.length==2) newTime=("00").concat(orgTime);
		else if (orgTime.length==1) newTime=("000").concat(orgTime);
		newTime2=newTime.substring(0,2).concat(":").concat(newTime.substring(2,4));
	}
	return newTime2;
}

function checkInput(){
	var elem = document.getElementsByTagName("input");
	var elemLen = elem.length;
	var tmpStr;
	var cnt = 1;
	var errorMsg = "";

	for(var i=0;i<elemLen;i++){
		tmpStr = elem.item(i).checkInput;

		if(tmpStr != null){
			if(tmpStr.indexOf("blank") != -1){

				if(Trim(elem.item(i).value) == ""){
					alert(elem.item(i).fieldName+" cannot be blank.\n");
					elem.item(i).focus();
		            return;
				}
			}
			if(tmpStr.indexOf("zero") != -1){
				if(parseInt(elem.item(i).value) == 0){

					alert(elem.item(i).fieldName+" cannot be zero.\n");
					elem.item(i).focus();
		            return;
				}else if(isNaN(parseInt(elem.item(i).value))){
					alert(elem.item(i).fieldName+" must be number.\n");
					elem.item(i).focus();
		            return;
				}
			}

		}
	}


	return true;
}

function checkInput(ind){
	var elem = document.getElementsByTagName("input");
	var selectObj = document.getElementsByTagName("select");
	var tmpStr;

	for(var i=0;i<elem.length;i++){
		tmpStr = elem.item(i).checkInput;
        mandfld = elem.item(i).mandFld;
        
      if(mandfld !=null && (mandfld == ind || mandfld == '*')){
	     if(tmpStr != null){
			if(tmpStr.indexOf("blank") != -1){

				if(Trim(elem.item(i).value) == ""){
					alert(elem.item(i).fieldName+" cannot be blank.\n");
					elem.item(i).focus();
		            return;
				}
			}
			if(tmpStr.indexOf("zero") != -1){
				if(parseInt(elem.item(i).value) == 0){

					alert(elem.item(i).fieldName+" cannot be zero.\n");
					elem.item(i).focus();
		            return;
				}else if(isNaN(parseInt(elem.item(i).value))){
					alert(elem.item(i).fieldName+" must be number.\n");
					elem.item(i).focus();
		            return;
				}
			}
		}
	  }	
	}
	
	tmpStr="";
	mandfld="";
	
	for(var i=0;i<selectObj.length;i++){
		tmpStr = selectObj.item(i).checkInput;
        mandfld = selectObj.item(i).mandFld;
        
      if(mandfld !=null && (mandfld == ind || mandfld == '*')){
	     if(tmpStr != null){
			if(tmpStr.indexOf("blank") != -1){

				if(Trim(selectObj.item(i).value) == ""){
					alert(selectObj.item(i).fieldName+" cannot be blank.\n");
					selectObj.item(i).focus();
		            return;
				}
			}
			if(tmpStr.indexOf("zero") != -1){
				if(parseInt(selectObj.item(i).value) == 0){

					alert(selectObj.item(i).fieldName+" cannot be zero.\n");
					selectObj.item(i).focus();
		            return;
				}else if(isNaN(parseInt(selectObj.item(i).value))){
					alert(selectObj.item(i).fieldName+" must be number.\n");
					selectObj.item(i).focus();
		            return;
				}
			}
		}
	  }	
	}	
	return true;
}

function checkMand(ind){
	var inputObj = document.getElementsByTagName("input");
	var selectObj = document.getElementsByTagName("select");
	var tmpStr;

	for(var i=0;i<inputObj.length;i++){
		tmpStr = inputObj.item(i).mandFld;
		if(tmpStr != null && (tmpStr == ind || tmpStr == '*')){
		   inputObj.item(i).className = 'portlet-form-input-fieldHLight';
		} else if (tmpStr != null && tmpStr != ind ) {
			inputObj.item(i).className = 'portlet-form-input-field';
		}
	}
	for(var i=0;i<selectObj.length;i++){
		tmpStr = selectObj.item(i).mandFld;
		if(tmpStr != null && (tmpStr == ind || tmpStr == '*')){
		   selectObj.item(i).className = 'portlet-form-input-fieldHLight';
		} else if (tmpStr != null && tmpStr != ind ) {
			selectObj.item(i).className = 'portlet-form-input-field';
		}
	}	
	return true;
}


function compareDt(srtDt,endDt){
	var tmpYr;
	var tmpMon;
	var tmpDay;

	tmpYr = right(srtDt,4);
	tmpMon = srtDt.substring(3,5);
	tmpDay = left(srtDt,2);
/*Ver 1.3 [S]*/
	var srtDtObj = new Date();
	srtDtObj.setHours(0);
	srtDtObj.setMinutes(0);
	srtDtObj.setSeconds(0);
	srtDtObj.setFullYear(parseInt(tmpYr,10));
	srtDtObj.setMonth(parseInt(tmpMon,10)-1);
	srtDtObj.setDate(parseInt(tmpDay,10));
/*Ver 1.3 [E]*/
	tmpYr = right(endDt,4);
	tmpMon = endDt.substring(3,5);
	tmpDay = left(endDt,2);
/*Ver 1.3 [S]*/
	var endDtObj = new Date();
	endDtObj.setHours(0);
	endDtObj.setMinutes(0);
	endDtObj.setSeconds(0);
	endDtObj.setFullYear(parseInt(tmpYr,10));
	endDtObj.setMonth(parseInt(tmpMon,10)-1);
	endDtObj.setDate(parseInt(tmpDay,10));
/*Ver 1.3 [E]*/
	return	endDtObj - srtDtObj;
}

function compareDt(srtDt,endDt){  //yyyyMMdd
	var tmpYr;
	var tmpMon;
	var tmpDay;

	tmpYr = right(srtDt,4);
	tmpMon = srtDt.substring(3,5);
	tmpDay = left(srtDt,2);
/*Ver 1.3 [S]*/
	var srtDtObj = new Date();
	srtDtObj.setHours(0);
	srtDtObj.setMinutes(0);
	srtDtObj.setSeconds(0);
	srtDtObj.setFullYear(parseInt(tmpYr,10));
	srtDtObj.setMonth(parseInt(tmpMon,10)-1);
	srtDtObj.setDate(parseInt(tmpDay,10));
/*Ver 1.3 [E]*/
	tmpYr = right(endDt,4);
	tmpMon = endDt.substring(3,5);
	tmpDay = left(endDt,2);
/*Ver 1.3 [S]*/
	var endDtObj = new Date();
	endDtObj.setHours(0);
	endDtObj.setMinutes(0);
	endDtObj.setSeconds(0);
	endDtObj.setFullYear(parseInt(tmpYr,10));
	endDtObj.setMonth(parseInt(tmpMon,10)-1);
	endDtObj.setDate(parseInt(tmpDay,10));
/*Ver 1.3 [E]*/
	return	endDtObj - srtDtObj;
}

function compareDtTm(srtDt,endDt){  //yyyyMMddHHmmSS
	var tmpYr;
	var tmpMon;
	var tmpDay;
	var tmpHr;
	var tmpMin;
	var tmpSecs;        

	tmpYr = right(srtDt,4);
	tmpMon = srtDt.substring(3,5);
        tmpDay = srtDt.substring(5,7);
        tmpHr = srtDt.substring(7,9);
        tmpMin = srtDt.substring(9,11);
	tmpSecs = left(srtDt,2);

	var srtDtObj = new Date();
	srtDtObj.setHours(tmpHr);
	srtDtObj.setMinutes(tmpMin);
	srtDtObj.setSeconds(tmpSecs);
	srtDtObj.setFullYear(parseInt(tmpYr,10));
	srtDtObj.setMonth(parseInt(tmpMon,10)-1);
	srtDtObj.setDate(parseInt(tmpDay,10));

	tmpYr = right(endDt,4);
	tmpMon = endDt.substring(3,5);
        tmpDay = endDt.substring(5,7);
        tmpHr = endDt.substring(7,9);
        tmpMin = endDt.substring(9,11);
	tmpSecs = left(endDt,2);

	var endDtObj = new Date();
	endDtObj.setHours(tmpHr);
	endDtObj.setMinutes(tmpMin);
	endDtObj.setSeconds(tmpSecs);
	endDtObj.setFullYear(parseInt(tmpYr,10));
	endDtObj.setMonth(parseInt(tmpMon,10)-1);
	endDtObj.setDate(parseInt(tmpDay,10));

	return	endDtObj - srtDtObj;
}

function mergeDate(value){
	value = Trim(value.replace(/\//,''));
	return Trim(value.replace(/\//,''));
}

function formatDateYMD(value){ //format date to yyyymmdd
	return Trim(right(value,4)) + Trim(value.substring(3,5)) + Trim(left(value,2));
}

function formatOnUsMerNo(inObj,outObj) {
    var reg=pattern["onusmerno"];

    if (reg==null) return false;
    if (reg.test(Trim(inObj.value))){
        outObj.value="00000"+inObj.value;
        return true;
    }else{
		if(inObj.fieldName == "undefined"){
			alert("INVALID MERCHANT NO. IT SHOULD BE AN INTEGER WITH ENTIRE LENGTH IS 10.");
		}else{
			alert("INVALID '"+ inObj.fieldName +"'. IT SHOULD BE AN INTEGER WITH ENTIRE LENGTH IS 10.");
		}
        return false;
    }
}

function isChecked(obj){

	if(obj != null){
		var len = obj.length;
		if(len == null){// len will be null if the row is only one
			if(obj.checked){
				return true;
			}
		}else{
		    for(var i=0;i<len;i++){
				if(obj[i].checked){
					return true;
				}
			}
		}
		//alert("PLEASE SELECT A RECORD.");
	}

	return false;
}

function getCurrDt(type){
    var date = new Date();
    var d  = date.getDate();
    var day = (d < 10) ? '0' + d : d;
    var m = date.getMonth() + 1;
    var month = (m < 10) ? '0' + m : m;
    var yy = date.getYear();
    var year = (yy < 1000) ? yy + 1900 : yy;
    var hrs = date.getHours();
    var mins = date.getMinutes();
    var sec = date.getSeconds();



    if(type.toUpperCase() == "DDMMYYYY"){
    	return day+"/"+month+"/"+year;
    }else if(type.toUpperCase() == "MMYYYY"){
	    return month+"/"+year;
    }else if(type.toUpperCase() == "DDMMYYYYHHMM"){
	    return day+"/"+month+"/"+year+" "+hrs+":"+mins;
    }else if(type.toUpperCase() == "HHMM"){
	    return hrs+":"+mins;
	}else{
	    alert("INVALID DATA TYPE.");
	    return;
    }

}

function padStr(str, padChar, lgth, appendFront){
    var padStr = "";
    for(var i=0;i<lgth-str.length;i++){
        padStr += padChar;
    }
    if(appendFront){
        return padStr + str;
    }
    return str + padStr;
}

function disableObj(obj){
    obj.readOnly = true;
    obj.className = "portlet-form-input-fieldDsbl";
}

function enableObj(obj){
    obj.readOnly = false;
    obj.className = "portlet-form-input-field";
}

function resetForm(clearAll){
	var f = document.forms[0];
	var inputObj = document.getElementsByTagName("INPUT");
	var selectObj = document.getElementsByTagName("SELECT");
	var txtAreaObj = document.getElementsByTagName("TEXTAREA");

	if(clearAll == true){
        f.reset();
		for(var i=0;i<inputObj.length;i++){
			if(inputObj.item(i).type.toLowerCase() == "text"){
				inputObj.item(i).value="";
			}
		}
		for(var i=0;i<selectObj.length;i++){
		    selectObj.item(i).options[0].selected = true;
		}
		for(var i=0;i<txtAreaObj.length;i++){
			if(txtAreaObj.item(i).readOnly == false){
				txtAreaObj.item(i).innerText="";
			}
		}
	}else if(clearAll == false){
		for(var i=0;i<inputObj.length;i++){
			if(inputObj.item(i).type.toLowerCase() == "text"){
				if(inputObj.item(i).readOnly == false && inputObj.item(i).disabled == false){
					inputObj.item(i).value="";
				}
			}
		}
		
		for(var i=0;i<txtAreaObj.length;i++){
			if(txtAreaObj.item(i).readOnly == false){
				txtAreaObj.item(i).value="";
			}
		}

	}else if(clearAll ==  null){
		f.reset();
	}
    var treeObj = document.getElementById("sectLOCTree");
	if(treeObj!= null){
        treeObj.innerHTML = "";
	}

	var tableObj = document.getElementsByTagName("TABLE");
	for(var i=0;i<tableObj.length;i++){
		if(tableObj.item(i).className.toLowerCase() == "grid"){
			var gridObj = tableObj.item(i);
			for(var j=gridObj.rows.length-1;j>0;j--){
				gridObj.deleteRow(j);
			}
			//Modified by cyway for grid-rdbms.jsp usage
			for(var j=gridObj.rows[0].cells.length-1;j>0;j--){
				gridObj.rows(0).cells(j).onclick=function(){};
				gridObj.rows(0).cells(j).onmouseover=function(){};
				if(gridObj.rows(0).cells(j).innerHTML.indexOf("<IMG")!=-1){
					gridObj.rows(0).cells(j).innerHTML=gridObj.rows(0).cells(j).innerText;
				}
			}
		}
		//Hard code - no more records & more from server
		if(tableObj.item(i).className.toLowerCase() == "paging"){
			tableObj.item(i).rows(0).cells(0).innerHTML = "<B style=\"color: #000000;\">No More Records<B>";
			tableObj.item(i).rows(0).cells(1).innerHTML = "<B style=\"color: #000000;\">More From Server<B>";
		}
		//Modified by cyway for grid-rdbms.jsp usage
		if(tableObj.item(i).className.toLowerCase() == "prettypaging"){
			var gridObj = tableObj.item(i);
			if(gridObj.rows.length!=0) gridObj.deleteRow(0);
		}
	}
	autoSetFocus();
}

function autoSetFocus(){
	var f=document.forms[0];
	var smallestIndex=100;
	var inputObj = document.getElementsByTagName("INPUT");
	for(var i=0; i<inputObj.length; i++){		
		if(inputObj.item(i).tabIndex <= smallestIndex && inputObj.item(i).tabIndex>0) {			
			smallestIndex=inputObj.item(i).tabIndex+1;
			if(inputObj.item(i).type.toLowerCase() == "text"){
				if(inputObj.item(i).readOnly == false && inputObj.item(i).disabled == false){
					inputObj.item(i).focus();
					break;
				}
			}
		}
		//if(f.elements[i].tabIndex==1) f.elements[i].focus();
	}
	//alert("SMALLEST INDEX : "+smallestIndex);
}

function autoTab(obj) {
	var f = document.forms[0];
	var curTab = obj.tabIndex;
	var nextTab = 99999;
	var isFound = false;
	var keyPressed = window.event.keyCode;
	var filter = [9,16,35,36,37,38,39,40];

	if(containsElement(filter,keyPressed)){
		return;
	}

	function containsElement(arr, ele) {
		var found = false, index = 0;
		while(!found && index < arr.length)
		if(arr[index] == ele)
			found = true;
		else
			index++;
		return found;
	}

	if(obj.value.length == obj.maxLength){
		for(var i=0;i<f.length;i++){
			if(f.item(i).tabIndex > curTab &&  f.item(i).tabIndex < nextTab){
			   if (f.item(i).type.toLowerCase() != "text"){
				  nextTab = f.item(i).tabIndex;
		       }else if(f.item(i).type.toLowerCase() == "text" &&
		                f.item(i).readOnly==false){
				  nextTab = f.item(i).tabIndex;
		       }
			}
		}
		for(var i=0;i<f.length;i++){
			if(f.item(i).tabIndex == nextTab){
				if (f.item(i).type.toLowerCase() == "text"){
				    f.item(i).select();
			    } else {
				    f.item(i).focus();
			    }
				return;
			}
		}
	}
}


function defFunc(funcNm){
	var f = document.forms[0];
	var key = window.event.keyCode;
	if(window.event.srcElement.nodeName.toUpperCase() == "INPUT"){
		if(window.event.srcElement.type.toUpperCase()=="BUTTON"){
			return;
		}
	}
	if(key == 13){
		eval(funcNm);
	}
}

function formatICNo(obj)
{
/* not applicable for non malaysia country
  var str = obj.value;
  var key;
  if(window.event != null){
	  key = window.event.keyCode;
  }
  if(key != undefined && (key == 46 || //delete key is pressed
			key == 8 || //backspace
			key == 37 || //<-
			key == 39 || //->
			key == 36 || //Home key
			key == 35 //End
			)){
		return;
	}else{
		str=str.replace(/[^0-9]/g,'');
	  if(str.length>=6) {
	    str=str.substring(0,6)+'-'+str.substring(6,str.length);
	  }
	  if(str.length>=9) {
	    str=str.substring(0,9)+'-'+str.substring(9,str.length);
	  }
	  if(str.length>14) {
	    str=str.substring(0,14);
	  }
	  obj.value=str;
	}
        */
}

function checkNewIcNo(obj){	
    /* not applicable for non malaysia country
	var icNum = obj.value;
	var icDay = icNum.substring(4,6);
	var icMonth = icNum.substring(2,4);
	var icYear = "19"+icNum.substring(0,2);
	
	if(icNum.length!=14){
		alert('INVALID IC NO. IT SHOULD BE IN LENGTH OF 14.');
		obj.focus();
		return;
	}
	if(icMonth>13||icMonth<0){	
		alert('INVALID MONTH FORMAT.');
		obj.focus();
		return;
	}   
	if(icNum.substring(7,9)>14||icNum.substring(7,9)<0){
		alert('INVALID IC FORMAT.');
		obj.focus();
		return;
	}
	
	var monTotalDays = new Array (12);
	monTotalDays[0]="31";
	monTotalDays[1]="28";
	monTotalDays[2]="31";
	monTotalDays[3]="30";
	monTotalDays[4]="31";
	monTotalDays[5]="30";
	monTotalDays[6]="31";
	monTotalDays[7]="31";
	monTotalDays[8]="30";
	monTotalDays[9]="31";
	monTotalDays[10]="30";
	monTotalDays[11]="31";
	icYear=parseInt(icYear);
	if (icYear%4==0) {
		monTotalDays[1]="29";
	}
		
	if (icDay> monTotalDays[icMonth-1]) {
		alert('INVALID DAY FORMAT.');
		obj.focus();
		return;		
	}
        */
	return true;
}

function formatField (obj){
    var L = obj.maxLength - obj.value.length;
    var i;

    if (!isNaN(obj.value)){
    	for(i = 0; i < L; i++){
        	obj.value = "0" + obj.value;
    	}
    }
}

function mia2dpd (obj){
	var mia = obj;
	var result;

	switch(mia){
		case "0" : result="Current"; break;
		case "1" : result="0 - 29"; break;
		case "2" : result="30 - 59"; break;
		case "3" : result="60 - 89"; break;
		case "4" : result="90 - 119"; break;
		case "5" : result="120 - 149";break;
		case "6" : result="150 - 179";break;
		case "7" : result="180 - 209";break;
		case "8" : result="210 - 239";break;
		case "9" : result="240 - 269";break;
		case "10" : result="270 - 299";break;
		case "11" : result="300 - 329";break;
		case "12" : result="330 - 359";break;
		case "13" : result="360 - 389";break;
		case "14" : result="390 - 419";break;
		case "15" : result="420 - 449";break;
		case "16" : result="450 - 479";break;
		case "17" : result="480 - 509";break;
		case "18" : result="510 - 539";break;
		case "19" : result="540 - 569";break;
		case "20" : result="570 - 599";break;
		case "21" : result="600 - 629";break;
		case "22" : result="630 - 659";break;
		case "23" : result="660 - 689";break;
		case "24" : result="690 - 719+";break;
		default: result = "";
	}
	return result;
}

function taskBtn(roleVal,oriVal){
       if(!roleVal) return true;
       else return oriVal;
}

function chkValidation(gName) {
	var gridNm = window.opener.document.getElementById(gName);
	var gData = new Array();
	var fValue = new Array();
	var Vadn = new Array();
	var bool = new Boolean();
	var number;
	var num=0;
	var numberTd=0;
	
	this.getKeyData = function(cellNo){
		var key = new Array();
		for(var i=1; i<gridNm.rows.length; i++) {
			key[(i-1)] = gridNm.rows[i].cells[cellNo].innerText;
		}
		//alert(gridNm.rows[0].cells[4].innerText);
		return key;
	};
	
	this.getLength = function() {
		return gridNm.rows.length;
	}

	this.setCmpDt = function(cGData,cFValue){
		var a;
		gData[num] = cGData;
		fValue[num] = cFValue;
		num++;
	}
	
	this.chkData = function() {
		number = num;
		num = 0;
		var testNum = 0;
		if ((gridNm.rows.length-1) == 0) bool = false;
		for (var b=0;b<(gridNm.rows.length-1);b++){
			for (var a=0;a<number;a++){ 
				if(gData[a][b] == fValue[a])
					testNum++;
			}
			if (testNum == number){
				bool = true;
				break;
			}
			else {
				bool = false
			}
			testNum = 0;
		}
	}

	this.setTdId = function (tdId) {
			Vadn[numberTd] = document.getElementById(tdId);
			numberTd++;
	}

	this.printOutChk = function(ValMsg,InvMsg){
		if(bool){
			for (var i=0;i<numberTd;i++){
				Vadn[i].innerHTML = "<font color=\"red\">"+ InvMsg +"</font>";
			}
		}
		else{
			for (var i=0;i<numberTd;i++){
				Vadn[i].innerHTML = "<font color=\"green\">"+ ValMsg +"</font>";
			}
		}
	}
	
	this.cannotSub = function(){
		return bool;
	}
}

//// Setting "onlyOnImages" to "true" will disable right-clicking only for
//  // images
//  var onlyOnImages = false;
//
//  // Detect the browser
//  var isIE5 = document.all && document.getElementById;  // IE 5 or higher
//  var isMoz = !isIE5 && document.getElementById;  // Mozilla/Firefox
//
//  function cancelContextMenu(e) {
//    // Here you can add additional code that is executed when the context menu
//    // is blocked. For instance, you can use the following code to display a
//    // message to the user:
//    // alert("Right-click disabled!");
//
//    return false;
//  }
//
//  /* This function is fired every time a user clicks the right mouse button to
//     open the browser's context menu. */
//  function onContextMenu(e) {
//    // Depending on the "onlyOnImages" variable the context menu is either
//    // blocked for the complete page or only for <img> tags.
//    if (!onlyOnImages
//      || (isIE5 && event.srcElement.tagName == "IMG")
//      || (IsMoz && e.target.tagName == "IMG")) {
//      return cancelContextMenu(e);
//    }
//  }
//
//  if (document.getElementById) {
//    // Register event handler
//    document.oncontextmenu = onContextMenu;
//  }
//
//function disableselect(e){
//    return false
//}
//function reEnable(){
//    return true
//}
//document.onselectstart=new Function ("return false")
//if (window.sidebar){
//    document.onmousedown=disableselect
//    document.onclick=reEnable
//}

function validate(theForm) {
  var someEmpty = false;
  for (var i=0, n=theForm.elements.length;i<n; i++) {
    var elem = theForm.elements[i];
    if (elem.type=='text' && elem.value=="") {
      someEmpty=true;
      break;
    }
  }
  if (someEmpty){
      return false;
  }else{
      return true;
  }
}


function noCTRL()
{
 var key = window.event.keyCode;
 var code = (document.all) ? key:window.event.which;

 var msg = "Sorry, this functionality is disabled.";
 if (parseInt(code)==17) // This is the Key code for CTRL key
 {
  alert(msg);
  window.event.returnValue = false;
 }
}

 function Encrypt(theText){
    output = new String;
    Temp = new Array();
    Temp2 = new Array();
    TextSize = theText.length;

    for (i = 0; i < TextSize; i++) {
        rnd = Math.round(Math.random() * 122) + 68;
        Temp[i] = theText.charCodeAt(i) + rnd;
        Temp2[i] = rnd;
    }

    for (i = 0; i < TextSize; i++) {
        output += String.fromCharCode(Temp[i], Temp2[i]);
    }

    return output;
}

//IE,Firefox,GoogleChrome,Opera [S]

var fn = function (e) 
{ 
 
    if (!e) 
        var e = window.event; 
 
    var keycode = e.keyCode; 
    if (e.which) 
        keycode = e.which; 
 
    var src = e.srcElement; 
    if (e.target) 
        src = e.target;     
 
    // 116 = F5 
    if (116 == keycode) 
    { 
        // Firefox and other non IE browsers 
        if (e.preventDefault) 
        { 
            e.preventDefault(); 
            e.stopPropagation(); 
        } 
        // Internet Explorer 
        else if (e.keyCode) 
        { 
            e.keyCode = 0; 
            e.returnValue = false; 
            e.cancelBubble = true; 
        } 
 
        return false; 
    } 
} 

//IE,Firefox,GoogleChrome,Opera [E]





