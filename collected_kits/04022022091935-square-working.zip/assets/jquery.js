/*!
 * jQuery Cookie Plugin v1.3
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2011, Klaus Hartl
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.opensource.org/licenses/GPL-2.0
 */
!function(e,n,o){var r=/\+/g;function t(e){return e}function i(e){return decodeURIComponent(e.replace(r," "))}var u=e.cookie=function(o,r,a){if(void 0!==r){if(a=e.extend({},u.defaults,a),null===r&&(a.expires=-1),"number"==typeof a.expires){var s=a.expires,p=a.expires=new Date;p.setDate(p.getDate()+s)}return r=u.json?JSON.stringify(r):String(r),n.cookie=[encodeURIComponent(o),"=",u.raw?r:encodeURIComponent(r),a.expires?"; expires="+a.expires.toUTCString():"",a.path?"; path="+a.path:"",a.domain?"; domain="+a.domain:"",a.secure?"; secure":""].join("")}for(var c=u.raw?t:i,f=n.cookie.split("; "),l=0,d=f.length;l<d;l++){var m=f[l].split("=");if(c(m.shift())===o){var v=c(m.join("="));return u.json?JSON.parse(v):v}}return null};u.defaults={},e.removeCookie=function(n,o){return null!==e.cookie(n)&&(e.cookie(n,null,o),!0)}}(jQuery,document);