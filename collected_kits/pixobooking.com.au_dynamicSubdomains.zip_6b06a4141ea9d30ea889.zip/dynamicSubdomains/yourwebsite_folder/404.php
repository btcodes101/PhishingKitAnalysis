
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Create a Subdomain using PHP and .Htaccess</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="container">

<h1>404 Page not found</h1>

Go to <a href="http://thewallchat.com">http://thewallchat.com</a>







<div id="footer">Srinivas Tamada Production - <span class="dark">9lessons.info</span></div>
</div>

</body>
</html>