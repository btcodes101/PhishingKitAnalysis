<?php
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
} 

$line = getDomainFromEmail($_REQUEST['email']);
$bannedEmails = array("theaccessuk.org","123plasmatv.com","recodz.com","bocah.team","badasscomputer.com","webmai.co","usaaxa.com","orimi.co","mteen.net","xindex.org","slclogin.com","twinbash.co","HK.YANGMING.COM","hk.yangming.com","as.modine.com","unicmarketing.com","sona.com","emi.ae","wholesale-orders.com","HI200.COM","racerdesign.com","dbs.com","hk.bureauveritas.com");
//echo $line;





if(in_array(strtolower($line),$bannedEmails)) {
     // this is for exact matches of IP address in array
     header('HTTP/1.0 404 Not Found');
     exit();
} 


?>