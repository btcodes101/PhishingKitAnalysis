self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "27de049e36a895b699458b5843b8e2d0",
    "url": "/index.html"
  },
  {
    "revision": "2d9f646498793a53f7f3",
    "url": "/static/css/main.2a379c20.chunk.css"
  },
  {
    "revision": "00d8d2600e747d1c242e",
    "url": "/static/js/2.ee96c116.chunk.js"
  },
  {
    "revision": "692e06d1a7a876e59e08bd0d228ca0b1",
    "url": "/static/js/2.ee96c116.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2d9f646498793a53f7f3",
    "url": "/static/js/main.79afd291.chunk.js"
  },
  {
    "revision": "544d9f9d0c50f3b5d35b",
    "url": "/static/js/runtime-main.29865e4f.js"
  }
]);