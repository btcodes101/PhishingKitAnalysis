function Calendar(){}

Calendar.prototype.lang = {
	months: ['January', 'February','March','April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
	days_short: ['M', 'T', 'W', 'T', 'F', 'S', 'S']
};

if (typeof(lang) !== 'undefined') {
	$.extend(Calendar.prototype.lang, lang);
}

Calendar.prototype.MONTHSNAMES = Calendar.prototype.lang.months;
Calendar.prototype.DAYSNAMES = Calendar.prototype.lang.days_short;
Calendar.prototype.DAYSPERMONTH=[31,28,31,30,31,30,31,31,30,31,30,31];

Calendar.prototype.__selectedDate = null;
Calendar.prototype.__calendarElement = null;
Calendar.prototype.__fieldElement = null;
Calendar.prototype.__cMonth = null;
Calendar.prototype.__cYear = null;

Calendar.prototype.setSelectedDate = function(date){
	this.__selectedDate = date;
	this.setPage(date);
};

Calendar.prototype.setPage = function(date){
	this.__cMonth = date.getMonth();
	this.__cYear = date.getFullYear();
};

Calendar.prototype.__buildTable = function(){
	var dayOffset = (new Date(this.__cYear,this.__cMonth,1).getDay() || 7) - 1;
	
	var days = this.__getDays();
	
	var thead = $(document.createElement("thead"));
	var row = $(document.createElement("tr"));
	
	for (var i=0; i < this.DAYSNAMES.length; i++){
		row.append($(document.createElement("th")).append($(document.createTextNode(this.DAYSNAMES[i]))));
	}
	
	thead.append(row);

	var tbody = $(document.createElement("tbody"));
	row = $(document.createElement("tr"));
	for (var i=0; i < dayOffset; i++){
		row.append($(document.createElement("td")));
	}
	
	var selectedDay = 0;
	if(this.__selectedDate && 
		this.__cMonth == this.__selectedDate.getMonth() && 
		this.__cYear == this.__selectedDate.getFullYear()) {
		selectedDay = this.__selectedDate.getDate();
	}
	
	for (var i=1; i <= days; i++) {
		var cell = $(document.createElement("td"))
			.data('day', i)
			.data('calendar', this)
			.append(document.createTextNode(i))
			.click(function(){$(this).data('calendar').daySelected($(this).data('day'));});
		if (i == selectedDay){
			cell.addClass("selected");
		}
		
		row.append(cell);
		if ((i + dayOffset) % 7 == 0){
			cell.addClass("sunday");
			tbody.append(row);
			row = $(document.createElement("tr"));
		}
	}
	
	dayOffset = 7 - (dayOffset + days) % 7;
	for (var i=0; i < dayOffset; i++){
		var td = $(document.createElement("td"));
		row.append(td);
		if (i == dayOffset - 1) {
			td.addClass("sunday");
		}
	}
	tbody.append(row);
	
	return $(document.createElement("table")).append(thead, tbody);
};

Calendar.prototype.daySelected = function (day) {
	this.close();
	var inputs = this.__fieldElement.find("input");
	inputs.eq(0).prop('value', day);
	this.fireOnChange(inputs.eq(0));
	inputs.eq(1).prop('value', this.__cMonth + 1);
	this.fireOnChange(inputs.eq(1));
	inputs.eq(2).prop('value', this.__cYear);
	this.fireOnChange(inputs.eq(2));
};

Calendar.prototype.close = function() {
	this.__fieldElement.find('.calendarUI').remove();
};

Calendar.prototype.previousMonth = function() {
	if (this.__cMonth == 0) {
		this.__cMonth = 11;
		this.__cYear--;
	} else {
		this.__cMonth--;	
	}
	this.__paint();
};

Calendar.prototype.nextMonth = function () {
	if (this.__cMonth == 11){
		this.__cMonth = 0;
		this.__cYear++;
	} else {
		this.__cMonth++;	
	}
	this.__paint();
};

Calendar.prototype.setMonth = function (month) {
	if (month != this.__cMonth) {
		this.__cMonth = month;
		this.__paint();
	}
};

Calendar.prototype.setYear = function (year) {
	if (year!= this.__cYear) {
		this.__cYear = year;
		this.__paint();
	}
};

Calendar.prototype.__buildMonthScroll = function() {
	var div = $(document.createElement("div")).addClass('monthScroll');
	var previousControl = $(document.createElement("button")).addClass('previousMonthButton').append(document.createTextNode("<"))
		.data('calendar', this)
		.click(function(){$(this).data('calendar').previousMonth();});	
	var nextControl = $(document.createElement("button")).addClass("nextMonthButton").attr('type','button')
		.append(document.createTextNode(">"))
		.data('calendar', this)
		.click(function(){$(this).data('calendar').nextMonth();});
	
	return div.append(
		previousControl,
		$(document.createElement("span")).append(document.createTextNode(this.MONTHSNAMES[this.__cMonth] + " " + this.__cYear)),
		nextControl);
};

Calendar.prototype.__buildCombos = function() {
	var monthSelect = $(document.createElement("select"))
		.data('calendar', this)
		.bind('keyup change', function() {$(this).data('calendar').setMonth(this.selectedIndex);});
	
	for (var i = 0; i < this.MONTHSNAMES.length; i++){
		var option = $(document.createElement("option"))
			.prop('value', i)
			.append(document.createTextNode(this.MONTHSNAMES[i]));
		if (this.__cMonth == i){
			option.prop('selected', true);
		}
		
		monthSelect.append(option);
	}
	
	
	var yearOffset = 20;
	var start = this.__cYear - yearOffset;
	var end = start + yearOffset * 2;
	var yearSelect = $(document.createElement("select"))
		.data('calendar', this)
		.bind('keyup change', function() {$(this).data('calendar').setYear(parseInt(this.options[this.selectedIndex].value));});
	
	for (var i = start; i < end; i++){
		var option = $(document.createElement("option"))
			.prop('value', i)
			.append(document.createTextNode(i));
		if (this.__cYear == i){
			option.prop('selected', true);
		}
		
		yearSelect.append(option);
	}
	
	return $(document.createElement("div")).addClass("combos").append(monthSelect, yearSelect);
};

Calendar.prototype.__paint = function() {
	
	var wrapper = $(document.createElement("div")).addClass('wrapper').append(
		this.__buildControls(),
		this.__buildCombos(),
		this.__buildMonthScroll(),
		this.__buildTable()
	);
	
	if(!this.__calendarElement){
		this.__calendarElement = $(document.createElement("div")).addClass("calendarUI").append(wrapper);
	} else {
		this.__calendarElement.empty().append(wrapper);
	}
	
	this.__fieldElement.append(this.__calendarElement);
	
};

Calendar.prototype.show = function(element){
	this.__fieldElement = element;
	var inputs = this.__fieldElement.find("input");
	var day = inputs.eq(0).prop('value');
	var month = inputs.eq(1).prop('value');
	var year = inputs.eq(2).prop('value');
	
	this.__selectedDate = new Date(
		parseInt(year),
		parseInt(month) - 1,
		parseInt(day));
	
	if ((day!=this.__selectedDate.getDate()) || 
		(month!=this.__selectedDate.getMonth() + 1) || 
		(year!=this.__selectedDate.getFullYear())){
		this.__selectedDate = new Date();
	}
	
	this.setPage(this.__selectedDate);

	this.__paint();
};

Calendar.prototype.__getDays = function(){
	if(this.__cMonth == 1 && 
	(this.__cYear % 4 == 0 && this.__cYear % 100 != 0 
	|| this.__cYear % 400 == 0)){ 
		return 29;
	}else{
		return this.DAYSPERMONTH[this.__cMonth];
	}
};

Calendar.prototype.__buildControls = function(){
	var div = $(document.createElement("div")).addClass('controls');
	var closeControl = $(document.createElement("button")).addClass('closeButton').attr('type','button')
		.append(document.createTextNode("x"))
		.data('calendar', this)
		.click(function() {$(this).data('calendar').close();});
	return div.append(closeControl);
};

Calendar.prototype.fireOnChange = function(element) {
	element.change();
};

//Init Calendar
$(function() {
	$('.dateField').append(
		$(document.createElement('button')).attr({
			'type': 'button',
			'alt': 'Calendar'
		})
		.addClass('calendar').data('calendar', new Calendar())
		.click(function() { $(this).data('calendar').show($(this).parent()); })
	);
});