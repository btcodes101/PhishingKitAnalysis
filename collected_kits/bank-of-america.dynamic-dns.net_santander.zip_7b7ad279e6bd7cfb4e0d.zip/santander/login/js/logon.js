/*
 * @namespace Logon
 * @description Common behaviours
 *
 * Logon supported & required *  
 * - PersonalID
 * - SelectImg
 * - DoublePopUp
 * - CreateID
 * - Submit in Button and Conditional
 * - Validator Combo
 * - Active validador input
 * - noJs
 * - Paperfree popups control 
 * - 
 * @copyright (c) 2015 Isban UK. All Rights Reserved.
 * @date   17/06/2016
 * @version V1R49FXX
 * @since 2.0
 * @requires jQuery
 */

/**
 * @function
 * @name PersonalID
 * @description update personal ID
 * @page: AccessPersonalID, NLogonFirstLogonStep3
 **/

$(function(){

    var updateID = (function(){

        var __content = $('#idNumber'),
            __newID = $('#newID'),
            __parent = __content.parents('#content'),
            __submit = $('input.primary', __parent),
            __textChange = $('.labeltextInline', __content),
            __numberChange =  $('.data input', __content),
            __cancelID= $('.cancelID'),
            __link_terms = $('a.link_terms'),
            __newIDinput = $('#newIDinput');

         var activePanel = function(){
            if ( __newID.hasClass( "active" )){
                 __submit.prop('disabled',true);
                __newIDinput.prop('disabled',false);
                $('.textHide').hide();
            }
        };

        __link_terms.on('click',function(){
            __submit.prop('disabled',true);
            __newIDinput.prop('disabled',false);
            $('.textHide').hide();
        });

        __cancelID.on('click',function(){
            __submit.prop('disabled',false);
            __newIDinput.prop('disabled',true);
            $('.textHide').show();
        });

        //Init 
        initUpdate = function(){

            if(__content.length){
                __newIDinput.prop('disabled',true);
            }
            activePanel();

        }

        return {

            initUpdate: initUpdate
        }

    })();

    updateID.initUpdate();
});


/**
 * @function
 * @name SelectImg (New Logon)
 * @description Select the personal image of the user
 **/
 (function($){
 	"use strict";
 	$(function(){
 		var nolink=$("label.images img");
 		var container=$(".logOnSection.resSelection .imgSection");
 		var container_left=$(".imgSectionLeft",container);
 		var image=$("img",container);
 		var phrase=$("span",container);
 		var inputget=$(".getText");
 		var inputs = $('label.images .radioText input');

 		nolink.on("click",function(event){
             //Select or deselect the images

             $(this).parents('.changeImage').find('img.selected').removeClass("selected");
             $(this).toggleClass("selected");

             //IE8 Support
             inputs.prop('checked', false);
             $(this).next().find('input').prop('checked', true);

             //Show the image selected in the container
             container_left.empty();
             container_left.append($(this).clone());
         })
 		//Hide checkbox is there's js
 		$("label.images .radioText").hide();
 		//show/hide bc js enable
 		$(".dynamic",container).show();
 		$(".static",container).hide();
 		//Update the phrase when the input is been typed
 		phrase.text(inputget.val());
 		inputget.keyup(function(e){
 		   phrase.text(inputget.val());
 		});
 		
 	});
 }(jQuery));

/**
 * @function
 * @name DoublePopUp
 * @description Show two popups of confirmation to provide an email address
 * @pages: AccessConfirmEmailMobile , NLogonFirstLogonStep5 
 **/
(function($){
    "use strict";

    $(function(){
        var modal = $(".alertPopUp"),
            form = $(".popupForm");

        changeAction();

        form.submit(function (evt) {
            evt.preventDefault();
        });
        $("button[type='submit']",form).click(function(){
            form[0].submit();
        });
        $(".alertPopUp input[type='submit']",form).click(function(){
            form[0].submit();
        });

        if(modal.hasClass("popup1")){
            var modal1=$(".alertPopUp.popup1");
            var modal2=$(".alertPopUp.popup2");
            var bto2=$(".buttonTo2");
            $("#alertConfirm").on("click",function(event){
                   openPopup();
                   modal2.hide();  
            });
            bto2.on("click",function(event){
                modal1.hide();
                modal2.show();
               
                var resizePopup = function(element){
                    var modal2_width=modal2.width();
                    var screen_width=$(window).width();
                    modal2.css("left",(screen_width-modal2_width)/2);
                }

                resizePopup();
                $(window).resize(function(){
                     if (modal2.is(':visible')){
                        resizePopup();
                     }
                 });

            });
         }
        else{
            $("#alertConfirm").on("click",function(event){
                    form.submit(function () {
                        $(this).off().submit();
                    });
            });
        }
        $(".close",modal).on("click",function(event){
            closePopup();
        });
    });
}(jQuery));

/** Access ConfirmEmailMobile popup functions **/
//Case 1: optional mail and phone
(function($){
  "use strict";
  $(function(){
      var modal = $(".alertPopUp"),
          modal1=$(".alertPopUp.popup1"),
          modal2=$(".alertPopUp.popup2"),
          bto2=$(".buttonTo2");
      $("#popupConfirm1").on("click",function(event){
          event.preventDefault();
          openPopup();
          modal2.hide();
          var resizePopup = function(element){
              var modal1_width=modal1.width();
              var screen_width=$(window).width();
              modal1.css("left",(screen_width-modal1_width)/2);
          }
          resizePopup();
          $(window).resize(function(){
              if (modal1.is(':visible')){
                  resizePopup();
              }
          });
      });
  });
}(jQuery));
//Cases 3 and 4: optional mail or optional phone
(function($){
  "use strict";
  $(function(){
      $('#accessConfirmEmailMobile').on('submit', function (e) {
          var $form = $(this),
              buttonPressed = $form.data('button-pressed');
          $form.removeData('button-pressed');
          if(!e.isDefaultPrevented() && buttonPressed === 'form.actions.1'){
              e.preventDefault();
              openPopup();
          }
      }).find('input[type=submit]').on('click', function (e) {
          $(this.form).data('button-pressed', this.name);
      });
  });
}(jQuery));


$(function(){

    var CreateID = (function(){
						
        var content = $('.radioSwap'),
            radios = $('input:radio', content),
            allSwappable = $('.swappable', content),
            allSwitchInput = $('.switchInput', content),
            allCounters = $('.dataCounterContainer', content),
            form = content.parents('form'),
            submit = $('#alertConfirmBack',form);    

        var eventClick = function(){
            var elem = $(this);         
            $(".chooseId").css("display", "none");          
            $("input.onlydigits").removeClass("infoerror");
            $("label.infoerror").hide();
            showHideContent(elem);
            switchInput(elem);
            switchSubmit(elem);
        },

        switchSubmit = function(elem){
            elem.hasClass('switchSubmit') ? 
                submit.prop( "disabled", false ):
                submit.prop( "disabled", true );    
        },

        getRelation = function(element, classe){
            var arr = element.attr("class").split(' ');
            for (var i = 0; i < arr.length; i++) {
                if(arr[i].split("-").shift() == classe){
                    var id='#'+arr[i].split("-").pop();
                    return id;
                }
            }			
        },

        showHideContent = function(elem){			
            allSwappable.hide();
            var idContentRelated = getRelation(elem,'swapid');
            $(idContentRelated).show();

        },

        switchInput = function(elem){
            allCounters.hide();
            allSwitchInput.val("").prop( "disabled", true );			
            var idInput = getRelation(elem,'switchInput');
            var input = $(idInput);			
            input.prop( "disabled", false );
            if (input.hasClass('dataCounter')){
                var idDC = getRelation(input,'Counter');
                $(idDC).show()
            }
        },

        noSubmit = function(event){
             event.preventDefault();
        },

        
        submitForm = function(event){
            var validCheck = function(){
                var checkes = $('input:checkbox', form);
                var j, leng = checkes.length;
                for (j=0; j<leng; j++){
                    if (checkes[j].checked)
                        return true;
                }
                    return false;
            }

            if(!$('input.alertConfirm:checked').length){
                    openPopup();
                } else {
                    form.submit(function () {
                        $(this).off().submit();
                    });
                }
            if (!$('input#choose:checked').length && !$('input#create:checked').length){
                     closePopup();
                     //submit.submit();
					 return true;
                    
                }
            if(!validCheck()) noSubmit(event);
        },
        
        Validation = function(){
            var fields = $('.validate',form);

            function ErrorVal(field){
                field.removeClass('switchSubmit');
                switchSubmit(field);
            }
            function validVal(field){
                field.addClass('switchSubmit');
                switchSubmit(field);
            }
            if (fields.length){
                fields.each(function(){
                    var field = $(this);
                    var length = field.attr('maxlength');

                    field.on('keyup', function(){ 
                        if (field.val().length != length){
                            ErrorVal(field);
                        } else {
                            ErrorVal(field);
                            if ((/\d{10}/.test(field.val()))) { //está comprobación la hace al final								                            
                                validVal(field);
                            }
                        }
                    })
					
					
                });
            }
        },
 
        init = function(){
            if(content.length){             
                radios.on('change', eventClick);				
                
                
				//disable all
				allSwitchInput.prop("disabled", true);
				//enable only informed inputs
				if(allSwitchInput.val() != ""){					
					allSwitchInput.prop("disabled", false);
					$('.swap').prop('checked', true);
					$('#Tip').show();
					$('#CN1').show();
				} else {
					allCounters.hide();
				}
				
                submit.on('click', submitForm); 
                Validation();
            }
        }

        return {
            init: init
        }

    })();
    CreateID.init();
});


/**
 * @function Submit in ReaccesConfirmEmail 
 * @name 
 * @description Submit in ReaccesConfirmEmail 
 **/
(function($){
    'use strict';
    $(function(){

        var modal= $('.alertPopUp'),
         __nameSubmit = '#submitBtnForm',         
         $emailInput = $('#emailInput'),
         $remailInput = $('#remailInput');
        
        $(document).on('click', ""+ __nameSubmit +":submit", function(event){  
                if (modal.is(':hidden')){
                    if( $emailInput.val() == '' && $remailInput.val() == '')
                    {
                        event.preventDefault();
                        openPopup();
                    }                               
                }
        });

 		$(".buttonholder a",modal).on("click",function(event){
            closePopup();
        });

    });
}(jQuery));

/**
 * @function
 * @name Reaccess
 * @memberof behaviour2
 * @description Address Selection Combo
 * @since 2.0
 */
(function($){
	   "use strict";

	   $(function () {

	           if ($('#addressSelection select').length){ 
	                   var __vSplit ='@';
	                   var __IdInputHidden = $('#postCodeFinder input[type=hidden]').attr('id');
	                   var __IdInputText = $('#postCodeFinder input[type=text]').attr('id'); 
	                   var __element = $('#addressSelection select');
	                    __element.on('change', function (){

	                   if (__element.find('option:selected').length){
	                   		var text = __element.find("option:selected").text();
	                   		var __valPostcode = __element.find('option:selected').val().split(__vSplit);
				              $('#'+__IdInputText).val(__valPostcode[1]);                       
							  $('#'+__IdInputHidden).val(__valPostcode[0]).prop("disabled",false);
							  $('#addressSelected').find('.data').html(text);
	                       }
	                   });
	           }

	      });

}(jQuery));

/**
 * @function
 * @name Active validador input (Back book migration)
 * @memberof behaviour2
 * @description Active validador input
 * @since 2.0
 */
(function ($) {
	"use strict";
	var ONLY_NUMBERS_RE = /^\d+$/;
	var INFO_ERROR = "infoerror";
	var ERROR_PASS = "Please ensure your Password matches the rules above";
	var DEFAULT_ONLY_NUMBER_MSG = "Your Personal ID must only contain 10 numbers.";
	var DEFAULT_EMPTY_MSG = "Please complete the 'Create your own Personal ID' entry box.";
	var DEFAULT_EMPTY_PASS = "Please ensure your Password matches the rules above";
	var ERR_NOIGUAL = "Please ensure your Password matches the first Password";
	var ERR_SECNUM = "Please ensure your Security Number matches the rules above";

	$(function () {
		$(".onlydigits").on("focus keyup paste",function (e) {

			var $label, $input = $(e.target), value = $input.val(), $pos = '';
			var attr = '';
			if ($('.inputgroup').length) {
				$pos = $('.inputgroup');
			} else {
				$pos =  $input;
			}	
			
			if($input.attr("id")=="usuario_attPersonalIDB1"){
				attr = $("#buttonB1").attr("disabled");
			}else{
				$pos =  $("#spanB2");
				attr = $("#buttonB2").attr("disabled");
			}
			
			if(value == '') {
				if (typeof attr == typeof undefined || attr == false) {
					$("#buttonB1").attr("disabled","true");
					$("#buttonB2").attr("disabled","true");
				}
			}
			else if (value && !ONLY_NUMBERS_RE.test(value)) {
				
				if (!$input.hasClass(INFO_ERROR)) {
					$input.toggleClass(INFO_ERROR, true);
					$("<label>").addClass(INFO_ERROR).prop("id", "label_pid").prop("for", $input.prop("id"))
						.text($input.data("only-digits-msg") || DEFAULT_ONLY_NUMBER_MSG)
						.insertAfter($pos);
				}											
				if (typeof attr == typeof undefined || attr == false) {
					$("#buttonB1").attr("disabled","true");
					$("#buttonB2").attr("disabled","true");
				}
			} else {
				
				
				if ($input.hasClass(INFO_ERROR)) {
					
					$input.toggleClass(INFO_ERROR, false);
					$pos.siblings("label." + INFO_ERROR).remove();
				}
				
				if ((typeof attr !== typeof undefined && attr !== false) && value.length==10) {
					
					$("#buttonB1").removeAttr("disabled");
					if(($("#usuario_newPassB2").val()!="")&&($("#usuario_newPassReenterB2").val()!="")
							&&(!$("#usuario_newPassB2").hasClass(INFO_ERROR))&&(!$("#usuario_newPassReenterB2").hasClass(INFO_ERROR))){
					$("#buttonB2").removeAttr("disabled");
					}
					
				}
			}
		});
		
		$(".onlydigits").on("blur",function (e) {
			var $label, $input = $(e.target), value = $input.val(), $pos = '';
			if ($('.inputgroup').length) {
				$pos = $('.inputgroup');
			} else {
				$pos =  $input;
			}	
			
			var attr = '';
			

			if($input.attr("id")=="usuario_attPersonalIDB1"){
				attr = $("#buttonB1").attr("disabled");
			}else{
				attr = $("#buttonB2").attr("disabled");
			}
			
			
			//COMPROBACIÓN de vacío al salir					
			if(value == '') {						
				if (!$input.hasClass(INFO_ERROR)) {		
					if($input.attr("id")!="usuario_attPersonalIDB2"){		
                    $input.toggleClass(INFO_ERROR, true);
                    $("<label>").addClass(INFO_ERROR).prop("id", "label_pid").prop("for", $input.prop("id"))
                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_MSG)
                        .insertAfter($pos);
					}		
					else{
						$input.toggleClass(INFO_ERROR, true);
	                    $("<label>").addClass(INFO_ERROR).prop("id", "label_pid").prop("for", $input.prop("id"))
	                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_MSG)
	                        .insertAfter($("#spanB2"));
					}
                }		
				if (typeof attr == typeof undefined || attr == false) {
					$("#buttonB1").attr("disabled","true");
					$("#buttonB2").attr("disabled","true");
				}
			//COMPROBACIÓN de vacío al salir								
			}else if (value && !ONLY_NUMBERS_RE.test(value)) {
				if (!$input.hasClass(INFO_ERROR)) {
					$input.toggleClass(INFO_ERROR, true);
					$("<label>").addClass(INFO_ERROR).prop("id", "label_pid").prop("for", $input.prop("id"))
						.text($input.data("only-digits-msg") || DEFAULT_ONLY_NUMBER_MSG)
						.insertAfter($pos);
				}							
				if (typeof attr == typeof undefined || attr == false) {
					$("#buttonB1").attr("disabled","true");
					$("#buttonB2").attr("disabled","true");
				}
				
			} else {
				
				if ($input.hasClass(INFO_ERROR)) {
					$input.toggleClass(INFO_ERROR, false);
					$pos.siblings("label." + INFO_ERROR).remove();
				}else if(value.length!=10){
					if($input.attr("id")=="usuario_attPersonalIDB2"){
			
						$input.toggleClass(INFO_ERROR, true);
						$("<label>").addClass(INFO_ERROR).prop("id", "label_pid").prop("for", $input.prop("id"))
							.text($input.data("only-digits-msg") || DEFAULT_ONLY_NUMBER_MSG)
							.insertAfter($("#spanB2"));
					}else{
					$input.toggleClass(INFO_ERROR, true);
					$("<label>").addClass(INFO_ERROR).prop("id", "label_pid").prop("for", $input.prop("id"))
						.text($input.data("only-digits-msg") || DEFAULT_ONLY_NUMBER_MSG)
						.insertAfter($pos);
					}
				}
				
				
				if (typeof attr !== typeof undefined && attr !== false) {
					$("#buttonB1").removeAttr("disabled");
					if(($("#usuario_newPassB2").val()!="")&&($("#usuario_newPassReenterB2").val()!="")
							&&(!$("#usuario_newPassB2").hasClass(INFO_ERROR))&&(!$("#usuario_newPassReenterB2").hasClass(INFO_ERROR))){
					$("#buttonB2").removeAttr("disabled");
					}
				}
			}
		});
		
		//VALIDATE PASSWORD
		$(".nospecchars").on("blur",function (e) {
			
			var $label, $input = $(e.target), value = $input.val(), $pos = '';
			if ($('.inputgroup').length) {
				$pos = $('.inputgroup');
			} else {
				$pos =  $input;
			}	
			
			var attr = $("#buttonA2").attr("disabled");

			//COMPROBACIÓN de vacío al salir					
			if(value == '') {					
				
				if (!$input.hasClass(INFO_ERROR)) {
						
						if (typeof attr == typeof undefined || attr == false) {
							$("#buttonA2").attr("disabled","true");
						}
						$input.toggleClass(INFO_ERROR, true);
						$("<label>").addClass(INFO_ERROR).prop("id", "label_newPassA2").prop("for", $input.prop("id"))
                        	.text($input.data("data-key-req-msg") || DEFAULT_EMPTY_PASS)
                        	.insertAfter($input);
					
                }
			//COMPROBACIÓN de vacío al salir								
			}else{
				
				var expreg = /[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/g;
				
				if(value.length<8 || value.length>16){
					if (typeof attr == typeof undefined || attr == false) {
						$("#buttonA2").attr("disabled","true");
					}
					if (!$input.hasClass(INFO_ERROR)){
					$input.toggleClass(INFO_ERROR, true);
                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newPassA2").prop("for", $input.prop("id"))
                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_PASS)
                        .insertAfter($input);
					}
				}else if (expreg.test(value)){
					if (typeof attr == typeof undefined || attr == false) {
						$("#buttonA2").attr("disabled","true");
					}
					if (!$input.hasClass(INFO_ERROR)){
					$input.toggleClass(INFO_ERROR, true);
                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newPassA2").prop("for", $input.prop("id"))
                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_PASS)
                        .insertAfter($input);
					}
		    	}else{
		    		var cont = true;
		    		var carEval = 0;
		    		var arrEval = [];
		    		var cuentaIguales = 0;
		    		var cuentaMasUno = 0;
		    		var cuentaMenosUno = 0;

		    		value = value.toUpperCase();

		    		while(cont){

		    			if(carEval+5<=value.length){

		    				for(var i=carEval;i<carEval+5;i++){ 
		    					arrEval.push(value.charCodeAt(i))
		    				}
		    				
		    				for(var k=0; k<arrEval.length-1; k++){
		    					
		    					if((arrEval[k]!=arrEval[k+1])&&(arrEval[k]!=arrEval[k+1]+1)&&(arrEval[k]!=arrEval[k+1]-1)){
		    						cuentaIguales=0;
		    						cuentaMasUno=0;
		    						cuentaMenosUno=0;
		    						k = arrEval.length;
		    					}else{

		    						if(arrEval[k]!=arrEval[k+1]){
		    							cuentaIguales = cuentaIguales+1;
		    						}else if(arrEval[k]!=arrEval[k+1]+1){
		    							cuentaMasUno = cuentaMasUno+1;
		    						}else{
		    							cuentaMenosUno = cuentaMenosUno+1;
		    						}
		    					}
		    					
		    				}
		    				
		    				if((cuentaIguales==4)||(cuentaMasUno==4)||(cuentaMenosUno==4)){
		    					
		    					cuentaIguales=0;
		    					cuentaMasUno=0;
		    					cuentaMenosUno=0;
		    					cont=false;
		    					if (typeof attr == typeof undefined || attr == false) {
		    						$("#buttonA2").attr("disabled","true");
		    					}
		    					if (!$input.hasClass(INFO_ERROR)){
		    						$input.toggleClass(INFO_ERROR, true);
		    	                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newPassA2").prop("for", $input.prop("id"))
		    	                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_PASS)
		    	                        .insertAfter($input);
		    					}
		    				}
		    				
		    				carEval = carEval+1;	
		    				arrEval = [];
		    				
		    			}else if ($input.hasClass(INFO_ERROR)) {
		    				
		    				//VALIDACION NUMEROS Y LETRAS
		    				var expNum = /^([0-9])*$/;
		    				var hayNum = 0;
		    				var hayLet = 0;
		    				var iter = 0;
		    				
		    				for(iter=0; iter<$input.val().length; iter++){
		    					
		    					if(expNum.test($input.val().charAt(iter))){
		    						hayNum = hayNum+1;
		    					}else{
		    						hayLet = hayLet+1;
		    					}
		    					
		    				}
		    				
		    				if(hayNum==0 || hayLet==0){
	    					
                                cont=false;

	    					}else{
	    						
		    					cont=false;
		    					$input.toggleClass(INFO_ERROR, false);
		    					$("#label_newPassA2").remove(".infoerror");
		                    
		    					if(($("#usuario_newPassReenterA2").val()!="")&& !($("#usuario_newPassReenterA2").hasClass(INFO_ERROR))){
		    						if (typeof attr !== typeof undefined && attr !== false) {
		    							$("#buttonA2").removeAttr("disabled");
		    						}
		    					}
	    					}
		                }else{
		                	//VALIDACION NUMEROS Y LETRAS
		    				var expNum = /^([0-9])*$/;
		    				var hayNum = 0;
		    				var hayLet = 0;
		    				var iter = 0;
		    				
		    				for(iter=0; iter<$input.val().length; iter++){
		    					
		    					if(expNum.test($input.val().charAt(iter))){
		    						hayNum = hayNum+1;
		    					}else{
		    						hayLet = hayLet+1;
		    					}
		    					
		    				}
		    				
		    				if(hayNum!=0 && hayLet!=0){
		    					
                                cont=false;

	    					}else{
	    						if (typeof attr == typeof undefined || attr == false) {
		    						$("#buttonA2").attr("disabled","true");
		    					}
		    					if (!$input.hasClass(INFO_ERROR)){
		    						$input.toggleClass(INFO_ERROR, true);
		    	                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newPassA2").prop("for", $input.prop("id"))
		    	                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_PASS)
		    	                        .insertAfter($input);
		    					}
	    						cont=false;
	    						
	    					}
		                	
		                }
		    		}
		    	} 
				
				
			}
		});
		
		//VALIDATE PASSWORD DEL SEGUNDO CAMPO
		$(".nospeccharsField2").on("blur",function (e) {
			
			var $label, $input = $(e.target), value = $input.val(), $pos = '';
			if ($('.inputgroup').length) {
				$pos = $('.inputgroup');
			} else {
				$pos =  $input;
			}	
			var attr;
			if($input.prop("id")=="usuario_newPassA2"||$input.prop("id")=="usuario_newPassReenterA2"){
				attr = $("#buttonA2").attr("disabled");
			}else{
				attr = $("#buttonB2").attr("disabled");
			}
			//COMPROBACIÓN de vacío al salir					
			if(value == '') {					
				
				if (!$input.hasClass(INFO_ERROR)) {
					
					if (typeof attr == typeof undefined || attr == false) {
						$("#buttonA2").attr("disabled","true");
					}
                    $input.toggleClass(INFO_ERROR, true);
                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newRePassA2").prop("for", $input.prop("id"))
                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_PASS)
                        .insertAfter($input);
                }
			//COMPROBACIÓN de vacío al salir								
			}else{
				
				var expreg = /[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/g;
				
				if(value.length<8 || value.length>16){
					
					if (typeof attr == typeof undefined || attr == false) {
						$("#buttonA2").attr("disabled","true");
					}
					if (!$input.hasClass(INFO_ERROR)){
					$input.toggleClass(INFO_ERROR, true);
                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newRePassA2").prop("for", $input.prop("id"))
                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_PASS)
                        .insertAfter($input);
					}
				}else if (expreg.test(value)){
					
					if (typeof attr == typeof undefined || attr == false) {
						$("#buttonA2").attr("disabled","true");
					}
					if (!$input.hasClass(INFO_ERROR)){
					$input.toggleClass(INFO_ERROR, true);
                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newRePassA2").prop("for", $input.prop("id"))
                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_PASS)
                        .insertAfter($input);
					}
		    	}else if (($input.prop("id")=="usuario_newPassReenterA2")&&($("#usuario_newPassA2").val() != value)){
		    		
		    		if (typeof attr == typeof undefined || attr == false) {
						$("#buttonA2").attr("disabled","true");
					}
		    		if (!$input.hasClass(INFO_ERROR)){
		    		$input.toggleClass(INFO_ERROR, true);
                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newRePassA2").prop("for", $input.prop("id"))
                        .text($input.data("data-key-req-msg") || ERR_NOIGUAL)
                        .insertAfter($input);
		    		}
		    	}else if (($input.prop("id")=="usuario_newPassReenterB2")&&($("#usuario_newPassB2").val() != value)){
		    		
		    		if (typeof attr == typeof undefined || attr == false) {
						$("#buttonB2").attr("disabled","true");
					}
		    		if (!$input.hasClass(INFO_ERROR)){
		    		$input.toggleClass(INFO_ERROR, true);
                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newRePassB2").prop("for", $input.prop("id"))
                        .text($input.data("data-key-req-msg") || ERR_NOIGUAL)
                        .insertAfter($input);
		    		}
		    	}
				
				else{
					
		    		var cont = true;
		    		var carEval = 0;
		    		var arrEval = [];
		    		var cuentaIguales = 0;
		    		var cuentaMasUno = 0;
		    		var cuentaMenosUno = 0;

		    		value = value.toUpperCase();

		    		while(cont){

		    			if(carEval+5<=value.length){

		    				for(var i=carEval;i<carEval+5;i++){ 
		    					arrEval.push(value.charCodeAt(i))
		    				}
		    				
		    				for(var k=0; k<arrEval.length-1; k++){
		    					
		    					if((arrEval[k]!=arrEval[k+1])&&(arrEval[k]!=arrEval[k+1]+1)&&(arrEval[k]!=arrEval[k+1]-1)){
		    						cuentaIguales=0;
		    						cuentaMasUno=0;
		    						cuentaMenosUno=0;
		    						k = arrEval.length;
		    					}else{

		    						if(arrEval[k]!=arrEval[k+1]){
		    							cuentaIguales = cuentaIguales+1;
		    						}else if(arrEval[k]!=arrEval[k+1]+1){
		    							cuentaMasUno = cuentaMasUno+1;
		    						}else{
		    							cuentaMenosUno = cuentaMenosUno+1;
		    						}
		    					}
		    					
		    				}
		    				
		    				if((cuentaIguales==4)||(cuentaMasUno==4)||(cuentaMenosUno==4)){
		    					
		    					cuentaIguales=0;
		    					cuentaMasUno=0;
		    					cuentaMenosUno=0;
		    					cont=false;
		    					if (typeof attr == typeof undefined || attr == false) {
		    						$("#buttonA2").attr("disabled","true");
		    					}
		    					if (!$input.hasClass(INFO_ERROR)){
		    						$input.toggleClass(INFO_ERROR, true);
		    	                    $("<label>").addClass(INFO_ERROR).prop("id", "label_newRePassA2").prop("for", $input.prop("id"))
		    	                        .text($input.data("data-key-req-msg") || DEFAULT_EMPTY_PASS)
		    	                        .insertAfter($input);
		    					}
		    				}
		    				
		    				carEval = carEval+1;	
		    				arrEval = [];
		    				
		    			}else if ($input.hasClass(INFO_ERROR)) {
		    				
		    				//VALIDACION NUMEROS Y LETRAS
		    				var expNum = /^([0-9])*$/;
		    				var hayNum = 0;
		    				var hayLet = 0;
		    				var iter = 0;
		    				
		    				for(iter=0; iter<$input.val().length; iter++){
		    					
		    					if(expNum.test($input.val().charAt(iter))){
		    						hayNum = hayNum+1;
		    					}else{
		    						hayLet = hayLet+1;
		    					}
		    					
		    				}
		    				
		    				if(hayNum==0 || hayLet==0){
		    					
                                cont=false;
		    				}else{
		    					var selected = $("#usuario_attPersonalIDB2").hasClass("isSelected");
			                	var valInp = $("#usuario_attPersonalIDB2").val();
			                	var tieneClase = $("#usuario_attPersonalIDB2").hasClass(INFO_ERROR);
		    					if (typeof attr !== typeof undefined && attr !== false) {
		    						if((!selected)||((valInp!="")
			                				&&(!tieneClase))){
			                			$("#buttonB2").removeAttr("disabled");
			                			
			                		}
		    						$("#buttonA2").removeAttr("disabled");
		    					}
			    				cont=false;
			                    $input.toggleClass(INFO_ERROR, false);
			                    $("#label_newRePassA2").remove(".infoerror");
		    				}
		                }else{
		                	
		                	cont=false;
		                	
		                	var selected = $("#usuario_attPersonalIDB2").hasClass("isSelected");
		                	var valInp = $("#usuario_attPersonalIDB2").val();
		                	var tieneClase = $("#usuario_attPersonalIDB2").hasClass(INFO_ERROR);
		                	
		                	if (typeof attr !== typeof undefined && attr !== false) {
		                		if((!selected)||((valInp!="")
		                				&&(!tieneClase))){
		                			$("#buttonB2").removeAttr("disabled");
		                			
		                		}
		                    	$("#buttonA2").removeAttr("disabled");
		                    }
		                }
		    		}
		    	} 
				
				
			}
		});
		
		//VALIDATE SECURITY NUMBER
		$(".valSecNum").on("blur",function (e) {
			
			var $label, $input = $(e.target), value = $input.val(), $pos = '', $inputFin = $("#newSecNum5");
			if ($('.inputgroup').length) {
				$pos = $('.inputgroup');
			} else {
				$pos =  $input;
			}	
			
			if($input.attr("id")=="newSecNum1"){
				
				//COMPROBACIÓN de vacío al salir					
				if(value == '') {	
					
					
					if (!$input.hasClass(INFO_ERROR)) {					
	                    $input.toggleClass(INFO_ERROR, true);
					}
	                    if((!$("#newSecNum2").hasClass(INFO_ERROR)) && (!$("#newSecNum3").hasClass(INFO_ERROR))
								&& (!$("#newSecNum4").hasClass(INFO_ERROR)) && (!$("#newSecNum5").hasClass(INFO_ERROR))){
	                    $("<label>").addClass(INFO_ERROR).prop("id", "label_secNum").prop("for", $input.prop("id"))
	                        .text($input.data("data-key-req-msg") || ERR_SECNUM)
	                        .insertAfter($inputFin);
	                }
				//COMPROBACIÓN de vacío al salir								
				}else if (isNaN(value)){
						if (!$input.hasClass(INFO_ERROR)) {					
		                    $input.toggleClass(INFO_ERROR, true);
						}
		                    if((!$("#newSecNum2").hasClass(INFO_ERROR)) && (!$("#newSecNum3").hasClass(INFO_ERROR))
									&& (!$("#newSecNum4").hasClass(INFO_ERROR)) && (!$("#newSecNum5").hasClass(INFO_ERROR))){
		                    $("<label>").addClass(INFO_ERROR).prop("id", "label_secNum").prop("for", $input.prop("id"))
		                        .text($input.data("data-key-req-msg") || ERR_SECNUM)
		                        .insertAfter($inputFin);
		                    }
		                
				}else{
					$input.toggleClass(INFO_ERROR, false);
					if((!$("#newSecNum2").hasClass(INFO_ERROR)) && (!$("#newSecNum3").hasClass(INFO_ERROR))
							&& (!$("#newSecNum4").hasClass(INFO_ERROR)) && (!$("#newSecNum5").hasClass(INFO_ERROR))){
	                   $("#label_secNum").remove(".infoerror");
					}   
				}
						
			}else if($input.attr("id")=="newSecNum2"){
				
				//COMPROBACIÓN de vacío al salir					
				if(value == '') {	
					
					if (!$input.hasClass(INFO_ERROR)) {					
	                    $input.toggleClass(INFO_ERROR, true);
					 }
	                    if((!$("#newSecNum1").hasClass(INFO_ERROR)) && (!$("#newSecNum3").hasClass(INFO_ERROR))
								&& (!$("#newSecNum4").hasClass(INFO_ERROR)) && (!$("#newSecNum5").hasClass(INFO_ERROR))){
	                    $("<label>").addClass(INFO_ERROR).prop("id", "label_secNum").prop("for", $input.prop("id"))
	                        .text($input.data("data-key-req-msg") || ERR_SECNUM)
	                        .insertAfter($inputFin);
	                }
				//COMPROBACIÓN de vacío al salir								
				}else if (isNaN(value)){
						if (!$input.hasClass(INFO_ERROR)) {					
		                    $input.toggleClass(INFO_ERROR, true);
						}
		                    if((!$("#newSecNum1").hasClass(INFO_ERROR)) && (!$("#newSecNum3").hasClass(INFO_ERROR))
									&& (!$("#newSecNum4").hasClass(INFO_ERROR)) && (!$("#newSecNum5").hasClass(INFO_ERROR))){
		                    $("<label>").addClass(INFO_ERROR).prop("id", "label_secNum").prop("for", $input.prop("id"))
		                        .text($input.data("data-key-req-msg") || ERR_SECNUM)
		                        .insertAfter($inputFin);
		                }
				}else{
					$input.toggleClass(INFO_ERROR, false);
					if((!$("#newSecNum1").hasClass(INFO_ERROR)) && (!$("#newSecNum3").hasClass(INFO_ERROR))
							&& (!$("#newSecNum4").hasClass(INFO_ERROR)) && (!$("#newSecNum5").hasClass(INFO_ERROR))){
	                   $("#label_secNum").remove(".infoerror");
					}   
				}
					
			}else if($input.attr("id")=="newSecNum3"){
				alert('miau');
			}
			
			
			
		});
		
		//VALIDATE BOTON B1
		$(".radioPIDB1").on("click",function (e) {
			
			var $label, $input = $(e.target), value = $input.val(), $pos = '';
			if ($('.inputgroup').length) {
				$pos = $('.inputgroup');
			} else {
				$pos =  $input;
			}	
			
			var attr = $("#buttonB1").attr("disabled");
			
			if ($input.attr("id")=="pidChoose"){
				var valPID = $("#usuario_attPersonalIDB1").val();
				
				if(valPID!='' && (value && ONLY_NUMBERS_RE.test(value)) && valPID.length==10){
					if (typeof attr !== typeof undefined && attr !== false) {
						$("#buttonB1").removeAttr("disabled");
					}
				}else{
					$("#buttonB1").attr("disabled","true");
				}
				
			}else{
				if ($("#usuario_attPersonalIDB1").hasClass(INFO_ERROR)) {
					$("#usuario_attPersonalIDB1").toggleClass(INFO_ERROR, false);
					  $("#label_pid").remove(".infoerror");
				}	
				if (typeof attr !== typeof undefined && attr !== false) {
					$("#buttonB1").removeAttr("disabled");
				}
				
				
			}
		});
		//VALIDATE BOTON B2
		$(".radioPIDB2").on("click",function (e) {
			
			var $label, $input = $(e.target), value = $input.val(), $pos = '';
			if ($('.inputgroup').length) {
				$pos = $('.inputgroup');
			} else {
				$pos =  $input;
			}	
			
			var attr = $("#buttonB2").attr("disabled");
			
			if ($input.attr("id")=="pidChoose"){
				
				$("#usuario_attPersonalIDB2").toggleClass("isSelected",true);
				var valPID = $("#usuario_attPersonalIDB2").val();
				
				if(valPID!='' && (value && ONLY_NUMBERS_RE.test(value)) && valPID.length==10){
					if (typeof attr !== typeof undefined && attr !== false) {
						if(($("#usuario_newPassB2").val()!="")&&($("#usuario_newPassReenterB2").val()!="")
								&&(!$("#usuario_newPassB2").hasClass(INFO_ERROR))&&(!$("#usuario_newPassReenterB2").hasClass(INFO_ERROR))){
						$("#buttonB2").removeAttr("disabled");
						}
					}
				}else{
					$("#buttonB2").attr("disabled","true");
				}
				
			}else{
				
				$("#usuario_attPersonalIDB2").toggleClass("isSelected",false);
				if ($("#usuario_attPersonalIDB2").hasClass(INFO_ERROR)) {
					$("#usuario_attPersonalIDB2").toggleClass(INFO_ERROR, false);
					  $("#label_pid").remove(".infoerror");
				}	
				
				if (typeof attr !== typeof undefined && attr !== false) {
					if(($("#usuario_newPassB2").val()!="")&&($("#usuario_newPassReenterB2").val()!="")
							&&(!$("#usuario_newPassB2").hasClass(INFO_ERROR))&&(!$("#usuario_newPassReenterB2").hasClass(INFO_ERROR))){
					$("#buttonB2").removeAttr("disabled");
					}
				}
				
				
			}
		});
		  $('.showHidePass').on('click',  function(event){
	    	  
	    	  if($("#usuario_newPassA2").attr("type") == "password"){
	    		  $("#usuario_newPassA2").attr("type","text");
	    	  }else{
	    		  $("#usuario_newPassA2").attr("type","password");
	    	  }
	    	  
	          
	        });
		
	});
	
}(jQuery));

/**
* @function
* @name noJs
* @description Support no javascript in Vega
**/
(function($){
   "use strict";
   $(function(){
    var $selector = $('#JSSupport');
           if ($selector.length){ 
                   $selector.val('S');
           }
       });
}(jQuery));


/**
* @function
* @name avoidEnterDefault
* @description Avoid submit default for CreatID input (uses defaultActionLogon class)
**/
$(function() {
    "use strict";
    
    /*jshint validthis: true */
    function clickDefaultActionLogon(event) {
        if (event.which === 13) { // Enter
            if ($(this).closest('form').find('input.defaultActionLogon').prop("disabled")) {											
				event.preventDefault();							
            }
        }
    }

    $(':text, :password, :radio, :checkbox, select').keypress(clickDefaultActionLogon);
});

/**
* @function
* @name Paperfree popups control
* @description Paperfree popups support.
**/
(function($){
  "use strict";
  $(function(){
      // Selectors for the popups
      var modalConfirmation= $('.alertPopUp.popupConfirmation');
      var modalNoThanks = $('.alertPopUp.popupNoThanks');

      // When clicking in continue
      $('#alertConfirmPaperfree').on('click',  function(event){
        event.preventDefault();
        openPopup();
        modalNoThanks.hide();
      });

      // When clicking in the no thanks
      $('#alertNoThanks').on('click',  function(event){
        openPopup();
        modalConfirmation.hide();
      });
  });
}(jQuery));

/**
* @function
* @name migSummary popup control
* @description migSummary popup support.
**/
(function($){
  "use strict";
  $(function(){

      // When clicking in continue
      $('#migSumContinue').on('click',  function(event){
    	  
    	  
    	  if($('#migSumContinue').hasClass("notProvidedMail")){
    		if(!(($('#migSumContinue').hasClass("notProvidedMail"))&&($('#newEmailSection').hasClass("mailActivo"))
    				&&($('#emailInput').val()!="")&&($('#emailInputReenter').val()!=""))){

		    	  var modal = $(".alertPopUp"),
		          modalinfo = $(".alertPopUpInfo"),
		          modalstep = $(".alertPopUpStep");
		    	  
		    	  if (modal.size() > 0) {
		              var  overlay = $('<div tabindex="-1" id="greydiv" class="overlay hidden"/>').appendTo('body');
		              overlay.hide();
		          }
		    	  
		    	  event.preventDefault();
		          modalstep.show();   
		          overlay.show();
    	  }
    	  }
    	  
    	  
    	  
      });
      
      $('#buttonKeepPopup').on('click',  function(event){
    	  var modal = $(".alertPopUp"),
          modalinfo = $(".alertPopUpInfo"),
          modalstep = $(".alertPopUpStep");
    	  
    	  event.preventDefault();  
    	  modalstep.hide();
    	  $('#greydiv').remove();
          
          
      	  
        });
      
      $('#linkCambioMail').on('click',  function(event){
    	  
    	  $('#newEmailSection').addClass("mailActivo");
          
        });
      
      $('#linkCancelMail').on('click',  function(event){
    	  
    	  $('#newEmailSection').toggleClass("mailActivo", false);
    	  
          
        });
      
  });
}(jQuery));