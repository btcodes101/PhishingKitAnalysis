/*
 * @namespace ie7
 * @description exceptions for IE7
 * @copyright (c) 2010 Isban UK. All Rights Reserved.
 * @date    27/05/2014
 * @requires jQuery
 */


(function () {
"use strict";

var rules, rule, i , j,	styleSheets = document.styleSheets;

for(i = 0; i < styleSheets.length ; i += 1) {
	rules = styleSheets[i].rules; //cssRules standart
	for(j = 0; j < rules.length ; j += 1) {
		rule = rules[j];

		if(rule.style.display === "inline-block"){
			rule.style.zoom = "1";
			rule.style.display = "inline";
		}

	}
}

//Fix for IE7 grid rounding problems
$(function(){
	$(".rd-grid").each(function () {
		var t = $(this);
		var width = t.width();
		var tolerance = Math.ceil(width * 0.02);
		var current = 0;
		t.contents().each(function () {
			var c = $(this);
			if(c.prop("nodeType") != 1){
				c.remove();
				return;
			}
			current += c.width();
			if( (current + tolerance) >= width ){
				c.width(c.width()-(current - width));
				current = 0;
			}
		});
	});
});

$(function(){
	$(".rd-grid").each(function () {
		var t = $(this);
		var width = t.width();
		var tolerance = Math.ceil(width * 0.02);
		var current = 0;
		t.contents().each(function () {
			var c = $(this);
			if(c.prop("nodeType") != 1){
				c.remove();
				return;
			}
			current += c.width();
			if( (current + tolerance) >= width ){
				c.width(c.width()-(current - width));
				current = 0;
			}
		});
	});
});

//Fix for IE7 MenÃº
$(function(){
	$("#mainmenu li a").each(function (i) {
		var li = $(this).parent();
		li.addClass('item'+i);
		if($(this).hasClass('active')){
			styleSheets[0].addRule('#mainmenu .item'+i, 'background:#FFFFFF');
		}
		var top = parseInt((li.outerHeight() - $(this).outerHeight()) / 2)  + "px";
		styleSheets[0].addRule('#mainmenu .item'+i+' a', "top:"+top);
	});

});


//Fix list last-child border IE7
$(function(){
	$("#mainmenu ul li").last().addClass( "last" );
	$("#submenu l li").last().addClass( "last" );
	$(".guide ol li").last().addClass( "last" );
	$(".toolboxes .toolbox").last().addClass( "last" );
	
});

//Combos IE7 Fix

$(function(){
	$(".accountlist div.actions").find("select").on("focus",function(e){
		var t = $(this), offset = t.offset();
		t.data("width",t.css("width"))
		.css({"width": "auto","position":"absolute"})
		.offset(offset);
	}).on("blur", function(e){
		var t = $(this);
		t.css({"width": t.data("width"), "position":"inline"});
	})
});

$(function(){
	$(".security-question span.data select").on("focus",function(e){
		var t = $(this), offset = t.offset();
		t.data("width",t.css("width"))
		.css({"width": "auto","position":"absolute"})
		.offset(offset);
	}).on("blur", function(e){
		var t = $(this);
		t.css({"width": t.data("width"), "position":"inline"});
	})
});



}());



//Trim support for IE7
if(typeof String.prototype.trim !== 'function') {
    String.prototype.trim = function() {
        return this.replace(/^\s+|\s+$/g, ''); 
    }
}


$(function() {
 $("ul.linkList li a").append("<span>&#9658;</span>");
});
