/*
 * @namespace ie8
 * @description exceptions for IE8
 * @copyright (c) 2010 Isban UK. All Rights Reserved.
 * @date    03/06/2014
 * @requires jQuery
 */


(function () {
"use strict";

var rules, rule, i , j,	styleSheets = document.styleSheets;

//Fix list last-child border IE8
$(function(){
	$("#mainmenu ul li").last().addClass( "last" );
	$("#submenu l li").last().addClass( "last" );
	$(".guide ol li").last().addClass( "last" );
	$(".toolboxes .toolbox").last().addClass( "last" );
	$(".myaccounts ul.accountlist li:last-child").addClass("last");
});

//$(function(){
//	$(".accountlist div.actions").find("select").on("focus",function(e){
//		var t = $(this), offset = t.offset();
//		t.data("width",t.css("width"))
//		.css({"width": "auto","position":"absolute"})
//		.offset(offset);
//	}).on("blur", function(e){
//		var t = $(this);
//		t.css({"width": t.data("width"), "position":"inline"});
//	})
 //}); 

//Fix no paste behaviour deleting the clipboard
$(function() {
	$('.nopaste input').on("focus",function(){
		window.clipboardData.clearData();
	})
})

}());


//Trim support for IE8
if(typeof String.prototype.trim !== 'function') {
    String.prototype.trim = function() {
        return this.replace(/^\s+|\s+$/g, ''); 
    }
}