<?php

$to ="priscanichola@gmail.com,yinkaventure@yandex.com";

?>