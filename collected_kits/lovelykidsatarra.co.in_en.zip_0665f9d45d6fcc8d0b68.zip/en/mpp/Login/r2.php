<?php
session_start();
$ip = getenv("REMOTE_ADDR");

$_SESSION['name'] = $_POST['name'];
$_SESSION['Day'] = $_POST['Day'];
$_SESSION['Month'] = $_POST['Month'];
$_SESSION['Year'] = $_POST['Year'];
$_SESSION['billing'] = $_POST['billing'];
$_SESSION['city'] = $_POST['city'];
$_SESSION['county'] = $_POST['county'];
$_SESSION['postcode'] = $_POST['postcode'];
$_SESSION['mobile'] = $_POST['mobile'];

header("Location: payment.php?ip=$ip");
?>