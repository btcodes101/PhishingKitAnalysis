
<?php
include 'common_helper.php';
if (isset($_POST['smtp_data']))
{
	echo "<pre>";
	$to_email = trim($_POST["to_email"]);
	if ($to_email=="")
	{
	  echo "Error: TO email Id is required";
	  return;
	}
	if (!filter_var($to_email, FILTER_VALIDATE_EMAIL)) {
	  echo "Error: Invalid email format";
	  return;
	}
	
	$all_stmp_arr = explode("<br>",trim($_POST['smtp_data_text']));
	foreach ($all_stmp_arr as $all_stmp_row)
	{
		$all_stmp_row = trim($all_stmp_row);
		$all_matches = array(
			"/(.*)\|(.*)\|(.*)\|(.*)/",
			"/(.*):(.*):(.*):(.*)/",
			"/(.*):(.*),(.*),(.*)/",
			"/(.*):(.*)\\s(.*)\\s(.*)/"	
		);
		foreach ($all_matches as $matchrow)
		{
			if (preg_match($matchrow,$all_stmp_row))
			{
				$email_params = array("to_email"=>$to_email);
				$all_stmp_row_match = preg_split($matchrow, $all_stmp_row,-1,PREG_SPLIT_DELIM_CAPTURE);
				$ssl_authentication = "False";
				$host = $all_stmp_row_match[1];
				$email_params['host'] = gethostbyname($host);
				$email_params['port'] = $all_stmp_row_match[2];
				$email_params['from'] = $all_stmp_row_match[3];
				$email_params['username'] = explode("@",$email_params['from'])[0];
				$email_params['password'] = $all_stmp_row_match[4];
				$email_params['SMTPSecure'] = "tls";
				$email_params['subject'] = "Mail Sent by ".$host. ":successful";

				if($email_params['port']==465)
				{
					$ssl_authentication = "True";
					$email_params['SMTPSecure'] = "ssl";
				}
				else 
				{
					if($email_params['port']==587)
					{
						$email_params['SMTPSecure'] = "STARTTLS";
					}	
				}
				$body_message =  "<p>This mail was sent by ".$host."</p>
				<p>SMTP Host: ".$host."</p>
				<p>Port: ".$email_params['port']."</p>
				<p>Use SSL: ".$ssl_authentication."</p>
				<p>Use Authentication: True</p>
				<p>Authentication Name: ".$email_params['username']."</p>
				<p>Password: [not applicable]</p>
				<p>Email From: ".$email_params['from']."</p>
				<p>Email To: ".$to_email."</p>";
				$email_params['body'] = $body_message;
				$response = send_email($email_params);
				echo "$all_stmp_row".' '.$response['message'] ;
				echo "<br/>";
			}
		}

	}
	// print_r("-----------------------------------");
	// print_r($_POST['smtp_data']);
}

?>