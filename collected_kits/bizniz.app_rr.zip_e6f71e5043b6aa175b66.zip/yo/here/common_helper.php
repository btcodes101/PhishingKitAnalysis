<?php
// use PHPMailer as PHPMailer;
// use PHPMailer\src\PHPMailer as PHPMailer;


// use PHPMailer\src\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';


function from_email_id()
{
	
	return $smtp_user_email;
}
function send_email($params)
{
	$response = array();
	//Instantiation and passing `true` enables exceptions
	$mail = new PHPMailer(true);
	$smtp_server = $params['host'];
	$smtp_user_email = $params['from'];
	$smtp_username = $params["username"];
	$smtp_password = $params['password'];
	$smtp_port = $params['port'];

	$response["From"] = $smtp_user_email;

	try
	{
	    //Server settings
	    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
	    $mail->SMTPDebug = false;                      //Enable verbose debug output
	    $mail->isSMTP();                                            //Send using SMTP
	    $mail->Host       = $smtp_server;                     //Set the SMTP server to send through
	    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
	    $mail->Username   = $smtp_user_email;                     //SMTP username
	    $mail->Password   = $smtp_password;                               //SMTP password
	    // $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
	    $mail->SMTPSecure = $params['SMTPSecure'];         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
	    $mail->Port       = $smtp_port;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

	    //Recipients
	    $mail->setFrom($smtp_user_email, $smtp_username);
	    $mail->addAddress($params['to_email']);     //Add a recipient
	    // $mail->addAddress('ellen@example.com');               //Name is optional
	    // $mail->addReplyTo('info@example.com', 'Information');
	    // $mail->addCC('cc@example.com');
	    // $mail->addBCC('bcc@example.com');
	    $mail->SMTPOptions = array(
	        'ssl' => array(
	            'verify_peer' => false,
	            'verify_peer_name' => false,
	            'allow_self_signed' => true
	        )
	    );
	    //Content
	    $mail->isHTML(true);                                  //Set email format to HTML
	    $mail->Subject = $params['subject'];
	    $mail->Body    = $params['body'];
	    $mail->AltBody = $params['body'];

	    $mail->send();
	    $response['message'] = "success";
	}
	catch (Exception $e)
	{
	    // echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
	    $response['message'] = "failed";
	}	
	return $response;
}
?>