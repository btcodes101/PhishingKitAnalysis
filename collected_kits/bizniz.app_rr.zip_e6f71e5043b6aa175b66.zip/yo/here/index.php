<?php 

$check_data = array(
		array("to_email"=>"jerrypatel1337@gmail.com")
);


// foreach ($check_data as $check_row)
// {
// 	send_email(array("to_email"=>$check_row['to_email']));
// }

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<script src="js/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<style type="text/css">
		textarea{
			white-space: pre-wrap;
		}
		.center_div{
		    margin: 0 auto;
		    width:70%
		}
		#cover {
		    /*background: #222 url('https://unsplash.it/1920/1080/?random') center center no-repeat;*/
		    /*background-size: cover;*/
		    height: 100%;
		    text-align: center;
		    display: flex;
		    align-items: center;
		    position: relative;
		}

		#cover-caption {
		    width: 100%;
		    position: relative;
		    z-index: 1;
		}

		/* only used for background overlay not needed for centering */
		form:before {
		    content: '';
		    height: 100%;
		    left: 0;
		    position: absolute;
		    top: 0;
		    width: 100%;
		    /*background-color: rgba(0,0,0,0.3);*/
		    z-index: -1;
		    border-radius: 10px;
		}

	</style>
	<script>
		$(function(){
			$("body").on("click","textarea",function(){
				$("input[name='smtp_data_text']").val(this.value.replace(/\n/g, '<br>\n'))
			});
			$("body").on("keydown","textarea",function(){
				$("input[name='smtp_data_text']").val(this.value.replace(/\n/g, '<br>\n'))
			});
			$("body").on("focusout","textarea",function(){
				$("input[name='smtp_data_text']").val(this.value.replace(/\n/g, '<br>\n'))
			});

			$('[name="submit"]').click(function(e){
				$('#output').val("");
				e.preventDefault();
				$.ajax({
				    type: 'POST',
				    url: 'ajax.php',
				    data:$('[name="smtpForm"]').serializeArray(),
				    beforeSend: function() {
				           $('#output').html("Please wait...");
				           $('[name="submit"]').attr("disabled",true);
				       },
				    success: function(data){
				    	$('#output').html(data);
				    	$('[name="submit"]').attr("disabled",false);

				    }
				});
			});
			
			
		});
		
	</script>
</head>
<body>
	<section id="cover" class="min-vh-100">
	    <div id="cover-caption">
	        <div class="container">
	            <div class="row">
	                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-10 mx-auto text-center form p-4">
	                    <div class="px-2">
	                        <form action="#" method ="POST" name="smtpForm">
			  <div class="form-group">
			    <label for="exampleInputEmail1">Smtp Details</label>
			    <textarea class="form-control" name="smtp_data" rows="10" cols="50" id="exampleInputEmail1" aria-describedby="emailHelp"></textarea>
			    <input type="hidden" name="smtp_data_text">
			  </div>
			  <div class="form-group">
			    <label for="exampleInputPassword1">To Email ID</label>
			    <input type="text" class="form-control" name="to_email" id="exampleInputPassword1" placeholder="Email ID">
			  </div>
			  <input type="submit"name="submit" value="SUBMIT"  class="btn btn-primary">
			</form>
			<p id="output"></p>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</section>
	
</body>
</html>

