<?php


echo "\r\n<!DOCTYPE html>\r\n<html >\r\n<head>\r\n  <meta charset=\"UTF-8\">\r\n  <title>--> itech PassCode 4<--</title>\r\n  \r\n      <link rel=\"stylesheet\" href=\"style1.css\">\r\n<meta name=\"viewport\" content=\"initial-scale=1, maximum-scale=1\">\r\n  \r\n</head>\r\n\r\n<body>\r\n<br><br>\r\n  <h1> itech Passcode 4</h1>\r\n\r\n<div class=\"btn-container\">\r\n<br><br>\r\n   <a href=\"linkbyimei.php\" class=\"btn\">Create New Link </a><br><br>\r\n  <a href=\"block.php\" class=\"btn\">Block Link</a>\r\n</div>\r\n  \r\n  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>\r\n\r\n  \r\n</body>\r\n</html>\r\n";

?>