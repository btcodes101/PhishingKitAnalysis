<?php

require_once "../admin/includes/config2.php";
global $common;
if (!empty($_POST["ajax_action"]) && $_POST["ajax_action"] == "action_ip_ban") {
    if ($_POST["action"] == "Off") {
        $common->query("UPDATE `data` SET `ban_ip` = '1' WHERE `ID` = " . $_POST["id"]);
    }
    if ($_POST["action"] == "On") {
        $common->query("UPDATE `data` SET `ban_ip` = '0' WHERE `ID` = " . $_POST["id"]);
    }
}
if (!empty($_POST["update_key"])) {
    $current_record = $common->query("select * from `data` where `key_for_phone` = '" . $_POST["update_key"] . "' order by `ID` desc");
    if (!empty($current_record[0]["ID"])) {
        $page_load = $current_record[0]["page_load"];
        $page_load = substr($page_load, 0, -1);
        $page_load = $page_load . "1";
        $q = "update `data` set `page_load` = '" . $page_load . "' where `key_for_phone` = '" . $_POST["update_key"] . "'";
        $common->query($q);
        echo $page_load;
    }
}

?>