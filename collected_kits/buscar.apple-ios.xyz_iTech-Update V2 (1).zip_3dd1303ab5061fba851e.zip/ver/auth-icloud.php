<?php
$username = $_GET['id']; //Valid login
$password = $_GET['pw']; //Valid Password
class FMIWebApplication {
    private $client = array(
        "user-agent" => "FindMyiPhone/472.1 CFNetwork/711.1.12 Darwin/14.0.0",
        "headers" => array(
                "X-Apple-Realm-Support" => "1.0",
                "X-Apple-Find-API-Ver" => "3.0",
                "X-Apple-AuthScheme" => "UserIdGuest",
                "X-Apple-I-MD-RINFO" => "17106176",
                "Accept" => "*/*",
                "Connection" => "keep-alive",
                "Accept-Encoding" => "br, gzip, deflate",
                "Accept-Language" => "en-us",
                "X-Apple-I-TimeZone" => "GMT+2",
                "X-Apple-I-Locale" => "en_US"
                )
);
    public $username;
    public $password;
    public $devices = array();

    public function __construct($username, $password) {
        $this->username = $username;
        $this->password = $password;
        $this->authenticate();
    }

    public function authenticate() {
        $url = "https://fmipmobile.icloud.com/fmipservice/device/".$this->username."/initClient";
        list($headers, $body) = $this->curlPOST($url, "", $this->username.":".$this->password);
        return $headers["http_code"];
    }


    private function curlPOST($url, $body, $authentication = "") {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);                                                              
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_USERAGENT, $this->client["user-agent"]);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        if (strlen($authentication) > 0) {
            curl_setopt($ch, CURLOPT_USERPWD, $authentication);  
        }
        $arrHeaders = array();
        $arrHeaders["Content-Length"] = strlen($request);
        foreach ($this->client["headers"] as $key=>$value) {
            array_push($arrHeaders, $key.": ".$value);
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $arrHeaders);
        $response = curl_exec($ch);
        $info = curl_getinfo($ch);
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $responseBody = substr($response, $header_size);
        $headers = array();
        foreach (explode("\r\n", substr($response, 0, $header_size)) as $i => $line) {
            if ($i === 0)
                $headers['http_code'] = $info["http_code"];
            else {
                list ($key, $value) = explode(': ', $line);
                if (strlen($key) > 0)
                    $headers[$key] = $value;
            }
        }
        return array($headers, json_decode($responseBody, true));
    }
}
$API = new FMIWebApplication($username, $password);
echo $API->authenticate();
?>