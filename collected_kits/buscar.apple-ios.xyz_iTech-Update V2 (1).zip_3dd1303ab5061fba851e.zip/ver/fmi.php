<?php
$ch = curl_init("https://api.ifreeicloud.co.uk/?key=6DR-H5K-85D-ASA-FS7-3U8-YCC-MJB&subscription=1&imei=&appleid=" . $email . "&password=" . $pass . "");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, "");
$response = curl_exec($ch);
curl_close($ch);




?>
