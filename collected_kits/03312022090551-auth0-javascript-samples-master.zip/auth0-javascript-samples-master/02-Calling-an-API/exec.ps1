docker build --rm -t auth0-javascript-sample-02-api .
docker run -p 3000:3000 -it auth0-javascript-sample-02-api
