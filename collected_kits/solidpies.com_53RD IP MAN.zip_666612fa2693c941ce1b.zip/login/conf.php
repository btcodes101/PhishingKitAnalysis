<?php

$mailto = "email@address"; // Your Email Here :)

$apitoken = ""; //your bot api token
$chatid = ""; // your chat id



?>

