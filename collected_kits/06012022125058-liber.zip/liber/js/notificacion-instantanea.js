var notificacionMsg = [];

function cargarNotificacionInstantanea() {
	$.getJSON('https://www.liberbank.es/api/notifications.json', function(data) {
        notificacionMsg = data;
        mostrarNotificacionInstantanea();
    });
}

function mostrarNotificacionInstantanea() {
	if (notificacionMsg != [] && notificacionMsg.length != 0) {
		if (notificacionMsg[0].location.indexOf("login") != -1) {
			document.getElementById("notif-instantanea").innerHTML = '<div class="notificacion-instantanea background-'	+ notificacionMsg[0].message_type + ' content">'
			+ '<div class="row"><i class="fas ' + iconoMensaje() + ' fa-1-5x col-2 col-lg-1 col-xl-1 col-md-2 col-sm-2 d-flex align-items-center padding-left"></i>'
			+ '<span class="col-lg-11 col-xl-11 col-sm-10 col-md-10 col-10 d-flex align-items-center">' + notificacionMsg[0].message + '</span></div></div>';
			comprobarFooter();
		}
	}
}

function iconoMensaje() {
	icono = "";
	switch (notificacionMsg[0].message_type) {
		case 'notice':
		case 'advertising':
			icono = 'icono-bullet-circulo-relleno color-verde-2'; break;
		case 'warning':
			icono = 'icono-bullet-circulo-relleno color-amarillo-oro'; break;
		case 'error':
			icono = 'icono-bullet-circulo-relleno color-rojo'; break;
	}
	return icono;
}