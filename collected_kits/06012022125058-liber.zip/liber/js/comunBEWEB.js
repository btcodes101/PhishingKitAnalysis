function lanzaAction(formulario,operacion){
	formulario.action="/BEWeb/2048/4485/"+operacion+".action";
	formulario.submit();
	formulario.action=rutaCGI;
}
function cambiaAction(formulario,operacion){
	formulario.action="/BEWeb/2048/4485/"+operacion+".action";
}