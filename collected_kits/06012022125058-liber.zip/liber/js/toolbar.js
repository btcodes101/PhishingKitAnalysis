var tituloAnterior;
var opButtonAnterior;

function toolbarMostrarBotonAtras(texto, enlace) {
	// Se debaj por compatilibidad de c�digo
}

function toolbarMostrarTitulo(titulo) {
	var capa = $('#toolbarTitulo');
	capa.html(titulo.replace(/&nbsp;/gi,' ').replace(/ +/g, ' '));
	capa.show();
}

function cambiarTitulo(titulo) {
	var capa = $('#toolbarTitulo');
	tituloAnterior = capa.innerHTML;
	capa.html(titulo.replace(/&nbsp;/gi,' ').replace(/ +/g, ' '));
	capa.show();
}

function restaurarTitulo() {
	var capa = $('#toolbarTitulo');
	capa.html(tituloAnterior);
	capa.show();
}

function cambiarOpButton(elemento) {
	// Se deba por compatilibidad de c�digo
}

function restaurarOpButton() {
	// Se deba por compatilibidad de c�digo
}

function mostrarOpButton() {
	// Se deba por compatilibidad de c�digo
}

function ocultarOpButton() {
	// Se deba por compatilibidad de c�digo
}