// beweb/4485/js/funAjax.js
// * * * * * * * * * * * *
function MiAjax(url){
	this.miurl = url;
	this.rofin = false;
	this.incremento = 0;
	var browser = navigator.appName;
	if (browser == "Microsoft Internet Explorer") this.ro = new ActiveXObject("Microsoft.XMLHTTP");
	else this.ro = new XMLHttpRequest();
}
MiAjax.prototype.lanzar = function(fnc){
	var URL = this.miurl + (this.incremento++);
	this.ro.open('get',URL,true);
	this.ro.onreadystatechange = fnc;
	this.ro.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	this.ro.setRequestHeader('Accept-Charset', 'UTF-8');
	this.ro.send(null);
}
// * * * recuperacion xml
function getData(obj){
	if (obj==null) return "";
	else return obj.data;
}
 

var ajaxJQ = {
		ops : {
			type: 'POST',
			datatype: "XML",
			url: "",
			data: ""			
		},
		init : function(opsObj,callback,callbackError) {
			if ($.isFunction(callback)) {
				ajaxJQ.ajaxCallback = callback;
			}
			if ($.isFunction(callbackError)) {
				ajaxJQ.ajaxCallbackError = callbackError;
			}

			for (var name in ajaxJQ.ops) {
				ajaxJQ.ops[name] = opsObj[name] === undefined ? ajaxJQ.ops[name] : opsObj[name];
			}
			if(ajaxJQ.ops.url == "") {
				return false;
			}
			ajaxJQ.request();
		},
		request : function(){
			$.ajax({
			    type: ajaxJQ.ops.type,
			    dataType: ajaxJQ.ops.datatype,
				url: ajaxJQ.ops.url,
			    data: ajaxJQ.ops.data,
			    error: function( objeto, quepaso)
			    {
			    	if ($.isFunction(ajaxJQ.ajaxCallbackError)) {
			    		ajaxJQ.ajaxCallbackError( objeto, quepaso);
			    	}
			    },
			    success: function( _respuesta )
			    {
			    	if ($.isFunction(ajaxJQ.ajaxCallback)) {
			    		ajaxJQ.ajaxCallback( _respuesta);
			    	}
			    },
			    timeout: 100001
			});
		},
		showError : function(errorOps) {
			
			var _ops = {
				title : "",
				message :"",
				container : "",
				action :""
			}
			for (var name in _ops) {
				_ops[name] = errorOps[name] === undefined ? _ops[name] : errorOps[name];
			}			
			
			if (_ops.container == ""){
				alert("error al mostrar el error");

				return;
			}	
			var _html = "<div id='error'>";
				_html += "<div class='encabezado'>";
				_html += "<div class='titular'>"+ _ops.title +"</div>";
				_html += "<div style='clear:both; margin:0px;'><img src='"+rutaEstaticos+"/images/t_sizer.gif' alt='' width='1' height='1' /></div>";
				_html += "</div>";
				_html += "<div style='width: 98%' class='redondeo'><div class='c1'><div class='c2'><div class='c3'><div class='c4'><div class='c5'>";
				_html += _ops.message;
				_html += "</div></div></div></div></div></div>";
				_html += "<div style='clear:both;'><img src='"+rutaEstaticos+"/images/t_sizer.gif' alt='' width='1' height='10' /></div>";

				if(_ops.action != ""){
					_html += "<div class='botones'><div class='botoncentro'>";
					_html += "<a href='javascript:" + _ops.action + "'><img src='"+rutaEstaticos+"/images/bot_atras.png' alt='' /></a>";
					_html += "</div></div>";					
				}
				_html += "</div>";
				
				$(_ops.container).html(_html);								
		}
	}
