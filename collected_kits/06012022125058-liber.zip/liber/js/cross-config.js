//g
var cookiesPath = 'cookies_bd';
var cookiesParam = '';

const indexCrossDomainId = 'crossDomainUtilsJS';
const crossConfigId = 'crossConfigJs';
const crossDomainVersion = 'cross-domain-new';
const gtmScriptId = 'gtmJS';
// const crossDomainVersion = 'cross-domain';

const listaEntornosPrueba = ['comercial-staging', 'bedesa', 'bedemo'];

const BD = 'bd';
const WP = 'wp';
const PS = 'ps';

const pathList = [
    {
        id: BD,
		path: 'cookies_bd',
		viewPath: BD + "/",
		css: '',
		loginCss: ''
    },
    {
        id: WP,
		path: 'cookies_v5_wp',
		viewPath: WP + "/",
		css: 'cookies.css',
		loginCss: 'cookies-login.css'
	},
	{
		id: PS,
		path: 'cookies_v5_wp',
		viewPath: PS + "/",
		css: 'cookies.css',
		loginCss: ''
	}
];



function initCrossDomain() {
	if (!String.prototype.endsWith) {
		String.prototype.endsWith = function(search, this_len) {
			if (this_len === undefined || this_len > this.length) {
				this_len = this.length;
			}
			return this.substring(this_len - search.length, this_len) === search;
		};
	}
	initContenedor();
	inyectarCrossDomain();
}

function initContenedor() {
	// Obtenemos los parÃ¡metros del script
	const params = getParamList(document.getElementById(crossConfigId).src);
	cookiesParam = getParam(params, 'CA');

	// Cargamos el path de las cookies
	if (cookiesParam) {
		cookiesPath = getCookiesPath(cookiesParam);
	}

	console.log('Contenedor:', cookiesPath);
}

function getCodigoGTM(entornoPruebas, entornoProd) {
	var local = window.location.hostname;
	var entornoPruebas = listaEntornosPrueba.indexOf(local) != -1;
	var codigo = entornoPruebas ? entornoPruebas : entornoProd
	return codigo;
}

function initDatalayer(entornoPruebas, entornoProd, appDataLayer) {
	
	const optparams = getOptions();

	const codigo__GTM = getCodigoGTM(entornoPruebas, entornoProd);
	dataLayer = appDataLayer || window['dataLayer'] || [];

	(function (w, d, s, l, i) {
		w[l] = w[l] || []; w[l].push({
			'gtm.start':
				new Date().getTime(), event: 'gtm.js'
		}); var f = d.getElementsByTagName(s)[0],
			j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
				'https://www.googletagmanager.com/gtm.js?id=' + i + dl + idEnv; f.parentNode.insertBefore(j, f);
	})(window, document, 'script', 'dataLayer', codigo__GTM);

	if (optparams !== 'na') {
		try {
			changeCookiesConfig(optparams);
		} catch (error) {
			console.warn('You cannot change the cookies config in this app');
		}
	} else {
		console.log('dataLayer:' + optparams)
	}
}

function processParams(params) {
	params = params || '';
	const p = params.split('?');
	const parametros = {};
	if (p && p.length > 1) {
		const aux = p[1].split('&');

		let nombreParam;
		let valueParam;

		for (let i = 0; i < aux.length; i++) {
			const param = aux[i];
			const pair = param.split('=');
			nombreParam = pair[0];
			valueParam = pair[1];

			parametros[nombreParam] = valueParam;
		}
	}

	return parametros;
}

function getParamList(src) {
	// const qs = document.getElementById('crossConfigJs').src.match(/\w+=\w+/g);
	const parametros = processParams(src);
	return parametros;
}

function getParam(params, name) {
	let value = '';
	if (params && params[name]) {
		value = params[name];
	}

	return value;
}

function __getParamFromURL(_param) {
	const parametros = getParamList(window.location.href);
	const param = getParam(parametros, _param);

	return param;
}

function getOptions() {
	const opt = document.currentScript.src;
	const optparams = opt.substring(opt.lastIndexOf('=') + 1, opt.length);
	console.log('APLICACION ' + optparams);

	let result = '';
	if (optparams && optparams.length > 0) {
		result = optparams;
	} else {
		result = 'na';
	}

	return result;
}

function getPathInfo(id) {
	id = id ||'';
	let info;
	for (let i = 0; i < pathList.length && !info; i++) {
		const data = pathList[i];
		if (data.id === id.toLowerCase()) {
			info = data;
		}
	}

	return info;
}

function getCookiesPath(id) {
	id = id || '';
	let path = '';
	const data = getPathInfo(id);
	
	if (data) {
		path = data.path;
	}

    return path;
}

function getViewPath(id) {
	id = id || '';
	const info = getPathInfo(id);
	let path = '';

	if (info) {
		path = info.viewPath;
	}

	return path;
}

function inyectarCrossConfig() {
	//const src = `https://www.liberbank.es/system/wilson_cms/files_store/${crossDomainVersion}/cross-config.js`;
	const src = "https://www.liberbank.es/system/wilson_cms/files_store/" + crossDomainVersion + "/cross-config.js";
	inyectarScript(crossConfigId, src);
}

function inyectarCrossDomain() {
	const id = 'crossJs';
	//const src = `https://www.liberbank.es/system/wilson_cms/files_store/${crossDomainVersion}/cross-domain.js`;
	const src = "https://www.liberbank.es/system/wilson_cms/files_store/"+ crossDomainVersion + "/cross-domain.js";
	inyectarScript(id, src);
}

function inyectarCookies() {
	const id = 'cookiesJs';
	//const src = `https://www.liberbank.es/system/wilson_cms/files_store/${cookiesPath}/externals/cookies/cookies.js?v=${cookiesParam}`;
	const src = "https://www.liberbank.es/system/wilson_cms/files_store/"+ cookiesPath + "/externals/cookies/cookies.js?v=" + cookiesParam;
	inyectarScript(id, src);
}

function inyectarCookiesLoader() {
	const idCookiesPath = 'cookiesLoader';
	//const urlCookiesPath = `https://www.liberbank.es/system/wilson_cms/files_store/${crossDomainVersion}/cookies-utils.js`;
	const urlCookiesPath = "https://www.liberbank.es/system/wilson_cms/files_store/" + crossDomainVersion + "/cookies-utils.js";
	inyectarScript(idCookiesPath, urlCookiesPath);
}

function inyectarScript(id, src) {
	const cookiesScript = document.createElement('script');
	cookiesScript.id = id;
	cookiesScript.src = src;
	document.head.appendChild(cookiesScript);
}

function getUrlGtmScript() {
	const url = "https://www.liberbank.es/system/wilson_cms/files_store/" + cookiesPath + "/externals/cookies/" + cookiesParam + "/gtm/gtm.js";
	return url;
}

// Iniciamos Cross-Domain
initCrossDomain();