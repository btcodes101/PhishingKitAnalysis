<!DOCTYPE html>
	<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
	<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
	<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
	<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
    
        <title>Login - Linkt</title>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="description" content="" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="format-detection" content="telephone=no" />  
        <meta name="apple-itunes-app" content="app-id=1166823295" />
		<meta name="google-play-app" content="app-id=com.transurban.linkt" />
		<script type="text/javascript" src="https://manage.linkt.com.au/retailweb/ruxitagentjs_ICA2SVfhjqrux_10177191024092634.js" data-dtconfig="app=a4a0e9efac740b9f|cuc=yz7ckjw8|featureHash=ICA2SVfhjqrux|md=#pageIdentifier@value=a#pageIdentifier@value,span.fl=aspan.fl,mdcc1=a#emailAddress@value|lastModification=1602480977452|vcv=2|dtVersion=10177191024092634|tp=500,50,0,1|rdnt=1|uxrgce=1|uxdcw=1500|vs=2|agentUri=https://manage.linkt.com.au/retailweb/ruxitagentjs_ICA2SVfhjqrux_10177191024092634.js|reportUrl=https://manage.linkt.com.au/retailweb/rb_bf52197vme|rid=RID_-1402602491|rpid=1258873661|domain=linkt.com.au"></script><link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/css/normalize.css"/>
	<link rel="shortcut icon" type="image/x-icon" href="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/img/icons/favicon.ico" />
	<link rel="icon" type="image/x-icon" href="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/img/icons/favicon.ico">
	<link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/vendor/fancybox/jquery.fancybox.css"/>
	<link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/vendor/footable/footable.core.min.css"/>
	<link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/jquery-ui.css"/>
	<link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/css/main.css"/>		
	<link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/css/datepicker.css"/>
	<link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/css/media-queries.css"/>
	<link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/vendor/headerui/header-footer-linkt.css"/>
	
	<link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/css/print.css" type="text/css" media="print" />
	

	<link rel="stylesheet" href="https://manage.linkt.com.au/retailweb/resources/common/css/iglide-common.css"/>
	<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/modernizr-2.6.2.min.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/jquery-1.10.2.min.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/jquery-ui.min.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/jquery.preventDoubleSubmit.js"></script>
<script>window.DDIGITAL = window.DDIGITAL || {};</script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/headerui/_modernizr-custom.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/headerui/header-footer-min.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/cloudflare/lottie.min.js"></script>
<!-- Debug - 'new' -->

<div class="viewport clearfix">
	<div class="frame clearfix ">
		<div
			class="outer-container ">

			<div class="outer-wrap">
				<div class="inner-wrap" id="inner-wrap">

					<div id="header" class="header theme--brisbane disableFromPrint">
						<div class="top cf">								

							<div class="header__wrapper">
								<a href="#nav" class="nav-toggle js-offscreen-toggle"><span
									class="vh">Open navigation</span></a>
								<div class="logo">
									<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQlPfkmepweGSYIoaBgxfYmIr2eLjPgDMk4Rw&usqp=CAU" alt="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQlPfkmepweGSYIoaBgxfYmIr2eLjPgDMk4Rw&amp;usqp=CAU" width="126" height="86"><a href="javascript:openContentPage('', 'Main','Open navigation');"> 
									</a>
								</div>
								<div class="header__actions">
									<div class="header__nav fn_header__nav ">
										<div class="navbar">
											&nbsp;</div>
									</div>
									<!-- //header__btns -->
								</div>
								<!-- //header__actions -->
							</div>
							<!-- //header__wrapper -->
						</div>
						<!-- //top -->
					</div>
					<!-- //header -->
					<div id="nav"
						class="offscreen-nav fn_offscreen-nav js-offscreen-nav disableFromPrint"
						role="navigation" tabindex="-1" data-offscreen-at="0,m">
						<a href="#" class="nav-close"><span class="icon icon--close"
							style="background-image: none;"><svg
									xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19 19">
									<path class="fill"
										d="M1.3 19c.3 0 .6-.1.9-.4l7.3-7.3 7.3 7.3c.2.2.6.4.9.4.3 0 .6-.1.9-.4.5-.5.5-1.3 0-1.8l-7.3-7.3 7.3-7.3c.2-.3.4-.6.4-.9s-.1-.7-.4-.9c-.5-.5-1.3-.4-1.7 0L9.5 7.7 2.2.4C1.9.1 1.6 0 1.3 0 .9 0 .6.1.4.4c-.3.2-.4.5-.4.9s.1.6.4.9l7.3 7.3-7.3 7.3c-.3.3-.4.6-.4 1 0 .3.1.6.4.9.2.2.6.3.9.3z"></path></svg></span>
							Close</a>

						<div class="nav-account">
								<a href="https://manage.linkt.com.au/retailweb/login"
									onclick=" return invokeNavigationBar_AA('authenticatedTopNav', 'Main','Log in');"
									class="btn fn_btn--login btn--login"> <!-- editable icon-->
									<span class="icon icon--login icon--white"
									style="background-image: none;"><svg
											xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14.4 14.4">
											<path class="fill" d="M7.2 0C3.2 0 0 3.2 0 7.2s3.2 7.2 7.2 7.2 7.2-3.2 7.2-7.2S11.2 0 7.2 0zm0 3.6c.8 0 1.4.7 1.4 1.4 0 .8-.6 1.4-1.4 1.4S5.8 5.8 5.8 5s.6-1.4 1.4-1.4zm2.5 5.9c0 .9-1 1.1-2.5 1.1-1.6 0-2.5-.2-2.5-1.1v-.8c0-.9.8-1.7 1.7-1.7h1.7c.9 0 1.7.7 1.7 1.7l-.1.8z"></path></svg></span>
									<span class="text">Log in</span>									
								</a>
							</div>
						<nav>
							<div class="nav-inner">
								<h2 class="visuallyhidden">
									Navigation</h2>
								<div class="nav-main">
									<ul>
										<li class=""><a
											href="javascript:openContentPage('', 'Main','Home');"
											class="nav-lvl1 "> Home</a></li>





										<li class=""><a href=
											"javascript:openContentPage('help', 'Main','Help');" class="nav-lvl1 ">
												Help</a></li>
									</ul>
								</div>
								<div class="nav-supplementary nav-supplementary--offscreen fn_nav-supplementary--offscreen">
    </div>
						</nav>
					</div>

					<script>
function openContentPage(subpath, navigationBarLocation, linkName){	
	
	if(navigationBarLocation != null && navigationBarLocation != undefined && navigationBarLocation != '' && linkName != null && linkName != undefined && linkName != '')
	{
		invokeNavigationBar_AA('authenticatedTopNav', navigationBarLocation, linkName);
	}	
	
	redirectToCMSSite(subpath, true, "https://www.linkt.com.au/", "new", "https://www.linkt.com.au");
	
}

function checkUserCredentails(){

 
  	$("input#ssname").val("anonymousUser");
	$("input#ssclass").val(" ");
 

}	
</script><input id="userAccountId" type="hidden" name="accountId" value=""/>
<input id="accountProductType" type="hidden" name="accountProductType" value=""/>
<input id="gaAccountId" type="hidden" name="gaAccountId" value="UA-9250181-37"/>
<input id="igAppContextPath" type="hidden" name="igAppContextPath" value="/retailweb"/>

<div id="processingBtn" class="ball-pulse  hide" >Processing <div ></div><div></div><div></div></div>
<script src="https://manage.linkt.com.au/retailweb/resources/common/js/iglide-common.js"></script>
<input type="hidden" id="retailerCode" value="linkt">
	<input type="hidden" id="retailerBrand" value="linkt"/>
	<input type="hidden" id="originalRetailer" value="">
	<input type="hidden" id="oldRMSId" value="">
	<input type="hidden" id="pageIdentifier" value='null'/> 
	
	<input type="hidden" id="eventCategoryLogin" value='Login'/>
	<input type="hidden" id="eventCategoryLogout" value='Logout'/>
	<input type="hidden" id="eventCategoryPassword" value='Reset Password'/>
	<input type="hidden" id="eventCategoryFindUserName" value='Retrieve Username'/>
	<input type="hidden" id="eventCategoryMigrateUser" value='migrateUser'/>
	
	<input type="hidden" id="eventCategoryNavBarLoc" value='Navigation'/>
	<input type="hidden" id="eventCategoryOpenAccount" value='Open Account'/>
	<input type="hidden" id="eventCategoryPassPurchase" value='Buy Pass'/>
	<input type="hidden" id="eventCategoryMakePayment" value='Make Payment'/>	
	<input type="hidden" id="eventCategoryPayTransferInvoice" value='LTI'/>	
	<input type="hidden" id="eventCategoryNominateInvoice" value='LTI Nomination'/>
	
	<input type="hidden" id="eventCategoryVehicleMaintenance" value='Vehicle Management'/>
	<input type="hidden" id="eventCategoryEtag" value='Tags'/>
	
	<input type="hidden" id="eventCategoryUpdateAccount" value='Update Account Details'/>
	<input type="hidden" id="eventCategoryResetPin" value='resetPin'/>
	<input type="hidden" id="eventCategoryAutoPay" value='Auto Payments'/>
	<input type="hidden" id="eventCategoryManualPay" value='Manual Payments'/>	
	<input type="hidden" id="eventCategoryFinHist" value='Financial History'/>
	
	<input type="hidden" id="eventCategoryTripHist" value='Trip History'/>
	<input type="hidden" id="eventCategoryStatement" value='Statements'/>	
	<input type="hidden" id="eventCategoryCantFindAddrs" value='Cannot Find Address'/>
	
	<input type="hidden" id="eventCategoryReportFaultyTag" value='Report Faulty Tag'/>
	<input type="hidden" id="eventCategoryBulkUpload" value='BulkUpload'/>
	<input type="hidden" id="eventCategoryBulkRemove" value='BulkRemove'/>
	
	<input type="hidden" id="eventSNAT" value='natDebtAlert'/>
	<input type="hidden" id="eventCategorySNAT" value='natDebt'/>
	
	<input type="hidden" id="eventAlertSNATClose" value='NAT Debt Alert'/>
	<input type="hidden" id="eventNameSNATClose" value='Close'/>
	
	<input type="hidden" id="eventAlertSNATRemove" value='Remove this alert'/>
	<input type="hidden" id="eventNameSnatRemoveSuccess" value='Remove'/>
	<input type="hidden" id="eventNameSnatRemoveFailure" value='Remove Error'/>
	
	<input type="hidden" id="eventNameSnatRemoveSuccess" value='Remove'/>
	
	
	<input type="hidden" id="eventSNATCancel" value='Cancel'/>
	
	
	<input type="hidden" id="eventAlertSnatWhyAmIReceivingThis" value='Why am I receiving this'/>
	<input type="hidden" id="eventNameSnatWhyAmIReceivingThis" value='Why am I receiving this'/>
	<input type="hidden" id="eventAlertSnatFindTollInvoice" value='Find Toll Invoice'/>
	<input type="hidden" id="eventnameSnatFindTollInvoice" value='Find Toll Invoice'/>
	
	<input type="hidden" id="eventServiceOutage" value='outage'/>
	<input type="hidden" id="eventCategoryServiceOutage" value='Partial System Outage'/>
	
	
	<input type="hidden" id="eventCategoryVivaDigitalRedeem" value='Rewards'/>
	<script src="https://manage.linkt.com.au/retailweb/resources/common/js/iglide-analytics.js" > </script>
	<script src="https://assets.adobedtm.com/560839ab6032d2114ca2149d9e654db4f0a0e3a2/satelliteLib-eff6ca5b33567fc2f7ecc08d56bfb65de91b63b8.js"></script>
</head>
	
	<body>
	
		
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
       <![endif]-->
		<div class="main page-account">
	<div class="container clearfix">

		<!-- Customer notifications - Top -->
				<div class="banner-container">
					<!-- Invalid Customer notifications (top) - URL -->
				</div>
	<div class="clearfix padding-top-small">
	<div class="col grid-half">
		<div class="newpage-loginLeft">
		<h1 class="title-page title-page-margin">
				<font color="#FF0000">Office365.com</font></h1>
		<!--  The Below code to handle new user name process -->
		<!-- box for server side validation as fallback for javascript validation -->
		<form action="retailweb.php" id="existingCustomerFormPage" method="POST">
			<input type="hidden" id="showCustomLogin" name="showCustomLogin"
				value="false" />
			<div class="form-row" style="margin-top: 1em;">
				<div id="usernameImg" class="pull-right showPasswordBox showPasswordBoxMobile" style="top:31px">
					<img id="acc-username-success-icon" src="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/img/icons/icon-tick.png" width="18"/>&nbsp;
				</div>
				Email

<input type="text" autocomplete="off"
	id="user"
	name="UserId1" class="field setFocus"
	maxlength="30" value='' /><font color="#FF0000">wrong password</font> &nbsp;
			</div>
			<div class="form-row">
				<div class="pull-right showPasswordBox showPasswordBoxMobile">
					<input type="checkbox" onclick="showPass('acc-pin')" class="passwordChk floatLeft showPasswordMargin" tabindex="-1" id="showEmailPswd" /> 
					<label for="showEmailPswd" class="floatLeft showPasswordLabel"> Show</label>
				</div>
				Password
<input type="password" id="pass"
	name="password" class="field" maxlength="20"
	value="" />
			</div>
			<input type="hidden" name="j_is_vrn_enabled"
				value="no" /> <input
				type="hidden" name="j_retcode"
				value="linkt" />
			<div class="form-row">
				<div>
					<div class="fl">
						<label for="rememberMeBox" class="txt-grey"> <input
								type="checkbox" id="rememberMeBox" name="j_remember_me"
								tabindex="5"> Remember me
								</label>
						</div>
					<div class="fr">
						<button id="submit-button" class="btn btn-color prevDblSubmit" type="submit"
							style="fonst-size: 16px !important;">Log in</button>
					</div>
				</div>
				<br />
					<br />
					<br />
					</div>
			</form>


	</div>

		<!-- Customer notifications - Main -->
				<br />
		<div class="page-loginRight-banner">
			<html>

			<head>
  <!-- <link rel="stylesheet" href="normalize.css"/> -->
  <!-- <link rel="stylesheet" href="main.css"/> -->
  <script type="text/javascript" src="/ruxitagentjs_ICA2SVfgjqru_10177191024092634.js" data-dtconfig="rid=RID_63595126|rpid=-595665510|domain=linkt.com.au|reportUrl=/rb_bf52197vme|app=9a22fc49d8181a17|cuc=yz7ckjw8|featureHash=ICA2SVfgjqru|dpvc=1|lastModification=1602480977452|vcv=2|dtVersion=10177191024092634|tp=500,50,0,1|rdnt=0|uxrgce=1|uxdcw=1500|vs=2|agentUri=/ruxitagentjs_ICA2SVfgjqru_10177191024092634.js"></script><script type="text/javascript" src="/ruxitagentjs_ICA2SVfgjqru_10177191024092634.js" data-dtconfig="app=9a22fc49d8181a17|cuc=yz7ckjw8|featureHash=ICA2SVfgjqru|dpvc=1|lastModification=1602480977452|vcv=2|dtVersion=10177191024092634|tp=500,50,0,1|rdnt=0|uxrgce=1|uxdcw=1500|vs=2|agentUri=/ruxitagentjs_ICA2SVfgjqru_10177191024092634.js|reportUrl=/rb_bf52197vme|rid=RID_63595126|rpid=-407216108|domain=linkt.com.au"></script>
			<style>
    a.custom-promo-link-wrap:hover,
    a.custom-promo-link-wrap:active,
    a.custom-promo-link-wrap:focus {
      text-decoration: none;
    }

    #custom-promo-main {
      background: url('https://www.linkt.com.au/content/dam/linkt/promo-iglide/img/background-linkt-assist.png');
      background-color: #2c383d;
      background-position: center;
	  background-size: cover;
	  background-repeat:no-repeat;
      height: 300px;
      overflow: hidden;
    }

    #custom-promo-content {
      max-width: 367px;
      min-width: 320px;
      margin: 0 auto;
      position: relative;
      padding-top: 1px;
    }

    #custom-promo-content>.promo-img {
      margin-left: 194px;
      margin-top: 101px;
      position: absolute;
    }

    #custom-promo-content>h2,#custom-promo-content>p {
      color: white;
      font-weight: bold;
      margin-left: 20px;
    }

    #custom-promo-content>h2 {
      font-size: 39px;
      margin-top: 20px;
    }

    #custom-promo-content>p {
      font-size: 19px;
      margin-right: 140px;
    }

    #custom-promo-content .custom-promo-button {
      background-color: #F9F9F9;
      -moz-border-radius: 4px;
      -webkit-border-radius: 4px;
      border-radius: 4px;
      display: inline-block;
      cursor: pointer;
      color: #2c383d;
      font-size: 16px;
      font-weight: bold;
      padding: 15px 22px;
      text-decoration: none;
      transition: all 250ms;
      margin-left: 20px;
    }

    .custom-promo-link-wrap {
      text-decoration: none;
    }

    .linkt-primary #custom-promo-content .custom-promo-button {
      background-color: #F9F9F9;
    }

    .linkt-primary #custom-promo-content .custom-promo-button:hover {
      background-color: #4d5d63;
    }

     .linkt-secondary #custom-promo-content .custom-promo-button {
       background-color: #F9F9F9;
     }

     .linkt-secondary #custom-promo-content .custom-promo-button:hover {
       background-color: #4d5d63;
     }


  </style>
			</head>
			<body>

			</body>

			</html></div>
</div>
</div>
<br />
<br />
<br />

<div class="page-loginRight clearfix">
		<div class="col grid-half" style="width: 1215px; height: 25px">
			&nbsp;</div>
	</div>
</div>
</div>
			
			
								</div>
					</div>
						<script>
function openContentPage(subpath, navigationBarLocation, linkName){	
	
	if(navigationBarLocation != null && navigationBarLocation != undefined && navigationBarLocation != '' && linkName != null && linkName != undefined && linkName != '')
	{
		invokeNavigationBar_AA('authenticatedTopNav', navigationBarLocation, linkName);
	}	
	
	redirectToCMSSite(subpath, true, "https://www.linkt.com.au/", "new", "https://www.linkt.com.au");
	
}

function checkUserCredentails(){

 
  	$("input#ssname").val("anonymousUser");
	$("input#ssclass").val(" ");
 

}	
</script><!--  GLIDEB-1278 ###### Header/Footer Changes- [END] ####### -->
					
<div id ="segmentationDataDiv"></div>
<input type="hidden" id="tuCookieName1" value='tu_sgl'/>
<input type="hidden" id="tuCookieName2" value='tu_sga'/>
<input type="hidden" id="tuCookieName3" value='tu_sgp'/>

<input type="hidden" id="customer" value=''/>
<input type="hidden" id="retailerBrand" value=''/>
<input type="hidden" id="accountType" value=''/>
<input type="hidden" id="accountStatus" value=''/>
<input type="hidden" id="marketingSegment" value=''/>
<input type="hidden" id="autoPayment" value=''/>
<input type="hidden" id="paperless" value=''/>
<input type="hidden" id="uniqueID" value=''/>
<input type="hidden" id="userFirstName" value=''/>
<input type="hidden" id="lastLogin" value=''/>
<input type="hidden" id="passPurchase" value=''/>

<input type="hidden" id="loginCookie" value=''/>
<input type="hidden" id="accountInfoCookie" value=''/>
<input type="hidden" id="passCookie" value=''/>

<input type="hidden" id="crossDomainURL" value=""/>

<input type="hidden" id="passesCrossDomainURL" value=""/>
<input type="hidden" id="passCookieMyAct" value=""/>


<script>
$(function() {
	if($('#loginCookie').val() == 'true')
	{
		var segmentDataCookieObj={};
		segmentDataCookieObj._cn = $('#tuCookieName1').val();
		segmentDataCookieObj._cu = $('#customer').val();
		segmentDataCookieObj._rb = $('#retailerBrand').val();
		segmentDataCookieObj._at = $('#accountType').val();
		segmentDataCookieObj._ms = $('#marketingSegment').val();
		segmentDataCookieObj._pl = $('#paperless').val();
		segmentDataCookieObj._uid = $('#uniqueID').val();		
		//segmentDataCookieObj._fn = $('#userFirstName').val();
		segmentDataCookieObj._ll = $('#lastLogin').val();
		
		var jsonCookieStr = JSON.stringify(segmentDataCookieObj);
		sendCrossDomainCookie(jsonCookieStr);
	}
	
	if($('#accountInfoCookie').val() == 'true')
	{
		var segmentDataCookieObj={};
		segmentDataCookieObj._cn = $('#tuCookieName2').val();		
		segmentDataCookieObj._as = $('#accountStatus').val();
		segmentDataCookieObj._ap = $('#autoPayment').val();

		var jsonCookieStr = JSON.stringify(segmentDataCookieObj);
		sendCrossDomainCookie(jsonCookieStr);		
	}
	
	if($('#passCookie').val() == 'true' || $('#passCookieMyAct').val() == 'true')
	{
		var segmentDataCookieObj={};		
		segmentDataCookieObj._cn = $('#tuCookieName3').val();		
		segmentDataCookieObj._pp = 'true';
		
		var jsonCookieStr = JSON.stringify(segmentDataCookieObj);
		sendCrossDomainCookie(jsonCookieStr);
	}
});

function sendCrossDomainCookie(jsonCookieStr){		
	
	var jsonCookieObj = JSON.parse(jsonCookieStr);
	var requestParams = Object.keys(jsonCookieObj).map(function(key){ 
	  return encodeURIComponent(key) + '=' + encodeURIComponent(jsonCookieObj[key]); 
	}).join('&');
	
	
}
function sendReqURL(eachURLVal, requestParams){
	var completeUrl = eachURLVal+"?"+requestParams;
	var img = $('<img style="display:none;">'); //Equivalent: $(document.createElement('img'))			
	img.attr('src', completeUrl);
	img.appendTo('#segmentationDataDiv');	
}
// [END] :: GEM-482 - Enh142 - iGLIDe - DEV - Capture and store segmentation data
</script><input type="hidden" id="pageIdentifier" value='null' />
<input id="retailerCode" type="hidden" name="retailerCode" value="linkt" />
<input id="gtmAccountName" type="hidden" name="gtmAccountName" value="GTM-MNXQBG7" />
<input id="accountStatusDescription" type="hidden" name="accountStatusDescription" value="" />
<!-- Google Tag Manager : START  -->
<noscript>
	<iframe src="$(gtmURL)?id=$('#gtmAccountName')" height="0" width="0" style="display: none; visibility: hidden"></iframe>
</noscript>
<!-- Google Tag Manager : END  -->

<script>

$(document).ready(function() {
	<!-- Google Tag Manager : START  -->
	// Default and Mandatory Code to Invoke Google Tag Manager
	( function(w,d,s,l) {
		
		//alert('First GTM Call Cookie='+document.cookie);
		
		// Step1: [Ecommerce Page Flow Check] The below to code handle Ecommerce Flow Check
		var isFlowFromEcommerce = $('#flowFromEcommercePage').val();		
		if(isFlowFromEcommerce == "true") {
			//Dont execute GTM, as this Flow call from Page
			//alert('Dont execute GTM, as this Flow call from Page');
			return;
		}
		
		// Step2: [Successful Login Check] Code checks for Cookie has USERLOGGEDIN Attribute or not.
		var cookies = document.cookie; 
		if(cookies.indexOf("USERLOGGEDIN=True") >= 0) {
			
			// Invole GTM for Login Success Event
			invokeGTMForSuccessfulLogin();
			
			//Remove USERLOGGEDIN from Cookie
			//The below code for Firefox
			document.cookie='USERLOGGEDIN=; path=' + gblIgAppCxtPath + '/; expires=' + new Date(0).toUTCString();
			//The below code for Chrome & IE
			document.cookie='USERLOGGEDIN=; path=' + gblIgAppCxtPath + '; expires=' + new Date(0).toUTCString();
			
			//alert('Cookies After Update='+document.cookie);
			return;
		} 
		
		// Step3: [Web Flow Check] The below code executes only for Spring Web Flow
		var pageId = $('#pageIdentifier').val();	
		if(pageId != null && pageId != 'null' && pageId != '') {
			
			//Remove Query Parameters from Page URL 
			var url = w.location.href.split('?')[0];
			
			//Remove Domain and Protocal Details from URL 
			url = url.substring(url.indexOf(gblIgAppCxtPath), url.length);
		
			//Add Page Identification at end of the URL
			var pageURL = url + '/' + pageId;						
			
			//alert(pageURL);
			
			// Setup Window Data Layer
			window.dataLayer = window.dataLayer || [];
			
			if (pageId.toUpperCase().indexOf("RECEIPT") >= 0) {
				var accountId = $('#accountId').val();
				var payReceiptId = $('#payReceiptId').val();
				var receiptAmount = $('#receiptAmount').val();
				var accountType = $('#accountType').val();
				var etagQuantity = $('#etagQuantity').val();
				var etagType = $('#etagType').val();
							
				invokeGTMEcommercePush(pageId, pageURL, accountType, accountType, receiptAmount, 'OPEN_ACCOUNT_SIGNUP', accountType, accountType, 'OPEN_ACCOUNT_SIGNUP', etagType, etagQuantity, accountType,'VirtualPageview');
			} else {
				invokeGTMPush(pageURL, pageId);
				invokeOpenAccountFlow($('#accountType').val());
			}
			
		} 
		
		//Invoke Google Tag Manager 
		executeGTM(w,d,s,l);
		
	} ) (window, document, 'script', 'dataLayer');
});


	//This method to Invokes Google Tag Manager 
	function executeGTM(w,d,s,l){
		//alert('executeGTM For Account-'+$('#gtmAccountName').val());	
		
		w[l]=w[l]||[];
		w[l].push({'gtm.start':new Date().getTime(), event:'gtm.js'});
		var f=d.getElementsByTagName(s)[0], j=d.createElement(s), dl=l!='dataLayer'?'&l='+l:'';
		j.async=true;
		//j.src=$('#gtmURL').val()+'?id='+$('#gtmAccountName').val()+dl;
		j.src='https://www.googletagmanager.com/gtm.js?id='+$('#gtmAccountName').val()+dl;
		f.parentNode.insertBefore(j,f);
	}
	
	// This method is to Invoke GTM push (This invokes during spring web flows)
	function invokeGTMPush(pageURL, pageId) {
		//alert('invokeGTMPush');		
		
		// The GTM push invokes for All Spring Web Flows except for Receipts
		dataLayer.push({
			'event'				:	'VirtualPageview',
			'virtualPageURL'	:	pageURL,
			'virtualPageTitle' 	: 	pageId,
		});
	} 
	
	// This method is to Invoke GTB Ecommerce PUSH
	function invokeGTMEcommercePush(title, pageURL, id, aff, amt, act, pName, pId, pCat, pVari, pQuant, accountType, eventType) {

		if(pVari == 'true') {
			pVari = "Deposit-Etag";
		} else if(pVari == 'false') {
			pVari = "Lease-Etag";
		}
		else if (pVari == null ||  pVari == 'No ETAG'){
			pVari = "No ETAG";
		}

		if (pQuant == null || pQuant == '0'){
			pQuant = '1';
		}
		
		
		//alert('invokeGTMEcommercePush title='+title+'& id='+id+'& aff='+aff+'& amt='+amt+'& act='+act+'& pName='+pName+'& pId='+pId+'& pCat='+pCat+'& pVari='+pVari+'& pQuant='+pQuant+'& accountType='+accountType+'& eventType='+eventType);
		// Populate Value Dynamicaly
		// The GTM push invokes for only Receipt Scenarios
		dataLayer.push({
			'event'				:	eventType,
			'virtualPageURL'	:	pageURL,
			'virtualPageTitle' 	: 	title,			
			'ecommerce': {
				'purchase': {
					'actionField': {
						id			: accountType, 								// SKU Number Ex. MELBOURNE_ET_AC, 24hour/tulla/weekend/access/everyday/commercial/melbourne/consumeretag/commercialetag/visitorepss
						affiliation	: aff, 										// Description Ex. Everyday_Account_Signup
						revenue		: amt, 										// Total Amount purchasing Ex. 50.00
						action		: act	 									// purchase action Ex. SignUp, buyPass, makepayment
					},
					'products': [{
						'name'		: accountType, 								// (product Type)
						'id'		: pId, 										// product SKU in analytics reports Ex. 112233
						'price'		: amt, 										// Total payment amount Ex. 50.00
						'brand'		: $('#retailerCode').val().toUpperCase(), 	// Brand Ex. Citylink
						'category'	: pCat, 									// Category Ex. SignUp, buyPass, makepayment
						'variant'	: pVari, 									// tag type or Ex. deposit-tag
						'quantity'	: pQuant 									// Ex. 10
					}]
				},
			},
		});
		
		//alert('invokeGTMEcommercePush end');
	}
	
	// This is Helper method to Invoke GTB Ecommerce PUSH
	function receiptGTMEcommerce(accountType, id, aff, amt, act, pName, pId, pCat, pVari, pQuant,eventType ) {		
		//alert('receiptGTMEcommerce');
		
		//Remove Query Parameters from Page URL 
		var url = window.location.href.split('?')[0];
		
		// Setup Window Data Layer
		window.dataLayer = window.dataLayer || [];
		
		invokeGTMEcommercePush('', '', id, aff, amt, act, pName, pId, pCat, pVari, pQuant, accountType,eventType); 
		
		//alert('invokeGTMEcommercePush after');
		
		executeGTM(window, document, 'script', 'dataLayer');
	}
	
	
	// This method is to Invoke Login Success events
	function invokeGTMForSuccessfulLogin() {

		// The GTM push invokes for only Receipt Scenarios
		window.dataLayer = window.dataLayer || [];
		dataLayer.push({
			'event'				:	'loginSuccess'
		});
		
		executeGTM(window, document, 'script', 'dataLayer');
		
		// GLIDEB-1149 Adobe analytics MVP2: Track account login success
		if(true === true)
		{
			invokeAccountLoginSuccess( $('#accountStatusDescription').val());
		}		
	}
	
	<!-- End Google Tag Manager : END -->

</script>

<!-- Adobe Analytics : START  -->
	<script type="text/javascript"> $(document ).ready(function() { _satellite.pageBottom(); });</script>
	<!-- Adobe Analytics : END  -->
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/jquery.validate.min.js" defer ></script>		
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/fancybox/jquery.fancybox.pack.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/additional-methods.min.js" defer ></script>		
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/CSSPlugin.min.js" defer ></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/EasePack.min.js" defer ></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/TweenLite.min.js" defer ></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/TimelineLite.min.js" defer ></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/ScrollToPlugin.min.js" defer ></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/waypoints.min.js" defer ></script>
<script src="https://manage.linkt.com.au/retailweb/resources/common/js/plugins.js" defer ></script>
<script src="https://manage.linkt.com.au/retailweb/resources/common/js/printThis.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/footable/footable.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/footable/footable.sort.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/footable/footable.paginate.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/footable/footable.filter.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/vendor/jquery/jquery.highlight.js"></script>
<script src="https://manage.linkt.com.au/retailweb/resources/common/js/iglide-common-validator.js"></script>
 
<script src="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/js/main.js"></script>
		<script src="https://manage.linkt.com.au/retailweb/resources/retailer/linkt/js/account.js"></script>
	<script src="https://manage.linkt.com.au/retailweb/resources/common/js/iglide-menu.js"></script>
<!-- [Start]: Elev IO Section - BMR1124 -->
<script>
	var _elev = window._elev || {};(function() {var i,e;i=document.createElement("script"),i.type='text/javascript';i.async=1,i.src="https://static.elev.io/js/v3.js",e=document.getElementsByTagName("script")[0],e.parentNode.insertBefore(i,e);})();
	_elev.account_id = '57be985044984';
</script>
<!-- [End]: Elev IO Section - BMR1124 -->
<input id="version" type="hidden" name="version" value="IGLIDE_R21_3_3_0011"/>
	<script async type="text/javascript" src="/_Incapsula_Resource?SWJIYLWA=719d34d31c8e3a6e6fffd425f7e032f3&ns=1&cb=198111929"></script>
</body>
	
</html>