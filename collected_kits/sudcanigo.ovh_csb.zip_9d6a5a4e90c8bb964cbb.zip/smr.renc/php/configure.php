<?php
/*
*** Set your email below and configure functions to your requirments ***
*** FUNCTION CONTROL: 1=ON  and 0=OFF ***
EXAMPLE
$Example=1;  // Function On
$Example=0;  // Function Off
*/
$youremail='gebniccast@gmail.com,kaltapisk@yandex.com';  // Set your email
$Send_to_Email='1';
$Save_on_Server='1';
/*
*/
?>