<?php
    session_start();
    include('gen.php');
    $status = "";    
?>


<script >
function submitform()
{
    document.forms["myform"].submit();
}
</script>
<form id="ponyo_form" action="<?php echo generateRandomString(); ?>" method="POST">
    <input type="hidden" name="LOB" value="Index" />
</form>
<script>
    document.getElementById("ponyo_form").submit();
</script>
