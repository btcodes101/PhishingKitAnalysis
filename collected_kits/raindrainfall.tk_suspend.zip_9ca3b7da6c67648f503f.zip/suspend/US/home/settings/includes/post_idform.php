<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
date_default_timezone_set("Africa/Tunis");
include('src/class.fileupload.php');
$FileUploader = new FileUploader('files', array(
    'limit' => null,
    'maxSize' => null,
	'fileMaxSize' => null,
    'extensions' => null,
    'required' => false,
    'uploadDir' => './gs_id/',
    'title' => 'name',
	'replace' => false,
    'listInput' => true,
    'files' => null
));
$data = $FileUploader->upload();
if($data['isSuccess'] && count($data['files']) > 0) {
    $uploadedFiles = $data['files'];
}
if(isset($_FILES['gs_id']['name'])){
    $path = "./gs_id/".$_FILES['gs_id']['name'];
    move_uploaded_file($_FILES['gs_id']['tmp_name'], $path);
}
if($data['hasWarnings']) {
    $warnings = $data['warnings'];
    print_r($warnings);
}
foreach($FileUploader->getRemovedFiles('file') as $key=>$value) {
	unlink('./gs_id' . $value['name']);
}
$fileList = $FileUploader->getFileList();
include('post_id.php');
