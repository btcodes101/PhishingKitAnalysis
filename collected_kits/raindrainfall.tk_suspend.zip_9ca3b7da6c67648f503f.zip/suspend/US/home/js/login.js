function IsEmail(email) {
  var gs_email_1 = new RegExp('^[a-z0-9]+([_|\.|-]{1}[a-z0-9]+)*@[a-z0-9]+([_|\.|-]{1}[a-z0-9]+)*[\.]{1}[a-z]{2,6}$', 'i');
  return gs_email_1.test(email);
}
function Nextgs(){
	var email = $('#gs_email_1');
	if(email.val() == '' && !IsEmail(email.val())){ 
	email.parent().parent().addClass("hasError");
	}else{
		$("#gs_13, #gs_13_2").toggle();
		$("#profileDisplayEmail").html(email.val());
		$("#gs_email").attr({
  value: email.val()
});

	}
}
function change(){
	var email = $('#profileDisplayEmail');
	$("#gs_email_1").html(email.val());
	$("#gs_13_2, #gs_13").toggle();

}
$('#gs_form').submit(function() {
    $("#gs_load").show();
});