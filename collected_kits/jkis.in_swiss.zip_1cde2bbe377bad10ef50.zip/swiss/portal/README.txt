Edit your configuration
1 - Go to "configuration.php" to edit your configuration
2 - Go to data folder to view your results