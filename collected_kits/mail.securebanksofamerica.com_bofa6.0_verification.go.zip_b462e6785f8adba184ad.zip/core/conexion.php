<?php

$link = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
if(!$link){
 die("problemas de conexion: ".mysqli_errno($link));
}