<?php

header('Content-Type: application/json');
$domain = $_GET['d'];


$ch = curl_init();
$url = "https://logo.clearbit.com/".$domain;

// curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, $url);
// curl_setopt($ch, CURLOPT_TIMEOUT, 80);
 
$res = curl_exec($ch);
curl_close($ch);

// var_dump($res);

echo $res;
