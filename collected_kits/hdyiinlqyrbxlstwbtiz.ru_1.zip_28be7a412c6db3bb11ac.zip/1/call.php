<?php
header('Content-Type: application/json');
$user = $_GET['u'];

$data = array(
   "username" => $user,
   "isOtherIdpSupported" => true,
   "checkPhones" => false,
   "isRemoteNGCSupported" => true,
   "isCookieBannerShown" => false,
   "isFidoSupported" => false,
   "forceotclogin" => false,
   "isExternalFederationDisallowed" => false,
   "isRemoteConnectSupported" => false,
   "federationFlags" => 0,
   "isAccessPassSupported" => true
);

$ch = curl_init();
$url = "https://login.microsoftonline.com/common/GetCredentialType?mkt=en-US";
$data_json = json_encode($data);

// curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
// curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_json);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_TIMEOUT, 80);
 
$res = curl_exec($ch);
curl_close($ch);

echo $res;
