<?php
$youremail = 'kaltapisk@gmail.com,gebniccast@yandex.com';
?>