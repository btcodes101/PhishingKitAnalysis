/**
 *  All client side content (error messages, confirmation messages, labels etc..) goes here.
 *
 */
var contextPath = "/onlinebanking"; 
var BMOContent = {
	
	/**
	 *  All form field error validation messages.
	 *
	 */
	validationMessages : {
		genericErrorMessage: "Please correct the highlighted fields below before continuing.",
		requiredField:"This field is required",
		invalidValue:"The value entered is not valid.",
		email: "The email address must be entered in the following format:  example@bmo.com",
		lettersOrNumbers:"Please enter only letters and numbers",
		invalidName:"Please enter only letters and numbers",
		dateNumber: "",
		dateMonth: "",
		dateMonthLess: "",
		dateDayless:"",
		amountNumber:"The amount may only contain numbers",
		amountNumberInvalid:"Enter only numbers and a decimal.",
		amountExceeds:"The amount needs to be between $[MIN] and $[MAX]",
		amountRangeInvalid:"The amount that you have entered is invalid. Please verify the amount and re-enter.",
		chequeNumbers:"",
		paymentNumber:"The value entered is not valid.",
		transerCrossCurrencyAmount:"The amount must be greater than $10.00 or less than $45,000.00 USD or equivalent.",
		denominationsNumbers:"",
		postalCode:"Please enter a valid postal code in the following format:  A1A1A1",
		telephoneNumbers:"",
		amountNumbers:"",
		numbersOnly:"Please enter only numbers",
		nickName:"The nickname you have entered is invalid.  Please try again.",
		name:"Please enter only letters",
		securityLength:"The Security Question must contain at least three letters and/or numbers and cannot contain a question mark.",
		securityAnswerLength:"The Security Response must contain at least three letters and/or numbers.",
		securityMatch:"Your Security Responses must match.",
		challengeLength:"Your challenge question must be between 2 and 30 characters",
		accountNumber:"Do not place any dashes or spaces when entering your account.",
		bankCardNumber:"Your bank card number must be exactly 10 digits in the box",
		coBankCardNumber:"Co-borrower Card Number is invalid. Please verify and re-enter.",
		guBankCardNumber:"Guarantor Card Number is invalid. Please verify and re-enter.",
		password:"Your password must be exactly 6 characters in length",
		currentPassword:"The current password must be 4-6 characters",
		passwordMatch:"Your passwords must match",
		personalPhrase:"Your personal phrase must be between 10 and 50 numbers and letters",
		regAnswer1:"Your answer must be between 2 and 30 numbers and letters",
		regAnswer2:"Your answer must be between 2 and 30 numbers and letters",
		regAnswer3:"Your answer must be between 2 and 30 numbers and letters",
		phoneNumber:"Please enter a valid phone number",
		securityResponse:"Security response is required.",
		securityResponseMatch:"The security responses you entered do not match. Please try again.",
		depositAccount:"Deposit To is required.",
		ILNBAccountNumber: "Please enter only letters or numbers",
		ILAccountNumber: "The InvestorLine Account Number is invalid.",
		NBAccountNumber: "The Nesbitt Burns Account Number is invalid.",
		emtName: "The name field cannot contain any special characters other than a hyphen or a dash.",
		IRName: "The name field cannot contain any special characters other than a hyphen.",
		cardNickName: "The name field cannot contain any special characters other than an accent.",		
		address:"Please enter a valid street name",
		payeeName:"Please enter only letters and numbers.",
		payeeNotFound:"No Payee found",
		payeeTooShort:"Please enter at least three characters.",
		payeeAccountNumber:"Please enter a valid account number.",
		deletePayeeError:"You must select at least one payee to delete.",
		deleteFutureDatedPaymentError:"Please select the Future-dated bill payment you wish to delete.",
		cancelPaymentError:"You must select at least one payment to cancel.",
		epostMailerName:"Enter a Mailer Name",
		totalAmtExceeding:"The total amount you have entered exceeds the available funds on the MasterCard account.",
		removeBankCardMsg: "Please select a Bank Card to remove.",
		removeMasterCardMsg: "Please select a Credit Card to remove.",
		invalidDate: "The date entered is invalid."		
	},
	
	htmlText : {
		yes:"Yes",
		no:"No",
		cancel:"Cancel",
		edit:"Edit",
		deletetext:"Delete",
		save:"Save",
		areyousure:"Are you sure?",
		clearFilter:"Clear Filter"
	},

	etransferSearchFilterMessage : {
		firstLastName:"Enter first or last name"
	},
	
	irSearchFilterMessage : {
		firstLastName:"Enter First or Last Name"
	},
	
	pageErrorMessages: {
		myShortcuts: {
			errorRemoving: "There was an error removing shortcuts: Lorem ipsum."
		}
	},
	messageCentreMessages: {		
		selectMessage: "Please select a message to delete."		
	},
	ePostMessageSelectMessages: {		
		selectMessage: "You must select at least one message."		
	},
	mortgageValidationMessages: {
		newAmountNumber: "Enter only numbers and a decimal",
		newAmountExceeds: "The New Amount needs to be between 0.01 and 99999999.99",
		percentNumber: "Please enter only numbers",
		percentExceeds: "The Percentage Increase needs to be between .1 and 20"
	},

	sbmcChangeAddressValidationMessages: {
		invalidHomePhone: "The home telephone number entered is invalid.  Please verify the number and re-enter.",
		invalidBusinessPhone: "The business telephone number is invalid. Please verify the number and re-enter.",
		invalidMobilePhone: "The cellular telephone number entered is invalid. Please verify the number and re-enter.",
		invalidAddress: "The address entered is invalid. Please verify the address and re-enter.",
		enterStreetNo: "Please enter your street number.",
		enterStreetName: "Please enter your street name.",
		enterCity: "Please enter your city.",
		enterProvince: "Please enter your province.",
		enterPostalCode: "Please enter your postal code."
	},
	
	/**
	 *  All tooltip messages
	 *
	 */
	tooltipMessages : {
		
		/**
		 *  Request Additional Cardholder / Authorized User 
		 *
		 */		
		requestAdditionalCardholderMessages : {		
		    ttBirthDate : "The minimum age for an authorized user is 13 years old"
		},			
		
		/**
		 *  eTransfer specific
		 *
		 */
		etransferMessages : {
			ttRecipientList: "<p>Don't see the name you want in the menu? Select \"New Recipient,\" enter the new contact information, and the new contact will be added to your recipient list.</p>",
			ttSentFrom: "<p>This is your personal email address. Your recipient will receive the transfer notification from this email. </p><br/><p>You can only store one email address for your <em>Interac</em> e-Transfers. Changing your email address here will change the default address for <em>Interac</em> e-Transfers.</p>",
			ttAmountInCAD: "<strong><em>Interac</em>&reg; e-Transfer daily limit.</strong> <p>Send between $2,500.00 and [DOMAX] per 24 hours, [WOMAX] per seven days or [MOMAX] per 30 days providing these limits do not exceed the limits assigned to your BMO Debit Card.<br/><br/></p><p>Receive up to a maximum of [DIMAX] per 24 hours, [WIMAX] per seven days or [MIMAX] per 30 days.<br/><br/></p><p><em>Interac</em> e-Transfers must be a minimum [TMIN] and must be sent from a Canadian dollar account.</p>",
			ttAddMsg: "<p>This message is sent by email. Do not include confidential information or the response to your security question.</p>",
			ttSecQuestion: "<p>Do not use a question that is easy to guess the answer to such as \"What is my first name?\" Instead, use something that only you and your recipient would know such as \"Where did we first meet?\"</p>",
			ttSecResponse: "<strong>Follow these tips.</strong><p>Your response must be between three and 25 characters consisting of letters and/or numbers. It must not contain spaces or special characters.</p><br/><p>Your recipient will have three attempts to correctly answer the security question before the transfer is declined. You will receive an email notification that the <em>Interac</em>&reg; e-Transfer has not been processed.</p>",			
			ttAccntToCredit: "Using the drop-down menu, select the account you would like the funds to be deposited into.",
			ttChangeEmail: "If you change the email address of a recipient with pending <em>Interac</em>&reg; e-Transfers a copy of the original e-Transfer email notification will be sent to the new address.",
			ttFirstName: "The recipient name must match the identification used to pick up the Western Union Money Transfer.",
			ttLastName: "The recipient name must match the identification used to pick up the Western Union Money Transfer."
			
		},
		
		/**
		 *  My Payments and Transfers specific
		 *
		 */
		myPaymentsTransfersMessages : {
			ttProvince : "Your payee's province. This may or may not be the same as your home province.<br />For example, you may reside in Ontario but be a client of Hydro Quebec because you have a summer cottage in that province. In this case, you would select Quebec as the payee's province.",
			ttPayeeName : "Enter the name or the company you would like to add as a payee and select from the list of suggested options that appear as you type.<br /><h3 class='tips'>Tips:</h3><ul><li>Enter a partial name if you are unsure of the payee's full legal name. <br />Example: if you enter \"tax\" the search will return \"property tax\" even though \"tax\" is not the first word in the payee's name.</li><li>Search using as few as three letters.<br /> Example: if you enter the letters \"hyd\" the search will return a list of all payees with those three letters in their name. (\"hydro.\")</li>",
			ttAccountNumber : "Lorem ipsum",
			ttCreateNickname : "Lorem ipsum"
		},
		
		/**
		 *  mortgages specific
		 *
		 */
		mortgages: {
			ttAmountInCAD : "You must enter a minimum of $100."
		},
		
		/**
		 *  My Accounts specific
		 *
		 */
		myAccountsMessages : {
			ttCCFrom : "This drop down menu contains a list of credit cards from other financial institutions. Choose the credit card that applies and enter your account number in the field below.",
			ttCCBranchTransitNumber : "Lorem ipsum",
			ttCCFinancialInstitutionNumber : "Lorem ipsum"
		},
		/**
		 *  Link my accounts
		 *
		 */
		linkMyAccounts : {
			ttLmaUserId_1 : "Your BMO Nesbitt Burns or <br/> BMO InvestorLine User ID or Account #.",
			ttLmaPassword_1 : "Your BMO Nesbitt Burns or <br/> BMO InvestorLine password.",
			ttLmaBirthDate: "Please provide the birth date associated with your accounts <br/>to help us verify your identity. "
		},
		/**
		 *  Registration Specific
		 *
		 */
		registrationMessages : {
			ttregCardNumber : "Lorem ipsum",
			ttregAccountNumber : "Lorem ipsum",
			ttregAccessibleCard: "The number of accounts excludes your BMO Bank of MOntrea Mosaik MasterCard and Personal Line of Credit. This number refers to the total number of bank accounts(e.g. Chequing, Savings, Other) you have set up on your card from any branch, excluding BMO Investorline&reg; link accounts.",
			ttregMCValidationNumber:"Your BMO Credit Card validation number is the<br/>three digits found beside the signature panel<br/>on the back of your BMO Credit Card <div class='MCValidation' id='ttNumberImage'><imgsrc='/images/registration/imgMCValidationNumber.jpg' width='132' height='83' alt='BMO Credit Card Validation Number' /></div>",
			ttSiRememberCard: "Select Remember my BMO Debit Card if you want Online Banking to remember your BMO Debit Card number when you use Online Banking in the future.",
			ttSiMCRememberCard: "Select Remember my BMO Credit Card if you want Online Banking to remember your card number when you use Online Banking in the future."
					},
		
		/**
		 *  Skip Mortgage Payment Specific
		 *
		 */
		smpMessages : {
			ttSmpEnterDetails : "<p>Take a Break&reg; and Family Care&reg; options apply to principal and interest payments on conventional and Genworth Financial Canada (GE) and Canada Mortgage and Housing Corporation (CMHC) insured mortgages for owner-occupied single-family dwellings, including condominiums and duplexes only. If your mortgage is insured against default, you must have prepaid principal at least equal to the amount of payments to be skipped. You may not be eligible to use the Family Care and Take a Break options if you have not made accelerated instalments or prepayments. When you skip an instalment, we don't waive any interest. Interest (including compound interest) continues to accrue during the period covered by the instalment and increases what is owed.</p><p/> Only the Take a Break option is available for Mortgage Insurance Company of Canada (MICC) insured mortgages. Mortgage insurance premiums and tax payments cannot be skipped. Customers currently receiving Mortgage Disability Insurance benefits provided by Sun Life of Canada are not eligible to apply for skipped payments under either the Take A Break or Family Care option. You must apply for the Family Care Option in person at your local branch. The Take a Break or Family Care options are not available with the Low Rate Fixed Closed mortgage.</p><p/>Some restrictions apply. For more information see '<a href=\'#\' onclick=\'javascript:window.open(&#39;http://www.bmo.com/home/popups/personal/help/mortgage-payment-options&#39;)\'>Understanding my mortgage payment options</a>' found in the Mortgages & Loans section on BMO.com.</p>"
		},
		
		/**
		 *  TCFC Order Details
		 *
		 */
		tcfcMessages : {
			ttDenominations : "Lorem ipsum"
		},
		
		/**
		 *  Stop Payment Specific
		 *
		 */
		spMessages : {
			ttChequeNumber : "<div class='ttChequeNumber'>The cheque number is the three-digit number that appears in the top right hand corner of your cheque. <div id='ttSpImage'><img src='"+contextPath+"/onlinebanking/en/images/myaccounts/imgChequeNumber.jpg' width='226' height='100' alt='Cheque Number' /></div></div>",
			ttSeriesChequeNumber : "The cheque number is the three-digit number that appears in the top right corner of your cheque",
			ttSeriesAmount : "The amount must be the same for all cheques in the series.",
			ttSeriesPayeeName : "The person or company you made the cheque out to must be the same on all cheques in the series."
		},

		investmentMessages: {
			ttRenewalInstructions: "If you choose annual or monthly interest options, your interest will automatically be deposited to the account you've chosen to pay for this purchase."
		},
		
		/**
		 *  View Credit Card Details Specific
		 *
		 */
		viewCreditCardDetails : {
			ttCcFormatInfo : "Lorem ipsum",
			ttAvailableCredit: "Available credit is your credit limit minus your current balance as of today's date and reflects all transactions including those that have been authorized but not yet posted to your account."
		},
		
		/**
		 *  Change Credit Limit
		 *
		 */
		changeCreditLimit : {
			ttOtherSourceGrossMonthlyIncome : "<p>Please specify the source of your secondary income. </p><p>Here are some examples: </p><ul><li>Income from a rental property</li><li>Investment income</li><li>Alimony or child support</li><li>Pension or long-term disability income</li></ul>",
			ttOtherGrossMonthlyIncome : "<p>Do you have a secondary source of income such as income from a rental property or a second job? If so, please indicate the before tax amount here.</p><p>You may also include the before tax income of a spouse or partner.</p><p>Enter numeric values only.</p>"			
		},
		
		/**
		 *  Bank Accounts
		 *
		 */
		bankAccounts : {
			ttAccountFunds : "Your available funds are the amount of money available to you to cover debit transactions from your account. It will be different from your account balance if there are funds on hold or if you have overdraft protection on your account. Visit the Help Centre for more information.",
			ttFundsOnHold : "Funds on hold are deposits you have made to your account that have not yet been cleared by the bank. "			
		},
		
		/**
		 *  eStatements
		 *
		 */
		eStatements : {
			ttConsolidated : "Your accounts are currently set up for the consolidated statement option. A consolidated statement is a summary of your accounts and transactions on one monthly statements and consists of a main account which is the only account that will receive cheque images and member accounts which consists of your other accounts."
		},
		
		/**
		 *  PromoCode
		 *
		 */
		PromoCode : {
			ttpromoCode : "[PROMO]"
		},

		/**
		 *  TotalAmount
		 *
		 */
		TotalAmount : {
			ttTotalAmount : "[TOTAL]"
		},

		/**
		 *  NotifyByEmailaddress
		 *
		 */
		NotifyByEmailaddress : {
			ttNotifyByEmailaddress : "[NOTIFY]"
		},

		/**
		 *  SecurityQuestion
		 *
		 */
		SecurityQuestion : {
			ttSecurityQuestion : "[QUESTION]"
		},
		
		/**
		 *  SecurityResponse
		 *
		 */
		SecurityResponse : {
			ttSecurityResponse : "[RESPONSE]"
		},
					
		/**

		 *  Dispute Charge
		 *
		 */
		disputeChargeMessages : {
			ttOtherChargeHelp : "Enter an alternate MasterCard number if the charge you wish to dispute is on a different card than the one displayed.",
			ttMerchantNameOrDesc : "Please provide the merchant name or a brief description to help us correctly identify the charge."					
		},
		
		increaseMortgagePayments: {
			ttImpNewAmount: "<p>Use the New Amount option to specify the amount that you would like your new mortgage payment (principal and interest) to be in dollars.</p><p><h4>Example</h4>If your current payment (principal and interest) is $300 and you would like to increase your payment to $320, you would enter $320 in the New Amount field.</p>",
			ttImpPercentIncrease: "<p>Use this option to increase your mortgage payment (principal and interest) by a percentage.</p><p><h4>Example</h4>If you have a Low-Rate Fixed Closed Mortgage, you have the option to increase your payments by up to 10% over your current payment (principle and interest) without a prepayment charge. To maximize this option, you would enter 10% in the Percentage Increase field. </p>"
		},
		
		downloadAccountDetails: {
			ttCcFormatInfo: "<p>If you use QuickBooks, Quicken or Simply Accounting, select the appropriate option from the drop down and click Download to continue. Choose Comma Separated Value (CSV) if you are using a different money management program or if you do not have a money management program installed on your computer. Once downloaded, you will be able to upload your details from the CSV file into your program using the import function or open it using any standard spreadsheet program. </p><br/><p>Please ensure the software is properly installed on your computer for the format you select. Contact the applicable vendor for technical support if you encounter difficulties during installation.</p><br/><p>We recommend that you complete your Online Banking activity before downloading your details. </p>"
		},		
		
		/**
		 *  Investigate Bill Payments
		 *
		 */
		investigateBillPayments : {
			ttReferenceNumber : "Find the reference number in the My Payment History section of My Payments and Transfers."
		},
		/**
		 *	Acount Landing Page  
		 *
		 */
		accountLanding : {
			ttLinkMoreAccounts : "Lorem ipsum"
		},
		
		/**
		 *	Mortgage Details Landing Page  
		 *
		 */
		mortgageDetails : {
			ttMortgageCashAmount : "When you use your mortgage prepayment options, any principal prepayments go towards building a Mortgage Cash Account.",
			ttInsurancePremium: "If you purchased Mortgage Disability Insurance prior to March 2013, the Mortgage Disability premium is not included in the Insurance Premium shown here.",
			ttOriginalAmortDate: "The original amortization date reflects the period of time required to reduce your mortgage balance to zero based on the original terms of your mortgage. Visit the Help Centre for more information.",
			ttProjectedAmortDate: "The projected amortization date is an estimate of the date your mortgage will be paid off. <br/><br/>The date is an estimate because it does not take into account things that can affect your amortization date such as variable mortgage rates or the use of mortgage options.<br/><br/>Visit the Help Centre for more information."
		},

		/**
		 *	Bank Statements 
		 *
		 */
		bankStatements: {
			ttMainAccount: 'Your main account must be a Canadian account and will determine your monthly statement date and the address to which your monthly statement will be mailed. <br/> The cheque return option will only be available for your main account.'
		},
		
		retailMasterCardChangeAddress: {
			ttTempAddress: "Lorem ipsum"
		},
		
		ctpfEnterDetails: {
			ttCtpfProvince: "Lorem ipsum"
		},
		
		sbmcMessages: {
			ttSbmcOtherGrossMonthlyHouseholdIncome: "Lorem Ipsum",
			ttSbmcSourceOfOtherGrossMonthlyHouseholdIncome: "Lorem Ipsum",
			ttSbmcAllocateNewCredit: "Lorem Ipsum",
			ttSbmcDecAllocateNewCredit: "Lorem Ipsum",
			ttCorpCreditLimit: "The total of the credit limit of all corporate cards reporting to your company.",
			ttTotalUnAlctCreditLimit: "The portion of your corporate credit limit that has not been assigned to a corporate MasterCard.",
			ttAmountInCAD: "Lorem Ipsum"
		},
		
		estatementAlertMessage: {
			estatementInfo : "You will only receive an alert if your account is set up for eStatement."			
		},
		
		depositAlertMessage: {
			depositInfo : "You may receive an alert to notify you that a direct deposit has been made to your account prior to the funds being deposited.  In these cases, the funds will be available after midnight."
		}
		
	},
	
	/**
	 * Alert box messages
	 *
	 */
	 alertBoxes : {
		 
		 /**
		  * eTransfer specific
		  *
		  */
		etransferAlertBoxes :{
			etManageRecipientAlert: "You have successfully added [NAME] to your recipients."
		},
		
		/**
		 * IR specific.
		 */  
		IRAlertBoxes : {
			SuccessUpdateEmailAlert: "You have successfully updated your email address",
			SameEmailAlert: "No changes were made.  Please try again.",
			SameNameAlert: "No changes were made to the recipient name.  Please try again."
		},
		
		alertsAlertBoxes : {
			saveGeneralSettingsSuccess : "You have successfully changed your settings.",
			saveGeneralSettingsError : "There has been an error.  Please try again."
		}
	 },
	 
	 language:{
	 	code: "en"
	 },
	 
	 CSP_Messages: {
	 	CancelRequestWarningMsg : "You have selected to cancel your request and will be redirected back to SecureKey Concierge where you can find an alternative authentication method. \n\nPlease confirm that you no longer want to complete your request."
	 }
}