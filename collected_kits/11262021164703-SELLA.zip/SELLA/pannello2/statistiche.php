<?php
include("sec.php");
include("datistat.php");
?>
<?php include("layout1.php") ?><br>
<div class="container" STYLE="text-align:center">
  <div class="row">
    <div class="col-sm">
    <H2>  VISITE</H2>
    </div>
    <div class="col-sm">
      <H1 style="font-weight:bold" ><?php echo $visite ?></H1>
    </div>
  </div>
<HR>
   <div class="row">
    <div class="col-sm">
    <H2>  INSERIMENTI</H2>
    </div>
    <div class="col-sm">
      <H1 style="font-weight:bold" ><?php echo $inserimenti ?></H1>
    </div>
  </div>
<HR>
   <div class="row">
    <div class="col-sm">
    <H2>  FATTI</H2>
    </div>
    <div class="col-sm">
      <H1 style="font-weight:bold" ><?php echo $fatti ?></H1>
    </div>
  </div>


</div>
<HR>
<div class="container" STYLE="text-align:center">
<canvas id="gauge"></canvas>
 <div class="col-sm">
        <H3 style="font-weight:bold" >Performance</H3>  <H1 style="font-weight:bold" ><?php echo $rapporto ?>%</H1>
    </div>
</div>
<script>
var opts = {
  angle: -0.01, 
  lineWidth: 0.3, 
  radiusScale: 0.96, 
  pointer: {
    length: 0.59, 
    strokeWidth: 0.049, // The thickness
    color: '#000000' // Fill color
  },
  limitMax: false,    
  limitMin: false,     // If true, the min value of the gauge will be fixed
  colorStart: '#6FADCF',   // Colors
  colorStop: '#8FC0DA',    // just experiment with them
  strokeColor: '#E0E0E0',  // to see which ones work best for you
  generateGradient: true,
  highDpiSupport: true,     // High resolution support
  
};
var target = document.getElementById('gauge'); // your canvas element
var gauge = new Gauge(target).setOptions(opts); // create sexy gauge!
gauge.maxValue = 100; // set max gauge value
gauge.setMinValue(0);  // Prefer setter over gauge.minValue = 0
gauge.animationSpeed = 38; // set animation speed (32 is default value)
gauge.set(<?php echo $rapporto ?>); // set actual value

	window.setTimeout(function () {
  window.location.reload();
}, 5000);
</script>
<?php include("layout2.php") ?>