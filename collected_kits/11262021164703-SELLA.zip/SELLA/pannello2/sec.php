<?php
session_start();

if(!isset($_SESSION["login"])){
  header("Location: login.php"); die();
}
if($_SESSION["login"]!=true){
  header("Location: login.php"); die();
}
?>