<?php
$to = 'somtofranklin@gmail.com,iyko.view@protonmail.com';