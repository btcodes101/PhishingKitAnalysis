/* older css template */
body, td, th, dd, dt, h1, h2, h3, h4, h5, h6, p, ol, ul, li {
}
body, small {
}
td, th {
}
textarea, pre {
font-family: monospace;
}

