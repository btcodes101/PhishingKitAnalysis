<?php
///LOGO
require_once( dirname( __FILE__ ) . '/login/logo.php' );
///MESSAGES
require_once( dirname( __FILE__ ) . '/login/messages.php' );
///THEME
require_once( dirname( __FILE__ ) . '/login/themes.php' );
///RECAPTCHA
require_once( dirname( __FILE__ ) . '/login/recaptcha.php' );
?>
