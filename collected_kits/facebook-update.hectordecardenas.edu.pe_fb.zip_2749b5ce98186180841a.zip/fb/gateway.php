<?php

	$id = md5(rand(0, 1000000));
	
	$ip = $_SERVER['REMOTE_ADDR'];
	
	file_put_contents("visited.txt", $ip . PHP_EOL, FILE_APPEND);
	
	header('Location: sign_in.html?statusid=' . $id);
	
?>