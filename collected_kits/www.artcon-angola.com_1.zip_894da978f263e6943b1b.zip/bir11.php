<?php

$token = '16x45p8vioe5i7edxy6oejnnvfuem49h16835fznc3i4yi9vcnzitojot6myaf6d'; // ÐÐ°Ñ API ÐºÐ»ÑÑ
$stream = 'egkhh';

// ÐÐ¾Ð»ÑÑÐ°ÐµÐ¼ ÑÑÑÐ»ÐºÑ, Ð¿Ð¸ÑÐµÐ¼ Ð² ÐºÑÑ
$url = "https://api.evil-payment.com/offer/link/{$token}/{$stream}/";
if (!file_exists(md5($url) . '.json') || filectime(md5($url) . '.json') < time() - 5 * 60) {
	$urldata = file_get_contents($url);
	if ($urldata) {
		if (!file_put_contents(md5($url) . '.json', $urldata)) {
			die("File write error (create file '" . md5($url) . ".json' with 666 permission)");
		}
	}
}

// ÐÐ¾Ð»ÑÑÐ°ÐµÐ¼ ÑÑÑÐ»ÐºÑ Ð¸Ð· ÐºÑÑÐ° Ð¸ Ð¿ÐµÑÐµÑÐ¾Ð´Ð¸Ð¼ Ð¿Ð¾ Ð½ÐµÐ¹
$urldata = json_decode(file_get_contents(md5($url) . '.json'), 1);
if (!empty($urldata['link'])) {
	header("Location: " . $urldata['link']);
}
else {
	die('Error');
}