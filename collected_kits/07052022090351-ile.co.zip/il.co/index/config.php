<?php
$botName = "5255769083:AAFWHFL9EYWsMBrol8ruOy4FN4jWHfcDUhY";
$chatID = "5152164908";
$yourEmail = "gomaaalghoul652@gmail.com";
?>