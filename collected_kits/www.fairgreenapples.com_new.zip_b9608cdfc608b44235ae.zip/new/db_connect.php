<?php  

require ('./db_config.php');

$conn = mysqli_connect($db_host, $db_user, $db_password) OR
die("Unable to connect to database" . mysqli_error($conn));

$db_select = mysqli_select_db($conn, 'bff') OR
die("Unable to select database" . mysqli_errno($conn));

?>