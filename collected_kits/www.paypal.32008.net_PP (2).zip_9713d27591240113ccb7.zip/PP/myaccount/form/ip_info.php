<?php
$emailku = 'haurgeulisghost@gmail.com';
?>