<?php
$emailku = 'mathodsoldja1984@protonmail.com';
?>
