<?php
error_reporting(0);
$ips = $_SERVER['REMOTE_ADDR'];
$date = date("l d F H:i:s");
$url = $_SERVER['REQUEST_URI'];
$agent = $_SERVER['HTTP_USER_AGENT'];

$fp = fopen("log.txt", "a"); 
fputs($fp, "$ips - DATE: $date - [URL: $url] | [Agent: $agent] \n"); 
fclose($fp);

require 'hs.php';
?>