
Open the file process-handler.php using your preffered text editor eg Notepad++

on line 4 find this line of code 

$yourEmailAddress = 'ennter-your-email-here';

replace ennter-your-email-here with the email address you want logs to be sent to

A backup copy of your logs will be stored in the file logs-backup.txt

access the page using index.php

