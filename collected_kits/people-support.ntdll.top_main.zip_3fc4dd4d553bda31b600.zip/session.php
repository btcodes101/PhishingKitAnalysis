<?php

    class Comp
    {

        public function headerX($location) {
            header("Location: " . $location . "?token=" . $_SESSION['token']);
        }

        public function createToken() {
            $input = "0123456789abcdefghijklmn";
            $strength = "200";
            $input_length = strlen($input);
            $random_string = '';
            for ($plus = 0; $plus < $strength; $plus++) {
                $random_character = $input[mt_rand(0, $input_length - 1)];
                $random_string .= $random_character;
            }
            return $_SESSION['token'] = hash("md5", $random_string);
        }

        public function checkToken() {
            if (!isset($_SESSION['token']) || !isset($_GET['token']) || $_SESSION['token'] != $_GET['token']) {
                return 0;
            }
            return 1;
        }

    }

    class Antibot extends Comp
    {

        public function throw404() {
            http_response_code(404);
            return header("Location:../index.php");
        }

    }
 
?>