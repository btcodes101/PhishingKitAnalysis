<?php
/*
hello megria
*/
// ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
session_start();
/*
include "anti1.php";
include "anti2.php";
include "anti3.php";
include "anti4.php";
include "anti5.php";
include "anti6.php";
include "anti7.php";
include "anti8.php";
*/
include "antibots.php";
include "blocker.php";
include "killbot.php";
?>
