<?php


$sendername = 'TyTyD';
$sendermail = 'ngentot@resusps.com';

$YOUR_EMAIL = 'leesimp12@hotmail.com';