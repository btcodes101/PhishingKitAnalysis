// validator-rules-bmo.js

function isDefined(variable) {
	var defined= true;
	if(typeof(variable) == "undefined") {
		defined= false;
	}
	return defined;
}



function validateOlbDateDad(form) {

    var bValid = true;
	var masterValid = true;
	//var olbDate = new olbdate(); 
	var formName = form.getAttributeNode("name");
    olbDate = eval('new ' + formName.value + '_olbdate()');    
    var i = 0;                                                                                          

	var fields = new Array();
	var focusField = null;
	for(x in olbDate)
	{
		var checkValueName = olbDate[x][2]("checkValue");
		var checkValue="ToFrom";
		if (eval("form."+checkValueName+"[0].checked")){
			checkValue="Since";
		}
		var correctValue = olbDate[x][2]("correctValue");
		
		if (checkValue == correctValue) {
			var mmonth = olbDate[x][2]("olbmonth");
			var yyear = olbDate[x][2]("olbyear");
			
			var checkday = form[olbDate[x][0]].value;
	
			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value"); 
	
			if(checkday != "" || checkmonth != "" || checkyear != "")
			{						
				bValid = isValidDate(checkday, checkmonth, checkyear);
				if(!bValid)
				{
				  	if (i == 0) {
	        			focusField = form[olbDate[x][0]]; 
	         	  	}
	
					fields[i++] = olbDate[x][1];
					masterValid = false;
				}
			}
		}
	}
			
	if(fields.length > 0) {
	    focusField.focus();

		alert(fields.join('\n'));
	}
				
	olbDate = null;															

	return masterValid;
}



function validateOlbTodayPlusDad(form) {

    var bValid = true;
	
	var masterValid = true;
	//olbDate = new olbdateplus();  
	var formName = form.getAttributeNode("name");
    olbDate = eval('new ' + formName.value + '_olbdateplus()');   
    var i = 0;                                                                                          
	var focusField = null;
	var fields = new Array();
	for(x in olbDate)
	{
		var checkValueName = olbDate[x][2]("checkValue");
		var checkValue="ToFrom";
		if (eval("form."+checkValueName+"[0].checked")){
			checkValue="Since";
		}
		var correctValue = olbDate[x][2]("correctValue");

		if (checkValue == correctValue) {
			var mmonth = olbDate[x][2]("olbmonth");
			var yyear = olbDate[x][2]("olbyear");
			var days = olbDate[x][2]("days");
			var compare = olbDate[x][2]("comparison");
			var checkday = form[olbDate[x][0]].value;
					
			if(yyear.length > 0 && mmonth.length > 0 && checkday.length > 0)
			{	
	
	
	
				var checkmonth = eval("form."+mmonth+".value");				
				var checkyear = eval("form."+yyear+".value");
	
				if(checkday == "" && checkmonth == "" && checkyear == "")
				{						
					return bValid;
				}
	
				var plusday = checkday;
				
				// decimal values (known Jscript error if checkday={"08","09"})
				var intDay = parseInt(checkday,10);
				var intDays = parseInt(days,10);
	
				var requestDate = new Date(checkyear,checkmonth-1,intDay+intDays,0,0,0,0);	
				var requestTime = requestDate.getTime();
				
				var nowDate = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0);
				var otherTime = nowDate.getTime();
	
				if(compare == ".le.")
				{
					if(requestTime <= otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
					}
				}
				if(compare == ".ge.")
				{
					if(requestTime >= otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				
				}
				
				if(compare == ".eq.")
				{
					if(requestTime == otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				
				}
				if(compare == ".gt.")
				{
					if(requestTime > otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				
				}
				if(compare == ".lt.")
				{
					if(requestTime < otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				
				}
				if(compare == ".ne.")
				{
					if(requestTime != otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				}
							
			}
		}
	}
	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
	return masterValid;
}



function validateOlbTodayPlus1Dad(form) {


    var bValid = true;
	
	var masterValid = true;
	olbDate = new olbdateplus1();  
    var i = 0;                                                                                          
	var focusField = null;
	var fields = new Array();

	for(x in olbDate)
	{
		var checkValueName = olbDate[x][2]("checkValue");
		var checkValue="ToFrom";
		if (eval("form."+checkValueName+"[0].checked")){
			checkValue="Since";
		}
		var correctValue = olbDate[x][2]("correctValue");

		if (checkValue == correctValue) {
			var mmonth = olbDate[x][2]("olbmonth");
			var yyear = olbDate[x][2]("olbyear");
			var days = olbDate[x][2]("days1");
			var checkday = form[olbDate[x][0]].value;
			var compare = olbDate[x][2]("comparison1");
	
			
			if(yyear.length > 0 && mmonth.length > 0 && checkday.length > 0)
			{	
	
	
	
				var checkmonth = eval("form."+mmonth+".value");				
				var checkyear = eval("form."+yyear+".value");
				
				var plusday = checkday;
				
				if(checkday == "" && checkmonth == "" && checkyear == "")
				{						
					return bValid;
				}
				
	
				var plusday = checkday;
				
				var intDay = parseInt(checkday,10);
				var intDays = parseInt(days,10);
	
				var requestDate = new Date(checkyear,checkmonth-1,intDay+intDays,0,0,0,0);	
				var requestTime = requestDate.getTime();
				
				var nowDate = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0);
				var otherTime = nowDate.getTime();
	
	
				if(compare == ".le.")
				{
					if(requestTime <= otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
					}
				}
				if(compare == ".ge.")
				{
					if(requestTime >= otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				
				}
				
				if(compare == ".eq.")
				{
					if(requestTime == otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				
				}
				if(compare == ".gt.")
				{
					if(requestTime > otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				
				}
				if(compare == ".lt.")
				{
					if(requestTime < otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				
				}
				if(compare == ".ne.")
				{
					if(requestTime != otherTime)
					{
					
						fields[i++] = olbDate[x][1];
						masterValid = false;
						break;									
										
					}
				
				}
			}
		}
	}
			
	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
				
				
																
	return masterValid;
				
}





function validateOlbDateGreaterEqualDad(form){
    var bValid = true;
		
	oOlbGreaterEqual = new olbDateValidationGreaterEqualDad ();  
    var i = 0;                                                                                          
	var fields = new Array();
	for(x in oOlbGreaterEqual)
	{
		var checkValueName = olbDate[x][2]("checkValue");
		var checkValue="ToFrom";
		if (eval("form."+checkValueName+"[0].checked")){
			checkValue="Since";
		}
		var correctValue = olbDate[x][2]("correctValue");

		if (checkValue == correctValue) {
			if (form.saveActivityRadio[1].checked){
				var fromMonthLabel = oOlbGreaterEqual[x][2]("olbmonth");
				var fromYearLabel = oOlbGreaterEqual[x][2]("olbyear");
				var toMonthLabel = oOlbGreaterEqual[x][2]("olbmonth2");
				var toYearLabel = oOlbGreaterEqual[x][2]("olbyear2");
				var toDayLabel = oOlbGreaterEqual[x][2]("olbday2");
		
				var fromDayValue = form[oOlbGreaterEqual[x][0]].value;				
		
				if(fromYearLabel.length > 0 && fromMonthLabel.length > 0 && 
					toYearLabel.length>0 && toMonthLabel.length>0 && toDayLabel.length>0)
				{	
		
					// get values from the form
					var fromMonthValue = eval("form."+fromMonthLabel+".value");				
					var fromYearValue = eval("form."+fromYearLabel+".value");
					var toDayValue = eval("form."+toDayLabel+".value");				
					var toMonthValue = eval("form."+toMonthLabel+".value");				
					var toYearValue = eval("form."+toYearLabel+".value");
					
					if(fromMonthValue == "" && fromDayValue == "" && fromYearValue == "" 
					&& toYearValue == "" && toDayValue == "" && toMonthValue == "")
					{						
						return bValid;
					}
		
					// convert values to int (ensure base-10 conversion for parseInt())		
					var fromDayInt = parseInt(fromDayValue,10);
					var fromMonthInt = parseInt(fromMonthValue,10);
					var fromYearInt = parseInt(fromYearValue,10);
					var toDayInt = parseInt(toDayValue,10);
					var toMonthInt = parseInt(toMonthValue,10);
					var toYearInt = parseInt(toYearValue,10);
		
					// standardize to/from dates with the same time for apple-apple comparison
					var fromDate = new Date(fromYearInt,fromMonthInt-1,fromDayInt,0,0,0,0);	
					var toDate = new Date(toYearInt, toMonthInt-1, toDayInt,0,0,0,0);
					var diff = toDate-fromDate;  				// difference in ms
					var diffStr = new String(diff/86400000);    //calculate days and convert to string			
	
					var point=diffStr.indexOf(".");    				//find the decimal point
					var daysStr=diffStr.substring(0,point);    		//get just the whole days				
					if (point>0){								// a decimal point occurs
						days=parseInt(daysStr);
					}
					else {
						days = parseInt(diffStr);
					}	
	
					if (days<0) {
			            fields[i++] = oOlbGreaterEqual[x][1];
		            	bValid = false;                                                                             
					}
				}
			}
		}
	}	
    if (fields.length > 0) {
        alert(fields.join('\n'));                                                                      
	}                                                                                                   
	return bValid;   
}



function Trim(TRIM_VALUE){
if(TRIM_VALUE.length < 1){
return"";
}
TRIM_VALUE = RTrim(TRIM_VALUE);
TRIM_VALUE = LTrim(TRIM_VALUE);
if(TRIM_VALUE==""){
return "";
}
else{
return TRIM_VALUE;
}
} //End Function

function RTrim(VALUE){
var w_space = String.fromCharCode(32);
var v_length = VALUE.length;
var strTemp = "";
if(v_length < 0){
return"";
}
var iTemp = v_length -1;

while(iTemp > -1){
if(VALUE.charAt(iTemp) == w_space){
}
else{
strTemp = VALUE.substring(0,iTemp +1);
break;
}
iTemp = iTemp-1;

} //End While
return strTemp;

} //End Function

function LTrim(VALUE){
var w_space = String.fromCharCode(32);
if(v_length < 1){
return"";
}
var v_length = VALUE.length;
var strTemp = "";

var iTemp = 0;

while(iTemp < v_length){
if(VALUE.charAt(iTemp) == w_space){
}
else{
strTemp = VALUE.substring(iTemp,v_length);
break;
}
iTemp = iTemp + 1;
} //End While
return strTemp;
} //End Function


function validateDependent(form) {

    var bValid = true;
	var masterValid = true;

	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
	oDependent = new DependentFieldsValidations ();                                                                         

    for (x in oDependent) {                                                                              
		var dependent = oDependent[x][2]("dependent");
		
		    	
    	if (Trim(form[oDependent[x][0]].value) == '' && 
    		 eval("form."+dependent+".value") == '10') {

 	        if (i == 0) {
            	focusField = form[oDependent[x][0]]; 
            }
            
            fields[i++] = oDependent[x][1];

            bValid = false;                                                                             
        }
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;   
}



function validateRepeatDefaultPFM(form) {
	var bValid = true;
    var fields = new Array();                                                                           
    var i=0;
	oRepeatDefaultPFM = new repeatDefaultPFM();
	for (x in oRepeatDefaultPFM) {
		if ((form.lastSoftware.value!=form.selectSoftware.options[form.selectSoftware.selectedIndex].value) && (form.saveActivityRadio[0].checked) &&
			(form.selectSoftware.options[form.selectSoftware.selectedIndex].value == form.oldDefaultSoftware.value)){
	   	 	fields[i++] = oRepeatDefaultPFM[x][1];
			if (!(confirm(fields.join('\n')))){
		          	bValid = false;
			}
		} 
	}
	return bValid;
}



function  validatePhone2(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oPhone = new phone2();                                                                         

    for (x in oPhone) {   
        
        var areaVariable = oPhone[x][2]("area");
    	var phoneVariable = oPhone[x][2]("phone");
		var phone2Variable = oPhone[x][2]("phone2");
		var extVariable= oPhone[x][2]("ext");

		var phoneNumber= "";
		// this is to support possible phone entry forms
		// that don't have a separate field for area code
		if (isDefined(areaVariable)) {
			phoneNumber+= form[areaVariable].value;
		}
		// phone number is mandatory to have
		phoneNumber+= form[phoneVariable].value;
		// optional as on some forms phone number is one field
		// while on others split 3+4
		if (isDefined(phone2Variable)) {
			phoneNumber+= form[phone2Variable].value;
		}
		// extension is optional
		if (isDefined(extVariable)) {
			phoneNumber+= form[extVariable].value;
		}

		if (phoneNumber.length > 0 ) {
	   	 	if (focusField == null) {
	       		if (isDefined(areaVariable) && form[areaVariable].value == '') {
	       			focusField = form[areaVariable];
	       		} else if (form[phoneVariable].value == '') {
					focusField = form[phoneVariable];
				} else if (isDefined(phone2Variable) && form[phone2Variable].value == '') {
					focusField = form[phone2Variable];
				}
	       		if (focusField != null) {
		      	 	fields[i++] = oPhone[x][1];
		          	bValid = false;
		        }
	   		}
	   	}
	}

    if (fields.length > 0) {
	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function validateOlbDiffDates(form) {

    var bValid = true;
	
	var masterValid = true;
	olbDate = new olbdiffdates();  
    var i = 0;                                                                                          
	var focusField = null;
	var fields = new Array();

	for(x in olbDate)
	{
		var fdiff1day = olbDate[x][2]("diff1day");
		var fdiff1month = olbDate[x][2]("diff1month");
		var fdiff1year = olbDate[x][2]("diff1year");

		var fdiff2day = olbDate[x][2]("diff2day");
		var fdiff2month = olbDate[x][2]("diff2month");
		var fdiff2year = olbDate[x][2]("diff2year");

		var diff1adjust = olbDate[x][2]("diff1daysadjust");
		var diff2adjust = olbDate[x][2]("diff2daysadjust");
		var compare = olbDate[x][2]("diffcompare");
		var diff1day = eval("form."+fdiff1day+".value");				
		var diff1month = eval("form."+fdiff1month+".value");				
		var diff1year = eval("form."+fdiff1year+".value");				
		
		var diff2day = eval("form."+fdiff2day+".value");				
		var diff2month = eval("form."+fdiff2month+".value");				
		var diff2year = eval("form."+fdiff2year+".value");				
		
		


		if(diff1day == "" && diff1month == "" && diff1year == "")
		{						
			return bValid;
		}

		if(diff2day == "" && diff2month == "" && diff2year == "")
		{						
			return bValid;
		}

		diff1day = parseInt(diff1day,10) + parseInt(diff1adjust,10);
		diff2day = parseInt(diff2day,10) + parseInt(diff2adjust,10);
		var realdate1 = new Date(diff1year, diff1month, diff1day,0,0,0,0).getTime();
		var realdate2 = new Date(diff2year, diff2month, diff2day,0,0,0,0).getTime();

			if(compare == ".le.")
			{
				if(realdate1 <= realdate2)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
				}
			}
			if(compare == ".ge.")
			{
				if(realdate1 >= realdate2)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			
			if(compare == ".eq.")
			{
				if(realdate1 == realdate2)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".gt.")
			{
				if(realdate1 > realdate2)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".lt.")
			{
				if(realdate1 < realdate2)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".ne.")
			{
				if(realdate1 != realdate2)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}


	}
			
	if(fields.length > 0) 
	{
		alert(fields.join('\n'));
	}
				
				
																
	return masterValid;
				
}



function validateDadPFMCheck(form) {

    var bValid = true;
    var i = 0;                                                                                                                    
    var fields = new Array();                                                                                                     
	var numAccounts=0;
	oDadPFMCheck = new dadPFMCheck();

	for(x in oDadPFMCheck)
	{
		if ((form.pfmID0 != null) && (form.pfmID0.checked)){
			numAccounts++;
		}
		if ((form.pfmID1 != null) && (form.pfmID1.checked)){
			numAccounts++;
		}
		if ((form.pfmID2 != null) && (form.pfmID2.checked)){
			numAccounts++;
		}
		if ((form.pfmID3 != null) && (form.pfmID3.checked)){
			numAccounts++;
		}
		if ((form.pfmID4 != null) && (form.pfmID4.checked)){
			numAccounts++;
		}
		if ((form.pfmID5 != null) && (form.pfmID5.checked)){
			numAccounts++;
		}
		if ((form.pfmID6 != null) && (form.pfmID6.checked)){
			numAccounts++;
		}
		if ((form.pfmID7 != null) && (form.pfmID7.checked)){
			numAccounts++;
		}
		if ((form.pfmID8 != null) && (form.pfmID8.checked)){
			numAccounts++;
		}
		if ((form.pfmID9 != null) && (form.pfmID9.checked)){
			numAccounts++;
		}	
	
		if ((form.selectSoftware.value == "104") && (numAccounts>1))	{
			var message = oDadPFMCheck[x][1];		
			bValid = false;
			fields[i++]=message;		
		}
	}
    if (fields.length > 0) {
       alert(fields.join('\n'));                                                                                                  
    }                                                                                                                             

    return bValid;
    			
}



function validateGroupRequired(form) {

    var bValid = true;
    var i = 0;                                                                                                                    
    var fields = new Array();                                                                                                     
	var numAccounts=0;
	oGroupRequired = new groupRequired();

	for(x in oGroupRequired)
	{
		if ((form.pfmID0 != null) && (form.pfmID0.checked)){
			numAccounts++;
		}
		if ((form.pfmID1 != null) && (form.pfmID1.checked)){
			numAccounts++;
		}
		if ((form.pfmID2 != null) && (form.pfmID2.checked)){
			numAccounts++;
		}
		if ((form.pfmID3 != null) && (form.pfmID3.checked)){
			numAccounts++;
		}
		if ((form.pfmID4 != null) && (form.pfmID4.checked)){
			numAccounts++;
		}
		if ((form.pfmID5 != null) && (form.pfmID5.checked)){
			numAccounts++;
		}
		if ((form.pfmID6 != null) && (form.pfmID6.checked)){
			numAccounts++;
		}
		if ((form.pfmID7 != null) && (form.pfmID7.checked)){
			numAccounts++;
		}
		if ((form.pfmID8 != null) && (form.pfmID8.checked)){
			numAccounts++;
		}
		if ((form.pfmID9 != null) && (form.pfmID9.checked)){
			numAccounts++;
		}
		if (numAccounts<1){
			var message = oGroupRequired[x][1];		
			bValid = false;
			fields[i++]=message;							
		}
	}
//	alert("numAccounts checked=" + numAccounts);
    if (fields.length > 0) {
       alert(fields.join('\n'));                                                                                                  
    }                                                                                                                             
    return bValid;
}


function validatePurchaseTCFX(form) {


    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
    var oAmount = new PurchaseTCFX();                                                                         

	if(form.mode.value != "confirm")
	{
		return true;
	}



    for (x in oAmount) 
    {   
			if (
				(parseInt(form.cusdtotal.value,10) + 
				parseInt(form.cusdtotal42.value,10)+ 
				parseInt(form.ccdntotal.value,10)+ 
				parseInt(form.cgbptotal.value,10)+ 
				parseInt(form.ceurtotal.value,10)+
				parseInt(form.usdtotal.value,10)+
				parseInt(form.gbptotal.value,10)+
				parseInt(form.eurtotal.value,10)) ==0 ) 
			{
				fields[i++] = oAmount[x][1];
				if (focusField == null) {
					focusField = form[oAmount[x][0]];
				}
				bValid = false;
				break;
			}


    }
    if (fields.length > 0) {
       	focusField.focus();
       	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;



}

function validateTC42amount(form) {

    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
    var oAmount = new TC42amountValidations();                                                                         

    for (x in oAmount) {   
        if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length != 0) {
			if ((parseInt(form.cusd2042.value,10) <= 0 && parseInt(form.cusd5042.value,10) <= 0 && parseInt(form.cusd10042.value,10) <= 0) && form.secondname.value.length != 0) {
				fields[i++] = oAmount[x][1];
				if (focusField == null) {
					focusField = form[oAmount[x][0]];
				}
				bValid = false;
			}
    	}                                                                                                   
    }
    if (fields.length > 0) {
       	focusField.focus();
       	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;
}

function validateTC42Secondname(form) {

    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
    var oAmount = new TC42Validations();                                                                         

    for (x in oAmount) {   
        if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length == 0) {   
			if ((parseInt(form.cusd2042.value,10) > 0 || parseInt(form.cusd5042.value,10) > 0 || parseInt(form.cusd10042.value,10) > 0) && form.secondname.value.length == 0) {
				fields[i++] = oAmount[x][1];
				if (focusField == null) {
					focusField = form[oAmount[x][0]];
				}
				bValid = false;
			}

    	}                                                                                                   
    }
    if (fields.length > 0) {
       	focusField.focus();
       	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;
}


/*
function validateTCFXRequired(form) {

    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
    var oTCFX = new TCFXRequired();                                                                         

	if(form.mode.value != "confirm")
	{
		return true;
	}


    for(x in oTCFX) 
    {                                                                              
        if(	form[oTCFX[x][0]].type == 'text' || 
        		form[oTCFX[x][0]].type == 'textarea' || 
        		form[oTCFX[x][0]].type == 'select-one' || 
        		form[oTCFX[x][0]].type == 'radio')
        		 
        	 
        	{   
			
				var iValue = form[oTCFX[x][0]].value;

				if (!iValue) 
				{
					fields[i++] = oTCFX[x][1];
					if (focusField == null) {
						focusField = form[oTCFX[x][0]];
					}
					bValid = false;
				}

    		}                                                                                                   

    }
 
    if(fields.length > 0) 
    {
       	focusField.focus();
       	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;
}
*/


function validateUSAddress(form) {

    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
    oAmount = new USAddress();                                                                         


/*
alert(form.usdtotal.value);
alert(form.cusdtotal42.value);
alert(form.cusdtotal.value);
alert(form.country.value);
*/
    for (x in oAmount) {                                                                              
        if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length > 0) {   

			if ((parseInt(form.usdtotal.value,10) > 0 || parseInt(form.cusdtotal42.value,10) > 0 || parseInt(form.cusdtotal.value,10) > 0) && form.country.value == "US") {
				fields[i++] = oAmount[x][1];
				if (focusField == null) {
					focusField = form[oAmount[x][0]];
				}
				bValid = false;
				break;
			}

    	}                                                                                                   

    }
 
    if (fields.length > 0) {
       	focusField.focus();
       	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;
}



function validateFloatRange(form) {
    var bValid = true;
    var focusField = null;
    var i = 0;
    var fields = new Array();
    oRange = new floatRange();
    for (x in oRange) {
        if ((form[oRange[x][0]].type == 'text' ||
             form[oRange[x][0]].type == 'textarea') &&
            (form[oRange[x][0]].value.length > 0)) {
            var fMin = parseFloat(oRange[x][2]("min"));
            var fMax = parseFloat(oRange[x][2]("max"));
            var fValue = parseFloat(form[oRange[x][0]].value);
            if (!(fValue >= fMin && fValue <= fMax)) {
                if (i == 0) {
                    focusField = form[oRange[x][0]];
                }
                fields[i++] = oRange[x][1];
                bValid = false;
            }
        }
    }
    if (fields.length > 0) {
        focusField.focus();
        alert(fields.join('\n'));
    }
    return bValid;
}

function accountType(form) {

	var bValid = true;
	var focusField = null;
	var i = 0;                                                                                          
	var fields = new Array();                                                                           
	oAmount = new acctType();                                                                         

    for (x in oAmount) {                                                                              
    	if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length > 0) {   

    		fromAccount = form.accountfrom.options[form.accountfrom.selectedIndex].value;
			toAccount = form.accountto.options[form.accountto.selectedIndex].value;
				
			var fA = fromAccount.charAt(fromAccount.length - 3);
			var tA = toAccount.charAt(toAccount.length - 3);

			if (fA!="U" && tA!="U") {
				fields[i++] = oAmount[x][1];
				if (focusField == null) {
					focusField = form[oAmount[x][0]];
				}
				bValid = false;
      				
   			}
   		}
   	}
            	
    if (fields.length > 0) {
      	focusField.focus();
      	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;
}





function validateDifferent(form) {

    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
    oAmount = new validateDiff();                                                                         


    for (x in oAmount) {                                                                              
        if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length > 0) {   

			if (form.accountfrom.selectedIndex==form.accountto.selectedIndex) {
				fields[i++] = oAmount[x][1];
				if (focusField == null) {
					focusField = form[oAmount[x][0]];
				}
				bValid = false;
			}

    	}                                                                                                   

    }
 
    if (fields.length > 0) {
       	focusField.focus();
       	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;
}


function isDigit (c)  {   return ((c >= "0") & (c <= "9"))  }

function validateSIN(form) {


    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
    oAmount = new sinValidationCheck();                                                                         


    for (x in oAmount) {                                                                              
        if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length > 0) {   

//		var secondProperty = billerPayReq[x][2]("secondProperty");
//		var thirdProperty = billerPayReq[x][2]("thirdProperty");

			sinNumber = form.sin1.value + form.sin2.value + form.sin3.value;

			//check for valid SIN number
	
			if (sinNumber.length != 9) {
				fields[i++] = oAmount[x][1];
				if (focusField == null) {
					focusField = form[oAmount[x][0]];
				}
				bValid = false;
			} else {
	
				for (index = 0; index < sinNumber.length;index++) {
					if (!(isDigit(sinNumber.charAt(index)))) {
						fields[i++] = oAmount[x][1];
						if (focusField == null) {
							focusField = form[oAmount[x][0]];
						}
						bValid = false;
						break; 
					}
				}
			} 
			
			if (bValid) {
			
				//start processing valid SIN
			
				//get the last digit from the SIN
				checkDigit = parseInt(sinNumber.charAt(sinNumber.length-1),10);
			 
				//process every 2nd digit  
				evenSum = 0;
				for(index=1;index <= sinNumber.length-2; index=index+2) {
					doubleDigit = sinNumber.charAt(index) * 2;
					
					if (doubleDigit >= 10) {
					 	evenSum = evenSum  + doubleDigit - 9;
					} else {
						evenSum = evenSum + doubleDigit;
					}
	
				}
			
			
				//process the remaining digits	
				oddSum=0;
	
				for(index=0;index <= sinNumber.length-3; index=index+2) 
					oddSum = oddSum + parseInt(sinNumber.charAt(index),10);
			
				totalSum = evenSum + oddSum;
			
				//compute the check digit
				computedCheckDigit = 0;
			
				if ((totalSum % 10) != 0) {
					temp = totalSum + '';
					computedCheckDigit = 10 - parseInt(temp.charAt(1),10);
				}
			
				if (computedCheckDigit != checkDigit) {
					fields[i++] = oAmount[x][1];
					if (focusField == null) {
						focusField = form[oAmount[x][0]];
					}
					bValid = false;
				}
			}
	
	    }                                                                                                   

    }
 
    if (fields.length > 0) {
       	focusField.focus();
       	alert(fields.join('\n'));                                                                      
	}

	return bValid;
}

function validateDOB(form) {                                                                       

	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oValidate = new ValidateDOBCheck();                                                                         



    for (x in oValidate) {                                                                              

		//get parameters
		var dayParam = oValidate[x][2]("day");
		var yearParam = oValidate[x][2]("year");
		var month = form[oValidate[x][0]].value;

		var day = eval("form."+dayParam+".value");
		var year = eval ("form."+yearParam+".value");

		if (year < 1900) {
			fields[i++] = oValidate[x][1];
			focusField = form[oValidate[x][0]];
            bValid = false;
			break;			
		} 

		dobDate = new Date(year,month-1,day);
		todaysDate = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0);
			
		if (bValid) {
			if (year != dobDate.getFullYear() || 
				month != (dobDate.getMonth() +1) ||
				day != dobDate.getDate()) {
				fields[i++] = oValidate[x][1];
				focusField = form[oValidate[x][0]];
	            bValid = false;
				break ;				
			} 
		}		
		
		if (bValid) {
			if (todaysDate < dobDate) {
				fields[i++] = oValidate[x][1];
				focusField = form[oValidate[x][0]];
	            bValid = false;
				break ;				
			}
		}			

		if (bValid) {
			if ((dobDate.getFullYear() + 12) > todaysDate.getFullYear()) {
				fields[i++] = oValidate[x][1];
				focusField = form[oValidate[x][0]];
	            bValid = false;
				break ;				
			}
		}  				
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      

}

function aoRequired(form) {                                                                       

	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    //oRequired = new aoRequiredCheck();                                                                         

    var formName = form.getAttributeNode("name");
    oRequired = eval('new ' + formName.value + '_aoRequiredCheck()'); 

    for (x in oRequired) {                                                                              

		//get parameters
		var dayParam = oRequired[x][2]("day");
		var yearParam = oRequired[x][2]("year");
		var month = form[oRequired[x][0]].value;

		var day = eval("form."+dayParam+".value");
		var year = eval ("form."+yearParam+".value");

		if (day == '' || month == '' || year == '') {
			if (focusField == null) {
	            focusField = form[oRequired[x][0]];
	        }
            fields[i++] = oRequired[x][1];
            bValid = false;
		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      

}

function validateYear(form) {                                                                       

	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oYear = new YearValidationCheck();                                                                         

    for (x in oYear) {                                                                              

		var year = form[oYear[x][0]].value;

		for (index = 0; index < year.length;index++) {
			if (!(isDigit(year.charAt(index)))) {
				fields[i++] = oYear[x][1];
				if (focusField == null) {
					focusField = form[oYear[x][0]];
				}
				bValid = false;
				break; 
			}
		}

	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      

}


function validateSkipDaterequired(form) {
			
	var bValid = true;
	var focusField = null;
    var masterValid = true;
	var i = 0;                                                                                          
	var fields = new Array();                                                                           

	odtRqd = new sdtRqd();                                                                         

	for (x in odtRqd) {                                                                                             
			if (focusField == null) {
			
				checkyear=form.skip_yyyy.value;
				checkday=form.skip_dd.value;
				checkmonth=form.skip_mm.value;
				
				if ( form.skip_yyyy.value.length == 0){

					focusField = form.skip_yyyy;
					masterValid = false;
				}	
				if ( form.skip_dd.value.length == 0){

					focusField = form.skip_dd;
				}	
				if ( form.skip_mm.value.length == 0){

					focusField = form.skip_mm;
				}							
				if ( (form.skip_mm.value.length==0)&&(form.skip_dd.value.length==0) ){
					focusField = form[7];
				}
			}
			if ( (form.skip_yyyy.value.length == 0)||
				(form.skip_dd.value.length == 0)||
				(form.skip_mm.value.length == 0) ){								
				fields[i++] = odtRqd[x][1];
  				masterValid = false;
			}           
	} 

    if (fields.length > 0) {

       focusField.focus();

       alert(fields.join('\n'));                                                                      
    }                                                                                                                                                                                                        
    return masterValid;                                                                                      
}

function isValidLetter (c) {   return ( ((c >= "A") && (c <= "Z")) || (c == '-') || (c == '_') || ((c >= "0") & (c <= "9"))) }

function validateAccountDescription(form) {                                                                       

	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oDescription = new AccountDescriptionCheck();                                                                         

    for (x in oDescription) {                                                                              

		if (form[oDescription[x][0]].value.length == 0)
			form[oDescription[x][0]].value = "PRS";
			
		form[oDescription[x][0]].value = form[oDescription[x][0]].value.toUpperCase();
		var description = form[oDescription[x][0]].value;

		for (index = 0; index < description.length;index++) {
			if (!(isValidLetter(description.charAt(index)))) {
				fields[i++] = oDescription[x][1];
				if (focusField == null) {
					focusField = form[oDescription[x][0]];
				}
				bValid = false;
				break; 
			}
		}

	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      

}


//Borrowing Form Javascripts

function fieldLength(form) {                                                                       

	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           

	oLength = new fieldLengthCheck();                                                                         


    for (x in oLength) {                                                                              

		//get parameters
		var lengthValue = oLength[x][2]("length");


		var appNumber = form[oLength[x][0]].value;

		if (appNumber.length != lengthValue) {
			fields[i++] = oLength[x][1];
			if (focusField == null) {
				focusField = form[oLength[x][0]];
			}
			bValid = false;
			break; 
		}

	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      

}


function validateApplicationNumber(form) {                                                                       

	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           

	oApplicationNumber = new validateApplicationNumberCheck();                                                                         


    for (x in oApplicationNumber) {                                                                              

		var appNumber = form[oApplicationNumber[x][0]].value;
		var tmp = appNumber.charAt(appNumber.length - 1);

		if (tmp!='d' && tmp!='D') {
			fields[i++] = oApplicationNumber[x][1];
			if (focusField == null) {
				focusField = form[oApplicationNumber[x][0]];
			}
			bValid = false;
			break; 
		}

	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      

}


function validateSpecialRequestAmount(form) {
				
	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oAmount = new SpecialRequestAmountValidations();                                                                         

    for (x in oAmount) {                                                                              
		if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length > 0) {   

			var iValue = form[oAmount[x][0]].value;

			//amount should be greater than zero
			if (iValue <= 0)  {
      			if (i == 0)
      				focusField = form[oAmount[x][0]];

	      		fields[i++] = oAmount[x][1];
      			bValid = false;
			} else {

				//TODO: include French mask
		   		var pattern=new RegExp("^[0-9]{1,8}(\\.[0-9]{0,2})?$");
					  					 
	  			if (!pattern.test(iValue) || eval(iValue)==0) {
	      					
	      			if (i == 0) {
	      				focusField = form[oAmount[x][0]];
	      			}
	      						
	      			fields[i++] = oAmount[x][1];
	      					
	      			bValid = false;
			   	}
			}
		}                                                                                               
	}                                                                                                   

    if (fields.length > 0) {

		focusField.focus();

		alert(fields.join('\n'));                                                                      
	}                                                                                                   

    return bValid;                                                                                      
}

function validateMinAmount(form) {

	var bValid = true;
    var i = 0;                                                                                          
    var fields = new Array(); 
    oAmount = new MinAmountValidations(); 

	for (x in oAmount) {
    	if (form[oAmount[x][0]]) {
			if (form[oAmount[x][0]].value < 10 ){
           	fields[i++] = oAmount[x][1];
			bValid = false;
			}
        }
	}                                                                                                   

    if (fields.length > 0) {
        alert(fields.join('\n'));                                                                      
	}                                                                                                   
	
	return bValid;

}

function validateAmount(form) {
				
	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oAmount = new AmountValidations();                                                                         

    for (x in oAmount) {                                                                              
	    if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length > 0) {   

	        var iValue = form[oAmount[x][0]].value;

            var pattern=new RegExp("^[0-9\\,\\s\\.]+$");
			var pattern2=new RegExp("^[0-9\\,\\s]*\\.([0-9\\s]{0,2})$");
			var pattern3=new RegExp("^[0-9\\,\\s]+[0-9\\s]{3,}$");
			var pattern6 = new RegExp("^[0-9\\s]+$");
  			var pattern4 =new RegExp("^[0-9\\s]*\\,([0-9\\s]{0,2})$");
 
  			var antipattern5 = new RegExp("^[0\\,\\.\\s]+$");

		 	if ((!pattern.test(iValue)) || (!pattern2.test(iValue) && !pattern3.test(iValue) && !pattern6.test(iValue) && !pattern4.test(iValue)) || (antipattern5.test(iValue))) {
  					  
				if (i == 0)
      				focusField = form[oAmount[x][0]];
      						
      			fields[i++] = oAmount[x][1];
      			bValid = false;
  					  
  			} 
        }                                                                                               
    }                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
    }                                                                                                   

    return bValid;                                                                                      
}

//the amount field in pay bills form allows max 9 digit values

function validatePayAmount(form) {
								
	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oAmount = new AmountValidations();                                                                         

    for (x in oAmount) {                                                                              
	    if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length > 0) {   

	        var iValue = form[oAmount[x][0]].value;

            var pattern=new RegExp("^[0-9\\,\\s\\.]+$");
			var pattern2=new RegExp("^[0-9\\,\\s]*\\.([0-9\\s]{0,2})$");
			var pattern3=new RegExp("^[0-9\\,\\s]+[0-9\\s]{3,}$");
			var pattern6 = new RegExp("^[0-9\\s]+$");
  			var pattern4 =new RegExp("^[0-9\\s]*\\,([0-9\\s]{0,2})$");
 
  			var antipattern5 = new RegExp("^[0\\,\\.\\s]+$");

			var pattern7 = new RegExp("^[0-9\\s]{1,9}$");
			var pattern8 = new RegExp("^[0-9]+$");


		 	if ((!pattern.test(iValue)) || (!pattern2.test(iValue) && !pattern3.test(iValue) && !pattern6.test(iValue) && !pattern4.test(iValue)) || (antipattern5.test(iValue))) {
  					  
				if (i == 0)
      				focusField = form[oAmount[x][0]];
      						
      			fields[i++] = oAmount[x][1];
      			bValid = false;
  					  
  			} 
  			
  			if(pattern8.test(iValue) && (!pattern7.test(iValue))){
				if (i == 0) {
      				focusField = form[oAmount[x][0]];
				}
      			fields[i++] = oAmount[x][1];
      			bValid = false;
  			}
  			
        }                                                                                               
    }                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
    }                                                                                                   

    return bValid;                                                                                      
}


function validateTCFXAmount(form) {

				
	var bValid = false;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oAmount = new TCFXAmountValidations();                                                                         


    for (x in oAmount) {                                                                              

		var parameterNumber = oAmount[x][2]("parameterNumber");

		for (j = 1; j <= parameterNumber; j++ ) { 
			parameter = oAmount[x][2]("param"+j.toString());

			value = eval ("form."+parameter+".value");

			if (value != 0) {
				bValid = true;
				break;
			}
		}

		if (!bValid) { 
	  		focusField = form[oAmount[x][0]];
	  		fields[i++] = oAmount[x][1];
			focusField.focus();
	        alert(fields.join('\n'));                                                                      
		}
	}

	return bValid;
	
}


function validateMustBeDifferent(form) {
			
	var radio_choice = false;
	var mustBeDifferent = new mustbedifferent();
	var fields = new Array();

	if(form.mode.value != "confirm")
	{
		return true;
	}

	var newValue = form.change.value;
	var oldValue = form.mustbedifferent.value;				



	if (newValue == oldValue) {
		fields[1]=mustBeDifferent[x][1];
		alert(fields.join('\n'));
		return (false);
	} 
						
	return (true);
}


//


function validateConsolidatedAccounts(form) {


    var bValid = true;
	var masterValid = true;
	var minOnesource = new validatesource();  
    var i = 0;                                                                                          
	var fields = new Array();
			
	// set var checkbox_choices to zero
	var checkbox_choices = 0;
	if(form.mode.value == "form" )
	{
		return true;
	}

	if(form.consolidate == null) {
		return(false);
	}
	
	var ccounter = 0;							
	// Loop from zero to the one minus the number of checkbox button selections
	for (counter = 0; counter < form.consolidate.length; counter++) {
			
		// If a checkbox has been selected it will return true
		// (If not it will return false)
		if (form.consolidate[counter].checked) { 
			ccounter = ccounter + 1; 
		}
	}

			
	// If three were selected then display an alert box stating input was OK

	for(x in minOnesource)
	{
		if(ccounter <= 1)
		{
			fields[i++] = minOnesource[x][1];
			break;
		}

	}
	if(fields.length > 0) {
		alert(fields.join('\n'));
		return false;
	}
					
}


function validateTargetAccount(form) {
			
	var radio_choice = false;
	var minOneaccount = new validatetarget();
	var fields = new Array();


	if(form.mode.value == "form" )
	{
		return true;
	}

	if(form.mode.value != "confirm" )
	{
		return true;
	}

	if(form.account == null)
	{
		for(x in minOneaccount)
		{
			fields[1]=minOneaccount[x][1];
			alert(fields.join('\n'));
			return (false);
		}
	}							

	for (counter = 0; counter < form.account.length; counter++)	{

		if (form.account[counter].checked) {
			radio_choice = true;
		} 

	}
	
	if(form.account.checked) {
		return(true);
	}
						
	if (!radio_choice) {
		for(x in minOneaccount)
		{
			fields[1]=minOneaccount[x][1];
			alert(fields.join('\n'));
			return (false);
		}
	}
	
	return (true);
}



//

function validateMinimumOneRadio(form) {
			
	var radio_choice = false;
	var minOneRadio = new minoneradio();
	var fields = new Array();

	if(form.mode.value != "form2" )
	{
		return true;
	}

	if(form.tobechanged == null)
	{
		for(x in minOneRadio)
		{
			fields[1]=minOneRadio[x][1];
			alert(fields.join('\n'));
			return (false);
		}
	}							

	for (counter = 0; counter < form.tobechanged.length; counter++)	{
		// If a radio button has been selected it will return true
		// (If not it will return false)

		if (form.tobechanged[counter].checked) {
			radio_choice = true;
		} 

	}
	
	if(form.tobechanged.checked) {
		return(true);
	}
						
	if (!radio_choice) {
		for(x in minOneRadio)
		{
			fields[1]=minOneRadio[x][1];
			alert(fields.join('\n'));
			return (false);
		}
	}
	
	return (true);
}



function validateOlbDateGreaterEqual(form){
    var bValid = true;
	
	oOlbGreaterEqual = new olbDateValidationGreaterEqual();  
    var i = 0;                                                                                          
	var fields = new Array();
	for(x in oOlbGreaterEqual)
	{
		if (form.saveActivityRadio[1].checked){
			var fromMonthLabel = oOlbGreaterEqual[x][2]("olbmonth");
			var fromYearLabel = oOlbGreaterEqual[x][2]("olbyear");
			var toMonthLabel = oOlbGreaterEqual[x][2]("olbmonth2");
			var toYearLabel = oOlbGreaterEqual[x][2]("olbyear2");
			var toDayLabel = oOlbGreaterEqual[x][2]("olbday2");
	
			var fromDayValue = form[oOlbGreaterEqual[x][0]].value;				
	
			if(fromYearLabel.length > 0 && fromMonthLabel.length > 0 && 
				toYearLabel.length>0 && toMonthLabel.length>0 && toDayLabel.length>0)
			{	
	
				// get values from the form
				var fromMonthValue = eval("form."+fromMonthLabel+".value");				
				var fromYearValue = eval("form."+fromYearLabel+".value");
				var toDayValue = eval("form."+toDayLabel+".value");				
				var toMonthValue = eval("form."+toMonthLabel+".value");				
				var toYearValue = eval("form."+toYearLabel+".value");
				
				if(fromMonthValue == "" && fromDayValue == "" && fromYearValue == "" 
				&& toYearValue == "" && toDayValue == "" && toMonthValue == "")
				{						
					return bValid;
				}
	
				// convert values to int (ensure base-10 conversion for parseInt())		
				var fromDayInt = parseInt(fromDayValue,10);
				var fromMonthInt = parseInt(fromMonthValue,10);
				var fromYearInt = parseInt(fromYearValue,10);
				var toDayInt = parseInt(toDayValue,10);
				var toMonthInt = parseInt(toMonthValue,10);
				var toYearInt = parseInt(toYearValue,10);
	
				// standardize to/from dates with the same time for apple-apple comparison
				var fromDate = new Date(fromYearInt,fromMonthInt-1,fromDayInt,0,0,0,0);	
				var toDate = new Date(toYearInt, toMonthInt-1, toDayInt,0,0,0,0);
				var diff = toDate-fromDate;  				// difference in ms
				var diffStr = new String(diff/86400000);    //calculate days and convert to string			

				var point=diffStr.indexOf(".");    				//find the decimal point
				var daysStr=diffStr.substring(0,point);    		//get just the whole days				
				if (point>0){								// a decimal point occurs
					days=parseInt(daysStr);
				}
				else {
					days = parseInt(diffStr);
				}	

				if (days<0) {
		            fields[i++] = oOlbGreaterEqual[x][1];
	            	bValid = false;                                                                             
				}
			}
		}
	}	
    if (fields.length > 0) {
        alert(fields.join('\n'));                                                                      
	}                                                                                                   
	return bValid;   
}



function validateOlbTodayPlus(form) {

    var bValid = true;
	
	var masterValid = true;
	olbDate = new olbdateplus();  
    var i = 0;                                                                                          
	var focusField = null;
	var fields = new Array();
	for(x in olbDate)
	{
		var mmonth = olbDate[x][2]("olbmonth");
		var yyear = olbDate[x][2]("olbyear");
		var days = olbDate[x][2]("days");
		var compare = olbDate[x][2]("comparison");
		var checkday = form[olbDate[x][0]].value;
				
		if(yyear.length > 0 && mmonth.length > 0 && checkday.length > 0)
		{	



			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value");

			if(checkday == "" && checkmonth == "" && checkyear == "")
			{						
				return bValid;
			}

			var plusday = checkday;
			
			// decimal values (known Jscript error if checkday={"08","09"})
			var intDay = parseInt(checkday,10);
			var intDays = parseInt(days,10);

			var requestDate = new Date(checkyear,checkmonth-1,intDay+intDays,0,0,0,0);	
			var requestTime = requestDate.getTime();
			
			var nowDate = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0);
			var otherTime = nowDate.getTime();

			if(compare == ".le.")
			{
				if(requestTime <= otherTime)
				{
					if (i == 0) {
            			focusField = form[mmonth]; 
             	  	}
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
				}
			}
			if(compare == ".ge.")
			{
				if(requestTime >= otherTime)
				{
					if (i == 0) {
            			focusField = form[mmonth]; 
             	  	}
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			
			if(compare == ".eq.")
			{
				if(requestTime == otherTime)
				{
					if (i == 0) {
            			focusField = form[mmonth]; 
             	  	}
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".gt.")
			{
				if(requestTime > otherTime)
				{
					if (i == 0) {
            			focusField = form[mmonth]; 
             	  	}
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".lt.")
			{
				if(requestTime < otherTime)
				{
					if (i == 0) {
            			focusField = form[mmonth]; 
             	  	}
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".ne.")
			{
				if(requestTime != otherTime)
				{
					if (i == 0) {
            			focusField = form[mmonth]; 
             	  	}
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
						
		}
	}
	
    
   

    	
	if(fields.length > 0) {
		focusField.focus();
		alert(fields.join('\n'));
	}
				
				
																
	return masterValid;
				
}

//

function validateOlbTodayPlusYears(form) {

    var bValid = true;
	
	var masterValid = true;
	olbDate = new olbdateplusyears();  
    var i = 0;                                                                                          
	var focusField = null;
	var fields = new Array();
	var serveryear = form.serveryear.value;
	var servermonth = form.servermonth.value;
	var serverday = form.serverday.value;
	for(x in olbDate)
	{
		var mmonth = olbDate[x][2]("olbmonth");
		var yyear = olbDate[x][2]("olbyear");
		var years = olbDate[x][2]("years");
		var compare = olbDate[x][2]("comparison");
		var checkday = form[olbDate[x][0]].value;
				
		if(yyear.length > 0 && mmonth.length > 0 && checkday.length > 0)
		{	



			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value");

			if(checkday == "" && checkmonth == "" && checkyear == "")
			{						
				return bValid;
			}

			var plusday = checkday;

			var requestTime = new Date(parseInt(years,10)+parseInt(checkyear,10),checkmonth-1,checkday,0,0,0,0).getTime();

			var otherTime = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0).getTime();
			
			if(compare == ".le.")
			{
				if(requestTime <= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
				}
			}
			if(compare == ".ge.")
			{
				if(requestTime >= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			
			if(compare == ".eq.")
			{
				if(requestTime == otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".gt.")
			{
				if(requestTime > otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".lt.")
			{
				if(requestTime < otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".ne.")
			{
				if(requestTime != otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
						
		}
	}
			
	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
				
				
																
	return masterValid;
				
}




function validateOlbTodayPlusYears1(form) {

    var bValid = true;
	
	var masterValid = true;
	olbDate = new olbdateplusyears1();  
    var i = 0;                                                                                          
	var focusField = null;
	var fields = new Array();
	var serveryear = form.serveryear.value;
	var servermonth = form.servermonth.value;
	var serverday = form.serverday.value;
	for(x in olbDate)
	{
		var mmonth = olbDate[x][2]("olbmonth");
		var yyear = olbDate[x][2]("olbyear");
		var years = olbDate[x][2]("years1");
		var compare = olbDate[x][2]("comparison1");
		var checkday = form[olbDate[x][0]].value;
				
		if(yyear.length > 0 && mmonth.length > 0 && checkday.length > 0)
		{	



			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value");

			if(checkday == "" && checkmonth == "" && checkyear == "")
			{						
				return bValid;
			}


			var plusday = checkday;

			var requestTime = new Date(parseInt(years,10)+parseInt(checkyear,10),checkmonth-1,checkday,0,0,0,0).getTime();

			var otherTime = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0).getTime();
			
			if(compare == ".le.")
			{
				if(requestTime <= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
				}
			}
			if(compare == ".ge.")
			{
				if(requestTime >= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			
			if(compare == ".eq.")
			{
				if(requestTime == otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".gt.")
			{
				if(requestTime > otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".lt.")
			{
				if(requestTime < otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".ne.")
			{
				if(requestTime != otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
						
		}
	}
			
	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
				
				
																
	return masterValid;
				
}

function validateOlbTodayPlusYears2(form) {

    var bValid = true;
	
	var masterValid = true;
	olbDate = new olbdateplusyears2();  
    var i = 0;                                                                                          
	var focusField = null;
	var fields = new Array();
	var serveryear = form.serveryear.value;
	var servermonth = form.servermonth.value;
	var serverday = form.serverday.value;
	for(x in olbDate)
	{
		var mmonth = olbDate[x][2]("olbmonth");
		var yyear = olbDate[x][2]("olbyear");
		var years = olbDate[x][2]("years2");
		var compare = olbDate[x][2]("comparison2");
		var checkday = form[olbDate[x][0]].value;
				
		if(yyear.length > 0 && mmonth.length > 0 && checkday.length > 0)
		{	



			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value");

			if(checkday == "" && checkmonth == "" && checkyear == "")
			{						
				return bValid;
			}

			var plusday = checkday;

			var requestTime = new Date(parseInt(years,10)+parseInt(checkyear,10),checkmonth-1,checkday,0,0,0,0).getTime();

			var otherTime = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0).getTime();
			
			if(compare == ".le.")
			{
				if(requestTime <= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
				}
			}
			if(compare == ".ge.")
			{
				if(requestTime >= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			
			if(compare == ".eq.")
			{
				if(requestTime == otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".gt.")
			{
				if(requestTime > otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".lt.")
			{
				if(requestTime < otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".ne.")
			{
				if(requestTime != otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
						
		}
	}
			
	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
				
				
																
	return masterValid;
				
}




//

function validateOlbTodayPlus1(form) {


    var bValid = true;
	
	var masterValid = true;
	olbDate = new olbdateplus1();  
    var i = 0;                                                                                          
	var focusField = null;
	var fields = new Array();

	for(x in olbDate)
	{
		var mmonth = olbDate[x][2]("olbmonth");
		var yyear = olbDate[x][2]("olbyear");
		var days = olbDate[x][2]("days1");
		var checkday = form[olbDate[x][0]].value;
		var compare = olbDate[x][2]("comparison1");

		
		if(yyear.length > 0 && mmonth.length > 0 && checkday.length > 0)
		{	



			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value");
			
			var plusday = checkday;
			
			if(checkday == "" && checkmonth == "" && checkyear == "")
			{						
				return bValid;
			}
			

			var plusday = checkday;
			
			var intDay = parseInt(checkday,10);
			var intDays = parseInt(days,10);

			var requestDate = new Date(checkyear,checkmonth-1,intDay+intDays,0,0,0,0);	
			var requestTime = requestDate.getTime();
			
			var nowDate = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0);
			var otherTime = nowDate.getTime();


			if(compare == ".le.")
			{
				if(requestTime <= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
				}
			}
			if(compare == ".ge.")
			{
				if(requestTime >= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			
			if(compare == ".eq.")
			{
				if(requestTime == otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".gt.")
			{
				if(requestTime > otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".lt.")
			{
				if(requestTime < otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".ne.")
			{
				if(requestTime != otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
		}
	}
			
	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
				
				
																
	return masterValid;
				
}


//

function validateOlbTodayPlus2(form) {


    var bValid = true;
	
	var masterValid = true;
	olbDate = new olbdateplus2();  
    var i = 0;                                                                                          
	var focusField = null;
	var fields = new Array();
	var serveryear = form.serveryear.value;
	var servermonth = form.servermonth.value;
	var serverday = form.serverday.value;

	for(x in olbDate)
	{
		var mmonth = olbDate[x][2]("olbmonth");
		var yyear = olbDate[x][2]("olbyear");
		var days = olbDate[x][2]("days2");
		var checkday = form[olbDate[x][0]].value;
		var compare = olbDate[x][2]("comparison2");

		
		if(yyear.length > 0 && mmonth.length > 0 && checkday.length > 0)
		{	



			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value");
			
			var plusday = checkday;

			if(checkday == "" && checkmonth == "" && checkyear == "")
			{						
				return bValid;
			}
				
				
			var plusday = checkday;
			
			var intDay = parseInt(checkday,10);
			var intDays = parseInt(days,10);

			var requestDate = new Date(checkyear,checkmonth-1,intDay+intDays,0,0,0,0);	
			var requestTime = requestDate.getTime();
			
			var nowDate = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0);
			var otherTime = nowDate.getTime();

			if(compare == ".le.")
			{
				if(requestTime <= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
				}
			}
			if(compare == ".ge.")
			{
				if(requestTime >= otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			
			if(compare == ".eq.")
			{
				if(requestTime == otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".gt.")
			{
				if(requestTime > otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".lt.")
			{
				if(requestTime < otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
			if(compare == ".ne.")
			{
				if(requestTime != otherTime)
				{
				
					fields[i++] = olbDate[x][1];
					masterValid = false;
					break;									
									
				}
			
			}
		}
	}
			
	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
				
				
																
	return masterValid;
				
}





function validateOlbTodayOrLater(form) {

    var bValid = true;
	var masterValid = true;

	olbDate = new olbdateOrLater();  
    var i = 0;                                                                                          

	for(x in olbDate) {

		var mmonth = olbDate[x][2]("olbmonth");
		var yyear = olbDate[x][2]("olbyear");
		
		var checkday = form[olbDate[x][0]].value;
		
		if(yyear.length > 0 && mmonth.length > 0 && checkday.length > 0){	

			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value"); 
			var requestDate = new Date(parseInt(checkyear,10),parseInt(checkmonth,10),parseInt(checkday,10),0,0,0,0);	
			var requestTime = requestDate.getTime();
			
			var focusField = null;
			var fields = new Array();
			
			var nowDate = new Date(olbServerYear, olbServerMonth, olbServerDay,0,0,0,0);
			var nowDay = nowDate.getDate();
			var nowMonth = nowDate.getMonth()+1;
			var nowYear = nowDate.getFullYear();
			var normalizedNowDate = new Date(parseInt(nowYear,10),parseInt(nowMonth,10),parseInt(nowDay,10),0,0,0,0);
			var nowTime = normalizedNowDate.getTime();

			if(requestTime > nowTime) {
				fields[i++] = olbDate[x][1];
				masterValid = false;
			}
		}
	}
			
	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
																
	return masterValid;
}



function validateSkipDate(form) {

    var bValid = true;
	var masterValid = true;
	var olbDate = new skipdate();  
    var i = 0;                                                                                          
	var fields = new Array();
	var focusField = null;
	for(x in olbDate)
	{
		var mmonth = olbDate[x][2]("olbmonth");
		var yyear = olbDate[x][2]("olbyear");
		
		var checkday = form[olbDate[x][0]].value;

			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value"); 

			if(checkday != "" && checkmonth != "" && checkyear != "")
			{						
				bValid = isValidDate(checkday, checkmonth, checkyear);
				if(!bValid)
				{
				  	if (i == 0) {
            			focusField = form[olbDate[x][0]]; 
             	  	}

					fields[i++] = olbDate[x][1];
					masterValid = false;
				}
			}
	}
			
	if(fields.length > 0) {
	    focusField.focus();

		alert(fields.join('\n'));
	}
				
	olbDate = null;															

	return masterValid;
}



function validateOlbDate(form) {

    var bValid = true;
	var masterValid = true;
	var olbDate = new olbdate();  
    var i = 0;                                                                                          

	var fields = new Array();
	var focusField = null;
	for(x in olbDate)
	{
		var mmonth = olbDate[x][2]("olbmonth");
		var yyear = olbDate[x][2]("olbyear");
		
		var checkday = form[olbDate[x][0]].value;

			var checkmonth = eval("form."+mmonth+".value");				
			var checkyear = eval("form."+yyear+".value"); 
			if(checkday != "" || checkmonth != "" || checkyear != "")
			{						
				bValid = isValidDate(checkday, checkmonth, checkyear);
				if (checkyear==""){
					bValid=false;
				}
				if(!bValid)
				{
				  	if (checkmonth == "") {
            			focusField = eval("form."+mmonth); 
             	  	}else if(checkyear == ""){
             	  		focusField = eval("form."+yyear);
             	  	}else{
             	  		focusField = form[olbDate[x][0]];;
             	  	}

					fields[i++] = olbDate[x][1];
					masterValid = false;
				}
			}
	}
			
	if(fields.length > 0) {
	    focusField.focus();

		alert(fields.join('\n'));
	}
				
	olbDate = null;															

	return masterValid;
}



function validateDependency(form) {

	var bValid = true;
    var focusField = null;

    var fields = new Array();                                                                           

    list = new dependency();                                                                         

    for (x in list) {                                                                              

		var dependent = list[x][2]("dependent");
		try {
	    	if ((form[list[x][0]].type == form[dependent].type))  {
        
		   		if (form[list[x][0]].value != '' && form[dependent].value != '') {
	   				bValid = false;
	   			} else {
	   				if (form[list[x][0]].value == '' && form[dependent].value == '') {
		            	bValid = false;                                                                             	   			
		   			} else {
	   				    bValid = true;                                                                             	   			
	   				}
	   			}
	        
	        	if (bValid == false) {
            		focusField = form[list[x][0]]; 
        	    	fields[0] = list[x][1];
        	    	
        	    	break;
            	}
       		}
        } catch (ex) {
			alert ('Unsupported field type');
		}                                                                                               
	}                                                                                                   

    if (fields.length > 0) {
	    focusField.focus();
        alert(fields.join('\n'));   
	}                                                                                                   

	return  bValid;               
}


///////////////////////////////////////////////////////////
//Please note that the "magic numbers" of the accountType
//have to match numbers from the AddBMOAccountForm.jsp 
//Those numbers have to be in sync with AccountType.java
///////////////////////////////////////////////////////////
function validateDependentAccountType(form) {

    var bValid = true;
	var masterValid = true;

	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    //oDependent = new DependentAccountTypeValidations ();  
    var formName = form.getAttributeNode("name");
    oDependent = eval('new ' + formName.value + '_DependentAccountTypeValidations()');                                                                          

    for (x in oDependent) {                                                                              
		var dependent = oDependent[x][2]("dependent");
		var accountType = eval("form." + dependent);
		    	
		if (( accountType.value == '0'  || //Bank Account
			  accountType.value == '1'  || //Deposit Investment
			  accountType.value == '2'  || //Investment
			  accountType.value == '3')	&& //Loan Account
			  form[oDependent[x][0]].value.length != 11 ) {
   		
   			if (i == 0) {
            	focusField = form[oDependent[x][0]]; 
            }
            
            fields[i++] = oDependent[x][1];

            bValid = false;                                                                             
        }

		if (( accountType.value == '4'  || //Line of Credit
			  accountType.value == '6')	&& //Credit Card
			  form[oDependent[x][0]].value.length != 16 ) {
   		
   			if (i == 0) {
            	focusField = form[oDependent[x][0]]; 
            }
            
            fields[i++] = oDependent[x][1];

            bValid = false;                                                                             
        }

		if (( accountType.value == '5') && //Mortgage
			  form[oDependent[x][0]].value.length != 10 ) {
   		
   			if (i == 0) {
            	focusField = form[oDependent[x][0]]; 
            }
            
            fields[i++] = oDependent[x][1];

            bValid = false;                                                                             
        }
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;   
}


function validateDeleteBillerCheckbox(form) {


    var bValid = true;
	var masterValid = true;
	//var minOneCheckbox = new minonecheckbox(); 
	var formName = form.getAttributeNode("name");
    minOneCheckbox = eval('new ' + formName.value + '_minonecheckbox()');    
    var i = 0;                                                                                          
	var fields = new Array();
			
	// set var checkbox_choices to zero
	var checkbox_choices = 0;

	if(form.tobedeleted == null) {
		return(false);
	}
								
	// Loop from zero to the one minus the number of checkbox button selections
	for (counter = 0; counter < form.tobedeleted.length; counter++) {
			
		// If a checkbox has been selected it will return true
		// (If not it will return false)
		if (form.tobedeleted[counter].checked) { 
			return(true); 
		}
	}

	// it could still be ok, because when there is only one
	// checkbox left, then it is NOT a multicheckbox situation
	if (form.tobedeleted.checked) {
		return(true);
	}
			
	// If three were selected then display an alert box stating input was OK

	for(x in minOneCheckbox)
	{

		fields[i++] = minOneCheckbox[x][1];
		break;

	}
	if(fields.length > 0) {
		alert(fields.join('\n'));
		return false;
	}
					
}

function validateAmountRange(form) {
				
	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    //oAmount = new AmountRangeValidations(); 
    var formName = form.getAttributeNode("name");
    oAmount = eval('new ' + formName.value + '_AmountRangeValidations()');                                                                           

    for (x in oAmount) {                                                                              
		if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length > 0) {   

			var iValue = form[oAmount[x][0]].value;

            var pattern = new RegExp("^[0-9]+([,\\.\\-][0-9]+)?$");
                      
  			if (!pattern.test(iValue)) {
  					  
  				if (i == 0) {
      				focusField = form[oAmount[x][0]];
      			}
      						
      			fields[i++] = oAmount[x][1];
      			bValid = false;
  					  
  			} 
        }                                                                                               
	}                                                                                                   

    if (fields.length > 0) {
	    focusField.focus();

        alert(fields.join('\n'));                                                                      
    }                                                                                                   

    return bValid;                                                                                      
}

function validateExpiryFormat(form) {
				
	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

//    oExpiryFmt = new CardExpFmt(); 
    var formName = form.getAttributeNode("name");
    oExpiryFmt = eval('new ' + formName.value + '_CardExpFmt()()');                                                                        

    for (x in oExpiryFmt) {                                                                              
		if ((form[oExpiryFmt[x][0]].type == 'text' || 
		     form[oExpiryFmt[x][0]].type == 'textarea' || 
		     form[oExpiryFmt[x][0]].type == 'select-one' || 
		     form[oExpiryFmt[x][0]].type == 'radio') && form[oExpiryFmt[x][0]].value.length > 0) {   

	        var iValue = form[oExpiryFmt[x][0]].value;
                       
            var pattern = new RegExp("^((0[1-9])|(1[0-2]))/[0-9]{2}$");
                      
		 	if ( !pattern.test(iValue) ) {
  					  
  				if (i == 0)
      				focusField = form[oExpiryFmt[x][0]];
      						
      			fields[i++] = oExpiryFmt[x][1];
      			bValid = false;
  			} 
        }                                                                                               
    }                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

       alert(fields.join('\n'));                                                                      
    }                                                                                                   

    return bValid;                                                                                      
}
            
function validateExpiryRequired(form) {
			
	var bValid = true;
	var focusField = null;

	var i = 0;                                                                                          
	var fields = new Array();                                                                           

	//oExpiryRqd = new CardExpRqd();
	var formName = form.getAttributeNode("name");
    oExpiryRqd = eval('new ' + formName.value + '_CardExpRqd');                                                                         


	for (x in oExpiryRqd) {                                                                                             
		if (form.accountfrom.value.indexOf("false")!=-1){
					
			if (form[oExpiryRqd[x][0]].value.length == 0){
				if (i == 0)
  					{focusField = form[oExpiryRqd[x][0]];}
				
				fields[i++] = oExpiryRqd[x][1];
  				bValid = false;
			}
		}            
	} 

    if (fields.length > 0) {

       focusField.focus();

       alert(fields.join('\n'));                                                                      
    }                                                                                                                                                                                                        

    return bValid;                                                                                      
}                        

function validateExpiryNotRequired(form) {
			
	var bValid = true;
	var focusField = null;

	var i = 0;                                                                                          
	var fields = new Array();                                                                           

	//oExpiryNRqd = new CardExpNRqd(); 
	var formName = form.getAttributeNode("name");
    oExpiryNRqd = eval('new ' + formName.value + '_CardExpNRqd()');                                                                        


	for (x in oExpiryNRqd) {                                                                                             
		if (form.accountfrom.value.indexOf("false")==-1){
					
			if (form[oExpiryNRqd[x][0]].value.length != 0){
				if (i == 0)
  					{focusField = form[oExpiryNRqd[x][0]];}
				
				fields[i++] = oExpiryNRqd[x][1];
  				bValid = false;
			}
		}            
	} 

    if (fields.length > 0) {

       focusField.focus();

       alert(fields.join('\n'));                                                                      
    }                                                                                                                                                                                                        

    return bValid;                                                                                      
}

function validateSame(form) {
	
    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
   
    //oSame = new sameFields(); 
    var formName = form.getAttributeNode("name");
    oSame = eval('new ' + formName.value + '_sameFields()');                                                                        
		
    for (x in oSame) {  
                                                                                
        if ((form[oSame[x][0]].type == 'text' || 
             form[oSame[x][0]].type == 'textarea' || 
             form[oSame[x][0]].type == 'password') && form[oSame[x][0]].value.length > 0) {   
			
			var value = oSame[x][2]("same");
			var	value1 = eval("form." + value + ".value");				
			
			if (form[oSame[x][0]].value!=value1) {
				fields[i++] = oSame[x][1];
				if (focusField == null) {
					focusField = form[oSame[x][0]];
				}
		
				bValid = false;
			}

    	}                                                                                                   

    }
 
    if (fields.length > 0) {
       	focusField.focus();

       	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;
}           

function validateSameEvenIfTheFirstOneIsEmpty(form) {
	
    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
   
    //oSame = new sameFieldsEvenIfTheFirstOneIsEmpty(); 
    var formName = form.getAttributeNode("name");
    oSame = eval('new ' + formName.value + '_sameFieldsEvenIfTheFirstOneIsEmpty()');                                                                        
		
    for (x in oSame) {  
        if ((form[oSame[x][0]].type == 'text' || 
             form[oSame[x][0]].type == 'textarea' || 
             form[oSame[x][0]].type == 'password')) {   
			
			var value = oSame[x][2]("same");
			var	value1 = eval("form." + value + ".value").toLowerCase();				
			var value2 = form[oSame[x][0]].value.toLowerCase();
			if (value2 != value1) {
				fields[i++] = oSame[x][1];
				if (focusField == null) {
					focusField = form[oSame[x][0]];
				}
		
				bValid = false;
			}

    	}                                                                                                   

    }
 
    if (fields.length > 0) {
       	focusField.focus();

       	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;
}           

function requiredDynamic(form) {
	
 	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
	var question = "";
    if(form.minQuestion)
    	question= form.minQuestion.value;
	
    //oRequired = new reqDyn();  
    var formName = form.getAttributeNode("name");
    oRequired = eval('new ' + formName.value + '_reqDyn()');                                                                       

    for (x in oRequired) {   
                                                                               
    	var number = oRequired[x][2]("number");
		
    	if(number<=question)
    	{
    	 if ((form[oRequired[x][0]].type == 'text' || form[oRequired[x][0]].type == 'textarea' || form[oRequired[x][0]].type == 'select-one' || form[oRequired[x][0]].type == 'radio' || form[oRequired[x][0]].type == 'password') && form[oRequired[x][0]].value == '') {

			if (i == 0)

            focusField = form[oRequired[x][0]]; 
            fields[i++] = oRequired[x][1];

            bValid = false;                                                                             

         }                                                                                               
		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      

}
function validateSameDynamic(form) {
	
    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
    var question = "";
    if(form.minQuestion)
    	question= form.minQuestion.value;
    //oSame = new ValSameDyn(); 
    var formName = form.getAttributeNode("name");
    oSame = eval('new ' + formName.value + '_ValSameDyn()');                                                                        
	
	for (x in oSame) { 
	
	var number = oSame[x][2]("number");
	
   	if(number<=question)
    {
	    if ((form[oSame[x][0]].type == 'text' || form[oSame[x][0]].type == 'textarea') && form[oSame[x][0]].value.length > 0) {   
			
				var value = oSame[x][2]("same");
				var value1 = eval("form."+value+".value");				
					
			if (form[oSame[x][0]].value!=value1) {
				fields[i++] = oSame[x][1];
				if (focusField == null) {
					focusField = form[oSame[x][0]];
				}
				bValid = false;
			}

    	  }
    	}                                                                                                   

    }
 
    if (fields.length > 0) {
       	focusField.focus();
       	alert(fields.join('\n'));                                                                      
	}
				
	return bValid;
} 
function minimumDynamic(form) {                                                                                                    

    var bValid = true;
    var focusField = null;

    var i = 0;                                                                                                                    
    var fields = new Array();                                                                                                     

	var question = "";
    if(form.minQuestion)
    	question= form.minQuestion.value;
    //oMinLength = new minDyn(); 
    var formName = form.getAttributeNode("name");
    oMinLength = eval('new ' + formName.value + '_minDyn()');                                                                        
	
	for (x in oMinLength) { 
	
	var number = oMinLength[x][2]("number");
	
   	if(number<=question)
    {
	     if (form[oMinLength[x][0]].type == 'text' || form[oMinLength[x][0]].type == 'textarea') {   
     	      var iMin = parseInt(oMinLength[x][2]("minlength"),10);
	
     	      if (!(form[oMinLength[x][0]].value.length >= iMin)) {

     	         if (i == 0)
     	            focusField = form[oMinLength[x][0]]; 
	
      	        fields[i++] = oMinLength[x][1];

      	        bValid = false;                                                                                                     
      	     }                                                                                                                      
      	  }
      	}                                                                                                                         
    }                                                                                                                             

    if (fields.length > 0) {

       focusField.focus();

       alert(fields.join('\n'));                                                                                                  
    }                                                                                                                             

    return bValid;                                                                                                                
}     

function validateMaskDynamic(form) {                                                                                                    

    var bValid = true;
    var focusField = null;
    var i = 0;                                                                                                                    
    var fields = new Array();                                                                                                     

                                                                                                      
    var question = "";
    if(form.minQuestion)
    	question= form.minQuestion.value;
    //oMasked = new maskDyn(); 
    var formName = form.getAttributeNode("name");
    oMasked = eval('new ' + formName.value + '_maskDyn()');                                                                        
	
	for (x in oMasked) { 
	
		var number = oMasked[x][2]("number");
	
   		if(number<=question)
    	{
      		                                                                                                         
        		if ((form[oMasked[x][0]].type == 'text' || form[oMasked[x][0]].type == 'textarea' || form[oMasked[x][0]].type == 'password') && form[oMasked[x][0]].value.length > 0) 
        		{   
           				if (!matchPattern(form[oMasked[x][0]].value, oMasked[x][2]("mask")))
           				{
	
    	          			if (i == 0)
        	      			{
            	     			focusField = form[oMasked[x][0]]; 
							}
              				fields[i++] = oMasked[x][1];

	              			bValid = false;                                                                                                     
    	      			 }                                                                                                                      
        		} 
   		}                                                                                                                         
	}
    
    if (fields.length > 0) {

       focusField.focus();

       alert(fields.join('\n'));                                                                                                  
    }                                                                                                                             

    return bValid;                                                                                                                
}

function validateAccountBasedOnCharacteristics(form) {

	var ret = true;
	var masterValid = true;
	var validator = new accountCharacteristicsBasedValidator();  
	var fields = new Array();
	var i = 0;
	if(form.mode.value == "confirm") {
		var isAlphaAllowed = eval(form.accountNrAlphaAllowed.value);
		
		var accountNrMinLen;
		if (eval(form.accountNrMinLen.value)) {
			accountNrMinLen = form.accountNrMinLen.value;
		}
		else {
			accountNrMinLen = form.accountNrMaxLen.value;
		}
		var accountNrMaxLen = form.accountNrMaxLen.value;
		var accountNr = form.accountNr.value;
		var regExp;
		for(x in validator) {
			if(isAlphaAllowed) {
				regExp = "^[A-Za-z0-9]{" +accountNrMinLen + "," + accountNrMaxLen + "}$";
			} else {
				regExp = "^[0-9]{" +accountNrMinLen + ","  + accountNrMaxLen + "}$";
			}
			var pattern = new RegExp(regExp);
			if(!pattern.test(accountNr)) {
				fields[i++] = validator[x][1];
				ret = false;
				break;
			}		
		}
	}

	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
	
	return ret;
}

function validateMinMaxAccountLength(form)
{

    var bValid = true;
	var masterValid = true;
	//var minMaxAlpha = new minmaxalpha();
	var formName = form.getAttributeNode("name");
    minMaxAlpha = eval('new ' + formName.value + '_minmaxalpha()');  
    var i = 0;                                                                                          
	var fields = new Array();
	var focusField = null;

	if(form.mode.value == "form2" || form.mode.value == "cancel")
	{
		return true;
	}

	var max = accountsize;
	var min = minaccountsize;
	var alpha = alphaAllowed;
	var change = form.change.value.length;
	var changeNumber = form.change.value;
	

	i = 0;
	for(x in minMaxAlpha)
	{
		
		
		if(change < min || change > max )
		{	
			fields[i++] = minMaxAlpha[x][1];
			masterValid = false;
			break;
		}		

		if(alpha == "false")
		{
			var smax = "^[0-9]{"+min+","+max+"}$";
			var pattern=new RegExp(smax);
			if(!pattern.test(changeNumber))
			{
				fields[i++] = minMaxAlpha[x][1];
				masterValid = false;
				break;
			}		
		} else
		{
			var smax = "^[A-Za-z0-9]{"+min+","+max+"}$";
			var pattern=new RegExp(smax);
			if(!pattern.test(changeNumber))
			{
				fields[i++] = minMaxAlpha[x][1];
				masterValid = false;
				break;			
			}
		}
		
	}
			
	if(fields.length > 0) {
		alert(fields.join('\n'));
	}
				
				
	return masterValid;


}

function validateBillerListSize(form) {

    var bValid = true;
    var i = 0;

    var fields = new Array();                                                                           
    //validatorFieldArray = new billerListSizeValidator();
    var formName = form.getAttributeNode("name");
    validatorFieldArray = eval('new ' + formName.value + '_billerListSizeValidator()');

	// validate only if we are on the second page
	if(form.page.value != "2") {
		return true;
	}

    for (x in validatorFieldArray) {
		var validatedFieldName = validatorFieldArray[x][0];
		var validatedFieldValue = form[validatedFieldName].value;
		var message = validatorFieldArray[x][1];
		if("true" != validatedFieldValue) {
            fields[i++] = message;
            bValid = false;                                                                             
		}
	}
	
    if (fields.length > 0) {
        alert(fields.join('\n'));                                                                      
	}
	
	return bValid;
}

function validateAtLeastOne(form) {
	 
    var bValid = true;
	var focusField = null;

	var i = 0;                                                                                          
	var fields = new Array();
	//oMustCheckOne = new MustCheckOne(); 
	var formName = form.getAttributeNode("name");
    oMustCheckOne = eval('new ' + formName.value + '_MustCheckOne()');
	
	var flag=0;
	var unlinkedFlag;
	for (x in oMustCheckOne) { 
		for (j=0;j<form.unlinked.value;j++) {
			unlinkedFlag = "unlinkedAccounts["+j+"].addFlag";
			if (form.elements[unescape(unlinkedFlag)].checked=="1"){
				flag=1;
			}			
		}
		if(flag==0){
    	fields[i++] =oMustCheckOne[x][1];
    	bValid=false;
    }
	}                                                                                        
    

    if (fields.length > 0) {

       alert(fields.join('\n'));                                                                      
    }  
    return bValid;                                                                                      

}

function validateAllOthers(form) {
	 
    var bValid = true;
	var focusField = null;
	var i = 0;                                                                                          
	var fields = new Array();
	var pattern = new RegExp("^[A-Za-z0-9]{0,5}$");
	var slocale = form.linked.value;
		slocale = slocale.substr(slocale.indexOf("@")+1);
	var unlinkedAlias,unlinkedPosition,unlinkedFlag;
	for (j=0;j<form.unlinked.value;j++) {
		unlinkedAlias = "unlinkedAccounts["+j+"].alias";
		unlinkedPosition = "unlinkedAccounts["+j+"].position";
		unlinkedFlag = "unlinkedAccounts["+j+"].addFlag";		
		if (!pattern.test(form.elements[unescape(unlinkedAlias)].value)){
			if ("1"==slocale){
				fields[i++] ="Vous avez entr� un caract�re non valide dans le champ Nom.  Recommencez et n�entrez que des lettres de A � Z, des chiffres de 0 � 9 ou une combinaison des deux.";
			}else{
				fields[i++] ="You have entered an invalid character in the Name field. Please re-enter using the letters A-Z and/or the numbers 0-9.";
			}
			bValid =false;
		}	
		if ((form.elements[unescape(unlinkedAlias)].value.length>0)&&(form.elements[unescape(unlinkedFlag)].checked!="1")){
			if ("1"==slocale){
				fields[i++] ="Vous devez s�lectionner �Lier� pour inclure le nom du ou des comptes que vous souhaitez lier � votre carte Maxi-Carte.";
			}else{
				fields[i++] ="You must select \"Link\" to have the nickname included for the account(s) you have requested to link to your FirstBank Card.";
			}			
			bValid =false;
		}	
		if ((form.elements[unescape(unlinkedPosition)].value.length>0)&&(form.elements[unescape(unlinkedPosition)].value!="MasterCard / Line of Credit")&&(form.elements[unescape(unlinkedPosition)].value!="MasterCard / Marge-cr�dit")&&(form.elements[unescape(unlinkedFlag)].checked!="1")){
			if ("1"==slocale){
				fields[i++] ="Vous devez s�lectionner �Lier� pour d�finir la position du ou des comptes que vous souhaitez lier � votre carte Maxi-Carte.";
			}else{
				fields[i++] ="You must select \"Link\" to have the position set for the account(s) you have requested to link to your FirstBank Card.";
			}			
			bValid =false;
		}	
		if ((form.elements[unescape(unlinkedPosition)].value.length==0)&&(form.elements[unescape(unlinkedFlag)].checked=="1")){
			if ("1"==slocale){
				fields[i++] ="Vous devez s�lectionner la �position� pour lier le ou les compte � votre carte Maxi-Carte.";
			}else{
				fields[i++] ="You must select the \"Position\" for the account(s) to be linked to for your FirstBank Card.";
			}				
			bValid =false;
		}
		if ((form.elements[unescape(unlinkedAlias)].value.length!=0)&&((form.elements[unescape(unlinkedPosition)].value=="Chequing")||(form.elements[unescape(unlinkedPosition)].value=="Savings")||(form.elements[unescape(unlinkedPosition)].value=="Ch�ques")||(form.elements[unescape(unlinkedPosition)].value=="Ch�ques")||(form.elements[unescape(unlinkedPosition)].value=="�pargne"))){
			if ("1"==slocale){
				fields[i++] ="Vous ne pouvez donner un nom aux comptes occupant la position �ch�ques� ou ��pargne�.";
			}else{
				fields[i++] ="Accounts set up in the Chequing or Savings position can not have a Name associated with them.";
			}			
			bValid =false;
		}			
	}
	if (fields.length > 0) {
       alert(fields.join('\n'));                                                                      
    }  
    return bValid;                                                                                  

}
			 
function validateAvailableSlots(form) {
	 
    var bValid = true;
	var focusField = null;

	var i = 0;                                                                                          
	var fields = new Array();
	//oNoMoreThanTen = new NoMoreThanTen();
	var formName = form.getAttributeNode("name");
    oNoMoreThanTen = eval('new ' + formName.value + '_NoMoreThanTen()'); 
	
	var flag=0;
	var unlinkedPosition,unlinkedFlag;
	for (x in oNoMoreThanTen) { 
		for (j=0;j<form.unlinked.value;j++) {
			unlinkedPosition = "unlinkedAccounts["+j+"].position";
			unlinkedFlag = "unlinkedAccounts["+j+"].addFlag";
			if ( (form.elements[unescape(unlinkedFlag)].checked=="1")
			&&( (form.elements[unescape(unlinkedPosition)].value=="Other")||(form.elements[unescape(unlinkedPosition)].value=="Autre") ) ){
				flag++;
			}			
		}
		var linked=form.linked.value.substring(0,form.linked.value.indexOf(","));
		var total=eval(flag) + eval(linked);
		if(total>8){
    		fields[i++] =oNoMoreThanTen[x][1];
    		bValid=false;
    	}
	}                                                                                        
    

    if (fields.length > 0) {

       alert(fields.join('\n'));                                                                      
    }  
    return bValid;                                                                                     

}		

function validateNoMultipleAccounts(form) {
	 
    var bValid = true;
	var focusField = null;

	var i = 0;                                                                                          
	var fields = new Array();
	//oNoMulti = new NoMulti();
	var formName = form.getAttributeNode("name");
    oNoMulti = eval('new ' + formName.value + '_NoMulti()'); 
	
	var flag=0;
	var unlinkedPosition,unlinkedFlag;
	for (x in oNoMulti) { 
		var flagS=flagC=flagM=0;
		for (j=0;j<form.unlinked.value;j++) {
			unlinkedPosition = "unlinkedAccounts["+j+"].position";
			unlinkedFlag = "unlinkedAccounts["+j+"].addFlag";
			if ( (form.elements[unescape(unlinkedPosition)].value=="Chequing")||(form.elements[unescape(unlinkedPosition)].value=="Ch�ques")||(form.elements[unescape(unlinkedPosition)].value=="Ch�ques") ){
				flagC++;
			}	
			if ( (form.elements[unescape(unlinkedPosition)].value=="Savings")||(form.elements[unescape(unlinkedPosition)].value=="�pargne") ){
				flagS++;
			}
			if ((form.elements[unescape(unlinkedPosition)].value=="MC / Line of credit"||form.elements[unescape(unlinkedPosition)].value=="MC/MCP")&&(form.elements[unescape(unlinkedFlag)].checked=="1")){
				flagM++;
			}		
		}
		if((flagC>1)||(flagS>1)||(flagM>1)){
    		fields[i++] =oNoMulti[x][1];
    		bValid=false;
    	}
	}                                                                                        
    

    if (fields.length > 0) {

       alert(fields.join('\n'));                                                                      
    }  
    return bValid;                                                                                     

}		  



function validateBillerPayRequired(form) {

	var bValid = true;
	var billerPayReq = new billerPayRequired();  
    var i = 0;        
	var fields = new Array();
	
	for(x in billerPayReq)
	{
		var secondProperty = billerPayReq[x][2]("secondProperty");
		var thirdProperty = billerPayReq[x][2]("thirdProperty");

		var second = eval("form."+secondProperty+".value");
		var third = eval ("form."+thirdProperty+".value");
		var first = form[billerPayReq[x][0]].value;
				
		var text = '1First='+ first + ' | ' + 'Second=' + second + ' |' + 'Third=' + third;

    	if (second !='' || third !='')  {
			if (first == ''){
				var message = billerPayReq[x][1];		
				bValid = false;
				fields[i++]=message;		
			}
		}
	}
    if (fields.length > 0) {
        alert(fields.join('\n'));                                                                      
	}
	
	return bValid;
}			 


function validateBillerPay(form) {

	var bValid = true;
	var billerpay = new billerPay();  
    var i = 0;        
	var fields = new Array();


	for(x in billerpay)
	{
		var amount1Property = billerpay[x][2]("amount1");
		var amount2Property = billerpay[x][2]("amount2");
		var amount3Property = billerpay[x][2]("amount3");
		
		var payto1Property = billerpay[x][2]("payto1");
		var payto2Property = billerpay[x][2]("payto2");
		var payto3Property = billerpay[x][2]("payto3");	
	
		var accountfrom1Property = billerpay[x][2]("accountfrom1");
		var accountfrom2Property = billerpay[x][2]("accountfrom2");
		var accountfrom3Property = billerpay[x][2]("accountfrom3");	
	
		var amount1 = eval ("form."+amount1Property+".value");
		var amount2 = eval ("form."+amount2Property+".value");
		var amount3 = eval ("form."+amount3Property+".value");
		
		var payto1 = eval ("form."+payto1Property+".value");
		var payto2 = eval ("form."+payto2Property+".value");
		var payto3 = eval ("form."+payto3Property+".value");
		
		var accountfrom1 = eval ("form."+accountfrom1Property+".value");
		var accountfrom2 = eval ("form."+accountfrom2Property+".value");
		var accountfrom3 = eval ("form."+accountfrom3Property+".value");		
	
	
		if ((amount1 == '') &&
			(payto1 =='') &&
			(accountfrom1 =='') &&
			(amount2 =='') &&
			(payto2 =='') &&
			(accountfrom2 =='') &&
			(amount3 =='') &&
			(payto3 =='') &&
			(accountfrom3 =='')) {
					var message = billerpay[x][1];		
					bValid = false;
					fields[i++]=message;					
					
		}
	}
	
    if (fields.length > 0) {
        alert(fields.join('\n'));                                                                      
	}
	return bValid;
}		

function  validateOneOrMoreOfTwoGroups(form) {

 	var fields = new Array(); 
	var i = 0;                                                                                          

    oOneOrMore = new oneOrMoreOfTwoGroups();                                                                         

    for (x in oOneOrMore) {

		var excCounter = 0;
		
		//evaluate single element
		try {
			if (form[oOneOrMore[x][0]].type == 'checkbox' && form[oOneOrMore[x][0]].checked == true) { 
				return true; 
			}
		} catch (ex) {
			excCounter += 1;
		}

		try {
			for (j = 0; j < form[oOneOrMore[x][0]].length; j++) {
		
				if (form[oOneOrMore[x][0]][j].type == 'checkbox' && form[oOneOrMore[x][0]][j].checked == true) { 
					return true; 
				}
			}
		} catch (ex) {
			excCounter += 1;
		}

		var group2 = oOneOrMore[x][2]("group2");	

		try {
			if (form[group2].type == 'checkbox' && form[group2].checked == true) { 
				return true; 
			}
		} catch (ex) {
			excCounter += 1;
		}

		try {
			for (j = 0; j < form[group2].length; j++) {
		
				if (form[group2][j].type == 'checkbox' && form[group2][j].checked == true) { 
					return true; 
				}
			}
		} catch (ex) {
			excCounter += 1;
		}

		//No accounts to delete
		if (excCounter == 4) {
		
			fields[i] = oOneOrMore[x][1];
			alert(fields.join('\n'));
			
			return false;
		}

		fields[i] = oOneOrMore[x][1];
	}                                                                                                   

	if(fields.length > 0) {
		alert(fields.join('\n'));
	}

	return false;               
}

function  validateXOR(form) {

	var bValid = true;
    var focusField = null;

    var fields = new Array();                                                                           

    oXOR = new xor();                                                                         

    for (x in oXOR) {                                                                              

		var other = oXOR[x][2]("other");
		try {
	    	if ((form[oXOR[x][0]].type == form[other].type))  {
        
		   		if (form[oXOR[x][0]].value != '' && form[other].value != '') {
	   				bValid = false;
	   			} else {
	   				if (form[oXOR[x][0]].value == '' && form[other].value == '') {
		            	bValid = false;                                                                             	   			
		   			} else {
	   				    bValid = true;                                                                             	   			
	   				}
	   			}
	        
	        	if (bValid == false) {
            		focusField = form[oXOR[x][0]]; 
        	    	fields[0] = oXOR[x][1];
        	    	
        	    	break;
            	}
       		}
        } catch (ex) {
			alert ('Unsupported field type');
		}                                                                                               
	}                                                                                                   

    if (fields.length > 0) {
	    focusField.focus();
        alert(fields.join('\n'));   
	}                                                                                                   

	return  bValid;               
}


function  validateContingency(form) {

	var bValid = true;
    var focusField = null;

    var fields = new Array();                                                                           

    contingentList = new contingency();                                                                         

    // contingency() is constructed by Struts for us 
	// [0] is the field name in the form
	// [1] is the constructed error message
	// [2] is the function to be called

    for (x in contingentList) {                                                                              

		var contingentUpon = contingentList[x][2]("contingentUpon");
		try {
	   		if (form[contingentList[x][0]].value != '' && form[contingentUpon].value == '') {
		    	bValid = false;                                                                             	   			
		   	} else {
	   			bValid = true;                                                                             	   			
	   		}
	        
	        if (bValid == false) {
            	focusField = form[contingentUpon]; 
        	   	fields[0] = contingentList[x][1];    	
        	   	break;
            }
        } catch (ex) {
			alert ('Unsupported field type');
		}                                                                                               
	}                                                                                                   

    if (fields.length > 0) {
	    focusField.focus();
        alert(fields.join('\n'));   
	}                                                                                                   

	return  bValid;               
}



function  validateCondRequired(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oCondRequired = new condRequired();                                                                         
	
    for (x in oCondRequired) {   
        
        var condVariable = oCondRequired[x][2]("condVariable");
		var value = oCondRequired[x][2]("value");

   		if ((form[condVariable][0].checked == true && form[condVariable][0].value == value) ||
   		    (form[condVariable][1].checked == true && form[condVariable][1].value == value)) {
		 	if (form[oCondRequired[x][0]].value == '') {

	       	 	if (i == 0) {
            		focusField = form[oCondRequired[x][0]]; 
           		}
            
           	 	fields[i++] = oCondRequired[x][1];

            	bValid = false;                                                                             
        	}
   		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function  validateCondMask(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oCondMask = new condMask();                                                                         
	
    for (x in oCondMask) {   
        
        var condVariable = oCondMask[x][2]("condVariable");
		var value = oCondMask[x][2]("value");

   		if ((form[condVariable][0].checked == true && form[condVariable][0].value == value) ||
   		    (form[condVariable][1].checked == true && form[condVariable][1].value == value) &&
   		     form[oCondMask[x][0]].value.length > 0 ) {
		 	if (!matchPattern1(form[oCondMask[x][0]].value, oCondMask[x][2]("mask"))) {

	       	 	if (i == 0) {
            		focusField = form[oCondMask[x][0]]; 
           		}
            
           	 	fields[i++] = oCondMask[x][1];

            	bValid = false;                                                                             
        	}
   		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function matchPattern1(value, mask) {

   var bMatched = mask.exec(value);

   if(!bMatched) {                                                                                                                

      return false;                                                                                                               
   }                                                                                                                              

   return true;                                                                                                                   
}

function validateReqXDefault(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oReqXDefault = new reqXDefault();                                                                         

    for (x in oReqXDefault) {                                                                              

		var defaultVal = oReqXDefault[x][2]("defValue");
		
    	if ((form[oReqXDefault[x][0]].type == 'text' || 
    	     form[oReqXDefault[x][0]].type == 'textarea' || 
    	     form[oReqXDefault[x][0]].type == 'select-one' || 
    	     form[oReqXDefault[x][0]].type == 'password') && 
    	     form[oReqXDefault[x][0]].value == defaultVal) {

	        if (i == 0) {
            	focusField = form[oReqXDefault[x][0]]; 
            }
            fields[i++] = oReqXDefault[x][1];

            bValid = false;                                                                             
        }                                                                                               
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      
}

function validatePcntAmount(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oPcntAmount = new pcntAmount();                                                                         

    for (x in oPcntAmount) {                                                                              

		var defaultVal = oPcntAmount[x][2]("limit");
		
    	if ((form[oPcntAmount[x][0]].type == 'text' || 
    	     form[oPcntAmount[x][0]].type == 'textarea') && 
    	     (isNaN(form[oPcntAmount[x][0]].value) == true || 
    	      parseFloat(form[oPcntAmount[x][0]].value) > parseFloat(defaultVal)  ||
    	      parseFloat(form[oPcntAmount[x][0]].value) > 100.0 ||
    	      parseFloat(form[oPcntAmount[x][0]].value) <= 0.0)) {

	        if (i == 0) {
            	focusField = form[oPcntAmount[x][0]]; 
            }
            fields[i++] = oPcntAmount[x][1];

            bValid = false;                                                                             
        }                                                                                               
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      
}

function validateEither1(form)
{
	olbEither = new validateeither1();
	  
    var i = 0;                                                                                          
	var j = 0;
	
	var focusField = null;
	var fields1 = new Array();
	var fields2 = new Array();

	var masterValid = true;	
	var bValid1 = false;
	var	bValid2 = false;
		
	var doingEther1 = false;
	var doingEther2 = false;
	
	for(x in olbEither)
	{
		var either1 = olbEither[x][2]("either1");
		var either2 = olbEither[x][2]("either2");
		
		var checkeither = false;
		if(form[olbEither[x][0]].type == 'checkbox' || form[olbEither[x][0]].type == 'radio')
		{
			checkeither = form[olbEither[x][0]].checked;
		}

		if(form[olbEither[x][0]].type == 'textarea' || form[olbEither[x][0]].type == 'text')
		{
			if(form[olbEither[x][0]].value.length == 0)
			{
				checkeither = false;
			} else
			{
				checkeither = true;
			}
			
		}		

		if(either1 == "true" || either1 == "commit") 
		{
		
			doingEther1 = true;
			if(checkeither == true)
			{
				bValid1 = true;
				fields1 = new Array();
			} else 
			{
					if (bValid1 == false && fields1.length == 0) 
					{
						fields1[i++] = olbEither[x][1];
					}
			}
		}

		if(either2 == "true" || either2 == "commit") 
		{
		
			doingEther2 = true;
			if(checkeither == true)
			{
				bValid2 = true;
				fields2 = new Array();
			} else 
			{
					if (bValid2 == false && fields2.length == 0) 
					{
						fields2[j++] = olbEither[x][1];
					}
			}
		}

	}

	if(fields1.length > 0) {
        alert(fields1.join('\n'));                                                                      
		masterValid = false;
	}									

	if(fields2.length > 0) {
        alert(fields2.join('\n'));                                                                      
		masterValid = false;
	}									
				
																
	return masterValid;


}


function validateEither(form)
{
	olbEither = new validateeither();
	  
    var i = 0;                                                                                          
	var j = 0;
	
	var focusField = null;
	var fields1 = new Array();
	var fields2 = new Array();

	var masterValid = true;	
	var bValid1 = false;
	var	bValid2 = false;
		
	var doingEther1 = false;
	var doingEther2 = false;
	
	for(x in olbEither)
	{
		var either1 = olbEither[x][2]("either1");
		var either2 = olbEither[x][2]("either2");
		
		var checkeither = false;
		if(form[olbEither[x][0]].type == 'checkbox' || form[olbEither[x][0]].type == 'radio')
		{
			checkeither = form[olbEither[x][0]].checked;
		}

		if(form[olbEither[x][0]].type == 'textarea' || form[olbEither[x][0]].type == 'text')
		{
			if(form[olbEither[x][0]].value.length == 0)
			{
				checkeither = false;
			} else
			{
				checkeither = true;
			}
			
		}		

		if(either1 == "true" || either1 == "commit") 
		{
		
			doingEther1 = true;
			if(checkeither == true)
			{
				bValid1 = true;
				fields1 = new Array();
			} else 
			{
					if (bValid1 == false && fields1.length == 0) 
					{
						fields1[i++] = olbEither[x][1];
					}
			}
		}

		if(either2 == "true" || either2 == "commit") 
		{
		
			doingEther2 = true;
			if(checkeither == true)
			{
				bValid2 = true;
				fields2 = new Array();
			} else 
			{
					if (bValid2 == false && fields2.length == 0) 
					{
						fields2[j++] = olbEither[x][1];
					}
			}
		}

	}

	if(fields1.length > 0) {
        alert(fields1.join('\n'));                                                                      
		masterValid = false;
	}									

	if(fields2.length > 0) {
        alert(fields2.join('\n'));                                                                      
		masterValid = false;
	}									
				
																
	return masterValid;


}


function validateDaterequired(form) {
			
	var bValid = true;
	var focusField = null;

	var i = 0;                                                                                          
	var fields = new Array();                                                                           

	odtRqd = new dtRqd();                                                                         

	for (x in odtRqd) {                                                                                             
		if (form.unknownFlag.checked!="1"){
			if (focusField == null) {
				if ( form.year.value.length == 0){
					focusField = form.year;
				}	
				if ( form.day.value.length == 0){
					focusField = form.day;
				}	
				if ( form.month.value.length == 0){
					focusField = form.month;
				}
				if ( (form.month.value.length==0)&&(form.day.value.length==0) ){
					focusField = form[4];
			}
			}
			if ( (form.year.value.length == 0)||
				(form.day.value.length == 0)||
				(form.month.value.length == 0) ){								
				fields[i++] = odtRqd[x][1];
  				bValid = false;
			}
		}            
	} 

    if (fields.length > 0) {

       focusField.focus();

       alert(fields.join('\n'));                                                                      
    }                                                                                                                                                                                                        

    return bValid;                                                                                      
}

function validateDatevalid(form) {
			
	var bValid = true;
	var focusField = null;

	var i = 0;                                                                                          
	var fields = new Array();                                                                           

	odtVld = new dtVld();                                                                         


	for (x in odtVld) {                                                                                             
		if (form.unknownFlag.checked!="1"){
			checkday=eval(form.day.value);
			checkmonth=eval(form.month.value);
			checkyear=eval(form.year.value);
			bValid = isValidDate(checkday, checkmonth, checkyear);
			if(!bValid){
				focusField = form.day;				
				fields[i++] = odtVld[x][1];
  				bValid = false;
			}	
		}            
	} 

    if (fields.length > 0) {

       focusField.focus();

       alert(fields.join('\n'));                                                                      
    }                                                                                                                                                                                                        

    return bValid;                                                                                      
}

function validateBiggerthanfrom(form) {
			
	var bValid = true;
	var focusField = null;

	var i = 0;                                                                                          
	var fields = new Array();                                                                           

	o = new bgThnFrm();                                                                         
	from= eval(form.fromNumber.value);
	to= eval(form.toNumber.value);
	for (x in o) {                                                                                             
		if ((to-from)<=0) {
			if (focusField == null) {
				focusField = form.fromNumber;				
			}
			fields[i++] = o[x][1];
  			bValid = false;
		}            
	} 
    if (fields.length > 0) {

       focusField.focus();

       alert(fields.join('\n'));                                                                      
    }                                                                                                                                                                                                        

    return bValid;                                                                                      
}

function validateOptionalspecialrequestamount(form) {			
	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oAmount = new optAmnt();                                                                         

    for (x in oAmount) {     
    	if (form[oAmount[x][0]].value.length == 0){
    		return true;
    	}                                                                         
		if ((form[oAmount[x][0]].type == 'text' || form[oAmount[x][0]].type == 'textarea' || form[oAmount[x][0]].type == 'select-one' || form[oAmount[x][0]].type == 'radio') && form[oAmount[x][0]].value.length > 0) {   

			var iValue = form[oAmount[x][0]].value;

			//amount should be greater than zero
			if (iValue <= 0)  {
      			if (i == 0)
      				focusField = form[oAmount[x][0]];

	      		fields[i++] = oAmount[x][1];
      			bValid = false;
			} else {

				//TODO: include French mask
		   		var pattern=new RegExp("^[0-9]{1,8}(\\.[0-9]{0,2})?$");
					  					 
	  			if (!pattern.test(iValue) || eval(iValue)==0) {
	      					
	      			if (i == 0) {
	      				focusField = form[oAmount[x][0]];
	      			}
	      						
	      			fields[i++] = oAmount[x][1];
	      					
	      			bValid = false;
			   	}
			}
		}                                                                                               
	}                                                                                                   

    if (fields.length > 0) {

		focusField.focus();

		alert(fields.join('\n'));                                                                      
	}                                                                                                   

    return bValid;                                                                                      
                                                                            
}

function  validatePhone(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oPhone = new phone();                                                                         

    for (x in oPhone) {   
        
        var areaVariable = oPhone[x][2]("area");
    	var nxxVariable = oPhone[x][2]("nxx");
		var trunkVariable = oPhone[x][2]("trunk");

		var extensionVariable = oPhone[x][2]("extension");
		
		var ext = false;
		try {
			if (form[extensionVariable].value != '') {
				ext = true;
			}		
		} catch (ex) { }
		
		var phoneNumber = form[areaVariable].value + form[nxxVariable].value + form[trunkVariable].value;

		if ((phoneNumber.length > 0 && phoneNumber.length != 10) || ext == true) {
		
      	 	if (i == 0) {
           		if (form[areaVariable].value == '') {
           			focusField = form[areaVariable]; 
           		} else {
           			if (form[nxxVariable].value == '') {
           				focusField = form[nxxVariable]; 
           			} else {
           				if (form[trunkVariable].value == '') {
           					focusField = form[trunkVariable]; 
 						}          			
           			}
           		}
       		}
            
       	 	fields[i++] = oPhone[x][1];

          	bValid = false;                                                                             
		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function  validateCount(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oCount = new count();                                                                         

	for (x in oCount) {                                                                                                          
	    
	    var maxValue = parseInt(oCount[x][2]("max"),10);

		var formValue;
		try {
			formValue = parseInt(form[oCount[x][0]].value,10);
		} catch (ex) {
			formValue = 0;
		}
        
        if (formValue > maxValue) {

            if (i == 0) {
                focusField = form[oCount[x][0]]; 
		    }
              
            fields[i++] = oCount[x][1];

        	bValid = false;                                                                                                     
        }                                                                                                                      
    }                                                                                                                             

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}	 


function  validateOLBEmail(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oolbEmail = new olbEmailCheck();                                                                         

	for (x in oolbEmail) {                                                                                                          

        if ((form[oolbEmail[x][0]].type == 'text' || form[oolbEmail[x][0]].type == 'textarea') && form[oolbEmail[x][0]].value.length > 0) {   
  
  		   email = form[oolbEmail[x][0]].value;
 		   //if blank then send tru for non required uses of the email field
  		   if (email.length == 0) {
  		      bValid= true;
  		      return bValid;
  		   }
  		   
  		   if (email.search(/^\w+((-\w+)|(\.\w+)|(\'\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) != -1) {
    			bValid = true;
    			return bValid;
    	   } else {
              if (i == 0)
                 focusField = form[oolbEmail[x][0]]; 

              fields[i++] = oolbEmail[x][1];
              bValid = false;                                                                                                     
           }                                                                                                                      
        }                                                                                                                         
    }                                                                                                                             

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}	 

function validatePoBox(form) {
				
	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oStreetName = new poBox();                                                                         

    for (x in oStreetName) {                                                                              
	    if ((form[oStreetName[x][0]].type == 'text' || 
	         form[oStreetName[x][0]].type == 'textarea' || 
	         form[oStreetName[x][0]].type == 'select-one') && form[oStreetName[x][0]].value.length > 0) {   

	        var iValue = form[oStreetName[x][0]].value;

            var antipattern1 = new RegExp("[pP][oO][sS][tT]\\s.*[oO][fF][fF][iI][cC][eE]\\s.*[bB][oO][xX]");
            var antipattern2 = new RegExp("[pP]\\..*\\s.*[oO]\\..*\\s.*[bB][oO][xX]");
            var antipattern21 = new RegExp("[pP]\\.?[oO]\\.?\\s*[bB][oO][xX]\\s+[0-9]+");

		    var antipattern3 = new RegExp("[bB][oO][iI][tT][eE]\\s.*[pP][oO][sS][tT][aA][lL][eE]");
		    var antipattern31 = new RegExp("[bB][oO][iI][tT][eE]\\s?[pP][oO][sS][tT][aA][lL][eE]\\s+[0-9]+");
		
		    var antipattern4 = new RegExp("[pP]\\.?\\s?[oO]\\.?\\s[0-9]+");
		
		
  		 	if (antipattern1.test(iValue) || 
  		 	    antipattern2.test(iValue) || antipattern21.test(iValue) ||
  		 	    antipattern3.test(iValue) || antipattern31.test(iValue) ||
  		 	    antipattern4.test(iValue)) {
  					  
				if (i == 0) {
      				focusField = form[oStreetName[x][0]];
      			}
      						
      			fields[i++] = oStreetName[x][1];
      			bValid = false;
  					  
  			} 
        }                                                                                               
    }                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();

        alert(fields.join('\n'));                                                                      
    }                                                                                                   

    return bValid;                                                                                      
}

function  validateArea2Phone(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oPhone = new area2phone();                                                                         

    for (x in oPhone) {   
        
    	var nxxVariable = oPhone[x][2]("nxx");
		var trunkVariable = oPhone[x][2]("trunk");
		
		var phoneNumber = form[nxxVariable].value + form[trunkVariable].value;


		if (form[oPhone[x][0]].value != '' && phoneNumber.length == 0) {
		
      	 	if (i == 0) {
        		focusField = form[nxxVariable]; 
        	}

       	 	fields[i++] = oPhone[x][1];
          	bValid = false;                                                                             
		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function  validateArea2Nxx(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oPhone = new area2nxx();                                                                         

    for (x in oPhone) {   
        
    	var nxxVariable = oPhone[x][2]("nxx");

		if (form[oPhone[x][0]].value != '' && form[nxxVariable].value == '') {
		
      	 	if (i == 0) {
      			focusField = form[nxxVariable]; 
        	}
       	 	fields[i++] = oPhone[x][1];
          	bValid = false;                                                                             
		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function  validateArea2Trunk(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oPhone = new area2trunk();                                                                         

    for (x in oPhone) {   
        
    	var trunkVariable = oPhone[x][2]("trunk");

		if (form[oPhone[x][0]].value != '' && form[trunkVariable].value == '') {
		
      	 	if (i == 0) {
      			focusField = form[trunkVariable]; 
        	}
       	 	fields[i++] = oPhone[x][1];
          	bValid = false;                                                                             
		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function  validateNxx2Area(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oNxx = new nxx2area();                                                                         

    for (x in oNxx) {   
        
    	var areaVariable = oNxx[x][2]("area");

		if (form[oNxx[x][0]].value != '' && form[areaVariable].value == '') {
		
      	 	if (i == 0) {
        		focusField = form[areaVariable]; 
        	}
            
       	 	fields[i++] = oNxx[x][1];

          	bValid = false;                                                                             
		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function  validateTrunk2Area(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oTrunk = new trunk2area();                                                                         

    for (x in oTrunk) {   
        
    	var areaVariable = oTrunk[x][2]("area");

		if (form[oTrunk[x][0]].value != '' && form[areaVariable].value == '') {
		
      	 	if (i == 0) {
        		focusField = form[areaVariable]; 
        	}
            
       	 	fields[i++] = oTrunk[x][1];

          	bValid = false;                                                                             
		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function  validateExt2Area(form) {

	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    oExt = new ext2area();                                                                         

    for (x in oExt) {   
        
    	var areaVariable = oExt[x][2]("area");

		if (form[oExt[x][0]].value != '' && form[areaVariable].value == '') {
		
      	 	if (i == 0) {
        		focusField = form[areaVariable]; 
        	}
            
       	 	fields[i++] = oExt[x][1];

          	bValid = false;                                                                             
		}
	}                                                                                                   

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function validateAmountEmail(form) {
	return validateAmount(form);
}

function validateStreetName(form) {
	var bValid = true;
    var focusField = null;

    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    olbStreet = new olbStreetNameCheck();                                                                         

	for (x in olbStreet) {                                                                                                          

        if ((form[olbStreet[x][0]].type == 'text') && (form[olbStreet[x][0]].value.length > 0)) {   
  
  		   street = form[olbStreet[x][0]].value;

		   if (!isNaN(street)) {
              if (i == 0) {
                 focusField = form[olbStreet[x][0]]; 
			  }
			  
              fields[i++] = olbStreet[x][1];
              bValid = false;                                                                                                     
		   }
        }                                                                                                                         
    }                                                                                                                             

    if (fields.length > 0) {

	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return  bValid;               
}

function validateGenericInputEMT(form) {
	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           
    giEmt = new genericInputEMT();                                                                         
//	var pattern = new RegExp("^[0-9a-zA-Z\xC0-\xFF \x27\x2E\-]*$");
	var pattern = new RegExp("^[0-9a-zA-Z���������������������� \x27\x2E\-]*$");
    for (x in giEmt) {                                                                              
		var recipientName = form[giEmt[x][0]].value;
		if (!pattern.test(recipientName)) {
			fields[i++] = giEmt[x][1];
			if (focusField == null) {
				focusField = form[giEmt[x][0]];
			}
			bValid = false;
		}
	}                                                                                                   
    if (fields.length > 0) {
	    focusField.focus();
        alert(fields.join('\n'));                                                                      
	}                                                                                                   
	return bValid;                                                                                      
}

function validateAliasRequiredIfAdd(form) {
	 
    var bValid = true;
	var focusField = null;
	
	var i = 0;                                                                                          
	var fields = new Array();
	oIfAliasRequired = new IfAliasRequired(); 
	
	var flag=0;
	var unlinkedPosition,unlinkedFlag,unlinkedAlias;
	for (x in oIfAliasRequired) { 
		var flagS=flagC=flagM=0;
		for (j=0;j<form.unlinked.value;j++) {
			unlinkedPosition = "unlinkedAccounts["+j+"].position";
			unlinkedFlag = "unlinkedAccounts["+j+"].addFlag";
			unlinkedAlias= "unlinkedAccounts["+j+"].alias";
			if ( ((form.elements[unescape(unlinkedPosition)].value=="Chequing")||(form.elements[unescape(unlinkedPosition)].value=="Ch�ques")||(form.elements[unescape(unlinkedPosition)].value=="Ch�ques"))&&(form.elements[unescape(unlinkedFlag)].checked=="1") ){
				flagC=1;
			}	
			if ( ((form.elements[unescape(unlinkedPosition)].value=="Savings")||(form.elements[unescape(unlinkedPosition)].value=="�pargne"))&&(form.elements[unescape(unlinkedFlag)].checked=="1") ){
				flagS=1;
			}
			if ((form.elements[unescape(unlinkedPosition)].value=="MasterCard / Line of Credit"||form.elements[unescape(unlinkedPosition)].value=="MasterCard / Marge-cr�dit")&&(form.elements[unescape(unlinkedFlag)].checked=="1")){
				flagM=1;
			}	
			if(!((flagC==1)||(flagS==1)||(flagM==1))){
    			if ((form.elements[unescape(unlinkedAlias)].value=="" || form.elements[unescape(unlinkedAlias)].length == 0)&&(form.elements[unescape(unlinkedFlag)].checked=="1")){
    				fields[i++] =oIfAliasRequired[x][1];
    				bValid=false;
    				break;
    			}
    		}else{
    			flagC=0;
    			flagS=0;
    			flagM=0;
    		}
    	}	
		
	} 
	if (fields.length > 0) {
        alert(fields.join('\n'));                                                                      
	}                                                                                                   
	return bValid;   
	            
}
/*
function aoRequiredRadioButton(form) {                                                                       


	var bValid = true;
    var focusField = null;
    var i = 0;                                                                                          
    var fields = new Array();                                                                           

    //oRadio = new aoRequiredRadioButtonCheck();  
                                                             
    var formName = form.getAttributeNode("name");
    oRadio = eval('new ' + formName.value + '_aoRequiredRadioButtonCheck()');                                                                         
	
    for (x in oRadio) {
		if ((!form[oRadio[x][0]][0].checked) && (!form[oRadio[x][0]][1].checked)) {
			if (focusField == null) {
				focusField = form[oRadio[x][0]];
            }
			fields[i++] = oRadio[x][1];
			bValid = false;                                                                             
	    }
	}                                                                                                   

    if (fields.length > 0) {
        alert(fields.join('\n'));                                                                      
	}                                                                                                   

	return bValid;                                                                                      

}
*/


	function validateAllRequired(form) {
		var masterValid = true;
		var data = eval('new ' + jcv_retrieveFormName(form) + '_allRequired()');
		var fields = new Array();
		var j = 0;
		var notSetFocus = true;
		for (x in data) {
			var valid = true;
			var num = data[x][2]('numberOfProperty');
			var count = parseInt(num);
			var props = new Array();
			for(var i=1; i<=count; i++) {
				var pname = 'property' + i;
				if (!isFieldPresent(form[data[x][2](pname)])) {
					continue;
				} else {
					var checkValue = eval("form."+data[x][2](pname)+".value");
					if (trim(checkValue).length <= 0) {
					//if(checkValue == ''){
						valid = false;
						if (notSetFocus) {
							eval("form."+data[x][2](pname)+".focus()");
							notSetFocus = false;
						}
					}
				}
			}
			if (!valid) {
				fields[j++] = data[x][1];
				masterValid = false;
			}
		}
		if(fields.length > 0) {
			alert(fields.join('\n'));
		}
		return masterValid;
	}

	function validateAllMask(form) {
		var masterValid = true;
		var data = eval('new ' + jcv_retrieveFormName(form) + '_allMask()');
		var fields = new Array();
		var j = 0;
		var notSetFocus = true;
		for (x in data) {
			var valid = true;
			var num = data[x][2]('numberOfProperty');
			var count = parseInt(num);
			var props = new Array();
			for(var i=1; i<=count; i++) {
				var pname = 'property' + i;
				var mname = 'mask' + i;
				if (!isFieldPresent(form[data[x][2](pname)])) {
					continue;
				} else {
					var checkValue = eval("form."+data[x][2](pname)+".value");
					var re = new RegExp(data[x][2](mname));
					if (!re.test(checkValue)) {
						valid = false;
						if (notSetFocus) {
							eval("form."+data[x][2](pname)+".focus()");
							notSetFocus = false;
						}
					}
				}
			}
			if (!valid) {
				fields[j++] = data[x][1];
				masterValid = false;
			}
		}
		if(fields.length > 0) {
			alert(fields.join('\n'));
		}
		return masterValid;
	}
	
	function isFieldPresent(field) {
		var fieldPresent = true;
		if (field == null || field == undefined) {
			fieldPresent = false;
		} else {
			if (field.disabled) {
				fieldPresent = false;
			}
		}
		return fieldPresent;
	}


  function jcv_retrieveFormName(form) {
      // Please refer to Bugs 31534, 35127, 35294, 37315 & 38159
      // for the history of the following code

      var formName;

      if (form.getAttributeNode) {
          if (form.getAttributeNode("id") && form.getAttributeNode("id").value) {
              formName = form.getAttributeNode("id").value;
          } else {
              formName = form.getAttributeNode("name").value;
          }
      } else if (form.getAttribute) {
          if (form.getAttribute("id")) {
              formName = form.getAttribute("id");
          } else {
              formName = form.attributes["name"];
          }
      } else {
          if (form.id) {
              formName = form.id;
          } else {
              formName = form.name;
          }
      }

      return formName;

  } 
  
  	function trim(s) {

        return s.replace( /^\s*/, "" ).replace( /\s*$/, "" );

    }

