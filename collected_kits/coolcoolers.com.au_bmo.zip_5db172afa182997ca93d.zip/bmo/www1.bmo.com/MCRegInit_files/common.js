var path="/mc/mcreg";

function set(form, target) {
	var actionSplit=form.action.split("/");
	form.action = path + "/" + actionSplit[actionSplit.length-1];
	if (target) {
		if (target.indexOf("/")==0)
			form.action = target;
		else {
			if (form.mode)
	   			form.mode.value=target;
		     			
			if (form.action.indexOf("?mode")== -1) {
				form.action = form.action + "?mode=" + target;
			} else {
				form.action = form.action.substring(0,form.action.indexOf("?mode"))+"?mode="+target;
			}
		}		
	}
	return true;	
}

function ssoIps() {
	return ssoJumpFormAction('IPS');
}

function ssoJump() {
	var selectedValue= document.ssoJumpForm.ssoJumpList[document.ssoJumpForm.ssoJumpList.selectedIndex].value;
	if (typeof selectedValue != 'undefined' && selectedValue != '') {
		var selectedValueArray = selectedValue.split('#');
		var acctType= selectedValueArray[0];
		var acctIndex= parseInt(selectedValueArray[1], 10);
		if (isNaN(acctIndex)) {
			acctIndex= "";
		}
		ssoJumpFormAction(acctType, acctIndex);
	}
	return false;
}

function ssoUpdateFormAction(acctType, acctIndex) {
	// open within the same target window by default
	document.ssoJumpForm.target= "";
	document.ssoJumpForm.ssoJumpAccount.value= acctIndex;
	document.ssoJumpForm.ssoJumpType.value= acctType;
	set(document.ssoJumpForm, '/OLB/fin/sum/null/ssoAm?mode=form3');
	document.ssoJumpForm.submit();
	return false;
}

function ssoJumpFormAction(acctType, acctIndex) {
	// rename the window to make sure that CFM always opens as a popup
	window.name="main";
	// open within the same target window by default
	document.ssoJumpForm.target= "";
	document.ssoJumpForm.ssoJumpAccount.value= acctIndex;
	document.ssoJumpForm.ssoJumpType.value= acctType;
	if (acctType == il || acctType == nb || acctType == mc) {
		var popupText = "PLEASE NOTE THE FOLLOWING:";
		popupText+= "\n\nYou are being automatically transferred to the ";
		if (acctType == il) {
			popupText+= "BMO InvestorLine";
		} else if (acctType == nb) {
			popupText+= "BMO Nesbitt Burns";
		} else if (acctType == mc) {
			popupText+= "MasterCard";
		}
		popupText+= " site.  You will not be required to enter your Username and password.";
		popupText+= "\n\nYou can return to Online Banking simply by choosing \"Online Banking\" from the drop-down menu at the top right of any page.";
		popupText+= "\n\nFor your security, you will now be signed out of Online Banking. A new banking session will be started when you return to Online Banking. Please note that when you return to Online Banking, your last Sign in date and time will be updated.";
		popupText+= "\n\nThis transfer may take a few moments.  Please do not click the \"Back\" button on your browser until you are using the other site or you will be signed out of all applications (this is a security feature).";
		// ask user to confirm and if the answer is "OK" - submit
		if (confirm(popupText)) {
			if (acctType == mc) {
				set(document.ssoJumpForm, '/OLBmain/ssoMc');
			} else {
				set(document.ssoJumpForm, '/OLBmain/ssoAm');
			}
			document.ssoJumpForm.submit();
		}
	} else if (acctType == 'CFM' || acctType == 'IPS' || acctType == 'IL' || 
				acctType == 'NB' || acctType == 'MMC' || acctType == 'OMC') {
		// default forward (new window)
		defaultWindowHandler = window.open('',"window_" + acctType,'width=640,height=480,top=50,left=150,toolbar=yes,scrollbars=yes,resizable=yes,location=yes,menubar=yes,directories=no,status=yes,copyhistory=no');
		document.ssoJumpForm.target= "window_" + acctType;
		set(document.ssoJumpForm, '/OLBmain/ssoDefault');
		document.ssoJumpForm.submit();
	} else {
		// CFM will popup in a new window
		keep = null;
		document.ssoJumpForm.target= "cfmWindow";
		set(document.ssoJumpForm, '/OLBmain/ssoCfm');
		top.cfmWindowHandler = window.open('','cfmWindow','width=640,height=480,top=50,left=150,toolbar=yes,scrollbars=yes,resizable=yes,location=yes,menubar=yes,directories=no,status=yes,copyhistory=no');
		document.ssoJumpForm.submit();
		top.cfmWindowHandler.focus();
	}
	return false;
}

function closePopups() {
	if (top.cfmWindowHandler) {
		top.cfmWindowHandler.close();
	}
	if (top.cfmWindow) {
		top.cfmWindow.close();
	}
	return true;
}

/* Pop up window for all external links */

function Popup(myUrl,popType) {
	var winName='olb_popup';
	var winTop=50;
	var winLeft=150;
	var d = new Date();
	var winTime = d.getUTCHours()+'_'+d.getUTCMinutes()+'_'+d.getUTCSeconds();

	switch (popType) {
		case 1:   // tools & info/help section - max size pop up, full too bar, resizable, scrollbars
/*
			if (top.winName) {
				top.winName.close();
			}
*/
		  	popup = window.open(myUrl,winName+winTime,'width=640,height=480,top=' + winTop + ',left=' + winLeft + ',toolbar=yes,scrollbars=yes,resizable=yes,location=yes,menubar=yes,directories=no,status=yes,copyhistory=no');
		break
		case 2:  // olb tool/message  - max pop up size, no tool bar, not resizable, scrolling if necessary
		  popup = window.open(myUrl,winName+winTime,'width=640,height=480,top=' + winTop + ',left=' + winLeft + ',toolbar=no,scrollbars=yes,resizable=no,location=no,menubar=no,directories=no,status=no,copyhistory=no');
		break
		case 3:  // olb tool/message  - smaller pop up size, no tool bar, not resizable, scrolling if necessary
		  popup = window.open(myUrl,winName+winTime,'width=480,height=360,top=' + winTop + ',left=' + winLeft + ',toolbar=no,scrollbars=no,resizable=no,location=no,menubar=no,directories=no,status=no,copyhistory=no');
		break
		case 4:  // calendars  - smallest pop up size, no tool bar, not resizable, scrolling if necessary
		  popup = window.open(myUrl,winName+winTime,'width=360,height=360,top=' + winTop + ',left=' + winLeft + ',toolbar=no,scrollbars=yes,resizable=no,location=no,menubar=no,directories=no,status=no,copyhistory=no');
		break
		case 5:  // popups within popups  - smallest pop up size, no tool bar, not resizable, scrolling if necessary
			winTop=100;
			winLeft=200;
	  	popup = window.open(myUrl,winName+winTime,'width=640,height=480,top=' + winTop + ',left=' + winLeft + ',toolbar=yes,scrollbars=yes,resizable=yes,location=yes,menubar=yes,directories=no,status=no,copyhistory=no');
		break
		case 6:  // printer friendly pages
		  popup = window.open(myUrl,winName+winTime,'width=600,height=480,top=' + winTop + ',left=' + winLeft + ',toolbar=no,scrollbars=yes,resizable=yes,location=no,menubar=no,directories=no,status=no,copyhistory=no');
		break
// these are NOT in the style guide
//		case 7:  // olb tool/message  - max pop up size, no tool bar, not resizable, scrolling if necessary
//		  popup = window.open(myUrl,winName+winTime,'width=800,height=450,top=' + winTop + ',left=' + winLeft + ',toolbar=no,scrollbars=yes,resizable=no,location=no,menubar=no,directories=no,status=no,copyhistory=no');
//		break
//		case 8:  // Sign In pages's forgotton password.
//		  popup = window.open(myUrl,winName+winTime,'width=480,height=360,top=' + winTop + ',left=' + winLeft + ',toolbar=no,scrollbars=no,resizable=no,location=no,menubar=no,directories=no,status=no,copyhistory=no');
//		break
		case 9:  // EMT Tour Only (Not Part of Style Guide)
		  popup = window.open(myUrl,winName+winTime,'width=800,height=600,top=' + winTop + ',left=' + winLeft + ',toolbar=no,scrollbars=yes,resizable=yes,location=no,menubar=no,directories=no,status=no,copyhistory=no');
		break
		case 10:  // Contact Us / Locate Us Popup (Not Part of Style Guide)
		  popup = window.open(myUrl,winName+winTime,'width=645,height=550,top=-25,left=125,toolbar=no,scrollbars=1,resizable=1,location=no,menubar=no,directories=no,status=no,copyhistory=no');
		break
		case 11:  // Popup (Not Part of Style Guide)
		  popup = window.open(myUrl,winName+winTime,'width=720,height=550,top=-25,left=125,toolbar=no,scrollbars=1,resizable=1,location=no,menubar=no,directories=no,status=no,copyhistory=no');
		break
		case 12:  // For CAO 
		  popup = window.open(myUrl,winName+winTime,'width=650,height=550,top=100,left=100,toolbar=no,scrollbars=1,resizable=1,location=no,menubar=no,directories=no,status=yes,copyhistory=no');
		break
		}

	popup.focus();

}

//*******************************************************************************
// * Function Name: openStaticPopUp
// * 
// * Parameters:
// *   URL		URL to display in the popup
// *   windowName	windowName as per the javascript window.open definition
// *			(the window name can be anything for the purposes of this
// *			 function)
// *
// * Description:
// *   Opens a pop up browser window with the URL that is passed in. This function
// *   is sensitive to the size of the screen and resizes and repositions the 
// *   popup accordingly
// ******************************************************************************/
function openStaticPopUp(URL,windowName)
{
// If the screen resolution in 800x600 then 
	if(screen.availWidth==800)
	{
		top.viewWin = window.open(URL, windowName, "width=680,height=490,top=20,left=60,scrollbars=1,toolbar=0,resizable=1,menubar=0,location=0,status=0,fullscreen=0,directories=0,channelmode=0");
	}
	else
	{
		top.viewWin = window.open(URL, windowName, "width=680,height=490,top=70,left=200,scrollbars=1,toolbar=0,resizable=1,menubar=0,location=0,status=0,fullscreen=0,directories=0,channelmode=0");
	}
}

function openB2CWindow(URL) {
	window.open(URL,"B2C_PARENT","width=640,height=480,top=50,left=150,toolbar=yes,scrollbars=yes,resizable=yes,location=yes,menubar=yes,directories=no,status=yes,copyhistory=no");
}


function selectAll(formname,checkType) {
	var idx, theCheckbox;
	idx = 0;
	theCheckbox = eval("document." + formname + "." + checkType + idx);
	while (typeof(theCheckbox) == "object")
	{
		theCheckbox.checked = true
		idx++;
		theCheckbox = eval("document." + formname + "." + checkType + idx);
	}

}

function selectAll_1(formname,checkType) {
	var idx, theCheckbox;
	idx = 0;
	theCheckbox = eval("document." + formname + "." + checkType);
	while (typeof(theCheckbox) == "object")
	{
		try {
			theCheckbox[idx].checked = true;
		
			idx++;
			theCheckbox = eval("document." + formname + "." + checkType);
		} catch (ex){
			//one element only
			theCheckbox.checked = true;

			return;
		}
	}

}

function clearAll(formname,checkType) {
	var idx, theCheckbox;
	idx = 0;
	theCheckbox = eval("document." + formname + "." + checkType + idx);
	while (typeof(theCheckbox) == "object")
	{
		theCheckbox.checked = false
		idx++;
		theCheckbox = eval("document." + formname + "." + checkType + idx);
	}
}

function clearAll_1(formname,checkType) {
	var idx, theCheckbox;
	idx = 0;
	theCheckbox = eval("document." + formname + "." + checkType);
	while (typeof(theCheckbox) == "object")
	{
		try {
			theCheckbox[idx].checked = false;
			idx++;
			theCheckbox = eval("document." + formname + "." + checkType);
		} catch (ex){
			//one element only
			theCheckbox.checked = false;

			return;
		}
	}
}

function changeAll(formname,checkType,ifChecked) {
	var idx, theCheckbox;

	if (eval(ifChecked)) {
		idx = 0;
		theCheckbox = eval("document." + formname + "." + checkType + idx);
		while (typeof(theCheckbox) == "object")
		{
			theCheckbox.checked = true
			idx++;
			theCheckbox = eval("document." + formname + "." + checkType + idx);
		}		
	} else {
		idx = 0;
		theCheckbox = eval("document." + formname + "." + checkType + idx);
		while (typeof(theCheckbox) == "object")
		{
			theCheckbox.checked = false
			idx++;
			theCheckbox = eval("document." + formname + "." + checkType + idx);
		}
	}
}

//sets the number of 'checked' checkboxes in the 'counter' field of 'formname'
function processCheckboxes(formname,checkType,counter) {
		
	var idx = 0;
	var count = 0;
	var theCheckbox = eval("document." + formname + "." + checkType);

	var counter = eval("document." + formname + "." + counter);
	
	while (typeof(theCheckbox) == "object")	{

		try {			
			if (theCheckbox[idx].checked == true) {
				counter.value = ++count; 
			}
		} catch (ex) {
			//there is only one checkbox on the form
			if (theCheckbox.checked == true) {
				counter.value = ++count; 
			}
				
			return;
		}

		idx++;
		theCheckbox = eval("document." + formname + "." + checkType);
	}

   	return ;	
}

function resetMe() {
	document.form1.reset();
}

function goHere(loc) {
	this.location.href=loc;
}


function filter (imagename, objectsrc) {
	if (document.images) {
	document.images[imagename].src=eval(objectsrc+".src")
	}
}

function clearOnSubmitHandler(form) {
	form.onsubmit = null;
}

function getDetails(paymentID,FIrefid,CustPayeeId,formName) {

   formName.pmtRefId.value = paymentID;
   formName.fIRefId.value  = FIrefid;
   formName.custPayeeId.value = CustPayeeId;
   
   formName.submit();   
}

function cancelPayment(name,id,email,CustPayeeId, FIrefid,amount,formName) {

        
        formName.recipientName.value = name;
        formName.pmtRefId.value = id;
        formName.emailAddress.value = email;
        formName.custPayeeId.value = CustPayeeId;
        formName.fIRefId.value  = FIrefid;
 		formName.amount.value  = amount;
        formName.submit();   
}

function isPresent(the_value,list)
{
	    var token_array = list.split('&');
        var i;

        if(document.EmtSendForm.list)
        {
        	if(document.EmtSendForm.list.value=="###")
        	{
                for(i=0;i<token_array.length;i++)
                {
       					if(token_array[i].toUpperCase() == the_value.toUpperCase())
                        {
                                return true;
                        }
                }
                return false;
                }
        	else
        	{
        		return false;
        	}
        }
        else
        {
                return false;
        }
}
  
     function validateMCRegFormStep3(form) { 
        if (bCancel) { 
            return true; 
        } else { 
            var formValidationResult; 
            formValidationResult = validateRequired(form) && validateMask(form) && validateAllRequired(form) && validateAllMask(form) && validateMinLength(form) && validateMaxLength(form) && isPassordMatch(form.password.value, form.reenter_password.value);; 
            return (formValidationResult); 
        } 
    }
  
	
	function isPassordMatch(letter, letter1){
	
			for(x=0;x<letter.length;x++)
				{
				if (letter1.charAt(x) != letter.charAt(x))
					{
					document.MCRegForm.reenter_password.focus();
					alert("The passwords entered do not match. Please check your entry.");
					document.MCRegForm.reenter_password.focus();
					return false;
					}
				}
			return true;
	}
	
	
  	function validateMCRegForm1(form) { 
        if (bCancel) { 
            return true; 
        } else { 
            var formValidationResult; 
            formValidationResult = validateRequired(form) && validateMask(form) && validateAllRequired(form) && validateAllMask(form) && validateMinLength(form) && validateMaxLength(form) && Mod10(form.card_number.value); 
            return (formValidationResult); 
        } 
    } 
	

	function Mod10(CreditCardNumber) { 
	var len = CreditCardNumber.length;  
	var iCreditCardNumber = parseInt(CreditCardNumber);  
	var sum = 0;  
	var result = false;  
	var calc;  

	  if(len >= 15){  
	    for(var i=len;i>0;i--){  
	      calc = parseInt(iCreditCardNumber) % 10;  
	      calc = parseInt(calc);  
	      sum += calc;  
	      i--;  
	      iCreditCardNumber = iCreditCardNumber / 10;                              
	      calc = parseInt(iCreditCardNumber) % 10 ;   
	      calc = calc *2;                             

	      switch(calc){
	        case 10: calc = 1; break;       
	        case 12: calc = 3; break;       
	        case 14: calc = 5; break;       
	        case 16: calc = 7; break;       
	        case 18: calc = 9; break;       
	        default: calc = calc;           
	      }                                               
	    iCreditCardNumber = iCreditCardNumber / 10;  
	    sum += calc;  
	  }  
	  if ((sum%10)==0){ 
	    result = true;  
	  } else {
	    result = false;  
	  }
	}
	if(!result){
	  document.MCRegForm.card_number.focus();
	  alert("The MasterCard number entered is invalid.  Please verify the number and re-enter.");
      document.MCRegForm.card_number.focus();
	}
	  return result; 
	}
	
	
