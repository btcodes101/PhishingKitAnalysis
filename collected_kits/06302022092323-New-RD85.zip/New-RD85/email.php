<?php 
$Receive_email="leopard3454@gmail.com";
$redirect="https://www.google.com/";
?>