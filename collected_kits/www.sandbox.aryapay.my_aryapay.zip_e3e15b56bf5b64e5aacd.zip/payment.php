<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>AryaPay - Your trusted payment gateway</title>
	<meta name="description" content="Secure Online Payment">
	<meta name="author" content="AryaPay">
	<meta content="width=device-width, initial-scale=1 user-scalable=yes" name="viewport" />

	<link rel="shortcut icon" type="image/png" href="images/favicon.png"/>
	<link rel="stylesheet" href="http://aryapay.estoneweb.com/pay/css/style.css" media="all" type="text/css" />
	<link rel="stylesheet" href="http://aryapay.estoneweb.com/pay/css/bootstrap.css" media="all" type="text/css" />
	
	<style id="antiClickjack">/*body{display:none;}*/</style>
	<script type="text/javascript">
		// if (self === top) {
			// var antiClickjack = document.getElementById("antiClickjack");
			// antiClickjack.parentNode.removeChild(antiClickjack);
		// } else {
			// top.location = self.location;
		// }
	</script>
	<script src="https://code.jquery.com/jquery-3.5.0.js"></script>
</head>
<body>
	<?php
		$returnurl = $_POST['returnurl'];
		
		$fpx_buyerBankBranch = $_POST['fpx_buyerBankBranch'];
		$fpx_buyerBankId = $_POST['fpx_buyerBankId'];
		$fpx_buyerIban = $_POST['fpx_buyerIban'];
		$fpx_buyerId = $_POST['fpx_buyerId'];
		$fpx_buyerName = $_POST['fpx_buyerName'];
		$fpx_creditAuthCode = $_POST['fpx_creditAuthCode'];
		$fpx_creditAuthNo = $_POST['fpx_creditAuthNo'];
		$fpx_debitAuthCode = $_POST['fpx_debitAuthCode'];
		$fpx_debitAuthNo = $_POST['fpx_debitAuthNo'];
		$fpx_fpxTxnId = $_POST['fpx_fpxTxnId'];
		$fpx_fpxTxnTime = $_POST['fpx_fpxTxnTime'];
		$fpx_makerName = $_POST['fpx_makerName'];
		$fpx_msgToken = $_POST['fpx_msgToken'];
		$fpx_msgType = $_POST['fpx_msgType'];
		$fpx_sellerExId = $_POST['fpx_sellerExId'];
		$fpx_sellerExOrderNo = $_POST['fpx_sellerExOrderNo'];
		$fpx_sellerId = $_POST['fpx_sellerId'];
		$fpx_sellerOrderNo = $_POST['fpx_sellerOrderNo'];
		$fpx_sellerTxnTime = $_POST['fpx_sellerTxnTime'];
		$fpx_txnAmount = $_POST['fpx_txnAmount'];
		$fpx_txnCurrency = $_POST['fpx_txnCurrency'];
		$fpx_checkSum = $_POST['fpx_checkSum'];

		$data = $fpx_buyerBankBranch."|".$fpx_buyerBankId."|".$fpx_buyerIban."|".$fpx_buyerId."|".$fpx_buyerName."|".$fpx_creditAuthCode."|".$fpx_creditAuthNo."|".$fpx_debitAuthCode."|".$fpx_debitAuthNo."|".$fpx_fpxTxnId."|".$fpx_fpxTxnTime."|".$fpx_makerName."|".$fpx_msgToken."|".$fpx_msgType."|".$fpx_sellerExId."|".$fpx_sellerExOrderNo."|".$fpx_sellerId."|".$fpx_sellerOrderNo."|".$fpx_sellerTxnTime."|".$fpx_txnAmount."|".$fpx_txnCurrency;

		// $val = verifySign_fpx($fpx_checkSum, $data);
	?>
	
	<header>
		<div class="container">
			<div id="fpxlogodiv"><img src="/images/fpx_full_logo.png" id="fpxlogo"></div>
			<div id="aryapaylogodiv"><img src="/images/aryapay_logo.png" id="aryapaylogo"></div>
		</div>
	</header> 
	<div id="main-container">
		<div class="clear"></div>
		<div class="bold" style="font-size: 20px; margin: 20px 0;">Pay with <img src='/images/fpx_standard_logo.png' id='mp_logo' width="100" height="auto"> (Current and Savings Account)</div>
		<?php
			if ($fpx_debitAuthCode == '00') {
				echo '<div class="payment_success bold">Payment Successful</div>';
			} elseif ($fpx_debitAuthCode == '99') {
				echo '<div class="payment_pending bold">Pending for Authorizer to approve</div>';
			} elseif ($fpx_debitAuthCode != '00' || $fpx_debitAuthCode != '' || $fpx_debitAuthCode != '99') {
				echo '<div class="payment_failed bold">Payment Unsuccessful</div>';
			}
		?>
		<table id="transaction-details">
			<tr>
				<td>Date</td>
				<td><?php echo $fpx_fpxTxnTime; ?></td>
			</tr>
			<tr>
				<td>Amount</td>
				<td class="bold"><?php echo $fpx_txnCurrency . ' ' . $fpx_txnAmount; ?></td>
			</tr>
			<tr>
				<td>Reference No</td>
				<td><?php echo $fpx_sellerOrderNo; ?></td>
			</tr>
			<tr>
				<td>FPX Transaction ID</td>
				<td><?php echo $fpx_fpxTxnId; ?></td>
			</tr>
			<!--
			<tr>
				<td>fpx_makerName</td>
				<td><?php echo $fpx_makerName; ?></td>
			</tr>
			-->
		</table>
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 submit">
			<form action="http://aryademo.estoneweb.com/?wc-api=WC_Aryapay_Gateway" method="POST">
				<input type=hidden name='skey' value='9c351bbb27ff1826412d08e8d0bb51b6'>
				<input type=hidden name='tranID' value='519918251'>
				<input type=hidden name='domain' value='estoneweb'>
				<input type=hidden name='status' value='00'>
				<input type=hidden name='amount' value='<?php echo $fpx_txnAmount; ?>'>
				<input type=hidden name='currency' value='<?php echo $fpx_txnCurrency; ?>'>
				<input type=hidden name='paydate' value='<?php echo $fpx_fpxTxnTime; ?>'>
				<input type=hidden name='orderid' value='<?php echo $fpx_sellerOrderNo; ?>'>
				<input type=hidden name='appcode' value=''>
				<input type=hidden name='error_code' value=''>
				<input type=hidden name='error_desc' value=''>
				<input type=hidden name='channel' value='FPX_MB2U'>
				<input type=hidden name='extraP' value='{"fpx_txn_id":"2102201121440130"}'>
				
				<button type="submit" class="normal">Back to merchant site</button>
			</form>
		<div>
	</div>
	<footer>
		<span class="bottom">
			<div id="footer_container">
				<div id="powered">
					Powered By <img src='/images/fpx_standard_logo.png' id='mp_logo' width="100" height="auto">
				</div>
			</div>
		</span>
	</footer>
	
<body>