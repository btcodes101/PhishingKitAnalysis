<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href='index.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/all.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/all.min.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/brands.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/brands.min.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/fontawesome.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/fontawesome.min.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/regular.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/regular.min.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/solid.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/solid.min.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/svg-with-js.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/svg-with-js.min.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/v4-shims.css' type='text/css' media='all' />
	<link rel="stylesheet" href='css/v4-shims.min.css' type='text/css' media='all' />
	
	<link rel="shortcut icon" type="image/png" href="images/favicon.png"/>
	<title>AryaPay Merchant Portal</title>
</head>

<body>
	<div class="login-box">
		<div class="logo">AryaPay</div>
		<div class="merchant-portal">Merchant Portal</div>
		<div class="login-box-body">
			<form method="POST" action="#" class="login-form">
				<div class="login-field">
					<input type="text" placeholder="Email" id="login-email" name="login-email" required>
				</div>
				<div class="login-field">
					<input type="password" placeholder="Password" id="login-password" name="login-passowrd" required>
				</div>
				<div class="login-field">
					<input type="submit" class="login-button" value="Login">
				</div>
			</form>
			<a href="#" class="float-right forgot-password">Forgot password?</a>
		</div>
	</div>
</body>
</html>