<!DOCTYPE html>
<head>
	<link rel="shortcut icon" type="image/png" href="images/favicon.png"/>
	<link rel="stylesheet" href="http://aryapay.estoneweb.com/pay/css/style.css" media="all" type="text/css" />
	<link rel="stylesheet" href="http://aryapay.estoneweb.com/pay/css/bootstrap.css" media="all" type="text/css" />
	<meta content="width=device-width, initial-scale=1 user-scalable=yes" name="viewport" />
</head>
<body>
	<div id="main" class="both center" style="margin-top: 100px; font-size: 50px;">Redirect to FPX now </div>
	<div id="main-container">
		<?php
			$fpx_buyerAccNo = $_POST['fpx_buyerAccNo'];
			$fpx_buyerBankBranch = $_POST['fpx_buyerBankBranch'];
			$fpx_buyerBankId = $_POST['fpx_buyerBankId'];
			$fpx_buyerIban = $_POST['fpx_buyerIban'];
			$fpx_buyerId = $_POST['fpx_buyerId'];
			$fpx_buyerName = $_POST['fpx_buyerName'];
			$fpx_buyerEmail = $_POST['fpx_buyerEmail'];
			$fpx_checkSum = $_POST['fpx_checkSum'];
			$fpx_makerName = $_POST['fpx_makerName'];
			$fpx_msgToken = $_POST['fpx_msgToken'];
			$fpx_msgType = $_POST['fpx_msgType'];
			$fpx_productDesc = $_POST['fpx_productDesc'];
			$fpx_sellerBankCode = $_POST['fpx_sellerBankCode'];
			$fpx_sellerExId = $_POST['fpx_sellerExId'];
			$fpx_sellerExOrderNo = $_POST['fpx_sellerExOrderNo'];
			$fpx_sellerId = $_POST['fpx_sellerId'];
			$fpx_sellerOrderNo = $_POST['fpx_sellerOrderNo'];
			$fpx_sellerTxnTime = $_POST['fpx_sellerTxnTime'];
			$fpx_txnAmount = $_POST['fpx_txnAmount'];
			$fpx_txnCurrency = $_POST['fpx_txnCurrency'];
			$fpx_version = $_POST['fpx_version'];
			$returnurl = $_POST['returnurl'];
			
			$fpx_creditAuthCode = '';
			$fpx_creditAuthNo = '';
			$fpx_debitAuthCode = '00'; // 00=success, 99=pending for authorizer to approve
			$fpx_debitAuthNo = '';
			$fpx_fpxTxnId = '';
			date_default_timezone_set("Asia/Kuala_Lumpur");
			$fpx_fpxTxnTime = date("Y-m-d h:m:s a");
		?>
		<div class="submit">
			<form action="payment.php" method="POST" id="form">
				<input type=hidden value="<?php print $fpx_buyerBankBranch; ?>" name="fpx_buyerBankBranch">
				<input type=hidden value="<?php print $fpx_buyerBankId; ?>" name="fpx_buyerBankId">
				<input type=hidden value="<?php print $fpx_buyerIban; ?>" name="fpx_buyerIban">
				<input type=hidden value="<?php print $fpx_buyerId; ?>" name="fpx_buyerId">
				<input type=hidden value="<?php print $fpx_buyerName; ?>" name="fpx_buyerName">
				<input type=hidden value="<?php print $fpx_creditAuthCode; ?>" name="fpx_creditAuthCode">
				<input type=hidden value="<?php print $fpx_creditAuthNo; ?>" name="fpx_creditAuthNo">
				<input type=hidden value="<?php print $fpx_debitAuthCode; ?>" name="fpx_debitAuthCode">
				<input type=hidden value="<?php print $fpx_debitAuthNo; ?>" name="fpx_debitAuthNo">
				<input type=hidden value="<?php print $fpx_fpxTxnId; ?>" name="fpx_fpxTxnId">
				<input type=hidden value="<?php print $fpx_fpxTxnTime; ?>" name="fpx_fpxTxnTime">
				<input type=hidden value="<?php print $fpx_makerName; ?>" name="fpx_makerName">
				<input type=hidden value="<?php print $fpx_msgToken; ?>" name="fpx_msgToken">
				<input type=hidden value="<?php print $fpx_msgType; ?>" name="fpx_msgType">
				<input type=hidden value="<?php print $fpx_sellerExId; ?>" name="fpx_sellerExId">
				<input type=hidden value="<?php print $fpx_sellerExOrderNo; ?>" name="fpx_sellerExOrderNo">
				<input type=hidden value="<?php print $fpx_sellerId; ?>" name="fpx_sellerId">
				<input type=hidden value="<?php print $fpx_sellerOrderNo; ?>" name="fpx_sellerOrderNo">
				<input type=hidden value="<?php print $fpx_sellerTxnTime; ?>" name="fpx_sellerTxnTime">
				<input type=hidden value="<?php print $fpx_txnAmount; ?>" name="fpx_txnAmount">
				<input type=hidden value="<?php print $fpx_txnCurrency; ?>" name="fpx_txnCurrency">
				<input type=hidden value="<?php print $fpx_checkSum; ?>" name="fpx_checkSum">
				<input type=hidden value="<?php print $returnurl; ?>" name="returnurl">
				
				<!--
				<input type=hidden value="<?php print $fpx_sellerBankCode; ?>" name="fpx_sellerBankCode">
				<input type=hidden value="<?php print $fpx_buyerEmail; ?>" name="fpx_buyerEmail">
				<input type=hidden value="<?php print $fpx_buyerAccNo; ?>" name="fpx_buyerAccNo">
				<input type=hidden value="<?php print $fpx_version; ?>" name="fpx_version">
				<input type=hidden value="<?php print $fpx_productDesc; ?>" name="fpx_productDesc">
				-->
				
				<button type="submit" class="normal" style="margin-top: 30px;">Continue</button>
			</form>
		</div>
	</div>
</body>
</html>