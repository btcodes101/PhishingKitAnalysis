<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>AryaPay - Your trusted payment gateway</title>
	<meta name="description" content="Secure Online Payment">
	<meta name="author" content="AryaPay">
	<meta content="width=device-width, initial-scale=1 user-scalable=yes" name="viewport" />

	<!--<link rel="stylesheet" href="http://localhost/aryapay/pay/css/style.css" media="all" type="text/css" />-->
	<!--<link rel="stylesheet" href="http://localhost/aryapay/pay/css/bootstrap.css" media="all" type="text/css" />-->
	
	<link rel="shortcut icon" type="image/png" href="http://aryapay.estoneweb.com/images/favicon.png"/>
	<link rel="stylesheet" href="http://aryapay.estoneweb.com/pay/css/style.css" media="all" type="text/css" />
	<link rel="stylesheet" href="http://aryapay.estoneweb.com/pay/css/bootstrap.css" media="all" type="text/css" />
	
	<style id="antiClickjack">/*body{display:none;}*/</style>
	<script type="text/javascript">
		// if (self === top) {
			// var antiClickjack = document.getElementById("antiClickjack");
			// antiClickjack.parentNode.removeChild(antiClickjack);
		// } else {
			// top.location = self.location;
		// }
	</script>
	<script src="https://code.jquery.com/jquery-3.5.0.js"></script>
	
	<?php
		function php_console_log($msg) {
			echo '<script>';
			echo 'console.log("' . $msg . '")';
			echo '</script>';
		}
	?>
	
	<script>
		// $('#businessmodel').change(function(){
			// console.log('asd');
		// });
	</script>
</head>
<body>
	<?php
		// Get real time bank list
		
		/*
		function hextobin($hexstr) {
			$n = strlen($hexstr); 
			$sbin="";   
			$i=0; 
			while($i<$n) {       
				$a = substr($hexstr, $i, 2);           
				$c = pack("H*", $a); 
				if ($i == 0){ $sbin = $c; } 
				else { $sbin .= $c; } 
				$i+=2; 
			} 
			return $sbin; 
		}

		function validateCertificate($path,$sign, $toSign) {
			global  $ErrorCode;

			$d_ate = date("Y");
			// validating Last Three Certificates 
			$fpxcert = array($path . "fpxuat_current.cer", $path . "fpxuat.cer");
			$certs = checkCertExpiry($fpxcert);
			// echo count($certs) ;
			$signdata = hextobin($sign);

			if(count($certs) == 1) {
				$pkeyid = openssl_pkey_get_public($certs[0]);
				$ret = openssl_verify($toSign, $signdata, $pkeyid);	
				if($ret != 1) {
					$ErrorCode =" Your Data cannot be verified against the Signature. "." ErrorCode :[09]";
					return "09";	  
				}
			} elseif(count($certs) == 2) {
				$pkeyid = openssl_pkey_get_public($certs[0]);
				$ret = openssl_verify($toSign, $signdata, $pkeyid);	
				if($ret!=1) {
					$pkeyid = openssl_pkey_get_public($certs[1]);
					$ret = openssl_verify($toSign, $signdata, $pkeyid);	
					if($ret!=1) {
						$ErrorCode = " Your Data cannot be verified against the Signature. "." ErrorCode :[09]";
						return "09";	  
					}
				}
			}
			if($ret==1) {
				$ErrorCode = " Your signature has been verified successfully. "." ErrorCode :[00]";
				return "00";	  
			}

			return $ErrorCode;
		}
		
		function verifySign_fpx($sign, $toSign) {
			error_reporting(0);
			return validateCertificate('C:\\DevExchange\\', $sign, $toSign);
		}
		
		$fpx_msgToken = "01";
		$fpx_msgType = "BE";
		$fpx_sellerExId = "EX00003846";
		$fpx_version = "6.0";
		$data = $fpx_msgToken . "|" . $fpx_msgType . "|" . $fpx_sellerExId . "|" . $fpx_version;

		$priv_key = file_get_contents('key/EX00003846.key');
		$priv_key = trim(preg_replace('/\r\n|\n\r|\r|\n/', '\n', $priv_key));
		php_console_log($priv_key);
		$pkeyid = openssl_pkey_get_private($priv_key);
		php_console_log('0' . $pkeyid);
		
		openssl_sign($data, $binary_signature, $pkeyid, OPENSSL_ALGO_SHA1);
		php_console_log('1' . $binary_signature);
		$fpx_checkSum = strtoupper(bin2hex( $binary_signature ) );
		
		php_console_log('2' . $fpx_checkSum);

		// extract data from the post

		extract($_POST);
		$fields_string = "";

		// set POST variables
		$url = 'https://uat.mepsfpx.com.my/FPXMain/RetrieveBankList';

		$fields = array(
			'fpx_msgToken' => urlencode($fpx_msgToken),
			'fpx_msgType' => urlencode($fpx_msgType),
			'fpx_sellerExId' => urlencode($fpx_sellerExId),
			'fpx_checkSum' => urlencode($fpx_checkSum),
			'fpx_version' => urlencode($fpx_version)
		);
		$response_value = array();
		$bank_list = array();

		try {
			// url-ify the data for the POST
			foreach($fields as $key=>$value) { $fields_string .= $key . '=' . $value . '&'; }
			rtrim($fields_string, '&');

			// open connection
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

			// set the url, number of POST vars, POST data
			curl_setopt($ch,CURLOPT_URL, $url);

			curl_setopt($ch,CURLOPT_POST, count($fields));
			curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

			// receive server response ...
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// execute post
			$result = curl_exec($ch);

			// close connection
			curl_close($ch);

			$token = strtok($result, "&");
			while ($token !== false) {
				list($key1,$value1) = explode("=", $token);
				$value1 = urldecode($value1);
				$response_value[$key1] = $value1;
				$token = strtok("&");
			}

			$fpx_msgToken = reset($response_value);

			// Response Checksum Calculation String
			$data = $response_value['fpx_bankList'] . "|" . $response_value['fpx_msgToken'] . "|" . $response_value['fpx_msgType'] . "|" . $response_value['fpx_sellerExId'];
			$val = verifySign_fpx($response_value['fpx_checkSum'], $data);

			// val == 00 verification success

			$token = strtok($response_value['fpx_bankList'], ",");
			while ($token !== false) {
				list($key1,$value1) = explode("~", $token);
				$value1 = urldecode($value1);
				$bank_list[$key1] = $value1;
				$token = strtok(",");
			}
		} catch(Exception $e) {
			echo 'Error :', ($e->getMessage());
		}*/
	?>

	<header>
		<div class="container">
			<div id="fpxlogodiv"><img src="/images/fpx_full_logo.png" id="fpxlogo"></div>
			<div id="aryapaylogodiv"><img src="/images/aryapay_logo.png" id="aryapaylogo"></div>
		</div>
	</header> 
	<div id="main-container">
	<?php
		/*foreach($bank_list as $key=>$value) {
		?>
			<div><?php echo $key.'='.$value; ?></div>
		<?php 
		}*/
	?>
	<!-- <div id="main" role="main"> -->
		<div id="message-box"></div>
		<div class="clear"></div>
		<div id="form-wrapper">
			<div class="bold" style="font-size: 20px; margin: 20px 0;">Pay with <img src='/images/fpx_standard_logo.png' id='mp_logo' width="100" height="auto"> (Current and Savings Account)</div>
			<!--<form action="/aryapay/payment.php" method="post">-->
			<form action="/fpx.php" method="post">
				<!--
				MOLPAY
				<input type=hidden id="merchantID" name="merchantID" value="<?php echo $_POST["merchant_id"]; ?>">
				<input type=hidden id="vcode" name="vcode" value="<?php echo $_POST["vcode"]; ?>">
				<input type=hidden id="linkKey" name="linkKey" value="">
				<input type=hidden id="payment_gateway" name="payment_gateway" value="FPX_PBB">
				<input type=hidden id="httpref" name="httpref" value="https://www.onlinepayment.com.my/MOLPay/pay/gocare/MB2U.php:::202.188.47.159, 162.158.166.249">
				<input type=hidden id="fshttpref" name="fshttpref" value="https://gocare.org.my/:::202.188.47.159, 162.158.166.250">
				<input type=hidden id="hash_fshttpref" name="hash_fshttpref" value="f73b6a72d6baa44a75f2073c3ef082e6">
				<input type=hidden id="returnurl" name="returnurl" value="https://gocare.org.my/?wc-api=WC_Molpay_Gateway">
				<input type=hidden id="callbackurl" name="callbackurl" value="">
				<input type=hidden id="notifyurl" name="notifyurl" value="">
				<input type=hidden id="extra" name="extra" value="">
				<input type=hidden id="currency" name="currency" value=myr>
				<input type=hidden id="l_version" name="l_version" value="1">
				<input type=hidden id="langcode" name="langcode" value="en">
				<input type=hidden id="rm_amount" name="rm_amount" value="">
				<input type=hidden id="def_amt" name="def_amt" value="<?php echo $_POST["amount"]; ?>">
				<input type=hidden id="def_cur" name="def_cur" value="MYR">
				<input type=hidden id="vc_currency" name="vc_currency" value="MYR">
				<input type=hidden id="vc_channel" name="vc_channel" value="PBB">
				<input type=hidden id="is_escrow" name="is_escrow" value="0">
				-->
				
				<?php
					$fpx_msgType="AR";
					$fpx_msgToken="01";
					$fpx_sellerExId="EX00003846";
					$fpx_sellerExOrderNo=date('YmdHis');
					$fpx_sellerTxnTime=date('YmdHis');
					$fpx_sellerOrderNo=$_POST['orderid'];
					$fpx_sellerId="SE00004293";
					$fpx_sellerBankCode="01";
					$fpx_txnCurrency="MYR";
					$fpx_txnAmount=$_POST['amount'];
					$fpx_buyerEmail=$_POST['bill_email'];
					$fpx_checkSum="";
					$fpx_buyerName=$_POST['bill_name'];
					$fpx_buyerBankId="TEST0021";
					$fpx_buyerBankBranch="";
					$fpx_buyerAccNo="";
					$fpx_buyerId="";
					$fpx_makerName="";
					$fpx_buyerIban="";
					$fpx_productDesc=$_POST['bill_desc'];
					$fpx_version="6.0";
					$returnurl = $_POST['returnurl'];
					
				?>
				
				<fieldset>
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 capital bold" style="font-size: 20px; margin: 0 0 20px;">Payment Summary</div>
					<div class="field">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">Amount (MYR)</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"><?php echo $_POST["amount"]; ?></div>
					</div>
					<div class="field">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">Order ID</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"><?php echo $_POST["orderid"]; ?></div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 capital bold" style="font-size: 20px; margin: 20px 0;">Contact Information</div>
					<div class="field">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">Name</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"><input id="cardholder" name="cardholder" type="text" value="<?php echo $_POST["bill_name"]; ?>" AUTOCOMPLETE=ON required class="cln" min="5" /></div>
					</div>
					<div class="field">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">Email</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"><input id="email" name="email" placeholder="demo@email.com.my" type="email" value="<?php echo $_POST["bill_email"]; ?>" AUTOCOMPLETE=ON required class="cln" min="5" /></div>
					</div>
					<div class="field">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">Contact Number</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
							<input id="mobile" name="mobile" placeholder="e.g. +60181122334" type="tel" value="<?php echo $_POST["bill_mobile"]; ?>" AUTOCOMPLETE=ON required class="cln" min="5" />
						</div>
					</div>
					<div class="field">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">Business Model</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
							<select id="businessmodel" name="businessmodel" tabindex=10 required>
								<option value="" hidden>Select a Business Model</option>
								<option value="B2C">Retail Banking (B2C)</option>
								<option value="B2B">Corporate Banking (B2B)</option>
							</select>
						</div>
					</div>
					<div class="field">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">Select Bank</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
							<select id="fpxbanklist" name="fpxbanklist" tabindex=10 required>
								<option value="" hidden>Select Bank</option>
								<option value="AMBB0209">AmBank</option>
								<option value="HLB0224">Hong Leong Bank</option>
								<option value="MB2U0227">Maybank2U</option>
								<option value="OCBC0229" disabled>OCBC Bank (offline)</option>
								<option value="PBB0233">Public Bank</option>
								<option value="RHB0218">RHB Bank</option>
							</select>
						</div>
					</div>
					<div class="field">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">Description</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"><textarea id="desc" name="desc" rows="5" required class="cln" min="5" title="Description for your payment. E.g. product details, shipping information, remarks, etc."><?php echo $_POST["bill_desc"]; ?></textarea></div>
					</div>
					<div class="field declaration">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"><input id="terms" name="terms" type="hidden" value="1" checked="checked" /></div>
						<div style="text-align:center;" class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							By clicking the "Proceed" button, you hereby agree with <a href='https://www.mepsfpx.com.my/FPXMain/termsAndConditions.jsp' target='_blank'>FPX's Terms & Conditions</a>.
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 field submit">
						<input type=hidden value="<?php print $fpx_msgType; ?>" name="fpx_msgType">
						<input type=hidden value="<?php print $fpx_msgToken; ?>" name="fpx_msgToken">
						<input type=hidden value="<?php print $fpx_sellerExId; ?>" name="fpx_sellerExId">
						<input type=hidden value="<?php print $fpx_sellerExOrderNo; ?>" name="fpx_sellerExOrderNo">
						<input type=hidden value="<?php print $fpx_sellerTxnTime; ?>" name="fpx_sellerTxnTime">
						<input type=hidden value="<?php print $fpx_sellerOrderNo; ?>" name="fpx_sellerOrderNo">
						<input type=hidden value="<?php print $fpx_sellerId; ?>" name="fpx_sellerId">
						<input type=hidden value="<?php print $fpx_sellerBankCode; ?>" name="fpx_sellerBankCode">
						<input type=hidden value="<?php print $fpx_txnCurrency; ?>" name="fpx_txnCurrency">
						<input type=hidden value="<?php print $fpx_txnAmount; ?>" name="fpx_txnAmount">
						<input type=hidden value="<?php print $fpx_buyerEmail; ?>" name="fpx_buyerEmail">
						<input type=hidden value="<?php print $fpx_checkSum; ?>" name="fpx_checkSum">
						<input type=hidden value="<?php print $fpx_buyerName; ?>" name="fpx_buyerName">
						<input type=hidden value="<?php print $fpx_buyerBankId; ?>" name="fpx_buyerBankId">
						<input type=hidden value="<?php print $fpx_buyerBankBranch; ?>" name="fpx_buyerBankBranch">
						<input type=hidden value="<?php print $fpx_buyerAccNo; ?>" name="fpx_buyerAccNo">
						<input type=hidden value="<?php print $fpx_buyerId; ?>" name="fpx_buyerId">
						<input type=hidden value="<?php print $fpx_makerName; ?>" name="fpx_makerName">
						<input type=hidden value="<?php print $fpx_buyerIban; ?>" name="fpx_buyerIban">
						<input type=hidden value="<?php print $fpx_version; ?>" name="fpx_version">
						<input type=hidden value="<?php print $fpx_productDesc; ?>" name="fpx_productDesc">
						<input type=hidden value="<?php print $returnurl; ?>" name="returnurl">

						<button id="pay" type="submit" class="normal">Proceed</button>
					</div>
				</fieldset>
			</form>
				
		</div>
		<section id="info"></section>
		<section id="help"></section>
	</div>
	<footer>
		<span class="bottom">
			<div id="footer_container">
				<div id="powered">
					Powered By: <img src='/images/fpx_standard_logo.png' id='mp_logo' width="100" height="auto">
				</div>
				<!--
				<div id="join_us">
					<a href="https://www.facebook.com/" target="_blank" alt="https://www.facebook.com/" title="https://www.facebook.com/">
						<img src="/images/facebook.png" border=0 width="25" height="25">
					</a>
					<a href="https://www.instagram.com/" target="_blank" alt="https://www.instagram.com/" title="https://www.instagram.com/">
						<img src="/images/instagram.png" border=0 width="25" height="25">
					</a>
				</div>
				-->
			</div>
		</span>
	</footer>
</body>
</html>
