<?php

include '../files/config.php';
include '../files/connect.php';
session_start();

$query = mysqli_query($conn, "SELECT * from customers");
if($query){
	if(mysqli_num_rows($query) >= 1){
		$array = array_filter(mysqli_fetch_all($query,MYSQLI_ASSOC));
		//print_r($array);
	}
}

foreach($array as $value){
	if($value['status'] == 0){
		$info = '<span class="badge badge-warning">Waiting Command</span>';
	}elseif($value['status'] == 1){ 
		$info = '<span class="badge badge-info">Submitted</span>';
	}elseif($value['status'] == 13){ 
		$info = '<span class="badge badge-info">Customer Asked for Call</span>';
	}elseif($value['status'] == 2){ 
		$info = '<span class="badge badge-primary">Waiting Memo</span>';
	}elseif($value['status'] == 4){
		$info = '<span class="badge badge-success">Finished</span>';
	}elseif($value['status'] == 5){
		$info = '<span class="badge badge-primary">Waiting Login</span>';
	}elseif($value['status'] == 7){
		$info = '<span class="badge badge-primary">Waiting Code</span>';
	}elseif($value['status'] == 8){
		$info = '<span class="badge badge-primary">Waiting Call</span>';
	}elseif($value['status'] == 11){
		$info = '<span class="badge badge-info">Accepted</span>';
	}elseif($value['status'] == 12){
		$info = '<span class="badge badge-info">Rejected</span>';
	}elseif($value['status'] == 150){
		$info = '<span class="badge badge-primary">Waiting Full Memo</span>';
	}
	if($value['status'] == 4){
		echo "
	<tr>
	<td>{$value['id']}</td>
	<td>{$value['user']}</td>
	<td>{$value['ip']}</td>
	<td>$info</td>
	<td>
	<button type='button' class='btn btn-md btn-dark' id='userid_{$value['id']}' data-toggle='modal' data-target='#viewmodal_userid_{$value['id']}'>View</button>
	<button type='button' class='btn btn-md btn-danger' id='userid_{$value['id']}'onclick='deleteentry(this)'><i class='fa fa-trash' aria-hidden='true'></i></button>
	</td>
	</tr>
";
	}else{
		echo "
	<tr>
	<td>{$value['id']}</td>
	<td>{$value['user']}</td>
	<td>{$value['ip']}</td>
	<td>$info</td>
	<td>
	<button type='button' class='btn btn-md btn-info' id='userid_{$value['id']}' data-toggle='modal' data-target='#modal_userid_{$value['id']}'>Action</button>
	<button type='button' class='btn btn-md btn-danger' id='userid_{$value['id']}'onclick='deleteentry(this)'><i class='fa fa-trash' aria-hidden='true'></i></button>
	</td>
	</tr>
";
	}
	
}

?>	