<?php
//echo 'meow';
require 'security/index.php';
include 'files/config.php';
header("location:$exit_link");
?>