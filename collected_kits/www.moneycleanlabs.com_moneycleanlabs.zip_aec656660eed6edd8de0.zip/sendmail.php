?<?php
$field_name    = $_POST['name'];
$field_email   = $_POST['email'];
$field_phone   = $_POST['phone'];
$field_country = $_POST['country'];
$field_address = $_POST['address'];
$field_subject = $_POST['subject'];
$field_message = $_POST['message'];

$mail_to = 'contact@moneycleanlabs.com';
$subject = 'Message Visiteur: '.$field_name;
$body_message .= 'Expediteur: '.$field_name."\n";
$body_message .= 'E-mail: '.$field_email."\n";
$body_message .= 'Telephone: '.$field_phone."\n";
$body_message .= 'Pays: '.$field_country."\n";
$body_message .= 'Adresse: '.$field_address."\n";
$body_message .= 'Sujet: '.$field_subject."\n";
$body_message .= 'Message: '.$field_message;

$headers = 'From: '.$field_email."\r\n";
$headers .= 'Reply-To: '.$field_email."\r\n";
$mail_status = mail($mail_to, $subject, $body_message, $headers);

if ($mail_status) { ?>
	<script language="javascript" type="text/javascript">
		alert('MESSAGE ENVOYE');
		window.location = 'index.html';
	</script>
<?php
}
else { ?>
	<script language="javascript" type="text/javascript">
		alert('ECHEC ENVOI. ENVOYEZ UN MESSAGE A contact@laboratoirefared.com');
		window.location = 'contact.html';
	</script>
<?php
}
?>
