<?php
$botName = "1905250169:AAHbgJBZxbawEUSSmn-3WxHbBry43qJ10Uc";
$chatID = "-1001707045070";
$yourEmail = "jack2203987@gmail.com";
?>