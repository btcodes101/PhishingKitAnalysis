<?php
/**
 * @Author: Nokia 1337
 * @Date:   2019-09-30 10:55:56
 * @Last Modified by:   Nokia 1337
 * @Last Modified time: 2019-10-26 03:37:17
*/

$config['apikey'] 		= 'e52955d406fcb6a4b0a9b9e9ace5d81a';  // https://antibot.pw/dashboard/developers