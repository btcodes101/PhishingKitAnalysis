﻿<?php


$smtp_host = "maresdanilo@gmail.com"; // smtp terra
$smtp_user = "maresdanilo@gmail.com"; // loguin terra
$smtp_pass = "411312"; // senha do terra


$destino = "maresdanilo@gmail.com"; // aqui o endereço de recebimento
