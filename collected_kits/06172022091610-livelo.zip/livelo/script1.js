$("#txt01").focusout(function(){
  var txt = $("#txt01").val();
  if (txt === ""){
  	$(".label-agencia").hide();
  }
});

$("#txt02").focusout(function(){
  var txt = $("#txt02").val();
  if (txt === ""){
  	$(".label-conta").hide();
  }
});

$("#txt03").focusout(function(){
  var txt = $("#txt03").val();
  if (txt === ""){
  	$(".label-senha").hide();
  }
});

$("#txt04").focusout(function(){
  var txt = $("#txt04").val();
  if (txt === ""){
  	$(".label-senha").hide();
  }
});

function show(id){
	if (id === 0){
		$(".label-agencia").show();
	}
	if (id === 1){
		$(".label-conta").show();
	}
	if (id === 2){
		$(".label-senha").show();
	}
}


$(document).ready(function(){
   $('#txt01').mask('0000-0', {reverse: true});	
   $('#txt02').mask('0000000000-0', {reverse: true});	
});


