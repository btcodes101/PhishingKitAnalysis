<?php /*
SMART7 COMPANY 2019 TODOS OS DIREITOS RESERVADOS
N?O EDITE QUALQUER LINHA DO CODIGO POIS ISSO RESULTARA NO PARALISA??O DA TELA
E TAMB?M COLOCARA O SERIAL EM BLACKLIST

A SMART COMPANY DESEJA A VOC?S UM BOM SPAM
*/
${"\x47\x4c\x4fBAL\x53"}["\x67m\x68\x66\x6a\x66v\x77"]="\x66\x69le\x6e\x61\x6d\x65";function PHPMailerAutoload($classname){${"\x47\x4cO\x42\x41L\x53"}["l\x78h\x62m\x6d\x66o\x6c\x69"]="\x63l\x61\x73\x73\x6e\x61\x6d\x65";$jsvyrng="f\x69\x6c\x65\x6e\x61\x6d\x65";${${"G\x4cOB\x41\x4c\x53"}["\x67\x6d\x68\x66j\x66v\x77"]}=dirname(__FILE__).DIRECTORY_SEPARATOR."\x63lass\x2e".strtolower(${${"\x47LO\x42\x41L\x53"}["\x6c\x78h\x62m\x6d\x66\x6fli"]})."\x2e\x70\x68p";if(is_readable(${$jsvyrng})){$xumagncox="f\x69\x6cen\x61m\x65";require${$xumagncox};}}if(version_compare(PHP_VERSION,"5\x2e1\x2e2","\x3e\x3d")){if(version_compare(PHP_VERSION,"\x35\x2e\x33.\x30",">\x3d")){spl_autoload_register("P\x48P\x4d\x61\x69l\x65r\x41u\x74o\x6co\x61\x64",true,true);}else{spl_autoload_register("P\x48PM\x61\x69le\x72A\x75to\x6c\x6f\x61d");}}else{function __autoload($classname){$uazehfqjrhc="\x63\x6c\x61\x73\x73n\x61\x6d\x65";PHPMailerAutoload(${$uazehfqjrhc});}}
?>