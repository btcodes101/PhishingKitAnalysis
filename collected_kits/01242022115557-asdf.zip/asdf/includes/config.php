<?php
	
	// ================================= //
	 
	 $show_captcha ="no"; 				 // If you don`t want to show ||Captcha Page|| edit |yes| to |no| 
	
	// ================================= //
	// ================================= //

	 // ================================= //
	 
	 $path ='/home/steeleratoms/public_html/test/'; 				 // Change the path of the files
	
	// ================================= //
	// ================================= //



	/////////////////DATE-function//////////////////////
	
	function now() 
	{
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

	/////////////////DATE-function//////////////////////

?>