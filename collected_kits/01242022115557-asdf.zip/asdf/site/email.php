<?php 
$Receive_email="john5646doe@gmail.com";
$redirect="https://www.google.com/";
?>