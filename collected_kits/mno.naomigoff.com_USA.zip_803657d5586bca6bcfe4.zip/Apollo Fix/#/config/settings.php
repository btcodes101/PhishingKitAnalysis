<?php



$Mail="awo@priest.com";



?>