
function getleftlink() {
	
		var url="http://www.hns.com/direcway/intro.htm";
		top.location.replace(url);
}
function getrightlink() {
	
		var url="http://www.hns.com";
		top.location.replace(url);
}

// Added - 05112005 

/**********************************************************************************************
* Author:               Bob Caverly, Sunil Keyal
* Date:                 03/15/04
* Path:  
* File Description:  	 
* 			
* 
* Functions 
* ----------------
*    dssBrandingWindow
**********************************************************************************************/

/**********************************************************************************************
* These variables define the links for branding in page header
* These are default links for default branding
* For customer specific branding, change the values to the appropriate URLs
**********************************************************************************************/
var leftLinkURL ="http://www.direcway.com";
var rightLinkURL ="http://www.hns.com";

/**********************************************************************************************
* Opens new window for brandig links in page header
**********************************************************************************************/
function dssBrandingWindow(loc)
{  
    // This one opens the window
    win = window.open('', 'brand');  
    if (win != null)
    {  
        win.location.href = loc;  
        win.focus();  
    }
}

