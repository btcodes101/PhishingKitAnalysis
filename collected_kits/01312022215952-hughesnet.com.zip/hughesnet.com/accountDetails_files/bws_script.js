/********************************************************************************************
 *  FILE NAME:  bws_script.js
 *  DESCRIPTION: This file is used to include all javascript validations for BWS Interfaces
 *
 *  Revision History
 *   Date         Version      Name  		     SPR Id	            Comments
 *  ================================================================================================================================
 *     -	      1.0		  Namrata Agarwal  	                    Initial Creation
 *  22-Nov-2005	  2.0		  Namrata Agarwal    SPR# 18425   	    Updated for incorporating validations for
 *                                                                  Update Customer Profile UI
 *  28-Nov-2005	  3.0		  Namrata Agarwal       	            Updated for incorporating validations for Update Billing address
 *  29-Nov-2005	  4.0		  Jaswinder Singh       	            Updated for incorporating validations for Create/ Search /Update
 *                                                                  WBS mapping for rated and non rated events
 *  05-Dec-2005	  5.0		  Jaswinder Singh       	            Updated for review comments and added for download WBS mapping
 *  05-Dec-2005	  6.0		  Jaswinder Singh       	            Added function for upload WBS mapping
 *  26-Dec-2005   7.0         Namrata Agarwal                       Merging 6.2 code to 6.3 branch
 *  28-Dec-2005   8.0         Jaswinder Singh        3266           Fixed SPR 3266
 *  02-Jan-2006   9.0         Jaswinder Singh        3314           Fixed SPR 3314
 *  07-Feb-2006   10.0         Jaswinder Singh       21704   	Fixed SPR 21704
 *  08-Feb-2006   11.0         Robin Bathla  	     21667    	Fixed SPR 21667
 *  10-Feb-2006   12.0         Robin Bathla  	     21666,21957	modified check in validate glid function
 *  10-Feb-2006   12.0         Robin Bathla  	     21787		modified check in validate glsegment function
 *  21-Feb-2006   13.0         Jaswinder Singh 	     22144		modified check in validate glID function
 *  Copyright 2004, Hughes Network Systems.
 **********************************************************************************************************************************/
  /***************** declaration of global varaibles for VAR residuals JSP*******************/
  var inputTextBoxCount ;
  
 var NAME_PREFIX = new Array();
 NAME_PREFIX[0] = "TS";
 NAME_PREFIX[1] = "TE";
 NAME_PREFIX[2] = "TD";

 /***************** declaration of global varaibles for VAR residuals JSP*******************/

 /***************** declaration of global variables for serviceadjusments JSP*******************/
 var nonMonetaryFlag = false;
 /***************** declaration of global variables for serviceadjusments JSP*******************/

/************ Functions added for DSR Category administration : Start  ************/

//CreateCategory.jsp and ModifyCategorydeals.jsp

function move(fbox, tbox)
{
var arrFbox = new Array();
var arrTbox = new Array();
var arrLookup = new Array();
var i;
for (i = 0; i < tbox.options.length; i++)
{
if ((null != tbox.options[i].value) && ('' != tbox.options[i].value))
{
arrLookup[tbox.options[i].text] = tbox.options[i].value;
arrTbox[i] = tbox.options[i].text;
}
}
var fLength = 0;
var tLength = arrTbox.length;

for(i = 0; i < fbox.options.length; i++)
{
arrLookup[fbox.options[i].text] = fbox.options[i].value;
if (fbox.options[i].selected && fbox.options[i].value != "")
{
arrTbox[tLength] = fbox.options[i].text;
tLength++;
}
else
{
arrFbox[fLength] = fbox.options[i].text;
fLength++;
}
}
arrFbox.sort();
arrTbox.sort();
fbox.length = 0;
tbox.length = 0;
var c;
for(c = 0; c < arrFbox.length; c++)
{
var no = new Option();
no.value = arrLookup[arrFbox[c]];
no.text = arrFbox[c];
fbox[c] = no;
}
for(c = 0; c < arrTbox.length; c++)
{
var no = new Option();
no.value = arrLookup[arrTbox[c]];
no.text = arrTbox[c];
tbox[c] = no;
}
}

function moveAll(fbox, tbox)
{
var c;
var k = tbox.options.length;
for(c = 0; c < fbox.options.length; c++ )
{
var no = new Option();
no.value = fbox.options[c].value;
no.text = fbox.options[c].text;
tbox[k + c] = no;
}
fbox.length = 0;
}

function checkAlphaNumericSpace(validStr) {

        checkOk = " _0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        checkStr = validStr;
        allValid = true;

        for (i=0; i<checkStr.length; i++) {
            ch = checkStr.charAt(i);
            for (j=0; j<checkOk.length; j++)
                if (ch == checkOk.charAt(j))
                   break;

                if (j == checkOk.length) {
                   allValid = false;
                   break;
                 }
        }

        if (!allValid)
        	return false;
        else
        	return true;
}

function checkAlphaNumericUnderScore(validStr) {

        checkOk = "-_0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        checkStr = validStr;
        allValid = true;

        for (i=0; i<checkStr.length; i++) {
            ch = checkStr.charAt(i);
            for (j=0; j<checkOk.length; j++)
                if (ch == checkOk.charAt(j))
                   break;

                if (j == checkOk.length) {
                   allValid = false;
                   break;
                 }
        }

        if (!allValid)
        	return false;
        else
        	return true;
}

function checkAlphaNumericWild(validStr) {

        checkOk = "-_*0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        checkStr = validStr;
        allValid = true;

        for (i=0; i<checkStr.length; i++) {
            ch = checkStr.charAt(i);
            for (j=0; j<checkOk.length; j++)
                if (ch == checkOk.charAt(j))
                   break;

                if (j == checkOk.length) {
                   allValid = false;
                   break;
                 }
        }

        if (!allValid)
        	return false;
        else
        	return true;
}

function validateCreateCategoryform(form)
{
  if (form.CategoryName.value == "")
  {
     	alert("Please enter the Category Name.");
        form.CategoryName.focus();
       	return false;
  }
  else if(!(checkAlphaNumericSpace(form.CategoryName.value)))
     {
         alert('Please enter an AlphaNumeric value for CategoryName.');
         form.CategoryName.focus();
         return false;
     }
  else
  {
     selectOnSubmit(form.NewMappedDeals);
  }
}


function selectOnSubmit(abox)
{

 for(c =0; c < abox.length; c++)
  {
    abox[c].selected=true;
  }
  return true;

 }

function sortBoxes()
{
sortBox(document.forms[0].UnMappedDeals);
sortBox(document.forms[0].NewMappedDeals);
}

function sortBox(box)
{
var arrBox = new Array();
var arrLookup = new Array();
var i;
var k=0;
for (i = 0; i < box.options.length; i++)

{

if ((box.options[i].value != null) && (box.options[i].value != ''))
{
arrLookup[box.options[i].text] = box.options[i].value;
arrBox[k] = box.options[i].text;
k++;
}
}
arrBox.sort();
box.length = 0;
var c;
for(c = 0; c < arrBox.length; c++)
{
var no = new Option();
no.value = arrLookup[arrBox[c]];
no.text = arrBox[c];
box[c] = no;
}
}


/************ Functions added for DSR Category administration : End  ************/





/**** functions added for create/search WBS Mapping Rated :start  ****/

   function validateCreateSearchWBSMappingRated(form) {


        if (form.glSegment.value == "")
	{
        	alert("Please enter the GL Segment.");
		form.glSegment.focus();
	       	return false;
	 }
         else if ((form.glSegment.value).charAt(0) != '.')
        {
		alert('GL Segment should start with a period(.).');
	        form.glSegment.focus();
	        return false;
	}

	if ((form.glSegment.value).match(/[^0-9a-zA-Z.]/))
	{
		alert('GL Segment can only contain alphanumerics separated by periods');
		form.glSegment.focus();
	        return false;
	}
	else if ((form.glSegment.value).match(/\.\./))
	{
		alert('GL Segment can not have consecutive periods');
		form.glSegment.focus();
	        return false;
	}
	else if ((form.glSegment.value).match(/\.$/))
	{
		alert('GL Segment can not have period at the end');
		form.glSegment.focus();
		return false;
	}

	   if (form.glID.value == "")
	   {
		alert("Please enter the GL ID.");
		form.glID.focus();
		return false;
	   }
	   else if(form.glID.value.length < 7 )
	   {
		alert('Please enter a 7 digit value for GL ID.');
		form.glID.focus();
		return false;
	  }
	   else if ((form.glID.value).charAt(0) == '0')
	   {
	   		alert('GL ID should not start with 0.');
	   	        form.glID.focus();
	   	        return false;
	   }
	   else if((isNaN(form.glID.value)))
	   {
		alert('Please enter a numeric value for GL ID.');
		form.glID.focus();
		return false;
	  }
	  else if (form.glID.value.indexOf(" ") != -1)
	  {
		alert("Spaces are not allowed in GL ID");
		form.glID.focus();
		return false;
	  }else if ( (form.glID.value).charAt(3) != '0' || (form.glID.value).charAt(4) != '0' ||
	   	(form.glID.value).charAt(5) != '0'  || (form.glID.value).charAt(6) != '0')
	  {
	   	   alert('GL ID should be in GGG0000 format.');
	   	   form.glID.focus();
	   	   return false;
	   }



        if ( form.reqType.value == "createWBS" && form.wbsNumber.value == "")
        {
         	alert("Please enter the WBS No.");
			form.wbsNumber.focus();
         	return false;
        }
	else if((  form.reqType.value == "createWBS" && isNaN(form.wbsNumber.value) ))
	{
		 alert('Please enter a numeric value for WBS Number.');
	         form.wbsNumber.focus();
		 return false;
	}
	else if (form.reqType.value == "createWBS" && form.wbsNumber.value.length < 5)
	{
         	alert("Please enter a 5 digit value for WBS Number.");
		form.wbsNumber.focus();
         	return false;
        }
	else if (form.reqType.value == "createWBS" && form.wbsNumber.value.indexOf(" ") != -1)
	{
		alert("Spaces are not allowed in WBS number.");
		form.wbsNumber.focus();
		return false;
        }
	if (!form.Submit.clicked)
        {
	 form.Submit.disabled = true;
        }
	if (!form.Reset.clicked)
        {
	 form.Reset.disabled = true;
        }
        form.submit();
   }



/**** functions added for create/search WBS Mapping Rated :ends  ****/



/**** functions added for update WBS Mapping  Rated and Non Rated  :start  ****/

   function validateUpdateWBSMapping(form)
     {

           if ( form.wbsNumber.value == "")
   		{
            	alert("Please enter the WBS Number.");
   			form.wbsNumber.focus();
            	return false;
           	}
   		else if((isNaN(form.wbsNumber.value)))
   		 {
   			  alert('Please enter a numeric value for WBS Number.');
   			  form.wbsNumber.focus();
   				return false;
   		 }
   		else if ( form.wbsNumber.value.length < 5)
   		{
            	alert("Please enter a 5 digit value for WBS Number.");
   			form.wbsNumber.focus();
            	return false;
           	}
           	else if (form.wbsNumber.value.indexOf(" ") != -1)
           	{
           	alert("Spaces are not allowed in WBS Number");
   			form.wbsNumber.focus();
            	return false;
           	}
   	toggleButton(form.Reset,form);
   	toggleButton(form.Submit,form);

   }

/**** functions added for update WBS Mapping Rated and Non Rated events(Special)  :ends  ****/


/**** function added for delete WBS Mapping:start  ****/

function validateDeleteWBSMapping(form) {
	if (confirm("You are about to delete the mapping. Are you sure?")) {
        	toggleButton(form.Submit,form);
        	return true;
       	}
       	else
       	{
       		return false;
       	}

}

/**** function added for delete WBS Mapping:ends  ****/


/*** functions added for down WBS Mapping Rated and Non Rated events(Special)  :start  ***/

function displayFieldsForDD2(thisForm, type)
  {

      deleteRow2();

      if (type == 'u') {
  	   var newRow0 = document.all.param_table.insertRow();
  	   var col0 = (newRow0.insertCell())
  	   col0.height = 10;

	   var newRow1 = document.all.param_table.insertRow();
	   var col1 = (newRow1.insertCell())
	   col1.innerHTML = "<font size=2><b><span class=Required>*</span>&nbsp;Select Event Type:&nbsp;</b></font>";
	   col1.align = 'right';
	   col1.width = '20%';
     	   (newRow1.insertCell()).innerHTML = "<input type=radio name=eventMode value=rated>Rated Events<br><input type=radio name=eventMode value=special>Special Events";

	   document.all.eventMode[0].checked = true;

     } else if (type == 'e') {
	   document.all.entireUnallocated[0].checked = true;
     }
}


function deleteRow2() {

	     numrows = document.all.param_table.rows.length;

	     while (numrows != 0){
	         param_table.deleteRow(numrows-1);
	         numrows = numrows - 1;
	     }

  }

/*** functions added for download WBS Mapping Rated and Non Rated events(Special)  :ends  ***/

/***** functions added for Bulk upload WBS Mapping :strart  ***/

function validateForm6(thisForm)
 {

  	 if (thisForm.upfile.value == "")
  	 {
		alert("Please enter the bulk upload filename");
		return false;
 	 }

 	 toggleButton(thisForm.Submit,thisForm);

  }
/***** functions added for Bulk Upload WBS Mapping :end  ***/

// validations for Billing Address
function validateUpdateAddress(form) {
			//SPR 36258 Start
			form.pcAddress.value = Trim(form.pcAddress.value);
			//SPR 36258 End
	        if(form.pcAddress.value == "") {
	            alert("Please enter your Billing Address.");
	            form.pcAddress.focus();
	            return false;
	        }

	        if(form.pcCity.value == "") {
	            alert("Please enter a City name.");
	            form.pcCity.focus();
	            return false;
	        }

			if (form.ccCountry.value == '') {
				alert("Please select a Country");
				form.ccCountry.focus();
				return false;
			}
			
			if (form.ccState.value == '') {
				alert("Please select a State/Province");
				form.ccState.focus();
				return false;
			}
			
	        if(form.ccCountry.value == "US" || form.ccCountry.value == "CA") {
			if(form.pcZipcode.value == "") {
			    alert("Please enter a Postal/Zip code.");
			    form.pcZipcode.focus();
			    return false;
			}

		       if(form.ccCountry.value == "US") {
				if (form.pcZipcode.value.match(/^\d{5}(\-\d{4})?$/) == null ) {
				    alert("Postal/Zip code must be in the format of 12345 or 12345-1234.");
				    form.pcZipcode.focus();
				    form.pcZipcode.select();
				    return false;
				 }
			      }

			      if(form.ccCountry.value == "CA") {
				if (form.pcZipcode.value.match(/^\D{1}\d{1}\D{1}\ ?\d{1}\D{1}\d{1}$/) == null ) {
				   alert("Postal/Zip code must be in the format of M1S 3L1 or M1S3L1.");
				   form.pcZipcode.focus();
				   form.pcZipcode.select();
				   return false;
				 }
			       }
		} else if (form.pcZipcode.value == "" || form.pcZipcode.value == null) {
			form.pcZipcode.style.color = "#ffffff";
			form.pcZipcode.value = "00000";
		}
	    return true;
}


// Validations for Update Customer Profile UI
function validateProfileForm(form)
{
     if(form.CCN.value != "")
     {
        if((isNaN(form.CCN.value)))
         {
            alert("Please enter a numeric value for Ordering Number.");
            form.CCN.focus();
            return false;
         }
        if ((form.CCN.value).charAt(0) != '2')
         {
            alert("Ordering Number should start with digit 2.");
            form.CCN.focus();
            return false;
         }
      }

     if(form.discountsAuthBy.value != null)
     {
        if(!(checkAlphaNumeric(form.discountsAuthBy.value)))
         {
            alert('Please enter an AlphaNumeric value for Discounts Authorized By.');
           form.discountsAuthBy.focus();
           return false;
         }
     }

}

// Validations for checking alphanumeric characters
function checkAlphaNumeric(validStr) {

        checkOk = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        checkStr = validStr;
        allValid = true;

        for (i=0; i<checkStr.length; i++) {
            ch = checkStr.charAt(i);
            for (j=0; j<checkOk.length; j++)
                if (ch == checkOk.charAt(j))
                   break;

                if (j == checkOk.length) {
                   allValid = false;
                   break;
                 }
        }

        if (!allValid)
        	return false;
        else
        	return true;
}

// Validations for checking alphanumeric characters with Hyphen
function checkAlphaNumericHyphen(validStr) {
     if (validStr.match(/[^0-9a-zA-Z-]/))
     {
		return false;
	 }
	 else 
	 {
	 	return true;
	 }
}

function checkCollectMoneyForm(form) {
	if(form.collectType[0].checked) {
	   if (form.currentBalance.value <= 0) {
	      alert("Cannot collect zero or a negative amount.");
	      return false;
	   }
	   if (form.collectamount.value == "") {
	      alert("Please enter the amount.");
	      return false;
	   }
	   if (form.collectamount.value <= 0) {
	      alert("Please enter an amount greater than zero.");
	      return false;
	   }
	}
	if(form.collectType[1].checked) {
	   if (form.collectamount.value == "") {
	      alert("Please enter the amount.");
	      return false;
	   }

	   if (form.collectamount.value <= 0) {
	      alert("Please enter an amount greater than zero.");
	      return false;
	   }

	 }

	if (!form.Submit.clicked) {
	   toggleButton(form.Submit,form);
	}

	return true;
}




function validateBulkAdjustmentForm(form) {

   if(form.upfile.value == "") {
     alert("Please enter the input bulk file.");
     return false;
   }

   toggleButton(form.Submit,form);
   return true;
}

function validateBulkPayReversalForm(form) {

   if(form.upfile.value == "") {
     alert("Please enter the input bulk file.");
     return false;
   }

   if(form.ReversalReason.value == "Select One") {
     alert("Please select a reason for bulk payment reversal.");
     return false;
   }

   toggleButton(form.Submit,form);
   return true;
}

function validateBulkWriteOffForm(form) {

   if(form.upfile.value == "") {
     alert("Please enter the input bulk file.");
     return false;
   }

   if(form.WriteOffReason.value == "Select One") {
     alert("Please select a reason for bulk write-off.");
     return false;
   }

   toggleButton(form.Submit,form);
   return true;
}

function validateSwitchToInvoiceForm(button,form) {

   var result = validateInvBillingInfo(form);

   if(result == true )
   {
      toggleButton(button,form);
   }
   else
   {
      return false;
   }
}

function validateSwitchToCCForm(button,form) {
   var result = validateCreditCardInfo(form);
   if(result==true)
   {
      toggleButton(button,form);
   }
   else
   {
	return false;
   }
}

function validateInvBillingInfo(form) {
                if(form.billName.value == "") {
                        alert("Please enter your Billing Name.");
                        form.billName.focus();
                        return false;
                }
                var msg = 'Billing ';

			if (!(invoiceNameCheck(Trim(form.billName.value)))) {
		   		form.billName.focus();
		   		return false;
			}
	    	if(InvalidNameCheck(Trim(form.billName.value), msg)){
			form.billName.focus();
			return false;
                }

              if(form.billAddress.value == "") {
                        alert("Please enter your Billing Address.");
                        form.billAddress.focus();
                        return false;
                }
                if(form.billCity.value == "") {
                        alert("Please enter a City name.");
                        form.billCity.focus();
                        return false;
                }

                if(form.billZipCode.value == "") {
                        alert("Please enter a Postal/Zip code.");
                        form.billZipCode.focus();
                        return false;
                }
               if(form.ccCountry.value == "US") {

		    if (form.billZipCode.value.match(/^\d{5}(\-\d{4})?$/) == null ) {
			       alert("Postal/Zip code must be in the format of 12345 or 12345-1234.");
			       form.billZipCode.focus();
			       form.billZipCode.select();
			      return false;
			     }
	       		}

		if(form.ccCountry.value == "CA") {
		 if (form.billZipCode.value.match(/^\D{1}\d{1}\D{1}\ ?\d{1}\D{1}\d{1}$/) == null ) {
		    alert("Postal/Zip code must be in the format of M1S 3L1 or M1S3L1.");
		    form.billZipCode.focus();
		    form.billZipCode.select();
		    return false;
		  }
		}

        return true;
}

function checkSettleDisputeForm(form) {
   var itemchecked = false;
   for(var j = 0 ; j < form.DisputeAmount.length ; j++) {
     if(form.DisputeAmount[j].checked) {
	 	itemchecked = true;
	 	break;
	 }
   }

   if(!itemchecked) {
    alert("Please select weekly/monthly credit or debit for the account.");
    form.DisputeAmount[0].focus();
	return false;
   }

    if(form.DisputeReason.value == "Select One") {
  	alert("Please select a reason for Service Adjustments.");
   	form.DisputeReason.focus();
        return false;
   }

   toggleButton(form.Reset,form);
   toggleButton(form.Submit,form);
   return true;
}

function clearSettleDisputeForm(form) {
   for(var j = 0 ; j < document.settledispute.DisputeAmount.length ; j++) {
     if(document.settledispute.DisputeAmount[j].checked) {
     	 document.settledispute.DisputeAmount[j].clear;
     }
   }
   return true;
}

function viewUsagePg (form) {
	toggleButton(form.Submit,form);
	return true;
}

function toggleButton (button,form) {
	if (typeof button.disabled != "undefined")
		button.disabled = !button.disabled;
	else if (button.clicked) {
		button.clicked = false;
		button.value = button.oldValue;
	}
	form.submit();
}

function validateDWayLogin(form) {
        if(form.siteId.value == "") {
                alert("Please enter Site ID.");
                form.siteId.focus();
                return false;
        }
        if(form.zip.value == "") {
                alert("Please enter Site Postal/Zip code.");
                form.zip.focus();
                return false;
        }
        if(form.phone.value == "") {
                alert("Please enter Site Phone Number.");
                form.phone.focus();
                return false;
        }
        return true;
}

function validateDPCLogin(form) {
        if(form.siteId.value == "") {
                alert("Please enter Site ID.");
                form.siteId.focus();
                return false;
        }
        if(form.zip.value == "") {
                alert("Please enter Site Postal/Zip code.");
                form.zip.focus();
                return false;
        }
        if(form.phone.value == "") {
                alert("Please enter Site Phone Number.");
                form.phone.focus();
                return false;
        }
        return true;
}

function validateProviderLogin(form) {
        if(form.login.value == "") {
                alert("Please enter Login ID.");
                form.login.focus();
                return false;
        }
        if(form.password.value == "") {
                alert("Please enter Password.");
                form.password.focus();
                return false;
        }
        return true;
}

function validateHardwareLogin(form) {
        if(form.account.value == "") {
                alert("Please enter Hardware Account Number.");
                form.account.focus();
                return false;
        }
        if(form.zip.value == "") {
                alert("Please enter Site Postal/Zip code.");
                form.zip.focus();
                return false;
        }
        if(form.phone.value == "") {
                alert("Please enter Site Phone Number.");
                form.phone.focus();
                return false;
        }
        return true;
}


function validateUpdateCCInfo(form, billingType, DisplayedCCNum) {
    	if (billingType == "CCBilling") {
            if(form.pcName.value == "") {
	            alert("Please enter the name on your credit card.");
	            form.pcName.focus();
	            return false;
	        }

        if (!(invoiceNameCheck(Trim(form.pcName.value))))
	    {
		   		form.pcName.focus();
		  		return false;
		  		}

	 var msg = 'Credit Card ';

	 if(InvalidNameCheck(Trim(form.pcName.value), msg)){
		form.pcName.focus();
		return false;
            }

	        if(form.pcCCNum.value == "") {
	            alert("Please enter your Credit Card Number.");
	            form.pcCCNum.focus();
	            return false;
	        }

		if (form.pcCCNum.value == DisplayedCCNum) {
		} else {
	            /* Commented for SPR -20211
		    if ((form.pcCCNum.value.match(/^\d{15,16}$/) == null)|| (checkCC(form.pcCCNum.value) == false)){
			alert("Credit Card Number is not correct. Please try again.");
			form.pcCCNum.focus();
			form.pcCCNum.select();
			return false;
		    }*/

		    if (form.pcCCNum.value.match(/^\d{15,16}$/) == null) {
			alert("The length of the Credit Card Number is not correct. Please try again.");
			form.pcCCNum.focus();
			form.pcCCNum.select();
			return false;
		    } else if (checkCC(form.pcCCNum.value) == false){
			alert("The format of the credit card number is not correct.The checksum is incorrect.Please try again.");
			form.pcCCNum.focus();
			form.pcCCNum.select();
			return false;

	            }
	        }

	        var now = new Date();
	        var mm = now.getMonth() + 1;
	        mm = (mm < 10)? "0" + mm:"" + mm;
	        var yyyy = now.getFullYear();

	        if (form.year.value == (yyyy + "").substring(2)) {
	            if (form.month.value < mm) {
		            alert("The Credit Card Expiration Month must be current month or later.");
		            form.month.focus();
		            return false;
	            }
	        }

	        if(form.pcAddress.value == "") {
	            alert("Please enter your Credit Card Billing Address.");
	            form.pcAddress.focus();
	            return false;
	        }

	        if(form.pcCity.value == "") {
	            alert("Please enter a City name.");
	            form.pcCity.focus();
	            return false;
	        }

		if(form.ccCountry.value == "") {
			alert("Please select a Country.");
			form.ccCountry.focus();
			return false;
		}
		if(form.ccState.value == "") {
			alert("Please select a State.");
			form.ccState.focus();
			return false;
		}

	        if((form.ccCountry.value == "US" || form.ccCountry.value == "CA") && form.pcZipcode.value == "") {
	            alert("Please enter a Postal/Zip code.");
	            form.pcZipcode.focus();
	            return false;
	        }

	       if(form.ccCountry.value == "US") {
	      	        if (form.pcZipcode.value.match(/^\d{5}(\-\d{4})?$/) == null ) {
	      	            alert("Postal/Zip code must be in the format of 12345 or 12345-1234.");
	      	            form.pcZipcode.focus();
	      	            form.pcZipcode.select();
	      	            return false;
	      	         }
	      	      }

	      	      if(form.ccCountry.value == "CA") {
	      	        if (form.pcZipcode.value.match(/^\D{1}\d{1}\D{1}\ ?\d{1}\D{1}\d{1}$/) == null ) {
	      	           alert("Postal/Zip code must be in the format of M1S 3L1 or M1S3L1.");
	      	           form.pcZipcode.focus();
	      	           form.pcZipcode.select();
	      	           return false;
	      	         }
	      	       }

	      	   }

        toggleButton(form.Submit,form);
	    toggleButton(form.Reset,form);
	    return true;
}

function validateCreditCardInfo(form) { 
                                                
                        if(form.ccName.value == "") {
                                alert("Please enter the name on your credit card.");
                                form.ccName.focus();
                                return false;
                        }

                        if (!(invoiceNameCheck(Trim(form.ccName.value)))) {
								   		form.ccName.focus();
								   		return false;
								   		}

                        var msg = 'Credit Card ';
                        if(InvalidNameCheck(Trim(form.ccName.value), msg)){
				form.ccName.focus();
				return false;
                         }
                         
                        if(form.ccNumber.value == "") {
                                alert("Please enter your Credit Card Number.");
                                form.ccNumber.focus();
                                return false;
                        }
                      
	             /* Commented for SPR - 20211
		   	if ((form.ccNumber.value.match(/^\d{15,16}$/) == null)|| (checkCC(form.ccNumber.value) == false)){
			        alert("Credit Card Number is not correct. Please try again.");
			        form.ccNumber.focus();
			        form.ccNumber.select();
			        return false;
		  	}*/
			if (form.ccNumber.value.match(/^\d{15,16}$/) == null) {
				alert("The length of the Credit Card Number is not correct. Please try again.");
				form.ccNumber.focus();
				form.ccNumber.select();
				return false;
			} else if (checkCC(form.ccNumber.value) == false){
				alert("The format of the credit card number is not correct.The checksum is incorrect.Please try again.");
				form.ccNumber.focus();
				form.ccNumber.select();
				return false;
                        }
                       
                       var now = new Date();
                        var mm = now.getMonth() + 1;
                        mm = (mm < 10)? "0" + mm:"" + mm;
                        var yyyy = now.getFullYear();
                        if (form.year.value == (yyyy + "").substring(2)) {
                                if (form.month.value < mm) {
                                        alert("The Credit Card Expiration Month must be current month or later.");
                                        form.month.focus();
                                        return false;
                                }
                        }
                        if(form.ccAdd.value == "") {
                                alert("Please enter your Credit Card Billing Address.");
                                form.ccAdd.focus();
                                return false;
                        }
                        if(form.ccCity.value == "") {
                                alert("Please enter a City name.");
                                form.ccCity.focus();
                                return false;
                        }
                        if(form.ccZipCode.value == "") {
                                alert("Please enter a Postal/Zip code.");
                                form.ccZipCode.focus();
                                return false;
                        }
		    if(form.ccCountry.value == "US") {
			  if (form.ccZipCode.value.match(/^\d{5}(\-\d{4})?$/) == null ) {
			    alert("Postal/Zip code must be in the format of 12345 or 12345-1234.");
			    form.ccZipCode.focus();
			    form.ccZipCode.select();
			    return false;
			  }
			}

			if(form.ccCountry.value == "CA") {
			  if (form.ccZipCode.value.match(/^\D{1}\d{1}\D{1}\ ?\d{1}\D{1}\d{1}$/) == null ) {
			     alert("Postal/Zip code must be in the format of M1S 3L1 or M1S3L1.");
			     form.ccZipCode.focus();
			     form.ccZipCode.select();
			     return false;
			  }
			 }

                        if(form.ccCountry.value == "") {
                                alert("Please enter a Country name.");
                                form.ccCountry.focus();
                                return false;
                        }
                        
        return true;
}

function validateChangePass(form, accType) {
    if(accType == "User") {
        if(form.oldPass.value == "") {
            alert("Please enter your Old Password.");
                        form.oldPass.focus();
            return false;
        }
    }
    if(form.newPass.value == "") {
        alert("Please enter your New Password.");
        form.newPass.focus();
        return false;
    }
        if(form.newPass.value.length < 6) {
                alert("Please enter a password with at least 6 characters.");
                form.newPass.focus();
                form.newPass.select();
        return false;
        }
        if(accType == "User") {
        if(form.oldPass.value == form.newPass.value) {
            alert("Please make the New Password different from the Old Password.");
            form.newPass.focus();
                        form.newPass.select();
                return false;
        }
    }
        if(form.newPassAgain.value == "") {
        alert("Please confirm your New Password.");
        form.newPassAgain.focus();
        return false;
    }
        if(form.newPass.value != form.newPassAgain.value) {
                alert("Changed Passwords do not match.");
                form.newPassAgain.focus();
                form.newPassAgain.select();
        return false;
        }
        return true;
}

function validateSearchBySiteId(form) {
       var chk = checkSiteId(form.siteId.value);
       form.siteId.value = form.siteId.value.toUpperCase();
       	if(!chk){
       		form.siteId.focus();
       		return false;
       	}

       	if(form.serviceName.value == "Select One") {
       	     alert("Please select a Service Type.");
       	     return false;
          	}
        toggleButton(form.Submit,form);
        return chk;
}

function validateSearchByCC(form)
{
        if(form.queryString.value == "")
        {
                alert("Please enter your search query.");
                form.queryString.value = "";
                form.queryString.focus();
                return false;
        }

        var str;
        for (var i = 0; i < form.queryType.length; i++) {
	if (form.queryType[i].checked) {
	str = form.queryType[i].value;
	break;
	}
	}

	var chk = true;
	if(str == "AccountNo")
	{
		if(Trim(form.queryString.value) == "")
        	{
        		alert('Account Number is not correct. Please try again.');
        		form.queryString.value = "";
	        	chk = false;
        	}
        }
	if(str == "Name")
	{
		if(Trim(form.queryString.value) == "")
		{
			alert('Last Name/First Name is not correct. Please try again.');
			form.queryString.value = "";
	        	chk = false;
		}
        }

        if(str == "CreditCard")
        {
        	chk = checkCC(form.queryString.value);
                if(chk == false)
                   alert('Credit Card is not correct. Please try again.');
        }
        if(str == "Phone")
        {
                chk = checkPhoneNumber(form.queryString.value);
                if(chk == false)  {
                    alert("Phone number should comprise of 10 digits in \n XXX-XXX-XXXX format.");
                }
                else  {
			        var nameone = form.queryString.value;
			        if(nameone.charAt(3) != "-") {
			            alert("Phone number should comprise of 10 digits in \n XXX-XXX-XXXX digits format.");
			        }
                }
        }

        form.queryString.focus();

        if (chk == true) {
         toggleButton(form.Submit,form);
        }

        return chk;
  }



function validateRefundForm(form) {
        if (!form.operationType[0].checked && !form.operationType[1].checked) {
                alert("Please select Credit or Debit option.");
                form.operationType[0].focus();
                return false;
        }
        if(Trim(form.refundAmount.value) == "") {
                alert("Please enter an amount.");
                form.refundAmount.focus();
                return false;
        }
        if(form.refundAmount.value == 0){
		alert("Zero amount can not be adjusted");
		form.refundAmount.focus();
		form.refundAmount.select();
		return false;
        }

        if(form.refundAmount.value < 0){
		alert("Amount ("+form.refundAmount.value+")\nNegative amount not allowed");
		form.refundAmount.focus();
		form.refundAmount.select();
		return false;
	}

	if (form.operationType[0].checked) {
                if (form.refundAmount.value.match(/^[0-9]+(\.\d{1,2})?$/) == null) {
                        alert("Please enter value upto 2 places of decimal.");
                        form.refundAmount.focus();
                        form.refundAmount.select();
                        return false;
                }
        }
        if (form.operationType[1].checked) {
                if (form.refundAmount.value.match(/^\-?[0-9]+(\.\d{1,2})?$/) == null) {
                        alert("Please enter value upto 2 places of decimal.");
                        form.refundAmount.focus();
                        form.refundAmount.select();
                        return false;
                }
        }

    if(form.crmRefNo.value == "")
	{
	     alert("Please enter the CRM Reference No.");
	     form.crmRefNo.value = "";
	     form.crmRefNo.focus();
	     return false;
	}
	if(!(checkAlphaNumericSpace(form.crmRefNo.value)))
     {
         alert("Please enter an AlphaNumeric value for CRM Reference Number.");
         form.crmRefNo.focus();
         return false;
     }
  	var val = form.Submit.disabled;
  	if (val){
	  return false;
	}
	else
	{
          form.Submit.disabled = true;
          return true;
       	}

}

// Addition for toggle link -- start

function toggleLink (links,indx)
{
   if (links != null)
   {
		if (links.length > 1)
		{
			for(var i=0; i<links.length;i++)
			{
				link = links[i];
				disableLink (link);

				if(i==indx)
				{
					link.disabled = !link.disabled;
				}
			}
		}
		else
		{
			link = links;
			disableLink (link);
			link.disabled = !link.disabled;
		}

	}
 }

function cancelLink () {
  return false;
}

function disableLink (link) {
  if (link.onclick)
    link.oldOnClick = link.onclick;
   link.onclick = cancelLink;
}

function enableLink (link) {
  link.onclick = link.oldOnClick ? link.oldOnClick : null;
}

// Addition for toggle link -- end

//Code to validate Site Id

function checkSiteId(nameToCheck)
{

  if ((nameToCheck == '') || (nameToCheck == null))
  {
	alert('Please enter a Site ID.');
	return false;
  }

  if(nameToCheck.length > 255)
  {
    alert('SiteId exceeds maximum acceptable length of 255.');
	return false;
  }

 for (var i=0; i < nameToCheck.length; i++) {
    var name = nameToCheck.charAt(i);
	if (!(name >= 'a' && name <= 'z') && !(name >= 'A' && name <= 'Z') && !(name >= '0' && name <= '9'))
	{
	  alert('Site ID contains invalid characters');
	  return false;
	}
    }
   return true;
}

//Code for validation of Phone Number
/************************************************
DESCRIPTION: Validates that a string contains valid
  phone pattern(xxx-xxx-xxxx).
  Ex. 999-999-9999

PARAMETERS:
   nameToCheck - String to be tested for validity

RETURNS:
   True if valid, otherwise false.
*************************************************/

function checkPhoneNumber(nameToCheck)
{
  if(nameToCheck.length != 12) return false;

  var objRegExp  = /^[1-9]\d{2}\-\d{3}\-\d{4}$/;
  return objRegExp.test(nameToCheck);
}

// Code for validation of Credit Card Number
// Uses Luhn's Algorithm

function checkCC(s) {

  var i, n, c, r, t;

  // First, reverse the string and remove any non-numeric characters.

  r = "";
  for (i = 0; i < s.length; i++) {
    c = parseInt(s.charAt(i), 10);
    if (c >= 0 && c <= 9)
      r = c + r;
  }

  // Check for a bad string.

  if (r.length <= 1)
    return false;

  // Now run through each single digit to create a new string. Even digits
  // are multiplied by two, odd digits are left alone.

  t = "";
  for (i = 0; i < r.length; i++) {
    c = parseInt(r.charAt(i), 10);
    if (i % 2 != 0)
      c *= 2;
    t = t + c;
  }

  // Finally, add up all the single digits in this string.

  n = 0;
  for (i = 0; i < t.length; i++) {
    c = parseInt(t.charAt(i), 10);
    n = n + c;
  }

  // If the resulting sum is an even multiple of ten (but not zero), the
  // card number is good.

  if (n != 0 && n % 10 == 0)
    return true;
  else
    return false;
}

/**
 * Check if given value is valid email address
 */

function isSpecialCharforMail(name)
{
	if ((name == '_') || (name == '-') || (name == '.') || (name == '@')){
	    return true;
	}
	else
	{
		return false;
	}
}

function checkEMail (emailStr) {
	if ((Trim(emailStr) == '') || (emailStr == null)) {
			alert(" Please provide a valid E-mail Id.");
			return true;
	}
	var firstAlphabet = emailStr.charAt(0);
		 if (!(firstAlphabet >= 'a' && firstAlphabet <= 'z') && !(firstAlphabet >= 'A' && firstAlphabet <= 'Z')){
			 alert(" E-mail Id should begin with an alphabet.");
			 return true;
		 }
	for (var i=0; i < emailStr.length; i++) {
		firstAlphabet = emailStr.charAt(i);
		 if (!(firstAlphabet >= 'a' && firstAlphabet <= 'z')
			 && !(firstAlphabet >= 'A' && firstAlphabet <= 'Z')
			 && !(firstAlphabet >= '0' && firstAlphabet <= '9')
			 && !(firstAlphabet == '-')
			 && !(firstAlphabet == '_')
			 && !(firstAlphabet == '@')
			 && !(firstAlphabet == '.')){
			 alert("Invalid characters specified in E-mail Id.");
			 return true;
		 }
	}

	for (var i=0; i < emailStr.length-1; i++) {
		if(isSpecialCharforMail(emailStr.charAt(i)) && isSpecialCharforMail(emailStr.charAt(i+1)))
		{
			 alert("Invalid E-mail Id, consecutive special characters not allowed.");
			 return true;
		}
	}
	var at_flag = false;
	for (var i=0; i < emailStr.length; i++) {
		if(emailStr.charAt(i) == '@')
		{
			flag = true;
		}
		if((emailStr.charAt(i) == '_') && flag)
		{
			 alert("Invalid E-mail Id, should not contain '_' after '@'.");
			 return true;
		}

	}
	var emailPat=/^(.+)@(.+)$/;
	var specialChars="\\(\\)<>@,;:\\\\\\\"\\.\\[\\]";
	var validChars="\[^\\s" + specialChars + "\]";
	var quotedUser="(\"[^\"]*\")";
	var ipDomainPat=/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
	var atom=validChars + '+';
	var word="(" + atom + "|" + quotedUser + ")";
	var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
	var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
	var matchArray=emailStr.match(emailPat);
	if (matchArray==null) {
		alert("E-mail Id address seems incorrect (check @ and .'s).");
		return true;
	}
	var user=matchArray[1];
	var domain=matchArray[2];

	if (user.match(userPat)==null) {
		alert("Invalid username in E-mail Id.");
		return true;
	}

	var IPArray=domain.match(ipDomainPat);
	var flag = 0;
	if (IPArray!=null) {
		  for (var i=1;i<=4;i++) {
			  if (IPArray[i]>255)
				flag = 1;
		  }
		  if((IPArray[1]==0) && (IPArray[2]==0) &&(IPArray[3]==0) &&(IPArray[4]==0))
			  flag = 1;
		  if((IPArray[1]==255) && (IPArray[2]==255) &&(IPArray[3]==255) &&(IPArray[4]==255))
			  flag = 1;
		  if((IPArray[1]==127))
			  flag = 1;
		  if((IPArray[1]<1 || IPArray[1]>223))
			  flag = 1;
		  if((IPArray[4]<1 || IPArray[4]>254))
			  flag = 1;

		  if(flag==1){
			  alert("Destination IP address is invalid in E-mail Id.");
			  return true;
		  }
		return false;
	}
	var domainArray=domain.match(domainPat);
    if (domainArray==null) {
		alert("Invalid Host Name in E-mail Id.");
		return true;
	}

	var atomPat=new RegExp(atom,"g");
	var domArr=domain.match(atomPat);
	var len=domArr.length;
	if (len<2) {
	   var errStr="Domain Name missing in email address.";
	   alert(errStr);
	   return true;
	}

	var domainName = domArr[len -1];

	if( domainName.length < 2)
	{
	  alert("Valid e-mail should have minimum six characters a@a.aa");
	  return true;
	}

	for (k=0; k< domainName.length;k++ )
	{
		name = domainName.charAt(k);
	    if (!(name >= 'a' && name <= 'z') && !(name >= 'A' && name <= 'Z')){
			alert("Domain name contains invalid characters.");
			return true;
		}
	}
	return false;
}

/*function collectmoneycheck(button,form)
{

  if(form.collectType[1].checked == true)
  {
   var collectamount = Trim(form.collectamount.value);
   var currentBalance = removeComma(form.currentBalance.value);

   if(form.collectamount.value == '')
   {
    alert('Please enter amount');
    form.collectamount.focus();
    return false;
   }
   else if((isNaN(form.collectamount.value)))
   {
      alert('Please enter a numeric value');
      form.collectamount.focus();
      return false;
   }
   else if ((collectamount.charAt(0)) == '-')
   {
           alert("You cannot collect negative amount.");
      	   form.collectamount.focus();
      	   return false;
   }
   else if (collectamount.match(/^[0-9]+(\.\d{1,2})?$/) == null)
   {
	   alert("Please enter value upto 2 places of decimal.");
	   form.collectamount.focus();
	   return false;
   }
   else if (collectamount.match(/^\-?[0-9]+(\.\d{1,2})?$/) == null)
   {
   	   alert("Please enter value upto 2 places of decimal.");
   	   form.collectamount.focus();
   	   return false;
   }

    else if(form.collectamount.value == 0)
 	{
 	  alert("You cannot collect zero amount");
	  form.collectamount.focus();
	  return false;
 	}
     else
    {
       	   var val = form.Submit.disabled;

       	   if (val){
       			return false;
       		}
       	   else
       		{
       			form.Submit.disabled = true;
       			return true;
		}
    }
 }
 else if (form.collectType[0].checked == true)
 {
 	if(form.currentBalance.value <= 0)
	{
	  alert("You cannot collect $0 amount or Negative amount");
 	  return false;
 	}
 	else
 	{
 	  toggleButton(button,form);
 	}
 }
}*/


function enableTextBox(form)
{
  form.collectamount.disabled = false;
  if(form.name == 'DirectDebitPaymentForm')
  {
       var amountLook = document.all.amt;
       amountLook.innerHTML = "<font size=2><b><span class=Required>*</span>&nbsp;Amount:&nbsp;&nbsp;&nbsp;</b></font>";
  }
  form.collectamount.focus();
}
function disableTextBox(form)
{
  form.collectamount.disabled = true;
  if(form.name == 'DirectDebitPaymentForm')
  {
       var amountLook = document.all.amt;
       amountLook.innerHTML = "<font size=2><b>Amount:&nbsp;&nbsp;&nbsp;</b></font>";
  }
}


function LTrim(str)
{
   var whitespace = new String(" \t\n\r");

   var s = new String(str);

   if (whitespace.indexOf(s.charAt(0)) != -1) {
      // We have a string with leading blank(s)...

      var j=0, i = s.length;

      // Iterate from the far left of string until we
      // don't have any more whitespace...
      while (j < i && whitespace.indexOf(s.charAt(j)) != -1)
         j++;

      // Get the substring from the first non-whitespace
      // character to the end of the string...
      s = s.substring(j, i);
   }
   return s;
}


function RTrim(str)
{
   var whitespace = new String(" \t\n\r");

   var s = new String(str);

   if (whitespace.indexOf(s.charAt(s.length-1)) != -1) {
      // We have a string with trailing blank(s)...

      var i = s.length - 1;       // Get length of string

      // Iterate from the far right of string until we
      // don't have any more whitespace...
      while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1)
         i--;


      // Get the substring from the front of the string to
      // where the last non-whitespace character is...
      s = s.substring(0, i+1);
   }

   return s;
}


function Trim(str)
{
   return RTrim(LTrim(str));
}

function removeComma(str)
{
    var s =new String(str);
     var j=0, i = s.length;

     while(j<i)
     {
       if(s.charAt(j) == ',')
       {
        var k = s.substring(0,j) + s.substring(j+1,i+1);
        s = k;
        break;
       }
       j++;
     }
     return s;
}

/**********************************************************/
/*******This is called in UpdateInfo.jsp file *************/
/**********************************************************/

function validate(form, billing)
{
  if(form.nifirstName.value == "") {
	  alert("Please enter your First Name.");
	  form.nifirstName.focus();
	  return false;
  }
     var  msg = 'First ';

 if(validateName(form.nifirstName.value, msg)){
	form.nifirstName.focus();
	return false;
 }

  var  msg = 'Middle ';

  if(form.nimiddleName.value != "")
  {
  	if(validateName(form.nimiddleName.value, msg)){
 		form.nimiddleName.focus();
 		return false;
 	}
  }

  if(form.nilastName.value == "") {
	  alert("Please enter your Last Name.");
	  form.nilastName.focus();
	  return false;
  }
 	 msg = 'Last ';

  if(validateNameWithSpaces(form.nilastName.value, msg)){
  	form.nilastName.focus();
  	return false;
 }

 if(form.niAddress.value == "") {
        alert("Please enter your Home Address.");
        form.niAddress.focus();
        return false;
 }
 if(form.niCity.value == "") {
        alert("Please enter a City name.");
        form.niCity.focus();
        return false;
 }
 /*
 if(form.niZipCode.value == "") {
        alert("Please enter a Postal/Zip code.");
        form.niZipCode.focus();
        return false;
 }
*/
 if(form.ccCountry.value == "US") {
        if (form.niZipCode.value.match(/^\d{5}(\-\d{4})?$/) == null ) {
	     alert("Postal/Zip code must be in the format of 12345 or 12345-1234.");
	     form.niZipCode.focus();
	     form.niZipCode.select();
	     return false;
	}
}

if(form.ccCountry.value == "CA") {
	  if (form.niZipCode.value.match(/^\D{1}\d{1}\D{1}\ ?\d{1}\D{1}\d{1}$/) == null ) {
	    alert("Postal/Zip code must be in the format of M1S 3L1 or M1S3L1.");
	    form.niZipCode.focus();
	    form.niZipCode.select();
	    return false;
	  }
}

if(form.niWorkPhone.value != "")
{
      if( checkPhoneNumbers(form.niWorkPhone,"Work Phone Number ")==false)
		return false;

}

if(form.niFax.value != "")
{
	if( checkPhoneNumbers(form.niFax,"Fax Number ")==false)
		return false;

}

if(form.niEmail.value == "")
{
	alert("Please enter your Email Address.");
	form.niEmail.focus();
	return false;
}

if(form.niEmail.value != "")
{
	var chk = checkEMail(form.niEmail.value);
	if(chk == true)
	{
		return false;
	}
}

if(form.niHomePhone.value != "")
{
	if( checkPhoneNumbers(form.niHomePhone,"Home Phone Number ")==false)
		return false;
}


  if (billing == "InvBilling") {
	 if(form.piName.value == "") {
		 alert("Please enter your Billing Name.");
		 form.piName.focus();
		 return false;
	 }
	 var msg = 'Billing ';

	 if (!(invoiceNameCheck(Trim(form.piName.value)))) {
	 	form.piName.focus();
		return false;
	 }

	 if(InvalidNameCheck(Trim(form.piName.value), msg)){
	  		form.piName.focus();
	  		return false;
 	 }

 	if(form.piAddress.value == "") {
		 alert("Please enter your Billing Address.");
		 form.piAddress.focus();
		 return false;
	 }
	 if(form.piCity.value == "") {
		 alert("Please enter a City name.");
		 form.piCity.focus();
		 return false;
	 }
	 if(form.ccCountry1.value == "") {
		alert("Please select a Country.");
		form.ccCountry1.focus();
		return false;
	 }
	 if(form.ccState1.value == "") {
		alert("Please select a State.");
		form.ccState1.focus();
		return false;
	 }
	 if(form.ccCountry1.value == "US" || form.ccCountry1.value == "CA") {
		 if(form.piZipcode.value == "") {
			 alert("Please enter a Postal/Zip code.");
			 form.piZipcode.focus();
			 return false;
		 }
		 if(form.ccCountry1.value == "US") {
		    if (form.piZipcode.value.match(/^\d{5}(\-\d{4})?$/) == null ) {
			    alert("Postal/Zip code must be in the format of 12345 or 12345-1234.");
			    form.piZipcode.focus();
			    form.piZipcode.select();
			    return false;
			  }
			}

			    if(form.ccCountry1.value == "CA") {
				if (form.piZipcode.value.match(/^\D{1}\d{1}\D{1}\ ?\d{1}\D{1}\d{1}$/) == null ) {
				     alert("Postal/Zip code must be in the format of M1S 3L1 or M1S3L1.");
				     form.piZipcode.focus();
				     form.piZipcode.select();
				     return false;
				   }
				}
		}  else if (form.piZipcode.value == "" || form.piZipcode.value == null) {
			form.piZipcode.style.color = "#ffffff";
			form.piZipcode.value = "00000";
		}
	 }
        form.Reset.disabled=true;
        toggleButton(form.Submit,form);
}


function InvalidNameCheck(nameToCheck,msg)
{
	var firstAlphabet = nameToCheck.charAt(0);
	 if (!(firstAlphabet >= 'a' && firstAlphabet <= 'z') && !(firstAlphabet >= 'A' && firstAlphabet <= 'Z'))
	 {
		 alert(msg + 'Name should start with an alphabet.');
		 return true;
	 }
	 for (var i=1; i < nameToCheck.length; i++) {
	 var name = nameToCheck.charAt(i);
	  if (!(name >= 'a' && name <= 'z') && !(name >= 'A' && name <= 'Z')
			 && !(name=='\'') && !(name==' ') && !(name >= '0' && name <= '9')){
		     alert(msg + 'Name contains invalid characters.');
			return true;
	  }
    }
    return false;
}

function validateName(nameToCheck,msg)
{
	var firstAlphabet = nameToCheck.charAt(0);
	 if (!(firstAlphabet >= 'a' && firstAlphabet <= 'z') && !(firstAlphabet >= 'A' && firstAlphabet <= 'Z'))
	 {
		 alert(msg + 'Name should start with an alphabet.');
		 return true;
	 }
	 for (var i=1; i < nameToCheck.length; i++) {
	 var name = nameToCheck.charAt(i);
	  if (!(name >= 'a' && name <= 'z') && !(name >= 'A' && name <= 'Z')
			 && !(name=='\'') && !(name >= '0' && name <= '9' )) {
		     alert(msg + 'Name contains invalid characters.');
			return true;
	  }
    }
    return false;
}
//SPR 26991 Start
function validateNameWithSpaces(nameToCheck,msg)
{
	var firstAlphabet = nameToCheck.charAt(0);
	var error = false;
	if (firstAlphabet.match(/[^\sa-zA-Z]/)) {
		 alert(msg + 'Name should start with an alphabet.');
		 return true;
	 }
	if (nameToCheck.match(/[^\sa-zA-Z0-9]/)) {
		alert (msg + "Only alphanumeric characters and spaces are valid in this field");
		return true;
	}
    return false;
}
//SPR 26991 End
function checkPhoneNumbers(field,stringtoshow){

	if (InvalidPhoneCheck(field.value)) {
		alert(stringtoshow+"should comprise of 10 digits or should be in \n XXX-XXX-XXXX or XXX XXX XXXX digits format.");
		field.focus();
		field.select();
		return false;
	}
	if (PhoneZeroCheck(field.value)) {
		alert(stringtoshow+"should contain atleast one non zero digit.");
		field.focus();
		field.select();
		return false;
	}
	if (PhoneStartZeroCheck(field.value)) {
		alert(stringtoshow+"can't start with zero.");
		field.focus();
		field.select();
		return false;
	}

	return true;
}

function PhoneZeroCheck(nameToCheck)
{
	if(nameToCheck.length == 0)
	{
		return false;
	}
	 for (var i=0; i < nameToCheck.length; i++) {
		var name = nameToCheck.charAt(i);
		if ((name >= '1' && name <= '9'))
			{
					return false;
			}
	  }

	return true;

}

function PhoneStartZeroCheck(nameToCheck) {
	if (nameToCheck.indexOf("0") == 0) {
		return true;
	}
}

function InvalidPhoneCheck(nameToCheck)
{	 flag=0;
	 if(nameToCheck.length>12)
		return true;
	 for (var i=0; i < nameToCheck.length; i++) {
		var name = nameToCheck.charAt(i);
		if ((name >= '0' && name <= '9'))
		{
				flag++;
		}
		if (!(name >= '0' && name <= '9') && !(name ==' ') && !(name =='-')) {
			return true;
		}
    }
	if ((flag!= 10)&& (flag!=0))
	{
		return true;
	}
	var nameone = nameToCheck.charAt(3);
	if( nameToCheck.length >10){
		var name = nameToCheck.charAt(7);
		if((name!="-" || nameone!="-") && ( !(name ==' ') || !(nameone ==' '))){
			return true;
		}
	}
	return false;
}

/***************************************************************/
/******* This is called from directdebitpayment.jsp  ***********/
/******* checkDirectDebitPaymentForm Method ********************/
/***************************************************************/

function checkDirectDebitPaymentForm(form) {

	if(form.collectType[0].checked) {
	   if (form.currentBalance.value <= 0) {
	      alert("Cannot collect zero or a negative amount.");
	      return false;
	   }
	}
	if(form.collectType[1].checked) {

	   var collectamount = Trim(form.collectamount.value);
   	   var currentBalance = removeComma(form.currentBalance.value);

	   if (form.collectamount.value == "") {
	      alert("Please enter the amount.");
	      form.collectamount.focus();
	      return false;
	   } else if (form.collectamount.value <= 0) {
	      alert("Please enter an amount greater than zero.");
	      form.collectamount.focus();
	      return false;
	   } else if((isNaN(form.collectamount.value))) {
	      alert('Please enter a numeric value');
	      form.collectamount.focus();
	      return false;
   	   } else if (collectamount.match(/^[0-9]+(\.\d{1,2})?$/) == null) {
	      alert("Please enter value upto 2 places of decimal.");
	      form.collectamount.focus();
	      return false;
	   } else if (collectamount.match(/^\-?[0-9]+(\.\d{1,2})?$/) == null) {
	      alert("Please enter value upto 2 places of decimal.");
	      form.collectamount.focus();
	      return false;
	   } else if(parseFloat(form.collectamount.value) > parseFloat(currentBalance)) {
	      alert('Please enter amount less than or equal to the current account balance.');
	      form.collectamount.focus();
	      return false;
	   }
	 }

	 if(form.bankroutingno.value == "") {
		 alert("Please enter the bank routing number.");
		 form.bankroutingno.focus();
		 return false;
	 } else if(isNaN(Trim(form.bankroutingno.value))) {
         	alert("Please enter numeric value for bank routing number.");
         	form.bankroutingno.focus();
         	return false;
     	}
     	else if(Trim(form.bankroutingno.value).length != 9) {
         	alert("Bank routing number should comprise of 9 digits.");
         	form.bankroutingno.focus();
         	return false;
     	}


	 if(form.checkingaccno.value == "") {
	 	alert("Please enter the bank account number.");
	 	form.checkingaccno.focus();
	 	return false;
	 }

	if (!form.Submit.clicked) {
	   toggleButton(form.Submit,form);
	}

	return true;
}

/**********************************************************/
/*******This is called from advancepayment.jsp file's ************/
/******* validateSwitchToCCForm Method ********************/
/**********************************************************/

function displayFieldsForDD(thisForm, type)
{

    deleterow();
    if (type == 'e')
    {
	   var newRow0 = document.all.extrarow0;
	   var col0 = (newRow0.insertCell())
	   col0.height = '12';

	   var newRow1 = document.all.param_table_row0;
	   var col1 = (newRow1.insertCell())
	   col1.innerHTML = "<font size=2><b><span class=Required>*</span>&nbsp;Bank Routing Number:&nbsp;&nbsp;</b></font>";
	   col1.align = 'right';
	   (newRow1.insertCell()).innerHTML = "<input type=text size=20 name=bankroutingno maxlength=16>";

	   var newRow2 = document.all.extrarow1;
	   var col2 = (newRow2.insertCell())
	   col2.height = '12';

	   var newRow3 = document.all.param_table_row1;
	   var col3 = (newRow3.insertCell())
	   col3.innerHTML = "<font size=2><b><span class=Required>*</span>&nbsp;Bank Account Number:&nbsp;&nbsp;</b></font>";
	   col3.align = 'right';
	   (newRow3.insertCell()).innerHTML = "<input type=text size=20 name=checkingaccountno maxlength=16>";


	   var newRow5 = document.all.param_table_row2;

	   var col5 = (newRow5.insertCell())
	   col5.innerHTML = "<font size=2><b>Bank Account Type:&nbsp;&nbsp;</b></font>";
	   col5.vAlign='top';
	   col5.align = 'right';

	   (newRow5.insertCell()).innerHTML = "Checking";

   }
}

/**********************************************************/
/*******This is called from function displayFieldsForDD of bws_script.js file ************/
/******* deleterow Method ********************/
/**********************************************************/

function deleterow()
{

    var newRow0 = document.all.extrarow0;
    var numcols0 = document.all.extrarow0.cells.length;
    while(numcols0 != 0)
    {
        newRow0.deleteCell(numcols0-1);
        numcols0 = numcols0 - 1;
    }

    var newRow1 = document.all.param_table_row0;
    var numcols1 = document.all.param_table_row0.cells.length;
    while(numcols1 != 0)
    {
    	newRow1.deleteCell(numcols3-1);
    	numcols1 = numcols1 - 1;
    }

    var newRow2 = document.all.extrarow1;
    var numcols2 = document.all.extrarow1.cells.length;
    while(numcols2 != 0)
    {
            newRow2.deleteCell(numcols2-1);
            numcols2 = numcols2 - 1;
    }

    var newRow3 = document.all.param_table_row1;
    var numcols3 = document.all.param_table_row1.cells.length;
    while(numcols3 != 0)
    {
	newRow3.deleteCell(numcols3-1);
	numcols3 = numcols3 - 1;
    }


    var newRow5 = document.all.param_table_row2;
    var numcols5 = document.all.param_table_row2.cells.length;
    while(numcols5 != 0)
    {
    	newRow5.deleteCell(numcols5-1);
    	numcols5 = numcols5 - 1;
    }

}


/**********************************************************/
/*******This is called from advancepayment.jsp file's ************/
/******* checkAdvancePayment Method ********************/
/**********************************************************/

function checkAdvancePayment(button,form)
{
    var collectamount = Trim(form.collectamount.value);
    var currentBalance = removeComma(form.currentBalance.value);
    var billtype      = form.billtype.value;
     if(form.collectamount.value == '')
     {
       alert('Please enter amount');
       form.collectamount.focus();
       return false;
     }
     else if((isNaN(form.collectamount.value)))
     {
        alert('Please enter a numeric value');
	form.collectamount.focus();
	return false;
     }
     else if ((collectamount.charAt(0)) == '-')
     {
	alert("You cannot pay negative amount.");
	form.collectamount.focus();
	return false;
     }
     else if (collectamount.match(/^[0-9]+(\.\d{1,2})?$/) == null)
     {
	alert("Please enter value upto 2 places of decimal.");
        form.collectamount.focus();
        return false;
     }
     else if (collectamount.match(/^\-?[0-9]+(\.\d{1,2})?$/) == null)
     {
	alert("Please enter value upto 2 places of decimal.");
	form.collectamount.focus();
	return false;
     }
     else if(form.collectamount.value == 0)
     {
	alert("You cannot collect zero amount");
	form.collectamount.focus();
	return false;
     }


     if(billtype == "CC")
     {
        if(form.paymenttype[1].checked)
        {
	   if(Trim(form.bankroutingno.value) == '')
	   {
	     alert('Please enter Bank Routing Number');
	     form.bankroutingno.focus();
	     return false;
	   }else if(isNaN(Trim(form.bankroutingno.value))) {
        	 alert("Please enter numeric value for bank routing number.");
         	form.bankroutingno.focus();
         	return false;
       	   }
       	   else if(Trim(form.bankroutingno.value).length != 9) {
       		alert("Bank routing number should comprise of 9 digits.");
       		form.bankroutingno.focus();
       		return false;
       	  }

	   else if(Trim(form.checkingaccountno.value) == '')
	   {
	     alert('Please enter Bank Account Number');
	     form.checkingaccountno.focus();
	     return false;
	   }
       }
     }else if (billtype == "INV")
     {
     	if(Trim(form.bankroutingno.value) == '')
	{
	   alert('Please enter Bank Routing Number');
	   form.bankroutingno.focus();
	   return false;
	} else if(isNaN(Trim(form.bankroutingno.value))) {
        	 alert("Please enter numeric value for bank routing number.");
         	form.bankroutingno.focus();
         	return false;
       	   }
       	   else if(Trim(form.bankroutingno.value).length != 9) {
       		alert("Bank routing number should comprise of 9 digits.");
       		form.bankroutingno.focus();
       		return false;
       	  }
	else if(Trim(form.checkingaccountno.value) == '')
	{
	   alert('Please enter Bank Account Number');
	   form.checkingaccountno.focus();
	   return false;
	}
     }

     if (!form.Submit.clicked) {
     	   toggleButton(form.Submit,form);
      }

     return true;
}

/**********************************************************/
/*******This is called from viewcorrelatedusage.jsp and viewratedusage.jsp file's ************/
/******* callMethodDivert Method ********************/
/**********************************************************/
function callMethodDivert(form,type)
{
   var month   = form.month.selectedIndex;
   var service = form.service.selectedIndex;
   var site    = form.site.selectedIndex;
   if (month == 0)
	{
          alert('Please select a Month.');
	  return false;
	}
   else if (service ==0)
	{
	  alert('Please select a Service Name.');
	  return false;
	}
   else if (site == 0)
           {
		alert('Please select a Site.');
		return false;
	   }

   if (form.service.value == '/service/ip' && type == 'correlated')
   {
      form.action = "http://usageweb.hughesnet.com/classic/usagequery2_wf_w2m.cfm";
      form.submit();
      return true;
   }
  form.Submit.disabled=true;
  form.submit();
  return true;

}



/**********************************************************/
/*******This is called from downloadcorrelatedusage.jsp and downloadratedusage.jsp file's ************/
/******* downloadUsage Method ********************/
/**********************************************************/
function downloadUsage(form)
{
   var month   = form.month.selectedIndex;
   if (month == 0)
	{
          alert('Please select a Month.');
	  return false;
	}
   return true;

}

/**********************************************************/
/*******This is called from getauditreport.jsp.jsp file's ************/
/******* validateViewAuditTrailInfo Method ********************/
/**********************************************************/
/*
  In 6.6 both DSS login and account number can't be null , either of them or both should be not null
*/
function validateViewAuditTrailInfo(form)
{
   var accountno = Trim(form.accountno.value);
   var login = Trim(form.dssLogin.value);

  if(accountno.length <= 0 && login.length <=0 )
  {
	alert('Please enter account number or DSS Login or Both');
	form.dssLogin.value ='';
	form.accountno.value = '';
	form.dssLogin.focus();
	return false;
  }

  var fromDay = form.fromday.value;
  var fromMM  = form.frommonth.value;
  var fromYY  = form.fromyear.value;

  var toDay   = form.today.value;
  var toMM    = form.tomonth.value;
  var toYY    = form.toyear.value;

  var from_result = validateDate(fromMM, fromDay, fromYY);
  if(from_result == false)
  {
     alert('Please enter a valid From Date');
     return false;
  }

  var to_result = validateDate(toMM, toDay, toYY);
  if(to_result == false)
  {
     alert('Please enter a valid To Date');
     return false;
  }

  if( fromYY > toYY )
  {
     alert('From Date should be smaller than To Date');
     return false;
  }
  else if( fromYY == toYY )
  {

    var mm1 = parseInt(fromMM);
    var mm2 = parseInt(toMM);
   if(fromMM == '08' || fromMM == '09' )
    {
        mm1 = parseInt(fromMM.substring(1,2));

     }
   if(toMM == '08' || toMM == '09' )
    {
          mm2 = parseInt(toMM.substring(1,2));
       }

    if(mm1 > mm2)
    {
      alert('From Date should be smaller than To Date');
      return false;
    }
    else if( mm1 == mm2)
    {
      if(parseInt(fromDay) > parseInt(toDay))
      {
            alert('From Date should be smaller than To Date');
            return false;
      }
    }
  }

  if (!form.Submit.clicked) {
     toggleButton(form.Submit,form);
  }
  return true;

}

/**********************************************************/
/*******This method validates the given date ************/
/******* validateDate Method ********************/
/**********************************************************/

function validateDate(month, day, year)
{

  var isLeapYear = false;

  var yr = parseInt(year);

  if( ( (yr%4 == 0) ) && ( (yr%100 != 0) ) || ( yr%400 == 0 ) )
  {
          isLeapYear = true;
  }

  if(month == '04' || month == '06' || month == '09' || month == '11' )
  {
    if( day == '31')
    {
      return false;
    }
  }
  else if(month == '02')
  {
      if(day == '31' || day == '30')
      {
      	return false;
      }
      else if( (isLeapYear == false) && (day == '29'))
      {
        return false;
      }

  }

  return true;
}

/**********************************************************/
/*******This method validates the Billing Name used in switchtoinvoice & updateifo jsp's************/
/******* invoiceNameCheck Method ********************/
/**********************************************************/
function invoiceNameCheck(nameToCheck)
{
	var nameToSplit = nameToCheck.split(" ");
	var countTokens = 0;
	for(i = 0;i < nameToSplit.length;i++) {
		if (nameToSplit[i] != "")
			countTokens++;
	}
	if (countTokens < 2) {
		alert("Please enter Billing Name either in FirstName LastName \n or in FirstName MiddleName LastName format.");
		return false;
	}
	return true;
}

/*******************************************************************/
/*******This method validates the getcheckreconciliation.jsp ***/
/******* validateGetReconciliation Method **********************/
/******************************************************************/
function validateGetReconciliation(form, buttonType,count) {
  var incr = 0;
  if (count == 1)  {
   		if (!form.radio.checked) {
		  	 alert("Please select a record first.");
  		  	 return false;
  		  }
  }  else if (count > 1) {
  	for (i = 0; i < count ; i++) {
  		if (form.radio[i].checked) {
  			incr++;
  			break;
   	       }
  	}
  	if (incr == 0) {
  		alert("Please select a record first.");
  		return false;
  	}
   }
  if (buttonType == 'a')
	form.requestType.value = "autosearch";
  else if (buttonType == 's')
  	form.requestType.value = "search";
  else{
	var deleteOK = confirm("You want to delete the record. Are you sure ?");
	if(deleteOK == false){
		return false;
	}
	form.requestType.value = "delete";
  }

    //toggleButton(form.AutoSearch,form);
    //toggleButton(form.Search,form);
    //toggleButton(form.Delete,form);
    form.AutoSearch.disabled = true;
    form.Search.disabled = true;
    form.Delete.disabled = true;

  form.submit();
  return true;
}
/******************************************************************************/
/*******This method displays dynamic rows in checkreconciliation.jsp ***/
/******* displayFieldsForSome*********************************************/
/*****************************************************************************/
function displayFieldsForSome(thisForm,type)
{
	removeRowFromTable();
    if (type == 'D')
    {
       removeRowFromTable();
       var newRow0 = document.all.param_table.insertRow();
	   var col0 = (newRow0.insertCell())
	   col0.height = 10;
	   var today = new Date();
	   var year = today.getFullYear();
	   var strYear = "";
	   for(var i = 0 ; i < 10 ; i++)  {
	   	   strYear = strYear + "<option value = " + year + "> " + year + "</option>" ;
	   	   year--;
	   }
	   var newRow1 = document.all.param_table.insertRow();
	   (newRow1.insertCell()).innerHTML = "<div class=sidelabel noWrap>&nbsp;<strong><span class=Required>*</span>&nbsp;Start Date:&nbsp;&nbsp;</strong></div>";

	   (newRow1.insertCell()).innerHTML = "<select name=startday><option value=01>01</option><option value=02>02</option><option value=03>03</option><option value=04>04</option><option value=05>05</option> <option value=06>06</option><option value=07>07</option><option value=08>08</option><option value=09>09</option><option value=10>10</option><option value=11>11</option><option value=12>12</option><option value=13>13</option><option value=14>14</option><option value=15>15</option><option value=16>16</option><option value=17>17</option><option value=18>18</option><option value=19>19</option><option value=20>20</option><option value=21>21</option><option value=22>22</option><option value=23>23</option><option value=24>24</option><option value=25>25</option><option value=26>26</option> <option value=27>27</option><option value=28>28</option><option value=29>29</option><option value=30>30</option><option value=31>31</option></select>";

	   (newRow1.insertCell()).innerHTML = "&nbsp;&nbsp;<select name=startmonth><option value=01>Jan</option><option value=02>Feb</option><option value=03>Mar</option><option value=04>Apr</option><option value=05>May</option><option value=06>Jun</option><option value=07>Jul</option><option value=08>Aug</option><option value=09>Sep</option><option value=10>Oct</option><option value=11>Nov</option><option value=12>Dec</option></select>";

	   (newRow1.insertCell()).innerHTML = "&nbsp;&nbsp;<select name=startyear>" + strYear +  "</select>";
	   (newRow1.insertCell()).innerHTML = "<div class=sidelabel noWrap>&nbsp;&nbsp;&nbsp;&nbsp;<strong><span class=Required>*</span>&nbsp;End Date:&nbsp;&nbsp;</strong></div>";

	   (newRow1.insertCell()).innerHTML = "<select name=endday><option value=01>01</option><option value=02>02</option><option value=03>03</option><option value=04>04</option><option value=05>05</option> <option value=06>06</option><option value=07>07</option><option value=08>08</option><option value=09>09</option><option value=10>10</option><option value=11>11</option><option value=12>12</option><option value=13>13</option><option value=14>14</option><option value=15>15</option><option value=16>16</option><option value=17>17</option><option value=18>18</option><option value=19>19</option>    <option value=20>20</option><option value=21>21</option><option value=22>22</option><option value=23>23</option><option value=24>24</option><option value=25>25</option><option value=26>26</option> <option value=27>27</option><option value=28>28</option><option value=29>29</option><option value=30>30</option><option value=31>31</option></select>";

	   (newRow1.insertCell()).innerHTML = "&nbsp;&nbsp;<select name=endmonth><option value=01>Jan</option><option value=02>Feb</option><option value=03>Mar</option><option value=04>Apr</option><option value=05>May</option><option value=06>Jun</option><option value=07>Jul</option><option value=08>Aug</option><option value=09>Sep</option><option value=10>Oct</option><option value=11>Nov</option><option value=12>Dec</option></select>";

	   (newRow1.insertCell()).innerHTML = "&nbsp;&nbsp;<select name=endyear>" + strYear +  "</select>";

   }
  if (type != 'D' && type != 'A') {
		removeRowFromTable();
		var newRow0 = document.all.param_table.insertRow();
		var col0 = (newRow0.insertCell())
		col0.height = 10;

		var newRow1 = document.all.param_table.insertRow();
		(newRow1.insertCell()).innerHTML = "<div class=sidelabel noWrap>&nbsp;<strong><span class=Required>*</span>&nbsp;Search:&nbsp;&nbsp;</strong></div>";
		(newRow1.insertCell()).innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=text size=20 name=queryString maxlength=16>";
	}

}
/******************************************************************************/
/*******This method removes dynamic rows in checkreconciliation.jsp ***/
/******* removeRowFromTable*********************************************/
/******************************************************************************/
function removeRowFromTable()
{
	var tbl = document.getElementById('param_table');
	var lastRow = tbl.rows.length;
	if (lastRow > 1) tbl.deleteRow(lastRow - 1);
}

/******************************************************************************/
/*******This method validates checkreconciliation.jsp *********************/
/******* validateCheckReconciliation***************************************/
/******************************************************************************/
function validateCheckReconciliation(form) {
  if (form.SELECTTYPE[1].checked) {
    var boolean = validateDate(form.startmonth.value,form.startday.value,form.startyear.value);
    if (!boolean) {
    	alert("Please correct the start date.");
    	return false;
    }
    boolean = validateDate(form.endmonth.value,form.endday.value,form.endyear.value);
    if (!boolean) {
    	alert("Please correct the end date.");
     	return false;
    }
    if (form.startyear.value > form.endyear.value ) {
       	alert("Start year cannot be greater than end year.");
       	return false;
    } else if ((form.startyear.value == form.endyear.value)
    		 && (form.startmonth.value > form.endmonth.value ) ) {
    	   alert("Start month cannot be greater than end month.");
       	   return false;
    } else if ((form.startmonth.value == form.endmonth.value )
       	         && (form.startday.value > form.endday.value ) ) {
       	   alert("Start day cannot be greater than end day.");
       	   return false;
    }
   } else if ((form.SELECTTYPE[2].checked)
   			|| (form.SELECTTYPE[3].checked)
   			|| (form.SELECTTYPE[4].checked)) {
   	 var originalStringValue = form.queryString.value;
   	 var trimmedStringValue = Trim(form.queryString.value);
	 if (originalStringValue.length ==  0 )
	 {
	 	alert("Please enter the search criteria.");
		form.queryString.focus();
		return false;
	}else if(originalStringValue.length != 0){
		if (trimmedStringValue.length == 0 )
		{
			alert("Only spaces in search is not allowed.");
			form.queryString.value = "";
			form.queryString.focus();
			return false;
		}
	}
}

toggleButton(form.Submit,form);
return true;
}

/******************************************************************************/
/*******This method validates autoreconciliation.jsp *********************/
/******* validateAutoReconciliation*****************************************/
/******************************************************************************/
function validateAutoReconciliation(form,buttonType) {
	 if (buttonType == 'r')
    		form.requestType.value = "reprocess";
    	 else if (buttonType == 'b')
    	 	form.requestType.value = "back";
    	 else if (buttonType == 'm') {
    	 	if  ((form.status.value == "No Match" ) || (form.status.value.length==0 ||
  		 				form.status.value==null))
    	 		form.requestType.value = "search";
    	 	else
    	 	       form.requestType.value = "modify";
    	 }

	//toggleButton(form.Modify,form);
	//toggleButton(form.Reprocess,form);
	//toggleButton(form.Back,form);
	form.Modify.disabled = true;
	form.Reprocess.disabled = true;
	form.Back.disabled = true;

 	form.submit();
	return true;
}

/******************************************************************************/
/*******This method validates modifycheckpaymentdetails.jsp *********************/
/******* validateModifyCheckPaymentDetails*****************************************/
/******************************************************************************/
function validateModifyCheckPaymentDetails(form,buttonType) {
	
    if (buttonType == 'r')
    {
    		form.chkAmt.value = removeComma(form.chkAmt.value);
		if(Trim(form.chkAmt.value).length == 0){
			alert("Please enter numeric value for check amount.");
			form.chkAmt.focus();
			return false;
		}
		if (isNaN(form.chkAmt.value)) {
			alert("Please enter numeric value for check amount.");
			return false;
		}
		if(form.chkAmt.value <0){
			alert("Check amount cannot be a negative amount.");
			form.chkAmt.focus();
			return false;
		}else if(form.chkAmt.value == 0){
			alert("Check amount cannot be zero.");
			form.chkAmt.focus();
			return false;
		}

		if(Trim(form.checkNo.value).length == 0){
			alert("Please enter check number.");
			form.checkNo.focus();
			return false;
		}

		if(form.checkNo.value == 0){
			alert("Check number cannot be zero.");
			form.checkNo.focus();
			return false;
		}

		form.requestType.value = "reprocess";
    }
    else if (buttonType == 'b')
    	 	form.requestType.value = "back";

   //toggleButton(form.Reprocess,form);
   form.Reprocess.disabled = true;
   //toggleButton(form.Back,form);
   form.Back.disabled = true;

   form.submit();
   return true;
}

/******************************************************************************/
/*******This method validates manualreconciliation.jsp *********************/
/******* validateManualReconciliation*****************************************/
/******************************************************************************/
function validateManualReconciliation(form,buttonType) {
	if (buttonType == 's')
	{
		form.requestType.value = "manualsearch";
		if (form.queryString.value == null)
		{
			alert("Please enter the search criteria");
			form.queryString.focus();
			return false;
		}else
		{
			var originalQueryStringValue =  form.queryString.value;
			var trimmedQueryStringValue =  Trim(form.queryString.value);
			var str;
			for (var i = 0; i < form.queryType.length; i++) {
				if (form.queryType[i].checked) {
					str = Trim(form.queryType[i].value);
					break;
				}
			}
			if (originalQueryStringValue.length == 0 )
			{
				alert("Please enter the search criteria.");
				form.queryString.focus();
				return false;
			}else if(originalQueryStringValue.length != 0){
				if (trimmedQueryStringValue.length == 0 )
				{
					alert("Only spaces in search is not allowed.");
					form.queryString.focus();
					return false;
				}
			}
			if(str == "Name"){
				if(InvalidLastFirstNameCheckManualReconciliation(originalQueryStringValue)){
				    form.queryString.focus();
		        	    return false;
				}

			}else if(str == "InvoiceNumber"){
				if(form.queryString.value.substring(0,3) != "B1-"){
					alert("Invoice number must start with B1-");
					form.queryString.focus();
					return false;
				}
			}
		}
	}else if (buttonType == 'b')
    		form.requestType.value = "back";

   	toggleButton(form.Submit,form);
   	toggleButton(form.Back,form);
   //form.submit();
   return true;
}


function InvalidLastFirstNameCheckManualReconciliation(nameToCheck)
{
	var firstAlphabet = nameToCheck.charAt(0);
	var blankFlag = false;
	if (!(firstAlphabet >= 'a' && firstAlphabet <= 'z') && !(firstAlphabet >= 'A' && firstAlphabet <= 'Z'))
	{
		alert('Last Name should start with an alphabet.');
		return true;
	 }
	 for (var i=1; i < nameToCheck.length; i++) {
		var name = nameToCheck.charAt(i);
	        if (!(name >= 'a' && name <= 'z') && !(name >= 'A' && name <= 'Z')
			 && !(name == ',') && !(name=='-') && !(name=='\'') && !(name==' ') && !(name >= '0' && name <= '9')) {
			alert('Last Name / First Name contains invalid characters.');
			return true;
	  	}
		if(blankFlag == false){
			if(name == ' '){
				blankFlag = true;
			}
		}else{
			if(name == ' '){
				alert('Please check the format for name search');
				return true;
			}
		}
    	}

	var spaceIndex = nameToCheck.indexOf(" ");

	if(spaceIndex == -1){
		alert('Please enter both last and first name.\nEach name should have at least one letter. ');
		return true;
	}else{
		var lastName = nameToCheck.substring(0,spaceIndex );
		var firstName = nameToCheck.substring(spaceIndex+1 );
		if(Trim(firstName).length == 0){
			alert('Please enter both last and first name.\nEach name should have at least one letter. ');
			return true;
		}
		var spaceIndex = firstName.indexOf(" ");
		if(spaceIndex!=-1){
			alert('Please check the format for name search.');
			return true;
		}


	}
    return false;
}

function checkServiceAdjustments(form,val)
{	
	if(nonMonetaryFlag && (document.getElementById("NonMonCredit").checked || document.getElementById("NonMonCreditOverride").checked ) )
	{
		if (form.nonMonMonths.selectedIndex == 0) {
		    alert('Please select months.');
		    return (false);
		 }

		if (form.nonMonAmount.selectedIndex == 0) {
		    alert('Please select amount.');
		    return (false);
		 }
		if (form.NONMONSERVICEADJUSTREASON.selectedIndex == 0) {
			alert('Please select a reason.');
			return (false);
		 }
	    if (form.CRMID.value == "") {
			alert('Please enter the CRM Reference No.');
			return (false);
	     }
		 
		if(document.getElementById("NonMonCredit").checked)
			form.reqType.value='applyNonMonetoryDiscount';
			
		if(document.getElementById("NonMonCreditOverride").checked) 
		form.reqType.value='NonMonCreditOverride';
		
	    var val = form.Submit.disabled;

		if (val){
	   	   	return false;
	   	}
		else
	   	{
	   	   	form.Submit.disabled = true;
	   	   	return true;
        }
	}     

	if (val == 1)
	{
	if (!(form.CreditPeriodDays.checked || form.CreditPeriodWeeks.checked
				   || form.CreditPeriodMonths.checked)) {
	alert("Please select any of the MONTHS|WEEKS|DAYS option.")
	return false;
	}
	if (form.CreditPeriodDays.checked) {
		 if (form.DAYS.selectedIndex == 0) {
		    alert('Please select a day.');
		    return (false);
		 }
	   }
	   if (form.CreditPeriodWeeks.checked) {
		if (form.WEEKS.selectedIndex == 0) {
		    alert('Please select a week.');
		    return (false);
		 }
	   }
	   if (form.CreditPeriodMonths.checked) {
		 if (form.MONTHS.selectedIndex == 0) {
		    alert('Please select a month.');
		    return (false);
		 }
	   }

	   if (!form.CreditPeriodMonths.checked && form.MONTHS.selectedIndex != 0) {
	   	alert('Please check the MONTH option.');
	   	return (false);
	   }

	   if (!form.CreditPeriodWeeks.checked && form.WEEKS.selectedIndex != 0) {
	   	alert('Please check the WEEKS option.');
	   	return (false);
	   }

	   if (!form.CreditPeriodDays.checked && form.DAYS.selectedIndex != 0) {
	   	alert('Please check the DAYS option.');
	   	return (false);
	   }

	   if (form.SERVICEADJUSTREASON.selectedIndex == 0) {
		alert('Please select a reason.');
		return (false);
	   }
	   if (Trim(form.CRMID.value) == '') {
		alert('Please enter the CRM Reference No.');
		return (false);
	   }
	   form.reqType.value='showCreditAmount';

	   var val = form.Submit.disabled;

	   if (val){
	   	   	return false;
	   	}
	   else
	   	{
	   	   	form.Submit.disabled = true;
	   	   	return true;
         	}

	} else if (val == 2) {

	form.reqType.value='applyServiceAdjustments';
	form.cancel.disabled=true;
	form.apply.disabled=true;
	form.submit();
	return true;

	} else if (val == 3) {
	form.reqType.value='cancelServiceAdjustments';
	form.cancel.disabled=true;
	form.apply.disabled=true;
	form.submit();
	return true;
	}
	else if (val == 4) {

	form.reqType.value='applyComplimentaryDiscount';
	form.cancel.disabled=true;
	form.apply.disabled=true;
	form.submit();
	return true;

	}
	else if (val == 5) {

	form.reqType.value='applyComplimentaryDiscountOverride';
	form.cancel.disabled=true;
	form.apply.disabled=true;
	form.submit();
	return true;

	}

    //return true;

}


function validateGenerateReportForm(form) {

        var sd = form.startDate.value;
        var ed = form.endDate.value;
        if ( sd == "") {
                        alert("Please enter Start Date.");
                        return false;
        }
        if ( ed == "") {
                        alert("Please enter End Date.");
                        return false;
        }

	if(Date.parse(sd) > Date.parse(ed)) {	// this works for the date in MM/DD/YYYY format
			alert('Start Date is more than End Date');
	        	return false;
	}

	var Date1 = new Date(Date.parse(sd));
	var Date2 = new Date(Date.parse(ed));

	var timeDifference = Date2.getTime() - Date1.getTime();
	var daysDifference = Math.floor(timeDifference/1000/60/60/24);

	if (daysDifference > 6) {	// daydiffence = 6 means 1 week(7 day) report i.e. Day1-Day7
	        	alert('Report cannot be generated for more than 7 days.');
	        	return false;
        }

	var val = form.Submit.disabled;

	if (val){
		        return false;
		}
		else
		{
		        form.Submit.disabled = true;
		        return true;
         	}

}


function submitGenerateReportResultForm( form,val)
{
  if( val == 1)
  {
    form.reportOperation.value="recalculate";

    for(i = 0; i < form.categoryNotInDB.value; i++)

    {
    	var churn = "churn" + i;
    	var endSub = "endSub" + i;

    	if(isNaN(document.generatereport.elements[churn].value))
    	{
    	  alert("Please enter a numeric value");
    	  document.generatereport.elements[churn].focus();
    	  document.generatereport.elements[churn].select();
    	  return false;
    	}
    	if(isNaN(document.generatereport.elements[endSub].value))
	{
	  alert("Please enter a numeric value");
	  document.generatereport.elements[endSub].focus();
	  document.generatereport.elements[endSub].select();
	  return false;
    	}
   }

  }
  else if( val == 2)
  {
    form.reportOperation.value="save";
  }
  else if( val == 3)
  {
    form.reportOperation.value="release";
  }
  else if( val == 4)
  {
    form.reportOperation.value="downloadReport";
  }
form.submit();
}


function validateSpinReportForm(form) {

        var sd = form.StartDate.value;
        var ed = form.EndDate.value;
        if ( sd == "") {
                        alert("Please enter Start Date.");
                        return false;
        }
        if ( ed == "") {
                        alert("Please enter End Date.");
                        return false;
        }

	if(Date.parse(sd) > Date.parse(ed)) {	// this works for the date in MM/DD/YYYY format
			alert('Start Date should be less than End Date');
	        	return false;
	}

	var val = form.Submit.disabled;

	if (val){
		        return false;
		}
		else
		{
		        form.Submit.disabled = true;
		        form.submit();
		        return true;
         	}
}


function redirect(x)  {

var groups=3;
var group=new Array(groups);

for (i=0; i<groups; i++)
group[i]=new Array()

group[0][0]=new Option("Select One","")

group[1][0]=new Option ("Select One","")
group[1][1]=new Option ("Alabama","AL")
group[1][2]=new Option ("Alaska","AK")
group[1][3]=new Option ("American Samoa","AS")
group[1][4]=new Option ("Arizona","AZ")
group[1][5]=new Option ("Arkansas","AR")
group[1][6]=new Option ("California","CA")
group[1][7]=new Option ("Colorado","CO")
group[1][8]=new Option ("Connecticut","CT")
group[1][9]=new Option ("Delaware","DE")
group[1][10]=new Option ("District of Columbia","DC")
group[1][11]=new Option ("Federated States of Micronesia","FM")
group[1][12]=new Option("Florida","FL")
group[1][13]=new Option("Georgia","GA")
group[1][14]=new Option("Guam","GU")
group[1][15]=new Option("Hawaii","HI")
group[1][16]=new Option("ldaho","ID")
group[1][17]=new Option("illinois","IL")
group[1][18]=new Option("Indiana","IN")
group[1][19]=new Option("Iowa","IA")
group[1][20]=new Option("Kansas","KS")
group[1][21]=new Option("Kentucky","KY")
group[1][22]=new Option("Louisiana","LA")
group[1][23]=new Option("Maine","ME")
group[1][24]=new Option("Marshall Islands","MH")
group[1][25]=new Option("Maryland","MD")
group[1][26]=new Option("Massachusetts","MA")
group[1][27]=new Option("Michigan","MI")
group[1][28]=new Option("Minnesota","MN")
group[1][29]=new Option("Mississippi","MS")
group[1][30]=new Option("Missouri","MO")
group[1][31]=new Option("Montana","MT")
group[1][32]=new Option("Nebraska","NE")
group[1][33]=new Option("Nevada","NV")
group[1][34]=new Option("New Hampshire","NH")
group[1][35]=new Option("New Jersey","NJ")
group[1][36]=new Option("New Mexico","NM")
group[1][37]=new Option("NewYork","NY")
group[1][38]=new Option("North Carolina","NC")
group[1][39]=new Option("North Dakota","ND")
group[1][40]=new Option("Nothern Mariana Islands","MP")
group[1][41]=new Option("Ohio","OH")
group[1][42]=new Option("Oklahoma","OK")
group[1][43]=new Option("Oregon","OR")
group[1][44]=new Option("Palau","PW")
group[1][45]=new Option("Pennsylvania","PA")
group[1][46]=new Option("Puerto Rico","PR")
group[1][47]=new Option("Rhode Island","RI")
group[1][48]=new Option("South Carolina","SC")
group[1][49]=new Option("South Dakota","SD")
group[1][50]=new Option("Tennessee","TN")
group[1][51]=new Option("Texas","TX")
group[1][52]=new Option("Utah","UT")
group[1][53]=new Option("Vermont","VT")
group[1][54]=new Option("Virginia","VA")
group[1][55]=new Option("Virgin Islands","VI")
group[1][56]=new Option("Washington","WA")
group[1][57]=new Option("West Virginia","WV")
group[1][58]=new Option("Wisconsin","WI")
group[1][59]=new Option("Wyoming","WY")

group[2][0]=new Option("Select One","")
group[2][1]=new Option("Alberta","AB")
group[2][2]=new Option("British Columbia","BC")
group[2][3]=new Option("Manitoba","MB")
group[2][4]=new Option("New Brunswick","NB")
group[2][5]=new Option("Newfoundland","NL")
group[2][6]=new Option("Northwest Territories","NT")
group[2][7]=new Option("Nova Scotia","NS")
group[2][8]=new Option("Ontario","ON")
group[2][9]=new Option("Prince Edward Island","PE")
group[2][10]=new Option("Quebec","QC")
group[2][11]=new Option("Saskatchewan","SK")
group[2][12]=new Option("Yukon","YT")


	var temp=document.search.state;
	for (m=temp.options.length-1;m>0;m--)
	temp.options[m]=null;
	for (i=0;i<group[x].length;i++){
		temp.options[i]=new Option(group[x][i].text,group[x][i].value);
	}
	temp.options[0].selected=true;
}

function isValid(checkStr)
{
	var invalidChars = "|,\":\';`~!@#$%^&()+=[]{}<>";

   	for (var i = 0; i < checkStr.length; i++) {
   	   if (invalidChars.indexOf(checkStr.charAt(i)) != -1)
   	      return false;
   	}
   	return true;
}

function checkAlphaWild(validStr) {

        checkOk = " *ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        checkStr = validStr;
        allValid = true;

        for (i=0; i<checkStr.length; i++) {
            ch = checkStr.charAt(i);
            for (j=0; j<checkOk.length; j++)
                if (ch == checkOk.charAt(j))
                   break;

                if (j == checkOk.length) {
                   allValid = false;
                   break;
                 }
        }

        if (!allValid)
        	return false;
        else
        	return true;
}


function validatenewsearch1(form)
{

	if (Trim(form.accountNumber.value) == "" || Trim(form.accountNumber.value) == "*")
	 if (form.country.value == "")
	  if (form.state.value == "")
	   if (Trim(form.city.value) == "" || Trim(form.city.value) == "*")
	    if (Trim(form.zip.value) == "" || Trim(form.zip.value) == "*")
	     if (Trim(form.fName.value) == "" || Trim(form.fName.value) == "*")
	      if (Trim(form.lName.value) == "" || Trim(form.lName.value) == "*")
	       if (Trim(form.company.value) == "" || Trim(form.company.value) == "*")
				{
					alert("Please enter Search Criteria");
					return false;
				}


	 if(Trim(form.accountNumber.value) != "")
	 	{
	 		if(!isValid(form.accountNumber.value))
	         	{
	         		alert('Account Number contains Invalid characters. Please re-enter.');
	         		form.accountNumber.focus();
	         		form.accountNumber.select();
	 	        	return false;
	         	}
	         }


	 if(Trim(form.fName.value) != "")
	 	{
	 		if(!checkAlphaWild(form.fName.value))
	 		{
	 			alert('First Name contains Invalid characters. Please re-enter.');
	 			form.fName.focus();
	 			form.fName.select();
	 	        	return false;
	 		}
        	}

        if(Trim(form.lName.value) != "")
		{
			if(!checkAlphaWild(form.lName.value))
			{
				alert('Last Name contains Invalid characters. Please re-enter.');
				form.lName.focus();
				form.lName.select();
				return false;
			}
		}

	 if(Trim(form.city.value) != "")
	 	{
	 		if(!checkAlphaWild(form.city.value))
	         	{
	         		alert('City Name contains Invalid characters. Please re-enter.');
	         		form.city.focus();
	         		form.city.select();
	 	        	return false;
	         	}
	         }


	 if(Trim(form.zip.value) != "")
	 	{
	 		if(!isValid(form.zip.value))
	 		{
	 			alert('ZipCode contains Invalid characters. Please re-enter.');
	 			form.zip.focus();
	 			form.zip.select();
	 	        	return false;
	 		}
        }

   	 if(Trim(form.company.value) != "")
 	 	{
 	 		if(!checkAlphaWild(form.company.value))
 	 		{
 	 			alert('Company Name contains Invalid characters. Please re-enter.');
 	 			form.company.focus();
 	 			form.company.select();
 	 	        	return false;
 	 		}
        }
		

  form.submit();
  form.Submit.disabled = true;
}

/*******************************************************************************/
/*Functions added for phone format by Neeti Sharma*/
/*These convert the 3 supported formats to the XXX-XXX-XXXX format*/
/*******************************************************************************/

function replace(string,text,by)
{
    // Replaces text with by in string
    var strLength = string.length, txtLength = text.length;
    if ((strLength == 0) || (txtLength == 0)) return string;

    var i = string.indexOf(text);
    if ((!i) && (text != string.substring(0,txtLength))) return string;
    if (i == -1) return string;

    var newstr = string.substring(0,i) + by;

    if (i+txtLength < strLength)
        newstr += replace(string.substring(i+txtLength,strLength),text,by);
    return newstr;
}

function insertNthChar(string,chr,nth)
{
  var output = '';
  for (var i=0; i<string.length; i++)
  {
    if (i>0 && i%3 == 0 && i<7)
      output += chr;
    output += string.charAt(i);
  }
  return output;
}

/***********************************Added functions end here********************************************/

/********************************* Function added for Search ******************************************/
function validatenewsearch2(form)
{
	if(form.searchParameter.value == "")
	{
		alert("Please enter your search query.");
		form.searchParameter.value = "";
		form.searchParameter.focus();
		return false;
    }

	var str;
	for (var i = 0; i < form.queryField.length; i++) {
	if (form.queryField[i].checked) {
		str = form.queryField[i].value;
		break;
		}
	}


	if (str == "AccountNo")
	{
		if(!checkAlphaNumericUnderScore(form.searchParameter.value))
		{
			alert('HughesNet Login contains Invalid characters. Please re-enter.');
			form.searchParameter.focus();
			form.searchParameter.select();
			return false;
		}
	}
	else if (str == "SiteID")
	{
		if(!checkAlphaNumeric(form.searchParameter.value))
		{
			alert('SiteID contains Invalid characters. Please re-enter.');
			form.searchParameter.focus();
			form.searchParameter.select();
			return false;
		}
	}
	else if (str == "SerialNumber")
	{
		if(!checkAlphaNumeric(form.searchParameter.value))
		{
			alert('SerialNumber contains Invalid characters. Please re-enter.');
			form.searchParameter.focus();
			form.searchParameter.select();
			return false;
		}
	}
	else if (str == "CreditCard")
	{
		if (form.searchParameter.value.match(/^\d{15,16}$/) == null)
		{
			alert("The length of the Credit/Debit Card Number is not correct. Please try again.");
			form.searchParameter.focus();
			form.searchParameter.select();
			return false;
		}
		if(!checkCC(form.searchParameter.value))
                {
			alert('Credit Card Number is Invalid. Please re-enter.');
			form.searchParameter.focus();
			form.searchParameter.select();
			return false;
		}
	}
	else if (str == "Phone")
	{
         if( checkPhoneNumbers(form.searchParameter,"Home Phone Number ")==false)
         {
          return false;
         }
         else
         {
           var phoneOutput = form.searchParameter.value;
           var phoneInput = form.searchParameter.value;

                var name = phoneInput.charAt(3);
                if (name == '-')
                {
                  phoneOutput = phoneInput;
                  form.searchParameter.value = phoneOutput;
                }
                else if (name == ' ')
                {
                  phoneOutput = replace(phoneInput,' ' ,'-');
                  form.searchParameter.value = phoneOutput;
                }
                else
                {
                  phoneOutput = insertNthChar(phoneInput,'-',3);
                  form.searchParameter.value = phoneOutput;
                }
         }
    }
	else if(str == "InvoiceNo")
    {
    	if(!checkAlphaNumericHyphen(Trim(form.searchParameter.value)))
	    {
	    	alert('Invoice Number contains Invalid characters. Allowed characters are Alphanumerics(0-9,A-Z,a-z) and Hyphen(-). Please re-enter.');
	    	form.searchParameter.focus();
	    	form.searchParameter.select();
	 	   	return false;
	    }	
    }
	else if(str == "HNSLocationID") {
		if(!checkAlphaNumeric(form.searchParameter.value))
		{
			alert('HNS Location Id contains Invalid characters. Please re-enter.');
			form.searchParameter.focus();
			form.searchParameter.select();
			return false;
		}
	} else if(str == "CustLocationID") {
		if( Trim(form.searchParameter.value) == "*" ) {
			alert("Please enter Search Criteria.");
			return false;
		}
		if(!isValid(Trim(form.searchParameter.value)))
		{
			alert('Customer Location Id contains Invalid characters. Please re-enter.');
			form.searchParameter.focus();
			form.searchParameter.select();
			return false;
		}
	}
  form.submit();
  form.Submit.disabled = true;
  return true;

}
/********************************* Functions ended for Search ******************************************/


/**************************************************************************/
/**********   Added for UpdateCCinfo.jsp (Start)***************************/
/**************************************************************************/

  function setReasonCode(form) {
                        var selectedAccStatusIndex = form.accountStatus.selectedIndex;
                        if (selectedAccStatusIndex == 0) {
                                form.statusReason.length = 0;
                                for (var i = 0; i < activeReasonCodes.length; i++) {
                                        form.statusReason.options[i] = new Option(activeReasonMessages[i], activeReasonCodes[i]);
                                }
                        }
                        if (selectedAccStatusIndex == 1) {
                                form.statusReason.length = 0;
                                for (var i = 0; i < inactiveReasonCodes.length; i++) {
                                        form.statusReason.options[i] = new Option(inactiveReasonMessages[i], inactiveReasonCodes[i]);
                                }
                        }
                        if (selectedAccStatusIndex == 2) {
                                form.statusReason.length = 0;
                                for (var i = 0; i < closedReasonCodes.length; i++) {
                                        form.statusReason.options[i] = new Option(closedReasonMessages[i], closedReasonCodes[i]);
                                }
                        }
                }

function deleterow()
        {
            numrows = document.all.param_table.rows.length;
            while (numrows != 0)
            {
                param_table.deleteRow(numrows-1);
                numrows = numrows - 1;
            }
        }



/**************************************************************************/
/**********   Added for UpdateCCinfo.jsp (END)***************************/
/**************************************************************************/

/**************************************************************************/
/**********   Added for viewUpdateInvoiceInfo.jsp (Start)*********************/
/**************************************************************************/


/**************************************************************************/
/**********   Added for viewUpdateInvoiceInfo.jsp (END)*********************/
/**************************************************************************/
/**************************************************************************/
/**********   Added for termsConditions.jsp (start)*********************/
/**************************************************************************/


  /**************************************************************************/
  /**********   Added for termsConditions.jsp (END)*********************/
/**************************************************************************/


/********************Added for first name last name check************************/
function LastFirstNameCheck(nameToCheck)
{
	var firstAlphabet = nameToCheck.charAt(0);
	var blankFlag = false;
	if (!(firstAlphabet >= 'a' && firstAlphabet <= 'z') && !(firstAlphabet >= 'A' && firstAlphabet <= 'Z'))
	{
		alert("First Name should start with an alphabet.");
		return true;
	 }
	 for (var i=1; i < nameToCheck.length; i++) {
		var name = nameToCheck.charAt(i);
	        if (!(name >= 'a' && name <= 'z') && !(name >= 'A' && name <= 'Z')
			 && !(name == ',') && !(name=='-') && !(name >= '0' && name <= '9')  && !(name=='\'') && !(name==' ')) {
			alert("First Name / Last Name contains invalid characters.");
			return true;
	  	}
		    	}

	var spaceIndex = nameToCheck.indexOf(" ");

	if(spaceIndex == -1){
		alert("Please enter both first and last name.");
		return true;
	}else{
		var lastName = nameToCheck.substring(0,spaceIndex );
		var firstName = nameToCheck.substring(spaceIndex+1 );
		if(Trim(firstName).length == 0){
			alert("Please enter both first and last name.");
			return true;
		}
	}
    return false;
}

function allcheck(form) { // this function is used in UnconfirmedTransactionSearchResult.jsp, addVarResiduals.jsp and modifyVarAccount.jsp

if(form.elements['tbrwcheckbox'])
{
	if(form.tbhdcheckbox.checked){
		if (form.tbrwcheckbox.length) {
			for(i=0; i < form.tbrwcheckbox.length;i++)
				form.tbrwcheckbox[i].checked=true;
		} else {
			form.tbrwcheckbox.checked=true;
		}
	} else {           
		if (form.tbrwcheckbox.length) {
        		for(i=0; i < form.tbrwcheckbox.length;i++)
  		    		form.tbrwcheckbox[i].checked=false;
  		} else {
  			form.tbrwcheckbox.checked=false;
  		}
  	}
}
  return true;
}
  
function chkDeleteRow(form){

	if(form.elements['tbrwcheckbox'])
	{
		var checklen=document.all.tbrwcheckbox.length;
		if (checklen) {
			for(i = checklen-1; i >= 0;i--)
			{
				if(form.tbrwcheckbox[i].checked == true){
					deleteRow(form);
					return true;
				}
			}
		} else {
			if(form.tbrwcheckbox.checked == true){
				tbr = document.getElementById('residualTable');
            			tbr.deleteRow(1);
            			form.tableLen.value = form.tableLen.value - 1;
            			form.Submit.disabled=true;
            			return true;
			}
		}
	}
	return true;
}

function deleteRow(form)
{
	var tbl = document.getElementById('residualTable');
	var lastRow = tbl.rows.length - 1;
	for (i=lastRow-1; i >= 0;i--)
  	{
      		if(form.tbrwcheckbox[i].checked == true){
  			tbr = document.getElementById('residualTable');
        		tbr.deleteRow(i+1);
        		form.tableLen.value = form.tableLen.value - 1;
        	}
  	}
  	
  	
  	if (parseInt(form.tableLen.value) < 1) {
  		form.Submit.disabled=true;
  	} else {
  		form.Submit.disabled=false;
  	}
  	return true;
  }

  function addRow(form)
    {
     
      var newRow = document.all.residualTable.insertRow();
     
        inputTextBoxCount = form.maxCounter.value;
     
          
      var col1 = (newRow.insertCell(0));            
      col1.innerHTML = '<TD align="right" width="5%" class="TableHead"><div align="center"><B><font face="Arial, Times, serif" size="3" ><input type="checkbox" size="3" name="tbrwcheckbox"></font> </B></div></TD>';
           
         // to insert input text boxes in 3 columns of new row
         
         for(i=1 ;i <= 3; i++){
         
           var col = (newRow.insertCell(i));
           var inputTextName = NAME_PREFIX[i-1] + inputTextBoxCount;
           var txtInp = document.createElement('input');
           txtInp.setAttribute('type', 'text');
           txtInp.setAttribute('name', inputTextName);
           txtInp.setAttribute('id', inputTextName);
           txtInp.style.cssText = 'border-style: solid; border-color: #ffffcc;padding-left:11ex;';
           txtInp.setAttribute('size', '27');
           txtInp.setAttribute('className', 'TableOddRowBG');
           col.appendChild(txtInp);
         
         }
  
     form.maxCounter.value = parseInt(inputTextBoxCount) + 1;
     
     var tableLength = form.tableLen.value;
     
     form.tableLen.value = parseInt(tableLength) + 1; 
     
     if (parseInt(form.tableLen.value) < 1) {
	form.Submit.disabled=true;
     } else {
	form.Submit.disabled=false;
     }     
    
 } 
 

 
 function validateThresholdRules(form,type){
 
 
      var sd = form.sdate.value;
      var ed = form.edate.value;
      if (sd != "" && ed != "") {
   		if(Date.parse(sd) > Date.parse(ed)) {	// this works for the date in MM/DD/YYYY format
   			alert('Start Date should be less than End Date.');
   	        	return false;
   		}
	}
 
 

     var tbl = document.getElementById('residualTable');
     var count = 0;
     var index;
     
       for(j=0; j < form.maxCounter.value ; j++){
      
            var thresholdStart = document.getElementById('TS' + j);
            var thresholdEnd = document.getElementById('TE' + j);
            var thresholdPer = document.getElementById('TD' + j);
            
            
             if(thresholdStart != null && thresholdEnd != null && thresholdPer != null) {
             
			   if (thresholdStart.value.length <= 0) {
			   alert('Please enter Threshold Range Start.'); thresholdStart.focus(); return false;}

			   else if(thresholdStart.value < 0){
			   alert('Please enter Positive Threshold Range Start.'); thresholdStart.focus(); thresholdStart.select(); return false;}

			   else if(thresholdStart.value.match(/[^0-9]/)){
			   alert('Please enter integral value for Threshold Range Start.'); thresholdStart.focus(); thresholdStart.select(); return false;}
		  

			   if(thresholdEnd.value.length <= 0) { count++; index=j;
			   //alert('Enter Threshold Range End'); thresholdEnd.focus(); return false;
			   }
			   
			   

			   else if(thresholdEnd.value < 0  ){
			   alert('Please enter Positive Threshold Range End.'); thresholdEnd.focus(); thresholdEnd.select(); return false;}

			   else if(thresholdEnd.value.match(/[^0-9]/)){
			   alert('Please enter integral value for Threshold Range End.'); thresholdEnd.focus(); thresholdEnd.select(); return false;}

                    

			   if(thresholdPer.value.length <= 0) {
			   alert('Please enter Residual Percentage(%).'); thresholdPer.focus(); return false;} 

			   else if(thresholdPer.value < 0){
			  alert('Please enter Positive Residual Percentage(%).'); thresholdPer.focus(); thresholdPer.select(); return false;}

			  else if(isNaN(thresholdPer.value)){
			   alert('Please enter numeric value for Residual Percentage(%).'  ); thresholdPer.focus(); thresholdPer.select(); return false;}

			   else if(!(thresholdPer.value >= 0 && thresholdPer.value <= 100)) {
						  alert('Residual Percentage(%) range should be 0-100.');           
						  thresholdPer.focus();
						  thresholdPer.select();
						  return false; }

			  else if(!thresholdPer.value.match(/^[0-9]+(\.\d{1,2})?$/) == null){
						  alert('Residual Percentage(%) range can have upto 2 decimal places.');           
						  thresholdPer.focus();
						  thresholdPer.select();
						  return false; }
 		                          
             } // end of null check of input boxes
    }// end of j loop
    if(count != 1){
    alert("Please ensure that one and only one Threshold Range End is Blank.");
    return false;
    } else {
    	(document.getElementById('TE' + index)).value="-1";
    }
    return true;
  }
 

 
/**************************************************************************/
  /**********   Added for Paymentech Payments's jsp (START)*********************/
/**************************************************************************/

 
function displayFields(thisForm)
  {	  	 
     
     if (document.all.param_table != null) {
     document.all.param_table.deleteRow(0);
     if (thisForm.searchField[0].checked) {
      var newRow1 = document.all.param_table.insertRow();   
  
      var col0 = (newRow1.insertCell(0));            
      col0.width = '30%';
      col0.align = 'center';
      col0.innerHTML = '<strong><span class=Required>*</span><font size="2">&nbsp;&nbsp;Start Date:&nbsp;&nbsp;</font></strong><input type=text size=8 name=sdate maxlength=10  onClick="showCalendar(document.InvalidTrans.sdate, false);" readonly><a href="javascript:showCalendar(document.InvalidTrans.sdate, false);" ><img name="calRef" src="/SDS/bws/img/calendar.gif" border="0" width="34" height="21"></a></td>';
    	  
     var col1=(newRow1.insertCell(1));
     col1.width = '70%';
     col1.align = 'left';
     col1.innerHTML ='<strong><span class=Required>*</span><font size="2">&nbsp;&nbsp;End Date:&nbsp;&nbsp;</font></strong><input type=text size=8 name=edate maxlength=10  onClick="showCalendar(document.InvalidTrans.edate, false);" readonly><a href="javascript:showCalendar(document.InvalidTrans.edate, false);" ><img name="calRef" src="/SDS/bws/img/calendar.gif" border="0" width="34" height="21"></a></td>';
     thisForm.searchField[0].checked=true;
	 	 
   }

 if (thisForm.searchField[1].checked) {
  
     var newRow1 = document.all.param_table.insertRow();	 
     var col0 = (newRow1.insertCell());
     col0.width = '21%';
     col0.align = 'left';
     col0.innerHTML = "<div class=sidelabel >Transaction ID:&nbsp;&nbsp;</div>";
  
     var col1=(newRow1.insertCell());
     col1.width = '79%';
     col1.align = 'left';
     col1.innerHTML ="<input type=text size=20 name=Transaction_ID>";
     thisForm.searchField[1].checked=true;
	 thisForm.Transaction_ID.select();
     thisForm.Transaction_ID.focus(); 
   }
    
   if (thisForm.searchField[2].checked) {

  	  var newRow1 = document.all.param_table.insertRow();
	  var col0 = (newRow1.insertCell());
	  col0.align = 'left';
	  col0.width = '21%';
	  col0.innerHTML = "<div class=sidelabel >&nbsp;&nbsp;CC or Bank Number:&nbsp;&nbsp;</div>";
	 
	  var col1=(newRow1.insertCell());
	  col1.width = '79%';
          col1.align = 'left';
	  col1.innerHTML ="<input type=text size=20 name=CC_or_Bank maxlength=16 >"; 
	  thisForm.searchField[2].checked=true;
	  thisForm.CC_or_Bank.select();
	  thisForm.CC_or_Bank.focus();
        
 }
 
 if (thisForm.searchField[3].checked) {
 
   	  var newRow1 = document.all.param_table.insertRow();
 	  var col0 = (newRow1.insertCell());
 	  col0.align = 'left';
 	  col0.width = '21%';
 	  col0.innerHTML = "<div class=sidelabel >&nbsp;&nbsp;Select Trans. Type:&nbsp;&nbsp;</div>";
 	 
 	  var col1=(newRow1.insertCell());
 	  col1.width = '79%';
          col1.align = 'left';
 	  col1.innerHTML ="<select name=transType ><option value='All'>ALL</option><option value='I'>Direct Debit Payment</option><option value='CC'>Credit Card Payment</option><option value='R'>Refund</option><option value='DO'>Orbital Gateway Payment</option></select>"; 
 	  thisForm.searchField[3].checked=true;
         
 }

 
 return true;	  
 }
}





function block(thisform) // only gadbad in this function verification
{
	if(thisform.NewAccountNumber.value != thisform.NewAccountNumber1.value)
	{
	
		alert("Please validate this account number.");
		thisform.Submitbutton.disabled=true;
		return false;
	}
	else
	{
		thisform.Submitbutton.disabled=true;
		thisform.submit();
	}
    
}

/**************************************************************************/
  /**********   Added for ChangeDueDate Feature (START)*********************/
/**************************************************************************/
function checkBulkUploadTextBox(thisForm)		//Added to check the empty text box in Bulk Upload
{
	var str=thisForm.upfile.value;
    checkStr=Trim(str);
	if (checkStr=="")
	{
	    alert("Please select the file to upload.");
		thisForm.upfile.focus();
	    return false;
	 }
	 else
		 return true;
}

function checkGlSegment(form)
{
	
	var checkStr = form.glSegment.value;
    	
	if (checkStr == "")
	{
		alert("Please enter the GL Segment.");
		form.glSegment.focus();
		return false;
	}

	else if(checkStr.match(/\.\./))
   	{   
  		alert('GL Segment can not have consecutive periods(.).');
		form.glSegment.focus();
		form.glSegment.select();
		return false;
	}
	
	else if( checkStr.indexOf("*") != checkStr.lastIndexOf("*") )
	{   
	  	alert('GL Segment search pattern can have single wildcard character');
		form.glSegment.focus();
		form.glSegment.select();
		return false;
	}
	else if (checkStr.charAt(0) != '.')
    	{
		alert('GL Segment should start with a period(.).');
	    	form.glSegment.focus();
	    	form.glSegment.select();
	    	return false;
	}
	else if (checkStr.charAt(checkStr.length-1) == '.')
	{
		alert('GL Segment should not end with a period(.).');
	    	form.glSegment.focus();
	    	form.glSegment.select();
	    	return false;
	}
	else if (checkStr.match(/[^0-9a-zA-Z.*]/))
	{
		alert('GaL Segment can only contain alphanumerics (0-9,A-Z,a-z) separated by periods(.). and optional wildcard');
		form.glSegment.focus();
		form.glSegment.select();
		return false;
	}
	
	else if( checkStr.indexOf("*") != -1) {
		if (!checkStr.match(/\*$/)) {
			alert('GL Segment search pattern can have wildcard character only at the end');
		}
		else 
			return true;
	}
	else 
		return true;
}


/**************************************************************************/
  /**********   Added for ChangeDueDate Feature (END)*********************/
/**************************************************************************/

/**************************************************************************/
/**********   Added for new search page csr_search_new (start)*********************/
/**************************************************************************/

function validatenewsearch3(form)
{

	if (Trim(form.accountNumber.value) == "" || Trim(form.accountNumber.value) == null)
	     {
        	alert("Please enter your SAN");
        	form.accountNumber.focus();
        	form.accountNumber.select();
        	return false;
	     }
	if(!checkAlphaNumericUnderScore(form.accountNumber.value))
	    {
		alert('Account Number contains Invalid characters. Please re-enter.');
		form.accountNumber.focus();
		form.accountNumber.select();
		return false;
	    }	 

	if (Trim(form.zip.value) == "" || Trim(form.zip.value) == null)
		{
        	alert("Please enter the Zip code");
        	form.zip.focus();
        	form.zip.select();
        	return false;
	     }
	     
	if(Trim(form.zip.value) != "")
	{
		if(!isAstValid(form.zip.value))
		{
			alert('ZipCode contains Invalid characters. Please re-enter.');
			form.zip.focus();
			form.zip.select();
			return false;
		}
		if (form.zip.value.match(/^\d{5}(\-\d{4})?$/) == null 
			&& form.zip.value.match(/^\D{1}\d{1}\D{1}\ ?\d{1}\D{1}\d{1}$/) == null ) {
		       alert("Postal/Zip code must be in the format of 12345 or 12345-1234 for US and M1S 3L1 or M1S3L1 for Canada");
		       form.zip.focus();
		       form.zip.select();
		      return false;
		}
			 
	}
 	 
  form.submit();
  form.Submit.disabled = true;
}

function isAstValid(checkStr)
{
	var invalidChars = "|,\":\';`~!@#$%^&()+=[]{}<>*";

   	for (var i = 0; i < checkStr.length; i++) {
   	   if (invalidChars.indexOf(checkStr.charAt(i)) != -1)
   	      return false;
   	}
   	return true;
}

/**************************************************************************/
/**********   Added for new search page csr_search_new (END)***************/
/**************************************************************************/


/**************************************************************************/
/*****************Functions added for enterprise billing*******************/
/**************************************************************************/

function editLabel(form)
{
	if (form.searchField[0].checked || form.searchField[1].checked) {
		form.Submit.value="Search Enterprise";
	} else if (form.searchField[2].checked) {
		form.Submit.value=" Search Invoice   ";
	}
}

function checkAccountNumberEnterprise(thisform)
{
	var checkStr = thisform.searchValue.value;
	var flag = false;
    	
	if (checkStr == "") {
		alert("Please enter the Account Number.");
		thisform.searchValue.focus();
	} else if( checkStr.indexOf("*") != checkStr.lastIndexOf("*") )	{   
	  	alert('Account search pattern can have single wildcard character');
		thisform.searchValue.focus();
		thisform.searchValue.select();
	} else if (checkStr.match(/[^0-9a-zA-Z-*_]/)) {
		alert('Account number can only contain alphanumerics (0-9,A-Z,a-z), hyphen(-), underscore(_) and optional wildcard');
		thisform.searchValue.focus();
		thisform.searchValue.select();
	} else if( checkStr.indexOf("*") != -1) {
		if (!checkStr.match(/\*$/)) {
			alert('Account Number search pattern can have wildcard character only at the end');
		} else if (checkStr.length<4) {
			alert('Account Number search patter should have minimum 3 characters excluding widcard character');
		}
		else 
			flag = true;
	} else if (checkStr.length<3) {
		alert('Account Number search patter should have minimum 3 characters excluding widcard character');
	} else 
		flag = true;
	
	if (flag) {
		return true;
	} else
		return false;
}


function checkCompanyNameEnterprise(thisform)
{
	var checkStr = thisform.searchValue.value;
	var flag = false;
    	
	if (checkStr == "") {
		alert("Please enter the Company Name.");
		thisform.searchValue.focus();
	} else if( checkStr.indexOf("*") != checkStr.lastIndexOf("*") )	{   
	  	alert('Company Name search pattern can have single wildcard character');
		thisform.searchValue.focus();
		thisform.searchValue.select();
	} else if( checkStr.indexOf("*") != -1) {
		if (!checkStr.match(/\*$/)) {
			alert('Company Name search pattern can have wildcard character only at the end');
	} else if (checkStr.length < 4) {
			alert('Company Name search pattern should have minimum 3 characters excluding widcard character');
		}
		else 
			flag = true;
	} else if (checkStr.length<3) {
		alert('Company Name search pattern should have minimum 3 characters excluding widcard character');
	} else 
		flag = true;
	
	if (flag) {
		return true;
	} else
		return false;
}



function checkInvoiceNumberEnterprise(thisform)
{
	var checkInvoice = Trim(thisform.searchValue.value);
	
	if(checkInvoice == "")
	{
		alert("Please enter the Invoice Number.");
		thisform.searchValue.focus();
		return false;
	} else if (!isAstValid(checkInvoice))
	{
		alert('Invoice number contains Invalid characters. Please re-enter.');
		thisform.searchValue.focus();
		thisform.searchValue.select();
		return false;
	} else {
		return true;
	}
}
	
function viewUpdateECheckAddress(form,switchToDD)
{	
	 if ((form.namedebitcard.value == '') || (form.namedebitcard.value == null))
	{
	    alert("Please enter the name on the Bank Account.");
	    form.namedebitcard.focus();
	    return false;
	}	
	 if(form.namedebitcard.value != "")
	 {	 	
	    if(InvalidNameCheck(Trim(form.namedebitcard.value), "Please check "))
	 	{
	 	    form.namedebitcard.focus();
		    return false;
		}
	  }
	  
	 if(LastFirstNameCheck(form.namedebitcard.value))
	 {		
		  form.namedebitcard.focus();
		  return false;
	 }
	
	 var nameToCheck=form.namedebitcard.value;
	 
	 if(nameToCheck.length > 255)
	 {	
	      alert("Name exceeds maximum acceptable length of 255.");
	      form.namedebitcard.focus();
	      return false;
         }
	
	 if(form.bankroutingno.value == "") 
	 {	
		 alert("Please enter the bank routing number.");
		 form.bankroutingno.focus();
		 return false;
	 } 
	if(isNaN(Trim(form.bankroutingno.value))) {
		alert("Please enter numeric value for bank routing number.");
		form.bankroutingno.focus();
		return false;
	        }
	if(Trim(form.bankroutingno.value).length != 9) {
		alert("Bank routing number should comprise of 9 digits.");
		form.bankroutingno.focus();
		return false;
	 }
			 
      	if(form.checkingaccno.value == "") 
      	 {	alert("Please enter the bank account number.");
		form.checkingaccno.focus();
		return false;
	 } 
	 if(isNaN(Trim(form.checkingaccno.value))) {
		alert("Please enter numeric value for bank Account number.");
		form.checkingaccno.focus();
		return false;
	}
		
	var numericExpression = /^[0-9]+$/;
	if(!form.checkingaccno.value.match(numericExpression)){
		alert("Please enter numeric value for bank Account number.");
		form.checkingaccno.focus();
		return false;
	}
	
//SPR 36258 Start
	form.address.value = Trim(form.address.value);
//SPR 36258 End

	if(form.address.value == "")
	 {
	   alert("Please enter your Billing Address.");
	   form.address.focus();
	   form.address.select();
	   return false;
	 }
	 
	if(form.city.value == "")
	 {
	   alert("Please enter City name.");
	   form.city.focus();
	   form.city.select();
	   return false;
	 }
	if(form.city.value.length > 90)
	 {
	  alert('City name exceeds maximum acceptable length of 90.');
	  form.city.focus();
	  form.city.select();
	  return false;
	 }
	 
	for (var i=0; i < form.city.value.length; i++)
	 {
	 
	   var name = form.city.value.charAt(i);
	   if (!(name >= 'a' && name <= 'z') && !(name >= 'A' && name <= 'Z') && !(name <= ' '))
	     {
	        alert('City contains invalid characters.');
		form.city.focus();
		form.city.select();
		return false;
	     }
	  }
	 if(form.country.value == "") {
		alert("Please select a Country.");
		form.country.focus();
		return false;
	 }
	 if(form.state.value == "") {
		alert("Please select a State.");
		form.state.focus();
		return false;
	 }
	 if(form.country.value == "US" || form.country.value == "CA") {
		 if(form.zip.value == "" || form.zip.value == null)
		 {
		   alert("Please enter a Zip Code.");
		   form.zip.focus();
		   form.zip.select();
		   return false;
		 }
		 if(form.zip.value.length < 5 || form.zip.value.length > 10)
		 {
		   alert('Range of Zip code must be within 5 to 10');
		   form.zip.focus();
		   form.zip.select();
		   return false;
		 }

		 if(form.country.value == "US")
		 {
		    if (form.zip.value.match(/^\d{5}(\-\d{4})?$/) == null )
		    {
		      alert("Postal/Zip code must be in the format of 12345 or 12345-1234.");
		      form.zip.focus();
		      form.zip.select();
		      return false;
		    }
		 }
		 else if(form.country.value == "CA")
		 {
		    if (form.zip.value.match(/^\D{1}\d{1}\D{1}\ ?\d{1}\D{1}\d{1}$/) == null )
		    {
		      alert("Postal/Zip code must be in the format of M1S 3L1 or M1S3L1.");
		      form.zip.focus();
		      form.zip.select();
		      return false;
		    }
		 }
 	 }
 	 if(switchToDD == "true"){
 	 
 	 	var chk = checkEMail(form.email.value);
			if(chk == true)
			{
			  return false;
			}
		 
	                 
	        var emailVal=form.email.value;
			 
			 if(emailVal.length > 255)
			 {	
			      alert("Email exceeds maximum acceptable length of 255.");
			      form.email.focus();
			      return false;
       			  }
       			  
       		  
 	   }

	if ((form.country.value != "US" && form.country.value != "CA") &&
		(form.zip.value == "" || form.zip.value == null)) {
		form.zip.style.color = "#ffffff";
		form.zip.value = "00000";
	} 	 
 	 return true;
}

function GetXmlHttpObject()
{
var xmlHttp=null;
try
  {
  // Firefox, Opera 8.0+, Safari
  xmlHttp=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  }
return xmlHttp;
}


