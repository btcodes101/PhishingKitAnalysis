var cArr = new Array();
cArr[0] = new Option("Select One","");
cArr[1] = new Option("AG - Antigua and Barbuda","AG");
cArr[2] = new Option("AR - Argentina","AR");
cArr[3] = new Option("BS - Bahamas","BS");
cArr[4] = new Option("BB - Barbados","BB");
cArr[5] = new Option("BZ - Belize","BZ");
cArr[6] = new Option("BO - Bolivia, Plurinational State Of","BO");
cArr[7] = new Option("BR - Brazil","BR");
cArr[8] = new Option("CA - Canada","CA");
cArr[9] = new Option("CL - Chile","CL");
cArr[10] = new Option("CO - Colombia","CO");
cArr[11] = new Option("CR - Costa Rica","CR");
cArr[12] = new Option("CU - Cuba","CU");
cArr[13] = new Option("DM - Dominica","DM");
cArr[14] = new Option("DO - Dominican Republic","DO");
cArr[15] = new Option("EC - Ecuador","EC");
cArr[16] = new Option("SV - El Salvador","SV");
cArr[17] = new Option("GF - French Guiana","GF");
cArr[18] = new Option("GL - Greenland","GL");
cArr[19] = new Option("GD - Grenada","GD");
cArr[20] = new Option("GT - Guatemala","GT");
cArr[21] = new Option("GY - Guyana","GY");
cArr[22] = new Option("HT - Haiti","HT");
cArr[23] = new Option("HN - Honduras","HN");
cArr[24] = new Option("JM - Jamaica","JM");
cArr[25] = new Option("MX - Mexico","MX");
cArr[26] = new Option("NI - Nicaragua","NI");
cArr[27] = new Option("PA - Panama","PA");
cArr[28] = new Option("PY - Paraguay","PY");
cArr[29] = new Option("PE - Peru","PE");
cArr[30] = new Option("KN - Saint Kitts And Nevis","KN");
cArr[31] = new Option("LC - Saint Lucia","LC");
cArr[32] = new Option("VC - Saint Vincent And The Grenedines","VC");
cArr[33] = new Option("SR - Suriname","SR");
cArr[34] = new Option("TT - Trinidad and Tobago","TT");
cArr[35] = new Option("US - United States","US");
cArr[36] = new Option("UY - Uruguay","UY");
cArr[37] = new Option("VE - Venezuela","VE");

var groups=cArr.length;
var group=new Array(groups);

for (i=0; i<groups; i++) {
	group[cArr[i].value]=new Array();
}

group["AG"][0] = new Option("Select One","UNK");
group["BS"][0] = new Option("Select One","UNK");
group["BB"][0] = new Option("Select One","UNK");
group["BZ"][0] = new Option("Select One","UNK");
group["CO"][0] = new Option("Select One","UNK");
group["CR"][0] = new Option("Select One","UNK");
group["CU"][0] = new Option("Select One","UNK");
group["DM"][0] = new Option("Select One","UNK");
group["DO"][0] = new Option("Select One","UNK");
group["EC"][0] = new Option("Select One","UNK");
group["SV"][0] = new Option("Select One","UNK");
group["GF"][0] = new Option("Select One","UNK");
group["GL"][0] = new Option("Select One","UNK");
group["GD"][0] = new Option("Select One","UNK");
group["GT"][0] = new Option("Select One","UNK");
group["GY"][0] = new Option("Select One","UNK");
//group["HT"][0] = new Option("Select One","UNK");
group["HN"][0] = new Option("Select One","UNK");
group["JM"][0] = new Option("Select One","UNK");
group["NI"][0] = new Option("Select One","UNK");
group["PA"][0] = new Option("Select One","UNK");
group["PY"][0] = new Option("Select One","UNK");
group["PE"][0] = new Option("Select One","UNK");
group["KN"][0] = new Option("Select One","UNK");
group["LC"][0] = new Option("Select One","UNK");
group["VC"][0] = new Option("Select One","UNK");
group["SR"][0] = new Option("Select One","UNK");
group["TT"][0] = new Option("Select One","UNK");
group["UY"][0] = new Option("Select One","UNK");



/*
group["AG"][0] = new Option("Select One","");
group["AG"][1] = new Option("10 - Barbuda","10");
group["AG"][2] = new Option("11 - Redonda","11");
group["AG"][3] = new Option("03 - Saint George","03");
group["AG"][4] = new Option("04 - Saint John�s","04");
group["AG"][5] = new Option("05 - Saint Mary","05");
group["AG"][6] = new Option("06 - Saint Paul","06");
group["AG"][7] = new Option("07 - Saint Peter","07");
group["AG"][8] = new Option("08 - Saint Philip","08");
*/

group["AR"][0] = new Option("Select One","");
group["AR"][1] = new Option("BA - Buenos Aires","BA");
group["AR"][2] = new Option("CB - Chubut","CB");
group["AR"][3] = new Option("CF - Capital Federal","CF");
group["AR"][4] = new Option("CH - Chaco","CH");
group["AR"][5] = new Option("CO - Cordoba","CO");
group["AR"][6] = new Option("CR - Corrientes","CR");
group["AR"][7] = new Option("CT - Catamarca","CT");
group["AR"][8] = new Option("ER - Entre Rios","ER");
group["AR"][9] = new Option("FO - Formosa","FO");
group["AR"][10] = new Option("JU - Jujuy","JU");
group["AR"][11] = new Option("LP - La Pampa","LP");
group["AR"][12] = new Option("LR - La Rioja","LR");
group["AR"][13] = new Option("MI - Misiones","MI");
group["AR"][14] = new Option("MZ - Mendoza","MZ");
group["AR"][15] = new Option("NQ - Neuquen","NQ");
group["AR"][16] = new Option("RN - Rio Negro","RN");
group["AR"][17] = new Option("SA - Salta","SA");
group["AR"][18] = new Option("SC - Santa Cruz","SC");
group["AR"][19] = new Option("SE - Santiago del Estero","SE");
group["AR"][20] = new Option("SF - Santa Fe","SF");
group["AR"][21] = new Option("SJ - San Juan","SJ");
group["AR"][22] = new Option("SL - San Luis","SL");
group["AR"][23] = new Option("TF - Tierra del Fuego","TF");
group["AR"][24] = new Option("TU - Tucuman","TU");

/*
group["BS"][0] = new Option("Select One","");
group["BS"][1] = new Option("AK - Acklins Islands","AK");
group["BS"][2] = new Option("BY - Berry Islands","BY");
group["BS"][3] = new Option("BI - Bimini and Cat Cay","BI");
group["BS"][4] = new Option("BP - Black Point","BP");
group["BS"][5] = new Option("CI - Cat Island","CI");
group["BS"][6] = new Option("CO - Central Abaco","CO");
group["BS"][7] = new Option("CS - Central Andros","CS");
group["BS"][8] = new Option("CE - Central Eleuthera","CE");
group["BS"][9] = new Option("FP - City of Freeport","FP");
group["BS"][9] = new Option("CK - Crooked Island and Long Cay","CK");
group["BS"][11] = new Option("EG - East Grand Bahama","EG");
group["BS"][12] = new Option("EX - Exuma","EX");
group["BS"][13] = new Option("GC - Grand Cay","GC");
group["BS"][14] = new Option("GT - Green Turtle Cay","GT");
group["BS"][15] = new Option("HI - Harbour Island","HI");
group["BS"][16] = new Option("HT - Hope Town","HT");
group["BS"][17] = new Option("IN - Inagua","IN");
group["BS"][18] = new Option("LI - Long Island","LI");
group["BS"][19] = new Option("MC - Mangrove Cay","MC");
group["BS"][20] = new Option("MG - Mayaguana","MG");
group["BS"][21] = new Option("MI - Moore�s Island","MI");
group["BS"][22] = new Option("NO - North Abaco","NO");
group["BS"][23] = new Option("NS - North Andros","NS");
group["BS"][24] = new Option("NE - North Eleuthera","NE");
group["BS"][25] = new Option("RI - Ragged Island","RI");
group["BS"][26] = new Option("RC - Rum Cay","RC");
group["BS"][27] = new Option("SS - San Salvador","SS");
group["BS"][28] = new Option("SO - South Abaco","SO");
group["BS"][29] = new Option("SA - South Andros","SA");
group["BS"][30] = new Option("SE - South Eleuthera","SE");
group["BS"][31] = new Option("SW - Spanish Wells","SW");
group["BS"][32] = new Option("WG - West Grand Bahama","WG");

group["BB"][0] = new Option("Select One","");
group["BB"][1] = new Option("01 - Christ Church","01");
group["BB"][2] = new Option("02 - Saint Andrew","02");
group["BB"][3] = new Option("03 - Saint George","03");
group["BB"][4] = new Option("04 - Saint James","04");
group["BB"][5] = new Option("05 - Saint John","05");
group["BB"][6] = new Option("06 - Saint Joseph","06");
group["BB"][7] = new Option("07 - Saint Lucy","07");
group["BB"][8] = new Option("08 - Saint Michael","08");
group["BB"][9] = new Option("09 - Saint Peter","09");
group["BB"][10] = new Option("10 - Saint Philip","10");
group["BB"][11] = new Option("11 - Saint Thomas","11");

group["BZ"][0] = new Option("Select One","");
group["BZ"][1] = new Option("BZ - Belize","BZ");
group["BZ"][2] = new Option("CY - Cayo","CY");
group["BZ"][3] = new Option("CZ - Corozal","CZL");
group["BZ"][4] = new Option("OW - Orange Walk","OW");
group["BZ"][5] = new Option("SC - Stann Creek","SC");
group["BZ"][6] = new Option("TO - Toledo","TOL");
*/

group["BO"][0] = new Option("Select One","");
group["BO"][1] = new Option("BE - Beni","BE");
group["BO"][2] = new Option("CH - Chuquisaca","CH");
group["BO"][3] = new Option("CO - Cochabamba","CO");
group["BO"][4] = new Option("LP - La Paz","LP");
group["BO"][5] = new Option("OR - Oruro","OR");
group["BO"][6] = new Option("PA - Pando","PA");
group["BO"][7] = new Option("PO - Potosi","PO");
group["BO"][8] = new Option("SC - Santa Cruz","SC");
group["BO"][9] = new Option("TA - Tarija","TA");

group["BR"][0] = new Option("Select One","");
group["BR"][1] = new Option("AC - Acre","AC");
group["BR"][2] = new Option("AL - Alagoas","AL");
group["BR"][3] = new Option("AM - Amazonas","AM");
group["BR"][4] = new Option("AP - Amapa","AP");
group["BR"][5] = new Option("BA - Bahia","BA");
group["BR"][6] = new Option("CE - Ceara","CE");
group["BR"][7] = new Option("DF - Distrito Federal","DF");
group["BR"][8] = new Option("ES - Espirito Santo","ES");
group["BR"][9] = new Option("FN - Fernando de Noronha","FN");
group["BR"][10] = new Option("GO - Goias","GO");
group["BR"][11] = new Option("MA - Maranhao","MA");
group["BR"][12] = new Option("MG - Minas Gerais","MG");
group["BR"][13] = new Option("MS - Mato Grosso do Sul","MS");
group["BR"][14] = new Option("MT - Mato Grosso","MT");
group["BR"][15] = new Option("PA - Para","PA");
group["BR"][16] = new Option("PB - Paraiba","PB");
group["BR"][17] = new Option("PE - Pernambuco","PE");
group["BR"][18] = new Option("PI - Piaui","PI");
group["BR"][19] = new Option("PR - Parana","PR");
group["BR"][20] = new Option("RJ - Rio do Janeiro","RJ");
group["BR"][21] = new Option("RN - Rio Grande Do Norte","RN");
group["BR"][22] = new Option("RO - Rondonia","RO");
group["BR"][23] = new Option("RR - Roraima","RR");
group["BR"][24] = new Option("RS - Rio Grande Do Sul","RS");
group["BR"][25] = new Option("SC - Santa Catarina","SC");
group["BR"][26] = new Option("SE - Sergipe","SE");
group["BR"][27] = new Option("SP - Sao Paulo","SP");
group["BR"][28] = new Option("TO - Tocantins","TO");

group["CA"][0] = new Option("Select One","");
group["CA"][1] = new Option("AB - Alberta","AB");
group["CA"][2] = new Option("BC - British Columbia","BC");
group["CA"][3] = new Option("MB - Manitoba","MB");
group["CA"][4] = new Option("NB - New Brunswick","NB");
group["CA"][5] = new Option("NF - Newfoundland","NF");
group["CA"][6] = new Option("NL - Newfoundland","NL");
group["CA"][7] = new Option("NN - Nunavut (NN)","NN");
group["CA"][8] = new Option("NS - Nova Scotia","NS");
group["CA"][9] = new Option("NT - Northwest Territories","NT");
group["CA"][10] = new Option("NU - Nunavut (NU)","NU");
group["CA"][11] = new Option("ON - Ontario","ON");
group["CA"][12] = new Option("PE - Prince Edward Island","PE");
group["CA"][13] = new Option("QC - Quebec","QC");
group["CA"][14] = new Option("SK - Saskatchewan","SK");
group["CA"][15] = new Option("YT - Yukon","YT");
group["CA"][16] = new Option("ZZ - Beyond the limits of any Prov.","ZZ");

group["CL"][0] = new Option("Select One","");
group["CL"][1] = new Option("AG - Aisen del Gral. C.I. del Campo","AG");
group["CL"][2] = new Option("AN - Antofagasta","AN");
group["CL"][3] = new Option("AR - Araucania","AR");
group["CL"][4] = new Option("AT - Atacama","AT");
group["CL"][5] = new Option("BB - Bio-Bio","BB");
group["CL"][6] = new Option("CO - Coquimbo","CO");
group["CL"][7] = new Option("LL - Los Lagos","LL");
group["CL"][8] = new Option("LO - Lib. Gral. Bernardo O'Higgins","LO");
group["CL"][9] = new Option("MA - Magallanes y Antartica Chilena","MA");
group["CL"][10] = new Option("MU - Maule","MU");
group["CL"][11] = new Option("RM - Region Metropolitana","RM");
group["CL"][12] = new Option("TA - Tarapaca","TA");
group["CL"][13] = new Option("VA - Valparaiso","VA");

/*
group["CO"][0] = new Option("Select One","");
group["CO"][1] = new Option("AM - Amazonas","AMA");
group["CO"][2] = new Option("AN - Antioquia","ANT");
group["CO"][3] = new Option("AR - Arauca","ARA");
group["CO"][4] = new Option("AT - Atl�ntico","ATL");
group["CO"][5] = new Option("BO - Bol�var","BOL");
group["CO"][6] = new Option("BO - Boyac�","BOY");
group["CO"][7] = new Option("CA - Caldas","CAL");
group["CO"][8] = new Option("CA - Caquet�","CAQ");
group["CO"][9] = new Option("CA - Casanare","CAS");
group["CO"][10] = new Option("CA - Cauca","CAU");
group["CO"][11] = new Option("CE - Cesar","CES");
group["CO"][12] = new Option("CH - Choc�","CHO");
group["CO"][13] = new Option("CU - Cundinamarca","CUN");
group["CO"][14] = new Option("CO - C�rdoba","COR");
group["CO"][15] = new Option("DC - Distrito Capital de Bogot�","DC");
group["CO"][16] = new Option("GU - Guain�a","GUA");
group["CO"][17] = new Option("GU - Guaviare","GUV");
group["CO"][18] = new Option("HU - Huila","HUI");
group["CO"][19] = new Option("LA - La Guajira","LAG");
group["CO"][20] = new Option("MA - Magdalena","MAG");
group["CO"][21] = new Option("ME - Meta","MET");
group["CO"][22] = new Option("NA - Nari�o","NAR");
group["CO"][23] = new Option("NS - Norte de Santander","NSA");
group["CO"][24] = new Option("PU - Putumayo","PUT");
group["CO"][25] = new Option("QU - Quind�o","QUI");
group["CO"][26] = new Option("RI - Risaralda","RIS");
group["CO"][27] = new Option("Pr - San Andr�s, Providencia y Santa Catalina","SAP");
group["CO"][28] = new Option("SA - Santander","SAN");
group["CO"][29] = new Option("SU - Sucre","SUC");
group["CO"][30] = new Option("TO - Tolima","TOL");
group["CO"][31] = new Option("VA - Valle del Cauca","VAC");
group["CO"][32] = new Option("VA - Vaup�s","VAU");
group["CO"][33] = new Option("VI - Vichada","VID");

group["CR"][0] = new Option("Select One","");
group["CR"][1] = new Option("A" - Alajuela","A");
group["CR"][2] = new Option("C" - Cartago","C");
group["CR"][3] = new Option("G" - Guanacaste","G");
group["CR"][4] = new Option("H" - Heredia","H");
group["CR"][5] = new Option("L" - Lim�n","L");
group["CR"][6] = new Option("P" - Puntarenas","P");
group["CR"][7] = new Option("SJ - San Jos�","SJ");

group["CU"][0] = new Option("Select One","");
group["CU"][1] = new Option("09 - Camag�ey","09");
group["CU"][2] = new Option("08 - Ciego de �vila","08");
group["CU"][3] = new Option("06 - Cienfuegos","06");
group["CU"][4] = new Option("03 - Ciudad de La Habana","03");
group["CU"][5] = new Option("12 - Granma","12");
group["CU"][6] = new Option("14 - Guant�namo","14");
group["CU"][7] = new Option("11 - Holgu�n","11");
group["CU"][8] = new Option("99 - Isla de la Juventud","99");
group["CU"][9] = new Option("02 - La Habana","02");
group["CU"][10] = new Option("10 - Las Tunas","10");
group["CU"][11] = new Option("04 - Matanzas","04");
group["CU"][12] = new Option("01 - Pinar del R�o","01");
group["CU"][13] = new Option("07 - Sancti Sp�ritus","07");
group["CU"][14] = new Option("13 - Santiago de Cuba","13");
group["CU"][15] = new Option("05 - Villa Clara","05");

group["DM"][0] = new Option("Select One","");
group["DM"][1] = new Option("02 - Saint Andrew","02");
group["DM"][2] = new Option("03 - Saint David","03");
group["DM"][3] = new Option("04 - Saint George","04");
group["DM"][4] = new Option("05 - Saint John","05");
group["DM"][5] = new Option("06 - Saint Joseph","06");
group["DM"][6] = new Option("07 - Saint Luke","07");
group["DM"][7] = new Option("08 - Saint Mark","08");
group["DM"][8] = new Option("09 - Saint Patrick","09");
group["DM"][9] = new Option("10 - Saint Paul","10");
group["DM"][10] = new Option("11 - Saint Peter","11");

group["DO"][0] = new Option("Select One","");
group["DO"][1] = new Option("02 - Azua","02");
group["DO"][2] = new Option("03 - Bahoruco","03");
group["DO"][3] = new Option("04 - Barahona","04");
group["DO"][4] = new Option("05 - Dajab�n","05");
group["DO"][5] = new Option("01 - Distrito Nacional (Santo Domingo)","01");
group["DO"][6] = new Option("06 - Duarte","06");
group["DO"][7] = new Option("08 - El Seybo [El Seibo]","08");
group["DO"][8] = new Option("09 - Espaillat","09");
group["DO"][9] = new Option("30 - Hato Mayor","30");
group["DO"][10] = new Option("10 - Independencia","10");
group["DO"][11] = new Option("11 - La Altagracia","11");
group["DO"][12] = new Option("07 - La Estrelleta [El�as Pi�a]","07");
group["DO"][13] = new Option("12 - La Romana","12");
group["DO"][14] = new Option("13 - La Vega","13");
group["DO"][15] = new Option("14 - Mar�a Trinidad S�nchez","14");
group["DO"][15] = new Option("28 - Monse�or Nouel","28");
group["DO"][16] = new Option("15 - Monte Cristi","15");
group["DO"][17] = new Option("29 - Monte Plata","29");
group["DO"][18] = new Option("16 - Pedernales","16");
group["DO"][19] = new Option("17 - Peravia","17");
group["DO"][20] = new Option("18 - Puerto Plata","18");
group["DO"][21] = new Option("19 - Salcedo","19");
group["DO"][22] = new Option("20 - Saman�","20");
group["DO"][23] = new Option("21 - San Crist�bal","21");
group["DO"][24] = new Option("31 - San Jose de Ocoa","31");
group["DO"][25] = new Option("22 - San Juan","22");
group["DO"][26] = new Option("23 - San Pedro de Macor�s","23");
group["DO"][27] = new Option("25 - Santiago","25");
group["DO"][28] = new Option("26 - Santiago Rodr�guez","26");
group["DO"][29] = new Option("24 - S�nchez Ram�rez","24");
group["DO"][30] = new Option("27 - Valverde","27");

group["EC"][0] = new Option("Select One","");
group["EC"][1] = new Option("A" - Azuay","A");
group["EC"][2] = new Option("B" - Bol�var","B");
group["EC"][3] = new Option("C" - Carchi","C");
group["EC"][4] = new Option("F" - Ca�ar","F");
group["EC"][5] = new Option("H" - Chimborazo","H");
group["EC"][6] = new Option("X" - Cotopaxi","X");
group["EC"][7] = new Option("O" - El Oro","O");
group["EC"][8] = new Option("E" - Esmeraldas","E");
group["EC"][9] = new Option("W" - Gal�pagos","W");
group["EC"][10] = new Option("G" - Guayas","G");
group["EC"][11] = new Option("I" - Imbabura","I");
group["EC"][12] = new Option("L" - Loja","L");
group["EC"][13] = new Option("R" - Los R�os","R");
group["EC"][14] = new Option("M" - Manab�","M");
group["EC"][15] = new Option("S" - Morona-Santiago","S");
group["EC"][16] = new Option("N" - Napo","N");
group["EC"][17] = new Option("D" - Orellana","D");
group["EC"][18] = new Option("Y" - Pastaza","Y");
group["EC"][19] = new Option("P" - Pichincha","P");
group["EC"][20] = new Option("SE - Santa Elena","SE");
group["EC"][21] = new Option("SD - Santo Domingo de los Tsachilas","SD");
group["EC"][22] = new Option("U" - Sucumb�os","U");
group["EC"][23] = new Option("T" - Tungurahua","T");
group["EC"][24] = new Option("Z" - Zamora-Chinchipe","Z");

group["SV"][0] = new Option("Select One","");
group["SV"][1] = new Option("AH - Ahuachap�n","AH");
group["SV"][2] = new Option("CA - Caba�as","CA");
group["SV"][3] = new Option("CH - Chalatenango","CH");
group["SV"][4] = new Option("CU - Cuscatl�n","CU");
group["SV"][5] = new Option("LI - La Libertad","LI");
group["SV"][6] = new Option("PA - La Paz","PA");
group["SV"][7] = new Option("UN - La Uni�n","UN");
group["SV"][8] = new Option("MO - Moraz�n","MO");
group["SV"][9] = new Option("SM - San Miguel","SM");
group["SV"][10] = new Option("SS - San Salvador","SS");
group["SV"][11] = new Option("SV - San Vicente","SV");
group["SV"][12] = new Option("SA - Santa Ana","SA");
group["SV"][13] = new Option("SO - Sonsonate","SO");
group["SV"][14] = new Option("US - Usulut�n","US");

group["GF"][1] = new Option("TB - [TBD]","TBD");

group["GL"][0] = new Option("Select One","");
group["GL"][1] = new Option("KU - Kommune Kujalleq (kl)","KU");
group["GL"][2] = new Option("SM - Kommuneqarfik Sermersooq (kl)","SM");
group["GL"][3] = new Option("QA - Qaasuitsup Kommunia (kl)","QA");
group["GL"][4] = new Option("QE - Qeqqata Kommunia (kl)","QE");

group["GD"][0] = new Option("Select One","");
group["GD"][1] = new Option("01 - Saint Andrew","01");
group["GD"][2] = new Option("02 - Saint David","02");
group["GD"][3] = new Option("03 - Saint George","03");
group["GD"][4] = new Option("04 - Saint John","04");
group["GD"][5] = new Option("05 - Saint Mark","05");
group["GD"][6] = new Option("06 - Saint Patrick","06");
group["GD"][7] = new Option("10 - Southern Grenadine Islands","10");

group["GT"][0] = new Option("Select One","");
group["GT"][1] = new Option("AV - Alta Verapaz","AV");
group["GT"][2] = new Option("BV - Baja Verapaz","BV");
group["GT"][3] = new Option("CM - Chimaltenango","CM");
group["GT"][4] = new Option("CQ - Chiquimula","CQ");
group["GT"][5] = new Option("PR - El Progreso","PR");
group["GT"][6] = new Option("ES - Escuintla","ES");
group["GT"][7] = new Option("GU - Guatemala","GU");
group["GT"][8] = new Option("HU - Huehuetenango","HU");
group["GT"][9] = new Option("IZ - Izabal","IZ");
group["GT"][10] = new Option("JA - Jalapa","JA");
group["GT"][11] = new Option("JU - Jutiapa","JU");
group["GT"][12] = new Option("PE - Pet�n","PE");
group["GT"][13] = new Option("QZ - Quetzaltenango","QZ");
group["GT"][14] = new Option("QC - Quich�","QC");
group["GT"][15] = new Option("RE - Retalhuleu","RE");
group["GT"][16] = new Option("SA - Sacatep�quez","SA");
group["GT"][17] = new Option("SM - San Marcos","SM");
group["GT"][18] = new Option("SR - Santa Rosa","SR");
group["GT"][19] = new Option("SO - Solol�","SO");
group["GT"][20] = new Option("SU - Suchitep�quez","SU");
group["GT"][21] = new Option("TO - Totonicap�n","TO");
group["GT"][22] = new Option("ZA - Zacapa","ZA");

group["GY"][0] = new Option("Select One","");
group["GY"][1] = new Option("BA - Barima-Waini","BA");
group["GY"][2] = new Option("CU - Cuyuni-Mazaruni","CU");
group["GY"][3] = new Option("DE - Demerara-Mahaica","DE");
group["GY"][4] = new Option("EB - East Berbice-Corentyne","EB");
group["GY"][5] = new Option("ES - Essequibo Islands-West Demerara","ES");
group["GY"][6] = new Option("MA - Mahaica-Berbice","MA");
group["GY"][7] = new Option("PM - Pomeroon-Supenaam","PM");
group["GY"][8] = new Option("PT - Potaro-Siparuni","PT");
group["GY"][9] = new Option("UD - Upper Demerara-Berbice","UD");
group["GY"][10] = new Option("UT - Upper Takutu-Upper Essequibo","UT");

group["HN"][0] = new Option("Select One","");
group["HN"][1] = new Option("AT - Atl�ntida","AT");
group["HN"][2] = new Option("CH - Choluteca","CH");
group["HN"][3] = new Option("CL - Col�n","CL");
group["HN"][4] = new Option("CM - Comayagua","CM");
group["HN"][5] = new Option("CP - Cop�n","CP");
group["HN"][6] = new Option("CR - Cort�s","CR");
group["HN"][7] = new Option("EP - El Para�so","EP");
group["HN"][8] = new Option("FM - Francisco Moraz�n","FM");
group["HN"][9] = new Option("GD - Gracias a Dios","GD");
group["HN"][10] = new Option("IN - Intibuc�","IN");
group["HN"][11] = new Option("IB - Islas de la Bah�a","IB");
group["HN"][12] = new Option("LP - La Paz","LP");
group["HN"][13] = new Option("LE - Lempira","LE");
group["HN"][14] = new Option("OC - Ocotepeque","OC");
group["HN"][15] = new Option("OL - Olancho","OL");
group["HN"][16] = new Option("SB - Santa B�rbara","SB");
group["HN"][17] = new Option("VA - Valle","VA");
group["HN"][18] = new Option("YO - Yoro","YO");

group["JM"][0] = new Option("Select One","");
group["JM"][1] = new Option("13 - Clarendon","13");
group["JM"][2] = new Option("09 - Hanover","09");
group["JM"][3] = new Option("01 - Kingston","01");
group["JM"][4] = new Option("12 - Manchester","12");
group["JM"][5] = new Option("04 - Portland","04");
group["JM"][6] = new Option("02 - Saint Andrew","02");
group["JM"][7] = new Option("06 - Saint Ann","06");
group["JM"][8] = new Option("14 - Saint Catherine","14");
group["JM"][9] = new Option("11 - Saint Elizabeth","11");
group["JM"][10] = new Option("08 - Saint James","08");
group["JM"][11] = new Option("05 - Saint Mary","05");
group["JM"][12] = new Option("03 - Saint Thomas","03");
group["JM"][13] = new Option("07 - Trelawny","07");
group["JM"][14] = new Option("10 - Westmoreland","10");
*/

group["HT"][0] = new Option("Select One","");
group["HT"][1] = new Option("AT - Artibonite","AT");
group["HT"][2] = new Option("CE - Centre","CE");
group["HT"][3] = new Option("GN - Grand'Anse","GN");
group["HT"][4] = new Option("NI - Nippes","NI");
group["HT"][5] = new Option("NO - Nord","NO");
group["HT"][6] = new Option("NR - Nord-Est","NR");
group["HT"][7] = new Option("NU - Nord-Ouest","NU");
group["HT"][8] = new Option("OU - Ouest","OU");
group["HT"][9] = new Option("SE - Sud-Est","SE");
group["HT"][10] = new Option("SU - Sud","SU");

group["MX"][0] = new Option("Select One","");
group["MX"][1] = new Option("AGS - Aguascalientes","AGS");
group["MX"][2] = new Option("BCN - Baja California Norte","BCN");
group["MX"][3] = new Option("BCS - Baja California Sur","BCS");
group["MX"][4] = new Option("CAMP - Campeche","CAMP");
group["MX"][5] = new Option("CHIH - Chihuahua","CHIH");
group["MX"][6] = new Option("CHPS - Chiapas","CHPS");
group["MX"][7] = new Option("COAH - Coahuila","COAH");
group["MX"][8] = new Option("COLI - Colima","COLI");
group["MX"][9] = new Option("DF - Distrito Federal","DF");
group["MX"][10] = new Option("DGO - Durango","DGO");
group["MX"][11] = new Option("EMEX - Estado de Mexico","EMEX");
group["MX"][12] = new Option("GRO - Guerrero","GRO");
group["MX"][13] = new Option("GTO - Guanajuato","GTO");
group["MX"][14] = new Option("HGO - Hidalgo","HGO");
group["MX"][15] = new Option("JAL - Jalisco","JAL");
group["MX"][16] = new Option("MICH - Michoacan","MICH");
group["MX"][17] = new Option("MOR - Morelos","MOR");
group["MX"][18] = new Option("NAY - Nayarit","NAY");
group["MX"][19] = new Option("NL - Nuevo Leon","NL");
group["MX"][20] = new Option("OAX - Oaxaca","OAX");
group["MX"][21] = new Option("PUE - Puebla","PUE");
group["MX"][22] = new Option("QRO - Queretaro","QRO");
group["MX"][23] = new Option("QROO - Quintana Roo","QROO");
group["MX"][24] = new Option("SIN - Sinaloa","SIN");
group["MX"][25] = new Option("SLP - San Luis Potos","SLP");
group["MX"][26] = new Option("SON - Sonora","SON");
group["MX"][27] = new Option("TAB - Tabasco","TAB");
group["MX"][28] = new Option("TAMP - Tamaulipas","TAMP");
group["MX"][29] = new Option("TLAX - Tlaxcala","TLAX");
group["MX"][30] = new Option("VER - Veracruz","VER");
group["MX"][31] = new Option("YUC - Yucatan","YUC");
group["MX"][32] = new Option("ZAC - Zacatecas","ZAC");

/*
group["NI"][0] = new Option("Select One","");
group["NI"][1] = new Option("AN - Atl�ntico Norte*","AN");
group["NI"][2] = new Option("AS - Atl�ntico Sur*","AS");
group["NI"][3] = new Option("BO - Boaco","BO");
group["NI"][4] = new Option("CA - Carazo","CA");
group["NI"][5] = new Option("CI - Chinandega","CI");
group["NI"][6] = new Option("CO - Chontales","CO");
group["NI"][7] = new Option("ES - Estel�","ES");
group["NI"][8] = new Option("GR - Granada","GR");
group["NI"][9] = new Option("JI - Jinotega","JI");
group["NI"][10] = new Option("LE - Le�n","LE");
group["NI"][11] = new Option("MD - Madriz","MD");
group["NI"][12] = new Option("MN - Managua","MN");
group["NI"][13] = new Option("MS - Masaya","MS");
group["NI"][14] = new Option("MT - Matagalpa","MT");
group["NI"][15] = new Option("NS - Nueva Segovia","NS");
group["NI"][16] = new Option("RI - Rivas","RI");
group["NI"][17] = new Option("SJ - R�o San Juan","SJ");

group["PA"][0] = new Option("Select One","");
group["PA"][1] = new Option("1" - Bocas del Toro","1");
group["PA"][2] = new Option("4" - Chiriqu�","4");
group["PA"][3] = new Option("2" - Cocl�","2");
group["PA"][4] = new Option("3" - Col�n","3");
group["PA"][5] = new Option("5" - Dari�n","5");
group["PA"][6] = new Option("EM - Ember�","EM");
group["PA"][7] = new Option("6" - Herrera","6");
group["PA"][8] = new Option("7" - Los Santos","7");
group["PA"][9] = new Option("NB - Ng�be-Bugl�","NB");
group["PA"][10] = new Option("8" - Panam�","8");
group["PA"][11] = new Option("9" - Veraguas","9");

group["PY"][0] = new Option("Select One","");
group["PY"][1] = new Option("16 - Alto Paraguay","16");
group["PY"][2] = new Option("10 - Alto Paran�","10");
group["PY"][3] = new Option("13 - Amambay","13");
group["PY"][4] = new Option("AS - Asunci�n","ASU");
group["PY"][5] = new Option("19 - Boquer�n","19");
group["PY"][6] = new Option("5" - Caaguaz�","5");
group["PY"][7] = new Option("6" - Caazap�","6");
group["PY"][8] = new Option("14 - Canindey�","14");
group["PY"][9] = new Option("11 - Central","11");
group["PY"][10] = new Option("1" - Concepci�n","1");
group["PY"][11] = new Option("3" - Cordillera","3");
group["PY"][12] = new Option("4" - Guair�","4");
group["PY"][13] = new Option("7" - Itap�a","7");
group["PY"][14] = new Option("8" - Misiones","8");
group["PY"][15] = new Option("9" - Paraguar�","9");
group["PY"][16] = new Option("15 - Presidente Hayes","15");
group["PY"][17] = new Option("2" - San Pedro","2");
group["PY"][18] = new Option("12 - �eembuc�","12");

group["PE"][0] = new Option("Select One","");
group["PE"][1] = new Option("AM - Amazonas","AMA");
group["PE"][2] = new Option("AN - Ancash","ANC");
group["PE"][3] = new Option("AP - Apur�mac","APU");
group["PE"][4] = new Option("AR - Arequipa","ARE");
group["PE"][5] = new Option("AY - Ayacucho","AYA");
group["PE"][6] = new Option("CA - Cajamarca","CAJ");
group["PE"][7] = new Option("CU - Cusco [Cuzco]","CUS");
group["PE"][8] = new Option("CA - El Callao","CAL");
group["PE"][9] = new Option("HU - Huancavelica","HUV");
group["PE"][10] = new Option("HU - Hu�nuco","HUC");
group["PE"][11] = new Option("IC - Ica","ICA");
group["PE"][12] = new Option("JU - Jun�n","JUN");
group["PE"][13] = new Option("LA - La Libertad","LAL");
group["PE"][14] = new Option("LA - Lambayeque","LAM");
group["PE"][15] = new Option("LI - Lima","LIM");
group["PE"][16] = new Option("LO - Loreto","LOR");
group["PE"][17] = new Option("MD - Madre de Dios","MDD");
group["PE"][18] = new Option("MO - Moquegua","MOQ");
group["PE"][19] = new Option("LM - Municipalidad Metropolitana de Lima","LMA");
group["PE"][20] = new Option("PA - Pasco","PAS");
group["PE"][21] = new Option("PI - Piura","PIU");
group["PE"][22] = new Option("PU - Puno","PUN");
group["PE"][23] = new Option("SA - San Mart�n","SAM");
group["PE"][24] = new Option("TA - Tacna","TAC");
group["PE"][25] = new Option("TU - Tumbes","TUM");
group["PE"][26] = new Option("UC - Ucayali","UCA");

group["KN"][0] = new Option("Select One","");
group["KN"][1] = new Option("01 - Christ Church Nichola Town","01");
group["KN"][2] = new Option("02 - Saint Anne Sandy Point","02");
group["KN"][3] = new Option("03 - Saint George Basseterre","03");
group["KN"][4] = new Option("04 - Saint George Gingerland","04");
group["KN"][5] = new Option("05 - Saint James Windward","05");
group["KN"][6] = new Option("06 - Saint John Capisterre","06");
group["KN"][7] = new Option("07 - Saint John Figtree","07");
group["KN"][8] = new Option("08 - Saint Mary Cayon","08");
group["KN"][9] = new Option("09 - Saint Paul Capisterre","09");
group["KN"][10] = new Option("10 - Saint Paul Charlestown","10");
group["KN"][11] = new Option("11 - Saint Peter Basseterre","11");
group["KN"][12] = new Option("12 - Saint Thomas Lowland","12");
group["KN"][13] = new Option("13 - Saint Thomas Middle Island","13");
group["KN"][14] = new Option("15 - Trinity Palmetto Point","15");

group["LC"][1] = new Option("TB - [TBD]","TBD");

group["VC"][0] = new Option("Select One","");
group["VC"][1] = new Option("01 - Charlotte","01");
group["VC"][2] = new Option("06 - Grenadines","06");
group["VC"][3] = new Option("02 - Saint Andrew","02");
group["VC"][4] = new Option("03 - Saint David","03");
group["VC"][5] = new Option("04 - Saint George","04");
group["VC"][6] = new Option("05 - Saint Patrick","05");

group["SR"][0] = new Option("Select One","");
group["SR"][1] = new Option("BR - Brokopondo","BR");
group["SR"][2] = new Option("CM - Commewijne","CM");
group["SR"][3] = new Option("CR - Coronie","CR");
group["SR"][4] = new Option("MA - Marowijne","MA");
group["SR"][5] = new Option("NI - Nickerie","NI");
group["SR"][6] = new Option("PR - Para","PR");
group["SR"][7] = new Option("PM - Paramaribo","PM");
group["SR"][8] = new Option("SA - Saramacca","SA");
group["SR"][9] = new Option("SI - Sipaliwini","SI");
group["SR"][10] = new Option("WA - Wanica","WA");

group["TT"][0] = new Option("Select One","");
group["TT"][1] = new Option("AR - Arima","ARI");
group["TT"][2] = new Option("CH - Chaguanas","CHA");
group["TT"][3] = new Option("CT - Couva-Tabaquite-Talparo","CTT");
group["TT"][4] = new Option("DM - Diego Martin","DMN");
group["TT"][5] = new Option("ET - Eastern Tobago","ETO");
group["TT"][6] = new Option("PE - Penal-Debe","PED");
group["TT"][7] = new Option("PT - Point Fortin","PTF");
group["TT"][8] = new Option("PO - Port of Spain","POS");
group["TT"][9] = new Option("PR - Princes Town","PRT");
group["TT"][10] = new Option("RC - Rio Claro-Mayaro","RCM");
group["TT"][11] = new Option("SF - San Fernando","SFO");
group["TT"][12] = new Option("SJ - San Juan-Laventille","SJL");
group["TT"][13] = new Option("SG - Sangre Grande","SGE");
group["TT"][14] = new Option("SI - Siparia","SIP");
group["TT"][15] = new Option("TU - Tunapuna-Piarco","TUP");
group["TT"][16] = new Option("WT - Western Tobago","WTO");
*/

group["US"][0] = new Option("Select One","");
group["US"][1] = new Option("AA - Armed Forces Americas","AA");
group["US"][2] = new Option("AE - Armed Forces Europe","AE");
group["US"][3] = new Option("AL - Alabama","AL");
group["US"][4] = new Option("AK - Alaska","AK");
group["US"][5] = new Option("AS - American Samoa","AS");
group["US"][6] = new Option("AZ - Arizona","AZ");
group["US"][7] = new Option("AR - Arkansas","AR");
group["US"][8] = new Option("AP - Armed Forces Pacific","AA");
group["US"][9] = new Option("CA - California","CA");
group["US"][10] = new Option("CO - Colorado","CO");
group["US"][11] = new Option("CT - Connecticut","CT");
group["US"][12] = new Option("DE - Delaware","DE");
group["US"][13] = new Option("DC - District of Columbia","DC");
group["US"][14] = new Option("FM - Federated States of Micronesia","FM");
group["US"][15] = new Option("FL - Florida","FL");
group["US"][16] = new Option("GA - Georgia","GA");
group["US"][17] = new Option("GU - Guam","GU");
group["US"][18] = new Option("HI - Hawaii","HI");
group["US"][19] = new Option("ID - ldaho","ID");
group["US"][20] = new Option("IL - illinois","IL");
group["US"][21] = new Option("IN - Indiana","IN");
group["US"][22] = new Option("IA - Iowa","IA");
group["US"][23] = new Option("KS - Kansas","KS");
group["US"][24] = new Option("KY - Kentucky","KY");
group["US"][25] = new Option("LA - Louisiana","LA");
group["US"][26] = new Option("ME - Maine","ME");
group["US"][27] = new Option("MH - Marshall Islands","MH");
group["US"][28] = new Option("MD - Maryland","MD");
group["US"][29] = new Option("MA - Massachusetts","MA");
group["US"][30] = new Option("MI - Michigan","MI");
group["US"][31] = new Option("MN - Minnesota","MN");
group["US"][32] = new Option("MS - Mississippi","MS");
group["US"][33] = new Option("MO - Missouri","MO");
group["US"][34] = new Option("MT - Montana","MT");
group["US"][35] = new Option("NE - Nebraska","NE");
group["US"][36] = new Option("NV - Nevada","NV");
group["US"][37] = new Option("NH - New Hampshire","NH");
group["US"][38] = new Option("NJ - New Jersey","NJ");
group["US"][39] = new Option("NM - New Mexico","NM");
group["US"][40] = new Option("NY - NewYork","NY");
group["US"][41] = new Option("NC - North Carolina","NC");
group["US"][42] = new Option("ND - North Dakota","ND");
group["US"][43] = new Option("MP - Nothern Mariana Islands","MP");
group["US"][44] = new Option("OH - Ohio","OH");
group["US"][45] = new Option("OK - Oklahoma","OK");
group["US"][46] = new Option("OR - Oregon","OR");
group["US"][47] = new Option("PW - Palau","PW");
group["US"][48] = new Option("PA - Pennsylvania","PA");
group["US"][49] = new Option("PR - Puerto Rico","PR");
group["US"][50] = new Option("RI - Rhode Island","RI");
group["US"][51] = new Option("SC - South Carolina","SC");
group["US"][52] = new Option("SD - South Dakota","SD");
group["US"][53] = new Option("TN - Tennessee","TN");
group["US"][54] = new Option("TX - Texas","TX");
group["US"][55] = new Option("UT - Utah","UT");
group["US"][56] = new Option("VT - Vermont","VT");
group["US"][57] = new Option("VA - Virginia","VA");
group["US"][58] = new Option("VI - Virgin Islands","VI");
group["US"][59] = new Option("WA - Washington","WA");
group["US"][60] = new Option("WV - West Virginia","WV");
group["US"][61] = new Option("WI - Wisconsin","WI");
group["US"][62] = new Option("WY - Wyoming","WY");

/*
group["UY"][0] = new Option("Select One","");
group["UY"][1] = new Option("AR - Artigas","AR");
group["UY"][2] = new Option("X1 - Canelones","X1");
group["UY"][3] = new Option("X2 - Cerro Largo","X2");
group["UY"][4] = new Option("X3 - Colonia","X3");
group["UY"][5] = new Option("DU - Durazno","DU");
group["UY"][6] = new Option("FS - Flores","FS");
group["UY"][7] = new Option("FD - Florida","FD");
group["UY"][8] = new Option("LA - Lavalleja","LA");
group["UY"][9] = new Option("MA - Maldonado","MA");
group["UY"][10] = new Option("MO - Montevideo","MO");
group["UY"][11] = new Option("PA - Paysand�","PA");
group["UY"][12] = new Option("RV - Rivera","RV");
group["UY"][13] = new Option("RO - Rocha","RO");
group["UY"][14] = new Option("RN - R�o Negro","RN");
group["UY"][15] = new Option("SA - Salto","SA");
group["UY"][16] = new Option("SJ - San Jos�","SJ");
group["UY"][17] = new Option("SO - Soriano","SO");
group["UY"][18] = new Option("TA - Tacuaremb�","TA");
group["UY"][19] = new Option("TT - Treinta y Tres","TT");
*/

group["VE"][0] = new Option("Select One","");
group["VE"][1] = new Option("AN - Anzoategui","AN");
group["VE"][2] = new Option("AP - Apure","AP");
group["VE"][3] = new Option("AR - Aragua","AR");
group["VE"][4] = new Option("BA - Barinas","BA");
group["VE"][5] = new Option("BO - Bolivar","BO");
group["VE"][6] = new Option("CA - Carabobo","CA");
group["VE"][7] = new Option("CO - Cojedes","CO");
group["VE"][8] = new Option("DA - Delta Amacuro","DA");
group["VE"][9] = new Option("FA - Falcon","FA");
group["VE"][10] = new Option("GU - Guarico","GU");
group["VE"][11] = new Option("LA - Lara","LA");
group["VE"][12] = new Option("ME - Merida","ME");
group["VE"][13] = new Option("MI - Miranda","MI");
group["VE"][14] = new Option("MO - Monagas","MO");
group["VE"][15] = new Option("NE - Nueva Esparta","NE");
group["VE"][16] = new Option("PO - Portuguesa","PO");
group["VE"][17] = new Option("SU - Sucre","SU");
group["VE"][18] = new Option("TA - Tachira","TA");
group["VE"][19] = new Option("TR - Trujillo","TR");
group["VE"][20] = new Option("YA - Yaracuy","YA");
group["VE"][21] = new Option("ZU - Zulia","ZU");

function getUSIndex(){
	for (var x=0; x < cArr.length; x++) {
		if (cArr[x].value == "US") {
			return x;
		}
	}
}

function renderCSOnLoad(tempC,tempS,pCountry,pState){
	var isCountry = false;
	var isCSelected = false;
	var isState = false;
	var isSSelected = false;
	if (pCountry != '' && pCountry != 'null') {
		isCountry = true;
		if (pCountry != 'US' && pCountry != 'CA') {
			if (document.getElementById("zipnr") != null) {
				document.getElementById("zipnr").innerHTML = "(Not Required)";
			} else if (document.getElementById("zipnrc") != null) {
				document.getElementById("zipnrc").innerHTML = "";
			}
		}
	}
	if (pState != '' && pState != 'null') {
		isState = true;
		if (pState == 'UNK') {
			if (document.getElementById("statenr") != null) {
				document.getElementById("statenr").innerHTML = "(Not Required)";
			} else if (document.getElementById("statenrc") != null) {
				document.getElementById("statenrc").innerHTML = "";
			}
		}
	}
	if (tempC != null) {
		removeAllOptions(tempC);
		for (i=0;i<cArr.length;i++){
			tempC.options[i]=new Option(cArr[i].text,cArr[i].value);
			if (isCountry && !isCSelected) {
				if (pCountry == cArr[i].value) {
					tempC.options[i].selected=true;
					isCSelected = true;
				}
			}
		}
		if (!isCountry) {
			tempC.options[getUSIndex()].selected=true;
			pCountry = "US";
		}
	}
	if (tempS != null) {
		removeAllOptions(tempS);
		for (i=0;i<group[pCountry].length;i++){
			tempS.options[i]=new Option(group[pCountry][i].text,group[pCountry][i].value);
			if (isState && !isSSelected) {
				if (pState == group[pCountry][i].value) {
					tempS.options[i].selected=true;
					isSSelected = true;
				}
			}
		}
		if (!isState) {
			tempS.options[0].selected=true;
		}
	}
}

function reRenderCS(tempS,pCountry){
	removeAllOptions(tempS);
	if (pCountry != '') {
		for (i=0;i<group[pCountry].length;i++){
			tempS.options[i]=new Option(group[pCountry][i].text,group[pCountry][i].value);
		}
		if (tempS.options.length == 1 && tempS.options[0].value == 'UNK') {
			if (document.getElementById("statenr") != null) {
				document.getElementById("statenr").innerHTML = "(Not Required)";
			} else if (document.getElementById("statenrc") != null) {
				document.getElementById("statenrc").innerHTML = "";
			}
		} else {
			if (document.getElementById("statenr") != null) {
				document.getElementById("statenr").innerHTML = "";
			} else if (document.getElementById("statenrc") != null) {
				document.getElementById("statenrc").innerHTML = "*";
			}
		}
		if (pCountry != 'US' && pCountry != 'CA') {
			if (document.getElementById("zipnr") != null) {
				document.getElementById("zipnr").innerHTML = "(Not Required)";
			} else if (document.getElementById("zipnrc") != null) {
				document.getElementById("zipnrc").innerHTML = "";
			}
		} else {
			if (document.getElementById("zipnr") != null) {
				document.getElementById("zipnr").innerHTML = "";
			} else if (document.getElementById("zipnrc") != null) {
				document.getElementById("zipnrc").innerHTML = "*";
			}
		}
	} else {
		tempS.options[0] = new Option("Select One","");
		if (document.getElementById("statenr") != null) {
			document.getElementById("statenr").innerHTML = "";
		} else if (document.getElementById("statenrc") != null) {
			document.getElementById("statenrc").innerHTML = "*";
		}
		if (document.getElementById("zipnr") != null) {
			document.getElementById("zipnr").innerHTML = "";
		} else if (document.getElementById("zipnrc") != null) {
			document.getElementById("zipnrc").innerHTML = "*";
		}
	}
	tempS.options[0].selected=true;
}

function removeAllOptions(selectbox) {
	var i;
	for(i=selectbox.options.length-1;i>=0;i--) {
		selectbox.remove(i);
	}
}


function redirect(x){
	var temp=document.updateInfo.ccState;
	for (m=temp.options.length-1;m>0;m--)
	temp.options[m]=null;
	for (i=0;i<group[x].length;i++){
		temp.options[i]=new Option(group[x][i].text,group[x][i].value);
	}
	temp.options[0].selected=true;
}


function redirect1(x){
	
	var temp=document.updateInfo.ccState1;
	for (m=temp.options.length-1;m>0;m--)
		temp.options[m]=null;
	
	for (i=0;i<group[x].length;i++){
		temp.options[i]=new Option(group[x][i].text,group[x][i].value);
	}
	temp.options[0].selected=true;
}

function redirect2(x){
	
	var temp=document.updateInfo.ccState2;
	for (m=temp.options.length-1;m>0;m--)
		temp.options[m]=null;
	
	for (i=0;i<group[x].length;i++){
		temp.options[i]=new Option(group[x][i].text,group[x][i].value);
	}
	temp.options[0].selected=true;
}

function redirectUpdateInvoiceinfo(x){
	
	var temp=document.updateInvoiceInfo.state;
	for (m=temp.options.length-1;m>0;m--)
		temp.options[m]=null;
	
	for (i=0;i<group[x].length;i++){
		temp.options[i]=new Option(group[x][i].text,group[x][i].value);
	}
	temp.options[0].selected=true;
}

function redirectUpdateCCinfo(x){
	
	var temp=document.updateCCInfo.ccState;
	for (m=temp.options.length-1;m>0;m--)
		temp.options[m]=null;
	
	for (i=0;i<group[x].length;i++){
		temp.options[i]=new Option(group[x][i].text,group[x][i].value);
	}
	temp.options[0].selected=true;
}

function redirectUpdateECheckinfo(x){
	
	var temp=document.updateDDInfo.state;
		for (m=temp.options.length-1;m>0;m--)
			temp.options[m]=null;
		
		for (i=0;i<group[x].length;i++){
			temp.options[i]=new Option(group[x][i].text,group[x][i].value);
		}
	temp.options[0].selected=true;
	
}

function resetUpdateCCInfo(pcName,pcCCNum,pcAddress,pcCity,month,year,piState,piCountry,pcZipcode){
	if(document.updateInfo.ccCountry!=null){
		if(piCountry == "US"){
			rePopulateState(0,document.updateInfo.ccState);
			document.updateInfo.ccCountry.options[0].selected=true;
		}
		else if(piCountry == "CA"){
			rePopulateState(1,document.updateInfo.ccState);
			document.updateInfo.ccCountry.options[1].selected=true;
		}
		else if(piCountry == "HT"){
			rePopulateState(2,document.updateInfo.ccState);
			document.updateInfo.ccCountry.options[2].selected=true;
		}
	}
	resetComboBoxes(document.updateInfo.ccState,piState);
	resetComboBoxes(document.updateInfo.month,month);
	resetComboBoxes(document.updateInfo.year,year);
	resetTextBoxes(document.updateInfo.pcName,pcName);
	resetTextBoxes(document.updateInfo.pcCCNum,pcCCNum);
	resetTextBoxes(document.updateInfo.pcAddress,pcAddress);
	resetTextBoxes(document.updateInfo.pcCity,pcCity);
	resetTextBoxes(document.updateInfo.pcZipcode,pcZipcode);
}

function resetUpdateInfo(niSalutation,nifirstName,nimiddleName,nilastName,niWorkPhone,niFax,niPager,niEmail,niJobTitle,niCompany,niHomePhone,piName,piPurchaseOrderNo,piAddress,piCity,piZipcode,piState,piCountry){
	resetComboBoxes(document.updateInfo.niSalutation,niSalutation);
	resetTextBoxes(document.updateInfo.nifirstName,nifirstName);
	resetTextBoxes(document.updateInfo.nimiddleName,nimiddleName);
	resetTextBoxes(document.updateInfo.nilastName,nilastName);
	resetTextBoxes(document.updateInfo.niWorkPhone,niWorkPhone);
	resetTextBoxes(document.updateInfo.niFax,niFax);
	resetTextBoxes(document.updateInfo.niPager,niPager);
	resetTextBoxes(document.updateInfo.niEmail,niEmail);
	resetTextBoxes(document.updateInfo.niJobTitle,niJobTitle);
	resetTextBoxes(document.updateInfo.niCompany,niCompany);
	resetTextBoxes(document.updateInfo.niHomePhone,niHomePhone);
	resetTextBoxes(document.updateInfo.piName,piName);
	resetTextBoxes(document.updateInfo.PurchaseOrder,piPurchaseOrderNo);
	resetTextBoxes(document.updateInfo.piAddress,piAddress);
	resetTextBoxes(document.updateInfo.piCity,piCity);
	resetTextBoxes(document.updateInfo.piZipcode,piZipcode);
	if(document.updateInfo.ccCountry1!=null){
		if(piCountry == "US"){
			rePopulateState(0,document.updateInfo.ccState1);
			document.updateInfo.ccCountry1.options[0].selected=true;
		}
		else if (piCountry == "CA"){
			rePopulateState(1,document.updateInfo.ccState1);
			document.updateInfo.ccCountry1.options[1].selected=true;
		}
		else if (piCountry == "HT"){
			rePopulateState(2,document.updateInfo.ccState1);
			document.updateInfo.ccCountry1.options[2].selected=true;
		}
	}
	resetComboBoxes(document.updateInfo.ccState1,piState);
}

function resetTextBoxes(fieldName,value){
	if(fieldName!=null)
		fieldName.value = value;
}

function resetComboBoxes(fieldName,value){
	if(fieldName!=null){
		for (i=0;i<fieldName.length;i++){
			if(fieldName.options[i].value== value ){
				fieldName.options[i].selected=true;
				break;
			}
		}
	}
}

function rePopulateState(x,comboToReset){
	if(comboToReset!=null){
		for (m=comboToReset.options.length-1;m>0;m--)
			comboToReset.options[m]=null;
		for (i=0;i<group[x].length;i++){
			comboToReset.options[i]=new Option(group[x][i].text,group[x][i].value);
		}
		comboToReset.options[0].selected=true;
	}
}

function resetUpdateInfo1(Address,City,Zipcode,State,Country){
	if(document.updateInfo.ccCountry!=null){
		if(Country == "US"){
			rePopulateState(0,document.updateInfo.ccState);
			document.updateInfo.ccCountry.options[0].selected=true;
		}
		else if(Country == "CA"){
			rePopulateState(1,document.updateInfo.ccState);
			document.updateInfo.ccCountry.options[1].selected=true;
		}
		else if(Country == "HT"){
		rePopulateState(2,document.updateInfo.ccState);
			document.updateInfo.ccCountry.options[2].selected=true;
		}
	}
	resetComboBoxes(document.updateInfo.ccState,State);
	resetTextBoxes(document.updateInfo.pcAddress,Address);
	resetTextBoxes(document.updateInfo.pcCity,City);
	resetTextBoxes(document.updateInfo.pcZipcode,Zipcode);
}
