/**********************************************************************************************
* Author:               Sunil Keyal
* Date:                 10/19/04
* Path:
* File Description:     This file contains help functions
*
* Functions
* ----------
*    openDSSHelpWin
*    openDSSAboutWin
**********************************************************************************************/

var help_context='';
var help_topic='';



/**********************************************************************************************
* Function Name: 	openDSSHelpWin
*     Opens the help window
*     helpURL is defined in style.jsp
*
***********************************************************************************************/
function openDSSHelpWin(help_context, help_topic, helpWin){

    finalHelpURL = helpURL+"?context="+help_context+"&topic="+help_topic;
    DSSHelpWin=window.open(finalHelpURL , "WWHFrame" , "width=1000,height=800,toolbar=no,scrollbars=yes,resizable=yes")  ;
}



/**********************************************************************************************
* Function Name: 	openDSSAboutWin
*   Opens the about window
*
***********************************************************************************************/
function openDSSAboutWin(){

    msgWindow=window.open("","About","width=300,height=30,toolbar=no,scrollbars=no,resizable=yes,menubar=no,location=no,directories=no")
    msgWindow.document.open("text/html","replace");
    msgWindow.document.write('<html><HEAD><TITLE>About DSS</TITLE></HEAD>');
    msgWindow.document.write('<BODY onClick="window.close()" bgcolor="#333399"><span STYLE="color: white; font-size: 14pt; font-family: Arial, Helvetica, sans-serif;">');
    msgWindow.document.write('<CENTER><b>DSS</b><br><br><span style="font-size:10pt">Release 9.0</span></CENTER>');
    msgWindow.document.write('</span></BODY></html>');
    msgWindow.focus();

}



