// This javascript provides collaspsible navigation menu capability

var head="display:''";
var ns6=document.getElementById&&!document.all;
var ie4=document.all&&navigator.userAgent.indexOf("Opera")==-1;
var foldercontentarray=new Array();
var c=0;
var nodelength=ns6? c-1 : foldinglist.length-1;

var openones='';

img1=new Image();
img1.src=foldImageURL;
img2=new Image();
img2.src=openImageURL;

/*
// This will set the initial cookie so that
// Menu will be expanded for the first time
var initialCookieValue='';
if (get_cookie("dss") == '') {
    initialCookieValue="dss=";
    for (i=0 ; i <= nodelength ; i++){
       initialCookieValue= initialCookieValue + i + " ";
    }
    document.cookie= initialCookieValue + ";path=/";
}
*/


// This function provides collapsible Menu
function checkcontained(e){
	var iscontained=0;
	cur=ns6? e.target : event.srcElement;
	i=0;
	if (cur.id=="foldheader"){
		iscontained=1;
	}
	else {
		while (ns6&&cur.parentNode||(ie4&&cur.parentElement)){
			if (cur.id=="foldheader"||cur.id=="foldinglist"){
				iscontained=(cur.id=="foldheader")? 1 : 0;
				break;
			}
			cur=ns6? cur.parentNode : cur.parentElement;
		}
	}

	if (iscontained){
		var foldercontent=ns6? cur.nextSibling.nextSibling : cur.all.tags("UL")[0];
		if (foldercontent.style.display=="none"){
			foldercontent.style.display="";
			cur.style.listStyleImage=openImageURL;
		}
		else{
			foldercontent.style.display="none";
			cur.style.listStyleImage=foldImageURL;
		}
	}
}



// This function returns the cookie
function get_cookie(Name) {
    var search = Name + "=";
    var returnvalue = "";
    if (document.cookie.length > 0) {
        offset = document.cookie.indexOf(search);
        // if cookie exists
        if (offset != -1) {
            offset += search.length;
            // set index of beginning of value
            end = document.cookie.indexOf(";", offset);
            // set index of end of cookie value
            if (end == -1) end = document.cookie.length;
            returnvalue=unescape(document.cookie.substring(offset, end));
        }
    }
    return returnvalue;
}



function checkit(){
    for (i=0 ; i <= nodelength ; i++){
        if ((ns6&&foldercontentarray[i].style.display=='')||(ie4&&foldinglist[i].style.display==''))
            openones=openones + " " + i;
    }
    document.cookie="dss="+openones+ ";path=/";
}


// This function starts the java script execution
// and starts the persistence in menu.
function menu_start() {
    document.onclick=checkcontained;

    if (ns6){
        for (i=0;i<document.getElementsByTagName("UL").length;i++){
            if (document.getElementsByTagName("UL")[i].id=="foldinglist"){
                foldercontentarray[c]=document.getElementsByTagName("UL")[i];
                c++;
            }
        }
    }
    if (get_cookie("dss") != ''){
        var openresults=get_cookie("dss").split(" ");
         for (i=0 ; i < openresults.length ; i++){
            if (ns6){
                foldercontentarray[openresults[i]].style.display='';
                foldercontentarray[openresults[i]].previousSibling.previousSibling.style.listStyleImage=openImageURL;
            }
            else {
                foldinglist[openresults[i]].style.display='';
                document.all[foldinglist[openresults[i]].sourceIndex -1].style.listStyleImage=openImageURL;
            }
        }
    }
    window.onunload=checkit;
}


menu_start();