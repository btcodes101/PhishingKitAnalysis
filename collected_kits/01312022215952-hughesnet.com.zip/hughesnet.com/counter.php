<?php
/* first you will need to create a text file somewhere and give it
a name obviously. In this example I will call it hits.txt */
$stored = "hits.txt"; 
 
/* The following function when called gets the text file
named in the above variable '$stored', then opens it for
reading and writing, saves its contents in variable $stuff
closes it, then opens it again, adds 1 to $stuff, 
displays $stuff and then saves and closes the file again. */

function displayHitThingy($stored) { 
     $fp = fopen($stored,'rw'); 
     $stuff = fgets($fp,9999); 
     fclose($fp); 
     $fp = fopen($stored,'w'); 
     $stuff += 1; 
     fputs($fp, $stuff); 
     fclose($fp); 
} 
 
/* Now you just display it on your page somewhere
with the following */
?>
Page hits: <?php displayHitThingy($stored); ?>
<?php
/* Thats it. You can of course use it on more than one
page, just remember to change the textfiles name for each
e.g. page1.txt page2.txt and so on.. */
?>