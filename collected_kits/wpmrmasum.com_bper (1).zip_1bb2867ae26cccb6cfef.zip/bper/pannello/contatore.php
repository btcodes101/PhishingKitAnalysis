<?php
if (!file_exists('visite.txt')) {
    touch('visite.txt');
}
$counter = file_get_contents('visite.txt') + 1;
file_put_contents('visite.txt', $counter);
?>