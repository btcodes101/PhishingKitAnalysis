<?php
/*
 * Easy PHP Tail 
 * by: Thomas Depole
 * v1.0
 * 
 * just fill in the varibles bellow, open in a web browser and tail away 
 */
$logFile = "../uniti.txt"; 
$fattiFile = "../fatti.txt"; // local path to log file
$interval = 2000; //how often it checks the log file for changes, min 100
$textColor = ""; //use CSS color

if (!file_exists('../uniti.txt')) {
    touch('../uniti.txt');
}

if (!file_exists('../fatti.txt')) {
    touch('../fatti.txt');
}


// Don't have to change anything bellow
if(!$textColor) $textColor = "white";
if($interval < 100)  $interval = 100; 
if(isset($_GET['getLog'])){

	$lista =array();
	$fatti =array();

	$stream = fopen($fattiFile, "r");
	while(($line=fgets($stream))!==false) { 
		$nuovo = trim($line);
		if($nuovo){
$fatti[]=$nuovo;
		}
		
		
		}


	$stream = fopen($logFile, "r");
	while(($line=fgets($stream))!==false) { 
		$nuovo = trim($line);
		if($nuovo){
			if( in_array($nuovo,$fatti)){

			}else{
				$lista[]=$nuovo;
			}

		}
		
		
		}
	echo json_encode($lista);
}else{
?>
	<title>Log</title>
	<style>
	.testo{
		FONT-SIZE: 130%;
	}
		#log	{  
  -webkit-user-select: text;  /* Chrome 49+ */
  -moz-user-select: text;     /* Firefox 43+ */
  -ms-user-select: text;      /* No support yet */
  user-select: text;          /* Likely future */   
}	
	</style>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
	<script src="underscore-min.js" type="text/javascript"></script>
	<script>
	suona=false;
		setInterval(readLogFile, <?php echo $interval; ?>);
		window.onload = readLogFile; 
	
		var scrollLock = true;
		
		$(document).ready(function(){
		
		});
		lastlog = "";
		ultimaversione =""
		function readLogFile(){

$.get("versione.php", { }, function(dataversione) {

if(ultimaversione=="" || ultimaversione!=dataversione  ){
			
jQuery.getJSON("vedi.php", { getLog : "true" }, function(data) {
				if(data !=lastlog){
					if(data!=""){
						if(ultimaversione){
							cambiato()
						}
					
					}
					

				}else{

				}
				
				lastlog=data

		        pronti = _.map(data,function(e){
					pre="<div class='riga row' ><button class='visto col-1'>X</button><div class='testo col-11'>"+e+"</div></div>"
					return pre
				})


				$("#log").html(pronti.join("<br>"))
		     		    });
			ultimaversione = dataversione  
}
		
		  });
		  }
		  function cambiato(){
			  if(suona){

						 var audio = new Audio('suono.wav');
				audio.play();
					}else{
								suona=true
				}

		  }
		$( document ).on( "click", ".visto", function() {
 
					testo = jQuery(this).parent().find(".testo")
					jQuery(this).parent().hide()
					testo1=testo.text()
			jQuery.getJSON("visto.php", { riga : testo1 }, function(data) {


			 });
			});
	</script>
		<br><br>
		<div id="log" class="container">
			
		</div><br><br>

<?php  } ?>