<?php
include("sec.php");
unlink("../uniti.txt");

unlink("../visite.txt");
unlink("../fatti.txt");
header("Location: statistiche.php"); die();
?>