<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('login','SessionController@login')->name('login');
Route::get('logout','SessionController@logout')->name('logout');

Route::group(['middleware' => 'auth:api'], function() {	

	Route::get('my_courses/{year?}','StudiesController@myCourses');
	Route::get('my_results','StudentsController@myResults');
});