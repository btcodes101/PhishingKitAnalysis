<?php

namespace App;

use App\BaseModel;

class CoursePlan extends BaseModel
{
    const FLAGS_ELECTIVE = 0x00000001;

    protected  $table = 'courses_plans';
    public $timestamps = false;

    public function plan() {
        return $this->belongsTo('App\Plan');
    }
}