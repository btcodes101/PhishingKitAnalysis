<?php

namespace App;

use App\ExcuseHistory;

use Illuminate\Database\Eloquent\Model;

class Excuse extends Model
{
    protected $fillable = ['excuse_type_id', 'term_id', 'period_from', 'period_to', 'reasons', 'created_at', 'updated_at'];

    const STATUS_INCOMPLETE = -1;
    const STATUS_PAPER_AUTHENTICATED = 0;
    
    CONST STATUS_WAITING_FOR_PROGRAM_DIRECTOR = 1;
    CONST STATUS_WAITING_FOR_STUDENT_AFFAIRS_COMMITTEE = 2;
    CONST STATUS_WAITING_FOR_COUNCIL_OF_THE_FACULTY = 3;

    /*const STATUS_IN_PROGRESS = 1;
    const STATUS_NEED_UPDATE = 2;
    const STATUS_UPDATED = 3;*/

    const STATUS_ACCEPTED = 4;
    const STATUS_REJECTED = 5;
    const STATUS_CANCELED = 6;
    const STATUS_NO_RESPONSE = 7;
    const STATUS_NEEDS_MORE_DOCUMENTS = 8;
    
   
    public static function statusLabels() {
        return [
            Excuse::STATUS_INCOMPLETE => 'Incomplete',
            Excuse::STATUS_PAPER_AUTHENTICATED => 'Paper Authenticated',
            
            Excuse::STATUS_WAITING_FOR_PROGRAM_DIRECTOR => 'Waiting for the program director',
            Excuse::STATUS_WAITING_FOR_STUDENT_AFFAIRS_COMMITTEE => 'Waiting for the student affairs committee',
            Excuse::STATUS_WAITING_FOR_COUNCIL_OF_THE_FACULTY => 'Waiting for the council of the faculty',


            /*Excuse::STATUS_IN_PROGRESS => 'In Progress',
            Excuse::STATUS_NEED_UPDATE => 'Need Update',
            Excuse::STATUS_UPDATED => 'Updated',*/
            
            Excuse::STATUS_ACCEPTED => 'Accepted',
            Excuse::STATUS_REJECTED => 'Rejected',
            Excuse::STATUS_CANCELED => 'Canceled',
            Excuse::STATUS_NO_RESPONSE => 'No Response',

            Excuse::STATUS_NEEDS_MORE_DOCUMENTS => 'Needs More Documents',
        ];
    }

    public static function statusBadges() {
        return [
            Excuse::STATUS_INCOMPLETE => 'light',
            Excuse::STATUS_PAPER_AUTHENTICATED => 'secondary',
            
            Excuse::STATUS_WAITING_FOR_PROGRAM_DIRECTOR => 'primary',
            Excuse::STATUS_WAITING_FOR_STUDENT_AFFAIRS_COMMITTEE => 'primary',
            Excuse::STATUS_WAITING_FOR_COUNCIL_OF_THE_FACULTY => 'primary',

            /*Excuse::STATUS_IN_PROGRESS => 'primary',
            Excuse::STATUS_NEED_UPDATE => 'dark',
            Excuse::STATUS_UPDATED => 'primary',*/
           
            Excuse::STATUS_ACCEPTED => 'success',
            Excuse::STATUS_REJECTED => 'danger',
            Excuse::STATUS_CANCELED => 'danger',
            Excuse::STATUS_NO_RESPONSE => 'danger',

            Excuse::STATUS_NEEDS_MORE_DOCUMENTS => 'primary',

            

            
        ];
    }
    public function excuseCourses() {
        //return $this->hasMany(ExcuseCourse::class, 'excuse_id');
        return $this->belongsToMany(Course::class, 'excuse_courses');
    }

    public function excuseMessages() {
        return $this->hasMany(ExcuseMessage::class, 'excuse_id');
    }

    public function files(){
        return $this->hasMany('App\Archive', 'parent_id', 'archive_id')->orderBy('order', 'asc')->orderBy('id', 'asc');
    }

    public function excuseType()
    {
        return $this->belongsTo(ExcuseType::class, 'excuse_type_id','id');
    } 

    public function term()
    {
        return $this->belongsTo(Term::class, 'term_id','id');
    }
    
    public function canDiscuss()
    {
        if($this->status == Excuse::STATUS_REJECTED || 
            $this->status == Excuse::STATUS_ACCEPTED || 
            $this->status == Excuse::STATUS_CANCELED || 
            $this->status == Excuse::STATUS_NO_RESPONSE
        ){
            return false;
        }

        return true;
    }

    public function MyExcuse()
    {
        if($this->student_id ==  auth()->id())
            return true;
        else
            return false;
    }

    public function logExcuseAction($action, $comment)
    {
        $excuse_history = new ExcuseHistory;

        $excuse_history->excuse_id = $this->id;
        $excuse_history->user_id = (auth()->user()->id)?auth()->user()->id:0;
        $excuse_history->action = $action;
        $excuse_history->action_comment = $comment; 

        $excuse_history->save();

        return true;
    }

    static function isExcusedTerm($student_id, $term_id)
    {
        //check if the student has an accepted excuse for this term
        $excuse = Excuse::where('student_id', $student_id)
                            ->where('term_id', $term_id)
                            ->where('excuse_type_id', 5) //5: is the id of term excuse
                            ->where('status', Excuse::STATUS_ACCEPTED)
                            ->first();

        if($excuse)
            return true;

        return false;
    }
    

}
