<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentTrainingMessage extends Model
{
    protected $table = 'student_training_messages';

    

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function files(){
        return $this->hasMany('App\Archive', 'parent_id', 'archive_id')->orderBy('order', 'asc')->orderBy('id', 'asc');
    }
}
