<?php

namespace App;

use BaseModel\Model;

class ExternalProgram extends BaseModel {

    protected $table = 'external_programs';
    
    public function plans(){
        return $this->belongsToMany('App\Plan', 'external_programs_plans', 'external_program_id', 'plan_id');
    }
}
