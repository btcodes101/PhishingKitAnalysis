<?php

namespace App;

use BaseModel\Model;

class ArchiveUser extends BaseModel
{
    protected $table = 'archive_users';
    public $timestamps = false;

    public function archive() {
        return $this->belongsTo('App\Archive', 'archive_id', 'id');
    }
}
