<?php

namespace App;

use BaseModel\Model;
use App\StudentResearchStage;

class StudentResearch extends BaseModel {

    protected $table = 'students_research';

    const STATUS_SUBMITTED              = 0x00000001;
    const STATUS_REGISTERED             = 0x00000010;
    const STATUS_DISCUSSED              = 0x00010000;

    protected $guarded = [];

    public $timestamps = false;

     protected $fillable = [
        'en_title',
        'ar_title',
        'research_plan_id',
    ];

    public static function statusLabels() {
        return [
            StudentResearch::STATUS_SUBMITTED => 'Submitted',
            StudentResearch::STATUS_REGISTERED => 'Registered',
            StudentResearch::STATUS_DISCUSSED => 'Discussed',
        ];
    }

    public function researchPlan() {
        return $this->belongsTo('App\ResearchPlan');
    }

    public function submittedBy() {
        return $this->belongsTo('App\User', 'submitted_by', 'id');
    }

    public function isSubmitted() {
        return (($this->status&StudentResearch::STATUS_SUBMITTED)!=0);
    }

    public function isRegistered() {
        return (($this->status&StudentResearch::STATUS_REGISTERED)!=0);
    }

    public function isDiscussed() {
        return (($this->status&StudentResearch::STATUS_DISCUSSED)!=0);
    }

    public function canUpdate() {

        //There should be no stages tell now
        if($this->currentStage())
            return false;

        return $this->isSubmitted();
    }

    public function canRegister() {
        
        if($this->isDiscussed() || $this->isRegistered())
            return false;
        
        if($this->isCurrentStageApproved())
            return false;

        return $this->isSubmitted();
    }

    public function undo() {
        $stage = $this->currentStage();
        if($stage->approved==0 && auth()->id()==$stage->submitted_by) {
            switch($stage->stage_code) {
                case 'registration': $this->status &= ~(StudentResearch::STATUS_REGISTERED); break;
                case 'discussion': $this->status &= ~(StudentResearch::STATUS_DISCUSSED); break;
            }
            $stage->delete();
            $this->save();
        }
        if($stage->approved==1 && auth()->id()==$stage->offical_approval_reported_by) {
            $stage->approved = 0;
            $stage->offical_approval_reported_by = $stage->department_approval_at = $stage->faculty_approval_at = $stage->university_approval_at = null;
            $stage->save();
            return true;
        }

        return false;
    }

    public function canUndo() {
        $stage = $this->currentStage();
        if(empty($stage)) return false;
        if($stage->approved==0 && auth()->id()==$stage->submitted_by)
            return true;
        if($stage->approved==1 && auth()->id()==$stage->offical_approval_reported_by)
            return true;

        return false;
    }

    public function canChange() {
        
        if($this->isDiscussed() || !$this->isCurrentStageApproved())
            return false;

        return $this->isRegistered();
    }

    public function canDiscuss() {

        if($this->isDiscussed() || !$this->isCurrentStageApproved())
            return false;

        return $this->isRegistered();
    }

    public function isCurrentStageApproved() {
        $stage = $this->currentStage();
        if(empty($stage)) return false;
        return ($stage->approved==1);
    }

    public function canApproveCurrentStage() {
        $stage = $this->currentStage();
        if(empty($stage)) return false;

        return ($stage->approved==0);
    }

    public function members() {
        return $this->hasMany('App\StudentResearchMember')->whereIn('role', [1, 2])->orderBy('role')->orderBy('order');
    }

    public function supervisors() {
        return $this->hasMany('App\StudentResearchMember')->where('role', 1)->orderBy('order');
    }

    public function supervisor($i) {
        if($i>=count($this->supervisors))return null;
        return $this->supervisors[$i];
    }

    public function committee() {
        return $this->hasMany('App\StudentResearchMember')->where('role', 2)->orderBy('role');
    }

    public function stages() {
        return $this->hasMany('App\StudentResearchStage', 'research_id', 'id')->orderBy('id');
    }

    public function stage($code) {
        return StudentResearchStage::where('research_id', $this->id)->where('stage_code', $code)->first();
    }

    public function currentStage() {
        return StudentResearchStage::where('research_id', $this->id)->orderBy('id', 'DESC')->first();
    }
}
