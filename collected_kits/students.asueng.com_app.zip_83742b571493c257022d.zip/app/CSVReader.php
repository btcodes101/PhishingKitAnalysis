<?php

namespace App;

use App\BaseModel;

class CSVReader extends BaseModel
{
    function __construct($file, $fields, $separator, $maxLineLength) {
        $this->file = $file;
        $this->fields = $fields;
        $this->separator = $separator;
        $this->maxLineLength = $maxLineLength;
        $this->nRows = 0;
    }

    function __destruct() {
        fclose($this->file);
    }

    public static function open($filePath, $separator = ",", $maxLineLength = 1000) {
        
        $file = fopen($filePath, "r");
        if(empty($file))return false;
        $fields = fgetcsv($file, $maxLineLength, $separator);
        if(empty($fields))return false;
        return new CSVReader($file, $fields, $separator, $maxLineLength);
    }

    public function next() {

        $data = fgetcsv($this->file, $this->maxLineLength, $this->separator);
        if(empty($data))return false;
        if(count($data)!=count($this->fields))return false;

        $row = (object)[];
        for ($c=0; $c < count($data); $c++) {
            $row->{$this->fields[$c]} = $data[$c];
        }
        $this->nRows++;

        return $row;
    }
} 