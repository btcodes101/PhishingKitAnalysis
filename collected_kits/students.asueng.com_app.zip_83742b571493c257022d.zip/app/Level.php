<?php

namespace App;

use App\BaseModel;

class Level extends BaseModel
{
	public $timestamps = false;
	
}
