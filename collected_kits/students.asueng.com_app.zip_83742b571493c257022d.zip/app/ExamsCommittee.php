<?php

namespace App;

use App\ProctoringCommitteeProctor;
use Illuminate\Database\Eloquent\Model;

class ExamsCommittee extends Model {

    const PAGE_LENGTH = 9;

    protected $table = 'exams_committees';

    protected $fillable = [
        'exams_id',
        'exams_date_id',
        'period',
        'course_id',
        'plan_id',
        'course_exam_type',
        'location_id',
        'delivery_id',
        'num_students',
        'extended_periods' ];

    public function exam(){
        return $this->belongsTo('App\Exams' , 'exams_id','id');
    }

    public function examsDate(){
        return $this->belongsTo('App\ExamsDate', 'exams_date_id', 'id');
    }

    public function course(){
        return $this->belongsTo('App\Course' , 'course_id','id');
    }

    public function committee(){
        return $this->belongsTo('App\Committee' , 'committee_id','id');
    }

    public function plan(){
        return $this->belongsTo('App\Plan' , 'plan_id','id');
    }

    public function linked(){
        return $this->belongsTo('App\ExamsCommittee' , 'linked_id','id');
    }

    public static function allocatePlanCourse($examsId, $examsDateId, $period, $extendedPeriods, $locationsIds, $courseId, $planId, $nStudents, $courseExamType) {

        $exams = Exams::find($examsId);

        $committee = Committee::locate($courseId, $planId, $exams->term_id, null, false);

        $nStudents = ($nStudents!==null)?$nStudents:Study::where('role', Study::ROLE_STUDENT)->where('course_id', $courseId)->where('plan_id', $planId)->where('term_id', $exams->term_id)->count();

        $allocated = 0;
        foreach ($locationsIds as $locationId) {

            $required = $nStudents - $allocated;
            $examsCommittee = ExamsCommittee::allocate($examsId, $examsDateId, $period, $extendedPeriods, $locationId, $committee->id, $courseId, $planId, $required, $courseExamType);
            if($examsCommittee)
                $allocated += $examsCommittee->num_students;
        }

        return true;
    }

    public static function allocate($examsId, $examsDateId, $period, $extendedPeriods, $locationId, $committeeID, $courseId, $planId, $required, $courseExamType) {

        $capacity = FacultyLocation::find($locationId)->capacity;

        $allocated = ExamsCommittee::where('exams_id', $examsId)
            ->where('exams_date_id', $examsDateId)
            ->where('period', $period)
            ->where('location_id', $locationId)
            ->whereRaw(\DB::raw("NOT (course_id=$courseId AND plan_id=$planId)"))
            ->sum('num_students');

        $examsCommittee = ExamsCommittee::where('exams_id', $examsId)
            ->where('exams_date_id', $examsDateId)
            ->where('period', $period)
            ->where('location_id', $locationId)
            ->where('committee_id', $committeeID)
            ->where('course_id', $courseId)
            ->where('plan_id', $planId)
            ->first();

        $avaliable = $capacity - $allocated;
        if($avaliable<0) $avaliable = 0;
        if($avaliable<$required)
            $required = $avaliable;

        if(empty($examsCommittee)) {
            $examsCommittee = new ExamsCommittee();
        }

        $examsCommittee->exams_id = $examsId;
        $examsCommittee->exams_date_id = $examsDateId;
        $examsCommittee->period = $period;
        $examsCommittee->extended_periods = $extendedPeriods;
        $examsCommittee->course_exam_type = $courseExamType;
        $examsCommittee->location_id = $locationId;
        $examsCommittee->committee_id = $committeeID;
        $examsCommittee->course_id = $courseId;
        $examsCommittee->plan_id = $planId;
        $examsCommittee->num_students = $required;
        $examsCommittee->save();
        $examsCommittee->updateExtendedPeriods();

        return $examsCommittee;
    }

    public function updateExtendedPeriods() {
        \DB::statement("DELETE FROM exams_committees WHERE linked_id = $this->id;");

        if($this->extended_periods==0)
            return;

        if( ($this->extended_periods+$this->period) > $this->exam->max_periods )
            return;

        for($i=1;$i<=$this->extended_periods;$i++) {
            $committeeCourse = $this->replicate();
            $committeeCourse->period = $this->period + $i;
            $committeeCourse->linked_id = $this->id;
            $committeeCourse->save();
        }
    }

    public static function locations($examsId, $examsDateId, $period) {
        return \DB::select(\DB::raw("SELECT T.*, faculty_locations.name as location_name, faculty_buildings.name as building_name, faculty_locations.capacity FROM (SELECT location_id, sum(num_students) as students FROM exams_committees WHERE exams_id = $examsId AND exams_date_id = $examsDateId AND period = $period GROUP BY location_id) AS T INNER JOIN faculty_locations ON faculty_locations.id = T.location_id INNER JOIN faculty_buildings ON faculty_buildings.id = faculty_locations.building_id;"));
    }

    public static function exams($examsId, $termId, $examsDateId, $period) {
        
        $majorField = lang()."_major";
        $minorField = lang()."_minor";
        $nameField = lang()."_name";
        $student = Study::ROLE_STUDENT;

        return \DB::select(\DB::raw("SELECT T.*, courses.code, plans.bylaw, plans.$majorField  as major, plans.$minorField as minor, years.$nameField as year, (SELECT count(*) FROM studies WHERE course_id = T.course_id AND role=$student AND term_id = $termId AND plan_id = T.plan_id) as total FROM (SELECT course_id, plan_id, course_exam_type, sum(num_students) as students FROM exams_committees WHERE exams_id = $examsId AND exams_date_id = $examsDateId AND period = $period GROUP BY course_id, plan_id, course_exam_type) AS T INNER JOIN courses ON courses.id = T.course_id INNER JOIN plans ON plans.id = T.plan_id INNER JOIN years ON years.id = plans.year_id;"));
    }

    /*Trashnext
    public static function getExaminers($termId, $courseId, $planId, $role) {

        $query = Study::select('users.id','users.ar_name', 'users.en_name','users.mobile', 'instructors.degree')
            ->leftJoin('users','users.id' , '=' , 'studies.user_id')
            ->leftJoin('instructors','instructors.id' , '=' , 'users.id')
            ->where('term_id', $termId)
            ->where('course_id', $courseId)
            ->where('role', $role);

        //If the plan specified and there is an instructor assigned to this plan
        if(!empty($planId)) {
            $finalQuery = clone $query;
            $result = $finalQuery->where('plan_id', $planId)->get();
            if(count($result->toArray())>0) return $result;
        }

        return $query->get();
    }
    */

    public static function getDeliveriesLength($examsId, $examsDataId, $period) {
        return ExamsCommittee::where(['exams_id' => $examsId , 'exams_date_id' => $examsDataId ,'period' => $period])->groupBy('course_id')->count();
    }

    public static function getDeliveriesData($examsId, $examsDataId, $period) {

        return ExamsCommittee::select('years.ar_name as year', 'exams_committees.committee_id', 'courses.id as course_id' ,'plans.id as plan_id' , 'courses.ar_name' ,'courses.en_name','courses.code', 'courses.bylaw', 'bylaws.ar_name as bylaw_name' , 'plans.ar_minor' , 'plans.ar_major' ,'exams_committees.num_students','exams_committees.exam_time','exams_committees.extended_periods', 'exams_committees.course_exam_type', 'exams.term_id')
            ->join('courses' , 'courses.id' , '=' , 'exams_committees.course_id' )
            ->join('bylaws' , 'bylaws.code' , '=' , 'courses.bylaw' )
            ->join('exams' , 'exams.id' , '=' , 'exams_committees.exams_id' )
            ->leftJoin('plans' , 'plans.id' , '=' , 'exams_committees.plan_id' )
            ->leftJoin('years' , 'years.id' , '=' , 'plans.year_id' )
            ->groupBy('exams_committees.course_id')
            ->groupBy('exams_committees.plan_id')
            ->groupBy('exams_committees.course_exam_type')
            ->where(['exams_committees.exams_id' => $examsId , 'exams_committees.exams_date_id' => $examsDataId , 'exams_committees.period' => $period])
            ->where('courses.current', 1)
            ->where('exams_committees.linked_id', 0)
            ->orderBy('plans.bylaw')->orderBy('exams_committees.course_exam_type')->orderBy('plans.year_id')->orderBy('courses.id')->get();
    }
    
    public static function getDeliveriesLocations($examsId, $examsDateId, $period, $courseId, $planId, $courseExamType = null) {
        
        $query = ExamsCommittee::select('faculty_locations.name' ,'exams_committees.num_students')
                ->where('exams_id' , $examsId)
                ->where('exams_date_id', $examsDateId)
                ->where('course_id', $courseId)
                ->where('period', $period)                
                ->join('faculty_locations','faculty_locations.id','=','exams_committees.location_id')
                ->orderBy('faculty_locations.name');

        if(!empty($courseExamType))
            $query->where('course_exam_type', $courseExamType);

        if(!empty($planId))
            $query->where('plan_id', $planId);
        
        return $query->get();
    }

    public static function getLocations($examsDateId, $period, $planId) {
        return ExamsCommittee::where('exams_date_id', $examsDateId)
            ->where('period', $period)
            ->where('plan_id', $planId)
            ->join('faculty_locations', 'faculty_locations.id', '=', 'exams_committees.location_id')
            ->get();
    }

    public static function allocatedPerCourse($examsId, $examsDateId, $period, $courseId) {
        return FacultyLocation::select(
            'faculty_locations.id',
            'faculty_locations.name as location_name',
            'faculty_buildings.name as building_name',
            'faculty_locations.capacity',
            'T.allocated')
            ->join(\DB::raw("(SELECT location_id, sum(num_students) as allocated FROM `exams_committees` WHERE exams_id = $examsId AND exams_date_id = $examsDateId AND period = $period  AND course_id = $courseId GROUP BY location_id) AS T"),  function($join) {
                $join->on('faculty_locations.id', '=', 'T.location_id');
            })
            ->join('faculty_buildings', 'faculty_locations.building_id', '=', 'faculty_buildings.id')
            ->first();
    }

    public static function allStudentsPerCourse($examsId, $examsDateId, $period, $courseExamType, $courseId, $planId) {
        return ExamsCommittee::where('exams_id','=',$examsId)
            ->where('exams_date_id','=',$examsDateId)
            ->where('period','=',$period)
            ->where('course_exam_type','=',$courseExamType)
            ->where('course_id','=',$courseId)
            ->where('plan_id', '=', $planId)
            ->sum('num_students');
    }

    public static function allocatedPerLocation($examsId, $examsDateId, $period, $locationId) {
        return FacultyLocation::select(
            'faculty_locations.id',
            'faculty_locations.name as location_name',
            'faculty_buildings.name as building_name',
            'faculty_locations.capacity',
            'T.allocated')
            ->join(\DB::raw("(SELECT location_id, sum(num_students) as allocated FROM `exams_committees` WHERE exams_id = $examsId AND exams_date_id = $examsDateId AND period = $period AND location_id = $locationId GROUP BY location_id) AS T"),  function($join) {
                $join->on('faculty_locations.id', '=', 'T.location_id');
            })
            ->join('faculty_buildings', 'faculty_locations.building_id', '=', 'faculty_buildings.id')
            ->first();
    }

    /*Trashnext
    public staticTrashnext function getExaminersCount($courseId, $planId, $role, $termId) {

        $query = Study::select('users.ar_name', 'users.mobile')
            ->leftJoin('users','users.id' , '=' , 'studies.user_id')
            ->where('course_id', $courseId)            
            ->where('term_id', $termId)
            ->where('role', $role);

        //If the plan specified and there is an instructor assigned to this plan
        if(!empty($planId)) {
            $finalQuery = clone $query;
            $count = $finalQuery->where('plan_id', $planId)->count();
            if($count>0) return $count;
        }

        return  $query->count();
    }
    */

    public function location() {
        return $this->belongsTo('App\FacultyLocation', 'location_id', 'id');
    }

    public function similar($planId = null) {

        $query = ExamsCommittee::where('exams_id', $this->exams_id)->where('exams_date_id', $this->exams_date_id)->where('period', $this->period)->where('committee_id', $this->committee_id);

        return $query->get();
    }

    public function locationCourses(){
        return ExamsCommittee::select('*')
            ->where('exams_id', $this->exams_id)
            ->where('exams_date_id', $this->exams_date_id)
            ->where('period', $this->period)
            ->where('location_id', $this->location_id)
            ->get();
    }

    public function proctors() {
        return ProctoringCommitteeProctor::select('proctoring_committees_proctors.*')
            ->join('instructors', 'instructors.id', 'proctoring_committees_proctors.staff_id')
            ->join('instructors_degrees', 'instructors_degrees.code', 'instructors.degree')
            ->where('exams_id', $this->exams_id)
            ->where('exams_date_id', $this->exams_date_id)
            ->where('period', $this->period)
            ->where('location_id', $this->location_id)
            ->orderBy('proctoring_committees_proctors.position', 'ASC')
            ->orderBy('instructors_degrees.id', 'DESC')
            ->orderBy('seniority', 'ASC')
            ->get();
    }

    public function instructors() {
        $teachers = $this->committee->teachers()->select('users.id','users.ar_name', 'users.en_name','users.mobile', 'instructors.degree')->leftJoin('instructors','instructors.id' , '=' , 'users.id')->get();
        return $teachers;
    }

    public function planLabel() {

        $label = strtoupper($this->course->getBylaw->lang('name'));
        if(!empty($this->plan_id))
            $label .= " - ".$this->plan->name();
        return $label;
    }

    public static function allocatedPerCommittee($committeeID) {
        return BaseModel::evalSQLValue("SELECT sum(num_students) as value FROM exams_committees WHERE committee_id = $committeeID");
    }
}
