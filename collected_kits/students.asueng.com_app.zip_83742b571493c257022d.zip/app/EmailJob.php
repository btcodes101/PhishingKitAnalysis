<?php

namespace App;

use App\User;
use App\Archive;
use App\BaseModel;
use Carbon\Carbon;

class EmailJob extends BaseModel
{
    protected $table = 'email_jobs';

    public function emailMessage(){
        return $this->belongsTo('App\EmailMessage');
    }
}