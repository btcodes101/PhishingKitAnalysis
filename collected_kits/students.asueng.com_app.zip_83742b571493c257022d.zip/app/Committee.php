<?php

namespace App;

use BaseModel\Model;
use DB;

class Committee extends BaseModel {

    const TYPE_REGULARE = 0;
    const TYPE_CHEP = 1;
    const TYPE_TAKHALOF = 2;

    const FLAG_PASS_FAIL        = 0x00000001;
    const FLAG_COURSE_FILES     = 0x00000002;
    const FLAG_QUESTIONNAIRE    = 0x00000004;

    const CONTROL_STATUS_DRAFT = 0;
    const CONTROL_STATUS_SUBMITTED = 1;
    const CONTROL_STATUS_ACCEPTED = 2;
    const CONTROL_STATUS_APPROVED = 3;
    const CONTROL_STATUS_PUBLISHED = 4;
    const CONTROL_STATUS_FREEZED = -1;


    protected $table = 'committees';
    protected $guarded = [];
    public $timestamps = false;

    public function course(){
        return $this->belongsTo('App\Course');
    }

    public function term(){
        return $this->belongsTo('App\Term');
    }

    private function studiesQuery($withChildrenCommittees) {

        $committeesIDs = [];
        if($withChildrenCommittees) {
            $committeesIDs = Committee::where('parent_committee_id', $this->id)->pluck('id')->toArray();
        }
        $committeesIDs = array_merge($committeesIDs, [$this->id]);
        
        $query = Study::where('term_id', $this->term_id);
        $query->whereIn('committee_id', $committeesIDs);
        return $query;
    }

    public function studies($withChildrenCommittees = false) {
        return $this->studiesQuery($withChildrenCommittees)->get();
    }

    public function nStudents($withChildrenCommittees = false) {
        return $this->studiesQuery($withChildrenCommittees)->count();
    }

    public function parent() {
        return $this->belongsTo('App\Committee', 'parent_committee_id', 'id');
    }

    public function children() {
        return $this->hasMany('App\Committee', 'id', 'parent_committee_id');
    }

    public function committeesPlans() {
        return $this->hasMany('App\CommitteePlan');
    }

    public function committeesInstructors() {
        return $this->hasMany('App\CommitteeInstructor');
    }

    public function committeeInstructor($instructorID) {
        return $this->committeesInstructors()->where('instructor_id', $instructorID)->first();
    }

    public function plans() {
        return $this->belongsToMany( 'App\Plan', 'committees_plans', 'committee_id', 'plan_id');
    }

    public function similar() {
        $plansIds = $this->committeesPlans()->pluck('plan_id')->toArray();
        $otherCommittees = Committee::where('id', '!=', $this->id)->where('term_id', $this->term_id)->where('course_id', $this->course_id)->where('type', $this->type)->get();
        
        //If has no plan, so other committees for same term/course are similar
        if(count($plansIds)==0 && count($otherCommittees)>0) return $otherCommittees;

        //If has plan, find other committees for same term/course/plan
        $similarCommittees = [];
        foreach ($otherCommittees as $otherCommittee) {
            $otherPlansIds = $otherCommittee->committeesPlans()->pluck('plan_id')->toArray();
            if(count($otherPlansIds)==0) $similarCommittees[] = $otherCommittee;
            $commonPlansIds = array_intersect($otherPlansIds, $plansIds);
            if(count($commonPlansIds)>0) $similarCommittees[] = $otherCommittee;
        }

        return $similarCommittees;
    }

    public function syncLMS($syncInstructors = false, $syncStudents = false) {
        
        $course = $this->course;
        
        $usersInfo = [];
        $plansIds = [];
        $description = "Course Committee: #".$this->id;
        $description .= "\nCourse Code: ".$course->short_name;
        $description .= "\nCourse Name: ".$course->en_name;
        $description .= "\nTerm: ".$this->term->en_name;
        $description .= "\nPlans: ";

        //Get plans ids and create extended code form plans short names if needed
        $committeesPlans = $this->committeesPlans;
        foreach ($committeesPlans as $committeePlan) {
            if(empty($committeePlan->plan))continue;
            $plansIds[] = $committeePlan->plan->id;
            $description .= "\n".$committeePlan->plan->name();
        }

        //Get Instructors Enroll Information
        $committeesInstructors = $this->committeesInstructors;
        if($syncInstructors) {
            foreach($committeesInstructors as $committeeInstructor) {
                $userInfo = (object)[];
                $userInfo->email = $committeeInstructor->user->email;
                $userInfo->name = $committeeInstructor->user->en_name;
                $userInfo->code = $committeeInstructor->user->code;
                $userInfo->role = "";
                switch($committeeInstructor->role) {
                    case Study::ROLE_TEACHER: $userInfo->role = "editingteacher"; break;
                    case Study::ROLE_EXAMINAR_COMMITTEE: $userInfo->role = "teacher"; break;
                    case Study::ROLE_TEACHING_ASSISTANT: $userInfo->role = "teacher"; break;
                }

                if(array_key_exists($usersInfo, $usersInfo)) {
                    $existingUserInfo = $usersInfo[$userInfo->email];
                    if($userInfo->role == "editingteacher") {
                        $usersInfo[$userInfo->email] = $userInfo;
                    }
                }
                else  {
                    $usersInfo[$userInfo->email] = $userInfo;
                }                
            }
        }

        //Get Studnets Enroll Information
        $studies = $this->studies(true);
        if($syncStudents) {
            foreach($studies as $study) {
                $userInfo = (object)[];
                $userInfo->email = $study->user->email;
                $userInfo->name = $study->user->en_name;
                $userInfo->code = $study->user->code;
                $userInfo->role = "student";
                $usersInfo[] = $userInfo;
            }
        }

        $similarCommittees = $this->similar();
        if(count($studies)==0 || count($committeesInstructors)==0 || count($similarCommittees)>0) {
            d("Incomplete committee:".$this->course->lmsName());
            return;
        } 

        LMS::syncCourse($this, $description, $usersInfo);
    }

    public static function locate($courseID, $planID, $termID, $type, $createIfNotFound) {

        $query = Committee::select('committees.*')
        ->join('committees_plans', 'committees_plans.committee_id', 'committees.id')
        ->where('committees_plans.plan_id', $planID)
        ->where('committees.term_id', $termID)
        ->where('committees.course_id', $courseID);
        if($type!==null) {
            $query->where('committees.type', $type);
        }        
        $committee = $query->first();

        if($committee) return $committee;

        $query = Committee::select('committees.*')
        ->leftJoin('committees_plans', 'committees_plans.committee_id', 'committees.id')
        ->where('committees.term_id', $termID)
        ->where('committees.course_id', $courseID)
        ->whereNull('committees_plans.plan_id');
        if($type!==null) {
            $query->where('committees.type', $type);
        }        
        $committee = $query->first();

        if($committee && $createIfNotFound===false) return $committee;

        //if creation is not allowed and committee not found return null.
        if($committee===null && $createIfNotFound==false) {
            dbg("Missing SIS committee (courseID:$courseID, planID:$planID, termID:$termID).");
            return null;
        }

        $query = Committee::select('committees.*')
        ->leftJoin('committees_plans', 'committees_plans.committee_id', 'committees.id')
        ->where('committees.term_id', $termID)
        ->where('committees.course_id', $courseID);
        if($type!==null) {
            $query->where('committees.type', $type);
        }        
        $committee = $query->first();

        //If creation allowed proceed with creation, create new committee if required, then assign the plan.

        if(empty($committee)) {
            $committee = new Committee();
            $committee->term_id = $termID;
            $committee->course_id = $courseID;
            $committee->type = $type;
            $committee->save();
        }

        $committeePlan = new CommitteePlan();
        $committeePlan->committee_id = $committee->id;
        $committeePlan->plan_id = $planID;
        $committeePlan->save();

        return $committee;
    }

    public function plansIDs() {
        $plansIDs = [];
        foreach($this->committeesPlans as $committeePlan) {
            $plansIDs[] = $committeePlan->plan_id;
        }
        return $plansIDs;
    }

    public function sectionsQuery($plansIDs = null, $avaliableOnly = false, $useOverQuota = false) {

        $lang = lang();
        
        $query = Section::select('sections.id', 'sections.group_no', 'sections.section_no', 'sections.quota', 'sections.over_quota', 'sections.plan_id', 'plans.year_id', 'years.'.$lang.'_name as year', 'plans.'.$lang.'_program as program', 'plans.'.$lang.'_minor as minor')
            ->join('plans', 'plans.id', 'sections.plan_id')
            ->leftjoin('years', 'years.id', 'plans.year_id')
            ->orderBy('sections.plan_id')
            ->orderBy('sections.group_no')
            ->orderBy('sections.section_no');

        $query->addSelect(DB::raw("(SELECT count(*) FROM studies WHERE studies.committee_id = $this->id AND studies.section_id = sections.id) as taken"));
        $group = __('tr.Group');
        $query->addSelect(DB::raw("CONCAT('$group ', sections.group_no) as 'group'"));
        $section = __('tr.Section');
        $query->addSelect(DB::raw("CONCAT('$section ', sections.section_no) as section"));

        $query->addSelect(DB::raw("CONCAT((CASE WHEN plans.year_id<100 THEN years.".$lang."_name ELSE plans.".$lang."_program END), ', ', plans.".$lang."_minor) as plan"));

        if($this->course->isCreditHours()) {
            $query->join('committees_sections', 'committees_sections.section_id', 'sections.id');
            $query->where('committee_id', $this->id);
        }

        if($avaliableOnly) {
            if($useOverQuota) {
                $query->havingRaw('(sections.quota + sections.over_quota)>taken');
            }
            else {
                $query->havingRaw('sections.quota>taken');
            }            
        }

        if($plansIDs) {
            $plansIDs = array_intersect($this->plansIDs(), $plansIDs);
        }
        else {
            $plansIDs = $this->plansIDs();
        }

        $query->whereIn('sections.plan_id', $plansIDs);

        return $query;
    }

    public function sections($plansIDs = null, $avaliableOnly = false, $useOverQuota = false) {
        return $this->sectionsQuery($plansIDs, $avaliableOnly, $useOverQuota)->get();
    }

    public function isSectionExist($sectionID) {

        if($sectionID===null) return false;
        $query = Section::where('term_id', $this->term_id);
        if($this->course->isCreditHours()) {
            $query->join('committees_sections', 'committees_sections.section_id', 'sections.id');
            $query->where('committee_id', $this->id);
        }
        $query->where('sections.id', $sectionID);
        
        return $query->exists();
    }

    public function isSectionsEnabled() {
        $plansIDs = $this->plansIDs();
        $query = Section::whereIn('sections.plan_id', $plansIDs);
        if($this->course->isCreditHours()) {
            $query->join('committees_sections', 'committees_sections.section_id', 'sections.id');
            $query->where('committee_id', $this->id);
        }

        return ($query->count()>0);
    }

    public function isPublished() {
        return ($this->control_status==Committee::CONTROL_STATUS_PUBLISHED);
    }

    public function isFreezed() {
        return ($this->control_status==Committee::CONTROL_STATUS_FREEZED);
    }

    public function passFailDegreesData() {
        $degreesData = [];
        $degreeData = (object)[];
        $degreeData->field = 'final_work';
        $degreeData->label = 'Final Work';
        $degreeData->short_label = 'W';
        $degreeData->excelLabel = 'final_work';
        $degreeData->max_value = $this->course->max_total;
        $degreeData->affect_total = true;
        $degreeData->exam = false;
        $degreeData->readonly = false;
        $degreesData['final_work'] = $degreeData;
        return $degreesData;
    }

    public function getStudentDegreesData() {
        if($this->isPassFail()) {
            return $this->passFailDegreesData();
        }
        return $this->course->getDegreesData(false, $this->max_first_mcq_exam, $this->max_final_mcq_exam);
    }

    public function isPassFail() {
        return ($this->flags&Committee::FLAG_PASS_FAIL);
    }
}
