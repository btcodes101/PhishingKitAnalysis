<?php

namespace App;

use App\User;
use App\Archive;
use App\QuestionnaireTask;
use App\BaseModel;

class QuestionnaireFaculty extends BaseModel
{
    protected $table = "questionnaires_faculty";

    public   $timestamps = false;

    protected $fillable = [
        'id',
        'questionnaire_id',
        'task_id',
        'status',
        'start_date',
        'end_date',
        'active',
        'created_at',
        'updated_at'
    ];

    public function questionnaireTask(){
        return $this->belongsTo('App\QuestionnaireTask', 'task_id', 'id');
    }

}