<?php

namespace App;

use BaseModel\Model;

class Organizations extends BaseModel
{
    protected $table = 'ico_organizations';
}
