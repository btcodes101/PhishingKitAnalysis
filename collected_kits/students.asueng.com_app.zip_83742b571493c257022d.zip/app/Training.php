<?php

namespace App;

use Auth;

use Illuminate\Database\Eloquent\Model;

class Training extends Model
{
    protected $table = 'trainings';

    protected $fillable = ['term_id', 'type', 'title', 'description', 'provider', 'num_of_weeks', 'num_of_students', 'acceptance_criteria', 'start_date', 'end_date', 'application_start_date', 'application_end_date', 'contact_person', 'cv_required', 'bylaw', 'source', 'created_at', 'updated_at'];

    const types = [
        'Online training', 
        'Field training', 
        'In-house training', 
        'External Class course'
    ];

    const IN_REVIEW = 'In Review';
    const ACCEPTED = 'Accepted';
    const REJECTED = 'Rejected';

    public function plans()
    {
        return $this->belongsToMany(Plan::class, 'student_training_plans');
    }
    public function term()
    {
        return $this->belongsTo(Term::class);
    }

    public function studentTraining()
    {
        return $this->hasMany(StudentTraining::class);
    }


    public function canApply()
    {

        $student = auth()->user()->student;
        $plan_id = $student->last_plan_id;

        if($this->approved != 1)
            return false;

        if($this->plans()->where('plan_id', $plan_id)->get()->count() >  0 || $this->all_plans == 1)
            return true;

        return false;
    }
     
}
