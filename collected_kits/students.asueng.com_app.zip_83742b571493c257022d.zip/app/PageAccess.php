<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PageAccess extends Model
{
    protected $table = 'pages_access';
    public $timestamps = false;

    public static function log() {

    	/*$pageAccess = new PageAccess();
    	$pageAccess->page = request()->getRequestUri();
    	$pageAccess->save();*/
    }
}
