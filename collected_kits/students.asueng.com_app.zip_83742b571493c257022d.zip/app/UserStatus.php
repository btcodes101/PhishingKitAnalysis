<?php

namespace App;

use App\BaseModel;

class UserStatus extends BaseModel
{
    protected $table = 'users_status';

    public function user() {
        return $this->belongsTo('App\User');
    }
}
