<?php

namespace App;

use App\BaseModel;

class CourseUser extends BaseModel
{
    protected $table = 'course_user';

    public function studyCourseID(){
        return $this->belongsTo('App\Course');
    }
}
