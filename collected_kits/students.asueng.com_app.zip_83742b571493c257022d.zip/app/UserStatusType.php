<?php

namespace App;

use App\BaseModel;

class UserStatusType extends BaseModel
{
    protected $table = 'users_status_types';
    public $timestamps = false;
}
