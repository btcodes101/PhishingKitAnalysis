<?php

namespace App;

use App\User;
use App\Archive;
use App\BaseModel;
use Carbon\Carbon;

class SMSMessage extends BaseModel
{
    protected $table = 'sms_messages';
    private $key = '@879YuDh12';

    public function archive(){
        return $this->belongsTo('App\Archive');
    }

    public function from(){
        return $this->belongsTo('App\User', 'from_user_id', 'id');
    }
}