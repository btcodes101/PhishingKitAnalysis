<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChangeTrackPreference extends Model
{
    protected $table = 'change_track_preferences';
    public $timestamps = false;
}
