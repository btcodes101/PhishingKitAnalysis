<?php

namespace App\Http\Controllers;

use App\Applicant;
use App\OpenPosition;
use App\Setting;
use App\Mail\SystemMail;
use App\Archive;
use App\User;
use App\Student;
use App\PageAccess;
use App\Keyword;
use App\Governorate;
use App\Ticket;
use App\TicketMessage;
use App\Department;
use App\TermPlan;
use App\Plan;
use App\Term;
use App\ApplicantType;
use App\Website;
use App\PaymentSetting;
use App\UserRequest;
use App\Http\Controllers\WebsiteController;
use App\ExternalProgram;
use Crypt;
use Mail;
use URL;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Storage;

class ApplicantsController extends Controller
{

    public function __construct()
    {
        \Artisan::call('cache:clear');
        $this->middleware('auth')->except('error', 'openApplicant', 'applyTo','saveApplicant', 'pgSpecializations', 'pgPrograms', 'emailVerify');
    }

    public function buildQuery($keywords, $applyTo, $status) {

        $query = Applicant::whereRaw(\DB::raw("TRUE"));
            
        if ($keywords) {
            $keywords = mb_ereg_replace(" ", "%", getFTS($keywords)); 
            $query->Where(\DB::raw("COALESCE(applicants.search_text,'')"), "like", "%$keywords%");
        }

        if ($applyTo) {
            $query->Where('applicants.apply_to', "=", "$applyTo");
        }

        if ($status) {
            $query->Where('applicants.status', "=", "$status");
        }

        if ($status!='-1') {
            $query->where('applicants.status', '!=', -1);
        }

        $query->where('active', 1);

        return $query;
    }

    public function index(Request $request) {

        /*foreach (Applicant::all() as $applicant) {
            $applicant->updateFTS();
        }*/

        $statistics = (object)[];
        
        if($request->ajax()) {

            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $keywords = $request->search['value'];
            $applyTo = $columns[0]["search"]["value"];
            $status = $columns[1]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $lang = lang();
            
            $query = $this->buildQuery($keywords, $applyTo, $status);

            \Log::info('Result:', [$query->toSql()]);

            $query->select('applicants.id', 'applicants.apply_to', $lang.'_full_name as name', 'applicants.status', 'applicants.email', 'applicants.created_at', 'applicants.secret');
            
            $rowsQuery = clone $query;
            $statisticsQuery = clone $query;

            $rows = $rowsQuery->orderBy($orderBy, $orderDir)->paginate($length);

            $visitors = 0;
            $applicantsTypes = null;
            if ($applyTo) {
                $applicantsTypes = [$applyTo];
            }
            else {
                $applicantsTypes = ApplicantType::pluck('code')->toArray();
            }
            foreach($applicantsTypes as $applicantType) {
                $visitors += PageAccess::where('page', 'LIKE', "%/website/home/applyto%$applicantType%")->count();
            }

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows,
                'count_applicants' => $statisticsQuery->count(),
                'count_visitors' => $visitors,
            ];
            
            return $result;
        }

        $path[] = (object)[
            'link' => route("manage"),
            'title' => __('tr.Manage'),
        ];
                        
        $applicantsTypes = ApplicantType::pluck(lang().'_name as name', 'code')->toArray();

        return view('manage.applicants.index', compact('path', 'applicantsTypes'));
    }

    public function discuss(Applicant $applicant) {

        if(empty($applicant->discuss_ticket_id)) {
            $ticket = new Ticket();
            $ticket->ticket_type_id = 10;
            $ticket->title = "Discuss applicantion #$applicant->id";
            $ticket->description = "Discuss applicantion #$applicant->id";
            $ticket->status = 0;
            $ticket->user_id = auth()->id();
            $ticket->related_id = $applicant->id;
            $ticket->save();
            $applicant->discussion_ticket_id = $ticket->id;
            $applicant->save();
        }

        return redirect(route('show_ticket', ['id'=>$applicant->discussion_ticket_id]));
    }

    public function feedback(Applicant $applicant) {

        if(empty($applicant->feedback_ticket_id)) {
            $ticket = new Ticket();
            $ticket->ticket_type_id = 9;
            $ticket->title = "Feedback applicant #$applicant->id";
            $ticket->description = "Feedback applicant #$applicant->id";
            $ticket->status = 0;
            $ticket->user_id = auth()->id();
            $ticket->related_id = $applicant->id;
            $ticket->save();
            $applicant->feedback_ticket_id = $ticket->id;
            $applicant->save();
        }

        return redirect(route('show_ticket', ['id'=>$applicant->feedback_ticket_id]));
    }

    public function show(Applicant $applicant) {

        if(!auth()->user()->hasPermissionTo('access_applicants'))
            abort(401);

        $path[] = (object)[
            'link' => route("manage"),
            'title' => __('tr.Manage'),
        ];

        $path[] = (object)[
            'link' => route("applicants"),
            'title' => __('tr.Applicants'),
        ];

        return view('manage.applicants.show', compact('path', 'applicant'));
    }

    public function saveCommon($applicant, $request, $dataValidators, $data) {

        if(!$applicant->canUpdate()) {
            return response()->json(['error'=>"Server error, invalid request."], 500);
        }

        $validators = [
            'en_full_name' => 'string|max:128',
            'ar_full_name' => 'string|max:128',
            'birth_date' => 'required|date',
            'nationality_code' => 'required|exists:countries,code',
            'gender' => 'required|string',
        ];

        
        //make sure the national id is unique (only the active ones)
        $checkApplicantNationalID = Applicant::where('id', '!=', $applicant->id)->where('national_id', $request->national_id)->where('active', 1)->first();
        if($checkApplicantNationalID)
            throw \Illuminate\Validation\ValidationException::withMessages(['national_id' => 'The national id has already been taken']);

        if($request->nationality_code=='EG') {
            $dataValidators['national_id'] = 'required|max:14|min:14';
        } else {
            $dataValidators['national_id'] = 'required|max:32|min:5';
        }

        foreach($applicant->fileTypes() as $fileContentType => $fileInfo) {
            $validators[$fileContentType] = 'mimes:jpeg,jpg,png,gif,pdf,doc,docx,odt|max:10240';
        }

        $request->validate(array_merge($validators, $dataValidators));
      
        $applicant->fill($request->all());
        $applicant->save();

        if(empty($applicant->archive_id)) {
            $archive = Archive::get("applicants/$applicant->apply_to/$applicant->id");
            $applicant->archive_id = $archive->id;
            $applicant->save();
            $applicant->refresh();
        }

        foreach($applicant->fileTypes() as $fileContentType => $fileInfo) {
            if(isset($request[$fileContentType])) {
                $file = $applicant->archive->findChildByContentType($fileContentType);
                if($file) {
                    $file->updateFile($request[$fileContentType]);
                } else {
                    $file = $applicant->archive->addFile($request[$fileContentType], $fileContentType);
                }
                $file->rename($fileContentType."_".$file->id);
                $file->save();
            } else {
                if(!$fileInfo->required) {
                    $file = $applicant->archive->findChildByContentType($fileContentType);
                    if($file)$file->delete();
                }
            }
        }

        $applicant->data = json_encode($data);
        if($applicant->status==Applicant::STATUS_INCOMPLETE) {
            $applicant->status = Applicant::STATUS_NEW;
        }
        else {
            $applicant->status = Applicant::STATUS_UPDATED;
        }
        $applicant->save();
        $applicant->updateFTS();
        $applicant->refresh();

        foreach ($applicant->archive->children as $file) {
            if($file->title!=$file->content_type) {
                $file->rename($file->content_type);
            }
        }

        
        $title = ucwords($applicant->apply_to);
        $title = "ASUENG - Application to ($title) is Updated";

        $systemMail = new SystemMail("application_is_submitted", ['title'=>$title, 'values' => ['update_link' => $applicant->updateLink(),'request_nmuber' => $applicant->id] ]);
        $systemMail->submit($applicant->email, false, Setting::value("email"));

        if($applicant->feedback) {
            $message = $applicant->feedback->messages()->first();
            if($applicant->comment && $message && $applicant->comment!=$message->comment) {
                $ticketMessage = new TicketMessage();
                $ticketMessage->ticket_id = $applicant->feedback->id;
                $ticketMessage->comment = $applicant->comment;
                $ticketMessage->user_id = 0;
                $ticketMessage->save();
            }
        }

        return response()->json();
    }

    public function saveCoeEnergy(Applicant $applicant, Request $request) {

        \Log::info('Request:', $request->all());

        $dataValidators = [
            'how_did_you_know' => 'required|string|max:256',
        ];
        
        $data = [
            'governorate' => $request->governorate,
            'governorate_other' => $request->governorate_other,
            'university' => $request->university,
            'university_other' => $request->university_other,
            'faculty' => $request->faculty,
            'student_code' => $request->student_code,
            'how_did_you_know' => $request->how_did_you_know,
        ];

        return $this->saveCommon($applicant, $request, $dataValidators, $data);
    }

    public function saveLuban(Applicant $applicant, Request $request) {

        \Log::info('Request:', $request->all());

        $dataValidators = [
            'how_did_you_know' => 'required|string|max:256',
        ];
        
        $data = [
            'governorate' => $request->governorate,
            'governorate_other' => $request->governorate_other,
            'university' => $request->university,
            'university_other' => $request->university_other,
            'faculty' => $request->faculty,
            'student_code' => $request->student_code,
            'how_did_you_know' => $request->how_did_you_know,
        ];

        return $this->saveCommon($applicant, $request, $dataValidators, $data);
    }

    public function savePostgraduate(Applicant $applicant, Request $request) { 

        \Log::info('Request:', $request->all());

        $dataValidators = [
                'graduation_date' => 'date',
            ];

        if($request->nationality_code == 'EG'){
            $dataValidators['national_id_issue_date'] = 'required|date';
        }
        else {
            $dataValidators['national_id_issue_date'] = 'required|date';
            $dataValidators['residency_end_date'] = 'required|date';            
        }

        $data = [
            'national_id_issue_date' => $request->national_id_issue_date,
            'military_status' => $request->military_status,
            "job" => $request->job,
            'work_place' => $request->work_place,
            'work_phone' => $request->work_phone,
            'birth_place' => $request->birth_place,
            'marital_status' => $request->marital_status,
            'religion' => $request->religion,
            'home_phone' => $request->home_phone,
            'home_address' => $request->home_address,
            'graduation_date' => $request->graduation_date,
            'graduation_grade' => $request->graduation_grade,
            'graduation_project_name' => $request->graduation_project_name,
            'graduation_project_grade' => $request->graduation_project_grade,
            'graduation_faculty' => $request->graduation_faculty,
            'graduation_department' => $request->graduation_department,
            'graduation_university' => $request->graduation_university,
            'graduation_university_other' => (isset($request->graduation_university_other))?$request->graduation_university_other:null,
            'diploma_name' => $request->diploma_name,
            'diploma_date_obtained' => $request->diploma_date_obtained,
            'diploma_grade' => $request->diploma_grade,
            'diploma_faculty' => $request->diploma_faculty,
            'diploma_university' => $request->diploma_university,
            'diploma_university_other' => (isset($request->diploma_university_other))?$request->diploma_university_other:null,
            'master_specialization' => $request->master_specialization,
            'master_date_obtained' => $request->master_date_obtained,
            'master_title' => $request->master_title,
            'master_faculty' => $request->master_faculty,
            'master_university' => $request->master_university,
            'master_university_other' => (isset($request->master_university_other))?$request->master_university_other:null,
            'apply_to_department' => $request->apply_to_department,
            'apply_to_specialization' => $request->apply_to_specialization,
            'apply_to_term' => $request->apply_to_term,
            'apply_to_program' => $request->apply_to_program,
        ];

       

        if($request->nationality_code == 'EG') {
            
        }
        else {
            $data['father_nationality'] = $request->father_nationality;
            $data['mother_nationality'] = $request->mother_nationality;
            $data['spouse_nationality'] = $request->spouse_nationality;
            $data['passport_type'] = $request->passport_type;
            $data['passport_issuer'] = $request->passport_issuer;
            $data['residency_type'] = $request->residency_type;
            $data['residency_end_date'] = $request->residency_end_date;
            $data['address_at_home_country'] = $request->address_at_home_country;
        }

        //Create request    
        //if the request not paid or the student changed his plan
        if($applicant->payment_status != 'PAID' || $request->apply_to_program != $applicant->plan_id){

            //set the old requests status to manully expired
            UserRequest::where('target_id', $applicant->id)->update(['order_status' => UserRequest::STATUS_MANUALLY_EXPIRED]);
            
            $plan = Plan::findOrFail($request->apply_to_program);
            $term = Term::findOrFail($request->apply_to_term);

            $planType = $plan->getType();

            $paymentSetting = PaymentSetting::where('year', $term->years)->first();
            if(!$paymentSetting || empty($paymentSetting))
                abort(404);

            $requestFees = 0;

            if($planType == Plan::DIPLOMA_PLAN){
                $requestFees = $paymentSetting->diploma_admission_fees;
            }elseif($planType == Plan::MASTER_PLAN){
                $requestFees = $paymentSetting->master_admission_fees;
            }elseif($planType == Plan::PHD_PLAN){
                $requestFees = $paymentSetting->phd_admission_fees + $paymentSetting->phd_qualification_exam_fees;
            }else{
                abort(404);
            }

            $items[] = [0=> __('tr.Admission fees'), 1=> $requestFees];

            $pg_students_activities_percentage = ($paymentSetting->pg_students_activities_percentage / 100) * $requestFees;
            $pg_students_activities_percentage = ($pg_students_activities_percentage > 20)?$pg_students_activities_percentage:20;
            
            $items[] = [0=> __('tr.Students Activities'), 1=> $pg_students_activities_percentage];

            $requestFees += ($pg_students_activities_percentage > 20)?$pg_students_activities_percentage:20;
            
            $userRequest = $this->createUserRequest('postgrad_admission_fees', 'pgAdmissionFees', $requestFees, $items, $applicant->id);

            $applicant->merchantRefNo = $userRequest->merchant_reference_no;
            $applicant->payment_status = 'UNPAID';

        }
        

        $applicant->plan_id = $request->apply_to_program;

        return $this->saveCommon($applicant, $request, $dataValidators, $data);
    }

    public function saveUndergraduate(Applicant $applicant, Request $request){
        
        \Log::info('Request:', $request->all());

        $dataValidators = [
            'school_study_type' => 'required',
        ];

        if($request->nationality_code == 'EG'){
            $dataValidators['national_id_issue_date'] = 'required|date';
        }
        else {
            $dataValidators['national_id_issue_date'] = 'required|date';
            $dataValidators['residency_end_date'] = 'required|date';            
        }        

        $data = [
            'birth_place' => $request->birth_place,
            'home_phone' => $request->home_phone,
            "home_address" => $request->home_address,
            'religion' => $request->religion,
            'national_id_issue_date' => $request->national_id_issue_date,
            
            'parent_name' => $request->parent_name,
            'parent_relation' => $request->parent_relation,
            'parent_national_id' => $request->parent_national_id,
            'parent_phone' => $request->parent_phone,
            'parent_email' => $request->parent_email,

            'school_study_type' => $request->school_study_type,
            'other_school_study_type' => $request->other_school_study_type,
            'school_name' => $request->school_name,
            'school_marks' => $request->school_marks,
            'school_max_marks' => $request->school_max_marks,

            'study_type' => $request->study_type,
            'first_program' => $request->first_program,
            'second_program' => $request->second_program,

            'transfer_status' => $request->transfer_status,
            'transfer_from_department' => $request->transfer_from_department,
            'transfer_from_faculty' => $request->transfer_from_faculty,
            'transfer_from_university' => $request->transfer_from_university,
        ];

        if($request->plan_id == null) {
            $request->merge([
                'plan_id' =>  179,
            ]);
        }

        if($request->nationality_code == 'EG') {

            $data['military_status'] = $request->military_status;
            $data['military_no'] = $request->military_no;
            $data['military_order'] = $request->military_order;
            $data['military_order_date'] = $request->military_order_date;
            $data['military_age'] = $request->military_age;
        }
        else {

            $data['father_nationality'] = $request->father_nationality;
            $data['mother_nationality'] = $request->mother_nationality;
            $data['passport_type'] = $request->passport_type;
            $data['passport_issuer'] = $request->passport_issuer;
            $data['residency_type'] = $request->residency_type;
            $data['residency_end_date'] = $request->residency_end_date;
            $data['address_at_home_country'] = $request->address_at_home_country;
        }
        
        if($applicant->payment_status != 'PAID' && $request->plan_id != 179){

            //set the old requests status to manully expired
            UserRequest::where('target_id', $applicant->id)->update(['order_status' => UserRequest::STATUS_MANUALLY_EXPIRED]);
            
            $requestFees = 500;
            $items[] = [0=> __('tr.International Admission fees'), 1=> $requestFees];
            $userRequest = $this->createUserRequest('international_admission_fees', 'IDAdmissionFees', $requestFees, $items, $applicant->id);
            $applicant->merchantRefNo = $userRequest->merchant_reference_no;
            $applicant->payment_status = 'UNPAID';
        }

        return $this->saveCommon($applicant, $request, $dataValidators, $data);
    }

    public function saveApplicant($type, Applicant $applicant, Request $request) {
        
        switch($type) {
            case "coeenergy": return $this->saveCoeEnergy($applicant, $request);
            case "postgraduate": return $this->savePostgraduate($applicant, $request);
            case "undergraduate": return $this->saveUndergraduate($applicant, $request);
            case "luban": return $this->saveLuban($applicant, $request);
        }
    }

    public function openApplicant(Applicant $applicant , Request $request)
    {
        $path[] = (object)[
            'link' => route("applicants"),
            'title' => __('tr.Applicants'),
        ];

        if ($request->has('secret')){
            //$email = "hassan.sayed2@eng.asu.edu.eg";
            $user = User::where('email', 'like', 'selectioncommitee@%')->first();
            if (decrypt($request->secret) ==  $user->email) {
                \auth()->login($user, false);
                return view('system.applicants.show', compact('path', 'applicant'));
            }
            
             abort(401);
        }
    }

   
    public function sheet(Request $request){
            
        $applyTo = $request->search_applicant;
        $status = $request->search_status;
        $keywords = $request->text_search;

        $query = $this->buildQuery($keywords, $applyTo, $status);
        
        $query->select('id as ID', 'apply_to as Apply To', 'status as Status', 'en_full_name as English Name', 'ar_full_name as Arabic Name', 'gender as Gender', 'birth_date as Birth Date', 'nationality_code as Nationality', 'national_id as National ID', 'created_at as Created At', 'updated_at as Updated At', 'data')->orderBy('id');

        \Log::info('Result:', [$query->toSql()]);

        $rows = $query->get();

        $countries = Applicant::countries();

        $keys = [];
        foreach ($rows as $applicant) {
            $data = json_decode($applicant->data);
            $data = (array)$data;
            foreach ($data as $key => $itemValue) {
                $keys[$key] = $key;
            }
        }

        $rows->transform(function ($value) use($countries, $keys) {

            $data = json_decode($value->data);

            $value->Status = ($value->Status!==null)?Applicant::statusTypes()[$value->Status]:null;
            $value->Gender = ($value->Gender!==null)?User::gendersLabels()[$value->Gender]:null;
            $value->Nationality = ($value->Nationality!==null)?$countries[$value->Nationality]:null;
            
            if($data) {

                $data = (array)$data;
                
                foreach ($keys as $key) {

                    $keyName = ucfirst(str_replace('_', ' ', $key));
                    if(array_key_exists($key, $data)) {

                        $newValue = Applicant::getDataValue($key, $data[$key]);
                        $value[$keyName] = $newValue;
                    } else {
                        
                        $value[$keyName] = "-";
                    }
                }

                unset($value->data);
            }

            return $value;
        });
        
        return Excel::create('Applicants', function ($excel) use ($rows) {
            $excel->sheet('Applicants', function ($sheet) use ($rows) {
                $sheet->fromArray($rows);
            });
        })->download();
    }

    public function pgSpecializations(Department $department) {

        $departments = Department::where('parent_id', $department->id)->select(lang().'_name as name', 'id')->orderBy(lang().'_name')->get();

        foreach ($departments as $departments) {
            $results[]= ['name' =>  $departments->name, 'search' =>  $departments->name, 'id' =>  $departments->id];
        }

        return response()->json($results);
    }

    public function pgPrograms(Term $term, Department $department) {

        $plans = Plan::select(lang().'_minor as name', 'id')
            ->join('terms_plans', 'terms_plans.plan_id', 'plans.id')
            ->where('terms_plans.term_id', $term->id)
            ->where('plans.year_id', 200)
            ->where('plans.department_code', $department->code)
            ->where('plans.general', 0)
            ->get();

        $results = array();

        foreach ($plans as $plan) {
            $results[]= ['name' =>  $plan->name, 'search' =>  $plan->name, 'id' =>  $plan->id];
        }

        return response()->json($results);
    }

    public static function emailVerify(Request $request) { //send emails

        \Log::info('Result:', [$request->all()]);
       
        $validators = [
            'email' => 'required|email',
            'apply_to' => 'required|string',
        ];

        if(env('APP_DEBUG') == false) {

            $ip = $_SERVER['REMOTE_ADDR'];
            $secretKey = '6Lf17rUUAAAAAGFFZ4GsZ1CZJJwAYkdEaEDC-EI5';
            $captcha = $request["g-recaptcha-response"];
            $url = "https://www.google.com/recaptcha/api/siteverify?secret=".$secretKey."&response=".$captcha."&remoteip=".$ip;
            dbg($url, "recaptcha");
            $response=file_get_contents($url);
            $responseKeys = json_decode($response,true);
            \Log::info('recaptcha:', [$responseKeys]);
            if(intval($responseKeys["success"]) !== 1)
                return response()->json(['error'=>"Server error, invalid request."], 500);
        }        
        
        $applicant = Applicant::where('email', $request->email)->where('apply_to', $request->apply_to)->first();

        if(!empty($applicant->id)) {

            $title = "Remember! - ".$applicant->applicantType->lang('name');
            
            $systemMail = new SystemMail("application_is_submitted", ['title'=>$title, 'values' => ['update_link' => $applicant->updateLink()]]);
            $systemMail->submit($applicant->email, false, Setting::value("email"));

            return response()->json(['error'=>"Another request for the same user and service is submitted before. Please check your email."], 500);
        }
            
        $applicant = new Applicant();
        $applicant->apply_to = $request->apply_to;
        $applicant->email = $request->email;
        $applicant->secret = Str::random(64);
        $applicant->save();

        $title = "ASUENG - Email Verification";
                
        $systemMail = new SystemMail("email_verification", ['title'=>$title, 'values' => ['update_link' => $applicant->updateLink()]]);
        $systemMail->submit($applicant->email, false, Setting::value("email"));

        return response()->json();
    }

    public function applyTo(Request $request, $applyto, Applicant $applicant = null, $secret = null) {

        if(!isset($applicant->id)) {
            
            $applicantType = ApplicantType::where('code', $applyto)->first();
            
            $website = new Website(Archive::locate('home'));

            return view('website.home.applyto.email_verify', compact('applicantType', 'website'));            
        }
        
        if($applicant->secret!=$secret)
            abort(400);

        $website = new Website(Archive::locate('home'));

        if($applicant && $applicant->data) {
            $applicant->data = json_decode($applicant->data);
        }

        $userRequest = new UserRequest();

        if( ($applyto == 'postgraduate' || ($applyto == 'undergraduate' && $applicant->plan_id != 179)) && $applicant->status == Applicant::STATUS_ACCEPTED){
            $userRequest = UserRequest::where('merchant_reference_no', $applicant->merchantRefNo)->first();
        }
   
        $plans = Plan::where("bylaw", "UG2018")->where("en_program", "Inter-Disciplinary Programs")->whereNotNull("minor_department_id")->pluck('en_minor', 'id')->toArray();
        
        return view("website.home.applyto.$applyto", compact('website', 'applicant', 'userRequest', 'plans'));
    }

    public static function actions(Request $request) {

        $applicant = Applicant::findOrfail($request->applicant_id);        
        
        if (isset($request->accept_applicant) == 'accept_applicant') {
            $applicant->status = 1;
            $applicant->save();

            if($applicant->apply_to != 'luban'){
                $user = new User(); 

                if(!auth()->user()->hasPermissionTo('edit_users'))
                    abort(401);

                $data = json_decode($applicant->data);

                //dd($applicant->data);

                foreach ($data as $key => $value) {
                    
                    if ($data->religion ==  __("tr.Muslim")) {
                        $user->religion = 1;
                    }
                    if ($data->religion ==  __("tr.Christian")) {
                        $user->religion = 2;
                    }
                    if ($data->religion ==  __("tr.Other")) {
                        $user->religion = 3;
                    }

                    $user->address = $data->address_at_home_country;
                }
                
                

                $user->en_name = $applicant->en_full_name;
                $user->ar_name = $applicant->ar_full_name;
                $user->national_id = $applicant->national_id;
                $user->email = $applicant->email;
                $user->email_alt = $applicant->email;
                $user->mobile = $applicant->mobile;
                $user->gender = $applicant->gender;
                $user->data = $applicant->data;

                $user->type = 3;
    
                $user->active = 1;
    
                $user->code = User::genCode($user->type);


                $user->save();
                $user->updateFTS();

                $instructor = null;
                $student = new Student();
                $student->id = $user->id;
                if($applicant->apply_to == 'undergraduate'){
                    foreach ($data as $key => $value) {
                        if(isset($data->school_study_type)){
                            $applicant->getDataValue($key, $value);
                            $student->school_study_type = $data->school_study_type;
                            $student->school_name = $data->school_name;
                            $student->school_marks = $data->school_marks;
                            $student->parent_name = $data->school_name;
                            $student->parent_phone = $data->parent_phone;
                            $student->parent_email = $data->parent_email;
                            $student->parent_relation = $data->parent_relation;
                            $student->parent_national_id = $data->parent_national_id;
                        }
                        
                    }
                }

                $student->save();

            }

            
            return back();
        }
        
        else if(isset($request->reject_applicant) == 'reject_applicant'){   
            $applicant->status = 2;
            if($request->notes != ''){
                
                $applicant->notes = $request->notes;
                $applicant->save();
                $title = "ASUENG - Rejected Application";
        
                $systemMail = new SystemMail("application_rejected", ['title'=>$title, 'values' => ['reject_reason' => $applicant->notes]]);
                $systemMail->submit($applicant->email, false, Setting::value("email"));
            }

            return back();
        }
        
        else if(isset($request->reset_applicant)  == 'reset_applicant'){
            $applicant->status = -1;
            $applicant->notes = null;   
            $applicant->save();
            
            $userData = User::where('email',$applicant->email)->get();
            if($userData->count() > 0){
                $user = DB::select('delete from users where email = "'.$applicant->email.'"');
                $student = DB::select('delete from students where id = '.$userData->first()->id);
            }
            return back();
        }
    }

    public function deleteApplicant(Applicant $applicant){

        if(!auth()->user()->hasPermissionTo('admin_applicants'))
            abort(401);

        $applicant->active = 0;
        $applicant->save();

        return response()->json();
    }
}
