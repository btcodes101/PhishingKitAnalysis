<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use Auth;
use Carbon\Carbon;

use App\User;
use App\Archive;
use App\ResearchPlan;
use App\StudentResearch;
use App\Setting;
use PDF;
use TCPDF_FONTS;
use Maatwebsite\Excel\Facades\Excel;
use DateTime;

class StudentsResearchController extends Controller
{
    public function __construct() {

        $this->middleware('auth');
    }

    public function show() {
        
        $lang = lang();

        $student = auth()->user()->student;

        $research = $student->research;

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];

        return view('study.research.show', compact('path', 'student', 'research')); 
    }
    
    public function edit() {
        
        $lang = lang();

        $student = auth()->user()->student;

        $research = $student->research;

        if($research && $research->isRegistered())
            abort(404);

        $researchPlans = ResearchPlan::pluck($lang.'_name as name', 'id')->toArray();

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        if(empty($research))
            $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];

        return view('study.research.edit', compact('path', 'student', 'research', 'researchPlans'));        
    }

    public function save(Request $request) {

        $request->validate([
            'ar_title' => 'required|string|max:512|min:8',
            'en_title' => 'required|string|max:512|min:8',
            'research_plan_id' => 'required|numeric|exists:research_plans,id',
        ]);

        $user = auth()->user();
        $student = $user->student;

        $research = $student->research;

        if($research && $research->isRegistered())
            abort(404);

        if(empty($research)) {
            $research = new StudentResearch();
            $research->student_id = $student->id;
        }

        $research->fill($request->all());
        $research->status |= StudentResearch::STATUS_SUBMITTED;
        $research->submitted_at = Carbon::now();
        $research->submitted_by = $student->id;
        $research->save();

        $folder = $user->archive;

        $file = $folder->findChildByContentType('Research Plan');
        if(empty($file)) {
            $file = $folder->addPage('Research Plan', '', 'Research Plan');
        }
        $abstract = $file->getLocale("en");
        $abstract->updatePage($request->en_abstract, true);
        $abstract = $file->getLocale("ar");
        $abstract->updatePage($request->ar_abstract, true);

        return redirect()->route('show_research');
    }

    public function print(Request $request) {

        $student = auth()->user()->student;
        
        app()->setLocale('ar');
        $lang = lang();
        $rtl = true;

        PDF::setHeaderCallback(function($pdf) use(&$rtl) {
            $pdf->setRTL(true);
            $fontname = TCPDF_FONTS::addTTFfont(public_path().'/arial.ttf', 'TrueTypeUnicode', '', 32);
            $pdf->SetFont($fontname,'', 12);
            $section = "header";
            $view = \View::make("study.research.report", compact('section'));
            $html = $view->render();
            $pdf->writeHTML($html);
            $pdf->Image(public_path('/img/logo.png'), 35, 10, 25, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
            $pdf->setRTL($rtl);
        });

        PDF::setFooterCallback(function($pdf) use($student, &$rtl) {
            $pdf->setRTL(true);
            $fontname = TCPDF_FONTS::addTTFfont(public_path().'/arial.ttf', 'TrueTypeUnicode', '', 32);
            $pdf->SetFont($fontname,'', 12);
            $pageNumber = $pdf->getAliasNumPage().'/'.$pdf->getAliasNbPages();
            $user = $student->user;
            $section = "footer";
            $view = \View::make("study.research.report", compact('section', 'user', 'pageNumber'));
            $html = $view->render();
            $pdf->writeHTML($html);
            $pdf->setRTL($rtl);
        });
        $code = $student->user->code;
        PDF::SetTitle("Research Plan - $code");
        PDF::SetMargins(15, 40, 15);
        PDF::SetHeaderMargin(10);
        PDF::SetFooterMargin(10);
        $setting = ['a_meta_charset' => 'UTF-8', 'a_meta_dir' => 'rtl', 'a_meta_language' => 'ar', 'w_page' =>  'page' ];
        PDF::setLanguageArray($setting);
        PDF::setFontSubsetting(true);
        PDF::SetAutoPageBreak(true, 30);
        $fontname = TCPDF_FONTS::addTTFfont(public_path().'/arial.ttf', 'TrueTypeUnicode', '', 32);
        PDF::SetFont($fontname,'', 12);
        PDF::AddPage('P', 'A4');
        
        $section = "main";
        $view = \View::make("study.research.report",compact('section', 'student'));
        $html = $view->render();
        PDF::writeHTML($html);

        PDF::setRTL(false);
        $rtl = false;
        $section = "enabstract";
        $view = \View::make("study.research.report", compact('section', 'student'));
        $html = $view->render();
        PDF::writeHTML($html);

        PDF::Output("Research Plan $code.pdf",'I');
    }
}
