<?php

namespace App\Http\Controllers;

use App;
use App\Archive;
use App\Course;
use App\File;
use App\Instructor;
use App\Study;
use App\User;
use App\Department;
use App\CourseFilesTask;
use App\Plan;
use App\Term;
use App\QuestionnairesTask;
use Auth;
use Carbon\Carbon;
use DB;
use DemeterChain\A;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\Paginator;
use Maatwebsite\Excel\Facades\Excel;

class QualityController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the course files records.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $path = [];
        return view('quality.index', compact('path'));
    }

    /**
     * Dispaly the quality team.
     *
     * @return \Illuminate\Http\Response
     */
    public function team()
    {
        if(!auth()->user()->hasPermissionTo('access_quality'))
            abort(401);

        $path = [
            (object)[
                'link' => route('quality'),
                'title' => 'Quality'
            ]
        ];

        $dqas = User::useresHasRole('DQA')->join('instructors', 'instructors.id', 'users.id')->get();

        $pqas = User::useresHasRole('PQA')->join('instructors', 'instructors.id', 'users.id')->get();

        $assistants = User::useresHasRole('QAASSISTANT')->get();

        $qaViceHeads = User::useresHasRole('VICEQA')->get();

        $qaHead = User::useresHasRole('QA')->first();

        $roles = [
            'VICEQA' => __('tr.Vice Manager'),
            'DQA' => __('tr.Department Organizer (DQA)'),
            'PQA' => __('tr.Program Organizer (PQA)'),
            'QAASSISTANT' => __('tr.Assistant'),
        ];

        return view('quality.team', compact('path', 'qaHead', 'qaViceHeads', 'dqas', 'pqas', 'assistants', 'roles'));
    }

    public function removeMember(User $user, $role) {
        $user->removeRole($role);
        return response()->json();
    }

    public function addMember(Request $request) {
        $user = User::find($request->user_id);
        if($user->type==User::TYPE_EMPLOYEE && $request->role=="QAASSISTANT")
            $user->assignRole($request->role);
        else if($user->type==User::TYPE_INSTRUCTOR && $request->role!="QAASSISTANT")
            $user->assignRole($request->role);
        else
            return response()->json(['error'=>'Invalid user/role.'], 500);

        return response()->json();       
    }
}