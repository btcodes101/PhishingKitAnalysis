<?php

namespace App\Http\Controllers;

use App\ArchiveRole;
use App\ArchiveUser;
use App\Mail\SystemMail;
use App\PrerequisiteCourses;
use App\ProctoringCommitteeExchange;
use App\QuestionnaireTask;
use App\User;
use App\Grade;
use App\GradeTerm;
use App\GradeTotal;
use App\Plan;
use App\Department;
use App\Course;
use App\Study;
use App\Student;
use App\Module;
use App\ModuleSample;
use App\ModuleCourse;
use App\CourseFilesTask;
use App\Term;
use App\Exams;
use App\ProctoringCommitteeOperation;
use App\ProctoringCommitteeProctor;
use App\Archive;
use App\CSVReader;
use App\Setting;
use App\Profile;
use App\Committee;
use App\ExternalProgram;
use App\ExternalProgramStudent;
use App\StudentFee;
use App\Service;
use App\UserRequest;
use Carbon\Carbon;
use App\ProctoringStaffPosition;
use Illuminate\Http\Request;
use Mail;
use mysql_xdevapi\Collection;
use PDF;
use Spatie\Permission\Models\Role;
use TCPDF_FONTS;
use Auth;
use Illuminate\Pagination\Paginator;
use DB;
use App\QualitiyArchive;

function extractFiles($content, $folder) {

    return preg_replace_callback('/<a(.*?)href=(["\'])(.*?)\\2(.*?)>/i',
        function($matches) use($folder) {

            list($full,,$pre,$orgLink,$post) = $matches;

            if(empty($orgLink))
                return false;

            $url = $orgLink;
            if(strpos($orgLink, "http")===false)
                $url = "https://eng.asu.edu.eg/news/view/$orgLink";
            $file = $folder->addRemoteFile($url);

            if(empty($file))
                return false;

            $newLink = route('download_file', ['id'=>$file->id]);
            return "<a $pre href='$newLink' $post>";
        }, $content);
}

function extractImages($content, $folder) {

    return preg_replace_callback('/<img(.*?)src=(["\'])(.*?)\\2(.*?)>/i',
        function($matches) use($folder) {

            list($full,,$pre,$orgLink,$post) = $matches;

            if(empty($orgLink))
                return false;

            $url = $orgLink;
            if(strpos($orgLink, "http")===false)
                $url = "https://eng.asu.edu.eg/news/view/$orgLink";
            $file = $folder->addRemoteFile($url);

            if(empty($file))
                return false;

            $newLink = route('download_file', ['id'=>$file->id]);
            return "<img $pre src='$newLink' $post>";

        }, $content);
}

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        \Artisan::call('cache:clear');
        $this->middleware('auth');
        $this->middleware('checkStdPaymentStatus')->only(['showCourse', 'examResults']);
    }
    
    public function index() {

        $path = [];
        $user = auth()->user();        

        return view('dashboard.index', compact('path', 'user'));
    }

    public function help()
    {
        $path = [
            (object)[
                'link' => route('dashboard'),
                'title' => __('tr.Dashboard')
            ],
        ];

        
        return view('help', compact('path'));
    }


    public function myArchive(){

        $path = [
            (object) [
                'link' => route('dashboard'),
                'title' => __('tr.Dashboard'),
            ],
        ];

        $availableArchives = [];

        $archiveUsers = ArchiveUser::where('user_id',auth()->id())->get();
        foreach ($archiveUsers as $archiveUser) {
            if($archiveUser->archive) {
                $availableArchives[] = $archiveUser->archive;
            }
        }

        $userRoles = auth()->user()->roles;
        foreach ($userRoles as $role) {
            $archiveRoles = ArchiveRole::where('role_id', $role->id)->get();
            foreach ($archiveRoles as $archiveRole) {
                if($archiveRole->archive) {
                    $availableArchives[] = $archiveRole->archive;
                }
            }
        }

        return view('dashboard.my_archive',compact('path', 'availableArchives'));
    }

    public function showArchive(Archive $archive,Request $request){

        if(empty($archive) || empty($archive->id)) {
            if(!auth()->user()->hasPermissionTo('admin_archive'))
                abort(401);
            $archive = Archive::root();
        }

        if(!$archive->canAccess()) {
            abort(401);
        }

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $parentId = $columns[0]["search"]["value"];
            $searchType = $columns[1]["search"]["value"];
            $type = $columns[2]["search"]["value"];
            $contentType = $columns[3]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = Archive::orderBy($orderBy, $orderDir);

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $query->where(\DB::raw("COALESCE(archive.search_text,'')") , "like", "%$textSearch%");
            }

            if ($searchType=="1") {
                $query->where('archive.path', 'LIKE', "$archive->path/$archive->title%");
            } else if ($parentId!==null) {
                $query->where('archive.parent_id', '=', $parentId);
            }

            if ($type!==null) {
                $query->where('archive.type', '=', $type);
            }

            if ($contentType!==null) {
                $query->where('archive.content_type', '=', $contentType);
            }

            if (!auth()->user()->hasPermissionTo('admin_archive')) {
                $query->whereRaw(\DB::raw('flags&1'));
            }

            $query->where('related_id', 0);

            \Log::info('Request:', [$query->toSql()]);

            $rows = $query->paginate($length);

            $rows->getCollection()->transform(function ($value) {
                
                $archive = Archive::find($value->id);
                $value->en_title = $archive->title;
                $archive = $archive->getLocale();
                $value->title = $archive->title;
                $value->sub_title = $archive->sub_title;
                $value->description = $archive->description;
                $value->size = $archive->size;

                return $value;
            });

            $rows->getCollection()->transform(function ($value) {

                $users = ArchiveUser::select('users.id', 'users.'.lang().'_name as name', DB::raw("(CASE WHEN users.type = 1 THEN departments.code WHEN users.type = 2 THEN '".__("tr.Employee")."' WHEN users.type = 4 THEN '".__("tr.External Instructor")."' ELSE '' END) AS code"))
                    ->where('archive_users.archive_id', $value->id)
                    ->join('users', 'users.id', '=', 'archive_users.user_id')
                    ->leftJoin('instructors', 'instructors.id', '=', 'users.id')
                    ->leftJoin('departments', 'departments.id', '=', 'instructors.department_id')
                    ->get()->toArray();

                $roles = ArchiveRole::select('roles.id', 'roles.name as name')
                    ->where('archive_roles.archive_id', $value->id)
                    ->join('roles', 'roles.id', '=', 'archive_roles.role_id')
                    ->get();

                $value->users = $users;
                $value->roles = $roles;
                return $value;
            });

            return [
                    'draw' => $draw,
                    'recordsTotal' => $rows->total(),
                    'recordsFiltered' => $rows->total(),
                    'data' => $rows
                ];
        }

        $path = [
            (object) [
                'link' => route('dashboard'),
                'title' => __('tr.Dashboard'),
            ],
            (object) [
                'link' => route('my_archive'),
                'title' => __('tr.My Archive'),
            ],
        ];

        
        return view('dashboard.show_archive', compact('path', 'archive', 'user', 'from'));
    }

    public function myServices() {
        
        $path = [];

        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];

        $user = auth()->user();
        $student = $user->student;
     
        return view('dashboard.my_services', compact('path', 'user', 'student'));
    }


    public function getPaymentAmount($id){
     
        $paymentAmount = StudentFee::where('id',$id)
        ->first();
        $paid_amount=$paymentAmount->amount-$paymentAmount->paid_amount;

        return response()->json($paid_amount);
       
    }
    public function control() {
        
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];

        return view('dashboard.control', compact('path'));
    }


    public function myCourses(Request $request) {  

       
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];        

        $student = auth()->user()->student;
        
        $lang = lang();

        $selectedYears = null;

        if($request->has('years')){

            $selectedYears = $request->years;
            $terms = Term::where('years', $selectedYears)->pluck('id');
            $termsArr = $terms->toArray();

        }else{

            $currentTermID = Setting::value('current_term_id');
            $controlTermID = Setting::value('control_term_id');
            $previousTermID = Setting::value('previous_term_id');
            $specialTermID = Setting::value('special_term_id');
            $admissionTermID = Setting::value('admission_term_id');
            $novemberTermID = Setting::value('november_term_id');

            $termsArr = [$specialTermID, $previousTermID, $currentTermID, $controlTermID, $admissionTermID, $novemberTermID];

        }

         

        $query = Study::select('studies.*')
        ->join('courses', 'courses.id', 'studies.course_id')
        ->join('committees', 'committees.id', 'studies.committee_id')
        ->join('terms', 'terms.id', 'studies.term_id')
        ->whereIn('studies.term_id', $termsArr)
        ->where('studies.user_id', $student->id)
        ->where('studies.status', '&', Study::STATUS_REGISTERED)
        ->where('studies.active', 1)
        ->where('courses.short_name', 'NOT LIKE', 'CRN%')
        ->orderBy('terms.start_date', 'DESC');

        $exams = Exams::current();        
        if($exams) {
            $query->leftJoin('exams_committees', function($join) use($exams) {
                $join->on('exams_committees.location_id', 'studies.exam_location_id');
                $join->on('exams_committees.committee_id', 'studies.committee_id');
                $join->where('exams_committees.linked_id', '0');
            });
            $query->leftJoin('exams_dates', 'exams_dates.id', 'exams_committees.exams_date_id');
            $query->orderBy('exams_dates.day_date');
            $query->orderBy('exams_committees.period');
        }

        $studies = $query->get();
        
        $modulesCoursesIDs = ModuleCourse::distinct('modules_courses.course_id')
        ->join('modules', 'modules.id', 'modules_courses.module_id')
        ->join('external_programs_students', 'external_programs_students.external_program_id', 'modules.external_program_id')
        ->where('external_programs_students.student_id', $student->id)
        ->pluck('modules_courses.course_id')
        ->toArray();

        $coursesIDs = Course::whereIn('base_course_id', $modulesCoursesIDs)->pluck('id')->toArray();
        $modulesCoursesIDs = array_merge($modulesCoursesIDs, $coursesIDs);

        $archive = []; 

        $years = Study::select('terms.*')
                        ->leftJoin('terms', 'terms.id', 'studies.term_id')
                        ->where('years', '!=', '')
                        ->where('studies.user_id', $student->id)
                        ->orderBy('id', 'DESC')
                        ->limit(10)
                        ->groupBy('years')
                        ->get();

        
        return view('dashboard.my_courses', compact('path', 'studies', 'student', 'modulesCoursesIDs', 'archive', 'years', 'selectedYears'));   
    }

     

    public function showCourse(Request $request, Course $course) {

        $user = auth()->user();

        $module = null;
        $data = null;

        $study = Study::where('course_id', $course->id)
        ->where('committee_id', $request->committee_id)
        ->where('user_id', $user->id)
        ->first();

        $degreesData = $study->committee->getStudentDegreesData();
 
        foreach ($degreesData as $degreeData) {
            $degreeData->degree = $study->{$degreeData->field};
        }

        $moduleCourse = ModuleCourse::distinct('modules_courses.*')
        ->join('modules', 'modules.id', 'modules_courses.module_id')
        ->join('external_programs_students', 'external_programs_students.external_program_id', 'modules.external_program_id')
        ->where('external_programs_students.student_id', $user->id)
        ->where(function($query) use($course) {
            $baseCourseID = $course->base_course_id;
            $query->orWhere('modules_courses.course_id', $course->id);
            if($baseCourseID) {
                $query->orWhere('course_id', $baseCourseID);
            }
        })
        ->first();
        
        if($moduleCourse) {            
            $module = $moduleCourse->module;         
            $data = $module->data($study->committee->term);            
            $data->activities = $module->folder("activities", $data->termYears, $user->code);
            $data->activities->setTempOwner();
        }

        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_courses'), 'title' => __('tr.My Courses')];

        return view('dashboard.show_course', compact('path', 'course', 'module', 'data', 'degreesData', 'study'));
    }

    public function examResults($term_id = NULL){ 
        // dd(auth()->user()->student->lastPublishedGradeTerm()['firstTerm']);
         
        $lang = lang();

        $user = auth()->user();

        $last_grade_term = $user->student->lastGradeTerm;
        
        $terms = Term::select('terms.*')
                        ->join('studies', 'studies.term_id', 'terms.id')
                        ->where('user_id', $user->id)
                        ->orderBy('term_id', 'DESC')
                        ->groupBy('term_id')
                        ->get();
 
        
        if($term_id == NULL)
            $term = ($terms->first() && $terms->first() != NULL)? $terms->first():Setting::resultsTerm();  
        else
            $term = Term::find($term_id);

 
        $studies = Study::with('course')
                        ->where('term_id', $term->id)
                        ->where('user_id', $user->id)
                        ->get();

        
        $coursesDegreesData = array();
        $degreesData = array();
            $all_published = true;
            $acheck = false;
        foreach($studies as $study){ //dd($study->toArray());
            $acheck = true;
            if($study->committee_id != NULL && !$study->committee->isPassFail()){

                $degreesData = $study->committee->getStudentDegreesData();

                foreach ($degreesData as $degreeData) {
                    $degreeData->degree = $study->{$degreeData->field};
                }
            }else{
                $degreesData = [];
            }
            
            if($study->committee_id != NULL){
                $published = $study->committee->isPublished();
            }else{
                $published = false;
                $all_published = false;
            }

            $coursesDegreesData[] = array( 
                                    'course_name' => $study->course->en_name,
                                    'short_name' => $study->course->short_name,
                                    'grade_letter' => $study->displayLatestGrade(),
                                    'published' => $published,
                                    'degrees' => $degreesData
                                );
        }
        
       $all_published = $all_published & $acheck;
       $grade_term = GradeTerm::where('student_id', $user->id)->where('term_id', $term->id)->first();
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];

        return view('dashboard.results', compact('path', 'term', 'coursesDegreesData', 'terms', 'grade_term', 'all_published'));

    }

    public function updateModuleCourse(Module $module, Course $course, Term $term, Request $request) {

        $user = auth()->user();
        $moduleSample = $module->sample($term->id, $course->id, $user->id);
        $moduleSample->status &= ~(ModuleSample::STATUS_ACCEPTED|ModuleSample::STATUS_REJECTED); 
        $moduleSample->save();

        return response()->json();
    }

    public function importFiles(Archive $archive, Request $request) {
        
        if(!auth()->user()->hasPermissionTo('admin_archive'))
            abort(404);

        try {

            $path = $_FILES['file']['tmp_name'];
            $archive->import($path);
            return response()->json();
        } catch (\Throwable $e) {
            return response()->json(['error'=>$e->getMessage(), 'code'=>$e->getCode()], 500);
        }
    }

    public function upgradeStudents() {

        $students = Student::where('graduated', 0)->whereIn('bylaw', ['UG2018'])->get();
        foreach ($students as $student) {
            $user = $student->user;
            $term = $student->term;
            $plan = $student->plan;
            $gradesTerms = $student->gradesTerms;
            echo "<p>";
            echo "$user->code: $user->en_name (id:$user->id)";
            echo "<br/>Term: ".$term->en_name;
            echo "<br/>Plan: ".$plan->name();
            if($student->last_level)echo "<br/>.Level: ".$student->level->en_name;
            else if($student->last_year_id)echo "<br/>Year: ".$student->year->en_name;
            echo "<br/>Terms Grades: ";
            echo "<ul>";
            foreach ($gradesTerms as $gradeTerm) {
                echo "<li><b>".$gradeTerm->term->en_name.":";
                if($gradeTerm->level) {
                    echo "".$gradeTerm->getLevel->en_name.", GPA(".$gradeTerm->grade_gpa."), Credit Hours(".$gradeTerm->credit_hours."), Passed Hours(".$gradeTerm->credit_hours."), Cumulative GPA(".$gradeTerm->cumulative_gpa."), Cumulative Credit Hours(".$gradeTerm->cumulative_credit_hours.")";
                }
                else {
                    echo "".$gradeTerm->getYear->en_name.", ".$gradeTerm->status->en_name.", ".$gradeTerm->facultyStatus->en_name.", ".$gradeTerm->gradeType->en_name.", ".$gradeTerm->total." of ".$gradeTerm->max_total.")";
                }
                echo "</b>";

                $grades = $gradeTerm->getGrades();
                echo "<ol>";
                foreach ($grades as $grade) {
                    echo "<li>".$grade->course->code.":".$grade->course->en_name." (id:$grade->course_id)";
                    if($gradeTerm->year>=100) {
                        echo ", Credit Hours(".$grade->course->credit_hours."), GPA(".$gradeTerm->grade_gpa."), Grade Letter(".$gradeTerm->grade_letter.")";
                    }
                    else {
                        echo ", Total(".$grade->total." of ".$grade->max_total."), Grade(".$grade->gradeNote->en_name."), State(".$grade->gradeState->en_name."), Control(".$grade->gradeControlAction->en_name.")";
                    }
                }
                echo "</ol>";
            }
            echo "</ul>";
            echo "</p>";
            dd("");
        }
    }

    public function uploadModuleFiles(Archive $archive, Request $request) {

        if(!$archive->canEdit()) {
            return response()->json(['error'=>['Failed to create new archive. Permission denied.']], 500);
        }

        if($request->ajax())
        {
            if(empty($archive->id)) {

                $archive = new Archive();
                $archive->id = 0;
            }

            $files = $request->file('files');
            $file = $request->file('file');
            if(empty($files) && !empty($file)) {
                $files = [$file];
            }

            $filesInfos = [];
            if(!empty($files)) {

                foreach ( $files as $file ) {
                    
                    if(!empty($request->title) && $request->replace=="yes") {
                        $oldFile = $archive->findChildByTitle($request->title);
                        if($oldFile)$oldFile->delete();
                    }

                    $archiveFile  = $archive->addFile($file, $request->content_type);
                    if(!empty($request->title)) {
                        $archiveFile->rename($request->title);
                    }

                    $filesInfos[] = (object) [
                        'id' => $archiveFile->id,
                        'name' => $archiveFile->name(),
                    ];
                }
            }

            return [
                "isSuccess" => true,
                "files" => $filesInfos
            ];
        }
    }

    public function applyToExternalProgram() {

        $user = auth()->user();
        $student = $user->student;

        $externalProgramRegisteration = $student->externalProgramRegisteration();

        if(!empty($externalProgramRegisteration) && !$externalProgramRegisteration->canChange())
            abort(401);

        $externalProgramID = ( $externalProgramRegisteration) ? $externalProgramRegisteration->external_program_id : null;

       
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.My Services')];
       
        $externalPrograms = ExternalProgram::join('external_programs_plans','external_programs_plans.external_program_id','external_programs.id')
        ->where('external_programs_plans.plan_id',$student->last_plan_id)
        ->pluck('external_programs.name', 'external_programs.id')
        ->toArray();
        
        return view('external_programs.apply', compact( 'status', 'path', 'externalPrograms', 'student', 'externalProgramID'));
    
        
    }
    public function uploadExternalProgramDocs() {

        $user = auth()->user();

        $status=ExternalProgramStudent::select('external_programs_students.status')
        ->where('student_id',auth()->user()->id)->first()->status;
       
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.Upload Docs')];
       
   
        
        return view('external_programs.upload_docs', compact( 'status', 'path'));
    
        
    }
    
     public function saveExternalProgramDocs(Request $request) {

        $user = auth()->user();
        $student = $user->student;

        $externalProgramRegisteration = $student->externalProgramRegisteration();
        if(empty($externalProgramRegisteration)) {
            $externalProgramRegisteration = new ExternalProgramStudent();
            $externalProgramRegisteration->student_id = $student->id;
        }

        $archivePath="users/user_".$student->id;       
        $archive = Archive::get($archivePath);
        if($archive)
        {
            Archive::where('archive.path',$archivePath)->delete();  
        }
        
        $file = $archive->addFile($request->birthDate, "birth_certificate_copy");
        $file = $archive->addFile($request->secondaryCertificate, "certification_copy");
        $file = $archive->addFile($request->englishLanguage, "english_certificate_copy");
        $file = $archive->addFile($request->nationalId, "national_id_copy");

        $externalProgramRegisteration->status = ExternalProgramStudent::STATUS_PENDING_ACCEPTED;
        $externalProgramRegisteration->save();   
        return redirect(route('show_external_program'))->with('status', 'your Files has been Uploaded.');
    }
    public function saveExternalProgram(Request $request) {

        $user = auth()->user();
        $student = $user->student;

        $externalProgramRegisteration = $student->externalProgramRegisteration();
        if(empty($externalProgramRegisteration)) {
            $externalProgramRegisteration = new ExternalProgramStudent();
            $externalProgramRegisteration->student_id = $student->id;
        }


        $externalProgramRegisteration->external_program_id = $request->external_program_id;
        $externalProgramRegisteration->status = ExternalProgramStudent::STATUS_PENDING;   

        $externalProgramRegisteration->save();
        
        return redirect(route('show_external_program'))->with('status', 'your request has been saved.');
    }

    public function showExternalProgram() {

        $user = auth()->user();
        $student = $user->student;
        $externalProgramRegisteration = $student->externalProgramRegisteration();
        $archivePath="users/user_".$student->id; 
        $archive = Archive::get($archivePath);

        $path = [
            (object)[
                'link' => route('dashboard'),
                'title' => __('tr.Dashboard')
            ],
        ];
       
        return view('external_programs.show', compact('path', 'student','archive'));
    }

}