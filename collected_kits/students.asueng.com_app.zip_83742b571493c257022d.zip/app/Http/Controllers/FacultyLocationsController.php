<?php

namespace App\Http\Controllers;

use App\FacultyBuilding;
use App\FacultyLocation;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator; 

class FacultyLocationsController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request){

        if(!auth()->user()->hasPermissionTo('access_lookups'))
            abort(401);

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $buildingId = $columns[0]["search"]["value"];
            $status = $columns[1]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = FacultyLocation::select('faculty_locations.id', 'faculty_locations.name', 'faculty_buildings.id as building_id', 'faculty_buildings.name as building_name', 'faculty_locations.floor', 'faculty_locations.capacity', 'faculty_locations.sectors', 'faculty_locations.status')
                ->leftJoin('faculty_buildings', 'faculty_buildings.id', '=' , 'faculty_locations.building_id')
                ->orderBy($orderBy, $orderDir);

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", $textSearch);
                $query->Where(\DB::raw("CONCAT(COALESCE(faculty_buildings.name,''), ' ', COALESCE(faculty_locations.name,''))") , "like", "%$textSearch%");
            }

            if ($buildingId) {
                $query->where('faculty_locations.building_id', $buildingId);
            }

            if ($status!==null) {
                $query->where('faculty_locations.status', $status);
            }

            \Log::info('Result:', [$query->toSql()]);
            $rows = $query->where('faculty_locations.active',1)->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $path = [ 
            (object) [
            'link' => route('manage'),
            'title' => __('tr.Manage'),
            ],
        ];

        $statusLabels = FacultyLocation::statusLabels();

        $buildings = FacultyBuilding::where('active', 1)->pluck('name', 'id')->toArray(); 

        return view('manage.locations',compact('path', 'buildings', 'statusLabels'));
    }

    public function save(FacultyLocation $location, Request $request){

        if(!auth()->user()->hasPermissionTo('edit_lookups'))
            abort(401);

        $validatedData = $request->validate([
            'name'=>'required|string',
            'capacity'=>'required|numeric',
            'sectors'=>'required|numeric',
            'building_id'=>'required',
            'status'=>'required',
        ]);

        $location->fill($request->all());
        $location->save();

        if($request->ajax()) {
            $result = [
                'id'=>$location->id,
                'name'=>$location->name,
                'building_id'=>$location->building_id,
                'building_name'=>$location->building->name,
                'floor'=>$location->floor,
                'capacity'=>$location->capacity,
                'sectors'=>$location->sectors,
                'status'=>$location->status,
            ];
            return response()->json($result);
        }

    }

    public function delete(FacultyLocation $location) {

        if(!auth()->user()->hasPermissionTo('delete_lookups'))
            abort(401);

        $location->active = 0;
        $location->save();
    }
}
