<?php

namespace App\Http\Controllers;

use App\Archive;
use App\Letters;
use App\Report\ReportSystem;

class LettersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function military(){
        $data = collect([
            'number' => 5111,
            'date' => "2018/10/24",
            'name' => "حسن محمد عبد الستار",
            'degree' => "المدرس المساعد",
            'department' => "الهندسة الإنشائية",
            'age' => 29,
            'ageDate' => "2018/11/09",
        ]);
        $report = new ReportSystem(null, null, 'ar',$data,
            'letters.militaryStatus',null,'A4','P','StaffAffairs');
        $report->build();
    }
}