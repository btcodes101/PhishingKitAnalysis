<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Student;
use App\Bylaw;
use App\User;
use App\BranchingPreference;
use App\Plan;
use App\UserRequest;
use App\ChangeTrackPreference;
use App\Term;
use App\Study;
use App\PlanQuota;
use App\StudentControlAppeal;
use App\Committee;
use App\Setting;
use App\Archive;

use Illuminate\Support\Facades\Validator;

use Exception;
use Auth;
use DB;

class ControlController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('auth');
    }

    private function getPath() {
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('control'), 'title' => __('tr.Control')];
        return $path;
    }
    
   
    /**
     * A function to submit a control appeal for a term 
     * @param:  
     * @return: 
     */
    public function applyAppeal(Request $request){

        $student = Auth::user()->student;
        if(!$student)
            abort(404);

        if(!$student->canRequestGradesRecheck())
            abort(404);

        $terms = Term::getOpenedGradesRecheckTerms($student->bylaw);
        if(count($terms) == 0)
            abort(404);

        $coustPerCourse = Setting::value('control_appeal_cost_per_course');
            if(!$coustPerCourse)
                $coustPerCourse = 100;

        $data = [];

        if($request->ajax()){
            
            $validator = \Validator::make($request->all(), [
                'term_id' => 'required',
                'courses' => 'required',
                'stdComments' => 'required',
            ]);
            
            if($validator->fails())
                return response()->json(['errors'=>$validator->errors()->all()], 401);
            

            $term_id = $request->term_id;
            $courses = $request->courses;
            $stdComments = $request->stdComments;
            $totalAmount = count($courses) *  $coustPerCourse;

            $term = Term::findOrFail($term_id);

            $data = [
                'term name' => $term->en_name,
                'term_id' => $term->id,
                'courses' => $courses,
                'stdComments' => $stdComments,
            ];

            //Add new record to the user requests table
            $userRequest = new UserRequest();
            $userRequest->user_id = $student->id;
            $userRequest->type = "Student_Control_Appeals";
            $userRequest->total_amount = $totalAmount;
            $userRequest->save();
            $userRequest->refresh();

            //generate the merchantRefNo
            $merchantRefNo = $userRequest->id.'_'.time(). '@ctrappls';

            $userRequest->data = json_encode($data);
            $userRequest->merchant_reference_no = $merchantRefNo;
            // $userRequest->payment_provider = 'fawry';
            $userRequest->order_status = 'INCOMPLETE';
            $userRequest->save();
    
            $userRequest->refresh();

            //for bank misr pay with Credit Card transactions only
            $session_id =  $this->createCheckoutSession($merchantRefNo, $userRequest);
            $userRequest->session_id = $session_id;

            //for bank misr pay with Meeza Card transactions only
            $meeza_msg_signature =  $this->createMsgSignature( $totalAmount, $userRequest->created_at);
            $userRequest->meeza_msg_signature = $meeza_msg_signature;

            $userRequest->save();


            if(empty($userRequest->archive_id)) {
                $archive = Archive::get("users_requests/$userRequest->id");
                $userRequest->archive_id = $archive->id;
                $userRequest->save();
                $userRequest->refresh();
            }
    

            return response()->json(['status'=>'success', 'userRequestId' =>  $userRequest->id], 200);

        }else{

            foreach($terms as $term){

                //get the courses of the student [the published onces only]
                $data[$term->en_name] = Study::select('students_control_appeals.control_decision', 'students_control_appeals.id as appeal_id', 'studies.id', 'courses.en_name', 'courses.short_name', 'studies.course_id', 'studies.term_id')
                            ->leftJoin('courses', 'courses.id', '=', 'studies.course_id')
                            ->leftJoin('committees', 'committees.id', '=', 'studies.committee_id')
                            ->leftJoin('students_control_appeals', function($join) use($student, $term){
                                $join->on('courses.id', '=', 'students_control_appeals.course_id')
                                        ->where('students_control_appeals.student_id', '=', $student->id)
                                        ->where("students_control_appeals.term_id", $term->id);
                            })
                            ->where("studies.user_id", $student->id)
                            ->where("studies.term_id", $term->id)
                            ->where("committees.control_status", Committee::CONTROL_STATUS_PUBLISHED)
                            ->get();

            
            }      

            //dd($courses);
            $path = $this->getPath();
            
            return view('students/control/applyAppeal', compact('path', 'data', 'coustPerCourse'));
        }
    }

    /**
     * 
     */
    public function paymentConfirmation(UserRequest $userRequest){
       
        $student = Auth::user()->student;
        if(!$student)
            abort(404);

        if(!$student->canRequestGradesRecheck())
            abort(404);

        if($student->id != $userRequest->user_id)
            abort(401);
        
        
        $path = $this->getPath();

        return view('students/control/confirm', compact('path', 'userRequest'));

    }

    /**
     * 
     */
    public function cancelAppealForCourse(Request $request){
        
        $student = Auth::user()->student;
        if(!$student)
            abort(404);

        if(!$student->canRequestGradesRecheck())
            abort(404);

        $validator = \Validator::make($request->all(), [
            'appeal_id' => 'required',
        ]);
        
        if($validator->fails())
            return response()->json(['errors'=>$validator->errors()->all()], 401);

        $appeal_id = $request->appeal_id;
        $appeal = StudentControlAppeal::find($appeal_id);
        if(!$appeal)
            return response()->json(['errors'=> 'Unknown Request!'], 404);

        if($student->id != $appeal->student_id)
            return response()->json(['errors'=> 'Unauthorized Action!'], 401);
            

        $result = StudentControlAppeal::destroy($appeal_id);

        if($result)
            return response()->json(['status'=>'success'], 200);
        else
            return response()->json(['errors'=>'Unknown Error'], 501);
    }

     /**
     * A function to display the control appeal result for a term 
     * @param:  
     * @return: 
     */
    public function appealResult(){
    
        abort(401);

        $lang = lang('name');
         
        
        $student = Auth::user()->student;
        if(!$student)
            abort(404);

        $appelas = StudentControlAppeal::leftJoin('terms', 'terms.id', 'students_control_appeals.term_id')
                                        ->leftJoin('courses', 'courses.id', '=', 'students_control_appeals.course_id')
                                        ->where('student_id', $student->id)
                                        ->orderBy('students_control_appeals.id', 'DESC')
                                        ->get([
                                            'terms.id as term_id',
                                            'terms.' . $lang . ' as term_name',
                                            'courses.' . $lang . ' as course_name',
                                            'courses.short_name as short_name',
                                            'students_control_appeals.control_decision as control_decision',
                                        ]);

        $appelas = $appelas->mapToGroups(function ($item, $key) {
            return [$item->term_name => $item];
        });

        /*foreach($appelas as $terms){
            foreach($terms as $term){
                d($term->course_name);
            }
        }*/

        //dd($appelas);
        $path = $this->getPath();
            
        return view('students/control/appealResult', compact('path', 'appelas'));
    }
}
