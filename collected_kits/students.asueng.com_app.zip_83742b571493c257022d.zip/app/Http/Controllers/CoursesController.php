<?php

namespace App\Http\Controllers;

use App;
use App\Archive;
use App\File;
use App\Study;
use App\Term;
use App\TermPlanCourse;
use App\User;
use App\Department;
use App\Course;
use App\Bylaw;
use Auth;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\Paginator;
use Maatwebsite\Excel\Facades\Excel;

class CoursesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the courses list.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {

        if(!auth()->user()->hasPermissionTo('access_courses'))
            abort(401);

        /*foreach (Course::all() as $course) {
            $course->updateFTS();
        }*/

        $lang = lang();

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $offeringDepartmentID = $columns[0]["search"]["value"];
            $bylaw = $columns[1]["search"]["value"];
            $editStatus = $columns[2]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $code = "code";
            if($lang=="ar")$code = "ar_code";

            $query = \DB::table('courses')
                ->select(\DB::raw("courses.id, courses.plan_id as course_plan_id,courses.".$lang."_name as name, (CASE WHEN courses.$code>'' THEN courses.$code ELSE courses.code END) as code,
                 departments.".$lang."_name as department, courses.bylaw, bylaws.".$lang."_name as bylaw_title , 
                 CONCAT(UPPER(plans.bylaw), ':', CASE WHEN plans.year_id<100 THEN years.".$lang."_name ELSE plans.".$lang."_program END, ', ',plans.".$lang."_minor) as plan_name"))
                ->leftJoin('plans','plans.id','=', 'courses.plan_id')
                ->leftjoin('departments','courses.offering_department_id','=','departments.id')
                ->leftjoin('years','years.id','=', 'plans.year_id')
                ->orderBy($orderBy, $orderDir);

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $textSearch = mb_ereg_replace("_", "\_", $textSearch);
                $query->Where(\DB::raw("COALESCE(search_text,'')") , "like", "%$textSearch%");
            }

            if ($offeringDepartmentID) {
                $query->where('courses.offering_department_id', '=', "$offeringDepartmentID");
            }

            if ($bylaw) {
                $query->where('courses.bylaw', '=', "$bylaw");
            }

            if ($editStatus!==null) {
                $query->where('courses.edit_status', '=', $editStatus);
            }

            $query->Where('courses.active', '=', 1);

            $query->leftjoin('bylaws','bylaws.code','=','courses.bylaw');

            \Log::info('Request:', [$query->toSql()]);

            $result = $query->paginate($length);

            return [
                'draw' => $draw,
                'recordsTotal' => $result->total(),
                'recordsFiltered' => $result->total(),
                'data' => $result
            ];
        }

        $path = [
            (object)[
                'link' => route('study'),
                'title' => __('tr.Study'),
            ],
        ];

        $departments = Department::select('id', $lang.'_name as name')->where('active', '=', 1)->where('parent_id', '!=', 0)->orderBy('id', 'asc')->pluck('name', 'id')->toArray();

        $bylaws = Bylaw::select('code AS id', $lang.'_name AS name')
            ->pluck('name', 'id')->toArray();

        $editStatusLabels = Course::editStatusLabels();

        return view('study.courses.index', compact('path', 'departments', 'bylaws', 'editStatusLabels'));
    }

    /**
     * Dispaly the course.
     *
     * @param Course $course
     * @return array
     */
    public function show(Request $request ,Course $course) {

        $course_term = $course->term_type;

        if(!auth()->user()->hasPermissionTo('show_courses'))
            abort(401);

        $lang = lang();
        if ($request->ajax() && $request->ajax_separator == 1){

            $draw = $request->draw;
            $columns = $request->columns;
            $termID = $columns[0]["search"]["value"];
            $planID = $columns[1]["search"]["value"];

            \Log::info('Request:', $request->all());

            $instructors = User::select('users.'.$lang.'_name as name','mobile','email','studies.role','studies.plan_id',
                'plans.'.$lang.'_minor as minor', 'plans.'.$lang.'_major as major', 'terms.'.$lang.'_name as term_name')
                ->join('instructors','instructors.id','users.id')
                ->join('studies','studies.user_id','instructors.id')
                ->join('terms', 'terms.id', 'studies.term_id')
                ->join('plans', 'plans.id', 'studies.plan_id')
                ->where('studies.course_id',$course->id);

            if ($termID){
                $instructors->where('studies.term_id', $termID);
            }

            if ($planID){
                $instructors->where('studies.plan_id', $planID);
            }

            $instructors = $instructors->paginate(99999);

            return [
                'draw' => $draw,
                'data' => $instructors
            ];
        }

        $path = [
            (object)[
                'link' => route('study'),
                'title' => __('tr.Study'),
            ],
            (object)[
                'link' => route('courses'),
                'title' => __('tr.Courses'),
            ],
        ];

        $latestTerm = DB::select('SELECT MAX(term_id) as "max_term" FROM `grades_total`')[0]->max_term;

        if ($request->ajax() && $request->ajax_separator == 2){

            $termID = $request->term_id;
            $planID = $request->plan_id;

            if($course->term_type==0){ //One Term
                // dd($currentTermID);
                $students = Study::select('users.id as student_id', 'studies.course_id as course_id', 'studies.plan_id','studies.control_status',
                    'users.'.$lang.'_name as student_name', 'studies.final_oral', 'studies.final_work', 'studies.final_exam',DB::raw("courses.max_total as max_total"),
                    DB::raw('SUM( IFNULL(studies.final_oral,0) + IFNULL(studies.final_work,0) + IFNULL(studies.final_exam,0) ) as total'),
                    DB::raw("ROUND((((IFNULL(studies.final_oral,0) + IFNULL(studies.final_work,0) + IFNULL(studies.final_exam,0))/(max_total))*100),2) as percentage"))
                    ->where('studies.course_id',$course->id)
                    ->where('studies.role',1)
                    ->leftJoin('users','users.id','studies.user_id')
                    ->leftJoin('students','students.id','users.id')
                    ->leftJoin('courses','courses.id','studies.course_id')
                    ->groupBy('users.id','studies.plan_id');

                if ($termID){
                    $students->where('studies.term_id',$termID);
                } else {
                    $students->where('studies.term_id',$latestTerm);
                }

                if ($planID){
                    $students->where('studies.plan_id',$planID);
                }

                $students = $students->get();
            } else { // Two Terms
                $students = Study::select('users.id as student_id', 'studies.course_id as course_id', 'studies.plan_id','studies.control_status',
                    'users.'.$lang.'_name as student_name','studies.first_oral','studies.first_work','studies.first_exam','studies.final_oral', 'studies.final_work', 'studies.final_exam',DB::raw("courses.max_total as max_total"),
                    DB::raw('SUM( IFNULL(studies.final_oral,0) + IFNULL(studies.final_work,0) + IFNULL(studies.final_exam,0) + IFNULL(studies.first_exam,0) + IFNULL(studies.first_work,0) + IFNULL(studies.first_oral,0) ) as total'),
                    DB::raw("ROUND(((( IFNULL(studies.first_oral,0) + IFNULL(studies.first_work,0) + IFNULL(studies.first_exam,0) + IFNULL(studies.final_oral,0) + IFNULL(studies.final_work,0) + IFNULL(studies.final_exam,0))/(max_total))*100),2) as percentage"))
                    ->where('studies.course_id',$course->id)
                    ->where('studies.role',1)
                    ->where('studies.active',1)
                    ->leftJoin('users','users.id','studies.user_id')
                    ->leftJoin('students','students.id','users.id')
                    ->leftJoin('courses','courses.id','studies.course_id')
                    ->groupBy('users.id','studies.plan_id');

                if ($termID){
                    $students->where('studies.term_id',$termID);
                } else {
                    $students->where('studies.term_id',$latestTerm);
                }

                if ($planID){
                    $students->where('studies.plan_id',$planID);
                }

                $students = $students->get();
            }

            /* Max Course degree percentage */

            if (isset($students[0]->control_status) != null) {
                $result = [
                    'data' => $students,
                    'edit' => $students[0]->control_status
                ];
            }else{
                $result = [
                    'data' => $students,
                    //'edit' => $students[0]->control_status
                ];
            }

            return response()->json($result);
        }

        $all_courses = DB::select('select max_first_work,max_first_oral,max_first_exam,max_final_work,max_final_oral,max_final_exam from courses where id = '.$course->id);

        $all_courses = array_map(function ($value) {
            return (array)$value;
        }, $all_courses);

        $course_grade = $all_courses[0];

        $bylaws = Bylaw::where('current', 1)->orderBy('code', 'DESC')->get();
        $terms = Term::select('id' ,$lang.'_name as name' ,'years', 'start_date', 'end_date','active')
            ->where('active','=','1')
            ->orderBy('start_date', 'desc')
            ->get();

        $currentTermID = $terms[0]->id;

        if ($request->ajax() && $request->ajax_separator == 3){

            $plans = TermPlanCourse::select('plans.id', 'plans.'.$lang.'_minor as minor', 'plans.'.$lang.'_major as major',
                'years.'.$lang.'_name as year_name')
                ->where('terms_plans_courses.course_id', $course->id)
                ->where('terms_plans_courses.term_id', $request->term_id)
                ->leftjoin('plans', 'plans.id', 'terms_plans_courses.plan_id')
                ->leftjoin('years', 'years.id', 'plans.year_id')
                ->get();

            return [
                'data' => $plans
            ];
        }



        return view('study.courses.show',compact('path', 'course', 'course_grade','course_term', 'bylaws', 'terms', 'currentTermID'));
    }

    public function courseGrade (Request $request){

        // $data = json_decode(stripslashes($_POST['data']));

        // dd($request->all());

        $terms = Term::select('id', 'en_name as name')
            ->where('active', '=', 1)
            ->orderBy('id', 'desc')
            ->pluck('name', 'id')->toArray();

        $currentTermID = null;
        if(count($terms)>=1) {
            $currentTermID = array_keys($terms)[0];
        }

        if($request->term_course != 0){
            $student_id = $request->std_id;
            $course_id = $request->course_id;
            $plan_id = $request->plan_id;
            $oral = $request->oral;
            $work = $request->work;
            $exam = $request->exam;
            $first_oral = $request->first_oral;
            $first_work = $request->first_work;
            $first_exam = $request->first_exam;

            $courseID = json_decode($request->course_id);
            $max_total = Course::where('id', $course_id)->first()->max_total;
            $max_total_exam = Course::where('id', $course_id)->first()->max_final_exam;
            $max_total_work = Course::where('id', $course_id)->first()->max_final_work;
            $max_total_oral = Course::where('id', $course_id)->first()->max_final_oral;

            $study = Study::where('user_id',$student_id)
                ->where('course_id',$course_id)
                ->where('plan_id',$plan_id)

                ->update([

                    'first_oral' => $first_oral,
                    'first_work' => $first_work,
                    'first_exam' => $first_exam,
                    'final_exam' => $exam,
                    'final_work' => $work,
                    'final_oral' => $oral,
                ]);

        }else{
            $student_id = $request->std_id;
            $course_id = $request->course_id;
            $plan_id = $request->plan_id;
            $oral = $request->oral;
            $work = $request->work;
            $exam = $request->exam;

            $courseID = json_decode($request->course_id);
            $max_total = Course::where('id', $course_id)->first()->max_total;
            $max_total_exam = Course::where('id', $course_id)->first()->max_final_exam;
            $max_total_work = Course::where('id', $course_id)->first()->max_final_work;
            $max_total_oral = Course::where('id', $course_id)->first()->max_final_oral;

            $study = Study::where('user_id',$student_id)
                ->where('course_id',$course_id)
                ->where('plan_id',$plan_id)

                ->update([
                    'final_exam' => $exam,
                    'final_work' => $work,
                    'final_oral' => $oral,
                ]);
        }



        return response()->json('Done');
    }

    public function sendToControl(Course $course){

        $terms = Term::select('id', 'en_name as name')
            ->where('active', '=', 1)
            ->orderBy('id', 'desc')
            ->pluck('name', 'id')->toArray();

        $currentTermID = null;
        if(count($terms)>=1) {
            $currentTermID = array_keys($terms)[0];
        }

        Study::where('studies.course_id',$course->id)
            ->where('studies.term_id',$currentTermID)
            ->where('studies.role',1)
            ->groupBy('users.id','studies.plan_id')
            ->update([
                'control_status' => 1
            ]);

        return response()->json('Done');
    }

    public function exportGrades(Course $course){

        $lang = lang();

        $terms = Term::select('id', 'en_name as name')
            ->where('active', '=', 1)
            ->orderBy('id', 'desc')
            ->pluck('name', 'id')->toArray();

        $currentTermID = null;
        if(count($terms)>=1) {
            $currentTermID = array_keys($terms)[0];
        }

        $query = Study::where('studies.course_id',$course->id)
            ->where('studies.term_id',$currentTermID)
            ->where('studies.role',1)
            ->leftJoin('users','users.id','studies.user_id')
            ->leftJoin('students','students.id','users.id')
            ->leftJoin('courses','courses.id','studies.course_id')
            ->groupBy('users.id','studies.plan_id');
        $students = clone $query;
        if (auth()->user()->hasRole('ControlEditor')){
            $students = $students->select('users.'.$lang.'_name as Name', 'studies.oral as Oral', 'studies.work as Work', 'studies.exam as Exam',
                DB::raw('SUM( NVL(studies.oral,0) + NVL(studies.work,0) + NVL(studies.exam,0) ) as Total'),
                'studies.exam',DB::raw("courses.max_total as Max Total"),
                DB::raw("ROUND((((NVL(studies.oral,0) + NVL(studies.work,0) + NVL(studies.exam,0))/(max_total))*100),2) as Percentage"))->get();
        } else {
            $students = $students->select('users.'.$lang.'_name as Name', 'studies.oral as Oral', 'studies.work as Work',
                DB::raw('SUM( NVL(studies.oral,0) + NVL(studies.work,0) + NVL(studies.exam,0) ) as Total'),
                'studies.exam',DB::raw("courses.max_total as Max Total"),
                DB::raw("ROUND((((NVL(studies.oral,0) + NVL(studies.work,0) + NVL(studies.exam,0))/(max_total))*100),2) as Percentage"))->get();
        }


        return Excel::create('Course Students Grades', function($excel) use ($students) {

            $excel->sheet('Courses', function($sheet) use ($students)
            {
                $sheet->fromArray($students);
            });
        })->download('xlsx');
    }

    /**
     * Edit the course.
     *
     * @param Course $course
     * @return \Illuminate\Http\Response
     */
    public function edit(Course $course) {

        if(!auth()->user()->hasAnyPermission(['edit_courses', 'add_courses']))
            abort(401);

        if(empty($course->id))
        {
            $course->id = 0;
            $course->max_first_work = $course->max_first_oral = $course->max_first_exam = 0;
            $course->max_final_work = $course->max_final_oral = $course->max_final_exam = 0;
            $course->max_total = 0;
            $course->credit = 0;
            $course->first_lecture = $course->first_tutorial = $course->first_laboratory = 0;
            $course->final_lecture = $course->final_tutorial = $course->final_laboratory = 0;
        }

        $path = [
            (object)[
                'link' => route('study'),
                'title' => __('tr.Study'),
            ],
            (object)[
                'link' => route('courses'),
                'title' => __('tr.Courses'),
            ],
            /*(object)[
                'link' => route('show_course', ['course_id'=>$course->id]),
                'title' => $course->lang('name')
            ],*/
        ];

        $departments = Department::select('id', 'en_name as name')->where('active', '=', 1)->orderBy('id', 'desc')->pluck('name', 'id')->toArray();

        $bylaws = Bylaw::select('code AS id', 'en_name AS name')
            ->pluck('name', 'id')->toArray();

        return view('study.courses.edit',compact('path', 'course', 'departments', 'bylaws'));
    }

    /**
     * Save the course.
     *
     * @param Course $course
     * @return \Illuminate\Http\Response
     */
    public function save(Course $course, Request $request) {

        if(!auth()->user()->hasAnyPermission(['edit_courses', 'add_courses']))
            abort(401);

        $course->fill($request->all());
        if(!empty($course->en_describtion))$course->en_describtion = trim($course->en_describtion);
        if(!empty($course->ar_describtion))$course->ar_describtion = trim($course->ar_describtion);
        if(!empty($course->references))$course->references = trim($course->references);
        $course->active = 1;
        $course->save();
        $course->updateFTS();

        return redirect(route('show_course', ['id'=>$course->id]));
    }

    /**
     * Soft Delete the course.
     *
     * @param Course $course
     * @return \Illuminate\Http\Response
     */
    public function delete(Course $course) {

        if(!auth()->user()->hasPermissionTo('delete_courses'))
            abort(401);

        $course->active = 0;
        $course->save();
        die("done");
    }

    /**
     * Get courses for given query
     *
     * @return void
     */
    public function resolve(Request $request) {

        if(!auth()->user()->hasPermissionTo('access_courses'))
            return response('Unauthenticated', 401);

        $bylaw = $request['bylaw'];
        $courses_codes = $request['courses_codes'];
        $courses_codes = preg_replace("/[\n\r]/",",",$courses_codes);
        $courses_codes = str_replace(' ', ',', $courses_codes);
        $courses_codes = explode(',', $courses_codes);

        $query = Course::select('id', 'code', 'en_name', 'bylaw')
            ->whereIn("courses.code", $courses_codes)
            ->orderBy('bylaw')->orderBy('code');

        if($bylaw) {
            $query->where("bylaw", '=', $bylaw);
        }

        $courses = $query->get();

        $results = [];
        foreach ($courses as $course) {
            $results[]= [
                'id' =>  $course->id,
                'name' =>  $course->code." (".strtoupper($course->bylaw).")".":".$course->en_name,
            ];
        }

        return response()->json($results);
    }

    /**
     * Get courses for given query
     *
     * @return void
     */
    public function names(Request $request) {

        if(!auth()->user()->hasPermissionTo('access_courses'))
            return response('Unauthenticated', 401);

        $orgQuery = $request["query"];
        $limit = $request["limit"];
        $query = getFTS($orgQuery);
        $query = mb_ereg_replace(" ", "%", $query);

        $courses = Course::select('id', 'code', 'en_name', 'ar_name', 'bylaw', 'plan_id', 'base_course_id')
            ->where('current', 1)
            ->where(\DB::raw("COALESCE(search_text,'')") , "like", "%$query%")
            ->limit($limit)->get();
        $results = [];

        foreach ($courses as $course) {
            $bylaw = strtoupper($course->bylaw);
            \Log::info('Course:', [$course->code, $course->plan_id, $course->base_course_id]);
            if($course->plan_id && $course->base_course_id)
                $bylaw .= " - ".$course->plan->lang('minor');
            $results[]= ['name' =>  "$course->code ($bylaw): $course->en_name", 'search' =>  "$orgQuery, $course->code, $bylaw, $course->en_name, $course->ar_name", 'id' =>  $course->id];
        }

        return response()->json($results)->withCallback("callback");
    }

    public function coursesReport(Request $request){
        if(!auth()->user()->hasPermissionTo('access_courses'))
            abort(401);

        $offering_department_id = $request->get('offering_department_id');
        $bylaw = $request->get('bylaw');
        $text_search = $request->get('text_search');

        $query = Course::select('courses.code as Code',
            'courses.en_name as English Name', 'courses.ar_name as Arabic Name',
            'bylaws.en_name as Bylaw',
            'departments.code as Offered By',
            'courses.term_type as Type',
            'courses.credit as Credit',
            'courses.first_lecture', 'courses.first_tutorial', 'courses.first_laboratory',
            'courses.final_lecture', 'courses.final_tutorial', 'courses.final_laboratory',
            'courses.max_first_work', 'courses.max_first_oral', 'courses.max_first_exam',
            'courses.max_final_work', 'courses.max_final_oral', 'courses.max_final_exam')
            ->join('departments','courses.offering_department_id','=','departments.id')
            ->join('bylaws','bylaws.code','=','courses.bylaw')
            ->orderBy('courses.en_name');

        if ($offering_department_id) {
            $query->where('financial_transactions.batch_id', 'like', "%$offering_department_id");
        }

        if ($bylaw) {
            $query->where('courses.bylaw', '=', $bylaw);
        }

        if ($text_search) {
            $text_search = mb_ereg_replace(" ", "%", $text_search);
            $text_search = mb_ereg_replace("_", "\_", $text_search);
            $query->Where(\DB::raw("COALESCE(search_text,'')") , "like", "%$text_search%");
        }

        $query = $query->get();

        return Excel::create('Courses Report', function ($excel) use ($query) {
            $excel->sheet('Courses', function ($sheet) use ($query) {
                $sheet->fromArray($query);
            });
        })->download();
    }
}
