<?php

namespace App\Http\Controllers;

use App\Website;
use App\User;
use App\Instructor;
use App\Archive;
use Illuminate\Http\Request;

class StaffProfileController extends Controller
{

    public function index(){
        $website = new Website(Archive::locate('home'));
        $instructors = User::where('type', User::TYPE_INSTRUCTOR)->join('instructors', 'instructors.id', '=', 'users.id')->paginate(9);
        return view('website.staff.profiles', compact('website','instructors'));
    }


    public function show($instructor){

        $website = new Website(Archive::locate('home'));
        if(is_numeric($instructor)) {
            $user = User::where('id', $instructor)->where('type', 1)->first();
        }
        else {
            $user = User::where('email', $instructor."@eng.asu.edu.eg")->where('type', 1)->first();
        }
        if(empty($user))abort(404);
        $instructor = $user->instructor;
        return view('website.staff.profile', compact('website','instructor','user'));        
    }

 

    public function search(Request $request)
    {
        $website = new Website(Archive::locate('home'));        
        
        if($request->ajax()) {

            $sort_by = $request->get('sortby');
            $sort_type = $request->get('sorttype');
            $query = $request->get('query');
            $textSearch = mb_ereg_replace(" ", "%", getFTS($query));
            $instructors = User::where('type', User::TYPE_INSTRUCTOR)->where("users.search_text",'LIKE',"%$textSearch%")->join('instructors', 'instructors.id', '=', 'users.id')->paginate(9);
            return view('website.staff.presult', compact('instructors'))->render();
        }
    }
}
