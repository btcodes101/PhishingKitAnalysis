<?php

namespace App\Http\Controllers;

use App\Log;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;


class LogsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {

        if (!auth()->user()->hasPermissionTo('access_log'))
            abort(401);

        if ($request->ajax()) {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $from = $columns[1]["search"]["value"];
            $to = $columns[2]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = Log::select('logs.id', 'logs.model_type', 'logs.model_id', 'logs.type', 'logs.description', 'logs.created_at as date', 'users.'.lang().'_name as user')
                ->leftJoin('users', 'users.id', '=', 'logs.user_id')
                ->orderBy('logs.id', 'DESC');

            if ($from !== null && $to !== null) {
                $query->whereBetween('logs.created_at', [$from, $to]);
            }

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", $textSearch);
                $query->Where(\DB::raw("CONCAT(COALESCE(logs.description,''), ' ', COALESCE(users.en_name,''), ' ', COALESCE(users.ar_name,''), ' ', COALESCE(users.type,''))"), "like", "%$textSearch%");
            }

            \Log::info('Request:', [$query->toSql()]);

            $result = $query->paginate($length);

            return [
                'draw' => $draw,
                'recordsTotal' => $result->total(),
                'recordsFiltered' => $result->total(),
                'data' => $result
            ];
        }

        $path = [
            (object)[
                'link' => route('manage'),
                'title' => __('tr.Manage'),
            ]
        ];

        return view('manage.logs', compact('path'));
    }

    public function showLog(Log $log){
        switch ($log->model_type) {

            case 'App\User':
                return redirect(route('show_user',['user'=>$log->model_id]));
                break;

        }

        abort(401);
    }
}