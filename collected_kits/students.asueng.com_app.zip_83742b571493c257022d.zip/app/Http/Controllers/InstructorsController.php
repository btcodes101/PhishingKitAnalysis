<?php

namespace App\Http\Controllers;

use App;
use App\Department;
use App\Instructor;
use App\InstructorDegree;
use App\InstructorStatus;
use App\UserStatus;
use App\UserStatusType;
use App\User;
use App\Log;
use App\Website;
use App\Archive;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Maatwebsite\Excel\Facades\Excel;
use PDF;
use Spatie\Permission\Models\Role;
use TCPDF_FONTS;

class InstructorsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth')->except('staffIndex', 'staffSearch', 'staffShow');;
    }

    public function main()
    {
        $path = [];

        return view('instructors.main', compact('path'));
    }

    /**
     * Show instructors list.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (!auth()->user()->hasPermissionTo('access_instructors'))
            abort(401);

        $lang = app()->getLocale();

        if ($request->ajax()) {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $departmentID = $columns[0]["search"]["value"];
            $degree = $columns[1]["search"]["value"];
            $statusId = $columns[2]["search"]["value"];
            $userActive = $columns[3]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = \DB::table('users')->select('users.id',
                'users.code',
                "users." . $lang . "_name as name",
                "departments." . $lang . "_name as department",
                "instructors_degrees." . $lang . "_name as degree",
                "users_status_types." . $lang . "_name as status",
                'users.email',
                'users.mobile')
                ->leftJoin('instructors', 'users.id', '=', 'instructors.id')
                ->leftJoin('instructors_degrees', 'instructors_degrees.code', '=', 'instructors.degree')
                ->leftjoin('users_status_types', 'users_status_types.id', '=', 'users.status_id')
                ->leftJoin('departments', 'instructors.department_id', '=', 'departments.id')
                ->orderBy($orderBy, $orderDir);

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $query->Where(\DB::raw("COALESCE(users.search_text,'')"), "like", "%$textSearch%");
            }

            if ($departmentID) {
                $query->Where('instructors.department_id', '=', $departmentID);
            }

            if ($degree) {
                $query->Where('instructors.degree', '=', $degree);
            }

            if ($statusId) {
                $query->where('users.status_id', $statusId);
            }

            if (isset($userActive)) {
                $query->Where('users.active', '=', $userActive);
            }

            $query->Where('users.type', '=', 1);

            \Log::info('Result:', [$query->toSql()]);

            $rows = $query->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $path = [];

        $departments = Department::select('id', $lang . "_name as name")->where('active', '=', 1)->orderBy('id', 'desc')->where('parent_id', '!=', 0)->pluck('name', 'id')->toArray();

        $statusList = UserStatusType::pluck(lang() . '_name as name', 'id')->toArray();

        $degrees = InstructorDegree::select('code as id', $lang . "_name as name")->pluck('name', 'id')->toArray();

        return view('instructors.index', compact('path', 'departments', 'degrees', 'statusList'));
    }

    

    /**
     * Display the user.
     *
     * @param Instructor $instructor
     * @return \Illuminate\Http\Response
     */
    public function show(Instructor $instructor)
    {
        if (!($instructor->id == auth()->user()->id || auth()->user()->hasPermissionTo('show_instructors')))
            abort(401);

        $path = [];

        if (auth()->user()->hasPermissionTo('access_instructors')) {
            $path[] = (object)[
                'link' => route("instructors"),
                'title' => __('tr.Instructors'),
            ];
        }

        $roles = Role::all();

        return view('instructors.show', compact('path', 'instructor','roles'));
    }

    public function editWork(Instructor $instructor)
    {
        if (!auth()->user()->hasPermissionTo('edit_instructors'))
            abort(401);

        $user = $instructor->user;

        $path[] = (object)[
            'link' => route('show_instructor', ['id' => $user->id]),
            'title' => $user->lang('name')
        ];

        $statusList = UserStatusType::pluck(lang() . '_name as name', 'id')->toArray();

        $degrees = InstructorDegree::select('code as id', 'en_name as name')->pluck('name', 'id')->toArray();

        $departments = Department::select('id', 'en_name as name')->where('parent_id', '!=', 0)->where('active', '=', 1)->orderBy('id', 'desc')->pluck('name', 'id')->toArray();

        return view('instructors.edit_work', compact('path', 'user', 'instructor', 'statusList', 'degrees', 'departments'));
    }

    public function saveWork(Instructor $instructor, Request $request)
    {
        if (!auth()->user()->hasPermissionTo('edit_instructors'))
            abort(401);

        $user = $instructor->user;

        $this->validate($request, [
            'en_name' => 'required|max:255|min:7',
            'email' => 'required|email',
            'code' => 'required',
            'ar_name' => 'required|string',
            'national_id' => 'required|alpha_num',
        ]);

        if(User::where('id', '!=', $user->id)->where('type', '=', $user->type)->where('national_id', '=', $request->national_id)->count()>0) {
            $this->validate($request, [
                    'national_id' => 'required|unique:users,national_id,'.$user->id,
                ]);
        }

        Log::add("Edit Work", "App\Instructor", $instructor->id, $instructor->user->lang('name'), $instructor->getAttributes(), $request->all());

        $user->code = $request->code;
        $user->email = $request->email;
        $user->en_name = $request->en_name;
        $user->ar_name = $request->ar_name;
        $user->national_id = $request->national_id;
        $user->birth_date = $request->birth_date;
        $user->email_alt = $request->email_alt;
        $user->phone = $request->phone;
        $user->mobile = $request->mobile;
        $user->status_id = $request->status_id;
        $user->status_description = $request->status_description;
        $user->address = $request->address;
        $user->gender = $request->gender;
        $user->active = UserStatusType::find($user->status_id)->active;
        $user->save();
        $user->updateFTS();

        $instructor->department_id = $request->department_id;
        $instructor->degree = $request->degree;
        $instructor->insurance_no = $request->insurance_no;
        $instructor->seniority = $request->seniority;
        $instructor->graduation_year = $request->graduation_year;
        $instructor->faculty = $request->faculty;
        $instructor->university = $request->university;
        $instructor->msc_at = $request->msc_at;
        $instructor->msc_place = $request->msc_place;
        $instructor->phd_at = $request->phd_at;
        $instructor->phd_place = $request->phd_place;
        $instructor->emeritus_at = $request->emeritus_at;
        $instructor->professor_at = $request->professor_at;
        $instructor->assistant_professor_at = $request->assistant_professor_at;
        $instructor->teacher_at = $request->teacher_at;
        $instructor->teaching_assistant_at = $request->teaching_assistant_at;
        $instructor->demonstrator_at = $request->demonstrator_at;
        $instructor->save();

        if($user->active==0) { 
            $instructor->seniority = 0;
            $instructor->save();
        } else {
            Instructor::normalizeSeniority($instructor);
        }

        return redirect(route('show_instructor', ['id' => $user->id]));
    }

    public function editAcademic(Instructor $instructor)
    {
        if (!$instructor->canEditAcademic())
            abort(401);

        $user = $instructor->user;

        $path[] = (object)[
            'link' => route('show_instructor', ['id' => $user->id]),
            'title' => $user->lang('name')
        ];

        $statusList = InstructorStatus::select('code as id', 'en_name as name')->pluck('name', 'id')->toArray();

        return view('instructors.edit_academic', compact('path', 'user', 'instructor', 'statusList'));
    }

    /**
     * @param Instructor $instructor
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function saveAcademic(Instructor $instructor, Request $request)
    {
        if (!$instructor->canEditAcademic())
            abort(401);

        $user = $instructor->user;

        $this->validate($request, [
        ]);

        Log::add("Edit Academic", "App\Instructor", $instructor->id, $instructor->user->lang('name'), $instructor->getAttributes(), $request->all());

        $instructor->brief = $request->get('brief');
        $instructor->degrees = $request->get('degrees');
        $instructor->awards = $request->get('awards');
        $instructor->books = $request->get('books');
        $instructor->articles = $request->get('articles');
        $instructor->publications = $request->get('publications');
        $instructor->research_projects = $request->get('research_projects');
        $instructor->engineering_projects = $request->get('engineering_projects');
        $instructor->degrees_supervised = $request->get('degrees_supervised');
        $instructor->other = $request->get('other');
        $instructor->save();

        return redirect(route('show_instructor', ['id' => $user->id]));
    }

    public function editStatus(UserStatus $status, Instructor $instructor)
    {
        if (!auth()->user()->hasPermissionTo('edit_instructors'))
            abort(401);

        $user = $instructor->user;

        $path[] = (object)[
            'link' => route('show_instructor', ['id' => $user->id]),
            'title' => $user->lang('name')
        ];

        $statusTypes = \DB::table('users_status_types')->pluck('en_name as name', 'id')->toArray();

        return view('instructors.edit_status', compact('path', 'user', 'instructor', 'status', 'statusTypes'));
    }

    public function saveStatus(Instructor $instructor, UserStatus $status, Request $request)
    {
        if (!auth()->user()->hasPermissionTo('edit_instructors'))
            abort(401);

        $user = $instructor->user;

        $oldData = (empty($status->id))?null:$status->getAttributes();
        $this->validate($request, [
            'from' => 'required|date',
            'to' => 'nullable|after:from|date',
        ]);
        if(empty($status->id)) {
            $lastStatus = UserStatus::where('user_id', $user->id)->orderBy('from', 'DESC')->first();
            if ($lastStatus && $lastStatus->to == null) {
                $lastStatus->to = $request->from;
                $lastStatus->save();
            }
        }

        $status->user_id = $user->id;
        $status->status_id = $request->status_id;
        $status->from = $request->from;
        $status->to = $request->to;
        $status->description = $request->description;
        $status->save();

        Log::add(($oldData)?"Edit Status":"Add Status", "App\UserStatus", $status->id, "Status of ".$status->user->lang('name'), $oldData, $request->all());

        return redirect(route('show_instructor', ['id' => $user->id]));
    }

    public function deleteStatus(UserStatus $status)
    {
        Log::add("Delete Status", "App\UserStatus", $status->id, $status->user->lang('name'), $status->getAttributes(), null);

        if ($status->delete()) {
            return response()->json(['status' => true]);
        }

        return response()->json(['false' => true]);
    }

    public function upload(Request $request){
        if ($request->file('files')) {
            $file = $request->file('files');
            $extensions = array("xls", "xlsx", "xlm", "xla", "xlc", "xlt", "xlw");
            $result = $file[0]->getClientOriginalExtension();
            if (in_array($result, $extensions)) {
                $name = uniqid() . $file[0]->getClientOriginalName();
                $file[0]->move(storage_path('app'), $name);
                $data = Excel::load(storage_path("app/$name"))->get();
                $format = false;
                $lose_staff = array();
                foreach ($data as $key => $value) {
                    if ($value->code != null && $value->seniority != null) {
                        $user = User::where('code','=',trim($value->code))->first();
                        if ($user) {
                            $format = true;
                            $user->instructor->seniority = trim($value->seniority);
                            $user->instructor->push();
                        } else {
                            array_push($lose_staff, $value->code);
                        }
                    }
                }
                \Storage::disk('local')->delete($name);
                if (!empty($lose_staff)){
                    return \response()->json('Same staff dose not exit ');
                }elseif ($format){
                    return response()->json('Data Save');
                }else{
                    return \response()->json('Error Format');
                }

            } else {
                return response()->json("The Error file Format");
            }
        }
    }

    public function instructorsInformation(){

        $instructors = Instructor::select('users.code', 'users.ar_name', 'users.en_name', 'users.national_id', 'instructors.seniority','departments.ar_name as department', 'instructors_degrees.ar_name as degree', 'users_status_types.ar_name as status', 'users.status_description', 'users.birth_date', 'instructors.demonstrator_at','instructors.teaching_assistant_at','instructors.teacher_at', 'instructors.assistant_professor_at','instructors.professor_at','instructors.emeritus_at','instructors.msc_at', 'instructors.phd_at', 'users.mobile', 'users.email', 'users.address', 'instructors.graduation_year', 'instructors.faculty', 'instructors.university')
            ->join('users','users.id','=','instructors.id')
            ->join('departments','departments.id','=','instructors.department_id')
            ->leftJoin('instructors_degrees','instructors_degrees.code','=','instructors.degree')
			->leftjoin('users_status_types', 'users_status_types.id', '=', 'users.status_id')
			->where('users.active', 1)
            ->orderBy('instructors_degrees.id', 'DESC')
            ->orderBy('instructors.seniority', 'ASC')
            ->get();


        return Excel::create('Instructors Information', function($excel) use ($instructors) {
            $excel->sheet('Instructors Information', function($sheet) use ($instructors)
            {
                foreach ($instructors as $key => $value) {
                    $result[] = array(
                        'الكود' => $value->code,
                        'الإسم العربي' => $value->ar_name,
                        'الإسم الإنجليزي' => $value->en_name,
                        'الرقم القومي' => $value->national_id,
                        'الأقدمية' => $value->seniority,
                        'القسم' => $value->department,
                        'الدرجة' => $value->degree,
						'الحالة' => $value->status,
						'ملحوظة' => $value->status_description,
                        'تاريخ الميلاد' => $value->birth_date,
                        'التليفون' => $value->mobile,
                        'العنوان الإلكتروني' => $value->email,
                        'معيد' => $value->demonstrator_at,
                        'مدرس مساعد' => $value->teaching_assistant_at,
                        'مدرس' => $value->teacher_at,
                        'أستاذ مساعد' => $value->assistant_professor_at,
                        'أستاذ' => $value->professor_at,
                        'أستاذ متفرغ' => $value->emeritus_at,
                        'الماجستيير' => $value->msc_at,
                        'الماجستير من' => $value->msc_place,
                        'الدكتوراة' => $value->phd_at,
                        'الدكتوراة من' => $value->phd_place,
                        'سنة التخرج' => $value->graduation_year,
                        'الكلية' => $value->faculty,
                        'الجامعة' => $value->university,                        
                        'العنوان' => $value->address,                        
                    );
                }
                $sheet->setRightToLeft(true);
                $sheet->fromArray($result);
            });
        })->download();
    }

    public function careerProgression(User $user){

        $title = "Career Progression";
        PDF::setHeaderCallback(function ($pdf){
            $arabic = '
                <table style="text-align: right">
                    <tr>
                        <td>شئون أعضاء هيئة التدريس</td>
                    </tr>
                </table>';
            $fontname = TCPDF_FONTS::addTTFfont(public_path().'/arial.ttf', 'TrueTypeUnicode', '', 32);
            PDF::SetFont($fontname,'', 9);
            $pdf->writeHTML($arabic);

            $pdf->writeHTML('<br/><br/><hr>');
            $image_file = public_path().'/img/logo.png';
            $pdf->Image($image_file, 30, 5, 25, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
        });
        PDF::SetTitle($title);
        PDF::SetMargins(10, 45, 10);
        PDF::SetHeaderMargin(10);
        PDF::SetFooterMargin(20);

        $setting = ['a_meta_charset' => 'UTF-8', 'a_meta_dir' => 'rtl', 'a_meta_language' => 'ar', 'w_page' =>  'page' ];
        PDF::setLanguageArray($setting);

        PDF::setFontSubsetting(true);
        PDF::SetAutoPageBreak(true, 10);
        $fontname = TCPDF_FONTS::addTTFfont(public_path().'/arial.ttf', 'TrueTypeUnicode', '', 32);
        PDF::SetFont($fontname,'', 14);
        PDF::AddPage('P', 'A4');

        $view = \View::make("instructors.reports.careerProgression",compact('user'));
        $html = $view->render();
        PDF::writeHTML($html);
        PDF::Output("$title.pdf",'I');
    }

    public function allStatistics(){
        $departments = Department::select('id','ar_name')->get();
        $query = Instructor::select('instructors.id','instructors.department_id','users.gender','departments.ar_name')
            ->join('users','users.id','=','instructors.id')
            ->join('departments','departments.id','=','instructors.department_id')
            ->get();

        $result = [];

        $data = [];
        foreach ($departments as $department){
            $data[] = Instructor::select('departments.ar_name as department_name',
                //professors
                \DB::raw('COUNT(case when male.gender="Male" and instructors.degree = "professor" then 1 end) as male_professors'),
                \DB::raw('COUNT(case when female.gender="Female" and instructors.degree = "professor" then 1 end) as female_professors'),
                //professors assistants
                \DB::raw('COUNT(case when male.gender="Male" and instructors.degree = "assistant_professor" then 1 end) as male_assistant_professors'),
                \DB::raw('COUNT(case when female.gender="Female" and instructors.degree = "assistant_professor" then 1 end) as female_assistant_professors'),
                //teachers
                \DB::raw('COUNT(case when male.gender="Male" and instructors.degree = "teacher" then 1 end) as male_teachers'),
                \DB::raw('COUNT(case when female.gender="Female" and instructors.degree = "teacher" then 1 end) as female_teachers'),
                //teachers assistants
                \DB::raw('COUNT(case when male.gender="Male" and instructors.degree = "teacher_assistant" then 1 end) as male_teacher_assistants'),
                \DB::raw('COUNT(case when female.gender="Female" and instructors.degree = "teacher_assistant" then 1 end) as female_teacher_assistants'),
                //demonstrators
                \DB::raw('COUNT(case when male.gender="Male" and instructors.degree = "demonstrator" then 1 end) as male_demonstrators'),
                \DB::raw('COUNT(case when female.gender="Female" and instructors.degree = "demonstrator" then 1 end) as female_demonstrator'),
                //total
                \DB::raw('COUNT(case when male.gender="Male" and instructors.degree != "emeritus_professor" then 1 end) as male'),
                \DB::raw('COUNT(case when female.gender="Female" and instructors.degree != "emeritus_professor" then 1 end) as female'),
                \DB::raw('(COUNT(case when male.gender="Male" and instructors.degree != "emeritus_professor" then 1 end) + COUNT(case when female.gender="Female" and instructors.degree != "emeritus_professor" then 1 end)) as total')
            )
                ->join('users','users.id','=','instructors.id')
                ->join('users as male','male.id','=','instructors.id')
                ->join('users as female','female.id','=','instructors.id')
                ->join('departments','departments.id','=','instructors.department_id')
                ->where('instructors.department_id','=',$department->id)
                ->get();
        }

        return Excel::create('Staff Statistics', function($excel) use($data,$departments){
            $excel->sheet('Staff Statistics', function($sheet) use($data,$departments)
            {
                $sheet->mergeCells('A1:A2');
                $sheet->mergeCells('B1:C1');
                $sheet->mergeCells('D1:E1');
                $sheet->mergeCells('F1:G1');
                $sheet->mergeCells('H1:I1');
                $sheet->mergeCells('J1:K1');
                $sheet->mergeCells('L1:N1');

                $sheet->setCellValue('A1', 'الأقسام/الدرجة العلمية');

                $sheet->setCellValue('B1', 'أستاذ');
                $sheet->setCellValue('B2', 'ذكور');
                $sheet->setCellValue('C2', 'إناث');

                $sheet->setCellValue('D1', 'أستاذ مساعد');
                $sheet->setCellValue('D2', 'ذكور');
                $sheet->setCellValue('E2', 'إناث');

                $sheet->setCellValue('F1', 'مدرس');
                $sheet->setCellValue('F2', 'ذكور');
                $sheet->setCellValue('G2', 'إناث');

                $sheet->setCellValue('H1', 'مدرس مساعد');
                $sheet->setCellValue('H2', 'ذكور');
                $sheet->setCellValue('I2', 'إناث');

                $sheet->setCellValue('J1', 'معيد');
                $sheet->setCellValue('J2', 'ذكور');
                $sheet->setCellValue('K2', 'إناث');

                $sheet->setCellValue('L1', 'الإجمالي');
                $sheet->setCellValue('L2', 'ذكور');
                $sheet->setCellValue('M2', 'إناث');
                $sheet->setCellValue('N2', 'الإجمالي');
                $sheet->setRightToLeft(true);

                $i = 3;
                foreach ($data as $item){
                    $char = 'A';
                    foreach ($item as $array){
                        foreach ($array->toArray() as $key => $value){
                            $sheet->cell($char.$i, function($cell)use($value) {$cell->setValue($value); });
                            $char++;
                        }
                    }
                    $i++;
                }
                $totalChar = 'B';
                $i--;
                $sheet->setCellValue('A'.(count($departments)+3),"الإجمالي");
                for ($j=0;$j<13;$j++){
                    $sheet->setCellValue($totalChar.(count($departments)+3),"=SUM($totalChar"."3:$totalChar$i)");
                    $totalChar++;
                }
            });
        })->download();
    }

    public function vacationsStatistics(){
        $departments = Department::select('id','ar_name')->get();
        $query = Instructor::select('instructors.id','instructors.department_id','users.gender','departments.ar_name')
            ->join('users','users.id','=','instructors.id')
            ->join('departments','departments.id','=','instructors.department_id')
            ->get();

        $result = [];

        $data = [];
        foreach ($departments as $department){
            $data[] = Instructor::select('departments.ar_name as department_name',
                //emeritus professors
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "emeritus_professor" then 1 end) as ep_total'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and users_status_types.id = 4 and instructors.degree = "emeritus_professor" then 1 end) as ep_ِaccompanying'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "emeritus_professor" and (users_status_types.id = 2 or users_status_types.id = 3) then 1 end) as ep_ِSecondment'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "emeritus_professor" and users_status_types.id = 10 then 1 end) as ep_scientific_mission'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "emeritus_professor" and users_status_types.id = 8 then 1 end) as ep_study_vacation'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "emeritus_professor" and users_status_types.id = 13 then 1 end) as ep_resigned'),
                //professors
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "professor" then 1 end) as p_total'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "professor" and users_status_types.id = 4 then 1 end) as p_ِaccompanying'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "professor" and (users_status_types.id = 2 or users_status_types.id = 3) then 1 end) as p_ِSecondment'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "professor" and users_status_types.id = 10 then 1 end) as p_scientific_mission'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "professor" and users_status_types.id = 8 then 1 end) as p_study_vacation'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "professor" and users_status_types.id = 13 then 1 end) as p_resigned'),
                //professors assistants
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "assistant_professor" then 1 end) as ap_total'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "assistant_professor" and users_status_types.id = 4 then 1 end) as ap_ِaccompanying'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "assistant_professor" and (users_status_types.id = 2 or users_status_types.id = 3) then 1 end) as ap_ِSecondment'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "assistant_professor" and users_status_types.id = 10 then 1 end) as ap_scientific_mission'),
                \DB::raw('COUNT(case when (users.gender="Male" or users.gender="Female") and instructors.degree = "assistant_professor" and users_status_types.id = 13 then 1 end) as ap_resigned')
            )
                ->join('users','users.id','=','instructors.id')
                ->leftjoin('users_status_types', 'users_status_types.id', '=', 'users.status_id')
                ->join('departments','departments.id','=','instructors.department_id')
                ->where('instructors.department_id','=',$department->id)
                ->get();
        }

        return Excel::create('Vacations Statistics', function($excel) use($data,$departments){
            $excel->sheet('Vacations Statistics', function($sheet) use($data,$departments)
            {
                $sheet->mergeCells('A1:A2');
                $sheet->mergeCells('B1:G1');
                $sheet->mergeCells('H1:M1');
                $sheet->mergeCells('N1:R1');

                $sheet->setCellValue('A1', 'الأقسام/الدرجة العلمية');

                $sheet->setCellValue('B1', 'أستاذ متفرغ');
                $sheet->setCellValue('B2', 'العدد الفعلي');
                $sheet->setCellValue('C2', 'اجازات مرافق');
                $sheet->setCellValue('D2', 'اعارات انتدابات كلية');
                $sheet->setCellValue('E2', 'مهمات');
                $sheet->setCellValue('F2', 'إستشاريين منتدبين');
                $sheet->setCellValue('G2', 'استقالات');

                $sheet->setCellValue('H1', 'أستاذ');
                $sheet->setCellValue('H2', 'العدد الفعلي');
                $sheet->setCellValue('I2', 'اجازات مرافق');
                $sheet->setCellValue('J2', 'اعارات انتدابات كلية');
                $sheet->setCellValue('K2', 'مهمات');
                $sheet->setCellValue('L2', 'إستشاريين منتدبين');
                $sheet->setCellValue('M2', 'استقالات');

                $sheet->setCellValue('N1', 'أستاذ متفرغ');
                $sheet->setCellValue('N2', 'العدد الفعلي');
                $sheet->setCellValue('O2', 'اجازات مرافق');
                $sheet->setCellValue('P2', 'اعارات انتدابات كلية');
                $sheet->setCellValue('Q2', 'مهمات');
                $sheet->setCellValue('R2', 'استقالات');

                $sheet->setRightToLeft(true);

                $i = 3;
                foreach ($data as $item){
                    $char = 'A';
                    foreach ($item as $array){
                        foreach ($array->toArray() as $key => $value){
                            $sheet->cell($char.$i, function($cell)use($value) {$cell->setValue($value); });
                            $char++;
                        }
                    }
                    $i++;
                }
                $totalChar = 'B';
                $i--;
                $sheet->setCellValue('A'.(count($departments)+3),"الإجمالي");
                for ($j=0;$j<17;$j++){
                    $sheet->setCellValue($totalChar.(count($departments)+3),"=SUM($totalChar"."3:$totalChar$i)");
                    $totalChar++;
                }
            });
        })->download();
    }

    public function staffIndex(Request $request) {

        $path = [];
        $emptyInstructors = '';
        $website = new Website(Archive::locate('home'));
        $instructors = User::where('type', User::TYPE_INSTRUCTOR)->join('instructors', 'instructors.id', '=', 'users.id')->paginate(9);
        return view('website.staff.profiles', compact('path','website','instructors'));
    }


    public function staffShow($instructor) {

        $path = [
            (object)[
                'link' => route('staff'),
                'title' => __('tr.Staff'),
            ],
        ];

        $checkByCast = (int)$instructor;
        $website = new Website(Archive::locate('home'));
        if($checkByCast == 0){
            $instructor = Instructor::where('short_name',$instructor)->first();
            $user = User::findOrfail($instructor->id);
            return view('website.staff.show', compact('path','website','instructor','user'));
        }else{
            $user = User::findOrfail($instructor);
            $instructor = Instructor::findOrfail($instructor);
            return view('website.staff.show', compact('path','website','instructor','user'));
        }
    }

    public function staffSearch(Request $request) {

        $website = new Website(Archive::locate('home'));
        
        
        
        if($request->ajax())
         {
          $sort_by = $request->get('sortby');
          $sort_type = $request->get('sorttype');
          $query = $request->get('query');
          $textSearch = mb_ereg_replace(" ", "%", getFTS($query));
          $instructors = User::where('type', User::TYPE_INSTRUCTOR)->where("users.search_text",'LIKE',"%$textSearch%")->join('instructors', 'instructors.id', '=', 'users.id')->paginate(9);
          
          return view('website.staff.presult', compact('instructors'))->render();
         }
    }
}