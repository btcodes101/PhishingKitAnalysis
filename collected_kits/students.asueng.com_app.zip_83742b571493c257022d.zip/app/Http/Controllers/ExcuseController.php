<?php

namespace App\Http\Controllers;

use App\Excuse;
use App\ExcuseType;
use App\ExcuseCourse;
use App\ExcuseMessage;
use App\Term;
use App\Study;
use App\Archive;
use App\UserRequest;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Pagination\Paginator;

use Exception;
use Auth;
use DB;
use Validator;
 


class ExcuseController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkStdPaymentStatus');

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(!auth()->user()->hasPermissionTo('submit_excuses'))
            abort(401);

        $path = [];

        $lang = lang();

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];

            $type = $columns[0]["search"]["value"];
            $status = $columns[1]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = Excuse::select('excuses.*', 'excuse_types.'.$lang.'_name as excuse_type_name')
                            ->leftjoin('excuse_types', 'excuse_types.id', 'excuses.excuse_type_id')
                            ->leftjoin('users', 'users.id', 'excuses.student_id')
                            ->whereRaw("(excuses.payment_status = 'FREE' OR excuses.payment_status = 'PAID')")
                            ->where('excuses.student_id', auth()->user()->id);


            if ($type){
                $query->where('excuses.excuse_type_id', $type);
            }

            if ($status){
                $query->where('excuses.status', $status);
            } 
            
            $rows = $query->orderBy($orderBy, $orderDir)->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $excuseStatus = Excuse::statusLabels();
        $excuseTypes = ExcuseType::pluck($lang."_name as name", "id")->toArray();
       

 
        return view('excuses.index', compact('path', 'excuseStatus', 'excuseTypes'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(auth()->user()->student->isPostgraduate())
            abort(401);

        if(!auth()->user()->hasPermissionTo('submit_excuses'))
            abort(401);

        $path = [
            (object) [
                'link' => route('excuses'),
                'title' => 'Excuses',
            ]
        ];

        $current_term = Term::currentTerm();
        if(!$current_term)
            abort(404);
        
      
        //get all the courses of the student in this term
        $courses = Study::leftJoin('courses', 'courses.id', '=', 'studies.course_id')
                            ->where('studies.user_id', Auth::id())
                            ->where('studies.term_id', $current_term->id)
                            ->pluck(lang()."_name as name", 'courses.id')
                            ->toArray();
        
        //get all the upcoming terms
        $terms = Term::whereIn('term_type', [Term::FALL, Term::SPRING, Term::SUMMER])
                        ->limit(10)
                        ->orderBy('id', 'DESC')
                        ->pluck(lang()."_name as name", 'id')
                        ->toArray();
        
        //get all the upcoming years
        $years = Term::where('start_date', '>=', $current_term->start_date )
                        ->whereIn('term_type', [Term::FALL, Term::SPRING, Term::SUMMER])
                        ->groupBy('years')
                        ->pluck("years", 'id')
                        ->toArray();

        $excuse_types = ExcuseType::pluck(lang()."_name as name", 'id')->toArray();

        return view('excuses.add', compact('path', 'excuse_types', 'courses', 'terms', 'years'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(auth()->user()->student->isPostgraduate())
            abort(401);

        if(!auth()->user()->hasPermissionTo('submit_excuses'))
            abort(401);

        $request->validate([
            'excuse_type_id'=>'required|numeric',
            'reasons'=>'required|string|min:10',
            'attachments.*' => 'required|mimes:jpeg,png,jpg,pdf,doc,docx|max:2048'
        ]);

        $excuse_type_id = $request->excuse_type_id;
       
        $excuseType = ExcuseType::findOrFail($excuse_type_id);

        $excuse_type_id = $request->excuse_type_id;
        $courses_ids = null;

        if($excuse_type_id == 1){  //Study period

            $request->validate([
                'period_from'=>'required|date',
                'period_to'=>'required|date|after:period_from',
                'term_id'=>'required|numeric',
            ]);

        }elseif($excuse_type_id == 2 || $excuse_type_id == 3 || $excuse_type_id == 4 || $excuse_type_id == 7 || $excuse_type_id == 8){ //Mid-term exam, Lab exam, Final exam (course/s), course/s, Corona Case

            $request->validate([
                'courses_ids'=>'required',
                'term_id'=>'required|numeric',
            ]);

                      
        }elseif($excuse_type_id == 5 || $excuse_type_id == 6){ //One semester, One academic year

            $request->validate(['term_id'=>'required|numeric']);

        }else{
            abort(404);
        }
 
        $excuse = new Excuse();
        $excuse->fill($request->all());
        $excuse->student_id = auth()->id();
        $excuse->status = -1;
        $excuse->save();


        if($request->has('courses_ids')){

            $courses_ids = $request->courses_ids;

            foreach($courses_ids as $course_id){
                $excuse_course = new ExcuseCourse();
                $excuse_course->excuse_id = $excuse->id;
                $excuse_course->course_id = $course_id;
                $excuse_course->save();
            }
        }


        $files = $request->file('attachments');
    
        $filesInfos = [];
        
        if(!empty($files))
        {
            $archive = Archive::get('excuses/excuse_'.$excuse->id);
            $excuse->archive_id = $archive->id;
            $excuse->save();
            
            foreach ( $files as $file )
            {
                $file  = $archive->addFile($file);
                
                $filesInfos[] = (object) [
                    'id' => $file->id,
                    'name' => $file->name(),
                    'url' => route('download_file', ['archive_id'=>$file->id]),
                ];
            }
        }

        if($excuseType->cost == 0){

            $excuse->payment_status = 'Free';
            $excuse->save();

            return redirect(route('show_excuse', ['id'=>$excuse->id]));

        }else{

            $excuse->payment_status = 'INCOMPLETE';
            $excuse->save();

            $student = Auth::user()->student;

            $total_amount = $excuseType->cost;

            $userRequest = new UserRequest();
            $userRequest->user_id = $student->id;
            $userRequest->type = "Student_Excuse";
            $userRequest->target_id = $excuse->id;
            $userRequest->save();
            $userRequest->refresh();

            //generate the merchantRefNo
            $merchantRefNo = $userRequest->id.'_'.time(). '@stdexus';

            //for bank misr pay with Credit Card transactions only
            $session_id =  $this->createCheckoutSession($merchantRefNo, $userRequest);
            $userRequest->session_id = $session_id;

             //for bank misr pay with Meeza Card transactions only
            $meeza_msg_signature =  $this->createMsgSignature( $total_amount, $userRequest->created_at);
            $userRequest->meeza_msg_signature = $meeza_msg_signature;

            $userRequest->data = '';
            $userRequest->total_amount = $total_amount; //$student_payments->total_amount;
            $userRequest->merchant_reference_no = $merchantRefNo;
            $userRequest->payment_provider = '';
            $userRequest->order_status = 'INCOMPLETE';
            $userRequest->save();
    
            $userRequest->refresh();

            if(empty($userRequest->archive_id)) {
                $archive = Archive::get("users_requests/$userRequest->id");
                $userRequest->archive_id = $archive->id;
                $userRequest->save();
                $userRequest->refresh();
            }

            $excuse->merchantRefNo = $merchantRefNo;
            $excuse->save();

            return redirect()->route('confirmation_excuses_fees_payment', ['id' => $userRequest->id]);
            
        }
       
        
    }

    public function paymentConfirmation($id){ 

        $student = Auth::user()->student;

        $userRequest = UserRequest::where('user_id', $student->id)->findOrFail($id);
  
        $student_excuse = Excuse::where('student_id', $student->id)
                                    ->where('merchantRefNo', $userRequest->merchant_reference_no)
                                    ->first();

        if(!$student_excuse)                                            
            abort(404);


        $path = [];
        $path[] = (object) ['link' => route('my_services'), 'title' => __('tr.Excuses')];
 
        return view('excuses/payments_confirm', compact('path', 'userRequest'));
    }
 
   

    /**
     * Display the specified resource.
     *
     * @param  \App\Excuse  $excuse
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if(!auth()->user()->hasPermissionTo('submit_excuses'))
            abort(401);

      

        $path[] = (object) [
            'link' => route('excuses'),
            'title' => 'Excuses'
        ];
    

        $excuse = Excuse::with('excuseType')->with('excuseCourses')->with('excuseMessages')->with('term')->findOrFail($id);
          
        if(!$excuse->MyExcuse())
            abort(401);
 
        return view('excuses.show', compact('path', 'excuse'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Excuse  $excuse
     * @return \Illuminate\Http\Response
     */
    public function edit(Excuse $excuse)
    {
        if(!auth()->user()->hasPermissionTo('edit_excuses'))
            abort(401);

        if(!$excuse->MyExcuse())
            abort(401);

        abort(404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Excuse  $excuse
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Excuse $excuse)
    {
        if(!auth()->user()->hasPermissionTo('edit_excuses'))
            abort(401);

        if(!$excuse->MyExcuse())
            abort(401);
            
        abort(404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Excuse  $excuse
     * @return \Illuminate\Http\Response
     */
    public function destroy(Excuse $excuse)
    {
        if(!auth()->user()->hasPermissionTo('delete_excuses'))
            abort(401);

        if(!$excuse->MyExcuse())
            abort(401);
            
        abort(404);
    }

    /**
     *add comment by ajax
     * @param Excuse $excuse
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function comment(Excuse $excuse, Request $request) {
        
        if(!auth()->user()->hasPermissionTo('submit_excuses'))
            abort(401);

        if(!$excuse->canDiscuss())
            abort(401);

        if(!$excuse->MyExcuse())
            abort(401);
            
        $validator = Validator::make($request->all(), [
            'comment' => 'required'
        ]);


        if ($validator->fails()) {
            return response()->json(['Errors' => $validator->errors()->all()], 401);
        }

        $excuseMessage = new ExcuseMessage();
        $excuseMessage->excuse_id = $excuse->id;
        $excuseMessage->comment = strip_tags($request->comment_line);
        $excuseMessage->user_id = auth()->user()->id;
        $excuseMessage->save();
        
        $results = [
            'id' =>  $excuseMessage->id,
            'comment' =>  $excuseMessage->comment,
            'user_id' =>  $excuseMessage->user_id,
            'user_name' =>  $excuseMessage->user->lang('name'),
            'created_from' =>  createdFrom($excuseMessage->created_at),
        ];
        
      
        
        return response()->json($results);
    }


    /**
     * 
     */
    public function add_files(Excuse $excuse, Request $request)
    {
        if(!auth()->user()->hasPermissionTo('submit_excuses'))
            abort(401);

        if(!$excuse->canDiscuss())
            abort(401);

        if(!$excuse->MyExcuse())
            abort(401);

        $request->validate([
            'attachments.*' => 'required|mimes:jpeg,png,jpg,pdf,doc,docx|max:2048'
        ]);   

        $files = $request->file('attachments');
    
        $filesInfos = [];
        
        if(!empty($files))
        {
            $archive = Archive::get('excuses/excuse_'.$excuse->id);
            $excuse->archive_id = $archive->id;
            $excuse->save();
            
            foreach ( $files as $file )
            {
                $file  = $archive->addFile($file);
                
                $filesInfos[] = (object) [
                    'id' => $file->id,
                    'name' => $file->name(),
                    'url' => route('download_file', ['archive_id'=>$file->id]),
                ];
            }
        }

        return redirect(route('show_excuse', ['id'=>$excuse->id]));
    }


    public function cancel_excuse(Excuse $excuse, Request $request)
    {
        
        if(!auth()->user()->hasPermissionTo('submit_excuses'))
            abort(401);

        if(!$excuse->canDiscuss())
            abort(401);

        if(!$excuse->MyExcuse())
            abort(401);

        $request->validate([
            'action_comment' => 'required|string|min:10'
        ]);   


        $excuseType = ExcuseType::findOrFail($excuse->excuse_type_id);


        $excuse->status = Excuse::STATUS_CANCELED;
        $excuse->save();

        $excuse->logExcuseAction(Excuse::statusLabels()[Excuse::STATUS_CANCELED], $request->action_comment);

        if($excuseType->cost > 0){ //cashback
            
            // Refund here
        }

        return redirect(route('show_excuse', ['id'=>$excuse->id]));
    }


    public function getTermCourses(Request $request){
        
        if(!auth()->user()->hasPermissionTo('submit_excuses'))
            abort(401);


        //get all the courses of the student in this term
        $courses = Study::leftJoin('courses', 'courses.id', '=', 'studies.course_id')
                        ->where('studies.user_id', Auth::id())
                        ->where('studies.term_id', $request->term_id)
                        ->pluck(lang()."_name as name", 'courses.id')
                        ->toArray();


        return response()->json($courses);
    }
}
