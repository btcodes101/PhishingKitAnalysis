<?php

namespace App\Http\Controllers;

use App;
use App\Archive;
use App\File;
use App\Log;
use App\Mail\SystemMail;
use App\User;
use App\Student;
use App\Instructor;
use App\Department;
use App\Study;
use App\InstructorDegree;
use Auth;
use DB;
use Illuminate\Queue\Jobs\Job;
use Redirect;
use Illuminate\Support\Facades\Mail;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use App\TicketType;
use App\Ticket;
use App\Setting;
use App\TicketMessage;
use Session;

class UsersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        \Artisan::call('cache:clear');

        $this->middleware('auth')->except('image','externalPasswordReset' ,'requestLogin' ,'requestLoginPost','issueTicket','signInTicketsShow','signInTicketsComment');
    }

    /**
     * Show employees list.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        /*foreach (User::all() as $user) {
            $user->updateFTS();
        }
        dd("done");*/

        if(!auth()->user()->hasPermissionTo('access_users'))
            abort(401);

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];
            $textSearch = $request->search['value'];
            $userType = $columns[0]["search"]["value"];
            $userStatus = $columns[1]["search"]["value"];
            $permission = $columns[2]["search"]["value"];
            $role = $columns[3]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = \DB::table('users')->select('users.id',
                'users.code',
                'users.en_name as name',
                'users.email',
                'users.mobile')
                ->leftjoin('model_has_permissions','model_has_permissions.model_id','=','users.id')
                ->leftjoin('model_has_roles','model_has_roles.model_id','=','users.id')
                ->leftjoin('permissions','permissions.id','=','model_has_permissions.permission_id')
                ->leftjoin('roles','roles.id','=','model_has_roles.role_id')
                ->groupBy('users.id')
                ->orderBy($orderBy, $orderDir);

            if ($textSearch) {
                $textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                $query->Where(\DB::raw("COALESCE(users.search_text,'')") , "like", "%$textSearch%");
            }

            if($userType) {
                $query->where('users.type', $userType);
            }

            if ($userStatus != ''){
                $query->where('users.active', $userStatus);
            }

            if ($permission){
                $query->where('permissions.id', $permission);
            }

            if ($role){
                $query->where('roles.id', $role);
            }

            \Log::info('Result:', [$query->toSql()]);

            $rows = $query->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $path = [];

        $permissions = Permission::select('id', 'name')->orderBy('name')->pluck('name', 'id')->toArray();

        $permissionsGroups = [];
        foreach ($permissions as $id => $name) {
            $friendly_name = ucwords(str_replace('_', ' ', $name));
            $sections = explode(' ', $friendly_name);
            $group_name = end($sections);
            $permissionsGroups[$group_name][$id] = $friendly_name;
        }

        $roles = Role::select('id', 'name')->orderBy('name')->pluck('name', 'id')->toArray();
        $status = [
            1 => __('tr.Active'),
            0 => __('tr.Inactive'),
        ];

        return view('users.index',compact('path','status','permissionsGroups','roles'));
    }


    public function show(User $user) {

        if(!auth()->user()->hasPermissionTo('show_users')){
            if($user->type==1) {
                return redirect(route('show_instructor', ['id'=>$user->id]));
            } else if($user->type==2) {
                return redirect(route('show_employee', ['id'=>$user->id]));
            } else if($user->type==3) {
                return redirect(route('show_student', ['id'=>$user->id]));
            } else if($user->type==4) {

            } else {
                abort(401);
            }
        }

        $path = [
            (object)[
                'link' => route("users"),
                'title' => __('tr.Users'),
            ],
        ];

        $roles = Role::all();

        return view('users.show',compact('path', 'user', 'roles'));
    }

    public function profile(User $user) {

        if($user->type==3) {
            return redirect(route('show_student', ['id'=>$user->id]));
        }
        
        abort(401);
    }

    /**
     * Edit the user.
     *
     * @param $from
     * @param User $user
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function edit($from , User $user, Request $request)
    {
        if(!auth()->user()->hasPermissionTo('edit_users'))
            abort(401);

        $single = rtrim($from, "s");
        $title = ucwords($from);

        $path = [
            (object)[
                'link' => route($from),
                'title' => __('tr.'.$title),
            ]
        ];

        if(empty($user->id))
        {
            $user->id = 0;
            $user->type = User::getType($from);
        }
        else
        {
            $path[]  =  (object)[
                'link' => route('show_'.$single, [$single.'_id'=>$user->id]),
                'title' => $user->lang('name')
            ];
        }

        $action = '';
        if($user->id==0)
            $action = 'add';
        else
            $action = 'edit';

        $degrees = InstructorDegree::select('code as id', lang().'_name as name')->pluck('name', 'id')->toArray();

        $departments = Department::select('id', lang().'_name as name')->where('active', '=', 1)->where('parent_id','!=',0)->orderBy('id', 'desc')->pluck('name', 'id')->toArray();

        return view('users.edit', compact('path', 'user', 'from', 'degrees', 'departments'));
    }

    /**
     * Save the user.
     *
     * @param $from
     * @param User $user
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function save($from, User $user, Request $request)
    {
        if(!auth()->user()->hasPermissionTo('edit_users'))
            abort(401);

        $single = rtrim($from, "s");

        $action = '';
        if($user->id==0) $action = 'add';
        else $action = 'edit';

        if($user->instructor && !auth()->user()->hasPermissionTo($action.'_instructors')) {
            abort(401);
        } else if($user->student && !auth()->user()->hasPermissionTo($action.'_students')) {
            abort(401);
        } else if($user->employee && !auth()->user()->hasPermissionTo($action.'_employees')) {
            abort(401);
        }

        $this->validate($request, [
            'code' => 'alpha_num',
            'en_name' => 'required|max:255|min:7',
            'email' => 'required|email|unique:users,email,'.$user->id,
            'national_id' => 'required|alpha_num',
        ]);

        if(User::where('id', '!=', $user->id)->where('type', '=', $request->type)->where('national_id', '=', $request->national_id)->count()>0) {
            $this->validate($request, [
                    'national_id' => 'required|unique:users,national_id,'.$user->id,
                ]);
        }

        $user->fill($request->all()); 
        $user->active = 1;
        if($action=="add") $user->code = User::genCode($user->type);
        $user->save();
        $user->updateFTS();

        $instructor = null;
        if($action=="add") {
            if($request->type==User::TYPE_INSTRUCTOR) { //instructor
                $instructor = new Instructor();
                $instructor->id = $user->id;
                $instructor->department_id = $request->department_id;
                $instructor->degree = $request->degree;
                $instructor->seniority = Instructor::where('degree', $request->degree)->max('seniority');
                $instructor->save();
                $user->assignRole('Instructor');
                Instructor::normalizeSeniority($instructor);
            } else if($request->type==User::TYPE_EMPLOYEE) { //employee
                $user->assignRole('Employee');
            } else if($request->type==User::TYPE_STUDENT) { //student
                $student = new Student();
                $student->id = $user->id;
                $student->save();
            }
        } else {
            if($request->type==User::TYPE_INSTRUCTOR) { //instructor
                $instructor = $user->instructor;
                $instructor->department_id = $request->department_id;
                $instructor->degree = $request->degree;
                $instructor->save();
            }
        }

        //Response of ajax request from pop-up dialog upon creating user
        if ($request->ajax()){
            return response()->json();
        }

        return redirect(route('show_'.$single, [$single.'_id'=>$user->id]));
    }

    public function editPassword(User $user)
    {
        if(!auth()->user()->hasPermissionTo('admin_system') && auth()->id()!=$user->id)
            abort(401);

        if(!$user->isExternalInstructor())
            abort(401);

        $path = [
            (object)[
                'link' => route('users'),
                'title' => __('tr.Users'),
            ],
            (object)[
                'link' => route('show_user', ['user_id'=>$user->id]),
                'title' => $user->lang('name'),
            ],
        ];

        return view('users.edit_pwd', compact('path', 'user'));
    }

    public function savePassword(User $user, Request $request)
    {
        if(!auth()->user()->hasPermissionTo('admin_system') && auth()->id()!=$user->id)
            abort(401);

        if(!$user->isExternalInstructor())
            abort(401);

        $rules = [];
        if(!$user->isEmptyPassword() && !auth()->user()->hasPermissionTo('admin_system')) {
            $rules['old_password'] = 'required';
            $rules['password'] = 'required|min:8|confirmed|different:old_password';
        } else {
            $rules['password'] = 'required|min:8';
        }
        $rules['password_confirmation'] = 'required|min:8';

        $this->validate($request, $rules);

        if ($user->isEmptyPassword() || auth()->user()->hasPermissionTo('admin_system') ||
            Hash::check($request->old_password, $user->password)) {
            $user->password = Hash::make($request->password);
            $user->save();

            $request->session()->flash('success', 'Password changed');
        } else {
            return Redirect::back()->withErrors('Wrong old password.');
        }

        return redirect(route('show_user', ['user_id'=>$user->id]));
    }

    public function resetPassword(User $user, Request $request) {

        if(!auth()->user()->hasPermissionTo('admin_system'))
            abort(401);

        $tempPassword = mt_rand(100000, 999999);
        $user->password = Hash::make($tempPassword);
        $user->save();

        $email = $user->email;
        $systemMail = new SystemMail("password_reset", ['values'=>['USER_NAME'=>$user->en_name, 'TEMP_PASSWORD'=>$tempPassword]]);
        Mail::to($email)->cc('asueng@eng.asu.edu.eg')->send($systemMail);

        return response()->json();
    }

    public function save_instractor($from, User $user, Request $request)
    {
        if(!auth()->user()->hasPermissionTo('edit_users'))
            abort(401);

        $single = rtrim($from, "s");

        $action = 'edit';
        if($user->id==0)
            $action = 'add';
        else
            $action = 'edit';

        if($user->instructor && !auth()->user()->hasPermissionTo($action.'_instructors')) {
            abort(401);
        }

        $instructor =Instructor::find($user->id);
        foreach ($request->instract as $key => $value) {
            $instructor->$key = $value;
        }
        $instructor->save();

        return redirect(route('show_'.$single, [$single.'_id'=>$user->id]));
    }

    /**
     * Soft Delete the course.
     *
     * @param Course $course
     * @return \Illuminate\Http\Response
     */
    public function delete(User $user)
    {
        if(!auth()->user()->hasPermissionTo('delete_users'))
            abort(401);

        $user->active = 0;
        $user->save();
        die("done");
    }

    /**
     * Resolve users for given query
     *
     * @return void
     */
    public function resolve(Request $request)
    {
        if(!auth()->user()->hasPermissionTo('access_instructors')) {
            return response('Unauthenticated', 401);
        } else if(!auth()->user()->hasPermissionTo('access_students')) {
            return response('Unauthenticated', 401);
        } else if(!auth()->user()->hasPermissionTo('access_employees')) {
            return response('Unauthenticated', 401);
        }

        $users_codes = $request['users_codes'];
        $users_codes = preg_replace("/[\n\r]/",",",$users_codes);
        $users_codes = str_replace(' ', ',', $users_codes);
        $users_codes = explode(',', $users_codes);

        $query = User::select('users.id', 'users.code', 'users.en_name')
            ->whereIn("users.code", $users_codes)
            ->orderBy('users.code');

        $users = $query->get();

        //\Log::info('Request:', $query->toSql()]);

        $results = [];
        foreach ($users as $user) {
            $results[]= [
                'id' =>  $user->id,
                'name' =>  $user->code.":".$user->en_name,
            ];
        }

        return response()->json($results);
    }

    /**
     * Get users for given query
     *
     * @return void
     */
    public function names(Request $request) {
        
        if(!auth()->user()->hasPermissionTo('access_users'))
            return response('Unauthenticated', 401);

        $studyRole = null;
        if(isset($request->study_role))
            $studyRole = $request->study_role;

        $types = [];
        if($studyRole==Study::ROLE_STUDENT) {
            $types[] = Study::TYPE_STUDENT;
        }

        if($studyRole==Study::ROLE_TEACHER||$studyRole==Study::ROLE_EXAMINAR_COMMITTEE||$studyRole==Study::ROLE_TEACHING_ASSISTANT) {
            $types[] = User::TYPE_INSTRUCTOR;
            $types[] = User::TYPE_EXTERNAL_INSTRUCTOR;
        }

        if(isset($request->types)) {
            $types = explode(',', $request->types);
        }

        $orgKeywords = $request["query"];
        $limit = $request["limit"];
        if(empty($limit) || $limit>10)$limit=10;

        $query = User::select('id', 'type', 'code','en_name' , 'ar_name', 'email', 'search_text');

        if(filter_var($orgKeywords, FILTER_VALIDATE_EMAIL)) {
            $query->where('email' , "like", "%$orgKeywords%");
        } else {
            $keywords = getFTS($orgKeywords);
            $keywords = mb_ereg_replace(" ", "%", $keywords);
            $query->where('search_text' , "like", "%$keywords%");
        }

        $query->where('active', 1)->limit($limit);

        if ($request->get('user_id')){
            $query->where('id', $request->get('user_id'));
        }

        if(count($types)) {
            $query->whereIn('type', $types);
        }

        $users = $query->get();
        $result = [];
        foreach ($users as $user) {
            $code = "";
            if($user->type==1) {
                $instructor = $user->instructor;
                if($instructor) {
                    $department = $instructor->department;
                    if($department) {
                        $code = $department->code;
                    }
                }
            } else if($user->type==2) {
                $code = __("tr.Employee");
            }
            else if($user->type==3) {
                $student = $user->student;
                if($student) {
                    $code = __("tr.Student");
                }
            }
            else if($user->type==4) {
                $code = __("tr.External Instructor");
            }

            $name = $user->lang('name');
            $result[]= [
                'id' =>  $user->id,
                'name' =>  "$name ($code)",
                'search' =>  $orgKeywords.":".$user->search_text,
            ];
        }

        \Log::info('Result:', $result);

        return response()->json($result)->withCallback("callback");
    }

    public function checkEmail($email, $id)
    {
        \Log::info('Request:', ["sss"]);

        if (User::where('id','!=',$id)->where('email', '=', $email)->exists()) die("exists");
        die("none");
    }

    public function checkCode($code, $id)
    {
        if (User::where('id','!=',$id)->where('code', '=', $code)->exists()) die("exists");
        die("none");
    }

    public function checkNationalID($nationalID, $id, $type = null)
    {
        if ($type){
            if (User::where('id','!=',$id)->where('type','=',$type)->where('national_id', '=', $nationalID)->exists()) die("exists");
        } else {
            if (User::where('id','!=',$id)->where('national_id', '=', $nationalID)->exists()) die("exists");
        }
        die("none");
    }

    public function sendEmail(){
        $data['data'] = "Hello From Controller";
        $data['email'] = "alsayed93ahmed@gmail.com";

        for ($i=0;$i<3;$i++){
            Mail::to($data['email'])->queue(new SystemMail("project_status_changed",
                (object)['project'=>"ASUENG", 'message'=>$data['data']]));
        }

        return redirect()->back();
    }

    public function waitingEmails(){
        $jobs = DB::table('jobs')->limit(10)->get();
        foreach ($jobs as $job){
            $start = strpos($job->payload, 's:24')+7;
            $end = strpos($job->payload, '\"',$start);
            $email = substr($job->payload, $start, ($end-$start));
            $job->email = $email;
        }

        if (count($jobs) == 0){
            $jobs = [
                'message' => __('tr.Emails Sent Successfully')
            ];
        } else {
            $jobs = $jobs->toArray();
            $jobs[10] = DB::table('jobs')->count();
        }
        return response()->json($jobs);
    }

    public function image(User $user){
        try{
            $image = $user->archive->findChildByContentType("Personal Photo");
            return response()->download(
                $image->physicalPath(),
                $image->name(),
                array('Content-Type: '.$image->application_type)
            );
        } catch (\Throwable $e) {
            abort(404);
        }
    }

    public function rebuildRoles() {

        if(!auth()->user()->hasPermissionTo('admin_system'))
            return response('Unauthenticated', 401);

        $nChanges = 0;
        foreach (User::all() as $user) {
            switch($user->type) {
                case User::TYPE_INSTRUCTOR:
                    if(!$user->hasRole("Instructor")) {
                        $user->assignRole('Instructor');
                        $nChanges++;
                    }
                break;
                case User::TYPE_EMPLOYEE:
                    if(!$user->hasRole("Employee")) {
                        $user->assignRole('Employee');
                        $nChanges++;
                    }
                break;
                case User::TYPE_STUDENT:
                break;
                case User::TYPE_EXTERNAL_INSTRUCTOR:
                    if(!$user->hasRole("ExternalInstructor")) {
                        $user->assignRole('ExternalInstructor');
                        $nChanges++;
                    }
                break;
                case User::TYPE_OTHER:
                break;
            }
        }

        die("done nChanges = $nChanges");
    }

    public function uploadSignature(User $user, Request $request) {

        if ($request->file('file')) {
            $extension = $request->file->getClientOriginalExtension();
            $allowedfileExtension = ['png', 'jpg', 'jpeg', 'tif', 'gif'];
            if (in_array($extension, $allowedfileExtension)) {
                $file = $user->archive->addFile($request->file, "Signature Image");
                return response()->json();
            } else  {
                return response()->json(['error' => 'Invalid File Format'], 500);
            }
        } else {
            return response()->json(['error' => 'Invalid File Format'], 500);
        }
    }

    public function uploadX509(User $user, Request $request) {

        if ($request->file('file')) {
            $extension = $request->file->getClientOriginalExtension();
            $allowedfileExtension = ['crt', 'cer'];
            if (in_array($extension, $allowedfileExtension)) {

                $file = $user->archive->addFile($request->file, "Digital Signing Certificate");
                $content = \File::get($file->physicalPath());
                try {
                    $x509CertificateIdentifier = openssl_x509_read($content);
                    if ($x509CertificateIdentifier == false)
                        return response()->json(['error' => 'Certificate is not in PEM format or invalid.'], 500);

                    openssl_x509_export($x509CertificateIdentifier, $certificate);

                } catch (\Exception $e) {
                    return response()->json(['error' => 'Certificate is not in PEM format or invalid.'], 500);
                }

                $user->public_certificate = $content;
                if ($user->save()) return response()->json();

            } else {
                return response()->json(['error' => 'Invalid File Format'], 500);
            }
        }
    }

    public function externalPasswordReset() {

        $userID = decryptData(request()->secrete, env("WEBSITE_SHARED_KEY", null));
        $user = User::find($userID);
        if(empty($user))
            abort(401);

        $password = $user->resetPassword();
        if($password===false) {
            die("Server error.");
        }
        
        session()->flash('send_success', __('tr.Email reset link is sent to your personal email successfully.'));

        return redirect('/'.lang().'/login');
    }

    public function requestLogin(){
        return view('auth.request_login',compact('errorCode'));
    }

    public function requestLoginPost(Request $request){

        $email = strip_tags($request->email);
        $code = strip_tags($request->code);
        $national_id = strip_tags($request->national_id);
        $mobile = strip_tags($request->mobile);
        $message = strip_tags($request->message);
        $action = strip_tags($request->action);

        if(explode('@', $request->email)[1] == 'eng.asu.edu.eg'){
            return back()->withInput()->withErrors('Please enter your personal email, not faculty email.');
        }

        $user = User::whereRaw(("(code = '$code' AND email_alt = '$email') OR (national_id = '$national_id' AND email_alt = '$email')"))->first();
        if(empty($user) && $action=="reset") {
            return back()->withInput()->withErrors('Please enter the registered personal email. If you do not provide persoanl email before or you do not know or no longer can access your registered personal email, you will not able to reset your email password. In that case, please send an email to student.affairs@eng.asu.edu.eg containing a scanned copy of your national ID and faculty Identity Card or select "Contact Helpdesk" instead of "Reset Password".');
        }

        /* $user = User::where('email_alt', $email)->where('code', $code)->first();
        if(empty($user) && $action=="reset") {
            return back()->withInput()->withErrors('Please enter the registered personal email. If you do not provide persoanl email before or you do not know or no longer can access your registered personal email, you will not able to reset your email password. In that case, please send an email to student.affairs@eng.asu.edu.eg containing a scanned copy of your national ID and faculty Identity Card or select "Contact Helpdesk" instead of "Reset Password".');
        }*/

        if($user && $user->type!=User::TYPE_STUDENT && $user->id!=380) {
            return back()->withInput()->withErrors('This is not student account. SIS can be accessed by students only.');
        }

        if($action=="reset") {            
            
            $link = route('external_password_reset');
            $resetLink = $link.'?secrete='.encryptData($user->id, env("WEBSITE_SHARED_KEY", null));

            $title = "ASUENG - Password Reset";

            $systemMail = new SystemMail("password_reset_request", ['title'=>$title, 'values' => ['user_name'=>$user->en_name, 'password_reset_link' => $resetLink]]);
            $systemMail->submit($email, false, Setting::value("email"),[],false);

            session()->flash('send_success',__('tr.Email reset link is sent to your personal email successfully.'));

            return redirect('/'.lang().'/login');        
        }        

        $data = [];
        
        $ticket = new Ticket();
        $ticket->ticket_type_id = 13;
        $ticket->user_id = env("GUEST_USER_ID", null);


        $data['email'] = $email;
        $data['code'] = $code;
        $data['national_id'] = $national_id;
        $data['mobile'] = $mobile;
        $data['message'] = $message;

        $studentData = json_encode($data);
       
        $ticket->title = 'SIS Login Issue';
        $ticket->description = $studentData;
        $ticket->status = -1; //incomplete
        $ticket->related_id = null;
        $ticket->save();

        $msg_issue = 'Code: '.$code.'<br>Email: '.$email.'<br>Issue No.: #'.$ticket->id.'<br>Message: '.$message;
        $link = route('show_external_ticket');
        $ticketLink = $link.'?secrete='.encryptData($ticket->id, env("WEBSITE_SHARED_KEY", null));

        $title = "ASUENG - Request Login";            
        $systemMail = new SystemMail("signin_request", ['title'=>$title, 'values' => ['request_data' => $msg_issue,'ticket_link' => $ticketLink]]);
        $systemMail->submit($email, false, Setting::value("email"),[],false);

        session()->flash('send_success',__('tr.Message Sent Successfully'));

        return redirect('/'.lang().'/login');        
    }

    public function signInTicketsShow($id)
    {
        $ticket = Ticket::findOrfail($id);
        $lang = lang();

        $tickesTypes = TicketType::pluck($lang."_name as name", "id")->toArray();

        return view('auth.tickets', compact('ticket'));
    
    }

    public function signInTicketsComment($id, Request $request){

        $ticket = Ticket::findOrfail($id);
        $ticketMessage = new TicketMessage();
        $ticketMessage->ticket_id = $ticket->id;
        $ticketMessage->comment = $request->comment;
        $ticketMessage->user_id = $ticket->user_id;
        $ticketMessage->save();
        
        $files = $request->file('attachments');
        
        $filesInfos = [];
        
        if(!empty($files))
        {
            $archive = Archive::get('tickets/ticket_'.$ticket->id.'/message_'.$ticketMessage->id);
            $ticketMessage->archive_id = $archive->id;
            $ticketMessage->save();
            
            foreach ( $files as $file )
            {
                $file  = $archive->addFile($file);
                
                $filesInfos[] = (object) [
                    'id' => $file->id,
                    'name' => $file->name(),
                    'url' => route('download_file', ['archive_id'=>$file->id]),
                ];
            }
        }

        $ticketMessage->echo();
        
        $results = [
            'id' =>  $ticketMessage->id,
            'comment' =>  $ticketMessage->comment,
            'user_id' =>  $ticketMessage->user_id,
            'user_name' =>  $ticketMessage->user->lang('name'),
            'created_from' =>  $ticketMessage->createdFrom(),
            'files_infos' =>  $filesInfos,
        ];
        
        $ticket->status = 1;
        $ticket->save();
        
        return response()->json($results);
    }
}
