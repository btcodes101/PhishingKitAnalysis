<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Pagination\Paginator;
use Spatie\Permission\Models\Role;
use Symfony\Component\HttpFoundation\Response;

use App\Student;
use App\Term;
use App\ExternalStudentsRequest;



use Auth;
use Hash;
use Validator;
use Exception;
use Log;
use DB;

class StudentsExternalRequestsController extends Controller
{

    public function __construct(){

        $this->middleware('auth');
    }

   /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){

        $student = auth()->user()->student;

        if(!$student->canApplyExternalRegistrationRequest())
            abort(401);

        $path = [];

        $lang = lang();

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;
            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];

            $year = $columns[0]["search"]["value"];
            $status = $columns[1]["search"]["value"];

            \Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });

            $query = ExternalStudentsRequest::where('student_id', $student->id);
            

            if ($status){
                $query->where('status', $status);
            } 

            if ($year){
                $query->where('year', $year);
            } 
            
            $rows = $query->orderBy($orderBy, $orderDir)->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }

        $years = $this->years();
        $status = ExternalStudentsRequest::statusLabels();
        
        return view('students.external_requests.index', compact('path', 'years', 'status'));

    }

    public function storeReRegistrationRequest(Request $request){  

        $student = auth()->user()->student;

        if(!$student->canApplyExternalRegistrationRequest())
            abort(401);

        if($student->forceToChangeBylaw()){
            $conditions = [
                'agreed_to_change_to_2018'=> 'required',
                'year'=> 'required',
            ];
        }else{
            $conditions = [
                'year'=> 'required',
            ];
        }
      
        $request->validate($conditions);
 

        $result = ExternalStudentsRequest::create($request->all());

        if($result){
            return redirect()->back()->with('message',  __('tr.Your request is submitted successfully'));
        }else{
            return back()->withErrors([ 'message' =>  __('tr.General Error')]);
        }
         
    }

    private function years()
    {
        $currentTerm  = Term::currentTerm();

        $years[$currentTerm->years] = $currentTerm->years;
        $years[$currentTerm->nextYears()] = $currentTerm->nextYears();

        return $years;
    }

     
}
