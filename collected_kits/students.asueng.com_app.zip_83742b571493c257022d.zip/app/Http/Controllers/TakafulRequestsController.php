<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\TakafulRequest;
use App\Student;
use App\User;
use App\Term;
use App\UserRequest;
use App\Setting;

use Auth;
use DB;
use Exception;
use Response;
use Validator;
use Log;

use Illuminate\Pagination\Paginator;

class TakafulRequestsController extends Controller
{

    public function __construct(){

        $this->middleware('auth');
    }

    private function getPath() {
        $path = [];
        $path[] = (object) ['link' => route('dashboard'), 'title' => __('tr.Dashboard')];
        $path[] = (object) ['link' => route('takaful'), 'title' => __('tr.Takaful')];
        return $path;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){
      

        $student = auth()->user()->student;
        if(!$student)
            abort(404);

        if(!$student->canApplyTakafulRequest())
            abort(401);

        $lang = lang();

        if($request->ajax())
        {
            $draw = $request->draw;
            $start = $request->start;
            $length = $request->length;
            $columns = $request->columns;

            $order = $request->order[0]['column'];
            $orderBy = $columns[$order]["name"];
            $orderDir = $request->order[0]['dir'];

            $term_id = $columns[0]["search"]["value"];
            $status = $columns[1]["search"]["value"];
          
           

            Log::info('Request:', $request->all());

            Paginator::currentPageResolver(function () use ($start, $length) {
                return ($start / $length + 1);
            });


            $query = TakafulRequest::select("takaful_requests.*", "terms.".$lang."_name as term_name")
                                        ->leftJoin('terms', 'terms.id', '=', 'takaful_requests.term_id')
                                        ->where('student_id', $student->id);

            if ($term_id) {
                $query->where('takaful_requests.term_id', $term_id);
            }

            if ($status) {
                $query->where('takaful_requests.status', $status);
            }
    
             
            
            $rows = $query->paginate($length);

            $result = [
                'draw' => $draw,
                'recordsTotal' => $rows->total(),
                'recordsFiltered' => $rows->total(),
                'data' => $rows
            ];

            return $result;
        }


        $path = [];
         
        $terms = Term::whereIn('term_type', [Term::FALL, Term::SPRING])
                    ->limit(20)
                    ->orderBy('id', 'DESC')
                    ->pluck($lang."_name as name", "id")
                    ->toArray();
         

        return view('takaful.index', compact('path', 'terms'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        abort(404);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){  

        $student = auth()->user()->student;
        if(!$student)
            abort(404);

        if(!$student->canApplyTakafulRequest())
            abort(401);

        $this->validate($request, [
            'term_id' => 'required|numeric',
            'guardian_name' => 'required',
            'guardian_occupation' => 'required',
            'guardian_net_income' => 'required|numeric',
            'guardian_mobile_number' => 'required',
            'mother_occupation' => 'required',
            'mother_net_income' => 'required|numeric',
            'number_of_family_members_living_with_you' => 'required|numeric',
        ]);

        $data = [
            'student_id' => $student->id,
            'term_id' => $request->term_id,
            'guardian_name' =>  $request->guardian_name,
            'guardian_occupation' =>  $request->guardian_occupation,
            'guardian_net_income' =>  $request->guardian_net_income,
            'guardian_mobile_number' =>  $request->guardian_mobile_number,
            'mother_occupation' =>  $request->mother_occupation,
            'mother_net_income' =>  $request->mother_net_income,
            'number_of_family_members_living_with_you' =>  $request->number_of_family_members_living_with_you,
        ];

     
        $requestFees = Setting::value('financial_aid_request_fees');
        if(!$requestFees)
            $requestFees = 10;

        $UserRequest = $this->createUserRequest('financial_aid_request', 'takaful', $requestFees, $data);

        if($UserRequest){
            return redirect()->route('takaful_payment_confirmation', [$UserRequest->id]);
        }else{
            abort(401);
        }

    }

    public function paymentConfirmation(UserRequest $userRequest){ 
       
        $student = Auth::user()->student;
        if(!$student)
            abort(404);


        if($student->id != $userRequest->user_id)
            abort(401);
        
        
        $path = $this->getPath();

        return view('system.components.payment_confirmation', compact('path', 'userRequest'));

    }


    /**
     * Display the specified resource.
     *
     * @param  \App\TakafulRequest  $takafulRequest
     * @return \Illuminate\Http\Response
     */
    public function show(TakafulRequest $takafulRequest)
    {
        abort(404);
    }

   /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TakafulRequest  $takafulRequest
     * @return \Illuminate\Http\Response
     */
    public function edit(TakafulRequest $takafulRequest){

        $student = auth()->user()->student;
        if(!$student)
            abort(404);
    

        if($student->id != $takafulRequest->student_id)
            abort(401);

        if($takafulRequest->status != TakafulRequest::STATUS_IN_PROGRESS)
            abort(401);

        $path = $this->getPath();
        return view('takaful.edit', compact('path', 'takafulRequest'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TakafulRequest  $takafulRequest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TakafulRequest $takafulRequest){

        $student = auth()->user()->student;
        if(!$student)
            abort(404);

        if($student->id != $takafulRequest->student_id)
            abort(401);

        if($takafulRequest->status != TakafulRequest::STATUS_IN_PROGRESS)
            abort(401);

        $this->validate($request, [
            'guardian_name' => 'required',
            'guardian_occupation' => 'required',
            'guardian_net_income' => 'required|numeric',
            'guardian_mobile_number' => 'required',
            'mother_occupation' => 'required',
            'mother_net_income' => 'required|numeric',
            'number_of_family_members_living_with_you' => 'required|numeric',
        ]);

        $takafulRequest->update($request->all());

        return redirect()->route('takaful_edit', [$takafulRequest->id])->with('message', 'Your request is submitted successfully');

    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TakafulRequest  $takafulRequest
     * @return \Illuminate\Http\Response
     */
    public function destroy(TakafulRequest $takafulRequest)
    {
        abort(404);
    }
}
