<?php

namespace App\Http\Controllers;
use PHPMailer\PHPMailer;
use Illuminate\Support\Facades\Hash;
use Crypt;
use App\User;
use App\Log;

class SessionsController extends Controller
{
    public function index()
    {
        return view('auth.login');
    }

    public function login() {

        $response = User::emailServerLogin(request('email'), request('password'));
        if($response->status) {
            Log::log("SIS Login", Auth()->user(), ['status'=>"success"]);
            return redirect()->to('/');
        }
        else if($response->redirect) {
            $user = User::where('email', request()->email)->first();
            if($user) {
                Log::log("SIS Login Redirect", $user, ['redirect'=>$response->redirect]);
            }
            return redirect()->to($response->redirect);
        }
        
        $user = User::where('email', request()->email)->first();
        if($user) {
            Log::log("SIS Login Failed", $user, ['message'=>$response->message]);
        }
        return back()->withErrors(['message' => $response->message]);
    }

    public function logout() {
        
        auth()->logout();
        \Session::flush();

        return redirect('/login');
    }

    public function reset() {

        if (request()->isMethod('post')) {
            $email = request()->email;
            $user = User::where('email', $email)->first();
            $password = request()->password;
            $confirmPassword = request()->confirm_password;
            if(strlen($password)<6)
                return back()->withErrors(['message' => 'Password length must be > 6 letters.']);
            if($password!=$confirmPassword)
                return back()->withErrors(['message' => 'Password and confirm password does not match.']);
            if(empty($email) || empty($user))
                return back()->withErrors(['message' => 'Invalid request.']);

            $user->password = Hash::make($password);
            $user->save();

            session()->flash('send_success', 'Password rest successfully.');
            return redirect()->to(route('login'));
        }

        $email = decryptData(request()->aas, env("WEBSITE_SHARED_KEY", null));
        $user = User::where('email', $email)->first();
        if(empty($email) || empty($user)) return redirect()->to(route('login'));
        
        return view('auth.reset', compact('user'));
    }

    public function request() {

        return view('auth.request');
    }

    public function external() {

        $secrete = request()->secrete;
        $id = decryptData($secrete, env("WEBSITE_SHARED_KEY", null));
        request()->session()->flush();
        auth()->loginUsingId($id, true);
        return redirect()->route('dashboard');
    }
}