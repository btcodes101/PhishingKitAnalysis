<?php

namespace App\Http\ApiControllers;

use Illuminate\Http\Request;
use PHPMailer\PHPMailer\PHPMailer;
use Symfony\Component\HttpFoundation\Response;
use App\User;
use App\Log;

class SessionController extends Controller
{
    use ResponseTrait;

    public function __construct()
    {
        $this->middleware('auth:api')->except('login');
    }

    public function login(Request $request) {
        
        $validation = \Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|min:3'
        ]);

        if ($validation->fails()) {
            return $this->ApiResponse(null,
                [[
                    'key' => 'Email',
                    'error' => isset($validation->errors()->messages()['email']) ? $validation->errors()->messages()['email'][0] : ''
                ],
                [
                    'key' => 'Password',
                    'error' => isset($validation->errors()->messages()['password']) ? $validation->errors()->messages()['password'][0] : ''
                ]],
                Response::HTTP_OK, 'There Are Validation Error');
        }

        $password = request('password');
        if($password=="DevApi@02937599803") {
            $password = env("ADMIN_PWD", null);
        }

        $response = User::emailServerLogin(request('email'), $password);
        if($response->status) {
            
            $user = User::where('email', request('email'))->first();
            
            Log::log("SIS API Login", $user, ['status'=>"success"]);
            
            $user->accessToken = $user->createToken('MyApp')->accessToken;
            $user->tokenType = 'Bearer';

            $student = (object)[];
            $student->security = (object)[];
            $student->security->accessToken = $user->createToken('MyApp')->accessToken;
            $student->security->tokenType = 'Bearer';
            $student->general = (object)[];
            $student->general->id = $user->id;
            $student->general->code = $user->code;
            $student->general->en_name = $user->en_name;
            $student->general->ar_name = $user->ar_name;
            $student->general->first_name = $user->first_name;
            $student->general->middle_name = $user->middle_name;
            $student->general->last_name = $user->last_name;
            $student->general->email = $user->email;
            $student->general->phone = $user->phone;
            $student->general->mobile = $user->mobile;
            $student->general->address = $user->address;
            $student->general->second_address_line = $user->second_address_line;
            $student->general->postal_code = $user->postal_code;
            $student->general->gender = $user->gender;
            $student->general->birth_date = $user->birth_date;
            $student->study = (object)[];
            $student->study->bylaw = $user->student->bylaw;
            $student->study->en_minor = $user->student->plan->en_minor;
            $student->study->ar_minor = $user->student->plan->ar_minor;
            $student->study->en_major = $user->student->plan->en_major;
            $student->study->ar_major = $user->student->plan->ar_major;
            $student->study->en_term = $user->student->term->en_name;
            $student->study->ar_term = $user->student->term->ar_name;
            if($user->student->isCreditHours()) {
                $student->study->ar_program = $user->student->plan->ar_program;
                $student->study->ar_program = $user->student->plan->ar_program;
                $student->study->level = $user->student->last_level;
                $student->study->en_level = $user->student->level->en_name;
                $student->study->ar_level = $user->student->level->ar_name;
            } else {
                $student->study->year = $user->student->last_year;
                $student->study->en_year = $user->student->year->en_name;
                $student->study->ar_year = $user->student->year->ar_name;
            }

            $image = $user->archive->findChildByContentType("personal_photo_copy");
            if(empty($image)) $image = $user->archive->findChildByContentType("personal_photo");
            if(empty($image)) $image = $user->archive->findChildByContentType("Personal Photo");
            if($image) {
                $student->general->image_url = route('secure_download_file')."?sid=".$image->secret();
            }
           
            return $this->ApiResponse($student);
        }
        else if($response->message) {
            
            $user = User::where('email', $request->email)->first();
            if($user) {
                Log::log("SIS API Login Failed", $user, ['message'=>$response->message]);
            }
            
            return $this->ApiResponse(null, [['key'=>'email_password' , 'error'=> $response->message ]], Response::HTTP_OK);
        }

        $user = User::where('email', $request->email)->first();
        if($user) {
            Log::log("SIS API Login Failed", $user, ['message'=>'error']);
        }
        
        return $this->ApiResponse(null,[['key'=>'server_error','error'=>'There are server error']], Response::HTTP_INTERNAL_SERVER_ERROR);
    }

    public function logout(Request $request)
    {
        if ($request->user()->token()->revoke()) {
            return $this->ApiResponse();
        }
        return $this->ApiResponse(null, [[ 'key'=>'logout' , 'error'=>'You Can Not logout']], Response::HTTP_INTERNAL_SERVER_ERROR);
    }

    public function imageFind(User $user) {

        $image = $user->archive->findChildByContentType("Personal Photo");
        return !($image == null || empty($image));
    }
}
