<?php

namespace App\Http\ApiControllers;

use App;
use App\Archive;
use App\File;
use App\Study;
use App\Term;
use App\Committee;
use App\Course;
use App\Exams;
use App\User;
use App\Setting;
use Auth;
use DB;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\Paginator;
use Symfony\Component\HttpFoundation\Response;


class StudiesController extends Controller
{
    use ResponseTrait;

    public function __construct() {

       $this->middleware('auth:api');
    }    

    public function myCourses($year = null) {

        $user = auth()->user();
        //$user = User::find(131206);
        $student = $user->student;

        if($year === null) {
            $year = $student->term->term_year;            
        }

        $termsIDs = Term::where('years', $year)->pluck('id')->toArray();         

        $query = Study::select('studies.id',
            'studies.committee_id',
            'studies.course_id',
            'courses.short_name as code', 
            'courses.en_name', 
            'courses.ar_name', 
            'courses.credit_hours',
            'studies.bn as study_bn',
            'studies.first_work',
            'courses.max_first_work',
            'studies.final_work',
            'courses.max_final_work',
            'studies.work',
            'studies.midterm',
            'courses.max_midterm',
            'studies.activities',
            'courses.max_activities',
            'studies.grade',
            'studies.grade_gpa',
            'studies.grade_letter',
            'studies.status',
            'studies.grade_id',
            'committees.control_status',
            'exams_dates.day_date as exam_date',
            'exams_committees.period as exam_period',
            'exams_dates.day_date as exam_date',
            'faculty_locations.name as exam_locations',
            'studies.exam_position as exam_bn')
        ->join('courses', 'courses.id', 'studies.course_id')
        ->join('committees', 'committees.id', 'studies.committee_id')
        ->join('terms', 'terms.id', 'studies.term_id')
        ->whereIn('studies.term_id', $termsIDs)
        ->leftJoin('exams_committees', function($join) {
            $join->on('exams_committees.location_id', 'studies.exam_location_id');
            $join->on('exams_committees.committee_id', 'studies.committee_id');
            $join->where('exams_committees.linked_id', '0');
        })
        ->leftJoin('exams_dates', 'exams_dates.id', 'exams_committees.exams_date_id')
        ->leftJoin('faculty_locations', 'faculty_locations.id', 'studies.exam_location_id')
        ->where('studies.user_id', $student->id)
        ->where('studies.status', '&', Study::STATUS_REGISTERED)
        ->where('studies.active', 1)
        ->where('courses.short_name', 'NOT LIKE', 'CRN%')
        ->orderBy('terms.start_date', 'DESC')
        ->orderBy('exams_dates.day_date')
        ->orderBy('exams_committees.period');

        $query->addSelect(DB::raw("(CASE WHEN grade_id is null THEN 'draft' ELSE 'final' END) as grade_status"));

        $studies = [];
        $tempStudies = $query->get();
        foreach ($tempStudies as $tempStudy) {
            
            $study = (object) $tempStudy->getAttributes();
            $study->teachers = $tempStudy->teachers;
            
            if($study->control_status&Committee::CONTROL_STATUS_PUBLISHED) {

            } else {

                unset($study->grade);
                unset($study->grade_gpa);
                unset($study->grade_letter);
            }
            
            if($study->status&Study::STATUS_CREDIT) {
                
                unset($study->first_work);
                unset($study->max_first_work);
                unset($study->final_work);
                unset($study->max_final_work);
                unset($study->work);
                unset($study->grade);
            } else {

                unset($study->credit_hours);
                unset($study->activities);
                unset($study->max_activities);
                unset($study->midterm);
                unset($study->max_midterm);
                unset($study->grade_gpa);
            }

            unset($study->control_status);
            unset($study->status);
            unset($study->grade_id);

            if($study->exam_bn===null) {
                
                unset($study->exam_date);
                unset($study->exam_period);
                unset($study->exam_locations);
                unset($study->exam_bn);
            }
            
            if(property_exists($study, 'work')) {
                
                if($study->work===null) {

                    unset($study->work);
                } else {

                    $study->max_work = $study->max_first_work + $study->max_final_work;
                }
            }

            if(property_exists($study, 'first_work') && $study->first_work===null) {

                unset($study->first_work);
                unset($study->max_first_work);
            }

            if(property_exists($study, 'final_work') && $study->final_work===null) {

                unset($study->final_work);
                unset($study->max_final_work);
            }

            if(property_exists($study, 'midterm') && $study->midterm===null) {

                unset($study->midterm);
                unset($study->max_midterm);
            }

            if(property_exists($study, 'activities') && $study->activities===null) {

                unset($study->activities);
                unset($study->max_activities);
            }

            $studies[] = $study;
        }

        return $this->ApiResponse($studies);
    }
}
