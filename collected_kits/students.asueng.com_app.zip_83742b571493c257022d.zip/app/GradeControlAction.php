<?php

namespace App;

use BaseModel\Model;

class GradeControlAction extends BaseModel
{
    protected $table = 'grades_control_actions';
}
