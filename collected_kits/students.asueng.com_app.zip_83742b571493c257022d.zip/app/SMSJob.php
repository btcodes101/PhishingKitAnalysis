<?php

namespace App;

use App\User;
use App\Archive;
use App\BaseModel;
use Carbon\Carbon;

class SMSJob extends BaseModel
{
    protected $table = 'sms_jobs';

    public function smsMessage(){
        return $this->belongsTo('App\SMSMessage');
    }

    public static function errorCode(){
        return [
            1901 => 'Success, Message Submitted Successfully',
            1902 => 'Invalid URL , This means that one of the parameters was not provided',
            9999 => 'Please Wait For A While , This means You Sent Alot Of API Request At The Same Time',
            1903 => 'Invalid value in username or password field',
            1904 => 'Invalid value in "sender" field',
            1905 => 'Invalid value in "mobile" field',
            1906 => 'Insufficient Credit selected.',
            1907 => 'Server under updating',
            1908 => 'Invalid Date & Time format in “DelayUntil=” parameter',
            1909 => 'Error In Message',
            8001 => 'Mobile IS Null',
            8002 => 'Message IS Null',
            8003 => 'Language IS Null',
            8004 => 'Sender IS Null',
            8005 => 'Username IS Null',
            8006 => 'Password IS Null',
            6000 => 'Success, Request Submitted Successfully',
            "Error" => 'Invalid URL , This means that one of the parameters was not provided or wrong information'
        ];
    }
}