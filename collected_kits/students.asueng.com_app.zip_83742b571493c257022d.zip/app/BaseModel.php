<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class BaseModel extends Model
{
	public function lang($field) {
		$value = $this[lang()."_".$field];
		if($value)return $value;
		if(lang()=='en') {
			$value = $this[$field];
			if($value)return $value;
		}
		return null;
	}

	public static function evalSQLValue($sql, $name='value') {
		$result = DB::select($sql);
		if(count($result)>0) return $result[0]->{$name};
		return false;
	}
}