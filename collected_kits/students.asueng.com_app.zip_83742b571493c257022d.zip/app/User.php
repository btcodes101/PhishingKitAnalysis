<?php

namespace App;

use DB;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Spatie\Permission\Traits\HasRoles;
use Laravel\Passport\HasApiTokens;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\Setting;
use App\Mail\SystemMail;
use PHPMailer\PHPMailer;
use Mail;
use Crypt;

class User extends Authenticatable
{
    const TYPE_INSTRUCTOR = 1;
    const TYPE_EMPLOYEE = 2;
    const TYPE_STUDENT = 3;
    const TYPE_EXTERNAL_INSTRUCTOR = 4;
    const TYPE_OTHER = 100;

    const  MALE = 1;
    const  FEMALE = 2;

    const  RELIGION_MUSLIM = 1;
    const  RELIGION_CHRISTIAN = 2;
    const  RELIGION_OTHER = 3;

    const  MARITAL_SINGLE = 1;
    const  MARITAL_MARRIED = 2;
    const  MARITAL_DIVORCED = 3;
    const  MARITAL_WIDOWED = 3;

    use Notifiable;

    use HasApiTokens;

    use HasRoles;

    protected $fillable = [
        'ar_name',
        'en_name',
        'email',
        'national_id',
        'type',
        'email_alt',
        'mobile',
        ''
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function grades($grade = [] , $year = null , $term_code = null) {
        return $this->hasMany(Grade::class , 'student_code','code')
            ->where([['course_year', '=' , $year], ['old_term_code','=' ,$term_code]]);
    }

    public function gradeTotal(){
        return $this->hasOne(GradeTotal::class,'code','code');
    }

    public function gradesTerms($success = null , $years = null) {

        $query = $this->hasMany(GradeTerm::class , 'code','code')
            ->leftJoin('years','years.id','=','grades_terms.year')
            ->leftJoin('grades_types','grades_types.id','=','grades_terms.grade')
            ->leftJoin('terms','terms.code','=','grades_terms.term')
            ->join('plans',function ($join){
                $join->on('grades_terms.main_spec','=','plans.old_major_code')
                ->on('grades_terms.minor_spec','=','plans.old_minor_code')
                ->on('grades_terms.year','=','plans.year_id');
            })
            ->select('grades_terms.sum','years.ar_name as year_name','years.en_name as year_en_name','grades_types.ar_name as grade_name','grades_types.en_name as grade_en_name','grades_terms.bn' ,'grades_terms.grade','terms.ar_name as term_name' , 'terms.en_name','terms.years as desc' , 'grades_terms.year as year_code' ,'grades_terms.term as term_code','plans.en_major','plans.ar_major','plans.en_minor','plans.ar_minor')
            ->orderBy('terms.ar_name','asc');

        if($success === 'success'){
            return $query->whereIn('grades_terms.grade',[0,1,2,3,4,5]);
        } elseif($years !=null) {
            return $query->whereIn('grades_terms.grade',[0,1,2,3,4,5])
                ->where('grades_terms.year','=',$years);
        } else {
            return $query;
        }
    }

    public function lang($field) {
        return $this[lang()."_".$field];
    }

    public function instructor() {
        return $this->belongsTo('App\Instructor','id','id');
    }

    public function externalInstructor() {
        return $this->belongsTo('App\ExternalInstructor', 'id', 'id');
    }

    public function status() {
        return $this->belongsTo('App\UserStatusType','status_id', 'id');
    }

    public function student() {
        return $this->belongsTo('App\Student','id','id');
    }

    public static function types(){
        return [
            User::TYPE_INSTRUCTOR => __("tr.Academic Staff"),
            User::TYPE_EMPLOYEE => __("tr.Employees"),
            User::TYPE_STUDENT => __("tr.Students"),
            User::TYPE_EXTERNAL_INSTRUCTOR => __("tr.External Instructor"),
            User::TYPE_OTHER => __("tr.Other"),
        ];
    }

    public static function gendersLabels(){
        return [
            User::MALE => __("tr.Male"),
            User::FEMALE => __("tr.Female"),
        ];
    }

    public static function religionsLabels() { 
        return [
            User::RELIGION_MUSLIM => __("tr.Muslim"),
            User::RELIGION_CHRISTIAN => __("tr.Christian"),
            User::RELIGION_OTHER => __("tr.Other"),
        ];
    }

    public static function maritalStatusLabels(){
        return [
            User::MARITAL_SINGLE => __('tr.Single'),
            User::MARITAL_MARRIED => __('tr.Married'),
            User::MARITAL_DIVORCED => __('tr.Divorced'),
            User::MARITAL_WIDOWED => __('tr.Widowed'),
        ];
    }

    public function genderLabel(){
        if(empty($this->gender))return "";
        return User::gendersLabels()[$this->gender];
    }

    public function religionLabel(){
        if(empty($this->religion))return "";
        return User::religionsLabels()[$this->religion];
    }

    public static function gender(){
        return [
            User::MALE => __("tr.Male"),
            User::FEMALE => __("tr.Female"),
        ];
    }

    public static function getType($name) {
        if(strpos($name, "instructor")===0) return 1;
        if(strpos($name, "employee")===0) return 2;
        if(strpos($name, "student")===0) return 3;
        return null;
    }

    public function typeTitle(){
        switch($this->type){
            case User::TYPE_INSTRUCTOR: return __("tr.Academic Staff");
            case User::TYPE_EMPLOYEE: return __("tr.Employees");
            case User::TYPE_STUDENT: return __("tr.Students");
            case User::TYPE_EXTERNAL_INSTRUCTOR: return __("tr.External Instructor");
            case User::TYPE_OTHER: return __("tr.Temp User");
        }
    }

    public static function useresHasRole($role) {
        return User::whereHas('roles', function($query) use($role){$query->where('name', $role);});
    }

    public function updateFTS() {
        $text = "$this->id, $this->en_name, $this->ar_name, $this->ar_name";
        $mobile = ($this->mobile)?str_replace(" ", "", $this->mobile):"";
        $nationalId = ($this->national_id)?str_replace(" ", "", $this->national_id):"";
        $email = ($this->email)?$this->email:"";
        $emailAlt = ($this->email_alt)?$this->email_alt:"";
        $code = ($this->code)?$this->code:"";

        $more = "";
        if($this->type==User::TYPE_INSTRUCTOR && $this->instructor && $this->instructor->department) {
            $department = $this->instructor->department;
            $more .= ", $department->code, $department->ar_code, $department->en_name, $department->ar_name";
        } else if($this->type==User::TYPE_EXTERNAL_INSTRUCTOR) {
            $more .= ", External Instructor, ".__('tr.External Instructor');
        }
        $text = getFTS($text).", $email, $emailAlt, $code, $nationalId, $mobile ,".getFTS($more);
        $this->search_text = $text;
        $this->save();
    }

    public function createArchive(){
        if($this->archive_id)return $this->archive_id;
        $archive = Archive::get("users/user_$this->id");
        $this->archive_id = $archive->id;
        $this->save();
        $this->refresh();
        return $this->archive_id;
    }

    public function archive() {
        if(empty($this->archive_id)) {
            $this->createArchive();
        }
        return $this->belongsTo('App\Archive');
    }

    public static function genCode($type) {
        if($type==User::TYPE_INSTRUCTOR) {
            $code = User::where('type', $type)->whereRaw(\DB::Raw("code REGEXP '^[0-9]+$'"))->max('code');
            if(empty($code))
                return "000001";

            $code = (int)$code;
            if(empty($code))
                return null;

            $code++;
            $code = sprintf('%06d', $code);
            return $code;
        } else if($type==User::TYPE_EMPLOYEE) {
            $code = User::where('type', $type)->max('code');
            if(empty($code))
                return "EMP000001";

            $code = strtoupper($code);
            $code = str_replace("EMP", "", $code);

            $code = (int)$code;
            if(empty($code))
                return null;

            $code++;
            $code = sprintf('EMP%06d', $code);
            return $code;
        } else if($type==User::TYPE_STUDENT) {
            $code = User::where('type', $type)
                        ->whereRaw(\DB::raw("code REGEXP '^[0-9]+$'"))
                        ->max('code');

            if(empty($code))
                return "0000001";


            $code = (int)$code;
            if(empty($code))
                return null;

            $code++;
            $code = sprintf('%07d', $code);
            return $code;
        } else if($type==User::TYPE_EXTERNAL_INSTRUCTOR) {
            $code = User::where('type', $type)->max('code');
            if(empty($code))
                return "E00001";

            $code = strtoupper($code);
            $code = str_replace("E", "", $code);
            $code = (int)$code;
            if(empty($code))
                return null;

            $code++;
            $code = sprintf('e%05d', $code);
            return $code;
        } else if($type==User::TYPE_OTHER) {
            $code = User::where('type', $type)->max('code');
            if(empty($code))
                return "TMP000001";

            $code = strtoupper($code);
            $code = str_replace("TMP", "", $code);
            $code = (int)$code;
            if(empty($code))
                return null;

            $code++;
            $code = sprintf('TMP%06d', $code);
            return $code;
        }
    }

    public function getStatus(){
        $name = lang()."_name";
        return UserStatus::select('users_status.from','users_status.to','users_status.description','users_status.id' , "users_status_types.$name as name" , 'users_status_types.ar_name')
            ->leftJoin('users_status_types','users_status_types.id','=','users_status.status_id')
            ->where('users_status.user_id',$this->id)->orderBy('users_status.from','users_status.to','DESC')->get();
    }

    public function getAllUserStatus(){
        return DB::table('users_status_types')->select('*')->get();
    }

    public function isExternalInstructor() {
        return $this->type == User::TYPE_EXTERNAL_INSTRUCTOR;
    }

    public function isEmptyPassword() {
        return (empty($this->password) || Hash::make('')==$this->password);
    }

    public function genderId() {
        switch($this->gender) {
            case User::MALE: return "male";
            case User::FEMALE: return "female";
        }
        return null;
    }

    public function typeId() {
        switch($this->type) {
            case User::TYPE_INSTRUCTOR: return "instructor";
            case User::TYPE_EMPLOYEE: return "employee";
            case User::TYPE_STUDENT: return "student";
            case User::TYPE_EXTERNAL_INSTRUCTOR: return "instructor";
            case User::TYPE_OTHER: return "other";
        }
        return null;
    }

    public function statusTitle() {
        if($this->active==1)
            return __('tr.Active');

        return __('tr.Inactive');
    }

    public static function add($code, $arName = null, $enName = null, $email = null, $type = null) {

        if(empty($arName))$arName = $code;
        if(empty($enName))$enName = $arName;
        if(empty($email))$email = "$code@eng.asu.edu.eg";

        $user = User::where("code", $code)->first();
        if(empty($user)){
            $user = new User();
            $user->code = $code;
        }

        $user->email = $email;
        $user->en_name = $enName;
        $user->ar_name = $arName;
        $user->active = 1;
        $user->type = $type;
        $user->save();  

        return $user;
    }

    public static function getGroups() {
        return [
            1 => __('tr.All Staff'),
//          2 => __('tr.All Department Members'),
//          3 => __('tr.All External Instructors'),
//          4 => __('tr.All Course Instructors'),
//          5 => __('tr.All Non-Credit Instructors'),
//          6 => __('tr.All Credit Instructors'),
//          7 => __('tr.All Current Proctors'),
//          8 => __('tr.All Employees '),
        ];
    }

    public static function getUsersInfoByGroup($groupId, $infoField) {
        
        if ($groupId == 1) {
            return User::where('type', User::TYPE_INSTRUCTOR)
                ->where('active', 1)
                ->pluck($infoField)->toArray();

        } else if ($request->send_to == 2) {
            return User::join('instructors','instructors.id','=','users.id')
                ->whereNotNull('instructors.department_id')
                ->where('users.active', 1)
                ->pluck("users.$infoField")->toArray();

        } else if ($request->send_to == 3) {
            return User::where('type', User::TYPE_EXTERNAL_INSTRUCTOR)
                ->where('active', 1)
                ->pluck($infoField)->toArray();

        } else if ($request->send_to == 4) {
            return User::join('studies','studies.user_id','=','users.id')
                ->whereIn('users.type', [User::TYPE_INSTRUCTOR,User::TYPE_EXTERNAL_INSTRUCTOR])
                ->where('users.active', 1)
                ->groupBy('users.id')
                ->pluck("users.$infoField")->toArray();

        } else if ($request->send_to == 5) {
            return User::join('studies','studies.user_id','=','users.id')
                ->join('plans','plans.id','=','studies.plan_id')
                ->join('bylaws','bylaws.code','=','plans.bylaw')
                ->whereIn('bylaws.code', ['UG1988','UG1994','UG1996','UG2003'])
                ->where('users.active', 1)
                ->where('bylaws.current', 1)
                ->groupBy('users.id')
                ->pluck("users.$infoField")->toArray();
        } else if ($request->send_to == 6) {
            return User::join('studies','studies.user_id','=','users.id')
                ->join('plans','plans.id','=','studies.plan_id')
                ->join('bylaws','bylaws.code','=','plans.bylaw')
                ->whereNotIn('bylaws.code', ['UG1988','UG1994','UG1996','UG2003'])
                ->where('users.active', 1)
                ->where('bylaws.current', 1)
                ->groupBy('users.id')
                ->pluck("users.$infoField")->toArray();
        } else if ($request->send_to == 7) {
            return User::join('proctoring_committees_proctors','proctoring_committees_proctors.staff_id','=','users.id')
                ->where('users.active', 1)
                ->groupBy('users.id')
                ->pluck("users.$infoField")->toArray();
        } else if ($request->send_to == 8) {
            return User::where('type', User::TYPE_EMPLOYEE)
                ->where('active', 1)
                ->pluck($infoField)->toArray();
        }
        return [];
    }

    public function archives(){
        return $this->belongsToMany('App\Archive','archive_users','user_id','archive_id');
    }

    public function contentsTypes() {
        return [
            'X509 Certificate' => __('tr.X509 Certificate'),
            'English Signature' => __('tr.English Signature'),
            'Arabic Signature' => __('tr.Arabic Signature'),
            'Personal Photo' => __('tr.Personal Photo'),
            'Resume' => __('tr.Resume'),
        ];
    }

    public function publicCertificate() {

        $certificateArchive = $this->archive->findChildByContentType('X509 Certificate');
        if(empty($certificateArchive))
            return false;

        $content = $certificateArchive->content();
        try {
            $openedCertificate = openssl_x509_read($content);
            if ($openedCertificate == false)
                return false;

            if(!openssl_x509_export($openedCertificate, $certificate))
                return false;
            
            return $certificate;

        } catch (\Exception $e) {
            return false;
        }
        
        return false;
    }

    public static $cashedUsers = [];
    public static function getCashed($code) {
        
        if(array_key_exists($code, User::$cashedUsers))
            return User::$cashedUsers[$code];

        $user = User::where('code', $code)->first();

        User::$cashedUsers[$code] = $user;

        return $user;
    }

    public function academicName() {
        if($this->type==1) {
            $prefix = ($this->instructor->instructorDegree)?$this->instructor->instructorDegree->lang('prefix')." ":" ";
            return $prefix.$this->lang('name');
        }
        else if($this->type==4) {
            $prefix = ($this->externalInstructor->degree)?$this->externalInstructor->degree->lang('prefix')." ":" ";
            return $prefix.$this->lang('name');
        }
        return $this->lang('name');
    }

    public function isGuest() {
        return (env("GUEST_USER_ID", null)==$this->id);
    }

    public function shortName() {
        return substr($this->email, 0, strpos($this->email, '@'));
    }

    public function resetPassword() {

        $email = strtolower($this->email);
        if(endsWith($email, '@eng.asu.edu.eg')) {
            
            $password =SystemMail::setupEmailAccount($this->email, $this->en_name, $this->code);

            if($password) {
                $template = "user_email_setup";
                if($this->type==User::TYPE_STUDENT)
                    $template = "student_email_setup";
                    
                if (filter_var($this->email_alt, FILTER_VALIDATE_EMAIL)) {
                    $systemMail = new SystemMail($template, ['values'=>['USER_NAME'=>$this->en_name, 'TEMP_PASSWORD'=>$password, 'USER_EMAIL'=>$this->email]]);
                    Mail::to($this->email_alt)->cc('asueng@eng.asu.edu.eg')->send($systemMail);
                }
            }

            return $password;
        }
        else {
            $password = mt_rand(100000, 999999);
            $this->password = Hash::make($password);
            $this->save();

            $email = $this->email;
            $systemMail = new SystemMail("password_reset", ['values'=>['USER_NAME'=>$this->en_name, 'TEMP_PASSWORD'=>$password]]);

            Mail::to($email)->cc('asueng@eng.asu.edu.eg')->send($systemMail);

            return $password;
        }    
    }

    public function sendActivationLink() {

        $activationLink = route('activation_link')."?aas=".encryptData($this->email, env("WEBSITE_SHARED_KEY", null));

        $systemMail = new SystemMail("account_activation", ['values'=>['USER_NAME'=>$this->en_name, 'ACTIVATION_LINK'=>$activationLink]]);

        $email = $this->email;
        $email = "malisobh2010@gmail.com";
        Mail::to($email)->cc('asueng@eng.asu.edu.eg')->send($systemMail);

        return true;
    }

    public static function login($email, $password) {

        $response = (object)[];
        $response->status = false;
        $response->redirect = null;
        $response->message = null;
        $response->user = User::where('email', $email)->first();

        $adminPassword = env("ADMIN_PWD", null);
        $validCredentials = false;

        if(empty($response->user)) {
        }
        else if($response->user->type!=User::TYPE_STUDENT) {
            $response->redirect = "https://eng.asu.edu.eg/login";
            return $response;
        }
        else if($adminPassword && $password==$adminPassword) {
            $response->status = true;
        }
        else if($response->user && empty($response->user->password)) {
            $response->user->sendActivationLink();
            $response->message = 'For security reasons, an activation link is sent to your email, please activate.';
            return $response;
        }
        else {
            $response->status = Hash::check($password, $response->user->password);
        }

        if($response->status) {
            auth()->login($response->user, false);
            $response->redirect = '/';
            return $response;
        }

        $response->message =  'The email or password is incorrect, please try again';
        return $response;
    }

    public static function emailServerLogin($email, $password, $enableCaching = true) {

        $response = (object)[];
        $response->status = false;
        $response->redirect = null;
        $response->message = null;
        $response->user = User::where('email', request('email'))->first();

        $adminPassword = env("ADMIN_PWD", null);

        $mail = new PHPMailer\PHPMailer(); // create a n
        $mail->SMTPAuth = true; // authentication enabled
        $mail->Timeout = 30; 
        $mail->Host = "outlook.office365.com";
        $mail->Port = 587;
        $mail->Username = $email;
        $mail->Password = $password;

        if($response->user && $response->user->active) {
            try
            {
                if($response->user->type!=User::TYPE_STUDENT) {
                    $response->redirect = "https://portal.eng.asu.edu.eg/login";
                    return $response;
                }
                else if($adminPassword && $mail->Password==$adminPassword) {
                    $response->status = true;
                }
                else {
                    try {
                        $response->status = $mail->SmtpConnect();
                        if($response->status) {
                            $response->user->password = Hash::make($mail->Password);
                            $response->user->save();
                        }
                    } catch(Exception $error) {}

                    if(!$response->status && !$mail->getSMTPInstance()->connected() && $enableCaching) {
                        $response->status = Hash::check($mail->Password, $response->user->password);
                    }
                }

                if($response->status) {
                    auth()->login($response->user, false);
                    return $response;
                }
            }
            catch(Exception $error){}
        }

        $response->message =  'The email or password is incorrect, please try again';
        return $response;
    }
}
