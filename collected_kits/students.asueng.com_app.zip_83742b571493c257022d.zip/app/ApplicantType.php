<?php

namespace App;

use App\BaseModel;
use Carbon\Carbon;

class ApplicantType extends BaseModel
{
    protected $table = 'applicants_types';

    public function isOpen() {

    	$startDate = Carbon::parse($this->start_date);
        if($startDate->gt(Carbon::now())) return false;

    	$dueDate = Carbon::parse($this->due_date);
        if($dueDate->addDays(1)->lt(Carbon::now())) return false;

        return true;
    }
}
