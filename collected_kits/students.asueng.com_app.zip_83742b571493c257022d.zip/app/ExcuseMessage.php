<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExcuseMessage extends Model
{
    public function excuse(){
        return $this->belongsTo(Excuse::class);
    }

    public function user(){
        return $this->belongsTo(User::class);
    }

    
}
