<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CertificateSerial extends Model
{
    protected $table = 'certificates_serials';
    public $timestamps = false;
}
