<?php

namespace App;

use BaseModel\Model;

class StudentStatus extends BaseModel
{

    protected $table = 'students_status';

    protected $guarded = [];

    public $timestamps = false;
}
