<?php

namespace App;

use App\User;
use App\Archive;
use App\BaseModel;

class QuestionnaireQuestion extends BaseModel
{
    protected $table = "questionnaires_questions";
    protected $guarded = [];

    public static function questionType(){
        return [
            0 => __('tr.Evaluation'),
            1 => __('tr.Text'),
            2 => __('tr.Gender'),
        ];
    }

    public static function questionGroup(){
        return QuestionnaireQuestion::select(\DB::raw('CONCAT(UCASE(LEFT(question_group, 1)),SUBSTRING(question_group, 2)) as question_group'))->distinct('question_group')->pluck('question_group')->toArray();
    }

    public function answer($questionnaireTask, $student) {

    	return QuestionnaireAnswer::where('student_id', $student->id)
    		->where('task_id', $questionnaireTask->id)
    		->where('question_id', $this->id)
    		->first();
    }

    public function comment($questionnaireTask, $student) {
        return QuestionnaireComment::where('student_id', $student->id)
            ->where('task_id', $questionnaireTask->id)
            ->where('question_id', $this->id)
            ->first();
    }
}