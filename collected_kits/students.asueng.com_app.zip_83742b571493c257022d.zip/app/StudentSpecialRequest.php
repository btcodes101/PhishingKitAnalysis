<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentSpecialRequest extends Model
{
    protected $table = 'student_special_requests';
    protected $fillable = ['student_id', 'term_id', 'request', 'description', 'updated_at', 'created_at'];

    const TYPES = [
        'Large font examination paper',
        'Special examination committee',
        'Other',
    ];

    
    public function courses()
    {
        return $this->belongsToMany(Course::class, 'student_special_requests_courses', 'special_request_id', 'course_id');
    }

    public function files(){
        return $this->hasMany(Archive::class, 'parent_id', 'archive_id')->orderBy('order', 'asc')->orderBy('id', 'asc');
    }
}
