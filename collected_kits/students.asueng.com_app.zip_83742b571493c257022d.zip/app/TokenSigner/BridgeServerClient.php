<?php

namespace App\TokenSigner;

use WebSocket\Client;

/**
 * Class BridgeServerClient provides connection to (Python Bridge Server).
 * @package App\TokenSigner
 */
class BridgeServerClient
{
    /**
     * Constants.
     */
    protected const JSON_COMMAND = "command";
    protected const JSON_COMMAND_REGISTER = "REGISTER";
    protected const JSON_COMMAND_SIGN = "SIGN";
    protected const JSON_COMMAND_SIGN_RESPONSE = "SIGN_RESPONSE";

    protected const JSON_TYPE = "type";
    protected const JSON_TYPE_TOKEN_CLIENT = "token_client";
    protected const JSON_TYPE_WEB_CLIENT = "web_client";

    protected const JSON_PUBLIC_CERT_HASHES = "publicCertHashes";
    protected const JSON_PUBLIC_CERT_HASH = "publicCertHash";

    protected const JSON_CLIENT_MSG = "msg";
    protected const JSON_DATA_TO_BE_SIGNED = "data";
    protected const JSON_SIGNATURE = "signature";
    protected const JSON_ERROR = "error";

    /**
     * @var Client webSocket client object.
     */
    protected $client;

    /**
     * BridgeServerClient constructor.
     * @param string $bridge_server_uri : URL for Bridge Server.
     * @param int $timeout : timeout in seconds.
     */
    public function __construct($bridge_server_uri = 'ws://localhost:8989', $timeout = 60)
    {
        $this->client = new Client($bridge_server_uri);
        $this->client->setTimeout($timeout);
    }

    /**
     * Register the client public certificate in bridge server.
     * @param $client_public_cert_hash : Fingerprint of the client public certificate.
     * @throws \WebSocket\BadOpcodeException
     */
    private function register($client_public_cert_hash)
    {
        $register_msg_obj = array(
            self::JSON_COMMAND => self::JSON_COMMAND_REGISTER,
            self::JSON_TYPE => self::JSON_TYPE_WEB_CLIENT,
            self::JSON_PUBLIC_CERT_HASHES => Array($client_public_cert_hash)
        );

        $register_msg_str = json_encode($register_msg_obj);

        $this->client->send($register_msg_str);
    }

    /**
     * Sign string date by client's smart token.
     * @param $client_public_cert_hash : Fingerprint of the client public certificate.
     * @param $data_to_be_signed_base64 : data to be signed in base64 format.
     * @param $msg_for_client : string message to show in TokenClient application while signing operation.
     * @return string: signature in base64 format.
     * @throws \WebSocket\BadOpcodeException
     * @throws \Exception
     */
    public function sign($client_public_cert_hash, $data_to_be_signed_base64, $msg_for_client): string
    {
        $this->register($client_public_cert_hash);

        $sign_msg_obj = array(
            self::JSON_COMMAND => self::JSON_COMMAND_SIGN,
            self::JSON_TYPE => self::JSON_TYPE_WEB_CLIENT,
            self::JSON_PUBLIC_CERT_HASH => $client_public_cert_hash,
            self::JSON_CLIENT_MSG => $msg_for_client,
            self::JSON_DATA_TO_BE_SIGNED => $data_to_be_signed_base64,
        );

        $sign_msg_str = json_encode($sign_msg_obj);

        $this->client->send($sign_msg_str);

        $received = $this->receive();

        $received = json_decode($received, true);
        if(array_key_exists('error', $received) && $received[self::JSON_ERROR] == true) {
            throw new \Exception($received['msg']);
        }
        else {
            $token_signature_base64 = $received[self::JSON_SIGNATURE];
        }

        return $token_signature_base64;
    }

    /**
     * Receives the response from bridge server.
     * @return bool|null|string
     * @throws \Exception
     */
    private function receive()
    {
        try {
            $received = $this->client->receive();
        } catch (\Exception $e) {
            throw new \Exception('connect ERROR: ' . $e);
        }

        return $received;
    }
}
