<?php

namespace App;

use App\BaseModel;

class Printing extends BaseModel
{
  protected $table = 'printings';

}
