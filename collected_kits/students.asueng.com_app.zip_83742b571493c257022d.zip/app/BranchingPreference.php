<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BranchingPreference extends Model
{
    protected $table = 'branching_preferences';
    public $timestamps = false;
}
