<?php

namespace App;

use App\TicketType;
use App\TicketHistory;

use Illuminate\Database\Eloquent\Model;


class Ticket extends Model
{

    const STATUS_INCOMPLETE = -1;
    const STATUS_NEW = 0;
    const STATUS_UPDATED = 1;
    const STATUS_OPEN = 1;
    const STATUS_CLOSED = 2;
    const STATUS_FEEDBACK = 3;
    const STATUS_NO_RESPONSE = 4;


    const ACTION_TAKEN = 'Taken';
    const ACTION_RELEASED = 'Released';
    const ACTION_FORWARDED = 'Forwarded';
    const ACTION_CLOSED = 'Closed';
    const ACTION_OPENED = 'Opened';
    const ACTION_User_Feedback = 'User Feedback';


    protected $fillable = ['ticket_type_id','title','status','description', 'archive_id'];


    public function files(){
        return $this->hasMany('App\Archive', 'parent_id', 'archive_id')->orderBy('order', 'asc')->orderBy('id', 'asc');
    }

    public function messages(){

       return $this->hasMany('App\TicketMessage')->orderBy('created_at', 'desc');
    }

    public function applicant(){
        return $this->belongsTo('App\Applicant', 'related_id', 'id');
    }

    public function student(){
        return $this->belongsTo('App\Student', 'related_id', 'id');
    }

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function canDiscuss() {
        
        if($this->user_id != auth()->id() || $this->status==Ticket::STATUS_CLOSED)
            return false;

        return true;
    }

    public function canOpen() {

        if($this->user_id==env("GUEST_USER_ID", null)) {
            if(auth()->user()->isGuest()) {
                return true;
            }
            return false;
        }
        if($this->user_id!=auth()->user()->id) {
            return false;
        }
        return true;
    }

    public static function statusLabels() {
        return [
            Ticket::STATUS_INCOMPLETE => 'incomplete',
            Ticket::STATUS_NEW => 'new',
            Ticket::STATUS_UPDATED => 'updated',
            Ticket::STATUS_FEEDBACK => 'feedback',
            Ticket::STATUS_CLOSED => 'closed',
            Ticket::STATUS_NO_RESPONSE => 'no_response',
        ];

    }

    public function statusLabel() {
        //print_r($this->status);
        return Ticket::statusLabels();
    }

    public function canDelete() {
        if(auth()->id()!=$this->user_id || !auth()->user()->hasPermissionTo('delete_tickets'))
            return false;

        if($this->messages()->count()>0)
            return false;

        return true;
    }

    public function type(){
        return $this->belongsTo('App\TicketType', 'ticket_type_id', 'id');
    }

    public function isExternal() {

        switch($this->ticket_type_id) {
            case 9:
            case 10:
            case 11:
                return true;
        }

        return false;
    }

    public function externalName() {
        switch($this->ticket_type_id) {
            case 9:
            case 10:
                return $this->applicant->lang('full_name');
            break;
        }
    }

    public function externalLink() {
        switch($this->ticket_type_id) {
            case 9:
            case 10:
                return route("show_applicant", ['id' => $this->related_id]);
            break;
        }
    }

    public static function statusBadges() {
        return [
            Ticket::STATUS_INCOMPLETE => 'light',
            Ticket::STATUS_NEW => 'secondary',
            Ticket::STATUS_UPDATED => 'primary',
            Ticket::STATUS_FEEDBACK => 'dark',
            Ticket::STATUS_CLOSED => 'success',
            Ticket::STATUS_NO_RESPONSE => 'danger',
        ];
    }

    public function logTicketAction($action, $comment)
    {
        $ticket_history = new TicketHistory;

        $ticket_history->ticket_id = $this->id;
        $ticket_history->user_id = (auth()->user()->id)?auth()->user()->id:0;
        $ticket_history->action = $action;
        $ticket_history->action_comment = $comment; 

        $ticket_history->save();

        return true;
    }

    public function hasWorkflow() {
        
        switch($this->ticket_type_id) {
            case 11:
            case 24:
                return false;
        }

        return true;
    }    
}
