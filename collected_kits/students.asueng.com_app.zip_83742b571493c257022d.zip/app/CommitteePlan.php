<?php

namespace App;

use BaseModel\Model;

class CommitteePlan extends BaseModel
{
    protected $table = 'committees_plans';
    protected $guarded = [];
    public $timestamps = false;

    public function plan(){
        return $this->belongsTo('App\Plan');
    }

    public function committee(){
        return $this->belongsTo('App\Committee');
    }
}
