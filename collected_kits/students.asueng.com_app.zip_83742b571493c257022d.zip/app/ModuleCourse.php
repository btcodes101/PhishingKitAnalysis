<?php

namespace App;

use BaseModel\Model;

class ModuleCourse extends BaseModel
{
    protected $table = 'modules_courses';
    protected $guarded = [];
    public $timestamps = false;

    public function course() {
        return $this->belongsTo('App\Course');
    }

    public function module() {
        return $this->belongsTo('App\Module');
    }
}
