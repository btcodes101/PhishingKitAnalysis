<?php

namespace App;

use App\BaseModel;
use App\Section;
use App\Exams;
use App\Term;
use App\ExamsCommittee;
use DB;

class Study extends BaseModel
{
    protected $guarded = [];

    const ROLE_STUDENT = 1;
    const ROLE_TEACHER = 2;
    const ROLE_EXAMINAR_COMMITTEE = 3;
    const ROLE_TEACHING_ASSISTANT = 4;

    const TYPE_FRESH = 1;
    const TYPE_FAIL = 2;
    const TYPE_REPEAT = 3;
    const TYPE_EXTERNAL = 4;

    const STATUS_SUCCEEDED          = 0x0000000000000001;
    const STATUS_FAILED             = 0x0000000000000002;    
    const STATUS_DEGREE             = 0x0000000000000004;
    const STATUS_CREDIT             = 0x0000000000000008;

    const STATUS_FRESH              = 0x0000000000000010;
    const STATUS_REPEAT             = 0x0000000000000020;
    const STATUS_IMPROVE            = 0x0000000000000040;
    const STATUS_TRANSFER           = 0x0000000000000080;

    const STATUS_EXAMINED_AGAIN     = 0x0000000000000100;
    const STATUS_SUSPENDED          = 0x0000000000000200;
    const STATUS_WITHDRAWN          = 0x0000000000000400;
    const STATUS_EXCUSED            = 0x0000000000000800;

    const STATUS_REGULAR            = 0x0000000000001000;
    const STATUS_EXTERNAL           = 0x0000000000002000;
    const STATUS_SELF               = 0x0000000000004000;
    const STATUS_AUDIT              = 0x0000000000008000;

    const STATUS_MANDATORY          = 0x0000000000010000;
    const STATUS_ELECTIVE           = 0x0000000000020000;
    const STATUS_REGISTERED         = 0x0000000000040000;
    const STATUS_AUTO               = 0x0000000000080000;

    const STATUS_REGISTER_REQUEST   = 0x0000000000100000;
    const STATUS_ADD_REQUEST        = 0x0000000000200000;
    const STATUS_DROP_REQUEST       = 0x0000000000400000;
    const STATUS_WITHDRAW_REQUEST   = 0x0000000000800000;

    const STATUS_EXCUSE_REQUEST     = 0x0000000001000000;
    const STATUS_SUCCEEDED_BEFORE   = 0x0000000002000000;
    const STATUS_EXCLUDE            = 0x0000000004000000;
    const STATUS_PUNISHED           = 0x0000000008000000;

    const STATUS_ABSENT_FIRST       = 0x0000000010000000;
    const STATUS_ABSENT             = 0x0000000020000000;
    const STATUS_CHEAT              = 0x0000000040000000;

    const STATUS_INCOMPLETE         = 0x0000000100000000;
    const STATUS_FREEZED            = 0x0000000200000000;
    
    const STATUS_UNUSED             = 0x8000000000000000; //(-ev)

    const STATUS_ATTENDED           = 0x0000000400000000;

    public function instructors() {

        return $this->hasMany('App\CommitteeInstructor', 'committee_id', 'committee_id')
                    ->join('users', 'users.id', 'committees_instructors.instructor_id')
                    ->select('users.id', 'users.en_name', 'users.ar_name');        
    }

    public function teachers() {

        return $this->hasMany('App\CommitteeInstructor', 'committee_id', 'committee_id')
                    ->join('users', 'users.id', 'committees_instructors.instructor_id')
                    ->where('committees_instructors.role', Study::ROLE_TEACHER)
                    ->select('users.id', 'users.en_name', 'users.ar_name');
          
    }

    public function getGrade(){
        return $this->belongsTo('App\Grade', 'grade_id', 'id');
    }

    public function course(){
        return $this->belongsTo('App\Course');
    }

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function term(){
        return $this->belongsTo('App\Term');
    }

    public function plan(){
        return $this->belongsTo('App\Plan');
    }

    public function section(){
        return $this->belongsTo('App\Section');
    }

    public function committee(){
        return $this->belongsTo('App\Committee');
    }

    public static function roles(){
        return [
            Study::ROLE_STUDENT => __('tr.Student'),
            Study::ROLE_TEACHER => __('tr.Teacher'), 
            Study::ROLE_EXAMINAR_COMMITTEE => __('tr.Examinar Committee'), 
            Study::ROLE_TEACHING_ASSISTANT => __('tr.Teaching Assistant'), 
        ];
    }

    public static function plans($term_id,$course_id)
    {
        $majorField = lang()."_major";
        $minorField = lang()."_minor";
        $nameField = lang()."_name";
        $student = __('tr.Student');
        $course = Course::find($course_id);
        $role = Study::ROLE_STUDENT;

        $result = \DB::select("SELECT studies.plan_id as id, CONCAT(UPPER(plans.bylaw), ',', years.$nameField, ',', plans.$minorField, ' (', COUNT(*), ' $student)') as name FROM studies INNER JOIN courses ON courses.id = studies.course_id INNER JOIN plans ON plans.id = studies.plan_id  INNER JOIN years ON plans.year_id = years.id WHERE studies.term_id = $term_id AND studies.role = $role AND courses.code = '$course->code' GROUP BY studies.plan_id ORDER BY name");

        return $result;
    }

    public static function locations($term_id,$course_id){
        $role = Study::ROLE_STUDENT;

        $locations = \DB::select("SELECT faculty_locations.id as id,faculty_locations.name , proctoring_committees_courses.num_students
                FROM faculty_locations 
                INNER JOIN proctoring_committees_courses ON proctoring_committees_courses.location_id = faculty_locations.id 
                INNER JOIN studies ON studies.course_id = proctoring_committees_courses.course_id 
                WHERE proctoring_committees_courses.course_id = $course_id
                AND studies.term_id = $term_id
                AND studies.role = $role
                GROUP BY faculty_locations.id 
                ORDER BY name");



        return $locations;
    }

    public static function roleTextId($role) {
        
        switch($role) {
            case Study::ROLE_STUDENT: return "student";
            case Study::ROLE_TEACHER: return "teacher";
            case Study::ROLE_TEACHING_ASSISTANT: return "assistant";
            case Study::ROLE_EXAMINAR_COMMITTEE: return "committee";
        }

        return null;
    }

    public static function roleId($roleTextId) {
        
        switch($roleTextId) {
            case "student": return Study::ROLE_STUDENT;
            case "teacher": return Study::ROLE_TEACHER;
            case "assistant": return Study::ROLE_TEACHING_ASSISTANT;
            case "committee": return Study::ROLE_EXAMINAR_COMMITTEE;
        }

        return null;
    }

    public static function unenrollUndo($committee, $student) {
        $study = Study::where('user_id', $student->id)
            ->where('course_id', $committee->course_id)
            ->where('term_id', $committee->term_id)
            ->first();

        if(empty($study)) return;

        $termStage = $student->termStage('studies');
        if($termStage->stage_code == "add_drop") {
            $study->status &= ~Study::STATUS_DROP_REQUEST;
            $study->save();
        }
        else if($termStage->stage_code == "withdraw") {
            $study->status &= ~Study::STATUS_WITHDRAW_REQUEST;
            $study->save();
        }
        $student->updatedStudiesRequest();
    }

    public static function requestMask() {
        return (Study::STATUS_REGISTER_REQUEST|Study::STATUS_WITHDRAW_REQUEST|Study::STATUS_ADD_REQUEST|Study::STATUS_DROP_REQUEST|Study::STATUS_EXCUSE_REQUEST);
    }

    public static function stateMask() {
        return (Study::STATUS_WITHDRAWN|Study::STATUS_EXCUSED|Study::STATUS_REGISTERED);
    }

    public static function unenroll($committee, $student) {

        $study = Study::where('user_id', $student->id)
                ->where('course_id', $committee->course_id)
                ->where('term_id', $committee->term_id)
                ->first();

        if(empty($study)) return;

        $termStage = $student->termStage('studies');
        if( $termStage->stage_code == "registration" || 
            $termStage->stage_code == "elective_selection" || 
            $termStage->stage_code == "late_elective_selection" || 
            ($termStage->stage_code == "add_drop" && ($study->status&Study::STATUS_REGISTERED)==0)) {
            $study->delete();
        }
        else if($termStage->stage_code == "add_drop") {
            $study->status |= Study::STATUS_DROP_REQUEST;
            $study->save();
        }        
        else if($termStage->stage_code == "withdraw") {
            $study->status |= Study::STATUS_WITHDRAW_REQUEST;
            $study->save();            
        }
        $student->updatedStudiesRequest();
    }

    public static function enroll($committee, $student, $section = null, $force = false) {

       if($committee->isSectionsEnabled() && $section) {

            $taken = Study::where('section_id', $section->id)
            ->where('committee_id', $committee->id)
            ->count();
            
            if(!$force && $taken >= ($section->quota)) {
                return false;
            }
        }

        $study = Study::where('term_id', $committee->term_id)
                ->where('course_id', $committee->course_id)
                ->where('user_id', $student->id)
                ->first();

        $new = false;
        if(empty($study)) {
            $study = new Study();
            $study->term_id = $committee->term_id;
            $study->course_id = $committee->course_id;
            $study->user_id = $student->id;
            $new = true;
        }

        $study->committee_id = $committee->id;
        $study->role = Study::ROLE_STUDENT;
        $study->type = Study::TYPE_FRESH;
        $study->plan_id = $student->last_plan_id;
        if($section) {
            $study->group = $section->id;
            $study->section_id = $section->id;
        }
        $study->save();
        if($new) {
            $study->status = 0;
        }

        $termStage = $student->termStage('studies');
        if($termStage->stage_code == "elective_selection") {
            $study->status |= Study::STATUS_REGISTERED|Study::STATUS_ELECTIVE|Study::STATUS_DEGREE|Study::STATUS_FRESH;
            $study->save();            
        }
        else if($termStage->stage_code == "registration") {
            $study->status |= Study::STATUS_REGISTER_REQUEST;
            $study->save();            
        }
        else if($termStage->stage_code == "add_drop") {
            $study->status |= Study::STATUS_ADD_REQUEST;
            $study->save();
        }
        $student->updatedStudiesRequest();

        return true;
    }

    public static function avaliableSections($committee, $plansIds) {

        $lang = lang();

        return Section::select('sections.id', 'sections.group_no', 'sections.section_no', 'sections.quota', 'plans.'.$lang.'_minor as minor', DB::raw('count(*) as taken'))
        ->join('studies', 'studies.section_id', 'sections.id')
        ->leftJoin('plans', 'plans.id', '=' ,'sections.plan_id')
        ->where('studies.course_id', $committee->course_id)
        ->where('studies.term_id', $committee->term_id)
        ->whereIn('studies.plan_id', $plansIds)
        ->groupBy('sections.id')
        ->orderBy('sections.id')
        ->havingRaw(DB::raw('taken < (quota)'))
        ->get();
    }

    public function isRegistered() {
        return (($this->status&Study::STATUS_REGISTERED)!=0);
    }

    public function isWithdrawn() {
        return (($this->status&Study::STATUS_WITHDRAWN)!=0);
    }

    public function isExcused() {
        return (($this->status&Study::STATUS_EXCUSED)!=0);
    }

    public function isFreezed() {
        return (($this->status&Study::STATUS_FREEZED)!=0);
    }

    public function exam() {

        $term = Term::findOrfail($this->term_id);
        
        if($term && $term->term_type == Term::ADMISSION){
            $exam = Exams::currentAdmission();
        }else{
            $exam = Exams::current();
        }
       
        

        $examsCommittee = ExamsCommittee::where('exams_id', $exam->id)
        ->where('location_id', $this->exam_location_id)
        ->where('committee_id', $this->committee_id)
        ->first();

        return $examsCommittee;
    }

    public function location() {
        return $this->belongsTo('App\FacultyLocation', 'exam_location_id', 'id');
    }

    public function sector() {
        $sectors = $this->location->sectors;
        $capacity = $this->location->capacity;
        return 1 + round( ($this->exam_position-1) / floor($capacity/$sectors), 0);
    }

    public function is30ExamFail() {
        if($this->status&Study::STATUS_FAILED) {
            $maxExam = numValue($this->course->max_first_exam) + numValue($this->course->max_final_exam);
            $minExam = floor(0.3 * $maxExam);
            if($this->exam < $minExam) return true;
        }
        return false;
    }

    public function is48OverFail() {
        $percentage = ($this->total * 100) / $this->course->max_total;
        if($this->status&Study::STATUS_FAILED && $this->status&Study::STATUS_DEGREE) {
            if($percentage >= 48) return true;
        }
        return false;
    }

    public function isGradeFinal() {
        return ($this->getGrade!==null);
    }

    public function displayLatestGrade() {

        $grade = $this->getGrade;
        if($grade) {
            if($grade->grade_letter && $this->course->credit_hours==0) {
                return "$this->grade_letter";
            }
            else if($grade->grade_letter && $grade->grade_gpa) {
                if($grade->grade_letter == 'P' || $grade->grade_letter == 'F') return $grade->grade_letter;
                return "$grade->grade_letter ($grade->grade_gpa)";
            }
            else if($grade->grade_letter) {
                return "$grade->grade_letter";
            }
            else if($grade->grade) {
                return GradeNote::find($grade->grade)->lang('name');
            }
        }
        
        if($this->grade_letter && $this->course->credit_hours==0) {
            return "$this->grade_letter";
        }
        else if($this->grade_letter && $this->grade_gpa) {
            if($this->grade_letter == 'P' || $this->grade_letter == 'F') return $this->grade_letter;
            return "$this->grade_letter ($this->grade_gpa)";
        }
        else if($this->grade_letter) {
            return "$this->grade_letter";
        }
        else if($this->grade) {
            return GradeNote::find($this->grade)->lang('name');
        }
    }
}
