<?php

namespace App;

use App\BaseModel;

class Country extends BaseModel
{
    protected $table = 'countries';

    protected $casts = ['id' =>'string'];
}
