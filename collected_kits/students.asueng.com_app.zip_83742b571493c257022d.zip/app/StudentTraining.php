<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentTraining extends Model
{
    protected $table = 'students_trainings';

    protected $fillable = ['student_id', 'training_id', 'status', 'created_at', 'updated_at'];

    const REQUEST = -1;
    const INREVIEW = 0;
    const ACCEPTED = 1;
    const REJECTED = 2;
    const APPROVED = 3;
    const DISAPPROVED = 4;
    const MEETING = 5;

    const COMPLETED = 100;
    const RUNNING = 101;
    const PENDING = 102;

    const STATUSES = [
        -1 => 'Request',
        0 => 'In Review',
        1 => 'Accepted',
        2 => 'Rejected',
        3 => 'Approved',
        4 => 'Disapproved',   //
        5 => 'Meeting',   //
       
        /*100 => 'Completed', //
        101 => 'Running',   //
        102 => 'Pending',   //*/
    ];

    const STATUSES_COLORS = [
        -1 => '#d49814',
        0 => 'blue',
        1 => 'green',
        2 => 'red',
        3 => 'green',
        4 => 'red',
        5 => '#d49814',

       /* 100 => 'green',
        101 => 'green',
        102 => '#d49814',*/
    ];


    public function training(){
        return  $this->belongsTo(Training::class);
    }

    public function files(){
        return $this->hasMany(Archive::class, 'parent_id', 'archive_id')->orderBy('order', 'asc')->orderBy('id', 'asc');
    }

    public function studentTrainingMessages() {
        return $this->hasMany(StudentTrainingMessage::class, 'student_training_id');
    }

    public function canDiscuss(){

        if($this->status == StudentTraining::ACCEPTED || $this->status == StudentTraining::APPROVED || $this->status == StudentTraining::MEETING)
            return true;

        return false;
    }


}
