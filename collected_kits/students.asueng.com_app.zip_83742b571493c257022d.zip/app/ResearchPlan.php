<?php

namespace App;

use BaseModel\Model;

class ResearchPlan extends BaseModel {
	
    protected $table = 'research_plans';

    public $timestamps = false;
}
