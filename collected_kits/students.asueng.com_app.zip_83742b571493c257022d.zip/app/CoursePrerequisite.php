<?php

namespace App;

use App\BaseModel;

class CoursePrerequisite extends BaseModel
{
    protected $table = 'courses_prerequisites';
    public $timestamps = false;
}
