<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExamsDelivery extends Model {

    protected $table = 'exams_delivery';

}