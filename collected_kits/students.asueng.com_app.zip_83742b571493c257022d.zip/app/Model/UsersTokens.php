<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UsersTokens extends Model
{
    protected $table = 'users_tokens';
}
