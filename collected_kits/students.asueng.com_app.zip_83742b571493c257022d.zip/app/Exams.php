<?php

namespace App;

use App\ProctoringStaffQuota;
use App\BaseModel;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Exams extends BaseModel
{
    public $table = 'exams';

    protected $fillable = [
        'id',
        'name',
        'max_periods',
        'start_date',
        'end_date',
        'preferences_start_date',
        'preferences_end_date',
        'proctoring_table_date',
        'backup_percentage_chiefs',
        'backup_percentage_vice_chiefs',
        'backup_percentage_proctors',
        'term_id',
        'published',
        'active',
        ];

    public function term() {
        return $this->belongsTo('App\Term');
    }

    public function notes(){
        return $this->hasMany('App\ProctoringStaffNote', 'exams_id','id');
    }

    public function dates(){
        return $this->hasMany('App\ExamsDate', 'exams_id','id')->where('active', 1)->orderBy('day_date');
    }

    public function instructors(){
        return $this->belongsToMany('App\Instructor','proctoring_exams_instructors');
    }

    public function preferencesEndTime() {
        return Carbon::parse($this->preferences_end_date)->addDays(1);
    }

    public function preferencesStartDate() {
        return Carbon::parse($this->preferences_start_date);
    }

    public function preferencesEndDate() {
        return Carbon::parse($this->preferences_end_date);
    }

    public function proctoringTableDate() {
        return Carbon::parse($this->proctoring_table_date);
    }

    public function isProctoringTableReady() {
        return ProctoringCommitteeProctor::where('staff_id', auth()->id())
                ->where('exams_id', $this->id)
                ->exists();
    }

    public function isPreferenceOpenSoon() {
        if(empty($this->preferences_start_date))return false;
        return $this->preferencesStartDate()->gt(Carbon::now());
    }

    public function isPreferenceOpened() {
        if(empty($this->preferences_start_date))return false;
        return $this->preferencesStartDate()->lte(Carbon::now());
    }

    public function isPreferenceClosed() {
        if(empty($this->preferences_end_date))return false;
        return $this->preferencesEndDate()->lt(Carbon::now()->subDays(1));
    }

    public function isPreferenceOpen() {
        return $this->isPreferenceOpened() && !$this->isPreferenceClosed();
    }

    public function isProctoringTableAvailable() {
        if(empty($this->proctoring_table_date))return false;
        return $this->proctoringTableDate()->lte(Carbon::now());
    }

    public function isChargedForProctoring() {
        $user = auth()->user();
        return ProctoringStaffPosition::where('exams_id', $this->id)
            ->where('staff_id', $user->id)->exists();
    }

    public static function current() {
        return Exams::find(Setting::value('current_exams_id'));
    }

    public static function currentAdmission() {
        return Exams::find(Setting::value('admission_exams_id'));
    }

    public function userHasPreference() {

        $staffCheckPreference = ProctoringStaffPreference::where(['staff_id' => auth()->id(), 'exams_id'=> $this->id])->exists();

        $staffCheckExamNote = ProctoringStaffNote::where(['staff_id' => auth()->id(), 'exams_id'=> $this->id])->exists();

        return ($staffCheckPreference && $staffCheckExamNote);
    }

    public static function preferenceStatusLabels() {
        return [
            0 => __('tr.None'),
            1 => __('tr.Submitted'),
        ];
    }

    public static function preferenceStatusBadges() {
        return [
            0 => "none",
            1 => "submitted",
        ];
    }

    public function nExams() {

        return ExamsCommittee::where('exams_id', $this->id)->count(\DB::raw('DISTINCT course_id, plan_id'));
    }

    public function nCommittees() {
        return \DB::select(\DB::raw("SELECT sum(num) as committees FROM (SELECT exams_date_id,
            period, count(DISTINCT location_id) as num
            FROM exams_committees 
            WHERE exams_id = $this->id
            GROUP BY exams_date_id, period) AS T;"))[0]->committees;
    }

    public function nSectors() {
        return \DB::select(\DB::raw("SELECT sum(count) as sectors FROM (
            SELECT exams_date_id, exams_dates.day_date, period, sum(proctors) as count
            FROM (SELECT exams_date_id, period, location_id, faculty_locations.sectors as proctors
            FROM exams_committees 
            INNER JOIN faculty_locations ON faculty_locations.id = exams_committees.location_id
            INNER JOIN courses ON courses.id = exams_committees.course_id
            WHERE exams_id = $this->id AND SUBSTRING(courses.bylaw,1,2) != 'pg'
            GROUP BY exams_date_id, period, location_id) AS T
            INNER JOIN exams_dates ON exams_dates.id = T.exams_date_id
            GROUP BY exams_date_id, period
            ORDER BY exams_dates.day_date ASC) AS B;"))[0]->sectors;
    }

    public function nLargeCommittees() {
        return \DB::select(\DB::raw("SELECT sum(num) as vices FROM (SELECT exams_date_id, period, (count(*) + count(CASE WHEN study = 'pg' and students>=70 THEN 1 ELSE NULL END)) as num FROM ( SELECT exams_date_id, period, location_id, sum(num_students) as students, SUBSTRING(courses.bylaw,1,2) as study FROM exams_committees 
            INNER JOIN courses ON courses.id = exams_committees.course_id
            WHERE exams_id = $this->id
            GROUP BY exams_date_id, period, location_id, study ) AS T 
            WHERE students>=70 OR (students<70 and study='pg') GROUP BY exams_date_id, period, study) AS B;"))[0]->vices;
    }

    public function proctorsDegrees() {
        return ['teacher_assistant', 'demonstrator'];
    }

    public function chiefDegrees() {
        return ['professor', 'assistant_professor', 'teacher'];
    }

    public function viceChiefDegrees() {
        return ['teacher_assistant'];
    }

    public function staffQuota($instructor) {

        $proctoringStaffQuota = ProctoringStaffQuota::where('degree', $instructor->degree)
            ->where('min_seniority', '<=', $instructor->seniority)
            ->where('max_seniority', '>=', $instructor->seniority)
            ->first();

        return $proctoringStaffQuota;
    } 

    private function countProctors($position) {
        return \DB::select(\DB::raw("SELECT count(*) as count FROM proctoring_staff_positions WHERE exams_id = $this->id AND position = $position;"))[0]->count;
    }    

    public function nTotalProctors() {
        return $this->countProctors(ProctoringCommitteeProctor::POSITION_PROCTOR);
    }

    public function nTotalChiefs() {
        return $this->countProctors(ProctoringCommitteeProctor::POSITION_CHIEF);
    }

    public function nTotalViceChiefs() {
        return $this->countProctors(ProctoringCommitteeProctor::POSITION_VICE_CHIEF);
    }

    public function proctorsCounts($user) {

        $dates = $this->dates()->get();
        $proctorsCounts = (object) [
            'main'=>0,
            'backup'=>0,
            'total'=>0,
        ];

        foreach($dates as $date) {
            for($period=1;$period<=3;$period++) {
                $proctor = $date->proctor($user, $period);
                if($proctor) {
                    if($proctor->location_id==-1)
                        $proctorsCounts->backup += 1 + $proctor->extended_periods;
                    else
                        $proctorsCounts->main += 1 + $proctor->extended_periods;
                    
                    $proctorsCounts->total += 1 + $proctor->extended_periods;
                }
            }
        }

        return $proctorsCounts;
    }

    public static function positionId($position) {
        switch ($position) {
            case ProctoringCommitteeProctor::POSITION_CHIEF:
                return "chief";
            
            case ProctoringCommitteeProctor::POSITION_VICE_CHIEF:
                return "vice-chief";

            case ProctoringCommitteeProctor::POSITION_PROCTOR:
                return "proctor";
        }
    }


    public static function positionLabel($position) {
        switch ($position) {
            case ProctoringCommitteeProctor::POSITION_CHIEF:
                return __("tr.Chairman");
            
            case ProctoringCommitteeProctor::POSITION_VICE_CHIEF:
                return __("tr.Assistant");

            case ProctoringCommitteeProctor::POSITION_PROCTOR:
                return __("tr.Proctor");
        }
    }

    public static function proctoringPositionsLabels() {
        return [
            0 => __('tr.Exempt'),
            1 => __('tr.Chairman'),
            2 => __('tr.Assistant'),
            3 => __('tr.Proctor'),
        ];
    }

    public static function proctoringPositionsLongLabels() {
        return [
            0 => __('tr.Exempt'),
            1 => __('tr.Chairman'),
            2 => __('tr.Chairman Assistant'),
            3 => __('tr.Proctor'),
        ];
    }

    public static function proctoringPositionsBadges() {
        return [
            0 => 'exempt',
            1 => 'chairman',
            2 => 'chairman-assistant',
            3 => 'proctor',
        ];
    }

    public function periodsLabels() {
        return [
            1 => __('tr.First Period'),
            2 => __('tr.Second Period'),
            3 => __('tr.Third Period'),
        ];
    }

    public static function absenceTypes() {
        return [
            1 => __('tr.Absent'),
            2 => __('tr.Excused'),
            3 => __('tr.Delayed'),
        ];
    }
    
    public function courses($bylaw, $planId, $examType) {
        
        $query = ExamsCommittee::select(\DB::raw('exams_committees.exams_id, exams_committees.exams_date_id, exams_committees.period, exams_committees.course_id, sum(num_students) as count, exams_committees.extended_periods'))
            ->join('courses', 'courses.id', 'course_id')
            ->join('exams_dates', 'exams_dates.id', 'exams_date_id')
            ->where('exams_committees.exams_id', $this->id)
            ->where('courses.bylaw', $bylaw)
            ->where('exams_committees.linked_id', 0)
            ->groupBy('exams_committees.exams_id', 
                'exams_committees.exams_date_id', 
                'exams_committees.period', 
                'exams_committees.course_id')
            ->orderBy('exams_dates.day_date')->orderBy('period')->orderBy('courses.code');

        if($planId) $query->where('exams_committees.plan_id', $planId);
        
        if($examType) { 
            $query->where('exams_committees.course_exam_type', $examType);
        } else {
            $query->whereNull('exams_committees.course_exam_type');
        }

        return $query->get();
    }

    public function examsCommittees($bylaw) {
        
        $query = ExamsCommittee::select(\DB::raw('exams_committees.exams_id, exams_committees.exams_date_id, exams_committees.period, exams_committees.committee_id, exams_committees.course_id, exams_committees.extended_periods'))
        ->join('committees', 'committees.id', 'committee_id')
        ->join('courses', 'courses.id', 'committees.course_id')
        ->join('exams_dates', 'exams_dates.id', 'exams_date_id')
        ->where('exams_committees.exams_id', $this->id)
        ->where('courses.bylaw', $bylaw)
        ->where('exams_committees.linked_id', 0)
        ->groupBy('exams_committees.exams_id', 
            'exams_committees.exams_date_id', 
            'exams_committees.period', 
            'exams_committees.course_id')
        ->orderBy('exams_dates.day_date')->orderBy('period')->orderBy('courses.code');

        return $query->get();
    }
}
