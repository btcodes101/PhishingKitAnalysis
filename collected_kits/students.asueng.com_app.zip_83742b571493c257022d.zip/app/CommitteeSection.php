<?php

namespace App;

use BaseModel\Model;

class committeeSection extends BaseModel
{
    protected $table = 'committees_sections';
    protected $guarded = [];
    public $timestamps = false;
}
