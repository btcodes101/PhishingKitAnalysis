<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransferSPToIPRequest extends Model
{
    protected $table = 'transfer_sp_to_ip_requests';
    protected $fillable = ['student_id', 'year', 'status'];
 
    const STATUS_IN_PROGRESS = 1;

    public static function statusLabels() {
        return [
            TransferIPToSPRequest::STATUS_IN_PROGRESS => __('tr.In Progress'),
        ];
    }


    public static function statusBadges() {
        return [
            TransferIPToSPRequest::STATUS_IN_PROGRESS => 'light',
        ];
    }

   
}
