<?php

namespace App;

use App\BaseModel;

class GradeType extends BaseModel
{
	protected $table = 'grades_types';

	public static function labels() {
		return GradeType::pluck(lang()."_name as name", "id")->toArray();
	}

	public function gradeLabel($graduated) {
		if($graduated && ($this->id<1 || $this->id>4))
			return __("tr.Pass");

		return $this->lang('name');
	}
}
