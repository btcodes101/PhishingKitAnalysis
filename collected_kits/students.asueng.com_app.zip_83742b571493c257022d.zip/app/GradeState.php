<?php

namespace App;

use App\BaseModel;

class GradeState extends BaseModel
{
    protected $table = 'grades_states';
}
