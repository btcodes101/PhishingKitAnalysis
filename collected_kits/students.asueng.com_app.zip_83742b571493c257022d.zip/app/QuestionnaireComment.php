<?php

namespace App;

use App\User;
use App\Archive;
use App\QuestionnaireTask;
use App\BaseModel;

class QuestionnaireComment extends BaseModel
{
    protected $table = "questionnaires_comments";

    public   $timestamps = false;

    protected $fillable = [
        'review_status'
    ];

    public function questionnaireTask(){
        return $this->belongsTo('App\QuestionnaireTask', 'task_id', 'id');
    }

    public function question() {
        return $this->belongsTo('App\QuestionnaireQuestion', 'question_id', 'id');
    }

    public function student(){
        return $this->belongsTo('App\User', 'student_id', 'id');
    }

    public function updateSimiler($term_id) {
        $query = QuestionnaireComment::where('comment', '=', $this->comment);

        if($term_id!==null) {
            $query->whereRaw(\DB::raw("task_id IN(SELECT id FROM questionnaires_tasks WHERE term_id = $term_id)"));
    	}
    	return $query->update(array('review_status' => $this->review_status));
    }
}