<?php

namespace App;

use App\Exams;
use App\ProctoringCommitteeCourse;
use Illuminate\Database\Eloquent\Model;

class ExamsCourses extends Model {

    protected $table = 'exams_courses';

    public function exams(){
        return $this->belongsTo('App\Exams' , 'exams_id','id');
    }

    public function course(){
        return $this->belongsTo('App\Course' , 'course_id','id');
    }

    public function plan(){
        return $this->belongsTo('App\Plan' , 'plan_id','id');
    }

    public static function getExamCourses($exams) {

        $rows = ProctoringCommitteeCourse::where('exams_id', $exams->id)->groupBy('exams_id', 'exams_date_id', 'period', '');

        foreach ($variable as $key => $value) {
            # code...
        }
    }
}
