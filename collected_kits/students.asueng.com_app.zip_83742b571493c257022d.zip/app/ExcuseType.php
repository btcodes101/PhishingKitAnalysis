<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExcuseType extends Model
{
    protected $table = 'excuse_types';
}
