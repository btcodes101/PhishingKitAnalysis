<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentSetting extends Model
{
    protected $table = 'payment_settings';
    protected $fillable = ['year', 'specialized_new_freshman_fees', 'specialized_higher_grades_fees', 'interdisciplinary_grades_fees', 'wafideen_club_fees', 'external_course_fees', 'failed_course_fees', 'created_at', 'updated_at'];
}
