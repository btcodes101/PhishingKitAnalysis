<?php

namespace App;

use App\BaseModel;
use App\Study;
use Maatwebsite\Excel\Facades\Excel;


class Quality extends BaseModel
{
    public static function getCourses($termId, $role = Study::ROLE_TEACHER) {
        
        return Study::select('studies.course_id', 'studies.plan_id')
            ->join('courses', 'courses.id', 'studies.course_id')
            ->where('studies.term_id', $termId)
            ->where('studies.role', $role)
            ->groupBy('studies.course_id', 'studies.plan_id')
            ->get()->toArray();
    }

    public static function getCourses_($termId, $role = Study::ROLE_TEACHER) {
        
        $special = Study::select('studies.course_id', 'studies.plan_id')
            ->join('courses', 'courses.id', 'studies.course_id')
            ->where('studies.term_id', $termId)
            ->where('courses.code', 'like', 'HUM%')
            ->where('studies.role', $role)
            ->groupBy('studies.course_id', 'studies.plan_id')
            ->get()->toArray();

        $general = Study::select(\DB::raw('studies.course_id, 0 as plan_id'))
            ->join('courses', 'courses.id', 'studies.course_id')
            ->where('studies.term_id', $termId)
            ->where('courses.code', 'not like', 'HUM%')
            ->where('studies.role', $role)
            ->groupBy('studies.course_id')
            ->get()->toArray();

        return array_merge($special, $general);
    }

    public static function exist($courseFilesTask) {
        $query = Study::where('course_id', $courseFilesTask->course_id)
                ->where('term_id', $courseFilesTask->term_id)
                ->where('role', Study::ROLE_TEACHER);
        if($courseFilesTask->plan_id!=0)
            $query->where('plan_id', $courseFilesTask->plan_id);
        return $query->exists();
    }
} 