<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    protected $table = 'services';

    public function fawry_account(){

        return $this->belongsTo(PaymentAccount::class,'fawry_account_id', 'id');
    }

    public function bank_misr_credit_card_account(){

        return $this->belongsTo(PaymentAccount::class,'bank_misr_credit_card_account_id', 'id');
    }

    
}
