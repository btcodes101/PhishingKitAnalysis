<?php

namespace App;

use BaseModel\Model;

class TermPlanCourse extends BaseModel
{
    protected $table = 'terms_plans_courses';
    protected $guarded = [];
    public $timestamps = false;
}
