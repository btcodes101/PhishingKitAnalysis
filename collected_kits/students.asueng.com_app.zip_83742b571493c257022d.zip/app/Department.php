<?php

namespace App;

use App\BaseModel;

class Department extends BaseModel
{
    public function users(){
        return $this->hasMany('App\AcademicUser');
    }

    public function offeringDepartment(){
        return $this->hasMany('App\StudyCourse','id','offering_department_id');
    }

    public function name(){
        if (\App::isLocale('en')) {
            return $this->en_name;
        } else {
            return $this->ar_name;
        }
    }

    public static function mainDepartmentsList() {
        return Department::where('parent_id', 0)->pluck(lang().'_name', 'id')->toArray();
    }

    public static function subDepartmentsList($parentId) {
        return Department::where('parent_id', $parentId)->pluck(lang().'_name', 'id')->toArray();
    }
}
