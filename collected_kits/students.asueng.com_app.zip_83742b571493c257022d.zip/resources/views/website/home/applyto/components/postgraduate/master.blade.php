<div class="thick_header">
    <h3>@lang('tr.Master')</h3>
</div>

<hr/>

<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Specialization') </label>
            <input type="text" id="master_specialization" name="master_specialization" class="form-control" value="{{ dataField($applicant, 'master_specialization') }}" maxlength="256" />
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Date Obtained') </label>
            <input type="date" id="master_date_obtained" name="master_date_obtained" class="form-control" value="{{ dataField($applicant, 'master_date_obtained') }}" />
        </div>
    </div>
</div>
<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Title')</label>
            <input type="text" id="master_title" name="master_title" class="form-control" value="{{ dataField($applicant, 'master_title') }}" maxlength="256" />
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.Faculty') </label>
            <input type="text" id="master_faculty" name="master_faculty" class="form-control" value="{{ dataField($applicant, 'master_faculty') }}" maxlength="256" />
        </div>
    </div>
</div>

<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.University')</label>
            {!! Form::select('master_university', array(''=>__('tr.Select University'))+'App\Applicant'::universities()+array('other'=>__('tr.Other')), dataField($applicant, 'master_university'), array('id'=> 'master_university', 'class'=>'form-control')) !!}
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group" id="master_university_other_div">
            <label>@lang('tr.Other')</label>
            <input type="text" id="master_university_other" name="master_university_other" class="form-control" value="{{dataField($applicant, 'master_university_other') }}" maxlength="256" />
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#master_university").change(function () {
            if($(this).val() == 'other'){
                $('#master_university_other_div').show();
                $('#master_university_other').prop('disabled', false);
            } else {
                $('#master_university_other_div').hide();
                $('#master_university_other').prop('disabled', true);
            }
        });
        $("#master_university").trigger('change');
    });
</script>