<div class="thick_header">
    <h3>@lang('tr.Admission Information')</h3>
</div>
<hr>

<div class="form-group">
    <label>@lang('tr.Study Type') <span class="required_field">*</span></label>
    {!! Form::select('study_type', array(''=>__('tr.Select Study Type'))+'App\Plan'::tracksList(), dataField($applicant, 'study_type'), array('id'=> 'study_type', 'class'=>'form-control', 'required' => 'required')) !!}
</div>
@php($programs = 'App\Plan'::programsList('interdisciplinary', 'UG2018'))
<div id="programs">
    <div class="form-group">
        <label>@lang('tr.First Program Choice') <span class="required_field">*</span></label>
        {!! Form::select('first_program', array(''=>__('tr.Select Study Type'))+$programs, dataField($applicant, 'first_program'), array('id'=> 'first_program', 'class'=>'form-control SelectFirstProgramPreferencetobeEnrolled', 'required' => 'required' ,'onchange'=>"removeAllOptions('first_program','second_program')")) !!}
    </div>

    <div class="form-group">
        <label>@lang('tr.Second Program Choice') <span class="required_field">*</span></label>
        {!! Form::select('second_program', array(''=>__('tr.Select Study Type'))+$programs, dataField($applicant, 'second_program'), array('id'=> 'second_program', 'class'=>'form-control SelectSecondProgramPreferencetobeEnrolled', 'required' => 'required' ,'onchange'=>"removeAllOptions('second_program','first_program')")) !!}
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {

        $('#study_type').on('change', () => {
            if($('#study_type').val() == '' || $('#study_type').val() == 'specialized'){
                $('#programs').hide();
                $('#programs :input').prop('disabled', true);
            } else {
                $('#programs').show();
                $('#programs :input').prop('disabled', false);
            }
        });

        $("#study_type").trigger('change');
    });

    function removeAllOptions(elN,selectN)
    {
        var el = document.getElementById(elN);
        var text = el.options[el.selectedIndex].value;
        var select = document.getElementById(selectN);
        for (var i=0, length = select.options.length; i< length; i++) {
        
            if (select.options[i] && select.options[i].value === text) {
                select.options[i].disabled=true;
            }
            else{
                select.options[i].disabled=false;
            }
        }
    }
</script>

    