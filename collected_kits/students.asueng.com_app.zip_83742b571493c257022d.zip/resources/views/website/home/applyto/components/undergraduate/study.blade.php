<div class="thick_header">
    <h3>@lang('tr.Study')</h3>
</div>
<hr>
<div class="form-row">
    <div class="col-lg-6">
        <div class="form-group">
            <label>@lang('tr.School Study Type') <span class="required_field">*</span></label>
            {!! Form::select('school_study_type', array(''=>__('tr.Select School Study Type'))+'App\Student'::schoolStudyType(), dataField($applicant, 'school_study_type'), array('id'=> 'school_study_type', 'class'=>'form-control', 'required' => 'required')) !!}
        </div>
    </div>
    <div class="col-lg-6" id="other_school_study_type_div">
        <div class="form-group">
            <label>@lang('tr.Other School Study Type')</label>
            <input type="text" class="form-control" id="other_school_study_type" name="other_school_study_type" value="{{ dataField($applicant, 'other_school_study_type') }}">
        </div>
    </div>
</div>

<div class="form-row">
    <div class="col-lg-4">
        <div class="form-group">
            <label>@lang('tr.School Name in Arabic') <span class="required_field">*</span></label>
            <input type="text" id="school_name" name="school_name" class="form-control" value="{{dataField($applicant, 'school_name') }}" required maxlength="256" style="direction: rtl;" />
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label>@lang('tr.School Marks') <span class="required_field">*</span></label>
            <input type="text" id="school_marks" name="school_marks" class="form-control" value="{{dataField($applicant, 'school_marks') }}" required maxlength="256" />
        </div>           
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label>@lang('tr.School Max Marks') <span class="required_field">*</span></label>
            <input type="text" name="school_max_marks" class="form-control" value="{{dataField($applicant, 'school_max_marks') }}" required maxlength="256" />
        </div>           
    </div>
    
</div>
<div class="thick_header">
    <h3>@lang('tr.Apply')</h3>
</div>
<hr>
<div class="form-row">
    <div class="col-lg-12">
        <div class="form-group">
            <label>@lang('tr.Apply To') <span class="required_field">*</span></label>
            <select class="form-control" id="undergraduate_type">
                <option value="0">Specialized</option>
            @if ($applicant->plan_id && $applicant->plan_id != 179)
                <option value="1" selected>International</option>
            @else
                <option value="1">International</option>
            @endif
            </select>
        </div>
    </div>

    <div class="col-lg-12" id="append_plans">
        <div class="form-group">
            <label>@lang('tr.Plan') <span class="required_field">*</span></label>
            {!! Form::select('plan_id', array(''=>__('tr.Select International Plan'))+$plans, field($applicant, 'plan_id'), array('id'=> 'plan_id', 'class'=>'form-control', 'title'=> __('tr.Plan'))); !!}
        </div>
    </div>  
   
</div>   

<script type="text/javascript">
    $(document).ready(function() {
        $('#school_study_type').on('change', () => {
            if($('#school_study_type').val() != 100){
                $('#other_school_study_type_div').hide();
                $('#other_school_study_type_div :input').prop('disabled', true);
            } else {
                $('#other_school_study_type_div').show();
                $('#other_school_study_type_div :input').prop('disabled', false);
            }
        });
      
        if($("#undergraduate_type").val()==0)
            $('#append_plans').hide();
        else
            $('#append_plans').show();

        $('#undergraduate_type').on('change', () => {
            if($("#undergraduate_type").val()==0){
                $('#append_plans').hide();
                $('#plan_id').val(0);
                $("#plan_id").prop("selectedIndex", 0);
            }
            else
                $('#append_plans').show();
        });
        
        $("#school_study_type").trigger('change');
    });

</script>