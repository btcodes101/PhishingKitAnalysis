<div class="thick_header">
    <h3>@lang('tr.Admission Information')</h3>
</div>
<hr>

<div class="form-group">
    <label>@lang('tr.Department') <span class="required_field">*</span></label>
    {!! Form::select('apply_to_department', array(''=>__('tr.Select Grade'))+'App\Department'::mainDepartmentsList(), dataField($applicant, 'apply_to_department'), array('id'=> 'apply_to_department', 'class'=>'form-control', 'required' => 'required')) !!}
</div>

<div class="form-group">
    <label>@lang('tr.Specialization') <span class="required_field">*</span></label>
    <select name="apply_to_specialization" id="apply_to_specialization" class="form-control" required>
        <option value=''>@lang('tr.Select Specialization')</option>
    </select>
</div>

<div class="form-group">
    <label>@lang('tr.Term') <span class="required_field">*</span></label>
    {!! Form::select('apply_to_term', array(''=>__('tr.Select Term'))+'App\Term'::nextTermsList(), dataField($applicant, 'apply_to_term'), array('id'=> 'apply_to_term', 'class'=>'form-control', 'required' => 'required')) !!}
</div>

<div class="form-group">
    <label>@lang('tr.Degree') <span class="required_field">*</span></label>
    <select name="apply_to_program" id="apply_to_program" class="form-control" required>
        <option value=''>@lang('tr.Select Degree')</option>
    </select>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        var submitToken = '{{ csrf_token() }}';
        
        var specializationsURL = '{{ route('applicants_pg_specializations', ['department_id'=>'#id']) }}';
        $('#apply_to_department').autoFill($('#apply_to_specialization'), specializationsURL, submitToken, '{{dataField($applicant, 'apply_to_specialization')}}');

        var programsURL = '{{ route('applicants_pg_programs', ['term_id'=>'#sid', 'department_id'=>'#id']) }}';
        $('#apply_to_specialization').autoFill($('#apply_to_program'), programsURL, submitToken, '{{dataField($applicant, 'apply_to_program')}}', $('#apply_to_term'));
    });
</script>

    