@extends('website.layouts.master')

@section('title', $applicant->applicantType->lang('name'))

@section('content')

@include('website.layouts.title', ['simple'=>true])

<section>
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                
                @include('website.home.applyto.components.email_verified')

                <form id="submit_form" action="{{ route('save_applicant', ['type'=>'coeenergy', 'id'=>$applicant->id]) }}" method="POST" enctype='multipart/form-data'>
                    {{ csrf_field() }}
                    <div style="border: 1px solid #dadada; padding: 20px;">
                        
                        @include('website.home.applyto.components.coeenergy.personal')
                        @include('system.components.documents', ['fileTypes'=>$applicant->fileTypes(), 'archive'=>$applicant->archive])
                        @include('website.home.components.feedback')
                        
                    </div>
                    
                    @if($applicant->canUpdate())
                    @include('system.components.submit', ['isNew'=>$applicant->isNew()])
                    @endif
                    <br/>

                </form>
            </div>
            <div class="col-md-3">
                
            </div>
        </div>
    </div>
</section>

<script>

document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
});

</script>

@endsection
