@extends('website.layouts.master')
@section('title', __('tr.Confirm Certificates Request'))

@section('content')

@include('website.layouts.title', ['simple'=>true])
<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <br/>
                <br/>
                <h3>@lang('tr.General Information')</h3>
                <hr/>
                <table class="table table-striped m-0">
                    <tr><td width="150px"><b>@lang('tr.English Name'):</b></td><td>{{$userRequest->data->en_name}}</td></tr>
                    <tr><td width="150px"><b>@lang('tr.Arabic Name'):</b></td><td>{{$userRequest->data->ar_name}}</td></tr>
                    <tr><td><b>@lang('tr.Email'):</b></td><td>{{$userRequest->data->email}}</td></tr>
                    <tr><td><b>@lang('tr.Mobile'):</b></td><td>{{$userRequest->data->mobile}}</td></tr>
                    <tr><td><b>@lang('tr.Graduation Date'):</b></td><td>{{$userRequest->data->graduation_date}}</td></tr>
                    <tr><td><b>@lang('tr.Student Code'):</b></td><td>{{$userRequest->data->student_code}}</td></tr>
                    <tr><td><b>@lang('tr.Program'):</b></td><td>{{$userRequest->data->en_plan}}</td></tr>
                    <tr>
                        <td><b>@lang('tr.Documents'):</b></td>
                        <td>
                            @foreach($userRequest->archive->childrenFiles as $file)
                                <a href="{{ route('secure_download_file')."?sid=".$file->secret() }}">{{$file->name()}}</a>, 
                            @endforeach
                        </td>
                    </tr>
                </table>
                <br/>
                @if($userRequest->data->mail == 1)
                <h3>@lang('tr.Mail Information')</h3>
                <hr/>
                <table class="table table-striped m-0">
                    <tr><td width="150px"><b>@lang('tr.Address'):</b></td><td>{{$userRequest->data->mail_address}}</td></tr>
                </table>
                <br/>
                @endif
                <h3>@lang('tr.Certificates')</h3>
                <table id='certificates_table' class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>@lang('tr.Certificate Type')</th>
                            <th>@lang('tr.Number of Certificates')</th>
                            <th>@lang('tr.Cost')</th>
                            <th width="20%">@lang('tr.Total')</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php($j = 1)
                        @php($total = 0)
                        @for($i=0; $i<count($userRequest->data->type); $i++)
                        @if($userRequest->data->quantity[$i]>0)
                        @php($certificateType = 'App\CertificateType'::find($userRequest->data->type[$i]))
                        @php($total+=$certificateType->cost*$userRequest->data->quantity[$i])
                        <tr>
                            <td>{{ $j++ }}</td>
                            <td>{{ $certificateType->lang('name') }}</td>
                            <td>{{ $userRequest->data->quantity[$i] }}</td>
                            <td>{{ $certificateType->cost }}</td>
                            <td>{{ $certificateType->cost*$userRequest->data->quantity[$i] }}</td>
                            
                        </tr>
                        @endif
                        @endfor
                    </tbody>
                </table>
                <div><b>@lang('tr.Total')</b>: {{$total}} @lang('tr.Egyptian Pound')</div>
                <br/>
                <hr/>
                @include('payments.components.pay')
            </div>

            <div class="col-lg-3">
                <div style="margin-top:50px;"></div>
                @include('website.components.news', ['style'=>2])
            </div>
        </div>
    </div>
</section>
@endsection
