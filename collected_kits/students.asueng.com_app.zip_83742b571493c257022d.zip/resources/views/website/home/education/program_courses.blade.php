<table style="width:100%; color: black; text-align: center;font-size: 11px;" cellpadding="4px" cellspacing="0px" border="1px">
	<tr style="background-color: #B4C6E7;">
		<td width="8%" rowspan="2">Code</td>
		<td width="36%" rowspan="2">Course Title</td>
		<td colspan="3">Credits and SWL</td>
		<td colspan="4">Contact Hours</td>
	</tr>
	<tr style="background-color: #B4C6E7;">
		<td width="8%">CH</td>
		<td width="8%">ECTS</td>
		<td width="8%">SWL</td>
		<td width="8%">Lec</td>
		<td width="8%">Tut</td>
		<td width="8%">Lab</td>
		<td width="8%">TT</td>
	</tr>
	@php($groupParent=null)
	@php($group=null)
	@php($groupModifier=null)

	@php($totalCH = 0)
	@php($totalECTS = 0)
	@php($totalSWL = 0)
	@php($totalLCH = 0)
	@php($totalTTH = 0)
	@php($totalLBH = 0)

	@foreach($website->programCoursesGroups($bylaw, $page->short_name) as $courseGroup)
		@if($courseGroup->group!=$group && $group=='default')
			@include('website.home.education.program_courses_total', ['withPrerequisites'=>false])
		@endif
		@if($courseGroup->group_parent!=$groupParent)
			@php($groupParent=$courseGroup->group_parent)
			@php($color='lightgray')
			@if(stristr($groupParent, 'Concentration')) 
				@php($color='#C6E0B4')
			@elseif(stristr($groupParent, 'Compulsory'))
				@php($color='#FFFF00')
			@endif
			<tr>
				<td colspan="9" style="background-color: {{$color}}; text-align: left;">{{ucwords($groupParent)}}</td>
			</tr>
		@endif
		@if($courseGroup->group!=$group)			
			@php($group=$courseGroup->group)
			@if($courseGroup->group!='default')
				<tr>
					<td colspan="9" style="background-color: #F4B083; text-align: left;">{{ucwords($group)}}</td>
				</tr>
			@endif
		@endif
		@if($courseGroup->group_modifier !=$groupModifier)
			@php($groupModifier=$courseGroup->group_modifier )
			<tr>
				<td colspan="9" style="background-color: lightgray; text-align: left;">Pool {{ucwords($groupModifier)}}</td>
			</tr>
		@endif
		@if($courseGroup->course_id)
			@php($course = $courseGroup->course)
			@if($courseGroup->group=='default')
				@php($totalCH += $course->credit_hours)
				@php($totalECTS += $course->equivalent_ects)
				@php($totalSWL += $course->required_swl)
				@php($totalLCH += $course->final_lecture)
				@php($totalTTH += $course->final_tutorial)
				@php($totalLBH += $course->final_laboratory)
			@endif
			<tr>
				<td>{{str_replace("_", "", $course->short_name)}}</td>
				<td style="text-align: left;">{{$course->en_name}}</td>
				<td>{{$course->credit_hours}}</td>
				<td>{{$course->equivalent_ects}}</td>
				<td>{{$course->required_swl}}</td>
				<td>{{$course->final_lecture}}</td>
				<td>{{$course->final_tutorial}}</td>
				<td>{{$course->final_laboratory}}</td>
				<td>{{$course->totalHours()}}</td>
			</tr>
		@else
			<tr>
				<td colspan="2" style="text-align: center;">
					{{ucwords($courseGroup->courseGroupName())}}					
				</td>
				@php($relatedCoursesGroups = $courseGroup->relatedCoursesGroups())
				@php($relatedCH = 0)
				@php($relatedECTS = 0)
				@php($relatedSWL = 0)
				@php($relatedLCH = 0)
				@php($relatedTTH = 0)
				@php($relatedLBH = 0)
				@foreach($relatedCoursesGroups as $relatedCourseGroup)
					@php($relatedCH += $relatedCourseGroup->course->credit_hours)
					@php($relatedECTS += $relatedCourseGroup->course->equivalent_ects)
					@php($relatedSWL += $relatedCourseGroup->course->required_swl)
					@php($relatedLCH += $relatedCourseGroup->course->final_lecture)
					@php($relatedTTH += $relatedCourseGroup->course->final_tutorial)
					@php($relatedLBH += $relatedCourseGroup->course->final_laboratory)
				@endforeach
				@if($courseGroup->group=='default')
					@php($totalCH += $relatedCH)
					@php($totalECTS += $relatedECTS)
					@php($totalSWL += $relatedSWL)
					@php($totalLCH += $relatedLCH)
					@php($totalTTH += $relatedTTH)
					@php($totalLBH += $relatedLBH)
				@endif
				<td>{{$relatedCH}}</td>
				<td>{{$relatedECTS}}</td>
				<td>{{$relatedSWL}}</td>
				<td>{{$relatedLCH}}</td>
				<td>{{$relatedTTH}}</td>
				<td>{{$relatedLBH}}</td>
				<td>{{$relatedLCH + $relatedTTH + $relatedLBH}}</td>				
			</tr>
		@endif
	@endforeach
	@if($totalCH>0)
	@include('website.home.education.program_courses_total', ['withPrerequisites'=>false])
	@endif
</table>

@php($plan = $website->programCoursesPlan($bylaw, $page->short_name))
@if($plan && $plan->isFinalPlan())
<hr/>
<p><b>Program Study Plan</b></p>

<table style="width:100%; color: black; text-align: center;font-size: 11px;" cellpadding="4px" cellspacing="0px" border="1px">
	<tr style="background-color: #B4C6E7;">
		<td width="8%" rowspan="2">Code</td>
		<td width="22%" rowspan="2">Course Title</td>
		<td colspan="3">Credits and SWL</td>
		<td colspan="4">Contact Hours</td>
		<td width="14%" rowspan="2">Prerequisites</td>
	</tr>
	<tr style="background-color: #B4C6E7;">
		<td width="8%">CH</td>
		<td width="8%">ECTS</td>
		<td width="8%">SWL</td>
		<td width="8%">Lec</td>
		<td width="8%">Tut</td>
		<td width="8%">Lab</td>
		<td width="8%">TT</td>
	</tr>

	@php($totalCH = 0)
	@php($totalECTS = 0)
	@php($totalSWL = 0)
	@php($totalLCH = 0)
	@php($totalTTH = 0)
	@php($totalLBH = 0)
	@php($semester = null)
	@php($compulsoryGroup = null)

	@foreach($website->programStudyPlan($bylaw, $page->short_name) as $courseGroup)
		@if(($semester && $semester!=$courseGroup->course_semester)||($compulsoryGroup && $compulsoryGroup!=$courseGroup->compulsoryGroup()))
			@include('website.home.education.program_courses_total', ['withPrerequisites'=>true])
			@php($totalCH = 0)
			@php($totalECTS = 0)
			@php($totalSWL = 0)
			@php($totalLCH = 0)
			@php($totalTTH = 0)
			@php($totalLBH = 0)
		@endif
		@if($semester!=$courseGroup->course_semester)
			<tr>
				<td colspan="10" style="background-color: #B4C6E7; text-align: center;">Semester {{$courseGroup->course_semester}}</td>
			</tr>
			@php($semester=$courseGroup->course_semester)
		@endif
		@if($compulsoryGroup!=$courseGroup->compulsoryGroup())
			@php($compulsoryGroup=$courseGroup->compulsoryGroup())
			<tr>
				<td colspan="10" style="background-color: #FFFF00; text-align: center;">{{$compulsoryGroup}}</td>
			</tr>			
		@endif
		<tr>
		@php($course = $courseGroup->course)
		@if($course)
			<td>{{str_replace("_", "", $course->short_name)}}</td>
			<td style="text-align: left;">{{$course->en_name}}</td>
		@else
			<td style="text-align: center;" colspan="2">{{$courseGroup->courseGroupName()}}</td>
			@php($course = $courseGroup->courseGroupCourse())
		@endif

		@if($course)
			@php($totalCH += $course->credit_hours)
			@php($totalECTS += $course->equivalent_ects)
			@php($totalSWL += $course->required_swl)
			@php($totalLCH += $course->final_lecture)
			@php($totalTTH += $course->final_tutorial)
			@php($totalLBH += $course->final_laboratory)
			<td>{{$course->credit_hours}}</td>
			<td>{{$course->equivalent_ects}}</td>
			<td>{{$course->required_swl}}</td>
			<td>{{$course->final_lecture}}</td>
			<td>{{$course->final_tutorial}}</td>
			<td>{{$course->final_laboratory}}</td>
			<td>{{$course->totalHours()}}</td>
			<td>@if($courseGroup->course_id) {{$course->prerequisites}} @endif</td>
		@endif
		</tr>
	@endforeach
	@if($totalCH>0)
	@include('website.home.education.program_courses_total', ['withPrerequisites'=>true])
	@endif
</table>
@endif