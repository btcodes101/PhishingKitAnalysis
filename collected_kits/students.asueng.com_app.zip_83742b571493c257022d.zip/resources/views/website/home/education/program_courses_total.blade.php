<tr style="background-color: lightgray;">
	<td colspan="2" style="text-align: center;"> Total </td>
	<td>{{$totalCH}}</td>
	<td>{{$totalECTS}}</td>
	<td>{{$totalSWL}}</td>
	<td>{{$totalLCH}}</td>
	<td>{{$totalTTH}}</td>
	<td>{{$totalLBH}}</td>
	<td>{{$totalLCH + $totalTTH + $totalLBH}}</td>
	@if($withPrerequisites)<td></td>@endif
</tr>
