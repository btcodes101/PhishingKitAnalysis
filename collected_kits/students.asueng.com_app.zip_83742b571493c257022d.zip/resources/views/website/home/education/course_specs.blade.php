@foreach($website->departmentCourses($bylaw, $page->short_name) as $course)
<table style="width:100%; color: black; text-align: center;" cellpadding="4px" cellspacing="0px" border="1px">
	<tr style="height: 0px; background-color: black;">
		<td width="12%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
		<td width="8%"></td>
	</tr>
	<tr style="background-color: #B4C6E7; text-align: left;">
		<td width="12%">{{str_replace('_', '', $course->short_name)}}</td>
		<td colspan="10">{{$course->en_name}}&nbsp;</td>
		<td width="8%">{{$course->credit_hours}} CH</td>
	</tr>
	<tr style="text-align: left;">
		<td style="background-color: #C5E0B3;" width="12%">Prerequisites</td>
		<td colspan="11">{{str_replace("_", "", $course->prerequisites)}}&nbsp;</td>
	</tr>        				
	<tr style="text-align: left;">
		<td style="background-color: #C5E0B3;" colspan="12">Number of weekly Contact Hours</td>
	</tr>
	<tr style="text-align: center;">
		<td style="background-color: #C5E0B3;" colspan="4">Lecture</td>
		<td style="background-color: #C5E0B3;" colspan="4">Tutorial</td>
		<td style="background-color: #C5E0B3;" colspan="4">Laboratory</td>
	</tr>
	<tr style="text-align: center;">
		<td colspan="4">{{$course->final_lecture}} {{($course->final_lecture!=1)?"Hours":"Hour"}}</td>
		<td colspan="4">{{$course->final_tutorial}} {{($course->final_tutorial!=1)?"Hours":"Hour"}}</td>
		<td colspan="4">{{$course->final_laboratory}} {{($course->final_laboratory!=1)?"Hours":"Hour"}}</td>
	</tr>
	<tr style="text-align: left;">
		<td style="background-color: #C5E0B3;" colspan="3">Required SWL</td>
		<td colspan="3">{{$course->required_swl}}</td>
		<td style="background-color: #C5E0B3;" colspan="3">Equivalent ECTS</td>
		<td colspan="3">{{$course->equivalent_ects}}</td>
	</tr>
	<tr style="text-align: left;">
		<td style="background-color: #C5E0B3;" colspan="12">Course Content</td>
	</tr>
	<tr style="text-align: left;">
		<td colspan="12">{{$course->en_describtion}}</td>
	</tr>
	@php($coursePlans = $course->coursePlans)
	@if(count($coursePlans)>0)
	<tr style="text-align: left;">
		<td style="background-color: #C5E0B3;" colspan="12">Used in Program / Level</td>
	</tr>
	<tr>
		<td style="background-color: #C5E0B3; text-align: left;" colspan="6">Program Name or requirement</td>
		<td style="background-color: #C5E0B3;  text-align: center;" colspan="3">Study Level</td>
		<td style="background-color: #C5E0B3;  text-align: center;" colspan="3">Semester</td>
	</tr>	
	@foreach($course->coursePlans as $coursePlan)
	<tr style="color: black; text-align: center;">
		<td style="text-align: left;" colspan="6">{{$coursePlan->plan->en_minor}}&nbsp;<br><span style="font-size: 10px; color: $888;">{{$course->planGroupName($coursePlan->plan->short_name)}}</span></td>
		<td style="text-align: center;" colspan="3">{{$coursePlan->level}}&nbsp;</td>
		<td style="text-align: center;" colspan="3">{{$coursePlan->semester}}&nbsp;</td>
	</tr>
	@endforeach
	@endif
	<tr style="text-align: left;">
		<td style="background-color: #C5E0B3;" colspan="12">Assessment Criteria</td>
	</tr>
	<tr style="text-align: center;">
		<td style="background-color: #C5E0B3;" colspan="3">Student Activities</td>
		<td style="background-color: #C5E0B3;" colspan="3">Mid-Term Exam</td>
		<td style="background-color: #C5E0B3;" colspan="3">Practical Exam</td>
		<td style="background-color: #C5E0B3;" colspan="3">Final Exam</td>
	</tr>
	<tr style="text-align: center;">
		<td colspan="3">{{$course->max_activities}}%</td>
		<td colspan="3">{{$course->max_midterm}}%</td>
		<td colspan="3">{{$course->max_practical}}%</td>
		<td colspan="3">{{$course->max_final_exam}}%</td>
	</tr>
</table>
<br/>
@endforeach