@extends('website.layouts.master')
@section('title', $website->title($page))

@section('content')

@include('website.layouts.title')
@php($section = $website->section($page))
<section>
<div class="section-wrapper p-t-40 p-b-20">
      <div class="container">
        <div class="row">
        	<div class="col-md-9">
        		@if($page->isPage())
        			@include('website.components.page')
        			@if($page->short_name!='index' && $page->parent->short_name=='programs')
        			@include('website.home.education.program_courses')
        			@elseif($page->short_name!='index' && $page->parent->short_name=='course_pool')
        				@include('website.home.education.department_courses')
        				<br/>
        				@include('website.home.education.course_specs')
        			@endif
        		@endif
                @include('website.components.other_pages')
        	</div>
        	<div class="col-md-3">
        		<div class="au-widget">
        			@include('website.components.topics')
        			@include('website.components.news', ['style'=>2])
        		</div>
        	</div>
        </div>
    </div>
</div>
</section>
@endsection
