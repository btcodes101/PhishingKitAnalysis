@extends('website.layouts.master')

@section('title', $user->lang('name').' '.__('tr.profile'))

@section('content')

@include('website.layouts.title', ['simple'=>true])

<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<style>

.blog .carousel-indicators {
	left: 0;
	top: auto;
    top: -19px;

}

/* The colour of the indicators */
.blog .carousel-indicators li {
    background: #a3a3a3;
    border-radius: 50%;
    width: 8px;
    height: 8px;
}

.blog .carousel-indicators .active {
background: #707070;
}

.keyText{
    font-weight: bold;
    margin-right: 10px;
}

@media only screen and (max-width: 910px) {
  .instructorName {
    text-align:center;
  }
  .instructorName2 {
    text-align:center;
    font-size: 1.2rem;
  }
}

</style>

<section>
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                
                <br/><br/>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="card-body">
                            @php($file = $user->archive->findChildByContentType("Personal Photo"))
                            @if($file)
                                <img src="{{ route('secure_download_file')."?sid=".$file->secret() }}" style="border: 2px solid #d8d7d7; padding: 4px; box-shadow: 0 0 1px 1px transparent; display: block; margin-left: auto; margin-right: auto;" width="60%">
                            @else
                                <img src="/img/user.png" width="85%">
                            @endif
                        </div>
                    </div>

                    <div class="col-lg-8">

                    <br><br><br>

                    @if(lang() == 'en')
                        <h3 class="instructorName" style="color:black;">{{ $user->en_name }}</h3>
                    @else
                        <h3 class="instructorName" style="color:black;">{{ $user->ar_name }}</h3>
                    @endif
                        <h4 class="instructorName2">{{ ($instructor->instructorDegree)?$instructor->instructorDegree->lang('name'):"" }} @lang('tr.at') {{ ($instructor->department)?$instructor->department->lang('name'):"" }}</h4>                     
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12" style="padding:15px;margin-top:10px;">                        
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-12">
                    
                        <p style="background: #f7f7f7; color: #007bff; padding: 10px; font-size: 20px; font-weight: bold; text-align: center;">@lang('tr.Career Info')</p>
                        
                        <div class="col-lg-12">
                            <div class="row">
                                
                                @if($instructor->emeritus_at)
                                    <tr>
                                        <div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.Emeritus') @lang('tr.at') : </span>{{ $instructor->emeritus_at }}</div>
                                    </tr>
                                @endif

                                @if($instructor->professor_at)
                                    <div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.Professor') @lang('tr.at') : </span>{{ $instructor->professor_at }}</div>
                                @endif

                                @if($instructor->assistant_professor_at)
                                    <div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.Assistant Professor') @lang('tr.at') : </span>{{ $instructor->assistant_professor_at }}</div>
                                @endif
                                
                                @if($instructor->teacher_at)
                                    <div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.Teacher') @lang('tr.at') : </span>{{ $instructor->teacher_at }}</div>
                                @endif
                                
                                @if($instructor->teaching_assistant_at)
                                    <div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.Teacher Assistant') @lang('tr.at') : </span>{{ $instructor->teaching_assistant_at }}</div>
                                @endif

                                @if($instructor->demonstrator_at)
                                    <div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.Demonstrator') @lang('tr.at') : </span>{{ $instructor->demonstrator_at }}</div>
                                @endif

                            </div>
                        </div>
                    
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-lg-12">
                    
                        <p style="background: #f7f7f7; color: #007bff; padding: 10px; font-size: 20px; font-weight: bold; text-align: center;">@lang('tr.Academic Info')</p>
                            
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.Email') : </span><a href="mailto:{{ $user->email }}">{{ $user->email }}</a></div>
                                @if($instructor->phd_place != null)<div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.PHD') : </span>{{ $instructor->phd_at }} @lang('tr.from') {{ $instructor->phd_place }}</div>@endif
                                
                                @if($instructor->msc_at != null)<div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.MSC') : </span>{{ $instructor->msc_at }} @lang('tr.from') {{ $instructor->msc_place }}</div>@endif
                                
                                <div class="col-lg-6" style="background: #f7f7f7a6; padding: 10px;  color: black; box-shadow: 0 0 1px 1px #0000000a; margin-bottom: 10px;"><span class="keyText">@lang('tr.Graduation') : </span>
                                        
                                    @if($instructor->graduation_month)
                                        {{ $instructor->graduation_month }} /
                                    @endif

                                    @if($instructor->graduation_year)
                                        {{ $instructor->graduation_year }}
                                    @endif

                                    @if($instructor->lang("university") != null)
                                        @lang('tr.from')

                                        @if($instructor->lang("faculty") != null)
                                            {{ $instructor->lang("faculty") }} ,
                                        @endif

                                        @if($instructor->lang("university") != null)
                                            {{ $instructor->lang("university") }}
                                        @endif
                                    @endif
                                </div>
                            </div>
                        </div>                    
                    </div>
                </div>

                <hr>

                @if($instructor->brief)
                <div class="row">
                
                    <div class="col-lg-12">
                        <p style="background: #f7f7f7; color: #007bff; padding: 10px; font-size: 20px; font-weight: bold; text-align: center;">@lang('tr.Brief')</p>
                        <p style="border: 3px solid #f5f5f5; padding: 10px; box-shadow: 0 0 1px 1px #f7f7f726;">{!! nl2br($instructor->brief) !!}</p>
                    </div>
                
                </div>
                @endif

                @if($instructor->awards)
                <div class="row">
                
                    <div class="col-lg-12">
                        <p style="background: #f7f7f7; color: #007bff; padding: 10px; font-size: 20px; font-weight: bold; text-align: center;">@lang('tr.Awards')</p>
                        <p style="border: 3px solid #f5f5f5; padding: 10px; box-shadow: 0 0 1px 1px #f7f7f726;">{!! nl2br($instructor->awards) !!}</p>
                    </div>
                
                </div>
                @endif

                @if($instructor->books)
                <div class="row">
                
                    <div class="col-lg-12">
                        <p style="background: #f7f7f7; color: #007bff; padding: 10px; font-size: 20px; font-weight: bold; text-align: center;">@lang('tr.Books')</p>
                        <p style="border: 3px solid #f5f5f5; padding: 10px; box-shadow: 0 0 1px 1px #f7f7f726;">{!! nl2br($instructor->books) !!}</p>
                    </div>
                
                </div>
                @endif

                @if($instructor->articles)
                <div class="row">
                
                    <div class="col-lg-12">
                        <p style="background: #f7f7f7; color: #007bff; padding: 10px; font-size: 20px; font-weight: bold; text-align: center;">@lang('tr.Articles')</p>
                        <p style="border: 3px solid #f5f5f5; padding: 10px; box-shadow: 0 0 1px 1px #f7f7f726;">{!! nl2br($instructor->articles) !!}</p>
                    </div>
                
                </div>
                @endif

                @if($instructor->publications)
                <div class="row">
                
                    <div class="col-lg-12">
                        <p style="background: #f7f7f7; color: #007bff; padding: 10px; font-size: 20px; font-weight: bold; text-align: center;">@lang('tr.Publications')</p>
                        <p style="border: 3px solid #f5f5f5; padding: 10px; box-shadow: 0 0 1px 1px #f7f7f726;">{!! nl2br($instructor->publications) !!}</p>
                    </div>
                
                </div>
                @endif

                @if($instructor->research_projects)
                <div class="row">
                
                    <div class="col-lg-12">
                        <p style="background: #f7f7f7; color: #007bff; padding: 10px; font-size: 20px; font-weight: bold; text-align: center;">@lang('tr.Research Projects')</p>
                        <p style="border: 3px solid #f5f5f5; padding: 10px; box-shadow: 0 0 1px 1px #f7f7f726;">{!! nl2br($instructor->research_projects) !!}</p>
                    </div>
                
                </div>
                @endif
                
            </div>

            <div class="col-md-3">
            <div style="margin-top:50px;"></div>
                @include('website.components.news', ['style'=>2])
            </div>
        </div>
    </div>
</section>



@endsection

@section('pagejs')

<script>

// optional
		$('#blogCarousel').carousel({
				interval: 8000
		});

</script>

@endsection


