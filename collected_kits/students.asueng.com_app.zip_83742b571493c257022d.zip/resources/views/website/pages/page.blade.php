@extends('website.layouts.master')

@section('title', $website->title($page))

@section('pagecss')

<style>
.moreTopicsBtn{
    display:none;
}

@media only screen and (max-width: 766px) {
  .moreTopics {
    display:none;
    
  }
  .moreTopicsBtn{
    display:inherit;
}
}
</style>
@endsection

@section('content')

@include('website.layouts.title')
@php($section = $website->section($page))
<section>    

<div class="section-wrapper p-t-40 p-b-20">
      <div class="container">
        <div class="row">
            <div class="col-md-9">
                @if($page->isPage())
                    @include('website.components.page')
                    @include('website.components.other_pages')
                @elseif($website->isComponent($page, "content_type"))
                    @include("website.components.$page->content_type")
                    @php($page=$page->parent)
                @elseif($website->isComponent($page, "short_name"))
                    @include("website.components.$page->short_name")
                    @php($page=$page->parent)
                @else
                    @include('website.components.other_pages')
                @endif
            </div>
            <div class="col-md-3">
                <div class="au-widget">
                    @if($page->isPage() || !$website->isComponent($page))
                        @include('website.components.topics')
                    @endif
                    @include('website.components.news', ['style'=>2])
                </div>
            </div>

        </div>
    </div>
</div>
</section>

@endsection

@section('pagejs')
@endsection
