@extends('website.layouts.master')

@section('title', $website->title($page))

@section('pagecss')

@section('content')

@include('website.layouts.title')
    
<section>
	<div class="section-wrapper p-t-40 p-b-20">
      	<div class="container">
	        <div class="row">
	            <div class="col-md-9">
	                <style type="text/css">
	                    div.page {
	                        font-size: 120%;
	                    }
	                    div.page ul {
	                            list-style: unset; padding-left: 40px;
	                        }
	                    div.page ul > li {
	                        list-style-type: unset;
	                    }
	                    div.page ul > li::before {
	                      color: black;
	                    }
	                    div.page ol {
	                            list-style: unset;
	                            list-style-type: decimal;
	                            padding-left: 40px;
	                        }
	                </style>
	                <div id="section-two" class="page" style="color: black;">
						@php($news = $website->news($page))

						<?php
							if(isset($_GET['search'])){
								$textSearch = $_GET['search'];
								$textSearch = mb_ereg_replace(" ", "%", getFTS($textSearch));
                				$textSearch = mb_ereg_replace("_", "\_", $textSearch);
								$result = $news->childrenPages('created_at', 'DESC')->where(\DB::raw("COALESCE(search_text,'')") , "like", "%$textSearch%")->offset(10*(request()->page-1))->limit(10)->get();
							}else{
								$result = $news->childrenPagesAndFiles('created_at', 'DESC')->offset(10*(request()->page-1))->limit(10)->get();
							}
						?>

						
						@if(count($result) > 0)

						@php($otherLanguage = 'ar')
						@if(app()->getLocale()!="en")
						@php($otherLanguage = 'en')
						@endif

	                    @foreach($result as $item)
	                    @php($orgItem = $item)
	                    @if(empty($item->title))
		                    @php($item = $item->getLocale($otherLanguage))
		                @endif
				        @php($image = $item->getPageImage())
				        <div class="blog blog-style-3">
				            <div class="blog-container">
				                @if($image)
				                <div class="blog-image">
				                    <div class="blog-image-container">
				                        <img src="{{route('download_file', ['id'=>$image->id])}}">
				                    </div>
				                </div>
				                @else
				                <div class="blog-image">
				                	<div class="blog-image-container">
				                		<img id='image' src="{{url('/img/defaultNews.jpg')}}">
				                	</div>
				                </div>
				                @endif
				                @if($item->isFile())
				                <div class="blog-content">
				                    <a href="{{route('download_file', $orgItem)}}" target="_blank" class="blog-content-title">{{ $item->locale->title }}</a>
				                    <p style="color: gray;"><i class="fa fa-calendar-alt"></i>&nbsp;{{ newsDate($item->created_at) }}&nbsp;</p>
				                    <p><a href="{{route('download_file', $orgItem)}}" target="_blank">&nbsp;<i class="fa fa-plus-square"></i>@lang('tr.Download')</a>&nbsp;</p>
				                    <p class="blog-content-text">{{ $item->locale->description }}&nbsp;&nbsp;&nbsp;&nbsp;</p>
				                </div>
				                @else
				                <div class="blog-content">
				                    <a href="{{$website->resolve($orgItem)}}" class="blog-content-title">{{ $item->locale->title }}</a>				                    
				                    <p style="color: gray;"><i class="fa fa-calendar-alt"></i>&nbsp;{{ newsDate($item->created_at) }}&nbsp;</p>
				                    <p><a href="{{$website->resolve($orgItem)}}">&nbsp;<i class="fa fa-plus-square"></i>@lang('tr.Read more')</a>&nbsp;</p>
				                    <p class="blog-content-text" style="text-align: {{left()}}">&nbsp;{{ $item->locale->description }}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
				                </div>
				                @endif
				            </div>
				        </div>
				        <hr>
						@endforeach

						@else

						<h1 style="text-align: center; margin-top: 100px; padding: 20px; font-weight: bold; color: #b3b0b0;"><i class="fas fa-exclamation-triangle"></i><br>@lang('tr.No Results')</h1>

						@endif
				        <nav class="au-panigation">
							@php($url = $website->resolve($page))
							<?php
							if(isset($_GET['search'])){
								$count = ceil($news->childrenPages('created_at', 'DESC')->where('search_text','like',"%".$_GET['search']."%")->count()/10);
							}else{
								$count = ceil($news->childrenPages()->count()/10);
							}
							?>
				        	@php($current = (request()->page)?request()->page:1)
                            <ul>
                            	@if($current>1)
	                            <li>
									<?php
									if(isset($_GET['search'])){
									?>
										<a href="{{$url."?page=".($current-1)."&search=".$_GET['search']}}" class="previous-page"><i class="fa fa-angle-{{left()}}"></i></a>
									<?php
									}else{
									?>
										<a href="{{$url."?page=".($current-1)}}" class="previous-page"><i class="fa fa-angle-{{left()}}"></i></a>
									<?php
									}
									?>
	                            </li>
	                            @endif
                            @php($hasDots=false)
                        	@for($pos=1;$pos<=$count;$pos++)
                    		@if($pos==1 || $pos==$count || ( $pos>=($current-2) && $pos<=($current+2) ) )
                    			@php($hasDots=false)
                    			@if($pos==$current)
                    			<li class="page-current">
                                    <a>{{$pos}}</a>
                                </li>
                    			@else
                                <li>
									<?php
										if(isset($_GET['search'])){
										?>
											<a href="{{$url."?page=".$pos."&search=".$_GET['search']}}">{{$pos}}</a>
										<?php
										}else{
										?>
											<a href="{{$url."?page=".$pos}}">{{$pos}}</a>
										<?php
										}
									?>
                                </li>
                                @endif
                            @elseif(!$hasDots)
                            	@php($hasDots=true)
                            	<li>
	                                <a class="dots">...</a>
	                            </li>
                            @endif
                            @endfor
                            	@if($current<$count)
	                            <li>
									<?php
									if(isset($_GET['search'])){
									?>
									
										<a href="{{$url."?page=".($current+1)."&search=".$_GET['search']}}" class="next-page">
											<i class="fa fa-angle-{{right()}}"></i>
										</a>

									<?php
									}else{
									?>
										<a href="{{$url."?page=".($current+1)}}" class="next-page">
											<i class="fa fa-angle-{{right()}}"></i>
										</a>
									<?php
									}
									?>

	                                
	                            </li>
	                            @endif
                            </ul>
                        </nav>
		            </div>
	            </div>
		        <div class="col-md-3">
		        	<div class="au-widget">
			            @include('website.components.topics')
			            @include('website.components.events')
			        </div>
		        </div>
	        </div>
	    </div>
    </div>
</section>
@endsection

@section('pagejs')

@endsection
