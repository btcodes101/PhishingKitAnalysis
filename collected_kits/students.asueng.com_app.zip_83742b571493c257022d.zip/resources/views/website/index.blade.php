@extends('website.layouts.master')

@section('title', $website->title($website->mainSection))

@section('pagecss')
@endsection

@section('content')

@include('website.layouts.title', ['page'=>$website->mainSection])

@include('website.components.banner')

@include('website.components.announcement')

@include('website.components.flip_sections')

@include('website.components.text_sections')

@include('website.components.scroll_sections')

@include('website.components.check_sections')

@include('website.components.blog')

@include('website.components.partners')

@endsection

@section('pagejs')
@endsection
