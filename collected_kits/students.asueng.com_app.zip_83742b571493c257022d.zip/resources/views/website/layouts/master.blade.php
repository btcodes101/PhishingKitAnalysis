<!doctype html>
<html lang="en">

@include('website.layouts.head')

<body>
<div id="wrapper" class="clearfix">

    @include('website.layouts.header')

    <!-- Loader -->
    <div class="loading">
        <div class="load">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
    <!-- End Pre Loader -->

    <div class="main-content">
        @yield('content')
    </div>

    @include('website.layouts.footer')
</div>
<!-- END: .app-wrap -->

@include('website.layouts.script')

</body>

</html>

<script type="text/javascript">
    setTimeout(function(){
        $('.loading, .load').hide();
    },1000);
</script>
