
    <!-- JQuery -->    
    <script src="/web/vendor/jquery/jquery-ui.min.js"></script>

    <!-- Bootstrap -->
    <script src="/web/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Revolution Banner -->
    <script src="/web/vendor/revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="/web/vendor/revolution/js/jquery.themepunch.revolution.min.js"></script>
    <script src="/web/vendor/revolution/js/extensions/revolution.extension.actions.min.js"></script>
    <script src="/web/vendor/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="/web/vendor/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="/web/vendor/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="/web/vendor/revolution/js/extensions/revolution.extension.migration.min.js"></script>
    <script src="/web/vendor/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <script src="/web/vendor/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
    <script src="/web/vendor/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
    <script src="/web/vendor/revolution/js/extensions/revolution.extension.video.min.js"></script>
    

    <!-- Carousel Slider -->
    <script src="/web/vendor/owlcarousel/dist/owl.carousel.min.js"></script>

    <!-- Theme and Vendor Configuration -->
    <script src="/web/js/theme.min.js"></script>
    <script src="/web/js/config-owl-carousel.min.js"></script>
    <script src="/web/js/config-slider.min.js"></script>

    <script src="/js/factory.js"></script>

    {{--Selectize--}}
    <script src="/js/selectize.js"></script>

@yield('pagejs')
