<header>
        <div class="header-wrapper">
            <!-- Desktop Menu -->
            <div class="header-wrapper-desktop d-none d-lg-block">
                <div class="header">
                    <div class="container">
                        <div class="col-md-12">
                            <div class="q-links">
                                <a href="{{ route('index') }}">@lang('tr.Home')</a>
                                @foreach($website->headerMenu() as $item)
                                    <a href="{{ $website->resolve($item) }}">
                                        {{ shortText($item->locale->title, 15) }}
                                    </a>
                                @endforeach
                                @if (auth()->id())
                                    <a href="{{ route('dashboard') }}">@lang('tr.My Account')</a>
                                @else
                                    <a href="{{ route('login') }}">@lang('tr.Login')</a>
                                @endif

                                @if( Lang::locale() == 'ar' )
                                    <a href="{{urlLocale("en")}}">English</a>
                                @else
                                    <a href="{{urlLocale("ar")}}">عربى</a>
                                @endif

                            </div>
                        </div>
                        <div class="main-header">

                            <div class="main-header-container">
                                @if($website->isHomeSection())
                                <div class="header-logo">
                                    <a href="{{ route('index') }}">
                                        <img src="{{route('download_file', ['id'=>$website->asset('logo')->id])}}">
                                    </a>
                                </div>
                                @else
                                <div style="position: relative;margin-right: auto; ">
                                    <div style="display: inline-block; vertical-align: top;">
                                        <a href="{{ route('index') }}">
                                            <img style="width:75px;" src="{{route('download_file', ['id'=>$website->asset('logo')->id])}}">
                                        </a>
                                    </div>
                                    <div style="display: inline-block; vertical-align: top;">
                                        <div>
                                            <a style="font-size: 200%; color: black; font-weight: bold; vertical-align: middle;" href="{{$website->resolve($website->mainSection)}}">{{$website->mainSection->locale->title}}</a>
                                        </div>
                                        <div style="width: 250px; font-size: 12px;">{{$website->mainSection->locale->sub_title}}</div>
                                </div>
                                </div>
                                @endif
                                <nav class="header-navbar">
                                    <ul class="navbar-menu" id="navbarMainMenu">
                                        @foreach($website->menu() as $item)
                                        <li class="" style="padding: 0 16px;">
                                            <a href="{{ $website->resolve($item) }}">{{ shortText($item->locale->title, 15) }}</a>
                                            @if($item->short_name!="news")
                                            @php($topics = $website->topics($item, 11))
                                            @if(count($topics)>1)
                                            <ul class="sub-menu">
                                                @php($i=0)
                                                @foreach($topics as $topic)
                                                @if($i<10)
                                                <li>
                                                    <a href="{{ $website->resolve($topic) }}">{{ shortText($topic->locale->title, 30) }}</a>
                                                </li>
                                                @else
                                                <li>
                                                    <a href="{{ $website->resolve($item) }}">@lang('tr.More')...</a>
                                                </li>
                                                @endif
                                                @php($i++)
                                                @endforeach
                                            </ul>
                                            @endif
                                            @endif
                                        </li>
                                        @endforeach

                                    </ul>
                                </nav>
                                <style>
                                    @media (max-width: 1200px) and (min-width: 992px){
                                        #navbarMainMenu{
                                                padding: 0 50px !important;
                                                margin-top: 34px !important;
                                                margin-left: 84px !important;
                                                margin-bottom: 23px !important;
                                        }
                                        #navbarMainMenu li a {
                                            line-height: 45px !important;
                                        }
                                    }
                                </style>
                                <div class="header-button">
                                    <div class="header-line">|</div>
                                    <div class="header-search">
                                        <span data-toggle="modal" data-target="#search-modal">
                                            <i class="fa fa-search"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Desktop Menu -->

            <!-- Mobile Menu -->
            <div class="header-wrapper-mobile d-block d-lg-none">
                <div class="header-mobile__bar">
                    <div class="header-mobile__logo">
                        <a href="{{ route('index') }}"> <img src="{{route('download_file', ['id'=>$website->asset('logo')->id])}}" alt="{{$website->value(lang('title'))}}"></a> @if($website->isHomeSection()) <a style="color: black;" href="{{ route('index') }}">{{$website->value(lang('short_title'))}}</a> @else &nbsp; <a style="font-size: 150%; color: black; font-weight: bold; vertical-align: middle;" href="{{$website->resolve($website->mainSection)}}">{{$website->mainSection->locale->title}}</a> @endif
                    </div>
                    <div class="header-mobile__button">
                        <span class="humburger-box">
                            <span class="hamburger__inner"></span>
                        </span>
                    </div>
                </div>
                <nav class="header-mobile__navbar">
                    <ul class="navbar-menu">
                        <li>
                            <a href="{{ route('index') }}">@lang('tr.Home')</a>
                        </li>
                        @foreach($website->menu() as $item)
                            <li>
                                @php($topics = $website->topics($item, 11))
                                @if(count($topics)==0)
                                    <a href="{{ $website->resolve($item) }}">
                                        {{ shortText($item->locale->title, 15)}}
                                    </a>
                                @else
                                    <a href="#">
                                        {{ shortText($item->locale->title, 15)}}
                                    </a>
                                @endif
                                @if($item->short_name!="news")                                
                                    @if(count($topics)>1)
                                    <ul class="sub-menu">
                                    @php($i=0)
                                    @foreach($topics as $topic)
                                        @if($i<10)
                                            <li>
                                                <a href="{{ $website->resolve($topic) }}">{{ shortText($topic->locale->title, 30)}}</a>
                                            </li>
                                        @else
                                            <li>
                                                <a href="{{ $website->resolve($item) }}">@lang('tr.More')...</a>
                                            </li>
                                        @endif
                                        @php($i++)
                                    @endforeach
                                    </ul>
                                    @endif
                                @endif
                            </li>
                        @endforeach
                        @foreach($website->headerMenu() as $item)
                            <li><a href="{{ $website->resolve($item) }}">{{$item->title}}</a></li>
                        @endforeach
                        @if (auth()->id())
                            <li><a href="{{ route('dashboard') }}">@lang('tr.My Account')</a></li>
                            <li><a href="{{ route('logout') }}">@lang('tr.Logout')</a></li>
                        @else
                            <li><a href="{{ route('login') }}">@lang('tr.Login')</a></li>
                        @endif

                        @if( Lang::locale() == 'ar' )
                            <li><a href="{{urlLocale("en")}}">English</a></li>
                        @else
                            <li><a href="{{urlLocale("ar")}}">عربى</a></li>
                        @endif
                    </ul>
                </nav>
            </div>
            <!-- End Mobile Menu -->
        </div>
    </header>
