@if(empty($simple))
    @php($simple = false)
@endif

<style type="text/css">
    @media only screen and (min-width: 900px) {
        div.website_title {
            @if($website->isHomeSection())
            padding-{{left()}}: 225px;
            @endif
        }
    }
    @media only screen and (max-width: 900px) {
        div.website_title {
            text-align: center!important;
        }
    }
</style>

@if($simple)

    <section>
        <div class="section-wrapper bg-gray-2">
            <div class="container">
                <div class="page-title page-title-1" style="background-color: unset!important;">
                    <div class="page-name website_title" style="text-align: {{left()}}">
                        <a href="#">@yield('title')</a>
                    </div>
                    @if(isset($path))
                    <nav aria-label="breadcrumb website_nav" class="page-links">
                        <ol class="breadcrumb">
                            @foreach($path as $item)
                            <li class="breadcrumb-item">
                                <a href="{{$item->link}}">{{$item->title}}</a>
                            </li>
                            @endforeach
                        </ol>
                    </nav>
                    @endif              
                </div>
            </div>
        </div>  
    </section>

@else

    @php($section=$website->section($page))
    @php($parents=$website->parents($page))

    @if(count($parents) && $page->content_type!='mainsection')

    <style type="text/css">
        li.active_title  a {
            color: red!important;
            font-weight: bolder!important;
        }
    </style>
    <section>
        <div class="section-wrapper bg-gray-2">
            <div class="container">
                <div class="page-title page-title-1" style="background-color: unset!important;">
                    <div class="page-name website_title" style="text-align: {{left()}};">
                        <a href="#">
                            {{$section->locale->title}}
                            @if(isset($_GET['search']))
                            <span style="font-size:16px;">- [ @lang('tr.Search') : {{ $_GET['search'] }} ]</span>
                            <a href="{{ strtok($_SERVER["REQUEST_URI"],'?') }}" style="color: #065f9f; font-weight: unset; font-size: 20px;"><i class="fas fa-times-circle"></i></a>
                            @endif
                        </a>
                    </div>
                    <nav aria-label="breadcrumb website_nav" class="page-links">
                        <ol class="breadcrumb">
                            @foreach($parents as $parent)
                            <li class="breadcrumb-item {{($parent->id==$section->id)?'active':''}}">
                                <a href="{{$website->resolve($parent)}}">{{$parent->locale->title}}</a>
                            </li>
                            @endforeach
                        </ol>
                    </nav>
                </div>
            </div>
        </div>  
    </section>
    
    @endif
@endif