<section>
    <div class="section-wrapper py-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    @include('website.components.news')
                </div>
                <div class="col-lg-6">
                    @include('website.components.events')
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Latest Blog -->