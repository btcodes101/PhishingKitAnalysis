@if($banner = $website->banner())
<!-- Slider -->
<section>
    <div class="rev_slider_wrapper">
        <div class="rev_slider" id="slide-1" data-version="5.4.4">
            <ul>
                @foreach($banner->childrenFiles as $slide)
                <li data-transition="fade">
                    <img src="{{route('download_file', ['id'=>$slide->id])}}" class="rev-slidebg">
                </li>
                @endforeach
            </ul>
        </div>
    </div>
</section>
<!-- End Slider -->
@endif