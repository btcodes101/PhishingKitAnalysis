<style type="text/css">
    div.page li {
        font-size: 18px;
    }

    div.page ul, div.page ol {
        padding-top: 18px;
    }    
</style>

<div class="page">
    @php($folder = $website->folder($page))
    
    @if($folder && $folder->id!=$section->id)
        
        @php($topics = $website->topics($folder))                       
        @if(count($topics)>0)
            <h2>{{$page->title}}</h2>
            <hr>
            @foreach($topics as $topic)
                <ul style="list-style: none; padding-left: 0;">
                @if($topic->id!=$page->id)
                    @if($topic->type == 2)
                    <li><a target="_blank" href="{{ route('download_file',$topic->id) }}">{{$topic->locale->title}}</a></li>
                    @else
                    <li><a href="{{ $website->resolve($topic) }}">{{$topic->locale->title}}</a></li>
                    @endif
                @endif
                </ul>
            @endforeach
        @endif
    @endif
</div>