@php($page = $page->findNonEmptyPage())

<style type="text/css">
    div.page div, div.page p, div.page li, div.page strong, div.page a {
        font-size: 18px;
    }

    div.page div, div.page p, div.page ul, div.page ol {
        padding-top: 18px;
    }

    div.page h2, div.page h3, div.page h4, div.page h5, div.page h6 {
        padding-top: 18px;
    }

    div.page ul {
        list-style: square;
    }

    div.page ol {
        list-style: decimal;
    }

    div.page ul ul, div.page ol ul {
        list-style: circle;
    }

    div.page ol ol, div.page ul ol {
        list-style: decimal;
    }

    div.page ul {
        padding-{{($page->language=='en')?"left":"right"}}: 40px;
    }

    table.compact_table {
        width: 100%;
    }

    table.compact_table td, table.compact_table td p, table.compact_table td span, table.compact_table td span span, table.compact_table td span span span {
        padding: 0px!important;
        margin: 0px!important;
        line-height: 1em;
    }
    
</style>
<div class="page" style="color: black;margin-bottom:20px;">
    @if($section->id!=$page->id)
        <h1>{{$page->locale->title}}</h1>
    @endif
    @if($page->isPage())
        <hr>                        
        <div style="margin-top:0px; padding-top:0px; direction: {{($page->language=='en')?"ltr":"rtl"}};text-align: {{($page->language=='en')?"left":"right"}};">
            {!! $page->page() !!}
        </div>                        
    @endif
</div>