@if($data = $website->moduleSections('text-sections'))
<!-- Objectives -->
<section>
    <div class="section-wrapper bg-gray p-t-62 p-b-45">
        <div class="container">
            <div class="section-title">
                <h3>{{$data->module->locale->title}}</h3>
                <div class="title-border m-b-67"></div>
            </div>
            <div class="row">
                @foreach($data->sections as $section)
                <div class="col-md-4 col-sm-6">
                    <div class="iconbox iconbox-style-2">
                        <div class="iconbox-container">
                            <div class="iconbox-image">
                                <a href="#">
                                    <i class="fa fa-check"></i>
                                </a>
                            </div>
                            <div class="iconbox-content">
                                <a href="{{$section->url()}}" class="iconbox-content-heading">{{$section->locale->title}}</a>
                                <div class="icon-content-body">
                                    <p>{{$section->locale->description}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</section>
<!-- Objectives -->
@endif