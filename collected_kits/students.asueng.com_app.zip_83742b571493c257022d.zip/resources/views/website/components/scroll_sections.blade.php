@if($data = $website->moduleSections('scroll-sections'))

<section>
    <div class="section-wrapper bg-black-1 p-t-70 p-b-80">
        <div class="container">
            <div class="section-title section-title-style-1">
                <h3><a href='{{$data->module->url()}}' style="color: white;">{{$data->module->locale->title}}</a></h3>
                <div class="title-border m-b-67"></div>
            </div>
            <div class="owl-carousel js-owl-nav owl-nav-1" data-items="4" data-loop="true" data-responsive='{"0":{"items":"1"},"576":{"items":"2"},"768":{"items":"3"},"992":{"items":"4"}}'>
                @foreach($data->sections as $section)
                <div class="project">
                    <div class="project-container">
                        <div class="project-image">
                            <img src="{{route('download_file', ['id'=>$section->id])}}" alt="Galala Academy">
                        </div>
                        <div class="project-content">
                            <div class="project-content-body">
                                <a href="{{$section->url()}}" class="project-title">{{$section->locale->title}}</a>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</section>

@endif