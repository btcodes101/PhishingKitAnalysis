@if($partners = $website->partners())
<!-- Partner -->
<section>
    <div class="section-wrapper bg-gray-1 py-50">
        <div class="container">
            <div class="owl-carousel" data-responsive='{"0":{"items":"1"},"576":{"items":"2"},"768":{"items":"3"},"992":{"items":"4"},"1200":{"items":"6"}}'>
                @foreach($partners->childrenFiles as $partner)
                <div class="partner">
                    <img src="{{route('secure_download_file')."?sid=".$partner->secret()}}" title="{{$partner->locale->sub_title}}">
                </div>
                @endforeach                
            </div>
        </div>
    </div>
</section>
<!-- End Partner -->
@endif