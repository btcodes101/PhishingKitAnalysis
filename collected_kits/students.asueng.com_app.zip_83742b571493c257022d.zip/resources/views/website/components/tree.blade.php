@if(!isset($level))
	@php($level = 1)
@endif

@if($level==1)
	@foreach($parent->children as $child)
		<div class="thick_header"><h3>{{$child->locale->title}}</h3></div>
		@if($child->isPage()||($child->isFolder() && !empty($child->content_type)))
	        <ul><li><a href="{{ $website->resolve($child) }}">{{$child->locale->title}}</li></ul>
	    @elseif($child->isFile())
	        <ul><li><a href="{{ route('secure_download_file')."?sid=".$child->secret() }}">{{$child->locale->title}}</a></li></ul>
	    @elseif($child->isFolder())    	
	    	@include('website.components.tree', ['parent'=>$child, 'level'=>($level+1)])
	    @endif		
	@endforeach
@else
	<ul>
	@foreach($parent->children as $child)
	    <li>
	    @if($child->isPage()||($child->isFolder() && !empty($child->content_type)))
	        <a href="{{ $website->resolve($child) }}">{{$child->locale->title}}</a>
	    @elseif($child->isFile())
	        <a href="{{ route('secure_download_file')."?sid=".$child->secret() }}">{{$child->locale->title}}</a>
	    @elseif($child->isFolder())    	
	    	{{$child->locale->title}}
	    	@include('website.components.tree', ['parent'=>$child, 'level'=>($level+1)])
	    @endif
	    </li>
	@endforeach
	</ul>
@endif