@if($data = $website->moduleSections('check-sections'))

<section>
    <div class="section-wrapper p-t-62 p-b-95">
        <div class="container">
            <div class="section-title">
                <h3>{{ $data->module->locale->title }}</h3>
                <div class="title-border m-b-46"></div>
            </div>
            <div class="row">
                @if($data->logo)
                <div class="col-lg-6">
                    <div class="video p-t-10">
                        <div class="video-image-thumbnail">
                            <img src="{{route('download_file', ['id'=>$data->logo->id])}}">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 p-r-5">
                @else
                <div class="col-lg-12">
                @endif            
                    @foreach($data->sections as $section)
                    <div class="iconbox iconbox-style-3">
                        <div class="iconbox-container">
                            <div class="iconbox-content">
                                <a href="{{$section->url()}}" class="iconbox-content-heading">
                                    <i class="fa fa-check"></i>{{$section->locale->title}}
                                </a>
                                <div class="iconbox-content-body">{{$section->locale->description}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach                    
                </div>
            </div>
        </div>
    </div>
</section>

@endif