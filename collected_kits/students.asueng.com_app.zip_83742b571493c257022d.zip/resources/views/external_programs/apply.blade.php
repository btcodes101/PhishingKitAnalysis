@extends('layouts.master')
@section('title', __("tr.Apply to UEL"))
@section('titleicon', "icon-cog3" )

@section('content')
	<!-- BEGIN .main-content -->
    <div class="main-content">
        <form method='post' action="{{ route('applyto_external_program') }}" enctype="multipart/form-data">
        {{ csrf_field() }}
        
        <div class="row">
            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header">@lang('tr.Apply to UEL')</div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>@lang('tr.Program')</label>
                            <div class="form-group">
                                {!! Form::select('external_program_id', array(''=>__('tr.Select Program'))+$externalPrograms, $externalProgramID, array('id'=> 'external_program_id', 'class'=>'form-control')) !!}
                            </div>
                        </div>

                    </div>
                </div>
                <hr/>
                @if($externalProgramID)
                <button type="submit" id="btnSubmitRequest" class="btn btn-primary btn-md" style="float: {{right()}}"> @lang('tr.Change')</button>                
                @else
                <button type="submit" id="btnSubmitRequest" class="btn btn-primary btn-md" style="float: {{right()}}"> @lang('tr.Submit')</button>
                @endif
            </div>

        </div>
        <br/>
        <br/>
    </form>
    </div>

    <!-- END: .main-content -->
@endsection

@section('pagejs')
	<script type="text/javascript">		
		$(document).ready(function() {
		});
	</script>
@endsection
