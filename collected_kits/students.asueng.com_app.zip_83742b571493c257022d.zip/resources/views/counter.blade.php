<style media="screen">
    body {
  background: #f5f5f5;
  }
  #timer {
  font-family: Arial, sans-serif;
  font-size: 15px;
  color: #999;
  letter-spacing: -1px;
  text-align: end;
  }
  #timer span {
  font-size: 20px;
  color: #333;
  margin: 0 3px 0 15px;
  }
  #timer span:first-child {
  margin-left: 0;
  }
</style>

<div id="timer">
  <span id="days"></span>@lang('tr.Days')
  <span id="hours"></span>@lang('tr.Hours')
  <span id="minutes"></span>@lang('tr.Minutes')
  <span id="seconds"></span>@lang('tr.Seconds')
</div>



<script>
	var timer;
	var compareDate = new Date();
	timer = setInterval(function() {
		timeBetweenDates(new Date("{{$date}}"));
	}, 1000);

	function dateToYMD(date) {
			var d = date.getDate();
			var m = date.getMonth() + 1; //Month from 0 to 11
			var y = date.getFullYear();
			return '' + y + '-' + (m<=9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d);
	}
	function timeBetweenDates(toDate) {
		var dateEntered = toDate;
		var now = new Date();
		var difference = dateEntered.getTime() - now.getTime();

		if (difference <= 0) {

			// Timer done
			clearInterval(timer);

		} else {

			var seconds = Math.floor(difference / 1000);
			var minutes = Math.floor(seconds / 60);
			var hours = Math.floor(minutes / 60);
			var days = Math.floor(hours / 24);

			hours %= 24;
			minutes %= 60;
			seconds %= 60;

			$("#days").text(days);
			$("#hours").text(hours);
			$("#minutes").text(minutes);
			$("#seconds").text(seconds);
		}
	}
</script>
