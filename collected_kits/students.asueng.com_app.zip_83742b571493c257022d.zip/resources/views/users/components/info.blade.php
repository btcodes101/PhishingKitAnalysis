
<div class="card">
    <div class="card-header">
        @lang('tr.UserInfo') ({{$user->typeTitle()}})
    </div>

    <div class="card-body">
        <table class="table table-striped m-0">
            <tbody>
            <tr>
                <th scope="row" width="150px">@lang('tr.EnglishName')</th>
                <td>{{ $user->en_name }}</td>
            </tr>
            <tr>
                <th scope="row" width="150px">@lang('tr.ArabicName')</th>
                <td style="direction: rtl;">{{ $user->ar_name }}</td>
            </tr>
            <tr>
                <th scope="row">@lang('tr.Email')</th>
                <td style="direction: ltr;">{{ $user->email }}, {{ $user->email_alt }}</td>
            </tr>
            <tr>
                <th scope="row">@lang('tr.Mobile')</th>
                <td>{{ $user->mobile }}, {{ $user->phone }}</td>
            </tr>
            <tr>
                <th scope="row">@lang('tr.Code')</th>
                <td>{{ $user->code }}</td>
            </tr>
            <tr>
                <th scope="row">@lang('tr.National ID')</th>
                <td>{{ $user->national_id }}</td>
            </tr>
            </tbody>
        </table>
    </div>
</div>