@extends('layouts.master')

@section('title', $user->lang('name'))
@section('subtitle', __('tr.UserInfo') )
@section('titleicon', "icon-user")


@section('content')
<div class="main-content">
    @include('users.components.info',['user'=>$user, 'from'=>'users'])
</div>
@endsection

