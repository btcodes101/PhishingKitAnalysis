<!doctype html>
<html lang="en">
@section('title', __('tr.LoginRequest') )
@include('components.head')

<body>

    <style>
            textarea
            {
                resize: none;
                overflow-y: show;
            }
    </style>
        
        <div class="container">
                <div class="login-screen row align-items-center">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <form method="post" action="{{ route('request_login_post') }}" aria-label="{{ __('tr.LoginRequest') }}">
                            {{ csrf_field() }}
                            <div class="login-container">
                                <div class="row no-gutters">
                                    <div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
                                        <div class="login-box">                                
                                            <a href="/login" class="login-logo">
                                                <img src="{{asset('img/asueng-b.png')}}" />
                                            </a>
                                            <h5>SIS Login Issue</h5>
                                            @if(!empty($errors->all()))
                                                <div class="alert alert-danger text-white bg-danger">
                                                    <ul>
                                                        @foreach($errors->all() as $error)
                                                            <li>{{ $error }}</li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                            @endif
                                            <div class="input-group">
                                                <span class="input-group-addon btn" id="email"><i class="icon-account_circle"></i></span>
                                                <input type="email" <?php if(Session::has('error_offical_mail')) { echo 'style="border-color:red;"'; } ?> required class="form-control" id="email" name="email" placeholder="@lang('tr.Personal Email')" value='{{old('email')}}'>
                                            </div>
                                            <br>
                                            <div class="input-group">
                                                <span class="input-group-addon btn" id="code"><i class="icon-sort-numerically"></i></span>
                                                <input type="text" required class="form-control" id="code" name="code" placeholder="@lang('tr.Code')" value="{{old('code')}}">
                                            </div>
                                            <br>
                                            <div class="input-group">
                                                <span class="input-group-addon btn" id="national_id"><i class="icon-v-card"></i></span>
                                                <input type="text" required class="form-control" id="national_id" name="national_id" placeholder="@lang('tr.National ID')" value="{{old('national_id')}}">
                                            </div>
                                            <br>
                                            <div class="input-group">
                                                <span class="input-group-addon btn" id="mobile"><i class="icon-phone4"></i></span>
                                                <input type="text" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" required class="form-control" id="mobile" name="mobile" placeholder="@lang('tr.Mobile')" value="{{old("mobile")}}">
                                            </div>
                                            <br>
                                            <div class="input-group">
                                                <span class="input-group-addon btn" id="mobile"><i class="icon-cog3"></i></span>
                                                <select required class="form-control thick-select" id="action" name="action" placeholder="@lang('tr.Action')">
                                                    <option value="reset" {{(old("action")=="reset")?"selected":""}}>@lang('tr.Reset Password')</option>
                                                    <option value="helpdesk" {{(old("action")=="helpdesk")?"selected":""}}>@lang('tr.Contact Helpdesk')</option>
                                                </select>
                                            </div>
                                            <br>
                                            <div class="input-group" id="message_div">
                                                <span class="input-group-addon btn" id="mobile"><i class="icon-bubble"></i></span>
                                                <textarea name="message" required minlength="5" id="message" cols="30" rows="3"  class="form-control" placeholder="@lang('tr.Message')">{{old("message")}}</textarea>   
                                            </div>

                                            
                                            <div class="actions clearfix">
                                                <button type="submit" class="btn btn-primary" style="width:130px;">@lang('tr.Send')</button>
                                            </div>
                                           
                                        </div>
                                    </div>
                                    <div class="col-xl-8 col-lg-7 col-md-6 col-sm-12">
                                        <div class="login-slider"></div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

@include('components.footer')

@include('components.script')

<script>
    $(document).ready(function(){
        $( "#action" ).change( function() {
            if($(this).val()=="helpdesk") {
                $('#message_div').show();
                $('#message').prop('required', true);
            }
            else {
                $('#message_div').hide();
                $('#message').prop('required', false);
            } 
        });
        $( "#action" ).trigger('change');
    });        
</script>
</body>
</html>
