<!doctype html>
<html lang="en">
@section('title', __('tr.Login') )
@include('components.head')

<body>
<div class="container">
    <div class="login-screen row align-items-center">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <form method="post" action="login" aria-label="{{ __('tr.Login') }}">
                {{ csrf_field() }}
                <div class="login-container">
                    <div class="row no-gutters">
                        <div class="col-xl-5 col-lg-5 col-md-6 col-sm-12">
                            <div class="login-box">                                
                                <a href="/" class="login-logo">
                                    <img src="{{asset('img/asueng-b.png')}}" />
                                </a>
                                <h5 style="text-align: center;">Students Information System (SIS)</h5>
                                <p style="text-align: center;"><strong>(SIS) system is for Undergraduate and Postgraduate Students only.</strong></p>
                                <div class="input-group">
                                    <span class="input-group-addon btn-lg" id="username"><i class="icon-account_circle"></i></span>
                                    <input placeholder="Student Email" id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autofocus>
                                </div>
                                <br>
                                <div class="input-group">
                                    <span class="input-group-addon btn-lg" id="password"><i class="icon-verified_user"></i></span>
                                    <input placeholder="Student Password" id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>
                                </div>

                                @if($errors->getMessages() != [])
                                    &ensp;
                                    <div class="alert alert-danger" style="color: darkred">
                                        {{ $errors->getMessages()['message'][0] }}
                                    </div>
                                @endif

                                <div class="actions clearfix">
                                    <button type="submit" class="btn btn-primary">@lang('tr.Login')</button>
                                </div>
                                <div class="or"></div>
                                <div class="mt-4">
                                    <a href="{{ route('RequestLogin') }}" class="additional-link">@lang("tr.Don't have an Account?") <span>@lang('tr.Request Now')</span></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-7 col-md-6 col-sm-12">
                            <div class="login-slider"></div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

@include('components.footer')

@include('components.script')

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

@if(Session::has('send_success'))
<script type="text/javascript">
    $(window).on('load',function(){
        infoBox('@lang('tr.Your request is submitted successfully').');
    });
</script>
@endif

</body>
</html>