<!doctype html>
<html lang="en">
@section('title', __('tr.Login') )
@include('components.head')

<body>
<div class="container">
    <div class="login-screen row align-items-center">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <!-- BEGIN .main-content -->
                <div class="main-content">
                    <div class="card" style="background:white;">
                        <div class="card-body" style="background:white;">
                            @if($ticket->isExternal())
                                @lang('tr.Feedback ticket of applicant:') <a href="{{ $ticket->externalLink() }}">{{$ticket->externalName()}}</a>
                            @else
                                Issue No. {{ $ticket->id }}<br>
                                {!! $ticket->description !!}
                            @endif
                        </div>
                    </div>
                
                    <div class="card" style="background:white;">
                        <div class="card-body" style="background:white;">
                            <form class="ajax_form" enctype="multipart/form-data" action="{{ route('signInTicketsComment', ['ticket_id'=>$ticket->id]) }}" method="POST">
                                {{ csrf_field() }}
                                <div class="form-group">
                                     <textarea name="comment" required class="form-control" rows="1" placeholder="Write your comment..."></textarea>
                                </div>
                                <div class="row gutters">
                                    <div class="col-3">
                                        <input type="file" class="filestyle" name="attachments[]" data-icon="true" multiple>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <button type="submit" id="send_comment" class="btn btn-primary float-right">Send</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                
                    <div class="card" style="background:white;">
                        <div class="card-body" style="background:white;">
                            <div class="media overflow-scroll">
                                <div class="media-body" id="comments">
                                    @foreach($ticket->messages as $message)
                
                                    <div class="media mt-3">
                                        <div class="mr-3">
                                            <a href="#">
                                                <span class="media-object">
                                                @php($file = ($message->user)?$message->user->archive->findChildByContentType("Personal Photo"):null)
                                                @if($file)
                                                    {{--<img class="ticket_avatar" alt="48x48" src="{{ $file }}">--}}
                                                    <img class="ticket_avatar" alt="48x48" style="width: 60px;" src="/img/user.png">
                                                @else
                                                    <img class="ticket_avatar" alt="48x48" style="width: 60px;" src="/img/user.png">
                                                @endif
                                                </span>
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <h5 class="mt-0 media-heading">
                                                @if($message->user)
                                                    <a style="color: #4266b2" href="#">{{ $message->user->en_name }}</a>
                                                @elseif($ticket->isExternal())
                                                    <a style="color: #4266b2" href="#">{{ $ticket->externalName() }}</a>
                                                @endif
                                                <span class="date" style="border: none;padding: 0px;">{{ $message->createdFrom() }}</span>
                                            </h5>
                                            <p>{{$message->comment}}</p>
                                            <div class="comments-footer clearfix">
                                                @foreach($message->files as $file)
                                                <span>
                                                <i class="icon-file-empty"></i> <a href="{{ route('download_file', ['archive_id'=>$file->id]) }}">{{ $file->name() }}</a>
                                                </span>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                    <div style="display: none;">
                                        <div class="media mt-3" id="comment_template">
                                            <div class="mr-3">
                                                <a href="#">
                                                    <span class="media-object">
                                                        <img class="ticket_avatar" alt="48x48" style="width: 60px;" src="/img/user.png">
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <h5 class="mt-0 media-heading">
                                                    <span class="user_name"></span>
                                                    <span class="date created_from" style="border: none;padding: 0px;"></span>
                                                </h5>
                                                <p class="comment"></p>
                                                <div class="comments-footer clearfix">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="display: none;">
                                        <span id="comment_file_template">
                                            <i class="icon-file-empty"></i> <a></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                
                </div>        
                </script>
        </div>
    </div>
</div>

@include('components.footer')

@include('components.script')

<script type="text/javascript">
    $(document).ready(function() {
        $(".ajax_form").ajaxForm([], function(response){
            var commentElement = $("#comment_template").clone();
            commentElement.attr('id', '');
            commentElement.find('.user_name').text(response.user_name);
            commentElement.find('.created_from').text(response.created_from);
            commentElement.find('.comment').text(response.comment);
                
            for(var i=0;i<response.files_infos.length;i++) {
                var commentFileElement = $("#comment_file_template").clone();
                commentFileElement.find('a').attr('href', response.files_infos[i].url)
                commentFileElement.find('a').text(response.files_infos[i].name)
                commentFileElement.appendTo(commentElement.find('.comments-footer'));
            }
            commentElement.prependTo('#comments');
        });
    });
</script>

</body>

</html>