@extends('layouts.master')

@section('title', __("tr.Help") )
@section('subtitle', __("tr.HelpCenter") )
@section('titleicon', "icon-help" )

@section('content')

<div class="main-content">
	<div class="row gutters">
		<div class="col-xl-12 col-lg-6 col-md-6 col-sm-6">
			<div class="card">
				<div class="card-header">@lang('tr.General Topics')</div>
				<div class="card-body">
					<ul class="stats">
						@can('show_coursefiles')
						<li>
							<span class="icon">
								<i class="icon-help"></i>
							</span>
							<A target="_blank" href="./files/quaity_upload_course_files.pdf">@lang('tr.Quality - Upload course files.')</A>
						</li>
						<li>
							<span class="icon">
								<i class="icon-help"></i>
							</span>
							<A target="_blank" href="./files/quaity_questionnaire_report.pdf">@lang('tr.Quality - Download questionnaire report.')</A>
						</li>
						@endcan

						@can('access_coursefiles')
						<li>
							<span class="icon">
								<i class="icon-help"></i>
							</span>
							<A target="_blank" href="./files/quaity_review_course_files.pdf">@lang('tr.Quality - Review course files.')</A>
						</li>
						@endcan
					</ul>
				</div>
			</div>
		</div>
	</div>

	@hasanyrole('Admin|QA|VICEQA')
	<div class="row gutters">
		<div class="col-xl-12 col-lg-6 col-md-6 col-sm-6">
			<div class="card">
				<div class="card-header">@lang('tr.ManagmentTopics')</div>
				<div class="card-body">
					<ul class="stats">
						@can('edit_coursefiles')
						<li>
							<span class="icon">
								<i class="icon-help"></i>
							</span>
							<A target="_blank" href="./files/quality_management.pdf">@lang('tr.Quality - Management.')</A>
						</li>
						@endcan
					</ul>
				</div>
			</div>
		</div>
	</div>
	@endhasanyrole

</div>
@endsection

@section('pagejs')
@endsection