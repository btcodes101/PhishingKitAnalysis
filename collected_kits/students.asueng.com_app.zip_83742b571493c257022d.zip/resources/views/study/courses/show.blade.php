@extends('layouts.master')

@section('title', $course->lang('name'))
@section('subtitle', __('tr.CourseInfo') )
@section('titleicon', "icon-file-text")

<style>
	.filterHeader>input{
		background:white;
		width:100%;
		border-top:1px solid black;
		padding:5px;
		color:green;
		font-weight:bold;
		margin-top:5px;
	}

	.htDimmed{
		color: gray !important;
		font-weight: bold !important;
	}

</style>

@section('content')
	<div class="main-content">
		<div class="row gutters ComBody">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<div class="card">
					<div class="card-header" role="tab" id="cardheadingOne">
						<a data-toggle="collapse" href="#collapseCardOne" aria-expanded="true" aria-controls="collapseCardOne" class="">
							<span class="icon-media-play"></span> @lang('tr.CourseInfo')&nbsp;({{$course->editStatusLabel()}})
						</a>
						@can('edit_courses')
							<a href="{{ route('edit_course', ['id'=>$course->id]) }}" class="btn stdf-btn  btn-sm float-right">
								<span class="icon-edit"></span> @lang('tr.Edit')
							</a>
						@endcan
					</div>

					<div id="collapseCardOne" class="collapse show" role="tabpanel" aria-labelledby="cardheadingOne" style="">
						<div class="card-body">
							<table class="table table-striped m-0">
								<tbody>
								<tr>
									<th scope="row" width="150px" style="font-size:14px;">@lang('tr.Code')</th>
									<td>{{ $course->code }} (<span dir='rtl'>{{ $course->ar_code }}</span>)</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.EnglishName')</th>
									<td>{{ $course->en_name }}</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.ArabicName')</th>
									<td><div style="direction: rtl" >{{ $course->ar_name }}</div></td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.Term')</th>
									<td>{{ $course->termType() }}</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.Department')</th>
									<td>{{ $course->department->lang('name') }}</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.Bylaw')</th>
									<td>{{ $course->bylaw }}</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.Grades') (W/O/E)</th>
									<td style="direction: ltr">
										@if($course->term_type==0)
											Final [ W( <B>{{ $course->max_final_work }}</B> => @if($course->isCreditHours())M:{{ ($course->max_midterm)?$course->max_midterm:0 }} + A:{{ ($course->max_activities)?$course->max_activities:0 }} + P:{{ ($course->max_practical)?$course->max_practical:0 }} @endif) + O( <B>{{ $course->max_final_oral }}</B> ) + E( <B>{{ $course->max_final_exam }}</B> ) ]
										@else
											First [ W( <B>{{ $course->max_first_work }}</B> ) + O( <B>{{ $course->max_first_oral }}</B> ) + E( <B>{{ $course->max_first_exam }}</B> ) ] + Final [ W( <B>{{ $course->max_final_work }}</B> ) + O( <B>{{ $course->max_final_oral }}</B> ) + F( <B>{{ $course->max_final_exam }}</B> ) )
										@endif
										@if($course->term_type==0)
											- <B>Credit Hours</B> ({{$course->credit_hours}})
										@endif
									</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.Hours') (L/O/W)</th>
									<td style="direction: ltr">
										@if($course->term_type==0)
											Final ( {{ $course->final_lecture }} - {{ $course->
											final_tutorial }} - {{ $course->final_laboratory }} )
										@else
											First ( {{ $course->first_lecture }} - {{ $course->
											first_tutorial }} - {{ $course->first_laboratory }} )
											Final ( {{ $course->final_lecture }} - {{ $course->
											final_tutorial }} - {{ $course->final_laboratory }} )
										@endif
									</td>
								</tr>
								@if(mb_strlen($course->en_describtion)>0)
									<tr>
										<td colspan="2">
											<B>Englis Describtion</B><BR/><BR/>
											{{ $course->en_describtion }}
										</td>
									</tr>
								@endif
								@if(mb_strlen($course->ar_describtion)>0)
									<tr>
										<td colspan="2">
											<B>Arabic Describtion</B><BR/><BR/>
											{{ $course->ar_describtion }}
										</td>
									</tr>
								@endif
								@if(mb_strlen($course->references)>0)
									<tr>
										<td colspan="2">
											<B>@lang('tr.References')</B><BR/><BR/>
											<ul>
												@foreach($course->allReferences() as $reference)
													<li>{{ $reference }}</li>
												@endforeach
											</ul>
										</td>
									</tr>
								@endif
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>

			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<div class="card">
					<div class="card-body">
						<div class="row">
							{{--Course--}}
							<div class="col-md-4">
								<select name="term_id" id="term_id" class="form-control">
									<option value="">@lang('tr.Select Term')</option>
									@foreach($terms as $term)
										<option value="{{ $term->id }}" {{ ($currentTermID == $term->id)?'selected':'' }}>{{ $term->name }}</option>
									@endforeach
								</select>
							</div>

							{{--User--}}
							<div class="col-md-8">
								<select name="plan_id" id="plan_id" class="form-control">
									<option value=''>@lang('tr.selectPlan')</option>
								</select>
							</div>
						</div>
					</div>
				</div>
			</div>

			@can('develop_system')
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
					<div class="card">
						<div class="card-header" role="tab" id="cardheadingTwo">
							<a data-toggle="collapse" href="#collapseCardTwo" aria-expanded="true" aria-controls="collapseCardTwo" class="">
								<span class="icon-media-play"></span> @lang('tr.Course Instructors')
							</a>
						</div>

						<div id="collapseCardTwo" class="collapse show" role="tabpanel" aria-labelledby="cardheadingTwo" style="">
							<div class="card-body">
								<table id="instructors_table" class="table m-0 display" style="width:100%">
									<thead>
									<tr>
										<th>@lang('tr.Name')</th>
										<th>@lang('tr.Phone')</th>
										<th>@lang('tr.Email')</th>
										<th>@lang('tr.Plan')</th>
										<th>@lang('tr.Term')</th>
										<th>@lang('tr.Role')</th>
									</tr>
									</thead>
								</table>
							</div>
						</div>
					</div>
				</div>
		</div>

		<div class="row gutters ComBody">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<div class="no_course_term"></div>
				<div class="card course_student">
					<div class="card-header" role="tab" id="cardheadingThree">
						<a data-toggle="collapse" href="#collapseCardThree" aria-expanded="true" aria-controls="collapseCardThree" class="" style="float:left;width: 14%;">
							<span class="icon-media-play"></span> @lang('tr.Course Students')
						</a>
						<div id='ajax_form_progress_bar' style="background-color: green; width:80%; height:2px; float: left; margin-top: 11px;"></div>
						<div class="float-right" id="online"></div>
					</div>

					<div id="collapseCardThree" class="collapse show" role="tabpanel" aria-labelledby="cardheadingThree" style="">
						<div class="card-body">
							<div class="row gutters">
								<div class="validation_grade"></div>
								<div id="dataTable" class="handsontable"></div>
								<button id="export-file" style="margin-top:10px;" class="intext-btn btn btn-sm btn-success">Download CSV</button>
							</div>
							<br>
							<a href="javascript:void(0)" class="btn btn-primary btn-sm" style="float: right" id="send_to_control">@lang('tr.Send To Control')</a>
							<br>
						</div>
					</div>
				</div>
			</div>
		</div>
		@endcan

	</div>

@endsection

@section('pagejs')
	<script type="text/javascript">

		var course_term = 0; course_term = '{{ $course_term }}';
		var hidden_cols = [0,1,2,3];
		var first_oral_grade,
				first_work_grade,
				first_exam_grade,
				final_work_grade,
				final_exam_grade,
				final_oral_grade,
				std_edit,
				course_edit,
				plan_edit,
				oral_edit,
				work_edit,
				exam_edit = 0;

		var columnsWidths = [];

		if(course_term != 0){

			first_oral_grade = '{{ $course_grade['max_first_oral'] }}';
			first_work_grade = '{{ $course_grade['max_first_work'] }}';
			first_exam_grade = '{{ $course_grade['max_first_exam'] }}';

			final_oral_grade = '{{ $course_grade['max_final_oral'] }}';
			final_work_grade = '{{ $course_grade['max_final_work'] }}';
			final_exam_grade = '{{ $course_grade['max_final_exam'] }}';

			if(first_oral_grade == 0){ hidden_cols.push(8);	}
			if(first_work_grade == 0){ hidden_cols.push(9); }
			if(first_exam_grade == 0){ hidden_cols.push(10);}

			if(final_oral_grade == 0){ hidden_cols.push(5);	}
			if(final_work_grade == 0){ hidden_cols.push(6);	}
			if(final_exam_grade == 0){ hidden_cols.push(7);	}

			var divideBy = 14 - (hidden_cols.length+4);
			var colWidth = (500/divideBy).toFixed(2);
			columnsWidths = [0,0,0,0,250, colWidth, colWidth, colWidth, colWidth, colWidth, colWidth, 100, 80,70];

		}else{

			final_oral_grade = '{{ $course_grade['max_final_oral'] }}';
			final_work_grade = '{{ $course_grade['max_final_work'] }}';
			final_exam_grade = '{{ $course_grade['max_final_exam'] }}';

			if(final_oral_grade == 0){ hidden_cols.push(5);	}
			if(final_work_grade == 0){ hidden_cols.push(6);	}
			if(final_exam_grade == 0){ hidden_cols.push(7);	}
			var divideBy = 11 - (hidden_cols.length+4);
			var colWidth = (500/divideBy).toFixed(2);
			columnsWidths = [80, 80, 80, 80, 250, colWidth, colWidth, colWidth, 100, 80, 70]
		}

		var result = [];
		/* Change badge from online to offline ِand vice versa every time connection is changed */
		window.addEventListener('load', function() {
			var status =  $('#online');
			function updateOnlineStatus(event) {
				var condition = navigator.onLine ?
						$('#online').html('<span class="badge badge-pill badge-success">@lang("tr.Online")</span>'):
						$('#online').html('<span class="badge badge-pill badge-danger">@lang("tr.Offline")</span>');
			}
			window.addEventListener('online',  updateOnlineStatus);
			window.addEventListener('offline', updateOnlineStatus);
		});

		$(function() {
			$('#ajax_form_progress_bar').fadeOut('fast');
			/* Initiate status upon page load */
			var condition = navigator.onLine ?
					$('#online').html('<span class="badge badge-pill badge-success">@lang("tr.Online")</span>') :
					$('#online').html('<span class="badge badge-pill badge-danger">@lang("tr.Offline")</span>');

			var data = [];
			var edit = $("<div/>").dynamicTableEditor({
				editHandler: function(aData, aContext) {
					data.push(JSON.stringify(aContext.row));
					/*
					Add changes to localstorage to submit them while 1 of these 2 conditions (online, interval time)
					is true
					*/
					localStorage.setItem('result',JSON.stringify(data));
					/* Set time to submit or retry to submit changes */
					setInterval(()=>{
						$('#ajax_form_progress_bar').fadeOut('fast');
						if(localStorage.getItem('result') !=[]) {
							$.ajax({
								type: 'post',
								headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
								url: '{{ route('course_grade') }}',
								data: {req: JSON.parse(localStorage.getItem('result'))},
								statusCode: {
									500: function (err) {
										data.push(JSON.stringify(aContext.row));
										$('#ajax_form_progress_bar').fadeIn('slow');
									}
								},
								success: function (data) {
									/* Call function to reload data upon submitting new degrees */
									loadData();
									localStorage.setItem('result', []);
									$('#ajax_form_progress_bar').fadeIn('slow');
									console.log(localStorage.getItem('result'));
								},
								error: function (error) {
									localStorage.setItem('result', []);
								}
							});
						}
					},5000);
					$("#save-data").html("Saving note: <strong>" + aData + "</strong>");
				}
			});

			//Validation
			emptyValidator = function(value, callback) {
				if (!value || 0 === value.length) {
					callback(false);
				} else {
					callback(true);
				}
			};

			if(course_term != 0){
				oralValidation = function(value,callback){
					if (0 === value.length) {
						$('.validation_grade').show();
						$('.validation_grade').html('<p style="color:red;font-weight:bold;">You Should Enter Grade in Oral</p>');
						$('.validation_grade').fadeOut(5000);
						callback(false);
					} else {
						if(value < 0 || value >  first_oral_grade){
							$('.validation_grade').show();
							$('.validation_grade').html('<p style="color:red;font-weight:bold;">Max Grade in Oral is '+first_oral_grade+'</p>');
							$('.validation_grade').fadeOut(5000);
							callback(false);
						}else{
							callback(true);
						}
					}
				};

				workValidation = function(value,callback){
					if (0 === value.length) {
						$('.validation_grade').show();
						$('.validation_grade').html('<p style="color:red;font-weight:bold;">You Should Enter Grade in Work</p>');
						$('.validation_grade').fadeOut(5000);
						callback(false);
					} else {
						if(value < 0 || value > first_work_grade){
							$('.validation_grade').show();
							$('.validation_grade').html('<p style="color:red;font-weight:bold;">Max Grade in Work is '+first_work_grade+'</p>');
							$('.validation_grade').fadeOut(5000);
							//alert('Work should be From 0 To '+first_work_grade);
							callback(false);
						}else{
							callback(true);
						}
					}

				};

				examValidation = function(value,callback){
					if ( 0 === value.length) {
						$('.validation_grade').show();
						$('.validation_grade').html('<p style="color:red;font-weight:bold;">You Should Enter Grade in Exam</p>');
						$('.validation_grade').fadeOut(5000);
						callback(false);
					} else {
						if(value < 0 || value > first_exam_grade){
							$('.validation_grade').show();
							$('.validation_grade').html('<p style="color:red;font-weight:bold;">Max Grade in Exam is '+first_exam_grade+'</p>');
							$('.validation_grade').fadeOut(5000);
							callback(false);
						}else{
							callback(true);
						}
					}

				};

				finaloralValidation = function(value,callback){
					if (0 === value.length) {
						$('.validation_grade').show();
						$('.validation_grade').html('<p style="color:red;font-weight:bold;">You Should Enter Grade in Oral</p>');
						$('.validation_grade').fadeOut(5000);
						callback(false);
					} else {
						if(value < 0 || value >  final_oral_grade){
							$('.validation_grade').show();
							$('.validation_grade').html('<p style="color:red;font-weight:bold;">Max Grade in Oral is '+final_oral_grade+'</p>');
							$('.validation_grade').fadeOut(5000);
							callback(false);
						}else{
							callback(true);
						}
					}
				};

				finalworkValidation = function(value,callback){
					if (0 === value.length) {
						$('.validation_grade').show();
						$('.validation_grade').html('<p style="color:red;font-weight:bold;">You Should Enter Grade in Work</p>');
						$('.validation_grade').fadeOut(5000);
						callback(false);
					} else {
						if(value < 0 || value > final_work_grade){
							$('.validation_grade').show();
							$('.validation_grade').html('<p style="color:red;font-weight:bold;">Max Grade in Work is '+final_work_grade+'</p>');
							$('.validation_grade').fadeOut(5000);
							callback(false);
						}else{
							callback(true);
						}
					}

				};

				finalexamValidation = function(value,callback){
					if ( 0 === value.length) {
						$('.validation_grade').show();
						$('.validation_grade').html('<p style="color:red;font-weight:bold;">You Should Enter Grade in Exam</p>');
						$('.validation_grade').fadeOut(5000);
						callback(false);
					} else {
						if(value < 0 || value > final_exam_grade){
							$('.validation_grade').show();
							$('.validation_grade').html('<p style="color:red;font-weight:bold;">Max Grade in Exam is '+final_exam_grade+'</p>');
							$('.validation_grade').fadeOut(5000);
							callback(false);
						}else{
							callback(true);
						}
					}

				}
			}else{
				oralValidation = function(value,callback){
					if (0 === value.length) {
						$('.validation_grade').show();
						$('.validation_grade').html('<p style="color:red;font-weight:bold;">You Should Enter Grade in Oral</p>');
						$('.validation_grade').fadeOut(5000);
						callback(false);
					} else {
						if(value < 0 || value >  final_oral_grade){
							$('.validation_grade').show();
							$('.validation_grade').html('<p style="color:red;font-weight:bold;">Max Grade in Oral is '+final_oral_grade+'</p>');
							$('.validation_grade').fadeOut(5000);
							callback(false);
						}else{
							callback(true);
						}
					}
				};

				workValidation = function(value,callback){
					if (0 === value.length) {
						$('.validation_grade').show();
						$('.validation_grade').html('<p style="color:red;font-weight:bold;">You Should Enter Grade in Work</p>');
						$('.validation_grade').fadeOut(5000);
						callback(false);
					} else {
						if(value < 0 || value > final_work_grade){
							$('.validation_grade').show();
							$('.validation_grade').html('<p style="color:red;font-weight:bold;">Max Grade in Work is '+final_work_grade+'</p>');
							$('.validation_grade').fadeOut(5000);
							callback(false);
						}else{
							callback(true);
						}
					}
				};

				examValidation = function(value,callback){
					if ( 0 === value.length) {
						$('.validation_grade').show();
						$('.validation_grade').html('<p style="color:red;font-weight:bold;">You Should Enter Grade in Exam</p>');
						$('.validation_grade').fadeOut(5000);
						callback(false);
					} else {
						if(value < 0 || value > final_exam_grade){
							$('.validation_grade').show();
							$('.validation_grade').html('<p style="color:red;font-weight:bold;">Max Grade in Exam is '+final_exam_grade+'</p>');
							$('.validation_grade').fadeOut(5000);
							callback(false);
						}else{
							callback(true);
						}
					}
				}
			}
			//End Validation

			//Search in Excel
			var container1 = document.getElementById('dataTable');

			if(course_term == 0){
				var hot1 = new Handsontable(container1, {
					minCols: 7,
					width: '100%',
					height: 180,
					rowHeaders: true,
					colHeaders: true,
					colWidths: columnsWidths,
					minSpareRows: 0,
					minSpareCols: 0,
					contextMenu: true,
					manualColumnResize: true,
					useFormula: true, // This is the line you are looking for
					colHeaders: ['Student ID', 'Course ID', 'Plan ID', 'Control Status','Student Name','Final Oral','Final Work','Final Exam','Max Total','Total','(%)'],
					columns: [
						{data: 'student_id',readOnly: true},
						{data: 'course_id',readOnly: true},
						{data: 'plan_id',readOnly: true},
						{data: 'control_status',readOnly: true},
						{data: 'student_name',readOnly: true},
						{data: 'final_oral',type: 'numeric',validator: oralValidation, allowInvalid: false,className: "htCenter"},
						{data: 'final_work',type: 'numeric',validator: workValidation, allowInvalid: false,className: "htCenter"},
						{data: 'final_exam',type: 'numeric',validator: examValidation, allowInvalid: false,className: "htCenter"},
						{data: 'max_total',readOnly: true,className: "htCenter"},
						{data: 'total',readOnly: true,className: "htCenter"},
						{data: 'percentage',readOnly: true,type:'numeric'},
					],
					hiddenColumns: {
						columns: hidden_cols,
						indicators: false
					},
					columnSorting: true,
					headerTooltips: {
						rows: true,
						columns: true,
						onlyTrimmed: false
					},
					search: true,
					licenseKey: 'non-commercial-and-evaluation',
					filters: true,
					dropdownMenu: ['filter_by_condition', 'filter_action_bar'],
					afterChange: function (change, source) {
						if(change != null){
							{{-- console.log(hot1.getDataAtRow(change[0][0])); --}}
							std_edit = hot1.getDataAtRow(change[0][0])[0];
							course_edit = hot1.getDataAtRow(change[0][0])[1];
							plan_edit = hot1.getDataAtRow(change[0][0])[2];
							oral_edit = hot1.getDataAtRow(change[0][0])[5];
							work_edit = hot1.getDataAtRow(change[0][0])[6];
							exam_edit = hot1.getDataAtRow(change[0][0])[7];

							$.ajax({

								type: 'post',
								headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
								url: '{{ route('course_grade') }}',
								data:
										'std_id='+std_edit+
										'&course_id='+course_edit+
										'&plan_id='+plan_edit+
										'&oral='+oral_edit+
										'&work='+work_edit+
										'&exam='+exam_edit+
										'&term_course='+course_term
								,
								statusCode: {
									500: function (err) {
										data.push(JSON.stringify(aContext.row));
										$('#ajax_form_progress_bar').fadeIn('slow');
									}
								},
								success: function (data) {
									/* Call function to reload data upon submitting new degrees */
									//loadData();
									{{--  alert(result["oral"]);  --}}
									localStorage.setItem('result', []);
									$('#ajax_form_progress_bar').fadeIn('slow');
									loadData();
									console.log(localStorage.getItem('result'));
								},
								error: function (error) {
									localStorage.setItem('result', []);
								}

							});

						}



					}
				});
			}else{
				var hot1 = new Handsontable(container1, {
					minCols: 7,
					width: '100%',
					height: 180,
					rowHeaders: true,
					colHeaders: true,
					colWidths: columnsWidths,
					minSpareRows: 0,
					minSpareCols: 0,
					contextMenu: true,
					manualColumnResize: true,
					useFormula: true, // This is the line you are looking for
					colHeaders: ['Student ID', 'Course ID', 'Plan ID', 'Control Staus','Student Name','Oral(2)','Work(2)','Exam(2)','Oral(1)','Work(1)','Exam(1)','Max Total','Total','(%)'],
					columns: [
						{data: 'student_id',readOnly: true},
						{data: 'course_id',readOnly: true},
						{data: 'plan_id',readOnly: true},
						{data: 'control_status',readOnly: true},
						{data: 'student_name',readOnly: true},
						{data: 'final_oral',type: 'numeric',validator: finaloralValidation, allowInvalid: false,className: "htCenter"},
						{data: 'final_work',type: 'numeric',validator: finalworkValidation, allowInvalid: false,className: "htCenter"},
						{data: 'final_exam',type: 'numeric',validator: finalexamValidation, allowInvalid: false,className: "htCenter"},
						{data: 'first_oral',type: 'numeric',validator: oralValidation, allowInvalid: false,className: "htCenter"},
						{data: 'first_work',type: 'numeric',validator: workValidation, allowInvalid: false,className: "htCenter"},
						{data: 'first_exam',type: 'numeric',validator: examValidation, allowInvalid: false,className: "htCenter"},
						{data: 'max_total',readOnly: true,className: "htCenter"},
						{data: 'total',readOnly: true,className: "htCenter"},
						{data: 'percentage',readOnly: true,type:'numeric'},
					],
					hiddenColumns: {
						columns: hidden_cols,
						indicators: false
					},
					columnSorting: true,
					headerTooltips: {
						rows: true,
						columns: true,
						onlyTrimmed: false
					},
					search: true,
					licenseKey: 'non-commercial-and-evaluation',
					filters: true,
					dropdownMenu: ['filter_by_condition', 'filter_action_bar'],
					afterChange: function (change, source) {
						if(change != null){
							{{-- console.log(hot1.getDataAtRow(change[0][0])); --}}
							std_edit = hot1.getDataAtRow(change[0][0])[0];
							course_edit = hot1.getDataAtRow(change[0][0])[1];
							plan_edit = hot1.getDataAtRow(change[0][0])[2];
							oral_edit = hot1.getDataAtRow(change[0][0])[5];
							work_edit = hot1.getDataAtRow(change[0][0])[6];
							exam_edit = hot1.getDataAtRow(change[0][0])[7];
							first_oral_edit = hot1.getDataAtRow(change[0][0])[8];
							first_work_edit = hot1.getDataAtRow(change[0][0])[9];
							first_exam_edit = hot1.getDataAtRow(change[0][0])[10];

							$.ajax({

								type: 'post',
								headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
								url: '{{ route('course_grade') }}',
								data:
										'std_id='+std_edit+
										'&course_id='+course_edit+
										'&plan_id='+plan_edit+
										'&oral='+oral_edit+
										'&work='+work_edit+
										'&exam='+exam_edit+
										'&first_oral='+first_oral_edit+
										'&first_work='+first_work_edit+
										'&first_exam='+first_exam_edit+
										'&term_course='+course_term
								,
								statusCode: {
									500: function (err) {
										data.push(JSON.stringify(aContext.row));
										$('#ajax_form_progress_bar').fadeIn('slow');
									}
								},
								success: function (data) {
									/* Call function to reload data upon submitting new degrees */
									//loadData();
									{{--  alert(result["oral"]);  --}}
									localStorage.setItem('result', []);
									$('#ajax_form_progress_bar').fadeIn('slow');
									loadData();
									console.log(localStorage.getItem('result'));
								},
								error: function (error) {
									localStorage.setItem('result', []);
								}

							});

						}
					}
				});
			}

			//Export To Excel
			var button1 = document.getElementById('export-file');
			var exportPlugin1 = hot1.getPlugin('exportFile');

			button1.addEventListener('click', function() {
				exportPlugin1.downloadFile('csv', {
					bom: false,
					columnDelimiter: ',',
					columnHeaders: true,
					exportHiddenColumns: true,
					exportHiddenRows: true,
					fileExtension: 'csv',
					filename: 'Studies_[YYYY]-[MM]-[DD]',
					mimeType: 'text/csv',
					rowDelimiter: '\r\n',
					rowHeaders: true,
				});
			});


			/* Fill table with data */


			function loadData(){
				var termID = $('#term_id').val();
				var planID = $('#plan_id').val();

				var url = `{{ route('show_course',['id'=> $course->id ,'ajax_separator' => 2, 'term_id'=>'selected', 'plan_id'=>'minor'])}}`;
				url = url.replace('selected', termID).replace('&amp;','&').replace('minor', planID).replace('&amp;','&');

				$.ajax({
					type: 'get',
					url: url,
					async: true,
					success: function(data) {
						{{-- console.log(data); --}}
						if(data.data.length == 0){
							$('.course_student').hide();
							$('.no_course_term').html('<h2 style="text-align: center; font-size: 20px; color: white; background: red; padding: 13px; border-radius: 50px; width: 40%; margin-right: auto; margin-left: auto; margin-top: 50px;">No Data is This Course</h2>');
						}else{
							$('.course_student').show();
							$('.no_course_term').hide();
						}
						var condition = '{{ auth()->user()->hasRole('ControlEditor')?'true':'false' }}';
						hot1.loadData(data.data);
						{{-- console.log(data.data); --}}
					}
				});
			}

			/* Call function to load data upon page load */
			$(document).ready(function () {
				$('#term_id').trigger('change');
				loadData();
			});

			$('#term_id').on('change',function () {
				$('#plan_id').find('option').not(':first').remove();

				var termID = $('#term_id').val();
				var getPlansURL = `{{ route('show_course',['id'=> $course->id ,'ajax_separator' => 3, 'term_id'=>'selected'])}}`;
				getPlansURL = getPlansURL.replace('selected', termID).replace('&amp;','&');
				$.ajax({
					type: 'GET',
					url: getPlansURL,
					data: 'data.data',
					success: function (data) {
						// Use jQuery's each to iterate over the opts value
						$.each(data.data, function(i, value) {
							// You will need to alter the below to get the right values from your json object.  Guessing that d.id / d.modelName are columns in your carModels data
							$('#plan_id').append('<option value="' + value.id + '">' + value.minor + ' - ' + value.major + '</option>');
						});
					},
				});
			});

			var table = $('#instructors_table').DataTable({
				processing: true,
				serverSide: true,
				scrollX: true,
				stateSave: false,
				paging: false,
				ordering: false,
				info: false,
				language: dataTableLanguage,
				rowId: 'id',
				"ajax": {
					"url": '{{ route('show_course', ['id' => $course->id,'ajax_separator' => 1]) }}',
					"dataSrc": "data.data",
				},
				"columns": [
					{ "data": "name", "name": "name"},
					{ "data": "mobile", "name": "mobile"},
					{ "data": "email", "name": "email"},
					{ "data": "minor", "name": "minor"},
					{ "data": "term_name", "name": "term_name"},
					{ "data": "role", "name": "role",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							var html = "";
							if(oData.role == 2){
								html = "@lang('tr.Teacher')";
							} else if (oData.role == 3){
								html = "@lang('tr.Examinar Committee')";
							} else if (oData.role == 4) {
								html = "@lang('tr.Teacher Assistant')";
							}
							$(nTd).html(html);
						}
					},
				]
			});

			$(".dataTables_filter").hide();

			$('#term_id, #plan_id').on('change', function () {
				table.columns(0).search($("#term_id").val());
				table.columns(1).search($("#plan_id").val());
				table.draw();
				loadData();
			});
		});
	</script>
@endsection
