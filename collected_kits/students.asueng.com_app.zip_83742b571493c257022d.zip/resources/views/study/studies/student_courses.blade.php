@extends('layouts.master')
@section('title', __("tr.Student Courses"))
@section('titleicon', "icon-people" )

@section('advancedaction')

    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 mt-2">
        <a target="_blank" href="{{route('registration_report')}}" class="btn btn-primary float-right" title="@lang('tr.Print Registration Report')">
            <i class="icon-print"></i>
        </a>
        @if($student->advisor)
        <a style="margin: 0px 5px 0px 5px;" target="_blank" href="{{route('academic_discuss')}}" class="btn btn-primary float-right" title="@lang('tr.Discuss with your advisor')">
            <i class="icon-chat"></i> @lang('tr.Discuss') @if($student->academic_discuss_status==2) <span class="badge badge-pill badge-warning" style="color: white;">1</span> @endif
        </a>
        @endif
    </div>
@stop

@section('content')
    <div class="modal fade" id="sections_modal" tabindex="-1" role="dialog" aria-labelledby="sections_modal_label" aria-hidden="true" style="display: none;">
        <form action="" method="post">
            {{ csrf_field() }}
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="sections_modal_label">@lang('tr.Select Section')</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <select name="section_id" id="section_id" class="form-control">
                                <option value="">@lang('tr.Select Section')</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="ok" class="btn btn-primary">@lang('tr.OK')</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">@lang('tr.Close')</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- BEGIN .main-content -->
    <div class="main-content">
        <div class="row gutters">
            <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
                <div class="row gutters">
                    <div class="col-lg-8 col-md-8 col-xs-8 col-sm-8">
                        <div class="card">
                            <div class="card-body">
                                <strong>{{$student->user->code}}</strong>: <a target="_blank" href="{{route('show_student', ['id'=>$student->id])}}">{{ $student->user->lang('name') }}</a> 
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-2 col-xs-2 col-sm-2">
                        <div class="card">
                            <div class="card-body">
                                @lang('tr.Hours') &nbsp; <span class='badge badge-primary' id="total_credit_hours"></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-2 col-xs-2 col-sm-2">
                        <div class="card">
                            <div class="card-body">
                                @lang('tr.Courses') &nbsp; <span class='badge badge-primary' id="courses_count"></span>
                            </div>
                        </div>
                    </div>
                </div>


                @if($student->isRegistered())
                    <div class="alert alert-success">
                        <i class="icon-tick"></i><strong>@lang('tr.Registered')</strong>: 
                @else
                    <div class="alert alert-warning">
                        <i class="icon-info2"></i><strong>@lang('tr.Not Registered')</strong>: 
                @endif
                        {{$student->plan->name()}} @if($student->last_level)<strong>, @lang('tr.Level')</strong>: {{$student->level->lang('name')}} @endif @if($student->last_term_id), <strong>@lang('tr.Term')</strong>: {{$student->term->lang('name')}} @endif
                    </div>

                @if($student->advisor)
                <div class="alert alert-success">
                    <i class="icon-user-tie"></i><strong>@lang('tr.Advisor')</strong>: <u>{{$student->advisor->lang('name')}}</u>, {{$student->advisor->email}}, {{$student->advisor->instructor->department->lang('name')}}.&nbsp;&nbsp;<b>@lang('tr.Contact Advisor')</b>
                </div>
                @endif

                @if(count($electiveGroups)>0 && $termStage && in_array($termStage->stage_code, ["elective_selection", "late_elective_selection"]) && $termStage->isOpen())
                <div class="card">
                    <div class="card-header">
                        @lang('tr.Elective Courses Selection')
                    </div>
                    <div class="card-body">
                        <form action="{{route('select_elective_studies')}}" method="POST">
                            {{ csrf_field() }}
                            @foreach($electiveGroups as $electiveCommittees)
                            <div class="form-group">
                                <select name="committees_ids[]" class="form-control">
                                    @foreach($electiveCommittees as $committee)
                                    <option value="{{$committee->id}}" {{in_array($committee->id, $selectedCommitteesIDs)?"selected":""}}>{{$committee->course->short_name}} - {{$committee->course->lang('name')}}</option>
                                    @endforeach
                                </select>
                            </div>
                            @endforeach
                            <div class="form-group float-right">                                
                                <button type="submit" class='btn btn-primary'>@lang('tr.Submit')</button>
                            </div>
                        </form>
                    </div>
                </div>
                @endif

                <div class="card">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-header">@lang('tr.Selected Courses')</div>
                        <div class="card-body">
                            <table id="selected_courses" class="hover" style="width:100%">
                                <thead>
                                <tr>
                                    <th width="5%">@lang('tr.Code')</th>
                                    <th width="35%">@lang('tr.Course')</th>
                                    <th width="15%">@lang('tr.Section')</th>
                                    <th width="30%">@lang('tr.Status')</th>
                                    <th width="15%"></th>
                                </tr>
                                </thead>
                            </table>
                        </div>                        
                    </div>
                </div>

                @if($student->advisor)
                <div class="alert alert-primary">
                    <i class="icon-chat"></i><strong>@lang('tr.Hint')!</strong>: @lang('tr.Discuss hint')
                    <a target="_blank" href='{{route('academic_discuss')}}'><span style="margin: 2px;" class="badge badge-primary float-right">@lang('tr.Discuss with your advisor')</span></a>
                </div>
                @endif

                @if($student->isStudiesAddAllowed())
                <div class="card">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-header">@lang('tr.Course Selector')</div>
                        <div class="card-body">
                            <table id="courses_table" class="display" style="width:100%">
                                <thead>
                                <tr>
                                    <th width="5%">@lang('tr.Code')</th>
                                    <th width="45%">@lang('tr.course')</th>
                                    <th width="45%">@lang('tr.Details')</th>
                                    <th width="10%"></th>
                                </tr>
                                </thead>
                            </table>
                        </div>                        
                    </div>
                </div>
                @endif

                @include('students.components.study_grades')

            </div>
        </div>
        <!-- Row end -->
    </div>
    <!-- END: .main-content -->
@endsection

@section('pagejs')
    <script type="text/javascript">
        $(document).ready(function() {

            var showCourseURL = '{{ route('show_course', ['id'=>'#id']) }}';

            var selectedCoursesTable = $('#selected_courses').DataTable({
                paging: false,
                bInfo: false,
                bPaginate: false,
                searching: false,
                processing: true,
                serverSide: true,
                scrollX: true,
                stateSave: false,
                language: dataTableLanguage,
                order: [[ 0, "asc" ]],
                rowId: 'id',
                "ajax": {
                    "url": '{{ route('student_courses', ['type'=>'student_courses']) }}',
                    "dataSrc": "data.data",
                    "complete": function (data, type) {

                        var data = data.responseJSON;

                        $("#total_credit_hours").text(data.total_credit_hours);
                        $("#courses_count").text(data.courses_count);

                        var error = false;
                        if(false && data.total_credit_hours > data.max_credit_hours) {
                            error = true;
                            $("#total_credit_hours").removeClass('badge-primary')
                            $("#total_credit_hours").addClass('badge-danger')

                        } else {
                            $("#total_credit_hours").removeClass('badge-danger')
                            $("#total_credit_hours").addClass('badge-primary')
                        }

                        if(data.courses_count > data.max_courses_count) {
                            error = true;
                            $("#courses_count").removeClass('badge-primary')
                            $("#courses_count").addClass('badge-danger')
                        } else {
                            $("#courses_count").removeClass('badge-danger')
                            $("#courses_count").addClass('badge-primary')
                        }
                    }
                },
                "columns": [
                    { "data": "short_name", "name": "short_name",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var course = $('#'+oData.short_name);
                            var html = "";
                            if(course.length>0) {
                                html = "<a href='#"+oData.short_name+"' class='taken_course'>" + oData.short_name + "<i class='icon-arrow-down-thick'></i></a>";
                            } else {
                                html = oData.short_name;
                            }
                            $(nTd).html(html);
                        }
                    },
                    { "data": "name", "name": "name",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "<a target='_blank' href='" + showCourseURL.replace('#id', oData.id) + "'>" + oData.name + "</a>";
                            html += "<br/><small>CH("+oData.credit_hours+"), Min("+oData.min_total+"), Max("+oData.max_total+")</small>";
                            if(oData.taken_course_id) {
                                html += "<br/><small><b><u>@lang('tr.Instead of')</u></b>: " + "<a href='#"+oData.taken_course_code+"' class='taken_course'>" + oData.taken_course_code + "<i class='icon-arrow-down-thick'></i></a>" + ": " + oData.taken_course_name+"</a><small>";
                            }
                            $(nTd).html(html);
                        }
                    },
                    { "data": "section_id", "name": "section_id", 
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            if(oData.section_id) {
                                if(oData.plan_id!=oData.section_plan_id) {
                                    html += oData.section_plan + ": ";
                                }
                                html += "G"+oData.group_no+"/S"+oData.section_no;
                            }
                            $(nTd).html(html);
                        }
                    },
                    { "data": "status", "name": "status", 
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            
                            if(oData.status&{{'App\Study'::STATUS_WITHDRAWN}}) {
                                html += "<span class='badge badge-pill badge-danger'>withdrawn</span>";
                            }
                            if(oData.status&{{'App\Study'::STATUS_EXCUSED}}) {
                                html += "<span class='badge badge-pill badge-warning'>execused</span>";
                            }
                            if(oData.status&{{'App\Study'::STATUS_REGISTER_REQUEST}}) {
                                html += "<span class='badge badge-bdr-pill badge-success'>register request</span>";
                            }                            
                            if(oData.status&{{'App\Study'::STATUS_ADD_REQUEST}}) {
                                html += "<span class='badge badge-bdr-pill badge-primary'>add request</span>";
                            }
                            if(oData.status&{{'App\Study'::STATUS_DROP_REQUEST}}) {
                                html += "<span class='badge badge-bdr-pill badge-danger'>drop request</span>";
                            }
                            if(oData.status&{{'App\Study'::STATUS_WITHDRAW_REQUEST}}) {
                                html += "<span class='badge badge-bdr-pill badge-danger'>withdraw request</span>";
                            }
                            if(oData.status&{{'App\Study'::STATUS_EXCUSE_REQUEST}}) {
                                html += "<span class='badge badge-bdr-pill badge-warning'>excuse request</span>";
                            }
                            if(oData.status&{{'App\Study'::STATUS_REGISTERED}}) {
                                html += "<span class='badge badge-pill badge-success'>registered</span>";
                            }
                            if(oData.upper_status&{{uword('App\Study'::STATUS_INCOMPLETE)}}) {
                                html += "<span class='badge badge-pill badge-danger'>incomplete</span>";
                            }
                            if(oData.upper_status&{{uword('App\Study'::STATUS_FREEZED)}}) {
                                html += "<span class='badge badge-pill badge-danger'>freezed</span>";
                            }

                            $(nTd).html(html);
                        }
                    },
                    { "data": "id", "name": "id",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";

                            @if($student->isStudiesEditAllowed())
                                if((oData.status&{{'App\Study'::STATUS_REGISTERED}})==0 && oData.has_sections && oData.default_section_id==null) {
                                    html += "<a href='javascript:void(0)' id='edit_section' class='edit_section badge badge-primary'>@lang('tr.Edit')</a>&nbsp;";
                                }
                            @endif

                            @if($student->isStudiesRemoveAllowed())
                                if( (oData.status&{{'App\Study'::STATUS_WITHDRAWN}})==0 && 
                                    (oData.status&{{'App\Study'::STATUS_EXCUSED}})==0
                                    ) {
                                    if((oData.status&{{'App\Study'::STATUS_DROP_REQUEST|'App\Study'::STATUS_WITHDRAW_REQUEST|'App\Study'::STATUS_EXCUSE_REQUEST}})==0) {
                                        if((oData.status&{{'App\Study'::STATUS_REGISTERED}})==0 || '{{$termStage->stage_code}}'=="withdraw" || '{{$termStage->stage_code}}'=="add_drop") {
                                            html += "<a href='javascript:void(0)' id='remove_course' class='remove_course badge badge-danger'>{{$student->stageRemoveTitle()}}</a>&nbsp;";
                                        }
                                    }
                                    else {
                                        html += "<a href='javascript:void(0)' id='undo_course' class='undo_course badge badge-warning'>@lang('tr.Undo')</a>&nbsp;";
                                    }
                                }
                            @endif
                            $(nTd).html("<span class='action-column float-right'>"+html+"</span>");
                        }
                    },
                ]
            });

            var coursesTable = $('#courses_table').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                stateSave: false,
                language: dataTableLanguage,
                order: [[ 0, "asc" ]],
                rowId: 'id',
                "ajax": {
                    "url": '{{ route('student_courses', ['type'=>'all_courses']) }}',
                    "dataSrc": "data.data",
                },
                "columns": [
                    { "data": "short_name", "name": "short_name",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var course = $('#'+oData.short_name);
                            var html = "";
                            if(course.length>0) {
                                html = "<a href='#"+oData.short_name+"' class='taken_course'>" + oData.short_name + "<i class='icon-arrow-down-thick'></i></a>";
                            } else {
                                html = oData.short_name;
                            }
                            $(nTd).html(html);
                        }
                    },
                    { "data": "name", "name": "name",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var name = oData.name;
                            if(oData.plan_id) {
                                name += " ("+oData.plan_short_name+")";
                            }
                            var html = "<a target='_blank' href='" + showCourseURL.replace('#id', oData.id) + "'>"+name+"</a>";
                            $(nTd).html(html);
                        }
                    },
                    { "data": "prerequisites", "name": "prerequisites", 
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            if(!oData.allowed) {
                                html += "Not allowed. Prerequisites: <span class='badge badge-danger'>" + oData.prerequisites + "</span>";
                            }
                            else {
                                html += "<b>Min</b>("+oData.min_total+"), <b>Max</b>("+oData.max_total+"), <b>Credit Hours</b>("+oData.credit_hours+")";
                            }

                            $(nTd).html(html);
                        }
                    },
                    { "data": "id", "name": "id",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";
                            @if($student->isStudiesAddAllowed())
                                if(oData.allowed) {
                                    html += "<a href='javascript:void(0)' id='add_course' class='add_course badge badge-primary'>{{$student->stageAddTitle()}}</a>";
                                }
                            @endif
                            $(nTd).html("<span class='action-column float-right'>"+html+"</span>");
                        }
                    },
                ]
            });

            $(document).on('click', '#undo_course, #remove_course, #edit_section, #add_course', function () {

                var action = $(this).attr('id');
                var data = null;

                if (action === 'remove_course' || action === 'undo_course') {
                    @if($student->isStudiesRemoveAllowed())
                    data = selectedCoursesTable.row($(this).closest('tr')).data();
                    committeeID = data.committee_id;
                    courseAction(action, committeeID);
                    @endif
                } 
                else if (action === 'edit_section'){
                    data = selectedCoursesTable.row($(this).closest('tr')).data();
                    editSection(action, data.committee_id, data.section_id);
                }
                else if (action === 'add_course'){
                    @if($student->isStudiesAddAllowed())
                    data = coursesTable.row($(this).closest('tr')).data();
                    editSection(action, data.committee_id);
                    @endif
                }
            });

            function editSection(action, committeeID, sectionID = null) {

                var sectionsURL = '{{ route('student_sections', ['committee_id'=>'#committee_id']) }}';
                sectionsURL = sectionsURL.replace('#committee_id', committeeID);

                $.ajax({type: 'GET',
                    url: sectionsURL,
                    success: function (response) {
                        if(response.data == 'nosections'||response.data == 'defaultsection') {
                            courseAction(action, committeeID);
                        }
                        else  if(response.data.length==0) {
                            errorBox('@lang('tr.Failed to find an empty section, all section are full.')');
                        }
                        else {
                            var modal = $('#sections_modal');
                            modal.execModal({
                                progressBar: 'progress_bar',
                                progressText: 'progress_text',
                            }, function(){}, function(){}, function(dialog) {

                                $.each(response.data, function(i, value) {
                                    var selected = "";
                                    if(sectionID==value.id)selected = "selected";
                                    dialog.find('#section_id').append('<option '+selected+' value="' + value.id + '">' + value.plan + " : @lang('tr.Group') " + value.group_no + " / @lang('tr.Section') "+ value.section_no + " (" + value.taken + "/" + value.quota + ')</option>');
                                });

                                dialog.find('#ok').click(function(event) {
                                    courseAction(action, committeeID, dialog.find('#section_id').val());
                                    dialog.modal('toggle');
                                });
                            });
                        }
                    }
                });
            }

            function courseAction(action, committeeID = null, sectionID = null) {
                
                var url = '{{ route('student_courses_actions', ['action'=>'#action']) }}';
                var token = "{{ csrf_token() }}";
                url = url.replace('#action', action);
                
                $.post(url, {"_token": token, "committee_id": committeeID, "section_id": sectionID }, function(response) {
                    coursesTable.draw();
                    selectedCoursesTable.draw();                    
                }).fail( function(response) {
                    if (!response.responseJSON.error){
                        errorBox('@lang("tr.Something went wrong, please try again!")')
                    } else {
                        errorBox(response.responseJSON.error);
                    }
                });
            }
        });
    </script>
@endsection