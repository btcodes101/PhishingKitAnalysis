<style>
    table {font-size: 10px;}
    td {border: 1px solid #dddddd;}
</style>
<?php $examsCommittee = $study->exam(); ?>

<!--Student Info-->
<table cellpadding="5">
    <tr style="width: 100%;">
        <td style="width: 18%;">Student Name:</td>
        <td  style="width: 32%;">{{$student->user->en_name}}</td>
        <td  style="width: 22%;">Course:</td>
        <td  style="width: 28%;">{{ $study->course->short_name  }}: {{ $study->course->lang('name') }} ({{$study->term->lang('name')}})</td>
    </tr>
   
    <tr style="width: 100%;"> 
        <td>Student Code:</td>
        <td>{{$student->user->code}}</td>
        <td >Exam Date:</td>
        <td>{{$examsCommittee->examsDate->date()->format('d F Y')}}</td>
    </tr>
         
    <tr style="width: 100%;">
        <td >National ID:</td>
        <td>{{$student->user->national_id}}</td>
        <td >Exam Period:</td>
        <td>{{$examsCommittee->examsDate->periodName($examsCommittee->period)}}</td>
    </tr>
    
    <tr style="width: 100%;">
        <td >Year/Level:</td>
        <td>
            @php
                if($student->level)
                    echo $student->level->en_name;
                else
                    echo $student->year->en_name;
            @endphp
        </td>
        <td >Gate:</td>
        <td>{{$gateName}}</td>
    </tr>
    
    <tr>
        <td >Study Plan:</td>
        <td>{{$student->plan->major()}}, {{$student->plan->minor()}}</td>
        <td>Location - BN - Sector:</td>
        <td>{{$examsCommittee->location->name}} - {{$study->exam_position}} - {{$study->sector()}} </td>
    </tr>
       
</table><br>
<div style="text-align:right;">
    <span>
    ممنوع اصطحاب الهاتف المحمول أو الساعات الذكية أو سماعات البلوتوث داخل اللجان.
    لا يعتد بالQR code إلا ورقيا ولا يسمح
    </span>
    <span>
        بالنسخة الاليكترونية على الهاتف المحمول.
    </span>
</div>
    Mobile Phone, Smart watches, & Bluetooth sets are not allowed inside Exam Halls.
    Only paper printed QR codes are accepted - Electronic versions on mobile phone are not accepted.



