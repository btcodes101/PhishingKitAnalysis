<table cellpadding="5px" width="735px">
    <tr style="width: 100%;">
        <td width="15%" style="font-weight: bold;">Student Name:</td>
        <td>{{$student->user->en_name}}</td>
    </tr>
    <tr style="width: 100%;">
        <td width="15%" style="font-weight: bold;">Student Code:</td>
        <td>{{$student->user->code}}</td>
    </tr>
    <tr style="width: 100%;">
        <td width="15%" style="font-weight: bold;">Official Email:</td>
        <td>{{$student->user->email}}</td>
    </tr>
    <tr>
        <td style="font-weight: bold;">Study Plan:</td>
        <td>{{$student->plan->longName()}}</td>
    </tr>
</table>

<br><br>
<table border="2px" cellpadding="4px">
    <tr style="width: 100%; background-color: lightgray;">
        <th style="width: 15%;text-align: center;">Code</th>
        <th style="width: 45%;text-align: center;">Course Name</th>
        <th style="width: 10%;text-align: center;">Credit Hourse</th>
        <th style="width: 15%;text-align: center;">Marks Min/Max</th>
        <th style="width: 15%;text-align: center;">Group / Section</th>
    </tr>
    @foreach($studies as $study)
    @php($course = $study->course)
    <tr>
        <td style="text-align: center;">{{$course->short_name}}</td>
        <td style="text-align: left;">{{$course->en_name}}</td>
        @if($study->isRegistered())
            <td style="text-align: center;">{{$course->credit_hours}}</td>
            <td style="text-align: center;">{{$course->min_total." / ".$course->max_total}}</td>
            <td style="text-align: center;">@if($study->section_id){{"G".$study->group_no." / S".$study->section_no}} @if($student->last_plan_id!=$study->section_plan_id) {{$study->section_plan_minor}} @endif @endif</td>
        @elseif($study->isWithdrawn())
            <td colspan="3" style="background-color: lightgray;">@lang('tr.withdrawn')</td>
        @elseif($study->isExcused())
            <td colspan="3" style="background-color: lightgray;">@lang('tr.excused')</td>
        @endif
    </tr>
    @endforeach
</table>
