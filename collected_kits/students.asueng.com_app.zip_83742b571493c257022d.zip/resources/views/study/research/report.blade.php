@if($section=="header")
<table>
    <tr>
        <td>
            <table style="text-align: right">
                <tr><th style="text-align: right">جامعة عين شمس</th></tr>
                <tr><th style="text-align: right">كلية الهندسة</th></tr>
                <tr><th style="text-align: right">شئون الدراسات العليا</th></tr>
            </table>
        </td>
        <td style="text-align: center; width:170px;">
            <span style="font-size:16px;">مذكرة</span>
            <h1>للنقل من القيد إلى التسجيل</h1>
        </td>
        <td style="text-align: left; width:100px;">
        </td>
    </tr>
</table>
@elseif($section=="footer")
<table>
    <tr>
        <td style="text-align: right; width: 80%;">{{$user->ar_name}}&nbsp;-&nbsp;<span>{!!digits(date("Y/m/d"))!!}</span></td>
        <td style="text-align: left; width: 20%;">{{$pageNumber}}</td>
    </tr>
</table>
@elseif($section=="main")
@php($research = $student->research)
@php($registrationStage = $research->stage('registration'))
<p><span>بخصوص تسجيل المهندس /</span> <span>{{$student->user->ar_name}}</span>.</p>
<p><span>للحصول على درجة</span> <span>{{$student->plan->ar_minor}}</span>.</p>
<p><span>تقدم سيادته بطلب للكلية للحصول على الدرجة المذكورة وقد وافق مجلس الكلية بجلسة في (@if($registrationStage && $registrationStage->faculty_approval_at)&nbsp;{!!formatDate($registrationStage->faculty_approval_at, "j/n/Y")!!}&nbsp;@else&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;@endif) على قيدة.</span></p>
<p><span>كما وافق السيد الأستاذ الدكتور نائب رئيس الجامعة في (@if($registrationStage && $registrationStage->university_approval_at)&nbsp;{!!formatDate($registrationStage->university_approval_at, "j/n/Y")!!}&nbsp;@else&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;@endif) على قيدة للدرجة المذكورة.</span></p>
<p><span>اسم البحث باللغة العربية:</span></p>
<h1 style="text-align: center;">{{$research->ar_title}}</h1>

<p><span>اسم البحث باللغة الإنجليزية</span></p>
<h3 style="text-align: center;">{{$research->en_title}}</h3>
<p><span>وقد حدد القسم أسماء المشرفين كما يلي:</span></p>
<table cellpadding="5px" width="500px" border="1px">
    <tr style="background-color: gray;">
        <td width="35%">اسم المشرف</td>
        <td width="20%">الوظيفة</td>
        <td width="15%">التوقيع</td>
        <td width="15%">ماجستيير</td>
        <td width="15%">دكتوراة</td>
    </tr>
    @foreach($research->supervisors as $supervisor)
    <tr>
        <td>{{ $supervisor->user->academicName() }}</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    @endforeach
</table>

<p><span>موضوع البحث يقع في خطة القسم للأبحاث في تخصص</span>&nbsp;<span>{{$research->researchPlan->lang('name')}}</span>.</p>

<table cellpadding="5px" width="500px" border="1px">
    <tr style="background-color: gray;">
        <td width="30%">رأي</td>
        <td width="15%">موافق</td>
        <td width="15%">غير موافق</td>
        <td width="20%">التاريخ</td>
        <td width="20%">التوقيع</td>
    </tr>
    <tr>
        <td>مجلس القسم</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>لجنة الدراسات العليا</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>مجلس الكلية</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
</table>
@php($archive = $student->user->archive->findChildByContentType('Research Plan'))
<br pagebreak="true" />
<h2 style="text-align: center;">الملخص باللغة العربية</h2>
<hr/>
<p  style="direction: rtl;">@if($archive) {!! $archive->getLocale('ar')->page() !!}@endif</p>
@elseif($section=="enabstract")
@php($archive = $student->user->archive->findChildByContentType('Research Plan'))
<br pagebreak="true" />
<h2 style="text-align: center;">الملخص باللغة الإنجليزية</h2>
<hr/>
<div style="direction: ltr;">@if($archive) {!! $archive->getLocale('en')->page() !!}@endif</div>
@endif