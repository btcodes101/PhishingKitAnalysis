@extends('layouts.master')

@section('title',  __('tr.My Research Plan') )
@section('titleicon', "icon-lab" )

@section('content')

<!-- BEGIN .main-content -->
<div class="main-content">

    @if($research->isSubmitted() && !$research->isRegistered())
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-warning">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <i class="icon-flash"></i><strong>Announcement!</strong> Dear student, your are not registered yet.
            <br>
            <br><b>First</b>: Make sure, that you provide all research information. Click update to complete the missing information.
            <br><b>Second</b>: Contact one of your supervisors to complete your registeration. The supervisor will (1) locate your registration (using your code) under [Research\Registrations], then (2) review it, then (3) set the supervisors list, and finally (4) approve it.
            <br><b>Third</b>: (1) Print the resgistration form, then (2) provide it to the postgraduate affairs employee. The employee will (3) complete the paper work and finally (4) register the official approval dates.
            <br><b>Finally</b>: Your registartion will be approved.
        </div>
    </div>
    @endif
    
    <div class="card">
        <div class="card-header">                
            @lang('tr.My Research Plan')

            @if($research->isSubmitted())
            <a href="{{route('print_research')}}" class="btn btn-primary btn-sm float-right">
                <span class="icon-print"></span> @lang('tr.Print')</a>
            </a>
            <span class="float-right">&nbsp;</span>
            @endif
            @if(!$research->isRegistered())
            <a href="{{ route('edit_research') }}" class="btn btn-primary btn-sm float-right"> <span class="icon-edit"></span> @lang('tr.Update')</a>
            @endif
        </div>

        <div class="card-body">
            <table class="table table-striped m-0">
                <tbody>

                <tr>
                    <th style="vertical-align: top;">@lang('tr.Status')</th>
                    <td>
                        <ul class="stages">
                        @if($research->isSubmitted())
                        <li class='icon-tick'><strong>@lang('tr.Submitted')</strong> @if($research->submitted_at) @lang('tr.at') <strong>{{$research->submitted_at}}</strong> @endif @if($research->submitted_by) @lang('tr.by') <strong>{{$research->submittedBy->lang('name')}}</strong> @endif</li>
                        @endif
                        <hr>
                        @foreach($research->stages as $stage)
                            <li class='icon-tick' style="line-height: 150%;">
                                <strong>{{$stage->statusLabel()}}</strong> @if($stage->submitted_at) @lang('tr.at') <strong>{{$stage->submitted_at}}</strong>@endif

                                @if($stage->submittedBy)
                                    - @lang('tr.provided by') <strong>{{$stage->submittedBy->academicName()}}</strong> 
                                @endif
                                
                                @if($stage->department_approval_at)
                                    <br/><strong>@lang('tr.Department Approval')</strong> @lang('tr.at') <strong>{{$stage->department_approval_at}}</strong>
                                @endif

                                @if($stage->faculty_approval_at)
                                    , <strong>@lang('tr.Faculty Approval')</strong> @lang('tr.at') <strong>{{$stage->faculty_approval_at}}</strong> 
                                @endif

                                @if($stage->university_approval_at)
                                    , <strong>@lang('tr.University Approval')</strong> @lang('tr.at') <strong>{{$stage->university_approval_at}}</strong> 
                                @endif

                                @if($stage->department_approval_at && $stage->submittedBy)
                                - @lang('tr.provided by') <strong>{{$stage->submittedBy->academicName()}}</strong>                                
                                @endif
                            </li>
                            <hr>
                        @endforeach
                        </ul>
                    </td>
                </tr>
                
                <tr>
                    <th style="width:200px;">@lang('tr.Student Code')</th>
                    <td><a href="{{route('show_student', ['id'=>$student->id])}}">{{ $student->user->code }}</a></td>
                </tr>

                <tr>
                    <th>@lang('tr.Student Name')</th>
                    <td><a href="{{route('show_student', ['id'=>$student->id])}}">{{ $student->user->lang('name') }}</a></td>
                </tr>

                <tr>
                    <th>@lang('tr.Study Plan')</th>
                    <td>{{$student->plan->name()}} @if($student->last_level)<strong>, @lang('tr.Level')</strong>: {{$student->level->lang('name')}} @endif @if($student->last_term_id), <strong>@lang('tr.Term')</strong>: {{$student->term->lang('name')}} @endif</td>
                </tr>

                <tr>
                    <th>@lang('tr.Research Plan')</th>
                    <td>{{ $research->researchPlan->lang('name') }}</td>
                </tr>
                
                <tr>
                    <th>@lang('tr.English Title')</th>
                    <td><span style="direction: ltr;text-align: justify;">{{ $research->en_title }}</td></td>
                </tr>
                
                <tr>
                    <th>@lang('tr.Arabic Title')</th>
                    <td><span style="direction: rtl;text-align: justify;">{{ $research->ar_title }}</span></td>
                </tr>

                <tr>
                    <th>@lang('tr.Supervisors')</th>
                    <td>
                        @foreach($research->supervisors as $supervisor)
                        {{ $supervisor->user->academicName() }}, 
                        @endforeach
                    </td>
                </tr>

                @php($archive = $student->user->archive->findChildByContentType('Research Plan'))
                <tr>
                    <th colspan="2">@lang('tr.English Abstract')</th>
                </tr>
                <tr>
                    <td colspan="2" style="background-color: white;"><div style="direction: ltr;text-align: justify;">@if($archive) {!! $archive->getLocale('en')->page() !!}@endif</div></td>
                </tr>
                
                <tr>
                    <th colspan="2">@lang('tr.Arabic Abstract')</th>
                </tr>
                <tr>
                    <td colspan="2" style="background-color: white;"><div style="direction: rtl;text-align: justify;">@if($archive) {!! $archive->getLocale('ar')->page() !!}@endif</div></td>
                </tr>
                
                </tbody>
            </table>
        </div>
    </div>

</div>
<!-- END: .main-content -->
@endsection

@section('pagejs')
@endsection
