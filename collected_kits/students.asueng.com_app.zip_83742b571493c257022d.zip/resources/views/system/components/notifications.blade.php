@if ($errors->any())
<div class="card">
    <div class="card-body pb-0">
        <div class="filter-box">
            <div class="row">
                @foreach ($errors->all() as $error)
                    <div class="col-md-12">
                        <div class="alert alert-danger" role="alert">
                            {{$error}}
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endif
@if( Session::has('message') )
<div class="card">
    <div class="card-body pb-0">
        <div class="filter-box">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-danger" role="alert">
                    {{ Session::get('message') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endif