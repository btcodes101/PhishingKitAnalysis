@extends('layouts.master')

@section('title', __("tr.Archive"))
@section('subtitle', __("tr.Showarchivecontents"))
@section('titleicon', "icon-tabs-outline" )

@section('content')
<!-- BEGIN .main-content -->
<div class="main-content">
    @include('system.archive.component', ['name'=>'archive1', 'archive'=>$archive, 'readOnly'=>true])
</div>
<!-- END: .main-content --> 
@endsection

