@extends('layouts.master')
@section('title', __("tr.Control"))
@section('titleicon', "icon-cog3" )

@section('content')
<!-- BEGIN .main-content -->
<!-- <div class="main-content">

    <form id="submit_form" action="" method="POST">
		{{ csrf_field() }}
        <div class="row">
            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
            	<div class="card">
					<div class="card-header">@lang('tr.Preferences')</div>
					<div class="card-body">
						<div class="form-group">
                            <select name="bylaw" id="bylaw" class="form-control" required>
                                <option value='2003'>@lang('tr.The students preferences [2003 bylaw]')</option>
                                <option value='2018'>@lang('tr.The students preferences [2018 bylaw]')</option>
                            </select>
                        </div>
					</div>
			    </div>
			    <hr/>
			    <button type="submit" id="submit" class="btn btn-primary btn-md">@lang('tr.Assign the students')<span id="ajax_form_progress_text"></span></button>
			</div>
		</div>        

	</form>

</div> -->
<!-- END: .main-content -->
@endsection

@section('pagejs')
<script type="text/javascript">
    $(document).ready(function () {
        $("#submit_form").submit(function(e){

            e.preventDefault();
            $("#submit").attr("disabled", true);
            var submitUrl = '';//route('apply_preferences')
            $.post(submitUrl, {"_token": '{{ csrf_token() }}', "bylaw": $('#bylaw').val()},
                function (response) {
                    infoBox("@lang('tr.Your request is submitted successfully')", function () {
                        $("#submit").attr("disabled", false);
                    });
            }).fail(function (response) {
                showRepsonseErrors(response);
                $("#submit").attr("disabled", false);
            });
        });
    });
</script>
@endsection