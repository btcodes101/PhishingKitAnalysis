@extends('layouts.master')

@section('title', __('tr.Dashboard') )
@section('subtitle', __('tr.DashboardInfo') )
@section('titleicon', "icon-laptop_windows" )
@section('content')
	<!-- BEGIN .main-content -->
    <div class="main-content">
        @if($user->hasRole('Student'))

            @if($user->student->askForSummerTermDecision())
            <div class="alert alert-warning">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <i class="icon-flash"></i>
                <strong>@lang('tr.Important')!</strong> @lang('tr.Do you want to register courses in summer :year?', ['year' => date('yy')]) 
                <a style="font-size: 12px;border-radius: 5px;" href='javascript:void(0)' class="btn btn-success summer_term_decision" data-decision='1'>@lang('tr.Yes')</a> 
                <a style="font-size: 12px;border-radius: 5px;" href='javascript:void(0)' class="btn btn-danger summer_term_decision"  data-decision='0'>@lang('tr.No')</a>
            </div>
            @endif  
            
            @if($user->student->canApplyToQuestionnaire())
            <div class="alert alert-warning">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <i class="icon-flash"></i><strong>@lang('tr.Important')!</strong> @lang('tr.Questionnaire is open participate now before the deadline.') (<a href='{{route('questionnaire_apply_index')}}' style="text-decoration: underline;">@lang('tr.Apply Now')</a>).
            </div>
            @endif

            @if($user->student->hasGraduationSurvey())
            <div class="alert alert-warning">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <i class="icon-flash"></i><strong>@lang('tr.Important')!</strong> @lang('tr.Graduation Survey is open participate now.') (<a href='{{route('graduation_survey')}}' style="text-decoration: underline;">@lang('tr.Apply Now')</a>).
            </div>
            @endif

            <div class="row gutters">
                <div class="col-md-3">
                    <a href="{{ route('my_courses') }}" class="setting-box">
                        <div class="title">@lang('tr.My Courses')</div>
                        <div class="icon">
                            <span class="icon-file-text"></span>
                        </div>
                    </a>
                </div>
            
                @if($user->student && $user->student->research)
                    <div class="col-md-3">
                        <a href="{{ route('show_research') }}" class="setting-box">
                            <div class="title">@lang('tr.My Research')</div>
                            <div class="icon">
                                <span class="icon-lab"></span>
                            </div>
                        </a>
                    </div>
                @endif

                <div class="col-md-3">
                    <a href="{{ route('my_services') }}" class="setting-box">
                        <div class="title">@lang('tr.My Services')</div>
                        <div class="icon">
                            <span class="icon-cog3"></span>
                        </div>
                    </a>
                </div>

                @can('access_archive')
                    <div class="col-md-3">
                        <a href="{{ route('my_archive') }}" class="setting-box">
                            <div class="title">@lang('tr.My Archive')</div>
                            <div class="icon">
                                <span class="icon-tabs-outline"></span>
                            </div>
                        </a>
                    </div>
                @endcan

                @if($user->student)
                    <div class="col-md-3">
                        <a href="{{ route('show_profile', [$user->id]) }}" class="setting-box">
                            <div class="title">@lang('tr.Profile')</div>
                            <div class="icon">
                                <span class="icon-stack"></span>
                            </div>
                        </a>
                    </div>                    
                @endif  
                @if($user->student)
                    <div class="col-md-3">
                        <a href="{{ route('tickets') }}" class="setting-box">
                            <div class="title">@lang('tr.Tickets')</div>
                            <div class="icon">
                                <span class="icon-chat2"></span>
                            </div>
                        </a>
                    </div>
                @endif  
                
                @if($user->student && !$user->student->isPostgraduate())
                    @can('submit_excuses')
                        <div class="col-md-3">
                            <a href="{{ route('excuses') }}" class="setting-box">
                                <div class="title">@lang('tr.Excuses')</div>
                                <div class="icon">
                                    <span class="icon-files-empty"></span>
                                </div>
                            </a>
                        </div>
                    @endcan
                @endif

                @if($user->student)
                        <div class="col-md-3">
                            <a href="{{ route('trainings') }}" class="setting-box">
                                <div class="title">@lang('tr.Students Training')</div>
                                <div class="icon">
                                    <span class="icon-file-text"></span>
                                </div>
                            </a>
                        </div>
                @endif

                @if($user->student->externalProgramRegisterationState())
                    <div class="col-md-3">
                        <a href="{{ route('show_external_program') }}" class="setting-box">
                            <div class="title">@lang('tr.East London')</div>
                            <div class="icon">
                                <span class="icon-library"></span>
                            </div>
                        </a>
                    </div>
                @endif


                <div class="col-md-3">
                    <a href="{{ route('student_fees') }}" class="setting-box">
                        <div class="title">@lang('tr.Fees')</div>
                        <div class="icon">
                            <span class="icon-coin-pound"></span>
                        </div>
                    </a>
                </div>
            </div>
        @endif
    </div>
    <!-- END: .main-content -->
@endsection

@section('pagejs')
	<script type="text/javascript">		
		$(document).ready(function() {
            $('.summer_term_decision').on('click', function(){

                var url = "{{route('summer_term_decision')}}";
                var decision = $(this).data('decision');
                var submitToken = '{{ csrf_token() }}';
                

                warningBox("Are you sure? " + "@lang('tr.This action could not be reversed.')", function() {
                    
                    $.post(url,{'decision':decision, '_token':submitToken},function(data, status){
                        infoBox(data.msg);
                        window.location.reload();
                    
                    }).fail(function(error) {
                       
                        var err = JSON.parse(error.responseText);
                        var errorTxt = '';
                        $.each(err, function(index, value){
                            errorTxt += value + '<br>';
                        })
                        errorBox(errorTxt);
                    });

                });
            });
		});
	</script>
@endsection
