@extends('layouts.master')

@section('title', $course->lang('name'))
@section('subtitle', __('tr.CourseInfo') )
@section('titleicon', "icon-file-text")

<style>
	.filterHeader>input{
		background:white;
		width:100%;
		border-top:1px solid black;
		padding:5px;
		color:green;
		font-weight:bold;
		margin-top:5px;
	}

	.htDimmed{
		color: gray !important;
		font-weight: bold !important;
	}

</style>

@section('content')
	<div class="main-content">

		@php($isPassFail = $study->committee->isPassFail())

		<!--Dr. Watheq request after Dr. Ibrahim confirmation in 2021/6/4 to show work degrees for non published courses similar to undergraduates-->
		@if($course->getBylaw->type=='undergraduate' || $course->getBylaw->type=='postgraduate' || $study->committee->isPublished())
		{{--  Student Grades Cards  --}}
		<div class="row">			
			@if(!$isPassFail && !$course->project) 
				@foreach($degreesData as $degreeData)
					<div class="col-lg-3"> 
						<div class="card">
							<div class="card-body">
								<div class="stats-widget">
									<div class="stats-widget-header">
										<i class="icon-clipboard2"></i>
									</div>
									<div class="stats-widget-body">
										<ul class="row no-gutters">
											<li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col" style="text-align: left; font-size: 150%;">{{ $degreeData->label }}</li>
											<li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col" style="text-align: right; font-size: 150%;">{{ ($degreeData->degree===null)?'-':$degreeData->degree }} / {{ $degreeData->max_value }}</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				@endforeach
			@endif
			@if($study->committee->isPublished()) 
				<div class="col-lg-3"> 
					<div class="card">
						<div class="card-body">
							<div class="stats-widget">
								@if($study->isGradeFinal())
								<a href="#" class="stats-label" style="color:white;font-weight:bold" data-toggle="tooltip" data-placement="top" title="" data-original-title="Control Status">Final</a>
								@else
								<a href="#" class="stats-label danger" data-toggle="tooltip" data-placement="top" title="" style="color:yellow;font-weight:bold" data-original-title="Control Status">Not Final</a>
								@endif
								<div class="stats-widget-header">
									<i class="icon-clipboard2"></i>
								</div>
								<div class="stats-widget-body">
									<ul class="row no-gutters">
										<li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col" style="text-align: left; font-size: 150%;">
											@lang("tr.Total")
										</li>										
										<li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col" style="text-align: right; font-size: 150%;">{{ $study->displayLatestGrade() }} @if(!$isPassFail) {!!$study->is30ExamFail()?'<font color="red">*</font>':''!!} {!!$study->is48OverFail()?'<font color="red">**</font>':''!!} @endif</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			@endif
			@if($study->committee->isFreezed()) 
				<div class="col-lg-3"> 
					<div class="card">
						<div class="card-body">
							<div class="stats-widget">
								<div class="stats-widget-header">
									<i class="icon-clipboard2"></i>
								</div>
								<div class="stats-widget-body">
									<ul class="row no-gutters">
										<li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col" style="text-align: left; font-size: 150%;">
											@lang("tr.Total")
										</li>										
										<li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col" style="text-align: right; font-size: 150%;">@lang('tr.Freezed')</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			@endif
		</div>
		@endif
		{{--  Student Grades Cards  --}}

		@if($study->committee->isPublished() && $study->is30ExamFail() && !$isPassFail)
		<div class="alert" style="font-size: 130%">
			<font color="red">*</font> the failure because you got less than 30% in the exam.
		</div>
		@endif

		@if($study->committee->isPublished() && $study->is48OverFail() && !$isPassFail)
		<div class="alert" style="font-size: 130%">
			<font color="red">**</font> total percentage is more or equal 48%.
		</div>
		@endif

		{{--  Course Data  --}}		
		<div class="card">
			<div class="card-header">@lang('tr.CourseInfo')</div>
			<div class="card-body">
				<table class="table table-striped m-0">
					<tbody>
					<tr>
						<th scope="row" width="150px">@lang('tr.Code')</th>
						<td>{{ $course->short_name }}</td>
					</tr>
					<tr>
						<th scope="row">@lang('tr.EnglishName')</th>
						<td>{{ $course->en_name }}</td>
					</tr>
					<tr>
						<th scope="row">@lang('tr.ArabicName')</th>
						<td><span style="direction: rtl" >{{ $course->ar_name }}</span></td>
					</tr>
					<tr>
						<th scope="row">@lang('tr.Term')</th>
						<td>{{ $course->termType() }}</td>
					</tr>
					<tr>
						<th scope="row">@lang('tr.Department')</th>
						<td>{{ $course->department->lang('name') }}</td>
					</tr>
					<tr>
						<th scope="row">@lang('tr.Bylaw')</th>
						<td>{{ $course->bylaw }}</td>
					</tr>
					<tr>
						<th scope="row" style="font-size:14px;">@lang('tr.Grades') (W/O/E)</th>
						<td style="direction: ltr">
							<B>Total ( {{ $course->max_total }} ) </B> = 
							@if($course->term_type==0)
								Final [ W( <B>{{ $course->max_final_work }}</B> => @if($course->isCreditHours())M:{{ ($course->max_midterm)?$course->max_midterm:0 }} + A:{{ ($course->max_activities)?$course->max_activities:0 }} + P:{{ ($course->max_practical)?$course->max_practical:0 }} @endif) + O( <B>{{ $course->max_final_oral }}</B> ) + E( <B>{{ $course->max_final_exam }}</B> ) ]
							@else
								First [ W( <B>{{ $course->max_first_work }}</B> ) + O( <B>{{ $course->max_first_oral }}</B> ) + E( <B>{{ $course->max_first_exam }}</B> ) ] + Final [ W( <B>{{ $course->max_final_work }}</B> ) + O( <B>{{ $course->max_final_oral }}</B> ) + F( <B>{{ $course->max_final_exam }}</B> ) )
							@endif
							@if($course->term_type==0)
								- <B>Credit Hours ({{$course->credit_hours}})</B>
							@endif
						</td>
					</tr>
					<tr>
						<th scope="row" style="font-size:14px;">@lang('tr.Hours') (L/O/W)</th>
						<td style="direction: ltr">
							@if($course->term_type==0)
								Final ( {{ $course->final_lecture }} - {{ $course->
								final_tutorial }} - {{ $course->final_laboratory }} )
							@else
								First ( {{ $course->first_lecture }} - {{ $course->
								first_tutorial }} - {{ $course->first_laboratory }} )
								Final ( {{ $course->final_lecture }} - {{ $course->
								final_tutorial }} - {{ $course->final_laboratory }} )
							@endif
						</td>
					</tr>
					@if(mb_strlen($course->en_describtion)>0)
						<tr>
							<td colspan="2">
								<B>Englis Describtion</B><BR/><BR/>
								{{ $course->en_describtion }}
							</td>
						</tr>
					@endif
					@if(mb_strlen($course->ar_describtion)>0)
						<tr>
							<td colspan="2">
								<B>Arabic Describtion</B><BR/><BR/>
								{{ $course->ar_describtion }}
							</td>
						</tr>
					@endif
					@if(mb_strlen($course->references)>0)
						<tr>
							<td colspan="2">
								<B>@lang('tr.References')</B><BR/><BR/>
								<ul>
									@foreach($course->allReferences() as $reference)
										<li>{{ $reference }}</li>
									@endforeach
								</ul>
							</td>
						</tr>
					@endif					
					</tbody>
				</table>
			</div>
		</div>
		{{--  Course Data  --}}

		@if($module)
		@php($moduleSample = $module->sample($study->committee->term->id, $course->id, auth()->id()))
		@php($style = '')
		@php($status = "draft")
		@php($notes = null)
		@if($moduleSample && ($moduleSample->status&'App\ModuleSample'::STATUS_REJECTED))
			@php($style = 'text-decoration: line-through; color:red')
			@php($notes = $moduleSample->notes)
			@php($status = "rejected")
		@elseif($moduleSample && ($moduleSample->status&'App\ModuleSample'::STATUS_ACCEPTED))
			@php($status = "accepted")
			@php($style = 'text-decoration: underline; color:green')
		@elseif($moduleSample)
			@php($notes = $moduleSample->notes)
		@endif
		<div class="card">
			<div class="card-header">East London</div>	
			<div class="card-body">
				@if($notes)
					<div class="alert custom alert-danger">
						<i class="icon-warning2"></i>{{$notes}}
					</div>									
				@endif

				<table class="table table-striped m-0">
					<tbody>
						<tr>
							<th scope="row" width="150px">Module</th>
							<td>{{ $module->code }}: {{ $module->name }}</td>
						</tr>
						<tr>
							<th scope="row">Program</th>
							<td>{{ $module->externalProgram->name }}</td>
						</tr>
						<tr>
							<th scope="row" style="vertical-align: top;">Activites Report</th>
							<td>
								@php($title = $module->genFileName('activities', $study->committee->term, $course->short_name, auth()->user()->code))
								@php($file = $data->activities->findChildByTitle($title))
								@if($file)
								<a target="_blank" style='{{$style}}' href="{{ route('secure_download_file')."?sid=".$file->secret() }}">{{$file->name()}}</a>&nbsp;
									@if($status=='accepted')
										<span class='badge badge-pill badge-success'>@lang('tr.Accepted')</span>
									@elseif($status=='rejected')
										<span class='badge badge-pill badge-danger'>@lang('tr.Rejected')</span>
									@elseif($status=='draft')
										<span class='badge badge-pill badge-warning'>@lang('tr.Under Revision')</span>
									@endif
								@endif
								@if(empty($file) || $status!='accepted')
								<button id="upload_files" type="button" class="btn btn-sm btn-secondary float-{{right()}}" action='{{ route('upload_files', ['id'=>$data->activities->id])."?replace=yes&content_type=activities&title=".$title }}'>@if($file) Update @else Upload @endif<span id="upload_files_progress_text"></span></button>
								@endif
							</td>
						</tr>
					</tbody>
				</table>		
			</div>	
		</div>
		@endif
	</div>
@endsection

@section('pagejs')
<script type="text/javascript">
	$(document).ready(function() {
		@if($module)
		$("#upload_files").uploadFiles({
            token: '{{ csrf_token() }}',
            progressBar: $('#upload_files #upload_files_progress_bar'),
            progressText: $('#upload_files #upload_files_progress_text'),
        },
        function(data) {
        	var url = '{{route('update_module_course', ['module_id'=>$module->id, 'course_id'=>$course->id, 'term_id'=>$study->committee->term_id])}}';
        	$.post(url, {"_token": '{{ csrf_token() }}' }, function(data, status){
                infoBox("done.", function() {
                	location.reload();
                });
            });                
    	});
    	@endif
	});
</script>	
@endsection