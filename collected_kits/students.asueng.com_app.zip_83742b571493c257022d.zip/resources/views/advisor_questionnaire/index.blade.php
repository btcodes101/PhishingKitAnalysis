@extends('layouts.master')

@section('title',  __('tr.Advisor Questionnaires') )
@section('subtitle', __('tr.Questionnaires Information') )
@section('titleicon', "icon-point-of-interest-outline" )

@section('pagecss')
@endsection

@section('content')
    
@php($isOpen = $questionnaireTask->term->isAdvisorQuestionnaireOpen())
@php($disabled = ($isOpen)?"":"disabled")
@php($dir=(lang()=="en")?"left":"right")
@php($idir=(lang()=="ar")?"left":"right")
<div class="main-content">
@if($student->advisor)
<div class="alert alert-warning">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
    <i class="icon-user-tie"></i><strong>@lang('tr.Advisor')</strong>: <u>{{$student->advisor->lang('name')}}</u>, {{$student->advisor->email}}, {{$student->advisor->instructor->department->lang('name')}}.</b>
</div>
  
@endif
<div class="row">
<div class="col-md-10">
<form id="QuestionerForm" action="{{ route('save_advisor_questionnaire') }}" method="POST"> 
    {{-- , ['id'=>$questionnaireTask->id] --}}
        {{ csrf_field() }}
    <section>
        <div class="section-wrapper p-t-37 p-b-33" style="padding:15px;">
            <div class="container">

                @php($count = 1)
                @php($answers = 0)

                @foreach($questionnaire->sections($group) as $section)                   
                    @foreach($questionnaire->questions($group, $section)->get() as $question)

                    <div class="row mb-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                  <h5  style="text-transform: capitalize!important;font-weight:bold;">{{$count}}. {{ $question->lang('question') }}</h5>
                                </div>
                                <div class="card-body" style="padding: 0.50rem;">

                                    @php($required= ($question->required)?"required":"")

                                    <input type="hidden" name="questions_ids[{{$question->id}}]" value="{{$question->id}}">

                                    <input type="hidden" name="answers_ids[{{$question->id}}]" value="0">
                                    
                                    

                                    @if($question->type==1)
                                        @php( $answer = $question->comment($questionnaireTask, $student) )
                                        @php($answers += ($answer)?1:0)

                                        <textarea {{$required}} {{$disabled}} name="answers[{{$question->id}}]" class="form-control inputs" rows="2">{{($answer)?$answer->comment:""}}</textarea>
                                    @else
                                        @php( $answer = $question->answer($questionnaireTask, $student) )
                                        @php($answers += ($answer)?1:0)
                                        <div class="row">
                                        @for($i=1;$i<=5;$i++)
                                        @php($checked = ($answer && $answer->answer==$i)?"checked":"" )
                                        @php($answerText = $question->{"answer$i"} )
                                            @if($answerText)
                                            <div class="col-md-2" style="max-width: 100%;flex: 1.1;">
                                                <label class="input-container">
                                                    <input {{$required}} {{$disabled}} type="radio" name="answers[{{$question->id}}][]" {{$checked}} value="{{$i}}">
                                                    {{ __('tr.'.$question->{"answer$i"}) }}
                                                    <span class="input-checkmark"></span>
                                                </label>
                                            </div>
                                            @endif
                                        @endfor
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    @php($count++)
                    @endforeach
                @endforeach
                

                @if(true)
                <div class="col-md-12">
                    @if($disabled == 'disabled')
                    <p class="btn float-{{$idir}} btn-bggreen waves-effect waves-light" style="background: #adaeaf; color: white; cursor: not-allowed;">{{ ($answers)?__('tr.Update'):__('tr.Submit') }}</p>
                    @else
                    <button type="submit" id="submited"  class="btn float-{{$idir}} btn-bggreen waves-effect waves-light" style="background: #4266b2; color: white;">
                        {{ ($answers)?__('tr.Update'):__('tr.Submit') }}
                    </button>
                    @endif
                </div>
                @endif

                <br><br><br><br>
            </div>
        </div>
    </section>
</form>
</div>
    
<div class="col-md-2">
    <img src="/web/images/person_03.png" style="width: 100%;" class="sticky">
</div>
</div>
</div>
@endsection

@section('pagejs')
@endsection
