@extends('layouts.master')

@section('title', __("tr.Submit Excuse"))
@section('subtitle', __("tr.Submit New Excuse") )
@section('titleicon', "icon-files-empty")

@section('content')
<div class="main-content">
        @if(!empty($errors->all()))
        <div class="alert alert-danger text-white bg-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    
  
    <form method="post" action="{{ route('save_excuse')}}" id="edit_form" enctype="multipart/form-data">
    {{ csrf_field() }}
        <div class="row gutters">
            <div class="col-lg-6 col-xs-12 col-md-12 col-sm-12" >
                <div class="card" >
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-body" >
                                        
                            
                            <div class="form-group">
                                <label>@lang('tr.Excuse Type') <required style="color: red;">*</required></label>
                                {!! Form::select('excuse_type_id', array(''=>__('tr.Select Type'))+$excuse_types, old('excuse_type_id'), array('id'=> 'excuse_type_id', 'class'=>'form-control', 'required'=>'yes')) !!}
                            </div>  
                            
                            <div class="form-group d-none" id='terms_dev' >
                                <label>@lang('tr.Term') <required style="color: red;">*</required></label>
                                <select name="term_id" id="term_id" class="form-control" disabled>
                                    <option value="">@lang('tr.Select Term')</option>
                                    @foreach($terms as $key => $value)
                                        <option value="{{$key}}" <?php if(old('term_id') == $key) echo 'selected';?> >{{$value}}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group d-none" id='years_dev'>
                                <label>@lang('tr.Year') <required style="color: red;">*</required></label>
                                <select name="term_id" id="year" class="form-control" disabled>
                                    <option value="">@lang('tr.Select Year')</option>
                                    @foreach($years as $key => $value)
                                        <option value="{{$key}}" <?php if(old('term_id') == $key) echo 'selected';?> >{{$value}}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group d-none" id='courses_dev'>
                                <label>@lang('tr.Courses') 
                                    <required style="color: red;">* <small style="font-style: italic;">Please press Ctrl to select more than one course.</small> </required>
                                </label>
                                <select name="courses_ids[]" id="courses_ids" class="form-control" multiple disabled>
                                   
                                </select>
                            </div>

                            <div class="form-group d-none" id='from_dev'>
                                <label>@lang('tr.From') <required style="color: red;">*</required></label>
                                <input type="date" class="form-control" id='from' name='period_from' value="{{old('period_from')}}" disabled>
                            </div>

                            <div class="form-group d-none" id='to_dev'>
                                <label>@lang('tr.To') <required style="color: red;">*</required></label>
                                <input type="date" class="form-control" id='to' name='period_to' value="{{old('period_to')}}" disabled>
                            </div>

                            
                            <div class="form-group">
                                <label>@lang('tr.Excuse Reasons') <required style="color: red;">*</required></label>
                                <textarea required name="reasons" id="reasons" class="form-control" placeholder="@lang('tr.Excuse Reasons')" cols="30" rows="5" title="Excuse Reasons" >{{ old('reasons') }}</textarea>
                            </div>
                            <div class="form-group">
                                <input required type="file" class="filestyle" name="attachments[]" data-icon="true" multiple>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row gutters">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary btn-md">
                <span class="icon-edit"></span> Submit</button>
            </div>
        </div>

        <hr/>
    </form>
</div>
@endsection

@section('pagejs')
<script type="text/javascript">
    $(document).ready(function() {
         
        $('#excuse_type_id').on('change', function(){

            var excuse_type_id = $('#excuse_type_id').val();

            if(excuse_type_id != ''){

                $('#from_dev').addClass('d-none');
                $('#to_dev').addClass('d-none');
                $('#terms_dev').addClass('d-none');
                $('#courses_dev').addClass('d-none');
                $('#years_dev').addClass('d-none');

                $('#from').prop('disabled', true);
                $('#to').prop('disabled', true);
                $('#term_id').prop('disabled', true);
                $('#year').prop('disabled', true);
                $('#courses_ids').prop('disabled', true);

               
                if(excuse_type_id == 1){ //Study period

                    $('#from_dev').removeClass('d-none');
                    $('#to_dev').removeClass('d-none');
                    $('#terms_dev').removeClass('d-none');

                    $('#from').removeAttr('disabled');
                    $('#to').removeAttr('disabled');
                    $('#term_id').removeAttr('disabled');

                    $('#from').prop('required', true);
                    $('#to').prop('required', true);
                    $('#term_id').prop('required', true);


                }else if(excuse_type_id == 2 || excuse_type_id == 3 || excuse_type_id == 4 || excuse_type_id == 7 || excuse_type_id == 8){ //Mid-term exam, Lab exam, Final exam (course/s), course/s, Corona Case

                    $('#courses_dev').removeClass('d-none');
                    $('#terms_dev').removeClass('d-none');

                    $('#courses_ids').removeAttr('disabled');
                    $('#term_id').removeAttr('disabled');

                    $('#courses_ids').prop('required', true);
                    $('#term_id').prop('required', true);

                }else if(excuse_type_id == 5){ //One semester

                    $('#terms_dev').removeClass('d-none');

                    $('#term_id').removeAttr('disabled');

                    $('#term_id').prop('required', true);
                    
                }else if(excuse_type_id == 6){ //One academic year

                    $('#years_dev').removeClass('d-none');

                    $('#year').removeAttr('disabled');

                    $('#year').prop('required', true);
                }
            }else{
                //console.log('Changed but empty');
            }
            
        });

        $('#excuse_type_id').trigger("change");


        var url = '{{route('get_term_courses')}}';
        $('#term_id').on('change', function(){
            $.post(url, {"_token": '{{ csrf_token() }}', "term_id": $(this).val()}, function(data, status){
                
                $('#courses_ids').empty()
                $.each(data, function(index, val) {
                    $('#courses_ids').append('<option value='+index+'>'+val+'</option>');
                });
             
            }).fail(function(error) {
                errorBox('Something wrong, please try again later.');
            });
        });
    });
</script>
@endsection