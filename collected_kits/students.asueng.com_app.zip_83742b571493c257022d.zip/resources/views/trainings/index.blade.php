@extends('layouts.master')
@section('title', __("tr.Student Trainings"))
@section('titleicon', "icon-file-text" )

@section('content')
	<!-- BEGIN .main-content -->
    <div class="main-content">
        
        <div class="row gutters">
            <div class="col-xl-12 col-lg-6 col-md-6 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <ul class="stats">
                            <li>
                                <span class="icon">
                                    <i class="icon-file-text"></i>
                                </span>
                                <A href="{{ route('studentstrainings') }}">@lang('tr.Available Trainings')</A>
                            </li>
                            @can('develope_system')
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-file-text"></i>
                                </span>
                                <A href="{{ route('create_training_request') }}">@lang('tr.Submit Training Request')</A>
                            </li> 
                            @endcan
                            <hr>
                            <li>
                                <span class="icon">
                                    <i class="icon-file-text"></i>
                                </span>
                                <A href="{{ route('my_trainings') }}">@lang('tr.My Trainings')</A>
                            </li>
                             

                        </ul>
                    </div>
                </div>
            </div>
        </div>
         
    </div>
    <!-- END: .main-content -->
@endsection


