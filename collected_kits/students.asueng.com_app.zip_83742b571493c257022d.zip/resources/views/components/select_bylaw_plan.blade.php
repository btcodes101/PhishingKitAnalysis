<div class="col-md-2">
    <select id="search_bylaw" name="search_bylaw" class=''>
        <option value="">@lang('tr.Select Bylaw')</option>
        @foreach($bylaws as $bylaw)
        <option value="{{ $bylaw->code }}">{{ $bylaw->lang('name') }}</option>
        @endforeach
    </select>
</div>

<div class="col-md-4">
    <select id="search_plan_id" name="search_plan_id" class=''>
        <option value="">@lang('tr.Select Study Plan')</option>
    </select> 
</div>

<script type="text/javascript">
    $(document).ready(function() {
        var submitToken = '{{ csrf_token() }}';
        var plansURL = '{{ route('studies_bylaws_plans', ['bylaw'=>'#id']) }}';
        $('#search_bylaw').autoFill($('#search_plan_id'), plansURL, submitToken, null);
    });
</script>