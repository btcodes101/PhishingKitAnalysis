<!-- BEGIN .main-heading -->
<header class="main-heading">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                <div class="page-icon">
                    <i class="@yield('titleicon')"></i>
                </div>
                <div class="page-title">
                    <h5>@yield('title')</h5>
                    <h6 class="sub-heading">@yield('subtitle')</h6>
                </div>
            </div>
            @if (trim($__env->yieldContent('actiontitle')))
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 ddd">
                <div class="right-actions">
                    <a href="@yield('actionlink')" class="btn btn-primary float-right" data-target="@yield('dataTarget')" data-toggle="@yield('dataToggle')" >
                        <i class="@yield('actionicon')"></i> @yield('actiontitle')
                    </a>
                </div>
            </div>
            @endif
            @yield('advancedaction')
        </div>
    </div>
</header>
<!-- END: .main-heading -->