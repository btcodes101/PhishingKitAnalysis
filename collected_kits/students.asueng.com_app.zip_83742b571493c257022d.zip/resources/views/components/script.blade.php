<script type="text/javascript">
	var dataTableLanguage = {
	    "lengthMenu": "@lang('tr.DataTablePages')",
	    "search": "@lang('tr.DataTableSearch')",
	    "info": "@lang('tr.DataTableInfo')",
	    "infoEmpty": "@lang('tr.DataTableNoRecord')",
	    "infoFiltered": "@lang('tr.DataTableFiltered')",
	    "loadingRecords": "@lang('tr.DataTableLoading')",
	    "processing": "@lang('tr.DataTableProcessing')",
	    "zeroRecords": "@lang('tr.DataTableZeroRecord')",
	    "paginate": {
	        "first": "@lang('tr.DataTableFirst')",
	        "last": "@lang('tr.DataTableLast')",
	        "next": "@lang('tr.DataTableNext')",
	        "previous": "@lang('tr.DataTablePrevious')",
	    },
	};

	// Loading
	$(function () {
		$(".loading-wrapper").fadeOut(500);
	});
</script>

<script src="/js/sweetalaert.js"></script>
<script src="/js/factory.js?1"></script>

<script src="/js/tether.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/vendor/unifyMenu/unifyMenu.js"></script>
<script src="/vendor/slimscroll/slimscroll.min.js"></script>
<script src="/vendor/onoffcanvas/onoffcanvas.js"></script>
<script src="/js/moment.js"></script>
<script src="/js/bloodhound.js"></script>
<script src="/js/bloodhound.min.js"></script>
<script src="/js/typeahead.jquery.min.js"></script>
<script src="/js/typeahead.jquery.js"></script>
<script src="/js/typeahead.bundle.js"></script>
<script src="/js/typeahead.bundle.min.js"></script>

<!-- Datatables JS -->
<script src="/js/jquery.dataTables.min.js"></script>
<script src="/js/dataTables.responsive.min.js"></script>
<script src="/js/dataTables.rowReorder.min.js"></script>
<script src="/js/dataTables.fixedColumns.min.js"></script>

<script type="text/javascript" src="/vendor/jquery-ui/jquery-ui.js"></script>
<script type="text/javascript" src="/js/moment.js"></script>
<script type="text/javascript" src="/js/dynamic-table.jquery.js"></script>
<script type="text/javascript" src="/js/dynamic-table-editor.jquery.js"></script>

<!-- Upload files -->
<script src="/js/jquery.fileuploader.js"></script>

<!-- Chosen Select JS -->
<script src="/js/chosen.jquery.js"></script>

<!-- Selectize JS -->
<script src="/js/selectize.js" charset='UTF-8'></script>

<!-- Summernote IS -->
<script src="/js/summernote.js"></script>

<script src="/js/jquery-confirm.js"></script>

<script src="/js/common.js"></script>
<script src="/js/printThis.js"></script>

{{--Handsontable--}}
<script src="/js/handsontable.full.min.js"></script>
<script src="{{ asset('js/numeral.sv-se.js') }}"></script>

<script src="/vendor/chartist/js/chartist.min.js"></script>
<script src="/vendor/chartist/js/chartist-tooltip.js"></script>

<script src="/vendor/ckeditor/ckeditor.js"></script>
<script src="/vendor/ckeditor/adapters/jquery.js"></script>

<script src="/vendor/ckfinder/ckfinder.js"></script>

@yield('js')
