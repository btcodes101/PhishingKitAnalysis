<header class="app-header">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8">
                <a href="{{ route('home') }}" class="logo">
                    <img src="/img/asueng.png" alt="ASUENG Dashboard">
                </a>
                <a class="mini-nav-btn" href="#app-side" id="app-side-mini-toggler">
                    <i class="icon-sort"></i>
                </a>
                <a href="#app-side" data-toggle="onoffcanvas" class="onoffcanvas-toggler" aria-expanded="false">
                    <i class="icon-chevron-thin-left"></i>
                </a>
                @if(!Auth::user()->hasRole('Guest'))
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ route('dashboard') }}">
                            <i class="icon-home6"></i>
                        </a>
                    </li>
                    @foreach($path as $part)
                    <li class="breadcrumb-item">
                        <a href="{{ $part->link }}">{{ shortText($part->title, 32) }}</a>&nbsp;
                    </li>
                    @endforeach
                    <li class="breadcrumb-item active">&nbsp; {{ shortText($__env->yieldContent('title'), 32) }} </li>
                </ol>
                @endif
            </div>

            
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4">
                <ul class="header-actions">
                    @if(!Auth::user()->hasRole('Guest'))
                    <li class="imp-notify">
                        @if( Lang::locale() == 'ar' )
                            <a id="language-url" href="{{urlLocale("en")}}"><div style="color: white" class="icon secondary">English</div></a>
                        @else
                            <a id="language-url" href="{{urlLocale("ar")}}"><div style="color: white" class="icon secondary">عربي</div></a>
                        @endif
                    </li>
                    @endif

                    <li class="dropdown">
                        <a href="profile.html#" id="userSettings" class="user-settings" data-toggle="dropdown" aria-haspopup="true">
                            @php($file = Auth::user()->archive->findChildByContentType("Personal Photo"))
                            @if($file)
                                <img class="avatar" src="{{ route('download_file', ['id'=>$file->id]) }}" alt="{{ Auth::user()->lang('name') }}">
                            @else
                                <img class="avatar" src="/img/user.png" alt="{{ Auth::user()->lang('name') }}">
                            @endif
                            <i class="icon-chevron-small-down"></i>
                        </a>
                        <div class="dropdown-menu lg dropdown-menu-right" aria-labelledby="userSettings">
                            @if(!Auth::user()->hasRole('Guest'))
                            <ul class="user-settings-list">
                                <li>
                                    <a href="{{ route('show_profile', ['id' => Auth()->user()->id])}}">
                                        <div class="icon">
                                            <i class="icon-account_circle"></i>
                                        </div>
                                        <p>@lang('tr.Profile')</p>
                                    </a>
                                </li>
                            </ul>
                            @endif
                            <div class="logout-btn">
                                <a href="{{route('logout')}}" class="btn btn-primary">@lang('tr.Logout')</a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</header>
<script type="text/javascript">
    $(document).ready(function () {
        // var currentURL =  window.location.href+'en';
        // $('#ar_switch').attr('href', currentURL.replace('en','ar'));
        // //$('#en_switch').attr('href',currentURL.replace('ar','en'))
    })
</script>