<div class="main-content">
    @if(!empty($errors->all()))
        <div class="alert alert-danger text-white bg-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('save_user', ['from'=>$from, 'user_id'=>$user->id]) }}" method="POST">
        {{ csrf_field() }}
        <div class="row">
            <div class="col-lg-6 col-xs-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-header">
                            @lang('tr.GeneralInformation')
                        </div>
                        <div class="card-body">

                            <div class="form-group">
                                <label>@lang('tr.EnglishName')</label>
                                <input required type="text" class="form-control" id="en_name" placeholder="@lang('tr.EnglishName')" name="en_name"  value="{{ $user->en_name }}">
                            </div>

                            <div class="form-group">
                                <label>@lang('tr.ArabicName')</label>
                                <input style="direction: rtl" required type="text" class="form-control" id="ar_name" placeholder="@lang('tr.ArabicName')" name="ar_name"  value="{{ $user->ar_name }}">
                            </div>

                            <div class="form-group">
                                <label>@lang('tr.Code')</label>
                                <input required type="text" class="form-control" id="code" placeholder="@lang('tr.Code')" name="code" value="{{ $user->code }}" pattern="[A-Za-z0-9]{6,7}" title="6 or 7 or 8 letters are required" data-remote-error="Member with the same code exists" data-remote="{{ route('check_code', ['code'=>'#value']) }}">
                            </div>

                            <div class="form-group">
                                <label>@lang('tr.NationalID')</label>
                                <input type="text" class="form-control" id="national_id" placeholder="@lang('tr.NationalID')" name="national_id" value="{{ $user->national_id }}" pattern="[0-9]{14}" title="14 digits are required" data-remote-error="Member with the same national id exists" data-remote="{{ route('check_national_id', ['national_id'=>'#value']) }}">
                            </div>

                            <div class="form-group">
                                <label>@lang('tr.Email')</label>
                                <input required type="email" class="form-control" id="email" placeholder="@lang('tr.Email')" name="email" value="{{ $user->email }}" data-remote-error="Member with the same email exists" data-remote="{{ route('check_email', ['email'=>'#value']) }}">
                            </div>

                            <div class="form-group">
                                <label>@lang('tr.Alt.Email')</label>
                                <input type="email" class="form-control" id="email_alt" placeholder="@lang('tr.Alt.Email')" name="email_alt" value="{{ $user->email_alt }}">
                            </div>

                            <div class="form-group">
                                <label>@lang('tr.Phone')</label>
                                <input type="phone" class="form-control" id="phone" placeholder="@lang('tr.Phone')" name="phone" value="{{ $user->phone }}">
                            </div>

                            <div class="form-group">
                                <label>@lang('tr.Mobile')</label>
                                <input type="phone" class="form-control" id="mobile" placeholder="@lang('tr.Mobile')" name="mobile" value="{{ $user->mobile }}">
                            </div>

                            <div class="form-group">
                                @if($from=="users")
                                    <label>@lang('tr.UserType')</label>
                                    {!! Form::select('type', array(''=>__('tr.SelectUserType'))+$user->types(), $user->type, array('id'=> 'type', 'data-placement'=>'top', 'title'=> __('SelectUserType'), 'class'=>'form-control', 'required'=>'yes', (($user->type!=0)?'disabled':'enabled')=>"yes" )) !!}
                                @else
                                    <input type="hidden" class="form-control" placeholder="@lang('tr.SelectUserType')" name="type" value="{{ $user->type }}">
                                    <input type="text" class="form-control" placeholder="@lang('tr.SelectUserType')" value="{{ $user->types()[$user->type] }}" readonly="yes">
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary btn-md"><span class="icon-edit"></span>@lang('tr.Save')</button>
            </div>
        </div>
    </form>
</div>
<hr/>

@section('pagejs')
    <script type="text/javascript">
        $(document).ready(function() {
            $("input[data-remote]").dataRemote();
        });
    </script>
@endsection