@if(!isset($fieldName))
    @php($fieldName = 'plan_id')
@endif

@if(!isset($customPlans))
    @php($customPlans = [])
@endif

@if(!isset($fieldId))
    @php($fieldId = 'plan_id')
@endif

@if(!isset($plan_id))
    @php($plan_id = null)
@endif

@if(!isset($className))
    @php($className = '')
@endif

@if(!isset($style))
    @php($style = '')
@endif

@if(!isset($required))
    @php($required = 'required')
@endif

@if(!isset($title))
    @php($title = __('tr.OfferedTo'))
@endif

@if(!isset($disabled))
    @php($disabled = '')
@endif

<select id="{{$fieldId}}" name="{{$fieldName}}" class='{{$className}}' title='{{$title}}' $required {{$disabled}} style='{{$style}}'>
    <option value="">{{$title}}</option>
    @foreach($customPlans as $key=>$value)
        <option value="{{ $key }}">{{ $value }}</option>
    @endforeach
    @foreach($bylaws as $bylaw)
        <optgroup label="{{ $bylaw->lang('name') }}">
            @php($major="")
            @foreach($bylaw->plans as $plan)
            @if($plan->lang('major')!=$major && !empty($major) )
                    <option disabled>
                        <b>{{$plan->lang('major')}}</b>
                    </option>
                @endif
                @php($major=$plan->lang('major'))
                @if($bylaw->credit_hours)
                    <option value="{{ $plan->id }}" @if($plan->id == $plan_id) selected @endif>{{ shortText($plan->lang('minor'), 64) }}</option>
                @else
                    <option value="{{ $plan->id }}" @if($plan->id == $plan_id) selected @endif>{{ $plan->year->lang('name') }}: {{ shortText($plan->lang('minor'), 64) }}</option>
                @endif
            @endforeach
        </optgroup>
    @endforeach
</select> 
