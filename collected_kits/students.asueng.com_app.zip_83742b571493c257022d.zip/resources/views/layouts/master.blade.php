<!doctype html>
<html lang="en">

@include('components.head')

@yield('pagecss')

<body style="overflow-x: hidden">

<!-- Loading starts -->
<div class="loading-wrapper">
    <div class="loading"></div>
</div>
<!-- Loading ends -->

<!-- BEGIN .app-wrap -->
<div class="app-wrap">
    
    @include('components.header')

    <!-- BEGIN .app-container -->
    <div class="app-container">

        @include('components.sidebar')

        <!-- BEGIN .app-main -->
        <div class="app-main">

            @include('components.heading')
            
            @yield('content')
            
        </div>
        <!-- END: .app-main -->
    </div>
    <!-- END: .app-container -->
    @include('components.footer')
</div>
<!-- END: .app-wrap -->

@include('components.script')

@yield('pagejs')

</body>

</html>