@extends('layouts.master')

@section('title', __("tr.Add Ticket"))
@section('subtitle', __("tr.Create New Ticket") )
@section('titleicon', "icon-chat2")

@section('content')
<div class="main-content">
        @if(!empty($errors->all()))
        <div class="alert alert-danger text-white bg-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    @php
    use 
    Illuminate\Support\Arr;
    @endphp
    
  
    <form method="post" action="{{ route('save_ticket')}}" id="edit_form" enctype="multipart/form-data">
    {{ csrf_field() }}
        <div class="row gutters">
            <div class="col-lg-6 col-xs-12 col-md-12 col-sm-12" >
                <div class="card" >
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-body" >
                                        
                            
                            <div class="form-group">
                                <label>@lang('tr.Discussion Type') <required style="color: red;">*</required></label>
                                {!! Form::select('ticket_type_id', array(''=>__('tr.Ticket Type'))+$ticketTypes, old('ticket_type_id'), array('id'=> 'ticket_type_id', 'class'=>'form-control', 'required'=>'yes')) !!}
                            </div>

                            <div class="form-group">
                                <label>@lang('tr.Title') <required style="color: red;">*</required></label>
                                <input type="text" name="title" class="form-control" data-placement="top" title="Title" value="{{ old('title') }}" placeholder="@lang('tr.Title')" required/>
                            </div>

                            <div class="form-group">
                                <label>@lang('tr.Description') <required style="color: red;">*</required></label>
                                <textarea required name="description" id="description" class="form-control" placeholder="@lang('tr.Description')" cols="30" rows="5" title="Description" >{{ old('description') }}</textarea>
                            </div>
                            <div class="form-group">
                                <input type="file" class="filestyle" name="attachments[]" data-icon="true" multiple>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row gutters">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary btn-md">
                <span class="icon-edit"></span> Submit</button>
            </div>
        </div>

        <hr/>
    </form>
</div>
@endsection

@section('pagejs')
<script type="text/javascript">
    $(document).ready(function() {
        {{--{!! genJSErros($errors) !!}--}}
        {{--$('#edit_form').showErrors(response);--}}
    });
</script>
@endsection