@extends('layouts.master')

@section('title', __("tr.Tickets"))
@section('subtitle', __("tr.Show user tickets" ) )
@section('titleicon', "icon-chat2")

@can('add_tickets')
	@section('actiontitle', __('tr.Submit Ticket'))
	@section('actionlink', route('add_ticket'))
	@section('actionicon', "icon-plus")
@endcan

@section('content')
	<!-- BEGIN .main-content -->
	<div class="main-content">
		<div class="row gutters">
			<div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
				 
			<div class="card">
					<div class="card-body pb-0">
						<div class="filter-box">
							<div class="row">
								<div class="col-md-2">
									{!! Form::select('ticket_type_id', array(""=>__("tr.Type"))+$ticketTypes, null, array('id'=> 'ticket_types_id', 'data-placement'=>'top', 'title'=> __('tr.Type'))) !!}
								</div>

								<div class="col-md-2">
									{!! Form::select('ticket_status', array(""=>__("tr.Select Status"))+$ticketStatus, null, array('id'=> 'ticket_status', 'data-placement'=>'top', 'title'=> __('tr.Status'))) !!}
								</div>
								 

								{{--Button--}}
								<div class="col-md-2 float">
									<button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
								</div>

								{{--Button--}}
								<div class="col-md-2 float">
									<button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
								</div>
							</div>
						</div>

					</div>
				</div>

				<div class="card">
					<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
						<div class="card-body">
							<table id="data_table" class="display" style="width:100%">
								<thead>
								<tr>
									<th width="16%">@lang('tr.Modified')</th>
									<th width="25%">@lang('tr.Title')</th>
									<th>@lang('tr.Type')</th>
									<th>@lang('tr.Responsable Name')</th>
									<th>@lang('tr.Status')</th>
									<th></th>
								</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Row end -->
	</div>
	<!-- END: .main-content -->

	<script type="text/javascript">
		var deleteURL = '{{ route('delete_ticket', ['id'=>'#id']) }}';
		var showURL = '{{ route('show_ticket', ['id'=>'#id']) }}';
		var statusLabels = [];
		var statusBadges = [];

		@foreach(\App\Ticket::statusLabels() as $key => $label)
				statusLabels[{{ $key }}] = '{{ str_replace('_', ' ', ucfirst($label)) }}';
		@endforeach

		@foreach(\App\Ticket::statusBadges() as $key => $badge)
			statusBadges[{{ $key }}] = '{{ $badge }}';
		@endforeach

		 

		$(document).ready(function() {
			var table = $('#data_table').DataTable({
				processing: true,
				serverSide: true,
				scrollX: true,
				stateSave: false,
				rowId: 'id',
				order: [
					[ 0, "desc" ]
				],
				"ajax": {
					"url": '{{ route('tickets') }}',
					"dataSrc": "data.data"

				},
				"columns": [
					{ "data": "updated_at", "name": "updated_at"},
					{ "data": "title", "name": "title",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							$(nTd).html("<a href='"+showURL.replace('#id', oData.id)+"'>"+oData.title+"</a>");
						}
					},
					{ "data": "ticket_type", "name": "ticket_type"},
					{ "data": "staff_name", "name": "staff_name"},
					{ "data": "status", "name": "status",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							var html = '';
							html += "<span class='badge badge-" + statusBadges[oData.status] + "'>" + statusLabels[oData.status] + "</span>";
							$(nTd).html(html);
						}
					},
					{ "data": "id", "name": "id",
						fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
							var html = "";
							html += "<a title='@lang('tr.View')' href='"+showURL.replace('#id', oData.id)+"' target='_blank'><i class='icon-eye'></i></a>&nbsp;";
							if(oData.status == 0 ){
								@can('delete_tickets')
									html += "<a title='@lang('tr.Delete')' href='javascript:void(0)' class='delete_ticket' id="+oData.id+"  label='"+oData.code+":"+oData.name+"' url='"+deleteURL.replace('#id', oData.id)+"'><i class='icon-delete'></i></a>";
								@endcan
							}
							$(nTd).html("<span class='action-column'>"+html+"</span>");
						}
					},
				]
			});

			$(".dataTables_filter").hide();

			$('#search_button').on( 'click', function () {
				table.columns(0).search($("#ticket_types_id").val());
				table.columns(1).search($("#ticket_status").val());
				table.draw();
			} );

		 

			$('#reset_button').on( 'click', function () {
				$("#ticket_types_id").val("");
				$("#ticket_status").val("");
				$('#search_button').trigger('click');
			});


			$(document).on("click", ".delete_ticket", function () {
				var deleteURL = '{{ route('delete_ticket', ['id'=>'#id']) }}';
				var row = $(this).closest('tr');
				var label = $(this).attr('label');
				var id = $(this).attr('id');
				var url = deleteURL.replace('#id', id);
				var message = "Are you sure you want to delete (<B>"+label+"</B>) ?";

				warningBox(message, function() {
					$.post(url, {"_token": '{{ csrf_token() }}' }, function(data, status){
						if(data.error) {
							errorBox(data.message);
						} else {
							table.row("#"+id).remove().draw(false);
							infoBox("Item deleted successfully.");
						}
					});
				});

			});

		});
	</script>
@stop
