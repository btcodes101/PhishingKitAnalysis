@extends('layouts.master')

@section('title',  __('tr.Tuition Fees Payment'))
@section('subtitle', __('tr.Student Financial Unit') )
@section('titleicon', "icon-coin-pound")


@section('content')
<div class="main-content">
	<div class="row">
        <div class="col-lg-8 col-xs-12 col-md-12 col-sm-12">
        	<div class="card">
				<div class="card-header">@lang('tr.You are about to pay <b>:amount </b>', ['amount' => $userRequest->total_amount])</div>
			</div>
			
			@include('payments.components.pay')
		</div>
	</div>	
	<br/>
	<br/>
</div>
@endsection
@section('pagejs')
<script>
	if({{$userRequest->type=="Charge_my_credit"}})
	$("#pay_with_student_credit").remove();
</script>
@endsection
