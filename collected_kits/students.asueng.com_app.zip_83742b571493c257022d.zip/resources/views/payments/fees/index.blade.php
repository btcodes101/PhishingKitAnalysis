@extends('layouts.master')
@section('title', __("tr.Payment"))
@section('titleicon', "icon-cog3" )

@section('advancedaction')
<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 mt-1">
    <div class="btn-group float-right">
        <form action="" method="post" >
            {{ csrf_field() }}
        </form>
        {{-- <button type="button" class="btn btn-primary btn-sm">@lang('tr.More')</button>
        <button type="button" class="btn btn-primary btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="sr-only">Toggle Dropdown</span>
        </button>
        <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-start" style="position: absolute; transform: translate3d(71px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
            <button id="add_payment" class="dropdown-item">@lang('tr.Add Payments')</button>
        </div> --}}
    </div>
</div>
@endsection

@section('content')
	<!-- BEGIN .main-content -->
    <div class="main-content">

        @if(Session::has('alert'))
        <div>
            <div class="alert custom alert-danger" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <i class="icon-warning2"></i><strong>Error! </strong>{{session()->pull('alert')[0]}}
            </div>
        </div>
    @endif
        <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="stats-widget">
                                <div class="stats-widget-header">
                                    <i class="icon-coin-pound"></i>
                                </div>
                                <div class="stats-widget-body">
                                    <!-- Row start -->
                                    <ul class="row no-gutters">
                                        <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                            <h6 class="blog-title">Required</h6>
                                        </li>
                                        <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                            <h4 class="total">{{$statistics->total_amount}}</h4>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>               
                </div>

                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="stats-widget">
                                <div class="stats-widget-header">
                                    <i class="icon-coin-pound"></i>
                                </div>
                                <div class="stats-widget-body">
                                    <!-- Row start -->
                                    <ul class="row no-gutters">
                                        <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                            <h6 class="blog-title">Credit</h6>
                                        </li>
                                        <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                            <h4 class="total">{{$student->financialCredit()}}</h4>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>               
                </div>
                    
            </div>
        </div>
        @if($statistics->total_amount != 0)
        <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="card-body">
                    <form action="{{route('pay_student_fee')}}" method='post'>
                    @csrf
                    <div class="row gutters">
                        <input type="hidden" class="form-control" value="{{$student->financialCredit()}}" id="total_credit" name="total_credit" />
                        <div class="form-group col-md-6">
                            <select class="form-control" id="studentUnPaidPaymemts" name="studentPaymentId">
                                @foreach($unPaidPayments as $payment)
                                    @php($amount = $payment->amount - $payment->paid)
                                    <option value="{{$payment->id}}" amount="{{$amount}}">{{"#$payment->id | $payment->service_name | $payment->term_name | $amount LE"}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <input type="number" step="any" min="0" id="total_amount" name="total_amount" class="form-control" value="0.0">
                        </div>
                        <div class="form-group col-md-2">
                            <button type='submit' disabled="disabled" id="payment_submit" class='btn btn-primary form-control' id='action'>@lang('tr.Pay Now')</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>               
        </div>
        @endif
        @php($methodsList = 'App\StudentFee'::methodsList())
        @php($statusList = 'App\StudentFee'::statusList())

        {{-- @include('financial.system_payments.edit_payment') --}}
            
        <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
            <div class="card">
                    <div class="card-body"> 
                        <table id="data_table" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Term</th>
                                <th>@lang('tr.Type')</th>
                                <th width="50%">@lang('tr.Payment')</th>
                                <th>@lang('tr.Status')</th>
                                <th width="10%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($payments as $payment)
                            @php($color = "")
                            @if($payment->amount > $payment->paid && $payment->due_date <= \Carbon\Carbon::now())

                            @php($color = "color: red;" )

                            @endif

                            <tr style="{{$color}}" id="{{$payment->id}}" student_id="{{$payment->student_id}}" user_name="{{$payment->user_name}}" service_id="{{$payment->service_id}}" method="{{$payment->method}}" amount="{{$payment->amount}}" due_date="{{$payment->due_date}}" term_id="{{$payment->term_id}}" notes="{{$payment->notes}}">
                                <td>{{$payment->id}}</td>
                                <td>{{$payment->term_name}}</td>
                                <td>{{$payment->service_name}}</td>
                                <td>
                                    <b>Amount</b>: {{$payment->paid}} of {{$payment->amount}}<br/>
                                    <b>Method</b>: {{$methodsList[$payment->method]}}<br/>
                                    <b>Due Date</b>: {{$payment->due_date}}<br/>
                                    <b>Notes</b>: {{$payment->notes}}<br/>
                                </td>
                                <td>
                                    @if($payment->status=='App\StudentFee'::STATUS_UN_PAID)
                                    <span class='badge badge-danger'>{{$statusList[$payment->status]}}</span>
                                    @elseif($payment->status=='App\StudentFee'::STATUS_PARTIALLY_PAID)
                                    <span class='badge badge-primary'>{{$statusList[$payment->status]}}</span>
                                    @else
                                    <span class='badge badge-success'>{{$statusList[$payment->status]}}</span>
                                    @endif
                                </td>
                                <td>
                                    <span class='action-column'>
                                    </span>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>
    <!-- END: .main-content -->
@endsection

@section('pagejs')
	<script type="text/javascript">
        function updateTotal()
        {
            var amount = $("#studentUnPaidPaymemts").find('option:selected').attr("amount"); 
            $("#total_amount").val(amount); 
        }
		$(document).ready(function() {
            updateTotal();
            var table = $('#data_table').DataTable({"ordering": false});
            function validatePayment()
            {
             if($('#total_amount').val()<=0)
                    $("#payment_submit").prop("disabled", true);
                else
                    $('#payment_submit').removeAttr("disabled");
            }
            validatePayment();
            $(document).on('keyup', '#total_amount', function () {
                if({{$statistics->total_amount}} < $('#total_amount').val())
                    $('#total_amount').val({{$statistics->total_amount}});
                validatePayment();
            });

            $("#studentUnPaidPaymemts").change(function(){
                updateTotal();     
            });
		});
	</script>
@endsection
