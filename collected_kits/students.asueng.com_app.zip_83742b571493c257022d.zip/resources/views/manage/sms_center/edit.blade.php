@extends('layouts.master')

@section('title', __('tr.Write SMS') )
@section('titleicon', "icon-message-typing")

@section('content')

@php($language = ($smsMessage)?$smsMessage->language:'en')
@php($message = ($smsMessage)?$smsMessage->message:'')

    <div class="main-content" id="app">

        <form action="{{ route('save_sms',['id'=>$smsMessage->id]) }}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
            <!--Start: Edit Page-->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-6 col-md-6 col-sm-6">
                    <div class="card" id="email_message" 
                    @if($language=='ar')
                    style="direction: rtl;text-align: right;"
                    @else
                    style="direction: ltr;text-align: left;"
                    @endif
                    >
                        <div class="card-body">
                            <div class="row form-group">
                                <div class="col-md-4">
                                    {!! Form::select('send_to', array(''=>__('tr.Send to ...')) + $sendToTypes, $smsMessage->send_to, array('id'=> 'send_to', 'class'=>'form-control', 'required'=>'required' )) !!}
                                </div>
                                <div class="col-md-2">
                                    <select id='language' name='language' class="form-control">
                                        <option {{($language=='ar')?'':'selected'}} value="en">English</option>
                                        <option {{($language=='ar')?'selected':''}} value="ar">عربي</option>
                                    </select>
                                </div>
                            </div>

                            <textarea class="form-control" rows="5" name="message" id="summernote" required minlength="5" maxlength="256">{!!$message!!}</textarea>
                            &ensp;
                            <hr>
                            <button type="submit" class="btn btn-primary btn-md float-right">
                                <span class="icon-edit"></span>
                                @if($smsMessage->id==0)
                                    @lang('tr.Send')
                                @else
                                    @lang('tr.Save')
                                @endif
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <br/>
    </div>
@endsection

@section('pagejs')
    <script type="text/javascript">

        $(document).ready(function() {

            $('#language').change(function(event) {
                
                if($(this).val()=="ar") {
                    $('#email_message').css('direction', 'rtl');
                    $('#email_message').css('text-align', 'right');
                } else {
                    $('#email_message').css('direction', 'ltr');
                    $('#email_message').css('text-align', 'left');
                }
            });

            init();
        });

    </script>
@endsection
