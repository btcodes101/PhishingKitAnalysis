@extends('layouts.master')

@section('title', __("tr.Management") )
@section('subtitle', __("tr.Managementarea"))
@section('titleicon', "icon-cog3" )

@section('content')
    <div class="main-content">
        <div class="row gutters">
            @can('access_terms')
                <div class="col-md-3">
                    <a href="{{ route('terms') }}" class="setting-box">
                        <div class="title">@lang('tr.Terms')</div>
                        <div class="icon">
                            <span class="icon-calendar3"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_lookups')
                <div class="col-md-3">
                    <a href="{{ route('buildings') }}" class="setting-box">
                        <div class="title">@lang('tr.Buildings')</div>
                        <div class="icon">
                            <span class="icon-office"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_lookups')
                <div class="col-md-3">
                    <a href="{{ route('locations') }}" class="setting-box">
                        <div class="title">@lang('tr.Locations')</div>
                        <div class="icon">
                            <span class="icon-room"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_studies')
                <div class="col-md-3">
                    <a href="{{ route('studies') }}" class="setting-box">
                        <div class="title">@lang('tr.Studies')</div>
                        <div class="icon">
                            <span class="icon-contacts"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_users')
                <div class="col-md-3">
                    <a href="{{ route('users') }}" class="setting-box">
                        <div class="title">@lang('tr.Users')</div>
                        <div class="icon">
                            <span class="icon-users"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_roles')
                <div class="col-md-3">
                    <a href="{{ route('roles') }}" class="setting-box">
                        <div class="title">@lang('tr.Roles')</div>
                        <div class="icon">
                            <span class="icon-lock"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_main_archive')
                <div class="col-md-3">
                    <a href="{{ route('archive') }}" class="setting-box">
                        <div class="title">@lang('tr.Archive')</div>
                        <div class="icon">
                            <span class="icon-tabs-outline"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_log')
                <div class="col-md-3">
                    <a href="{{ route('log') }}" class="setting-box">
                        <div class="title">@lang('tr.Log')</div>
                        <div class="icon">
                            <span class="icon-th-list"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_emails')
                <div class="col-md-3">
                    <a href="{{ route('emails_center') }}" class="setting-box">
                        <div class="title">@lang('tr.Emails Center')</div>
                        <div class="icon">
                            <span class="icon-mail6"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_sms')
                <div class="col-md-3">
                    <a href="{{ route('sms_center') }}" class="setting-box">
                        <div class="title">@lang('tr.SMS Center')</div>
                        <div class="icon">
                            <span class="icon-message"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_printing')
                <div class="col-md-3">
                    <a href="{{ route('printing_center') }}" class="setting-box">
                        <div class="title">@lang('tr.Printing Center')</div>
                        <div class="icon">
                            <span class="icon-mail6"></span>
                        </div>
                    </a>
                </div>
            @endcan

            @can('access_applicants')
            <div class="col-md-3">
                <a href="{{ route('applicants') }}" class="setting-box">
                    <div class="title">@lang('tr.Applicants')</div>
                    <div class="icon">
                        <span class="icon-users"></span>
                    </div>
                </a>
            </div>
            @endcan

            @can('access_projects')
            <div class="col-md-3">
                <a href="{{ route('projects') }}" class="setting-box">
                    <div class="title">@lang('tr.Projects')</div>
                    <div class="icon">
                        <span class="icon-user-tie"></span>
                    </div>
                </a>
            </div>
            @endcan

            @can('access_publications')
            <div class="col-md-3">
                <a href="{{ route('publications') }}" class="setting-box">
                    <div class="title">@lang('tr.Publications')</div>
                    <div class="icon">
                        <span class="icon-user-tie"></span>
                    </div>
                </a>
            </div>
            @endcan

        </div>
    </div>
@stop