@extends('layouts.master')

@section('title', __('tr.Buildings') )
@section('subtitle', __('tr.BuildingInformation'))
@section('titleicon', "icon-office")

@can('add_lookups')
@section('advancedaction')
    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
        <div class="right-actions">
            <div class="btn-group float-right">
                <div class="btn-group">
                    <button id="add_building" type="button" class="btn btn-primary">
                        <i class="icon-plus"></i> @lang('tr.AddBuilding')
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection
@endcan

@section('content')
    <div class='modal fade' id='edit_modal' tabindex='-1' role='dialog' aria-labelledby='edit_modal' aria-hidden='true'>
        <form action="" method="post" enctype='multipart/form-data'>
            {{ csrf_field() }}
            <div class='modal-dialog' role='document'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <h5 class='modal-title' id='modal_label'></h5>
                        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                        </button>
                    </div>
                    <div class='modal-body'>
                        <div class="form-group">
                            <input required type="text" class="form-control" id="name" name="name" title="@lang('tr.Building Name')" placeholder="@lang('tr.Building Name')">
                        </div>
                        <div class="form-group">
                            {!! Form::select('status', array(""=>__("tr.Select Building Status"))+$statusLabels, null, array('id'=> 'status', 'class'=>'form-control', 'title'=> __('tr.Building Status'))) !!}
                        </div>
                    </div>
                    <div>
                        <div id='progress_bar' style="background-color: green; width: 0%; height: 2px;"></div>
                    </div>
                    <div class='modal-footer'>
                        <button type='submit' class='btn btn-primary' id='action'>@lang('tr.Submit') <span id="progress_text"></span></button>
                        <button type='button' class='btn btn-light' id='close' data-dismiss='modal'>@lang('tr.Cancel')</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- BEGIN .main-content -->
    <div class="main-content">
        <div class="row gutters">
            <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-body pb-0">
                        <div class="filter-box">
                            <div class="row">
                                <div class="col-md-6">
                                    {!! Form::select('search_status', array(""=>__("tr.Select Building Status"))+$statusLabels, null, array('id'=> 'search_status', 'data-placement'=>'top', 'title'=> __('tr.Building Status'))) !!}
                                </div>
                                <div class="col-md-2">
                                    <input type="text" placeholder="@lang('tr.TextSearch')" id="text_search">
                                </div>
                                <div class="col-md-2 float">
                                    <button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
                                </div>

                                {{--Button--}}
                                <div class="col-md-2 float">
                                    <button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="card-body">
                            <table id="buildings_table" class="display" style="width:100%">
                                <thead>
                                <tr>
                                    <th>@lang('tr.#')</th>
                                    <th>@lang('tr.Building Name')</th>
                                    <th>@lang('tr.Building Status')</th>
                                    <th></th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->
    </div>
    <!-- END: .main-content -->

    <script type="text/javascript">

        $(document).ready(function() {

            var statusLabels = [
            @foreach($statusLabels as $value)
            '{{ $value }}',
            @endforeach
            ];

            var table = $('#buildings_table').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                stateSave: false,
                rowId: 'id',
                language: dataTableLanguage,
                "ajax": {
                    "url": '{{ route('buildings') }}',
                    "dataSrc": "data.data"
                },
                "columns": [
                    { "data": "id", "name": "id"},
                    { "data": "name", "name": "name"},
                    { "data": "status", "name": "status" ,
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            $(nTd).text(statusLabels[oData.status]);
                        }
                    },
                    { "data": "id", "name": "id",
                        fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
                            var html = "";

                            @can('edit_lookups')
                            html += "<a title='@lang('tr.Edit')' href='javascript:void(0)' class='edit_building'><i class='icon-edit'></i></a>&nbsp;";
                            @endcan

                            @can('delete_lookups')
                            html += "<a title='@lang('tr.Delete')' href='javascript:void(0)' class='delete_building'><i class='icon-delete'></i></a>";
                            @endcan

                            $(nTd).html("<span class='action-column'>"+html+"</span>");
                        }
                    },
                ]
            });

            $(".dataTables_filter").hide();

            $('#search_button').on( 'click', function () {
                table.search($("#text_search").val());
                table.columns(0).search($("#search_status").val());
                table.draw();
            } );

            $('#text_search').keyup(function (e){
                if(e.keyCode == 13)
                    $('#search_button').trigger('click');
            });

            $('#reset_button').on( 'click', function () {
                $("#text_search").val("");
                $("#search_status").val("");
                $('#search_button').trigger('click');
            } );

            function edit(row) {
                var modal = $('#edit_modal');
                var data = null;
                modal.find('form')[0].reset();
                modal.find("option:selected").removeAttr("selected");
                if(row) {
                    data = table.row(row).data();
                    modal.find('#name').val(data.name);
                    modal.find('#status option[value='+data.status+']').attr('selected', 'selected');
                }
                var action = '{{ route('save_building', ['id'=>'#id']) }}';
                modal.find('#modal_label').text((data)?'Edit Building':'Add Building');
                action = action.replace('#id', (data)?data.id:0);
                modal.find('form').attr('action', action);
                modal.execModal({
                    progressBar: 'progress_bar',
                    progressText: 'progress_text',
                }, function(response){
                    if(row) {
                       table.draw(false);
                    } else {
                        table.page('last').draw('page');
                    }
                }, function(response){
                    var errorString = '';
                    $.each( response.errors, function( key, value) {
                        errorString += key + ', ' + value + ',';
                    });
                    errorBox(errorString);
                });
            }

            $(document).on("click", ".delete_building", function () {
                var deleteURL = '{{ route('delete_building', ['id'=>'#id']) }}';
                var row = $(this).closest('tr');
                var data = table.row(row).data();
                var url = deleteURL.replace('#id', data.id);
                var message = "Are you sure you want to delete (<B>"+data.name+"</B>) ?";

                warningBox(message, function() {
                    $.post(url, {"_token": '{{ csrf_token() }}' }, function(data, status){
                        table.row("#"+data.id).remove().draw(false);
                        infoBox('@lang('tr.DeletedSuccessfully')');
                    });
                });
            });

            $('#add_building').on('click', function () {
                edit(null);
            });

            $(document).on("click", ".edit_building", function () {
                edit($(this).closest('tr'));
            });
        });
    </script>
@stop
