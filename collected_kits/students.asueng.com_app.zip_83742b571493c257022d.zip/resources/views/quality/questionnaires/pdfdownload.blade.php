<table width="100%"><h2>Gerneral Information</h2></table>
<table border="1px" cellpadding="5px">
    <tr style="width: 100%">
        <th style="width: 20%;font-size: large; ">Course</th>
        <td style="width: 80%;font-size: large;">{{ $questionnaireTask->course->code.':'. $questionnaireTask->course->en_name }}</td>
    </tr>
    <tr>
        <th style="width: 20%;font-size: large;">Instructors</th>
        <td style="width: 80%;font-size: large;">
            @foreach($instructors as $instructor)
                {{ $instructor->name }}
                @if($instructor !== $instructors[count($instructors)-1])
                    ,
                @endif
            @endforeach
        </td>
    </tr>
</table>
@foreach( $questionnairesTasks as $questionnaireTask)
    @if( $questionnaireTask->instructor_id ==0 )
        <table width="100%"><h2>Course Evaluation ({{$questionnaireTask->count}} Participants)</h2></table>
    @else
        <table width="100%"><h2>Instructor Evaluation : {{ $questionnaireTask->instructor->en_name}} ({{ $questionnaireTask->count }} Participants)</h2></table>
    @endif

    <table border="1px" cellpadding="5px">
        <tr style="width: 100%;font-size: large;">
            <th style="width: 80%;font-size: large;">Question</th>
            <th style="width: 20%;font-size: large;">Score</th>
        </tr>
        @foreach($questionnaireTask->questionnaireQuestionsAnswers() as $questionnaireQuestionAnswer)
        <tr style="width: 100%;font-size: large;">
            <td style="width: 80%;font-size: large;">{{ $questionnaireQuestionAnswer->en_question }}</td>
            <td style="width: 20%;font-size: large;">{{ $questionnaireQuestionAnswer->average_score }}%</td>
        </tr>
        @endforeach
    </table>
    @if(auth()->user()->hasPermissionTo('edit_questionnaires') || $questionnaireTask->term->questionnaire_publish_status==2)
    @foreach($questionnaireTask->questionnaireQuestionsComments() as $questionnaireQuestionComment)
        @if(!empty($questionnaireQuestionComment->comment))
        <p>
            - {{ $questionnaireQuestionComment->comment }}
        </p>
        @endif
    @endforeach
    @endif
@endforeach