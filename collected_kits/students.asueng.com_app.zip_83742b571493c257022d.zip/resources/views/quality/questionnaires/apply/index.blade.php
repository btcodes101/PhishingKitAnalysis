@extends('layouts.master')

@section('title',  __('tr.Questionnaires') )
@section('subtitle', __('tr.Questionnaires Information') )
@section('titleicon', "icon-point-of-interest-outline" )

@section('pagecss')
@endsection

@section('content')
<link href="https://fonts.googleapis.com/css?family=Cairo" rel="stylesheet">

<style>
    .questionnaire_msg{
        padding: 10px;
    }
    .questionnaire_msg>h1,
    .questionnaire_msg>h2,
    .questionnaire_msg>h3,
    .questionnaire_msg>h4,
    .questionnaire_msg>h5,
    .questionnaire_msg>h5,
    .questionnaire_msg>p,
    .questionnaire_msg>span,
    .questionnaire_msg>ul{
        color: black !important;
}
</style>

@php($dir=(lang()=="en")?"left":"right")


<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 main-bg questionnaire_msg" style="color:black !important;padding: 30px;font-size: 10px;text-align: center;">
            <div class="overlay"></div>
            {!! $term->questionnaire_message !!}
        </div>
    </div>
</div>

<p style="width:90%;height:2px;background:black;display:block;margin-left:auto;margin-right:auto;"></p>

<br>

<div class="section-wrapper p-t-37 p-b-33">

    <div class="container">
        
        @foreach($tasks as $task)
        
        
        @if($task != null)
        
        
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10 mt-1" style="display: block; margin-left: auto; margin-right: auto; width: 90%;">
                <div class="row" style="border: 1px solid #4266b2; padding: 7px; background: #e6ecf3; box-shadow: 0 0 1px 1px #5a81d426;">
                    
                    <div class="col-sm-10">
                        <h5 style="text-transform: capitalize!important;text-align:{{$dir}};">{{$task->title()}}</h5>
                    </div>
                    <div class="col-sm-2">
                    
                        @php($title = "")
                        @php($type = "")
                        @if($term->isQuestionnaireOpen())
                            @if($task->isAnswered())
                                @php($title = __('tr.Update'))
                                @php($type = "btn-primary")
                            @else
                                @php($title = __('tr.Start'))
                                @php($type = "btn-warning")
                            @endif
                        @else
                            @php($title = __('tr.View'))
                            @php($type = "btn-success")
                        @endif
                        <a href="{{ route('questionnaire_apply_show', ['id'=>$task->id]) }}" class="btn waves-effect {{ $type }}  float-right" > {{ $title }}</a>
                    </div>
                </div>
                
            </div>
            <div class="col-md-1"></div>
        </div>
        
        
        
        
        <div class="col-md-12">
            <hr>
        </div>
        @endif
        @endforeach
        
        

    </div>
</div>
@endsection

@section('pagejs')
@endsection
