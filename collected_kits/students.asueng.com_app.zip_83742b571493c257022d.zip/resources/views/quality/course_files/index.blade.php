@extends('layouts.master')

@section('title', __('tr.Course Files') )
@section('subtitle', __('tr.Course Files Info') )
@section('titleicon', "icon-point-of-interest-outline" )

@section('content')

<?php
$statusBadges = [
	'badge-warning',
	'badge-danger',
	'badge-primary',
	'badge-info',
	'badge-secondary',
	'badge-success',
	'badge-warning',
	'badge-danger',
	'badge-danger',
]
?>

	<!-- BEGIN .main-content -->
	<div class="main-content">
			
		<!-- Table -->
		<div class="card">
			<div class="card-body pb-0">
	    		<div class="row filter-box">
	            	{{--Term--}}	                        
	                <div class="col-md-2">
						{!! Form::select('term_id', array(""=>__("tr.SelectTerm"))+$terms, $currentTermID, array('id'=> 'term_id', 'data-placement'=>'top', 'title'=> __('tr.Term'))) !!}
					</div>

					{{--Status--}}
					<div class="col-md-2">
						{!! Form::select('status', array(""=>__("tr.SelectStatus"))+$statusTypes, null, array('id'=> 'status', 'data-placement'=>'top', 'title'=> __('tr.Status'))) !!}
					</div>

	                {{--By Law--}}
	                <div class="col-md-2">
						<select name="bylaw_id" id="bylaw_id">
							<option value="">@lang('tr.Select Bylaw')</option>
							@foreach($allBylaws as $item)
								<option value="{{ $item->code }}">{{ $item->lang('name') }}</option>
							@endforeach
						</select>
					</div>

					{{--Offered From--}}
	                <div class="col-md-2">
						{!! Form::select('offering_department_id', array(""=>__("tr.OfferedBy"))+$departments, null, array('id'=> 'offering_department_id', 'data-placement'=>'top', 'title'=> __('OfferedBy'))) !!}
					</div>

	                {{--Offered To--}}
	                <div class="form-group col-md-4">
	                    @include('components.select_plan', ['bylaws'=>$bylaws, 'className'=>''])                                       
	                </div>									

                    {{--Text search[en_name, ar_name, code]--}}
					<div class="col-md-4">
						{{ Form::text('text_search', null, ['id'=>'text_search', 'data-placement'=>'top', 'title'=> __('tr.TextSearch'), 'placeholder'=>__('tr.TextSearch')]) }}
					</div>					

					{{--Button--}}
					<div class="col-md-2 float">
						<button class="btn btn-primary" type="button" id="search_button">@lang('tr.Search')</button>
					</div>

					{{--Button--}}
					<div class="col-md-2 float">
						<button class="btn btn-danger" type="button" id="reset_button">@lang('tr.Reset')</button>
					</div>

	            </div>
	        </div>
        </div>

        <!-- Statistics -->
        <div id="term_statistics" class="row gutters">
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6">
                <div class="card" id="remaining">
                    <div class="card-body">
                        <div class="stats-widget">
                            <a href="#" class="stats-label" data-placement="top">-</a>
                            <div class="stats-widget-header">
                                <i class="icon-file-text"></i>
                            </div>
                            <div class="stats-widget-body">
                                <!-- Row start -->
                                <ul class="row no-gutters">
                                    <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                        <h6 class="blog-title">@lang('tr.Remaining')</h6>
                                    </li>
                                    <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                        <h4 class="total">-</h4>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6">
                <div class="card" id="submitted">
                    <div class="card-body">
                        <div class="stats-widget">
                            <a href="#" class="stats-label" data-placement="top">-</a>
                            <div class="stats-widget-header">
                                <i class="icon-upload6"></i>
                            </div>
                            <div class="stats-widget-body">
                                <!-- Row start -->
                                <ul class="row no-gutters">
                                    <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                        <h6 class="blog-title">@lang('tr.Submitted')</h6>
                                    </li>
                                    <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                        <h4 class="total">-</h4>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>			

            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6">
                <div class="card" id='reviewed'>
                    <div class="card-body">
                        <div class="stats-widget">
                            <a href="#" class="stats-label" data-placement="top">-</a>
                            <div class="stats-widget-header">
                                <i class="icon-book-open"></i>
                            </div>
                            <div class="stats-widget-body">
                                <!-- Row start -->
                                <ul class="row no-gutters">
                                    <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                        <h6 class="blog-title">@lang('tr.Reviewed')</h6>
                                    </li>
                                    <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                        <h4 class="total">-</h4>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6">
                <div class="card" id='approved'>
                    <div class="card-body">
                        <div class="stats-widget">
                            <a href="#" class="stats-label" data-placement="top">-</a>
                            <div class="stats-widget-header">
                                <i class="icon-clipboard"></i>
                            </div>
                            <div class="stats-widget-body">
                                <!-- Row start -->
                                <ul class="row no-gutters">
                                    <li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
                                        <h6 class="blog-title">@lang('tr.Approved')</h6>
                                    </li>
                                    <li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
                                        <h4 class="total">-</h4>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



			<div class="col-xl-2 col-lg-2 col-md-2 col-sm-6">
				<div class="card" id='rejected'>
					<div class="card-body">
						<div class="stats-widget">
                            <a href="#" class="stats-label" data-placement="top">-</a>
							<div class="stats-widget-header">
								<i class="icon-warning"></i>
							</div>
							<div class="stats-widget-body">
								<!-- Row start -->
								<ul class="row no-gutters">
									<li class="col-xl-9 col-lg-9 col-md-9 col-sm-9 col">
										<h6 class="blog-title">@lang('tr.Not Passed')</h6>
									</li>
									<li class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col">
										<h4 class="total">-</h4>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-xl-2 col-lg-2 col-md-2 col-sm-6">
				<div class="card" id='holded'>
					<div class="card-body">
						<div class="stats-widget">
							<a href="#" class="stats-label" data-placement="top">-</a>
							<div class="stats-widget-header">
								<i class="icon-upload-to-cloud"></i>
							</div>
							<div class="stats-widget-body">
								<!-- Row start -->
								<ul class="row no-gutters">
									<li class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col">
										<h6 class="blog-title">@lang('tr.Held')</h6>
									</li>
									<li class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col">
										<h4 class="total">-</h4>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>

        </div>
				
		<!-- Table -->
		<div class="card">
			<div class="card-header">
				<span id="term_name">@lang('tr.AllTerms')</span>
				@can('approve_coursefiles')
				<div id="term_action" class="btn-group float-right">
					<div class="btn-group">
						<button type="button" class="btn btn-primary btn-sm">@lang('tr.More')</button>
						<button type="button" class="btn btn-primary btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<span class="sr-only">Toggle Dropdown</span>
						</button>
						<div class="dropdown-menu dropdown-menu-right" x-placement="bottom-start" style="position: absolute; transform: translate3d(71px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
								<a id="course_files_report" class="dropdown-item" href="{{ route("course_files_report",['termID' => '#term_id']) }}">@lang('tr.Download Report')</a>

								<a id="term_edit_action" class="dropdown-item">@lang('tr.Update Schedule')</a>
						</div>
					</div>
				</div>
				@endcan
			</div>
			
			<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
				<div class="card-body">
					<table id="data_table" class="display" style="width:100%">
				        <thead>
				            <tr>
				                <th>ID</th>
				                <th>@lang('tr.CourseID')</th>
				                <th width="25%">@lang('tr.Course')</th>
				                <th>@lang('tr.Status')</th>
				                <th width="20%">@lang('tr.OfferedBy')</th>
				                <th width="25%">@lang('tr.OfferedTo')</th>
				                <th>@lang('tr.Term')</th>
				                <th></th>
				            </tr>
				        </thead>						        
				    </table>
				</div>
			</div>
		</div>
	
	</div>
	<!-- END: .main-content -->
@endsection

@section('pagejs')
<script type="text/javascript">

	var showURL = '{{ route('show_course_files', ['id'=>'#id']) }}';
	var showCourseURL = '{{ route('show_course', ['id'=>'#id']) }}';
	var statusTypes = [
	@foreach($statusTypes as $key=>$value)
	'{{ $value }}',
	@endforeach
	];

	var statusBadges = [
	@foreach($statusBadges as $value)
	'{{ $value }}',
	@endforeach
	];
	
    $(document).ready(function() {
    	
    	$('#plan_id').selectize({
    		plugins: ['remove_button'],
    	});

        var table = $('#data_table').DataTable({
	        processing: true,
			serverSide: true,
			scrollX: true,
			stateSave: false,
			rowId: 'id',
		    "ajax": {
		        "url": '{{ route('course_files') }}',
		        "dataSrc": "data.data"
		    },
		    "columns": [
			    { "data": "id", "name": "id",
		            fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
		                $(nTd).html("<a href='"+showURL.replace('#id', oData.id)+"'>"+oData.id+"</a>");
		            }
		        },
			    { "data": "course_id", "name": "course_id", "visible": false },
			    { "data": "course", "name": "course",
		            fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
		                $(nTd).html("<a href='"+showCourseURL.replace('#id', oData.course_id)+"'>"+oData.course+"</a>");
		            } },
			    { "data": "status", "name": "status",
		            fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
			    		$(nTd).html("<span class='badge "+statusBadges[oData.status]+"'>"+statusTypes[oData.status]+"</span>");
		            }
		        },
			    { "data": "department", "name": "department"},
			    { "data": "plan", "name": "plan",
		            fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
		            	if(oData.plans==null || oData.plans.length==0) {
		            		var html = oData.bylaw.toUpperCase() + ", Multiple plans";
		            		html += " (" + oData.instructors + " instructors)";
		            		$(nTd).html(html);
		            		return;
		            	}
		            	var first = oData.plans[0];
		            	var head = first.bylaw.toUpperCase();
		            	if(first.year_id>=100) head += ", " + first.year_name;
		            	head += " (" + oData.instructors + " instructors)";
		            	var body = "";
		            	$.each( oData.plans, function( key, value) {
		            		if(body.length>0)body += ", ";
				            body += "<b>"+value.minor+"</b>";
				            if(value.program)body += ", <b>"+value.program+"</b>";
				            if(first.year_id<100) body += " (" + value.year_name + ")";
				            body += " (" + value.students + " students)";
				        });
		                $(nTd).html("<span style='font-size:90%'>"+oData.plan_id+","+head+": "+body+"<span>");
		            }
		        },
			    { "data": "term", "name": "term" },
			    { "data": "id", "name": "id",
		            fnCreatedCell: function (nTd, sData, oData, iRow, iCol) {
		            	var html = "";
                        
                        html += "<a title='@lang('tr.View')' href='"+showURL.replace('#id', oData.id)+"'><i class='icon-eye'></i></i></a>&nbsp;";

                        @can('delete_coursefiles')
                        if(oData.status==0 || oData.status==8) {
                        	if(oData.active==0)
		            			html += "<a title='@lang('tr.Recover')' href='javascript:void(0)' class='recover_coursefiles'><i class='icon-undo2'></i></a>";
		            		else
		            			html += "<a title='@lang('tr.Delete')' href='javascript:void(0)' class='delete_coursefiles'><i class='icon-delete'></i></a>";
	            		}
		            	@endcan

                        $(nTd).html("<span class='action-column'>" + html + "</span>");
		            }
		        },
		  	],
		  	"searchCols": [
		  		{ "search": "{{ $currentTermID }}" },
		  	]
	    });

	    function showStatistics(item, value, total) {
	    	item.find('.stats-label').html(Math.round(100*value/total)+"%");
	        item.find('.total').html(value);
	    }

	    table.on('xhr.dt', function ( e, settings, json, xhr ) {
			console.log(json.count_new);
	        showStatistics($('#remaining'), json.count_new, json.count_total);
	        showStatistics($('#submitted'), json.count_submitted, json.count_total);
	        showStatistics($('#rejected'), json.count_rejected, json.count_total);
	        showStatistics($('#holded'), json.count_holded, json.count_total);
	        showStatistics($('#reviewed'), json.count_reviewed, json.count_total);
	        showStatistics($('#approved'), json.count_approved, json.count_total);
	    });

	    $(".dataTables_filter").hide();

	    $('#term_id').on('change', function () {
	    	
	    	if($(this).val()=="") {
	    		$("#term_action").hide();
	    		$("#term_statistics").hide();
	    		$("#term_name").text('@lang('tr.All')');
	    		$('#search_button').trigger('click');
	    	} else {
	    		$("#term_action").show();
	    		$("#term_statistics").show();
	    		$("#term_name").text($(this).find(":selected").text());
	    		var editLink = '{{ route('edit_term', ['id'=>'#term_id', 'section'=>'course_files']) }}';
				var courseFilesUrl = "{{ route("course_files_report",['termID' => '#term_id']) }}";
	    		$("#term_edit_action").attr('href', editLink.replace('#term_id', $(this).val()));
				$("#course_files_report").attr('href',courseFilesUrl.replace('#term_id',$(this).val()));
				$('#search_button').trigger('click');
	    	}
		});

		$('#term_id').trigger('change');

	    $('#search_button').on('click', function () {
		    table.search($("#text_search").val());
		    table.columns(0).search($("#term_id").val());
		    table.columns(1).search($("#status").val());
		    table.columns(2).search($("#bylaw_id").val());
		    table.columns(3).search($("#offering_department_id").val());
		    table.columns(4).search($("#plan_id").val());
		    table.draw();
		} );

		$('#text_search').on('keyup', function (e){
			if(e.keyCode == 13)
				$('#search_button').trigger('click');
		});

		$('#reset_button').on('click', function () {
			$("#text_search").val("");
			$("#term_id").val({{$currentTermID}});
			$("#offering_department_id").val("");
			$("#plan_id")[0].selectize.clear();
			$("#status").val("");
			$("#bylaw_id").val("");
			$('#search_button').trigger('click');
		} );

		$(document).on("click", ".delete_coursefiles", function () {
	        var deleteURL = '{{ route('delete_coursefiles', ['id'=>'#id']) }}';
	        var row = $(this).closest('tr');
	        var data = table.row(row).data();
	        var url = deleteURL.replace('#id', data.id);
	        var message = "Are you sure you want to move course files task (<B>"+data.id+"</B>) to the temporary trash?";

	        warningBox(message, function() {
	            $.post(url, {"_token": '{{ csrf_token() }}' }, function(data, status){
	                table.row("#"+data.id).remove().draw(false);
	                infoBox('@lang('tr.DeletedSuccessfully')');
	            });
	        });
	    });

	    $(document).on("click", ".recover_coursefiles", function () {
	        var deleteURL = '{{ route('recover_coursefiles', ['id'=>'#id']) }}';
	        var row = $(this).closest('tr');
	        var data = table.row(row).data();
	        var url = deleteURL.replace('#id', data.id);
	        var message = "Are you sure you want to recover course files task (<B>"+data.id+"</B>) from trash?";

	        warningBox(message, function() {
	            $.post(url, {"_token": '{{ csrf_token() }}' }, function(data, status){
	                table.row("#"+data.id).remove().draw(false);
	                infoBox('@lang('tr.DeletedSuccessfully')');
	            });
	        });
	    });

	});

    $('#remind_staff').on('click',function (event) {
        event.preventDefault();
        $.ajax({
            url: "{{ route("remind_staff") }}",
            success: function () {
                swal('Reminding Emails Sent Successfully',{icon: 'success'});
            }
        });
    });

    $('#remind_dqa').on('click',function (event) {
        event.preventDefault();
        $.ajax({
            url: "{{ route("remind_dqa") }}",
            success: function () {
                swal('Reminding Emails Sent Successfully',{icon: 'success'});
            }
        });
    });

    
</script>
@endsection