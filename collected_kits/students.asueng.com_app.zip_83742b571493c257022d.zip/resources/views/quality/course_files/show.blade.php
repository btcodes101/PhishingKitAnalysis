@extends('layouts.master')

@section('title', $courseFilesTask->course->code.": ".$courseFilesTask->course->lang('name'))
@section('subtitle', __('tr.Course Files Upload Task') )
@section('titleicon', "icon-point-of-interest-outline" )

@if($courseFilesTask->canUndo())
    @section('actiontitle', __('tr.Undo'))
    @section('actionlink', route('undo_course_files', ['id'=>$courseFilesTask->id]))
@endif

@section('content')
    <div class="main-content">
        <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                @if($courseFilesTask->term->isCourseFilesScheduled())

                    @if($courseFilesTask->term->isCourseFilesOpenSoon())
                        <div class="alert alert-info">
                            <i class="icon-info-large"></i> <strong class='danger'>@lang('tr.Information')!</strong> @lang('tr.Course files upload process will start at') <strong>{{ $courseFilesTask->term->course_files_start_date}}</strong>.
                        </div>
                    @elseif($courseFilesTask->term->isCourseFilesOpen())
                        <div class="alert">
                            <i class="icon-info-large"></i> <strong class='danger'>@lang('tr.Information')!</strong> @lang('tr.Course files upload process will close at') <strong>{{ $courseFilesTask->term->course_files_due_date}}</strong>.
                        </div>
                    @elseif($courseFilesTask->term->isCourseFilesClosed())
                        <div class="alert">
                            <i class="icon-info-large"></i> <strong class='danger'>@lang('tr.Information')!</strong> @lang('tr.Course files upload process closed at') <strong>{{ $courseFilesTask->term->course_files_due_date}}</strong>.
                        </div>
                    @endif

                    @if($courseFilesTask->isNew())
                        <div class="alert">
                            <i class="icon-flash"></i> <strong class='danger'>@lang('tr.Important')!</strong> @lang('tr.Please submit your course files before')
                        </div>
                    @elseif($courseFilesTask->isNotApproved())
                        <div class="alert bg-danger text-white">
                            <i class="icon-error"></i> <strong class='danger'>@lang('tr.Not Approved')!</strong> @lang('tr.Course files are not approved.')
                            @if($courseFilesTask->canSubmit())
                                @lang('tr.Update is required.')
                            @endif
                            @if($courseFilesTask->status_comment)
                            <hr>
                            @lang('tr.Reason')!</strong> {!! formatMultiline($courseFilesTask->status_comment) !!}
                            @endif
                        </div>                                     
                    @elseif($courseFilesTask->isApproved())
                        <div class="alert bg-success text-white">
                            <i class="icon-tick"></i> <strong class='danger'>@lang('tr.Congratulation')!</strong> @lang('tr.Course files are approved.')
                            @if($courseFilesTask->status_comment)
                            <hr>
                            @lang('tr.Reason')!</strong> {!! formatMultiline($courseFilesTask->status_comment) !!}
                            @endif
                        </div>
                    @elseif($courseFilesTask->isHeld())
                        <div class="alert bg-warning text-white">
                            <i class="icon-warning"></i> <strong class='danger'>@lang('tr.Held')!</strong> @lang('tr.Course files are held.')
                            @if($courseFilesTask->status_comment)
                            <hr>
                            @lang('tr.Reason')!</strong> {!! formatMultiline($courseFilesTask->status_comment) !!}
                            @endif
                        </div>
                    @elseif($courseFilesTask->isNotAccepted())
                        <div class="alert bg-danger text-white">
                            <i class="icon-error"></i> <strong class='danger'>@lang('tr.Not Accepted')!</strong> @lang('tr.Course files are not accepted.')
                            @if($courseFilesTask->status_comment)
                            <hr>
                            @lang('tr.Reason')!</strong> {!! formatMultiline($courseFilesTask->status_comment) !!}
                            @endif
                        </div>
                    @elseif(($courseFilesTask->isReviewer() || $courseFilesTask->isQA()) && $courseFilesTask->isReviewed())
                        <div class="alert alert-info">
                            <i class="icon-tick"></i> <strong class='danger'>@lang('tr.Information')!</strong> @lang('tr.Course files are approved by reviewer.')
                        </div>
                    @else
                        <div class="alert alert-info">
                            <i class="icon-info-large"></i> <strong class='danger'>@lang('tr.Information')!</strong> @lang('tr.Course files are under revision.')
                        </div>
                    @endif

                    
                @else
                    <div class="alert alert-info">
                        <i class="icon-info-large"></i> <strong class='danger'>@lang('tr.Information')!</strong> @lang('tr.Course files submission will be scheduled soon.')
                    </div>
                @endif
            </div>

            {{--Teachers--}}
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header" role="tab" id="cardheadingTwo">
                        <a data-toggle="collapse" href="#collapseCardTwo" aria-expanded="true" aria-controls="collapseCardTwo" class="">
                            <span class="icon-media-play"></span> @lang('tr.Teachers')
                        </a>
                    </div>
                    {{-- new Table --}}

                    <div id="collapseCardTwo" class="collapse show" role="tabpanel" aria-labelledby="cardheadingTwo" style="">
                        <div class="card-body">
                            <table id="show" class="table table-responsive" style="width: 100%;" role="grid" aria-describedby="example_info">
                                <thead>
                                <tr role="row">
                                    <th>@lang('tr.Name')</th>
                                    <th>@lang('tr.Mobile')</th>
                                    <th>@lang('tr.Email')</th>
                                    <th>@lang('tr.Department')</th>
                                </thead>

                                <tbody>
                                @foreach( $courseFilesTask->teachers() as $user )
                                    <tr role="row" class="odd">

                                        {{--Name--}}
                                        <td><i class='icon-user'></i>&nbsp;<a href='{{ route('show_instructor', ['id'=>$user->id]) }}'>{{ $user->lang('name') }}</a></td>

                                        {{--Mobile--}}
                                        <td>{{ $user->mobile }}</td>

                                        {{--Email--}}
                                        <td>{{ $user->email }}</td>

                                        {{--Department--}}
                                        <td>{{ ($user->instructor)?$user->instructor->department->lang('name'):"" }}</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                @include('system.archive.component', ['name'=>'archive1', 'archive'=>\App\Archive::find($courseFilesTask->getArchiveID()) ,'pathName'=>'Course Files','addFolders'=>false, 'addPages'=>false, 'readOnly'=>!$courseFilesTask->canSubmit(), 'actAsOwner'=>$courseFilesTask->canSubmit()])
            </div>

            @php($statusHistory = $courseFilesTask->getAllowedStatusHistory())
            @if(count($statusHistory)>0)
            {{--Teachers--}}
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        @lang('tr.Comments')
                    </div>
                    <div class="card-body">
                        <div class="media overflow-scroll">
                            <div class="media-body">
                            @foreach( $statusHistory as $item )
                                <div class="media mt-3">
                                    <div class="mr-3">
                                        <a href="{{ route('show_profile',['id'=>$item->user->id]) }}">
                                            <span class="media-object">
                                                <img style="width: 48px;height: 48px" class="ticket_avatar" alt="48x48" src="/img/user.png">
                                            </span>
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <h5 class="mt-0 media-heading"><a style="color:#4266b2;" href="{{ route('show_profile',['id'=>$item->user->id]) }}">{{ $item->user->lang('name') }}</a> ({{ \App\CourseFilesTask::statusTypes()[$item->status] }})
                                            <span class="date" style="border: none;padding: 0px;">{{ timeFrom($item->submitted_at) }}</span>
                                        </h5>
                                        <p>{!! formatMultiline($item->status_comment) !!}</p>
                                    </div>
                                </div>
                            @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif

    @can('show_coursefiles')
        {{--Submit or Update Status--}}
        @if($courseFilesTask->canSubmit())
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        @if($courseFilesTask->status == 0 )
                            @lang('tr.Course Files Upload Status')
                        @else
                            @lang('tr.Course Files Update Status')
                        @endif
                    </div>
                    <div class="card-body">
                        <form action="{{ route('action_course_files', ['id'=>$courseFilesTask->id]) }}" method="POST" id='action_form'>
                            {{ csrf_field() }}
                            <div class="form-group">
                                <div class="input-group">
                                    <div style="display: inline-block; vertical-align: middle; padding: 10px">
                                        <input type="checkbox" name="status_confirm" id='status_confirm' value="confirm">
                                    </div>
                                    <div style="display: inline-block; vertical-align: middle; color: darkgreen; font-weight: bold; padding: 8px;">
                                        @lang('tr.CourseFilesUploadConfirmMessage')
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <textarea name="status_comment" type="text" class="form-control form-control-lg" placeholder="@lang('tr.Comment')" rows="5"></textarea>
                            </div>
                            <button type="submit" id="action_submit" class="btn float-right btn-success">@lang('tr.Submit')</button>
                        </form>
                    </div>
                </div>
            </div>
        @endif

        {{--Edit Review Status--}}
        {{--@php(dd($courseFilesTask->canReview()))--}}
        @if($courseFilesTask->canReview())
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header">@lang('tr.Course Files Review Status')</div>
                    <div class="card-body">
                        <form action="{{ route('action_course_files', ['id'=>$courseFilesTask->id]) }}" method="POST" id='action_form'>
                            {{ csrf_field() }}                            
                            <div class="form-group">
                                {!! Form::select('status', array(''=>__('tr.Select Decision'))+$courseFilesTask->reviewerDecisionList(), null, array('id'=> 'status', 'title'=> __('Decision'), 'class'=>'form-control', 'required'=>'required' )) !!}
                            </div>
                            <div class="form-group">
                                <textarea name="status_comment" type="text" class="form-control form-control-lg" placeholder="@lang('tr.Comment')" rows="5"></textarea>
                            </div>
                            <button type="submit" id="action_submit" class="btn float-right btn-success">@lang('tr.Submit')</button>
                        </form>
                    </div>
                </div>
            </div>
        @endif

        {{--Approve Status--}}
        @if($courseFilesTask->canApprove())
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header">@lang('tr.Course Files Approve Status')</div>
                    <div class="card-body">
                        <form action="{{ route('action_course_files', ['id'=>$courseFilesTask->id]) }}" method="POST" id='action_form'>
                            {{ csrf_field() }}
                            <div class="form-group">
                                {!! Form::select('status', array(''=>__('tr.Select Decision'))+$courseFilesTask->qaDecisionList(), $courseFilesTask->statusDecision(), array('id'=> 'status', 'title'=> __('Decision'), 'class'=>'form-control', 'required'=>'required' )) !!}
                            </div>
                            <div class="form-group">
                                <textarea name="status_comment" type="text" class="form-control form-control-lg" placeholder="@lang('tr.Comment')" rows="5"></textarea>
                            </div>
                            <button type="submit" id="action_submit" class="btn float-right btn-success">@lang('tr.Submit')</button>
                        </form>
                    </div>
                </div>
            </div>
            @endif
            @endif
            </div>
            </div>
@endsection

@section('pagejs')
    <script type="text/javascript">

        $(document).ready(function() {

            $(document).on("change", "#status", function () {
                if($(this).val()=="1"||$(this).val()=="2"||$(this).val()=="3") {
                    $('#action_submit').prop('disabled', false);
                } else {
                    $('#action_submit').prop('disabled', true);
                }
            });

            $(document).on("change", "#status_confirm", function () {
                if($(this).is(":checked") && $('[id*="archive1"]').find('#data_table').find("tbody tr[role='row']").length) {
                    $('#action_submit').prop('disabled', false)
                } else {
                    $('#action_submit').prop('disabled', true);
                }
            });

            $("#status_confirm").trigger("change");
            $("#status").trigger("change");
        });
    </script>
@endsection