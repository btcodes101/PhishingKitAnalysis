@extends('layouts.master')

@section('title', __("tr.Quality Team"))
@section('subtitle', __("tr.Show quality team members"))
@section('titleicon', "icon-user" )

@section('content')

	<!-- Add Member -->
    <div class='modal fade' id='add_member_modal' tabindex='-1' role='dialog' aria-labelledby='add_member_modal' aria-hidden='true'>
        <form action="{{route('add_quality_member')}}" method="post">
            {{ csrf_field() }} 
            <div class='modal-dialog' role='document'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <h5 class='modal-title' id='modal_label'>@lang('tr.Add Member')</h5>
                        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                        </button>
                    </div>
                    <div class='modal-body'>                        
                        <div class="form-group">
                            <select class="selectize" id="user_id" name="user_id">
                                <option value="">@lang('tr.Select Member')</option>
                            </select>
                        </div>
                        <div class="form-group">
                            {!! Form::select('role', array(""=>__("tr.Select Role"))+$roles, null, array('id'=> 'role', 'class'=>'form-control', 'title'=> __('tr.Role'), 'class selectize'=>'form-control', 'required'=>'required')) !!}
                        </div>
                    </div>
                    <div>
                        <div id='progress_bar' style="background-color: green; width: 0%; height: 2px;"></div>
                    </div>
                    <div class='modal-footer'>
                        <button type='submit' class='btn btn-primary' id='action'>@lang('tr.Submit') <span id="progress_text"></span></button>
                        <button type='button' class='btn btn-light' id='close' data-dismiss='modal'>@lang('tr.Cancel')</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

	<div class="main-content">
		<div class="row gutters">

			{{--Heads--}}
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<div class="card">
					<div class="card-header">
						@lang('tr.Quality Management')

						@can('admin_quality')
						<button id='add_member' type="button" class="btn btn-primary btn-sm float-right">
							@lang('tr.Add Member')
						</button>
						@endcan
					</div>

					{{-- Table --}}					
					<div class="card-body">
						<table id="manage-team"  class="display" style="width: 100%;" role="grid" aria-describedby="example_info">
							<thead>
							<tr role="row">
								<th>@lang('tr.Name')</th>
								<th>@lang('tr.Position')</th>
								<th>@lang('tr.Mobile')</th>
								<th>@lang('tr.Email')</th>
								<th>@lang('tr.Department')</th>
								<th width="50px"></th>
							</thead>

							<tbody>
							<tr role="row" class="odd">
								
								{{--Name--}}
								<td><i class='icon-user'></i>&nbsp;{{ $qaHead->lang('name') }}</td>

								{{--Position--}}
								<td><span class="badge badge-success">Head</span></td>

								{{--Mobile--}}
								<td>{{ $qaHead->mobile }}</td>

								{{--Email--}}
								<td>{{ $qaHead->email }}</td>

								{{--Department--}}
								<td>{{ $qaHead->instructor->department->lang('name') }}</td>

								<td class="action-column">
								@can('access_instructors')
									<a title='View' href='{{ route('show_instructor', ['user_id'=>$qaHead->id]) }}'>
										<i class='icon-eye'></i>
									</a>
								@endcan
								</td>
							</tr>
							@foreach( $qaViceHeads as $user )
								<tr role="row" class="odd" id='{{$user->id}}'>
									
									{{--Name--}}
									<td class="name"><i class='icon-user'></i>&nbsp;{{ $user->lang('name') }}</td>

									{{--Position--}}
									<td><span class="badge badge-secondary">Vice Head</span></td>

									{{--Mobile--}}
									<td>{{ $user->mobile }}</td>

									{{--Email--}}
									<td>{{ $user->email }}</td>

									{{--Department--}}
									<td>{{ $user->instructor->department->lang('name') }}</td>

									<td class="action-column">
									@can('access_instructors')
										<a title='View' href='{{ route('show_instructor', ['user_id'=>$user->id]) }}'>
											<i class='icon-eye'></i>
										</a>
									@endcan	
									@can('admin_quality')
										<a title='Delete' class='remove_member' role='VICEQA' href='javascript:void(0)'>
											<i class='icon-delete'></i>
										</a>											
									@endcan									
									</td>
								</tr>
							@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>

			{{--DQAs--}}
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<div class="card">
					<div class="card-header">
						@lang('tr.DQA Members')
					</div>
					<div class="card-body">
						<table id="dqa-team" class="display" style="width: 100%;" role="grid" aria-describedby="example_info">
							<thead>
							<tr role="row">
								<th>@lang('tr.Name')</th>
								<th>@lang('tr.Mobile')</th>
								<th>@lang('tr.Email')</th>
								<th>@lang('tr.Department')</th>
								<th width="30px"></th>
							</thead>

							<tbody>
							@foreach( $dqas as $user )
								<tr role="row" class="odd" id='{{$user->id}}'>
									
									{{--Name--}}
									<td class="name"><i class='icon-user'></i>&nbsp;{{ $user->lang('name') }}</td>

									{{--Mobile--}}
									<td>{{ $user->mobile }}</td>

									{{--Email--}}
									<td>{{ $user->email }}</td>

									{{--Department--}}
									<td>{{ $user->instructor->department->lang('name') }}</td>

									<td class="action-column">
									@can('access_instructors')
										<a title='View' href='{{ route('show_instructor', ['user_id'=>$user->id]) }}'>
											<i class='icon-eye'></i>
										</a>
									@endcan
									@can('admin_quality')
										<a title='Delete' class='remove_member' role='DQA' href='javascript:void(0)'>
											<i class='icon-delete'></i>
										</a>
									@endcan
									</td>
								</tr>
							@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>

			{{--Start PQAs--}}
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<div class="card">
					<div class="card-header">
						@lang('tr.PQA Members')
					</div>

					{{-- Table --}}
					<div class="card-body">
						<table id="pqa-team" class="display" style="width: 100%;" role="grid" aria-describedby="example_info">
							<thead>
							<tr role="row">
								<th>@lang('tr.Name')</th>
								<th>@lang('tr.Mobile')</th>
								<th>@lang('tr.Email')</th>
								<th>@lang('tr.Department')</th>
								<th width="30px"></th>
							</thead>

							<tbody>
							@foreach( $pqas as $user )
								<tr role="row" class="odd" id='{{$user->id}}'>
									
									{{--Name--}}
									<td class="name"><i class='icon-user'></i>&nbsp;{{ $user->lang('name') }}</td>

									{{--Mobile--}}
									<td>{{ $user->mobile }}</td>

									{{--Email--}}
									<td>{{ $user->email }}</td>

									{{--Department--}}
									<td>{{ $user->instructor->department->lang('name') }}</td>

									<td class="action-column">
									@can('access_instructors')
										<a title='View' href='{{ route('show_instructor', ['user_id'=>$user->id]) }}'>
											<i class='icon-eye'></i>
										</a>
									@endcan
									@can('admin_quality')
										<a title='Delete' class='remove_member' role='PQA' href='javascript:void(0)'>
											<i class='icon-delete'></i>
										</a>
									@endcan
									</td>
								</tr>
							@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>
			{{--End PQAs--}}

			{{--Start Assistants--}}
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<div class="card">
					<div class="card-header">
						@lang('tr.Assistants')
					</div>

					{{-- Table --}}
					<div class="card-body">
						<table id="assistants-team" class="display" style="width: 100%;" role="grid" aria-describedby="example_info">
							<thead>
							<tr role="row">
								<th>@lang('tr.Name')</th>
								<th>@lang('tr.Mobile')</th>
								<th>@lang('tr.Email')</th>
								<th width="30px"></th>
							</thead>

							<tbody>
							@foreach( $assistants as $user )
								<tr role="row" class="odd" id='{{$user->id}}'>
									
									{{--Name--}}
									<td class="name"><i class='icon-user'></i>&nbsp;{{ $user->lang('name') }}</td>

									{{--Mobile--}}
									<td>{{ $user->mobile }}</td>

									{{--Email--}}
									<td>{{ $user->email }}</td>

									<td class="action-column">
									@can('access_instructors')
										<a title='View' href='{{ route('show_employee', ['user_id'=>$user->id]) }}'>
											<i class='icon-eye'></i>
										</a>
									@endcan
									@can('admin_quality')
										<a title='Delete' class='remove_member' role='QAASSISTANT' href='javascript:void(0)'>
											<i class='icon-delete'></i>
										</a>
									@endcan
									</td>
								</tr>
							@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>
			{{--End PQAs--}}

		</div>
	</div>
@endsection

@section('pagejs')
	<script type="text/javascript">
		$(document).ready(function() {
		    $('#manage-team').DataTable({
		    	paging: false,
		    	bInfo: false,
		    	ordering: false,
			});
			$(".dataTables_filter").hide();
		    $('#dqa-team').DataTable();
		    $('#pqa-team').DataTable();
		    $('#assistants-team').DataTable();

		    var removeUrl = '{{ route('remove_quality_member', ['id'=>'#id', 'role'=>'#role'])}}';

		    $(document).on("click", ".remove_member", function(){
		    	var id = $(this).closest('tr').attr("id");
		    	var name = $(this).closest('tr').find('.name').text();
				var role = $(this).attr("role");
				var url = removeUrl.replace('#id', id).replace('#role', role);
				var message = "Are you sure you want to delete (<B> "+name+" </B>) from (<B> "+role+" </B>) role?";

				warningBox(message, function() {
					$.get(url, function(response){
						location.reload();
				    }).fail(function(response) {
					    showRepsonseErrors(response);
				  	});
				});
		    });

		    function initUsers(element) {

				return element.selectize({
	                valueField: 'id',
	                labelField: 'name',
	                searchField: 'search',
	                plugins: ['remove_button'],
	                options: [],
	                create: false,
	                render: {
	                    option: function(item, escape) {
	                        return "<div style='padding:5px;'>"+escape(item.name)+"</div>";
	                    }
	                },
	                load: function(query, callback) {
	                    if (!query.length) return callback();
	                    var namesUrl = '{{ route('users_names', ['types'=>'1,2']) }}';
	                    $.ajax({
	                        url: namesUrl,
	                        type: 'GET',
	                        dataType: 'jsonp',
	                        jsonp: 'callback',
	                        jsonpCallback: 'callback',
	                        data: {
	                            query: query,
	                            limit: 10
	                        },
	                        error: function() {
	                            callback();
	                        },
	                        success: function(res) {
	                            callback(res);
	                        }
	                    });
	                }
	            });
			}


            $(document).on("click", "#add_member", function () {
                var modal = $('#add_member_modal').clone();
                modal.execModal({
                    progressBar: 'progress_bar',
                    progressText: 'progress_text',
                }, function(response) {
                    location.reload();
                }, function(response) {
                    showRepsonseErrors(response);
                }, function(dialog){
                    initUsers(dialog.find('#user_id'));
                });
            });
		});
    </script>
@endsection