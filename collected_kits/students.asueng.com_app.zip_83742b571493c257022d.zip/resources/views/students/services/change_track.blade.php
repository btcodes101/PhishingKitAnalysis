@extends('layouts.master')

@section('title',  __('tr.Change Track Preferences'))
@section('titleicon', "icon-file-text")

@section('content')
<div class="main-content">

	<form id="submit_form" action="{{ route('save_change_track') }}" method="POST">
		{{ csrf_field() }}
		<input type="hidden" name="request_id" value="{{($changeTrackPreference)?$changeTrackPreference->request_id:0}}">
        <div class="row">
            <div class="col-lg-7 col-xs-12 col-md-12 col-sm-12">
            	<div class="card">
					<div class="card-header">@lang('tr.Change Track Preferences')</div>
					<div class="card-body">

						<div class="form-group">
                            <label class="col-form-label">@lang('tr.Required Track')</label>
                            {!! Form::select('plan_id', array(''=>__('tr.Select Track'))+$plans, ($changeTrackPreference)?$changeTrackPreference->to_plan_id:null, array('id'=> 'plan_id', 'class'=>'form-control', 'required'=>'required' )) !!}
                        </div>

				        <div class="form-check">
							<label class="form-check-label">
								<input class="form-check-input" type="checkbox" name="first_attempt" value="first_attempt" required>
								@lang('tr.I acknowledge this is the first attempt to change my study track.')
							</label>
						</div>

					<!--	<div class="form-check">
							<label class="form-check-label">
								<input class="form-check-input" type="checkbox" name="change_to_2018" value="change_to_2018" required>
								@lang('tr.I accept to switch to bylaw 2018.')
							</label>
						</div> -->

					</div>
			        
			    </div>
			    <hr/>
			    <button type="submit" id="submit" class="btn btn-primary btn-md"> @if($changeTrackPreference) @lang('tr.Update') @else @lang('tr.Submit') @endif <span id="ajax_form_progress_text"></span></button>
			</div>
		</div>        

	</form>
	<br/>
	<br/>
</div>

@endsection