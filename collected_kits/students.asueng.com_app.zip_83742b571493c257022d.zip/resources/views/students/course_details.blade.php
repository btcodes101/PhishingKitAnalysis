@extends('layouts.master')

@section('title', $course->lang('name'))
@section('subtitle', __('tr.CourseInfo') )
@section('titleicon', "icon-file-text")

<style>
	.filterHeader>input{
		background:white;
		width:100%;
		border-top:1px solid black;
		padding:5px;
		color:green;
		font-weight:bold;
		margin-top:5px;
	}

	.htDimmed{
		color: gray !important;
		font-weight: bold !important;
	}

</style>

@section('content')
	<div class="main-content">
		<div class="row gutters ComBody">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<div class="card">
					<div class="card-header" role="tab" id="cardheadingOne">
						<a data-toggle="collapse" href="#collapseCardOne" aria-expanded="true" aria-controls="collapseCardOne" class="">
							<span class="icon-media-play"></span> @lang('tr.CourseInfo')&nbsp;({{$course->editStatusLabel()}})
						</a>
					</div>

					<div id="collapseCardOne" class="collapse show" role="tabpanel" aria-labelledby="cardheadingOne" style="">
						<div class="card-body">
							<table class="table table-striped m-0">
								<tbody>
								<tr>
									<th scope="row" width="150px" style="font-size:14px;">@lang('tr.Code')</th>
									<td>{{ $course->code }} (<span dir='rtl'>{{ $course->ar_code }}</span>)</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.EnglishName')</th>
									<td>{{ $course->en_name }}</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.ArabicName')</th>
									<td><div style="direction: rtl" >{{ $course->ar_name }}</div></td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.Term')</th>
									<td>{{ $course->termType() }}</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.Department')</th>
									<td>{{ $course->department->lang('name') }}</td>
								</tr>
								<tr>
									<th scope="row" style="font-size:14px;">@lang('tr.Bylaw')</th>
									<td>{{ $course->bylaw }}</td>
								</tr>
								
								@if(mb_strlen($course->en_describtion)>0)
									<tr>
										<td colspan="2">
											<B>Englis Describtion</B><BR/><BR/>
											{{ $course->en_describtion }}
										</td>
									</tr>
								@endif
								@if(mb_strlen($course->ar_describtion)>0)
									<tr>
										<td colspan="2">
											<B>Arabic Describtion</B><BR/><BR/>
											{{ $course->ar_describtion }}
										</td>
									</tr>
								@endif
								@if(mb_strlen($course->references)>0)
									<tr>
										<td colspan="2">
											<B>@lang('tr.References')</B><BR/><BR/>
											<ul>
												@foreach($course->allReferences() as $reference)
													<li>{{ $reference }}</li>
												@endforeach
											</ul>
										</td>
									</tr>
								@endif
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>

		

	</div>

@endsection

@section('pagejs')
	
@endsection
