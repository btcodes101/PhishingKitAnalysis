@extends('layouts.master')


@section('subtitle', __('tr.CurrentTermCourses') )
@section('titleicon', "icon-user")


@section('content')  

@if($student->bylaw == 'UG2018')
     <div class="row gutters ComBody">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header" role="tab" id="cardheadingTwo">
                        <a data-toggle="collapse" href="#collapseStudentInformation" aria-expanded="true"
                           aria-controls="collapseCardTwo" class="">
                            <span class="icon-media-play"></span> @lang('tr.CurrentTermCourses')
                        </a>
                   
                    </div>

                    <div id="collapseStudentInformation" class="collapse show" role="tabpanel"
                         aria-labelledby="cardheadingTwo"
                         style="">
                        <div class="card-body">
                            <table class="table table-striped m-0">
                                <thead>
                                	<tr>
	                                    <th scope="row" width="180px">@lang('tr.CourseName')</th>
	                                    <th scope="row" width="180px">@lang('tr.CourseCode')</th>
	                                    <th scope="row" width="180px">@lang('tr.Section')</th>
	                                    
                                	</tr>
                                </thead>
                                <tbody>
                                	@foreach ($studentCourses as $studentCourse)
	                                	<tr>
	                                		<td>{{$studentCourse->en_name}}</td>
	                                		<td>{{$studentCourse->short_name}}</td>
	                                		<td>{{$studentCourse->group_name}}:{{$studentCourse->section_name}}</td>
	                                	</tr>
                                	@endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@else
<div class="row gutters ComBody">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="card-body"> 
                <p>Group: {{$student->excel_group_ug2003}}</p>
                <p>Section: {{$student->excel_section_ug2003}}</p>
            </div>
        </div>
    </div>
</div>
    
@endif
@endsection
