@extends('layouts.master')

@section('title',  __('tr.Confirm Certificates Request'))
@section('titleicon', "icon-file-text")

@section('content')
<div class="main-content">
	<div class="row">
        <div class="col-lg-8 col-xs-12 col-md-12 col-sm-12">
        	
        	<div class="card">
				<div class="card-header">@lang('tr.General Information')</div>
				<div class="card-body">
					<table class="table table-striped m-0">
		                <tr><td width="150px"><b>@lang('tr.English Name'):</b></td><td>{{$userRequest->data->en_name}}</td></tr>                
		                <tr><td><b>@lang('tr.Mobile'):</b></td><td>{{$userRequest->data->mobile}}</td></tr>                
		                <tr><td><b>@lang('tr.Provided to'):</b></td><td>{{$userRequest->data->apply_to}}</td></tr>
		                <tr>
		                    <td><b>@lang('tr.Documents'):</b></td>
		                    <td>
		                        @foreach($userRequest->archive->childrenFiles as $file)
		                            <a href="{{ route('secure_download_file')."?sid=".$file->secret() }}">{{$file->name()}}</a>, 
		                        @endforeach
		                    </td>
		                </tr>
                    	<tr><td width="150px"><b>@lang('tr.Total Fees'):</b></td><td>{{$userRequest->total_amount}}</td></tr>
		            </table>
				</div>
			</div>

			@if($userRequest->data->mail == 1)
			<div class="card">
				<div class="card-header">@lang('tr.Shipping Information')</div>
				<div class="card-body">
					<table class="table table-striped m-0">						
                    	<tr><td width="150px"><b>@lang('tr.Shipping Address'):</b></td><td>{{$userRequest->data->mail_address}}</td></tr>
                    	<tr><td width="150px"><b>@lang('tr.Shipping Cost'):</b></td><td>{{$userRequest->data->cost}}</td></tr>
		            </table>
				</div>
			</div>
            @endif

			<div class="card">
				<div class="card-header">@lang('tr.Certificates')</div>
				<div class="card-body">
					<table id='certificates_table' class="table table-striped">
		                <thead>
		                    <tr>
		                        <th>#</th>
		                        <th>@lang('tr.Certificate Type')</th>
		                        <th>@lang('tr.Number of Certificates')</th>
		                        <th>@lang('tr.Cost')</th>
		                        <th width="20%">@lang('tr.Total')</th>
		                    </tr>
		                </thead>
		                <tbody>
		                    @php($j = 1)
		                    @php($total = 0)
		                    @for($i=0; $i<count($userRequest->data->type); $i++)
		                    @if($userRequest->data->quantity[$i]>0)
		                    @php($certificateType = 'App\CertificateType'::find($userRequest->data->type[$i]))
		                    @php($total+=$certificateType->cost*$userRequest->data->quantity[$i])
		                    <tr>
		                        <td>{{ $j++ }}</td>
		                        <td>{{ $certificateType->lang('name') }}</td>
		                        <td>{{ $userRequest->data->quantity[$i] }}</td>
		                        <td>{{ $certificateType->cost }}</td>
		                        <td>{{ $certificateType->cost*$userRequest->data->quantity[$i] }}</td>
		                    </tr>
		                    @endif
		                    @endfor
		                </tbody>
		            </table>
				</div>
			</div>

		<hr/>
		@include('payments.components.pay')
		</div>
	</div>	
	<br/>
	<br/>
</div>
@endsection
