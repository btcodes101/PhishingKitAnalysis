@extends('layouts.master')

@section('title', __('tr.Profile') )
@section('subtitle', __('tr.ProfileInfo') )
@section('titleicon', "icon-user" )

@section('content')


<!-- END: .main-content -->
@stop