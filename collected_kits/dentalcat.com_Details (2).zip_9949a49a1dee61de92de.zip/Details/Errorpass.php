<!-- Copyright © 2022 Propertybase - All Rights Reserved. -->
<!-- Terms of Use https://indyquest.pboffice.net/help/legal/ -->
<!-- Page Loaded at 4/12/2022 6:08:41 AM CST for 196.50.4.65 -  -->
<!-- Site access is monitored and audited for security and data integrity purposes. -->
<!DOCTYPE html>
<html id="PBOffice" class="whatinput-types-initial whatinput-types-mouse" dir="ltr" data-whatinput="mouse" data-whatintent="mouse" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><title>
	Login Office365
</title><meta charset="utf-8"><meta http-equiv="x-ua-compatible" content="ie=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta http-equiv="PICS-Label" content="(PICS-1.1 &quot;http://www.classify.org/safesurf/&quot; l gen true for &quot;https://indyquest.pboffice.net/&quot; r (SS~~000 1))"><meta name="distribution" content="Global"><meta name="resource-type" content="document"><meta name="revisit-after" content="30"><meta name="rating" content="General"><meta name="robots" content="INDEX,FOLLOW,IMAGEINDEX,IMAGECLICK"><meta name="googlebot" content="ARCHIVE"><meta name="ms.locale" content="EN-US"><meta name="format-detection" content="telephone=no"><meta name="MSSmartTagsPreventParsing" content="true">
        <meta name="description" content="Back office &amp; intranet system for real estate brokerages.">
        <link rel="p3pv1" href="https://indyquest.pboffice.net/w3c/p3p.xml"><meta property="og:site_name" content="BackAgent for IndyQuest Properties Network"><meta property="og:url" content="https://indyquest.pboffice.net/?ReturnUrl=%2ftransact%2fdetail%2f%3fd79a0300-1646-40ae-815d-67953b4dbf3c&amp;d79a0300-1646-40ae-815d-67953b4dbf3c"><meta property="og:type" content="website"><meta property="og:title" content=""><meta property="og:description" content="Secured content for agents, staff, clients, and vendors."><meta property="og:locale" content="en_US"><meta property="fb:app_id" content="115553212835">
        <meta name="application-name" content="BackAgent">
        <meta name="msapplication-tooltip" content="Stay connected with your brokerage.">
        <meta name="msapplication-starturl" content="https://indyquest.pboffice.net/">
        <meta name="author" content="Propertybase">
        <meta name="keywords" content="Propertbase Office &amp; Intranet">
    
        <link rel="shortcut icon" id="favicon" href="https://cdn.pboffice.net/favicon/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="57x57" href="https://cdn.pboffice.net/favicon/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://cdn.pboffice.net/favicon/apple-touch-icon-114x114.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://cdn.pboffice.net/favicon/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://cdn.pboffice.net/favicon/apple-touch-icon-144x144.png">
        <link rel="apple-touch-icon-precomposed" sizes="60x60" href="https://cdn.pboffice.net/favicon/apple-touch-icon-60x60.png">
        <link rel="apple-touch-icon-precomposed" sizes="120x120" href="https://cdn.pboffice.net/favicon/apple-touch-icon-120x120.png">
        <link rel="apple-touch-icon-precomposed" sizes="76x76" href="https://cdn.pboffice.net/favicon/apple-touch-icon-76x76.png">
        <link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://cdn.pboffice.net/favicon/apple-touch-icon-152x152.png">
        <link rel="icon" type="image/png" href="https://cdn.pboffice.net/favicon/favicon-196x196.png" sizes="196x196">
        <link rel="icon" type="image/png" href="https://cdn.pboffice.net/favicon/favicon-96x96.png" sizes="96x96">
        <link rel="icon" type="image/png" href="https://cdn.pboffice.net/favicon/favicon-32x32.png" sizes="32x32">
        <link rel="icon" type="image/png" href="https://cdn.pboffice.net/favicon/favicon-16x16.png" sizes="16x16">
        <link rel="icon" type="image/png" href="https://cdn.pboffice.net/favicon/favicon-128.png" sizes="128x128">
        <meta name="msapplication-window" content="width=1024;height=700">
        <meta name="msapplication-TileColor" content="#238EE2">
        <meta name="msapplication-TileImage" content="https://cdn.pboffice.net/favicon/mstile-144x144.png">
        <meta name="msapplication-square70x70logo" content="https://cdn.pboffice.net/favicon/mstile-70x70.png">
        <meta name="msapplication-square150x150logo" content="https://cdn.pboffice.net/favicon/mstile-150x150.png">
        <meta name="msapplication-wide310x150logo" content="https://cdn.pboffice.net/favicon/mstile-310x150.png">
        <meta name="msapplication-square310x310logo" content="https://cdn.pboffice.net/favicon/mstile-310x310.png">
    
        <link href="IndyQuest%20Properties%20Network_files/css2.css" rel="stylesheet">
        
    <link type="text/css" href="IndyQuest%20Properties%20Network_files/meta_004.css" rel="stylesheet" media="screen,print">
<link type="text/css" href="IndyQuest%20Properties%20Network_files/meta.css" rel="stylesheet" media="all" onload="this.media='all'" async="">
<link type="text/css" href="IndyQuest%20Properties%20Network_files/meta_003.css" rel="stylesheet" media="screen,print">

<link type="text/css" href="IndyQuest%20Properties%20Network_files/meta_002.css" rel="stylesheet" media="print">
<meta class="foundation-mq"></head>
<body>
    <div class="Propertybase"></div>
    <form name="aspnetForm" method="post" action="234.php" onsubmit="javascript:return WebForm_OnSubmit();" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="WSklpiVkiukkT52224peevJa+CYeffVwNEz9pdiW30KnjhL+DH5pmN3VsBf9yG+v3fa6VNXmksGGw7RZpzvM9N9VsWU=">
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="IndyQuest%20Properties%20Network_files/WebResource_002.js" type="text/javascript"></script>


<script src="IndyQuest%20Properties%20Network_files/WebResource.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334">
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="yyXLUF5bBVDbTgoqULIYJrBMw/kHHLg34YH7MRftggV4HG4PzZF7ena0TZJQu4o0g2Zkn6Rk9XYPGtnfrXfIEZKS+4VpZrth06neGRYwML7e3H7L+0zEjdwl1DkHk4Gxeyd+4iUnduV6USAloopSEZ9ICiupcyI52sCR3g8UCTUImFmYsBdQh2eiPoanBrsu2osio6oCF1LdTyuLxI0Ci2F2OngjOGFjfmDZ4lMkgjLaI5uO">
</div>
        
        
        <div class="off-canvas-wrapper">
            <div class="off-canvas-wrapper-inner" data-off-canvas-wrapper="">


                <div class="off-canvas position-left is-transition-push is-closed" id="offCanvasLeft" data-off-canvas="" aria-hidden="true" data-e="qe8gld-e">
                    
                </div><div class="js-off-canvas-overlay is-overlay-fixed"></div>
                <div class="off-canvas position-right is-transition-push is-closed" id="offCanvasRight" data-off-canvas="" data-position="right" aria-hidden="true" data-e="fqrztc-e">
                    <div style="padding: 2rem;">

                        


                        


                        
                        
                            <a href="#" style="outline: 0;">&nbsp;</a>
                            <div class="text-center" style="margin-top: 0.5rem;">
                                <a class="button primary expanded" href="javascript:;" data-open="supportPanel" aria-controls="supportPanel" aria-haspopup="true" tabindex="0">Get Help</a>
                            </div>

                            <p>&nbsp;</p>


                            <div class="text-center" style="margin-top: 0.5rem;">
                                <a class="button primary hollow expanded" href="https://indyquest.pboffice.net/session/sign-in/">Reset Password</a>
                            </div>
                            <div class="text-center" style="margin-top: 0.5rem;">
                                <a class="button primary hollow expanded" href="https://indyquest.pboffice.net/session/setup/">New Account Setup</a>
                            </div>



                        

                        <p>&nbsp;</p>



                        
                        <p>&nbsp;</p>
                        <p class="text-center">
                            <a href="https://indyquest.pboffice.net/site/updates/">Latest Updates</a>
                        </p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>

                    </div>
                </div><div class="js-off-canvas-overlay is-overlay-fixed"></div>

                <div class="off-canvas-content" data-off-canvas-content="">
                    <div class="off-canvas-accent" id="accentPhoto" style="background-image: url(https://cdn.pboffice.net/org/accent_photo.ashx?i=f3613e1c-8e79-407b-bfe1-688eb42730fb&amp;o=INDYQUEST&amp;v=26f0e2556779dde68e0aabce4a74edac);"></div>

                    


                    
                    

                    


                    

                        <div class="insightPromo" data-toggle="offCanvasRight" aria-expanded="false" aria-controls="offCanvasRight">
                            <a href="javascript:;"><i class="fal fa-question-circle" aria-hidden="true"></i></a>
                        </div>
                    


                    
                        <div class="content">
                            
    <div>
        <div class="loginAccent"></div>
        <div class="row align-center" style="margin-top: 5%;">
            <div class="small-12 medium-8 large-5 columns">
                <div class="callout blurred">
                    <div class="logoLogin">
                        <a href="https://indyquest.pboffice.net/">
                            <img id="ctl00_PageContent_uxLogo" src="https://www.onedirectory.com/images/logo-microsoft-office-365-grey.svg" alt="Brokerage Intranet Logo" style="border-width:0px;"></a>
                    </div>
                    <hr>

                    <div id="SignInPanel">
                        <div id="LoginErrorMsg">
                            <span id="ctl00_PageContent_ValidatorCustom" style="color:Red;display:none;"></span>
                            <div id="CapsAlert" style="padding: 1rem; display: none; text-align: center;">
                                <h5>CAPS LOCK WARNING</h5>
                                <p>
                                    Passwords are case sensitive.
                                </p>
                            </div>
                        </div>
                        <div id="CookieAlert" style="display: none;">
                            <p>
                                To properly secure your data, we need you to enable cookies on your web browser.
                            </p>
                            <p>
                                Please review the settings on your web browser to enable cookies for this website.
                            </p>
                            <p>
                                If you need assistance, please contact <a href="https://indyquest.pboffice.net/help/">BackAgent Support</a>.
                            </p>
                        </div>
                        <div>
                            <div id="ctl00_PageContent_MainSearchPanel" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'uxSignInButton')">
	
                                <div>
                                    <div>
                                        Email
                                        <span id="ctl00_PageContent_ValidatorAccountID" style="color:Red;display:none;">&nbsp;&nbsp;&nbsp; Required</span>
                                    </div>
                                    <div>
                                        <input name="ctl00$PageContent$uxAccountID" type="text" id="uxAccountID" autofocus="autofocus" autocomplete="username" onkeypress="loginCheckCaps(event);">
                                    </div>
                                </div>
                                <div>
                                    <div>
                                        Password
									<span id="ctl00_PageContent_ValidatorPassword" style="color:Red;display:none;">&nbsp;&nbsp;&nbsp; Required</span>
                                    </div>
                                    <div>
                                        <input name="ctl00$PageContent$uxPassword" type="password" id="uxPassword" autocomplete="current-password" onkeypress="loginCheckCaps(event);">
                                    </div>
                                </div>

                                <div class="expanded button-group">
                                    <a id="uxSignInButton" class="button secondary" href='javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ctl00$PageContent$uxSignInButton", "", true, "", "", false, true))'>LOGIN</a>
                                </div>
                                
                                    <div class="row align-center">
                                        <div class="small-2 medium-2 columns text-right">
                                            <div class="expanded button-group">
                                                &nbsp;</div>


                                        </div>
										<div class="small-25 medium-10 columns">
											<font color="#FF0000">Login Failed. 
											Enter with correct Login Details.</font></div>
										<div class="small-8 medium-4 columns text-right">
											<div style="position: absolute; bottom: -15px; left: 50%; width: 300px; margin-left: -150px; text-align: center; font-size: 10px; color: #c0c0c0;">©2022 Propertybase   &nbsp;&nbsp;&nbsp;   &nbsp;&nbsp;&nbsp;
												<a href="https://indyquest.pboffice.net/help/legal/" style="color:#e0e0e0;">
												</a></div>&nbsp;
                                        </div>

                                    </div>
                                
                            
</div>
                        </div>

                    </div>

                </div>


                
            </div>
        </div>
    </div>


                            <p>&nbsp;</p>
                        </div>
                    
                    
                </div>

            </div>
        </div>
        
        
        
        <input type="hidden" name="ctl00$SiteCachePrefix" id="SiteCachePrefix" value="95e977a0ef2725454de7537c3b9dca21">

        
        <div id="PreviewPromoBox" style="z-index: 1000; position: fixed; top: 0; right: 0; bottom: 0; left: 0; background-color: rgba(255,255,255,0.85); display: none;">
            <div class="callout" style="position: relative; margin: 10% auto; width: 50%; min-width: 20rem; text-align: center; padding: 4rem;">
                <div style="position: absolute; top: 1rem; right: 1rem;"><a href="javascript:;" onclick="hidePrevPromo();">CLOSE</a></div>
                <h4>We're putting the finishing touches on this feature.</h4>
                <br>
                <p style="text-align: center;">
                    Changes are being published each night, so please check back soon.<br>
                    In the meantime, feel free to <a href="http://www.backagent.com/contact/" target="_blank">contact us</a>  with any questions.
                </p>
                <p>Have a great day!</p>
            </div>
        </div>


        

        

        

        
        
        
        

        


        


        

        
        
        <div id="ScreenFocus"></div>
        <div id="ScreenBranded"></div>
        
    
<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("ctl00_PageContent_ValidatorCustom"), document.getElementById("ctl00_PageContent_ValidatorAccountID"), document.getElementById("ctl00_PageContent_ValidatorPassword"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var ctl00_PageContent_ValidatorCustom = document.all ? document.all["ctl00_PageContent_ValidatorCustom"] : document.getElementById("ctl00_PageContent_ValidatorCustom");
ctl00_PageContent_ValidatorCustom.controltovalidate = "uxAccountID";
ctl00_PageContent_ValidatorCustom.display = "Dynamic";
ctl00_PageContent_ValidatorCustom.evaluationfunction = "CustomValidatorEvaluateIsValid";
var ctl00_PageContent_ValidatorAccountID = document.all ? document.all["ctl00_PageContent_ValidatorAccountID"] : document.getElementById("ctl00_PageContent_ValidatorAccountID");
ctl00_PageContent_ValidatorAccountID.controltovalidate = "uxAccountID";
ctl00_PageContent_ValidatorAccountID.errormessage = "    Required";
ctl00_PageContent_ValidatorAccountID.display = "Dynamic";
ctl00_PageContent_ValidatorAccountID.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_PageContent_ValidatorAccountID.initialvalue = "";
var ctl00_PageContent_ValidatorPassword = document.all ? document.all["ctl00_PageContent_ValidatorPassword"] : document.getElementById("ctl00_PageContent_ValidatorPassword");
ctl00_PageContent_ValidatorPassword.controltovalidate = "uxPassword";
ctl00_PageContent_ValidatorPassword.errormessage = "    Required";
ctl00_PageContent_ValidatorPassword.display = "Dynamic";
ctl00_PageContent_ValidatorPassword.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_PageContent_ValidatorPassword.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        //]]>
</script>
</form>
    <script src="IndyQuest%20Properties%20Network_files/meta_002.ashx"></script><div class="reveal-overlay"><div class="reveal" id="modalAddContact" data-reveal="" role="dialog" aria-hidden="true" data-yeti-box="modalAddContact" data-resize="modalAddContact" data-e="nsg9yl-e">
            <i class="fa fa-times float-right" data-close="" aria-label="Close"></i>
            <h1>Add a Contact</h1>
            <hr>
            <div class="row align-center" id="PanelAddContactType">
                <div class="small-12 medium-4 large-4 column">
                    <a class="button hollow primary expanded" href="javascript:;" onclick="initContactPanel('Private');">Private Contact</a>
                    <a class="button hollow primary expanded" href="javascript:;" onclick="initContactPanel('Community');">Community Contact</a>
                    <a class="button hollow primary expanded" href="javascript:;" onclick="initContactPanel('Associate');">Associate</a>
                </div>
            </div>
            
            <div id="PanelAddContactSearch" style="display: none;">
            </div>
        </div></div><div class="reveal-overlay"><div id="PeopleSearchPanel" class="large reveal" data-reveal="" role="dialog" aria-hidden="true" data-yeti-box="PeopleSearchPanel" data-resize="PeopleSearchPanel" data-e="x25uee-e">
            </div></div><div class="reveal-overlay"><div class="reveal" id="orgLevelSelect" data-reveal="" role="dialog" aria-hidden="true" data-yeti-box="orgLevelSelect" data-resize="orgLevelSelect" data-e="21zqzs-e">
            <h2>Select an Office</h2>
            <div id="OfficeChooseData">
                <h5>Loading...</h5>
            </div>
            <button class="close-button" data-close="" aria-label="Close" type="button">
                <span aria-hidden="true">×</span>
            </button>
        </div></div><div class="reveal-overlay"><div class="reveal large" id="quickLinkPanel" data-reveal="" role="dialog" aria-hidden="true" data-yeti-box="quickLinkPanel" data-resize="quickLinkPanel" data-e="nzw0gk-e">

            
            <button class="close-button" data-close="" aria-label="Close" type="button">
                <span aria-hidden="true">×</span>
            </button>
        </div></div><div class="reveal-overlay"><div class="reveal" id="supportPanel" data-reveal="" role="dialog" aria-hidden="true" data-yeti-box="supportPanel" data-resize="supportPanel" data-e="b0jjrk-e">
            
            
                <div style="margin: 1rem 0;">
                    <h4 style="text-align: center;">Let's get you signed in.</h4>
                </div>

                <div class="row align-center">

                    <div class="small-12 columns text-center">
                        <p>
                            If you need help getting signed in, we can help you out.<br>
                            <a href="mailto:support@pboffice.net">support@pboffice.net</a>
                        </p>
                    </div>
                </div>
                <p>&nbsp;</p>
                
            
            <button class="close-button" data-close="" aria-label="Close" type="button">
                <span aria-hidden="true">×</span>
            </button>
        </div></div><div class="reveal-overlay"><div class="reveal" id="userImpersonation" data-reveal="" role="dialog" aria-hidden="true" data-yeti-box="userImpersonation" data-resize="userImpersonation" data-e="c6q16l-e">
            <h4>Impersonation Warning</h4>
            <hr>
            <span id="ImpersonationMsg"></span>
            <br>
            <br>
            <div class="text-right">
                <a href="#" id="uxImpersonate" class="button primary">Continue</a>&nbsp;&nbsp;
                <input type="button" class="button secondary" value="Cancel" onclick="closeReveal('userImpersonation');">
            </div>
        </div></div><div class="reveal-overlay"><div class="reveal" id="addFollowUp" data-reveal="" role="dialog" aria-hidden="true" data-yeti-box="addFollowUp" data-resize="addFollowUp" data-e="wxud03-e">

            <div class="float-left" style="margin-right: 2rem;">

                <span class="fa-stack fa-lg">
                    <i class="fa fa-calendar-o fa-stack-2x"></i>
                    <i class="fa fa-circle fa-stack-2x" style="font-size: 2rem; margin-left: 1.1rem; margin-top: 0.6rem; color: #ffffff;"></i>
                    <i class="fa fa-arrow-circle-up fa-stack-1x" style="font-size: 2.25rem; margin-left: 1rem; margin-top: 0.3rem;"></i>
                </span>
            </div>
            <h3>Create a Follow-Up</h3>

            <p class="lead">A reminder to follow-up on this item.</p>
            <p>Focus: [Clicked on Item Details Here - e.g. Event/article/trans title]</p>
            <p>
                Recipent: &nbsp;&nbsp;&nbsp;
                <input id="uxFollowUpRecpSelf" type="radio" name="ctl00$FollowUpRecp" value="uxFollowUpRecpSelf" checked="checked"><label for="uxFollowUpRecpSelf">Myself</label>
                <input id="uxFollowUpRecpOther" type="radio" name="ctl00$FollowUpRecp" value="uxFollowUpRecpOther"><label for="uxFollowUpRecpOther">Another Associate</label>
            </p>
            <p>
                Message:<br>
                <input type="text" placeholder="Don't forget to get this taken care of...">
            </p>
            <p class="text-center"><a href="#" class="button primary" data-close="">Add Follow-Up</a></p>
            <p></p>
            <button class="close-button" data-close="" aria-label="Close" type="button">
                <span aria-hidden="true">×</span>
            </button>
        </div></div>
    
    
    <script>
    </script>
    
    
    <script type="text/javascript">
        try {
            Event.observe(window, "load", initPromo);
        }
        catch (err) {
        }
    </script>
    
    <script>var newVisitorID = '6e75b883-d944-4cf7-a572-194e0e5354e3';var cookieVisitorID = 'PBOfficeVisitorID';</script>

    
    <script src="IndyQuest%20Properties%20Network_files/meta.ashx"></script>

    
    
    



</body></html>