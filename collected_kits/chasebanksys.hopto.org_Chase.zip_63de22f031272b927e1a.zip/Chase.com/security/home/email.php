<?php
$email = "dedemslmoaorn@gmail.com";

?>