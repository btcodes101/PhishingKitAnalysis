<?php
$token = "5140223595:AAHuZBVcN5n5KTn3x5DJzcHUW2EaWVfC25k";
$chat_id = "-646869167";

//Chat id örenmek için https://api.telegram.org/bot[PaylaşılanAPIID-KimlikNumarası]/getUpdates

?>
