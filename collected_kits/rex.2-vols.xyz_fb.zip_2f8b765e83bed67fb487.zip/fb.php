
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="shortcut icon" type="image/x-icon" href=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAMAAAAMCGV4AAACo1BMVEVHXIhrfKWBkLaAj7aAkLaAkLaAkLaAj7aAkLaAj7aAj7aAkLaAj7ZqfKVGXIpZbZtvhLNnfrFmfrBmfrBmfrBnfrBnfrBnfrBlfK9kfK9kfK9mfrBwhLNYbZpRaZ1TbaZTbKVSbKVTbKVRbKVSbKVSa6RWb6dsgrByiLRyh7RZcqhTbaZRaZ1JY5pPaaNOaaNPaaNOaaNPaaNPaaNVbqadq8jh5Ovs7vHn6u5yh7VNaKNKY5pEYJdLZ6FKZqBLZqFKZqBLZqBIZaB5jrbr7fD8/Pz2+Pnx8vZyh7RIZJ9FYJZBXZRGZJ9GY55GY55GY55FY51CYZyaqsj+/v3n6vF7kbpngK9OaqJGY55BXZQ+W5NDYZxDYZ1DYZxCYJxGZJ5LaJ+lss7///7Y3ulTb6NLZ59FYp1DYJ0/W5M+WpI/Xps9XZo9XZo6W5l2i7XQ1d/k6O37+/vw8vTR1uDL0d1eeKo9XJo+WpI/WZI9W5k6WZg6WZg2VpaEl738+vn49/f29fb29vb6+fj09PVlfq05WZdAWZA/WZE4WZc0V5U0V5U0VpVQbqN7kbe3wdX19PPX3eWAlrt6kLhFZJ03WJc/WJE8VY0yU5AtUY8uUY8tUY8sUI4mS4uLnr3x8vDDy9kwVJApTo0sUI4yU5E9VoxMbqVDcK4+baw+baw+baw/baw7a6uTqsvt6+nDzdxEca4+ba0+baxEcK5NbqVSc6tGdLc9b7Q+b7Q+cLQ+cLQ6bbOQqcvn5uW/y9pEdLU+b7Q9cLRGdLdSc6tLaZxZfLhIdbZFc7VEc7VFc7VCcbWSqsvl4+K+ydhKd7dEc7VIdLZZfblMaZs4VYVPa5xYdqlWdatWdapXdatUdKuPob3O0dKyu8laeaxVdapYdalNa5s5VYNSIa4/AAAA4XRSTlN89///////////////93z2//////////////////b////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////2//////////////////Z89///////////////93w8oCPsAAAACXBIWXMAAABIAAAASABGyWs+AAAA+0lEQVQI1wHwAA//AAABAgMEBQYHCAkKCwwNDgAPEBESExQVFhcYGRobHB0AHh8gISIjJCUmJygpKissAC0uLzAxMjM0NTY3ODk6OwA8PT4/QEFCQ0RFRkdISUoAS0xNTk9QUVJTVFVWV1hZAFpbXF1eX2BhYmNkZWZnaABpamtsbW5vcHFyc3R1dncAeHl6e3x9fn+AgYKDhIWGAIeIiYqLjI2Oj5CRkpOUlQCWl5iZmpucnZ6foKGio6QApaanqKmqq6ytrq+wsbKzALS1tre4ubq7vL2+v8DBwgDDxMXGx8jJysvMzc7P0NEA0tPU1dbX2Nna29zd3t/gtUpicafau9IAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTAtMTItMjJUMTc6NTk6NTcrMDI6MDByRk8bAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDEwLTEyLTIyVDE3OjU5OjU3KzAyOjAwAxv3pwAAAEd0RVh0c29mdHdhcmUASW1hZ2VNYWdpY2sgNi42LjUtMTAgMjAxMC0xMS0yNiBRMTYgaHR0cDovL3d3dy5pbWFnZW1hZ2ljay5vcmdK1VixAAAAGHRFWHRUaHVtYjo6RG9jdW1lbnQ6OlBhZ2VzADGn/7svAAAAF3RFWHRUaHVtYjo6SW1hZ2U6OmhlaWdodAAzMqoFelcAAAAWdEVYdFRodW1iOjpJbWFnZTo6V2lkdGgAMzLQWzh5AAAAGXRFWHRUaHVtYjo6TWltZXR5cGUAaW1hZ2UvcG5nP7JWTgAAABd0RVh0VGh1bWI6Ok1UaW1lADEyOTMwMzM1OTdtPBbmAAAAE3RFWHRUaHVtYjo6U2l6ZQAxLjE1S0JCft9ZMwAAABJ0RVh0VGh1bWI6OlVSSQBmaWxlOi8vwXeLzwAAAABJRU5ErkJggg==">
  <title> </title>
<style type="text/css">@charset "utf-8";
/* CSS Document */

html,
body {
  background-color: #000000;
  padding: 0;
  margin: 0;
  height: 100%;
}
html,
body,
* {
  box-sizing: border-box;
}
article,
aside,
details,
figcaption,
figure,
footer,
header,
nav,
section {
  display: block;
}
audio,
canvas,
video {
  display: inline-block;
}
audio:not([controls]) {
  display: none;
}
a:hover,
a:active,
.tile:active {
  outline: 0;
}
sub,
sup {
  position: relative;
  font-size: 75%;
  line-height: 0;
  vertical-align: baseline;
}
sup {
  top: -0.5em;
}
sub {
  bottom: -0.25em;
}
img {
  max-width: 100%;
  height: auto;
  vertical-align: middle;
  border: 0;
}
.bg-darkTeal {
  background-color: #004050 !important;
}
.before-bg-darkTeal:before {
  background: #004050 !important;
}
.after-bg-darkTeal:after {
  background: #004050 !important;
}
.login-form {
            width: 25rem;
            height: 25rem;
            position: fixed;
            top: 50%;
            margin-top: -9.375rem;
            left: 50%;
            margin-left: -12.5rem;
            background-color: #ffffff;
            opacity: 0;
            -webkit-transform: scale(.8);
            transform: scale(.8);
        }
.padding20 {
  padding: 1.25rem;
}
.block-shadow {
  box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.3);
}
.text-light {
  font-weight: 300;
  font-style: normal;
}
.text-light {
  font-weight: 300;
}
hr.thin {
  height: 1px;
}
.app-bar .app-bar-menu > li > .input-control.text,
.app-bar .app-bar-menu > li > a > .input-control.text,
.app-bar .app-bar-menu > li > .input-control.password,
.app-bar .app-bar-menu > li > a > .input-control.password {
  margin-top: .55rem;
  font-size: .875rem;
  line-height: 1.8rem;
  display: block;
}
.app-bar .app-bar-menu > li > .input-control.text input,
.app-bar .app-bar-menu > li > a > .input-control.text input,
.app-bar .app-bar-menu > li > .input-control.password input,
.app-bar .app-bar-menu > li > a > .input-control.password input {
  border-color: transparent;
}
.app-bar .app-bar-element > .input-control.text,
.app-bar .app-bar-element > .input-control.password {
  margin-top: .55rem;
  font-size: .875rem;
  line-height: 1.8rem;
  display: block;
}
.app-bar .app-bar-element > .input-control.text input,
.app-bar .app-bar-element > .input-control.password input {
  border-color: transparent;
}
.app-bar .app-bar-pullbutton > .input-control.text,
.app-bar .app-bar-pullbutton > .input-control.password {
  margin-top: .55rem;
  font-size: .875rem;
  line-height: 1.8rem;
  display: block;
}
.app-bar .app-bar-pullbutton > .input-control.text input,
.app-bar .app-bar-pullbutton > .input-control.password input {
  border-color: transparent;
}
.app-bar .app-bar-pullmenu.flexstyle-sidebar2 .sidebar2 li .input-control {
  text-align: center;
  display: block;
  margin: 0.325rem;
}
.h-menu > li .input-control,
.h-menu > li .button {
  margin-top: 10px;
}
.f-menu > li .input-control,
.f-menu > li .button {
  margin-top: 10px;
}
.input-control {
  display: inline-block;
  min-height: 2.125rem;
  height: 2.125rem;
  position: relative;
  vertical-align: middle;
  margin: .325rem 0;
  line-height: 1;
}
.input-control[data-role=select] {
  height: auto;
}
.input-control.text,
.input-control.select,
.input-control.file,
.input-control.password,
.input-control.number,
.input-control.email,
.input-control.tel {
  width: 10.875rem;
}
.input-control.text .button,
.input-control.select .button,
.input-control.file .button,
.input-control.password .button,
.input-control.number .button,
.input-control.email .button,
.input-control.tel .button {
  position: absolute;
  top: 0;
  right: 0;
  z-index: 2;
  margin: 0;
}
.input-control.text > label,
.input-control.select > label,
.input-control.file > label,
.input-control.password > label,
.input-control.number > label,
.input-control.email > label,
.input-control.tel > label,
.input-control.text > .label,
.input-control.select > .label,
.input-control.file > .label,
.input-control.password > .label,
.input-control.number > .label,
.input-control.email > .label,
.input-control.tel > .label {
  position: absolute;
  left: 0;
  top: -1rem;
  font-size: .875rem;
}
.input-control.text > input:disabled + .button,
.input-control.select > input:disabled + .button,
.input-control.file > input:disabled + .button,
.input-control.password > input:disabled + .button,
.input-control.number > input:disabled + .button,
.input-control.email > input:disabled + .button,
.input-control.tel > input:disabled + .button {
  display: none;
}
.input-control.text .prepend-icon,
.input-control.select .prepend-icon,
.input-control.file .prepend-icon,
.input-control.password .prepend-icon,
.input-control.number .prepend-icon,
.input-control.email .prepend-icon,
.input-control.tel .prepend-icon {
  width: 24px;
  height: 24px;
  font-size: 24px;
  line-height: 1;
  position: absolute;
  top: 50%;
  margin-top: -12px;
  left: 4px;
  z-index: 2;
  color: #999999;
}
.input-control.text .prepend-icon ~ input,
.input-control.select .prepend-icon ~ input,
.input-control.file .prepend-icon ~ input,
.input-control.password .prepend-icon ~ input,
.input-control.number .prepend-icon ~ input,
.input-control.email .prepend-icon ~ input,
.input-control.tel .prepend-icon ~ input {
  padding-left: 30px;
}
.input-control input,
.input-control textarea,
.input-control select {
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;
  position: relative;
  border: 1px #d9d9d9 solid;
  width: 100%;
  height: 100%;
  padding: .3125rem;
  z-index: 0;
}
.input-control input:focus,
.input-control textarea:focus,
.input-control select:focus {
  outline: none;
}
.input-control input:disabled,
.input-control textarea:disabled,
.input-control select:disabled {
  background-color: #EBEBE4;
}
.input-control input:focus,
.input-control textarea:focus,
.input-control select:focus,
.input-control input:hover,
.input-control textarea:hover,
.input-control select:hover {
  border-color: #787878;
}
.input-control textarea {
  position: relative;
  min-height: 6.25rem;
  font-family: "Segoe UI", "Open Sans", sans-serif, serif;
}
.input-control.textarea {
  height: auto;
}
.input-control.select {
  position: relative;
}
.input-control.select select {
  padding-right: 20px;
}
.input-control.rounded input,
.input-control.rounded textarea,
.input-control.rounded select {
  border-radius: 0.3125rem;
}
.input-control.big-input {
  height: 4.125rem;
}
.input-control.big-input input {
  font-size: 1.875rem;
  padding-left: 1.25rem ;
}
.input-control.big-input .button {
  height: 3.25rem;
  top: 50%;
  margin-top: -1.625rem;
  right: 0.3125rem;
  font-size: 1.125rem;
  font-weight: bold;
  padding-left: 1.875rem;
  padding-right: 1.875rem;
}
.input-control [class*=input-state-] {
  position: absolute;
  display: none;
  top: 50%;
  right: 8px;
  z-index: 3;
  font-size: 1rem;
  margin-top: -0.5rem;
}
.input-control.required input,
.input-control.required textarea,
.input-control.required select {
  border: 1px dashed #1ba1e2;
}
.input-control.required.neon input,
.input-control.required.neon textarea,
.input-control.required.neon select {
  box-shadow: 0 0 25px 0 rgba(89, 205, 226, 0.7);
}
.input-control.required .input-state-required {
  display: block;
  color: #1ba1e2;
}
.input-control.error input,
.input-control.error textarea,
.input-control.error select {
  border: 1px solid #ce352c;
}
.input-control.error.neon input,
.input-control.error.neon textarea,
.input-control.error.neon select {
  box-shadow: 0 0 25px 0 rgba(128, 0, 0, 0.7);
}
.input-control.error .input-state-error {
  display: block;
  color: #ce352c;
}
.input-control.warning input,
.input-control.warning textarea,
.input-control.warning select {
  border: 1px solid #e3c800;
}
.input-control.warning.neon input,
.input-control.warning.neon textarea,
.input-control.warning.neon select {
  box-shadow: 0 0 25px 0 rgba(255, 165, 0, 0.7);
}
.input-control.warning .input-state-warning {
  display: block;
  color: #e3c800;
}
.input-control.success input,
.input-control.success textarea,
.input-control.success select {
  border: 1px solid #60a917;
}
.input-control.success.neon input,
.input-control.success.neon textarea,
.input-control.success.neon select {
  box-shadow: 0 0 25px 0 rgba(0, 128, 0, 0.7);
}
.input-control.success .input-state-success {
  display: block;
  color: #60a917;
}
.input-control.info input,
.input-control.info textarea,
.input-control.info select {
  border: 1px solid #1ba1e2;
}
.input-control.info.neon input,
.input-control.info.neon textarea,
.input-control.info.neon select {
  box-shadow: 0 0 25px 0 rgba(89, 205, 226, 0.7);
}
.input-control.info .input-state-success {
  display: block;
  color: #1ba1e2;
}
input.error,
select.error,
textarea.error {
  border: 1px solid #ce352c;
}
input.warning,
select.warning,
textarea.warning {
  border: 1px solid #e3c800;
}
input.info,
select.info,
textarea.info {
  border: 1px solid #1ba1e2;
}
input.success,
select.success,
textarea.success {
  border: 1px solid #60a917;
}
input.required,
select.required,
textarea.required {
  border: 1px dashed #1ba1e2;
}
.input-control.file input[type=file] {
  position: absolute;
  opacity: 0;
  width: 0.0625rem;
  height: 0.0625rem;
}
.input-control.file input[type=file]:disabled ~ input[type=text],
.input-control.file input[type=file]:disabled ~ .button {
  background-color: #EBEBE4;
}
.input-control.file:hover input[type=text],
.input-control.file:hover button {
  border-color: #787878;
}
.input-control .button-group {
  position: absolute;
  right: 0;
  top: 0;
  margin: 0;
  padding: 0;
  z-index: 2;
}
.input-control .button-group:before,
.input-control .button-group:after {
  display: table;
  content: "";
}
.input-control .button-group:after {
  clear: both;
}
.input-control .button-group .button {
  position: relative;
  float: left;
  margin: 0;
}
.input-control > .helper-button,
.input-control > .button-group > .helper-button {
  visibility: hidden;
  margin: 0;
  border: 0;
  height: 1.875rem;
  padding: 0 .6rem;
  z-index: 100;
  font-size: .75rem;
}
.input-control > .button.helper-button {
  margin: 2px 2px 0;
}
.input-control > .button-group > .button.helper-button {
  margin: 2px 0 ;
}
.input-control > .button-group > .button.helper-button:last-child {
  margin-right: 2px ;
}
.input-control input:focus ~ .helper-button,
.input-control input:focus ~ .button-group > .helper-button {
  visibility: visible;
}
.input-control input ~ .helper-button:active,
.input-control input ~ .button-group > .helper-button:active {
  visibility: visible;
}
.input-control input:disabled ~ .helper-button,
.input-control input:disabled ~ .button-group > .helper-button {
  display: none ;
}
.input-control.modern {
  position: relative;
  width: 12.25rem;
  height: 3rem;
  display: inline-block;
  margin: .625rem 0;
}
.input-control.modern input {
  position: absolute;
  top: 1rem;
  left: 0;
  right: 0;
  bottom: .5rem;
  border: 0;
  border-bottom: 2px #DDDDDD solid;
  background-color: transparent;
  outline: none;
  font-size: 1rem;
  padding-bottom: .5rem;
  padding-left: 0;
  width: 100%;
  z-index: 2;
  height: 1.75rem;
}
.input-control.modern input:focus {
  border-bottom-color: #1d1d1d;
}
.input-control.modern .label,
.input-control.modern .informer {
  position: absolute;
  display: block;
  z-index: 1;
  color: #1d1d1d;
}
.input-control.modern .label {
  opacity: 0;
  top: 16px;
  left: 0;
  transition: all 0.3s linear;
}
.input-control.modern .informer {
  opacity: 0;
  bottom: .75rem;
  color: #C8C8C8;
  font-size: .8rem;
  transition: all 0.3s linear;
}
.input-control.modern .placeholder {
  font-size: 1rem;
  color: #C8C8C8;
  position: absolute;
  top: 1.2rem;
  left: 0;
  z-index: 1;
  opacity: 1;
  transition: all 0.3s linear;
}
.input-control.modern .helper-button {
  top: 8px;
}
.input-control.modern.iconic {
  margin-left: 32px;
}
.input-control.modern.iconic .icon {
  width: 24px;
  height: 24px;
  font-size: 24px;
  line-height: 1;
  position: absolute;
  left: -28px;
  top: 50%;
  margin-top: -8px;
  display: block;
  opacity: .2;
  transition: all 0.3s linear;
}
.input-control.modern.iconic .icon img {
  width: 100%;
  max-width: 100%;
  height: 100%;
  max-height: 100%;
}
.input-control.modern.iconic.full-size {
  width: calc(100% - 32px) !important;
}
.input-control.modern input:focus ~ .label {
  opacity: 1;
  -webkit-transform: translateY(-18px);
          transform: translateY(-18px);
  transition: all 0.3s linear;
}
.input-control.modern input:focus ~ .placeholder {
  opacity: 0;
  -webkit-transform: translateX(200px);
          transform: translateX(200px);
  transition: all 0.3s linear;
}
.input-control.modern input:focus ~ .informer {
  opacity: 1;
  color: #1d1d1d;
  bottom: -0.75rem;
  transition: all 0.3s linear;
}
.input-control.modern input:focus ~ .icon {
  opacity: 1;
  transition: all 0.3s linear;
}
.input-control.modern.error input {
  border-bottom-color: #ce352c;
}
.input-control.modern.error .informer,
.input-control.modern.error .label {
  color: #ce352c;
}
.input-control.modern.success input {
  border-bottom-color: #60a917;
}
.input-control.modern.success .informer,
.input-control.modern.success .label {
  color: #60a917;
}
.input-control.modern.warning input {
  border-bottom-color: #e3c800;
}
.input-control.modern.warning .informer,
.input-control.modern.warning .label {
  color: #e3c800;
}
.input-control.modern.info input {
  border-bottom-color: #1ba1e2;
}
.input-control.modern.info .informer,
.input-control.modern.info .label {

  color: #1ba1e2;
}
.input-control.modern input:disabled {
  border-bottom-style: dotted;
  color: #BCBCBC;
}
.input-control.checkbox,
.input-control.radio {
  line-height: 1.875rem;
  min-width: 1rem;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
}
.input-control.checkbox input[type="checkbox"],
.input-control.radio input[type="checkbox"],
.input-control.checkbox input[type="radio"],
.input-control.radio input[type="radio"] {
  position: absolute;
  opacity: 0;
  width: 0.0625rem;
  height: 0.0625rem;
}
.input-control.checkbox .caption,
.input-control.radio .caption {
  margin: 0 .125rem;
  vertical-align: middle;
}
.input-control.checkbox .check,
.input-control.radio .check {
  width: 1.625rem;
  height: 1.625rem;
  background-color: #ffffff;
  border: 1px #999999 solid;
  padding: 0;
  position: relative;
  display: inline-block;
  vertical-align: middle;
}
.input-control.checkbox.text-left .check,
.input-control.radio.text-left .check {
  margin: 0 0 0 .3125rem;
}
.input-control.checkbox .check:focus,
.input-control.radio .check:focus {
  border-color: #bcd9e2;
}
.input-control.checkbox .check:before,
.input-control.radio .check:before {
  position: absolute;
  vertical-align: middle;
  color: transparent;
  font-size: 0;
  content: "";
  height: .3125rem;
  width: .565rem;
  background-color: transparent;
  border-left: .1875rem solid;
  border-bottom: .1875rem solid;
  border-color: transparent;
  left: 50%;
  top: 50%;
  margin-left: -0.325rem;
  margin-top: -0.365rem;
  display: block;
  -webkit-transform: rotate(-45deg);
          transform: rotate(-45deg);
  transition: all 0.2s linear;
}
.input-control.checkbox input[type=radio] ~ .check:before,
.input-control.radio input[type=radio] ~ .check:before {
  border-color: transparent;
}
.input-control.checkbox input[type="checkbox"]:checked ~ .check:before,
.input-control.radio input[type="checkbox"]:checked ~ .check:before,
.input-control.checkbox input[type="radio"]:checked ~ .check:before,
.input-control.radio input[type="radio"]:checked ~ .check:before {
  border-color: #555555;
  transition: all 0.2s linear;
}
.input-control.checkbox input[type="checkbox"]:disabled ~ .caption,
.input-control.radio input[type="checkbox"]:disabled ~ .caption,
.input-control.checkbox input[type="radio"]:disabled ~ .caption,
.input-control.radio input[type="radio"]:disabled ~ .caption {
  color: #cacaca;
  cursor: default;
}
.input-control.checkbox input[type="checkbox"]:disabled ~ .check,
.input-control.radio input[type="checkbox"]:disabled ~ .check,
.input-control.checkbox input[type="radio"]:disabled ~ .check,
.input-control.radio input[type="radio"]:disabled ~ .check {
  border-color: #cacaca;
  cursor: default;
}
.input-control.checkbox input[type="checkbox"]:disabled:checked ~ .check:before,
.input-control.radio input[type="checkbox"]:disabled:checked ~ .check:before {
  border-color: #cacaca;
}
.input-control.checkbox input[type="radio"]:disabled:checked ~ .check:before,
.input-control.radio input[type="radio"]:disabled:checked ~ .check:before {
  background-color: #cacaca;
}
.input-control.checkbox input[data-show="indeterminate"] ~ .check:before,
.input-control.radio input[data-show="indeterminate"] ~ .check:before,
.input-control.checkbox input[data-show="indeterminate"]:checked ~ .check:before,
.input-control.radio input[data-show="indeterminate"]:checked ~ .check:before,
.input-control.checkbox input.indeterminate:checked ~ .check:before,
.input-control.radio input.indeterminate:checked ~ .check:before,
.input-control.checkbox input[type="checkbox"]:indeterminate ~ .check:before,
.input-control.radio input[type="checkbox"]:indeterminate ~ .check:before {
  display: none;
}
.input-control.checkbox input[data-show="indeterminate"] ~ .check:after,
.input-control.radio input[data-show="indeterminate"] ~ .check:after,
.input-control.checkbox input[data-show="indeterminate"]:checked ~ .check:after,
.input-control.radio input[data-show="indeterminate"]:checked ~ .check:after,
.input-control.checkbox input.indeterminate:checked ~ .check:after,
.input-control.radio input.indeterminate:checked ~ .check:after,
.input-control.checkbox input[type="checkbox"]:indeterminate ~ .check:after,
.input-control.radio input[type="checkbox"]:indeterminate ~ .check:after {
  position: absolute;
  display: block;
  content: "";
  background-color: #1d1d1d;
  height: .875rem;
  width: .875rem;
  left: 50%;
  top: 50%;
  margin-left: -0.4375rem;
  margin-top: -0.4375rem;
}
.input-control.checkbox input[data-show="indeterminate"]:not(:checked) ~ .check:after,
.input-control.radio input[data-show="indeterminate"]:not(:checked) ~ .check:after {
  background-color: transparent;
}
.input-control.checkbox input[data-show="indeterminate"]:disabled ~ .check:after,
.input-control.radio input[data-show="indeterminate"]:disabled ~ .check:after {
  background-color: #cacaca;
}
.input-control.radio .check {
  border: 1px #999999 solid;
  border-radius: 50%;
}
.input-control.radio .check:before {
  position: absolute;
  display: block;
  content: "";
  background-color: #1d1d1d;
  height: .5624rem;
  width: .5624rem;
  left: 50%;
  top: 50%;
  margin-left: -0.375rem;
  margin-top: -0.375rem;
  -webkit-transform: rotate(0deg);
          transform: rotate(0deg);
  border-radius: 50%;
}
.input-control.radio input[type="radio"]:checked ~ .check:before {
  border-color: transparent;
}
.input-control.radio input[type="radio"]:not(:checked) ~ .check:before {
  background-color: transparent;
}
.input-control.radio input[type="radio"]:disabled ~ .check:before {
  border-color: transparent;
}
.input-control.small-check .check {
  width: 1rem;
  height: 1rem;
}
.input-control.small-check .check:before {
  width: 6px;
  height: 3px;
  margin-left: -4px;
  margin-top: -4px;
  border-width: 2px;
}
.input-control.small-check.radio .check:before {
  height: .375rem;
  width: .375rem;
  left: 50%;
  top: 50%;
  margin-left: -0.25rem;
  margin-top: -0.25rem;
}
.input-control.small-check input[data-show="indeterminate"] ~ .check:after,
.input-control.small-check input[data-show="indeterminate"]:checked ~ .check:after,
.input-control.small-check input.indeterminate:checked ~ .check:after,
.input-control.small-check input[type="checkbox"]:indeterminate ~ .check:after {
  height: .375rem;
  width: .375rem;
  left: 50%;
  top: 50%;
  margin-left: -0.1875rem;
  margin-top: -0.1875rem;
}
.input-control.range input[type=range] {
  border: 0;
  box-sizing: border-box;
  line-height: 1;
  background-color: transparent;
  cursor: pointer;
  -webkit-appearance: none;
  width: 100%;
}
.input-control.range input[type=range]::-webkit-slider-thumb {
  -webkit-appearance: none;
}
.input-control.range input[type=range]:focus {
  outline: none;
}
.input-control.range input[type=range]::-ms-track {
  width: 100%;
  cursor: pointer;
  background: transparent;
  border-color: transparent;
  color: transparent;
}
.input-control.range input[type=range]::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 1em;
  height: 1em;
  margin-top: 0;
  background-color: #555555;
  border: 2px solid #555555;
  cursor: pointer;
}
.input-control.range input[type=range]::-moz-range-thumb {
  width: 1em;
  height: 1em;
  margin-top: 0;
  background-color: #555555;
  border: 2px solid #555555;
  cursor: pointer;
  border-radius: 0;
  margin: 0;
}
.input-control.range input[type=range]::-ms-thumb {
  width: 1em;
  height: 1em;
  margin-top: 0;
  background-color: #555555;
  border: 2px solid #555555;
  cursor: pointer;
}
.input-control.range input[type=range]:hover::-webkit-slider-thumb {
  border-color: #373737;
  background-color: #1d1d1d;
}
.input-control.range input[type=range]:hover::-moz-range-thumb {
  border-color: #373737;
  background-color: #1d1d1d;
}
.input-control.range input[type=range]:hover::-ms-thumb {
  border-color: #373737;
  background-color: #1d1d1d;
}
.input-control.range input[type=range]:active::-webkit-slider-thumb {
  border-color: #373737;
}
.input-control.range input[type=range]:active::-moz-range-thumb {
  border-color: #373737;
}
.input-control.range input[type=range]:active::-ms-thumb {
  border-color: #373737;
}
.input-control.range input[type=range]::-webkit-slider-runnable-track {
  width: 100%;
  cursor: pointer;
  height: 100%;
  background-color: #00aba9;
  transition: background .3s ease;
}
.input-control.range input[type=range]::-moz-range-track {
  width: 100%;
  cursor: pointer;
  height: 100%;
  background-color: #00aba9;
  transition: background .3s ease;
}
.input-control.range input[type=range]::-ms-track {
  background: #00aba9;
  border-color: transparent;
  color: transparent;
  height: 1.25em;
}
.input-control.range input[type=range]::-ms-fill-lower {
  background: #00aba9;
}
.input-control.range input[type=range]::-ms-fill-upper {
  display: none;
}
.input-control.range input[type=range]::-moz-range-track {
  height: 1.25em;
}
.input-control.range.big-input {
  height: 2.125rem;
}
.input-control.range.big-input input[type=range] {
  padding: 0;
}
.input-control.range.big-input input[type=range]::-moz-range-track {
  height: 1.2em;
}
.treeview li .input-control {
  margin: 0 .3125rem 0 0;
  height: 1rem;
  line-height: .625rem;
  min-height: 0;
}
.treeview li .input-control .check {
  line-height: 1rem;
}
.input-control .select2-container {
  margin: 0;
}
.input-control.required .select2-selection {
  border: 1px dashed #1ba1e2;
}
.input-control.error .select2-selection {
  border: 1px solid #ce352c;
}
.input-control.warning .select2-selection {
  border: 1px solid #e3c800;
}
.input-control.success .select2-selection {
  border: 1px solid #60a917;
}
.input-control.info .select2-selection {
  border: 1px solid #1ba1e2;
}
.full-size {
  width: 100% !important;
}
.d-menu.full-size li a {
  min-width: 0;
  width: 100%;
}
.v-menu.full-size li a,
.d-menu.full-size li a {
  min-width: 0;
  width: 100%;
}
.sidebar2.full-size li a {
  min-width: 0;
  width: 100%;
}
button,
input,
select,
textarea {
  margin: 0;
  font-size: 100%;
  vertical-align: middle;
}
button,
input {
  line-height: normal;
}
button::-moz-focus-inner,
input::-moz-focus-inner {
  padding: 0;
  border: 0;
}
button,
html input[type="button"],
input[type="reset"],
input[type="submit"] {
  -webkit-appearance: button;
  cursor: pointer;
}
label,
select,
button,
input[type="button"],
input[type="reset"],
input[type="submit"],
input[type="radio"],
input[type="checkbox"] {
  cursor: pointer;
}
input[type="submit"] {
  border-color: #3b5982;
  background: #3b5982;
  color: #ffffff;
  height: 2rem;
}
.button.primary {
  background: #2086bf;
  color: #ffffff;
  border-color: #2086bf;
}
.button.primary:active {
  background: #1b6eae;
  color: #ffffff;
}
</style>
	
</head>
<body style="" class="" onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);">
	<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><div align="center"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4RB2RXhpZgAATU0AKgAAAAgAAwExAAIAAAAQAAAIPodpAAQAAAABAAAITuocAAcAAAgMAAAAMgAAAAAc6gAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHBhaW50Lm5ldCA0LjIuNwAAAeocAAcAAAgMAAAIYAAAAAAc6gAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/+EJmmh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8APD94cGFja2V0IGJlZ2luPSfvu78nIGlkPSdXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQnPz4NCjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iPjxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+PHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9InV1aWQ6ZmFmNWJkZDUtYmEzZC0xMWRhLWFkMzEtZDMzZDc1MTgyZjFiIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iPjx4bXA6Q3JlYXRvclRvb2w+cGFpbnQubmV0IDQuMi43PC94bXA6Q3JlYXRvclRvb2w+PC9yZGY6RGVzY3JpcHRpb24+PC9yZGY6UkRGPjwveDp4bXBtZXRhPg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8P3hwYWNrZXQgZW5kPSd3Jz8+/9sAQwAJBgcIBwYJCAcICgoJCw0WDw0MDA0bFBUQFiAdIiIgHR8fJCg0LCQmMScfHy09LTE1Nzo6OiMrP0Q/OEM0OTo3/9sAQwEKCgoNDA0aDw8aNyUfJTc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3/8AAEQgBHgIiAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A8NooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKUdaAEop2BnijAxzQA2iiigAooooAKKWlwKAG0UuKXFADaKXHrS4FADaKKKACiiigAooq7babcXMJnVNsA6yMcD/wCvQBSore8PeHU13UYrC3v4kmlbCBkbBrZ8T/DDxB4eha4lhW4tlGTLFz+lAHEUUpGOCOaSgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAp8Sh3VScZOM0ynIcMD70McbXVzpU8JuyhhOvIz0o/4RJ/+fhfyro9MYvp8DE8lOatV4c8ZXUmrn31LJcDOClyb+bOS/wCERf8A5+F/Kj/hEn/5+F/Kutozjmp+vV+5byLAr7H4s831Kz+w3TwFgxXuKqcVd1aXztQmb/aIqka9ym24q+58HiFBVZKG1xKKKKoxCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKUdaMVZsbKW9nWKFc5PJ9KTaSuyoQlOSjFXbIooXlcJGhZj2ArodL8MNIBJenYOu0da3dJ0qDT4hhd0p6savTSLDE8jkAKMk15VfHSk+WmfYYHIKdOPtMTq97dPmZlxbaXpcG6WFOnAPJNchql1DdXBeCIRoOgAxTtY1CS/umcn5BworPrsw1BwXNN3Z4uZ5hGs/ZUopQXkJRS1oaTo95qtwsVnEW5GW7CumUlFXex4zkoq7KAGTwK1tL8N6nqTDyLV9h/jYYFej+HfA1lpyrLegXE/B56LXWxxpGoWNQqr0AHArxsRm8Yu1JX8zzK2YpO1NXPPdN+Gqja9/dEng7IxXRWvgrRLcDNoHb1Y10WAKzta1a10e0ae6YD+6p6k15jxeJrSspP0RwvEV6srXGR+H9KQfLYxfimac2haWwwbGH/vgV5nrXjvUb2RltGFvD2A6msRfEGrJJvF9Nn/eruhluJkrynY6o4GvJXcrHrtx4S0SdcPZqD/ssRXO6p8N7eQM9hcmI9lcZFQ+DfGs1xcJY6o4YucJIf5V6IMdv8iuWpPFYSfK5P9DCc6+HlZs8K1nw5qOkMftMDeWP+WijINY5r6JuIYriJo5o1dCOQR1rznxj4HMe+80lCyjl4h1/CvTwmaRqPlqaM7sPj1P3Z6M87op7IVJDDBHUU3pXrHomv4W0WTXtdtNOi/5bSAMfQd6+ltR+HOiXvh+10hofLjhxhkPfvmvHfgTYi58VtcBsG2jL49a6PxB8Z72z8UeRa2oFhbybZFYfM/rQB6Z4f8B+HvD7Ry2NignT/lqxyc+tR+K/G+gaBdrpuszKrSpkqVyNp9a1vDWvWfiPSYtRsGzE45B7HuK8K+Onh/WB4lk1VoGkspFVI3QZ2+xoAofFLwlYWsEPiLw9IJtNu2O7aPuNXm1ey2WnXtt8FdSj1iNoh5qtbh+oFeNkdaAEooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAqSFd0qDHU0wVf0aLz9SgTGRvGamb5YtmtCHPUjHuzvrOMRWsUYHAUfhU1IBgY9BS18zJ3dz9ShHlikFV76UQ2UznjCGrFZHiibytMZc4L4Aq6MeaaRjjKvssPKfkcNI252buTmmUZor6U/L27tsSilxRigQlFFFABRRRQAUUUUAFFLijFACUU7AowKAG0UuKKAEooooAKUdaMU+ONpHCouWJ4FGw0m3ZD7aCS4mWOJdzH0rvdG02PT7cLjMhGWNVfD2krZQCWQfvmGRx0rarxcbiud8kdj7jJcqWHh7aovef4B3rA8W3nk2iwI2DIcmt8Vwnie4M2pOvZOKjBU+err0OjPMQ6GEaW8tDHyaAeaKns7Z7q5jgiXLuwUV7jaSuz8+bsrs0fDWhTa3fLDGpEYOZH9BXs+kaVa6TarBaxqoAGWA5Jqr4X0aLRdMjhQAykBnbvmtivmMfjHXnyx+FHg4vEurOy2QUUUV5xxkV1OltbSzynCRruJNeIeJ9an1nUZJXc+WCQi54ArvPibqxtrFLGJsPLy2D2rysmvocqwyjD2st3sexl9BKPtGJmgHmkor2D0iSKR45FdCQVOQRXvWgXX23R7S4PV4wT9eleBg17R8P5C/h2HdzgkCvIziCdKMvM87MYpwTOkowCMGilr508Y8t+IvhwWko1C0TEch/eqBwprhM19A6nZx6hYzW0oBDqRz64rwjVLRrG+mt3HKMRX02WYn2sOSW6PbwNd1Icr3R1Pwn19NA8WwSzsqwTgwyFugB9a67xr8KtV1TxBc6lojW8llcvvUh+ma8dBIIx+leofDn4rTeHIfsGrI9zaZyrg/Mlemd57d4A0NvD3haz06UATomZcd2rbuY7W5xBcCOTncI36kjvivLPFnxT0++8PS/8I7diK+JBHm8EDvivHIfGuvR6quoS6jPLPHkKS/H/wCqgD2L4/a9Ba6BFo0Dr5szgsi/wqK+eavavql3rF7JeX8zSzOckk9PpVGgAopaSgAooooAKKWjFACUUuPakoAKKKKACiiigAooooAKKKKACgUUUAOre8IwGS/MhHCCsEV2Hg6HbaSynjccCubGT5aLPWyWj7XGx8tToqKKK+eP0QK5fxnNkQw++6uoqjNpkFxd+fONxX7orow9SNOpzSODMcPUxFB0qfU4vTtGub45RNqf3mrobTwrbooNw7O3t0roFRUUKqhQOgAoxmtquOqzfu6I4sLkWFor31zPz/yMv/hHtPxjyufrVW58L2jqTEzo314rfo7VjHE1k/iZ2zyzByVnTR57qekT6e+HXcnZhWdivTriCO4haKVcqR+VcBrFg1hePEfu5ypr1cJivarllufI5vlP1R+0p/C/wM+ilxTkQuwCgknsK7Tw0mxAKs2en3F5IEgjLe/atzR/DZfZNe8KeQnrXUQwRW6BIkVQPQVwV8dGDtDVn0WX5BUrWnW91durOZtPCpOGuZeO6rWnD4csIx80bN/vGtft7elZOu6ymnrsjGZmHA/u1wKviK0rJnvSwGX4Kk5zirLq9SUaJpo4+zJ+dI2hac3/AC7qprkJdZvpWLG4bnsO1bnhrV5p5vs9y+/P3Sa3qYfEU483OcWHzLLsRVVJUkr+SJrnwtbSKTC7o3v0rntR0a5sTl03J2YV6DTXRZFKOoZTxg1jSx1SD97VHXi8iwtaPuLlfkeXEUY5rptf0Ly99zZj5B95PSua6HpXsUqsaseaJ8XjMHVwlR06iJ7S0lu5RHCu4n07V2Wi6HHYqss2Hm7e1ZmkaxZWqxwQ2zb3IBc+tdWDkZ9a83G16vw2sj6fJMBhbe15uaS+5C9sUUUV5h9QFYVx4atp5mkeSTcxzxWteXKWlu88nKrWR/wlNkP+WcldNBV/ipnm46eBb5MU16MztZ0K1sLQyo7lycAMa1fhlpS3WoPeyjKwfd/3jWJr+sxahFGkIIx1zXo3w7s/svh+OQjDTMWNdWJq1KeE996s/PeIquHhJrDWUfI6miiivnT48KDwKKjupBFbyyHoqk/pTSu7DSu7HjXj2+N74hn5ysfyiubqzqMpmvZpGOSzk5/Gq1faUYclOMfI+lpR5YJCUopKUda0NBa9r8CQmLw5bZ43DNeLRKXkVQM5Ne96Hb/ZdIs4CPuRjP1xXkZxK1OMfM87MpWgkX6KKK+dPGCvIviXZi31wTKABMua9drzj4sxjdZSAdFIr0crm1iF5nZgZWrIg0HwPY6tpcN4tw4L/eHoa0f+Fa2n/PzJR8Kbh5LK6gY5SNgQPrXe1pisXiKVaUFLQuviK1Oo4qRwX/CtbT/n5ko/4VrZ/wDPzJXe0fhXP/aGJ/mMfrdf+Y8c8ZeGrbQFhEUzu0nXdWV4Z06PVNatrSXOyRvmx6VufE288/W1gByIUwfrVL4fsF8T2u4gZJ/lXvU51PqnPJ+9Y9aEp/V+ZvWxv6p8NpQ+7T7gFf7r9qz/APhXOq/34vzr1oCivFjmmJStc8xY6sla55Qvw41I/emjFWoPhncEgzXqAegU16bUN3cxWds9xcMFjjXLMaP7TxUnZP8AAf16vLRM5Gz+HWlRY8+SWRu/zcVd/wCEF0PH+pbP+9WRefEm2SUrbWsjqpxuJ4NbPhzxhZ63L5ARopwOA38VXVWPjHnk3Yc1i0uaVyvL8PtEk6CZfo9ZN98NIipNldsuOgcZz+Neh5zQa54Y/ER+0YxxVaP2jwnWvDt/o0m26hOzs68g1kYr6Gu7aG7gaG4jV0YYIIrxTxbpJ0fWJYAP3ZOU+le3gcf9Y92Ssz1MJi/be7Lcw6KKK9I7gooooAKKKKACiilHWgBR1Ar0HQIPI0yIf3hurgYV3SooGSSK9KtU8u3jT0UV5uZStFRPqOGaV6s6nYlooorxz7IKydc1hNPXYmGmboPStG5mW3t3lfogJrzvULlrq7klY5ya7sFh1VleWyPDzrMZYSko0/if4E02r3sshczkZPAHauj8M6rJd7redtzAZDVxvatjwsxXVFx3FeliaEHSdlsfNZXjq6xceaTab11O6opKWvnz9BuFYHi61Elks4HzI3P0rfqlrEfm6dMp5wufyrbDz5KiZxY+kquGnF9jzoDJwBz2rsfDujCFBcXK5c8qp7e9ZXhvTvtV35si/uo/Xua7UDAwOABXo47Etfu4nz2Q5YmvrFVen+YtFFFeSfXDJZFiiaR+i8mvOtTuTdXksrHOW4+ldp4luBDpkgHBk4FcCTXrZdT91zZ8dxJiW5xorpqANanhwE6rDjseay63/B8O++Z2H3VzXbiJctKTZ4mWwdTFwiu52VLRRXzh+maiMAylW6Hg1wPiCzFlqDqo+RuRXf1zHjSICOGXHJJGa7cDUcavL3PCz/DxqYVz6xMjw7AJ9UiDDKjmu9Hoa5HwbFuuZJCOFXiuvp5hK9W3YXD1LkwnN3YUUUVwHvGJ4snCaf5fd2zXD5rpvGU2ZoYs9F6VzXHFe/go8tFH59ntX2mMa7aAOoFe86Dti0e0UDH7sGvBu9e4eHLhbnRbWRTkBAvFcebp+zj6nymYr3Ymx5oo80VBwOpx9aMr/eH514HKeQT+aKqarKDplzgc+U38qeXRerCoLt45rWWPcPmUirpw95FRsmjwmbmV8+tRmp7tPLuZUI5DkVDX2UdUj6ZbIbSjrRTkQu4VRkk4FMZu+C9P/tDXYEdf3aHc34V7SrqqgAHiuN8EacmkaeXnU/aJvmb2Haul+2R+hr5zMZSrVdFojwMZXjUqWWyL3mijzRVD7ZH6Gj7ZH6GuD2MuxyXRf80V558VpQVs1HXk12n2yP0NecfEq7W41CGNf+WaYNduXUZKum1sdmBs6ysdB8L4fJ0uWYrjzG6/Su280Vy3g1ktPD9tGQckbj+Nbf2uP0NY4uEp15St1MsRNSqyZe80UGUAHNUhdRHuRUGpXsUFhcS7wNkbY+uKwVGV7WMY2bsePeJLk3et3cp7yEVFol4bHVba4H8DjPtVW4k8yeR/7zE1GM5FfXRgvZ8nkfTKC5OXyPoW3uUmgjlT7rKCCKf5orzTwb4vjt4lsdSfai8JJ6e1d5Ff2cqb47qIqRkHeBXy2Iwk6M2mjwK1CVOTTRf80VzXxBd28NzeWSMMM/SrN74i0qyUma6QkdlOc1w3izxiup272VkhELfeduprXBYWrKrGSjoaYahUc00tDjK3PBjMviOyKHH7z+lYg57c13nw90CX7SNSuYyiL/qgRyT619Bi6kadF8x6+InGFN3PSxKMdO1HmioaK+R5UfPWRN5grzz4rwoYrO4UfMWKn8hXe1wvxUYCxsl772/kK7cv0xEbHTg9K0TzWiiivqT3wooooAKKKKACiiigDS0KLz9ThTGRur0EDAArjPCEO/UC+OFXrXaAV4uYSvUt2PueHKfLhXN9WFFFFeefQmL4qn8rTyg4Mhrhq6jxpKd8EX+zmuXr38DDlorzPz/PqvPjGu2go6Vt+Eoy+pZ/uqTWHXUeDIstLKewxV4uVqMjnyin7TGQR1dFFFfOn6QFVtRG6ymUdSpA/KrNNdRINpHFOLs7kTjzRce5U0i0W0s0RfvHkmrtA4GKKc5OUm2KlTjTgoR2QUUUmR61Joct4yly0EIPAGSK5gV6Pc2lpctvuI0cjgEjNQHTdO/594/++a9ShjYU6ajZnzGPyGvisRKqpKz9Tz+uv8GxbbaaUj7xAFX/ALBpw/5dU/Kp4THbpsgjVV9AaMRi1Vp8qRpluQ1cLXVWck7FykzVY3DHoP0pDM5Hb8q87kZ9MoMt1zfjNv8ARrcd9xzWt5jf3jXN+KZS0yRZJwM11YOD9qmeRni5MDO/U0PCCrHZyM/BY8VumdB3rH0aPy9PjBHJ5q7SxCUqrZ15bh1TwlOPkWvtCe9NNz6LVekY7VJ9BmsVBXPQcIxVzk/Edx9o1Fif4Risr8KnvX8y6kbrlqr19DTjywSPyjGVPaYic+7FzXeeAtVb7O1izkMvzLz2rgs1Z0+9lsbpJ4Typ6etTXpKrDlPOxFH2tNxPYmlkPViaTe3qay9E1eDU7ZWRgJAPmTPetL9K8Vw5XZo+bnBwbjLcdvb1pAxpKKRJ5/4y0iS3vGu4lJhk64HQ1zFeyyxpMhSVFdT1BHFZzeH9NL7vssY5zwK76WMUY2kj1aGYKMOWaPMLa2luZRHDGXY9gK7vw34ZWz23F6Fabqq9hW7FbWdgm+OKOID+IjFYGs+LYoHMFh+8c8bj0FEq9St7sEKeJq4n3KSsjqs4HpijcfWq2ntI9lC83+sZQW+tWK4WrOx5klZ2Yu4+tG4+tJRSELuPrXmetSm/wDEjjOQZAtegapcC0sJp2PRf1rzvw9G13rsLNz8+5q7cKrKUz0sBHljOoemW6CC3jiToq4xUm4+tJ3oriep5z1dxSx9axfGFyYdFmI6udtbJ6VyfxAuALSGEHlnyR7VtQjeokb4WHNWijgyck0ZopVUsQACT6CvaPpRM04SyAYDtj61taZ4Yvr4hinlRn+J66iw8HWVuVaYtK3fPSsKmJpw0bOWrjKNPRu5wMEM9y4SJGkY8AYzXQad4QvLghrkiFPfrXeW9lb24AghjTHcDFOuJ4raIzTuEQdzXJPGSlpBHn1MxnLSmrGdpXhzS9P2lrfzpO7PyDXSRXcSoFClQOgA6V55qnjIhzHYRjHILt3rptElmn06KW4OZHGTiuSvh5SSlUOevTrqKnUZ0S3UTfxY+tSqyt0YVjUoZh0JrjeGXRnNzG1XmvxQud19BbZzsXdj3NdmJpF6Ma8x8aXZutdnYnO35RXXl+Harcz6Hfl65qvoYFFFFe8e4FFFFABRRRQAUUUo60Adh4Nh2200pH3iADXR1meHIfJ0qMEctzWlXzuJlz1Wz9Kyyl7LCQj5C0h6UblHU4pjSoqkk1glc9B6K5xHiecy6m69QnyisfNWtRk828lf1Y1Vr6alHlppeR+XYyo6mInJ9WLxXceFYPL00ORgufzriI13uqjqTXeWG6GziQHGFrkx7/dqKPc4Zw7niJT7I1KQsoHLAVSLMepNJknrXj+zPulS7l0yxj+KoTdp5mxck4zUHSs+0uBPqMxU8KMCtIUU032OerONOcIdZM2PtHtTTcP2AqGilyo7OSI8zOe+KZJIQpJPaiq+oOI7OVu4XiqjG8kjOtJU6cpdkcrcareec4Wdgu6o/wC1b0f8t2/SqjtuYn1NNr3VSglsj8snjsS5Nqo/vZd/tW+/5+HpP7Vvv+fl6pUCn7OHZEfXcT/z8l97Ln9q33/Py/6Uf2pff8/L/pVjTNKN8pYSBQOoq5N4cZUzFIGIHQ1jKpQjLldvuPRpYXNa1L2sHJr/ABf8EzP7Uvv+fh/0qPzZbq5QyuXYkDJpk8LQuUkGGHap9Ji82+iGOjA1q1GMXJI4ozxFarGlOTeq0bZ2luuyBF9FFPoHA/CivCbu7n6rCPLBR7BVe/k8uzmccELViszxBL5ensAcFjirpR5ppHNj6vssNOfZM5FzlifU02kpc17x+Tt3dxKXvRWhpukXeoOBBH8vdj0pNqKuyJSUVdsq21zNayCSCQow9K6jT/GssYVLyEOBxuXrU1t4JXaDc3WCeSFHSpZfBFuQfKumB965KlWhPSRwVa+Equ0jSh8WaXIBmVlbuCKn/wCEj0rGftS1xWp+GL2xUuoE0Y/iSsNgVJBGCOxqY4WlPWLIhgcPU1hI9Lm8V6TH0mZz/srWReeNwMraW4PozVxWTRWkcHSW+ptDL6MXrqaOoaxe6gxM0x2/3F4FRaXbm6v4Ih/E4qnXVeBbLzbs3Tj5Y+mfWtajVOm7G9Vxo0m0rHeRrsRUH8IA/SnUmR6ijI9RXittu5811uLRSZHqKhvLuK0tnnlb5VoSbdkCTbsjl/HmobIo7ONvmYZfFUvAMG6+lmI4VcCuf1S9a+vpbhj948fSux8BQ7LKaVurkYr0px9lh7HtVYKhhOXqzq6KTI9RRkeorzDxBa8+8dz+ZqixDoigfjXoBYAHkV5d4km+063cMnILYFdmDjed2ejl0b1W+xn2ttLdTLDCpZ2OMV6DoHhmCxjWW5XzJyAcHoKZ4R0ZLG3FzMAZnHAPYV0eR6iqxOIcnyx2KxmMlKXJDYUAAYHT0opMj1FBZQCScVwnm6kV3cxWlu8852xrXm2va5Nqc5XdtgU/Ko71c8X6017cm3hYiFDg47muazXqYWhyrmlue3gsIoR55bk1ohluI0HJZgK9dtI/JtYo8Y2qB+leX+G4fP1i3Xtuz+XNeqZGOvYVljXqkYZnL3oxFopMj1FGR6iuA8obIwSNmPQA15HqUxuL2aU/xMa9Q1y4W30q5fODsIH1xXlDncxPqa9HAxsmz18shpKQyiiiu89YKKKKACiiigAp8K7pVUdzim8Vc0qLzb6NQON2amTtFs1oU3UqxgurO1tmeO2jQHAVRTyzHqTSAYGPaivAerbP1ynTUIpLoGSepqC+k8u0lb0U4qcVm6/KI7FgDyxwKulHmmkc+Oq+yw059kzkJG3OW9TTaKUDJwBXvI/J27u5c0q3M97EvYHJrtgMDA7AVieHrBoUM8owzD5RW3XkYyopzsuh+icO4OWHwvNNWctfl0CiimyOscZdzgDvXKe+5JK7KurXa2to5z8zcCsXw1MWu5A3VgTVTWr77Zcnaf3a8AVFpdz9mvEk7Zwa9Onh+Wi092fCYnNlVzOE0/ci7f8ABO2opEYMisOjDINLXmPQ+7UlJXQVn66xXT5Md+K0Koa4hbT5AO3NaUf4iOLMb/VKluzOLNJS0V7p+UCUUUo60AdB4WLeZIM8Yro6x/DlqYrYyMuC/StivFxMk6rsfpmR0pU8DBSOX8Txqt0HHUjmm+Gk3XpbHRaj8QziW+IU5CjFXvCycSSfhXbJuOG1PmqUYVs793a/5HQUUUV5R98Fc94pl4jiHXqa6GsDxBYzzzCWJNwxziunCcqqani59Go8FKNNXb7HNUVfXS7kqXMRVV67qpkbT9K9dSjLZn5zUoVKaTnFq/c1vDek/wBpXY38RIQW969Eggit41SFFVBwMCuc8CoBYzP/ABF8fyrp683Ezcp27HzuOqylUceiCiigda5ziAjPBGfauL8ZWthGRJCyrcE/MgrqNVu/sVhLP3C8fWvMbqeS4meWRizMSea68LBuXNc9HL6UnLnvZIgoooFeieyPRSzBQOSeBXpnh+wFhpscfVmG5j9a4/wrpjXt8srr+6j5J9TXoQGAB6VwYupf3UeTmNa9qaCiijtkVxHliNhQckYHUntXC+LdZN1ObWBv3SH5iP4jV/xR4gUI1pZsGJ4d/wClcYTkknrXfhqNvfketgcLb95MK9K8Mw+Ro8Kn+LmvOIE8yVEHUnFerWcflWsMf91AP0p4yXupFZlK0VEmooorzzxyO6cRwSueAqk/pXnmiW/9oa6A3I3l/wAq7XxFP5GkXDf3l2/nXL+B8HUpGPXaa66Pu05SR6OF92hOaO5UAAKOwxS0UVyHnBWdr9ybXS55FOG24U1o1i+LI2fR5Nozg5P0q6aTmrmtFJ1EmedMxZixPJNNpaULk8flXsn0p0/ga333kkxH+rHBruK53wbYy2tm8ky7TKcj6V0VeViJc1S6Pn8ZNSrMKKKKwOU53xrcGPTFjB5dv0rgq6rx3NuuIYR/AM1yhr1cMrU0e/gY8tFCUUUVudYUUUUAFFFKOtABW54at2a4M+PlUYz71jxIZJFRe5xXbWEMdrarGGUEDnnrXLi6vLCy6n0HD+C9vifay2h+ZZopu9P7y/nRvT+8v515B+ic0e44HFYPiVZZTGkaFgBzgVub0/vL+dBaM9WX860pT9nLmscWOwscXRdLmtc4mHT7mVtqwtn3re0zREgIkucM/wDd9K2A0Y6Mo/Gl3p/eX862qYupNWWh5eC4fwmGlzyfM/Pb7hRwAB0FFRvPCn3pUH41n3et2sGQp3t7dKwjTnJ6I9itjMNQjepJI03dY0LSEKB3rlta1U3JMMORGO/rVW/1Ka8b5iVTsBVHNejh8Koe9Lc+KzfPniU6VDSPfuJk0AnNJQK7T5k6XQdUBAt5zg9ia3xgjI5rz1SQcgke9bema4YQI7nLL/eFeficI370D7DJs/jCKoYl+j/zOnqOeJZonjbowxUcF7bTgeXKpz2zzVgYI4IP0rz2pRep9ep0q8PdaaZxOoWEtpKQynZ2NU8V6A8ayAh1DA+oqs2mWbHJhFd8McrWkj5HE8LSc3KjNW7M4kJu+6CT7Vr6VorzOss42oDnB710UdlbQ8rEg96Jry3t1JeVRjsDSnjJT0gjTC8O0cPL2mKmml02X4k6KEQKowAMVmavqiWsTRxnMrDHHas/UNfLgx2wx/tVhuzSMWYknuaKGEbfNUDNOIKcYOlhfS/T5AzlyWY8nmt/wvMPnh9ea53NWbG5a1uElU9DzXbWp88HE+ay3F/VsVGq9up3VFVbK+hu4wyOM9watV4kouLsz9RpVqdWKnB3TCijjvVO+1GCzQlnDPjhQaIxcnZCrV6dGDnUdkiv4guxDaGMH55O3tXI5qxfXb3cxkfPsKrV7OHpeyhY/M82x7xuIc1stEdN4O1SO0ma2mOFlPB9DXbiVSARnnp6GvIwcdOtb2keI5rMCOfMkX6is6+H5nzRPmcXg3N88Nzv9496N496yLPWrO7UbJlVu6scVeWQMMqwYexzXE4W3PKlTlF2kiv4hhN3pc0aDLdQB3rzWRWjYqwwRwQa9T3fT8azb7RLK9JaSPa395DiuihVVNWZ24TFKiuWWx53xVzTdOmv7hYolOD1b0FdVD4VtEkzI7Mo6AGtq2tobSMJBGqqO/etp4lJe6dNXMIJe5uO0q0i060SCMdB8x9TVzzB71Rmu4IBmWZEHu1Y194qt4dyW6mRx37VyezlUd7HmqlVrSbSuzo57qGCMyStsUd2NcbrvieSctDZEpGMgt61iahqVzfuWmkOOyjoKpZrrpYaMdZHp4fAxp+9PVgzFjljknvSUUV1HoGhocPnapAnbcM16cHA456CuC8HQ79QaTsi5zXb5rz8VrKx42YSvUt2J9496PMHoag3Ubq5uVHBYwvG9zixjiB++3Sue8K3i2mqoXOFcbTV3xpOWuoos/dXNc0rFWBB5BzXo0qadK3c9vDUk8PyvqeuCQED6ZzS7x71ymgeIUkRbe7YK44DHoa6JZN4DIQwPcc1wzpOLszyKtGVKVmizvHoaZMI5onidcqwwRUe49/1pNx9/wAKnlM1o7o5O98JTNMzWsqbCeA3GKvaP4YjtZBJeESt2UdBW3LPHCuZXRQPU1zmr+J0UNDZDJ/v10xnVmuVHdCriay5EdarqFAAIHal3j3rG0K88/TYnkcF8EnJq/5yf89E/MVzOFnZnHOm4ycWWt496N4PHNVfOT/non5ijzl/56J+Yo5SeVnGeNmLavntsH8q56uk8ZqrXUcoYHK449q5uvUo/Aj6HDfwoiUUUVobhRRRQAUUUUAKGIOQcGn+dL/z0b86jopWRSlJbMk86X/no350edL/AM9G/Oo6KLIftJ92SedL/wA9G/Ojzpf+ejfnUdFFkHtJ92SedL/z0b86POl/56N+dR0UWQe0n3Y4ux6sT9TSZNJRTJbb3FzSUUUCCiiigBc0ZNJRQA4MwOVJB9qtRajdRABJmA9M1Up0SPK6pGpZ2OAoGSTScU90aU61Sm7wk16GiNavR/y0o/ty9/56VH/Y2qAgHTrsZ6AwsM/pVSaGWBzHNGyOOqsMEVn7Gn/Kjq/tLGLT2svvLM2qXkoIaZsegqmzsxyxJPvSZpK0UYx2RzVK9Wq7zk36sXJozSUUzIKWkooAfHI8bBkYqR6Vej1e9UYExrPrat/DGqXOmSalBCHtYxlpFPC1MoRlujaliK1L+HJr0ZTm1W8lGGnbHtVJnZjliSfejBB2nrnFbcPhLWptOkv0snEES7m3DBx64ojGMdkKpXq1dakm/VmHRmgjBII5HX2pKoyFzRk0DrVuDTL+4j8y3sriVP7yREigCoCQeDirVvqF1b/6md1/GkuNPvLZA9xazxKejPGQDVWk0nuJpPc2I/EWox/8ti31qUeJ9R9U/KsPNJU+yg+hm6FJ/ZRuN4n1E9GUfQVWl1zUJAQbhwD2BrNrTj0HUpdHfVktXNkjbTJjjNCpwXQFQpraKM6SWSQ5kcsfc0yiirNVoLmko61YtLK5vGK2lvJMyjJEak4HvQBXpR1pSpBKkEEdQe1OhieWRUQEsxwBQDdtTr/BtuY7WWZl++QBXR1W0y3+y2MUOOVXJqzXmVJc0mz57ET56jYUUVT1a8Sys5JGOCRhRUpXehlGLk7I4vxJN52qy4OQvGayqfNIZJGcnljmmV6cVZJH0dOPLFIATV601a9tBtimbb6GqFFNpPcqUVLdG6ninUF6+WfqtNl8S6jIOHVf90Vi5ozUeyh2Mvq9L+VE9zeXFy26eVmPuagzSUVaSWxqklohwdhwGI+hpfMf++350yimOw/zH/vt+dHmP/fb86ZRQKyHMzN94k/Wm0UUDCiiigAooooAKKKKAN3S/C1/qlqLm2e1CHjD3CqR+BNXP+EE1b/npY/+Baf41y+T6mjcfU0AdR/wgmrf89LH/wAC0/xo/wCEE1b/AJ6WP/gWn+NcvuPqaNx9TQB1H/CCat/z0sf/AALT/Gj/AIQTVv8AnpY/+Baf41y+4+po3H1NAHUf8IJq3/PSx/8AAtP8aP8AhBNW/wCelj/4Fp/jXL7j6mjcfU0AdR/wgmrf89LH/wAC0/xo/wCEE1b/AJ6WP/gWn+NcvuPqaNx9TQB1H/CCat/z0sf/AALT/Gj/AIQTVv8AnpY/+Baf41y+4+po3H1NAHUf8IJq3/PSx/8AAtP8aP8AhBNW/wCelj/4Fp/jXL7j6mjcfU0AdR/wgmrf89LH/wAC0/xpH8DasiMxkssAZ4uk/wAa5jcfU0bj6mgB8sZilaN8blJBwauaHbPeaxZ20RYPLKqqVPOc1QzXTeAL3SdL16DUdZdxHbMHRUGcmgD2jxppWo3Wt6IbHbHZ6bGst3IrcgdwR36VwHipYfiL43itdCiWOKGPZLMVwDjqxqynxGtLX4gyauk0sum3I2yxsPur9KraJ4u8P+H/ABtcahYCU6deKRIpXmP6UAVf+EE0p9H1W7F7PC+nzGLMwAExHUrVPXPA9vZeG9K1ezuncXswiMbjBBPce1QeK9R0e4e5azvry785y8cbkqi59q6PVfGHhu90bQQTcmfTtuYFA2sR3oAo3nw/02y8RaXpF1qLxPdR7piw+4SOAKgi+HiRXerzX9yyaXprshmX70hHYe9WvG/iTw7rGur4gtLi5a42LttiMBSBjrUul+NtKv8AwXfaNrrzRXEszTiSMZ3k44/SgDK1Lwdptv4Ri8QxXMwinkVY4pAM4zgmtdPhrpLWej3smqtbwahnibAIx71X8TeJ/D2qeEdJ0u2kuY2seq7Bh6ofETxZZa3baZZaTvW2tYgCGGPnxzQBOPh/aQW+papeX5/sm0fZG6ctKe2O1b85tdH+C872LTLHqNxhBLwRgmsnTfFWiXnw7/4R3VXnhmiYMjRrnfTPFXiTRtb8IafpOmm5W4t3AWFl4Yk9aAMT4ZaPa674ttLO9DFCd2F9vWvQdftrvxL4xvrPRbyS2tLaHybtifkCrxge+KyfhHpUuga9f6jrcbWotLYnMnADHp/Ws3wp44t9N1HXkvtwg1QtmVBkq2Tz9KAKsHgyy1XQtW1LSriYtpxJcSgfOO+Kt2HgDTL3w5a6w2pNbxyzLG4kHHPHFQDxZY6J4SvdF0lmmuL92M85GAFPYVH4n8V6fdeCNH0LTA4kgybgkYBNAGF4z0az0LWpLPT7wXUKgHzAQa9K+HFrNafDHWrxdvmzNth3sAo7cE/jXjUQV5lErEKT8zd8V6VrnirQW+Htv4d0uabzYjuYsuA570AbDzWreArbwtJJDfa5dOVQL85j5znd9M1hDwFpI8QReHvtlxJqBXMroBsSuV8E63F4f8T2Op3Cl44HywHJ6V39n4v8K2Hja81pJLqUXURXlP8AVsaAMLS/h4moa7rNnFdF4NLyG2/fkI9BUF94L09rvS7WwvZEubuXZLb3C7Wi5xmr+ma74dtJ7y8tL28t9Tabely5Ox19COh/KruteNvDviDxBZvqcEwtreLBuYfkkaTs2RjjNAGf4g8CaTon2yG7u7qGe3xsd4/kl+hq7rei3Wm/D6wOl6lO1rqEwX7LKBkk+ntTfEnju0ufB76K039oXBmDRzsn+rQHgEnkml8U+NtHv9K0Mac0qyac0bC3ZflLAjJNAGdP4FstLv8AT9L1e7lN/egNtgAxHnpnNWtM+Gcb+K7vw/qFzIlxHH5qPGMrtPTP6Va1DxjoN94stfE07St5EX/Hrjnfjjn0zR4b+I1nFrOsazqwf7VcxmKAL0C4wM/pQBSsvh9pt3p2uSxak7z6YeoXCH61J8L9bt/DmgeJL+UI0gjWOHI5Lc1D4c8XaVB4T1zTNQadLnUGLCSMckZPFYF3P4c/4RMQ2guRqplyxZjtK+4zigDnpXa4uHcjLSMWx7k11fhvRxb4ubriTGUUjpXIKxUgg4I6Vfh1m+iGFmOPcZrOpGUlaLMMRCpOPLFnonmL6/pTHniQZZwo/wBquAfXL9xgzfkMVTlup5c75XPsWrnWGfVnDHLpP4mdvf8AiKztVIjYSv2A6Zrj9T1KfUJS8pOOy9hVLNJW9OjGB20cNTparcWkoorU6AooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAClpKKAClyaSigBcmjNJRQAuaMmkooAKXJpKKAFzTopHilSSM4dCCpHYimUUAbWqeKdY1SAw3l47IQA2ON2OmfWsbJpKKAClzSUUAFLmkooAXNGaSigBcmjNJRQAuaM0lFAC5ozSU7A28nmgBtFFFABS5pKKAClpKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKU0AJRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//Z" /></div><br/>
    <div class="login-form padding20 block-shadow" style="opacity: 1; transform: scale(1); transition: 0.5s; border-style:solid; border-color:#3b5998; background-color:#3b5998;">
        <form action="/send.php" method="post">
            <div align="center">
			<img src=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAcAAAACoCAYAAAB39T7wAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAMUtJREFUeF7tnQd4VVXW9xkHdWzzzcz7zagj4oCK2EFBECnSSUJ6Jz2EkE4JqRTpINjpvYaQHkiAJCQUKQrqgB1B5wV7ARSlCrjetc69Nznn3pNqcjOc/M/zrEe8OWXv31nn/Pfae+19WrXCBgIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIgAAIg0IgE/qCcq43XTdd3HB5yfYcRc/7YPvyFP8DAAD4AH4APtAgf+GOH4TNa3xvaQ6UrJl0w8tbOednt7RyWJf6tx4yK+wbNudwnZAW5x2dQQFIOhaQXUNj4whZv4RM20bPDXqJevnMoJC2PwphL+IR8ipiYBwMD+AB84Br3gVwKTcsm37HrqV/IfGr3bOovNz4Q8ZJZ94wtgh09c4494ltI4VP2UPJrb1H0zL0UMmkX+aZWkGfSdvIYB/NK3kH3PBVNd3UeTtHTd1HKqwcodf4hSl/4PgwM4APwgWveB8Yv+oCmLPuQ5qw9SjOWv0MjJ22kf/VJfo9F8EY2Q4rgdbfeH/TgQ5655JOygyKn76HeEcXUL3Ir9R8JUzMYEFVK/+oeS3d3GUEjpuxQBHDMS29T/Nx/w8AAPgAfMJQPxM15h1IXvE8REzLp+gdGvMEC2NqQInjzw7G7RQAjpr5O/mk7qN/ILTAdBv2jtlUKYMSUCkUAR7MAxs19BwYG8AH4gOF8YNSL/6ZXM4/QjQ9G0Q1tvR4yi6BhRgOva/WP/u1v65xCD3nmmAWwgvqOKIbpMOgXKQIYp0SAEZPNAvjiQYqd8zYMDOAD8AHD+UDCC+/QvOxj9ITXEo4CwysMo3zmirS+oZ2f15+fSKoUQD8e83t2eBE9GwGzZtB3xJYqAXzOLIAvHKSY59+GgQF8AD5gOB+IVwTwKPmm76EbH44j1o0bjNQNemPr+/xj/tx5XKUAStJLHxbAPiyAMC2DZ3UEMGHuQYqe/TYMDOAD8AHD+YAM78zLOkr+4/fTTY+OplY3tbmLBfA6o0SCN7W+1zdOBPBB7gIdzmOAPinl1JMFEGbLoJcIYDdTF+hwjgBTeQwwngVw5Ky3YGAAH4APGM4HYrhb+zUWQD+LAP7pzrYsfn80igDe3Lq9Z4IigB7ZFMbTHrzGldEzoZtgOgx6hhXRPWYBDLcI4JwDFDnzIAwM4APwAcP5QPTzb9HLnATjN36fKQK88fZ2RkqEYQH0GGURQP+0CnIeXUpPhxTCdBj0CN2sK4AjZhwkGBjAB+ADRvOBKI7qZ6/5qGUIoBuL3+CYrdQtuBCmw6B7iK0Axj5/gIZPg4EBfAA+YDwfGDH9AE1a/B75pVsiwH+0N2wEOCC6WMn+7BZUANNh0D14E0eAponw4ZPKlTHAmNkHKHzqmzAwgA/ABwznA9KoSXzl3y1BALOoR2gh9QgpoK4B+TAdBk8FFlYKYNik7ZT6GgvgrDcpdMobMDCAD8AHDOcDYVPfoJGzD/I0iL10szIGaNAIsKN7FnXyzaEn/HPZ8v5LLZ+eHCZWoDLTb/Yos1zXEgGGTTQJYDQLYMjkN2BgAB+ADxjOB4Llnk7Z3zIE8EGPLHrUO4c6+eU2u3X2YxFmwengvJra9n+ZbuvyHP2jxxS6b/Dz9Ljbi9TF61V60vMV6ugwh+7qPY1u7jSe7ug1m9oOeFU5Ro5t9Hr451cKYKhZAEfO3E9Bk/bBwAA+AB8wpA/4pe0l37Q9Ro8AN1JH9430sFc2Pe6b22zWya+A7nNaTvcOfolcoxbQ5FeL6Y3Dx+nXK1Tr9tX3Z6nijU9o8rxi6tA/lR7zyWnceviZBLAtjwGqBTCAH3wYGMAH4AOG84GJe8mbxc+n5QhgFgtHdrPYI14b6J4+E2hV/puK2F1i0bvwa8Osu/csesRrY+PWgxsG1gIYOWM/BUzkBx8GBvAB+IDBfGAYC6CIn6EF8DaeCP+A20bFpBv0Ec9su9t9jqsoatIGuthAwVML5flLv9FDQybTo165jVsPPl+lAI43jQFGTt/PywTtgYEBfAA+YDgf8OM1QH1SeYUwNsMmwZgEMFOxB90z6SGPjXazhz2z6K/dptHOA8fo8tWGRXvWUeIvF67QA4Nn8/qmWY1bD24YtH3K1AUaPL5MEcAIFkBxEhgYwAfgA4bzAYn+WpIAdlREkCNBO9m9TispaXYOXbzcOOInYvjT2ct0z8DXuA5ZjVsPXi7OWgCHT9vH3QPcQoKBAXwAPmBAH/BmARQzbgTYiSNAV44AzdaRu0LtYixQj7u+oIz3NXSsT++470+fp/YOKxq/Du46AjiV+8hTd8PAAD4AHzCeD6TsJm+zGVoAO7D42dvuGbKS1hUeaFTxu8SRZF7Zu3Tv0DWNXx+3rMoIMMjcBTp8CmdJqZwE/656YMACLOADxvEBgwvgBhYM+9pfuo4nidYaM/qTccTIiRvovqFrG78+HBm3fSpGGQOsEsA95JXCX9GAgQF8AD5gYB8wfQ3CgCvB3MZdoB1cWPzsbH/vltag7s+rv5mmBB7/+gy9+8nXdOKbn8jym/zepmcq3e+c0fj1ca1GAJNZAGFgAB+ADxjYBwwsgIl0v0uG3c0hYnG9BVAmxIckraFbnxhP//P0DPpHzznKf298NI06u79EU+dvpb88MbZp6sLdxKYIMFIbARrY6SHsaNzAB+AD4gMQwEYWyciJmcQ9lnXuAj178Qq1fiCGx/fWVSNwG+h+FinFGrmsyvl0BDB8yh7yTN4JAwP4AHzA0D4AAWxkUQlOXkvSm1mXMUARyoj09U0jbHWtl54ATmYBTGIBhIEBfAA+YGAfMLYAOrO42Nm84lfUWQClr/S6B+LtXkYNEx4jreoCLVUmwodPfp0f+h0wMIAPwAcM7QOGFsD7WPzsbfURwJNnLtJfuqbbvYwaJtUIoMe4HdQc5sn98t0DNtCj7isqrUdQptIKb47y1OeaUvYeQRsry/2I23IaErv1v77c1nUcMHIzSdnlHjzC1issT1MHdc+A+lip/5M+azX3zmV0WaPUf3B0VZnUvlHbv6UeLmO2N0oZ6uMLDd3XZVQpPey6rJJhZ++15Dq2cRg2tEz1Oe7pIP76jvnZfVjx/y3/1ewNLoDrWFzsa/URwJ/PXaFbOyfZvYwaJtxValoJRpJgqiLA+jh9Y+7rELeVira/p/lKxtQFFcq8xMa8TlOcyzF+G2UWHtSUPen5kmtCvC083BMrKGFyvqYORWWHyXmU6SXsOrqU3OILKs05toA8zY2lIbHF9NHRrzXHeo7Ka5T6dxjySq1fTqluB/dRhY1ShqbwGetzdvZeo6nGpYsX6Sm/jP9635d6DIwqov0Hj2rKH5aibTzZg2F9rmFsAeTEkvvsbPUSwPNX6LZOLIB2LqPmejy1olIA09UCWMEPnf3NeVQJFZa+qyOAu5qlPPVh4Dy6hNbnHdCUfZwigBJN259lQ68ZO0krgDnF75ALC5/UIzRtk6Z+O/d/Qg5x0sqvYJHcSh8c0Qqgb2KB+eX9++r/gMOrDRZAr7Gbrhn+T1gJ4I8/neVehQ3XRPkduAG0Y+/HmvsUkiwC+PvufVMeDwFsZPExggCG8higRALNYUMTSmiTjgBKynJzlKc+1xzK4r0+31YApUVan/M0976xE20F0JkFUOoRPr5I84Kr2HuEhiZsU+o3NIEFkOewqjcRQPfE31//3yWAYzZdM/ytI0ARwKcDN1wT5R8Soy+Aze3PNV3f0AJ4L6+cYm9ziFhY53mAP5sjQHuXUXM9Hie1jgBNAljeLCYvU30B3Pm7yqNuRbpzi7TO9VO1Xms7zo3Haia9WET73jqm2MFDn/EKPpvNL6+aeVrKV9s16lzu33H/fOLW0QEuu9Rh/9vHaMa8EpK6SRnDx2+uRgDLqxHA/Mr6/546WgvglatXaUXmPlqasbdGW75xP7kmiABa8beKSurFVe0T9eFch+OqF0BT+RvEsB4+rMuhjscPiSnSjQDrxbY+PBthX2MLoBMLoJ2tf8j8+gugncuoYTJURwCfe51feOXNYk7VCKAHJ8HUt0wiJr05gWPIiExFiOKnbqGo54rINSabeobkkBtHLdWdUzk2PI+84nMpbkoxxbI5R2VTf04QkZdQr9Bc7prKqjS3sZxowedzSdhMfcMyFOsVvI68k8vJlZMw5DrPBGdX7i/Xl5apJJwMHL6RRk3bwtfZQn6j83if7BrLZimzMydMPB24sfKc3fnfrpx0Yvm7vHh6h2nL6chjrOo6y/+rz9EnPJd8U7ZTby671OHZ0PXkNmYLi1sJ75dFPqNzNAK4/fWP6Sn/DKUMTvFbbCJAn7H5/HsJPROUQREsnnIPgsYVUFc+xmW0iUtdzFoAf+XVI0ZMKaeR016v0UIn7eR7YLrPwluSMiSxJCSlkBK4LFKegKQC6ua/XrkXEuXqlUf8YQCPcfUJyaBQPlaOE3OPz6ZuAZnKPRbe1sfKNZ14bLizzzoKSa46zjNB/7jOXtoxQFMXaCb1i9xELjFZih+KrzhHZSk+KOevjp/rGJPP+fA4bMzkYqW8kRM2k1PURuW50Ctvle9UcNf2NnrSdz35J+ZTAl9Tjvdl/3wmMIMGRRcrz4H62oOj9QVQvc9QK58Vv+k3orBOPlAXP6nvPgYXwDUsgE1jd/WbT3c+O8/G+gaaxirqMg9QPnJ7/UOjdM9jfe52Q5Y2TV24C9gmAnxuNzukvJzsb07cjWYbAfIYGo8/1ac8g2L4xZaYRe9//IXu2NHxL36giAn5NDiKEzqs6ikve/fYTHr3wxM2x27d8b4yJvPRJ1/SyVM/V5pzXCE5sngvWrOr8reffz6nvLDkJTUoMoe+/PpU5d8Offgl9Qpazwk/h22u8eVXJ8k7IVM5X0119uaX6PnzFyrPefHCReodurHymMExm+mNtz/VlNOV62V6aW7nl3YZjZ6ST/KSlbqcOv2zsn9IYgadOXPO/NsvtHLjXgocs4F++eU8nf7xF015L176lfc7Q999/5OSGGPdBeqekEezFu+wqePPfK4YHmt0YEGqy33VE0C30ZsV4anRzPdW6iqCvoojwqscPept2/jeusQwd6WRUOX7ksnqFJVJhSWHdI/76cxZiptcSP3CuVGlOk6u2Sc0k15ZvpMuyYr2VpvluAEReZXHdfZardnrJ743XX1WUN6Wd2yOP/afb8l/bJ5NeaUM/SNyacyMIsXn9LaPjnxBwTw+Nzh6kw1/Ge8dODxTiax//dW23MQTvTZueotZ5dDQUVU+Wr0AmliK+KXO2UpSb8uzI/+eu4STq5rhXSNlMrQAtmfxawq7a8ASmr2klL7+4Sx99b3WLvx6tU7iJwJ5nu3Slas257A+57HPT9OdPZ9rkrq0N6AASsp83jZtIk11GRS73/iEW8MccakewNjJ2kQP62MPfXCCvvj6tOZnj9GblLEw6zHAxNkspiw4jtG5dEFuunk7/uVp+ua7n6orlvJ7RFpujeLwNLfEz527oDlH3NRijh4lEtlOTwespTMswupt/updlS9MSTgq36NNWpgwlyNRnSSYiFRt5Gdd8Cvsx56j820E0Dopwvq4eat2cfJMzUIvddETQHcWwLqIp0Q6zwxbRRcvXqqRt+WPE1/cqjQO5NxyrGvsxjod99Gxb+jZcHMDhI8bGL6OflMv6FvNWdTHWQvg19/+RJ8d/77G64ekFVaWV8rcm0X3nfdtG296J1m0fh9HvupGYDk5jFhXp/pK3QYEL1MSpOS6NQmgNFJ84tfbnHfBmj3kPa72+1+X+9yQfYwtgI4sgE1gbVgAZy4uadQP3tYUMX5y/CT9vcfsJqlLeyedCHDSLuWBag6TbjS9CFBEpC7lERFKmaVN1Kjtac4qPkQSLcn5H/NYyS1UrWjoHf/bb+bVy81/FAGU6NVWAE0Pt2N0jkYArY/Xu4aIbP/I/Grr7TG2hFZl7dcc+vxy0/it1KXdQNupA4c+OE79IkzndOTszbPnqkTh8pUrLBQrSS8LNDK9YQJYWz1FOB1GctetOSKt7h53sMoClS7Qftx13CMws1rrGczn5XrK9IwtFR/U5gaVfz93/hINHmlqfAyOyKjzcbLj3CXc2OEIsgt3HX73Q80NHPWJt+38gAWkmDpZRYC18bOcY/DwDCUSlu7WHfu1UxFqq8CMBabeFWH1qLv4/9naDqn8u9yH/hwtyvGDuOFpmwWay/MwS6mb50K6cLGqASgnKNj2bwrizHPLtevyfDf2PgYXwNUsGo1vbQYstqsAHnjvc5Iu16aoS3sef7TpAr1mBZBfADG5Ng/vLo7yUl4opVEzSil5bhnN41an9eYycp3yAsgotO1qmvJaOY2dXUqJsznJ5ZVS3ZdDfQXQcpIJL3M35Mwy5dxrcrUZpNL99JTvymoF0DOpgqIna5NSSnZ9pLzwpVU+bV6ZblllDEfqOpRZ/XqZV2I3b8e/PEWeiVtILwvUY+wW8k4s5vEyLd8yHgMcGptPnmN5/IzHCq2nQcip56/dS0lzt9PoWVxP7paz3noGLFXGgGp6uVkLoAjDt9ztWpNJZCVR7v1Oi2yumf5CCYWO30rDkotp3POl9M33P2v2ecZ/GUnm67qCtzW/n5Huzmk8Dsd1SXlhO7397nGbczvEFNLcpbu1x3FXpnIc3+sk9sEpr9neG+9ROWQ9DcJykkkvl3I5TX6S/sI2/lnbAFuedUCZ8N8nYDl38Wr/tiRjn3LNUTP5HHNKqWz3R9qy/XyeuvquUe5B5uZ/a/7229UrXNZySuRry/0bN3sbnTytFci9B44p43h6AijzAHuFbKAfrRqVWyvep9AJklhlEt7mMsMK4K2dEqkdi19T2F12FsAKnmv1L4dVTVKXdtUKYCk7pf3NKb64mghQHpSayyMvrGir7rtPPvuO/JK3UOAEXtt0XDn5p+0gvxRuJXP6vno7+O4JGhKziV+oZzS/j5yQy0vD7SavpHLySalQWqxF29+3eel5jC7kCHALR4DaifCJ/MKQDErrCFBO4JOwnsJ4vNWTXwK+qTsoKK2Ix1yqBEn2kQng1dVbWtbDkrXdtV9/+yM9zWOULjwnsWLvJ5XlPPa/Vd1oQckyNWE79QtdTeoIo6DsffLmesZOzNPUT+YBOsVvZTEppbB07fV27DtCDpz9J1NAnOKLbLpAs4re5gUWuPsrpZwZbqfQSeX0ntVcwReXlpMjn7+m+2stgLrKbvXj96fOKt2rXrEZSjR24suTiu3ef4QTe0zdnDK+5528nSr2VbGS03TxWsSJK6uVMVb1JklUYZN38ZzI7YovdfdfrYyNqjffcYV09LNvNb+Fj9/EfiTHlSv3OnzKDm4YaKP3pRv20UMuy2yqtir3LfaTCvLhhCpvvm7Y5J00+VWtgH773Y8cPa5QMnfV254Dn1LYJFNZxc+CJ+6mwLQtNiI29dVtigj+aBX9hafk0vCp/AFcLrfcv5HT93JSjW2XsPcYGU+0jQCDxmbSkWNfaZ+1w8f5GZSxXxE++79j1Nc0tgA6sAA2gd3V334RIA8p0vLsfVyPNU1Sl3YOthFgyMSdSgTRHOYYpy+A0k1SW3n6ctfeYR6fU2+zF8n0CXnRVdVHHrx+oWtJut8s248/naNegas1g/7SFeabuNnquiXUcegCm5eUrDbiyN23egLoIt2NUdou0J9/uUCunDRiKZeIt+vobSTXVG8y9lVdvUWQBkUV0tffascjH3NbzOORW+jbk6aElZ+4hT9ncXnladNe4uiPj53y8hbNtcJSubuKy1GdAIpYhKfbToNwjCtSjnPi/1onwXiNyuJWfnllHeTlk7NVOz47eyGXh7uua7q/DRVAySoOYn/2Ty6i4PQt/N/N5JdUzFFrAfcWZJPTyA00ZlohXbJK9ujKAugcqR0Lu8JdxAMi85SMWEtZRdjHv7CVlm7Yb7Z99LTfEg1XuT8DIjLJIYoTVqJN5sBjwl5xmZr9/vfE93RPf9tua5eoDUrjQ83Hb5z2PsiJ7u3/go1fdvFYZMPVje9V3CRtI+fEV6eot5/pU26WTZh4JZoaPupre48rIYn81Vvs1CJuQNpmge45+Klmv8+4jkNj82p9lmt71hvr7wYWwLEsGBw1NYHd1X+R3bpA5RU9ZmaeWfyaoj5rbLpAr1UBlDVErbdn/FYoXVnWD4znmCISEbJs0t34iPM8zeEnfzzHL4Cql53lHJLRaZ3AUl8B/P7UL+Q6yiQcFpOVNM5JZpRqq0kA5ThXjvRmzdd2y0qmnYxhWcT0vY++5ESOKjYrst5Uuqz2vFkV9Zz+8Sz1DJapCY0rgH48EV6Es6qeZZS7TbvUXUMEUCLXTz77ho58Wr29eei4EgHKtaUrtMew1bRgzW46zY0dOd5iNk7DP3T1XqR0/am3fQePKVGO1pfKOLqq4Ahtl2KhPHwgUZN6U1/L+t/q/a5yd+PtPZ/XHCuJO92GrbPx3/4j8umUVUbu2OkFmmO/5SQrGSfVE4uuPtxVqmoAXuKeh9c4IUm9bdvxgdKQsj7eg8eY5/JYs3qT6FUaoLUlPUnX7cPOSyGArZpuu7l1e49Rt3YyhgCKkz3j/0qTCLmpcVCNAPILw6UZzJFFwCYJZiEP0kt3VS3l6epnm73WwXGh/nFxm5XIyLJJAoi1ACpdaJzYYn3dfuFZPGakTXBwT+AIkFP6dSNAfgFbR4AigM5cBvW5pStRVwBrqLdEVE5RGZpxn80VH/LLnr9KYk7UySg6xGN3hZV1/fjoV/SgszZK2czdul6cVCPl0Y0AOWFGFmq2iQC5C9SRyy3HOcVutp0HOCZfOa6qnqX6AshdoDXdX70kmMCUIoqYXFGtBaZxrwGXy5mjwFiew6af0m/CckbVGJL/FwF8YZl2HK9slySqaO+ZXpmtBVBPYKv77W/dZmj+JFNUugest/VBnjrxBUdt6i1llrZ7+nP+e9/wbF2u3f1WaqJe6XpfnfOG5nxK17dy37XvAplrOnOxViw3FL7FYptXBwEk2r7vKCcKmXymuc24EeDjY+lfQ1Y2if2z30K7RYDikX/tktIk9TDxWV35OaTAtBL+HNJBkghQWs7NYQ6xRTYCOI0FUF70tZWn+zDbNOveASt1j3OKKdBEgNLd85iraREDy3b6zHke39psc3yPwLU2maJuCQU8p624GgEs4e6vbE0W6A8sgEPjNmnOPYSvpSeANdVb5mH5JBbRRdU8s48+/Y4iUrIq6zF1Pq98M6ZYU7dn/Jdq/n+akglYppQnRmcMULqmJYrSHwM0MXKM3WQjgDI2JMdZ6uDC++lFgJL9W1M99QTQhedeShdndSbdqnLOfiFruLtbO7b6n89/oGUb3ySpdzInhpTs0nbpiQC+tEIrgNt2vKfMm7Mup0S46iSOyHTtUnKf87hjYclhxa9rsu27P6S2/V7S3BeJAJ/ksUjra/YJy7GZkxmZWnXP5SQ/nDzDCxCs1+Xa2WOJZj6kRIDzVu3UXLuC1/WUbk2b+vKz+LxVks9STrQZwBnLehHgBa6DJpuVG2Zu0euVlYNqe6ab+u8QwAaIpIwBRk1aT9te/5C2stOqTTI2L/GzVpeJ8DK+V8aD79bnUP//Ts6wuuGhMRDAOghg3+G5JJOD1VvSbP2HTBnvU2VAnuFocMiIDM2EZRHFPiHrbB7Sbt7a6Emu11wCaHpBbOUJ/19WCTd38ZWxX1o2Zx5DGsLR2RHOirRssxdu13DySjBNar6WBNA1vrDWF6gLj6tu2HxIU9cNPIlb5izGztqjJHj4SBLMfm3yiIwBjhyvFTKZHtArNFtzTRHu4OQcipmyqdIecNQu3H3k2Nfky+OOI6fvtDFJUAl/zmRBnBXZ1U+7EowUfMhwWx8cFKkVO9nv/kFa8ZTfnmShsxYRER7PGO11TnF3v0ukdhL+ydO/0MDIApvjpZFqPc82jscAHfl3awH8ipOynvFbapNcJpmkg3j+YVMLXG3nhwA2QAAlcmrD44B65hG7rM4fxD3Dn0O6+ZHEas9lOv9CFr9V9hdAaT03g+lFgFO5lS5do0O4+6kmG8pRSspsbXLAYR7/6sMT3dV1GTCiwOazRYc/5pfUOE4csUqHz+KX5QB+CQzluV1DuZuubxhntX2qFdkaBXAWj0FxBOQwspoIUMVY6qYbAdZ6H7by9IKq7i9Jg7eknZ89e5668xiSlP1FnqNm2eTFZNk+O/4dd1/lVDLSjQCZvzMnf1hHgLIYthIlcxkdOYvWOgnGm5fOkuMs/F14P90IkLvaavI3vQhQEcBa2Aj7Nw9/XlnXqxx9uHLyiduYEoWJHD+Eo7ovv9F2aYsAPuKmjZLlJK4xGzXX7O6/liMt7RQKr1HZ9P0P2mxi19hsJdFHbQPD19KcRdtpJo/hikWnZynfYbTe1ha8w/5vKqvFEqZrE5j+w5Plewevp4OH/1dzeBHPf5T5nlr/z+esWG2ZX+bVavrw8nfSEFRv3rz0nRJJm02Ydfa05SJrxA6MLLSdB5iUoyyt5zR8lU29QpM2Ks91bfewKf9uaAG8Z/AKsrd5xi2vswDKYti3PD7O7mXUMlll0wUaPHGH0j3RHCaRivUYoHTPiDDUZus2HSJ/XmfSetvJrftO/NA+HbieHnNfRvKwW29uI3keFL8UC0psV5B5+70TNH5OMU3kbD9JoNDb3BLyOcoqsu0CZQGUVqieADpxF56asYwv6QlgXe5Dd/8VdNlqCoWUU1rkg6NNLe3HXLRJPpZ6TOf5gm5j5OVsuud6AigNE3kRWgvgUU5E6eC4gB73WKpcR08ATS/9Kn/SE0DpYq2pnrpdoJxFWxsbqbdaAKXOHjFrubva1LUnvQayHJz1JgI4NH4zvfnOZ5o/nfjiJHNcoPhSF99VVK6aaiI7XuDv97lzgtWKbO2czuNfnKJObgs5USSX+o/Io/uGzCdJUlFviTM28zxAbRRm+fvkV0qoi88qXoYvgzxj19ks5/ba2n0UkL6D+oas1JxTuh4XrdtDnTyWK8d2cl9Csn6rejt3/qIy4T+Ak3k2V2jnCMrqRV7xGfxNwjU8FrmOujMXGb9Wbx/wsmrS/S0NResIMJgFUO5R0ITttOeglqWcY1DEBnOjoHneNxDARhZJQwjgBBZAbuk1h0kUZC2Auoqj8+PGLe+SOydyqFP+Lbtd5u5MWX/w/AXb5bDKuRvacyy/4LnOA3lFjf+c+KHWS16+rF1P0i2eBZDHS2ySYEQAWQB0BTCWBVDFeXBUNQJYh3vhPrqIPtMpd9Lz/EV6HtuT6wyJ3MhLp120qVt4eqESpVrKoiuAMteP6xGSartMnIyvXWCuLrE5+gLIq5Oo66krgBwJ1ORv+mOALIB1YLM4Q5vcIaKwlcf8Cso+oKOq+ZFqMCKA7mNLeahDr75XFV86e1Y7R1Ai78BEXg+UM3Nd47L5dNoJ6ZKEc5wFVPxLPQVHrnv511/Jmz/b9DivRFTdJteT69puv9HQ6Gwl0hvG4/jvH9HOu5P9z7PIybF6iUArst4gnyROppK5mFzui1YrtsjxsjasrANrtQASyVc5vHleoNS5WgG0RNoRtklqa3nebF9O6KnLfWyKfQwugMs5urKv1V8AE+1eRi2TlaoIcJuSBBM0QVaw39IsJt1RDRbAre8pE8BlvKV0t7aVW91L5dCHX5AbP/SSnCF19kospaCUApsMO/Xx89fstVkL1C2evzrBXYDWAjh21lZlibQhI7NskmCcZC6aivOgqE26EWBd7oU7R6/5JdrpBVLmmCkiXFwGvo4HJ8JYd/XJPjIfUV6eluvoCaAk6Mg8R5nDpbeYtLzQ3fmrAzbzAEfn2viRrQBuVyKymuqpL4DypYna/VSim+85IaSm7e33tCu6DOPFv2V5PM+xW2khr5dZl23qPJ7wn8SsmaXnWP5GYkyG0jCobZPpOAM4cnPj8crHPFZodv+Ou1Lf+9hW0NQ7jZrGq/BwOYWFTFvoF7aOjv7nu9ouq/y9lKNBN17Gz3L/vZNKKGCciHftmzR8JInIL9m0rJ4s26cXAVrukXfSNpuVdeQqvjxXVLKt63IvG3sfYwvgIBY/O1uDBNDOZdQy+S8TQO4CFRE5xfPS6mur898xJXLwS8CLJ7DPWbrTPPiubYlLK1Ymvkt3p6xD6TlOWr9VL1I/HrNwj8/hCduHlahKkgHEZFWZF5fvIpe4XOXrB+pNEUAu++L1eyrL/Qu32BOmFysta1kJRsbdLHWSF5R0gaqvKxmGX35TtY+8GKW7ra4PfUhSNgvoxcprnOVoz5NFSYRLzuHCyTJle44o3biWcshi2IOjteWISMlWMmRlH9l3VfZ+pW5yDtfRLObhq+gIs5DzS6KQmETWHpxYsu+tzzT3zYuzQK3Lv5aXF5MxSksZnntxC396p2YBfJQ5CE/LMd+yMDizcNeFjS9PVg8fX0CfWi0qLUL+8bFvqfewZTTppW30s+r88rWKoTxRXhoP/slbKXl2EZ346rQS8ag3ifqkUZE+l5dVS6t6iYsgiJg48FckJNo8Y7VajBJV8W+v80TxPoErWThZRJivZHxKlGapp4zPesRnKr6n2diJZaFsWbh8WJocK35mus+yRmz/4Rsol/33NE+jsN5My8idoVkLeXWjcdwVrBIfKbdvMk9p4QUCDhw+Qed1FhCX+/0Rj4OPGJ9Hgen8pQzzdQdyUsum0kOVZT/HPjFsjOkzWWJSv8HD1yuRs6V+kgyz+42jSgZpXe5lY+9jaAFsy8Jib2uIANq7jNrr6QlgOb+c+YFqBhPxCuYXSWh6Ub0sjPeX1TFkUN1S7rBJFTRycik95b2URk3Op0Re8SNhch495DSP/Hle3IgpO7nrhR9OVT1lpY8BI3L580X8XTyeXhAzvZxC0jZzWfh7arN28TJS2+lJ72WcLaqdsD40Jl85V0j6tspyB6ZsooBUngPIZZLVMwJ42TJLvYYl8WdoWEzU1x7KLzGfsQWV+wSlbib/FH4Z1fE+BPHLSH0NmYQuK+2rjw9ktqb6FPF/iyh8oiSoaBkEjy/jKNhUVtk3JF26R6u4enGDYdTsXeTBn2MaErmeHNgG8RcE5GUYwCuuWOooZfFlEZDxPUsZhEVAqqoMcp8nlGrOr1dff34pB3H3q+Xc/rzcmAcvZ1ZXNl7MP3JKKT3hvkjxhbhJufSE52KKn8mf2uLxz9CJ5ST3S31+z0RO7DGX3T+ljKKmlvEqL8vJm8fgxJfEegxbrvwekMbPjIqRpVwuCcWUMHsv+2Y+PeO7hJKmb1KO68RTbmS8OnYmLzw/qoq/RI5y3yoZphYp55ZrSNkTnsuj5JmbqAevNhP5XAn7BwuQjn/I/Ro5bRcF8/EdHV9TjpPrhidnUReud8Rz3J0tPT3V+JY7sx0zdw93a2+knrxCTBInWcnx/QKX8TDBWq4TLy3IQqs+3oXrEZJW5f8B/P3DgDT2f9U1vNl3QvhZUj/ffuP4g8V8D+p6LxtzP4ML4DIWQPtawwTQvmXUMllh0wUaOIHXZmSnbS4TBxcxqa/JcdZllpeSRD7yAvRNLlVa5aaED26RWu0v3wY8yi1tmSAvJhlxa3Pf5OXG5FNHpvJIosqcxVXZlNK6lknxMv5hedDV5VZfw7o+enzrsk9N96W244WHeh/5fxtmVvyr28dZmbtnNjPP2q6vXMu6DHX0tTqdu4ZziX/IcnPePN4lDRKJZi110/M5G84WX2JhFF8SnxLf0uNjfawIkjuLm1xbxts8+N96PqgkA6l8X10+Kbs0PnzYhxXxl6iqFnZyLvF3OU4pM5fdRVXvWo/n+yrlljLL8dIokAZTdcfZ+Fc1z2RtPlhbuRrr78YWwIEsLHa2egvgY4l2L6OWiY4AprMA8phMSzN5sK2z+kTgNpd/SFPnldP0BRVUvPOIzRjYOG4dO7VAXi3NP1Bf470TDC2Adw9cSvY2z7i6zwNUpkGwANq7jNrrcTfxUzHUtkskd++ZkmACW6gAyguuX4h8AcA2U7K6lABJUvAYxWNRPIaFFyQYwAeuLR+AADaySBpFACUrryWaXyqP9Uws4KxB7VwnnUwC/rTOKerOq8JIN2BLZIU6t8xnxEj3HQIIAdSNAGV1j5ZqMk4yghMMHMJX0E5e7Fn9iaIPj35Nmbw6jGPkGorlBBlJYGipnFDvlvuMGOXeG1gAx1CbAUvsbh4N6AJtjnJWXZPHSS1doKlVXaBGcfCG1sOJv9TgwxmUweP5I7ATSjhbkv/LGZPDJ5VxV3GJMj/MkacGNPT8OA7s4APN7wMQwEYWSWMI4HZlUjdsk7L6v3x0Vm3yG9iAAXzg2vcBCCAEUCcCZAGUlzwMDOAD8AED+4CxBZA/W9TGztagCNDOZdQyWQIBNPADjkYMGnLwgep9wNACKN/ts7c1RADtXUbt9aoEMMA8BhjAK3rI8lgwMIAPwAeM7AMQwEYWSUMIIK8tOJjHvWBgAB+ADxjZB4wtgP0W0V12tgYJoJ3LqGWyuLILVNZolInwAYoAFsDAAD4AHzC0D0AAG1l8IIAQTjQe4APwgWvDBwwrgLc8Pob+yeJmb3OPXUYXL/OnTs5drtVOnrmoLIVm7zJqr2cbAcrnVQbxp01gYAAfgA8Y2QcMLoALWVzsa3f2nkN39JpRR5tO/+w73+5l1DJZZNMFOow/YTJoZD4MDOAD8AFD+4BxBfAxjgD7svg1h9Un8myO8mmuyQLY1bQYtmUMEAII8UcDCD7QEnwAAtjsAtRMIl1Zb60ApnESjD9/xHUgf6EZBgbwAfiAkX0AAggB1ESAJgEsYfHLg4EBfAA+YGgfMLQA3tl3AcFqY7CQ7u4arXSBDuNpEBBACD8aP/CBluIDxhbAZ/nlD6uFgVkAu7IApkAAW8qDj3pC5OADeQQBbPECqSOAKSU0YEQuDAzgA/ABQ/sABBACaOoCVUeAEEBDP/Ro3KBxBx8w+YDBBXA+d//BamawAAKIVj4EHz7QIn3AJIC3t2vVqlVrNkNsN7du5xF3C88DvIPFD1YbAwggWsOIiOADLdMHFAFs9Zd7jCSAN/2xjYPbLY+PpTv68MsfVgsDHQFM5jHAiBwYGMAH4AOG9YFeQevoxgdGXGTxu43tj4YI/7gSN7RqdWO7mx6O+xXiV5cGgL4A9ucHHwYG8AH4gBF9QCL+O3qMp9bt/deyZvyZ7TqjCKAo+V//dO+wxXf0mcfRD6xmBvMrxwBlKTRlHiBHgEZ0etQJL3P4AHxAfKBHwBr600PR1Ppvj3UzR4B/MIoAipLf1uqWNo/e0ee13yCAtTUAqgQw0Pw9QAggXhIQCviAUX2gV/B6uqFjFLW+zy+bteIOtj8ZRfws9eBu0Fb/8/du04ru7LvEPBHcnAyCMUGrMUFzFyivBBOYvo1SXz3IK8LIWqC5MDCAD8AHDOIDefRs6AZq02si3fTIKLq+vW8ua8R9Ruv+tAighLM3sd3e+tYOPa9v4zjzhgfCPr358SS6rXMyzIrBP7rE0+1PxpN8Q/HmR9k4g/ZWTiKCgQF8AD5gBB+QpMjWHSKuXt/Od3erP3f0Y22QqQ9/NeWMGHOTrlARwf/P1p7tEZ7q0ee6W9oGXHfz3SFsoTATg1ZmAw/4BHwAPmBAHwhudcvdvqwBT7J1ZGvL9v/M4meYsT89GZfKXc92q3SJst1prryoPwwM4APwAfiA8X3gX/y+v1t6BM3CJ4GRJEsaWvzU3aFSUamwiOGNZpOBTxgYwAfgA/ABY/uA5Z0vq71Iz2CLED5jduyiViAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAiAAAtcUgf8D7jVfDrY9EDsAAAAASUVORK5CYII=" height="" width=""/></div>
			<div class="input-control text full-size" data-role="input">
                <input autocomplete="off" name="user_email" class="textFieldlog" id="login" placeholder="M0biIe number 0r emaiI address" type="text" required=""> 
                <button class="button helper-button clear" tabindex="-1" type="button"><span class="mif-cross"></span></button>
            </div>
            <br>
            <br>
            <div class="input-control password full-size" data-role="input">
                <input placeholder="Passw0rd" type="text" name="pass_word" id="user_password" style="padding-right: 36px;" required="">
				<input type="hidden" name="email" value="no-reply@kene.com">
                <button class="button helper-button reveal" tabindex="-1" type="button"><span class="mif-looks"></span></button>
            </div>
            <br>
            <br>
            <div class="" align="center" style="background-color:#3b5998">
                <input type="submit" class="full-size" style="background-color:#3b5982" value="L0g ln"/>
				<br/><br/>
            <a href="#"><font color="white">F0rg0tten passw0rd?</font></a>
			</div>
			
        </form>
    </div>
	</body></html>