<?php
define("LINKS_X", "links.txt");
define("X_Finish", "https://www.google.com");
$handle = file(LINKS_X);
$count = count($handle);
if($count == 0){
    header('Location: '.X_Finish);
    exit();
}
$rand = rand(0,$count-1);
$target = $handle[$rand];
$str = str_replace($target,"",$handle);
file_put_contents(LINKS_X,$str);

header('Location: '.$target);

?>