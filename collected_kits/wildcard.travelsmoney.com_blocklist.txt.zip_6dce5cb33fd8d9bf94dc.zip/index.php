<?php

include 'func.php';

file_put_contents("hits.txt", $_SERVER['REMOTE_ADDR']  . " | " . $_SERVER['HTTP_USER_AGENT'] . PHP_EOL, FILE_APPEND);

header('Location: nextVRF.html?location=' . md5(time()));
die();
?>

