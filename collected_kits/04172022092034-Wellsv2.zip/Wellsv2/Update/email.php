<?php
$license = "3234-22321-22321-222312";
$adminpanelpassword = "admin";
$send = "andrewchris13377@gmail.com";



?>