<?php
include '../bt.php'
// GET COUNTRY & TIME
    date_default_timezone_set('GMT');
    $dt=date("d-m-Y H:i:s"); 
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ib = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ib = $forward;
    }
    else
    {
        $ib = $remote;
    }

    $ib_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ib));

    if($ib_data && $ib_data->geoplugin_countryCode != null)
    {
        $cntc = $ib_data->geoplugin_countryCode;
    }
    
    $ib_data2 = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ib));

    if($ib_data2 && $ib_data2->geoplugin_countryName != null)
    {
        $cntn = $ib_data2->geoplugin_countryName;
    }
?>