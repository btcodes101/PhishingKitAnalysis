<?

$to = "vintagepearlapparel@hotmail.com,islandbestclotting@yahoo.com,akatwatsom@gmail.com";

?>