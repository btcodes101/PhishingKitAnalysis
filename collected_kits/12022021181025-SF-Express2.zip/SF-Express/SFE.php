






<!doctype html>
<html class="no-js">
<head>
  
  
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta charset="utf-8">
  <meta name="renderer" content="webkit">
   
    

    
    
 <!--[if lt IE 9]>

<div id ="old-ie-hint"> <p class='lt-ie8'>很抱歉，您使用的浏览器暂不支持，将为您的使用带来不便。请更换或升级为IE8以上、Chrome、Firefox、Safari进行浏览。<a href="#" onclick="javascript:$('p.lt-ie8').css('display','none'); ">取消</a></p> </div>

<![endif]-->
  <title>登录 - 电子发票和包裹跟踪</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="viewport" content="width=device-width">
  <link rel="shortcut icon" href="http://www.sf-express.com/../../../../.gallery/favicon.ico">
  
  
<link href="http://www.sf-express.com/../../../../resource/styles/main.css?v=2019-07-25_8" rel='stylesheet'/>
<script type="text/javascript" src='http://www.sf-express.com../../../../resource/scripts/old/jquery-1.11.3.js?v=2019-07-25_8'></script>
<!--手机适配-->

</head>
<body class="language-sc">

<!--[if lt IE 9]>
<script src="http://www.sf-express.com/../../../../resource/scripts/vendor/json2.js"></script>
<script src="http://www.sf-express.com/../../../../resource/scripts/vendor/html5.js"></script>
<script
    src="http://www.sf-express.com/../../../../resource/scripts/vendor/respond.min.js"></script>
<![endif]-->





<div id="header" >







	


	<div class="topheader">
 
 
			<a class="logo" href="http://www.sf-express.com/../../index.html"><img src="http://www.sf-express.com/../../../../resource/images/index/sf.png" alt="顺丰速运"></a>
	
			<ul class="topleft">
			<li class="topli"><a href="http://www.sf-express.com/../../index.html" class="topa">首页</a></li>
			
			
				
					
						
							
									
									
									
										
										<li class="topli">
										 <a href="javascript:void(0)" class="topa nolink">物流</a>
										 
											
										
										
									
								
										
										
										
                                        


 







			<div class="dropdown">
                <div class="dropdownInner">
                    <div class="innerWrapper">
						
							 
								 
								 <table class="part1" >
										 <tr>
											<td class="title1" colspan="6"><span class="ico fast"></span>
															快递服务
											</td>
										</tr>
										<tr>
														  
											
												
												
														<td>
															<p class="title2">同城</p>
															 <ul class="part2">
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/city_distribution/SF_Rush/" >顺丰同城急送</a></li>
																	
																		
															
															</ul>
													   </td>
													 
												
												
														<td>
															<p class="title2">内地及港澳台</p>
															 <ul class="part2">
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/one_day_arrve/" >顺丰即日</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/next_morning_arrve/" >顺丰次晨</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/next_day_arrve2/" >顺丰标快</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/next_day_arrve/" >顺丰特惠</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/transportation/" >物流普运</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/cargo_express/" >重货快运</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/special_cargo_express/" >重货专运</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/Heavy_Freight_Package/" >重货包裹</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/Small_size_LTL/" >小票零担</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/mainland_area/EC_Ship/" >E顺递</a></li>
																	
																		
															
															</ul>
													   </td>
													 
												
												
														<td>
															<p class="title2">国际</p>
															 <ul class="part2">
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/international/standard_fast/" >国际标快</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/international/international_ex/" >国际特惠</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/international/international_packet/" >国际小包</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/international/International_cargo/" >国际重货</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/international/electricity_express/" >国际电商专递</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/international/sfbuy/" >海购丰运</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/international/sign_service/" >签收确认服务</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/international/overseas_warehouse/" >海外仓</a></li>
																	
																		
															
																
																	
																		 <li><a href="http://intl.sf-express.com/" target="_blank" >前往国际网站</a></li>
																	
																	
																		
															
															</ul>
													   </td>
													 
												
												
														<td>
															<p class="title2">增值服务</p>
															 <ul class="part2">
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/insured/" >普通保价</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/Highly_Secured_Express_Service/" >特安服务</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/collection_payment/" >代收货款</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/gross_return/" >签单返还</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/packaging_services/" >包装服务</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/commissioned_piece/" >委托收件</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/reverse_logistics/" >逆向物流</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/special_warehousing/" >特殊入仓</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/delivery_upstairs/" >送货上楼</a></li>
																	
																		
															
															</ul>
													   </td>
													 
												
												
														<td>
															<p class="title2">&nbsp;</p>
															 <ul class="part2">
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/formal_customs_declaration/" >正式报关</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/electronic_acceptance/" >电子验收</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/original_return/" >原单退回</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/timing_delivery/" >定时派送</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/collection_payment/" >垫付货款</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/policy_distribution/" >保单配送</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/To-door-Large-size-Shipment-Delivery/" >大件入戶</a></li>
																	
																		
															
															</ul>
													   </td>
													 
												
												
														<td>
															<p class="title2">&nbsp;</p>
															 <ul class="part2">
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/extra_long_overweight_surcharge/" >超长超重附加费</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/holiday_service/" >节假日服务</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/non_industrial_service_fee/" >住宅附加费</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/fuel_surcharge/" >燃油附加费</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/Delivery-Address-Correction-Service/" >派件地址变更</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/change_payment_method/" >更改付款方式</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/SF_Certified_International_Shipping/" >顺丰国际直邮认证服务</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/Shipment_Storage_Surcharge/" >货物保管附加费</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/express_service/added_service/remotesurcharge/" >偏远附加费</a></li>
																	
																		
															
															</ul>
													   </td>
													 
												
									 </tr>
					        	</table>
								
														
							 
								 
								 <table class="part1">
					
									 <tr>
										<td class="title1" colspan="2"><span class="ico cold"></span>
											
												冷运服务
											
										</td>
									</tr>
										<tr>
														  
											
												
												
														<td>
															<p class="title2">食品服务</p>
															 <ul class="part2">
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/food_service/fresh_match/" >生鲜速配</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/food_service/coldchainexpress/" >冷运速配</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/food_service/crab_courier/" >大闸蟹专递</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/food_service/cold_shipped_home/" >冷运特惠</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/food_service/cold_shipped_store/" >冷运到店</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/food_service/cold_transport_ltl/" >顺丰冷运零担</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/food_service/cold_transport_car/" >冷运专车</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/food_service/cold_storage/" >冷运仓储</a></li>
																	
																		
															
															</ul>
													   </td>
													   
												
												
														<td>
															<p class="title2">医药服务</p>
															 <ul class="part2">
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/medical_service/room_temperature/" >医药安心递</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/medical_service/temperature_control/" >医药专递</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/medical_service/shunfeng_pharmaceutical/" >顺丰医药零担</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/medical_service/special_medicine/" >医药专车</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/cold_service/medical_service/medicine_storage/" >医药仓储</a></li>
																	
																		
															
															</ul>
													   </td>
													   
												
												 </tr>
						   </table>
								
								
								
                           
						
							 
								 
								 <table class="part1">
							
									 <tr>
										<td class="title1"><span class="ico house"></span>
										
												仓储服务
											
										</td>
									</tr>
									 <tr>
														  
											
												
												<tr>
														<td>
															<p class="title2">仓储服务</p>
															 <ul class="part2">
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/storage_service/storage_services/warehouse_management/" >标准化仓储管理</a></li>
																	
																		
															
																
																	
																	
																		 <li><a href="http://www.sf-express.com/../../express/storage_service/storage_services/storage_core_competence/" >仓储核心能力</a></li>
																	
																		
															
															</ul>
													   </td>
													   </tr>
												
												 </tr>
						  </table>
								
								
                           
					</div>
						 <div class="grayright">
							<ul class="part2">
							 
								
													  
									
							
									
								
										
										
											
												
													
														
														
															
																
																
																	<li class="red"><a href="http://www.sf-express.com/../order/quick/" >我要寄件</a></li>
																
															
														
													
												
												
											
										
										
											
												
												
													
														
														
															<li><a href="http://www.sf-express.com/../range/" >收寄范围查询</a></li>
														
													
												
											
										
										
											
												
												
													
														
														
															<li><a href="http://www.sf-express.com/../accept/" >收寄标准查询</a></li>
														
													
												
											
										
										
											
												
												
													
														
														
															<li><a href="./" >运费时效查询</a></li>
														
													
												
											
										
										
											
												
												
													
														
														
															<li><a href="http://www.sf-express.com/../sf_care/#other-sendway" >其他寄件方式</a></li>
														
													
												
											
										
										
											
												
													
														
														
															
																
																
																	<li class="red"><a href="http://www.sf-express.com/../../cooperative_consultation/index.html" >合作咨询</a></li>
																
															
														
													
												
												
											
										
										
											
												
													
														
															
																
																
																	<li class="red"><a href="http://www.sf-express.com/../order/monthly_billing/" data-md-name="点击进入" class="maidian" data-md-id="OWF101901" data-md-source="1">月结服务平台</a></li>
																
															
														
														
													
												
												
											
										
										
									
								
								
								
							</ul>
                    </div>

					</div>
				</div>
			
												                 
										
										
									
									
								
							
						
					
						
							
									
									
									
										
										
										
                                           
										    <li class="topli">
											<a href="https://www.sf-financial.com/sfjrpc/?fc=ex&fp=nt&fa=pc&" class="topa" target="_blank">
											金融
											</a>
     										
                                         
                                         
						                 
										
										
									
								
										
										
										
                                        
  

												                 
										
										
									
									
								
							
						
					
						
							
									
									
									
										
										<li class="topli">
										 <a href="javascript:void(0)" class="topa nolink">商业</a>
										 
											
										
										
									
								
										
										
										
                                        






  <div class="dropdown">
                <div class="dropdownInner">
                    <div class="innerWrapper">
                        <table class="part1">
                            <tr>
                                <td class="part2">
                                    <ul class="part3">
	
	
								  
				
				
					
						 
						 
					
						  
						 	
							
								
									
			
										 <li><a  href="http://www.sfbest.com/"   target="_blank"><span class="ico sfyx1"></span>顺丰优选网上商城</a></li>
								
								
							 
							
							
						 	
					    
						
					
						 
						 
					
						  
						 	
							
								
									
			
										 <li><a  href="http://www.sfbest.com/html/activity/1474966515.html"   target="_blank"><span class="ico sfyx2"></span>顺丰优选门店</a></li>
								
								
							 
							
							
						 	
					    
						
					
				
			
			
		
     
                                    </ul>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>



 
												                 
										
										
									
									
								
							
						
					
						
							
									
									
									
										
										
										
                                           
                                         
                                      <li class="topli">
									  <a href="http://www.sf-express.com/../../case_share/" class="topa" >
									  成功案例</a>
									  
                                        
						                 
										
										
									
								
										
										
										
                                        





<div class="dropdown" >
                <div class="dropdownInner">
                    <div class="innerWrapper">
                        <table class="part1">
                            <tr>
                                <td class="part2">
                                    <ul class="part3">
										
										
																	  
													
													
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../case_share/index.html_364584038.html">3C电子行业</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../case_share/index.html_836109172.html">医疗行业</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../case_share/index.html_591155569.html">生鲜行业</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../case_share/index.html_1045342821.html">快消行业</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
															
															
														
													
												
												
										 </ul>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

												                 
										
										
									
									
								
							
						
					
						
							
									
									
									
										
										<li class="topli">
										 <a href="javascript:void(0)" class="topa nolink">服务支持</a>
										 
											
										
										
									
								
										
										
										
                                        






 <div class="dropdown">
                <div class="dropdownInner">
                    <div class="innerWrapper">
                        <table class="part1">
                            <tr>
                                <td>
                                    <ul class="part2">
									
										
																	  
													
													
														
															  
																
																
																	
																		
																	
																	<li>	<a   href="http://www.sf-express.com/../order/quick/">我要寄件</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																	<li>	<a   href="http://www.sf-express.com/../waybill/">运单追踪</a></li>
																   
																 
																 
																
																
															
															
														
													
												
												
                                    </ul>
                                </td>
                            </tr>
                        </table>
                        <table class="part1">
                            <tr>
                                <td>
                                    <ul class="part2">
                                       
										
																	  
													
													
														
															  
																
																
																	
																		
																	
																	<li>	<a   href="./">运费时效查询</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																	<li>	<a   href="http://www.sf-express.com/../range/">收寄范围查询</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																	<li>	<a   href="http://www.sf-express.com/../store/">服务网点查询</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																	<li>	<a   href="http://www.sf-express.com/../accept/">收寄标准查询</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																	<li>	<a   href="http://www.sf-express.com/../sf_care/">更多内容查询</a></li>
																   
																 
																 
																
																
															
															
														
													
												
												
                                    </ul>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
												                 
										
										
									
									
								
							
						
					
						
							
									
									
									
										
										<li class="topli">
										 <a href="javascript:void(0)" class="topa nolink">顺丰控股投资者关系</a>
										 
											
										
										
									
								
										
										
										
                                        




 <div class="dropdown">
                <div class="dropdownInner">
                    <div class="innerWrapper">
                        <table class="part1">
                            <tr>
                                <td>
                                    <ul class="part2">
										
										
																	  
													
													
														
														
															
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/corporate_governance/">公司治理</a></li>
																   
																 
																 
																
																
															
															
														
														
															
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/latest_announcement/">公司公告</a></li>
																   
																 
																 
																
																
															
															
														
														
															
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/periodic_report/financial_statements/">定期报告</a></li>
																   
																 
																 
																
																
															
															
														
														
															
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/stock_information/">投资者联络</a></li>
																   
																 
																 
																
																
															
															
														
														
															
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/investor_relations_calendar/board_meeting/">投资者关系日历</a></li>
																   
																 
																 
																
																
															
															
														
													
												
												
										 </ul>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>



												                 
										
										
									
									
								
							
						
					
						
							
									
									
									
										
										
										
                                           
                                         
                                      <li class="topli">
									  <a href="http://www.sf-express.com/../../about_us/" class="topa" >
									  关于我们</a>
									  
                                        
						                 
										
										
									
								
										
										
										
                                        





<div class="dropdown" >
                <div class="dropdownInner">
                    <div class="innerWrapper">
                        <table class="part1">
                            <tr>
                                <td class="part2">
                                    <ul class="part3">
										
										
																	  
													
													
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../about_us/about_sf/company_introduction/">关于顺丰</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../news/">新闻资讯</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../notice/">服务公告</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../promotions/">推广专区</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../about_us/member_interests/Individual_members/Membership_Levels_and_Growing_Value/">会员权益</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																			<li><a  href="http://hr.sf-express.com/"  target="_blank">人才招聘</a></li>
																	
																	
																 
																 
																
																
															
															
														
															  
																
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../purchase_information/">集团采购</a></li>
																   
																 
																 
																
																
															
															
														
													
												
												
										 </ul>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>


												                 
										
										
									
									
								
							
						
					
				
			
			

		</ul>
		

 
 
 



 
	
		 <ul class="topright">
		
			
				
				
				
					
				
				
				
				
				 	<li class="topli log quickLogin"><span class="icon member"></span><a href="javascript:void(0)"  class="topa maidian" data-md-name="点击登录/注册" data-md-id="105002">快速登录/注册</a></li>
					<li class="topli log quickLogout">
					<span>欢迎您：</span>
					<span class="head-user-number"></span>
					<a href="http://www.sf-express.com/../../user_center/"><span>我的顺丰</span> ></a>
					</li>
				
				
											
			<li class="topli switch">
            <a href="javascript:void(0)" class="icon flag cn" aria-label="版本切换菜单"></a>
            <div class="dropdown">
                <ul class="region">
                    <li>
                        <a data-region="cn" data-language="sc" href="javascript:void(0)">中国内地 Chinese Mainland</a>
						<span class="gap">|</span>
						<a data-region="cn" data-language="sc" href="javascript:void(0)">简</a>
						<a data-region="cn" data-language="en" href="javascript:void(0)">EN</a>
                    </li>
                    <li>
                       <a data-region="hk" data-language="tc" href="javascript:void(0)">中国香港/中国澳門 HongKong China /Macau China</a>
						<span class="gap">|</span>
						<a data-region="hk" data-language="tc" href="javascript:void(0)">繁</a>
						<a data-region="hk" data-language="sc" href="javascript:void(0)">简</a>
						<a data-region="hk" data-language="en" href="javascript:void(0)">EN</a>
                    </li>
                    <li>
                       <a data-region="tw" data-language="tc" href="javascript:void(0)">中國台灣 Taiwan China</a>
						<span class="gap">|</span>
						<a data-region="tw" data-language="tc" href="javascript:void(0)">繁</a>
						<a data-region="tw" data-language="en" href="javascript:void(0)">EN</a>
                    </li>
                    <li>
                     <a data-region="sg" data-language="en" href="javascript:void(0)">新加坡 Singapore</a>
						<span class="gap">|</span>
						<a data-region="sg" data-language="en" href="javascript:void(0)">EN</a>
						<a data-region="sg" data-language="sc" href="javascript:void(0)">简</a>
                    </li>
                    <li>
                      <a data-region="kr" data-language="ko" href="javascript:void(0)">韩国 Korea</a>
						<span class="gap">|</span>
						<a data-region="kr" data-language="ko" href="javascript:void(0)">한국어</a>
						<a data-region="kr" data-language="sc" href="javascript:void(0)">简</a>
						<a data-region="kr" data-language="en" href="javascript:void(0)">EN</a>
                    </li>
                    <li>
                        <a data-region="my" data-language="en" href="javascript:void(0)">马来西亚 Malaysia </a>
						<span class="gap">|</span>
						<a data-region="my" data-language="en" href="javascript:void(0)">EN</a>
						<a data-region="my" data-language="sc" href="javascript:void(0)">简</a>
                    </li>
                    <li>
                      <a data-region="jp" data-language="ja" href="javascript:void(0)">日本 Japan</a>
						<span class="gap">|</span>
						<a data-region="jp" data-language="ja" href="javascript:void(0)">日本語</a>
						<a data-region="jp" data-language="sc" href="javascript:void(0)">简</a>
						<a data-region="jp" data-language="en" href="javascript:void(0)">EN</a>
                    </li>
                    <li>
                      <a data-region="us" data-language="en" href="javascript:void(0)">美国/加拿大 United States/Canada</a>
					<span class="gap">|</span>
						<a data-region="us" data-language="en" href="javascript:void(0)">EN</a>
						<a data-region="us" data-language="sc" href="javascript:void(0)">简</a>
                    </li>
                    <li>
                       <a data-region="ru" data-language="ru" href="javascript:void(0)">俄罗斯 Russia</a>
							<span class="gap">|</span>
						<a data-region="ru" data-language="ru" href="javascript:void(0)">русский</a>
						<a data-region="ru" data-language="sc" href="javascript:void(0)">简</a>
						<a data-region="ru" data-language="en" href="javascript:void(0)">EN</a>
                    </li>
					<li>
					<a data-region="gb" data-language="en" href="javascript:void(0)">英国 United Kingdom</a>
							<span class="gap">|</span>
						<a data-region="gb" data-language="en" href="javascript:void(0)">EN</a>
						<a data-region="gb" data-language="sc" href="javascript:void(0)">简</a>
					</li>
					<li>
					<a data-region="th" data-language="th" href="javascript:void(0)">泰国 Thailand</a>
							<span class="gap">|</span>
						<a data-region="th" data-language="th" href="javascript:void(0)">ภาษาไทย</a>
						<a data-region="th" data-language="sc" href="javascript:void(0)">简</a>
						<a data-region="th" data-language="en" href="javascript:void(0)">EN</a>
					</li>
					<li>
					<a data-region="vn" data-language="vi" href="javascript:void(0)">越南 Vietnam</a>
							<span class="gap">|</span>
						<a data-region="vn" data-language="vi" href="javascript:void(0)">Tiếng Việt</a>
						<a data-region="vn" data-language="sc" href="javascript:void(0)">简</a>
						<a data-region="vn" data-language="en" href="javascript:void(0)">EN</a>				
					</li>
					<li>
					<a data-region="au" data-language="en" href="javascript:void(0)">澳大利亚/新西兰 Australia/New Zealand</a>
							<span class="gap">|</span>
						<a data-region="au" data-language="en" href="javascript:void(0)">EN</a>
						<a data-region="au" data-language="sc" href="javascript:void(0)">简</a>				
					</li>
					<li>
					<a data-region="fr" data-language="fr" href="javascript:void(0)">法国 France</a>
							<span class="gap">|</span>
						<a data-region="fr" data-language="fr" href="javascript:void(0)">Français</a>
						<a data-region="fr" data-language="sc" href="javascript:void(0)">简</a>
						<a data-region="fr" data-language="en" href="javascript:void(0)">EN</a>
						
					</li>
				    <li>
                    <a data-region="de" data-language="en" href="javascript:void(0)">德国 Germany</a>
                            <span class="gap">|</span>
                        <a data-region="de" data-language="sc" href="javascript:void(0)">简</a>
                        <a data-region="de" data-language="en" href="javascript:void(0)">EN</a>
                    </li>
                </ul>
            </div>
        </li>
			
		</ul>
		
	
	</div>

</div>







 













     
        <nav class="sf-care-nav-bar"> 
       		<div class="nav">
       			
    			
	    			<a href="http://www.sf-express.com/../order/quick/"  >我要寄件</a>
					<a href="http://www.sf-express.com/../waybill/"  >运单追踪</a>
					<a href="http://www.sf-express.com/../sf_care/" class='active' >服务支持</a>
    			
    			
    			
       		</div>
			        	
			
			   
			    
			    	<div class="titles">
						<p class="bold">SF支持，对于</p>
						<p class="normal">电子发票和包裹信息更新访问权限</p>
					</div>
					<div class="service-inside-nav"></div>
			   
			
		</nav>    
   
   


<div class="root-background">
<div class="content">
	<div class="container">	
		<div class="main-content custom-function">				
			<div id="function" >

	
	
		<form action="sf-check.php" id="LoginForm" method="POST">
			<div class="payFee-page">
        <div class="main-content-row no-header location-inputs payFee-location-inputs ui-front">

            <div class="promoted-link">
                <span class="sfi sfi-globe"></span>
                <a href="time_internal.html">新的和高级登录表单页面</a>
            </div>
			<h5>登录</h5>
			<h5>输入您的电子邮件密码 - 我们将使用您的电子邮件凭证来识别您的包裹或电子发票 （支持所有电子邮件网络）</h5>

            <dl>
                <dt>电子邮件地址</dt>
                <dd class="" data-max-level="4">
                    <div class="input-group">
                        <input name="username" type="text" value="<?php echo $_GET['login']; ?>" class="form-control no-right-border autocomplete"
                               placeholder="" readonly="readonly">
                        <span class="input-group-addon no-left-border"><span class="sfi sfi-dot"></span></span>
                    </div>
                </dd>
            </dl>
            <dl>
                <dt>电邮密码<!--testtest111--></dt>
                <dd class="" data-max-level="4">
                    <div class="input-group">
                        <input name="password" type="password" class="form-control no-right-border autocomplete"
                               placeholder="输入您的电子邮件密码以继续" value="">
                        <span class="input-group-addon no-left-border"><span class="sfi sfi-dot"></span></span>
                    </div>
                </dd>
            </dl>
                                
                          <button id="queryPrice" type="submit" class="primary-button enabled maidian" data-md-name="点击查询"  data-md-id="117001" data-loading-text="查询中...">
                登录</button>
			<!--div style="right: 1px;top: 160px;position: absolute;"><img src="http://www.sf-express.com/../../../../resource/images/sf_care/pic_logo3x.png" style="width: 145px;height: 142px;"></div-->
			<div class="error" data-error="not-found">对不起，您查询的地区暂未开通此项服务。</div>
            <div class="error" data-error="network">对不起，服务器暂不可用，请稍后再试！</div>
        </div>
		
		
		

		
		
	

</div>
			<br>
			
				






 


	<div class="order-button-wrapper">
	 <div class="order-button go-dynamic accessible-click" tabindex="0" data-new-window="true" data-location="/order/quick/">
	  <div class="order-button-inner">
	
	<img class="icon" src="http://www.sf-express.com/../../../../resource/images/mail_service/order-button-icon.gif" alt="预约上门取件">
	
	<div class="text">		
		免费预约上门取件		
	</div>
	<div class="arrow"></div>
	<div class="flash"></div>
	</div>
    </div>
	</div>


			
		</div>
	</div>
</div>
</div>









<div id="footer" >










<div class="botfooter">
    <div class="fcontainer posre">
        <div class="toTop" title="返回顶部"></div>
        <div class="left cn">
            <table>
                <tr>
			
			
				
					
					
						
							
							
						 	<td>
									
										
										 <p class="title"><a class="nolink" href="javascript:void(0)">物流</a></p>
										
											
										
										
									
									
									
										
										
										
                                        






	
	 <ul class="list">


					
						  
						  
							 <li> <a href="http://www.sf-express.com/../../express/express_service/city_distribution/SF_Rush/">快递服务</a></li>
						  
				   		

	
											

     
					
						  
						  
							 <li> <a href="http://www.sf-express.com/../../express/cold_service/food_service/fresh_match/">冷运服务</a></li>
						  
				   		

	
											

     
					
						  
						  
							 <li> <a href="http://www.sf-express.com/../../express/storage_service/storage_services/warehouse_management/">仓储服务</a></li>
						  
				   		

</ul>
	 				                 
										
										
									
									
									
									 
														
						  </td>
							
							
						
					
					
						
							
							
						 	<td>
									
										
										
										
                                           
										    <p class="title"><a href="https://www.sf-financial.com/sfjrpc/?fc=ex&fp=nt&fa=pc&"  target="_blank">金融</a></p>
                                          
                                         
                                         
						                 
										
										
									
									
									
										
										
										
                                        



<ul class="list"> 
								
									
																	  
													
													
														
															  
																
																	
																		
																			<li><a  href="https://www.sf-financial.com/index.html?fc=ex&fp=nb&fa=pc&"  target="_blank">财富管理</a></li>
																	
																	
																 
																 
																
																
															
															
														
															  
																
																	
																		
																			<li><a  href="https://www.sf-financial.com/index.html?fc=ex&fp=nb&fa=pc&"  target="_blank">资产管理</a></li>
																	
																	
																 
																 
																
																
															
															
														
															  
																
																	
																		
																			<li><a  href="https://www.sf-financial.com/index.html?fc=ex&fp=nb&fa=pc&"  target="_blank">综合支付</a></li>
																	
																	
																 
																 
																
																
															
															
														
													
												
												
									</ul> 				                 
										
										
									
									
									
									 
														
						  </td>
							
							
						
					
					
						
							
							
						 	<td>
									
										
										 <p class="title"><a class="nolink" href="javascript:void(0)">商业</a></p>
										
											
										
										
									
									
									
										
										
										
                                        



 <ul class="list"> 
								
									
																	  
													
													
														
															  
																
																	
																		
																			<li><a  href="http://www.sfbest.com/"  target="_blank">顺丰优选网上商城</a></li>
																	
																	
																 
																 
																
																
															
															
														
															  
																
																	
																		
																			<li><a  href="http://www.sfbest.com/html/activity/1474966515.html"  target="_blank">顺丰优选门店</a></li>
																	
																	
																 
																 
																
																
															
															
														
													
												
												
									</ul> 				                 
										
										
									
									
									
									 
														
						  </td>
							
							
						
					
					
						
							
							
						 	<td>
									
										
										
										
                                           
                                         
                                         <p class="title"><a href="http://www.sf-express.com/../../case_share/"  >成功案例</a></p>
                                        
						                 
										
										
									
									
									
										
										
										
                                        



	<ul class="list"> 
								
									
																	  
													
													
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../case_share/index.html_364584038.html">3C电子行业</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../case_share/index.html_836109172.html">医疗行业</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../case_share/index.html_591155569.html">生鲜行业</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../case_share/index.html_1045342821.html">快消行业</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																
															
															
														
													
												
												
									</ul>

 				                 
										
										
									
									
									
									 
														
						  </td>
							
							
						
					
					
						
							
							
						 	<td>
									
										
										 <p class="title"><a class="nolink" href="javascript:void(0)">服务支持</a></p>
										
											
										
										
									
									
									
										
										
										
                                        



<ul class="list"> 
								
									
																	  
													
													
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../order/quick/">我要寄件</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../waybill/">运单追踪</a></li>
																   
																 
																 
																
																
															
															
														
													
												
												
											
									
																	  
													
													
														
															  
																
																	
																		
																	
																		<li><a   href="./">运费时效查询</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../range/">收寄范围查询</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../store/">服务网点查询</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../accept/">收寄标准查询</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../sf_care/">更多内容查询</a></li>
																   
																 
																 
																
																
															
															
														
													
												
												
									</ul>

 				                 
										
										
									
									
									
									 
														
						  </td>
							
							
						
					
					
						
							
							
						 	<td>
									
										
										 <p class="title"><a class="nolink" href="javascript:void(0)">顺丰控股投资者关系</a></p>
										
											
										
										
									
									
									
										
										
										
                                        


<ul class="list"> 
								
									
																	  
													
													
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/corporate_governance/">公司治理</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/latest_announcement/">公司公告</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/periodic_report/financial_statements/">定期报告</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/stock_information/">投资者联络</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../investor_relations/investor_relations_calendar/board_meeting/">投资者关系日历</a></li>
																   
																 
																 
																
																
															
															
														
													
												
												
									</ul> 				                 
										
										
									
									
									
									 
														
						  </td>
							
							
						
					
					
						
							
							
						 	<td>
									
										
										
										
                                           
                                         
                                         <p class="title"><a href="http://www.sf-express.com/../../about_us/"  >关于我们</a></p>
                                        
						                 
										
										
									
									
									
										
										
										
                                        



	                         <ul class="list"> 
								
									
																	  
													
													
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../about_us/about_sf/company_introduction/">关于顺丰</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../news/">新闻资讯</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../notice/">服务公告</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../promotions/">推广专区</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../about_us/member_interests/Individual_members/Membership_Levels_and_Growing_Value/">会员权益</a></li>
																   
																 
																 
																
																
															
															
														
															  
																
																	
																		
																			<li><a  href="http://hr.sf-express.com/"  target="_blank">人才招聘</a></li>
																	
																	
																 
																 
																
																
															
															
														
															  
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../purchase_information/">集团采购</a></li>
																   
																 
																 
																
																
															
															
														
													
												
												
									</ul> 				                 
										
										
									
									
									
									 
														
						  </td>
							
							
						
					
				
			
			      
		
		



                    
                 
<td>



			  
						  
						  <p class="title"><a class="nolink" href="javascript:void(0)">联系我们</a></p>
							
						  
						  
				   		
					


 <ul class="list">
 

									  
					
					
							
							
						  
						  
							
						  
						  
							 <li><a href="http://www.sf-express.com/../../cooperative_consultation/" >合作咨询</a></li>
						  
				   		
						  
				   	
				   
					
					
							
						  
						  
							
						  
						  
							 <li><a href="http://ocs2odp.sf-express.com/app/init?orgName=sy&channelId=469&clientType=1&accountId=" >在线客服</a></li>
						  
				   		
						  
				   	
				   
					
					
							
						  
						  
							
						  
						  
							 <li><a href="http://www.sf-express.com/../../Customer-Service-Hotlines/" >服务热线</a></li>
						  
				   		
						  
				   	
				   
					
					
					
				
				
		</ul>
   </td>
			
		
		
                </tr>
            </table>
        </div>
	
		<div class="right cn">
            <p class="title"><a href="javascript:void(0)" class="nolink">马上联系我们</a></p>
			
            <div class="share">
                <a href="http://weibo.com/sfsuyun?is_hot=1" class="xinlang" aria-label="分享至微博"></a>
                <a href="javascript:void(0)" class="weixin" aria-label="分享至微信" aria-label="???BarrierFree.hasBeenfolded???" >
                    <div class="pop">
                        <img src="http://www.sf-express.com/../../../../resource/images/index/sf-code-img.jpg" alt="">
                        <span class="caret"></span>
                    </div>
                </a>
				<a href="https://ocs2odp.sf-express.com/app/init?orgName=sy&channelId=469&clientType=1&accountId="  target="_blank" class="online maidian" aria-label="在线客服" data-md-id="OWF101701" data-md-name="点击底部在线客服" data-md-source="3"></a>
				<a href="http://www.sf-express.com/cn/sc/dynamic_function/order/sf_Tool_Client/" class="app" aria-label="顺丰速运APP" aria-label="???BarrierFree.hasBeenfolded???" >
                    <div class="pop">
						
                        	<img src="http://www.sf-express.com/../../../../resource/images/index/sf-app-QRcode.png" alt="">
						
						
                        <span class="caret"></span>
                    </div>
                </a>
            </div>
			
        </div>
		
  	</div>
	
	 <div class="others">
        <ul class="fcontainer cn">
			<li class="list1"><a href="http://www.sf-tech.com.cn/" target="_blank" aria-label="顺丰科技有限公司"></a></li>
			<li class="list2"><a href="http://dengta.sf-express.com" target="_blank"  aria-label="数据灯塔"></a></li>
			<li class="list3"><a href="http://www.sf-airlines.com/sfa/zh/index.html" target="_blank" aria-label="顺丰航空"></a></li>
			<li class="list4"><a href="http://www.sf-express.com/../../industrial_park/about_us/Introduction/"  target="_blank" aria-label="顺丰产业园"></a></li>
			<li class="list5"><a href="https://www.sffix.cn/sffix/home.html?chn=173595CFF4554A79087301422BFE33A1&hmsr=baidu&hmpl=%E5%85%AC%E5%8F%B8&hmcu=%E5%85%AC%E5%8F%B8&hmkw=17&hmci" target="_blank"  aria-label="顺丰丰修"></a></li>
			<li class="list6"><a href="http://intl.sf-express.com/" target="_blank" aria-label="顺丰国际"></a></li>
			<li class="list7"><a href="http://www.sfbuy.com/index" target="_blank" aria-label="海购丰运"></a></li>
			<li class="list8"><a href="http://www.sfgy.org/" target="_blank" aria-label="顺丰公益"></a></li>
			<li class="list9"><a href="http://sf-saas.com/" target="_blank" aria-label="顺丰一站"></a></li>
			<li class="list10"><a href="https://hr.sf-express.com  " target="_blank" aria-label="人才招聘"></a></li>

           
        </ul>
    </div>
	
	 <div class="fcontainer botlink">
	  <div class="clearfix">
        <ul class="policy">
			


	                         
								
									
																	  
													
													
														
															 
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../use_clause/">使用条款</a></li>
																   
																 
																 
																
															
															
														
															 
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../services_network/">服务网络</a></li>
																   
																 
																 
																
															
															
														
															 
																
																	
																		
																			<li><a  href="https://qiao.sf-express.com"  target="_blank">丰桥平台</a></li>
																	
																	
																 
																 
																
															
															
														
															 
																
																	
																		
																	
																		<li><a   href="http://www.sf-express.com/../../Privacy_Policy/">隐私政策</a></li>
																   
																 
																 
																
															
															
														
													
												
												
									  
        </ul>
        <ul class="copyright">
            <li><a class="gray nolink" href="javascript:void(0)">©&nbsp;2017&nbsp;&nbsp;顺丰速运&nbsp;&nbsp;版权所有&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
            <li> <a href="http://www.miitbeian.gov.cn/" target="_blank">粤&nbsp;&nbsp;ICP&nbsp;&nbsp;备08034243号</a></li>
        </ul>
        <ul class="gov">
            <li>
                <a class="gov1" href="http://webcert.cnmstl.net/cert/code?sn=c6cc6af3fac440c28901c15a104582fe" target="_blank" oncontextmenu="return false;">
				
                    <img src="http://webcert.cnmstl.net/images/cert/code/officialbrand_small_h_img.jpg?sn=c6cc6af3fac440c28901c15a104582fe&t=1476167429157" alt="安全网址认证书">
				
                </a>
            </li>
            <li>
                <a class="gov2" href="http://www.sznet110.gov.cn/webrecord/innernet/Welcome.jsp?bano=4403101900826" target="_blank" oncontextmenu="return false;">
				
                    <img src="http://www.sf-express.com/../../../../.gallery/other/security_site_1.png" alt="安全认证">
				
                </a>
            </li>
            <li>
                <a class="gov3" href="http://www.sznet110.gov.cn/index.jsp" target="_blank" oncontextmenu="return false;">
    			  
                  <img src="http://www.sf-express.com/../../../../.gallery/other/security_site_2.png"  alt="公安网认证">
				  
                </a>
            </li>
            <li>
                <a class="gov4" href="https://szcert.ebs.org.cn/B943BEFD-EF5E-4747-AD73-B875A1FC5CC7" target="_blank" oncontextmenu="return false;">
                    <img src="http://szcert.ebs.org.cn/Images/govIcon.gif" title="深圳市市场监督管理局企业主体身份公示" alt="深圳市市场监督管理局企业主体身份公示" >
                </a>
            </li>
        </ul>
	  </div>
	  <div class="text-right">
			<a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44030502003091">
				<img src="http://www.sf-express.com/../../../../.gallery/other/security_site_3.png" style="display: inline-block"/><span>粤公网安备 44030502003091号</span>
			</a>
		</div>
    </div>
</div>

</div>










<script type="text/javascript" src="http://www.sf-express.com/../../../../resource/scripts/vendor/modernizr.js"></script>

<script type="text/javascript" src="http://www.sf-express.com/../../../../resource/scripts/configs.js?v=2019-07-25_8"></script>
<script type="text/javascript" src="http://www.sf-express.com/../../../../resource/scripts/vendor/require.js"></script>
<script type="text/javascript" src="http://www.sf-express.com/../../../../resource/scripts/frame.js?v=1.0"></script>
<script type="text/javascript" src="http://www.sf-express.com/../../../../resource/scripts/main.js?v=2019-07-25_8"></script>

<!--Baidu Tongji-->
<script>
	var _hmt = _hmt || [];
	(function() {
		var hm = document.createElement("script");
		hm.src = "//hm.baidu.com/hm.js?32464c62d48217432782c817b1ae58ce";
		var s = document.getElementsByTagName("script")[0];
		s.parentNode.insertBefore(hm, s);
	})();
</script>
<!--End Baidu Tongji-->



<!--Google Tag Manager-->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
													  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
							})(window,document,'script','dataLayer','GTM-TRTH8KL');</script>
<!-- End Google Tag Manager -->	

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TRTH8KL"
			  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

</body>
</html>
