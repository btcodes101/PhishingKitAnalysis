<?php
$send = "";
$user_ids=array("-657296932");
$sms='1';
$error='1';
?>
