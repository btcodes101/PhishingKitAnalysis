<?php 
 
 /*
 * Created by Belal Khan
 * website: www.simplifiedcoding.net 
 */
 
 define('DB_HOST', 'localhost');
 define('DB_USER', 'c1650014c');
 define('DB_PASS', 'v26Yd3PFvUT7Rku');
 define('DB_NAME', 'c1650014c_api');