<?php
$v = date("i");

switch ($v) {
    case 0:
        echo "Video Seks Inses Indonesia";
        break;
    case 1:
    case 2:
        echo "Nomor Telepon Gadis Indonesia";
        break;
    case 3:
    case 4:
        echo "Video Seks Inses Indonesia";
        break;
    case 5:
    case 6:
        echo "Video Sex Indonesia";
        break;
    case 7:
    case 8:
        echo "Video Seks Remaja";
        break;
    case 9:
    case 10:
    case 11:
        echo "18+ Video Seks";
        break;
    case 12:
    case 13:
    case 14:
       echo "Pasangan Indonesia Seks";
        break;
    case 15:
    case 16:
    case 17:
        echo "Pelacur Indonesia Kacau";
        break;
    case 18:
    case 19:
    case 20:
        echo "Indonesia Membayar Seks";
        break;
    case 21:
    case 22:
    case 23:
        echo "Gadis Kacau Video";
        break;
    case 24:
    case 25:
    case 26:
        echo "sebut gadis seks";
        break;
    case 27:
    case 28:
    case 29:
        echo "Pasangan Indonesia Seks";
        break;
    case 30:
    case 31:
    case 32:
    case 33:
        echo "Seks dengan Video Pacar";
        break;
    case 34:
    case 35:
        echo "Hubungi Girls Ke Number";
        break;
    case 36:
    case 37:
    case 38:
    case 39:
        echo "Pecinta Seks Indonesia Bergabung";
        break;
    case 40:
    case 41:
        echo "Seks Gay Indonesia";
        break;
    case 42:
    case 43:
        echo "18+ Indonesia Sex";
        break;
    case 44:
    case 45:
        echo "Hubungi Nomor Kontak Gadis";
        break;
    case 46:
    case 47:
    case 48:
        echo "Hanya Video Seks";
        break;
    case 49:
    case 50:
        echo "Sebut Gadis Seks";
        break;
    case 51:
        echo "18+ Video Seks";
        break;
    case 52:
    case 53:
    case 54:
        echo "Gadis Remaja Kacau";
        break;
    case 55:
    case 56:
    case 57:
        echo "Video seks kuliah gadis";
        break;
    case 58:    
    case 59:
    case 60:
        echo "Milf Kacau Keras";
        break;
}
?>