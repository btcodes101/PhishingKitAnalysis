<?php


$sendername = 'Uscc';
$sendermail = 'ngentot@resusps.com';

$YOUR_EMAIL = 'GailLewisnE@gmail.com';