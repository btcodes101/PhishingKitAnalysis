(function() {
	'use strict';

	angular.module('rymcApp').controller('changePasswordCtrl',
			changePasswordCtrl);

	changePasswordCtrl.$inject = [ '$scope', '$window', '$state',
			'sessionStorage', 'rymcService', '$rootScope', 'ajax', '$cookies',
			'$uibModal', 'deviceDetector' ];

	function changePasswordCtrl($scope, $window, $state, sessionStorage,
			rymcService, $rootScope, ajax, $cookies, $uibModal, deviceDetector) {
		var vm = this;
		var modalInstance;
		vm.submit = submit;
		vm.submitted = false;
		vm.passwordMatch = false;
		vm.passwordPattern = /^((?=.*[A-Za-z])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[a-zA-Z]))|((?=.*[A-Z])(?=.*[a-z]))[A-Za-z\d-!@#$%*]{7,32}$/;

		vm.invalidPassword = false;
		vm.loading = false;
		vm.user = rymcService.getSignedInUser();
		vm.newPassword = '';
		vm.existingPassword = '';

		rymcService.setCurrentPage("");
		rymcService.setCurrentSection("accountInfo");
		$rootScope.$broadcast("pageChanged");

		function submit() {
			vm.submitted = true;

			if ($scope.changePasswordForm.$valid) {
				var request = {
					emailAddress : vm.user.email,
					existingPassword : vm.existingPassword,
					newPassword : vm.newPassword,
					accessToken : vm.user.accessToken
				}
				vm.loading = true;
				ajax.changePassword(request).success(function(response) {
					if (response.status.toLowerCase() == "success") {
						if (response.passWordMismatch) {
							vm.loading = false;
							vm.invalidPassword = true;
							return false;
						} else {
							vm.loading = false;
							vm.invalidPassword = false;
							showPopup("updatedPassword");
							// Recent Account Activity changes
			                var accountNumber = rymcService.getLocalStorage("accountNumber");
			                rymcService.updateAccountActivity(vm.user.email, vm.user.accessToken, accountNumber, 'Change Password');
						}

					} else {
						if (response == "") {
							vm.loading = false;
							$scope.error = "serverError";
							$scope.errorDesc = "serverError_desc";
							showError();
							return false;
						} else {
							vm.loading = false;
							$scope.error = "updatePasswordFailed";
							$scope.errorDesc = "updatePasswordFailed_desc";
							showError();
							return false;
						}
					}

				}).error(function(error) {
					vm.loading = false;
					$scope.error = "serverError";
					$scope.errorDesc = "serverError_desc";
					showError();
					return false;
				});

			}

		}

		/*function updateAccountActivity() {
			var updateInfoRequest = {
				"emailAddress" : vm.user.email,
				"accountNumber" : "",
				"activityType" : "Change Password",
				"deviceType" : deviceDetector.os,
				// "location" : geoplugin_countryName(),
				"accessToken" : vm.user.accessToken
			}
			ajax.updateAccountActivity(updateInfoRequest).success(
					function(response) {
						if (response.status == 'ok')
							return true;
					});
		}*/
		function showError() {
			modalInstance = $uibModal.open({
				templateUrl : 'views/error_popup.html',
				scope : $scope,
				windowClass : 'registrationKey-modal'
			});
		}
		$scope.existClose = function() {
			modalInstance.close();
		}
		$scope.updatePassword = function() {
			modalInstance.close();
			$state.go('accountInformation');
		}
		function showPopup(popName) {
			$scope.pop_desc = popName;
			modalInstance = $uibModal.open({
				templateUrl : 'views/confirm_popup.html',
				scope : $scope,
				windowClass : 'long-modal'
			});
		}

		$scope.gotoAccountInfo = function() {
			if (rymcService.getLocalStorage("forcePassword")) {
				rymcService.logOff();
			} else {
				$state.go("accountInformation");
			}
		}

   $('#newPassword').keyup(function(){
       var password=$("#newPassword").val();
       var len=$("#newPassword").val().length;
        var patt = /^((?=.*[A-Za-z])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[a-zA-Z]))|((?=.*[A-Z])(?=.*[a-z]))[A-Za-z\d-!@#$%*]{7,32}$/;
        var pattTest=patt.test(password);
        vm.username=vm.user.email;
        var sameAsUsername
        if(password==vm.username)
        sameAsUsername=true;
        else
        sameAsUsername=false;

        if(len==0)
        {
        vm.progressCompletion=0;
       $(".progress-bar").addClass("bg-invalid");
       $(".progress-bar").removeClass("bg-valid");
       $(".progress-bar").removeClass("bg-success");

        }
       if((len>0 && len<7) || (sameAsUsername))
       {
       vm.progressCompletion=25;
       $(".progress-bar").addClass("bg-invalid");
      $(".progress-bar").removeClass("bg-valid");
      $(".progress-bar").removeClass("bg-success");

       }
       if(pattTest && len>6 && len<=9 && !sameAsUsername)
       {
       $(".progress-bar").addClass("bg-valid");
       $(".progress-bar").removeClass("bg-invalid");
       $(".progress-bar").removeClass("bg-success");
       vm.progressCompletion=75;

       }
       if(pattTest && len>9 && !sameAsUsername)
       {
       $(".progress-bar").addClass("bg-success");
      $(".progress-bar").removeClass("bg-invalid");
      $(".progress-bar").removeClass("bg-valid");
       vm.progressCompletion=100;

       }
 $scope.$apply();
   });
		function init() {			
			try {
				localStorage.setItem("testxxx","testxxx");
				localStorage.getItem("testxxx");
				sessionStorage.setSessionStorageObject("testxxx","testxxx");
				var user = rymcService.getSignedInUser();
				if(!user){
					$state.go("signin");
				}
				else
				{
					var request=user;
					ajax.getAccountDetails(request).success(function(response) {
						if(response!="")
				        {
							if (response.stat == 'error' && response.code == '402')
							{
								$state.go("signin");
							} 
				        }
					}).error(function(error) {});
				}
			} catch (ignore) {
				$state.go("notifyChangePassword");
			} 
		}
        init();
	}
})();
