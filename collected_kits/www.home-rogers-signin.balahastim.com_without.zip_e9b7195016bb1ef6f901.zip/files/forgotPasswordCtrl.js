(function() {
  'use strict';

angular.module('rymcApp').controller('forgotPasswordCtrl', forgotPasswordCtrl);

forgotPasswordCtrl.$inject = ['$scope','$window','$state','rymcService','$rootScope','ajax','sessionStorage','$uibModal'];

function forgotPasswordCtrl($scope,$window,$state,rymcService,$rootScope,ajax,sessionStorage,$uibModal) {

var vm=this;
rymcService.setCurrentPage("passwordRecovery");
$rootScope.$broadcast("pageChanged");
vm.submit=submit;
vm.loading = false;
var modalInstance;
vm.validateEmail=validateEmail;
vm.emailValidated=false;
//vm.emailPattern=/\w*rogers.com\b/;
function submit(){
    vm.submitted = true;
    var request={
    "email":vm.emailAddress
    }
    vm.loading=true;
 ajax.validateRecoveryEmail(request).success(function(response) {
	 vm.loading=false;
   if(response && response.status.toLowerCase()=="success")
   {
   sessionStorage.setSessionStorageObject('forgotPassword',response);
   $state.go("verification");
   }
    else
   {
    	 vm.loading=false;
	    if(response=="")
	    	{
	    	  $scope.error="serverError";
              $scope.errorDesc="serverError_desc";
  	    	}
	    else if(response.ErrorCode>200)
	        {
	        $scope.error="",
	        $scope.errorDesc="passwordRecovery."+response.ErrorCode;
	        }
	    else
	    	{
	    	 $scope.error="serverError";
             $scope.errorDesc="serverError_desc";
	    	}
	        showError();
           return false;
   }

 }).error(function(error) {
	 				vm.loading=false;
                    $scope.error="serverError";
                    $scope.errorDesc="serverError_desc";
                    showError();
                    return false;
 });


}

function validateEmail()
{
var email=document.getElementById("username").value;
email=email.toLowerCase()
document.getElementById("username").value=email
vm.emailAddress=email;

if(email.indexOf("rogers.com")>1)
{
    vm.emailValidated=true;
}
else
{
     vm.emailValidated=false;
}
}

function showError(){
    modalInstance = $uibModal.open({
        templateUrl: 'views/error_popup.html',
        scope: $scope,
        windowClass: 'registrationKey-modal'
    });
}
$scope.existClose = function () {
        modalInstance.close();
}

}
})();
 