'use strict';

/**
 * @ngdoc Directive
 * @name deviceModel
 * @description # A directive showing one product, smartphone, basic phone or
 *              tablet. Usage: <device-model data-device='model'
 *              data-settings='settings'></device-model> 'data-device':
 *              introduce an array of product (belong to same model) from
 *              outside scope. 'data-settings': settings
 *
 */

angular.module('rymcApp').directive('authorizedApp', authorizedApp).controller(
		'authorizedAppCtrl', authorizedAppCtrl);

function authorizedApp() {
	var varDirective = {
		restrict : 'E',
		scope : {
			passwords : '='
		},
		templateUrl : 'js/directives/authorizedApplications/authorizedApplications.html',
		controller : authorizedAppCtrl,
		controllerAs : 'vm'
	};
	return varDirective;
}
authorizedAppCtrl.$inject = [ '$scope', 'ajax', '$uibModal', '$rootScope',
		'$translate', 'settings', 'rymcService', 'sessionStorage', '$state' ];
function authorizedAppCtrl($scope, ajax, $uibModal, $rootScope, $translate,
		settings, rymcService, sessionStorage, $state) {
	var vm = this;
	var modalInstance;
	vm.showGeneratePassword = showGeneratePassword;
	vm.passwordName = '';
	vm.showConfirmDelete = showConfirmDelete;
	vm.user = rymcService.getSignedInUser();
    $scope.namePattern=/^([a-zA-Z0-9\u00C0-\u00FF-' ](?!_)(?!.*  ))+$/;

	if ($scope.passwords.passwordName && $scope.passwords.passwordName != " ") {
		vm.passwordName = $scope.passwords.passwordName;
		$scope.generatedPassword = vm.passwordName;
	}

	function showGeneratePassword() {
		$scope.generatedPassword = vm.passwordName;
		var request = {
			appPasswordName : vm.passwordName,
			emailAddress : vm.user.email,
			accessToken : vm.user.accessToken
		}
		vm.loading=true;
		ajax.setAppPassword(request).success(function(result) {
			vm.loading=false;
            $scope.generatedPassword=result.strAppPassword;
			if (result.status.toLowerCase() === "success") {
				modalInstance = $uibModal.open({
					templateUrl : 'views/generatePassword.html',
					scope : $scope,
					windowClass : 'alternate-modal'
				});
				//$scope.$parent.vm.init();
				// Recent Account Activity changes
                var accountNumber = rymcService.getLocalStorage("accountNumber");
                rymcService.updateAccountActivity(vm.user.email, vm.user.accessToken, accountNumber, 'App Password Set');
			} else {
				vm.loading=false;
				if(result.errorCode==100001)
				{
				$scope.generatedPassword='';
				$scope.error="";
				   $scope.errorDesc="addPasswords."+result.errorCode;
				   showError();
				}
			}

		}).error(function(error) {
			vm.loading=false;
			$scope.generatedPassword='';
			 $scope.error="serverError";
             $scope.errorDesc="serverError_desc";
             showError();
             return false;
			console.log("error");
		})
	}

	$scope.existClose = function() {
		modalInstance.close();
	}
	$scope.done = function() {
		modalInstance.close();
		$scope.$parent.vm.init();
		$scope.$parent.vm.showAddAnother=true;
	}

	function showConfirmDelete(popName) {
			$scope.pop_desc = popName;
    		$scope.generatedPassword = vm.passwordName;
	         modalInstance = $uibModal.open({
    					templateUrl : 'views/confirm_popup.html',
    					scope : $scope,
    					windowClass : 'long-modal'
    				});
    }

    $scope.deletePassword=function(){
		var request = {
			appPasswordName : vm.passwordName,
			emailAddress : vm.user.email,
			accessToken : vm.user.accessToken
		}
		$scope.loading=true;
		ajax.deleteAppPassword(request).success(function(result) {
			$scope.loading=false;
			if (result.status.toLowerCase() === "success") {
				$scope.$parent.vm.init();
				// Recent Account Activity changes
                var accountNumber = rymcService.getLocalStorage("accountNumber");
                rymcService.updateAccountActivity(vm.user.email, vm.user.accessToken, accountNumber, 'App Password Deleted');
			} else {
            console.log("not deleting");
			}

		}, function(error) {
			console.log("error");
		})

	}
    function showError(){
        modalInstance = $uibModal.open({
            templateUrl: 'views/error_popup.html',
            scope: $scope,
            windowClass: 'registrationKey-modal'
        });
    }


}