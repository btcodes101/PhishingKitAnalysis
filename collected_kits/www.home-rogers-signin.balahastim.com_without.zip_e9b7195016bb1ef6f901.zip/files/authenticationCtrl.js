(function() {
	'use strict';

	angular.module('rymcApp').controller('authenticationCtrl',
			authenticationCtrl);

	authenticationCtrl.$inject = [ '$scope', '$window', '$state',
			'sessionStorage', 'rymcService', '$rootScope', 'ajax', '$cookies',
			'$uibModal', 'deviceDetector' ];

	function authenticationCtrl($scope, $window, $state, sessionStorage,
			rymcService, $rootScope, ajax, $cookies, $uibModal, deviceDetector) {
		var vm = this;
		var modalInstance;

		vm.loading = false;
		vm.user = rymcService.getSignedInUser();
		vm.authentication = false;
		vm.initLoading = true;
		vm.getStarted = false;
		vm.showauthenticate = false;
		vm.enterotp = false;
		vm.init = init;
		vm.authenticateStart = authenticateStart;
		vm.sendSMS = sendSMS;
		vm.verifyOTP = verifyOTP;
		vm.disable2FA = disable2FA;
		vm.optInFlag = '';
		vm.resendFlag = false;
		vm.status = '';
		vm.phone = '';
		rymcService.setCurrentPage("");
		rymcService.setCurrentSection("accountInfo");
		$rootScope.$broadcast("pageChanged");

		init();
		function init() {
			var request = {
				'emailAddress' : rymcService.getSignedInUser().email,
				'accessToken' : rymcService.getSignedInUser().accessToken
			};
			ajax.getTwoFactorAuthInfo(request).success(function(result) {
				vm.initLoading = false;
				vm.authentication = true;
				if (result && result.status == "success") {
					// Already registered for 2FA
					if (result.phone_NUMBER) {
						vm.phone = result.phone_NUMBER;
					}
					vm.loading = false;
					vm.status = 'success';
				} else {
					vm.getStarted = true;
					vm.loading = false;
				}
			}).error(function(error) {
				$scope.error = "serverError";
				$scope.errorDesc = "serverError_desc";
				showError();
				vm.loading = false;
				return false;
			});
		}

		function authenticateStart() {
			vm.getStarted = false;
			vm.optInFlag = 'Y';
			vm.phone = '';
			vm.showauthenticate = true;
			vm.status = 'update';
		}

		function sendSMS() {
			var request = {
				emailAddress : vm.user.email,
				phoneNumber : vm.phone,
				accessToken : vm.user.accessToken
			}
			vm.loading = true;
			ajax.performTwoFactorAuth(request).success(function(response) {
				vm.loading = false;
				if (response.status == 'success') {
					vm.showauthenticate = false;
					if (vm.optInFlag == 'N') {
						vm.status = 'disable';
						vm.enterotp = false;
					} else {
						vm.enterotp = true;
					}
					$cookies.remove('otpExpiry');
					vm.resendFlag = false;
					setOTPExpiryValue(2); // Timeout 2 minutes
				} else {
					vm.loading = false;
					$scope.error = "phoneNumberError";
					$scope.errorDesc = "phoneNumberError_desc";
					showError();
					return false;
				}
			}).error(function(error) {
				vm.loading = false;
				$scope.error = "serverError";
				$scope.errorDesc = "serverError_desc";
				showError();
				return false;
			});
		}

		function verifyOTP() {
			var request = {
				emailAddress : vm.user.email,
				phoneNumber : vm.phone,
				secretCode : vm.otp,
				optInFlag : vm.optInFlag,
				accessToken : vm.user.accessToken
			}
			if ($cookies.get('otpExpiry')) {
				vm.loading = true;
				ajax.validateAndProcess2FA(request).success(function(response) {
					vm.loading = false;
					if (response.status == 'success') {
						vm.showauthenticate = false;
						vm.enterotp = false;
						vm.otp = '';
						if (vm.optInFlag == 'N') {
							vm.status = '';
							vm.getStarted = true;
							vm.loading = false;
						} else {
							vm.status = 'success';
						}
						vm.optInFlag = '';
					} else {
						vm.loading = false;
						vm.otp = '';
						$scope.error = "otpError";
						$scope.errorDesc = "otpError_desc";
						showError();
						return false;
					}
				}).error(function(error) {
					vm.loading = false;
					$scope.error = "serverError";
					$scope.errorDesc = "serverError_desc";
					showError();
					return false;
				});
			} else {
				// OTP Expired
				console.log('OTP is expired for 2FA');
				vm.loading = false;
				vm.otp = '';
				$scope.error = "Invalid OTP";
				$scope.errorDesc = "Your OTP is expired";
				showError();
				vm.resendFlag = true;
				return false;
			}
		}

		function disable2FA() {
			vm.status = 'disable';
			vm.optInFlag = 'N';
			vm.getStarted = false;
			vm.showauthenticate = false;
			sendSMS();
		}

		function setOTPExpiryValue(timeout) {
			var today = new Date();
			var expiresValue = new Date(today);
			expiresValue.setMinutes(today.getMinutes() + timeout);
			$cookies.put('otpExpiry', 'OTP', {
				'expires' : expiresValue
			});
		}

		$scope.gotoAccountInfo = function() {
			$state.go("accountInformation");
		}

		function showError() {
			modalInstance = $uibModal.open({
				templateUrl : 'views/error_popup.html',
				scope : $scope,
				windowClass : 'registrationKey-modal'
			});
		}
		$scope.existClose = function() {
			modalInstance.close();
		}

	}
})();
