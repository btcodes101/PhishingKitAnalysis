(function() {
  'use strict';

angular.module('rymcApp').controller('addPrimaryAccountCtrl', addPrimaryAccountCtrl);

addPrimaryAccountCtrl.$inject = ['$scope','$window','$state','rymcService','$rootScope','$uibModal','ajax'];

function addPrimaryAccountCtrl($scope,$window,$state,rymcService,$rootScope,$uibModal,ajax) {

var vm=this;

vm.submit=submit;
vm.submitted=false;
vm.passwordPattern=/^((?=.*[A-Za-z])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[a-zA-Z]))|((?=.*[A-Z])(?=.*[a-z]))[A-Za-z\d-!@#$%*]{7,32}$/;
//vm.passwordPattern_old=/^(?=.*[A-Za-z])(?=.*\d)(?=.*[-!@#$%*])[A-Za-z\d-!@#$%*]{6,32}$/;
//vm.postalCodePattern=/^(\d{5}(-\d{4})?|[A-Za-z]\d[A-Za-z] *\d[A-Za-z]\d)$/;
vm.usernamePattern=/^[a-z](-(?!(\.|-|_))|_(?!(\.|_|-))|\.(?!(_|\.|-))|[a-z0-9]){1,32}[a-z0-9-_]$/;
vm.namePattern=/^([a-zA-Z\u00C0-\u00FF-'](?!_))+$/;
vm.showPopup=showPopup;
vm.loading = false;
var modalInstance;
vm.formatDOB=formatDOB;
rymcService.setCurrentPage("registration");
$rootScope.$broadcast("pageChanged");
vm.todayDate=new Date();

function submit(){
    vm.submitted = true;
    vm.invalidFirstName=false;
    vm.invalidLastName=false;
    vm.invalidDate=false;
    if($scope.addAccountForm.$valid)
    {
  	var request={
    "username":vm.username+vm.domain,
    "accountNumber":rymcService.getLocalStorage("accountNumber"),
    "randomToken":rymcService.getRandomToken(),
    "firstName":vm.firstName,
    "lastName":vm.lastName,
    "preferredLanguage":vm.language,
    "dob" : formatDOB(vm.date_DOB),
    "secretQuestion":vm.secretQuestion,
    "secretAnswer":vm.secretAnswer,
    "primarySecondaryFlag":"P",
    "newPassword":vm.newPassword,
    "tnc":"Y",
    "birthMonth":getMonth(vm.date_DOB),
    "birthYear":getYear(vm.date_DOB),
    "birthday":getDate(vm.date_DOB),
         }

        if(rymcService.getInvalidWords(vm.firstName) || rymcService.getInvalidWords(vm.lastName) || (vm.date_DOB>vm.todayDate))
        {
                if(vm.date_DOB>vm.todayDate)
                {
                vm.invalidDate=true;
                }
                if(rymcService.getInvalidWords(vm.firstName))
                {
                   vm.invalidFirstName=true;
                }
                if(rymcService.getInvalidWords(vm.lastName))
                {
                   vm.invalidLastName=true;
                }

        }
        else
        {
            vm.loading = true;
            // ajax call
            ajax.registerAccount(request).success(function(response) {

              vm.data = response; //or whatever else.
               console.log(vm.data);
                if(vm.data.status.toLowerCase()=="success")
                  {
                  vm.loading=false;
                    vm.showPopup('registered');
                    rymcService.clearLocalStorage();
                    rymcService.setRandomToken(null);
                  }
                else if(vm.data=="")
	           	 {
	           	 	vm.loading = false;
	                vm.newPassword="";
	                vm.confirmNewPassword="";
	                $scope.error="serverError";
	                $scope.errorDesc="serverError_desc";
	                showError();
	                return false;
	           	 }
                else if(vm.data.errorCode>200)
                {
                	 vm.loading = false;
                     vm.newPassword="";
                     vm.confirmNewPassword="";
                     if(vm.data.errorCode==380)
                     {
                     vm.invalidUsername=true;
                     vm.errorMsg="addAccount."+vm.data.errorCode;
                     }
                     else
                     {
                     $scope.error="";
                     $scope.errorDesc="registrationErrors."+vm.data.errorCode;
                     showError();
                     }
                     return false;
                }
                  else
                  {
                    vm.loading = false;
                    vm.newPassword="";
                    vm.confirmNewPassword="";
                    $scope.error="createAccountFailed";
                    $scope.errorDesc="createAccountFailed_desc";
                    showError();
                    return false;
                  }
            }).error(function(error) {

                       vm.loading = false;
                       vm.newPassword="";
                       vm.confirmNewPassword="";
                       $scope.error="serverError";
                       $scope.errorDesc="serverError_desc";
                       showError();
                       return false;
               })
        }

     }


}


   function formatDOB(dob){
        var dateofBirth=new Date(dob);
        var month=dateofBirth.getUTCMonth()+1;
        var date=dateofBirth.getUTCDate();
        if(date<10)
        date="0"+date;
        if(month<10)
        month="0"+month

        var formattedDate=dateofBirth.getUTCFullYear()+"-"+month+"-"+date;
        return formattedDate;
    }

   function getDate(dob){
	    var dateofBirth=new Date(dob);
	    var date=dateofBirth.getUTCDate();
        if(date<10)
        date="0"+date;
	    var formattedDate=date;
	    return formattedDate;
	}
	function getMonth(dob){
	    var dateofBirth=new Date(dob);
	    var month=dateofBirth.getUTCMonth()+1;
	    if(month<10)
        month="0"+month
	    var formattedMonth=month;
	    return formattedMonth;
	}
	function getYear(dob){
	    var dateofBirth=new Date(dob);
	    var formattedYear=dateofBirth.getUTCFullYear();
	    return formattedYear;
	}
    $scope.gotoRegistration=function()
    {
        $state.go("registration");
    }
    $scope.gotoSignin=function()
    {
        $state.go('signin');
    }
function showError(){
    modalInstance = $uibModal.open({
        templateUrl: 'views/error_popup.html',
        scope: $scope,
        windowClass: 'registrationKey-modal'
    });
}
function showPopup(popName){
$scope.pop_desc=popName;
    modalInstance = $uibModal.open({
        templateUrl: 'views/registrationPopup.html',
        scope: $scope,
        windowClass: 'registrationKey-modal',
        backdrop: 'static',
        keyboard: false
    });
}
$scope.existClose = function () {
        modalInstance.close();
}

 $('#newPassword').keyup(function(){
         var password=$("#newPassword").val();
         var len=$("#newPassword").val().length;
          var patt = /^((?=.*[A-Za-z])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[a-zA-Z]))|((?=.*[A-Z])(?=.*[a-z]))[A-Za-z\d-!@#$%*]{7,32}$/;
          var pattTest=patt.test(password);
          vm.userId=vm.username+vm.domain;

          var sameAsUsername
          if(password==vm.userId)
          sameAsUsername=true;
          else
          sameAsUsername=false;


          if(len==0)
          {
          vm.progressCompletion=0;
         $(".progress-bar").addClass("bg-invalid");
         $(".progress-bar").removeClass("bg-valid");
         $(".progress-bar").removeClass("bg-success");

          }
          if((len>0 && len<7) || (sameAsUsername))
         {
         vm.progressCompletion=25;
         $(".progress-bar").addClass("bg-invalid");
        $(".progress-bar").removeClass("bg-valid");
        $(".progress-bar").removeClass("bg-success");

         }
         if(pattTest && len>6 && len<=9 && !sameAsUsername)
         {
         $(".progress-bar").addClass("bg-valid");
         $(".progress-bar").removeClass("bg-invalid");
         $(".progress-bar").removeClass("bg-success");
         vm.progressCompletion=75;

         }
          if(pattTest && len>9 && !sameAsUsername)
         {
         $(".progress-bar").addClass("bg-success");
        $(".progress-bar").removeClass("bg-invalid");
        $(".progress-bar").removeClass("bg-valid");
         vm.progressCompletion=100;

         }
   $scope.$apply();
     });



   	/* popover */
        $('[data-toggle="popover"]').popover({placement:'auto right'});

         $("button.navbar-toggle").click(function(){
         $(".shadow").toggleClass("in");
        });
    /* popover */
function init()
{
	if(rymcService.getLocalStorage("accountNumber")==null && rymcService.getLocalStorage("termsAccepted")==null)
	{
	 $state.go("registration");
	}
// this neds to be fetched from validate registration key response
vm.domain=rymcService.getLocalStorage("domain");
}
init();
}
})();
 