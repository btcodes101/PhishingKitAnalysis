(function() {
  'use strict';

angular.module('rymcApp').controller('addAccountCtrl', addAccountCtrl);

addAccountCtrl.$inject = ['$scope','$window','$state','ajax','$uibModal','sessionStorage','rymcService','$rootScope','$cookies'];

function addAccountCtrl($scope,$window,$state,ajax,$uibModal,sessionStorage,rymcService,$rootScope,$cookies) {

var vm=this;

vm.submit=submit;
vm.submitted=false;
vm.passwordPattern=/^((?=.*[A-Za-z])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[a-zA-Z]))|((?=.*[A-Z])(?=.*[a-z]))[A-Za-z\d-!@#$%*]{7,32}$/;
//vm.postalCodePattern=/^(\d{5}(-\d{4})?|[A-Za-z]\d[A-Za-z] *\d[A-Za-z]\d)$/;
vm.usernamePattern=/^[a-z](-(?!(\.|-|_))|_(?!(\.|_|-))|\.(?!(_|\.|-))|[a-z0-9]){1,32}[a-z0-9-_]$/;
vm.namePattern=/^([a-zA-Z\u00C0-\u00FF-'](?!_))+$/;
vm.loading=false;
vm.formatDOB=formatDOB;
vm.showPopup=showPopup;
vm.user=rymcService.getSignedInUser();
vm.primaryEmail=rymcService.getPrimaryEmail();
var modalInstance;
rymcService.setCurrentPage("");
rymcService.setCurrentSection("manageEmailAccounts")
$rootScope.$broadcast("pageChanged");
vm.todayDate=new Date();
var request='';

function submit(){
vm.submitted = true;
vm.invalidFirstName=false;
vm.invalidLastName=false;
vm.invalidDate=false;
    if($scope.addAccountForm.$valid)
     {
         request={
         "username":vm.username+vm.domain,
         "accountNumber":localStorage.getItem("accountNumber"),
         "firstName":vm.firstName,
         "lastName":vm.lastName,
         "preferredLanguage":vm.language,
         "dob":formatDOB(vm.date_DOB),
         "secretQuestion" : vm.secretQuestion,
         "secretAnswer":vm.secretAnswer,
         "primaryEmail":vm.primaryEmail,
         "isAddSecondary":true,
         "primarySecondaryFlag":"S",
         "newPassword" : vm.newPassword,
         "birthMonth":getMonth(vm.date_DOB),
         "birthYear":getYear(vm.date_DOB),
         "birthday":getDate(vm.date_DOB),
         "accessToken" : vm.user.accessToken
          }

        if(rymcService.getInvalidWords(vm.firstName) || rymcService.getInvalidWords(vm.lastName) || (vm.date_DOB>vm.todayDate))
        {
                if(vm.date_DOB>vm.todayDate)
                {
                vm.invalidDate=true;
                }
                if(rymcService.getInvalidWords(vm.firstName))
                {
                   vm.invalidFirstName=true;
                }
                if(rymcService.getInvalidWords(vm.lastName))
                {
                   vm.invalidLastName=true;
                }

        }
        else
        {
            addAccount('terms');
        }

     }


}

function addAccount()
{
	 vm.loading=true;
     ajax.registerAccount(request).success(function(response) {
    vm.loading=false;
       vm.data = response; //or whatever else.
         if(vm.data.status.toLowerCase()=="success")
           {

         var newRequest={
          "account_STATUS": "A",
           "termination_DATE": null,
           "account_NUMBER": localStorage.getItem("accountNumber"),
           "first_NAME": vm.firstName,
           "last_NAME": vm.lastName,
           "accountid": vm.username+vm.domain,
           "date_OF_BIRTH":formatDOB(vm.date_DOB),
           "secret_ANSWER": vm.secretAnswer,
           "registration_NUMBER": "REG_NO",
           "preferred_LANGUAGE": vm.language,
           "secret_QUESTION": vm.secretQuestion,
           "system_CREATION_DATE": null,
           "terminated_WITH_PRIMARY": null,
           "primary_SECONDARY_FLAG": "s",
           "email_ID_ACC_ID_CREATION_DT": null,
           "forcePasswordChange":"",
           "birthMonth":getMonth(vm.date_DOB),
           "birthYear":getYear(vm.date_DOB),
           "birthday":getDate(vm.date_DOB),
           "accessToken" : vm.user.accessToken
           }

           rymcService.addUserAccount(newRequest);
           vm.showPopup('accountCreated');
           }
           else if(vm.data=="")
         	 {
        	 //modalInstance.close();
         	 vm.loading = false;
              vm.newPassword="";
              vm.confirmNewPassword="";
              $scope.error="serverError";
              $scope.errorDesc="serverError_desc";
              showError();
              return false;
         	 }
           else if(vm.data.errorCode>200)
           {
        	   //modalInstance.close();
         	  vm.loading = false;
               vm.newPassword="";
               vm.confirmNewPassword="";
               if(vm.data.errorCode==380)
               {
               vm.invalidUsername=true;
               vm.errorMsg="addAccount."+vm.data.errorCode;
               }
               else
               {
               $scope.error="";
               $scope.errorDesc="registrationErrors."+vm.data.errorCode;
               showError();
               }
               return false;
           }
           else
           {
        	// modalInstance.close();
             vm.loading = false;
             vm.newPassword="";
             vm.confirmNewPassword="";
             $scope.error="createAccountFailed";
             $scope.errorDesc="createAccountFailed_desc";
             showError();
             return false;

           }
     }).error(function(error) {
                   // modalInstance.close();
                    vm.loading = false;
                    vm.newPassword="";
                    vm.confirmNewPassword="";
                    $scope.error="serverError";
                    $scope.errorDesc="serverError_desc";
                    showError();
                    return false;
           })
}

function showError(){
    modalInstance = $uibModal.open({
        templateUrl: 'views/error_popup.html',
        scope: $scope,
        windowClass: 'registrationKey-modal'
    });
}
$scope.existClose = function () {
        modalInstance.close();
}
function showPopup(popName){
$scope.pop_desc=popName;
    modalInstance = $uibModal.open({
        templateUrl: 'views/registrationPopup.html',
        scope: $scope,
        windowClass: 'registrationKey-modal',
        backdrop: 'static',
        keyboard: false
    });
}
$scope.gotoDashboard=function()
{
    $state.go('dashboard');
}
function formatDOB(dob){
    var dateofBirth=new Date(dob);
    var month=dateofBirth.getUTCMonth()+1;
    var date=dateofBirth.getUTCDate();
    if(date<10)
    date="0"+date;
    if(month<10)
    month="0"+month

    var formattedDate=dateofBirth.getUTCFullYear()+"-"+month+"-"+date;
    return formattedDate;
}
function getDate(dob){
    var dateofBirth=new Date(dob);
    var date=dateofBirth.getUTCDate();
    if(date<10)
    date="0"+date;
    var formattedDate=date;
    return formattedDate;
}
function getMonth(dob){
    var dateofBirth=new Date(dob);
    var month=dateofBirth.getUTCMonth()+1;
    if(month<10)
    month="0"+month
    var formattedMonth=month;
    return formattedMonth;
}
function getYear(dob){
    var dateofBirth=new Date(dob);
    var formattedYear=dateofBirth.getUTCFullYear();
    return formattedYear;
}
$('#newPassword').keyup(function(){
       var password=$("#newPassword").val();
       var len=$("#newPassword").val().length;
        var patt = /^((?=.*[A-Za-z])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[a-zA-Z]))|((?=.*[A-Z])(?=.*[a-z]))[A-Za-z\d-!@#$%*]{7,32}$/;
        var pattTest=patt.test(password);
        vm.userId=vm.username+vm.domain;

        var sameAsUsername
        if(password==vm.userId)
        sameAsUsername=true;
        else
        sameAsUsername=false;


        if(len==0)
        {
        vm.progressCompletion=0;
       $(".progress-bar").addClass("bg-invalid");
       $(".progress-bar").removeClass("bg-valid");
       $(".progress-bar").removeClass("bg-success");

        }
        if((len>0 && len<7) || (sameAsUsername))
       {
       vm.progressCompletion=25;
       $(".progress-bar").addClass("bg-invalid");
      $(".progress-bar").removeClass("bg-valid");
      $(".progress-bar").removeClass("bg-success");

       }
       if(pattTest && len>6 && len<=9 && !sameAsUsername)
       {
       $(".progress-bar").addClass("bg-valid");
       $(".progress-bar").removeClass("bg-invalid");
       $(".progress-bar").removeClass("bg-success");
       vm.progressCompletion=75;

       }
        if(pattTest && len>9 && !sameAsUsername)
       {
       $(".progress-bar").addClass("bg-success");
      $(".progress-bar").removeClass("bg-invalid");
      $(".progress-bar").removeClass("bg-valid");
       vm.progressCompletion=100;

       }
 $scope.$apply();
   });


/* popover */
    $('[data-toggle="popover"]').popover({placement:'auto right'});

     $("button.navbar-toggle").click(function(){
     $(".shadow").toggleClass("in");
    });
/* popover */
function init()
{
	// this neds to be fetched from validate registration key response
	if(vm.user && vm.user.email && vm.user.email.indexOf('@nl.rogers.com') > 1) {
    	vm.domain="@nl.rogers.com";
    } else {
    	vm.domain="@rogers.com";
    }
}
init();

}
})();
 