(function() {
	'use strict';

	angular.module('rymcApp').controller('alternateContactInfoCtrl',
			alternateContactInfoCtrl);

	alternateContactInfoCtrl.$inject = [ '$scope', '$window', '$state',
			'$uibModal', 'ajax', 'sessionStorage', 'rymcService', '$rootScope',
			'settings' ];

	function alternateContactInfoCtrl($scope, $window, $state, $uibModal, ajax,
			sessionStorage, rymcService, $rootScope, settings) {
		var vm = this;
		var request = {
			'emailAddress' : rymcService.getSignedInUser().email,
			'accountNumber' : rymcService.getLocalStorage("accountNumber"),
			'accessToken' : rymcService.getSignedInUser().accessToken
		};
		vm.passWordName = null;
		vm.updatePhones = updatePhones;
		vm.updateEmails = updateEmails;
		rymcService.setCurrentPage("");
		rymcService.setCurrentSection("accountInfo");
		$rootScope.$broadcast("pageChanged");
		vm.allowedContacts = settings.allowedAlternateContacts;
		vm.init = init;
		var modalInstance;
		/* get phones */
		function init() {
			vm.showAddPhone=true;
			vm.showAddEmail=true;
			$scope.inputCounterEmail = 0;
			$scope.inputCounterPhone = 0;
			$scope.inputsPhone = [ {
				id : 'input',
				phone : '',
				phoneKey : ''
			} ];
			$scope.inputsEmail = [ {
				id : 'input',
				email : '',
				emailKey : ''
			} ];

			vm.loading = true;
			ajax.getAlternateContactDetails(request).success(function(result) {
				if (result && result.status == "success") {

					rymcService.setAlternatePhones(result.secondaryPhoneList);
					rymcService.setAlternateEmails(result.secondaryEmailList);
					$scope.phones = result.secondaryPhoneList;
					$scope.emails = result.secondaryEmailList;
					createInputs();
					vm.loading = false;
				} else if (result && result.status == "failure") {
					$state.go("signin");
				} else {
					createBlankInputs();
					vm.loading = false;
				}

			 }).error(function(error) {

				$scope.error = "serverError";
				$scope.errorDesc = "serverError_desc";
				showError();
				vm.loading = false;
				return false;

			})

		}
		function createInputs() {
			if ($scope.phones.length == 0) {
				$scope.addPhone();
			}
			if ($scope.phones.length > 0) {
				angular.forEach($scope.phones, function(value, key) {
					$scope.inputTemplatePhone = {
						id : 'inputPhone-' + $scope.inputCounterPhone,
						phone : value.alternate_PHONE_NO,
						phoneKey : key,
						status : "",
						phoneIdentification : value.id
					};
					$scope.inputCounterPhone += 1;
					$scope.inputsPhone.push($scope.inputTemplatePhone);
				});
			}
			if ($scope.emails.length == 0) {
				$scope.addEmail();
			}
			if ($scope.emails.length > 0) {
				angular.forEach($scope.emails, function(value, key) {
					$scope.inputTemplateEmail = {
						id : 'inputEmail-' + $scope.inputCounterEmail,
						email : value.alternate_EMAIL_ID,
						emailKey : key,
						status : "",
						emailIdentification : value.id
					};
					$scope.inputCounterEmail += 1;
					$scope.inputsEmail.push($scope.inputTemplateEmail);
				});
			}

		}
		function createBlankInputs() {
			$scope.inputsPhone = [ {
				id : 'inputPhone',
				phone : ' '
			} ];
			$scope.inputsEmail = [ {
				id : 'inputEmail',
				email : ' '
			} ];
		}
		$scope.addPhone = function() {
			if ($scope.inputCounterPhone < vm.allowedContacts) {
				vm.showAddPhone=false;
				$scope.inputTemplatePhone = {
					id : 'inputphone-' + $scope.inputCounterPhone,
					phone : ' '
				};
				$scope.inputCounterPhone += 1;
				$scope.inputsPhone.push($scope.inputTemplatePhone);
			}
		};

		$scope.addEmail = function() {
			if ($scope.inputCounterEmail < vm.allowedContacts) {
				vm.showAddEmail=false;
				$scope.inputTemplateEmail = {
					id : 'inputemail-' + $scope.inputCounterEmail,
					name : '',
					phone : ' ',
					email : ' '
				};
				$scope.inputCounterEmail += 1;
				$scope.inputsEmail.push($scope.inputTemplateEmail);
			}
		};

		function showError() {
			modalInstance = $uibModal.open({
				templateUrl : 'views/error_popup.html',
				scope : $scope,
				windowClass : 'registrationKey-modal'
			});
		}
	    $scope.existClose = function () {
            modalInstance.close();
	    }
		init();

		function updatePhones(deletedPhone) {
			$scope.inputCounter = 0;
			$scope.inputsPhone = [ {
				id : 'input',
				phone : '',
				phoneKey : ''
			} ];

			$scope.phones = rymcService.getAlternatePhones();
			var index = $scope.phones.indexOf(deletedPhone);
			$scope.phones.splice(index, 1);
			console.log($scope.phones.length);

			if ($scope.phones) {
				if ($scope.phones.length > 0) {
					angular.forEach($scope.phones, function(value, key) {
						$scope.inputTemplatePhone = {
							id : 'inputPhone-' + $scope.inputCounterPhone,
							phone : value.alternate_PHONE_NO,
							phoneKey : key,
							status : "",
							phoneIdentification : value.id
						};
						$scope.inputCounterPhone += 1;
						$scope.inputsPhone.push($scope.inputTemplatePhone);
					});
				}

				if ($scope.phones.length == 0)
					$scope.addPhone();
			}

		}

		function updateEmails(deletedEmail) {
			$scope.inputCounterEmail = 0;
			$scope.inputsEmail = [ {
				id : 'input',
				email : '',
				emailKey : ''
			} ];

			$scope.emails = rymcService.getAlternateEmails();
			var index = $scope.emails.indexOf(deletedEmail);
			$scope.emails.splice(index, 1);
			if ($scope.emails) {
				if ($scope.emails.length > 0) {
					angular.forEach($scope.emails, function(value, key) {
						$scope.inputTemplateEmail = {
							id : 'inputEmail-' + $scope.inputCounterEmail,
							email : value.alternate_EMAIL_ID,
							emailKey : key,
							status : "",
							emailIdentification : value.id
						};
						$scope.inputCounterEmail += 1;
						$scope.inputsEmail.push($scope.inputTemplateEmail);
					});
				}

				if ($scope.emails.length == 0)
					$scope.addEmail();
			}

		}
		/*
		 * function updatePhones(phoneObj) { $scope.phones =
		 * rymcService.getAlternateContacts().secondaryPhoneList; delete
		 * $scope.phones[phoneObj.phoneKey]; init(); } function
		 * updateEmails(emailObj) { console.log(emailObj); $scope.emails =
		 * rymcService.getAlternateContacts().secondaryEmailList; delete
		 * $scope.emails[emailObj.emailKey]; init(); }
		 */
	}
})();
