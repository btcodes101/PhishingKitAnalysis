(function() {
	'use strict';

	angular.module('rymcApp').controller('registrationCtrl', registrationCtrl);

	registrationCtrl.$inject = [ '$scope', '$window', '$state', 'rymcService',
			'$rootScope', '$uibModal', 'sessionStorage', 'ajax', '$translate' ];

	function registrationCtrl($scope, $window, $state, rymcService, $rootScope,
			$uibModal, sessionStorage, ajax, $translate) {

		var vm = this;
		vm.submit = submit;
		vm.submitTerms = submitTerms;
		vm.showPopup = showPopup;
		vm.loading = false;
		vm.gotoSignin = gotoSignin;
		var modalInstance;

		rymcService.setCurrentPage("registration");
		$rootScope.$broadcast("pageChanged");

		function submit() {

			vm.invalidKey = false;
			vm.submitted = true;
			if ($scope.RegistrationForm.$valid) {
				var request = {
					// "confirmationKey":vm.registrationKey,
					// "confirmationPassword":vm.registrationNumber
					"registrationKey" : vm.registrationKey,
					"registrationNum" : vm.registrationNumber
				}
				vm.loading = true;

				// ajax call
				ajax.validateRegistrationKey(request).success(
						function(response) {

							vm.data = response; // or whatever else.

							if (vm.data.status == "success") {
								rymcService.setRandomToken(vm.data.randomToken);
								vm.showPopup('terms');
							} else if (vm.data == "") {
								vm.loading = false;
								$scope.error = "serverError";
								$scope.errorDesc = "serverError_desc";
								showError();
								return false;
							} else if (vm.data.errorCode > 200) {
								vm.loading = false;
								$scope.error = "";
								$scope.errorDesc = "registrationErrors."
										+ vm.data.errorCode;
								showError();
								return false;
							} else {
								vm.loading = false;
								$scope.error = "createAccountFailed";
								$scope.errorDesc = "createAccountFailed_desc";
								showError();
								return false;
							}
						 }).error(function(error) {

							vm.loading = false;
							$scope.error = "serverError";
							$scope.errorDesc = "serverError_desc";
							showError();
							return false;

						})

			}
		}
		function showError() {
			modalInstance = $uibModal.open({
				templateUrl : 'views/error_popup.html',
				scope : $scope,
				windowClass : 'registrationKey-modal'
			});
		}

		function showPopup(popName) {

			$scope.pop_desc = popName;
			vm.loading = false;
			modalInstance = $uibModal.open({
				templateUrl : 'views/registrationPopup.html',
				scope : $scope,
				windowClass : 'registrationKey-modal'
			});
		}
		$scope.existClose = function() {
			modalInstance.close();
		}
		function submitTerms() {
			if (vm.chk_terms) {
				// once we have the API response
				rymcService.setLocalStorage('accountNumber',
						vm.data.accountNumber);
				rymcService.setLocalStorage('termsAccepted', "true");
				rymcService.setLocalStorage('domain', vm.data.domain);
				$state.go("addPrimaryAccount");
			} else {
				vm.showTermsError = true;
			}
		}

		function gotoSignin() {
			$state.go("signin");
		}

	}
})();
