(function() {
  'use strict';

angular.module('rymcApp').controller('dashboardCtrl', dashboardCtrl);

dashboardCtrl.$inject = ['$scope','$window','ajax','$state','$rootScope','$translate','rymcService','$uibModal','sessionStorage','settings','$cookies'];

function dashboardCtrl($scope,$window,ajax,$state,$rootScope,$translate,rymcService,$uibModal,sessionStorage,settings,$cookies) {
var vm=this;
vm.initUserAccount=initUserAccount;
vm.updateUserAccount=updateUserAccount;
vm.addAccount=addAccount;
vm.accounts=[];
$scope.submitted=false;
vm.user=rymcService.getSignedInUser();
vm.totalAccounts=settings.allowedNumberofAccounts;
vm.showAddAccount=true;
vm.showProgress=true;
vm.showPopup=showPopup;
vm.submitTerms=submitTerms;
var modalInstance;

function initUserAccount(){
if(!vm.user){
$state.go("signin");
}
else
{
            var request=vm.user;
            vm.loading=true;
            ajax.getAccountDetails(request).success(function(response) {
            if(response!="")
            {
            	if (response.stat == 'error' && response.code == '402')
            	{
            		$state.go("signin");
            	} else {
            	rymcService.setYahooMailUrl(response.yahooEmailUrl);
            	var userAccounts = response.mcCustProfileDetailsList;
            rymcService.setLocalStorage('accountNumber', userAccounts[0].account_NUMBER);
            rymcService.setUserAccounts(userAccounts);

            vm.accounts = userAccounts; //or whatever else.
            vm.progressCompletion=100/vm.totalAccounts*vm.accounts.length;

            if((vm.accounts.length==1 && vm.accounts[0] && vm.accounts[0].primary_SECONDARY_FLAG.toLowerCase()=="s") || vm.accounts.length>=9)
            {
            vm.showAddAccount=false;
            }
            if((vm.accounts.length==1 && vm.accounts[0] && vm.accounts[0].primary_SECONDARY_FLAG.toLowerCase()=="s"))
            {
            vm.showProgress=false;
            }

            vm.loading=false;
            }
            	}
            else if(response=="")
            	{
            	 $scope.error="serverError";
                 $scope.errorDesc="serverError_desc";
                 showError();
                 vm.loading=false;
                 return false;
            	}
            else
            {
               $scope.error="serverError";
               $scope.errorDesc="serverError_desc";
               showError();
               vm.loading=false;
               return false;
            }
			//findAlternateContacts();
            }).error(function(error) {
                   $scope.error="serverError";
                   $scope.errorDesc="serverError_desc";
                   showError();
                   vm.loading=false;
                   return false;
            });
            //findAlternateContacts();
}

}

vm.initUserAccount();

function updateUserAccount(deletedAccount)
{
    vm.accounts=rymcService.getUserAccounts();
    var index = vm.accounts.indexOf(deletedAccount);
    vm.accounts.splice(index, 1);
    vm.progressCompletion=100/vm.totalAccounts*vm.accounts.length;
    if(vm.accounts.length<9)
    {
    vm.showAddAccount=true;
    }
}

function findAlternateContacts()
{
       var request={'emailAddress':rymcService.getSignedInUser().email, 'accountNumber':rymcService.getLocalStorage("accountNumber")};
       ajax.getAlternateContactDetails(request).success(function(response) {
        if(response && response.status=="success")
        {
             if((!response.secondaryPhoneList || Object.keys(response.secondaryPhoneList).length==0) && (!response.secondaryEmailList ||  Object.keys(response.secondaryEmailList).length==0))
             {
             if(!sessionStorage.getSessionStorageValue("dontShowAlternateContact"))
             showPopup_alternateNumber();
             }
        }
        else{
        	 $scope.error="serverError";
             $scope.errorDesc="serverError_desc";
             showError();
             vm.loading=false;
             return false;
        }
       }).error(function(error) {
                   $scope.error="serverError";
                   $scope.errorDesc="serverError_desc";
                   showError();
                   vm.loading=false;
                   return false;
            });

}

function addAccount(){
	 vm.showPopup('terms');
}
function showPopup(popName){

	 $scope.pop_desc=popName;
	 vm.loading=false;
	    modalInstance = $uibModal.open({
	        templateUrl: 'views/registrationPopup.html',
	        scope: $scope,
	        windowClass: 'registrationKey-modal'
	    });
	}
function submitTerms()
{
    if(vm.chk_terms)
    {
        // once we have the API response
        rymcService.setLocalStorage('termsAccepted', "true")
        $state.go("addAccount");
    }
    else
    {
        vm.showTermsError=true;
    }
}
rymcService.setCurrentPage("");
rymcService.setCurrentSection("manageEmailAccounts")
$rootScope.$broadcast("pageChanged");

$scope.gotoDashboard=function(){
modalInstance.close();
$state.go('dashboard');
}
function showError(){
    modalInstance = $uibModal.open({
        templateUrl: 'views/error_popup.html',
        scope: $scope,
        windowClass: 'registrationKey-modal'
    });
}
function showPopup_alternateNumber() {
    modalInstance = $uibModal.open({
        templateUrl: 'views/alternateNumber.html',
        controller:'alternateNumberCtrl',
        scope: $scope,
        windowClass: 'alternate-modal'
    });
    modalInstance.result.then(function(response){
       //console.log('response', response);
    });
    }
    $scope.existClose = function () {
            modalInstance.close();
    }

    $scope.closeAlternateContact = function () {
            sessionStorage.setSessionStorageValue("dontShowAlternateContact",true);
            modalInstance.close();
    }


/* popover */
    $('[data-toggle="popover"]').popover({placement:'auto right'});

     $("button.navbar-toggle").click(function(){
     $(".shadow").toggleClass("in");
    });
/* popover */

}



})();
 