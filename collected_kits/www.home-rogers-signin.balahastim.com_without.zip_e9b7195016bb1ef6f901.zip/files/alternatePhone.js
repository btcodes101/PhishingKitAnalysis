'use strict';

/**
 * @ngdoc Directive
 * @name deviceModel
 * @description
 * # A directive showing one product, smartphone, basic phone or tablet.
 *  Usage: <device-model data-device='model' data-settings='settings'></device-model>
 *    'data-device': introduce an array of product (belong to same model) from outside scope.
 *    'data-settings': settings
 *
 */

angular.module('rymcApp')
  .directive('alternatePhone', alternatePhone)
  .controller('alternatePhoneCtrl', alternatePhoneCtrl);


function alternatePhone() {
  var varDirective = {
    restrict: 'E',
    scope:{
    phones:'='
    },
    templateUrl: 'js/directives/alternatePhone/alternatePhone.html',
    controller: alternatePhoneCtrl,
    controllerAs: 'vm'
  };
  return varDirective;
}
alternatePhoneCtrl.$inject = ['$scope','ajax','$uibModal','$rootScope','$translate','settings','rymcService','sessionStorage','$state','deviceDetector','$filter'];
function alternatePhoneCtrl($scope,ajax,$uibModal,$rootScope,$translate,settings,rymcService,sessionStorage,$state,deviceDetector,$filter) {
    var vm=this;
    var modalInstance;
    vm.savePhone=savePhone;
    vm.phone='';
    vm.showConfirmDelete=showConfirmDelete;
    vm.loading=false;

    if($scope.phones.phone && $scope.phones.phone!=" ")
    {
        vm.phone=$scope.phones.phone;
        $scope.saved=vm.phone;
    }

    function savePhone(){
    	var alternatePhonesList = rymcService.getAlternatePhones();
        var phoneExists= $filter('filter')(alternatePhonesList, { alternate_PHONE_NO: vm.phone });
        if(phoneExists.length>0){
    		//var index = $scope.$parent.inputsPhone.indexOf($scope.$parent.inputTemplatePhone);
    		//$scope.$parent.inputsPhone.splice(index, 1);
    		//$scope.$parent.vm.showAddPhone=true;
    		//alert('Phone number already exists.');
    		$scope.error="phoneExists";
            $scope.errorDesc="phoneExistsDesc";
            showError();
    		return false;
        }
        else
        {
    	var request  = {
        emailAddress:rymcService.getSignedInUser().email,
        secondaryPhone:vm.phone,
        accountStatus:"create",
        //accountNumber:rymcService.getSignedInUser().account_NUMBER,
        accountNumber:rymcService.getLocalStorage("accountNumber"),
        primaryFlag:"y",
        accessToken : rymcService.getSignedInUser().accessToken
        };
        vm.loading=true;
     ajax.createAlternatePhone(request).success(function(response) {

     if(response.status=="success")
     {
    	//updateAccountActivity("Added new phone number");
        $scope.saved=vm.phone;
        $scope.$parent.vm.init();
        $scope.$parent.vm.showAddPhone=true;
        vm.loading=false;
        // Recent Account Activity changes
        var accountNumber = rymcService.getLocalStorage("accountNumber");
        rymcService.updateAccountActivity(rymcService.getSignedInUser().email, rymcService.getSignedInUser().accessToken, 
        		accountNumber, 'Alternate PHONE NUMBER Created');
     }
     else
     {
            $scope.error="createAccountFailed";
            $scope.errorDesc="createAccountFailed_desc";
            showError();
            vm.loading=false;
            return false;

     }
     }).error(function(error) {
             $scope.error="serverError";
             $scope.errorDesc="serverError_desc";
             showError();
             vm.loading=false;
             return false;
     });
    }
        //ajax call save phone
    }

    $scope.existClose = function () {
       modalInstance.close();
    }

    function showConfirmDelete(popName){
        $scope.pop_desc=popName;
        modalInstance = $uibModal.open({
            templateUrl: 'views/confirm_popup.html',
            scope: $scope,
            windowClass: 'long-modal'
        });
    }

    function showError(){
        modalInstance = $uibModal.open({
            templateUrl: 'views/error_popup.html',
            scope: $scope,
            windowClass: 'registrationKey-modal'
        });
    }

$scope.deletePhone=function(){
    $scope.loading=true;

        var request  = {
        emailAddress:rymcService.getSignedInUser().email,
        secondaryPhone:$scope.phones.phone,
        accountStatus:"delete",
        //accountNumber:rymcService.getSignedInUser().account_NUMBER,
        accountNumber:rymcService.getLocalStorage("accountNumber"),
        primaryFlag:"y",
        id:$scope.phones.phoneIdentification,
        accessToken : rymcService.getSignedInUser().accessToken
        };

        ajax.deleteAlternatePhone(request).success(function(response) {

        if(response.status.toLowerCase()=="success")
        {
        	//updateAccountActivity("Deleted phone number");
        	$scope.loading=false;
            modalInstance.close();
            $scope.$parent.vm.init();
            // Recent Account Activity changes
            var accountNumber = rymcService.getLocalStorage("accountNumber");
            rymcService.updateAccountActivity(rymcService.getSignedInUser().email, rymcService.getSignedInUser().accessToken, 
            		accountNumber, 'Alternate PHONE NUMBER Deleted');
        }
        else
        {
            $scope.loading=false;
            modalInstance.close();
            $scope.error="deleteAccountFailed";
            $scope.errorDesc="deleteAccountFailed_desc";
            showError();
        }

        }).error(function(error) {
                             vm.loading = false;
                             $scope.error="serverError";
                             $scope.errorDesc="serverError_desc";
                             showError();
                             return false;
        });

}

function checkIfPhoneExists(alternatePhonesList, phone) {
	var flag = false;
	if (alternatePhonesList) {
		if (alternatePhonesList.length > 0) {
			angular.forEach(alternatePhonesList, function(value, key) {
				if(value.alternate_PHONE_NO == phone) {
					console.log("phone number already exists");
					flag = true;
				}
			});
		}
	}
	return flag;
}

}