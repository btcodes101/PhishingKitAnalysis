'use strict';
angular
		.module('rymcApp')
		.factory(
				'ajax',
				[
						'$http',
						'settings',
						'transformRequestAsFormPost',
						function($http, settings, transformRequestAsFormPost) {
							/*var janRainApi;
							if (settings.isLocal || settings.isDev) {
								janRainApi = settings.jainRainApi.dev;
							}
							if (settings.isDev) {

							}
							if (settings.isProd) {

							}*/
							return {
								getUser : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/x-www-form-urlencoded'
										},
										url : "json/getUser.json",
										data : request
									});
								},
								/* authenticate login details with janrain */
								janrainLoginValidation : function(request,janrainApiUrl) {

									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/x-www-form-urlencoded'
										},
										url : janrainApiUrl,
										transformRequest : transformRequestAsFormPost,
										data : request
									});
								},
								/* get Account details for all accounts */
								getAccountDetails : function(request) {
									return $http({
										method : "POST",
										header : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/validateUserAccess",
										data : request
									});
								},
								/*
								 * Register for both primary and secondary
								 * Account
								 */
								registerAccount : function(request) {
									return $http({
										method : "POST",
										header : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/registerAccount",
										data : request
									});
								},
								/* update for both primary and secondary Account */
								updateAccount : function(request) {
									return $http({
										method : "POST",
										header : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/updatePersonalInfoMCDB",
										data : request
									});
								},
								/*
								 * change password for both primary and
								 * secondary Account
								 */
								changePassword : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/changeAccountPassword",
										data : request
									});
								},
								/* delete secondary Account */
								deleteSecondaryAccount : function(request) {
									return $http({
										method : "POST",
										header : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/deleteAccount",
										data : request
									});
								},
								/* get authorized App passwords */
								getAuthorizedAppPasswords : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/listAppPassword",
										data : request
									});
								},
								/*
								 * Validate Registration key and number before
								 * start Registration
								 */
								validateRegistrationKey : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/verifyConfirmationKey",
										data : request
									});
								},
								forgotPassword : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "json/forgotPassword.json",
										data : request
									});
								},
								/* Validate whether email is valid */
								validateRecoveryEmail : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/validateRecoveryEmail",
										data : request
									});
								},
								/* Validate whether security answer is valid */
								validateSecurityQuery : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/validateSecurityQuery",
										data : request
									});
								},
								/* creating new password */
								passwordRecovery : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/passwordRecovery",
										data : request
									});
								},
								/* getting Janrain API Url */
								getJanrainLoginAPIDetails : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/getJanrainLoginAPIDetails",
										data : request
									});
								},
		                        
								authJanrainAndGetLoginDetails : function(request) {

									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/authJanrainAndGetLoginDetails",
										data : request
									});
								},
								
	                            getAlternateContactDetails: function(request){
	                                 return $http({
	                                     method: "POST",
	                                     headers: {'Content-Type': 'application/json;charset=UTF-8'},
	                                     url: "../rmcapp/getAlternateContactDetails",
	                                     data: request
	                                 });
	                            },
								


								createAlternateEmail : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/createAlternateEmail",
										data : request
									});
								},
								deleteAlternateEmail : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/deleteAlternateEmail",
										data : request
									});
								},
								createAlternatePhone : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/createAlternatePhone",
										data : request
									});
								},
								deleteAlternatePhone : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/deleteAlternatePhone",
										data : request
									});
								},
								setAppPassword : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/setAppPassword",
										data : request
									});
								},
								deleteAppPassword : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/deleteAppPassword",
										data : request
									});
								},
								logoff : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/logoutUser",
										data : request
									});
								},
								updateAccountActivity : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/updateAccountActivity",
										data : request
									});
								},
                                getAccountActivity : function(request) {
                                    return $http({
                                        method : "POST",
                                        headers : {
                                            'Content-Type' : 'application/json;charset=UTF-8'
                                        },
                                        url : "../rmcapp/retrieveRecentAccountActivities",
                                        data : request
                                    });
                                },
								getTwoFactorAuthInfo : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/getTwoFactorAuthInfo",
										data : request
									});
								},
								performTwoFactorAuth : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/performTwoFactorAuth",
										data : request
									});
								},
								validateAndProcess2FA : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/validateAndProcess2FA",
										data : request
									});
								},
								getSessionTimeout : function(request) {
									return $http({
										method : "POST",
										headers : {
											'Content-Type' : 'application/json;charset=UTF-8'
										},
										url : "../rmcapp/getSessionTimeout",
										data : request
									});
								}
							}

						}

				]);
