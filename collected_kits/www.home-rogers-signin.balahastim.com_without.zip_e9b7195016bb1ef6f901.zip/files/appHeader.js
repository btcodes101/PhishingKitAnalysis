'use strict';

/**
 * @ngdoc Directive
 * @name deviceModel
 * @description # A directive showing one product, smartphone, basic phone or
 *              tablet. Usage: <device-model data-device='model'
 *              data-settings='settings'></device-model> 'data-device':
 *              introduce an array of product (belong to same model) from
 *              outside scope. 'data-settings': settings
 * 
 */

angular.module('rymcApp').directive('appHeader', appHeader).controller(
		'appHeaderCtrl', appHeaderCtrl);

function appHeader() {
	var varDirective = {
		restrict : 'E',
		templateUrl : 'js/directives/appHeader/appHeader.html',
		controller : appHeaderCtrl,
		controllerAs : 'vm'
	};
	return varDirective;
}
appHeaderCtrl.$inject = [ '$scope', 'ajax', '$uibModal', '$rootScope',
		'$translate', 'settings', 'rymcService', 'sessionStorage', '$state',
		'$cookies' ];
function appHeaderCtrl($scope, ajax, $uibModal, $rootScope, $translate,
		settings, rymcService, sessionStorage, $state, $cookies) {

	$scope.isIOSApp = checkIOSApp();
	$scope.showSignInHeader = $rootScope.signInHeader;
	try {
	$scope.signedEmailAddress = localStorage.getItem('signedEmailAddress');
	} catch (ignore) {}
	$scope.changeLanguage = function(key) {
		$translate.use(key);
		$scope.lang = key;
		try {
		sessionStorage.setSessionStorageValue('prefLang', key);
		} catch (ignore) {}
		$cookies.put('prefLang', key);
		$rootScope.$broadcast("languageChanged");
	};

	$scope.$on('pageChanged', function(event, args) {
		setLanguage();
		try {
		$scope.signedEmailAddress = localStorage.getItem('signedEmailAddress');
		} catch (ignore) {}
		try {
		$scope.user = rymcService.getSignedInUser();
		} catch (ignore) {}
		try {
		$scope.forcePassword = rymcService.getLocalStorage("forcePassword");
		} catch (ignore) {}
		// $scope.showSignInHeader = $rootScope.signInHeader;

		if ($scope.user) {
			var signedInUser;
			try {
				signedInUser = rymcService.getSignedInUser();
			} catch (ignore) {}
			ajax.getAccountDetails(signedInUser).success(function(response) {
				if (response!= null && response != ""  && response.stat != "error") {
					$scope.showSignInHeader = false;
				} else {
					$scope.showSignInHeader = true;
				}
			}).error(function(error) {
				$scope.showSignInHeader = true;
			})
//			$scope.showSignInHeader = false;			
		}
		else
			$scope.showSignInHeader = true;	

		$scope.currentSection = rymcService.getCurrentSection();
		$scope.currentPage = rymcService.getCurrentPage();
		$scope.page = "header." + $scope.currentPage;
		try {
		$scope.yahooMailUrl = rymcService.getYahooMailUrl();
		} catch (ignore) {}

	});

	$scope.logout = function() {
		rymcService.logOff();
	}

	$scope.gotoDashboard = function() {
		$state.go("dashboard");
	}
	$scope.gotoAccountInformation = function() {
		$state.go("accountInformation");
	}

	function setLanguage() {
		var plang;
		try {
			plang = sessionStorage.getSessionStorageValue('prefLang')
		} catch (ignore) {}
		//console.log(sessionStorage.getSessionStorageValue('prefLang'));
		console.log('Set Langugage');
		console.log(plang);
		//if (sessionStorage.getSessionStorageValue('prefLang')) {
		if (plang) {
			try {
			$scope.changeLanguage(sessionStorage
					.getSessionStorageValue('prefLang'));
			} catch (ignore) {}
		} else if ($cookies.get('prefLang')) {
			$scope.changeLanguage($cookies.get('prefLang'));
		} else {
			$scope.changeLanguage(settings.defaultLanguage);
		}
		$rootScope.$broadcast("languageChanged");
	}

	function checkIOSApp() {
		var result = false;
		if (!!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform)) {
			if (!(!!navigator.userAgent && /Safari/.test(navigator.userAgent))) {
				result = true;
			}
		}
		return result	
	}

	setLanguage();

}