'use strict';

/**
 * @ngdoc Directive
 * @name deviceModel
 * @description
 * # A directive showing one product, smartphone, basic phone or tablet.
 *  Usage: <device-model data-device='model' data-settings='settings'></device-model>
 *    'data-device': introduce an array of product (belong to same model) from outside scope.
 *    'data-settings': settings
 *
 */

angular.module('rymcApp')
  .directive('alternateEmail', alternateEmail)
  .controller('alternateEmailCtrl', alternateEmailCtrl);


function alternateEmail() {
  var varDirective = {
    restrict: 'E',
    scope:{
    emails:'='
    },
    templateUrl: 'js/directives/alternateEmail/alternateEmail.html',
    controller: alternateEmailCtrl,
    controllerAs: 'vm'
  };
  return varDirective;
}
alternateEmailCtrl.$inject = ['$scope','ajax','$uibModal','$rootScope','$translate','settings','rymcService','sessionStorage','$state','deviceDetector','$filter'];
function alternateEmailCtrl($scope,ajax,$uibModal,$rootScope,$translate,settings,rymcService,sessionStorage,$state,deviceDetector,$filter) {
    var vm=this;
    var modalInstance;
    vm.saveEmail=saveEmail;
    vm.phone='';
    vm.showConfirmDelete=showConfirmDelete;
    vm.loading=false;
    $scope.error='';
    $scope.errorDesc='';
    if($scope.emails.email && $scope.emails.email!=" ")
    {
        vm.email=$scope.emails.email;
        $scope.saved=vm.email;
    }

    function saveEmail(){
		       var alternateEmailsList = rymcService.getAlternateEmails();
		       		    		//alert('Email address already exists.');

                var emailExists= $filter('filter')(alternateEmailsList, { alternate_EMAIL_ID: vm.email });
                if(emailExists.length>0)
                {
                    $scope.error="emailExists";
                    $scope.errorDesc="emailExistsDesc";
                    showError();
                    return false;
                }
		       else
		       {
               var request  = {
            	  emailAddress:rymcService.getSignedInUser().email,
                  secondaryEmail:vm.email,
                  accountStatus:"create",
                  //accountNumber:rymcService.getSignedInUser().account_NUMBER,
                  accountNumber:rymcService.getLocalStorage("accountNumber"),
                  primaryFlag:"y",
                  accessToken : rymcService.getSignedInUser().accessToken
                  };
               vm.loading=true;
               ajax.createAlternateEmail(request).success(function(response) {

               if(response.status=="success")
               {
            	  //updateAccountActivity("Added new email");
                  $scope.saved=vm.email;
                  $scope.$parent.vm.init();
                  $scope.$parent.vm.showAddEmail=true;
                  vm.loading=false;
                  // Recent Account Activity changes
                  var accountNumber = rymcService.getLocalStorage("accountNumber");
                  rymcService.updateAccountActivity(rymcService.getSignedInUser().email, rymcService.getSignedInUser().accessToken, 
                  		accountNumber, 'Alternate EMAIL Created');
               }
               else
               {
                      $scope.error="createAccountFailed";
                      $scope.errorDesc="createAccountFailed_desc";
                      showError();
                      vm.loading=false;
                      return false;

               }
               }).error(function(error) {
                       $scope.error="serverError";
                       $scope.errorDesc="serverError_desc";
                       showError();
                       vm.loading=false;
                       return false;
               });
            }
    }

    $scope.existClose = function () {
       modalInstance.close();
    }

    function showConfirmDelete(popName){
        $scope.pop_desc=popName;
        modalInstance = $uibModal.open({
            templateUrl: 'views/confirm_popup.html',
            scope: $scope,
            windowClass: 'long-modal'
        });
    }


        function showError(){
            modalInstance = $uibModal.open({
                templateUrl: 'views/error_popup.html',
                scope: $scope,
                windowClass: 'registrationKey-modal'
            });
        }

    $scope.deleteEmail=function(){
    console.log("delete email");
    $scope.loading=true;

        var request  = {
        emailAddress:rymcService.getSignedInUser().email,
        secondaryEmail:vm.email,
        accountStatus:"delete",
        //accountNumber:rymcService.getSignedInUser().account_NUMBER,
        accountNumber:rymcService.getLocalStorage("accountNumber"),
        primaryFlag:"y",
        id:$scope.emails.emailIdentification,
        accessToken : rymcService.getSignedInUser().accessToken
        };

        ajax.deleteAlternateEmail(request).success(function(response) {

        if(response.status.toLowerCase()=="success")
        {
        	//updateAccountActivity("Deleted Email");
            modalInstance.close();
            $scope.$parent.vm.init();
            // Recent Account Activity changes
            var accountNumber = rymcService.getLocalStorage("accountNumber");
            rymcService.updateAccountActivity(rymcService.getSignedInUser().email, rymcService.getSignedInUser().accessToken, 
            		accountNumber, 'Alternate EMAIL Deleted');
        }
        else
        {
            $scope.loading=false;
            modalInstance.close();
            $scope.error="deleteAccountFailed";
            $scope.errorDesc="deleteAccountFailed_desc";
            showError();
        }

        }).error(function(error) {
                             vm.loading = false;
                             $scope.error="serverError";
                             $scope.errorDesc="serverError_desc";
                             showError();
                             return false;
        });

}
    function checkIfEmailExists(alternateEmailsList, email) {
    	var flag = false;
    	if (alternateEmailsList) {
    		if (alternateEmailsList.length > 0) {
    			angular.forEach(alternateEmailsList, function(value, key) {
    				if(value.alternate_EMAIL_ID == email) {
    					console.log("email already exists");
    					$scope.error="emailExists";
    					alert('hello');
                        $scope.errorDesc="emailExistsDesc";
                        showError();
    					flag = true;
    				}
    			});
    		}
    	}
    	return flag;
    }
}