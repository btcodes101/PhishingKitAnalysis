(function() {
	'use strict';

	angular.module('rymcApp').controller('signinCtrl', signinCtrl);

	signinCtrl.$inject = [ '$scope', '$window', 'ajax', '$state', '$rootScope',
			'$translate', 'rymcService', 'sessionStorage', 'settings',
			'$cookies', '$location', '$uibModal', 'deviceDetector' ];

	function signinCtrl($scope, $window, ajax, $state, $rootScope, $translate,
			rymcService, sessionStorage, settings, $cookies, $location,
			$uibModal, deviceDetector) {
		var vm = this;
		vm.loading = false;
		vm.submit = submit;
		vm.userCookie = null;
		vm.gotoForgotPassword = gotoForgotPassword;
		vm.checkForcePassword = checkForcePassword;
		vm.rejectYahooUser = rejectYahooUser;
		rymcService.setCurrentPage("signIn");
		$rootScope.$broadcast("pageChanged");
		vm.changePasswordFlag = false;
		vm.validateEmail = validateEmail;
		vm.enablebutton = enablebutton;
		vm.emailValidated = false;
		vm.isMobileApp = false;
		vm.showSignin = true;
		vm.enterotp = false;
		vm.verifyOTP = verifyOTP;
		vm.sendSMS = sendSMS;
		vm.resendFlag = false;
		var authUserDetails = null;
		var modalInstance;

		function submit() {
			// Set the 'submitted' flag to true
			vm.invalidUser = false;
			vm.submitted = true;

			if (vm.userFromYahoo) {
				vm.signInEmailAddress = vm.userFromYahoo.userId;
			}
			vm.loading = true;

			var janrainAuthRequest = {
				"email" : vm.signInEmailAddress.toLowerCase(),
				"password" : vm.currentPassword
			}

			ajax.authJanrainAndGetLoginDetails(janrainAuthRequest).success(
					function(result) {
						if (result && result.stat == "ok") {
							if (result.redirectYahoo) {
								setUserInfoForSAML(result);
								handleYahooRedirect(result);
								// $window.location.href = result.redirectYahoo;
							} else {
								populateUserInfoDetails(result);
							}
						} else {
							vm.loading = false;
							if (result.code > 200) {
								vm.invalidUser = true;
								vm.errorMsg = "signin." + result.code;
								return false;
							} else {
								$scope.error = "serverError";
								$scope.errorDesc = "serverError_desc";
								showError();
								return false;
							}
						}

					}).error(function(error) {
				vm.loading = false;
				$scope.error = "serverError";
				$scope.errorDesc = "serverError_desc";
				showError();
				return false;
			})

		}

		function setUserInfoForSAML(result) {
			if (result.stat == "ok") {
				if (vm.userFromYahoo) {
					var userDetails = {
						"accessToken" : result.access_token,
						"email" : result.yahooEmail,
						"flow" : vm.userFromYahoo.flow
					}
				} else {
					var userDetails = {
						"accessToken" : result.access_token,
						"email" : result.yahooEmail
					}
				}
				var today = new Date();
				var expiresValue = new Date(today);
				expiresValue.setMinutes(today.getMinutes() + 60);
				try {
				sessionStorage.setSessionStorageObject('signedInUser',
						userDetails);
				} catch (ignore) {} 
				$cookies.putObject('signedInUser', userDetails, {
					'expires' : expiresValue
				});
				try {
				localStorage.setItem('signedEmailAddress', result.yahooEmail);
				} catch (ignore) {}
				if (vm.rememberMe) {
					$cookies.put('username', vm.signInEmailAddress
							.toLowerCase());
				}

				if (vm.userCookie && !vm.rememberMe) {
					$cookies.remove("username");
				}
				try {
				rymcService.setYahooMailUrl(result.yahooEmailUrl);
				} catch (ignore) {}
			}
		}

		function validateEmail() {

			if (vm.signInEmailAddress) {

				var email = vm.signInEmailAddress;
				email = email.toLowerCase();

				if (email.indexOf("rogers.com") > 1) {
					vm.emailValidated = true;
				} else {
					vm.emailValidated = false;
				}
			}
		}

		function enablebutton() {
			var password = vm.currentPassword;
			if (password.length > 1) {
				vm.emailValidated = true;
			} else {
				vm.emailValidated = false;
			}
		}

		function showError() {
			modalInstance = $uibModal.open({
				templateUrl : 'views/error_popup.html',
				scope : $scope,
				windowClass : 'registrationKey-modal'
			});
		}
		$scope.existClose = function() {
			modalInstance.close();
		}

		function rejectYahooUser() {
			vm.userFromYahoo = "";
		}
		function checkForcePassword(userDetails) {

			var request = userDetails;

			ajax
					.getAccountDetails(request)
					.success(
							function(response) {
								rymcService
										.setYahooMailUrl(response.yahooEmailUrl);
								rymcService
										.setPrimaryEmail(response.primaryEmail);
								var userAccounts = response.mcCustProfileDetailsList;
								if (!vm.userFromYahoo)
									rymcService.setUserAccounts(userAccounts); // save
								// accounts
								// in
								// service

								if (userAccounts) {
									var today = new Date();
									var expiresValue = new Date(today);
									expiresValue
											.setMinutes(today.getMinutes() + 60);
									sessionStorage.setSessionStorageObject(
											'signedInUser', userDetails);
									$cookies.putObject('signedInUser',
											userDetails, {
												'expires' : expiresValue
											});
									if (vm.rememberMe) {
										$cookies.put('username',
												vm.signInEmailAddress
														.toLowerCase());
									}

									if (vm.userCookie && !vm.rememberMe) {
										$cookies.remove("username");
									}

									for (var i = 0; i < userAccounts.length; i++) {
										if (request.email == userAccounts[i].accountid) {
											sessionStorage
													.setSessionStorageValue(
															'prefLang',
															userAccounts[i].preferred_LANGUAGE
																	.toLowerCase());
											$cookies
													.put(
															'prefLang',
															userAccounts[i].preferred_LANGUAGE
																	.toLowerCase());
											if (userAccounts[i].forcePasswordChange == "Y") {
												rymcService.setLocalStorage(
														"forcePassword", true);
												// $state.go("changePassword");
												vm.changePasswordFlag = true;
											}
										}
									}
									// updateAccountActivity();
									// Recent Account Activity changes
									rymcService.updateAccountActivity(
											request.email, request.accessToken,
											'', 'Login');
									if (vm.changePasswordFlag
											|| $rootScope.basePath == 'changePassword') {
										$rootScope.basePath = '';
										$state.go("changePassword");
									} else {
										$state.go('dashboard');
									}
								} else {
									// Invalid user or userAccounts is null
									vm.loading = false;
									if (response.code > 200) {
										vm.invalidUser = true;
										vm.errorMsg = "signin." + response.code;
										return false;
									} else {
										$scope.error = "serverError";
										$scope.errorDesc = "serverError_desc";
										showError();
										return false;
									}
								}
							}).error(function(error) {
						vm.loading = false;
						$scope.error = "serverError";
						$scope.errorDesc = "serverError_desc";
						showError();
						return false;
					});

		}

		function gotoForgotPassword() {
			$state.go("forgotPassword");
		}

		function init() {
			if ($location.search().userId && $location.search().userId != ""
					&& $location.search().flow && $location.search().flow != "")
				vm.userFromYahoo = $location.search();
			if ($cookies.get('username')) {
				vm.userCookie = $cookies.get('username');
				vm.signInEmailAddress = vm.userCookie;
			}
			vm.validateEmail();
			
			try {
				localStorage.setItem("testxxx","testxxx");
				localStorage.getItem("testxxx");
				sessionStorage.setSessionStorageObject("testxxx","testxxx");
				vm.isMobileApp = false;
			} catch (ignore) {
				vm.isMobileApp = true;
			} 
		}

		function populateUserInfoDetails(result) {

			if (result.stat == "ok") {
				if (vm.userFromYahoo) {
					var userDetails = {
						"accessToken" : result.access_token,
						// "displayName":result.capture_user.displayName,
						"email" : result.capture_user.email,
						"flow" : vm.userFromYahoo.flow
					}
				} else {
					var userDetails = {
						"accessToken" : result.access_token,
						// "displayName":result.capture_user.displayName,
						"email" : result.capture_user.email
					}
				}
				localStorage.setItem('signedEmailAddress',
						result.capture_user.email);
				// 2FA Auth login : start
				/*
				 * var authRequest = { 'emailAddress' : userDetails.email,
				 * 'accessToken' : userDetails.accessToken };
				 * ajax.getTwoFactorAuthInfo(authRequest).success(function(result) {
				 * if (result && result.status == "success") { // Already
				 * registered for 2FA if(result.phone_NUMBER &&
				 * result.twoFactorAuthFlag && result.twoFactorAuthFlag == 'Y') {
				 * console.log('User is registered for 2FA'); vm.showSignin =
				 * false; authUserDetails = { 'emailAddress' :
				 * userDetails.email, 'accessToken' : userDetails.accessToken,
				 * 'phoneNumber' : result.phone_NUMBER }; sendSMS(); } else {
				 * console.log('User is not registered for 2FA');
				 * checkForcePassword(userDetails); } } else { console.log('User
				 * is not registered for 2FA'); checkForcePassword(userDetails); }
				 * }).error(function(error) { checkForcePassword(userDetails);
				 * });
				 */
				// 2FA Auth login : end
				checkForcePassword(userDetails);
				// $state.go('dashboard');
			} else {
				vm.loading = false;
				if (result == "") {
					$scope.error = "serverError";
					$scope.errorDesc = "serverError_desc";
					showError();
					return false;
				} else {
					vm.invalidUser = true;
					vm.errorMsg = "signin." + result.code;
					return false;
				}
			}
		}

		function issuePostRedirect(url, samlResponse, relayState) {
			// build the form
			var form = document.createElement("form");

			form.action = url;
			form.method = "post";

			var createHidden = (function() {
				return function(fn, key, value) {
					var tn = document.createElement("input");
					tn.name = key;
					tn.type = "hidden";
					fn.appendChild(tn);
					tn.value = value;
				};
			})();

			createHidden(form, "SAMLResponse", samlResponse);
			createHidden(form, "RelayState", relayState);

			// Firefox won't submit the form unless it is part of the DOM...
			form.style.position = 'absolute';
			form.style.visibility = 'hidden';
			form.style.height = '0px';
			form.style.width = '0px';
			document.body.appendChild(form);

			// send it
			form.submit();
		}

		// Function to redirect back to Yahoo when SSO initiated from Yahoo
		// portal
		function handleYahooRedirect(result) {

			var url = result.redirectYahoo;
			var samlResponse = result.SAMLResponse;
			var relayState = result.RelayState;

			issuePostRedirect(url, samlResponse, relayState);

			return true;
		}

		function sendSMS() {
			var request = {
				emailAddress : authUserDetails.emailAddress,
				phoneNumber : authUserDetails.phoneNumber,
				accessToken : authUserDetails.accessToken
			}
			vm.loading = true;
			ajax.performTwoFactorAuth(request).success(function(response) {
				vm.loading = false;
				if (response && response.status == 'success') {
					$cookies.remove('otpExpiry');
					vm.resendFlag = false;
					vm.enterotp = true;
					setOTPExpiryValue(2); // Timeout 2 minutes
				} else {
					vm.loading = false;
					$scope.error = "phoneNumberError";
					$scope.errorDesc = "phoneNumberError_desc";
					showError();
					return false;
				}
			}).error(function(error) {
				vm.loading = false;
				$scope.error = "serverError";
				$scope.errorDesc = "serverError_desc";
				showError();
				return false;
			});
		}

		function verifyOTP() {
			var request = {
				emailAddress : authUserDetails.emailAddress,
				phoneNumber : authUserDetails.phoneNumber,
				accessToken : authUserDetails.accessToken,
				secretCode : vm.otp
			}
			if ($cookies.get('otpExpiry')) {
				vm.loading = true;
				ajax.validateAndProcess2FA(request).success(function(response) {
					vm.loading = false;
					if (response && response.status == 'success') {
						vm.enterotp = false;
						vm.showSignin = true;
						vm.otp = '';
						var userDetails = {
							'email' : authUserDetails.emailAddress,
							'accessToken' : authUserDetails.accessToken
						};
						checkForcePassword(userDetails);
					} else {
						vm.loading = false;
						vm.otp = '';
						$scope.error = "otpError";
						$scope.errorDesc = "otpError_desc";
						showError();
						return false;
					}
				}).error(function(error) {
					vm.loading = false;
					$scope.error = "serverError";
					$scope.errorDesc = "serverError_desc";
					showError();
					return false;
				});
			} else {
				// OTP Expired
				console.log('OTP is expired for 2FA');
				vm.loading = false;
				vm.otp = '';
				$scope.error = "Invalid OTP";
				$scope.errorDesc = "Your OTP is expired";
				showError();
				vm.resendFlag = true;
				return false;
			}
		}

		function setOTPExpiryValue(timeout) {
			var today = new Date();
			var expiresValue = new Date(today);
			expiresValue.setMinutes(today.getMinutes() + timeout);
			$cookies.put('otpExpiry', 'OTP', {
				'expires' : expiresValue
			});
		}
		
		init();
	}
})();
