'use strict';

angular
  .module('rymcApp')
  .factory('sessionStorage', ['$window',
    function ($window) {
      var sessionStorage = {};

      // Read
      sessionStorage.getSessionStorageValue = function (key) {
        return $window.sessionStorage.getItem(key);
      };
      sessionStorage.getSessionStorageObject = function (key) {
        var valueString = $window.sessionStorage.getItem(key);
        var valueObject = angular.fromJson(valueString);
        return valueObject;
      };

      // Write
      sessionStorage.setSessionStorageValue = function (key, val) {
        $window.sessionStorage.setItem(key, val);
      };
      sessionStorage.setSessionStorageObject = function (key, val) {
        var valueString = angular.toJson(val);
        $window.sessionStorage.setItem(key, valueString);
      };

      // Delete
      sessionStorage.deleteSessionStorageValue = function (key) {
        $window.sessionStorage.removeItem(key);
      };
      sessionStorage.deleteSessionStorageObject = function (key) {
        this.deleteSessionStorageValue(key);
      };

      // Clear all
      sessionStorage.clearAllSessionStorageValues = function () {
        // console.log('inside clearalllocalstorage');
        while ($window.sessionStorage.length > 0) {
          $window.sessionStorage.removeItem($window.sessionStorage.key(0));
        }
      };

      // Clear all except those mentioned in the array
      sessionStorage.clearAllSessionStorageValuesExcept = function (theseArr) {
        while ($window.sessionStorage.length > 0) {
          var keyIndex = theseArr.indexOf($window.sessionStorage.key(0));
          if (keyIndex >= 0){
            // found it -> skipping this one
          } else {
            $window.sessionStorage.removeItem($window.sessionStorage.key(0));
          }
        }
      };

      return sessionStorage;
    }
  ]);
