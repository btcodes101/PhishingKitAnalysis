(function() {
  'use strict';

angular.module('rymcApp').controller('notifyChangePasswordCtrl', notifyChangePasswordCtrl);

notifyChangePasswordCtrl.$inject = ['$scope','$window','$state','rymcService','$rootScope','ajax','sessionStorage','$uibModal'];

function notifyChangePasswordCtrl($scope,$window,$state,rymcService,$rootScope,ajax,sessionStorage,$uibModal) {

var vm=this;
rymcService.setCurrentPage("changePassword");
$rootScope.$broadcast("pageChanged");







}
})();
 