'use strict';

/**
 * @ngdoc overview
 * @name portalApp
 * @description
 * # portalApp
 *
 * Main module of the application.
 */
angular
  .module('rymcApp', ['ui.router','ui.bootstrap','pascalprecht.translate','ngIdle','ngclipboard','ngCookies','rorymadden.date-dropdowns','ng.deviceDetector']);

