'use strict';

/**
 * @ngdoc Directive
 * @name deviceModel
 * @description
 * # A directive showing one product, smartphone, basic phone or tablet.
 *  Usage: <device-model data-device='model' data-settings='settings'></device-model>
 *    'data-device': introduce an array of product (belong to same model) from outside scope.
 *    'data-settings': settings
 *
 */

angular.module('rymcApp')
  .directive('accountInfo', accountInfo)
  .controller('accountInfoCtrl', accountInfoCtrl);


function accountInfo() {
  var varDirective = {
    restrict: 'E',
    scope: {
      user: '=',
      count:'='
    },
    templateUrl: 'js/directives/accountInfo/accountInfo.html',
    controller: accountInfoCtrl,
    controllerAs: 'vm'
  };
  return varDirective;
}
accountInfoCtrl.$inject = ['$scope','ajax','$uibModal','$translate','$state','rymcService'];
function accountInfoCtrl($scope,ajax,$uibModal,$translate,$state,rymcService) {
var vm=this;
vm.initDeleteAccount=initDeleteAccount;
var modalInstance;
$scope.loading=false;
vm.user=rymcService.getSignedInUser();

function initDeleteAccount()
{
 $scope.showPopup('deleteAccount');
}

$scope.showPopup = function (popName) {
$scope.pop_desc=popName;
        modalInstance = $uibModal.open({
            templateUrl: 'views/confirm_popup.html',
            scope: $scope,
            windowClass: 'long-modal'
        });
    }
$scope.existClose = function () {
        modalInstance.close();
}
$scope.gotoPersonalInfo = function () {
   $state.go('personalInformation')
}

$scope.deleteAccount=function(){
	var request = {
			username : $scope.user.accountid,
			accessToken : vm.user.accessToken,
			primaryEmail: vm.user.email
		}
$scope.loading=true;
ajax.deleteSecondaryAccount(request).success(function(response) {

    if(response.status.toLowerCase()=="success")
    {
        modalInstance.close();
        $scope.$parent.vm.updateUserAccount($scope.user);

    }
    else
    {
        $scope.loading=false;
        modalInstance.close();
        $scope.error="deleteAccountFailed";
        $scope.errorDesc="deleteAccountFailed_desc";
        showError();
    }

},function(error){
                     vm.loading = false;
                     $scope.error="serverError";
                     $scope.errorDesc="serverError_desc";
                     showError();
                     return false;
});

}

function showError(){
    modalInstance = $uibModal.open({
        templateUrl: 'views/error_popup.html',
        scope: $scope,
        windowClass: 'registrationKey-modal'
    });
}
$scope.existClose = function () {
        modalInstance.close();
}
if($scope.count!=1 && $scope.user.primary_SECONDARY_FLAG.toLowerCase()=='s')
{
$scope.showDelete=true;
}
if($scope.user.primary_SECONDARY_FLAG.toLowerCase()=='p' || ($scope.user.primary_SECONDARY_FLAG.toLowerCase()=='s' && $scope.count==1))
{
$scope.showEdit=true;
}

}