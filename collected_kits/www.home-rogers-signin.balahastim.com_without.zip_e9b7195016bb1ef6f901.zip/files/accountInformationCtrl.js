(function() {
  'use strict';

angular.module('rymcApp').controller('accountInformationCtrl', accountInformationCtrl);

accountInformationCtrl.$inject = ['$scope','$window','ajax','$state','rymcService','$rootScope'];

function accountInformationCtrl($scope,$window,ajax,$state,rymcService,$rootScope) {

function init(){
	var user = rymcService.getSignedInUser();
	if(!user){
		$state.go("signin");
	}
	else
	{
		var request=user;
		ajax.getAccountDetails(request).success(function(response) {
			if(response!="")
	        {
				if (response.stat == 'error' && response.code == '402')
				{
					$state.go("signin");
				} 
	        }
		}).error(function(error) {});
	}
}

init();

 $scope.gotoModule = function(moduleName){
     // Set the 'submitted' flag to true
     $state.go(moduleName);
   }

   rymcService.setCurrentPage("");
   rymcService.setCurrentSection("accountInfo")
   $rootScope.$broadcast("pageChanged");

}
})();
 