(function() {
	'use strict';

	angular.module('rymcApp').controller('authorizedApplicationsCtrl',
			authorizedApplicationsCtrl);

	authorizedApplicationsCtrl.$inject = [ '$scope', '$window', '$state',
			'$uibModal', 'ajax', 'sessionStorage', 'rymcService', '$rootScope' ];

	function authorizedApplicationsCtrl($scope, $window, $state, $uibModal,
		ajax, sessionStorage, rymcService, $rootScope) {
		var vm = this;
		var request = "vinayak.sharma@gmail.com";
		vm.passWordName = null;
		vm.init=init;
		vm.initfromService=initfromService;
		vm.user=rymcService.getSignedInUser();
		rymcService.setCurrentPage("");
		rymcService.setCurrentSection("accountInfo");
		$rootScope.$broadcast("pageChanged");
		var modalInstance;

		function init(){
		vm.showAddAnother=true;
		$scope.inputCounter = 0;
		$scope.inputs = [ {
			id : 'input',
			name : '',
			passwordName : null
		} ];
		var request = {
			emailAddress : vm.user.email,
			accessToken : vm.user.accessToken
		}
		vm.loading=true;
		ajax.getAuthorizedAppPasswords(request).success(function(result) {
			vm.loading=false;
			rymcService.setAuthorizedPasswords(result.lstAppPasswordList);
			if (result && result.lstAppPasswordList) {

				$scope.result = result.lstAppPasswordList; // or whatever else.
				if($scope.result.length==0)
				{
				$scope.add();
				}
				// console.log($scope.result.length);
				// passwordName=result.passwordName
				if($scope.result.length>0){
				angular.forEach($scope.result, function(value, key) {
					$scope.inputTemplate = {
						id : 'input-' + $scope.inputCounter,
						name : '',
						passwordName : value
					};
					$scope.inputCounter += 1;
					$scope.inputs.push($scope.inputTemplate);
				});
				}
			} else if (result && result.status == 'error') {
				$state.go("signin");
			} else {
				$scope.inputs = [ {
					id : 'input',
					name : '',
					passwordName : ' '
				} ];
				vm.loading=false;
			}

		}).error(function(error) {
			 vm.loading = false;
             $scope.error="serverError";
             $scope.errorDesc="serverError_desc";
             showError();
             return false;
		})
		}
init();
		$scope.add = function() {
			vm.showAddAnother=false;
			$scope.inputTemplate = {
				id : 'input-' + $scope.inputCounter,
				name : '',
				passwordName : ' '
			};
			$scope.inputCounter += 1;
			$scope.inputs.push($scope.inputTemplate);
		};
		
		   function showError(){
	            modalInstance = $uibModal.open({
	                templateUrl: 'views/error_popup.html',
	                scope: $scope,
	                windowClass: 'registrationKey-modal'
	            });
	        }
	        $scope.existClose = function () {
	                modalInstance.close();
	        }
		function initfromService(deletedPassword)
		{

		$scope.inputCounter = 0;
        $scope.inputs = [ {
            id : 'input',
            name : '',
            passwordName : null
        } ];

		$scope.passwords=rymcService.getAuthorizedPasswords();
        var index = $scope.passwords.indexOf(deletedPassword);
        $scope.passwords.splice(index, 1);
		if($scope.passwords)
		{

            if($scope.passwords.length>0){
            // console.log($scope.result.length);
            // passwordName=result.passwordName
            angular.forEach($scope.passwords, function(value, key) {
                $scope.inputTemplate = {
                    id : 'input-' + $scope.inputCounter,
                    name : '',
                    passwordName : value
                };
                $scope.inputCounter += 1;
                $scope.inputs.push($scope.inputTemplate);
            });
            }
            
            if($scope.passwords.length==0)
            {
       				$scope.inputs = [ {
       					id : 'input',
       					name : '',
       					passwordName : ' '
       				} ];
            }

		}
		}
		
	}
})();
