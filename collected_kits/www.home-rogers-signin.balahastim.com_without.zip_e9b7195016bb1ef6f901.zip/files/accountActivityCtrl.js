(function() {
  'use strict';

angular.module('rymcApp').controller('accountActivityCtrl', accountActivityCtrl);

accountActivityCtrl.$inject = ['$scope','$window','$state','$uibModal','ajax','sessionStorage','rymcService','$rootScope'];

function accountActivityCtrl($scope,$window,$state,$uibModal,ajax,sessionStorage,rymcService,$rootScope) {
var vm=this;
vm.user=rymcService.getSignedInUser();
vm.recentActivities=[];
rymcService.setCurrentPage("");
rymcService.setCurrentSection("accountInfo");
$rootScope.$broadcast("pageChanged");

        var request = {
                 emailAddress:vm.user.email,
				 accessToken: vm.user.accessToken
		 }
     ajax.getAccountActivity(request).success(function(response) {

        if(response)
        {
        	if (response.status && response.status.toLowerCase()=='failure') {
        		$state.go("signin");
        	} else {
          vm.recentActivities=response;
        	}
        }
       /*else if(response.status.toLowerCase()=='failure')
       {
            $scope.error="serverError";
            $scope.errorDesc=response.errorDesc;
            showError();
            vm.loading=false;
            return false;

       }*/
       }).error(function(error) {
             $scope.error="serverError";
             $scope.errorDesc="serverError_desc";
             showError();
             vm.loading=false;
             return false;
         });

    $scope.existClose = function () {
        modalInstance.close();
     }
        function showError(){
            modalInstance = $uibModal.open({
                templateUrl: 'views/error_popup.html',
                scope: $scope,
                windowClass: 'registrationKey-modal'
            });
        }

 $scope.gotoModule = function(moduleName){
     // Set the 'submitted' flag to true
     $state.go(moduleName);
   }
}
})();
 