(function() {
  'use strict';

angular.module('rymcApp').controller('personalInformationCtrl', personalInformationCtrl);

personalInformationCtrl.$inject = ['$scope','$window','$state','ajax','rymcService','sessionStorage','$rootScope','$uibModal','$cookies'];

function personalInformationCtrl($scope,$window,$state,ajax,rymcService,sessionStorage,$rootScope,$uibModal,$cookies) {

var vm=this;
var modalInstance;
vm.submit=submit;
vm.submitted=false;
vm.passwordPattern=/^((?=.*[A-Za-z])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[a-zA-Z]))|((?=.*[A-Z])(?=.*[a-z]))[A-Za-z\d-!@#$%*]{7,32}$/;
//vm.postalCodePattern=/^(\d{5}(-\d{4})?|[A-Za-z]\d[A-Za-z] *\d[A-Za-z]\d)$/;
vm.usernamePattern=/^[a-z](-(?!(\.|-|_))|_(?!(\.|_|-))|\.(?!(_|\.|-))|[a-z0-9]){1,32}[a-z0-9-_]$/;
vm.namePattern=/^([a-zA-Z\u00C0-\u00FF-'](?!_))+$/;
vm.init=init;
rymcService.setCurrentPage("");
rymcService.setCurrentSection("accountInfo");
$rootScope.$broadcast("pageChanged");
vm.user=rymcService.getSignedInUser();
vm.loading = false;
function init()
{
               var request = {
               				 email: vm.user.email,
               				 accessToken : vm.user.accessToken
               	}
               vm.loading=true;
                ajax.getAccountDetails(request).success(function(response) {
                	if(response && response!="")
                		{
                    	if (response.stat == 'error' && response.code == '402')
                    	{
                    		$state.go("signin");
                    	} else {
                		var userAccounts = response.mcCustProfileDetailsList;
		                    for(var i=0;i<userAccounts.length;i++)
		                    {
		                    if(request.email==userAccounts[i].accountid)
		                    {
		                    vm.firstName=userAccounts[i].first_NAME;
		                    vm.lastName=userAccounts[i].last_NAME;
		                    vm.language=userAccounts[i].preferred_LANGUAGE.toLowerCase();
		                    }
		                    }
		                    vm.loading=false;
                		}
                		}
                	else
                		{
                		 $scope.error="serverError";
                         $scope.errorDesc="serverError_desc";
                         vm.loading=false;
                         showError();
                		}
                	
                }).error(function(error) {
                                    $scope.error="serverError";
                                    $scope.errorDesc="serverError_desc";
                                    vm.loading=false;
                                    showError();
                });

}


function submit(){

vm.submitted = true;
    if($scope.addAccountForm.$valid)
     {
        var request = {
                 emailAddress:vm.user.email,
				 firstName: vm.firstName,
				 lastName : vm.lastName,
				 preferredLanguage:vm.language,
				 accessToken : vm.user.accessToken
		 }
		vm.loading = true;
        ajax.updateAccount(request).success(function(response) {
            if(response.status.toLowerCase()=="success")
            {
                vm.loading = false;
                showPopup("InfoUpdated");
                // Recent Account Activity changes
                var accountNumber = rymcService.getLocalStorage("accountNumber");
                rymcService.updateAccountActivity(vm.user.email, vm.user.accessToken, accountNumber, 'Personal Information Updated');
            }
            else if(response==""){
            	 vm.loading = false;
                 $scope.error="serverError";
                 $scope.errorDesc="serverError_desc";
                 showError();
                 return false;
            }
            else
            {
                vm.loading = false;
                $scope.error="updatePersonalInfoFailed";
                $scope.errorDesc="updatePersonalInfoFailed_desc";
                showError();
                return false;
            }

        }).error(function(error) {
                   vm.loading = false;
                   $scope.error="serverError";
                   $scope.errorDesc="serverError_desc";
                   showError();
                   return false;
        });
     }
     else
     {
     return false;
     }

}

function showError(){
    modalInstance = $uibModal.open({
        templateUrl: 'views/error_popup.html',
        scope: $scope,
        windowClass: 'registrationKey-modal'
    });
}
$scope.existClose = function () {
        modalInstance.close();
}
function showPopup(popName) {
$scope.pop_desc=popName;
        modalInstance = $uibModal.open({
            templateUrl: 'views/confirm_popup.html',
            scope: $scope,
            windowClass: 'long-modal'
        });
    }

$scope.gotoAccountInfo=function()
{
	history.back();
}

vm.init();

}
})();
 