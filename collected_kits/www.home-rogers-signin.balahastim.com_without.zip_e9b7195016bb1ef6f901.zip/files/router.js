'use strict';

angular
		.module('rymcApp')
		.config(
				[
						'$stateProvider',
						'$urlRouterProvider',
						'$httpProvider',
						'settings',
						function($stateProvider, $urlRouterProvider,
								$httpProvider, settings) {

							$urlRouterProvider.otherwise('/signin');
							// $urlRouterProvider.otherwise('error404'); // Send
							// them to '/' = home or '/error404'
							$stateProvider

									// HOME STATES AND NESTED VIEWS
									// ========================================
									.state(
											'signin',
											{
												url : '/signin',
												controller : 'signinCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/signin/signin.html',
												data : {
													requireLogin : false
												}
											})
									.state(
											'signout',
											{
												url : '/signout',
												controller : 'signoutCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/signin/signin.html',
												data : {
													requireLogin : true
												}
											})
									.state('logout', {
										url : '/logout',
										controller : 'signoutCtrl',
										controllerAs : 'vm',
										// templateUrl :
										// 'js/modules/signin/signin.html',
										data : {
											requireLogin : true
										}
									})
									.state(
											'registration',
											{
												url : '/registration',
												controller : 'registrationCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/registration/registration.html',
												data : {
													requireLogin : false
												}
											})
									.state(
											'forgotPassword',
											{
												url : '/forgotPassword',
												controller : 'forgotPasswordCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/forgotPassword/forgotPassword.html',
												data : {
													requireLogin : false
												}
											})
									.state(
											'verification',
											{
												url : '/verification',
												controller : 'verificationCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/verification/verification.html',
												data : {
													requireLogin : false
												}
											})
									.state(
											'dashboard',
											{
												url : '/dashboard',
												controller : 'dashboardCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/dashboard/dashboard.html',
												data : {
													requireLogin : true
												}
											})
									.state(
											'addAccount',
											{
												url : '/addAccount',
												controller : 'addAccountCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/addAccount/addAccount.html',
												data : {
													requireLogin : true
												}
											})
									.state(
											'addPrimaryAccount',
											{
												url : '/addPrimaryAccount',
												controller : 'addPrimaryAccountCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/addPrimaryAccount/addPrimaryAccount.html',
												data : {
													requireLogin : false
												}
											})
									.state(
											'authorizedApplications',
											{
												url : '/authorizedApplications',
												controller : 'authorizedApplicationsCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/authorizedApplications/authorizedApplications.html',
												data : {
													requireLogin : true
												}
											})
									.state(
											'alternateContactInfo',
											{
												url : '/alternateContactInfo',
												controller : 'alternateContactInfoCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/alternateContactInfo/alternateContactInfo.html',
												data : {
													requireLogin : true
												}
											})
									.state(
											'authentication',
											{
												url : '/authentication',
												controller : 'authenticationCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/authentication/authentication.html',
												data : {
													requireLogin : true
												}
											})
									.state(
											'accountInformation',
											{
												url : '/accountInformation',
												controller : 'accountInformationCtrl',
												templateUrl : 'js/modules/accountInformation/accountInformation.html',
												data : {
													requireLogin : true
												}
											})
									.state(
											'changePassword',
											{
												url : '/changePassword',
												controller : 'changePasswordCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/changePassword/changePassword.html',
												data : {
													requireLogin : true
												}
											})
									.state(
											'notifyChangePassword',
											{
												url : '/notifyChangePassword',
												controller : 'notifyChangePasswordCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/notifyChangePassword/notifyChangePassword.html',
												data : {
													requireLogin : true
												}
											})
									.state(
											'personalInformation',
											{
												url : '/personalInformation',
												controller : 'personalInformationCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/personalInformation/personalInformation.html',
												data : {
													requireLogin : true
												}
											})
									.state(
											'accountActivity',
											{
												url : '/accountActivity',
												controller : 'accountActivityCtrl',
												controllerAs : 'vm',
												templateUrl : 'js/modules/accountActivity/accountActivity.html',
												data : {
													requireLogin : true
												}
											})

						} ]);
