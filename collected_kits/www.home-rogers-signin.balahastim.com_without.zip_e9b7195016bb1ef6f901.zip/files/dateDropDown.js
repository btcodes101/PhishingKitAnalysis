(function () {
  'use strict';

  var dd = angular.module('rorymadden.date-dropdowns', []);

  dd.factory('rsmdateutils', function () {

    var that = this,
        dayRange = [1, 31],
        months = [
          'Jan',
          'Feb',
          'Mar',
          'Apr',
          'May',
          'Jun',
          'Jul',
          'Aug',
          'Sep',
          'Oct',
          'Nov',
          'Dec'
        ],
        monthsfr = [
          'Janv',
          'F&eacute;vr',
          'Mars',
          'Avril',
          'Mai',
          'Juin',
          'Juil',
          'Ao&ucirc;t',
          'Sept',
          'Oct',
          'Nov',
          'D&eacute;c'
        ];



    function changeDate (date) {
      if(date.day > 28) {
        date.day--;
        return date;
      } else if (date.month > 11) {
        date.day = 31;
        date.month--;
        console.log(date);
        return date;
      }
    };

    return {
      checkDate: function (date) {
        var d;

        if (isNaN(date.day) || date.month === null || date.month === undefined || isNaN(date.year)) return false;

        d = new Date(date.year, date.month, date.day);

        if (d && (d.getMonth() === date.month && d.getDate() === Number(date.day))) {
          return d;
        }
        return this.checkDate(changeDate(date));
      },
      days: (function () {
        var days = [];
        while (dayRange[0] <= dayRange[1]) {
          days.push(dayRange[0]++);
        }
        return days;
      }()),
      months: (function () {
        var lst = [],
            mLen = months.length;

        for (var i = 0; i < mLen; i++) {
          lst.push({
            value: i,
            name: months[i]
          });
        }
        return lst;
      }()),
        monthsfr: (function () {
          var lst = [],
              mLen = monthsfr.length;

          for (var i = 0; i < mLen; i++) {
            lst.push({
              value: i,
              name: monthsfr[i]
            });
          }
          return lst;
        }())
    };
  })

  dd.directive('rsmdatedropdowns', ['rsmdateutils', function (rsmdateutils) {
    return {
      restrict: 'A',
      replace: true,
      require: 'ngModel',
      scope: {
        model: '=ngModel',
        userlanguage:'='
      },
      controller: ['$scope','$rootScope', 'rsmdateutils', function ($scope, $rootScope,rsmDateUtils) {
        $scope.days = rsmDateUtils.days;
        /* console.log("directive lang "+ $scope.userlanguage);*/
        if($scope.userlanguage=='en')
        $scope.months = rsmDateUtils.months;

        if($scope.userlanguage=='fr')
        $scope.months = rsmDateUtils.monthsfr;

        $scope.$on('languageChanged', function(event, args) {
        if($scope.userlanguage=='en')
        $scope.months = rsmDateUtils.monthsfr;

                if($scope.userlanguage=='fr')
                $scope.months = rsmDateUtils.months;
        });


        $scope.dateFields = {};

        $scope.dateFields.day = new Date($scope.model).getUTCDate();
        $scope.dateFields.month = new Date($scope.model).getUTCMonth();
        $scope.dateFields.year = new Date($scope.model).getUTCFullYear();

        // Initialize with current date (if set)
        $scope.$watch('model', function (newDate) {
          if(newDate) {
            $scope.dateFields.day = new Date(newDate).getUTCDate();
            $scope.dateFields.month = new Date(newDate).getUTCMonth();
            $scope.dateFields.year = new Date(newDate).getUTCFullYear();
          }
        });

        $scope.checkDate = function () {
          var date = rsmDateUtils.checkDate($scope.dateFields);
         // console.log(date);
          if (date) {
            $scope.model = date;
          }
        };
      }],
      template:
      '<div class="form-inline">' +

      '     <select name="dateFields.day" ng-model="dateFields.day" placeholder="Day" class="date" ng-options="day for day in days" ng-change="checkDate()" ng-disabled="disableFields"></select>' +
      '    <select name="dateFields.month" ng-model="dateFields.month" placeholder="Month" class="month" ng-options="month.value as (month.name | inputFr) for month in months" value="{{ dateField.month | inputFr }}" ng-change="checkDate()" ng-disabled="disableFields"><options></options></select>' +
      '    <select ng-show="!yearText"  name="dateFields.year" ng-model="dateFields.year" placeholder="Year" class="year" ng-options="year for year in years" ng-change="checkDate()" ng-disabled="disableFields"></select>' +
      '    <input ng-show="yearText" type="text" name="dateFields.year" data-ng-model="dateFields.year" placeholder="Year" class="form-control" ng-disabled="disableFields">' +
      '</div>',
      link: function (scope, element, attrs, ctrl) {
        var currentYear = parseInt(attrs.startingYear, 10) || new Date().getFullYear(),
            numYears = parseInt(attrs.numYears,10) || 100,
            oldestYear = currentYear - numYears,
            overridable = [
              'dayDivClass',
              'dayClass',
              'monthDivClass',
              'monthClass',
              'yearDivClass',
              'yearClass'
            ],
            required;

        scope.years = [];
        scope.yearText = attrs.yearText ? true : false;

        if (attrs.ngDisabled) {
          scope.$parent.$watch(attrs.ngDisabled, function (newVal) {
            scope.disableFields = newVal;
          });
        }

        if (attrs.required) {
          required = attrs.required.split(' ');

          ctrl.$parsers.push(function (value) {
            angular.forEach(required, function (elem) {
              if (!angular.isNumber(elem)) {
                ctrl.$setValidity('required', false);
              }
            });
            ctrl.$setValidity('required', true);
          });
        }

        for (var i = currentYear; i >= oldestYear; i--) {
          scope.years.push(i);
        }

        (function () {
          var oLen = overridable.length,
              oCurrent,
              childEle;
          while (oLen--) {
            oCurrent = overridable[oLen];
            childEle = element[0].children[Math.floor(oLen / 2)];

            if (oLen % 2 && oLen != 2) {
              childEle = childEle.children[0];
            }

            if (attrs[oCurrent]) {
              angular.element(childEle).attr('class', attrs[oCurrent]);
            }
          }
        }());
      }
    };
  }]);
}());