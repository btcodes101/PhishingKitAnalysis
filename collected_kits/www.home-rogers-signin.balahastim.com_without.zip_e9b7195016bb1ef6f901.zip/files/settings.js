'use strict';

angular.module('rymcApp').constant('settings', {
	supportedLanguages : {
		en : 'English',
		fr : 'Français'
	},
	defaultLanguage : 'en',
	allowedNumberofAccounts : 9,
	allowedAlternateContacts : 12,
	samlAPIRequestAPI : 'https://api.login.yahoo.com/oauth2/request_auth',
	rymcAPIRequestAPI : '',
	janrainLoginAPIMethod : '/oauth/auth_native_traditional',
	janrainLoginAPI : 'https://rogers-dev.janraincapture.com',
	janrainApacheURL : 'http://10.18.69.231:8081/janrain',
	// jainRainRequestParams:{client_id:'bydbyendue6bpg6prjfb26xgjhjhcwgn',
	jainRainRequestParams : {
		client_id : 'y9vbbs2wjf7uxhsnbg8txb6qhffdwgpd',
		flow : 'standard_email',
		redirect_url : 'https://localhost',
		flow_version : '20170210215725516621',
		response_type : 'token',
		locale : 'en-US'
	}
	
/*
 * isLocal: window.location.host.match('localhost'), //change to false in
 * production isDev: window.location.host.match('10.18.64.212'), isQa:
 * window.location.host.match('qa'), isProd:
 * window.location.host.match('www.rogers.com') /*jainRainApi:{
 * dev:'https://rogers-dev.janraincapture.com/oauth/auth_native_traditional',
 * qa:'https://rogers-dev.janraincapture.com/oauth/auth_native_traditional',
 * prod:'https://rogers-dev.janraincapture.com/oauth/auth_native_traditional', },
 */
}).config(
		[ 'KeepaliveProvider', 'IdleProvider',
				function(KeepaliveProvider, IdleProvider,sessionTimeout) {
					IdleProvider.idle(1200);//default value is 20 minutes
					IdleProvider.timeout(30);//default value is 30 seconds
					KeepaliveProvider.interval(600);//default 10 mins
					//Keepalive sends request to server every 10 mins as per default interval, to keep session alive
					KeepaliveProvider.http("../rmcapp/heartbeat");
				} ]).run(
		[
				'$rootScope',
				'rymcService',
				'$state',
				'sessionStorage',
				'Idle',
				'$uibModal',
				'Keepalive',
				'$cookies',
				'ajax',
				function($rootScope, rymcService, $state, sessionStorage, Idle,
						$uibModal, Keepalive, $cookies, ajax) {

					var started = false;
					var warning;
					var timedout;
					//set the Idle service idle value alone from server timeout value
					var sessionTimeout = rymcService.getSessionTimeOut().then(function(value){
						Idle.setIdle(value);
					});
					
										
					function closeModals() {
						if (warning) {
							warning.close();
							warning = null;
						}
						if (timedout) {
							timedout.close();
							$state.go("signin");
							timedout = null;
						}
					}
					$rootScope.$on('IdleStart', function() {
						closeModals();
						warning = $uibModal.open({
							templateUrl : 'views/warning-dialog.html',
							windowClass : 'modal-danger'
						});
					});
					$rootScope.$on('IdleEnd', function() {
						Idle.unwatch();
						started = false;
						closeModals();
					});
					$rootScope.$on('IdleTimeout', function() {
						closeModals();
						timedout = $uibModal.open({
							templateUrl : 'views/timedout-dialog.html',
							windowClass : 'modal-danger'
						});
						// setTimeout(function(){closeModals();},2000);
						setTimeout(function() {
							rymcService.logOff(false);
						}, 500);
					});

					$rootScope.closetimedOut = function() {
						timedout.close();
					}

					$rootScope.$on('$stateChangeStart', function(event,
							toState, toParams) {
				        if(toState.name!="signin")
				        $rootScope.basePath=toState.name;
						var requireLogin = toState.data.requireLogin;
						var UserSession = "";
						UserSession = rymcService.getSignedInUser();

						if (UserSession) {
							$rootScope.signInHeader=false;
							Idle.watch();
							
						} else {
							$rootScope.signInHeader=true;
							Idle.unwatch();

						}

						if (requireLogin && !UserSession) {
							event.preventDefault();
							$state.go("signin");
						}

						if (!requireLogin && UserSession) {
						ajax.getAccountDetails(rymcService.getSignedInUser()).success(function(response) {
							if (response!= null && response != ""  && response.stat != "error") {
								event.preventDefault();
								$state.go("dashboard");
							} else {
								$rootScope.signInHeader=true;
								Idle.unwatch();
								sessionStorage.clearAllSessionStorageValues();
								rymcService.clearLocalStorage();
								$cookies.remove('signedInUser');
								event.preventDefault();
								$state.go("signin");
							}
						}).error(function(error) {
							$rootScope.signInHeader=true;
							Idle.unwatch();
							sessionStorage.clearAllSessionStorageValues();
							rymcService.clearLocalStorage();
							$cookies.remove('signedInUser');
							event.preventDefault();
							$state.go("signin");
						})
						}
						if (rymcService.getLocalStorage("forcePassword")
								&& toState.name != "changePassword") {
							sessionStorage.clearAllSessionStorageValues();
							rymcService.clearLocalStorage();
						}
						// get me a login screen!

					});

				} ]);
