(function() {
	'use strict';

	angular.module('rymcApp').controller('signoutCtrl', signoutCtrl);

	signoutCtrl.$inject = [ '$scope', 'rymcService'];

	function signoutCtrl($scope, rymcService) {
		var vm = this;

		function init() {
			rymcService.logOffYahoo();
		}
		init();
	}
})();
