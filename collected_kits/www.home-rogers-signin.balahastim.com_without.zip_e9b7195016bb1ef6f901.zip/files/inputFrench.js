'use strict';

angular.module('rymcApp').

filter('inputFr', function() {
    return function(input) {

      if (!input) {
        return '';
      }
      var inputStr = $('<textarea />').html(input).text();

      var retVal = inputStr;

      return (retVal);
    };
  })


