(function() {
  'use strict';

angular.module('rymcApp').controller('alternateNumberCtrl', alternateNumberCtrl);

alternateNumberCtrl.$inject = ['$scope','$uibModalInstance','rymcService','ajax'];

function alternateNumberCtrl($scope,$uibModalInstance,rymcService,ajax) {
$scope.submitted=false;
$scope.loading=false;
$scope.submit = function(){

$scope.submitted = true;

    // if($scope.signinForm.$valid && $scope.status)
     if($scope.alternateContact.$valid)
     {


        if($scope.alternatePhone)
        {
        $scope.savePhone();
        }
        if($scope.alternateEmail){
        $scope.saveEmail();
        }

     }
     else
     {
     return false;
     }
   }


   $scope.savePhone=function(){
        var request  = {
        emailAddress:rymcService.getSignedInUser().email,
        secondaryPhone:$scope.alternatePhone,
        accountStatus:"create",
        //accountNumber:rymcService.getSignedInUser().account_NUMBER,
        accountNumber:rymcService.getLocalStorage("accountNumber"),
        primaryFlag:"y"
        };
        $scope.loading=true;
     ajax.createAlternatePhone(request).success(function(response) {

     if(response.status=="success")
     {

        $scope.loading=false;
         $uibModalInstance.close({
           alternatePhone: $scope.alternatePhone,
           alterNateEmail: $scope.alternateEmail
       });
     }
     else
     {
            $scope.error="createAccountFailed";
            $scope.errorDesc="createAccountFailed_desc";
            $scopeshowError();
            $scope.loading=false;
            return false;

     }
     },function(error){
             $scope.error="serverError";
             $scope.errorDesc="serverError_desc";
             $scope.showError();
             $scope.loading=false;
             return false;
     });

        //ajax call save phone
    }



    $scope.saveEmail=function(){
               var request  = {
            	  emailAddress:rymcService.getSignedInUser().email,
                  secondaryEmail:$scope.alternateEmail,
                  accountStatus:"create",
                  //accountNumber:rymcService.getSignedInUser().account_NUMBER,
                  accountNumber:rymcService.getLocalStorage("accountNumber"),
                  primaryFlag:"y"
                  };
               $scope.loading=true;
               ajax.createAlternateEmail(request).success(function(response) {

               if(response.status=="success")
               {
                     $scope.loading=false;
                       $uibModalInstance.close({
                                alternatePhone: $scope.alternatePhone,
                                alterNateEmail: $scope.alternateEmail
                            });
               }
               else
               {
                      $scope.error="createAccountFailed";
                      $scope.errorDesc="createAccountFailed_desc";
                      showError();
                      $scope.loading=false;
                      return false;

               }
               },function(error){
                       $scope.error="serverError";
                       $scope.errorDesc="serverError_desc";
                       showError();
                       $scope.loading=false;
                       return false;
               });

    }

       $scope.showError=function(){
            modalInstance = $uibModal.open({
                templateUrl: 'views/error_popup.html',
                scope: $scope,
                windowClass: 'registrationKey-modal'
            });
        }

    $scope.existClose = function () {
       modalInstance.close();
    }
}

})();
 