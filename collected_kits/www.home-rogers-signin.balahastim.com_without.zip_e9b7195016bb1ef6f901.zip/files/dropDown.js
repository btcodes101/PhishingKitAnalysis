'use strict';

/**
 * @ngdoc Directive
 * @name deviceModel
 * @description
 * # A directive showing one product, smartphone, basic phone or tablet.
 *  Usage: <device-model data-device='model' data-settings='settings'></device-model>
 *    'data-device': introduce an array of product (belong to same model) from outside scope.
 *    'data-settings': settings
 *
 */

angular.module('rymcApp')
  .directive('dropDown', dropDown)
  .controller('dropDownCtrl', dropDownCtrl);


function dropDown() {
  var varDirective = {
    restrict: 'E',
    templateUrl: 'js/directives/dropDown/dropDown.html',
    controller: dropDownCtrl,
    controllerAs: 'vm'
  };
  return varDirective;
}
dropDownCtrl.$inject = ['rymcService','$scope','$translate'];
function dropDownCtrl(rymcService,$scope) {

   $scope.callCodes=rymcService.getCountryCodes();
   			function DropDown(el) {
   				this.dd = el;
   				this.placeholder = this.dd.children('span');
   				this.opts = this.dd.find('ul#ctns > li');
   				this.val = '';
   				this.index = -1;
   				this.initEvents();
   			}
   			DropDown.prototype = {
   				initEvents : function() {
   					var obj = this;

   					obj.dd.on('click', function(event){
   						$(this).toggleClass('active');
   						return false;
   					});

   					obj.opts.on('click',function(){
   						var opt = $(this);
   						obj.val = opt.val();

   						obj.index = opt.index();
   						obj.placeholder.text(obj.val);

   					});
   				},
   				getValue : function() {
   					return this.val;
   				},
   				getIndex : function() {
   					return this.index;
   				}
   			}

   			$(function() {

   				var dd = new DropDown( $('#dd') );
    				$(document).click(function() {
   					// all dropdowns
   					$('.wrapper-dropdown-3').removeClass('active');
   				});

   			});




var step = 25;
var scrolling = false;

// Wire up events for the 'scrollUp' link:
$("#down").bind("click", function(event) {
    event.preventDefault();
    // Animates the scrollTop property by the specified
    // step.
    $("#content").animate({
        scrollTop: "-=" + step + "px"
    });
}).bind("mouseover", function(event) {
    scrolling = true;
    scrollContent("up");

}).bind("mouseout", function(event) {
    scrolling = false;
});


$("#up").bind("click", function(event) {
    event.preventDefault();
    $("#content").animate({
        scrollTop: "+=" + step + "px"
    });
}).bind("mouseover", function(event) {
    scrolling = true;
    scrollContent("down");
}).bind("mouseout", function(event) {
    scrolling = false;
});
function scrollContent(direction) {
    var amount = (direction === "up" ? "-=3px" : "+=3px");
    $("#ctns").animate({
        scrollTop: amount
    }, 1, function() {
        if (scrolling) {
            // If we want to keep scrolling, call the scrollContent function again:
            scrollContent(direction);
        }
    });
}

}