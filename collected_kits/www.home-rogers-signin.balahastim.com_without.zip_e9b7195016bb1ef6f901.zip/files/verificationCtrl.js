(function() {
  'use strict';

angular.module('rymcApp').controller('verificationCtrl', verificationCtrl);

verificationCtrl.$inject = ['$scope','$window','$state','rymcService','$rootScope','sessionStorage','ajax','$uibModal','deviceDetector'];

function verificationCtrl($scope,$window,$state,rymcService,$rootScope,sessionStorage,ajax,$uibModal,deviceDetector) {

var vm=this;
rymcService.setCurrentPage("passwordRecovery");
$rootScope.$broadcast("pageChanged");
vm.submit=submit;
vm.submitPassword=submitPassword;
vm.passwordPattern=/^((?=.*[A-Za-z])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[a-zA-Z]))|((?=.*[A-Z])(?=.*[a-z]))[A-Za-z\d-!@#$%*]{7,32}$/;
vm.userVerified=false;
vm.forgotPasswordDetails=sessionStorage.getSessionStorageObject('forgotPassword');
var modalInstance;
vm.todayDate=new Date();
vm.gotoSignIn=gotoSignIn;
vm.date_DOB='';
vm.loading = false;
function submit(){
vm.invalidDate=false;
vm.submitted = true;

        var request={
        "securityAnswer":vm.answer,
        "dob":formatDOB(vm.date_DOB),
        "email":vm.forgotPasswordDetails.email,
        "securityQuestion":vm.forgotPasswordDetails.securityQuestion,
        }
    console.log(request);
    if(vm.date_DOB>vm.todayDate)
     {
      vm.invalidDate=true;
     }
     else
     {
    	 vm.loading = true;
     ajax.validateSecurityQuery(request).success(function(response) {

    	 vm.loading=false;
       if(response.status.toLowerCase()=="success")
       {
           if(response.verified)
           {
           vm.userVerified=true;
           vm.submitted=false;
           rymcService.setRandomToken(response.randomToken);
           }
           else
           {
           vm.invalidUser=true;
           }
       }
       else if(response=="")
    	   {
    	   vm.loading=false;
    	   $scope.error="serverError";
           $scope.errorDesc="serverError_desc";
           showError();
           return false;
    	   }
       else
      {
    	      vm.loading=false;
    	      $scope.error="validateSecurityFailed";
              $scope.errorDesc="validateSecurityFailed_desc";
              showError();
              return false;
      }
     }).error(function(error) {
    	     vm.loading=false;
             $scope.error="serverError";
             $scope.errorDesc="serverError_desc";
             showError();
             return false;
     });

}



}

function showError(){
    modalInstance = $uibModal.open({
        templateUrl: 'views/error_popup.html',
        scope: $scope,
        windowClass: 'registrationKey-modal'
    });
}

function submitPassword(){
    vm.submitted = true;
    vm.loading = true;
        var request={
        "email":vm.forgotPasswordDetails.email,
        "password":vm.newPassword,
        "account_Number":vm.forgotPasswordDetails.account_Number,
        "randomToken":rymcService.getRandomToken()
        }
   ajax.passwordRecovery(request).success(function(response) {
     if(response.status.toLowerCase()=="success")
       {
    	rymcService.setRandomToken(null);
        var emailAddress = vm.forgotPasswordDetails.email;
    	sessionStorage.deleteSessionStorageObject('forgotPassword');
        $scope.showPopup('updatedPassword');
        // Recent Account Activity changes
        rymcService.updateAccountActivity(emailAddress, '', '', 'Password Recovery');
       }
          else
         {
                 $scope.error="passwordRecoveryFailed";
                 $scope.errorDesc="passwordRecoveryFailed_desc";
                 showError();
                 vm.loading = false;
                 return false;
         }


   }).error(function(error) {

               $scope.error="serverError";
               $scope.errorDesc="serverError_desc";
               showError();
               vm.loading = false;
               return false;
  });



}


$scope.showPopup = function (popName) {
$scope.pop_desc=popName;
        modalInstance = $uibModal.open({
            templateUrl: 'views/confirm_popup.html',
            scope: $scope,
            windowClass: 'long-modal'
        });
    }
$scope.existClose = function () {
        modalInstance.close();
        $state.go("signin");
}
$scope.updatePassword=function()
{
modalInstance.close();
$state.go("signin");
}

    function formatDOB(dob){
        var dateofBirth=new Date(dob);
        var month=dateofBirth.getUTCMonth()+1;
        var formattedDate=dateofBirth.getUTCFullYear()+"-"+month+"-"+dateofBirth.getUTCDate();
        return formattedDate;
    }

/*    function updateAccountActivity()
    {
    	var updateInfoRequest = {
    			"emailAddress":vm.forgotPasswordDetails.email,
    			"accountNumber":"",
    			"activityType":"Password Recovery",
    			"deviceType" : deviceDetector.os,
    			"location" : geoplugin_countryName(),
    			"accessToken": ""
    	}
    	ajax.updateAccountActivity(updateInfoRequest).success(function(response) {
            if(response.status=='ok')
            return true;
    	});
    }
*/
    function gotoSignIn()
    {
    $state.go("signin");
    }
       $('#newPassword').keyup(function(){
                   var password=$("#newPassword").val();
                   var len=$("#newPassword").val().length;
                    var patt = /^((?=.*[A-Za-z])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[-!@#$%*]))|((?=.*[0-9])(?=.*[a-zA-Z]))|((?=.*[A-Z])(?=.*[a-z]))[A-Za-z\d-!@#$%*]{7,32}$/;
                    var pattTest=patt.test(password);
                    vm.username=vm.forgotPasswordDetails.email;
                    var sameAsUsername
                    if(password==vm.username)
                    sameAsUsername=true;
                    else
                    sameAsUsername=false;
                    if(len==0)
                    {
                    vm.progressCompletion=0;
                   $(".progress-bar").addClass("bg-invalid");
                   $(".progress-bar").removeClass("bg-valid");
                   $(".progress-bar").removeClass("bg-success");

                    }
                    if((len>0 && len<7) || (sameAsUsername))
                   {
                   vm.progressCompletion=25;
                   $(".progress-bar").addClass("bg-invalid");
                  $(".progress-bar").removeClass("bg-valid");
                  $(".progress-bar").removeClass("bg-success");

                   }
                   if(pattTest && len>6 && len<=9 && !sameAsUsername)
                   {
                   $(".progress-bar").addClass("bg-valid");
                   $(".progress-bar").removeClass("bg-invalid");
                   $(".progress-bar").removeClass("bg-success");
                   vm.progressCompletion=75;

                   }
                    if(pattTest && len>9 && !sameAsUsername)
                   {
                   $(".progress-bar").addClass("bg-success");
                  $(".progress-bar").removeClass("bg-invalid");
                  $(".progress-bar").removeClass("bg-valid");
                   vm.progressCompletion=100;

                   }
            $scope.$apply();
               });
}
})();
 