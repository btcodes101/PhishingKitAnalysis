'use strict';

/**
 * @ngdoc Directive
 * @name deviceModel
 * @description
 * # A directive showing one product, smartphone, basic phone or tablet.
 *  Usage: <device-model data-device='model' data-settings='settings'></device-model>
 *    'data-device': introduce an array of product (belong to same model) from outside scope.
 *    'data-settings': settings
 *
 */

angular.module('rymcApp')
  .directive('appFooter', appFooter)
  .controller('appFooterCtrl', appFooterCtrl);


function appFooter() {
  var varDirective = {
    restrict: 'E',
    templateUrl: 'js/directives/appFooter/appFooter.html',
    controller: appFooterCtrl,
    controllerAs: 'vm'
  };
  return varDirective;
}
appFooterCtrl.$inject = ['$scope','$translate','rymcService','sessionStorage','$state','$cookies','$rootScope'];

function appFooterCtrl($scope,$translate,rymcService,sessionStorage,$state,$cookies,$rootScope) {

   $scope.$on('pageChanged', function(event, args) {
   $scope.currentYear=new Date().getFullYear();


       if($rootScope.signInHeader)
       $scope.showFooter=false;
       else
       $scope.showFooter=true;


   });

}
