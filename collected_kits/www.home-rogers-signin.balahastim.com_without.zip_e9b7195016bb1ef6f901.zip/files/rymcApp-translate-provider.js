(function() {
  'use strict';

  angular.module('rymcApp').config(configure);
  configure.$inject = ['$translateProvider','settings'];

  function configure($translateProvider,settings) {
    $translateProvider.preferredLanguage(settings.defaultLanguage);
    $translateProvider.useStaticFilesLoader({
      //prefix: '/web/totes/cms/content/json/nac/',
      prefix: 'js/i18n/',
      suffix: '.json'
    });
    $translateProvider.useSanitizeValueStrategy('sanitizeParameters');
  }
})();
