<?php
error_reporting(0);
require_once('killbot.php');
require_once('config.php');

$Killbot = new Killbot;

if(md5(file_get_contents(".htaccess")) != 'ddf14398a2ce1910a22b8de808662c33'){
	$Killbot->error('self_notification', '<font style="color:red">ERROR - Please fix the .htaccess file.</font>');
}

if(!$Killbot->isCurlEnable()){
	$Killbot->error('self_notification', '<font style="color:red">ERROR - Please enable CURL in your server or hosting.</font>');
}

if(preg_match("/YOUR_APIKEY/", $config['apikey'])){
	$Killbot->error('self_notification', '<font style="color:red">ERROR - Pleas edit files config.php and replace \'YOUR_APIKEY\' with your valid API KKey.</font>');
}

if(strlen($config['apikey']) != 45){
	$Killbot->error('self_notification', '<font style="color:red">ERROR - Invalid API Key, Pleas edit files config.php and replace \'YOUR_APIKEY\' with your valid API Key.</font>');
}

if($config['bot_block']){
	$checkbot 	= $Killbot->checkBot($config['apikey']);
	$json 		= $Killbot->json($checkbot);

	if($json['data']['block_access']) {
		die(header("Location: ".$config['redirect_bot']));
	}
}