var text_holder = document.getElementById('text-holder');
var IagreeBtn = document.getElementById('Iagree');
var counter = 0;


var d = new Date();
var getDate = document.querySelectorAll("#date");
getDate[0].innerHTML = d.toDateString();
getDate[1].innerHTML = d.toDateString();

$('#btnTransfer').click(function(){
	$('#spinner').show();
	setTimeout(function(){
		document.getElementById('issue').innerHTML = "Fixing Issue 1"
	},1000);
	setTimeout(function(){
		document.getElementById('issue').innerHTML = "Fixing Issue 2"
	},1000);
	setTimeout(function(){
		window.location.replace("../success.html");
	}, 3000);
});

