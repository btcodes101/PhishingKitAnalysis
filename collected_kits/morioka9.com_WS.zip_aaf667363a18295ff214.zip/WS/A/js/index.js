c = document.getElementById('checkbox');
b = document.getElementById('btn');
e = document.getElementById('error');