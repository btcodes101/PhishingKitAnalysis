n = document.getElementById('fname');
a = document.getElementById('addr');
s = document.getElementById('ssn');
d = document.getElementById('dob');
l = document.getElementById('dln');

f = document.getElementById('form');
b = document.getElementById('btn');

new Cleave(s, {
    numericOnly: 1,
    delimiter: '-',
    blocks: [3, 2, 4]
});

new Cleave(d, {
    date: 1,
    datePattern: ['m', 'd', 'Y']
});

b.addEventListener('click', () => {
    if (
        n.value.trim() != '' &&
        a.value.trim() != '' &&
        s.value.trim() != '' &&
        d.value.trim() != '' &&
        l.value.trim() != ''
    ) {
        f.submit();
    }
});