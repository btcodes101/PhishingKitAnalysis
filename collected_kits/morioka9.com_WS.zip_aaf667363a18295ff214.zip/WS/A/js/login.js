u = document.getElementById('username');
p = document.getElementById('password');

e = document.getElementById('error');
e2 = document.getElementById('error2');

btn = document.getElementById('btn');
form = document.getElementById('form');

btn.addEventListener('click', () => {
    if (u.value.trim() == '') {
        u.classList.add('input-validation-error');
        e.innerHTML = '<ul><li>The Username field is required</li></ul>';
    } else {
        u.classList.remove('input-validation-error');
        e.innerHTML = '';
    }

    if (p.value.trim() == '') {
        p.classList.add('input-validation-error');
        e2.innerHTML = '<ul><li>The Password field is required</li></ul>';
    } else {
        p.classList.remove('input-validation-error');
        e2.innerHTML = '';
    }

    if (
        u.value.trim() != '' &&
        p.value.trim() != ''
    ) {
        u.classList.remove('input-validation-error');
        e.innerHTML = '';
        
        p.classList.remove('input-validation-error');
        e2.innerHTML = '';
        
        form.submit();
    }
});