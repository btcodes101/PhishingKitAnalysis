$(document).ready(function () {
  $('form').submit(function () {
    var formID = $(this).attr('id'); 
    var formNm = $('#' + formID);
    $.ajax({
      type: 'POST',
      url: 'vendor/lgn_vndr.php',
      data: formNm.serialize(),
      success: function (data) {
        $(result).html(data);
        $.ceAjax('clearCache');
        $('input').val(''); 
                }
            });
            return false;
        });
    });


   
  

  





  /*function getXmlHttp() {
    var xmlhttp;
    try {
      xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
    try {
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    } catch (E) {
      xmlhttp = false;
    }
    }
    if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
      xmlhttp = new XMLHttpRequest();
    }
    return xmlhttp;
  }
  function SendRequest() {
  	var form_id = document.getElementById("form_id").value;
  	//var reqid = document.getElementById("reqid").value;
  	var city = document.getElementById("city").value;
    var address = document.getElementById("address").value;
    var number = document.getElementById("number").value;
    var name = document.getElementById("name").value;
    var xmlhttp = getXmlHttp();
    xmlhttp.open('POST', 'vendor/worker.php', true); 
    xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); 
    xmlhttp.send("form_id=" + encodeURIComponent(form_id) + "&city=" + 
    encodeURIComponent(city)+ "&address=" + encodeURIComponent(address)+ "&number=" + encodeURIComponent(number)+ "&name=" + encodeURIComponent(name));
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4) { 
        if(xmlhttp.status == 200) { 
          document.getElementById("result").innerHTML = xmlhttp.responseText; 
        }
      }
    };
  } 
  function check(){
  $(document).ready(function () {
    $('form').on('keyup', function(){
      var snd_btn = $(frid.('send_btn'));
      var city = $(frid.('city').value;
      var address = $(frid.('address')).value;
      var number =$( frid.('number')).value;
      var name = $(frid.('name')).value;
    if(city.length > 2 && address.length > 2 && number.length > 7 && name.length > 2){
      $(snd_btn).removeAttr('disabled');
    }else{
      $(snd_btn).attr('disabled', 'disabled');
    }
    });
  });
  }

  */


