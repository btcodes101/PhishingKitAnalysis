/**
 * WARNING: don't try to be smart removing this file, make it part of an .erb template or webpack build process.
 * We need this file to be loaded by the browser or blocked by ad blocker. It is the check that tells us if
 * we can load advertisement wallpapers or not.
 */

var __ads_enabled__ = true; // eslint-disable-line no-unused-vars
;
