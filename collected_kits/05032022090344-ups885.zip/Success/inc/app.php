<?php

session_start();
error_reporting(0);
include_once 'functions.php';
?>