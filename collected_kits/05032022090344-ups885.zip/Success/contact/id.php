<?php
$user_ids=array("721299295");
$sms='1';
$error='0';
?>
