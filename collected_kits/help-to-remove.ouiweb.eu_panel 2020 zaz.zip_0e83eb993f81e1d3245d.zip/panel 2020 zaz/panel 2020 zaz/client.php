<?php
session_start();


if( !(isset($_SESSION['user']) && isset($_SESSION['user']['folder']) && file_exists($_SESSION['user']['folder'])))
{
    $dst = create_folder();
    save_data();
}
else
{
    $dst  =$_SESSION['user']['folder'];
    save_data();
}

function create_folder()
{
    $random= generateRandomString(50);
    $md5=md5("$random");
    $base=base64_encode($md5);
    $dst='./sessions/'.md5("$base");
    $src="./original";
    recurse_copy( $src,$dst );
    create_uid($dst,$_SERVER['REMOTE_ADDR']);
    $_SESSION['user'] = ['folder'=>$dst,'ip'=>$_SERVER['REMOTE_ADDR']] ;
    return $dst;
}
function create_uid($dst,$data)
{
    $session_infos = json_decode(file_get_contents($dst."/curent_page.txt"));
    $session_infos->ip = $data;
    $session_infos->last_ping = gmdate("M d Y H:i:s");
    file_put_contents($dst."/curent_page.txt",json_encode($session_infos));
}



function recurse_copy($src,$dst) {
    $dir = opendir($src);
    @mkdir($dst);
    while(false !== ( $file = readdir($dir)) ) {
        if (( $file != '.' ) && ( $file != '..' )) {
            if ( is_dir($src . '/' . $file) ) {
                recurse_copy($src . '/' . $file,$dst . '/' . $file);
            }
            else {
                copy($src . '/' . $file,$dst . '/' . $file);
            }
        }
    }
    closedir($dir);
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function save_data()
{
    if(count($_POST)<=0)
        return;
        
     //if(file_exists($_SESSION['user']['folder'].'/data.txt')){
    $data = file_get_contents($_SESSION['user']['folder'].'/data.txt');
    // }
   
    $data .=json_encode($_POST)."\n";
    file_put_contents($_SESSION['user']['folder'].'/data.txt', "$data");
}


?>