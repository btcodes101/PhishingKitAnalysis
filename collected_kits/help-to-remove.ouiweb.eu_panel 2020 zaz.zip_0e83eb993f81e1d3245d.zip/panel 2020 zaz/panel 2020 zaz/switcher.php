<?php
if($_SERVER['REQUEST_METHOD']=='OPTIONS')
{
    header("Access-Control-Allow-Origin: http://localhost:63342");
    header("Access-Control-Allow-Headers: Content-Type");
    echo '';
    exit();
}
header("Access-Control-Allow-Origin: http://localhost:63342");
header("Access-Control-Allow-Headers: Content-Type");

var_dump($_POST);
upate_page('sessions/'. $_POST['uid'],$_POST['page']);
function upate_page($dst,$data)
{
    $session_infos = json_decode(file_get_contents($dst."/curent_page.txt"));
    $session_infos->curent_page = $data;
    file_put_contents($dst."/curent_page.txt",json_encode($session_infos));
}
?>