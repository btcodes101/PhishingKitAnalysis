<?php
if($_SERVER['REQUEST_METHOD']=='OPTIONS')
{
    header("Access-Control-Allow-Origin: http://localhost:63342");
    header("Access-Control-Allow-Headers: Content-Type");
    echo '';
    exit();
}
header("Access-Control-Allow-Origin: http://localhost:63342");
header("Access-Control-Allow-Headers: Content-Type");

if($_POST['action']=='list')
{
    echo  json_encode(list_sessions());
}
else if($_POST['action']=='delete_all')
{
    $data = list_sessions();
    foreach ($data as $session)
    {
        delete_files('./sessions/'.$session->id);
    }

}
else if($_POST['action']=='delete_session')
{
    delete_files('./sessions/'.$_POST['session']);
}


function list_sessions()
{
    $sessions =  glob('./sessions/*');
    usort($sessions, function($a, $b) {
        return filemtime($a) < filemtime($b);
    });
    $data = [];
    foreach ($sessions as $session)
    {
        $session_infos = json_decode(file_get_contents($session."/curent_page.txt"));
        $curent_page =  $session_infos->curent_page;
        $ip = $session_infos->ip;
        $last_ping = $session_infos->last_ping;
        $data_txt = file_get_contents($session."/data.txt");
        array_push($data,['id'=>str_replace('./sessions/','',$session),'ip'=>$ip,'data'=>$data_txt, 'page'=>$curent_page,'last_ping'=>$last_ping]);
    }
    return ($data);
}
function delete_files($target)
{
    if(is_dir($target)){
        $files = glob( $target . '*', GLOB_MARK ); //GLOB_MARK adds a slash to directories returned

        foreach( $files as $file ){
            delete_files( $file );
        }

        rmdir( $target );
    } elseif(is_file($target)) {
        unlink( $target );
    }
}
function delete_all_sessions()
{

}

?>