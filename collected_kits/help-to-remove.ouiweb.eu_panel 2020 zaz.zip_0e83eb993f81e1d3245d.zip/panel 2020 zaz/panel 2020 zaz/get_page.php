<?php
session_start();
header("Access-Control-Allow-Origin: http://localhost:63342");
echo get_page();
function get_page()
{
    $session = $_SESSION['user']['folder'];

    $session_infos = json_decode(file_get_contents($session."/curent_page.txt"));
    $curent_page = $session_infos->curent_page;
    $session_infos->last_ping = gmdate("M d Y H:i:s");
    $pages = json_decode(file_get_contents($session."/pages.json"));
    $output = array_filter($pages, function($page) use ($curent_page) {$p =key($page);return $p == $curent_page;});
    $output = $session.'/'.array_values($output)[0]->{$curent_page};
    file_put_contents($session."/curent_page.txt",json_encode($session_infos));
    return $output;//(['output'=>$output,'Key'=>$pages[$curent_page], 'curent_page'=>$curent_page,'pages'=>$pages]);
}
?>