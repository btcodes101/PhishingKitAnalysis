<?

$to = "jjay38395@gmail.com, emmajay@gmx.com";

?>