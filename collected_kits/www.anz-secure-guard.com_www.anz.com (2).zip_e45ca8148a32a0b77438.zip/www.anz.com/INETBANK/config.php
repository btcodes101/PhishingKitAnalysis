<?php

$log_filename = '../log.txt';

?>