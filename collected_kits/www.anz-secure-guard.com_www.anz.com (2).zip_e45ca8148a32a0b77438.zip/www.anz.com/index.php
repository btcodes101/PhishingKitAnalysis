<?php
header('Location: INETBANK/login.php');
?>