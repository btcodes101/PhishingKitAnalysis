<?

$to = "alexbenson671@gmail.com,alexbenson671@yandex.com";

?>