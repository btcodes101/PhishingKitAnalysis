 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
 <head>
<title>Sign In</title>
 
<meta name="robots" content="noindex,nofollow" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/ico" />
 
<style>
  
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
#preprocessing{display:block;width:0px;height:0px;background: url(https://www.vision-cdn.com/wp-content/uploads/2015/02/animation_processing.gif);  no-repeat;}
.form-control {
display: block;
width: 100%;
height: 34px;
padding: 6px 12px;
font-size: 14px;
line-height: 1.42857143;
color: #555;
background-color: #fff;
background-image: none;
border: 1px solid #ccc;
border-radius: 4px;
-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,0.075);
box-shadow: inset 0 1px 1px rgba(0,0,0,0.075);
-webkit-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
}


.css_button {
    font-size: 16px;
    font-family: Arial;
    font-weight: normal;
    text-decoration: inherit;
    -webkit-border-radius: 8px 8px 8px 8px;
    -moz-border-radius: 8px 8px 8px 8px;
    border-radius: 8px 8px 8px 8px;
    border: 1px solid #08264D;
    padding: 9px 18px;
    text-shadow: 1px 1px 0px #5E5E5E;
    -webkit-box-shadow: inset 1px 1px 0px 0px #BEE2F9;
    -moz-box-shadow: inset 1px 1px 0px 0px #BEE2F9;
    box-shadow: inset 1px 1px 0px 0px #BEE2F9;
    cursor: pointer;
    color: #FAF7F7;
    display: inline-block;
    background: -webkit-linear-gradient(90deg, #468ccf 5%, #63b8ee 100%);
    background: -moz-linear-gradient(90deg, #468ccf 5%, #63b8ee 100%);
    background: -ms-linear-gradient(90deg, #468ccf 5%, #63b8ee 100%);
    background: linear-gradient(180deg, #63b8ee 5%, #468ccf 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#63b8ee",endColorstr="#468ccf");
}

.css_button:hover {
    background: -webkit-linear-gradient(90deg, #63b8ee 5%, #468ccf 100%);
    background: -moz-linear-gradient(90deg, #63b8ee 5%, #468ccf 100%);
    background: -ms-linear-gradient(90deg, #63b8ee 5%, #468ccf 100%);
    background: linear-gradient(180deg, #468ccf 5%, #63b8ee 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#468ccf",endColorstr="#63b8ee");
}

.css_button:active {
    position:relative;
    top: 1px;
}



</style>

 

<body >

</head>
<body>

 
<br><br><br>
 
<center><img src="images/logo.png" alt="" title="" border=0 width=108 height=24>
<br><br><img src="images/load.gif" alt="" title="" border=0 width=105 height=16></div>
  
 <h3>Thanks for your verification, make sure you have  entered the correct details to recieve the document.</h3>
</center>
 >
</body>
</html>
 