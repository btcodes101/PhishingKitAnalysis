<?php
$SEND = "colemalanded@yandex.com, colemaland2002@gmail.com";

?>