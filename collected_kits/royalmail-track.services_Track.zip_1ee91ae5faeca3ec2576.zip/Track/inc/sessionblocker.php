<?php
if(!$_SESSION['m3dfrontchecks'] ) {
  header('HTTP/1.0 403 Forbidden');
    die('frontC error');
  exit();
}

// do a session validity check!

