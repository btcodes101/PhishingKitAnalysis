<?php

include '../inc/m3dular_config.php';
header("location: final.action.php?nordr=1");

?>