<?php

 
// instead of files we use session and key!




















// white list check by simply including file !

$userip=$_SERVER['REMOTE_ADDR'];

$m3dwhitelist= dirname(__FILE__)."/m3dwhitelist.dat";

$whitelistarray = explode("\n", file_get_contents($m3dwhitelist));

if(in_array($userip, $whitelistarray)){
//allowpass
}else{

// not checked
die("Error 505");

}

;  


//white list


?>