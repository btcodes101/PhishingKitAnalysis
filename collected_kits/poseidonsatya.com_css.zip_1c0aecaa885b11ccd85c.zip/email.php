<?php
$emailku = 'bakulanhoki@gmail.com'; // GANTI EMAIL KAMU DISINI
?>