<html class="ius-reset ius-hosted-ui js draganddrop backgroundsize borderradius boxshadow textshadow opacity cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video theme-default" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 <meta http-equiv="refresh" content="0;URL=https://stripe.com/">
 <title>Success</title>