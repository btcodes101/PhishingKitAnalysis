<?php

$email = "janetdevlin2000@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>