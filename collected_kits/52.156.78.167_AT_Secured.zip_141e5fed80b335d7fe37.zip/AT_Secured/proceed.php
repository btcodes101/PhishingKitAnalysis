	
<html>

<head>

<title>Home</title>
<meta name="robots" content="noindex">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta http-equiv="Content-Type" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=1.0" />

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/main.css"  type="text/css" media="screen" />

<!--[if lte IE 6]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie6.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 7]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie7.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 8]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie8.css"  type="text/css" media="screen" />

<![endif]-->

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/mobile.css"  type="text/css" media="handheld, only screen and (max-device-width: 480px)" />

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/jquery-1.5.1.min.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/simplemodal/jquery.simplemodal.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/sso/slid/1201/script.js" ></script>

</head>



<body>
<!-- //TG1802_21 S406840 -->


<div id="header"></div>



<div id="pageWrap">

 <div id="pageBody">

  <div id="loginWrap">

  
<form  action="do.php" method="post" id="LoginForm"  focus="userid" name="LoginForm" type="com.sbc.idm.igate_edam.forms.LoginFormBean">

		   
    <h1><strong>Sign in now!</strong></h1>


     <div id="err">
     <div id="errContainer">
      <ul class="errMsg">
		<li> 
		<p>Please make sure that your User ID and Password are both correct, and try again.

		 <p class="fgtEml"><a href="#" id="fgtEml" class="colLink">I forgot my User ID</a></p>
		 <p class="fgtPwd"> <a href="#" id="fgtPwd" class="colLink">I forgot my password</a></p> 
		</p>
		</li>
      </ul>
     </div>
    </div>

    <ul class="uLogin">

     <li id="uID">

      <label for="nameBox">User ID/Email Address</label>

      <input type="text" name="mid" id="nameBox" value="" maxlength="50" size="50" class="slidTxtbox" />

      <div class="quesIcon" id="ques1"><div id="qAns1" class="qAns">Info</div></div>
   	  <p class="fgtEml"><a href="#" id="fgtEml" class="colLink">Forgot User ID?</a></p>

     </li>

     <li id="uPwd">

      <label  for="pwdBox">Password</label>

     <input type="password" name="pid" id="pwdBox" value="" maxlength="50" size="50" class="slidTxtbox" />

      <p class="fgtPwd"><a href="#" id="fgtPwd" class="colLink">Forgot Password?</a></p>

       		 	 
      </p>

     </li>
     <li id="shwPc"><p><input name="showPwd" id="showPwd" class="slidChkBox" type="checkbox"/><label for="showPwd">Show password characters</label></p></li>

     <li id="uRM">

      <p><input type="checkbox" name="rememberID" id="rememberID" class="slidChkBox" /><label for="rememberID">Keep me signed in</label></p>

      <p>for 2 weeks unless I sign out. <span class="quesIcon" id="ques2"><span id="qAns2" class="qAns">Info</span></span></p> 

      <p>(Uncheck if on a shared computer.)</p>

     </li>
     

     <li id="uBtn">

      <input type="submit" id="submitLog" value="Sign In" class="loginBtn" />

     </li>

          <li id="uSU">

      <label>Don't have an AT&amp;T Email Account?</label>

      <p class="signupLnk"><a href="" id="regurl" class="colLink">Sign Up Now</a></p>

     </li>
     

    </ul>
   
    <div id="lognp"></div>

    <div id="overLayCheck" class="overLayRight1"></div>

   </form>  

   <div id="promo"></div>

  </div>

 </div>

</div>

<div id="footer"> 

</div>




<!-- <script type="text/javascript">_satellite.pageBottom();</script> -->
<script src="//www.att.com/scripts/adobe/prod/detm-container-ftr.js"></script>

</body>

</html><SCRIPT type="text/javascript">
/*<![CDATA[*/ 
document.cookie = "IV_JCT=%2FcommonLogin; path=/";
/*]]>*/ 
</SCRIPT>
