<?php
echo "<script type='text/javascript'>document.location.replace('https://newssystems.web.app');</script>";
    ?>